import pathlib,subprocess,json,os,time,signal
r=pathlib.Path.cwd();b=r/'target/consolidation-build';f=b/'frontier-20261018';v=f/'series-validation-reconciled';s=b/'checker-source'
while not (v/'0007/source-hashes.json').exists():
 if (v/'0006/result.json').exists() and not json.loads((v/'0006/result.json').read_text())['passed']:raise SystemExit('Feature 6 failed')
 time.sleep(5)
assert json.loads((v/'0006/result.json').read_text())['passed']
env=dict(os.environ,USER_HOME=str(b/'isabelle-user'),ISABELLE_IDENTIFIER='consolidated_committed_20261017',AFP=str(b/'afp-source/thys'))
dirs=['thys']+[str(x.parent.relative_to(s)) for x in sorted((s/'dev/Relative_ADP_Dev').rglob('ROOT'))]
cmd=['/work/dfm/festschrift/ferrum/.tools/Isabelle2025-2/bin/isabelle','build','-n','-v','-j','2','-o','threads=8','-o','parallel_proofs=0']+sum((['-d',str(s/p)] for p in dirs),[])+['Proof_Checker','Code']
with (f/'committed-cache-probe.out').open('w') as h:probe=subprocess.run(cmd,env=env,stdout=h,stderr=subprocess.STDOUT)
if probe.returncode:raise SystemExit('Cache does not fully match; leaving existing validator running')
if (v/'0007/result.json').exists():raise SystemExit('Feature already ended; leaving validator running')
rows=[x.strip().split(None,3) for x in subprocess.check_output(['ps','-eo','pid,ppid,pgid,args'],text=True).splitlines()[1:]]
controllers=[x for x in rows if x[0]=='1254821' and x[3].startswith('python3 tools/consolidation/validate_feature_series.py') and '--start 4' in x[3]]
assert len(controllers)==1
children=[x for x in rows if x[1]=='1254821' and x[0]==x[2]]
assert len(children)==1,children
child=children[0];(f/'committed-cache-switch-interruption.json').write_text(json.dumps(dict(validator_pid=1254821,build_pid=int(child[0]),signal='SIGINT',interrupted_feature=7,reason='Read-only Isabelle probe verified exact private committed-cache match for Proof_Checker and Code.'),indent=2)+'\n')
os.killpg(int(child[0]),signal.SIGINT)
while pathlib.Path('/proc/1254821').exists():time.sleep(2)
cmd=['python3','tools/consolidation/validate_feature_series.py','--manifest',str(f/'series-qdp-closed/manifest.json'),'--source',str(s),'--output',str(f/'series-validation-committed'),'--isabelle','/work/dfm/festschrift/ferrum/.tools/Isabelle2025-2/bin/isabelle','--user-home',str(b/'isabelle-user'),'--identifier','consolidated_committed_20261017','--afp',str(b/'afp-source/thys'),'--start','7']
with (f/'series-validation-committed.out').open('w') as h:result=subprocess.run(cmd,stdout=h,stderr=subprocess.STDOUT)
raise SystemExit(result.returncode)
