import pathlib,json,sys,subprocess,gzip
r=pathlib.Path.cwd();b=r/'target/consolidation-build';sys.path.insert(0,str(r/'tools/consolidation'))
from replay import sha,write
from coverage_delta import read_mix
from coverage import inspect
prefix='promotion-20261018';mix=b/(prefix+'-mix.tsv')
with mix.open('w') as f:subprocess.run([str(b/'bin/export-mix'),str(b/'hpc-mix-promotion-20261018')],stdout=f,check=True)
entries=read_mix(mix);wanted={};names=['check_relative_adp_root','xml2relative_adp_root','is_relative_adp_root_xml']
for module,rows in entries.items():
 for e in rows:
  for name in names:
   if e['label']=='TopLevelBox ["'+name+'"]':wanted.setdefault(name,[]).append(dict(module=module,**e))
assert set(wanted)==set(names),(set(names)-set(wanted))
registry=json.loads((r/'tests/certification/compact/processor-registry.json').read_text());reports={};allhits={}
for suite,manifest in [(prefix+'-new-positives','promotion-20261018'),(prefix+'-filter-positives','frontier-20261018'),(prefix+'-supplemental','frontier-20261017')]:
 observations=[];out=b/suite
 for root in json.loads((r/'tests/certification'/manifest/'manifest.json').read_text())['roots']:
  run=out/root['id'];raw=subprocess.check_output([str(b/'bin/export-tix'),str(run/'coverage.tix')]);(run/'coverage.tsv.gz').write_bytes(gzip.compress(raw,mtime=0));hits={}
  for line in raw.decode().splitlines():
   module,digest,count,ticks=line.split('\t');hit=set(int(x) for x in ticks.split(',') if x);hits[module]=(digest,hit);allhits.setdefault(module,set()).update(hit)
  functions={name:any(e['module'] in hits and hits[e['module']][0]==e['hash'] and e['tick'] in hits[e['module']][1] for e in es) for name,es in wanted.items()}
  analysis=inspect(run/'proof.cpf.xml',root['category'],registry)
  observations.append(dict(id=root['id'],root=root['root'],functions=functions,coverage_sha256=sha(run/'coverage.tsv.gz'),unknown_proof_nodes_in_frozen_registry=analysis['unknown_proof_tags']))
 reports[suite]=observations
branches=[]
for name,es in wanted.items():
 for e in es:
  p=e['position']
  for x in entries[e['module']]:
   q=x['position']
   if x['label'].startswith('BinBox') and (p[0],p[1])<=(q[0],q[1]) and (q[2],q[3])<=(p[2],p[3]):branches.append(dict(function=name,module=e['module'],**x,observed=x['tick'] in allhits[e['module']]))
write(r/'docs/consolidation/promotion-20261018/runtime-coverage.json',dict(scope='Supplemental genuine certificate bytes, incomplete generation provenance. Positive runtime coverage is separate from theorem verification. Unobserved branches remain explicit gaps.',mix_sha256=sha(mix),function_entries=wanted,reports=reports,branches=branches))
