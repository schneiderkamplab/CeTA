import pathlib,json,hashlib,tarfile,gzip,io
r=pathlib.Path.cwd();b=r/'target/consolidation-build';f=b/'frontier-20261018';dest=r/'docs/consolidation/promotion-20261018';sha=lambda data:hashlib.sha256(data).hexdigest()
files=set()
for prefix in ['promotion-20261018']:
 files.update((b/'logs').glob(prefix+'*'))
 for directory in b.glob(prefix+'-*'):
  if not directory.is_dir() or directory.name.endswith('-haskell'):continue
  for p in directory.rglob('*'):
   if p.is_file() and p.suffix in ['.json','.stdout','.stderr','.gz']:files.add(p)
for directory in ['promotion-baseline']:
 for p in (f/directory).rglob('*'):
  if p.is_file() and p.suffix in ['.json','.stdout','.stderr']:files.add(p)
files.update(p for p in f.iterdir() if p.is_file() and p.suffix in ['.py','.json','.out'])
# Full candidates stay separately frozen; selected compressed proofs are tracked fixtures.
files={p for p in files if p.is_file() and not p.name.endswith('proof.cpf.xml.gz') and not ('series' in p.name and p.suffix=='.out')}
manifest=[];archive=dest/'verification-evidence.tar.gz'
with archive.open('wb') as raw,gzip.GzipFile(fileobj=raw,mode='wb',mtime=0) as compressed,tarfile.open(fileobj=compressed,mode='w') as tar:
 for p in sorted(files):
  data=p.read_bytes();name=str(p.relative_to(b));info=tarfile.TarInfo(name);info.size=len(data);info.mode=0o644;info.mtime=0;tar.addfile(info,io.BytesIO(data));manifest.append(dict(path=name,bytes=len(data),sha256=sha(data)))
blob=json.dumps(dict(archive_sha256=sha(archive.read_bytes()),files=manifest),sort_keys=True).encode();(dest/'evidence-manifest.json.gz').write_bytes(gzip.compress(blob,mtime=0))
with tarfile.open(archive) as tar:
 for row in manifest:assert sha(tar.extractfile(row['path']).read())==row['sha256']
(dest/'evidence-validation.json').write_text(json.dumps(dict(files=len(manifest),archive_sha256=sha(archive.read_bytes()),passed=True,scope='Hash verification of archived logs, results, scripts and source identities; certificates selected for durable regression live in tests/certification/promotion-20261018.'),indent=2)+'\n')
print('Frozen and verified',len(manifest),'evidence files')
