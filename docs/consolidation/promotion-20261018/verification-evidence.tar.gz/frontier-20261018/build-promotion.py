import pathlib,subprocess,os,shutil,time,json,hashlib,sys
r=pathlib.Path.cwd();b=r/'target/consolidation-build';f=b/'frontier-20261018';s=b/'checker-source'
finished=f/'series-validation-recovered/0025/result.json'
while not finished.exists():
 for folder in ['series-validation-retirement','series-validation-sharing','series-validation-recovered']:
  for p in (f/folder).glob('*/result.json'):
   if not json.loads(p.read_text())['passed']:raise SystemExit('Feature validation failed: '+str(p))
 time.sleep(10)
assert json.loads(finished.read_text())['passed']
expected=json.loads((f/'filter-built-source.json').read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
ceta='thys/Relative_ADP/Integration/Relative_ADP_Ceta.thy';promotion='thys/Relative_ADP/Integration/Relative_ADP_Promotion.thy'
assert all(sha(s/p)==h for p,h in expected.items() if p!=ceta),'Unrelated private source mismatch'
for p in [ceta,promotion]:shutil.copy2(r/p,s/p)
expected.update({p:sha(s/p) for p in [ceta,promotion]});(f/'promotion-built-source.json').write_text(json.dumps(expected,indent=2)+'\n')
env=dict(os.environ,USER_HOME=str(b/'isabelle-user'),ISABELLE_IDENTIFIER='consolidated_sharing_20261017',AFP=str(b/'afp-source/thys'))
isa='/work/dfm/festschrift/ferrum/.tools/Isabelle2025-2/bin/isabelle';ghc='/work/dfm/festschrift/ferrum/.tools/.ghcup/bin/ghc';attempt=sys.argv[1] if len(sys.argv)>1 else 'v1'
dirs=sum((['-d',str(s/d)] for d in ['thys','thys/Relative_ADP','thys/RFC_Absolute_Ext']),[])
def run(name,cmd,cwd=r):subprocess.run(['python3',str(r/'tools/consolidation/run_logged.py'),'--log',str(b/'logs'/name),'--',*cmd],cwd=cwd,env=env,check=True)
run('promotion-20261018-'+attempt+'-build.log',[isa,'build','-v','-j','2','-o','threads=8','-o','parallel_proofs=0',*dirs,'Proof_Checker','Code','RFC_Absolute_Ext','Relative_ADP_Checker_Dev','Relative_ADP_Ceta_Dev','Outermost_RZ_Ext'])
assert all(sha(s/p)==h for p,h in expected.items())
dest=b/'promotion-20261018-haskell';run('promotion-20261018-'+attempt+'-export.log',[isa,'export','-n',*dirs,'-O',str(dest),'-p','3','-x','Relative_ADP_Ceta_Dev.Relative_ADP_Code_Haskell:code/export1/**','Relative_ADP_Ceta_Dev'])
for p in dest.glob('*.hs'):
 shutil.copy2(p,r/'generated/Haskell'/p.name);shutil.copy2(p,s/'generated/Haskell'/p.name)
shutil.copy2(r/'src/Haskell/Main_Relative_ADP.hs',dest/'Main.hs');(b/'bin-promotion-20261018').mkdir(exist_ok=True)
for flavor in ['relative','relative-hpc']:
 args=[ghc,'-O2','-package','array','-XRankNTypes','-odir',str(b/('ghc-promotion-20261018-'+flavor)),'-hidir',str(b/('ghc-promotion-20261018-'+flavor))]
 if flavor.endswith('hpc'):args+=['-fhpc','-hpcdir',str(b/'hpc-mix-promotion-20261018')]
 run('promotion-20261018-'+flavor+'.log',args+['--make','Main.hs','-o',str(b/'bin-promotion-20261018'/('ceta-'+flavor))],dest)
print('Promotion build, export and both compilers passed',flush=True)
