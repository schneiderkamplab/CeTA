import pathlib,json,sys,os,re,time,concurrent.futures
r=pathlib.Path.cwd();b=r/'target/consolidation-build';sys.path.insert(0,str(r/'tools/consolidation'));from replay import execute,sha,write,certified
prefix='promotion-20261018';receipt=b/'logs'/(prefix+'-relative-hpc.receipt.json')
while not receipt.exists():time.sleep(5)
assert json.loads(receipt.read_text())['returncode']==0
source=b/(prefix+'-compact');prior=json.loads((source/'summary.json').read_text());assert prior['acceptance_passed'];checker=b/('bin-'+prefix)/'ceta-relative-hpc';out=b/(prefix+'-compact-hpc-agreement');out.mkdir()
manifest=r/'tests/certification/compact/manifest.json';m=json.loads(manifest.read_text());rows=[(kind,x) for kind in ['positives','negatives'] for x in m[kind]]
def one(pair):
 kind,row=pair;run=out/row['id'];run.mkdir();proof=source/row['id']/'proof.cpf.xml';assert sha(proof)==row['cpf_sha256' if kind=='positives' else 'mutation_sha256'];timeout=max(120,1.5*row['reference_hpc']['elapsed_seconds']+30) if kind=='positives' else 120
 p=run/'check';c=execute([str(checker),str(proof)],run,dict(os.environ,HPCTIXFILE=str(run/'coverage.tix')),p,timeout)
 if kind=='positives':ok=certified(c,p)
 else:
  text=p.with_suffix('.stdout').read_text()+p.with_suffix('.stderr').read_text();ok=c['returncode']==1 and not c['timed_out'] and text.startswith('REJECTED') and bool(re.search(row['expected_diagnostic_regex'],text,re.S|re.I))
 result=dict(id=row['id'],kind=kind,passed=ok,check=c);write(run/'result.json',result);return result
with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:results=list(pool.map(one,rows))
write(out/'summary.json',dict(scope='Integrated production/HPC acceptance agreement. Counter mapping to the frozen default-export denominator is a separate obligation.',source_summary_sha256=sha(source/'summary.json'),manifest_sha256=sha(manifest),checker_sha256=sha(checker),results=results,passed=all(x['passed'] for x in results)));assert all(x['passed'] for x in results);print('Compact integrated HPC agreement passed',flush=True)
