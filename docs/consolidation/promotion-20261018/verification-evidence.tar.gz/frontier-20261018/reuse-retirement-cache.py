import pathlib,subprocess,json,os,time,signal
r=pathlib.Path.cwd();b=r/'target/consolidation-build';f=b/'frontier-20261018';v=f/'series-validation-uncovered';s=b/'checker-source';isa='/work/dfm/festschrift/ferrum/.tools/Isabelle2025-2/bin/isabelle'
while not (v/'0013/source-hashes.json').exists():
 for n in [10,11,12]:
  p=v/f'{n:04d}/result.json'
  if p.exists() and not json.loads(p.read_text())['passed']:raise SystemExit('Earlier feature failed')
 time.sleep(10)
assert json.loads((v/'0012/result.json').read_text())['passed']
env=dict(os.environ,USER_HOME=str(b/'isabelle-user'),ISABELLE_IDENTIFIER='consolidated_retirement_20261017',AFP=str(b/'afp-source/thys'))
cmd=[isa,'build','-n','-b','-v','-j','2','-o','threads=8','-o','parallel_proofs=0']+sum((['-d',str(s/p)] for p in ['thys','thys/Relative_ADP','thys/RFC_Absolute_Ext']),[])+['CSR_Checker_Extensions']
with (f/'retirement-cache-probe.out').open('w') as h:probe=subprocess.run(cmd,env=env,stdout=h,stderr=subprocess.STDOUT)
if probe.returncode or (v/'0013/result.json').exists():raise SystemExit('No cache switch needed or compatible cache unavailable; existing validator continues')
rows=[x.strip().split(None,3) for x in subprocess.check_output(['ps','-eo','pid,ppid,pgid,args'],text=True).splitlines()[1:]]
p=[x for x in rows if x[3].startswith('python3 tools/consolidation/validate_feature_series.py ') and '--output target/consolidation-build/frontier-20261018/series-validation-uncovered ' in x[3]];assert len(p)==1,p
c=[x for x in rows if x[1]==p[0][0] and x[0]==x[2]];assert len(c)==1,c
(f/'retirement-cache-switch-interruption.json').write_text(json.dumps(dict(validator_pid=int(p[0][0]),build_pid=int(c[0][0]),signal='SIGINT',interrupted_feature=13,reason='Exact private retirement cache confirmed by read-only Isabelle probe.'),indent=2)+'\n');os.killpg(int(c[0][0]),signal.SIGINT)
while pathlib.Path('/proc/'+p[0][0]).exists():time.sleep(1)
q=f/'finalize-series.py';t=q.read_text().replace("'series-validation-uncovered'];", "'series-validation-uncovered','series-validation-retirement','series-validation-sharing'];").replace("f/'rz-cache-probe.out']", "f/'rz-cache-probe.out',f/'retirement-cache-switch-interruption.json',f/'retirement-cache-probe.out',f/'reuse-retirement-cache.py']").replace("ISABELLE_IDENTIFIER='consolidated_uncovered_v2_20261017'", "ISABELLE_IDENTIFIER='consolidated_sharing_20261017'").replace("m['controlled_relocation_interruption']=", "m['controlled_retirement_interruption']=dict(receipt='series-validation-uncovered/0013/result.json',reason='Reused exact private retirement dependency cache after read-only verification.');m['controlled_relocation_interruption']=");q.write_text(t)
for name,identifier,start,stop in [('retirement','consolidated_retirement_20261017',13,15),('sharing','consolidated_sharing_20261017',16,None)]:
 cmd=['python3','tools/consolidation/validate_feature_series.py','--manifest',str(f/'series-final-cache-policy/manifest.json'),'--source',str(s),'--output',str(f/('series-validation-'+name)),'--isabelle',isa,'--user-home',str(b/'isabelle-user'),'--identifier',identifier,'--afp',str(b/'afp-source/thys'),'--start',str(start)]
 if stop:cmd+=['--stop',str(stop)]
 with (f/('series-validation-'+name+'.out')).open('w') as h:result=subprocess.run(cmd,stdout=h,stderr=subprocess.STDOUT)
 if result.returncode:raise SystemExit(result.returncode)
