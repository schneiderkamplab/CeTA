import pathlib,json,hashlib,collections
r=pathlib.Path.cwd();b=r/'target/consolidation-build';f=b/'frontier-20261018';prefix='promotion-20261018'
key=lambda x:(x['root'],x.get('proof_sha256',x.get('cpf_sha256')),x['input_sha256'],x.get('answer',x.get('audit',{}).get('answer','yes')).lower())
identity=json.loads((f/'campaign-full-identity.json').read_text());expected={key(x) for x in identity['roots']+identity['covered']};assert len(expected)==4176
promotion=json.loads((r/'tests/certification/promotion-20261018/manifest.json').read_text())['roots'];expected.update(key(x) for x in promotion);assert len(expected)==4177
accepted=set();receipts={}
for suffix in ['campaign','full','supplemental','new-positives']:
 out=b/(prefix+'-'+suffix);summary=json.loads((out/'summary.json').read_text());assert summary.get('passed');receipts[suffix]=hashlib.sha256((out/'summary.json').read_bytes()).hexdigest()
 if suffix=='campaign':accepted.update(key(x) for x in summary['results'] if x['passed'])
 elif suffix=='full':
  for p in out.glob('*/result.json'):
   row=json.loads(p.read_text());assert row['passed'];accepted.add(key(row))
 else:
  ids={x['id'] for x in summary['results'] if x['passed']}
  for x in (promotion if suffix=='new-positives' else json.loads((r/'tests/certification/frontier-20261017/manifest.json').read_text())['roots']):
   assert x['id'] in ids;accepted.add(key(x))
missing=sorted(expected-accepted)
report=dict(expected_exact_identities=len(expected),accepted_current_exact_identities=len(expected&accepted),missing=missing,passed=not missing,identity_fields=['root','proof_sha256','input_sha256','answer'],categories=dict(collections.Counter(k[0].split('/')[0] for k in expected)),receipt_sha256=receipts,scope='Exact frozen available current-frontier identities. Latest SRS225 lacked details; selected SRS206 is the last available inventory. Certificate recheck, not fresh Ferrum generation.')
(r/'docs/consolidation/promotion-20261018/campaign-comparison.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report));assert not missing
