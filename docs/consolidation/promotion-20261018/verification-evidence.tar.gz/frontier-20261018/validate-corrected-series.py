import pathlib,json,time,subprocess
r=pathlib.Path.cwd();b=r/'target/consolidation-build';f=b/'frontier-20261018';p=f/'series-corrected/manifest.json'
while not p.exists():time.sleep(5)
m=json.loads(p.read_text());assert len(m['series'])==26
subprocess.run(['python3','tools/consolidation/validate_feature_series.py','--manifest',str(p),'--source',str(b/'checker-source'),'--output',str(f/'series-validation-corrected'),'--isabelle','/work/dfm/festschrift/ferrum/.tools/Isabelle2025-2/bin/isabelle','--user-home',str(b/'isabelle-user'),'--identifier','consolidated_frontier_20261017','--afp',str(b/'afp-source/thys')],check=True)
