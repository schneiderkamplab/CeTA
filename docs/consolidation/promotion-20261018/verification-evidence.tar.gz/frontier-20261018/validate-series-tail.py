import pathlib,json,time,subprocess
r=pathlib.Path.cwd();b=r/'target/consolidation-build';f=b/'frontier-20261018';manifest=r/'docs/consolidation/feature-series/manifest.json'
while not manifest.exists():time.sleep(5)
a=json.loads((f/'series-root-check-v2/manifest.json').read_text());z=json.loads(manifest.read_text());assert [x['commit'] for x in a['series'][:23]]==[x['commit'] for x in z['series'][:23]]
p=f/'series-validation-prefix-v2/0023/result.json'
while not p.exists():time.sleep(5)
assert json.loads(p.read_text())['passed']
subprocess.run(['python3','tools/consolidation/validate_feature_series.py','--manifest',str(manifest),'--source',str(b/'checker-source'),'--output',str(f/'series-validation-tail'),'--isabelle','/work/dfm/festschrift/ferrum/.tools/Isabelle2025-2/bin/isabelle','--user-home',str(b/'isabelle-user'),'--identifier','consolidated_frontier_20261017','--afp',str(b/'afp-source/thys'),'--start','24'],check=True)
