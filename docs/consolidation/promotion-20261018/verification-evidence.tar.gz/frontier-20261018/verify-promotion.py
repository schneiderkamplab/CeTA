import pathlib,json,time,subprocess
r=pathlib.Path.cwd();b=r/'target/consolidation-build';f=b/'frontier-20261018';prefix='promotion-20261018'
receipt=b/'logs'/(prefix+'-relative-hpc.receipt.json')
while not receipt.exists():
 failure=b/'logs'/(prefix+'-v2-build.receipt.json')
 if failure.exists() and json.loads(failure.read_text())['returncode']:raise SystemExit('Promotion formal build failed')
 time.sleep(10)
assert json.loads(receipt.read_text())['returncode']==0
checker=b/('bin-'+prefix)/'ceta-relative';hpc=b/('bin-'+prefix)/'ceta-relative-hpc'
def run(suffix,args):
 subprocess.run(['python3','tools/consolidation/run_logged.py','--log',str(b/'logs'/(prefix+'-'+suffix+'.log')),'--',*args],check=True)
common=['--checker',str(checker),'--hpc-checker',str(hpc)]
run('new-positives',['python3','tools/consolidation/frontier_suite.py','--manifest','tests/certification/promotion-20261018/manifest.json',*common,'--output',str(b/(prefix+'-new-positives'))])
run('new-negatives',['python3','tools/consolidation/adp_promotion_negatives.py','--manifest','tests/certification/promotion-20261018/manifest.json',*common,'--output',str(b/(prefix+'-new-negatives'))])
run('compact',['python3','tools/consolidation/suite.py','--manifest','tests/certification/compact/manifest.json','--checker',str(checker),'--output',str(b/(prefix+'-compact'))])
run('performance',['python3','tools/consolidation/performance.py','--manifest','tests/certification/compact/manifest.json','--suite-result',str(b/(prefix+'-compact/summary.json')),'--reference',str(r/'target/consolidation-snapshot/artifacts/production_checker'),'--candidate',str(checker),'--output',str(b/(prefix+'-performance')),'--repeats','9'])
run('compact-hpc-agreement',['python3',str(f/'promotion-compact-hpc-agreement.py')])
run('supplemental',['python3','tools/consolidation/frontier_suite.py','--manifest','tests/certification/frontier-20261017/manifest.json',*common,'--output',str(b/(prefix+'-supplemental'))])
run('filter-positives',['python3','tools/consolidation/campaign_recheck.py','--manifest','tests/certification/frontier-20261018/manifest.json',*common,'--output',str(b/(prefix+'-filter-positives'))])
run('filter-negatives',['python3','tools/consolidation/adp_frontier_negatives.py','--manifest','tests/certification/frontier-20261018/manifest.json',*common,'--output',str(b/(prefix+'-filter-negatives'))])
run('campaign',['python3','tools/consolidation/campaign_recheck.py','--manifest',str(f/'campaign/manifest.json'),'--checker',str(checker),'--output',str(b/(prefix+'-campaign')),'--jobs','4'])
run('full',['python3','tools/consolidation/recheck_entry.py','--manifest','tests/certification/replay-assets/full-replay.json','--source',str(b/'final-full-replay'),'--checker',str(checker),'--output',str(b/(prefix+'-full')),'--jobs','4'])
print('Promotion focused and full certificate verification passed',flush=True)
