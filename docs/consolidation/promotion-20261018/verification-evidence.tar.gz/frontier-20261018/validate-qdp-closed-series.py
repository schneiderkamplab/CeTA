import pathlib,json,time,subprocess
r=pathlib.Path.cwd();b=r/'target/consolidation-build';f=b/'frontier-20261018';p=f/'series-qdp-closed/manifest.json'
while not p.exists():time.sleep(5)
m=json.loads(p.read_text());assert len(m['series'])==25
old=json.loads((f/'series-root-check/manifest.json').read_text());assert m['series'][0]['commit']==old['series'][0]['commit'];assert json.loads((f/'series-validation-prefix/0001/result.json').read_text())['passed']
subprocess.run(['python3','tools/consolidation/validate_feature_series.py','--manifest',str(p),'--source',str(b/'checker-source'),'--output',str(f/'series-validation-qdp-closed'),'--isabelle','/work/dfm/festschrift/ferrum/.tools/Isabelle2025-2/bin/isabelle','--user-home',str(b/'isabelle-user'),'--identifier','consolidated_frontier_20261017','--afp',str(b/'afp-source/thys'),'--start','2'],check=True)
