import pathlib,json,hashlib,subprocess
r=pathlib.Path.cwd();b=r/'target/consolidation-build';f=b/'frontier-20261018';d=r/'docs/consolidation/promotion-20261018'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
receipts={}
for suffix in ['v2-build','v2-export','relative','relative-hpc','new-positives','new-negatives','compact','performance','compact-hpc-agreement','supplemental','filter-positives','filter-negatives','campaign','full']:
 p=b/'logs'/('promotion-20261018-'+suffix+'.receipt.json');v=json.loads(p.read_text());assert v['returncode']==0,(suffix,v);receipts[suffix]=dict(sha256=sha(p),receipt=v)
expected=json.loads((f/'promotion-built-source.json').read_text());assert all(sha(r/p)==h for p,h in expected.items())
module=r/'generated/Haskell/Ceta_Relative.hs';assert module.read_bytes()==(b/'promotion-20261018-haskell/Ceta_Relative.hs').read_bytes()
coverage=json.loads((r/'docs/consolidation/frontier-20261018/coverage-preservation.json').read_text())
modules=coverage['unchanged_generated_modules'] if 'unchanged_generated_modules' in coverage else None
unchanged=[]
for path in subprocess.check_output(['git','ls-tree','-r','--name-only','8259236','--','generated/Haskell'],text=True).splitlines():
 if path.endswith('Ceta_Relative.hs'):continue
 assert (r/path).read_bytes()==subprocess.check_output(['git','show','8259236:'+path]),path
 unchanged.append(dict(path=path,sha256=sha(r/path)))
assert len(unchanged)==401
agreement=b/'promotion-20261018-compact-hpc-agreement/summary.json';assert json.loads(agreement.read_text())['passed']
(d/'coverage-preservation.json').write_text(json.dumps(dict(ordinary_modules=len(unchanged),unchanged_modules=unchanged,frozen_required_obligations=45753,previous_retirements=20,new_retirements=0,integrated_compact_agreement_sha256=sha(agreement)),indent=2)+'\n')
comparison=json.loads((d/'campaign-comparison.json').read_text());assert comparison['passed'] and comparison['accepted_current_exact_identities']==4177
(d/'verification.json').write_text(json.dumps(dict(passed=True,source_sha256=expected,generated_module_sha256=sha(module),checker_sha256=sha(b/'bin-promotion-20261018/ceta-relative'),hpc_checker_sha256=sha(b/'bin-promotion-20261018/ceta-relative-hpc'),receipts=receipts,exact_certified_identities=4177,scope='Frozen certificate rechecks; not fresh Ferrum regeneration.'),indent=2)+'\n')
p=d/'criterion-coverage.json';v=json.loads(p.read_text());v['status']='Formal production targets, export, production/HPC compilation, focused and full frozen-certificate checks passed.';v['positive_scope']=v['positive_scope'].replace('Certification pending.','Certified twice with production/HPC agreement.');p.write_text(json.dumps(v,indent=2)+'\n')
print('Promotion verification and unchanged ordinary coverage verified')
