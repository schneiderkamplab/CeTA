theory Raw_Promotion_Code
  imports Raw_Campaign_Cert
begin

ML \<open>
  val checked = @{thms certify_cert_problem_raw_sound certify_relative_adp_cert_problem_sound
    check_relative_adp_root_sound promotion_rejects_missing_strict_rules promotion_rejects_foreign_rules};
  val _ = if Options.default_bool "quick_and_dirty" orelse Thm_Deps.has_skip_proof checked
    then error "Unverified promotion checker" else ();
  val _ = writeln "PROMOTION_CHECKER_SOUND_NO_SKIPS";
  val (modules, _) = Code_Target.produce_code @{context} false
    [@{const_name certify_proof_raw_integrated}, @{const_name certify_proof_raw}, @{const_name Certified},
     @{const_name Unsupported}, @{const_name Error}, @{const_name literal.explode}]
    "Haskell" "Ceta_Raw_Integrated" NONE [];
  val root = Path.explode "/work/dfm/festschrift/CeTA-raw-superiority/target/promotion-v267/haskell";
  fun ensure_dir path =
    if OS.FileSys.isDir (Path.implode path) handle OS.SysErr _ => false
    then () else OS.FileSys.mkDir (Path.implode path);
  fun write_module (names, bytes) =
    let
      val segments = map Path.basic names;
      val _ = fold (fn segment => fn parent =>
        let val path = Path.append parent segment
        in ensure_dir path; path end) (fst (split_last segments)) root;
    in Bytes.write (Path.appends (root :: segments)) bytes end;
  val _ = List.app write_module modules;
  val _ = writeln "PROMOTION_HASKELL_EXPORTED";
\<close>

end
