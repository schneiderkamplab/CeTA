import pathlib,time,json,subprocess
r=pathlib.Path.cwd();b=r/'target/consolidation-build';p=b/'logs/frontier-make.receipt.json'
while not p.exists():time.sleep(5)
assert json.loads(p.read_text())['returncode']==0
raise SystemExit(subprocess.run(['python3','tools/consolidation/run_logged.py','--log',str(b/'logs/frontier-compact-integrated.log'),'--','python3','tools/consolidation/suite.py','--manifest','tests/certification/compact/manifest.json','--checker',str(b/'bin-frontier/ceta-relative-adp'),'--output',str(b/'compact-frontier-integrated')]).returncode)
