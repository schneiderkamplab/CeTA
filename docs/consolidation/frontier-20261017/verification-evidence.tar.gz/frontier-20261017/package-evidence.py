import pathlib,json,gzip,tarfile,hashlib,subprocess,collections
r=pathlib.Path.cwd();b=r/'target/consolidation-build';d=r/'docs/consolidation/frontier-20261017'
def read(p):return json.loads(p.read_text())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
comparison=read(b/'frontier-corpus-comparison/summary.json');assert comparison['passed'] and comparison['roots']==3484
compact=read(b/'compact-frontier-v2/summary.json');integrated=read(b/'compact-frontier-integrated/summary.json');supp=read(b/'frontier-supplemental/summary.json');derived=read(b/'frontier-derived/summary.json');same=read(b/'frontier-performance-relative-reference/summary.json');repeat=read(b/'frontier-performance-relative-repeat/summary.json');cross=read(b/'frontier-performance-integrated/summary.json');hpc=read(b/'frontier-performance-hpc/summary.json')
assert compact['acceptance_passed'] and compact['coverage_passed'] and integrated['acceptance_passed'] and supp['passed'] and derived['passed']
assert same['candidate_acceptance_passed'] and repeat['candidate_acceptance_passed'] and not repeat['confirmed_slowdowns'] and not hpc['confirmed_slowdowns']
source=read(b/'frontier-source-match.json');assert all(sha(r/p)==v for p,v in source['files'].items())
required=['frontier-focused','frontier-integration-v4','frontier-export-rfc','frontier-export-relative','frontier-make','frontier-hpc','frontier-relative-hpc','frontier-compact-v2','frontier-compact-integrated','frontier-supplemental','frontier-derived','frontier-corpus-retry','frontier-corpus-comparison']
receipts={n:read(b/'logs'/(n+'.receipt.json')) for n in required};assert all(v['returncode']==0 for v in receipts.values())
paths=set()
for p in (b/'logs').glob('frontier*'):
 if p.is_file():paths.add(p)
for p in b.glob('frontier*.json'):paths.add(p)
paths.update(p for p in (b/'frontier-20261017').glob('*') if p.suffix in ['.py','.txt'])
folders=['frontier-corpus','frontier-corpus-comparison','frontier-supplemental','frontier-supplemental-production','frontier-derived','frontier-derived-production','frontier-old-acceptance','compact-frontier-v2','compact-frontier-integrated','frontier-performance-integrated','frontier-performance-integrated-pending','frontier-performance-relative-reference','frontier-performance-relative-repeat','frontier-performance-hpc','frontier-timeout-investigation','frontier-resume-test']
for folder in folders:
 for p in (b/folder).rglob('*'):
  if p.is_symlink() or not p.is_file():continue
  if p.suffix in ['.json','.stdout','.stderr','.log'] or p.name=='coverage.tsv.gz':paths.add(p)
for p in [b/'hpc-mix-frontier.tsv',b/'hpc-modules-frontier.tsv']:paths.add(p)
archive=d/'verification-evidence.tar.gz'
with archive.open('wb') as raw,gzip.GzipFile(filename='',mode='wb',fileobj=raw,mtime=0) as gz,tarfile.open(fileobj=gz,mode='w') as t:
 for p in sorted(paths):
  info=t.gettarinfo(str(p),arcname=str(p.relative_to(b)));info.uid=info.gid=0;info.uname=info.gname='';info.mtime=0
  with p.open('rb') as f:t.addfile(info,f)
manifest={str(p.relative_to(b)):sha(p) for p in sorted(paths)}
with gzip.GzipFile(filename=str(d/'evidence-manifest.json.gz'),mode='wb',mtime=0) as f:f.write((json.dumps(manifest,sort_keys=True,indent=2)+'\n').encode())
failed=list((b/'frontier-corpus/failed-attempts').glob('*/result.json'))
report=dict(base_commit=source['base_commit'],scope='Frozen 2026-10-17 frontier integration; certificate recheck, not fresh Ferrum regeneration or exhaustive moving-frontier certification.',all_targets_passed=True,production_source_files_verified=len(source['files']),binaries={p.name:sha(p) for p in (b/'bin-frontier').glob('ceta*') if p.is_file()},build_receipts={n:dict(returncode=v['returncode'],elapsed_seconds=v['elapsed_seconds'],max_child_rss_kib=v['max_child_rss_kib']) for n,v in receipts.items()},compact=dict(positives=208,semantic_negatives=408,default_and_integrated_acceptance=True,production_hpc_agreement=True,observed_required=compact['observed_required_coverage'],frozen_required=compact['frozen_required_coverage'],previous_retirements=len(compact['retired_coverage']),new_retirements=0),frontier=dict(real_supplemental_proofs=len(supp['results']),semantic_mutations=sum(len(x['mutations']) for x in supp['results']),derived_fixtures=len(derived['results']),production_hpc_agreement=True,genuine_replay_additions=0),corpus=dict(roots=comparison['roots'],exact_root_set_preserved=True,twice_default_production=True,hpc_agreement=True,additional_integrated_check=True,missing_coverage=comparison['missing_coverage'],unknown_node_roots=comparison['unknown_node_roots'],verification_kind=comparison['verification_kind']),performance=dict(default_production_slowdowns=0,default_hpc_slowdowns_after_repeats=0,integrated_vs_default_confirmed=len(cross['confirmed_slowdowns']),same_entry_cases=len(same['results']),same_entry_initial_outliers=same['confirmed_slowdowns'],same_entry_repeat_outliers=repeat['confirmed_slowdowns'],interpretation='Integrated/default overhead is visible but inherited; same-entry outliers cleared under eleven alternating repeats.'),interruption=dict(workspace_mount_outage=True,initial_completed_roots=298,failed_attempts_preserved=len(failed),sequential_timeout_investigation=read(b/'frontier-timeout-investigation/results.json'),retry_policy='Failed and interrupted attempts retained separately. Final checks keep original per-root deadlines and restore the original 16-worker concurrency. No timeout is counted as a pass.'),coverage_limits=['Supplemental generation source/build provenance is incomplete; proofs are excluded from genuine oracle-only suite.','Full-to-outermost and absolute-RFC Split paths have derived fixtures but no genuine replay coverage.','Runtime observations do not execute Isabelle proofs.','Incomplete outermost CDP criterion and broader forbidden-pattern bridge were not imported.'],evidence=archive.name,evidence_sha256=sha(archive),evidence_manifest='evidence-manifest.json.gz',evidence_manifest_sha256=sha(d/'evidence-manifest.json.gz'),passed=True)
(d/'verification.json').write_text(json.dumps(report,indent=2,sort_keys=True)+'\n')
print(json.dumps(dict(evidence_files=len(paths),evidence_bytes=archive.stat().st_size,passed=True)))
