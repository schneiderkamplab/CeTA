import pathlib,json,gzip,concurrent.futures,sys,os
r=pathlib.Path.cwd();b=r/'target/consolidation-build';sys.path.insert(0,str(r/'tools/consolidation'));from replay import execute,certified,write,sha
base=r/'tests/certification/frontier-20261017';out=b/'frontier-old-acceptance';out.mkdir(exist_ok=False)
def one(row):
 d=out/row['id'];d.mkdir();p=d/'proof.xml';p.write_bytes(gzip.decompress((base/row['id']/'proof.cpf.xml.gz').read_bytes()))
 binary=b/'bin-sharing'/('ceta-relative-adp' if row['category']=='TRS_Relative' else 'ceta')
 c=execute([str(binary),str(p)],d,dict(os.environ),d/'check',600);c['certified']=certified(c,d/'check');c['checker_sha256']=sha(binary)
 return dict(id=row['id'],root=row['root'],category=row['category'],check=c)
with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:rows=list(pool.map(one,json.loads((base/'manifest.json').read_text())['roots']))
write(out/'summary.json',dict(scope='Comparison with last verified binaries, not a provenance or soundness claim.',results=rows));print({cat:sum(x['check']['certified'] for x in rows if x['category']==cat) for cat in {x['category'] for x in rows}},flush=True)
