import pathlib,subprocess,os
r=pathlib.Path.cwd();b=r/'target/consolidation-build'
old=b/'isabelle-user/.isabelle/consolidated_sharing_20261017';new=old.with_name('consolidated_frontier_20261017')
if not new.exists():subprocess.run(['cp','-a','--reflink=auto',str(old),str(new)],check=True)
files=subprocess.check_output(['git','diff','--name-only'],text=True).splitlines()+subprocess.check_output(['git','ls-files','--others','--exclude-standard','thys'],text=True).splitlines()
for p in files:
 if p.startswith('thys/'):(b/'checker-source'/p).write_bytes((r/p).read_bytes())
env=dict(os.environ,USER_HOME=str(b/'isabelle-user'),ISABELLE_IDENTIFIER=new.name,AFP=str(b/'afp-source/thys'))
dirs=sum((['-d',str(b/'checker-source'/d)] for d in ['thys','thys/Relative_ADP','thys/RFC_Absolute_Ext']),[])
cmd=['/work/dfm/festschrift/ferrum/.tools/Isabelle2025-2/bin/isabelle','build','-b','-v','-j','2','-o','threads=8','-o','parallel_proofs=0',*dirs,'Relative_ADP_Checker_Dev','RFC_Absolute_Ext']
raise SystemExit(subprocess.run(['python3','tools/consolidation/run_logged.py','--log',str(b/'logs/frontier-focused.log'),'--',*cmd],env=env).returncode)
