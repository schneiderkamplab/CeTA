import pathlib,json,time,subprocess,hashlib,shutil,collections,re
r=pathlib.Path.cwd();b=r/'target/consolidation-build';d=r/'docs/consolidation/frontier-20261017'
def wait_json(p,key='passed'):
 while not p.exists():time.sleep(5)
 s=json.loads(p.read_text());assert s[key],str(p);return s
wait_json(b/'frontier-corpus-comparison-v2/summary.json')
for name in ['frontier-corpus-integrated-v3','frontier-supplemental-v3','frontier-derived-integrated-v3']:wait_json(b/name/'summary.json')
wait_json(b/'compact-frontier-integrated-v3/summary.json','acceptance_passed');perf=wait_json(b/'frontier-performance-relative-v3-repeat/summary.json','candidate_acceptance_passed');assert not perf['confirmed_slowdowns'],perf['confirmed_slowdowns']
while not (b/'frontier-runtime-coverage-v3.json').exists():time.sleep(5)
coverage=json.loads((b/'frontier-runtime-coverage-v3.json').read_text());shutil.copy2(b/'frontier-runtime-coverage-v3.json',d/'runtime-coverage.json');p=d/'coverage-inventory.json';inv=json.loads(p.read_text());inv['runtime_function_hits']={k:dict(collections.Counter(f for row in v['observations'] for f,hit in row['functions'].items() if hit)) for k,v in coverage['reports'].items()};assert all(not row['unknown_proof_nodes_in_frozen_registry'] for v in coverage['reports'].values() for row in v['observations']);p.write_text(json.dumps(inv,indent=2)+'\n')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
old=json.loads((b/'frontier-source-match.json').read_text());current={p:sha(r/p) for p in old['files']};assert all(sha(b/'checker-source'/p)==v for p,v in current.items());(b/'frontier-source-match-v3.json').write_text(json.dumps(old|dict(files=current),indent=2)+'\n')
exports={p.name:sha(p) for p in (b/'frontier-relative-v3-haskell').glob('*.hs') if p.name!='Main.hs'};assert all(sha(r/'generated/Haskell'/p)==v for p,v in exports.items());(b/'frontier-export-comparison-v3.json').write_text(json.dumps(dict(relative=exports,passed=True),indent=2)+'\n')
source_diff=subprocess.check_output(['git','diff','--','thys'],text=True);added='\n'.join(l[1:] for l in source_diff.splitlines() if l.startswith('+') and not l.startswith('+++'));added+='\n'+(r/'thys/Relative_ADP/Semantics/Reduction_Pair/Relative_ADP_Com_Order_Check.thy').read_text()+'\n'+(r/'thys/Relative_ADP/Integration/Base/Relative_ADP_Integration_Base.thy').read_text();assert not re.search(r'\b(sorry|oops|axiomatization|skip_proof)\b|quick_and_dirty\s*=\s*true',added);(b/'frontier-admission-scan-v3.json').write_text(json.dumps(dict(passed=True,forbidden_additions=[],added_source_sha256=hashlib.sha256(added.encode()).hexdigest()),indent=2)+'\n')
subprocess.run(['python3','tools/consolidation/timings.py','--log',str(b/'logs/frontier-single-parse-build-v3.log'),'--output',str(d/'single-parse-timings.json')],check=True)
subprocess.run(['python3','target/consolidation-build/frontier-20261017/package-evidence-v3.py'],check=True)
