import pathlib,json,gzip,sys
r=pathlib.Path.cwd();b=r/'target/consolidation-build';sys.path.insert(0,str(r/'tools/consolidation'));from coverage_delta import read_mix;from coverage_transition import Transition;from replay import sha,write
p=json.loads((b/'frontier-transition-proposal.json').read_text());mix=read_mix(b/'hpc-mix-frontier.tsv');delta=json.loads((b/'frontier-coverage-delta.json').read_text());gaps={x['old_obligation']:x for x in delta['unmapped_required_counters']};review=[]
expected={'RFC_Absolute_Cert':'check_cert_rfc_absolute','RFC_Absolute_Check':'check_rfc_absolute'}
assert len(p['gaps'])==2
for old in p.pop('gaps'):
 before=gaps[old['intermediate_obligation']];label='TopLevelBox ["'+expected[old['module']]+'"]';assert before['label']==label
 candidates=[x for x in mix[old['module']] if x['label']==label];assert len(candidates)==1;new=candidates[0]
 reason=('This is a function-entry counter, not a claim that every equation or soundness premise executed. The same function remains the entry point with its old contract; added Split/outermost equations are separately tested by derived fixtures. All other retained counters map through unchanged expressions. No branch counter is retired or replaced by an entry counter.')
 p['mappings'].append(dict(old_obligation=old['old_obligation'],module=old['module'],old_tick=old['old_tick'],new_tick=new['tick'],new_hash=new['hash'],method='Reviewed same-function entry counter after adding equations',reason=reason))
 review.append(dict(old_obligation=old['old_obligation'],module=old['module'],label=label,old_position=before['position'],new_position=new['position'],old_entry_source_sha256=__import__('hashlib').sha256(before['source_excerpt'].encode()).hexdigest(),new_module_source_sha256=sha(b/'frontier-rfc-haskell'/new['source']),reason=reason))
p['scope']='Original frozen denominator retained; unchanged-expression composition plus two reviewed same-function entry counters. Only the 20 previously retired counters remain retired. New functionality is reported separately; no theorem-equivalence claim is made by runtime counter mappings.'
p['mappings'].sort(key=lambda x:x['old_obligation']);p['reviewed_entries']=review;p['new_mix_sha256']=sha(b/'hpc-mix-frontier.tsv');p['prior_transition_sha256']=sha(r/'docs/consolidation/cleanup-coverage-transition.json.gz')
dest=r/'docs/consolidation/frontier-20261017/coverage-transition.json.gz';dest.write_bytes(gzip.compress(json.dumps(p,sort_keys=True).encode(),mtime=0));write(dest.with_name('coverage-review.json'),dict(review=review,automatic_mapping_count=len(p['mappings'])-len(review),retired_count=len(p['retired']),delta_sha256=sha(b/'frontier-coverage-delta.json')))
Transition(dest,r/'tests/certification/compact/coverage-denominator.json',b/'bin-frontier/ceta',b/'bin-frontier/ceta-hpc');print('Reviewed transition valid:',len(p['mappings']),'mapped;',len(p['retired']),'previously retired')
