import pathlib,json,time,subprocess
r=pathlib.Path.cwd();b=r/'target/consolidation-build';p=b/'logs/frontier-dispatch-relative-hpc.receipt.json'
while not p.exists():time.sleep(5)
assert json.loads(p.read_text())['returncode']==0
subprocess.run(['python3','tools/consolidation/run_logged.py','--log',str(b/'logs/frontier-derived-integrated-v2.log'),'--','python3','tools/consolidation/frontier_suite.py','--manifest','tests/certification/frontier-20261017/bridge-fixtures.json','--checker',str(b/'bin-frontier-v2/ceta-relative'),'--hpc-checker',str(b/'bin-frontier-v2/ceta-relative-hpc'),'--output',str(b/'frontier-derived-integrated-v2')],check=True)
subprocess.run(['python3','target/consolidation-build/frontier-20261017/collect-coverage-v2.py'],check=True)
