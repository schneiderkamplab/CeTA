import pathlib,json,gzip,sys,os,re,statistics,time
r=pathlib.Path.cwd();b=r/'target/consolidation-build';sys.path.insert(0,str(r/'tools/consolidation'));from replay import execute,certified,sha,write;from run_logged import memory_used
base=r/'tests/certification/compact';manifest=json.loads((base/'manifest.json').read_text());suite=json.loads((b/'compact-frontier-integrated/summary.json').read_text());out=b/'frontier-performance-relative-reference';out.mkdir(exist_ok=True)
cpus=sorted(os.sched_getaffinity(0));os.sched_setaffinity(0,{cpus[min(1,len(cpus)-1)]})
rows={x['id']:x|dict(kind='positive') for x in manifest['positives']};rows.update({x['id']:x|dict(kind='negative') for x in manifest['negatives']});binaries={'reference':b/'bin-sharing/ceta-relative-adp','candidate':b/'bin-frontier/ceta-relative-adp'};results=[]
for ident in sorted(suite['slowdown_candidates']):
 row=rows[ident];run=out/ident
 if (run/'result.json').exists():
  saved=json.loads((run/'result.json').read_text());assert saved['candidate_acceptance_passed'];results.append(saved);continue
 if run.exists():run.rename(out/(ident+'-interrupted'))
 run.mkdir();proof=run/'proof.cpf.xml';proof.write_bytes(gzip.decompress((base/row['certificate']).read_bytes()));assert sha(proof)==row['cpf_sha256' if row['kind']=='positive' else 'mutation_sha256']
 checks={n:[] for n in binaries}
 for iteration in range(6):
  for name in (['reference','candidate'] if iteration%2==0 else ['candidate','reference']):
   while memory_used()>2*1024**4:time.sleep(5)
   prefix=run/(name+'-'+str(iteration));c=execute([str(binaries[name]),str(proof)],run,{k:v for k,v in os.environ.items() if not k.startswith('HPCTIX')},prefix,600)
   text=prefix.with_suffix('.stdout').read_text()+prefix.with_suffix('.stderr').read_text()
   c['outcome_passed']=certified(c,prefix) if row['kind']=='positive' else c['returncode']==1 and not c['timed_out'] and text.startswith('REJECTED') and bool(re.search(row['expected_diagnostic_regex'],text,re.S|re.I))
   c['warmup']=iteration==0;checks[name].append(c)
  if iteration==0 and not checks['reference'][0]['outcome_passed']:
   break
 comparable=all(c['outcome_passed'] for c in checks['reference'])
 candidate_passed=all(c['outcome_passed'] for c in checks['candidate'])
 medians={n:statistics.median(c['elapsed_seconds'] for c in cs if not c['warmup']) for n,cs in checks.items()} if comparable else None
 ratio=medians['candidate']/medians['reference'] if comparable else None
 result=dict(id=ident,kind=row['kind'],checks=checks,comparable=comparable,candidate_acceptance_passed=candidate_passed,medians=medians,slowdown_ratio=ratio,confirmed_slowdown=bool(comparable and candidate_passed and ratio>1.2));write(run/'result.json',result);results.append(result)
summary=dict(scope='Controlled comparison against the previous integrated entry point. Original default-checker timings only nominate cases; old integrated failures are reported separately and never treated as successful checks.',method='One warmup, five alternating repeats, pinned CPU.',cpu=list(os.sched_getaffinity(0)),reference_sha256=sha(binaries['reference']),candidate_sha256=sha(binaries['candidate']),results=results,candidate_acceptance_passed=all(x['candidate_acceptance_passed'] for x in results),not_comparable=[x['id'] for x in results if not x['comparable']],confirmed_slowdowns=[x['id'] for x in results if x['confirmed_slowdown']]);write(out/'summary.json',summary);print({k:v for k,v in summary.items() if k!='results'},flush=True)
