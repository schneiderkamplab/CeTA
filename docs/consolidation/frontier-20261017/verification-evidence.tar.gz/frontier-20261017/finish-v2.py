import pathlib,json,subprocess,os,time,shutil
r=pathlib.Path.cwd();b=r/'target/consolidation-build';receipt=b/'logs/frontier-focused.receipt.json'
while not receipt.exists():time.sleep(5)
assert json.loads(receipt.read_text())['returncode']==0,'Focused gate failed'
s=b/'checker-source'
for p in ['thys/RFC_Absolute_Ext/RFC_Absolute_Cert.thy','thys/Relative_ADP/Integration/ROOT','thys/Relative_ADP/Integration/Relative_ADP_Ceta.thy','thys/Relative_ADP/Integration/Relative_ADP_Integration_Base.thy']:(s/p).write_bytes((r/p).read_bytes())
env=dict(os.environ,USER_HOME=str(b/'isabelle-user'),ISABELLE_IDENTIFIER='consolidated_frontier_20261017',AFP=str(b/'afp-source/thys'))
isa='/work/dfm/festschrift/ferrum/.tools/Isabelle2025-2/bin/isabelle';ghc='/work/dfm/festschrift/ferrum/.tools/.ghcup/bin/ghc'
dirs=sum((['-d',str(s/d)] for d in ['thys','thys/Relative_ADP','thys/RFC_Absolute_Ext']),[])
def run(name,cmd,cwd=r):
 subprocess.run(['python3',str(r/'tools/consolidation/run_logged.py'),'--log',str(b/'logs'/name),'--',*cmd],cwd=cwd,env=env,check=True)
run('frontier-integration-v2.log',[isa,'build','-v','-j','2','-o','threads=8','-o','parallel_proofs=0',*dirs,'Proof_Checker','Code','RFC_Absolute_Ext','Relative_ADP_Ceta_Dev','Outermost_RZ_Ext'])
for name,session,theory in [('rfc','RFC_Absolute_Ext','RFC_Absolute_Ext.RFC_Absolute_Code'),('relative','Relative_ADP_Ceta_Dev','Relative_ADP_Ceta_Dev.Relative_ADP_Code_Haskell')]:
 dest=b/('frontier-'+name+'-haskell');run('frontier-export-'+name+'.log',[isa,'export','-n',*dirs,'-O',str(dest),'-p','3','-x',theory+':code/export1/**',session])
 for p in dest.glob('*.hs'):shutil.copy2(p,s/'generated/Haskell'/p.name)
run('frontier-make.log',['make','-j2','ceta','ceta-ordinary','ceta-relative-adp','GHC='+ghc,'CETA_BUILD_DIR='+str(b/'ghc-frontier'),'CETA_BIN_DIR='+str(b/'bin-frontier')],s)
dest=b/'frontier-rfc-haskell';shutil.copy2(r/'src/Haskell/Main_RFC.hs',dest/'Main.hs')
run('frontier-hpc.log',[ghc,'-O2','-package','array','-XRankNTypes','-odir',str(b/'ghc-frontier-hpc'),'-hidir',str(b/'ghc-frontier-hpc'),'-fhpc','-hpcdir',str(b/'hpc-mix-frontier'),'--make','Main.hs','-o',str(b/'bin-frontier/ceta-hpc')],dest)
for flag,name in [([], 'hpc-mix-frontier.tsv'),(['--modules'],'hpc-modules-frontier.tsv')]:
 with (b/name).open('w') as out:subprocess.run([str(b/'bin/export-mix'),*flag,str(b/'hpc-mix-frontier')],stdout=out,check=True)
print('Integration, exports, production and HPC builds passed',flush=True)
