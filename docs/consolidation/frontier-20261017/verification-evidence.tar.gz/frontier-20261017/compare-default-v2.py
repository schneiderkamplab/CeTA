import pathlib,json,time,subprocess,hashlib,shutil,collections,re
r=pathlib.Path.cwd();b=r/'target/consolidation-build';d=r/'docs/consolidation/frontier-20261017'
def wait_json(p,key='passed'):
 while not p.exists():time.sleep(5)
 s=json.loads(p.read_text());assert s[key],str(p);return s
wait_json(b/'frontier-corpus-v2/summary.json')
subprocess.run(['python3','tools/consolidation/run_logged.py','--log',str(b/'logs/frontier-corpus-comparison-v2.log'),'--','python3','tools/consolidation/compare_replay.py','--manifest','tests/certification/replay-assets/full-replay.json','--replay',str(b/'frontier-corpus-v2'),'--compact','tests/certification/compact','--baseline-evidence','docs/consolidation/coverage-baseline','--transition','docs/consolidation/frontier-20261017/coverage-transition.json.gz','--checker',str(b/'bin-frontier/ceta'),'--hpc-checker',str(b/'bin-frontier/ceta-hpc'),'--output',str(b/'frontier-corpus-comparison-v2'),'--jobs','8','--certificate-recheck'],check=True)
