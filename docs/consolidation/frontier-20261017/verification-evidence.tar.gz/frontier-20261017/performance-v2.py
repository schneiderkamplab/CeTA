import pathlib,json,time,subprocess
r=pathlib.Path.cwd();b=r/'target/consolidation-build';p=b/'compact-frontier-integrated-v2/summary.json'
while not p.exists():time.sleep(5)
assert json.loads(p.read_text())['acceptance_passed']
s=(b/'frontier-20261017/relative-performance.py').read_text().replace('compact-frontier-integrated/summary.json','compact-frontier-integrated-v2/summary.json').replace("out=b/'frontier-performance-relative-reference'", "out=b/'frontier-performance-relative-v2'").replace("b/'bin-frontier/ceta-relative-adp'", "b/'bin-frontier-v2/ceta-relative'")
p=b/'frontier-20261017/relative-performance-v2.py';p.write_text(s)
def run(label,script):subprocess.run(['python3','tools/consolidation/run_logged.py','--log',str(b/'logs'/(label+'.log')),'--','python3',str(script)],check=True)
run('frontier-performance-relative-v2',p)
summary=json.loads((b/'frontier-performance-relative-v2/summary.json').read_text())
s=s.replace("out=b/'frontier-performance-relative-v2'", "out=b/'frontier-performance-relative-v2-repeat'").replace("for ident in sorted(suite['slowdown_candidates']):", 'for ident in '+repr(summary['confirmed_slowdowns'])+':').replace('range(6)','range(12)').replace('five alternating repeats','eleven alternating repeats');p=b/'frontier-20261017/relative-performance-v2-repeat.py';p.write_text(s);run('frontier-performance-relative-v2-repeat',p)
