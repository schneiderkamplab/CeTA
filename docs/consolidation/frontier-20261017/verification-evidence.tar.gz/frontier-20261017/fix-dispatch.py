import pathlib,subprocess,os,shutil
r=pathlib.Path.cwd();b=r/'target/consolidation-build';s=b/'checker-source';p=pathlib.Path('thys/Relative_ADP/Integration/Relative_ADP_Ceta.thy');shutil.copy2(r/p,s/p)
env=dict(os.environ,USER_HOME=str(b/'isabelle-user'),ISABELLE_IDENTIFIER='consolidated_frontier_20261017',AFP=str(b/'afp-source/thys'))
isa='/work/dfm/festschrift/ferrum/.tools/Isabelle2025-2/bin/isabelle';ghc='/work/dfm/festschrift/ferrum/.tools/.ghcup/bin/ghc'
dirs=sum((['-d',str(s/d)] for d in ['thys','thys/Relative_ADP','thys/RFC_Absolute_Ext']),[])
def run(name,cmd,cwd=r):subprocess.run(['python3',str(r/'tools/consolidation/run_logged.py'),'--log',str(b/'logs'/name),'--',*cmd],cwd=cwd,env=env,check=True)
run('frontier-dispatch-build.log',[isa,'build','-v','-j','2','-o','threads=8','-o','parallel_proofs=0',*dirs,'Proof_Checker','Code','RFC_Absolute_Ext','Relative_ADP_Ceta_Dev','Outermost_RZ_Ext'])
dest=b/'frontier-relative-v2-haskell';run('frontier-dispatch-export.log',[isa,'export','-n',*dirs,'-O',str(dest),'-p','3','-x','Relative_ADP_Ceta_Dev.Relative_ADP_Code_Haskell:code/export1/**','Relative_ADP_Ceta_Dev'])
for p in dest.glob('*.hs'):
 shutil.copy2(p,r/'generated/Haskell'/p.name);shutil.copy2(p,s/'generated/Haskell'/p.name)
shutil.copy2(r/'src/Haskell/Main_Relative_ADP.hs',dest/'Main.hs');(b/'bin-frontier-v2').mkdir(exist_ok=True)
for flavor in ['relative','relative-hpc']:
 args=[ghc,'-O2','-package','array','-XRankNTypes','-odir',str(b/('ghc-frontier-v2-'+flavor)),'-hidir',str(b/('ghc-frontier-v2-'+flavor))]
 if flavor.endswith('hpc'):args+=['-fhpc','-hpcdir',str(b/'hpc-mix-frontier-relative-v2')]
 run('frontier-dispatch-'+flavor+'.log',args+['--make','Main.hs','-o',str(b/'bin-frontier-v2'/('ceta-'+flavor))],dest)
print('Dispatch build and export passed',flush=True)
