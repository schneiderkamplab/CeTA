import pathlib,json,sys,time,subprocess,gzip,collections
r=pathlib.Path.cwd();b=r/'target/consolidation-build';sys.path.insert(0,str(r/'tools/consolidation'))
from replay import sha,write
from coverage import inspect
from coverage_delta import read_mix
while not all((b/n/'summary.json').exists() for n in ['frontier-supplemental','frontier-derived']):time.sleep(5)
reg=json.loads((r/'tests/certification/compact/processor-registry.json').read_text())
targets=['check_rfc_absolute','check_cert_rfc_absolute','rel_impl_adp_com_redpair','check_relative_adp_com_redpair','certify_proof_integrated','check_outermost_rz_termination_proof']
reports={}
for suite,mixdir,manifest in [('frontier-supplemental','hpc-mix-frontier-relative','manifest.json'),('frontier-derived','hpc-mix-frontier','bridge-fixtures.json')]:
 out=b/suite;mix=b/(mixdir+'.tsv')
 if not mix.exists():
  with mix.open('w') as f:subprocess.run([str(b/'bin/export-mix'),str(b/mixdir)],stdout=f,check=True)
 entries=read_mix(mix);wanted={}
 for module,rows in entries.items():
  for row in rows:
   if row['label'].startswith('TopLevelBox'):
    for name in targets:
     if '"'+name+'"' in row['label']:wanted.setdefault(name,[]).append(dict(module=module,**row))
 observations=[]
 for root in json.loads((r/'tests/certification/frontier-20261017'/manifest).read_text())['roots']:
  run=out/root['id'];tix=run/'coverage.tix'
  raw=subprocess.check_output([str(b/'bin/export-tix'),str(tix)])
  (run/'coverage.tsv.gz').write_bytes(gzip.compress(raw,mtime=0))
  observed={}
  for line in raw.decode().splitlines():
   module,digest,count,ticks=line.split('\t');observed[module]=(digest,set(int(x) for x in ticks.split(',') if x))
  functions={name:any(e['module'] in observed and observed[e['module']][0]==e['hash'] and e['tick'] in observed[e['module']][1] for e in es) for name,es in wanted.items()}
  analysis=inspect(run/'proof.cpf.xml',root['category'],reg)
  observations.append(dict(id=root['id'],root=root['root'],coverage_sha256=sha(run/'coverage.tsv.gz'),functions=functions,unknown_proof_nodes_in_frozen_registry=analysis['unknown_proof_tags']))
  tix.unlink()
 reports[suite]=dict(mix_sha256=sha(mix),function_entries=wanted,observations=observations)
write(b/'frontier-runtime-coverage.json',dict(scope='Supplemental and explicitly derived positive execution evidence. Runtime entry counters do not execute soundness theorems or prove all side-condition coverage. Unmapped structural nodes remain explicit gaps; the genuine compact denominator is unchanged.',reports=reports))
print('Supplemental/derived runtime coverage recorded',flush=True)
