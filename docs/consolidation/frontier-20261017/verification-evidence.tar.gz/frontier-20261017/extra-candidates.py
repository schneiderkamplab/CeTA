import pathlib,json,sys,gzip,hashlib
r=pathlib.Path.cwd();sys.path.insert(0,str(r/'tools/consolidation'));from root_audit import compare
src=r.parent/'ferrum-aaecc/target/outermost-relative-20261017/com-frontier-v151/TRS_Relative';out=r/'tests/certification/frontier-20261017';out.mkdir(exist_ok=True)
rows=json.loads((out/'manifest.json').read_text())['roots']
extra=r.parent/'ferrum-aaecc/target/outermost-relative-20261017'
for row in sum((json.loads((extra/name/'details.json').read_text()) for name in ['outer-full-v119','fresh-rfc-v115']),[]):
 if not row['certified']:continue
 proof=pathlib.Path(row['artifact_dir'])/'proof.cpf.xml'; inp=(r.parent/'ferrum-aaecc'/row['path']).resolve()
 data=proof.read_bytes();text=inp.read_bytes();ident=hashlib.sha256(str(inp).encode()).hexdigest()[:20]
 d=out/ident;d.mkdir(exist_ok=True)
 (d/'input.ari').write_bytes(text);(d/'proof.cpf.xml.gz').write_bytes(gzip.compress(data,mtime=0))
 result=dict(id=ident,root=str(inp.relative_to(r.parent/'TPDB-ARI')),category=row['category'],proof_sha256=hashlib.sha256(data).hexdigest(),input_sha256=hashlib.sha256(text).hexdigest(),source=str(proof),source_record=row)
 try:result['audit']=compare(text.decode(),proof,'yes',row['category'])
 except Exception as e:result['audit_error']=str(e)
 result['source_command']=json.loads((proof.parent/'command.json').read_text())
 rows.append(result)
(out/'manifest.json').write_text(json.dumps(dict(scope='Supplemental frontier proof rechecks. Incomplete source/build provenance; excluded from the genuine oracle-only positive suite.',roots=rows),indent=2)+'\n')
print(len(rows),'frozen; audit errors:',[(x['root'],x['audit_error']) for x in rows if 'audit_error'in x])
