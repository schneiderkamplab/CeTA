from pathlib import Path
import subprocess,json,hashlib,tarfile,io
r=Path.cwd(); out=r/'docs/consolidation/frontier-20261017';out.mkdir(exist_ok=True)
manifest={}
with tarfile.open(out/'sources.tar.gz','w:gz') as t:
 for name in ['CeTA-raw-superiority','CeTA-OUTERMOST-VERIFY']:
  src=r.parent/name
  paths=subprocess.check_output(['git','diff','--name-only'],cwd=src,text=True).splitlines()+subprocess.check_output(['git','ls-files','--others','--exclude-standard','thys'],cwd=src,text=True).splitlines()
  files={p:(src/p).read_bytes() for p in paths if (src/p).is_file()}
  head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=src,text=True).strip()
  for p,data in files.items():
   assert (src/p).read_bytes()==data
   info=tarfile.TarInfo(name+'/'+p);info.size=len(data);t.addfile(info,io.BytesIO(data))
  manifest[name]={'head':head,'files':{p:hashlib.sha256(d).hexdigest() for p,d in files.items()}}
(out/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
# Import only the selected ADP/RFC changes; reject any base divergence.
src=r.parent/'CeTA-raw-superiority'
paths=[p for p in manifest[src.name]['files'] if p.startswith('thys/Relative_ADP/') and not p.endswith('Relative_ADP_Checker_Adapter_Test.thy')]+['thys/RFC_Absolute_Ext/RFC_Absolute_Check.thy']
for p in paths:
 if (r/p).exists():
  old=subprocess.check_output(['git','show','HEAD:'+p],cwd=src)
  assert (r/p).read_bytes()==old,p
 data=(src/p).read_bytes();assert hashlib.sha256(data).hexdigest()==manifest[src.name]['files'][p]
 (r/p).write_bytes(data)
p=r/'thys/RFC_Absolute_Ext/RFC_Absolute_Check.thy';p.write_text(p.read_text().replace('raw_isOK_unit','rfc_isOK_unit'))
print('Frozen and imported',len(paths),'selected files')
