from pathlib import Path
import tarfile
r=Path.cwd()
with tarfile.open(r/'docs/consolidation/frontier-20261017/sources.tar.gz') as t:
 raw=t.extractfile('CeTA-raw-superiority/thys/Raw_Campaign_Ext/Raw_Ordinary_Cert.thy').read().decode()
lemma=raw[raw.index('lemma full_termination_implies_outermost:'):raw.index('\ncontext fixes')]
p=r/'thys/RFC_Absolute_Ext/RFC_Absolute_Cert.thy';s=p.read_text().replace('\ncontext fixes','\n'+lemma+'\ncontext fixes',1)
old='| "check_cert_rfc_absolute inp prop ans p = check_cert I J K L False inp prop ans p"'
new='''| "check_cert_rfc_absolute (FP_TRS_input Outermost R) Termination (Decision True)
      (TRS_Termination_Proof p) =
    check_rfc_absolute I J (showsl_lit (STR ''1''))
      (tp_ops.mk I False [] R []) p"
'''+old
assert old in s;s=s.replace(old,new)
old='  apply ((erule check_cert_with_assms_sound[OF I J K L]; simp)+)'
new='''  apply (drule check_rfc_absolute_sound[OF I J])
  apply (rule full_termination_implies_outermost)
  apply (simp add: desired_property_def tp_spec.mk_sound[OF I])
'''+old
assert old in s;s=s.replace(old,new);p.write_text(s)
p=r/'thys/Relative_ADP/Integration/Relative_ADP_Ceta.thy';s=p.read_text().replace('    Proof_Checker.Ceta_Verifier','    Proof_Checker.Ceta_Verifier\n    RFC_Absolute_Ext.RFC_Absolute_Cert')
a=s.index('definition certify_proof_integrated ::')
s=s[:a]+'''text \\<open>Try the ordinary/RFC checker first and parse annotated dependency
pairs only if it does not certify the proof. This avoids both a duplicate checker
and a preliminary scan that forces large automaton certificates into memory.
Each successful branch retains its own soundness theorem.\\<close>

definition certify_proof_integrated ::
  "bool \\<Rightarrow> string option \\<Rightarrow> string option \\<Rightarrow>
   string option \\<Rightarrow> string \\<Rightarrow> cert_result" where
  "certify_proof_integrated assumptions inp_o prop_o answ_o proof_string =
    (let ordinary = certify_proof_rfc_absolute assumptions inp_o prop_o answ_o proof_string in
     if ordinary = Certified then ordinary else
      bind2' (parse_combined_relative_adp_cert_problem
        inp_o prop_o answ_o proof_string)
        (\\<lambda>_. ordinary)
        (\\<lambda>(inp, prop, answ, proof).
          certify_relative_adp_cert_problem inp prop answ proof))"

end
''';p.write_text(s)
p=r/'thys/Relative_ADP/Integration/ROOT';s=p.read_text().replace('    Proof_Checker','    Proof_Checker\n    RFC_Absolute_Ext');p.write_text(s)
