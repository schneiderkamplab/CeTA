import pathlib,json,gzip,subprocess,sys,time
r=pathlib.Path.cwd();b=r/'target/consolidation-build';sys.path.insert(0,str(r/'tools/consolidation'));from replay import sha,write
while not (b/'hpc-modules-frontier.tsv').exists():time.sleep(5)
t=json.load(gzip.open(r/'docs/consolidation/cleanup-coverage-transition.json.gz','rt'))
modules={};offset=0
for name,m in sorted(t['new_modules'].items()):modules[name]=m|dict(offset=offset);offset+=m['count']
req=sorted(set(modules[x['module']]['offset']+x['new_tick'] for x in t['mappings']))
d=b/'frontier-intermediate-denominator.json';write(d,dict(modules=modules,required_obligations=req))
subprocess.run(['python3','tools/consolidation/coverage_delta.py','--old-mix',str(b/'hpc-mix-cleanup.tsv'),'--new-mix',str(b/'hpc-mix-frontier.tsv'),'--old-source',str(b/'cleanup-rfc-haskell'),'--new-source',str(b/'frontier-rfc-haskell'),'--denominator',str(d),'--output',str(b/'frontier-coverage-delta.json')],check=True)
delta=json.loads((b/'frontier-coverage-delta.json').read_text())
newmods={}
for line in (b/'hpc-modules-frontier.tsv').read_text().splitlines():
 n,h,c,_=line.split('\t');newmods[n]=dict(hash=h,count=int(c))
lookup={x['old_obligation']:x for x in delta['mappings']};mapped=[];gaps=[]
for old in t['mappings']:
 i=modules[old['module']]['offset']+old['new_tick'];new=lookup.get(i)
 if new:mapped.append(new|dict(old_obligation=old['old_obligation'],old_tick=old['old_tick']))
 else:gaps.append(old|dict(intermediate_obligation=i))
write(b/'frontier-transition-proposal.json',dict(denominator_sha256=t['denominator_sha256'],checker_sha256=sha(b/'bin-frontier/ceta'),hpc_checker_sha256=sha(b/'bin-frontier/ceta-hpc'),mappings=mapped,retired=t['retired'],new_modules=newmods,gaps=gaps,scope='Original frozen denominator; unchanged-expression composition through verified cleanup mapping; changed enclosing expressions require explicit review.'))
print('Mapped',len(mapped),'gaps',len(gaps),flush=True)
