import pathlib,time,json,subprocess
r=pathlib.Path.cwd();b=r/'target/consolidation-build';p=b/'logs/frontier-hpc.receipt.json'
while not p.exists():time.sleep(5)
assert json.loads(p.read_text())['returncode']==0
raise SystemExit(subprocess.run(['python3','tools/consolidation/run_logged.py','--log',str(b/'logs/frontier-derived.log'),'--','python3','tools/consolidation/frontier_suite.py','--manifest','tests/certification/frontier-20261017/bridge-fixtures.json','--checker',str(b/'bin-frontier/ceta'),'--hpc-checker',str(b/'bin-frontier/ceta-hpc'),'--output',str(b/'frontier-derived'),'--jobs','2']).returncode)
