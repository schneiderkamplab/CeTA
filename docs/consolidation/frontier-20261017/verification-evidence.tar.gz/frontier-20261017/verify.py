import pathlib,subprocess,json,time,shutil,os
r=pathlib.Path.cwd();b=r/'target/consolidation-build'
receipt=b/'logs/frontier-hpc.receipt.json'
while not receipt.exists():time.sleep(5)
assert json.loads(receipt.read_text())['returncode']==0
wrap=['python3',str(r/'tools/consolidation/run_logged.py')]
corpus=subprocess.Popen([*wrap,'--log',str(b/'logs/frontier-corpus.log'),'--','python3','tools/consolidation/recheck_packaged.py','--source',str(b/'final-full-replay'),'--manifest','tests/certification/replay-assets/full-replay.json','--checker',str(b/'bin-frontier/ceta'),'--hpc-checker',str(b/'bin-frontier/ceta-hpc'),'--export-tix',str(b/'bin/export-tix'),'--additional-checker',str(b/'bin-frontier/ceta-relative-adp'),'--output',str(b/'frontier-corpus'),'--jobs','16'],cwd=r)
ghc='/work/dfm/festschrift/ferrum/.tools/.ghcup/bin/ghc';dest=b/'frontier-relative-haskell';shutil.copy2(r/'src/Haskell/Main_Relative_ADP.hs',dest/'Main.hs')
subprocess.run([*wrap,'--log',str(b/'logs/frontier-relative-hpc.log'),'--',ghc,'-O2','-package','array','-XRankNTypes','-odir',str(b/'ghc-frontier-relative-hpc'),'-hidir',str(b/'ghc-frontier-relative-hpc'),'-fhpc','-hpcdir',str(b/'hpc-mix-frontier-relative'),'--make','Main.hs','-o',str(b/'bin-frontier/ceta-relative-hpc')],cwd=dest,check=True)
subprocess.run([*wrap,'--log',str(b/'logs/frontier-supplemental.log'),'--','python3','tools/consolidation/frontier_suite.py','--manifest','tests/certification/frontier-20261017/manifest.json','--checker',str(b/'bin-frontier/ceta-relative-adp'),'--hpc-checker',str(b/'bin-frontier/ceta-relative-hpc'),'--output',str(b/'frontier-supplemental')],cwd=r,check=True)
raise SystemExit(corpus.wait())
