import pathlib,time,json,subprocess
r=pathlib.Path.cwd();b=r/'target/consolidation-build';wrap=['python3','tools/consolidation/run_logged.py']
def wait(name):
 p=b/'logs'/(name+'.receipt.json')
 while not p.exists():time.sleep(5)
 assert json.loads(p.read_text())['returncode']==0

def run(name,args):return subprocess.run([*wrap,'--log',str(b/'logs'/(name+'.log')),'--',*args],check=True)
wait('frontier-dispatch-relative')
proof=b/'final-full-replay/e024eddb80edda4f7311b16f/proof.cpf.xml'
for name,binary in [('previous',b/'bin-sharing/ceta-relative-adp'),('fixed',b/'bin-frontier-v2/ceta-relative')]:
 run('frontier-streaming-'+name,[str(binary),str(proof)])
corpus=subprocess.Popen([*wrap,'--log',str(b/'logs/frontier-corpus-integrated-v2.log'),'--','python3','tools/consolidation/recheck_entry.py','--source',str(b/'final-full-replay'),'--manifest','tests/certification/replay-assets/full-replay.json','--checker',str(b/'bin-frontier-v2/ceta-relative'),'--output',str(b/'frontier-corpus-integrated-v2'),'--jobs','8'])
run('frontier-compact-integrated-v2',['python3','tools/consolidation/suite.py','--manifest','tests/certification/compact/manifest.json','--checker',str(b/'bin-frontier-v2/ceta-relative'),'--output',str(b/'compact-frontier-integrated-v2')])
wait('frontier-dispatch-relative-hpc')
run('frontier-supplemental-v2',['python3','tools/consolidation/frontier_suite.py','--manifest','tests/certification/frontier-20261017/manifest.json','--checker',str(b/'bin-frontier-v2/ceta-relative'),'--hpc-checker',str(b/'bin-frontier-v2/ceta-relative-hpc'),'--output',str(b/'frontier-supplemental-v2')])
raise SystemExit(corpus.wait())
