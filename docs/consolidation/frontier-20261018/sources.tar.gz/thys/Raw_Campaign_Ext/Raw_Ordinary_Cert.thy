theory Raw_Ordinary_Cert
  imports "../RFC_Absolute_Ext/RFC_Absolute_Cert"
begin

lemma full_termination_implies_outermost:
  assumes "desired_property (Inn_TRS_input No_Strategy R []) Termination (Decision True)"
  shows "desired_property (FP_TRS_input Outermost R) Termination (Decision True)"
proof -
  have sn: "SN (Trs.rstep (set R))"
    using assms by (simp add: desired_property_def SN_qrel_def)
  have subset: "ostep (lhss (set R)) (set R) \<subseteq> Trs.rstep (set R)"
    unfolding ostep_defs using rstep_r_p_s_imp_rstep by blast
  from SN_subset[OF sn subset] show ?thesis
    by (simp add: desired_property_def)
qed

context fixes
  I :: "('tp, ('f::{showl,compare_order,countable},label_type) lab,string) tp_ops"
  and J :: "('dpp, ('f,label_type) lab,string) dpp_ops"
  and K :: "('ac_tp, ('f,label_type) lab,string) ac_tp_ops"
  and L :: "('ac_dpp, ('f,label_type) lab,string) ac_dpp_ops"
begin

fun certify_cert_problem_full_outermost :: "bool \<Rightarrow> (('f,label_type) lab,string) input
  \<Rightarrow> (('f,label_type) lab,string) property \<Rightarrow> (('f,label_type) lab,string) answer
  \<Rightarrow> ('f,label_type,string) proof \<Rightarrow> cert_result" where
  "certify_cert_problem_full_outermost a (FP_TRS_input Outermost R) Termination (Decision True)
      (TRS_Termination_Proof p) =
    certify_cert_problem_rfc_absolute I J K L a
      (Inn_TRS_input No_Strategy R []) (Termination :: (('f,label_type) lab,string) property)
        (Decision True) (TRS_Termination_Proof p)"
| "certify_cert_problem_full_outermost a inp prop ans p =
    certify_cert_problem_rfc_absolute I J K L a inp prop ans p"

lemma certify_cert_problem_full_outermost_sound:
  assumes I: "tp_spec I" and J: "dpp_spec J" and K: "ac_tp_spec K" and L: "ac_dpp_spec L"
    and ok: "certify_cert_problem_full_outermost False inp prop ans p = Certified"
  shows "desired_property inp prop ans"
  using ok
  apply (induction "False" "inp" "prop" "ans" "p" rule: certify_cert_problem_full_outermost.induct)
  apply (simp_all only: certify_cert_problem_full_outermost.simps)
  apply (drule certify_cert_problem_rfc_absolute_sound[OF I J K L])
  apply (erule full_termination_implies_outermost)
  apply (erule certify_cert_problem_rfc_absolute_sound[OF I J K L])+
  done

definition certify_cert_problem_raw where
  "certify_cert_problem_raw a inp prop ans p =
    (let old = certify_cert_problem_rfc_absolute I J K L a inp prop ans p in
      if old = Certified then old
      else certify_cert_problem_full_outermost a inp prop ans p)"

lemma certify_cert_problem_raw_sound:
  assumes I: "tp_spec I" and J: "dpp_spec J" and K: "ac_tp_spec K" and L: "ac_dpp_spec L"
    and ok: "certify_cert_problem_raw False inp prop ans p = Certified"
  shows "desired_property inp prop ans"
  using ok unfolding certify_cert_problem_raw_def Let_def
  by (auto split: if_splits intro:
      certify_cert_problem_rfc_absolute_sound[OF I J K L]
      certify_cert_problem_full_outermost_sound[OF I J K L])
end

definition certify_proof_raw where
  "certify_proof_raw a inp_o prop_o answ_o prfs =
    bind2' (parse_combined_cert_problem inp_o prop_o answ_o prfs) Unsupported
      (\<lambda>(inp,prop,answ,p).
        certify_cert_problem_raw tp_impl dpp_impl ac_tp_impl ac_dpp_impl a inp prop answ p)"

end
