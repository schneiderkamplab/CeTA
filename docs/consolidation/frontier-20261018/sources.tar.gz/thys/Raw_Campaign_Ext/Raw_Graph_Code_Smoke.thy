theory Raw_Graph_Code_Smoke
  imports Raw_Campaign_Cert
begin
ML \<open>
  val _ = Code_Target.produce_code @{context} false
    [@{const_name relative_adp_root_graph_candidates}]
    "Haskell" "GraphSmoke" NONE [];
  val _ = writeln "ROOT_GRAPH_CODE_EXPORT_PASSED";
\<close>
end
