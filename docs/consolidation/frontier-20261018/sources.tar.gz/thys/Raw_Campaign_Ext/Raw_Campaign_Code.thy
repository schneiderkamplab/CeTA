theory Raw_Campaign_Code
  imports Raw_Campaign_Cert
begin

ML \<open>
  val checked = @{thms certify_cert_problem_raw_sound certify_relative_adp_cert_problem_sound};
  val _ = if Options.default_bool "quick_and_dirty" orelse Thm_Deps.has_skip_proof checked
    then error "Unverified checker dependencies" else ();
\<close>

export_code certify_proof_raw_integrated certify_proof_raw Certified Unsupported Error Inl Inr
  nat_of_integer literal.explode
  in Haskell module_name Ceta_Raw_Integrated

end
