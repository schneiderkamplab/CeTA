theory Raw_Campaign_Cert
  imports Raw_Ordinary_Cert "../Relative_ADP/Integration/Relative_ADP_Ceta"
begin

fun raw_tag_prefix :: "string \<Rightarrow> string \<Rightarrow> bool" where
  "raw_tag_prefix [] ys = True"
| "raw_tag_prefix (x # xs) [] = False"
| "raw_tag_prefix (x # xs) (y # ys) = (x = y \<and> raw_tag_prefix xs ys)"

fun raw_has_adp_tag :: "string \<Rightarrow> bool" where
  "raw_has_adp_tag [] = False"
| "raw_has_adp_tag (c # cs) =
    (raw_tag_prefix ''<relativeAdpTerminationProof>'' (c # cs) \<or> raw_has_adp_tag cs)"

definition certify_proof_raw_integrated where
  "certify_proof_raw_integrated a inp_o prop_o answ_o prfs =
    (let ordinary = certify_proof_raw a inp_o prop_o answ_o prfs in
     if ordinary = Certified then ordinary else
      bind2' (parse_combined_relative_adp_cert_problem inp_o prop_o answ_o prfs)
      (\<lambda>_. ordinary)
      (\<lambda>(inp,prop,answ,p). certify_relative_adp_cert_problem inp prop answ p))"

text \<open>Ordinary proofs use the established checker first. Only unsuccessful
checks try the independently sound annotated-DP checker. A preliminary scan of
the entire XML must be avoided: it forces multi-gigabyte automata certificates
before parsing. Neither dispatch nor a failed check grants proof credit.\<close>

end
