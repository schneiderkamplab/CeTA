import pathlib,json,time,subprocess,hashlib
r=pathlib.Path.cwd();b=r/'target/consolidation-build';comparison=b/'frontier-20261018/parent-export-comparison.json'
while not comparison.exists():time.sleep(5)
x=json.loads(comparison.read_text());assert x['identical'], 'Generated output changed: review before committing'
assert subprocess.check_output(['git','rev-parse','--short','HEAD'],text=True).strip()=='8259236'
assert subprocess.run(['git','diff','--cached','--quiet']).returncode==0
p=pathlib.Path('thys/Relative_ADP/Integration/ROOT');assert (r/p).read_bytes()==subprocess.check_output(['git','show','HEAD:'+str(p)])
(r/p).write_bytes((b/'checker-source'/p).read_bytes())
report=x|dict(validation={})
for name in ['frontier-parent-20261018-build','frontier-parent-20261018-export']:
 q=b/'logs'/(name+'.receipt.json');receipt=json.loads(q.read_text());assert receipt['returncode']==0;report['validation'][name]=receipt
report['source_sha256']=hashlib.sha256((r/p).read_bytes()).hexdigest();report['scope']='Session-parent change only; exported modules match the previously verified committed checker byte for byte.'
doc=r/'docs/consolidation/frontier-20261018/parent-verification.json';doc.write_text(json.dumps(report,indent=2)+'\n')
subprocess.run(['git','add','--',str(p),str(doc.relative_to(r))],check=True)
subprocess.run(['git','diff','--cached','--check'],check=True)
subprocess.run(['git','commit','-m','Reuse the verified ordinary heap for ADP integration'],check=True)
commit=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip();(b/'frontier-20261018/parent-commit.json').write_text(json.dumps(dict(commit=commit),indent=2)+'\n');print(commit,flush=True)
