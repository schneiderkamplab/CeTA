import pathlib,time,subprocess
r=pathlib.Path.cwd();b=r/'target/consolidation-build';manifest=b/'frontier-20261018/campaign/manifest.json'
while not manifest.exists():time.sleep(5)
p=subprocess.run(['python3','tools/consolidation/run_logged.py','--log',str(b/'logs/frontier-20261018-previous-campaign.log'),'--','python3','tools/consolidation/campaign_recheck.py','--manifest',str(manifest),'--checker',str(b/'bin-frontier-v3/ceta-relative'),'--output',str(b/'frontier-20261018/previous-campaign'),'--jobs','4'])
print('Previous checker comparison exit',p.returncode,flush=True)
