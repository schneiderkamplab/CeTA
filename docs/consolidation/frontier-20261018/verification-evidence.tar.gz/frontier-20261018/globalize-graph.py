import pathlib,re
r=pathlib.Path.cwd();p=r/'thys/Relative_ADP/Semantics/Dependency_Graph/Relative_ADP_Generic_Graph_Impl.thy';s=p.read_text();backup=r/'target/consolidation-build/frontier-20261018/graph-locale-before-export-fix.thy';backup.write_text(s)
pattern=r'definition (\w+) ::\s*"([^"]+)" where\s*"([^"]+)"\n'
found=list(re.finditer(pattern,s));assert len(found)==16,len(found)
dependent={'estimated_successors'};definitions=[];aliases=[]
for m in found:
 name,typ,body=m.groups();dep=any(re.search(r'\b'+n+r'\b',body) for n in dependent)
 if dep:
  dependent.add(name);typ="(('f,'v) adp list \\<Rightarrow> nat \\<Rightarrow> nat list) \\<Rightarrow>\n    "+typ
 # All definition references occur in original dependency order.
 for n in sorted(dependent-{'estimated_successors'},key=len,reverse=True):
  body=re.sub(r'\b'+n+r'\b','('+n+' estimated_successors)',body)
 definitions.append('definition '+name+' ::\n  "'+typ+'" where\n  "'+body+'"\n')
 if dep:aliases.append('abbreviation '+name+' where\n  "'+name+' \\<equiv> Relative_ADP_Generic_Graph_Impl.'+name+' estimated_successors"\n')
 aliases.append('lemmas '+name+'_def = Relative_ADP_Generic_Graph_Impl.'+name+'_def'+('[where estimated_successors=estimated_successors]' if dep else '')+'\n')
start=s.index('locale relative_adp_graph_estimator');begin=s.index('\nbegin\n',start)+len('\nbegin\n');end=s.index('\nend\n\ndeclare relative_adp_graph_estimator.')
proofs=re.sub(pattern,'',s[begin:end]);header=s[start:begin]
text=s[:start]+'''text \\<open>The executable graph functions are total definitions independent of
estimator correctness. The locale below supplies bounds and edge coverage only
for their soundness proofs. Both checked estimators use these same functions.\\<close>

'''+ '\n'.join(definitions)+'\n'+header+'\n'+'\n'.join(aliases)+'\n'+proofs+'\nend\n\nend\n'
p.write_text(text)
for name in ['thys/Relative_ADP/Semantics/Dependency_Graph/Relative_ADP_Dependency_Graph_Impl.thy','thys/Relative_ADP/Checker/Relative_ADP_Root_Graph.thy']:
 q=r/name;q.write_text(q.read_text().replace('relative_adp_graph_estimator.relative_adp_','Relative_ADP_Generic_Graph_Impl.relative_adp_'))
print('Moved',len(found),'executable definitions outside the soundness locale')
