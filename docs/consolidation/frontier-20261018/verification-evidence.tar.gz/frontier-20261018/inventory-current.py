import pathlib,json,hashlib,collections,xml.etree.ElementTree as ET
r=pathlib.Path.cwd();p=r.parent/'ferrum-aaecc/target/outermost-relative-20261017';b=r/'target/consolidation-build';out=b/'frontier-20261018'
known=set()
for f in (b/'final-full-replay').glob('*/result.json'):
 x=json.loads(f.read_text());known.add((x['root'],x['cpf_sha256'],x['input_sha256'],x['expected_answer']))
for x in json.loads((r/'tests/certification/frontier-20261017/manifest.json').read_text())['roots']:known.add((x['root'],x['proof_sha256'],x['input_sha256'],'yes'))
seen={};missing=[];reports=[]
for f in [p/d/'details.json' for d in ['protected-recovered-v235','final-TRS_Relative-v225','final-TRS_Outermost-v225','replay-private-srs-v206','csr-production-replay-v240']]:
 print('Inventory',f,flush=True)
 try: rows=json.loads(f.read_text())
 except Exception as e: reports.append({'file':str(f),'error':str(e)});continue
 if not isinstance(rows,list):continue
 for row in rows:
  if not isinstance(row,dict) or not row.get('certified'):continue
  proof=pathlib.Path(row['artifact_dir'])/'proof.cpf.xml';inp=(r.parent/'ferrum-aaecc'/row['path']).resolve()
  if not proof.exists() or not inp.exists():missing.append(dict(report=str(f),proof=str(proof),input=str(inp)));continue
  with proof.open('rb') as handle: digest=hashlib.file_digest(handle,'sha256').hexdigest()
  key=(str(inp.relative_to(r.parent/'TPDB-ARI')),digest,hashlib.sha256(inp.read_bytes()).hexdigest(),row.get('status'))
  if key in known:continue
  if key in seen:seen[key]['reports'].append(str(f));continue
  try: tags=collections.Counter(n.tag for n in ET.parse(proof).iter())
  except Exception as e:reports.append(dict(file=str(proof),error=str(e)));continue
  seen[key]=dict(id=hashlib.sha256(('|'.join(key)).encode()).hexdigest()[:24],proof_sha256=key[1],input_sha256=key[2],root=str(inp.relative_to(r.parent/'TPDB-ARI')),category=row['category'],answer=row.get('status'),source=str(proof),input=str(inp),reports=[str(f)],source_record=row,new_nodes={k:tags[k] for k in ['relativeAdpRootDependencyGraph','relativeAdpFilteredDerelatification'] if tags[k]})
result=dict(scope='Successful campaign records, supplementary until provenance audit; exact proof/input hash difference from prior frozen suites',roots=list(seen.values()),missing=missing,errors=reports)
(out/'campaign-inventory.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(dict(new=len(seen),missing=len(missing),errors=len(reports),categories=dict(collections.Counter(x['category'] for x in seen.values())),new_modes=dict(collections.Counter(k for x in seen.values() for k in x['new_nodes'])))))
