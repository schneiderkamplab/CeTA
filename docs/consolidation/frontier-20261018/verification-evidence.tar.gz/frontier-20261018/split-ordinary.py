"""Prepare exact source stages for the three imported ordinary criteria."""
import subprocess,re,pathlib
r=pathlib.Path.cwd();out=r/'target/consolidation-build/frontier-20261018/ordinary-stages';out.mkdir(exist_ok=True)
path='thys/Proof_Checker_Base/Check_Termination.thy'
full=subprocess.check_output(['git','show','85b6876:'+path],text=True)
# All affected declarations/cases are delimited; never rewrite a proof body.
def version(keep):
 s=full
 for feature,constructor,number in [('rule','Rule_Strengthening',54),('qdp','Zantema_To_SRS_Proc',53)]:
  if feature in keep:continue
  s=re.sub(r'^\| '+constructor+r'[^\n]*\n','',s,flags=re.M)
  s=re.sub(r'^\| "(?:sn|dp)_assms [^\n]*\('+constructor+r'[^\n]*\n','',s,flags=re.M)
  pattern=r'^\| "check_(?:trs|dp)_termination_proof [^\n]*\('+constructor+r'[^\n]*\n.*?(?=^\| |^  by pat_completeness)'
  s,n=re.subn(pattern,'',s,flags=re.M|re.S);assert n==1,(feature,n)
  pattern=r'^next\n  case \('+str(number)+r' [^\n]*\n.*?(?=^next\n|^qed\n)'
  s,n=re.subn(pattern,'',s,flags=re.M|re.S);assert n==1,(feature,n)
 if 'qdp' not in keep:s=s.replace(' QDP_To_SRS_Zantema','')
 if 'rule' not in keep:s=s.replace(' Rule_Strengthening\n','\n')
 return s
for name,keep in [('aaecc',set()),('qdp',{'qdp'}),('rule',{'qdp','rule'})]:
 s=version(keep);(out/(name+'.thy')).write_text(s)
 assert s.count('next\n  case (')==full.count('next\n  case (')-(2-len(keep))
print('Three ordinary processor source stages prepared')
