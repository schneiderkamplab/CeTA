import pathlib,json,time,subprocess,hashlib
r=pathlib.Path.cwd();b=r/'target/consolidation-build';f=b/'frontier-20261018'
p=b/'logs/frontier-filter-20261018-export.receipt.json'
while not p.exists():time.sleep(5)
assert json.loads(p.read_text())['returncode']==0
# Archive the exact production-source identity before reusing the private source.
files=subprocess.check_output(['git','ls-files','thys','dev','src','Makefile','ROOTS'],text=True).splitlines()+['thys/Relative_ADP/Checker/Relative_ADP_DP_Argument_Filter.thy']
hashes={}
for name in files:
 path=r/name
 if path.is_file():
  assert path.read_bytes()==(b/'checker-source'/name).read_bytes(),name
  hashes[name]=hashlib.sha256(path.read_bytes()).hexdigest()
(f/'filter-built-source.json').write_text(json.dumps(hashes,indent=2)+'\n')
subprocess.run(['python3','tools/consolidation/validate_feature_series.py','--manifest',str(f/'series-root-check/manifest.json'),'--source',str(b/'checker-source'),'--output',str(f/'series-validation-prefix'),'--isabelle','/work/dfm/festschrift/ferrum/.tools/Isabelle2025-2/bin/isabelle','--user-home',str(b/'isabelle-user'),'--identifier','consolidated_frontier_20261017','--afp',str(b/'afp-source/thys'),'--stop','22'],check=True)
