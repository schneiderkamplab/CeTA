import pathlib,json,gzip,xml.etree.ElementTree as ET,sys,time,hashlib
r=pathlib.Path.cwd();b=r/'target/consolidation-build';sys.path.insert(0,str(r/'tools/consolidation'));from replay import execute,certified,write
receipt=b/'logs/frontier-root-20261018-relative.receipt.json'
while not receipt.exists():time.sleep(5)
assert json.loads(receipt.read_text())['returncode']==0
source=r/'tests/certification/frontier-20261017';out=b/'frontier-20261018/root-derived-probe';out.mkdir(exist_ok=False);results=[]
for row in json.loads((source/'manifest.json').read_text())['roots']:
 tree=ET.ElementTree(ET.fromstring(gzip.decompress((source/row['id']/'proof.cpf.xml.gz').read_bytes())))
 graphs=list(tree.iter('relativeAdpDependencyGraph'))
 if not graphs:continue
 for node in graphs:node.tag='relativeAdpRootDependencyGraph'
 run=out/row['id'];run.mkdir();proof=run/'proof.xml';tree.write(proof);prefix=run/'check'
 c=execute([str(b/'bin-frontier-root-20261018/ceta-relative'),str(proof)],run,{},prefix,600);c['certified']=certified(c,prefix)
 results.append(dict(source_id=row['id'],source_sha256=row['proof_sha256'],mutation='Replace baseline ADP graph nodes with root-sensitive graph nodes; original input unchanged',proof_sha256=hashlib.sha256(proof.read_bytes()).hexdigest(),check=c))
write(out/'summary.json',dict(scope='Derived certificates, never real Ferrum replays',results=results))
print('Derived accepted',sum(x['check']['certified'] for x in results),'of',len(results),flush=True)
