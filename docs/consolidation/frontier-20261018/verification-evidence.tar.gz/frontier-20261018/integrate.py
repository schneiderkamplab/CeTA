import pathlib,json,hashlib,tarfile,subprocess,shutil
r=pathlib.Path.cwd();dev=r.parent/'CeTA-raw-superiority';out=r/'docs/consolidation/frontier-20261018';out.mkdir(exist_ok=True)
paths=subprocess.check_output(['git','ls-files','-m','-o','--exclude-standard'],cwd=dev,text=True).splitlines()
files={p:hashlib.sha256((dev/p).read_bytes()).hexdigest() for p in paths if (dev/p).is_file()}
with tarfile.open(out/'sources.tar.gz','w:gz') as t:
 for p in files:t.add(dev/p,arcname=p)
(out/'manifest.json').write_text(json.dumps(dict(head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=dev,text=True).strip(),base=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),files=files),indent=2)+'\n')
b=r/'target/consolidation-build/frontier-20261018';(b/'original').mkdir(exist_ok=True)
for p in ['thys/Relative_ADP/Checker/Relative_ADP_Checker_Adapter.thy','thys/Relative_ADP/Checker/Relative_ADP_Checker_Tests.thy','thys/Relative_ADP/Integration/Relative_ADP_Ceta.thy']:
 (b/'original'/pathlib.Path(p).name).write_bytes((r/p).read_bytes())
for name in ['Relative_ADP_Generic_Graph_Impl','Relative_ADP_Root_Graph']:
 p='thys/Relative_ADP/Checker/'+name+'.thy';shutil.copy2(dev/p,r/p)
p='thys/Relative_ADP/Checker/Relative_ADP_Checker_Adapter.thy';old=(r/p).read_text();new=(dev/p).read_text()
new=new.replace('    Relative_ADP_DP_Argument_Filter\n','').replace('      "((\'f adp_symbol, nat list) lab) afs_list"\n','')
start='| "check_relative_adp_termination_proof P B\n      (Relative_ADP_Derelatification';end='theorem check_relative_adp_termination_proof_sound:'
new=new[:new.index(start)]+old[old.index(start):old.index(end)]+new[new.index(end):]
start='next\n  fix filters cert P B';end='  have finite_plain:'
new=new[:new.index(start)]+old[old.index('next\n  fix cert P B'):old.index(end)]+new[new.index(end):]
(r/p).write_text(new)
p=r/'thys/Relative_ADP/Checker/Relative_ADP_Checker_Tests.thy';p.write_text(p.read_text().replace('Relative_ADP_Dependency_Graph [','Relative_ADP_Dependency_Graph False ['))
p=r/'thys/Relative_ADP/Integration/Relative_ADP_Ceta.thy';text=p.read_text().replace('xml_return (Relative_ADP_Dependency_Graph proofs)','xml_return (Relative_ADP_Dependency_Graph False proofs)\n      } XMLor XMLdo (STR \'\'relativeAdpRootDependencyGraph\'\') {\n        proofs \\<leftarrow>* xml2relative_adp_termination_proof;\n        xml_return (Relative_ADP_Dependency_Graph True proofs)');p.write_text(text)
