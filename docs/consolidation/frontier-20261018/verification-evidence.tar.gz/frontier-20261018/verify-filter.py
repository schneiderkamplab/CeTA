import pathlib,json,time,subprocess,os,sys,hashlib
r=pathlib.Path.cwd();b=r/'target/consolidation-build';sys.path.insert(0,str(r/'tools/consolidation'));from replay import execute,sha,write

def wait(name):
 p=b/'logs'/(name+'.receipt.json')
 while not p.exists():time.sleep(5)
 assert json.loads(p.read_text())['returncode']==0,name

def run(name,cmd,env=None):
 subprocess.run(['python3','tools/consolidation/run_logged.py','--log',str(b/'logs'/(name+'.log')),'--',*cmd],env=env,check=True)

wait('frontier-filter-20261018-relative')
checker=b/'bin-frontier-filter-20261018/ceta-relative';hpc=b/'bin-frontier-filter-20261018/ceta-relative-hpc'
compact=b/'frontier-filter-20261018-compact'
run('frontier-filter-20261018-compact',['python3','tools/consolidation/suite.py','--manifest','tests/certification/compact/manifest.json','--checker',str(checker),'--output',str(compact)])
run('frontier-filter-20261018-performance',['python3','tools/consolidation/performance.py','--manifest','tests/certification/compact/manifest.json','--suite-result',str(compact/'summary.json'),'--reference',str(r/'target/consolidation-snapshot/artifacts/production_checker'),'--candidate',str(checker),'--output',str(b/'frontier-filter-20261018-performance'),'--repeats','9'])
wait('frontier-filter-20261018-relative-hpc')
run('frontier-filter-20261018-supplemental',['python3','tools/consolidation/frontier_suite.py','--manifest','tests/certification/frontier-20261017/manifest.json','--checker',str(checker),'--hpc-checker',str(hpc),'--output',str(b/'frontier-filter-20261018-supplemental')])

run('frontier-filter-20261018-new-positives',['python3','tools/consolidation/campaign_recheck.py','--manifest','tests/certification/frontier-20261018/manifest.json','--checker',str(checker),'--hpc-checker',str(hpc),'--output',str(b/'frontier-filter-20261018-new-positives')])
run('frontier-filter-20261018-new-negatives',['python3','tools/consolidation/adp_frontier_negatives.py','--manifest','tests/certification/frontier-20261018/manifest.json','--checker',str(checker),'--hpc-checker',str(hpc),'--output',str(b/'frontier-filter-20261018-new-negatives')])
print('Focused filter verification passed',flush=True)
