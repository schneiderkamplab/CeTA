import pathlib,json,hashlib,subprocess
r=pathlib.Path.cwd();b=r/'target/consolidation-build';f=b/'frontier-20261018';prefix='frontier-shared-v3-20261018'
assert 'Shared root graph verification passed' in (f/'verify-shared-v3.out').read_text()
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
receipts={p.name:json.loads(p.read_text()) for p in (b/'logs').glob(prefix+'*.receipt.json')}
assert receipts and all(x['returncode']==0 for x in receipts.values())
paths=subprocess.check_output(['git','diff','--name-only'],text=True).splitlines()+['thys/Relative_ADP/Checker/Relative_ADP_Root_Graph.thy','thys/Relative_ADP/Semantics/Dependency_Graph/Relative_ADP_Generic_Graph_Impl.thy']
for path in paths:
 if path.startswith('thys/'):assert (r/path).read_bytes()==(b/'checker-source'/path).read_bytes(),path
assert (r/'generated/Haskell/Ceta_Relative.hs').read_bytes()==(b/(prefix+'-haskell/Ceta_Relative.hs')).read_bytes()
summaries={}
for suffix in ['compact','performance','supplemental']:
 p=b/(prefix+'-'+suffix)/'summary.json';d=json.loads(p.read_text());summaries[suffix]={'sha256':sha(p),**{k:v for k,v in d.items() if k not in ['results','cpu_affinity']}}
p=f/'shared-root-derived-v3/summary.json';d=json.loads(p.read_text());assert d['passed'];summaries['derived_graph_negatives']={'count':len(d['results']),'passed':True,'sha256':sha(p)}
report=dict(source_base=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),source_sha256={p:sha(r/p) for p in paths},receipts=receipts,summaries=summaries,scope='Shared root-sensitive graph feature. Genuine nonempty new-mode proofs require the following filter feature; derived mutations are not genuine positives.',executable_structure='One generic successor-parameterized graph algorithm; baseline and root-compatible estimators instantiate one soundness locale.')
out=r/'docs/consolidation/frontier-20261018/root-verification.json';out.write_text(json.dumps(report,indent=2)+'\n')
subprocess.run(['git','diff','--check'],check=True)
subprocess.run(['git','add','--',*paths,str(out.relative_to(r))],check=True)
subprocess.run(['git','commit','-m','Share ADP graph checking and add root-sensitive estimation'],check=True)
commit=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip();(f/'root-commit.json').write_text(json.dumps({'commit':commit})+'\n')
