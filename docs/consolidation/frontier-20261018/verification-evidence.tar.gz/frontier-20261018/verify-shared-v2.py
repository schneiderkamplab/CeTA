import pathlib,json,time,subprocess,os,sys,hashlib
r=pathlib.Path.cwd();b=r/'target/consolidation-build';sys.path.insert(0,str(r/'tools/consolidation'));from replay import execute,sha,write

def wait(name):
 p=b/'logs'/(name+'.receipt.json')
 while not p.exists():time.sleep(5)
 assert json.loads(p.read_text())['returncode']==0,name

def run(name,cmd,env=None):
 subprocess.run(['python3','tools/consolidation/run_logged.py','--log',str(b/'logs'/(name+'.log')),'--',*cmd],env=env,check=True)

wait('frontier-shared-v2-20261018-relative')
checker=b/'bin-frontier-shared-v2-20261018/ceta-relative';hpc=b/'bin-frontier-shared-v2-20261018/ceta-relative-hpc'
compact=b/'frontier-shared-v2-20261018-compact'
run('frontier-shared-v2-20261018-compact',['python3','tools/consolidation/suite.py','--manifest','tests/certification/compact/manifest.json','--checker',str(checker),'--output',str(compact)])
run('frontier-shared-v2-20261018-performance',['python3','tools/consolidation/performance.py','--manifest','tests/certification/compact/manifest.json','--suite-result',str(compact/'summary.json'),'--reference',str(r/'target/consolidation-snapshot/artifacts/production_checker'),'--candidate',str(checker),'--output',str(b/'frontier-shared-v2-20261018-performance'),'--repeats','9'])
wait('frontier-shared-v2-20261018-relative-hpc')
# With the ordinary stack as heap parent, explicitly build the ADP test session.
s=b/'checker-source';env=dict(os.environ,USER_HOME=str(b/'isabelle-user'),ISABELLE_IDENTIFIER='consolidated_frontier_20261017',AFP=str(b/'afp-source/thys'))
dirs=sum((['-d',str(s/d)] for d in ['thys','thys/Relative_ADP','thys/RFC_Absolute_Ext']),[])
run('frontier-shared-v2-20261018-tests',['/work/dfm/festschrift/ferrum/.tools/Isabelle2025-2/bin/isabelle','build','-v','-j','2','-o','threads=8','-o','parallel_proofs=0',*dirs,'Relative_ADP_Checker_Dev'],env)
run('frontier-shared-v2-20261018-supplemental',['python3','tools/consolidation/frontier_suite.py','--manifest','tests/certification/frontier-20261017/manifest.json','--checker',str(checker),'--hpc-checker',str(hpc),'--output',str(b/'frontier-shared-v2-20261018-supplemental')])
probe=b/'frontier-20261018/root-derived-probe';report=json.loads((probe/'summary.json').read_text());out=b/'frontier-20261018/shared-root-derived-v2';out.mkdir();results=[]
for row in report['results']:
 source=probe/row['source_id'];proof=source/'proof.xml';assert sha(proof)==row['proof_sha256']
 diagnostic=(source/'check.stderr').read_text().strip();assert diagnostic in ['relative ADP graph child count mismatch','relative ADP main index out of range']
 run_dir=out/row['source_id'];run_dir.mkdir();checks=[]
 for i,binary in enumerate([checker,hpc]):
  prefix=run_dir/('check-'+str(i));c=execute([str(binary),str(proof)],run_dir,dict(os.environ,HPCTIXFILE=str(run_dir/'coverage.tix')),prefix,600)
  text=prefix.with_suffix('.stdout').read_text()+prefix.with_suffix('.stderr').read_text();c['semantic_rejection']=c['returncode']==1 and not c['timed_out'] and text.startswith('REJECTED') and diagnostic in text;checks.append(c)
 results.append(row|dict(expected_diagnostic=diagnostic,checks=checks,passed=all(c['semantic_rejection'] for c in checks)))
write(out/'summary.json',dict(scope='Derived graph-mode mutations, not genuine replays',results=results,passed=all(x['passed'] for x in results)))
assert all(x['passed'] for x in results)
print('Shared root graph verification passed',flush=True)
