import pathlib,json,hashlib,subprocess
r=pathlib.Path.cwd();b=r/'target/consolidation-build';f=b/'frontier-20261018';prefix='frontier-filter-20261018';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert 'Focused filter verification passed' in (f/'verify-filter.out').read_text()
assert 'Final campaign verification passed' in (f/'verify-final-campaign.out').read_text()
receipts={p.name:json.loads(p.read_text()) for p in (b/'logs').glob(prefix+'*.receipt.json')};assert receipts and all(x['returncode']==0 for x in receipts.values())
source=json.loads((f/'filter-built-source.json').read_text());assert all(sha(r/p)==s for p,s in source.items())
assert (r/'generated/Haskell/Ceta_Relative.hs').read_bytes()==(b/(prefix+'-haskell/Ceta_Relative.hs')).read_bytes()
summaries={}
for suffix in ['compact','compact-hpc-agreement','performance','supplemental','new-positives','new-negatives','campaign','full']:
 p=b/(prefix+'-'+suffix)/'summary.json';d=json.loads(p.read_text());assert d.get('passed',d.get('acceptance_passed',False));summaries[suffix]={'sha256':sha(p),**{k:v for k,v in d.items() if k not in ['results','cpu_affinity','expected_ids','certified_ids','expected_roots','certified_roots']}}
 if 'results' in d:summaries[suffix]['result_count']=len(d['results'])
report=dict(source_base=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),source_sha256=source,receipts=receipts,summaries=summaries,scope='Filtered nonminimal DP checking through the existing engine. Frozen campaign certificate rechecks, not fresh Ferrum generation.',checker_sha256=sha(b/('bin-'+prefix)/'ceta-relative'),hpc_sha256=sha(b/('bin-'+prefix)/'ceta-relative-hpc'))
out=r/'docs/consolidation/frontier-20261018/filter-verification.json';out.write_text(json.dumps(report,indent=2)+'\n')
paths=['thys/Relative_ADP/Checker/Relative_ADP_DP_Argument_Filter.thy','thys/Relative_ADP/Checker/Relative_ADP_Checker_Adapter.thy','thys/Relative_ADP/Integration/Relative_ADP_Ceta.thy','generated/Haskell/Ceta_Relative.hs',str(out.relative_to(r))]
subprocess.run(['git','diff','--check'],check=True);subprocess.run(['git','add','--',*paths],check=True);subprocess.run(['git','commit','-m','Check argument-filtered nonminimal ADP derelatification'],check=True)
commit=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip();(f/'filter-commit.json').write_text(json.dumps({'commit':commit})+'\n')
