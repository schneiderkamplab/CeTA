import pathlib,tarfile
r=pathlib.Path.cwd()
with tarfile.open(r/'docs/consolidation/frontier-20261018/sources.tar.gz') as t:
 for name in ['Relative_ADP_DP_Argument_Filter','Relative_ADP_Checker_Adapter']:
  p='thys/Relative_ADP/Checker/'+name+'.thy'
  (r/p).write_bytes(t.extractfile(p).read())
p=r/'thys/Relative_ADP/Integration/Relative_ADP_Ceta.thy';text=p.read_text().replace('xml_return (Relative_ADP_Derelatification ordinary_proof)', '''xml_return (Relative_ADP_Derelatification [] ordinary_proof)
      } XMLor XMLdo (STR ''relativeAdpFilteredDerelatification'') {
        filters \\<leftarrow> CPF_Proof_Parser.afs relative_adp_drp1_symbol_parser;
        ordinary_proof \\<leftarrow> xml2dp_termination_proof
          relative_adp_drp1_symbol_parser Mapping.empty Mapping.empty;
        xml_return (Relative_ADP_Derelatification filters ordinary_proof)''');p.write_text(text)
