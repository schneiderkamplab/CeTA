import pathlib,json,time,subprocess,os,sys,hashlib
r=pathlib.Path.cwd();b=r/'target/consolidation-build';sys.path.insert(0,str(r/'tools/consolidation'));from replay import execute,sha,write

def wait(name):
 p=b/'logs'/(name+'.receipt.json')
 while not p.exists():time.sleep(5)
 assert json.loads(p.read_text())['returncode']==0,name

def run(name,cmd,env=None):
 subprocess.run(['python3','tools/consolidation/run_logged.py','--log',str(b/'logs'/(name+'.log')),'--',*cmd],env=env,check=True)

wait('frontier-filter-20261018-relative')
checker=b/'bin-frontier-filter-20261018/ceta-relative';hpc=b/'bin-frontier-filter-20261018/ceta-relative-hpc'
run('frontier-filter-20261018-campaign',['python3','tools/consolidation/campaign_recheck.py','--manifest',str(b/'frontier-20261018/campaign/manifest.json'),'--checker',str(checker),'--output',str(b/'frontier-filter-20261018-campaign'),'--jobs','4'])
run('frontier-filter-20261018-full',['python3','tools/consolidation/recheck_entry.py','--manifest','tests/certification/replay-assets/full-replay.json','--source',str(b/'final-full-replay'),'--checker',str(checker),'--output',str(b/'frontier-filter-20261018-full'),'--jobs','4'])
print('Final campaign verification passed',flush=True)
