import pathlib,subprocess,os,time,json,hashlib
r=pathlib.Path.cwd();b=r/'target/consolidation-build';s=b/'checker-source'
receipt=b/'logs/frontier-root-20261018-relative.receipt.json'
while not receipt.exists():time.sleep(5)
assert json.loads(receipt.read_text())['returncode']==0
paths=subprocess.check_output(['git','ls-tree','-r','--name-only','8259236','--','thys/Relative_ADP'],text=True).splitlines()
for name in paths:
 p=s/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(subprocess.check_output(['git','show','8259236:'+name]))
p=s/'thys/Relative_ADP/Integration/ROOT';text=p.read_text().replace('= Relative_ADP_Checker_Dev +','= RFC_Absolute_Ext +').replace('    Proof_Checker\n    RFC_Absolute_Ext','    Relative_ADP_Checker_Dev');p.write_text(text)
env=dict(os.environ,USER_HOME=str(b/'isabelle-user'),ISABELLE_IDENTIFIER='consolidated_frontier_20261017',AFP=str(b/'afp-source/thys'))
isa='/work/dfm/festschrift/ferrum/.tools/Isabelle2025-2/bin/isabelle';dirs=sum((['-d',str(s/d)] for d in ['thys','thys/Relative_ADP','thys/RFC_Absolute_Ext']),[])
def run(name,cmd):subprocess.run(['python3',str(r/'tools/consolidation/run_logged.py'),'--log',str(b/'logs'/name),'--',*cmd],env=env,check=True)
run('frontier-parent-20261018-build.log',[isa,'build','-v','-j','2','-o','threads=8','-o','parallel_proofs=0',*dirs,'Proof_Checker','Code','RFC_Absolute_Ext','Relative_ADP_Ceta_Dev','Outermost_RZ_Ext'])
dest=b/'frontier-parent-20261018-haskell';run('frontier-parent-20261018-export.log',[isa,'export','-n',*dirs,'-O',str(dest),'-p','3','-x','Relative_ADP_Ceta_Dev.Relative_ADP_Code_Haskell:code/export1/**','Relative_ADP_Ceta_Dev'])
results=[]
for p in dest.glob('*.hs'):
 old=subprocess.check_output(['git','show','8259236:generated/Haskell/'+p.name]);new=p.read_bytes();results.append(dict(module=p.name,identical=old==new,sha256=hashlib.sha256(new).hexdigest()))
report=dict(source_base='8259236',change='Integration parent RFC_Absolute_Ext; same theory imports',modules=results,identical=bool(results) and all(x['identical'] for x in results))
(b/'frontier-20261018/parent-export-comparison.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report),flush=True)
