from pathlib import Path
import json
b=Path('target/consolidation-build');f=b/'frontier-20261018'
for n in ['relative','relative-hpc']:
 p=b/'logs'/('frontier-filter-20261018-'+n+'.receipt.json');print(n,json.loads(p.read_text())['returncode'] if p.exists() else 'running/pending')
for n in ['compact','supplemental','new-positives','new-negatives','campaign','full']:
 p=b/('frontier-filter-20261018-'+n);s=p/'summary.json'
 if s.exists():
  d=json.loads(s.read_text());print(n,d.get('passed',d.get('acceptance_passed')),len(d.get('results',[])),d.get('failures'))
 elif p.exists():print(n,'case results',len(list(p.glob('*/result.json'))))
p=f/'series-validation-prefix/summary.json'
if p.exists():
 d=json.loads(p.read_text());print('series',[(r['title'],r['passed']) for r in d['results']])
for n in ['series-validation-prefix.out','verify-filter.out','verify-final-campaign.out']:
 p=f/n;lines=p.read_text().splitlines() if p.exists() else [];print(n,lines[-1][-300:] if lines else 'pending')
