import pathlib,time,json,subprocess
r=pathlib.Path.cwd();b=r/'target/consolidation-build';receipt=b/'logs/frontier-root-20261018-relative.receipt.json'
while not receipt.exists():time.sleep(5)
assert json.loads(receipt.read_text())['returncode']==0
checker=b/'bin-frontier-root-20261018/ceta-relative'
for name,script,manifest in [('compact','suite.py','tests/certification/compact/manifest.json'),('supplemental','frontier_suite.py','tests/certification/frontier-20261017/manifest.json')]:
 subprocess.run(['python3','tools/consolidation/run_logged.py','--log',str(b/'logs'/('frontier-root-20261018-'+name+'.log')),'--','python3','tools/consolidation/'+script,'--manifest',manifest,'--checker',str(checker),'--output',str(b/('frontier-root-20261018-'+name))],check=True)
print('Root graph compatibility suites passed',flush=True)
