import pathlib,re
r=pathlib.Path.cwd();out=r/'target/consolidation-build/frontier-20261018/shared';out.mkdir(exist_ok=True)
p=r/'thys/Relative_ADP/Checker/Relative_ADP_Generic_Graph_Impl.thy';s=p.read_text().replace('imports Relative_ADP_Dependency_Graph_Dev.Relative_ADP_Dependency_Graph_Impl','imports Relative_ADP_Dependency_Graph Auxx.Gabow_SCC_RBT "Transitive-Closure-II.RTrancl"');(out/p.name).write_text(s)
old=(r/'thys/Relative_ADP/Semantics/Dependency_Graph/Relative_ADP_Dependency_Graph_Impl.thy').read_text();matches=list(re.finditer(r'^definition (\w+)',old,re.M));dependent={'relative_adp_estimated_successors'};defs=[]
for i,m in enumerate(matches):
 name=m[1];section=old[m.start():old.find('\n\n',old.index(' where',m.start()))] if ' where' in old[m.start():] else ''
 # Definition text extends through its quoted equation, until the following blank line.
 dep=any(re.search(r'\b'+re.escape(n)+r'\b',section) for n in dependent)
 if dep:dependent.add(name)
 defs.append((name,dep))
text='''theory Relative_ADP_Dependency_Graph_Impl
  imports Relative_ADP_Generic_Graph_Impl
begin

text \\<open>The original estimator is an instance of the shared executable graph
processor. Abbreviations retain the existing interface without a second implementation.\\<close>

global_interpretation baseline: relative_adp_graph_estimator relative_adp_estimated_successors
  by standard (auto intro: relative_adp_estimated_successors_bounds relative_adp_estimated_successors_sound)

'''
for name,dep in defs:
 text+=f'abbreviation {name} where\n  "{name} \\<equiv> relative_adp_graph_estimator.{name}'+(' relative_adp_estimated_successors' if dep else '')+'"\n\n'
for name,_ in defs:text+=f'lemmas {name}_def = baseline.{name}_def\n'
for name in re.findall(r'^(?:lemma|theorem) (\w+)',old,re.M):text+=f'lemmas {name} = baseline.{name}\n'
text+='\nend\n';(out/'Relative_ADP_Dependency_Graph_Impl.thy').write_text(text)
print(defs)
