import pathlib,json,time,subprocess
r=pathlib.Path.cwd();b=r/'target/consolidation-build';f=b/'frontier-20261018';p=f/'series-validation-prefix/0004/result.json'
while not p.exists():time.sleep(5)
assert not json.loads(p.read_text())['passed'],'Old split unexpectedly passes; review ordering before replacing it'
a=json.loads((f/'series-root-check/manifest.json').read_text());z=json.loads((f/'series-root-check-v2/manifest.json').read_text());assert [x['commit'] for x in a['series'][:3]]==[x['commit'] for x in z['series'][:3]]
subprocess.run(['python3','tools/consolidation/validate_feature_series.py','--manifest',str(f/'series-root-check-v2/manifest.json'),'--source',str(b/'checker-source'),'--output',str(f/'series-validation-prefix-v2'),'--isabelle','/work/dfm/festschrift/ferrum/.tools/Isabelle2025-2/bin/isabelle','--user-home',str(b/'isabelle-user'),'--identifier','consolidated_frontier_20261017','--afp',str(b/'afp-source/thys'),'--start','4','--stop','23'],check=True)
