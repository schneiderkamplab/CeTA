import pathlib,subprocess,os,shutil
r=pathlib.Path.cwd();
import time,json
receipt=r/'target/consolidation-build/frontier-20261018/parent-commit.json'
while not receipt.exists():time.sleep(5)
assert json.loads(receipt.read_text())['commit']
b=r/'target/consolidation-build';s=b/'checker-source';
(s/'thys/Relative_ADP/Checker/Relative_ADP_Generic_Graph_Impl.thy').unlink(missing_ok=True)
shutil.copy2(r/'thys/Relative_ADP/Semantics/ROOT',s/'thys/Relative_ADP/Semantics/ROOT')
shutil.copy2(r/'thys/Relative_ADP/Integration/ROOT',s/'thys/Relative_ADP/Integration/ROOT')
for p in r.glob('thys/Relative_ADP/**/*.thy'):
 if not (s/p.relative_to(r)).exists() or p.read_bytes() != (s/p.relative_to(r)).read_bytes(): shutil.copy2(p,s/p.relative_to(r))
env=dict(os.environ,USER_HOME=str(b/'isabelle-user'),ISABELLE_IDENTIFIER='consolidated_frontier_20261017',AFP=str(b/'afp-source/thys'))
isa='/work/dfm/festschrift/ferrum/.tools/Isabelle2025-2/bin/isabelle';ghc='/work/dfm/festschrift/ferrum/.tools/.ghcup/bin/ghc'
dirs=sum((['-d',str(s/d)] for d in ['thys','thys/Relative_ADP','thys/RFC_Absolute_Ext']),[])
def run(name,cmd,cwd=r):subprocess.run(['python3',str(r/'tools/consolidation/run_logged.py'),'--log',str(b/'logs'/name),'--',*cmd],cwd=cwd,env=env,check=True)
run('frontier-shared-v3-20261018-build-v3.log',[isa,'build','-v','-j','2','-o','threads=8','-o','parallel_proofs=0',*dirs,'Proof_Checker','Code','RFC_Absolute_Ext','Relative_ADP_Checker_Dev','Relative_ADP_Ceta_Dev','Outermost_RZ_Ext'])
dest=b/'frontier-shared-v3-20261018-haskell';run('frontier-shared-v3-20261018-export.log',[isa,'export','-n',*dirs,'-O',str(dest),'-p','3','-x','Relative_ADP_Ceta_Dev.Relative_ADP_Code_Haskell:code/export1/**','Relative_ADP_Ceta_Dev'])
for p in dest.glob('*.hs'):
 shutil.copy2(p,r/'generated/Haskell'/p.name);shutil.copy2(p,s/'generated/Haskell'/p.name)
shutil.copy2(r/'src/Haskell/Main_Relative_ADP.hs',dest/'Main.hs');(b/'bin-frontier-shared-v3-20261018').mkdir(exist_ok=True)
for flavor in ['relative','relative-hpc']:
 args=[ghc,'-O2','-package','array','-XRankNTypes','-odir',str(b/('ghc-frontier-shared-v3-20261018-'+flavor)),'-hidir',str(b/('ghc-frontier-shared-v3-20261018-'+flavor))]
 if flavor.endswith('hpc'):args+=['-fhpc','-hpcdir',str(b/'hpc-mix-frontier-shared-v3-20261018')]
 run('frontier-shared-v3-20261018-'+flavor+'.log',args+['--make','Main.hs','-o',str(b/'bin-frontier-shared-v3-20261018'/('ceta-'+flavor))],dest)
print('Dispatch build and export passed',flush=True)
