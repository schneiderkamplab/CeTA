import pathlib,json,gzip,hashlib,concurrent.futures,shutil
r=pathlib.Path.cwd();b=r/'target/consolidation-build/frontier-20261018';x=json.loads((b/'campaign-inventory.json').read_text());out=b/'campaign';out.mkdir(exist_ok=False)
def freeze(row):
 d=out/row['id'];d.mkdir();inp=pathlib.Path(row['input']);shutil.copyfile(inp,d/'input.ari');p=pathlib.Path(row['source']);h=hashlib.sha256()
 with p.open('rb') as src,(d/'proof.cpf.xml.gz').open('wb') as dest,gzip.GzipFile(filename='',fileobj=dest,mode='wb',mtime=0) as z:
  while chunk:=src.read(1024*1024):h.update(chunk);z.write(chunk)
 assert h.hexdigest()==row['proof_sha256']
 assert hashlib.sha256((d/'input.ari').read_bytes()).hexdigest()==row['input_sha256']
 row['compressed_sha256']=hashlib.sha256((d/'proof.cpf.xml.gz').read_bytes()).hexdigest()
 for name in ['command.json','environment.json','metadata.json']:
  f=p.parent/name
  if f.exists():shutil.copyfile(f,d/name)
 return row
with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:x['roots']=list(pool.map(freeze,x['roots']))
(out/'manifest.json').write_text(json.dumps(x,indent=2)+'\n')
# Keep every real new-criterion fixture durably; broader frozen corpus remains private.
durable=r/'tests/certification/frontier-20261018';durable.mkdir(exist_ok=False)
roots=[row for row in x['roots'] if row['new_nodes']]
for row in roots:shutil.copytree(out/row['id'],durable/row['id'])
(durable/'manifest.json').write_text(json.dumps(dict(scope='Supplemental real campaign certificates, not independently proven witness-free oracle-only generation.',roots=roots),indent=2)+'\n')
print('Frozen',len(x['roots']),'campaign proofs;',len(roots),'new-criterion proofs durable',flush=True)
