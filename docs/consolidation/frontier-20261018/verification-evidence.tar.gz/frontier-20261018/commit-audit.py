import pathlib,time,json,subprocess,hashlib,gzip
r=pathlib.Path.cwd();b=r/'target/consolidation-build/frontier-20261018';marker=b/'parent-commit.json'
while not marker.exists():time.sleep(5)
parent=json.loads(marker.read_text())['commit'];assert subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()==parent
assert subprocess.run(['git','diff','--cached','--quiet']).returncode==0
subprocess.run(['python3','tools/consolidation/test_root_audit.py'],check=True)
ident='6e6ea9f6e2102a8185147376';row=next(x for x in json.loads((b/'campaign/manifest.json').read_text())['roots'] if x['id']==ident)
fixture=pathlib.Path('tests/certification/frontier-20261018')/ident
(r/fixture/'provenance.json').write_text(json.dumps(row,indent=2)+'\n')
checks=json.loads((b/'previous-empty-weak/summary.json').read_text());assert checks['passed']
report=dict(case=row['root'],proof_sha256=row['proof_sha256'],input_sha256=row['input_sha256'],unit_test='python3 tools/consolidation/test_root_audit.py',checks=checks,scope='Audit normalization only when the original weak partition is empty. Certificate and checker semantics unchanged.',original_failure_retained='target/consolidation-build/frontier-20261018/previous-campaign/'+ident+'/result.json')
doc=pathlib.Path('docs/consolidation/frontier-20261018/empty-weak-audit.json');(r/doc).write_text(json.dumps(report,indent=2)+'\n')
subprocess.run(['git','add','--','tools/consolidation/root_audit.py','tools/consolidation/test_root_audit.py',str(fixture),str(doc)],check=True)
subprocess.run(['git','diff','--cached','--check'],check=True)
subprocess.run(['git','commit','-m','Audit relative certificates with an empty weak partition'],check=True)
commit=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip();(b/'audit-commit.json').write_text(json.dumps(dict(commit=commit),indent=2)+'\n');print(commit,flush=True)
