%query: p(i).
p(z).
p(s(X)) :- p(X).
