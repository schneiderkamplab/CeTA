theory LP_Cut_SEG_Free_Control
  imports LP_Cut_Return_Free_Check LP_Cut_SEG_Control LP_Cut_Free_Refutation
begin

definition lpc_return_free_module_rep where
  "lpc_return_free_module_rep nds states Fs ss t =
    (\<exists>swaps. lpc_return_free_rep nds states Fs (lpc_return_scope_word swaps ss) t)"

fun lpc_check_return_free_module_action where
  "lpc_check_return_free_module_action fuel P Q nds states Fs nd F ss returned arity (LPCRPrimitive action) =
    lpc_check_return_free_action fuel P Q nds states Fs nd F ss returned arity action"
| "lpc_check_return_free_module_action fuel P Q nds states Fs nd F ss returned arity (LPCRTrim successor barriers e) =
    (ss=successor@barriers \<and> lp_cut_barriers (map fst barriers) \<and>
      lpc_check_return_free_table_link fuel Q nds states Fs nd successor (lpcn_ground nd) (lpcn_guards nd) [] F e)"
| "lpc_check_return_free_module_action fuel P Q nds states Fs nd F ss returned arity (LPCRParallel links) =
    (length links=length ss \<and> list_all (\<lambda>i.
      lpc_check_return_free_table_link fuel Q nds states Fs nd [ss!i] (lpcn_ground nd) (lpcn_guards nd) [] F (links!i)) [0..<length ss])"
| "lpc_check_return_free_module_action fuel P Q nds states Fs nd F ss returned arity (LPCRRefuted i k bindings) =
    (lp_cut_check_refuted_guard fuel (lpcn_guards nd) i k bindings \<or>
      lpc_check_free_refutation fuel (lpcn_ground nd) F (lpcn_guards nd) i k)"


theorem lpc_seg_free_control_action:
  fixes P :: "('f,string) lp_cut_program"
  assumes checked: "lpc_check_return_free_module_action fuel P Q nds states Fs nd F ss returned arity action"
    and known: "lp_cut_knowledge (set (lpcn_ground nd)) (lpcn_guards nd) eta"
    and free: "lpc_free_knowledge (set F) eta"
    and lower: "\<And>vs v. ([(lpcn_pred nd,map eta (lpcn_vars nd))],v)\<in>(lp_ild Q)\<^sup>+ \<Longrightarrow>
      lpc_return_free_module_rep nds states Fs vs v \<Longrightarrow> lpc_return_contract P vs R t ret"
    and emit: "\<And>rho. ([(lpcn_pred nd,map eta (lpcn_vars nd))],[(returned,map rho [0..<arity])])\<in>(lp_ild Q)\<^sup>* \<Longrightarrow>
      (t,ret rho)\<in>R\<^sup>*"
  shows "lpc_return_contract P (lpc_return_eval eta ss) R t ret"
proof (cases action)
  case (LPCRPrimitive primitive)
  have check: "lpc_check_return_free_action fuel P Q nds states Fs nd F ss returned arity primitive"
    using checked LPCRPrimitive by simp
  show ?thesis
  proof (rule lpc_seg_primitive_contract)
    fix event tt assume step: "lpc_answer_transition P (lpc_return_eval eta ss) event tt"
    obtain u swaps where strict: "([(lpcn_pred nd,map eta (lpcn_vars nd))],u)\<in>(lp_ild Q)\<^sup>+"
      and rep: "lpc_return_free_rep nds states Fs (lpc_return_scope_word swaps tt) u"
      using lpc_return_free_action_sound[OF check known free step] by blast
    show "lpc_return_contract P tt R t ret"
      by (rule lower[OF strict]) (use rep in \<open>auto simp: lpc_return_free_module_rep_def\<close>)
  next
    fix rho tt assume step: "lpc_answer_transition P (lpc_return_eval eta ss) (Some rho) tt"
    have edge: "([(lpcn_pred nd,map eta (lpcn_vars nd))],[(returned,map rho [0..<arity])])\<in>(lp_ild Q)\<^sup>*"
      using lpc_return_free_action_sound[OF check known free step] by blast
    show "(t,ret rho)\<in>R\<^sup>*" by (rule emit[OF edge])
  qed
next
  case (LPCRTrim successor barriers e)
  have shape: "ss=successor@barriers" and barriers: "lp_cut_barriers (map fst barriers)"
    and link: "lpc_check_return_free_table_link fuel Q nds states Fs nd successor (lpcn_ground nd) (lpcn_guards nd) [] F e"
    using checked LPCRTrim by auto
  have equations: "lp_equations [] eta" by (simp add: lp_equations_def)
  obtain v swaps where strict: "([(lpcn_pred nd,map eta (lpcn_vars nd))],v)\<in>(lp_ild Q)\<^sup>+"
    and rep: "lpc_return_free_rep nds states Fs (lpc_return_scope_word swaps (lpc_return_eval eta successor)) v"
    using lpc_return_free_table_link_sound[OF link equations refl known free] by blast
  have child: "lpc_return_contract P (lpc_return_eval eta successor) R t ret"
    by (rule lower[OF strict]) (use rep in \<open>auto simp: lpc_return_free_module_rep_def\<close>)
  have suffix: "lp_cut_barriers (map fst (lpc_return_eval eta barriers))"
    using barriers by (simp add: lpc_return_eval_erases lp_cut_state_map_def list_all_iff lp_cut_barrier_entry_map)
  show ?thesis using lpc_return_contract_append_barriers[OF child suffix]
    by (simp add: shape lpc_return_eval_def)
next
  case (LPCRParallel links)
  show ?thesis
  proof (rule lpc_return_contract_singletons)
    fix e assume member: "e\<in>set (lpc_return_eval eta ss)"
    obtain i where index: "i<length ss" and e: "[e]=lpc_return_eval eta [ss!i]"
      using member by (auto simp: lpc_return_eval_def in_set_conv_nth)
    have link: "lpc_check_return_free_table_link fuel Q nds states Fs nd [ss!i] (lpcn_ground nd) (lpcn_guards nd) [] F (links!i)"
      using checked LPCRParallel index by (auto simp: list_all_iff)
    have equations: "lp_equations [] eta" by (simp add: lp_equations_def)
    obtain v swaps where strict: "([(lpcn_pred nd,map eta (lpcn_vars nd))],v)\<in>(lp_ild Q)\<^sup>+"
      and rep: "lpc_return_free_rep nds states Fs (lpc_return_scope_word swaps (lpc_return_eval eta [ss!i])) v"
      using lpc_return_free_table_link_sound[OF link equations refl known free] by blast
    show "lpc_return_contract P [e] R t ret"
      unfolding e by (rule lower[OF strict]) (use rep in \<open>auto simp: lpc_return_free_module_rep_def\<close>)
  qed
next
  case (LPCRRefuted i k bindings)
  have "lp_cut_check_refuted_guard fuel (lpcn_guards nd) i k bindings \<or>
    lpc_check_free_refutation fuel (lpcn_ground nd) F (lpcn_guards nd) i k"
    using checked LPCRRefuted by simp
  then show ?thesis using lp_cut_checked_refuted_guard[OF _ known]
    lpc_check_free_refutation_sound[OF _ known free] by blast
qed

definition lpc_seg_free_check_control where
  "lpc_seg_free_check_control fuel P Q nds states Fs returned arity actions =
    (length nds=length states \<and> length nds=length Fs \<and> length nds=length actions \<and>
     list_all (\<lambda>i. map fst (states!i)=lpcn_state (nds!i) \<and>
       (case actions!i of None \<Rightarrow> True | Some action \<Rightarrow>
         lpc_check_return_free_module_action fuel P Q nds states Fs (nds!i) (Fs!i) (states!i) returned arity action)) [0..<length nds])"

theorem lpc_seg_free_control_contract:
  fixes P :: "('f,string) lp_cut_program"
  assumes checked: "lpc_seg_free_check_control fuel P Q nds states Fs returned arity actions"
    and ranked: "lpc_seg_ranked_control rank_of Q"
    and program: "lp_cut_source_program P"
    and represented: "lpc_return_free_module_rep nds states Fs ss a"
    and boundary: "\<And>i eta. i<length nds \<Longrightarrow> actions!i=None \<Longrightarrow>
      lp_cut_knowledge (set (lpcn_ground (nds!i))) (lpcn_guards (nds!i)) eta \<Longrightarrow>
      lpc_free_knowledge (set (Fs!i)) eta \<Longrightarrow>
      (a,[(lpcn_pred (nds!i),map eta (lpcn_vars (nds!i)))])\<in>(lp_ild Q)\<^sup>* \<Longrightarrow>
      lpc_return_contract P (lpc_return_eval eta (states!i)) R t ret"
    and emit: "\<And>rho. (a,[(returned,map rho [0..<arity])])\<in>(lp_ild Q)\<^sup>* \<Longrightarrow> (t,ret rho)\<in>R\<^sup>*"
  shows "lpc_return_contract P ss R t ret"
proof -
  have sn: "SN (lp_ild Q)" by (rule lpc_seg_ranked_control_SN[OF ranked])
  have all: "\<forall>us. (a,b)\<in>(lp_ild Q)\<^sup>* \<longrightarrow>
      lpc_return_free_module_rep nds states Fs us b \<longrightarrow> lpc_return_contract P us R t ret" for b
  proof (rule SN_on_induct[OF SN_on_trancl[OF sn] UNIV_I], intro allI impI)
    fix b us
    assume ih: "\<And>c. (b,c)\<in>(lp_ild Q)\<^sup>+ \<Longrightarrow>
      \<forall>vs. (a,c)\<in>(lp_ild Q)\<^sup>* \<longrightarrow> lpc_return_free_module_rep nds states Fs vs c \<longrightarrow> lpc_return_contract P vs R t ret"
      and reached: "(a,b)\<in>(lp_ild Q)\<^sup>*"
      and rep: "lpc_return_free_module_rep nds states Fs us b"
    obtain swaps i eta where index: "i<length nds"
      and shape: "lpc_return_scope_word swaps us=lpc_return_eval eta (states!i)"
      and known: "lp_cut_knowledge (set (lpcn_ground (nds!i))) (lpcn_guards (nds!i)) eta"
      and free: "lpc_free_knowledge (set (Fs!i)) eta"
      and b: "b=[(lpcn_pred (nds!i),map eta (lpcn_vars (nds!i)))]"
      using rep by (auto simp: lpc_return_free_module_rep_def lpc_return_free_rep_def)
    have canonical: "lpc_return_contract P (lpc_return_eval eta (states!i)) R t ret"
    proof (cases "actions!i")
      case None show ?thesis by (rule boundary[OF index None known free]) (use reached b in simp)
    next
      case (Some action)
      have member: "i\<in>set [0..<length nds]" using index by simp
      have local: "case actions!i of None \<Rightarrow> True | Some action \<Rightarrow>
          lpc_check_return_free_module_action fuel P Q nds states Fs (nds!i) (Fs!i) (states!i) returned arity action"
        using checked member unfolding lpc_seg_free_check_control_def list_all_iff by blast
      have check: "lpc_check_return_free_module_action fuel P Q nds states Fs (nds!i) (Fs!i) (states!i) returned arity action"
        using local Some by simp
      show ?thesis
      proof (rule lpc_seg_free_control_action[OF check known free])
        fix vs c assume edge: "([(lpcn_pred (nds!i),map eta (lpcn_vars (nds!i)))],c)\<in>(lp_ild Q)\<^sup>+"
          and child: "lpc_return_free_module_rep nds states Fs vs c"
        have bc: "(b,c)\<in>(lp_ild Q)\<^sup>+" using edge b by simp
        have ac: "(a,c)\<in>(lp_ild Q)\<^sup>*" by (rule rtrancl_trans[OF reached trancl_into_rtrancl[OF bc]])
        show "lpc_return_contract P vs R t ret" using ih[OF bc] ac child by blast
      next
        fix rho assume edge: "([(lpcn_pred (nds!i),map eta (lpcn_vars (nds!i)))],[(returned,map rho [0..<arity])])\<in>(lp_ild Q)\<^sup>*"
        have tail: "(b,[(returned,map rho [0..<arity])])\<in>(lp_ild Q)\<^sup>*" using edge b by simp
        show "(t,ret rho)\<in>R\<^sup>*" by (rule emit[OF rtrancl_trans[OF reached tail]])
      qed
    qed
    have restored: "lpc_return_contract P (lpc_return_scope_word (rev swaps) (lpc_return_eval eta (states!i))) R t ret"
      by (rule lpc_return_contract_scopes[OF program canonical])
    show "lpc_return_contract P us R t ret" using restored by (simp add: shape[symmetric] lpc_return_scope_word_inverse)
  qed
  show ?thesis using all[of a] represented by auto
qed

end
