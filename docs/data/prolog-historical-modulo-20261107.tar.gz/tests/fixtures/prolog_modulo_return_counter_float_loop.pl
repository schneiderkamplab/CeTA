%query:count.
count :- walk(-1,_, -18014398509481984.0,0).
walk(N,R,N,R) :- !.
walk(N,R,K,C) :- K < N, relative_prime(K,N), !,
    D is C + 1, J is K + 1, walk(N,R,J,D).
walk(N,R,K,C) :- K < N, J is K + 1, walk(N,R,J,C).
relative_prime(X,Y) :- divisor(X,Y,1).
divisor(X,0,X) :- X > 0.
divisor(X,Y,G) :- Y > 0, Z is X mod Y, divisor(Y,Z,G).
