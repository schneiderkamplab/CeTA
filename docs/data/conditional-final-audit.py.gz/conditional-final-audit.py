import os,subprocess,signal,sys
from pathlib import Path
R=Path('/work/dfm/festschrift');env=dict(os.environ,USER_HOME=str(R/'CeTA/target/trs-standard/user'),ISABELLE_IDENTIFIER='trs_standard',AFP=str(R/'CeTA-consolidated/target/consolidation-build/afp-source/thys'))
cmd=[str(R/'ferrum/.tools/Isabelle2025-2/bin/isabelle'),'console','-d',str(R/'CeTA/thys'),'-d',str(R/'CeTA-consolidated/target/consolidation-build/afp-source/thys'),'-n','-l','Relative_ADP_Ceta_Dev','-d',str(R/'CeTA/thys/Category_Specifications/Conditional_Integrated'),'-i','Category_Conditional_Integrated','-o','quick_and_dirty=false','-o','threads=4','-o','parallel_proofs=0']
text='Thy_Info.use_thy_legacy "'+str(R/'CeTA/thys/Category_Specifications/Conditional_Integrated/TRS_Conditional_Operational_NO')+'";\nThy_Info.use_thy_legacy "'+str(R/'CeTA/thys/Category_Specifications/Conditional_Integrated/TRS_Conditional_Checker_Bridge')+'";\n'

with (R/'CeTA/target/conditional-review'/('console-'+sys.argv[1]+'.log')).open('w') as f:
 p=subprocess.Popen(cmd,stdin=subprocess.PIPE,text=True,env=env,stdout=f,stderr=subprocess.STDOUT,start_new_session=True)
 try: p.communicate(text,timeout=240)
 except subprocess.TimeoutExpired:
  os.killpg(p.pid,signal.SIGTERM)
  p.wait()
  raise
