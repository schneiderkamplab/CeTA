%query:walk(g,g).
walk(A,B) :- A//B>0, R is 100 mod (A//B), walk(R,B).
