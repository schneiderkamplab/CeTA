%query:main.
main :- walk(-1,-2).
walk(A,B) :- A>B, walk(B,A).
walk(A,B) :- A<B, walk(B,A).
