%query:measure(g,g,f).
measure(A,B,R) :- common(A,B,G), R is G+1.
common(A,0,A) :- !.
common(0,A,A) :- !.
common(A,B,G) :- A>=B, !, B>0, C is A mod B, common(B,C,G).
common(A,B,G) :- A<B, !, A>0, common(B,A,G).
