%query:main.
main :- exchange(0.25,0.5).
exchange(A,B) :- A < B, exchange(B,A).
