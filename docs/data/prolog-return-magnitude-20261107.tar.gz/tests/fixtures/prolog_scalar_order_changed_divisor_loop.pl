%query:main.
main :- walk(4,2).
walk(A,B) :- A//B>0, C is B//2, C>0, walk(A,C).
walk(A,1) :- walk(A,1).
