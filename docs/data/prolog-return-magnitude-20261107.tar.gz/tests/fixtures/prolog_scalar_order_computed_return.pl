%query:normalize(g,f).
normalize(pair(A,B),pair(A,B)) :- !, common(A,B,G), G=:=1.
normalize(pair(A,B),pair(X,Y)) :- !, common(A,B,G), G>1, normalize(pair(A//G,B//G),pair(U,V)), X is U, Y is V.
common(A,0,A) :- !.
common(0,A,A) :- !.
common(A,B,G) :- A>=B, !, B>0, C is A mod B, common(B,C,G).
common(A,B,G) :- A<B, !, A>0, common(B,A,G).
