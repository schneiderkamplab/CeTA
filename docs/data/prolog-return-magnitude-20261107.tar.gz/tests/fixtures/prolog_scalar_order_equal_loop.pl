%query:main.
main :- exchange(0.25,0.25).
exchange(A,B) :- A =< B, exchange(B,A).
