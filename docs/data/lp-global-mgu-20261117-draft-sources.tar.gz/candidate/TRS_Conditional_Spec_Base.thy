theory TRS_Conditional_Spec_Base
  imports TRS_Spec_Base Rewriting_Sequences_Spec
begin

text \<open>An oriented conditional rule has a left side, a right side and an
ordered list of reachability conditions. All terms, substitutions and contexts
are the shared first-order objects; no second term language is introduced.\<close>
type_synonym ('f,'v) conditional_rule =
  "(('f,'v) fo_term \<times> ('f,'v) fo_term) \<times>
    (('f,'v) fo_term \<times> ('f,'v) fo_term) list"

definition conditional_problem ::
  "'f arity \<Rightarrow> ('f,'v) conditional_rule set \<Rightarrow> bool" where
  "conditional_problem A R \<longleftrightarrow>
    finite R \<and>
    (\<forall>((l,r),cs)\<in>R. arity_correct A l \<and> arity_correct A r \<and>
      (\<forall>(s,t)\<in>set cs. arity_correct A s \<and> arity_correct A t))"

text \<open>A goal asks for one rewrite or for a finite, possibly empty sequence.
The inference rules below describe proof attempts, including unsuccessful ones.
Premises are evaluated in their displayed order.\<close>
datatype ('f,'v) conditional_goal =
    CRewrite "('f,'v) fo_term" "('f,'v) fo_term"
  | CReach "('f,'v) fo_term" "('f,'v) fo_term"

inductive conditional_inference ::
  "'f arity \<Rightarrow> ('f,'v) conditional_rule set \<Rightarrow> ('f, 'v) conditional_goal
    \<Rightarrow> ('f, 'v) conditional_goal list \<Rightarrow> bool" for A R where
  reflexive: "arity_correct A s \<Longrightarrow> conditional_inference A R (CReach s s) []"
| transitive: "arity_correct A s \<Longrightarrow> arity_correct A u \<Longrightarrow> arity_correct A t \<Longrightarrow>
    conditional_inference A R (CReach s t) [CRewrite s u, CReach u t]"
| rule: "((l,r),cs) \<in> R \<Longrightarrow> correct_context A C \<Longrightarrow>
    correct_substitution A sigma \<Longrightarrow>
    arity_correct A (fo_plug C (fo_subst sigma l)) \<Longrightarrow>
    arity_correct A (fo_plug C (fo_subst sigma r)) \<Longrightarrow>
    (\<forall>(s,t)\<in>set cs. arity_correct A (fo_subst sigma s) \<and>
      arity_correct A (fo_subst sigma t)) \<Longrightarrow>
    conditional_inference A R
      (CRewrite (fo_plug C (fo_subst sigma l))
                (fo_plug C (fo_subst sigma r)))
      (map (\<lambda>(s,t). CReach (fo_subst sigma s) (fo_subst sigma t)) cs)"

text \<open>Success requires a finite proof of every premise. This least
inductive definition cannot justify a rule by circular condition evaluation.\<close>
inductive conditional_success ::
  "'f arity \<Rightarrow> ('f,'v) conditional_rule set \<Rightarrow> ('f, 'v) conditional_goal
    \<Rightarrow> bool" for A R where
  derive: "conditional_inference A R g gs \<Longrightarrow>
    list_all (conditional_success A R) gs \<Longrightarrow> conditional_success A R g"

definition conditional_step ::
  "'f arity \<Rightarrow> ('f,'v) conditional_rule set \<Rightarrow> ('f, 'v) fo_term \<Rightarrow> ('f,
    'v) fo_term \<Rightarrow> bool" where
  "conditional_step A R s t \<longleftrightarrow> conditional_success A R (CRewrite s t)"

text \<open>An evaluation descends to a premise only after all its earlier
siblings have succeeded. The selected premise need not succeed. This records
infinite left-to-right proof attempts, not only completed rewrite steps.\<close>
definition conditional_evaluation_step ::
  "'f arity \<Rightarrow> ('f,'v) conditional_rule set \<Rightarrow> ('f, 'v) conditional_goal
    \<Rightarrow> ('f, 'v) conditional_goal \<Rightarrow> bool" where
  "conditional_evaluation_step A R g h \<longleftrightarrow>
    (\<exists>gs i. conditional_inference A R g gs \<and> i < length gs \<and>
      (\<forall>j<i. conditional_success A R (gs!j)) \<and> h = gs!i)"
end
