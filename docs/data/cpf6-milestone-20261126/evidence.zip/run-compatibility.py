import concurrent.futures, hashlib, json, subprocess, time
from pathlib import Path
root=Path('/work/dfm/festschrift/CeTA-cpf6-milestone')
base=Path('/work/dfm/festschrift/CeTA/target/cpf6-milestone')
plan=json.loads((base/'compatibility-plan.json').read_text())
checker=Path(plan['checker']);identity=hashlib.sha256(checker.read_bytes()).hexdigest()
out=base/'compatibility';out.mkdir(exist_ok=False)
(out/'pins.json').write_text(json.dumps(dict(checker_sha256=identity,plan_sha256=hashlib.sha256((base/'compatibility-plan.json').read_bytes()).hexdigest()),indent=2)+'\n')
def run(job):
 start=time.monotonic();log=out/(job['name']+'.log')
 with log.open('w') as f:
  try:
   q=subprocess.run(job['command'],cwd=root,stdout=f,stderr=subprocess.STDOUT,timeout=7200);code=q.returncode
  except subprocess.TimeoutExpired:code=124
 return dict(**job,exit=code,seconds=time.monotonic()-start,log_sha256=hashlib.sha256(log.read_bytes()).hexdigest())
rows=[]
with (out/'gates.jsonl').open('w') as f,concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:
 futures=[pool.submit(run,j) for j in plan['jobs']]
 for future in concurrent.futures.as_completed(futures):
  r=future.result();rows.append(r);f.write(json.dumps(r)+'\n');f.flush();print(r['name'],r['exit'],round(r['seconds'],1),flush=True)
stable=hashlib.sha256(checker.read_bytes()).hexdigest()==identity
summary=dict(checker_sha256=identity,stable=stable,passed=stable and all(r['exit']==0 for r in rows),gates=rows)
(out/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
assert summary['passed']
