import hashlib,json,os,shutil,sys
from pathlib import Path
r=Path('/work/dfm/festschrift');b=r/'CeTA/target/cpf6-milestone';out=b/'replay';out.mkdir(exist_ok=False);f=r/'ferrum-cpf6-milestone';old=r/'ferrum-prolog-release/target/retention-improvement-20261120'
sys.path.insert(0,str(f/'scripts/adaptive'));from resource_guard import run_guarded
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert json.loads((b/'source-regressions/summary.json').read_text())['passed']
snapshot=out/'snapshot';snapshot.mkdir();(snapshot/'bin').mkdir()
for p in (old/'snapshot').iterdir():
 if p.name!='bin':(snapshot/p.name).symlink_to(p.resolve(),target_is_directory=p.is_dir())
for name,src in [('ferrum',f/'target/release/ferrum'),('ceta',b/'pilot-unified/ceta')]:shutil.copy2(src,snapshot/'bin'/name)
roots=[d for d in json.loads((old/'other-oracle/results.json').read_text()) if d['category'] in ['Logic_Programming','Logic_Programming_with_Cut']];assert len(roots)==456
(out/'lp-roots.json').write_text(json.dumps([d['root'] for d in roots]))
pins=dict(ferrum=sha(snapshot/'bin/ferrum'),ceta=sha(snapshot/'bin/ceta'),oracle=sha(snapshot/'oracle.jsonl'))
commands=[]
for mode,oldname in [('strict','other-oracle'),('learned','other-learned-socket')]:
 cmd=[sys.executable,str(f/'scripts/adaptive/evaluate_frontier.py'),'--snapshot',str(snapshot),'--binary',str(snapshot/'bin/ferrum'),'--out',str(out/mode),'--mode','oracle' if mode=='strict' else 'only','--workers','32','--sample',str(out/'lp-roots.json'),'--settings','release' if mode=='strict' else 'competition']
 cmd+=['--policy',str(snapshot/'oracle.jsonl')] if mode=='strict' else ['--policy-package',str(old/'budget-policy-package/package.json')]
 commands.append(dict(name=mode,command=cmd,baseline=str(old/oldname/'results.json'),kind='lp'))
for mode,oldname in [('prolog-strict','prolog-oracle'),('prolog-learned','prolog-learned')]:
 baseline=json.loads((old/oldname/'results.json').read_text());expected={x['source']:x['verdict'] for x in baseline['entries'] if x['verdict']!='UNKNOWN'}
 (out/(mode+'-expected.json')).write_text(json.dumps(expected,indent=2)+'\n');(out/(mode+'-environment.json')).write_text(json.dumps(baseline['environment'],indent=2)+'\n')
 cmd=[sys.executable,str(f/'scripts/replay_prolog_source_frontier.py'),'--binary',str(snapshot/'bin/ferrum'),'--checker',str(snapshot/'bin/ceta'),'--roots',str(r/'TPDB-ARI/Prolog'),'--expected',str(out/(mode+'-expected.json')),'--output',str(out/mode),'--environment',str(out/(mode+'-environment.json')),'--seconds','60','--workers','4']
 cmd+=['--oracle',str(snapshot/'oracle.jsonl')] if mode=='prolog-strict' else ['--policy',str(old/'training/policy.json')]
 commands.append(dict(name=mode,command=cmd,baseline=str(old/oldname/'results.json'),kind='prolog'))
os.sched_setaffinity(0,sorted(os.sched_getaffinity(0))[:128]);pins.update(cpu_affinity=sorted(os.sched_getaffinity(0)),memory_bytes=800000000000)
(out/'plan.json').write_text(json.dumps(dict(pins=pins,commands=commands),indent=2)+'\n');results=[]
for job in commands:
 name=job['name'];print('START',name,flush=True)
 with (out/(name+'.stdout')).open('w') as stdout,(out/(name+'.stderr')).open('w') as stderr:resource=run_guarded(job['command'],stdout,stderr,os.environ.copy(),10800,800000000000)
 current=json.loads((out/name/'results.json').read_text());baseline=json.loads(Path(job['baseline']).read_text())
 if job['kind']=='lp':
  expected={x['root']:x for x in baseline if x['category'] in ['Logic_Programming','Logic_Programming_with_Cut']};actual={x['root']:x for x in current};assert set(expected)==set(actual)
  regressions=[k for k,v in expected.items() if v['certified'] and (not actual[k]['certified'] or actual[k]['status']!=v['status'])]
  successes=sum(x['certified'] for x in current)
  assert all(v['source_sha256']==actual[k]['source_sha256'] for k,v in expected.items())
 else:
  expected={x['source']:x for x in baseline['entries']};actual={x['source']:x for x in current['entries']};assert set(expected)==set(actual)
  regressions=[k for k,v in expected.items() if v['verdict']!='UNKNOWN' and actual[k]['verdict']!=v['verdict']];successes=sum(x['verdict']!='UNKNOWN' for x in current['entries'])
  assert baseline['sources']==current['sources']
 row=dict(name=name,roots=len(expected),certified=successes,unresolved=len(expected)-successes,regressions=regressions,resource=resource,passed=resource['code']==0 and not regressions);results.append(row)
 (out/(name+'-retention.json')).write_text(json.dumps(row,indent=2)+'\n');print('DONE',name,row['certified'],'regressions',len(regressions),flush=True)
 assert sha(snapshot/'bin/ceta')==pins['ceta'] and sha(snapshot/'bin/ferrum')==pins['ferrum']
(out/'summary.json').write_text(json.dumps(dict(passed=all(x['passed'] for x in results),modes=results,pins=pins),indent=2)+'\n')
