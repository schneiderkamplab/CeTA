import json,hashlib
from pathlib import Path
from lxml import etree as E
r=Path('/work/dfm/festschrift');b=r/'CeTA/target/cpf6-milestone';replay=b/'replay';rows=[]
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
for mode in ['strict','learned','prolog-strict','prolog-learned']:
 p=replay/mode
 if not (replay/(mode+'-retention.json')).exists():continue
 summary=json.loads((replay/(mode+'-retention.json')).read_text());assert summary['passed']
 if mode.startswith('prolog'):
  d=json.loads((p/'results.json').read_text())
  for row in d['entries']:
   root=row['source'];ok=row['verdict']!='UNKNOWN';proof=p/root.replace('/','__')/'proof.xml'
   item=dict(mode=mode,root=root,category='Prolog',source=str(r/'TPDB-ARI/Prolog'/root),source_sha256=row['source_sha256'],answer=row['verdict'].lower(),disposition='converted' if ok else 'unresolved')
   if ok:item.update(cpf=str(proof),cpf_sha256=row['report']['certificate_sha256'])
   rows.append(item)
 else:
  for file in p.glob('*/*/result.json'):
   row=json.loads(file.read_text());item=dict(mode=mode,root=row['root'],category=row['category'],source=str(r/'TPDB-ARI'/row['root']),source_sha256=row['source_sha256'],answer=row['status'],disposition='converted' if row['certified'] else 'unresolved')
   if row['certified']:
    options=[f for f in file.parent.rglob('*.xml') if sha(f)==row['certificate_sha256']];assert options
    item.update(cpf=str(options[0]),cpf_sha256=row['certificate_sha256'])
   rows.append(item)
for i,row in enumerate(rows):
 row['id']=i
 if row['disposition']=='converted':
  d=E.parse(row['cpf'],E.XMLParser(huge_tree=True));assert d.getroot().tag=='certificationProblem';row['constructor']=d.find('proof')[0].tag
(replay/'audit-inventory.json').write_text(json.dumps(rows,indent=2)+'\n');print(len(rows),'fresh mode/root entries')
