import json,hashlib,subprocess,concurrent.futures,collections
from pathlib import Path
from lxml import etree as E
r=Path('/work/dfm/festschrift');b=r/'CeTA/target/cpf6-milestone';old=r/'ferrum-prolog-release/target/retention-improvement-20261120';out=b/'retained';out.mkdir(exist_ok=True)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();rows=[]
for mode in ['other-oracle','other-learned-socket']:
 for cat in ['Logic_Programming','Logic_Programming_with_Cut']:
  for result in sorted((old/mode/cat).glob('*/result.json')):
   d=json.loads(result.read_text());item=dict(mode=mode,root=d['root'],category=cat,source=str(r/'TPDB-ARI'/d['root']),source_sha256=d['source_sha256'],certified=d['certified'],answer=d['status'])
   if d['certified']:
    options=[p for p in result.parent.rglob('*.xml') if sha(p)==d['certificate_sha256']];assert options,item
    item.update(proof=str(options[0]),proof_sha256=d['certificate_sha256'])
   rows.append(item)
for mode in ['prolog-oracle','prolog-learned']:
 d=json.loads((old/mode/'results.json').read_text())
 for row in d['entries']:
  item=dict(mode=mode,root=row['source'],category='Prolog',source=str(r/'TPDB-ARI/Prolog'/row['source']),source_sha256=row['source_sha256'],certified=row['verdict']!='UNKNOWN',answer=row['verdict'].lower())
  if item['certified']:
   p=old/mode/row['source'].replace('/','__')/'proof.xml';assert sha(p)==row['report']['certificate_sha256'];item.update(proof=str(p),proof_sha256=sha(p))
  rows.append(item)
for i,row in enumerate(rows):row['id']=i
(out/'inventory.json').write_text(json.dumps(rows,indent=2)+'\n')
codec=r/'ferrum-cpf6-milestone/target/release/examples/cpf6_lp_codec';schema=E.XMLSchema(E.parse(str(r/'CeTA-cpf6-milestone/xml/cpf6.xsd')))
def run(row):
 if not row['certified']:return dict(**row,disposition='baseline-unresolved')
 try:
  dest=out/(str(row['id'])+'.xml')
  source_doc=E.parse(row['proof'],E.XMLParser(huge_tree=True)).getroot()
  extra=[row['source']] if source_doc.tag=='prologUndefinedQueryProof' and source_doc.find('program') is None else []
  q=subprocess.run([codec,'encode',row['proof'],dest,*extra],capture_output=True,text=True,timeout=60)
  if q.returncode:raise ValueError(q.stderr)
  doc=E.parse(str(dest),E.XMLParser(huge_tree=True));schema.assertValid(doc)
  return dict(**row,disposition='converted',cpf=str(dest),cpf_sha256=sha(dest),constructor=doc.find('proof')[0].tag)
 except Exception as e:return dict(**row,disposition='failure',error=str(e))
with concurrent.futures.ThreadPoolExecutor(8) as pool:results=list(pool.map(run,rows))
(out/'results.json').write_text(json.dumps(results,indent=2)+'\n');print(collections.Counter(x['disposition'] for x in results));print(collections.Counter(x.get('constructor') for x in results))
for x in results:
 if x['disposition']=='failure':print(x['id'],x['root'],x['error'][:700])
