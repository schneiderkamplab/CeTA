import hashlib,json,zipfile,subprocess
from pathlib import Path
r=Path('/work/dfm/festschrift');root=r/'CeTA-cpf6-milestone';base=r/'CeTA/target/cpf6-milestone'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
read=lambda p:json.loads((base/p).read_text())
compat=read('compatibility/summary.json');retained=read('retained-check/summary.json');fresh=read('fresh-audit/summary.json');replay=read('replay/summary.json')
for record in [compat,retained,fresh,replay,read('focused/summary.json'),read('schema-tests/summary.json'),read('transport-result.json'),read('all-schema-determinism.json'),read('bundled-source-regressions/summary.json')]:assert record['passed']
identity=sha(base/'pilot-unified/ceta');assert identity==compat['checker_sha256']==retained['pins']['ceta']==fresh['pins']['ceta']==replay['pins']['ceta']
assert retained['entries']==fresh['entries']==1354 and retained['certified']==fresh['certified']==1274
assert retained['unresolved']==fresh['unresolved']==80
assert read('compatibility/cpf4-full-retained/summary.json')['passed']==4821
assert len(compat['gates'])==22
assert '783 passed; 0 failed; 30 ignored' in (base/'ferrum-lp-tests.log').read_text()
assert '29 passed; 0 failed' in (base/'ferrum-cpf6-tests.log').read_text()
assert '34 CPF6 LP checker cases passed' in (base/'lp-translation-tests.log').read_text()
report=dict(milestone='CeTA CPF6 support and validation',passed=True,checker_sha256=identity,ferrum_sha256=replay['pins']['ferrum'],oracle_sha256=replay['pins']['oracle'],
 distinct_inputs=677,mode_entries=1354,retained_certified=1274,fresh_certified=1274,retained_checks=2548,fresh_additional_checks=2548,unresolved_mode_entries=80,
 cpf6_proof_forms=71,additional_prolog_source_forms=15,generated_parser_groups=123,compatibility_gates=22,cpf3_cases=596,cpf4_certificates=4821,cpf4_checks=9642,cpf5_mode_certificates=2674,cpf5_checks=5348,
 source_regression_cases=397,source_regression_constructors=37,focused_gates=8,existing_schema_suites=7,codec_tests=29,lp_tests=783,lp_ignored_tests=30,translation_cases=34,modes=replay['modes'],
 scope='Existing dispatched LP/cut/Prolog source and residual forms; CPF3-5 preservation. Experimental unexported context-reference formalization excluded. LeTA deferred. No search-completeness or runtime-improvement claim.',
 caveats=['One focused context-to-ITS candidate is rejected by both the old checker on native XML and the new checker; it is not counted as certified.', 'Previously recorded numeric child CPF version labels are retained when converting historical evidence.', 'Full raw proofs and build artifacts remain local; this archive contains verification records and command/source/build pins.'])
for name in ['CeTA','ferrum']:
 tree=r/(name+'-cpf6-milestone');old=read(name+'-source-pins.json')
 for p,h in old['files'].items():
  if p.startswith('src/'):assert sha(tree/p)==h,p
 files=subprocess.check_output(['git','-C',str(tree),'diff','--name-only'],text=True).splitlines()+subprocess.check_output(['git','-C',str(tree),'ls-files','--others','--exclude-standard'],text=True).splitlines()
 record=dict(base=subprocess.check_output(['git','-C',str(tree),'rev-parse','HEAD'],text=True).strip(),tree=str(tree),files={p:sha(tree/p) for p in files if not p.startswith('docs/data/cpf6-milestone')})
 (base/(name+'-final-source-pins.json')).write_text(json.dumps(record,indent=2)+'\n')
paths={p for p in base.iterdir() if p.is_file() and p.suffix in ['.json','.jsonl','.log','.py']}
for name in ['compatibility','retained','retained-check','fresh-audit','focused','schema-tests','source-regressions','bundled-source-regressions','context-its','examples','ceta-only-cli']:
 paths.update(p for p in (base/name).rglob('*') if p.is_file() and p.suffix in ['.json','.jsonl','.log'])
paths.update(p for p in (base/'replay').iterdir() if p.is_file() and p.suffix in ['.json','.log','.stdout','.stderr'])
for mode in ['strict','learned','prolog-strict','prolog-learned']:
 for name in ['manifest.json','results.json','summary.json','environment.json']:
  p=base/'replay'/mode/name
  if p.exists():paths.add(p)
paths.add(base/'pilot-unified/build.json')
output=root/'docs/data/cpf6-milestone-20261126';output.mkdir(parents=True,exist_ok=True)
report['evidence_hashes']={str(p.relative_to(base)):sha(p) for p in sorted(paths)}
archive=output/'evidence.zip'
with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for p in sorted(paths):z.write(p,str(p.relative_to(base)))
with zipfile.ZipFile(archive) as z:assert z.testzip() is None
report.update(evidence_archive_sha256=sha(archive),archive_integrity_checked=True,archive_bytes=archive.stat().st_size)
(output/'summary.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({k:v for k,v in report.items() if k not in ['evidence_hashes','modes']},indent=2))
