import json,re
from pathlib import Path
r=Path('/work/dfm/festschrift');c=r/'CeTA-cpf6-milestone';f=r/'ferrum-cpf6-milestone'
rows=json.loads((r/'CeTA/target/cpf6-milestone/prolog-parser-fields.json').read_text());old=(c/'src/Haskell/Ceta/Input/Cpf6.hs').read_text();specs=[]
for row in rows:
 if row['root'] in old:continue
 fields=[]
 for expr in row['fields']:
  names=re.findall(r"STR ''([^']+)''",expr)
  name=names[0] if names else {'lpp_numeric_component_parser':'prologNumericComponent','lpp_transfer_contract_parser':'prologSuccessTransferContract'}[expr]
  if name in ['profile','program','predicate','modes']:continue
  if name=='core' and 'coreGoals' in names:name='core|coreGoals'
  if expr.startswith('['):name+='?'
  fields.append(name)
 specs.append(dict(root=row['root'],answer='yes' if row['root'].startswith('prologEstablished') or row['root']=='prologContextITSProof' else 'no',fields=fields,version_before_source='version' in fields,parser=row['file']))
(c/'xml/cpf6-prolog-source-forms.json').write_text(json.dumps(specs,indent=2)+'\n')
# Tables have only syntax/transport information. Generated mathematical checkers remain unchanged.
hs='\n-- Remaining source forms, in the field order of their Isabelle XML parsers.\nprologSourceSpec tag = lookup tag\n  ['+',\n   '.join('('+json.dumps(s['root'])+',('+json.dumps(s['answer'])+','+json.dumps(s['fields'])+'))' for s in specs)+']\n'
hs+='''
sourceNames [] [] = True
sourceNames [] _ = False
sourceNames (s:ss) ns =
  let optional = not (null s) && last s == '?'
      field = if optional then init s else s
      alternatives = case break (=='|') field of (a,[]) -> [a]; (a,_:b) -> [a,b]
  in case ns of
       n:rest | n `elem` alternatives -> sourceNames ss rest
       _ -> optional && sourceNames ss ns

prologSourceCertificate mode program query answer proof = do
  (expected,names) <- maybe (Left "unknown Prolog source form") Right (prologSourceSpec (label proof))
  assert (answer == expected) "Prolog source answer mismatch"
  evidence <- X.elems proof
  assert (sourceNames names (map label evidence)) "invalid Prolog source evidence fields"
  queryFields <- X.elems query
  assert (map label queryFields == ["predicate","modes"]) "invalid Prolog query"
  let (version,body) = if take 1 names == ["version"] then splitAt 1 evidence else ([],evidence)
  return (X.renderXML (X.Element (label proof) []
    ([X.Element "profile" [] [X.Text mode]] ++ version ++ [program] ++ queryFields ++ body)))
'''
old=old.replace('    if label proof == "prologUndefinedQueryProof" then','    if maybe False (const True) (prologSourceSpec (label proof)) then\n      prologSourceCertificate mode program query answer proof\n    else if label proof == "prologUndefinedQueryProof" then')
(c/'src/Haskell/Ceta/Input/Cpf6.hs').write_text(old+hs)
p=f/'src/cert/logic_programming_input.rs';s=p.read_text()
a=s.index('/// Migrate implemented outer constructors');b=s.index('pub fn encode(',a)
s=s[:a]+'''/// Export a complete CPF 6 document. Unsupported roots fail explicitly.
pub fn export_migrated(fragment: &str) -> Result<String> {
    let doc = Document::parse(fragment)?;
    if doc.root_element().has_tag_name("certificationProblem") { decode(fragment)?; return Ok(fragment.to_owned()); }
    encode(fragment)
}
'''+s[b:]
s=s.replace('    if tag == "prologEstablishedStableSEGGuardedProof" { return encode_prolog_stable_guarded(fragment, root); }','    if prolog_source_spec(tag).is_some() { return encode_prolog_source(fragment, root); }\n    if tag == "prologEstablishedStableSEGGuardedProof" { return encode_prolog_stable_guarded(fragment, root); }')
needle='    if tag == "prologEstablishedStableSEGGuardedProof" {\n        children(children(cs[4]'
pos=s.index(needle)
s=s[:pos]+'''    if let Some((answer,names)) = prolog_source_spec(tag) {
        children(children(cs[4], &[answer])?[0], &[])?;
        let evidence=source_fields(ps[0],names)?;
        let (version,body)=if names.first()==Some(&"version") { (evidence[..1].to_vec(),evidence[1..].to_vec()) } else { (vec![],evidence) };
        let raw=|nodes:Vec<Node<'_, '_>>|nodes.iter().map(|n|&cpf[n.range()]).collect::<String>();
        return Ok(format!("<{tag}><profile>{}</profile>{}{}{}{}{}</{tag}>",xml_text(&scalar(source[0])?),raw(version),&cpf[source[1].range()],&cpf[query[0].range()],&cpf[query[1].range()],raw(body)));
    }
'''+s[pos:]
s+='\nfn prolog_source_spec(tag: &str) -> Option<(&\'static str, &\'static [&\'static str])> {\n    Some(match tag {\n'+''.join('        '+json.dumps(t['root'])+' => ('+json.dumps(t['answer'])+', &'+json.dumps(t['fields'])+'),\n' for t in specs)+'        _ => return None,\n    })\n}\n'
s+='''
fn source_fields<'a,'i>(node:Node<'a,'i>,spec:&[&str]) -> Result<Vec<Node<'a,'i>>> {
    let actual:Vec<_>=node.children().filter(|n|n.is_element()).collect();
    let mut offset=0;
    for field in spec {
        let optional=field.ends_with('?');let name=field.trim_end_matches('?');
        if actual.get(offset).is_some_and(|n|name.split('|').any(|a|n.has_tag_name(a))) {offset+=1;}
        else {ensure!(optional,"missing or reordered Prolog field: {field}");}
    }
    ensure!(offset==actual.len(),"extra Prolog evidence fields");
    let names:Vec<_>=actual.iter().map(|n|n.tag_name().name()).collect();
    children(node,&names)
}
fn encode_prolog_source(fragment:&str,root:Node<'_, '_>) -> Result<String> {
    let tag=root.tag_name().name();let (answer,fields)=prolog_source_spec(tag).unwrap();
    let versioned=fields.first()==Some(&"version");
    let mut names=vec!["profile"];
    if versioned {names.push("version");}
    names.extend(["program","predicate","modes"]);
    names.extend_from_slice(if versioned {&fields[1..]} else {fields});
    let nodes=source_fields(root,&names)?;let start=if versioned {2} else {1};
    let raw=|i:usize|&fragment[nodes[i].range()];
    let mut evidence=if versioned {raw(1).to_string()} else {String::new()};
    evidence.extend(nodes[start+3..].iter().map(|n|&fragment[n.range()]));
    Ok(format!("<certificationProblem><cpfVersion>6.0</cpfVersion><lookupTables/><input><prologInput><executionProfile>{}</executionProfile>{}<query>{}{}</query></prologInput></input><property><termination/></property><answer><{answer}/></answer><proof><{tag}>{evidence}</{tag}></proof></certificationProblem>",xml_text(&scalar(nodes[0])?),raw(start),raw(start+1),raw(start+2)))
}
'''
p.write_text(s)
print('Added',len(specs),'source forms; removed silent fragment export fallback')
