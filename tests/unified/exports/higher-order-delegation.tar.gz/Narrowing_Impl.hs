{-# LANGUAGE EmptyDataDecls, RankNTypes, ScopedTypeVariables #-}

module Narrowing_Impl(narrowing_proc) where {

import Prelude ((==), (/=), (<), (<=), (>=), (>), (+), (-), (*), (/), (**),
  (>>=), (>>), (=<<), (&&), (||), (^), (^^), (.), ($), ($!), (++), (!!), Eq,
  error, id, return, not, fst, snd, map, filter, concat, concatMap, reverse,
  zip, null, takeWhile, dropWhile, all, any, Integer, negate, abs, divMod,
  String, Bool(True, False), Maybe(Nothing, Just));
import Data.Bits ((.&.), (.|.), (.^.));
import qualified Prelude;
import qualified Data.Bits;
import qualified Uint;
import qualified Array;
import qualified IArray;
import qualified Uint32;
import qualified Uint64;
import qualified Data_Bits;
import qualified Bit_Shifts;
import qualified Str_Literal;
import qualified Dependency_Graph_Impl;
import qualified Icap_Impl;
import qualified Check_Monad;
import qualified Error_Monad;
import qualified Dependency_Pair_Problem_Spec;
import qualified Sum_Type;
import qualified Compare;
import qualified Mapping;
import qualified Q_Restricted_Rewriting_Impl;
import qualified Option_Util;
import qualified HOL;
import qualified Term_Rewriting;
import qualified Arith;

qnarrows_impl ::
  forall a.
    (Eq a) => (Term_Rewriting.Term a [Arith.Char] -> Bool) ->
                Bool ->
                  [(Term_Rewriting.Term a [Arith.Char],
                     Term_Rewriting.Term a [Arith.Char])] ->
                    Term_Rewriting.Term a [Arith.Char] ->
                      [(Term_Rewriting.Term a [Arith.Char],
                         [Arith.Char] -> Term_Rewriting.Term a [Arith.Char])];
qnarrows_impl isnf nfs r t =
  concatMap
    (\ p ->
      let {
        tp = Term_Rewriting.subt_at t p;
      } in (if not (Term_Rewriting.is_Var tp)
             then concatMap
                    (\ (l, ra) ->
                      concatMap
                        (\ (mu_1, mu_2) ->
                          (if Q_Restricted_Rewriting_Impl.nF_subst_impl isnf nfs
                                (l, ra) mu_2
                            then (if all isnf
                                       (Term_Rewriting.args
 (Term_Rewriting.eval_term Term_Rewriting.Fun l mu_2))
                                   then [(Term_Rewriting.intp_actxt
    Term_Rewriting.Fun
    (Term_Rewriting.ctxt_of_pos_term p
      (Term_Rewriting.eval_term Term_Rewriting.Fun t mu_1))
    (Term_Rewriting.eval_term Term_Rewriting.Fun ra mu_2),
   mu_1)]
                                   else [])
                            else []))
                        (Option_Util.option_to_list
                          (Term_Rewriting.mgu_vd_string tp l)))
                    r
             else []))
    (Term_Rewriting.poss_list t);

narrowing_proc ::
  forall a b.
    (Compare.Compare_order b, Eq b,
      Term_Rewriting.Showl b) => Dependency_Pair_Problem_Spec.Dpp_ops_ext a b
                                   [Arith.Char] () ->
                                   (Term_Rewriting.Term b [Arith.Char],
                                     Term_Rewriting.Term b [Arith.Char]) ->
                                     [Arith.Nat] ->
                                       [(Term_Rewriting.Term b [Arith.Char],
  Term_Rewriting.Term b [Arith.Char])] ->
 a -> Sum_Type.Sum (String -> String) a;
narrowing_proc i st p sts dpp =
  (case (case st of {
          (s, t) ->
            let {
              q = Dependency_Pair_Problem_Spec.q i dpp;
            } in Error_Monad.bind
                   (Check_Monad.check
                     (Dependency_Pair_Problem_Spec.nFQ_subset_NF_rules i dpp ||
                       null q && Term_Rewriting.linear_term t)
                     (Term_Rewriting.showsl_lit
                       "innermost or full rewriting required (and linearity of t in full rewriting case)"))
                   (\ _ ->
                     let {
                       ic = Icap_Impl.icap_impl_dpp_mv i dpp;
                       isnf = Dependency_Pair_Problem_Spec.is_QNF i dpp;
                       pairs = Dependency_Pair_Problem_Spec.pairs i dpp;
                     } in Error_Monad.bind
                            (Check_Monad.check
                              (Arith.membera (Term_Rewriting.poss_list t) p)
                              (Term_Rewriting.showsl_lit
                                 "position not contained in " .
                                Term_Rewriting.showsl_terma t))
                            (\ _ ->
                              let {
                                tp = Term_Rewriting.subt_at t p;
                                nftp = isnf tp;
                              } in Error_Monad.bind
                                     (Check_Monad.check
                                       (Arith.membera
  (Term_Rewriting.poss_list (ic [s] t)) p ||
 not nftp)
                                       (Term_Rewriting.showsl_lit
 "neither is position contained in capped term of t, nor is t|_p not in Q-normal form"))
                                     (\ _ ->
                                       let {
 nfs = Dependency_Pair_Problem_Spec.nfs i dpp;
 narrows = qnarrows_impl isnf nfs (Dependency_Pair_Problem_Spec.rules i dpp) tp;
 stsa =
   filter (\ (smu, _) -> isnf smu)
     (map (\ (ta, mu) ->
            (Term_Rewriting.eval_term Term_Rewriting.Fun s mu,
              Term_Rewriting.intp_actxt Term_Rewriting.Fun
                (Term_Rewriting.ctxt_of_pos_term p
                  (Term_Rewriting.eval_term Term_Rewriting.Fun t mu))
                ta))
       narrows);
                                       } in
 Error_Monad.bind
   (Error_Monad.catch_error
     (Error_Monad.forallM
       (\ new ->
         Check_Monad.check
           (any (\ sta ->
                  Term_Rewriting.instance_rule new sta &&
                    (not nfs || (null q || Term_Rewriting.wf_rule sta)))
             sts)
           (Term_Rewriting.showsl_lit "could not find narrowed pair " .
             Term_Rewriting.showsl_rule new))
       stsa)
     (\ x -> Sum_Type.Inl (snd x)))
   (\ _ ->
     let {
       iedg = Dependency_Graph_Impl.is_iedg_edge_dpp i dpp (s, t);
     } in Error_Monad.bind
            (Error_Monad.catch_error
              (Check_Monad.check_subseteq (Term_Rewriting.vars_term_list tp)
                (Term_Rewriting.vars_term_list s))
              (\ x ->
                Sum_Type.Inl
                  ((Term_Rewriting.showsl_lit "variable " .
                     Term_Rewriting.showsl_lista x) .
                    Term_Rewriting.showsl_lit " only occurs on rhs of pair")))
            (\ _ ->
              Error_Monad.bind
                (Check_Monad.check
                  (Arith.membera (Dependency_Pair_Problem_Spec.p i dpp) st ||
                    null (Dependency_Pair_Problem_Spec.r i dpp))
                  (Term_Rewriting.showsl_lit
                    "strict DP or no strict rules required"))
                (\ _ ->
                  (if nftp
                    then Error_Monad.catch_error
                           (Error_Monad.forallM
                             (\ (u, v) ->
                               Error_Monad.bind
                                 (Check_Monad.check
                                   (Arith.membera (Term_Rewriting.poss_list u)
                                     p)
                                   (Term_Rewriting.showsl_lit
                                      "position not contained in lhs of pair " .
                                     Term_Rewriting.showsl_rule (u, v)))
                                 (\ _ ->
                                   (case Term_Rewriting.mgu_vd_string tp
   (Term_Rewriting.subt_at u p)
                                     of {
                                     Nothing -> Sum_Type.Inr ();
                                     Just (mu_1, mu_2) ->
                                       Check_Monad.check
 (not (isnf (Term_Rewriting.eval_term Term_Rewriting.Fun s mu_1)) ||
   not (isnf (Term_Rewriting.eval_term Term_Rewriting.Fun u mu_2)))
 (Term_Rewriting.showsl_lit
    "t |_ p and u |_ p unify and satisfy variable condition for pair (u,v) = " .
   Term_Rewriting.showsl_rule (u, v));
                                   })))
                             (filter (\ (u, _) -> iedg u) pairs))
                           (\ x -> Sum_Type.Inl (snd x))
                    else Sum_Type.Inr ())))))));
        })
    of {
    Sum_Type.Inl a -> Sum_Type.Inl a;
    Sum_Type.Inr _ ->
      Sum_Type.Inr (Dependency_Pair_Problem_Spec.replace_pair i dpp st sts);
  });

}
