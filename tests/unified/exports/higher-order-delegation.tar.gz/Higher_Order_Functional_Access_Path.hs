{-# LANGUAGE EmptyDataDecls, RankNTypes, ScopedTypeVariables #-}

module Higher_Order_Functional_Access_Path(ho_check_functional_access_path)
  where {

import Prelude ((==), (/=), (<), (<=), (>=), (>), (+), (-), (*), (/), (**),
  (>>=), (>>), (=<<), (&&), (||), (^), (^^), (.), ($), ($!), (++), (!!), Eq,
  error, id, return, not, fst, snd, map, filter, concat, concatMap, reverse,
  zip, null, takeWhile, dropWhile, all, any, Integer, negate, abs, divMod,
  String, Bool(True, False), Maybe(Nothing, Just));
import Data.Bits ((.&.), (.|.), (.^.));
import qualified Prelude;
import qualified Data.Bits;
import qualified Uint;
import qualified Array;
import qualified IArray;
import qualified Uint32;
import qualified Uint64;
import qualified Data_Bits;
import qualified Bit_Shifts;
import qualified Str_Literal;
import qualified Higher_Order_Candidate_Interpretation;
import qualified Higher_Order_Source_Computability;
import qualified Higher_Order_Closure_Check;
import qualified Higher_Order_Application;
import qualified Arith;
import qualified Higher_Order_Core;

ho_application_unwrap ::
  [Higher_Order_Core.Ho_type] ->
    [Higher_Order_Core.Ho_type] ->
      [([Higher_Order_Core.Ho_type],
         (Higher_Order_Core.Ho_pattern, Higher_Order_Core.Ho_pattern))] ->
        [Higher_Order_Core.Ho_type] ->
          Higher_Order_Core.Ho_term -> Maybe Higher_Order_Core.Ho_term;
ho_application_unwrap s g r d u =
  (case u of {
    Higher_Order_Core.HBound _ -> Nothing;
    Higher_Order_Core.HFree _ -> Nothing;
    Higher_Order_Core.HConst _ -> Nothing;
    Higher_Order_Core.HApp (Higher_Order_Core.HBound _) _ -> Nothing;
    Higher_Order_Core.HApp (Higher_Order_Core.HFree _) _ -> Nothing;
    Higher_Order_Core.HApp (Higher_Order_Core.HConst _) _ -> Nothing;
    Higher_Order_Core.HApp
      (Higher_Order_Core.HApp (Higher_Order_Core.HBound _) _) _
      -> Nothing;
    Higher_Order_Core.HApp
      (Higher_Order_Core.HApp (Higher_Order_Core.HFree _) _) _
      -> Nothing;
    Higher_Order_Core.HApp
      (Higher_Order_Core.HApp (Higher_Order_Core.HConst c) f) x
      -> (case Higher_Order_Core.ho_typeof s g d f of {
           Nothing -> Nothing;
           Just (Higher_Order_Core.HBase _) -> Nothing;
           Just (Higher_Order_Core.HArrow a ca) ->
             (if Higher_Order_Core.ho_typeof s g d x == Just a &&
                   Higher_Order_Core.ho_lookup s c ==
                     Just (Higher_Order_Core.HArrow
                            (Higher_Order_Core.HArrow a ca)
                            (Higher_Order_Core.HArrow a ca)) &&
                     Arith.membera r
                       (Higher_Order_Application.ho_application_rule a ca c)
               then Just (Higher_Order_Core.HApp f x) else Nothing);
         });
    Higher_Order_Core.HApp
      (Higher_Order_Core.HApp (Higher_Order_Core.HApp _ _) _) _
      -> Nothing;
    Higher_Order_Core.HApp
      (Higher_Order_Core.HApp (Higher_Order_Core.HAbs _ _) _) _
      -> Nothing;
    Higher_Order_Core.HApp (Higher_Order_Core.HAbs _ _) _ -> Nothing;
    Higher_Order_Core.HAbs _ _ -> Nothing;
  });

ho_check_functional_access_path ::
  [Higher_Order_Core.Ho_type] ->
    [Higher_Order_Core.Ho_type] ->
      [([Higher_Order_Core.Ho_type],
         (Higher_Order_Core.Ho_pattern, Higher_Order_Core.Ho_pattern))] ->
        (Arith.Nat -> Arith.Nat) ->
          Arith.Nat ->
            [Higher_Order_Core.Ho_type] ->
              Higher_Order_Core.Ho_term -> Higher_Order_Core.Ho_term -> Bool;
ho_check_functional_access_path s g r sorts fuel d t u =
  (if Arith.equal_nat fuel Arith.zero_nat
    then Higher_Order_Core.equal_ho_term t u
    else Higher_Order_Core.equal_ho_term t u ||
           (case u of {
             Higher_Order_Core.HBound _ ->
               (case ho_application_unwrap s g r d u of {
                 Nothing ->
                   (case Higher_Order_Core.ho_typeof s g d u of {
                     Nothing -> False;
                     Just (Higher_Order_Core.HBase a) ->
                       (case Higher_Order_Source_Computability.ho_application_head
                               u
                         of {
                         Higher_Order_Core.HBound _ -> False;
                         Higher_Order_Core.HFree _ -> False;
                         Higher_Order_Core.HConst _ ->
                           any (\ v ->
                                 (case Higher_Order_Core.ho_typeof s g d v of {
                                   Nothing -> False;
                                   Just ta ->
                                     Higher_Order_Candidate_Interpretation.ho_positive_type
                                       sorts (sorts a) ta &&
                                       ho_check_functional_access_path s g r
 sorts (Arith.minus_nat fuel Arith.one_nat) d t v;
                                 }))
                             (Higher_Order_Closure_Check.ho_spine_arguments u);
                         Higher_Order_Core.HApp _ _ -> False;
                         Higher_Order_Core.HAbs _ _ -> False;
                       });
                     Just (Higher_Order_Core.HArrow _ _) -> False;
                   });
                 Just a ->
                   ho_check_functional_access_path s g r sorts
                     (Arith.minus_nat fuel Arith.one_nat) d t a;
               });
             Higher_Order_Core.HFree _ ->
               (case ho_application_unwrap s g r d u of {
                 Nothing ->
                   (case Higher_Order_Core.ho_typeof s g d u of {
                     Nothing -> False;
                     Just (Higher_Order_Core.HBase a) ->
                       (case Higher_Order_Source_Computability.ho_application_head
                               u
                         of {
                         Higher_Order_Core.HBound _ -> False;
                         Higher_Order_Core.HFree _ -> False;
                         Higher_Order_Core.HConst _ ->
                           any (\ v ->
                                 (case Higher_Order_Core.ho_typeof s g d v of {
                                   Nothing -> False;
                                   Just ta ->
                                     Higher_Order_Candidate_Interpretation.ho_positive_type
                                       sorts (sorts a) ta &&
                                       ho_check_functional_access_path s g r
 sorts (Arith.minus_nat fuel Arith.one_nat) d t v;
                                 }))
                             (Higher_Order_Closure_Check.ho_spine_arguments u);
                         Higher_Order_Core.HApp _ _ -> False;
                         Higher_Order_Core.HAbs _ _ -> False;
                       });
                     Just (Higher_Order_Core.HArrow _ _) -> False;
                   });
                 Just a ->
                   ho_check_functional_access_path s g r sorts
                     (Arith.minus_nat fuel Arith.one_nat) d t a;
               });
             Higher_Order_Core.HConst _ ->
               (case ho_application_unwrap s g r d u of {
                 Nothing ->
                   (case Higher_Order_Core.ho_typeof s g d u of {
                     Nothing -> False;
                     Just (Higher_Order_Core.HBase a) ->
                       (case Higher_Order_Source_Computability.ho_application_head
                               u
                         of {
                         Higher_Order_Core.HBound _ -> False;
                         Higher_Order_Core.HFree _ -> False;
                         Higher_Order_Core.HConst _ ->
                           any (\ v ->
                                 (case Higher_Order_Core.ho_typeof s g d v of {
                                   Nothing -> False;
                                   Just ta ->
                                     Higher_Order_Candidate_Interpretation.ho_positive_type
                                       sorts (sorts a) ta &&
                                       ho_check_functional_access_path s g r
 sorts (Arith.minus_nat fuel Arith.one_nat) d t v;
                                 }))
                             (Higher_Order_Closure_Check.ho_spine_arguments u);
                         Higher_Order_Core.HApp _ _ -> False;
                         Higher_Order_Core.HAbs _ _ -> False;
                       });
                     Just (Higher_Order_Core.HArrow _ _) -> False;
                   });
                 Just a ->
                   ho_check_functional_access_path s g r sorts
                     (Arith.minus_nat fuel Arith.one_nat) d t a;
               });
             Higher_Order_Core.HApp _ _ ->
               (case ho_application_unwrap s g r d u of {
                 Nothing ->
                   (case Higher_Order_Core.ho_typeof s g d u of {
                     Nothing -> False;
                     Just (Higher_Order_Core.HBase a) ->
                       (case Higher_Order_Source_Computability.ho_application_head
                               u
                         of {
                         Higher_Order_Core.HBound _ -> False;
                         Higher_Order_Core.HFree _ -> False;
                         Higher_Order_Core.HConst _ ->
                           any (\ v ->
                                 (case Higher_Order_Core.ho_typeof s g d v of {
                                   Nothing -> False;
                                   Just ta ->
                                     Higher_Order_Candidate_Interpretation.ho_positive_type
                                       sorts (sorts a) ta &&
                                       ho_check_functional_access_path s g r
 sorts (Arith.minus_nat fuel Arith.one_nat) d t v;
                                 }))
                             (Higher_Order_Closure_Check.ho_spine_arguments u);
                         Higher_Order_Core.HApp _ _ -> False;
                         Higher_Order_Core.HAbs _ _ -> False;
                       });
                     Just (Higher_Order_Core.HArrow _ _) -> False;
                   });
                 Just a ->
                   ho_check_functional_access_path s g r sorts
                     (Arith.minus_nat fuel Arith.one_nat) d t a;
               });
             Higher_Order_Core.HAbs a v ->
               ho_check_functional_access_path s g r sorts
                 (Arith.minus_nat fuel Arith.one_nat) (a : d)
                 (Higher_Order_Core.ho_lift Arith.one_nat Arith.zero_nat t) v ||
                 (case Higher_Order_Core.ho_typeof s g d t of {
                   Nothing -> False;
                   Just (Higher_Order_Core.HBase _) -> False;
                   Just (Higher_Order_Core.HArrow ta _) ->
                     Higher_Order_Core.equal_ho_type ta a &&
                       ho_check_functional_access_path s g r sorts
                         (Arith.minus_nat fuel Arith.one_nat) (a : d)
                         (Higher_Order_Core.HApp
                           (Higher_Order_Core.ho_lift Arith.one_nat
                             Arith.zero_nat t)
                           (Higher_Order_Core.HBound Arith.zero_nat))
                         v;
                 });
           }));

}
