{-# LANGUAGE EmptyDataDecls, RankNTypes, ScopedTypeVariables #-}

module Higher_Order_Call_Comparison(ho_check_call_comparison) where {

import Prelude ((==), (/=), (<), (<=), (>=), (>), (+), (-), (*), (/), (**),
  (>>=), (>>), (=<<), (&&), (||), (^), (^^), (.), ($), ($!), (++), (!!), Eq,
  error, id, return, not, fst, snd, map, filter, concat, concatMap, reverse,
  zip, null, takeWhile, dropWhile, all, any, Integer, negate, abs, divMod,
  String, Bool(True, False), Maybe(Nothing, Just));
import Data.Bits ((.&.), (.|.), (.^.));
import qualified Prelude;
import qualified Data.Bits;
import qualified Uint;
import qualified Array;
import qualified IArray;
import qualified Uint32;
import qualified Uint64;
import qualified Data_Bits;
import qualified Bit_Shifts;
import qualified Str_Literal;
import qualified Higher_Order_Polynomial_Checker;
import qualified Higher_Order_Call_Polynomial;
import qualified Higher_Order_Full_Application;
import qualified Higher_Order_Polynomial;
import qualified Arith;
import qualified Higher_Order_Core;

ho_check_call_comparison ::
  [Higher_Order_Core.Ho_type] ->
    [Higher_Order_Polynomial.Ho_polynomial] ->
      [Higher_Order_Polynomial.Ho_polynomial] ->
        Arith.Nat ->
          [Higher_Order_Core.Ho_type] ->
            Arith.Nat ->
              [Higher_Order_Core.Ho_term] ->
                Arith.Nat -> [Higher_Order_Core.Ho_term] -> Bool -> Bool;
ho_check_call_comparison s ps ms fuel g c ls d xs strict =
  Arith.less_nat c (Arith.size_list s) &&
    Arith.less_nat d (Arith.size_list s) &&
      Arith.less_eq_nat (Arith.size_list ls)
        (Arith.size_list
          (Higher_Order_Full_Application.ho_argument_types (Arith.nth s c))) &&
        Arith.less_eq_nat (Arith.size_list xs)
          (Arith.size_list
            (Higher_Order_Full_Application.ho_argument_types
              (Arith.nth s d))) &&
          Arith.list_all2
            (\ a x -> Higher_Order_Core.ho_typeof s g [] x == Just a)
            (Arith.take (Arith.size_list ls)
              (Higher_Order_Full_Application.ho_argument_types (Arith.nth s c)))
            ls &&
            Arith.list_all2
              (\ a x -> Higher_Order_Core.ho_typeof s g [] x == Just a)
              (Arith.take (Arith.size_list xs)
                (Higher_Order_Full_Application.ho_argument_types
                  (Arith.nth s d)))
              xs &&
              Higher_Order_Core.equal_ho_type
                (Higher_Order_Full_Application.ho_drop_type (Arith.size_list ls)
                  (Arith.nth s c))
                (Higher_Order_Full_Application.ho_drop_type (Arith.size_list xs)
                  (Arith.nth s d)) &&
                (if strict
                  then Higher_Order_Polynomial_Checker.ho_check_polynomial_gt
                  else Higher_Order_Polynomial_Checker.ho_check_polynomial_ge)
                  fuel
                  g
                  (Higher_Order_Full_Application.ho_drop_type
                    (Arith.size_list ls) (Arith.nth s c))
                  (Higher_Order_Call_Polynomial.ho_call_polynomial s ps ms g c
                    ls)
                  (Higher_Order_Call_Polynomial.ho_call_polynomial s ps ms g d
                    xs);

}
