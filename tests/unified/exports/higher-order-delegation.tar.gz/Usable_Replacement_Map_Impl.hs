{-# LANGUAGE EmptyDataDecls, RankNTypes, ScopedTypeVariables #-}

module
  Usable_Replacement_Map_Impl(showsl_position_set,
                               get_innermost_strict_repl_map_dpp)
  where {

import Prelude ((==), (/=), (<), (<=), (>=), (>), (+), (-), (*), (/), (**),
  (>>=), (>>), (=<<), (&&), (||), (^), (^^), (.), ($), ($!), (++), (!!), Eq,
  error, id, return, not, fst, snd, map, filter, concat, concatMap, reverse,
  zip, null, takeWhile, dropWhile, all, any, Integer, negate, abs, divMod,
  String, Bool(True, False), Maybe(Nothing, Just));
import Data.Bits ((.&.), (.|.), (.^.));
import qualified Prelude;
import qualified Data.Bits;
import qualified Uint;
import qualified Array;
import qualified IArray;
import qualified Uint32;
import qualified Uint64;
import qualified Data_Bits;
import qualified Bit_Shifts;
import qualified Str_Literal;
import qualified Inductive_Set_Impl;
import qualified Map_Choice;
import qualified Compare_Order_Instances;
import qualified Icap_Impl;
import qualified HOL;
import qualified Dependency_Pair_Problem_Spec;
import qualified Innermost_Usable_Rules_Impl;
import qualified Sum_Type;
import qualified Compare;
import qualified Term_Rewriting;
import qualified Arith;

showsl_position_set ::
  forall a. (a, Arith.Nat) -> Arith.Set Arith.Nat -> String -> String;
showsl_position_set f s =
  Term_Rewriting.showsl_list_nat
    (concatMap (\ i -> (if Arith.member i s then [Arith.suc i] else []))
      (Arith.upt Arith.zero_nat (snd f)));

generate_impl ::
  forall a b c d.
    (Compare.Compare_order a, Eq a, Eq b,
      Eq c) => [(Term_Rewriting.Term a [Arith.Char],
                  Term_Rewriting.Term a [Arith.Char])] ->
                 (Term_Rewriting.Term a [Arith.Char] -> Bool) ->
                   ([Term_Rewriting.Term a [Arith.Char]] ->
                     Term_Rewriting.Term a [Arith.Char] ->
                       Term_Rewriting.Term a (Sum_Type.Sum () [Arith.Char])) ->
                     ([Term_Rewriting.Term a [Arith.Char]] ->
                       Term_Rewriting.Term a [Arith.Char] -> [(b, c)]) ->
                       Sum_Type.Sum
                         ([Term_Rewriting.Term a [Arith.Char]],
                           (Term_Rewriting.Term a [Arith.Char], (b, c)))
                         d ->
                         [Sum_Type.Sum
                            ([Term_Rewriting.Term a [Arith.Char]],
                              (Term_Rewriting.Term a [Arith.Char], (b, c)))
                            ((a, Arith.Nat), Arith.Nat)];
generate_impl rr nfq e_cap uu
  (Sum_Type.Inl (ss, (Term_Rewriting.Fun f ts, (l, r)))) =
  concatMap
    (\ i ->
      (if Arith.membera (uu ss (Arith.nth ts i)) (l, r)
        then map (\ u -> u)
               [Sum_Type.Inl (ss, (Arith.nth ts i, (l, r))),
                 Sum_Type.Inr ((f, Arith.size_list ts), i)]
        else []))
    (Arith.upt Arith.zero_nat (Arith.size_list ts)) ++
    concatMap
      (\ (la, ra) ->
        concatMap
          (\ mss ->
            (if Innermost_Usable_Rules_Impl.rule_match_impl nfq (e_cap mss) mss
                  f (map (Term_Rewriting.map_term (\ x -> x)
                           (\ a -> Arith.char_0x78 : a))
                      ts)
                  la
              then (if Arith.membera (uu (Term_Rewriting.args la) ra) (l, r)
                     then [Sum_Type.Inl (Term_Rewriting.args la, (ra, (l, r)))]
                     else [])
              else []))
          [map (Term_Rewriting.map_term (\ x -> x) (\ a -> Arith.char_0x78 : a))
             ss])
      rr;
generate_impl rr nfq e_cap uu (Sum_Type.Inl (va, (Term_Rewriting.Var ve, vd))) =
  [];
generate_impl rr nfq e_cap uu (Sum_Type.Inr v) = [];

all_terms_impl ::
  forall a.
    (Compare.Compare_order a,
      Eq a) => [(Term_Rewriting.Term a [Arith.Char],
                  Term_Rewriting.Term a [Arith.Char])] ->
                 [([Term_Rewriting.Term a [Arith.Char]],
                    (Term_Rewriting.Term a [Arith.Char],
                      (Term_Rewriting.Term a [Arith.Char],
                        Term_Rewriting.Term a [Arith.Char])))] ->
                   [([Term_Rewriting.Term a [Arith.Char]],
                      Term_Rewriting.Term a [Arith.Char])];
all_terms_impl rr initt =
  Arith.remdups
    (map (\ (ss, (t, _)) -> (ss, t)) initt ++
      map (\ (l, a) -> (Term_Rewriting.args l, a)) rr);

all_subterms_impl ::
  forall a.
    (Compare.Compare_order a,
      Eq a) => [(Term_Rewriting.Term a [Arith.Char],
                  Term_Rewriting.Term a [Arith.Char])] ->
                 [([Term_Rewriting.Term a [Arith.Char]],
                    (Term_Rewriting.Term a [Arith.Char],
                      (Term_Rewriting.Term a [Arith.Char],
                        Term_Rewriting.Term a [Arith.Char])))] ->
                   [([Term_Rewriting.Term a [Arith.Char]],
                      Term_Rewriting.Term a [Arith.Char])];
all_subterms_impl rr initt =
  Arith.remdups
    (concatMap
      (\ (ss, s) -> map (\ a -> (ss, a)) (Term_Rewriting.supteq_list s))
      (all_terms_impl rr initt));

everything_impl ::
  forall a.
    (Compare.Compare_order a,
      Eq a) => [(Term_Rewriting.Term a [Arith.Char],
                  Term_Rewriting.Term a [Arith.Char])] ->
                 [([Term_Rewriting.Term a [Arith.Char]],
                    (Term_Rewriting.Term a [Arith.Char],
                      (Term_Rewriting.Term a [Arith.Char],
                        Term_Rewriting.Term a [Arith.Char])))] ->
                   [Sum_Type.Sum
                      ([Term_Rewriting.Term a [Arith.Char]],
                        (Term_Rewriting.Term a [Arith.Char],
                          (Term_Rewriting.Term a [Arith.Char],
                            Term_Rewriting.Term a [Arith.Char])))
                      ((a, Arith.Nat), Arith.Nat)];
everything_impl rr initt =
  map Sum_Type.Inl
    (concatMap
      (\ (ss, t) ->
        map (\ lr -> (ss, (t, lr))) (Arith.remdups (map (snd . snd) initt)))
      (all_subterms_impl rr initt)) ++
    Arith.remdups
      (map Sum_Type.Inr
        (concatMap
          (\ t ->
            (if not (Term_Rewriting.is_Var t)
              then concatMap
                     (\ (f, ts) ->
                       map (\ a -> ((f, Arith.size_list ts), a))
                         (Arith.upt Arith.zero_nat (Arith.size_list ts)))
                     (case t of {
                       Term_Rewriting.Fun f ts -> [(f, ts)];
                     })
              else []))
          (Arith.remdups (map snd (all_subterms_impl rr initt)))));

mu_approx_impl ::
  forall a.
    (Compare.Compare_order a,
      Eq a) => [(Term_Rewriting.Term a [Arith.Char],
                  Term_Rewriting.Term a [Arith.Char])] ->
                 [([Term_Rewriting.Term a [Arith.Char]],
                    (Term_Rewriting.Term a [Arith.Char],
                      (Term_Rewriting.Term a [Arith.Char],
                        Term_Rewriting.Term a [Arith.Char])))] ->
                   ([Term_Rewriting.Term a [Arith.Char]] ->
                     Term_Rewriting.Term a [Arith.Char] ->
                       [(Term_Rewriting.Term a [Arith.Char],
                          Term_Rewriting.Term a [Arith.Char])]) ->
                     (Term_Rewriting.Term a [Arith.Char] -> Bool) ->
                       ([Term_Rewriting.Term a [Arith.Char]] ->
                         Term_Rewriting.Term a [Arith.Char] ->
                           Term_Rewriting.Term a
                             (Sum_Type.Sum () [Arith.Char])) ->
                         ([(a, Arith.Nat)],
                           ((a, Arith.Nat) -> Arith.Set Arith.Nat, String));
mu_approx_impl rr initt u_impl nfq e_cap =
  let {
    uu = Map_Choice.precompute_fun (\ (a, b) -> u_impl a b)
           (all_subterms_impl rr initt);
    uua = (\ s t -> uu (s, t));
    fis = Arith.remdups
            (concatMap (\ entry -> map (\ fi -> fi) (case entry of {
              Sum_Type.Inl _ -> [];
              Sum_Type.Inr fi -> [fi];
            }))
              (Inductive_Set_Impl.inductive_set_impl (everything_impl rr initt)
                Sum_Type.equal_sum (generate_impl rr nfq e_cap uua)
                (map Sum_Type.Inl initt)));
    fs = Arith.remdups (map fst fis);
    mu = (\ f ->
           Arith.set
             (Arith.map_filter
               (\ x -> (if (case x of {
                             (g, _) -> g == f;
                           })
                         then Just (snd x) else Nothing))
               fis));
  } in (fs, (Map_Choice.precompute_fun mu fs,
              "innermost URM wrt. specific rules"));

get_innermost_strict_repl_map_dpp ::
  forall a b.
    (Compare.Compare_order b,
      Eq b) => Dependency_Pair_Problem_Spec.Dpp_ops_ext a b [Arith.Char] () ->
                 a -> [(Term_Rewriting.Term b [Arith.Char],
                         Term_Rewriting.Term b [Arith.Char])] ->
                        ([(b, Arith.Nat)],
                          ((b, Arith.Nat) -> Arith.Set Arith.Nat, String));
get_innermost_strict_repl_map_dpp i d s =
  let {
    r = Dependency_Pair_Problem_Spec.rules i d;
    p = Dependency_Pair_Problem_Spec.pairs i d;
    isNF = Dependency_Pair_Problem_Spec.is_QNF i d;
    u = Innermost_Usable_Rules_Impl.inn_usable_rules_wf_dpp i d True;
    a = Icap_Impl.icap_impl_dpp i d;
  } in mu_approx_impl r
         (concatMap (\ (sa, t) -> map (\ lr -> ([sa], (t, lr))) s) p)
         (\ ss t -> u (ss, t)) isNF a;

}
