{-# LANGUAGE EmptyDataDecls, RankNTypes, ScopedTypeVariables #-}

module Check_Joins(Crit_pair_info(..), Cp_join_hints(..), is_rsteps_join_one)
  where {

import Prelude ((==), (/=), (<), (<=), (>=), (>), (+), (-), (*), (/), (**),
  (>>=), (>>), (=<<), (&&), (||), (^), (^^), (.), ($), ($!), (++), (!!), Eq,
  error, id, return, not, fst, snd, map, filter, concat, concatMap, reverse,
  zip, null, takeWhile, dropWhile, all, any, Integer, negate, abs, divMod,
  String, Bool(True, False), Maybe(Nothing, Just));
import Data.Bits ((.&.), (.|.), (.^.));
import qualified Prelude;
import qualified Data.Bits;
import qualified Uint;
import qualified Array;
import qualified IArray;
import qualified Uint32;
import qualified Uint64;
import qualified Data_Bits;
import qualified Bit_Shifts;
import qualified Str_Literal;
import qualified Rewrite_Relations_Impl;
import qualified Error_Monad;
import qualified Compare;
import qualified Mapping;
import qualified Check_Monad;
import qualified HOL;
import qualified Sum_Type;
import qualified Term_Rewriting;
import qualified Arith;

data Crit_pair_info a b =
  Crit_Pair_Info (Term_Rewriting.Term a b) (Maybe (Term_Rewriting.Term a b))
    (Term_Rewriting.Term a b) [Term_Rewriting.Term a b] (Maybe [[Arith.Nat]])
    (Maybe (Arith.Nat, Arith.Nat));

data Cp_join_hints a b = CP_Auto Arith.Nat | CP_Sequences [Crit_pair_info a b];

check_steps ::
  forall a b.
    (Eq a,
      Eq b) => (Term_Rewriting.Term a b -> Term_Rewriting.Term a b -> Bool) ->
                 Term_Rewriting.Term a b ->
                   [Term_Rewriting.Term a b] ->
                     Term_Rewriting.Term a b ->
                       (Term_Rewriting.Term a b, [Term_Rewriting.Term a b]);
check_steps f s [] u = (if f s u then (u, []) else (s, []));
check_steps f s (t : ts) u =
  (if Term_Rewriting.equal_term s t || f s t then check_steps f t ts u
    else (s, t : ts));

finalize_steps ::
  forall a.
    (Eq a,
      Term_Rewriting.Showl a) => a -> [a] ->
a -> Sum_Type.Sum (String -> String) ();
finalize_steps x xs y =
  Check_Monad.check (x == y)
    (let {
       z = (case xs of {
             [] -> y;
             z : _ -> z;
           });
     } in (((Term_Rewriting.showsl_lit "got stuck at step from " .
              Term_Rewriting.showsl x) .
             Term_Rewriting.showsl_lit " to ") .
            Term_Rewriting.showsl z) .
            Term_Rewriting.showsl_literal "\n");

is_rsteps_join ::
  forall a b.
    (Eq a, Arith.Ccompare b, Eq b,
      Mapping.Mapping_impl b) => [(Term_Rewriting.Term a b,
                                    Term_Rewriting.Term a b)] ->
                                   [(Term_Rewriting.Term a b,
                                      Term_Rewriting.Term a b)] ->
                                     Arith.Nat ->
                                       Term_Rewriting.Term a b ->
 Term_Rewriting.Term a b -> Bool;
is_rsteps_join r sa n s t =
  let {
    ss = Term_Rewriting.reachable_terms sa t n;
  } in any (Arith.membera ss) (Term_Rewriting.reachable_terms r s n);

cp_right :: forall a b. Crit_pair_info a b -> Term_Rewriting.Term a b;
cp_right (Crit_Pair_Info x1 x2 x3 x4 x5 x6) = x3;

cp_left :: forall a b. Crit_pair_info a b -> Term_Rewriting.Term a b;
cp_left (Crit_Pair_Info x1 x2 x3 x4 x5 x6) = x1;

cp_join :: forall a b. Crit_pair_info a b -> [Term_Rewriting.Term a b];
cp_join (Crit_Pair_Info x1 x2 x3 x4 x5 x6) = x4;

check_join_sequence ::
  forall a b.
    (Compare.Compare a, Eq a, Term_Rewriting.Showl a, Arith.Ccompare b,
      Compare.Compare b, Eq b, Mapping.Mapping_impl b,
      Term_Rewriting.Showl b) => [(Term_Rewriting.Term a b,
                                    Term_Rewriting.Term a b)] ->
                                   [(Term_Rewriting.Term a b,
                                      Term_Rewriting.Term a b)] ->
                                     Term_Rewriting.Term a b ->
                                       Term_Rewriting.Term a b ->
 [Term_Rewriting.Term a b] -> Sum_Type.Sum (String -> String) ();
check_join_sequence r sa s t terms =
  (case check_steps (Rewrite_Relations_Impl.is_par_rstep r) s terms t of {
    (x, xs) ->
      (case check_steps
              (\ sb ta -> Rewrite_Relations_Impl.is_par_rstep sa ta sb) x xs t
        of {
        (y, ys) ->
          Error_Monad.catch_error (finalize_steps y ys t)
            (\ xa ->
              Sum_Type.Inl
                (((((Term_Rewriting.showsl_lit "could not ensure " .
                      Term_Rewriting.showsl_terma s) .
                     Term_Rewriting.showsl_lit " ->* . *<- ") .
                    Term_Rewriting.showsl_terma t) .
                   Term_Rewriting.showsl_literal "\n") .
                  xa));
      });
  });

is_rsteps_join_one ::
  forall a b.
    (Compare.Compare a, Eq a, Term_Rewriting.Showl a, Arith.Ccompare b,
      Compare.Compare b, Eq b, Mapping.Mapping_impl b,
      Term_Rewriting.Showl b) => [(Term_Rewriting.Term a b,
                                    Term_Rewriting.Term a b)] ->
                                   Cp_join_hints a b ->
                                     Sum_Type.Sum (String -> String)
                                       ((Term_Rewriting.Term a b,
  Term_Rewriting.Term a b) ->
 Sum_Type.Sum (String -> String) ());
is_rsteps_join_one r (CP_Auto n) =
  Sum_Type.Inr
    (\ (s, t) ->
      Check_Monad.check (is_rsteps_join r r n s t)
        (((((Term_Rewriting.showsl_nat n .
              Term_Rewriting.showsl_lit
                " steps do not suffice to show joinability of ") .
             Term_Rewriting.showsl_terma s) .
            Term_Rewriting.showsl_lit " and ") .
           Term_Rewriting.showsl_terma t) .
          Term_Rewriting.showsl_literal "\n"));
is_rsteps_join_one r (CP_Sequences cp_infos) =
  Error_Monad.bind
    (Error_Monad.catch_error
      (Error_Monad.catch_error
        (Error_Monad.forallM
          (\ cp ->
            check_join_sequence r r (cp_left cp) (cp_right cp) (cp_join cp))
          cp_infos)
        (\ x -> Sum_Type.Inl (snd x)))
      (\ x ->
        Sum_Type.Inl
          ((x . Term_Rewriting.showsl_lit "\nunderlying TRS:\n") .
            Term_Rewriting.showsl_rules r)))
    (\ _ ->
      Sum_Type.Inr
        (\ (s, t) ->
          Check_Monad.check
            (Term_Rewriting.equal_term s t ||
              any (\ cp ->
                    Term_Rewriting.instance_rule (s, t)
                      (cp_left cp, cp_right cp) ||
                      Term_Rewriting.instance_rule (s, t)
                        (cp_right cp, cp_left cp))
                cp_infos)
            ((((Term_Rewriting.showsl_literal
                  " could not find joining sequence for " .
                 Term_Rewriting.showsl_terma s) .
                Term_Rewriting.showsl_lit " and ") .
               Term_Rewriting.showsl_terma t) .
              Term_Rewriting.showsl_literal "\n")));

}
