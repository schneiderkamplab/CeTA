{-# LANGUAGE EmptyDataDecls, RankNTypes, ScopedTypeVariables #-}

module
  Higher_Order_Polynomial_Checker(ho_check_polynomial_ge,
                                   ho_check_polynomial_gt)
  where {

import Prelude ((==), (/=), (<), (<=), (>=), (>), (+), (-), (*), (/), (**),
  (>>=), (>>), (=<<), (&&), (||), (^), (^^), (.), ($), ($!), (++), (!!), Eq,
  error, id, return, not, fst, snd, map, filter, concat, concatMap, reverse,
  zip, null, takeWhile, dropWhile, all, any, Integer, negate, abs, divMod,
  String, Bool(True, False), Maybe(Nothing, Just));
import Data.Bits ((.&.), (.|.), (.^.));
import qualified Prelude;
import qualified Data.Bits;
import qualified Uint;
import qualified Array;
import qualified IArray;
import qualified Uint32;
import qualified Uint64;
import qualified Data_Bits;
import qualified Bit_Shifts;
import qualified Str_Literal;
import qualified Higher_Order_Polynomial_Comparison;
import qualified Higher_Order_Polynomial_Dominance;
import qualified Higher_Order_Polynomial_Normalization;
import qualified Higher_Order_Polynomial;
import qualified Higher_Order_Core;
import qualified Arith;

ho_check_polynomial_ge ::
  Arith.Nat ->
    [Higher_Order_Core.Ho_type] ->
      Higher_Order_Core.Ho_type ->
        Higher_Order_Polynomial.Ho_polynomial ->
          Higher_Order_Polynomial.Ho_polynomial -> Bool;
ho_check_polynomial_ge fuel g (Higher_Order_Core.HBase b) p q =
  Higher_Order_Polynomial_Comparison.ho_check_base_polynomial_ge g b
    (Higher_Order_Polynomial_Normalization.ho_polynomial_normalize fuel p)
    (Higher_Order_Polynomial_Normalization.ho_polynomial_normalize fuel q) ||
    Higher_Order_Polynomial_Dominance.ho_check_monotone_base_ge g b
      (Higher_Order_Polynomial_Normalization.ho_polynomial_normalize fuel p)
      (Higher_Order_Polynomial_Normalization.ho_polynomial_normalize fuel q);
ho_check_polynomial_ge fuel g (Higher_Order_Core.HArrow a b) p q =
  ho_check_polynomial_ge fuel (a : g) b
    (Higher_Order_Polynomial.HPApply a b
      (Higher_Order_Polynomial_Normalization.ho_polynomial_rename Arith.suc p)
      (Higher_Order_Polynomial.HPVar Arith.zero_nat))
    (Higher_Order_Polynomial.HPApply a b
      (Higher_Order_Polynomial_Normalization.ho_polynomial_rename Arith.suc q)
      (Higher_Order_Polynomial.HPVar Arith.zero_nat));

ho_check_polynomial_gt ::
  Arith.Nat ->
    [Higher_Order_Core.Ho_type] ->
      Higher_Order_Core.Ho_type ->
        Higher_Order_Polynomial.Ho_polynomial ->
          Higher_Order_Polynomial.Ho_polynomial -> Bool;
ho_check_polynomial_gt fuel g (Higher_Order_Core.HBase b) p q =
  Higher_Order_Polynomial_Comparison.ho_check_base_polynomial_gt g b
    (Higher_Order_Polynomial_Normalization.ho_polynomial_normalize fuel p)
    (Higher_Order_Polynomial_Normalization.ho_polynomial_normalize fuel q) ||
    Higher_Order_Polynomial_Dominance.ho_check_monotone_base_gt g b
      (Higher_Order_Polynomial_Normalization.ho_polynomial_normalize fuel p)
      (Higher_Order_Polynomial_Normalization.ho_polynomial_normalize fuel q);
ho_check_polynomial_gt fuel g (Higher_Order_Core.HArrow a b) p q =
  ho_check_polynomial_gt fuel (a : g) b
    (Higher_Order_Polynomial.HPApply a b
      (Higher_Order_Polynomial_Normalization.ho_polynomial_rename Arith.suc p)
      (Higher_Order_Polynomial.HPVar Arith.zero_nat))
    (Higher_Order_Polynomial.HPApply a b
      (Higher_Order_Polynomial_Normalization.ho_polynomial_rename Arith.suc q)
      (Higher_Order_Polynomial.HPVar Arith.zero_nat));

}
