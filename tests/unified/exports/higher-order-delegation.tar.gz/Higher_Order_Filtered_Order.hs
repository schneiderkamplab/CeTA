{-# LANGUAGE EmptyDataDecls, RankNTypes, ScopedTypeVariables #-}

module Higher_Order_Filtered_Order(ho_filtered_less) where {

import Prelude ((==), (/=), (<), (<=), (>=), (>), (+), (-), (*), (/), (**),
  (>>=), (>>), (=<<), (&&), (||), (^), (^^), (.), ($), ($!), (++), (!!), Eq,
  error, id, return, not, fst, snd, map, filter, concat, concatMap, reverse,
  zip, null, takeWhile, dropWhile, all, any, Integer, negate, abs, divMod,
  String, Bool(True, False), Maybe(Nothing, Just));
import Data.Bits ((.&.), (.|.), (.^.));
import qualified Prelude;
import qualified Data.Bits;
import qualified Uint;
import qualified Array;
import qualified IArray;
import qualified Uint32;
import qualified Uint64;
import qualified Data_Bits;
import qualified Bit_Shifts;
import qualified Str_Literal;
import qualified Higher_Order_Priority_Order;
import qualified Higher_Order_Syntactic_Descent;
import qualified Arith;
import qualified Quasi_Order;
import qualified Higher_Order_Core;

ho_selected_arguments :: forall a. [Arith.Nat] -> [a] -> [a];
ho_selected_arguments indices xs =
  Arith.map_filter
    (\ x ->
      (if Arith.less_nat x (Arith.size_list xs) then Just (Arith.nth xs x)
        else Nothing))
    indices;

ho_filtered_less ::
  forall a b.
    (Eq b,
      Quasi_Order.Ord b) => (Arith.Nat -> Arith.Nat) ->
                              (a -> [Arith.Nat]) ->
                                (a -> b) ->
                                  a -> [Higher_Order_Core.Ho_term] ->
 a -> [Higher_Order_Core.Ho_term] -> Bool;
ho_filtered_less priority select phase d ys c xs =
  Higher_Order_Syntactic_Descent.ho_lex_subterm
    (ho_selected_arguments (select d) ys)
    (ho_selected_arguments (select c) xs) ||
    ho_selected_arguments (select d) ys ==
      ho_selected_arguments (select c) xs &&
      (Quasi_Order.less (phase d) (phase c) ||
        phase d == phase c &&
          Higher_Order_Syntactic_Descent.ho_lex_subterm
            (Higher_Order_Priority_Order.ho_priority_arguments priority ys)
            (Higher_Order_Priority_Order.ho_priority_arguments priority xs));

}
