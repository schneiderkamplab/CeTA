{-# LANGUAGE EmptyDataDecls, RankNTypes, ScopedTypeVariables #-}

module
  Higher_Order_Call_Polynomial(ho_call_polynomial,
                                ho_check_weak_polynomial_rule)
  where {

import Prelude ((==), (/=), (<), (<=), (>=), (>), (+), (-), (*), (/), (**),
  (>>=), (>>), (=<<), (&&), (||), (^), (^^), (.), ($), ($!), (++), (!!), Eq,
  error, id, return, not, fst, snd, map, filter, concat, concatMap, reverse,
  zip, null, takeWhile, dropWhile, all, any, Integer, negate, abs, divMod,
  String, Bool(True, False), Maybe(Nothing, Just));
import Data.Bits ((.&.), (.|.), (.^.));
import qualified Prelude;
import qualified Data.Bits;
import qualified Uint;
import qualified Array;
import qualified IArray;
import qualified Uint32;
import qualified Uint64;
import qualified Data_Bits;
import qualified Bit_Shifts;
import qualified Str_Literal;
import qualified Higher_Order_Polynomial_Checker;
import qualified Higher_Order_Weak_Polynomial;
import qualified Higher_Order_Expression_Bridge;
import qualified Higher_Order_Interpretation;
import qualified Higher_Order_Polynomial;
import qualified Higher_Order_Core;
import qualified Arith;

ho_polynomial_apply_list ::
  Higher_Order_Core.Ho_type ->
    Higher_Order_Polynomial.Ho_polynomial ->
      [Higher_Order_Polynomial.Ho_polynomial] ->
        Higher_Order_Polynomial.Ho_polynomial;
ho_polynomial_apply_list a p [] = p;
ho_polynomial_apply_list (Higher_Order_Core.HArrow a c) p (q : qs) =
  ho_polynomial_apply_list c (Higher_Order_Polynomial.HPApply a c p q) qs;
ho_polynomial_apply_list (Higher_Order_Core.HBase b) p (q : qs) =
  Higher_Order_Polynomial.HPNumber b Arith.zero_nat;

ho_call_polynomial ::
  [Higher_Order_Core.Ho_type] ->
    [Higher_Order_Polynomial.Ho_polynomial] ->
      [Higher_Order_Polynomial.Ho_polynomial] ->
        [Higher_Order_Core.Ho_type] ->
          Arith.Nat ->
            [Higher_Order_Core.Ho_term] ->
              Higher_Order_Polynomial.Ho_polynomial;
ho_call_polynomial s ps ms g c xs =
  ho_polynomial_apply_list (Arith.nth s c) (Arith.nth ms c)
    (map (\ x ->
           Higher_Order_Weak_Polynomial.ho_weak_polynomial_translate ps
             (Higher_Order_Expression_Bridge.ho_compile s g [] x))
      xs);

ho_check_weak_polynomial_rule ::
  [Higher_Order_Core.Ho_type] ->
    [Higher_Order_Polynomial.Ho_polynomial] ->
      Arith.Nat ->
        [Higher_Order_Core.Ho_type] ->
          Higher_Order_Core.Ho_pattern -> Higher_Order_Core.Ho_pattern -> Bool;
ho_check_weak_polynomial_rule s ps fuel g l r =
  (case Higher_Order_Core.ho_typeof s g []
          (Higher_Order_Core.ho_erase_pattern l)
    of {
    Nothing -> False;
    Just a ->
      Higher_Order_Core.ho_typeof s g []
        (Higher_Order_Core.ho_erase_pattern r) ==
        Just a &&
        Higher_Order_Polynomial_Checker.ho_check_polynomial_ge fuel g a
          (Higher_Order_Weak_Polynomial.ho_weak_polynomial_translate ps
            (Higher_Order_Expression_Bridge.ho_compile s g []
              (Higher_Order_Core.ho_erase_pattern l)))
          (Higher_Order_Weak_Polynomial.ho_weak_polynomial_translate ps
            (Higher_Order_Expression_Bridge.ho_compile s g []
              (Higher_Order_Core.ho_erase_pattern r)));
  });

}
