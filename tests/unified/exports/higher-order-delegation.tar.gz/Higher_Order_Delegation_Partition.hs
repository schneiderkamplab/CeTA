{-# LANGUAGE EmptyDataDecls, RankNTypes, ScopedTypeVariables #-}

module Higher_Order_Delegation_Partition(ho_partition_rule) where {

import Prelude ((==), (/=), (<), (<=), (>=), (>), (+), (-), (*), (/), (**),
  (>>=), (>>), (=<<), (&&), (||), (^), (^^), (.), ($), ($!), (++), (!!), Eq,
  error, id, return, not, fst, snd, map, filter, concat, concatMap, reverse,
  zip, null, takeWhile, dropWhile, all, any, Integer, negate, abs, divMod,
  String, Bool(True, False), Maybe(Nothing, Just));
import Data.Bits ((.&.), (.|.), (.^.));
import qualified Prelude;
import qualified Data.Bits;
import qualified Uint;
import qualified Array;
import qualified IArray;
import qualified Uint32;
import qualified Uint64;
import qualified Data_Bits;
import qualified Bit_Shifts;
import qualified Str_Literal;
import qualified Higher_Order_Source_Computability;
import qualified Higher_Order_Saturated_Neutral;
import qualified Higher_Order_Algebraic_Embedding;
import qualified Higher_Order_Core;
import qualified Arith;

ho_decode_fo_pattern ::
  Higher_Order_Core.Ho_pattern ->
    Maybe Higher_Order_Algebraic_Embedding.Ho_fo_tree;
ho_decode_fo_pattern (Higher_Order_Core.PMeta n xs) =
  (if null xs then Just (Higher_Order_Algebraic_Embedding.HFOVar n)
    else Nothing);
ho_decode_fo_pattern (Higher_Order_Core.PConst c) =
  Just (Higher_Order_Algebraic_Embedding.HFOFun c []);
ho_decode_fo_pattern (Higher_Order_Core.PApp p q) =
  (case ho_decode_fo_pattern p of {
    Nothing -> Nothing;
    Just (Higher_Order_Algebraic_Embedding.HFOVar _) -> Nothing;
    Just (Higher_Order_Algebraic_Embedding.HFOFun c xs) ->
      Arith.map_option
        (\ y -> Higher_Order_Algebraic_Embedding.HFOFun c (xs ++ [y]))
        (ho_decode_fo_pattern q);
  });
ho_decode_fo_pattern (Higher_Order_Core.PBound v) = Nothing;
ho_decode_fo_pattern (Higher_Order_Core.PAbs v va) = Nothing;

ho_check_fo_rule ::
  forall a.
    Arith.Set Arith.Nat ->
      (Arith.Nat -> Arith.Nat) ->
        (a, (Higher_Order_Core.Ho_pattern, Higher_Order_Core.Ho_pattern)) ->
          Maybe (Higher_Order_Algebraic_Embedding.Ho_fo_tree,
                  Higher_Order_Algebraic_Embedding.Ho_fo_tree);
ho_check_fo_rule f arity rule =
  (case rule of {
    (_, (l, r)) ->
      (case (ho_decode_fo_pattern l, ho_decode_fo_pattern r) of {
        (Nothing, _) -> Nothing;
        (Just _, Nothing) -> Nothing;
        (Just p, Just q) ->
          (if Higher_Order_Algebraic_Embedding.ho_fo_wellformed f arity p &&
                Higher_Order_Algebraic_Embedding.ho_fo_wellformed f arity q &&
                  Arith.less_eq_set
                    (Higher_Order_Algebraic_Embedding.ho_fo_variables q)
                    (Higher_Order_Algebraic_Embedding.ho_fo_variables p)
            then Just (p, q) else Nothing);
      });
  });

ho_partition_rule ::
  forall a.
    Arith.Set Arith.Nat ->
      (Arith.Nat -> Arith.Nat) ->
        Arith.Set
          (Higher_Order_Algebraic_Embedding.Ho_fo_tree,
            Higher_Order_Algebraic_Embedding.Ho_fo_tree) ->
          (a, (Higher_Order_Core.Ho_pattern, Higher_Order_Core.Ho_pattern)) ->
            Bool;
ho_partition_rule f arity p rule =
  (case rule of {
    (_, (l, _)) ->
      (case Higher_Order_Source_Computability.ho_application_head
              (Higher_Order_Core.ho_erase_pattern l)
        of {
        Higher_Order_Core.HBound _ -> False;
        Higher_Order_Core.HFree _ -> False;
        Higher_Order_Core.HConst c ->
          Arith.equal_nat
            (Higher_Order_Saturated_Neutral.ho_spine_length
              (Higher_Order_Core.ho_erase_pattern l))
            (arity c) &&
            (if Arith.member c f then (case ho_check_fo_rule f arity rule of {
Nothing -> False;
Just pq -> Arith.member pq p;
                                      })
              else True);
        Higher_Order_Core.HApp _ _ -> False;
        Higher_Order_Core.HAbs _ _ -> False;
      });
  });

}
