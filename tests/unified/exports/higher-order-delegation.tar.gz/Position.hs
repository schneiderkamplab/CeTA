{-# LANGUAGE EmptyDataDecls, RankNTypes, ScopedTypeVariables #-}

module Position(showsl_pos) where {

import Prelude ((==), (/=), (<), (<=), (>=), (>), (+), (-), (*), (/), (**),
  (>>=), (>>), (=<<), (&&), (||), (^), (^^), (.), ($), ($!), (++), (!!), Eq,
  error, id, return, not, fst, snd, map, filter, concat, concatMap, reverse,
  zip, null, takeWhile, dropWhile, all, any, Integer, negate, abs, divMod,
  String, Bool(True, False), Maybe(Nothing, Just));
import Data.Bits ((.&.), (.|.), (.^.));
import qualified Prelude;
import qualified Data.Bits;
import qualified Uint;
import qualified Array;
import qualified IArray;
import qualified Uint32;
import qualified Uint64;
import qualified Data_Bits;
import qualified Bit_Shifts;
import qualified Str_Literal;
import qualified Term_Rewriting;
import qualified Arith;

showsl_pos :: [Arith.Nat] -> String -> String;
showsl_pos =
  Term_Rewriting.showsl_list_gen
    (\ i -> Term_Rewriting.showsl_nat (Arith.suc i)) "empty" "" "." "";

}
