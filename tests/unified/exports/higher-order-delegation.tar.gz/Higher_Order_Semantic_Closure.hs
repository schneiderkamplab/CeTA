{-# LANGUAGE EmptyDataDecls, RankNTypes, ScopedTypeVariables #-}

module Higher_Order_Semantic_Closure(ho_check_semantic_closure) where {

import Prelude ((==), (/=), (<), (<=), (>=), (>), (+), (-), (*), (/), (**),
  (>>=), (>>), (=<<), (&&), (||), (^), (^^), (.), ($), ($!), (++), (!!), Eq,
  error, id, return, not, fst, snd, map, filter, concat, concatMap, reverse,
  zip, null, takeWhile, dropWhile, all, any, Integer, negate, abs, divMod,
  String, Bool(True, False), Maybe(Nothing, Just));
import Data.Bits ((.&.), (.|.), (.^.));
import qualified Prelude;
import qualified Data.Bits;
import qualified Uint;
import qualified Array;
import qualified IArray;
import qualified Uint32;
import qualified Uint64;
import qualified Data_Bits;
import qualified Bit_Shifts;
import qualified Str_Literal;
import qualified Higher_Order_Source_Computability;
import qualified Higher_Order_Call_Comparison;
import qualified Higher_Order_Accessible_Closure;
import qualified Higher_Order_Priority_Order;
import qualified Higher_Order_Syntactic_Descent;
import qualified Higher_Order_Closure_Check;
import qualified Higher_Order_Full_Application;
import qualified Higher_Order_Polynomial;
import qualified Arith;
import qualified Higher_Order_Core;

ho_semantic_closure_step ::
  [Higher_Order_Core.Ho_type] ->
    [Higher_Order_Core.Ho_type] ->
      (Arith.Nat -> Arith.Nat) ->
        [Higher_Order_Polynomial.Ho_polynomial] ->
          [Higher_Order_Polynomial.Ho_polynomial] ->
            Arith.Nat ->
              (Arith.Nat -> Arith.Nat) ->
                (Arith.Nat -> Arith.Nat) ->
                  (Arith.Nat -> Arith.Nat) ->
                    Arith.Nat ->
                      [Higher_Order_Core.Ho_term] ->
                        ([Higher_Order_Core.Ho_type] ->
                          Higher_Order_Core.Ho_term -> Bool) ->
                          [Higher_Order_Core.Ho_type] ->
                            Higher_Order_Core.Ho_term -> Bool;
ho_semantic_closure_step s g sorts ps ms ofuel prec priority arity c ls recur d
  t = (case Higher_Order_Core.ho_typeof s g d t of {
        Nothing -> False;
        Just a ->
          Arith.membera ls t ||
            (any (Higher_Order_Accessible_Closure.ho_accessible_from s g sorts
                   t)
               ls ||
              ((case t of {
                 Higher_Order_Core.HBound n ->
                   Arith.less_nat n (Arith.size_list d);
                 Higher_Order_Core.HFree _ -> False;
                 Higher_Order_Core.HConst da ->
                   Arith.less_nat (prec da) (prec c);
                 Higher_Order_Core.HApp f x -> recur d f && recur d x;
                 Higher_Order_Core.HAbs ta aa -> recur (ta : d) aa;
               }) ||
                (case Higher_Order_Source_Computability.ho_application_head t of
                  {
                  Higher_Order_Core.HBound _ -> False;
                  Higher_Order_Core.HFree _ -> False;
                  Higher_Order_Core.HConst da ->
                    (case Higher_Order_Core.ho_lookup s da of {
                      Nothing -> False;
                      Just u ->
                        Arith.equal_nat (prec da) (prec c) &&
                          Higher_Order_Core.equal_ho_type a
                            (Higher_Order_Full_Application.ho_drop_type
                              (arity da) u) &&
                            Arith.list_all2
                              (\ ta x ->
                                Higher_Order_Core.ho_typeof s g d x == Just ta)
                              (Arith.take (arity da)
                                (Higher_Order_Full_Application.ho_argument_types
                                  u))
                              (Higher_Order_Closure_Check.ho_spine_arguments
                                t) &&
                              (null d &&
                                (Higher_Order_Call_Comparison.ho_check_call_comparison
                                   s ps ms ofuel g c ls da
                                   (Higher_Order_Closure_Check.ho_spine_arguments
                                     t)
                                   True ||
                                  Higher_Order_Call_Comparison.ho_check_call_comparison
                                    s ps ms ofuel g c ls da
                                    (Higher_Order_Closure_Check.ho_spine_arguments
                                      t)
                                    False &&
                                    Higher_Order_Syntactic_Descent.ho_lex_subterm
                                      (Higher_Order_Priority_Order.ho_priority_arguments
priority (Higher_Order_Closure_Check.ho_spine_arguments t))
                                      (Higher_Order_Priority_Order.ho_priority_arguments
priority ls))) &&
                                all (recur d)
                                  (Higher_Order_Closure_Check.ho_spine_arguments
                                    t);
                    });
                  Higher_Order_Core.HApp _ _ -> False;
                  Higher_Order_Core.HAbs _ _ -> False;
                })));
      });

ho_check_semantic_closure ::
  [Higher_Order_Core.Ho_type] ->
    [Higher_Order_Core.Ho_type] ->
      (Arith.Nat -> Arith.Nat) ->
        [Higher_Order_Polynomial.Ho_polynomial] ->
          [Higher_Order_Polynomial.Ho_polynomial] ->
            Arith.Nat ->
              (Arith.Nat -> Arith.Nat) ->
                (Arith.Nat -> Arith.Nat) ->
                  (Arith.Nat -> Arith.Nat) ->
                    Arith.Nat ->
                      [Higher_Order_Core.Ho_term] ->
                        Arith.Nat ->
                          [Higher_Order_Core.Ho_type] ->
                            Higher_Order_Core.Ho_term -> Bool;
ho_check_semantic_closure s g sorts ps ms ofuel prec priority arity c ls fuel d
  t = (if Arith.equal_nat fuel Arith.zero_nat then False
        else ho_semantic_closure_step s g sorts ps ms ofuel prec priority arity
               c ls
               (ho_check_semantic_closure s g sorts ps ms ofuel prec priority
                 arity c ls (Arith.minus_nat fuel Arith.one_nat))
               d t);

}
