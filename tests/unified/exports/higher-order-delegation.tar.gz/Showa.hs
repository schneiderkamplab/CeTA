{-# LANGUAGE EmptyDataDecls, RankNTypes, ScopedTypeVariables #-}

module Showa(shows_string, Showa, shows_quote, shows_prec_list, shows_list_list)
  where {

import Prelude ((==), (/=), (<), (<=), (>=), (>), (+), (-), (*), (/), (**),
  (>>=), (>>), (=<<), (&&), (||), (^), (^^), (.), ($), ($!), (++), (!!), Eq,
  error, id, return, not, fst, snd, map, filter, concat, concatMap, reverse,
  zip, null, takeWhile, dropWhile, all, any, Integer, negate, abs, divMod,
  String, Bool(True, False), Maybe(Nothing, Just));
import Data.Bits ((.&.), (.|.), (.^.));
import qualified Prelude;
import qualified Data.Bits;
import qualified Uint;
import qualified Array;
import qualified IArray;
import qualified Uint32;
import qualified Uint64;
import qualified Data_Bits;
import qualified Bit_Shifts;
import qualified Str_Literal;
import qualified Arith;

shows_prec_char :: Arith.Nat -> Arith.Char -> [Arith.Char] -> [Arith.Char];
shows_prec_char p c = (\ a -> c : a);

shows_string :: [Arith.Char] -> [Arith.Char] -> [Arith.Char];
shows_string = (\ a b -> a ++ b);

shows_list_char :: [Arith.Char] -> [Arith.Char] -> [Arith.Char];
shows_list_char cs = shows_string cs;

class Showa a where {
  shows_prec :: Arith.Nat -> a -> [Arith.Char] -> [Arith.Char];
  shows_list :: [a] -> [Arith.Char] -> [Arith.Char];
};

instance Showa Arith.Char where {
  shows_prec = shows_prec_char;
  shows_list = shows_list_char;
};

shows_sep ::
  forall a.
    (a -> [Arith.Char] -> [Arith.Char]) ->
      ([Arith.Char] -> [Arith.Char]) -> [a] -> [Arith.Char] -> [Arith.Char];
shows_sep s sep [] = shows_string [];
shows_sep s sep [x] = s x;
shows_sep s sep (x : v : va) = (s x . sep) . shows_sep s sep (v : va);

shows_quote :: ([Arith.Char] -> [Arith.Char]) -> [Arith.Char] -> [Arith.Char];
shows_quote s =
  (shows_prec_char Arith.zero_nat Arith.char_0x27 . s) .
    shows_prec_char Arith.zero_nat Arith.char_0x27;

shows_list_gen ::
  forall a.
    (a -> [Arith.Char] -> [Arith.Char]) ->
      [Arith.Char] ->
        [Arith.Char] ->
          [Arith.Char] -> [Arith.Char] -> [a] -> [Arith.Char] -> [Arith.Char];
shows_list_gen showsx e l s r xs =
  (if null xs then shows_string e
    else (shows_string l . shows_sep showsx (shows_string s) xs) .
           shows_string r);

showsp_list ::
  forall a.
    (Arith.Nat -> a -> [Arith.Char] -> [Arith.Char]) ->
      Arith.Nat -> [a] -> [Arith.Char] -> [Arith.Char];
showsp_list s p xs =
  shows_list_gen (s Arith.zero_nat) [Arith.char_0x5B, Arith.char_0x5D]
    [Arith.char_0x5B] [Arith.char_0x2C, Arith.char_0x20] [Arith.char_0x5D] xs;

shows_prec_list ::
  forall a. (Showa a) => Arith.Nat -> [a] -> [Arith.Char] -> [Arith.Char];
shows_prec_list p xs = shows_list xs;

shows_list_list :: forall a. (Showa a) => [[a]] -> [Arith.Char] -> [Arith.Char];
shows_list_list xss = showsp_list shows_prec_list Arith.zero_nat xss;

}
