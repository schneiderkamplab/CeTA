{-# LANGUAGE EmptyDataDecls, RankNTypes, ScopedTypeVariables #-}

module Higher_Order_Interpretation(Ho_expression(..), ho_rename_up) where {

import Prelude ((==), (/=), (<), (<=), (>=), (>), (+), (-), (*), (/), (**),
  (>>=), (>>), (=<<), (&&), (||), (^), (^^), (.), ($), ($!), (++), (!!), Eq,
  error, id, return, not, fst, snd, map, filter, concat, concatMap, reverse,
  zip, null, takeWhile, dropWhile, all, any, Integer, negate, abs, divMod,
  String, Bool(True, False), Maybe(Nothing, Just));
import Data.Bits ((.&.), (.|.), (.^.));
import qualified Prelude;
import qualified Data.Bits;
import qualified Uint;
import qualified Array;
import qualified IArray;
import qualified Uint32;
import qualified Uint64;
import qualified Data_Bits;
import qualified Bit_Shifts;
import qualified Str_Literal;
import qualified Higher_Order_Core;
import qualified Arith;

data Ho_expression = HEVar Arith.Nat | HEConst Arith.Nat
  | HEApp Higher_Order_Core.Ho_type Higher_Order_Core.Ho_type Ho_expression
      Ho_expression
  | HEAbs Higher_Order_Core.Ho_type Higher_Order_Core.Ho_type Ho_expression;

ho_rename_up :: (Arith.Nat -> Arith.Nat) -> Arith.Nat -> Arith.Nat;
ho_rename_up r n =
  (if Arith.equal_nat n Arith.zero_nat then Arith.zero_nat
    else Arith.suc (r (Arith.minus_nat n Arith.one_nat)));

}
