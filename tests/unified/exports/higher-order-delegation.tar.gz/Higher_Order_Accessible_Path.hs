{-# LANGUAGE EmptyDataDecls, RankNTypes, ScopedTypeVariables #-}

module Higher_Order_Accessible_Path(ho_check_accessible_path) where {

import Prelude ((==), (/=), (<), (<=), (>=), (>), (+), (-), (*), (/), (**),
  (>>=), (>>), (=<<), (&&), (||), (^), (^^), (.), ($), ($!), (++), (!!), Eq,
  error, id, return, not, fst, snd, map, filter, concat, concatMap, reverse,
  zip, null, takeWhile, dropWhile, all, any, Integer, negate, abs, divMod,
  String, Bool(True, False), Maybe(Nothing, Just));
import Data.Bits ((.&.), (.|.), (.^.));
import qualified Prelude;
import qualified Data.Bits;
import qualified Uint;
import qualified Array;
import qualified IArray;
import qualified Uint32;
import qualified Uint64;
import qualified Data_Bits;
import qualified Bit_Shifts;
import qualified Str_Literal;
import qualified Higher_Order_Candidate_Interpretation;
import qualified Higher_Order_Source_Computability;
import qualified Higher_Order_Closure_Check;
import qualified Higher_Order_Core;
import qualified Arith;

ho_check_accessible_path ::
  [Higher_Order_Core.Ho_type] ->
    [Higher_Order_Core.Ho_type] ->
      (Arith.Nat -> Arith.Nat) ->
        Arith.Nat ->
          Higher_Order_Core.Ho_term -> Higher_Order_Core.Ho_term -> Bool;
ho_check_accessible_path s g rank fuel t u =
  (if Arith.equal_nat fuel Arith.zero_nat
    then Higher_Order_Core.equal_ho_term t u
    else Higher_Order_Core.equal_ho_term t u ||
           (case Higher_Order_Core.ho_typeof s g [] u of {
             Nothing -> False;
             Just (Higher_Order_Core.HBase b) ->
               (case Higher_Order_Source_Computability.ho_application_head u of
                 {
                 Higher_Order_Core.HBound _ -> False;
                 Higher_Order_Core.HFree _ -> False;
                 Higher_Order_Core.HConst _ ->
                   any (\ v ->
                         (case Higher_Order_Core.ho_typeof s g [] v of {
                           Nothing -> False;
                           Just ta ->
                             Higher_Order_Candidate_Interpretation.ho_positive_type
                               rank (rank b) ta &&
                               ho_check_accessible_path s g rank
                                 (Arith.minus_nat fuel Arith.one_nat) t v;
                         }))
                     (Higher_Order_Closure_Check.ho_spine_arguments u);
                 Higher_Order_Core.HApp _ _ -> False;
                 Higher_Order_Core.HAbs _ _ -> False;
               });
             Just (Higher_Order_Core.HArrow _ _) -> False;
           }));

}
