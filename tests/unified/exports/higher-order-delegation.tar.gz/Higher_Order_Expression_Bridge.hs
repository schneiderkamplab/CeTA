{-# LANGUAGE EmptyDataDecls, RankNTypes, ScopedTypeVariables #-}

module Higher_Order_Expression_Bridge(ho_compile) where {

import Prelude ((==), (/=), (<), (<=), (>=), (>), (+), (-), (*), (/), (**),
  (>>=), (>>), (=<<), (&&), (||), (^), (^^), (.), ($), ($!), (++), (!!), Eq,
  error, id, return, not, fst, snd, map, filter, concat, concatMap, reverse,
  zip, null, takeWhile, dropWhile, all, any, Integer, negate, abs, divMod,
  String, Bool(True, False), Maybe(Nothing, Just));
import Data.Bits ((.&.), (.|.), (.^.));
import qualified Prelude;
import qualified Data.Bits;
import qualified Uint;
import qualified Array;
import qualified IArray;
import qualified Uint32;
import qualified Uint64;
import qualified Data_Bits;
import qualified Bit_Shifts;
import qualified Str_Literal;
import qualified Higher_Order_Interpretation;
import qualified Higher_Order_Core;
import qualified Arith;

ho_compile ::
  [Higher_Order_Core.Ho_type] ->
    [Higher_Order_Core.Ho_type] ->
      [Higher_Order_Core.Ho_type] ->
        Higher_Order_Core.Ho_term -> Higher_Order_Interpretation.Ho_expression;
ho_compile s v b (Higher_Order_Core.HBound n) =
  Higher_Order_Interpretation.HEVar n;
ho_compile s v b (Higher_Order_Core.HFree n) =
  Higher_Order_Interpretation.HEVar (Arith.plus_nat (Arith.size_list b) n);
ho_compile s v b (Higher_Order_Core.HConst n) =
  Higher_Order_Interpretation.HEConst n;
ho_compile s v b (Higher_Order_Core.HApp f x) =
  (case Higher_Order_Core.ho_typeof s v b f of {
    Nothing -> Higher_Order_Interpretation.HEVar Arith.zero_nat;
    Just (Higher_Order_Core.HBase _) ->
      Higher_Order_Interpretation.HEVar Arith.zero_nat;
    Just (Higher_Order_Core.HArrow a c) ->
      Higher_Order_Interpretation.HEApp a c (ho_compile s v b f)
        (ho_compile s v b x);
  });
ho_compile s v b (Higher_Order_Core.HAbs a t) =
  (case Higher_Order_Core.ho_typeof s v (a : b) t of {
    Nothing -> Higher_Order_Interpretation.HEVar Arith.zero_nat;
    Just c -> Higher_Order_Interpretation.HEAbs a c (ho_compile s v (a : b) t);
  });

}
