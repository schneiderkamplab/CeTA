{-# LANGUAGE EmptyDataDecls, RankNTypes, ScopedTypeVariables #-}

module Rewriting_Impl(rewriting_proc) where {

import Prelude ((==), (/=), (<), (<=), (>=), (>), (+), (-), (*), (/), (**),
  (>>=), (>>), (=<<), (&&), (||), (^), (^^), (.), ($), ($!), (++), (!!), Eq,
  error, id, return, not, fst, snd, map, filter, concat, concatMap, reverse,
  zip, null, takeWhile, dropWhile, all, any, Integer, negate, abs, divMod,
  String, Bool(True, False), Maybe(Nothing, Just));
import Data.Bits ((.&.), (.|.), (.^.));
import qualified Prelude;
import qualified Data.Bits;
import qualified Uint;
import qualified Array;
import qualified IArray;
import qualified Uint32;
import qualified Uint64;
import qualified Data_Bits;
import qualified Bit_Shifts;
import qualified Str_Literal;
import qualified Innermost_Usable_Rules_Impl;
import qualified Critical_Pairs_Impl;
import qualified Renaming2_String;
import qualified Renaming2;
import qualified Lists_are_Infinite;
import qualified Q_Restricted_Rewriting_Impl;
import qualified Check_Monad;
import qualified Error_Monad;
import qualified HOL;
import qualified Dependency_Pair_Problem_Spec;
import qualified Sum_Type;
import qualified Compare;
import qualified Mapping;
import qualified Arith;
import qualified Term_Rewriting;

check_rewrite_common_preconditions ::
  forall a b c d.
    (Compare.Compare_order b, Eq b,
      Term_Rewriting.Showl b) => Dependency_Pair_Problem_Spec.Dpp_ops_ext a b
                                   [Arith.Char] () ->
                                   Maybe [(Term_Rewriting.Term b [Arith.Char],
    Term_Rewriting.Term b [Arith.Char])] ->
                                     (Term_Rewriting.Term b [Arith.Char],
                                       Term_Rewriting.Term c [Arith.Char]) ->
                                       [Term_Rewriting.Term b [Arith.Char]] ->
 [Term_Rewriting.Term b [Arith.Char]] ->
   d -> (Term_Rewriting.Term b [Arith.Char],
          Term_Rewriting.Term b [Arith.Char]) ->
          [Arith.Nat] -> Bool -> a -> Sum_Type.Sum (String -> String) ();
check_rewrite_common_preconditions i u_opt st ss ts t lr p sound dpp =
  let {
    r = Dependency_Pair_Problem_Spec.rules i dpp;
    s = fst st;
    ta = snd st;
    tp = Term_Rewriting.subt_at ta p;
    u = (case u_opt of {
          Nothing ->
            concatMap
              (\ tb ->
                Innermost_Usable_Rules_Impl.inn_usable_rules_pair i dpp (s, tb))
              ts;
          Just u -> u;
        });
  } in Error_Monad.bind
         (Error_Monad.catch_error (Check_Monad.check_subseteq u r)
           (\ x ->
             Sum_Type.Inl
               (Term_Rewriting.showsl_rule x .
                 Term_Rewriting.showsl_lit
                   " is not a rule of the rewrite system ")))
         (\ _ ->
           let {
             urc = Innermost_Usable_Rules_Impl.is_ur_closed_impl_dpp_mv i dpp u;
             check_urc =
               (\ sa tb ->
                 Check_Monad.check (urc sa tb)
                   ((Term_Rewriting.showsl_lit "term " .
                      Term_Rewriting.showsl_terma tb) .
                     Term_Rewriting.showsl_lit
                       " is not closed under usable rules"));
             nfs = Dependency_Pair_Problem_Spec.nfs i dpp;
           } in Error_Monad.bind
                  (Error_Monad.catch_error
                    (Error_Monad.forallM
                      (\ (l, _) ->
                        Check_Monad.check (not (Term_Rewriting.is_Var l))
                          (Term_Rewriting.showsl_lit
                            "lhss must not be variables"))
                      u)
                    (\ x -> Sum_Type.Inl (snd x)))
                  (\ _ ->
                    Error_Monad.bind
                      (Check_Monad.check (Term_Rewriting.wf_rule lr)
                        (Term_Rewriting.showsl_rule lr .
                          Term_Rewriting.showsl_lit
                            " is not a well formed rule"))
                      (\ _ ->
                        Error_Monad.bind
                          (if nfs && sound then Sum_Type.Inr ()
                            else Error_Monad.catch_error
                                   (Check_Monad.check_subseteq
                                     (Term_Rewriting.vars_term_list tp)
                                     (Term_Rewriting.vars_term_list s))
                                   (\ _ ->
                                     Sum_Type.Inl
                                       (Term_Rewriting.showsl_lit
 "variable condition in pair violated")))
                          (\ _ ->
                            Error_Monad.bind
                              (Error_Monad.catch_error
                                (Error_Monad.forallM (check_urc ss) ts)
                                (\ x -> Sum_Type.Inl (snd x)))
                              (\ _ ->
                                Error_Monad.bind
                                  (Error_Monad.catch_error
                                    (Error_Monad.forallM
                                      (\ (l, a) ->
check_urc (Term_Rewriting.args l) a)
                                      u)
                                    (\ x -> Sum_Type.Inl (snd x)))
                                  (\ _ ->
                                    Error_Monad.bind
                                      (Error_Monad.catch_error
(Critical_Pairs_Impl.check_critical_pairs_innermost
  Renaming2_String.string_rename u)
(\ x ->
  Sum_Type.Inl
    (Term_Rewriting.showsl_lit "problem in showing UNF of usable rules\n" . x)))
                                      (\ _ ->
Error_Monad.catch_error
  (Error_Monad.forallM
    (\ (_, (sa, tb)) ->
      Check_Monad.check (Term_Rewriting.equal_term sa tb)
        (Term_Rewriting.showsl_lit
          "non-trivial critical pair between rule to rewrite and usable rules"))
    (Critical_Pairs_Impl.critical_pairs_impl Renaming2_String.string_rename [lr]
      u))
  (\ x -> Sum_Type.Inl (snd x)))))))));

rewriting_proc ::
  forall a b.
    (Compare.Compare_order b, Eq b,
      Term_Rewriting.Showl b) => Dependency_Pair_Problem_Spec.Dpp_ops_ext a b
                                   [Arith.Char] () ->
                                   Maybe [(Term_Rewriting.Term b [Arith.Char],
    Term_Rewriting.Term b [Arith.Char])] ->
                                     (Term_Rewriting.Term b [Arith.Char],
                                       Term_Rewriting.Term b [Arith.Char]) ->
                                       (Term_Rewriting.Term b [Arith.Char],
 Term_Rewriting.Term b [Arith.Char]) ->
 (Term_Rewriting.Term b [Arith.Char], Term_Rewriting.Term b [Arith.Char]) ->
   (Term_Rewriting.Term b [Arith.Char], Term_Rewriting.Term b [Arith.Char]) ->
     [Arith.Nat] -> a -> Sum_Type.Sum (String -> String) a;
rewriting_proc i u stb sta st lr p dpp =
  (case let {
          s = fst stb;
          t = snd sta;
        } in Error_Monad.bind
               (Q_Restricted_Rewriting_Impl.check_rstep
                 (Dependency_Pair_Problem_Spec.rules i dpp) p lr (snd stb) t)
               (\ _ ->
                 Error_Monad.bind
                   (Check_Monad.check
                     (Dependency_Pair_Problem_Spec.nFQ_subset_NF_rules i dpp)
                     (Term_Rewriting.showsl_lit "innermost rewriting required"))
                   (\ _ ->
                     Error_Monad.bind
                       (check_rewrite_common_preconditions i u stb [s]
                         [Term_Rewriting.subt_at (snd stb) p] t lr p True dpp)
                       (\ _ ->
                         Error_Monad.bind
                           (Check_Monad.check
                             (Term_Rewriting.eq_rule_mod_vars sta st)
                             (((Term_Rewriting.showsl_lit "the rule " .
                                 Term_Rewriting.showsl_rule sta) .
                                Term_Rewriting.showsl_lit
                                  " is not a renamed variant of ") .
                               Term_Rewriting.showsl_rule st))
                           (\ _ ->
                             Error_Monad.bind
                               (Check_Monad.check
                                 (Term_Rewriting.equal_term s (fst sta))
                                 (Term_Rewriting.showsl_lit
                                   "left-hand sides of old and new pair differ"))
                               (\ _ ->
                                 Error_Monad.bind
                                   (Check_Monad.check
                                     (Arith.membera
(Dependency_Pair_Problem_Spec.p i dpp) stb ||
                                       null
 (Dependency_Pair_Problem_Spec.r i dpp))
                                     (Term_Rewriting.showsl_lit
                                       "strict DP or no strict rules required"))
                                   (\ _ ->
                                     Check_Monad.check
                                       (Dependency_Pair_Problem_Spec.nfs i
  dpp ||
 Dependency_Pair_Problem_Spec.wwf_rules i dpp)
                                       (Term_Rewriting.showsl_lit
 "well-formed rules or normal subst. required")))))))
    of {
    Sum_Type.Inl a -> Sum_Type.Inl a;
    Sum_Type.Inr _ ->
      Sum_Type.Inr (Dependency_Pair_Problem_Spec.replace_pair i dpp stb [st]);
  });

}
