{-# LANGUAGE EmptyDataDecls, RankNTypes, ScopedTypeVariables #-}

module
  Higher_Order_Full_Application(ho_drop_type, ho_result_sort, ho_argument_types)
  where {

import Prelude ((==), (/=), (<), (<=), (>=), (>), (+), (-), (*), (/), (**),
  (>>=), (>>), (=<<), (&&), (||), (^), (^^), (.), ($), ($!), (++), (!!), Eq,
  error, id, return, not, fst, snd, map, filter, concat, concatMap, reverse,
  zip, null, takeWhile, dropWhile, all, any, Integer, negate, abs, divMod,
  String, Bool(True, False), Maybe(Nothing, Just));
import Data.Bits ((.&.), (.|.), (.^.));
import qualified Prelude;
import qualified Data.Bits;
import qualified Uint;
import qualified Array;
import qualified IArray;
import qualified Uint32;
import qualified Uint64;
import qualified Data_Bits;
import qualified Bit_Shifts;
import qualified Str_Literal;
import qualified Higher_Order_Core;
import qualified Arith;

ho_drop_type ::
  Arith.Nat -> Higher_Order_Core.Ho_type -> Higher_Order_Core.Ho_type;
ho_drop_type n a =
  (if Arith.equal_nat n Arith.zero_nat then a
    else (case a of {
           Higher_Order_Core.HBase aa -> Higher_Order_Core.HBase aa;
           Higher_Order_Core.HArrow _ aa ->
             ho_drop_type (Arith.minus_nat n Arith.one_nat) aa;
         }));

ho_result_sort :: Higher_Order_Core.Ho_type -> Arith.Nat;
ho_result_sort (Higher_Order_Core.HBase b) = b;
ho_result_sort (Higher_Order_Core.HArrow a c) = ho_result_sort c;

ho_argument_types :: Higher_Order_Core.Ho_type -> [Higher_Order_Core.Ho_type];
ho_argument_types (Higher_Order_Core.HBase b) = [];
ho_argument_types (Higher_Order_Core.HArrow a c) = a : ho_argument_types c;

}
