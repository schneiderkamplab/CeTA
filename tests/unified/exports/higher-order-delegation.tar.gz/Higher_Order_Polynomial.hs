{-# LANGUAGE EmptyDataDecls, RankNTypes, ScopedTypeVariables #-}

module
  Higher_Order_Polynomial(Ho_polynomial(..), equal_ho_polynomial,
                           ho_polynomial_typeof, ho_check_polynomial_signature)
  where {

import Prelude ((==), (/=), (<), (<=), (>=), (>), (+), (-), (*), (/), (**),
  (>>=), (>>), (=<<), (&&), (||), (^), (^^), (.), ($), ($!), (++), (!!), Eq,
  error, id, return, not, fst, snd, map, filter, concat, concatMap, reverse,
  zip, null, takeWhile, dropWhile, all, any, Integer, negate, abs, divMod,
  String, Bool(True, False), Maybe(Nothing, Just));
import Data.Bits ((.&.), (.|.), (.^.));
import qualified Prelude;
import qualified Data.Bits;
import qualified Uint;
import qualified Array;
import qualified IArray;
import qualified Uint32;
import qualified Uint64;
import qualified Data_Bits;
import qualified Bit_Shifts;
import qualified Str_Literal;
import qualified Higher_Order_Core;
import qualified Arith;

data Ho_polynomial = HPVar Arith.Nat | HPNumber Arith.Nat Arith.Nat
  | HPAdd Arith.Nat Ho_polynomial Ho_polynomial
  | HPMultiply Arith.Nat Ho_polynomial Ho_polynomial
  | HPApply Higher_Order_Core.Ho_type Higher_Order_Core.Ho_type Ho_polynomial
      Ho_polynomial
  | HPAbstract Higher_Order_Core.Ho_type Higher_Order_Core.Ho_type
      Ho_polynomial;

equal_ho_polynomial :: Ho_polynomial -> Ho_polynomial -> Bool;
equal_ho_polynomial (HPApply x51 x52 x53 x54) (HPAbstract x61 x62 x63) = False;
equal_ho_polynomial (HPAbstract x61 x62 x63) (HPApply x51 x52 x53 x54) = False;
equal_ho_polynomial (HPMultiply x41 x42 x43) (HPAbstract x61 x62 x63) = False;
equal_ho_polynomial (HPAbstract x61 x62 x63) (HPMultiply x41 x42 x43) = False;
equal_ho_polynomial (HPMultiply x41 x42 x43) (HPApply x51 x52 x53 x54) = False;
equal_ho_polynomial (HPApply x51 x52 x53 x54) (HPMultiply x41 x42 x43) = False;
equal_ho_polynomial (HPAdd x31 x32 x33) (HPAbstract x61 x62 x63) = False;
equal_ho_polynomial (HPAbstract x61 x62 x63) (HPAdd x31 x32 x33) = False;
equal_ho_polynomial (HPAdd x31 x32 x33) (HPApply x51 x52 x53 x54) = False;
equal_ho_polynomial (HPApply x51 x52 x53 x54) (HPAdd x31 x32 x33) = False;
equal_ho_polynomial (HPAdd x31 x32 x33) (HPMultiply x41 x42 x43) = False;
equal_ho_polynomial (HPMultiply x41 x42 x43) (HPAdd x31 x32 x33) = False;
equal_ho_polynomial (HPNumber x21 x22) (HPAbstract x61 x62 x63) = False;
equal_ho_polynomial (HPAbstract x61 x62 x63) (HPNumber x21 x22) = False;
equal_ho_polynomial (HPNumber x21 x22) (HPApply x51 x52 x53 x54) = False;
equal_ho_polynomial (HPApply x51 x52 x53 x54) (HPNumber x21 x22) = False;
equal_ho_polynomial (HPNumber x21 x22) (HPMultiply x41 x42 x43) = False;
equal_ho_polynomial (HPMultiply x41 x42 x43) (HPNumber x21 x22) = False;
equal_ho_polynomial (HPNumber x21 x22) (HPAdd x31 x32 x33) = False;
equal_ho_polynomial (HPAdd x31 x32 x33) (HPNumber x21 x22) = False;
equal_ho_polynomial (HPVar x1) (HPAbstract x61 x62 x63) = False;
equal_ho_polynomial (HPAbstract x61 x62 x63) (HPVar x1) = False;
equal_ho_polynomial (HPVar x1) (HPApply x51 x52 x53 x54) = False;
equal_ho_polynomial (HPApply x51 x52 x53 x54) (HPVar x1) = False;
equal_ho_polynomial (HPVar x1) (HPMultiply x41 x42 x43) = False;
equal_ho_polynomial (HPMultiply x41 x42 x43) (HPVar x1) = False;
equal_ho_polynomial (HPVar x1) (HPAdd x31 x32 x33) = False;
equal_ho_polynomial (HPAdd x31 x32 x33) (HPVar x1) = False;
equal_ho_polynomial (HPVar x1) (HPNumber x21 x22) = False;
equal_ho_polynomial (HPNumber x21 x22) (HPVar x1) = False;
equal_ho_polynomial (HPAbstract x61 x62 x63) (HPAbstract y61 y62 y63) =
  Higher_Order_Core.equal_ho_type x61 y61 &&
    Higher_Order_Core.equal_ho_type x62 y62 && equal_ho_polynomial x63 y63;
equal_ho_polynomial (HPApply x51 x52 x53 x54) (HPApply y51 y52 y53 y54) =
  Higher_Order_Core.equal_ho_type x51 y51 &&
    Higher_Order_Core.equal_ho_type x52 y52 &&
      equal_ho_polynomial x53 y53 && equal_ho_polynomial x54 y54;
equal_ho_polynomial (HPMultiply x41 x42 x43) (HPMultiply y41 y42 y43) =
  Arith.equal_nat x41 y41 &&
    equal_ho_polynomial x42 y42 && equal_ho_polynomial x43 y43;
equal_ho_polynomial (HPAdd x31 x32 x33) (HPAdd y31 y32 y33) =
  Arith.equal_nat x31 y31 &&
    equal_ho_polynomial x32 y32 && equal_ho_polynomial x33 y33;
equal_ho_polynomial (HPNumber x21 x22) (HPNumber y21 y22) =
  Arith.equal_nat x21 y21 && Arith.equal_nat x22 y22;
equal_ho_polynomial (HPVar x1) (HPVar y1) = Arith.equal_nat x1 y1;

instance Eq Ho_polynomial where {
  a == b = equal_ho_polynomial a b;
};

ho_polynomial_typeof ::
  [Higher_Order_Core.Ho_type] ->
    Ho_polynomial -> Maybe Higher_Order_Core.Ho_type;
ho_polynomial_typeof g (HPVar n) = Higher_Order_Core.ho_lookup g n;
ho_polynomial_typeof g (HPNumber b n) = Just (Higher_Order_Core.HBase b);
ho_polynomial_typeof g (HPAdd b p q) =
  (case (ho_polynomial_typeof g p, ho_polynomial_typeof g q) of {
    (Nothing, _) -> Nothing;
    (Just (Higher_Order_Core.HBase _), Nothing) -> Nothing;
    (Just (Higher_Order_Core.HBase _), Just (Higher_Order_Core.HBase _)) ->
      Just (Higher_Order_Core.HBase b);
    (Just (Higher_Order_Core.HBase _), Just (Higher_Order_Core.HArrow _ _)) ->
      Nothing;
    (Just (Higher_Order_Core.HArrow _ _), _) -> Nothing;
  });
ho_polynomial_typeof g (HPMultiply b p q) =
  (case (ho_polynomial_typeof g p, ho_polynomial_typeof g q) of {
    (Nothing, _) -> Nothing;
    (Just (Higher_Order_Core.HBase _), Nothing) -> Nothing;
    (Just (Higher_Order_Core.HBase _), Just (Higher_Order_Core.HBase _)) ->
      Just (Higher_Order_Core.HBase b);
    (Just (Higher_Order_Core.HBase _), Just (Higher_Order_Core.HArrow _ _)) ->
      Nothing;
    (Just (Higher_Order_Core.HArrow _ _), _) -> Nothing;
  });
ho_polynomial_typeof g (HPApply a b f x) =
  (if ho_polynomial_typeof g f == Just (Higher_Order_Core.HArrow a b) &&
        ho_polynomial_typeof g x == Just a
    then Just b else Nothing);
ho_polynomial_typeof g (HPAbstract a b t) =
  (if ho_polynomial_typeof (a : g) t == Just b
    then Just (Higher_Order_Core.HArrow a b) else Nothing);

ho_check_polynomial_signature ::
  [Higher_Order_Core.Ho_type] -> [Ho_polynomial] -> Bool;
ho_check_polynomial_signature s ps =
  Arith.equal_nat (Arith.size_list ps) (Arith.size_list s) &&
    all (\ n ->
          ho_polynomial_typeof [] (Arith.nth ps n) == Just (Arith.nth s n))
      (Arith.upt Arith.zero_nat (Arith.size_list s));

}
