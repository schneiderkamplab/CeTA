{-# LANGUAGE EmptyDataDecls, RankNTypes, ScopedTypeVariables #-}

module
  Higher_Order_Polynomial_Normalization(ho_polynomial_rename,
 ho_polynomial_normalize)
  where {

import Prelude ((==), (/=), (<), (<=), (>=), (>), (+), (-), (*), (/), (**),
  (>>=), (>>), (=<<), (&&), (||), (^), (^^), (.), ($), ($!), (++), (!!), Eq,
  error, id, return, not, fst, snd, map, filter, concat, concatMap, reverse,
  zip, null, takeWhile, dropWhile, all, any, Integer, negate, abs, divMod,
  String, Bool(True, False), Maybe(Nothing, Just));
import Data.Bits ((.&.), (.|.), (.^.));
import qualified Prelude;
import qualified Data.Bits;
import qualified Uint;
import qualified Array;
import qualified IArray;
import qualified Uint32;
import qualified Uint64;
import qualified Data_Bits;
import qualified Bit_Shifts;
import qualified Str_Literal;
import qualified HOL;
import qualified Higher_Order_Interpretation;
import qualified Higher_Order_Polynomial;
import qualified Higher_Order_Core;
import qualified Arith;

ho_polynomial_rename ::
  (Arith.Nat -> Arith.Nat) ->
    Higher_Order_Polynomial.Ho_polynomial ->
      Higher_Order_Polynomial.Ho_polynomial;
ho_polynomial_rename r (Higher_Order_Polynomial.HPVar n) =
  Higher_Order_Polynomial.HPVar (r n);
ho_polynomial_rename r (Higher_Order_Polynomial.HPNumber b n) =
  Higher_Order_Polynomial.HPNumber b n;
ho_polynomial_rename r (Higher_Order_Polynomial.HPAdd b p q) =
  Higher_Order_Polynomial.HPAdd b (ho_polynomial_rename r p)
    (ho_polynomial_rename r q);
ho_polynomial_rename r (Higher_Order_Polynomial.HPMultiply b p q) =
  Higher_Order_Polynomial.HPMultiply b (ho_polynomial_rename r p)
    (ho_polynomial_rename r q);
ho_polynomial_rename r (Higher_Order_Polynomial.HPApply a b f x) =
  Higher_Order_Polynomial.HPApply a b (ho_polynomial_rename r f)
    (ho_polynomial_rename r x);
ho_polynomial_rename r (Higher_Order_Polynomial.HPAbstract a b t) =
  Higher_Order_Polynomial.HPAbstract a b
    (ho_polynomial_rename (Higher_Order_Interpretation.ho_rename_up r) t);

ho_polynomial_subst_up ::
  (Arith.Nat -> Higher_Order_Polynomial.Ho_polynomial) ->
    Arith.Nat -> Higher_Order_Polynomial.Ho_polynomial;
ho_polynomial_subst_up s n =
  (if Arith.equal_nat n Arith.zero_nat
    then Higher_Order_Polynomial.HPVar Arith.zero_nat
    else ho_polynomial_rename Arith.suc (s (Arith.minus_nat n Arith.one_nat)));

ho_polynomial_subst ::
  (Arith.Nat -> Higher_Order_Polynomial.Ho_polynomial) ->
    Higher_Order_Polynomial.Ho_polynomial ->
      Higher_Order_Polynomial.Ho_polynomial;
ho_polynomial_subst s (Higher_Order_Polynomial.HPVar n) = s n;
ho_polynomial_subst s (Higher_Order_Polynomial.HPNumber b n) =
  Higher_Order_Polynomial.HPNumber b n;
ho_polynomial_subst s (Higher_Order_Polynomial.HPAdd b p q) =
  Higher_Order_Polynomial.HPAdd b (ho_polynomial_subst s p)
    (ho_polynomial_subst s q);
ho_polynomial_subst s (Higher_Order_Polynomial.HPMultiply b p q) =
  Higher_Order_Polynomial.HPMultiply b (ho_polynomial_subst s p)
    (ho_polynomial_subst s q);
ho_polynomial_subst s (Higher_Order_Polynomial.HPApply a b f x) =
  Higher_Order_Polynomial.HPApply a b (ho_polynomial_subst s f)
    (ho_polynomial_subst s x);
ho_polynomial_subst s (Higher_Order_Polynomial.HPAbstract a b t) =
  Higher_Order_Polynomial.HPAbstract a b
    (ho_polynomial_subst (ho_polynomial_subst_up s) t);

ho_polynomial_beta_subst ::
  Higher_Order_Polynomial.Ho_polynomial ->
    Higher_Order_Polynomial.Ho_polynomial ->
      Higher_Order_Polynomial.Ho_polynomial;
ho_polynomial_beta_subst x t =
  ho_polynomial_subst
    (\ n ->
      (if Arith.equal_nat n Arith.zero_nat then x
        else Higher_Order_Polynomial.HPVar (Arith.minus_nat n Arith.one_nat)))
    t;

ho_polynomial_contract ::
  Higher_Order_Polynomial.Ho_polynomial ->
    Higher_Order_Polynomial.Ho_polynomial;
ho_polynomial_contract
  (Higher_Order_Polynomial.HPApply a b
    (Higher_Order_Polynomial.HPAbstract c d t) x)
  = ho_polynomial_beta_subst x t;
ho_polynomial_contract
  (Higher_Order_Polynomial.HPAdd b (Higher_Order_Polynomial.HPNumber c n)
    (Higher_Order_Polynomial.HPNumber d m))
  = Higher_Order_Polynomial.HPNumber b (Arith.plus_nat n m);
ho_polynomial_contract
  (Higher_Order_Polynomial.HPMultiply b (Higher_Order_Polynomial.HPNumber c n)
    (Higher_Order_Polynomial.HPNumber d m))
  = Higher_Order_Polynomial.HPNumber b (Arith.times_nat n m);
ho_polynomial_contract (Higher_Order_Polynomial.HPVar v) =
  Higher_Order_Polynomial.HPVar v;
ho_polynomial_contract (Higher_Order_Polynomial.HPNumber v va) =
  Higher_Order_Polynomial.HPNumber v va;
ho_polynomial_contract
  (Higher_Order_Polynomial.HPAdd v (Higher_Order_Polynomial.HPVar vc) vb) =
  Higher_Order_Polynomial.HPAdd v (Higher_Order_Polynomial.HPVar vc) vb;
ho_polynomial_contract
  (Higher_Order_Polynomial.HPAdd v (Higher_Order_Polynomial.HPAdd vc vd ve) vb)
  = Higher_Order_Polynomial.HPAdd v (Higher_Order_Polynomial.HPAdd vc vd ve) vb;
ho_polynomial_contract
  (Higher_Order_Polynomial.HPAdd v (Higher_Order_Polynomial.HPMultiply vc vd ve)
    vb)
  = Higher_Order_Polynomial.HPAdd v
      (Higher_Order_Polynomial.HPMultiply vc vd ve) vb;
ho_polynomial_contract
  (Higher_Order_Polynomial.HPAdd v (Higher_Order_Polynomial.HPApply vc vd ve vf)
    vb)
  = Higher_Order_Polynomial.HPAdd v
      (Higher_Order_Polynomial.HPApply vc vd ve vf) vb;
ho_polynomial_contract
  (Higher_Order_Polynomial.HPAdd v (Higher_Order_Polynomial.HPAbstract vc vd ve)
    vb)
  = Higher_Order_Polynomial.HPAdd v
      (Higher_Order_Polynomial.HPAbstract vc vd ve) vb;
ho_polynomial_contract
  (Higher_Order_Polynomial.HPAdd v va (Higher_Order_Polynomial.HPVar vc)) =
  Higher_Order_Polynomial.HPAdd v va (Higher_Order_Polynomial.HPVar vc);
ho_polynomial_contract
  (Higher_Order_Polynomial.HPAdd v va (Higher_Order_Polynomial.HPAdd vc vd ve))
  = Higher_Order_Polynomial.HPAdd v va (Higher_Order_Polynomial.HPAdd vc vd ve);
ho_polynomial_contract
  (Higher_Order_Polynomial.HPAdd v va
    (Higher_Order_Polynomial.HPMultiply vc vd ve))
  = Higher_Order_Polynomial.HPAdd v va
      (Higher_Order_Polynomial.HPMultiply vc vd ve);
ho_polynomial_contract
  (Higher_Order_Polynomial.HPAdd v va
    (Higher_Order_Polynomial.HPApply vc vd ve vf))
  = Higher_Order_Polynomial.HPAdd v va
      (Higher_Order_Polynomial.HPApply vc vd ve vf);
ho_polynomial_contract
  (Higher_Order_Polynomial.HPAdd v va
    (Higher_Order_Polynomial.HPAbstract vc vd ve))
  = Higher_Order_Polynomial.HPAdd v va
      (Higher_Order_Polynomial.HPAbstract vc vd ve);
ho_polynomial_contract
  (Higher_Order_Polynomial.HPMultiply v (Higher_Order_Polynomial.HPVar vc) vb) =
  Higher_Order_Polynomial.HPMultiply v (Higher_Order_Polynomial.HPVar vc) vb;
ho_polynomial_contract
  (Higher_Order_Polynomial.HPMultiply v (Higher_Order_Polynomial.HPAdd vc vd ve)
    vb)
  = Higher_Order_Polynomial.HPMultiply v
      (Higher_Order_Polynomial.HPAdd vc vd ve) vb;
ho_polynomial_contract
  (Higher_Order_Polynomial.HPMultiply v
    (Higher_Order_Polynomial.HPMultiply vc vd ve) vb)
  = Higher_Order_Polynomial.HPMultiply v
      (Higher_Order_Polynomial.HPMultiply vc vd ve) vb;
ho_polynomial_contract
  (Higher_Order_Polynomial.HPMultiply v
    (Higher_Order_Polynomial.HPApply vc vd ve vf) vb)
  = Higher_Order_Polynomial.HPMultiply v
      (Higher_Order_Polynomial.HPApply vc vd ve vf) vb;
ho_polynomial_contract
  (Higher_Order_Polynomial.HPMultiply v
    (Higher_Order_Polynomial.HPAbstract vc vd ve) vb)
  = Higher_Order_Polynomial.HPMultiply v
      (Higher_Order_Polynomial.HPAbstract vc vd ve) vb;
ho_polynomial_contract
  (Higher_Order_Polynomial.HPMultiply v va (Higher_Order_Polynomial.HPVar vc)) =
  Higher_Order_Polynomial.HPMultiply v va (Higher_Order_Polynomial.HPVar vc);
ho_polynomial_contract
  (Higher_Order_Polynomial.HPMultiply v va
    (Higher_Order_Polynomial.HPAdd vc vd ve))
  = Higher_Order_Polynomial.HPMultiply v va
      (Higher_Order_Polynomial.HPAdd vc vd ve);
ho_polynomial_contract
  (Higher_Order_Polynomial.HPMultiply v va
    (Higher_Order_Polynomial.HPMultiply vc vd ve))
  = Higher_Order_Polynomial.HPMultiply v va
      (Higher_Order_Polynomial.HPMultiply vc vd ve);
ho_polynomial_contract
  (Higher_Order_Polynomial.HPMultiply v va
    (Higher_Order_Polynomial.HPApply vc vd ve vf))
  = Higher_Order_Polynomial.HPMultiply v va
      (Higher_Order_Polynomial.HPApply vc vd ve vf);
ho_polynomial_contract
  (Higher_Order_Polynomial.HPMultiply v va
    (Higher_Order_Polynomial.HPAbstract vc vd ve))
  = Higher_Order_Polynomial.HPMultiply v va
      (Higher_Order_Polynomial.HPAbstract vc vd ve);
ho_polynomial_contract
  (Higher_Order_Polynomial.HPApply v va (Higher_Order_Polynomial.HPVar vd) vc) =
  Higher_Order_Polynomial.HPApply v va (Higher_Order_Polynomial.HPVar vd) vc;
ho_polynomial_contract
  (Higher_Order_Polynomial.HPApply v va (Higher_Order_Polynomial.HPNumber vd ve)
    vc)
  = Higher_Order_Polynomial.HPApply v va
      (Higher_Order_Polynomial.HPNumber vd ve) vc;
ho_polynomial_contract
  (Higher_Order_Polynomial.HPApply v va (Higher_Order_Polynomial.HPAdd vd ve vf)
    vc)
  = Higher_Order_Polynomial.HPApply v va
      (Higher_Order_Polynomial.HPAdd vd ve vf) vc;
ho_polynomial_contract
  (Higher_Order_Polynomial.HPApply v va
    (Higher_Order_Polynomial.HPMultiply vd ve vf) vc)
  = Higher_Order_Polynomial.HPApply v va
      (Higher_Order_Polynomial.HPMultiply vd ve vf) vc;
ho_polynomial_contract
  (Higher_Order_Polynomial.HPApply v va
    (Higher_Order_Polynomial.HPApply vd ve vf vg) vc)
  = Higher_Order_Polynomial.HPApply v va
      (Higher_Order_Polynomial.HPApply vd ve vf vg) vc;
ho_polynomial_contract (Higher_Order_Polynomial.HPAbstract v va vb) =
  Higher_Order_Polynomial.HPAbstract v va vb;

ho_polynomial_normalize ::
  Arith.Nat ->
    Higher_Order_Polynomial.Ho_polynomial ->
      Higher_Order_Polynomial.Ho_polynomial;
ho_polynomial_normalize n p =
  (if Arith.equal_nat n Arith.zero_nat then p
    else (case p of {
           Higher_Order_Polynomial.HPVar a -> Higher_Order_Polynomial.HPVar a;
           Higher_Order_Polynomial.HPNumber a b ->
             Higher_Order_Polynomial.HPNumber a b;
           Higher_Order_Polynomial.HPAdd b q r ->
             ho_polynomial_contract
               (Higher_Order_Polynomial.HPAdd b
                 (ho_polynomial_normalize (Arith.minus_nat n Arith.one_nat) q)
                 (ho_polynomial_normalize (Arith.minus_nat n Arith.one_nat) r));
           Higher_Order_Polynomial.HPMultiply b q r ->
             ho_polynomial_contract
               (Higher_Order_Polynomial.HPMultiply b
                 (ho_polynomial_normalize (Arith.minus_nat n Arith.one_nat) q)
                 (ho_polynomial_normalize (Arith.minus_nat n Arith.one_nat) r));
           Higher_Order_Polynomial.HPApply a b f x ->
             let {
               q = Higher_Order_Polynomial.HPApply a b
                     (ho_polynomial_normalize (Arith.minus_nat n Arith.one_nat)
                       f)
                     (ho_polynomial_normalize (Arith.minus_nat n Arith.one_nat)
                       x);
               r = ho_polynomial_contract q;
             } in (if Higher_Order_Polynomial.equal_ho_polynomial r q then q
                    else ho_polynomial_normalize
                           (Arith.minus_nat n Arith.one_nat) r);
           Higher_Order_Polynomial.HPAbstract a b t ->
             Higher_Order_Polynomial.HPAbstract a b
               (ho_polynomial_normalize (Arith.minus_nat n Arith.one_nat) t);
         }));

}
