{-# LANGUAGE EmptyDataDecls, RankNTypes, ScopedTypeVariables #-}

module
  CPF_Input_Parser(position, pos, plain_var, term, rule, rules, state, dp_input,
                    trs_input, final_states, innermostLhss, strategy_to_fp,
                    tree_automaton)
  where {

import Prelude ((==), (/=), (<), (<=), (>=), (>), (+), (-), (*), (/), (**),
  (>>=), (>>), (=<<), (&&), (||), (^), (^^), (.), ($), ($!), (++), (!!), Eq,
  error, id, return, not, fst, snd, map, filter, concat, concatMap, reverse,
  zip, null, takeWhile, dropWhile, all, any, Integer, negate, abs, divMod,
  String, Bool(True, False), Maybe(Nothing, Just));
import Data.Bits ((.&.), (.|.), (.^.));
import qualified Prelude;
import qualified Data.Bits;
import qualified Uint;
import qualified Array;
import qualified IArray;
import qualified Uint32;
import qualified Uint64;
import qualified Data_Bits;
import qualified Bit_Shifts;
import qualified Str_Literal;
import qualified Tree_Automata_Impl;
import qualified Outermost_Forbidden_Patterns;
import qualified Context_Sensitive_Impl;
import qualified HOL;
import qualified Sum_Type;
import qualified Ceta_Problem_Spec;
import qualified Mapping;
import qualified Term_Rewriting;
import qualified Strict_Sum;
import qualified Extended_Nat;
import qualified Xmlt;
import qualified Xml;
import qualified Arith;

list2position :: [Arith.Nat] -> [Arith.Nat];
list2position [] = [];
list2position (n : ns) = n : list2position ns;

position ::
  (Xml.Xml, ([([Arith.Char], [Arith.Char])], (Bool, ([String], [String])))) ->
    Strict_Sum.Sum_bot (Xmlt.Xml_error String) Arith.Nat;
position =
  Xmlt.xml_do_prepared (Arith.explode "position") "position"
    (Xmlt.xml_take_nat
      (\ n -> Xmlt.xml_return (Arith.minus_nat n Arith.one_nat)));

pos ::
  (Xml.Xml, ([([Arith.Char], [Arith.Char])], (Bool, ([String], [String])))) ->
    Strict_Sum.Sum_bot (Xmlt.Xml_error String) [Arith.Nat];
pos = Xmlt.xml_do_prepared (Arith.explode "positionInTerm") "positionInTerm"
        (Xmlt.xml_take_many_sub [] Arith.zero_nat Extended_Nat.Infinity_enat
          position (\ lst -> Xmlt.xml_return (list2position lst)));

plain_var ::
  (Xml.Xml, ([([Arith.Char], [Arith.Char])], (Bool, ([String], [String])))) ->
    Strict_Sum.Sum_bot (Xmlt.Xml_error String) [Arith.Char];
plain_var = Xmlt.xml_text "var";

var ::
  forall a.
    (Xml.Xml, ([([Arith.Char], [Arith.Char])], (Bool, ([String], [String])))) ->
      Strict_Sum.Sum_bot (Xmlt.Xml_error String)
        (Term_Rewriting.Term a [Arith.Char]);
var = Xmlt.xml_change plain_var (Xmlt.xml_return . Term_Rewriting.Var);

term ::
  forall a.
    (Term_Rewriting.Showl a) => ((Xml.Xml,
                                   ([([Arith.Char], [Arith.Char])],
                                     (Bool, ([String], [String])))) ->
                                  Strict_Sum.Sum_bot (Xmlt.Xml_error String)
                                    a) ->
                                  Mapping.Mapping [Arith.Char]
                                    (Term_Rewriting.Term a [Arith.Char]) ->
                                    (Xml.Xml,
                                      ([([Arith.Char], [Arith.Char])],
(Bool, ([String], [String])))) ->
                                      Strict_Sum.Sum_bot (Xmlt.Xml_error String)
(Term_Rewriting.Term a [Arith.Char]);
term xml2name termMap x =
  Xmlt.xml_do_or_prepared (Arith.explode "funapp") "funapp"
    (Xmlt.xml_take xml2name
      (\ name ->
        Xmlt.xml_take_many_sub [] Arith.zero_nat Extended_Nat.Infinity_enat
          (term xml2name termMap)
          (\ args -> Xmlt.xml_return (Term_Rewriting.Fun name args))))
    (Xmlt.xml_or var
      (Xmlt.xml_change (Xmlt.xml_text "termIndex")
        (\ idx ->
          (case Mapping.lookup termMap idx of {
            Nothing ->
              Xmlt.xml_error
                (("term index " ++ Arith.implode idx) ++
                  " is unknown in term-index map");
            Just a -> Xmlt.xml_return a;
          }))))
    x;

conditions ::
  forall a.
    (Term_Rewriting.Showl a) => ((Xml.Xml,
                                   ([([Arith.Char], [Arith.Char])],
                                     (Bool, ([String], [String])))) ->
                                  Strict_Sum.Sum_bot (Xmlt.Xml_error String)
                                    a) ->
                                  Mapping.Mapping [Arith.Char]
                                    (Term_Rewriting.Term a [Arith.Char]) ->
                                    String ->
                                      (Xml.Xml,
([([Arith.Char], [Arith.Char])], (Bool, ([String], [String])))) ->
Strict_Sum.Sum_bot (Xmlt.Xml_error String)
  [(Term_Rewriting.Term a [Arith.Char], Term_Rewriting.Term a [Arith.Char])];
conditions xml2name termMap tag =
  Xmlt.xml_do_prepared (Arith.explode tag) tag
    (Xmlt.xml_take_many_sub [] Arith.zero_nat Extended_Nat.Infinity_enat
      (Xmlt.xml_do_prepared (Arith.explode "condition") "condition"
        (Xmlt.xml_take (term xml2name termMap)
          (\ l ->
            Xmlt.xml_take (term xml2name termMap)
              (\ r -> Xmlt.xml_return (l, r)))))
      Xmlt.xml_return);

crule ::
  forall a.
    (Term_Rewriting.Showl a) => ((Xml.Xml,
                                   ([([Arith.Char], [Arith.Char])],
                                     (Bool, ([String], [String])))) ->
                                  Strict_Sum.Sum_bot (Xmlt.Xml_error String)
                                    a) ->
                                  Mapping.Mapping [Arith.Char]
                                    (Term_Rewriting.Term a [Arith.Char]) ->
                                    String ->
                                      (Xml.Xml,
([([Arith.Char], [Arith.Char])], (Bool, ([String], [String])))) ->
Strict_Sum.Sum_bot (Xmlt.Xml_error String)
  ((Term_Rewriting.Term a [Arith.Char], Term_Rewriting.Term a [Arith.Char]),
    [(Term_Rewriting.Term a [Arith.Char], Term_Rewriting.Term a [Arith.Char])]);
crule xml2name termMap tag =
  Xmlt.xml_do_prepared (Arith.explode tag) tag
    (Xmlt.xml_take (term xml2name termMap)
      (\ l ->
        Xmlt.xml_take (term xml2name termMap)
          (\ r ->
            Xmlt.xml_take_default [] (conditions xml2name termMap "conditions")
              (\ conds -> Xmlt.xml_return ((l, r), conds)))));

full_rule ::
  forall a.
    (Term_Rewriting.Showl a) => ((Xml.Xml,
                                   ([([Arith.Char], [Arith.Char])],
                                     (Bool, ([String], [String])))) ->
                                  Strict_Sum.Sum_bot (Xmlt.Xml_error String)
                                    a) ->
                                  Mapping.Mapping [Arith.Char]
                                    (Term_Rewriting.Term a [Arith.Char]) ->
                                    (Xml.Xml,
                                      ([([Arith.Char], [Arith.Char])],
(Bool, ([String], [String])))) ->
                                      Strict_Sum.Sum_bot (Xmlt.Xml_error String)
(Term_Rewriting.Term a [Arith.Char], Term_Rewriting.Term a [Arith.Char]);
full_rule xml2name termMap =
  Xmlt.xml_change (crule xml2name termMap "rule")
    (\ (lr, conds) ->
      (if null conds then Xmlt.xml_return lr
        else Xmlt.xml_error "conditional rule is not allowed here"));

rule ::
  forall a.
    (Term_Rewriting.Showl a) => ((Xml.Xml,
                                   ([([Arith.Char], [Arith.Char])],
                                     (Bool, ([String], [String])))) ->
                                  Strict_Sum.Sum_bot (Xmlt.Xml_error String)
                                    a) ->
                                  Mapping.Mapping [Arith.Char]
                                    (Term_Rewriting.Term a [Arith.Char]) ->
                                    Mapping.Mapping [Arith.Char]
                                      (Term_Rewriting.Term a [Arith.Char],
Term_Rewriting.Term a [Arith.Char]) ->
                                      (Xml.Xml,
([([Arith.Char], [Arith.Char])], (Bool, ([String], [String])))) ->
Strict_Sum.Sum_bot (Xmlt.Xml_error String)
  (Term_Rewriting.Term a [Arith.Char], Term_Rewriting.Term a [Arith.Char]);
rule xml2name termMap ruleMap =
  Xmlt.xml_or
    (Xmlt.xml_change (Xmlt.xml_text "ruleIndex")
      (\ idx ->
        (case Mapping.lookup ruleMap idx of {
          Nothing ->
            Xmlt.xml_error
              (("rule index " ++ Arith.implode idx) ++
                " is unknown in rule map");
          Just a -> Xmlt.xml_return a;
        })))
    (full_rule xml2name termMap);

rules ::
  forall a.
    (Term_Rewriting.Showl a) => ((Xml.Xml,
                                   ([([Arith.Char], [Arith.Char])],
                                     (Bool, ([String], [String])))) ->
                                  Strict_Sum.Sum_bot (Xmlt.Xml_error String)
                                    a) ->
                                  Mapping.Mapping [Arith.Char]
                                    (Term_Rewriting.Term a [Arith.Char]) ->
                                    Mapping.Mapping [Arith.Char]
                                      (Term_Rewriting.Term a [Arith.Char],
Term_Rewriting.Term a [Arith.Char]) ->
                                      (Xml.Xml,
([([Arith.Char], [Arith.Char])], (Bool, ([String], [String])))) ->
Strict_Sum.Sum_bot (Xmlt.Xml_error String)
  [(Term_Rewriting.Term a [Arith.Char], Term_Rewriting.Term a [Arith.Char])];
rules xml2name termMap ruleMap =
  Xmlt.xml_do_prepared (Arith.explode "rules") "rules"
    (Xmlt.xml_take_many_sub [] Arith.zero_nat Extended_Nat.Infinity_enat
      (rule xml2name termMap ruleMap) Xmlt.xml_return);

state ::
  (Xml.Xml, ([([Arith.Char], [Arith.Char])], (Bool, ([String], [String])))) ->
    Strict_Sum.Sum_bot (Xmlt.Xml_error String) [Arith.Char];
state = Xmlt.xml_text "state";

nfs_def :: Maybe Bool -> Bool;
nfs_def nfs_opt = (case nfs_opt of {
                    Nothing -> Ceta_Problem_Spec.default_nfs_flag;
                    Just nfs -> nfs;
                  });

innermostLhssStrategy ::
  forall a.
    (Term_Rewriting.Showl a) => ((Xml.Xml,
                                   ([([Arith.Char], [Arith.Char])],
                                     (Bool, ([String], [String])))) ->
                                  Strict_Sum.Sum_bot (Xmlt.Xml_error String)
                                    a) ->
                                  Mapping.Mapping [Arith.Char]
                                    (Term_Rewriting.Term a [Arith.Char]) ->
                                    (Xml.Xml,
                                      ([([Arith.Char], [Arith.Char])],
(Bool, ([String], [String])))) ->
                                      Strict_Sum.Sum_bot (Xmlt.Xml_error String)
(Ceta_Problem_Spec.Strategy a [Arith.Char]);
innermostLhssStrategy xml2name termMap =
  Xmlt.xml_do_prepared (Arith.explode "innermostLhss") "innermostLhss"
    (Xmlt.xml_take_optional (Xmlt.xml_bool "nfs")
      (\ nfs ->
        Xmlt.xml_take_many_sub [] Arith.zero_nat Extended_Nat.Infinity_enat
          (term xml2name termMap)
          (\ ret ->
            Xmlt.xml_return
              (Ceta_Problem_Spec.Innermost_Q (nfs_def nfs) ret))));

forbidden_pattern ::
  forall a.
    (Term_Rewriting.Showl a) => ((Xml.Xml,
                                   ([([Arith.Char], [Arith.Char])],
                                     (Bool, ([String], [String])))) ->
                                  Strict_Sum.Sum_bot (Xmlt.Xml_error String)
                                    a) ->
                                  Mapping.Mapping [Arith.Char]
                                    (Term_Rewriting.Term a [Arith.Char]) ->
                                    (Xml.Xml,
                                      ([([Arith.Char], [Arith.Char])],
(Bool, ([String], [String])))) ->
                                      Strict_Sum.Sum_bot (Xmlt.Xml_error String)
(Term_Rewriting.Actxt a (Term_Rewriting.Term a [Arith.Char]),
  (Term_Rewriting.Term a [Arith.Char], Term_Rewriting.Location));
forbidden_pattern xml2name termMap =
  Xmlt.xml_do_prepared (Arith.explode "forbiddenPattern") "forbiddenPattern"
    (Xmlt.xml_take (term xml2name termMap)
      (\ t ->
        Xmlt.xml_take pos
          (\ p ->
            Xmlt.xml_take
              (Xmlt.xml_or (Xmlt.xml_leaf "here" Term_Rewriting.H)
                (Xmlt.xml_or (Xmlt.xml_leaf "above" Term_Rewriting.A)
                  (Xmlt.xml_or (Xmlt.xml_leaf "below" Term_Rewriting.B)
                    (Xmlt.xml_leaf "below" Term_Rewriting.R))))
              (\ l ->
                (if Term_Rewriting.in_poss p t
                  then Xmlt.xml_return
                         (Term_Rewriting.ctxt_of_pos_term p t,
                           (Term_Rewriting.subt_at t p, l))
                  else Xmlt.xml_error "position does not exist in term")))));

forbidden_patterns ::
  forall a.
    (Term_Rewriting.Showl a) => ((Xml.Xml,
                                   ([([Arith.Char], [Arith.Char])],
                                     (Bool, ([String], [String])))) ->
                                  Strict_Sum.Sum_bot (Xmlt.Xml_error String)
                                    a) ->
                                  Mapping.Mapping [Arith.Char]
                                    (Term_Rewriting.Term a [Arith.Char]) ->
                                    (Xml.Xml,
                                      ([([Arith.Char], [Arith.Char])],
(Bool, ([String], [String])))) ->
                                      Strict_Sum.Sum_bot (Xmlt.Xml_error String)
[(Term_Rewriting.Actxt a (Term_Rewriting.Term a [Arith.Char]),
   (Term_Rewriting.Term a [Arith.Char], Term_Rewriting.Location))];
forbidden_patterns xml2name termMap =
  Xmlt.xml_do_prepared (Arith.explode "forbiddenPatterns") "forbiddenPatterns"
    (Xmlt.xml_take_many_sub [] Arith.zero_nat Extended_Nat.Infinity_enat
      (forbidden_pattern xml2name termMap) Xmlt.xml_return);

replacement_map ::
  forall a.
    (Term_Rewriting.Showl a) => ((Xml.Xml,
                                   ([([Arith.Char], [Arith.Char])],
                                     (Bool, ([String], [String])))) ->
                                  Strict_Sum.Sum_bot (Xmlt.Xml_error String)
                                    a) ->
                                  (Xml.Xml,
                                    ([([Arith.Char], [Arith.Char])],
                                      (Bool, ([String], [String])))) ->
                                    Strict_Sum.Sum_bot (Xmlt.Xml_error String)
                                      [((a, Arith.Nat), [Arith.Nat])];
replacement_map xml2name =
  Xmlt.xml_do_prepared (Arith.explode "contextSensitive") "contextSensitive"
    (Xmlt.xml_take_many_sub [] Arith.zero_nat Extended_Nat.Infinity_enat
      (Xmlt.xml_do_prepared (Arith.explode "replacementMapEntry")
        "replacementMapEntry"
        (Xmlt.xml_take xml2name
          (\ f ->
            Xmlt.xml_take (Xmlt.xml_nat "arity")
              (\ a ->
                Xmlt.xml_take_many_sub [] Arith.zero_nat
                  Extended_Nat.Infinity_enat position
                  (\ is -> Xmlt.xml_return ((f, a), is))))))
      Xmlt.xml_return);

innermost ::
  forall a.
    (Term_Rewriting.Showl a) => (Xml.Xml,
                                  ([([Arith.Char], [Arith.Char])],
                                    (Bool, ([String], [String])))) ->
                                  Strict_Sum.Sum_bot (Xmlt.Xml_error String)
                                    (Ceta_Problem_Spec.Strategy a [Arith.Char]);
innermost =
  Xmlt.xml_do_prepared (Arith.explode "innermost") "innermost"
    (Xmlt.xml_take_optional (Xmlt.xml_bool "nfs")
      (\ nfs -> Xmlt.xml_return (Ceta_Problem_Spec.Innermost (nfs_def nfs))));

inn_fp_strategy ::
  forall a.
    (Term_Rewriting.Showl a) => ((Xml.Xml,
                                   ([([Arith.Char], [Arith.Char])],
                                     (Bool, ([String], [String])))) ->
                                  Strict_Sum.Sum_bot (Xmlt.Xml_error String)
                                    a) ->
                                  Mapping.Mapping [Arith.Char]
                                    (Term_Rewriting.Term a [Arith.Char]) ->
                                    (Xml.Xml,
                                      ([([Arith.Char], [Arith.Char])],
(Bool, ([String], [String])))) ->
                                      Strict_Sum.Sum_bot (Xmlt.Xml_error String)
(Sum_Type.Sum (Ceta_Problem_Spec.Strategy a [Arith.Char])
  (Ceta_Problem_Spec.Fp_strategy a [Arith.Char]));
inn_fp_strategy xml2name termMap =
  Xmlt.xml_do_prepared (Arith.explode "strategy") "strategy"
    (Xmlt.xml_take
      (Xmlt.xml_or
        (Xmlt.xml_change
          (Xmlt.xml_or innermost (innermostLhssStrategy xml2name termMap))
          (\ s -> Xmlt.xml_return (Sum_Type.Inl s)))
        (Xmlt.xml_or
          (Xmlt.xml_leaf "outermost" (Sum_Type.Inr Ceta_Problem_Spec.Outermost))
          (Xmlt.xml_or
            (Xmlt.xml_change (replacement_map xml2name)
              (\ p ->
                Xmlt.xml_return
                  (Sum_Type.Inr (Ceta_Problem_Spec.Context_Sensitive p))))
            (Xmlt.xml_change (forbidden_patterns xml2name termMap)
              (\ p ->
                Xmlt.xml_return
                  (Sum_Type.Inr (Ceta_Problem_Spec.Forbidden_Patterns p)))))))
      Xmlt.xml_return);

dp_input ::
  forall a.
    (Term_Rewriting.Showl a) => ((Xml.Xml,
                                   ([([Arith.Char], [Arith.Char])],
                                     (Bool, ([String], [String])))) ->
                                  Strict_Sum.Sum_bot (Xmlt.Xml_error String)
                                    a) ->
                                  Mapping.Mapping [Arith.Char]
                                    (Term_Rewriting.Term a [Arith.Char]) ->
                                    Mapping.Mapping [Arith.Char]
                                      (Term_Rewriting.Term a [Arith.Char],
Term_Rewriting.Term a [Arith.Char]) ->
                                      (Xml.Xml,
([([Arith.Char], [Arith.Char])], (Bool, ([String], [String])))) ->
Strict_Sum.Sum_bot (Xmlt.Xml_error String)
  (Ceta_Problem_Spec.Input a [Arith.Char]);
dp_input xml2name termMap ruleMap =
  Xmlt.xml_do_prepared (Arith.explode "dpInput") "dpInput"
    (Xmlt.xml_take
      (Xmlt.xml_do_prepared (Arith.explode "trs") "trs"
        (Xmlt.xml_take (rules xml2name termMap ruleMap) Xmlt.xml_return))
      (\ r ->
        Xmlt.xml_take
          (Xmlt.xml_do_prepared (Arith.explode "dps") "dps"
            (Xmlt.xml_take (rules xml2name termMap ruleMap) Xmlt.xml_return))
          (\ p ->
            Xmlt.xml_take_default (Sum_Type.Inl Ceta_Problem_Spec.No_Strategy)
              (inn_fp_strategy xml2name termMap)
              (\ str ->
                Xmlt.xml_take (Xmlt.xml_bool "minimal")
                  (\ m ->
                    (case str of {
                      Sum_Type.Inl s ->
                        Xmlt.xml_return (Ceta_Problem_Spec.DP_input m p s r);
                      Sum_Type.Inr _ ->
                        Xmlt.xml_error
                          "ordinary dpInput cannot discard replacement-map or outermost context; use a typed CSR-DP input";
                    }))))));

trs_input ::
  forall a.
    (Term_Rewriting.Showl a) => ((Xml.Xml,
                                   ([([Arith.Char], [Arith.Char])],
                                     (Bool, ([String], [String])))) ->
                                  Strict_Sum.Sum_bot (Xmlt.Xml_error String)
                                    a) ->
                                  Mapping.Mapping [Arith.Char]
                                    (Term_Rewriting.Term a [Arith.Char]) ->
                                    Mapping.Mapping [Arith.Char]
                                      (Term_Rewriting.Term a [Arith.Char],
Term_Rewriting.Term a [Arith.Char]) ->
                                      (Xml.Xml,
([([Arith.Char], [Arith.Char])], (Bool, ([String], [String])))) ->
Strict_Sum.Sum_bot (Xmlt.Xml_error String)
  (Ceta_Problem_Spec.Input a [Arith.Char]);
trs_input xml2name termMap ruleMap =
  Xmlt.xml_do_prepared (Arith.explode "trsInput") "trsInput"
    (Xmlt.xml_take
      (Xmlt.xml_do_prepared (Arith.explode "trs") "trs"
        (Xmlt.xml_take (rules xml2name termMap ruleMap) Xmlt.xml_return))
      (\ r ->
        Xmlt.xml_take_default (Sum_Type.Inl Ceta_Problem_Spec.No_Strategy)
          (inn_fp_strategy xml2name termMap)
          (\ str ->
            Xmlt.xml_take_default []
              (Xmlt.xml_do_prepared (Arith.explode "relativeRules")
                "relativeRules"
                (Xmlt.xml_take (rules xml2name termMap ruleMap)
                  Xmlt.xml_return))
              (\ rel ->
                (case str of {
                  Sum_Type.Inl istrat ->
                    Xmlt.xml_return
                      (Ceta_Problem_Spec.Inn_TRS_input istrat r rel);
                  Sum_Type.Inr fpstrat ->
                    (if null rel
                      then Xmlt.xml_return
                             (Ceta_Problem_Spec.FP_TRS_input fpstrat r)
                      else Xmlt.xml_error
                             "the combination of relative rules with strategies is only supported for innermost");
                })))));

transition ::
  forall a b.
    ((Xml.Xml,
       ([([Arith.Char], [Arith.Char])], (Bool, ([String], [String])))) ->
      Strict_Sum.Sum_bot (Xmlt.Xml_error String)
        (Sum_Type.Sum (a, [[Arith.Char]]) b)) ->
      (Xml.Xml,
        ([([Arith.Char], [Arith.Char])], (Bool, ([String], [String])))) ->
        Strict_Sum.Sum_bot (Xmlt.Xml_error String)
          (Sum_Type.Sum (Term_Rewriting.Ta_rule [Arith.Char] a)
            (b, [Arith.Char]));
transition xml2lhs =
  Xmlt.xml_do_prepared (Arith.explode "transition") "transition"
    (Xmlt.xml_take xml2lhs
      (\ lhs ->
        Xmlt.xml_take
          (Xmlt.xml_do_prepared (Arith.explode "rhs") "rhs"
            (Xmlt.xml_take state Xmlt.xml_return))
          (\ q ->
            Xmlt.xml_return
              (case lhs of {
                Sum_Type.Inl (f, qs) ->
                  Sum_Type.Inl (Term_Rewriting.TA_rule f qs q);
                Sum_Type.Inr qa -> Sum_Type.Inr (qa, q);
              }))));

transitions ::
  forall a b.
    ((Xml.Xml,
       ([([Arith.Char], [Arith.Char])], (Bool, ([String], [String])))) ->
      Strict_Sum.Sum_bot (Xmlt.Xml_error String)
        (Sum_Type.Sum (a, [[Arith.Char]]) b)) ->
      (Xml.Xml,
        ([([Arith.Char], [Arith.Char])], (Bool, ([String], [String])))) ->
        Strict_Sum.Sum_bot (Xmlt.Xml_error String)
          ([Term_Rewriting.Ta_rule [Arith.Char] a], [(b, [Arith.Char])]);
transitions xml2lhs =
  Xmlt.xml_do_prepared (Arith.explode "transitions") "transitions"
    (Xmlt.xml_take_many_sub [] Arith.zero_nat Extended_Nat.Infinity_enat
      (transition xml2lhs)
      (\ rls ->
        (case Arith.partition (\ a -> (case a of {
Sum_Type.Inl _ -> True;
Sum_Type.Inr _ -> False;
                                      }))
                rls
          of {
          (rules, eps) -> let {
                            ruls = map (\ (Sum_Type.Inl r) -> r) rules;
                            ep = map (\ (Sum_Type.Inr e) -> e) eps;
                          } in Xmlt.xml_return (ruls, ep);
        })));

final_states ::
  (Xml.Xml, ([([Arith.Char], [Arith.Char])], (Bool, ([String], [String])))) ->
    Strict_Sum.Sum_bot (Xmlt.Xml_error String) [[Arith.Char]];
final_states =
  Xmlt.xml_do_prepared (Arith.explode "finalStates") "finalStates"
    (Xmlt.xml_take_many_sub [] Arith.zero_nat Extended_Nat.Infinity_enat state
      Xmlt.xml_return);

innermostLhss ::
  forall a.
    (Term_Rewriting.Showl a) => ((Xml.Xml,
                                   ([([Arith.Char], [Arith.Char])],
                                     (Bool, ([String], [String])))) ->
                                  Strict_Sum.Sum_bot (Xmlt.Xml_error String)
                                    a) ->
                                  Mapping.Mapping [Arith.Char]
                                    (Term_Rewriting.Term a [Arith.Char]) ->
                                    (Xml.Xml,
                                      ([([Arith.Char], [Arith.Char])],
(Bool, ([String], [String])))) ->
                                      Strict_Sum.Sum_bot (Xmlt.Xml_error String)
[Term_Rewriting.Term a [Arith.Char]];
innermostLhss xml2name termMap =
  Xmlt.xml_do_prepared (Arith.explode "innermostLhss") "innermostLhss"
    (Xmlt.xml_take_many_sub [] Arith.zero_nat Extended_Nat.Infinity_enat
      (term xml2name termMap) Xmlt.xml_return);

strategy_to_fp ::
  forall a.
    (Eq a) => Ceta_Problem_Spec.Fp_strategy a [Arith.Char] ->
                [(Term_Rewriting.Term a [Arith.Char],
                   Term_Rewriting.Term a [Arith.Char])] ->
                  [(Term_Rewriting.Actxt a (Term_Rewriting.Term a [Arith.Char]),
                     (Term_Rewriting.Term a [Arith.Char],
                       Term_Rewriting.Location))];
strategy_to_fp (Ceta_Problem_Spec.Forbidden_Patterns p) r = p;
strategy_to_fp Ceta_Problem_Spec.Outermost r =
  Outermost_Forbidden_Patterns.o_to_fp_impl (map fst r);
strategy_to_fp (Ceta_Problem_Spec.Context_Sensitive mu) r =
  Context_Sensitive_Impl.mu_to_fp_impl mu;

tree_automaton ::
  forall a.
    ((Xml.Xml,
       ([([Arith.Char], [Arith.Char])], (Bool, ([String], [String])))) ->
      Strict_Sum.Sum_bot (Xmlt.Xml_error String)
        (Sum_Type.Sum (a, [[Arith.Char]]) [Arith.Char])) ->
      (Xml.Xml,
        ([([Arith.Char], [Arith.Char])], (Bool, ([String], [String])))) ->
        Strict_Sum.Sum_bot (Xmlt.Xml_error String)
          (Tree_Automata_Impl.Tree_automaton [Arith.Char] a);
tree_automaton xml2lhs =
  Xmlt.xml_do_prepared (Arith.explode "treeAutomaton") "treeAutomaton"
    (Xmlt.xml_take final_states
      (\ f ->
        Xmlt.xml_take (transitions xml2lhs)
          (\ t_eps ->
            Xmlt.xml_return
              (Tree_Automata_Impl.Tree_Automaton f (fst t_eps) (snd t_eps)))));

}
