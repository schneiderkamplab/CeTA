{-# LANGUAGE EmptyDataDecls, RankNTypes, ScopedTypeVariables #-}

module CPF_Proof_Parser(xml2trs_termination_proof, symbol_parser) where {

import Prelude ((==), (/=), (<), (<=), (>=), (>), (+), (-), (*), (/), (**),
  (>>=), (>>), (=<<), (&&), (||), (^), (^^), (.), ($), ($!), (++), (!!), Eq,
  error, id, return, not, fst, snd, map, filter, concat, concatMap, reverse,
  zip, null, takeWhile, dropWhile, all, any, Integer, negate, abs, divMod,
  String, Bool(True, False), Maybe(Nothing, Just));
import Data.Bits ((.&.), (.|.), (.^.));
import qualified Prelude;
import qualified Data.Bits;
import qualified Uint;
import qualified Array;
import qualified IArray;
import qualified Uint32;
import qualified Uint64;
import qualified Data_Bits;
import qualified Bit_Shifts;
import qualified Str_Literal;
import qualified Defaults;
import qualified Monadic_Rewriting_Impl;
import qualified Complex_Constant_Removal_Impl;
import qualified Bounded_Increase_Impl;
import qualified Generalized_Usable_Rules;
import qualified Ordered_Semiring;
import qualified HOL;
import qualified Ordered_Completion_Impl;
import qualified Ceta_Problem_Spec;
import qualified Check_Termination_Common;
import qualified Check_Termination;
import qualified Compare;
import qualified Labelings;
import qualified Tree_Automata_Impl;
import qualified Matchbounds_Impl;
import qualified Sum_Type;
import qualified Critical_Pairs_Impl;
import qualified Check_Joins;
import qualified Reduction_Pair_Implementations;
import qualified List_Order_Implementations;
import qualified Max_Polynomial;
import qualified Max_Monus;
import qualified WPO;
import qualified Semantic_Labeling_Carrier;
import qualified NthRoot;
import qualified Congruence;
import qualified Group;
import qualified Ring;
import qualified Subterm_Criterion;
import qualified Subterm_Criterion_Impl;
import qualified Mapping;
import qualified CPF_Input_Parser;
import qualified Strict_Sum;
import qualified Extended_Nat;
import qualified Xmlt;
import qualified Xml;
import qualified Polynomials;
import qualified Matrix;
import qualified Matrix_Core_Order_Impl;
import qualified Term_Rewriting;
import qualified Arith;

data Domain = Natural Arith.Nat | Integera | NegativeInteger | Arctic
  | Arctic_rat | Int_mat Arith.Nat Arith.Nat | Arctic_mat Arith.Nat
  | Arctic_rat_mat Arith.Nat | Rational Term_Rewriting.Rat Arith.Nat
  | Rat_mat Arith.Nat Arith.Nat | Mini_Alg Term_Rewriting.Real Arith.Nat
  | Mini_Alg_mat Arith.Nat Arith.Nat
  | Int_core_mat Arith.Nat [Arith.Nat] Matrix_Core_Order_Impl.Core_matrix_mode
  | Real_core_mat Term_Rewriting.Real Arith.Nat [Arith.Nat]
      Matrix_Core_Order_Impl.Core_matrix_mode;

data Interpretation a =
  Int_linear_poly ((a, Arith.Nat), (Arith.Int, [Arith.Int]))
  | Rat_linear_poly ((a, Arith.Nat), (Term_Rewriting.Rat, [Term_Rewriting.Rat]))
  | Arctic_linear_poly
      ((a, Arith.Nat), (Term_Rewriting.Arctic, [Term_Rewriting.Arctic]))
  | Arctic_rat_linear_poly
      ((a, Arith.Nat),
        (Term_Rewriting.Arctic_delta Term_Rewriting.Rat,
          [Term_Rewriting.Arctic_delta Term_Rewriting.Rat]))
  | Real_linear_poly
      ((a, Arith.Nat), (Term_Rewriting.Real, [Term_Rewriting.Real]))
  | Int_matrix ((a, Arith.Nat), (Matrix.Mat Arith.Int, [Matrix.Mat Arith.Int]))
  | Rat_matrix
      ((a, Arith.Nat),
        (Matrix.Mat Term_Rewriting.Rat, [Matrix.Mat Term_Rewriting.Rat]))
  | Arctic_matrix
      ((a, Arith.Nat),
        (Matrix.Mat Term_Rewriting.Arctic, [Matrix.Mat Term_Rewriting.Arctic]))
  | Arctic_rat_matrix
      ((a, Arith.Nat),
        (Matrix.Mat (Term_Rewriting.Arctic_delta Term_Rewriting.Rat),
          [Matrix.Mat (Term_Rewriting.Arctic_delta Term_Rewriting.Rat)]))
  | Real_matrix
      ((a, Arith.Nat),
        (Matrix.Mat Term_Rewriting.Real, [Matrix.Mat Term_Rewriting.Real]))
  | Int_core_matrix
      ((a, Arith.Nat), (Matrix.Mat Arith.Int, [Matrix.Mat Arith.Int]))
  | Real_core_matrix Term_Rewriting.Real
      ((a, Arith.Nat),
        (Matrix.Mat Term_Rewriting.Real, [Matrix.Mat Term_Rewriting.Real]))
  | Int_non_linear_poly
      ((a, Arith.Nat), [(Polynomials.Monom Arith.Nat, Arith.Int)])
  | Rat_non_linear_poly
      ((a, Arith.Nat), [(Polynomials.Monom Arith.Nat, Term_Rewriting.Rat)])
  | Real_non_linear_poly
      ((a, Arith.Nat), [(Polynomials.Monom Arith.Nat, Term_Rewriting.Real)]);

afs ::
  forall a.
    (Term_Rewriting.Showl a) => ((Xml.Xml,
                                   ([([Arith.Char], [Arith.Char])],
                                     (Bool, ([String], [String])))) ->
                                  Strict_Sum.Sum_bot (Xmlt.Xml_error String)
                                    a) ->
                                  (Xml.Xml,
                                    ([([Arith.Char], [Arith.Char])],
                                      (Bool, ([String], [String])))) ->
                                    Strict_Sum.Sum_bot (Xmlt.Xml_error String)
                                      [((a, Arith.Nat),
 Term_Rewriting.Af_entry)];
afs xml2name =
  Xmlt.xml_do_prepared (Arith.explode "argumentFilter") "argumentFilter"
    (Xmlt.xml_take_many_sub [] Arith.zero_nat Extended_Nat.Infinity_enat
      (Xmlt.xml_do_prepared (Arith.explode "argumentFilterEntry")
        "argumentFilterEntry"
        (Xmlt.xml_take xml2name
          (\ name ->
            Xmlt.xml_take (Xmlt.xml_nat "arity")
              (\ arity ->
                Xmlt.xml_take
                  (Xmlt.xml_or
                    (Xmlt.xml_change (Xmlt.xml_nat "collapsing")
                      (\ n ->
                        Xmlt.xml_return
                          (Term_Rewriting.Collapse
                            (Arith.minus_nat n Arith.one_nat))))
                    (Xmlt.xml_do_prepared (Arith.explode "nonCollapsing")
                      "nonCollapsing"
                      (Xmlt.xml_take_many_sub [] Arith.zero_nat
                        Extended_Nat.Infinity_enat CPF_Input_Parser.position
                        (\ ls -> Xmlt.xml_return (Term_Rewriting.AFList ls)))))
                  (\ main -> Xmlt.xml_return ((name, arity), main))))))
      Xmlt.xml_return);

scg_position ::
  (Xml.Xml, ([([Arith.Char], [Arith.Char])], (Bool, ([String], [String])))) ->
    Strict_Sum.Sum_bot (Xmlt.Xml_error String) Arith.Nat;
scg_position = Xmlt.xml_nat "position";

scg ::
  forall a.
    (Term_Rewriting.Showl a) => ((Xml.Xml,
                                   ([([Arith.Char], [Arith.Char])],
                                     (Bool, ([String], [String])))) ->
                                  Strict_Sum.Sum_bot (Xmlt.Xml_error String)
                                    a) ->
                                  Mapping.Mapping [Arith.Char]
                                    (Term_Rewriting.Term a [Arith.Char]) ->
                                    Mapping.Mapping [Arith.Char]
                                      (Term_Rewriting.Term a [Arith.Char],
Term_Rewriting.Term a [Arith.Char]) ->
                                      (Xml.Xml,
([([Arith.Char], [Arith.Char])], (Bool, ([String], [String])))) ->
Strict_Sum.Sum_bot (Xmlt.Xml_error String)
  ((Term_Rewriting.Term a [Arith.Char], Term_Rewriting.Term a [Arith.Char]),
    ([(Arith.Nat, Arith.Nat)], [(Arith.Nat, Arith.Nat)]));
scg xml2name termIndexMap ruleMap =
  Xmlt.xml_do_prepared (Arith.explode "sizeChangeGraph") "sizeChangeGraph"
    (Xmlt.xml_take (CPF_Input_Parser.rule xml2name termIndexMap ruleMap)
      (\ lr ->
        Xmlt.xml_take_many_sub [] Arith.zero_nat Extended_Nat.Infinity_enat
          (Xmlt.xml_do_prepared (Arith.explode "edge") "edge"
            (Xmlt.xml_take scg_position
              (\ p ->
                Xmlt.xml_take (Xmlt.xml_bool "strict")
                  (\ s ->
                    Xmlt.xml_take scg_position
                      (\ q -> Xmlt.xml_return (s, (p, q)))))))
          (\ edges ->
            Xmlt.xml_return
              (lr, (Arith.map_filter
                      (\ x -> (if fst x then Just (snd x) else Nothing)) edges,
                     Arith.map_filter
                       (\ x -> (if not (fst x) then Just (snd x) else Nothing))
                       edges)))));

ctxt ::
  forall a.
    (Term_Rewriting.Showl a) => ((Xml.Xml,
                                   ([([Arith.Char], [Arith.Char])],
                                     (Bool, ([String], [String])))) ->
                                  Strict_Sum.Sum_bot (Xmlt.Xml_error String)
                                    a) ->
                                  Mapping.Mapping [Arith.Char]
                                    (Term_Rewriting.Term a [Arith.Char]) ->
                                    (Xml.Xml,
                                      ([([Arith.Char], [Arith.Char])],
(Bool, ([String], [String])))) ->
                                      Strict_Sum.Sum_bot (Xmlt.Xml_error String)
(Term_Rewriting.Actxt a (Term_Rewriting.Term a [Arith.Char]));
ctxt xml2name termIndexMap x =
  Xmlt.xml_do_or_prepared (Arith.explode "box") "box"
    (Xmlt.xml_return Term_Rewriting.Hole)
    (Xmlt.xml_do_prepared (Arith.explode "funContext") "funContext"
      (Xmlt.xml_take xml2name
        (\ name ->
          Xmlt.xml_take
            (Xmlt.xml_do_prepared (Arith.explode "before") "before"
              (Xmlt.xml_take_many_sub [] Arith.zero_nat
                Extended_Nat.Infinity_enat
                (CPF_Input_Parser.term xml2name termIndexMap) Xmlt.xml_return))
            (\ left ->
              Xmlt.xml_take (ctxt xml2name termIndexMap)
                (\ mid ->
                  Xmlt.xml_take
                    (Xmlt.xml_do_prepared (Arith.explode "after") "after"
                      (Xmlt.xml_take_many_sub [] Arith.zero_nat
                        Extended_Nat.Infinity_enat
                        (CPF_Input_Parser.term xml2name termIndexMap)
                        Xmlt.xml_return))
                    (\ right ->
                      Xmlt.xml_return
                        (Term_Rewriting.More name left mid right)))))))
    x;

proj ::
  forall a.
    (Term_Rewriting.Showl a) => ((Xml.Xml,
                                   ([([Arith.Char], [Arith.Char])],
                                     (Bool, ([String], [String])))) ->
                                  Strict_Sum.Sum_bot (Xmlt.Xml_error String)
                                    a) ->
                                  (Xml.Xml,
                                    ([([Arith.Char], [Arith.Char])],
                                      (Bool, ([String], [String])))) ->
                                    Strict_Sum.Sum_bot (Xmlt.Xml_error String)
                                      (Subterm_Criterion_Impl.ProjL a);
proj xml2name =
  Xmlt.xml_change (afs xml2name)
    (\ afl ->
      Xmlt.xml_return
        (Subterm_Criterion_Impl.Projection
          (map (\ a -> (case a of {
                         (fa, Term_Rewriting.Collapse aa) -> (fa, aa);
                         (fa, Term_Rewriting.AFList _) -> (fa, snd fa);
                       }))
            afl)));

start_term ::
  forall a.
    (Eq a,
      Term_Rewriting.Showl a) => ((Xml.Xml,
                                    ([([Arith.Char], [Arith.Char])],
                                      (Bool, ([String], [String])))) ->
                                   Strict_Sum.Sum_bot (Xmlt.Xml_error String)
                                     a) ->
                                   Mapping.Mapping [Arith.Char]
                                     (Term_Rewriting.Term a [Arith.Char]) ->
                                     Term_Rewriting.Term a [Arith.Char] ->
                                       (Xml.Xml,
 ([([Arith.Char], [Arith.Char])], (Bool, ([String], [String])))) ->
 Strict_Sum.Sum_bot (Xmlt.Xml_error String)
   (Term_Rewriting.Term a [Arith.Char]);
start_term xml2name termIndexMap t =
  Xmlt.xml_do_prepared (Arith.explode "startTerm") "startTerm"
    (Xmlt.xml_take (CPF_Input_Parser.term xml2name termIndexMap)
      (\ s ->
        (if Term_Rewriting.equal_term s t then Xmlt.xml_return t
          else Xmlt.xml_error "<startTerm> does not match lhs")));

rstep ::
  forall a.
    (Term_Rewriting.Showl a) => ((Xml.Xml,
                                   ([([Arith.Char], [Arith.Char])],
                                     (Bool, ([String], [String])))) ->
                                  Strict_Sum.Sum_bot (Xmlt.Xml_error String)
                                    a) ->
                                  Mapping.Mapping [Arith.Char]
                                    (Term_Rewriting.Term a [Arith.Char]) ->
                                    Mapping.Mapping [Arith.Char]
                                      (Term_Rewriting.Term a [Arith.Char],
Term_Rewriting.Term a [Arith.Char]) ->
                                      (Xml.Xml,
([([Arith.Char], [Arith.Char])], (Bool, ([String], [String])))) ->
Strict_Sum.Sum_bot (Xmlt.Xml_error String)
  ([Arith.Nat],
    ((Term_Rewriting.Term a [Arith.Char], Term_Rewriting.Term a [Arith.Char]),
      Term_Rewriting.Term a [Arith.Char]));
rstep xml2name termIndexMap ruleMap =
  Xmlt.xml_do_prepared (Arith.explode "rewriteStep") "rewriteStep"
    (Xmlt.xml_take CPF_Input_Parser.pos
      (\ p ->
        Xmlt.xml_take (CPF_Input_Parser.rule xml2name termIndexMap ruleMap)
          (\ r ->
            Xmlt.xml_take (CPF_Input_Parser.term xml2name termIndexMap)
              (\ t -> Xmlt.xml_return (p, (r, t))))));

rseq ::
  forall a.
    (Eq a,
      Term_Rewriting.Showl a) => ((Xml.Xml,
                                    ([([Arith.Char], [Arith.Char])],
                                      (Bool, ([String], [String])))) ->
                                   Strict_Sum.Sum_bot (Xmlt.Xml_error String)
                                     a) ->
                                   Mapping.Mapping [Arith.Char]
                                     (Term_Rewriting.Term a [Arith.Char]) ->
                                     Mapping.Mapping [Arith.Char]
                                       (Term_Rewriting.Term a [Arith.Char],
 Term_Rewriting.Term a [Arith.Char]) ->
                                       ((a, Arith.Nat) -> Arith.Nat) ->
 (Term_Rewriting.Term a [Arith.Char], Term_Rewriting.Term a [Arith.Char]) ->
   (Xml.Xml, ([([Arith.Char], [Arith.Char])], (Bool, ([String], [String])))) ->
     Strict_Sum.Sum_bot (Xmlt.Xml_error String)
       ((Term_Rewriting.Term a [Arith.Char],
          Term_Rewriting.Term a [Arith.Char]),
         [([Arith.Nat],
            ((Term_Rewriting.Term a [Arith.Char],
               Term_Rewriting.Term a [Arith.Char]),
              Term_Rewriting.Term a [Arith.Char]))]);
rseq xml2name termIndexMap ruleMap pi r =
  Xmlt.xml_do_prepared (Arith.explode "rewriteSequence") "rewriteSequence"
    (Xmlt.xml_take
      (start_term xml2name termIndexMap
        (Subterm_Criterion.proj_term pi (fst r)))
      (\ _ ->
        Xmlt.xml_take_many_sub [] Arith.zero_nat Extended_Nat.Infinity_enat
          (rstep xml2name termIndexMap ruleMap)
          (\ rseq -> Xmlt.xml_return (r, rseq))));

subst ::
  forall a.
    (Term_Rewriting.Showl a) => ((Xml.Xml,
                                   ([([Arith.Char], [Arith.Char])],
                                     (Bool, ([String], [String])))) ->
                                  Strict_Sum.Sum_bot (Xmlt.Xml_error String)
                                    a) ->
                                  Mapping.Mapping [Arith.Char]
                                    (Term_Rewriting.Term a [Arith.Char]) ->
                                    (Xml.Xml,
                                      ([([Arith.Char], [Arith.Char])],
(Bool, ([String], [String])))) ->
                                      Strict_Sum.Sum_bot (Xmlt.Xml_error String)
[([Arith.Char], Term_Rewriting.Term a [Arith.Char])];
subst xml2name termIndexMap =
  Xmlt.xml_do_prepared (Arith.explode "substitution") "substitution"
    (Xmlt.xml_take_many_sub [] Arith.zero_nat Extended_Nat.Infinity_enat
      (Xmlt.xml_do_prepared (Arith.explode "substEntry") "substEntry"
        (Xmlt.xml_take
          (Xmlt.xml_do_prepared (Arith.explode "var") "var"
            (Xmlt.xml_take_text Xmlt.xml_return))
          (\ var ->
            Xmlt.xml_take (CPF_Input_Parser.term xml2name termIndexMap)
              (\ trm -> Xmlt.xml_return (var, trm)))))
      Xmlt.xml_return);

xml_rat ::
  (Xml.Xml, ([([Arith.Char], [Arith.Char])], (Bool, ([String], [String])))) ->
    Strict_Sum.Sum_bot (Xmlt.Xml_error String) Term_Rewriting.Rat;
xml_rat =
  Xmlt.xml_or
    (Xmlt.xml_change (Xmlt.xml_int "integer")
      (Xmlt.xml_return . Term_Rewriting.of_int))
    (Xmlt.xml_do_prepared (Arith.explode "rational") "rational"
      (Xmlt.xml_take (Xmlt.xml_int "numerator")
        (\ a ->
          Xmlt.xml_take (Xmlt.xml_int "denominator")
            (\ b ->
              Xmlt.xml_return
                (Term_Rewriting.divide_rat (Term_Rewriting.of_int a)
                  (Term_Rewriting.of_int b))))));

sum_lpoly ::
  forall a.
    Congruence.Partial_object_ext a (Group.Monoid_ext a (Ring.Ring_ext a ())) ->
      [a] -> [a] -> [a];
sum_lpoly c [] ys = ys;
sum_lpoly c (v : va) [] = v : va;
sum_lpoly c (x : xs) (y : ys) = Ring.add c x y : sum_lpoly c xs ys;

lpoly_of ::
  forall a.
    (Eq a) => Congruence.Partial_object_ext a
                (Group.Monoid_ext a (Ring.Ring_ext a ())) ->
                Polynomials.Tpoly Arith.Nat a ->
                  Strict_Sum.Sum_bot String (a, [a]);
lpoly_of c (Polynomials.PNum i) = Strict_Sum.returna (i, []);
lpoly_of c (Polynomials.PVar x) =
  Strict_Sum.returna
    (Ring.zero c, Arith.replicate x (Ring.zero c) ++ [Group.one c]);
lpoly_of c (Polynomials.PSum []) = Strict_Sum.returna (Ring.zero c, []);
lpoly_of c (Polynomials.PSum (p : ps)) =
  Strict_Sum.bind (lpoly_of c p)
    (\ (cp, ncp) ->
      Strict_Sum.bind (lpoly_of c (Polynomials.PSum ps))
        (\ (cq, ncq) ->
          Strict_Sum.returna (Ring.add c cp cq, sum_lpoly c ncp ncq)));
lpoly_of c (Polynomials.PMult []) = Strict_Sum.returna (Group.one c, []);
lpoly_of c (Polynomials.PMult (p : ps)) =
  Strict_Sum.bind (lpoly_of c p)
    (\ (cp, ncp) ->
      Strict_Sum.bind (lpoly_of c (Polynomials.PMult ps))
        (\ (cq, ncq) ->
          (if all (\ a -> Ring.zero c == a) ncp
            then Strict_Sum.returna
                   (Group.mult c cp cq, map (Group.mult c cp) ncq)
            else (if all (\ a -> Ring.zero c == a) ncq
                   then Strict_Sum.returna
                          (Group.mult c cp cq,
                            map (\ x -> Group.mult c x cq) ncp)
                   else Strict_Sum.errora
                          "cannot transform non-linear polynomial to linear polynomial"))));

renaming ::
  forall a.
    (Term_Rewriting.Showl a) => ((Xml.Xml,
                                   ([([Arith.Char], [Arith.Char])],
                                     (Bool, ([String], [String])))) ->
                                  Strict_Sum.Sum_bot (Xmlt.Xml_error String)
                                    a) ->
                                  (Xml.Xml,
                                    ([([Arith.Char], [Arith.Char])],
                                      (Bool, ([String], [String])))) ->
                                    Strict_Sum.Sum_bot (Xmlt.Xml_error String)
                                      [(a, a)];
renaming xml2name =
  Xmlt.xml_do_prepared (Arith.explode "renaming") "renaming"
    (Xmlt.xml_take_many_sub [] Arith.zero_nat Extended_Nat.Infinity_enat
      (Xmlt.xml_do_prepared (Arith.explode "renamingEntry") "renamingEntry"
        (Xmlt.xml_take xml2name
          (\ a -> Xmlt.xml_take xml2name (\ b -> Xmlt.xml_return (a, b)))))
      Xmlt.xml_return);

xml_real ::
  (Xml.Xml, ([([Arith.Char], [Arith.Char])], (Bool, ([String], [String])))) ->
    Strict_Sum.Sum_bot (Xmlt.Xml_error String) Term_Rewriting.Real;
xml_real =
  Xmlt.xml_or
    (Xmlt.xml_change xml_rat (Xmlt.xml_return . Term_Rewriting.ratreal))
    (Xmlt.xml_do_prepared (Arith.explode "algebraic") "algebraic"
      (Xmlt.xml_take xml_rat
        (\ a ->
          Xmlt.xml_take xml_rat
            (\ b ->
              Xmlt.xml_take xml_rat
                (\ c ->
                  Xmlt.xml_return
                    (Term_Rewriting.plus_real (Term_Rewriting.ratreal a)
                      (Term_Rewriting.times_real (Term_Rewriting.ratreal b)
                        (NthRoot.sqrt (Term_Rewriting.ratreal c)))))))));

arith_fun ::
  (Xml.Xml, ([([Arith.Char], [Arith.Char])], (Bool, ([String], [String])))) ->
    Strict_Sum.Sum_bot (Xmlt.Xml_error String)
      Semantic_Labeling_Carrier.ArithFun;
arith_fun xml =
  Xmlt.xml_do_prepared (Arith.explode "arithFunction") "arithFunction"
    (Xmlt.xml_take
      (Xmlt.xml_or
        (Xmlt.xml_change (Xmlt.xml_nat "natural")
          (\ n -> Xmlt.xml_return (Semantic_Labeling_Carrier.Const n)))
        (Xmlt.xml_or
          (Xmlt.xml_change (Xmlt.xml_nat "variable")
            (\ n ->
              Xmlt.xml_return
                (Semantic_Labeling_Carrier.Arg
                  (Arith.minus_nat n Arith.one_nat))))
          (Xmlt.xml_dispatch_two (Arith.explode "sum") "sum"
            (Xmlt.xml_take_many_sub [] Arith.zero_nat Extended_Nat.Infinity_enat
              arith_fun
              (\ asa -> Xmlt.xml_return (Semantic_Labeling_Carrier.Sum asa)))
            (Arith.explode "product") "product"
            (Xmlt.xml_take_many_sub [] Arith.zero_nat Extended_Nat.Infinity_enat
              arith_fun
              (\ asa -> Xmlt.xml_return (Semantic_Labeling_Carrier.Prod asa)))
            (Xmlt.xml_dispatch_two (Arith.explode "max") "max"
              (Xmlt.xml_take_many_sub [] Arith.zero_nat
                Extended_Nat.Infinity_enat arith_fun
                (\ asa -> Xmlt.xml_return (Semantic_Labeling_Carrier.Max asa)))
              (Arith.explode "min") "min"
              (Xmlt.xml_take_many_sub [] Arith.zero_nat
                Extended_Nat.Infinity_enat arith_fun
                (\ a -> Xmlt.xml_return (Semantic_Labeling_Carrier.Min a)))
              (Xmlt.xml_do_prepared (Arith.explode "ifEqual") "ifEqual"
                (Xmlt.xml_take arith_fun
                  (\ a ->
                    Xmlt.xml_take arith_fun
                      (\ b ->
                        Xmlt.xml_take arith_fun
                          (\ c ->
                            Xmlt.xml_take arith_fun
                              (\ d ->
                                Xmlt.xml_return
                                  (Semantic_Labeling_Carrier.IfEqual a b c
                                    d)))))))))))
      Xmlt.xml_return)
    xml;

int_coeff ::
  (Xml.Xml, ([([Arith.Char], [Arith.Char])], (Bool, ([String], [String])))) ->
    Strict_Sum.Sum_bot (Xmlt.Xml_error String) Arith.Int;
int_coeff = Xmlt.xml_int "integer";

vec_coeff ::
  forall a.
    ((Xml.Xml,
       ([([Arith.Char], [Arith.Char])], (Bool, ([String], [String])))) ->
      Strict_Sum.Sum_bot (Xmlt.Xml_error String) a) ->
      (Xml.Xml,
        ([([Arith.Char], [Arith.Char])], (Bool, ([String], [String])))) ->
        Strict_Sum.Sum_bot (Xmlt.Xml_error String) (Matrix.Vec a);
vec_coeff xml2coeff =
  Xmlt.xml_do_prepared (Arith.explode "vector") "vector"
    (Xmlt.xml_take_many_sub [] Arith.zero_nat Extended_Nat.Infinity_enat
      xml2coeff (\ a -> Xmlt.xml_return (Matrix.vec_of_list a)));

mat_coeff ::
  forall a.
    Arith.Nat ->
      a -> ((Xml.Xml,
              ([([Arith.Char], [Arith.Char])], (Bool, ([String], [String])))) ->
             Strict_Sum.Sum_bot (Xmlt.Xml_error String) a) ->
             (Xml.Xml,
               ([([Arith.Char], [Arith.Char])],
                 (Bool, ([String], [String])))) ->
               Strict_Sum.Sum_bot (Xmlt.Xml_error String) (Matrix.Mat a);
mat_coeff n ze xml2coeff =
  Xmlt.xml_do_or_prepared (Arith.explode "matrix") "matrix"
    (Xmlt.xml_take_many_sub [] Arith.zero_nat Extended_Nat.Infinity_enat
      (vec_coeff xml2coeff) (\ a -> Xmlt.xml_return (Matrix.mat_of_rows n a)))
    (Xmlt.xml_change (vec_coeff xml2coeff)
      (\ v ->
        Xmlt.xml_return
          (Matrix.mat n n
            (\ (i, j) ->
              (if Arith.equal_nat j Arith.zero_nat then Matrix.vec_index v i
                else ze)))));

nat_coeff ::
  (Xml.Xml, ([([Arith.Char], [Arith.Char])], (Bool, ([String], [String])))) ->
    Strict_Sum.Sum_bot (Xmlt.Xml_error String) Arith.Nat;
nat_coeff = Xmlt.xml_nat "nat";

precedence_weight_ac ::
  forall a.
    (Term_Rewriting.Showl a) => ((Xml.Xml,
                                   ([([Arith.Char], [Arith.Char])],
                                     (Bool, ([String], [String])))) ->
                                  Strict_Sum.Sum_bot (Xmlt.Xml_error String)
                                    a) ->
                                  (Xml.Xml,
                                    ([([Arith.Char], [Arith.Char])],
                                      (Bool, ([String], [String])))) ->
                                    Strict_Sum.Sum_bot (Xmlt.Xml_error String)
                                      (Arith.Nat ->
([((a, Arith.Nat), (Arith.Nat, (Arith.Nat, Bool)))], Arith.Nat));
precedence_weight_ac xml2name =
  Xmlt.xml_do_prepared (Arith.explode "precedenceWeight") "precedenceWeight"
    (Xmlt.xml_take_many_sub [] Arith.zero_nat Extended_Nat.Infinity_enat
      (Xmlt.xml_do_prepared (Arith.explode "precedenceWeightEntry")
        "precedenceWeightEntry"
        (Xmlt.xml_take xml2name
          (\ f ->
            Xmlt.xml_take (Xmlt.xml_nat "arity")
              (\ a ->
                Xmlt.xml_take (Xmlt.xml_nat "precedence")
                  (\ p ->
                    Xmlt.xml_take (Xmlt.xml_nat "weight")
                      (\ w ->
                        Xmlt.xml_take_default False (Xmlt.xml_bool "isAC")
                          (\ e -> Xmlt.xml_return ((f, a), (p, (w, e))))))))))
      (\ ret -> Xmlt.xml_return (\ a -> (ret, a))));

ac_knuth_bendix_order ::
  forall a.
    (Term_Rewriting.Showl a) => ((Xml.Xml,
                                   ([([Arith.Char], [Arith.Char])],
                                     (Bool, ([String], [String])))) ->
                                  Strict_Sum.Sum_bot (Xmlt.Xml_error String)
                                    a) ->
                                  (Xml.Xml,
                                    ([([Arith.Char], [Arith.Char])],
                                      (Bool, ([String], [String])))) ->
                                    Strict_Sum.Sum_bot (Xmlt.Xml_error String)
                                      (Reduction_Pair_Implementations.Redtriple_impl
a);
ac_knuth_bendix_order xml2name =
  Xmlt.xml_do_prepared (Arith.explode "ACKBO") "ACKBO"
    (Xmlt.xml_take (Xmlt.xml_nat "w0")
      (\ w0 ->
        Xmlt.xml_take (precedence_weight_ac xml2name)
          (\ prw ->
            Xmlt.xml_take_default [] (afs xml2name)
              (\ afsa ->
                Xmlt.xml_return
                  (Reduction_Pair_Implementations.ACKBO (prw w0) afsa)))));

precedence_weight ::
  forall a.
    (Term_Rewriting.Showl a) => ((Xml.Xml,
                                   ([([Arith.Char], [Arith.Char])],
                                     (Bool, ([String], [String])))) ->
                                  Strict_Sum.Sum_bot (Xmlt.Xml_error String)
                                    a) ->
                                  (Xml.Xml,
                                    ([([Arith.Char], [Arith.Char])],
                                      (Bool, ([String], [String])))) ->
                                    Strict_Sum.Sum_bot (Xmlt.Xml_error String)
                                      (Arith.Nat ->
([((a, Arith.Nat), (Arith.Nat, (Arith.Nat, Maybe [Arith.Nat])))], Arith.Nat));
precedence_weight xml2name =
  Xmlt.xml_do_prepared (Arith.explode "precedenceWeight") "precedenceWeight"
    (Xmlt.xml_take_many_sub [] Arith.zero_nat Extended_Nat.Infinity_enat
      (Xmlt.xml_do_prepared (Arith.explode "precedenceWeightEntry")
        "precedenceWeightEntry"
        (Xmlt.xml_take xml2name
          (\ f ->
            Xmlt.xml_take (Xmlt.xml_nat "arity")
              (\ a ->
                Xmlt.xml_take (Xmlt.xml_nat "precedence")
                  (\ p ->
                    Xmlt.xml_take (Xmlt.xml_nat "weight")
                      (\ w ->
                        Xmlt.xml_take_optional
                          (Xmlt.xml_do_prepared
                            (Arith.explode "subtermCoefficientEntries")
                            "subtermCoefficientEntries"
                            (Xmlt.xml_take_many_sub [] Arith.zero_nat
                              Extended_Nat.Infinity_enat (Xmlt.xml_nat "entry")
                              Xmlt.xml_return))
                          (\ e -> Xmlt.xml_return ((f, a), (p, (w, e))))))))))
      (\ ret -> Xmlt.xml_return (\ a -> (ret, a))));

knuth_bendix_order ::
  forall a.
    (Term_Rewriting.Showl a) => ((Xml.Xml,
                                   ([([Arith.Char], [Arith.Char])],
                                     (Bool, ([String], [String])))) ->
                                  Strict_Sum.Sum_bot (Xmlt.Xml_error String)
                                    a) ->
                                  (Xml.Xml,
                                    ([([Arith.Char], [Arith.Char])],
                                      (Bool, ([String], [String])))) ->
                                    Strict_Sum.Sum_bot (Xmlt.Xml_error String)
                                      (Reduction_Pair_Implementations.Redtriple_impl
a);
knuth_bendix_order xml2name =
  Xmlt.xml_do_prepared (Arith.explode "knuthBendixOrder") "knuthBendixOrder"
    (Xmlt.xml_take (Xmlt.xml_nat "w0")
      (\ w0 ->
        Xmlt.xml_take (precedence_weight xml2name)
          (\ prw ->
            Xmlt.xml_take_default [] (afs xml2name)
              (\ afsa ->
                Xmlt.xml_return
                  (Reduction_Pair_Implementations.KBO (prw w0) afsa)))));

max_monus_parser ::
  (Xml.Xml, ([([Arith.Char], [Arith.Char])], (Bool, ([String], [String])))) ->
    Strict_Sum.Sum_bot (Xmlt.Xml_error String)
      (Term_Rewriting.Term Max_Monus.Sig Arith.Nat);
max_monus_parser xml =
  Xmlt.xml_dispatch_two (Arith.explode "sum") "sum"
    (Xmlt.xml_take_many_sub [] Arith.zero_nat Extended_Nat.Infinity_enat
      max_monus_parser
      (\ exps -> Xmlt.xml_return (Term_Rewriting.Fun Max_Monus.SumF exps)))
    (Arith.explode "max") "max"
    (Xmlt.xml_take_many_sub [] Arith.one_nat Extended_Nat.Infinity_enat
      max_monus_parser
      (\ exps -> Xmlt.xml_return (Term_Rewriting.Fun Max_Monus.MaxF exps)))
    (Xmlt.xml_dispatch_two (Arith.explode "maxExt") "maxExt"
      (Xmlt.xml_take (Xmlt.xml_nat "min")
        (\ c0 ->
          Xmlt.xml_take_many_sub [] Arith.zero_nat Extended_Nat.Infinity_enat
            (Xmlt.xml_do_prepared (Arith.explode "maxExtEntry") "maxExtEntry"
              (Xmlt.xml_take (Xmlt.xml_int "intercept")
                (\ c ->
                  Xmlt.xml_take (Xmlt.xml_nat "slope")
                    (\ d ->
                      Xmlt.xml_take max_monus_parser
                        (\ e -> Xmlt.xml_return ((c, d), e))))))
            (\ cdes ->
              Xmlt.xml_return
                (Term_Rewriting.Fun (Max_Monus.MaxExtF c0 (map fst cdes))
                  (map snd cdes)))))
      (Arith.explode "constant") "constant"
      (Xmlt.xml_take_nat
        (\ n -> Xmlt.xml_return (Term_Rewriting.Fun (Max_Monus.ConstF n) [])))
      (Xmlt.xml_do_prepared (Arith.explode "variable") "variable"
        (Xmlt.xml_take_nat
          (\ n ->
            Xmlt.xml_return
              (Term_Rewriting.Var (Arith.minus_nat n Arith.one_nat))))))
    xml;

precedence_list ::
  forall a.
    (Term_Rewriting.Showl a) => ((Xml.Xml,
                                   ([([Arith.Char], [Arith.Char])],
                                     (Bool, ([String], [String])))) ->
                                  Strict_Sum.Sum_bot (Xmlt.Xml_error String)
                                    a) ->
                                  (Xml.Xml,
                                    ([([Arith.Char], [Arith.Char])],
                                      (Bool, ([String], [String])))) ->
                                    Strict_Sum.Sum_bot (Xmlt.Xml_error String)
                                      [((a, Arith.Nat), Arith.Nat)];
precedence_list xml2name =
  Xmlt.xml_do_prepared (Arith.explode "precedenceList") "precedenceList"
    (Xmlt.xml_take_many_sub [] Arith.zero_nat Extended_Nat.Infinity_enat
      (Xmlt.xml_do_prepared (Arith.explode "precedenceListEntry")
        "precedenceListEntry"
        (Xmlt.xml_take xml2name
          (\ f ->
            Xmlt.xml_take (Xmlt.xml_nat "arity")
              (\ a ->
                Xmlt.xml_take (Xmlt.xml_nat "precedence")
                  (\ p -> Xmlt.xml_return ((f, a), p))))))
      Xmlt.xml_return);

max_poly_parser ::
  (Xml.Xml, ([([Arith.Char], [Arith.Char])], (Bool, ([String], [String])))) ->
    Strict_Sum.Sum_bot (Xmlt.Xml_error String)
      (Term_Rewriting.Term Max_Polynomial.Sig Arith.Nat);
max_poly_parser xml =
  Xmlt.xml_dispatch_two (Arith.explode "product") "product"
    (Xmlt.xml_take_many_sub [] Arith.zero_nat Extended_Nat.Infinity_enat
      max_poly_parser
      (\ exps ->
        Xmlt.xml_return (Term_Rewriting.Fun Max_Polynomial.ProdF exps)))
    (Arith.explode "sum") "sum"
    (Xmlt.xml_take_many_sub [] Arith.zero_nat Extended_Nat.Infinity_enat
      max_poly_parser
      (\ exps -> Xmlt.xml_return (Term_Rewriting.Fun Max_Polynomial.SumF exps)))
    (Xmlt.xml_dispatch_two (Arith.explode "max") "max"
      (Xmlt.xml_take_many_sub [] Arith.one_nat Extended_Nat.Infinity_enat
        max_poly_parser
        (\ exps ->
          Xmlt.xml_return (Term_Rewriting.Fun Max_Polynomial.MaxF exps)))
      (Arith.explode "constant") "constant"
      (Xmlt.xml_take_nat
        (\ n ->
          Xmlt.xml_return (Term_Rewriting.Fun (Max_Polynomial.ConstF n) [])))
      (Xmlt.xml_do_prepared (Arith.explode "variable") "variable"
        (Xmlt.xml_take_nat
          (\ n ->
            Xmlt.xml_return
              (Term_Rewriting.Var (Arith.minus_nat n Arith.one_nat))))))
    xml;

arctic_rat_linear_poly ::
  forall a.
    Interpretation a ->
      ((a, Arith.Nat),
        (Term_Rewriting.Arctic_delta Term_Rewriting.Rat,
          [Term_Rewriting.Arctic_delta Term_Rewriting.Rat]));
arctic_rat_linear_poly (Arctic_rat_linear_poly x4) = x4;

real_non_linear_poly ::
  forall a.
    Interpretation a ->
      ((a, Arith.Nat), [(Polynomials.Monom Arith.Nat, Term_Rewriting.Real)]);
real_non_linear_poly (Real_non_linear_poly x15) = x15;

rat_non_linear_poly ::
  forall a.
    Interpretation a ->
      ((a, Arith.Nat), [(Polynomials.Monom Arith.Nat, Term_Rewriting.Rat)]);
rat_non_linear_poly (Rat_non_linear_poly x14) = x14;

int_non_linear_poly ::
  forall a.
    Interpretation a ->
      ((a, Arith.Nat), [(Polynomials.Monom Arith.Nat, Arith.Int)]);
int_non_linear_poly (Int_non_linear_poly x13) = x13;

arctic_linear_poly ::
  forall a.
    Interpretation a ->
      ((a, Arith.Nat), (Term_Rewriting.Arctic, [Term_Rewriting.Arctic]));
arctic_linear_poly (Arctic_linear_poly x3) = x3;

arctic_rat_matrix ::
  forall a.
    Interpretation a ->
      ((a, Arith.Nat),
        (Matrix.Mat (Term_Rewriting.Arctic_delta Term_Rewriting.Rat),
          [Matrix.Mat (Term_Rewriting.Arctic_delta Term_Rewriting.Rat)]));
arctic_rat_matrix (Arctic_rat_matrix x9) = x9;

real_linear_poly ::
  forall a.
    Interpretation a ->
      ((a, Arith.Nat), (Term_Rewriting.Real, [Term_Rewriting.Real]));
real_linear_poly (Real_linear_poly x5) = x5;

real_core_matrix ::
  forall a.
    Interpretation a ->
      ((a, Arith.Nat),
        (Matrix.Mat Term_Rewriting.Real, [Matrix.Mat Term_Rewriting.Real]));
real_core_matrix (Real_core_matrix x121 x122) = x122;

rat_linear_poly ::
  forall a.
    Interpretation a ->
      ((a, Arith.Nat), (Term_Rewriting.Rat, [Term_Rewriting.Rat]));
rat_linear_poly (Rat_linear_poly x2) = x2;

int_linear_poly ::
  forall a. Interpretation a -> ((a, Arith.Nat), (Arith.Int, [Arith.Int]));
int_linear_poly (Int_linear_poly x1) = x1;

int_core_matrix ::
  forall a.
    Interpretation a ->
      ((a, Arith.Nat), (Matrix.Mat Arith.Int, [Matrix.Mat Arith.Int]));
int_core_matrix (Int_core_matrix x11) = x11;

arctic_matrix ::
  forall a.
    Interpretation a ->
      ((a, Arith.Nat),
        (Matrix.Mat Term_Rewriting.Arctic, [Matrix.Mat Term_Rewriting.Arctic]));
arctic_matrix (Arctic_matrix x8) = x8;

real_matrix ::
  forall a.
    Interpretation a ->
      ((a, Arith.Nat),
        (Matrix.Mat Term_Rewriting.Real, [Matrix.Mat Term_Rewriting.Real]));
real_matrix (Real_matrix x10) = x10;

rat_matrix ::
  forall a.
    Interpretation a ->
      ((a, Arith.Nat),
        (Matrix.Mat Term_Rewriting.Rat, [Matrix.Mat Term_Rewriting.Rat]));
rat_matrix (Rat_matrix x7) = x7;

int_matrix ::
  forall a.
    Interpretation a ->
      ((a, Arith.Nat), (Matrix.Mat Arith.Int, [Matrix.Mat Arith.Int]));
int_matrix (Int_matrix x6) = x6;

real_domain ::
  (Xml.Xml, ([([Arith.Char], [Arith.Char])], (Bool, ([String], [String])))) ->
    Strict_Sum.Sum_bot (Xmlt.Xml_error String) Term_Rewriting.Real;
real_domain =
  Xmlt.xml_do_prepared (Arith.explode "algebraicNumbers") "algebraicNumbers"
    (Xmlt.xml_take
      (Xmlt.xml_do_prepared (Arith.explode "delta") "delta"
        (Xmlt.xml_take xml_real (\ x -> Xmlt.xml_return (id x))))
      (\ x -> Xmlt.xml_return (id x)));

rat_domain ::
  (Xml.Xml, ([([Arith.Char], [Arith.Char])], (Bool, ([String], [String])))) ->
    Strict_Sum.Sum_bot (Xmlt.Xml_error String) Term_Rewriting.Rat;
rat_domain =
  Xmlt.xml_do_prepared (Arith.explode "rationals") "rationals"
    (Xmlt.xml_take
      (Xmlt.xml_do_prepared (Arith.explode "delta") "delta"
        (Xmlt.xml_take xml_rat (\ x -> Xmlt.xml_return (id x))))
      (\ x -> Xmlt.xml_return (id x)));

basic_domain ::
  (Xml.Xml, ([([Arith.Char], [Arith.Char])], (Bool, ([String], [String])))) ->
    Strict_Sum.Sum_bot (Xmlt.Xml_error String) (Arith.Nat -> Domain);
basic_domain =
  Xmlt.xml_or (Xmlt.xml_leaf "naturals" Natural)
    (Xmlt.xml_or (Xmlt.xml_leaf "integers" (\ _ -> Integera))
      (Xmlt.xml_or (Xmlt.xml_leaf "negativeIntegers" (\ _ -> NegativeInteger))
        (Xmlt.xml_or (Xmlt.xml_change rat_domain (Xmlt.xml_return . Rational))
          (Xmlt.xml_or
            (Xmlt.xml_change real_domain (Xmlt.xml_return . Mini_Alg))
            (Xmlt.xml_do_prepared (Arith.explode "arctic") "arctic"
              (Xmlt.xml_take
                (Xmlt.xml_do_prepared (Arith.explode "domain") "domain"
                  (Xmlt.xml_take
                    (Xmlt.xml_or (Xmlt.xml_leaf "naturals" (\ _ -> Arctic))
                      (Xmlt.xml_or (Xmlt.xml_leaf "integers" (\ _ -> Arctic))
                        (Xmlt.xml_change rat_domain
                          (\ _ -> Xmlt.xml_return (\ _ -> Arctic_rat)))))
                    (\ x -> Xmlt.xml_return (id x))))
                (\ x -> Xmlt.xml_return (id x))))))));

interpretation_type ::
  (Xml.Xml, ([([Arith.Char], [Arith.Char])], (Bool, ([String], [String])))) ->
    Strict_Sum.Sum_bot (Xmlt.Xml_error String) Domain;
interpretation_type =
  Xmlt.xml_do_prepared (Arith.explode "type") "type"
    (Xmlt.xml_take
      (Xmlt.xml_dispatch_two (Arith.explode "matrixInterpretation")
        "matrixInterpretation"
        (Xmlt.xml_take
          (Xmlt.xml_do_prepared (Arith.explode "domain") "domain"
            (Xmlt.xml_take basic_domain (\ x -> Xmlt.xml_return (id x))))
          (\ a ->
            Xmlt.xml_take (Xmlt.xml_nat "dimension")
              (\ b ->
                Xmlt.xml_take (Xmlt.xml_nat "strictDimension")
                  (\ c ->
                    Xmlt.xml_return (case a Arith.zero_nat of {
                                      Natural _ -> Int_mat b c;
                                      Integera -> Int_mat b c;
                                      Arctic -> Arctic_mat b;
                                      Arctic_rat -> Arctic_rat_mat b;
                                      Rational _ _ -> Rat_mat b c;
                                      Mini_Alg _ _ -> Mini_Alg_mat b c;
                                    })))))
        (Arith.explode "coreMatrixInterpretation") "coreMatrixInterpretation"
        (Xmlt.xml_take
          (Xmlt.xml_do_prepared (Arith.explode "domain") "domain"
            (Xmlt.xml_take basic_domain (\ x -> Xmlt.xml_return (id x))))
          (\ domain ->
            Xmlt.xml_take (Xmlt.xml_nat "dimension")
              (\ di ->
                Xmlt.xml_take
                  (Xmlt.xml_do_prepared (Arith.explode "indices") "indices"
                    (Xmlt.xml_take_many_sub [] Arith.zero_nat
                      Extended_Nat.Infinity_enat nat_coeff
                      (\ a ->
                        Xmlt.xml_return
                          (map (\ x -> Arith.minus_nat x Arith.one_nat) a))))
                  (\ ids ->
                    Xmlt.xml_take
                      (Xmlt.xml_do_prepared (Arith.explode "mode") "mode"
                        (Xmlt.xml_take
                          (Xmlt.xml_or
                            (Xmlt.xml_leaf "E" Matrix_Core_Order_Impl.E_I)
                            (Xmlt.xml_leaf "M" Matrix_Core_Order_Impl.M_I))
                          Xmlt.xml_return))
                      (\ m ->
                        (case (case domain Arith.zero_nat of {
                                Natural _ -> Just Nothing;
                                Integera -> Just Nothing;
                                NegativeInteger -> Nothing;
                                Arctic -> Nothing;
                                Arctic_rat -> Nothing;
                                Int_mat _ _ -> Nothing;
                                Arctic_mat _ -> Nothing;
                                Arctic_rat_mat _ -> Nothing;
                                Rational r _ ->
                                  Just (Just (Term_Rewriting.ratreal r));
                                Rat_mat _ _ -> Nothing;
                                Mini_Alg r _ -> Just (Just r);
                                Mini_Alg_mat _ _ -> Nothing;
                                Int_core_mat _ _ _ -> Nothing;
                                Real_core_mat _ _ _ _ -> Nothing;
                              })
                          of {
                          Nothing ->
                            Xmlt.xml_error
                              "domain must be integers or rationals or reals in coreMatrixInterpretation";
                          Just Nothing ->
                            Xmlt.xml_return (Int_core_mat di ids m);
                          Just (Just d) ->
                            Xmlt.xml_return (Real_core_mat d di ids m);
                        }))))))
        (Xmlt.xml_do_prepared (Arith.explode "polynomial") "polynomial"
          (Xmlt.xml_take
            (Xmlt.xml_do_prepared (Arith.explode "domain") "domain"
              (Xmlt.xml_take
                (Xmlt.xml_or basic_domain
                  (Xmlt.xml_do_prepared (Arith.explode "matrices") "matrices"
                    (Xmlt.xml_take (Xmlt.xml_nat "dimension")
                      (\ a ->
                        Xmlt.xml_take (Xmlt.xml_nat "strictDimension")
                          (\ b ->
                            Xmlt.xml_take
                              (Xmlt.xml_do_prepared (Arith.explode "domain")
                                "domain"
                                (Xmlt.xml_take basic_domain
                                  (\ x -> Xmlt.xml_return (id x))))
                              (\ c ->
                                Xmlt.xml_return
                                  (\ d ->
                                    (case c d of {
                                      Natural _ -> Int_mat a b;
                                      Integera -> Int_mat a b;
                                      Arctic -> Arctic_mat a;
                                      Arctic_rat -> Arctic_rat_mat a;
                                      Rational _ _ -> Rat_mat a b;
                                      Mini_Alg _ _ -> Mini_Alg_mat a b;
                                    }))))))))
                (\ x -> Xmlt.xml_return (id x))))
            (\ a ->
              Xmlt.xml_take (Xmlt.xml_nat "degree")
                (\ b -> Xmlt.xml_return (a b))))))
      (\ x -> Xmlt.xml_return (id x)));

arctic_rat_coeff ::
  (Xml.Xml, ([([Arith.Char], [Arith.Char])], (Bool, ([String], [String])))) ->
    Strict_Sum.Sum_bot (Xmlt.Xml_error String)
      (Term_Rewriting.Arctic_delta Term_Rewriting.Rat);
arctic_rat_coeff =
  Xmlt.xml_or
    (Xmlt.xml_change xml_rat (Xmlt.xml_return . Term_Rewriting.Num_arc_delta))
    (Xmlt.xml_leaf "minusInfinity" Term_Rewriting.MinInfty_delta);

arctic_coeff ::
  (Xml.Xml, ([([Arith.Char], [Arith.Char])], (Bool, ([String], [String])))) ->
    Strict_Sum.Sum_bot (Xmlt.Xml_error String) Term_Rewriting.Arctic;
arctic_coeff =
  Xmlt.xml_or
    (Xmlt.xml_change int_coeff (Xmlt.xml_return . Term_Rewriting.Num_arc))
    (Xmlt.xml_leaf "minusInfinity" Term_Rewriting.MinInfty);

xml_change ::
  forall a b c d e.
    (a -> Strict_Sum.Sum_bot String b) ->
      a -> ([Xml.Xml], (c, (d, (e, [String])))) ->
             Strict_Sum.Sum_bot (Xmlt.Xml_error String) b;
xml_change f p x =
  Xmlt.bind2 (f p) (\ e -> Xmlt.xml_error e x) Strict_Sum.right;

polynomial ::
  forall a.
    ((Xml.Xml,
       ([([Arith.Char], [Arith.Char])], (Bool, ([String], [String])))) ->
      Strict_Sum.Sum_bot (Xmlt.Xml_error String) a) ->
      (Xml.Xml,
        ([([Arith.Char], [Arith.Char])], (Bool, ([String], [String])))) ->
        Strict_Sum.Sum_bot (Xmlt.Xml_error String)
          (Polynomials.Tpoly Arith.Nat a);
polynomial xml2coeff x =
  Xmlt.xml_or
    (Xmlt.xml_change xml2coeff (\ n -> Xmlt.xml_return (Polynomials.PNum n)))
    (Xmlt.xml_or
      (Xmlt.xml_change (Xmlt.xml_nat "variable")
        (\ n ->
          Xmlt.xml_return (Polynomials.PVar (Arith.minus_nat n Arith.one_nat))))
      (Xmlt.xml_do_or_prepared (Arith.explode "sum") "sum"
        (Xmlt.xml_take_many_sub [] Arith.zero_nat Extended_Nat.Infinity_enat
          (polynomial xml2coeff) (\ a -> Xmlt.xml_return (Polynomials.PSum a)))
        (Xmlt.xml_do_prepared (Arith.explode "product") "product"
          (Xmlt.xml_take_many_sub [] Arith.zero_nat Extended_Nat.Infinity_enat
            (polynomial xml2coeff)
            (\ a -> Xmlt.xml_return (Polynomials.PMult a))))))
    x;

fit_length ::
  forall a.
    Congruence.Partial_object_ext a (Group.Monoid_ext a (Ring.Ring_ext a ())) ->
      Arith.Nat -> [a] -> [a];
fit_length c n uu =
  (if Arith.equal_nat n Arith.zero_nat then []
    else (case uu of {
           [] -> Arith.replicate (Arith.suc (Arith.minus_nat n Arith.one_nat))
                   (Ring.zero c);
           b : bs -> b : fit_length c (Arith.minus_nat n Arith.one_nat) bs;
         }));

interpretation ::
  forall a.
    Bool ->
      ((Xml.Xml,
         ([([Arith.Char], [Arith.Char])], (Bool, ([String], [String])))) ->
        Strict_Sum.Sum_bot (Xmlt.Xml_error String) a) ->
        (Xml.Xml,
          ([([Arith.Char], [Arith.Char])], (Bool, ([String], [String])))) ->
          Strict_Sum.Sum_bot (Xmlt.Xml_error String)
            (Reduction_Pair_Implementations.Redtriple_impl a);
interpretation bi xml2name =
  Xmlt.xml_do_prepared (Arith.explode "interpretation") "interpretation"
    (Xmlt.xml_take interpretation_type
      (\ typea ->
        Xmlt.xml_take_many_sub [] Arith.zero_nat Extended_Nat.Infinity_enat
          (Xmlt.xml_do_prepared (Arith.explode "interpret") "interpret"
            (Xmlt.xml_take xml2name
              (\ f ->
                Xmlt.xml_take (Xmlt.xml_nat "arity")
                  (\ a ->
                    (case typea of {
                      Natural deg ->
                        (if Arith.less_eq_nat deg Arith.one_nat && not bi
                          then let {
                                 c = Ordered_Semiring.class_semiring HOL.Type
                                       ();
                               } in Xmlt.xml_take
                                      (Xmlt.xml_change (polynomial int_coeff)
(xml_change (lpoly_of c)))
                                      (\ poly ->
Xmlt.xml_return
  (Int_linear_poly ((f, a), (fst poly, fit_length c a (snd poly)))))
                          else Xmlt.xml_take
                                 (Xmlt.xml_change (polynomial int_coeff)
                                   (Xmlt.xml_return . Polynomials.poly_of))
                                 (\ poly ->
                                   Xmlt.xml_return
                                     (Int_non_linear_poly ((f, a), poly))));
                      Integera ->
                        Xmlt.xml_take
                          (Xmlt.xml_change (polynomial int_coeff)
                            (Xmlt.xml_return . Polynomials.poly_of))
                          (\ poly ->
                            Xmlt.xml_return
                              (Int_non_linear_poly ((f, a), poly)));
                      NegativeInteger ->
                        Xmlt.xml_take
                          (Xmlt.xml_change (polynomial int_coeff)
                            (Xmlt.xml_return . Polynomials.poly_of))
                          (\ poly ->
                            Xmlt.xml_return
                              (Int_non_linear_poly ((f, a), poly)));
                      Arctic ->
                        let {
                          c = Ordered_Semiring.class_semiring HOL.Type ();
                        } in Xmlt.xml_take
                               (Xmlt.xml_change (polynomial arctic_coeff)
                                 (xml_change (lpoly_of c)))
                               (\ poly ->
                                 Xmlt.xml_return
                                   (Arctic_linear_poly
                                     ((f, a),
                                       (fst poly, fit_length c a (snd poly)))));
                      Arctic_rat ->
                        let {
                          c = Ordered_Semiring.class_semiring HOL.Type ();
                        } in Xmlt.xml_take
                               (Xmlt.xml_change (polynomial arctic_rat_coeff)
                                 (xml_change (lpoly_of c)))
                               (\ poly ->
                                 Xmlt.xml_return
                                   (Arctic_rat_linear_poly
                                     ((f, a),
                                       (fst poly, fit_length c a (snd poly)))));
                      Int_mat n _ ->
                        let {
                          c = Matrix.ring_mat HOL.Type n ();
                        } in Xmlt.xml_take
                               (Xmlt.xml_change
                                 (polynomial
                                   (mat_coeff n Arith.zero_int int_coeff))
                                 (xml_change (lpoly_of c)))
                               (\ poly ->
                                 Xmlt.xml_return
                                   (Int_matrix
                                     ((f, a),
                                       (fst poly, fit_length c a (snd poly)))));
                      Arctic_mat n ->
                        let {
                          c = Matrix.ring_mat HOL.Type n ();
                        } in Xmlt.xml_take
                               (Xmlt.xml_change
                                 (polynomial
                                   (mat_coeff n Term_Rewriting.zero_arctic
                                     arctic_coeff))
                                 (xml_change (lpoly_of c)))
                               (\ poly ->
                                 Xmlt.xml_return
                                   (Arctic_matrix
                                     ((f, a),
                                       (fst poly, fit_length c a (snd poly)))));
                      Arctic_rat_mat n ->
                        let {
                          c = Matrix.ring_mat HOL.Type n ();
                        } in Xmlt.xml_take
                               (Xmlt.xml_change
                                 (polynomial
                                   (mat_coeff n Term_Rewriting.zero_arctic_delta
                                     arctic_rat_coeff))
                                 (xml_change (lpoly_of c)))
                               (\ poly ->
                                 Xmlt.xml_return
                                   (Arctic_rat_matrix
                                     ((f, a),
                                       (fst poly, fit_length c a (snd poly)))));
                      Rational _ deg ->
                        (if Arith.less_eq_nat deg Arith.one_nat && not bi
                          then let {
                                 c = Ordered_Semiring.class_semiring HOL.Type
                                       ();
                               } in Xmlt.xml_take
                                      (Xmlt.xml_change (polynomial xml_rat)
(xml_change (lpoly_of c)))
                                      (\ poly ->
Xmlt.xml_return
  (Rat_linear_poly ((f, a), (fst poly, fit_length c a (snd poly)))))
                          else Xmlt.xml_take
                                 (Xmlt.xml_change (polynomial xml_rat)
                                   (Xmlt.xml_return . Polynomials.poly_of))
                                 (\ poly ->
                                   Xmlt.xml_return
                                     (Rat_non_linear_poly ((f, a), poly))));
                      Rat_mat n _ ->
                        let {
                          c = Matrix.ring_mat HOL.Type n ();
                        } in Xmlt.xml_take
                               (Xmlt.xml_change
                                 (polynomial
                                   (mat_coeff n Term_Rewriting.zero_rat
                                     xml_rat))
                                 (xml_change (lpoly_of c)))
                               (\ poly ->
                                 Xmlt.xml_return
                                   (Rat_matrix
                                     ((f, a),
                                       (fst poly, fit_length c a (snd poly)))));
                      Mini_Alg _ deg ->
                        (if Arith.less_eq_nat deg Arith.one_nat && not bi
                          then let {
                                 c = Ordered_Semiring.class_semiring HOL.Type
                                       ();
                               } in Xmlt.xml_take
                                      (Xmlt.xml_change (polynomial xml_real)
(xml_change (lpoly_of c)))
                                      (\ poly ->
Xmlt.xml_return
  (Real_linear_poly ((f, a), (fst poly, fit_length c a (snd poly)))))
                          else Xmlt.xml_take
                                 (Xmlt.xml_change (polynomial xml_real)
                                   (Xmlt.xml_return . Polynomials.poly_of))
                                 (\ poly ->
                                   Xmlt.xml_return
                                     (Real_non_linear_poly ((f, a), poly))));
                      Mini_Alg_mat n _ ->
                        let {
                          c = Matrix.ring_mat HOL.Type n ();
                        } in Xmlt.xml_take
                               (Xmlt.xml_change
                                 (polynomial
                                   (mat_coeff n Term_Rewriting.zero_real
                                     xml_real))
                                 (xml_change (lpoly_of c)))
                               (\ poly ->
                                 Xmlt.xml_return
                                   (Real_matrix
                                     ((f, a),
                                       (fst poly, fit_length c a (snd poly)))));
                      Int_core_mat n _ _ ->
                        let {
                          c = Matrix.ring_mat HOL.Type n ();
                        } in Xmlt.xml_take
                               (Xmlt.xml_change
                                 (polynomial
                                   (mat_coeff n Arith.zero_int int_coeff))
                                 (xml_change (lpoly_of c)))
                               (\ poly ->
                                 Xmlt.xml_return
                                   (Int_core_matrix
                                     ((f, a),
                                       (fst poly, fit_length c a (snd poly)))));
                      Real_core_mat d n _ _ ->
                        let {
                          c = Matrix.ring_mat HOL.Type n ();
                        } in Xmlt.xml_take
                               (Xmlt.xml_change
                                 (polynomial
                                   (mat_coeff n Term_Rewriting.zero_real
                                     xml_real))
                                 (xml_change (lpoly_of c)))
                               (\ poly ->
                                 Xmlt.xml_return
                                   (Real_core_matrix d
                                     ((f, a),
                                       (fst poly, fit_length c a (snd poly)))));
                    })))))
          (\ pi ->
            Xmlt.xml_return
              (case typea of {
                Natural deg ->
                  (if Arith.less_eq_nat deg Arith.one_nat && not bi
                    then Reduction_Pair_Implementations.Int_carrier
                           (map int_linear_poly pi)
                    else Reduction_Pair_Implementations.Int_nl_carrier
                           (map int_non_linear_poly pi));
                Integera ->
                  Reduction_Pair_Implementations.Int_nl_carrier
                    (map int_non_linear_poly pi);
                NegativeInteger ->
                  Reduction_Pair_Implementations.Neg_Integer_Poly
                    (map int_non_linear_poly pi);
                Arctic ->
                  Reduction_Pair_Implementations.Arctic_carrier
                    (map arctic_linear_poly pi);
                Arctic_rat ->
                  Reduction_Pair_Implementations.Arctic_rat_carrier
                    (map arctic_rat_linear_poly pi);
                Int_mat n sd ->
                  Reduction_Pair_Implementations.Int_mat_carrier n sd
                    (map int_matrix pi);
                Arctic_mat n ->
                  Reduction_Pair_Implementations.Arctic_mat_carrier n
                    (map arctic_matrix pi);
                Arctic_rat_mat n ->
                  Reduction_Pair_Implementations.Arctic_rat_mat_carrier n
                    (map arctic_rat_matrix pi);
                Rational d deg ->
                  (if Arith.less_eq_nat deg Arith.one_nat && not bi
                    then Reduction_Pair_Implementations.Rat_carrier
                           (map rat_linear_poly pi)
                    else Reduction_Pair_Implementations.Rat_nl_carrier d
                           (map rat_non_linear_poly pi));
                Rat_mat n sd ->
                  Reduction_Pair_Implementations.Rat_mat_carrier n sd
                    (map rat_matrix pi);
                Mini_Alg d deg ->
                  (if Arith.less_eq_nat deg Arith.one_nat && not bi
                    then Reduction_Pair_Implementations.Real_carrier
                           (map real_linear_poly pi)
                    else Reduction_Pair_Implementations.Real_nl_carrier d
                           (map real_non_linear_poly pi));
                Mini_Alg_mat n sd ->
                  Reduction_Pair_Implementations.Real_mat_carrier n sd
                    (map real_matrix pi);
                Int_core_mat n ids m ->
                  Reduction_Pair_Implementations.Core_matrix
                    (Matrix_Core_Order_Impl.Core_Matrix_Inter m n ids
                      (map (\ (f, (c, cs)) -> (f, (cs, c)))
                        (map int_core_matrix pi)));
                Real_core_mat d n ids m ->
                  Reduction_Pair_Implementations.Core_matrix_delta d
                    (Matrix_Core_Order_Impl.Core_Matrix_Inter m n ids
                      (map (\ (f, (c, cs)) -> (f, (cs, c)))
                        (map real_core_matrix pi)));
              }))));

level_mapping ::
  forall a.
    (Term_Rewriting.Showl a) => ((Xml.Xml,
                                   ([([Arith.Char], [Arith.Char])],
                                     (Bool, ([String], [String])))) ->
                                  Strict_Sum.Sum_bot (Xmlt.Xml_error String)
                                    a) ->
                                  (Xml.Xml,
                                    ([([Arith.Char], [Arith.Char])],
                                      (Bool, ([String], [String])))) ->
                                    Strict_Sum.Sum_bot (Xmlt.Xml_error String)
                                      [((a, Arith.Nat),
 [(Arith.Nat, Arith.Nat)])];
level_mapping xml2name =
  Xmlt.xml_do_prepared (Arith.explode "levelMapping") "levelMapping"
    (Xmlt.xml_take_many_sub [] Arith.zero_nat Extended_Nat.Infinity_enat
      (Xmlt.xml_do_prepared (Arith.explode "levelMappingEntry")
        "levelMappingEntry"
        (Xmlt.xml_take xml2name
          (\ f ->
            Xmlt.xml_take (Xmlt.xml_nat "arity")
              (\ a ->
                Xmlt.xml_take_many_sub [] Arith.zero_nat
                  Extended_Nat.Infinity_enat
                  (Xmlt.xml_do_prepared (Arith.explode "positionLevelEntry")
                    "positionLevelEntry"
                    (Xmlt.xml_take (Xmlt.xml_nat "position")
                      (\ aa ->
                        Xmlt.xml_take (Xmlt.xml_nat "level")
                          (\ b -> Xmlt.xml_return (aa, b)))))
                  (\ ps ->
                    Xmlt.xml_return
                      ((f, a),
                        map (\ (p, b) ->
                              ((if Arith.equal_nat p Arith.zero_nat then a
                                 else Arith.minus_nat p Arith.one_nat),
                                b))
                          ps))))))
      Xmlt.xml_return);

wpo_params ::
  forall a.
    (Term_Rewriting.Showl a) => ((Xml.Xml,
                                   ([([Arith.Char], [Arith.Char])],
                                     (Bool, ([String], [String])))) ->
                                  Strict_Sum.Sum_bot (Xmlt.Xml_error String)
                                    a) ->
                                  (Xml.Xml,
                                    ([([Arith.Char], [Arith.Char])],
                                      (Bool, ([String], [String])))) ->
                                    Strict_Sum.Sum_bot (Xmlt.Xml_error String)
                                      [((a, Arith.Nat),
 (Arith.Nat, ([Arith.Nat], WPO.Order_tag)))];
wpo_params xml2name =
  Xmlt.xml_do_prepared (Arith.explode "precedenceStatus") "precedenceStatus"
    (Xmlt.xml_take_many_sub [] Arith.zero_nat Extended_Nat.Infinity_enat
      (Xmlt.xml_do_prepared (Arith.explode "precedenceStatusEntry")
        "precedenceStatusEntry"
        (Xmlt.xml_take xml2name
          (\ f ->
            Xmlt.xml_take (Xmlt.xml_nat "arity")
              (\ a ->
                Xmlt.xml_take (Xmlt.xml_nat "precedence")
                  (\ p ->
                    Xmlt.xml_take_optional
                      (Xmlt.xml_or (Xmlt.xml_leaf "lex" WPO.Lex)
                        (Xmlt.xml_leaf "mul" WPO.Mul))
                      (\ ot ->
                        Xmlt.xml_take
                          (Xmlt.xml_do_prepared (Arith.explode "status")
                            "status"
                            (Xmlt.xml_take_many_sub [] Arith.zero_nat
                              Extended_Nat.Infinity_enat
                              CPF_Input_Parser.position Xmlt.xml_return))
                          (\ s ->
                            Xmlt.xml_return
                              ((f, a), (p, (s, (case ot of {
         Nothing -> WPO.Lex;
         Just lm -> lm;
       })))))))))))
      Xmlt.xml_return);

status_precedence ::
  forall a.
    (Term_Rewriting.Showl a) => ((Xml.Xml,
                                   ([([Arith.Char], [Arith.Char])],
                                     (Bool, ([String], [String])))) ->
                                  Strict_Sum.Sum_bot (Xmlt.Xml_error String)
                                    a) ->
                                  (Xml.Xml,
                                    ([([Arith.Char], [Arith.Char])],
                                      (Bool, ([String], [String])))) ->
                                    Strict_Sum.Sum_bot (Xmlt.Xml_error String)
                                      [((a, Arith.Nat),
 (Arith.Nat, WPO.Order_tag))];
status_precedence xml2name =
  Xmlt.xml_do_prepared (Arith.explode "statusPrecedence") "statusPrecedence"
    (Xmlt.xml_take_many_sub [] Arith.zero_nat Extended_Nat.Infinity_enat
      (Xmlt.xml_do_prepared (Arith.explode "statusPrecedenceEntry")
        "statusPrecedenceEntry"
        (Xmlt.xml_take xml2name
          (\ f ->
            Xmlt.xml_take (Xmlt.xml_nat "arity")
              (\ a ->
                Xmlt.xml_take (Xmlt.xml_nat "precedence")
                  (\ p ->
                    Xmlt.xml_take
                      (Xmlt.xml_or (Xmlt.xml_leaf "lex" WPO.Lex)
                        (Xmlt.xml_leaf "mul" WPO.Mul))
                      (\ s -> Xmlt.xml_return ((f, a), (p, s))))))))
      Xmlt.xml_return);

path_order ::
  forall a.
    (Term_Rewriting.Showl a) => ((Xml.Xml,
                                   ([([Arith.Char], [Arith.Char])],
                                     (Bool, ([String], [String])))) ->
                                  Strict_Sum.Sum_bot (Xmlt.Xml_error String)
                                    a) ->
                                  (Xml.Xml,
                                    ([([Arith.Char], [Arith.Char])],
                                      (Bool, ([String], [String])))) ->
                                    Strict_Sum.Sum_bot (Xmlt.Xml_error String)
                                      (Reduction_Pair_Implementations.Redtriple_impl
a);
path_order xml2name =
  Xmlt.xml_do_prepared (Arith.explode "recursivePathOrder") "recursivePathOrder"
    (Xmlt.xml_take (status_precedence xml2name)
      (\ prec_tau ->
        Xmlt.xml_take_default [] (afs xml2name)
          (\ af ->
            Xmlt.xml_return (Reduction_Pair_Implementations.RPO prec_tau af))));

redtriple ::
  forall a.
    (Term_Rewriting.Showl a) => ((Xml.Xml,
                                   ([([Arith.Char], [Arith.Char])],
                                     (Bool, ([String], [String])))) ->
                                  Strict_Sum.Sum_bot (Xmlt.Xml_error String)
                                    a) ->
                                  (a -> a) ->
                                    Bool ->
                                      (Xml.Xml,
([([Arith.Char], [Arith.Char])], (Bool, ([String], [String])))) ->
Strict_Sum.Sum_bot (Xmlt.Xml_error String)
  (Reduction_Pair_Implementations.Redtriple_impl a);
redtriple xml2name shp bi xml =
  Xmlt.xml_or (path_order xml2name)
    (Xmlt.xml_or (knuth_bendix_order xml2name)
      (Xmlt.xml_or (ac_knuth_bendix_order xml2name)
        (Xmlt.xml_or (interpretation bi xml2name)
          (Xmlt.xml_do_or_prepared (Arith.explode "maxPoly") "maxPoly"
            (Xmlt.xml_take_many_sub [] Arith.zero_nat Extended_Nat.Infinity_enat
              (Xmlt.xml_do_prepared (Arith.explode "interpret") "interpret"
                (Xmlt.xml_take xml2name
                  (\ f ->
                    Xmlt.xml_take (Xmlt.xml_nat "arity")
                      (\ a ->
                        Xmlt.xml_take max_poly_parser
                          (\ e -> Xmlt.xml_return ((f, a), e))))))
              (\ inters ->
                Xmlt.xml_return
                  (Reduction_Pair_Implementations.Max_poly inters)))
            (Xmlt.xml_dispatch_two (Arith.explode "maxMonus") "maxMonus"
              (Xmlt.xml_take_many_sub [] Arith.zero_nat
                Extended_Nat.Infinity_enat
                (Xmlt.xml_do_prepared (Arith.explode "interpret") "interpret"
                  (Xmlt.xml_take xml2name
                    (\ f ->
                      Xmlt.xml_take (Xmlt.xml_nat "arity")
                        (\ a ->
                          Xmlt.xml_take max_monus_parser
                            (\ e -> Xmlt.xml_return ((f, a), e))))))
                (\ inters ->
                  Xmlt.xml_return
                    (Reduction_Pair_Implementations.Max_monus inters)))
              (Arith.explode "coWeightedPathOrder") "coWeightedPathOrder"
              (Xmlt.xml_take (wpo_params xml2name)
                (\ a ->
                  Xmlt.xml_take (redtriple xml2name shp bi)
                    (\ b ->
                      Xmlt.xml_return
                        (Reduction_Pair_Implementations.COWPO a b))))
              (Xmlt.xml_dispatch_two (Arith.explode "weightedPathOrder")
                "weightedPathOrder"
                (Xmlt.xml_take (wpo_params xml2name)
                  (\ a ->
                    Xmlt.xml_take (redtriple xml2name shp bi)
                      (\ b ->
                        Xmlt.xml_return
                          (Reduction_Pair_Implementations.WPO a b))))
                (Arith.explode "generalizedWeightedPathOrder")
                "generalizedWeightedPathOrder"
                (Xmlt.xml_take (precedence_list xml2name)
                  (\ pr ->
                    Xmlt.xml_take (redtriple xml2name shp bi)
                      (\ b ->
                        Xmlt.xml_return
                          (Reduction_Pair_Implementations.GWPO (pr, shp) b))))
                (Xmlt.xml_dispatch_two
                  (Arith.explode "monotonicSemanticPathOrder")
                  "monotonicSemanticPathOrder"
                  (Xmlt.xml_take (redtriple xml2name shp bi)
                    (\ a ->
                      Xmlt.xml_return (Reduction_Pair_Implementations.MSPO a)))
                  (Arith.explode "filteredRedPair") "filteredRedPair"
                  (Xmlt.xml_take_default [] (afs xml2name)
                    (\ af ->
                      Xmlt.xml_take (redtriple xml2name shp bi)
                        (\ b ->
                          Xmlt.xml_return
                            (Reduction_Pair_Implementations.Filtered_Redtriple
                              af b))))
                  (Xmlt.xml_do_prepared (Arith.explode "scnp") "scnp"
                    (Xmlt.xml_take
                      (Xmlt.xml_do_prepared (Arith.explode "status") "status"
                        (Xmlt.xml_take
                          (Xmlt.xml_or
                            (Xmlt.xml_leaf "ms"
                              List_Order_Implementations.MS_Ext)
                            (Xmlt.xml_or
                              (Xmlt.xml_leaf "min"
                                List_Order_Implementations.Min_Ext)
                              (Xmlt.xml_or
                                (Xmlt.xml_leaf "dms"
                                  List_Order_Implementations.Dms_Ext)
                                (Xmlt.xml_leaf "max"
                                  List_Order_Implementations.Max_Ext))))
                          Xmlt.xml_return))
                      (\ a ->
                        Xmlt.xml_take (level_mapping xml2name)
                          (\ b ->
                            Xmlt.xml_take (redtriple xml2name shp False)
                              (\ c ->
                                Xmlt.xml_return
                                  (Reduction_Pair_Implementations.SCNP a b
                                    c)))))))))))))
    xml;

xml2crit_pair_info ::
  forall a.
    (Term_Rewriting.Showl a) => ((Xml.Xml,
                                   ([([Arith.Char], [Arith.Char])],
                                     (Bool, ([String], [String])))) ->
                                  Strict_Sum.Sum_bot (Xmlt.Xml_error String)
                                    a) ->
                                  Mapping.Mapping [Arith.Char]
                                    (Term_Rewriting.Term a [Arith.Char]) ->
                                    (Xml.Xml,
                                      ([([Arith.Char], [Arith.Char])],
(Bool, ([String], [String])))) ->
                                      Strict_Sum.Sum_bot (Xmlt.Xml_error String)
(Check_Joins.Crit_pair_info a [Arith.Char]);
xml2crit_pair_info xml2name termIndexMap =
  Xmlt.xml_do_prepared (Arith.explode "critPairInfo") "critPairInfo"
    (Xmlt.xml_take
      (Xmlt.xml_do_prepared (Arith.explode "left") "left"
        (Xmlt.xml_take (CPF_Input_Parser.term xml2name termIndexMap)
          (\ x -> Xmlt.xml_return (id x))))
      (\ s ->
        Xmlt.xml_take_optional
          (Xmlt.xml_do_prepared (Arith.explode "peak") "peak"
            (Xmlt.xml_take (CPF_Input_Parser.term xml2name termIndexMap)
              (\ x -> Xmlt.xml_return (id x))))
          (\ t ->
            Xmlt.xml_take
              (Xmlt.xml_do_prepared (Arith.explode "right") "right"
                (Xmlt.xml_take (CPF_Input_Parser.term xml2name termIndexMap)
                  (\ x -> Xmlt.xml_return (id x))))
              (\ u ->
                Xmlt.xml_take_optional
                  (Xmlt.xml_do_prepared (Arith.explode "overlapPositions")
                    "overlapPositions"
                    (Xmlt.xml_take_many_sub [] Arith.zero_nat
                      Extended_Nat.Infinity_enat CPF_Input_Parser.pos
                      Xmlt.xml_return))
                  (\ pos ->
                    Xmlt.xml_take_optional
                      (Xmlt.xml_do_prepared (Arith.explode "labels") "labels"
                        (Xmlt.xml_take (Xmlt.xml_nat "maxLeft")
                          (\ left ->
                            Xmlt.xml_take (Xmlt.xml_nat "right")
                              (\ right -> Xmlt.xml_return (left, right)))))
                      (\ labels ->
                        Xmlt.xml_take
                          (Xmlt.xml_do_prepared
                            (Arith.explode "intermediateTerms")
                            "intermediateTerms"
                            (Xmlt.xml_take_many_sub [] Arith.zero_nat
                              Extended_Nat.Infinity_enat
                              (CPF_Input_Parser.term xml2name termIndexMap)
                              Xmlt.xml_return))
                          (\ joins ->
                            Xmlt.xml_return
                              (Check_Joins.Crit_Pair_Info s t u joins pos
                                labels))))))));

joinSequences ::
  forall a.
    (Term_Rewriting.Showl a) => ((Xml.Xml,
                                   ([([Arith.Char], [Arith.Char])],
                                     (Bool, ([String], [String])))) ->
                                  Strict_Sum.Sum_bot (Xmlt.Xml_error String)
                                    a) ->
                                  Mapping.Mapping [Arith.Char]
                                    (Term_Rewriting.Term a [Arith.Char]) ->
                                    (Xml.Xml,
                                      ([([Arith.Char], [Arith.Char])],
(Bool, ([String], [String])))) ->
                                      Strict_Sum.Sum_bot (Xmlt.Xml_error String)
[Check_Joins.Crit_pair_info a [Arith.Char]];
joinSequences xml2name termIndexMap =
  Xmlt.xml_do_prepared (Arith.explode "joinSequences") "joinSequences"
    (Xmlt.xml_take_many_sub [] Arith.zero_nat Extended_Nat.Infinity_enat
      (xml2crit_pair_info xml2name termIndexMap) Xmlt.xml_return);

joinAutoBfs ::
  (Xml.Xml, ([([Arith.Char], [Arith.Char])], (Bool, ([String], [String])))) ->
    Strict_Sum.Sum_bot (Xmlt.Xml_error String) (Maybe Arith.Nat);
joinAutoBfs =
  Xmlt.xml_change (Xmlt.xml_int "joinAutoBfs")
    (\ x ->
      Xmlt.xml_return
        (if Arith.less_int x Arith.zero_int then Nothing
          else Just (Arith.nat x)));

joinAutoBfs1 ::
  (Xml.Xml, ([([Arith.Char], [Arith.Char])], (Bool, ([String], [String])))) ->
    Strict_Sum.Sum_bot (Xmlt.Xml_error String) Arith.Nat;
joinAutoBfs1 =
  Xmlt.xml_change joinAutoBfs
    (\ x -> Xmlt.xml_return (case x of {
                              Nothing -> Arith.one_nat;
                              Just n -> n;
                            }));

xml2cp_join_info ::
  forall a.
    (Term_Rewriting.Showl a) => ((Xml.Xml,
                                   ([([Arith.Char], [Arith.Char])],
                                     (Bool, ([String], [String])))) ->
                                  Strict_Sum.Sum_bot (Xmlt.Xml_error String)
                                    a) ->
                                  Mapping.Mapping [Arith.Char]
                                    (Term_Rewriting.Term a [Arith.Char]) ->
                                    (Xml.Xml,
                                      ([([Arith.Char], [Arith.Char])],
(Bool, ([String], [String])))) ->
                                      Strict_Sum.Sum_bot (Xmlt.Xml_error String)
(Check_Joins.Cp_join_hints a [Arith.Char]);
xml2cp_join_info xml2name termIndexMap =
  Xmlt.xml_or
    (Xmlt.xml_change joinAutoBfs1 (Xmlt.xml_return . Check_Joins.CP_Auto))
    (Xmlt.xml_change (joinSequences xml2name termIndexMap)
      (\ joins -> Xmlt.xml_return (Check_Joins.CP_Sequences joins)));

wcr_proof ::
  forall a.
    (Term_Rewriting.Showl a) => ((Xml.Xml,
                                   ([([Arith.Char], [Arith.Char])],
                                     (Bool, ([String], [String])))) ->
                                  Strict_Sum.Sum_bot (Xmlt.Xml_error String)
                                    a) ->
                                  Mapping.Mapping [Arith.Char]
                                    (Term_Rewriting.Term a [Arith.Char]) ->
                                    (Xml.Xml,
                                      ([([Arith.Char], [Arith.Char])],
(Bool, ([String], [String])))) ->
                                      Strict_Sum.Sum_bot (Xmlt.Xml_error String)
(Critical_Pairs_Impl.Join_info a [Arith.Char]);
wcr_proof xml2name termIndexMap =
  Xmlt.xml_do_prepared (Arith.explode "wcrProof") "wcrProof"
    (Xmlt.xml_take
      (Xmlt.xml_or
        (Xmlt.xml_change (xml2cp_join_info xml2name termIndexMap)
          (Xmlt.xml_return . Critical_Pairs_Impl.Guided_BFS))
        (Xmlt.xml_leaf "joinAutoNF" Critical_Pairs_Impl.Join_NF))
      (\ x -> Xmlt.xml_return (id x)));

sl_variant ::
  forall a.
    ((Xml.Xml,
       ([([Arith.Char], [Arith.Char])], (Bool, ([String], [String])))) ->
      Strict_Sum.Sum_bot (Xmlt.Xml_error String) a) ->
      (Xml.Xml,
        ([([Arith.Char], [Arith.Char])], (Bool, ([String], [String])))) ->
        Strict_Sum.Sum_bot (Xmlt.Xml_error String)
          (Semantic_Labeling_Carrier.Sl_variant a [Arith.Char]);
sl_variant xml2name =
  Xmlt.xml_do_prepared (Arith.explode "model") "model"
    (Xmlt.xml_take
      (Xmlt.xml_do_or_prepared (Arith.explode "rootLabeling") "rootLabeling"
        (Xmlt.xml_take_optional xml2name
          (\ fo ->
            Xmlt.xml_return
              (Semantic_Labeling_Carrier.Rootlab
                (case fo of {
                  Nothing -> Nothing;
                  Just f -> Just (f, Arith.one_nat);
                }))))
        (Xmlt.xml_do_prepared (Arith.explode "finiteModel") "finiteModel"
          (Xmlt.xml_take
            (Xmlt.xml_change (Xmlt.xml_nat "carrierSize")
              (\ n -> Xmlt.xml_return (Arith.minus_nat n Arith.one_nat)))
            (\ n ->
              Xmlt.xml_take_optional
                (Xmlt.xml_do_prepared (Arith.explode "tupleOrder") "tupleOrder"
                  (Xmlt.xml_take (Xmlt.xml_leaf "pointWise" ())
                    (\ x -> Xmlt.xml_return (id x))))
                (\ to ->
                  Xmlt.xml_take_many_sub [] Arith.zero_nat
                    Extended_Nat.Infinity_enat
                    (Xmlt.xml_do_prepared (Arith.explode "interpret")
                      "interpret"
                      (Xmlt.xml_take xml2name
                        (\ a ->
                          Xmlt.xml_take (Xmlt.xml_nat "arity")
                            (\ b ->
                              Xmlt.xml_take arith_fun
                                (\ c -> Xmlt.xml_return ((a, b), c))))))
                    (\ inter ->
                      Xmlt.xml_return
                        (case to of {
                          Nothing ->
                            Semantic_Labeling_Carrier.Finitelab
                              (Semantic_Labeling_Carrier.SL_Inter n inter);
                          Just _ ->
                            Semantic_Labeling_Carrier.QuasiFinitelab
                              (Semantic_Labeling_Carrier.SL_Inter n inter) [];
                        })))))))
      (\ x -> Xmlt.xml_return (id x)));

closed_criterion ::
  (Xml.Xml, ([([Arith.Char], [Arith.Char])], (Bool, ([String], [String])))) ->
    Strict_Sum.Sum_bot (Xmlt.Xml_error String)
      (Tree_Automata_Impl.Ta_relation [Arith.Char]);
closed_criterion =
  Xmlt.xml_do_prepared (Arith.explode "criterion") "criterion"
    (Xmlt.xml_take
      (Xmlt.xml_or
        (Xmlt.xml_leaf "compatibility" Tree_Automata_Impl.Id_Relation)
        (Xmlt.xml_do_or_prepared (Arith.explode "stateCompatibility")
          "stateCompatibility"
          (Xmlt.xml_take
            (Xmlt.xml_do_prepared (Arith.explode "relation") "relation"
              (Xmlt.xml_take_many_sub [] Arith.zero_nat
                Extended_Nat.Infinity_enat
                (Xmlt.xml_do_prepared (Arith.explode "entry") "entry"
                  (Xmlt.xml_take CPF_Input_Parser.state
                    (\ a ->
                      Xmlt.xml_take CPF_Input_Parser.state
                        (\ b -> Xmlt.xml_return (a, b)))))
                Xmlt.xml_return))
            (\ x -> Xmlt.xml_return (Tree_Automata_Impl.Some_Relation x)))
          (Xmlt.xml_or
            (Xmlt.xml_leaf "decisionProcedure" Tree_Automata_Impl.Decision_Proc)
            (Xmlt.xml_leaf "decisionProcedureOld"
              Tree_Automata_Impl.Decision_Proc_Old))))
      Xmlt.xml_return);

ta_bounds_lhs ::
  forall a.
    ((Xml.Xml,
       ([([Arith.Char], [Arith.Char])], (Bool, ([String], [String])))) ->
      Strict_Sum.Sum_bot (Xmlt.Xml_error String) a) ->
      (Xml.Xml,
        ([([Arith.Char], [Arith.Char])], (Bool, ([String], [String])))) ->
        Strict_Sum.Sum_bot (Xmlt.Xml_error String)
          (Sum_Type.Sum ((a, Arith.Nat), [[Arith.Char]]) [Arith.Char]);
ta_bounds_lhs xml2name =
  Xmlt.xml_do_prepared (Arith.explode "lhs") "lhs"
    (Xmlt.xml_or
      (Xmlt.xml_take CPF_Input_Parser.state
        (\ a -> Xmlt.xml_return (Sum_Type.Inr a)))
      (Xmlt.xml_take xml2name
        (\ f ->
          Xmlt.xml_take (Xmlt.xml_nat "height")
            (\ h ->
              Xmlt.xml_take_many_sub [] Arith.zero_nat
                Extended_Nat.Infinity_enat CPF_Input_Parser.state
                (\ qs -> Xmlt.xml_return (Sum_Type.Inl ((f, h), qs)))))));

bounds_bound ::
  (Xml.Xml, ([([Arith.Char], [Arith.Char])], (Bool, ([String], [String])))) ->
    Strict_Sum.Sum_bot (Xmlt.Xml_error String) Arith.Nat;
bounds_bound = Xmlt.xml_nat "bound";

bounds_type ::
  (Xml.Xml, ([([Arith.Char], [Arith.Char])], (Bool, ([String], [String])))) ->
    Strict_Sum.Sum_bot (Xmlt.Xml_error String) Matchbounds_Impl.Boundstype;
bounds_type =
  Xmlt.xml_do_prepared (Arith.explode "type") "type"
    (Xmlt.xml_take
      (Xmlt.xml_or (Xmlt.xml_leaf "roof" Matchbounds_Impl.Roof)
        (Xmlt.xml_leaf "match" Matchbounds_Impl.Match))
      (\ x -> Xmlt.xml_return (id x)));

bounds_info ::
  forall a.
    ((Xml.Xml,
       ([([Arith.Char], [Arith.Char])], (Bool, ([String], [String])))) ->
      Strict_Sum.Sum_bot (Xmlt.Xml_error String) a) ->
      (Xml.Xml,
        ([([Arith.Char], [Arith.Char])], (Bool, ([String], [String])))) ->
        Strict_Sum.Sum_bot (Xmlt.Xml_error String)
          (Matchbounds_Impl.Bounds_info a [Arith.Char]);
bounds_info xml2name =
  Xmlt.xml_do_prepared (Arith.explode "bounds") "bounds"
    (Xmlt.xml_take bounds_type
      (\ a ->
        Xmlt.xml_take bounds_bound
          (\ b ->
            Xmlt.xml_take CPF_Input_Parser.final_states
              (\ c ->
                Xmlt.xml_take
                  (CPF_Input_Parser.tree_automaton (ta_bounds_lhs xml2name))
                  (\ d ->
                    Xmlt.xml_take_default Tree_Automata_Impl.Id_Relation
                      closed_criterion
                      (\ e ->
                        Xmlt.xml_return
                          (Matchbounds_Impl.Bounds_Info a b c d e)))))));

multiset_af ::
  forall a.
    (Term_Rewriting.Showl a) => ((Xml.Xml,
                                   ([([Arith.Char], [Arith.Char])],
                                     (Bool, ([String], [String])))) ->
                                  Strict_Sum.Sum_bot (Xmlt.Xml_error String)
                                    a) ->
                                  (Xml.Xml,
                                    ([([Arith.Char], [Arith.Char])],
                                      (Bool, ([String], [String])))) ->
                                    Strict_Sum.Sum_bot (Xmlt.Xml_error String)
                                      [((a, Arith.Nat), [Arith.Nat])];
multiset_af xml2name =
  Xmlt.xml_do_prepared (Arith.explode "multisetArgumentFilter")
    "multisetArgumentFilter"
    (Xmlt.xml_take_many_sub [] Arith.zero_nat Extended_Nat.Infinity_enat
      (Xmlt.xml_do_prepared (Arith.explode "multisetArgumentFilterEntry")
        "multisetArgumentFilterEntry"
        (Xmlt.xml_take xml2name
          (\ f ->
            Xmlt.xml_take (Xmlt.xml_nat "arity")
              (\ a ->
                Xmlt.xml_take
                  (Xmlt.xml_do_prepared (Arith.explode "status") "status"
                    (Xmlt.xml_take_many_sub [] Arith.zero_nat
                      Extended_Nat.Infinity_enat CPF_Input_Parser.position
                      Xmlt.xml_return))
                  (\ p -> Xmlt.xml_return ((f, a), p))))))
      Xmlt.xml_return);

uncurry_info ::
  forall a.
    (Term_Rewriting.Showl a) => ((Xml.Xml,
                                   ([([Arith.Char], [Arith.Char])],
                                     (Bool, ([String], [String])))) ->
                                  Strict_Sum.Sum_bot (Xmlt.Xml_error String)
                                    a) ->
                                  Mapping.Mapping [Arith.Char]
                                    (Term_Rewriting.Term a [Arith.Char]) ->
                                    Mapping.Mapping [Arith.Char]
                                      (Term_Rewriting.Term a [Arith.Char],
Term_Rewriting.Term a [Arith.Char]) ->
                                      (Xml.Xml,
([([Arith.Char], [Arith.Char])], (Bool, ([String], [String])))) ->
Strict_Sum.Sum_bot (Xmlt.Xml_error String)
  (a, ([((a, Arith.Nat), [a])],
        ([(Term_Rewriting.Term a [Arith.Char],
            Term_Rewriting.Term a [Arith.Char])],
          [(Term_Rewriting.Term a [Arith.Char],
             Term_Rewriting.Term a [Arith.Char])])));
uncurry_info xml2name termIndexMap ruleMap =
  Xmlt.xml_do_prepared (Arith.explode "uncurryInformation") "uncurryInformation"
    (Xmlt.xml_take xml2name
      (\ a ->
        Xmlt.xml_take
          (Xmlt.xml_do_prepared (Arith.explode "uncurriedSymbols")
            "uncurriedSymbols"
            (Xmlt.xml_take_many_sub [] Arith.zero_nat Extended_Nat.Infinity_enat
              (Xmlt.xml_do_prepared (Arith.explode "uncurriedSymbolEntry")
                "uncurriedSymbolEntry"
                (Xmlt.xml_take xml2name
                  (\ f ->
                    Xmlt.xml_take (Xmlt.xml_nat "arity")
                      (\ n ->
                        Xmlt.xml_take_many_sub [] Arith.zero_nat
                          Extended_Nat.Infinity_enat xml2name
                          (\ fs -> Xmlt.xml_return ((f, n), fs))))))
              Xmlt.xml_return))
          (\ sml ->
            Xmlt.xml_take
              (Xmlt.xml_do_prepared (Arith.explode "uncurryRules")
                "uncurryRules"
                (Xmlt.xml_take
                  (CPF_Input_Parser.rules xml2name termIndexMap ruleMap)
                  (\ x -> Xmlt.xml_return (id x))))
              (\ u ->
                Xmlt.xml_take
                  (Xmlt.xml_do_prepared (Arith.explode "etaRules") "etaRules"
                    (Xmlt.xml_take
                      (CPF_Input_Parser.rules xml2name termIndexMap ruleMap)
                      (\ x -> Xmlt.xml_return (id x))))
                  (\ e -> Xmlt.xml_return (a, (sml, (u, e))))))));

xml2inn_fp_trs_assm ::
  forall a.
    (Eq a,
      Term_Rewriting.Showl a) => ((Xml.Xml,
                                    ([([Arith.Char], [Arith.Char])],
                                      (Bool, ([String], [String])))) ->
                                   Strict_Sum.Sum_bot (Xmlt.Xml_error String)
                                     a) ->
                                   Mapping.Mapping [Arith.Char]
                                     (Term_Rewriting.Term a [Arith.Char]) ->
                                     Mapping.Mapping [Arith.Char]
                                       (Term_Rewriting.Term a [Arith.Char],
 Term_Rewriting.Term a [Arith.Char]) ->
                                       (Xml.Xml,
 ([([Arith.Char], [Arith.Char])], (Bool, ([String], [String])))) ->
 Strict_Sum.Sum_bot (Xmlt.Xml_error String)
   (Sum_Type.Sum
     (Bool,
       ([Term_Rewriting.Term a [Arith.Char]],
         ([(Term_Rewriting.Term a [Arith.Char],
             Term_Rewriting.Term a [Arith.Char])],
           [(Term_Rewriting.Term a [Arith.Char],
              Term_Rewriting.Term a [Arith.Char])])))
     ([(Term_Rewriting.Actxt a (Term_Rewriting.Term a [Arith.Char]),
         (Term_Rewriting.Term a [Arith.Char], Term_Rewriting.Location))],
       [(Term_Rewriting.Term a [Arith.Char],
          Term_Rewriting.Term a [Arith.Char])]));
xml2inn_fp_trs_assm xml2name termIndexMap ruleMap =
  Xmlt.xml_change (CPF_Input_Parser.trs_input xml2name termIndexMap ruleMap)
    (\ a ->
      (case a of {
        Ceta_Problem_Spec.DP_input _ _ _ _ ->
          Xmlt.xml_error "trs as input required";
        Ceta_Problem_Spec.Relative_DP_input _ _ _ _ _ _ _ ->
          Xmlt.xml_error "trs as input required";
        Ceta_Problem_Spec.CSR_Improved_DP_input _ _ _ _ _ ->
          Xmlt.xml_error "trs as input required";
        Ceta_Problem_Spec.CSR_Muterm_Typed_DP_input _ _ _ _ _ ->
          Xmlt.xml_error "trs as input required";
        Ceta_Problem_Spec.Inn_TRS_input inn r s ->
          Xmlt.xml_return
            (Sum_Type.Inl
              (Ceta_Problem_Spec.strategy_to_nfs inn,
                (Ceta_Problem_Spec.strategy_to_Q inn r, (r, s))));
        Ceta_Problem_Spec.FP_TRS_input fp r ->
          Xmlt.xml_return
            (Sum_Type.Inr (CPF_Input_Parser.strategy_to_fp fp r, r));
        Ceta_Problem_Spec.AC_input _ _ _ ->
          Xmlt.xml_error "trs as input required";
        Ceta_Problem_Spec.LTS_input _ -> Xmlt.xml_error "trs as input required";
        Ceta_Problem_Spec.LTS_safety_input _ _ ->
          Xmlt.xml_error "trs as input required";
        Ceta_Problem_Spec.CTRS_input _ ->
          Xmlt.xml_error "trs as input required";
        Ceta_Problem_Spec.EQ_input _ -> Xmlt.xml_error "trs as input required";
        Ceta_Problem_Spec.EQ_RO_input _ _ ->
          Xmlt.xml_error "trs as input required";
        Ceta_Problem_Spec.EQ_reasoning_input _ _ ->
          Xmlt.xml_error "trs as input required";
        Ceta_Problem_Spec.TA_input _ _ ->
          Xmlt.xml_error "trs as input required";
        Ceta_Problem_Spec.Infeasibility_input _ _ ->
          Xmlt.xml_error "trs as input required";
        Ceta_Problem_Spec.Single_TRS_input _ _ ->
          Xmlt.xml_error "trs as input required";
        Ceta_Problem_Spec.Two_TRS_input _ _ _ ->
          Xmlt.xml_error "trs as input required";
        Ceta_Problem_Spec.Unknown_input _ ->
          Xmlt.xml_error "trs as input required";
      }));

xml2fp_trs_assm ::
  forall a.
    (Eq a,
      Term_Rewriting.Showl a) => ((Xml.Xml,
                                    ([([Arith.Char], [Arith.Char])],
                                      (Bool, ([String], [String])))) ->
                                   Strict_Sum.Sum_bot (Xmlt.Xml_error String)
                                     a) ->
                                   Mapping.Mapping [Arith.Char]
                                     (Term_Rewriting.Term a [Arith.Char]) ->
                                     Mapping.Mapping [Arith.Char]
                                       (Term_Rewriting.Term a [Arith.Char],
 Term_Rewriting.Term a [Arith.Char]) ->
                                       (Xml.Xml,
 ([([Arith.Char], [Arith.Char])], (Bool, ([String], [String])))) ->
 Strict_Sum.Sum_bot (Xmlt.Xml_error String)
   ([(Term_Rewriting.Actxt a (Term_Rewriting.Term a [Arith.Char]),
       (Term_Rewriting.Term a [Arith.Char], Term_Rewriting.Location))],
     [(Term_Rewriting.Term a [Arith.Char],
        Term_Rewriting.Term a [Arith.Char])]);
xml2fp_trs_assm xml2name termIndexMap ruleMap =
  Xmlt.xml_change (xml2inn_fp_trs_assm xml2name termIndexMap ruleMap)
    (\ a ->
      (case a of {
        Sum_Type.Inl _ -> Xmlt.xml_error "FP TRS expected at this point";
        Sum_Type.Inr aa -> Xmlt.xml_return aa;
      }));

xml2cond_constraint ::
  forall a.
    (Term_Rewriting.Showl a) => ((Xml.Xml,
                                   ([([Arith.Char], [Arith.Char])],
                                     (Bool, ([String], [String])))) ->
                                  Strict_Sum.Sum_bot (Xmlt.Xml_error String)
                                    a) ->
                                  Mapping.Mapping [Arith.Char]
                                    (Term_Rewriting.Term a [Arith.Char]) ->
                                    (Xml.Xml,
                                      ([([Arith.Char], [Arith.Char])],
(Bool, ([String], [String])))) ->
                                      Strict_Sum.Sum_bot (Xmlt.Xml_error String)
(Generalized_Usable_Rules.Cond_constraint a [Arith.Char]);
xml2cond_constraint xml2name termIndexMap x =
  Xmlt.xml_do_prepared (Arith.explode "conditionalConstraint")
    "conditionalConstraint"
    (Xmlt.xml_take
      (Xmlt.xml_dispatch_two (Arith.explode "all") "all"
        (Xmlt.xml_take (Xmlt.xml_text "var")
          (\ a ->
            Xmlt.xml_take (xml2cond_constraint xml2name termIndexMap)
              (\ b -> Xmlt.xml_return (Generalized_Usable_Rules.CC_all a b))))
        (Arith.explode "implication") "implication"
        (Xmlt.xml_take (xml2cond_constraint xml2name termIndexMap)
          (\ c ->
            Xmlt.xml_take_many_sub [] Arith.zero_nat Extended_Nat.Infinity_enat
              (xml2cond_constraint xml2name termIndexMap)
              (\ cs ->
                let {
                  ccs = c : cs;
                } in Xmlt.xml_return
                       (Generalized_Usable_Rules.CC_impl
                         (Arith.take (Arith.size_list cs) ccs)
                         (Arith.last ccs)))))
        (Xmlt.xml_do_prepared (Arith.explode "constraint") "constraint"
          (Xmlt.xml_take (CPF_Input_Parser.term xml2name termIndexMap)
            (\ s ->
              Xmlt.xml_take
                (Xmlt.xml_or (Xmlt.xml_leaf "rewrite" Nothing)
                  (Xmlt.xml_or (Xmlt.xml_leaf "strict" (Just True))
                    (Xmlt.xml_leaf "nonStrict" (Just False))))
                (\ rel ->
                  Xmlt.xml_take (CPF_Input_Parser.term xml2name termIndexMap)
                    (\ t ->
                      Xmlt.xml_return
                        (case rel of {
                          Nothing -> Generalized_Usable_Rules.CC_rewr s t;
                          Just stri ->
                            Generalized_Usable_Rules.CC_cond stri (s, t);
                        })))))))
      (\ xa -> Xmlt.xml_return (id xa)))
    x;

xml2cond_constraint_prf ::
  forall a.
    (Term_Rewriting.Showl a) => ((Xml.Xml,
                                   ([([Arith.Char], [Arith.Char])],
                                     (Bool, ([String], [String])))) ->
                                  Strict_Sum.Sum_bot (Xmlt.Xml_error String)
                                    a) ->
                                  Mapping.Mapping [Arith.Char]
                                    (Term_Rewriting.Term a [Arith.Char]) ->
                                    Mapping.Mapping [Arith.Char]
                                      (Term_Rewriting.Term a [Arith.Char],
Term_Rewriting.Term a [Arith.Char]) ->
                                      (Xml.Xml,
([([Arith.Char], [Arith.Char])], (Bool, ([String], [String])))) ->
Strict_Sum.Sum_bot (Xmlt.Xml_error String)
  (Bounded_Increase_Impl.Cond_constraint_prf a [Arith.Char]);
xml2cond_constraint_prf xml2name termIndexMap ruleMap x =
  let {
    cc = xml2cond_constraint xml2name termIndexMap;
  } in Xmlt.xml_do_prepared (Arith.explode "conditionalConstraintProof")
         "conditionalConstraintProof"
         (Xmlt.xml_take
           (Xmlt.xml_or (Xmlt.xml_leaf "final" Bounded_Increase_Impl.Final)
             (Xmlt.xml_dispatch_two (Arith.explode "differentConstructor")
               "differentConstructor"
               (Xmlt.xml_take cc
                 (\ a ->
                   Xmlt.xml_return
                     (Bounded_Increase_Impl.Different_Constructor a)))
               (Arith.explode "sameConstructor") "sameConstructor"
               (Xmlt.xml_take cc
                 (\ a ->
                   Xmlt.xml_take cc
                     (\ b ->
                       Xmlt.xml_take
                         (xml2cond_constraint_prf xml2name termIndexMap ruleMap)
                         (\ c ->
                           Xmlt.xml_return
                             (Bounded_Increase_Impl.Same_Constructor a b c)))))
               (Xmlt.xml_dispatch_two (Arith.explode "variableEquation")
                 "variableEquation"
                 (Xmlt.xml_take (Xmlt.xml_text "var")
                   (\ a ->
                     Xmlt.xml_take (CPF_Input_Parser.term xml2name termIndexMap)
                       (\ b ->
                         Xmlt.xml_take cc
                           (\ c ->
                             Xmlt.xml_take
                               (xml2cond_constraint_prf xml2name termIndexMap
                                 ruleMap)
                               (\ d ->
                                 Xmlt.xml_return
                                   (Bounded_Increase_Impl.Variable_Equation a b
                                     c d))))))
                 (Arith.explode "funargIntoVar") "funargIntoVar"
                 (Xmlt.xml_take cc
                   (\ a ->
                     Xmlt.xml_take CPF_Input_Parser.position
                       (\ b ->
                         Xmlt.xml_take (Xmlt.xml_text "var")
                           (\ c ->
                             Xmlt.xml_take cc
                               (\ d ->
                                 Xmlt.xml_take
                                   (xml2cond_constraint_prf xml2name
                                     termIndexMap ruleMap)
                                   (\ e ->
                                     Xmlt.xml_return
                                       (Bounded_Increase_Impl.Funarg_Into_Var a
 b c d e)))))))
                 (Xmlt.xml_dispatch_two (Arith.explode "simplifyCondition")
                   "simplifyCondition"
                   (Xmlt.xml_take cc
                     (\ a ->
                       Xmlt.xml_take (subst xml2name termIndexMap)
                         (\ b ->
                           Xmlt.xml_take cc
                             (\ c ->
                               Xmlt.xml_take
                                 (xml2cond_constraint_prf xml2name termIndexMap
                                   ruleMap)
                                 (\ d ->
                                   Xmlt.xml_return
                                     (Bounded_Increase_Impl.Simplify_Condition a
                                       b c d))))))
                   (Arith.explode "induction") "induction"
                   (Xmlt.xml_take cc
                     (\ a ->
                       Xmlt.xml_take
                         (Xmlt.xml_do_prepared (Arith.explode "conjuncts")
                           "conjuncts"
                           (Xmlt.xml_take_many_sub [] Arith.zero_nat
                             Extended_Nat.Infinity_enat cc Xmlt.xml_return))
                         (\ b ->
                           Xmlt.xml_take
                             (Xmlt.xml_do_prepared
                               (Arith.explode "ruleConstraintProofs")
                               "ruleConstraintProofs"
                               (Xmlt.xml_take_many_sub [] Arith.zero_nat
                                 Extended_Nat.Infinity_enat
                                 (Xmlt.xml_do_prepared
                                   (Arith.explode "ruleConstraintProof")
                                   "ruleConstraintProof"
                                   (Xmlt.xml_take
                                     (CPF_Input_Parser.rule xml2name
                                       termIndexMap ruleMap)
                                     (\ lr ->
                                       Xmlt.xml_take
 (Xmlt.xml_do_prepared (Arith.explode "subtermVarEntries") "subtermVarEntries"
   (Xmlt.xml_take_many_sub [] Arith.zero_nat Extended_Nat.Infinity_enat
     (Xmlt.xml_do_prepared (Arith.explode "subtermVarEntry") "subtermVarEntry"
       (Xmlt.xml_take (CPF_Input_Parser.term xml2name termIndexMap)
         (\ aa ->
           Xmlt.xml_take_many_sub [] Arith.zero_nat Extended_Nat.Infinity_enat
             (Xmlt.xml_text "var") (\ ba -> Xmlt.xml_return (aa, ba)))))
     Xmlt.xml_return))
 (\ rys ->
   Xmlt.xml_take cc
     (\ cca ->
       Xmlt.xml_take (xml2cond_constraint_prf xml2name termIndexMap ruleMap)
         (\ p -> Xmlt.xml_return (lr, (rys, (cca, p)))))))))
                                 Xmlt.xml_return))
                             (\ c ->
                               Xmlt.xml_return
                                 (Bounded_Increase_Impl.Induction a b c)))))
                   (Xmlt.xml_do_prepared (Arith.explode "deleteCondition")
                     "deleteCondition"
                     (Xmlt.xml_take cc
                       (\ a ->
                         Xmlt.xml_take
                           (xml2cond_constraint_prf xml2name termIndexMap
                             ruleMap)
                           (\ b ->
                             Xmlt.xml_return
                               (Bounded_Increase_Impl.Delete_Condition a
                                 b)))))))))
           (\ xa -> Xmlt.xml_return (id xa)))
         x;

xml2cond_red_pair_proof ::
  forall a.
    (Term_Rewriting.Showl a) => ((Xml.Xml,
                                   ([([Arith.Char], [Arith.Char])],
                                     (Bool, ([String], [String])))) ->
                                  Strict_Sum.Sum_bot (Xmlt.Xml_error String)
                                    a) ->
                                  Mapping.Mapping [Arith.Char]
                                    (Term_Rewriting.Term a [Arith.Char]) ->
                                    Mapping.Mapping [Arith.Char]
                                      (Term_Rewriting.Term a [Arith.Char],
Term_Rewriting.Term a [Arith.Char]) ->
                                      (Xml.Xml,
([([Arith.Char], [Arith.Char])], (Bool, ([String], [String])))) ->
Strict_Sum.Sum_bot (Xmlt.Xml_error String)
  (Bounded_Increase_Impl.Cond_red_pair_prf a [Arith.Char]);
xml2cond_red_pair_proof xml2name termIndexMap ruleMap =
  Xmlt.xml_do_prepared (Arith.explode "condRedPairProof") "condRedPairProof"
    (Xmlt.xml_take xml2name
      (\ c ->
        Xmlt.xml_take (Xmlt.xml_nat "before")
          (\ b ->
            Xmlt.xml_take (Xmlt.xml_nat "after")
              (\ a ->
                Xmlt.xml_take
                  (Xmlt.xml_do_prepared (Arith.explode "conditions")
                    "conditions"
                    (Xmlt.xml_take_many_sub [] Arith.zero_nat
                      Extended_Nat.Infinity_enat
                      (Xmlt.xml_do_prepared (Arith.explode "condition")
                        "condition"
                        (Xmlt.xml_take
                          (xml2cond_constraint xml2name termIndexMap)
                          (\ ca ->
                            Xmlt.xml_take
                              (Xmlt.xml_do_prepared (Arith.explode "dpSequence")
                                "dpSequence"
                                (Xmlt.xml_take
                                  (CPF_Input_Parser.rules xml2name termIndexMap
                                    ruleMap)
                                  (\ x -> Xmlt.xml_return (id x))))
                              (\ s ->
                                Xmlt.xml_take
                                  (xml2cond_constraint_prf xml2name termIndexMap
                                    ruleMap)
                                  (\ p -> Xmlt.xml_return (ca, (s, p)))))))
                      Xmlt.xml_return))
                  (\ ccs ->
                    Xmlt.xml_return
                      (Bounded_Increase_Impl.Cond_Red_Pair_Prf c ccs b a))))));

projected_rseq ::
  forall a.
    (Eq a,
      Term_Rewriting.Showl a) => ((Xml.Xml,
                                    ([([Arith.Char], [Arith.Char])],
                                      (Bool, ([String], [String])))) ->
                                   Strict_Sum.Sum_bot (Xmlt.Xml_error String)
                                     a) ->
                                   Mapping.Mapping [Arith.Char]
                                     (Term_Rewriting.Term a [Arith.Char]) ->
                                     Mapping.Mapping [Arith.Char]
                                       (Term_Rewriting.Term a [Arith.Char],
 Term_Rewriting.Term a [Arith.Char]) ->
                                       ((a, Arith.Nat) -> Arith.Nat) ->
 (Xml.Xml, ([([Arith.Char], [Arith.Char])], (Bool, ([String], [String])))) ->
   Strict_Sum.Sum_bot (Xmlt.Xml_error String)
     ((Term_Rewriting.Term a [Arith.Char], Term_Rewriting.Term a [Arith.Char]),
       [([Arith.Nat],
          ((Term_Rewriting.Term a [Arith.Char],
             Term_Rewriting.Term a [Arith.Char]),
            Term_Rewriting.Term a [Arith.Char]))]);
projected_rseq xml2name termIndexMap ruleMap pi =
  Xmlt.xml_do_prepared (Arith.explode "projectedRewriteSequence")
    "projectedRewriteSequence"
    (Xmlt.xml_take (CPF_Input_Parser.rule xml2name termIndexMap ruleMap)
      (\ r ->
        Xmlt.xml_take (rseq xml2name termIndexMap ruleMap pi r)
          Xmlt.xml_return));

xml2dp_input ::
  forall a b c d.
    (Eq a,
      Term_Rewriting.Showl a) => ((Xml.Xml,
                                    ([([Arith.Char], [Arith.Char])],
                                      (Bool, ([String], [String])))) ->
                                   Strict_Sum.Sum_bot (Xmlt.Xml_error String)
                                     a) ->
                                   Mapping.Mapping [Arith.Char]
                                     (Term_Rewriting.Term a [Arith.Char]) ->
                                     Mapping.Mapping [Arith.Char]
                                       (Term_Rewriting.Term a [Arith.Char],
 Term_Rewriting.Term a [Arith.Char]) ->
                                       b ->
 (Xml.Xml, ([([Arith.Char], [Arith.Char])], (Bool, ([String], [String])))) ->
   Strict_Sum.Sum_bot (Xmlt.Xml_error String)
     (Bool,
       (Bool,
         ([(Term_Rewriting.Term a [Arith.Char],
             Term_Rewriting.Term a [Arith.Char])],
           ([c], ([Term_Rewriting.Term a [Arith.Char]],
                   ([d], [(Term_Rewriting.Term a [Arith.Char],
                            Term_Rewriting.Term a [Arith.Char])]))))));
xml2dp_input xml2name termIndexMap ruleMap termination =
  Xmlt.xml_change (CPF_Input_Parser.dp_input xml2name termIndexMap ruleMap)
    (\ (Ceta_Problem_Spec.DP_input m p q r) ->
      Xmlt.xml_return
        (Ceta_Problem_Spec.strategy_to_nfs q,
          (m, (p, ([], (Ceta_Problem_Spec.strategy_to_Q q r, ([], r)))))));

flat_contexts ::
  forall a.
    (Term_Rewriting.Showl a) => ((Xml.Xml,
                                   ([([Arith.Char], [Arith.Char])],
                                     (Bool, ([String], [String])))) ->
                                  Strict_Sum.Sum_bot (Xmlt.Xml_error String)
                                    a) ->
                                  Mapping.Mapping [Arith.Char]
                                    (Term_Rewriting.Term a [Arith.Char]) ->
                                    (Xml.Xml,
                                      ([([Arith.Char], [Arith.Char])],
(Bool, ([String], [String])))) ->
                                      Strict_Sum.Sum_bot (Xmlt.Xml_error String)
[Term_Rewriting.Actxt a (Term_Rewriting.Term a [Arith.Char])];
flat_contexts xml2name termIndexMap =
  Xmlt.xml_do_prepared (Arith.explode "flatContexts") "flatContexts"
    (Xmlt.xml_take_many_sub [] Arith.zero_nat Extended_Nat.Infinity_enat
      (ctxt xml2name termIndexMap) Xmlt.xml_return);

rfc_initial_terms ::
  forall a.
    (Term_Rewriting.Showl a) => ((Xml.Xml,
                                   ([([Arith.Char], [Arith.Char])],
                                     (Bool, ([String], [String])))) ->
                                  Strict_Sum.Sum_bot (Xmlt.Xml_error String)
                                    a) ->
                                  Mapping.Mapping [Arith.Char]
                                    (Term_Rewriting.Term a [Arith.Char]) ->
                                    (Xml.Xml,
                                      ([([Arith.Char], [Arith.Char])],
(Bool, ([String], [String])))) ->
                                      Strict_Sum.Sum_bot (Xmlt.Xml_error String)
[Term_Rewriting.Term a [Arith.Char]];
rfc_initial_terms xml2name termIndexMap =
  Xmlt.xml_do_prepared (Arith.explode "initialTerms") "initialTerms"
    (Xmlt.xml_take_many_sub [] Arith.zero_nat Extended_Nat.Infinity_enat
      (CPF_Input_Parser.term xml2name termIndexMap) Xmlt.xml_return);

xml2inn_trs_assm ::
  forall a.
    (Eq a,
      Term_Rewriting.Showl a) => ((Xml.Xml,
                                    ([([Arith.Char], [Arith.Char])],
                                      (Bool, ([String], [String])))) ->
                                   Strict_Sum.Sum_bot (Xmlt.Xml_error String)
                                     a) ->
                                   Mapping.Mapping [Arith.Char]
                                     (Term_Rewriting.Term a [Arith.Char]) ->
                                     Mapping.Mapping [Arith.Char]
                                       (Term_Rewriting.Term a [Arith.Char],
 Term_Rewriting.Term a [Arith.Char]) ->
                                       (Xml.Xml,
 ([([Arith.Char], [Arith.Char])], (Bool, ([String], [String])))) ->
 Strict_Sum.Sum_bot (Xmlt.Xml_error String)
   (Bool,
     ([Term_Rewriting.Term a [Arith.Char]],
       ([(Term_Rewriting.Term a [Arith.Char],
           Term_Rewriting.Term a [Arith.Char])],
         [(Term_Rewriting.Term a [Arith.Char],
            Term_Rewriting.Term a [Arith.Char])])));
xml2inn_trs_assm xml2name termIndexMap ruleMap =
  Xmlt.xml_change (xml2inn_fp_trs_assm xml2name termIndexMap ruleMap)
    (\ a ->
      (case a of {
        Sum_Type.Inl aa -> Xmlt.xml_return aa;
        Sum_Type.Inr _ ->
          Xmlt.xml_error "innermost (relative) TRS expected at this point";
      }));

xml2subproof ::
  forall a b.
    (Compare.Compare_order a, Eq a, Term_Rewriting.Showl a,
      Compare.Compare_order b, Eq b,
      Term_Rewriting.Showl b) => ((Xml.Xml,
                                    ([([Arith.Char], [Arith.Char])],
                                      (Bool, ([String], [String])))) ->
                                   Strict_Sum.Sum_bot (Xmlt.Xml_error String)
                                     (Labelings.Lab a b)) ->
                                   Mapping.Mapping [Arith.Char]
                                     (Term_Rewriting.Term (Labelings.Lab a b)
                                       [Arith.Char]) ->
                                     Mapping.Mapping [Arith.Char]
                                       (Term_Rewriting.Term (Labelings.Lab a b)
  [Arith.Char],
 Term_Rewriting.Term (Labelings.Lab a b) [Arith.Char]) ->
                                       (Xml.Xml,
 ([([Arith.Char], [Arith.Char])], (Bool, ([String], [String])))) ->
 Strict_Sum.Sum_bot (Xmlt.Xml_error String)
   (Check_Termination_Common.Generic_assm_proof a b [Arith.Char]
     (Check_Termination.Trs_termination_proof a b [Arith.Char])
     (Check_Termination.Dp_termination_proof a b [Arith.Char])
     (Check_Termination.Fptrs_termination_proof a b [Arith.Char]) ()
     (Check_Termination.Unknown_proof a b [Arith.Char]));
xml2subproof xml2name termIndexMap ruleMap x =
  Xmlt.xml_do_prepared (Arith.explode "subProof") "subProof"
    (Xmlt.xml_or
      (Xmlt.xml_take (xml2dp_input xml2name termIndexMap ruleMap True)
        (\ inp ->
          Xmlt.xml_take (xml2dp_termination_proof xml2name termIndexMap ruleMap)
            (\ prf ->
              Xmlt.xml_return
                (Check_Termination_Common.Finite_assm_proof inp prf))))
      (Xmlt.xml_take (xml2inn_fp_trs_assm xml2name termIndexMap ruleMap)
        (\ a ->
          (case a of {
            Sum_Type.Inl qtrs ->
              Xmlt.xml_take
                (xml2trs_termination_proof xml2name termIndexMap ruleMap)
                (\ prf ->
                  Xmlt.xml_return
                    (Check_Termination_Common.SN_assm_proof qtrs prf));
            Sum_Type.Inr fptrs ->
              Xmlt.xml_take
                (xml2fptrs_termination_proof xml2name termIndexMap ruleMap)
                (\ prf ->
                  Xmlt.xml_return
                    (Check_Termination_Common.SN_FP_assm_proof fptrs prf));
          }))))
    x;

xml2fptrs_termination_proof ::
  forall a b.
    (Compare.Compare_order a, Eq a, Term_Rewriting.Showl a,
      Compare.Compare_order b, Eq b,
      Term_Rewriting.Showl b) => ((Xml.Xml,
                                    ([([Arith.Char], [Arith.Char])],
                                      (Bool, ([String], [String])))) ->
                                   Strict_Sum.Sum_bot (Xmlt.Xml_error String)
                                     (Labelings.Lab a b)) ->
                                   Mapping.Mapping [Arith.Char]
                                     (Term_Rewriting.Term (Labelings.Lab a b)
                                       [Arith.Char]) ->
                                     Mapping.Mapping [Arith.Char]
                                       (Term_Rewriting.Term (Labelings.Lab a b)
  [Arith.Char],
 Term_Rewriting.Term (Labelings.Lab a b) [Arith.Char]) ->
                                       (Xml.Xml,
 ([([Arith.Char], [Arith.Char])], (Bool, ([String], [String])))) ->
 Strict_Sum.Sum_bot (Xmlt.Xml_error String)
   (Check_Termination.Fptrs_termination_proof a b [Arith.Char]);
xml2fptrs_termination_proof xml2name termIndexMap ruleMap x =
  Xmlt.xml_do_prepared (Arith.explode "trsTerminationProof")
    "trsTerminationProof"
    (Xmlt.xml_take
      (Xmlt.xml_do_or_prepared (Arith.explode "terminationAssumption")
        "terminationAssumption"
        (Xmlt.xml_take (xml2fp_trs_assm xml2name termIndexMap ruleMap)
          (\ inp -> Xmlt.xml_return (Check_Termination.Assume_FP_SN inp [])))
        (Xmlt.xml_do_prepared (Arith.explode "unknownProof") "unknownProof"
          (Xmlt.xml_take (xml2fp_trs_assm xml2name termIndexMap ruleMap)
            (\ inp ->
              Xmlt.xml_take_many_sub [] Arith.zero_nat
                Extended_Nat.Infinity_enat
                (xml2subproof xml2name termIndexMap ruleMap)
                (\ subprfs ->
                  Xmlt.xml_return
                    (Check_Termination.Assume_FP_SN inp subprfs))))))
      Xmlt.xml_return)
    x;

xml2trs_termination_proof_body ::
  forall a b.
    (Compare.Compare_order a, Eq a, Term_Rewriting.Showl a,
      Compare.Compare_order b, Eq b,
      Term_Rewriting.Showl b) => ((Xml.Xml,
                                    ([([Arith.Char], [Arith.Char])],
                                      (Bool, ([String], [String])))) ->
                                   Strict_Sum.Sum_bot (Xmlt.Xml_error String)
                                     (Labelings.Lab a b)) ->
                                   Mapping.Mapping [Arith.Char]
                                     (Term_Rewriting.Term (Labelings.Lab a b)
                                       [Arith.Char]) ->
                                     Mapping.Mapping [Arith.Char]
                                       (Term_Rewriting.Term (Labelings.Lab a b)
  [Arith.Char],
 Term_Rewriting.Term (Labelings.Lab a b) [Arith.Char]) ->
                                       (Xml.Xml,
 ([([Arith.Char], [Arith.Char])], (Bool, ([String], [String])))) ->
 Strict_Sum.Sum_bot (Xmlt.Xml_error String)
   (Check_Termination.Trs_termination_proof a b [Arith.Char]);
xml2trs_termination_proof_body xml2name termIndexMap ruleMap x =
  Xmlt.xml_do_or_prepared (Arith.explode "rIsEmpty") "rIsEmpty"
    (Xmlt.xml_return Check_Termination.R_is_Empty)
    (Xmlt.xml_dispatch_two (Arith.explode "semlab") "semlab"
      (Xmlt.xml_take (sl_variant xml2name)
        (\ sli ->
          Xmlt.xml_take
            (Xmlt.xml_do_prepared (Arith.explode "trs") "trs"
              (Xmlt.xml_take
                (CPF_Input_Parser.rules xml2name termIndexMap ruleMap)
                (\ xa -> Xmlt.xml_return (id xa))))
            (\ lr ->
              Xmlt.xml_take_default []
                (CPF_Input_Parser.innermostLhss xml2name termIndexMap)
                (\ lq ->
                  Xmlt.xml_take
                    (xml2trs_termination_proof xml2name termIndexMap ruleMap)
                    (\ p ->
                      Xmlt.xml_return
                        (Check_Termination.Semlab sli lq lr p))))))
      (Arith.explode "split") "split"
      (Xmlt.xml_take
        (Xmlt.xml_do_prepared (Arith.explode "trs") "trs"
          (Xmlt.xml_take (CPF_Input_Parser.rules xml2name termIndexMap ruleMap)
            (\ xa -> Xmlt.xml_return (id xa))))
        (\ a ->
          Xmlt.xml_take
            (xml2trs_termination_proof xml2name termIndexMap ruleMap)
            (\ b ->
              Xmlt.xml_take
                (xml2trs_termination_proof xml2name termIndexMap ruleMap)
                (\ c -> Xmlt.xml_return (Check_Termination.Split a b c)))))
      (Xmlt.xml_dispatch_two (Arith.explode "dpTrans") "dpTrans"
        (Xmlt.xml_take
          (Xmlt.xml_do_prepared (Arith.explode "dps") "dps"
            (Xmlt.xml_take
              (CPF_Input_Parser.rules xml2name termIndexMap ruleMap)
              (\ xa -> Xmlt.xml_return (id xa))))
          (\ dps ->
            Xmlt.xml_take
              (xml2dp_termination_proof xml2name termIndexMap ruleMap)
              (\ prf ->
                Xmlt.xml_return
                  (Check_Termination.DP_Trans Defaults.default_nfs_dp True dps
                    prf))))
        (Arith.explode "ruleRemoval") "ruleRemoval"
        (Xmlt.xml_take (redtriple xml2name Labelings.Sharp False)
          (\ ord ->
            Xmlt.xml_take
              (Xmlt.xml_do_prepared (Arith.explode "trs") "trs"
                (Xmlt.xml_take
                  (CPF_Input_Parser.rules xml2name termIndexMap ruleMap)
                  (\ xa -> Xmlt.xml_return (id xa))))
              (\ r ->
                Xmlt.xml_take
                  (xml2trs_termination_proof xml2name termIndexMap ruleMap)
                  (\ p ->
                    Xmlt.xml_return (Check_Termination.Rule_Removal ord r p)))))
        (Xmlt.xml_or
          (Xmlt.xml_change (bounds_info xml2name)
            (Xmlt.xml_return . Check_Termination.Bounds))
          (Xmlt.xml_do_or_prepared (Arith.explode "relativeBounds")
            "relativeBounds"
            (Xmlt.xml_take (bounds_info xml2name)
              (\ a ->
                Xmlt.xml_take
                  (Xmlt.xml_do_prepared (Arith.explode "trs") "trs"
                    (Xmlt.xml_take
                      (CPF_Input_Parser.rules xml2name termIndexMap ruleMap)
                      (\ xa -> Xmlt.xml_return (id xa))))
                  (\ b ->
                    Xmlt.xml_take
                      (xml2trs_termination_proof xml2name termIndexMap ruleMap)
                      (\ c ->
                        Xmlt.xml_return
                          (Check_Termination.Relative_Bounds a b c)))))
            (Xmlt.xml_dispatch_two (Arith.explode "rfcBounds") "rfcBounds"
              (Xmlt.xml_take (rfc_initial_terms xml2name termIndexMap)
                (\ ts ->
                  Xmlt.xml_take (bounds_info xml2name)
                    (\ a ->
                      Xmlt.xml_return (Check_Termination.Rfc_Bounds a ts))))
              (Arith.explode "rfcAutomatonClosedBounds")
              "rfcAutomatonClosedBounds"
              (Xmlt.xml_take (rfc_initial_terms xml2name termIndexMap)
                (\ ts ->
                  Xmlt.xml_take (bounds_info xml2name)
                    (\ a ->
                      Xmlt.xml_return
                        (Check_Termination.Rfc_Automaton_Closed_Bounds a ts))))
              (Xmlt.xml_dispatch_two (Arith.explode "rfcRelativeBounds")
                "rfcRelativeBounds"
                (Xmlt.xml_take (rfc_initial_terms xml2name termIndexMap)
                  (\ ts ->
                    Xmlt.xml_take (bounds_info xml2name)
                      (\ a ->
                        Xmlt.xml_take
                          (Xmlt.xml_do_prepared (Arith.explode "trs") "trs"
                            (Xmlt.xml_take
                              (CPF_Input_Parser.rules xml2name termIndexMap
                                ruleMap)
                              (\ xa -> Xmlt.xml_return (id xa))))
                          (\ b ->
                            Xmlt.xml_take
                              (xml2trs_termination_proof xml2name termIndexMap
                                ruleMap)
                              (\ c ->
                                Xmlt.xml_return
                                  (Check_Termination.Rfc_Relative_Bounds a ts b
                                    c))))))
                (Arith.explode "rfcAutomatonClosedRelativeBounds")
                "rfcAutomatonClosedRelativeBounds"
                (Xmlt.xml_take (rfc_initial_terms xml2name termIndexMap)
                  (\ ts ->
                    Xmlt.xml_take (bounds_info xml2name)
                      (\ a ->
                        Xmlt.xml_take
                          (Xmlt.xml_do_prepared (Arith.explode "trs") "trs"
                            (Xmlt.xml_take
                              (CPF_Input_Parser.rules xml2name termIndexMap
                                ruleMap)
                              (\ xa -> Xmlt.xml_return (id xa))))
                          (\ b ->
                            Xmlt.xml_take
                              (xml2trs_termination_proof xml2name termIndexMap
                                ruleMap)
                              (\ c ->
                                Xmlt.xml_return
                                  (Check_Termination.Rfc_Automaton_Closed_Relative_Bounds
                                    a ts b c))))))
                (Xmlt.xml_dispatch_two
                  (Arith.explode "rfcMatchboxRelativeBounds")
                  "rfcMatchboxRelativeBounds"
                  (Xmlt.xml_take (rfc_initial_terms xml2name termIndexMap)
                    (\ ts ->
                      Xmlt.xml_take (bounds_info xml2name)
                        (\ a ->
                          Xmlt.xml_take
                            (Xmlt.xml_do_prepared (Arith.explode "trs") "trs"
                              (Xmlt.xml_take
                                (CPF_Input_Parser.rules xml2name termIndexMap
                                  ruleMap)
                                (\ xa -> Xmlt.xml_return (id xa))))
                            (\ b ->
                              Xmlt.xml_take
                                (xml2trs_termination_proof xml2name termIndexMap
                                  ruleMap)
                                (\ c ->
                                  Xmlt.xml_return
                                    (Check_Termination.Rfc_Matchbox_Relative_Bounds
                                      a ts b c))))))
                  (Arith.explode "rfcNativeMatchboxRelativeBounds")
                  "rfcNativeMatchboxRelativeBounds"
                  (Xmlt.xml_take (rfc_initial_terms xml2name termIndexMap)
                    (\ ts ->
                      Xmlt.xml_take (bounds_info xml2name)
                        (\ a ->
                          Xmlt.xml_take
                            (Xmlt.xml_do_prepared (Arith.explode "trs") "trs"
                              (Xmlt.xml_take
                                (CPF_Input_Parser.rules xml2name termIndexMap
                                  ruleMap)
                                (\ xa -> Xmlt.xml_return (id xa))))
                            (\ b ->
                              Xmlt.xml_take
                                (xml2trs_termination_proof xml2name termIndexMap
                                  ruleMap)
                                (\ c ->
                                  Xmlt.xml_return
                                    (Check_Termination.Rfc_Native_Matchbox_Relative_Bounds
                                      a ts b c))))))
                  (Xmlt.xml_dispatch_two (Arith.explode "ruleStrengthening")
                    "ruleStrengthening"
                    (Xmlt.xml_take
                      (Xmlt.xml_do_prepared (Arith.explode "trs") "trs"
                        (Xmlt.xml_take
                          (CPF_Input_Parser.rules xml2name termIndexMap ruleMap)
                          (\ xa -> Xmlt.xml_return (id xa))))
                      (\ stronger ->
                        Xmlt.xml_take
                          (xml2trs_termination_proof xml2name termIndexMap
                            ruleMap)
                          (\ prf ->
                            Xmlt.xml_return
                              (Check_Termination.Rule_Strengthening stronger
                                prf))))
                    (Arith.explode "stringReversal") "stringReversal"
                    (Xmlt.xml_take
                      (Xmlt.xml_do_prepared (Arith.explode "trs") "trs"
                        (Xmlt.xml_take
                          (CPF_Input_Parser.rules xml2name termIndexMap ruleMap)
                          (\ xa -> Xmlt.xml_return (id xa))))
                      (\ _ ->
                        Xmlt.xml_take
                          (xml2trs_termination_proof xml2name termIndexMap
                            ruleMap)
                          (\ prf ->
                            Xmlt.xml_return
                              (Check_Termination.String_Reversal prf))))
                    (Xmlt.xml_dispatch_two (Arith.explode "equalityRemoval")
                      "equalityRemoval"
                      (Xmlt.xml_take
                        (xml2trs_termination_proof xml2name termIndexMap
                          ruleMap)
                        (\ a ->
                          Xmlt.xml_return (Check_Termination.Drop_Equality a)))
                      (Arith.explode "rightGroundTermination")
                      "rightGroundTermination"
                      (Xmlt.xml_return
                        Check_Termination.Right_Ground_Termination)
                      (Xmlt.xml_dispatch_two (Arith.explode "constantToUnary")
                        "constantToUnary"
                        (Xmlt.xml_take CPF_Input_Parser.plain_var
                          (\ v ->
                            Xmlt.xml_take (renaming xml2name)
                              (\ ren ->
                                Xmlt.xml_take
                                  (Xmlt.xml_do_prepared (Arith.explode "trs")
                                    "trs"
                                    (Xmlt.xml_take
                                      (CPF_Input_Parser.rules xml2name
termIndexMap ruleMap)
                                      (\ xa -> Xmlt.xml_return (id xa))))
                                  (\ s ->
                                    Xmlt.xml_take
                                      (xml2trs_termination_proof xml2name
termIndexMap ruleMap)
                                      (\ p ->
Xmlt.xml_return
  (Check_Termination.Constant_String
    (Monadic_Rewriting_Impl.Const_string_sound_proof v ren s) p))))))
                        (Arith.explode "removeNonApplicableRules")
                        "removeNonApplicableRules"
                        (Xmlt.xml_take
                          (Xmlt.xml_do_prepared (Arith.explode "trs") "trs"
                            (Xmlt.xml_take
                              (CPF_Input_Parser.rules xml2name termIndexMap
                                ruleMap)
                              (\ xa -> Xmlt.xml_return (id xa))))
                          (\ a ->
                            Xmlt.xml_take
                              (xml2trs_termination_proof xml2name termIndexMap
                                ruleMap)
                              (\ b ->
                                Xmlt.xml_return
                                  (Check_Termination.Remove_Nonapplicable_Rules
                                    a b))))
                        (Xmlt.xml_dispatch_two (Arith.explode "uncurry")
                          "uncurry"
                          (Xmlt.xml_take
                            (uncurry_info xml2name termIndexMap ruleMap)
                            (\ i ->
                              Xmlt.xml_take
                                (Xmlt.xml_do_prepared (Arith.explode "trs")
                                  "trs"
                                  (Xmlt.xml_take
                                    (CPF_Input_Parser.rules xml2name
                                      termIndexMap ruleMap)
                                    (\ xa -> Xmlt.xml_return (id xa))))
                                (\ r ->
                                  Xmlt.xml_take
                                    (xml2trs_termination_proof xml2name
                                      termIndexMap ruleMap)
                                    (\ p ->
                                      Xmlt.xml_return
(Check_Termination.Uncurry i r p)))))
                          (Arith.explode "flatContextClosure")
                          "flatContextClosure"
                          (Xmlt.xml_take (flat_contexts xml2name termIndexMap)
                            (\ i ->
                              Xmlt.xml_take
                                (Xmlt.xml_do_prepared (Arith.explode "trs")
                                  "trs"
                                  (Xmlt.xml_take
                                    (CPF_Input_Parser.rules xml2name
                                      termIndexMap ruleMap)
                                    (\ xa -> Xmlt.xml_return (id xa))))
                                (\ r ->
                                  Xmlt.xml_take
                                    (xml2trs_termination_proof xml2name
                                      termIndexMap ruleMap)
                                    (\ p ->
                                      Xmlt.xml_return
(Check_Termination.Fcc i r p)))))
                          (Xmlt.xml_dispatch_two
                            (Arith.explode "switchInnermost") "switchInnermost"
                            (Xmlt.xml_take (wcr_proof xml2name termIndexMap)
                              (\ a ->
                                Xmlt.xml_take
                                  (xml2trs_termination_proof xml2name
                                    termIndexMap ruleMap)
                                  (\ b ->
                                    Xmlt.xml_return
                                      (Check_Termination.Switch_Innermost a
b))))
                            (Arith.explode "aaeccInnermost") "aaeccInnermost"
                            (Xmlt.xml_take
                              (Xmlt.xml_do_prepared (Arith.explode "r1") "r1"
                                (Xmlt.xml_take
                                  (CPF_Input_Parser.rules xml2name termIndexMap
                                    ruleMap)
                                  (\ xa -> Xmlt.xml_return (id xa))))
                              (\ r1 ->
                                Xmlt.xml_take
                                  (Xmlt.xml_do_prepared (Arith.explode "r2")
                                    "r2"
                                    (Xmlt.xml_take
                                      (CPF_Input_Parser.rules xml2name
termIndexMap ruleMap)
                                      (\ xa -> Xmlt.xml_return (id xa))))
                                  (\ r2 ->
                                    Xmlt.xml_take
                                      (Xmlt.xml_do_prepared
(Arith.explode "sigma") "sigma"
(Xmlt.xml_take_many_sub [] Arith.zero_nat Extended_Nat.Infinity_enat
  (Xmlt.xml_do_prepared (Arith.explode "symbol") "symbol"
    (Xmlt.xml_take xml2name Xmlt.xml_return))
  Xmlt.xml_return))
                                      (\ fs ->
Xmlt.xml_take (wcr_proof xml2name termIndexMap)
  (\ w ->
    Xmlt.xml_take (xml2trs_termination_proof xml2name termIndexMap ruleMap)
      (\ p ->
        Xmlt.xml_return (Check_Termination.AAECC_Innermost r1 r2 fs w p)))))))
                            (Xmlt.xml_dispatch_two
                              (Arith.explode "permutingArgumentFilter")
                              "permutingArgumentFilter"
                              (Xmlt.xml_take (afs xml2name)
                                (\ a ->
                                  Xmlt.xml_take
                                    (xml2trs_termination_proof xml2name
                                      termIndexMap ruleMap)
                                    (\ b ->
                                      Xmlt.xml_return
(Check_Termination.Permuting_AFS a b))))
                              (Arith.explode "terminationAssumption")
                              "terminationAssumption"
                              (Xmlt.xml_take
                                (xml2inn_trs_assm xml2name termIndexMap ruleMap)
                                (\ qtrs ->
                                  Xmlt.xml_return
                                    (Check_Termination.Assume_SN qtrs [])))
                              (Xmlt.xml_do_prepared
                                (Arith.explode "unknownProof") "unknownProof"
                                (Xmlt.xml_take (Xmlt.xml_text "description")
                                  (\ _ ->
                                    Xmlt.xml_take
                                      (xml2inn_trs_assm xml2name termIndexMap
ruleMap)
                                      (\ b ->
Xmlt.xml_take_many_sub [] Arith.zero_nat Extended_Nat.Infinity_enat
  (xml2subproof xml2name termIndexMap ruleMap)
  (\ c -> Xmlt.xml_return (Check_Termination.Assume_SN b c)))))))))))))))))))
    x;

xml2trs_termination_proof ::
  forall a b.
    (Compare.Compare_order a, Eq a, Term_Rewriting.Showl a,
      Compare.Compare_order b, Eq b,
      Term_Rewriting.Showl b) => ((Xml.Xml,
                                    ([([Arith.Char], [Arith.Char])],
                                      (Bool, ([String], [String])))) ->
                                   Strict_Sum.Sum_bot (Xmlt.Xml_error String)
                                     (Labelings.Lab a b)) ->
                                   Mapping.Mapping [Arith.Char]
                                     (Term_Rewriting.Term (Labelings.Lab a b)
                                       [Arith.Char]) ->
                                     Mapping.Mapping [Arith.Char]
                                       (Term_Rewriting.Term (Labelings.Lab a b)
  [Arith.Char],
 Term_Rewriting.Term (Labelings.Lab a b) [Arith.Char]) ->
                                       (Xml.Xml,
 ([([Arith.Char], [Arith.Char])], (Bool, ([String], [String])))) ->
 Strict_Sum.Sum_bot (Xmlt.Xml_error String)
   (Check_Termination.Trs_termination_proof a b [Arith.Char]);
xml2trs_termination_proof xml2name termIndexMap ruleMap x =
  Xmlt.xml_do_prepared (Arith.explode "trsTerminationProof")
    "trsTerminationProof"
    (Xmlt.xml_take
      (xml2trs_termination_proof_body xml2name termIndexMap ruleMap)
      (\ xa -> Xmlt.xml_return (id xa)))
    x;

xml2dp_termination_proof ::
  forall a b.
    (Compare.Compare_order a, Eq a, Term_Rewriting.Showl a,
      Compare.Compare_order b, Eq b,
      Term_Rewriting.Showl b) => ((Xml.Xml,
                                    ([([Arith.Char], [Arith.Char])],
                                      (Bool, ([String], [String])))) ->
                                   Strict_Sum.Sum_bot (Xmlt.Xml_error String)
                                     (Labelings.Lab a b)) ->
                                   Mapping.Mapping [Arith.Char]
                                     (Term_Rewriting.Term (Labelings.Lab a b)
                                       [Arith.Char]) ->
                                     Mapping.Mapping [Arith.Char]
                                       (Term_Rewriting.Term (Labelings.Lab a b)
  [Arith.Char],
 Term_Rewriting.Term (Labelings.Lab a b) [Arith.Char]) ->
                                       (Xml.Xml,
 ([([Arith.Char], [Arith.Char])], (Bool, ([String], [String])))) ->
 Strict_Sum.Sum_bot (Xmlt.Xml_error String)
   (Check_Termination.Dp_termination_proof a b [Arith.Char]);
xml2dp_termination_proof xml2name termIndexMap ruleMap x =
  Xmlt.xml_do_prepared (Arith.explode "dpProof") "dpProof"
    (Xmlt.xml_take
      (Xmlt.xml_do_or_prepared (Arith.explode "pIsEmpty") "pIsEmpty"
        (Xmlt.xml_return Check_Termination.P_is_Empty)
        (Xmlt.xml_dispatch_two (Arith.explode "depGraphProc") "depGraphProc"
          (Xmlt.xml_take_many_sub [] Arith.zero_nat Extended_Nat.Infinity_enat
            (Xmlt.xml_do_prepared (Arith.explode "component") "component"
              (Xmlt.xml_take
                (Xmlt.xml_do_prepared (Arith.explode "dps") "dps"
                  (Xmlt.xml_take
                    (CPF_Input_Parser.rules xml2name termIndexMap ruleMap)
                    (\ xa -> Xmlt.xml_return (id xa))))
                (\ dps ->
                  Xmlt.xml_take_optional
                    (xml2dp_termination_proof xml2name termIndexMap ruleMap)
                    (\ prfOpt -> Xmlt.xml_return (prfOpt, dps)))))
            (\ a -> Xmlt.xml_return (Check_Termination.Dep_Graph_Proc a)))
          (Arith.explode "redPairProc") "redPairProc"
          (Xmlt.xml_take (redtriple xml2name Labelings.Sharp False)
            (\ a ->
              Xmlt.xml_take
                (Xmlt.xml_do_prepared (Arith.explode "dps") "dps"
                  (Xmlt.xml_take
                    (CPF_Input_Parser.rules xml2name termIndexMap ruleMap)
                    (\ xa -> Xmlt.xml_return (id xa))))
                (\ b ->
                  Xmlt.xml_take
                    (xml2dp_termination_proof xml2name termIndexMap ruleMap)
                    (\ c ->
                      Xmlt.xml_return (Check_Termination.Redpair_Proc a b c)))))
          (Xmlt.xml_dispatch_two (Arith.explode "usableRulesProc")
            "usableRulesProc"
            (Xmlt.xml_take
              (Xmlt.xml_do_prepared (Arith.explode "usableRules") "usableRules"
                (Xmlt.xml_take
                  (CPF_Input_Parser.rules xml2name termIndexMap ruleMap)
                  (\ xa -> Xmlt.xml_return (id xa))))
              (\ a ->
                Xmlt.xml_take
                  (xml2dp_termination_proof xml2name termIndexMap ruleMap)
                  (\ b ->
                    Xmlt.xml_return (Check_Termination.Usable_Rules_Proc a b))))
            (Arith.explode "innermostLhssRemovalProc")
            "innermostLhssRemovalProc"
            (Xmlt.xml_take
              (CPF_Input_Parser.innermostLhss xml2name termIndexMap)
              (\ a ->
                Xmlt.xml_take
                  (xml2dp_termination_proof xml2name termIndexMap ruleMap)
                  (\ b ->
                    Xmlt.xml_return (Check_Termination.Q_Reduction_Proc a b))))
            (Xmlt.xml_dispatch_two (Arith.explode "rewritingProc")
              "rewritingProc"
              (Xmlt.xml_take
                (CPF_Input_Parser.rule xml2name termIndexMap ruleMap)
                (\ (s, t) ->
                  Xmlt.xml_take (rstep xml2name termIndexMap ruleMap)
                    (\ (p, (lr, ta)) ->
                      Xmlt.xml_take_default (s, ta)
                        (CPF_Input_Parser.rule xml2name termIndexMap ruleMap)
                        (\ st ->
                          Xmlt.xml_take_optional
                            (Xmlt.xml_do_prepared (Arith.explode "usableRules")
                              "usableRules"
                              (Xmlt.xml_take
                                (CPF_Input_Parser.rules xml2name termIndexMap
                                  ruleMap)
                                (\ xa -> Xmlt.xml_return (id xa))))
                            (\ ur ->
                              Xmlt.xml_take
                                (xml2dp_termination_proof xml2name termIndexMap
                                  ruleMap)
                                (\ prof ->
                                  Xmlt.xml_return
                                    (Check_Termination.Rewriting_Proc ur (s, t)
                                      (s, ta) st lr p prof)))))))
              (Arith.explode "narrowingProc") "narrowingProc"
              (Xmlt.xml_take
                (CPF_Input_Parser.rule xml2name termIndexMap ruleMap)
                (\ a ->
                  Xmlt.xml_take CPF_Input_Parser.pos
                    (\ b ->
                      Xmlt.xml_take
                        (Xmlt.xml_do_prepared (Arith.explode "narrowings")
                          "narrowings"
                          (Xmlt.xml_take
                            (CPF_Input_Parser.rules xml2name termIndexMap
                              ruleMap)
                            (\ xa -> Xmlt.xml_return (id xa))))
                        (\ c ->
                          Xmlt.xml_take
                            (xml2dp_termination_proof xml2name termIndexMap
                              ruleMap)
                            (\ d ->
                              Xmlt.xml_return
                                (Check_Termination.Narrowing_Proc a b c d))))))
              (Xmlt.xml_dispatch_two (Arith.explode "instantiationProc")
                "instantiationProc"
                (Xmlt.xml_take
                  (CPF_Input_Parser.rule xml2name termIndexMap ruleMap)
                  (\ a ->
                    Xmlt.xml_take
                      (Xmlt.xml_do_prepared (Arith.explode "instantiations")
                        "instantiations"
                        (Xmlt.xml_take
                          (CPF_Input_Parser.rules xml2name termIndexMap ruleMap)
                          (\ xa -> Xmlt.xml_return (id xa))))
                      (\ b ->
                        Xmlt.xml_take
                          (xml2dp_termination_proof xml2name termIndexMap
                            ruleMap)
                          (\ c ->
                            Xmlt.xml_return
                              (Check_Termination.Instantiation_Proc a b c)))))
                (Arith.explode "forwardInstantiationProc")
                "forwardInstantiationProc"
                (Xmlt.xml_take
                  (CPF_Input_Parser.rule xml2name termIndexMap ruleMap)
                  (\ a ->
                    Xmlt.xml_take
                      (Xmlt.xml_do_prepared (Arith.explode "instantiations")
                        "instantiations"
                        (Xmlt.xml_take
                          (CPF_Input_Parser.rules xml2name termIndexMap ruleMap)
                          (\ xa -> Xmlt.xml_return (id xa))))
                      (\ b ->
                        Xmlt.xml_take_optional
                          (Xmlt.xml_do_prepared (Arith.explode "usableRules")
                            "usableRules"
                            (Xmlt.xml_take
                              (CPF_Input_Parser.rules xml2name termIndexMap
                                ruleMap)
                              (\ xa -> Xmlt.xml_return (id xa))))
                          (\ c ->
                            Xmlt.xml_take
                              (xml2dp_termination_proof xml2name termIndexMap
                                ruleMap)
                              (\ d ->
                                Xmlt.xml_return
                                  (Check_Termination.Forward_Instantiation_Proc
                                    a b c d))))))
                (Xmlt.xml_dispatch_two (Arith.explode "semlabProc") "semlabProc"
                  (Xmlt.xml_take (sl_variant xml2name)
                    (\ sli ->
                      Xmlt.xml_take
                        (Xmlt.xml_do_prepared (Arith.explode "dps") "dps"
                          (Xmlt.xml_take
                            (CPF_Input_Parser.rules xml2name termIndexMap
                              ruleMap)
                            (\ xa -> Xmlt.xml_return (id xa))))
                        (\ lp ->
                          Xmlt.xml_take
                            (Xmlt.xml_do_prepared (Arith.explode "trs") "trs"
                              (Xmlt.xml_take
                                (CPF_Input_Parser.rules xml2name termIndexMap
                                  ruleMap)
                                (\ xa -> Xmlt.xml_return (id xa))))
                            (\ lr ->
                              Xmlt.xml_take_default []
                                (CPF_Input_Parser.innermostLhss xml2name
                                  termIndexMap)
                                (\ lq ->
                                  Xmlt.xml_take
                                    (xml2dp_termination_proof xml2name
                                      termIndexMap ruleMap)
                                    (\ p ->
                                      Xmlt.xml_return
(Check_Termination.Semlab_Proc sli lp lq lr p)))))))
                  (Arith.explode "subtermProc") "subtermProc"
                  (Xmlt.xml_take
                    (Xmlt.xml_or
                      (Xmlt.xml_change (proj xml2name)
                        (Xmlt.xml_return . Sum_Type.Inl))
                      (Xmlt.xml_change (multiset_af xml2name)
                        (Xmlt.xml_return . Sum_Type.Inr)))
                    (\ pi_mpi ->
                      Xmlt.xml_take_many_sub [] Arith.zero_nat
                        Extended_Nat.Infinity_enat
                        (projected_rseq xml2name termIndexMap ruleMap
                          (Subterm_Criterion_Impl.create_proj
                            (case pi_mpi of {
                              Sum_Type.Inl lpi -> lpi;
                              Sum_Type.Inr _ ->
                                Subterm_Criterion_Impl.Projection [];
                            })))
                        (\ seq ->
                          Xmlt.xml_take
                            (Xmlt.xml_do_prepared (Arith.explode "dps") "dps"
                              (Xmlt.xml_take
                                (CPF_Input_Parser.rules xml2name termIndexMap
                                  ruleMap)
                                (\ xa -> Xmlt.xml_return (id xa))))
                            (\ dps ->
                              Xmlt.xml_take
                                (xml2dp_termination_proof xml2name termIndexMap
                                  ruleMap)
                                (\ prf ->
                                  Xmlt.xml_return
                                    (case pi_mpi of {
                                      Sum_Type.Inl lpi ->
Check_Termination.Subterm_Criterion_Proc lpi seq dps prf;
                                      Sum_Type.Inr mpi ->
Check_Termination.Gen_Subterm_Criterion_Proc mpi dps prf;
                                    }))))))
                  (Xmlt.xml_dispatch_two (Arith.explode "redPairUrProc")
                    "redPairUrProc"
                    (Xmlt.xml_take (redtriple xml2name Labelings.Sharp False)
                      (\ a ->
                        Xmlt.xml_take
                          (Xmlt.xml_do_prepared (Arith.explode "dps") "dps"
                            (Xmlt.xml_take
                              (CPF_Input_Parser.rules xml2name termIndexMap
                                ruleMap)
                              (\ xa -> Xmlt.xml_return (id xa))))
                          (\ b ->
                            Xmlt.xml_take
                              (Xmlt.xml_do_prepared
                                (Arith.explode "usableRules") "usableRules"
                                (Xmlt.xml_take
                                  (CPF_Input_Parser.rules xml2name termIndexMap
                                    ruleMap)
                                  (\ xa -> Xmlt.xml_return (id xa))))
                              (\ c ->
                                Xmlt.xml_take
                                  (xml2dp_termination_proof xml2name
                                    termIndexMap ruleMap)
                                  (\ d ->
                                    Xmlt.xml_return
                                      (Check_Termination.Redpair_UR_Proc a b c
d))))))
                    (Arith.explode "monoRedPairUrProc") "monoRedPairUrProc"
                    (Xmlt.xml_take (redtriple xml2name Labelings.Sharp False)
                      (\ a ->
                        Xmlt.xml_take
                          (Xmlt.xml_do_prepared (Arith.explode "dps") "dps"
                            (Xmlt.xml_take
                              (CPF_Input_Parser.rules xml2name termIndexMap
                                ruleMap)
                              (\ xa -> Xmlt.xml_return (id xa))))
                          (\ b ->
                            Xmlt.xml_take
                              (Xmlt.xml_do_prepared (Arith.explode "trs") "trs"
                                (Xmlt.xml_take
                                  (CPF_Input_Parser.rules xml2name termIndexMap
                                    ruleMap)
                                  (\ xa -> Xmlt.xml_return (id xa))))
                              (\ c ->
                                Xmlt.xml_take
                                  (Xmlt.xml_do_prepared
                                    (Arith.explode "usableRules") "usableRules"
                                    (Xmlt.xml_take
                                      (CPF_Input_Parser.rules xml2name
termIndexMap ruleMap)
                                      (\ xa -> Xmlt.xml_return (id xa))))
                                  (\ d ->
                                    Xmlt.xml_take
                                      (xml2dp_termination_proof xml2name
termIndexMap ruleMap)
                                      (\ e ->
Xmlt.xml_return (Check_Termination.Mono_Redpair_UR_Proc a b c d e)))))))
                    (Xmlt.xml_dispatch_two (Arith.explode "monoRedPairProc")
                      "monoRedPairProc"
                      (Xmlt.xml_take (redtriple xml2name Labelings.Sharp False)
                        (\ a ->
                          Xmlt.xml_take
                            (Xmlt.xml_do_prepared (Arith.explode "dps") "dps"
                              (Xmlt.xml_take
                                (CPF_Input_Parser.rules xml2name termIndexMap
                                  ruleMap)
                                (\ xa -> Xmlt.xml_return (id xa))))
                            (\ b ->
                              Xmlt.xml_take
                                (Xmlt.xml_do_prepared (Arith.explode "trs")
                                  "trs"
                                  (Xmlt.xml_take
                                    (CPF_Input_Parser.rules xml2name
                                      termIndexMap ruleMap)
                                    (\ xa -> Xmlt.xml_return (id xa))))
                                (\ c ->
                                  Xmlt.xml_take
                                    (xml2dp_termination_proof xml2name
                                      termIndexMap ruleMap)
                                    (\ d ->
                                      Xmlt.xml_return
(Check_Termination.Mono_Redpair_Proc a b c d))))))
                      (Arith.explode "innermostMonoRedPairProc")
                      "innermostMonoRedPairProc"
                      (Xmlt.xml_take (redtriple xml2name Labelings.Sharp False)
                        (\ rp ->
                          Xmlt.xml_take
                            (Xmlt.xml_do_prepared (Arith.explode "dps") "dps"
                              (Xmlt.xml_take
                                (CPF_Input_Parser.rules xml2name termIndexMap
                                  ruleMap)
                                (\ xa -> Xmlt.xml_return (id xa))))
                            (\ p ->
                              Xmlt.xml_take
                                (Xmlt.xml_do_prepared (Arith.explode "trs")
                                  "trs"
                                  (Xmlt.xml_take
                                    (CPF_Input_Parser.rules xml2name
                                      termIndexMap ruleMap)
                                    (\ xa -> Xmlt.xml_return (id xa))))
                                (\ r ->
                                  Xmlt.xml_take
                                    (xml2dp_termination_proof xml2name
                                      termIndexMap ruleMap)
                                    (\ c ->
                                      Xmlt.xml_return
(Check_Termination.Mono_URM_Redpair_Proc rp p r c))))))
                      (Xmlt.xml_dispatch_two (Arith.explode "uncurryProc")
                        "uncurryProc"
                        (Xmlt.xml_take_optional (Xmlt.xml_nat "applicativeTop")
                          (\ a ->
                            Xmlt.xml_take
                              (uncurry_info xml2name termIndexMap ruleMap)
                              (\ b ->
                                Xmlt.xml_take
                                  (Xmlt.xml_do_prepared (Arith.explode "dps")
                                    "dps"
                                    (Xmlt.xml_take
                                      (CPF_Input_Parser.rules xml2name
termIndexMap ruleMap)
                                      (\ xa -> Xmlt.xml_return (id xa))))
                                  (\ c ->
                                    Xmlt.xml_take
                                      (Xmlt.xml_do_prepared
(Arith.explode "trs") "trs"
(Xmlt.xml_take (CPF_Input_Parser.rules xml2name termIndexMap ruleMap)
  (\ xa -> Xmlt.xml_return (id xa))))
                                      (\ d ->
Xmlt.xml_take (xml2dp_termination_proof xml2name termIndexMap ruleMap)
  (\ e -> Xmlt.xml_return (Check_Termination.Uncurry_Proc a b c d e)))))))
                        (Arith.explode "flatContextClosureProc")
                        "flatContextClosureProc"
                        (Xmlt.xml_take
                          (Xmlt.xml_do_prepared (Arith.explode "freshSymbol")
                            "freshSymbol"
                            (Xmlt.xml_take xml2name
                              (\ xa -> Xmlt.xml_return (id xa))))
                          (\ a ->
                            Xmlt.xml_take (flat_contexts xml2name termIndexMap)
                              (\ b ->
                                Xmlt.xml_take
                                  (Xmlt.xml_do_prepared (Arith.explode "dps")
                                    "dps"
                                    (Xmlt.xml_take
                                      (CPF_Input_Parser.rules xml2name
termIndexMap ruleMap)
                                      (\ xa -> Xmlt.xml_return (id xa))))
                                  (\ c ->
                                    Xmlt.xml_take
                                      (Xmlt.xml_do_prepared
(Arith.explode "trs") "trs"
(Xmlt.xml_take (CPF_Input_Parser.rules xml2name termIndexMap ruleMap)
  (\ xa -> Xmlt.xml_return (id xa))))
                                      (\ d ->
Xmlt.xml_take (xml2dp_termination_proof xml2name termIndexMap ruleMap)
  (\ e -> Xmlt.xml_return (Check_Termination.Fcc_Proc a b c d e)))))))
                        (Xmlt.xml_dispatch_two
                          (Arith.explode "switchInnermostProc")
                          "switchInnermostProc"
                          (Xmlt.xml_take (wcr_proof xml2name termIndexMap)
                            (\ a ->
                              Xmlt.xml_take
                                (xml2dp_termination_proof xml2name termIndexMap
                                  ruleMap)
                                (\ b ->
                                  Xmlt.xml_return
                                    (Check_Termination.Switch_Innermost_Proc a
                                      b))))
                          (Arith.explode "splitProc") "splitProc"
                          (Xmlt.xml_take
                            (Xmlt.xml_do_prepared (Arith.explode "dps") "dps"
                              (Xmlt.xml_take
                                (CPF_Input_Parser.rules xml2name termIndexMap
                                  ruleMap)
                                (\ xa -> Xmlt.xml_return (id xa))))
                            (\ a ->
                              Xmlt.xml_take
                                (Xmlt.xml_do_prepared (Arith.explode "trs")
                                  "trs"
                                  (Xmlt.xml_take
                                    (CPF_Input_Parser.rules xml2name
                                      termIndexMap ruleMap)
                                    (\ xa -> Xmlt.xml_return (id xa))))
                                (\ b ->
                                  Xmlt.xml_take
                                    (xml2dp_termination_proof xml2name
                                      termIndexMap ruleMap)
                                    (\ c ->
                                      Xmlt.xml_take
(xml2dp_termination_proof xml2name termIndexMap ruleMap)
(\ d -> Xmlt.xml_return (Check_Termination.Split_Proc a b c d))))))
                          (Xmlt.xml_dispatch_two
                            (Arith.explode "finitenessAssumption")
                            "finitenessAssumption"
                            (Xmlt.xml_take
                              (xml2dp_input xml2name termIndexMap ruleMap True)
                              (\ dpp ->
                                Xmlt.xml_return
                                  (Check_Termination.Assume_Finite dpp [])))
                            (Arith.explode "unknownProof") "unknownProof"
                            (Xmlt.xml_take (Xmlt.xml_text "description")
                              (\ _ ->
                                Xmlt.xml_take
                                  (xml2dp_input xml2name termIndexMap ruleMap
                                    True)
                                  (\ b ->
                                    Xmlt.xml_take_many_sub [] Arith.zero_nat
                                      Extended_Nat.Infinity_enat
                                      (xml2subproof xml2name termIndexMap
ruleMap)
                                      (\ c ->
Xmlt.xml_return (Check_Termination.Assume_Finite b c)))))
                            (Xmlt.xml_dispatch_two (Arith.explode "switchToTRS")
                              "switchToTRS"
                              (Xmlt.xml_take
                                (xml2trs_termination_proof xml2name termIndexMap
                                  ruleMap)
                                (\ a ->
                                  Xmlt.xml_return
                                    (Check_Termination.To_Trs_Proc a)))
                              (Arith.explode "qdpToSrs") "qdpToSrs"
                              (Xmlt.xml_take
                                (xml2trs_termination_proof xml2name termIndexMap
                                  ruleMap)
                                (\ a ->
                                  Xmlt.xml_return
                                    (Check_Termination.Zantema_To_SRS_Proc a)))
                              (Xmlt.xml_dispatch_two
                                (Arith.explode "generalRedPairProc")
                                "generalRedPairProc"
                                (Xmlt.xml_take
                                  (redtriple xml2name Labelings.Sharp True)
                                  (\ rp ->
                                    Xmlt.xml_take
                                      (Xmlt.xml_do_prepared
(Arith.explode "strict") "strict"
(Xmlt.xml_take (CPF_Input_Parser.rules xml2name termIndexMap ruleMap)
  (\ xa -> Xmlt.xml_return (id xa))))
                                      (\ s ->
Xmlt.xml_take
  (Xmlt.xml_do_prepared (Arith.explode "bound") "bound"
    (Xmlt.xml_take (CPF_Input_Parser.rules xml2name termIndexMap ruleMap)
      (\ xa -> Xmlt.xml_return (id xa))))
  (\ b ->
    Xmlt.xml_take (xml2cond_red_pair_proof xml2name termIndexMap ruleMap)
      (\ c ->
        Xmlt.xml_take (xml2dp_termination_proof xml2name termIndexMap ruleMap)
          (\ ps ->
            Xmlt.xml_take_optional
              (xml2dp_termination_proof xml2name termIndexMap ruleMap)
              (\ pbo ->
                Xmlt.xml_return
                  (Check_Termination.General_Redpair_Proc rp s b c
                    (case pbo of {
                      Nothing -> [ps];
                      Just pb -> [ps, pb];
                    })))))))))
                                (Arith.explode "complexConstantRemovalProc")
                                "complexConstantRemovalProc"
                                (Xmlt.xml_take
                                  (CPF_Input_Parser.term xml2name termIndexMap)
                                  (\ t ->
                                    Xmlt.xml_take
                                      (Xmlt.xml_do_prepared
(Arith.explode "ruleMap") "ruleMap"
(Xmlt.xml_take_many_sub [] Arith.zero_nat Extended_Nat.Infinity_enat
  (Xmlt.xml_do_prepared (Arith.explode "ruleMapEntry") "ruleMapEntry"
    (Xmlt.xml_take (CPF_Input_Parser.rule xml2name termIndexMap ruleMap)
      (\ a ->
        Xmlt.xml_take (CPF_Input_Parser.rule xml2name termIndexMap ruleMap)
          (\ b -> Xmlt.xml_return (a, b)))))
  Xmlt.xml_return))
                                      (\ rls ->
Xmlt.xml_take (xml2dp_termination_proof xml2name termIndexMap ruleMap)
  (\ prf ->
    Xmlt.xml_return
      (Check_Termination.Complex_Constant_Removal_Proc
        (Complex_Constant_Removal_Impl.Complex_Constant_Removal_Proof t rls)
        prf)))))
                                (Xmlt.xml_do_prepared
                                  (Arith.explode "sizeChangeProc")
                                  "sizeChangeProc"
                                  (Xmlt.xml_take
                                    (Xmlt.xml_or
                                      (Xmlt.xml_leaf "subtermCriterion" Nothing)
                                      (Xmlt.xml_do_prepared
(Arith.explode "reductionPair") "reductionPair"
(Xmlt.xml_take (redtriple xml2name Labelings.Sharp False)
  (\ redp ->
    Xmlt.xml_take_optional
      (Xmlt.xml_do_prepared (Arith.explode "usableRules") "usableRules"
        (Xmlt.xml_take (CPF_Input_Parser.rules xml2name termIndexMap ruleMap)
          (\ xa -> Xmlt.xml_return (id xa))))
      (\ ur -> Xmlt.xml_return (Just (redp, ur)))))))
                                    (\ version ->
                                      Xmlt.xml_take_many_sub [] Arith.zero_nat
Extended_Nat.Infinity_enat (scg xml2name termIndexMap ruleMap)
(\ b ->
  (case version of {
    Nothing -> Xmlt.xml_return (Check_Termination.Size_Change_Subterm_Proc b);
    Just redp_ur ->
      Xmlt.xml_return
        (Check_Termination.Size_Change_Redpair_Proc (fst redp_ur) (snd redp_ur)
          b);
  }))))))))))))))))))
      (\ xa -> Xmlt.xml_return (id xa)))
    x;

symbol_parser ::
  (Xml.Xml, ([([Arith.Char], [Arith.Char])], (Bool, ([String], [String])))) ->
    Strict_Sum.Sum_bot (Xmlt.Xml_error String)
      (Labelings.Lab [Arith.Char] [Arith.Nat]);
symbol_parser x =
  Xmlt.xml_or
    (Xmlt.xml_change (Xmlt.xml_text "name") (Xmlt.xml_return . Labelings.UnLab))
    (Xmlt.xml_do_or_prepared (Arith.explode "sharp") "sharp"
      (Xmlt.xml_take symbol_parser
        (\ xa -> Xmlt.xml_return (Labelings.Sharp xa)))
      (Xmlt.xml_do_prepared (Arith.explode "labeledSymbol") "labeledSymbol"
        (Xmlt.xml_take symbol_parser
          (\ a ->
            Xmlt.xml_take
              (Xmlt.xml_do_or_prepared (Arith.explode "numberLabel")
                "numberLabel"
                (Xmlt.xml_take_many_sub [] Arith.zero_nat
                  Extended_Nat.Infinity_enat (Xmlt.xml_nat "number")
                  (\ aa -> Xmlt.xml_return (Sum_Type.Inl aa)))
                (Xmlt.xml_do_prepared (Arith.explode "symbolLabel")
                  "symbolLabel"
                  (Xmlt.xml_take_many_sub [] Arith.zero_nat
                    Extended_Nat.Infinity_enat symbol_parser
                    (\ aa -> Xmlt.xml_return (Sum_Type.Inr aa)))))
              (\ b ->
                Xmlt.xml_return (case b of {
                                  Sum_Type.Inl ba -> Labelings.Lab a ba;
                                  Sum_Type.Inr ba -> Labelings.FunLab a ba;
                                }))))))
    x;

}
