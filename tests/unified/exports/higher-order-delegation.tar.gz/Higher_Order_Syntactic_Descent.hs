{-# LANGUAGE EmptyDataDecls, RankNTypes, ScopedTypeVariables #-}

module Higher_Order_Syntactic_Descent(ho_lex_subterm) where {

import Prelude ((==), (/=), (<), (<=), (>=), (>), (+), (-), (*), (/), (**),
  (>>=), (>>), (=<<), (&&), (||), (^), (^^), (.), ($), ($!), (++), (!!), Eq,
  error, id, return, not, fst, snd, map, filter, concat, concatMap, reverse,
  zip, null, takeWhile, dropWhile, all, any, Integer, negate, abs, divMod,
  String, Bool(True, False), Maybe(Nothing, Just));
import Data.Bits ((.&.), (.|.), (.^.));
import qualified Prelude;
import qualified Data.Bits;
import qualified Uint;
import qualified Array;
import qualified IArray;
import qualified Uint32;
import qualified Uint64;
import qualified Data_Bits;
import qualified Bit_Shifts;
import qualified Str_Literal;
import qualified Higher_Order_Core;
import qualified Arith;

ho_app_subterm ::
  Higher_Order_Core.Ho_term -> Higher_Order_Core.Ho_term -> Bool;
ho_app_subterm s (Higher_Order_Core.HApp f x) =
  Higher_Order_Core.equal_ho_term s (Higher_Order_Core.HApp f x) ||
    (ho_app_subterm s f || ho_app_subterm s x);
ho_app_subterm s (Higher_Order_Core.HBound v) =
  Higher_Order_Core.equal_ho_term s (Higher_Order_Core.HBound v);
ho_app_subterm s (Higher_Order_Core.HFree v) =
  Higher_Order_Core.equal_ho_term s (Higher_Order_Core.HFree v);
ho_app_subterm s (Higher_Order_Core.HConst v) =
  Higher_Order_Core.equal_ho_term s (Higher_Order_Core.HConst v);
ho_app_subterm s (Higher_Order_Core.HAbs v va) =
  Higher_Order_Core.equal_ho_term s (Higher_Order_Core.HAbs v va);

ho_lex_subterm ::
  [Higher_Order_Core.Ho_term] -> [Higher_Order_Core.Ho_term] -> Bool;
ho_lex_subterm [] ys = False;
ho_lex_subterm (x : xs) [] = False;
ho_lex_subterm (x : xs) (y : ys) =
  Arith.equal_nat (Arith.size_list xs) (Arith.size_list ys) &&
    (Higher_Order_Core.equal_ho_term x y && ho_lex_subterm xs ys ||
      not (Higher_Order_Core.equal_ho_term x y) && ho_app_subterm x y);

}
