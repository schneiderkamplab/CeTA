{-# LANGUAGE EmptyDataDecls, RankNTypes, ScopedTypeVariables #-}

module Higher_Order_Application(ho_application_rule) where {

import Prelude ((==), (/=), (<), (<=), (>=), (>), (+), (-), (*), (/), (**),
  (>>=), (>>), (=<<), (&&), (||), (^), (^^), (.), ($), ($!), (++), (!!), Eq,
  error, id, return, not, fst, snd, map, filter, concat, concatMap, reverse,
  zip, null, takeWhile, dropWhile, all, any, Integer, negate, abs, divMod,
  String, Bool(True, False), Maybe(Nothing, Just));
import Data.Bits ((.&.), (.|.), (.^.));
import qualified Prelude;
import qualified Data.Bits;
import qualified Uint;
import qualified Array;
import qualified IArray;
import qualified Uint32;
import qualified Uint64;
import qualified Data_Bits;
import qualified Bit_Shifts;
import qualified Str_Literal;
import qualified Higher_Order_Core;
import qualified Arith;

ho_application_rule ::
  Higher_Order_Core.Ho_type ->
    Higher_Order_Core.Ho_type ->
      Arith.Nat ->
        ([Higher_Order_Core.Ho_type],
          (Higher_Order_Core.Ho_pattern, Higher_Order_Core.Ho_pattern));
ho_application_rule a b c =
  ([Higher_Order_Core.HArrow a b, a],
    (Higher_Order_Core.PApp
       (Higher_Order_Core.PApp (Higher_Order_Core.PConst c)
         (Higher_Order_Core.PMeta Arith.zero_nat []))
       (Higher_Order_Core.PMeta Arith.one_nat []),
      Higher_Order_Core.PApp (Higher_Order_Core.PMeta Arith.zero_nat [])
        (Higher_Order_Core.PMeta Arith.one_nat [])));

}
