{-# LANGUAGE EmptyDataDecls, RankNTypes, ScopedTypeVariables #-}

module Higher_Order_Semantic_Delegation_Check(ho_check_semantic_delegation_side)
  where {

import Prelude ((==), (/=), (<), (<=), (>=), (>), (+), (-), (*), (/), (**),
  (>>=), (>>), (=<<), (&&), (||), (^), (^^), (.), ($), ($!), (++), (!!), Eq,
  error, id, return, not, fst, snd, map, filter, concat, concatMap, reverse,
  zip, null, takeWhile, dropWhile, all, any, Integer, negate, abs, divMod,
  String, Bool(True, False), Maybe(Nothing, Just));
import Data.Bits ((.&.), (.|.), (.^.));
import qualified Prelude;
import qualified Data.Bits;
import qualified Uint;
import qualified Array;
import qualified IArray;
import qualified Uint32;
import qualified Uint64;
import qualified Data_Bits;
import qualified Bit_Shifts;
import qualified Str_Literal;
import qualified Higher_Order_Semantic_Schema;
import qualified Higher_Order_Call_Polynomial;
import qualified Higher_Order_Finite_Branching;
import qualified Higher_Order_Candidate_Interpretation;
import qualified Higher_Order_Source_Computability;
import qualified Higher_Order_Delegation_Partition;
import qualified Higher_Order_Source_Order;
import qualified Higher_Order_Full_Application;
import qualified HOL;
import qualified Higher_Order_Polynomial;
import qualified Higher_Order_Core;
import qualified Higher_Order_Algebraic_Embedding;
import qualified Arith;

ho_check_semantic_delegation_side ::
  [Higher_Order_Core.Ho_type] ->
    [([Higher_Order_Core.Ho_type],
       (Higher_Order_Core.Ho_pattern, Higher_Order_Core.Ho_pattern))] ->
      [Arith.Nat] ->
        [(Higher_Order_Algebraic_Embedding.Ho_fo_tree,
           Higher_Order_Algebraic_Embedding.Ho_fo_tree)] ->
          [Higher_Order_Polynomial.Ho_polynomial] ->
            [Higher_Order_Polynomial.Ho_polynomial] ->
              Arith.Nat ->
                [Arith.Nat] ->
                  [Arith.Nat] ->
                    [Arith.Nat] -> [Arith.Nat] -> Arith.Nat -> Bool;
ho_check_semantic_delegation_side s r f p ps ms ofuel ranks arities priorities
  sorts fuel =
  Higher_Order_Polynomial.ho_check_polynomial_signature s ps &&
    Higher_Order_Polynomial.ho_check_polynomial_signature s ms &&
      all (\ (g, (a, b)) ->
            Higher_Order_Call_Polynomial.ho_check_weak_polynomial_rule s ps
              ofuel g a b)
        r &&
        Arith.equal_nat (Arith.size_list ranks) (Arith.size_list s) &&
          Arith.equal_nat (Arith.size_list arities) (Arith.size_list s) &&
            all (\ n -> Arith.less_eq_nat n (Arith.size_list priorities))
              arities &&
              let {
                d = Arith.minus_nat (Arith.size_list s) Arith.one_nat;
              } in (if Arith.less_nat d (Arith.size_list s)
                     then Arith.all_interval
                            (\ i ->
                              Arith.less_eq_nat (Arith.nth arities i)
                                (Arith.size_list
                                  (Higher_Order_Full_Application.ho_argument_types
                                    (Arith.nth s i))))
                            Arith.zero_nat d
                     else True) &&
                all (\ c ->
                      Arith.less_nat c (Arith.size_list s) &&
                        Arith.equal_nat (Arith.nth arities c)
                          (Arith.size_list
                            (Higher_Order_Full_Application.ho_argument_types
                              (Arith.nth s c))) &&
                          all (Higher_Order_Candidate_Interpretation.ho_positive_type
                                (\ b ->
                                  (if Arith.less_nat b (Arith.size_list sorts)
                                    then Arith.nth sorts b else Arith.zero_nat))
                                (if Arith.less_nat
                                      (Higher_Order_Full_Application.ho_result_sort
(Arith.nth s c))
                                      (Arith.size_list sorts)
                                  then Arith.nth sorts
 (Higher_Order_Full_Application.ho_result_sort (Arith.nth s c))
                                  else Arith.zero_nat))
                            (Higher_Order_Full_Application.ho_argument_types
                              (Arith.nth s c)))
                  f &&
                  Higher_Order_Source_Order.ho_zero_arity_rules r &&
                    Higher_Order_Finite_Branching.ho_finitely_matching_rules
                      r &&
                      all (Higher_Order_Core.ho_rule_welltyped s) r &&
                        all (Higher_Order_Delegation_Partition.ho_partition_rule
                              (Arith.set f) (Arith.nth arities) (Arith.set p))
                          r &&
                          all (\ (g, (l, ra)) ->
                                (case Higher_Order_Source_Computability.ho_application_head
(Higher_Order_Core.ho_erase_pattern l)
                                  of {
                                  Higher_Order_Core.HBound _ -> False;
                                  Higher_Order_Core.HFree _ -> False;
                                  Higher_Order_Core.HConst c ->
                                    Arith.membera f c ||
                                      Higher_Order_Semantic_Schema.ho_check_semantic_schema_rule
s (\ b ->
    (if Arith.less_nat b (Arith.size_list sorts) then Arith.nth sorts b
      else Arith.zero_nat))
ps ms ofuel (Arith.nth ranks) (Arith.nth priorities) (Arith.nth arities) fuel
(g, (l, ra));
                                  Higher_Order_Core.HApp _ _ -> False;
                                  Higher_Order_Core.HAbs _ _ -> False;
                                }))
                            r;

}
