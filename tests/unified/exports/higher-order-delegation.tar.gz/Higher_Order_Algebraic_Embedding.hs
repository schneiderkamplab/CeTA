{-# LANGUAGE EmptyDataDecls, RankNTypes, ScopedTypeVariables #-}

module
  Higher_Order_Algebraic_Embedding(Ho_fo_tree(..), ho_fo_variables,
                                    ho_fo_wellformed)
  where {

import Prelude ((==), (/=), (<), (<=), (>=), (>), (+), (-), (*), (/), (**),
  (>>=), (>>), (=<<), (&&), (||), (^), (^^), (.), ($), ($!), (++), (!!), Eq,
  error, id, return, not, fst, snd, map, filter, concat, concatMap, reverse,
  zip, null, takeWhile, dropWhile, all, any, Integer, negate, abs, divMod,
  String, Bool(True, False), Maybe(Nothing, Just));
import Data.Bits ((.&.), (.|.), (.^.));
import qualified Prelude;
import qualified Data.Bits;
import qualified Uint;
import qualified Array;
import qualified IArray;
import qualified Uint32;
import qualified Uint64;
import qualified Data_Bits;
import qualified Bit_Shifts;
import qualified Str_Literal;
import qualified Complete_Lattices;
import qualified Comparator;
import qualified Phantom_Type;
import qualified Arith;

data Ho_fo_tree = HFOVar Arith.Nat | HFOFun Arith.Nat [Ho_fo_tree];

instance Eq Ho_fo_tree where {
  a == b = equal_ho_fo_tree a b;
};

equal_ho_fo_tree :: Ho_fo_tree -> Ho_fo_tree -> Bool;
equal_ho_fo_tree (HFOVar x1) (HFOFun x21 x22) = False;
equal_ho_fo_tree (HFOFun x21 x22) (HFOVar x1) = False;
equal_ho_fo_tree (HFOFun x21 x22) (HFOFun y21 y22) =
  Arith.equal_nat x21 y21 && x22 == y22;
equal_ho_fo_tree (HFOVar x1) (HFOVar y1) = Arith.equal_nat x1 y1;

ceq_ho_fo_tree :: Maybe (Ho_fo_tree -> Ho_fo_tree -> Bool);
ceq_ho_fo_tree = Just equal_ho_fo_tree;

instance Arith.Ceq Ho_fo_tree where {
  ceq = ceq_ho_fo_tree;
};

set_impl_ho_fo_tree :: Phantom_Type.Phantom Ho_fo_tree Arith.Set_impla;
set_impl_ho_fo_tree = Phantom_Type.Phantom Arith.Set_RBT;

instance Arith.Set_impl Ho_fo_tree where {
  set_impl = set_impl_ho_fo_tree;
};

comparator_ho_fo_tree :: Ho_fo_tree -> Ho_fo_tree -> Comparator.Order;
comparator_ho_fo_tree (HFOVar x) (HFOVar y) = Comparator.comparator_of x y;
comparator_ho_fo_tree (HFOVar x) (HFOFun ya yb) = Comparator.Lt;
comparator_ho_fo_tree (HFOFun x xa) (HFOVar y) = Comparator.Gt;
comparator_ho_fo_tree (HFOFun x xa) (HFOFun ya yb) =
  (case Comparator.comparator_of x ya of {
    Comparator.Eqa -> Arith.comparator_list comparator_ho_fo_tree xa yb;
    Comparator.Lt -> Comparator.Lt;
    Comparator.Gt -> Comparator.Gt;
  });

compare_ho_fo_tree :: Ho_fo_tree -> Ho_fo_tree -> Comparator.Order;
compare_ho_fo_tree = comparator_ho_fo_tree;

ccompare_ho_fo_tree :: Maybe (Ho_fo_tree -> Ho_fo_tree -> Comparator.Order);
ccompare_ho_fo_tree = Just compare_ho_fo_tree;

instance Arith.Ccompare Ho_fo_tree where {
  ccompare = ccompare_ho_fo_tree;
};

ho_fo_variables :: Ho_fo_tree -> Arith.Set Arith.Nat;
ho_fo_variables (HFOVar n) =
  Arith.insert n (Arith.set_empty (Phantom_Type.of_phantom Arith.set_impl_nat));
ho_fo_variables (HFOFun c ts) =
  Complete_Lattices.sup_set (Arith.image ho_fo_variables (Arith.set ts));

ho_fo_wellformed ::
  Arith.Set Arith.Nat -> (Arith.Nat -> Arith.Nat) -> Ho_fo_tree -> Bool;
ho_fo_wellformed f arity (HFOVar n) = True;
ho_fo_wellformed f arity (HFOFun c ts) =
  Arith.member c f &&
    Arith.equal_nat (Arith.size_list ts) (arity c) &&
      all (ho_fo_wellformed f arity) ts;

}
