{-# LANGUAGE EmptyDataDecls, RankNTypes, ScopedTypeVariables #-}

module Higher_Order_CeTA_Semantic_Check(ho_check_ceta_semantic_delegation_xml)
  where {

import Prelude ((==), (/=), (<), (<=), (>=), (>), (+), (-), (*), (/), (**),
  (>>=), (>>), (=<<), (&&), (||), (^), (^^), (.), ($), ($!), (++), (!!), Eq,
  error, id, return, not, fst, snd, map, filter, concat, concatMap, reverse,
  zip, null, takeWhile, dropWhile, all, any, Integer, negate, abs, divMod,
  String, Bool(True, False), Maybe(Nothing, Just));
import Data.Bits ((.&.), (.|.), (.^.));
import qualified Prelude;
import qualified Data.Bits;
import qualified Uint;
import qualified Array;
import qualified IArray;
import qualified Uint32;
import qualified Uint64;
import qualified Data_Bits;
import qualified Bit_Shifts;
import qualified Str_Literal;
import qualified CPF_Proof_Parser;
import qualified Dependency_Pair_Problem_Impl;
import qualified Termination_Problem_Impl;
import qualified Phantom_Type;
import qualified Strict_Sum;
import qualified Xmlt;
import qualified Xml;
import qualified Mapping;
import qualified Higher_Order_Semantic_Delegation_Check;
import qualified Higher_Order_CeTA_Check;
import qualified Error_Monad;
import qualified Dependency_Pair_Problem_Spec;
import qualified Higher_Order_Algebraic_Embedding;
import qualified Termination_Problem_Spec;
import qualified Check_Termination;
import qualified Higher_Order_Polynomial;
import qualified Higher_Order_Core;
import qualified Labelings;
import qualified Sum_Type;
import qualified Arith;
import qualified Compare_Order_Instances;
import qualified Term_Rewriting;
import qualified Countable;

ho_check_ceta_semantic_delegation ::
  forall a b.
    Termination_Problem_Spec.Tp_ops_ext a
      (Labelings.Lab [Arith.Char] [Arith.Nat]) [Arith.Char] () ->
      Dependency_Pair_Problem_Spec.Dpp_ops_ext b
        (Labelings.Lab [Arith.Char] [Arith.Nat]) [Arith.Char] () ->
        [Higher_Order_Core.Ho_type] ->
          [([Higher_Order_Core.Ho_type],
             (Higher_Order_Core.Ho_pattern, Higher_Order_Core.Ho_pattern))] ->
            [Arith.Nat] ->
              [(Higher_Order_Algebraic_Embedding.Ho_fo_tree,
                 Higher_Order_Algebraic_Embedding.Ho_fo_tree)] ->
                Arith.Nat ->
                  [Higher_Order_Polynomial.Ho_polynomial] ->
                    [Higher_Order_Polynomial.Ho_polynomial] ->
                      Arith.Nat ->
                        [Arith.Nat] ->
                          [Arith.Nat] ->
                            [Arith.Nat] ->
                              [Arith.Nat] ->
                                Arith.Nat ->
                                  Check_Termination.Trs_termination_proof
                                    [Arith.Char] [Arith.Nat] [Arith.Char] ->
                                    Bool;
ho_check_ceta_semantic_delegation i j s r f p ce ps ms ofuel ranks arities
  priorities sorts fuel prf =
  Higher_Order_Semantic_Delegation_Check.ho_check_semantic_delegation_side s r f
    p ps ms ofuel ranks arities priorities sorts fuel &&
    Error_Monad.isOK
      (Check_Termination.check_trs_termination_proof i j False id
        (Termination_Problem_Spec.mk i False []
          (Higher_Order_CeTA_Check.ho_delegation_trs p ce) [])
        prf);

ho_check_ceta_semantic_delegation_xml ::
  [Higher_Order_Core.Ho_type] ->
    [([Higher_Order_Core.Ho_type],
       (Higher_Order_Core.Ho_pattern, Higher_Order_Core.Ho_pattern))] ->
      [Arith.Nat] ->
        [(Higher_Order_Algebraic_Embedding.Ho_fo_tree,
           Higher_Order_Algebraic_Embedding.Ho_fo_tree)] ->
          Arith.Nat ->
            [Higher_Order_Polynomial.Ho_polynomial] ->
              [Higher_Order_Polynomial.Ho_polynomial] ->
                Arith.Nat ->
                  [Arith.Nat] ->
                    [Arith.Nat] ->
                      [Arith.Nat] ->
                        [Arith.Nat] -> Arith.Nat -> [Arith.Char] -> Bool;
ho_check_ceta_semantic_delegation_xml s r f p ce ps ms ofuel ranks arities
  priorities sorts fuel xml =
  Strict_Sum.case_sum_bot False (\ _ -> False)
    (ho_check_ceta_semantic_delegation Termination_Problem_Impl.tp_rbt_impl
      Dependency_Pair_Problem_Impl.dpp_rbt_impl s r f p ce ps ms ofuel ranks
      arities priorities sorts fuel)
    (Xmlt.parse_xml_string
      (CPF_Proof_Parser.xml2trs_termination_proof CPF_Proof_Parser.symbol_parser
        (Mapping.mapping_empty
          (Phantom_Type.of_phantom Mapping.mapping_impl_list))
        (Mapping.mapping_empty
          (Phantom_Type.of_phantom Mapping.mapping_impl_list)))
      xml);

}
