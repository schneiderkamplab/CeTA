{-# LANGUAGE EmptyDataDecls, RankNTypes, ScopedTypeVariables #-}

module Multimap(values, delete_values, insert_values, intersect_values) where {

import Prelude ((==), (/=), (<), (<=), (>=), (>), (+), (-), (*), (/), (**),
  (>>=), (>>), (=<<), (&&), (||), (^), (^^), (.), ($), ($!), (++), (!!), Eq,
  error, id, return, not, fst, snd, map, filter, concat, concatMap, reverse,
  zip, null, takeWhile, dropWhile, all, any, Integer, negate, abs, divMod,
  String, Bool(True, False), Maybe(Nothing, Just));
import Data.Bits ((.&.), (.|.), (.^.));
import qualified Prelude;
import qualified Data.Bits;
import qualified Uint;
import qualified Array;
import qualified IArray;
import qualified Uint32;
import qualified Uint64;
import qualified Data_Bits;
import qualified Bit_Shifts;
import qualified Str_Literal;
import qualified HOL;
import qualified Quasi_Order;
import qualified Arith;
import qualified RBT;
import qualified Compare;

aux ::
  forall a b.
    (Eq a,
      Compare.Compare_order b) => (a -> Maybe b) ->
                                    RBT.Rbt b [a] ->
                                      a -> RBT.Rbt b [a] -> RBT.Rbt b [a];
aux key ma v m =
  (case key v of {
    Nothing -> m;
    Just k ->
      (case RBT.lookup ma k of {
        Nothing -> m;
        Just ws ->
          (if Arith.membera ws v
            then (case RBT.lookup m k of {
                   Nothing -> RBT.insert k [v] m;
                   Just vs -> RBT.insert k (Arith.inserta v vs) m;
                 })
            else m);
      });
  });

values :: forall a b. (Quasi_Order.Linorder a) => RBT.Rbt a [b] -> [b];
values m = concatMap snd (RBT.entries m);

touch_bucket ::
  forall a b c.
    (Compare.Compare_order b) => (a -> Maybe b) ->
                                   a -> RBT.Rbt b c -> RBT.Rbt b c;
touch_bucket key_of v m = (case key_of v of {
                            Nothing -> m;
                            Just k -> (case RBT.lookup m k of {
Nothing -> m;
Just xs -> RBT.insert k xs m;
                                      });
                          });

touch_buckets ::
  forall a b c.
    (Compare.Compare_order b) => (a -> Maybe b) ->
                                   [a] -> RBT.Rbt b c -> RBT.Rbt b c;
touch_buckets key_of [] m = m;
touch_buckets key_of (v : vs) m =
  touch_bucket key_of v (touch_buckets key_of vs m);

bucket_filter ::
  forall a b.
    (Arith.Ceq a, Arith.Ccompare a, Eq b,
      Quasi_Order.Linorder b) => (a -> Maybe b) ->
                                   Arith.Set a ->
                                     RBT.Rbt b [a] -> RBT.Rbt b [a];
bucket_filter key_of d m =
  RBT.mapa
    (\ k -> filter (\ v -> not (key_of v == Just k) || not (Arith.member v d)))
    m;

delete_values ::
  forall a b.
    (Arith.Ceq a, Arith.Ccompare a, Arith.Set_impl a, Compare.Compare_order b,
      Eq b) => (a -> Maybe b) -> [a] -> RBT.Rbt b [a] -> RBT.Rbt b [a];
delete_values key_of vs m =
  touch_buckets key_of vs (bucket_filter key_of (Arith.set vs) m);

indexed_insert_step ::
  forall a b.
    (Arith.Ceq a, Arith.Ccompare a, Arith.Set_impl a,
      Compare.Compare_order b) => (a -> Maybe b) ->
                                    a -> (RBT.Rbt b [a],
   RBT.Rbt b (Arith.Set a)) ->
   (RBT.Rbt b [a], RBT.Rbt b (Arith.Set a));
indexed_insert_step key_of v accum =
  (case accum of {
    (m, ix) ->
      (case key_of v of {
        Nothing -> (m, ix);
        Just k ->
          (case RBT.lookup m k of {
            Nothing ->
              (RBT.insert k [v] m,
                RBT.insert k (Arith.insert v Arith.bot_set) ix);
            Just xs ->
              let {
                s = Arith.the (RBT.lookup ix k);
              } in (RBT.insert k (if Arith.member v s then xs else v : xs) m,
                     RBT.insert k (Arith.insert v s) ix);
          });
      });
  });

indexed_insert_values ::
  forall a b.
    (Arith.Ceq a, Arith.Ccompare a, Arith.Set_impl a,
      Compare.Compare_order b) => (a -> Maybe b) ->
                                    [a] ->
                                      (RBT.Rbt b [a],
RBT.Rbt b (Arith.Set a)) ->
(RBT.Rbt b [a], RBT.Rbt b (Arith.Set a));
indexed_insert_values key_of [] accum = accum;
indexed_insert_values key_of (v : vs) accum =
  indexed_insert_step key_of v (indexed_insert_values key_of vs accum);

insert_values ::
  forall a b.
    (Arith.Ceq a, Arith.Ccompare a, Arith.Set_impl a,
      Compare.Compare_order b) => (a -> Maybe b) ->
                                    [a] -> RBT.Rbt b [a] -> RBT.Rbt b [a];
insert_values key_of vs m =
  fst (indexed_insert_values key_of vs (m, RBT.mapa (\ _ -> Arith.set) m));

intersect_values ::
  forall a b.
    (Eq a,
      Compare.Compare_order b) => (a -> Maybe b) ->
                                    [a] -> RBT.Rbt b [a] -> RBT.Rbt b [a];
intersect_values key vs m = Arith.foldr (aux key m) vs RBT.empty;

}
