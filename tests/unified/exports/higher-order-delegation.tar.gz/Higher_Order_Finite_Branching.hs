{-# LANGUAGE EmptyDataDecls, RankNTypes, ScopedTypeVariables #-}

module Higher_Order_Finite_Branching(ho_finitely_matching_rules) where {

import Prelude ((==), (/=), (<), (<=), (>=), (>), (+), (-), (*), (/), (**),
  (>>=), (>>), (=<<), (&&), (||), (^), (^^), (.), ($), ($!), (++), (!!), Eq,
  error, id, return, not, fst, snd, map, filter, concat, concatMap, reverse,
  zip, null, takeWhile, dropWhile, all, any, Integer, negate, abs, divMod,
  String, Bool(True, False), Maybe(Nothing, Just));
import Data.Bits ((.&.), (.|.), (.^.));
import qualified Prelude;
import qualified Data.Bits;
import qualified Uint;
import qualified Array;
import qualified IArray;
import qualified Uint32;
import qualified Uint64;
import qualified Data_Bits;
import qualified Bit_Shifts;
import qualified Str_Literal;
import qualified Higher_Order_Source_Order;
import qualified Higher_Order_Core;
import qualified Phantom_Type;
import qualified Arith;

ho_free_support :: Higher_Order_Core.Ho_term -> Arith.Set Arith.Nat;
ho_free_support (Higher_Order_Core.HFree n) =
  Arith.insert n (Arith.set_empty (Phantom_Type.of_phantom Arith.set_impl_nat));
ho_free_support (Higher_Order_Core.HApp f x) =
  Arith.sup_set (ho_free_support f) (ho_free_support x);
ho_free_support (Higher_Order_Core.HAbs a t) = ho_free_support t;
ho_free_support (Higher_Order_Core.HBound v) =
  Arith.set_empty (Phantom_Type.of_phantom Arith.set_impl_nat);
ho_free_support (Higher_Order_Core.HConst v) =
  Arith.set_empty (Phantom_Type.of_phantom Arith.set_impl_nat);

ho_finitely_matching_rules ::
  forall a.
    [(a, (Higher_Order_Core.Ho_pattern, Higher_Order_Core.Ho_pattern))] -> Bool;
ho_finitely_matching_rules r =
  all (\ (_, (l, ra)) ->
        Higher_Order_Source_Order.ho_zero_arity_pattern l &&
          Higher_Order_Source_Order.ho_zero_arity_pattern ra &&
            Arith.less_eq_set
              (ho_free_support (Higher_Order_Core.ho_erase_pattern ra))
              (ho_free_support (Higher_Order_Core.ho_erase_pattern l)))
    r;

}
