{-# LANGUAGE EmptyDataDecls, RankNTypes, ScopedTypeVariables #-}

module Higher_Order_CeTA_Check(ho_delegation_trs, ho_check_ceta_delegation_xml)
  where {

import Prelude ((==), (/=), (<), (<=), (>=), (>), (+), (-), (*), (/), (**),
  (>>=), (>>), (=<<), (&&), (||), (^), (^^), (.), ($), ($!), (++), (!!), Eq,
  error, id, return, not, fst, snd, map, filter, concat, concatMap, reverse,
  zip, null, takeWhile, dropWhile, all, any, Integer, negate, abs, divMod,
  String, Bool(True, False), Maybe(Nothing, Just));
import Data.Bits ((.&.), (.|.), (.^.));
import qualified Prelude;
import qualified Data.Bits;
import qualified Uint;
import qualified Array;
import qualified IArray;
import qualified Uint32;
import qualified Uint64;
import qualified Data_Bits;
import qualified Bit_Shifts;
import qualified Str_Literal;
import qualified CPF_Proof_Parser;
import qualified Dependency_Pair_Problem_Impl;
import qualified Termination_Problem_Impl;
import qualified Phantom_Type;
import qualified Strict_Sum;
import qualified Xmlt;
import qualified Xml;
import qualified Mapping;
import qualified Higher_Order_Delegation_Check;
import qualified Error_Monad;
import qualified Dependency_Pair_Problem_Spec;
import qualified Termination_Problem_Spec;
import qualified Check_Termination;
import qualified Higher_Order_Core;
import qualified Sum_Type;
import qualified Compare_Order_Instances;
import qualified Countable;
import qualified Higher_Order_Algebraic_Embedding;
import qualified Term_Rewriting;
import qualified Labelings;
import qualified Arith;

ho_fo_symbol :: forall a. Arith.Nat -> Labelings.Lab [Arith.Char] a;
ho_fo_symbol c =
  Labelings.UnLab (Arith.replicate c Arith.char_0x66 ++ [Arith.char_0x73]);

ho_to_fo_term ::
  Higher_Order_Algebraic_Embedding.Ho_fo_tree ->
    Term_Rewriting.Term (Labelings.Lab [Arith.Char] [Arith.Nat]) [Arith.Char];
ho_to_fo_term (Higher_Order_Algebraic_Embedding.HFOVar n) =
  Term_Rewriting.Var (Arith.replicate n Arith.char_0x78 ++ [Arith.char_0x76]);
ho_to_fo_term (Higher_Order_Algebraic_Embedding.HFOFun c ts) =
  Term_Rewriting.Fun (ho_fo_symbol c) (map ho_to_fo_term ts);

ho_delegation_trs ::
  [(Higher_Order_Algebraic_Embedding.Ho_fo_tree,
     Higher_Order_Algebraic_Embedding.Ho_fo_tree)] ->
    Arith.Nat ->
      [(Term_Rewriting.Term (Labelings.Lab [Arith.Char] [Arith.Nat])
          [Arith.Char],
         Term_Rewriting.Term (Labelings.Lab [Arith.Char] [Arith.Nat])
           [Arith.Char])];
ho_delegation_trs p ce =
  map (\ (pa, q) -> (ho_to_fo_term pa, ho_to_fo_term q)) p ++
    [(Term_Rewriting.Fun (ho_fo_symbol ce)
        [Term_Rewriting.Var [Arith.char_0x76],
          Term_Rewriting.Var [Arith.char_0x78, Arith.char_0x76]],
       Term_Rewriting.Var [Arith.char_0x76]),
      (Term_Rewriting.Fun (ho_fo_symbol ce)
         [Term_Rewriting.Var [Arith.char_0x76],
           Term_Rewriting.Var [Arith.char_0x78, Arith.char_0x76]],
        Term_Rewriting.Var [Arith.char_0x78, Arith.char_0x76])];

ho_check_ceta_delegation ::
  forall a b.
    Termination_Problem_Spec.Tp_ops_ext a
      (Labelings.Lab [Arith.Char] [Arith.Nat]) [Arith.Char] () ->
      Dependency_Pair_Problem_Spec.Dpp_ops_ext b
        (Labelings.Lab [Arith.Char] [Arith.Nat]) [Arith.Char] () ->
        [Higher_Order_Core.Ho_type] ->
          [([Higher_Order_Core.Ho_type],
             (Higher_Order_Core.Ho_pattern, Higher_Order_Core.Ho_pattern))] ->
            [Arith.Nat] ->
              [(Higher_Order_Algebraic_Embedding.Ho_fo_tree,
                 Higher_Order_Algebraic_Embedding.Ho_fo_tree)] ->
                Arith.Nat ->
                  [Arith.Nat] ->
                    [Arith.Nat] ->
                      [Arith.Nat] ->
                        [Arith.Nat] ->
                          Arith.Nat ->
                            Check_Termination.Trs_termination_proof [Arith.Char]
                              [Arith.Nat] [Arith.Char] ->
                              Bool;
ho_check_ceta_delegation i j s r f p ce ranks arities priorities sorts fuel prf
  = Higher_Order_Delegation_Check.ho_check_delegation_side s r f p ranks arities
      priorities sorts fuel &&
      Error_Monad.isOK
        (Check_Termination.check_trs_termination_proof i j False id
          (Termination_Problem_Spec.mk i False [] (ho_delegation_trs p ce) [])
          prf);

ho_check_ceta_delegation_xml ::
  [Higher_Order_Core.Ho_type] ->
    [([Higher_Order_Core.Ho_type],
       (Higher_Order_Core.Ho_pattern, Higher_Order_Core.Ho_pattern))] ->
      [Arith.Nat] ->
        [(Higher_Order_Algebraic_Embedding.Ho_fo_tree,
           Higher_Order_Algebraic_Embedding.Ho_fo_tree)] ->
          Arith.Nat ->
            [Arith.Nat] ->
              [Arith.Nat] ->
                [Arith.Nat] -> [Arith.Nat] -> Arith.Nat -> [Arith.Char] -> Bool;
ho_check_ceta_delegation_xml s r f p ce ranks arities priorities sorts fuel xml
  = Strict_Sum.case_sum_bot False (\ _ -> False)
      (ho_check_ceta_delegation Termination_Problem_Impl.tp_rbt_impl
        Dependency_Pair_Problem_Impl.dpp_rbt_impl s r f p ce ranks arities
        priorities sorts fuel)
      (Xmlt.parse_xml_string
        (CPF_Proof_Parser.xml2trs_termination_proof
          CPF_Proof_Parser.symbol_parser
          (Mapping.mapping_empty
            (Phantom_Type.of_phantom Mapping.mapping_impl_list))
          (Mapping.mapping_empty
            (Phantom_Type.of_phantom Mapping.mapping_impl_list)))
        xml);

}
