{-# LANGUAGE EmptyDataDecls, RankNTypes, ScopedTypeVariables #-}

module
  Higher_Order_Polynomial_Dominance(ho_check_monotone_base_ge,
                                     ho_check_monotone_base_gt)
  where {

import Prelude ((==), (/=), (<), (<=), (>=), (>), (+), (-), (*), (/), (**),
  (>>=), (>>), (=<<), (&&), (||), (^), (^^), (.), ($), ($!), (++), (!!), Eq,
  error, id, return, not, fst, snd, map, filter, concat, concatMap, reverse,
  zip, null, takeWhile, dropWhile, all, any, Integer, negate, abs, divMod,
  String, Bool(True, False), Maybe(Nothing, Just));
import Data.Bits ((.&.), (.|.), (.^.));
import qualified Prelude;
import qualified Data.Bits;
import qualified Uint;
import qualified Array;
import qualified IArray;
import qualified Uint32;
import qualified Uint64;
import qualified Data_Bits;
import qualified Bit_Shifts;
import qualified Str_Literal;
import qualified Higher_Order_Polynomial_Normalization;
import qualified Higher_Order_Polynomial_Comparison;
import qualified Higher_Order_Polynomial;
import qualified Higher_Order_Core;
import qualified Quasi_Order;
import qualified Arith;

ho_monomial_dominates ::
  forall a b. (Eq b) => (a -> b -> Bool) -> [a] -> [b] -> Bool;
ho_monomial_dominates r [] ys = null ys;
ho_monomial_dominates r (x : xs) ys =
  any (\ y -> r x y && ho_monomial_dominates r xs (Arith.remove1 y ys)) ys;

ho_poly_consume_term ::
  forall a b c.
    (Eq b, Arith.Minus c, Arith.Zero c, Eq c,
      Quasi_Order.Ord c) => (a -> b -> Bool) ->
                              c -> [b] -> [(c, [a])] -> Maybe [(c, [a])];
ho_poly_consume_term r c m [] = (if c == Arith.zero then Just [] else Nothing);
ho_poly_consume_term r c m ((d, n) : p) =
  (if ho_monomial_dominates r n m
    then (if Quasi_Order.less_eq c d then Just ((Arith.minusa d c, n) : p)
           else ho_poly_consume_term r (Arith.minusa c d) m p)
    else Arith.map_option (\ a -> (d, n) : a) (ho_poly_consume_term r c m p));

ho_poly_consume ::
  forall a b c.
    (Eq b, Arith.Minus c, Arith.Zero c, Eq c,
      Quasi_Order.Ord c) => (a -> b -> Bool) ->
                              [(c, [a])] -> [(c, [b])] -> Maybe [(c, [a])];
ho_poly_consume r p [] = Just p;
ho_poly_consume r p ((c, m) : q) = (case ho_poly_consume_term r c m p of {
                                     Nothing -> Nothing;
                                     Just ra -> ho_poly_consume r ra q;
                                   });

ho_structural_polynomial_ge ::
  Arith.Nat ->
    [Higher_Order_Core.Ho_type] ->
      Higher_Order_Core.Ho_type ->
        Higher_Order_Polynomial.Ho_polynomial ->
          Higher_Order_Polynomial.Ho_polynomial -> Bool;
ho_structural_polynomial_ge fuel g a p q =
  (if Arith.equal_nat fuel Arith.zero_nat
    then Higher_Order_Polynomial.equal_ho_polynomial p q &&
           Higher_Order_Polynomial.ho_polynomial_typeof g p == Just a
    else Higher_Order_Polynomial.ho_polynomial_typeof g p == Just a &&
           Higher_Order_Polynomial.ho_polynomial_typeof g q == Just a &&
             (Higher_Order_Polynomial.equal_ho_polynomial p q ||
               ((case a of {
                  Higher_Order_Core.HBase b ->
                    Higher_Order_Polynomial_Comparison.ho_check_base_polynomial_ge
                      g b p q;
                  Higher_Order_Core.HArrow b c ->
                    ho_structural_polynomial_ge
                      (Arith.minus_nat fuel Arith.one_nat) (b : g) c
                      (Higher_Order_Polynomial_Normalization.ho_polynomial_normalize
                        (Arith.nat_of_integer (16 :: Integer))
                        (Higher_Order_Polynomial.HPApply b c
                          (Higher_Order_Polynomial_Normalization.ho_polynomial_rename
                            Arith.suc p)
                          (Higher_Order_Polynomial.HPVar Arith.zero_nat)))
                      (Higher_Order_Polynomial_Normalization.ho_polynomial_normalize
                        (Arith.nat_of_integer (16 :: Integer))
                        (Higher_Order_Polynomial.HPApply b c
                          (Higher_Order_Polynomial_Normalization.ho_polynomial_rename
                            Arith.suc q)
                          (Higher_Order_Polynomial.HPVar Arith.zero_nat)));
                }) ||
                 (case (p, q) of {
                   (Higher_Order_Polynomial.HPVar _, _) -> False;
                   (Higher_Order_Polynomial.HPNumber _ _, _) -> False;
                   (Higher_Order_Polynomial.HPAdd _ _ _, _) -> False;
                   (Higher_Order_Polynomial.HPMultiply _ _ _, _) -> False;
                   (Higher_Order_Polynomial.HPApply _ _ _ _,
                     Higher_Order_Polynomial.HPVar _)
                     -> False;
                   (Higher_Order_Polynomial.HPApply _ _ _ _,
                     Higher_Order_Polynomial.HPNumber _ _)
                     -> False;
                   (Higher_Order_Polynomial.HPApply _ _ _ _,
                     Higher_Order_Polynomial.HPAdd _ _ _)
                     -> False;
                   (Higher_Order_Polynomial.HPApply _ _ _ _,
                     Higher_Order_Polynomial.HPMultiply _ _ _)
                     -> False;
                   (Higher_Order_Polynomial.HPApply ba c f x,
                     Higher_Order_Polynomial.HPApply d e ga y)
                     -> Higher_Order_Core.equal_ho_type ba d &&
                          Higher_Order_Core.equal_ho_type c a &&
                            Higher_Order_Core.equal_ho_type e a &&
                              ho_structural_polynomial_ge
                                (Arith.minus_nat fuel Arith.one_nat) g
                                (Higher_Order_Core.HArrow ba a) f ga &&
                                ho_structural_polynomial_ge
                                  (Arith.minus_nat fuel Arith.one_nat) g ba x y;
                   (Higher_Order_Polynomial.HPApply _ _ _ _,
                     Higher_Order_Polynomial.HPAbstract _ _ _)
                     -> False;
                   (Higher_Order_Polynomial.HPAbstract _ _ _, _) -> False;
                 }))));

ho_function_atom_dominates ::
  [Higher_Order_Core.Ho_type] ->
    Higher_Order_Polynomial.Ho_polynomial ->
      Higher_Order_Polynomial.Ho_polynomial -> Bool;
ho_function_atom_dominates ga
  (Higher_Order_Polynomial.HPApply (Higher_Order_Core.HBase a)
    (Higher_Order_Core.HBase b) f x)
  (Higher_Order_Polynomial.HPApply (Higher_Order_Core.HBase c)
    (Higher_Order_Core.HBase d) g y)
  = Arith.equal_nat a c &&
      Arith.equal_nat b d &&
        Higher_Order_Polynomial.equal_ho_polynomial f g &&
          Higher_Order_Polynomial.ho_polynomial_typeof ga f ==
            Just (Higher_Order_Core.HArrow (Higher_Order_Core.HBase a)
                   (Higher_Order_Core.HBase b)) &&
            Higher_Order_Polynomial_Comparison.ho_check_base_polynomial_ge ga a
              x y;
ho_function_atom_dominates g (Higher_Order_Polynomial.HPVar v) q =
  Higher_Order_Polynomial.equal_ho_polynomial (Higher_Order_Polynomial.HPVar v)
    q;
ho_function_atom_dominates g (Higher_Order_Polynomial.HPNumber v va) q =
  Higher_Order_Polynomial.equal_ho_polynomial
    (Higher_Order_Polynomial.HPNumber v va) q;
ho_function_atom_dominates g (Higher_Order_Polynomial.HPAdd v va vb) q =
  Higher_Order_Polynomial.equal_ho_polynomial
    (Higher_Order_Polynomial.HPAdd v va vb) q;
ho_function_atom_dominates g (Higher_Order_Polynomial.HPMultiply v va vb) q =
  Higher_Order_Polynomial.equal_ho_polynomial
    (Higher_Order_Polynomial.HPMultiply v va vb) q;
ho_function_atom_dominates g
  (Higher_Order_Polynomial.HPApply (Higher_Order_Core.HArrow vd ve) va vb vc) q
  = Higher_Order_Polynomial.equal_ho_polynomial
      (Higher_Order_Polynomial.HPApply (Higher_Order_Core.HArrow vd ve) va vb
        vc)
      q;
ho_function_atom_dominates g
  (Higher_Order_Polynomial.HPApply v (Higher_Order_Core.HArrow vd ve) vb vc) q =
  Higher_Order_Polynomial.equal_ho_polynomial
    (Higher_Order_Polynomial.HPApply v (Higher_Order_Core.HArrow vd ve) vb vc)
    q;
ho_function_atom_dominates g (Higher_Order_Polynomial.HPAbstract v va vb) q =
  Higher_Order_Polynomial.equal_ho_polynomial
    (Higher_Order_Polynomial.HPAbstract v va vb) q;
ho_function_atom_dominates g p (Higher_Order_Polynomial.HPVar v) =
  Higher_Order_Polynomial.equal_ho_polynomial p
    (Higher_Order_Polynomial.HPVar v);
ho_function_atom_dominates g p (Higher_Order_Polynomial.HPNumber v va) =
  Higher_Order_Polynomial.equal_ho_polynomial p
    (Higher_Order_Polynomial.HPNumber v va);
ho_function_atom_dominates g p (Higher_Order_Polynomial.HPAdd v va vb) =
  Higher_Order_Polynomial.equal_ho_polynomial p
    (Higher_Order_Polynomial.HPAdd v va vb);
ho_function_atom_dominates g p (Higher_Order_Polynomial.HPMultiply v va vb) =
  Higher_Order_Polynomial.equal_ho_polynomial p
    (Higher_Order_Polynomial.HPMultiply v va vb);
ho_function_atom_dominates g p
  (Higher_Order_Polynomial.HPApply (Higher_Order_Core.HArrow vd ve) va vb vc) =
  Higher_Order_Polynomial.equal_ho_polynomial p
    (Higher_Order_Polynomial.HPApply (Higher_Order_Core.HArrow vd ve) va vb vc);
ho_function_atom_dominates g p
  (Higher_Order_Polynomial.HPApply v (Higher_Order_Core.HArrow vd ve) vb vc) =
  Higher_Order_Polynomial.equal_ho_polynomial p
    (Higher_Order_Polynomial.HPApply v (Higher_Order_Core.HArrow vd ve) vb vc);
ho_function_atom_dominates g p (Higher_Order_Polynomial.HPAbstract v va vb) =
  Higher_Order_Polynomial.equal_ho_polynomial p
    (Higher_Order_Polynomial.HPAbstract v va vb);

ho_curried_atom_dominates ::
  [Higher_Order_Core.Ho_type] ->
    Higher_Order_Polynomial.Ho_polynomial ->
      Higher_Order_Polynomial.Ho_polynomial -> Bool;
ho_curried_atom_dominates g p q =
  ho_function_atom_dominates g p q ||
    (case Higher_Order_Polynomial.ho_polynomial_typeof g p of {
      Nothing -> False;
      Just (Higher_Order_Core.HBase b) ->
        ho_structural_polynomial_ge (Arith.nat_of_integer (16 :: Integer)) g
          (Higher_Order_Core.HBase b) p q;
      Just (Higher_Order_Core.HArrow _ _) -> False;
    });

ho_check_monotone_base_ge ::
  [Higher_Order_Core.Ho_type] ->
    Arith.Nat ->
      Higher_Order_Polynomial.Ho_polynomial ->
        Higher_Order_Polynomial.Ho_polynomial -> Bool;
ho_check_monotone_base_ge g b p q =
  Higher_Order_Polynomial.ho_polynomial_typeof g p ==
    Just (Higher_Order_Core.HBase b) &&
    Higher_Order_Polynomial.ho_polynomial_typeof g q ==
      Just (Higher_Order_Core.HBase b) &&
      not (Arith.is_none
            (ho_poly_consume (ho_curried_atom_dominates g)
              (Higher_Order_Polynomial_Comparison.ho_polynomial_coefficients p)
              (Higher_Order_Polynomial_Comparison.ho_polynomial_coefficients
                q)));

ho_check_monotone_base_gt ::
  [Higher_Order_Core.Ho_type] ->
    Arith.Nat ->
      Higher_Order_Polynomial.Ho_polynomial ->
        Higher_Order_Polynomial.Ho_polynomial -> Bool;
ho_check_monotone_base_gt g b p q =
  Higher_Order_Polynomial.ho_polynomial_typeof g p ==
    Just (Higher_Order_Core.HBase b) &&
    Higher_Order_Polynomial.ho_polynomial_typeof g q ==
      Just (Higher_Order_Core.HBase b) &&
      (case ho_poly_consume (ho_curried_atom_dominates g)
              (Higher_Order_Polynomial_Comparison.ho_polynomial_coefficients p)
              (Higher_Order_Polynomial_Comparison.ho_polynomial_coefficients q)
        of {
        Nothing -> False;
        Just a ->
          Higher_Order_Polynomial_Comparison.ho_poly_positive_constant a;
      });

}
