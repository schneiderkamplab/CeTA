{-# LANGUAGE EmptyDataDecls, RankNTypes, ScopedTypeVariables #-}

module
  Higher_Order_Functional_Access_Schema(ho_check_functional_access_schema_rule)
  where {

import Prelude ((==), (/=), (<), (<=), (>=), (>), (+), (-), (*), (/), (**),
  (>>=), (>>), (=<<), (&&), (||), (^), (^^), (.), ($), ($!), (++), (!!), Eq,
  error, id, return, not, fst, snd, map, filter, concat, concatMap, reverse,
  zip, null, takeWhile, dropWhile, all, any, Integer, negate, abs, divMod,
  String, Bool(True, False), Maybe(Nothing, Just));
import Data.Bits ((.&.), (.|.), (.^.));
import qualified Prelude;
import qualified Data.Bits;
import qualified Uint;
import qualified Array;
import qualified IArray;
import qualified Uint32;
import qualified Uint64;
import qualified Data_Bits;
import qualified Bit_Shifts;
import qualified Str_Literal;
import qualified Higher_Order_Functional_Access_Closure;
import qualified Higher_Order_Source_Computability;
import qualified Higher_Order_Full_Application;
import qualified Higher_Order_Closure_Check;
import qualified Arith;
import qualified Higher_Order_Core;

ho_check_functional_access_schema_rule ::
  [Higher_Order_Core.Ho_type] ->
    [([Higher_Order_Core.Ho_type],
       (Higher_Order_Core.Ho_pattern, Higher_Order_Core.Ho_pattern))] ->
      (Arith.Nat -> Arith.Nat) ->
        (Arith.Nat -> Arith.Nat) ->
          (Arith.Nat -> Arith.Nat) ->
            (Arith.Nat -> Arith.Nat) ->
              Arith.Nat ->
                ([Higher_Order_Core.Ho_type],
                  (Higher_Order_Core.Ho_pattern,
                    Higher_Order_Core.Ho_pattern)) ->
                  Bool;
ho_check_functional_access_schema_rule s r sorts prec priority arity fuel rule =
  (case rule of {
    (g, (l, ra)) ->
      Higher_Order_Core.ho_rule_welltyped s (g, (l, ra)) &&
        (case Higher_Order_Source_Computability.ho_application_head
                (Higher_Order_Core.ho_erase_pattern l)
          of {
          Higher_Order_Core.HBound _ -> False;
          Higher_Order_Core.HFree _ -> False;
          Higher_Order_Core.HConst c ->
            (case Higher_Order_Core.ho_lookup s c of {
              Nothing -> False;
              Just t ->
                Arith.list_all2
                  (\ a x -> Higher_Order_Core.ho_typeof s g [] x == Just a)
                  (Arith.take (arity c)
                    (Higher_Order_Full_Application.ho_argument_types t))
                  (Higher_Order_Closure_Check.ho_spine_arguments
                    (Higher_Order_Core.ho_erase_pattern l)) &&
                  Higher_Order_Functional_Access_Closure.ho_check_functional_access_closure
                    s g r sorts prec priority arity c
                    (Higher_Order_Closure_Check.ho_spine_arguments
                      (Higher_Order_Core.ho_erase_pattern l))
                    fuel [] (Higher_Order_Core.ho_erase_pattern ra);
            });
          Higher_Order_Core.HApp _ _ -> False;
          Higher_Order_Core.HAbs _ _ -> False;
        });
  });

}
