{-# LANGUAGE EmptyDataDecls, RankNTypes, ScopedTypeVariables #-}

module Rewrite_Relations_Impl(is_par_rstep) where {

import Prelude ((==), (/=), (<), (<=), (>=), (>), (+), (-), (*), (/), (**),
  (>>=), (>>), (=<<), (&&), (||), (^), (^^), (.), ($), ($!), (++), (!!), Eq,
  error, id, return, not, fst, snd, map, filter, concat, concatMap, reverse,
  zip, null, takeWhile, dropWhile, all, any, Integer, negate, abs, divMod,
  String, Bool(True, False), Maybe(Nothing, Just));
import Data.Bits ((.&.), (.|.), (.^.));
import qualified Prelude;
import qualified Data.Bits;
import qualified Uint;
import qualified Array;
import qualified IArray;
import qualified Uint32;
import qualified Uint64;
import qualified Data_Bits;
import qualified Bit_Shifts;
import qualified Str_Literal;
import qualified Mapping;
import qualified Compare;
import qualified Arith;
import qualified Term_Rewriting;

is_par_rstep ::
  forall a b.
    (Compare.Compare a, Eq a, Arith.Ccompare b, Compare.Compare b, Eq b,
      Mapping.Mapping_impl b) => [(Term_Rewriting.Term a b,
                                    Term_Rewriting.Term a b)] ->
                                   Term_Rewriting.Term a b ->
                                     Term_Rewriting.Term a b -> Bool;
is_par_rstep r (Term_Rewriting.Fun f ss) (Term_Rewriting.Fun g ts) =
  Term_Rewriting.equal_term (Term_Rewriting.Fun f ss)
    (Term_Rewriting.Fun g ts) ||
    (Term_Rewriting.is_root_step (Arith.set r) (Term_Rewriting.Fun f ss)
       (Term_Rewriting.Fun g ts) ||
      f == g &&
        Arith.equal_nat (Arith.size_list ss) (Arith.size_list ts) &&
          Arith.list_all2 (is_par_rstep r) ss ts);
is_par_rstep r (Term_Rewriting.Var v) t =
  Term_Rewriting.equal_term (Term_Rewriting.Var v) t ||
    Term_Rewriting.is_root_step (Arith.set r) (Term_Rewriting.Var v) t;
is_par_rstep r s (Term_Rewriting.Var v) =
  Term_Rewriting.equal_term s (Term_Rewriting.Var v) ||
    Term_Rewriting.is_root_step (Arith.set r) s (Term_Rewriting.Var v);

}
