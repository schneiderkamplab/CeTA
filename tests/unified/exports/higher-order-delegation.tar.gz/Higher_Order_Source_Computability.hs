{-# LANGUAGE EmptyDataDecls, RankNTypes, ScopedTypeVariables #-}

module Higher_Order_Source_Computability(ho_application_head) where {

import Prelude ((==), (/=), (<), (<=), (>=), (>), (+), (-), (*), (/), (**),
  (>>=), (>>), (=<<), (&&), (||), (^), (^^), (.), ($), ($!), (++), (!!), Eq,
  error, id, return, not, fst, snd, map, filter, concat, concatMap, reverse,
  zip, null, takeWhile, dropWhile, all, any, Integer, negate, abs, divMod,
  String, Bool(True, False), Maybe(Nothing, Just));
import Data.Bits ((.&.), (.|.), (.^.));
import qualified Prelude;
import qualified Data.Bits;
import qualified Uint;
import qualified Array;
import qualified IArray;
import qualified Uint32;
import qualified Uint64;
import qualified Data_Bits;
import qualified Bit_Shifts;
import qualified Str_Literal;
import qualified Higher_Order_Core;
import qualified Arith;

ho_application_head :: Higher_Order_Core.Ho_term -> Higher_Order_Core.Ho_term;
ho_application_head (Higher_Order_Core.HApp f x) = ho_application_head f;
ho_application_head (Higher_Order_Core.HBound v) = Higher_Order_Core.HBound v;
ho_application_head (Higher_Order_Core.HFree v) = Higher_Order_Core.HFree v;
ho_application_head (Higher_Order_Core.HConst v) = Higher_Order_Core.HConst v;
ho_application_head (Higher_Order_Core.HAbs v va) = Higher_Order_Core.HAbs v va;

}
