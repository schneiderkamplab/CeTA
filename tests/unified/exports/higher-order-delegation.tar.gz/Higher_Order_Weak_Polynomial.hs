{-# LANGUAGE EmptyDataDecls, RankNTypes, ScopedTypeVariables #-}

module Higher_Order_Weak_Polynomial(ho_weak_polynomial_translate) where {

import Prelude ((==), (/=), (<), (<=), (>=), (>), (+), (-), (*), (/), (**),
  (>>=), (>>), (=<<), (&&), (||), (^), (^^), (.), ($), ($!), (++), (!!), Eq,
  error, id, return, not, fst, snd, map, filter, concat, concatMap, reverse,
  zip, null, takeWhile, dropWhile, all, any, Integer, negate, abs, divMod,
  String, Bool(True, False), Maybe(Nothing, Just));
import Data.Bits ((.&.), (.|.), (.^.));
import qualified Prelude;
import qualified Data.Bits;
import qualified Uint;
import qualified Array;
import qualified IArray;
import qualified Uint32;
import qualified Uint64;
import qualified Data_Bits;
import qualified Bit_Shifts;
import qualified Str_Literal;
import qualified Higher_Order_Interpretation;
import qualified Higher_Order_Polynomial;
import qualified Higher_Order_Core;
import qualified Arith;

ho_weak_polynomial_translate ::
  [Higher_Order_Polynomial.Ho_polynomial] ->
    Higher_Order_Interpretation.Ho_expression ->
      Higher_Order_Polynomial.Ho_polynomial;
ho_weak_polynomial_translate ps (Higher_Order_Interpretation.HEVar n) =
  Higher_Order_Polynomial.HPVar n;
ho_weak_polynomial_translate ps (Higher_Order_Interpretation.HEConst n) =
  (if Arith.less_nat n (Arith.size_list ps) then Arith.nth ps n
    else Higher_Order_Polynomial.HPNumber Arith.zero_nat Arith.zero_nat);
ho_weak_polynomial_translate ps (Higher_Order_Interpretation.HEApp a b f x) =
  Higher_Order_Polynomial.HPApply a b (ho_weak_polynomial_translate ps f)
    (ho_weak_polynomial_translate ps x);
ho_weak_polynomial_translate ps (Higher_Order_Interpretation.HEAbs a b t) =
  Higher_Order_Polynomial.HPAbstract a b (ho_weak_polynomial_translate ps t);

}
