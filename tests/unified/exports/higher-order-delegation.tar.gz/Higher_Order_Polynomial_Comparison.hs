{-# LANGUAGE EmptyDataDecls, RankNTypes, ScopedTypeVariables #-}

module
  Higher_Order_Polynomial_Comparison(ho_poly_positive_constant,
                                      ho_polynomial_coefficients,
                                      ho_check_base_polynomial_ge,
                                      ho_check_base_polynomial_gt)
  where {

import Prelude ((==), (/=), (<), (<=), (>=), (>), (+), (-), (*), (/), (**),
  (>>=), (>>), (=<<), (&&), (||), (^), (^^), (.), ($), ($!), (++), (!!), Eq,
  error, id, return, not, fst, snd, map, filter, concat, concatMap, reverse,
  zip, null, takeWhile, dropWhile, all, any, Integer, negate, abs, divMod,
  String, Bool(True, False), Maybe(Nothing, Just));
import Data.Bits ((.&.), (.|.), (.^.));
import qualified Prelude;
import qualified Data.Bits;
import qualified Uint;
import qualified Array;
import qualified IArray;
import qualified Uint32;
import qualified Uint64;
import qualified Data_Bits;
import qualified Bit_Shifts;
import qualified Str_Literal;
import qualified Higher_Order_Polynomial;
import qualified Higher_Order_Core;
import qualified Quasi_Order;
import qualified Arith;

ho_monomial_match :: forall a. (Eq a) => [a] -> [a] -> Bool;
ho_monomial_match [] ys = null ys;
ho_monomial_match (x : xs) ys =
  Arith.membera ys x && ho_monomial_match xs (Arith.remove1 x ys);

ho_poly_subtract_term ::
  forall a b.
    (Arith.Minus a, Arith.Zero a, Eq a, Quasi_Order.Ord a,
      Eq b) => a -> [b] -> [(a, [b])] -> Maybe [(a, [b])];
ho_poly_subtract_term c m [] = (if c == Arith.zero then Just [] else Nothing);
ho_poly_subtract_term c m ((d, n) : p) =
  (if ho_monomial_match m n
    then (if Quasi_Order.less_eq c d then Just ((Arith.minusa d c, n) : p)
           else ho_poly_subtract_term (Arith.minusa c d) m p)
    else Arith.map_option (\ a -> (d, n) : a) (ho_poly_subtract_term c m p));

ho_poly_subtract ::
  forall a b.
    (Arith.Minus a, Arith.Zero a, Eq a, Quasi_Order.Ord a,
      Eq b) => [(a, [b])] -> [(a, [b])] -> Maybe [(a, [b])];
ho_poly_subtract p [] = Just p;
ho_poly_subtract p ((c, m) : q) = (case ho_poly_subtract_term c m p of {
                                    Nothing -> Nothing;
                                    Just r -> ho_poly_subtract r q;
                                  });

ho_nat_poly_times ::
  forall a b. (Arith.Times a) => [(a, [b])] -> [(a, [b])] -> [(a, [b])];
ho_nat_poly_times p q =
  concatMap (\ (c, m) -> map (\ (d, n) -> (Arith.times c d, m ++ n)) q) p;

ho_check_nat_poly_ge ::
  forall a b.
    (Arith.Minus a, Arith.Zero a, Eq a, Quasi_Order.Ord a,
      Eq b) => [(a, [b])] -> [(a, [b])] -> Bool;
ho_check_nat_poly_ge p q = not (Arith.is_none (ho_poly_subtract p q));

ho_poly_positive_constant ::
  forall a b. (Arith.Zero a, Quasi_Order.Ord a) => [(a, [b])] -> Bool;
ho_poly_positive_constant p =
  any (\ (c, m) -> Quasi_Order.less Arith.zero c && null m) p;

ho_check_nat_poly_gt ::
  forall a b.
    (Arith.Minus a, Arith.Zero a, Eq a, Quasi_Order.Ord a,
      Eq b) => [(a, [b])] -> [(a, [b])] -> Bool;
ho_check_nat_poly_gt p q = (case ho_poly_subtract p q of {
                             Nothing -> False;
                             Just a -> ho_poly_positive_constant a;
                           });

ho_polynomial_coefficients ::
  Higher_Order_Polynomial.Ho_polynomial ->
    [(Arith.Nat, [Higher_Order_Polynomial.Ho_polynomial])];
ho_polynomial_coefficients (Higher_Order_Polynomial.HPNumber b n) = [(n, [])];
ho_polynomial_coefficients (Higher_Order_Polynomial.HPAdd b p q) =
  ho_polynomial_coefficients p ++ ho_polynomial_coefficients q;
ho_polynomial_coefficients (Higher_Order_Polynomial.HPMultiply b p q) =
  ho_nat_poly_times (ho_polynomial_coefficients p)
    (ho_polynomial_coefficients q);
ho_polynomial_coefficients (Higher_Order_Polynomial.HPVar v) =
  [(Arith.one_nat, [Higher_Order_Polynomial.HPVar v])];
ho_polynomial_coefficients (Higher_Order_Polynomial.HPApply v va vb vc) =
  [(Arith.one_nat, [Higher_Order_Polynomial.HPApply v va vb vc])];
ho_polynomial_coefficients (Higher_Order_Polynomial.HPAbstract v va vb) =
  [(Arith.one_nat, [Higher_Order_Polynomial.HPAbstract v va vb])];

ho_check_base_polynomial_ge ::
  [Higher_Order_Core.Ho_type] ->
    Arith.Nat ->
      Higher_Order_Polynomial.Ho_polynomial ->
        Higher_Order_Polynomial.Ho_polynomial -> Bool;
ho_check_base_polynomial_ge g b p q =
  Higher_Order_Polynomial.ho_polynomial_typeof g p ==
    Just (Higher_Order_Core.HBase b) &&
    Higher_Order_Polynomial.ho_polynomial_typeof g q ==
      Just (Higher_Order_Core.HBase b) &&
      ho_check_nat_poly_ge (ho_polynomial_coefficients p)
        (ho_polynomial_coefficients q);

ho_check_base_polynomial_gt ::
  [Higher_Order_Core.Ho_type] ->
    Arith.Nat ->
      Higher_Order_Polynomial.Ho_polynomial ->
        Higher_Order_Polynomial.Ho_polynomial -> Bool;
ho_check_base_polynomial_gt g b p q =
  Higher_Order_Polynomial.ho_polynomial_typeof g p ==
    Just (Higher_Order_Core.HBase b) &&
    Higher_Order_Polynomial.ho_polynomial_typeof g q ==
      Just (Higher_Order_Core.HBase b) &&
      ho_check_nat_poly_gt (ho_polynomial_coefficients p)
        (ho_polynomial_coefficients q);

}
