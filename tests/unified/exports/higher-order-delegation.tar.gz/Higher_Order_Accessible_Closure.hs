{-# LANGUAGE EmptyDataDecls, RankNTypes, ScopedTypeVariables #-}

module Higher_Order_Accessible_Closure(ho_accessible_from) where {

import Prelude ((==), (/=), (<), (<=), (>=), (>), (+), (-), (*), (/), (**),
  (>>=), (>>), (=<<), (&&), (||), (^), (^^), (.), ($), ($!), (++), (!!), Eq,
  error, id, return, not, fst, snd, map, filter, concat, concatMap, reverse,
  zip, null, takeWhile, dropWhile, all, any, Integer, negate, abs, divMod,
  String, Bool(True, False), Maybe(Nothing, Just));
import Data.Bits ((.&.), (.|.), (.^.));
import qualified Prelude;
import qualified Data.Bits;
import qualified Uint;
import qualified Array;
import qualified IArray;
import qualified Uint32;
import qualified Uint64;
import qualified Data_Bits;
import qualified Bit_Shifts;
import qualified Str_Literal;
import qualified Higher_Order_Accessible_Path;
import qualified Higher_Order_Core;
import qualified Arith;

ho_accessible_from ::
  [Higher_Order_Core.Ho_type] ->
    [Higher_Order_Core.Ho_type] ->
      (Arith.Nat -> Arith.Nat) ->
        Higher_Order_Core.Ho_term -> Higher_Order_Core.Ho_term -> Bool;
ho_accessible_from s g sorts t u =
  Higher_Order_Accessible_Path.ho_check_accessible_path s g sorts
    (Arith.suc (Higher_Order_Core.size_ho_term u)) t u;

}
