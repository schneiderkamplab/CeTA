{-# LANGUAGE EmptyDataDecls, RankNTypes, ScopedTypeVariables #-}

module
  Higher_Order_Core(Ho_type(..), equal_ho_type, Ho_term(..), equal_ho_term,
                     Ho_pattern(..), ho_lift, ho_lookup, ho_typeof,
                     ho_erase_pattern, ho_rule_welltyped, size_ho_term)
  where {

import Prelude ((==), (/=), (<), (<=), (>=), (>), (+), (-), (*), (/), (**),
  (>>=), (>>), (=<<), (&&), (||), (^), (^^), (.), ($), ($!), (++), (!!), Eq,
  error, id, return, not, fst, snd, map, filter, concat, concatMap, reverse,
  zip, null, takeWhile, dropWhile, all, any, Integer, negate, abs, divMod,
  String, Bool(True, False), Maybe(Nothing, Just));
import Data.Bits ((.&.), (.|.), (.^.));
import qualified Prelude;
import qualified Data.Bits;
import qualified Uint;
import qualified Array;
import qualified IArray;
import qualified Uint32;
import qualified Uint64;
import qualified Data_Bits;
import qualified Bit_Shifts;
import qualified Str_Literal;
import qualified Arith;

data Ho_type = HBase Arith.Nat | HArrow Ho_type Ho_type;

equal_ho_type :: Ho_type -> Ho_type -> Bool;
equal_ho_type (HBase x1) (HArrow x21 x22) = False;
equal_ho_type (HArrow x21 x22) (HBase x1) = False;
equal_ho_type (HArrow x21 x22) (HArrow y21 y22) =
  equal_ho_type x21 y21 && equal_ho_type x22 y22;
equal_ho_type (HBase x1) (HBase y1) = Arith.equal_nat x1 y1;

data Ho_term = HBound Arith.Nat | HFree Arith.Nat | HConst Arith.Nat
  | HApp Ho_term Ho_term | HAbs Ho_type Ho_term;

equal_ho_term :: Ho_term -> Ho_term -> Bool;
equal_ho_term (HApp x41 x42) (HAbs x51 x52) = False;
equal_ho_term (HAbs x51 x52) (HApp x41 x42) = False;
equal_ho_term (HConst x3) (HAbs x51 x52) = False;
equal_ho_term (HAbs x51 x52) (HConst x3) = False;
equal_ho_term (HConst x3) (HApp x41 x42) = False;
equal_ho_term (HApp x41 x42) (HConst x3) = False;
equal_ho_term (HFree x2) (HAbs x51 x52) = False;
equal_ho_term (HAbs x51 x52) (HFree x2) = False;
equal_ho_term (HFree x2) (HApp x41 x42) = False;
equal_ho_term (HApp x41 x42) (HFree x2) = False;
equal_ho_term (HFree x2) (HConst x3) = False;
equal_ho_term (HConst x3) (HFree x2) = False;
equal_ho_term (HBound x1) (HAbs x51 x52) = False;
equal_ho_term (HAbs x51 x52) (HBound x1) = False;
equal_ho_term (HBound x1) (HApp x41 x42) = False;
equal_ho_term (HApp x41 x42) (HBound x1) = False;
equal_ho_term (HBound x1) (HConst x3) = False;
equal_ho_term (HConst x3) (HBound x1) = False;
equal_ho_term (HBound x1) (HFree x2) = False;
equal_ho_term (HFree x2) (HBound x1) = False;
equal_ho_term (HAbs x51 x52) (HAbs y51 y52) =
  equal_ho_type x51 y51 && equal_ho_term x52 y52;
equal_ho_term (HApp x41 x42) (HApp y41 y42) =
  equal_ho_term x41 y41 && equal_ho_term x42 y42;
equal_ho_term (HConst x3) (HConst y3) = Arith.equal_nat x3 y3;
equal_ho_term (HFree x2) (HFree y2) = Arith.equal_nat x2 y2;
equal_ho_term (HBound x1) (HBound y1) = Arith.equal_nat x1 y1;

instance Eq Ho_term where {
  a == b = equal_ho_term a b;
};

instance Eq Ho_type where {
  a == b = equal_ho_type a b;
};

data Ho_pattern = PBound Arith.Nat | PConst Arith.Nat
  | PApp Ho_pattern Ho_pattern | PAbs Ho_type Ho_pattern
  | PMeta Arith.Nat [Ho_pattern];

instance Eq Ho_pattern where {
  a == b = equal_ho_pattern a b;
};

equal_ho_pattern :: Ho_pattern -> Ho_pattern -> Bool;
equal_ho_pattern (PAbs x41 x42) (PMeta x51 x52) = False;
equal_ho_pattern (PMeta x51 x52) (PAbs x41 x42) = False;
equal_ho_pattern (PApp x31 x32) (PMeta x51 x52) = False;
equal_ho_pattern (PMeta x51 x52) (PApp x31 x32) = False;
equal_ho_pattern (PApp x31 x32) (PAbs x41 x42) = False;
equal_ho_pattern (PAbs x41 x42) (PApp x31 x32) = False;
equal_ho_pattern (PConst x2) (PMeta x51 x52) = False;
equal_ho_pattern (PMeta x51 x52) (PConst x2) = False;
equal_ho_pattern (PConst x2) (PAbs x41 x42) = False;
equal_ho_pattern (PAbs x41 x42) (PConst x2) = False;
equal_ho_pattern (PConst x2) (PApp x31 x32) = False;
equal_ho_pattern (PApp x31 x32) (PConst x2) = False;
equal_ho_pattern (PBound x1) (PMeta x51 x52) = False;
equal_ho_pattern (PMeta x51 x52) (PBound x1) = False;
equal_ho_pattern (PBound x1) (PAbs x41 x42) = False;
equal_ho_pattern (PAbs x41 x42) (PBound x1) = False;
equal_ho_pattern (PBound x1) (PApp x31 x32) = False;
equal_ho_pattern (PApp x31 x32) (PBound x1) = False;
equal_ho_pattern (PBound x1) (PConst x2) = False;
equal_ho_pattern (PConst x2) (PBound x1) = False;
equal_ho_pattern (PMeta x51 x52) (PMeta y51 y52) =
  Arith.equal_nat x51 y51 && x52 == y52;
equal_ho_pattern (PAbs x41 x42) (PAbs y41 y42) =
  equal_ho_type x41 y41 && equal_ho_pattern x42 y42;
equal_ho_pattern (PApp x31 x32) (PApp y31 y32) =
  equal_ho_pattern x31 y31 && equal_ho_pattern x32 y32;
equal_ho_pattern (PConst x2) (PConst y2) = Arith.equal_nat x2 y2;
equal_ho_pattern (PBound x1) (PBound y1) = Arith.equal_nat x1 y1;

ho_lift :: Arith.Nat -> Arith.Nat -> Ho_term -> Ho_term;
ho_lift d k (HBound n) =
  HBound (if Arith.less_nat n k then n else Arith.plus_nat n d);
ho_lift d k (HFree n) = HFree n;
ho_lift d k (HConst n) = HConst n;
ho_lift d k (HApp f x) = HApp (ho_lift d k f) (ho_lift d k x);
ho_lift d k (HAbs a t) = HAbs a (ho_lift d (Arith.suc k) t);

ho_lookup :: forall a. [a] -> Arith.Nat -> Maybe a;
ho_lookup xs n =
  (if Arith.less_nat n (Arith.size_list xs) then Just (Arith.nth xs n)
    else Nothing);

ho_typeof :: [Ho_type] -> [Ho_type] -> [Ho_type] -> Ho_term -> Maybe Ho_type;
ho_typeof s v b (HBound n) = ho_lookup b n;
ho_typeof s v b (HFree n) = ho_lookup v n;
ho_typeof s v b (HConst n) = ho_lookup s n;
ho_typeof s v b (HApp f x) =
  (case ho_typeof s v b f of {
    Nothing -> Nothing;
    Just (HBase _) -> Nothing;
    Just (HArrow a c) ->
      (if ho_typeof s v b x == Just a then Just c else Nothing);
  });
ho_typeof s v b (HAbs a t) =
  Arith.map_option (HArrow a) (ho_typeof s v (a : b) t);

ho_erase_pattern :: Ho_pattern -> Ho_term;
ho_erase_pattern (PBound n) = HBound n;
ho_erase_pattern (PConst n) = HConst n;
ho_erase_pattern (PApp f x) = HApp (ho_erase_pattern f) (ho_erase_pattern x);
ho_erase_pattern (PAbs a t) = HAbs a (ho_erase_pattern t);
ho_erase_pattern (PMeta n ts) =
  Arith.foldl (\ a x -> HApp a (ho_erase_pattern x)) (HFree n) ts;

ho_rule_welltyped :: [Ho_type] -> ([Ho_type], (Ho_pattern, Ho_pattern)) -> Bool;
ho_rule_welltyped s r =
  (case r of {
    (g, (l, u)) -> (case ho_typeof s g [] (ho_erase_pattern l) of {
                     Nothing -> False;
                     Just a -> ho_typeof s g [] (ho_erase_pattern u) == Just a;
                   });
  });

size_ho_term :: Ho_term -> Arith.Nat;
size_ho_term (HBound x1) = Arith.zero_nat;
size_ho_term (HFree x2) = Arith.zero_nat;
size_ho_term (HConst x3) = Arith.zero_nat;
size_ho_term (HApp x41 x42) =
  Arith.plus_nat (Arith.plus_nat (size_ho_term x41) (size_ho_term x42))
    (Arith.suc Arith.zero_nat);
size_ho_term (HAbs x51 x52) =
  Arith.plus_nat (size_ho_term x52) (Arith.suc Arith.zero_nat);

}
