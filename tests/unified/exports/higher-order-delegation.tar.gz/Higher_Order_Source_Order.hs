{-# LANGUAGE EmptyDataDecls, RankNTypes, ScopedTypeVariables #-}

module Higher_Order_Source_Order(ho_zero_arity_pattern, ho_zero_arity_rules)
  where {

import Prelude ((==), (/=), (<), (<=), (>=), (>), (+), (-), (*), (/), (**),
  (>>=), (>>), (=<<), (&&), (||), (^), (^^), (.), ($), ($!), (++), (!!), Eq,
  error, id, return, not, fst, snd, map, filter, concat, concatMap, reverse,
  zip, null, takeWhile, dropWhile, all, any, Integer, negate, abs, divMod,
  String, Bool(True, False), Maybe(Nothing, Just));
import Data.Bits ((.&.), (.|.), (.^.));
import qualified Prelude;
import qualified Data.Bits;
import qualified Uint;
import qualified Array;
import qualified IArray;
import qualified Uint32;
import qualified Uint64;
import qualified Data_Bits;
import qualified Bit_Shifts;
import qualified Str_Literal;
import qualified Arith;
import qualified Higher_Order_Core;

ho_zero_arity_pattern :: Higher_Order_Core.Ho_pattern -> Bool;
ho_zero_arity_pattern (Higher_Order_Core.PBound n) = True;
ho_zero_arity_pattern (Higher_Order_Core.PConst n) = True;
ho_zero_arity_pattern (Higher_Order_Core.PApp f x) =
  ho_zero_arity_pattern f && ho_zero_arity_pattern x;
ho_zero_arity_pattern (Higher_Order_Core.PAbs a t) = ho_zero_arity_pattern t;
ho_zero_arity_pattern (Higher_Order_Core.PMeta n ts) = null ts;

ho_zero_arity_rules ::
  forall a.
    [(a, (Higher_Order_Core.Ho_pattern, Higher_Order_Core.Ho_pattern))] -> Bool;
ho_zero_arity_rules r =
  all (\ (_, (l, ra)) -> ho_zero_arity_pattern l && ho_zero_arity_pattern ra) r;

}
