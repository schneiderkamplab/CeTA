{-# LANGUAGE EmptyDataDecls, RankNTypes, ScopedTypeVariables #-}

module
  Ceta_Problem_Spec(Fp_strategy(..), Strategy(..), Input(..), strategy_to_Q,
                     default_nfs_flag, strategy_to_nfs)
  where {

import Prelude ((==), (/=), (<), (<=), (>=), (>), (+), (-), (*), (/), (**),
  (>>=), (>>), (=<<), (&&), (||), (^), (^^), (.), ($), ($!), (++), (!!), Eq,
  error, id, return, not, fst, snd, map, filter, concat, concatMap, reverse,
  zip, null, takeWhile, dropWhile, all, any, Integer, negate, abs, divMod,
  String, Bool(True, False), Maybe(Nothing, Just));
import Data.Bits ((.&.), (.|.), (.^.));
import qualified Prelude;
import qualified Data.Bits;
import qualified Uint;
import qualified Array;
import qualified IArray;
import qualified Uint32;
import qualified Uint64;
import qualified Data_Bits;
import qualified Bit_Shifts;
import qualified Str_Literal;
import qualified Ordered_Completion_Impl;
import qualified Tree_Automata_Impl;
import qualified Term_Rewriting;
import qualified Arith;

data Fp_strategy a b = Outermost
  | Context_Sensitive [((a, Arith.Nat), [Arith.Nat])]
  | Forbidden_Patterns
      [(Term_Rewriting.Actxt a (Term_Rewriting.Term a b),
         (Term_Rewriting.Term a b, Term_Rewriting.Location))];

data Strategy a b = No_Strategy | Innermost Bool
  | Innermost_Q Bool [Term_Rewriting.Term a b];

data Input a b =
  DP_input Bool [(Term_Rewriting.Term a b, Term_Rewriting.Term a b)]
    (Strategy a b) [(Term_Rewriting.Term a b, Term_Rewriting.Term a b)]
  | Relative_DP_input Bool Bool
      [(Term_Rewriting.Term a b, Term_Rewriting.Term a b)]
      [(Term_Rewriting.Term a b, Term_Rewriting.Term a b)]
      [Term_Rewriting.Term a b]
      [(Term_Rewriting.Term a b, Term_Rewriting.Term a b)]
      [(Term_Rewriting.Term a b, Term_Rewriting.Term a b)]
  | CSR_Improved_DP_input Bool a [((a, Arith.Nat), [Arith.Nat])]
      [(Term_Rewriting.Term a b, Term_Rewriting.Term a b)]
      [(Term_Rewriting.Term a b, Term_Rewriting.Term a b)]
  | CSR_Muterm_Typed_DP_input Bool [((a, Arith.Nat), [Arith.Nat])]
      [(Term_Rewriting.Term a b, Term_Rewriting.Term a b)]
      [(Term_Rewriting.Term a b, Term_Rewriting.Term a b)]
      [(Term_Rewriting.Term a b, Term_Rewriting.Term a b)]
  | Inn_TRS_input (Strategy a b)
      [(Term_Rewriting.Term a b, Term_Rewriting.Term a b)]
      [(Term_Rewriting.Term a b, Term_Rewriting.Term a b)]
  | FP_TRS_input (Fp_strategy a b)
      [(Term_Rewriting.Term a b, Term_Rewriting.Term a b)]
  | AC_input [(Term_Rewriting.Term a b, Term_Rewriting.Term a b)] [a] [a]
  | LTS_input
      (Term_Rewriting.Lts_impl Term_Rewriting.Sig b Term_Rewriting.Ty
        [Arith.Char] [Arith.Char])
  | LTS_safety_input
      (Term_Rewriting.Lts_impl Term_Rewriting.Sig b Term_Rewriting.Ty
        [Arith.Char] [Arith.Char])
      [[Arith.Char]]
  | CTRS_input
      [((Term_Rewriting.Term a b, Term_Rewriting.Term a b),
         [(Term_Rewriting.Term a b, Term_Rewriting.Term a b)])]
  | EQ_input [(Term_Rewriting.Term a b, Term_Rewriting.Term a b)]
  | EQ_RO_input [(Term_Rewriting.Term a b, Term_Rewriting.Term a b)]
      (Ordered_Completion_Impl.Reduction_order_input a)
  | EQ_reasoning_input [(Term_Rewriting.Term a b, Term_Rewriting.Term a b)]
      (Term_Rewriting.Term a b, Term_Rewriting.Term a b)
  | TA_input (Tree_Automata_Impl.Tree_automaton [Arith.Char] a)
      [(Term_Rewriting.Term a b, Term_Rewriting.Term a b)]
  | Infeasibility_input
      [((Term_Rewriting.Term a b, Term_Rewriting.Term a b),
         [(Term_Rewriting.Term a b, Term_Rewriting.Term a b)])]
      [(Term_Rewriting.Term a b, Term_Rewriting.Term a b)]
  | Single_TRS_input [(a, Arith.Nat)]
      [(Term_Rewriting.Term a b, Term_Rewriting.Term a b)]
  | Two_TRS_input [(a, Arith.Nat)]
      [(Term_Rewriting.Term a b, Term_Rewriting.Term a b)]
      [(Term_Rewriting.Term a b, Term_Rewriting.Term a b)]
  | Unknown_input [Arith.Char];

strategy_to_Q ::
  forall a b.
    (Eq a,
      Eq b) => Strategy a b ->
                 [(Term_Rewriting.Term a b, Term_Rewriting.Term a b)] ->
                   [Term_Rewriting.Term a b];
strategy_to_Q No_Strategy uu = [];
strategy_to_Q (Innermost uv) r = Arith.remdups (map fst r);
strategy_to_Q (Innermost_Q uw q) ux = q;

default_nfs_flag :: Bool;
default_nfs_flag = False;

strategy_to_nfs :: forall a b. Strategy a b -> Bool;
strategy_to_nfs No_Strategy = default_nfs_flag;
strategy_to_nfs (Innermost nfs) = nfs;
strategy_to_nfs (Innermost_Q nfs uu) = nfs;

}
