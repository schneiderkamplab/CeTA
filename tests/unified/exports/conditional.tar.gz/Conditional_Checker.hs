{-# LANGUAGE EmptyDataDecls, RankNTypes, ScopedTypeVariables #-}

module
  Conditional_Checker(Nat, Term(..), Num, Sum, Cstep_proof(..),
                       Conditional_descent_proof(..), nat_of_integer,
                       conditional_check, conditional_substitution,
                       conditional_check_loop, conditional_check_rewrite_loop)
  where {

import Prelude ((==), (/=), (<), (<=), (>=), (>), (+), (-), (*), (/), (**),
  (>>=), (>>), (=<<), (&&), (||), (^), (^^), (.), ($), ($!), (++), (!!), Eq,
  error, id, return, not, fst, snd, map, filter, concat, concatMap, reverse,
  zip, null, takeWhile, dropWhile, all, any, Integer, negate, abs, divMod,
  String, Bool(True, False), Maybe(Nothing, Just));
import Data.Bits ((.&.), (.|.), (.^.));
import qualified Prelude;
import qualified Data.Bits;
import qualified Str_Literal;

data Nat = Zero_nat | Suc Nat;

equal_nat :: Nat -> Nat -> Bool;
equal_nat Zero_nat (Suc x2) = False;
equal_nat (Suc x2) Zero_nat = False;
equal_nat (Suc x2) (Suc y2) = equal_nat x2 y2;
equal_nat Zero_nat Zero_nat = True;

instance Eq Nat where {
  a == b = equal_nat a b;
};

plus_nat :: Nat -> Nat -> Nat;
plus_nat Zero_nat n = n;
plus_nat (Suc m) n = plus_nat m (Suc n);

times_nat :: Nat -> Nat -> Nat;
times_nat Zero_nat n = Zero_nat;
times_nat (Suc m) n = plus_nat n (times_nat m n);

class Times a where {
  times :: a -> a -> a;
};

class (Times a) => Dvd a where {
};

instance Times Nat where {
  times = times_nat;
};

instance Dvd Nat where {
};

one_nat :: Nat;
one_nat = Suc Zero_nat;

class One a where {
  one :: a;
};

instance One Nat where {
  one = one_nat;
};

class Plus a where {
  plus :: a -> a -> a;
};

instance Plus Nat where {
  plus = plus_nat;
};

class Zero a where {
  zero :: a;
};

instance Zero Nat where {
  zero = Zero_nat;
};

class (Plus a) => Semigroup_add a where {
};

class (One a, Semigroup_add a) => Numeral a where {
};

instance Semigroup_add Nat where {
};

instance Numeral Nat where {
};

class (One a, Times a) => Power a where {
};

instance Power Nat where {
};

minus_nat :: Nat -> Nat -> Nat;
minus_nat m Zero_nat = m;
minus_nat Zero_nat n = Zero_nat;
minus_nat (Suc m) (Suc n) = minus_nat m n;

class Minus a where {
  minus :: a -> a -> a;
};

instance Minus Nat where {
  minus = minus_nat;
};

less_eq_nat :: Nat -> Nat -> Bool;
less_eq_nat Zero_nat n = True;
less_eq_nat (Suc m) n = less_nat m n;

less_nat :: Nat -> Nat -> Bool;
less_nat n Zero_nat = False;
less_nat m (Suc n) = less_eq_nat m n;

class Ord a where {
  less_eq :: a -> a -> Bool;
  less :: a -> a -> Bool;
};

class (Semigroup_add a) => Cancel_semigroup_add a where {
};

class (Semigroup_add a) => Ab_semigroup_add a where {
};

class (Ab_semigroup_add a, Cancel_semigroup_add a,
        Minus a) => Cancel_ab_semigroup_add a where {
};

class (Semigroup_add a, Zero a) => Monoid_add a where {
};

class (Ab_semigroup_add a, Monoid_add a) => Comm_monoid_add a where {
};

class (Cancel_ab_semigroup_add a,
        Comm_monoid_add a) => Cancel_comm_monoid_add a where {
};

class (Times a, Zero a) => Mult_zero a where {
};

class (Times a) => Semigroup_mult a where {
};

class (Ab_semigroup_add a, Semigroup_mult a) => Semiring a where {
};

class (Comm_monoid_add a, Mult_zero a, Semiring a) => Semiring_0 a where {
};

class (Cancel_comm_monoid_add a, Semiring_0 a) => Semiring_0_cancel a where {
};

class (Semigroup_mult a) => Ab_semigroup_mult a where {
};

class (Ab_semigroup_mult a, Semiring a) => Comm_semiring a where {
};

class (Comm_semiring a, Semiring_0 a) => Comm_semiring_0 a where {
};

class (Comm_semiring_0 a,
        Semiring_0_cancel a) => Comm_semiring_0_cancel a where {
};

class (Semigroup_mult a, Power a) => Monoid_mult a where {
};

class (Monoid_mult a, Numeral a, Semiring a) => Semiring_numeral a where {
};

class (One a, Zero a) => Zero_neq_one a where {
};

class (Semiring_numeral a, Semiring_0 a, Zero_neq_one a) => Semiring_1 a where {
};

class (Semiring_0_cancel a, Semiring_1 a) => Semiring_1_cancel a where {
};

class (Ab_semigroup_mult a, Monoid_mult a, Dvd a) => Comm_monoid_mult a where {
};

class (Comm_monoid_mult a, Comm_semiring_0 a,
        Semiring_1 a) => Comm_semiring_1 a where {
};

class (Comm_semiring_0_cancel a, Comm_semiring_1 a,
        Semiring_1_cancel a) => Comm_semiring_1_cancel a where {
};

class (Ord a) => Preorder a where {
};

class (Preorder a) => Order a where {
};

class (Order a) => Linorder a where {
};

class (Linorder a, Comm_semiring_1_cancel a) => Interval a where {
};

instance Cancel_semigroup_add Nat where {
};

instance Ab_semigroup_add Nat where {
};

instance Cancel_ab_semigroup_add Nat where {
};

instance Monoid_add Nat where {
};

instance Comm_monoid_add Nat where {
};

instance Cancel_comm_monoid_add Nat where {
};

instance Mult_zero Nat where {
};

instance Semigroup_mult Nat where {
};

instance Semiring Nat where {
};

instance Semiring_0 Nat where {
};

instance Semiring_0_cancel Nat where {
};

instance Ab_semigroup_mult Nat where {
};

instance Comm_semiring Nat where {
};

instance Comm_semiring_0 Nat where {
};

instance Comm_semiring_0_cancel Nat where {
};

instance Monoid_mult Nat where {
};

instance Semiring_numeral Nat where {
};

instance Zero_neq_one Nat where {
};

instance Semiring_1 Nat where {
};

instance Semiring_1_cancel Nat where {
};

instance Comm_monoid_mult Nat where {
};

instance Comm_semiring_1 Nat where {
};

instance Comm_semiring_1_cancel Nat where {
};

instance Ord Nat where {
  less_eq = less_eq_nat;
  less = less_nat;
};

instance Preorder Nat where {
};

instance Order Nat where {
};

instance Linorder Nat where {
};

instance Interval Nat where {
};

class Showl a where {
  showsl :: a -> String -> String;
  showsl_list :: [a] -> String -> String;
};

showsl_lista :: forall a. (Showl a) => [a] -> String -> String;
showsl_lista xs = showsl_list xs;

showsl_lit :: String -> String -> String;
showsl_lit = (\ a b -> a ++ b);

showsl_sep ::
  forall a.
    (a -> String -> String) -> (String -> String) -> [a] -> String -> String;
showsl_sep s sep [] = showsl_lit "";
showsl_sep s sep [x] = s x;
showsl_sep s sep (x : v : va) = (s x . sep) . showsl_sep s sep (v : va);

showsl_list_gen ::
  forall a.
    (a -> String -> String) ->
      String -> String -> String -> String -> [a] -> String -> String;
showsl_list_gen showslx e l s r xs =
  (if null xs then showsl_lit e
    else (showsl_lit l . showsl_sep showslx (showsl_lit s) xs) . showsl_lit r);

default_showsl_list ::
  forall a. (a -> String -> String) -> [a] -> String -> String;
default_showsl_list sl = showsl_list_gen sl "[]" "[" ", " "]";

showsl_list_list :: forall a. (Showl a) => [[a]] -> String -> String;
showsl_list_list xs = default_showsl_list showsl_lista xs;

instance (Showl a) => Showl [a] where {
  showsl = showsl_lista;
  showsl_list = showsl_list_list;
};

data Term a b = Var b | Fun a [Term a b];

instance (Eq a, Eq b) => Eq (Term a b) where {
  a == b = equal_term a b;
};

equal_term :: forall a b. (Eq a, Eq b) => Term a b -> Term a b -> Bool;
equal_term (Var x1) (Fun x21 x22) = False;
equal_term (Fun x21 x22) (Var x1) = False;
equal_term (Fun x21 x22) (Fun y21 y22) = x21 == y21 && x22 == y22;
equal_term (Var x1) (Var y1) = x1 == y1;

data Num = One | Bit0 Num | Bit1 Num;

one_integer :: Integer;
one_integer = (1 :: Integer);

instance One Integer where {
  one = one_integer;
};

instance Plus Integer where {
  plus = (\ a b -> a + b);
};

instance Zero Integer where {
  zero = (0 :: Integer);
};

instance Semigroup_add Integer where {
};

instance Numeral Integer where {
};

instance Times Integer where {
  times = (\ a b -> a * b);
};

instance Power Integer where {
};

instance Ab_semigroup_add Integer where {
};

instance Semigroup_mult Integer where {
};

instance Semiring Integer where {
};

instance Mult_zero Integer where {
};

instance Monoid_add Integer where {
};

instance Comm_monoid_add Integer where {
};

instance Semiring_0 Integer where {
};

instance Monoid_mult Integer where {
};

instance Semiring_numeral Integer where {
};

instance Zero_neq_one Integer where {
};

instance Semiring_1 Integer where {
};

divmod_nat :: Nat -> Nat -> (Nat, Nat);
divmod_nat m n =
  (if equal_nat n Zero_nat || less_nat m n then (Zero_nat, m)
    else (case divmod_nat (minus_nat m n) n of {
           (q, a) -> (Suc q, a);
         }));

modulo_nat :: Nat -> Nat -> Nat;
modulo_nat m n = snd (divmod_nat m n);

divide_nat :: Nat -> Nat -> Nat;
divide_nat m n = fst (divmod_nat m n);

of_nat_aux :: forall a. (Semiring_1 a) => (a -> a) -> Nat -> a -> a;
of_nat_aux inc Zero_nat i = i;
of_nat_aux inc (Suc n) i = of_nat_aux inc n (inc i);

of_nat :: forall a. (Semiring_1 a) => Nat -> a;
of_nat n = of_nat_aux (\ i -> plus i one) n zero;

integer_of_nat :: Nat -> Integer;
integer_of_nat = of_nat;

bit_cut_integer :: Integer -> (Integer, Bool);
bit_cut_integer k =
  (if k == (0 :: Integer) then ((0 :: Integer), False)
    else (case divMod (abs k) (abs (2 :: Integer)) of {
           (r, s) ->
             ((if (0 :: Integer) < k then r else negate r - s),
               s == (1 :: Integer));
         }));

data Char = Char Bool Bool Bool Bool Bool Bool Bool Bool;

char_of_integer :: Integer -> Char;
char_of_integer k =
  (case bit_cut_integer k of {
    (q0, b0) ->
      (case bit_cut_integer q0 of {
        (q1, b1) ->
          (case bit_cut_integer q1 of {
            (q2, b2) ->
              (case bit_cut_integer q2 of {
                (q3, b3) ->
                  (case bit_cut_integer q3 of {
                    (q4, b4) ->
                      (case bit_cut_integer q4 of {
                        (q5, b5) ->
                          (case bit_cut_integer q5 of {
                            (q6, b6) ->
                              (case bit_cut_integer q6 of {
                                (_, a) -> Char b0 b1 b2 b3 b4 b5 b6 a;
                              });
                          });
                      });
                  });
              });
          });
      });
  });

of_bool :: forall a. (Zero_neq_one a) => Bool -> a;
of_bool False = zero;
of_bool True = one;

integer_of_char :: Char -> Integer;
integer_of_char (Char b0 b1 b2 b3 b4 b5 b6 b7) =
  ((((((of_bool b7 * (2 :: Integer) + of_bool b6) * (2 :: Integer) +
        of_bool b5) *
        (2 :: Integer) +
       of_bool b4) *
       (2 :: Integer) +
      of_bool b3) *
      (2 :: Integer) +
     of_bool b2) *
     (2 :: Integer) +
    of_bool b1) *
    (2 :: Integer) +
    of_bool b0;

implode :: [Char] -> String;
implode cs = Str_Literal.literalOfAsciis (map integer_of_char cs);

lit_of_digit :: Nat -> String;
lit_of_digit n = implode [char_of_integer ((48 :: Integer) + integer_of_nat n)];

nat_of_num :: Num -> Nat;
nat_of_num One = one_nat;
nat_of_num (Bit0 n) = let {
                        m = nat_of_num n;
                      } in plus_nat m m;
nat_of_num (Bit1 n) = let {
                        m = nat_of_num n;
                      } in Suc (plus_nat m m);

showsl_nat :: Nat -> String -> String;
showsl_nat n =
  (if less_nat n (nat_of_num (Bit0 (Bit1 (Bit0 One))))
    then showsl_lit (lit_of_digit n)
    else showsl_nat (divide_nat n (nat_of_num (Bit0 (Bit1 (Bit0 One))))) .
           showsl_lit
             (lit_of_digit
               (modulo_nat n (nat_of_num (Bit0 (Bit1 (Bit0 One)))))));

data Int = Zero_int | Pos Num | Neg Num;

uminus_int :: Int -> Int;
uminus_int Zero_int = Zero_int;
uminus_int (Pos m) = Neg m;
uminus_int (Neg m) = Pos m;

less_num :: Num -> Num -> Bool;
less_num m One = False;
less_num One (Bit0 n) = True;
less_num One (Bit1 n) = True;
less_num (Bit0 m) (Bit0 n) = less_num m n;
less_num (Bit0 m) (Bit1 n) = less_eq_num m n;
less_num (Bit1 m) (Bit1 n) = less_num m n;
less_num (Bit1 m) (Bit0 n) = less_num m n;

less_eq_num :: Num -> Num -> Bool;
less_eq_num One n = True;
less_eq_num (Bit0 m) One = False;
less_eq_num (Bit1 m) One = False;
less_eq_num (Bit0 m) (Bit0 n) = less_eq_num m n;
less_eq_num (Bit0 m) (Bit1 n) = less_eq_num m n;
less_eq_num (Bit1 m) (Bit1 n) = less_eq_num m n;
less_eq_num (Bit1 m) (Bit0 n) = less_num m n;

less_int :: Int -> Int -> Bool;
less_int Zero_int Zero_int = False;
less_int Zero_int (Pos l) = True;
less_int Zero_int (Neg l) = False;
less_int (Pos k) Zero_int = False;
less_int (Pos k) (Pos l) = less_num k l;
less_int (Pos k) (Neg l) = False;
less_int (Neg k) Zero_int = True;
less_int (Neg k) (Pos l) = True;
less_int (Neg k) (Neg l) = less_num l k;

nat :: Int -> Nat;
nat (Neg k) = Zero_nat;
nat Zero_int = Zero_nat;
nat (Pos k) = nat_of_num k;

showsl_int :: Int -> String -> String;
showsl_int i =
  (if less_int i Zero_int then showsl_lit "-" . showsl_nat (nat (uminus_int i))
    else showsl_nat (nat i));

plus_num :: Num -> Num -> Num;
plus_num One One = Bit0 One;
plus_num One (Bit0 n) = Bit1 n;
plus_num One (Bit1 n) = Bit0 (plus_num n One);
plus_num (Bit0 m) One = Bit1 m;
plus_num (Bit0 m) (Bit0 n) = Bit0 (plus_num m n);
plus_num (Bit0 m) (Bit1 n) = Bit1 (plus_num m n);
plus_num (Bit1 m) One = Bit0 (plus_num m One);
plus_num (Bit1 m) (Bit0 n) = Bit1 (plus_num m n);
plus_num (Bit1 m) (Bit1 n) = Bit0 (plus_num (plus_num m n) One);

times_num :: Num -> Num -> Num;
times_num m One = m;
times_num One n = n;
times_num (Bit0 m) (Bit0 n) = Bit0 (Bit0 (times_num m n));
times_num (Bit0 m) (Bit1 n) = Bit0 (times_num m (Bit1 n));
times_num (Bit1 m) (Bit0 n) = Bit0 (times_num (Bit1 m) n);
times_num (Bit1 m) (Bit1 n) =
  Bit1 (plus_num (plus_num m n) (Bit0 (times_num m n)));

times_int :: Int -> Int -> Int;
times_int k Zero_int = Zero_int;
times_int Zero_int l = Zero_int;
times_int (Pos m) (Pos n) = Pos (times_num m n);
times_int (Pos m) (Neg n) = Neg (times_num m n);
times_int (Neg m) (Pos n) = Neg (times_num m n);
times_int (Neg m) (Neg n) = Pos (times_num m n);

apsnd :: forall a b c. (a -> b) -> (c, a) -> (c, b);
apsnd f (x, y) = (x, f y);

divmod_integer :: Integer -> Integer -> (Integer, Integer);
divmod_integer k l =
  (if k == (0 :: Integer) then ((0 :: Integer), (0 :: Integer))
    else (if (0 :: Integer) < l
           then (if (0 :: Integer) < k then divMod (abs k) (abs l)
                  else (case divMod (abs k) (abs l) of {
                         (r, s) ->
                           (if s == (0 :: Integer)
                             then (negate r, (0 :: Integer))
                             else (negate r - (1 :: Integer), l - s));
                       }))
           else (if l == (0 :: Integer) then ((0 :: Integer), k)
                  else apsnd negate
                         (if k < (0 :: Integer) then divMod (abs k) (abs l)
                           else (case divMod (abs k) (abs l) of {
                                  (r, s) ->
                                    (if s == (0 :: Integer)
                                      then (negate r, (0 :: Integer))
                                      else (negate r - (1 :: Integer),
     negate l - s));
                                })))));

one_int :: Int;
one_int = Pos One;

bitM :: Num -> Num;
bitM One = One;
bitM (Bit0 n) = Bit1 (bitM n);
bitM (Bit1 n) = Bit1 (Bit0 n);

dup :: Int -> Int;
dup Zero_int = Zero_int;
dup (Pos n) = Pos (Bit0 n);
dup (Neg n) = Neg (Bit0 n);

plus_int :: Int -> Int -> Int;
plus_int k Zero_int = k;
plus_int Zero_int l = l;
plus_int (Pos m) (Pos n) = Pos (plus_num m n);
plus_int (Pos m) (Neg n) = sub m n;
plus_int (Neg m) (Pos n) = sub n m;
plus_int (Neg m) (Neg n) = Neg (plus_num m n);

sub :: Num -> Num -> Int;
sub One One = Zero_int;
sub (Bit0 m) One = Pos (bitM m);
sub (Bit1 m) One = Pos (Bit0 m);
sub One (Bit0 n) = Neg (bitM n);
sub One (Bit1 n) = Neg (Bit0 n);
sub (Bit0 m) (Bit0 n) = dup (sub m n);
sub (Bit1 m) (Bit1 n) = dup (sub m n);
sub (Bit1 m) (Bit0 n) = plus_int (dup (sub m n)) one_int;
sub (Bit0 m) (Bit1 n) = minus_int (dup (sub m n)) one_int;

minus_int :: Int -> Int -> Int;
minus_int k Zero_int = k;
minus_int Zero_int l = uminus_int l;
minus_int (Pos m) (Pos n) = sub m n;
minus_int (Pos m) (Neg n) = Pos (plus_num m n);
minus_int (Neg m) (Pos n) = Neg (plus_num m n);
minus_int (Neg m) (Neg n) = sub n m;

int_of_integer :: Integer -> Int;
int_of_integer k =
  (if k == (0 :: Integer) then Zero_int
    else (if k == (-1 :: Integer) then uminus_int one_int
           else (case divmod_integer k (2 :: Integer) of {
                  (l, j) ->
                    let {
                      la = times_int (Pos (Bit0 One)) (int_of_integer l);
                    } in (if j == (0 :: Integer) then la
                           else plus_int la one_int);
                })));

showsl_integer :: Integer -> String -> String;
showsl_integer i = showsl_int (int_of_integer i);

showsl_list_integer :: [Integer] -> String -> String;
showsl_list_integer xs = default_showsl_list showsl_integer xs;

instance Showl Integer where {
  showsl = showsl_integer;
  showsl_list = showsl_list_integer;
};

data Sum a b = Inl a | Inr b;

data Actxt a b = Hole | More a [b] (Actxt a b) [b];

data Cstep_proof a b =
  Cstep_step ((Term a b, Term a b), [(Term a b, Term a b)]) [Nat]
    (b -> Term a b) (Term a b) (Term a b) [[Cstep_proof a b]];

data Conditional_descent_proof a b = Conditional_rewrite (Cstep_proof a b)
  | Conditional_call Nat (b -> Term a b) Nat [[Cstep_proof a b]] (Term a b)
      (Term a b)
  | Conditional_argument a [Term a b] Nat;

nth :: forall a. [a] -> Nat -> a;
nth (x : xs) Zero_nat = x;
nth (x : xs) (Suc n) = nth xs n;

upt :: Nat -> Nat -> [Nat];
upt i j = (if less_nat i j then i : upt (Suc i) j else []);

drop :: forall a. Nat -> [a] -> [a];
drop n [] = [];
drop n (x : xs) = (case n of {
                    Zero_nat -> x : xs;
                    Suc m -> drop m xs;
                  });

take :: forall a. Nat -> [a] -> [a];
take n [] = [];
take n (x : xs) = (case n of {
                    Zero_nat -> [];
                    Suc m -> x : take m xs;
                  });

foldr :: forall a b. (a -> b -> b) -> [a] -> b -> b;
foldr f [] = id;
foldr f (x : xs) = f x . foldr f xs;

map_of :: forall a b. (Eq a) => [(a, b)] -> a -> Maybe b;
map_of [] k = Nothing;
map_of ((l, v) : ps) k = (if l == k then Just v else map_of ps k);

fun_upd :: forall a b. (Eq a) => (a -> b) -> a -> b -> a -> b;
fun_upd f a b = (\ x -> (if x == a then b else f x));

member :: forall a. (Eq a) => [a] -> a -> Bool;
member [] y = False;
member (x : xs) y = x == y || member xs y;

bind :: forall a b. Maybe a -> (a -> Maybe b) -> Maybe b;
bind Nothing f = Nothing;
bind (Just x) f = f x;

is_none :: forall a. Maybe a -> Bool;
is_none Nothing = True;
is_none (Just x) = False;

eval_term :: forall a b c. (a -> [b] -> b) -> Term a c -> (c -> b) -> b;
eval_term i (Var x) alpha = alpha x;
eval_term i (Fun f ss) alpha = i f (map (\ s -> eval_term i s alpha) ss);

binda :: forall a b c. Sum a b -> (b -> Sum a c) -> Sum a c;
binda m f = (case m of {
              Inl a -> Inl a;
              Inr a -> f a;
            });

isOK :: forall a b. Sum a b -> Bool;
isOK m = (case m of {
           Inl _ -> False;
           Inr _ -> True;
         });

is_Var :: forall a b. Term a b -> Bool;
is_Var (Var x1) = True;
is_Var (Fun x21 x22) = False;

check :: forall a. Bool -> a -> Sum a ();
check b e = (if b then Inr () else Inl e);

add_vars_term :: forall a b. Term a b -> [b] -> [b];
add_vars_term (Var x) xs = x : xs;
add_vars_term (Fun uu ts) xs = foldr add_vars_term ts xs;

add_vars_rule :: forall a b. (Term a b, Term a b) -> [b] -> [b];
add_vars_rule r xs = add_vars_term (fst r) (add_vars_term (snd r) xs);

vars_trs_list :: forall a b. [(Term a b, Term a b)] -> [b];
vars_trs_list trs = foldr add_vars_rule trs [];

catch_error :: forall a b c. Sum a b -> (a -> Sum c b) -> Sum c b;
catch_error m f = (case m of {
                    Inl a -> f a;
                    Inr a -> Inr a;
                  });

existsM :: forall a b. (a -> Sum b ()) -> [a] -> Sum [b] ();
existsM f [] = Inl [];
existsM f (x : xs) =
  catch_error (f x) (\ e -> catch_error (existsM f xs) (\ xa -> Inl (e : xa)));

forallM :: forall a b. (a -> Sum b ()) -> [a] -> Sum (a, b) ();
forallM f [] = Inr ();
forallM f (x : xs) =
  binda (catch_error (f x) (\ xa -> Inl (x, xa))) (\ _ -> forallM f xs);

length_tailrec :: forall a. [a] -> Nat -> Nat;
length_tailrec [] n = n;
length_tailrec (x : xs) n = length_tailrec xs (Suc n);

subst_of_map :: forall a b. (a -> b) -> (a -> Maybe b) -> a -> b;
subst_of_map d sigma x = (case sigma x of {
                           Nothing -> d x;
                           Just t -> t;
                         });

map_option :: forall a b. (a -> b) -> Maybe a -> Maybe b;
map_option f Nothing = Nothing;
map_option f (Just x2) = Just (f x2);

zip_option :: forall a b. [a] -> [b] -> Maybe [(a, b)];
zip_option [] [] = Just [];
zip_option (x : xs) (y : ys) =
  bind (zip_option xs ys) (\ zs -> Just ((x, y) : zs));
zip_option (x : xs) [] = Nothing;
zip_option [] (y : ys) = Nothing;

decompose ::
  forall a b c. (Eq a) => Term a b -> Term a c -> Maybe [(Term a b, Term a c)];
decompose s t =
  (case (s, t) of {
    (Var _, _) -> Nothing;
    (Fun _ _, Var _) -> Nothing;
    (Fun f ss, Fun g ts) -> (if f == g then zip_option ss ts else Nothing);
  });

match_term_list ::
  forall a b c.
    (Eq a, Eq b,
      Eq c) => [(Term a b, Term a c)] ->
                 (b -> Maybe (Term a c)) -> Maybe (b -> Maybe (Term a c));
match_term_list [] sigma = Just sigma;
match_term_list ((Var x, t) : p) sigma =
  (if is_none (sigma x) || sigma x == Just t
    then match_term_list p (fun_upd sigma x (Just t)) else Nothing);
match_term_list ((Fun f ss, Fun g ts) : p) sigma =
  (case decompose (Fun f ss) (Fun g ts) of {
    Nothing -> Nothing;
    Just us -> match_term_list (us ++ p) sigma;
  });
match_term_list ((Fun f ss, Var x) : p) sigma = Nothing;

match_list ::
  forall a b c.
    (Eq a, Eq b,
      Eq c) => (a -> Term b c) ->
                 [(Term b a, Term b c)] -> Maybe (a -> Term b c);
match_list d p =
  map_option (subst_of_map d) (match_term_list p (\ _ -> Nothing));

showsl_literal :: String -> String -> String;
showsl_literal s = showsl_lit s;

showsl_term ::
  forall a b.
    (a -> String -> String) ->
      (b -> String -> String) -> Term a b -> String -> String;
showsl_term fun var (Var x) = var x;
showsl_term fun var (Fun f ts) =
  fun f . showsl_list_gen id "" "(" ", " ")" (map (showsl_term fun var) ts);

showsl_rulea ::
  forall a b.
    (a -> String -> String) ->
      (b -> String -> String) ->
        String -> (Term a b, Term a b) -> String -> String;
showsl_rulea fun var arr (l, r) =
  (showsl_term fun var l . showsl_literal arr) . showsl_term fun var r;

showsl_rule ::
  forall a b. (Showl a, Showl b) => (Term a b, Term a b) -> String -> String;
showsl_rule = showsl_rulea showsl showsl " -> ";

vars_term_list :: forall a b. Term a b -> [b];
vars_term_list t = add_vars_term t [];

match_rules ::
  forall a b.
    (Eq a,
      Eq b) => [(Term a b, Term a b)] ->
                 [(Term a b, Term a b)] -> Maybe (b -> Term a b);
match_rules rs_1 rs_2 =
  bind (zip_option (map fst rs_2 ++ map snd rs_2)
         (map fst rs_1 ++ map snd rs_1))
    (match_list Var);

check_subseteq :: forall a. (Eq a) => [a] -> [a] -> Sum a ();
check_subseteq xs ys =
  catch_error (forallM (\ x -> (if member ys x then Inr () else Inl x)) xs)
    (\ x -> Inl (snd x));

ctxt_of_pos_term :: forall a b. [Nat] -> Term a b -> Actxt a (Term a b);
ctxt_of_pos_term [] t = Hole;
ctxt_of_pos_term (i : ps) (Fun f ts) =
  More f (take i ts) (ctxt_of_pos_term ps (nth ts i)) (drop (Suc i) ts);

nat_of_integer :: Integer -> Nat;
nat_of_integer k =
  (if k <= (0 :: Integer) then Zero_nat
    else (case divmod_integer k (2 :: Integer) of {
           (l, j) ->
             let {
               la = nat_of_integer l;
               lb = plus_nat la la;
             } in (if j == (0 :: Integer) then lb else plus_nat lb one_nat);
         }));

size_list :: forall a. [a] -> Nat;
size_list xs = length_tailrec xs Zero_nat;

intp_actxt :: forall a b. (a -> [b] -> b) -> Actxt a b -> b -> b;
intp_actxt i Hole a = a;
intp_actxt i (More f ls c rs) a = i f (ls ++ intp_actxt i c a : rs);

all_interval :: forall a. (Eq a, Interval a) => (a -> Bool) -> a -> a -> Bool;
all_interval p a b =
  (if less a b then p a && all_interval p (plus a one) b else True) &&
    (if a == b then p a else True);

x_impl ::
  forall a b. ((Term a b, Term a b), [(Term a b, Term a b)]) -> Nat -> [b];
x_impl cr i =
  concat
    (vars_term_list (fst (fst cr)) :
      map (vars_term_list . snd) (take i (snd cr)));

check_varcond_no_Var_lhs ::
  forall a b.
    (Showl a, Showl b) => [(Term a b, Term a b)] -> Sum (String -> String) ();
check_varcond_no_Var_lhs =
  (\ xs ->
    catch_error
      (forallM
        (\ rule ->
          check (not (is_Var (fst rule)))
            ((showsl_literal "variable left-hand side in rule " .
               showsl_rule rule) .
              showsl_literal "\n"))
        xs)
      (\ x -> Inl (snd x)));

showsl_eq ::
  forall a b. (Showl a, Showl b) => (Term a b, Term a b) -> String -> String;
showsl_eq = showsl_rulea showsl showsl " ->* ";

showsl_terma :: forall a b. (Showl a, Showl b) => Term a b -> String -> String;
showsl_terma t = showsl_term showsl showsl t;

showsl_conditions ::
  forall a b. (Showl a, Showl b) => [(Term a b, Term a b)] -> String -> String;
showsl_conditions = showsl_sep showsl_eq (showsl_lit ", ");

showsl_crule ::
  forall a b c d.
    (Showl a, Showl b, Showl c,
      Showl d) => ((Term a b, Term a b), [(Term c d, Term c d)]) ->
                    String -> String;
showsl_crule cr =
  showsl_rule (fst cr) .
    (if null (snd cr) then id
      else showsl_lit " | " . showsl_conditions (snd cr));

check_crule_variants ::
  forall a b.
    (Eq a, Showl a, Eq b,
      Showl b) => ((Term a b, Term a b), [(Term a b, Term a b)]) ->
                    ((Term a b, Term a b), [(Term a b, Term a b)]) ->
                      Sum (String -> String) ();
check_crule_variants ra r =
  let {
    rs = fst ra : snd ra;
    rsa = fst r : snd r;
  } in check (not (is_none (match_rules rs rsa)) &&
               not (is_none (match_rules rsa rs)))
         (((showsl_crule ra . showsl_lit " and ") . showsl_crule r) .
           showsl_lit " are not variants of each other\n");

showsl_crules ::
  forall a b c d.
    (Showl a, Showl b, Showl c,
      Showl d) => [((Term a b, Term a b), [(Term c d, Term c d)])] ->
                    String -> String;
showsl_crules ctrs =
  showsl_list_gen showsl_crule "" "" "\n" "" ctrs . showsl_literal "\n";

showsl_ctrs ::
  forall a b c d.
    (Showl a, Showl b, Showl c,
      Showl d) => [((Term a b, Term a b), [(Term c d, Term c d)])] ->
                    String -> String;
showsl_ctrs r = showsl_lit "CTRS:\n\n" . showsl_crules r;

check_variant_in_ctrs ::
  forall a b.
    (Eq a, Showl a, Eq b,
      Showl b) => [((Term a b, Term a b), [(Term a b, Term a b)])] ->
                    ((Term a b, Term a b), [(Term a b, Term a b)]) ->
                      Sum (String -> String) ();
check_variant_in_ctrs ra r =
  catch_error
    (catch_error (existsM (check_crule_variants r) ra)
      (\ x -> Inl (showsl_sep id id x)))
    (\ _ ->
      Inl (((showsl_lit "rule " . showsl_crule r) .
             showsl_lit " is not a variant of any rule in:\n") .
            showsl_ctrs ra));

cstep_trg :: forall a b. Cstep_proof a b -> Term a b;
cstep_trg (Cstep_step x1 x2 x3 x4 x5 x6) = x5;

cstep_src :: forall a b. Cstep_proof a b -> Term a b;
cstep_src (Cstep_step x1 x2 x3 x4 x5 x6) = x4;

check_cstep ::
  forall a b.
    (Eq a, Showl a, Eq b,
      Showl b) => [((Term a b, Term a b), [(Term a b, Term a b)])] ->
                    Cstep_proof a b -> Sum (String -> String) ();
check_cstep ra (Cstep_step ((l, r), cs) p sigma s t pss) =
  binda (check_variant_in_ctrs ra ((l, r), cs))
    (\ _ ->
      binda (check (equal_nat (size_list pss) (size_list cs))
              (showsl_lit
                "mismatch between number of conditions and number of rewrite sequences"))
        (\ _ ->
          binda (check
                  (equal_term s
                    (intp_actxt Fun (ctxt_of_pos_term p s)
                      (eval_term Fun l sigma)))
                  ((showsl_terma s .
                     showsl_lit " does not contain an instance of ") .
                    showsl_terma l))
            (\ _ ->
              binda (check
                      (equal_term t
                        (intp_actxt Fun (ctxt_of_pos_term p s)
                          (eval_term Fun r sigma)))
                      ((showsl_terma t .
                         showsl_lit " does not contain an instance of ") .
                        showsl_terma r))
                (\ _ ->
                  catch_error
                    (forallM
                      (\ i ->
                        check_csteps ra (eval_term Fun (fst (nth cs i)) sigma)
                          (eval_term Fun (snd (nth cs i)) sigma) (nth pss i))
                      (upt Zero_nat (size_list cs)))
                    (\ x -> Inl (snd x))))));

check_csteps ::
  forall a b.
    (Eq a, Showl a, Eq b,
      Showl b) => [((Term a b, Term a b), [(Term a b, Term a b)])] ->
                    Term a b ->
                      Term a b ->
                        [Cstep_proof a b] -> Sum (String -> String) ();
check_csteps r s t [] =
  check (equal_term s t)
    ((((showsl_lit "empty rewrite sequence but source " . showsl_terma s) .
        showsl_lit " and target ") .
       showsl_terma t) .
      showsl_lit " differ");
check_csteps r s t [p] =
  binda (check (equal_term (cstep_src p) s)
          ((showsl_terma (cstep_src p) .
             showsl_lit " does not match the source ") .
            showsl_terma s))
    (\ _ ->
      binda (check (equal_term (cstep_trg p) t)
              ((showsl_terma (cstep_trg p) .
                 showsl_lit " does not match the target ") .
                showsl_terma t))
        (\ _ -> check_cstep r p));
check_csteps r s t (p : v : va) =
  binda (check (equal_term (cstep_src p) s)
          ((showsl_terma (cstep_src p) .
             showsl_lit " does not match the source ") .
            showsl_terma s))
    (\ _ ->
      binda (check_cstep r p) (\ _ -> check_csteps r (cstep_trg p) t (v : va)));

check_dctrs ::
  forall a b.
    (Showl a, Eq b,
      Showl b) => [((Term a b, Term a b), [(Term a b, Term a b)])] ->
                    Sum (String -> String) ();
check_dctrs r =
  catch_error
    (catch_error
      (forallM
        (\ cr ->
          catch_error
            (forallM
              (\ i ->
                catch_error
                  (check_subseteq (vars_term_list (fst (nth (snd cr) i)))
                    (x_impl cr i))
                  (\ x ->
                    Inl ((((((showsl_lit "variable " . showsl x) .
                              showsl_lit " in condition ") .
                             showsl_rule (nth (snd cr) i)) .
                            showsl_lit " of rule ") .
                           showsl_crule cr) .
                          showsl_lit "violates DCTRS condition\n")))
              (upt Zero_nat (size_list (snd cr))))
            (\ x -> Inl (snd x)))
        r)
      (\ x -> Inl (snd x)))
    (\ x -> Inl (showsl_lit "the CTRS is not deterministic\n" . x));

check_type3 ::
  forall a b.
    (Showl a, Eq b,
      Showl b) => [((Term a b, Term a b), [(Term a b, Term a b)])] ->
                    Sum (String -> String) ();
check_type3 r =
  catch_error
    (catch_error
      (forallM
        (\ cr ->
          catch_error
            (check_subseteq (vars_term_list (snd (fst cr)))
              (vars_term_list (fst (fst cr)) ++ vars_trs_list (snd cr)))
            (\ x ->
              Inl ((((showsl_lit "variable " . showsl x) .
                      showsl_lit " occurs only in right-hand side of rule ") .
                     showsl_crule cr) .
                    showsl_literal "\n")))
        r)
      (\ x -> Inl (snd x)))
    (\ x -> Inl (showsl_lit "the CTRS is not of type 3\n" . x));

check_wf_ctrs ::
  forall a b.
    (Showl a, Eq b,
      Showl b) => [((Term a b, Term a b), [(Term a b, Term a b)])] ->
                    Sum (String -> String) ();
check_wf_ctrs r =
  catch_error
    (binda (check_varcond_no_Var_lhs (map fst r))
      (\ _ -> binda (check_dctrs r) (\ _ -> check_type3 r)))
    (\ x -> Inl (showsl_lit "the CTRS is not well-formed\n" . x));

descent_source :: forall a b. Conditional_descent_proof a b -> Term a b;
descent_source (Conditional_rewrite p) = cstep_src p;
descent_source (Conditional_call k sigma i ps s t) = s;
descent_source (Conditional_argument f ts i) = Fun f ts;

descent_target :: forall a b. Conditional_descent_proof a b -> Term a b;
descent_target (Conditional_rewrite p) = cstep_trg p;
descent_target (Conditional_call k sigma i ps s t) = t;
descent_target (Conditional_argument f ts i) = nth ts i;

check_conditional_descent ::
  forall a b.
    (Eq a, Showl a, Eq b,
      Showl b) => [((Term a b, Term a b), [(Term a b, Term a b)])] ->
                    Conditional_descent_proof a b -> Bool;
check_conditional_descent r (Conditional_rewrite p) = isOK (check_cstep r p);
check_conditional_descent r (Conditional_call k sigma i ps s t) =
  less_nat k (size_list r) &&
    (case nth r k of {
      (a, b) ->
        (case a of {
          (l, _) ->
            (\ cs ->
              less_nat i (size_list cs) &&
                equal_nat (size_list ps) i &&
                  equal_term s (eval_term Fun l sigma) &&
                    equal_term t (eval_term Fun (fst (nth cs i)) sigma) &&
                      let {
                        d = minus_nat i one_nat;
                      } in (if less_nat d i
                             then all_interval
                                    (\ j ->
                                      isOK
(check_csteps r (eval_term Fun (fst (nth cs j)) sigma)
  (eval_term Fun (snd (nth cs j)) sigma) (nth ps j)))
                                    Zero_nat d
                             else True));
        })
          b;
    });
check_conditional_descent r (Conditional_argument f ts i) =
  less_nat i (size_list ts);

check_conditional_trace ::
  forall a b.
    (Eq a, Showl a, Eq b,
      Showl b) => [((Term a b, Term a b), [(Term a b, Term a b)])] ->
                    Term a b ->
                      Term a b -> [Conditional_descent_proof a b] -> Bool;
check_conditional_trace r s t [] = equal_term s t;
check_conditional_trace r s t (p : ps) =
  equal_term s (descent_source p) &&
    check_conditional_descent r p &&
      check_conditional_trace r (descent_target p) t ps;

check_conditional_cycle ::
  forall a b.
    (Eq a, Showl a, Eq b,
      Showl b) => [((Term a b, Term a b), [(Term a b, Term a b)])] ->
                    Term a b -> [Conditional_descent_proof a b] -> Bool;
check_conditional_cycle r s ps =
  not (null ps) && check_conditional_trace r s s ps;

conditional_check ::
  [((Term Integer [Integer], Term Integer [Integer]),
     [(Term Integer [Integer], Term Integer [Integer])])] ->
    Term Integer [Integer] ->
      [Conditional_descent_proof Integer [Integer]] -> Bool;
conditional_check r s ps =
  isOK (check_wf_ctrs r) && check_conditional_cycle r s ps;

ordinary_descent_step :: forall a b. Conditional_descent_proof a b -> Bool;
ordinary_descent_step (Conditional_rewrite p) = True;
ordinary_descent_step (Conditional_argument f ts i) = True;
ordinary_descent_step (Conditional_call k s i ps t u) = False;

check_conditional_loop ::
  forall a b.
    (Eq a, Showl a, Eq b,
      Showl b) => [((Term a b, Term a b), [(Term a b, Term a b)])] ->
                    Term a b ->
                      [Conditional_descent_proof a b] ->
                        (b -> Term a b) -> Bool;
check_conditional_loop r s ps sigma =
  not (null ps) && check_conditional_trace r s (eval_term Fun s sigma) ps;

conditional_substitution ::
  [([Integer], Term Integer [Integer])] -> [Integer] -> Term Integer [Integer];
conditional_substitution xs x = (case map_of xs x of {
                                  Nothing -> Var x;
                                  Just t -> t;
                                });

conditional_check_loop ::
  [((Term Integer [Integer], Term Integer [Integer]),
     [(Term Integer [Integer], Term Integer [Integer])])] ->
    Term Integer [Integer] ->
      [Conditional_descent_proof Integer [Integer]] ->
        [([Integer], Term Integer [Integer])] -> Bool;
conditional_check_loop r s ps xs =
  isOK (check_wf_ctrs r) &&
    check_conditional_loop r s ps (conditional_substitution xs);

conditional_check_rewrite_loop ::
  [((Term Integer [Integer], Term Integer [Integer]),
     [(Term Integer [Integer], Term Integer [Integer])])] ->
    Term Integer [Integer] ->
      [Conditional_descent_proof Integer [Integer]] ->
        [([Integer], Term Integer [Integer])] -> Bool;
conditional_check_rewrite_loop r s ps xs =
  all ordinary_descent_step ps &&
    check_conditional_loop r s ps (conditional_substitution xs);

}
