{-# LANGUAGE EmptyDataDecls, RankNTypes, ScopedTypeVariables #-}

module
  LP_Cut_NO_Generated(Nat(..), integer_of_nat, equal_nat, less_eq_nat, Ord(..),
                       less_nat, Quasi_order(..), Weak_order(..), Preorder(..),
                       Order(..), ceq_nat, Ceq(..), Linorder(..), Ordera(..),
                       comparator_of, compare_nat, ccompare_nat, Ccompare(..),
                       equality_list, ceq_list, Phantom(..), Set_impla(..),
                       set_impl_list, Set_impl(..), Showl(..), showsl_lista,
                       showsl_lit, showsl_sep, showsl_list_gen,
                       default_showsl_list, showsl_list_list, comparator_list,
                       ccompare_list, Term(..), equal_term, Char(..),
                       integer_of_char, equal_char, shows_prec_char,
                       shows_string, shows_list_char, Showa(..), less_eq_char,
                       less_char, ceq_char, implode, showsl_list_char,
                       showsl_char, compare_char, ccompare_char,
                       Lp_cut_goal(..), equal_lp_cut_goal, Lp_cut_entry(..),
                       equal_lp_cut_entry, Lp_cut_symbol(..),
                       equal_lp_cut_symbol, showsl_lp_cut_symbol,
                       showsl_list_lp_cut_symbol, Num(..), Color(..), Rbt(..),
                       Mapping_rbt(..), Set_dlist(..), Set(..), Xml(..),
                       Xmldoc(..), Alist(..), Sum(..), Xml_error(..),
                       Mapping(..), Enat(..), Sum_bot(..), Mapping_impl(..),
                       Lp_cut_tag(..), Lp_cut_coverage(..), Lpc_no_action(..),
                       plus_nat, one_nat, suc, max, minus_nat, zero_nat, nth,
                       upt, list_of_dlist, dlist_all, impl_ofa,
                       rBT_Impl_rbt_all, alla, ball, drop, take, foldl, foldr,
                       map_of, fun_upd, balance, rbt_comp_ins, paint,
                       rbt_comp_insert_with_key, rbt_comp_insert, the, insertb,
                       list_member, list_insert, inserta, balance_right,
                       balance_left, combine, rbt_comp_del,
                       rbt_comp_del_from_left, rbt_comp_del_from_right,
                       rbt_comp_delete, delete, list_remove1, removea, insert,
                       remove, memberc, rbt_comp_lookup, lookupb, memberb,
                       member, bind2, membera, ground, char_0x7A, char_0x79,
                       char_0x78, char_0x77, char_0x76, char_0x75, char_0x74,
                       char_0x73, char_0x72, char_0x71, char_0x70, char_0x6F,
                       char_0x6E, char_0x6D, char_0x6C, char_0x6B, char_0x6A,
                       char_0x69, char_0x68, char_0x67, char_0x66, char_0x65,
                       char_0x64, char_0x63, char_0x62, char_0x61, char_0x5F,
                       char_0x5A, char_0x59, char_0x58, char_0x57, char_0x56,
                       char_0x55, char_0x54, char_0x53, char_0x52, char_0x51,
                       char_0x50, char_0x4F, char_0x4E, char_0x4D, char_0x4C,
                       char_0x4B, char_0x4A, char_0x49, char_0x48, char_0x47,
                       char_0x46, char_0x45, char_0x44, char_0x43, char_0x42,
                       char_0x41, char_0x3B, char_0x3A, char_0x39, char_0x38,
                       char_0x37, char_0x36, char_0x35, char_0x34, char_0x33,
                       char_0x32, char_0x31, char_0x30, char_0x2D, char_0x26,
                       letters, apsnd, divmod_integer, modulo_integer,
                       char_of_integer, explode, left, xml_error, mismatch,
                       xml_do, right, xml_or, empty, hd, tl, times_nat,
                       nat_of_integer, nat_of_digit, obind, nat_of_string_aux,
                       nat_of_string, xml_take_nat, xml_return, xml_nat,
                       impl_of, lookup, distinct, of_phantom, emptyb, emptya,
                       set_empty_choose, set_empty, set_aux, set, is_letter,
                       update_tokens, char_0x3C, char_0x21, comment_error,
                       comment_error_hyphen, rc_open_1, rc_close_3, rc_close_2,
                       rc_close_1, rc_open_4, rc_open_3, rc_open_2,
                       remove_comments, returna, bind, binda, char_0x3F,
                       char_0x3E, shows_prec_list, length_tailrec, size_list,
                       char_0x20, char_0x27, shows_quote, scan_upto, trim,
                       spaces, parse_header, char_0x2C, err_expecting, eoi,
                       char_0x2F, char_0x3D, char_0x22, exactly_aux, exactly,
                       many, parse_attribute_value, many_letters_main,
                       parse_name, parse_attributes, char_0x5D, char_0x5B,
                       oneof_closed, parse_text_main, parse_text_impl,
                       parse_text, parse_nodes, parse_node, parse_doc,
                       bool_of_string, xml_take_text, xml_text, xml_bool,
                       xml_take, replicate, lookupa, eval_term,
                       xml_error_to_string, parse_xml, xml_change, char_0x23,
                       special_map, doc_of_string, map_xml_text, add_vars_term,
                       vars_term_list, vars_term, plain_var, var, map_option,
                       extract_special, zero_enat, minus_enat, equal_enat,
                       one_enat, xml_take_many_sub, term, normalize_special,
                       parse_xml_string, lp_cut_map, char_0x24, lp_prefix,
                       lp_cut_bind, set_impl_nat, lp_cut_goal_scopes,
                       lpc_scope_absent, lp_cut_fresh, lp_cut_slice,
                       mapping_empty_choose, mapping_empty, lp_cut_prune,
                       lp_cut_admin, lpc_mgu_substitution, lp_cut_decode,
                       lp_cut_decode_list, lp_atom_subst, lp_eliminate,
                       lp_normalize_goals, lp_cut_encode, lp_cut_normalize,
                       lpc_check_mgu, lp_cut_terms, lp_cut_short_goals,
                       lpc_no_swap, lpc_no_resolve_swap, lp_cut_check_equality,
                       lp_cut_lower_finite, lp_cut_check_meta,
                       lp_cut_check_case, lp_cut_check_clash,
                       lp_cut_check_admin, lpc_no_resolve, lpc_no_step,
                       lpc_no_trace, lp_cut_source_goal, lp_cut_source_program,
                       lpc_no_suffix_safe, lp_cut_is_barrier,
                       lpc_no_check_source, mapping_impl_list,
                       lpc_symbol_parser, lpc_term_parser, lpc_goal_parser,
                       lpc_entry_parser, lpc_no_action_parser,
                       lpc_no_trace_parser, lpc_no_certificate_parser,
                       case_sum_bot, check_lpc_no_xml)
  where {

import Prelude ((==), (/=), (<), (<=), (>=), (>), (+), (-), (*), (/), (**),
  (>>=), (>>), (=<<), (&&), (||), (^), (^^), (.), ($), ($!), (++), (!!), Eq,
  error, id, return, not, fst, snd, map, filter, concat, concatMap, reverse,
  zip, null, takeWhile, dropWhile, all, any, Integer, negate, abs, divMod,
  String, Bool(True, False), Maybe(Nothing, Just));
import Data.Bits ((.&.), (.|.), (.^.));
import qualified Prelude;
import qualified Data.Bits;
import qualified Uint;
import qualified Array;
import qualified Uint32;
import qualified Uint64;
import qualified Data_Bits;
import qualified Bit_Shifts;
import qualified Str_Literal;

newtype Nat = Nat Integer;

integer_of_nat :: Nat -> Integer;
integer_of_nat (Nat x) = x;

equal_nat :: Nat -> Nat -> Bool;
equal_nat m n = integer_of_nat m == integer_of_nat n;

instance Eq Nat where {
  a == b = equal_nat a b;
};

less_eq_nat :: Nat -> Nat -> Bool;
less_eq_nat m n = integer_of_nat m <= integer_of_nat n;

class Ord a where {
  less_eq :: a -> a -> Bool;
  less :: a -> a -> Bool;
};

less_nat :: Nat -> Nat -> Bool;
less_nat m n = integer_of_nat m < integer_of_nat n;

instance Ord Nat where {
  less_eq = less_eq_nat;
  less = less_nat;
};

class (Ord a) => Quasi_order a where {
};

class (Quasi_order a) => Weak_order a where {
};

class (Ord a) => Preorder a where {
};

class (Preorder a, Weak_order a) => Order a where {
};

instance Quasi_order Nat where {
};

instance Weak_order Nat where {
};

instance Preorder Nat where {
};

instance Order Nat where {
};

ceq_nat :: Maybe (Nat -> Nat -> Bool);
ceq_nat = Just equal_nat;

class Ceq a where {
  ceq :: Maybe (a -> a -> Bool);
};

instance Ceq Nat where {
  ceq = ceq_nat;
};

class (Order a) => Linorder a where {
};

instance Linorder Nat where {
};

data Ordera = Eqa | Lt | Gt;

comparator_of :: forall a. (Eq a, Linorder a) => a -> a -> Ordera;
comparator_of x y = (if less x y then Lt else (if x == y then Eqa else Gt));

compare_nat :: Nat -> Nat -> Ordera;
compare_nat = comparator_of;

ccompare_nat :: Maybe (Nat -> Nat -> Ordera);
ccompare_nat = Just compare_nat;

class Ccompare a where {
  ccompare :: Maybe (a -> a -> Ordera);
};

instance Ccompare Nat where {
  ccompare = ccompare_nat;
};

equality_list :: forall a. (a -> a -> Bool) -> [a] -> [a] -> Bool;
equality_list eq_a [] [] = True;
equality_list eq_a [] (y : ya) = False;
equality_list eq_a (x : xa) [] = False;
equality_list eq_a (x : xa) (y : ya) = eq_a x y && equality_list eq_a xa ya;

ceq_list :: forall a. (Ceq a) => Maybe ([a] -> [a] -> Bool);
ceq_list = (case ceq of {
             Nothing -> Nothing;
             Just eq_a -> Just (equality_list eq_a);
           });

instance (Ceq a) => Ceq [a] where {
  ceq = ceq_list;
};

newtype Phantom a b = Phantom b;

data Set_impla = Set_Choose | Set_Collect | Set_DList | Set_RBT | Set_Monada;

set_impl_list :: forall a. Phantom [a] Set_impla;
set_impl_list = Phantom Set_Choose;

class Set_impl a where {
  set_impl :: Phantom a Set_impla;
};

instance Set_impl [a] where {
  set_impl = set_impl_list;
};

class Showl a where {
  showsl :: a -> String -> String;
  showsl_list :: [a] -> String -> String;
};

showsl_lista :: forall a. (Showl a) => [a] -> String -> String;
showsl_lista xs = showsl_list xs;

showsl_lit :: String -> String -> String;
showsl_lit = (\ a b -> a ++ b);

showsl_sep ::
  forall a.
    (a -> String -> String) -> (String -> String) -> [a] -> String -> String;
showsl_sep s sep [] = showsl_lit "";
showsl_sep s sep [x] = s x;
showsl_sep s sep (x : v : va) = (s x . sep) . showsl_sep s sep (v : va);

showsl_list_gen ::
  forall a.
    (a -> String -> String) ->
      String -> String -> String -> String -> [a] -> String -> String;
showsl_list_gen showslx e l s r xs =
  (if null xs then showsl_lit e
    else (showsl_lit l . showsl_sep showslx (showsl_lit s) xs) . showsl_lit r);

default_showsl_list ::
  forall a. (a -> String -> String) -> [a] -> String -> String;
default_showsl_list sl = showsl_list_gen sl "[]" "[" ", " "]";

showsl_list_list :: forall a. (Showl a) => [[a]] -> String -> String;
showsl_list_list xs = default_showsl_list showsl_lista xs;

instance (Showl a) => Showl [a] where {
  showsl = showsl_lista;
  showsl_list = showsl_list_list;
};

comparator_list :: forall a. (a -> a -> Ordera) -> [a] -> [a] -> Ordera;
comparator_list comp_a [] [] = Eqa;
comparator_list comp_a [] (y : ya) = Lt;
comparator_list comp_a (x : xa) [] = Gt;
comparator_list comp_a (x : xa) (y : ya) =
  (case comp_a x y of {
    Eqa -> comparator_list comp_a xa ya;
    Lt -> Lt;
    Gt -> Gt;
  });

ccompare_list :: forall a. (Ccompare a) => Maybe ([a] -> [a] -> Ordera);
ccompare_list = (case ccompare of {
                  Nothing -> Nothing;
                  Just comp_a -> Just (comparator_list comp_a);
                });

instance (Ccompare a) => Ccompare [a] where {
  ccompare = ccompare_list;
};

data Term a b = Var b | Fun a [Term a b];

instance (Eq a, Eq b) => Eq (Term a b) where {
  a == b = equal_term a b;
};

equal_term :: forall a b. (Eq a, Eq b) => Term a b -> Term a b -> Bool;
equal_term (Var x1) (Fun x21 x22) = False;
equal_term (Fun x21 x22) (Var x1) = False;
equal_term (Fun x21 x22) (Fun y21 y22) = x21 == y21 && x22 == y22;
equal_term (Var x1) (Var y1) = x1 == y1;

newtype Char = Chr Integer;

integer_of_char :: Char -> Integer;
integer_of_char (Chr x) = x;

equal_char :: Char -> Char -> Bool;
equal_char c d = integer_of_char c == integer_of_char d;

instance Eq Char where {
  a == b = equal_char a b;
};

shows_prec_char :: Nat -> Char -> [Char] -> [Char];
shows_prec_char p c = (\ a -> c : a);

shows_string :: [Char] -> [Char] -> [Char];
shows_string = (\ a b -> a ++ b);

shows_list_char :: [Char] -> [Char] -> [Char];
shows_list_char cs = shows_string cs;

class Showa a where {
  shows_prec :: Nat -> a -> [Char] -> [Char];
  shows_list :: [a] -> [Char] -> [Char];
};

instance Showa Char where {
  shows_prec = shows_prec_char;
  shows_list = shows_list_char;
};

less_eq_char :: Char -> Char -> Bool;
less_eq_char c d = integer_of_char c <= integer_of_char d;

less_char :: Char -> Char -> Bool;
less_char c d = integer_of_char c < integer_of_char d;

instance Ord Char where {
  less_eq = less_eq_char;
  less = less_char;
};

instance Quasi_order Char where {
};

instance Weak_order Char where {
};

instance Preorder Char where {
};

instance Order Char where {
};

ceq_char :: Maybe (Char -> Char -> Bool);
ceq_char = Just equal_char;

instance Ceq Char where {
  ceq = ceq_char;
};

instance Linorder Char where {
};

implode :: [Char] -> String;
implode cs = Str_Literal.literalOfAsciis (map integer_of_char cs);

showsl_list_char :: [Char] -> String -> String;
showsl_list_char cs s = showsl_lit (implode cs) s;

showsl_char :: Char -> String -> String;
showsl_char c = showsl_lit (implode [c]);

instance Showl Char where {
  showsl = showsl_char;
  showsl_list = showsl_list_char;
};

compare_char :: Char -> Char -> Ordera;
compare_char = comparator_of;

ccompare_char :: Maybe (Char -> Char -> Ordera);
ccompare_char = Just compare_char;

instance Ccompare Char where {
  ccompare = ccompare_char;
};

instance Ord Integer where {
  less_eq = (\ a b -> a <= b);
  less = (\ a b -> a < b);
};

data Lp_cut_goal a = LPCAtom a | LPCCut Nat | LPCTrue | LPCFail | LPCMeta a
  | LPCExpand a Nat | LPCUnify a a;

equal_lp_cut_goal :: forall a. (Eq a) => Lp_cut_goal a -> Lp_cut_goal a -> Bool;
equal_lp_cut_goal (LPCExpand x61 x62) (LPCUnify x71 x72) = False;
equal_lp_cut_goal (LPCUnify x71 x72) (LPCExpand x61 x62) = False;
equal_lp_cut_goal (LPCMeta x5) (LPCUnify x71 x72) = False;
equal_lp_cut_goal (LPCUnify x71 x72) (LPCMeta x5) = False;
equal_lp_cut_goal (LPCMeta x5) (LPCExpand x61 x62) = False;
equal_lp_cut_goal (LPCExpand x61 x62) (LPCMeta x5) = False;
equal_lp_cut_goal LPCFail (LPCUnify x71 x72) = False;
equal_lp_cut_goal (LPCUnify x71 x72) LPCFail = False;
equal_lp_cut_goal LPCFail (LPCExpand x61 x62) = False;
equal_lp_cut_goal (LPCExpand x61 x62) LPCFail = False;
equal_lp_cut_goal LPCFail (LPCMeta x5) = False;
equal_lp_cut_goal (LPCMeta x5) LPCFail = False;
equal_lp_cut_goal LPCTrue (LPCUnify x71 x72) = False;
equal_lp_cut_goal (LPCUnify x71 x72) LPCTrue = False;
equal_lp_cut_goal LPCTrue (LPCExpand x61 x62) = False;
equal_lp_cut_goal (LPCExpand x61 x62) LPCTrue = False;
equal_lp_cut_goal LPCTrue (LPCMeta x5) = False;
equal_lp_cut_goal (LPCMeta x5) LPCTrue = False;
equal_lp_cut_goal LPCTrue LPCFail = False;
equal_lp_cut_goal LPCFail LPCTrue = False;
equal_lp_cut_goal (LPCCut x2) (LPCUnify x71 x72) = False;
equal_lp_cut_goal (LPCUnify x71 x72) (LPCCut x2) = False;
equal_lp_cut_goal (LPCCut x2) (LPCExpand x61 x62) = False;
equal_lp_cut_goal (LPCExpand x61 x62) (LPCCut x2) = False;
equal_lp_cut_goal (LPCCut x2) (LPCMeta x5) = False;
equal_lp_cut_goal (LPCMeta x5) (LPCCut x2) = False;
equal_lp_cut_goal (LPCCut x2) LPCFail = False;
equal_lp_cut_goal LPCFail (LPCCut x2) = False;
equal_lp_cut_goal (LPCCut x2) LPCTrue = False;
equal_lp_cut_goal LPCTrue (LPCCut x2) = False;
equal_lp_cut_goal (LPCAtom x1) (LPCUnify x71 x72) = False;
equal_lp_cut_goal (LPCUnify x71 x72) (LPCAtom x1) = False;
equal_lp_cut_goal (LPCAtom x1) (LPCExpand x61 x62) = False;
equal_lp_cut_goal (LPCExpand x61 x62) (LPCAtom x1) = False;
equal_lp_cut_goal (LPCAtom x1) (LPCMeta x5) = False;
equal_lp_cut_goal (LPCMeta x5) (LPCAtom x1) = False;
equal_lp_cut_goal (LPCAtom x1) LPCFail = False;
equal_lp_cut_goal LPCFail (LPCAtom x1) = False;
equal_lp_cut_goal (LPCAtom x1) LPCTrue = False;
equal_lp_cut_goal LPCTrue (LPCAtom x1) = False;
equal_lp_cut_goal (LPCAtom x1) (LPCCut x2) = False;
equal_lp_cut_goal (LPCCut x2) (LPCAtom x1) = False;
equal_lp_cut_goal (LPCUnify x71 x72) (LPCUnify y71 y72) =
  x71 == y71 && x72 == y72;
equal_lp_cut_goal (LPCExpand x61 x62) (LPCExpand y61 y62) =
  x61 == y61 && equal_nat x62 y62;
equal_lp_cut_goal (LPCMeta x5) (LPCMeta y5) = x5 == y5;
equal_lp_cut_goal (LPCCut x2) (LPCCut y2) = equal_nat x2 y2;
equal_lp_cut_goal (LPCAtom x1) (LPCAtom y1) = x1 == y1;
equal_lp_cut_goal LPCFail LPCFail = True;
equal_lp_cut_goal LPCTrue LPCTrue = True;

instance (Eq a) => Eq (Lp_cut_goal a) where {
  a == b = equal_lp_cut_goal a b;
};

data Lp_cut_entry a = LPCGoals [Lp_cut_goal a]
  | LPCClause [Lp_cut_goal a] Nat Nat | LPCBarrier Nat;

equal_lp_cut_entry ::
  forall a. (Eq a) => Lp_cut_entry a -> Lp_cut_entry a -> Bool;
equal_lp_cut_entry (LPCClause x21 x22 x23) (LPCBarrier x3) = False;
equal_lp_cut_entry (LPCBarrier x3) (LPCClause x21 x22 x23) = False;
equal_lp_cut_entry (LPCGoals x1) (LPCBarrier x3) = False;
equal_lp_cut_entry (LPCBarrier x3) (LPCGoals x1) = False;
equal_lp_cut_entry (LPCGoals x1) (LPCClause x21 x22 x23) = False;
equal_lp_cut_entry (LPCClause x21 x22 x23) (LPCGoals x1) = False;
equal_lp_cut_entry (LPCBarrier x3) (LPCBarrier y3) = equal_nat x3 y3;
equal_lp_cut_entry (LPCClause x21 x22 x23) (LPCClause y21 y22 y23) =
  x21 == y21 && equal_nat x22 y22 && equal_nat x23 y23;
equal_lp_cut_entry (LPCGoals x1) (LPCGoals y1) = x1 == y1;

instance (Eq a) => Eq (Lp_cut_entry a) where {
  a == b = equal_lp_cut_entry a b;
};

data Lp_cut_symbol a = LPCUser a | LPCBang | LPCComma | LPCEquals | LPCTruth
  | LPCFailure | LPCCallSymbol;

equal_lp_cut_symbol ::
  forall a. (Eq a) => Lp_cut_symbol a -> Lp_cut_symbol a -> Bool;
equal_lp_cut_symbol LPCFailure LPCCallSymbol = False;
equal_lp_cut_symbol LPCCallSymbol LPCFailure = False;
equal_lp_cut_symbol LPCTruth LPCCallSymbol = False;
equal_lp_cut_symbol LPCCallSymbol LPCTruth = False;
equal_lp_cut_symbol LPCTruth LPCFailure = False;
equal_lp_cut_symbol LPCFailure LPCTruth = False;
equal_lp_cut_symbol LPCEquals LPCCallSymbol = False;
equal_lp_cut_symbol LPCCallSymbol LPCEquals = False;
equal_lp_cut_symbol LPCEquals LPCFailure = False;
equal_lp_cut_symbol LPCFailure LPCEquals = False;
equal_lp_cut_symbol LPCEquals LPCTruth = False;
equal_lp_cut_symbol LPCTruth LPCEquals = False;
equal_lp_cut_symbol LPCComma LPCCallSymbol = False;
equal_lp_cut_symbol LPCCallSymbol LPCComma = False;
equal_lp_cut_symbol LPCComma LPCFailure = False;
equal_lp_cut_symbol LPCFailure LPCComma = False;
equal_lp_cut_symbol LPCComma LPCTruth = False;
equal_lp_cut_symbol LPCTruth LPCComma = False;
equal_lp_cut_symbol LPCComma LPCEquals = False;
equal_lp_cut_symbol LPCEquals LPCComma = False;
equal_lp_cut_symbol LPCBang LPCCallSymbol = False;
equal_lp_cut_symbol LPCCallSymbol LPCBang = False;
equal_lp_cut_symbol LPCBang LPCFailure = False;
equal_lp_cut_symbol LPCFailure LPCBang = False;
equal_lp_cut_symbol LPCBang LPCTruth = False;
equal_lp_cut_symbol LPCTruth LPCBang = False;
equal_lp_cut_symbol LPCBang LPCEquals = False;
equal_lp_cut_symbol LPCEquals LPCBang = False;
equal_lp_cut_symbol LPCBang LPCComma = False;
equal_lp_cut_symbol LPCComma LPCBang = False;
equal_lp_cut_symbol (LPCUser x1) LPCCallSymbol = False;
equal_lp_cut_symbol LPCCallSymbol (LPCUser x1) = False;
equal_lp_cut_symbol (LPCUser x1) LPCFailure = False;
equal_lp_cut_symbol LPCFailure (LPCUser x1) = False;
equal_lp_cut_symbol (LPCUser x1) LPCTruth = False;
equal_lp_cut_symbol LPCTruth (LPCUser x1) = False;
equal_lp_cut_symbol (LPCUser x1) LPCEquals = False;
equal_lp_cut_symbol LPCEquals (LPCUser x1) = False;
equal_lp_cut_symbol (LPCUser x1) LPCComma = False;
equal_lp_cut_symbol LPCComma (LPCUser x1) = False;
equal_lp_cut_symbol (LPCUser x1) LPCBang = False;
equal_lp_cut_symbol LPCBang (LPCUser x1) = False;
equal_lp_cut_symbol (LPCUser x1) (LPCUser y1) = x1 == y1;
equal_lp_cut_symbol LPCCallSymbol LPCCallSymbol = True;
equal_lp_cut_symbol LPCFailure LPCFailure = True;
equal_lp_cut_symbol LPCTruth LPCTruth = True;
equal_lp_cut_symbol LPCEquals LPCEquals = True;
equal_lp_cut_symbol LPCComma LPCComma = True;
equal_lp_cut_symbol LPCBang LPCBang = True;

instance (Eq a) => Eq (Lp_cut_symbol a) where {
  a == b = equal_lp_cut_symbol a b;
};

showsl_lp_cut_symbol ::
  forall a. (Showl a) => Lp_cut_symbol a -> String -> String;
showsl_lp_cut_symbol (LPCUser f) = showsl f;
showsl_lp_cut_symbol LPCBang = showsl_lit "!";
showsl_lp_cut_symbol LPCComma = showsl_lit ",";
showsl_lp_cut_symbol LPCEquals = showsl_lit "=";
showsl_lp_cut_symbol LPCTruth = showsl_lit "true";
showsl_lp_cut_symbol LPCFailure = showsl_lit "fail";
showsl_lp_cut_symbol LPCCallSymbol = showsl_lit "call";

showsl_list_lp_cut_symbol ::
  forall a. (Showl a) => [Lp_cut_symbol a] -> String -> String;
showsl_list_lp_cut_symbol xs = default_showsl_list showsl_lp_cut_symbol xs;

instance (Showl a) => Showl (Lp_cut_symbol a) where {
  showsl = showsl_lp_cut_symbol;
  showsl_list = showsl_list_lp_cut_symbol;
};

data Num = One | Bit0 Num | Bit1 Num;

data Color = R | B;

data Rbt a b = Empty | Branch Color (Rbt a b) a b (Rbt a b);

newtype Mapping_rbt b a = Mapping_RBTa (Rbt b a);

newtype Set_dlist a = Abs_dlist [a];

data Set a = Collect_set (a -> Bool) | DList_set (Set_dlist a)
  | RBT_set (Mapping_rbt a ()) | Set_Monad [a] | Complement (Set a);

data Xml = XML [Char] [([Char], [Char])] [Xml] | XML_text [Char];

data Xmldoc = XMLDOC [[Char]] Xml;

newtype Alist b a = Alist [(b, a)];

data Sum a b = Inl a | Inr b;

data Xml_error a = TagMismatch [String] | Fatal a;

data Mapping a b = Assoc_List_Mapping (Alist a b)
  | RBT_Mapping (Mapping_rbt a b) | Mapping (a -> Maybe b);

data Enat = Enat Nat | Infinity_enat;

newtype Sum_bot a b = Sumbot (Sum a b);

data Mapping_impl = Mapping_Choose | Mapping_Assoc_List | Mapping_RBT
  | Mapping_Mapping;

data Lp_cut_tag = LPCAtomTag | LPCCutTag Nat | LPCTrueTag | LPCFailTag
  | LPCMetaTag | LPCExpandTag Nat | LPCUnifyTag;

data Lp_cut_coverage = LPCAlwaysSuccess | LPCAlwaysFailure | LPCBoth;

data Lpc_no_action a = LPCNOAdmin | LPCNOCase Nat
  | LPCNOMeta Nat [Lp_cut_goal (Term (Lp_cut_symbol a) [Char])]
  | LPCNOResolve Nat [[Char]] [Term (Lp_cut_symbol a) [Char]]
  | LPCNOUnify [[Char]] [Term (Lp_cut_symbol a) [Char]] | LPCNOBacktrack Nat
  | LPCNOUnifyFail
  | LPCNOResolveSwap Nat [[Char]] [Term (Lp_cut_symbol a) [Char]] [Char] [Char];

plus_nat :: Nat -> Nat -> Nat;
plus_nat m n = Nat (integer_of_nat m + integer_of_nat n);

one_nat :: Nat;
one_nat = Nat (1 :: Integer);

suc :: Nat -> Nat;
suc n = plus_nat n one_nat;

max :: forall a. (Ord a) => a -> a -> a;
max a b = (if less_eq a b then b else a);

minus_nat :: Nat -> Nat -> Nat;
minus_nat m n = Nat (max (0 :: Integer) (integer_of_nat m - integer_of_nat n));

zero_nat :: Nat;
zero_nat = Nat (0 :: Integer);

nth :: forall a. [a] -> Nat -> a;
nth (x : xs) n =
  (if equal_nat n zero_nat then x else nth xs (minus_nat n one_nat));

upt :: Nat -> Nat -> [Nat];
upt i j = (if less_nat i j then i : upt (suc i) j else []);

list_of_dlist :: forall a. (Ceq a) => Set_dlist a -> [a];
list_of_dlist (Abs_dlist x) = x;

dlist_all :: forall a. (Ceq a) => (a -> Bool) -> Set_dlist a -> Bool;
dlist_all x xc = all x (list_of_dlist xc);

impl_ofa :: forall b a. (Ccompare b) => Mapping_rbt b a -> Rbt b a;
impl_ofa (Mapping_RBTa x) = x;

rBT_Impl_rbt_all :: forall a b. (a -> b -> Bool) -> Rbt a b -> Bool;
rBT_Impl_rbt_all p Empty = True;
rBT_Impl_rbt_all p (Branch c l k v r) =
  p k v && rBT_Impl_rbt_all p l && rBT_Impl_rbt_all p r;

alla :: forall a b. (Ccompare a) => (a -> b -> Bool) -> Mapping_rbt a b -> Bool;
alla xb xc = rBT_Impl_rbt_all xb (impl_ofa xc);

ball :: forall a. (Ceq a, Ccompare a) => Set a -> (a -> Bool) -> Bool;
ball (RBT_set rbt) p =
  (case (ccompare :: Maybe (a -> a -> Ordera)) of {
    Nothing ->
      (error :: forall a. String -> (() -> a) -> a)
        "Ball RBT_set: ccompare = None" (\ _ -> ball (RBT_set rbt) p);
    Just _ -> alla (\ k _ -> p k) rbt;
  });
ball (DList_set dxs) p =
  (case (ceq :: Maybe (a -> a -> Bool)) of {
    Nothing ->
      (error :: forall a. String -> (() -> a) -> a) "Ball DList_set: ceq = None"
        (\ _ -> ball (DList_set dxs) p);
    Just _ -> dlist_all p dxs;
  });
ball (Set_Monad xs) p = all p xs;

drop :: forall a. Nat -> [a] -> [a];
drop n [] = [];
drop n (x : xs) =
  (if equal_nat n zero_nat then x : xs else drop (minus_nat n one_nat) xs);

take :: forall a. Nat -> [a] -> [a];
take n [] = [];
take n (x : xs) =
  (if equal_nat n zero_nat then [] else x : take (minus_nat n one_nat) xs);

foldl :: forall a b. (a -> b -> a) -> a -> [b] -> a;
foldl f a [] = a;
foldl f a (x : xs) = foldl f (f a x) xs;

foldr :: forall a b. (a -> b -> b) -> [a] -> b -> b;
foldr f [] = id;
foldr f (x : xs) = f x . foldr f xs;

map_of :: forall a b. (Eq a) => [(a, b)] -> a -> Maybe b;
map_of [] k = Nothing;
map_of ((l, v) : ps) k = (if l == k then Just v else map_of ps k);

fun_upd :: forall a b. (a -> a -> Bool) -> (a -> b) -> a -> b -> a -> b;
fun_upd equal f aa b a = (if equal aa a then b else f a);

balance :: forall a b. Rbt a b -> a -> b -> Rbt a b -> Rbt a b;
balance (Branch R a w x b) s t (Branch R c y z d) =
  Branch R (Branch B a w x b) s t (Branch B c y z d);
balance (Branch R (Branch R a w x b) s t c) y z Empty =
  Branch R (Branch B a w x b) s t (Branch B c y z Empty);
balance (Branch R (Branch R a w x b) s t c) y z (Branch B va vb vc vd) =
  Branch R (Branch B a w x b) s t (Branch B c y z (Branch B va vb vc vd));
balance (Branch R Empty w x (Branch R b s t c)) y z Empty =
  Branch R (Branch B Empty w x b) s t (Branch B c y z Empty);
balance (Branch R (Branch B va vb vc vd) w x (Branch R b s t c)) y z Empty =
  Branch R (Branch B (Branch B va vb vc vd) w x b) s t (Branch B c y z Empty);
balance (Branch R Empty w x (Branch R b s t c)) y z (Branch B va vb vc vd) =
  Branch R (Branch B Empty w x b) s t (Branch B c y z (Branch B va vb vc vd));
balance (Branch R (Branch B ve vf vg vh) w x (Branch R b s t c)) y z
  (Branch B va vb vc vd) =
  Branch R (Branch B (Branch B ve vf vg vh) w x b) s t
    (Branch B c y z (Branch B va vb vc vd));
balance Empty w x (Branch R b s t (Branch R c y z d)) =
  Branch R (Branch B Empty w x b) s t (Branch B c y z d);
balance (Branch B va vb vc vd) w x (Branch R b s t (Branch R c y z d)) =
  Branch R (Branch B (Branch B va vb vc vd) w x b) s t (Branch B c y z d);
balance Empty w x (Branch R (Branch R b s t c) y z Empty) =
  Branch R (Branch B Empty w x b) s t (Branch B c y z Empty);
balance Empty w x (Branch R (Branch R b s t c) y z (Branch B va vb vc vd)) =
  Branch R (Branch B Empty w x b) s t (Branch B c y z (Branch B va vb vc vd));
balance (Branch B va vb vc vd) w x (Branch R (Branch R b s t c) y z Empty) =
  Branch R (Branch B (Branch B va vb vc vd) w x b) s t (Branch B c y z Empty);
balance (Branch B va vb vc vd) w x
  (Branch R (Branch R b s t c) y z (Branch B ve vf vg vh)) =
  Branch R (Branch B (Branch B va vb vc vd) w x b) s t
    (Branch B c y z (Branch B ve vf vg vh));
balance Empty s t Empty = Branch B Empty s t Empty;
balance Empty s t (Branch B va vb vc vd) =
  Branch B Empty s t (Branch B va vb vc vd);
balance Empty s t (Branch v Empty vb vc Empty) =
  Branch B Empty s t (Branch v Empty vb vc Empty);
balance Empty s t (Branch v (Branch B ve vf vg vh) vb vc Empty) =
  Branch B Empty s t (Branch v (Branch B ve vf vg vh) vb vc Empty);
balance Empty s t (Branch v Empty vb vc (Branch B vf vg vh vi)) =
  Branch B Empty s t (Branch v Empty vb vc (Branch B vf vg vh vi));
balance Empty s t (Branch v (Branch B ve vj vk vl) vb vc (Branch B vf vg vh vi))
  = Branch B Empty s t
      (Branch v (Branch B ve vj vk vl) vb vc (Branch B vf vg vh vi));
balance (Branch B va vb vc vd) s t Empty =
  Branch B (Branch B va vb vc vd) s t Empty;
balance (Branch B va vb vc vd) s t (Branch B ve vf vg vh) =
  Branch B (Branch B va vb vc vd) s t (Branch B ve vf vg vh);
balance (Branch B va vb vc vd) s t (Branch v Empty vf vg Empty) =
  Branch B (Branch B va vb vc vd) s t (Branch v Empty vf vg Empty);
balance (Branch B va vb vc vd) s t (Branch v (Branch B vi vj vk vl) vf vg Empty)
  = Branch B (Branch B va vb vc vd) s t
      (Branch v (Branch B vi vj vk vl) vf vg Empty);
balance (Branch B va vb vc vd) s t (Branch v Empty vf vg (Branch B vj vk vl vm))
  = Branch B (Branch B va vb vc vd) s t
      (Branch v Empty vf vg (Branch B vj vk vl vm));
balance (Branch B va vb vc vd) s t
  (Branch v (Branch B vi vn vo vp) vf vg (Branch B vj vk vl vm)) =
  Branch B (Branch B va vb vc vd) s t
    (Branch v (Branch B vi vn vo vp) vf vg (Branch B vj vk vl vm));
balance (Branch v Empty vb vc Empty) s t Empty =
  Branch B (Branch v Empty vb vc Empty) s t Empty;
balance (Branch v Empty vb vc (Branch B ve vf vg vh)) s t Empty =
  Branch B (Branch v Empty vb vc (Branch B ve vf vg vh)) s t Empty;
balance (Branch v (Branch B vf vg vh vi) vb vc Empty) s t Empty =
  Branch B (Branch v (Branch B vf vg vh vi) vb vc Empty) s t Empty;
balance (Branch v (Branch B vf vg vh vi) vb vc (Branch B ve vj vk vl)) s t Empty
  = Branch B (Branch v (Branch B vf vg vh vi) vb vc (Branch B ve vj vk vl)) s t
      Empty;
balance (Branch v Empty vf vg Empty) s t (Branch B va vb vc vd) =
  Branch B (Branch v Empty vf vg Empty) s t (Branch B va vb vc vd);
balance (Branch v Empty vf vg (Branch B vi vj vk vl)) s t (Branch B va vb vc vd)
  = Branch B (Branch v Empty vf vg (Branch B vi vj vk vl)) s t
      (Branch B va vb vc vd);
balance (Branch v (Branch B vj vk vl vm) vf vg Empty) s t (Branch B va vb vc vd)
  = Branch B (Branch v (Branch B vj vk vl vm) vf vg Empty) s t
      (Branch B va vb vc vd);
balance (Branch v (Branch B vj vk vl vm) vf vg (Branch B vi vn vo vp)) s t
  (Branch B va vb vc vd) =
  Branch B (Branch v (Branch B vj vk vl vm) vf vg (Branch B vi vn vo vp)) s t
    (Branch B va vb vc vd);

rbt_comp_ins ::
  forall a b.
    (a -> a -> Ordera) -> (a -> b -> b -> b) -> a -> b -> Rbt a b -> Rbt a b;
rbt_comp_ins c f k v Empty = Branch R Empty k v Empty;
rbt_comp_ins c f k v (Branch B l x y r) =
  (case c k x of {
    Eqa -> Branch B l x (f k y v) r;
    Lt -> balance (rbt_comp_ins c f k v l) x y r;
    Gt -> balance l x y (rbt_comp_ins c f k v r);
  });
rbt_comp_ins c f k v (Branch R l x y r) =
  (case c k x of {
    Eqa -> Branch R l x (f k y v) r;
    Lt -> Branch R (rbt_comp_ins c f k v l) x y r;
    Gt -> Branch R l x y (rbt_comp_ins c f k v r);
  });

paint :: forall a b. Color -> Rbt a b -> Rbt a b;
paint c Empty = Empty;
paint c (Branch uu l k v r) = Branch c l k v r;

rbt_comp_insert_with_key ::
  forall a b.
    (a -> a -> Ordera) -> (a -> b -> b -> b) -> a -> b -> Rbt a b -> Rbt a b;
rbt_comp_insert_with_key c f k v t = paint B (rbt_comp_ins c f k v t);

rbt_comp_insert ::
  forall a b. (a -> a -> Ordera) -> a -> b -> Rbt a b -> Rbt a b;
rbt_comp_insert c = rbt_comp_insert_with_key c (\ _ _ nv -> nv);

the :: forall a. Maybe a -> a;
the (Just x2) = x2;

insertb ::
  forall a b. (Ccompare a) => a -> b -> Mapping_rbt a b -> Mapping_rbt a b;
insertb xc xd xe =
  Mapping_RBTa (rbt_comp_insert (the ccompare) xc xd (impl_ofa xe));

list_member :: forall a. (a -> a -> Bool) -> [a] -> a -> Bool;
list_member equal [] y = False;
list_member equal (x : xs) y = equal x y || list_member equal xs y;

list_insert :: forall a. (a -> a -> Bool) -> a -> [a] -> [a];
list_insert equal x xs = (if list_member equal xs x then xs else x : xs);

inserta :: forall a. (Ceq a) => a -> Set_dlist a -> Set_dlist a;
inserta xb xc = Abs_dlist (list_insert (the ceq) xb (list_of_dlist xc));

balance_right :: forall a b. Rbt a b -> a -> b -> Rbt a b -> Rbt a b;
balance_right a k x (Branch R b s y c) = Branch R a k x (Branch B b s y c);
balance_right (Branch B a k x b) s y Empty =
  balance (Branch R a k x b) s y Empty;
balance_right (Branch B a k x b) s y (Branch B va vb vc vd) =
  balance (Branch R a k x b) s y (Branch B va vb vc vd);
balance_right (Branch R a k x (Branch B b s y c)) t z Empty =
  Branch R (balance (paint R a) k x b) s y (Branch B c t z Empty);
balance_right (Branch R a k x (Branch B b s y c)) t z (Branch B va vb vc vd) =
  Branch R (balance (paint R a) k x b) s y
    (Branch B c t z (Branch B va vb vc vd));
balance_right Empty k x Empty = Empty;
balance_right (Branch R va vb vc Empty) k x Empty = Empty;
balance_right (Branch R va vb vc (Branch R ve vf vg vh)) k x Empty = Empty;
balance_right Empty k x (Branch B va vb vc vd) = Empty;
balance_right (Branch R ve vf vg Empty) k x (Branch B va vb vc vd) = Empty;
balance_right (Branch R ve vf vg (Branch R vi vj vk vl)) k x
  (Branch B va vb vc vd) = Empty;

balance_left :: forall a b. Rbt a b -> a -> b -> Rbt a b -> Rbt a b;
balance_left (Branch R a k x b) s y c = Branch R (Branch B a k x b) s y c;
balance_left Empty k x (Branch B a s y b) =
  balance Empty k x (Branch R a s y b);
balance_left (Branch B va vb vc vd) k x (Branch B a s y b) =
  balance (Branch B va vb vc vd) k x (Branch R a s y b);
balance_left Empty k x (Branch R (Branch B a s y b) t z c) =
  Branch R (Branch B Empty k x a) s y (balance b t z (paint R c));
balance_left (Branch B va vb vc vd) k x (Branch R (Branch B a s y b) t z c) =
  Branch R (Branch B (Branch B va vb vc vd) k x a) s y
    (balance b t z (paint R c));
balance_left Empty k x Empty = Empty;
balance_left Empty k x (Branch R Empty vb vc vd) = Empty;
balance_left Empty k x (Branch R (Branch R ve vf vg vh) vb vc vd) = Empty;
balance_left (Branch B va vb vc vd) k x Empty = Empty;
balance_left (Branch B va vb vc vd) k x (Branch R Empty vf vg vh) = Empty;
balance_left (Branch B va vb vc vd) k x
  (Branch R (Branch R vi vj vk vl) vf vg vh) = Empty;

combine :: forall a b. Rbt a b -> Rbt a b -> Rbt a b;
combine Empty x = x;
combine (Branch v va vb vc vd) Empty = Branch v va vb vc vd;
combine (Branch R a k x b) (Branch R c s y d) =
  (case combine b c of {
    Empty -> Branch R a k x (Branch R Empty s y d);
    Branch R b2 t z c2 -> Branch R (Branch R a k x b2) t z (Branch R c2 s y d);
    Branch B b2 t z c2 -> Branch R a k x (Branch R (Branch B b2 t z c2) s y d);
  });
combine (Branch B a k x b) (Branch B c s y d) =
  (case combine b c of {
    Empty -> balance_left a k x (Branch B Empty s y d);
    Branch R b2 t z c2 -> Branch R (Branch B a k x b2) t z (Branch B c2 s y d);
    Branch B b2 t z c2 ->
      balance_left a k x (Branch B (Branch B b2 t z c2) s y d);
  });
combine (Branch B va vb vc vd) (Branch R b k x c) =
  Branch R (combine (Branch B va vb vc vd) b) k x c;
combine (Branch R a k x b) (Branch B va vb vc vd) =
  Branch R a k x (combine b (Branch B va vb vc vd));

rbt_comp_del :: forall a b. (a -> a -> Ordera) -> a -> Rbt a b -> Rbt a b;
rbt_comp_del c x Empty = Empty;
rbt_comp_del c x (Branch uu a y s b) =
  (case c x y of {
    Eqa -> combine a b;
    Lt -> rbt_comp_del_from_left c x a y s b;
    Gt -> rbt_comp_del_from_right c x a y s b;
  });

rbt_comp_del_from_left ::
  forall a b.
    (a -> a -> Ordera) -> a -> Rbt a b -> a -> b -> Rbt a b -> Rbt a b;
rbt_comp_del_from_left c x (Branch B lt z v rt) y s b =
  balance_left (rbt_comp_del c x (Branch B lt z v rt)) y s b;
rbt_comp_del_from_left c x Empty y s b =
  Branch R (rbt_comp_del c x Empty) y s b;
rbt_comp_del_from_left c x (Branch R va vb vc vd) y s b =
  Branch R (rbt_comp_del c x (Branch R va vb vc vd)) y s b;

rbt_comp_del_from_right ::
  forall a b.
    (a -> a -> Ordera) -> a -> Rbt a b -> a -> b -> Rbt a b -> Rbt a b;
rbt_comp_del_from_right c x a y s (Branch B lt z v rt) =
  balance_right a y s (rbt_comp_del c x (Branch B lt z v rt));
rbt_comp_del_from_right c x a y s Empty =
  Branch R a y s (rbt_comp_del c x Empty);
rbt_comp_del_from_right c x a y s (Branch R va vb vc vd) =
  Branch R a y s (rbt_comp_del c x (Branch R va vb vc vd));

rbt_comp_delete :: forall a b. (a -> a -> Ordera) -> a -> Rbt a b -> Rbt a b;
rbt_comp_delete c k t = paint B (rbt_comp_del c k t);

delete :: forall a b. (Ccompare a) => a -> Mapping_rbt a b -> Mapping_rbt a b;
delete xb xc = Mapping_RBTa (rbt_comp_delete (the ccompare) xb (impl_ofa xc));

list_remove1 :: forall a. (a -> a -> Bool) -> a -> [a] -> [a];
list_remove1 equal x [] = [];
list_remove1 equal x (y : xs) =
  (if equal x y then xs else y : list_remove1 equal x xs);

removea :: forall a. (Ceq a) => a -> Set_dlist a -> Set_dlist a;
removea xb xc = Abs_dlist (list_remove1 (the ceq) xb (list_of_dlist xc));

insert :: forall a. (Ceq a, Ccompare a) => a -> Set a -> Set a;
insert xa (Complement x) = Complement (remove xa x);
insert x (RBT_set rbt) =
  (case (ccompare :: Maybe (a -> a -> Ordera)) of {
    Nothing ->
      (error :: forall a. String -> (() -> a) -> a)
        "insert RBT_set: ccompare = None" (\ _ -> insert x (RBT_set rbt));
    Just _ -> RBT_set (insertb x () rbt);
  });
insert x (DList_set dxs) =
  (case (ceq :: Maybe (a -> a -> Bool)) of {
    Nothing ->
      (error :: forall a. String -> (() -> a) -> a)
        "insert DList_set: ceq = None" (\ _ -> insert x (DList_set dxs));
    Just _ -> DList_set (inserta x dxs);
  });
insert x (Set_Monad xs) = Set_Monad (x : xs);
insert x (Collect_set a) =
  (case ceq of {
    Nothing ->
      (error :: forall a. String -> (() -> a) -> a)
        "insert Collect_set: ceq = None" (\ _ -> insert x (Collect_set a));
    Just eq -> Collect_set (fun_upd eq a x True);
  });

remove :: forall a. (Ceq a, Ccompare a) => a -> Set a -> Set a;
remove x (Complement a) = Complement (insert x a);
remove x (RBT_set rbt) =
  (case (ccompare :: Maybe (a -> a -> Ordera)) of {
    Nothing ->
      (error :: forall a. String -> (() -> a) -> a)
        "remove RBT_set: ccompare = None" (\ _ -> remove x (RBT_set rbt));
    Just _ -> RBT_set (delete x rbt);
  });
remove x (DList_set dxs) =
  (case (ceq :: Maybe (a -> a -> Bool)) of {
    Nothing ->
      (error :: forall a. String -> (() -> a) -> a)
        "remove DList_set: ceq = None" (\ _ -> remove x (DList_set dxs));
    Just _ -> DList_set (removea x dxs);
  });
remove x (Collect_set a) =
  (case ceq of {
    Nothing ->
      (error :: forall a. String -> (() -> a) -> a) "remove Collect: ceq = None"
        (\ _ -> remove x (Collect_set a));
    Just eq -> Collect_set (fun_upd eq a x False);
  });

memberc :: forall a. (Ceq a) => Set_dlist a -> a -> Bool;
memberc xa = list_member (the ceq) (list_of_dlist xa);

rbt_comp_lookup :: forall a b. (a -> a -> Ordera) -> Rbt a b -> a -> Maybe b;
rbt_comp_lookup c Empty k = Nothing;
rbt_comp_lookup c (Branch uu l x y r) k = (case c k x of {
    Eqa -> Just y;
    Lt -> rbt_comp_lookup c l k;
    Gt -> rbt_comp_lookup c r k;
  });

lookupb :: forall a b. (Ccompare a) => Mapping_rbt a b -> a -> Maybe b;
lookupb xa = rbt_comp_lookup (the ccompare) (impl_ofa xa);

memberb :: forall a. (Ccompare a) => Mapping_rbt a () -> a -> Bool;
memberb t x = lookupb t x == Just ();

member :: forall a. (Ceq a, Ccompare a) => a -> Set a -> Bool;
member x (Set_Monad xs) =
  (case ceq of {
    Nothing ->
      (error :: forall a. String -> (() -> a) -> a)
        "member Set_Monad: ceq = None" (\ _ -> member x (Set_Monad xs));
    Just eq -> list_member eq xs x;
  });
member xa (Complement x) = not (member xa x);
member x (RBT_set rbt) = memberb rbt x;
member x (DList_set dxs) = memberc dxs x;
member x (Collect_set a) = a x;

bind2 ::
  forall a b c d.
    Sum_bot a b -> (a -> Sum_bot c d) -> (b -> Sum_bot c d) -> Sum_bot c d;
bind2 (Sumbot a) f g = (case a of {
                         Inl aa -> f aa;
                         Inr aa -> g aa;
                       });

membera :: forall a. (Eq a) => [a] -> a -> Bool;
membera [] y = False;
membera (x : xs) y = x == y || membera xs y;

ground :: forall a b. Term a b -> Bool;
ground (Var x) = False;
ground (Fun f ts) = all ground ts;

char_0x7A :: Char;
char_0x7A = Chr (122 :: Integer);

char_0x79 :: Char;
char_0x79 = Chr (121 :: Integer);

char_0x78 :: Char;
char_0x78 = Chr (120 :: Integer);

char_0x77 :: Char;
char_0x77 = Chr (119 :: Integer);

char_0x76 :: Char;
char_0x76 = Chr (118 :: Integer);

char_0x75 :: Char;
char_0x75 = Chr (117 :: Integer);

char_0x74 :: Char;
char_0x74 = Chr (116 :: Integer);

char_0x73 :: Char;
char_0x73 = Chr (115 :: Integer);

char_0x72 :: Char;
char_0x72 = Chr (114 :: Integer);

char_0x71 :: Char;
char_0x71 = Chr (113 :: Integer);

char_0x70 :: Char;
char_0x70 = Chr (112 :: Integer);

char_0x6F :: Char;
char_0x6F = Chr (111 :: Integer);

char_0x6E :: Char;
char_0x6E = Chr (110 :: Integer);

char_0x6D :: Char;
char_0x6D = Chr (109 :: Integer);

char_0x6C :: Char;
char_0x6C = Chr (108 :: Integer);

char_0x6B :: Char;
char_0x6B = Chr (107 :: Integer);

char_0x6A :: Char;
char_0x6A = Chr (106 :: Integer);

char_0x69 :: Char;
char_0x69 = Chr (105 :: Integer);

char_0x68 :: Char;
char_0x68 = Chr (104 :: Integer);

char_0x67 :: Char;
char_0x67 = Chr (103 :: Integer);

char_0x66 :: Char;
char_0x66 = Chr (102 :: Integer);

char_0x65 :: Char;
char_0x65 = Chr (101 :: Integer);

char_0x64 :: Char;
char_0x64 = Chr (100 :: Integer);

char_0x63 :: Char;
char_0x63 = Chr (99 :: Integer);

char_0x62 :: Char;
char_0x62 = Chr (98 :: Integer);

char_0x61 :: Char;
char_0x61 = Chr (97 :: Integer);

char_0x5F :: Char;
char_0x5F = Chr (95 :: Integer);

char_0x5A :: Char;
char_0x5A = Chr (90 :: Integer);

char_0x59 :: Char;
char_0x59 = Chr (89 :: Integer);

char_0x58 :: Char;
char_0x58 = Chr (88 :: Integer);

char_0x57 :: Char;
char_0x57 = Chr (87 :: Integer);

char_0x56 :: Char;
char_0x56 = Chr (86 :: Integer);

char_0x55 :: Char;
char_0x55 = Chr (85 :: Integer);

char_0x54 :: Char;
char_0x54 = Chr (84 :: Integer);

char_0x53 :: Char;
char_0x53 = Chr (83 :: Integer);

char_0x52 :: Char;
char_0x52 = Chr (82 :: Integer);

char_0x51 :: Char;
char_0x51 = Chr (81 :: Integer);

char_0x50 :: Char;
char_0x50 = Chr (80 :: Integer);

char_0x4F :: Char;
char_0x4F = Chr (79 :: Integer);

char_0x4E :: Char;
char_0x4E = Chr (78 :: Integer);

char_0x4D :: Char;
char_0x4D = Chr (77 :: Integer);

char_0x4C :: Char;
char_0x4C = Chr (76 :: Integer);

char_0x4B :: Char;
char_0x4B = Chr (75 :: Integer);

char_0x4A :: Char;
char_0x4A = Chr (74 :: Integer);

char_0x49 :: Char;
char_0x49 = Chr (73 :: Integer);

char_0x48 :: Char;
char_0x48 = Chr (72 :: Integer);

char_0x47 :: Char;
char_0x47 = Chr (71 :: Integer);

char_0x46 :: Char;
char_0x46 = Chr (70 :: Integer);

char_0x45 :: Char;
char_0x45 = Chr (69 :: Integer);

char_0x44 :: Char;
char_0x44 = Chr (68 :: Integer);

char_0x43 :: Char;
char_0x43 = Chr (67 :: Integer);

char_0x42 :: Char;
char_0x42 = Chr (66 :: Integer);

char_0x41 :: Char;
char_0x41 = Chr (65 :: Integer);

char_0x3B :: Char;
char_0x3B = Chr (59 :: Integer);

char_0x3A :: Char;
char_0x3A = Chr (58 :: Integer);

char_0x39 :: Char;
char_0x39 = Chr (57 :: Integer);

char_0x38 :: Char;
char_0x38 = Chr (56 :: Integer);

char_0x37 :: Char;
char_0x37 = Chr (55 :: Integer);

char_0x36 :: Char;
char_0x36 = Chr (54 :: Integer);

char_0x35 :: Char;
char_0x35 = Chr (53 :: Integer);

char_0x34 :: Char;
char_0x34 = Chr (52 :: Integer);

char_0x33 :: Char;
char_0x33 = Chr (51 :: Integer);

char_0x32 :: Char;
char_0x32 = Chr (50 :: Integer);

char_0x31 :: Char;
char_0x31 = Chr (49 :: Integer);

char_0x30 :: Char;
char_0x30 = Chr (48 :: Integer);

char_0x2D :: Char;
char_0x2D = Chr (45 :: Integer);

char_0x26 :: Char;
char_0x26 = Chr (38 :: Integer);

letters :: [Char];
letters =
  [char_0x61, char_0x62, char_0x63, char_0x64, char_0x65, char_0x66, char_0x67,
    char_0x68, char_0x69, char_0x6A, char_0x6B, char_0x6C, char_0x6D, char_0x6E,
    char_0x6F, char_0x70, char_0x71, char_0x72, char_0x73, char_0x74, char_0x75,
    char_0x76, char_0x77, char_0x78, char_0x79, char_0x7A, char_0x41, char_0x42,
    char_0x43, char_0x44, char_0x45, char_0x46, char_0x47, char_0x48, char_0x49,
    char_0x4A, char_0x4B, char_0x4C, char_0x4D, char_0x4E, char_0x4F, char_0x50,
    char_0x51, char_0x52, char_0x53, char_0x54, char_0x55, char_0x56, char_0x57,
    char_0x58, char_0x59, char_0x5A, char_0x5F, char_0x30, char_0x31, char_0x32,
    char_0x33, char_0x34, char_0x35, char_0x36, char_0x37, char_0x38, char_0x39,
    char_0x26, char_0x3B, char_0x3A, char_0x2D];

apsnd :: forall a b c. (a -> b) -> (c, a) -> (c, b);
apsnd f (x, y) = (x, f y);

divmod_integer :: Integer -> Integer -> (Integer, Integer);
divmod_integer k l =
  (if k == (0 :: Integer) then ((0 :: Integer), (0 :: Integer))
    else (if (0 :: Integer) < l
           then (if (0 :: Integer) < k then divMod ( k ) ( l )
                  else (case divMod ( (negate k) ) ( l ) of {
                         (r, s) ->
                           (if s == (0 :: Integer)
                             then (negate r, (0 :: Integer))
                             else (negate r - (1 :: Integer), l - s));
                       }))
           else (if l == (0 :: Integer) then ((0 :: Integer), k)
                  else apsnd negate
                         (if k < (0 :: Integer)
                           then divMod ( (negate k) ) ( (negate l) )
                           else (case divMod ( k ) ( (negate l) ) of {
                                  (r, s) ->
                                    (if s == (0 :: Integer)
                                      then (negate r, (0 :: Integer))
                                      else (negate r - (1 :: Integer),
     negate l - s));
                                })))));

modulo_integer :: Integer -> Integer -> Integer;
modulo_integer k l = snd (divmod_integer k l);

char_of_integer :: Integer -> Char;
char_of_integer k =
  Chr (if (0 :: Integer) <= k && k < (256 :: Integer) then k
        else modulo_integer k (256 :: Integer));

explode :: String -> [Char];
explode s = map char_of_integer (Str_Literal.asciisOfLiteral s);

left :: forall a b. a -> Sum_bot a b;
left x = Sumbot (Inl x);

xml_error ::
  forall a b c d.
    String -> ([Xml], (a, (b, (c, [String])))) -> Sum_bot (Xml_error String) d;
xml_error str x =
  (case x of {
    (xmls, (_, (_, (_, pos)))) ->
      let {
        next =
          (case xmls of {
            [] -> "tag close";
            XML tag _ _ : _ -> ("<" ++ implode tag) ++ ">";
            XML_text stra : _ -> ("text element \"" ++ implode stra) ++ "\"";
          });
      } in left (Fatal
                  ((((("parse error on " ++ next) ++ " at ") ++
                      default_showsl_list showsl_lit pos "") ++
                     ":\n") ++
                    str));
  });

mismatch ::
  forall a b.
    String ->
      ([Xml], (a, (Bool, ([String], [String])))) ->
        Sum_bot (Xml_error String) b;
mismatch tag x =
  (case x of {
    (_, (_, (True, (cands, _)))) -> left (TagMismatch (tag : cands));
    (_, (_, (False, (cands, _)))) ->
      xml_error
        ("expecting " ++ default_showsl_list showsl_lit (tag : cands) "") x;
  });

xml_do ::
  forall a.
    String ->
      (([Xml], ([([Char], [Char])], (Bool, ([String], [String])))) ->
        Sum_bot (Xml_error String) a) ->
        (Xml, ([([Char], [Char])], (Bool, ([String], [String])))) ->
          Sum_bot (Xml_error String) a;
xml_do tag p x =
  (case x of {
    (XML nam atts xmls, (_, (_, (_, pos)))) ->
      (if nam == explode tag then p (xmls, (atts, (False, ([], tag : pos))))
        else mismatch tag ([fst x], snd x));
    (XML_text _, _) -> mismatch tag ([fst x], snd x);
  });

right :: forall a b. a -> Sum_bot b a;
right x = Sumbot (Inr x);

xml_or ::
  forall a b c d e f g.
    ((a, (b, (Bool, (c, d)))) -> Sum_bot (Xml_error e) f) ->
      ((a, (b, (g, ([String], d)))) -> Sum_bot (Xml_error e) f) ->
        (a, (b, (g, (c, d)))) -> Sum_bot (Xml_error e) f;
xml_or p1 p2 x =
  (case x of {
    (x1, (atts, (flag, (cands, rest)))) ->
      bind2 (p1 (x1, (atts, (True, (cands, rest)))))
        (\ a ->
          (case a of {
            TagMismatch cands1 -> p2 (x1, (atts, (flag, (cands1, rest))));
            Fatal aa -> left (Fatal aa);
          }))
        right;
  });

empty :: forall a b. Alist a b;
empty = Alist [];

hd :: forall a. [a] -> a;
hd (x21 : x22) = x21;

tl :: forall a. [a] -> [a];
tl [] = [];
tl (x21 : x22) = x22;

times_nat :: Nat -> Nat -> Nat;
times_nat m n = Nat (integer_of_nat m * integer_of_nat n);

nat_of_integer :: Integer -> Nat;
nat_of_integer k = Nat (max (0 :: Integer) k);

nat_of_digit :: Char -> Maybe Nat;
nat_of_digit x =
  (if equal_char x char_0x30 then Just zero_nat
    else (if equal_char x char_0x31 then Just one_nat
           else (if equal_char x char_0x32
                  then Just (nat_of_integer (2 :: Integer))
                  else (if equal_char x char_0x33
                         then Just (nat_of_integer (3 :: Integer))
                         else (if equal_char x char_0x34
                                then Just (nat_of_integer (4 :: Integer))
                                else (if equal_char x char_0x35
                                       then Just (nat_of_integer (5 :: Integer))
                                       else (if equal_char x char_0x36
      then Just (nat_of_integer (6 :: Integer))
      else (if equal_char x char_0x37 then Just (nat_of_integer (7 :: Integer))
             else (if equal_char x char_0x38
                    then Just (nat_of_integer (8 :: Integer))
                    else (if equal_char x char_0x39
                           then Just (nat_of_integer (9 :: Integer))
                           else Nothing))))))))));

obind :: forall a b. Maybe a -> (a -> Maybe b) -> Maybe b;
obind opt f = (case opt of {
                Nothing -> Nothing;
                Just a -> f a;
              });

nat_of_string_aux :: Nat -> [Char] -> Maybe Nat;
nat_of_string_aux n [] = Just n;
nat_of_string_aux n (d : s) =
  obind (nat_of_digit d)
    (\ m ->
      nat_of_string_aux
        (plus_nat (times_nat (nat_of_integer (10 :: Integer)) n) m) s);

nat_of_string :: [Char] -> Sum String Nat;
nat_of_string s =
  (case (if null s then Nothing else nat_of_string_aux zero_nat s) of {
    Nothing -> Inl (("cannot convert \"" ++ implode s) ++ "\" to a number");
    Just a -> Inr a;
  });

xml_take_nat ::
  forall a.
    (Nat ->
      ([Xml], ([([Char], [Char])], (Bool, ([String], [String])))) ->
        Sum_bot (Xml_error String) a) ->
      ([Xml], ([([Char], [Char])], (Bool, ([String], [String])))) ->
        Sum_bot (Xml_error String) a;
xml_take_nat p xs =
  (case xs of {
    ([], _) -> xml_error "expecting a number" xs;
    (XML _ _ _ : _, _) -> xml_error "expecting a number" xs;
    (XML_text text : xmls, s) -> (case nat_of_string text of {
                                   Inl x -> xml_error x xs;
                                   Inr n -> p n (xmls, s);
                                 });
  });

xml_return ::
  forall a.
    a -> ([Xml], ([([Char], [Char])], (Bool, ([String], [String])))) ->
           Sum_bot (Xml_error String) a;
xml_return v x = (case x of {
                   ([], _) -> right v;
                   (_ : _, _) -> xml_error "expecting tag close" x;
                 });

xml_nat ::
  String ->
    (Xml, ([([Char], [Char])], (Bool, ([String], [String])))) ->
      Sum_bot (Xml_error String) Nat;
xml_nat tag = xml_do tag (xml_take_nat xml_return);

impl_of :: forall b a. Alist b a -> [(b, a)];
impl_of (Alist x) = x;

lookup :: forall a b. (Eq a) => Alist a b -> a -> Maybe b;
lookup xa = map_of (impl_of xa);

distinct :: forall a. (Eq a) => [a] -> Bool;
distinct [] = True;
distinct (x : xs) = not (membera xs x) && distinct xs;

of_phantom :: forall a b. Phantom a b -> b;
of_phantom (Phantom x) = x;

emptyb :: forall a b. (Ccompare a) => Mapping_rbt a b;
emptyb = Mapping_RBTa Empty;

emptya :: forall a. (Ceq a) => Set_dlist a;
emptya = Abs_dlist [];

set_empty_choose :: forall a. (Ceq a, Ccompare a) => Set a;
set_empty_choose = (case (ccompare :: Maybe (a -> a -> Ordera)) of {
                     Nothing -> (case (ceq :: Maybe (a -> a -> Bool)) of {
                                  Nothing -> Set_Monad [];
                                  Just _ -> DList_set emptya;
                                });
                     Just _ -> RBT_set emptyb;
                   });

set_empty :: forall a. (Ceq a, Ccompare a) => Set_impla -> Set a;
set_empty Set_Collect = Collect_set (\ _ -> False);
set_empty Set_DList = DList_set emptya;
set_empty Set_RBT = RBT_set emptyb;
set_empty Set_Monada = Set_Monad [];
set_empty Set_Choose = set_empty_choose;

set_aux :: forall a. (Ceq a, Ccompare a) => Set_impla -> [a] -> Set a;
set_aux Set_Monada = Set_Monad;
set_aux Set_Choose =
  (case (ccompare :: Maybe (a -> a -> Ordera)) of {
    Nothing -> (case (ceq :: Maybe (a -> a -> Bool)) of {
                 Nothing -> Set_Monad;
                 Just _ -> foldl (\ s x -> insert x s) (DList_set emptya);
               });
    Just _ -> foldl (\ s x -> insert x s) (RBT_set emptyb);
  });
set_aux impl = foldl (\ s x -> insert x s) (set_empty impl);

set :: forall a. (Ceq a, Ccompare a, Set_impl a) => [a] -> Set a;
set xs = set_aux (of_phantom (set_impl :: Phantom a Set_impla)) xs;

is_letter :: Char -> Bool;
is_letter c =
  let {
    ci = integer_of_char c;
  } in (97 :: Integer) <= ci && ci <= (122 :: Integer) ||
         ((65 :: Integer) <= ci && ci <= (90 :: Integer) ||
           ((48 :: Integer) <= ci && ci <= (59 :: Integer) ||
             (ci == (95 :: Integer) ||
               (ci == (38 :: Integer) || ci == (45 :: Integer)))));

update_tokens :: forall a. ([a] -> [a]) -> [a] -> Sum [Char] ([a], [a]);
update_tokens f ts = Inr (ts, f ts);

char_0x3C :: Char;
char_0x3C = Chr (60 :: Integer);

char_0x21 :: Char;
char_0x21 = Chr (33 :: Integer);

comment_error :: () -> [Char];
comment_error x =
  (error :: forall a. String -> (() -> a) -> a) "comment not terminated"
    (\ _ -> []);

comment_error_hyphen :: () -> [Char];
comment_error_hyphen x =
  (error :: forall a. String -> (() -> a) -> a) "double hyphen within comment"
    (\ _ -> []);

rc_open_1 :: [Char] -> [Char];
rc_open_1 [] = [];
rc_open_1 (c : cs) =
  (if integer_of_char c == (60 :: Integer) then rc_open_2 cs
    else c : rc_open_1 cs);

rc_close_3 :: [Char] -> [Char];
rc_close_3 [] = comment_error ();
rc_close_3 (c : cs) =
  (if integer_of_char c == (62 :: Integer) then rc_open_1 cs
    else comment_error_hyphen ());

rc_close_2 :: [Char] -> [Char];
rc_close_2 [] = comment_error ();
rc_close_2 (c : cs) =
  (if integer_of_char c == (45 :: Integer) then rc_close_3 cs
    else rc_close_1 cs);

rc_close_1 :: [Char] -> [Char];
rc_close_1 [] = comment_error ();
rc_close_1 (c : cs) =
  (if integer_of_char c == (45 :: Integer) then rc_close_2 cs
    else rc_close_1 cs);

rc_open_4 :: [Char] -> [Char];
rc_open_4 [] = [char_0x3C, char_0x21, char_0x2D];
rc_open_4 (c : cs) =
  let {
    ic = integer_of_char c;
  } in (if ic == (45 :: Integer) then rc_close_1 cs
         else (if ic == (60 :: Integer)
                then c : char_0x21 : char_0x2D : rc_open_2 cs
                else char_0x3C : char_0x21 : char_0x2D : c : rc_open_1 cs));

rc_open_3 :: [Char] -> [Char];
rc_open_3 [] = [char_0x3C, char_0x21];
rc_open_3 (c : cs) =
  let {
    ic = integer_of_char c;
  } in (if ic == (45 :: Integer) then rc_open_4 cs
         else (if ic == (60 :: Integer) then c : char_0x21 : rc_open_2 cs
                else char_0x3C : char_0x21 : c : rc_open_1 cs));

rc_open_2 :: [Char] -> [Char];
rc_open_2 [] = [char_0x3C];
rc_open_2 (c : cs) =
  let {
    ic = integer_of_char c;
  } in (if ic == (33 :: Integer) then rc_open_3 cs
         else (if ic == (60 :: Integer) then c : rc_open_2 cs
                else char_0x3C : c : rc_open_1 cs));

remove_comments :: [Char] -> [Char];
remove_comments xs = rc_open_1 xs;

returna :: forall a b. a -> [b] -> Sum [Char] (a, [b]);
returna x = (\ ts -> Inr (x, ts));

bind :: forall a b c. Sum a b -> (b -> Sum a c) -> Sum a c;
bind m f = (case m of {
             Inl a -> Inl a;
             Inr a -> f a;
           });

binda ::
  forall a b c.
    ([a] -> Sum [Char] (b, [a])) ->
      (b -> [a] -> Sum [Char] (c, [a])) -> [a] -> Sum [Char] (c, [a]);
binda m f ts = bind (m ts) (\ (a, b) -> f a b);

char_0x3F :: Char;
char_0x3F = Chr (63 :: Integer);

char_0x3E :: Char;
char_0x3E = Chr (62 :: Integer);

shows_prec_list :: forall a. (Showa a) => Nat -> [a] -> [Char] -> [Char];
shows_prec_list p xs = shows_list xs;

length_tailrec :: forall a. [a] -> Nat -> Nat;
length_tailrec [] n = n;
length_tailrec (x : xs) n = length_tailrec xs (suc n);

size_list :: forall a. [a] -> Nat;
size_list xs = length_tailrec xs zero_nat;

char_0x20 :: Char;
char_0x20 = Chr (32 :: Integer);

char_0x27 :: Char;
char_0x27 = Chr (39 :: Integer);

shows_quote :: ([Char] -> [Char]) -> [Char] -> [Char];
shows_quote s =
  (shows_prec_char zero_nat char_0x27 . s) . shows_prec_char zero_nat char_0x27;

scan_upto :: [Char] -> [Char] -> Sum [Char] ([Char], [Char]);
scan_upto end (t : ts) =
  (if map snd (zip end (t : ts)) == end
    then Inr (end, drop (size_list end) (t : ts))
    else bind (scan_upto end ts) (\ (res, tsa) -> Inr (t : res, tsa)));
scan_upto end [] =
  Inl ([char_0x64, char_0x69, char_0x64, char_0x20, char_0x6E, char_0x6F,
         char_0x74, char_0x20, char_0x66, char_0x69, char_0x6E, char_0x64,
         char_0x20, char_0x65, char_0x6E, char_0x64, char_0x2D, char_0x6D,
         char_0x61, char_0x72, char_0x6B, char_0x65, char_0x72, char_0x20] ++
        shows_quote (shows_prec_list zero_nat end) []);

trim :: [Char] -> [Char];
trim =
  dropWhile
    (\ c ->
      let {
        ci = integer_of_char c;
      } in (if (34 :: Integer) <= ci then False
             else ci == (32 :: Integer) ||
                    (ci == (10 :: Integer) ||
                      (ci == (9 :: Integer) || ci == (13 :: Integer)))));

spaces :: [Char] -> Sum [Char] ((), [Char]);
spaces cs = Inr ((), trim cs);

parse_header :: [Char] -> Sum [Char] ([[Char]], [Char]);
parse_header ts =
  (if take (nat_of_integer (2 :: Integer)) (trim ts) == [char_0x3C, char_0x3F]
    then binda (scan_upto [char_0x3F, char_0x3E])
           (\ h -> binda parse_header (\ hs -> returna (h : hs))) ts
    else binda spaces (\ _ -> returna []) ts);

char_0x2C :: Char;
char_0x2C = Chr (44 :: Integer);

err_expecting :: forall a b. (Showa a) => [Char] -> [a] -> Sum [Char] (b, [a]);
err_expecting msg ts =
  Inl ([char_0x65, char_0x78, char_0x70, char_0x65, char_0x63, char_0x74,
         char_0x69, char_0x6E, char_0x67, char_0x20] ++
        msg ++
          [char_0x2C, char_0x20, char_0x62, char_0x75, char_0x74, char_0x20,
            char_0x66, char_0x6F, char_0x75, char_0x6E, char_0x64, char_0x3A,
            char_0x20] ++
            shows_quote
              (shows_prec_list zero_nat
                (take (nat_of_integer (30 :: Integer)) ts))
              []);

eoi :: forall a. (Showa a) => [a] -> Sum [Char] ((), [a]);
eoi [] = Inr ((), []);
eoi (v : va) =
  err_expecting
    [char_0x65, char_0x6E, char_0x64, char_0x20, char_0x6F, char_0x66,
      char_0x20, char_0x69, char_0x6E, char_0x70, char_0x75, char_0x74]
    (v : va);

char_0x2F :: Char;
char_0x2F = Chr (47 :: Integer);

char_0x3D :: Char;
char_0x3D = Chr (61 :: Integer);

char_0x22 :: Char;
char_0x22 = Chr (34 :: Integer);

exactly_aux ::
  [Char] -> [Char] -> [Char] -> [Char] -> Sum [Char] ([Char], [Char]);
exactly_aux s i (x : xs) (y : ys) =
  (if equal_char x y then exactly_aux s i xs ys
    else err_expecting ([char_0x22] ++ s ++ [char_0x22]) i);
exactly_aux s i [] xs = Inr (s, trim xs);
exactly_aux s i (x : xs) [] = err_expecting ([char_0x22] ++ s ++ [char_0x22]) i;

exactly :: [Char] -> [Char] -> Sum [Char] ([Char], [Char]);
exactly s x = exactly_aux s x s x;

many :: (Char -> Bool) -> [Char] -> Sum [Char] ([Char], [Char]);
many p (t : ts) =
  (if p t then bind (many p ts) (\ (rs, tsa) -> Inr (t : rs, tsa))
    else Inr ([], t : ts));
many p [] = Inr ([], []);

parse_attribute_value :: [Char] -> Sum [Char] ([Char], [Char]);
parse_attribute_value =
  binda (exactly [char_0x22])
    (\ _ ->
      binda (many (\ y -> not (equal_char char_0x22 y)))
        (\ v -> binda (exactly [char_0x22]) (\ _ -> returna v)));

many_letters_main :: [Char] -> ([Char], [Char]);
many_letters_main [] = ([], []);
many_letters_main (c : cs) =
  (if is_letter c then (case many_letters_main cs of {
                         (ds, a) -> (c : ds, a);
                       })
    else ([], c : cs));

parse_name :: [Char] -> Sum [Char] ([Char], [Char]);
parse_name s =
  (case many_letters_main s of {
    (n, ts) ->
      (if null n
        then Inl ([char_0x65, char_0x78, char_0x70, char_0x65, char_0x63,
                    char_0x74, char_0x65, char_0x64, char_0x20, char_0x6C,
                    char_0x65, char_0x74, char_0x74, char_0x65, char_0x72,
                    char_0x20] ++
                   letters ++
                     [char_0x20, char_0x62, char_0x75, char_0x74, char_0x20,
                       char_0x66, char_0x69, char_0x72, char_0x73, char_0x74,
                       char_0x20, char_0x73, char_0x79, char_0x6D, char_0x62,
                       char_0x6F, char_0x6C, char_0x20, char_0x69, char_0x73,
                       char_0x20, char_0x22] ++
                       take one_nat s ++ [char_0x22])
        else Inr (n, trim ts));
  });

parse_attributes :: [Char] -> Sum [Char] ([([Char], [Char])], [Char]);
parse_attributes [] = Inr ([], []);
parse_attributes (c : s) =
  let {
    ic = integer_of_char c;
  } in (if ic == (47 :: Integer) || ic == (62 :: Integer) then Inr ([], c : s)
         else binda parse_name
                (\ k ->
                  binda (exactly [char_0x3D])
                    (\ _ ->
                      binda parse_attribute_value
                        (\ v ->
                          binda parse_attributes
                            (\ atts -> returna ((k, v) : atts)))))
                (c : s));

char_0x5D :: Char;
char_0x5D = Chr (93 :: Integer);

char_0x5B :: Char;
char_0x5B = Chr (91 :: Integer);

oneof_closed :: [Char] -> Sum [Char] ([Char], [Char]);
oneof_closed (x : xs) =
  (if equal_char x char_0x3E then Inr ([char_0x3E], trim xs)
    else (if equal_char x char_0x2F && (case xs of {
 [] -> False;
 y : _ -> equal_char y char_0x3E;
                                       })
           then Inr ([char_0x2F, char_0x3E], trim (tl xs))
           else err_expecting
                  [char_0x6F, char_0x6E, char_0x65, char_0x20, char_0x6F,
                    char_0x66, char_0x20, char_0x5B, char_0x2F, char_0x3E,
                    char_0x2C, char_0x20, char_0x3E, char_0x5D]
                  (x : xs)));
oneof_closed [] =
  err_expecting
    [char_0x6F, char_0x6E, char_0x65, char_0x20, char_0x6F, char_0x66,
      char_0x20, char_0x5B, char_0x2F, char_0x3E, char_0x2C, char_0x20,
      char_0x3E, char_0x5D]
    [];

parse_text_main :: [Char] -> [Char] -> ([Char], [Char]);
parse_text_main [] res = ([], reverse (trim res));
parse_text_main (c : cs) res =
  (if integer_of_char c == (60 :: Integer) then (c : cs, reverse (trim res))
    else parse_text_main cs (c : res));

parse_text_impl :: forall a. [Char] -> Sum a (Maybe [Char], [Char]);
parse_text_impl cs =
  (case parse_text_main (trim cs) [] of {
    (rem, txt) ->
      (if null txt then Inr (Nothing, rem) else Inr (Just txt, rem));
  });

parse_text :: [Char] -> Sum [Char] (Maybe [Char], [Char]);
parse_text cs = parse_text_impl cs;

parse_nodes :: [Char] -> Sum [Char] ([Xml], [Char]);
parse_nodes ts =
  (if null ts ||
        take (nat_of_integer (2 :: Integer)) ts == [char_0x3C, char_0x2F]
    then returna [] ts
    else (if not (equal_char (hd ts) char_0x3C)
           then binda parse_text
                  (\ t ->
                    binda parse_nodes (\ ns -> returna (XML_text (the t) : ns)))
                  ts
           else binda (exactly [char_0x3C])
                  (\ _ ->
                    binda parse_name
                      (\ n ->
                        binda parse_attributes
                          (\ atts ->
                            binda oneof_closed
                              (\ e ->
                                (if e == [char_0x2F, char_0x3E]
                                  then binda parse_nodes
 (\ cs -> returna (XML n atts [] : cs))
                                  else binda parse_nodes
 (\ cs ->
   binda (exactly [char_0x3C, char_0x2F])
     (\ _ ->
       binda (exactly n)
         (\ _ ->
           binda (exactly [char_0x3E])
             (\ _ ->
               binda parse_nodes (\ ns -> returna (XML n atts cs : ns)))))))))))
                  ts));

parse_node :: [Char] -> Sum [Char] (Xml, [Char]);
parse_node =
  binda (exactly [char_0x3C])
    (\ _ ->
      binda parse_name
        (\ n ->
          binda parse_attributes
            (\ atts ->
              binda oneof_closed
                (\ e ->
                  (if e == [char_0x2F, char_0x3E] then returna (XML n atts [])
                    else binda parse_nodes
                           (\ cs ->
                             binda (exactly [char_0x3C, char_0x2F])
                               (\ _ ->
                                 binda (exactly n)
                                   (\ _ ->
                                     binda (exactly [char_0x3E])
                                       (\ _ -> returna (XML n atts cs))))))))));

parse_doc :: [Char] -> Sum [Char] (Xmldoc, [Char]);
parse_doc =
  binda (update_tokens remove_comments)
    (\ _ ->
      binda parse_header
        (\ h ->
          binda parse_node
            (\ xml -> binda eoi (\ _ -> returna (XMLDOC h xml)))));

bool_of_string :: [Char] -> Sum String Bool;
bool_of_string s =
  (if s == [char_0x74, char_0x72, char_0x75, char_0x65] then Inr True
    else (if s == [char_0x66, char_0x61, char_0x6C, char_0x73, char_0x65]
           then Inr False
           else Inl (("cannot convert \"" ++ implode s) ++ "\" into Boolean")));

xml_take_text ::
  forall a.
    ([Char] ->
      ([Xml], ([([Char], [Char])], (Bool, ([String], [String])))) ->
        Sum_bot (Xml_error String) a) ->
      ([Xml], ([([Char], [Char])], (Bool, ([String], [String])))) ->
        Sum_bot (Xml_error String) a;
xml_take_text p xs = (case xs of {
                       ([], _) -> xml_error "expecting a text" xs;
                       (XML _ _ _ : _, _) -> xml_error "expecting a text" xs;
                       (XML_text text : xmls, s) -> p text (xmls, s);
                     });

xml_text ::
  String ->
    (Xml, ([([Char], [Char])], (Bool, ([String], [String])))) ->
      Sum_bot (Xml_error String) [Char];
xml_text tag = xml_do tag (xml_take_text xml_return);

xml_bool ::
  String ->
    (Xml, ([([Char], [Char])], (Bool, ([String], [String])))) ->
      Sum_bot (Xml_error String) Bool;
xml_bool tag x =
  bind2 (xml_text tag x) left
    (\ str -> (case bool_of_string str of {
                Inl err -> xml_error err ([fst x], snd x);
                Inr a -> right a;
              }));

xml_take ::
  forall a b.
    ((Xml, ([([Char], [Char])], (Bool, ([String], [String])))) ->
      Sum_bot (Xml_error String) a) ->
      (a -> ([Xml], ([([Char], [Char])], (Bool, ([String], [String])))) ->
              Sum_bot (Xml_error String) b) ->
        ([Xml], ([([Char], [Char])], (Bool, ([String], [String])))) ->
          Sum_bot (Xml_error String) b;
xml_take p1 p2 x =
  (case x of {
    ([], rest) ->
      bind2 (p1 (XML [] [] [], rest)) left (\ _ -> left (Fatal "unexpected"));
    (xa : xs, (atts, (flag, (cands, rest)))) ->
      bind2 (p1 (xa, (atts, (flag, (cands, rest))))) left
        (\ a -> p2 a (xs, (atts, (False, ([], rest)))));
  });

replicate :: forall a. Nat -> a -> [a];
replicate n x =
  (if equal_nat n zero_nat then [] else x : replicate (minus_nat n one_nat) x);

lookupa :: forall a b. (Ccompare a, Eq a) => Mapping a b -> a -> Maybe b;
lookupa (RBT_Mapping t) = lookupb t;
lookupa (Assoc_List_Mapping al) = lookup al;

eval_term :: forall a b c. (a -> [b] -> b) -> Term a c -> (c -> b) -> b;
eval_term i (Var x) alpha = alpha x;
eval_term i (Fun f ss) alpha = i f (map (\ s -> eval_term i s alpha) ss);

xml_error_to_string :: Xml_error String -> [Char];
xml_error_to_string (Fatal e) = explode ("Fatal: " ++ e);
xml_error_to_string (TagMismatch e) =
  explode ("tag mismatch: " ++ default_showsl_list showsl_lit e "");

parse_xml ::
  forall a.
    ((Xml, ([([Char], [Char])], (Bool, ([String], [String])))) ->
      Sum_bot (Xml_error String) a) ->
      Xml -> Sum_bot [Char] a;
parse_xml p xml =
  bind2 (xml_take p xml_return ([xml], ([], (False, ([], [])))))
    (left . xml_error_to_string) right;

xml_change ::
  forall a b.
    ((Xml, ([([Char], [Char])], (Bool, ([String], [String])))) ->
      Sum_bot (Xml_error String) a) ->
      (a -> ([Xml], ([([Char], [Char])], (Bool, ([String], [String])))) ->
              Sum_bot (Xml_error String) b) ->
        (Xml, ([([Char], [Char])], (Bool, ([String], [String])))) ->
          Sum_bot (Xml_error String) b;
xml_change p f x = bind2 (p x) left (\ a -> (case x of {
      (_, rest) -> f a ([], rest);
    }));

char_0x23 :: Char;
char_0x23 = Chr (35 :: Integer);

special_map :: [Char] -> Maybe [Char];
special_map =
  map_of
    [([char_0x71, char_0x75, char_0x6F, char_0x74], [char_0x22]),
      ([char_0x23, char_0x33, char_0x34], [char_0x22]),
      ([char_0x61, char_0x6D, char_0x70], [char_0x26]),
      ([char_0x23, char_0x33, char_0x38], [char_0x26]),
      ([char_0x61, char_0x70, char_0x6F, char_0x73], [char_0x27]),
      ([char_0x23, char_0x33, char_0x39], [char_0x27]),
      ([char_0x6C, char_0x74], [char_0x3C]),
      ([char_0x23, char_0x36, char_0x30], [char_0x3C]),
      ([char_0x67, char_0x74], [char_0x3E]),
      ([char_0x23, char_0x36, char_0x32], [char_0x3E])];

doc_of_string :: [Char] -> Sum [Char] Xmldoc;
doc_of_string s = bind (parse_doc s) (\ (doc, _) -> Inr doc);

map_xml_text :: ([Char] -> [Char]) -> Xml -> Xml;
map_xml_text f (XML t asa cs) = XML t asa (map (map_xml_text f) cs);
map_xml_text f (XML_text txt) = XML_text (f txt);

add_vars_term :: forall a b. Term a b -> [b] -> [b];
add_vars_term (Var x) xs = x : xs;
add_vars_term (Fun uu ts) xs = foldr add_vars_term ts xs;

vars_term_list :: forall a b. Term a b -> [b];
vars_term_list t = add_vars_term t [];

vars_term :: forall a b. (Ceq b, Ccompare b, Set_impl b) => Term a b -> Set b;
vars_term t = set (vars_term_list t);

plain_var ::
  (Xml, ([([Char], [Char])], (Bool, ([String], [String])))) ->
    Sum_bot (Xml_error String) [Char];
plain_var = xml_text "var";

var ::
  forall a.
    (Xml, ([([Char], [Char])], (Bool, ([String], [String])))) ->
      Sum_bot (Xml_error String) (Term a [Char]);
var = xml_change plain_var (xml_return . Var);

map_option :: forall a b. (a -> b) -> Maybe a -> Maybe b;
map_option f Nothing = Nothing;
map_option f (Just x2) = Just (f x2);

extract_special :: [Char] -> [Char] -> Maybe ([Char], [Char]);
extract_special acc [] = Nothing;
extract_special acc (x : xs) =
  (if equal_char x char_0x3B
    then map_option (\ s -> (s, xs)) (special_map (reverse acc))
    else extract_special (x : acc) xs);

zero_enat :: Enat;
zero_enat = Enat zero_nat;

minus_enat :: Enat -> Enat -> Enat;
minus_enat (Enat a) (Enat b) = Enat (minus_nat a b);
minus_enat Infinity_enat n = Infinity_enat;
minus_enat (Enat a) Infinity_enat = zero_enat;

equal_enat :: Enat -> Enat -> Bool;
equal_enat (Enat nat) Infinity_enat = False;
equal_enat Infinity_enat (Enat nat) = False;
equal_enat (Enat nata) (Enat nat) = equal_nat nata nat;
equal_enat Infinity_enat Infinity_enat = True;

one_enat :: Enat;
one_enat = Enat one_nat;

xml_take_many_sub ::
  forall a b.
    [a] ->
      Nat ->
        Enat ->
          ((Xml, ([([Char], [Char])], (Bool, ([String], [String])))) ->
            Sum_bot (Xml_error String) a) ->
            ([a] ->
              ([Xml], ([([Char], [Char])], (Bool, ([String], [String])))) ->
                Sum_bot (Xml_error String) b) ->
              ([Xml], ([([Char], [Char])], (Bool, ([String], [String])))) ->
                Sum_bot (Xml_error String) b;
xml_take_many_sub acc minOccurs maxOccurs p1 p2 ([], (atts, (allow, rest))) =
  (if equal_nat minOccurs zero_nat
    then p2 (reverse acc) ([], (atts, (allow, rest)))
    else bind2 (p1 (XML [] [] [], (atts, (False, rest)))) left
           (\ _ -> left (Fatal "unexpected")));
xml_take_many_sub acc minOccurs maxOccurs p1 p2
  (xml : xmls, (atts, (allow, (cands, rest)))) =
  (if equal_enat maxOccurs zero_enat
    then p2 (reverse acc) (xml : xmls, (atts, (allow, (cands, rest))))
    else bind2 (p1 (xml, (atts, (equal_nat minOccurs zero_nat, (cands, rest)))))
           (\ e ->
             (case e of {
               TagMismatch _ ->
                 p2 (reverse acc) (xml : xmls, (atts, (allow, (cands, rest))));
               Fatal _ -> left e;
             }))
           (\ a ->
             xml_take_many_sub (a : acc) (minus_nat minOccurs one_nat)
               (minus_enat maxOccurs one_enat) p1 p2
               (xmls, (atts, (False, ([], rest))))));

term ::
  forall a.
    (Showl a) => ((Xml, ([([Char], [Char])], (Bool, ([String], [String])))) ->
                   Sum_bot (Xml_error String) a) ->
                   Mapping [Char] (Term a [Char]) ->
                     (Xml, ([([Char], [Char])],
                             (Bool, ([String], [String])))) ->
                       Sum_bot (Xml_error String) (Term a [Char]);
term xml2name termMap x =
  xml_or
    (xml_do "funapp"
      (xml_take xml2name
        (\ name ->
          xml_take_many_sub [] zero_nat Infinity_enat (term xml2name termMap)
            (\ args -> xml_return (Fun name args)))))
    (xml_or var
      (xml_change (xml_text "termIndex")
        (\ idx ->
          (case lookupa termMap idx of {
            Nothing ->
              xml_error
                (("term index " ++ implode idx) ++
                  " is unknown in term-index map");
            Just a -> xml_return a;
          }))))
    x;

normalize_special :: [Char] -> [Char];
normalize_special [] = [];
normalize_special (x : xs) =
  (if equal_char x char_0x26
    then (case extract_special [] xs of {
           Nothing -> [char_0x26] ++ normalize_special xs;
           Just (spec, ys) -> spec ++ normalize_special ys;
         })
    else x : normalize_special xs);

parse_xml_string ::
  forall a.
    ((Xml, ([([Char], [Char])], (Bool, ([String], [String])))) ->
      Sum_bot (Xml_error String) a) ->
      [Char] -> Sum_bot [Char] a;
parse_xml_string p str =
  (case doc_of_string str of {
    Inl a -> left a;
    Inr (XMLDOC _ xml) -> parse_xml p (map_xml_text normalize_special xml);
  });

lp_cut_map :: forall a b. (a -> b) -> Lp_cut_goal a -> Lp_cut_goal b;
lp_cut_map f (LPCAtom a) = LPCAtom (f a);
lp_cut_map f (LPCCut m) = LPCCut m;
lp_cut_map f LPCTrue = LPCTrue;
lp_cut_map f LPCFail = LPCFail;
lp_cut_map f (LPCMeta a) = LPCMeta (f a);
lp_cut_map f (LPCExpand a m) = LPCExpand (f a) m;
lp_cut_map f (LPCUnify a b) = LPCUnify (f a) (f b);

char_0x24 :: Char;
char_0x24 = Chr (36 :: Integer);

lp_prefix :: Nat -> [Char] -> [Char];
lp_prefix k x = replicate k char_0x24 ++ x;

lp_cut_bind :: forall a b. Nat -> (a -> b) -> Lp_cut_goal a -> Lp_cut_goal b;
lp_cut_bind m f (LPCCut n) = LPCCut m;
lp_cut_bind m f (LPCAtom v) = lp_cut_map f (LPCAtom v);
lp_cut_bind m f LPCTrue = lp_cut_map f LPCTrue;
lp_cut_bind m f LPCFail = lp_cut_map f LPCFail;
lp_cut_bind m f (LPCMeta v) = lp_cut_map f (LPCMeta v);
lp_cut_bind m f (LPCExpand v va) = lp_cut_map f (LPCExpand v va);
lp_cut_bind m f (LPCUnify v va) = lp_cut_map f (LPCUnify v va);

set_impl_nat :: Phantom Nat Set_impla;
set_impl_nat = Phantom Set_RBT;

lp_cut_goal_scopes :: forall a. Lp_cut_goal a -> Set Nat;
lp_cut_goal_scopes (LPCCut m) = insert m (set_empty (of_phantom set_impl_nat));
lp_cut_goal_scopes (LPCExpand a m) =
  insert m (set_empty (of_phantom set_impl_nat));
lp_cut_goal_scopes (LPCAtom v) = set_empty (of_phantom set_impl_nat);
lp_cut_goal_scopes LPCTrue = set_empty (of_phantom set_impl_nat);
lp_cut_goal_scopes LPCFail = set_empty (of_phantom set_impl_nat);
lp_cut_goal_scopes (LPCMeta v) = set_empty (of_phantom set_impl_nat);
lp_cut_goal_scopes (LPCUnify v va) = set_empty (of_phantom set_impl_nat);

lpc_scope_absent :: forall a. Nat -> Lp_cut_entry a -> Bool;
lpc_scope_absent m (LPCGoals gs) =
  all (\ g -> not (member m (lp_cut_goal_scopes g))) gs;
lpc_scope_absent m (LPCClause gs c n) =
  not (equal_nat m n) && all (\ g -> not (member m (lp_cut_goal_scopes g))) gs;
lpc_scope_absent m (LPCBarrier n) = not (equal_nat m n);

lp_cut_fresh :: forall a. Nat -> [Lp_cut_entry a] -> Bool;
lp_cut_fresh m es = all (lpc_scope_absent m) es;

lp_cut_slice :: forall a b c. (Eq a) => [(Term a b, c)] -> a -> Nat -> [Nat];
lp_cut_slice p f n =
  filter (\ c -> (case fst (nth p c) of {
                   Var _ -> False;
                   Fun g ts -> g == f && equal_nat (size_list ts) n;
                 }))
    (upt zero_nat (size_list p));

mapping_empty_choose :: forall a b. (Ccompare a) => Mapping a b;
mapping_empty_choose = (case (ccompare :: Maybe (a -> a -> Ordera)) of {
                         Nothing -> Assoc_List_Mapping empty;
                         Just _ -> RBT_Mapping emptyb;
                       });

mapping_empty :: forall a b. (Ccompare a) => Mapping_impl -> Mapping a b;
mapping_empty Mapping_RBT = RBT_Mapping emptyb;
mapping_empty Mapping_Assoc_List = Assoc_List_Mapping empty;
mapping_empty Mapping_Mapping = Mapping (\ _ -> Nothing);
mapping_empty Mapping_Choose = mapping_empty_choose;

lp_cut_prune :: forall a. Nat -> [Lp_cut_entry a] -> [Lp_cut_entry a];
lp_cut_prune m [] = [];
lp_cut_prune m (e : es) =
  (case e of {
    LPCGoals _ -> lp_cut_prune m es;
    LPCClause _ _ _ -> lp_cut_prune m es;
    LPCBarrier n -> (if equal_nat m n then e : es else lp_cut_prune m es);
  });

lp_cut_admin :: forall a. [Lp_cut_entry a] -> Maybe [Lp_cut_entry a];
lp_cut_admin [] = Nothing;
lp_cut_admin (LPCBarrier m : es) = Just es;
lp_cut_admin (LPCClause gs c m : es) = Nothing;
lp_cut_admin (LPCGoals [] : es) = Just es;
lp_cut_admin (LPCGoals (g : gs) : es) =
  (case g of {
    LPCAtom _ -> Nothing;
    LPCCut m -> Just (LPCGoals gs : lp_cut_prune m es);
    LPCTrue -> Just (LPCGoals gs : es);
    LPCFail -> Just es;
    LPCMeta _ -> Nothing;
    LPCExpand _ _ -> Nothing;
    LPCUnify _ _ -> Nothing;
  });

lpc_mgu_substitution ::
  forall a b. (Eq a) => [a] -> [Term b a] -> a -> Term b a;
lpc_mgu_substitution v images x = (case map_of (zip v images) x of {
                                    Nothing -> Var x;
                                    Just t -> t;
                                  });

lp_cut_decode :: forall a. (Lp_cut_tag, [a]) -> Maybe (Lp_cut_goal a);
lp_cut_decode (LPCAtomTag, [a]) = Just (LPCAtom a);
lp_cut_decode (LPCCutTag m, []) = Just (LPCCut m);
lp_cut_decode (LPCTrueTag, []) = Just LPCTrue;
lp_cut_decode (LPCFailTag, []) = Just LPCFail;
lp_cut_decode (LPCMetaTag, [a]) = Just (LPCMeta a);
lp_cut_decode (LPCExpandTag m, [a]) = Just (LPCExpand a m);
lp_cut_decode (LPCUnifyTag, [a, b]) = Just (LPCUnify a b);
lp_cut_decode (LPCCutTag vb, v : vc) = Nothing;
lp_cut_decode (LPCTrueTag, v : vb) = Nothing;
lp_cut_decode (LPCFailTag, v : vb) = Nothing;
lp_cut_decode (LPCMetaTag, []) = Nothing;
lp_cut_decode (LPCMetaTag, v : vc : vd) = Nothing;
lp_cut_decode (LPCExpandTag vb, []) = Nothing;
lp_cut_decode (LPCExpandTag vb, v : vd : ve) = Nothing;
lp_cut_decode (LPCUnifyTag, []) = Nothing;
lp_cut_decode (LPCUnifyTag, [v]) = Nothing;
lp_cut_decode (LPCUnifyTag, v : vc : ve : vf) = Nothing;
lp_cut_decode (LPCAtomTag, []) = Nothing;
lp_cut_decode (LPCAtomTag, vb : vd : ve) = Nothing;
lp_cut_decode (v, vb : vd : va : vc) = Nothing;

lp_cut_decode_list :: forall a. [(Lp_cut_tag, [a])] -> Maybe [Lp_cut_goal a];
lp_cut_decode_list [] = Just [];
lp_cut_decode_list (a : asa) =
  (case lp_cut_decode a of {
    Nothing -> Nothing;
    Just g -> map_option (\ aa -> g : aa) (lp_cut_decode_list asa);
  });

lp_atom_subst ::
  forall a b c d. (a, [Term b c]) -> (c -> Term b d) -> (a, [Term b d]);
lp_atom_subst a sigma = (fst a, map (\ t -> eval_term Fun t sigma) (snd a));

lp_eliminate :: forall a b. (Eq a) => a -> Term b a -> a -> Term b a;
lp_eliminate x t y = (if x == y then t else Var y);

lp_normalize_goals ::
  forall a b c.
    (Eq a,
      Eq b) => Nat ->
                 [(Term a b, Term a b)] ->
                   [(c, [Term a b])] -> Maybe (Maybe [(c, [Term a b])]);
lp_normalize_goals fuel es gs =
  (if equal_nat fuel zero_nat then Nothing
    else (case es of {
           [] -> Just (Just gs);
           (Var x, t) : rest ->
             (if equal_term t (Var x)
               then lp_normalize_goals (minus_nat fuel one_nat) rest gs
               else lp_normalize_goals (minus_nat fuel one_nat)
                      (map (\ (l, r) ->
                             (eval_term Fun l (lp_eliminate x t),
                               eval_term Fun r (lp_eliminate x t)))
                        rest)
                      (map (\ a -> lp_atom_subst a (lp_eliminate x t)) gs));
           (Fun f ss, Var x) : rest ->
             lp_normalize_goals (minus_nat fuel one_nat)
               ((Var x, Fun f ss) : rest) gs;
           (Fun f ss, Fun g ts) : rest ->
             (if f == g && equal_nat (size_list ss) (size_list ts)
               then lp_normalize_goals (minus_nat fuel one_nat)
                      (zip ss ts ++ rest) gs
               else Just Nothing);
         }));

lp_cut_encode :: forall a. Lp_cut_goal a -> (Lp_cut_tag, [a]);
lp_cut_encode (LPCAtom a) = (LPCAtomTag, [a]);
lp_cut_encode (LPCCut m) = (LPCCutTag m, []);
lp_cut_encode LPCTrue = (LPCTrueTag, []);
lp_cut_encode LPCFail = (LPCFailTag, []);
lp_cut_encode (LPCMeta a) = (LPCMetaTag, [a]);
lp_cut_encode (LPCExpand a m) = (LPCExpandTag m, [a]);
lp_cut_encode (LPCUnify a b) = (LPCUnifyTag, [a, b]);

lp_cut_normalize ::
  forall a b.
    (Eq a,
      Eq b) => Nat ->
                 [(Term a b, Term a b)] ->
                   [Lp_cut_goal (Term a b)] ->
                     Maybe (Maybe [Lp_cut_goal (Term a b)]);
lp_cut_normalize fuel es gs =
  (case lp_normalize_goals fuel es (map lp_cut_encode gs) of {
    Nothing -> Nothing;
    Just Nothing -> Just Nothing;
    Just (Just hs) -> map_option Just (lp_cut_decode_list hs);
  });

lpc_check_mgu ::
  forall a b.
    (Eq a, Eq b) => Nat -> [(Term a b, Term a b)] -> [b] -> [Term a b] -> Bool;
lpc_check_mgu fuel equations v images =
  distinct v &&
    equal_nat (size_list v) (size_list images) &&
      lp_cut_normalize fuel equations (map (\ x -> LPCAtom (Var x)) v) ==
        Just (Just (map LPCAtom images)) &&
        all (\ (s, t) ->
              equal_term (eval_term Fun s (lpc_mgu_substitution v images))
                (eval_term Fun t (lpc_mgu_substitution v images)))
          equations;

lp_cut_terms :: forall a. Lp_cut_goal a -> [a];
lp_cut_terms (LPCAtom a) = [a];
lp_cut_terms (LPCMeta a) = [a];
lp_cut_terms (LPCExpand a m) = [a];
lp_cut_terms (LPCUnify a b) = [a, b];
lp_cut_terms (LPCCut v) = [];
lp_cut_terms LPCTrue = [];
lp_cut_terms LPCFail = [];

lp_cut_short_goals ::
  forall a b. (Ceq b, Ccompare b) => Nat -> [Lp_cut_goal (Term a [b])] -> Bool;
lp_cut_short_goals k gs =
  all (\ g ->
        all (\ t -> ball (vars_term t) (\ x -> less_nat (size_list x) k))
          (lp_cut_terms g))
    gs;

lpc_no_swap :: forall a. (Eq a) => a -> a -> a -> a;
lpc_no_swap x y z = (if z == x then y else (if z == y then x else z));

lpc_no_resolve_swap ::
  forall a.
    (Eq a) => Nat ->
                [(Term a [Char], [Lp_cut_goal (Term a [Char])])] ->
                  Term a [Char] ->
                    [Lp_cut_goal (Term a [Char])] ->
                      Nat ->
                        Nat ->
                          [Lp_cut_entry (Term a [Char])] ->
                            Nat ->
                              [[Char]] ->
                                [Term a [Char]] ->
                                  [Char] ->
                                    [Char] ->
                                      [Lp_cut_entry (Term a [Char])] -> Bool;
lpc_no_resolve_swap fuel p a gs c m es k v images x y successor =
  less_nat c (size_list p) &&
    ball (vars_term a) (\ va -> less_nat (size_list va) k) &&
      lp_cut_short_goals k gs &&
        lpc_check_mgu fuel
          [(a, eval_term Fun (fst (nth p c)) (\ va -> Var (lp_prefix k va)))] v
          images &&
          successor ==
            LPCGoals
              (map (lp_cut_bind m
                     (\ t ->
                       eval_term Fun
                         (eval_term Fun t
                           (\ va ->
                             lpc_mgu_substitution v images (lp_prefix k va)))
                         (\ va -> Var (lpc_no_swap x y va))))
                 (snd (nth p c)) ++
                map (lp_cut_map
                      (\ t ->
                        eval_term Fun
                          (eval_term Fun t (lpc_mgu_substitution v images))
                          (\ va -> Var (lpc_no_swap x y va))))
                  gs) :
              es;

lp_cut_check_equality ::
  forall a.
    (Eq a) => Nat -> Term a [Char] -> Term a [Char] -> Lp_cut_coverage -> Bool;
lp_cut_check_equality fuel a b coverage =
  (case coverage of {
    LPCAlwaysSuccess -> equal_term a b;
    LPCAlwaysFailure ->
      (lp_normalize_goals ::
        Nat ->
          [(Term a [Char], Term a [Char])] ->
            [(a, [Term a [Char]])] -> Maybe (Maybe [(a, [Term a [Char]])]))
        fuel [(a, b)] [] ==
        Just Nothing;
    LPCBoth -> True;
  });

lp_cut_lower_finite ::
  forall a b.
    Nat ->
      Term (Lp_cut_symbol a) b ->
        Maybe [Lp_cut_goal (Term (Lp_cut_symbol a) b)];
lp_cut_lower_finite m (Fun (LPCUser f) ts) =
  Just [LPCAtom (Fun (LPCUser f) ts)];
lp_cut_lower_finite m (Fun LPCBang []) = Just [LPCCut m];
lp_cut_lower_finite m (Fun LPCComma [a, b]) =
  (case lp_cut_lower_finite m a of {
    Nothing -> Nothing;
    Just asa -> map_option (\ aa -> asa ++ aa) (lp_cut_lower_finite m b);
  });
lp_cut_lower_finite m (Fun LPCEquals [a, b]) = Just [LPCUnify a b];
lp_cut_lower_finite m (Fun LPCTruth []) = Just [LPCTrue];
lp_cut_lower_finite m (Fun LPCFailure []) = Just [LPCFail];
lp_cut_lower_finite m (Fun LPCCallSymbol [a]) = Just [LPCMeta a];
lp_cut_lower_finite m (Var v) = Nothing;
lp_cut_lower_finite m (Fun LPCBang (v : vb)) = Nothing;
lp_cut_lower_finite m (Fun LPCComma []) = Nothing;
lp_cut_lower_finite m (Fun LPCComma [v]) = Nothing;
lp_cut_lower_finite m (Fun LPCComma (v : vc : ve : vf)) = Nothing;
lp_cut_lower_finite m (Fun LPCEquals []) = Nothing;
lp_cut_lower_finite m (Fun LPCEquals [v]) = Nothing;
lp_cut_lower_finite m (Fun LPCEquals (v : vc : ve : vf)) = Nothing;
lp_cut_lower_finite m (Fun LPCTruth (v : vb)) = Nothing;
lp_cut_lower_finite m (Fun LPCFailure (v : vb)) = Nothing;
lp_cut_lower_finite m (Fun LPCCallSymbol []) = Nothing;
lp_cut_lower_finite m (Fun LPCCallSymbol (v : vc : vd)) = Nothing;

lp_cut_check_meta ::
  forall a b.
    (Eq a,
      Eq b) => Nat ->
                 Term (Lp_cut_symbol a) b ->
                   [Lp_cut_goal (Term (Lp_cut_symbol a) b)] ->
                     [Lp_cut_entry (Term (Lp_cut_symbol a) b)] ->
                       [Lp_cut_goal (Term (Lp_cut_symbol a) b)] -> Bool;
lp_cut_check_meta m a gs es body =
  lp_cut_fresh m (LPCGoals (LPCMeta a : gs) : es) &&
    lp_cut_lower_finite m a == Just body;

lp_cut_check_case ::
  forall a b c d.
    (Eq a,
      Eq d) => [(Term (Lp_cut_symbol a) b, c)] ->
                 Nat ->
                   a -> [Term (Lp_cut_symbol a) d] ->
                          [Lp_cut_goal (Term (Lp_cut_symbol a) d)] ->
                            [Lp_cut_entry (Term (Lp_cut_symbol a) d)] ->
                              [Lp_cut_entry (Term (Lp_cut_symbol a) d)] -> Bool;
lp_cut_check_case p m f ts gs es next =
  lp_cut_fresh m (LPCGoals (LPCAtom (Fun (LPCUser f) ts) : gs) : es) &&
    next ==
      map (\ c -> LPCClause (LPCAtom (Fun (LPCUser f) ts) : gs) c m)
        (lp_cut_slice p (LPCUser f) (size_list ts)) ++
        LPCBarrier m : es;

lp_cut_check_clash ::
  forall a. (Eq a) => Nat -> Nat -> Term a [Char] -> Term a [Char] -> Bool;
lp_cut_check_clash fuel k a h =
  ball (vars_term a) (\ x -> less_nat (size_list x) k) &&
    (lp_normalize_goals ::
      Nat ->
        [(Term a [Char], Term a [Char])] ->
          [(a, [Term a [Char]])] -> Maybe (Maybe [(a, [Term a [Char]])]))
      fuel [(a, eval_term Fun h (\ x -> Var (lp_prefix k x)))] [] ==
      Just Nothing;

lp_cut_check_admin ::
  forall a. (Eq a) => [Lp_cut_entry a] -> [Lp_cut_entry a] -> Bool;
lp_cut_check_admin s t = lp_cut_admin s == Just t;

lpc_no_resolve ::
  forall a.
    (Eq a) => Nat ->
                [(Term a [Char], [Lp_cut_goal (Term a [Char])])] ->
                  Term a [Char] ->
                    [Lp_cut_goal (Term a [Char])] ->
                      Nat ->
                        Nat ->
                          [Lp_cut_entry (Term a [Char])] ->
                            Nat ->
                              [[Char]] ->
                                [Term a [Char]] ->
                                  [Lp_cut_entry (Term a [Char])] -> Bool;
lpc_no_resolve fuel p a gs c m es k v images successor =
  less_nat c (size_list p) &&
    ball (vars_term a) (\ x -> less_nat (size_list x) k) &&
      lp_cut_short_goals k gs &&
        lpc_check_mgu fuel
          [(a, eval_term Fun (fst (nth p c)) (\ x -> Var (lp_prefix k x)))] v
          images &&
          successor ==
            LPCGoals
              (map (lp_cut_bind m
                     (\ t ->
                       eval_term Fun t
                         (\ x ->
                           lpc_mgu_substitution v images (lp_prefix k x))))
                 (snd (nth p c)) ++
                map (lp_cut_map
                      (\ t -> eval_term Fun t (lpc_mgu_substitution v images)))
                  gs) :
              es;

lpc_no_step ::
  forall a.
    (Eq a) => Nat ->
                [(Term (Lp_cut_symbol a) [Char],
                   [Lp_cut_goal (Term (Lp_cut_symbol a) [Char])])] ->
                  [Lp_cut_entry (Term (Lp_cut_symbol a) [Char])] ->
                    Lpc_no_action a ->
                      [Lp_cut_entry (Term (Lp_cut_symbol a) [Char])] -> Bool;
lpc_no_step fuel p s LPCNOAdmin t = lp_cut_check_admin s t;
lpc_no_step fuel p (LPCGoals (LPCAtom (Fun (LPCUser f) ts) : gs) : es)
  (LPCNOCase m) t = lp_cut_check_case p m f ts gs es t;
lpc_no_step fuel p (LPCGoals (LPCMeta a : gs) : es) (LPCNOMeta m body) t =
  lp_cut_check_meta m a gs es body &&
    t == LPCGoals (body ++ gs) : LPCBarrier m : es;
lpc_no_step fuel p (LPCClause (LPCAtom a : gs) c m : es)
  (LPCNOResolve k v images) t = lpc_no_resolve fuel p a gs c m es k v images t;
lpc_no_step fuel p (LPCClause (LPCAtom a : gs) c m : es)
  (LPCNOResolveSwap k v images x y) t =
  lpc_no_resolve_swap fuel p a gs c m es k v images x y t;
lpc_no_step fuel p (LPCGoals (LPCUnify a b : gs) : es) (LPCNOUnify v images) t =
  lpc_check_mgu fuel [(a, b)] v images &&
    t == LPCGoals
           (map (lp_cut_map
                  (\ u -> eval_term Fun u (lpc_mgu_substitution v images)))
             gs) :
           es;
lpc_no_step fuel p (LPCClause (LPCAtom a : gs) c m : es) (LPCNOBacktrack k) t =
  less_nat c (size_list p) &&
    lp_cut_check_clash fuel k a (fst (nth p c)) && t == es;
lpc_no_step fuel p (LPCGoals (LPCUnify a b : gs) : es) LPCNOUnifyFail t =
  lp_cut_check_equality fuel a b LPCAlwaysFailure && t == es;
lpc_no_step fuel p [] (LPCNOCase v) t = False;
lpc_no_step fuel p (LPCGoals [] : vb) (LPCNOCase v) t = False;
lpc_no_step fuel p (LPCGoals (LPCAtom (Var vg) : ve) : vb) (LPCNOCase v) t =
  False;
lpc_no_step fuel p (LPCGoals (LPCAtom (Fun LPCBang vh) : ve) : vb) (LPCNOCase v)
  t = False;
lpc_no_step fuel p (LPCGoals (LPCAtom (Fun LPCComma vh) : ve) : vb)
  (LPCNOCase v) t = False;
lpc_no_step fuel p (LPCGoals (LPCAtom (Fun LPCEquals vh) : ve) : vb)
  (LPCNOCase v) t = False;
lpc_no_step fuel p (LPCGoals (LPCAtom (Fun LPCTruth vh) : ve) : vb)
  (LPCNOCase v) t = False;
lpc_no_step fuel p (LPCGoals (LPCAtom (Fun LPCFailure vh) : ve) : vb)
  (LPCNOCase v) t = False;
lpc_no_step fuel p (LPCGoals (LPCAtom (Fun LPCCallSymbol vh) : ve) : vb)
  (LPCNOCase v) t = False;
lpc_no_step fuel p (LPCGoals (LPCCut vf : ve) : vb) (LPCNOCase v) t = False;
lpc_no_step fuel p (LPCGoals (LPCTrue : ve) : vb) (LPCNOCase v) t = False;
lpc_no_step fuel p (LPCGoals (LPCFail : ve) : vb) (LPCNOCase v) t = False;
lpc_no_step fuel p (LPCGoals (LPCMeta vf : ve) : vb) (LPCNOCase v) t = False;
lpc_no_step fuel p (LPCGoals (LPCExpand vf vg : ve) : vb) (LPCNOCase v) t =
  False;
lpc_no_step fuel p (LPCGoals (LPCUnify vf vg : ve) : vb) (LPCNOCase v) t =
  False;
lpc_no_step fuel p (LPCClause vc vd ve : vb) (LPCNOCase v) t = False;
lpc_no_step fuel p (LPCBarrier vc : vb) (LPCNOCase v) t = False;
lpc_no_step fuel p [] (LPCNOMeta v va) t = False;
lpc_no_step fuel p (LPCGoals [] : vc) (LPCNOMeta v va) t = False;
lpc_no_step fuel p (LPCGoals (LPCAtom vg : vf) : vc) (LPCNOMeta v va) t = False;
lpc_no_step fuel p (LPCGoals (LPCCut vg : vf) : vc) (LPCNOMeta v va) t = False;
lpc_no_step fuel p (LPCGoals (LPCTrue : vf) : vc) (LPCNOMeta v va) t = False;
lpc_no_step fuel p (LPCGoals (LPCFail : vf) : vc) (LPCNOMeta v va) t = False;
lpc_no_step fuel p (LPCGoals (LPCExpand vg vh : vf) : vc) (LPCNOMeta v va) t =
  False;
lpc_no_step fuel p (LPCGoals (LPCUnify vg vh : vf) : vc) (LPCNOMeta v va) t =
  False;
lpc_no_step fuel p (LPCClause vd ve vf : vc) (LPCNOMeta v va) t = False;
lpc_no_step fuel p (LPCBarrier vd : vc) (LPCNOMeta v va) t = False;
lpc_no_step fuel p [] (LPCNOResolve v va vb) t = False;
lpc_no_step fuel p (LPCGoals ve : vd) (LPCNOResolve v va vb) t = False;
lpc_no_step fuel p (LPCClause [] vf vg : vd) (LPCNOResolve v va vb) t = False;
lpc_no_step fuel p (LPCClause (LPCCut vj : vi) vf vg : vd)
  (LPCNOResolve v va vb) t = False;
lpc_no_step fuel p (LPCClause (LPCTrue : vi) vf vg : vd) (LPCNOResolve v va vb)
  t = False;
lpc_no_step fuel p (LPCClause (LPCFail : vi) vf vg : vd) (LPCNOResolve v va vb)
  t = False;
lpc_no_step fuel p (LPCClause (LPCMeta vj : vi) vf vg : vd)
  (LPCNOResolve v va vb) t = False;
lpc_no_step fuel p (LPCClause (LPCExpand vj vk : vi) vf vg : vd)
  (LPCNOResolve v va vb) t = False;
lpc_no_step fuel p (LPCClause (LPCUnify vj vk : vi) vf vg : vd)
  (LPCNOResolve v va vb) t = False;
lpc_no_step fuel p (LPCBarrier ve : vd) (LPCNOResolve v va vb) t = False;
lpc_no_step fuel p [] (LPCNOUnify v va) t = False;
lpc_no_step fuel p (LPCGoals [] : vc) (LPCNOUnify v va) t = False;
lpc_no_step fuel p (LPCGoals (LPCAtom vg : vf) : vc) (LPCNOUnify v va) t =
  False;
lpc_no_step fuel p (LPCGoals (LPCCut vg : vf) : vc) (LPCNOUnify v va) t = False;
lpc_no_step fuel p (LPCGoals (LPCTrue : vf) : vc) (LPCNOUnify v va) t = False;
lpc_no_step fuel p (LPCGoals (LPCFail : vf) : vc) (LPCNOUnify v va) t = False;
lpc_no_step fuel p (LPCGoals (LPCMeta vg : vf) : vc) (LPCNOUnify v va) t =
  False;
lpc_no_step fuel p (LPCGoals (LPCExpand vg vh : vf) : vc) (LPCNOUnify v va) t =
  False;
lpc_no_step fuel p (LPCClause vd ve vf : vc) (LPCNOUnify v va) t = False;
lpc_no_step fuel p (LPCBarrier vd : vc) (LPCNOUnify v va) t = False;
lpc_no_step fuel p [] (LPCNOBacktrack v) t = False;
lpc_no_step fuel p (LPCGoals vc : vb) (LPCNOBacktrack v) t = False;
lpc_no_step fuel p (LPCClause [] vd ve : vb) (LPCNOBacktrack v) t = False;
lpc_no_step fuel p (LPCClause (LPCCut vh : vg) vd ve : vb) (LPCNOBacktrack v) t
  = False;
lpc_no_step fuel p (LPCClause (LPCTrue : vg) vd ve : vb) (LPCNOBacktrack v) t =
  False;
lpc_no_step fuel p (LPCClause (LPCFail : vg) vd ve : vb) (LPCNOBacktrack v) t =
  False;
lpc_no_step fuel p (LPCClause (LPCMeta vh : vg) vd ve : vb) (LPCNOBacktrack v) t
  = False;
lpc_no_step fuel p (LPCClause (LPCExpand vh vi : vg) vd ve : vb)
  (LPCNOBacktrack v) t = False;
lpc_no_step fuel p (LPCClause (LPCUnify vh vi : vg) vd ve : vb)
  (LPCNOBacktrack v) t = False;
lpc_no_step fuel p (LPCBarrier vc : vb) (LPCNOBacktrack v) t = False;
lpc_no_step fuel p [] LPCNOUnifyFail t = False;
lpc_no_step fuel p (LPCGoals [] : va) LPCNOUnifyFail t = False;
lpc_no_step fuel p (LPCGoals (LPCAtom ve : vd) : va) LPCNOUnifyFail t = False;
lpc_no_step fuel p (LPCGoals (LPCCut ve : vd) : va) LPCNOUnifyFail t = False;
lpc_no_step fuel p (LPCGoals (LPCTrue : vd) : va) LPCNOUnifyFail t = False;
lpc_no_step fuel p (LPCGoals (LPCFail : vd) : va) LPCNOUnifyFail t = False;
lpc_no_step fuel p (LPCGoals (LPCMeta ve : vd) : va) LPCNOUnifyFail t = False;
lpc_no_step fuel p (LPCGoals (LPCExpand ve vf : vd) : va) LPCNOUnifyFail t =
  False;
lpc_no_step fuel p (LPCClause vb vc vd : va) LPCNOUnifyFail t = False;
lpc_no_step fuel p (LPCBarrier vb : va) LPCNOUnifyFail t = False;
lpc_no_step fuel p [] (LPCNOResolveSwap v va vb vc vd) t = False;
lpc_no_step fuel p (LPCGoals vg : vf) (LPCNOResolveSwap v va vb vc vd) t =
  False;
lpc_no_step fuel p (LPCClause [] vh vi : vf) (LPCNOResolveSwap v va vb vc vd) t
  = False;
lpc_no_step fuel p (LPCClause (LPCCut vl : vk) vh vi : vf)
  (LPCNOResolveSwap v va vb vc vd) t = False;
lpc_no_step fuel p (LPCClause (LPCTrue : vk) vh vi : vf)
  (LPCNOResolveSwap v va vb vc vd) t = False;
lpc_no_step fuel p (LPCClause (LPCFail : vk) vh vi : vf)
  (LPCNOResolveSwap v va vb vc vd) t = False;
lpc_no_step fuel p (LPCClause (LPCMeta vl : vk) vh vi : vf)
  (LPCNOResolveSwap v va vb vc vd) t = False;
lpc_no_step fuel p (LPCClause (LPCExpand vl vm : vk) vh vi : vf)
  (LPCNOResolveSwap v va vb vc vd) t = False;
lpc_no_step fuel p (LPCClause (LPCUnify vl vm : vk) vh vi : vf)
  (LPCNOResolveSwap v va vb vc vd) t = False;
lpc_no_step fuel p (LPCBarrier vg : vf) (LPCNOResolveSwap v va vb vc vd) t =
  False;

lpc_no_trace ::
  forall a.
    (Eq a) => Nat ->
                [(Term (Lp_cut_symbol a) [Char],
                   [Lp_cut_goal (Term (Lp_cut_symbol a) [Char])])] ->
                  [Lp_cut_entry (Term (Lp_cut_symbol a) [Char])] ->
                    [(Lpc_no_action a,
                       [Lp_cut_entry (Term (Lp_cut_symbol a) [Char])])] ->
                      [Lp_cut_entry (Term (Lp_cut_symbol a) [Char])] -> Bool;
lpc_no_trace fuel p s [] t = s == t;
lpc_no_trace fuel p s ((action, u) : rest) t =
  lpc_no_step fuel p s action u && lpc_no_trace fuel p u rest t;

lp_cut_source_goal :: forall a. Lp_cut_goal a -> Bool;
lp_cut_source_goal (LPCExpand a m) = False;
lp_cut_source_goal (LPCAtom v) = True;
lp_cut_source_goal (LPCCut v) = True;
lp_cut_source_goal LPCTrue = True;
lp_cut_source_goal LPCFail = True;
lp_cut_source_goal (LPCMeta v) = True;
lp_cut_source_goal (LPCUnify v va) = True;

lp_cut_source_program :: forall a b. [(a, [Lp_cut_goal b])] -> Bool;
lp_cut_source_program p = all (\ c -> all lp_cut_source_goal (snd c)) p;

lpc_no_suffix_safe :: forall a. [Lp_cut_entry a] -> Bool;
lpc_no_suffix_safe (LPCGoals (LPCCut m : gs) : es) = False;
lpc_no_suffix_safe [] = True;
lpc_no_suffix_safe (LPCGoals [] : va) = True;
lpc_no_suffix_safe (LPCGoals (LPCAtom ve : vd) : va) = True;
lpc_no_suffix_safe (LPCGoals (LPCTrue : vd) : va) = True;
lpc_no_suffix_safe (LPCGoals (LPCFail : vd) : va) = True;
lpc_no_suffix_safe (LPCGoals (LPCMeta ve : vd) : va) = True;
lpc_no_suffix_safe (LPCGoals (LPCExpand ve vf : vd) : va) = True;
lpc_no_suffix_safe (LPCGoals (LPCUnify ve vf : vd) : va) = True;
lpc_no_suffix_safe (LPCClause vb vc vd : va) = True;
lpc_no_suffix_safe (LPCBarrier vb : va) = True;

lp_cut_is_barrier :: forall a. Lp_cut_entry a -> Bool;
lp_cut_is_barrier (LPCBarrier m) = True;
lp_cut_is_barrier (LPCGoals v) = False;
lp_cut_is_barrier (LPCClause v va vb) = False;

lpc_no_check_source ::
  forall a.
    (Eq a) => Nat ->
                [(Term (Lp_cut_symbol a) [Char],
                   [Lp_cut_goal (Term (Lp_cut_symbol a) [Char])])] ->
                  a -> [Bool] ->
                         [Term (Lp_cut_symbol a) [Char]] ->
                           Term (Lp_cut_symbol a) [Char] ->
                             [Lp_cut_entry (Term (Lp_cut_symbol a) [Char])] ->
                               [Lp_cut_entry (Term (Lp_cut_symbol a) [Char])] ->
                                 [(Lpc_no_action a,
                                    [Lp_cut_entry
                                       (Term (Lp_cut_symbol a) [Char])])] ->
                                   [(Lpc_no_action a,
                                      [Lp_cut_entry
 (Term (Lp_cut_symbol a) [Char])])] ->
                                     Bool;
lpc_no_check_source fuel p q modes argv a before after initial_steps steps =
  lp_cut_source_program p &&
    equal_nat (size_list argv) (size_list modes) &&
      all (\ (t, b) -> (if b then ground t else True)) (zip argv modes) &&
        (all lp_cut_is_barrier before && all lp_cut_is_barrier after ||
          all (\ x -> lpc_no_suffix_safe (snd x)) steps) &&
          not (null steps) &&
            lpc_no_trace fuel p [LPCGoals [LPCAtom (Fun (LPCUser q) argv)]]
              initial_steps ([LPCGoals [LPCAtom a]] ++ before) &&
              lpc_no_trace fuel p [LPCGoals [LPCAtom a]] steps
                ([LPCGoals [LPCAtom a]] ++ after);

mapping_impl_list :: forall a. Phantom [a] Mapping_impl;
mapping_impl_list = Phantom Mapping_Choose;

lpc_symbol_parser ::
  (Xml, ([([Char], [Char])], (Bool, ([String], [String])))) ->
    Sum_bot (Xml_error String) (Lp_cut_symbol [Char]);
lpc_symbol_parser =
  xml_or (xml_change (xml_text "user") (\ s -> xml_return (LPCUser s)))
    (xml_or (xml_do "bangSymbol" (xml_return LPCBang))
      (xml_or (xml_do "commaSymbol" (xml_return LPCComma))
        (xml_or (xml_do "equalsSymbol" (xml_return LPCEquals))
          (xml_or (xml_do "trueSymbol" (xml_return LPCTruth))
            (xml_or (xml_do "failSymbol" (xml_return LPCFailure))
              (xml_do "callSymbol" (xml_return LPCCallSymbol)))))));

lpc_term_parser ::
  (Xml, ([([Char], [Char])], (Bool, ([String], [String])))) ->
    Sum_bot (Xml_error String) (Term (Lp_cut_symbol [Char]) [Char]);
lpc_term_parser =
  term lpc_symbol_parser (mapping_empty (of_phantom mapping_impl_list));

lpc_goal_parser ::
  (Xml, ([([Char], [Char])], (Bool, ([String], [String])))) ->
    Sum_bot (Xml_error String)
      (Lp_cut_goal (Term (Lp_cut_symbol [Char]) [Char]));
lpc_goal_parser =
  xml_or
    (xml_do "atom" (xml_take lpc_term_parser (\ t -> xml_return (LPCAtom t))))
    (xml_or (xml_change (xml_nat "cut") (\ m -> xml_return (LPCCut m)))
      (xml_or (xml_do "true" (xml_return LPCTrue))
        (xml_or (xml_do "fail" (xml_return LPCFail))
          (xml_or
            (xml_do "meta"
              (xml_take lpc_term_parser (\ t -> xml_return (LPCMeta t))))
            (xml_do "unify"
              (xml_take lpc_term_parser
                (\ a ->
                  xml_take lpc_term_parser
                    (\ b -> xml_return (LPCUnify a b)))))))));

lpc_entry_parser ::
  (Xml, ([([Char], [Char])], (Bool, ([String], [String])))) ->
    Sum_bot (Xml_error String)
      (Lp_cut_entry (Term (Lp_cut_symbol [Char]) [Char]));
lpc_entry_parser =
  xml_or
    (xml_change
      (xml_do "goals"
        (xml_take_many_sub [] zero_nat Infinity_enat lpc_goal_parser
          (\ a -> xml_return (id a))))
      (\ gs -> xml_return (LPCGoals gs)))
    (xml_or
      (xml_do "clauseChoice"
        (xml_take
          (xml_do "goals"
            (xml_take_many_sub [] zero_nat Infinity_enat lpc_goal_parser
              (\ a -> xml_return (id a))))
          (\ gs ->
            xml_take (xml_nat "index")
              (\ c ->
                xml_take (xml_nat "scope")
                  (\ m -> xml_return (LPCClause gs c m))))))
      (xml_change (xml_nat "barrier") (\ m -> xml_return (LPCBarrier m))));

lpc_no_action_parser ::
  (Xml, ([([Char], [Char])], (Bool, ([String], [String])))) ->
    Sum_bot (Xml_error String) (Lpc_no_action [Char]);
lpc_no_action_parser =
  xml_or (xml_do "admin" (xml_return LPCNOAdmin))
    (xml_or
      (xml_do "case"
        (xml_take (xml_nat "scope") (\ m -> xml_return (LPCNOCase m))))
      (xml_or
        (xml_do "meta"
          (xml_take (xml_nat "scope")
            (\ m ->
              xml_take
                (xml_do "body"
                  (xml_take_many_sub [] zero_nat Infinity_enat lpc_goal_parser
                    (\ a -> xml_return (id a))))
                (\ body -> xml_return (LPCNOMeta m body)))))
        (xml_or
          (xml_do "resolve"
            (xml_take (xml_nat "prefix")
              (\ k ->
                xml_take
                  (xml_do "variables"
                    (xml_take_many_sub [] zero_nat Infinity_enat
                      (xml_text "var") (\ a -> xml_return (id a))))
                  (\ v ->
                    xml_take
                      (xml_do "images"
                        (xml_take_many_sub [] zero_nat Infinity_enat
                          lpc_term_parser (\ a -> xml_return (id a))))
                      (\ images -> xml_return (LPCNOResolve k v images))))))
          (xml_or
            (xml_do "resolveSwap"
              (xml_take (xml_nat "prefix")
                (\ k ->
                  xml_take
                    (xml_do "variables"
                      (xml_take_many_sub [] zero_nat Infinity_enat
                        (xml_text "var") (\ a -> xml_return (id a))))
                    (\ v ->
                      xml_take
                        (xml_do "images"
                          (xml_take_many_sub [] zero_nat Infinity_enat
                            lpc_term_parser (\ a -> xml_return (id a))))
                        (\ images ->
                          xml_take (xml_text "from")
                            (\ x ->
                              xml_take (xml_text "to")
                                (\ y ->
                                  xml_return
                                    (LPCNOResolveSwap k v images x y))))))))
            (xml_or
              (xml_do "unify"
                (xml_take
                  (xml_do "variables"
                    (xml_take_many_sub [] zero_nat Infinity_enat
                      (xml_text "var") (\ a -> xml_return (id a))))
                  (\ v ->
                    xml_take
                      (xml_do "images"
                        (xml_take_many_sub [] zero_nat Infinity_enat
                          lpc_term_parser (\ a -> xml_return (id a))))
                      (\ images -> xml_return (LPCNOUnify v images)))))
              (xml_or
                (xml_do "backtrack"
                  (xml_take (xml_nat "prefix")
                    (\ k -> xml_return (LPCNOBacktrack k))))
                (xml_do "unifyFail" (xml_return LPCNOUnifyFail))))))));

lpc_no_trace_parser ::
  String ->
    (Xml, ([([Char], [Char])], (Bool, ([String], [String])))) ->
      Sum_bot (Xml_error String)
        [(Lpc_no_action [Char],
           [Lp_cut_entry (Term (Lp_cut_symbol [Char]) [Char])])];
lpc_no_trace_parser tag =
  xml_do tag
    (xml_take_many_sub [] zero_nat Infinity_enat
      (xml_do "step"
        (xml_take lpc_no_action_parser
          (\ a ->
            xml_take
              (xml_do "state"
                (xml_take_many_sub [] zero_nat Infinity_enat lpc_entry_parser
                  (\ aa -> xml_return (id aa))))
              (\ s -> xml_return (a, s)))))
      (\ a -> xml_return (id a)));

lpc_no_certificate_parser ::
  (Xml, ([([Char], [Char])], (Bool, ([String], [String])))) ->
    Sum_bot (Xml_error String)
      ([(Term (Lp_cut_symbol [Char]) [Char],
          [Lp_cut_goal (Term (Lp_cut_symbol [Char]) [Char])])],
        ([Char],
          ([Bool],
            (Nat, ([Term (Lp_cut_symbol [Char]) [Char]],
                    (Term (Lp_cut_symbol [Char]) [Char],
                      ([Lp_cut_entry (Term (Lp_cut_symbol [Char]) [Char])],
                        ([Lp_cut_entry (Term (Lp_cut_symbol [Char]) [Char])],
                          ([(Lpc_no_action [Char],
                              [Lp_cut_entry
                                 (Term (Lp_cut_symbol [Char]) [Char])])],
                            [(Lpc_no_action [Char],
                               [Lp_cut_entry
                                  (Term (Lp_cut_symbol [Char])
                                    [Char])])])))))))));
lpc_no_certificate_parser =
  xml_do "lpCutSourceNonterminationProof"
    (xml_take
      (xml_do "program"
        (xml_take_many_sub [] zero_nat Infinity_enat
          (xml_do "clause"
            (xml_take
              (xml_do "head"
                (xml_take lpc_term_parser (\ x -> xml_return (id x))))
              (\ h ->
                xml_take
                  (xml_do "body"
                    (xml_take_many_sub [] zero_nat Infinity_enat lpc_goal_parser
                      (\ a -> xml_return (id a))))
                  (\ body -> xml_return (h, body)))))
          (\ a -> xml_return (id a))))
      (\ p ->
        xml_take (xml_text "predicate")
          (\ q ->
            xml_take
              (xml_do "modes"
                (xml_take_many_sub [] zero_nat Infinity_enat (xml_bool "mode")
                  (\ a -> xml_return (id a))))
              (\ modes ->
                xml_take (xml_nat "fuel")
                  (\ fuel ->
                    xml_take
                      (xml_do "arguments"
                        (xml_take_many_sub [] zero_nat Infinity_enat
                          lpc_term_parser (\ a -> xml_return (id a))))
                      (\ argv ->
                        xml_take
                          (xml_do "core"
                            (xml_take lpc_term_parser
                              (\ x -> xml_return (id x))))
                          (\ a ->
                            xml_take
                              (xml_do "before"
                                (xml_take_many_sub [] zero_nat Infinity_enat
                                  lpc_entry_parser
                                  (\ aa -> xml_return (id aa))))
                              (\ before ->
                                xml_take
                                  (xml_do "after"
                                    (xml_take_many_sub [] zero_nat Infinity_enat
                                      lpc_entry_parser
                                      (\ aa -> xml_return (id aa))))
                                  (\ after ->
                                    xml_take (lpc_no_trace_parser "prefix")
                                      (\ initial_steps ->
xml_take (lpc_no_trace_parser "loop")
  (\ steps ->
    xml_return
      (p, (q, (modes,
                (fuel,
                  (argv,
                    (a, (before,
                          (after, (initial_steps, steps))))))))))))))))))));

case_sum_bot :: forall a b c. a -> (b -> a) -> (c -> a) -> Sum_bot b c -> a;
case_sum_bot f g h (Sumbot p) = (case p of {
                                  Inl a -> g a;
                                  Inr a -> h a;
                                });

check_lpc_no_xml :: [Char] -> Bool;
check_lpc_no_xml xml =
  case_sum_bot False (\ _ -> False)
    (\ (p, (q, (modes, (fuel, (argv, (a, (before, (after, (b, c))))))))) ->
      lpc_no_check_source fuel p q modes argv a before after b c)
    (parse_xml_string lpc_no_certificate_parser xml);

}
