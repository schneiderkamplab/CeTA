{-# LANGUAGE EmptyDataDecls, RankNTypes, ScopedTypeVariables #-}

module
  Higher_Order_Checker(Nat, Ho_type(..), Ho_term(..), Ho_pattern(..),
                        Ho_polynomial(..), Num, Set, Ho_step_proof(..),
                        Ho_context(..), Ho_termination_certificate(..),
                        Ho_modular_certificate(..), Ho_guarded_certificate(..),
                        nat_of_integer, ho_typeof, ho_check_step, ho_check_loop,
                        ho_polynomial_normalize, ho_meta_polynomial_residual,
                        ho_check_meta_removal,
                        ho_check_functional_access_schema,
                        ho_check_lambda_access_schema,
                        ho_check_polynomial_rule_ge,
                        ho_check_polynomial_removal, ho_check_call_comparison,
                        ho_check_component_schema, ho_check_polynomial_rule_gt,
                        ho_polynomial_residual, ho_check_semantic_schema,
                        ho_check_application, ho_check_termination,
                        ho_check_modular, ho_check_meta, ho_check_rule_pump,
                        ho_check_embedding, ho_check_plain_pump,
                        ho_check_prefix_schema, ho_check_blocked_schema,
                        ho_check_expansion_input, ho_expansion_diagnostics,
                        ho_check_lex_semantic_schema,
                        ho_check_guarded_certificate)
  where {

import Prelude ((==), (/=), (<), (<=), (>=), (>), (+), (-), (*), (/), (**),
  (>>=), (>>), (=<<), (&&), (||), (^), (^^), (.), ($), ($!), (++), (!!), Eq,
  error, id, return, not, fst, snd, map, filter, concat, concatMap, reverse,
  zip, null, takeWhile, dropWhile, all, any, Integer, negate, abs, divMod,
  String, Bool(True, False), Maybe(Nothing, Just));
import Data.Bits ((.&.), (.|.), (.^.));
import qualified Prelude;
import qualified Data.Bits;

data Nat = Zero_nat | Suc Nat;

equal_nat :: Nat -> Nat -> Bool;
equal_nat Zero_nat (Suc x2) = False;
equal_nat (Suc x2) Zero_nat = False;
equal_nat (Suc x2) (Suc y2) = equal_nat x2 y2;
equal_nat Zero_nat Zero_nat = True;

instance Eq Nat where {
  a == b = equal_nat a b;
};

plus_nat :: Nat -> Nat -> Nat;
plus_nat Zero_nat n = n;
plus_nat (Suc m) n = plus_nat m (Suc n);

times_nat :: Nat -> Nat -> Nat;
times_nat Zero_nat n = Zero_nat;
times_nat (Suc m) n = plus_nat n (times_nat m n);

class Times a where {
  times :: a -> a -> a;
};

class (Times a) => Dvd a where {
};

instance Times Nat where {
  times = times_nat;
};

instance Dvd Nat where {
};

one_nat :: Nat;
one_nat = Suc Zero_nat;

class One a where {
  one :: a;
};

instance One Nat where {
  one = one_nat;
};

class Plus a where {
  plus :: a -> a -> a;
};

instance Plus Nat where {
  plus = plus_nat;
};

class Zero a where {
  zero :: a;
};

instance Zero Nat where {
  zero = Zero_nat;
};

class (Plus a) => Semigroup_add a where {
};

class (One a, Semigroup_add a) => Numeral a where {
};

instance Semigroup_add Nat where {
};

instance Numeral Nat where {
};

class (One a, Times a) => Power a where {
};

instance Power Nat where {
};

minus_nat :: Nat -> Nat -> Nat;
minus_nat m Zero_nat = m;
minus_nat Zero_nat n = Zero_nat;
minus_nat (Suc m) (Suc n) = minus_nat m n;

class Minus a where {
  minus :: a -> a -> a;
};

instance Minus Nat where {
  minus = minus_nat;
};

less_eq_nat :: Nat -> Nat -> Bool;
less_eq_nat Zero_nat n = True;
less_eq_nat (Suc m) n = less_nat m n;

less_nat :: Nat -> Nat -> Bool;
less_nat n Zero_nat = False;
less_nat m (Suc n) = less_eq_nat m n;

class Ord a where {
  less_eq :: a -> a -> Bool;
  less :: a -> a -> Bool;
};

class (Semigroup_add a) => Cancel_semigroup_add a where {
};

class (Semigroup_add a) => Ab_semigroup_add a where {
};

class (Ab_semigroup_add a, Cancel_semigroup_add a,
        Minus a) => Cancel_ab_semigroup_add a where {
};

class (Semigroup_add a, Zero a) => Monoid_add a where {
};

class (Ab_semigroup_add a, Monoid_add a) => Comm_monoid_add a where {
};

class (Cancel_ab_semigroup_add a,
        Comm_monoid_add a) => Cancel_comm_monoid_add a where {
};

class (Times a, Zero a) => Mult_zero a where {
};

class (Times a) => Semigroup_mult a where {
};

class (Ab_semigroup_add a, Semigroup_mult a) => Semiring a where {
};

class (Comm_monoid_add a, Mult_zero a, Semiring a) => Semiring_0 a where {
};

class (Cancel_comm_monoid_add a, Semiring_0 a) => Semiring_0_cancel a where {
};

class (Semigroup_mult a) => Ab_semigroup_mult a where {
};

class (Ab_semigroup_mult a, Semiring a) => Comm_semiring a where {
};

class (Comm_semiring a, Semiring_0 a) => Comm_semiring_0 a where {
};

class (Comm_semiring_0 a,
        Semiring_0_cancel a) => Comm_semiring_0_cancel a where {
};

class (Semigroup_mult a, Power a) => Monoid_mult a where {
};

class (Monoid_mult a, Numeral a, Semiring a) => Semiring_numeral a where {
};

class (One a, Zero a) => Zero_neq_one a where {
};

class (Semiring_numeral a, Semiring_0 a, Zero_neq_one a) => Semiring_1 a where {
};

class (Semiring_0_cancel a, Semiring_1 a) => Semiring_1_cancel a where {
};

class (Ab_semigroup_mult a, Monoid_mult a, Dvd a) => Comm_monoid_mult a where {
};

class (Comm_monoid_mult a, Comm_semiring_0 a,
        Semiring_1 a) => Comm_semiring_1 a where {
};

class (Comm_semiring_0_cancel a, Comm_semiring_1 a,
        Semiring_1_cancel a) => Comm_semiring_1_cancel a where {
};

class (Ord a) => Preorder a where {
};

class (Preorder a) => Order a where {
};

class (Order a) => Linorder a where {
};

class (Linorder a, Comm_semiring_1_cancel a) => Interval a where {
};

instance Cancel_semigroup_add Nat where {
};

instance Ab_semigroup_add Nat where {
};

instance Cancel_ab_semigroup_add Nat where {
};

instance Monoid_add Nat where {
};

instance Comm_monoid_add Nat where {
};

instance Cancel_comm_monoid_add Nat where {
};

instance Mult_zero Nat where {
};

instance Semigroup_mult Nat where {
};

instance Semiring Nat where {
};

instance Semiring_0 Nat where {
};

instance Semiring_0_cancel Nat where {
};

instance Ab_semigroup_mult Nat where {
};

instance Comm_semiring Nat where {
};

instance Comm_semiring_0 Nat where {
};

instance Comm_semiring_0_cancel Nat where {
};

instance Monoid_mult Nat where {
};

instance Semiring_numeral Nat where {
};

instance Zero_neq_one Nat where {
};

instance Semiring_1 Nat where {
};

instance Semiring_1_cancel Nat where {
};

instance Comm_monoid_mult Nat where {
};

instance Comm_semiring_1 Nat where {
};

instance Comm_semiring_1_cancel Nat where {
};

instance Ord Nat where {
  less_eq = less_eq_nat;
  less = less_nat;
};

instance Preorder Nat where {
};

instance Order Nat where {
};

instance Linorder Nat where {
};

instance Interval Nat where {
};

data Ho_type = HBase Nat | HArrow Ho_type Ho_type;

equal_ho_type :: Ho_type -> Ho_type -> Bool;
equal_ho_type (HBase x1) (HArrow x21 x22) = False;
equal_ho_type (HArrow x21 x22) (HBase x1) = False;
equal_ho_type (HArrow x21 x22) (HArrow y21 y22) =
  equal_ho_type x21 y21 && equal_ho_type x22 y22;
equal_ho_type (HBase x1) (HBase y1) = equal_nat x1 y1;

data Ho_term = HBound Nat | HFree Nat | HConst Nat | HApp Ho_term Ho_term
  | HAbs Ho_type Ho_term;

equal_ho_term :: Ho_term -> Ho_term -> Bool;
equal_ho_term (HApp x41 x42) (HAbs x51 x52) = False;
equal_ho_term (HAbs x51 x52) (HApp x41 x42) = False;
equal_ho_term (HConst x3) (HAbs x51 x52) = False;
equal_ho_term (HAbs x51 x52) (HConst x3) = False;
equal_ho_term (HConst x3) (HApp x41 x42) = False;
equal_ho_term (HApp x41 x42) (HConst x3) = False;
equal_ho_term (HFree x2) (HAbs x51 x52) = False;
equal_ho_term (HAbs x51 x52) (HFree x2) = False;
equal_ho_term (HFree x2) (HApp x41 x42) = False;
equal_ho_term (HApp x41 x42) (HFree x2) = False;
equal_ho_term (HFree x2) (HConst x3) = False;
equal_ho_term (HConst x3) (HFree x2) = False;
equal_ho_term (HBound x1) (HAbs x51 x52) = False;
equal_ho_term (HAbs x51 x52) (HBound x1) = False;
equal_ho_term (HBound x1) (HApp x41 x42) = False;
equal_ho_term (HApp x41 x42) (HBound x1) = False;
equal_ho_term (HBound x1) (HConst x3) = False;
equal_ho_term (HConst x3) (HBound x1) = False;
equal_ho_term (HBound x1) (HFree x2) = False;
equal_ho_term (HFree x2) (HBound x1) = False;
equal_ho_term (HAbs x51 x52) (HAbs y51 y52) =
  equal_ho_type x51 y51 && equal_ho_term x52 y52;
equal_ho_term (HApp x41 x42) (HApp y41 y42) =
  equal_ho_term x41 y41 && equal_ho_term x42 y42;
equal_ho_term (HConst x3) (HConst y3) = equal_nat x3 y3;
equal_ho_term (HFree x2) (HFree y2) = equal_nat x2 y2;
equal_ho_term (HBound x1) (HBound y1) = equal_nat x1 y1;

instance Eq Ho_term where {
  a == b = equal_ho_term a b;
};

instance Eq Ho_type where {
  a == b = equal_ho_type a b;
};

data Ho_pattern = PBound Nat | PConst Nat | PApp Ho_pattern Ho_pattern
  | PAbs Ho_type Ho_pattern | PMeta Nat [Ho_pattern];

instance Eq Ho_pattern where {
  a == b = equal_ho_pattern a b;
};

equal_ho_pattern :: Ho_pattern -> Ho_pattern -> Bool;
equal_ho_pattern (PAbs x41 x42) (PMeta x51 x52) = False;
equal_ho_pattern (PMeta x51 x52) (PAbs x41 x42) = False;
equal_ho_pattern (PApp x31 x32) (PMeta x51 x52) = False;
equal_ho_pattern (PMeta x51 x52) (PApp x31 x32) = False;
equal_ho_pattern (PApp x31 x32) (PAbs x41 x42) = False;
equal_ho_pattern (PAbs x41 x42) (PApp x31 x32) = False;
equal_ho_pattern (PConst x2) (PMeta x51 x52) = False;
equal_ho_pattern (PMeta x51 x52) (PConst x2) = False;
equal_ho_pattern (PConst x2) (PAbs x41 x42) = False;
equal_ho_pattern (PAbs x41 x42) (PConst x2) = False;
equal_ho_pattern (PConst x2) (PApp x31 x32) = False;
equal_ho_pattern (PApp x31 x32) (PConst x2) = False;
equal_ho_pattern (PBound x1) (PMeta x51 x52) = False;
equal_ho_pattern (PMeta x51 x52) (PBound x1) = False;
equal_ho_pattern (PBound x1) (PAbs x41 x42) = False;
equal_ho_pattern (PAbs x41 x42) (PBound x1) = False;
equal_ho_pattern (PBound x1) (PApp x31 x32) = False;
equal_ho_pattern (PApp x31 x32) (PBound x1) = False;
equal_ho_pattern (PBound x1) (PConst x2) = False;
equal_ho_pattern (PConst x2) (PBound x1) = False;
equal_ho_pattern (PMeta x51 x52) (PMeta y51 y52) =
  equal_nat x51 y51 && x52 == y52;
equal_ho_pattern (PAbs x41 x42) (PAbs y41 y42) =
  equal_ho_type x41 y41 && equal_ho_pattern x42 y42;
equal_ho_pattern (PApp x31 x32) (PApp y31 y32) =
  equal_ho_pattern x31 y31 && equal_ho_pattern x32 y32;
equal_ho_pattern (PConst x2) (PConst y2) = equal_nat x2 y2;
equal_ho_pattern (PBound x1) (PBound y1) = equal_nat x1 y1;

data Ho_polynomial = HPVar Nat | HPNumber Nat Nat
  | HPAdd Nat Ho_polynomial Ho_polynomial
  | HPMultiply Nat Ho_polynomial Ho_polynomial
  | HPApply Ho_type Ho_type Ho_polynomial Ho_polynomial
  | HPAbstract Ho_type Ho_type Ho_polynomial;

equal_ho_polynomial :: Ho_polynomial -> Ho_polynomial -> Bool;
equal_ho_polynomial (HPApply x51 x52 x53 x54) (HPAbstract x61 x62 x63) = False;
equal_ho_polynomial (HPAbstract x61 x62 x63) (HPApply x51 x52 x53 x54) = False;
equal_ho_polynomial (HPMultiply x41 x42 x43) (HPAbstract x61 x62 x63) = False;
equal_ho_polynomial (HPAbstract x61 x62 x63) (HPMultiply x41 x42 x43) = False;
equal_ho_polynomial (HPMultiply x41 x42 x43) (HPApply x51 x52 x53 x54) = False;
equal_ho_polynomial (HPApply x51 x52 x53 x54) (HPMultiply x41 x42 x43) = False;
equal_ho_polynomial (HPAdd x31 x32 x33) (HPAbstract x61 x62 x63) = False;
equal_ho_polynomial (HPAbstract x61 x62 x63) (HPAdd x31 x32 x33) = False;
equal_ho_polynomial (HPAdd x31 x32 x33) (HPApply x51 x52 x53 x54) = False;
equal_ho_polynomial (HPApply x51 x52 x53 x54) (HPAdd x31 x32 x33) = False;
equal_ho_polynomial (HPAdd x31 x32 x33) (HPMultiply x41 x42 x43) = False;
equal_ho_polynomial (HPMultiply x41 x42 x43) (HPAdd x31 x32 x33) = False;
equal_ho_polynomial (HPNumber x21 x22) (HPAbstract x61 x62 x63) = False;
equal_ho_polynomial (HPAbstract x61 x62 x63) (HPNumber x21 x22) = False;
equal_ho_polynomial (HPNumber x21 x22) (HPApply x51 x52 x53 x54) = False;
equal_ho_polynomial (HPApply x51 x52 x53 x54) (HPNumber x21 x22) = False;
equal_ho_polynomial (HPNumber x21 x22) (HPMultiply x41 x42 x43) = False;
equal_ho_polynomial (HPMultiply x41 x42 x43) (HPNumber x21 x22) = False;
equal_ho_polynomial (HPNumber x21 x22) (HPAdd x31 x32 x33) = False;
equal_ho_polynomial (HPAdd x31 x32 x33) (HPNumber x21 x22) = False;
equal_ho_polynomial (HPVar x1) (HPAbstract x61 x62 x63) = False;
equal_ho_polynomial (HPAbstract x61 x62 x63) (HPVar x1) = False;
equal_ho_polynomial (HPVar x1) (HPApply x51 x52 x53 x54) = False;
equal_ho_polynomial (HPApply x51 x52 x53 x54) (HPVar x1) = False;
equal_ho_polynomial (HPVar x1) (HPMultiply x41 x42 x43) = False;
equal_ho_polynomial (HPMultiply x41 x42 x43) (HPVar x1) = False;
equal_ho_polynomial (HPVar x1) (HPAdd x31 x32 x33) = False;
equal_ho_polynomial (HPAdd x31 x32 x33) (HPVar x1) = False;
equal_ho_polynomial (HPVar x1) (HPNumber x21 x22) = False;
equal_ho_polynomial (HPNumber x21 x22) (HPVar x1) = False;
equal_ho_polynomial (HPAbstract x61 x62 x63) (HPAbstract y61 y62 y63) =
  equal_ho_type x61 y61 && equal_ho_type x62 y62 && equal_ho_polynomial x63 y63;
equal_ho_polynomial (HPApply x51 x52 x53 x54) (HPApply y51 y52 y53 y54) =
  equal_ho_type x51 y51 &&
    equal_ho_type x52 y52 &&
      equal_ho_polynomial x53 y53 && equal_ho_polynomial x54 y54;
equal_ho_polynomial (HPMultiply x41 x42 x43) (HPMultiply y41 y42 y43) =
  equal_nat x41 y41 &&
    equal_ho_polynomial x42 y42 && equal_ho_polynomial x43 y43;
equal_ho_polynomial (HPAdd x31 x32 x33) (HPAdd y31 y32 y33) =
  equal_nat x31 y31 &&
    equal_ho_polynomial x32 y32 && equal_ho_polynomial x33 y33;
equal_ho_polynomial (HPNumber x21 x22) (HPNumber y21 y22) =
  equal_nat x21 y21 && equal_nat x22 y22;
equal_ho_polynomial (HPVar x1) (HPVar y1) = equal_nat x1 y1;

instance Eq Ho_polynomial where {
  a == b = equal_ho_polynomial a b;
};

data Num = One | Bit0 Num | Bit1 Num;

data Set a = Set [a] | Coset [a];

data Ho_step_proof = HRule Nat [Ho_term] | HBeta | HLeft Ho_step_proof
  | HRight Ho_step_proof | HUnder Ho_step_proof;

data Ho_context = HHole | HCLeft Ho_context Ho_term
  | HCRight Ho_term Ho_context;

data Ho_expression = HEVar Nat | HEConst Nat
  | HEApp Ho_type Ho_type Ho_expression Ho_expression
  | HEAbs Ho_type Ho_type Ho_expression;

data Ho_termination_certificate = HOEmpty | HOApplication Nat
  | HOGeneralSchema [Nat] Nat | HOPartialSchema [Nat] [Nat] Nat
  | HOLambdaSchema [Nat] [Nat] Nat | HOPrioritySchema [Nat] [Nat] [Nat] Nat
  | HOAccessibleSchema [Nat] [Nat] [Nat] [Nat] Nat
  | HODescentSchema [Nat] [Nat] [Nat] [Nat] Nat Nat
  | HOPolynomial [Ho_polynomial] Nat Ho_termination_certificate;

data Ho_modular_certificate = HOMBase Ho_termination_certificate
  | HOMFunctional [Nat] [Nat] [Nat] [Nat] Nat
  | HOMLambda [Nat] [Nat] [Nat] [Nat] Nat
  | HOMSemantic [Ho_polynomial] [Ho_polynomial] Nat [Nat] [Nat] [Nat] [Nat] Nat
  | HOMComponent [[Ho_polynomial]] [[Ho_polynomial]] Nat [Nat] [Nat] [Nat] [Nat]
      Nat
  | HOMPolynomial [Ho_polynomial] Nat Ho_modular_certificate;

data Ho_guarded_certificate = HOGBase Ho_modular_certificate
  | HOGSchema [Nat] [Nat] [Nat] [Nat] Nat [Nat]
  | HOGPolynomial [Ho_polynomial] Nat Ho_guarded_certificate;

nth :: forall a. [a] -> Nat -> a;
nth (x : xs) Zero_nat = x;
nth (x : xs) (Suc n) = nth xs n;

upt :: Nat -> Nat -> [Nat];
upt i j = (if less_nat i j then i : upt (Suc i) j else []);

ball :: forall a. Set a -> (a -> Bool) -> Bool;
ball (Set xs) p = all p xs;

drop :: forall a. Nat -> [a] -> [a];
drop n [] = [];
drop n (x : xs) = (case n of {
                    Zero_nat -> x : xs;
                    Suc m -> drop m xs;
                  });

find :: forall a. (a -> Bool) -> [a] -> Maybe a;
find uu [] = Nothing;
find p (x : xs) = (if p x then Just x else find p xs);

fold :: forall a b. (a -> b -> b) -> [a] -> b -> b;
fold f [] s = s;
fold f (x : xs) s = fold f xs (f x s);

take :: forall a. Nat -> [a] -> [a];
take n [] = [];
take n (x : xs) = (case n of {
                    Zero_nat -> [];
                    Suc m -> x : take m xs;
                  });

image :: forall a b. (a -> b) -> Set a -> Set b;
image f (Set xs) = Set (map f xs);

foldl :: forall a b. (a -> b -> a) -> a -> [b] -> a;
foldl f a [] = a;
foldl f a (x : xs) = foldl f (f a x) xs;

foldr :: forall a b. (a -> b -> b) -> [a] -> b -> b;
foldr f [] = id;
foldr f (x : xs) = f x . foldr f xs;

map_option :: forall a b. (a -> b) -> Maybe a -> Maybe b;
map_option f Nothing = Nothing;
map_option f (Just x2) = Just (f x2);

those :: forall a. [Maybe a] -> Maybe [a];
those [] = Just [];
those (x : xs) = (case x of {
                   Nothing -> Nothing;
                   Just y -> map_option (\ a -> y : a) (those xs);
                 });

removeAll :: forall a. (Eq a) => a -> [a] -> [a];
removeAll x [] = [];
removeAll x (y : xs) = (if x == y then removeAll x xs else y : removeAll x xs);

membera :: forall a. (Eq a) => [a] -> a -> Bool;
membera [] y = False;
membera (x : xs) y = x == y || membera xs y;

inserta :: forall a. (Eq a) => a -> [a] -> [a];
inserta x xs = (if membera xs x then xs else x : xs);

insert :: forall a. (Eq a) => a -> Set a -> Set a;
insert x (Set xs) = Set (inserta x xs);
insert x (Coset xs) = Coset (removeAll x xs);

member :: forall a. (Eq a) => a -> Set a -> Bool;
member x (Set xs) = membera xs x;
member x (Coset xs) = not (membera xs x);

remove1 :: forall a. (Eq a) => a -> [a] -> [a];
remove1 x [] = [];
remove1 x (y : xs) = (if x == y then xs else y : remove1 x xs);

nat_of_num :: Num -> Nat;
nat_of_num One = one_nat;
nat_of_num (Bit0 n) = let {
                        m = nat_of_num n;
                      } in plus_nat m m;
nat_of_num (Bit1 n) = let {
                        m = nat_of_num n;
                      } in Suc (plus_nat m m);

is_none :: forall a. Maybe a -> Bool;
is_none Nothing = True;
is_none (Just x) = False;

apsnd :: forall a b c. (a -> b) -> (c, a) -> (c, b);
apsnd f (x, y) = (x, f y);

length_tailrec :: forall a. [a] -> Nat -> Nat;
length_tailrec [] n = n;
length_tailrec (x : xs) n = length_tailrec xs (Suc n);

list_all2 :: forall a b. (a -> b -> Bool) -> [a] -> [b] -> Bool;
list_all2 p [] ys = null ys;
list_all2 p xs [] = null xs;
list_all2 p (x : xs) (y : ys) = p x y && list_all2 p xs ys;

bot_set :: forall a. Set a;
bot_set = Set [];

sup_set :: forall a. (Eq a) => Set a -> Set a -> Set a;
sup_set (Set xs) a = fold insert xs a;
sup_set (Coset xs) a = Coset (filter (\ x -> not (member x a)) xs);

ho_lift :: Nat -> Nat -> Ho_term -> Ho_term;
ho_lift d k (HBound n) = HBound (if less_nat n k then n else plus_nat n d);
ho_lift d k (HFree n) = HFree n;
ho_lift d k (HConst n) = HConst n;
ho_lift d k (HApp f x) = HApp (ho_lift d k f) (ho_lift d k x);
ho_lift d k (HAbs a t) = HAbs a (ho_lift d (Suc k) t);

ho_subst :: (Nat -> Ho_term) -> Nat -> Ho_term -> Ho_term;
ho_subst s d (HBound n) = HBound n;
ho_subst s d (HFree n) = ho_lift d Zero_nat (s n);
ho_subst s d (HConst n) = HConst n;
ho_subst s d (HApp f x) = HApp (ho_subst s d f) (ho_subst s d x);
ho_subst s d (HAbs a t) = HAbs a (ho_subst s (Suc d) t);

divmod_integer :: Integer -> Integer -> (Integer, Integer);
divmod_integer k l =
  (if k == (0 :: Integer) then ((0 :: Integer), (0 :: Integer))
    else (if (0 :: Integer) < l
           then (if (0 :: Integer) < k then divMod (abs k) (abs l)
                  else (case divMod (abs k) (abs l) of {
                         (r, s) ->
                           (if s == (0 :: Integer)
                             then (negate r, (0 :: Integer))
                             else (negate r - (1 :: Integer), l - s));
                       }))
           else (if l == (0 :: Integer) then ((0 :: Integer), k)
                  else apsnd negate
                         (if k < (0 :: Integer) then divMod (abs k) (abs l)
                           else (case divMod (abs k) (abs l) of {
                                  (r, s) ->
                                    (if s == (0 :: Integer)
                                      then (negate r, (0 :: Integer))
                                      else (negate r - (1 :: Integer),
     negate l - s));
                                })))));

nat_of_integer :: Integer -> Nat;
nat_of_integer k =
  (if k <= (0 :: Integer) then Zero_nat
    else (case divmod_integer k (2 :: Integer) of {
           (l, j) ->
             let {
               la = nat_of_integer l;
               lb = plus_nat la la;
             } in (if j == (0 :: Integer) then lb else plus_nat lb one_nat);
         }));

size_list :: forall a. [a] -> Nat;
size_list xs = length_tailrec xs Zero_nat;

ho_lookup :: forall a. [a] -> Nat -> Maybe a;
ho_lookup xs n =
  (if less_nat n (size_list xs) then Just (nth xs n) else Nothing);

ho_typeof :: [Ho_type] -> [Ho_type] -> [Ho_type] -> Ho_term -> Maybe Ho_type;
ho_typeof s v b (HBound n) = ho_lookup b n;
ho_typeof s v b (HFree n) = ho_lookup v n;
ho_typeof s v b (HConst n) = ho_lookup s n;
ho_typeof s v b (HApp f x) =
  (case ho_typeof s v b f of {
    Nothing -> Nothing;
    Just (HBase _) -> Nothing;
    Just (HArrow a c) ->
      (if ho_typeof s v b x == Just a then Just c else Nothing);
  });
ho_typeof s v b (HAbs a t) = map_option (HArrow a) (ho_typeof s v (a : b) t);

insort_key :: forall a b. (Linorder b) => (a -> b) -> a -> [a] -> [a];
insort_key f x [] = [x];
insort_key f x (y : ys) =
  (if less_eq (f x) (f y) then x : y : ys else y : insort_key f x ys);

sort_key :: forall a b. (Linorder b) => (a -> b) -> [a] -> [a];
sort_key f xs = foldr (insort_key f) xs [];

less_eq_set :: forall a. (Eq a) => Set a -> Set a -> Bool;
less_eq_set (Set xs) b = all (\ x -> member x b) xs;
less_eq_set a (Coset ys) = all (\ y -> not (member y a)) ys;
less_eq_set (Coset []) (Set []) = False;

equal_set :: forall a. (Eq a) => Set a -> Set a -> Bool;
equal_set a b = less_eq_set a b && less_eq_set b a;

ho_plain :: Ho_term -> Bool;
ho_plain (HBound n) = False;
ho_plain (HFree n) = True;
ho_plain (HConst n) = True;
ho_plain (HApp f x) = ho_plain f && ho_plain x;
ho_plain (HAbs a t) = False;

ho_fill :: Ho_context -> Ho_term -> Ho_term;
ho_fill HHole t = t;
ho_fill (HCLeft c x) t = HApp (ho_fill c t) x;
ho_fill (HCRight x c) t = HApp x (ho_fill c t);

ho_beta_subst :: Ho_term -> Nat -> Ho_term -> Ho_term;
ho_beta_subst u k (HBound n) =
  (if less_nat n k then HBound n
    else (if equal_nat n k then ho_lift k Zero_nat u
           else HBound (minus_nat n one_nat)));
ho_beta_subst u k (HFree n) = HFree n;
ho_beta_subst u k (HConst n) = HConst n;
ho_beta_subst u k (HApp f x) = HApp (ho_beta_subst u k f) (ho_beta_subst u k x);
ho_beta_subst u k (HAbs a t) = HAbs a (ho_beta_subst u (Suc k) t);

ho_erase_pattern :: Ho_pattern -> Ho_term;
ho_erase_pattern (PBound n) = HBound n;
ho_erase_pattern (PConst n) = HConst n;
ho_erase_pattern (PApp f x) = HApp (ho_erase_pattern f) (ho_erase_pattern x);
ho_erase_pattern (PAbs a t) = HAbs a (ho_erase_pattern t);
ho_erase_pattern (PMeta n ts) =
  foldl (\ a x -> HApp a (ho_erase_pattern x)) (HFree n) ts;

ho_rule_welltyped :: [Ho_type] -> ([Ho_type], (Ho_pattern, Ho_pattern)) -> Bool;
ho_rule_welltyped s r =
  (case r of {
    (g, (l, u)) -> (case ho_typeof s g [] (ho_erase_pattern l) of {
                     Nothing -> False;
                     Just a -> ho_typeof s g [] (ho_erase_pattern u) == Just a;
                   });
  });

all_interval :: forall a. (Eq a, Interval a) => (a -> Bool) -> a -> a -> Bool;
all_interval p a b =
  (if less a b then p a && all_interval p (plus a one) b else True) &&
    (if a == b then p a else True);

ho_typed_subst ::
  [Ho_type] -> [Ho_type] -> [Ho_type] -> [Ho_type] -> (Nat -> Ho_term) -> Bool;
ho_typed_subst sa v b g s =
  let {
    d = minus_nat (size_list g) one_nat;
  } in (if less_nat d (size_list g)
         then all_interval (\ n -> ho_typeof sa v b (s n) == Just (nth g n))
                Zero_nat d
         else True);

ho_meta_apply :: Ho_term -> [Ho_term] -> Maybe Ho_term;
ho_meta_apply t [] = Just t;
ho_meta_apply t (u : us) =
  (case t of {
    HBound _ -> Nothing;
    HFree _ -> Nothing;
    HConst _ -> Nothing;
    HApp _ _ -> Nothing;
    HAbs _ b -> ho_meta_apply (ho_beta_subst u Zero_nat b) us;
  });

ho_instantiate :: (Nat -> Ho_term) -> Nat -> Ho_pattern -> Maybe Ho_term;
ho_instantiate s d (PBound n) = Just (HBound n);
ho_instantiate s d (PConst n) = Just (HConst n);
ho_instantiate s d (PApp f x) =
  (case ho_instantiate s d f of {
    Nothing -> Nothing;
    Just a -> map_option (HApp a) (ho_instantiate s d x);
  });
ho_instantiate s d (PAbs a t) =
  map_option (HAbs a) (ho_instantiate s (Suc d) t);
ho_instantiate s d (PMeta n ts) =
  (case those (map (ho_instantiate s d) ts) of {
    Nothing -> Nothing;
    Just a -> ho_meta_apply (ho_lift d Zero_nat (s n)) a;
  });

ho_check_step ::
  [Ho_type] ->
    [Ho_type] ->
      [([Ho_type], (Ho_pattern, Ho_pattern))] ->
        [Ho_type] -> Ho_term -> Ho_step_proof -> Maybe Ho_term;
ho_check_step s v r b t (HRule i ss) =
  (if less_nat i (size_list r)
    then (case nth r i of {
           (g, (l, ra)) ->
             (if equal_nat (size_list ss) (size_list g) &&
                   ho_rule_welltyped s (g, (l, ra)) &&
                     ho_typed_subst s v b g (nth ss) &&
                       ho_instantiate (nth ss) Zero_nat l == Just t
               then ho_instantiate (nth ss) Zero_nat ra else Nothing);
         })
    else Nothing);
ho_check_step s v r b t HBeta =
  (case t of {
    HBound _ -> Nothing;
    HFree _ -> Nothing;
    HConst _ -> Nothing;
    HApp (HBound _) _ -> Nothing;
    HApp (HFree _) _ -> Nothing;
    HApp (HConst _) _ -> Nothing;
    HApp (HApp _ _) _ -> Nothing;
    HApp (HAbs _ ba) u -> Just (ho_beta_subst u Zero_nat ba);
    HAbs _ _ -> Nothing;
  });
ho_check_step s v r b t (HLeft p) =
  (case t of {
    HBound _ -> Nothing;
    HFree _ -> Nothing;
    HConst _ -> Nothing;
    HApp f x -> map_option (\ u -> HApp u x) (ho_check_step s v r b f p);
    HAbs _ _ -> Nothing;
  });
ho_check_step s v r b t (HRight p) =
  (case t of {
    HBound _ -> Nothing;
    HFree _ -> Nothing;
    HConst _ -> Nothing;
    HApp f x -> map_option (HApp f) (ho_check_step s v r b x p);
    HAbs _ _ -> Nothing;
  });
ho_check_step s v r b t (HUnder p) =
  (case t of {
    HBound _ -> Nothing;
    HFree _ -> Nothing;
    HConst _ -> Nothing;
    HApp _ _ -> Nothing;
    HAbs a ba -> map_option (HAbs a) (ho_check_step s v r (a : b) ba p);
  });

ho_check_path ::
  [Ho_type] ->
    [Ho_type] ->
      [([Ho_type], (Ho_pattern, Ho_pattern))] ->
        Ho_type -> Ho_term -> [Ho_step_proof] -> Maybe Ho_term;
ho_check_path s v r a t [] = Just t;
ho_check_path s v r a t (p : ps) =
  (case ho_check_step s v r [] t p of {
    Nothing -> Nothing;
    Just u ->
      (if ho_typeof s v [] t == Just a && ho_typeof s v [] u == Just a
        then ho_check_path s v r a u ps else Nothing);
  });

ho_check_loop ::
  [Ho_type] ->
    [Ho_type] ->
      [([Ho_type], (Ho_pattern, Ho_pattern))] ->
        Ho_type -> Ho_term -> [Ho_step_proof] -> Bool;
ho_check_loop s v r a t ps =
  not (null ps) && ho_check_path s v r a t ps == Just t;

ho_closed_at :: Nat -> Ho_term -> Bool;
ho_closed_at d (HBound n) = less_nat n d;
ho_closed_at d (HFree n) = False;
ho_closed_at d (HConst n) = True;
ho_closed_at d (HApp f x) = ho_closed_at d f && ho_closed_at d x;
ho_closed_at d (HAbs a t) = ho_closed_at (Suc d) t;

ho_plain_pattern :: Ho_pattern -> Bool;
ho_plain_pattern (PConst n) = True;
ho_plain_pattern (PApp f x) = ho_plain_pattern f && ho_plain_pattern x;
ho_plain_pattern (PMeta n ts) = null ts;
ho_plain_pattern (PBound v) = False;
ho_plain_pattern (PAbs v va) = False;

sup_seta :: forall a. (Eq a) => Set (Set a) -> Set a;
sup_seta (Set xs) = fold sup_set xs bot_set;

ho_nat_poly_times ::
  forall a b. (Times a) => [(a, [b])] -> [(a, [b])] -> [(a, [b])];
ho_nat_poly_times p q =
  concatMap (\ (c, m) -> map (\ (d, n) -> (times c d, m ++ n)) q) p;

ho_polynomial_coefficients :: Ho_polynomial -> [(Nat, [Ho_polynomial])];
ho_polynomial_coefficients (HPNumber b n) = [(n, [])];
ho_polynomial_coefficients (HPAdd b p q) =
  ho_polynomial_coefficients p ++ ho_polynomial_coefficients q;
ho_polynomial_coefficients (HPMultiply b p q) =
  ho_nat_poly_times (ho_polynomial_coefficients p)
    (ho_polynomial_coefficients q);
ho_polynomial_coefficients (HPVar v) = [(one_nat, [HPVar v])];
ho_polynomial_coefficients (HPApply v va vb vc) =
  [(one_nat, [HPApply v va vb vc])];
ho_polynomial_coefficients (HPAbstract v va vb) =
  [(one_nat, [HPAbstract v va vb])];

ho_poly_positive_constant :: forall a b. (Zero a, Ord a) => [(a, [b])] -> Bool;
ho_poly_positive_constant p = any (\ (c, m) -> less zero c && null m) p;

ho_monomial_match :: forall a. (Eq a) => [a] -> [a] -> Bool;
ho_monomial_match [] ys = null ys;
ho_monomial_match (x : xs) ys =
  membera ys x && ho_monomial_match xs (remove1 x ys);

ho_poly_subtract_term ::
  forall a b.
    (Minus a, Zero a, Eq a, Ord a,
      Eq b) => a -> [b] -> [(a, [b])] -> Maybe [(a, [b])];
ho_poly_subtract_term c m [] = (if c == zero then Just [] else Nothing);
ho_poly_subtract_term c m ((d, n) : p) =
  (if ho_monomial_match m n
    then (if less_eq c d then Just ((minus d c, n) : p)
           else ho_poly_subtract_term (minus c d) m p)
    else map_option (\ a -> (d, n) : a) (ho_poly_subtract_term c m p));

ho_poly_subtract ::
  forall a b.
    (Minus a, Zero a, Eq a, Ord a,
      Eq b) => [(a, [b])] -> [(a, [b])] -> Maybe [(a, [b])];
ho_poly_subtract p [] = Just p;
ho_poly_subtract p ((c, m) : q) = (case ho_poly_subtract_term c m p of {
                                    Nothing -> Nothing;
                                    Just r -> ho_poly_subtract r q;
                                  });

ho_check_nat_poly_gt ::
  forall a b.
    (Minus a, Zero a, Eq a, Ord a, Eq b) => [(a, [b])] -> [(a, [b])] -> Bool;
ho_check_nat_poly_gt p q = (case ho_poly_subtract p q of {
                             Nothing -> False;
                             Just a -> ho_poly_positive_constant a;
                           });

ho_polynomial_typeof :: [Ho_type] -> Ho_polynomial -> Maybe Ho_type;
ho_polynomial_typeof g (HPVar n) = ho_lookup g n;
ho_polynomial_typeof g (HPNumber b n) = Just (HBase b);
ho_polynomial_typeof g (HPAdd b p q) =
  (case (ho_polynomial_typeof g p, ho_polynomial_typeof g q) of {
    (Nothing, _) -> Nothing;
    (Just (HBase _), Nothing) -> Nothing;
    (Just (HBase _), Just (HBase _)) -> Just (HBase b);
    (Just (HBase _), Just (HArrow _ _)) -> Nothing;
    (Just (HArrow _ _), _) -> Nothing;
  });
ho_polynomial_typeof g (HPMultiply b p q) =
  (case (ho_polynomial_typeof g p, ho_polynomial_typeof g q) of {
    (Nothing, _) -> Nothing;
    (Just (HBase _), Nothing) -> Nothing;
    (Just (HBase _), Just (HBase _)) -> Just (HBase b);
    (Just (HBase _), Just (HArrow _ _)) -> Nothing;
    (Just (HArrow _ _), _) -> Nothing;
  });
ho_polynomial_typeof g (HPApply a b f x) =
  (if ho_polynomial_typeof g f == Just (HArrow a b) &&
        ho_polynomial_typeof g x == Just a
    then Just b else Nothing);
ho_polynomial_typeof g (HPAbstract a b t) =
  (if ho_polynomial_typeof (a : g) t == Just b then Just (HArrow a b)
    else Nothing);

ho_check_base_polynomial_gt ::
  [Ho_type] -> Nat -> Ho_polynomial -> Ho_polynomial -> Bool;
ho_check_base_polynomial_gt g b p q =
  ho_polynomial_typeof g p == Just (HBase b) &&
    ho_polynomial_typeof g q == Just (HBase b) &&
      ho_check_nat_poly_gt (ho_polynomial_coefficients p)
        (ho_polynomial_coefficients q);

ho_rename_up :: (Nat -> Nat) -> Nat -> Nat;
ho_rename_up r n = (case n of {
                     Zero_nat -> Zero_nat;
                     Suc k -> Suc (r k);
                   });

ho_polynomial_rename :: (Nat -> Nat) -> Ho_polynomial -> Ho_polynomial;
ho_polynomial_rename r (HPVar n) = HPVar (r n);
ho_polynomial_rename r (HPNumber b n) = HPNumber b n;
ho_polynomial_rename r (HPAdd b p q) =
  HPAdd b (ho_polynomial_rename r p) (ho_polynomial_rename r q);
ho_polynomial_rename r (HPMultiply b p q) =
  HPMultiply b (ho_polynomial_rename r p) (ho_polynomial_rename r q);
ho_polynomial_rename r (HPApply a b f x) =
  HPApply a b (ho_polynomial_rename r f) (ho_polynomial_rename r x);
ho_polynomial_rename r (HPAbstract a b t) =
  HPAbstract a b (ho_polynomial_rename (ho_rename_up r) t);

ho_polynomial_subst_up :: (Nat -> Ho_polynomial) -> Nat -> Ho_polynomial;
ho_polynomial_subst_up s n = (case n of {
                               Zero_nat -> HPVar Zero_nat;
                               Suc k -> ho_polynomial_rename Suc (s k);
                             });

ho_polynomial_subst :: (Nat -> Ho_polynomial) -> Ho_polynomial -> Ho_polynomial;
ho_polynomial_subst s (HPVar n) = s n;
ho_polynomial_subst s (HPNumber b n) = HPNumber b n;
ho_polynomial_subst s (HPAdd b p q) =
  HPAdd b (ho_polynomial_subst s p) (ho_polynomial_subst s q);
ho_polynomial_subst s (HPMultiply b p q) =
  HPMultiply b (ho_polynomial_subst s p) (ho_polynomial_subst s q);
ho_polynomial_subst s (HPApply a b f x) =
  HPApply a b (ho_polynomial_subst s f) (ho_polynomial_subst s x);
ho_polynomial_subst s (HPAbstract a b t) =
  HPAbstract a b (ho_polynomial_subst (ho_polynomial_subst_up s) t);

ho_polynomial_beta_subst :: Ho_polynomial -> Ho_polynomial -> Ho_polynomial;
ho_polynomial_beta_subst x t =
  ho_polynomial_subst (\ a -> (case a of {
                                Zero_nat -> x;
                                Suc aa -> HPVar aa;
                              }))
    t;

ho_polynomial_contract :: Ho_polynomial -> Ho_polynomial;
ho_polynomial_contract (HPApply a b (HPAbstract c d t) x) =
  ho_polynomial_beta_subst x t;
ho_polynomial_contract (HPAdd b (HPNumber c n) (HPNumber d m)) =
  HPNumber b (plus_nat n m);
ho_polynomial_contract (HPMultiply b (HPNumber c n) (HPNumber d m)) =
  HPNumber b (times_nat n m);
ho_polynomial_contract (HPVar v) = HPVar v;
ho_polynomial_contract (HPNumber v va) = HPNumber v va;
ho_polynomial_contract (HPAdd v (HPVar vc) vb) = HPAdd v (HPVar vc) vb;
ho_polynomial_contract (HPAdd v (HPAdd vc vd ve) vb) =
  HPAdd v (HPAdd vc vd ve) vb;
ho_polynomial_contract (HPAdd v (HPMultiply vc vd ve) vb) =
  HPAdd v (HPMultiply vc vd ve) vb;
ho_polynomial_contract (HPAdd v (HPApply vc vd ve vf) vb) =
  HPAdd v (HPApply vc vd ve vf) vb;
ho_polynomial_contract (HPAdd v (HPAbstract vc vd ve) vb) =
  HPAdd v (HPAbstract vc vd ve) vb;
ho_polynomial_contract (HPAdd v va (HPVar vc)) = HPAdd v va (HPVar vc);
ho_polynomial_contract (HPAdd v va (HPAdd vc vd ve)) =
  HPAdd v va (HPAdd vc vd ve);
ho_polynomial_contract (HPAdd v va (HPMultiply vc vd ve)) =
  HPAdd v va (HPMultiply vc vd ve);
ho_polynomial_contract (HPAdd v va (HPApply vc vd ve vf)) =
  HPAdd v va (HPApply vc vd ve vf);
ho_polynomial_contract (HPAdd v va (HPAbstract vc vd ve)) =
  HPAdd v va (HPAbstract vc vd ve);
ho_polynomial_contract (HPMultiply v (HPVar vc) vb) =
  HPMultiply v (HPVar vc) vb;
ho_polynomial_contract (HPMultiply v (HPAdd vc vd ve) vb) =
  HPMultiply v (HPAdd vc vd ve) vb;
ho_polynomial_contract (HPMultiply v (HPMultiply vc vd ve) vb) =
  HPMultiply v (HPMultiply vc vd ve) vb;
ho_polynomial_contract (HPMultiply v (HPApply vc vd ve vf) vb) =
  HPMultiply v (HPApply vc vd ve vf) vb;
ho_polynomial_contract (HPMultiply v (HPAbstract vc vd ve) vb) =
  HPMultiply v (HPAbstract vc vd ve) vb;
ho_polynomial_contract (HPMultiply v va (HPVar vc)) =
  HPMultiply v va (HPVar vc);
ho_polynomial_contract (HPMultiply v va (HPAdd vc vd ve)) =
  HPMultiply v va (HPAdd vc vd ve);
ho_polynomial_contract (HPMultiply v va (HPMultiply vc vd ve)) =
  HPMultiply v va (HPMultiply vc vd ve);
ho_polynomial_contract (HPMultiply v va (HPApply vc vd ve vf)) =
  HPMultiply v va (HPApply vc vd ve vf);
ho_polynomial_contract (HPMultiply v va (HPAbstract vc vd ve)) =
  HPMultiply v va (HPAbstract vc vd ve);
ho_polynomial_contract (HPApply v va (HPVar vd) vc) =
  HPApply v va (HPVar vd) vc;
ho_polynomial_contract (HPApply v va (HPNumber vd ve) vc) =
  HPApply v va (HPNumber vd ve) vc;
ho_polynomial_contract (HPApply v va (HPAdd vd ve vf) vc) =
  HPApply v va (HPAdd vd ve vf) vc;
ho_polynomial_contract (HPApply v va (HPMultiply vd ve vf) vc) =
  HPApply v va (HPMultiply vd ve vf) vc;
ho_polynomial_contract (HPApply v va (HPApply vd ve vf vg) vc) =
  HPApply v va (HPApply vd ve vf vg) vc;
ho_polynomial_contract (HPAbstract v va vb) = HPAbstract v va vb;

ho_polynomial_normalize :: Nat -> Ho_polynomial -> Ho_polynomial;
ho_polynomial_normalize Zero_nat p = p;
ho_polynomial_normalize (Suc n) (HPVar k) = HPVar k;
ho_polynomial_normalize (Suc n) (HPNumber b k) = HPNumber b k;
ho_polynomial_normalize (Suc n) (HPAdd b p q) =
  ho_polynomial_contract
    (HPAdd b (ho_polynomial_normalize n p) (ho_polynomial_normalize n q));
ho_polynomial_normalize (Suc n) (HPMultiply b p q) =
  ho_polynomial_contract
    (HPMultiply b (ho_polynomial_normalize n p) (ho_polynomial_normalize n q));
ho_polynomial_normalize (Suc n) (HPApply a b f x) =
  let {
    q = HPApply a b (ho_polynomial_normalize n f) (ho_polynomial_normalize n x);
    r = ho_polynomial_contract q;
  } in (if equal_ho_polynomial r q then q else ho_polynomial_normalize n r);
ho_polynomial_normalize (Suc n) (HPAbstract a b t) =
  HPAbstract a b (ho_polynomial_normalize n t);

ho_check_nat_poly_ge ::
  forall a b.
    (Minus a, Zero a, Eq a, Ord a, Eq b) => [(a, [b])] -> [(a, [b])] -> Bool;
ho_check_nat_poly_ge p q = not (is_none (ho_poly_subtract p q));

ho_check_base_polynomial_ge ::
  [Ho_type] -> Nat -> Ho_polynomial -> Ho_polynomial -> Bool;
ho_check_base_polynomial_ge g b p q =
  ho_polynomial_typeof g p == Just (HBase b) &&
    ho_polynomial_typeof g q == Just (HBase b) &&
      ho_check_nat_poly_ge (ho_polynomial_coefficients p)
        (ho_polynomial_coefficients q);

ho_structural_polynomial_ge ::
  Nat -> [Ho_type] -> Ho_type -> Ho_polynomial -> Ho_polynomial -> Bool;
ho_structural_polynomial_ge Zero_nat g a p q =
  equal_ho_polynomial p q && ho_polynomial_typeof g p == Just a;
ho_structural_polynomial_ge (Suc fuel) g a p q =
  ho_polynomial_typeof g p == Just a &&
    ho_polynomial_typeof g q == Just a &&
      (equal_ho_polynomial p q ||
        ((case a of {
           HBase b -> ho_check_base_polynomial_ge g b p q;
           HArrow b c ->
             ho_structural_polynomial_ge fuel (b : g) c
               (ho_polynomial_normalize
                 (nat_of_num (Bit0 (Bit0 (Bit0 (Bit0 One)))))
                 (HPApply b c (ho_polynomial_rename Suc p) (HPVar Zero_nat)))
               (ho_polynomial_normalize
                 (nat_of_num (Bit0 (Bit0 (Bit0 (Bit0 One)))))
                 (HPApply b c (ho_polynomial_rename Suc q) (HPVar Zero_nat)));
         }) ||
          (case (p, q) of {
            (HPVar _, _) -> False;
            (HPNumber _ _, _) -> False;
            (HPAdd _ _ _, _) -> False;
            (HPMultiply _ _ _, _) -> False;
            (HPApply _ _ _ _, HPVar _) -> False;
            (HPApply _ _ _ _, HPNumber _ _) -> False;
            (HPApply _ _ _ _, HPAdd _ _ _) -> False;
            (HPApply _ _ _ _, HPMultiply _ _ _) -> False;
            (HPApply ba c f x, HPApply d e ga y) ->
              equal_ho_type ba d &&
                equal_ho_type c a &&
                  equal_ho_type e a &&
                    ho_structural_polynomial_ge fuel g (HArrow ba a) f ga &&
                      ho_structural_polynomial_ge fuel g ba x y;
            (HPApply _ _ _ _, HPAbstract _ _ _) -> False;
            (HPAbstract _ _ _, _) -> False;
          })));

ho_function_atom_dominates ::
  [Ho_type] -> Ho_polynomial -> Ho_polynomial -> Bool;
ho_function_atom_dominates ga (HPApply (HBase a) (HBase b) f x)
  (HPApply (HBase c) (HBase d) g y) =
  equal_nat a c &&
    equal_nat b d &&
      equal_ho_polynomial f g &&
        ho_polynomial_typeof ga f == Just (HArrow (HBase a) (HBase b)) &&
          ho_check_base_polynomial_ge ga a x y;
ho_function_atom_dominates g (HPVar v) q = equal_ho_polynomial (HPVar v) q;
ho_function_atom_dominates g (HPNumber v va) q =
  equal_ho_polynomial (HPNumber v va) q;
ho_function_atom_dominates g (HPAdd v va vb) q =
  equal_ho_polynomial (HPAdd v va vb) q;
ho_function_atom_dominates g (HPMultiply v va vb) q =
  equal_ho_polynomial (HPMultiply v va vb) q;
ho_function_atom_dominates g (HPApply (HArrow vd ve) va vb vc) q =
  equal_ho_polynomial (HPApply (HArrow vd ve) va vb vc) q;
ho_function_atom_dominates g (HPApply v (HArrow vd ve) vb vc) q =
  equal_ho_polynomial (HPApply v (HArrow vd ve) vb vc) q;
ho_function_atom_dominates g (HPAbstract v va vb) q =
  equal_ho_polynomial (HPAbstract v va vb) q;
ho_function_atom_dominates g p (HPVar v) = equal_ho_polynomial p (HPVar v);
ho_function_atom_dominates g p (HPNumber v va) =
  equal_ho_polynomial p (HPNumber v va);
ho_function_atom_dominates g p (HPAdd v va vb) =
  equal_ho_polynomial p (HPAdd v va vb);
ho_function_atom_dominates g p (HPMultiply v va vb) =
  equal_ho_polynomial p (HPMultiply v va vb);
ho_function_atom_dominates g p (HPApply (HArrow vd ve) va vb vc) =
  equal_ho_polynomial p (HPApply (HArrow vd ve) va vb vc);
ho_function_atom_dominates g p (HPApply v (HArrow vd ve) vb vc) =
  equal_ho_polynomial p (HPApply v (HArrow vd ve) vb vc);
ho_function_atom_dominates g p (HPAbstract v va vb) =
  equal_ho_polynomial p (HPAbstract v va vb);

ho_curried_atom_dominates ::
  [Ho_type] -> Ho_polynomial -> Ho_polynomial -> Bool;
ho_curried_atom_dominates g p q =
  ho_function_atom_dominates g p q ||
    (case ho_polynomial_typeof g p of {
      Nothing -> False;
      Just (HBase b) ->
        ho_structural_polynomial_ge (nat_of_num (Bit0 (Bit0 (Bit0 (Bit0 One)))))
          g (HBase b) p q;
      Just (HArrow _ _) -> False;
    });

ho_monomial_dominates ::
  forall a b. (Eq b) => (a -> b -> Bool) -> [a] -> [b] -> Bool;
ho_monomial_dominates r [] ys = null ys;
ho_monomial_dominates r (x : xs) ys =
  any (\ y -> r x y && ho_monomial_dominates r xs (remove1 y ys)) ys;

ho_poly_consume_term ::
  forall a b c.
    (Eq b, Minus c, Zero c, Eq c,
      Ord c) => (a -> b -> Bool) -> c -> [b] -> [(c, [a])] -> Maybe [(c, [a])];
ho_poly_consume_term r c m [] = (if c == zero then Just [] else Nothing);
ho_poly_consume_term r c m ((d, n) : p) =
  (if ho_monomial_dominates r n m
    then (if less_eq c d then Just ((minus d c, n) : p)
           else ho_poly_consume_term r (minus c d) m p)
    else map_option (\ a -> (d, n) : a) (ho_poly_consume_term r c m p));

ho_poly_consume ::
  forall a b c.
    (Eq b, Minus c, Zero c, Eq c,
      Ord c) => (a -> b -> Bool) ->
                  [(c, [a])] -> [(c, [b])] -> Maybe [(c, [a])];
ho_poly_consume r p [] = Just p;
ho_poly_consume r p ((c, m) : q) = (case ho_poly_consume_term r c m p of {
                                     Nothing -> Nothing;
                                     Just ra -> ho_poly_consume r ra q;
                                   });

ho_check_monotone_base_gt ::
  [Ho_type] -> Nat -> Ho_polynomial -> Ho_polynomial -> Bool;
ho_check_monotone_base_gt g b p q =
  ho_polynomial_typeof g p == Just (HBase b) &&
    ho_polynomial_typeof g q == Just (HBase b) &&
      (case ho_poly_consume (ho_curried_atom_dominates g)
              (ho_polynomial_coefficients p) (ho_polynomial_coefficients q)
        of {
        Nothing -> False;
        Just a -> ho_poly_positive_constant a;
      });

ho_check_polynomial_gt ::
  Nat -> [Ho_type] -> Ho_type -> Ho_polynomial -> Ho_polynomial -> Bool;
ho_check_polynomial_gt fuel g (HBase b) p q =
  ho_check_base_polynomial_gt g b (ho_polynomial_normalize fuel p)
    (ho_polynomial_normalize fuel q) ||
    ho_check_monotone_base_gt g b (ho_polynomial_normalize fuel p)
      (ho_polynomial_normalize fuel q);
ho_check_polynomial_gt fuel g (HArrow a b) p q =
  ho_check_polynomial_gt fuel (a : g) b
    (HPApply a b (ho_polynomial_rename Suc p) (HPVar Zero_nat))
    (HPApply a b (ho_polynomial_rename Suc q) (HPVar Zero_nat));

ho_polynomial_raise ::
  Ho_type -> Ho_polynomial -> Ho_polynomial -> Ho_polynomial;
ho_polynomial_raise (HBase b) p c = HPAdd b p c;
ho_polynomial_raise (HArrow a b) p c =
  HPAbstract a b
    (ho_polynomial_raise b
      (HPApply a b (ho_polynomial_rename Suc p) (HPVar Zero_nat))
      (ho_polynomial_rename Suc c));

ho_polynomial_zero :: Ho_type -> Ho_polynomial;
ho_polynomial_zero (HBase b) = HPNumber b Zero_nat;
ho_polynomial_zero (HArrow a b) = HPAbstract a b (ho_polynomial_zero b);

ho_polynomial_lower :: Ho_type -> Ho_polynomial -> Ho_polynomial;
ho_polynomial_lower (HBase b) p = p;
ho_polynomial_lower (HArrow a b) p =
  ho_polynomial_lower b (HPApply a b p (ho_polynomial_zero a));

ho_meta_polynomial_spine ::
  Ho_type -> Ho_polynomial -> [Ho_polynomial] -> Ho_polynomial;
ho_meta_polynomial_spine t p [] = p;
ho_meta_polynomial_spine t p (q : qs) =
  (case t of {
    HBase _ -> HPNumber Zero_nat Zero_nat;
    HArrow a c -> ho_meta_polynomial_spine c (HPApply a c p q) qs;
  });

ho_meta_polynomial ::
  [Ho_type] ->
    [Ho_type] -> [Ho_type] -> [Ho_polynomial] -> Ho_pattern -> Ho_polynomial;
ho_meta_polynomial s g d ps (PBound n) = HPVar n;
ho_meta_polynomial s g d ps (PConst n) =
  (if less_nat n (size_list ps) then nth ps n else HPNumber Zero_nat Zero_nat);
ho_meta_polynomial s g d ps (PApp p q) =
  (case ho_typeof s g d (ho_erase_pattern p) of {
    Nothing -> HPNumber Zero_nat Zero_nat;
    Just (HBase _) -> HPNumber Zero_nat Zero_nat;
    Just (HArrow a c) ->
      ho_polynomial_raise c
        (HPApply a c (ho_meta_polynomial s g d ps p)
          (ho_meta_polynomial s g d ps q))
        (ho_polynomial_lower a (ho_meta_polynomial s g d ps q));
  });
ho_meta_polynomial s g d ps (PAbs a p) =
  (case ho_typeof s g (a : d) (ho_erase_pattern p) of {
    Nothing -> HPNumber Zero_nat Zero_nat;
    Just c -> HPAbstract a c (ho_meta_polynomial s g (a : d) ps p);
  });
ho_meta_polynomial s g d ps (PMeta n qs) =
  (case ho_lookup g n of {
    Nothing -> HPNumber Zero_nat Zero_nat;
    Just t ->
      ho_meta_polynomial_spine t (HPVar (plus_nat (size_list d) n))
        (map (ho_meta_polynomial s g d ps) qs);
  });

ho_meta_rule_polynomial ::
  [Ho_type] -> [Ho_polynomial] -> [Ho_type] -> Ho_pattern -> Ho_polynomial;
ho_meta_rule_polynomial s ps g p = ho_meta_polynomial s g [] ps p;

ho_check_meta_rule_gt ::
  [Ho_type] ->
    [Ho_polynomial] -> Nat -> [Ho_type] -> Ho_pattern -> Ho_pattern -> Bool;
ho_check_meta_rule_gt s ps fuel g l r =
  (case ho_typeof s g [] (ho_erase_pattern l) of {
    Nothing -> False;
    Just a ->
      ho_typeof s g [] (ho_erase_pattern r) == Just a &&
        ho_check_polynomial_gt fuel g a (ho_meta_rule_polynomial s ps g l)
          (ho_meta_rule_polynomial s ps g r);
  });

ho_meta_polynomial_residual ::
  [Ho_type] ->
    [Ho_polynomial] ->
      Nat ->
        [([Ho_type], (Ho_pattern, Ho_pattern))] ->
          [([Ho_type], (Ho_pattern, Ho_pattern))];
ho_meta_polynomial_residual s ps fuel r =
  filter (\ (g, (l, ra)) -> not (ho_check_meta_rule_gt s ps fuel g l ra)) r;

ho_check_polynomial_signature :: [Ho_type] -> [Ho_polynomial] -> Bool;
ho_check_polynomial_signature s ps =
  equal_nat (size_list ps) (size_list s) &&
    all (\ n -> ho_polynomial_typeof [] (nth ps n) == Just (nth s n))
      (upt Zero_nat (size_list s));

ho_check_monotone_base_ge ::
  [Ho_type] -> Nat -> Ho_polynomial -> Ho_polynomial -> Bool;
ho_check_monotone_base_ge g b p q =
  ho_polynomial_typeof g p == Just (HBase b) &&
    ho_polynomial_typeof g q == Just (HBase b) &&
      not (is_none
            (ho_poly_consume (ho_curried_atom_dominates g)
              (ho_polynomial_coefficients p) (ho_polynomial_coefficients q)));

ho_check_polynomial_ge ::
  Nat -> [Ho_type] -> Ho_type -> Ho_polynomial -> Ho_polynomial -> Bool;
ho_check_polynomial_ge fuel g (HBase b) p q =
  ho_check_base_polynomial_ge g b (ho_polynomial_normalize fuel p)
    (ho_polynomial_normalize fuel q) ||
    ho_check_monotone_base_ge g b (ho_polynomial_normalize fuel p)
      (ho_polynomial_normalize fuel q);
ho_check_polynomial_ge fuel g (HArrow a b) p q =
  ho_check_polynomial_ge fuel (a : g) b
    (HPApply a b (ho_polynomial_rename Suc p) (HPVar Zero_nat))
    (HPApply a b (ho_polynomial_rename Suc q) (HPVar Zero_nat));

ho_check_meta_rule_ge ::
  [Ho_type] ->
    [Ho_polynomial] -> Nat -> [Ho_type] -> Ho_pattern -> Ho_pattern -> Bool;
ho_check_meta_rule_ge s ps fuel g l r =
  (case ho_typeof s g [] (ho_erase_pattern l) of {
    Nothing -> False;
    Just a ->
      ho_typeof s g [] (ho_erase_pattern r) == Just a &&
        ho_check_polynomial_ge fuel g a (ho_meta_rule_polynomial s ps g l)
          (ho_meta_rule_polynomial s ps g r);
  });

ho_check_meta_removal ::
  [Ho_type] ->
    [Ho_polynomial] -> Nat -> [([Ho_type], (Ho_pattern, Ho_pattern))] -> Bool;
ho_check_meta_removal s ps fuel r =
  ho_check_polynomial_signature s ps &&
    all (\ (g, (a, b)) -> ho_check_meta_rule_ge s ps fuel g a b) r;

ho_application_rule ::
  Ho_type -> Ho_type -> Nat -> ([Ho_type], (Ho_pattern, Ho_pattern));
ho_application_rule a b c =
  ([HArrow a b, a],
    (PApp (PApp (PConst c) (PMeta Zero_nat [])) (PMeta one_nat []),
      PApp (PMeta Zero_nat []) (PMeta one_nat [])));

ho_application_unwrap ::
  [Ho_type] ->
    [Ho_type] ->
      [([Ho_type], (Ho_pattern, Ho_pattern))] ->
        [Ho_type] -> Ho_term -> Maybe Ho_term;
ho_application_unwrap s g r d u =
  (case u of {
    HBound _ -> Nothing;
    HFree _ -> Nothing;
    HConst _ -> Nothing;
    HApp (HBound _) _ -> Nothing;
    HApp (HFree _) _ -> Nothing;
    HApp (HConst _) _ -> Nothing;
    HApp (HApp (HBound _) _) _ -> Nothing;
    HApp (HApp (HFree _) _) _ -> Nothing;
    HApp (HApp (HConst c) f) x ->
      (case ho_typeof s g d f of {
        Nothing -> Nothing;
        Just (HBase _) -> Nothing;
        Just (HArrow a ca) ->
          (if ho_typeof s g d x == Just a &&
                ho_lookup s c == Just (HArrow (HArrow a ca) (HArrow a ca)) &&
                  membera r (ho_application_rule a ca c)
            then Just (HApp f x) else Nothing);
      });
    HApp (HApp (HApp _ _) _) _ -> Nothing;
    HApp (HApp (HAbs _ _) _) _ -> Nothing;
    HApp (HAbs _ _) _ -> Nothing;
    HAbs _ _ -> Nothing;
  });

ho_positive_type :: (Nat -> Nat) -> Nat -> Ho_type -> Bool;
ho_positive_type rank n (HBase b) = less_eq_nat (rank b) n;
ho_positive_type rank n (HArrow a b) =
  ho_negative_type rank n a && ho_positive_type rank n b;

ho_negative_type :: (Nat -> Nat) -> Nat -> Ho_type -> Bool;
ho_negative_type rank n (HBase b) = less_nat (rank b) n;
ho_negative_type rank n (HArrow a b) =
  ho_positive_type rank n a && ho_negative_type rank n b;

ho_application_head :: Ho_term -> Ho_term;
ho_application_head (HApp f x) = ho_application_head f;
ho_application_head (HBound v) = HBound v;
ho_application_head (HFree v) = HFree v;
ho_application_head (HConst v) = HConst v;
ho_application_head (HAbs v va) = HAbs v va;

ho_spine_arguments :: Ho_term -> [Ho_term];
ho_spine_arguments (HApp f x) = ho_spine_arguments f ++ [x];
ho_spine_arguments (HBound v) = [];
ho_spine_arguments (HFree v) = [];
ho_spine_arguments (HConst v) = [];
ho_spine_arguments (HAbs v va) = [];

ho_check_functional_access_path ::
  [Ho_type] ->
    [Ho_type] ->
      [([Ho_type], (Ho_pattern, Ho_pattern))] ->
        (Nat -> Nat) -> Nat -> [Ho_type] -> Ho_term -> Ho_term -> Bool;
ho_check_functional_access_path s g r sorts Zero_nat d t u = equal_ho_term t u;
ho_check_functional_access_path s g r sorts (Suc fuel) d t u =
  equal_ho_term t u ||
    (case u of {
      HBound _ ->
        (case ho_application_unwrap s g r d u of {
          Nothing ->
            (case ho_typeof s g d u of {
              Nothing -> False;
              Just (HBase a) ->
                (case ho_application_head u of {
                  HBound _ -> False;
                  HFree _ -> False;
                  HConst _ ->
                    any (\ v ->
                          (case ho_typeof s g d v of {
                            Nothing -> False;
                            Just ta ->
                              ho_positive_type sorts (sorts a) ta &&
                                ho_check_functional_access_path s g r sorts fuel
                                  d t v;
                          }))
                      (ho_spine_arguments u);
                  HApp _ _ -> False;
                  HAbs _ _ -> False;
                });
              Just (HArrow _ _) -> False;
            });
          Just a -> ho_check_functional_access_path s g r sorts fuel d t a;
        });
      HFree _ ->
        (case ho_application_unwrap s g r d u of {
          Nothing ->
            (case ho_typeof s g d u of {
              Nothing -> False;
              Just (HBase a) ->
                (case ho_application_head u of {
                  HBound _ -> False;
                  HFree _ -> False;
                  HConst _ ->
                    any (\ v ->
                          (case ho_typeof s g d v of {
                            Nothing -> False;
                            Just ta ->
                              ho_positive_type sorts (sorts a) ta &&
                                ho_check_functional_access_path s g r sorts fuel
                                  d t v;
                          }))
                      (ho_spine_arguments u);
                  HApp _ _ -> False;
                  HAbs _ _ -> False;
                });
              Just (HArrow _ _) -> False;
            });
          Just a -> ho_check_functional_access_path s g r sorts fuel d t a;
        });
      HConst _ ->
        (case ho_application_unwrap s g r d u of {
          Nothing ->
            (case ho_typeof s g d u of {
              Nothing -> False;
              Just (HBase a) ->
                (case ho_application_head u of {
                  HBound _ -> False;
                  HFree _ -> False;
                  HConst _ ->
                    any (\ v ->
                          (case ho_typeof s g d v of {
                            Nothing -> False;
                            Just ta ->
                              ho_positive_type sorts (sorts a) ta &&
                                ho_check_functional_access_path s g r sorts fuel
                                  d t v;
                          }))
                      (ho_spine_arguments u);
                  HApp _ _ -> False;
                  HAbs _ _ -> False;
                });
              Just (HArrow _ _) -> False;
            });
          Just a -> ho_check_functional_access_path s g r sorts fuel d t a;
        });
      HApp _ _ ->
        (case ho_application_unwrap s g r d u of {
          Nothing ->
            (case ho_typeof s g d u of {
              Nothing -> False;
              Just (HBase a) ->
                (case ho_application_head u of {
                  HBound _ -> False;
                  HFree _ -> False;
                  HConst _ ->
                    any (\ v ->
                          (case ho_typeof s g d v of {
                            Nothing -> False;
                            Just ta ->
                              ho_positive_type sorts (sorts a) ta &&
                                ho_check_functional_access_path s g r sorts fuel
                                  d t v;
                          }))
                      (ho_spine_arguments u);
                  HApp _ _ -> False;
                  HAbs _ _ -> False;
                });
              Just (HArrow _ _) -> False;
            });
          Just a -> ho_check_functional_access_path s g r sorts fuel d t a;
        });
      HAbs a v ->
        ho_check_functional_access_path s g r sorts fuel (a : d)
          (ho_lift one_nat Zero_nat t) v ||
          (case ho_typeof s g d t of {
            Nothing -> False;
            Just (HBase _) -> False;
            Just (HArrow ta _) ->
              equal_ho_type ta a &&
                ho_check_functional_access_path s g r sorts fuel (a : d)
                  (HApp (ho_lift one_nat Zero_nat t) (HBound Zero_nat)) v;
          });
    });

size_ho_term :: Ho_term -> Nat;
size_ho_term (HBound x1) = Zero_nat;
size_ho_term (HFree x2) = Zero_nat;
size_ho_term (HConst x3) = Zero_nat;
size_ho_term (HApp x41 x42) =
  plus_nat (plus_nat (size_ho_term x41) (size_ho_term x42)) (Suc Zero_nat);
size_ho_term (HAbs x51 x52) = plus_nat (size_ho_term x52) (Suc Zero_nat);

ho_functional_access_from ::
  [Ho_type] ->
    [Ho_type] ->
      [([Ho_type], (Ho_pattern, Ho_pattern))] ->
        (Nat -> Nat) -> Ho_term -> Ho_term -> Bool;
ho_functional_access_from s g r sorts t u =
  not (is_none (ho_typeof s g [] t)) &&
    ho_check_functional_access_path s g r sorts (Suc (size_ho_term u)) [] t u;

ho_priority_arguments :: forall a. (Nat -> Nat) -> [a] -> [a];
ho_priority_arguments priority xs =
  map (nth xs) (sort_key priority (upt Zero_nat (size_list xs)));

ho_argument_types :: Ho_type -> [Ho_type];
ho_argument_types (HBase b) = [];
ho_argument_types (HArrow a c) = a : ho_argument_types c;

ho_app_subterm :: Ho_term -> Ho_term -> Bool;
ho_app_subterm s (HApp f x) =
  equal_ho_term s (HApp f x) || (ho_app_subterm s f || ho_app_subterm s x);
ho_app_subterm s (HBound v) = equal_ho_term s (HBound v);
ho_app_subterm s (HFree v) = equal_ho_term s (HFree v);
ho_app_subterm s (HConst v) = equal_ho_term s (HConst v);
ho_app_subterm s (HAbs v va) = equal_ho_term s (HAbs v va);

ho_lex_subterm :: [Ho_term] -> [Ho_term] -> Bool;
ho_lex_subterm [] ys = False;
ho_lex_subterm (x : xs) [] = False;
ho_lex_subterm (x : xs) (y : ys) =
  equal_nat (size_list xs) (size_list ys) &&
    (equal_ho_term x y && ho_lex_subterm xs ys ||
      not (equal_ho_term x y) && ho_app_subterm x y);

ho_drop_type :: Nat -> Ho_type -> Ho_type;
ho_drop_type Zero_nat a = a;
ho_drop_type (Suc n) (HBase b) = HBase b;
ho_drop_type (Suc n) (HArrow a c) = ho_drop_type n c;

ho_functional_access_closure_step ::
  forall a.
    (Eq a,
      Ord a) => [Ho_type] ->
                  [Ho_type] ->
                    [([Ho_type], (Ho_pattern, Ho_pattern))] ->
                      (Nat -> Nat) ->
                        (Nat -> a) ->
                          (Nat -> Nat) ->
                            (Nat -> Nat) ->
                              Nat ->
                                [Ho_term] ->
                                  ([Ho_type] -> Ho_term -> Bool) ->
                                    [Ho_type] -> Ho_term -> Bool;
ho_functional_access_closure_step s g r sorts prec priority arity c ls recur d t
  = (case ho_typeof s g d t of {
      Nothing -> False;
      Just a ->
        membera ls t ||
          (any (ho_functional_access_from s g r sorts t) ls ||
            ((case t of {
               HBound n -> less_nat n (size_list d);
               HFree _ -> False;
               HConst da -> less (prec da) (prec c);
               HApp f x -> recur d f && recur d x;
               HAbs ta aa -> recur (ta : d) aa;
             }) ||
              (case ho_application_head t of {
                HBound _ -> False;
                HFree _ -> False;
                HConst da ->
                  (case ho_lookup s da of {
                    Nothing -> False;
                    Just u ->
                      prec da == prec c &&
                        equal_ho_type a (ho_drop_type (arity da) u) &&
                          list_all2 (\ ta x -> ho_typeof s g d x == Just ta)
                            (take (arity da) (ho_argument_types u))
                            (ho_spine_arguments t) &&
                            ho_lex_subterm
                              (ho_priority_arguments priority
                                (ho_spine_arguments t))
                              (ho_priority_arguments priority ls) &&
                              all (recur d) (ho_spine_arguments t);
                  });
                HApp _ _ -> False;
                HAbs _ _ -> False;
              })));
    });

ho_check_functional_access_closure ::
  [Ho_type] ->
    [Ho_type] ->
      [([Ho_type], (Ho_pattern, Ho_pattern))] ->
        (Nat -> Nat) ->
          (Nat -> Nat) ->
            (Nat -> Nat) ->
              (Nat -> Nat) ->
                Nat -> [Ho_term] -> Nat -> [Ho_type] -> Ho_term -> Bool;
ho_check_functional_access_closure s g r sorts prec priority arity c ls Zero_nat
  d t = False;
ho_check_functional_access_closure s g r sorts prec priority arity c ls
  (Suc fuel) d t =
  ho_functional_access_closure_step s g r sorts prec priority arity c ls
    (ho_check_functional_access_closure s g r sorts prec priority arity c ls
      fuel)
    d t;

ho_check_functional_access_schema_rule ::
  [Ho_type] ->
    [([Ho_type], (Ho_pattern, Ho_pattern))] ->
      (Nat -> Nat) ->
        (Nat -> Nat) ->
          (Nat -> Nat) ->
            (Nat -> Nat) ->
              Nat -> ([Ho_type], (Ho_pattern, Ho_pattern)) -> Bool;
ho_check_functional_access_schema_rule s r sorts prec priority arity fuel rule =
  (case rule of {
    (g, (l, ra)) ->
      ho_rule_welltyped s (g, (l, ra)) &&
        (case ho_application_head (ho_erase_pattern l) of {
          HBound _ -> False;
          HFree _ -> False;
          HConst c ->
            (case ho_lookup s c of {
              Nothing -> False;
              Just t ->
                list_all2 (\ a x -> ho_typeof s g [] x == Just a)
                  (take (arity c) (ho_argument_types t))
                  (ho_spine_arguments (ho_erase_pattern l)) &&
                  ho_check_functional_access_closure s g r sorts prec priority
                    arity c (ho_spine_arguments (ho_erase_pattern l)) fuel []
                    (ho_erase_pattern ra);
            });
          HApp _ _ -> False;
          HAbs _ _ -> False;
        });
  });

ho_zero_arity_pattern :: Ho_pattern -> Bool;
ho_zero_arity_pattern (PBound n) = True;
ho_zero_arity_pattern (PConst n) = True;
ho_zero_arity_pattern (PApp f x) =
  ho_zero_arity_pattern f && ho_zero_arity_pattern x;
ho_zero_arity_pattern (PAbs a t) = ho_zero_arity_pattern t;
ho_zero_arity_pattern (PMeta n ts) = null ts;

ho_zero_arity_rules :: forall a. [(a, (Ho_pattern, Ho_pattern))] -> Bool;
ho_zero_arity_rules r =
  all (\ (_, (l, ra)) -> ho_zero_arity_pattern l && ho_zero_arity_pattern ra) r;

ho_check_functional_access_schema ::
  [Ho_type] ->
    [([Ho_type], (Ho_pattern, Ho_pattern))] ->
      [Nat] -> [Nat] -> [Nat] -> [Nat] -> Nat -> Bool;
ho_check_functional_access_schema s r ranks arities priorities sorts fuel =
  equal_nat (size_list ranks) (size_list s) &&
    equal_nat (size_list arities) (size_list s) &&
      all (\ n -> less_eq_nat n (size_list priorities)) arities &&
        let {
          d = minus_nat (size_list s) one_nat;
        } in (if less_nat d (size_list s)
               then all_interval
                      (\ i ->
                        less_eq_nat (nth arities i)
                          (size_list (ho_argument_types (nth s i))))
                      Zero_nat d
               else True) &&
          ho_zero_arity_rules r &&
            all (ho_check_functional_access_schema_rule s r
                  (\ b ->
                    (if less_nat b (size_list sorts) then nth sorts b
                      else Zero_nat))
                  (nth ranks) (nth priorities) (nth arities) fuel)
              r;

ho_check_lambda_access_path ::
  [Ho_type] ->
    [Ho_type] -> (Nat -> Nat) -> Nat -> [Ho_type] -> Ho_term -> Ho_term -> Bool;
ho_check_lambda_access_path s g sorts Zero_nat d t u = equal_ho_term t u;
ho_check_lambda_access_path s g sorts (Suc fuel) d t u =
  equal_ho_term t u ||
    (case u of {
      HBound _ ->
        (case ho_typeof s g d u of {
          Nothing -> False;
          Just (HBase b) ->
            (case ho_application_head u of {
              HBound _ -> False;
              HFree _ -> False;
              HConst _ ->
                any (\ v ->
                      (case ho_typeof s g d v of {
                        Nothing -> False;
                        Just ta ->
                          ho_positive_type sorts (sorts b) ta &&
                            ho_check_lambda_access_path s g sorts fuel d t v;
                      }))
                  (ho_spine_arguments u);
              HApp _ _ -> False;
              HAbs _ _ -> False;
            });
          Just (HArrow _ _) -> False;
        });
      HFree _ ->
        (case ho_typeof s g d u of {
          Nothing -> False;
          Just (HBase b) ->
            (case ho_application_head u of {
              HBound _ -> False;
              HFree _ -> False;
              HConst _ ->
                any (\ v ->
                      (case ho_typeof s g d v of {
                        Nothing -> False;
                        Just ta ->
                          ho_positive_type sorts (sorts b) ta &&
                            ho_check_lambda_access_path s g sorts fuel d t v;
                      }))
                  (ho_spine_arguments u);
              HApp _ _ -> False;
              HAbs _ _ -> False;
            });
          Just (HArrow _ _) -> False;
        });
      HConst _ ->
        (case ho_typeof s g d u of {
          Nothing -> False;
          Just (HBase b) ->
            (case ho_application_head u of {
              HBound _ -> False;
              HFree _ -> False;
              HConst _ ->
                any (\ v ->
                      (case ho_typeof s g d v of {
                        Nothing -> False;
                        Just ta ->
                          ho_positive_type sorts (sorts b) ta &&
                            ho_check_lambda_access_path s g sorts fuel d t v;
                      }))
                  (ho_spine_arguments u);
              HApp _ _ -> False;
              HAbs _ _ -> False;
            });
          Just (HArrow _ _) -> False;
        });
      HApp _ _ ->
        (case ho_typeof s g d u of {
          Nothing -> False;
          Just (HBase b) ->
            (case ho_application_head u of {
              HBound _ -> False;
              HFree _ -> False;
              HConst _ ->
                any (\ v ->
                      (case ho_typeof s g d v of {
                        Nothing -> False;
                        Just ta ->
                          ho_positive_type sorts (sorts b) ta &&
                            ho_check_lambda_access_path s g sorts fuel d t v;
                      }))
                  (ho_spine_arguments u);
              HApp _ _ -> False;
              HAbs _ _ -> False;
            });
          Just (HArrow _ _) -> False;
        });
      HAbs a b -> ho_check_lambda_access_path s g sorts fuel (a : d) t b;
    });

ho_lambda_access_from ::
  [Ho_type] -> [Ho_type] -> (Nat -> Nat) -> Ho_term -> Ho_term -> Bool;
ho_lambda_access_from s g sorts t u =
  not (is_none (ho_typeof s g [] t)) &&
    ho_check_lambda_access_path s g sorts (Suc (size_ho_term u)) [] t u;

ho_lambda_access_closure_step ::
  forall a.
    (Eq a,
      Ord a) => [Ho_type] ->
                  [Ho_type] ->
                    (Nat -> Nat) ->
                      (Nat -> a) ->
                        (Nat -> Nat) ->
                          (Nat -> Nat) ->
                            Nat ->
                              [Ho_term] ->
                                ([Ho_type] -> Ho_term -> Bool) ->
                                  [Ho_type] -> Ho_term -> Bool;
ho_lambda_access_closure_step s g sorts prec priority arity c ls recur d t =
  (case ho_typeof s g d t of {
    Nothing -> False;
    Just a ->
      membera ls t ||
        (any (ho_lambda_access_from s g sorts t) ls ||
          ((case t of {
             HBound n -> less_nat n (size_list d);
             HFree _ -> False;
             HConst da -> less (prec da) (prec c);
             HApp f x -> recur d f && recur d x;
             HAbs ta aa -> recur (ta : d) aa;
           }) ||
            (case ho_application_head t of {
              HBound _ -> False;
              HFree _ -> False;
              HConst da ->
                (case ho_lookup s da of {
                  Nothing -> False;
                  Just u ->
                    prec da == prec c &&
                      equal_ho_type a (ho_drop_type (arity da) u) &&
                        list_all2 (\ ta x -> ho_typeof s g d x == Just ta)
                          (take (arity da) (ho_argument_types u))
                          (ho_spine_arguments t) &&
                          ho_lex_subterm
                            (ho_priority_arguments priority
                              (ho_spine_arguments t))
                            (ho_priority_arguments priority ls) &&
                            all (recur d) (ho_spine_arguments t);
                });
              HApp _ _ -> False;
              HAbs _ _ -> False;
            })));
  });

ho_check_lambda_access_closure ::
  [Ho_type] ->
    [Ho_type] ->
      (Nat -> Nat) ->
        (Nat -> Nat) ->
          (Nat -> Nat) ->
            (Nat -> Nat) ->
              Nat -> [Ho_term] -> Nat -> [Ho_type] -> Ho_term -> Bool;
ho_check_lambda_access_closure s g sorts prec priority arity c ls Zero_nat d t =
  False;
ho_check_lambda_access_closure s g sorts prec priority arity c ls (Suc fuel) d t
  = ho_lambda_access_closure_step s g sorts prec priority arity c ls
      (ho_check_lambda_access_closure s g sorts prec priority arity c ls fuel) d
      t;

ho_check_lambda_access_schema_rule ::
  [Ho_type] ->
    (Nat -> Nat) ->
      (Nat -> Nat) ->
        (Nat -> Nat) ->
          (Nat -> Nat) -> Nat -> ([Ho_type], (Ho_pattern, Ho_pattern)) -> Bool;
ho_check_lambda_access_schema_rule s sorts prec priority arity fuel rule =
  (case rule of {
    (g, (l, r)) ->
      ho_rule_welltyped s (g, (l, r)) &&
        (case ho_application_head (ho_erase_pattern l) of {
          HBound _ -> False;
          HFree _ -> False;
          HConst c ->
            (case ho_lookup s c of {
              Nothing -> False;
              Just t ->
                list_all2 (\ a x -> ho_typeof s g [] x == Just a)
                  (take (arity c) (ho_argument_types t))
                  (ho_spine_arguments (ho_erase_pattern l)) &&
                  ho_check_lambda_access_closure s g sorts prec priority arity c
                    (ho_spine_arguments (ho_erase_pattern l)) fuel []
                    (ho_erase_pattern r);
            });
          HApp _ _ -> False;
          HAbs _ _ -> False;
        });
  });

ho_check_lambda_access_schema ::
  [Ho_type] ->
    [([Ho_type], (Ho_pattern, Ho_pattern))] ->
      [Nat] -> [Nat] -> [Nat] -> [Nat] -> Nat -> Bool;
ho_check_lambda_access_schema s r ranks arities priorities sorts fuel =
  equal_nat (size_list ranks) (size_list s) &&
    equal_nat (size_list arities) (size_list s) &&
      all (\ n -> less_eq_nat n (size_list priorities)) arities &&
        let {
          d = minus_nat (size_list s) one_nat;
        } in (if less_nat d (size_list s)
               then all_interval
                      (\ i ->
                        less_eq_nat (nth arities i)
                          (size_list (ho_argument_types (nth s i))))
                      Zero_nat d
               else True) &&
          ho_zero_arity_rules r &&
            all (ho_check_lambda_access_schema_rule s
                  (\ b ->
                    (if less_nat b (size_list sorts) then nth sorts b
                      else Zero_nat))
                  (nth ranks) (nth priorities) (nth arities) fuel)
              r;

ho_polynomial_translate :: [Ho_polynomial] -> Ho_expression -> Ho_polynomial;
ho_polynomial_translate ps (HEVar n) = HPVar n;
ho_polynomial_translate ps (HEConst n) =
  (if less_nat n (size_list ps) then nth ps n else HPNumber Zero_nat Zero_nat);
ho_polynomial_translate ps (HEApp a b f x) =
  ho_polynomial_raise b
    (HPApply a b (ho_polynomial_translate ps f) (ho_polynomial_translate ps x))
    (ho_polynomial_lower a (ho_polynomial_translate ps x));
ho_polynomial_translate ps (HEAbs a b t) =
  HPAbstract a b (ho_polynomial_translate ps t);

ho_compile :: [Ho_type] -> [Ho_type] -> [Ho_type] -> Ho_term -> Ho_expression;
ho_compile s v b (HBound n) = HEVar n;
ho_compile s v b (HFree n) = HEVar (plus_nat (size_list b) n);
ho_compile s v b (HConst n) = HEConst n;
ho_compile s v b (HApp f x) =
  (case ho_typeof s v b f of {
    Nothing -> HEVar Zero_nat;
    Just (HBase _) -> HEVar Zero_nat;
    Just (HArrow a c) -> HEApp a c (ho_compile s v b f) (ho_compile s v b x);
  });
ho_compile s v b (HAbs a t) = (case ho_typeof s v (a : b) t of {
                                Nothing -> HEVar Zero_nat;
                                Just c -> HEAbs a c (ho_compile s v (a : b) t);
                              });

ho_rule_polynomial ::
  [Ho_type] -> [Ho_polynomial] -> [Ho_type] -> Ho_pattern -> Ho_polynomial;
ho_rule_polynomial s ps g p =
  ho_polynomial_translate ps (ho_compile s g [] (ho_erase_pattern p));

ho_check_polynomial_rule_ge ::
  [Ho_type] ->
    [Ho_polynomial] -> Nat -> [Ho_type] -> Ho_pattern -> Ho_pattern -> Bool;
ho_check_polynomial_rule_ge s ps fuel g l r =
  (case ho_typeof s g [] (ho_erase_pattern l) of {
    Nothing -> False;
    Just a ->
      ho_typeof s g [] (ho_erase_pattern r) == Just a &&
        ho_check_polynomial_ge fuel g a (ho_rule_polynomial s ps g l)
          (ho_rule_polynomial s ps g r);
  });

ho_check_polynomial_removal ::
  [Ho_type] ->
    [Ho_polynomial] -> Nat -> [([Ho_type], (Ho_pattern, Ho_pattern))] -> Bool;
ho_check_polynomial_removal s ps fuel r =
  ho_zero_arity_rules r &&
    ho_check_polynomial_signature s ps &&
      all (\ (g, (a, b)) -> ho_check_polynomial_rule_ge s ps fuel g a b) r;

ho_weak_polynomial_translate ::
  [Ho_polynomial] -> Ho_expression -> Ho_polynomial;
ho_weak_polynomial_translate ps (HEVar n) = HPVar n;
ho_weak_polynomial_translate ps (HEConst n) =
  (if less_nat n (size_list ps) then nth ps n else HPNumber Zero_nat Zero_nat);
ho_weak_polynomial_translate ps (HEApp a b f x) =
  HPApply a b (ho_weak_polynomial_translate ps f)
    (ho_weak_polynomial_translate ps x);
ho_weak_polynomial_translate ps (HEAbs a b t) =
  HPAbstract a b (ho_weak_polynomial_translate ps t);

ho_polynomial_apply_list ::
  Ho_type -> Ho_polynomial -> [Ho_polynomial] -> Ho_polynomial;
ho_polynomial_apply_list a p [] = p;
ho_polynomial_apply_list (HArrow a c) p (q : qs) =
  ho_polynomial_apply_list c (HPApply a c p q) qs;
ho_polynomial_apply_list (HBase b) p (q : qs) = HPNumber b Zero_nat;

ho_call_polynomial ::
  [Ho_type] ->
    [Ho_polynomial] ->
      [Ho_polynomial] -> [Ho_type] -> Nat -> [Ho_term] -> Ho_polynomial;
ho_call_polynomial s ps ms g c xs =
  ho_polynomial_apply_list (nth s c) (nth ms c)
    (map (\ x -> ho_weak_polynomial_translate ps (ho_compile s g [] x)) xs);

ho_check_call_comparison ::
  [Ho_type] ->
    [Ho_polynomial] ->
      [Ho_polynomial] ->
        Nat ->
          [Ho_type] -> Nat -> [Ho_term] -> Nat -> [Ho_term] -> Bool -> Bool;
ho_check_call_comparison s ps ms fuel g c ls d xs strict =
  less_nat c (size_list s) &&
    less_nat d (size_list s) &&
      less_eq_nat (size_list ls) (size_list (ho_argument_types (nth s c))) &&
        less_eq_nat (size_list xs) (size_list (ho_argument_types (nth s d))) &&
          list_all2 (\ a x -> ho_typeof s g [] x == Just a)
            (take (size_list ls) (ho_argument_types (nth s c))) ls &&
            list_all2 (\ a x -> ho_typeof s g [] x == Just a)
              (take (size_list xs) (ho_argument_types (nth s d))) xs &&
              equal_ho_type (ho_drop_type (size_list ls) (nth s c))
                (ho_drop_type (size_list xs) (nth s d)) &&
                (if strict then ho_check_polynomial_gt
                  else ho_check_polynomial_ge)
                  fuel
                  g
                  (ho_drop_type (size_list ls) (nth s c))
                  (ho_call_polynomial s ps ms g c ls)
                  (ho_call_polynomial s ps ms g d xs);

ho_check_accessible_path ::
  [Ho_type] -> [Ho_type] -> (Nat -> Nat) -> Nat -> Ho_term -> Ho_term -> Bool;
ho_check_accessible_path s g rank Zero_nat t u = equal_ho_term t u;
ho_check_accessible_path s g rank (Suc fuel) t u =
  equal_ho_term t u ||
    (case ho_typeof s g [] u of {
      Nothing -> False;
      Just (HBase b) ->
        (case ho_application_head u of {
          HBound _ -> False;
          HFree _ -> False;
          HConst _ ->
            any (\ v ->
                  (case ho_typeof s g [] v of {
                    Nothing -> False;
                    Just ta ->
                      ho_positive_type rank (rank b) ta &&
                        ho_check_accessible_path s g rank fuel t v;
                  }))
              (ho_spine_arguments u);
          HApp _ _ -> False;
          HAbs _ _ -> False;
        });
      Just (HArrow _ _) -> False;
    });

ho_accessible_from ::
  [Ho_type] -> [Ho_type] -> (Nat -> Nat) -> Ho_term -> Ho_term -> Bool;
ho_accessible_from s g sorts t u =
  ho_check_accessible_path s g sorts (Suc (size_ho_term u)) t u;

ho_component_closure_step ::
  [Ho_type] ->
    [Ho_type] ->
      (Nat -> Nat) ->
        [Ho_polynomial] ->
          [Ho_polynomial] ->
            Nat ->
              (Nat -> Nat) ->
                (Nat -> Nat) ->
                  (Nat -> Nat) ->
                    Nat ->
                      [Ho_term] ->
                        ([Ho_type] -> Ho_term -> Bool) ->
                          [Ho_type] -> Ho_term -> Bool;
ho_component_closure_step s g sorts ps ms ofuel prec priority arity c ls recur d
  t = (case ho_typeof s g d t of {
        Nothing -> False;
        Just a ->
          membera ls t ||
            (any (ho_accessible_from s g sorts t) ls ||
              ((case t of {
                 HBound n -> less_nat n (size_list d);
                 HFree _ -> False;
                 HConst da -> less_nat (prec da) (prec c);
                 HApp f x -> recur d f && recur d x;
                 HAbs ta aa -> recur (ta : d) aa;
               }) ||
                (case ho_application_head t of {
                  HBound _ -> False;
                  HFree _ -> False;
                  HConst da ->
                    (case ho_lookup s da of {
                      Nothing -> False;
                      Just u ->
                        equal_nat (prec da) (prec c) &&
                          equal_ho_type a (ho_drop_type (arity da) u) &&
                            list_all2 (\ ta x -> ho_typeof s g d x == Just ta)
                              (take (arity da) (ho_argument_types u))
                              (ho_spine_arguments t) &&
                              (null d &&
                                (ho_check_call_comparison s ps ms ofuel g c ls
                                   da (ho_spine_arguments t) True ||
                                  ho_check_call_comparison s ps ms ofuel g c ls
                                    da (ho_spine_arguments t) False &&
                                    ho_lex_subterm
                                      (ho_priority_arguments priority
(ho_spine_arguments t))
                                      (ho_priority_arguments priority ls))) &&
                                all (recur d) (ho_spine_arguments t);
                    });
                  HApp _ _ -> False;
                  HAbs _ _ -> False;
                })));
      });

ho_check_component_closure ::
  [Ho_type] ->
    [Ho_type] ->
      (Nat -> Nat) ->
        [Ho_polynomial] ->
          [Ho_polynomial] ->
            Nat ->
              (Nat -> Nat) ->
                (Nat -> Nat) ->
                  (Nat -> Nat) ->
                    Nat -> [Ho_term] -> Nat -> [Ho_type] -> Ho_term -> Bool;
ho_check_component_closure s g sorts ps ms ofuel prec priority arity c ls
  Zero_nat d t = False;
ho_check_component_closure s g sorts ps ms ofuel prec priority arity c ls
  (Suc fuel) d t =
  ho_component_closure_step s g sorts ps ms ofuel prec priority arity c ls
    (ho_check_component_closure s g sorts ps ms ofuel prec priority arity c ls
      fuel)
    d t;

ho_check_component_schema_rule ::
  [Ho_type] ->
    (Nat -> Nat) ->
      [Ho_polynomial] ->
        [Ho_polynomial] ->
          Nat ->
            (Nat -> Nat) ->
              (Nat -> Nat) ->
                (Nat -> Nat) ->
                  Nat -> ([Ho_type], (Ho_pattern, Ho_pattern)) -> Bool;
ho_check_component_schema_rule s sorts ps ms ofuel prec priority arity fuel rule
  = (case rule of {
      (g, (l, r)) ->
        ho_rule_welltyped s (g, (l, r)) &&
          (case ho_application_head (ho_erase_pattern l) of {
            HBound _ -> False;
            HFree _ -> False;
            HConst c ->
              (case ho_lookup s c of {
                Nothing -> False;
                Just t ->
                  list_all2 (\ a x -> ho_typeof s g [] x == Just a)
                    (take (arity c) (ho_argument_types t))
                    (ho_spine_arguments (ho_erase_pattern l)) &&
                    ho_check_component_closure s g sorts ps ms ofuel prec
                      priority arity c (ho_spine_arguments (ho_erase_pattern l))
                      fuel [] (ho_erase_pattern r);
              });
            HApp _ _ -> False;
            HAbs _ _ -> False;
          });
    });

ho_check_weak_polynomial_rule ::
  [Ho_type] ->
    [Ho_polynomial] -> Nat -> [Ho_type] -> Ho_pattern -> Ho_pattern -> Bool;
ho_check_weak_polynomial_rule s ps fuel g l r =
  (case ho_typeof s g [] (ho_erase_pattern l) of {
    Nothing -> False;
    Just a ->
      ho_typeof s g [] (ho_erase_pattern r) == Just a &&
        ho_check_polynomial_ge fuel g a
          (ho_weak_polynomial_translate ps
            (ho_compile s g [] (ho_erase_pattern l)))
          (ho_weak_polynomial_translate ps
            (ho_compile s g [] (ho_erase_pattern r)));
  });

ho_component_rule_head :: forall a b. (a, (Ho_pattern, b)) -> Nat;
ho_component_rule_head rule =
  (case rule of {
    (_, (l, _)) -> (case ho_application_head (ho_erase_pattern l) of {
                     HBound _ -> Zero_nat;
                     HFree _ -> Zero_nat;
                     HConst c -> c;
                     HApp _ _ -> Zero_nat;
                     HAbs _ _ -> Zero_nat;
                   });
  });

ho_component_programs :: forall a. [a] -> Nat -> a;
ho_component_programs pss n =
  nth pss (if less_nat n (size_list pss) then n else Zero_nat);

ho_check_component_schema ::
  [Ho_type] ->
    [([Ho_type], (Ho_pattern, Ho_pattern))] ->
      [[Ho_polynomial]] ->
        [[Ho_polynomial]] ->
          Nat -> [Nat] -> [Nat] -> [Nat] -> [Nat] -> Nat -> Bool;
ho_check_component_schema s r pss mss ofuel ranks arities priorities sorts fuel
  = not (null pss) &&
      not (null mss) &&
        all (ho_check_polynomial_signature s) pss &&
          all (ho_check_polynomial_signature s) mss &&
            all (\ ps ->
                  all (\ (g, (a, b)) ->
                        ho_check_weak_polynomial_rule s ps ofuel g a b)
                    r)
              pss &&
              equal_nat (size_list ranks) (size_list s) &&
                equal_nat (size_list arities) (size_list s) &&
                  all (\ n -> less_eq_nat n (size_list priorities)) arities &&
                    let {
                      d = minus_nat (size_list s) one_nat;
                    } in (if less_nat d (size_list s)
                           then all_interval
                                  (\ i ->
                                    less_eq_nat (nth arities i)
                                      (size_list (ho_argument_types (nth s i))))
                                  Zero_nat d
                           else True) &&
                      ho_zero_arity_rules r &&
                        all (\ rule ->
                              ho_check_component_schema_rule s
                                (\ b ->
                                  (if less_nat b (size_list sorts)
                                    then nth sorts b else Zero_nat))
                                (ho_component_programs pss
                                  (nth ranks (ho_component_rule_head rule)))
                                (ho_component_programs mss
                                  (nth ranks (ho_component_rule_head rule)))
                                ofuel (nth ranks) (nth priorities) (nth arities)
                                fuel rule)
                          r;

ho_check_polynomial_rule_gt ::
  [Ho_type] ->
    [Ho_polynomial] -> Nat -> [Ho_type] -> Ho_pattern -> Ho_pattern -> Bool;
ho_check_polynomial_rule_gt s ps fuel g l r =
  (case ho_typeof s g [] (ho_erase_pattern l) of {
    Nothing -> False;
    Just a ->
      ho_typeof s g [] (ho_erase_pattern r) == Just a &&
        ho_check_polynomial_gt fuel g a (ho_rule_polynomial s ps g l)
          (ho_rule_polynomial s ps g r);
  });

ho_polynomial_residual ::
  [Ho_type] ->
    [Ho_polynomial] ->
      Nat ->
        [([Ho_type], (Ho_pattern, Ho_pattern))] ->
          [([Ho_type], (Ho_pattern, Ho_pattern))];
ho_polynomial_residual s ps fuel r =
  filter (\ (g, (l, ra)) -> not (ho_check_polynomial_rule_gt s ps fuel g l ra))
    r;

ho_semantic_closure_step ::
  [Ho_type] ->
    [Ho_type] ->
      (Nat -> Nat) ->
        [Ho_polynomial] ->
          [Ho_polynomial] ->
            Nat ->
              (Nat -> Nat) ->
                (Nat -> Nat) ->
                  (Nat -> Nat) ->
                    Nat ->
                      [Ho_term] ->
                        ([Ho_type] -> Ho_term -> Bool) ->
                          [Ho_type] -> Ho_term -> Bool;
ho_semantic_closure_step s g sorts ps ms ofuel prec priority arity c ls recur d
  t = (case ho_typeof s g d t of {
        Nothing -> False;
        Just a ->
          membera ls t ||
            (any (ho_accessible_from s g sorts t) ls ||
              ((case t of {
                 HBound n -> less_nat n (size_list d);
                 HFree _ -> False;
                 HConst da -> less_nat (prec da) (prec c);
                 HApp f x -> recur d f && recur d x;
                 HAbs ta aa -> recur (ta : d) aa;
               }) ||
                (case ho_application_head t of {
                  HBound _ -> False;
                  HFree _ -> False;
                  HConst da ->
                    (case ho_lookup s da of {
                      Nothing -> False;
                      Just u ->
                        equal_nat (prec da) (prec c) &&
                          equal_ho_type a (ho_drop_type (arity da) u) &&
                            list_all2 (\ ta x -> ho_typeof s g d x == Just ta)
                              (take (arity da) (ho_argument_types u))
                              (ho_spine_arguments t) &&
                              (null d &&
                                (ho_check_call_comparison s ps ms ofuel g c ls
                                   da (ho_spine_arguments t) True ||
                                  ho_check_call_comparison s ps ms ofuel g c ls
                                    da (ho_spine_arguments t) False &&
                                    ho_lex_subterm
                                      (ho_priority_arguments priority
(ho_spine_arguments t))
                                      (ho_priority_arguments priority ls))) &&
                                all (recur d) (ho_spine_arguments t);
                    });
                  HApp _ _ -> False;
                  HAbs _ _ -> False;
                })));
      });

ho_check_semantic_closure ::
  [Ho_type] ->
    [Ho_type] ->
      (Nat -> Nat) ->
        [Ho_polynomial] ->
          [Ho_polynomial] ->
            Nat ->
              (Nat -> Nat) ->
                (Nat -> Nat) ->
                  (Nat -> Nat) ->
                    Nat -> [Ho_term] -> Nat -> [Ho_type] -> Ho_term -> Bool;
ho_check_semantic_closure s g sorts ps ms ofuel prec priority arity c ls
  Zero_nat d t = False;
ho_check_semantic_closure s g sorts ps ms ofuel prec priority arity c ls
  (Suc fuel) d t =
  ho_semantic_closure_step s g sorts ps ms ofuel prec priority arity c ls
    (ho_check_semantic_closure s g sorts ps ms ofuel prec priority arity c ls
      fuel)
    d t;

ho_check_semantic_schema_rule ::
  [Ho_type] ->
    (Nat -> Nat) ->
      [Ho_polynomial] ->
        [Ho_polynomial] ->
          Nat ->
            (Nat -> Nat) ->
              (Nat -> Nat) ->
                (Nat -> Nat) ->
                  Nat -> ([Ho_type], (Ho_pattern, Ho_pattern)) -> Bool;
ho_check_semantic_schema_rule s sorts ps ms ofuel prec priority arity fuel rule
  = (case rule of {
      (g, (l, r)) ->
        ho_rule_welltyped s (g, (l, r)) &&
          (case ho_application_head (ho_erase_pattern l) of {
            HBound _ -> False;
            HFree _ -> False;
            HConst c ->
              (case ho_lookup s c of {
                Nothing -> False;
                Just t ->
                  list_all2 (\ a x -> ho_typeof s g [] x == Just a)
                    (take (arity c) (ho_argument_types t))
                    (ho_spine_arguments (ho_erase_pattern l)) &&
                    ho_check_semantic_closure s g sorts ps ms ofuel prec
                      priority arity c (ho_spine_arguments (ho_erase_pattern l))
                      fuel [] (ho_erase_pattern r);
              });
            HApp _ _ -> False;
            HAbs _ _ -> False;
          });
    });

ho_check_semantic_schema ::
  [Ho_type] ->
    [([Ho_type], (Ho_pattern, Ho_pattern))] ->
      [Ho_polynomial] ->
        [Ho_polynomial] ->
          Nat -> [Nat] -> [Nat] -> [Nat] -> [Nat] -> Nat -> Bool;
ho_check_semantic_schema s r ps ms ofuel ranks arities priorities sorts fuel =
  ho_check_polynomial_signature s ps &&
    ho_check_polynomial_signature s ms &&
      all (\ (g, (a, b)) -> ho_check_weak_polynomial_rule s ps ofuel g a b) r &&
        equal_nat (size_list ranks) (size_list s) &&
          equal_nat (size_list arities) (size_list s) &&
            all (\ n -> less_eq_nat n (size_list priorities)) arities &&
              let {
                d = minus_nat (size_list s) one_nat;
              } in (if less_nat d (size_list s)
                     then all_interval
                            (\ i ->
                              less_eq_nat (nth arities i)
                                (size_list (ho_argument_types (nth s i))))
                            Zero_nat d
                     else True) &&
                ho_zero_arity_rules r &&
                  all (ho_check_semantic_schema_rule s
                        (\ b ->
                          (if less_nat b (size_list sorts) then nth sorts b
                            else Zero_nat))
                        ps ms ofuel (nth ranks) (nth priorities) (nth arities)
                        fuel)
                    r;

ho_accessible_closure_step ::
  forall a.
    (Eq a,
      Ord a) => [Ho_type] ->
                  [Ho_type] ->
                    (Nat -> Nat) ->
                      (Nat -> a) ->
                        (Nat -> Nat) ->
                          (Nat -> Nat) ->
                            Nat ->
                              [Ho_term] ->
                                ([Ho_type] -> Ho_term -> Bool) ->
                                  [Ho_type] -> Ho_term -> Bool;
ho_accessible_closure_step s g sorts prec priority arity c ls recur d t =
  (case ho_typeof s g d t of {
    Nothing -> False;
    Just a ->
      membera ls t ||
        (any (ho_accessible_from s g sorts t) ls ||
          ((case t of {
             HBound n -> less_nat n (size_list d);
             HFree _ -> False;
             HConst da -> less (prec da) (prec c);
             HApp f x -> recur d f && recur d x;
             HAbs ta aa -> recur (ta : d) aa;
           }) ||
            (case ho_application_head t of {
              HBound _ -> False;
              HFree _ -> False;
              HConst da ->
                (case ho_lookup s da of {
                  Nothing -> False;
                  Just u ->
                    prec da == prec c &&
                      equal_ho_type a (ho_drop_type (arity da) u) &&
                        list_all2 (\ ta x -> ho_typeof s g d x == Just ta)
                          (take (arity da) (ho_argument_types u))
                          (ho_spine_arguments t) &&
                          ho_lex_subterm
                            (ho_priority_arguments priority
                              (ho_spine_arguments t))
                            (ho_priority_arguments priority ls) &&
                            all (recur d) (ho_spine_arguments t);
                });
              HApp _ _ -> False;
              HAbs _ _ -> False;
            })));
  });

ho_check_accessible_closure ::
  [Ho_type] ->
    [Ho_type] ->
      (Nat -> Nat) ->
        (Nat -> Nat) ->
          (Nat -> Nat) ->
            (Nat -> Nat) ->
              Nat -> [Ho_term] -> Nat -> [Ho_type] -> Ho_term -> Bool;
ho_check_accessible_closure s g sorts prec priority arity c ls Zero_nat d t =
  False;
ho_check_accessible_closure s g sorts prec priority arity c ls (Suc fuel) d t =
  ho_accessible_closure_step s g sorts prec priority arity c ls
    (ho_check_accessible_closure s g sorts prec priority arity c ls fuel) d t;

ho_check_accessible_schema_rule ::
  [Ho_type] ->
    (Nat -> Nat) ->
      (Nat -> Nat) ->
        (Nat -> Nat) ->
          (Nat -> Nat) -> Nat -> ([Ho_type], (Ho_pattern, Ho_pattern)) -> Bool;
ho_check_accessible_schema_rule s sorts prec priority arity fuel rule =
  (case rule of {
    (g, (l, r)) ->
      ho_rule_welltyped s (g, (l, r)) &&
        (case ho_application_head (ho_erase_pattern l) of {
          HBound _ -> False;
          HFree _ -> False;
          HConst c ->
            (case ho_lookup s c of {
              Nothing -> False;
              Just t ->
                list_all2 (\ a x -> ho_typeof s g [] x == Just a)
                  (take (arity c) (ho_argument_types t))
                  (ho_spine_arguments (ho_erase_pattern l)) &&
                  ho_check_accessible_closure s g sorts prec priority arity c
                    (ho_spine_arguments (ho_erase_pattern l)) fuel []
                    (ho_erase_pattern r);
            });
          HApp _ _ -> False;
          HAbs _ _ -> False;
        });
  });

ho_check_accessible_schema ::
  [Ho_type] ->
    [([Ho_type], (Ho_pattern, Ho_pattern))] ->
      [Nat] -> [Nat] -> [Nat] -> [Nat] -> Nat -> Bool;
ho_check_accessible_schema s r ranks arities priorities sorts fuel =
  equal_nat (size_list ranks) (size_list s) &&
    equal_nat (size_list arities) (size_list s) &&
      all (\ n -> less_eq_nat n (size_list priorities)) arities &&
        let {
          d = minus_nat (size_list s) one_nat;
        } in (if less_nat d (size_list s)
               then all_interval
                      (\ i ->
                        less_eq_nat (nth arities i)
                          (size_list (ho_argument_types (nth s i))))
                      Zero_nat d
               else True) &&
          ho_zero_arity_rules r &&
            all (ho_check_accessible_schema_rule s
                  (\ b ->
                    (if less_nat b (size_list sorts) then nth sorts b
                      else Zero_nat))
                  (nth ranks) (nth priorities) (nth arities) fuel)
              r;

ho_closure_step ::
  forall a.
    (Eq a,
      Ord a) => [Ho_type] ->
                  [Ho_type] ->
                    (Nat -> a) ->
                      (Nat -> Nat) ->
                        Nat ->
                          [Ho_term] -> (Ho_term -> Bool) -> Ho_term -> Bool;
ho_closure_step s g rank arity c ls recur t =
  (case ho_typeof s g [] t of {
    Nothing -> False;
    Just a ->
      membera ls t ||
        ((case a of {
           HBase _ -> any (ho_app_subterm t) ls;
           HArrow _ _ -> False;
         }) ||
          ((case t of {
             HBound _ -> False;
             HFree _ -> False;
             HConst d -> less (rank d) (rank c);
             HApp f x -> recur f && recur x;
             HAbs _ _ -> False;
           }) ||
            (case ho_application_head t of {
              HBound _ -> False;
              HFree _ -> False;
              HConst d ->
                (case ho_lookup s d of {
                  Nothing -> False;
                  Just u ->
                    rank d == rank c &&
                      equal_ho_type a (ho_drop_type (arity d) u) &&
                        list_all2 (\ ta x -> ho_typeof s g [] x == Just ta)
                          (take (arity d) (ho_argument_types u))
                          (ho_spine_arguments t) &&
                          ho_lex_subterm (ho_spine_arguments t) ls &&
                            all recur (ho_spine_arguments t);
                });
              HApp _ _ -> False;
              HAbs _ _ -> False;
            })));
  });

ho_check_closure ::
  [Ho_type] ->
    [Ho_type] ->
      (Nat -> Nat) ->
        (Nat -> Nat) -> Nat -> [Ho_term] -> Nat -> Ho_term -> Bool;
ho_check_closure s g rank arity c ls Zero_nat t = False;
ho_check_closure s g rank arity c ls (Suc fuel) t =
  ho_closure_step s g rank arity c ls
    (ho_check_closure s g rank arity c ls fuel) t;

ho_check_schema_rule ::
  [Ho_type] ->
    (Nat -> Nat) ->
      (Nat -> Nat) -> Nat -> ([Ho_type], (Ho_pattern, Ho_pattern)) -> Bool;
ho_check_schema_rule s rank arity fuel rule =
  (case rule of {
    (g, (l, r)) ->
      ho_rule_welltyped s (g, (l, r)) &&
        (case ho_application_head (ho_erase_pattern l) of {
          HBound _ -> False;
          HFree _ -> False;
          HConst c ->
            (case ho_lookup s c of {
              Nothing -> False;
              Just t ->
                list_all2 (\ a x -> ho_typeof s g [] x == Just a)
                  (take (arity c) (ho_argument_types t))
                  (ho_spine_arguments (ho_erase_pattern l)) &&
                  ho_check_closure s g rank arity c
                    (ho_spine_arguments (ho_erase_pattern l)) fuel
                    (ho_erase_pattern r);
            });
          HApp _ _ -> False;
          HAbs _ _ -> False;
        });
  });

ho_check_schema_with_arities ::
  [Ho_type] ->
    [([Ho_type], (Ho_pattern, Ho_pattern))] -> [Nat] -> [Nat] -> Nat -> Bool;
ho_check_schema_with_arities s r ranks arities fuel =
  equal_nat (size_list ranks) (size_list s) &&
    equal_nat (size_list arities) (size_list s) &&
      let {
        d = minus_nat (size_list s) one_nat;
      } in (if less_nat d (size_list s)
             then all_interval
                    (\ i ->
                      less_eq_nat (nth arities i)
                        (size_list (ho_argument_types (nth s i))))
                    Zero_nat d
             else True) &&
        ho_zero_arity_rules r &&
          all (ho_check_schema_rule s (nth ranks) (nth arities) fuel) r;

ho_priority_closure_step ::
  forall a.
    (Eq a,
      Ord a) => [Ho_type] ->
                  [Ho_type] ->
                    (Nat -> a) ->
                      (Nat -> Nat) ->
                        (Nat -> Nat) ->
                          Nat ->
                            [Ho_term] ->
                              ([Ho_type] -> Ho_term -> Bool) ->
                                [Ho_type] -> Ho_term -> Bool;
ho_priority_closure_step s g rank priority arity c ls recur d t =
  (case ho_typeof s g d t of {
    Nothing -> False;
    Just a ->
      membera ls t ||
        ((case a of {
           HBase _ -> any (ho_app_subterm t) ls;
           HArrow _ _ -> False;
         }) ||
          ((case t of {
             HBound n -> less_nat n (size_list d);
             HFree _ -> False;
             HConst da -> less (rank da) (rank c);
             HApp f x -> recur d f && recur d x;
             HAbs ta aa -> recur (ta : d) aa;
           }) ||
            (case ho_application_head t of {
              HBound _ -> False;
              HFree _ -> False;
              HConst da ->
                (case ho_lookup s da of {
                  Nothing -> False;
                  Just u ->
                    rank da == rank c &&
                      equal_ho_type a (ho_drop_type (arity da) u) &&
                        list_all2 (\ ta x -> ho_typeof s g d x == Just ta)
                          (take (arity da) (ho_argument_types u))
                          (ho_spine_arguments t) &&
                          ho_lex_subterm
                            (ho_priority_arguments priority
                              (ho_spine_arguments t))
                            (ho_priority_arguments priority ls) &&
                            all (recur d) (ho_spine_arguments t);
                });
              HApp _ _ -> False;
              HAbs _ _ -> False;
            })));
  });

ho_check_priority_closure ::
  [Ho_type] ->
    [Ho_type] ->
      (Nat -> Nat) ->
        (Nat -> Nat) ->
          (Nat -> Nat) ->
            Nat -> [Ho_term] -> Nat -> [Ho_type] -> Ho_term -> Bool;
ho_check_priority_closure s g rank priority arity c ls Zero_nat d t = False;
ho_check_priority_closure s g rank priority arity c ls (Suc fuel) d t =
  ho_priority_closure_step s g rank priority arity c ls
    (ho_check_priority_closure s g rank priority arity c ls fuel) d t;

ho_check_priority_schema_rule ::
  [Ho_type] ->
    (Nat -> Nat) ->
      (Nat -> Nat) ->
        (Nat -> Nat) -> Nat -> ([Ho_type], (Ho_pattern, Ho_pattern)) -> Bool;
ho_check_priority_schema_rule s rank priority arity fuel rule =
  (case rule of {
    (g, (l, r)) ->
      ho_rule_welltyped s (g, (l, r)) &&
        (case ho_application_head (ho_erase_pattern l) of {
          HBound _ -> False;
          HFree _ -> False;
          HConst c ->
            (case ho_lookup s c of {
              Nothing -> False;
              Just t ->
                list_all2 (\ a x -> ho_typeof s g [] x == Just a)
                  (take (arity c) (ho_argument_types t))
                  (ho_spine_arguments (ho_erase_pattern l)) &&
                  ho_check_priority_closure s g rank priority arity c
                    (ho_spine_arguments (ho_erase_pattern l)) fuel []
                    (ho_erase_pattern r);
            });
          HApp _ _ -> False;
          HAbs _ _ -> False;
        });
  });

ho_check_priority_schema ::
  [Ho_type] ->
    [([Ho_type], (Ho_pattern, Ho_pattern))] ->
      [Nat] -> [Nat] -> [Nat] -> Nat -> Bool;
ho_check_priority_schema s r ranks arities priorities fuel =
  equal_nat (size_list ranks) (size_list s) &&
    equal_nat (size_list arities) (size_list s) &&
      all (\ n -> less_eq_nat n (size_list priorities)) arities &&
        let {
          d = minus_nat (size_list s) one_nat;
        } in (if less_nat d (size_list s)
               then all_interval
                      (\ i ->
                        less_eq_nat (nth arities i)
                          (size_list (ho_argument_types (nth s i))))
                      Zero_nat d
               else True) &&
          ho_zero_arity_rules r &&
            all (ho_check_priority_schema_rule s (nth ranks) (nth priorities)
                  (nth arities) fuel)
              r;

ho_check_general_schema ::
  [Ho_type] -> [([Ho_type], (Ho_pattern, Ho_pattern))] -> [Nat] -> Nat -> Bool;
ho_check_general_schema s r ranks fuel =
  ho_check_schema_with_arities s r ranks (map (size_list . ho_argument_types) s)
    fuel;

ho_applied_prefixes :: Ho_term -> [(Ho_term, [Ho_term])];
ho_applied_prefixes (HApp f x) =
  (HApp f x, []) : map (\ (v, xs) -> (v, xs ++ [x])) (ho_applied_prefixes f);
ho_applied_prefixes (HBound v) = [(HBound v, [])];
ho_applied_prefixes (HFree v) = [(HFree v, [])];
ho_applied_prefixes (HConst v) = [(HConst v, [])];
ho_applied_prefixes (HAbs v va) = [(HAbs v va, [])];

ho_bound_argument :: forall a. (Eq a) => [a] -> a -> Ho_term -> Bool;
ho_bound_argument d a (HBound i) = less_nat i (size_list d) && nth d i == a;
ho_bound_argument d a (HFree v) = False;
ho_bound_argument d a (HConst v) = False;
ho_bound_argument d a (HApp v va) = False;
ho_bound_argument d a (HAbs v va) = False;

ho_check_candidate_drop ::
  [Ho_type] ->
    [Ho_type] -> (Nat -> Nat) -> Nat -> [Ho_type] -> Ho_term -> Ho_term -> Bool;
ho_check_candidate_drop s g sorts n d t u =
  (case ho_typeof s g [] u of {
    Nothing -> False;
    Just (HBase b) ->
      equal_nat (sorts b) n &&
        (case ho_application_head u of {
          HBound _ -> False;
          HFree _ -> False;
          HConst _ ->
            any (\ (v, xs) ->
                  membera (ho_spine_arguments u) v &&
                    (case ho_typeof s g [] v of {
                      Nothing -> False;
                      Just ta ->
                        ho_positive_type sorts n ta &&
                          list_all2 (ho_bound_argument d) (ho_argument_types ta)
                            xs;
                    }))
              (ho_applied_prefixes t);
          HApp _ _ -> False;
          HAbs _ _ -> False;
        });
    Just (HArrow _ _) -> False;
  });

ho_lex_checked :: forall a. (Eq a) => (a -> a -> Bool) -> [a] -> [a] -> Bool;
ho_lex_checked rel [] ys = False;
ho_lex_checked rel (x : xs) [] = False;
ho_lex_checked rel (x : xs) (y : ys) =
  equal_nat (size_list xs) (size_list ys) &&
    (x == y && ho_lex_checked rel xs ys || rel x y);

ho_descent_closure_step ::
  [Ho_type] ->
    [Ho_type] ->
      (Nat -> Nat) ->
        Nat ->
          (Nat -> Nat) ->
            (Nat -> Nat) ->
              (Nat -> Nat) ->
                Nat ->
                  [Ho_term] ->
                    ([Ho_type] -> Ho_term -> Bool) ->
                      [Ho_type] -> Ho_term -> Bool;
ho_descent_closure_step s g sorts n prec priority arity c ls recur d t =
  (case ho_typeof s g d t of {
    Nothing -> False;
    Just a ->
      membera ls t ||
        (any (ho_accessible_from s g sorts t) ls ||
          ((case t of {
             HBound na -> less_nat na (size_list d);
             HFree _ -> False;
             HConst da -> less_nat (prec da) (prec c);
             HApp f x -> recur d f && recur d x;
             HAbs ta aa -> recur (ta : d) aa;
           }) ||
            (case ho_application_head t of {
              HBound _ -> False;
              HFree _ -> False;
              HConst da ->
                (case ho_lookup s da of {
                  Nothing -> False;
                  Just u ->
                    equal_nat (prec da) (prec c) &&
                      equal_ho_type a (ho_drop_type (arity da) u) &&
                        list_all2 (\ ta x -> ho_typeof s g d x == Just ta)
                          (take (arity da) (ho_argument_types u))
                          (ho_spine_arguments t) &&
                          ho_lex_checked (ho_check_candidate_drop s g sorts n d)
                            (ho_priority_arguments priority
                              (ho_spine_arguments t))
                            (ho_priority_arguments priority ls) &&
                            all (recur d) (ho_spine_arguments t);
                });
              HApp _ _ -> False;
              HAbs _ _ -> False;
            })));
  });

ho_check_descent_closure ::
  [Ho_type] ->
    [Ho_type] ->
      (Nat -> Nat) ->
        Nat ->
          (Nat -> Nat) ->
            (Nat -> Nat) ->
              (Nat -> Nat) ->
                Nat -> [Ho_term] -> Nat -> [Ho_type] -> Ho_term -> Bool;
ho_check_descent_closure s g sorts n prec priority arity c ls Zero_nat d t =
  False;
ho_check_descent_closure s g sorts n prec priority arity c ls (Suc fuel) d t =
  ho_descent_closure_step s g sorts n prec priority arity c ls
    (ho_check_descent_closure s g sorts n prec priority arity c ls fuel) d t;

ho_check_descent_schema_rule ::
  [Ho_type] ->
    (Nat -> Nat) ->
      Nat ->
        (Nat -> Nat) ->
          (Nat -> Nat) ->
            (Nat -> Nat) ->
              Nat -> ([Ho_type], (Ho_pattern, Ho_pattern)) -> Bool;
ho_check_descent_schema_rule s sorts n prec priority arity fuel rule =
  (case rule of {
    (g, (l, r)) ->
      ho_rule_welltyped s (g, (l, r)) &&
        (case ho_application_head (ho_erase_pattern l) of {
          HBound _ -> False;
          HFree _ -> False;
          HConst c ->
            (case ho_lookup s c of {
              Nothing -> False;
              Just t ->
                list_all2 (\ a x -> ho_typeof s g [] x == Just a)
                  (take (arity c) (ho_argument_types t))
                  (ho_spine_arguments (ho_erase_pattern l)) &&
                  ho_check_descent_closure s g sorts n prec priority arity c
                    (ho_spine_arguments (ho_erase_pattern l)) fuel []
                    (ho_erase_pattern r);
            });
          HApp _ _ -> False;
          HAbs _ _ -> False;
        });
  });

ho_check_descent_schema ::
  [Ho_type] ->
    [([Ho_type], (Ho_pattern, Ho_pattern))] ->
      [Nat] -> [Nat] -> [Nat] -> [Nat] -> Nat -> Nat -> Bool;
ho_check_descent_schema s r ranks arities priorities sorts n fuel =
  equal_nat (size_list ranks) (size_list s) &&
    equal_nat (size_list arities) (size_list s) &&
      all (\ na -> less_eq_nat na (size_list priorities)) arities &&
        let {
          d = minus_nat (size_list s) one_nat;
        } in (if less_nat d (size_list s)
               then all_interval
                      (\ i ->
                        less_eq_nat (nth arities i)
                          (size_list (ho_argument_types (nth s i))))
                      Zero_nat d
               else True) &&
          ho_zero_arity_rules r &&
            all (ho_check_descent_schema_rule s
                  (\ b ->
                    (if less_nat b (size_list sorts) then nth sorts b
                      else Zero_nat))
                  n (nth ranks) (nth priorities) (nth arities) fuel)
              r;

ho_lambda_closure_step ::
  forall a.
    (Eq a,
      Ord a) => [Ho_type] ->
                  [Ho_type] ->
                    (Nat -> a) ->
                      (Nat -> Nat) ->
                        Nat ->
                          [Ho_term] ->
                            ([Ho_type] -> Ho_term -> Bool) ->
                              [Ho_type] -> Ho_term -> Bool;
ho_lambda_closure_step s g rank arity c ls recur d t =
  (case ho_typeof s g d t of {
    Nothing -> False;
    Just a ->
      membera ls t ||
        ((case a of {
           HBase _ -> any (ho_app_subterm t) ls;
           HArrow _ _ -> False;
         }) ||
          ((case t of {
             HBound n -> less_nat n (size_list d);
             HFree _ -> False;
             HConst da -> less (rank da) (rank c);
             HApp f x -> recur d f && recur d x;
             HAbs ta aa -> recur (ta : d) aa;
           }) ||
            (case ho_application_head t of {
              HBound _ -> False;
              HFree _ -> False;
              HConst da ->
                (case ho_lookup s da of {
                  Nothing -> False;
                  Just u ->
                    rank da == rank c &&
                      equal_ho_type a (ho_drop_type (arity da) u) &&
                        list_all2 (\ ta x -> ho_typeof s g d x == Just ta)
                          (take (arity da) (ho_argument_types u))
                          (ho_spine_arguments t) &&
                          ho_lex_subterm (ho_spine_arguments t) ls &&
                            all (recur d) (ho_spine_arguments t);
                });
              HApp _ _ -> False;
              HAbs _ _ -> False;
            })));
  });

ho_check_lambda_closure ::
  [Ho_type] ->
    [Ho_type] ->
      (Nat -> Nat) ->
        (Nat -> Nat) -> Nat -> [Ho_term] -> Nat -> [Ho_type] -> Ho_term -> Bool;
ho_check_lambda_closure s g rank arity c ls Zero_nat d t = False;
ho_check_lambda_closure s g rank arity c ls (Suc fuel) d t =
  ho_lambda_closure_step s g rank arity c ls
    (ho_check_lambda_closure s g rank arity c ls fuel) d t;

ho_check_lambda_schema_rule ::
  [Ho_type] ->
    (Nat -> Nat) ->
      (Nat -> Nat) -> Nat -> ([Ho_type], (Ho_pattern, Ho_pattern)) -> Bool;
ho_check_lambda_schema_rule s rank arity fuel rule =
  (case rule of {
    (g, (l, r)) ->
      ho_rule_welltyped s (g, (l, r)) &&
        (case ho_application_head (ho_erase_pattern l) of {
          HBound _ -> False;
          HFree _ -> False;
          HConst c ->
            (case ho_lookup s c of {
              Nothing -> False;
              Just t ->
                list_all2 (\ a x -> ho_typeof s g [] x == Just a)
                  (take (arity c) (ho_argument_types t))
                  (ho_spine_arguments (ho_erase_pattern l)) &&
                  ho_check_lambda_closure s g rank arity c
                    (ho_spine_arguments (ho_erase_pattern l)) fuel []
                    (ho_erase_pattern r);
            });
          HApp _ _ -> False;
          HAbs _ _ -> False;
        });
  });

ho_check_lambda_schema ::
  [Ho_type] ->
    [([Ho_type], (Ho_pattern, Ho_pattern))] -> [Nat] -> [Nat] -> Nat -> Bool;
ho_check_lambda_schema s r ranks arities fuel =
  equal_nat (size_list ranks) (size_list s) &&
    equal_nat (size_list arities) (size_list s) &&
      let {
        d = minus_nat (size_list s) one_nat;
      } in (if less_nat d (size_list s)
             then all_interval
                    (\ i ->
                      less_eq_nat (nth arities i)
                        (size_list (ho_argument_types (nth s i))))
                    Zero_nat d
             else True) &&
        ho_zero_arity_rules r &&
          all (ho_check_lambda_schema_rule s (nth ranks) (nth arities) fuel) r;

ho_check_application ::
  [Ho_type] -> [([Ho_type], (Ho_pattern, Ho_pattern))] -> Nat -> Bool;
ho_check_application s r c =
  less_nat c (size_list s) &&
    (case nth s c of {
      HBase _ -> False;
      HArrow (HBase _) _ -> False;
      HArrow (HArrow _ _) (HBase _) -> False;
      HArrow (HArrow a b) (HArrow ca d) ->
        equal_ho_type a ca &&
          equal_ho_type b d && r == [ho_application_rule a b c];
    });

ho_check_termination ::
  [Ho_type] ->
    [([Ho_type], (Ho_pattern, Ho_pattern))] ->
      Ho_termination_certificate -> Bool;
ho_check_termination s r HOEmpty = null r;
ho_check_termination s r (HOApplication c) = ho_check_application s r c;
ho_check_termination s r (HOGeneralSchema ranks fuel) =
  ho_check_general_schema s r ranks fuel;
ho_check_termination s r (HOPartialSchema ranks arities fuel) =
  ho_check_schema_with_arities s r ranks arities fuel;
ho_check_termination s r (HOLambdaSchema ranks arities fuel) =
  ho_check_lambda_schema s r ranks arities fuel;
ho_check_termination s r (HOPrioritySchema ranks arities priorities fuel) =
  ho_check_priority_schema s r ranks arities priorities fuel;
ho_check_termination s r
  (HOAccessibleSchema ranks arities priorities sorts fuel) =
  ho_check_accessible_schema s r ranks arities priorities sorts fuel;
ho_check_termination s r (HODescentSchema ranks arities priorities sorts n fuel)
  = ho_check_descent_schema s r ranks arities priorities sorts n fuel;
ho_check_termination s r (HOPolynomial ps fuel proof) =
  ho_check_polynomial_removal s ps fuel r &&
    ho_check_termination s (ho_polynomial_residual s ps fuel r) proof;

ho_check_modular ::
  [Ho_type] ->
    [([Ho_type], (Ho_pattern, Ho_pattern))] -> Ho_modular_certificate -> Bool;
ho_check_modular s r (HOMBase cert) = ho_check_termination s r cert;
ho_check_modular s r (HOMFunctional ranks arities priorities sorts fuel) =
  ho_check_functional_access_schema s r ranks arities priorities sorts fuel;
ho_check_modular s r (HOMLambda ranks arities priorities sorts fuel) =
  ho_check_lambda_access_schema s r ranks arities priorities sorts fuel;
ho_check_modular s r
  (HOMSemantic ps ms ofuel ranks arities priorities sorts fuel) =
  ho_check_semantic_schema s r ps ms ofuel ranks arities priorities sorts fuel;
ho_check_modular s r
  (HOMComponent ps ms ofuel ranks arities priorities sorts fuel) =
  ho_check_component_schema s r ps ms ofuel ranks arities priorities sorts fuel;
ho_check_modular s r (HOMPolynomial ps fuel child) =
  ho_check_polynomial_removal s ps fuel r &&
    ho_check_modular s (ho_polynomial_residual s ps fuel r) child;

ho_check_meta ::
  [Ho_type] ->
    [([Ho_type], (Ho_pattern, Ho_pattern))] -> Ho_modular_certificate -> Bool;
ho_check_meta s r (HOMPolynomial ps fuel child) =
  ho_check_meta_removal s ps fuel r &&
    ho_check_meta s (ho_meta_polynomial_residual s ps fuel r) child;
ho_check_meta s r (HOMBase v) = ho_check_modular s r (HOMBase v);
ho_check_meta s r (HOMFunctional v va vb vc vd) =
  ho_check_modular s r (HOMFunctional v va vb vc vd);
ho_check_meta s r (HOMLambda v va vb vc vd) =
  ho_check_modular s r (HOMLambda v va vb vc vd);
ho_check_meta s r (HOMSemantic v va vb vc vd ve vf vg) =
  ho_check_modular s r (HOMSemantic v va vb vc vd ve vf vg);
ho_check_meta s r (HOMComponent v va vb vc vd ve vf vg) =
  ho_check_modular s r (HOMComponent v va vb vc vd ve vf vg);

ho_plain_images :: [Ho_term] -> Nat -> Ho_term;
ho_plain_images ss i =
  (if less_nat i (size_list ss) then nth ss i else HFree i);

ho_check_rule_pump ::
  [Ho_type] ->
    [([Ho_type], (Ho_pattern, Ho_pattern))] -> Nat -> [Ho_term] -> Bool;
ho_check_rule_pump s r i ss =
  less_nat i (size_list r) &&
    (case nth r i of {
      (g, (l, ra)) ->
        equal_nat (size_list ss) (size_list g) &&
          ho_plain_pattern l &&
            ho_plain_pattern ra &&
              ho_rule_welltyped s (g, (l, ra)) &&
                all ho_plain ss &&
                  ho_typed_subst s g [] g (nth ss) &&
                    equal_ho_term (ho_erase_pattern ra)
                      (ho_subst (nth ss) Zero_nat (ho_erase_pattern l));
    });

ho_guard_body :: Set Nat -> Ho_term -> Bool;
ho_guard_body f (HBound n) = True;
ho_guard_body f (HConst c) = member c f;
ho_guard_body f (HApp t u) = ho_guard_body f t && ho_guard_body f u;
ho_guard_body f (HFree v) = False;
ho_guard_body f (HAbs v va) = False;

ho_guard_vars :: Ho_term -> Set Nat;
ho_guard_vars (HFree n) = insert n bot_set;
ho_guard_vars (HApp t u) = sup_set (ho_guard_vars t) (ho_guard_vars u);
ho_guard_vars (HBound v) = bot_set;
ho_guard_vars (HConst v) = bot_set;
ho_guard_vars (HAbs v va) = bot_set;

ho_lex_signatures :: [Ho_type] -> [([Ho_polynomial], [Ho_polynomial])] -> Bool;
ho_lex_signatures s orders =
  all (\ (ps, ms) ->
        ho_check_polynomial_signature s ps &&
          ho_check_polynomial_signature s ms)
    orders;

ho_plain_context :: Ho_context -> Bool;
ho_plain_context HHole = True;
ho_plain_context (HCLeft c x) = ho_plain_context c && ho_plain x;
ho_plain_context (HCRight x c) = ho_plain x && ho_plain_context c;

ho_check_embedding ::
  [Ho_type] ->
    [Ho_type] ->
      [([Ho_type], (Ho_pattern, Ho_pattern))] ->
        Ho_type -> Ho_term -> [Ho_step_proof] -> Ho_context -> Bool;
ho_check_embedding s v r a t ps c =
  not (null ps) &&
    ho_typeof s v [] t == Just a &&
      ho_typeof s v [] (ho_fill c t) == Just a &&
        ho_check_path s v r a t ps == Just (ho_fill c t);

ho_constant_abstraction :: Ho_term -> Bool;
ho_constant_abstraction (HAbs a (HFree n)) = True;
ho_constant_abstraction (HBound v) = False;
ho_constant_abstraction (HFree v) = False;
ho_constant_abstraction (HConst v) = False;
ho_constant_abstraction (HApp v va) = False;
ho_constant_abstraction (HAbs v (HBound vb)) = False;
ho_constant_abstraction (HAbs v (HConst vb)) = False;
ho_constant_abstraction (HAbs v (HApp vb vc)) = False;
ho_constant_abstraction (HAbs v (HAbs vb vc)) = False;

ho_guard_occurs :: Nat -> Ho_term -> Bool;
ho_guard_occurs n (HBound m) = equal_nat n m;
ho_guard_occurs n (HApp t u) = ho_guard_occurs n t || ho_guard_occurs n u;
ho_guard_occurs n (HFree v) = False;
ho_guard_occurs n (HConst v) = False;
ho_guard_occurs n (HAbs v va) = False;

ho_guard_lambda :: Set Nat -> Ho_term -> Bool;
ho_guard_lambda f (HAbs a t) = ho_guard_body f t && ho_guard_occurs Zero_nat t;
ho_guard_lambda f (HBound v) = False;
ho_guard_lambda f (HFree v) = False;
ho_guard_lambda f (HConst v) = False;
ho_guard_lambda f (HApp v va) = False;

ho_guard_clash :: Set Nat -> [Ho_term] -> [Ho_term] -> Bool;
ho_guard_clash f xs ls =
  any (\ i ->
        less_nat i (size_list ls) &&
          ho_guard_lambda f (nth xs i) && ho_constant_abstraction (nth ls i))
    (upt Zero_nat (size_list xs));

ho_guard_template :: Set Nat -> Ho_term -> Bool;
ho_guard_template f (HFree n) = True;
ho_guard_template f (HConst c) = member c f;
ho_guard_template f (HApp t u) = ho_guard_template f t && ho_guard_template f u;
ho_guard_template f (HBound v) = False;
ho_guard_template f (HAbs v va) = False;

ho_guard_rules :: forall a. Set Nat -> [(a, (Ho_pattern, Ho_pattern))] -> Bool;
ho_guard_rules f r =
  all (\ (_, (l, ra)) ->
        (case ho_application_head (ho_erase_pattern l) of {
          HBound _ -> False;
          HFree _ -> False;
          HConst c ->
            (if member c f
              then ho_guard_template f (ho_erase_pattern l) &&
                     ho_guard_template f (ho_erase_pattern ra) &&
                       equal_set (ho_guard_vars (ho_erase_pattern l))
                         (ho_guard_vars (ho_erase_pattern ra))
              else True);
          HApp _ _ -> False;
          HAbs _ _ -> False;
        }))
    r;

ho_is_abstraction :: Ho_term -> Bool;
ho_is_abstraction (HAbs a t) = True;
ho_is_abstraction (HBound v) = False;
ho_is_abstraction (HFree v) = False;
ho_is_abstraction (HConst v) = False;
ho_is_abstraction (HApp v va) = False;

ho_lambda_clash :: [Ho_term] -> [Ho_term] -> Bool;
ho_lambda_clash xs ls =
  any (\ i ->
        less_nat i (size_list ls) &&
          ho_is_abstraction (nth xs i) &&
            (case ho_application_head (nth ls i) of {
              HBound _ -> False;
              HFree _ -> False;
              HConst _ -> True;
              HApp _ _ -> False;
              HAbs _ _ -> False;
            }))
    (upt Zero_nat (size_list xs));

ho_guard_blocked ::
  forall a b. Set Nat -> [(a, (Ho_pattern, b))] -> Nat -> [Ho_term] -> Bool;
ho_guard_blocked f r c xs =
  all (\ (_, (l, _)) ->
        not (equal_ho_term (ho_application_head (ho_erase_pattern l))
              (HConst c)) ||
          ho_guard_clash f xs (ho_spine_arguments (ho_erase_pattern l)))
    r;

ho_check_plain_step ::
  [Ho_type] ->
    [Ho_type] ->
      [([Ho_type], (Ho_pattern, Ho_pattern))] ->
        Ho_term -> Ho_step_proof -> Maybe Ho_term;
ho_check_plain_step s v r t (HRule i ss) =
  (if less_nat i (size_list r)
    then (case nth r i of {
           (g, (l, ra)) ->
             (if equal_nat (size_list ss) (size_list g) &&
                   ho_rule_welltyped s (g, (l, ra)) &&
                     ho_plain_pattern l &&
                       ho_plain_pattern ra &&
                         all ho_plain ss &&
                           ho_typed_subst s v [] g (ho_plain_images ss) &&
                             equal_ho_term t
                               (ho_subst (ho_plain_images ss) Zero_nat
                                 (ho_erase_pattern l))
               then Just (ho_subst (ho_plain_images ss) Zero_nat
                           (ho_erase_pattern ra))
               else Nothing);
         })
    else Nothing);
ho_check_plain_step s v r t (HLeft p) =
  (case t of {
    HBound _ -> Nothing;
    HFree _ -> Nothing;
    HConst _ -> Nothing;
    HApp f x ->
      (if ho_plain x
        then map_option (\ u -> HApp u x) (ho_check_plain_step s v r f p)
        else Nothing);
    HAbs _ _ -> Nothing;
  });
ho_check_plain_step s v r t (HRight p) =
  (case t of {
    HBound _ -> Nothing;
    HFree _ -> Nothing;
    HConst _ -> Nothing;
    HApp f x ->
      (if ho_plain f then map_option (HApp f) (ho_check_plain_step s v r x p)
        else Nothing);
    HAbs _ _ -> Nothing;
  });
ho_check_plain_step s v r t HBeta = Nothing;
ho_check_plain_step s va r t (HUnder v) = Nothing;

ho_check_plain_path ::
  [Ho_type] ->
    [Ho_type] ->
      [([Ho_type], (Ho_pattern, Ho_pattern))] ->
        Ho_type -> Ho_term -> [Ho_step_proof] -> Maybe Ho_term;
ho_check_plain_path s v r a t [] = Just t;
ho_check_plain_path s v r a t (p : ps) =
  (case ho_check_plain_step s v r t p of {
    Nothing -> Nothing;
    Just u ->
      (if ho_typeof s v [] t == Just a && ho_typeof s v [] u == Just a
        then ho_check_plain_path s v r a u ps else Nothing);
  });

ho_check_plain_pump ::
  [Ho_type] ->
    [Ho_type] ->
      [([Ho_type], (Ho_pattern, Ho_pattern))] ->
        Ho_type ->
          Ho_term -> [Ho_step_proof] -> Ho_context -> [Ho_term] -> Bool;
ho_check_plain_pump s v r a t ps c ss =
  not (null ps) &&
    ho_plain t &&
      ho_plain_context c &&
        equal_nat (size_list ss) (size_list v) &&
          all ho_plain ss &&
            ho_typed_subst s v [] v (ho_plain_images ss) &&
              ho_typeof s v [] t == Just a &&
                ho_typeof s v []
                  (ho_fill c (ho_subst (ho_plain_images ss) Zero_nat t)) ==
                  Just a &&
                  ho_check_plain_path s v r a t ps ==
                    Just (ho_fill c (ho_subst (ho_plain_images ss) Zero_nat t));

ho_lambda_blocked ::
  forall a b. [(a, (Ho_pattern, b))] -> Nat -> [Ho_term] -> Bool;
ho_lambda_blocked r c xs =
  all (\ (_, (l, _)) ->
        not (equal_ho_term (ho_application_head (ho_erase_pattern l))
              (HConst c)) ||
          ho_lambda_clash xs (ho_spine_arguments (ho_erase_pattern l)))
    r;

ho_apply_terms :: Ho_term -> [Ho_term] -> Ho_term;
ho_apply_terms f xs = foldl HApp f xs;

ho_result_sort :: Ho_type -> Nat;
ho_result_sort (HBase b) = b;
ho_result_sort (HArrow a c) = ho_result_sort c;

ho_type_bases :: Ho_type -> Set Nat;
ho_type_bases (HBase b) = insert b bot_set;
ho_type_bases (HArrow a c) = sup_set (ho_type_bases a) (ho_type_bases c);

ho_check_lex_comparison ::
  [Ho_type] ->
    [([Ho_polynomial], [Ho_polynomial])] ->
      Nat -> [Ho_type] -> Nat -> [Ho_term] -> Nat -> [Ho_term] -> Bool -> Bool;
ho_check_lex_comparison s [] fuel g c ls d xs strict = not strict;
ho_check_lex_comparison s ((ps, ms) : orders) fuel g c ls d xs strict =
  ho_check_call_comparison s ps ms fuel g c ls d xs False &&
    (if strict
      then ho_check_call_comparison s ps ms fuel g c ls d xs True ||
             ho_check_lex_comparison s orders fuel g c ls d xs True
      else ho_check_lex_comparison s orders fuel g c ls d xs False);

ho_beta_head_step :: Ho_term -> Maybe Ho_term;
ho_beta_head_step t =
  (case (ho_application_head t, ho_spine_arguments t) of {
    (HBound _, _) -> Nothing;
    (HFree _, _) -> Nothing;
    (HConst _, _) -> Nothing;
    (HApp _ _, _) -> Nothing;
    (HAbs _ _, []) -> Nothing;
    (HAbs _ b, x : xs) -> Just (ho_apply_terms (ho_beta_subst x Zero_nat b) xs);
  });

ho_binder_types :: Ho_term -> Set Ho_type;
ho_binder_types (HApp f x) = sup_set (ho_binder_types f) (ho_binder_types x);
ho_binder_types (HAbs a t) = insert a (ho_binder_types t);
ho_binder_types (HBound v) = bot_set;
ho_binder_types (HFree v) = bot_set;
ho_binder_types (HConst v) = bot_set;

ho_bound_closed :: Nat -> Ho_term -> Bool;
ho_bound_closed d (HBound n) = less_nat n d;
ho_bound_closed d (HFree n) = True;
ho_bound_closed d (HConst n) = True;
ho_bound_closed d (HApp f x) = ho_bound_closed d f && ho_bound_closed d x;
ho_bound_closed d (HAbs a t) = ho_bound_closed (Suc d) t;

ho_beta_head_normal :: Nat -> Ho_term -> Maybe Ho_term;
ho_beta_head_normal Zero_nat t = Nothing;
ho_beta_head_normal (Suc n) t = (case ho_beta_head_step t of {
                                  Nothing -> Just t;
                                  Just a -> ho_beta_head_normal n a;
                                });

ho_prefix_variables :: forall a b. [a] -> [b] -> [Ho_term];
ho_prefix_variables g ds =
  map HFree (upt (size_list g) (plus_nat (size_list g) (size_list ds)));

ho_check_prefix_schema_rule ::
  [Ho_type] ->
    [([Ho_type], (Ho_pattern, Ho_pattern))] ->
      (Nat -> Nat) ->
        (Nat -> Nat) ->
          (Nat -> Nat) ->
            (Nat -> Nat) ->
              Nat -> ([Ho_type], (Ho_pattern, Ho_pattern)) -> Bool;
ho_check_prefix_schema_rule s r sorts prec priority arity fuel rule =
  (case rule of {
    (g, (l, ra)) ->
      ho_rule_welltyped s (g, (l, ra)) &&
        (case ho_application_head (ho_erase_pattern l) of {
          HBound _ -> False;
          HFree _ -> False;
          HConst c ->
            (case ho_lookup s c of {
              Nothing -> False;
              Just t ->
                let {
                  ls = ho_spine_arguments (ho_erase_pattern l);
                  ds = drop (size_list ls)
                         (take (arity c) (ho_argument_types t));
                  vs = ho_prefix_variables g ds;
                  h = g ++ ds;
                  rs = ho_apply_terms (ho_erase_pattern ra) vs;
                } in less_eq_nat (size_list ls) (arity c) &&
                       list_all2 (\ a x -> ho_typeof s h [] x == Just a)
                         (take (arity c) (ho_argument_types t)) (ls ++ vs) &&
                         ho_typeof s h [] rs ==
                           Just (ho_drop_type (arity c) t) &&
                           ho_check_functional_access_closure s h r sorts prec
                             priority arity c (ls ++ vs) fuel [] rs;
            });
          HApp _ _ -> False;
          HAbs _ _ -> False;
        });
  });

ho_check_prefix_schema ::
  [Ho_type] ->
    [([Ho_type], (Ho_pattern, Ho_pattern))] ->
      [Nat] -> [Nat] -> [Nat] -> [Nat] -> Nat -> Bool;
ho_check_prefix_schema s r ranks arities priorities sorts fuel =
  equal_nat (size_list ranks) (size_list s) &&
    equal_nat (size_list arities) (size_list s) &&
      all (\ n -> less_eq_nat n (size_list priorities)) arities &&
        let {
          d = minus_nat (size_list s) one_nat;
        } in (if less_nat d (size_list s)
               then all_interval
                      (\ i ->
                        less_eq_nat (nth arities i)
                          (size_list (ho_argument_types (nth s i))))
                      Zero_nat d
               else True) &&
          ho_zero_arity_rules r &&
            all (ho_check_prefix_schema_rule s r
                  (\ b ->
                    (if less_nat b (size_list sorts) then nth sorts b
                      else Zero_nat))
                  (nth ranks) (nth priorities) (nth arities) fuel)
              r;

ho_check_blocked_closure ::
  [Ho_type] ->
    [Ho_type] ->
      [([Ho_type], (Ho_pattern, Ho_pattern))] ->
        (Nat -> Nat) ->
          (Nat -> Nat) ->
            (Nat -> Nat) ->
              (Nat -> Nat) ->
                Nat -> [Ho_term] -> Nat -> [Ho_type] -> Ho_term -> Bool;
ho_check_blocked_closure s g r sorts prec priority arity c ls Zero_nat d t =
  False;
ho_check_blocked_closure s g r sorts prec priority arity c ls (Suc fuel) d t =
  ho_check_functional_access_closure s g r sorts prec priority arity c ls
    (Suc fuel) d t ||
    (case ho_typeof s g d t of {
      Nothing -> False;
      Just a ->
        (case t of {
          HBound _ -> False;
          HFree _ -> False;
          HConst _ -> False;
          HApp f x ->
            ho_check_blocked_closure s g r sorts prec priority arity c ls fuel d
              f &&
              ho_check_blocked_closure s g r sorts prec priority arity c ls fuel
                d x;
          HAbs ta aa ->
            ho_check_blocked_closure s g r sorts prec priority arity c ls fuel
              (ta : d) aa;
        }) ||
          (case ho_application_head t of {
            HBound _ -> False;
            HFree _ -> False;
            HConst da ->
              (case ho_lookup s da of {
                Nothing -> False;
                Just u ->
                  equal_ho_type a (ho_drop_type (arity da) u) &&
                    list_all2 (\ ta x -> ho_typeof s g d x == Just ta)
                      (take (arity da) (ho_argument_types u))
                      (ho_spine_arguments t) &&
                      ho_lambda_blocked r da (ho_spine_arguments t) &&
                        all (ho_check_blocked_closure s g r sorts prec priority
                              arity c ls fuel d)
                          (ho_spine_arguments t);
              });
            HApp _ _ -> False;
            HAbs _ _ -> False;
          });
    });

ho_check_blocked_schema_rule ::
  [Ho_type] ->
    [([Ho_type], (Ho_pattern, Ho_pattern))] ->
      (Nat -> Nat) ->
        (Nat -> Nat) ->
          (Nat -> Nat) ->
            (Nat -> Nat) ->
              Nat -> ([Ho_type], (Ho_pattern, Ho_pattern)) -> Bool;
ho_check_blocked_schema_rule s r sorts prec priority arity fuel rule =
  (case rule of {
    (g, (l, ra)) ->
      ho_rule_welltyped s (g, (l, ra)) &&
        (case ho_application_head (ho_erase_pattern l) of {
          HBound _ -> False;
          HFree _ -> False;
          HConst c ->
            (case ho_lookup s c of {
              Nothing -> False;
              Just t ->
                list_all2 (\ a x -> ho_typeof s g [] x == Just a)
                  (take (arity c) (ho_argument_types t))
                  (ho_spine_arguments (ho_erase_pattern l)) &&
                  ho_check_blocked_closure s g r sorts prec priority arity c
                    (ho_spine_arguments (ho_erase_pattern l)) fuel []
                    (ho_erase_pattern ra);
            });
          HApp _ _ -> False;
          HAbs _ _ -> False;
        });
  });

ho_check_blocked_schema ::
  [Ho_type] ->
    [([Ho_type], (Ho_pattern, Ho_pattern))] ->
      [Nat] -> [Nat] -> [Nat] -> [Nat] -> Nat -> Bool;
ho_check_blocked_schema s r ranks arities priorities sorts fuel =
  equal_nat (size_list ranks) (size_list s) &&
    equal_nat (size_list arities) (size_list s) &&
      all (\ n -> less_eq_nat n (size_list priorities)) arities &&
        let {
          d = minus_nat (size_list s) one_nat;
        } in (if less_nat d (size_list s)
               then all_interval
                      (\ i ->
                        less_eq_nat (nth arities i)
                          (size_list (ho_argument_types (nth s i))))
                      Zero_nat d
               else True) &&
          ho_zero_arity_rules r &&
            all (ho_check_blocked_schema_rule s r
                  (\ b ->
                    (if less_nat b (size_list sorts) then nth sorts b
                      else Zero_nat))
                  (nth ranks) (nth priorities) (nth arities) fuel)
              r;

ho_check_guarded_closure ::
  Set Nat ->
    [Ho_type] ->
      [Ho_type] ->
        [([Ho_type], (Ho_pattern, Ho_pattern))] ->
          (Nat -> Nat) ->
            (Nat -> Nat) ->
              (Nat -> Nat) ->
                (Nat -> Nat) ->
                  Nat -> [Ho_term] -> Nat -> [Ho_type] -> Ho_term -> Bool;
ho_check_guarded_closure f s g r sorts prec priority arity c ls Zero_nat d t =
  False;
ho_check_guarded_closure f s g r sorts prec priority arity c ls (Suc fuel) d t =
  ho_check_functional_access_closure s g r sorts prec priority arity c ls
    (Suc fuel) d t ||
    (case ho_typeof s g d t of {
      Nothing -> False;
      Just a ->
        (case t of {
          HBound _ -> False;
          HFree _ -> False;
          HConst _ -> False;
          HApp fa x ->
            ho_check_guarded_closure f s g r sorts prec priority arity c ls fuel
              d fa &&
              ho_check_guarded_closure f s g r sorts prec priority arity c ls
                fuel d x;
          HAbs ta aa ->
            ho_check_guarded_closure f s g r sorts prec priority arity c ls fuel
              (ta : d) aa;
        }) ||
          (case ho_application_head t of {
            HBound _ -> False;
            HFree _ -> False;
            HConst da ->
              (case ho_lookup s da of {
                Nothing -> False;
                Just u ->
                  equal_ho_type a (ho_drop_type (arity da) u) &&
                    list_all2 (\ ta x -> ho_typeof s g d x == Just ta)
                      (take (arity da) (ho_argument_types u))
                      (ho_spine_arguments t) &&
                      ho_guard_blocked f r da (ho_spine_arguments t) &&
                        all (ho_bound_closed Zero_nat) (ho_spine_arguments t) &&
                          all (ho_check_guarded_closure f s g r sorts prec
                                priority arity c ls fuel d)
                            (ho_spine_arguments t);
              });
            HApp _ _ -> False;
            HAbs _ _ -> False;
          });
    });

ho_check_guarded_schema_rule ::
  Set Nat ->
    [Ho_type] ->
      [([Ho_type], (Ho_pattern, Ho_pattern))] ->
        (Nat -> Nat) ->
          (Nat -> Nat) ->
            (Nat -> Nat) ->
              (Nat -> Nat) ->
                Nat -> ([Ho_type], (Ho_pattern, Ho_pattern)) -> Bool;
ho_check_guarded_schema_rule f s r sorts prec priority arity fuel rule =
  (case rule of {
    (g, (l, ra)) ->
      ho_rule_welltyped s (g, (l, ra)) &&
        (case ho_application_head (ho_erase_pattern l) of {
          HBound _ -> False;
          HFree _ -> False;
          HConst c ->
            (case ho_lookup s c of {
              Nothing -> False;
              Just t ->
                list_all2 (\ a x -> ho_typeof s g [] x == Just a)
                  (take (arity c) (ho_argument_types t))
                  (ho_spine_arguments (ho_erase_pattern l)) &&
                  ho_check_guarded_closure f s g r sorts prec priority arity c
                    (ho_spine_arguments (ho_erase_pattern l)) fuel []
                    (ho_erase_pattern ra);
            });
          HApp _ _ -> False;
          HAbs _ _ -> False;
        });
  });

ho_check_guarded_schema ::
  Set Nat ->
    [Ho_type] ->
      [([Ho_type], (Ho_pattern, Ho_pattern))] ->
        [Nat] -> [Nat] -> [Nat] -> [Nat] -> Nat -> Bool;
ho_check_guarded_schema f s r ranks arities priorities sorts fuel =
  ho_guard_rules f r &&
    equal_nat (size_list ranks) (size_list s) &&
      equal_nat (size_list arities) (size_list s) &&
        all (\ n -> less_eq_nat n (size_list priorities)) arities &&
          let {
            d = minus_nat (size_list s) one_nat;
          } in (if less_nat d (size_list s)
                 then all_interval
                        (\ i ->
                          less_eq_nat (nth arities i)
                            (size_list (ho_argument_types (nth s i))))
                        Zero_nat d
                 else True) &&
            ho_zero_arity_rules r &&
              all (ho_check_guarded_schema_rule f s r
                    (\ b ->
                      (if less_nat b (size_list sorts) then nth sorts b
                        else Zero_nat))
                    (nth ranks) (nth priorities) (nth arities) fuel)
                r;

ho_expansion_recursive_branch ::
  forall a.
    (Eq a) => [Ho_type] ->
                [Ho_type] ->
                  [Ho_polynomial] ->
                    [Ho_polynomial] ->
                      Nat ->
                        (Nat -> a) ->
                          (Nat -> Nat) ->
                            Nat ->
                              [Ho_term] -> (Ho_term -> Bool) -> Ho_term -> Bool;
ho_expansion_recursive_branch s g ps ms ofuel prec arity c ls recur t =
  (case ho_application_head t of {
    HBound _ -> False;
    HFree _ -> False;
    HConst d ->
      (case ho_lookup s d of {
        Nothing -> False;
        Just u ->
          prec d == prec c &&
            ho_typeof s g [] t == Just (ho_drop_type (arity d) u) &&
              list_all2 (\ ta x -> ho_typeof s g [] x == Just ta)
                (take (arity d) (ho_argument_types u)) (ho_spine_arguments t) &&
                ho_check_call_comparison s ps ms ofuel g c ls d
                  (ho_spine_arguments t) True &&
                  all recur (ho_spine_arguments t);
      });
    HApp _ _ -> False;
    HAbs _ _ -> False;
  });

ho_check_definition_expansion ::
  forall a. [(a, (Ho_pattern, Ho_pattern))] -> Nat -> Ho_term -> Nat -> Bool;
ho_check_definition_expansion r c e fuel =
  ho_closed_at Zero_nat e &&
    all (\ (_, (l, ra)) ->
          (if equal_ho_term (ho_application_head (ho_erase_pattern l))
                (HConst c)
            then ho_beta_head_normal fuel
                   (ho_apply_terms e
                     (ho_spine_arguments (ho_erase_pattern l))) ==
                   Just (ho_erase_pattern ra)
            else True))
      r;

ho_expansion_observation ::
  [Ho_type] ->
    [Ho_type] -> (Ho_type -> [Ho_term]) -> (Ho_term -> Bool) -> Ho_term -> Bool;
ho_expansion_observation s g obs recur t =
  (case ho_typeof s g [] t of {
    Nothing -> False;
    Just ta ->
      not (is_none (ho_typeof s g [] (ho_apply_terms t (obs ta)))) &&
        recur (ho_apply_terms t (obs ta));
  });

ho_expansion_definition_branch ::
  forall a.
    [Ho_type] ->
      [Ho_type] ->
        [(a, (Ho_pattern, Ho_pattern))] ->
          (Nat -> Nat) ->
            (Nat -> Maybe (Ho_term, Nat)) ->
              (Ho_type -> [Ho_term]) -> (Ho_term -> Bool) -> Ho_term -> Bool;
ho_expansion_definition_branch s g r rank defs obs recur t =
  (case (ho_typeof s g [] t, ho_application_head t) of {
    (Nothing, _) -> False;
    (Just (HBase _), HBound _) -> False;
    (Just (HBase _), HFree _) -> False;
    (Just (HBase b), HConst c) ->
      (case ho_lookup s c of {
        Nothing -> False;
        Just ta ->
          (case defs c of {
            Nothing -> False;
            Just (e, fuel) ->
              equal_nat b (ho_result_sort ta) &&
                list_all2 (\ a x -> ho_typeof s g [] x == Just a)
                  (ho_argument_types ta) (ho_spine_arguments t) &&
                  ho_check_definition_expansion r c e fuel &&
                    ho_typeof s g []
                      (ho_apply_terms e (ho_spine_arguments t)) ==
                      Just (HBase b) &&
                      all (ho_expansion_observation s g obs recur)
                        (ho_spine_arguments t) &&
                        all (\ x ->
                              (case ho_typeof s g [] x of {
                                Nothing -> False;
                                Just a ->
                                  (if ho_positive_type rank (rank b) a
                                    then recur x else True);
                              }))
                          (ho_spine_arguments t) &&
                          recur (ho_apply_terms e (ho_spine_arguments t));
          });
      });
    (Just (HBase _), HApp _ _) -> False;
    (Just (HBase _), HAbs _ _) -> False;
    (Just (HArrow _ _), _) -> False;
  });

ho_expansion_beta_branch ::
  [Ho_type] ->
    [Ho_type] -> (Ho_type -> [Ho_term]) -> (Ho_term -> Bool) -> Ho_term -> Bool;
ho_expansion_beta_branch s g obs recur t =
  (case (ho_typeof s g [] t, (ho_application_head t, ho_spine_arguments t)) of {
    (Nothing, _) -> False;
    (Just (HBase _), (HBound _, _)) -> False;
    (Just (HBase _), (HFree _, _)) -> False;
    (Just (HBase _), (HConst _, _)) -> False;
    (Just (HBase _), (HApp _ _, _)) -> False;
    (Just (HBase _), (HAbs _ _, [])) -> False;
    (Just (HBase b), (HAbs _ body, x : xs)) ->
      all (ho_expansion_observation s g obs recur) (x : xs) &&
        ho_typeof s g [] (ho_apply_terms (ho_beta_subst x Zero_nat body) xs) ==
          Just (HBase b) &&
          recur (ho_apply_terms (ho_beta_subst x Zero_nat body) xs);
    (Just (HArrow _ _), _) -> False;
  });

ho_check_expansion_closure ::
  forall a.
    [Ho_type] ->
      [Ho_type] ->
        [(a, (Ho_pattern, Ho_pattern))] ->
          (Nat -> Nat) ->
            (Nat -> Maybe (Ho_term, Nat)) ->
              (Ho_type -> [Ho_term]) ->
                (Ho_term -> Bool) ->
                  ((Ho_term -> Bool) -> Ho_term -> Bool) ->
                    Nat -> Ho_term -> Bool;
ho_check_expansion_closure s g r rank defs obs leaf extra Zero_nat t = False;
ho_check_expansion_closure s g r rank defs obs leaf extra (Suc n) t =
  not (is_none (ho_typeof s g [] t)) &&
    (leaf t ||
      (extra (ho_check_expansion_closure s g r rank defs obs leaf extra n) t ||
        ((case t of {
           HBound _ -> False;
           HFree _ -> False;
           HConst _ -> False;
           HApp f x ->
             ho_check_expansion_closure s g r rank defs obs leaf extra n f &&
               ho_check_expansion_closure s g r rank defs obs leaf extra n x;
           HAbs _ _ -> False;
         }) ||
          (ho_expansion_beta_branch s g obs
             (ho_check_expansion_closure s g r rank defs obs leaf extra n) t ||
            ho_expansion_definition_branch s g r rank defs obs
              (ho_check_expansion_closure s g r rank defs obs leaf extra n)
              t))));

ho_check_call_semantic_closure ::
  forall a.
    [Ho_type] ->
      [Ho_type] ->
        [(a, (Ho_pattern, Ho_pattern))] ->
          Set Nat ->
            (Nat -> Maybe (Ho_term, Nat)) ->
              (Ho_type -> [Ho_term]) ->
                (Nat -> Nat) ->
                  [Ho_polynomial] ->
                    [Ho_polynomial] ->
                      Nat ->
                        (Nat -> Nat) ->
                          (Nat -> Nat) ->
                            (Nat -> Nat) ->
                              Nat -> [Ho_term] -> Nat -> Nat -> Ho_term -> Bool;
ho_check_call_semantic_closure s g r k defs obs sorts ps ms ofuel prec priority
  arity c ls fuel efuel t =
  ho_check_expansion_closure s g r sorts defs obs
    (\ u ->
      ball (ho_binder_types u) (\ ta -> less_eq_set (ho_type_bases ta) k) &&
        ho_check_semantic_closure s g sorts ps ms ofuel prec priority arity c ls
          fuel [] u)
    (ho_expansion_recursive_branch s g ps ms ofuel prec arity c ls) efuel t;

ho_expansion_witness :: [Ho_type] -> [Ho_type] -> Ho_type -> Maybe Ho_term;
ho_expansion_witness s g (HBase b) =
  (case find (\ i -> equal_ho_type (nth g i) (HBase b))
          (upt Zero_nat (size_list g))
    of {
    Nothing ->
      map_option HConst
        (find (\ i -> equal_ho_type (nth s i) (HBase b))
          (upt Zero_nat (size_list s)));
    Just i -> Just (HFree i);
  });
ho_expansion_witness s g (HArrow a c) =
  (case find (\ i -> equal_ho_type (nth g i) (HArrow a c))
          (upt Zero_nat (size_list g))
    of {
    Nothing ->
      (if equal_ho_type a c then Just (HAbs a (HBound Zero_nat))
        else map_option (\ t -> HAbs a (ho_lift one_nat Zero_nat t))
               (ho_expansion_witness s g c));
    Just i -> Just (HFree i);
  });

ho_expansion_observations :: [Ho_type] -> [Ho_type] -> Ho_type -> [Ho_term];
ho_expansion_observations s g t =
  (case those (map (ho_expansion_witness s g) (ho_argument_types t)) of {
    Nothing -> [];
    Just ts -> ts;
  });

ho_check_expansion_schema_rule ::
  forall a.
    [Ho_type] ->
      [(a, (Ho_pattern, Ho_pattern))] ->
        Set Nat ->
          (Nat -> Maybe (Ho_term, Nat)) ->
            Nat ->
              (Nat -> Nat) ->
                [Ho_polynomial] ->
                  [Ho_polynomial] ->
                    Nat ->
                      (Nat -> Nat) ->
                        (Nat -> Nat) ->
                          (Nat -> Nat) ->
                            Nat ->
                              ([Ho_type], (Ho_pattern, Ho_pattern)) -> Bool;
ho_check_expansion_schema_rule s r k defs efuel sorts ps ms ofuel prec priority
  arity fuel rule =
  (case rule of {
    (g, (l, ra)) ->
      ho_rule_welltyped s (g, (l, ra)) &&
        (case ho_application_head (ho_erase_pattern l) of {
          HBound _ -> False;
          HFree _ -> False;
          HConst c ->
            (case ho_lookup s c of {
              Nothing -> False;
              Just t ->
                list_all2 (\ a x -> ho_typeof s g [] x == Just a)
                  (take (arity c) (ho_argument_types t))
                  (ho_spine_arguments (ho_erase_pattern l)) &&
                  ho_check_call_semantic_closure s g r k defs
                    (ho_expansion_observations s g) sorts ps ms ofuel prec
                    priority arity c (ho_spine_arguments (ho_erase_pattern l))
                    fuel efuel (ho_erase_pattern ra);
            });
          HApp _ _ -> False;
          HAbs _ _ -> False;
        });
  });

ho_expansion_sorts ::
  forall a b. [Ho_type] -> [(a, (b, Ho_pattern))] -> Set Nat;
ho_expansion_sorts s r =
  sup_set (sup_seta (image ho_type_bases (Set s)))
    (sup_seta
      (image
        (\ (_, (_, ra)) ->
          sup_seta
            (image ho_type_bases (ho_binder_types (ho_erase_pattern ra))))
        (Set r)));

ho_check_expansion_schema ::
  [Ho_type] ->
    [([Ho_type], (Ho_pattern, Ho_pattern))] ->
      (Nat -> Maybe (Ho_term, Nat)) ->
        Nat ->
          [Ho_polynomial] ->
            [Ho_polynomial] ->
              Nat -> [Nat] -> [Nat] -> [Nat] -> [Nat] -> Nat -> Bool;
ho_check_expansion_schema s r defs efuel ps ms ofuel ranks arities priorities
  sorts fuel =
  ho_check_polynomial_signature s ps &&
    ho_check_polynomial_signature s ms &&
      all (\ (g, (a, b)) -> ho_check_weak_polynomial_rule s ps ofuel g a b) r &&
        equal_nat (size_list ranks) (size_list s) &&
          equal_nat (size_list arities) (size_list s) &&
            all (\ n -> less_eq_nat n (size_list priorities)) arities &&
              let {
                d = minus_nat (size_list s) one_nat;
              } in (if less_nat d (size_list s)
                     then all_interval
                            (\ i ->
                              less_eq_nat (nth arities i)
                                (size_list (ho_argument_types (nth s i))))
                            Zero_nat d
                     else True) &&
                ho_zero_arity_rules r &&
                  all (ho_check_expansion_schema_rule s r
                        (ho_expansion_sorts s r) defs efuel
                        (\ b ->
                          (if less_nat b (size_list sorts) then nth sorts b
                            else Zero_nat))
                        ps ms ofuel (nth ranks) (nth priorities) (nth arities)
                        fuel)
                    r;

ho_check_expansion_input ::
  [Ho_type] ->
    [([Ho_type], (Ho_pattern, Ho_pattern))] ->
      [Maybe (Ho_term, Nat)] ->
        Nat ->
          [Ho_polynomial] ->
            [Ho_polynomial] ->
              Nat -> [Nat] -> [Nat] -> [Nat] -> [Nat] -> Nat -> Bool;
ho_check_expansion_input s r ds efuel ps ms ofuel ranks arities priorities sorts
  fuel =
  ho_check_expansion_schema s r
    (\ c -> (if less_nat c (size_list ds) then nth ds c else Nothing)) efuel ps
    ms ofuel ranks arities priorities sorts fuel;

ho_expansion_diagnostics ::
  [Ho_type] ->
    [([Ho_type], (Ho_pattern, Ho_pattern))] ->
      [Maybe (Ho_term, Nat)] ->
        Nat ->
          [Ho_polynomial] ->
            [Ho_polynomial] ->
              Nat -> [Nat] -> [Nat] -> [Nat] -> [Nat] -> Nat -> [Bool];
ho_expansion_diagnostics s r ds efuel ps ms ofuel ranks arities priorities sorts
  fuel =
  let {
    defs = (\ c -> (if less_nat c (size_list ds) then nth ds c else Nothing));
    rank =
      (\ b -> (if less_nat b (size_list sorts) then nth sorts b else Zero_nat));
  } in [ho_check_polynomial_signature s ps,
         ho_check_polynomial_signature s ms] ++
         map (\ (g, (a, b)) -> ho_check_weak_polynomial_rule s ps ofuel g a b)
           r ++
           map (ho_check_expansion_schema_rule s r (ho_expansion_sorts s r) defs
                 efuel rank ps ms ofuel (nth ranks) (nth priorities)
                 (nth arities) fuel)
             r;

ho_lex_semantic_closure_step ::
  [Ho_type] ->
    [Ho_type] ->
      (Nat -> Nat) ->
        [([Ho_polynomial], [Ho_polynomial])] ->
          Nat ->
            (Nat -> Nat) ->
              (Nat -> Nat) ->
                (Nat -> Nat) ->
                  Nat ->
                    [Ho_term] ->
                      ([Ho_type] -> Ho_term -> Bool) ->
                        [Ho_type] -> Ho_term -> Bool;
ho_lex_semantic_closure_step s g sorts orders ofuel prec priority arity c ls
  recur d t =
  (case ho_typeof s g d t of {
    Nothing -> False;
    Just a ->
      membera ls t ||
        (any (ho_accessible_from s g sorts t) ls ||
          ((case t of {
             HBound n -> less_nat n (size_list d);
             HFree _ -> False;
             HConst da -> less_nat (prec da) (prec c);
             HApp f x -> recur d f && recur d x;
             HAbs ta aa -> recur (ta : d) aa;
           }) ||
            (case ho_application_head t of {
              HBound _ -> False;
              HFree _ -> False;
              HConst da ->
                (case ho_lookup s da of {
                  Nothing -> False;
                  Just u ->
                    equal_nat (prec da) (prec c) &&
                      equal_ho_type a (ho_drop_type (arity da) u) &&
                        list_all2 (\ ta x -> ho_typeof s g d x == Just ta)
                          (take (arity da) (ho_argument_types u))
                          (ho_spine_arguments t) &&
                          (null d &&
                            (ho_check_lex_comparison s orders ofuel g c ls da
                               (ho_spine_arguments t) True ||
                              ho_check_lex_comparison s orders ofuel g c ls da
                                (ho_spine_arguments t) False &&
                                ho_lex_subterm
                                  (ho_priority_arguments priority
                                    (ho_spine_arguments t))
                                  (ho_priority_arguments priority ls))) &&
                            all (recur d) (ho_spine_arguments t);
                });
              HApp _ _ -> False;
              HAbs _ _ -> False;
            })));
  });

ho_check_lex_semantic_closure ::
  [Ho_type] ->
    [Ho_type] ->
      (Nat -> Nat) ->
        [([Ho_polynomial], [Ho_polynomial])] ->
          Nat ->
            (Nat -> Nat) ->
              (Nat -> Nat) ->
                (Nat -> Nat) ->
                  Nat -> [Ho_term] -> Nat -> [Ho_type] -> Ho_term -> Bool;
ho_check_lex_semantic_closure s g sorts orders ofuel prec priority arity c ls
  Zero_nat d t = False;
ho_check_lex_semantic_closure s g sorts orders ofuel prec priority arity c ls
  (Suc fuel) d t =
  ho_lex_semantic_closure_step s g sorts orders ofuel prec priority arity c ls
    (ho_check_lex_semantic_closure s g sorts orders ofuel prec priority arity c
      ls fuel)
    d t;

ho_check_lex_semantic_schema_rule ::
  [Ho_type] ->
    (Nat -> Nat) ->
      [([Ho_polynomial], [Ho_polynomial])] ->
        Nat ->
          (Nat -> Nat) ->
            (Nat -> Nat) ->
              (Nat -> Nat) ->
                Nat -> ([Ho_type], (Ho_pattern, Ho_pattern)) -> Bool;
ho_check_lex_semantic_schema_rule s sorts orders ofuel prec priority arity fuel
  rule =
  (case rule of {
    (g, (l, r)) ->
      ho_rule_welltyped s (g, (l, r)) &&
        (case ho_application_head (ho_erase_pattern l) of {
          HBound _ -> False;
          HFree _ -> False;
          HConst c ->
            (case ho_lookup s c of {
              Nothing -> False;
              Just t ->
                list_all2 (\ a x -> ho_typeof s g [] x == Just a)
                  (take (arity c) (ho_argument_types t))
                  (ho_spine_arguments (ho_erase_pattern l)) &&
                  ho_check_lex_semantic_closure s g sorts orders ofuel prec
                    priority arity c (ho_spine_arguments (ho_erase_pattern l))
                    fuel [] (ho_erase_pattern r);
            });
          HApp _ _ -> False;
          HAbs _ _ -> False;
        });
  });

ho_check_lex_semantic_schema ::
  [Ho_type] ->
    [([Ho_type], (Ho_pattern, Ho_pattern))] ->
      [([Ho_polynomial], [Ho_polynomial])] ->
        Nat -> [Nat] -> [Nat] -> [Nat] -> [Nat] -> Nat -> Bool;
ho_check_lex_semantic_schema s r orders ofuel ranks arities priorities sorts
  fuel =
  ho_lex_signatures s orders &&
    all (\ (ps, _) ->
          all (\ (g, (a, b)) -> ho_check_weak_polynomial_rule s ps ofuel g a b)
            r)
      orders &&
      equal_nat (size_list ranks) (size_list s) &&
        equal_nat (size_list arities) (size_list s) &&
          all (\ n -> less_eq_nat n (size_list priorities)) arities &&
            let {
              d = minus_nat (size_list s) one_nat;
            } in (if less_nat d (size_list s)
                   then all_interval
                          (\ i ->
                            less_eq_nat (nth arities i)
                              (size_list (ho_argument_types (nth s i))))
                          Zero_nat d
                   else True) &&
              ho_zero_arity_rules r &&
                all (ho_check_lex_semantic_schema_rule s
                      (\ b ->
                        (if less_nat b (size_list sorts) then nth sorts b
                          else Zero_nat))
                      orders ofuel (nth ranks) (nth priorities) (nth arities)
                      fuel)
                  r;

ho_check_guarded_certificate ::
  [Ho_type] ->
    [([Ho_type], (Ho_pattern, Ho_pattern))] -> Ho_guarded_certificate -> Bool;
ho_check_guarded_certificate s r (HOGBase cert) = ho_check_modular s r cert;
ho_check_guarded_certificate s r
  (HOGSchema ranks arities priorities sorts fuel guards) =
  ho_check_guarded_schema (Set guards) s r ranks arities priorities sorts fuel;
ho_check_guarded_certificate s r (HOGPolynomial ps fuel child) =
  ho_check_polynomial_removal s ps fuel r &&
    ho_check_guarded_certificate s (ho_polynomial_residual s ps fuel r) child;

}
