{-# LANGUAGE EmptyDataDecls, RankNTypes, ScopedTypeVariables #-}

module
  ITS_Checker(Num, Char, char_of_integer, integer_of_char, Ia4_sig, Ty, Xml,
               Lts_impl, Sum(..), Xml_error, Sum_bot, Its4_proof,
               check_its4_string)
  where {

import Prelude ((==), (/=), (<), (<=), (>=), (>), (+), (-), (*), (/), (**),
  (>>=), (>>), (=<<), (&&), (||), (^), (^^), (.), ($), ($!), (++), (!!), Eq,
  error, id, return, not, fst, snd, map, filter, concat, concatMap, reverse,
  zip, null, takeWhile, dropWhile, all, any, Integer, negate, abs, divMod,
  String, Bool(True, False), Maybe(Nothing, Just));
import Data.Bits ((.&.), (.|.), (.^.));
import qualified Prelude;
import qualified Data.Bits;
import qualified Uint;
import qualified Array;
import qualified Uint32;
import qualified Uint64;
import qualified Data_Bits;
import qualified Bit_Shifts;
import qualified Str_Literal;

newtype Int = Int_of_integer Integer;

integer_of_int :: Int -> Integer;
integer_of_int (Int_of_integer k) = k;

times_int :: Int -> Int -> Int;
times_int k l = Int_of_integer (integer_of_int k * integer_of_int l);

zero_int :: Int;
zero_int = Int_of_integer (0 :: Integer);

data Num = One | Bit0 Num | Bit1 Num;

one_int :: Int;
one_int = Int_of_integer (1 :: Integer);

class Times a where {
  times :: a -> a -> a;
};

apsnd :: forall a b c. (a -> b) -> (c, a) -> (c, b);
apsnd f (x, y) = (x, f y);

divmod_integer :: Integer -> Integer -> (Integer, Integer);
divmod_integer k l =
  (if k == (0 :: Integer) then ((0 :: Integer), (0 :: Integer))
    else (if (0 :: Integer) < l
           then (if (0 :: Integer) < k then divMod ( k ) ( l )
                  else (case divMod ( (negate k) ) ( l ) of {
                         (r, s) ->
                           (if s == (0 :: Integer)
                             then (negate r, (0 :: Integer))
                             else (negate r - (1 :: Integer), l - s));
                       }))
           else (if l == (0 :: Integer) then ((0 :: Integer), k)
                  else apsnd negate
                         (if k < (0 :: Integer)
                           then divMod ( (negate k) ) ( (negate l) )
                           else (case divMod ( k ) ( (negate l) ) of {
                                  (r, s) ->
                                    (if s == (0 :: Integer)
                                      then (negate r, (0 :: Integer))
                                      else (negate r - (1 :: Integer),
     negate l - s));
                                })))));

divide_integer :: Integer -> Integer -> Integer;
divide_integer k l = fst (divmod_integer k l);

lcm_integer :: Integer -> Integer -> Integer;
lcm_integer a b =
  divide_integer (Prelude.abs a * Prelude.abs b) (Prelude.gcd a b);

lcm_int :: Int -> Int -> Int;
lcm_int (Int_of_integer x) (Int_of_integer y) =
  Int_of_integer (lcm_integer x y);

gcd_int :: Int -> Int -> Int;
gcd_int (Int_of_integer x) (Int_of_integer y) =
  Int_of_integer (Prelude.gcd x y);

class Zero a where {
  zeroa :: a;
};

class One a where {
  one :: a;
};

class (Times a) => Dvd a where {
};

class (One a, Zero a, Dvd a) => Gcd a where {
  gcd :: a -> a -> a;
  lcm :: a -> a -> a;
};

instance Zero Int where {
  zeroa = zero_int;
};

instance One Int where {
  one = one_int;
};

instance Times Int where {
  times = times_int;
};

instance Dvd Int where {
};

instance Gcd Int where {
  gcd = gcd_int;
  lcm = lcm_int;
};

equal_int :: Int -> Int -> Bool;
equal_int k l = integer_of_int k == integer_of_int l;

instance Eq Int where {
  a == b = equal_int a b;
};

uminus_int :: Int -> Int;
uminus_int k = Int_of_integer (negate (integer_of_int k));

minus_int :: Int -> Int -> Int;
minus_int k l = Int_of_integer (integer_of_int k - integer_of_int l);

plus_int :: Int -> Int -> Int;
plus_int k l = Int_of_integer (integer_of_int k + integer_of_int l);

class Uminus a where {
  uminus :: a -> a;
};

class Minus a where {
  minus :: a -> a -> a;
};

class Plus a where {
  plus :: a -> a -> a;
};

class (Plus a) => Semigroup_add a where {
};

class (Semigroup_add a) => Cancel_semigroup_add a where {
};

class (Semigroup_add a) => Ab_semigroup_add a where {
};

class (Ab_semigroup_add a, Cancel_semigroup_add a,
        Minus a) => Cancel_ab_semigroup_add a where {
};

class (Semigroup_add a, Zero a) => Monoid_add a where {
};

class (Ab_semigroup_add a, Monoid_add a) => Comm_monoid_add a where {
};

class (Cancel_ab_semigroup_add a,
        Comm_monoid_add a) => Cancel_comm_monoid_add a where {
};

class (Times a, Zero a) => Mult_zero a where {
};

class (Times a) => Semigroup_mult a where {
};

class (Ab_semigroup_add a, Semigroup_mult a) => Semiring a where {
};

class (Comm_monoid_add a, Mult_zero a, Semiring a) => Semiring_0 a where {
};

class (Cancel_comm_monoid_add a, Semiring_0 a) => Semiring_0_cancel a where {
};

class (Cancel_semigroup_add a, Minus a, Monoid_add a,
        Uminus a) => Group_add a where {
};

class (Cancel_comm_monoid_add a, Group_add a) => Ab_group_add a where {
};

class (Ab_group_add a, Semiring_0_cancel a) => Ring a where {
};

instance Plus Int where {
  plus = plus_int;
};

instance Semigroup_add Int where {
};

instance Cancel_semigroup_add Int where {
};

instance Ab_semigroup_add Int where {
};

instance Minus Int where {
  minus = minus_int;
};

instance Cancel_ab_semigroup_add Int where {
};

instance Monoid_add Int where {
};

instance Comm_monoid_add Int where {
};

instance Cancel_comm_monoid_add Int where {
};

instance Mult_zero Int where {
};

instance Semigroup_mult Int where {
};

instance Semiring Int where {
};

instance Semiring_0 Int where {
};

instance Semiring_0_cancel Int where {
};

instance Uminus Int where {
  uminus = uminus_int;
};

instance Group_add Int where {
};

instance Ab_group_add Int where {
};

instance Ring Int where {
};

class (One a, Semigroup_add a) => Numeral a where {
};

instance Numeral Int where {
};

class (One a, Times a) => Power a where {
};

instance Power Int where {
};

divide_int :: Int -> Int -> Int;
divide_int k l =
  Int_of_integer (divide_integer (integer_of_int k) (integer_of_int l));

class Divide a where {
  divide :: a -> a -> a;
};

instance Divide Int where {
  divide = divide_int;
};

class (Semigroup_mult a, Power a) => Monoid_mult a where {
};

class (Monoid_mult a, Numeral a, Semiring a) => Semiring_numeral a where {
};

class (One a, Zero a) => Zero_neq_one a where {
};

class (Semiring_numeral a, Semiring_0 a, Zero_neq_one a) => Semiring_1 a where {
};

class (Semiring_0_cancel a, Semiring_1 a) => Semiring_1_cancel a where {
};

class (Group_add a, Numeral a) => Neg_numeral a where {
};

class (Neg_numeral a, Ring a, Semiring_1_cancel a) => Ring_1 a where {
};

instance Monoid_mult Int where {
};

instance Semiring_numeral Int where {
};

instance Zero_neq_one Int where {
};

instance Semiring_1 Int where {
};

instance Semiring_1_cancel Int where {
};

instance Neg_numeral Int where {
};

instance Ring_1 Int where {
};

less_eq_int :: Int -> Int -> Bool;
less_eq_int k l = integer_of_int k <= integer_of_int l;

class Ord a where {
  less_eq :: a -> a -> Bool;
  less :: a -> a -> Bool;
};

less_int :: Int -> Int -> Bool;
less_int k l = integer_of_int k < integer_of_int l;

instance Ord Int where {
  less_eq = less_eq_int;
  less = less_int;
};

class (Semiring_0 a) => Semiring_no_zero_divisors a where {
};

class (Semiring_1 a,
        Semiring_no_zero_divisors a) => Semiring_1_no_zero_divisors a where {
};

class (Semigroup_mult a) => Ab_semigroup_mult a where {
};

class (Ab_semigroup_mult a, Semiring a) => Comm_semiring a where {
};

class (Comm_semiring a, Semiring_0 a) => Comm_semiring_0 a where {
};

class (Comm_semiring_0 a,
        Semiring_0_cancel a) => Comm_semiring_0_cancel a where {
};

class (Ab_semigroup_mult a, Monoid_mult a, Dvd a) => Comm_monoid_mult a where {
};

class (Comm_monoid_mult a, Comm_semiring_0 a,
        Semiring_1 a) => Comm_semiring_1 a where {
};

class (Comm_semiring_0_cancel a, Comm_semiring_1 a,
        Semiring_1_cancel a) => Comm_semiring_1_cancel a where {
};

class (Comm_semiring_1_cancel a,
        Semiring_1_no_zero_divisors a) => Semidom a where {
};

instance Semiring_no_zero_divisors Int where {
};

instance Semiring_1_no_zero_divisors Int where {
};

instance Ab_semigroup_mult Int where {
};

instance Comm_semiring Int where {
};

instance Comm_semiring_0 Int where {
};

instance Comm_semiring_0_cancel Int where {
};

instance Comm_monoid_mult Int where {
};

instance Comm_semiring_1 Int where {
};

instance Comm_semiring_1_cancel Int where {
};

instance Semidom Int where {
};

class (Ord a) => Quasi_order a where {
};

class (Quasi_order a) => Weak_order a where {
};

class (Ord a) => Preorder a where {
};

class (Preorder a, Weak_order a) => Order a where {
};

instance Quasi_order Int where {
};

instance Weak_order Int where {
};

instance Preorder Int where {
};

instance Order Int where {
};

abs_int :: Int -> Int;
abs_int i = (if less_int i zero_int then uminus_int i else i);

normalize_int :: Int -> Int;
normalize_int = abs_int;

sgn_int :: Int -> Int;
sgn_int i =
  (if equal_int i zero_int then zero_int
    else (if less_int zero_int i then one_int else uminus_int one_int));

unit_factor_int :: Int -> Int;
unit_factor_int = sgn_int;

class (Semiring_no_zero_divisors a) => Semiring_no_zero_divisors_cancel a where {
};

class (One a, Zero a, Divide a) => Divide_trivial a where {
};

class (Divide_trivial a, Semidom a,
        Semiring_no_zero_divisors_cancel a) => Semidom_divide a where {
};

class Unit_factor a where {
  unit_factor :: a -> a;
};

class (Semidom_divide a, Unit_factor a) => Semidom_divide_unit_factor a where {
};

class (Semidom_divide a) => Algebraic_semidom a where {
};

class (Algebraic_semidom a,
        Semidom_divide_unit_factor a) => Normalization_semidom a where {
  normalizeb :: a -> a;
};

class (Gcd a, Comm_semiring_1 a) => Comm_monoid_gcd a where {
};

class (Normalization_semidom a, Comm_monoid_gcd a) => Semiring_gcd a where {
};

instance Comm_monoid_gcd Int where {
};

instance Semiring_no_zero_divisors_cancel Int where {
};

instance Divide_trivial Int where {
};

instance Semidom_divide Int where {
};

instance Unit_factor Int where {
  unit_factor = unit_factor_int;
};

instance Semidom_divide_unit_factor Int where {
};

instance Algebraic_semidom Int where {
};

instance Normalization_semidom Int where {
  normalizeb = normalize_int;
};

instance Semiring_gcd Int where {
};

class (Order a) => Linorder a where {
};

instance Linorder Int where {
};

modulo_integer :: Integer -> Integer -> Integer;
modulo_integer k l = snd (divmod_integer k l);

newtype Nat = Nat Integer;

integer_of_nat :: Nat -> Integer;
integer_of_nat (Nat x) = x;

modulo_nat :: Nat -> Nat -> Nat;
modulo_nat m n = Nat (modulo_integer (integer_of_nat m) (integer_of_nat n));

divide_nat :: Nat -> Nat -> Nat;
divide_nat m n = Nat (divide_integer (integer_of_nat m) (integer_of_nat n));

max :: forall a. (Ord a) => a -> a -> a;
max a b = (if less_eq a b then b else a);

instance Ord Integer where {
  less_eq = (\ a b -> a <= b);
  less = (\ a b -> a < b);
};

nat_of_integer :: Integer -> Nat;
nat_of_integer k = Nat (max (0 :: Integer) k);

newtype Char = Chr Integer;

char_of_integer :: Integer -> Char;
char_of_integer k =
  Chr (if (0 :: Integer) <= k && k < (256 :: Integer) then k
        else modulo_integer k (256 :: Integer));

integer_of_char :: Char -> Integer;
integer_of_char (Chr x) = x;

implode :: [Char] -> String;
implode cs = Str_Literal.literalOfAsciis (map integer_of_char cs);

lit_of_digit :: Nat -> String;
lit_of_digit n = implode [char_of_integer ((48 :: Integer) + integer_of_nat n)];

less_nat :: Nat -> Nat -> Bool;
less_nat m n = integer_of_nat m < integer_of_nat n;

showsl_lit :: String -> String -> String;
showsl_lit = (\ a b -> a ++ b);

showsl_nat :: Nat -> String -> String;
showsl_nat n =
  (if less_nat n (nat_of_integer (10 :: Integer))
    then showsl_lit (lit_of_digit n)
    else showsl_nat (divide_nat n (nat_of_integer (10 :: Integer))) .
           showsl_lit
             (lit_of_digit (modulo_nat n (nat_of_integer (10 :: Integer)))));

nat :: Int -> Nat;
nat = nat_of_integer . integer_of_int;

showsl_int :: Int -> String -> String;
showsl_int i =
  (if less_int i zero_int then showsl_lit "-" . showsl_nat (nat (uminus_int i))
    else showsl_nat (nat i));

showsl_sep ::
  forall a.
    (a -> String -> String) -> (String -> String) -> [a] -> String -> String;
showsl_sep s sep [] = showsl_lit "";
showsl_sep s sep [x] = s x;
showsl_sep s sep (x : v : va) = (s x . sep) . showsl_sep s sep (v : va);

showsl_list_gen ::
  forall a.
    (a -> String -> String) ->
      String -> String -> String -> String -> [a] -> String -> String;
showsl_list_gen showslx e l s r xs =
  (if null xs then showsl_lit e
    else (showsl_lit l . showsl_sep showslx (showsl_lit s) xs) . showsl_lit r);

default_showsl_list ::
  forall a. (a -> String -> String) -> [a] -> String -> String;
default_showsl_list sl = showsl_list_gen sl "[]" "[" ", " "]";

showsl_list_int :: [Int] -> String -> String;
showsl_list_int xs = default_showsl_list showsl_int xs;

class Showl a where {
  showsl :: a -> String -> String;
  showsl_list :: [a] -> String -> String;
};

instance Showl Int where {
  showsl = showsl_int;
  showsl_list = showsl_list_int;
};

equal_nat :: Nat -> Nat -> Bool;
equal_nat m n = integer_of_nat m == integer_of_nat n;

instance Eq Nat where {
  a == b = equal_nat a b;
};

times_nat :: Nat -> Nat -> Nat;
times_nat m n = Nat (integer_of_nat m * integer_of_nat n);

instance Times Nat where {
  times = times_nat;
};

instance Dvd Nat where {
};

one_nat :: Nat;
one_nat = Nat (1 :: Integer);

instance One Nat where {
  one = one_nat;
};

plus_nat :: Nat -> Nat -> Nat;
plus_nat m n = Nat (integer_of_nat m + integer_of_nat n);

instance Plus Nat where {
  plus = plus_nat;
};

zero_nat :: Nat;
zero_nat = Nat (0 :: Integer);

instance Zero Nat where {
  zeroa = zero_nat;
};

instance Semigroup_add Nat where {
};

instance Numeral Nat where {
};

instance Power Nat where {
};

minus_nat :: Nat -> Nat -> Nat;
minus_nat m n = Nat (max (0 :: Integer) (integer_of_nat m - integer_of_nat n));

instance Minus Nat where {
  minus = minus_nat;
};

instance Divide Nat where {
  divide = divide_nat;
};

class (Divide a, Dvd a) => Modulo a where {
  modulo :: a -> a -> a;
};

instance Modulo Nat where {
  modulo = modulo_nat;
};

less_eq_nat :: Nat -> Nat -> Bool;
less_eq_nat m n = integer_of_nat m <= integer_of_nat n;

class (Linorder a, Comm_semiring_1_cancel a) => Interval a where {
};

instance Cancel_semigroup_add Nat where {
};

instance Ab_semigroup_add Nat where {
};

instance Cancel_ab_semigroup_add Nat where {
};

instance Monoid_add Nat where {
};

instance Comm_monoid_add Nat where {
};

instance Cancel_comm_monoid_add Nat where {
};

instance Mult_zero Nat where {
};

instance Semigroup_mult Nat where {
};

instance Semiring Nat where {
};

instance Semiring_0 Nat where {
};

instance Semiring_0_cancel Nat where {
};

instance Ab_semigroup_mult Nat where {
};

instance Comm_semiring Nat where {
};

instance Comm_semiring_0 Nat where {
};

instance Comm_semiring_0_cancel Nat where {
};

instance Monoid_mult Nat where {
};

instance Semiring_numeral Nat where {
};

instance Zero_neq_one Nat where {
};

instance Semiring_1 Nat where {
};

instance Semiring_1_cancel Nat where {
};

instance Comm_monoid_mult Nat where {
};

instance Comm_semiring_1 Nat where {
};

instance Comm_semiring_1_cancel Nat where {
};

instance Ord Nat where {
  less_eq = less_eq_nat;
  less = less_nat;
};

instance Quasi_order Nat where {
};

instance Weak_order Nat where {
};

instance Preorder Nat where {
};

instance Order Nat where {
};

instance Linorder Nat where {
};

instance Interval Nat where {
};

instance Semiring_no_zero_divisors Nat where {
};

instance Semiring_1_no_zero_divisors Nat where {
};

instance Semidom Nat where {
};

data Ordera = Eqa | Lt | Gt;

comparator_of :: forall a. (Eq a, Linorder a) => a -> a -> Ordera;
comparator_of x y = (if less x y then Lt else (if x == y then Eqa else Gt));

compare_nat :: Nat -> Nat -> Ordera;
compare_nat = comparator_of;

class Compare a where {
  compare :: a -> a -> Ordera;
};

instance Compare Nat where {
  compare = compare_nat;
};

instance Divide_trivial Nat where {
};

instance Semiring_no_zero_divisors_cancel Nat where {
};

instance Semidom_divide Nat where {
};

class (Comm_semiring_1_cancel a, Modulo a) => Semiring_modulo a where {
};

class (Divide_trivial a, Semiring_modulo a) => Semiring_modulo_trivial a where {
};

class (Algebraic_semidom a,
        Semiring_modulo_trivial a) => Semidom_modulo a where {
};

instance Semiring_modulo Nat where {
};

instance Semiring_modulo_trivial Nat where {
};

instance Algebraic_semidom Nat where {
};

instance Semidom_modulo Nat where {
};

class (Compare a, Linorder a) => Compare_order a where {
};

instance Compare_order Nat where {
};

newtype Rat = Frct (Int, Int);

quotient_of :: Rat -> (Int, Int);
quotient_of (Frct x) = x;

equal_rat :: Rat -> Rat -> Bool;
equal_rat a b = quotient_of a == quotient_of b;

instance Eq Rat where {
  a == b = equal_rat a b;
};

normalize :: (Int, Int) -> (Int, Int);
normalize p =
  (if less_int zero_int (snd p)
    then let {
           a = gcd_int (fst p) (snd p);
         } in (divide_int (fst p) a, divide_int (snd p) a)
    else (if equal_int (snd p) zero_int then (zero_int, one_int)
           else let {
                  a = uminus_int (gcd_int (fst p) (snd p));
                } in (divide_int (fst p) a, divide_int (snd p) a)));

times_rat :: Rat -> Rat -> Rat;
times_rat p q =
  Frct (case quotient_of p of {
         (a, c) -> (case quotient_of q of {
                     (b, d) -> normalize (times_int a b, times_int c d);
                   });
       });

instance Times Rat where {
  times = times_rat;
};

instance Dvd Rat where {
};

abs_rat :: Rat -> Rat;
abs_rat p = Frct (case quotient_of p of {
                   (a, b) -> (abs_int a, b);
                 });

class Abs a where {
  absa :: a -> a;
};

instance Abs Rat where {
  absa = abs_rat;
};

one_rat :: Rat;
one_rat = Frct (one_int, one_int);

instance One Rat where {
  one = one_rat;
};

sgn_rat :: Rat -> Rat;
sgn_rat p = Frct (sgn_int (fst (quotient_of p)), one_int);

class Sgn a where {
  sgn :: a -> a;
};

instance Sgn Rat where {
  sgn = sgn_rat;
};

uminus_rat :: Rat -> Rat;
uminus_rat p = Frct (case quotient_of p of {
                      (a, b) -> (uminus_int a, b);
                    });

minus_rat :: Rat -> Rat -> Rat;
minus_rat p q =
  Frct (case quotient_of p of {
         (a, c) ->
           (case quotient_of q of {
             (b, d) ->
               normalize
                 (minus_int (times_int a d) (times_int b c), times_int c d);
           });
       });

zero_rat :: Rat;
zero_rat = Frct (zero_int, one_int);

plus_rat :: Rat -> Rat -> Rat;
plus_rat p q =
  Frct (case quotient_of p of {
         (a, c) ->
           (case quotient_of q of {
             (b, d) ->
               normalize
                 (plus_int (times_int a d) (times_int b c), times_int c d);
           });
       });

class (Comm_semiring_1_cancel a) => Comm_semiring_1_cancel_crossproduct a where {
};

class (Ring a,
        Semiring_no_zero_divisors_cancel a) => Ring_no_zero_divisors a where {
};

class (Ring_1 a, Ring_no_zero_divisors a,
        Semiring_1_no_zero_divisors a) => Ring_1_no_zero_divisors a where {
};

class (Comm_semiring_0_cancel a, Ring a) => Comm_ring a where {
};

class (Comm_ring a, Comm_semiring_1_cancel a, Ring_1 a) => Comm_ring_1 a where {
};

class (Comm_ring_1 a, Ring_1_no_zero_divisors a, Semidom a,
        Comm_semiring_1_cancel_crossproduct a) => Idom a where {
};

instance Plus Rat where {
  plus = plus_rat;
};

instance Semigroup_add Rat where {
};

instance Cancel_semigroup_add Rat where {
};

instance Ab_semigroup_add Rat where {
};

instance Minus Rat where {
  minus = minus_rat;
};

instance Cancel_ab_semigroup_add Rat where {
};

instance Zero Rat where {
  zeroa = zero_rat;
};

instance Monoid_add Rat where {
};

instance Comm_monoid_add Rat where {
};

instance Cancel_comm_monoid_add Rat where {
};

instance Mult_zero Rat where {
};

instance Semigroup_mult Rat where {
};

instance Semiring Rat where {
};

instance Semiring_0 Rat where {
};

instance Semiring_0_cancel Rat where {
};

instance Ab_semigroup_mult Rat where {
};

instance Comm_semiring Rat where {
};

instance Comm_semiring_0 Rat where {
};

instance Comm_semiring_0_cancel Rat where {
};

instance Power Rat where {
};

instance Monoid_mult Rat where {
};

instance Numeral Rat where {
};

instance Semiring_numeral Rat where {
};

instance Zero_neq_one Rat where {
};

instance Semiring_1 Rat where {
};

instance Semiring_1_cancel Rat where {
};

instance Comm_monoid_mult Rat where {
};

instance Comm_semiring_1 Rat where {
};

instance Comm_semiring_1_cancel Rat where {
};

instance Comm_semiring_1_cancel_crossproduct Rat where {
};

instance Semiring_no_zero_divisors Rat where {
};

instance Semiring_1_no_zero_divisors Rat where {
};

instance Semiring_no_zero_divisors_cancel Rat where {
};

instance Uminus Rat where {
  uminus = uminus_rat;
};

instance Group_add Rat where {
};

instance Ab_group_add Rat where {
};

instance Ring Rat where {
};

instance Ring_no_zero_divisors Rat where {
};

instance Neg_numeral Rat where {
};

instance Ring_1 Rat where {
};

instance Ring_1_no_zero_divisors Rat where {
};

instance Comm_ring Rat where {
};

instance Comm_ring_1 Rat where {
};

instance Semidom Rat where {
};

instance Idom Rat where {
};

inverse_rat :: Rat -> Rat;
inverse_rat p =
  Frct (case quotient_of p of {
         (a, b) ->
           (if equal_int a zero_int then (zero_int, one_int)
             else (times_int (sgn_int a) b, abs_int a));
       });

divide_rat :: Rat -> Rat -> Rat;
divide_rat p q =
  Frct (case quotient_of p of {
         (a, c) -> (case quotient_of q of {
                     (b, d) -> normalize (times_int a d, times_int c b);
                   });
       });

class (Divide a) => Inverse a where {
  inverse :: a -> a;
};

class (Idom a) => Ufd a where {
};

class (Inverse a, Divide_trivial a,
        Ring_1_no_zero_divisors a) => Division_ring a where {
};

class (Idom a, Semidom_divide a) => Idom_divide a where {
};

class (Division_ring a, Idom_divide a, Ufd a) => Field a where {
};

instance Ufd Rat where {
};

instance Divide Rat where {
  divide = divide_rat;
};

instance Divide_trivial Rat where {
};

instance Inverse Rat where {
  inverse = inverse_rat;
};

instance Division_ring Rat where {
};

instance Semidom_divide Rat where {
};

instance Idom_divide Rat where {
};

instance Field Rat where {
};

less_eq_rat :: Rat -> Rat -> Bool;
less_eq_rat p q =
  (case quotient_of p of {
    (a, c) -> (case quotient_of q of {
                (b, d) -> less_eq_int (times_int a d) (times_int c b);
              });
  });

less_rat :: Rat -> Rat -> Bool;
less_rat p q =
  (case quotient_of p of {
    (a, c) -> (case quotient_of q of {
                (b, d) -> less_int (times_int a d) (times_int c b);
              });
  });

class (Abs a, Minus a, Uminus a, Zero a, Ord a) => Abs_if a where {
};

instance Ord Rat where {
  less_eq = less_eq_rat;
  less = less_rat;
};

instance Abs_if Rat where {
};

class (Semiring_1 a) => Semiring_char_0 a where {
};

class (Semiring_char_0 a, Ring_1 a) => Ring_char_0 a where {
};

instance Semiring_char_0 Rat where {
};

instance Ring_char_0 Rat where {
};

instance Quasi_order Rat where {
};

instance Weak_order Rat where {
};

instance Preorder Rat where {
};

instance Order Rat where {
};

class (Order a) => No_bot a where {
};

instance No_bot Rat where {
};

class (Order a) => No_top a where {
};

instance No_top Rat where {
};

instance Linorder Rat where {
};

class (Abs a, Sgn a, Idom a) => Idom_abs_sgn a where {
};

instance Idom_abs_sgn Rat where {
};

class (Ab_semigroup_add a, Order a) => Ordered_ab_semigroup_add a where {
};

class (Ordered_ab_semigroup_add a) => Strict_ordered_ab_semigroup_add a where {
};

class (Cancel_ab_semigroup_add a,
        Strict_ordered_ab_semigroup_add a) => Ordered_cancel_ab_semigroup_add a where {
};

class (Comm_monoid_add a,
        Ordered_ab_semigroup_add a) => Ordered_comm_monoid_add a where {
};

class (Ordered_comm_monoid_add a, Semiring a) => Ordered_semiring a where {
};

class (Ordered_semiring a, Semiring_0 a) => Ordered_semiring_0 a where {
};

class (Ordered_cancel_ab_semigroup_add a, Ordered_semiring_0 a,
        Semiring_0_cancel a) => Ordered_cancel_semiring a where {
};

class (Ordered_cancel_ab_semigroup_add a) => Ordered_ab_semigroup_add_imp_le a where {
};

class (Comm_monoid_add a,
        Strict_ordered_ab_semigroup_add a) => Strict_ordered_comm_monoid_add a where {
};

class (Ordered_cancel_ab_semigroup_add a, Ordered_comm_monoid_add a,
        Strict_ordered_comm_monoid_add a) => Ordered_cancel_comm_monoid_add a where {
};

class (Cancel_comm_monoid_add a, Ordered_ab_semigroup_add_imp_le a,
        Ordered_cancel_comm_monoid_add a) => Ordered_ab_semigroup_monoid_add_imp_le a where {
};

class (Ab_group_add a,
        Ordered_ab_semigroup_monoid_add_imp_le a) => Ordered_ab_group_add a where {
};

class (Ordered_ab_group_add a, Ordered_cancel_semiring a,
        Ring a) => Ordered_ring a where {
};

instance Ordered_ab_semigroup_add Rat where {
};

instance Strict_ordered_ab_semigroup_add Rat where {
};

instance Ordered_cancel_ab_semigroup_add Rat where {
};

instance Ordered_comm_monoid_add Rat where {
};

instance Ordered_semiring Rat where {
};

instance Ordered_semiring_0 Rat where {
};

instance Ordered_cancel_semiring Rat where {
};

instance Ordered_ab_semigroup_add_imp_le Rat where {
};

instance Strict_ordered_comm_monoid_add Rat where {
};

instance Ordered_cancel_comm_monoid_add Rat where {
};

instance Ordered_ab_semigroup_monoid_add_imp_le Rat where {
};

instance Ordered_ab_group_add Rat where {
};

instance Ordered_ring Rat where {
};

class (Field a, Ring_char_0 a) => Field_char_0 a where {
};

instance Field_char_0 Rat where {
};

class (Order a, Zero_neq_one a) => Zero_less_one a where {
};

instance Zero_less_one Rat where {
};

class (Field a, Idom_abs_sgn a) => Field_abs_sgn a where {
};

instance Field_abs_sgn Rat where {
};

class (Order a) => Dense_order a where {
};

instance Dense_order Rat where {
};

class (Ordered_cancel_ab_semigroup_add a, Ordered_semiring a,
        Semiring_0_cancel a) => Ordered_semiring_strict a where {
};

class (Ordered_ab_semigroup_add a,
        Linorder a) => Linordered_ab_semigroup_add a where {
};

class (Linordered_ab_semigroup_add a,
        Ordered_ab_semigroup_add_imp_le a) => Linordered_cancel_ab_semigroup_add a where {
};

class (Linordered_cancel_ab_semigroup_add a,
        Ordered_ab_semigroup_monoid_add_imp_le a,
        Ordered_cancel_semiring a) => Linordered_semiring a where {
};

class (Linordered_semiring a,
        Ordered_semiring_strict a) => Linordered_semiring_strict a where {
};

class (Ordered_semiring_0 a, Semiring_1 a,
        Zero_less_one a) => Ordered_semiring_1 a where {
};

class (Ordered_semiring_1 a,
        Ordered_semiring_strict a) => Ordered_semiring_1_strict a where {
};

class (Linordered_semiring a,
        Ordered_semiring_1 a) => Linordered_semiring_1 a where {
};

class (Linordered_semiring_1 a, Linordered_semiring_strict a,
        Ordered_semiring_1_strict a) => Linordered_semiring_1_strict a where {
};

class (Abs a, Ordered_ab_group_add a) => Ordered_ab_group_add_abs a where {
};

class (Linordered_cancel_ab_semigroup_add a,
        Ordered_ab_group_add a) => Linordered_ab_group_add a where {
};

class (Linordered_ab_group_add a, Ordered_ab_group_add_abs a, Abs_if a,
        Linordered_semiring a, Ordered_ring a) => Linordered_ring a where {
};

class (Linordered_ring a, Linordered_semiring_strict a,
        Ring_no_zero_divisors a) => Linordered_ring_strict a where {
};

class (Ordered_semiring_0 a,
        Ordered_semiring_strict a) => Semiring_real_line a where {
};

class (Semiring_real_line a,
        Ordered_semiring_1 a) => Semiring_1_real_line a where {
};

class (Comm_semiring_0 a, Ordered_semiring a) => Ordered_comm_semiring a where {
};

class (Comm_semiring_0_cancel a, Ordered_cancel_semiring a,
        Ordered_comm_semiring a) => Ordered_cancel_comm_semiring a where {
};

class (Ordered_cancel_comm_semiring a,
        Ordered_semiring_strict a) => Ordered_comm_semiring_strict a where {
};

class (Linordered_semiring_strict a,
        Ordered_comm_semiring_strict a) => Linordered_comm_semiring_strict a where {
};

class (Semiring_char_0 a, Linorder a, Comm_semiring_1 a,
        Ordered_comm_semiring a,
        Ordered_semiring_1 a) => Linordered_nonzero_semiring a where {
};

class (Linordered_comm_semiring_strict a, Linordered_nonzero_semiring a,
        Semidom a) => Linordered_semidom a where {
};

class (Comm_ring a, Ordered_cancel_comm_semiring a,
        Ordered_ring a) => Ordered_comm_ring a where {
};

class (Ordered_ab_group_add_abs a, Ordered_ring a) => Ordered_ring_abs a where {
};

class (Ring_char_0 a, Semiring_1_real_line a, Idom_abs_sgn a,
        Linordered_ring_strict a, Linordered_semidom a,
        Linordered_semiring_1_strict a, Ordered_comm_ring a,
        Ordered_ring_abs a) => Linordered_idom a where {
};

instance Ordered_semiring_strict Rat where {
};

instance Linordered_ab_semigroup_add Rat where {
};

instance Linordered_cancel_ab_semigroup_add Rat where {
};

instance Linordered_semiring Rat where {
};

instance Linordered_semiring_strict Rat where {
};

instance Ordered_semiring_1 Rat where {
};

instance Ordered_semiring_1_strict Rat where {
};

instance Linordered_semiring_1 Rat where {
};

instance Linordered_semiring_1_strict Rat where {
};

instance Ordered_ab_group_add_abs Rat where {
};

instance Linordered_ab_group_add Rat where {
};

instance Linordered_ring Rat where {
};

instance Linordered_ring_strict Rat where {
};

instance Semiring_real_line Rat where {
};

instance Semiring_1_real_line Rat where {
};

instance Ordered_comm_semiring Rat where {
};

instance Ordered_cancel_comm_semiring Rat where {
};

instance Ordered_comm_semiring_strict Rat where {
};

instance Linordered_comm_semiring_strict Rat where {
};

instance Linordered_nonzero_semiring Rat where {
};

instance Linordered_semidom Rat where {
};

instance Ordered_comm_ring Rat where {
};

instance Ordered_ring_abs Rat where {
};

instance Linordered_idom Rat where {
};

class (Ord a) => Non_strict_order a where {
};

class (Ab_semigroup_add a, Monoid_add a,
        Non_strict_order a) => Ordered_ab_semigroup a where {
};

class (Semiring_0 a, Ordered_ab_semigroup a) => Ordered_semiring_0a a where {
};

class (Semiring_1 a, Ordered_semiring_0a a) => Ordered_semiring_1a a where {
};

class (Comm_semiring_1 a, Ordered_semiring_1a a) => Poly_carrier a where {
};

instance Non_strict_order Rat where {
};

instance Ordered_ab_semigroup Rat where {
};

instance Ordered_semiring_0a Rat where {
};

instance Ordered_semiring_1a Rat where {
};

instance Poly_carrier Rat where {
};

class (Dense_order a, No_bot a, No_top a) => Unbounded_dense_order a where {
};

class (Dense_order a, Linorder a) => Dense_linorder a where {
};

class (Dense_linorder a,
        Unbounded_dense_order a) => Unbounded_dense_linorder a where {
};

class (Field_abs_sgn a, Field_char_0 a, Unbounded_dense_linorder a,
        Linordered_idom a) => Linordered_field a where {
};

instance Unbounded_dense_order Rat where {
};

instance Dense_linorder Rat where {
};

instance Unbounded_dense_linorder Rat where {
};

instance Linordered_field Rat where {
};

class (Linordered_field a) => Archimedean_field a where {
};

class (Poly_carrier a) => Large_ordered_semiring_1 a where {
};

class (Archimedean_field a,
        Large_ordered_semiring_1 a) => Floor_ceiling a where {
  floor :: a -> Int;
};

floor_rat :: Rat -> Int;
floor_rat p = (case quotient_of p of {
                (a, b) -> divide_int a b;
              });

instance Archimedean_field Rat where {
};

instance Large_ordered_semiring_1 Rat where {
};

instance Floor_ceiling Rat where {
  floor = floor_rat;
};

less_eq_list :: forall a. (Eq a, Order a) => [a] -> [a] -> Bool;
less_eq_list (x : xs) [] = False;
less_eq_list [] xs = True;
less_eq_list (x : xs) (y : ys) = less x y || x == y && less_eq_list xs ys;

less_list :: forall a. (Eq a, Order a) => [a] -> [a] -> Bool;
less_list xs [] = False;
less_list [] (x : xs) = True;
less_list (x : xs) (y : ys) = less x y || x == y && less_list xs ys;

instance (Eq a, Order a) => Ord [a] where {
  less_eq = less_eq_list;
  less = less_list;
};

comparator_list :: forall a. (a -> a -> Ordera) -> [a] -> [a] -> Ordera;
comparator_list comp_a [] [] = Eqa;
comparator_list comp_a [] (y : ya) = Lt;
comparator_list comp_a (x : xa) [] = Gt;
comparator_list comp_a (x : xa) (y : ya) =
  (case comp_a x y of {
    Eqa -> comparator_list comp_a xa ya;
    Lt -> Lt;
    Gt -> Gt;
  });

compare_list :: forall a. (Compare a) => [a] -> [a] -> Ordera;
compare_list = comparator_list compare;

instance (Compare a) => Compare [a] where {
  compare = compare_list;
};

instance (Eq a, Order a) => Quasi_order [a] where {
};

instance (Eq a, Order a) => Weak_order [a] where {
};

instance (Eq a, Order a) => Preorder [a] where {
};

instance (Eq a, Order a) => Order [a] where {
};

instance (Eq a, Linorder a) => Linorder [a] where {
};

showsl_lista :: forall a. (Showl a) => [a] -> String -> String;
showsl_lista xs = showsl_list xs;

showsl_list_list :: forall a. (Showl a) => [[a]] -> String -> String;
showsl_list_list xs = default_showsl_list showsl_lista xs;

instance (Showl a) => Showl [a] where {
  showsl = showsl_lista;
  showsl_list = showsl_list_list;
};

instance (Compare_order a, Eq a) => Compare_order [a] where {
};

data Term a b = Var b | Fun a [Term a b];

instance (Eq a, Eq b) => Eq (Term a b) where {
  a == b = equal_term a b;
};

equal_term :: forall a b. (Eq a, Eq b) => Term a b -> Term a b -> Bool;
equal_term (Var x1) (Fun x21 x22) = False;
equal_term (Fun x21 x22) (Var x1) = False;
equal_term (Fun x21 x22) (Fun y21 y22) = x21 == y21 && x22 == y22;
equal_term (Var x1) (Var y1) = x1 == y1;

showsl_term ::
  forall a b.
    (a -> String -> String) ->
      (b -> String -> String) -> Term a b -> String -> String;
showsl_term fun var (Var x) = var x;
showsl_term fun var (Fun f ts) =
  fun f . showsl_list_gen id "" "(" ", " ")" (map (showsl_term fun var) ts);

showsl_terma :: forall a b. (Showl a, Showl b) => Term a b -> String -> String;
showsl_terma t = showsl_term showsl showsl t;

showsl_list_term ::
  forall a b. (Showl a, Showl b) => [Term a b] -> String -> String;
showsl_list_term xs = default_showsl_list showsl_terma xs;

instance (Showl a, Showl b) => Showl (Term a b) where {
  showsl = showsl_terma;
  showsl_list = showsl_list_term;
};

equal_char :: Char -> Char -> Bool;
equal_char c d = integer_of_char c == integer_of_char d;

instance Eq Char where {
  a == b = equal_char a b;
};

shows_prec_char :: Nat -> Char -> [Char] -> [Char];
shows_prec_char p c = (\ a -> c : a);

shows_string :: [Char] -> [Char] -> [Char];
shows_string = (\ a b -> a ++ b);

shows_list_char :: [Char] -> [Char] -> [Char];
shows_list_char cs = shows_string cs;

class Showa a where {
  shows_prec :: Nat -> a -> [Char] -> [Char];
  shows_list :: [a] -> [Char] -> [Char];
};

instance Showa Char where {
  shows_prec = shows_prec_char;
  shows_list = shows_list_char;
};

less_eq_char :: Char -> Char -> Bool;
less_eq_char c d = integer_of_char c <= integer_of_char d;

less_char :: Char -> Char -> Bool;
less_char c d = integer_of_char c < integer_of_char d;

instance Ord Char where {
  less_eq = less_eq_char;
  less = less_char;
};

instance Quasi_order Char where {
};

instance Weak_order Char where {
};

instance Preorder Char where {
};

instance Order Char where {
};

instance Linorder Char where {
};

compare_char :: Char -> Char -> Ordera;
compare_char = comparator_of;

instance Compare Char where {
  compare = compare_char;
};

showsl_list_char :: [Char] -> String -> String;
showsl_list_char cs s = showsl_lit (implode cs) s;

showsl_char :: Char -> String -> String;
showsl_char c = showsl_lit (implode [c]);

instance Showl Char where {
  showsl = showsl_char;
  showsl_list = showsl_list_char;
};

instance Compare_order Char where {
};

data Trans_var a = Pre a | Post a | Intermediate a;

equal_trans_var :: forall a. (Eq a) => Trans_var a -> Trans_var a -> Bool;
equal_trans_var (Post x2) (Intermediate x3) = False;
equal_trans_var (Intermediate x3) (Post x2) = False;
equal_trans_var (Pre x1) (Intermediate x3) = False;
equal_trans_var (Intermediate x3) (Pre x1) = False;
equal_trans_var (Pre x1) (Post x2) = False;
equal_trans_var (Post x2) (Pre x1) = False;
equal_trans_var (Intermediate x3) (Intermediate y3) = x3 == y3;
equal_trans_var (Post x2) (Post y2) = x2 == y2;
equal_trans_var (Pre x1) (Pre y1) = x1 == y1;

instance (Eq a) => Eq (Trans_var a) where {
  a == b = equal_trans_var a b;
};

comparator_trans_var ::
  forall a. (a -> a -> Ordera) -> Trans_var a -> Trans_var a -> Ordera;
comparator_trans_var comp_v (Pre x) (Pre y) = comp_v x y;
comparator_trans_var comp_v (Pre x) (Post ya) = Lt;
comparator_trans_var comp_v (Pre x) (Intermediate yb) = Lt;
comparator_trans_var comp_v (Post x) (Pre y) = Gt;
comparator_trans_var comp_v (Post x) (Post ya) = comp_v x ya;
comparator_trans_var comp_v (Post x) (Intermediate yb) = Lt;
comparator_trans_var comp_v (Intermediate x) (Pre y) = Gt;
comparator_trans_var comp_v (Intermediate x) (Post ya) = Gt;
comparator_trans_var comp_v (Intermediate x) (Intermediate yb) = comp_v x yb;

compare_trans_var ::
  forall a. (Compare a) => Trans_var a -> Trans_var a -> Ordera;
compare_trans_var = comparator_trans_var compare;

instance (Compare a) => Compare (Trans_var a) where {
  compare = compare_trans_var;
};

showsl_trans_var :: forall a. (Showl a) => Trans_var a -> String -> String;
showsl_trans_var (Pre v) = showsl v;
showsl_trans_var (Post v) = showsl v . showsl_lit "\'";
showsl_trans_var (Intermediate v) = showsl v . showsl_lit "#";

showsl_list_trans_var ::
  forall a. (Showl a) => [Trans_var a] -> String -> String;
showsl_list_trans_var xs = default_showsl_list showsl_trans_var xs;

instance (Showl a) => Showl (Trans_var a) where {
  showsl = showsl_trans_var;
  showsl_list = showsl_list_trans_var;
};

data QDelta = QDelta Rat Rat;

equal_QDelta :: QDelta -> QDelta -> Bool;
equal_QDelta (QDelta x1 x2) (QDelta y1 y2) = equal_rat x1 y1 && equal_rat x2 y2;

instance Eq QDelta where {
  a == b = equal_QDelta a b;
};

one_QDelta :: QDelta;
one_QDelta = QDelta one_rat zero_rat;

instance One QDelta where {
  one = one_QDelta;
};

qdsnd :: QDelta -> Rat;
qdsnd (QDelta a b) = b;

qdfst :: QDelta -> Rat;
qdfst (QDelta a b) = a;

plus_QDelta :: QDelta -> QDelta -> QDelta;
plus_QDelta qd1 qd2 =
  QDelta (plus_rat (qdfst qd1) (qdfst qd2)) (plus_rat (qdsnd qd1) (qdsnd qd2));

instance Plus QDelta where {
  plus = plus_QDelta;
};

zero_QDelta :: QDelta;
zero_QDelta = QDelta zero_rat zero_rat;

instance Zero QDelta where {
  zeroa = zero_QDelta;
};

minus_QDelta :: QDelta -> QDelta -> QDelta;
minus_QDelta qd1 qd2 =
  QDelta (minus_rat (qdfst qd1) (qdfst qd2))
    (minus_rat (qdsnd qd1) (qdsnd qd2));

instance Minus QDelta where {
  minus = minus_QDelta;
};

uminus_QDelta :: QDelta -> QDelta;
uminus_QDelta qd = QDelta (uminus_rat (qdfst qd)) (uminus_rat (qdsnd qd));

instance Uminus QDelta where {
  uminus = uminus_QDelta;
};

less_eq_QDelta :: QDelta -> QDelta -> Bool;
less_eq_QDelta qd1 qd2 =
  less_rat (qdfst qd1) (qdfst qd2) ||
    equal_rat (qdfst qd1) (qdfst qd2) && less_eq_rat (qdsnd qd1) (qdsnd qd2);

less_QDelta :: QDelta -> QDelta -> Bool;
less_QDelta qd1 qd2 =
  less_rat (qdfst qd1) (qdfst qd2) ||
    equal_rat (qdfst qd1) (qdfst qd2) && less_rat (qdsnd qd1) (qdsnd qd2);

instance Ord QDelta where {
  less_eq = less_eq_QDelta;
  less = less_QDelta;
};

instance Quasi_order QDelta where {
};

instance Weak_order QDelta where {
};

instance Preorder QDelta where {
};

instance Order QDelta where {
};

instance Semigroup_add QDelta where {
};

instance Cancel_semigroup_add QDelta where {
};

instance Monoid_add QDelta where {
};

instance Group_add QDelta where {
};

instance Linorder QDelta where {
};

instance Ab_semigroup_add QDelta where {
};

instance Cancel_ab_semigroup_add QDelta where {
};

instance Comm_monoid_add QDelta where {
};

instance Cancel_comm_monoid_add QDelta where {
};

instance Ab_group_add QDelta where {
};

scaleRat_QDelta :: Rat -> QDelta -> QDelta;
scaleRat_QDelta r qd = QDelta (times_rat r (qdfst qd)) (times_rat r (qdsnd qd));

class ScaleRat a where {
  scaleRat :: Rat -> a -> a;
};

class (Ab_group_add a, ScaleRat a) => Rational_vector a where {
};

class (Order a, Rational_vector a) => Ordered_rational_vector a where {
};

class (Ordered_ab_semigroup_add a, Linorder a,
        Ordered_rational_vector a) => Linordered_rational_vector a where {
};

class (One a, Linordered_rational_vector a) => Lrv a where {
};

instance ScaleRat QDelta where {
  scaleRat = scaleRat_QDelta;
};

instance Rational_vector QDelta where {
};

instance Ordered_rational_vector QDelta where {
};

instance Ordered_ab_semigroup_add QDelta where {
};

instance Linordered_rational_vector QDelta where {
};

instance Lrv QDelta where {
};

data Formula a = Atom a | NegAtom a | Conjunction [Formula a]
  | Disjunction [Formula a];

instance (Eq a) => Eq (Formula a) where {
  a == b = equal_formula a b;
};

equal_formula :: forall a. (Eq a) => Formula a -> Formula a -> Bool;
equal_formula (Conjunction x3) (Disjunction x4) = False;
equal_formula (Disjunction x4) (Conjunction x3) = False;
equal_formula (NegAtom x2) (Disjunction x4) = False;
equal_formula (Disjunction x4) (NegAtom x2) = False;
equal_formula (NegAtom x2) (Conjunction x3) = False;
equal_formula (Conjunction x3) (NegAtom x2) = False;
equal_formula (Atom x1) (Disjunction x4) = False;
equal_formula (Disjunction x4) (Atom x1) = False;
equal_formula (Atom x1) (Conjunction x3) = False;
equal_formula (Conjunction x3) (Atom x1) = False;
equal_formula (Atom x1) (NegAtom x2) = False;
equal_formula (NegAtom x2) (Atom x1) = False;
equal_formula (Disjunction x4) (Disjunction y4) = x4 == y4;
equal_formula (Conjunction x3) (Conjunction y3) = x3 == y3;
equal_formula (NegAtom x2) (NegAtom y2) = x2 == y2;
equal_formula (Atom x1) (Atom y1) = x1 == y1;

newtype Monom a = Abs_monom [(a, Nat)];

rep_monom :: forall a. (Linorder a) => Monom a -> [(a, Nat)];
rep_monom (Abs_monom x) = x;

equal_monom :: forall a. (Eq a, Linorder a) => Monom a -> Monom a -> Bool;
equal_monom xa xc = rep_monom xa == rep_monom xc;

instance (Eq a, Linorder a) => Eq (Monom a) where {
  a == b = equal_monom a b;
};

showsl_prod :: forall a b. (Showl a, Showl b) => (a, b) -> String -> String;
showsl_prod (x, y) =
  (((showsl_lit "(" . showsl x) . showsl_lit ", ") . showsl y) . showsl_lit ")";

showsl_list_prod ::
  forall a b. (Showl a, Showl b) => [(a, b)] -> String -> String;
showsl_list_prod xs = default_showsl_list showsl_prod xs;

instance (Showl a, Showl b) => Showl (a, b) where {
  showsl = showsl_prod;
  showsl_list = showsl_list_prod;
};

data Sig = LessF | LeF | SumF Nat | ConstF Int | ProdF Nat | EqF;

equal_sig :: Sig -> Sig -> Bool;
equal_sig (ProdF x5) EqF = False;
equal_sig EqF (ProdF x5) = False;
equal_sig (ConstF x4) EqF = False;
equal_sig EqF (ConstF x4) = False;
equal_sig (ConstF x4) (ProdF x5) = False;
equal_sig (ProdF x5) (ConstF x4) = False;
equal_sig (SumF x3) EqF = False;
equal_sig EqF (SumF x3) = False;
equal_sig (SumF x3) (ProdF x5) = False;
equal_sig (ProdF x5) (SumF x3) = False;
equal_sig (SumF x3) (ConstF x4) = False;
equal_sig (ConstF x4) (SumF x3) = False;
equal_sig LeF EqF = False;
equal_sig EqF LeF = False;
equal_sig LeF (ProdF x5) = False;
equal_sig (ProdF x5) LeF = False;
equal_sig LeF (ConstF x4) = False;
equal_sig (ConstF x4) LeF = False;
equal_sig LeF (SumF x3) = False;
equal_sig (SumF x3) LeF = False;
equal_sig LessF EqF = False;
equal_sig EqF LessF = False;
equal_sig LessF (ProdF x5) = False;
equal_sig (ProdF x5) LessF = False;
equal_sig LessF (ConstF x4) = False;
equal_sig (ConstF x4) LessF = False;
equal_sig LessF (SumF x3) = False;
equal_sig (SumF x3) LessF = False;
equal_sig LessF LeF = False;
equal_sig LeF LessF = False;
equal_sig (ProdF x5) (ProdF y5) = equal_nat x5 y5;
equal_sig (ConstF x4) (ConstF y4) = equal_int x4 y4;
equal_sig (SumF x3) (SumF y3) = equal_nat x3 y3;
equal_sig EqF EqF = True;
equal_sig LeF LeF = True;
equal_sig LessF LessF = True;

data Ia4_sig = IA4_Base Sig | IA4_Div | IA4_Mod;

equal_ia4_sig :: Ia4_sig -> Ia4_sig -> Bool;
equal_ia4_sig IA4_Div IA4_Mod = False;
equal_ia4_sig IA4_Mod IA4_Div = False;
equal_ia4_sig (IA4_Base x1) IA4_Mod = False;
equal_ia4_sig IA4_Mod (IA4_Base x1) = False;
equal_ia4_sig (IA4_Base x1) IA4_Div = False;
equal_ia4_sig IA4_Div (IA4_Base x1) = False;
equal_ia4_sig (IA4_Base x1) (IA4_Base y1) = equal_sig x1 y1;
equal_ia4_sig IA4_Mod IA4_Mod = True;
equal_ia4_sig IA4_Div IA4_Div = True;

instance Eq Ia4_sig where {
  a == b = equal_ia4_sig a b;
};

showsl_sig :: Sig -> String -> String;
showsl_sig LessF = showsl_lit "<";
showsl_sig LeF = showsl_lit "<=";
showsl_sig EqF = showsl_lit "=";
showsl_sig (SumF n) = showsl_lit "+";
showsl_sig (ProdF n) = showsl_lit "*";
showsl_sig (ConstF n) = showsl_int n;

showsl_ia4_sig :: Ia4_sig -> String -> String;
showsl_ia4_sig (IA4_Base f) = showsl_sig f;
showsl_ia4_sig IA4_Div = showsl_lit "div";
showsl_ia4_sig IA4_Mod = showsl_lit "mod";

showsl_list_ia4_sig :: [Ia4_sig] -> String -> String;
showsl_list_ia4_sig xs = default_showsl_list showsl_ia4_sig xs;

instance Showl Ia4_sig where {
  showsl = showsl_ia4_sig;
  showsl_list = showsl_list_ia4_sig;
};

data Transition_rule a b c d =
  Transition d d (Formula (Term a (Trans_var b, c)));

equal_transition_rule ::
  forall a b c d.
    (Eq a, Eq b, Eq c,
      Eq d) => Transition_rule a b c d -> Transition_rule a b c d -> Bool;
equal_transition_rule (Transition x1 x2 x3) (Transition y1 y2 y3) =
  x1 == y1 && x2 == y2 && equal_formula x3 y3;

instance (Eq a, Eq b, Eq c, Eq d) => Eq (Transition_rule a b c d) where {
  a == b = equal_transition_rule a b;
};

data Sharp a = Flat a | Sharp a;

equal_sharp :: forall a. (Eq a) => Sharp a -> Sharp a -> Bool;
equal_sharp (Flat x1) (Sharp x2) = False;
equal_sharp (Sharp x2) (Flat x1) = False;
equal_sharp (Sharp x2) (Sharp y2) = x2 == y2;
equal_sharp (Flat x1) (Flat y1) = x1 == y1;

instance (Eq a) => Eq (Sharp a) where {
  a == b = equal_sharp a b;
};

comparator_sharp ::
  forall a. (a -> a -> Ordera) -> Sharp a -> Sharp a -> Ordera;
comparator_sharp comp_l (Flat x) (Flat y) = comp_l x y;
comparator_sharp comp_l (Flat x) (Sharp ya) = Lt;
comparator_sharp comp_l (Sharp x) (Flat y) = Gt;
comparator_sharp comp_l (Sharp x) (Sharp ya) = comp_l x ya;

compare_sharp :: forall a. (Compare a) => Sharp a -> Sharp a -> Ordera;
compare_sharp = comparator_sharp compare;

le_of_comp :: forall a. (a -> a -> Ordera) -> a -> a -> Bool;
le_of_comp acomp x y = (case acomp x y of {
                         Eqa -> True;
                         Lt -> True;
                         Gt -> False;
                       });

less_eq_sharp :: forall a. (Compare a) => Sharp a -> Sharp a -> Bool;
less_eq_sharp = le_of_comp compare_sharp;

lt_of_comp :: forall a. (a -> a -> Ordera) -> a -> a -> Bool;
lt_of_comp acomp x y = (case acomp x y of {
                         Eqa -> False;
                         Lt -> True;
                         Gt -> False;
                       });

less_sharp :: forall a. (Compare a) => Sharp a -> Sharp a -> Bool;
less_sharp = lt_of_comp compare_sharp;

instance (Compare a) => Ord (Sharp a) where {
  less_eq = less_eq_sharp;
  less = less_sharp;
};

instance (Compare a) => Compare (Sharp a) where {
  compare = compare_sharp;
};

instance (Compare a) => Quasi_order (Sharp a) where {
};

instance (Compare a) => Weak_order (Sharp a) where {
};

instance (Compare a) => Preorder (Sharp a) where {
};

instance (Compare a) => Order (Sharp a) where {
};

instance (Compare a) => Linorder (Sharp a) where {
};

showsl_sharp :: forall a. (Showl a) => Sharp a -> String -> String;
showsl_sharp (Flat s) = showsl s;
showsl_sharp (Sharp s) = showsl_lit "#" . showsl s;

showsl_list_sharp :: forall a. (Showl a) => [Sharp a] -> String -> String;
showsl_list_sharp xs = default_showsl_list showsl_sharp xs;

instance (Showl a) => Showl (Sharp a) where {
  showsl = showsl_sharp;
  showsl_list = showsl_list_sharp;
};

instance (Compare a) => Compare_order (Sharp a) where {
};

data La_solver_type = Simplex_Solver | BB_Solver;

default_la_solver_type :: La_solver_type;
default_la_solver_type = BB_Solver;

class Default a where {
  defaulta :: a;
};

instance Default La_solver_type where {
  defaulta = default_la_solver_type;
};

showsl_la_solver_type :: La_solver_type -> String -> String;
showsl_la_solver_type BB_Solver = showsl_lit "Branch-and-Bound";
showsl_la_solver_type Simplex_Solver = showsl_lit "Simplex";

showsl_list_la_solver_type :: [La_solver_type] -> String -> String;
showsl_list_la_solver_type xs = default_showsl_list showsl_la_solver_type xs;

instance Showl La_solver_type where {
  showsl = showsl_la_solver_type;
  showsl_list = showsl_list_la_solver_type;
};

data Ty = BoolT | IntT;

data Ia4_variable a = IA4_Old a | IA4_Quot (Term Ia4_sig (a, Ty))
  | IA4_Rem (Term Ia4_sig (a, Ty));

equal_ty :: Ty -> Ty -> Bool;
equal_ty BoolT IntT = False;
equal_ty IntT BoolT = False;
equal_ty IntT IntT = True;
equal_ty BoolT BoolT = True;

instance Eq Ty where {
  a == b = equal_ty a b;
};

equal_ia4_variable ::
  forall a. (Eq a) => Ia4_variable a -> Ia4_variable a -> Bool;
equal_ia4_variable (IA4_Quot x2) (IA4_Rem x3) = False;
equal_ia4_variable (IA4_Rem x3) (IA4_Quot x2) = False;
equal_ia4_variable (IA4_Old x1) (IA4_Rem x3) = False;
equal_ia4_variable (IA4_Rem x3) (IA4_Old x1) = False;
equal_ia4_variable (IA4_Old x1) (IA4_Quot x2) = False;
equal_ia4_variable (IA4_Quot x2) (IA4_Old x1) = False;
equal_ia4_variable (IA4_Rem x3) (IA4_Rem y3) = equal_term x3 y3;
equal_ia4_variable (IA4_Quot x2) (IA4_Quot y2) = equal_term x2 y2;
equal_ia4_variable (IA4_Old x1) (IA4_Old y1) = x1 == y1;

instance (Eq a) => Eq (Ia4_variable a) where {
  a == b = equal_ia4_variable a b;
};

comparator_prod ::
  forall a b.
    (a -> a -> Ordera) -> (b -> b -> Ordera) -> (a, b) -> (a, b) -> Ordera;
comparator_prod comp_a comp_b (x, xa) (y, ya) = (case comp_a x y of {
          Eqa -> comp_b xa ya;
          Lt -> Lt;
          Gt -> Gt;
        });

comparator_sig :: Sig -> Sig -> Ordera;
comparator_sig LessF LessF = Eqa;
comparator_sig LessF LeF = Lt;
comparator_sig LessF (SumF y) = Lt;
comparator_sig LessF (ConstF ya) = Lt;
comparator_sig LessF (ProdF yb) = Lt;
comparator_sig LessF EqF = Lt;
comparator_sig LeF LessF = Gt;
comparator_sig LeF LeF = Eqa;
comparator_sig LeF (SumF y) = Lt;
comparator_sig LeF (ConstF ya) = Lt;
comparator_sig LeF (ProdF yb) = Lt;
comparator_sig LeF EqF = Lt;
comparator_sig (SumF x) LessF = Gt;
comparator_sig (SumF x) LeF = Gt;
comparator_sig (SumF x) (SumF y) = comparator_of x y;
comparator_sig (SumF x) (ConstF ya) = Lt;
comparator_sig (SumF x) (ProdF yb) = Lt;
comparator_sig (SumF x) EqF = Lt;
comparator_sig (ConstF x) LessF = Gt;
comparator_sig (ConstF x) LeF = Gt;
comparator_sig (ConstF x) (SumF y) = Gt;
comparator_sig (ConstF x) (ConstF ya) = comparator_of x ya;
comparator_sig (ConstF x) (ProdF yb) = Lt;
comparator_sig (ConstF x) EqF = Lt;
comparator_sig (ProdF x) LessF = Gt;
comparator_sig (ProdF x) LeF = Gt;
comparator_sig (ProdF x) (SumF y) = Gt;
comparator_sig (ProdF x) (ConstF ya) = Gt;
comparator_sig (ProdF x) (ProdF yb) = comparator_of x yb;
comparator_sig (ProdF x) EqF = Lt;
comparator_sig EqF LessF = Gt;
comparator_sig EqF LeF = Gt;
comparator_sig EqF (SumF y) = Gt;
comparator_sig EqF (ConstF ya) = Gt;
comparator_sig EqF (ProdF yb) = Gt;
comparator_sig EqF EqF = Eqa;

comparator_ia4_sig :: Ia4_sig -> Ia4_sig -> Ordera;
comparator_ia4_sig (IA4_Base x) (IA4_Base y) = comparator_sig x y;
comparator_ia4_sig (IA4_Base x) IA4_Div = Lt;
comparator_ia4_sig (IA4_Base x) IA4_Mod = Lt;
comparator_ia4_sig IA4_Div (IA4_Base y) = Gt;
comparator_ia4_sig IA4_Div IA4_Div = Eqa;
comparator_ia4_sig IA4_Div IA4_Mod = Lt;
comparator_ia4_sig IA4_Mod (IA4_Base y) = Gt;
comparator_ia4_sig IA4_Mod IA4_Div = Gt;
comparator_ia4_sig IA4_Mod IA4_Mod = Eqa;

comparator_term ::
  forall a b.
    (a -> a -> Ordera) -> (b -> b -> Ordera) -> Term a b -> Term a b -> Ordera;
comparator_term comp_f comp_v (Var x) (Var y) = comp_v x y;
comparator_term comp_f comp_v (Var x) (Fun ya yb) = Lt;
comparator_term comp_f comp_v (Fun x xa) (Var y) = Gt;
comparator_term comp_f comp_v (Fun x xa) (Fun ya yb) =
  (case comp_f x ya of {
    Eqa -> comparator_list (comparator_term comp_f comp_v) xa yb;
    Lt -> Lt;
    Gt -> Gt;
  });

comparator_ty :: Ty -> Ty -> Ordera;
comparator_ty BoolT BoolT = Eqa;
comparator_ty BoolT IntT = Lt;
comparator_ty IntT BoolT = Gt;
comparator_ty IntT IntT = Eqa;

comparator_ia4_variable ::
  forall a. (a -> a -> Ordera) -> Ia4_variable a -> Ia4_variable a -> Ordera;
comparator_ia4_variable comp_v (IA4_Old x) (IA4_Old y) = comp_v x y;
comparator_ia4_variable comp_v (IA4_Old x) (IA4_Quot ya) = Lt;
comparator_ia4_variable comp_v (IA4_Old x) (IA4_Rem yb) = Lt;
comparator_ia4_variable comp_v (IA4_Quot x) (IA4_Old y) = Gt;
comparator_ia4_variable comp_v (IA4_Quot x) (IA4_Quot ya) =
  comparator_term comparator_ia4_sig (comparator_prod comp_v comparator_ty) x
    ya;
comparator_ia4_variable comp_v (IA4_Quot x) (IA4_Rem yb) = Lt;
comparator_ia4_variable comp_v (IA4_Rem x) (IA4_Old y) = Gt;
comparator_ia4_variable comp_v (IA4_Rem x) (IA4_Quot ya) = Gt;
comparator_ia4_variable comp_v (IA4_Rem x) (IA4_Rem yb) =
  comparator_term comparator_ia4_sig (comparator_prod comp_v comparator_ty) x
    yb;

compare_ia4_variable ::
  forall a. (Compare a) => Ia4_variable a -> Ia4_variable a -> Ordera;
compare_ia4_variable = comparator_ia4_variable compare;

less_eq_ia4_variable ::
  forall a. (Compare a) => Ia4_variable a -> Ia4_variable a -> Bool;
less_eq_ia4_variable = le_of_comp compare_ia4_variable;

less_ia4_variable ::
  forall a. (Compare a) => Ia4_variable a -> Ia4_variable a -> Bool;
less_ia4_variable = lt_of_comp compare_ia4_variable;

instance (Compare a) => Ord (Ia4_variable a) where {
  less_eq = less_eq_ia4_variable;
  less = less_ia4_variable;
};

instance (Compare a) => Compare (Ia4_variable a) where {
  compare = compare_ia4_variable;
};

instance (Compare a) => Quasi_order (Ia4_variable a) where {
};

instance (Compare a) => Weak_order (Ia4_variable a) where {
};

instance (Compare a) => Preorder (Ia4_variable a) where {
};

instance (Compare a) => Order (Ia4_variable a) where {
};

instance (Compare a) => Linorder (Ia4_variable a) where {
};

showsl_ty :: Ty -> String -> String;
showsl_ty BoolT = showsl_lit "Bool";
showsl_ty IntT = showsl_lit "Int";

showsl_list_ty :: [Ty] -> String -> String;
showsl_list_ty xs = default_showsl_list showsl_ty xs;

instance Showl Ty where {
  showsl = showsl_ty;
  showsl_list = showsl_list_ty;
};

showsl_ia4_variable ::
  forall a. (Showl a) => Ia4_variable a -> String -> String;
showsl_ia4_variable (IA4_Old x) = showsl x;
showsl_ia4_variable (IA4_Quot e) =
  (showsl_lit "quotient(" . showsl_terma e) . showsl_lit ")";
showsl_ia4_variable (IA4_Rem e) =
  (showsl_lit "remainder(" . showsl_terma e) . showsl_lit ")";

showsl_list_ia4_variable ::
  forall a. (Showl a) => [Ia4_variable a] -> String -> String;
showsl_list_ia4_variable xs = default_showsl_list showsl_ia4_variable xs;

instance (Showl a) => Showl (Ia4_variable a) where {
  showsl = showsl_ia4_variable;
  showsl_list = showsl_list_ia4_variable;
};

instance (Compare a) => Compare_order (Ia4_variable a) where {
};

rel_option :: forall a b. (a -> b -> Bool) -> Maybe a -> Maybe b -> Bool;
rel_option r Nothing (Just y2) = False;
rel_option r (Just y2) Nothing = False;
rel_option r Nothing Nothing = True;
rel_option r (Just x2) (Just y2) = r x2 y2;

newtype Fmap a b = Fmap_of_list [(a, b)];

map_of :: forall a b. (Eq a) => [(a, b)] -> a -> Maybe b;
map_of [] k = Nothing;
map_of ((l, v) : ps) k = (if l == k then Just v else map_of ps k);

fmlookup :: forall a b. (Eq a) => Fmap a b -> a -> Maybe b;
fmlookup (Fmap_of_list m) = map_of m;

data Set a = Set [a] | Coset [a];

newtype Fset a = Abs_fset (Set a);

fset_of_list :: forall a. [a] -> Fset a;
fset_of_list xa = Abs_fset (Set xa);

fset :: forall a. Fset a -> Set a;
fset (Abs_fset x) = x;

image :: forall a b. (a -> b) -> Set a -> Set b;
image f (Set xs) = Set (map f xs);

fimage :: forall b a. (b -> a) -> Fset b -> Fset a;
fimage xb xc = Abs_fset (image xb (fset xc));

fmdom :: forall a b. Fmap a b -> Fset a;
fmdom (Fmap_of_list m) = fimage fst (fset_of_list m);

ball :: forall a. Set a -> (a -> Bool) -> Bool;
ball (Set xs) p = all p xs;

fmrel ::
  forall a b c. (Eq c) => (a -> b -> Bool) -> Fmap c a -> Fmap c b -> Bool;
fmrel r m n =
  ball (fset (fmdom m)) (\ x -> rel_option r (fmlookup m x) (fmlookup n x)) &&
    ball (fset (fmdom n)) (\ x -> rel_option r (fmlookup m x) (fmlookup n x));

equal_fmap :: forall a b. (Eq a, Eq b) => Fmap a b -> Fmap a b -> Bool;
equal_fmap = fmrel (\ a b -> a == b);

newtype Linear_poly = LinearPoly (Fmap Nat Rat);

linear_poly_map :: Linear_poly -> Fmap Nat Rat;
linear_poly_map (LinearPoly x) = x;

equal_linear_poly :: Linear_poly -> Linear_poly -> Bool;
equal_linear_poly x y = equal_fmap (linear_poly_map x) (linear_poly_map y);

instance Eq Linear_poly where {
  a == b = equal_linear_poly a b;
};

instance Eq Sig where {
  a == b = equal_sig a b;
};

data Color = R | B;

data Rbta a b = Empty | Branch Color (Rbta a b) a b (Rbta a b);

newtype Rbt b a = RBT (Rbta b a);

data Xml = XML [Char] [([Char], [Char])] [Xml] | XML_text [Char];

data Xmldoc = XMLDOC [[Char]] Xml;

data Lts_impl a b c d e =
  Lts_Impl [d] [(e, Transition_rule a b c d)] [(d, Formula (Term a (b, c)))];

data Atom a = Leq Nat a | Geq Nat a;

data Sum a b = Inl a | Inr b;

data Le_rel = Leq_Rel | Lt_Rel;

newtype Mapping a b = Mapping (Rbt a b);

data State a b =
  State [(Nat, Linear_poly)] (Mapping Nat (a, b)) (Mapping Nat (a, b))
    (Mapping Nat b) Bool (Maybe [a]);

data Istate a =
  IState Nat [(Nat, Linear_poly)] [(a, Atom QDelta)] (Linear_poly -> Maybe Nat)
    [a];

data Xml_error a = TagMismatch [String] | Fatal a;

data Lts_ext a b c d e =
  Lts_ext (Set d) (Set (Transition_rule a b c d)) (d -> Formula (Term a (b, c)))
    e;

data Enat = Enat Nat | Infinity_enat;

data Tpoly a b = PVar a | PNum b | PSum [Tpoly a b] | PMult [Tpoly a b];

data Direction a b =
  Direction (b -> b -> Bool) (State a b -> Mapping Nat (a, b))
    (State a b -> Mapping Nat (a, b)) (State a b -> Nat -> Maybe b)
    (State a b -> Nat -> Maybe b) (State a b -> Nat -> a)
    (State a b -> Nat -> a)
    ((Mapping Nat (a, b) -> Mapping Nat (a, b)) -> State a b -> State a b)
    (Nat -> b -> Atom b) (Nat -> b -> Atom b) (Rat -> Rat -> Bool);

data Constraint = LT Linear_poly Rat | GT Linear_poly Rat | LEQ Linear_poly Rat
  | GEQ Linear_poly Rat | EQ Linear_poly Rat;

newtype Sum_bot a b = Sumbot (Sum a b);

data Le_constraint a = Le_Constraint Le_rel Linear_poly a;

data Linearity a = Non_Linear | Onea | Variable a;

newtype Proper_base = Abs_proper_base Int;

data Ns_constraint a = LEQ_ns Linear_poly a | GEQ_ns Linear_poly a;

data Ia4_nontermination_proof a =
  IA4_EquivalentState ([(a, Int)], [Char])
    [(([Char], Transition_rule Ia4_sig a Ty [Char]), ([(a, Int)], [Char]))]
    [(([Char], Transition_rule Ia4_sig a Ty [Char]), ([(a, Int)], [Char]))];

data Fresh_variable_addition_info a b c d =
  Fresh_Variable_Addition_Info b c [(d, Formula (Term a (Trans_var b, c)))];

data Transition_removal_info a b c d e =
  Transition_removal_info (Sharp c -> a) [d] b a (d -> e);

data Location_addition_info a b c d e =
  Location_Addition_Info d d e (Transition_rule a b c d);

data Art_edge_impl a b c = Cover_Edge a c | Children_Edge [(b, (a, c))];

data Art_node_impl a b c d e f g =
  Art_Node e (Formula (Term a (b, c))) d (Art_edge_impl e f g);

data Art_impl_ext a b c d e f g h =
  Art_impl_ext [e] [Art_node_impl a b c d e f g] h;

data Invariant_proof a b c d e f g =
  Impact [(d, Formula (Term a (b, c)))] (Art_impl_ext a b c d e f g ());

data Cooperation_proof a b c d e f = Trivial
  | Invariants_Update (Invariant_proof a b c (Sharp d) [Char] e f)
      (Cooperation_proof a b c d e f)
  | Location_Addition (Location_addition_info a b c (Sharp d) e)
      (Cooperation_proof a b c d e f)
  | Fresh_Variable_Addition (Fresh_variable_addition_info a b c e)
      (Cooperation_proof a b c d e f)
  | Transition_Removal (Transition_removal_info [Term a (b, c)] c d e f)
      (Cooperation_proof a b c d e f)
  | Scc_Decomp [([Sharp d], Cooperation_proof a b c d e f)]
  | Cut_Transition_Split [([e], Cooperation_proof a b c d e f)];

data Termination_proof a b c d e f = Triviala
  | Via_Cooperation
      [([(Sharp e, Transition_rule a b c (Sharp d))],
         Cooperation_proof a b c d (Sharp e) f)]
  | Invariants_Update_LTS (Invariant_proof a b c d [Char] e f)
      (Termination_proof a b c d e f);

data Its4_proof =
  ITS4_Termination
    (Termination_proof Ia4_sig [Char] Ty [Char] [Char] La_solver_type)
  | ITS4_Nontermination (Ia4_nontermination_proof [Char])
  | ITS4_Recurrent ([([Char], Int)], [Char])
      [(([Char], Transition_rule Ia4_sig [Char] Ty [Char]),
         ([([Char], Int)], [Char]))]
      (Formula (Term Ia4_sig ([Char], Ty)))
      ([Char], Transition_rule Ia4_sig [Char] Ty [Char])
      [(([Char], Ty), Term Ia4_sig ([Char], Ty))]
      [(([Char], Ty), Term Ia4_sig ([Char], Ty))]
  | ITS4_RecurrentCycle ([([Char], Int)], [Char])
      [(([Char], Transition_rule Ia4_sig [Char] Ty [Char]),
         ([([Char], Int)], [Char]))]
      (Formula (Term Ia4_sig ([Char], Ty)))
      [(([Char], Transition_rule Ia4_sig [Char] Ty [Char]),
         ([(([Char], Ty), Term Ia4_sig ([Char], Ty))],
           [(([Char], Ty), Term Ia4_sig ([Char], Ty))]))];

data Art_edge a b c d e = Cover e | Children [(Transition_rule a b c d, e)];

data Art_ext a b c d e f =
  Art_ext [e] [e] (e -> Art_edge a b c d e) (e -> d)
    (e -> Formula (Term a (b, c))) f;

data Val = Int Int | Boola Bool;

newtype Simplex_state a = Simplex_State
  ([Ns_constraint QDelta],
    ((Mapping a [(a, Atom QDelta)],
       (Mapping Nat QDelta -> Mapping Nat QDelta, [a])),
      State a QDelta));

data Poly_constraint a = Poly_Ge [(Monom a, Int)] | Poly_Eq [(Monom a, Int)];

data Hinter_ext a b c d e =
  Hinter_ext [c] (b -> [d]) (c -> a) (c -> Maybe [a]) e;

data Gen_g_impl_ext a b c d = Gen_g_impl_ext a b c d;

newtype Cut_transition_split_info a = Cut_Transition_Split_Info [[a]];

suc :: Nat -> Nat;
suc n = plus_nat n one_nat;

bex :: forall a. Set a -> (a -> Bool) -> Bool;
bex (Set xs) p = any p xs;

nth :: forall a. [a] -> Nat -> a;
nth (x : xs) n =
  (if equal_nat n zero_nat then x else nth xs (minus_nat n one_nat));

upt :: Nat -> Nat -> [Nat];
upt i j = (if less_nat i j then i : upt (suc i) j else []);

drop :: forall a. Nat -> [a] -> [a];
drop n [] = [];
drop n (x : xs) =
  (if equal_nat n zero_nat then x : xs else drop (minus_nat n one_nat) xs);

find :: forall a. (a -> Bool) -> [a] -> Maybe a;
find uu [] = Nothing;
find p (x : xs) = (if p x then Just x else find p xs);

fold :: forall a b. (a -> b -> b) -> [a] -> b -> b;
fold f [] s = s;
fold f (x : xs) s = fold f xs (f x s);

take :: forall a. Nat -> [a] -> [a];
take n [] = [];
take n (x : xs) =
  (if equal_nat n zero_nat then [] else x : take (minus_nat n one_nat) xs);

empty :: forall a b. (Linorder a) => Rbt a b;
empty = RBT Empty;

transitions_impl ::
  forall a b c d e. Lts_impl a b c d e -> [(e, Transition_rule a b c d)];
transitions_impl (Lts_Impl x1 x2 x3) = x2;

initiala :: forall a b c d e. Lts_impl a b c d e -> [d];
initiala (Lts_Impl x1 x2 x3) = x1;

assertion_impl ::
  forall a b c d e. Lts_impl a b c d e -> [(d, Formula (Term a (b, c)))];
assertion_impl (Lts_Impl x1 x2 x3) = x3;

rbt_lookup :: forall a b. (Compare_order a) => Rbta a b -> a -> Maybe b;
rbt_lookup Empty k = Nothing;
rbt_lookup (Branch uu l x y r) k = (case compare k x of {
                                     Eqa -> Just y;
                                     Lt -> rbt_lookup l k;
                                     Gt -> rbt_lookup r k;
                                   });

impl_of :: forall b a. (Linorder b) => Rbt b a -> Rbta b a;
impl_of (RBT x) = x;

lookup :: forall a b. (Compare_order a) => Rbt a b -> a -> Maybe b;
lookup x = rbt_lookup (impl_of x);

lookupa :: forall a b. (Compare_order a) => Mapping a b -> a -> Maybe b;
lookupa (Mapping t) = lookup t;

lookup_default :: forall a b. (Compare_order b) => a -> Mapping b a -> b -> a;
lookup_default d m k = (case lookupa m k of {
                         Nothing -> d;
                         Just v -> v;
                       });

balance :: forall a b. Rbta a b -> a -> b -> Rbta a b -> Rbta a b;
balance (Branch R a w x b) s t (Branch R c y z d) =
  Branch R (Branch B a w x b) s t (Branch B c y z d);
balance (Branch R (Branch R a w x b) s t c) y z Empty =
  Branch R (Branch B a w x b) s t (Branch B c y z Empty);
balance (Branch R (Branch R a w x b) s t c) y z (Branch B va vb vc vd) =
  Branch R (Branch B a w x b) s t (Branch B c y z (Branch B va vb vc vd));
balance (Branch R Empty w x (Branch R b s t c)) y z Empty =
  Branch R (Branch B Empty w x b) s t (Branch B c y z Empty);
balance (Branch R (Branch B va vb vc vd) w x (Branch R b s t c)) y z Empty =
  Branch R (Branch B (Branch B va vb vc vd) w x b) s t (Branch B c y z Empty);
balance (Branch R Empty w x (Branch R b s t c)) y z (Branch B va vb vc vd) =
  Branch R (Branch B Empty w x b) s t (Branch B c y z (Branch B va vb vc vd));
balance (Branch R (Branch B ve vf vg vh) w x (Branch R b s t c)) y z
  (Branch B va vb vc vd) =
  Branch R (Branch B (Branch B ve vf vg vh) w x b) s t
    (Branch B c y z (Branch B va vb vc vd));
balance Empty w x (Branch R b s t (Branch R c y z d)) =
  Branch R (Branch B Empty w x b) s t (Branch B c y z d);
balance (Branch B va vb vc vd) w x (Branch R b s t (Branch R c y z d)) =
  Branch R (Branch B (Branch B va vb vc vd) w x b) s t (Branch B c y z d);
balance Empty w x (Branch R (Branch R b s t c) y z Empty) =
  Branch R (Branch B Empty w x b) s t (Branch B c y z Empty);
balance Empty w x (Branch R (Branch R b s t c) y z (Branch B va vb vc vd)) =
  Branch R (Branch B Empty w x b) s t (Branch B c y z (Branch B va vb vc vd));
balance (Branch B va vb vc vd) w x (Branch R (Branch R b s t c) y z Empty) =
  Branch R (Branch B (Branch B va vb vc vd) w x b) s t (Branch B c y z Empty);
balance (Branch B va vb vc vd) w x
  (Branch R (Branch R b s t c) y z (Branch B ve vf vg vh)) =
  Branch R (Branch B (Branch B va vb vc vd) w x b) s t
    (Branch B c y z (Branch B ve vf vg vh));
balance Empty s t Empty = Branch B Empty s t Empty;
balance Empty s t (Branch B va vb vc vd) =
  Branch B Empty s t (Branch B va vb vc vd);
balance Empty s t (Branch v Empty vb vc Empty) =
  Branch B Empty s t (Branch v Empty vb vc Empty);
balance Empty s t (Branch v (Branch B ve vf vg vh) vb vc Empty) =
  Branch B Empty s t (Branch v (Branch B ve vf vg vh) vb vc Empty);
balance Empty s t (Branch v Empty vb vc (Branch B vf vg vh vi)) =
  Branch B Empty s t (Branch v Empty vb vc (Branch B vf vg vh vi));
balance Empty s t (Branch v (Branch B ve vj vk vl) vb vc (Branch B vf vg vh vi))
  = Branch B Empty s t
      (Branch v (Branch B ve vj vk vl) vb vc (Branch B vf vg vh vi));
balance (Branch B va vb vc vd) s t Empty =
  Branch B (Branch B va vb vc vd) s t Empty;
balance (Branch B va vb vc vd) s t (Branch B ve vf vg vh) =
  Branch B (Branch B va vb vc vd) s t (Branch B ve vf vg vh);
balance (Branch B va vb vc vd) s t (Branch v Empty vf vg Empty) =
  Branch B (Branch B va vb vc vd) s t (Branch v Empty vf vg Empty);
balance (Branch B va vb vc vd) s t (Branch v (Branch B vi vj vk vl) vf vg Empty)
  = Branch B (Branch B va vb vc vd) s t
      (Branch v (Branch B vi vj vk vl) vf vg Empty);
balance (Branch B va vb vc vd) s t (Branch v Empty vf vg (Branch B vj vk vl vm))
  = Branch B (Branch B va vb vc vd) s t
      (Branch v Empty vf vg (Branch B vj vk vl vm));
balance (Branch B va vb vc vd) s t
  (Branch v (Branch B vi vn vo vp) vf vg (Branch B vj vk vl vm)) =
  Branch B (Branch B va vb vc vd) s t
    (Branch v (Branch B vi vn vo vp) vf vg (Branch B vj vk vl vm));
balance (Branch v Empty vb vc Empty) s t Empty =
  Branch B (Branch v Empty vb vc Empty) s t Empty;
balance (Branch v Empty vb vc (Branch B ve vf vg vh)) s t Empty =
  Branch B (Branch v Empty vb vc (Branch B ve vf vg vh)) s t Empty;
balance (Branch v (Branch B vf vg vh vi) vb vc Empty) s t Empty =
  Branch B (Branch v (Branch B vf vg vh vi) vb vc Empty) s t Empty;
balance (Branch v (Branch B vf vg vh vi) vb vc (Branch B ve vj vk vl)) s t Empty
  = Branch B (Branch v (Branch B vf vg vh vi) vb vc (Branch B ve vj vk vl)) s t
      Empty;
balance (Branch v Empty vf vg Empty) s t (Branch B va vb vc vd) =
  Branch B (Branch v Empty vf vg Empty) s t (Branch B va vb vc vd);
balance (Branch v Empty vf vg (Branch B vi vj vk vl)) s t (Branch B va vb vc vd)
  = Branch B (Branch v Empty vf vg (Branch B vi vj vk vl)) s t
      (Branch B va vb vc vd);
balance (Branch v (Branch B vj vk vl vm) vf vg Empty) s t (Branch B va vb vc vd)
  = Branch B (Branch v (Branch B vj vk vl vm) vf vg Empty) s t
      (Branch B va vb vc vd);
balance (Branch v (Branch B vj vk vl vm) vf vg (Branch B vi vn vo vp)) s t
  (Branch B va vb vc vd) =
  Branch B (Branch v (Branch B vj vk vl vm) vf vg (Branch B vi vn vo vp)) s t
    (Branch B va vb vc vd);

rbt_ins ::
  forall a b.
    (Compare_order a) => (a -> b -> b -> b) -> a -> b -> Rbta a b -> Rbta a b;
rbt_ins f k v Empty = Branch R Empty k v Empty;
rbt_ins f k v (Branch B l x y r) = (case compare k x of {
                                     Eqa -> Branch B l x (f k y v) r;
                                     Lt -> balance (rbt_ins f k v l) x y r;
                                     Gt -> balance l x y (rbt_ins f k v r);
                                   });
rbt_ins f k v (Branch R l x y r) = (case compare k x of {
                                     Eqa -> Branch R l x (f k y v) r;
                                     Lt -> Branch R (rbt_ins f k v l) x y r;
                                     Gt -> Branch R l x y (rbt_ins f k v r);
                                   });

paint :: forall a b. Color -> Rbta a b -> Rbta a b;
paint c Empty = Empty;
paint c (Branch uu l k v r) = Branch c l k v r;

rbt_insert_with_key ::
  forall a b.
    (Compare_order a) => (a -> b -> b -> b) -> a -> b -> Rbta a b -> Rbta a b;
rbt_insert_with_key f k v t = paint B (rbt_ins f k v t);

rbt_insert :: forall a b. (Compare_order a) => a -> b -> Rbta a b -> Rbta a b;
rbt_insert = rbt_insert_with_key (\ _ _ nv -> nv);

insert :: forall a b. (Compare_order a) => a -> b -> Rbt a b -> Rbt a b;
insert xc xd xe = RBT (rbt_insert xc xd (impl_of xe));

updatea ::
  forall a b. (Compare_order a) => a -> b -> Mapping a b -> Mapping a b;
updatea k v (Mapping t) = Mapping (insert k v t);

emptya :: forall a b. (Linorder a) => Mapping a b;
emptya = Mapping empty;

foldr :: forall a b. (a -> b -> b) -> [a] -> b -> b;
foldr f [] = id;
foldr f (x : xs) = f x . foldr f xs;

of_alist :: forall a b. (Compare_order a) => [(a, b)] -> Mapping a b;
of_alist xs = foldr (\ (a, b) -> updatea a b) xs emptya;

map_of_default :: forall a b. (Compare_order b) => a -> [(b, a)] -> b -> a;
map_of_default d xs = lookup_default d (of_alist xs);

assertion_of ::
  forall a b c d e.
    (Compare_order d) => Lts_impl a b c d e -> d -> Formula (Term a (b, c));
assertion_of pi = map_of_default (Conjunction []) (assertion_impl pi);

lts_of ::
  forall a b c d e.
    (Compare_order d) => Lts_impl a b c d e -> Lts_ext a b c d ();
lts_of pi =
  Lts_ext (Set (initiala pi)) (image snd (Set (transitions_impl pi)))
    (assertion_of pi) ();

source :: forall a b c d. Transition_rule a b c d -> d;
source (Transition l uu uv) = l;

target :: forall a b c d. Transition_rule a b c d -> d;
target (Transition uu r uv) = r;

foldl :: forall a b. (a -> b -> a) -> a -> [b] -> a;
foldl f a [] = a;
foldl f a (x : xs) = foldl f (f a x) xs;

val :: QDelta -> Rat -> Rat;
val qd delta = plus_rat (qdfst qd) (times_rat delta (qdsnd qd));

balance_right :: forall a b. Rbta a b -> a -> b -> Rbta a b -> Rbta a b;
balance_right a k x (Branch R b s y c) = Branch R a k x (Branch B b s y c);
balance_right (Branch B a k x b) s y Empty =
  balance (Branch R a k x b) s y Empty;
balance_right (Branch B a k x b) s y (Branch B va vb vc vd) =
  balance (Branch R a k x b) s y (Branch B va vb vc vd);
balance_right (Branch R a k x (Branch B b s y c)) t z Empty =
  Branch R (balance (paint R a) k x b) s y (Branch B c t z Empty);
balance_right (Branch R a k x (Branch B b s y c)) t z (Branch B va vb vc vd) =
  Branch R (balance (paint R a) k x b) s y
    (Branch B c t z (Branch B va vb vc vd));
balance_right Empty k x Empty = Empty;
balance_right (Branch R va vb vc Empty) k x Empty = Empty;
balance_right (Branch R va vb vc (Branch R ve vf vg vh)) k x Empty = Empty;
balance_right Empty k x (Branch B va vb vc vd) = Empty;
balance_right (Branch R ve vf vg Empty) k x (Branch B va vb vc vd) = Empty;
balance_right (Branch R ve vf vg (Branch R vi vj vk vl)) k x
  (Branch B va vb vc vd) = Empty;

balance_left :: forall a b. Rbta a b -> a -> b -> Rbta a b -> Rbta a b;
balance_left (Branch R a k x b) s y c = Branch R (Branch B a k x b) s y c;
balance_left Empty k x (Branch B a s y b) =
  balance Empty k x (Branch R a s y b);
balance_left (Branch B va vb vc vd) k x (Branch B a s y b) =
  balance (Branch B va vb vc vd) k x (Branch R a s y b);
balance_left Empty k x (Branch R (Branch B a s y b) t z c) =
  Branch R (Branch B Empty k x a) s y (balance b t z (paint R c));
balance_left (Branch B va vb vc vd) k x (Branch R (Branch B a s y b) t z c) =
  Branch R (Branch B (Branch B va vb vc vd) k x a) s y
    (balance b t z (paint R c));
balance_left Empty k x Empty = Empty;
balance_left Empty k x (Branch R Empty vb vc vd) = Empty;
balance_left Empty k x (Branch R (Branch R ve vf vg vh) vb vc vd) = Empty;
balance_left (Branch B va vb vc vd) k x Empty = Empty;
balance_left (Branch B va vb vc vd) k x (Branch R Empty vf vg vh) = Empty;
balance_left (Branch B va vb vc vd) k x
  (Branch R (Branch R vi vj vk vl) vf vg vh) = Empty;

combine :: forall a b. Rbta a b -> Rbta a b -> Rbta a b;
combine Empty x = x;
combine (Branch v va vb vc vd) Empty = Branch v va vb vc vd;
combine (Branch R a k x b) (Branch R c s y d) =
  (case combine b c of {
    Empty -> Branch R a k x (Branch R Empty s y d);
    Branch R b2 t z c2 -> Branch R (Branch R a k x b2) t z (Branch R c2 s y d);
    Branch B b2 t z c2 -> Branch R a k x (Branch R (Branch B b2 t z c2) s y d);
  });
combine (Branch B a k x b) (Branch B c s y d) =
  (case combine b c of {
    Empty -> balance_left a k x (Branch B Empty s y d);
    Branch R b2 t z c2 -> Branch R (Branch B a k x b2) t z (Branch B c2 s y d);
    Branch B b2 t z c2 ->
      balance_left a k x (Branch B (Branch B b2 t z c2) s y d);
  });
combine (Branch B va vb vc vd) (Branch R b k x c) =
  Branch R (combine (Branch B va vb vc vd) b) k x c;
combine (Branch R a k x b) (Branch B va vb vc vd) =
  Branch R a k x (combine b (Branch B va vb vc vd));

rbt_del :: forall a b. (Compare_order a) => a -> Rbta a b -> Rbta a b;
rbt_del x Empty = Empty;
rbt_del x (Branch c a y s b) = (case compare x y of {
                                 Eqa -> combine a b;
                                 Lt -> rbt_del_from_left x a y s b;
                                 Gt -> rbt_del_from_right x a y s b;
                               });

rbt_del_from_left ::
  forall a b.
    (Compare_order a) => a -> Rbta a b -> a -> b -> Rbta a b -> Rbta a b;
rbt_del_from_left x (Branch B lt z v rt) y s b =
  balance_left (rbt_del x (Branch B lt z v rt)) y s b;
rbt_del_from_left x Empty y s b = Branch R (rbt_del x Empty) y s b;
rbt_del_from_left x (Branch R va vb vc vd) y s b =
  Branch R (rbt_del x (Branch R va vb vc vd)) y s b;

rbt_del_from_right ::
  forall a b.
    (Compare_order a) => a -> Rbta a b -> a -> b -> Rbta a b -> Rbta a b;
rbt_del_from_right x a y s (Branch B lt z v rt) =
  balance_right a y s (rbt_del x (Branch B lt z v rt));
rbt_del_from_right x a y s Empty = Branch R a y s (rbt_del x Empty);
rbt_del_from_right x a y s (Branch R va vb vc vd) =
  Branch R a y s (rbt_del x (Branch R va vb vc vd));

rbt_delete :: forall a b. (Compare_order a) => a -> Rbta a b -> Rbta a b;
rbt_delete k t = paint B (rbt_del k t);

delete :: forall a b. (Compare_order a) => a -> Rbt a b -> Rbt a b;
delete xb xc = RBT (rbt_delete xb (impl_of xc));

of_int :: Int -> Rat;
of_int a = Frct (a, one_int);

removeAll :: forall a. (Eq a) => a -> [a] -> [a];
removeAll x [] = [];
removeAll x (y : xs) = (if x == y then removeAll x xs else y : removeAll x xs);

membera :: forall a. (Eq a) => [a] -> a -> Bool;
membera [] y = False;
membera (x : xs) y = x == y || membera xs y;

insertb :: forall a. (Eq a) => a -> [a] -> [a];
insertb x xs = (if membera xs x then xs else x : xs);

inserta :: forall a. (Eq a) => a -> Set a -> Set a;
inserta x (Set xs) = Set (insertb x xs);
inserta x (Coset xs) = Coset (removeAll x xs);

member :: forall a. (Eq a) => a -> Set a -> Bool;
member x (Set xs) = membera xs x;
member x (Coset xs) = not (membera xs x);

bind2 ::
  forall a b c d.
    Sum_bot a b -> (a -> Sum_bot c d) -> (b -> Sum_bot c d) -> Sum_bot c d;
bind2 (Sumbot a) f g = (case a of {
                         Inl aa -> f aa;
                         Inr aa -> g aa;
                       });

update :: forall a b. (Eq a) => a -> b -> [(a, b)] -> [(a, b)];
update k v [] = [(k, v)];
update k v (p : ps) = (if fst p == k then (k, v) : ps else p : update k v ps);

merge :: forall a b. (Eq a) => [(a, b)] -> [(a, b)] -> [(a, b)];
merge qs ps = foldr (\ (a, b) -> update a b) ps qs;

fun_upd :: forall a b. (Eq a) => (a -> b) -> a -> b -> a -> b;
fun_upd f a b = (\ x -> (if x == a then b else f x));

bind :: forall a b. Maybe a -> (a -> Maybe b) -> Maybe b;
bind Nothing f = Nothing;
bind (Just x) f = f x;

lhs :: (Nat, Linear_poly) -> Nat;
lhs (l, r) = l;

rhs :: (Nat, Linear_poly) -> Linear_poly;
rhs (l, r) = r;

char_0x7A :: Char;
char_0x7A = Chr (122 :: Integer);

char_0x79 :: Char;
char_0x79 = Chr (121 :: Integer);

char_0x78 :: Char;
char_0x78 = Chr (120 :: Integer);

char_0x77 :: Char;
char_0x77 = Chr (119 :: Integer);

char_0x76 :: Char;
char_0x76 = Chr (118 :: Integer);

char_0x75 :: Char;
char_0x75 = Chr (117 :: Integer);

char_0x74 :: Char;
char_0x74 = Chr (116 :: Integer);

char_0x73 :: Char;
char_0x73 = Chr (115 :: Integer);

char_0x72 :: Char;
char_0x72 = Chr (114 :: Integer);

char_0x71 :: Char;
char_0x71 = Chr (113 :: Integer);

char_0x70 :: Char;
char_0x70 = Chr (112 :: Integer);

char_0x6F :: Char;
char_0x6F = Chr (111 :: Integer);

char_0x6E :: Char;
char_0x6E = Chr (110 :: Integer);

char_0x6D :: Char;
char_0x6D = Chr (109 :: Integer);

char_0x6C :: Char;
char_0x6C = Chr (108 :: Integer);

char_0x6B :: Char;
char_0x6B = Chr (107 :: Integer);

char_0x6A :: Char;
char_0x6A = Chr (106 :: Integer);

char_0x69 :: Char;
char_0x69 = Chr (105 :: Integer);

char_0x68 :: Char;
char_0x68 = Chr (104 :: Integer);

char_0x67 :: Char;
char_0x67 = Chr (103 :: Integer);

char_0x66 :: Char;
char_0x66 = Chr (102 :: Integer);

char_0x65 :: Char;
char_0x65 = Chr (101 :: Integer);

char_0x64 :: Char;
char_0x64 = Chr (100 :: Integer);

char_0x63 :: Char;
char_0x63 = Chr (99 :: Integer);

char_0x62 :: Char;
char_0x62 = Chr (98 :: Integer);

char_0x61 :: Char;
char_0x61 = Chr (97 :: Integer);

char_0x5F :: Char;
char_0x5F = Chr (95 :: Integer);

char_0x5A :: Char;
char_0x5A = Chr (90 :: Integer);

char_0x59 :: Char;
char_0x59 = Chr (89 :: Integer);

char_0x58 :: Char;
char_0x58 = Chr (88 :: Integer);

char_0x57 :: Char;
char_0x57 = Chr (87 :: Integer);

char_0x56 :: Char;
char_0x56 = Chr (86 :: Integer);

char_0x55 :: Char;
char_0x55 = Chr (85 :: Integer);

char_0x54 :: Char;
char_0x54 = Chr (84 :: Integer);

char_0x53 :: Char;
char_0x53 = Chr (83 :: Integer);

char_0x52 :: Char;
char_0x52 = Chr (82 :: Integer);

char_0x51 :: Char;
char_0x51 = Chr (81 :: Integer);

char_0x50 :: Char;
char_0x50 = Chr (80 :: Integer);

char_0x4F :: Char;
char_0x4F = Chr (79 :: Integer);

char_0x4E :: Char;
char_0x4E = Chr (78 :: Integer);

char_0x4D :: Char;
char_0x4D = Chr (77 :: Integer);

char_0x4C :: Char;
char_0x4C = Chr (76 :: Integer);

char_0x4B :: Char;
char_0x4B = Chr (75 :: Integer);

char_0x4A :: Char;
char_0x4A = Chr (74 :: Integer);

char_0x49 :: Char;
char_0x49 = Chr (73 :: Integer);

char_0x48 :: Char;
char_0x48 = Chr (72 :: Integer);

char_0x47 :: Char;
char_0x47 = Chr (71 :: Integer);

char_0x46 :: Char;
char_0x46 = Chr (70 :: Integer);

char_0x45 :: Char;
char_0x45 = Chr (69 :: Integer);

char_0x44 :: Char;
char_0x44 = Chr (68 :: Integer);

char_0x43 :: Char;
char_0x43 = Chr (67 :: Integer);

char_0x42 :: Char;
char_0x42 = Chr (66 :: Integer);

char_0x41 :: Char;
char_0x41 = Chr (65 :: Integer);

char_0x3B :: Char;
char_0x3B = Chr (59 :: Integer);

char_0x3A :: Char;
char_0x3A = Chr (58 :: Integer);

char_0x39 :: Char;
char_0x39 = Chr (57 :: Integer);

char_0x38 :: Char;
char_0x38 = Chr (56 :: Integer);

char_0x37 :: Char;
char_0x37 = Chr (55 :: Integer);

char_0x36 :: Char;
char_0x36 = Chr (54 :: Integer);

char_0x35 :: Char;
char_0x35 = Chr (53 :: Integer);

char_0x34 :: Char;
char_0x34 = Chr (52 :: Integer);

char_0x33 :: Char;
char_0x33 = Chr (51 :: Integer);

char_0x32 :: Char;
char_0x32 = Chr (50 :: Integer);

char_0x31 :: Char;
char_0x31 = Chr (49 :: Integer);

char_0x30 :: Char;
char_0x30 = Chr (48 :: Integer);

char_0x2D :: Char;
char_0x2D = Chr (45 :: Integer);

char_0x26 :: Char;
char_0x26 = Chr (38 :: Integer);

letters :: [Char];
letters =
  [char_0x61, char_0x62, char_0x63, char_0x64, char_0x65, char_0x66, char_0x67,
    char_0x68, char_0x69, char_0x6A, char_0x6B, char_0x6C, char_0x6D, char_0x6E,
    char_0x6F, char_0x70, char_0x71, char_0x72, char_0x73, char_0x74, char_0x75,
    char_0x76, char_0x77, char_0x78, char_0x79, char_0x7A, char_0x41, char_0x42,
    char_0x43, char_0x44, char_0x45, char_0x46, char_0x47, char_0x48, char_0x49,
    char_0x4A, char_0x4B, char_0x4C, char_0x4D, char_0x4E, char_0x4F, char_0x50,
    char_0x51, char_0x52, char_0x53, char_0x54, char_0x55, char_0x56, char_0x57,
    char_0x58, char_0x59, char_0x5A, char_0x5F, char_0x30, char_0x31, char_0x32,
    char_0x33, char_0x34, char_0x35, char_0x36, char_0x37, char_0x38, char_0x39,
    char_0x26, char_0x3B, char_0x3A, char_0x2D];

explode :: String -> [Char];
explode s = map char_of_integer (Str_Literal.asciisOfLiteral s);

left :: forall a b. a -> Sum_bot a b;
left x = Sumbot (Inl x);

xml_error ::
  forall a b c d.
    String -> ([Xml], (a, (b, (c, [String])))) -> Sum_bot (Xml_error String) d;
xml_error str x =
  (case x of {
    (xmls, (_, (_, (_, pos)))) ->
      let {
        next =
          (case xmls of {
            [] -> "tag close";
            XML tag _ _ : _ -> ("<" ++ implode tag) ++ ">";
            XML_text stra : _ -> ("text element \"" ++ implode stra) ++ "\"";
          });
      } in left (Fatal
                  ((((("parse error on " ++ next) ++ " at ") ++
                      default_showsl_list showsl_lit pos "") ++
                     ":\n") ++
                    str));
  });

mismatch ::
  forall a b.
    String ->
      ([Xml], (a, (Bool, ([String], [String])))) ->
        Sum_bot (Xml_error String) b;
mismatch tag x =
  (case x of {
    (_, (_, (True, (cands, _)))) -> left (TagMismatch (tag : cands));
    (_, (_, (False, (cands, _)))) ->
      xml_error
        ("expecting " ++ default_showsl_list showsl_lit (tag : cands) "") x;
  });

xml_do ::
  forall a.
    String ->
      (([Xml], ([([Char], [Char])], (Bool, ([String], [String])))) ->
        Sum_bot (Xml_error String) a) ->
        (Xml, ([([Char], [Char])], (Bool, ([String], [String])))) ->
          Sum_bot (Xml_error String) a;
xml_do tag p x =
  (case x of {
    (XML nam atts xmls, (_, (_, (_, pos)))) ->
      (if nam == explode tag then p (xmls, (atts, (False, ([], tag : pos))))
        else mismatch tag ([fst x], snd x));
    (XML_text _, _) -> mismatch tag ([fst x], snd x);
  });

right :: forall a b. a -> Sum_bot b a;
right x = Sumbot (Inr x);

xml_or ::
  forall a b c d e f g.
    ((a, (b, (Bool, (c, d)))) -> Sum_bot (Xml_error e) f) ->
      ((a, (b, (g, ([String], d)))) -> Sum_bot (Xml_error e) f) ->
        (a, (b, (g, (c, d)))) -> Sum_bot (Xml_error e) f;
xml_or p1 p2 x =
  (case x of {
    (x1, (atts, (flag, (cands, rest)))) ->
      bind2 (p1 (x1, (atts, (True, (cands, rest)))))
        (\ a ->
          (case a of {
            TagMismatch cands1 -> p2 (x1, (atts, (flag, (cands1, rest))));
            Fatal aa -> left (Fatal aa);
          }))
        right;
  });

foldli :: forall a b. [a] -> (b -> Bool) -> (a -> b -> b) -> b -> b;
foldli [] c f sigma = sigma;
foldli (x : xs) c f sigma =
  (if c sigma then foldli xs c f (f x sigma) else sigma);

extract :: forall a. (a -> Bool) -> [a] -> Maybe ([a], (a, [a]));
extract p [] = Nothing;
extract p (x : xs) =
  (if p x then Just ([], (x, xs))
    else (case extract p xs of {
           Nothing -> Nothing;
           Just (ys, (y, zs)) -> Just (x : ys, (y, zs));
         }));

hd :: forall a. [a] -> a;
hd (x21 : x22) = x21;

tl :: forall a. [a] -> [a];
tl [] = [];
tl (x21 : x22) = x22;

remdups :: forall a. (Eq a) => [a] -> [a];
remdups [] = [];
remdups (x : xs) = (if membera xs x then remdups xs else x : remdups xs);

remove1 :: forall a. (Eq a) => a -> [a] -> [a];
remove1 x [] = [];
remove1 x (y : xs) = (if x == y then xs else y : remove1 x xs);

rbt_bulkload :: forall a b. (Compare_order a) => [(a, b)] -> Rbta a b;
rbt_bulkload xs = foldr (\ (a, b) -> rbt_insert a b) xs Empty;

bulkload :: forall a b. (Compare_order a) => [(a, b)] -> Rbt a b;
bulkload xa = RBT (rbt_bulkload xa);

gelb :: forall a. (Eq a) => (a -> a -> Bool) -> a -> Maybe a -> Bool;
gelb lt c b = (case b of {
                Nothing -> True;
                Just ba -> lt ba c || ba == c;
              });

geub :: forall a. (Eq a) => (a -> a -> Bool) -> a -> Maybe a -> Bool;
geub lt c b = (case b of {
                Nothing -> False;
                Just ba -> lt ba c || ba == c;
              });

gtlb :: forall a b. (a -> b -> Bool) -> b -> Maybe a -> Bool;
gtlb lt c b = (case b of {
                Nothing -> True;
                Just ba -> lt ba c;
              });

leub :: forall a. (Eq a) => (a -> a -> Bool) -> a -> Maybe a -> Bool;
leub lt c b = (case b of {
                Nothing -> True;
                Just ba -> lt c ba || c == ba;
              });

ltlb :: forall a b. (a -> b -> Bool) -> a -> Maybe b -> Bool;
ltlb lt c b = (case b of {
                Nothing -> False;
                Just a -> lt c a;
              });

ltub :: forall a b. (a -> b -> Bool) -> a -> Maybe b -> Bool;
ltub lt c b = (case b of {
                Nothing -> True;
                Just a -> lt c a;
              });

poly :: forall a. Ns_constraint a -> Linear_poly;
poly (LEQ_ns p a) = p;
poly (GEQ_ns p a) = p;

nat_of_digit :: Char -> Maybe Nat;
nat_of_digit x =
  (if equal_char x char_0x30 then Just zero_nat
    else (if equal_char x char_0x31 then Just one_nat
           else (if equal_char x char_0x32
                  then Just (nat_of_integer (2 :: Integer))
                  else (if equal_char x char_0x33
                         then Just (nat_of_integer (3 :: Integer))
                         else (if equal_char x char_0x34
                                then Just (nat_of_integer (4 :: Integer))
                                else (if equal_char x char_0x35
                                       then Just (nat_of_integer (5 :: Integer))
                                       else (if equal_char x char_0x36
      then Just (nat_of_integer (6 :: Integer))
      else (if equal_char x char_0x37 then Just (nat_of_integer (7 :: Integer))
             else (if equal_char x char_0x38
                    then Just (nat_of_integer (8 :: Integer))
                    else (if equal_char x char_0x39
                           then Just (nat_of_integer (9 :: Integer))
                           else Nothing))))))))));

obind :: forall a b. Maybe a -> (a -> Maybe b) -> Maybe b;
obind opt f = (case opt of {
                Nothing -> Nothing;
                Just a -> f a;
              });

nat_of_string_aux :: Nat -> [Char] -> Maybe Nat;
nat_of_string_aux n [] = Just n;
nat_of_string_aux n (d : s) =
  obind (nat_of_digit d)
    (\ m ->
      nat_of_string_aux
        (plus_nat (times_nat (nat_of_integer (10 :: Integer)) n) m) s);

nat_of_string :: [Char] -> Sum String Nat;
nat_of_string s =
  (case (if null s then Nothing else nat_of_string_aux zero_nat s) of {
    Nothing -> Inl (("cannot convert \"" ++ implode s) ++ "\" to a number");
    Just a -> Inr a;
  });

int_of_nat :: Nat -> Int;
int_of_nat n = Int_of_integer (integer_of_nat n);

safe_head :: forall a. [a] -> Maybe a;
safe_head [] = Nothing;
safe_head (x : xs) = Just x;

sbind :: forall a b c. Sum a b -> (b -> Sum a c) -> Sum a c;
sbind su f = (case su of {
               Inl a -> Inl a;
               Inr a -> f a;
             });

int_of_string :: [Char] -> Sum String Int;
int_of_string s =
  (if safe_head s == Just char_0x2D
    then sbind (nat_of_string (tl s)) (\ n -> Inr (uminus_int (int_of_nat n)))
    else sbind (nat_of_string s) (\ n -> Inr (int_of_nat n)));

xml_take_int ::
  forall a.
    (Int ->
      ([Xml], ([([Char], [Char])], (Bool, ([String], [String])))) ->
        Sum_bot (Xml_error String) a) ->
      ([Xml], ([([Char], [Char])], (Bool, ([String], [String])))) ->
        Sum_bot (Xml_error String) a;
xml_take_int p xs =
  (case xs of {
    ([], _) -> xml_error "expecting an integer" xs;
    (XML _ _ _ : _, _) -> xml_error "expecting an integer" xs;
    (XML_text text : xmls, s) -> (case int_of_string text of {
                                   Inl x -> xml_error x xs;
                                   Inr n -> p n (xmls, s);
                                 });
  });

xml_return ::
  forall a.
    a -> ([Xml], ([([Char], [Char])], (Bool, ([String], [String])))) ->
           Sum_bot (Xml_error String) a;
xml_return v x = (case x of {
                   ([], _) -> right v;
                   (_ : _, _) -> xml_error "expecting tag close" x;
                 });

xml_int ::
  String ->
    (Xml, ([([Char], [Char])], (Bool, ([String], [String])))) ->
      Sum_bot (Xml_error String) Int;
xml_int tag = xml_do tag (xml_take_int xml_return);

distinct :: forall a. (Eq a) => [a] -> Bool;
distinct [] = True;
distinct (x : xs) = not (membera xs x) && distinct xs;

lvars :: [(Nat, Linear_poly)] -> Set Nat;
lvars t = Set (map lhs t);

constraint_to_qdelta_constraint :: Constraint -> [Ns_constraint QDelta];
constraint_to_qdelta_constraint (LT l r) =
  [LEQ_ns l (QDelta r (uminus_rat one_rat))];
constraint_to_qdelta_constraint (GT l r) = [GEQ_ns l (QDelta r one_rat)];
constraint_to_qdelta_constraint (LEQ l r) = [LEQ_ns l (QDelta r zero_rat)];
constraint_to_qdelta_constraint (GEQ l r) = [GEQ_ns l (QDelta r zero_rat)];
constraint_to_qdelta_constraint (EQ l r) =
  [LEQ_ns l (QDelta r zero_rat), GEQ_ns l (QDelta r zero_rat)];

i_constraint_to_qdelta_constraint ::
  forall a. (a, Constraint) -> [(a, Ns_constraint QDelta)];
i_constraint_to_qdelta_constraint (i, c) =
  map (\ a -> (i, a)) (constraint_to_qdelta_constraint c);

to_ns :: forall a. [(a, Constraint)] -> [(a, Ns_constraint QDelta)];
to_ns l = concatMap i_constraint_to_qdelta_constraint l;

is_letter :: Char -> Bool;
is_letter c =
  let {
    ci = integer_of_char c;
  } in (97 :: Integer) <= ci && ci <= (122 :: Integer) ||
         ((65 :: Integer) <= ci && ci <= (90 :: Integer) ||
           ((48 :: Integer) <= ci && ci <= (59 :: Integer) ||
             (ci == (95 :: Integer) ||
               (ci == (38 :: Integer) || ci == (45 :: Integer)))));

update_tokens :: forall a. ([a] -> [a]) -> [a] -> Sum [Char] ([a], [a]);
update_tokens f ts = Inr (ts, f ts);

char_0x3C :: Char;
char_0x3C = Chr (60 :: Integer);

char_0x21 :: Char;
char_0x21 = Chr (33 :: Integer);

comment_error :: () -> [Char];
comment_error x =
  (error :: forall a. String -> (() -> a) -> a) "comment not terminated"
    (\ _ -> []);

comment_error_hyphen :: () -> [Char];
comment_error_hyphen x =
  (error :: forall a. String -> (() -> a) -> a) "double hyphen within comment"
    (\ _ -> []);

rc_open_1 :: [Char] -> [Char];
rc_open_1 [] = [];
rc_open_1 (c : cs) =
  (if integer_of_char c == (60 :: Integer) then rc_open_2 cs
    else c : rc_open_1 cs);

rc_close_3 :: [Char] -> [Char];
rc_close_3 [] = comment_error ();
rc_close_3 (c : cs) =
  (if integer_of_char c == (62 :: Integer) then rc_open_1 cs
    else comment_error_hyphen ());

rc_close_2 :: [Char] -> [Char];
rc_close_2 [] = comment_error ();
rc_close_2 (c : cs) =
  (if integer_of_char c == (45 :: Integer) then rc_close_3 cs
    else rc_close_1 cs);

rc_close_1 :: [Char] -> [Char];
rc_close_1 [] = comment_error ();
rc_close_1 (c : cs) =
  (if integer_of_char c == (45 :: Integer) then rc_close_2 cs
    else rc_close_1 cs);

rc_open_4 :: [Char] -> [Char];
rc_open_4 [] = [char_0x3C, char_0x21, char_0x2D];
rc_open_4 (c : cs) =
  let {
    ic = integer_of_char c;
  } in (if ic == (45 :: Integer) then rc_close_1 cs
         else (if ic == (60 :: Integer)
                then c : char_0x21 : char_0x2D : rc_open_2 cs
                else char_0x3C : char_0x21 : char_0x2D : c : rc_open_1 cs));

rc_open_3 :: [Char] -> [Char];
rc_open_3 [] = [char_0x3C, char_0x21];
rc_open_3 (c : cs) =
  let {
    ic = integer_of_char c;
  } in (if ic == (45 :: Integer) then rc_open_4 cs
         else (if ic == (60 :: Integer) then c : char_0x21 : rc_open_2 cs
                else char_0x3C : char_0x21 : c : rc_open_1 cs));

rc_open_2 :: [Char] -> [Char];
rc_open_2 [] = [char_0x3C];
rc_open_2 (c : cs) =
  let {
    ic = integer_of_char c;
  } in (if ic == (33 :: Integer) then rc_open_3 cs
         else (if ic == (60 :: Integer) then c : rc_open_2 cs
                else char_0x3C : c : rc_open_1 cs));

remove_comments :: [Char] -> [Char];
remove_comments xs = rc_open_1 xs;

returna :: forall a b. a -> [b] -> Sum [Char] (a, [b]);
returna x = (\ ts -> Inr (x, ts));

binda :: forall a b c. Sum a b -> (b -> Sum a c) -> Sum a c;
binda m f = (case m of {
              Inl a -> Inl a;
              Inr a -> f a;
            });

bindb ::
  forall a b c.
    ([a] -> Sum [Char] (b, [a])) ->
      (b -> [a] -> Sum [Char] (c, [a])) -> [a] -> Sum [Char] (c, [a]);
bindb m f ts = binda (m ts) (\ (a, b) -> f a b);

char_0x3F :: Char;
char_0x3F = Chr (63 :: Integer);

char_0x3E :: Char;
char_0x3E = Chr (62 :: Integer);

shows_prec_list :: forall a. (Showa a) => Nat -> [a] -> [Char] -> [Char];
shows_prec_list p xs = shows_list xs;

length_tailrec :: forall a. [a] -> Nat -> Nat;
length_tailrec [] n = n;
length_tailrec (x : xs) n = length_tailrec xs (suc n);

size_list :: forall a. [a] -> Nat;
size_list xs = length_tailrec xs zero_nat;

char_0x20 :: Char;
char_0x20 = Chr (32 :: Integer);

char_0x27 :: Char;
char_0x27 = Chr (39 :: Integer);

shows_quote :: ([Char] -> [Char]) -> [Char] -> [Char];
shows_quote s =
  (shows_prec_char zero_nat char_0x27 . s) . shows_prec_char zero_nat char_0x27;

scan_upto :: [Char] -> [Char] -> Sum [Char] ([Char], [Char]);
scan_upto end (t : ts) =
  (if map snd (zip end (t : ts)) == end
    then Inr (end, drop (size_list end) (t : ts))
    else binda (scan_upto end ts) (\ (res, tsa) -> Inr (t : res, tsa)));
scan_upto end [] =
  Inl ([char_0x64, char_0x69, char_0x64, char_0x20, char_0x6E, char_0x6F,
         char_0x74, char_0x20, char_0x66, char_0x69, char_0x6E, char_0x64,
         char_0x20, char_0x65, char_0x6E, char_0x64, char_0x2D, char_0x6D,
         char_0x61, char_0x72, char_0x6B, char_0x65, char_0x72, char_0x20] ++
        shows_quote (shows_prec_list zero_nat end) []);

trim :: [Char] -> [Char];
trim =
  dropWhile
    (\ c ->
      let {
        ci = integer_of_char c;
      } in (if (34 :: Integer) <= ci then False
             else ci == (32 :: Integer) ||
                    (ci == (10 :: Integer) ||
                      (ci == (9 :: Integer) || ci == (13 :: Integer)))));

spaces :: [Char] -> Sum [Char] ((), [Char]);
spaces cs = Inr ((), trim cs);

parse_header :: [Char] -> Sum [Char] ([[Char]], [Char]);
parse_header ts =
  (if take (nat_of_integer (2 :: Integer)) (trim ts) == [char_0x3C, char_0x3F]
    then bindb (scan_upto [char_0x3F, char_0x3E])
           (\ h -> bindb parse_header (\ hs -> returna (h : hs))) ts
    else bindb spaces (\ _ -> returna []) ts);

char_0x2C :: Char;
char_0x2C = Chr (44 :: Integer);

err_expecting :: forall a b. (Showa a) => [Char] -> [a] -> Sum [Char] (b, [a]);
err_expecting msg ts =
  Inl ([char_0x65, char_0x78, char_0x70, char_0x65, char_0x63, char_0x74,
         char_0x69, char_0x6E, char_0x67, char_0x20] ++
        msg ++
          [char_0x2C, char_0x20, char_0x62, char_0x75, char_0x74, char_0x20,
            char_0x66, char_0x6F, char_0x75, char_0x6E, char_0x64, char_0x3A,
            char_0x20] ++
            shows_quote
              (shows_prec_list zero_nat
                (take (nat_of_integer (30 :: Integer)) ts))
              []);

eoi :: forall a. (Showa a) => [a] -> Sum [Char] ((), [a]);
eoi [] = Inr ((), []);
eoi (v : va) =
  err_expecting
    [char_0x65, char_0x6E, char_0x64, char_0x20, char_0x6F, char_0x66,
      char_0x20, char_0x69, char_0x6E, char_0x70, char_0x75, char_0x74]
    (v : va);

char_0x2F :: Char;
char_0x2F = Chr (47 :: Integer);

char_0x3D :: Char;
char_0x3D = Chr (61 :: Integer);

char_0x22 :: Char;
char_0x22 = Chr (34 :: Integer);

exactly_aux ::
  [Char] -> [Char] -> [Char] -> [Char] -> Sum [Char] ([Char], [Char]);
exactly_aux s i (x : xs) (y : ys) =
  (if equal_char x y then exactly_aux s i xs ys
    else err_expecting ([char_0x22] ++ s ++ [char_0x22]) i);
exactly_aux s i [] xs = Inr (s, trim xs);
exactly_aux s i (x : xs) [] = err_expecting ([char_0x22] ++ s ++ [char_0x22]) i;

exactly :: [Char] -> [Char] -> Sum [Char] ([Char], [Char]);
exactly s x = exactly_aux s x s x;

many :: (Char -> Bool) -> [Char] -> Sum [Char] ([Char], [Char]);
many p (t : ts) =
  (if p t then binda (many p ts) (\ (rs, tsa) -> Inr (t : rs, tsa))
    else Inr ([], t : ts));
many p [] = Inr ([], []);

parse_attribute_value :: [Char] -> Sum [Char] ([Char], [Char]);
parse_attribute_value =
  bindb (exactly [char_0x22])
    (\ _ ->
      bindb (many (\ y -> not (equal_char char_0x22 y)))
        (\ v -> bindb (exactly [char_0x22]) (\ _ -> returna v)));

many_letters_main :: [Char] -> ([Char], [Char]);
many_letters_main [] = ([], []);
many_letters_main (c : cs) =
  (if is_letter c then (case many_letters_main cs of {
                         (ds, a) -> (c : ds, a);
                       })
    else ([], c : cs));

parse_name :: [Char] -> Sum [Char] ([Char], [Char]);
parse_name s =
  (case many_letters_main s of {
    (n, ts) ->
      (if null n
        then Inl ([char_0x65, char_0x78, char_0x70, char_0x65, char_0x63,
                    char_0x74, char_0x65, char_0x64, char_0x20, char_0x6C,
                    char_0x65, char_0x74, char_0x74, char_0x65, char_0x72,
                    char_0x20] ++
                   letters ++
                     [char_0x20, char_0x62, char_0x75, char_0x74, char_0x20,
                       char_0x66, char_0x69, char_0x72, char_0x73, char_0x74,
                       char_0x20, char_0x73, char_0x79, char_0x6D, char_0x62,
                       char_0x6F, char_0x6C, char_0x20, char_0x69, char_0x73,
                       char_0x20, char_0x22] ++
                       take one_nat s ++ [char_0x22])
        else Inr (n, trim ts));
  });

parse_attributes :: [Char] -> Sum [Char] ([([Char], [Char])], [Char]);
parse_attributes [] = Inr ([], []);
parse_attributes (c : s) =
  let {
    ic = integer_of_char c;
  } in (if ic == (47 :: Integer) || ic == (62 :: Integer) then Inr ([], c : s)
         else bindb parse_name
                (\ k ->
                  bindb (exactly [char_0x3D])
                    (\ _ ->
                      bindb parse_attribute_value
                        (\ v ->
                          bindb parse_attributes
                            (\ atts -> returna ((k, v) : atts)))))
                (c : s));

char_0x5D :: Char;
char_0x5D = Chr (93 :: Integer);

char_0x5B :: Char;
char_0x5B = Chr (91 :: Integer);

oneof_closed :: [Char] -> Sum [Char] ([Char], [Char]);
oneof_closed (x : xs) =
  (if equal_char x char_0x3E then Inr ([char_0x3E], trim xs)
    else (if equal_char x char_0x2F && (case xs of {
 [] -> False;
 y : _ -> equal_char y char_0x3E;
                                       })
           then Inr ([char_0x2F, char_0x3E], trim (tl xs))
           else err_expecting
                  [char_0x6F, char_0x6E, char_0x65, char_0x20, char_0x6F,
                    char_0x66, char_0x20, char_0x5B, char_0x2F, char_0x3E,
                    char_0x2C, char_0x20, char_0x3E, char_0x5D]
                  (x : xs)));
oneof_closed [] =
  err_expecting
    [char_0x6F, char_0x6E, char_0x65, char_0x20, char_0x6F, char_0x66,
      char_0x20, char_0x5B, char_0x2F, char_0x3E, char_0x2C, char_0x20,
      char_0x3E, char_0x5D]
    [];

the :: forall a. Maybe a -> a;
the (Just x2) = x2;

parse_text_main :: [Char] -> [Char] -> ([Char], [Char]);
parse_text_main [] res = ([], reverse (trim res));
parse_text_main (c : cs) res =
  (if integer_of_char c == (60 :: Integer) then (c : cs, reverse (trim res))
    else parse_text_main cs (c : res));

parse_text_impl :: forall a. [Char] -> Sum a (Maybe [Char], [Char]);
parse_text_impl cs =
  (case parse_text_main (trim cs) [] of {
    (rem, txt) ->
      (if null txt then Inr (Nothing, rem) else Inr (Just txt, rem));
  });

parse_text :: [Char] -> Sum [Char] (Maybe [Char], [Char]);
parse_text cs = parse_text_impl cs;

parse_nodes :: [Char] -> Sum [Char] ([Xml], [Char]);
parse_nodes ts =
  (if null ts ||
        take (nat_of_integer (2 :: Integer)) ts == [char_0x3C, char_0x2F]
    then returna [] ts
    else (if not (equal_char (hd ts) char_0x3C)
           then bindb parse_text
                  (\ t ->
                    bindb parse_nodes (\ ns -> returna (XML_text (the t) : ns)))
                  ts
           else bindb (exactly [char_0x3C])
                  (\ _ ->
                    bindb parse_name
                      (\ n ->
                        bindb parse_attributes
                          (\ atts ->
                            bindb oneof_closed
                              (\ e ->
                                (if e == [char_0x2F, char_0x3E]
                                  then bindb parse_nodes
 (\ cs -> returna (XML n atts [] : cs))
                                  else bindb parse_nodes
 (\ cs ->
   bindb (exactly [char_0x3C, char_0x2F])
     (\ _ ->
       bindb (exactly n)
         (\ _ ->
           bindb (exactly [char_0x3E])
             (\ _ ->
               bindb parse_nodes (\ ns -> returna (XML n atts cs : ns)))))))))))
                  ts));

parse_node :: [Char] -> Sum [Char] (Xml, [Char]);
parse_node =
  bindb (exactly [char_0x3C])
    (\ _ ->
      bindb parse_name
        (\ n ->
          bindb parse_attributes
            (\ atts ->
              bindb oneof_closed
                (\ e ->
                  (if e == [char_0x2F, char_0x3E] then returna (XML n atts [])
                    else bindb parse_nodes
                           (\ cs ->
                             bindb (exactly [char_0x3C, char_0x2F])
                               (\ _ ->
                                 bindb (exactly n)
                                   (\ _ ->
                                     bindb (exactly [char_0x3E])
                                       (\ _ -> returna (XML n atts cs))))))))));

parse_doc :: [Char] -> Sum [Char] (Xmldoc, [Char]);
parse_doc =
  bindb (update_tokens remove_comments)
    (\ _ ->
      bindb parse_header
        (\ h ->
          bindb parse_node
            (\ xml -> bindb eoi (\ _ -> returna (XMLDOC h xml)))));

xml_take ::
  forall a b.
    ((Xml, ([([Char], [Char])], (Bool, ([String], [String])))) ->
      Sum_bot (Xml_error String) a) ->
      (a -> ([Xml], ([([Char], [Char])], (Bool, ([String], [String])))) ->
              Sum_bot (Xml_error String) b) ->
        ([Xml], ([([Char], [Char])], (Bool, ([String], [String])))) ->
          Sum_bot (Xml_error String) b;
xml_take p1 p2 x =
  (case x of {
    ([], rest) ->
      bind2 (p1 (XML [] [] [], rest)) left (\ _ -> left (Fatal "unexpected"));
    (xa : xs, (atts, (flag, (cands, rest)))) ->
      bind2 (p1 (xa, (atts, (flag, (cands, rest))))) left
        (\ a -> p2 a (xs, (atts, (False, ([], rest)))));
  });

xml_take_text ::
  forall a.
    ([Char] ->
      ([Xml], ([([Char], [Char])], (Bool, ([String], [String])))) ->
        Sum_bot (Xml_error String) a) ->
      ([Xml], ([([Char], [Char])], (Bool, ([String], [String])))) ->
        Sum_bot (Xml_error String) a;
xml_take_text p xs = (case xs of {
                       ([], _) -> xml_error "expecting a text" xs;
                       (XML _ _ _ : _, _) -> xml_error "expecting a text" xs;
                       (XML_text text : xmls, s) -> p text (xmls, s);
                     });

xml_text ::
  String ->
    (Xml, ([([Char], [Char])], (Bool, ([String], [String])))) ->
      Sum_bot (Xml_error String) [Char];
xml_text tag = xml_do tag (xml_take_text xml_return);

partition :: forall a. (a -> Bool) -> [a] -> ([a], [a]);
partition p [] = ([], []);
partition p (x : xs) =
  (case partition p xs of {
    (yes, no) -> (if p x then (x : yes, no) else (yes, x : no));
  });

replicate :: forall a. Nat -> a -> [a];
replicate n x =
  (if equal_nat n zero_nat then [] else x : replicate (minus_nat n one_nat) x);

deletea :: forall a b. (Compare_order a) => a -> Mapping a b -> Mapping a b;
deletea k (Mapping t) = Mapping (delete k t);

b_i_l :: forall a b. State a b -> Mapping Nat (a, b);
b_i_l (State x1 x2 x3 x4 x5 x6) = x2;

indexl :: forall a b. State a b -> Nat -> a;
indexl s = (fst . the) . lookupa (b_i_l s);

b_i_u :: forall a b. State a b -> Mapping Nat (a, b);
b_i_u (State x1 x2 x3 x4 x5 x6) = x3;

indexu :: forall a b. State a b -> Nat -> a;
indexu s = (fst . the) . lookupa (b_i_u s);

eval_term :: forall a b c. (a -> [b] -> b) -> Term a c -> (c -> b) -> b;
eval_term i (Var x) alpha = alpha x;
eval_term i (Fun f ss) alpha = i f (map (\ s -> eval_term i s alpha) ss);

xml_error_to_string :: Xml_error String -> [Char];
xml_error_to_string (Fatal e) = explode ("Fatal: " ++ e);
xml_error_to_string (TagMismatch e) =
  explode ("tag mismatch: " ++ default_showsl_list showsl_lit e "");

parse_xml ::
  forall a.
    ((Xml, ([([Char], [Char])], (Bool, ([String], [String])))) ->
      Sum_bot (Xml_error String) a) ->
      Xml -> Sum_bot [Char] a;
parse_xml p xml =
  bind2 (xml_take p xml_return ([xml], ([], (False, ([], [])))))
    (left . xml_error_to_string) right;

form_or :: forall a. Formula a -> Formula a -> Formula a;
form_or (Disjunction []) psi = psi;
form_or (Atom v) (Disjunction []) = Atom v;
form_or (NegAtom v) (Disjunction []) = NegAtom v;
form_or (Conjunction v) (Disjunction []) = Conjunction v;
form_or (Disjunction (va : vb)) (Disjunction []) = Disjunction (va : vb);
form_or (Disjunction (v : va)) (Disjunction (vb : vc)) =
  Disjunction ((v : va) ++ vb : vc);
form_or (Disjunction (v : va)) (Atom vb) = Disjunction ((v : va) ++ [Atom vb]);
form_or (Disjunction (v : va)) (NegAtom vb) =
  Disjunction ((v : va) ++ [NegAtom vb]);
form_or (Disjunction (v : va)) (Conjunction vb) =
  Disjunction ((v : va) ++ [Conjunction vb]);
form_or (Atom v) (Disjunction (va : vb)) = Disjunction (Atom v : va : vb);
form_or (NegAtom v) (Disjunction (va : vb)) = Disjunction (NegAtom v : va : vb);
form_or (Conjunction v) (Disjunction (va : vb)) =
  Disjunction (Conjunction v : va : vb);
form_or (Atom v) (Atom va) = Disjunction [Atom v, Atom va];
form_or (Atom v) (NegAtom va) = Disjunction [Atom v, NegAtom va];
form_or (Atom v) (Conjunction va) = Disjunction [Atom v, Conjunction va];
form_or (NegAtom v) (Atom va) = Disjunction [NegAtom v, Atom va];
form_or (NegAtom v) (NegAtom va) = Disjunction [NegAtom v, NegAtom va];
form_or (NegAtom v) (Conjunction va) = Disjunction [NegAtom v, Conjunction va];
form_or (Conjunction v) (Atom va) = Disjunction [Conjunction v, Atom va];
form_or (Conjunction v) (NegAtom va) = Disjunction [Conjunction v, NegAtom va];
form_or (Conjunction v) (Conjunction va) =
  Disjunction [Conjunction v, Conjunction va];

cnf_form_or :: forall a. Formula a -> Formula a -> Formula a;
cnf_form_or (Conjunction phi_s) (Conjunction psi_s) =
  Conjunction (concatMap (\ phi -> map (form_or phi) psi_s) phi_s);
cnf_form_or (Atom v) psi = form_or (Atom v) psi;
cnf_form_or (NegAtom v) psi = form_or (NegAtom v) psi;
cnf_form_or (Disjunction v) psi = form_or (Disjunction v) psi;
cnf_form_or phi (Atom v) = form_or phi (Atom v);
cnf_form_or phi (NegAtom v) = form_or phi (NegAtom v);
cnf_form_or phi (Disjunction v) = form_or phi (Disjunction v);

form_cnf_ex :: forall a. [Formula a] -> Formula a;
form_cnf_ex [] = Conjunction [Disjunction []];
form_cnf_ex (phi : phi_s) = cnf_form_or phi (form_cnf_ex phi_s);

form_and :: forall a. Formula a -> Formula a -> Formula a;
form_and (Conjunction []) psi = psi;
form_and (Atom v) (Conjunction []) = Atom v;
form_and (NegAtom v) (Conjunction []) = NegAtom v;
form_and (Conjunction (va : vb)) (Conjunction []) = Conjunction (va : vb);
form_and (Disjunction v) (Conjunction []) = Disjunction v;
form_and (Conjunction (v : va)) (Conjunction (vb : vc)) =
  Conjunction ((v : va) ++ vb : vc);
form_and (Conjunction (v : va)) (Atom vb) = Conjunction ((v : va) ++ [Atom vb]);
form_and (Conjunction (v : va)) (NegAtom vb) =
  Conjunction ((v : va) ++ [NegAtom vb]);
form_and (Conjunction (v : va)) (Disjunction vb) =
  Conjunction ((v : va) ++ [Disjunction vb]);
form_and (Atom v) (Conjunction (va : vb)) = Conjunction (Atom v : va : vb);
form_and (NegAtom v) (Conjunction (va : vb)) =
  Conjunction (NegAtom v : va : vb);
form_and (Disjunction v) (Conjunction (va : vb)) =
  Conjunction (Disjunction v : va : vb);
form_and (Atom v) (Atom va) = Conjunction [Atom v, Atom va];
form_and (Atom v) (NegAtom va) = Conjunction [Atom v, NegAtom va];
form_and (Atom v) (Disjunction va) = Conjunction [Atom v, Disjunction va];
form_and (NegAtom v) (Atom va) = Conjunction [NegAtom v, Atom va];
form_and (NegAtom v) (NegAtom va) = Conjunction [NegAtom v, NegAtom va];
form_and (NegAtom v) (Disjunction va) = Conjunction [NegAtom v, Disjunction va];
form_and (Disjunction v) (Atom va) = Conjunction [Disjunction v, Atom va];
form_and (Disjunction v) (NegAtom va) = Conjunction [Disjunction v, NegAtom va];
form_and (Disjunction v) (Disjunction va) =
  Conjunction [Disjunction v, Disjunction va];

form_all :: forall a. [Formula a] -> Formula a;
form_all [] = Conjunction [];
form_all (phi : phi_s) = form_and phi (form_all phi_s);

flatten :: forall a. Formula a -> Formula a;
flatten (Conjunction phi_s) = form_all (map flatten phi_s);
flatten (Disjunction phi_s) = form_cnf_ex (map flatten phi_s);
flatten (Atom v) = Conjunction [Disjunction [Atom v]];
flatten (NegAtom v) = Conjunction [Disjunction [NegAtom v]];

is_Atom :: forall a. Formula a -> Bool;
is_Atom (Atom uu) = True;
is_Atom (NegAtom v) = False;
is_Atom (Conjunction v) = False;
is_Atom (Disjunction v) = False;

initial :: forall a b c d e. Lts_ext a b c d e -> Set d;
initial (Lts_ext initial transition_rules assertion more) = initial;

untrans_var :: forall a. Trans_var a -> a;
untrans_var (Pre x) = x;
untrans_var (Post x) = x;
untrans_var (Intermediate x) = x;

map_filter :: forall a b. (a -> Maybe b) -> [a] -> [b];
map_filter f [] = [];
map_filter f (x : xs) = (case f x of {
                          Nothing -> map_filter f xs;
                          Just y -> y : map_filter f xs;
                        });

map_option :: forall a b. (a -> b) -> Maybe a -> Maybe b;
map_option f Nothing = Nothing;
map_option f (Just x2) = Just (f x2);

boundsl :: forall a b. State a b -> Nat -> Maybe b;
boundsl s = map_option snd . lookupa (b_i_l s);

boundsu :: forall a b. State a b -> Nat -> Maybe b;
boundsu s = map_option snd . lookupa (b_i_u s);

part :: forall a b. (Linorder b) => (a -> b) -> b -> [a] -> ([a], ([a], [a]));
part f pivot [] = ([], ([], []));
part f pivot (x : xs) =
  (case part f pivot xs of {
    (lts, (eqs, gts)) ->
      let {
        xa = f x;
      } in (if less xa pivot then (x : lts, (eqs, gts))
             else (if less pivot xa then (lts, (eqs, x : gts))
                    else (lts, (x : eqs, gts))));
  });

sort_key :: forall a b. (Linorder b) => (a -> b) -> [a] -> [a];
sort_key f xs =
  (case xs of {
    [] -> [];
    [_] -> xs;
    [x, y] -> (if less_eq (f x) (f y) then xs else [y, x]);
    _ : _ : _ : _ ->
      (case part f
              (f (nth xs
                   (divide_nat (size_list xs) (nat_of_integer (2 :: Integer)))))
              xs
        of {
        (lts, (eqs, gts)) -> sort_key f lts ++ eqs ++ sort_key f gts;
      });
  });

sorted_list_of_set :: forall a. (Eq a, Linorder a) => Set a -> [a];
sorted_list_of_set (Set xs) = sort_key (\ x -> x) (remdups xs);

ordered_keys :: forall a b. (Eq a, Linorder a) => Fmap a b -> [a];
ordered_keys m = sorted_list_of_set (fset (fmdom m));

vars_list :: Linear_poly -> [Nat];
vars_list lp = ordered_keys (linear_poly_map lp);

min :: forall a. (Ord a) => a -> a -> a;
min a b = (if less_eq a b then a else b);

sum_list :: forall a. (Monoid_add a) => [a] -> a;
sum_list xs = foldr plus xs zeroa;

valuate :: forall a. (Rational_vector a) => Linear_poly -> (Nat -> a) -> a;
valuate lp val =
  let {
    lpm = linear_poly_map lp;
  } in sum_list
         (map (\ x -> scaleRat (the (fmlookup lpm x)) (val x)) (vars_list lp));

delta_0 :: QDelta -> QDelta -> Rat;
delta_0 qd1 qd2 =
  let {
    c1 = qdfst qd1;
    c2 = qdfst qd2;
    k1 = qdsnd qd1;
    k2 = qdsnd qd2;
  } in (if less_rat c1 c2 && less_rat k2 k1
         then divide_rat (minus_rat c2 c1) (minus_rat k1 k2) else one_rat);

delta_0_val :: Ns_constraint QDelta -> (Nat -> QDelta) -> Rat;
delta_0_val (LEQ_ns lll rrr) vl = delta_0 (valuate lll vl) rrr;
delta_0_val (GEQ_ns lll rrr) vl = delta_0 rrr (valuate lll vl);

delta_0_val_min :: [Ns_constraint QDelta] -> (Nat -> QDelta) -> Rat;
delta_0_val_min [] vl = one_rat;
delta_0_val_min (h : t) vl = min (delta_0_val_min t vl) (delta_0_val h vl);

tabulate :: forall a b. (Compare_order a) => [a] -> (a -> b) -> Mapping a b;
tabulate ks f = Mapping (bulkload (map (\ k -> (k, f k)) ks));

map2fun :: forall a. (Zero a) => Mapping Nat a -> Nat -> a;
map2fun v = (\ x -> (case lookupa v x of {
                      Nothing -> zeroa;
                      Just y -> y;
                    }));

from_ns :: Mapping Nat QDelta -> [Ns_constraint QDelta] -> Mapping Nat Rat;
from_ns vl cs =
  let {
    delta = delta_0_val_min cs (map2fun vl);
  } in tabulate (remdups (concatMap vars_list (map poly cs)))
         (\ var -> val (map2fun vl var) delta);

uBI_upd ::
  forall a b.
    (Linorder b) => Direction a b ->
                      (Mapping Nat (a, b) -> Mapping Nat (a, b)) ->
                        State a b -> State a b;
uBI_upd (Direction x1 x2 x3 x4 x5 x6 x7 x8 x9 x10 x11) = x8;

update_B_I ::
  forall a b c d e.
    (Compare_order a) => ((Mapping a (b, c) -> Mapping a (b, c)) -> d -> e) ->
                           b -> a -> c -> d -> e;
update_B_I field_update i x c s = field_update (updatea x (i, c)) s;

lt :: forall a b. (Linorder b) => Direction a b -> b -> b -> Bool;
lt (Direction x1 x2 x3 x4 x5 x6 x7 x8 x9 x10 x11) = x1;

ub :: forall a b. (Linorder b) => Direction a b -> State a b -> Nat -> Maybe b;
ub (Direction x1 x2 x3 x4 x5 x6 x7 x8 x9 x10 x11) = x5;

li :: forall a b. (Linorder b) => Direction a b -> State a b -> Nat -> a;
li (Direction x1 x2 x3 x4 x5 x6 x7 x8 x9 x10 x11) = x6;

lb :: forall a b. (Linorder b) => Direction a b -> State a b -> Nat -> Maybe b;
lb (Direction x1 x2 x3 x4 x5 x6 x7 x8 x9 x10 x11) = x4;

v_update :: forall a b. Mapping Nat a -> State b a -> State b a;
v_update v (State t bil biu v_old u uc) = State t bil biu v u uc;

v :: forall a b. State a b -> Mapping Nat b;
v (State x1 x2 x3 x4 x5 x6) = x4;

t :: forall a b. State a b -> [(Nat, Linear_poly)];
t (State x1 x2 x3 x4 x5 x6) = x1;

get_var_coeff :: Fmap Nat Rat -> Nat -> Rat;
get_var_coeff lp v = (case fmlookup lp v of {
                       Nothing -> zero_rat;
                       Just c -> c;
                     });

coeff :: Linear_poly -> Nat -> Rat;
coeff lp = get_var_coeff (linear_poly_map lp);

rhs_eq_val ::
  forall a.
    (Minus a, Plus a, Zero a,
      ScaleRat a) => Mapping Nat a -> Nat -> a -> (Nat, Linear_poly) -> a;
rhs_eq_val v x_i c e =
  let {
    x_j = lhs e;
    a_i_j = coeff (rhs e) x_i;
  } in plus (map2fun v x_j) (scaleRat a_i_j (minus c (map2fun v x_i)));

update_code :: forall a b. (Lrv a) => Nat -> a -> State b a -> State b a;
update_code x c s =
  v_update
    (updatea x c
      (foldl (\ va e -> updatea (lhs e) (rhs_eq_val (v s) x c e) va) (v s)
        (t s)))
    s;

set_unsat :: forall a b. (Eq a) => [a] -> State a b -> State a b;
set_unsat i (State t bil biu v u uc) =
  State t bil biu v True (Just (remdups i));

assert_bound_codea ::
  forall a b.
    (Eq a, Eq b,
      Lrv b) => Direction a b -> a -> Nat -> b -> State a b -> State a b;
assert_bound_codea dir i x c s =
  (if geub (lt dir) c (ub dir s x) then s
    else let {
           sa = update_B_I (uBI_upd dir) i x c s;
         } in (if ltlb (lt dir) c (lb dir s x) then set_unsat [i, li dir s x] sa
                else (if not (member x (lvars (t sa))) &&
                           lt dir c (map2fun (v s) x)
                       then update_code x c sa else sa)));

b_i_u_update ::
  forall a b.
    (Mapping Nat (a, b) -> Mapping Nat (a, b)) -> State a b -> State a b;
b_i_u_update up (State t bil biu v u uc) = State t bil (up biu) v u uc;

positive :: forall a b. (Linorder b) => Direction a b;
positive =
  Direction less b_i_l b_i_u boundsl boundsu indexl indexu b_i_u_update Leq Geq
    less_eq_rat;

b_i_l_update ::
  forall a b.
    (Mapping Nat (a, b) -> Mapping Nat (a, b)) -> State a b -> State a b;
b_i_l_update up (State t bil biu v u uc) = State t (up bil) biu v u uc;

negative :: forall a b. (Linorder b) => Direction a b;
negative =
  Direction (\ x y -> less y x) b_i_u b_i_l boundsu boundsl indexu indexl
    b_i_l_update Geq Leq (\ x y -> less_eq_rat y x);

assert_bound_code ::
  forall a b. (Eq a, Eq b, Lrv b) => (a, Atom b) -> State a b -> State a b;
assert_bound_code (i, Leq x c) s = assert_bound_codea positive i x c s;
assert_bound_code (i, Geq x c) s = assert_bound_codea negative i x c s;

u :: forall a b. State a b -> Bool;
u (State x1 x2 x3 x4 x5 x6) = x5;

assert_bound_loop_code ::
  forall a b. (Eq a, Eq b, Lrv b) => [(a, Atom b)] -> State a b -> State a b;
assert_bound_loop_code ats s =
  foldl (\ sa a -> (if u sa then sa else assert_bound_code a sa)) s ats;

init_state :: forall a b. (Zero b) => [(Nat, Linear_poly)] -> State a b;
init_state t =
  State t emptya emptya
    (tabulate (remdups (map lhs t ++ concatMap (vars_list . rhs) t))
      (\ _ -> zeroa))
    False Nothing;

min_satisfying :: forall a. (Linorder a) => (a -> Bool) -> [a] -> Maybe a;
min_satisfying p l =
  let {
    xs = filter p l;
  } in (if null xs then Nothing else Just (foldl min (hd xs) (tl xs)));

le_ubound :: forall a. (Eq a, Linorder a) => a -> Maybe a -> Bool;
le_ubound c b = leub less c b;

ge_lbound :: forall a. (Eq a, Linorder a) => a -> Maybe a -> Bool;
ge_lbound c b = gelb less c b;

in_bounds ::
  forall a b.
    (Eq b, Linorder b) => a -> (a -> b) -> (a -> Maybe b, a -> Maybe b) -> Bool;
in_bounds x v (lb, ub) = ge_lbound (v x) (lb x) && le_ubound (v x) (ub x);

min_lvar_not_in_bounds ::
  forall a b. (Zero b, Eq b, Linorder b) => State a b -> Maybe Nat;
min_lvar_not_in_bounds s =
  min_satisfying
    (\ x -> not (in_bounds x (map2fun (v s)) (boundsl s, boundsu s)))
    (map lhs (t s));

fmmap :: forall a b c. (a -> b) -> Fmap c a -> Fmap c b;
fmmap f (Fmap_of_list m) = Fmap_of_list (map (apsnd f) m);

fmempty :: forall a b. Fmap a b;
fmempty = Fmap_of_list [];

scale :: Rat -> Fmap Nat Rat -> Fmap Nat Rat;
scale r lp = (if equal_rat r zero_rat then fmempty else fmmap (times_rat r) lp);

scaleRat_linear_poly :: Rat -> Linear_poly -> Linear_poly;
scaleRat_linear_poly r p = LinearPoly (scale r (linear_poly_map p));

uminus_linear_poly :: Linear_poly -> Linear_poly;
uminus_linear_poly lp = scaleRat_linear_poly (uminus_rat one_rat) lp;

fmfilter :: forall a b. (a -> Bool) -> Fmap a b -> Fmap a b;
fmfilter p (Fmap_of_list m) = Fmap_of_list (filter (\ (k, _) -> p k) m);

fmdrop :: forall a b. (Eq a) => a -> Fmap a b -> Fmap a b;
fmdrop a = fmfilter (\ aa -> not (aa == a));

fmadd :: forall a b. (Eq a) => Fmap a b -> Fmap a b -> Fmap a b;
fmadd (Fmap_of_list m) (Fmap_of_list n) = Fmap_of_list (merge m n);

fmupd :: forall a b. (Eq a) => a -> b -> Fmap a b -> Fmap a b;
fmupd k v m = fmadd m (Fmap_of_list [(k, v)]);

set_var_coeff :: Nat -> Rat -> Fmap Nat Rat -> Fmap Nat Rat;
set_var_coeff v c lp =
  (if equal_rat c zero_rat then fmdrop v lp else fmupd v c lp);

add_monom :: Rat -> Nat -> Fmap Nat Rat -> Fmap Nat Rat;
add_monom c v lp = set_var_coeff v (plus_rat c (get_var_coeff lp v)) lp;

add :: Fmap Nat Rat -> Fmap Nat Rat -> Fmap Nat Rat;
add lp1 lp2 =
  foldl (\ lp v -> add_monom (get_var_coeff lp1 v) v lp) lp2 (ordered_keys lp1);

plus_linear_poly :: Linear_poly -> Linear_poly -> Linear_poly;
plus_linear_poly p1 p2 =
  LinearPoly (add (linear_poly_map p1) (linear_poly_map p2));

minus_linear_poly :: Linear_poly -> Linear_poly -> Linear_poly;
minus_linear_poly lp1 lp2 = plus_linear_poly lp1 (uminus_linear_poly lp2);

var :: Nat -> Linear_poly;
var x = LinearPoly (set_var_coeff x one_rat fmempty);

subst_var :: Nat -> Linear_poly -> Linear_poly -> Linear_poly;
subst_var v lpa lp =
  minus_linear_poly
    (plus_linear_poly lp (scaleRat_linear_poly (coeff lp v) lpa))
    (scaleRat_linear_poly (coeff lp v) (var v));

subst_var_eq_code ::
  Nat -> Linear_poly -> (Nat, Linear_poly) -> (Nat, Linear_poly);
subst_var_eq_code v lp eq = (lhs eq, subst_var v lp (rhs eq));

eq_idx_for_lvar_aux :: [(Nat, Linear_poly)] -> Nat -> Nat -> Nat;
eq_idx_for_lvar_aux [] x i = i;
eq_idx_for_lvar_aux (eq : t) x i =
  (if equal_nat (lhs eq) x then i
    else eq_idx_for_lvar_aux t x (plus_nat i one_nat));

eq_idx_for_lvar :: [(Nat, Linear_poly)] -> Nat -> Nat;
eq_idx_for_lvar t x = eq_idx_for_lvar_aux t x zero_nat;

eq_for_lvar_code :: [(Nat, Linear_poly)] -> Nat -> (Nat, Linear_poly);
eq_for_lvar_code t v = nth t (eq_idx_for_lvar t v);

pivot_eq :: (Nat, Linear_poly) -> Nat -> (Nat, Linear_poly);
pivot_eq e y =
  let {
    cy = coeff (rhs e) y;
  } in (y, plus_linear_poly
             (scaleRat_linear_poly (divide_rat (uminus_rat one_rat) cy)
               (minus_linear_poly (rhs e) (scaleRat_linear_poly cy (var y))))
             (scaleRat_linear_poly (divide_rat one_rat cy) (var (lhs e))));

pivot_tableau_code ::
  Nat -> Nat -> [(Nat, Linear_poly)] -> [(Nat, Linear_poly)];
pivot_tableau_code x_i x_j t =
  let {
    eq = eq_for_lvar_code t x_i;
    eqa = pivot_eq eq x_j;
  } in map (\ e ->
             (if equal_nat (lhs e) (lhs eq) then eqa
               else subst_var_eq_code x_j (rhs eqa) e))
         t;

t_update :: forall a b. [(Nat, Linear_poly)] -> State a b -> State a b;
t_update t (State t_old bil biu v u uc) = State t bil biu v u uc;

pivot_code :: forall a b. (Lrv b) => Nat -> Nat -> State a b -> State a b;
pivot_code x_i x_j s = t_update (pivot_tableau_code x_i x_j (t s)) s;

pivot_and_update_code ::
  forall a b. (Lrv a) => Nat -> Nat -> a -> State b a -> State b a;
pivot_and_update_code x_i x_j c s = update_code x_i c (pivot_code x_i x_j s);

ui :: forall a b. (Linorder b) => Direction a b -> State a b -> Nat -> a;
ui (Direction x1 x2 x3 x4 x5 x6 x7 x8 x9 x10 x11) = x7;

unsat_indices ::
  forall a b.
    (Eq a,
      Linorder b) => Direction a b ->
                       State a b -> [Nat] -> (Nat, Linear_poly) -> [a];
unsat_indices dir s vs eq =
  let {
    r = rhs eq;
    lia = li dir s;
    uia = ui dir s;
  } in remdups
         (lia (lhs eq) :
           map (\ x -> (if less_rat (coeff r x) zero_rat then lia x else uia x))
             vs);

min_rvar_incdec_eq ::
  forall a b.
    (Eq a,
      Lrv b) => Direction a b -> State a b -> (Nat, Linear_poly) -> Sum [a] Nat;
min_rvar_incdec_eq dir s eq =
  let {
    rvars = vars_list (rhs eq);
  } in (case min_satisfying
               (\ x ->
                 less_rat zero_rat (coeff (rhs eq) x) &&
                   ltub (lt dir) (map2fun (v s) x) (ub dir s x) ||
                   less_rat (coeff (rhs eq) x) zero_rat &&
                     gtlb (lt dir) (map2fun (v s) x) (lb dir s x))
               rvars
         of {
         Nothing -> Inl (unsat_indices dir s rvars eq);
         Just a -> Inr a;
       });

check_codea ::
  forall a b. (Eq a, Lrv b) => Direction a b -> Nat -> State a b -> State a b;
check_codea dir x_i s =
  let {
    l_i = the (lb dir s x_i);
  } in (case min_rvar_incdec_eq dir s (eq_for_lvar_code (t s) x_i) of {
         Inl i -> set_unsat i s;
         Inr x_j -> pivot_and_update_code x_i x_j l_i s;
       });

lt_lbound :: forall a. (Linorder a) => a -> Maybe a -> Bool;
lt_lbound c b = ltlb less c b;

check_code :: forall a b. (Eq a, Eq b, Lrv b) => State a b -> State a b;
check_code s =
  (if u s then s
    else (case min_lvar_not_in_bounds s of {
           Nothing -> s;
           Just x_i ->
             let {
               dir = (if lt_lbound (map2fun (v s) x_i) (boundsl s x_i)
                       then positive else negative);
             } in check_code (check_codea dir x_i s);
         }));

assert_all_state_code ::
  forall a b.
    (Eq a, Eq b, Lrv b) => [(Nat, Linear_poly)] -> [(a, Atom b)] -> State a b;
assert_all_state_code t ats =
  check_code (assert_bound_loop_code ats (init_state t));

u_c :: forall a b. State a b -> Maybe [a];
u_c (State x1 x2 x3 x4 x5 x6) = x6;

assert_all_code ::
  forall a b.
    (Eq a, Eq b,
      Lrv b) => [(Nat, Linear_poly)] ->
                  [(a, Atom b)] -> Sum [a] (Mapping Nat b);
assert_all_code t asa = let {
                          s = assert_all_state_code t asa;
                        } in (if u s then Inl (the (u_c s)) else Inr (v s));

max_var :: Linear_poly -> Nat;
max_var lp = let {
               vl = vars_list lp;
             } in (if null vl then zero_nat else foldl max (hd vl) (tl vl));

normalize_ns_constraint ::
  forall a. (Lrv a) => Ns_constraint a -> Ns_constraint a;
normalize_ns_constraint (LEQ_ns l r) =
  let {
    v = max_var l;
    c = coeff l v;
  } in (if equal_rat c zero_rat then LEQ_ns l r
         else let {
                ic = inverse_rat c;
              } in (if less_rat c zero_rat
                     then GEQ_ns (scaleRat_linear_poly ic l) (scaleRat ic r)
                     else LEQ_ns (scaleRat_linear_poly ic l) (scaleRat ic r)));
normalize_ns_constraint (GEQ_ns l r) =
  let {
    v = max_var l;
    c = coeff l v;
  } in (if equal_rat c zero_rat then GEQ_ns l r
         else let {
                ic = inverse_rat c;
              } in (if less_rat c zero_rat
                     then LEQ_ns (scaleRat_linear_poly ic l) (scaleRat ic r)
                     else GEQ_ns (scaleRat_linear_poly ic l) (scaleRat ic r)));

pivot_tableau_eq ::
  [(Nat, Linear_poly)] ->
    (Nat, Linear_poly) ->
      [(Nat, Linear_poly)] ->
        Nat ->
          ([(Nat, Linear_poly)], ((Nat, Linear_poly), [(Nat, Linear_poly)]));
pivot_tableau_eq t1 eq t2 x = let {
                                eqa = pivot_eq eq x;
                                m = map (subst_var_eq_code x (rhs eqa));
                              } in (m t1, (eqa, m t2));

preprocess_opt ::
  forall a.
    (Lrv a) => Set Nat ->
                 [(Nat, Linear_poly)] ->
                   [(Nat, Linear_poly)] ->
                     ([(Nat, Linear_poly)], Mapping Nat a -> Mapping Nat a);
preprocess_opt x t1 [] = (t1, id);
preprocess_opt xa t1 ((x, p) : t2) =
  (if not (member x xa)
    then (case preprocess_opt xa t1 t2 of {
           (t, tv) -> (t, (\ v -> updatea x (valuate p (map2fun v)) v) . tv);
         })
    else (case find (\ xb -> not (member xb xa)) (vars_list p) of {
           Nothing -> preprocess_opt xa ((x, p) : t1) t2;
           Just y ->
             (case pivot_tableau_eq t1 (x, p) t2 y of {
               (tt1, ((z, q), tt2)) ->
                 (case preprocess_opt xa tt1 tt2 of {
                   (t, tv) ->
                     (t, (\ v -> updatea z (valuate q (map2fun v)) v) . tv);
                 });
             });
         }));

atom_var :: forall a. Atom a -> Nat;
atom_var (Leq var a) = var;
atom_var (Geq var a) = var;

preprocess_part_2 ::
  forall a b c.
    (Lrv c) => [(a, Atom b)] ->
                 [(Nat, Linear_poly)] ->
                   ([(Nat, Linear_poly)], Mapping Nat c -> Mapping Nat c);
preprocess_part_2 asa t =
  preprocess_opt (image atom_var (image snd (Set asa))) [] t;

start_fresh_variable :: forall a. [(a, Ns_constraint QDelta)] -> Nat;
start_fresh_variable [] = zero_nat;
start_fresh_variable ((i, h) : t) =
  max (plus_nat (max_var (poly h)) one_nat) (start_fresh_variable t);

unsatIndices :: forall a. Istate a -> [a];
unsatIndices (IState x1 x2 x3 x4 x5) = x5;

tableau :: forall a. Istate a -> [(Nat, Linear_poly)];
tableau (IState x1 x2 x3 x4 x5) = x2;

atoms :: forall a. Istate a -> [(a, Atom QDelta)];
atoms (IState x1 x2 x3 x4 x5) = x3;

zero :: Fmap Nat Rat;
zero = fmempty;

zero_linear_poly :: Linear_poly;
zero_linear_poly = LinearPoly zero;

qdelta_constraint_to_atom :: Ns_constraint QDelta -> Nat -> Atom QDelta;
qdelta_constraint_to_atom (LEQ_ns l r) v = Leq v r;
qdelta_constraint_to_atom (GEQ_ns l r) v = Geq v r;

firstFreshVariable :: forall a. Istate a -> Nat;
firstFreshVariable (IState x1 x2 x3 x4 x5) = x1;

is_monom :: Linear_poly -> Bool;
is_monom l = equal_nat (size_list (vars_list l)) one_nat;

poly_Mapping :: forall a. Istate a -> Linear_poly -> Maybe Nat;
poly_Mapping (IState x1 x2 x3 x4 x5) = x4;

linear_poly_to_eq :: Linear_poly -> Nat -> (Nat, Linear_poly);
linear_poly_to_eq p v = (v, p);

zero_satisfies :: forall a. (Lrv a) => Ns_constraint a -> Bool;
zero_satisfies (LEQ_ns l r) = less_eq zeroa r;
zero_satisfies (GEQ_ns l r) = less_eq r zeroa;

monom_var :: Linear_poly -> Nat;
monom_var l = max_var l;

monom_coeff :: Linear_poly -> Rat;
monom_coeff l = coeff l (monom_var l);

monom_to_atom :: Ns_constraint QDelta -> Atom QDelta;
monom_to_atom (LEQ_ns l r) =
  (if less_rat (monom_coeff l) zero_rat
    then Geq (monom_var l) (scaleRat_QDelta (inverse_rat (monom_coeff l)) r)
    else Leq (monom_var l) (scaleRat_QDelta (inverse_rat (monom_coeff l)) r));
monom_to_atom (GEQ_ns l r) =
  (if less_rat (monom_coeff l) zero_rat
    then Leq (monom_var l) (scaleRat_QDelta (inverse_rat (monom_coeff l)) r)
    else Geq (monom_var l) (scaleRat_QDelta (inverse_rat (monom_coeff l)) r));

preprocessa :: forall a. [(a, Ns_constraint QDelta)] -> Nat -> Istate a;
preprocessa [] v = IState v [] [] (\ _ -> Nothing) [];
preprocessa ((i, h) : t) v =
  let {
    s = preprocessa t v;
    p = poly h;
    is_monom_h = is_monom p;
    va = firstFreshVariable s;
    ta = tableau s;
    a = atoms s;
    m = poly_Mapping s;
    u = unsatIndices s;
  } in (if is_monom_h then IState va ta ((i, monom_to_atom h) : a) m u
         else (if equal_linear_poly p zero_linear_poly
                then (if zero_satisfies h then s else IState va ta a m (i : u))
                else (case m p of {
                       Nothing ->
                         IState (plus_nat va one_nat)
                           (linear_poly_to_eq p va : ta)
                           ((i, qdelta_constraint_to_atom h va) : a)
                           (fun_upd m p (Just va)) u;
                       Just vaa ->
                         IState va ta ((i, qdelta_constraint_to_atom h vaa) : a)
                           m u;
                     })));

preprocess_part_1 ::
  forall a.
    [(a, Ns_constraint QDelta)] ->
      ([(Nat, Linear_poly)], ([(a, Atom QDelta)], [a]));
preprocess_part_1 l = let {
                        start = start_fresh_variable l;
                        is = preprocessa l start;
                      } in (tableau is, (atoms is, unsatIndices is));

map_prod :: forall a b c d. (a -> b) -> (c -> d) -> (a, c) -> (b, d);
map_prod f g (a, b) = (f a, g b);

preprocess ::
  forall a.
    [(a, Ns_constraint QDelta)] ->
      ([(Nat, Linear_poly)],
        ([(a, Atom QDelta)], (Mapping Nat QDelta -> Mapping Nat QDelta, [a])));
preprocess l =
  (case preprocess_part_1 (map (map_prod id normalize_ns_constraint) l) of {
    (t, (asa, ui)) -> (case preprocess_part_2 asa t of {
                        (ta, tv) -> (ta, (asa, (tv, ui)));
                      });
  });

solve_exec_ns_code ::
  forall a.
    (Eq a) => [(a, Ns_constraint QDelta)] -> Sum [a] (Mapping Nat QDelta);
solve_exec_ns_code s =
  (case preprocess s of {
    (t, (asa, (trans_v, []))) -> (case assert_all_code t asa of {
                                   Inl a -> Inl a;
                                   Inr v -> Inr (trans_v v);
                                 });
    (_, (_, (_, i : _))) -> Inl [i];
  });

solve_exec_code ::
  forall a. (Eq a) => [(a, Constraint)] -> Sum [a] (Mapping Nat Rat);
solve_exec_code cs = let {
                       csa = to_ns cs;
                     } in (case solve_exec_ns_code csa of {
                            Inl a -> Inl a;
                            Inr v -> Inr (from_ns v (map snd csa));
                          });

simplex_index ::
  forall a. (Eq a) => [(a, Constraint)] -> Sum [a] (Mapping Nat Rat);
simplex_index = solve_exec_code;

simplex :: [Constraint] -> Sum [Nat] (Mapping Nat Rat);
simplex cs = simplex_index (zip (upt zero_nat (size_list cs)) cs);

xml_change ::
  forall a b.
    ((Xml, ([([Char], [Char])], (Bool, ([String], [String])))) ->
      Sum_bot (Xml_error String) a) ->
      (a -> ([Xml], ([([Char], [Char])], (Bool, ([String], [String])))) ->
              Sum_bot (Xml_error String) b) ->
        (Xml, ([([Char], [Char])], (Bool, ([String], [String])))) ->
          Sum_bot (Xml_error String) b;
xml_change p f x = bind2 (p x) left (\ a -> (case x of {
      (_, rest) -> f a ([], rest);
    }));

isOK :: forall a b. Sum a b -> Bool;
isOK m = (case m of {
           Inl _ -> False;
           Inr _ -> True;
         });

form_not :: forall a. Formula a -> Formula a;
form_not (Atom a) = NegAtom a;
form_not (NegAtom a) = Atom a;
form_not (Conjunction phi_s) = Disjunction (map form_not phi_s);
form_not (Disjunction phi_s) = Conjunction (map form_not phi_s);

get_Atom :: forall a. Formula a -> a;
get_Atom (Atom a) = a;
get_Atom (NegAtom a) = a;

gen_pick ::
  forall a b c d e f.
    (a -> (Maybe b -> Bool) -> (c -> d -> Maybe c) -> Maybe e -> Maybe f) ->
      a -> f;
gen_pick it s =
  the (it s (\ a -> (case a of {
                      Nothing -> True;
                      Just _ -> False;
                    }))
         (\ x _ -> Just x)
        Nothing);

list_update :: forall a. [a] -> Nat -> a -> [a];
list_update [] i y = [];
list_update (x : xs) i y =
  (if equal_nat i zero_nat then y : xs
    else x : list_update xs (minus_nat i one_nat) y);

is_Var :: forall a b. Term a b -> Bool;
is_Var (Var x1) = True;
is_Var (Fun x21 x22) = False;

char_0x23 :: Char;
char_0x23 = Chr (35 :: Integer);

special_map :: [Char] -> Maybe [Char];
special_map =
  map_of
    [([char_0x71, char_0x75, char_0x6F, char_0x74], [char_0x22]),
      ([char_0x23, char_0x33, char_0x34], [char_0x22]),
      ([char_0x61, char_0x6D, char_0x70], [char_0x26]),
      ([char_0x23, char_0x33, char_0x38], [char_0x26]),
      ([char_0x61, char_0x70, char_0x6F, char_0x73], [char_0x27]),
      ([char_0x23, char_0x33, char_0x39], [char_0x27]),
      ([char_0x6C, char_0x74], [char_0x3C]),
      ([char_0x23, char_0x36, char_0x30], [char_0x3C]),
      ([char_0x67, char_0x74], [char_0x3E]),
      ([char_0x23, char_0x36, char_0x32], [char_0x3E])];

check :: forall a. Bool -> a -> Sum a ();
check b e = (if b then Inr () else Inl e);

assertion ::
  forall a b c d e. Lts_ext a b c d e -> d -> Formula (Term a (b, c));
assertion (Lts_ext initial transition_rules assertion more) = assertion;

map_of_total ::
  forall a b.
    (Compare_order a) => (a -> String -> String) -> [(a, b)] -> a -> b;
map_of_total err xys =
  let {
    m = of_alist xys;
  } in (\ x ->
         (case lookupa m x of {
           Nothing ->
             (error :: forall a. String -> (() -> a) -> a) (err x "")
               (\ _ -> the Nothing);
           Just y -> y;
         }));

transition_of ::
  forall a b c d e.
    (Compare_order e,
      Showl e) => Lts_impl a b c d e -> e -> Transition_rule a b c d;
transition_of pi =
  map_of_total
    (\ a ->
      ((showsl_lit "access to non-existing transition " . showsl a) .
        showsl_lit "\navailable transitions:\n") .
        showsl_list (map fst (transitions_impl pi)))
    (transitions_impl pi);

rep_proper_base :: Proper_base -> Int;
rep_proper_base (Abs_proper_base x) = x;

get_base :: Proper_base -> Int;
get_base x = rep_proper_base x;

square_base :: Proper_base -> Proper_base;
square_base xa =
  Abs_proper_base (times_int (rep_proper_base xa) (rep_proper_base xa));

log_main :: Proper_base -> Int -> (Nat, Int);
log_main b x =
  (if less_int x (get_base b) then (zero_nat, one_int)
    else (case log_main (square_base b) x of {
           (z, bz) -> let {
                        l = times_nat (nat_of_integer (2 :: Integer)) z;
                        bz1 = times_int bz (get_base b);
                      } in (if less_int x bz1 then (l, bz) else (suc l, bz1));
         }));

doc_of_string :: [Char] -> Sum [Char] Xmldoc;
doc_of_string s = binda (parse_doc s) (\ (doc, _) -> Inr doc);

map_xml_text :: ([Char] -> [Char]) -> Xml -> Xml;
map_xml_text f (XML t asa cs) = XML t asa (map (map_xml_text f) cs);
map_xml_text f (XML_text txt) = XML_text (f txt);

nodes_lts_impl :: forall a b c d e. (Eq d) => Lts_impl a b c d e -> [d];
nodes_lts_impl pi =
  remdups
    (map (source . snd) (transitions_impl pi) ++
      map (target . snd) (transitions_impl pi));

into_base :: Int -> Proper_base;
into_base xa =
  Abs_proper_base
    (if less_eq_int (Int_of_integer (2 :: Integer)) xa then xa
      else Int_of_integer (2 :: Integer));

map_term :: forall a b c d. (a -> b) -> (c -> d) -> Term a c -> Term b d;
map_term f1 f2 (Var x1) = Var (f2 x1);
map_term f1 f2 (Fun x21 x22) = Fun (f1 x21) (map (map_term f1 f2) x22);

catch_error :: forall a b c. Sum a b -> (a -> Sum c b) -> Sum c b;
catch_error m f = (case m of {
                    Inl a -> f a;
                    Inr a -> Inr a;
                  });

forallM :: forall a b. (a -> Sum b ()) -> [a] -> Sum (a, b) ();
forallM f [] = Inr ();
forallM f (x : xs) =
  binda (catch_error (f x) (\ xa -> Inl (x, xa))) (\ _ -> forallM f xs);

trans_id ::
  forall a.
    (String ->
      (Xml, ([([Char], [Char])], (Bool, ([String], [String])))) ->
        Sum_bot (Xml_error String) a) ->
      (Xml, ([([Char], [Char])], (Bool, ([String], [String])))) ->
        Sum_bot (Xml_error String) a;
trans_id trans_id_parser = trans_id_parser "transitionId";

one_monom :: forall a. (Linorder a) => Monom a;
one_monom = Abs_monom [];

zero_poly :: forall a b. [(Monom a, b)];
zero_poly = [];

var_monom :: forall a. (Linorder a) => a -> Monom a;
var_monom xa = Abs_monom [(xa, one_nat)];

monom_mult_list ::
  forall a. (Eq a, Linorder a) => [(a, Nat)] -> [(a, Nat)] -> [(a, Nat)];
monom_mult_list [] n = n;
monom_mult_list ((x, p) : m) n =
  (case n of {
    [] -> (x, p) : m;
    (y, q) : na ->
      (if x == y then (x, plus_nat p q) : monom_mult_list m na
        else (if less x y then (x, p) : monom_mult_list m n
               else (y, q) : monom_mult_list ((x, p) : m) na));
  });

times_monom :: forall a. (Eq a, Linorder a) => Monom a -> Monom a -> Monom a;
times_monom xb xc = Abs_monom (monom_mult_list (rep_monom xb) (rep_monom xc));

monom_mult_poly ::
  forall a b.
    (Eq a, Linorder a, Eq b,
      Semiring_0 b) => (Monom a, b) -> [(Monom a, b)] -> [(Monom a, b)];
monom_mult_poly uu [] = [];
monom_mult_poly (ma, c) ((m, d) : p) =
  (if times c d == zeroa then monom_mult_poly (ma, c) p
    else (times_monom ma m, times c d) : monom_mult_poly (ma, c) p);

poly_add ::
  forall a b.
    (Eq a, Linorder a, Eq b,
      Semiring_0 b) => [(Monom a, b)] -> [(Monom a, b)] -> [(Monom a, b)];
poly_add [] q = q;
poly_add ((m, c) : p) q =
  (case extract (\ mc -> fst mc == m) q of {
    Nothing -> (m, c) : poly_add p q;
    Just (q1, ((_, d), q2)) ->
      (if plus c d == zeroa then poly_add p (q1 ++ q2)
        else (m, plus c d) : poly_add p (q1 ++ q2));
  });

poly_mult ::
  forall a b.
    (Eq a, Linorder a, Eq b,
      Semiring_0 b) => [(Monom a, b)] -> [(Monom a, b)] -> [(Monom a, b)];
poly_mult [] q = [];
poly_mult (mc : p) q = poly_add (monom_mult_poly mc q) (poly_mult p q);

one_poly :: forall a b. (Linorder a, Semiring_1 b) => [(Monom a, b)];
one_poly = [(one_monom, one)];

poly_of ::
  forall a b.
    (Eq a, Linorder a, Eq b, Comm_semiring_1 b) => Tpoly a b -> [(Monom a, b)];
poly_of (PNum i) = (if i == zeroa then [] else [(one_monom, i)]);
poly_of (PVar x) = [(var_monom x, one)];
poly_of (PSum []) = zero_poly;
poly_of (PSum (p : ps)) = poly_add (poly_of p) (poly_of (PSum ps));
poly_of (PMult []) = one_poly;
poly_of (PMult (p : ps)) = poly_mult (poly_of p) (poly_of (PMult ps));

dvd :: forall a. (Eq a, Semidom_modulo a) => a -> a -> Bool;
dvd a b = modulo b a == zeroa;

sup_set :: forall a. (Eq a) => Set a -> Set a -> Set a;
sup_set (Set xs) a = fold inserta xs a;
sup_set (Coset xs) a = Coset (filter (\ x -> not (member x a)) xs);

bot_set :: forall a. Set a;
bot_set = Set [];

sup_seta :: forall a. (Eq a) => Set (Set a) -> Set a;
sup_seta (Set xs) = fold sup_set xs bot_set;

vars_term :: forall a b. (Eq b) => Term a b -> Set b;
vars_term (Var x1) = inserta x1 bot_set;
vars_term (Fun x21 x22) = sup_seta (image vars_term (Set x22));

array_get :: forall a. Array.Array a -> Nat -> a;
array_get (Array.Array a) n = nth a n;

array_set :: forall a. Array.Array a -> Nat -> a -> Array.Array a;
array_set (Array.Array aa) n a = Array.Array (list_update aa n a);

as_length :: forall a. (Array.Array a, Nat) -> Nat;
as_length = snd;

array_shrink :: forall a. Array.Array a -> Nat -> Array.Array a;
array_shrink (Array.Array a) sz =
  (if less_nat (size_list a) sz then error "undefined"
    else Array.Array (take sz a));

array_length :: forall a. Array.Array a -> Nat;
array_length (Array.Array a) = size_list a;

as_shrink :: forall a. (Array.Array a, Nat) -> (Array.Array a, Nat);
as_shrink s =
  (case s of {
    (a, n) ->
      let {
        aa = (if less_eq_nat (times_nat (nat_of_integer (128 :: Integer)) n)
                   (array_length a) &&
                   less_nat (nat_of_integer (4 :: Integer)) n
               then array_shrink a n else a);
      } in (aa, n);
  });

as_take :: forall a. Nat -> (Array.Array a, Nat) -> (Array.Array a, Nat);
as_take m s = (case s of {
                (a, n) -> (if less_nat m n then as_shrink (a, m) else (a, n));
              });

as_top :: forall a. (Array.Array a, Nat) -> a;
as_top s = (case s of {
             (a, n) -> array_get a (minus_nat n one_nat);
           });

as_pop :: forall a. (Array.Array a, Nat) -> (Array.Array a, Nat);
as_pop s = (case s of {
             (a, n) -> as_shrink (a, minus_nat n one_nat);
           });

as_get :: forall a. (Array.Array a, Nat) -> Nat -> a;
as_get s i = (case s of {
               (a, _) -> array_get a i;
             });

while :: forall a. (a -> Bool) -> (a -> a) -> a -> a;
while b c s = (if b s then while b c (c s) else s);

pop_tr ::
  forall a.
    (Compare_order a) => ((Array.Array a, Nat),
                           ((Array.Array Nat, Nat),
                             (Rbta a Int, (Array.Array (Nat, [a]), Nat)))) ->
                           ((Array.Array a, Nat),
                             ((Array.Array Nat, Nat),
                               (Rbta a Int, (Array.Array (Nat, [a]), Nat))));
pop_tr s =
  (case s of {
    (a, (aa, (ab, bb))) ->
      let {
        x = minus_nat (as_length aa) one_nat;
        xa = (case while (\ (xe, _) ->
                           less_nat xe
                             (if equal_nat (plus_nat x one_nat) (as_length aa)
                               then as_length a
                               else as_get aa (plus_nat x one_nat)))
                     (\ (ac, bc) ->
                       (suc ac,
                         rbt_insert (as_get a ac) (uminus_int one_int) bc))
                     (as_get aa x, ab)
               of {
               (_, bc) -> bc;
             });
        xb = as_take (as_top aa) a;
        xc = as_pop aa;
      } in (xb, (xc, (xa, bb)));
  });

lec_poly :: forall a. Le_constraint a -> Linear_poly;
lec_poly (Le_Constraint x1 x2 x3) = x2;

constraint_to_le_constraint :: Constraint -> [Le_constraint Rat];
constraint_to_le_constraint (LEQ l x) = [Le_Constraint Leq_Rel l x];
constraint_to_le_constraint (GEQ l x) =
  [Le_Constraint Leq_Rel (uminus_linear_poly l) (uminus_rat x)];
constraint_to_le_constraint (LT l x) = [Le_Constraint Lt_Rel l x];
constraint_to_le_constraint (GT l x) =
  [Le_Constraint Lt_Rel (uminus_linear_poly l) (uminus_rat x)];
constraint_to_le_constraint (EQ l x) =
  [Le_Constraint Leq_Rel l x,
    Le_Constraint Leq_Rel (uminus_linear_poly l) (uminus_rat x)];

normalizea :: [Constraint] -> [Le_constraint Rat];
normalizea cs = concatMap constraint_to_le_constraint cs;

vars_of_constraints :: [Constraint] -> [Nat];
vars_of_constraints cs =
  remdups (concatMap (vars_list . lec_poly) (normalizea cs));

divmod_nat :: Nat -> Nat -> (Nat, Nat);
divmod_nat m n =
  let {
    k = integer_of_nat m;
    l = integer_of_nat n;
  } in map_prod nat_of_integer nat_of_integer
         (if k == (0 :: Integer) then ((0 :: Integer), (0 :: Integer))
           else (if l == (0 :: Integer) then ((0 :: Integer), k)
                  else divMod ( k ) ( l )));

binary_power :: forall a. (Monoid_mult a) => a -> Nat -> a;
binary_power x n =
  (if equal_nat n zero_nat then one
    else (case divmod_nat n (nat_of_integer (2 :: Integer)) of {
           (d, r) -> let {
                       rec = binary_power (times x x) d;
                     } in (if equal_nat r zero_nat then rec else times rec x);
         }));

sqrt_int_maina :: Int -> Int -> (Int, Bool);
sqrt_int_maina x n =
  let {
    x2 = times_int x x;
  } in (if less_eq_int x2 n then (x, equal_int x2 n)
         else sqrt_int_maina
                (divide_int (plus_int (divide_int n x) x)
                  (Int_of_integer (2 :: Integer)))
                n);

numeral :: forall a. (Numeral a) => Num -> a;
numeral One = one;
numeral (Bit0 n) = let {
                     m = numeral n;
                   } in plus m m;
numeral (Bit1 n) = let {
                     m = numeral n;
                   } in plus (plus m m) one;

of_nat :: forall a. (Semiring_1 a) => Nat -> a;
of_nat n =
  (if equal_nat n zero_nat then zeroa
    else (case divmod_nat n (nat_of_integer (2 :: Integer)) of {
           (m, q) -> let {
                       ma = times (numeral (Bit0 One)) (of_nat m);
                     } in (if equal_nat q zero_nat then ma else plus ma one);
         }));

ceiling :: forall a. (Floor_ceiling a) => a -> Int;
ceiling x = uminus_int (floor (uminus x));

log_ceiling :: Int -> Int -> Nat;
log_ceiling b x = (case log_main (into_base b) x of {
                    (y, by) -> (if equal_int x by then y else suc y);
                  });

start_value :: Int -> Nat -> Int;
start_value n p =
  binary_power (Int_of_integer (2 :: Integer))
    (nat (ceiling
           (divide_rat (of_nat (log_ceiling (Int_of_integer (2 :: Integer)) n))
             (of_nat p))));

sqrt_int_main :: Int -> (Int, Bool);
sqrt_int_main x =
  sqrt_int_maina (start_value x (nat_of_integer (2 :: Integer))) x;

sqrt_int_ceiling_pos :: Int -> Int;
sqrt_int_ceiling_pos x = (case sqrt_int_main x of {
                           (y, True) -> y;
                           (y, False) -> plus_int y one_int;
                         });

sqrt_int_floor_pos :: Int -> Int;
sqrt_int_floor_pos x = fst (sqrt_int_main x);

sqrt_int_floor :: Int -> Int;
sqrt_int_floor x =
  (if less_eq_int zero_int x then sqrt_int_floor_pos x
    else uminus_int (sqrt_int_ceiling_pos (uminus_int x)));

det_bound_hadamard :: Nat -> Int -> Int;
det_bound_hadamard n c =
  (if equal_nat n one_nat || dvd (nat_of_integer (2 :: Integer)) n
    then times_int
           (binary_power (int_of_nat n)
             (divide_nat n (nat_of_integer (2 :: Integer))))
           (binary_power (abs_int c) n)
    else sqrt_int_floor
           (binary_power
             (times_int (int_of_nat n)
               (binary_power c (nat_of_integer (2 :: Integer))))
             n));

abort_empty_set :: forall a. (Set a -> a) -> a;
abort_empty_set _ = error "List.abort_empty_set";

maxa :: forall a. (Linorder a) => Set a -> a;
maxa (Set []) = abort_empty_set maxa;
maxa (Set (x : xs)) = fold max xs x;

vars :: Linear_poly -> Set Nat;
vars lp = fset (fmdom (linear_poly_map lp));

max_coeff :: Le_constraint Rat -> Rat;
max_coeff (Le_Constraint uu l c) =
  maxa (sup_set (inserta (abs_rat c) bot_set)
         (image (\ x -> abs_rat (coeff l x)) (vars l)));

max_coeff_constraints :: [Le_constraint Rat] -> Rat;
max_coeff_constraints cs = maxa (Set (zero_rat : map max_coeff cs));

lcm_fin :: forall a. (Semiring_gcd a) => Set a -> a;
lcm_fin (Set xs) = fold lcm xs one;

common_denominator :: Le_constraint Rat -> Int;
common_denominator (Le_Constraint uu l c) =
  let {
    coeffs_list = map (coeff l) (vars_list l);
    denominators = map (snd . quotient_of) (c : coeffs_list);
  } in lcm_fin (Set denominators);

mul_constraint :: Rat -> Le_constraint Rat -> Le_constraint Rat;
mul_constraint x (Le_Constraint r l c) =
  Le_Constraint r (scaleRat_linear_poly x l) (times_rat x c);

constraint_to_ints :: Le_constraint Rat -> Le_constraint Rat;
constraint_to_ints c = mul_constraint (of_int (common_denominator c)) c;

var_list :: [Constraint] -> [Nat];
var_list cs = let {
                lecs = concatMap constraint_to_le_constraint cs;
                polys = map lec_poly lecs;
              } in remdups (concatMap vars_list polys);

compute_bound_num_of_vars :: [Constraint] -> Int;
compute_bound_num_of_vars cs =
  let {
    le_cs = normalizea cs;
    le_csa = map constraint_to_ints le_cs;
    max_coeff = max_coeff_constraints le_csa;
    n = plus_nat one_nat (size_list (var_list cs));
  } in times_int (int_of_nat (plus_nat n one_nat))
         (det_bound_hadamard n (floor_rat max_coeff));

solution_simplex :: forall a. Simplex_state a -> Nat -> Rat;
solution_simplex (Simplex_State (cs, ((asi, (tv, ui)), s))) =
  map2fun (from_ns (tv (v s)) cs);

i_bounds_to_constraints ::
  forall a.
    [Nat] -> (Nat -> (a, Int)) -> (Nat -> (a, Int)) -> [(a, Constraint)];
i_bounds_to_constraints is lb ub =
  map (\ x -> (fst (lb x), GEQ (var x) (of_int (snd (lb x))))) is ++
    map (\ x -> (fst (ub x), LEQ (var x) (of_int (snd (ub x))))) is;

atom_to_qdnsconstr :: Atom Rat -> Ns_constraint QDelta;
atom_to_qdnsconstr atm =
  (case atm of {
    Leq x qdcnst -> LEQ_ns (var x) (QDelta qdcnst zero_rat);
    Geq x qdcnst -> GEQ_ns (var x) (QDelta qdcnst zero_rat);
  });

atom_to_qdatom :: Atom Rat -> Atom QDelta;
atom_to_qdatom atm = (case atm of {
                       Leq vr c -> Leq vr (QDelta c zero_rat);
                       Geq vr c -> Geq vr (QDelta c zero_rat);
                     });

update_iatom_in_state ::
  Simplex_state Nat -> (Nat, Atom Rat) -> Simplex_state Nat;
update_iatom_in_state s iatm =
  (case s of {
    Simplex_State (cs, ((asi, (tv, ui)), l3s)) ->
      let {
        csa = list_update cs (fst iatm) (atom_to_qdnsconstr (snd iatm));
        asia = updatea (fst iatm) [(fst iatm, atom_to_qdatom (snd iatm))] asi;
      } in Simplex_State (csa, ((asia, (tv, ui)), l3s));
  });

list_map_to_fun ::
  forall a b. (Compare_order a) => Mapping a [(a, b)] -> a -> [(a, b)];
list_map_to_fun m i = (case lookupa m i of {
                        Nothing -> [];
                        Just ias -> ias;
                      });

assert_s ::
  forall a b.
    (Eq a, Eq b, Lrv b) => (a, Atom b) -> State a b -> Sum [a] (State a b);
assert_s a s = let {
                 sa = assert_bound_code a s;
               } in (if u sa then Inl (the (u_c sa)) else Inr sa);

assert_all_s ::
  forall a b.
    (Eq a, Eq b, Lrv b) => [(a, Atom b)] -> State a b -> Sum [a] (State a b);
assert_all_s [] s = Inr s;
assert_all_s (a : asa) s = (case assert_s a s of {
                             Inl aa -> Inl aa;
                             Inr aa -> assert_all_s asa aa;
                           });

assert_simplex ::
  forall a.
    (Compare_order a,
      Eq a) => a -> Simplex_state a -> Sum [a] (Simplex_state a);
assert_simplex i (Simplex_State (cs, ((asi, (tv, ui)), s))) =
  (if membera ui i then Inl [i]
    else (case assert_all_s (list_map_to_fun asi i) s of {
           Inl a -> Inl a;
           Inr sa -> Inr (Simplex_State (cs, ((asi, (tv, ui)), sa)));
         }));

assert_all_simplex ::
  forall a.
    (Compare_order a,
      Eq a) => [a] -> Simplex_state a -> Sum [a] (Simplex_state a);
assert_all_simplex [] s = Inr s;
assert_all_simplex (ja : j) s = (case assert_simplex ja s of {
                                  Inl a -> Inl a;
                                  Inr a -> assert_all_simplex j a;
                                });

del_atom_from_state ::
  Simplex_state Nat -> (Nat, Atom Rat) -> Simplex_state Nat;
del_atom_from_state s iatm =
  (case s of {
    Simplex_State (l1, (l2, State t bl bu v c uc)) ->
      let {
        bua = deletea (atom_var (snd iatm)) bu;
        bla = deletea (atom_var (snd iatm)) bl;
      } in Simplex_State (l1, (l2, State t bla bua v c uc));
  });

sum_to_option :: forall a b. Sum a b -> Maybe b;
sum_to_option (Inr x) = Just x;
sum_to_option (Inl uu) = Nothing;

bnb_update_state ::
  [(Nat, Constraint)] ->
    [Nat] ->
      (Nat -> (Nat, Int)) ->
        (Nat -> (Nat, Int)) ->
          Simplex_state Nat -> (Nat, Atom Rat) -> Maybe (Simplex_state Nat);
bnb_update_state cs is lb ub s iatm =
  let {
    idx_list = map fst (i_bounds_to_constraints is lb ub ++ cs);
  } in (case assert_all_simplex (remove1 (fst iatm) idx_list)
               (del_atom_from_state s iatm)
         of {
         Inl _ -> Nothing;
         Inr sa ->
           sum_to_option
             (assert_simplex (fst iatm) (update_iatom_in_state sa iatm));
       });

check_s ::
  forall a b. (Eq a, Eq b, Lrv b) => State a b -> (State a b, Maybe [a]);
check_s s = let {
              sa = check_code s;
            } in (if u sa then (sa, Just (the (u_c sa))) else (sa, Nothing));

check_simplex ::
  forall a. (Eq a) => Simplex_state a -> (Simplex_state a, Maybe [a]);
check_simplex (Simplex_State (cs, (asi_tv, s))) =
  (case check_s s of {
    (sa, a) -> (Simplex_State (cs, (asi_tv, sa)), a);
  });

is_int_rat :: Rat -> Bool;
is_int_rat x = equal_int (snd (quotient_of x)) one_int;

bnb_state_core_p ::
  [(Nat, Constraint)] ->
    [Nat] ->
      Mapping Nat (Nat, Int) ->
        Mapping Nat (Nat, Int) ->
          Simplex_state Nat -> Maybe (Maybe (Nat -> Rat));
bnb_state_core_p cs is lb ub s =
  (case check_simplex s of {
    (x, Nothing) ->
      let {
        v = solution_simplex x;
      } in (case find (\ xa -> not (is_int_rat (v xa))) is of {
             Nothing -> Just (Just v);
             Just xa ->
               let {
                 new_leq =
                   (fst (the (lookupa ub xa)),
                     Leq xa (of_int (floor_rat (v xa))));
                 new_geq =
                   (fst (the (lookupa lb xa)),
                     Geq xa (of_int (ceiling (v xa))));
                 uba = updatea xa (fst (the (lookupa ub xa)), floor_rat (v xa))
                         ub;
                 lba = updatea xa (fst (the (lookupa lb xa)), ceiling (v xa))
                         lb;
               } in bind (case bnb_update_state cs is (the . lookupa lb)
                                 (the . lookupa uba) x new_leq
                           of {
                           Nothing -> Just Nothing;
                           Just a -> bnb_state_core_p cs is lb uba a;
                         })
                      (\ a ->
                        (case a of {
                          Nothing ->
                            (case bnb_update_state cs is (the . lookupa lba)
                                    (the . lookupa ub) x new_geq
                              of {
                              Nothing -> Just Nothing;
                              Just aa -> bnb_state_core_p cs is lba ub aa;
                            });
                          Just va -> Just (Just va);
                        }));
           });
    (_, Just _) -> Just Nothing;
  });

create_map :: forall a b. (Compare_order a) => [(a, b)] -> Mapping a [(a, b)];
create_map [] = emptya;
create_map ((i, a) : xs) = let {
                             m = create_map xs;
                           } in (case lookupa m i of {
                                  Nothing -> updatea i [(i, a)] m;
                                  Just ias -> updatea i ((i, a) : ias) m;
                                });

init_simplex ::
  forall a. (Compare_order a, Eq a) => [(a, Constraint)] -> Simplex_state a;
init_simplex cs =
  let {
    tons_cs = to_ns cs;
  } in Simplex_State
         (map snd tons_cs,
           (case preprocess tons_cs of {
             (t, (asa, (trans_v, ui))) ->
               ((create_map asa, (trans_v, remdups ui)), init_state t);
           }));

bnb_state_init ::
  [Constraint] ->
    [Nat] ->
      (Nat -> Int) ->
        (Nat -> Int) ->
          ([(Nat, Constraint)],
            (Mapping Nat (Nat, Int),
              (Mapping Nat (Nat, Int), Sum [Nat] (Simplex_state Nat))));
bnb_state_init cs is lb ub =
  let {
    lba = zip is (upt zero_nat (size_list is));
    uba = zip is (upt (size_list is) (plus_nat (size_list is) (size_list is)));
    lbb = map (\ (x, y) -> (x, (y, lb x))) lba;
    ubb = map (\ (x, y) -> (x, (y, ub x))) uba;
    lb_m = of_alist lbb;
    ub_m = of_alist ubb;
    csa = zip (upt (plus_nat (size_list is) (size_list is))
                (plus_nat (plus_nat (size_list is) (size_list is))
                  (size_list cs)))
            cs;
    bs = i_bounds_to_constraints is (the . lookupa lb_m) (the . lookupa ub_m) ++
           csa;
    s = assert_all_simplex (map fst bs) (init_simplex bs);
  } in (csa, (lb_m, (ub_m, s)));

branch_and_bound :: [Constraint] -> [Nat] -> Maybe (Nat -> Rat);
branch_and_bound cs is =
  let {
    bnd = compute_bound_num_of_vars cs;
  } in (case bnb_state_init cs is (\ _ -> uminus_int bnd) (\ _ -> bnd) of {
         (_, (_, (_, Inl _))) -> Nothing;
         (csa, (lb_m, (ub_m, Inr s))) ->
           the (bnb_state_core_p csa is lb_m ub_m s);
       });

int_of_rat :: Rat -> Int;
int_of_rat x = fst (quotient_of x);

branch_and_bound_int :: [Constraint] -> Maybe (Nat -> Int);
branch_and_bound_int cs =
  let {
    vs = vars_of_constraints cs;
  } in (case branch_and_bound cs vs of {
         Nothing -> Nothing;
         Just v ->
           Just (\ x -> (if membera vs x then int_of_rat (v x) else zero_int));
       });

la_solver :: La_solver_type -> [Constraint] -> Maybe (Nat -> Int);
la_solver BB_Solver cs = branch_and_bound_int cs;
la_solver Simplex_Solver cs = (case simplex cs of {
                                Inl _ -> Nothing;
                                Inr v -> Just (\ x -> floor_rat (map2fun v x));
                              });

succ_transitions ::
  forall a b c d e.
    (Eq d) => Lts_impl a b c d e -> d -> [Transition_rule a b c d];
succ_transitions (Lts_Impl i ts lc) l =
  concatMap (\ (_, tau) -> (if source tau == l then [tau] else [])) ts;

extract_special :: [Char] -> [Char] -> Maybe ([Char], [Char]);
extract_special acc [] = Nothing;
extract_special acc (x : xs) =
  (if equal_char x char_0x3B
    then map_option (\ s -> (s, xs)) (special_map (reverse acc))
    else extract_special (x : acc) xs);

array_grow :: forall a. Array.Array a -> Nat -> a -> Array.Array a;
array_grow (Array.Array a) inc x = Array.Array (a ++ replicate inc x);

modulo_int :: Int -> Int -> Int;
modulo_int k l =
  Int_of_integer (modulo_integer (integer_of_int k) (integer_of_int l));

euclid_rem :: Int -> Int -> Int;
euclid_rem n d = modulo_int n (abs_int d);

diff_by_label :: forall a b. (Eq a) => [(a, b)] -> Set a -> [(a, b)];
diff_by_label pairs l = filter (\ v -> not (member (fst v) l)) pairs;

zero_enat :: Enat;
zero_enat = Enat zero_nat;

minus_enat :: Enat -> Enat -> Enat;
minus_enat (Enat a) (Enat b) = Enat (minus_nat a b);
minus_enat Infinity_enat n = Infinity_enat;
minus_enat (Enat a) Infinity_enat = zero_enat;

equal_enat :: Enat -> Enat -> Bool;
equal_enat (Enat nat) Infinity_enat = False;
equal_enat Infinity_enat (Enat nat) = False;
equal_enat (Enat nata) (Enat nat) = equal_nat nata nat;
equal_enat Infinity_enat Infinity_enat = True;

one_enat :: Enat;
one_enat = Enat one_nat;

xml_take_many_sub ::
  forall a b.
    [a] ->
      Nat ->
        Enat ->
          ((Xml, ([([Char], [Char])], (Bool, ([String], [String])))) ->
            Sum_bot (Xml_error String) a) ->
            ([a] ->
              ([Xml], ([([Char], [Char])], (Bool, ([String], [String])))) ->
                Sum_bot (Xml_error String) b) ->
              ([Xml], ([([Char], [Char])], (Bool, ([String], [String])))) ->
                Sum_bot (Xml_error String) b;
xml_take_many_sub acc minOccurs maxOccurs p1 p2 ([], (atts, (allow, rest))) =
  (if equal_nat minOccurs zero_nat
    then p2 (reverse acc) ([], (atts, (allow, rest)))
    else bind2 (p1 (XML [] [] [], (atts, (False, rest)))) left
           (\ _ -> left (Fatal "unexpected")));
xml_take_many_sub acc minOccurs maxOccurs p1 p2
  (xml : xmls, (atts, (allow, (cands, rest)))) =
  (if equal_enat maxOccurs zero_enat
    then p2 (reverse acc) (xml : xmls, (atts, (allow, (cands, rest))))
    else bind2 (p1 (xml, (atts, (equal_nat minOccurs zero_nat, (cands, rest)))))
           (\ e ->
             (case e of {
               TagMismatch _ ->
                 p2 (reverse acc) (xml : xmls, (atts, (allow, (cands, rest))));
               Fatal _ -> left e;
             }))
           (\ a ->
             xml_take_many_sub (a : acc) (minus_nat minOccurs one_nat)
               (minus_enat maxOccurs one_enat) p1 p2
               (xmls, (atts, (False, ([], rest))))));

formula_parser ::
  forall a b c.
    ((Xml, ([([Char], [Char])], (Bool, ([String], [String])))) ->
      Sum_bot (Xml_error String) (Formula (Term a (b, c)))) ->
      (Xml, ([([Char], [Char])], (Bool, ([String], [String])))) ->
        Sum_bot (Xml_error String) (Formula (Term a (b, c)));
formula_parser atom_parser x =
  xml_or
    (xml_do "disjunction"
      (xml_take_many_sub [] zero_nat Infinity_enat (formula_parser atom_parser)
        (\ fs -> xml_return (Disjunction fs))))
    (xml_or
      (xml_do "conjunction"
        (xml_take_many_sub [] zero_nat Infinity_enat
          (formula_parser atom_parser) (\ fs -> xml_return (Conjunction fs))))
      atom_parser)
    x;

hints_parser ::
  forall a.
    (Default a) => (Xml, ([([Char], [Char])], (Bool, ([String], [String])))) ->
                     Sum_bot (Xml_error String) a;
hints_parser xml = xml_do "auto" (xml_return defaulta) xml;

xml_take_default ::
  forall a b.
    a -> ((Xml, ([([Char], [Char])], (Bool, ([String], [String])))) ->
           Sum_bot (Xml_error String) a) ->
           (a -> ([Xml], ([([Char], [Char])], (Bool, ([String], [String])))) ->
                   Sum_bot (Xml_error String) b) ->
             ([Xml], ([([Char], [Char])], (Bool, ([String], [String])))) ->
               Sum_bot (Xml_error String) b;
xml_take_default a p1 p2 xs =
  (case xs of {
    ([], _) -> p2 a xs;
    (xml : xmls, (atts, (allow, (cands, rest)))) ->
      bind2 (p1 (xml, (atts, (True, (cands, rest)))))
        (\ e ->
          (case e of {
            TagMismatch cands1 ->
              p2 a (xml : xmls, (atts, (allow, (cands1, rest))));
            Fatal _ -> left e;
          }))
        (\ aa -> p2 aa (xmls, (atts, (False, ([], rest)))));
  });

art_node_parser ::
  forall a b c d e f g.
    (Default g) => (String ->
                     (Xml, ([([Char], [Char])],
                             (Bool, ([String], [String])))) ->
                       Sum_bot (Xml_error String) a) ->
                     ((Xml, ([([Char], [Char])],
                              (Bool, ([String], [String])))) ->
                       Sum_bot (Xml_error String) b) ->
                       ((Xml, ([([Char], [Char])],
                                (Bool, ([String], [String])))) ->
                         Sum_bot (Xml_error String) c) ->
                         ((Xml, ([([Char], [Char])],
                                  (Bool, ([String], [String])))) ->
                           Sum_bot (Xml_error String)
                             (Formula (Term d (e, f)))) ->
                           (Xml, ([([Char], [Char])],
                                   (Bool, ([String], [String])))) ->
                             Sum_bot (Xml_error String)
                               (Art_node_impl d e f b a c g, [a]);
art_node_parser art_node_id_parser location_parser trans_parser atom_parser =
  xml_do "node"
    (xml_take_default False (xml_do "initial" (xml_return True))
      (\ init ->
        xml_take (art_node_id_parser "nodeId")
          (\ nodeId ->
            xml_take
              (xml_do "invariant"
                (xml_take (formula_parser atom_parser) xml_return))
              (\ invariant ->
                xml_take
                  (xml_do "location" (xml_take location_parser xml_return))
                  (\ location ->
                    xml_take
                      (xml_or
                        (xml_do "children"
                          (xml_take_many_sub [] zero_nat Infinity_enat
                            (xml_do "child"
                              (xml_take trans_parser
                                (\ tr ->
                                  xml_take (art_node_id_parser "nodeId")
                                    (\ n ->
                                      xml_take_default defaulta
(xml_do "hints" (xml_take hints_parser xml_return))
(\ h -> xml_return (tr, (n, h)))))))
                            (\ chs -> xml_return (Children_Edge chs))))
                        (xml_do "coverEdge"
                          (xml_take (art_node_id_parser "nodeId")
                            (\ n ->
                              xml_take_default defaulta
                                (xml_do "hints"
                                  (xml_take hints_parser xml_return))
                                (\ h -> xml_return (Cover_Edge n h))))))
                      (\ edges ->
                        xml_return
                          (Art_Node nodeId invariant location edges,
                            (if init then [nodeId] else []))))))));

art_parser ::
  forall a b c d e f g.
    (Default g) => (String ->
                     (Xml, ([([Char], [Char])],
                             (Bool, ([String], [String])))) ->
                       Sum_bot (Xml_error String) a) ->
                     ((Xml, ([([Char], [Char])],
                              (Bool, ([String], [String])))) ->
                       Sum_bot (Xml_error String) b) ->
                       ((Xml, ([([Char], [Char])],
                                (Bool, ([String], [String])))) ->
                         Sum_bot (Xml_error String) c) ->
                         ((Xml, ([([Char], [Char])],
                                  (Bool, ([String], [String])))) ->
                           Sum_bot (Xml_error String)
                             (Formula (Term d (e, f)))) ->
                           (Xml, ([([Char], [Char])],
                                   (Bool, ([String], [String])))) ->
                             Sum_bot (Xml_error String)
                               (Art_impl_ext d e f b a c g ());
art_parser art_node_id_parser location_parser trans_parser atom_parser =
  xml_do "impact"
    (xml_take_default []
      (xml_change (art_node_id_parser "initial") (\ x -> xml_return [x]))
      (\ init ->
        xml_take
          (xml_do "nodes"
            (xml_take_many_sub [] zero_nat Infinity_enat
              (art_node_parser art_node_id_parser location_parser trans_parser
                atom_parser)
              xml_return))
          (\ pairs -> let {
                        nodes = map fst pairs;
                        inits = init ++ concatMap snd pairs;
                      } in xml_return (Art_impl_ext inits nodes ()))));

transition_parser ::
  forall a b c d e.
    ((Xml, ([([Char], [Char])], (Bool, ([String], [String])))) ->
      Sum_bot (Xml_error String) a) ->
      ((Xml, ([([Char], [Char])], (Bool, ([String], [String])))) ->
        Sum_bot (Xml_error String) b) ->
        ((Xml, ([([Char], [Char])], (Bool, ([String], [String])))) ->
          Sum_bot (Xml_error String) (Formula (Term c (Trans_var d, e)))) ->
          (Xml, ([([Char], [Char])], (Bool, ([String], [String])))) ->
            Sum_bot (Xml_error String) (b, Transition_rule c d e a);
transition_parser location_parser trans_parser tatom_parser =
  xml_do "transition"
    (xml_take trans_parser
      (\ tr ->
        xml_take (xml_do "source" (xml_take location_parser xml_return))
          (\ l ->
            xml_take (xml_do "target" (xml_take location_parser xml_return))
              (\ r ->
                xml_take
                  (xml_do "formula"
                    (xml_take (formula_parser tatom_parser) xml_return))
                  (\ phi -> xml_return (tr, Transition l r phi))))));

lts_parser ::
  forall a b c d e.
    ((Xml, ([([Char], [Char])], (Bool, ([String], [String])))) ->
      Sum_bot (Xml_error String) a) ->
      ((Xml, ([([Char], [Char])], (Bool, ([String], [String])))) ->
        Sum_bot (Xml_error String) b) ->
        ((Xml, ([([Char], [Char])], (Bool, ([String], [String])))) ->
          Sum_bot (Xml_error String) (Formula (Term c (Trans_var d, e)))) ->
          String ->
            (Xml, ([([Char], [Char])], (Bool, ([String], [String])))) ->
              Sum_bot (Xml_error String) (Lts_impl c d e a b);
lts_parser location_parser trans_parser tatom_parser tag =
  xml_do tag
    (xml_take
      (xml_do "initial"
        (xml_take_many_sub [] one_nat Infinity_enat location_parser xml_return))
      (\ i ->
        xml_take_many_sub [] zero_nat Infinity_enat
          (transition_parser location_parser trans_parser tatom_parser)
          (\ t -> xml_return (Lts_Impl i t []))));

eval_monom_list ::
  forall a b. (Linorder a, Comm_semiring_1 b) => (a -> b) -> [(a, Nat)] -> b;
eval_monom_list alpha [] = one;
eval_monom_list alpha ((x, p) : m) =
  times (eval_monom_list alpha m) (binary_power (alpha x) p);

eval_monom ::
  forall a b. (Linorder a, Comm_semiring_1 b) => (a -> b) -> Monom a -> b;
eval_monom x xc = eval_monom_list x (rep_monom xc);

eval_poly ::
  forall a b.
    (Linorder a, Comm_semiring_1 b) => (a -> b) -> [(Monom a, b)] -> b;
eval_poly alpha [] = zeroa;
eval_poly alpha (mc : p) =
  plus (times (eval_monom alpha (fst mc)) (snd mc)) (eval_poly alpha p);

normalize_special :: [Char] -> [Char];
normalize_special [] = [];
normalize_special (x : xs) =
  (if equal_char x char_0x26
    then (case extract_special [] xs of {
           Nothing -> [char_0x26] ++ normalize_special xs;
           Just (spec, ys) -> spec ++ normalize_special ys;
         })
    else x : normalize_special xs);

parse_xml_string ::
  forall a.
    ((Xml, ([([Char], [Char])], (Bool, ([String], [String])))) ->
      Sum_bot (Xml_error String) a) ->
      [Char] -> Sum_bot [Char] a;
parse_xml_string p str =
  (case doc_of_string str of {
    Inl a -> left a;
    Inr (XMLDOC _ xml) -> parse_xml p (map_xml_text normalize_special xml);
  });

eval :: forall a b c. (a -> [b] -> b) -> Term a c -> (c -> b) -> b;
eval i (Var x) alpha = alpha x;
eval i (Fun f ss) alpha = i f (map (\ s -> eval i s alpha) ss);

euclid_quot :: Int -> Int -> Int;
euclid_quot n d =
  (if less_int d zero_int then uminus_int (divide_int n (uminus_int d))
    else divide_int n d);

to_bool :: Val -> Bool;
to_bool (Boola x2) = x2;

ia4_ground_val :: forall a. (Compare_order a) => [(a, Int)] -> (a, Ty) -> Val;
ia4_ground_val vs (x, IntT) = Int (map_of_default zero_int vs x);
ia4_ground_val vs (x, BoolT) = Boola False;

satisfies :: forall a b. (a -> b -> Bool) -> a -> Formula b -> Bool;
satisfies eval_true alpha (Atom a) = eval_true alpha a;
satisfies eval_true alpha (NegAtom a) = not (eval_true alpha a);
satisfies eval_true alpha (Conjunction phi_s) =
  all (satisfies eval_true alpha) phi_s;
satisfies eval_true alpha (Disjunction phi_s) =
  any (satisfies eval_true alpha) phi_s;

to_int :: Val -> Int;
to_int (Int x1) = x1;

prod_list :: forall a. (Monoid_mult a) => [a] -> a;
prod_list xs = foldr times xs one;

ia :: Sig -> [Val] -> Val;
ia LessF [x, y] = Boola (less_int (to_int x) (to_int y));
ia LeF [x, y] = Boola (less_eq_int (to_int x) (to_int y));
ia EqF [x, y] = Boola (equal_int (to_int x) (to_int y));
ia (SumF n) xs = Int (sum_list (map to_int xs));
ia (ConstF x) [] = Int x;
ia (ProdF n) xs = Int (prod_list (map to_int xs));
ia LeF [] = error "undefined";
ia LeF [v] = error "undefined";
ia LeF (v : vb : vd : ve) = error "undefined";
ia (ConstF v) (va : vb) = error "undefined";
ia EqF [] = error "undefined";
ia EqF [v] = error "undefined";
ia EqF (v : vb : vd : ve) = error "undefined";
ia LessF [] = error "undefined";
ia LessF [v] = error "undefined";
ia LessF (v : vb : vd : ve) = error "undefined";

i :: Ia4_sig -> [Val] -> Val;
i (IA4_Base f) xs = ia f xs;
i IA4_Div [a, d] = Int (euclid_quot (to_int a) (to_int d));
i IA4_Mod [a, d] = Int (euclid_rem (to_int a) (to_int d));
i IA4_Div [] = error "undefined";
i IA4_Div [v] = error "undefined";
i IA4_Div (v : vb : vd : ve) = error "undefined";
i IA4_Mod [] = error "undefined";
i IA4_Mod [v] = error "undefined";
i IA4_Mod (v : vb : vd : ve) = error "undefined";

ia4_ground_state_ok ::
  forall a b c.
    (Compare_order a,
      Compare_order b) => Lts_impl Ia4_sig a Ty b c -> ([(a, Int)], b) -> Bool;
ia4_ground_state_ok p s =
  satisfies (\ alpha t -> to_bool (eval i t alpha)) (ia4_ground_val (fst s))
    (assertion_of p (snd s));

pre_post_inter ::
  forall a b c.
    ((a, b) -> c) -> ((a, b) -> c) -> ((a, b) -> c) -> (Trans_var a, b) -> c;
pre_post_inter alpha beta gamma (Pre x, t) = alpha (x, t);
pre_post_inter alpha beta gamma (Post x, t) = beta (x, t);
pre_post_inter alpha beta gamma (Intermediate x, t) = gamma (x, t);

ia4_check_ground_step ::
  forall a b c.
    (Compare_order a, Eq a, Compare_order b, Eq b,
      Eq c) => Lts_impl Ia4_sig a Ty b c ->
                 ([(a, Int)], b) ->
                   ((c, Transition_rule Ia4_sig a Ty b), ([(a, Int)], b)) ->
                     Sum (String -> String) ();
ia4_check_ground_step p src ((lab, Transition l r f), tgt) =
  binda (check (membera (transitions_impl p) (lab, Transition l r f))
          (showsl_lit "unknown lasso transition"))
    (\ _ ->
      binda (check (ia4_ground_state_ok p tgt)
              (showsl_lit "invalid target valuation"))
        (\ _ ->
          binda (check (snd src == l && snd tgt == r)
                  (showsl_lit "lasso endpoints"))
            (\ _ ->
              check (satisfies (\ alpha t -> to_bool (eval i t alpha))
                      (pre_post_inter (ia4_ground_val (fst src))
                        (ia4_ground_val (fst tgt)) (ia4_ground_val []))
                      f)
                (showsl_lit "lasso guard or update is false"))));

ia4_check_ground_seq ::
  forall a b c.
    (Compare_order a, Eq a, Compare_order b, Eq b,
      Eq c) => Lts_impl Ia4_sig a Ty b c ->
                 ([(a, Int)], b) ->
                   [((c, Transition_rule Ia4_sig a Ty b), ([(a, Int)], b))] ->
                     Sum (String -> String) ([(a, Int)], b);
ia4_check_ground_seq p src [] = Inr src;
ia4_check_ground_seq p src ((tau, tgt) : ts) =
  binda (ia4_check_ground_step p src (tau, tgt))
    (\ _ -> ia4_check_ground_seq p tgt ts);

type_of_funa :: Sig -> ([Ty], Ty);
type_of_funa LessF = ([IntT, IntT], BoolT);
type_of_funa LeF = ([IntT, IntT], BoolT);
type_of_funa EqF = ([IntT, IntT], BoolT);
type_of_funa (SumF n) = (replicate n IntT, IntT);
type_of_funa (ConstF uu) = ([], IntT);
type_of_funa (ProdF n) = (replicate n IntT, IntT);

type_of_fun :: Ia4_sig -> ([Ty], Ty);
type_of_fun (IA4_Base f) = type_of_funa f;
type_of_fun IA4_Div = ([IntT, IntT], IntT);
type_of_fun IA4_Mod = ([IntT, IntT], IntT);

all_interval :: forall a. (Eq a, Interval a) => (a -> Bool) -> a -> a -> Bool;
all_interval p a b =
  (if less a b then p a && all_interval p (plus a one) b else True) &&
    (if a == b then p a else True);

has_type ::
  forall a b c. (Eq b) => (a -> ([b], b)) -> Term a (c, b) -> b -> Bool;
has_type type_of_fun (Var v) ty = snd v == ty;
has_type type_of_fun (Fun f es) ty =
  ty == snd (type_of_fun f) &&
    equal_nat (size_list es) (size_list (fst (type_of_fun f))) &&
      let {
        d = minus_nat (size_list es) one_nat;
      } in (if less_nat d (size_list es)
             then all_interval
                    (\ i ->
                      has_type type_of_fun (nth es i)
                        (nth (fst (type_of_fun f)) i))
                    zero_nat d
             else True);

is_bool ::
  forall a b c. (Eq b) => (a -> ([b], b)) -> Set b -> Term a (c, b) -> Bool;
is_bool type_of_fun bool_types e = bex bool_types (has_type type_of_fun e);

formula :: forall a. (a -> Bool) -> Formula a -> Bool;
formula atom (Atom a) = atom a;
formula atom (NegAtom a) = atom a;
formula atom (Conjunction phi_s) = all (formula atom) phi_s;
formula atom (Disjunction phi_s) = all (formula atom) phi_s;

transition_rule ::
  forall a b c d.
    (Eq b) => (a -> ([b], b)) -> Set b -> Transition_rule a c b d -> Bool;
transition_rule type_of_fun bool_types (Transition l r phi) =
  formula (is_bool type_of_fun bool_types) phi;

check_lts_impl ::
  forall a b c d e.
    (Eq b) => (a -> ([b], b)) ->
                Set b -> Lts_impl a c b d e -> Sum (String -> String) ();
check_lts_impl type_of_fun bool_types pi =
  (case pi of {
    Lts_Impl _ ti lc ->
      binda (catch_error
              (forallM
                (\ (_, t) ->
                  check (transition_rule type_of_fun bool_types t)
                    (showsl_lit "ill-formed transition in LTS"))
                ti)
              (\ x -> Inl (snd x)))
        (\ _ ->
          catch_error
            (forallM
              (\ (_, f) ->
                check (formula (is_bool type_of_fun bool_types) f)
                  (showsl_lit "ill-formed location condition in LTS"))
              lc)
            (\ x -> Inl (snd x)));
  });

ia4_check_ground_nontermination ::
  forall a.
    (Compare_order a,
      Eq a) => Lts_impl Ia4_sig a Ty [Char] [Char] ->
                 Ia4_nontermination_proof a -> Sum (String -> String) ();
ia4_check_ground_nontermination p (IA4_EquivalentState init stem loop) =
  binda (check_lts_impl type_of_fun (inserta BoolT bot_set) p)
    (\ _ ->
      binda (check
              (membera (initiala p) (snd init) && ia4_ground_state_ok p init)
              (showsl_lit "invalid initial lasso state"))
        (\ _ ->
          binda (ia4_check_ground_seq p init stem)
            (\ head ->
              binda (ia4_check_ground_seq p head loop)
                (\ last ->
                  check (not (null loop) && head == last)
                    (showsl_lit "empty or non-closing lasso")))));

showsl_literal :: String -> String -> String;
showsl_literal s = showsl_lit s;

normalize_lits ::
  forall a b c.
    (Showl b) => (Bool -> Term a (b, c) -> Formula (Term a (b, c))) ->
                   Formula (Term a (b, c)) -> Formula (Term a (b, c));
normalize_lits normalize_lit (Conjunction phi_s) =
  Conjunction (map (normalize_lits normalize_lit) phi_s);
normalize_lits normalize_lit (Disjunction phi_s) =
  Disjunction (map (normalize_lits normalize_lit) phi_s);
normalize_lits normalize_lit (NegAtom phi) = normalize_lit False phi;
normalize_lits normalize_lit (Atom phi) = normalize_lit True phi;

showsl_formula ::
  forall a. (a -> String -> String) -> Formula a -> String -> String;
showsl_formula showsl_atom (Atom a) = showsl_atom a;
showsl_formula showsl_atom (NegAtom a) =
  (showsl_literal "! (" . showsl_atom a) . showsl_literal ")";
showsl_formula showsl_atom (Conjunction fs) =
  let {
    a = map (showsl_formula showsl_atom) fs;
  } in showsl_list_gen id "True" "Conj[" ", " "]" a;
showsl_formula showsl_atom (Disjunction fs) =
  let {
    a = map (showsl_formula showsl_atom) fs;
  } in showsl_list_gen id "False" "Disj[" ", " "]" a;

trivial_checker :: forall a. (Eq a) => [Formula a] -> Bool;
trivial_checker lits = (case partition is_Atom lits of {
                         (asa, nas) -> let {
 pos = map get_Atom asa;
 neg = map get_Atom nas;
                                       } in any (membera neg) pos;
                       });

trivial_clause_checker :: forall a. (Eq a) => Formula a -> Bool;
trivial_clause_checker f = (case f of {
                             Disjunction a -> trivial_checker a;
                           });

check_valid_formula ::
  forall a b c d.
    (Eq a, Eq b, Showl b, Eq c, Default d,
      Showl d) => (Term a (b, c) -> String -> String) ->
                    (d -> Formula (Term a (b, c)) ->
                            Sum (String -> String) ()) ->
                      (Bool -> Term a (b, c) -> Formula (Term a (b, c))) ->
                        d -> Formula (Term a (b, c)) ->
                               Sum (String -> String) ();
check_valid_formula showsl_atom logic_checker normalize_lit h phi =
  catch_error
    (case flatten phi of {
      Conjunction phi_s ->
        catch_error
          (forallM
            (\ phia ->
              catch_error
                (check (trivial_clause_checker phia)
                  "trivial clause checker failed")
                (\ _ ->
                  (case flatten (normalize_lits normalize_lit phia) of {
                    Conjunction phi_sa ->
                      catch_error (forallM (logic_checker h) phi_sa)
                        (\ x -> Inl (snd x));
                  })))
            phi_s)
          (\ x -> Inl (snd x));
    })
    (\ x ->
      Inl (((showsl_lit "problem in checking validity of formula " .
              showsl_formula showsl_atom phi) .
             showsl_literal "\n") .
            x));

ia4_policy_typed :: forall a b. [((a, Ty), Term Ia4_sig (b, Ty))] -> Bool;
ia4_policy_typed xs = all (\ (x, e) -> has_type type_of_fun e (snd x)) xs;

ia4_policy_path_valid ::
  forall a b c d e f g h i.
    (Eq a, Eq b, Eq c, Eq d,
      Eq e) => Lts_impl a b c d e ->
                 d -> [((e, Transition_rule a b c d),
                         ([((f, Ty), Term Ia4_sig (g, Ty))],
                           [((h, Ty), Term Ia4_sig (i, Ty))]))] ->
                        Bool;
ia4_policy_path_valid p l [] = True;
ia4_policy_path_valid p l ((tau, (post, local)) : steps) =
  membera (transitions_impl p) tau &&
    source (snd tau) == l &&
      ia4_policy_typed post &&
        ia4_policy_typed local &&
          ia4_policy_path_valid p (target (snd tau)) steps;

ia4_policy_path_end ::
  forall a b c d e f g. a -> [((b, Transition_rule c d e a), (f, g))] -> a;
ia4_policy_path_end l [] = l;
ia4_policy_path_end l ((tau, (post, local)) : steps) =
  ia4_policy_path_end (target (snd tau)) steps;

map_formula :: forall a b. (a -> b) -> Formula a -> Formula b;
map_formula f (Atom x1) = Atom (f x1);
map_formula f (NegAtom x2) = NegAtom (f x2);
map_formula f (Conjunction x3) = Conjunction (map (map_formula f) x3);
map_formula f (Disjunction x4) = Disjunction (map (map_formula f) x4);

ia4_subst_formula ::
  forall a b c. (a -> Term b c) -> Formula (Term b a) -> Formula (Term b c);
ia4_subst_formula s f = map_formula (\ e -> eval_term Fun e s) f;

ia4_policy_exp :: forall a b. (Eq a) => [(a, Term b a)] -> a -> Term b a;
ia4_policy_exp [] x = Var x;
ia4_policy_exp ((y, e) : xs) x = (if x == y then e else ia4_policy_exp xs x);

ia4_step_policy ::
  forall a b c.
    (Eq a,
      Eq b) => [((a, b), Term c (a, b))] ->
                 [((a, b), Term c (a, b))] -> (Trans_var a, b) -> Term c (a, b);
ia4_step_policy post local (Pre x, t) = Var (x, t);
ia4_step_policy post local (Post x, t) = ia4_policy_exp post (x, t);
ia4_step_policy post local (Intermediate x, t) = ia4_policy_exp local (x, t);

transition_formula ::
  forall a b c d. Transition_rule a b c d -> Formula (Term a (Trans_var b, c));
transition_formula (Transition uu uv phi) = phi;

ia4_policy_path_wp ::
  forall a b c d e f.
    (Eq b, Eq c,
      Compare_order d) => Lts_impl a b c d e ->
                            [((f, Transition_rule a b c d),
                               ([((b, c), Term a (b, c))],
                                 [((b, c), Term a (b, c))]))] ->
                              Formula (Term a (b, c)) ->
                                Formula (Term a (b, c));
ia4_policy_path_wp p [] region = region;
ia4_policy_path_wp p ((tau, (post, local)) : steps) region =
  Conjunction
    [ia4_subst_formula (ia4_step_policy post local)
       (transition_formula (snd tau)),
      ia4_subst_formula (ia4_policy_exp post)
        (assertion_of p (target (snd tau))),
      ia4_subst_formula (ia4_policy_exp post)
        (ia4_policy_path_wp p steps region)];

iA_exp_to_tpoly :: forall a. Term Sig (a, Ty) -> Tpoly a Int;
iA_exp_to_tpoly (Var (a, ty)) = PVar a;
iA_exp_to_tpoly (Fun (SumF uu) asa) = PSum (map iA_exp_to_tpoly asa);
iA_exp_to_tpoly (Fun (ConstF a) []) = PNum a;
iA_exp_to_tpoly (Fun (ProdF uv) asa) = PMult (map iA_exp_to_tpoly asa);

iA_exp_to_poly ::
  forall a. (Eq a, Linorder a) => Term Sig (a, Ty) -> [(Monom a, Int)];
iA_exp_to_poly = poly_of . iA_exp_to_tpoly;

showsl_monom_list ::
  forall a. (Linorder a, Showl a) => [(a, Nat)] -> String -> String;
showsl_monom_list [(x, p)] =
  (if equal_nat p one_nat then showsl_lit "x" . showsl x
    else ((showsl_lit "x" . showsl x) . showsl_lit "^") . showsl_nat p);
showsl_monom_list ((x, p) : v : va) =
  ((if equal_nat p one_nat then showsl_lit "x" . showsl x
     else ((showsl_lit "x" . showsl x) . showsl_literal "^") . showsl_nat p) .
    showsl_literal "*") .
    showsl_monom_list (v : va);
showsl_monom_list [] = showsl_literal "1";

showsl_monom :: forall a. (Linorder a, Showl a) => Monom a -> String -> String;
showsl_monom xa = showsl_monom_list (rep_monom xa);

showsl_poly ::
  forall a b.
    (Eq a, Linorder a, Showl a, One b, Eq b,
      Showl b) => [(Monom a, b)] -> String -> String;
showsl_poly [] = showsl_lit "0";
showsl_poly ((m, c) : p) =
  (if c == one then showsl_monom m
    else (if m == one_monom then showsl c
           else (showsl c . showsl_lit "*") . showsl_monom m)) .
    (if null p then id else showsl_lit " + " . showsl_poly p);

showsl_IA_exp ::
  forall a. (Eq a, Linorder a, Showl a) => Term Sig (a, Ty) -> String -> String;
showsl_IA_exp (Fun LessF [s, t]) =
  (showsl_IA_exp s . showsl_lit " < ") . showsl_IA_exp t;
showsl_IA_exp (Fun LeF [s, t]) =
  (showsl_IA_exp s . showsl_lit " <= ") . showsl_IA_exp t;
showsl_IA_exp (Fun EqF [s, t]) =
  (showsl_IA_exp s . showsl_lit " = ") . showsl_IA_exp t;
showsl_IA_exp (Var v) = showsl_poly (iA_exp_to_poly (Var v));
showsl_IA_exp (Fun LeF []) =
  (showsl_poly :: [(Monom a, Int)] -> String -> String)
    ((iA_exp_to_poly :: Term Sig (a, Ty) -> [(Monom a, Int)]) (Fun LeF []));
showsl_IA_exp (Fun LeF [v]) = showsl_poly (iA_exp_to_poly (Fun LeF [v]));
showsl_IA_exp (Fun LeF (v : vc : ve : vf)) =
  showsl_poly (iA_exp_to_poly (Fun LeF (v : vc : ve : vf)));
showsl_IA_exp (Fun (SumF vb) va) =
  showsl_poly (iA_exp_to_poly (Fun (SumF vb) va));
showsl_IA_exp (Fun (ConstF vb) va) =
  showsl_poly (iA_exp_to_poly (Fun (ConstF vb) va));
showsl_IA_exp (Fun (ProdF vb) va) =
  showsl_poly (iA_exp_to_poly (Fun (ProdF vb) va));
showsl_IA_exp (Fun EqF []) =
  (showsl_poly :: [(Monom a, Int)] -> String -> String)
    ((iA_exp_to_poly :: Term Sig (a, Ty) -> [(Monom a, Int)]) (Fun EqF []));
showsl_IA_exp (Fun EqF [v]) = showsl_poly (iA_exp_to_poly (Fun EqF [v]));
showsl_IA_exp (Fun EqF (v : vc : ve : vf)) =
  showsl_poly (iA_exp_to_poly (Fun EqF (v : vc : ve : vf)));
showsl_IA_exp (Fun v []) =
  (showsl_poly :: [(Monom a, Int)] -> String -> String)
    ((iA_exp_to_poly :: Term Sig (a, Ty) -> [(Monom a, Int)]) (Fun v []));
showsl_IA_exp (Fun v [vb]) = showsl_poly (iA_exp_to_poly (Fun v [vb]));
showsl_IA_exp (Fun v (vb : vd : vf : vg)) =
  showsl_poly (iA_exp_to_poly (Fun v (vb : vd : vf : vg)));

lit_normalize ::
  forall a. Bool -> Term Sig (a, Ty) -> Formula (Term Sig (a, Ty));
lit_normalize False e = NegAtom e;
lit_normalize True (Fun LessF [a, b]) = NegAtom (Fun LeF [b, a]);
lit_normalize True (Fun LeF [a, b]) = NegAtom (Fun LessF [b, a]);
lit_normalize True (Fun EqF [a, b]) =
  Conjunction [NegAtom (Fun LessF [a, b]), NegAtom (Fun LessF [b, a])];
lit_normalize True (Var x) = Atom (Var x);

poly_minus ::
  forall a b.
    (Eq a, Linorder a, Eq b,
      Ring_1 b) => [(Monom a, b)] -> [(Monom a, b)] -> [(Monom a, b)];
poly_minus f g = poly_add f (monom_mult_poly (one_monom, uminus one) g);

iA_exp_to_poly_constraint ::
  forall a. (Eq a, Linorder a) => Term Sig (a, Ty) -> Poly_constraint a;
iA_exp_to_poly_constraint (Fun LeF [a, b]) =
  Poly_Ge (poly_minus (iA_exp_to_poly b) (iA_exp_to_poly a));
iA_exp_to_poly_constraint (Fun EqF [a, b]) =
  Poly_Eq (poly_minus (iA_exp_to_poly b) (iA_exp_to_poly a));
iA_exp_to_poly_constraint (Fun LessF [a, b]) =
  Poly_Ge
    (poly_minus (poly_minus (iA_exp_to_poly b) (iA_exp_to_poly a)) one_poly);

showsl_poly_constraint ::
  forall a.
    (Eq a, Linorder a, Showl a) => Poly_constraint a -> String -> String;
showsl_poly_constraint (Poly_Ge p) = showsl_poly p . showsl_lit " >= 0";
showsl_poly_constraint (Poly_Eq p) = showsl_poly p . showsl_lit " = 0";

unsat_bool_checker :: forall a. (Eq a) => [Formula a] -> Bool;
unsat_bool_checker blits = any (\ blit -> membera blits (form_not blit)) blits;

translate_atom :: forall a. Formula a -> a;
translate_atom (Atom e) = e;

translate_atoms :: forall a. [Formula a] -> [a];
translate_atoms = map translate_atom;

split_bool_vars ::
  forall a b.
    [Formula (Term a b)] -> ([Formula (Term a b)], [Formula (Term a b)]);
split_bool_vars = partition (\ lit -> is_Var (get_Atom lit));

translate_conj ::
  forall a b. Formula (Term a b) -> ([Formula (Term a b)], [Term a b]);
translate_conj (Conjunction phi_s) =
  (case split_bool_vars phi_s of {
    (bvars, ia_lits) -> (bvars, translate_atoms ia_lits);
  });

monom_vars_list :: forall a. (Linorder a) => Monom a -> [a];
monom_vars_list xa = map fst (rep_monom xa);

poly_vars_list :: forall a b. (Eq a, Linorder a) => [(Monom a, b)] -> [a];
poly_vars_list p = remdups (concatMap (monom_vars_list . fst) p);

vars_poly_constraint_list ::
  forall a. (Eq a, Linorder a) => Poly_constraint a -> [a];
vars_poly_constraint_list (Poly_Ge p) = poly_vars_list p;
vars_poly_constraint_list (Poly_Eq p) = poly_vars_list p;

interpret_poly_constraint ::
  forall a. (Linorder a) => (a -> Int) -> Poly_constraint a -> Bool;
interpret_poly_constraint f (Poly_Ge p) = less_eq_int zero_int (eval_poly f p);
interpret_poly_constraint f (Poly_Eq p) = equal_int (eval_poly f p) zero_int;

lp_monom :: Rat -> Nat -> Linear_poly;
lp_monom c x =
  LinearPoly (if equal_rat c zero_rat then fmempty else fmupd x c fmempty);

monom_list_linearity :: forall a. [(a, Nat)] -> Linearity a;
monom_list_linearity [] = Onea;
monom_list_linearity [(x, n)] =
  (if equal_nat n one_nat then Variable x else Non_Linear);
monom_list_linearity (v : vb : vc) = Non_Linear;

monom_linearity :: forall a. (Linorder a) => Monom a -> Linearity a;
monom_linearity xa = monom_list_linearity (rep_monom xa);

ipoly_to_linear_poly ::
  forall a.
    (Linorder a) => (a -> Nat) -> [(Monom a, Int)] -> Maybe (Linear_poly, Int);
ipoly_to_linear_poly rho [] = Just (zero_linear_poly, zero_int);
ipoly_to_linear_poly rho ((monomial, c) : rest) =
  bind (ipoly_to_linear_poly rho rest)
    (\ (p, d) ->
      (case monom_linearity monomial of {
        Non_Linear -> Nothing;
        Onea -> Just (p, plus_int c d);
        Variable x ->
          Just (plus_linear_poly (lp_monom (of_int c) (rho x)) p, d);
      }));

to_linear_constraints ::
  forall a. (Linorder a) => (a -> Nat) -> Poly_constraint a -> [Constraint];
to_linear_constraints rho (Poly_Ge p) =
  (case ipoly_to_linear_poly rho p of {
    Nothing -> [];
    Just (q, c) -> [GEQ q (of_int (uminus_int c))];
  });
to_linear_constraints rho (Poly_Eq p) =
  (case ipoly_to_linear_poly rho p of {
    Nothing -> [];
    Just (q, c) -> [EQ q (of_int (uminus_int c))];
  });

unsat_via_la_solver ::
  forall a.
    (Compare_order a,
      Eq a) => La_solver_type ->
                 [Poly_constraint a] -> Maybe (Maybe ([a], a -> Int));
unsat_via_la_solver typea les =
  let {
    vs = remdups (concatMap vars_poly_constraint_list les);
    ren_map = of_alist (zip vs (upt zero_nat (size_list vs)));
    ren_fun = (\ v -> (case lookupa ren_map v of {
                        Nothing -> zero_nat;
                        Just n -> n;
                      }));
    cs = concatMap (to_linear_constraints ren_fun) les;
  } in (case la_solver typea cs of {
         Nothing -> Just Nothing;
         Just beta ->
           let {
             alpha = beta . ren_fun;
           } in (if all (interpret_poly_constraint alpha) les
                  then Just (Just (vs, alpha)) else Nothing);
       });

unsat_checker ::
  forall a.
    (Compare_order a, Eq a,
      Showl a) => La_solver_type ->
                    [Poly_constraint a] -> Sum (String -> String) ();
unsat_checker solver cnjs =
  catch_error
    (case unsat_via_la_solver solver cnjs of {
      Nothing ->
        Inl (showsl_lit
              "could not use linear arithmetic solver to prove unsatisfiability");
      Just Nothing -> Inr ();
      Just (Just (vs, alpha)) ->
        Inl (showsl_lit "the linear inequalities are satisfiable:\n" .
              showsl_list_gen
                (\ v ->
                  (showsl_monom (var_monom v) . showsl_lit " := ") .
                    showsl_int (alpha v))
                "" "" "\n" "" vs);
    })
    (\ x ->
      Inl (((((showsl_lit "The linear inequalities\n  " .
                showsl_sep showsl_poly_constraint (showsl_lit "\n  ") cnjs) .
               showsl_lit "\ncannot be proved unsatisfiable via solver\n  ") .
              showsl_la_solver_type solver) .
             showsl_literal "\n") .
            x));

check_clause ::
  forall a.
    (Compare_order a, Eq a,
      Showl a) => La_solver_type ->
                    Formula (Term Sig (a, Ty)) -> Sum (String -> String) ();
check_clause typea phi =
  (case translate_conj (form_not phi) of {
    (bvars, ia_lits) ->
      let {
        es = map iA_exp_to_poly_constraint ia_lits;
      } in (if unsat_bool_checker bvars then Inr ()
             else catch_error (unsat_checker typea es)
                    (\ x ->
                      Inl (((showsl_lit
                               "Could not prove unsatisfiability of IA conjunction\n" .
                              showsl_list_gen showsl_poly_constraint "False" ""
                                " && " "" es) .
                             showsl_literal "\n") .
                            x)));
  });

divisor_value :: forall a. Term Ia4_sig a -> Int;
divisor_value e = to_int (eval i e (\ _ -> Int zero_int));

lower_exp :: forall a. Term Ia4_sig (a, Ty) -> Term Sig (Ia4_variable a, Ty);
lower_exp (Var (v, ty)) = Var (IA4_Old v, ty);
lower_exp (Fun (IA4_Base f) es) = Fun f (map lower_exp es);
lower_exp (Fun IA4_Div [a, d]) = Var (IA4_Quot (Fun IA4_Div [a, d]), IntT);
lower_exp (Fun IA4_Mod [a, d]) = Var (IA4_Rem (Fun IA4_Div [a, d]), IntT);
lower_exp (Fun IA4_Div []) = Fun (ConstF zero_int) [];
lower_exp (Fun IA4_Div [v]) = Fun (ConstF zero_int) [];
lower_exp (Fun IA4_Div (v : vc : ve : vf)) = Fun (ConstF zero_int) [];
lower_exp (Fun IA4_Mod []) = Fun (ConstF zero_int) [];
lower_exp (Fun IA4_Mod [v]) = Fun (ConstF zero_int) [];
lower_exp (Fun IA4_Mod (v : vc : ve : vf)) = Fun (ConstF zero_int) [];

qr_constraints ::
  forall a b.
    Term Ia4_sig (a, Ty) ->
      Term Ia4_sig (a, Ty) ->
        Term Ia4_sig b -> [Formula (Term Sig (Ia4_variable a, Ty))];
qr_constraints e a d =
  [Atom (Fun EqF
          [lower_exp a,
            Fun (SumF (nat_of_integer (2 :: Integer)))
              [Fun (ProdF (nat_of_integer (2 :: Integer)))
                 [Fun (ConstF (divisor_value d)) [], Var (IA4_Quot e, IntT)],
                Var (IA4_Rem e, IntT)]]),
    Atom (Fun LeF [Fun (ConstF zero_int) [], Var (IA4_Rem e, IntT)]),
    Atom (Fun LessF
           [Var (IA4_Rem e, IntT),
             Fun (ConstF (abs_int (divisor_value d))) []])];

constraints ::
  forall a. Term Ia4_sig (a, Ty) -> [Formula (Term Sig (Ia4_variable a, Ty))];
constraints (Var uu) = [];
constraints (Fun (IA4_Base uv) es) = concatMap constraints es;
constraints (Fun IA4_Div [a, d]) =
  constraints a ++ constraints d ++ qr_constraints (Fun IA4_Div [a, d]) a d;
constraints (Fun IA4_Mod [a, d]) =
  constraints a ++ constraints d ++ qr_constraints (Fun IA4_Div [a, d]) a d;
constraints (Fun IA4_Div []) = [];
constraints (Fun IA4_Div [v]) = [];
constraints (Fun IA4_Div (v : vc : ve : vf)) = [];
constraints (Fun IA4_Mod []) = [];
constraints (Fun IA4_Mod [v]) = [];
constraints (Fun IA4_Mod (v : vc : ve : vf)) = [];

formula_constraints ::
  forall a.
    Formula (Term Ia4_sig (a, Ty)) -> [Formula (Term Sig (Ia4_variable a, Ty))];
formula_constraints (Atom e) = constraints e;
formula_constraints (NegAtom e) = constraints e;
formula_constraints (Conjunction fs) = concatMap formula_constraints fs;
formula_constraints (Disjunction fs) = concatMap formula_constraints fs;

lower_formula ::
  forall a.
    Formula (Term Ia4_sig (a, Ty)) -> Formula (Term Sig (Ia4_variable a, Ty));
lower_formula f = map_formula lower_exp f;

elimination_formula ::
  forall a.
    Formula (Term Ia4_sig (a, Ty)) -> Formula (Term Sig (Ia4_variable a, Ty));
elimination_formula f =
  Disjunction [form_not (Conjunction (formula_constraints f)), lower_formula f];

less_eq_set :: forall a. (Eq a) => Set a -> Set a -> Bool;
less_eq_set (Set xs) b = all (\ x -> member x b) xs;
less_eq_set a (Coset ys) = all (\ y -> not (member y a)) ys;
less_eq_set (Coset []) (Set []) = False;

equal_set :: forall a. (Eq a) => Set a -> Set a -> Bool;
equal_set a b = less_eq_set a b && less_eq_set b a;

supported_exp :: forall a. (Eq a) => Term Ia4_sig (a, Ty) -> Bool;
supported_exp (Var uu) = True;
supported_exp (Fun (IA4_Base uv) es) = all supported_exp es;
supported_exp (Fun IA4_Div [a, d]) =
  supported_exp a &&
    supported_exp d &&
      equal_set (vars_term d) bot_set &&
        not (equal_int (divisor_value d) zero_int);
supported_exp (Fun IA4_Mod [a, d]) =
  supported_exp a &&
    supported_exp d &&
      equal_set (vars_term d) bot_set &&
        not (equal_int (divisor_value d) zero_int);
supported_exp (Fun IA4_Div []) = False;
supported_exp (Fun IA4_Div [v]) = False;
supported_exp (Fun IA4_Div (v : vc : ve : vf)) = False;
supported_exp (Fun IA4_Mod []) = False;
supported_exp (Fun IA4_Mod [v]) = False;
supported_exp (Fun IA4_Mod (v : vc : ve : vf)) = False;

supported_formula :: forall a. (Eq a) => Formula (Term Ia4_sig (a, Ty)) -> Bool;
supported_formula (Atom e) = supported_exp e;
supported_formula (NegAtom e) = supported_exp e;
supported_formula (Conjunction fs) = all supported_formula fs;
supported_formula (Disjunction fs) = all supported_formula fs;

ia4_check_clause ::
  forall a.
    (Compare a, Eq a,
      Showl a) => La_solver_type ->
                    Formula (Term Ia4_sig (a, Ty)) -> Sum (String -> String) ();
ia4_check_clause h f =
  binda (check (supported_formula f)
          (showsl_lit "div/mod requires a nonzero constant divisor"))
    (\ _ ->
      check_valid_formula showsl_IA_exp check_clause lit_normalize h
        (elimination_formula f));

ia4_check_recurrent_cycle ::
  forall a b c.
    (Compare_order a, Eq a, Showl a, Compare_order b, Eq b,
      Eq c) => Lts_impl Ia4_sig a Ty b c ->
                 ([(a, Int)], b) ->
                   [((c, Transition_rule Ia4_sig a Ty b), ([(a, Int)], b))] ->
                     Formula (Term Ia4_sig (a, Ty)) ->
                       [((c, Transition_rule Ia4_sig a Ty b),
                          ([((a, Ty), Term Ia4_sig (a, Ty))],
                            [((a, Ty), Term Ia4_sig (a, Ty))]))] ->
                         Sum (String -> String) ();
ia4_check_recurrent_cycle p init stem region steps =
  binda (check_lts_impl type_of_fun (inserta BoolT bot_set) p)
    (\ _ ->
      binda (check
              (membera (initiala p) (snd init) && ia4_ground_state_ok p init)
              (showsl_lit "invalid recurrent initial state"))
        (\ _ ->
          binda (ia4_check_ground_seq p init stem)
            (\ head ->
              binda (check
                      (formula (is_bool type_of_fun (inserta BoolT bot_set))
                         region &&
                        satisfies (\ alpha t -> to_bool (eval i t alpha))
                          (ia4_ground_val (fst head)) region)
                      (showsl_lit
                        "stem does not reach a typed recurrent region"))
                (\ _ ->
                  binda (check
                          (not (null steps) &&
                            ia4_policy_path_valid p (snd head) steps &&
                              ia4_policy_path_end (snd head) steps == snd head)
                          (showsl_lit "invalid or empty recurrent cycle"))
                    (\ _ ->
                      let {
                        obligation =
                          Disjunction
                            [form_not region,
                              ia4_policy_path_wp p steps region];
                      } in binda (check
                                   (formula
                                     (is_bool type_of_fun
                                       (inserta BoolT bot_set))
                                     obligation)
                                   (showsl_lit
                                     "ill-typed recurrent cycle obligation"))
                             (\ _ ->
                               check_valid_formula showsl_terma ia4_check_clause
                                 (\ b e -> (if b then Atom e else NegAtom e))
                                 default_la_solver_type obligation))))));

add_vars_term :: forall a b. Term a b -> [b] -> [b];
add_vars_term (Var x) xs = x : xs;
add_vars_term (Fun uu ts) xs = foldr add_vars_term ts xs;

vars_term_list :: forall a b. Term a b -> [b];
vars_term_list t = add_vars_term t [];

in_vars_formula :: forall a b. (Eq a) => a -> Formula (Term b a) -> Bool;
in_vars_formula x (Atom a) = membera (vars_term_list a) x;
in_vars_formula x (NegAtom a) = membera (vars_term_list a) x;
in_vars_formula x (Conjunction phi_s) = any (in_vars_formula x) phi_s;
in_vars_formula x (Disjunction phi_s) = any (in_vars_formula x) phi_s;

fresh_variable_checker ::
  forall a b c d e.
    (Showl a, Eq b, Showl b, Eq c, Showl c, Showl d,
      Showl e) => (a -> ([b], b)) ->
                    Set b ->
                      (Trans_var c ->
                        b -> Formula (Term a (Trans_var c, b)) ->
                               Sum (String -> String) ()) ->
                        (Term a (Trans_var c, b) -> String -> String) ->
                          Lts_impl a c b d e ->
                            (e -> Formula (Term a (Trans_var c, b))) ->
                              c -> b -> Sum (String -> String) ();
fresh_variable_checker type_of_fun bool_types definability_checker sa2 p f x ty
  = catch_error
      (binda
        (catch_error
          (forallM
            (\ (l, fa) ->
              check (not (in_vars_formula (x, ty) fa))
                ((showsl x .
                   showsl_lit
                     " is not fresh, it occurs in location condition of ") .
                  showsl l))
            (assertion_impl p))
          (\ xa -> Inl (snd xa)))
        (\ _ ->
          catch_error
            (forallM
              (\ (tr, tau) ->
                let {
                  psi = f tr;
                } in binda (check (formula (is_bool type_of_fun bool_types) psi)
                             (showsl_lit
                               "new transition formula seems to be not well-formed"))
                       (\ _ ->
                         catch_error
                           (case tau of {
                             Transition _ _ phi ->
                               binda (definability_checker (Post x) ty psi)
                                 (\ _ ->
                                   binda (check
   (not (in_vars_formula (Post x, ty) phi))
   (showsl_lit "Post x in transition formula" . showsl_formula sa2 phi))
                                     (\ _ ->
                                       check
 (not (in_vars_formula (Pre x, ty) phi))
 (showsl_lit "Pre x in transition formula" . showsl_formula sa2 phi)));
                           })
                           (\ xa ->
                             Inl (((showsl_lit
                                      "problem in transition formula of transition " .
                                     showsl tr) .
                                    showsl_literal "\n") .
                                   xa))))
              (transitions_impl p))
            (\ xa -> Inl (snd xa))))
      (\ xa -> Inl (showsl_lit "fresh_variable_checker failed\n" . xa));

showsl_formulaa :: forall a. (Showl a) => Formula a -> String -> String;
showsl_formulaa (Atom a) = showsl a;
showsl_formulaa (NegAtom a) = (showsl_lit "! (" . showsl a) . showsl_lit ")";
showsl_formulaa (Conjunction a) =
  showsl_list_gen id "TRUE" "(" " & " ")" (map showsl_formulaa a);
showsl_formulaa (Disjunction a) =
  showsl_list_gen id "FALSE" "(" " | " ")" (map showsl_formulaa a);

refine_transition_formula ::
  forall a b c d.
    Transition_rule a b c d ->
      Formula (Term a (Trans_var b, c)) -> Transition_rule a b c d;
refine_transition_formula (Transition l r phi) psi =
  Transition l r (form_and phi psi);

refine_transition_formulas ::
  forall a b c d e.
    Lts_impl a b c d e ->
      (e -> Formula (Term a (Trans_var b, c))) -> Lts_impl a b c d e;
refine_transition_formulas p f =
  Lts_Impl (initiala p)
    (map (\ (tr, tau) -> (tr, refine_transition_formula tau (f tr)))
      (transitions_impl p))
    (assertion_impl p);

fresh_variable_addition ::
  forall a b c d e.
    (Showl a, Eq b, Showl b, Eq c, Showl c, Showl d, Compare_order e,
      Showl e) => (a -> ([b], b)) ->
                    Set b ->
                      (Trans_var c ->
                        b -> Formula (Term a (Trans_var c, b)) ->
                               Sum (String -> String) ()) ->
                        (Term a (Trans_var c, b) -> String -> String) ->
                          Lts_impl a c b d e ->
                            Fresh_variable_addition_info a c b e ->
                              Sum (String -> String) (Lts_impl a c b d e);
fresh_variable_addition type_of_fun bool_types definability_checker sa2 p
  (Fresh_Variable_Addition_Info x ty forms) =
  let {
    m = of_alist forms;
    f = lookup_default (Conjunction []) m;
  } in (case catch_error
               (binda
                 (catch_error
                   (forallM
                     (\ fa ->
                       check (formula (is_bool type_of_fun bool_types) fa)
                         (showsl_formulaa fa .
                           showsl_lit " is not a valid formula"))
                     (map snd forms))
                   (\ xa -> Inl (snd xa)))
                 (\ _ ->
                   fresh_variable_checker type_of_fun bool_types
                     definability_checker sa2 p f x ty))
               (\ xa ->
                 Inl (((showsl_lit "problem in adding fresh variable " .
                         showsl x) .
                        showsl_literal "\n") .
                       xa))
         of {
         Inl a -> Inl a;
         Inr _ -> Inr (refine_transition_formulas p f);
       });

showsl_transition ::
  forall a b c d.
    (Showl d) => (Term a (Trans_var b, c) -> String -> String) ->
                   Transition_rule a b c d -> String -> String;
showsl_transition showsl_tatom (Transition s t phi) =
  (((showsl s . showsl_lit " ---> ") . showsl t) . showsl_lit ": ") .
    showsl_formula showsl_tatom phi;

showsl_labeled_transition ::
  forall a b c d e.
    (Showl d,
      Showl e) => (Term a (Trans_var b, c) -> String -> String) ->
                    (d, Transition_rule a b c e) -> String -> String;
showsl_labeled_transition showsl_tatom (lab, tran) =
  (showsl lab . showsl_lit ": ") . showsl_transition showsl_tatom tran;

showsl_lts ::
  forall a b c d e.
    (Showl d,
      Showl e) => (Term a (b, c) -> String -> String) ->
                    (Term a (Trans_var b, c) -> String -> String) ->
                      Lts_impl a b c d e -> String -> String;
showsl_lts showsl_atom showsl_tatom (Lts_Impl i tran lc) =
  (((((showsl_lit "LTS:\nInitial locations: " . showsl_list i) .
       showsl_lit "\nTransitions\n") .
      showsl_sep (showsl_labeled_transition showsl_tatom) (showsl_literal "\n")
        tran) .
     showsl_lit "\nLocation conditions") .
    showsl_sep
      (\ (l, f) -> (showsl l . showsl_lit ": ") . showsl_formula showsl_atom f)
      (showsl_literal "\n") lc) .
    showsl_literal "\n";

is_sharp :: forall a. Sharp a -> Bool;
is_sharp (Flat uu) = False;
is_sharp (Sharp uv) = True;

trivial_termination_checker ::
  forall a b c d e.
    (Showl d,
      Showl e) => (Term a (b, c) -> String -> String) ->
                    (Term a (Trans_var b, c) -> String -> String) ->
                      Lts_impl a b c (Sharp d) e -> Sum (String -> String) ();
trivial_termination_checker showsl_atom showsl_tatom p =
  check (null (filter (\ tau -> is_sharp (source tau))
                (map snd (transitions_impl p))))
    (showsl_lit "there are remaining sharp transitions in " .
      showsl_lts showsl_atom showsl_tatom p);

transition_hintsa :: forall a b c d e. Hinter_ext a b c d e -> c -> Maybe [a];
transition_hintsa
  (Hinter_ext nodes succ_trans_list cover_hints transition_hints more) =
  transition_hints;

node_invariant ::
  forall a b c d e f. Art_ext a b c d e f -> e -> Formula (Term a (b, c));
node_invariant
  (Art_ext initial_nodes nodes edge node_location node_invariant more) =
  node_invariant;

rename_vars_exp :: forall a b c d. (a -> b) -> Term c (a, d) -> Term c (b, d);
rename_vars_exp r = map_term id (map_prod r id);

nodesa :: forall a b c d e. Hinter_ext a b c d e -> [c];
nodesa (Hinter_ext nodes succ_trans_list cover_hints transition_hints more) =
  nodes;

edge :: forall a b c d e f. Art_ext a b c d e f -> e -> Art_edge a b c d e;
edge (Art_ext initial_nodes nodes edge node_location node_invariant more) =
  edge;

check_children_edges_cond ::
  forall a b c d e f g h i j k.
    (Default a, Showl a, Eq b, Showl b, Eq c, Showl c, Eq d, Showl d, Showl e,
      Showl f) => (a -> Formula (Term b (Trans_var c, d)) ->
                          Sum (String -> String) ()) ->
                    (Term b (Trans_var c, d) -> String -> String) ->
                      (Bool ->
                        Term b (Trans_var c, d) ->
                          Formula (Term b (Trans_var c, d))) ->
                        Art_ext b c d e f g ->
                          Lts_ext b c d e h ->
                            Hinter_ext a i f j k -> Sum (String -> String) ();
check_children_edges_cond tc2 sa2 ne2 a p h =
  let {
    lc = assertion p;
  } in catch_error
         (catch_error
           (forallM
             (\ aa ->
               (case edge a aa of {
                 Cover _ -> Inr ();
                 Children children ->
                   (case transition_hintsa h aa of {
                     Nothing -> Inl (showsl_lit "not yet");
                     Just hints ->
                       catch_error
                         (binda
                           (check
                             (equal_nat (size_list hints) (size_list children))
                             (showsl_lit
                               "the number of hints differs from the number of children"))
                           (\ _ ->
                             catch_error
                               (forallM
                                 (\ (b, c) ->
                                   (case b of {
                                     (tau, ba) ->
                                       (\ ha ->
 (case tau of {
   Transition l _ phi ->
     catch_error
       (check_valid_formula sa2 tc2 ne2 ha
         (Disjunction
           [map_formula (rename_vars_exp Post) (node_invariant a ba),
             form_not (map_formula (rename_vars_exp Pre) (node_invariant a aa)),
             form_not (map_formula (rename_vars_exp Pre) (lc l)),
             form_not phi]))
       (\ x ->
         Inl (((((((showsl_lit "problem in checking edge " . showsl aa) .
                    showsl_lit " --> ") .
                   showsl ba) .
                  showsl_lit " for transition\n") .
                 showsl_transition sa2 tau) .
                showsl_literal "\n") .
               x));
 }));
                                   })
                                     c)
                                 (zip children hints))
                               (\ x -> Inl (snd x))))
                         (\ x ->
                           Inl (((showsl_lit
                                    "problem in checking transitions of node " .
                                   showsl aa) .
                                  showsl_literal "\n") .
                                 x));
                   });
               }))
             (nodesa h))
           (\ x -> Inl (snd x)))
         (\ x ->
           Inl (showsl_lit
                  "could not ensure transition edge condition of ART\n" .
                 x));

is_cover_nodea :: forall a b c d e. Art_edge a b c d e -> Bool;
is_cover_nodea (Cover x1) = True;
is_cover_nodea (Children x2) = False;

cover_hintsa :: forall a b c d e. Hinter_ext a b c d e -> c -> a;
cover_hintsa
  (Hinter_ext nodes succ_trans_list cover_hints transition_hints more) =
  cover_hints;

node_location :: forall a b c d e f. Art_ext a b c d e f -> e -> d;
node_location
  (Art_ext initial_nodes nodes edge node_location node_invariant more) =
  node_location;

nodes :: forall a b c d e f. Art_ext a b c d e f -> [e];
nodes (Art_ext initial_nodes nodes edge node_location node_invariant more) =
  nodes;

check_cover_edges_cond ::
  forall a b c d e f g h i j k l m n o.
    (Default a, Showl a, Eq b, Showl b, Eq c, Showl c, Eq d, Showl d, Eq e,
      Eq f,
      Showl f) => (a -> Formula (Term b (c, d)) -> Sum (String -> String) ()) ->
                    (Term b (c, d) -> String -> String) ->
                      (Bool -> Term b (c, d) -> Formula (Term b (c, d))) ->
                        Art_ext b c d e f g ->
                          Lts_ext h i j k l ->
                            Hinter_ext a m f n o -> Sum (String -> String) ();
check_cover_edges_cond tc sa ne a p h =
  let {
    _ = assertion p;
  } in catch_error
         (catch_error
           (forallM
             (\ aa ->
               (case edge a aa of {
                 Cover b ->
                   catch_error
                     (binda
                       (check (membera (nodes a) b)
                         (showsl_lit "target node is not listed as art-node"))
                       (\ _ ->
                         binda (check (node_location a aa == node_location a b)
                                 (showsl_lit "node-locations differ"))
                           (\ _ ->
                             binda (check (not (is_cover_nodea (edge a b)))
                                     (showsl_lit
                                       "target node must not have cover edge"))
                               (\ _ ->
                                 check_valid_formula sa tc ne
                                   (cover_hintsa h aa)
                                   (Disjunction
                                     [node_invariant a b,
                                       form_not (node_invariant a aa)])))))
                     (\ x ->
                       Inl (((showsl_lit
                                "problem in checking cover edge of node " .
                               showsl aa) .
                              showsl_literal "\n") .
                             x));
                 Children _ -> Inr ();
               }))
             (nodesa h))
           (\ x -> Inl (snd x)))
         (\ x ->
           Inl (showsl_lit "could not ensure cover edge condition of ART\n" .
                 x));

succ_trans_list :: forall a b c d e. Hinter_ext a b c d e -> b -> [d];
succ_trans_list
  (Hinter_ext nodes succ_trans_list cover_hints transition_hints more) =
  succ_trans_list;

initial_nodes :: forall a b c d e f. Art_ext a b c d e f -> [e];
initial_nodes
  (Art_ext initial_nodes nodes edge node_location node_invariant more) =
  initial_nodes;

check_simulation_cond ::
  forall a b c d e f g h i j k l m.
    (Default a, Showl a, Eq b, Showl b, Eq c, Showl c, Eq d, Showl d, Eq e,
      Showl e, Eq f,
      Showl f) => (a -> Formula (Term b (c, d)) -> Sum (String -> String) ()) ->
                    (Term b (c, d) -> String -> String) ->
                      (Bool -> Term b (c, d) -> Formula (Term b (c, d))) ->
                        Art_ext b c d e f g ->
                          Lts_ext h i j e k ->
                            Hinter_ext l e f (Transition_rule b c d e) m ->
                              Sum (String -> String) ();
check_simulation_cond tc sa ne a p h =
  catch_error
    (binda
      (check
        (less_eq_set (initial p)
          (Set (map (node_location a) (initial_nodes a))))
        (showsl_lit
          "not all initial nodes of LTS are represented by initial nodes in ART"))
      (\ _ ->
        catch_error
          (forallM
            (\ aa ->
              (case edge a aa of {
                Cover _ -> Inr ();
                Children children ->
                  let {
                    l = node_location a aa;
                  } in catch_error
                         (catch_error
                           (forallM
                             (\ tau ->
                               check (any (\ (taua, b) ->
    equal_transition_rule taua tau &&
      node_location a b == target tau && membera (nodes a) b)
                                       children)
                                 (((((showsl_lit
"could not find matching transition in ART for node " .
                                       showsl aa) .
                                      showsl_lit " and transition ") .
                                     showsl (source tau)) .
                                    showsl_lit " --> ") .
                                   showsl (target tau)))
                             (succ_trans_list h l))
                           (\ x -> Inl (snd x)))
                         (\ e1 ->
                           catch_error
                             (check_valid_formula sa tc ne defaulta
                               (form_not (node_invariant a aa)))
                             (\ _ ->
                               Inl (e1 . showsl_lit
   "\nand could not prove unsatisfiability of the node invariant")));
              }))
            (nodesa h))
          (\ x -> Inl (snd x))))
    (\ x ->
      Inl (showsl_lit "could not ensure simulation condition of ART\n" . x));

check_initial_cond ::
  forall a b c d e f.
    (Eq a, Showl a, Eq b, Showl b, Eq c, Showl c, Eq e,
      Showl e) => (Term a (b, c) -> String -> String) ->
                    Art_ext a b c d e f -> Sum (String -> String) ();
check_initial_cond sa a =
  catch_error
    (forallM
      (\ init ->
        binda (check (membera (nodes a) init)
                ((showsl_lit "initial node of A (" . showsl init) .
                  showsl_lit ") is not mentioned as node of ART"))
          (\ _ ->
            check (equal_formula (node_invariant a init) (Conjunction []))
              (((showsl_lit "the node invariant for the initial ART node (" .
                  showsl init) .
                 showsl_lit ") must be TRUE,  but it is ") .
                showsl_formula sa (node_invariant a init))))
      (initial_nodes a))
    (\ x -> Inl (snd x));

art ::
  forall a b c d e f.
    (Showl a, Eq b,
      Showl b) => (a -> ([b], b)) -> Set b -> Art_ext a c b d e f -> Bool;
art type_of_fun bool_types a =
  all (\ aa -> formula (is_bool type_of_fun bool_types) (node_invariant a aa))
    (nodes a);

check_art ::
  forall a b c d e f.
    (Showl a, Eq b,
      Showl b) => (a -> ([b], b)) ->
                    Set b -> Art_ext a c b d e f -> Sum (String -> String) ();
check_art type_of_fun bool_types a =
  check (art type_of_fun bool_types a) (showsl_lit "ill-formed invariant");

check_art_invariants ::
  forall a b c d e f g h i.
    (Eq a, Showl a, Eq b, Showl b, Default c, Showl c, Eq d, Showl d, Eq e,
      Showl e, Eq f,
      Showl f) => (a -> ([b], b)) ->
                    Set b ->
                      (c -> Formula (Term a (d, b)) ->
                              Sum (String -> String) ()) ->
                        (c -> Formula (Term a (Trans_var d, b)) ->
                                Sum (String -> String) ()) ->
                          (Term a (d, b) -> String -> String) ->
                            (Term a (Trans_var d, b) -> String -> String) ->
                              (Bool ->
                                Term a (d, b) -> Formula (Term a (d, b))) ->
                                (Bool ->
                                  Term a (Trans_var d, b) ->
                                    Formula (Term a (Trans_var d, b))) ->
                                  Art_ext a d b e f g ->
                                    Lts_ext a d b e h ->
                                      Hinter_ext c e f (Transition_rule a d b e)
i ->
Sum (String -> String) ();
check_art_invariants type_of_fun bool_types tc tc2 sa sa2 ne ne2 a p h =
  catch_error
    (binda (check_art type_of_fun bool_types a)
      (\ _ ->
        binda (check_initial_cond sa a)
          (\ _ ->
            binda (check_simulation_cond tc sa ne a p h)
              (\ _ ->
                binda (check_cover_edges_cond tc sa ne a p h)
                  (\ _ -> check_children_edges_cond tc2 sa2 ne2 a p h)))))
    (\ x -> Inl (showsl_lit "could not ensure validity of art-graph:\n" . x));

name :: forall a b c d e f g. Art_node_impl a b c d e f g -> e;
name (Art_Node x1 x2 x3 x4) = x1;

edgea ::
  forall a b c d e f g. Art_node_impl a b c d e f g -> Art_edge_impl e f g;
edgea (Art_Node x1 x2 x3 x4) = x4;

nodesb ::
  forall a b c d e f g h.
    Art_impl_ext a b c d e f g h -> [Art_node_impl a b c d e f g];
nodesb (Art_impl_ext initial_nodes nodes more) = nodes;

is_cover_node :: forall a b c d e f g. Art_node_impl a b c d e f g -> Bool;
is_cover_node (Art_Node uu uv uw (Cover_Edge ux uy)) = True;
is_cover_node (Art_Node uz va vb (Children_Edge vc)) = False;

transition_hints ::
  forall a b c d e f g.
    (Eq e) => Art_impl_ext a b c d e f g () -> e -> Maybe [g];
transition_hints ai =
  map_of
    (map_filter
      (\ x ->
        (if not (is_cover_node x)
          then Just (name x, (case edgea x of {
                               Children_Edge a -> map (\ (_, (_, h)) -> h) a;
                             }))
          else Nothing))
      (nodesb ai));

cover_hints ::
  forall a b c d e f g.
    (Compare_order e, Default g) => Art_impl_ext a b c d e f g () -> e -> g;
cover_hints ai =
  map_of_default defaulta
    (map_filter
      (\ x ->
        (if is_cover_node x then Just (name x, (case edgea x of {
         Cover_Edge _ h -> h;
       }))
          else Nothing))
      (nodesb ai));

art_nodes :: forall a b c d e f g. Art_impl_ext a b c d e f g () -> [e];
art_nodes ai = map name (nodesb ai);

make_hinter ::
  forall a b c d e f g h i j k l.
    (Eq d, Compare_order j, Eq j,
      Default l) => Lts_impl a b c d e ->
                      Art_impl_ext f g h i j k l () ->
                        Hinter_ext l d j (Transition_rule a b c d) ();
make_hinter pi ai =
  Hinter_ext (art_nodes ai) (succ_transitions pi) (cover_hints ai)
    (transition_hints ai) ();

invariant ::
  forall a b c d e f g. Art_node_impl a b c d e f g -> Formula (Term a (b, c));
invariant (Art_Node x1 x2 x3 x4) = x2;

location :: forall a b c d e f g. Art_node_impl a b c d e f g -> d;
location (Art_Node x1 x2 x3 x4) = x3;

initial_nodesa :: forall a b c d e f g h. Art_impl_ext a b c d e f g h -> [e];
initial_nodesa (Art_impl_ext initial_nodes nodes more) = initial_nodes;

art_edge_of ::
  forall a b c d e f g.
    (Compare_order e,
      Showl e) => Lts_impl a b c d e ->
                    Art_edge_impl f e g -> Art_edge a b c d f;
art_edge_of pi (Cover_Edge an uu) = Cover an;
art_edge_of pi (Children_Edge ans) =
  Children (map (\ (t, (a, _)) -> (transition_of pi t, a)) ans);

art_of ::
  forall a b c d e f g.
    (Compare_order e, Showl e, Compare_order f,
      Showl f) => Lts_impl a b c d e ->
                    Art_impl_ext a b c d f e g () -> Art_ext a b c d f ();
art_of pi ai =
  let {
    ans = nodesb ai;
  } in Art_ext (initial_nodesa ai) (art_nodes ai)
         (map_of_total
           (\ a -> showsl_lit "error in looking up art edge " . showsl a)
           (map (\ a -> (name a, art_edge_of pi (edgea a))) ans))
         (map_of_total
           (\ a -> showsl_lit "error in looking up node location " . showsl a)
           (map (\ a -> (name a, location a)) ans))
         (map_of_total
           (\ a -> showsl_lit "error in looking up node invariant " . showsl a)
           (map (\ a -> (name a, invariant a)) ans))
         ();

check_art_invariants_impl ::
  forall a b c d e f g.
    (Eq a, Showl a, Eq b, Showl b, Default c, Showl c, Eq d, Showl d,
      Compare_order e, Eq e, Showl e, Compare_order f, Eq f, Showl f,
      Compare_order g,
      Showl g) => (a -> ([b], b)) ->
                    Set b ->
                      (c -> Formula (Term a (d, b)) ->
                              Sum (String -> String) ()) ->
                        (c -> Formula (Term a (Trans_var d, b)) ->
                                Sum (String -> String) ()) ->
                          (Term a (d, b) -> String -> String) ->
                            (Term a (Trans_var d, b) -> String -> String) ->
                              (Bool ->
                                Term a (d, b) -> Formula (Term a (d, b))) ->
                                (Bool ->
                                  Term a (Trans_var d, b) ->
                                    Formula (Term a (Trans_var d, b))) ->
                                  Art_impl_ext a d b e f g c () ->
                                    Lts_impl a d b e g ->
                                      Sum (String -> String) ();
check_art_invariants_impl type_of_fun bool_types tc tc2 sa sa2 ne ne2 ai pi =
  check_art_invariants type_of_fun bool_types tc tc2 sa sa2 ne ne2
    (art_of pi ai) (lts_of pi) (make_hinter pi ai);

check_unique_names ::
  forall a b c d e f g h.
    (Eq e) => Art_impl_ext a b c d e f g h -> Sum (String -> String) ();
check_unique_names ai =
  check (distinct (map name (nodesb ai)))
    (showsl_lit "Nodes in art graph must have unique names");

restrict_invariants ::
  forall a b c d.
    (Eq a) => (a -> Formula (Term b (c, d))) ->
                Set a -> a -> Formula (Term b (c, d));
restrict_invariants i la l = (if member l la then i l else Conjunction []);

get_disj_invariant ::
  forall a b c d e.
    (Eq d) => Art_ext a b c d e () -> d -> Formula (Term a (b, c));
get_disj_invariant a l =
  Disjunction
    (map_filter
      (\ x ->
        (if node_location a x == l && not (is_cover_nodea (edge a x))
          then Just (node_invariant a x) else Nothing))
      (nodes a));

get_disjunctions :: forall a. Formula a -> [Formula a];
get_disjunctions (Disjunction phis) = concatMap get_disjunctions phis;
get_disjunctions (Atom v) = [Atom v];
get_disjunctions (NegAtom v) = [NegAtom v];
get_disjunctions (Conjunction v) = [Conjunction v];

get_conjunctions :: forall a. Formula a -> [Formula a];
get_conjunctions (Conjunction phis) = concatMap get_conjunctions phis;
get_conjunctions (Atom v) = [Atom v];
get_conjunctions (NegAtom v) = [NegAtom v];
get_conjunctions (Disjunction v) = [Disjunction v];

check_trivial_implication :: forall a. (Eq a) => Formula a -> Formula a -> Bool;
check_trivial_implication phi psi =
  all (\ phia ->
        let {
          c_phis = get_conjunctions phia;
        } in any (\ psia -> all (membera c_phis) (get_conjunctions psia))
               (get_disjunctions psi))
    (get_disjunctions phi);

showsl_art_node ::
  forall a b c d e f g.
    (Showl d, Showl e,
      Showl f) => Art_node_impl a b c d e f g -> String -> String;
showsl_art_node (Art_Node n uu l (Cover_Edge m uv)) =
  (((showsl n . showsl_lit "(@ ") . showsl l) . showsl_lit "): covered by ") .
    showsl m;
showsl_art_node (Art_Node n uw l (Children_Edge ls)) =
  (((showsl n . showsl_lit "(@ ") . showsl l) . showsl_lit "): goes to ") .
    default_showsl_list
      (\ (tr, (na, _)) ->
        ((showsl_lit "-" . showsl tr) . showsl_lit "->") . showsl na)
      ls;

showsl_art ::
  forall a b c d e f g.
    (Showl d, Showl e,
      Showl f) => Art_impl_ext a b c d e f g () -> String -> String;
showsl_art a =
  (((showsl_lit "ART:\nInitial node: " . showsl_list (initial_nodesa a)) .
     showsl_lit "\nArcs\n") .
    showsl_sep showsl_art_node (showsl_literal "\n") (nodesb a)) .
    showsl_literal "\n";

debug :: forall a. (String -> String) -> String -> a -> a;
debug i t x = x;

invariant_proof_checker ::
  forall a b c d e f g.
    (Eq a, Showl a, Eq b, Showl b, Default c, Showl c, Eq d, Showl d,
      Compare_order e, Eq e, Showl e, Compare_order f, Showl f, Compare_order g,
      Eq g,
      Showl g) => (a -> ([b], b)) ->
                    Set b ->
                      (c -> Formula (Term a (d, b)) ->
                              Sum (String -> String) ()) ->
                        (c -> Formula (Term a (Trans_var d, b)) ->
                                Sum (String -> String) ()) ->
                          (Term a (d, b) -> String -> String) ->
                            (Term a (Trans_var d, b) -> String -> String) ->
                              (Bool ->
                                Term a (d, b) -> Formula (Term a (d, b))) ->
                                (Bool ->
                                  Term a (Trans_var d, b) ->
                                    Formula (Term a (Trans_var d, b))) ->
                                  Lts_impl a d b e f ->
                                    Invariant_proof a d b e g f c ->
                                      Sum (String -> String)
(e -> Formula (Term a (d, b)));
invariant_proof_checker type_of_fun bool_types tc tc2 sa sa2 ne ne2 pi
  (Impact ii ai) =
  debug id "invariant checking: Impact"
    (let {
       i = map_of_default (Conjunction []) ii;
     } in (case catch_error
                  (binda (check_unique_names ai)
                    (\ _ ->
                      binda (debug id
                              "provided invariants against deduced invariants from ART graph"
                              (catch_error
                                (forallM
                                  (\ l ->
                                    let {
                                      il = i l;
                                    } in binda
   (check (formula (is_bool type_of_fun bool_types) il)
     (showsl_lit "ill-formed formula for location " . showsl l))
   (\ _ ->
     check (check_trivial_implication (get_disj_invariant (art_of pi ai) l) il)
       (showsl_lit
          "could not match provided invariant with invariant extracted from art-graph at location " .
         showsl l)))
                                  (nodes_lts_impl pi))
                                (\ x -> Inl (snd x))))
                        (\ _ ->
                          debug id "checking ART graph"
                            (check_art_invariants_impl type_of_fun bool_types tc
                              tc2 sa sa2 ne ne2 ai pi))))
                  (\ x ->
                    Inl ((((showsl_lit "problem in ensuring invariants for " .
                             showsl_lts sa sa2 pi) .
                            showsl_lit "\nvia ") .
                           showsl_art ai) .
                          x))
            of {
            Inl a -> Inl a;
            Inr _ -> Inr (restrict_invariants i (Set (nodes_lts_impl pi)));
          }));

lex_less_formula ::
  forall a b c.
    (Showl a, Showl b,
      Showl c) => (Term a (Trans_var b, c) ->
                    Term a (Trans_var b, c) ->
                      Formula (Term a (Trans_var b, c))) ->
                    (Term a (Trans_var b, c) ->
                      Term a (Trans_var b, c) ->
                        Formula (Term a (Trans_var b, c))) ->
                      [Term a (Trans_var b, c)] ->
                        [Term a (Trans_var b, c)] ->
                          [Term a (Trans_var b, c)] ->
                            Formula (Term a (Trans_var b, c));
lex_less_formula less_eq_formula less_formula xs ys zs =
  (case xs of {
    [] -> Disjunction [];
    x : xsa ->
      (case ys of {
        [] -> Disjunction [];
        y : ysa ->
          (case zs of {
            [] -> Disjunction [];
            z : zsa ->
              (case xsa of {
                [] -> (case ysa of {
                        [] -> (case zsa of {
                                [] -> form_and (less_formula y z)
(less_eq_formula x z);
                                _ : _ -> Disjunction [];
                              });
                        _ : _ -> Disjunction [];
                      });
                _ : _ ->
                  (case ysa of {
                    [] -> Disjunction [];
                    _ : _ ->
                      (case zsa of {
                        [] -> Disjunction [];
                        _ : _ ->
                          form_or
                            (form_and (less_formula y z) (less_eq_formula x z))
                            (Conjunction
                              [less_eq_formula y z,
                                lex_less_formula less_eq_formula less_formula
                                  xsa ysa zsa]);
                      });
                  });
              });
          });
      });
  });

bound_exp :: forall a b c d e. Transition_removal_info a b c d e -> a;
bound_exp (Transition_removal_info x1 x2 x3 x4 x5) = x4;

hinter :: forall a b c d e. Transition_removal_info a b c d e -> d -> e;
hinter (Transition_removal_info x1 x2 x3 x4 x5) = x5;

rank :: forall a b c d e. Transition_removal_info a b c d e -> Sharp c -> a;
rank (Transition_removal_info x1 x2 x3 x4 x5) = x1;

check_lex_strict ::
  forall a b c d e f.
    (Eq a, Showl a, Eq b, Showl b, Eq c, Showl c, Default d, Showl d, Compare e,
      Showl e,
      Showl f) => (a -> ([b], b)) ->
                    Set b ->
                      (Term a (Trans_var c, b) -> String -> String) ->
                        (d -> Formula (Term a (Trans_var c, b)) ->
                                Sum (String -> String) ()) ->
                          (Bool ->
                            Term a (Trans_var c, b) ->
                              Formula (Term a (Trans_var c, b))) ->
                            (Term a (Trans_var c, b) ->
                              Term a (Trans_var c, b) ->
                                Formula (Term a (Trans_var c, b))) ->
                              (Term a (Trans_var c, b) ->
                                Term a (Trans_var c, b) ->
                                  Formula (Term a (Trans_var c, b))) ->
                                Transition_removal_info [Term a (c, b)] b e f
                                  d ->
                                  Lts_impl a c b (Sharp e) f ->
                                    (f, Transition_rule a c b (Sharp e)) ->
                                      Sum (String -> String) ();
check_lex_strict type_of_fun bool_types showsl_atom logic_checker normalize_lit
  less_eq_formula less_formula info pi (tr, Transition l r phi) =
  let {
    psi = lex_less_formula less_eq_formula less_formula
            (map (rename_vars_exp Pre) (bound_exp info))
            (map (rename_vars_exp Post) (rank info r))
            (map (rename_vars_exp Pre) (rank info l));
  } in binda (check (formula (is_bool type_of_fun bool_types) psi)
               ((showsl_lit "lex-less does not encode valid formula" .
                  showsl_literal "\n") .
                 showsl_formulaa psi))
         (\ _ ->
           check_valid_formula showsl_atom logic_checker normalize_lit
             (hinter info tr)
             (Disjunction
               [psi, form_not
                       (map_formula (rename_vars_exp Pre) (assertion_of pi l)),
                 form_not phi]));

lex_leq_formula ::
  forall a b c.
    (Showl a, Showl b,
      Showl c) => (Term a (Trans_var b, c) ->
                    Term a (Trans_var b, c) ->
                      Formula (Term a (Trans_var b, c))) ->
                    (Term a (Trans_var b, c) ->
                      Term a (Trans_var b, c) ->
                        Formula (Term a (Trans_var b, c))) ->
                      [Term a (Trans_var b, c)] ->
                        [Term a (Trans_var b, c)] ->
                          [Term a (Trans_var b, c)] ->
                            Formula (Term a (Trans_var b, c));
lex_leq_formula less_eq_formula less_formula xs ys zs =
  (case xs of {
    [] -> (case ys of {
            [] -> (case zs of {
                    [] -> Conjunction [];
                    _ : _ -> Disjunction [];
                  });
            _ : _ -> Disjunction [];
          });
    x : xsa ->
      (case ys of {
        [] -> Disjunction [];
        y : ysa ->
          (case zs of {
            [] -> Disjunction [];
            z : zsa ->
              (case xsa of {
                [] -> (case ysa of {
                        [] -> (case zsa of {
                                [] -> less_eq_formula y z;
                                _ : _ -> Disjunction [];
                              });
                        _ : _ -> Disjunction [];
                      });
                _ : _ ->
                  (case ysa of {
                    [] -> Disjunction [];
                    _ : _ ->
                      (case zsa of {
                        [] -> Disjunction [];
                        _ : _ ->
                          form_or
                            (form_and (less_formula y z) (less_eq_formula x z))
                            (Conjunction
                              [less_eq_formula y z,
                                lex_leq_formula less_eq_formula less_formula xsa
                                  ysa zsa]);
                      });
                  });
              });
          });
      });
  });

check_lex_weak ::
  forall a b c d e f.
    (Eq a, Showl a, Eq b, Showl b, Eq c, Showl c, Default d, Showl d, Compare e,
      Showl e,
      Showl f) => (a -> ([b], b)) ->
                    Set b ->
                      (Term a (Trans_var c, b) -> String -> String) ->
                        (d -> Formula (Term a (Trans_var c, b)) ->
                                Sum (String -> String) ()) ->
                          (Bool ->
                            Term a (Trans_var c, b) ->
                              Formula (Term a (Trans_var c, b))) ->
                            (Term a (Trans_var c, b) ->
                              Term a (Trans_var c, b) ->
                                Formula (Term a (Trans_var c, b))) ->
                              (Term a (Trans_var c, b) ->
                                Term a (Trans_var c, b) ->
                                  Formula (Term a (Trans_var c, b))) ->
                                Transition_removal_info [Term a (c, b)] b e f
                                  d ->
                                  Lts_impl a c b (Sharp e) f ->
                                    (f, Transition_rule a c b (Sharp e)) ->
                                      Sum (String -> String) ();
check_lex_weak type_of_fun bool_types showsl_atom logic_checker normalize_lit
  less_eq_formula less_formula info pi (tr, Transition l r phi) =
  let {
    psi = lex_leq_formula less_eq_formula less_formula
            (map (rename_vars_exp Pre) (bound_exp info))
            (map (rename_vars_exp Post) (rank info r))
            (map (rename_vars_exp Pre) (rank info l));
  } in binda (check (formula (is_bool type_of_fun bool_types) psi)
               ((showsl_lit "lex-leq does not encode valid formula" .
                  showsl_literal "\n") .
                 showsl_formulaa psi))
         (\ _ ->
           check_valid_formula showsl_atom logic_checker normalize_lit
             (hinter info tr)
             (Disjunction
               [psi, form_not
                       (map_formula (rename_vars_exp Pre) (assertion_of pi l)),
                 form_not phi]));

update_transitions_impl ::
  forall a b c d e f.
    Lts_impl a b c d e -> [(f, Transition_rule a b c d)] -> Lts_impl a b c d f;
update_transitions_impl (Lts_Impl i tsa lc) ts = Lts_Impl i ts lc;

del_transitions_impl ::
  forall a b c d e. (Eq e) => Lts_impl a b c d e -> [e] -> Lts_impl a b c d e;
del_transitions_impl p td =
  update_transitions_impl p (diff_by_label (transitions_impl p) (Set td));

processor ::
  forall a b c d e.
    (Eq a,
      Showl a) => ((a, Transition_rule b c d (Sharp e)) ->
                    Sum (String -> String) ()) ->
                    ((a, Transition_rule b c d (Sharp e)) ->
                      Sum (String -> String) ()) ->
                      [a] ->
                        Lts_impl b c d (Sharp e) a ->
                          Sum (String -> String) (Lts_impl b c d (Sharp e) a);
processor check_weak check_strict td pi =
  catch_error
    (binda
      (catch_error
        (forallM
          (\ (tr, tau) ->
            (if membera td tr
              then binda (check (is_sharp (source tau))
                           ((showsl_lit "non-sharp transition " . showsl tr) .
                             showsl_lit " cannot be removed"))
                     (\ _ ->
                       catch_error (check_strict (tr, tau))
                         (\ x ->
                           Inl (((showsl_lit
                                    "Failed to strictly orient transition " .
                                   showsl tr) .
                                  showsl_literal "\n") .
                                 x)))
              else (if is_sharp (source tau)
                     then catch_error (check_weak (tr, tau))
                            (\ x ->
                              Inl (((showsl_lit
                                       "Failed to weakly orient transition " .
                                      showsl tr) .
                                     showsl_literal "\n") .
                                    x))
                     else Inr ())))
          (transitions_impl pi))
        (\ x -> Inl (snd x)))
      (\ _ -> Inr (del_transitions_impl pi td)))
    (\ x ->
      Inl (((showsl_lit "Failed to eliminate transitions " . showsl_list td) .
             showsl_lit ":\n") .
            x));

removed :: forall a b c d e. Transition_removal_info a b c d e -> [d];
removed (Transition_removal_info x1 x2 x3 x4 x5) = x2;

lex_processor ::
  forall a b c d e f.
    (Eq a, Showl a, Eq b, Showl b, Eq c, Showl c, Default d, Showl d, Compare e,
      Eq e, Showl e, Eq f,
      Showl f) => (a -> ([b], b)) ->
                    Set b ->
                      (Term a (Trans_var c, b) -> String -> String) ->
                        (d -> Formula (Term a (Trans_var c, b)) ->
                                Sum (String -> String) ()) ->
                          (Bool ->
                            Term a (Trans_var c, b) ->
                              Formula (Term a (Trans_var c, b))) ->
                            b -> (Term a (Trans_var c, b) ->
                                   Term a (Trans_var c, b) ->
                                     Formula (Term a (Trans_var c, b))) ->
                                   (Term a (Trans_var c, b) ->
                                     Term a (Trans_var c, b) ->
                                       Formula (Term a (Trans_var c, b))) ->
                                     (Term a (Trans_var c, b) -> Bool) ->
                                       Transition_removal_info [Term a (c, b)] b
 e f d ->
 Lts_impl a c b (Sharp e) f ->
   Sum (String -> String) (Lts_impl a c b (Sharp e) f);
lex_processor type_of_fun bool_types showsl_atom logic_checker normalize_lit
  dom_type less_eq_formula less_formula is_constant info pi =
  binda (catch_error
          (forallM
            (\ l ->
              catch_error
                (forallM
                  (\ e ->
                    check (has_type type_of_fun e dom_type)
                      (showsl_lit "Unexpected type of expression:\n" .
                        showsl_terma e))
                  (rank info l))
                (\ x -> Inl (snd x)))
            (nodes_lts_impl pi))
          (\ x -> Inl (snd x)))
    (\ _ ->
      binda (catch_error
              (forallM
                (\ e ->
                  check (has_type type_of_fun e dom_type)
                    (showsl_lit "Unexpected type of bound: " . showsl_terma e))
                (bound_exp info))
              (\ x -> Inl (snd x)))
        (\ _ ->
          binda (catch_error
                  (forallM
                    (\ e ->
                      check (is_constant e)
                        (showsl_lit "Non-constant bound: " . showsl_terma e))
                    (map (rename_vars_exp Pre) (bound_exp info)))
                  (\ x -> Inl (snd x)))
            (\ _ ->
              processor
                (check_lex_weak type_of_fun bool_types showsl_atom logic_checker
                  normalize_lit less_eq_formula less_formula info pi)
                (check_lex_strict type_of_fun bool_types showsl_atom
                  logic_checker normalize_lit less_eq_formula less_formula info
                  pi)
                (removed info) pi)));

check_skip_transition ::
  forall a b c d e.
    (Eq a, Eq b, Showl b, Eq c, Default d,
      Showl d) => (Term a (b, c) -> String -> String) ->
                    (d -> Formula (Term a (b, c)) ->
                            Sum (String -> String) ()) ->
                      (Bool -> Term a (b, c) -> Formula (Term a (b, c))) ->
                        Transition_rule a b c e -> Sum (String -> String) ();
check_skip_transition showsl_atom logic_checker normalize_lit tau =
  (case tau of {
    Transition _ _ phi ->
      check_valid_formula showsl_atom logic_checker normalize_lit defaulta
        (map_formula (rename_vars_exp untrans_var) phi);
  });

change_source ::
  forall a b c d. a -> Transition_rule b c d a -> Transition_rule b c d a;
change_source l (Transition src tgt phi) = Transition l tgt phi;

location_addition_outgoing ::
  forall a b c d e f.
    (Eq a, Eq b, Eq c, Showl c, Default d, Showl d, Compare e, Eq e, Showl e,
      Showl f) => (a -> ([b], b)) ->
                    Set b ->
                      (Term a (c, b) -> String -> String) ->
                        (d -> Formula (Term a (c, b)) ->
                                Sum (String -> String) ()) ->
                          (Bool -> Term a (c, b) -> Formula (Term a (c, b))) ->
                            Lts_impl a c b (Sharp e) f ->
                              Location_addition_info a c b (Sharp e) f ->
                                Sum (String -> String)
                                  (Lts_impl a c b (Sharp e) f);
location_addition_outgoing type_of_fun bool_types showsl_atom logic_checker
  normalize_lit p (Location_Addition_Info old new skip_ID skip) =
  binda (check (not (membera (nodes_lts_impl p) new))
          ((showsl_lit "location-id " . showsl_sharp new) .
            showsl_lit " is not fresh"))
    (\ _ ->
      binda (check (is_sharp new)
              ((showsl_lit "new location " . showsl_sharp new) .
                showsl_lit " must be sharp location"))
        (\ _ ->
          binda (check (is_sharp old)
                  ((showsl_lit "copied location " . showsl_sharp old) .
                    showsl_lit " must be sharp location"))
            (\ _ ->
              binda (check (transition_rule type_of_fun bool_types skip)
                      ((showsl_lit "new transition " . showsl skip_ID) .
                        showsl_lit " seems to be ill-formed"))
                (\ _ ->
                  binda (catch_error
                          (check_skip_transition showsl_atom logic_checker
                            normalize_lit skip)
                          (\ x ->
                            Inl (((showsl_lit "new transition " .
                                    showsl skip_ID) .
                                   showsl_lit " must be skip transition\n") .
                                  x)))
                    (\ _ ->
                      binda (check
                              (equal_sharp (source skip) old &&
                                equal_sharp (target skip) new)
                              (((((showsl_lit "new skip transition " .
                                    showsl skip_ID) .
                                   showsl_lit " must be from ") .
                                  showsl_sharp old) .
                                 showsl_lit " to ") .
                                showsl_sharp new))
                        (\ _ ->
                          let {
                            trans = transitions_impl p;
                          } in (case partition
                                       (\ tau -> is_sharp (source (snd tau)))
                                       trans
                                 of {
                                 (sharp, flat) ->
                                   (case partition
   (\ tau -> equal_sharp (source (snd tau)) old) sharp
                                     of {
                                     (sharp_modify, sharp_keep) ->
                                       let {
 q = Lts_Impl (initiala p)
       ((skip_ID, skip) :
         flat ++
           sharp_keep ++
             map (\ tau -> (fst tau, change_source new (snd tau))) sharp_modify)
       ((new, assertion_of p old) : assertion_impl p);
                                       } in
 binda (catch_error
         (forallM
           (\ l ->
             check (equal_formula (assertion_of p l) (assertion_of q l))
               ((showsl_lit "location condition of initial state " .
                  showsl_sharp l) .
                 showsl_lit " has been changed"))
           (initiala p))
         (\ x -> Inl (snd x)))
   (\ _ -> Inr q);
                                   });
                               })))))));

change_target ::
  forall a b c d. a -> Transition_rule b c d a -> Transition_rule b c d a;
change_target l (Transition src tgt phi) = Transition src l phi;

location_addition_incoming ::
  forall a b c d e f.
    (Eq a, Eq b, Eq c, Showl c, Default d, Showl d, Compare e, Eq e, Showl e,
      Showl f) => (a -> ([b], b)) ->
                    Set b ->
                      (Term a (c, b) -> String -> String) ->
                        (d -> Formula (Term a (c, b)) ->
                                Sum (String -> String) ()) ->
                          (Bool -> Term a (c, b) -> Formula (Term a (c, b))) ->
                            Lts_impl a c b (Sharp e) f ->
                              Location_addition_info a c b (Sharp e) f ->
                                Sum (String -> String)
                                  (Lts_impl a c b (Sharp e) f);
location_addition_incoming type_of_fun bool_types showsl_atom logic_checker
  normalize_lit p (Location_Addition_Info new old skip_ID skip) =
  binda (check (not (membera (nodes_lts_impl p) new))
          ((showsl_lit "location-id " . showsl_sharp new) .
            showsl_lit " is not fresh"))
    (\ _ ->
      binda (check (is_sharp new)
              ((showsl_lit "new location " . showsl_sharp new) .
                showsl_lit " must be sharp location"))
        (\ _ ->
          binda (check (is_sharp old)
                  ((showsl_lit "copied location " . showsl_sharp old) .
                    showsl_lit " must be sharp location"))
            (\ _ ->
              binda (check (transition_rule type_of_fun bool_types skip)
                      ((showsl_lit "new transition " . showsl skip_ID) .
                        showsl_lit " seems to be ill-formed"))
                (\ _ ->
                  binda (catch_error
                          (check_skip_transition showsl_atom logic_checker
                            normalize_lit skip)
                          (\ x ->
                            Inl (((showsl_lit "new transition " .
                                    showsl skip_ID) .
                                   showsl_lit " must be skip transition\n") .
                                  x)))
                    (\ _ ->
                      binda (check
                              (equal_sharp (source skip) new &&
                                equal_sharp (target skip) old)
                              (((((showsl_lit "new skip transition " .
                                    showsl skip_ID) .
                                   showsl_lit " must be from ") .
                                  showsl_sharp new) .
                                 showsl_lit " to ") .
                                showsl_sharp old))
                        (\ _ ->
                          let {
                            trans = transitions_impl p;
                          } in (case partition
                                       (\ tau -> is_sharp (source (snd tau)))
                                       trans
                                 of {
                                 (sharp, flat) ->
                                   (case partition
   (\ tau -> equal_sharp (target (snd tau)) old) sharp
                                     of {
                                     (sharp_modify, sharp_keep) ->
                                       let {
 q = Lts_Impl (initiala p)
       ((skip_ID, skip) :
         flat ++
           sharp_keep ++
             map (\ tau -> (fst tau, change_target new (snd tau))) sharp_modify)
       ((new, assertion_of p old) : assertion_impl p);
                                       } in
 binda (catch_error
         (forallM
           (\ l ->
             check (equal_formula (assertion_of p l) (assertion_of q l))
               ((showsl_lit "location condition of initial state " .
                  showsl_sharp l) .
                 showsl_lit " has been changed"))
           (initiala p))
         (\ x -> Inl (snd x)))
   (\ _ -> Inr q);
                                   });
                               })))))));

location_addition ::
  forall a b c d e f.
    (Eq a, Eq b, Eq c, Showl c, Default d, Showl d, Compare e, Eq e, Showl e,
      Showl f) => (a -> ([b], b)) ->
                    Set b ->
                      (Term a (c, b) -> String -> String) ->
                        (d -> Formula (Term a (c, b)) ->
                                Sum (String -> String) ()) ->
                          (Bool -> Term a (c, b) -> Formula (Term a (c, b))) ->
                            Lts_impl a c b (Sharp e) f ->
                              Location_addition_info a c b (Sharp e) f ->
                                Sum (String -> String)
                                  (Lts_impl a c b (Sharp e) f);
location_addition type_of_fun bool_types showsl_atom logic_checker normalize_lit
  p info =
  (case info of {
    Location_Addition_Info src _ _ _ ->
      (if not (membera (nodes_lts_impl p) src)
        then location_addition_incoming type_of_fun bool_types showsl_atom
               logic_checker normalize_lit p info
        else location_addition_outgoing type_of_fun bool_types showsl_atom
               logic_checker normalize_lit p info);
  });

fix_invariants ::
  forall a b c d e.
    (Compare_order d, Eq d, Showl d,
      Showl e) => Lts_impl a b c d e ->
                    (d -> Formula (Term a (b, c))) ->
                      Sum (String -> String) (Lts_impl a b c d e);
fix_invariants p phi =
  catch_error
    (let {
       ls = nodes_lts_impl p;
       _ = assertion_of p;
     } in Inr (Lts_Impl (initiala p) (transitions_impl p)
                (map (\ l -> (l, phi l)) ls)))
    (\ x ->
      Inl (showsl_lit "problem when fixing invariants as assertions\n" . x));

call_graph_sharp_impl ::
  forall a b c d e.
    (Eq d) => Lts_impl a b c (Sharp d) e -> [(Sharp d, Sharp d)];
call_graph_sharp_impl r =
  remdups
    (concatMap
      (\ tau ->
        (if is_sharp (source (snd tau))
          then [(source (snd tau), target (snd tau))] else []))
      (transitions_impl r));

fun_of_map_fun :: forall a b. (a -> Maybe b) -> (a -> b) -> a -> b;
fun_of_map_fun m d a = (case m a of {
                         Nothing -> d a;
                         Just b -> b;
                       });

g_list_to_map_rm_basic_ops ::
  forall a b. (Compare_order a) => [(a, b)] -> Rbt a b;
g_list_to_map_rm_basic_ops l =
  foldl (\ m (k, v) -> insert k v m) empty (reverse l);

ceta_map_of :: forall a b. (Compare_order a) => [(a, b)] -> a -> Maybe b;
ceta_map_of ps = lookup (g_list_to_map_rm_basic_ops ps);

precompute_fun :: forall a b. (Compare_order a) => (a -> b) -> [a] -> a -> b;
precompute_fun f asa =
  fun_of_map_fun (ceta_map_of (map (\ a -> (a, f a)) asa)) f;

edges_to_adj_fun :: forall a. (Compare_order a, Eq a) => [(a, a)] -> a -> [a];
edges_to_adj_fun e =
  precompute_fun
    (\ a ->
      remdups (concatMap (\ ea -> (if fst ea == a then [snd ea] else [])) e))
    (remdups (map fst e ++ map snd e));

create_graph_impl ::
  forall a.
    (Compare_order a,
      Eq a) => [(a, a)] -> Gen_g_impl_ext (a -> Bool) (a -> [a]) [a] ();
create_graph_impl e =
  Gen_g_impl_ext (membera (map fst e ++ map snd e)) (edges_to_adj_fun e)
    (remdups (map fst e ++ map snd e)) ();

as_singleton :: forall a b. (One b) => a -> (Array.Array a, b);
as_singleton x = (Array.Array [x], one);

gi_V0 :: forall a b c d. Gen_g_impl_ext a b c d -> c;
gi_V0 (Gen_g_impl_ext gi_V gi_E gi_V0 more) = gi_V0;

as_is_empty :: forall a. (Array.Array a, Nat) -> Bool;
as_is_empty s = equal_nat (snd s) zero_nat;

is_Nil :: forall a. [a] -> Bool;
is_Nil a = (case a of {
             [] -> True;
             _ : _ -> False;
           });

rev_append :: forall a. [a] -> [a] -> [a];
rev_append [] ac = ac;
rev_append (x : xs) ac = rev_append xs (x : ac);

glist_delete_aux :: forall a. (a -> a -> Bool) -> a -> [a] -> [a] -> [a];
glist_delete_aux eq x [] asa = asa;
glist_delete_aux eq x (y : ys) asa =
  (if eq x y then rev_append asa ys else glist_delete_aux eq x ys (y : asa));

glist_delete :: forall a. (a -> a -> Bool) -> a -> [a] -> [a];
glist_delete eq x l = glist_delete_aux eq x l [];

as_set :: forall a. (Array.Array a, Nat) -> Nat -> a -> (Array.Array a, Nat);
as_set s i x = (case s of {
                 (a, b) -> (array_set a i x, b);
               });

select_edge_tr ::
  forall a.
    (Eq a,
      Linorder a) => ((Array.Array a, Nat),
                       ((Array.Array Nat, Nat),
                         (Rbta a Int, (Array.Array (Nat, [a]), Nat)))) ->
                       (Maybe a,
                         ((Array.Array a, Nat),
                           ((Array.Array Nat, Nat),
                             (Rbta a Int, (Array.Array (Nat, [a]), Nat)))));
select_edge_tr s =
  (case s of {
    (a, (aa, (ab, bb))) ->
      (if as_is_empty bb then (Nothing, (a, (aa, (ab, bb))))
        else (case as_top bb of {
               (ac, bc) ->
                 (if less_eq_nat (as_get aa (minus_nat (as_length aa) one_nat))
                       ac
                   then let {
                          xa = gen_pick (\ x -> foldli (id x)) bc;
                          xb = glist_delete (\ ad b -> ad == b) xa bc;
                          xc = (if is_Nil xb then as_pop bb
                                 else as_set bb
(minus_nat (as_length bb) one_nat) (ac, xb));
                        } in (Just xa, (a, (aa, (ab, xc))))
                   else (Nothing, (a, (aa, (ab, bb)))));
             }));
  });

gi_E :: forall a b c d. Gen_g_impl_ext a b c d -> b;
gi_E (Gen_g_impl_ext gi_V gi_E gi_V0 more) = gi_E;

as_empty :: forall a b. (Zero b) => () -> (Array.Array a, b);
as_empty uu = (Array.Array [], zeroa);

stat_start :: () -> ();
stat_start = (\ _ -> ());

last_seg_tr ::
  forall a.
    (Linorder a) => ((Array.Array a, Nat),
                      ((Array.Array Nat, Nat),
                        (Rbta a Int, (Array.Array (Nat, [a]), Nat)))) ->
                      [a];
last_seg_tr s =
  (case s of {
    (a, (aa, (_, _))) ->
      (case while (\ (xe, _) ->
                    less_nat xe
                      (if equal_nat
                            (plus_nat (minus_nat (as_length aa) one_nat)
                              one_nat)
                            (as_length aa)
                        then as_length a
                        else as_get aa
                               (plus_nat (minus_nat (as_length aa) one_nat)
                                 one_nat)))
              (\ (ac, bc) -> let {
                               xa = as_get a ac;
                             } in (suc ac, xa : bc))
              (as_get aa (minus_nat (as_length aa) one_nat), [])
        of {
        (_, bc) -> bc;
      });
  });

find_max_nat :: Nat -> (Nat -> Bool) -> Nat;
find_max_nat n uu =
  (if equal_nat n zero_nat then zero_nat
    else (if uu (minus_nat n one_nat) then minus_nat n one_nat
           else find_max_nat (minus_nat n one_nat) uu));

idx_of_tr ::
  forall a.
    (Compare_order a) => a -> ((Array.Array a, Nat),
                                ((Array.Array Nat, Nat),
                                  (Rbta a Int,
                                    (Array.Array (Nat, [a]), Nat)))) ->
                                Nat;
idx_of_tr s v =
  (case v of {
    (_, (aa, (ab, _))) ->
      let {
        x = (case rbt_lookup ab s of {
              Just i ->
                (if less_eq_int zero_int i then nat i else error "undefined");
            });
        xa = find_max_nat (as_length aa) (\ j -> less_eq_nat (as_get aa j) x);
      } in xa;
  });

collapse_tr ::
  forall a.
    (Compare_order a) => a -> ((Array.Array a, Nat),
                                ((Array.Array Nat, Nat),
                                  (Rbta a Int,
                                    (Array.Array (Nat, [a]), Nat)))) ->
                                ((Array.Array a, Nat),
                                  ((Array.Array Nat, Nat),
                                    (Rbta a Int,
                                      (Array.Array (Nat, [a]), Nat))));
collapse_tr v s =
  (case s of {
    (a, (aa, (ab, bb))) -> let {
                             x = idx_of_tr v (a, (aa, (ab, bb)));
                             xa = as_take (plus_nat x one_nat) aa;
                           } in (a, (xa, (ab, bb)));
  });

stat_stop :: () -> ();
stat_stop = (\ _ -> ());

stat_newnode :: () -> ();
stat_newnode = (\ _ -> ());

as_push :: forall a. (Array.Array a, Nat) -> a -> (Array.Array a, Nat);
as_push s x =
  (case s of {
    (a, n) ->
      let {
        aa = (if equal_nat n (array_length a)
               then array_grow a
                      (max (nat_of_integer (4 :: Integer))
                        (times_nat (nat_of_integer (2 :: Integer)) n))
                      x
               else a);
        ab = array_set aa n x;
      } in (ab, plus_nat n one_nat);
  });

push_code ::
  forall a b.
    (Compare_order a) => Gen_g_impl_ext (a -> Bool) (a -> [a]) [a] b ->
                           a -> ((Array.Array a, Nat),
                                  ((Array.Array Nat, Nat),
                                    (Rbta a Int,
                                      (Array.Array (Nat, [a]), Nat)))) ->
                                  ((Array.Array a, Nat),
                                    ((Array.Array Nat, Nat),
                                      (Rbta a Int,
(Array.Array (Nat, [a]), Nat))));
push_code g_impl =
  (\ x (xa, (xb, (xc, xd))) ->
    let {
      _ = stat_newnode ();
      y_a = as_length xa;
      y_b = as_push xa x;
      y_c = as_push xb y_a;
      y_d = rbt_insert x (int_of_nat y_a) xc;
      y_e = (if is_Nil (gi_E g_impl x) then xd
              else as_push xd (y_a, gi_E g_impl x));
    } in (y_b, (y_c, (y_d, y_e))));

compute_SCC_tr ::
  forall a b.
    (Compare_order a,
      Eq a) => Gen_g_impl_ext (a -> Bool) (a -> [a]) [a] b -> [[a]];
compute_SCC_tr g =
  let {
    _ = stat_start ();
    xa = ([], Empty);
  } in (case foldli (id (gi_V0 g)) (\ _ -> True)
               (\ xb (a, b) ->
                 (if not (case rbt_lookup b xb of {
                           Nothing -> False;
                           Just i ->
                             (if less_eq_int zero_int i then False else True);
                         })
                   then let {
                          xc = (a, (as_singleton xb,
                                     (as_singleton zero_nat,
                                       (rbt_insert xb (int_of_nat zero_nat) b,
 (if is_Nil (gi_E g xb) then as_empty ()
   else as_singleton (zero_nat, gi_E g xb))))));
                        } in (case while (\ (_, xf) ->
   not (as_is_empty (case xf of {
                      (xg, (_, (_, _))) -> xg;
                    })))
                                     (\ (aa, ba) ->
                                       (case select_edge_tr ba of {
 (Nothing, bb) -> let {
                    xf = last_seg_tr bb;
                    xg = pop_tr bb;
                    xh = xf : aa;
                  } in (xh, xg);
 (Just xf, bb) ->
   (if (case rbt_lookup (case bb of {
                          (_, (_, (xl, _))) -> xl;
                        })
               xf
         of {
         Nothing -> False;
         Just i -> (if less_eq_int zero_int i then True else False);
       })
     then let {
            ab = collapse_tr xf bb;
          } in (aa, ab)
     else (if not (case rbt_lookup (case bb of {
                                     (_, (_, (xl, _))) -> xl;
                                   })
                          xf
                    of {
                    Nothing -> False;
                    Just i -> (if less_eq_int zero_int i then False else True);
                  })
            then (aa, push_code g xf bb) else (aa, bb)));
                                       }))
                                     xc
                               of {
                               (aa, (_, (_, (ad, _)))) -> (aa, ad);
                             })
                   else (a, b)))
               xa
         of {
         (a, _) -> let {
                     _ = stat_stop ();
                   } in a;
       });

scc_decomp :: forall a. (Compare_order a, Eq a) => [(a, a)] -> [[a]];
scc_decomp e =
  let {
    ee = Set e;
  } in filter (\ a -> (case a of {
                        [] -> True;
                        [v] -> member (v, v) ee;
                        _ : _ : _ -> True;
                      }))
         (compute_SCC_tr (create_graph_impl e));

scc_decomposition ::
  forall a b c d e.
    (Compare_order d, Eq d,
      Showl d) => Lts_impl a b c (Sharp d) e ->
                    [[Sharp d]] ->
                      Sum (String -> String) [Lts_impl a b c (Sharp d) e];
scc_decomposition cp sccs_info =
  let {
    cg = call_graph_sharp_impl cp;
    sccs = scc_decomp cg;
  } in binda (catch_error
               (forallM
                 (\ c ->
                   check (any (\ d -> equal_set (Set c) (Set d)) sccs_info)
                     ((showsl_lit "could not find SCC " . showsl_lista c) .
                       showsl_lit " in provided decomposition"))
                 sccs)
               (\ x -> Inl (snd x)))
         (\ _ ->
           let {
             trans = transitions_impl cp;
           } in (case partition (\ tau -> is_sharp (source (snd tau))) trans of
                  {
                  (sharp, flat) ->
                    let {
                      cPs = map (\ c ->
                                  let {
                                    l = Set c;
                                  } in Lts_Impl (initiala cp)
 (flat ++
   filter (\ tau -> member (source (snd tau)) l && member (target (snd tau)) l)
     sharp)
 (assertion_impl cp))
                              sccs_info;
                    } in catch_error (Inr cPs)
                           (\ x ->
                             Inl (((showsl_lit
                                      "error is SCC-decomposition w.r.t. sccs_info\n" .
                                     showsl_lista sccs_info) .
                                    showsl_literal "\n") .
                                   x));
                }));

cut_transition_split ::
  forall a b c d e.
    (Eq a, Showl a, Eq e,
      Showl e) => Cut_transition_split_info a ->
                    Lts_impl b c d (Sharp e) a ->
                      Sum (String -> String) [Lts_impl b c d (Sharp e) a];
cut_transition_split (Cut_Transition_Split_Info ct_ids) cp =
  catch_error
    (case partition ((\ tau -> is_sharp (source tau)) . snd)
            (transitions_impl cp)
      of {
      (p, r) ->
        (case partition ((is_sharp . target) . snd) r of {
          (ct, rr) ->
            let {
              slist = map (source . snd) p;
              s = Set slist;
              cT_ids = Set (concat ct_ids);
            } in binda (catch_error
                         (forallM
                           (\ l ->
                             check (not (is_sharp l))
                               ((showsl_lit "initial state " . showsl_sharp l) .
                                 showsl_lit " must not be sharped"))
                           (initiala cp))
                         (\ x -> Inl (snd x)))
                   (\ _ ->
                     binda (catch_error
                             (forallM
                               (\ (t_id, cta) ->
                                 check (if member (target cta) s
 then member t_id cT_ids else True)
                                   (((showsl_lit
"did not find cut-transition " .
                                       showsl t_id) .
                                      showsl_lit
" in partition\nrelevant cut-points are: ") .
                                     showsl_list_sharp slist))
                               ct)
                             (\ x -> Inl (snd x)))
                       (\ _ ->
                         let {
                           rrp = rr ++ p;
                         } in Inr (map (\ ct_idsa ->
 Lts_Impl (initiala cp) (filter (\ cta -> membera ct_idsa (fst cta)) ct ++ rrp)
   (assertion_impl cp))
                                    ct_ids)));
        });
    })
    (\ x -> Inl (showsl_lit "error in splitting cut transitions on LTS\n" . x));

showsl_cooperation_program ::
  forall a b c d e.
    (Showl d, Showl e) => Lts_impl a b c (Sharp d) e -> String -> String;
showsl_cooperation_program (Lts_Impl i tran lc) =
  let {
    trana = filter (\ (_, tt) -> is_sharp (target tt)) tran;
    tranb = (case partition (\ (_, tt) -> is_sharp (source tt)) trana of {
              (ss, fs) -> fs ++ ss;
            });
  } in showsl_lit "Cooperation program (only sharp-part)\n" .
         showsl_sep
           (\ (t, tt) ->
             (((showsl t . showsl_lit ": ") . showsl_sharp (source tt)) .
               showsl_lit " --> ") .
               showsl_sharp (target tt))
           (showsl_literal "\n") tranb .
    showsl_literal "\n";

forallM_index_aux ::
  forall a b. (a -> Nat -> Sum b ()) -> Nat -> [a] -> Sum ((a, Nat), b) ();
forallM_index_aux p i [] = Inr ();
forallM_index_aux p i (x : xs) =
  binda (catch_error (p x i) (\ xa -> Inl ((x, i), xa)))
    (\ _ -> forallM_index_aux p (suc i) xs);

forallM_index ::
  forall a b. (a -> Nat -> Sum b ()) -> [a] -> Sum ((a, Nat), b) ();
forallM_index p xs = forallM_index_aux p zero_nat xs;

add_index :: (String -> String) -> Nat -> String -> String;
add_index s i = (s . showsl_lit ".") . showsl_nat i;

check_cooperation_proof ::
  forall a b c d e f.
    (Eq a, Showl a, Eq b, Showl b, Default c, Showl c, Eq d, Showl d,
      Compare_order e, Eq e, Showl e, Compare_order f, Eq f,
      Showl f) => (a -> ([b], b)) ->
                    Set b ->
                      (c -> Formula (Term a (d, b)) ->
                              Sum (String -> String) ()) ->
                        (c -> Formula (Term a (Trans_var d, b)) ->
                                Sum (String -> String) ()) ->
                          (Term a (d, b) -> String -> String) ->
                            (Term a (Trans_var d, b) -> String -> String) ->
                              (Bool ->
                                Term a (d, b) -> Formula (Term a (d, b))) ->
                                (Bool ->
                                  Term a (Trans_var d, b) ->
                                    Formula (Term a (Trans_var d, b))) ->
                                  b -> (Term a (Trans_var d, b) ->
 Term a (Trans_var d, b) -> Formula (Term a (Trans_var d, b))) ->
 (Term a (Trans_var d, b) ->
   Term a (Trans_var d, b) -> Formula (Term a (Trans_var d, b))) ->
   (Term a (Trans_var d, b) -> Bool) ->
     (Trans_var d ->
       b -> Formula (Term a (Trans_var d, b)) -> Sum (String -> String) ()) ->
       (String -> String) ->
         Lts_impl a d b (Sharp e) f ->
           Cooperation_proof a d b e f c -> Sum (String -> String) ();
check_cooperation_proof type_of_fun bool_types tc tc2 sa sa2 ne ne2 dom_type
  less_eq_formula less_formula is_constant definability_checker i cPi Trivial =
  debug i "Trivial CP"
    (catch_error (trivial_termination_checker sa sa2 cPi)
      (\ x ->
        Inl ((i . showsl_lit
                    ": error in trivial cooperation termination checker\n") .
              x)));
check_cooperation_proof type_of_fun bool_types tc tc2 sa sa2 ne ne2 dom_type
  less_eq_formula less_formula is_constant definability_checker i cPi
  (Invariants_Update iproof cproof) =
  debug i "Invariants_Update"
    (binda
      (catch_error
        (invariant_proof_checker type_of_fun bool_types tc tc2 sa sa2 ne ne2 cPi
          iproof)
        (\ x ->
          Inl (((i . showsl_lit ": error in invariant update\n") .
                 showsl_cooperation_program cPi) .
                x)))
      (\ ia ->
        binda (fix_invariants cPi ia)
          (\ q ->
            catch_error
              (check_cooperation_proof type_of_fun bool_types tc tc2 sa sa2 ne
                ne2 dom_type less_eq_formula less_formula is_constant
                definability_checker (add_index i one_nat) q cproof)
              (\ x ->
                Inl ((i . showsl_lit ": error below invariant update\n") .
                      x)))));
check_cooperation_proof type_of_fun bool_types tc tc2 sa sa2 ne ne2 dom_type
  less_eq_formula less_formula is_constant definability_checker i cPi
  (Transition_Removal info iproof) =
  debug i "Transition Removal"
    (binda
      (catch_error
        (lex_processor type_of_fun bool_types sa2 tc2 ne2 dom_type
          less_eq_formula less_formula is_constant info cPi)
        (\ x ->
          Inl (((i . showsl_lit ": error in transition removal\n") .
                 showsl_cooperation_program cPi) .
                x)))
      (\ cPia ->
        catch_error
          (check_cooperation_proof type_of_fun bool_types tc tc2 sa sa2 ne ne2
            dom_type less_eq_formula less_formula is_constant
            definability_checker (add_index i one_nat) cPia iproof)
          (\ x ->
            Inl ((i . showsl_lit ": error below transition removal\n") . x))));
check_cooperation_proof type_of_fun bool_types tc tc2 sa sa2 ne ne2 dom_type
  less_eq_formula less_formula is_constant definability_checker i cPi
  (Location_Addition info iproof) =
  debug i "Location Addition"
    (binda
      (catch_error (location_addition type_of_fun bool_types sa tc ne cPi info)
        (\ x ->
          Inl (((i . showsl_literal ": error in location addition\n") .
                 showsl_cooperation_program cPi) .
                x)))
      (\ q ->
        catch_error
          (check_cooperation_proof type_of_fun bool_types tc tc2 sa sa2 ne ne2
            dom_type less_eq_formula less_formula is_constant
            definability_checker (add_index i one_nat) q iproof)
          (\ x ->
            Inl ((i . showsl_literal ": error below location addition\n") .
                  x))));
check_cooperation_proof type_of_fun bool_types tc tc2 sa sa2 ne ne2 dom_type
  less_eq_formula less_formula is_constant definability_checker i cPi
  (Fresh_Variable_Addition info iproof) =
  debug i "Fresh Variable Addition"
    (binda
      (catch_error
        (fresh_variable_addition type_of_fun bool_types definability_checker sa2
          cPi info)
        (\ x ->
          Inl (((i . showsl_lit ": error in fresh variable addition\n") .
                 showsl_cooperation_program cPi) .
                x)))
      (\ q ->
        catch_error
          (check_cooperation_proof type_of_fun bool_types tc tc2 sa sa2 ne ne2
            dom_type less_eq_formula less_formula is_constant
            definability_checker (add_index i one_nat) q iproof)
          (\ x ->
            Inl ((i . showsl_lit ": error below fresh variable addition\n") .
                  x))));
check_cooperation_proof type_of_fun bool_types tc tc2 sa sa2 ne ne2 dom_type
  less_eq_formula less_formula is_constant definability_checker i cPi
  (Scc_Decomp scc_proofs) =
  debug i "SCC Decomp"
    (binda
      (catch_error (scc_decomposition cPi (map fst scc_proofs))
        (\ x ->
          Inl (((i . showsl_lit ": error in Scc decomposition\n") .
                 showsl_cooperation_program cPi) .
                x)))
      (\ sccs ->
        catch_error
          (forallM_index
            (\ (scc, prof) j ->
              catch_error
                (check_cooperation_proof type_of_fun bool_types tc tc2 sa sa2 ne
                  ne2 dom_type less_eq_formula less_formula is_constant
                  definability_checker (add_index i (suc j)) scc prof)
                (\ x ->
                  Inl ((i . showsl_lit ": error below Scc decomposition\n") .
                        x)))
            (zip sccs (map snd scc_proofs)))
          (\ x -> Inl (snd x))));
check_cooperation_proof type_of_fun bool_types tc tc2 sa sa2 ne ne2 dom_type
  less_eq_formula less_formula is_constant definability_checker i cPi
  (Cut_Transition_Split scc_proofs) =
  debug i "Cut Transition Split"
    (binda
      (catch_error
        (cut_transition_split (Cut_Transition_Split_Info (map fst scc_proofs))
          cPi)
        (\ x ->
          Inl (((i . showsl_lit ": error in cut-transition split\n") .
                 showsl_cooperation_program cPi) .
                x)))
      (\ sccs ->
        catch_error
          (forallM_index
            (\ (scc, prof) j ->
              catch_error
                (check_cooperation_proof type_of_fun bool_types tc tc2 sa sa2 ne
                  ne2 dom_type less_eq_formula less_formula is_constant
                  definability_checker (add_index i (suc j)) scc prof)
                (\ x ->
                  Inl ((i . showsl_lit ": error below cut-transition split\n") .
                        x)))
            (zip sccs (map snd scc_proofs)))
          (\ x -> Inl (snd x))));

check_exists_cut ::
  forall a b c d e.
    (Eq a, Eq b, Showl b, Eq c, Default d, Showl d, Eq e,
      Showl e) => (Term a (b, c) -> String -> String) ->
                    (d -> Formula (Term a (b, c)) ->
                            Sum (String -> String) ()) ->
                      (Bool -> Term a (b, c) -> Formula (Term a (b, c))) ->
                        [Transition_rule a b c (Sharp e)] ->
                          e -> Sum (String -> String) ();
check_exists_cut showsl_atom logic_checker normalize_lit taus n =
  check (any (\ tau ->
               equal_sharp (source tau) (Flat n) &&
                 equal_sharp (target tau) (Sharp n) &&
                   isOK (check_skip_transition showsl_atom logic_checker
                          normalize_lit tau))
          taus)
    (showsl_lit "missing skip transition for " . showsl n);

sharp_transition ::
  forall a b c d. Transition_rule a b c d -> Transition_rule a b c (Sharp d);
sharp_transition (Transition l r phi) = Transition (Sharp l) (Sharp r) phi;

flat_transition ::
  forall a b c d. Transition_rule a b c d -> Transition_rule a b c (Sharp d);
flat_transition (Transition l r phi) = Transition (Flat l) (Flat r) phi;

make_copy_prog ::
  forall a b c d e.
    Lts_impl a b c d e ->
      [(Sharp e, Transition_rule a b c (Sharp d))] ->
        Lts_impl a b c (Sharp d) (Sharp e);
make_copy_prog (Lts_Impl init tau_s lc) cutpoints =
  Lts_Impl (map Flat init)
    (map (\ (tr, tau) -> (Flat tr, flat_transition tau)) tau_s ++
      cutpoints ++ map (\ (tr, tau) -> (Sharp tr, sharp_transition tau)) tau_s)
    (map (\ (tr, a) -> (Flat tr, a)) lc ++ map (\ (tr, a) -> (Sharp tr, a)) lc);

call_graph_impl :: forall a b c d e. (Eq d) => Lts_impl a b c d e -> [(d, d)];
call_graph_impl r =
  remdups
    (map (\ tau -> (source (snd tau), target (snd tau))) (transitions_impl r));

check_acyclic ::
  forall a.
    (Compare_order a, Eq a, Showl a) => [(a, a)] -> Sum (String -> String) ();
check_acyclic r =
  catch_error
    (catch_error
      (forallM
        (\ scc ->
          Inl ((showsl_lit "SCC " . showsl_list scc) . showsl_lit " detected "))
        (scc_decomp r))
      (\ x -> Inl (snd x)))
    (\ x ->
      Inl (((showsl_lit "\ngraph " . showsl_list_prod r) .
             showsl_lit " not acyclic\n") .
            x));

check_cut_points ::
  forall a.
    (Compare_order a, Eq a,
      Showl a) => [(a, a)] -> Set a -> Sum (String -> String) ();
check_cut_points r x =
  check_acyclic
    (filter (\ ab -> not (member (fst ab) x) && not (member (snd ab) x)) r);

natural :: forall a. Sharp a -> a;
natural (Sharp l) = l;
natural (Flat l) = l;

create_initial_cp_prog ::
  forall a b c d e f.
    (Eq a, Eq b, Eq c, Showl c, Default d, Showl d, Compare_order e, Eq e,
      Showl e,
      Showl f) => (a -> ([b], b)) ->
                    Set b ->
                      (Term a (c, b) -> String -> String) ->
                        (d -> Formula (Term a (c, b)) ->
                                Sum (String -> String) ()) ->
                          (Bool -> Term a (c, b) -> Formula (Term a (c, b))) ->
                            Lts_impl a c b e f ->
                              [[(Sharp f, Transition_rule a c b (Sharp e))]] ->
                                Sum (String -> String)
                                  [Lts_impl a c b (Sharp e) (Sharp f)];
create_initial_cp_prog type_of_fun bool_types showsl_atom logic_checker
  normalize_lit p cp_trans_list =
  (case let {
          cp_trans = concat cp_trans_list;
          cut_points =
            remdups (map (\ (_, tau) -> natural (source tau)) cp_trans);
        } in binda (catch_error
                     (check_cut_points (call_graph_impl p) (Set cut_points))
                     (\ x ->
                       Inl (showsl_lit
                              "problem in ensuring validity of cutpoints\n" .
                             x)))
               (\ _ ->
                 binda (catch_error
                         (forallM
                           (\ (n, cp) ->
                             check (transition_rule type_of_fun bool_types cp)
                               (showsl_sharp n .
                                 showsl_lit " is non valid transition rule"))
                           cp_trans)
                         (\ x -> Inl (snd x)))
                   (\ _ ->
                     catch_error
                       (forallM
                         (check_exists_cut showsl_atom logic_checker
                           normalize_lit (map snd cp_trans))
                         cut_points)
                       (\ x -> Inl (snd x))))
    of {
    Inl a -> Inl a;
    Inr _ -> Inr (map (make_copy_prog p) cp_trans_list);
  });

check_termination_proof ::
  forall a b c d e f.
    (Eq a, Showl a, Eq b, Showl b, Default c, Showl c, Eq d, Showl d,
      Compare_order e, Eq e, Showl e, Compare_order f, Eq f,
      Showl f) => (a -> ([b], b)) ->
                    Set b ->
                      (c -> Formula (Term a (d, b)) ->
                              Sum (String -> String) ()) ->
                        (c -> Formula (Term a (Trans_var d, b)) ->
                                Sum (String -> String) ()) ->
                          (Term a (d, b) -> String -> String) ->
                            (Term a (Trans_var d, b) -> String -> String) ->
                              (Bool ->
                                Term a (d, b) -> Formula (Term a (d, b))) ->
                                (Bool ->
                                  Term a (Trans_var d, b) ->
                                    Formula (Term a (Trans_var d, b))) ->
                                  b -> (Term a (Trans_var d, b) ->
 Term a (Trans_var d, b) -> Formula (Term a (Trans_var d, b))) ->
 (Term a (Trans_var d, b) ->
   Term a (Trans_var d, b) -> Formula (Term a (Trans_var d, b))) ->
   (Term a (Trans_var d, b) -> Bool) ->
     (Trans_var d ->
       b -> Formula (Term a (Trans_var d, b)) -> Sum (String -> String) ()) ->
       (String -> String) ->
         Lts_impl a d b e f ->
           Termination_proof a d b e f c -> Sum (String -> String) ();
check_termination_proof type_of_fun bool_types tc tc2 sa sa2 ne ne2 dom_type
  less_eq_formula less_formula is_constant definability_checker i pi Triviala =
  debug i "Trivial Termination"
    (catch_error
      (check (null (transitions_impl pi))
        (showsl_lit "transition rules remains at trivial termination proof"))
      (\ x ->
        Inl ((i . showsl_lit ": error in trivial termination checker\n") . x)));
check_termination_proof type_of_fun bool_types tc tc2 sa sa2 ne ne2 dom_type
  less_eq_formula less_formula is_constant definability_checker i pi
  (Invariants_Update_LTS iproof cproof) =
  debug i "Invariant Update"
    (binda
      (catch_error
        (invariant_proof_checker type_of_fun bool_types tc tc2 sa sa2 ne ne2 pi
          iproof)
        (\ x -> Inl ((i . showsl_lit ": error in invariant update\n") . x)))
      (\ ia ->
        binda (fix_invariants pi ia)
          (\ q ->
            catch_error
              (check_termination_proof type_of_fun bool_types tc tc2 sa sa2 ne
                ne2 dom_type less_eq_formula less_formula is_constant
                definability_checker (add_index i one_nat) q cproof)
              (\ x ->
                Inl ((i . showsl_lit ": error below invariant update\n") .
                      x)))));
check_termination_proof type_of_fun bool_types tc tc2 sa sa2 ne ne2 dom_type
  less_eq_formula less_formula is_constant definability_checker i pi
  (Via_Cooperation cp_proofs) =
  debug i "Switch to Cooperation Program"
    (binda
      (catch_error
        (create_initial_cp_prog type_of_fun bool_types sa tc ne pi
          (map fst cp_proofs))
        (\ x ->
          Inl ((i . showsl_lit
                      ": error in creating initial cooperation program\n") .
                x)))
      (\ cPi ->
        catch_error
          (forallM_index
            (\ (r, prf) n ->
              catch_error
                (check_cooperation_proof type_of_fun bool_types tc tc2 sa sa2 ne
                  ne2 dom_type less_eq_formula less_formula is_constant
                  definability_checker (add_index i n) r prf)
                (\ x ->
                  Inl ((i . showsl_lit
                              ": error below switching to initial cooperation program\n") .
                        x)))
            (zip cPi (map snd cp_proofs)))
          (\ x -> Inl (snd x))));

checka ::
  forall a b c d e f.
    (Eq a, Showl a, Eq b, Showl b, Default c, Showl c, Eq d, Showl d,
      Compare_order e, Eq e, Showl e, Compare_order f, Eq f,
      Showl f) => (a -> ([b], b)) ->
                    Set b ->
                      (c -> Formula (Term a (d, b)) ->
                              Sum (String -> String) ()) ->
                        (c -> Formula (Term a (Trans_var d, b)) ->
                                Sum (String -> String) ()) ->
                          (Term a (d, b) -> String -> String) ->
                            (Term a (Trans_var d, b) -> String -> String) ->
                              (Bool ->
                                Term a (d, b) -> Formula (Term a (d, b))) ->
                                (Bool ->
                                  Term a (Trans_var d, b) ->
                                    Formula (Term a (Trans_var d, b))) ->
                                  b -> (Term a (Trans_var d, b) ->
 Term a (Trans_var d, b) -> Formula (Term a (Trans_var d, b))) ->
 (Term a (Trans_var d, b) ->
   Term a (Trans_var d, b) -> Formula (Term a (Trans_var d, b))) ->
   (Term a (Trans_var d, b) -> Bool) ->
     (Trans_var d ->
       b -> Formula (Term a (Trans_var d, b)) -> Sum (String -> String) ()) ->
       Lts_impl a d b e f ->
         Termination_proof a d b e f c -> Sum (String -> String) ();
checka type_of_fun bool_types tc tc2 sa sa2 ne ne2 dom_type less_eq_formula
  less_formula is_constant definability_checker pi prf =
  binda (debug id "init - Check well-formedness"
          (catch_error (check_lts_impl type_of_fun bool_types pi)
            (\ x -> Inl (showsl_lit "input LTS is not well-formed" . x))))
    (\ _ ->
      check_termination_proof type_of_fun bool_types tc tc2 sa sa2 ne ne2
        dom_type less_eq_formula less_formula is_constant definability_checker
        id pi prf);

contains_var_term :: forall a b. (Eq a) => a -> Term b a -> Bool;
contains_var_term x (Var y) = x == y;
contains_var_term x (Fun uu ts) = any (contains_var_term x) ts;

ia4_defining_equation ::
  forall a. (Eq a) => a -> Ty -> Formula (Term Ia4_sig (a, Ty)) -> Bool;
ia4_defining_equation x ty (Atom (Fun (IA4_Base EqF) [Var (y, t), e])) =
  x == y &&
    equal_ty ty t &&
      equal_ty ty IntT &&
        has_type type_of_fun e IntT && not (contains_var_term (x, ty) e);
ia4_defining_equation uu uv (Atom (Var va)) = False;
ia4_defining_equation uu uv (Atom (Fun (IA4_Base LessF) vb)) = False;
ia4_defining_equation uu uv (Atom (Fun (IA4_Base LeF) vb)) = False;
ia4_defining_equation uu uv (Atom (Fun (IA4_Base (SumF vd)) vb)) = False;
ia4_defining_equation uu uv (Atom (Fun (IA4_Base (ConstF vd)) vb)) = False;
ia4_defining_equation uu uv (Atom (Fun (IA4_Base (ProdF vd)) vb)) = False;
ia4_defining_equation uu uv (Atom (Fun IA4_Div vb)) = False;
ia4_defining_equation uu uv (Atom (Fun IA4_Mod vb)) = False;
ia4_defining_equation uu uv (Atom (Fun va [])) = False;
ia4_defining_equation uu uv (Atom (Fun va (Fun ve vf : vd))) = False;
ia4_defining_equation uu uv (Atom (Fun va [vc])) = False;
ia4_defining_equation uu uv (Atom (Fun va (vc : ve : vg : vh))) = False;
ia4_defining_equation uu uv (NegAtom v) = False;
ia4_defining_equation uu uv (Conjunction v) = False;
ia4_defining_equation uu uv (Disjunction v) = False;

ia4_definable ::
  forall a. (Eq a) => a -> Ty -> Formula (Term Ia4_sig (a, Ty)) -> Bool;
ia4_definable x ty (Conjunction []) = True;
ia4_definable x ty (Conjunction [f]) = ia4_defining_equation x ty f;
ia4_definable x ty (Atom v) = ia4_defining_equation x ty (Atom v);
ia4_definable x ty (NegAtom v) = ia4_defining_equation x ty (NegAtom v);
ia4_definable x ty (Conjunction (va : v : vc)) =
  ia4_defining_equation x ty (Conjunction (va : v : vc));
ia4_definable x ty (Disjunction v) = ia4_defining_equation x ty (Disjunction v);

ia4_def_checker ::
  forall a.
    (Eq a) => a -> Ty -> Formula (Term Ia4_sig (a, Ty)) ->
                           Sum (String -> String) ();
ia4_def_checker x ty f =
  check (ia4_definable x ty f)
    (showsl_lit
      "fresh variable definition requires an independent typed equation");

ia4_check_termination ::
  forall a b c.
    (Compare a, Eq a, Showl a, Compare_order b, Eq b, Showl b, Compare_order c,
      Eq c,
      Showl c) => Lts_impl Ia4_sig a Ty b c ->
                    Termination_proof Ia4_sig a Ty b c La_solver_type ->
                      Sum (String -> String) ();
ia4_check_termination =
  checka type_of_fun (inserta BoolT bot_set) ia4_check_clause ia4_check_clause
    showsl_terma showsl_terma (\ b e -> (if b then Atom e else NegAtom e))
    (\ b e -> (if b then Atom e else NegAtom e)) IntT
    (\ s t -> Atom (Fun (IA4_Base LeF) [s, t]))
    (\ s t -> Atom (Fun (IA4_Base LessF) [s, t]))
    (\ e -> equal_set (vars_term e) bot_set) ia4_def_checker;

ia4_recurrent_obligation ::
  forall a b c d e.
    (Eq b, Eq c,
      Compare_order d) => Lts_impl a b c d e ->
                            d -> Formula (Term a (b, c)) ->
                                   Formula (Term a (Trans_var b, c)) ->
                                     [((b, c), Term a (b, c))] ->
                                       [((b, c), Term a (b, c))] ->
 Formula (Term a (b, c));
ia4_recurrent_obligation p l region transition_guard post local =
  Disjunction
    [form_not region,
      Conjunction
        [ia4_subst_formula (ia4_step_policy post local) transition_guard,
          ia4_subst_formula (ia4_policy_exp post) (assertion_of p l),
          ia4_subst_formula (ia4_policy_exp post) region]];

ia4_check_recurrent_policy ::
  forall a b c.
    (Compare a, Eq a, Showl a, Compare_order b, Eq b,
      Eq c) => Lts_impl Ia4_sig a Ty b c ->
                 b -> Formula (Term Ia4_sig (a, Ty)) ->
                        (c, Transition_rule Ia4_sig a Ty b) ->
                          [((a, Ty), Term Ia4_sig (a, Ty))] ->
                            [((a, Ty), Term Ia4_sig (a, Ty))] ->
                              Sum (String -> String) ();
ia4_check_recurrent_policy p l region tau post local =
  binda (check
          (membera (transitions_impl p) tau &&
            source (snd tau) == l && target (snd tau) == l)
          (showsl_lit "recurrent transition must be an original self-loop"))
    (\ _ ->
      binda (check
              (ia4_policy_typed post &&
                ia4_policy_typed local &&
                  formula (is_bool type_of_fun (inserta BoolT bot_set)) region)
              (showsl_lit "ill-typed recurrent region or successor policy"))
        (\ _ ->
          let {
            obligation =
              ia4_recurrent_obligation p l region (transition_formula (snd tau))
                post local;
          } in binda (check
                       (formula (is_bool type_of_fun (inserta BoolT bot_set))
                         obligation)
                       (showsl_lit "ill-typed recurrent obligation"))
                 (\ _ ->
                   check_valid_formula showsl_terma ia4_check_clause
                     (\ b e -> (if b then Atom e else NegAtom e))
                     default_la_solver_type obligation)));

ia4_check_recurrent ::
  forall a b c.
    (Compare_order a, Eq a, Showl a, Compare_order b, Eq b,
      Eq c) => Lts_impl Ia4_sig a Ty b c ->
                 ([(a, Int)], b) ->
                   [((c, Transition_rule Ia4_sig a Ty b), ([(a, Int)], b))] ->
                     Formula (Term Ia4_sig (a, Ty)) ->
                       (c, Transition_rule Ia4_sig a Ty b) ->
                         [((a, Ty), Term Ia4_sig (a, Ty))] ->
                           [((a, Ty), Term Ia4_sig (a, Ty))] ->
                             Sum (String -> String) ();
ia4_check_recurrent p init stem region tau post local =
  binda (check_lts_impl type_of_fun (inserta BoolT bot_set) p)
    (\ _ ->
      binda (check
              (membera (initiala p) (snd init) && ia4_ground_state_ok p init)
              (showsl_lit "invalid recurrent initial state"))
        (\ _ ->
          binda (ia4_check_ground_seq p init stem)
            (\ head ->
              binda (check
                      (satisfies (\ alpha t -> to_bool (eval i t alpha))
                        (ia4_ground_val (fst head)) region)
                      (showsl_lit "stem does not reach the recurrent region"))
                (\ _ ->
                  ia4_check_recurrent_policy p (snd head) region tau post
                    local))));

check_its4 ::
  Lts_impl Ia4_sig [Char] Ty [Char] [Char] ->
    Bool -> Its4_proof -> Sum (String -> String) ();
check_its4 p True (ITS4_Termination proof) = ia4_check_termination p proof;
check_its4 p False (ITS4_Nontermination proof) =
  ia4_check_ground_nontermination p proof;
check_its4 p False (ITS4_Recurrent init stem region tr post local) =
  ia4_check_recurrent p init stem region tr post local;
check_its4 p False (ITS4_RecurrentCycle init stem region steps) =
  ia4_check_recurrent_cycle p init stem region steps;
check_its4 uu False (ITS4_Termination v) =
  Inl (showsl_lit "ITS verdict/proof mismatch");
check_its4 uu True (ITS4_Nontermination v) =
  Inl (showsl_lit "ITS verdict/proof mismatch");
check_its4 uu True (ITS4_Recurrent v va vb vc vd ve) =
  Inl (showsl_lit "ITS verdict/proof mismatch");
check_its4 uu True (ITS4_RecurrentCycle v va vb vc) =
  Inl (showsl_lit "ITS verdict/proof mismatch");

type_parser ::
  (Xml, ([([Char], [Char])], (Bool, ([String], [String])))) ->
    Sum_bot (Xml_error String) Ty;
type_parser =
  xml_or (xml_do "int" (xml_return IntT)) (xml_do "bool" (xml_return BoolT));

variable_parser ::
  (Xml, ([([Char], [Char])], (Bool, ([String], [String])))) ->
    Sum_bot (Xml_error String) [Char];
variable_parser = xml_text "variableId";

ia4_exp_parsera ::
  forall a.
    (Eq a) => ((Xml, ([([Char], [Char])], (Bool, ([String], [String])))) ->
                Sum_bot (Xml_error String) a) ->
                (Xml, ([([Char], [Char])], (Bool, ([String], [String])))) ->
                  Sum_bot (Xml_error String) (Term Ia4_sig (a, Ty));
ia4_exp_parsera v xml =
  xml_or
    (xml_do "div"
      (xml_take (ia4_exp_parsera v)
        (\ a ->
          xml_take (ia4_exp_parsera v)
            (\ d ->
              (if not (equal_set (vars_term d) bot_set)
                then xml_error "symbolic div/mod divisor is unsupported"
                else (if equal_int (divisor_value d) zero_int
                       then xml_error "zero div/mod divisor is unsupported"
                       else xml_return (Fun IA4_Div [a, d])))))))
    (xml_or
      (xml_do "mod"
        (xml_take (ia4_exp_parsera v)
          (\ a ->
            xml_take (ia4_exp_parsera v)
              (\ d ->
                (if not (equal_set (vars_term d) bot_set)
                  then xml_error "symbolic div/mod divisor is unsupported"
                  else (if equal_int (divisor_value d) zero_int
                         then xml_error "zero div/mod divisor is unsupported"
                         else xml_return (Fun IA4_Mod [a, d])))))))
      (xml_or
        (xml_do "product"
          (xml_take_many_sub [] zero_nat Infinity_enat (ia4_exp_parsera v)
            (\ exps ->
              xml_return (Fun (IA4_Base (ProdF (size_list exps))) exps))))
        (xml_or
          (xml_do "sum"
            (xml_take_many_sub [] zero_nat Infinity_enat (ia4_exp_parsera v)
              (\ exps ->
                xml_return (Fun (IA4_Base (SumF (size_list exps))) exps))))
          (xml_or
            (xml_change (xml_int "constant")
              (\ i -> xml_return (Fun (IA4_Base (ConstF i)) [])))
            (xml_change v (\ x -> xml_return (Var (x, IntT))))))))
    xml;

ia4_exp_parser ::
  (Xml, ([([Char], [Char])], (Bool, ([String], [String])))) ->
    Sum_bot (Xml_error String) (Term Ia4_sig ([Char], Ty));
ia4_exp_parser = ia4_exp_parsera variable_parser;

sharp_trans_id ::
  forall a.
    (String ->
      (Xml, ([([Char], [Char])], (Bool, ([String], [String])))) ->
        Sum_bot (Xml_error String) a) ->
      (Xml, ([([Char], [Char])], (Bool, ([String], [String])))) ->
        Sum_bot (Xml_error String) (Sharp a);
sharp_trans_id trans_id_parser =
  xml_or
    (xml_change (trans_id_parser "transitionDuplicate") (xml_return . Sharp))
    (xml_change (trans_id_parser "transitionId") (xml_return . Flat));

ia4_bexp_parser ::
  forall a.
    (Eq a) => ((Xml, ([([Char], [Char])], (Bool, ([String], [String])))) ->
                Sum_bot (Xml_error String) a) ->
                (Xml, ([([Char], [Char])], (Bool, ([String], [String])))) ->
                  Sum_bot (Xml_error String) (Formula (Term Ia4_sig (a, Ty)));
ia4_bexp_parser v =
  let {
    ia4_bexp_parser =
      xml_or
        (xml_do "leq"
          (xml_take (ia4_exp_parsera v)
            (\ l ->
              xml_take (ia4_exp_parsera v)
                (\ r -> xml_return (Fun (IA4_Base LeF) [l, r])))))
        (xml_or
          (xml_do "less"
            (xml_take (ia4_exp_parsera v)
              (\ l ->
                xml_take (ia4_exp_parsera v)
                  (\ r -> xml_return (Fun (IA4_Base LessF) [l, r])))))
          (xml_or
            (xml_do "eq"
              (xml_take (ia4_exp_parsera v)
                (\ l ->
                  xml_take (ia4_exp_parsera v)
                    (\ r -> xml_return (Fun (IA4_Base EqF) [l, r])))))
            (xml_or
              (xml_do "geq"
                (xml_take (ia4_exp_parsera v)
                  (\ l ->
                    xml_take (ia4_exp_parsera v)
                      (\ r -> xml_return (Fun (IA4_Base LeF) [r, l])))))
              (xml_do "greater"
                (xml_take (ia4_exp_parsera v)
                  (\ l ->
                    xml_take (ia4_exp_parsera v)
                      (\ r -> xml_return (Fun (IA4_Base LessF) [r, l]))))))));
  } in xml_or
         (xml_do "not"
           (xml_take ia4_bexp_parser (\ a -> xml_return (NegAtom a))))
         (xml_change ia4_bexp_parser (xml_return . Atom));

ia4_atom_parser ::
  (Xml, ([([Char], [Char])], (Bool, ([String], [String])))) ->
    Sum_bot (Xml_error String) (Formula (Term Ia4_sig ([Char], Ty)));
ia4_atom_parser = xml_change (ia4_bexp_parser variable_parser) xml_return;

location_parser ::
  forall a.
    (String ->
      (Xml, ([([Char], [Char])], (Bool, ([String], [String])))) ->
        Sum_bot (Xml_error String) a) ->
      (Xml, ([([Char], [Char])], (Bool, ([String], [String])))) ->
        Sum_bot (Xml_error String) a;
location_parser location_id_parser = location_id_parser "locationId";

trans_var_parser ::
  (Xml, ([([Char], [Char])], (Bool, ([String], [String])))) ->
    Sum_bot (Xml_error String) (Trans_var [Char]);
trans_var_parser =
  xml_or (xml_do "post" (xml_take variable_parser (\ v -> xml_return (Post v))))
    (xml_or
      (xml_do "aux"
        (xml_take variable_parser (\ v -> xml_return (Intermediate v))))
      (xml_change variable_parser (xml_return . Pre)));

ia4_tatom_parser ::
  (Xml, ([([Char], [Char])], (Bool, ([String], [String])))) ->
    Sum_bot (Xml_error String) (Formula (Term Ia4_sig (Trans_var [Char], Ty)));
ia4_tatom_parser = xml_change (ia4_bexp_parser trans_var_parser) xml_return;

ia4_lts_input_parser ::
  (Xml, ([([Char], [Char])], (Bool, ([String], [String])))) ->
    Sum_bot (Xml_error String) (Lts_impl Ia4_sig [Char] Ty [Char] [Char]);
ia4_lts_input_parser =
  lts_parser (location_parser xml_text) (trans_id xml_text) ia4_tatom_parser
    "lts";

ia4_ground_state_parser ::
  (Xml, ([([Char], [Char])], (Bool, ([String], [String])))) ->
    Sum_bot (Xml_error String) ([([Char], Int)], [Char]);
ia4_ground_state_parser =
  xml_do "state"
    (xml_take (xml_text "locationId")
      (\ loc ->
        xml_take
          (xml_do "substitution"
            (xml_take_many_sub [] zero_nat Infinity_enat
              (xml_do "substEntry"
                (xml_take variable_parser
                  (\ v ->
                    xml_take (xml_int "constant") (\ n -> xml_return (v, n)))))
              xml_return))
          (\ vs -> xml_return (vs, loc))));

ia4_ground_step_parser ::
  (Xml, ([([Char], [Char])], (Bool, ([String], [String])))) ->
    Sum_bot (Xml_error String)
      (([Char], Transition_rule Ia4_sig [Char] Ty [Char]),
        ([([Char], Int)], [Char]));
ia4_ground_step_parser =
  xml_do "transitionStep"
    (xml_take
      (transition_parser (location_parser xml_text) (trans_id xml_text)
        ia4_tatom_parser)
      (\ tr ->
        xml_take ia4_ground_state_parser (\ tgt -> xml_return (tr, tgt))));

ia4_lts_nontermination_proof_parser ::
  (Xml, ([([Char], [Char])], (Bool, ([String], [String])))) ->
    Sum_bot (Xml_error String) (Ia4_nontermination_proof [Char]);
ia4_lts_nontermination_proof_parser =
  xml_do "equivalentState"
    (xml_take ia4_ground_state_parser
      (\ init ->
        xml_take
          (xml_do "stem"
            (xml_take_many_sub [] zero_nat Infinity_enat ia4_ground_step_parser
              xml_return))
          (\ stem ->
            xml_take
              (xml_do "loop"
                (xml_take_many_sub [] one_nat Infinity_enat
                  ia4_ground_step_parser xml_return))
              (\ loop -> xml_return (IA4_EquivalentState init stem loop)))));

invariant_proof_parser ::
  forall a b c d e f.
    (Default f) => ((Xml, ([([Char], [Char])], (Bool, ([String], [String])))) ->
                     Sum_bot (Xml_error String) a) ->
                     ((Xml, ([([Char], [Char])],
                              (Bool, ([String], [String])))) ->
                       Sum_bot (Xml_error String) b) ->
                       ((Xml, ([([Char], [Char])],
                                (Bool, ([String], [String])))) ->
                         Sum_bot (Xml_error String)
                           (Formula (Term c (d, e)))) ->
                         [(a, Formula (Term c (d, e)))] ->
                           (Xml, ([([Char], [Char])],
                                   (Bool, ([String], [String])))) ->
                             Sum_bot (Xml_error String)
                               (Invariant_proof c d e a [Char] b f);
invariant_proof_parser location_parser trans_parser atom_parser i =
  xml_change (art_parser xml_text location_parser trans_parser atom_parser)
    (\ prf -> xml_return (Impact i prf));

sharp_location_parser ::
  forall a.
    (String ->
      (Xml, ([([Char], [Char])], (Bool, ([String], [String])))) ->
        Sum_bot (Xml_error String) a) ->
      (Xml, ([([Char], [Char])], (Bool, ([String], [String])))) ->
        Sum_bot (Xml_error String) (Sharp a);
sharp_location_parser location_id_parser =
  xml_or
    (xml_change (location_id_parser "locationDuplicate") (xml_return . Sharp))
    (xml_change (location_id_parser "locationId") (xml_return . Flat));

invariant_parser ::
  forall a b c d.
    ((Xml, ([([Char], [Char])], (Bool, ([String], [String])))) ->
      Sum_bot (Xml_error String) a) ->
      ((Xml, ([([Char], [Char])], (Bool, ([String], [String])))) ->
        Sum_bot (Xml_error String) (Formula (Term b (c, d)))) ->
        (Xml, ([([Char], [Char])], (Bool, ([String], [String])))) ->
          Sum_bot (Xml_error String) (a, Formula (Term b (c, d)));
invariant_parser location_parser atom_parser =
  xml_do "invariant"
    (xml_take (xml_do "location" (xml_take location_parser xml_return))
      (\ l ->
        xml_take
          (xml_do "formula" (xml_take (formula_parser atom_parser) xml_return))
          (\ phi -> xml_return (l, phi))));

invariants_parser ::
  forall a b c d.
    ((Xml, ([([Char], [Char])], (Bool, ([String], [String])))) ->
      Sum_bot (Xml_error String) a) ->
      ((Xml, ([([Char], [Char])], (Bool, ([String], [String])))) ->
        Sum_bot (Xml_error String) (Formula (Term b (c, d)))) ->
        (Xml, ([([Char], [Char])], (Bool, ([String], [String])))) ->
          Sum_bot (Xml_error String) [(a, Formula (Term b (c, d)))];
invariants_parser location_parser atom_parser =
  xml_do "invariants"
    (xml_take_many_sub [] zero_nat Infinity_enat
      (invariant_parser location_parser atom_parser) xml_return);

cooperation_proof_parser ::
  forall a b c d e f.
    (Compare a, Compare_order e,
      Default f) => (String ->
                      (Xml, ([([Char], [Char])],
                              (Bool, ([String], [String])))) ->
                        Sum_bot (Xml_error String) a) ->
                      ((Xml, ([([Char], [Char])],
                               (Bool, ([String], [String])))) ->
                        Sum_bot (Xml_error String) (Term b (c, d))) ->
                        ((Xml, ([([Char], [Char])],
                                 (Bool, ([String], [String])))) ->
                          Sum_bot (Xml_error String)
                            (Formula (Term b (c, d)))) ->
                          ((Xml, ([([Char], [Char])],
                                   (Bool, ([String], [String])))) ->
                            Sum_bot (Xml_error String)
                              (Formula (Term b (Trans_var c, d)))) ->
                            ((Xml, ([([Char], [Char])],
                                     (Bool, ([String], [String])))) ->
                              Sum_bot (Xml_error String) c) ->
                              ((Xml, ([([Char], [Char])],
                                       (Bool, ([String], [String])))) ->
                                Sum_bot (Xml_error String) d) ->
                                d -> ((Xml,
([([Char], [Char])], (Bool, ([String], [String])))) ->
                                       Sum_bot (Xml_error String) e) ->
                                       (Xml,
 ([([Char], [Char])], (Bool, ([String], [String])))) ->
 Sum_bot (Xml_error String) (Cooperation_proof b c d a e f);
cooperation_proof_parser location_id_parser exp_parser atom_parser tatom_parser
  variable_parser type_parser dom_type trans_parser xs =
  xml_or (xml_do "trivial" (xml_return Trivial))
    (xml_or
      (xml_do "newInvariants"
        (xml_take
          (invariants_parser (sharp_location_parser location_id_parser)
            atom_parser)
          (\ i ->
            xml_take
              (invariant_proof_parser (sharp_location_parser location_id_parser)
                trans_parser atom_parser i)
              (\ p ->
                xml_take
                  (cooperation_proof_parser location_id_parser exp_parser
                    atom_parser tatom_parser variable_parser type_parser
                    dom_type trans_parser)
                  (\ cp -> xml_return (Invariants_Update p cp))))))
      (xml_or
        (xml_do "transitionRemoval"
          (xml_take
            (xml_do "rankingFunctions"
              (xml_take_many_sub [] zero_nat Infinity_enat
                (xml_do "rankingFunction"
                  (xml_take
                    (xml_do "location"
                      (xml_take (sharp_location_parser location_id_parser)
                        xml_return))
                    (\ l ->
                      xml_take
                        (xml_do "expression"
                          (xml_take_many_sub [] one_nat Infinity_enat exp_parser
                            xml_return))
                        (\ es -> xml_return (l, es)))))
                xml_return))
            (\ rs ->
              xml_take
                (xml_do "bound"
                  (xml_take_many_sub [] zero_nat Infinity_enat exp_parser
                    xml_return))
                (\ bounds ->
                  xml_take
                    (xml_do "remove"
                      (xml_take_many_sub [] zero_nat Infinity_enat trans_parser
                        xml_return))
                    (\ removed ->
                      xml_take_default (\ _ -> defaulta)
                        (xml_do "hints"
                          (xml_take_many_sub [] zero_nat Infinity_enat
                            (xml_do "hint"
                              (xml_take trans_parser
                                (\ tr ->
                                  xml_take_default defaulta hints_parser
                                    (\ hint -> xml_return (tr, hint)))))
                            (\ pairs ->
                              xml_return (map_of_default defaulta pairs))))
                        (\ hinter ->
                          xml_take
                            (cooperation_proof_parser location_id_parser
                              exp_parser atom_parser tatom_parser
                              variable_parser type_parser dom_type trans_parser)
                            (\ inner ->
                              let {
                                rf = map_of_default [] rs;
                              } in xml_return
                                     (Transition_Removal
                                       (Transition_removal_info rf removed
 dom_type bounds hinter)
                                       inner))))))))
        (xml_or
          (xml_do "locationAddition"
            (xml_take
              (transition_parser (sharp_location_parser location_id_parser)
                trans_parser tatom_parser)
              (\ tr ->
                xml_take
                  (cooperation_proof_parser location_id_parser exp_parser
                    atom_parser tatom_parser variable_parser type_parser
                    dom_type trans_parser)
                  (\ prof ->
                    (case tr of {
                      (tr_id, tau) ->
                        xml_return
                          (Location_Addition
                            (Location_Addition_Info (source tau) (target tau)
                              tr_id tau)
                            prof);
                    })))))
          (xml_or
            (xml_do "freshVariableAddition"
              (xml_take variable_parser
                (\ x1 ->
                  xml_take type_parser
                    (\ x2 ->
                      xml_take
                        (xml_do "additionalFormulas"
                          (xml_take_many_sub [] zero_nat Infinity_enat
                            (xml_do "additionalFormula"
                              (xml_take trans_parser
                                (\ tr ->
                                  xml_take (formula_parser tatom_parser)
                                    (\ phi -> xml_return (tr, phi)))))
                            xml_return))
                        (\ x3 ->
                          xml_take
                            (cooperation_proof_parser location_id_parser
                              exp_parser atom_parser tatom_parser
                              variable_parser type_parser dom_type trans_parser)
                            (\ prof ->
                              xml_return
                                (Fresh_Variable_Addition
                                  (Fresh_Variable_Addition_Info x1 x2 x3)
                                  prof)))))))
            (xml_or
              (xml_do "cutTransitionSplit"
                (xml_take_many_sub [] zero_nat Infinity_enat
                  (xml_do "cutTransitionsWithProof"
                    (xml_take
                      (xml_do "cutTransitions"
                        (xml_take_many_sub [] zero_nat Infinity_enat
                          trans_parser xml_return))
                      (\ cuts ->
                        xml_take
                          (cooperation_proof_parser location_id_parser
                            exp_parser atom_parser tatom_parser variable_parser
                            type_parser dom_type trans_parser)
                          (\ prof -> xml_return (cuts, prof)))))
                  (\ ps -> xml_return (Cut_Transition_Split ps))))
              (xml_do "sccDecomposition"
                (xml_take_many_sub [] zero_nat Infinity_enat
                  (xml_do "sccWithProof"
                    (xml_take
                      (xml_do "scc"
                        (xml_take_many_sub [] one_nat Infinity_enat
                          (sharp_location_parser location_id_parser)
                          xml_return))
                      (\ scc ->
                        xml_take
                          (cooperation_proof_parser location_id_parser
                            exp_parser atom_parser tatom_parser variable_parser
                            type_parser dom_type trans_parser)
                          (\ prof -> xml_return (scc, prof)))))
                  (\ sccs -> xml_return (Scc_Decomp sccs)))))))))
    xs;

cut_points_to_transitions ::
  forall a b c d e.
    [(Sharp a, Transition_rule b c d (Sharp e))] ->
      [(e, (a, Formula (Term b (Trans_var c, d))))] ->
        [(Sharp a, Transition_rule b c d (Sharp e))];
cut_points_to_transitions ts [] = ts;
cut_points_to_transitions ts ((l, (tr, phi)) : cps) =
  cut_points_to_transitions ((Flat tr, Transition (Flat l) (Sharp l) phi) : ts)
    cps;

cutPoints_parser ::
  forall a b c d e.
    (String ->
      (Xml, ([([Char], [Char])], (Bool, ([String], [String])))) ->
        Sum_bot (Xml_error String) a) ->
      (String ->
        (Xml, ([([Char], [Char])], (Bool, ([String], [String])))) ->
          Sum_bot (Xml_error String) b) ->
        ((Xml, ([([Char], [Char])], (Bool, ([String], [String])))) ->
          Sum_bot (Xml_error String) (Formula (Term c (Trans_var d, e)))) ->
          (Xml, ([([Char], [Char])], (Bool, ([String], [String])))) ->
            Sum_bot (Xml_error String)
              [(Sharp b, Transition_rule c d e (Sharp a))];
cutPoints_parser location_id_parser trans_id_parser tatom_parser =
  xml_do "cutPoints"
    (xml_take_many_sub [] zero_nat Infinity_enat
      (xml_do "cutPoint"
        (xml_take (location_id_parser "locationId")
          (\ l ->
            xml_take (trans_id_parser "skipId")
              (\ tr ->
                xml_take
                  (xml_do "skipFormula"
                    (xml_take (formula_parser tatom_parser) xml_return))
                  (\ phi -> xml_return (l, (tr, phi)))))))
      (\ tuples -> xml_return (cut_points_to_transitions [] tuples)));

termination_proof_parser ::
  forall a b c d e f.
    (Compare a, Compare b,
      Default f) => (String ->
                      (Xml, ([([Char], [Char])],
                              (Bool, ([String], [String])))) ->
                        Sum_bot (Xml_error String) a) ->
                      (String ->
                        (Xml, ([([Char], [Char])],
                                (Bool, ([String], [String])))) ->
                          Sum_bot (Xml_error String) b) ->
                        ((Xml, ([([Char], [Char])],
                                 (Bool, ([String], [String])))) ->
                          Sum_bot (Xml_error String) (Term c (d, e))) ->
                          ((Xml, ([([Char], [Char])],
                                   (Bool, ([String], [String])))) ->
                            Sum_bot (Xml_error String)
                              (Formula (Term c (d, e)))) ->
                            ((Xml, ([([Char], [Char])],
                                     (Bool, ([String], [String])))) ->
                              Sum_bot (Xml_error String)
                                (Formula (Term c (Trans_var d, e)))) ->
                              ((Xml, ([([Char], [Char])],
                                       (Bool, ([String], [String])))) ->
                                Sum_bot (Xml_error String) d) ->
                                ((Xml, ([([Char], [Char])],
 (Bool, ([String], [String])))) ->
                                  Sum_bot (Xml_error String) e) ->
                                  e -> (Xml,
 ([([Char], [Char])], (Bool, ([String], [String])))) ->
 Sum_bot (Xml_error String) (Termination_proof c d e a b f);
termination_proof_parser location_id_parser trans_id_parser exp_parser
  atom_parser tatom_parser variable_parser type_parser dom_type xml =
  xml_or (xml_do "trivial" (xml_return Triviala))
    (xml_or
      (xml_do "newInvariants"
        (xml_take
          (invariants_parser (location_parser location_id_parser) atom_parser)
          (\ i ->
            xml_take
              (invariant_proof_parser (location_parser location_id_parser)
                (trans_id trans_id_parser) atom_parser i)
              (\ p ->
                xml_take
                  (termination_proof_parser location_id_parser trans_id_parser
                    exp_parser atom_parser tatom_parser variable_parser
                    type_parser dom_type)
                  (\ cp -> xml_return (Invariants_Update_LTS p cp))))))
      (xml_do "switchToCooperationTermination"
        (xml_take
          (cutPoints_parser location_id_parser trans_id_parser tatom_parser)
          (\ cp ->
            xml_take
              (cooperation_proof_parser location_id_parser exp_parser
                atom_parser tatom_parser variable_parser type_parser dom_type
                (sharp_trans_id trans_id_parser))
              (\ p -> xml_return (Via_Cooperation [(cp, p)]))))))
    xml;

ia4_lts_termination_proof_parser ::
  forall a.
    (Default a) => (Xml, ([([Char], [Char])], (Bool, ([String], [String])))) ->
                     Sum_bot (Xml_error String)
                       (Termination_proof Ia4_sig [Char] Ty [Char] [Char] a);
ia4_lts_termination_proof_parser =
  termination_proof_parser xml_text xml_text ia4_exp_parser ia4_atom_parser
    ia4_tatom_parser variable_parser type_parser IntT;

ia4_policy_parser ::
  (Xml, ([([Char], [Char])], (Bool, ([String], [String])))) ->
    Sum_bot (Xml_error String) [(([Char], Ty), Term Ia4_sig ([Char], Ty))];
ia4_policy_parser =
  xml_do "policy"
    (xml_take_many_sub [] zero_nat Infinity_enat
      (xml_do "assignment"
        (xml_take variable_parser
          (\ v -> xml_take ia4_exp_parser (\ e -> xml_return ((v, IntT), e)))))
      xml_return);

ia4_policy_step_parser ::
  (Xml, ([([Char], [Char])], (Bool, ([String], [String])))) ->
    Sum_bot (Xml_error String)
      (([Char], Transition_rule Ia4_sig [Char] Ty [Char]),
        ([(([Char], Ty), Term Ia4_sig ([Char], Ty))],
          [(([Char], Ty), Term Ia4_sig ([Char], Ty))]));
ia4_policy_step_parser =
  xml_do "policyStep"
    (xml_take
      (transition_parser (location_parser xml_text) (trans_id xml_text)
        ia4_tatom_parser)
      (\ tr ->
        xml_take ia4_policy_parser
          (\ post ->
            xml_take ia4_policy_parser
              (\ local -> xml_return (tr, (post, local))))));

its4_proof_parser ::
  (Xml, ([([Char], [Char])], (Bool, ([String], [String])))) ->
    Sum_bot (Xml_error String) Its4_proof;
its4_proof_parser =
  xml_do "proof"
    (xml_take
      (xml_or
        (xml_do "ltsTerminationProof"
          (xml_take ia4_lts_termination_proof_parser
            (\ p -> xml_return (ITS4_Termination p))))
        (xml_do "ltsNonterminationProof"
          (xml_take
            (xml_or
              (xml_change ia4_lts_nontermination_proof_parser
                (xml_return . ITS4_Nontermination))
              (xml_or
                (xml_do "recurrentSet"
                  (xml_take ia4_ground_state_parser
                    (\ init ->
                      xml_take
                        (xml_do "stem"
                          (xml_take_many_sub [] zero_nat Infinity_enat
                            ia4_ground_step_parser xml_return))
                        (\ stem ->
                          xml_take
                            (xml_do "region"
                              (xml_take (formula_parser ia4_atom_parser)
                                xml_return))
                            (\ region ->
                              xml_take
                                (transition_parser (location_parser xml_text)
                                  (trans_id xml_text) ia4_tatom_parser)
                                (\ tr ->
                                  xml_take ia4_policy_parser
                                    (\ post ->
                                      xml_take ia4_policy_parser
(\ local -> xml_return (ITS4_Recurrent init stem region tr post local)))))))))
                (xml_do "recurrentCycle"
                  (xml_take ia4_ground_state_parser
                    (\ init ->
                      xml_take
                        (xml_do "stem"
                          (xml_take_many_sub [] zero_nat Infinity_enat
                            ia4_ground_step_parser xml_return))
                        (\ stem ->
                          xml_take
                            (xml_do "region"
                              (xml_take (formula_parser ia4_atom_parser)
                                xml_return))
                            (\ region ->
                              xml_take
                                (xml_do "cycle"
                                  (xml_take_many_sub [] one_nat Infinity_enat
                                    ia4_policy_step_parser xml_return))
                                (\ steps ->
                                  xml_return
                                    (ITS4_RecurrentCycle init stem region
                                      steps)))))))))
            xml_return)))
      xml_return);

its4_cpf_parser ::
  (Xml, ([([Char], [Char])], (Bool, ([String], [String])))) ->
    Sum_bot (Xml_error String)
      (Lts_impl Ia4_sig [Char] Ty [Char] [Char], (Bool, Its4_proof));
its4_cpf_parser =
  xml_do "certificationProblem"
    (xml_take (xml_text "cpfVersion")
      (\ _ ->
        xml_take
          (xml_do "lookupTables"
            (xml_take (xml_do "ruleTable" (xml_return ())) xml_return))
          (\ _ ->
            xml_take (xml_do "input" (xml_take ia4_lts_input_parser xml_return))
              (\ input ->
                xml_take
                  (xml_do "property"
                    (xml_take (xml_do "termination" (xml_return ()))
                      xml_return))
                  (\ _ ->
                    xml_take
                      (xml_do "answer"
                        (xml_take
                          (xml_or (xml_do "yes" (xml_return True))
                            (xml_do "no" (xml_return False)))
                          xml_return))
                      (\ answer ->
                        xml_take its4_proof_parser
                          (\ proof ->
                            xml_return (input, (answer, proof)))))))));

case_sum_bot :: forall a b c. a -> (b -> a) -> (c -> a) -> Sum_bot b c -> a;
case_sum_bot f g h (Sumbot p) = (case p of {
                                  Inl a -> g a;
                                  Inr a -> h a;
                                });

check_its4_string :: [Char] -> Sum [Char] ();
check_its4_string s =
  case_sum_bot
    (Inl [char_0x49, char_0x54, char_0x53, char_0x20, char_0x70, char_0x61,
           char_0x72, char_0x73, char_0x65, char_0x72, char_0x20, char_0x64,
           char_0x69, char_0x64, char_0x20, char_0x6E, char_0x6F, char_0x74,
           char_0x20, char_0x74, char_0x65, char_0x72, char_0x6D, char_0x69,
           char_0x6E, char_0x61, char_0x74, char_0x65])
    Inl (\ (p, (a, proof)) -> (case check_its4 p a proof of {
                                Inl message -> Inl (explode (message ""));
                                Inr () -> Inr ();
                              }))
    (parse_xml_string its4_cpf_parser s);

}
