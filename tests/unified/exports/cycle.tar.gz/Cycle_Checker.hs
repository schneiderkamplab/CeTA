{-# LANGUAGE EmptyDataDecls, RankNTypes, ScopedTypeVariables #-}

module
  Cycle_Checker(Nat, cycle_nat, check_cycle_embedding, check_cycle_transport,
                 check_cycle_morphism_direction)
  where {

import Prelude ((==), (/=), (<), (<=), (>=), (>), (+), (-), (*), (/), (**),
  (>>=), (>>), (=<<), (&&), (||), (^), (^^), (.), ($), ($!), (++), (!!), Eq,
  error, id, return, not, fst, snd, map, filter, concat, concatMap, reverse,
  zip, null, takeWhile, dropWhile, all, any, Integer, negate, abs, divMod,
  String, Bool(True, False), Maybe(Nothing, Just));
import Data.Bits ((.&.), (.|.), (.^.));
import qualified Prelude;
import qualified Data.Bits;

data Nat = Zero_nat | Suc Nat;

equal_nat :: Nat -> Nat -> Bool;
equal_nat Zero_nat (Suc x2) = False;
equal_nat (Suc x2) Zero_nat = False;
equal_nat (Suc x2) (Suc y2) = equal_nat x2 y2;
equal_nat Zero_nat Zero_nat = True;

instance Eq Nat where {
  a == b = equal_nat a b;
};

data Num = One | Bit0 Num | Bit1 Num;

nth :: forall a. [a] -> Nat -> a;
nth (x : xs) Zero_nat = x;
nth (x : xs) (Suc n) = nth xs n;

less_nat :: Nat -> Nat -> Bool;
less_nat n Zero_nat = False;
less_nat m (Suc n) = less_eq_nat m n;

less_eq_nat :: Nat -> Nat -> Bool;
less_eq_nat Zero_nat n = True;
less_eq_nat (Suc m) n = less_nat m n;

upt :: Nat -> Nat -> [Nat];
upt i j = (if less_nat i j then i : upt (Suc i) j else []);

drop :: forall a. Nat -> [a] -> [a];
drop n [] = [];
drop n (x : xs) = (case n of {
                    Zero_nat -> x : xs;
                    Suc m -> drop m xs;
                  });

take :: forall a. Nat -> [a] -> [a];
take n [] = [];
take n (x : xs) = (case n of {
                    Zero_nat -> [];
                    Suc m -> x : take m xs;
                  });

member :: forall a. (Eq a) => [a] -> a -> Bool;
member [] y = False;
member (x : xs) y = x == y || member xs y;

apsnd :: forall a b c. (a -> b) -> (c, a) -> (c, b);
apsnd f (x, y) = (x, f y);

length_tailrec :: forall a. [a] -> Nat -> Nat;
length_tailrec [] n = n;
length_tailrec (x : xs) n = length_tailrec xs (Suc n);

spell :: forall a b. (a -> [b]) -> [a] -> [b];
spell a xs = concatMap a xs;

one_nat :: Nat;
one_nat = Suc Zero_nat;

divmod_integer :: Integer -> Integer -> (Integer, Integer);
divmod_integer k l =
  (if k == (0 :: Integer) then ((0 :: Integer), (0 :: Integer))
    else (if (0 :: Integer) < l
           then (if (0 :: Integer) < k then divMod (abs k) (abs l)
                  else (case divMod (abs k) (abs l) of {
                         (r, s) ->
                           (if s == (0 :: Integer)
                             then (negate r, (0 :: Integer))
                             else (negate r - (1 :: Integer), l - s));
                       }))
           else (if l == (0 :: Integer) then ((0 :: Integer), k)
                  else apsnd negate
                         (if k < (0 :: Integer) then divMod (abs k) (abs l)
                           else (case divMod (abs k) (abs l) of {
                                  (r, s) ->
                                    (if s == (0 :: Integer)
                                      then (negate r, (0 :: Integer))
                                      else (negate r - (1 :: Integer),
     negate l - s));
                                })))));

plus_nat :: Nat -> Nat -> Nat;
plus_nat Zero_nat n = n;
plus_nat (Suc m) n = plus_nat m (Suc n);

nat_of_integer :: Integer -> Nat;
nat_of_integer k =
  (if k <= (0 :: Integer) then Zero_nat
    else (case divmod_integer k (2 :: Integer) of {
           (l, j) ->
             let {
               la = nat_of_integer l;
               lb = plus_nat la la;
             } in (if j == (0 :: Integer) then lb else plus_nat lb one_nat);
         }));

cycle_nat :: Integer -> Nat;
cycle_nat = nat_of_integer;

word_power :: forall a. [a] -> Nat -> [a];
word_power u Zero_nat = [];
word_power u (Suc n) = u ++ word_power u n;

size_list :: forall a. [a] -> Nat;
size_list xs = length_tailrec xs Zero_nat;

cycle_trace ::
  forall a. (Eq a) => [([a], [a])] -> [a] -> [(Nat, Nat)] -> Maybe [a];
cycle_trace r w [] = Just w;
cycle_trace r w ((i, k) : ss) =
  (if less_nat i (size_list r)
    then (case nth r i of {
           (l, ra) ->
             (if less_eq_nat (plus_nat k (size_list l)) (size_list w) &&
                   take (size_list l) (drop k w) == l
               then cycle_trace r
                      (take k w ++ ra ++ drop (plus_nat k (size_list l)) w) ss
               else Nothing);
         })
    else Nothing);

check_cycle_morphism ::
  forall a.
    (Eq a) => [([a], [a])] ->
                [a] -> [[a]] -> [[Nat]] -> [[(Nat, Nat)]] -> [Nat] -> Bool;
check_cycle_morphism r pivot a f t b =
  equal_nat (size_list f) (size_list a) &&
    equal_nat (size_list t) (size_list a) &&
      not (null b) &&
        all (\ i -> less_nat i (size_list a)) b &&
          all (\ i ->
                all (\ j -> less_nat j (size_list a)) (nth f i) &&
                  cycle_trace r (nth a i ++ pivot) (nth t i) ==
                    Just (pivot ++ spell (nth a) (nth f i)) &&
                    (if member b i
                      then not (null (nth t i)) && any (member b) (nth f i)
                      else True))
            (upt Zero_nat (size_list a));

check_cycle_embedding ::
  forall a. (Eq a) => [([a], [a])] -> [a] -> [(Nat, Nat)] -> [a] -> [a] -> Bool;
check_cycle_embedding ra w ss l r =
  not (null ss) && cycle_trace ra w ss == Just (l ++ w ++ r);

check_cycle_transport ::
  forall a.
    (Eq a) => [([a], [a])] ->
                [a] ->
                  [(Nat, Nat)] ->
                    [a] -> [a] -> Nat -> Nat -> [a] -> Bool -> Bool;
check_cycle_transport r w ss u v p s ext right =
  not (null ss) &&
    not (null u) &&
      not (null v) &&
        less_nat Zero_nat p &&
          less_eq_nat p s &&
            (case cycle_trace r w ss of {
              Nothing -> False;
              Just z ->
                (if right
                  then ext ++ w == v ++ word_power u p &&
                         ext ++ z == word_power u s ++ v
                  else w ++ ext == word_power u p ++ v &&
                         z ++ ext == v ++ word_power u s);
            });

check_cycle_morphism_direction ::
  forall a.
    (Eq a) => [([a], [a])] ->
                [a] ->
                  [[a]] -> [[Nat]] -> [[(Nat, Nat)]] -> [Nat] -> Bool -> Bool;
check_cycle_morphism_direction r pivot a f t b mirrored =
  check_cycle_morphism
    (if mirrored then map (\ (l, ra) -> (reverse l, reverse ra)) r else r) pivot
    a f t b;

}
