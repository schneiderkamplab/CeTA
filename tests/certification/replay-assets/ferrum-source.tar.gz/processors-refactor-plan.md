# Universal Processor Worklist

Last updated: 2026-08-11.

## Invariant

Ferrum has one processor contract for every supported problem kind:

```rust
pub trait WorklistProcessor {
    fn name(&self) -> &'static str;
    fn apply(&self, state: &ProblemState) -> ProcessorResult;
}
```

A successful application contains `Vec<ProblemState>` residuals and a
reconstruction function.  An empty vector means the processor solved its input.
A nonempty vector means every child must be solved before reconstruction may
produce the parent certificate.  Processor implementations do not invoke proof
search recursively and do not own strategy continuations.

The universal state sum covers ordinary TRSs, SRSs, context-sensitive TRSs,
relative TRSs and SRSs, dependency-pair problems, and relative annotated
dependency-pair problems.  SRS states remain distinct from unary TRSs because
their applicability and CPF proof constructors differ.

## Scheduling

Only the top-level and dependency-pair schedulers interpret strategy syntax.
They flatten sequence, choice, parallel, repetition, timeout, and delay nodes
into atomic attempts.  The common lazy worklist:

1. applies one atomic processor;
2. enqueues every returned residual state;
3. asks utility guidance again for each child state;
4. resumes later alternatives when a child branch fails; and
5. reconstructs certificates bottom-up after all children close.

This makes residual states independently guideable and removes the need for
stored composed strategies.

Fallback search is depth-bounded and cost-aware. Deterministic closers are
tried before open-ended transformations in the unguided portfolio, and after
two speculative child steps the retained processor suffix gets a turn. This
prevents repeatable instantiation or narrowing chains from starving a valid
sibling atom without eagerly expanding the whole portfolio.

Strategy atoms are represented by `ConfiguredTopLevelProcessor` and
`ConfiguredDpProcessor`, which implement `WorklistProcessor` directly.  There
is no separate `apply_atomic_*` adapter API.

## Module ownership

Processor structs and their state transitions live under
`src/proving/processors/`:

- `top_level/` contains ordinary TRS/SRS transformations and terminal checks;
- `csr/` contains CSR transformations, rule removal, and loop search;
- `relative/` and `relative_adp/` contain relative processors;
- `dp/` contains one atomic dependency-pair processor per module;
- `worklist.rs` is the only recursive problem scheduler.

Shared algorithms are grouped by mathematical family:

- `dependency_pairs/cap.rs`, `graph.rs`, and `usable_rules.rs`;
- `dependency_pairs/construction.rs` and `proof.rs`;
- `dependency_pairs/semantic_labeling.rs`;
- `dependency_pairs/size_change.rs`;
- `dependency_pairs/transformations.rs`;
- `dependency_pairs/reduction_pair.rs`;
- `nontermination/direct_loops.rs`, `srs_loops.rs`,
  `relative_loops.rs`, `narrowing_loops.rs`,
  `dependency_pair_loops.rs`, `search.rs`, and `validation.rs`;
- `processors/top_level/srs/automaton.rs` for the tightly coupled
  match-bounds/RFC automaton family.

These algorithm modules compute or validate one transition.  They do not run a
worklist or interpret strategy composition.

The former `NonterminationStrategyResult` adapter has been removed. Ordinary
and relative nontermination atoms are `WorklistProcessor` implementations;
their shared `search_nontermination_witness` routine only discovers a checked
terminal witness and never represents processor progress or scheduling.

The SRS match-bounds and RFC automaton searches likewise return typed
`BoundsProof`/`SrsRfcMatchBoundsWitness` data.  Only their worklist processors
construct terminal `ProblemCertificate`s; the automaton algorithms never
return a nested Ferrum `Proof` in production.

Canonical DP identities include the complete executable residual context:
strong and weak pairs, active/graph/transformation rules, Q left-hand sides,
minimality, CSR construction and replacement map, and pair-source provenance.
Set-like collections are order-independent and source indices are remapped
with canonical rule order. Oracle evidence uses only the complete context-safe
identity. Lossless event/runtime aliases are typed as structural and may carry
exact witnesses without copying their canonical evidence row. Semantic
canonical aliases may carry generic atoms but never exact witnesses.

## Certification boundary

Proof reconstruction consumes typed child certificates only.  A positive result
is retained only when its complete CPF is accepted by the configured CeTA-CSR
binary.  Failed synthesis, timeouts, malformed output, and checker rejection
remain non-results.  Structural refactoring does not weaken processor
side-conditions or checker obligations.

## Verification gates

Changes to this architecture require:

- focused worklist and processor-family tests;
- all-target compilation and a release build;
- CPF/CeTA smoke tests for every moved proof shape;
- strict oracle-only category replays with fallback disabled;
- zero certification failures and no loss relative to the frozen category
  baselines;
- `git diff --check`.

Current frozen parity baselines are recorded by the timestamped artifacts under
`target/oracle-integration-global-composition-free-20260808/`.

The bridge-free release replay uses
`target/universal-worklist-evidence-20260808/oracle-global-v722-no-bridge-complete.jsonl`.
Every answer below was produced with fallback disabled and certified by
CeTA-CSR:

| category | certified YES | certified NO | unresolved/timeout |
| --- | ---: | ---: | ---: |
| TRS Context Sensitive | 94 | 4 | 10 / 0 |
| TRS Standard | 758 | 227 | 539 / 4 |
| TRS Innermost | 37 | 6 | 322 / 1 |
| TRS Relative | 45 | 13 | 82 / 0 |
| SRS Standard | 77 | 12 | 1832 / 0 |
| TRS Outermost | 0 | 160 | 119 / 0 |
| SRS Relative | 0 | 0 | 461 / 0 |

All seven replays have zero certification failures.  TRS Standard improves
from the pre-refactor 958 certified answers to 985; the other established
category baselines are retained.  No composed strategy candidate is present
in the oracle.

## Exact-witness reduction plan

The v722 oracle has 401,682 positive state/candidate entries.  Of these,
103,781 are representation-bound `exact-*` entries (2,846 distinct witness
atoms) and 297,901 are generic processor atoms.  Witness reduction must be
measured by strict replay, not by deleting records syntactically.

1. Add selected-candidate identities for rewriting and every remaining
   multi-candidate transformation, matching the existing selected narrowing
   and instantiation atoms.  These are strategy facts rather than solver
   witnesses.
2. Make each bounded synthesis processor deterministic over the canonical
   `ProblemState`: stable constraint order, stable objective, exact model
   validation, and deterministic tie breaking.  Replace an exact witness with
   the smallest generic parameterized atom whenever it reconstructs the same
   certified residual transition.
3. Run a state-wise minimizer in this order: redundant exact candidates,
   exact terminal witnesses already reproduced by a generic atom, exact
   transformation witnesses, then duplicate aliases.  Recheck the affected
   roots after every removal batch and restore a witness immediately on a
   certified-answer loss.
4. Cluster exact polynomial, matrix, Arctic, path-order, loop, and automaton
   witnesses by processor family and inferred parameter envelope.  Probe one
   generic representative per state; promote it only after the complete CPF
   passes CeTA twice.
5. Freeze successive witness-reduced oracles and require the category matrix
   above, zero certification failures, and identical child-state context
   hashes.  Report both entry reduction and the number of roots that still
   intrinsically require a concrete witness.

The first representation-only reduction is complete:

- exact atoms are content-addressed by SHA-256 and stored once;
- semantic and structural aliases are explicit and checked by the runtime;
- 16,581 byte-for-byte duplicate direct rows became one-hop structural aliases;
- the v724 oracle is 278,967,006 bytes, down 47,772,273 bytes (14.62%) from
  v722, without changing any guidance;
- strict v724 replay reproduces every baseline above with zero certification
  failures.

The first evidence prune is also complete. Across all successful strict v724
replays, 1,759 of 2,846 distinct exact witnesses were actually selected. The
v725 oracle retains those witnesses—including failed exact attempts on an
eventually certified chain—and removes 44,892 unselected exact occurrences.
It is 265,789,516 bytes, 18.65% below v722. Full CSR replay and all 670 affected
successful roots in the other categories retain their certified answers with
zero failures.

The next plan is therefore narrower than the original one:

1. Trace the exact state key, selected atom, residual hashes, and reconstructed
   certificate for each of the 1,759 retained witnesses.
2. For each state, run the corresponding deterministic generic processor with
   the witness-inferred parameter envelope. Remove the exact witness only when
   the generic atom produces a CeTA-certified proof with identical residual
   contexts (the concrete model itself need not be identical).
3. Start with polynomial and matrix families, which account for most selected
   occurrences, then Arctic/path orders, and leave semantic-labeling and loop
   witnesses last.
4. After each family batch, replay only affected roots; periodically run the
   full category matrix to detect canonicalization or scheduling drift.
5. Keep a small irreducible witness layer for processors whose concrete model
   is proof information and cannot yet be deterministically rediscovered under
   the 60-second allowance.

The first deterministic rediscovery phase is complete in v738:

- `exact-poly` fell from 872 definitions to 166.  Generic `poly(...)` atoms
  replace 706 models; the retained models are exactly those selected by chains
  that lost their certified answer during the staged probes.
- `exact-matrix` fell from 342 definitions to 23.  Generic `matrix(...)` atoms
  replace 319 natural-matrix models, with inferred dimension and conservative
  constant, coefficient, signature, and arity bounds.
- The total exact-witness layer fell from 1,757 to 732 definitions (58.34%).
  The manifest is
  `target/universal-worklist-evidence-20260808/oracle-global-v738-matrix-large-probe.jsonl`.
- Probes were staged by solver cost rather than imposing a semantic signature
  limit: small signatures first, then up to 20 symbols, then all remaining
  signatures and bounds.
- The final cross-family replay covers the deduplicated union of 587 affected
  roots: 68 CSR, 22 TRS Relative, 23 TRS Innermost, 446 TRS Standard, and 28
  SRS Standard.  All 587 are oracle-only certified, with no fallback and zero
  certification failures.  Every final CPF was accepted by CeTA a second time.

The remaining reduction order is natural Arctic interpretations, path orders,
integer matrices, rational/weak/monotonic polynomials, and finally the smaller
semantic-labeling, subterm, KBO, match-bounds, and loop-sensitive families.

The subsequent v744 Arctic phase replaces another 61 exact models: 51 natural
Arctic witnesses become `arctic-matrix(...)` atoms and ten signed witnesses
become `integer-arctic-matrix(...)` atoms.  Seventy-eight Arctic witnesses are
retained for chains that did not survive deterministic rediscovery.  The
cumulative exact layer is now 671 definitions, down 61.81% from v725.  A final
cross-family replay of 604 affected roots is fully oracle-only certified, and
all 604 CPFs pass a second independent CeTA invocation.  The current candidate
is
`target/universal-worklist-evidence-20260808/oracle-global-v744-arctic-family-safe.jsonl`.

The v749 path-order phase replaces 40 of 178 exact orders with the generic
`path-order` atom.  Path-order synthesis is notably model-sensitive: ten
initial chain regressions and three cross-family/concurrency regressions
required retaining 138 exact orders.  The cross-family audit, rather than only
the baseline selected-atom trace, is therefore the acceptance criterion for
later families.  The final v749 union has 631 exact definitions (64.09% below
v725) and replays all 647 affected roots oracle-only; all 647 certificates pass
CeTA twice.  Its manifest is
`target/universal-worklist-evidence-20260808/oracle-global-v749-path-order-safe.jsonl`.

The v751 integer-matrix phase also fixed a missing generic processor route:
top-level strategies now parse and serialize bounded `integer-matrix(...)`
atoms, and ordinary/relative worklist processors pass the requested finite
interval to synthesis.  Before that fix all 39 affected Relative roots returned
MAYBE; afterwards 37 replayed generically and two required four retained exact
models.  Thus 58 of 62 exact integer matrices are removed.  The cumulative
v751 manifest contains 573 exact definitions (67.39% below v725), and all 668
affected roots certify oracle-only twice with CeTA:
`target/universal-worklist-evidence-20260808/oracle-global-v751-integer-matrix-safe.jsonl`.

The v753 rational-polynomial phase replaces 35 of 40 exact rational models
with bounded `rat-poly(...)` synthesis atoms.  Three chains were sensitive to
the synthesized model and retain the five exact models selected by their
successful proofs.  The cumulative exact layer now contains 538 definitions,
69.38% fewer than v725.  The cross-family audit grew to 685 roots: 70 CSR, 43
TRS Relative, 24 TRS Innermost, 515 TRS Standard, and 33 SRS Standard.  All 685
replay oracle-only without composed strategies or fallback, and every CPF is
accepted by CeTA a second time.  The current candidate is
`target/universal-worklist-evidence-20260808/oracle-global-v753-rat-poly-safe.jsonl`.

The v755 weak-polynomial phase replaces four of eleven exact affine models
with bounded `weak-poly(...)` atoms.  Weak interpretations are particularly
model-sensitive: removing all eleven caused four of five selected chains to
fail, so the seven models used by those proofs remain exact.  The cumulative
manifest now has 534 exact definitions (69.61% below v725).  The same 685-root
cross-family replay remains fully oracle-only certified, and all certificates
again pass a second CeTA invocation:
`target/universal-worklist-evidence-20260808/oracle-global-v755-weak-poly-safe.jsonl`.

The v757 monotonic-polynomial phase replaces 19 of 21 exact models with
bounded `mono-poly(...)` atoms.  Generic synthesis changed the residual rule
set for AG01 `#3.39` and `#3.40`, so those two selected models remain exact.
The cumulative layer is down to 515 exact definitions (70.69% below v725).
All 685 roots still replay oracle-only and all CPFs pass the independent second
CeTA check.  The current candidate is
`target/universal-worklist-evidence-20260808/oracle-global-v757-mono-poly-safe.jsonl`.

The v759 max-polynomial phase replaces three of seven exact models with
bounded `max-poly(...)` atoms, including the required alternative count.  The
`csrdiv` chain still needs its four selected exact models because rediscovery
chooses a different residual.  The cumulative layer now contains 512 exact
definitions (70.86% below v725); all 685 roots and both CeTA passes remain
clean.  The current candidate is
`target/universal-worklist-evidence-20260808/oracle-global-v759-max-poly-safe.jsonl`.

The v760 subterm phase removes all 32 exact projections and replaces them with
the generic `subterm` atom.  All 16 directly affected roots and the cumulative
685-root audit remain certified, including the two affected CSR roots; every
CPF also passes the second CeTA invocation.  The exact layer now contains 480
definitions (72.68% below v725), with no exact subterm witness remaining.  The
current candidate is
`target/universal-worklist-evidence-20260808/oracle-global-v760-subterm-probe.jsonl`.

The v761 KBO phase removes all 34 exact precedence/weight models and replaces
them with bounded `kbo(...)` atoms.  The nine directly affected SRS roots and
the cumulative 685-root audit remain certified, with every CPF accepted on the
second CeTA pass.  The exact layer now contains 446 definitions (74.62% below
v725), with no exact KBO witness remaining.  The current candidate is
`target/universal-worklist-evidence-20260808/oracle-global-v761-kbo-probe.jsonl`.

The v763 semantic-labeling phase replaces 13 of 15 exact carrier-two DP models
with the generic `semantic-labeling` atom.  `JFP_Ex31` and `Ex1_GM99_C` retain
their exact models because generic enumeration reaches the harness deadline.
The three exact Relative models also remain: generic Relative synthesis is
currently carrier-two only, and did not rediscover even the carrier-two
`rt3-5` model.  The cumulative layer now contains 433 exact definitions
(75.36% below v725), while all 685 roots and both CeTA passes remain clean:
`target/universal-worklist-evidence-20260808/oracle-global-v763-semantic-labeling-safe.jsonl`.

The remaining exact match-bounds automaton was also probed against
`match-bounds(max-bound=3)`.  Generic reconstruction leaves SRS `z112`
unsolved, so that single checked automaton remains exact.  At v763 every exact
family has therefore had an initial bounded-rediscovery audit; the 433 retained
definitions are the model-sensitive remainder, not unexamined legacy entries.

The second reduction pass starts by making top-level and Relative polynomial
rule removal expose deterministic lazy alternatives.  A generic `poly(...)`
atom preserves the existing solver result as candidate zero, then offers one
`poly(...,candidate=N)` sibling per rule, requiring that rule to be strict.
Each application still exposes its own conjunctive `Vec<ProblemState>`; the
candidates are disjunctive worklist branches and are appended after existing
processor atoms, so established scheduling is unchanged.

The v770 audit removes another 50 exact polynomial models.  Two semantic-label
models for `Ex16_Luc06_C` are restored as a deliberate performance exception:
without them the proof remains replayable but sits at the 54--62 second
boundary, whereas the retained route takes about 21 seconds.  The net exact
layer is 385 definitions (78.09% below v725), including 116 exact polynomial
models.  The focused 67-root polynomial cohort and the cumulative 685-root
oracle-only replay are fully certified, and all 685 final CPFs pass CeTA a
second time.  The current candidate is
`target/universal-worklist-evidence-20260808/oracle-global-v770-poly-alternatives-safe.jsonl`.

The v772 pass extends the same explicit alternative interface to ordinary DP
and CSR polynomial processors.  DP `poly(...)` now preserves candidate zero
and appends one strict-pair-targeted sibling per strong pair.  CSR polynomial
rule removal analogously accepts a canonical strict-rule candidate and returns
its residual CSR state through the common worklist.  Selected generic attempts
record the bounded candidate atom, while the generated CPF still contains the
concrete interpretation and CeTA checks it normally.

The fully generic polynomial experiment rediscovered seven further roots, but
six of those share their selected polynomial definition with a different root
that still needs it.  Consequently the monotone safe overlay removes one more
exact definition, leaving 384 total and 115 `exact-poly` definitions:
`target/universal-worklist-evidence-20260808/oracle-global-v772-dp-poly-safe.jsonl`.
All 685 cumulative roots replay oracle-only under 32-way load, and all 685
certificates pass an independent second CeTA invocation.  The CSR experiment
also exposed the next optimization target: per-rule candidates frequently
produce the same residual rule set (hundreds of duplicate applications on the
largest systems).  Future reduction must enumerate or memoize distinct
residuals rather than paying for every syntactic rule target; exact witnesses
remain in place until that implementation passes the same parity gate.

The v776 natural-matrix phase adds the analogous strict-pair alternatives to
DP matrix processing.  Candidate zero preserves the existing SAT result;
candidate N requires the Nth strong pair to be strict while retaining all weak
pair, usable-rule, sparsity, dimension, and fixed strict-rule obligations.
Twenty of the 23 remaining exact natural matrices are replaced.  The three
models shared by `Ex1_2_Luc02c_GM` and `PEANO_nokinds_GM` remain exact because
the bounded alternatives do not close those roots.  The cumulative exact
layer now contains 364 definitions (79.28% below v725), including only three
natural matrices.  All 685 roots replay oracle-only under 32-way load and all
685 CPFs pass CeTA independently a second time.  The current candidate is
`target/universal-worklist-evidence-20260808/oracle-global-v776-matrix-alternatives-safe.jsonl`.

The next witness-reduction passes are ordered by impact and by how naturally
the processor exposes independently checkable residual states:

1. Add strict-pair alternatives for the 78 retained Arctic interpretations,
   keeping natural and integer domains distinct and preserving exact
   minus-infinity semantics in the emitted CPF.
2. Enumerate path-order residuals by required strict pair and deterministic
   precedence/filter model blocking.  This targets the largest remaining
   non-polynomial family (138 definitions) without embedding an order model in
   guidance.
3. Extend polynomial alternatives to fixed-usable-rule and CSR-DP contexts,
   then enumerate distinct deletion sets rather than one query per syntactic
   target.  This is required for the 115 hard polynomial definitions.
4. Apply the same bounded candidate protocol to the small rational, weak,
   monotonic, max-polynomial, and integer-matrix families (22 definitions in
   total), processing one family and one parity gate at a time.
5. Expand ordinary and Relative semantic-label model enumeration for the
   seven retained models.  The single match-bounds automaton remains last: its
   current generic constructor does not rediscover `z112`, so removing it
   requires deterministic automaton-state exploration rather than a wider
   opaque timeout.

Every pass remains monotone: probe without the family witnesses, retain the
models selected by failed roots, replay the affected cohort, run the full
685-root oracle-only gate, and check every resulting CPF with CeTA a second
time before promotion.

The v778 natural-Arctic pass implements the first roadmap item for the natural
domain.  Candidate N constrains the Nth strong pair while preserving every
Arctic weak-orientation and well-formedness obligation; structural templates
are accepted only when they delete that same required pair.  Thirty of the 70
retained natural-domain witnesses are removed.  Eleven models selected by the
two failed roots remain, as do 29 models outside the current bounded envelope;
the eight signed-domain models are deliberately untouched.  The cumulative
exact layer is now 334 definitions (80.99% below v725), with 40 natural and
eight signed Arctic witnesses.  All 685 roots and the independent second CeTA
pass remain clean.  The promoted candidate is
`target/universal-worklist-evidence-20260808/oracle-global-v778-arctic-alternatives-safe.jsonl`.

The v779 signed-Arctic pass applies the same residual-alternative protocol to
integer-domain Arctic interpretations.  Candidate N requires the Nth strong
pair to be strict, while exact validation and ordinary CPF export retain the
full signed and minus-infinity semantics.  All eight exact signed models are
replaced by five bounded candidate atoms.  The cumulative exact layer is now
326 definitions (81.45% below v725), with 40 natural Arctic witnesses and no
signed Arctic witness.  A 32-worker gate had one unrelated, load-sensitive
`MYNAT_nokinds_noand_GM` miss which certified on an immediate isolated retry;
the coherent 16-worker gate then replayed all 685 roots, and all 685 CPFs
passed CeTA independently twice.  The promoted candidate is
`target/universal-worklist-evidence-20260808/oracle-global-v779-integer-arctic-alternatives-probe.jsonl`.

The v780 pass raises the natural-Arctic bounded envelope from four to eight.
All 40 input models are dimension one and have finite entries at most seven,
so this stage covers their numeric range without an unbounded search.  The
probe rediscovered four of ten affected roots.  The monotone overlay retains
the 17 exact models selected by the six failed residual chains and replaces
the other 23 with 17 bounded candidate atoms.  The cumulative exact layer is
now 303 definitions (82.75% below v725), including 17 natural Arctic witnesses
and no signed Arctic witness.  All 685 roots replay oracle-only and all 685
CPFs pass CeTA independently twice.  The promoted candidate is
`target/universal-worklist-evidence-20260808/oracle-global-v780-arctic8-safe.jsonl`.

Further numeric widening cannot remove those 17 retained models: their
coefficients are already inside the bound-eight envelope.  Their blocker is
residual/model selection, so they join the later deterministic model-blocking
work.  Path-order model blocking is now the next large architectural phase.

The v781 path-order strict-pair phase adds `path-order(candidate=N)` without
embedding a precedence, status, or argument-filter model.  Candidate zero is
the ordinary deterministic query; candidate N requires the Nth strong DP to
be deleted and independently checks the synthesized order before constructing
the residual state.  The all-generic probe recovered seven of 13 affected
roots.  Six roots require mutually dependent exact-prefix chains, and a
partially retained chain also starved `Ex2_Luc02a_iGM`; retaining that complete
baseline chain restores deterministic replay.  The monotone overlay removes
46 of 138 exact path-order definitions and retains 92.  The cumulative exact
layer is now 257 definitions (85.37% below v725).  All 685 roots replay
oracle-only and all 685 CPFs pass CeTA independently twice.  The promoted
candidate is
`target/universal-worklist-evidence-20260808/oracle-global-v781-path-order-safe2.jsonl`.

The next path-order phase must block already returned precedence, status, and
argument-filter models for each strict-pair target.  This will expose multiple
distinct residual deletion sets and is necessary to replace the six retained
chains atomically; merely widening time or numeric bounds cannot help them.

The subsequent small-family audit found that blind bounded replacement is not
enough for integer matrices (0/2 hard roots), weak polynomials (0/4), rational
polynomials (0/3), max polynomials (0/1), or monotonic polynomials (0/2).
Strict-pair integer-matrix alternatives were also probed and discarded because
they did not improve either Relative chain.  These families require explicit
target residual/deletion-set constraints, especially in fixed-usable-rule and
Relative contexts; wider numeric envelopes only repeat the wrong model.

Carrier-two semantic labeling does provide a safe incremental gain.  The v788
probe removes two of four exact ordinary semantic-label models, while retaining
the models selected by `JFP_Ex31` and `Ex1_GM99_C`.  All three affected roots
replay with the mixed overlay.  The cumulative exact layer is now 255
definitions (85.49% below v725).  All 685 roots replay oracle-only and all 685
CPFs pass CeTA independently twice.  The promoted candidate is
`target/universal-worklist-evidence-20260808/oracle-global-v788-semantic-safe.jsonl`.

The next implementation step is target-residual synthesis: derive the exact
set of pairs/rules deleted by each retained certified processor event, pass
that set as a non-witness search constraint, and record only the generic atom
plus residual identity.  Apply it first to the 92 path-order and 115 polynomial
definitions, then reuse it for the 17 Arctic and 22 small arithmetic models.

The v789 pass implements target-residual synthesis for DP path orders.  The
oracle atom `path-order-target(strict=...)` records only the indices of the
pairs deleted in the certified child state.  It does not retain precedence,
symbol status, argument filtering, or another order witness: Ferrum synthesizes
those data afresh and asserts both that every target pair is strict and that
every non-target pair is not strict.  The extraction is state-local and uses
the semantically canonical DP-state key, so the 100 selected events remain
independently addressable despite serializer aliases.

All 92 remaining exact path-order definitions are removed.  The seven affected
roots replay and certify in the focused gate, then the complete 685-root
oracle-only gate passes under 16-way load: 515 TRS Standard, 24 TRS Innermost,
43 TRS Relative, 33 SRS Standard, and 70 CSR roots.  Every generated CPF passes
two additional independent CeTA-CSR invocations.  The cumulative exact layer
now contains 163 definitions, 90.72% below the original 1,757.  The promoted
oracle is
`target/universal-worklist-evidence-20260808/oracle-global-v789-path-order-targets.jsonl`.

The next highest-impact phase is the same state-local deletion-set interface
for the 115 exact polynomial interpretations.  It must cover ordinary DP,
fixed-usable-rule, and CSR rule-removal states without retaining polynomial
coefficients.  Once that full parity gate passes, reuse the protocol for the
17 Arctic and 22 small arithmetic witnesses; deterministic match-bounds state
exploration remains the final isolated exact family.

The v790 polynomial phase adds `poly-target(...)` at every worklist level that
can perform linear-polynomial deletion: ordinary and innermost DP states,
fixed-usable-rule and CSR-DP states, top-level TRS/SRS states, Relative states,
and native CSR states.  The atom retains a bounded search envelope and the
certified residual deletion set, but no polynomial constants or coefficients.
Ferrum synthesizes a fresh interpretation while asserting that precisely the
target rules or pairs are strict; exact validation and normal CPF construction
remain unchanged.

The initial all-target probe certifies 14 of the 52 affected roots.  The safe
overlay restores complete state chains—not partial model prefixes—for the 38
misses, retaining 81 exact polynomials and removing the other 34.  Building
that overlay exposed and fixed an important canonicalization detail: raw and
structural oracle aliases can point through another canonical row, so chain
restoration must follow alias targets transitively.  Target extraction likewise
records raw, whitespace-independent structural, and semantic-canonical keys.

The 52-root focused gate then certifies 36 TRS Standard, 10 TRS Innermost, and
six CSR roots.  The full 685-root oracle-only gate also remains clean, and all
685 generated CPFs pass two additional independent CeTA-CSR invocations.  The
exact layer now contains 129 definitions, 92.66% below the original 1,757,
including 81 exact linear polynomials.  The promoted oracle is
`target/universal-worklist-evidence-20260808/oracle-global-v790-poly-targets-safe.jsonl`.

The next reduction should apply the same deletion-set constraint to the 17
remaining natural-Arctic models and then to weak, rational, max, monotonic, and
integer-matrix processors.  The retained 81 linear polynomials are not a
numeric-bound problem: their target queries either have no model in the
current specialized encoding or expose a continuation that differs from the
certified chain.  Further progress there requires model enumeration within a
fixed deletion set or a stronger complete polynomial encoding, not larger
opaque witness records.

The v792 natural-Arctic phase adds `arctic-target(...)` for DP states.  Like
the path-order and polynomial target atoms, it stores the certified residual
deletion set and a finite synthesis envelope, but no matrix entries.  Ferrum
synthesizes a new natural-Arctic interpretation and requires exactly the
target pairs to be strict; structural templates and SMT models are subjected
to the same constraint and exact validation before ordinary CPF emission.

Four of the six affected roots replay with target synthesis alone.  The safe
overlay restores the complete state chains for the two model-sensitive roots,
`Ex4_7_56_Bor03_GM` and innermost `Ex1_2_Luc02c_iGM`, retaining 11 exact
models and removing six.  All six affected roots then certify, followed by the
complete 685-root oracle-only gate: 515 TRS Standard, 24 TRS Innermost, 43 TRS
Relative, 33 SRS Standard, and 70 CSR.  Every resulting CPF passes two further
independent CeTA-CSR invocations.  The exact layer now contains 123 definitions,
92.999% below the original 1,757.  The promoted oracle is
`target/universal-worklist-evidence-20260808/oracle-global-v792-arctic-targets-safe.jsonl`.

The next phase is the small arithmetic group: weak, rational, max, monotonic,
and integer-matrix interpretations.  Each should receive the same explicit
residual-target interface and its own focused and full parity gate.  Semantic
labeling and match bounds remain separate because their useful child state is
not characterized solely by a deleted rule or pair set.

The v794 weak-polynomial phase adds `weak-poly-target(...)`.  It preserves the
negative-constant search interval and CeTA affine comparison semantics while
requiring exactly the certified DP deletion set; it does not store polynomial
coefficients.  The CSR proof for `Maude_06/LengthOfFiniteLists_complete`
replays with fresh synthesis.  The three Standard roots remain chain-sensitive,
so their complete original state chains retain six exact models.  One of seven
weak-polynomial witnesses is removed, reducing the exact layer to 122
definitions.  The focused four-root gate and complete 685-root oracle-only
gate pass, and all 685 CPFs pass two additional independent CeTA-CSR runs.  The
promoted oracle is
`target/universal-worklist-evidence-20260808/oracle-global-v794-weak-poly-targets-safe.jsonl`.

Rational-polynomial targets are next, followed by monotonic and max-polynomial
targets.  Integer matrices are Relative top-level processors and therefore
need an analogous rule-target representation rather than DP-pair indices.

The v797 rational pilot deliberately avoids pair identities.  Its
`rat-poly-target(...)` atom stores the numeric envelope, `min-delete=N`, and
`residual-budget=1`.  The QF_BV query constrains the number of strictly
oriented pairs but is otherwise free to choose the first model and residual.
`kabasci03` replays immediately with this advice.

The initial strict run of `MNZ_10/0` and `Secret_06_TRS/2` failed because the
new first residual states had no oracle rows, not because the residuals were
unhelpful.  Focused fallback runs solved both roots and their complete CPFs
passed CeTA twice.  Importing those certified child chains—without replacing
the inherited parent choices—then made both roots strict-oracle replayable
with budget one.  This validates the intended worklist design: accept a fresh
processor result, index its child, and learn the continuation there instead of
forcing the old residual by pair position.

The resulting oracle retains four exact rational witnesses, now in deeper
newly exposed continuations, versus five before the phase.  The full 685-root
oracle-only gate and two additional CeTA passes are clean.  The promoted oracle
is
`target/universal-worklist-evidence-20260808/oracle-global-v797-rat-min-delete-plus-children.jsonl`.

Before increasing any residual budget, repeat this procedure for other
failures: first freeze certified continuations for the budget-one residual.
Only a child that remains unsolved after focused recovery justifies asking the
processor for a second distinct residual.

The v831 continuation applies that rule to every remaining rational witness
and then to the larger arithmetic witness classes.  Linear polynomial
processors now accept `poly-min-delete(...)` consistently at DP, top-level
TRS/SRS, and native CSR worklist levels.  The atom retains only a synthesis
envelope and the minimum number of rules or pairs to delete; its
`residual-budget` remains one.  Newly selected residual states are learned
from certification-gated fallback event logs and recursively receive their
own state-local guidance.  This removes every exact rational witness and all
exact weak-polynomial and subterm witnesses.

Natural-Arctic, ordinary natural-matrix, max-polynomial, integer-matrix, and
semantic-labeling families were then probed with the same focused-recovery
protocol.  Exact witnesses were retained only when the generic replacement
and an isolated 60--120 second recovery both failed.  The exact layer falls
from 117 definitions in v798 to 41 in v831: 19 linear polynomials, four max
polynomials, four integer matrices, three natural Arctic matrices, three
natural matrices, three relative semantic-labeling models, two monotonic
polynomials, two ordinary semantic-labeling models, and one match-bounds
witness.  The retained linear definitions are the minimal complete chains for
ten roots whose newly selected children are not yet closed by current search.

The full v831 oracle-only gate certifies all 685 retained roots: 515 TRS
Standard, 24 TRS Innermost, 43 TRS Relative, 33 SRS Standard, and 70 CSR.
Every generated CPF passes two additional independent CeTA-CSR invocations.
The candidate oracle is
`target/universal-worklist-evidence-20260808/oracle-global-v831-linear-parity-safe.jsonl`.

The comparison harness now writes summary and detail checkpoints after each
completed category, using atomic replacement so an interruption cannot leave
a truncated multi-category report.  Witness-migration tools can consume
additional certified event streams, preserve zero-residual terminal steps,
and retain only the requested failed witness family while keeping newly
learned child-state rows.  These changes make the next reductions auditable:
start with the two monotonic-polynomial witnesses, then relative semantic
labeling and match bounds, retaining an exact definition only after focused
recovery demonstrates a real search gap.

The v833 monotonic-polynomial phase removes both remaining exact models.  A
generic probe exposed uncovered residuals for `AG01/#3.39` and `#3.40`; a
focused fallback closed them, and importing only non-exact actions made both
strictly replayable.  The exact layer is therefore 39 definitions, with no
exact rational, weak-polynomial, monotonic-polynomial, or subterm witnesses.

This phase also hardened the state-first exporter.  Witness-definition rows
are now preserved as first-class oracle metadata, campaign imports may exclude
exact candidates while still learning residual states, and only records
actually touched by a campaign are normalized.  The previous global re-rank
changed an unrelated root's executable schedule and caused a reproducible
timeout; preserving untouched base order fixes it.  The corrected v833 gate
again certifies all 685 roots, and all 685 CPFs pass two further CeTA-CSR
checks.  The promoted candidate is
`target/universal-worklist-evidence-20260808/oracle-global-v833-mono-learning.jsonl`.

The v835 phase parameterizes synthesized relative semantic labeling by carrier
size.  Carrier two retains the existing goal-directed SAT synthesis; larger
carriers first try a canonical, witness-free constant interpretation whose
result is checked by the ordinary labeling validator.  This makes the
carrier-three `AProVE_24/depGraph` and carrier-four `Relative_05/rt3-4`
proofs replay without stored models.  The carrier-two `rt3-5` search still
does not rediscover its certified model and retains the sole exact relative
semantic-labeling witness.  The exact layer falls to 37 definitions.  The
complete 685-root gate and two additional CeTA-CSR passes remain clean with
`target/universal-worklist-evidence-20260808/oracle-global-v835-relative-semantic-safe.jsonl`.

## Exact-witness reduction checkpoint (2026-08-11)

The current parity-preserving oracle contains 37 exact witness definitions and
no inline exact candidates.  This is down from 1,757 original definitions
(97.9% removed) and from 117 at the start of the minimum-deletion phase (80
removed, or 68.4%).  The retained definitions are:

| Family | Exact definitions |
| --- | ---: |
| linear polynomial | 19 |
| max polynomial | 4 |
| integer matrix | 4 |
| natural Arctic matrix | 3 |
| natural matrix | 3 |
| ordinary semantic labeling | 2 |
| relative semantic labeling | 1 |
| match bounds | 1 |
| rational polynomial | 0 |
| weak polynomial | 0 |
| monotonic polynomial | 0 |
| subterm | 0 |
| **Total** | **37** |

The verification baseline is 685/685 strict oracle-only roots certified: 515
TRS Standard, 24 TRS Innermost, 43 TRS Relative, 33 SRS Standard, and 70 CSR.
All 685 generated CPFs passed two additional CeTA-CSR checks.  The singleton
match-bounds witness for `SRS_Standard/Zantema_04/z112.ari` was replaced by
bounded generic advice and tested both strictly and with an isolated
120-second fallback.  Both returned MAYBE, so this witness is retained as a
demonstrated search gap rather than an unexamined dependency.

Continue with the 19 linear-polynomial definitions first, learning and
recursively guiding every newly selected residual before increasing the
residual budget above one.  Then address natural matrix/Arctic synthesis,
followed by max polynomial and integer matrix.  The remaining semantic and
match-bounds models should be revisited only with a concrete strengthening of
their model search or residual exploration.
