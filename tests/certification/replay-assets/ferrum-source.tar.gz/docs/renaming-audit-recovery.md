# Renaming audit recovery (2026-09-14)

This diagnostic report does not replace the certified-root ledger in
[state-of-the-art.md](state-of-the-art.md). No composite proof actions have
been enabled. This task made no CeTA source or production-checker changes;
unrelated work in the shared CeTA tree was left untouched.

All artifacts below are relative to `target/renaming-fixes-20260914/`.

## The 38 differing action cases

All 38 now match in original/renamed action comparisons:

| Class | Cases |
| --- | ---: |
| Exact subterm/rational polynomial | 6 |
| Size change | 10 |
| Top-level uncurrying | 3 |
| Nontermination | 1 |
| Integer-Arctic matrix | 5 |
| KBO | 3 |
| Monotonic usable polynomial | 1 |
| Path order | 8 |
| Natural matrix | 1 |

Fixes include bounded SCT model/graph-pattern blocking, pair-order deletion
priorities, structural matrix variable declaration order, and explicit
top-level uncurrying application-role parameters. Models still undergo exact
validation. Application roles are derived from structure, not benchmark names.
Witness transport now accounts for the importer's normalized fresh CSR wrapper.

The nontermination case needs a lenient allowance: original 12.486 seconds,
renamed 74.270 seconds in the isolated run, both twice certified. Its timing
disparity is not fixed. The audit establishes recovery for these cases with
the default backend, not universal timing or solver-model invariance.

## The 24 previously uncovered witness transports

All 24 now transport and compare equal, addressed smallest classes first:

- Three singletons: weak polynomial, semantic labeling, monotonic polynomial.
  Model symbols containing angle brackets must not be mistaken for XML.
  Typed labels follow the native CPF import encoding. Unused model-only symbols
  receive fresh injective names rather than guessed aliases to live functions.
- Seven path-order-removal actions: their optional raw-XML `source-hex`
  context now uses the same mapping as the input and model.
- Fourteen polynomial actions: transport now handles their encoded labeled
  symbols.

## Combined verification

`unified-62-v18/results.jsonl` and
`unified-62-v18-equivalence.jsonl` establish **62/62 equal** against one frozen
executable: 124 successful action executions, comprising **46 terminal proofs
each certified twice** and 78 open transformations. Open transformations are
not counted as certified terminal results.

Frozen executable: `ferrum-v18`, SHA-256
`f5efc40a06bc8d69ba96c47376ca87e8125025dfd23ab3a779c84bdcc66347bf`.

The full release Rust test run passes **942 tests, zero failures, zero ignored**
(including the CSR OvCons production-CeTA regression). Python audit tests pass
16/16; modular tests 26/26; replay tests 10/10; extraction tests 204/204;
monotone-merge tests 11/11.
Logs are under `/tmp/ferrum-renaming-*`.
One unrestricted concurrent v18 run had a persistent-SMT closed-stdout failure
(941 passes, one failure). That test passed in isolation, and the full run with
four test threads passed 942/942 in 48.23 seconds. Nothing was ignored.
The final capability guard prevents Z3 optimization commands reaching the
automatic cvc5 fallback when Z3 is absent. A cvc5-only KBO probe also solved
and certified twice (`cvc5-only-kbo-v2.*`).
The audit now rejects missing requested indices instead of reporting an empty
success; `unified-62-v17` was such an empty invocation and is not evidence.

## Root integration

Changed solver models expose residuals that the previous oracle never visited.
The initial complete guard, `full-guard-v17-oracle-v5`, retained 1,746/1,759
certified roots with 13 losses and zero checker failures. This is diagnostic,
not a replacement baseline.

Root recovery uses separately keyed native actions, never whole-proof wrappers:

- Explicit uncurrying roles recover AG01/#3.53 and #3.55.
- Modular continuation hints recover Ex15_Luc98_FR and id_inc.
- A bounded existing first-pair-strict matrix alternative restores the CSR
  OvCons default strategy; its newly generated source proof certified twice.
- Batch extraction now normalizes TPDB-prefixed manifest paths before filtering
  runtime traces. Previously that filter silently discarded relevant traces.
- Source-bound reduction-pair actions retain their conservative context/shape
  gates. Reusable matrix/polynomial models are additionally offered as **weak**
  state-local hints; Ferrum independently checks their live obligations.
  No action is promoted merely because its source root certified.

`guard-losses-v14` recovers **13/13** initial losses, including CSR and
Innermost OvCons. `final-guard-v17-oracle-v14` then passed **1,759/1,759**.
After the backend-capability guard, the final binary independently retained
**1,759/1,759** again in `final-guard-v18-oracle-v14`:

- Standard: **1,338** (1,039 YES, 299 NO).
- Innermost: **311** (301 YES, ten NO).
- CSR: **110** (105 YES, five NO).

`comparison.json` records zero missing inputs, losses, polarity changes, or
uncertified decisions. `twice-rechecked.jsonl` records **3,518 successful
additional CeTA checks**, with proof hashes unchanged between checks.
Both full runs used strict no-fallback/state-local scheduling, 48 workers,
two Rayon threads, a 180-second strategy ceiling and a 185-second harness
ceiling. These preserve the certified-root set; they are not new full-category
coverage scores. Observed cache-excluded memory stayed below 0.6 TB.

`oracle-v14-audit.json` verifies 517,541 states and 20,917 modular witnesses,
with zero composite termination/nontermination actions, malformed records,
or dangling witness references. Oracle SHA-256:
`84b778e6f56eecf260ad12300956a8b61cdef26fdb874822c2c91c0a15acc972`.

Production checker: `/work/dfm/festschrift/CeTA-CSR/ceta`, SHA-256
`a6d8977c1738daa3e225f0e52443fb56659d09b175516d4215bcd77a3bf0ab46`.
