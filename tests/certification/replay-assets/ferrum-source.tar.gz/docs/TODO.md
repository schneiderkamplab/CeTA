# Ferrum TODO

Last updated: 2026-08-04.

## Relative TRS and SRS

- Relative natural/integer matrix, KBO, and monotone identity-filter path-order
  rule removal are implemented and CeTA-certified. Remaining order work is
  transformation-assisted search and broader classes where corpus evidence
  justifies them.
- Relative root-equivalent semantic labeling and complete flat-context closure
  are implemented and CeTA-certified; together they close
  `Relative_05/rt3-4` and `rt3-5`. Extend semantic labeling with broader
  finite/quasi-model synthesis when corpus evidence justifies the added search.
- Finish certification of the IJCAR 2024 relative annotated dependency-pair
  framework. Ferrum has canonical A1/A2 ADPs, recursive graph decomposition,
  a verified move-to-main precursor to DRP1, and annotated polynomial reduction
  pairs. The isolated CeTA tree
  now checks canonical local steps, covering VRFs, one/two-origin predecessor
  construction, finite origin-path composition, semantic nontermination
  pullback, and productive blocks consisting of base steps plus preserved-origin
  strict Case `(r)` steps followed by a main Case `(pr)` step. The block prefix
  uses the actual weak ADP relation `adp_step (P union Q)`. Further thin children
  now embed serial productive blocks in
  the relative ADP relation and prove a conditional hard chain criterion. Its
  sole remaining premise is `relative_origin_productive`: the paper's global
  two-origin context construction that repeatedly obtains a productive block
  and embeds the next block below its continuation mark. Do not replace it by
  the invalid two-nonterminating-position shortcut from IJCAR Example 24.
  Finite two-origin traces, trace-to-block conversion, contextual lifting,
  root-to-global bridging, and the direct-root strict base case are checked in
  separate child sessions. Finite non-root prefixes and the branch where the
  first root step is strict `R` are checked. The root-`B` branch has checked multihole
  syntax, carrier invariants, preservation under below-hole strict/base steps,
  the concrete RHS-origin context update, and its pairwise origin-transfer
  theorem. The invariant ranges over retained positions whose current symbol
  is defined, since only those positions can be annotated by canonical ADPs.
  Structural fill/unfill decomposition, the assembled root-base state
  transition, abstract carrier-refinement composition, concrete hole-position
  transport, and the proof that every new hole is a descendant of an old hole
  are checked. Canonical old-hole witnesses, pairwise parallelity for new holes
  with the same owner, concrete carrier refinement, the combined root-base
  carrier transition, and combined inner strict/base transitions are also
  checked. Initial carriers are proved relatively terminating, and every inner
  rewrite is reflected by a one-coordinate carrier-list step. The thin
  `Relative_ADP_Carrier_Run_Dev` session now also proves that componentwise
  relative termination lifts to the finite carrier list and applies this to
  the initial carriers. The global carrier induction is now complete in CeTA
  worktree `/work/dfm/festschrift/CeTA-CSR-relative-adp`, branch
  `codex/relative-adp-20260811`, commit `13b5b42`. Isabelle checks
  `relative_root_origin_productive_direct` and
  `canonical_relative_adp_SN_imp_relative_SN`: finite base prefixes transport
  the origin state, the finite product of terminating carriers is the
  well-founded measure, inner strict steps recurse, and the first strict
  context step supplies the productive origin witness.
  Do not assume `SN (suptrel B)`, which is not implied by base nonduplication.
  The erased monotone reduction-pair processor is now formally proved and fully
  exposed through the executable XML checker in the same CeTA worktree. Ferrum
  invokes it as `relative-adp-erasure-reduction-pair`, forces graph processing
  on its residual, emits `<relativeAdpTerminationProof>`, and prefers the
  integrated sibling checker. Canonical A1/A2 reconstruction, base
  nonduplication, recursive residuals, index bounds, monotonicity, and all weak
  and strict orientations are checked. A graph-child reduction pair is emitted
  directly on the canonical problem only when its strict erasure classes cover
  every canonical main ADP; this normalization is then rechecked by CeTA.
  Remaining work is the genuine productive SCC/minimal-lasso graph theorem and
  checker, the paper's `Com`-monotone annotated reduction pair, and DRP1/
  derelatification. Ordinary relative
  `dpTrans` merges `R/S` and cannot
  certify the 44 AProVE uncertified-only YES proofs using this framework.
- Continue broader generic relative-loop search beyond the now-complete
  TermCOMP slice. Mixed strict/weak witnesses and recursive symbolic closing
  substitutions are represented natively in CPF. Ferrum CeTA-certifies all 11
  AProVE_cert TRS Relative NOs and both additional AProVE uncertified-only NOs.
- Decide on a certified representation for SRS rules with an empty left-hand side. The direct unary-TRS CPF encoding is rejected by CeTA's well-formedness check and must not be emitted as certified.
- Expose relative processor composition through the strategy language instead of the initial fixed polynomial/relative-bounds entry strategy.

## Certification

- Extend CPF/CeTA support where Ferrum's processors need proof objects that are
  not currently accepted by the standard checker.
- Keep the default strategy restricted to processors whose YES/NO results can
  be reflected to the original problem and, where applicable, certified by CeTA.
- Add CeTA smoke tests before enabling any new certified processor in the
  default strategy.
- For candidate-only processors, keep results as MAYBE/UNKNOWN until a checked
  certificate path exists.

## SRS

- SRS strategy/runtime audit from
  `target/termcomp-runs/20260715-084417-srs-standard-128-60s`:
  - after fixing deadline polling in SRS nontermination search, a 128-example
    rerun of old timeouts produced 128 MAYBEs and 0 timeouts in 13s;
  - processors/branches that need explicit local budgets on SRS workloads are
    generic `termination`, DP path orders, DP matrix interpretations,
    max-polynomial, top-level KBO, top-level polynomial, and the SRS NO branch;
  - cheap processors that can run eagerly or in parallel are subterm/SCT,
    strict and weighted SRS length, ordinary match-bounds, direct/SRS loops,
    variable condition, and candidate generation for narrowing/instantiation.
- Split the SRS default strategy into explicit parallel portfolios:
  - YES portfolio: strict/weighted length, ordinary match-bounds, reversed
    match-bounds, certified SRS weighted rule removal, RFC/relative
    match-bounds candidates once certifiable, top-level polynomial/KBO, and
    generic DP fallback under a small local budget;
  - NO portfolio: variable condition, direct loops, SRS word loops, reversed
    SRS loops, overlap-closure/non-loop search, and bounded
    rewriting/narrowing under local budgets;
  - success in one branch must cancel sibling branches and kill active solver or
    search subprocesses.
- Strengthen ordinary match-bounds to Matchbox-level power:
  - exact RHS-path insertion now reuses existing compatible path prefixes
    instead of allocating fresh intermediate states for every completion step;
  - strategy syntax now supports
    `match-bounds(max-bound=N,max-states=N,max-transitions=N)` for controlled
    high-budget certified ordinary match-bounds experiments;
  - a 128-example prior-UNKNOWN SRS sample with high-budget ordinary
    match-bounds alone still produced 0 YES, so the next high-impact bounds
    work is RFC/relative/roof bounds rather than only larger ordinary limits;
  - continue improving state merging/generalization without losing CeTA
    compatibility;
  - add regression tests from SRS_Standard and Matchbox/AProVE proofs.
- Strengthen certifiable SRS weighted-length processors:
  - `srs-weighted-rule-removal(max-weight=N)` now synthesizes a weighted-length
    reduction pair, removes all strictly decreasing SRS rules, and emits the
    existing CPF-certified monotone polynomial rule-removal proof;
  - symbol weights may be zero when the final polynomial certificate permits
    it; strictness is still required for every removed rule;
  - the default SRS YES portfolio runs this processor alongside all-strict
    weighted length, match-bounds, reversed match-bounds, top-level polynomial,
    and KBO.
- Implement RFC match-bounds with a certified story:
  - Ferrum now has `rfc-match-bounds(...)`, and bounded direct RFC is enabled
    in the default SRS YES strategy;
  - it computes finite right-hand-side forward closures under SRS rewriting,
    fails rather than truncating when `max-words` or `max-word-len` is exceeded,
    and uses the finite language as the initial language for match-bounds
    completion;
  - a fixed 256-example prior-unsolved probe produced 243 raw YES candidates;
  - Ferrum now emits CPF3 `<rfcBounds>` with explicit `<initialTerms>` and a
    nested `<bounds>` object; direct RFC smoke tests certify with the patched
    CeTA checker;
  - the patched CeTA parser/checker now has a certified `Rfc_Bounds` proof
    object that checks finite initial-language templates with at most one
    variable, automaton acceptance for every selected tail state, RHS coverage,
    signature containment, and closure under the executable RFC narrowing step;
    the executable step is proved equal to IsaFoR's
    `right_forw_closure string_rename` narrowing relation;
  - `/work/dfm/festschrift/CeTA-rfc` now contains the direct
    finite-initial-language theorem, but the executable `rfc_bounds_tt` still
    extracts ordinary bounds facts through `check_bounds_generic`; therefore
    currently certified RFC proofs must also satisfy CeTA's global
    `lift0(T(Sigma))` automaton side condition;
  - the RFC-capable CeTA executable was regenerated from Isabelle `Code`
    session exports and installed as
    `/work/dfm/festschrift/ferrum/.tools/ceta-relative-bounds`;
  - Ferrum now seeds RFC automata with final-state signature loops so simple
    non-empty unary RFC certificates pass CeTA, and declines empty-LHS/empty-RHS
    RFC certificates until the empty-word narrowing case is certified;
  - CeTA-rfc now has `check_bounds_generic_without_contains` and
    `check_bounds_generic_without_contains_exact`, verified by `IsaFoR_2`, and
    `rfc_bounds_tt` uses them directly; RFC proofs no longer require global
    `lift0(T(Sigma))` acceptance;
  - CeTA-rfc now also has a conservative certified `<rfcRelativeBounds>`
    checker. The current theorem accepts deletion of exactly all current strict
    rules for full rewriting problems with empty Q and weak components, and
    reduces soundness to the verified direct RFC theorem plus an empty residual
    proof;
  - Ferrum has an opt-in
    `rfc-relative-match-bounds(max-bound=...,max-words=...,max-word-len=...,max-states=...,max-transitions=...)`
    strategy processor that emits this proof shape. The real TPDB example
    `SRS_Standard/Zantema_04/z061.ari` certifies with
    `.tools/ceta-relative-bounds`;
  - Ferrum no longer seeds finite-initial RFC automata with final-state
    signature loops;
  - 2026-07-18 TRS Standard SK90 certificates exposed that
    `string-reversal(rfc-match-bounds(...))` can produce finite initial
    languages that Ferrum considers closed but CeTA rejects under its
    executable one-step RFC narrowing check. Reversed RFC is therefore
    temporarily excluded from the default strategy; the next RFC correctness
    task is to align Ferrum's reversed/unary closure generator exactly with
    CeTA's `rfc_narrows_impl`, then re-enable and benchmark it;
  - next step after that is to implement and certify Matchbox-style
    `RelRFCmb` merge-at-bound/epsilon semantics and non-empty residual relative
    RFC deletion, then rerun Ferrum's RFC SRS candidates.
  - a focused 653-example `SRS_Standard` Matchbox-RFC run with only
    `rfc-relative-match-bounds(max-bound=3,max-words=10000,max-word-len=128,max-states=2000,max-transitions=50000)`
    produced 1 YES / 1 certified YES and 652 MAYBE; see
    `target/termcomp-runs/20260718-srs-standard-653-rfc-relative-32w-20s-rerun`;
  - a naive attempt to model Matchbox `at_bound = Merge` by capping strict RHS
    heights inside the existing certified completion loop was rejected by CeTA
    on ordinary/relative certificates, so the merge-at-bound implementation
    must be a separate proof object with explicit epsilon/merge semantics and a
    dedicated CeTA theorem.
  - 2026-07-18 update: Ferrum now carries explicit bounds
    `stateCompatibility` relations in `BoundsProof` and emits CPF3
    `<criterion><stateCompatibility>...`; `.tools/ceta-relative-bounds`
    accepts a real explicit-relation smoke certificate. The SRS match-bounds
    completion code now returns a completion object containing both the tree
    automaton and the state relation, so future merge/epsilon completions can be
    exported without another proof-object refactor.
  - 2026-07-18 update: the strategy language accepts
    `at-bound=exact|merge` for `rfc-match-bounds(...)` and
    `rfc-relative-match-bounds(...)`. `exact` is still the default. The current
    `merge` mode only caps strict RHS transition heights and is not yet added to
    the default SRS strategy, because Matchbox examples such as
    `SRS_Standard/Zantema_04/z031.ari` fail before certificate generation: the
    existing CeTA RFC checker requires an explicitly finite
    `rfc_initial_closed` list, while Matchbox `RelRFCmb` proves the right-forward
    closure by automaton acceptance/merge instead of enumerating it.
  - 2026-07-18 automaton-closure implementation: Ferrum has a separate
    `RfcAutomatonClosedBounds` proof step and emits CPF3
    `<rfcAutomatonClosedBounds>`. The SRS saturation implements the finite-state
    split rule: for every split `L = S M` of a left-hand side and every
    automaton path reading `M` then `S`, add the corresponding right-hand-side
    path.
  - 2026-07-22 exact automaton-closed export: Ferrum now has a conservative
    exact witness path that tries universal/exact automaton-closed completion
    before declining. It only exports `<rfcAutomatonClosedBounds>` when the
    generated automaton satisfies the same all-state initial acceptance,
    split-closure, lhs-suffix-totality, and local compatibility conditions as
    CeTA-rfc. Smoke tests show this safe path still does not recover the old
    merge-style raw RFC candidates.
  - 2026-07-22 relative-chain theorem status: CeTA-rfc contains a verified
    automaton-closed relative SN-on-RFC theorem, but that is not yet enough for
    a processor with non-empty residual rules. A direct attempt at a general
    relative RFC equivalence exposed the real missing argument: weak-only
    `K` steps cannot be treated as strict multiset decreases. The next proof
    task is to formalize the subsequence/chain extraction over infinitely many
    strict `D` steps, producing infinitely many strict RFC narrowing steps while
    allowing finite weak stretches between them. Until that theorem is
    certified, CPF `<rfcAutomatonClosedRelativeBounds>` remains parsed but
    intentionally rejected by the local checker.
  - 2026-07-22 update: the remaining non-empty-residual proof has been
    replaced by the verified split argument actually needed by the processor.
    CeTA-rfc proves that automaton-closed RFC termination of the deleted rules
    relative to kept rules, together with the recursive residual proof for kept
    rules relative to deleted rules, implies termination of the original full
    rewriting problem. CPF `<rfcAutomatonClosedRelativeBounds>` is now enabled
    in the local `Proof_Checker` and checked by the full Isabelle
    `Proof_Checker` session.
  - 2026-07-22 certification correction: CeTA-rfc now contains a verified
    checker for `<rfcAutomatonClosedBounds>` using all-state initial acceptance,
    split closure, lhs suffix totality, and the ordinary match-bounds local
    compatibility check. Existing Ferrum automaton-closed witnesses still fail
    the local compatibility check in CeTA, so production proof search no longer
    exports `<rfcAutomatonClosedBounds>` as a certified YES. The earlier `z031`
    bound-0 witness used Matchbox-style merge-at-bound semantics and is no
    longer exported as a certified YES, because the current checker does not
    formalize merge semantics.
  - 2026-07-18 CeTA-rfc progress: `Matchbounds_Impl.thy` now contains a
    conservative executable automaton-closure predicate for unary/SRS-shaped
    rules. It extracts unary words, checks every split `L = S M`, and verifies
    that every automaton path reading `M` then `S` has the corresponding RHS
    path. `Proof_Checker` builds with this predicate. The remaining work is the
    Isabelle soundness theorem connecting this predicate to
    `rfc_forward_closure`, then replacing the temporary conservative delegation
    for `<rfcAutomatonClosedBounds>`.
  - 2026-07-21 automaton-closed RFC theorem check: the previous candidate
    soundness theorem is too strong for the current executable side
    conditions. Prefix-overlap narrowing can instantiate an open tail with a
    remaining lhs suffix, e.g. source `pre . a(x)` and rule
    `a(b(y)) -> c(y)`. The split-closure predicate only says that if the
    suffix path exists, then the RHS path must exist; it does not require the
    suffix path to exist. Therefore the split check can pass vacuously while
    RFC narrowing produces an unaccepted term. The CeTA-rfc split session now
    contains a verified candidate side condition `rfc_lhs_suffix_total_impl`
    requiring every strict lhs suffix to be accepted from every checked
    automaton state. The next theorem attempt should either combine this
    condition with the existing split lemma, or move to an explicit SRS
    word-level RFC relation and prove equivalence afterward. This has since
    been handled for the exact automaton-closed checker; merge/epsilon/relative
    RFC semantics remain open.
  - 2026-07-18 proof-search correction: after enabling the automaton-closed
    proof object, a fixed 256-example prior-unsolved SRS probe produced
    15 raw YES / 0 certified YES / 100 MAYBE / 141 timeout. Rerunning the old
    RFC parameters on the same slice produced only 1 raw YES at 20s, and a
    64-example old-raw-YES slice produced 0 YES at 60s. The earlier 243 raw
    terminations came from an older, more permissive search path whose CPF
    export failed; do not count it as current proof-search power until the
    corresponding construction is justified and reproduced.
- Partial relative match-bounds needs an explicit relative-proof-state design
  before it can be enabled in the default strategy:
  - Ferrum now has an explicit `relative-match-bounds-removal(...)` processor
    that carries the current strict SRS plus accumulated weak rules through
    recursive relative-bounds proof search;
  - nested automata are constructed against the full relative state, and the
    regression `a(x) -> b(x), b(x) -> c(x)` is CeTA-certified with nested
    `<relativeBounds>`;
  - Ferrum now tries larger certifiable rule batches before singleton deletion,
    caps the batch portfolio, and checks cancellation inside the recursive
    search and automaton completion loops;
  - fixed probes on prior-unsolved SRS examples still produced no certified YES
    wins and many timeouts, so this processor remains opt-in until it has better
    state merging and branch ordering guided by Matchbox/AProVE proof data.
- CeTA extension boundary for SRS bounds:
  - local checker sources are available under `.tools/CeTA-3.9`;
  - the official CeTA 3.9 source archive is unpacked under
    `.tools/CeTA-source-3.9/CeTA-3.9`; the Mercurial development repository was
    identified but not reachable from this machine at the time of cloning;
  - Ferrum's working CeTA extension fork is `.tools/CeTA-ferrum-rfc`; keep the
    downloaded release source pristine and only promote changes after Isabelle
    checking;
  - local Isabelle verification uses Isabelle 2025-2 from
    `https://isabelle.in.tum.de/website-Isabelle2025-2/dist/Isabelle2025-2_linux.tar.gz`
    and AFP current from `https://isa-afp.org/release/afp-current.tar.gz`;
  - termination `<bounds>` currently checks ordinary global acceptance via
    `Matchbounds_Impl.bounds_tt`, i.e. compatibility plus acceptance of
    `lift0(T(Sigma))`;
  - the working fork now contains an Isabelle-level `Relative_Bounds`
    termination proof constructor, parser support for `<relativeBounds>`, and a
    `bounds_rel_tt` processor;
  - verification completed locally with
    `.tools/Isabelle2025-2/bin/isabelle build -j 32 -d .tools/CeTA-ferrum-rfc/thys Proof_Checker`
    and
    `.tools/Isabelle2025-2/bin/isabelle build -j 32 -d .tools/CeTA-ferrum-rfc/thys Code`;
  - the verified source diff is recorded in
    `docs/ceta-relative-bounds.patch`;
  - the maintained CeTA tree and Ferrum's bundled `.tools/CeTA-ferrum-rfc`
    both build `Proof_Checker` with the RFC finite-initial checker as of
    2026-07-16;
  - `scripts/build_ceta_relative_bounds.sh` verifies the patched Isabelle
    sessions, exports generated Haskell, and builds `.tools/ceta-relative-bounds`
    with a GHC 9.6 toolchain when available;
  - Ferrum now emits termination-side `<relativeBounds>` for the conservative
    all-strict-rules SRS match-bounds case with an empty residual proof, and
    the patched checker certifies real TPDB examples under
    `target/relative-matchbounds-real`;
  - 2026-07-22: Ferrum and the CeTA-rfc fork now have first-class
    `<rfcMatchboxRelativeBounds>` CPF/checker syntax backed by a verified
    Matchbox-style merge/epsilon closure theorem. Ferrum constructs explicit
    state-compatibility pairs for `rfc-relative-match-bounds(...,at-bound=merge)`
    and emits identity pairs whenever it emits a non-empty compatibility
    relation. A Ferrum-generated smoke CPF for the synthetic SRS rule `ab -> c`
    certifies with the freshly exported `.tools/ceta-relative-bounds` binary.
    Remaining RFC work is search strength on real SRS examples, plus an
    absolute Matchbox proof-step if we want `rfc-match-bounds(...,at-bound=merge)`
    outside the relative-removal formulation.
  - 2026-07-23 source-analysis note:
    `docs/matchbox-rfc-search-analysis.md` records the pure-matchbox GPLv3
    source locations and the clean-room implementation backlog. The most
    relevant reference code is pure-matchbox's exact RFC construction in
    `src/Matchbox/Decomp.hs` and approximate `RelRFCmb`/right-barren
    construction in `src/Matchbox/Barren.hs`; pure-matchbox itself disables CPF
    for RFC/ROC except exact FULL match-bounds, so Ferrum must target the local
    CeTA-rfc semantics directly rather than copying a ready CPF design.
  - 2026-07-23 certified Matchbox-style RFC note:
    CeTA-rfc now verifies `<rfcMatchboxRelativeBounds>` with the dedicated
    right-extension condition, and Ferrum emits certifiable witnesses for real
    TPDB examples. The direct-40 smoke run
    `target/termcomp-runs/20260723-rfc-ext-right-direct40-32w-60s` certified
    `SRS_Standard/Zantema_04/{z049,z055,z062,z063}.ari` with no certification
    failures. Remaining work is search power: reduce completion timeouts,
    improve state merging/partial deletion, and compose RFC with
    preprocessing/strictification/reversal.
  - 2026-07-23 search update:
    Ferrum now recursively tries certified `rfc-relative-match-bounds` on
    residual SRSs before falling back to ordinary relative match-bounds. The
    strategy parameter `closure=full` enables the additional Matchbox-style
    barren `ext_left` and `overlap` closure generators; default
    `closure=right` keeps the faster right-extension profile. The default
    direct-40 candidate run
    `target/termcomp-runs/20260723-rfc-closure-param-default-direct40-32w-60s`
    remains 13 YES / 13 certified YES / 0 certification failures.
  - 2026-07-23 partial-deletion update:
    Matchbox-style RFC now tries validated subsets of the barren-removable rule
    pool instead of only the all-removable batch. The direct-40 run
    `target/termcomp-runs/20260723-rfc-partial-deletion-default-direct40-32w-60s`
    reached 14 YES / 14 certified YES / 0 certification failures. The extra
    example was certified by a reversed TRS/DP proof in the default parallel
    strategy, so record this as a benchmark-search improvement, not as a new
    RFC certificate shape.
  - 2026-07-23 653-candidate run:
    The current default strategy over the fixed 653 SRS RFC/Matchbox candidate
    set produced 81 YES / 81 certified YES / 0 certification failures at 60s.
    The run had to be split because 32-worker and 16-worker attempts crossed
    the memory-pressure guard; 8 workers completed safely. Combined summary:
    `target/termcomp-runs/20260723-srs-653-current-default-combined-60s/summary.md`.
  - 2026-07-23 runtime/search hardening:
    Matchbox-style RFC barren completion now uses the configured automaton
    limits during internal place/epsilon construction, not only after exporting
    the final automaton. If the place budget or epsilon-closure budget would be
    exceeded, the processor declines the attempt. This is a search cap only and
    does not affect soundness of emitted proofs. The default SRS YES strategy
    now runs a short preliminary portfolio of cheap certifiable preprocessing
    branches before racing RFC/match-bounds against fallback termination:
    reversed weighted rule removal, small top-level linear polynomial rule
    removal, reversed polynomial rule removal, KBO, reversed KBO, path order,
    and reversed path order, all under short local timeouts. This avoids
    starving the known reversed-DP fallback on examples such as
    `SRS_Standard/ICFP_2010/3268.ari`. The fixed direct-40 smoke run
    `target/termcomp-runs/20260723-srs-caps-cheap-seq-direct40-8w-60s`
    reached 14 YES / 14 certified YES / 0 certification failures, matching the
    previous best solved count on this slice with one more timeout among
    unsolved examples.
  - 2026-07-24 large-cap RFC update:
    the fixed 189 direct-`RelRFCmb{-1}` set now gives 155 YES, 101 certified
    YES within 40 seconds, 34 MAYBE, and 54 CeTA timeouts. This is 143 new raw
    YES with no losses; there are no checker rejections. Prioritize quotient/
    merge witness minimization and a verified indexed unary-word evaluator in
    CeTA before adding another RFC search family. Full artifacts:
    `target/termcomp-runs/20260724-rfc-large-caps-189-32w-40s-v2`.
  - 2026-07-24 RFC checker performance update:
    CeTA-rfc now has a proved specialized unary-word evaluator plus explicit
    sharing for right-extension RHS results and no-top state sets. The unchanged
    `ICFP_2010/107193.ari` certificate fell from about 155 seconds to 54.4
    seconds. At 40 seconds the fixed 189-example artifacts now yield 119
    certified YES, up from 101; at 60 seconds they yield 141. The next checker
    step is a verified transition index keyed by lifted symbol and unary LHS
    state. Full focused artifacts are under
    `target/checker-runs/20260724-rfc-word-share-v10-*`.
  - 2026-07-24 RFC transition-index update:
    the verified unary evaluator now builds a red-black-tree transition index
    for each lifted symbol, keyed by unary LHS state, and shares it across all
    tail states. Its result is proved extensionally equal to the former scan
    evaluator for closure, right-extension, and no-top-redex checks. The fixed
    155 retained YES certificates now all certify within 40 seconds, with zero
    timeouts or rejections; `ICFP_2010/107193.ari` takes 14.85 seconds. Checker
    artifacts are in
    `target/checker-runs/20260724-rfc-index-v11-fixed155-40s`.
  - 2026-07-24 Ferrum completion-performance update:
    unary word evaluation now uses a bitset state index, epsilon obligations
    are inserted as one transitively closed batch, and epsilon SCCs are
    quotiented between closure rounds. The fixed 155 prior YES cases remain
    155/155 certified, and `ICFP_2010/160263.ari` is newly recovered and
    certified in 65 ms. The combined fixed-189 result is 156 YES / 156
    certified YES / 33 MAYBE. Dense post-extension closure, exemplified by
    `ICFP_2010/140639.ari`, remains the next search-performance target.
  - 2026-07-24 certified strict-completion update:
    paired-tail completion now closes missing RHS runs through canonical rule
    tails and computes strict below-top compatibility in the closure/extension
    fixed point. RFC search tries the bounded barren construction across all
    bounds before expensive fallback constructors. The fixed 189 direct
    `RelRFCmb{-1}` examples now produce 189 YES / 189 certified YES / 0 MAYBE /
    0 timeout / 0 certification failures. Full artifacts:
    `target/termcomp-runs/20260724-rfc-complete-certified189-32w-40s`.
  - next certifiable SRS work is partial rule partitioning and RFC-bounds
    certificates; see `docs/ceta-rfc-relative-bounds-plan.md`.
- Add stronger SRS transformations:
  - broaden the now-certified string-reversal processor beyond the current
    reversal-plus-ordinary-match-bounds use;
  - safe alphabet/symbol simplifications;
  - decomposition and rule partitioning for relative match-bounds.
- Improve SRS nontermination:
  - stronger word-loop discovery beyond the current forward/reversed bounded
    SRS loop search;
  - overlap-closure loop search;
  - non-loop certificates where CeTA supports them.
- Strengthen native Matchbox RFC witness search:
  - preserve a separate proved state simulation/merge relation instead of
    materializing all compatibility edges as top-height automaton paths;
  - keep `<rfcNativeMatchboxRelativeBounds>` restricted to executable
    identity/epsilon witnesses until the generalized relation theorem is
    formalized;
  - compare each generalized witness against the existing certified
    `<rfcMatchboxRelativeBounds>` path before claiming benchmark gains.

## Benchmarks

- Run full TermCOMP 2025 `SRS_Standard` after each major SRS processor change.
- Keep per-example artifacts and certification outputs by default.
- Compare against Matchbox, MnM, and AProVE_cert on solved/missed examples.

## Relative ADPs

- Broaden certified `Com` reduction-pair search beyond additive natural linear
  polynomials. The executable theorem, CPF node, and additive witness path are
  complete; future orders must provide the same checked compound invariance,
  strict monotonicity, and discard laws.
- Rebenchmark the complete `TRS_Relative` category with retained certificates
  and quantify the additional certified YES results from `Com` and DRP1.
