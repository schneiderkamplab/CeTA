# HRM Strategy Dataset Processor Counts

Generated from `target/termcomp-proof-corpus/training/hrm-strategy-direct/ferrum.strategy.direct.*.jsonl.gz`.

Rows are generated from `subproofs.cpf.canonical.smt-lex.final.jsonl.gz`, i.e. the canonical proof-fragment dataset with full `output_xml` proof information. Each row has `instruction = <input>...</input>` and `response` equal to one leaf processor label or leaf variant. Structural aliases and sub-strategies such as `orders`, `dp`, and `string-reversal(...)` are excluded.

`path-order-af` is used when the proof XML exposes an argument-filtered path-order witness; plain `path-order` is used when no argument filter is present. This separates the monotone/no-filter case from AF-backed path orders in a single response field.

Numeric bounds for polynomial, matrix, KBO, and match-bound labels are extracted only from leaf `<integer>` nodes in actual witness processor XML roots. Structural wrappers such as `<dpTrans>` are skipped, so nested proof text is not concatenated into bogus parameters.

## Summary

| Metric | Count |
| --- | ---: |
| Total rows | 120,513 |
| Distinct strategy labels | 1,902 |
| train rows | 118,167 |
| validation rows | 1,193 |
| test rows | 1,153 |

## Label Provenance

| Source | Rows |
| --- | ---: |
| `coarse_processor` | 55,219 |
| `exact_xml_polynomial_bounds` | 29,497 |
| `exact_xml_matrix_bounds` | 24,205 |
| `exact_xml_subterm` | 4,868 |
| `exact_xml_top_path_order_af` | 3,331 |
| `exact_xml_loop` | 1,425 |
| `exact_xml_kbo_bounds` | 1,358 |
| `exact_xml_path_order` | 287 |
| `exact_xml_match_bound` | 281 |
| `exact_xml_nonloop` | 42 |

## Processor Family Counts

| Family | Rows | Distinct labels |
| --- | ---: | ---: |
| `graph` | 36,700 | 1 |
| `poly` | 29,497 | 833 |
| `matrix` | 24,205 | 892 |
| `size-change` | 16,272 | 1 |
| `subterm` | 4,868 | 1 |
| `path-order` | 3,618 | 2 |
| `instantiate` | 2,079 | 1 |
| `nontermination` | 1,467 | 2 |
| `kbo` | 1,358 | 163 |
| `match-bounds` | 281 | 5 |
| `forward-instantiate` | 168 | 1 |

## Full Strategy Label Table

| Strategy label | Total | Train | Validation | Test |
| --- | ---: | ---: | ---: | ---: |
| `graph` | 36,700 | 35,991 | 369 | 340 |
| `size-change` | 16,272 | 15,959 | 166 | 147 |
| `subterm` | 4,868 | 4,765 | 59 | 44 |
| `path-order-af` | 3,331 | 3,263 | 30 | 38 |
| `matrix(max-constant=1, max-coefficient=1, symbols=3, arity=1, dim=3)` | 2,839 | 2,781 | 30 | 28 |
| `instantiate(per-pair=2)` | 2,079 | 2,035 | 21 | 23 |
| `matrix(max-constant=0, max-coefficient=1, symbols=3, arity=1, dim=1)` | 1,896 | 1,857 | 25 | 14 |
| `matrix(max-constant=1, max-coefficient=1, symbols=2, arity=1, dim=3)` | 1,790 | 1,748 | 21 | 21 |
| `poly(max-constant=1, max-coefficient=1, symbols=2, arity=1)` | 1,712 | 1,677 | 16 | 19 |
| `poly(max-constant=1, max-coefficient=1, symbols=4, arity=1)` | 1,661 | 1,629 | 14 | 18 |
| `poly(max-constant=1, max-coefficient=1, symbols=3, arity=1)` | 1,649 | 1,620 | 16 | 13 |
| `nontermination(loop)` | 1,425 | 1,393 | 14 | 18 |
| `poly(max-constant=1, max-coefficient=1, symbols=6, arity=1)` | 1,376 | 1,347 | 16 | 13 |
| `matrix(max-constant=0, max-coefficient=1, symbols=2, arity=1, dim=1)` | 1,323 | 1,301 | 9 | 13 |
| `matrix(max-constant=0, max-coefficient=1, symbols=6, arity=1, dim=1)` | 1,264 | 1,240 | 10 | 14 |
| `poly(max-constant=2, max-coefficient=2, symbols=3, arity=1)` | 816 | 803 | 7 | 6 |
| `matrix(max-constant=2, max-coefficient=2, symbols=3, arity=1, dim=2)` | 790 | 776 | 7 | 7 |
| `poly(max-constant=1, max-coefficient=1, symbols=3, arity=2)` | 690 | 673 | 9 | 8 |
| `poly(max-constant=2, max-coefficient=2, symbols=6, arity=1)` | 624 | 611 | 6 | 7 |
| `poly(max-constant=1, max-coefficient=1, symbols=2, arity=2)` | 582 | 573 | 7 | 2 |
| `poly(max-constant=2, max-coefficient=2, symbols=4, arity=1)` | 557 | 551 | 4 | 2 |
| `matrix(max-constant=0, max-coefficient=1, symbols=4, arity=1, dim=1)` | 486 | 468 | 5 | 13 |
| `matrix(max-constant=2, max-coefficient=2, symbols=2, arity=1, dim=2)` | 484 | 471 | 4 | 9 |
| `poly(max-constant=2, max-coefficient=2, symbols=3, arity=2)` | 423 | 405 | 11 | 7 |
| `poly(max-constant=2, max-coefficient=2, symbols=4, arity=2)` | 414 | 402 | 8 | 4 |
| `poly(max-constant=2, max-coefficient=2, symbols=2, arity=1)` | 398 | 391 | 4 | 3 |
| `matrix(max-constant=2, max-coefficient=2, symbols=3, arity=1, dim=3)` | 362 | 356 | 2 | 4 |
| `matrix(max-constant=2, max-coefficient=2, symbols=2, arity=1, dim=3)` | 349 | 347 | 1 | 1 |
| `poly(max-constant=1, max-coefficient=1, symbols=5, arity=1)` | 308 | 304 | 1 | 3 |
| `poly(max-constant=1, max-coefficient=1, symbols=4, arity=2)` | 301 | 295 | 1 | 5 |
| `matrix(max-constant=2, max-coefficient=2, symbols=2, arity=2, dim=2)` | 290 | 283 | 3 | 4 |
| `path-order` | 287 | 284 | 1 | 2 |
| `matrix(max-constant=1, max-coefficient=1, symbols=4, arity=1, dim=3)` | 284 | 278 | 4 | 2 |
| `poly(max-constant=3, max-coefficient=3, symbols=4, arity=1)` | 276 | 272 | 1 | 3 |
| `matrix(max-constant=1, max-coefficient=1, symbols=6, arity=1, dim=3)` | 265 | 261 | 3 | 1 |
| `poly(max-constant=2, max-coefficient=2, symbols=8, arity=2)` | 262 | 254 | 2 | 6 |
| `matrix(max-constant=1, max-coefficient=1, symbols=2, arity=2, dim=3)` | 250 | 248 | 0 | 2 |
| `matrix(max-constant=1, max-coefficient=1, symbols=3, arity=2, dim=3)` | 245 | 240 | 1 | 4 |
| `poly(max-constant=2, max-coefficient=2, symbols=7, arity=2)` | 243 | 239 | 3 | 1 |
| `poly(max-constant=2, max-coefficient=2, symbols=2, arity=2)` | 240 | 236 | 1 | 3 |
| `poly(max-constant=2, max-coefficient=2, symbols=6, arity=2)` | 238 | 235 | 1 | 2 |
| `poly(max-constant=2, max-coefficient=2, symbols=14, arity=2)` | 236 | 234 | 2 | 0 |
| `poly(max-constant=4, max-coefficient=4, symbols=3, arity=1)` | 224 | 224 | 0 | 0 |
| `matrix(max-constant=2, max-coefficient=2, symbols=4, arity=1, dim=2)` | 219 | 215 | 2 | 2 |
| `poly(max-constant=2, max-coefficient=2, symbols=11, arity=2)` | 218 | 216 | 2 | 0 |
| `matrix(max-constant=0, max-coefficient=1, symbols=5, arity=1, dim=1)` | 216 | 214 | 1 | 1 |
| `poly(max-constant=2, max-coefficient=2, symbols=12, arity=2)` | 216 | 210 | 2 | 4 |
| `poly(max-constant=2, max-coefficient=2, symbols=5, arity=2)` | 210 | 206 | 1 | 3 |
| `poly(max-constant=2, max-coefficient=2, symbols=5, arity=1)` | 209 | 204 | 1 | 4 |
| `poly(max-constant=1, max-coefficient=1, symbols=5, arity=2)` | 205 | 202 | 1 | 2 |
| `poly(max-constant=2, max-coefficient=2, symbols=9, arity=2)` | 205 | 196 | 4 | 5 |
| `poly(max-constant=2, max-coefficient=2, symbols=19, arity=3)` | 201 | 196 | 3 | 2 |
| `poly(max-constant=3, max-coefficient=3, symbols=6, arity=1)` | 201 | 200 | 0 | 1 |
| `poly(max-constant=4, max-coefficient=4, symbols=4, arity=1)` | 198 | 191 | 3 | 4 |
| `poly(max-constant=3, max-coefficient=3, symbols=3, arity=1)` | 195 | 191 | 2 | 2 |
| `poly(max-constant=2, max-coefficient=2, symbols=13, arity=3)` | 194 | 194 | 0 | 0 |
| `matrix(max-constant=3, max-coefficient=3, symbols=3, arity=1, dim=3)` | 187 | 186 | 0 | 1 |
| `matrix(max-constant=1, max-coefficient=1, symbols=2, arity=1, dim=4)` | 182 | 181 | 0 | 1 |
| `matrix(max-constant=1, max-coefficient=1, symbols=3, arity=1, dim=2)` | 180 | 177 | 1 | 2 |
| `poly(max-constant=2, max-coefficient=2, symbols=10, arity=2)` | 172 | 170 | 0 | 2 |
| `forward-instantiate(per-pair=2)` | 168 | 165 | 1 | 2 |
| `matrix(max-constant=1, max-coefficient=1, symbols=2, arity=1, dim=5)` | 164 | 161 | 2 | 1 |
| `poly(max-constant=5, max-coefficient=5, symbols=4, arity=1)` | 147 | 145 | 1 | 1 |
| `poly(max-constant=1, max-coefficient=1, symbols=8, arity=2)` | 146 | 141 | 5 | 0 |
| `poly(max-constant=2, max-coefficient=2, symbols=43, arity=3)` | 145 | 144 | 0 | 1 |
| `poly(max-constant=4, max-coefficient=4, symbols=6, arity=1)` | 142 | 139 | 1 | 2 |
| `poly(max-constant=2, max-coefficient=2, symbols=26, arity=3)` | 139 | 134 | 3 | 2 |
| `matrix(max-constant=1, max-coefficient=1, symbols=5, arity=1, dim=3)` | 134 | 132 | 1 | 1 |
| `poly(max-constant=2, max-coefficient=2, symbols=17, arity=2)` | 133 | 130 | 2 | 1 |
| `poly(max-constant=2, max-coefficient=2, symbols=15, arity=2)` | 132 | 130 | 2 | 0 |
| `matrix(max-constant=2, max-coefficient=2, symbols=6, arity=1, dim=2)` | 130 | 130 | 0 | 0 |
| `matrix(max-constant=3, max-coefficient=3, symbols=3, arity=1, dim=2)` | 127 | 120 | 3 | 4 |
| `poly(max-constant=1, max-coefficient=1, symbols=6, arity=2)` | 126 | 125 | 0 | 1 |
| `poly(max-constant=2, max-coefficient=2, symbols=16, arity=2)` | 126 | 126 | 0 | 0 |
| `poly(max-constant=1, max-coefficient=1, symbols=7, arity=2)` | 125 | 121 | 2 | 2 |
| `match-bounds(max-bound=1)` | 123 | 119 | 1 | 3 |
| `matrix(max-constant=1, max-coefficient=1, symbols=2, arity=1, dim=2)` | 123 | 121 | 1 | 1 |
| `poly(max-constant=2, max-coefficient=2, symbols=8, arity=3)` | 116 | 113 | 0 | 3 |
| `poly(max-constant=3, max-coefficient=3, symbols=3, arity=2)` | 115 | 112 | 3 | 0 |
| `matrix(max-constant=2, max-coefficient=2, symbols=3, arity=2, dim=2)` | 113 | 112 | 1 | 0 |
| `poly(max-constant=5, max-coefficient=5, symbols=8, arity=3)` | 108 | 106 | 1 | 1 |
| `poly(max-constant=2, max-coefficient=2, symbols=11, arity=3)` | 106 | 103 | 2 | 1 |
| `poly(max-constant=2, max-coefficient=2, symbols=10, arity=3)` | 105 | 103 | 1 | 1 |
| `poly(max-constant=3, max-coefficient=3, symbols=4, arity=2)` | 105 | 102 | 3 | 0 |
| `matrix(max-constant=1, max-coefficient=1, symbols=5, arity=2, dim=3)` | 104 | 102 | 2 | 0 |
| `poly(max-constant=4, max-coefficient=4, symbols=2, arity=1)` | 104 | 101 | 2 | 1 |
| `matrix(max-constant=3, max-coefficient=3, symbols=2, arity=1, dim=2)` | 103 | 101 | 1 | 1 |
| `poly(max-constant=3, max-coefficient=3, symbols=2, arity=1)` | 103 | 102 | 1 | 0 |
| `poly(max-constant=5, max-coefficient=5, symbols=6, arity=1)` | 103 | 96 | 3 | 4 |
| `poly(max-constant=1, max-coefficient=1, symbols=7, arity=1)` | 102 | 101 | 0 | 1 |
| `poly(max-constant=5, max-coefficient=5, symbols=4, arity=2)` | 101 | 99 | 1 | 1 |
| `matrix(max-constant=2, max-coefficient=2, symbols=7, arity=1, dim=2)` | 99 | 96 | 1 | 2 |
| `matrix(max-constant=3, max-coefficient=3, symbols=2, arity=1, dim=3)` | 99 | 95 | 4 | 0 |
| `poly(max-constant=5, max-coefficient=5, symbols=5, arity=1)` | 99 | 98 | 1 | 0 |
| `kbo(weight=2, symbols=3)` | 98 | 96 | 1 | 1 |
| `poly(max-constant=4, max-coefficient=4, symbols=3, arity=2)` | 98 | 95 | 2 | 1 |
| `matrix(max-constant=1, max-coefficient=1, symbols=3, arity=1, dim=4)` | 96 | 92 | 2 | 2 |
| `poly(max-constant=1, max-coefficient=1, symbols=4, arity=3)` | 96 | 92 | 1 | 3 |
| `poly(max-constant=5, max-coefficient=5, symbols=3, arity=1)` | 96 | 92 | 1 | 3 |
| `poly(max-constant=5, max-coefficient=5, symbols=15, arity=2)` | 94 | 93 | 0 | 1 |
| `matrix(max-constant=0, max-coefficient=1, symbols=1, arity=1, dim=1)` | 92 | 91 | 0 | 1 |
| `poly(max-constant=5, max-coefficient=5, symbols=3, arity=2)` | 91 | 90 | 0 | 1 |
| `poly(max-constant=5, max-coefficient=5, symbols=5, arity=2)` | 91 | 91 | 0 | 0 |
| `poly(max-constant=2, max-coefficient=2, symbols=20, arity=2)` | 89 | 87 | 1 | 1 |
| `poly(max-constant=3, max-coefficient=3, symbols=5, arity=1)` | 89 | 86 | 2 | 1 |
| `poly(max-constant=2, max-coefficient=2, symbols=41, arity=3)` | 88 | 87 | 0 | 1 |
| `matrix(max-constant=1, max-coefficient=1, symbols=4, arity=2, dim=3)` | 87 | 85 | 0 | 2 |
| `matrix(max-constant=2, max-coefficient=2, symbols=5, arity=1, dim=2)` | 87 | 87 | 0 | 0 |
| `matrix(max-constant=3, max-coefficient=3, symbols=3, arity=1, dim=5)` | 85 | 84 | 1 | 0 |
| `poly(max-constant=1, max-coefficient=1, symbols=3, arity=3)` | 85 | 83 | 1 | 1 |
| `kbo(weight=2, symbols=2)` | 82 | 79 | 1 | 2 |
| `matrix(max-constant=1, max-coefficient=1, symbols=10, arity=1, dim=3)` | 82 | 79 | 1 | 2 |
| `poly(max-constant=2, max-coefficient=2, symbols=27, arity=2)` | 82 | 78 | 2 | 2 |
| `kbo(weight=1, symbols=3)` | 81 | 81 | 0 | 0 |
| `match-bounds(max-bound=3)` | 81 | 80 | 0 | 1 |
| `matrix(max-constant=4, max-coefficient=4, symbols=3, arity=1, dim=3)` | 81 | 81 | 0 | 0 |
| `poly(max-constant=2, max-coefficient=2, symbols=13, arity=2)` | 81 | 79 | 0 | 2 |
| `matrix(max-constant=1, max-coefficient=1, symbols=7, arity=1, dim=3)` | 80 | 79 | 1 | 0 |
| `poly(max-constant=0, max-coefficient=1, symbols=3, arity=1)` | 80 | 76 | 2 | 2 |
| `poly(max-constant=2, max-coefficient=2, symbols=16, arity=3)` | 79 | 77 | 1 | 1 |
| `poly(max-constant=3, max-coefficient=3, symbols=5, arity=2)` | 79 | 76 | 2 | 1 |
| `poly(max-constant=5, max-coefficient=5, symbols=13, arity=3)` | 79 | 78 | 0 | 1 |
| `poly(max-constant=3, max-coefficient=3, symbols=12, arity=2)` | 77 | 77 | 0 | 0 |
| `poly(max-constant=5, max-coefficient=5, symbols=12, arity=2)` | 77 | 77 | 0 | 0 |
| `poly(max-constant=4, max-coefficient=4, symbols=2, arity=2)` | 75 | 72 | 2 | 1 |
| `poly(max-constant=2, max-coefficient=2, symbols=28, arity=4)` | 74 | 73 | 0 | 1 |
| `poly(max-constant=2, max-coefficient=2, symbols=7, arity=1)` | 74 | 72 | 2 | 0 |
| `poly(max-constant=4, max-coefficient=4, symbols=7, arity=2)` | 74 | 73 | 1 | 0 |
| `poly(max-constant=5, max-coefficient=5, symbols=9, arity=2)` | 74 | 74 | 0 | 0 |
| `poly(max-constant=2, max-coefficient=2, symbols=9, arity=3)` | 73 | 73 | 0 | 0 |
| `poly(max-constant=3, max-coefficient=3, symbols=26, arity=3)` | 73 | 72 | 0 | 1 |
| `poly(max-constant=5, max-coefficient=5, symbols=2, arity=2)` | 73 | 73 | 0 | 0 |
| `poly(max-constant=5, max-coefficient=5, symbols=9, arity=3)` | 73 | 71 | 1 | 1 |
| `matrix(max-constant=2, max-coefficient=2, symbols=2, arity=1, dim=4)` | 72 | 72 | 0 | 0 |
| `poly(max-constant=3, max-coefficient=3, symbols=16, arity=3)` | 72 | 69 | 1 | 2 |
| `poly(max-constant=5, max-coefficient=5, symbols=33, arity=5)` | 72 | 71 | 1 | 0 |
| `matrix(max-constant=2, max-coefficient=2, symbols=2, arity=1, dim=5)` | 71 | 70 | 0 | 1 |
| `matrix(max-constant=3, max-coefficient=3, symbols=4, arity=2, dim=1)` | 71 | 71 | 0 | 0 |
| `poly(max-constant=3, max-coefficient=3, symbols=14, arity=2)` | 71 | 68 | 2 | 1 |
| `matrix(max-constant=1, max-coefficient=1, symbols=4, arity=2, dim=2)` | 69 | 69 | 0 | 0 |
| `matrix(max-constant=2, max-coefficient=2, symbols=4, arity=2, dim=2)` | 68 | 65 | 1 | 2 |
| `poly(max-constant=1, max-coefficient=1, symbols=2, arity=3)` | 68 | 65 | 1 | 2 |
| `poly(max-constant=4, max-coefficient=4, symbols=4, arity=2)` | 68 | 68 | 0 | 0 |
| `matrix(max-constant=2, max-coefficient=2, symbols=6, arity=1, dim=3)` | 67 | 65 | 1 | 1 |
| `matrix(max-constant=3, max-coefficient=3, symbols=3, arity=2, dim=2)` | 67 | 65 | 1 | 1 |
| `matrix(max-constant=4, max-coefficient=4, symbols=2, arity=1, dim=3)` | 67 | 67 | 0 | 0 |
| `poly(max-constant=5, max-coefficient=5, symbols=10, arity=2)` | 67 | 65 | 1 | 1 |
| `poly(max-constant=3, max-coefficient=3, symbols=8, arity=2)` | 65 | 63 | 2 | 0 |
| `match-bounds(max-bound=2)` | 64 | 64 | 0 | 0 |
| `matrix(max-constant=1, max-coefficient=1, symbols=3, arity=1, dim=5)` | 64 | 63 | 1 | 0 |
| `matrix(max-constant=3, max-coefficient=3, symbols=8, arity=1, dim=2)` | 64 | 63 | 0 | 1 |
| `poly(max-constant=2, max-coefficient=2, symbols=21, arity=3)` | 64 | 63 | 0 | 1 |
| `poly(max-constant=3, max-coefficient=3, symbols=13, arity=3)` | 64 | 64 | 0 | 0 |
| `poly(max-constant=5, max-coefficient=5, symbols=7, arity=2)` | 64 | 64 | 0 | 0 |
| `matrix(max-constant=2, max-coefficient=2, symbols=4, arity=1, dim=3)` | 63 | 61 | 1 | 1 |
| `poly(max-constant=1, max-coefficient=1, symbols=13, arity=3)` | 63 | 63 | 0 | 0 |
| `matrix(max-constant=1, max-coefficient=1, symbols=6, arity=2, dim=3)` | 62 | 60 | 2 | 0 |
| `poly(max-constant=3, max-coefficient=3, symbols=2, arity=2)` | 62 | 59 | 1 | 2 |
| `kbo(weight=4, symbols=3)` | 61 | 59 | 1 | 1 |
| `matrix(max-constant=3, max-coefficient=3, symbols=2, arity=2, dim=2)` | 61 | 58 | 2 | 1 |
| `matrix(max-constant=3, max-coefficient=3, symbols=9, arity=1, dim=2)` | 61 | 60 | 1 | 0 |
| `poly(max-constant=3, max-coefficient=3, symbols=7, arity=2)` | 60 | 60 | 0 | 0 |
| `poly(max-constant=5, max-coefficient=5, symbols=11, arity=3)` | 60 | 58 | 2 | 0 |
| `matrix(max-constant=1, max-coefficient=1, symbols=7, arity=2, dim=3)` | 59 | 58 | 1 | 0 |
| `poly(max-constant=2, max-coefficient=2, symbols=22, arity=3)` | 59 | 58 | 0 | 1 |
| `poly(max-constant=1, max-coefficient=1, symbols=8, arity=3)` | 58 | 58 | 0 | 0 |
| `poly(max-constant=3, max-coefficient=3, symbols=9, arity=2)` | 58 | 58 | 0 | 0 |
| `poly(max-constant=5, max-coefficient=5, symbols=2, arity=1)` | 58 | 56 | 0 | 2 |
| `matrix(max-constant=3, max-coefficient=3, symbols=2, arity=1, dim=5)` | 57 | 56 | 0 | 1 |
| `matrix(max-constant=5, max-coefficient=5, symbols=2, arity=1, dim=2)` | 57 | 57 | 0 | 0 |
| `poly(max-constant=2, max-coefficient=2, symbols=20, arity=3)` | 57 | 55 | 1 | 1 |
| `poly(max-constant=2, max-coefficient=2, symbols=5, arity=3)` | 57 | 56 | 1 | 0 |
| `poly(max-constant=7, max-coefficient=7, symbols=4, arity=1)` | 57 | 56 | 0 | 1 |
| `matrix(max-constant=2, max-coefficient=2, symbols=10, arity=1, dim=3)` | 56 | 56 | 0 | 0 |
| `matrix(max-constant=2, max-coefficient=2, symbols=4, arity=2, dim=1)` | 56 | 55 | 0 | 1 |
| `matrix(max-constant=2, max-coefficient=2, symbols=3, arity=1, dim=4)` | 55 | 55 | 0 | 0 |
| `poly(max-constant=1, max-coefficient=1, symbols=8, arity=1)` | 55 | 54 | 0 | 1 |
| `poly(max-constant=4, max-coefficient=4, symbols=5, arity=1)` | 55 | 54 | 0 | 1 |
| `matrix(max-constant=4, max-coefficient=4, symbols=3, arity=1, dim=2)` | 54 | 54 | 0 | 0 |
| `poly(max-constant=3, max-coefficient=3, symbols=19, arity=3)` | 54 | 53 | 0 | 1 |
| `matrix(max-constant=1, max-coefficient=1, symbols=4, arity=3, dim=3)` | 53 | 53 | 0 | 0 |
| `matrix(max-constant=1, max-coefficient=1, symbols=5, arity=2, dim=2)` | 53 | 53 | 0 | 0 |
| `poly(max-constant=1, max-coefficient=1, symbols=9, arity=3)` | 53 | 52 | 1 | 0 |
| `poly(max-constant=2, max-coefficient=2, symbols=12, arity=3)` | 53 | 53 | 0 | 0 |
| `poly(max-constant=3, max-coefficient=3, symbols=6, arity=2)` | 53 | 52 | 0 | 1 |
| `poly(max-constant=4, max-coefficient=4, symbols=5, arity=2)` | 53 | 52 | 0 | 1 |
| `poly(max-constant=5, max-coefficient=5, symbols=22, arity=3)` | 53 | 49 | 4 | 0 |
| `matrix(max-constant=1, max-coefficient=1, symbols=3, arity=2, dim=2)` | 52 | 52 | 0 | 0 |
| `matrix(max-constant=2, max-coefficient=2, symbols=8, arity=1, dim=3)` | 52 | 51 | 0 | 1 |
| `matrix(max-constant=3, max-coefficient=3, symbols=3, arity=2, dim=1)` | 52 | 51 | 0 | 1 |
| `poly(max-constant=2, max-coefficient=2, symbols=48, arity=4)` | 52 | 52 | 0 | 0 |
| `kbo(weight=14, symbols=17)` | 51 | 50 | 1 | 0 |
| `matrix(max-constant=3, max-coefficient=3, symbols=25, arity=2, dim=1)` | 51 | 50 | 0 | 1 |
| `matrix(max-constant=3, max-coefficient=3, symbols=4, arity=2, dim=2)` | 51 | 50 | 1 | 0 |
| `poly(max-constant=1, max-coefficient=1, symbols=12, arity=2)` | 51 | 48 | 1 | 2 |
| `poly(max-constant=2, max-coefficient=2, symbols=15, arity=3)` | 51 | 51 | 0 | 0 |
| `poly(max-constant=2, max-coefficient=2, symbols=7, arity=3)` | 51 | 51 | 0 | 0 |
| `matrix(max-constant=3, max-coefficient=3, symbols=5, arity=1, dim=3)` | 50 | 49 | 1 | 0 |
| `poly(max-constant=1, max-coefficient=1, symbols=10, arity=3)` | 50 | 50 | 0 | 0 |
| `poly(max-constant=2, max-coefficient=2, symbols=8, arity=1)` | 50 | 48 | 1 | 1 |
| `matrix(max-constant=2, max-coefficient=2, symbols=3, arity=2, dim=1)` | 49 | 48 | 1 | 0 |
| `matrix(max-constant=3, max-coefficient=3, symbols=6, arity=2, dim=2)` | 49 | 47 | 0 | 2 |
| `poly(max-constant=1, max-coefficient=1, symbols=9, arity=2)` | 49 | 48 | 1 | 0 |
| `poly(max-constant=5, max-coefficient=5, symbols=13, arity=2)` | 49 | 48 | 0 | 1 |
| `matrix(max-constant=4, max-coefficient=4, symbols=4, arity=1, dim=3)` | 48 | 47 | 1 | 0 |
| `poly(max-constant=2, max-coefficient=2, symbols=19, arity=2)` | 48 | 48 | 0 | 0 |
| `poly(max-constant=3, max-coefficient=3, symbols=16, arity=2)` | 48 | 43 | 4 | 1 |
| `matrix(max-constant=3, max-coefficient=3, symbols=7, arity=1, dim=2)` | 47 | 46 | 1 | 0 |
| `poly(max-constant=3, max-coefficient=3, symbols=58, arity=3)` | 47 | 46 | 0 | 1 |
| `poly(max-constant=5, max-coefficient=5, symbols=11, arity=2)` | 47 | 46 | 1 | 0 |
| `matrix(max-constant=3, max-coefficient=3, symbols=10, arity=1, dim=2)` | 46 | 45 | 0 | 1 |
| `matrix(max-constant=3, max-coefficient=3, symbols=6, arity=1, dim=2)` | 46 | 43 | 0 | 3 |
| `poly(max-constant=5, max-coefficient=5, symbols=8, arity=2)` | 46 | 46 | 0 | 0 |
| `matrix(max-constant=1, max-coefficient=1, symbols=2, arity=2, dim=2)` | 45 | 45 | 0 | 0 |
| `poly(max-constant=5, max-coefficient=5, symbols=6, arity=3)` | 45 | 43 | 2 | 0 |
| `matrix(max-constant=2, max-coefficient=2, symbols=4, arity=3, dim=2)` | 44 | 44 | 0 | 0 |
| `matrix(max-constant=2, max-coefficient=2, symbols=5, arity=1, dim=3)` | 44 | 44 | 0 | 0 |
| `matrix(max-constant=2, max-coefficient=2, symbols=9, arity=3, dim=2)` | 44 | 43 | 0 | 1 |
| `matrix(max-constant=1, max-coefficient=1, symbols=6, arity=2, dim=2)` | 43 | 43 | 0 | 0 |
| `matrix(max-constant=2, max-coefficient=2, symbols=4, arity=2, dim=3)` | 43 | 42 | 1 | 0 |
| `matrix(max-constant=3, max-coefficient=3, symbols=8, arity=1, dim=1)` | 43 | 42 | 0 | 1 |
| `matrix(max-constant=4, max-coefficient=4, symbols=2, arity=1, dim=2)` | 43 | 42 | 1 | 0 |
| `poly(max-constant=2, max-coefficient=2, symbols=6, arity=3)` | 43 | 43 | 0 | 0 |
| `poly(max-constant=3, max-coefficient=3, symbols=10, arity=3)` | 43 | 42 | 1 | 0 |
| `poly(max-constant=6, max-coefficient=6, symbols=4, arity=1)` | 43 | 42 | 0 | 1 |
| `matrix(max-constant=1, max-coefficient=1, symbols=6, arity=1, dim=2)` | 42 | 42 | 0 | 0 |
| `matrix(max-constant=2, max-coefficient=2, symbols=6, arity=2, dim=1)` | 42 | 42 | 0 | 0 |
| `matrix(max-constant=3, max-coefficient=3, symbols=33, arity=2, dim=1)` | 42 | 42 | 0 | 0 |
| `matrix(max-constant=3, max-coefficient=3, symbols=6, arity=1, dim=1)` | 42 | 41 | 0 | 1 |
| `matrix(max-constant=4, max-coefficient=4, symbols=7, arity=1, dim=3)` | 42 | 42 | 0 | 0 |
| `matrix(max-constant=5, max-coefficient=5, symbols=24, arity=2, dim=1)` | 42 | 40 | 1 | 1 |
| `nontermination(dp-nonloop)` | 42 | 42 | 0 | 0 |
| `poly(max-constant=1, max-coefficient=1, symbols=10, arity=2)` | 42 | 41 | 1 | 0 |
| `poly(max-constant=1, max-coefficient=1, symbols=11, arity=2)` | 42 | 42 | 0 | 0 |
| `poly(max-constant=2, max-coefficient=2, symbols=32, arity=3)` | 42 | 42 | 0 | 0 |
| `poly(max-constant=2, max-coefficient=2, symbols=44, arity=3)` | 42 | 41 | 1 | 0 |
| `poly(max-constant=3, max-coefficient=3, symbols=11, arity=2)` | 42 | 40 | 1 | 1 |
| `poly(max-constant=3, max-coefficient=3, symbols=15, arity=2)` | 42 | 40 | 0 | 2 |
| `poly(max-constant=5, max-coefficient=5, symbols=17, arity=3)` | 42 | 38 | 2 | 2 |
| `matrix(max-constant=3, max-coefficient=3, symbols=4, arity=1, dim=2)` | 41 | 40 | 0 | 1 |
| `matrix(max-constant=7, max-coefficient=7, symbols=2, arity=1, dim=2)` | 41 | 39 | 0 | 2 |
| `matrix(max-constant=2, max-coefficient=2, symbols=8, arity=1, dim=2)` | 40 | 39 | 0 | 1 |
| `poly(max-constant=3, max-coefficient=3, symbols=7, arity=1)` | 40 | 39 | 0 | 1 |
| `poly(max-constant=5, max-coefficient=5, symbols=28, arity=3)` | 40 | 38 | 1 | 1 |
| `matrix(max-constant=3, max-coefficient=3, symbols=4, arity=3, dim=2)` | 39 | 39 | 0 | 0 |
| `matrix(max-constant=4, max-coefficient=4, symbols=21, arity=3, dim=1)` | 39 | 39 | 0 | 0 |
| `poly(max-constant=1, max-coefficient=1, symbols=8, arity=4)` | 39 | 39 | 0 | 0 |
| `poly(max-constant=3, max-coefficient=3, symbols=27, arity=2)` | 39 | 37 | 0 | 2 |
| `poly(max-constant=8, max-coefficient=8, symbols=4, arity=1)` | 39 | 39 | 0 | 0 |
| `matrix(max-constant=1, max-coefficient=1, symbols=4, arity=1, dim=5)` | 38 | 38 | 0 | 0 |
| `matrix(max-constant=1, max-coefficient=1, symbols=7, arity=2, dim=2)` | 38 | 38 | 0 | 0 |
| `matrix(max-constant=2, max-coefficient=2, symbols=3, arity=1, dim=5)` | 38 | 38 | 0 | 0 |
| `poly(max-constant=2, max-coefficient=2, symbols=30, arity=2)` | 38 | 38 | 0 | 0 |
| `poly(max-constant=4, max-coefficient=4, symbols=6, arity=2)` | 38 | 36 | 2 | 0 |
| `poly(max-constant=5, max-coefficient=5, symbols=32, arity=3)` | 38 | 38 | 0 | 0 |
| `matrix(max-constant=1, max-coefficient=1, symbols=3, arity=2, dim=4)` | 37 | 37 | 0 | 0 |
| `matrix(max-constant=1, max-coefficient=1, symbols=4, arity=3, dim=2)` | 37 | 36 | 1 | 0 |
| `matrix(max-constant=1, max-coefficient=1, symbols=7, arity=2, dim=1)` | 37 | 37 | 0 | 0 |
| `matrix(max-constant=3, max-coefficient=3, symbols=7, arity=2, dim=1)` | 37 | 37 | 0 | 0 |
| `matrix(max-constant=5, max-coefficient=5, symbols=17, arity=4, dim=1)` | 37 | 37 | 0 | 0 |
| `poly(max-constant=1, max-coefficient=1, symbols=14, arity=2)` | 37 | 36 | 1 | 0 |
| `poly(max-constant=2, max-coefficient=2, symbols=34, arity=3)` | 37 | 37 | 0 | 0 |
| `poly(max-constant=2, max-coefficient=2, symbols=4, arity=3)` | 37 | 35 | 0 | 2 |
| `poly(max-constant=2, max-coefficient=2, symbols=55, arity=3)` | 37 | 37 | 0 | 0 |
| `poly(max-constant=3, max-coefficient=3, symbols=20, arity=2)` | 37 | 37 | 0 | 0 |
| `poly(max-constant=5, max-coefficient=5, symbols=10, arity=3)` | 37 | 37 | 0 | 0 |
| `matrix(max-constant=2, max-coefficient=2, symbols=3, arity=1, dim=1)` | 36 | 36 | 0 | 0 |
| `matrix(max-constant=4, max-coefficient=4, symbols=6, arity=1, dim=3)` | 36 | 36 | 0 | 0 |
| `poly(max-constant=1, max-coefficient=1, symbols=21, arity=3)` | 36 | 35 | 0 | 1 |
| `poly(max-constant=2, max-coefficient=2, symbols=17, arity=4)` | 36 | 35 | 1 | 0 |
| `poly(max-constant=2, max-coefficient=2, symbols=26, arity=4)` | 35 | 35 | 0 | 0 |
| `poly(max-constant=3, max-coefficient=3, symbols=9, arity=3)` | 35 | 34 | 0 | 1 |
| `poly(max-constant=5, max-coefficient=5, symbols=15, arity=3)` | 35 | 34 | 1 | 0 |
| `poly(max-constant=7, max-coefficient=7, symbols=3, arity=1)` | 35 | 34 | 1 | 0 |
| `kbo(weight=5, symbols=14)` | 34 | 33 | 1 | 0 |
| `kbo(weight=5, symbols=41)` | 34 | 34 | 0 | 0 |
| `matrix(max-constant=1, max-coefficient=1, symbols=41, arity=3, dim=1)` | 34 | 34 | 0 | 0 |
| `matrix(max-constant=1, max-coefficient=1, symbols=8, arity=1, dim=3)` | 34 | 33 | 1 | 0 |
| `matrix(max-constant=2, max-coefficient=2, symbols=5, arity=2, dim=2)` | 34 | 33 | 0 | 1 |
| `matrix(max-constant=2, max-coefficient=2, symbols=7, arity=2, dim=1)` | 34 | 33 | 1 | 0 |
| `poly(max-constant=3, max-coefficient=3, symbols=6, arity=3)` | 34 | 34 | 0 | 0 |
| `poly(max-constant=3, max-coefficient=3, symbols=8, arity=1)` | 34 | 34 | 0 | 0 |
| `poly(max-constant=4, max-coefficient=4, symbols=12, arity=2)` | 34 | 34 | 0 | 0 |
| `poly(max-constant=6, max-coefficient=6, symbols=2, arity=1)` | 34 | 34 | 0 | 0 |
| `poly(max-constant=8, max-coefficient=8, symbols=5, arity=1)` | 34 | 34 | 0 | 0 |
| `matrix(max-constant=0, max-coefficient=1, symbols=7, arity=1, dim=1)` | 33 | 33 | 0 | 0 |
| `matrix(max-constant=1, max-coefficient=1, symbols=2, arity=1, dim=6)` | 33 | 31 | 0 | 2 |
| `matrix(max-constant=3, max-coefficient=3, symbols=5, arity=2, dim=2)` | 33 | 32 | 0 | 1 |
| `matrix(max-constant=3, max-coefficient=3, symbols=8, arity=2, dim=1)` | 33 | 32 | 1 | 0 |
| `poly(max-constant=2, max-coefficient=2, symbols=58, arity=3)` | 33 | 33 | 0 | 0 |
| `poly(max-constant=3, max-coefficient=3, symbols=13, arity=2)` | 33 | 33 | 0 | 0 |
| `poly(max-constant=5, max-coefficient=5, symbols=14, arity=2)` | 33 | 32 | 0 | 1 |
| `matrix(max-constant=1, max-coefficient=1, symbols=4, arity=2, dim=1)` | 32 | 30 | 1 | 1 |
| `matrix(max-constant=3, max-coefficient=3, symbols=6, arity=3, dim=2)` | 32 | 32 | 0 | 0 |
| `poly(max-constant=1, max-coefficient=1, symbols=19, arity=3)` | 32 | 31 | 0 | 1 |
| `poly(max-constant=2, max-coefficient=2, symbols=28, arity=3)` | 32 | 32 | 0 | 0 |
| `poly(max-constant=2, max-coefficient=2, symbols=3, arity=3)` | 32 | 32 | 0 | 0 |
| `poly(max-constant=3, max-coefficient=3, symbols=10, arity=1)` | 32 | 32 | 0 | 0 |
| `poly(max-constant=3, max-coefficient=3, symbols=17, arity=2)` | 32 | 31 | 0 | 1 |
| `poly(max-constant=4, max-coefficient=4, symbols=7, arity=1)` | 32 | 32 | 0 | 0 |
| `poly(max-constant=5, max-coefficient=5, symbols=12, arity=3)` | 32 | 32 | 0 | 0 |
| `poly(max-constant=5, max-coefficient=5, symbols=6, arity=2)` | 32 | 32 | 0 | 0 |
| `poly(max-constant=6, max-coefficient=6, symbols=3, arity=1)` | 32 | 32 | 0 | 0 |
| `poly(max-constant=6, max-coefficient=6, symbols=6, arity=1)` | 32 | 31 | 1 | 0 |
| `matrix(max-constant=3, max-coefficient=3, symbols=5, arity=1, dim=1)` | 31 | 30 | 0 | 1 |
| `poly(max-constant=2, max-coefficient=2, symbols=25, arity=3)` | 31 | 31 | 0 | 0 |
| `poly(max-constant=5, max-coefficient=5, symbols=18, arity=2)` | 31 | 30 | 0 | 1 |
| `poly(max-constant=5, max-coefficient=5, symbols=4, arity=3)` | 31 | 31 | 0 | 0 |
| `kbo(weight=1, symbols=14)` | 30 | 30 | 0 | 0 |
| `matrix(max-constant=1, max-coefficient=1, symbols=10, arity=2, dim=3)` | 30 | 26 | 3 | 1 |
| `matrix(max-constant=1, max-coefficient=1, symbols=23, arity=2, dim=1)` | 30 | 29 | 0 | 1 |
| `matrix(max-constant=1, max-coefficient=1, symbols=8, arity=4, dim=2)` | 30 | 29 | 0 | 1 |
| `matrix(max-constant=4, max-coefficient=4, symbols=2, arity=1, dim=4)` | 30 | 30 | 0 | 0 |
| `matrix(max-constant=5, max-coefficient=5, symbols=23, arity=2, dim=1)` | 30 | 29 | 1 | 0 |
| `poly(max-constant=1, max-coefficient=1, symbols=7, arity=3)` | 30 | 30 | 0 | 0 |
| `poly(max-constant=2, max-coefficient=2, symbols=14, arity=3)` | 30 | 30 | 0 | 0 |
| `poly(max-constant=2, max-coefficient=2, symbols=22, arity=2)` | 30 | 27 | 1 | 2 |
| `poly(max-constant=2, max-coefficient=2, symbols=46, arity=3)` | 30 | 29 | 1 | 0 |
| `poly(max-constant=3, max-coefficient=3, symbols=10, arity=2)` | 30 | 30 | 0 | 0 |
| `poly(max-constant=3, max-coefficient=3, symbols=8, arity=3)` | 30 | 30 | 0 | 0 |
| `poly(max-constant=47, max-coefficient=47, symbols=4, arity=1)` | 30 | 30 | 0 | 0 |
| `kbo(weight=5, symbols=16)` | 29 | 28 | 0 | 1 |
| `matrix(max-constant=2, max-coefficient=2, symbols=2, arity=1, dim=1)` | 29 | 28 | 0 | 1 |
| `poly(max-constant=0, max-coefficient=1, symbols=4, arity=1)` | 29 | 29 | 0 | 0 |
| `poly(max-constant=1, max-coefficient=1, symbols=16, arity=2)` | 29 | 29 | 0 | 0 |
| `poly(max-constant=3, max-coefficient=3, symbols=11, arity=3)` | 29 | 29 | 0 | 0 |
| `poly(max-constant=5, max-coefficient=5, symbols=13, arity=4)` | 29 | 29 | 0 | 0 |
| `poly(max-constant=9, max-coefficient=9, symbols=6, arity=1)` | 29 | 29 | 0 | 0 |
| `matrix(max-constant=1, max-coefficient=1, symbols=8, arity=2, dim=3)` | 28 | 28 | 0 | 0 |
| `matrix(max-constant=3, max-coefficient=3, symbols=5, arity=1, dim=2)` | 28 | 28 | 0 | 0 |
| `matrix(max-constant=5, max-coefficient=5, symbols=3, arity=1, dim=3)` | 28 | 28 | 0 | 0 |
| `poly(max-constant=0, max-coefficient=1, symbols=2, arity=2)` | 28 | 28 | 0 | 0 |
| `poly(max-constant=1, max-coefficient=1, symbols=12, arity=3)` | 28 | 28 | 0 | 0 |
| `poly(max-constant=4, max-coefficient=4, symbols=8, arity=3)` | 28 | 28 | 0 | 0 |
| `poly(max-constant=5, max-coefficient=5, symbols=20, arity=3)` | 28 | 28 | 0 | 0 |
| `poly(max-constant=5, max-coefficient=5, symbols=9, arity=4)` | 28 | 28 | 0 | 0 |
| `poly(max-constant=8, max-coefficient=8, symbols=14, arity=2)` | 28 | 28 | 0 | 0 |
| `poly(max-constant=8, max-coefficient=8, symbols=6, arity=2)` | 28 | 27 | 0 | 1 |
| `matrix(max-constant=2, max-coefficient=2, symbols=8, arity=2, dim=1)` | 27 | 27 | 0 | 0 |
| `matrix(max-constant=3, max-coefficient=3, symbols=8, arity=2, dim=2)` | 27 | 26 | 0 | 1 |
| `poly(max-constant=0, max-coefficient=1, symbols=8, arity=3)` | 27 | 26 | 1 | 0 |
| `poly(max-constant=10, max-coefficient=10, symbols=4, arity=1)` | 27 | 27 | 0 | 0 |
| `matrix(max-constant=0, max-coefficient=1, symbols=8, arity=1, dim=1)` | 26 | 26 | 0 | 0 |
| `matrix(max-constant=1, max-coefficient=1, symbols=6, arity=2, dim=1)` | 26 | 26 | 0 | 0 |
| `matrix(max-constant=2, max-coefficient=2, symbols=4, arity=1, dim=1)` | 26 | 26 | 0 | 0 |
| `matrix(max-constant=3, max-coefficient=3, symbols=4, arity=1, dim=3)` | 26 | 25 | 1 | 0 |
| `matrix(max-constant=3, max-coefficient=3, symbols=6, arity=2, dim=3)` | 26 | 26 | 0 | 0 |
| `poly(max-constant=5, max-coefficient=5, symbols=1, arity=2)` | 26 | 26 | 0 | 0 |
| `poly(max-constant=5, max-coefficient=5, symbols=7, arity=3)` | 26 | 26 | 0 | 0 |
| `poly(max-constant=7, max-coefficient=7, symbols=6, arity=1)` | 26 | 26 | 0 | 0 |
| `poly(max-constant=8, max-coefficient=8, symbols=6, arity=1)` | 26 | 26 | 0 | 0 |
| `matrix(max-constant=0, max-coefficient=1, symbols=10, arity=1, dim=1)` | 25 | 24 | 1 | 0 |
| `matrix(max-constant=5, max-coefficient=5, symbols=2, arity=1, dim=5)` | 25 | 25 | 0 | 0 |
| `matrix(max-constant=6, max-coefficient=6, symbols=2, arity=1, dim=2)` | 25 | 24 | 0 | 1 |
| `matrix(max-constant=7, max-coefficient=7, symbols=2, arity=1, dim=3)` | 25 | 24 | 0 | 1 |
| `poly(max-constant=1, max-coefficient=1, symbols=5, arity=3)` | 25 | 25 | 0 | 0 |
| `poly(max-constant=1, max-coefficient=1, symbols=6, arity=3)` | 25 | 24 | 1 | 0 |
| `poly(max-constant=2, max-coefficient=2, symbols=48, arity=3)` | 25 | 25 | 0 | 0 |
| `poly(max-constant=3, max-coefficient=3, symbols=20, arity=3)` | 25 | 24 | 0 | 1 |
| `poly(max-constant=4, max-coefficient=4, symbols=6, arity=3)` | 25 | 25 | 0 | 0 |
| `poly(max-constant=8, max-coefficient=8, symbols=4, arity=2)` | 25 | 25 | 0 | 0 |
| `kbo(weight=3, symbols=3)` | 24 | 24 | 0 | 0 |
| `matrix(max-constant=4, max-coefficient=4, symbols=3, arity=1, dim=4)` | 24 | 24 | 0 | 0 |
| `matrix(max-constant=5, max-coefficient=5, symbols=19, arity=3, dim=1)` | 24 | 24 | 0 | 0 |
| `matrix(max-constant=6, max-coefficient=6, symbols=3, arity=1, dim=3)` | 24 | 24 | 0 | 0 |
| `matrix(max-constant=8, max-coefficient=8, symbols=3, arity=1, dim=1)` | 24 | 22 | 1 | 1 |
| `poly(max-constant=1, max-coefficient=1, symbols=11, arity=3)` | 24 | 22 | 1 | 1 |
| `poly(max-constant=1, max-coefficient=1, symbols=9, arity=1)` | 24 | 24 | 0 | 0 |
| `poly(max-constant=15, max-coefficient=15, symbols=4, arity=1)` | 24 | 24 | 0 | 0 |
| `poly(max-constant=23, max-coefficient=23, symbols=4, arity=1)` | 24 | 24 | 0 | 0 |
| `poly(max-constant=3, max-coefficient=3, symbols=22, arity=2)` | 24 | 24 | 0 | 0 |
| `poly(max-constant=4, max-coefficient=4, symbols=14, arity=2)` | 24 | 24 | 0 | 0 |
| `poly(max-constant=5, max-coefficient=5, symbols=14, arity=6)` | 24 | 24 | 0 | 0 |
| `kbo(weight=1, symbols=4)` | 23 | 22 | 0 | 1 |
| `kbo(weight=3, symbols=12)` | 23 | 21 | 0 | 2 |
| `matrix(max-constant=1, max-coefficient=1, symbols=8, arity=2, dim=1)` | 23 | 23 | 0 | 0 |
| `matrix(max-constant=2, max-coefficient=2, symbols=10, arity=1, dim=1)` | 23 | 23 | 0 | 0 |
| `matrix(max-constant=2, max-coefficient=2, symbols=7, arity=2, dim=2)` | 23 | 23 | 0 | 0 |
| `matrix(max-constant=3, max-coefficient=3, symbols=2, arity=1, dim=4)` | 23 | 23 | 0 | 0 |
| `matrix(max-constant=5, max-coefficient=5, symbols=12, arity=2, dim=1)` | 23 | 23 | 0 | 0 |
| `matrix(max-constant=5, max-coefficient=5, symbols=15, arity=3, dim=1)` | 23 | 23 | 0 | 0 |
| `matrix(max-constant=5, max-coefficient=5, symbols=20, arity=3, dim=1)` | 23 | 23 | 0 | 0 |
| `matrix(max-constant=6, max-coefficient=6, symbols=2, arity=1, dim=3)` | 23 | 22 | 0 | 1 |
| `poly(max-constant=4, max-coefficient=4, symbols=4, arity=3)` | 23 | 23 | 0 | 0 |
| `kbo(weight=2, symbols=4)` | 22 | 20 | 1 | 1 |
| `matrix(max-constant=1, max-coefficient=1, symbols=17, arity=2, dim=1)` | 22 | 21 | 0 | 1 |
| `matrix(max-constant=1, max-coefficient=1, symbols=3, arity=2, dim=1)` | 22 | 22 | 0 | 0 |
| `matrix(max-constant=15, max-coefficient=15, symbols=3, arity=1, dim=3)` | 22 | 22 | 0 | 0 |
| `matrix(max-constant=2, max-coefficient=2, symbols=5, arity=2, dim=3)` | 22 | 22 | 0 | 0 |
| `matrix(max-constant=3, max-coefficient=3, symbols=7, arity=1, dim=1)` | 22 | 21 | 0 | 1 |
| `matrix(max-constant=3, max-coefficient=3, symbols=7, arity=3, dim=1)` | 22 | 20 | 0 | 2 |
| `matrix(max-constant=4, max-coefficient=4, symbols=5, arity=1, dim=3)` | 22 | 21 | 1 | 0 |
| `matrix(max-constant=7, max-coefficient=7, symbols=5, arity=1, dim=2)` | 22 | 21 | 1 | 0 |
| `matrix(max-constant=8, max-coefficient=8, symbols=4, arity=1, dim=2)` | 22 | 22 | 0 | 0 |
| `poly(max-constant=1, max-coefficient=1, symbols=13, arity=2)` | 22 | 22 | 0 | 0 |
| `poly(max-constant=2, max-coefficient=2, symbols=24, arity=3)` | 22 | 21 | 0 | 1 |
| `poly(max-constant=3, max-coefficient=3, symbols=4, arity=3)` | 22 | 22 | 0 | 0 |
| `poly(max-constant=42, max-coefficient=42, symbols=4, arity=1)` | 22 | 22 | 0 | 0 |
| `poly(max-constant=5, max-coefficient=5, symbols=16, arity=3)` | 22 | 22 | 0 | 0 |
| `poly(max-constant=9, max-coefficient=9, symbols=3, arity=1)` | 22 | 22 | 0 | 0 |
| `kbo(weight=3, symbols=11)` | 21 | 21 | 0 | 0 |
| `kbo(weight=3, symbols=9)` | 21 | 20 | 1 | 0 |
| `kbo(weight=5, symbols=3)` | 21 | 21 | 0 | 0 |
| `matrix(max-constant=1, max-coefficient=1, symbols=18, arity=2, dim=2)` | 21 | 20 | 1 | 0 |
| `matrix(max-constant=1, max-coefficient=1, symbols=21, arity=3, dim=1)` | 21 | 21 | 0 | 0 |
| `matrix(max-constant=1, max-coefficient=1, symbols=7, arity=1, dim=1)` | 21 | 20 | 1 | 0 |
| `matrix(max-constant=3, max-coefficient=3, symbols=23, arity=2, dim=1)` | 21 | 21 | 0 | 0 |
| `matrix(max-constant=3, max-coefficient=3, symbols=6, arity=1, dim=3)` | 21 | 20 | 0 | 1 |
| `matrix(max-constant=4, max-coefficient=4, symbols=2, arity=1, dim=5)` | 21 | 19 | 1 | 1 |
| `matrix(max-constant=4, max-coefficient=4, symbols=6, arity=1, dim=2)` | 21 | 21 | 0 | 0 |
| `poly(max-constant=0, max-coefficient=1, symbols=7, arity=2)` | 21 | 21 | 0 | 0 |
| `poly(max-constant=2, max-coefficient=2, symbols=37, arity=3)` | 21 | 21 | 0 | 0 |
| `poly(max-constant=3, max-coefficient=3, symbols=15, arity=3)` | 21 | 20 | 0 | 1 |
| `poly(max-constant=3, max-coefficient=3, symbols=19, arity=2)` | 21 | 21 | 0 | 0 |
| `poly(max-constant=3, max-coefficient=3, symbols=21, arity=3)` | 21 | 21 | 0 | 0 |
| `poly(max-constant=4, max-coefficient=4, symbols=15, arity=2)` | 21 | 21 | 0 | 0 |
| `poly(max-constant=4, max-coefficient=4, symbols=15, arity=3)` | 21 | 21 | 0 | 0 |
| `poly(max-constant=4, max-coefficient=4, symbols=9, arity=2)` | 21 | 21 | 0 | 0 |
| `poly(max-constant=5, max-coefficient=5, symbols=7, arity=4)` | 21 | 20 | 1 | 0 |
| `kbo(weight=1, symbols=2)` | 20 | 19 | 1 | 0 |
| `kbo(weight=3, symbols=14)` | 20 | 18 | 1 | 1 |
| `matrix(max-constant=1, max-coefficient=1, symbols=4, arity=1, dim=1)` | 20 | 20 | 0 | 0 |
| `matrix(max-constant=3, max-coefficient=3, symbols=6, arity=3, dim=1)` | 20 | 20 | 0 | 0 |
| `matrix(max-constant=3, max-coefficient=3, symbols=7, arity=2, dim=2)` | 20 | 20 | 0 | 0 |
| `matrix(max-constant=4, max-coefficient=4, symbols=5, arity=1, dim=2)` | 20 | 19 | 0 | 1 |
| `matrix(max-constant=5, max-coefficient=5, symbols=2, arity=1, dim=3)` | 20 | 20 | 0 | 0 |
| `matrix(max-constant=5, max-coefficient=5, symbols=4, arity=3, dim=2)` | 20 | 20 | 0 | 0 |
| `poly(max-constant=1, max-coefficient=1, symbols=26, arity=3)` | 20 | 19 | 1 | 0 |
| `poly(max-constant=10, max-coefficient=10, symbols=5, arity=1)` | 20 | 20 | 0 | 0 |
| `poly(max-constant=14, max-coefficient=14, symbols=6, arity=1)` | 20 | 20 | 0 | 0 |
| `poly(max-constant=16, max-coefficient=16, symbols=6, arity=1)` | 20 | 19 | 0 | 1 |
| `poly(max-constant=3, max-coefficient=3, symbols=33, arity=5)` | 20 | 20 | 0 | 0 |
| `poly(max-constant=4, max-coefficient=4, symbols=8, arity=1)` | 20 | 20 | 0 | 0 |
| `poly(max-constant=5, max-coefficient=5, symbols=12, arity=5)` | 20 | 20 | 0 | 0 |
| `poly(max-constant=5, max-coefficient=5, symbols=7, arity=1)` | 20 | 20 | 0 | 0 |
| `kbo(weight=1, symbols=7)` | 19 | 19 | 0 | 0 |
| `kbo(weight=6, symbols=4)` | 19 | 19 | 0 | 0 |
| `matrix(max-constant=2, max-coefficient=2, symbols=10, arity=3, dim=1)` | 19 | 19 | 0 | 0 |
| `matrix(max-constant=2, max-coefficient=2, symbols=8, arity=1, dim=1)` | 19 | 19 | 0 | 0 |
| `matrix(max-constant=3, max-coefficient=3, symbols=6, arity=2, dim=4)` | 19 | 18 | 0 | 1 |
| `matrix(max-constant=6, max-coefficient=6, symbols=2, arity=1, dim=5)` | 19 | 19 | 0 | 0 |
| `poly(max-constant=1, max-coefficient=1, symbols=18, arity=2)` | 19 | 19 | 0 | 0 |
| `poly(max-constant=16, max-coefficient=16, symbols=4, arity=1)` | 19 | 19 | 0 | 0 |
| `poly(max-constant=3, max-coefficient=3, symbols=12, arity=3)` | 19 | 18 | 1 | 0 |
| `poly(max-constant=4, max-coefficient=4, symbols=9, arity=3)` | 19 | 19 | 0 | 0 |
| `poly(max-constant=5, max-coefficient=5, symbols=26, arity=3)` | 19 | 19 | 0 | 0 |
| `poly(max-constant=8, max-coefficient=8, symbols=7, arity=1)` | 19 | 19 | 0 | 0 |
| `matrix(max-constant=1, max-coefficient=1, symbols=4, arity=1, dim=4)` | 18 | 18 | 0 | 0 |
| `matrix(max-constant=2, max-coefficient=2, symbols=10, arity=2, dim=2)` | 18 | 18 | 0 | 0 |
| `matrix(max-constant=2, max-coefficient=2, symbols=23, arity=2, dim=1)` | 18 | 18 | 0 | 0 |
| `matrix(max-constant=2, max-coefficient=2, symbols=24, arity=2, dim=1)` | 18 | 18 | 0 | 0 |
| `matrix(max-constant=2, max-coefficient=2, symbols=26, arity=4, dim=1)` | 18 | 17 | 0 | 1 |
| `matrix(max-constant=3, max-coefficient=3, symbols=24, arity=2, dim=1)` | 18 | 18 | 0 | 0 |
| `matrix(max-constant=4, max-coefficient=4, symbols=3, arity=2, dim=3)` | 18 | 18 | 0 | 0 |
| `matrix(max-constant=5, max-coefficient=5, symbols=10, arity=2, dim=3)` | 18 | 18 | 0 | 0 |
| `matrix(max-constant=5, max-coefficient=5, symbols=12, arity=2, dim=2)` | 18 | 18 | 0 | 0 |
| `matrix(max-constant=9, max-coefficient=9, symbols=3, arity=1, dim=3)` | 18 | 17 | 0 | 1 |
| `poly(max-constant=16, max-coefficient=16, symbols=3, arity=1)` | 18 | 18 | 0 | 0 |
| `poly(max-constant=3, max-coefficient=3, symbols=11, arity=4)` | 18 | 17 | 1 | 0 |
| `poly(max-constant=4, max-coefficient=4, symbols=11, arity=2)` | 18 | 18 | 0 | 0 |
| `poly(max-constant=5, max-coefficient=5, symbols=3, arity=3)` | 18 | 17 | 1 | 0 |
| `poly(max-constant=8, max-coefficient=8, symbols=2, arity=1)` | 18 | 18 | 0 | 0 |
| `kbo(weight=12, symbols=3)` | 17 | 17 | 0 | 0 |
| `kbo(weight=3, symbols=41)` | 17 | 17 | 0 | 0 |
| `matrix(max-constant=1, max-coefficient=1, symbols=4, arity=1, dim=2)` | 17 | 17 | 0 | 0 |
| `matrix(max-constant=1, max-coefficient=1, symbols=5, arity=1, dim=2)` | 17 | 16 | 1 | 0 |
| `matrix(max-constant=2, max-coefficient=2, symbols=10, arity=2, dim=3)` | 17 | 16 | 0 | 1 |
| `matrix(max-constant=2, max-coefficient=2, symbols=3, arity=3, dim=1)` | 17 | 17 | 0 | 0 |
| `matrix(max-constant=3, max-coefficient=3, symbols=9, arity=1, dim=1)` | 17 | 17 | 0 | 0 |
| `matrix(max-constant=3, max-coefficient=3, symbols=9, arity=2, dim=1)` | 17 | 15 | 1 | 1 |
| `matrix(max-constant=5, max-coefficient=5, symbols=15, arity=2, dim=3)` | 17 | 17 | 0 | 0 |
| `matrix(max-constant=7, max-coefficient=7, symbols=3, arity=1, dim=2)` | 17 | 17 | 0 | 0 |
| `poly(max-constant=1, max-coefficient=1, symbols=32, arity=3)` | 17 | 16 | 1 | 0 |
| `poly(max-constant=21, max-coefficient=21, symbols=4, arity=1)` | 17 | 17 | 0 | 0 |
| `poly(max-constant=22, max-coefficient=22, symbols=4, arity=1)` | 17 | 17 | 0 | 0 |
| `poly(max-constant=27, max-coefficient=27, symbols=6, arity=1)` | 17 | 17 | 0 | 0 |
| `poly(max-constant=3, max-coefficient=3, symbols=28, arity=3)` | 17 | 16 | 1 | 0 |
| `poly(max-constant=3, max-coefficient=3, symbols=40, arity=3)` | 17 | 17 | 0 | 0 |
| `poly(max-constant=4, max-coefficient=4, symbols=8, arity=2)` | 17 | 17 | 0 | 0 |
| `poly(max-constant=6, max-coefficient=6, symbols=5, arity=1)` | 17 | 17 | 0 | 0 |
| `poly(max-constant=8, max-coefficient=8, symbols=3, arity=1)` | 17 | 17 | 0 | 0 |
| `poly(max-constant=8, max-coefficient=8, symbols=9, arity=2)` | 17 | 17 | 0 | 0 |
| `kbo(weight=1, symbols=6)` | 16 | 16 | 0 | 0 |
| `matrix(max-constant=1, max-coefficient=1, symbols=10, arity=2, dim=2)` | 16 | 16 | 0 | 0 |
| `matrix(max-constant=1, max-coefficient=1, symbols=12, arity=2, dim=3)` | 16 | 16 | 0 | 0 |
| `matrix(max-constant=1, max-coefficient=1, symbols=6, arity=3, dim=3)` | 16 | 16 | 0 | 0 |
| `matrix(max-constant=1, max-coefficient=1, symbols=9, arity=2, dim=3)` | 16 | 15 | 0 | 1 |
| `matrix(max-constant=2, max-coefficient=2, symbols=3, arity=2, dim=3)` | 16 | 16 | 0 | 0 |
| `matrix(max-constant=2, max-coefficient=2, symbols=6, arity=2, dim=2)` | 16 | 16 | 0 | 0 |
| `matrix(max-constant=2, max-coefficient=2, symbols=9, arity=2, dim=1)` | 16 | 16 | 0 | 0 |
| `matrix(max-constant=2, max-coefficient=2, symbols=9, arity=2, dim=3)` | 16 | 16 | 0 | 0 |
| `matrix(max-constant=3, max-coefficient=3, symbols=10, arity=2, dim=2)` | 16 | 16 | 0 | 0 |
| `matrix(max-constant=3, max-coefficient=3, symbols=13, arity=2, dim=1)` | 16 | 15 | 1 | 0 |
| `matrix(max-constant=3, max-coefficient=3, symbols=16, arity=2, dim=1)` | 16 | 15 | 0 | 1 |
| `matrix(max-constant=3, max-coefficient=3, symbols=16, arity=2, dim=2)` | 16 | 16 | 0 | 0 |
| `matrix(max-constant=3, max-coefficient=3, symbols=9, arity=2, dim=2)` | 16 | 16 | 0 | 0 |
| `matrix(max-constant=4, max-coefficient=4, symbols=4, arity=1, dim=2)` | 16 | 16 | 0 | 0 |
| `matrix(max-constant=4, max-coefficient=4, symbols=6, arity=2, dim=3)` | 16 | 16 | 0 | 0 |
| `matrix(max-constant=4, max-coefficient=4, symbols=9, arity=3, dim=1)` | 16 | 13 | 0 | 3 |
| `poly(max-constant=0, max-coefficient=1, symbols=7, arity=3)` | 16 | 15 | 1 | 0 |
| `poly(max-constant=1, max-coefficient=1, symbols=1, arity=2)` | 16 | 16 | 0 | 0 |
| `poly(max-constant=1, max-coefficient=1, symbols=17, arity=4)` | 16 | 15 | 0 | 1 |
| `poly(max-constant=13, max-coefficient=13, symbols=4, arity=1)` | 16 | 15 | 1 | 0 |
| `poly(max-constant=2, max-coefficient=2, symbols=1, arity=2)` | 16 | 15 | 1 | 0 |
| `poly(max-constant=2, max-coefficient=2, symbols=13, arity=4)` | 16 | 16 | 0 | 0 |
| `poly(max-constant=2, max-coefficient=2, symbols=18, arity=2)` | 16 | 16 | 0 | 0 |
| `poly(max-constant=32, max-coefficient=32, symbols=4, arity=1)` | 16 | 16 | 0 | 0 |
| `poly(max-constant=4, max-coefficient=4, symbols=8, arity=4)` | 16 | 16 | 0 | 0 |
| `poly(max-constant=41, max-coefficient=41, symbols=4, arity=1)` | 16 | 15 | 0 | 1 |
| `poly(max-constant=5, max-coefficient=5, symbols=8, arity=1)` | 16 | 16 | 0 | 0 |
| `poly(max-constant=9, max-coefficient=9, symbols=4, arity=1)` | 16 | 16 | 0 | 0 |
| `kbo(weight=1, symbols=8)` | 15 | 15 | 0 | 0 |
| `matrix(max-constant=1, max-coefficient=1, symbols=2, arity=1, dim=7)` | 15 | 14 | 1 | 0 |
| `matrix(max-constant=10, max-coefficient=10, symbols=3, arity=1, dim=3)` | 15 | 14 | 0 | 1 |
| `matrix(max-constant=12, max-coefficient=12, symbols=3, arity=1, dim=3)` | 15 | 14 | 1 | 0 |
| `matrix(max-constant=13, max-coefficient=13, symbols=2, arity=1, dim=3)` | 15 | 15 | 0 | 0 |
| `matrix(max-constant=2, max-coefficient=2, symbols=10, arity=1, dim=2)` | 15 | 15 | 0 | 0 |
| `matrix(max-constant=3, max-coefficient=3, symbols=6, arity=2, dim=1)` | 15 | 14 | 0 | 1 |
| `matrix(max-constant=3, max-coefficient=3, symbols=7, arity=1, dim=5)` | 15 | 15 | 0 | 0 |
| `matrix(max-constant=7, max-coefficient=7, symbols=3, arity=1, dim=3)` | 15 | 15 | 0 | 0 |
| `poly(max-constant=2, max-coefficient=2, symbols=23, arity=3)` | 15 | 15 | 0 | 0 |
| `poly(max-constant=2, max-coefficient=2, symbols=25, arity=2)` | 15 | 15 | 0 | 0 |
| `poly(max-constant=4, max-coefficient=4, symbols=10, arity=2)` | 15 | 15 | 0 | 0 |
| `poly(max-constant=8, max-coefficient=8, symbols=12, arity=2)` | 15 | 15 | 0 | 0 |
| `poly(max-constant=8, max-coefficient=8, symbols=17, arity=2)` | 15 | 14 | 1 | 0 |
| `kbo(weight=5, symbols=43)` | 14 | 14 | 0 | 0 |
| `matrix(max-constant=1, max-coefficient=1, symbols=3, arity=1, dim=7)` | 14 | 13 | 0 | 1 |
| `matrix(max-constant=2, max-coefficient=2, symbols=10, arity=2, dim=1)` | 14 | 13 | 0 | 1 |
| `matrix(max-constant=2, max-coefficient=2, symbols=7, arity=1, dim=1)` | 14 | 11 | 1 | 2 |
| `matrix(max-constant=2, max-coefficient=2, symbols=7, arity=3, dim=1)` | 14 | 13 | 1 | 0 |
| `matrix(max-constant=3, max-coefficient=3, symbols=25, arity=2, dim=2)` | 14 | 14 | 0 | 0 |
| `matrix(max-constant=3, max-coefficient=3, symbols=7, arity=3, dim=2)` | 14 | 14 | 0 | 0 |
| `matrix(max-constant=4, max-coefficient=4, symbols=19, arity=3, dim=1)` | 14 | 13 | 1 | 0 |
| `matrix(max-constant=5, max-coefficient=5, symbols=10, arity=1, dim=4)` | 14 | 14 | 0 | 0 |
| `matrix(max-constant=5, max-coefficient=5, symbols=14, arity=2, dim=1)` | 14 | 14 | 0 | 0 |
| `matrix(max-constant=5, max-coefficient=5, symbols=2, arity=1, dim=4)` | 14 | 13 | 0 | 1 |
| `matrix(max-constant=5, max-coefficient=5, symbols=3, arity=1, dim=2)` | 14 | 14 | 0 | 0 |
| `matrix(max-constant=5, max-coefficient=5, symbols=6, arity=1, dim=2)` | 14 | 13 | 1 | 0 |
| `poly(max-constant=1, max-coefficient=1, symbols=10, arity=1)` | 14 | 14 | 0 | 0 |
| `poly(max-constant=1, max-coefficient=1, symbols=16, arity=3)` | 14 | 14 | 0 | 0 |
| `poly(max-constant=1, max-coefficient=1, symbols=4, arity=4)` | 14 | 14 | 0 | 0 |
| `poly(max-constant=11, max-coefficient=11, symbols=6, arity=1)` | 14 | 14 | 0 | 0 |
| `poly(max-constant=17, max-coefficient=17, symbols=6, arity=1)` | 14 | 14 | 0 | 0 |
| `poly(max-constant=2, max-coefficient=2, symbols=10, arity=4)` | 14 | 12 | 1 | 1 |
| `poly(max-constant=2, max-coefficient=2, symbols=17, arity=3)` | 14 | 14 | 0 | 0 |
| `poly(max-constant=2, max-coefficient=2, symbols=9, arity=1)` | 14 | 14 | 0 | 0 |
| `poly(max-constant=21, max-coefficient=21, symbols=5, arity=1)` | 14 | 14 | 0 | 0 |
| `poly(max-constant=4, max-coefficient=4, symbols=13, arity=3)` | 14 | 13 | 0 | 1 |
| `poly(max-constant=4, max-coefficient=4, symbols=13, arity=4)` | 14 | 14 | 0 | 0 |
| `poly(max-constant=5, max-coefficient=5, symbols=10, arity=1)` | 14 | 13 | 0 | 1 |
| `kbo(weight=4, symbols=12)` | 13 | 13 | 0 | 0 |
| `matrix(max-constant=1, max-coefficient=1, symbols=14, arity=2, dim=1)` | 13 | 13 | 0 | 0 |
| `matrix(max-constant=1, max-coefficient=1, symbols=16, arity=2, dim=1)` | 13 | 13 | 0 | 0 |
| `matrix(max-constant=1, max-coefficient=1, symbols=19, arity=2, dim=2)` | 13 | 13 | 0 | 0 |
| `matrix(max-constant=1, max-coefficient=1, symbols=3, arity=1, dim=6)` | 13 | 13 | 0 | 0 |
| `matrix(max-constant=1, max-coefficient=1, symbols=5, arity=2, dim=1)` | 13 | 12 | 0 | 1 |
| `matrix(max-constant=10, max-coefficient=10, symbols=2, arity=1, dim=3)` | 13 | 12 | 1 | 0 |
| `matrix(max-constant=13, max-coefficient=13, symbols=3, arity=1, dim=3)` | 13 | 13 | 0 | 0 |
| `matrix(max-constant=2, max-coefficient=2, symbols=12, arity=2, dim=3)` | 13 | 12 | 1 | 0 |
| `matrix(max-constant=2, max-coefficient=2, symbols=17, arity=2, dim=1)` | 13 | 13 | 0 | 0 |
| `matrix(max-constant=2, max-coefficient=2, symbols=3, arity=1, dim=6)` | 13 | 12 | 1 | 0 |
| `matrix(max-constant=2, max-coefficient=2, symbols=5, arity=1, dim=4)` | 13 | 13 | 0 | 0 |
| `matrix(max-constant=2, max-coefficient=2, symbols=8, arity=2, dim=2)` | 13 | 13 | 0 | 0 |
| `matrix(max-constant=3, max-coefficient=3, symbols=3, arity=1, dim=1)` | 13 | 13 | 0 | 0 |
| `matrix(max-constant=4, max-coefficient=4, symbols=11, arity=2, dim=3)` | 13 | 13 | 0 | 0 |
| `matrix(max-constant=4, max-coefficient=4, symbols=13, arity=4, dim=1)` | 13 | 13 | 0 | 0 |
| `matrix(max-constant=4, max-coefficient=4, symbols=15, arity=3, dim=1)` | 13 | 13 | 0 | 0 |
| `matrix(max-constant=4, max-coefficient=4, symbols=3, arity=1, dim=5)` | 13 | 13 | 0 | 0 |
| `matrix(max-constant=41, max-coefficient=41, symbols=3, arity=1, dim=5)` | 13 | 13 | 0 | 0 |
| `matrix(max-constant=5, max-coefficient=5, symbols=5, arity=1, dim=2)` | 13 | 13 | 0 | 0 |
| `matrix(max-constant=8, max-coefficient=8, symbols=4, arity=1, dim=1)` | 13 | 13 | 0 | 0 |
| `poly(max-constant=0, max-coefficient=1, symbols=9, arity=3)` | 13 | 13 | 0 | 0 |
| `poly(max-constant=1, max-coefficient=1, symbols=17, arity=2)` | 13 | 13 | 0 | 0 |
| `poly(max-constant=2, max-coefficient=2, symbols=18, arity=3)` | 13 | 13 | 0 | 0 |
| `poly(max-constant=3, max-coefficient=3, symbols=17, arity=4)` | 13 | 13 | 0 | 0 |
| `poly(max-constant=3, max-coefficient=3, symbols=9, arity=1)` | 13 | 13 | 0 | 0 |
| `poly(max-constant=4, max-coefficient=4, symbols=26, arity=3)` | 13 | 13 | 0 | 0 |
| `poly(max-constant=5, max-coefficient=5, symbols=14, arity=3)` | 13 | 13 | 0 | 0 |
| `poly(max-constant=5, max-coefficient=5, symbols=16, arity=2)` | 13 | 13 | 0 | 0 |
| `poly(max-constant=5, max-coefficient=5, symbols=25, arity=2)` | 13 | 12 | 1 | 0 |
| `poly(max-constant=5, max-coefficient=5, symbols=5, arity=3)` | 13 | 13 | 0 | 0 |
| `poly(max-constant=7, max-coefficient=7, symbols=2, arity=1)` | 13 | 12 | 1 | 0 |
| `poly(max-constant=8, max-coefficient=8, symbols=7, arity=2)` | 13 | 13 | 0 | 0 |
| `kbo(weight=2, symbols=6)` | 12 | 12 | 0 | 0 |
| `kbo(weight=3, symbols=28)` | 12 | 12 | 0 | 0 |
| `kbo(weight=4, symbols=5)` | 12 | 12 | 0 | 0 |
| `kbo(weight=4, symbols=7)` | 12 | 12 | 0 | 0 |
| `kbo(weight=5, symbols=11)` | 12 | 11 | 1 | 0 |
| `kbo(weight=6, symbols=3)` | 12 | 11 | 1 | 0 |
| `matrix(max-constant=1, max-coefficient=1, symbols=11, arity=2, dim=3)` | 12 | 12 | 0 | 0 |
| `matrix(max-constant=1, max-coefficient=1, symbols=3, arity=1, dim=1)` | 12 | 12 | 0 | 0 |
| `matrix(max-constant=1, max-coefficient=1, symbols=3, arity=3, dim=2)` | 12 | 12 | 0 | 0 |
| `matrix(max-constant=18, max-coefficient=18, symbols=3, arity=1, dim=3)` | 12 | 12 | 0 | 0 |
| `matrix(max-constant=2, max-coefficient=2, symbols=9, arity=1, dim=2)` | 12 | 12 | 0 | 0 |
| `matrix(max-constant=21, max-coefficient=21, symbols=2, arity=1, dim=5)` | 12 | 11 | 1 | 0 |
| `matrix(max-constant=3, max-coefficient=3, symbols=13, arity=2, dim=3)` | 12 | 12 | 0 | 0 |
| `matrix(max-constant=3, max-coefficient=3, symbols=19, arity=2, dim=3)` | 12 | 12 | 0 | 0 |
| `matrix(max-constant=5, max-coefficient=5, symbols=12, arity=2, dim=3)` | 12 | 12 | 0 | 0 |
| `matrix(max-constant=5, max-coefficient=5, symbols=8, arity=1, dim=2)` | 12 | 11 | 1 | 0 |
| `matrix(max-constant=5, max-coefficient=5, symbols=9, arity=2, dim=3)` | 12 | 12 | 0 | 0 |
| `matrix(max-constant=6, max-coefficient=6, symbols=3, arity=1, dim=5)` | 12 | 12 | 0 | 0 |
| `matrix(max-constant=9, max-coefficient=9, symbols=2, arity=1, dim=3)` | 12 | 11 | 0 | 1 |
| `poly(max-constant=10, max-coefficient=10, symbols=15, arity=1)` | 12 | 12 | 0 | 0 |
| `poly(max-constant=130, max-coefficient=130, symbols=4, arity=1)` | 12 | 12 | 0 | 0 |
| `poly(max-constant=2, max-coefficient=2, symbols=11, arity=4)` | 12 | 12 | 0 | 0 |
| `poly(max-constant=2, max-coefficient=2, symbols=24, arity=2)` | 12 | 12 | 0 | 0 |
| `poly(max-constant=2, max-coefficient=2, symbols=33, arity=2)` | 12 | 12 | 0 | 0 |
| `poly(max-constant=25, max-coefficient=25, symbols=4, arity=1)` | 12 | 11 | 1 | 0 |
| `poly(max-constant=3, max-coefficient=3, symbols=44, arity=3)` | 12 | 12 | 0 | 0 |
| `poly(max-constant=30, max-coefficient=30, symbols=6, arity=1)` | 12 | 11 | 1 | 0 |
| `poly(max-constant=35, max-coefficient=35, symbols=4, arity=1)` | 12 | 12 | 0 | 0 |
| `poly(max-constant=38, max-coefficient=38, symbols=4, arity=1)` | 12 | 12 | 0 | 0 |
| `poly(max-constant=4, max-coefficient=4, symbols=12, arity=3)` | 12 | 12 | 0 | 0 |
| `poly(max-constant=4, max-coefficient=4, symbols=12, arity=5)` | 12 | 12 | 0 | 0 |
| `poly(max-constant=45, max-coefficient=45, symbols=4, arity=1)` | 12 | 11 | 0 | 1 |
| `poly(max-constant=5, max-coefficient=5, symbols=19, arity=3)` | 12 | 12 | 0 | 0 |
| `poly(max-constant=55, max-coefficient=55, symbols=4, arity=1)` | 12 | 12 | 0 | 0 |
| `poly(max-constant=6, max-coefficient=6, symbols=3, arity=2)` | 12 | 12 | 0 | 0 |
| `kbo(weight=2, symbols=21)` | 11 | 11 | 0 | 0 |
| `kbo(weight=4, symbols=6)` | 11 | 11 | 0 | 0 |
| `kbo(weight=4, symbols=9)` | 11 | 11 | 0 | 0 |
| `kbo(weight=8, symbols=3)` | 11 | 11 | 0 | 0 |
| `matrix(max-constant=1, max-coefficient=1, symbols=11, arity=3, dim=3)` | 11 | 10 | 0 | 1 |
| `matrix(max-constant=1, max-coefficient=1, symbols=5, arity=3, dim=3)` | 11 | 11 | 0 | 0 |
| `matrix(max-constant=11, max-coefficient=11, symbols=2, arity=1, dim=3)` | 11 | 11 | 0 | 0 |
| `matrix(max-constant=11, max-coefficient=11, symbols=3, arity=1, dim=3)` | 11 | 11 | 0 | 0 |
| `matrix(max-constant=2, max-coefficient=2, symbols=7, arity=1, dim=3)` | 11 | 11 | 0 | 0 |
| `matrix(max-constant=3, max-coefficient=3, symbols=10, arity=1, dim=3)` | 11 | 11 | 0 | 0 |
| `matrix(max-constant=3, max-coefficient=3, symbols=2, arity=1, dim=1)` | 11 | 11 | 0 | 0 |
| `matrix(max-constant=4, max-coefficient=4, symbols=20, arity=3, dim=1)` | 11 | 11 | 0 | 0 |
| `matrix(max-constant=5, max-coefficient=5, symbols=26, arity=4, dim=1)` | 11 | 10 | 1 | 0 |
| `matrix(max-constant=5, max-coefficient=5, symbols=3, arity=1, dim=5)` | 11 | 10 | 0 | 1 |
| `matrix(max-constant=5, max-coefficient=5, symbols=6, arity=2, dim=2)` | 11 | 11 | 0 | 0 |
| `matrix(max-constant=5, max-coefficient=5, symbols=7, arity=2, dim=3)` | 11 | 11 | 0 | 0 |
| `matrix(max-constant=5, max-coefficient=5, symbols=8, arity=2, dim=2)` | 11 | 10 | 0 | 1 |
| `matrix(max-constant=8, max-coefficient=8, symbols=3, arity=1, dim=3)` | 11 | 11 | 0 | 0 |
| `poly(max-constant=1, max-coefficient=1, symbols=15, arity=3)` | 11 | 10 | 1 | 0 |
| `poly(max-constant=10, max-coefficient=10, symbols=3, arity=1)` | 11 | 11 | 0 | 0 |
| `poly(max-constant=2, max-coefficient=2, symbols=10, arity=1)` | 11 | 11 | 0 | 0 |
| `poly(max-constant=2, max-coefficient=2, symbols=47, arity=3)` | 11 | 10 | 1 | 0 |
| `poly(max-constant=3, max-coefficient=3, symbols=18, arity=3)` | 11 | 11 | 0 | 0 |
| `poly(max-constant=4, max-coefficient=4, symbols=10, arity=3)` | 11 | 10 | 1 | 0 |
| `poly(max-constant=4, max-coefficient=4, symbols=11, arity=3)` | 11 | 11 | 0 | 0 |
| `poly(max-constant=6, max-coefficient=6, symbols=5, arity=2)` | 11 | 11 | 0 | 0 |
| `kbo(weight=1, symbols=21)` | 10 | 10 | 0 | 0 |
| `kbo(weight=2, symbols=14)` | 10 | 10 | 0 | 0 |
| `kbo(weight=2, symbols=26)` | 10 | 10 | 0 | 0 |
| `kbo(weight=3, symbols=21)` | 10 | 10 | 0 | 0 |
| `matrix(max-constant=1, max-coefficient=1, symbols=5, arity=1, dim=4)` | 10 | 10 | 0 | 0 |
| `matrix(max-constant=1, max-coefficient=1, symbols=6, arity=3, dim=2)` | 10 | 10 | 0 | 0 |
| `matrix(max-constant=1, max-coefficient=1, symbols=8, arity=3, dim=3)` | 10 | 9 | 0 | 1 |
| `matrix(max-constant=1, max-coefficient=1, symbols=9, arity=2, dim=1)` | 10 | 10 | 0 | 0 |
| `matrix(max-constant=11, max-coefficient=11, symbols=2, arity=1, dim=5)` | 10 | 10 | 0 | 0 |
| `matrix(max-constant=15, max-coefficient=15, symbols=4, arity=1, dim=2)` | 10 | 10 | 0 | 0 |
| `matrix(max-constant=2, max-coefficient=2, symbols=16, arity=2, dim=3)` | 10 | 10 | 0 | 0 |
| `matrix(max-constant=2, max-coefficient=2, symbols=2, arity=2, dim=3)` | 10 | 10 | 0 | 0 |
| `matrix(max-constant=2, max-coefficient=2, symbols=4, arity=1, dim=4)` | 10 | 10 | 0 | 0 |
| `matrix(max-constant=2, max-coefficient=2, symbols=5, arity=1, dim=1)` | 10 | 10 | 0 | 0 |
| `matrix(max-constant=21, max-coefficient=21, symbols=3, arity=1, dim=3)` | 10 | 10 | 0 | 0 |
| `matrix(max-constant=3, max-coefficient=3, symbols=11, arity=5, dim=1)` | 10 | 10 | 0 | 0 |
| `matrix(max-constant=3, max-coefficient=3, symbols=17, arity=3, dim=1)` | 10 | 10 | 0 | 0 |
| `matrix(max-constant=4, max-coefficient=4, symbols=8, arity=2, dim=3)` | 10 | 9 | 1 | 0 |
| `matrix(max-constant=5, max-coefficient=5, symbols=10, arity=3, dim=3)` | 10 | 10 | 0 | 0 |
| `matrix(max-constant=5, max-coefficient=5, symbols=7, arity=1, dim=2)` | 10 | 10 | 0 | 0 |
| `matrix(max-constant=5, max-coefficient=5, symbols=7, arity=1, dim=3)` | 10 | 9 | 1 | 0 |
| `poly(max-constant=0, max-coefficient=1, symbols=2, arity=1)` | 10 | 10 | 0 | 0 |
| `poly(max-constant=1, max-coefficient=1, symbols=2, arity=0)` | 10 | 10 | 0 | 0 |
| `poly(max-constant=1, max-coefficient=1, symbols=30, arity=5)` | 10 | 10 | 0 | 0 |
| `poly(max-constant=10, max-coefficient=10, symbols=4, arity=2)` | 10 | 10 | 0 | 0 |
| `poly(max-constant=10, max-coefficient=10, symbols=47, arity=3)` | 10 | 10 | 0 | 0 |
| `poly(max-constant=10, max-coefficient=10, symbols=6, arity=1)` | 10 | 10 | 0 | 0 |
| `poly(max-constant=2, max-coefficient=2, symbols=29, arity=3)` | 10 | 10 | 0 | 0 |
| `poly(max-constant=2, max-coefficient=2, symbols=33, arity=3)` | 10 | 10 | 0 | 0 |
| `poly(max-constant=2, max-coefficient=2, symbols=44, arity=2)` | 10 | 10 | 0 | 0 |
| `poly(max-constant=22, max-coefficient=22, symbols=6, arity=1)` | 10 | 10 | 0 | 0 |
| `poly(max-constant=23, max-coefficient=23, symbols=6, arity=1)` | 10 | 10 | 0 | 0 |
| `poly(max-constant=24, max-coefficient=24, symbols=4, arity=1)` | 10 | 10 | 0 | 0 |
| `poly(max-constant=3, max-coefficient=3, symbols=18, arity=2)` | 10 | 10 | 0 | 0 |
| `poly(max-constant=6, max-coefficient=6, symbols=2, arity=2)` | 10 | 10 | 0 | 0 |
| `poly(max-constant=6, max-coefficient=6, symbols=4, arity=2)` | 10 | 10 | 0 | 0 |
| `poly(max-constant=7, max-coefficient=7, symbols=6, arity=3)` | 10 | 10 | 0 | 0 |
| `poly(max-constant=8, max-coefficient=8, symbols=11, arity=2)` | 10 | 10 | 0 | 0 |
| `poly(max-constant=8, max-coefficient=8, symbols=15, arity=2)` | 10 | 10 | 0 | 0 |
| `poly(max-constant=8, max-coefficient=8, symbols=8, arity=2)` | 10 | 10 | 0 | 0 |
| `kbo(weight=1, symbols=16)` | 9 | 9 | 0 | 0 |
| `kbo(weight=2, symbols=16)` | 9 | 9 | 0 | 0 |
| `kbo(weight=2, symbols=30)` | 9 | 9 | 0 | 0 |
| `kbo(weight=2, symbols=7)` | 9 | 9 | 0 | 0 |
| `match-bounds(max-bound=5)` | 9 | 8 | 1 | 0 |
| `matrix(max-constant=1, max-coefficient=1, symbols=15, arity=2, dim=3)` | 9 | 9 | 0 | 0 |
| `matrix(max-constant=1, max-coefficient=1, symbols=19, arity=2, dim=3)` | 9 | 9 | 0 | 0 |
| `matrix(max-constant=1, max-coefficient=1, symbols=24, arity=2, dim=1)` | 9 | 8 | 0 | 1 |
| `matrix(max-constant=1, max-coefficient=1, symbols=3, arity=3, dim=3)` | 9 | 9 | 0 | 0 |
| `matrix(max-constant=1, max-coefficient=1, symbols=4, arity=3, dim=4)` | 9 | 9 | 0 | 0 |
| `matrix(max-constant=1, max-coefficient=1, symbols=8, arity=2, dim=2)` | 9 | 9 | 0 | 0 |
| `matrix(max-constant=2, max-coefficient=2, symbols=16, arity=2, dim=1)` | 9 | 8 | 1 | 0 |
| `matrix(max-constant=2, max-coefficient=2, symbols=21, arity=3, dim=1)` | 9 | 9 | 0 | 0 |
| `matrix(max-constant=2, max-coefficient=2, symbols=6, arity=3, dim=1)` | 9 | 8 | 1 | 0 |
| `matrix(max-constant=3, max-coefficient=3, symbols=5, arity=3, dim=2)` | 9 | 9 | 0 | 0 |
| `matrix(max-constant=4, max-coefficient=4, symbols=10, arity=1, dim=3)` | 9 | 9 | 0 | 0 |
| `matrix(max-constant=4, max-coefficient=4, symbols=12, arity=2, dim=1)` | 9 | 9 | 0 | 0 |
| `matrix(max-constant=4, max-coefficient=4, symbols=2, arity=2, dim=2)` | 9 | 9 | 0 | 0 |
| `matrix(max-constant=4, max-coefficient=4, symbols=4, arity=2, dim=3)` | 9 | 9 | 0 | 0 |
| `matrix(max-constant=5, max-coefficient=5, symbols=15, arity=2, dim=2)` | 9 | 9 | 0 | 0 |
| `matrix(max-constant=5, max-coefficient=5, symbols=16, arity=3, dim=1)` | 9 | 9 | 0 | 0 |
| `matrix(max-constant=5, max-coefficient=5, symbols=26, arity=4, dim=3)` | 9 | 9 | 0 | 0 |
| `matrix(max-constant=8, max-coefficient=8, symbols=6, arity=1, dim=3)` | 9 | 9 | 0 | 0 |
| `matrix(max-constant=8, max-coefficient=8, symbols=7, arity=1, dim=2)` | 9 | 9 | 0 | 0 |
| `poly(max-constant=0, max-coefficient=1, symbols=8, arity=4)` | 9 | 9 | 0 | 0 |
| `poly(max-constant=1, max-coefficient=1, symbols=13, arity=4)` | 9 | 9 | 0 | 0 |
| `poly(max-constant=1, max-coefficient=1, symbols=19, arity=2)` | 9 | 9 | 0 | 0 |
| `poly(max-constant=1, max-coefficient=1, symbols=9, arity=4)` | 9 | 8 | 1 | 0 |
| `poly(max-constant=10, max-coefficient=10, symbols=6, arity=2)` | 9 | 9 | 0 | 0 |
| `poly(max-constant=12, max-coefficient=12, symbols=6, arity=1)` | 9 | 9 | 0 | 0 |
| `poly(max-constant=2, max-coefficient=2, symbols=31, arity=3)` | 9 | 8 | 1 | 0 |
| `poly(max-constant=28, max-coefficient=28, symbols=4, arity=1)` | 9 | 8 | 1 | 0 |
| `poly(max-constant=3, max-coefficient=3, symbols=25, arity=2)` | 9 | 9 | 0 | 0 |
| `poly(max-constant=4, max-coefficient=4, symbols=17, arity=3)` | 9 | 9 | 0 | 0 |
| `poly(max-constant=4, max-coefficient=4, symbols=5, arity=3)` | 9 | 9 | 0 | 0 |
| `poly(max-constant=6, max-coefficient=6, symbols=7, arity=2)` | 9 | 9 | 0 | 0 |
| `poly(max-constant=7, max-coefficient=7, symbols=2, arity=2)` | 9 | 9 | 0 | 0 |
| `poly(max-constant=9, max-coefficient=9, symbols=5, arity=1)` | 9 | 9 | 0 | 0 |
| `kbo(weight=2, symbols=55)` | 8 | 7 | 1 | 0 |
| `kbo(weight=5, symbols=2)` | 8 | 8 | 0 | 0 |
| `matrix(max-constant=0, max-coefficient=1, symbols=15, arity=1, dim=1)` | 8 | 8 | 0 | 0 |
| `matrix(max-constant=1, max-coefficient=1, symbols=14, arity=2, dim=3)` | 8 | 8 | 0 | 0 |
| `matrix(max-constant=1, max-coefficient=1, symbols=17, arity=2, dim=3)` | 8 | 8 | 0 | 0 |
| `matrix(max-constant=1, max-coefficient=1, symbols=4, arity=2, dim=4)` | 8 | 8 | 0 | 0 |
| `matrix(max-constant=1, max-coefficient=1, symbols=6, arity=1, dim=1)` | 8 | 8 | 0 | 0 |
| `matrix(max-constant=1, max-coefficient=1, symbols=6, arity=1, dim=5)` | 8 | 8 | 0 | 0 |
| `matrix(max-constant=1, max-coefficient=1, symbols=9, arity=3, dim=5)` | 8 | 8 | 0 | 0 |
| `matrix(max-constant=13, max-coefficient=13, symbols=2, arity=1, dim=4)` | 8 | 8 | 0 | 0 |
| `matrix(max-constant=14, max-coefficient=14, symbols=3, arity=1, dim=3)` | 8 | 8 | 0 | 0 |
| `matrix(max-constant=16, max-coefficient=16, symbols=2, arity=1, dim=3)` | 8 | 8 | 0 | 0 |
| `matrix(max-constant=16, max-coefficient=16, symbols=3, arity=1, dim=3)` | 8 | 8 | 0 | 0 |
| `matrix(max-constant=17, max-coefficient=17, symbols=3, arity=1, dim=3)` | 8 | 8 | 0 | 0 |
| `matrix(max-constant=2, max-coefficient=2, symbols=33, arity=2, dim=1)` | 8 | 7 | 1 | 0 |
| `matrix(max-constant=2, max-coefficient=2, symbols=5, arity=2, dim=1)` | 8 | 8 | 0 | 0 |
| `matrix(max-constant=2, max-coefficient=2, symbols=6, arity=2, dim=3)` | 8 | 8 | 0 | 0 |
| `matrix(max-constant=2, max-coefficient=2, symbols=7, arity=2, dim=3)` | 8 | 8 | 0 | 0 |
| `matrix(max-constant=3, max-coefficient=3, symbols=10, arity=2, dim=1)` | 8 | 8 | 0 | 0 |
| `matrix(max-constant=3, max-coefficient=3, symbols=10, arity=3, dim=1)` | 8 | 8 | 0 | 0 |
| `matrix(max-constant=3, max-coefficient=3, symbols=12, arity=2, dim=2)` | 8 | 8 | 0 | 0 |
| `matrix(max-constant=3, max-coefficient=3, symbols=3, arity=3, dim=1)` | 8 | 8 | 0 | 0 |
| `matrix(max-constant=3, max-coefficient=3, symbols=4, arity=1, dim=1)` | 8 | 8 | 0 | 0 |
| `matrix(max-constant=4, max-coefficient=4, symbols=4, arity=1, dim=5)` | 8 | 8 | 0 | 0 |
| `matrix(max-constant=4, max-coefficient=4, symbols=8, arity=1, dim=2)` | 8 | 8 | 0 | 0 |
| `matrix(max-constant=4, max-coefficient=4, symbols=8, arity=1, dim=3)` | 8 | 8 | 0 | 0 |
| `matrix(max-constant=5, max-coefficient=5, symbols=10, arity=2, dim=4)` | 8 | 8 | 0 | 0 |
| `matrix(max-constant=5, max-coefficient=5, symbols=11, arity=2, dim=2)` | 8 | 7 | 1 | 0 |
| `matrix(max-constant=5, max-coefficient=5, symbols=17, arity=2, dim=3)` | 8 | 8 | 0 | 0 |
| `matrix(max-constant=5, max-coefficient=5, symbols=4, arity=2, dim=3)` | 8 | 8 | 0 | 0 |
| `matrix(max-constant=8, max-coefficient=8, symbols=5, arity=1, dim=2)` | 8 | 7 | 0 | 1 |
| `matrix(max-constant=8, max-coefficient=8, symbols=7, arity=1, dim=3)` | 8 | 8 | 0 | 0 |
| `poly(max-constant=0, max-coefficient=1, symbols=3, arity=2)` | 8 | 8 | 0 | 0 |
| `poly(max-constant=1, max-coefficient=1, symbols=15, arity=2)` | 8 | 8 | 0 | 0 |
| `poly(max-constant=1, max-coefficient=1, symbols=26, arity=4)` | 8 | 8 | 0 | 0 |
| `poly(max-constant=10, max-coefficient=10, symbols=9, arity=2)` | 8 | 7 | 1 | 0 |
| `poly(max-constant=11, max-coefficient=11, symbols=4, arity=1)` | 8 | 8 | 0 | 0 |
| `poly(max-constant=127, max-coefficient=127, symbols=4, arity=1)` | 8 | 8 | 0 | 0 |
| `poly(max-constant=132, max-coefficient=132, symbols=4, arity=1)` | 8 | 8 | 0 | 0 |
| `poly(max-constant=176, max-coefficient=176, symbols=6, arity=1)` | 8 | 8 | 0 | 0 |
| `poly(max-constant=2, max-coefficient=2, symbols=2, arity=3)` | 8 | 8 | 0 | 0 |
| `poly(max-constant=29, max-coefficient=29, symbols=4, arity=1)` | 8 | 8 | 0 | 0 |
| `poly(max-constant=3, max-coefficient=3, symbols=14, arity=3)` | 8 | 8 | 0 | 0 |
| `poly(max-constant=3, max-coefficient=3, symbols=21, arity=2)` | 8 | 8 | 0 | 0 |
| `poly(max-constant=3, max-coefficient=3, symbols=24, arity=2)` | 8 | 8 | 0 | 0 |
| `poly(max-constant=3, max-coefficient=3, symbols=3, arity=3)` | 8 | 8 | 0 | 0 |
| `poly(max-constant=3, max-coefficient=3, symbols=31, arity=3)` | 8 | 8 | 0 | 0 |
| `poly(max-constant=3, max-coefficient=3, symbols=33, arity=3)` | 8 | 8 | 0 | 0 |
| `poly(max-constant=3, max-coefficient=3, symbols=33, arity=4)` | 8 | 7 | 1 | 0 |
| `poly(max-constant=3, max-coefficient=3, symbols=39, arity=3)` | 8 | 7 | 0 | 1 |
| `poly(max-constant=3, max-coefficient=3, symbols=5, arity=3)` | 8 | 8 | 0 | 0 |
| `poly(max-constant=31, max-coefficient=31, symbols=4, arity=1)` | 8 | 7 | 0 | 1 |
| `poly(max-constant=4, max-coefficient=4, symbols=16, arity=2)` | 8 | 8 | 0 | 0 |
| `poly(max-constant=4, max-coefficient=4, symbols=20, arity=3)` | 8 | 7 | 1 | 0 |
| `poly(max-constant=48, max-coefficient=48, symbols=4, arity=1)` | 8 | 8 | 0 | 0 |
| `poly(max-constant=5, max-coefficient=5, symbols=11, arity=4)` | 8 | 8 | 0 | 0 |
| `poly(max-constant=5, max-coefficient=5, symbols=5, arity=5)` | 8 | 8 | 0 | 0 |
| `poly(max-constant=65, max-coefficient=65, symbols=4, arity=1)` | 8 | 8 | 0 | 0 |
| `poly(max-constant=80, max-coefficient=80, symbols=4, arity=1)` | 8 | 8 | 0 | 0 |
| `poly(max-constant=80, max-coefficient=80, symbols=5, arity=1)` | 8 | 8 | 0 | 0 |
| `poly(max-constant=9, max-coefficient=9, symbols=15, arity=1)` | 8 | 8 | 0 | 0 |
| `kbo(weight=1, symbols=10)` | 7 | 7 | 0 | 0 |
| `kbo(weight=1, symbols=5)` | 7 | 7 | 0 | 0 |
| `kbo(weight=2, symbols=8)` | 7 | 7 | 0 | 0 |
| `kbo(weight=3, symbols=19)` | 7 | 7 | 0 | 0 |
| `kbo(weight=4, symbols=4)` | 7 | 7 | 0 | 0 |
| `kbo(weight=5, symbols=10)` | 7 | 6 | 1 | 0 |
| `kbo(weight=7, symbols=3)` | 7 | 7 | 0 | 0 |
| `matrix(max-constant=1, max-coefficient=1, symbols=4, arity=2, dim=5)` | 7 | 7 | 0 | 0 |
| `matrix(max-constant=1, max-coefficient=1, symbols=5, arity=2, dim=4)` | 7 | 7 | 0 | 0 |
| `matrix(max-constant=13, max-coefficient=13, symbols=5, arity=1, dim=3)` | 7 | 7 | 0 | 0 |
| `matrix(max-constant=14, max-coefficient=14, symbols=2, arity=1, dim=3)` | 7 | 7 | 0 | 0 |
| `matrix(max-constant=15, max-coefficient=15, symbols=2, arity=1, dim=3)` | 7 | 7 | 0 | 0 |
| `matrix(max-constant=15, max-coefficient=15, symbols=2, arity=1, dim=5)` | 7 | 7 | 0 | 0 |
| `matrix(max-constant=16, max-coefficient=16, symbols=3, arity=1, dim=5)` | 7 | 7 | 0 | 0 |
| `matrix(max-constant=2, max-coefficient=2, symbols=11, arity=2, dim=2)` | 7 | 7 | 0 | 0 |
| `matrix(max-constant=2, max-coefficient=2, symbols=17, arity=4, dim=1)` | 7 | 7 | 0 | 0 |
| `matrix(max-constant=2, max-coefficient=2, symbols=4, arity=1, dim=5)` | 7 | 7 | 0 | 0 |
| `matrix(max-constant=2, max-coefficient=2, symbols=41, arity=3, dim=1)` | 7 | 5 | 2 | 0 |
| `matrix(max-constant=20, max-coefficient=20, symbols=2, arity=1, dim=5)` | 7 | 7 | 0 | 0 |
| `matrix(max-constant=4, max-coefficient=4, symbols=14, arity=2, dim=1)` | 7 | 7 | 0 | 0 |
| `matrix(max-constant=4, max-coefficient=4, symbols=3, arity=1, dim=1)` | 7 | 7 | 0 | 0 |
| `matrix(max-constant=4, max-coefficient=4, symbols=5, arity=2, dim=3)` | 7 | 7 | 0 | 0 |
| `matrix(max-constant=4, max-coefficient=4, symbols=7, arity=2, dim=3)` | 7 | 7 | 0 | 0 |
| `matrix(max-constant=4, max-coefficient=4, symbols=9, arity=2, dim=3)` | 7 | 7 | 0 | 0 |
| `matrix(max-constant=5, max-coefficient=5, symbols=16, arity=3, dim=2)` | 7 | 7 | 0 | 0 |
| `matrix(max-constant=5, max-coefficient=5, symbols=7, arity=2, dim=2)` | 7 | 6 | 1 | 0 |
| `matrix(max-constant=8, max-coefficient=8, symbols=2, arity=1, dim=7)` | 7 | 7 | 0 | 0 |
| `matrix(max-constant=8, max-coefficient=8, symbols=8, arity=1, dim=2)` | 7 | 7 | 0 | 0 |
| `poly(max-constant=0, max-coefficient=1, symbols=6, arity=2)` | 7 | 6 | 1 | 0 |
| `poly(max-constant=0, max-coefficient=1, symbols=8, arity=2)` | 7 | 7 | 0 | 0 |
| `poly(max-constant=1, max-coefficient=1, symbols=10, arity=4)` | 7 | 7 | 0 | 0 |
| `poly(max-constant=1, max-coefficient=1, symbols=11, arity=4)` | 7 | 7 | 0 | 0 |
| `poly(max-constant=1, max-coefficient=1, symbols=17, arity=3)` | 7 | 7 | 0 | 0 |
| `poly(max-constant=1, max-coefficient=1, symbols=20, arity=3)` | 7 | 7 | 0 | 0 |
| `poly(max-constant=10, max-coefficient=10, symbols=11, arity=3)` | 7 | 6 | 0 | 1 |
| `poly(max-constant=2, max-coefficient=2, symbols=21, arity=2)` | 7 | 6 | 0 | 1 |
| `poly(max-constant=2, max-coefficient=2, symbols=29, arity=2)` | 7 | 7 | 0 | 0 |
| `poly(max-constant=2, max-coefficient=2, symbols=40, arity=3)` | 7 | 7 | 0 | 0 |
| `poly(max-constant=3, max-coefficient=3, symbols=1, arity=2)` | 7 | 7 | 0 | 0 |
| `poly(max-constant=3, max-coefficient=3, symbols=43, arity=3)` | 7 | 7 | 0 | 0 |
| `poly(max-constant=39, max-coefficient=39, symbols=5, arity=1)` | 7 | 7 | 0 | 0 |
| `poly(max-constant=4, max-coefficient=4, symbols=10, arity=1)` | 7 | 7 | 0 | 0 |
| `poly(max-constant=4, max-coefficient=4, symbols=10, arity=4)` | 7 | 7 | 0 | 0 |
| `poly(max-constant=4, max-coefficient=4, symbols=14, arity=3)` | 7 | 7 | 0 | 0 |
| `poly(max-constant=6, max-coefficient=6, symbols=11, arity=2)` | 7 | 6 | 0 | 1 |
| `poly(max-constant=6, max-coefficient=6, symbols=4, arity=3)` | 7 | 7 | 0 | 0 |
| `poly(max-constant=7, max-coefficient=7, symbols=8, arity=1)` | 7 | 7 | 0 | 0 |
| `poly(max-constant=7, max-coefficient=7, symbols=9, arity=2)` | 7 | 6 | 0 | 1 |
| `poly(max-constant=8, max-coefficient=8, symbols=2, arity=2)` | 7 | 7 | 0 | 0 |
| `kbo(weight=2, symbols=11)` | 6 | 6 | 0 | 0 |
| `kbo(weight=3, symbols=43)` | 6 | 6 | 0 | 0 |
| `kbo(weight=4, symbols=28)` | 6 | 6 | 0 | 0 |
| `kbo(weight=4, symbols=34)` | 6 | 6 | 0 | 0 |
| `kbo(weight=4, symbols=8)` | 6 | 6 | 0 | 0 |
| `kbo(weight=5, symbols=25)` | 6 | 6 | 0 | 0 |
| `kbo(weight=6, symbols=6)` | 6 | 6 | 0 | 0 |
| `kbo(weight=7, symbols=4)` | 6 | 6 | 0 | 0 |
| `matrix(max-constant=1, max-coefficient=1, symbols=10, arity=1, dim=2)` | 6 | 6 | 0 | 0 |
| `matrix(max-constant=1, max-coefficient=1, symbols=10, arity=3, dim=3)` | 6 | 6 | 0 | 0 |
| `matrix(max-constant=1, max-coefficient=1, symbols=12, arity=2, dim=1)` | 6 | 5 | 1 | 0 |
| `matrix(max-constant=1, max-coefficient=1, symbols=12, arity=3, dim=3)` | 6 | 6 | 0 | 0 |
| `matrix(max-constant=1, max-coefficient=1, symbols=2, arity=1, dim=1)` | 6 | 6 | 0 | 0 |
| `matrix(max-constant=1, max-coefficient=1, symbols=2, arity=2, dim=4)` | 6 | 6 | 0 | 0 |
| `matrix(max-constant=1, max-coefficient=1, symbols=5, arity=1, dim=1)` | 6 | 6 | 0 | 0 |
| `matrix(max-constant=1, max-coefficient=1, symbols=5, arity=1, dim=5)` | 6 | 6 | 0 | 0 |
| `matrix(max-constant=1, max-coefficient=1, symbols=7, arity=2, dim=5)` | 6 | 6 | 0 | 0 |
| `matrix(max-constant=1, max-coefficient=1, symbols=8, arity=3, dim=2)` | 6 | 6 | 0 | 0 |
| `matrix(max-constant=10, max-coefficient=10, symbols=2, arity=1, dim=5)` | 6 | 6 | 0 | 0 |
| `matrix(max-constant=10, max-coefficient=10, symbols=3, arity=1, dim=2)` | 6 | 6 | 0 | 0 |
| `matrix(max-constant=12, max-coefficient=12, symbols=2, arity=1, dim=3)` | 6 | 6 | 0 | 0 |
| `matrix(max-constant=2, max-coefficient=2, symbols=14, arity=2, dim=1)` | 6 | 6 | 0 | 0 |
| `matrix(max-constant=2, max-coefficient=2, symbols=14, arity=6, dim=2)` | 6 | 6 | 0 | 0 |
| `matrix(max-constant=2, max-coefficient=2, symbols=19, arity=3, dim=1)` | 6 | 6 | 0 | 0 |
| `matrix(max-constant=2, max-coefficient=2, symbols=8, arity=3, dim=2)` | 6 | 6 | 0 | 0 |
| `matrix(max-constant=2, max-coefficient=2, symbols=9, arity=1, dim=3)` | 6 | 6 | 0 | 0 |
| `matrix(max-constant=3, max-coefficient=3, symbols=3, arity=1, dim=4)` | 6 | 6 | 0 | 0 |
| `matrix(max-constant=3, max-coefficient=3, symbols=33, arity=2, dim=2)` | 6 | 6 | 0 | 0 |
| `matrix(max-constant=3, max-coefficient=3, symbols=4, arity=1, dim=4)` | 6 | 6 | 0 | 0 |
| `matrix(max-constant=3, max-coefficient=3, symbols=5, arity=2, dim=1)` | 6 | 6 | 0 | 0 |
| `matrix(max-constant=31, max-coefficient=31, symbols=2, arity=1, dim=5)` | 6 | 6 | 0 | 0 |
| `matrix(max-constant=36, max-coefficient=36, symbols=2, arity=1, dim=5)` | 6 | 6 | 0 | 0 |
| `matrix(max-constant=4, max-coefficient=4, symbols=10, arity=2, dim=3)` | 6 | 5 | 1 | 0 |
| `matrix(max-constant=4, max-coefficient=4, symbols=16, arity=2, dim=1)` | 6 | 6 | 0 | 0 |
| `matrix(max-constant=4, max-coefficient=4, symbols=6, arity=2, dim=2)` | 6 | 6 | 0 | 0 |
| `matrix(max-constant=41, max-coefficient=41, symbols=2, arity=1, dim=5)` | 6 | 6 | 0 | 0 |
| `matrix(max-constant=5, max-coefficient=5, symbols=10, arity=1, dim=3)` | 6 | 6 | 0 | 0 |
| `matrix(max-constant=5, max-coefficient=5, symbols=3, arity=1, dim=4)` | 6 | 6 | 0 | 0 |
| `matrix(max-constant=5, max-coefficient=5, symbols=6, arity=1, dim=3)` | 6 | 6 | 0 | 0 |
| `matrix(max-constant=5, max-coefficient=5, symbols=6, arity=2, dim=3)` | 6 | 6 | 0 | 0 |
| `matrix(max-constant=5, max-coefficient=5, symbols=8, arity=2, dim=3)` | 6 | 6 | 0 | 0 |
| `matrix(max-constant=56, max-coefficient=56, symbols=3, arity=1, dim=5)` | 6 | 6 | 0 | 0 |
| `matrix(max-constant=6, max-coefficient=6, symbols=6, arity=1, dim=3)` | 6 | 6 | 0 | 0 |
| `matrix(max-constant=7, max-coefficient=7, symbols=7, arity=1, dim=2)` | 6 | 5 | 1 | 0 |
| `matrix(max-constant=8, max-coefficient=8, symbols=2, arity=1, dim=3)` | 6 | 6 | 0 | 0 |
| `matrix(max-constant=8, max-coefficient=8, symbols=2, arity=1, dim=5)` | 6 | 6 | 0 | 0 |
| `matrix(max-constant=8, max-coefficient=8, symbols=7, arity=1, dim=1)` | 6 | 5 | 0 | 1 |
| `poly(max-constant=0, max-coefficient=1, symbols=9, arity=2)` | 6 | 6 | 0 | 0 |
| `poly(max-constant=1, max-coefficient=1, symbols=1, arity=1)` | 6 | 6 | 0 | 0 |
| `poly(max-constant=1, max-coefficient=1, symbols=36, arity=3)` | 6 | 6 | 0 | 0 |
| `poly(max-constant=1, max-coefficient=1, symbols=44, arity=3)` | 6 | 6 | 0 | 0 |
| `poly(max-constant=1, max-coefficient=1, symbols=58, arity=3)` | 6 | 6 | 0 | 0 |
| `poly(max-constant=10, max-coefficient=10, symbols=10, arity=2)` | 6 | 6 | 0 | 0 |
| `poly(max-constant=10, max-coefficient=10, symbols=12, arity=2)` | 6 | 6 | 0 | 0 |
| `poly(max-constant=10, max-coefficient=10, symbols=16, arity=2)` | 6 | 6 | 0 | 0 |
| `poly(max-constant=10, max-coefficient=10, symbols=20, arity=2)` | 6 | 6 | 0 | 0 |
| `poly(max-constant=10, max-coefficient=10, symbols=24, arity=3)` | 6 | 6 | 0 | 0 |
| `poly(max-constant=10, max-coefficient=10, symbols=7, arity=2)` | 6 | 6 | 0 | 0 |
| `poly(max-constant=151, max-coefficient=151, symbols=6, arity=1)` | 6 | 6 | 0 | 0 |
| `poly(max-constant=188, max-coefficient=188, symbols=4, arity=1)` | 6 | 6 | 0 | 0 |
| `poly(max-constant=2, max-coefficient=2, symbols=11, arity=5)` | 6 | 5 | 0 | 1 |
| `poly(max-constant=2, max-coefficient=2, symbols=14, arity=4)` | 6 | 6 | 0 | 0 |
| `poly(max-constant=2, max-coefficient=2, symbols=23, arity=2)` | 6 | 6 | 0 | 0 |
| `poly(max-constant=2, max-coefficient=2, symbols=26, arity=2)` | 6 | 6 | 0 | 0 |
| `poly(max-constant=2, max-coefficient=2, symbols=36, arity=3)` | 6 | 6 | 0 | 0 |
| `poly(max-constant=2, max-coefficient=2, symbols=38, arity=3)` | 6 | 6 | 0 | 0 |
| `poly(max-constant=2, max-coefficient=2, symbols=51, arity=3)` | 6 | 6 | 0 | 0 |
| `poly(max-constant=2, max-coefficient=2, symbols=52, arity=3)` | 6 | 6 | 0 | 0 |
| `poly(max-constant=2, max-coefficient=2, symbols=7, arity=4)` | 6 | 6 | 0 | 0 |
| `poly(max-constant=2, max-coefficient=2, symbols=8, arity=4)` | 6 | 6 | 0 | 0 |
| `poly(max-constant=2, max-coefficient=2, symbols=9, arity=4)` | 6 | 5 | 1 | 0 |
| `poly(max-constant=21, max-coefficient=21, symbols=6, arity=1)` | 6 | 5 | 0 | 1 |
| `poly(max-constant=24, max-coefficient=24, symbols=6, arity=1)` | 6 | 6 | 0 | 0 |
| `poly(max-constant=26, max-coefficient=26, symbols=3, arity=1)` | 6 | 6 | 0 | 0 |
| `poly(max-constant=3, max-coefficient=3, symbols=10, arity=4)` | 6 | 6 | 0 | 0 |
| `poly(max-constant=3, max-coefficient=3, symbols=2, arity=3)` | 6 | 4 | 1 | 1 |
| `poly(max-constant=3, max-coefficient=3, symbols=32, arity=3)` | 6 | 5 | 1 | 0 |
| `poly(max-constant=3, max-coefficient=3, symbols=36, arity=3)` | 6 | 6 | 0 | 0 |
| `poly(max-constant=3, max-coefficient=3, symbols=9, arity=4)` | 6 | 6 | 0 | 0 |
| `poly(max-constant=32, max-coefficient=32, symbols=6, arity=1)` | 6 | 6 | 0 | 0 |
| `poly(max-constant=33, max-coefficient=33, symbols=3, arity=1)` | 6 | 6 | 0 | 0 |
| `poly(max-constant=4, max-coefficient=4, symbols=17, arity=2)` | 6 | 6 | 0 | 0 |
| `poly(max-constant=5, max-coefficient=5, symbols=2, arity=3)` | 6 | 6 | 0 | 0 |
| `poly(max-constant=51, max-coefficient=51, symbols=4, arity=1)` | 6 | 6 | 0 | 0 |
| `poly(max-constant=53, max-coefficient=53, symbols=4, arity=1)` | 6 | 6 | 0 | 0 |
| `poly(max-constant=58, max-coefficient=58, symbols=4, arity=1)` | 6 | 5 | 1 | 0 |
| `poly(max-constant=6, max-coefficient=6, symbols=12, arity=2)` | 6 | 6 | 0 | 0 |
| `poly(max-constant=6, max-coefficient=6, symbols=8, arity=2)` | 6 | 6 | 0 | 0 |
| `poly(max-constant=69, max-coefficient=69, symbols=6, arity=1)` | 6 | 6 | 0 | 0 |
| `poly(max-constant=7, max-coefficient=7, symbols=4, arity=3)` | 6 | 6 | 0 | 0 |
| `poly(max-constant=77, max-coefficient=77, symbols=6, arity=1)` | 6 | 6 | 0 | 0 |
| `poly(max-constant=8, max-coefficient=8, symbols=5, arity=3)` | 6 | 6 | 0 | 0 |
| `kbo(weight=0, symbols=14)` | 5 | 4 | 0 | 1 |
| `kbo(weight=10, symbols=6)` | 5 | 5 | 0 | 0 |
| `kbo(weight=3, symbols=4)` | 5 | 5 | 0 | 0 |
| `kbo(weight=3, symbols=6)` | 5 | 5 | 0 | 0 |
| `kbo(weight=5, symbols=19)` | 5 | 5 | 0 | 0 |
| `kbo(weight=5, symbols=5)` | 5 | 5 | 0 | 0 |
| `kbo(weight=51, symbols=6)` | 5 | 5 | 0 | 0 |
| `matrix(max-constant=1, max-coefficient=1, symbols=13, arity=2, dim=3)` | 5 | 5 | 0 | 0 |
| `matrix(max-constant=1, max-coefficient=1, symbols=13, arity=3, dim=3)` | 5 | 5 | 0 | 0 |
| `matrix(max-constant=1, max-coefficient=1, symbols=16, arity=2, dim=2)` | 5 | 5 | 0 | 0 |
| `matrix(max-constant=1, max-coefficient=1, symbols=20, arity=3, dim=1)` | 5 | 4 | 1 | 0 |
| `matrix(max-constant=1, max-coefficient=1, symbols=3, arity=3, dim=1)` | 5 | 5 | 0 | 0 |
| `matrix(max-constant=1, max-coefficient=1, symbols=4, arity=3, dim=1)` | 5 | 5 | 0 | 0 |
| `matrix(max-constant=1, max-coefficient=1, symbols=5, arity=2, dim=5)` | 5 | 5 | 0 | 0 |
| `matrix(max-constant=1, max-coefficient=1, symbols=8, arity=1, dim=1)` | 5 | 5 | 0 | 0 |
| `matrix(max-constant=1, max-coefficient=1, symbols=9, arity=1, dim=3)` | 5 | 5 | 0 | 0 |
| `matrix(max-constant=1, max-coefficient=1, symbols=9, arity=3, dim=1)` | 5 | 5 | 0 | 0 |
| `matrix(max-constant=13, max-coefficient=13, symbols=2, arity=1, dim=5)` | 5 | 5 | 0 | 0 |
| `matrix(max-constant=15, max-coefficient=15, symbols=3, arity=1, dim=5)` | 5 | 5 | 0 | 0 |
| `matrix(max-constant=17, max-coefficient=17, symbols=2, arity=1, dim=4)` | 5 | 5 | 0 | 0 |
| `matrix(max-constant=19, max-coefficient=19, symbols=3, arity=1, dim=3)` | 5 | 5 | 0 | 0 |
| `matrix(max-constant=2, max-coefficient=2, symbols=10, arity=4, dim=2)` | 5 | 5 | 0 | 0 |
| `matrix(max-constant=2, max-coefficient=2, symbols=12, arity=2, dim=1)` | 5 | 5 | 0 | 0 |
| `matrix(max-constant=2, max-coefficient=2, symbols=15, arity=3, dim=1)` | 5 | 5 | 0 | 0 |
| `matrix(max-constant=2, max-coefficient=2, symbols=3, arity=2, dim=4)` | 5 | 5 | 0 | 0 |
| `matrix(max-constant=2, max-coefficient=2, symbols=8, arity=2, dim=3)` | 5 | 5 | 0 | 0 |
| `matrix(max-constant=2, max-coefficient=2, symbols=9, arity=1, dim=1)` | 5 | 4 | 0 | 1 |
| `matrix(max-constant=22, max-coefficient=22, symbols=3, arity=1, dim=3)` | 5 | 4 | 1 | 0 |
| `matrix(max-constant=24, max-coefficient=24, symbols=3, arity=1, dim=3)` | 5 | 5 | 0 | 0 |
| `matrix(max-constant=26, max-coefficient=26, symbols=2, arity=1, dim=5)` | 5 | 5 | 0 | 0 |
| `matrix(max-constant=3, max-coefficient=3, symbols=10, arity=1, dim=1)` | 5 | 5 | 0 | 0 |
| `matrix(max-constant=3, max-coefficient=3, symbols=11, arity=2, dim=2)` | 5 | 5 | 0 | 0 |
| `matrix(max-constant=3, max-coefficient=3, symbols=16, arity=3, dim=2)` | 5 | 5 | 0 | 0 |
| `matrix(max-constant=3, max-coefficient=3, symbols=7, arity=1, dim=3)` | 5 | 5 | 0 | 0 |
| `matrix(max-constant=3, max-coefficient=3, symbols=8, arity=1, dim=3)` | 5 | 5 | 0 | 0 |
| `matrix(max-constant=3, max-coefficient=3, symbols=8, arity=3, dim=2)` | 5 | 5 | 0 | 0 |
| `matrix(max-constant=31, max-coefficient=31, symbols=3, arity=1, dim=5)` | 5 | 5 | 0 | 0 |
| `matrix(max-constant=4, max-coefficient=4, symbols=4, arity=3, dim=3)` | 5 | 5 | 0 | 0 |
| `matrix(max-constant=5, max-coefficient=5, symbols=11, arity=3, dim=1)` | 5 | 5 | 0 | 0 |
| `matrix(max-constant=5, max-coefficient=5, symbols=12, arity=3, dim=2)` | 5 | 5 | 0 | 0 |
| `matrix(max-constant=5, max-coefficient=5, symbols=14, arity=2, dim=3)` | 5 | 5 | 0 | 0 |
| `matrix(max-constant=5, max-coefficient=5, symbols=16, arity=2, dim=3)` | 5 | 5 | 0 | 0 |
| `matrix(max-constant=5, max-coefficient=5, symbols=4, arity=2, dim=2)` | 5 | 5 | 0 | 0 |
| `matrix(max-constant=5, max-coefficient=5, symbols=6, arity=2, dim=4)` | 5 | 5 | 0 | 0 |
| `matrix(max-constant=5, max-coefficient=5, symbols=7, arity=3, dim=1)` | 5 | 5 | 0 | 0 |
| `matrix(max-constant=5, max-coefficient=5, symbols=9, arity=2, dim=1)` | 5 | 5 | 0 | 0 |
| `matrix(max-constant=6, max-coefficient=6, symbols=2, arity=1, dim=6)` | 5 | 5 | 0 | 0 |
| `matrix(max-constant=61, max-coefficient=61, symbols=2, arity=1, dim=5)` | 5 | 5 | 0 | 0 |
| `matrix(max-constant=7, max-coefficient=7, symbols=4, arity=1, dim=2)` | 5 | 5 | 0 | 0 |
| `matrix(max-constant=8, max-coefficient=8, symbols=2, arity=1, dim=1)` | 5 | 5 | 0 | 0 |
| `matrix(max-constant=9, max-coefficient=9, symbols=4, arity=1, dim=3)` | 5 | 5 | 0 | 0 |
| `poly(max-constant=0, max-coefficient=1, symbols=7, arity=4)` | 5 | 5 | 0 | 0 |
| `poly(max-constant=1, max-coefficient=1, symbols=14, arity=3)` | 5 | 5 | 0 | 0 |
| `poly(max-constant=1, max-coefficient=1, symbols=20, arity=2)` | 5 | 5 | 0 | 0 |
| `poly(max-constant=1, max-coefficient=1, symbols=22, arity=3)` | 5 | 5 | 0 | 0 |
| `poly(max-constant=1, max-coefficient=1, symbols=25, arity=2)` | 5 | 5 | 0 | 0 |
| `poly(max-constant=1, max-coefficient=1, symbols=3, arity=4)` | 5 | 5 | 0 | 0 |
| `poly(max-constant=10, max-coefficient=10, symbols=14, arity=2)` | 5 | 5 | 0 | 0 |
| `poly(max-constant=10, max-coefficient=10, symbols=19, arity=3)` | 5 | 5 | 0 | 0 |
| `poly(max-constant=10, max-coefficient=10, symbols=29, arity=3)` | 5 | 5 | 0 | 0 |
| `poly(max-constant=10, max-coefficient=10, symbols=7, arity=1)` | 5 | 4 | 1 | 0 |
| `poly(max-constant=11, max-coefficient=11, symbols=3, arity=1)` | 5 | 5 | 0 | 0 |
| `poly(max-constant=16, max-coefficient=16, symbols=2, arity=2)` | 5 | 5 | 0 | 0 |
| `poly(max-constant=2, max-coefficient=2, symbols=27, arity=3)` | 5 | 5 | 0 | 0 |
| `poly(max-constant=2, max-coefficient=2, symbols=28, arity=2)` | 5 | 5 | 0 | 0 |
| `poly(max-constant=2, max-coefficient=2, symbols=30, arity=5)` | 5 | 5 | 0 | 0 |
| `poly(max-constant=2, max-coefficient=2, symbols=35, arity=2)` | 5 | 5 | 0 | 0 |
| `poly(max-constant=2, max-coefficient=2, symbols=37, arity=2)` | 5 | 5 | 0 | 0 |
| `poly(max-constant=2, max-coefficient=2, symbols=39, arity=2)` | 5 | 5 | 0 | 0 |
| `poly(max-constant=2, max-coefficient=2, symbols=54, arity=3)` | 5 | 5 | 0 | 0 |
| `poly(max-constant=21, max-coefficient=21, symbols=3, arity=1)` | 5 | 5 | 0 | 0 |
| `poly(max-constant=3, max-coefficient=3, symbols=19, arity=4)` | 5 | 5 | 0 | 0 |
| `poly(max-constant=3, max-coefficient=3, symbols=46, arity=3)` | 5 | 5 | 0 | 0 |
| `poly(max-constant=34, max-coefficient=34, symbols=6, arity=1)` | 5 | 5 | 0 | 0 |
| `poly(max-constant=4, max-coefficient=4, symbols=13, arity=2)` | 5 | 5 | 0 | 0 |
| `poly(max-constant=4, max-coefficient=4, symbols=7, arity=3)` | 5 | 5 | 0 | 0 |
| `poly(max-constant=5, max-coefficient=5, symbols=22, arity=2)` | 5 | 5 | 0 | 0 |
| `poly(max-constant=6, max-coefficient=6, symbols=3, arity=3)` | 5 | 5 | 0 | 0 |
| `poly(max-constant=6, max-coefficient=6, symbols=7, arity=1)` | 5 | 5 | 0 | 0 |
| `poly(max-constant=6, max-coefficient=6, symbols=9, arity=3)` | 5 | 5 | 0 | 0 |
| `poly(max-constant=7, max-coefficient=7, symbols=11, arity=3)` | 5 | 5 | 0 | 0 |
| `poly(max-constant=7, max-coefficient=7, symbols=16, arity=2)` | 5 | 5 | 0 | 0 |
| `poly(max-constant=7, max-coefficient=7, symbols=3, arity=2)` | 5 | 5 | 0 | 0 |
| `poly(max-constant=7, max-coefficient=7, symbols=4, arity=2)` | 5 | 5 | 0 | 0 |
| `poly(max-constant=7, max-coefficient=7, symbols=5, arity=1)` | 5 | 5 | 0 | 0 |
| `poly(max-constant=7, max-coefficient=7, symbols=5, arity=2)` | 5 | 5 | 0 | 0 |
| `poly(max-constant=7, max-coefficient=7, symbols=7, arity=2)` | 5 | 5 | 0 | 0 |
| `poly(max-constant=8, max-coefficient=8, symbols=5, arity=2)` | 5 | 5 | 0 | 0 |
| `kbo(weight=0, symbols=2)` | 4 | 4 | 0 | 0 |
| `kbo(weight=0, symbols=3)` | 4 | 4 | 0 | 0 |
| `kbo(weight=1, symbols=9)` | 4 | 4 | 0 | 0 |
| `kbo(weight=10, symbols=3)` | 4 | 4 | 0 | 0 |
| `kbo(weight=16, symbols=3)` | 4 | 4 | 0 | 0 |
| `kbo(weight=18, symbols=6)` | 4 | 4 | 0 | 0 |
| `kbo(weight=2, symbols=10)` | 4 | 4 | 0 | 0 |
| `kbo(weight=2, symbols=5)` | 4 | 4 | 0 | 0 |
| `kbo(weight=21, symbols=3)` | 4 | 4 | 0 | 0 |
| `kbo(weight=3, symbols=2)` | 4 | 4 | 0 | 0 |
| `kbo(weight=3, symbols=7)` | 4 | 4 | 0 | 0 |
| `kbo(weight=5, symbols=12)` | 4 | 4 | 0 | 0 |
| `kbo(weight=5, symbols=20)` | 4 | 4 | 0 | 0 |
| `kbo(weight=5, symbols=24)` | 4 | 4 | 0 | 0 |
| `kbo(weight=6, symbols=10)` | 4 | 4 | 0 | 0 |
| `kbo(weight=6, symbols=7)` | 4 | 4 | 0 | 0 |
| `kbo(weight=8, symbols=14)` | 4 | 3 | 1 | 0 |
| `match-bounds(max-bound=4)` | 4 | 4 | 0 | 0 |
| `matrix(max-constant=1, max-coefficient=1, symbols=10, arity=1, dim=4)` | 4 | 4 | 0 | 0 |
| `matrix(max-constant=1, max-coefficient=1, symbols=10, arity=3, dim=2)` | 4 | 4 | 0 | 0 |
| `matrix(max-constant=1, max-coefficient=1, symbols=11, arity=3, dim=1)` | 4 | 4 | 0 | 0 |
| `matrix(max-constant=1, max-coefficient=1, symbols=13, arity=3, dim=1)` | 4 | 4 | 0 | 0 |
| `matrix(max-constant=1, max-coefficient=1, symbols=19, arity=3, dim=1)` | 4 | 4 | 0 | 0 |
| `matrix(max-constant=1, max-coefficient=1, symbols=2, arity=3, dim=1)` | 4 | 4 | 0 | 0 |
| `matrix(max-constant=1, max-coefficient=1, symbols=26, arity=4, dim=2)` | 4 | 4 | 0 | 0 |
| `matrix(max-constant=1, max-coefficient=1, symbols=3, arity=3, dim=4)` | 4 | 4 | 0 | 0 |
| `matrix(max-constant=1, max-coefficient=1, symbols=4, arity=3, dim=5)` | 4 | 4 | 0 | 0 |
| `matrix(max-constant=1, max-coefficient=1, symbols=6, arity=2, dim=4)` | 4 | 4 | 0 | 0 |
| `matrix(max-constant=1, max-coefficient=1, symbols=6, arity=2, dim=5)` | 4 | 4 | 0 | 0 |
| `matrix(max-constant=1, max-coefficient=1, symbols=6, arity=3, dim=1)` | 4 | 4 | 0 | 0 |
| `matrix(max-constant=1, max-coefficient=1, symbols=7, arity=1, dim=5)` | 4 | 4 | 0 | 0 |
| `matrix(max-constant=1, max-coefficient=1, symbols=9, arity=3, dim=3)` | 4 | 4 | 0 | 0 |
| `matrix(max-constant=10, max-coefficient=10, symbols=6, arity=1, dim=2)` | 4 | 4 | 0 | 0 |
| `matrix(max-constant=10, max-coefficient=10, symbols=6, arity=1, dim=3)` | 4 | 3 | 1 | 0 |
| `matrix(max-constant=13, max-coefficient=13, symbols=6, arity=1, dim=3)` | 4 | 4 | 0 | 0 |
| `matrix(max-constant=15, max-coefficient=15, symbols=6, arity=1, dim=3)` | 4 | 4 | 0 | 0 |
| `matrix(max-constant=19, max-coefficient=19, symbols=2, arity=1, dim=5)` | 4 | 4 | 0 | 0 |
| `matrix(max-constant=2, max-coefficient=2, symbols=13, arity=3, dim=1)` | 4 | 4 | 0 | 0 |
| `matrix(max-constant=2, max-coefficient=2, symbols=15, arity=9, dim=2)` | 4 | 4 | 0 | 0 |
| `matrix(max-constant=2, max-coefficient=2, symbols=17, arity=2, dim=2)` | 4 | 4 | 0 | 0 |
| `matrix(max-constant=2, max-coefficient=2, symbols=2, arity=3, dim=1)` | 4 | 3 | 0 | 1 |
| `matrix(max-constant=2, max-coefficient=2, symbols=20, arity=3, dim=1)` | 4 | 4 | 0 | 0 |
| `matrix(max-constant=2, max-coefficient=2, symbols=25, arity=2, dim=1)` | 4 | 4 | 0 | 0 |
| `matrix(max-constant=2, max-coefficient=2, symbols=4, arity=3, dim=3)` | 4 | 4 | 0 | 0 |
| `matrix(max-constant=2, max-coefficient=2, symbols=6, arity=1, dim=1)` | 4 | 4 | 0 | 0 |
| `matrix(max-constant=2, max-coefficient=2, symbols=6, arity=2, dim=4)` | 4 | 3 | 0 | 1 |
| `matrix(max-constant=20, max-coefficient=20, symbols=3, arity=1, dim=3)` | 4 | 4 | 0 | 0 |
| `matrix(max-constant=20, max-coefficient=20, symbols=3, arity=1, dim=5)` | 4 | 4 | 0 | 0 |
| `matrix(max-constant=3, max-coefficient=3, symbols=3, arity=3, dim=2)` | 4 | 4 | 0 | 0 |
| `matrix(max-constant=3, max-coefficient=3, symbols=5, arity=1, dim=6)` | 4 | 4 | 0 | 0 |
| `matrix(max-constant=3, max-coefficient=3, symbols=7, arity=2, dim=3)` | 4 | 4 | 0 | 0 |
| `matrix(max-constant=3, max-coefficient=3, symbols=8, arity=3, dim=3)` | 4 | 4 | 0 | 0 |
| `matrix(max-constant=3, max-coefficient=3, symbols=9, arity=2, dim=3)` | 4 | 4 | 0 | 0 |
| `matrix(max-constant=39, max-coefficient=39, symbols=2, arity=1, dim=5)` | 4 | 4 | 0 | 0 |
| `matrix(max-constant=4, max-coefficient=4, symbols=16, arity=3, dim=1)` | 4 | 4 | 0 | 0 |
| `matrix(max-constant=4, max-coefficient=4, symbols=3, arity=2, dim=1)` | 4 | 4 | 0 | 0 |
| `matrix(max-constant=4, max-coefficient=4, symbols=3, arity=2, dim=2)` | 4 | 4 | 0 | 0 |
| `matrix(max-constant=4, max-coefficient=4, symbols=4, arity=3, dim=1)` | 4 | 4 | 0 | 0 |
| `matrix(max-constant=4, max-coefficient=4, symbols=5, arity=1, dim=4)` | 4 | 3 | 1 | 0 |
| `matrix(max-constant=4, max-coefficient=4, symbols=5, arity=3, dim=3)` | 4 | 4 | 0 | 0 |
| `matrix(max-constant=40, max-coefficient=40, symbols=3, arity=1, dim=5)` | 4 | 4 | 0 | 0 |
| `matrix(max-constant=42, max-coefficient=42, symbols=3, arity=1, dim=5)` | 4 | 4 | 0 | 0 |
| `matrix(max-constant=5, max-coefficient=5, symbols=3, arity=2, dim=1)` | 4 | 4 | 0 | 0 |
| `matrix(max-constant=5, max-coefficient=5, symbols=4, arity=1, dim=2)` | 4 | 4 | 0 | 0 |
| `matrix(max-constant=5, max-coefficient=5, symbols=41, arity=3, dim=1)` | 4 | 4 | 0 | 0 |
| `matrix(max-constant=5, max-coefficient=5, symbols=5, arity=2, dim=2)` | 4 | 3 | 1 | 0 |
| `matrix(max-constant=5, max-coefficient=5, symbols=7, arity=3, dim=3)` | 4 | 4 | 0 | 0 |
| `matrix(max-constant=5, max-coefficient=5, symbols=8, arity=3, dim=2)` | 4 | 4 | 0 | 0 |
| `matrix(max-constant=5, max-coefficient=5, symbols=8, arity=3, dim=3)` | 4 | 4 | 0 | 0 |
| `matrix(max-constant=5, max-coefficient=5, symbols=8, arity=4, dim=1)` | 4 | 3 | 0 | 1 |
| `matrix(max-constant=5, max-coefficient=5, symbols=9, arity=3, dim=3)` | 4 | 4 | 0 | 0 |
| `matrix(max-constant=6, max-coefficient=6, symbols=4, arity=1, dim=3)` | 4 | 4 | 0 | 0 |
| `matrix(max-constant=8, max-coefficient=8, symbols=3, arity=1, dim=5)` | 4 | 4 | 0 | 0 |
| `matrix(max-constant=8, max-coefficient=8, symbols=4, arity=1, dim=3)` | 4 | 4 | 0 | 0 |
| `matrix(max-constant=8, max-coefficient=8, symbols=6, arity=1, dim=1)` | 4 | 4 | 0 | 0 |
| `matrix(max-constant=9, max-coefficient=9, symbols=6, arity=1, dim=2)` | 4 | 4 | 0 | 0 |
| `poly(max-constant=0, max-coefficient=1, symbols=12, arity=2)` | 4 | 4 | 0 | 0 |
| `poly(max-constant=0, max-coefficient=1, symbols=12, arity=3)` | 4 | 4 | 0 | 0 |
| `poly(max-constant=0, max-coefficient=1, symbols=16, arity=4)` | 4 | 4 | 0 | 0 |
| `poly(max-constant=0, max-coefficient=1, symbols=4, arity=2)` | 4 | 3 | 0 | 1 |
| `poly(max-constant=0, max-coefficient=1, symbols=5, arity=2)` | 4 | 4 | 0 | 0 |
| `poly(max-constant=1, max-coefficient=1, symbols=1, arity=3)` | 4 | 4 | 0 | 0 |
| `poly(max-constant=1, max-coefficient=1, symbols=28, arity=3)` | 4 | 4 | 0 | 0 |
| `poly(max-constant=1, max-coefficient=1, symbols=42, arity=3)` | 4 | 4 | 0 | 0 |
| `poly(max-constant=10, max-coefficient=10, symbols=15, arity=2)` | 4 | 4 | 0 | 0 |
| `poly(max-constant=10, max-coefficient=10, symbols=17, arity=3)` | 4 | 4 | 0 | 0 |
| `poly(max-constant=10, max-coefficient=10, symbols=18, arity=3)` | 4 | 4 | 0 | 0 |
| `poly(max-constant=10, max-coefficient=10, symbols=22, arity=3)` | 4 | 4 | 0 | 0 |
| `poly(max-constant=10, max-coefficient=10, symbols=3, arity=3)` | 4 | 4 | 0 | 0 |
| `poly(max-constant=10, max-coefficient=10, symbols=34, arity=3)` | 4 | 4 | 0 | 0 |
| `poly(max-constant=10, max-coefficient=10, symbols=42, arity=3)` | 4 | 4 | 0 | 0 |
| `poly(max-constant=10, max-coefficient=10, symbols=5, arity=2)` | 4 | 4 | 0 | 0 |
| `poly(max-constant=10, max-coefficient=10, symbols=8, arity=2)` | 4 | 4 | 0 | 0 |
| `poly(max-constant=100, max-coefficient=100, symbols=4, arity=1)` | 4 | 4 | 0 | 0 |
| `poly(max-constant=104, max-coefficient=104, symbols=3, arity=1)` | 4 | 3 | 0 | 1 |
| `poly(max-constant=109, max-coefficient=109, symbols=3, arity=1)` | 4 | 4 | 0 | 0 |
| `poly(max-constant=124, max-coefficient=124, symbols=6, arity=1)` | 4 | 4 | 0 | 0 |
| `poly(max-constant=128, max-coefficient=128, symbols=6, arity=1)` | 4 | 4 | 0 | 0 |
| `poly(max-constant=129, max-coefficient=129, symbols=6, arity=1)` | 4 | 4 | 0 | 0 |
| `poly(max-constant=13, max-coefficient=13, symbols=5, arity=1)` | 4 | 4 | 0 | 0 |
| `poly(max-constant=130, max-coefficient=130, symbols=6, arity=1)` | 4 | 4 | 0 | 0 |
| `poly(max-constant=134, max-coefficient=134, symbols=4, arity=1)` | 4 | 4 | 0 | 0 |
| `poly(max-constant=14, max-coefficient=14, symbols=4, arity=1)` | 4 | 4 | 0 | 0 |
| `poly(max-constant=147, max-coefficient=147, symbols=6, arity=1)` | 4 | 4 | 0 | 0 |
| `poly(max-constant=16, max-coefficient=16, symbols=4, arity=3)` | 4 | 4 | 0 | 0 |
| `poly(max-constant=16, max-coefficient=16, symbols=5, arity=1)` | 4 | 4 | 0 | 0 |
| `poly(max-constant=16, max-coefficient=16, symbols=8, arity=1)` | 4 | 4 | 0 | 0 |
| `poly(max-constant=178, max-coefficient=178, symbols=3, arity=1)` | 4 | 4 | 0 | 0 |
| `poly(max-constant=18, max-coefficient=18, symbols=6, arity=1)` | 4 | 4 | 0 | 0 |
| `poly(max-constant=185, max-coefficient=185, symbols=5, arity=1)` | 4 | 4 | 0 | 0 |
| `poly(max-constant=1954, max-coefficient=1954, symbols=3, arity=1)` | 4 | 4 | 0 | 0 |
| `poly(max-constant=2, max-coefficient=2, symbols=12, arity=5)` | 4 | 3 | 0 | 1 |
| `poly(max-constant=2, max-coefficient=2, symbols=14, arity=6)` | 4 | 4 | 0 | 0 |
| `poly(max-constant=2, max-coefficient=2, symbols=17, arity=7)` | 4 | 4 | 0 | 0 |
| `poly(max-constant=2, max-coefficient=2, symbols=18, arity=7)` | 4 | 4 | 0 | 0 |
| `poly(max-constant=2, max-coefficient=2, symbols=19, arity=7)` | 4 | 4 | 0 | 0 |
| `poly(max-constant=2, max-coefficient=2, symbols=30, arity=3)` | 4 | 4 | 0 | 0 |
| `poly(max-constant=2, max-coefficient=2, symbols=35, arity=3)` | 4 | 4 | 0 | 0 |
| `poly(max-constant=23, max-coefficient=23, symbols=5, arity=1)` | 4 | 3 | 1 | 0 |
| `poly(max-constant=26, max-coefficient=26, symbols=4, arity=1)` | 4 | 4 | 0 | 0 |
| `poly(max-constant=262, max-coefficient=262, symbols=3, arity=1)` | 4 | 4 | 0 | 0 |
| `poly(max-constant=28, max-coefficient=28, symbols=3, arity=1)` | 4 | 4 | 0 | 0 |
| `poly(max-constant=3, max-coefficient=3, symbols=12, arity=5)` | 4 | 4 | 0 | 0 |
| `poly(max-constant=3, max-coefficient=3, symbols=13, arity=4)` | 4 | 4 | 0 | 0 |
| `poly(max-constant=3, max-coefficient=3, symbols=14, arity=6)` | 4 | 4 | 0 | 0 |
| `poly(max-constant=3, max-coefficient=3, symbols=17, arity=3)` | 4 | 4 | 0 | 0 |
| `poly(max-constant=3, max-coefficient=3, symbols=20, arity=4)` | 4 | 3 | 1 | 0 |
| `poly(max-constant=3, max-coefficient=3, symbols=24, arity=3)` | 4 | 4 | 0 | 0 |
| `poly(max-constant=3, max-coefficient=3, symbols=29, arity=3)` | 4 | 4 | 0 | 0 |
| `poly(max-constant=3, max-coefficient=3, symbols=33, arity=2)` | 4 | 4 | 0 | 0 |
| `poly(max-constant=3, max-coefficient=3, symbols=34, arity=3)` | 4 | 3 | 0 | 1 |
| `poly(max-constant=3, max-coefficient=3, symbols=5, arity=4)` | 4 | 4 | 0 | 0 |
| `poly(max-constant=32, max-coefficient=32, symbols=3, arity=1)` | 4 | 4 | 0 | 0 |
| `poly(max-constant=321, max-coefficient=321, symbols=3, arity=1)` | 4 | 4 | 0 | 0 |
| `poly(max-constant=33, max-coefficient=33, symbols=6, arity=1)` | 4 | 4 | 0 | 0 |
| `poly(max-constant=333, max-coefficient=333, symbols=6, arity=1)` | 4 | 4 | 0 | 0 |
| `poly(max-constant=35, max-coefficient=35, symbols=6, arity=1)` | 4 | 4 | 0 | 0 |
| `poly(max-constant=381, max-coefficient=381, symbols=6, arity=1)` | 4 | 4 | 0 | 0 |
| `poly(max-constant=39, max-coefficient=39, symbols=3, arity=1)` | 4 | 4 | 0 | 0 |
| `poly(max-constant=4, max-coefficient=4, symbols=18, arity=2)` | 4 | 3 | 1 | 0 |
| `poly(max-constant=42, max-coefficient=42, symbols=6, arity=1)` | 4 | 4 | 0 | 0 |
| `poly(max-constant=443, max-coefficient=443, symbols=6, arity=1)` | 4 | 4 | 0 | 0 |
| `poly(max-constant=5, max-coefficient=5, symbols=10, arity=4)` | 4 | 3 | 1 | 0 |
| `poly(max-constant=5, max-coefficient=5, symbols=30, arity=2)` | 4 | 4 | 0 | 0 |
| `poly(max-constant=5, max-coefficient=5, symbols=8, arity=4)` | 4 | 4 | 0 | 0 |
| `poly(max-constant=54, max-coefficient=54, symbols=3, arity=1)` | 4 | 4 | 0 | 0 |
| `poly(max-constant=6, max-coefficient=6, symbols=14, arity=2)` | 4 | 4 | 0 | 0 |
| `poly(max-constant=6, max-coefficient=6, symbols=33, arity=2)` | 4 | 4 | 0 | 0 |
| `poly(max-constant=6, max-coefficient=6, symbols=6, arity=3)` | 4 | 4 | 0 | 0 |
| `poly(max-constant=6, max-coefficient=6, symbols=9, arity=2)` | 4 | 4 | 0 | 0 |
| `poly(max-constant=66, max-coefficient=66, symbols=4, arity=1)` | 4 | 4 | 0 | 0 |
| `poly(max-constant=7, max-coefficient=7, symbols=10, arity=2)` | 4 | 4 | 0 | 0 |
| `poly(max-constant=7, max-coefficient=7, symbols=12, arity=2)` | 4 | 3 | 0 | 1 |
| `poly(max-constant=70, max-coefficient=70, symbols=6, arity=1)` | 4 | 4 | 0 | 0 |
| `poly(max-constant=71, max-coefficient=71, symbols=3, arity=1)` | 4 | 4 | 0 | 0 |
| `poly(max-constant=8, max-coefficient=8, symbols=11, arity=3)` | 4 | 4 | 0 | 0 |
| `poly(max-constant=8, max-coefficient=8, symbols=3, arity=2)` | 4 | 4 | 0 | 0 |
| `poly(max-constant=8, max-coefficient=8, symbols=3, arity=3)` | 4 | 4 | 0 | 0 |
| `poly(max-constant=8, max-coefficient=8, symbols=8, arity=1)` | 4 | 4 | 0 | 0 |
| `poly(max-constant=878, max-coefficient=878, symbols=4, arity=1)` | 4 | 3 | 1 | 0 |
| `poly(max-constant=89, max-coefficient=89, symbols=6, arity=1)` | 4 | 4 | 0 | 0 |
| `poly(max-constant=94, max-coefficient=94, symbols=6, arity=1)` | 4 | 4 | 0 | 0 |
| `kbo(weight=0, symbols=1)` | 3 | 3 | 0 | 0 |
| `kbo(weight=1, symbols=11)` | 3 | 3 | 0 | 0 |
| `kbo(weight=12, symbols=17)` | 3 | 3 | 0 | 0 |
| `kbo(weight=18, symbols=3)` | 3 | 3 | 0 | 0 |
| `kbo(weight=4, symbols=2)` | 3 | 3 | 0 | 0 |
| `kbo(weight=5, symbols=13)` | 3 | 3 | 0 | 0 |
| `kbo(weight=6, symbols=5)` | 3 | 3 | 0 | 0 |
| `kbo(weight=7, symbols=14)` | 3 | 3 | 0 | 0 |
| `kbo(weight=7, symbols=6)` | 3 | 3 | 0 | 0 |
| `kbo(weight=8, symbols=10)` | 3 | 3 | 0 | 0 |
| `kbo(weight=9, symbols=3)` | 3 | 2 | 1 | 0 |
| `matrix(max-constant=1, max-coefficient=1, symbols=10, arity=3, dim=1)` | 3 | 3 | 0 | 0 |
| `matrix(max-constant=1, max-coefficient=1, symbols=10, arity=3, dim=5)` | 3 | 3 | 0 | 0 |
| `matrix(max-constant=1, max-coefficient=1, symbols=13, arity=3, dim=2)` | 3 | 3 | 0 | 0 |
| `matrix(max-constant=1, max-coefficient=1, symbols=15, arity=2, dim=2)` | 3 | 3 | 0 | 0 |
| `matrix(max-constant=1, max-coefficient=1, symbols=15, arity=3, dim=1)` | 3 | 3 | 0 | 0 |
| `matrix(max-constant=1, max-coefficient=1, symbols=26, arity=4, dim=1)` | 3 | 3 | 0 | 0 |
| `matrix(max-constant=1, max-coefficient=1, symbols=26, arity=4, dim=3)` | 3 | 3 | 0 | 0 |
| `matrix(max-constant=1, max-coefficient=1, symbols=7, arity=2, dim=4)` | 3 | 3 | 0 | 0 |
| `matrix(max-constant=1, max-coefficient=1, symbols=7, arity=3, dim=1)` | 3 | 3 | 0 | 0 |
| `matrix(max-constant=10, max-coefficient=10, symbols=14, arity=2, dim=3)` | 3 | 3 | 0 | 0 |
| `matrix(max-constant=10, max-coefficient=10, symbols=3, arity=1, dim=5)` | 3 | 3 | 0 | 0 |
| `matrix(max-constant=12, max-coefficient=12, symbols=6, arity=1, dim=3)` | 3 | 3 | 0 | 0 |
| `matrix(max-constant=14, max-coefficient=14, symbols=4, arity=1, dim=3)` | 3 | 3 | 0 | 0 |
| `matrix(max-constant=16, max-coefficient=16, symbols=2, arity=1, dim=5)` | 3 | 3 | 0 | 0 |
| `matrix(max-constant=16, max-coefficient=16, symbols=5, arity=1, dim=3)` | 3 | 2 | 1 | 0 |
| `matrix(max-constant=17, max-coefficient=17, symbols=2, arity=1, dim=3)` | 3 | 3 | 0 | 0 |
| `matrix(max-constant=17, max-coefficient=17, symbols=3, arity=1, dim=4)` | 3 | 3 | 0 | 0 |
| `matrix(max-constant=18, max-coefficient=18, symbols=2, arity=1, dim=3)` | 3 | 3 | 0 | 0 |
| `matrix(max-constant=2, max-coefficient=2, symbols=12, arity=2, dim=2)` | 3 | 3 | 0 | 0 |
| `matrix(max-constant=2, max-coefficient=2, symbols=13, arity=3, dim=2)` | 3 | 3 | 0 | 0 |
| `matrix(max-constant=2, max-coefficient=2, symbols=13, arity=4, dim=1)` | 3 | 3 | 0 | 0 |
| `matrix(max-constant=2, max-coefficient=2, symbols=15, arity=2, dim=2)` | 3 | 3 | 0 | 0 |
| `matrix(max-constant=2, max-coefficient=2, symbols=5, arity=3, dim=3)` | 3 | 3 | 0 | 0 |
| `matrix(max-constant=2, max-coefficient=2, symbols=6, arity=3, dim=2)` | 3 | 3 | 0 | 0 |
| `matrix(max-constant=20, max-coefficient=20, symbols=4, arity=1, dim=5)` | 3 | 3 | 0 | 0 |
| `matrix(max-constant=21, max-coefficient=21, symbols=3, arity=1, dim=5)` | 3 | 3 | 0 | 0 |
| `matrix(max-constant=21, max-coefficient=21, symbols=6, arity=1, dim=3)` | 3 | 3 | 0 | 0 |
| `matrix(max-constant=23, max-coefficient=23, symbols=3, arity=1, dim=3)` | 3 | 3 | 0 | 0 |
| `matrix(max-constant=25, max-coefficient=25, symbols=2, arity=1, dim=5)` | 3 | 3 | 0 | 0 |
| `matrix(max-constant=3, max-coefficient=3, symbols=13, arity=3, dim=2)` | 3 | 3 | 0 | 0 |
| `matrix(max-constant=3, max-coefficient=3, symbols=14, arity=2, dim=1)` | 3 | 3 | 0 | 0 |
| `matrix(max-constant=3, max-coefficient=3, symbols=14, arity=3, dim=3)` | 3 | 3 | 0 | 0 |
| `matrix(max-constant=3, max-coefficient=3, symbols=17, arity=2, dim=1)` | 3 | 3 | 0 | 0 |
| `matrix(max-constant=3, max-coefficient=3, symbols=21, arity=3, dim=1)` | 3 | 3 | 0 | 0 |
| `matrix(max-constant=3, max-coefficient=3, symbols=4, arity=1, dim=5)` | 3 | 3 | 0 | 0 |
| `matrix(max-constant=3, max-coefficient=3, symbols=4, arity=2, dim=3)` | 3 | 3 | 0 | 0 |
| `matrix(max-constant=3, max-coefficient=3, symbols=5, arity=2, dim=3)` | 3 | 3 | 0 | 0 |
| `matrix(max-constant=3, max-coefficient=3, symbols=9, arity=1, dim=3)` | 3 | 3 | 0 | 0 |
| `matrix(max-constant=35, max-coefficient=35, symbols=3, arity=1, dim=5)` | 3 | 3 | 0 | 0 |
| `matrix(max-constant=37, max-coefficient=37, symbols=3, arity=1, dim=5)` | 3 | 3 | 0 | 0 |
| `matrix(max-constant=4, max-coefficient=4, symbols=14, arity=3, dim=1)` | 3 | 3 | 0 | 0 |
| `matrix(max-constant=4, max-coefficient=4, symbols=17, arity=2, dim=1)` | 3 | 3 | 0 | 0 |
| `matrix(max-constant=4, max-coefficient=4, symbols=23, arity=2, dim=1)` | 3 | 3 | 0 | 0 |
| `matrix(max-constant=4, max-coefficient=4, symbols=24, arity=2, dim=1)` | 3 | 3 | 0 | 0 |
| `matrix(max-constant=4, max-coefficient=4, symbols=3, arity=2, dim=4)` | 3 | 3 | 0 | 0 |
| `matrix(max-constant=4, max-coefficient=4, symbols=4, arity=2, dim=1)` | 3 | 3 | 0 | 0 |
| `matrix(max-constant=4, max-coefficient=4, symbols=4, arity=2, dim=2)` | 3 | 3 | 0 | 0 |
| `matrix(max-constant=4, max-coefficient=4, symbols=6, arity=1, dim=4)` | 3 | 3 | 0 | 0 |
| `matrix(max-constant=4, max-coefficient=4, symbols=6, arity=2, dim=4)` | 3 | 2 | 1 | 0 |
| `matrix(max-constant=4, max-coefficient=4, symbols=7, arity=1, dim=2)` | 3 | 3 | 0 | 0 |
| `matrix(max-constant=4, max-coefficient=4, symbols=7, arity=2, dim=2)` | 3 | 3 | 0 | 0 |
| `matrix(max-constant=40, max-coefficient=40, symbols=2, arity=1, dim=5)` | 3 | 3 | 0 | 0 |
| `matrix(max-constant=46, max-coefficient=46, symbols=2, arity=1, dim=5)` | 3 | 3 | 0 | 0 |
| `matrix(max-constant=47, max-coefficient=47, symbols=3, arity=1, dim=5)` | 3 | 3 | 0 | 0 |
| `matrix(max-constant=5, max-coefficient=5, symbols=4, arity=3, dim=3)` | 3 | 3 | 0 | 0 |
| `matrix(max-constant=5, max-coefficient=5, symbols=4, arity=3, dim=4)` | 3 | 3 | 0 | 0 |
| `matrix(max-constant=5, max-coefficient=5, symbols=5, arity=1, dim=3)` | 3 | 3 | 0 | 0 |
| `matrix(max-constant=5, max-coefficient=5, symbols=6, arity=3, dim=1)` | 3 | 3 | 0 | 0 |
| `matrix(max-constant=5, max-coefficient=5, symbols=8, arity=1, dim=3)` | 3 | 3 | 0 | 0 |
| `matrix(max-constant=56, max-coefficient=56, symbols=2, arity=1, dim=5)` | 3 | 2 | 1 | 0 |
| `matrix(max-constant=6, max-coefficient=6, symbols=3, arity=1, dim=2)` | 3 | 3 | 0 | 0 |
| `matrix(max-constant=64, max-coefficient=64, symbols=2, arity=1, dim=7)` | 3 | 3 | 0 | 0 |
| `matrix(max-constant=7, max-coefficient=7, symbols=3, arity=3, dim=2)` | 3 | 3 | 0 | 0 |
| `matrix(max-constant=7, max-coefficient=7, symbols=6, arity=1, dim=2)` | 3 | 3 | 0 | 0 |
| `matrix(max-constant=7, max-coefficient=7, symbols=6, arity=1, dim=3)` | 3 | 3 | 0 | 0 |
| `matrix(max-constant=7, max-coefficient=7, symbols=8, arity=1, dim=2)` | 3 | 3 | 0 | 0 |
| `matrix(max-constant=75, max-coefficient=75, symbols=3, arity=1, dim=5)` | 3 | 3 | 0 | 0 |
| `matrix(max-constant=8, max-coefficient=8, symbols=10, arity=1, dim=3)` | 3 | 3 | 0 | 0 |
| `matrix(max-constant=8, max-coefficient=8, symbols=3, arity=1, dim=2)` | 3 | 3 | 0 | 0 |
| `poly(max-constant=0, max-coefficient=1, symbols=10, arity=2)` | 3 | 3 | 0 | 0 |
| `poly(max-constant=0, max-coefficient=1, symbols=11, arity=5)` | 3 | 3 | 0 | 0 |
| `poly(max-constant=1, max-coefficient=1, symbols=23, arity=2)` | 3 | 3 | 0 | 0 |
| `poly(max-constant=1, max-coefficient=1, symbols=27, arity=2)` | 3 | 3 | 0 | 0 |
| `poly(max-constant=1, max-coefficient=1, symbols=28, arity=4)` | 3 | 3 | 0 | 0 |
| `poly(max-constant=1, max-coefficient=1, symbols=43, arity=3)` | 3 | 3 | 0 | 0 |
| `poly(max-constant=1, max-coefficient=1, symbols=48, arity=3)` | 3 | 3 | 0 | 0 |
| `poly(max-constant=10, max-coefficient=10, symbols=8, arity=3)` | 3 | 3 | 0 | 0 |
| `poly(max-constant=199, max-coefficient=199, symbols=6, arity=1)` | 3 | 3 | 0 | 0 |
| `poly(max-constant=2, max-coefficient=2, symbols=13, arity=6)` | 3 | 3 | 0 | 0 |
| `poly(max-constant=2, max-coefficient=2, symbols=13, arity=8)` | 3 | 3 | 0 | 0 |
| `poly(max-constant=2, max-coefficient=2, symbols=9, arity=5)` | 3 | 3 | 0 | 0 |
| `poly(max-constant=2, max-coefficient=2, symbols=9, arity=6)` | 3 | 3 | 0 | 0 |
| `poly(max-constant=3, max-coefficient=3, symbols=23, arity=2)` | 3 | 3 | 0 | 0 |
| `poly(max-constant=3, max-coefficient=3, symbols=35, arity=4)` | 3 | 3 | 0 | 0 |
| `poly(max-constant=3, max-coefficient=3, symbols=42, arity=3)` | 3 | 3 | 0 | 0 |
| `poly(max-constant=3, max-coefficient=3, symbols=7, arity=3)` | 3 | 3 | 0 | 0 |
| `poly(max-constant=376, max-coefficient=376, symbols=6, arity=1)` | 3 | 3 | 0 | 0 |
| `poly(max-constant=38, max-coefficient=38, symbols=3, arity=1)` | 3 | 3 | 0 | 0 |
| `poly(max-constant=4, max-coefficient=4, symbols=25, arity=2)` | 3 | 3 | 0 | 0 |
| `poly(max-constant=4, max-coefficient=4, symbols=7, arity=4)` | 3 | 3 | 0 | 0 |
| `poly(max-constant=6, max-coefficient=6, symbols=13, arity=2)` | 3 | 3 | 0 | 0 |
| `poly(max-constant=6, max-coefficient=6, symbols=8, arity=3)` | 3 | 3 | 0 | 0 |
| `poly(max-constant=7, max-coefficient=7, symbols=3, arity=3)` | 3 | 3 | 0 | 0 |
| `poly(max-constant=7, max-coefficient=7, symbols=30, arity=5)` | 3 | 3 | 0 | 0 |
| `poly(max-constant=7, max-coefficient=7, symbols=36, arity=3)` | 3 | 3 | 0 | 0 |
| `poly(max-constant=7, max-coefficient=7, symbols=6, arity=2)` | 3 | 3 | 0 | 0 |
| `poly(max-constant=7, max-coefficient=7, symbols=8, arity=3)` | 3 | 3 | 0 | 0 |
| `poly(max-constant=8, max-coefficient=8, symbols=10, arity=1)` | 3 | 3 | 0 | 0 |
| `poly(max-constant=8, max-coefficient=8, symbols=20, arity=2)` | 3 | 3 | 0 | 0 |
| `poly(max-constant=8, max-coefficient=8, symbols=4, arity=3)` | 3 | 3 | 0 | 0 |
| `poly(max-constant=8, max-coefficient=8, symbols=8, arity=3)` | 3 | 3 | 0 | 0 |
| `poly(max-constant=9, max-coefficient=9, symbols=2, arity=1)` | 3 | 3 | 0 | 0 |
| `poly(max-constant=9, max-coefficient=9, symbols=3, arity=2)` | 3 | 3 | 0 | 0 |
| `kbo(weight=0, symbols=16)` | 2 | 2 | 0 | 0 |
| `kbo(weight=1, symbols=22)` | 2 | 2 | 0 | 0 |
| `kbo(weight=1, symbols=34)` | 2 | 2 | 0 | 0 |
| `kbo(weight=11, symbols=3)` | 2 | 2 | 0 | 0 |
| `kbo(weight=14, symbols=3)` | 2 | 2 | 0 | 0 |
| `kbo(weight=17, symbols=3)` | 2 | 2 | 0 | 0 |
| `kbo(weight=19, symbols=3)` | 2 | 2 | 0 | 0 |
| `kbo(weight=2, symbols=13)` | 2 | 2 | 0 | 0 |
| `kbo(weight=2, symbols=20)` | 2 | 2 | 0 | 0 |
| `kbo(weight=2, symbols=38)` | 2 | 2 | 0 | 0 |
| `kbo(weight=2, symbols=44)` | 2 | 2 | 0 | 0 |
| `kbo(weight=2, symbols=9)` | 2 | 2 | 0 | 0 |
| `kbo(weight=24, symbols=3)` | 2 | 2 | 0 | 0 |
| `kbo(weight=27, symbols=3)` | 2 | 2 | 0 | 0 |
| `kbo(weight=3, symbols=10)` | 2 | 2 | 0 | 0 |
| `kbo(weight=3, symbols=13)` | 2 | 2 | 0 | 0 |
| `kbo(weight=3, symbols=8)` | 2 | 2 | 0 | 0 |
| `kbo(weight=30, symbols=3)` | 2 | 1 | 0 | 1 |
| `kbo(weight=4, symbols=33)` | 2 | 2 | 0 | 0 |
| `kbo(weight=41, symbols=3)` | 2 | 2 | 0 | 0 |
| `kbo(weight=48, symbols=3)` | 2 | 2 | 0 | 0 |
| `kbo(weight=5, symbols=17)` | 2 | 2 | 0 | 0 |
| `kbo(weight=5, symbols=8)` | 2 | 2 | 0 | 0 |
| `kbo(weight=7, symbols=15)` | 2 | 2 | 0 | 0 |
| `kbo(weight=8, symbols=12)` | 2 | 1 | 0 | 1 |
| `matrix(max-constant=0, max-coefficient=1, symbols=11, arity=1, dim=1)` | 2 | 2 | 0 | 0 |
| `matrix(max-constant=1, max-coefficient=1, symbols=1, arity=3, dim=1)` | 2 | 2 | 0 | 0 |
| `matrix(max-constant=1, max-coefficient=1, symbols=10, arity=2, dim=1)` | 2 | 2 | 0 | 0 |
| `matrix(max-constant=1, max-coefficient=1, symbols=13, arity=4, dim=1)` | 2 | 2 | 0 | 0 |
| `matrix(max-constant=1, max-coefficient=1, symbols=14, arity=2, dim=4)` | 2 | 2 | 0 | 0 |
| `matrix(max-constant=1, max-coefficient=1, symbols=15, arity=2, dim=1)` | 2 | 2 | 0 | 0 |
| `matrix(max-constant=1, max-coefficient=1, symbols=16, arity=3, dim=3)` | 2 | 2 | 0 | 0 |
| `matrix(max-constant=1, max-coefficient=1, symbols=17, arity=2, dim=2)` | 2 | 1 | 0 | 1 |
| `matrix(max-constant=1, max-coefficient=1, symbols=17, arity=4, dim=1)` | 2 | 2 | 0 | 0 |
| `matrix(max-constant=1, max-coefficient=1, symbols=2, arity=2, dim=1)` | 2 | 2 | 0 | 0 |
| `matrix(max-constant=1, max-coefficient=1, symbols=2, arity=2, dim=5)` | 2 | 2 | 0 | 0 |
| `matrix(max-constant=1, max-coefficient=1, symbols=2, arity=3, dim=2)` | 2 | 2 | 0 | 0 |
| `matrix(max-constant=1, max-coefficient=1, symbols=3, arity=2, dim=5)` | 2 | 2 | 0 | 0 |
| `matrix(max-constant=1, max-coefficient=1, symbols=5, arity=3, dim=1)` | 2 | 2 | 0 | 0 |
| `matrix(max-constant=1, max-coefficient=1, symbols=5, arity=3, dim=2)` | 2 | 2 | 0 | 0 |
| `matrix(max-constant=1, max-coefficient=1, symbols=6, arity=4, dim=3)` | 2 | 2 | 0 | 0 |
| `matrix(max-constant=1, max-coefficient=1, symbols=7, arity=1, dim=2)` | 2 | 2 | 0 | 0 |
| `matrix(max-constant=1, max-coefficient=1, symbols=8, arity=2, dim=5)` | 2 | 2 | 0 | 0 |
| `matrix(max-constant=1, max-coefficient=1, symbols=9, arity=3, dim=2)` | 2 | 2 | 0 | 0 |
| `matrix(max-constant=10, max-coefficient=10, symbols=5, arity=1, dim=3)` | 2 | 2 | 0 | 0 |
| `matrix(max-constant=11, max-coefficient=11, symbols=3, arity=1, dim=2)` | 2 | 2 | 0 | 0 |
| `matrix(max-constant=12, max-coefficient=12, symbols=3, arity=1, dim=4)` | 2 | 2 | 0 | 0 |
| `matrix(max-constant=12, max-coefficient=12, symbols=7, arity=1, dim=3)` | 2 | 2 | 0 | 0 |
| `matrix(max-constant=13, max-coefficient=13, symbols=4, arity=1, dim=3)` | 2 | 2 | 0 | 0 |
| `matrix(max-constant=13, max-coefficient=13, symbols=6, arity=1, dim=2)` | 2 | 2 | 0 | 0 |
| `matrix(max-constant=13, max-coefficient=13, symbols=7, arity=1, dim=2)` | 2 | 2 | 0 | 0 |
| `matrix(max-constant=14, max-coefficient=14, symbols=2, arity=1, dim=5)` | 2 | 2 | 0 | 0 |
| `matrix(max-constant=14, max-coefficient=14, symbols=4, arity=1, dim=2)` | 2 | 2 | 0 | 0 |
| `matrix(max-constant=14, max-coefficient=14, symbols=5, arity=1, dim=5)` | 2 | 2 | 0 | 0 |
| `matrix(max-constant=15, max-coefficient=15, symbols=2, arity=1, dim=4)` | 2 | 2 | 0 | 0 |
| `matrix(max-constant=15, max-coefficient=15, symbols=2, arity=1, dim=7)` | 2 | 2 | 0 | 0 |
| `matrix(max-constant=15, max-coefficient=15, symbols=8, arity=1, dim=3)` | 2 | 2 | 0 | 0 |
| `matrix(max-constant=17, max-coefficient=17, symbols=6, arity=1, dim=3)` | 2 | 2 | 0 | 0 |
| `matrix(max-constant=18, max-coefficient=18, symbols=3, arity=1, dim=5)` | 2 | 2 | 0 | 0 |
| `matrix(max-constant=18, max-coefficient=18, symbols=5, arity=1, dim=3)` | 2 | 2 | 0 | 0 |
| `matrix(max-constant=18, max-coefficient=18, symbols=6, arity=1, dim=3)` | 2 | 2 | 0 | 0 |
| `matrix(max-constant=2, max-coefficient=2, symbols=11, arity=3, dim=2)` | 2 | 2 | 0 | 0 |
| `matrix(max-constant=2, max-coefficient=2, symbols=16, arity=3, dim=2)` | 2 | 2 | 0 | 0 |
| `matrix(max-constant=2, max-coefficient=2, symbols=2, arity=2, dim=1)` | 2 | 2 | 0 | 0 |
| `matrix(max-constant=2, max-coefficient=2, symbols=28, arity=4, dim=1)` | 2 | 2 | 0 | 0 |
| `matrix(max-constant=2, max-coefficient=2, symbols=33, arity=2, dim=2)` | 2 | 2 | 0 | 0 |
| `matrix(max-constant=2, max-coefficient=2, symbols=4, arity=3, dim=1)` | 2 | 2 | 0 | 0 |
| `matrix(max-constant=2, max-coefficient=2, symbols=5, arity=1, dim=5)` | 2 | 2 | 0 | 0 |
| `matrix(max-constant=2, max-coefficient=2, symbols=5, arity=3, dim=1)` | 2 | 2 | 0 | 0 |
| `matrix(max-constant=21, max-coefficient=21, symbols=5, arity=1, dim=3)` | 2 | 2 | 0 | 0 |
| `matrix(max-constant=22, max-coefficient=22, symbols=3, arity=1, dim=5)` | 2 | 2 | 0 | 0 |
| `matrix(max-constant=24, max-coefficient=24, symbols=2, arity=1, dim=3)` | 2 | 2 | 0 | 0 |
| `matrix(max-constant=24, max-coefficient=24, symbols=2, arity=1, dim=4)` | 2 | 2 | 0 | 0 |
| `matrix(max-constant=24, max-coefficient=24, symbols=2, arity=1, dim=5)` | 2 | 2 | 0 | 0 |
| `matrix(max-constant=24, max-coefficient=24, symbols=3, arity=1, dim=5)` | 2 | 2 | 0 | 0 |
| `matrix(max-constant=24, max-coefficient=24, symbols=8, arity=1, dim=3)` | 2 | 2 | 0 | 0 |
| `matrix(max-constant=26, max-coefficient=26, symbols=5, arity=1, dim=4)` | 2 | 1 | 0 | 1 |
| `matrix(max-constant=27, max-coefficient=27, symbols=2, arity=1, dim=4)` | 2 | 2 | 0 | 0 |
| `matrix(max-constant=27, max-coefficient=27, symbols=3, arity=1, dim=5)` | 2 | 2 | 0 | 0 |
| `matrix(max-constant=29, max-coefficient=29, symbols=3, arity=1, dim=5)` | 2 | 2 | 0 | 0 |
| `matrix(max-constant=3, max-coefficient=3, symbols=11, arity=3, dim=3)` | 2 | 2 | 0 | 0 |
| `matrix(max-constant=3, max-coefficient=3, symbols=12, arity=3, dim=2)` | 2 | 2 | 0 | 0 |
| `matrix(max-constant=3, max-coefficient=3, symbols=13, arity=2, dim=2)` | 2 | 2 | 0 | 0 |
| `matrix(max-constant=3, max-coefficient=3, symbols=13, arity=4, dim=1)` | 2 | 2 | 0 | 0 |
| `matrix(max-constant=3, max-coefficient=3, symbols=14, arity=3, dim=1)` | 2 | 2 | 0 | 0 |
| `matrix(max-constant=3, max-coefficient=3, symbols=15, arity=3, dim=1)` | 2 | 2 | 0 | 0 |
| `matrix(max-constant=3, max-coefficient=3, symbols=16, arity=3, dim=3)` | 2 | 2 | 0 | 0 |
| `matrix(max-constant=3, max-coefficient=3, symbols=2, arity=3, dim=1)` | 2 | 2 | 0 | 0 |
| `matrix(max-constant=3, max-coefficient=3, symbols=20, arity=3, dim=1)` | 2 | 2 | 0 | 0 |
| `matrix(max-constant=3, max-coefficient=3, symbols=4, arity=3, dim=3)` | 2 | 2 | 0 | 0 |
| `matrix(max-constant=3, max-coefficient=3, symbols=4, arity=3, dim=4)` | 2 | 2 | 0 | 0 |
| `matrix(max-constant=3, max-coefficient=3, symbols=41, arity=3, dim=1)` | 2 | 2 | 0 | 0 |
| `matrix(max-constant=3, max-coefficient=3, symbols=8, arity=4, dim=1)` | 2 | 2 | 0 | 0 |
| `matrix(max-constant=30, max-coefficient=30, symbols=2, arity=1, dim=5)` | 2 | 2 | 0 | 0 |
| `matrix(max-constant=30, max-coefficient=30, symbols=3, arity=1, dim=5)` | 2 | 2 | 0 | 0 |
| `matrix(max-constant=34, max-coefficient=34, symbols=3, arity=1, dim=5)` | 2 | 2 | 0 | 0 |
| `matrix(max-constant=37, max-coefficient=37, symbols=2, arity=1, dim=5)` | 2 | 2 | 0 | 0 |
| `matrix(max-constant=4, max-coefficient=4, symbols=11, arity=2, dim=2)` | 2 | 2 | 0 | 0 |
| `matrix(max-constant=4, max-coefficient=4, symbols=12, arity=2, dim=2)` | 2 | 2 | 0 | 0 |
| `matrix(max-constant=4, max-coefficient=4, symbols=12, arity=2, dim=3)` | 2 | 2 | 0 | 0 |
| `matrix(max-constant=4, max-coefficient=4, symbols=15, arity=2, dim=1)` | 2 | 2 | 0 | 0 |
| `matrix(max-constant=4, max-coefficient=4, symbols=15, arity=2, dim=3)` | 2 | 2 | 0 | 0 |
| `matrix(max-constant=4, max-coefficient=4, symbols=17, arity=2, dim=3)` | 2 | 2 | 0 | 0 |
| `matrix(max-constant=4, max-coefficient=4, symbols=2, arity=1, dim=1)` | 2 | 2 | 0 | 0 |
| `matrix(max-constant=4, max-coefficient=4, symbols=41, arity=3, dim=1)` | 2 | 2 | 0 | 0 |
| `matrix(max-constant=4, max-coefficient=4, symbols=5, arity=2, dim=1)` | 2 | 2 | 0 | 0 |
| `matrix(max-constant=4, max-coefficient=4, symbols=6, arity=3, dim=1)` | 2 | 2 | 0 | 0 |
| `matrix(max-constant=43, max-coefficient=43, symbols=2, arity=1, dim=5)` | 2 | 2 | 0 | 0 |
| `matrix(max-constant=44, max-coefficient=44, symbols=2, arity=1, dim=5)` | 2 | 2 | 0 | 0 |
| `matrix(max-constant=45, max-coefficient=45, symbols=2, arity=1, dim=5)` | 2 | 2 | 0 | 0 |
| `matrix(max-constant=45, max-coefficient=45, symbols=3, arity=1, dim=5)` | 2 | 2 | 0 | 0 |
| `matrix(max-constant=45, max-coefficient=45, symbols=5, arity=1, dim=5)` | 2 | 2 | 0 | 0 |
| `matrix(max-constant=46, max-coefficient=46, symbols=3, arity=1, dim=5)` | 2 | 2 | 0 | 0 |
| `matrix(max-constant=48, max-coefficient=48, symbols=3, arity=1, dim=5)` | 2 | 2 | 0 | 0 |
| `matrix(max-constant=49, max-coefficient=49, symbols=3, arity=1, dim=5)` | 2 | 2 | 0 | 0 |
| `matrix(max-constant=5, max-coefficient=5, symbols=11, arity=2, dim=3)` | 2 | 2 | 0 | 0 |
| `matrix(max-constant=5, max-coefficient=5, symbols=14, arity=3, dim=1)` | 2 | 2 | 0 | 0 |
| `matrix(max-constant=5, max-coefficient=5, symbols=16, arity=2, dim=1)` | 2 | 2 | 0 | 0 |
| `matrix(max-constant=5, max-coefficient=5, symbols=17, arity=2, dim=1)` | 2 | 2 | 0 | 0 |
| `matrix(max-constant=5, max-coefficient=5, symbols=20, arity=2, dim=3)` | 2 | 2 | 0 | 0 |
| `matrix(max-constant=5, max-coefficient=5, symbols=4, arity=1, dim=4)` | 2 | 2 | 0 | 0 |
| `matrix(max-constant=5, max-coefficient=5, symbols=4, arity=3, dim=1)` | 2 | 2 | 0 | 0 |
| `matrix(max-constant=5, max-coefficient=5, symbols=4, arity=3, dim=5)` | 2 | 2 | 0 | 0 |
| `matrix(max-constant=5, max-coefficient=5, symbols=5, arity=2, dim=3)` | 2 | 2 | 0 | 0 |
| `matrix(max-constant=5, max-coefficient=5, symbols=5, arity=3, dim=2)` | 2 | 2 | 0 | 0 |
| `matrix(max-constant=5, max-coefficient=5, symbols=5, arity=3, dim=3)` | 2 | 2 | 0 | 0 |
| `matrix(max-constant=5, max-coefficient=5, symbols=6, arity=3, dim=2)` | 2 | 2 | 0 | 0 |
| `matrix(max-constant=5, max-coefficient=5, symbols=7, arity=2, dim=1)` | 2 | 2 | 0 | 0 |
| `matrix(max-constant=6, max-coefficient=6, symbols=12, arity=2, dim=3)` | 2 | 2 | 0 | 0 |
| `matrix(max-constant=6, max-coefficient=6, symbols=4, arity=1, dim=2)` | 2 | 2 | 0 | 0 |
| `matrix(max-constant=6, max-coefficient=6, symbols=6, arity=1, dim=2)` | 2 | 2 | 0 | 0 |
| `matrix(max-constant=60, max-coefficient=60, symbols=6, arity=1, dim=5)` | 2 | 2 | 0 | 0 |
| `matrix(max-constant=63, max-coefficient=63, symbols=3, arity=1, dim=5)` | 2 | 2 | 0 | 0 |
| `matrix(max-constant=66, max-coefficient=66, symbols=3, arity=1, dim=5)` | 2 | 2 | 0 | 0 |
| `matrix(max-constant=7, max-coefficient=7, symbols=2, arity=1, dim=5)` | 2 | 2 | 0 | 0 |
| `matrix(max-constant=7, max-coefficient=7, symbols=2, arity=1, dim=7)` | 2 | 2 | 0 | 0 |
| `matrix(max-constant=7, max-coefficient=7, symbols=4, arity=3, dim=2)` | 2 | 2 | 0 | 0 |
| `matrix(max-constant=70, max-coefficient=70, symbols=5, arity=1, dim=5)` | 2 | 2 | 0 | 0 |
| `matrix(max-constant=71, max-coefficient=71, symbols=2, arity=1, dim=5)` | 2 | 2 | 0 | 0 |
| `matrix(max-constant=72, max-coefficient=72, symbols=3, arity=1, dim=5)` | 2 | 2 | 0 | 0 |
| `matrix(max-constant=74, max-coefficient=74, symbols=3, arity=1, dim=5)` | 2 | 2 | 0 | 0 |
| `matrix(max-constant=75, max-coefficient=75, symbols=8, arity=1, dim=5)` | 2 | 2 | 0 | 0 |
| `matrix(max-constant=8, max-coefficient=8, symbols=5, arity=1, dim=3)` | 2 | 2 | 0 | 0 |
| `matrix(max-constant=8, max-coefficient=8, symbols=5, arity=3, dim=3)` | 2 | 2 | 0 | 0 |
| `matrix(max-constant=9, max-coefficient=9, symbols=2, arity=1, dim=5)` | 2 | 2 | 0 | 0 |
| `matrix(max-constant=9, max-coefficient=9, symbols=6, arity=1, dim=3)` | 2 | 2 | 0 | 0 |
| `poly(max-constant=0, max-coefficient=1, symbols=10, arity=3)` | 2 | 2 | 0 | 0 |
| `poly(max-constant=0, max-coefficient=1, symbols=10, arity=5)` | 2 | 2 | 0 | 0 |
| `poly(max-constant=0, max-coefficient=1, symbols=11, arity=3)` | 2 | 2 | 0 | 0 |
| `poly(max-constant=0, max-coefficient=1, symbols=18, arity=4)` | 2 | 2 | 0 | 0 |
| `poly(max-constant=0, max-coefficient=1, symbols=6, arity=1)` | 2 | 2 | 0 | 0 |
| `poly(max-constant=1, max-coefficient=1, symbols=11, arity=5)` | 2 | 2 | 0 | 0 |
| `poly(max-constant=1, max-coefficient=1, symbols=13, arity=6)` | 2 | 2 | 0 | 0 |
| `poly(max-constant=1, max-coefficient=1, symbols=13, arity=8)` | 2 | 2 | 0 | 0 |
| `poly(max-constant=1, max-coefficient=1, symbols=14, arity=4)` | 2 | 2 | 0 | 0 |
| `poly(max-constant=1, max-coefficient=1, symbols=14, arity=6)` | 2 | 2 | 0 | 0 |
| `poly(max-constant=1, max-coefficient=1, symbols=18, arity=3)` | 2 | 2 | 0 | 0 |
| `poly(max-constant=1, max-coefficient=1, symbols=19, arity=4)` | 2 | 1 | 0 | 1 |
| `poly(max-constant=1, max-coefficient=1, symbols=30, arity=3)` | 2 | 2 | 0 | 0 |
| `poly(max-constant=1, max-coefficient=1, symbols=32, arity=2)` | 2 | 2 | 0 | 0 |
| `poly(max-constant=1, max-coefficient=1, symbols=33, arity=4)` | 2 | 2 | 0 | 0 |
| `poly(max-constant=1, max-coefficient=1, symbols=46, arity=3)` | 2 | 2 | 0 | 0 |
| `poly(max-constant=10, max-coefficient=10, symbols=13, arity=3)` | 2 | 2 | 0 | 0 |
| `poly(max-constant=10, max-coefficient=10, symbols=2, arity=3)` | 2 | 2 | 0 | 0 |
| `poly(max-constant=10, max-coefficient=10, symbols=3, arity=2)` | 2 | 2 | 0 | 0 |
| `poly(max-constant=10, max-coefficient=10, symbols=33, arity=3)` | 2 | 2 | 0 | 0 |
| `poly(max-constant=10, max-coefficient=10, symbols=43, arity=3)` | 2 | 2 | 0 | 0 |
| `poly(max-constant=10, max-coefficient=10, symbols=44, arity=3)` | 2 | 2 | 0 | 0 |
| `poly(max-constant=10, max-coefficient=10, symbols=45, arity=3)` | 2 | 2 | 0 | 0 |
| `poly(max-constant=10, max-coefficient=10, symbols=48, arity=3)` | 2 | 2 | 0 | 0 |
| `poly(max-constant=10, max-coefficient=10, symbols=7, arity=3)` | 2 | 2 | 0 | 0 |
| `poly(max-constant=10, max-coefficient=10, symbols=9, arity=3)` | 2 | 1 | 1 | 0 |
| `poly(max-constant=111, max-coefficient=111, symbols=6, arity=1)` | 2 | 2 | 0 | 0 |
| `poly(max-constant=114, max-coefficient=114, symbols=6, arity=1)` | 2 | 2 | 0 | 0 |
| `poly(max-constant=13, max-coefficient=13, symbols=6, arity=1)` | 2 | 2 | 0 | 0 |
| `poly(max-constant=136, max-coefficient=136, symbols=6, arity=1)` | 2 | 2 | 0 | 0 |
| `poly(max-constant=14, max-coefficient=14, symbols=5, arity=1)` | 2 | 2 | 0 | 0 |
| `poly(max-constant=15, max-coefficient=15, symbols=2, arity=1)` | 2 | 2 | 0 | 0 |
| `poly(max-constant=16, max-coefficient=16, symbols=16, arity=4)` | 2 | 2 | 0 | 0 |
| `poly(max-constant=16, max-coefficient=16, symbols=3, arity=2)` | 2 | 1 | 1 | 0 |
| `poly(max-constant=16, max-coefficient=16, symbols=7, arity=1)` | 2 | 2 | 0 | 0 |
| `poly(max-constant=164, max-coefficient=164, symbols=6, arity=1)` | 2 | 2 | 0 | 0 |
| `poly(max-constant=18, max-coefficient=18, symbols=25, arity=2)` | 2 | 2 | 0 | 0 |
| `poly(max-constant=18, max-coefficient=18, symbols=33, arity=2)` | 2 | 2 | 0 | 0 |
| `poly(max-constant=19, max-coefficient=19, symbols=3, arity=1)` | 2 | 2 | 0 | 0 |
| `poly(max-constant=2, max-coefficient=2, symbols=1, arity=3)` | 2 | 2 | 0 | 0 |
| `poly(max-constant=2, max-coefficient=2, symbols=15, arity=1)` | 2 | 2 | 0 | 0 |
| `poly(max-constant=2, max-coefficient=2, symbols=15, arity=7)` | 2 | 2 | 0 | 0 |
| `poly(max-constant=2, max-coefficient=2, symbols=16, arity=7)` | 2 | 2 | 0 | 0 |
| `poly(max-constant=2, max-coefficient=2, symbols=20, arity=7)` | 2 | 2 | 0 | 0 |
| `poly(max-constant=2, max-coefficient=2, symbols=24, arity=4)` | 2 | 2 | 0 | 0 |
| `poly(max-constant=2, max-coefficient=2, symbols=3, arity=0)` | 2 | 2 | 0 | 0 |
| `poly(max-constant=2, max-coefficient=2, symbols=4, arity=5)` | 2 | 2 | 0 | 0 |
| `poly(max-constant=2, max-coefficient=2, symbols=5, arity=5)` | 2 | 2 | 0 | 0 |
| `poly(max-constant=2, max-coefficient=2, symbols=6, arity=4)` | 2 | 2 | 0 | 0 |
| `poly(max-constant=2, max-coefficient=2, symbols=8, arity=6)` | 2 | 2 | 0 | 0 |
| `poly(max-constant=20, max-coefficient=20, symbols=6, arity=1)` | 2 | 2 | 0 | 0 |
| `poly(max-constant=209, max-coefficient=209, symbols=6, arity=1)` | 2 | 2 | 0 | 0 |
| `poly(max-constant=21, max-coefficient=21, symbols=4, arity=2)` | 2 | 2 | 0 | 0 |
| `poly(max-constant=26, max-coefficient=26, symbols=5, arity=1)` | 2 | 2 | 0 | 0 |
| `poly(max-constant=26, max-coefficient=26, symbols=6, arity=1)` | 2 | 2 | 0 | 0 |
| `poly(max-constant=27, max-coefficient=27, symbols=3, arity=1)` | 2 | 2 | 0 | 0 |
| `poly(max-constant=274, max-coefficient=274, symbols=3, arity=1)` | 2 | 2 | 0 | 0 |
| `poly(max-constant=286, max-coefficient=286, symbols=6, arity=1)` | 2 | 2 | 0 | 0 |
| `poly(max-constant=3, max-coefficient=3, symbols=1, arity=1)` | 2 | 2 | 0 | 0 |
| `poly(max-constant=3, max-coefficient=3, symbols=11, arity=5)` | 2 | 2 | 0 | 0 |
| `poly(max-constant=3, max-coefficient=3, symbols=14, arity=4)` | 2 | 2 | 0 | 0 |
| `poly(max-constant=3, max-coefficient=3, symbols=2, arity=0)` | 2 | 2 | 0 | 0 |
| `poly(max-constant=3, max-coefficient=3, symbols=22, arity=3)` | 2 | 2 | 0 | 0 |
| `poly(max-constant=3, max-coefficient=3, symbols=23, arity=3)` | 2 | 2 | 0 | 0 |
| `poly(max-constant=3, max-coefficient=3, symbols=25, arity=3)` | 2 | 2 | 0 | 0 |
| `poly(max-constant=3, max-coefficient=3, symbols=27, arity=3)` | 2 | 2 | 0 | 0 |
| `poly(max-constant=3, max-coefficient=3, symbols=28, arity=2)` | 2 | 2 | 0 | 0 |
| `poly(max-constant=3, max-coefficient=3, symbols=3, arity=0)` | 2 | 2 | 0 | 0 |
| `poly(max-constant=3, max-coefficient=3, symbols=31, arity=2)` | 2 | 2 | 0 | 0 |
| `poly(max-constant=3, max-coefficient=3, symbols=32, arity=2)` | 2 | 2 | 0 | 0 |
| `poly(max-constant=3, max-coefficient=3, symbols=35, arity=3)` | 2 | 1 | 1 | 0 |
| `poly(max-constant=3, max-coefficient=3, symbols=37, arity=3)` | 2 | 2 | 0 | 0 |
| `poly(max-constant=3, max-coefficient=3, symbols=41, arity=3)` | 2 | 2 | 0 | 0 |
| `poly(max-constant=3, max-coefficient=3, symbols=48, arity=3)` | 2 | 2 | 0 | 0 |
| `poly(max-constant=3, max-coefficient=3, symbols=50, arity=3)` | 2 | 2 | 0 | 0 |
| `poly(max-constant=3, max-coefficient=3, symbols=52, arity=3)` | 2 | 2 | 0 | 0 |
| `poly(max-constant=3, max-coefficient=3, symbols=54, arity=3)` | 2 | 2 | 0 | 0 |
| `poly(max-constant=3, max-coefficient=3, symbols=6, arity=0)` | 2 | 2 | 0 | 0 |
| `poly(max-constant=3, max-coefficient=3, symbols=6, arity=4)` | 2 | 2 | 0 | 0 |
| `poly(max-constant=3, max-coefficient=3, symbols=8, arity=5)` | 2 | 2 | 0 | 0 |
| `poly(max-constant=31, max-coefficient=31, symbols=6, arity=1)` | 2 | 2 | 0 | 0 |
| `poly(max-constant=36, max-coefficient=36, symbols=2, arity=1)` | 2 | 2 | 0 | 0 |
| `poly(max-constant=37, max-coefficient=37, symbols=6, arity=1)` | 2 | 2 | 0 | 0 |
| `poly(max-constant=4, max-coefficient=4, symbols=1, arity=2)` | 2 | 2 | 0 | 0 |
| `poly(max-constant=4, max-coefficient=4, symbols=14, arity=6)` | 2 | 2 | 0 | 0 |
| `poly(max-constant=4, max-coefficient=4, symbols=20, arity=2)` | 2 | 2 | 0 | 0 |
| `poly(max-constant=4, max-coefficient=4, symbols=22, arity=3)` | 2 | 2 | 0 | 0 |
| `poly(max-constant=4, max-coefficient=4, symbols=3, arity=3)` | 2 | 2 | 0 | 0 |
| `poly(max-constant=4, max-coefficient=4, symbols=9, arity=1)` | 2 | 2 | 0 | 0 |
| `poly(max-constant=40, max-coefficient=40, symbols=6, arity=1)` | 2 | 2 | 0 | 0 |
| `poly(max-constant=422, max-coefficient=422, symbols=5, arity=1)` | 2 | 2 | 0 | 0 |
| `poly(max-constant=46, max-coefficient=46, symbols=6, arity=1)` | 2 | 2 | 0 | 0 |
| `poly(max-constant=49, max-coefficient=49, symbols=4, arity=1)` | 2 | 2 | 0 | 0 |
| `poly(max-constant=5, max-coefficient=5, symbols=21, arity=2)` | 2 | 2 | 0 | 0 |
| `poly(max-constant=5, max-coefficient=5, symbols=28, arity=2)` | 2 | 2 | 0 | 0 |
| `poly(max-constant=59, max-coefficient=59, symbols=3, arity=1)` | 2 | 2 | 0 | 0 |
| `poly(max-constant=6, max-coefficient=6, symbols=12, arity=3)` | 2 | 2 | 0 | 0 |
| `poly(max-constant=6, max-coefficient=6, symbols=17, arity=2)` | 2 | 2 | 0 | 0 |
| `poly(max-constant=6, max-coefficient=6, symbols=20, arity=3)` | 2 | 2 | 0 | 0 |
| `poly(max-constant=6, max-coefficient=6, symbols=30, arity=5)` | 2 | 2 | 0 | 0 |
| `poly(max-constant=6, max-coefficient=6, symbols=9, arity=1)` | 2 | 2 | 0 | 0 |
| `poly(max-constant=7, max-coefficient=7, symbols=12, arity=3)` | 2 | 2 | 0 | 0 |
| `poly(max-constant=7, max-coefficient=7, symbols=17, arity=3)` | 2 | 2 | 0 | 0 |
| `poly(max-constant=7, max-coefficient=7, symbols=20, arity=2)` | 2 | 2 | 0 | 0 |
| `poly(max-constant=7, max-coefficient=7, symbols=20, arity=3)` | 2 | 2 | 0 | 0 |
| `poly(max-constant=7, max-coefficient=7, symbols=30, arity=2)` | 2 | 2 | 0 | 0 |
| `poly(max-constant=7, max-coefficient=7, symbols=7, arity=1)` | 2 | 2 | 0 | 0 |
| `poly(max-constant=70, max-coefficient=70, symbols=5, arity=1)` | 2 | 2 | 0 | 0 |
| `poly(max-constant=8, max-coefficient=8, symbols=10, arity=3)` | 2 | 2 | 0 | 0 |
| `poly(max-constant=8, max-coefficient=8, symbols=13, arity=3)` | 2 | 2 | 0 | 0 |
| `poly(max-constant=8, max-coefficient=8, symbols=16, arity=2)` | 2 | 2 | 0 | 0 |
| `poly(max-constant=8, max-coefficient=8, symbols=18, arity=3)` | 2 | 2 | 0 | 0 |
| `poly(max-constant=8, max-coefficient=8, symbols=27, arity=2)` | 2 | 2 | 0 | 0 |
| `poly(max-constant=8, max-coefficient=8, symbols=36, arity=3)` | 2 | 2 | 0 | 0 |
| `poly(max-constant=8, max-coefficient=8, symbols=7, arity=3)` | 2 | 2 | 0 | 0 |
| `poly(max-constant=8, max-coefficient=8, symbols=9, arity=3)` | 2 | 2 | 0 | 0 |
| `poly(max-constant=85, max-coefficient=85, symbols=4, arity=1)` | 2 | 2 | 0 | 0 |
| `poly(max-constant=9, max-coefficient=9, symbols=12, arity=3)` | 2 | 1 | 0 | 1 |
| `kbo(weight=0, symbols=10)` | 1 | 1 | 0 | 0 |
| `kbo(weight=0, symbols=13)` | 1 | 1 | 0 | 0 |
| `kbo(weight=0, symbols=15)` | 1 | 1 | 0 | 0 |
| `kbo(weight=0, symbols=4)` | 1 | 1 | 0 | 0 |
| `kbo(weight=0, symbols=9)` | 1 | 1 | 0 | 0 |
| `kbo(weight=1, symbols=13)` | 1 | 1 | 0 | 0 |
| `kbo(weight=1, symbols=19)` | 1 | 1 | 0 | 0 |
| `kbo(weight=1, symbols=23)` | 1 | 1 | 0 | 0 |
| `kbo(weight=1, symbols=28)` | 1 | 1 | 0 | 0 |
| `kbo(weight=2, symbols=12)` | 1 | 0 | 1 | 0 |
| `kbo(weight=2, symbols=15)` | 1 | 1 | 0 | 0 |
| `kbo(weight=2, symbols=19)` | 1 | 1 | 0 | 0 |
| `kbo(weight=2, symbols=22)` | 1 | 1 | 0 | 0 |
| `kbo(weight=2, symbols=23)` | 1 | 1 | 0 | 0 |
| `kbo(weight=2, symbols=24)` | 1 | 1 | 0 | 0 |
| `kbo(weight=2, symbols=27)` | 1 | 1 | 0 | 0 |
| `kbo(weight=2, symbols=28)` | 1 | 0 | 0 | 1 |
| `kbo(weight=2, symbols=29)` | 1 | 1 | 0 | 0 |
| `kbo(weight=2, symbols=35)` | 1 | 1 | 0 | 0 |
| `kbo(weight=2, symbols=37)` | 1 | 1 | 0 | 0 |
| `kbo(weight=2, symbols=39)` | 1 | 1 | 0 | 0 |
| `kbo(weight=2, symbols=47)` | 1 | 1 | 0 | 0 |
| `kbo(weight=2, symbols=54)` | 1 | 1 | 0 | 0 |
| `kbo(weight=22, symbols=3)` | 1 | 1 | 0 | 0 |
| `kbo(weight=23, symbols=3)` | 1 | 1 | 0 | 0 |
| `kbo(weight=28, symbols=3)` | 1 | 1 | 0 | 0 |
| `kbo(weight=3, symbols=16)` | 1 | 1 | 0 | 0 |
| `kbo(weight=3, symbols=18)` | 1 | 1 | 0 | 0 |
| `kbo(weight=3, symbols=5)` | 1 | 1 | 0 | 0 |
| `kbo(weight=4, symbols=11)` | 1 | 1 | 0 | 0 |
| `kbo(weight=4, symbols=29)` | 1 | 1 | 0 | 0 |
| `kbo(weight=4, symbols=31)` | 1 | 1 | 0 | 0 |
| `kbo(weight=43, symbols=3)` | 1 | 1 | 0 | 0 |
| `kbo(weight=5, symbols=18)` | 1 | 1 | 0 | 0 |
| `kbo(weight=5, symbols=23)` | 1 | 1 | 0 | 0 |
| `kbo(weight=5, symbols=4)` | 1 | 1 | 0 | 0 |
| `kbo(weight=6, symbols=2)` | 1 | 1 | 0 | 0 |
| `kbo(weight=6, symbols=8)` | 1 | 1 | 0 | 0 |
| `kbo(weight=6, symbols=9)` | 1 | 1 | 0 | 0 |
| `kbo(weight=7, symbols=13)` | 1 | 1 | 0 | 0 |
| `kbo(weight=8, symbols=7)` | 1 | 1 | 0 | 0 |
| `kbo(weight=9, symbols=22)` | 1 | 1 | 0 | 0 |
| `matrix(max-constant=0, max-coefficient=1, symbols=12, arity=1, dim=1)` | 1 | 1 | 0 | 0 |
| `matrix(max-constant=1, max-coefficient=1, symbols=10, arity=2, dim=4)` | 1 | 1 | 0 | 0 |
| `matrix(max-constant=1, max-coefficient=1, symbols=10, arity=3, dim=4)` | 1 | 1 | 0 | 0 |
| `matrix(max-constant=1, max-coefficient=1, symbols=16, arity=2, dim=3)` | 1 | 1 | 0 | 0 |
| `matrix(max-constant=1, max-coefficient=1, symbols=26, arity=3, dim=3)` | 1 | 1 | 0 | 0 |
| `matrix(max-constant=1, max-coefficient=1, symbols=5, arity=1, dim=6)` | 1 | 1 | 0 | 0 |
| `matrix(max-constant=1, max-coefficient=1, symbols=6, arity=1, dim=4)` | 1 | 1 | 0 | 0 |
| `matrix(max-constant=1, max-coefficient=1, symbols=6, arity=3, dim=5)` | 1 | 1 | 0 | 0 |
| `matrix(max-constant=1, max-coefficient=1, symbols=8, arity=1, dim=2)` | 1 | 1 | 0 | 0 |
| `matrix(max-constant=1, max-coefficient=1, symbols=9, arity=2, dim=2)` | 1 | 1 | 0 | 0 |
| `matrix(max-constant=10, max-coefficient=10, symbols=2, arity=1, dim=4)` | 1 | 0 | 1 | 0 |
| `matrix(max-constant=11, max-coefficient=11, symbols=2, arity=1, dim=6)` | 1 | 1 | 0 | 0 |
| `matrix(max-constant=11, max-coefficient=11, symbols=4, arity=1, dim=5)` | 1 | 1 | 0 | 0 |
| `matrix(max-constant=11, max-coefficient=11, symbols=5, arity=1, dim=3)` | 1 | 1 | 0 | 0 |
| `matrix(max-constant=11, max-coefficient=11, symbols=6, arity=1, dim=3)` | 1 | 1 | 0 | 0 |
| `matrix(max-constant=12, max-coefficient=12, symbols=11, arity=1, dim=3)` | 1 | 1 | 0 | 0 |
| `matrix(max-constant=12, max-coefficient=12, symbols=2, arity=1, dim=4)` | 1 | 1 | 0 | 0 |
| `matrix(max-constant=12, max-coefficient=12, symbols=2, arity=1, dim=5)` | 1 | 1 | 0 | 0 |
| `matrix(max-constant=12, max-coefficient=12, symbols=3, arity=1, dim=2)` | 1 | 1 | 0 | 0 |
| `matrix(max-constant=12, max-coefficient=12, symbols=3, arity=1, dim=5)` | 1 | 1 | 0 | 0 |
| `matrix(max-constant=12, max-coefficient=12, symbols=5, arity=1, dim=3)` | 1 | 1 | 0 | 0 |
| `matrix(max-constant=12, max-coefficient=12, symbols=7, arity=1, dim=5)` | 1 | 1 | 0 | 0 |
| `matrix(max-constant=12, max-coefficient=12, symbols=8, arity=1, dim=3)` | 1 | 1 | 0 | 0 |
| `matrix(max-constant=13, max-coefficient=13, symbols=3, arity=1, dim=4)` | 1 | 1 | 0 | 0 |
| `matrix(max-constant=13, max-coefficient=13, symbols=3, arity=1, dim=5)` | 1 | 1 | 0 | 0 |
| `matrix(max-constant=14, max-coefficient=14, symbols=2, arity=1, dim=4)` | 1 | 1 | 0 | 0 |
| `matrix(max-constant=14, max-coefficient=14, symbols=2, arity=1, dim=7)` | 1 | 1 | 0 | 0 |
| `matrix(max-constant=14, max-coefficient=14, symbols=3, arity=1, dim=2)` | 1 | 1 | 0 | 0 |
| `matrix(max-constant=14, max-coefficient=14, symbols=6, arity=1, dim=3)` | 1 | 1 | 0 | 0 |
| `matrix(max-constant=14, max-coefficient=14, symbols=7, arity=1, dim=3)` | 1 | 1 | 0 | 0 |
| `matrix(max-constant=14, max-coefficient=14, symbols=8, arity=1, dim=3)` | 1 | 1 | 0 | 0 |
| `matrix(max-constant=15, max-coefficient=15, symbols=4, arity=1, dim=3)` | 1 | 1 | 0 | 0 |
| `matrix(max-constant=15, max-coefficient=15, symbols=5, arity=1, dim=3)` | 1 | 0 | 0 | 1 |
| `matrix(max-constant=16, max-coefficient=16, symbols=4, arity=1, dim=2)` | 1 | 1 | 0 | 0 |
| `matrix(max-constant=16, max-coefficient=16, symbols=4, arity=1, dim=3)` | 1 | 1 | 0 | 0 |
| `matrix(max-constant=16, max-coefficient=16, symbols=4, arity=1, dim=5)` | 1 | 0 | 1 | 0 |
| `matrix(max-constant=16, max-coefficient=16, symbols=4, arity=3, dim=4)` | 1 | 1 | 0 | 0 |
| `matrix(max-constant=16, max-coefficient=16, symbols=6, arity=1, dim=3)` | 1 | 1 | 0 | 0 |
| `matrix(max-constant=16, max-coefficient=16, symbols=6, arity=3, dim=5)` | 1 | 1 | 0 | 0 |
| `matrix(max-constant=16, max-coefficient=16, symbols=7, arity=1, dim=3)` | 1 | 1 | 0 | 0 |
| `matrix(max-constant=16, max-coefficient=16, symbols=7, arity=2, dim=4)` | 1 | 1 | 0 | 0 |
| `matrix(max-constant=16, max-coefficient=16, symbols=8, arity=1, dim=3)` | 1 | 1 | 0 | 0 |
| `matrix(max-constant=17, max-coefficient=17, symbols=2, arity=1, dim=5)` | 1 | 1 | 0 | 0 |
| `matrix(max-constant=17, max-coefficient=17, symbols=2, arity=1, dim=6)` | 1 | 1 | 0 | 0 |
| `matrix(max-constant=17, max-coefficient=17, symbols=3, arity=1, dim=2)` | 1 | 1 | 0 | 0 |
| `matrix(max-constant=17, max-coefficient=17, symbols=4, arity=1, dim=3)` | 1 | 1 | 0 | 0 |
| `matrix(max-constant=17, max-coefficient=17, symbols=8, arity=1, dim=3)` | 1 | 1 | 0 | 0 |
| `matrix(max-constant=18, max-coefficient=18, symbols=2, arity=1, dim=5)` | 1 | 1 | 0 | 0 |
| `matrix(max-constant=18, max-coefficient=18, symbols=4, arity=1, dim=3)` | 1 | 1 | 0 | 0 |
| `matrix(max-constant=18, max-coefficient=18, symbols=6, arity=2, dim=3)` | 1 | 1 | 0 | 0 |
| `matrix(max-constant=18, max-coefficient=18, symbols=8, arity=1, dim=3)` | 1 | 1 | 0 | 0 |
| `matrix(max-constant=19, max-coefficient=19, symbols=2, arity=1, dim=3)` | 1 | 1 | 0 | 0 |
| `matrix(max-constant=19, max-coefficient=19, symbols=2, arity=1, dim=4)` | 1 | 1 | 0 | 0 |
| `matrix(max-constant=19, max-coefficient=19, symbols=3, arity=1, dim=4)` | 1 | 1 | 0 | 0 |
| `matrix(max-constant=19, max-coefficient=19, symbols=3, arity=1, dim=5)` | 1 | 1 | 0 | 0 |
| `matrix(max-constant=19, max-coefficient=19, symbols=4, arity=1, dim=3)` | 1 | 1 | 0 | 0 |
| `matrix(max-constant=19, max-coefficient=19, symbols=6, arity=1, dim=4)` | 1 | 1 | 0 | 0 |
| `matrix(max-constant=2, max-coefficient=2, symbols=11, arity=1, dim=2)` | 1 | 1 | 0 | 0 |
| `matrix(max-constant=2, max-coefficient=2, symbols=11, arity=3, dim=3)` | 1 | 1 | 0 | 0 |
| `matrix(max-constant=2, max-coefficient=2, symbols=17, arity=2, dim=3)` | 1 | 1 | 0 | 0 |
| `matrix(max-constant=2, max-coefficient=2, symbols=2, arity=2, dim=4)` | 1 | 1 | 0 | 0 |
| `matrix(max-constant=2, max-coefficient=2, symbols=3, arity=1, dim=7)` | 1 | 1 | 0 | 0 |
| `matrix(max-constant=2, max-coefficient=2, symbols=4, arity=2, dim=4)` | 1 | 1 | 0 | 0 |
| `matrix(max-constant=2, max-coefficient=2, symbols=4, arity=3, dim=4)` | 1 | 1 | 0 | 0 |
| `matrix(max-constant=2, max-coefficient=2, symbols=5, arity=3, dim=2)` | 1 | 1 | 0 | 0 |
| `matrix(max-constant=2, max-coefficient=2, symbols=8, arity=3, dim=3)` | 1 | 1 | 0 | 0 |
| `matrix(max-constant=2, max-coefficient=2, symbols=9, arity=2, dim=2)` | 1 | 1 | 0 | 0 |
| `matrix(max-constant=20, max-coefficient=20, symbols=3, arity=1, dim=2)` | 1 | 1 | 0 | 0 |
| `matrix(max-constant=20, max-coefficient=20, symbols=5, arity=1, dim=3)` | 1 | 1 | 0 | 0 |
| `matrix(max-constant=20, max-coefficient=20, symbols=8, arity=1, dim=5)` | 1 | 1 | 0 | 0 |
| `matrix(max-constant=21, max-coefficient=21, symbols=2, arity=1, dim=3)` | 1 | 1 | 0 | 0 |
| `matrix(max-constant=21, max-coefficient=21, symbols=4, arity=1, dim=3)` | 1 | 1 | 0 | 0 |
| `matrix(max-constant=22, max-coefficient=22, symbols=4, arity=1, dim=3)` | 1 | 1 | 0 | 0 |
| `matrix(max-constant=22, max-coefficient=22, symbols=6, arity=1, dim=3)` | 1 | 1 | 0 | 0 |
| `matrix(max-constant=23, max-coefficient=23, symbols=2, arity=1, dim=2)` | 1 | 1 | 0 | 0 |
| `matrix(max-constant=23, max-coefficient=23, symbols=2, arity=1, dim=4)` | 1 | 1 | 0 | 0 |
| `matrix(max-constant=23, max-coefficient=23, symbols=2, arity=1, dim=7)` | 1 | 1 | 0 | 0 |
| `matrix(max-constant=23, max-coefficient=23, symbols=3, arity=1, dim=2)` | 1 | 1 | 0 | 0 |
| `matrix(max-constant=23, max-coefficient=23, symbols=6, arity=1, dim=3)` | 1 | 1 | 0 | 0 |
| `matrix(max-constant=23, max-coefficient=23, symbols=7, arity=1, dim=5)` | 1 | 1 | 0 | 0 |
| `matrix(max-constant=24, max-coefficient=24, symbols=7, arity=1, dim=3)` | 1 | 1 | 0 | 0 |
| `matrix(max-constant=25, max-coefficient=25, symbols=3, arity=1, dim=5)` | 1 | 1 | 0 | 0 |
| `matrix(max-constant=26, max-coefficient=26, symbols=2, arity=1, dim=7)` | 1 | 1 | 0 | 0 |
| `matrix(max-constant=26, max-coefficient=26, symbols=3, arity=1, dim=3)` | 1 | 1 | 0 | 0 |
| `matrix(max-constant=26, max-coefficient=26, symbols=3, arity=3, dim=4)` | 1 | 1 | 0 | 0 |
| `matrix(max-constant=26, max-coefficient=26, symbols=6, arity=1, dim=5)` | 1 | 1 | 0 | 0 |
| `matrix(max-constant=27, max-coefficient=27, symbols=2, arity=1, dim=5)` | 1 | 1 | 0 | 0 |
| `matrix(max-constant=28, max-coefficient=28, symbols=2, arity=1, dim=3)` | 1 | 1 | 0 | 0 |
| `matrix(max-constant=28, max-coefficient=28, symbols=3, arity=1, dim=3)` | 1 | 1 | 0 | 0 |
| `matrix(max-constant=28, max-coefficient=28, symbols=3, arity=1, dim=5)` | 1 | 1 | 0 | 0 |
| `matrix(max-constant=29, max-coefficient=29, symbols=2, arity=1, dim=7)` | 1 | 1 | 0 | 0 |
| `matrix(max-constant=3, max-coefficient=3, symbols=11, arity=3, dim=1)` | 1 | 1 | 0 | 0 |
| `matrix(max-constant=3, max-coefficient=3, symbols=12, arity=2, dim=1)` | 1 | 1 | 0 | 0 |
| `matrix(max-constant=3, max-coefficient=3, symbols=12, arity=2, dim=3)` | 1 | 1 | 0 | 0 |
| `matrix(max-constant=3, max-coefficient=3, symbols=12, arity=3, dim=3)` | 1 | 1 | 0 | 0 |
| `matrix(max-constant=3, max-coefficient=3, symbols=15, arity=2, dim=1)` | 1 | 1 | 0 | 0 |
| `matrix(max-constant=3, max-coefficient=3, symbols=15, arity=2, dim=2)` | 1 | 1 | 0 | 0 |
| `matrix(max-constant=3, max-coefficient=3, symbols=15, arity=2, dim=3)` | 1 | 1 | 0 | 0 |
| `matrix(max-constant=3, max-coefficient=3, symbols=16, arity=2, dim=3)` | 1 | 1 | 0 | 0 |
| `matrix(max-constant=3, max-coefficient=3, symbols=19, arity=3, dim=1)` | 1 | 1 | 0 | 0 |
| `matrix(max-constant=3, max-coefficient=3, symbols=8, arity=2, dim=3)` | 1 | 1 | 0 | 0 |
| `matrix(max-constant=3, max-coefficient=3, symbols=8, arity=2, dim=5)` | 1 | 1 | 0 | 0 |
| `matrix(max-constant=3, max-coefficient=3, symbols=8, arity=3, dim=1)` | 1 | 1 | 0 | 0 |
| `matrix(max-constant=31, max-coefficient=31, symbols=3, arity=1, dim=4)` | 1 | 1 | 0 | 0 |
| `matrix(max-constant=32, max-coefficient=32, symbols=2, arity=1, dim=5)` | 1 | 1 | 0 | 0 |
| `matrix(max-constant=32, max-coefficient=32, symbols=2, arity=1, dim=7)` | 1 | 1 | 0 | 0 |
| `matrix(max-constant=32, max-coefficient=32, symbols=3, arity=1, dim=2)` | 1 | 1 | 0 | 0 |
| `matrix(max-constant=34, max-coefficient=34, symbols=2, arity=1, dim=5)` | 1 | 1 | 0 | 0 |
| `matrix(max-constant=34, max-coefficient=34, symbols=2, arity=1, dim=7)` | 1 | 1 | 0 | 0 |
| `matrix(max-constant=35, max-coefficient=35, symbols=2, arity=1, dim=5)` | 1 | 1 | 0 | 0 |
| `matrix(max-constant=36, max-coefficient=36, symbols=2, arity=1, dim=7)` | 1 | 1 | 0 | 0 |
| `matrix(max-constant=36, max-coefficient=36, symbols=3, arity=1, dim=5)` | 1 | 1 | 0 | 0 |
| `matrix(max-constant=36, max-coefficient=36, symbols=4, arity=1, dim=5)` | 1 | 1 | 0 | 0 |
| `matrix(max-constant=36, max-coefficient=36, symbols=6, arity=1, dim=5)` | 1 | 1 | 0 | 0 |
| `matrix(max-constant=38, max-coefficient=38, symbols=2, arity=1, dim=7)` | 1 | 1 | 0 | 0 |
| `matrix(max-constant=38, max-coefficient=38, symbols=3, arity=1, dim=5)` | 1 | 1 | 0 | 0 |
| `matrix(max-constant=39, max-coefficient=39, symbols=5, arity=1, dim=3)` | 1 | 1 | 0 | 0 |
| `matrix(max-constant=39, max-coefficient=39, symbols=6, arity=1, dim=5)` | 1 | 1 | 0 | 0 |
| `matrix(max-constant=4, max-coefficient=4, symbols=10, arity=2, dim=4)` | 1 | 1 | 0 | 0 |
| `matrix(max-constant=4, max-coefficient=4, symbols=11, arity=3, dim=3)` | 1 | 1 | 0 | 0 |
| `matrix(max-constant=4, max-coefficient=4, symbols=16, arity=2, dim=3)` | 1 | 1 | 0 | 0 |
| `matrix(max-constant=4, max-coefficient=4, symbols=17, arity=4, dim=1)` | 1 | 1 | 0 | 0 |
| `matrix(max-constant=4, max-coefficient=4, symbols=2, arity=2, dim=3)` | 1 | 1 | 0 | 0 |
| `matrix(max-constant=4, max-coefficient=4, symbols=28, arity=4, dim=1)` | 1 | 1 | 0 | 0 |
| `matrix(max-constant=4, max-coefficient=4, symbols=4, arity=1, dim=1)` | 1 | 1 | 0 | 0 |
| `matrix(max-constant=4, max-coefficient=4, symbols=4, arity=3, dim=2)` | 1 | 1 | 0 | 0 |
| `matrix(max-constant=4, max-coefficient=4, symbols=4, arity=3, dim=4)` | 1 | 1 | 0 | 0 |
| `matrix(max-constant=4, max-coefficient=4, symbols=5, arity=1, dim=5)` | 1 | 1 | 0 | 0 |
| `matrix(max-constant=4, max-coefficient=4, symbols=6, arity=1, dim=1)` | 1 | 1 | 0 | 0 |
| `matrix(max-constant=4, max-coefficient=4, symbols=7, arity=1, dim=1)` | 1 | 1 | 0 | 0 |
| `matrix(max-constant=4, max-coefficient=4, symbols=7, arity=3, dim=1)` | 1 | 1 | 0 | 0 |
| `matrix(max-constant=4, max-coefficient=4, symbols=9, arity=1, dim=3)` | 1 | 1 | 0 | 0 |
| `matrix(max-constant=40, max-coefficient=40, symbols=5, arity=1, dim=5)` | 1 | 1 | 0 | 0 |
| `matrix(max-constant=40, max-coefficient=40, symbols=6, arity=1, dim=5)` | 1 | 1 | 0 | 0 |
| `matrix(max-constant=41, max-coefficient=41, symbols=2, arity=1, dim=6)` | 1 | 1 | 0 | 0 |
| `matrix(max-constant=41, max-coefficient=41, symbols=2, arity=1, dim=7)` | 1 | 1 | 0 | 0 |
| `matrix(max-constant=41, max-coefficient=41, symbols=4, arity=1, dim=5)` | 1 | 1 | 0 | 0 |
| `matrix(max-constant=42, max-coefficient=42, symbols=2, arity=1, dim=7)` | 1 | 1 | 0 | 0 |
| `matrix(max-constant=43, max-coefficient=43, symbols=5, arity=1, dim=5)` | 1 | 0 | 0 | 1 |
| `matrix(max-constant=43, max-coefficient=43, symbols=6, arity=1, dim=5)` | 1 | 1 | 0 | 0 |
| `matrix(max-constant=44, max-coefficient=44, symbols=2, arity=1, dim=7)` | 1 | 1 | 0 | 0 |
| `matrix(max-constant=44, max-coefficient=44, symbols=4, arity=1, dim=5)` | 1 | 1 | 0 | 0 |
| `matrix(max-constant=46, max-coefficient=46, symbols=2, arity=1, dim=7)` | 1 | 1 | 0 | 0 |
| `matrix(max-constant=47, max-coefficient=47, symbols=2, arity=1, dim=5)` | 1 | 0 | 1 | 0 |
| `matrix(max-constant=49, max-coefficient=49, symbols=2, arity=1, dim=5)` | 1 | 1 | 0 | 0 |
| `matrix(max-constant=5, max-coefficient=5, symbols=12, arity=3, dim=3)` | 1 | 0 | 0 | 1 |
| `matrix(max-constant=5, max-coefficient=5, symbols=13, arity=2, dim=3)` | 1 | 1 | 0 | 0 |
| `matrix(max-constant=5, max-coefficient=5, symbols=13, arity=4, dim=1)` | 1 | 1 | 0 | 0 |
| `matrix(max-constant=5, max-coefficient=5, symbols=2, arity=2, dim=2)` | 1 | 1 | 0 | 0 |
| `matrix(max-constant=5, max-coefficient=5, symbols=3, arity=1, dim=1)` | 1 | 1 | 0 | 0 |
| `matrix(max-constant=5, max-coefficient=5, symbols=3, arity=2, dim=2)` | 1 | 1 | 0 | 0 |
| `matrix(max-constant=5, max-coefficient=5, symbols=3, arity=2, dim=3)` | 1 | 1 | 0 | 0 |
| `matrix(max-constant=5, max-coefficient=5, symbols=3, arity=2, dim=4)` | 1 | 1 | 0 | 0 |
| `matrix(max-constant=5, max-coefficient=5, symbols=4, arity=1, dim=3)` | 1 | 1 | 0 | 0 |
| `matrix(max-constant=5, max-coefficient=5, symbols=4, arity=1, dim=5)` | 1 | 1 | 0 | 0 |
| `matrix(max-constant=5, max-coefficient=5, symbols=6, arity=3, dim=3)` | 1 | 1 | 0 | 0 |
| `matrix(max-constant=5, max-coefficient=5, symbols=8, arity=2, dim=1)` | 1 | 1 | 0 | 0 |
| `matrix(max-constant=5, max-coefficient=5, symbols=9, arity=3, dim=1)` | 1 | 1 | 0 | 0 |
| `matrix(max-constant=50, max-coefficient=50, symbols=2, arity=1, dim=5)` | 1 | 1 | 0 | 0 |
| `matrix(max-constant=50, max-coefficient=50, symbols=3, arity=1, dim=5)` | 1 | 1 | 0 | 0 |
| `matrix(max-constant=51, max-coefficient=51, symbols=3, arity=1, dim=5)` | 1 | 1 | 0 | 0 |
| `matrix(max-constant=52, max-coefficient=52, symbols=2, arity=1, dim=5)` | 1 | 1 | 0 | 0 |
| `matrix(max-constant=52, max-coefficient=52, symbols=3, arity=1, dim=5)` | 1 | 1 | 0 | 0 |
| `matrix(max-constant=55, max-coefficient=55, symbols=3, arity=1, dim=5)` | 1 | 1 | 0 | 0 |
| `matrix(max-constant=55, max-coefficient=55, symbols=5, arity=1, dim=5)` | 1 | 1 | 0 | 0 |
| `matrix(max-constant=57, max-coefficient=57, symbols=2, arity=1, dim=5)` | 1 | 1 | 0 | 0 |
| `matrix(max-constant=59, max-coefficient=59, symbols=2, arity=1, dim=5)` | 1 | 1 | 0 | 0 |
| `matrix(max-constant=59, max-coefficient=59, symbols=2, arity=1, dim=7)` | 1 | 1 | 0 | 0 |
| `matrix(max-constant=6, max-coefficient=6, symbols=2, arity=1, dim=4)` | 1 | 1 | 0 | 0 |
| `matrix(max-constant=6, max-coefficient=6, symbols=6, arity=2, dim=3)` | 1 | 1 | 0 | 0 |
| `matrix(max-constant=60, max-coefficient=60, symbols=2, arity=1, dim=5)` | 1 | 1 | 0 | 0 |
| `matrix(max-constant=60, max-coefficient=60, symbols=3, arity=1, dim=5)` | 1 | 1 | 0 | 0 |
| `matrix(max-constant=62, max-coefficient=62, symbols=5, arity=1, dim=5)` | 1 | 1 | 0 | 0 |
| `matrix(max-constant=63, max-coefficient=63, symbols=2, arity=1, dim=5)` | 1 | 1 | 0 | 0 |
| `matrix(max-constant=63, max-coefficient=63, symbols=7, arity=1, dim=5)` | 1 | 1 | 0 | 0 |
| `matrix(max-constant=64, max-coefficient=64, symbols=3, arity=1, dim=5)` | 1 | 1 | 0 | 0 |
| `matrix(max-constant=65, max-coefficient=65, symbols=2, arity=1, dim=5)` | 1 | 1 | 0 | 0 |
| `matrix(max-constant=65, max-coefficient=65, symbols=3, arity=1, dim=5)` | 1 | 1 | 0 | 0 |
| `matrix(max-constant=67, max-coefficient=67, symbols=2, arity=1, dim=5)` | 1 | 1 | 0 | 0 |
| `matrix(max-constant=67, max-coefficient=67, symbols=3, arity=1, dim=5)` | 1 | 1 | 0 | 0 |
| `matrix(max-constant=7, max-coefficient=7, symbols=2, arity=1, dim=6)` | 1 | 1 | 0 | 0 |
| `matrix(max-constant=7, max-coefficient=7, symbols=3, arity=1, dim=4)` | 1 | 1 | 0 | 0 |
| `matrix(max-constant=7, max-coefficient=7, symbols=3, arity=1, dim=5)` | 1 | 1 | 0 | 0 |
| `matrix(max-constant=7, max-coefficient=7, symbols=4, arity=1, dim=3)` | 1 | 1 | 0 | 0 |
| `matrix(max-constant=7, max-coefficient=7, symbols=6, arity=2, dim=3)` | 1 | 1 | 0 | 0 |
| `matrix(max-constant=7, max-coefficient=7, symbols=6, arity=3, dim=2)` | 1 | 1 | 0 | 0 |
| `matrix(max-constant=7, max-coefficient=7, symbols=7, arity=1, dim=3)` | 1 | 1 | 0 | 0 |
| `matrix(max-constant=70, max-coefficient=70, symbols=2, arity=1, dim=5)` | 1 | 1 | 0 | 0 |
| `matrix(max-constant=70, max-coefficient=70, symbols=3, arity=1, dim=5)` | 1 | 1 | 0 | 0 |
| `matrix(max-constant=71, max-coefficient=71, symbols=3, arity=1, dim=5)` | 1 | 1 | 0 | 0 |
| `matrix(max-constant=73, max-coefficient=73, symbols=2, arity=1, dim=5)` | 1 | 1 | 0 | 0 |
| `matrix(max-constant=75, max-coefficient=75, symbols=2, arity=1, dim=5)` | 1 | 1 | 0 | 0 |
| `matrix(max-constant=75, max-coefficient=75, symbols=6, arity=1, dim=5)` | 1 | 1 | 0 | 0 |
| `matrix(max-constant=76, max-coefficient=76, symbols=2, arity=1, dim=5)` | 1 | 1 | 0 | 0 |
| `matrix(max-constant=77, max-coefficient=77, symbols=2, arity=1, dim=5)` | 1 | 1 | 0 | 0 |
| `matrix(max-constant=77, max-coefficient=77, symbols=3, arity=1, dim=5)` | 1 | 1 | 0 | 0 |
| `matrix(max-constant=78, max-coefficient=78, symbols=8, arity=1, dim=5)` | 1 | 1 | 0 | 0 |
| `matrix(max-constant=8, max-coefficient=8, symbols=13, arity=2, dim=3)` | 1 | 1 | 0 | 0 |
| `matrix(max-constant=8, max-coefficient=8, symbols=2, arity=1, dim=2)` | 1 | 1 | 0 | 0 |
| `matrix(max-constant=8, max-coefficient=8, symbols=6, arity=2, dim=3)` | 1 | 1 | 0 | 0 |
| `matrix(max-constant=89, max-coefficient=89, symbols=2, arity=1, dim=7)` | 1 | 1 | 0 | 0 |
| `matrix(max-constant=9, max-coefficient=9, symbols=4, arity=1, dim=5)` | 1 | 1 | 0 | 0 |
| `poly(max-constant=0, max-coefficient=1, symbols=5, arity=1)` | 1 | 1 | 0 | 0 |
| `poly(max-constant=0, max-coefficient=1, symbols=5, arity=3)` | 1 | 1 | 0 | 0 |
| `poly(max-constant=0, max-coefficient=1, symbols=6, arity=3)` | 1 | 1 | 0 | 0 |
| `poly(max-constant=1, max-coefficient=1, symbols=10, arity=5)` | 1 | 1 | 0 | 0 |
| `poly(max-constant=1, max-coefficient=1, symbols=12, arity=4)` | 1 | 1 | 0 | 0 |
| `poly(max-constant=1, max-coefficient=1, symbols=13, arity=5)` | 1 | 1 | 0 | 0 |
| `poly(max-constant=1, max-coefficient=1, symbols=14, arity=5)` | 1 | 1 | 0 | 0 |
| `poly(max-constant=1, max-coefficient=1, symbols=22, arity=2)` | 1 | 1 | 0 | 0 |
| `poly(max-constant=1, max-coefficient=1, symbols=24, arity=2)` | 1 | 1 | 0 | 0 |
| `poly(max-constant=1, max-coefficient=1, symbols=28, arity=2)` | 1 | 1 | 0 | 0 |
| `poly(max-constant=1, max-coefficient=1, symbols=38, arity=3)` | 1 | 1 | 0 | 0 |
| `poly(max-constant=1, max-coefficient=1, symbols=48, arity=4)` | 1 | 1 | 0 | 0 |
| `poly(max-constant=1, max-coefficient=1, symbols=5, arity=4)` | 1 | 1 | 0 | 0 |
| `poly(max-constant=1, max-coefficient=1, symbols=7, arity=5)` | 1 | 1 | 0 | 0 |
| `poly(max-constant=1, max-coefficient=1, symbols=8, arity=5)` | 1 | 1 | 0 | 0 |
| `poly(max-constant=10, max-coefficient=10, symbols=17, arity=2)` | 1 | 1 | 0 | 0 |
| `poly(max-constant=10, max-coefficient=10, symbols=2, arity=2)` | 1 | 1 | 0 | 0 |
| `poly(max-constant=10, max-coefficient=10, symbols=20, arity=3)` | 1 | 1 | 0 | 0 |
| `poly(max-constant=10, max-coefficient=10, symbols=21, arity=3)` | 1 | 1 | 0 | 0 |
| `poly(max-constant=10, max-coefficient=10, symbols=23, arity=3)` | 1 | 1 | 0 | 0 |
| `poly(max-constant=10, max-coefficient=10, symbols=25, arity=3)` | 1 | 1 | 0 | 0 |
| `poly(max-constant=10, max-coefficient=10, symbols=26, arity=3)` | 1 | 1 | 0 | 0 |
| `poly(max-constant=10, max-coefficient=10, symbols=27, arity=3)` | 1 | 1 | 0 | 0 |
| `poly(max-constant=11, max-coefficient=11, symbols=9, arity=3)` | 1 | 1 | 0 | 0 |
| `poly(max-constant=12, max-coefficient=12, symbols=3, arity=1)` | 1 | 1 | 0 | 0 |
| `poly(max-constant=12, max-coefficient=12, symbols=7, arity=3)` | 1 | 1 | 0 | 0 |
| `poly(max-constant=12, max-coefficient=12, symbols=8, arity=1)` | 1 | 1 | 0 | 0 |
| `poly(max-constant=13, max-coefficient=13, symbols=2, arity=2)` | 1 | 1 | 0 | 0 |
| `poly(max-constant=14, max-coefficient=14, symbols=14, arity=6)` | 1 | 1 | 0 | 0 |
| `poly(max-constant=14, max-coefficient=14, symbols=7, arity=1)` | 1 | 1 | 0 | 0 |
| `poly(max-constant=15, max-coefficient=15, symbols=6, arity=1)` | 1 | 1 | 0 | 0 |
| `poly(max-constant=16, max-coefficient=16, symbols=10, arity=4)` | 1 | 1 | 0 | 0 |
| `poly(max-constant=16, max-coefficient=16, symbols=5, arity=2)` | 1 | 1 | 0 | 0 |
| `poly(max-constant=16, max-coefficient=16, symbols=6, arity=3)` | 1 | 1 | 0 | 0 |
| `poly(max-constant=16, max-coefficient=16, symbols=7, arity=2)` | 1 | 1 | 0 | 0 |
| `poly(max-constant=16, max-coefficient=16, symbols=8, arity=2)` | 1 | 1 | 0 | 0 |
| `poly(max-constant=18, max-coefficient=18, symbols=5, arity=1)` | 1 | 1 | 0 | 0 |
| `poly(max-constant=18, max-coefficient=18, symbols=6, arity=2)` | 1 | 1 | 0 | 0 |
| `poly(max-constant=2, max-coefficient=2, symbols=10, arity=6)` | 1 | 1 | 0 | 0 |
| `poly(max-constant=2, max-coefficient=2, symbols=10, arity=9)` | 1 | 1 | 0 | 0 |
| `poly(max-constant=2, max-coefficient=2, symbols=11, arity=6)` | 1 | 1 | 0 | 0 |
| `poly(max-constant=2, max-coefficient=2, symbols=13, arity=5)` | 1 | 1 | 0 | 0 |
| `poly(max-constant=2, max-coefficient=2, symbols=15, arity=4)` | 1 | 1 | 0 | 0 |
| `poly(max-constant=2, max-coefficient=2, symbols=19, arity=4)` | 1 | 1 | 0 | 0 |
| `poly(max-constant=2, max-coefficient=2, symbols=21, arity=4)` | 1 | 1 | 0 | 0 |
| `poly(max-constant=2, max-coefficient=2, symbols=23, arity=4)` | 1 | 1 | 0 | 0 |
| `poly(max-constant=2, max-coefficient=2, symbols=27, arity=4)` | 1 | 1 | 0 | 0 |
| `poly(max-constant=2, max-coefficient=2, symbols=33, arity=4)` | 1 | 1 | 0 | 0 |
| `poly(max-constant=2, max-coefficient=2, symbols=42, arity=3)` | 1 | 1 | 0 | 0 |
| `poly(max-constant=2, max-coefficient=2, symbols=44, arity=4)` | 1 | 1 | 0 | 0 |
| `poly(max-constant=20, max-coefficient=20, symbols=4, arity=1)` | 1 | 1 | 0 | 0 |
| `poly(max-constant=24, max-coefficient=24, symbols=5, arity=1)` | 1 | 1 | 0 | 0 |
| `poly(max-constant=26, max-coefficient=26, symbols=3, arity=3)` | 1 | 1 | 0 | 0 |
| `poly(max-constant=28, max-coefficient=28, symbols=5, arity=1)` | 1 | 1 | 0 | 0 |
| `poly(max-constant=3, max-coefficient=3, symbols=48, arity=4)` | 1 | 1 | 0 | 0 |
| `poly(max-constant=3, max-coefficient=3, symbols=7, arity=4)` | 1 | 1 | 0 | 0 |
| `poly(max-constant=4, max-coefficient=4, symbols=16, arity=3)` | 1 | 1 | 0 | 0 |
| `poly(max-constant=4, max-coefficient=4, symbols=22, arity=2)` | 1 | 1 | 0 | 0 |
| `poly(max-constant=4, max-coefficient=4, symbols=24, arity=3)` | 1 | 1 | 0 | 0 |
| `poly(max-constant=4167, max-coefficient=4167, symbols=6, arity=1)` | 1 | 1 | 0 | 0 |
| `poly(max-constant=5, max-coefficient=5, symbols=15, arity=1)` | 1 | 1 | 0 | 0 |
| `poly(max-constant=5, max-coefficient=5, symbols=19, arity=2)` | 1 | 1 | 0 | 0 |
| `poly(max-constant=5, max-coefficient=5, symbols=20, arity=2)` | 1 | 1 | 0 | 0 |
| `poly(max-constant=5, max-coefficient=5, symbols=21, arity=3)` | 1 | 1 | 0 | 0 |
| `poly(max-constant=5, max-coefficient=5, symbols=24, arity=2)` | 1 | 1 | 0 | 0 |
| `poly(max-constant=5, max-coefficient=5, symbols=30, arity=5)` | 1 | 1 | 0 | 0 |
| `poly(max-constant=5, max-coefficient=5, symbols=4, arity=4)` | 1 | 1 | 0 | 0 |
| `poly(max-constant=6, max-coefficient=6, symbols=10, arity=1)` | 1 | 1 | 0 | 0 |
| `poly(max-constant=6, max-coefficient=6, symbols=10, arity=2)` | 1 | 1 | 0 | 0 |
| `poly(max-constant=6, max-coefficient=6, symbols=10, arity=3)` | 1 | 1 | 0 | 0 |
| `poly(max-constant=6, max-coefficient=6, symbols=11, arity=3)` | 1 | 1 | 0 | 0 |
| `poly(max-constant=6, max-coefficient=6, symbols=14, arity=3)` | 1 | 1 | 0 | 0 |
| `poly(max-constant=6, max-coefficient=6, symbols=15, arity=2)` | 1 | 1 | 0 | 0 |
| `poly(max-constant=6, max-coefficient=6, symbols=16, arity=2)` | 1 | 1 | 0 | 0 |
| `poly(max-constant=6, max-coefficient=6, symbols=5, arity=3)` | 1 | 1 | 0 | 0 |
| `poly(max-constant=6, max-coefficient=6, symbols=6, arity=2)` | 1 | 1 | 0 | 0 |
| `poly(max-constant=6, max-coefficient=6, symbols=7, arity=3)` | 1 | 1 | 0 | 0 |
| `poly(max-constant=6, max-coefficient=6, symbols=8, arity=1)` | 1 | 1 | 0 | 0 |
| `poly(max-constant=7, max-coefficient=7, symbols=10, arity=1)` | 1 | 1 | 0 | 0 |
| `poly(max-constant=7, max-coefficient=7, symbols=11, arity=2)` | 1 | 1 | 0 | 0 |
| `poly(max-constant=7, max-coefficient=7, symbols=14, arity=3)` | 1 | 1 | 0 | 0 |
| `poly(max-constant=7, max-coefficient=7, symbols=15, arity=1)` | 1 | 1 | 0 | 0 |
| `poly(max-constant=7, max-coefficient=7, symbols=19, arity=3)` | 1 | 1 | 0 | 0 |
| `poly(max-constant=7, max-coefficient=7, symbols=46, arity=3)` | 1 | 1 | 0 | 0 |
| `poly(max-constant=7, max-coefficient=7, symbols=7, arity=3)` | 1 | 1 | 0 | 0 |
| `poly(max-constant=7, max-coefficient=7, symbols=9, arity=3)` | 1 | 1 | 0 | 0 |
| `poly(max-constant=8, max-coefficient=8, symbols=10, arity=2)` | 1 | 1 | 0 | 0 |
| `poly(max-constant=8, max-coefficient=8, symbols=13, arity=2)` | 1 | 1 | 0 | 0 |
| `poly(max-constant=8, max-coefficient=8, symbols=14, arity=3)` | 1 | 1 | 0 | 0 |
| `poly(max-constant=8, max-coefficient=8, symbols=14, arity=6)` | 1 | 1 | 0 | 0 |
| `poly(max-constant=8, max-coefficient=8, symbols=19, arity=3)` | 1 | 1 | 0 | 0 |
| `poly(max-constant=8, max-coefficient=8, symbols=21, arity=3)` | 1 | 1 | 0 | 0 |
| `poly(max-constant=8, max-coefficient=8, symbols=23, arity=3)` | 1 | 1 | 0 | 0 |
| `poly(max-constant=8, max-coefficient=8, symbols=24, arity=3)` | 1 | 1 | 0 | 0 |
| `poly(max-constant=8, max-coefficient=8, symbols=25, arity=3)` | 1 | 1 | 0 | 0 |
| `poly(max-constant=8, max-coefficient=8, symbols=26, arity=3)` | 1 | 1 | 0 | 0 |
| `poly(max-constant=8, max-coefficient=8, symbols=27, arity=3)` | 1 | 1 | 0 | 0 |
| `poly(max-constant=8, max-coefficient=8, symbols=29, arity=3)` | 1 | 1 | 0 | 0 |
| `poly(max-constant=8, max-coefficient=8, symbols=34, arity=3)` | 1 | 1 | 0 | 0 |
| `poly(max-constant=8, max-coefficient=8, symbols=9, arity=1)` | 1 | 1 | 0 | 0 |
| `poly(max-constant=9, max-coefficient=9, symbols=19, arity=3)` | 1 | 1 | 0 | 0 |
| `poly(max-constant=9, max-coefficient=9, symbols=20, arity=3)` | 1 | 1 | 0 | 0 |
| `poly(max-constant=9, max-coefficient=9, symbols=34, arity=3)` | 1 | 1 | 0 | 0 |
| `poly(max-constant=9, max-coefficient=9, symbols=5, arity=2)` | 1 | 1 | 0 | 0 |
| `poly(max-constant=9, max-coefficient=9, symbols=7, arity=1)` | 1 | 1 | 0 | 0 |
| `poly(max-constant=9, max-coefficient=9, symbols=8, arity=2)` | 1 | 1 | 0 | 0 |
