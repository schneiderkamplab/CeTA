# Residual closure and polynomial query sharing (2026-09-17)

Artifacts: `target/innermost-residual-sharing-20260917/`.
CeTA source and checker are unchanged. All certification below uses
`/work/dfm/festschrift/CeTA-CSR/ceta`.

## Verified baseline

Follow-up `full-v3/` with `parameter-v8.jsonl` improves this to **294/311**:
Ex1_GM99_iGM now certifies, with zero losses against 293 and double rechecks of
all 294 certificates. See the SOTA ledger for checksums and the complete replay.
The parity run below documents the preceding encoding validation.

`full-v2/` retains **293/311 native/parameter-only, no-fallback roots**:
283 YES, ten NO, 16 Unknown, two timeouts. Exact comparison with the previous
293-root baseline has no missing roots, losses, polarity changes or uncertified
decisions. All 293 certificates passed two additional checks
(`full-v2-comparison.json`, `full-v2-rechecks.jsonl`). This is parity, not a new
root high-water mark. Runtime was 402 seconds, with 300-second root ceilings.

Same-binary guards `production-guard-v2/` and `csr-guard-v2/` retain 311/311
and 110/110 respectively, with exact comparisons and additional double checks
(`production-v2-*`, `csr-v2-*`). Standard was not rerun. Production and compact
CSR oracles were not replaced.

Frozen binary: `ferrum-v2`, SHA256
`63460c5d1280ebd2d8c9612722300aff1b22accb0f76055e2ac42852c2140f80`.
Native profile: `parameter-v5.jsonl`, SHA256
`0a5dc95a7ef673663b46efccae73fb7f9bfdb485e57fbebcaaf05f1fabafd46a`.

## Residual work

The 49-state `probes-v2/` wave certified six local closures, including PEANO
continuations. The probe tool now fits symbol/arity limits to the actual live
signature, without raising coefficient bounds or copying interpretations.
Local certificates are checked twice; extracted events are weak native-action
hints with zero independent certification credit. Root recovery still requires
its own complete replay.

Sharing altered Ex26's selected polynomial model and exposed an unguided child.
Eight local Ex26 closures (`loss-probes-v1/`) were certified and their native
hints integrated. The final full replay recovers Ex26 without reintroducing
exact orders.

The Length export defect also affected *nested* semantic labels around marked
symbols. A reversible companion calculation now preserves every label layer
and the marked role during CSR canonicalization/import. It does not drop source
provenance or turn a non-minimal problem into a minimal one. Regression coverage
includes plain, single, and multiply labeled symbols with an empty rule set.
The subsequent `probes-v3/` wave no longer reports the previous Length parse
errors; the root is not yet claimed recovered.

Longer isolated RPO probes distinguish budget from missing continuation:
`ex12-rpo60.xml` closes an older Ex1_2_AEL03_GM residual in 30 seconds;
`ex12-live18.xml` closes its newer 18-pair residual in 45 seconds. Both certify
twice. Appendix's corresponding probe still reaches 60 seconds. Subsequent
AEL03 root replays remain Unknown: the native upstream search exposes further
different children. These are local advances, not extra certified roots.

## Encoding changes

The ordinary polynomial encoder already had a term cache and a shared
expression DAG. The usable-rule encoder bypassed it and built expanded strings.
It now uses that encoder too: repeated terms reuse their interpretations and
repeated arithmetic expressions use named SMT `define-fun` bindings. This is
SMT-level sharing, not a hand-written CNF/Tseitin conversion.

The dominant Length blow-up was additionally in identifiers: nested labeling
produced a 2.88 MB symbol name, with four names totaling over 10 MB. Hexadecimal
SMT identifiers copied these strings throughout the query. When long names are
present, this polynomial query now uses a query-local injective short-name
bijection. The decoded model is translated back to original names and then
independently validated against the original state. No names are hashed or
conflated, no Q/R/P context is replaced, and no retained interpretation is used.

The previous Length trace ended with a 675,283,835-byte query. The new
`full-v1/` Length trace contains 222 polynomial usable-rule queries, **largest
11,029 bytes**; compacted queries are commonly 2,253–2,869 bytes. Solver time
has a 5 ms median and 26 ms maximum in that trace. This is not an end-to-end
root speedup claim: repeated labeling/continuation exploration still prevents
closure. The now-small queries expose that remaining problem more clearly.

Encoding time and solver time are logged separately. Returned SAT, UNSAT and
unknown statuses are preserved; absent output is conservatively labeled
`timeout/cancel/process-failure`, not asserted to be UNSAT. No interpretation
enumeration or broad timeout increase was introduced.

## Verification and next work

- `library-v2.log`: 1,023 passed, zero failed or ignored.
- `python-tests.log`: 44 passed.
- `polynomial-tests-v1.log`: six focused tests, including a long-name model
  restoration/collision test, exact validation, and rejection of a cyclic DP.
- `nested-marked-test-v2.log`: nested-label role preservation passes.
- `check-final.log` and `git diff --check` pass.

Continue from the current live residuals, not merely old archived children.
Prioritize completing AEL03 and GM99 continuations and the remaining non-minimal
Length chain. For further efficiency work, measure repeated labeling and
state construction separately from solving; do not mistake fast SAT responses
followed by open children for an SMT timeout problem.

An isolated ancestral-cycle experiment used the full canonical semantic-CSR
state plus strategy/cursor/nfs, rather than raw names. Its context-separation
test passed and the Length progress log dropped from 4.8 GB to 15 MB, but the
root still returned Unknown after 303 seconds. This is not a demonstrated
root-replay speedup or recovery. The experiment was removed from production
source and saved as `canonical-cycle-experiment.patch`, with binary
`ferrum-cycle`, `cycle-test.log`, and `length-cycle/` artifacts. Repeated
semantic-label alternatives remain a concrete target for joint synthesis or
carefully scoped duplicate-state elimination; the experiment is not part of
the 294-root baseline.

## Fresh live-frontier wave (probes-v4)

Revisited the current `full-v3/` unresolved roots: 31 distinct residual/recipe
probes, eight workers, two Rayon threads, 60-second local ceilings. Three
35-pair PEANO_complete_noand_GM residuals closed and passed two CeTA-CSR
checks each; 25 probes timed out. The other three reported local solved but
could not export a certificate. Those three are LengthOfFiniteLists_nokinds_C
one-pair semantic-CSR continuations, failing with `expected a CSR-DP residual`.
They are **not certified closures**. Restoration deliberately changes the
runtime obligation to ordinary/nonminimal while retaining semantic CSR
metadata; neither the CSR exporter nor the ordinary exporter currently
accepts this standalone context. Do not fix this by discarding that metadata.

Artifacts: `probes-v4/details.json`, per-probe stdout/events/CPFs, and
`probe-v4-hints-{19,20,21}.jsonl` under the artifact base above. The three
certified closures contribute six native state-local hint records to candidate
`parameter-v9.jsonl`; existing records/ranks are retained. Independent event
certification credit stays zero. The `peano-v4/` no-fallback root replay is
the next acceptance check, not a claimed root gain or baseline promotion.

The frontier harness now removes duplicate atoms after fitting signature
bounds: formerly distinct source bounds sometimes became identical searches.
`--processor-timeout` allows explicit per-family budgets (default remains eight
seconds); the overall probe ceiling still applies. This does not change
coefficient bounds or production strategies. All 46 focused Python tests pass.
Ferrum runtime and CeTA sources are unchanged by this wave.

## Semantic-CSR standalone export and continued PEANO closure

`peano-v4/` and `peano-v5/` both remain Unknown (247 and 251 seconds).
`peano-probes-v5/` closed all four selected live residuals, including a new
31-pair state, with double CeTA checks. Their native actions form candidate
`parameter-v10.jsonl`. This is frontier progress, not a root gain. The next
wave is `peano-probes-v6/`.

The three Length export failures above are now fixed without a CeTA change.
The exporter selects the retained semantic CSR context for an ordinary-runtime,
nonminimal continuation and writes the existing **nonminimal CSR-DP input**.
It retains P, active R, the replacement map and minimal=false. This is not an
ordinary-DP coercion. Q/NFS/relative obligations outside that input remain
rejected, as do conflicting CSR contexts. The existing checker still decides
whether the particular continuation proof is supported; this is not blanket
standalone support for every semantic-labeling tail.

`length-standalone-v1/{8,9,10}.cpf.xml` all independently certify twice (native
search 13–16 ms). The exported hints and their retained double-check reports
are `length-standalone-hints-{8,9,10}.*`; candidate `parameter-v11.jsonl` adds
them monotonically. `length-v5/` is the full-root acceptance replay, not yet a
high-water promotion.

Verification: release build passed; the initial export change passed all
1,024 library tests (`library-standalone-v1.log`). After adding conflicting-
context rejection and a synthesized polynomial/cyclic-mutation regression,
all six semantic-CSR focused tests passed (`semantic-csr-export-tests.log`).
The mutation is rejected by production CeTA-CSR; the positive proof certifies.
No CeTA source or binary changed. Production root search strategies are unchanged.

## Exhausted guidance is also a frontier

`peano-v6/` remained Unknown after 256 seconds, but had **zero missing-guidance
states**. The collector previously overlooked guided states where all recorded
attempts failed. Its new opt-in `--include-exhausted` includes those inputs,
still checks input digests and excludes locally productive states so their
children remain the focus. All 47 focused Python tests pass.

`peano-exhausted-v1/` found three such obligations (10, 13 and 31 pairs).
All three certified twice using native SCT, graph and polynomial processing;
their native hints form candidate `parameter-v13.jsonl`. The full-root check
is `peano-v7/`; do not count these local proofs as a root gain.

`length-v5/` timed out at the harness boundary (313 seconds). Its next seven
two-pair probes (`length-probes-v6/`) produced six twice-certified closures,
integrated in `parameter-v14.jsonl`. The seventh returned inapplicable after
4.4 seconds; a separate monotonic-polynomial/matrix/KBO probe also failed
quickly. This last miss is not supported as a timeout diagnosis. Its artifact
directory begins `7c1bbdf4` under `length-probes-v6/`; inspect its residual
chain rather than granting it more time without evidence.

## Measured native-action scheduling

`peano-v7/` remained Unknown in 284 seconds. A concrete timing mismatch was
isolated: state `4fe55e45a5bfb939754536505eb47abd8199f3f691726e91b6d80725b2ffa7d1`
certifies locally with a polynomial transformation taking 13,777 ms, but
guided replay repeatedly stops that same action at about 8,042 ms. The native
hint retains `best_elapsed_ms`, but prediction previously discarded the field.

Prediction now carries measured positive-action times into DP scheduling. The
allowance is max(existing allowance, ceil(1.2 * measured time)), capped at
300 seconds and still bounded by the parent deadline. Evidence ranking and
certification credit do not change. Failed/timeout entries do not supply these
times, and candidate filtering also filters timing metadata. The affected
step receives 16,533 ms. This is targeted timing recovery, not a global budget
increase. `peano-v8/` is the root acceptance run using `parameter-v14.jsonl`.

Verification: the measured-budget regression passes, including missing/tiny
measurements and overflow/cap handling. All 1,026 library tests pass in
`library-measured-v1.log`; the subsequent candidate-filter tightening passes
all 29 lookup tests in `measured-lookup-tests.log`. CeTA is unchanged.

## Complete root recovery and category acceptance

`peano-v8/` reached the formerly capped polynomial step successfully but did
not close the root within its budget. The four-pair leaf selected from the
previous failed replay then certified independently (`peano-four-pair-v1/`).
Its native hint completes candidate `parameter-v15.jsonl`.

`peano-v9/` is a complete no-fallback certified root in 50.287 seconds, with
two independent certificate rechecks. Crucially, the full category run
`full-v4/` reproduces the gain in 50.089 seconds: **295/311**, one gain and
zero losses against `full-v3/`. All 295 certificates pass the additional two
checks. Production Innermost 311/311 and compact CSR 110/110 guards also pass
with no losses and double certificate rechecks. See the authoritative ledger
for commits, hashes and exact artifacts.

`length-v7/` is a separate 600-second diagnostic root replay with the same
native hints and measured allowances. It is not counted as a recovery or
used to change the 300-second category baseline. Do not weaken the nonminimal
semantic-CSR context to enable ordinary SCT: the frozen/hybrid semantic-tail
checker has its own CSR hypotheses, and the ordinary runtime flag is not
permission to invent minimality.
