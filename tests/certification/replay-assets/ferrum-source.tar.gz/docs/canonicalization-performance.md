# Exact canonicalization: coordinated symmetries

The September 16, 2026 Innermost native-guidance export exposed two slow
states from `PALINDROME_complete_noand_GM`: a 102-rule root and a 43-rule
residual. Both exceeded the exporter's 15-second ceiling; the residual also
exceeded an isolated 60-second ceiling. These were implementation limitations,
not an established intrinsic size limit.

Instrumentation (`FERRUM_CANONICAL_TRACE=1`) showed over 26,000 search nodes
and 15,000 leaves within 28 seconds, with **zero** branches removed by the old
single-transposition symmetry check. Most time was spent in refinement.

The exact search now:

- Learns a symbol permutation when two complete leaf encodings are identical.
  This witnesses an automorphism of the complete grouped input, including
  group membership and pair-local variable sharing.
- Prunes a branch only if it is in a previously searched branch's orbit under
  witnessed automorphisms preserving the current color partition. In
  particular, these permutations fix previously individualized symbols.
- Computes symbol-to-pair occurrence indexes once and reuses them during
  refinement. It also reuses the fixed identity encoding for swap checks.

Equal refinement fingerprints alone are **not** evidence of equivalence.
No context is erased, no approximate hash is accepted as an isomorphism, and
no symbol-count cutoff or benchmark-specific production dispatch was added.
Worst-case search remains potentially expensive; these optimizations do not
claim a general polynomial-time bound.

## Measurements and checks

With the frozen `target/innermost-native-remaining-20260916/ferrum-v2` binary:

| Input | New wall time | Search nodes | Pruned branches |
| --- | ---: | ---: | ---: |
| 43-rule residual | 0.833 s | 3,422 | 18,868 |
| 102-rule root | 1.009 s | 2,825 | 15,212 |

These are individual measurements, not a statistical benchmark. Raw logs
are `canonical-profile-before.log`, `canonical-index-{43,102}.log`, and
`canonical-final-times.log` under the same artifact directory.

Fourteen focused Rust tests pass. Coverage includes comparison against search
without learned automorphisms on small coordinated-symmetry inputs, fixed-color
restrictions, original/canonical metadata mappings, and renamed/reordered
versions of both retained CPF input fixtures.

Re-exporting native hints from the 43 retained certified root proofs retained
all 2,362 previous state keys and added exactly two formerly missing canonical
keys. There were 1,186 canonical aliases and zero canonicalization failures.
The source proofs were independently checked twice with CeTA-CSR. Aliased
search suggestions receive **zero** independent event certification credit;
they still require successful proof search and root certification.

Artifacts: `canonical-native-hints-v2.jsonl` and its `.checks.json` sidecar.
The preferred experimental merged profile is `parameter-v14.jsonl`; this does
not replace the production oracle. Canonicalizing these states does not by itself
claim to close their roots. See the category replay ledger for certified totals.
