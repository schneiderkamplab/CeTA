# CSR oracle compaction and source-relative local export

2026-09-16. These are independent tasks: the 110-root parameter-only replay
already certifies without standalone export of every intermediate state.

## Safe deployment boundary

The validated CSR slice is now
`target/csr-native-wpo-sparse-20260916/csr-slice-v3.jsonl`: **1,735,544 bytes**,
1,336 records, no exact witnesses or composite proof actions. Its independent
no-fallback replay certifies **110/110 (105 YES, five NO)** and every CPF passes
two further CeTA checks. Full elapsed time is 62 seconds. Maximum root time is
58.524 seconds, but the configured cap remains 300 seconds: this is not a
separate strict-60-second experiment. The slice retains only observed lookup
states and their alias components, so keep the larger profile for exploration.

SHA256: `563a2447503c4c78d4161f8657dfd48281a3d5030e022bd17fad75dbe16638af`.
Artifacts beside the slice: `csr-slice-replay-v3/details.json`,
`csr-slice-v3-comparison.json`, `csr-slice-v3-rechecks.jsonl`. Frozen executable:
`ferrum-lookup-trace-release`, SHA256
`f30ffc857a518f2c0348385eb7b7795944d459016f42040a802e5090d0f16526`.
The trace-producing full parameter replay also certifies 110/110 twice:
`csr-traced-replay/details.json`, `csr-traced-rechecks.jsonl`.
Six Python slicing tests and all 29 Rust utility-lookup tests pass.

The rejected event-only slices v1/v2 each yield 99 certified, ten Unknown,
one timeout. They are retained for diagnosis, not deployment. No production
guidance was overwritten. Recording the actual raw/structural/canonical
queries recovers the missing state-local guidance; no proof processor changed.

The tested parameter oracle is
`target/csr-native-wpo-sparse-20260916/parameter-v22.jsonl`: 429,107,566 bytes,
no exact actions or witness definitions, and 110/110 twice-certified roots.
It can be used for this CSR root set now. This does not establish witness-free
Standard or Innermost coverage.

The unchanged production oracle is 3,455,805,631 bytes. Of that,
2,981,725,965 bytes are 21,379 modular witness definitions; 474,079,666 bytes
are guidance records. No complete TRS/DP proof-action family occurs among
those definitions. Complete proof actions remain disabled in Ferrum.
`exact-dp` denotes a DP transformation, not `exact-dp-proof`.

Do not delete witnesses from the shared production oracle merely because a
CSR-origin state no longer needs them. An ordinary DP state or witness can
also be used by Standard or Innermost. Use separate category profiles until
all affected categories and retained residuals pass their own guard replays.

`scripts/slice_parameter_oracle.py` makes an additional category slice. It
preserves entire records, action order, invalidations and connected alias
components, refusing any witness-bearing source. The output is only a
candidate until a complete replay certifies. Event keys alone are insufficient:
runtime lookup also queries serializer and canonical representations absent
from the event stream. Optional `FERRUM_ORACLE_LOOKUP_TRACE_DIR` records actual
raw/structural queries, including misses, in per-process files in an existing
directory. Pass that directory as `--lookup-trace-dir` when slicing.

## Standalone MU-TERM obligation: next implementation

The existing `csrMutermTypedDpInput` entry requires minimality and the exact
source unhiding rules. It cannot represent all reduced, source-relative
recursive states. Do not remove the exporter guard or replace source R with
active usable U: that changes the mathematical obligation.

The existing theorem `check_muterm_recursive_dp_proof_sound` in
`CeTA-CSR/thys/Proof_Checker/CSR_Muterm_Typed_Checker.thy` provides a promising
integration point. It checks a recursive proof with separate arguments:

- source rules R and replacement map;
- exact source bridges Bcheck;
- local bridge subset B;
- active usable rules U;
- current pairs P.

Its conclusion is the source-relative `finite_muterm_i4_good_typed_dpp`
property, not ordinary DP minimality or termination of U. Its executable
entry must establish well-formedness, overlay, exact source bridges, local
bridge inclusion, marked-symbol freshness and map compatibility. The wrapper,
CPF input/parser, desired-property definition, Ferrum export/import and tests
must all agree on that claim. Existing root certification does not substitute
for this standalone theorem/parser integration.

Acceptance cases are the retained `emmes-multilinear` and `exintrod-shape`
native chains. Require independent positive checks and mutations of source
rules, map, local bridges and usable rules. Preserve their complete-root
certification and the ordinary/innermost guards. Any Isabelle builds must use
separate writable heaps and reuse compatible dependencies.

This entry is not implemented yet; no CeTA source or executable was changed
for the compaction experiment.
