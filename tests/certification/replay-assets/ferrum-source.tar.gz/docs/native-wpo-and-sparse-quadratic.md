# Native WPO and restricted rational quadratic synthesis

2026-09-16. Starting baseline: **106/110** parameter-only, no-fallback CSR
roots. The separate witness-enabled production oracle covers all 110 already.

## Search, not retained interpretations

`wpo-max(max-constant=4,max-coefficient=1,max-symbols=32,max-arity=3,alternatives=2)`
jointly chooses the max algebra, precedence ranks, collapsing filters and
partial lexicographic statuses. The SMT comparison DAG mirrors the existing
executable WPO equations. Projection filters are encoded by conditional
algebra coefficients, not by enumerating complete filtered terms. The model
is independently checked by `WpoMaxOrder` before constructing the existing
CPF weighted-path-order proof.

Current search restrictions are explicit: identity/collapsing filters,
left-to-right subsequences as statuses, at most four arguments and eight max
alternatives. Reordered/multiset statuses are not synthesized yet. Nonempty Q
and obligations requiring strict R deletion are declined, not erased.
Selected status arguments satisfy weak simplicity of the max base.

The oracle records only the native atom and bounds. It supplies no coefficient,
precedence, filter or status assignment. Converting a retained WPO keeps the
`wpo-max` family; plain `max-poly` is not a substitute for this processor.
Fresh synthesis events may serialize their resulting model as `exact-*`
**output evidence**; this is not a supplied oracle action. The final parameter
oracle has zero exact atoms, hex payloads or witness references.

For rational quadratics, new optional parameters restrict a **global search
class**, independently of symbol names:

- `coefficients=0+1+2+4`: allowed numerator values, including constants.
- `quadratic-terms=1`: at most one nonzero quadratic monomial per symbol.
- `quadratic-shape=multilinear`: exclude all squares, retaining mixed products.
- `quadratic-shape=unary-squares`: permit squares only for unary symbols,
  retaining mixed products for other arities.

Omitted parameters preserve the previous unrestricted search. Sparse shapes
also avoid constructing the forbidden symbolic products. Every resulting
interpretation still undergoes exact rational orientation checks. No per-symbol
interpretation or monomial position is retained in guidance.

ExIntrod uses denominator 2, gap 1/2, numerator bound 4, alphabet 0/1/2/4 and
`unary-squares`. emmes uses denominator 4, gap 1/4, bound 8, alphabet 0/2/4/8
and `multilinear`. Both use at most one quadratic monomial per symbol.

## Targeted results and replay integration

Artifacts: `target/csr-native-wpo-sparse-20260916/`.

- Five independent WPO residual proofs (`wpo-0.xml` through `wpo-4.xml`)
  pass CeTA twice. Native search takes approximately 2–10 seconds.
- Complete ordinary DP chains `ex3-chain.xml` and `ex5-chain.xml` also pass
  twice, taking approximately 10 and 43 seconds respectively.
- `emmes-multilinear` closes its local native chain in 11 seconds;
  `exintrod-shape` closes its chain in 58 seconds. Their local source-relative
  MU-TERM contexts cannot currently be exported as standalone CPFs. These
  local outcomes were therefore only **unchecked weak search hints** until
  reconstructed at the original root.
- Full original CSR proofs `ex3-root-v2.xml`, `exintrod-root-v2.xml`,
  `emmes-root-v2.xml` and `ex5-root-v3.xml` each pass CeTA twice. All use
  `FERRUM_DP_LLM_NO_FALLBACK=1`, `timeout(180s, fail)` and a parameter-only
  oracle.
- Ex5's live replay exposed an additional five-pair component. Its independent
  native max/graph/WPO/SCT proof `ex5-five.xml` passes twice; those state-local
  actions were added as well. No graph-estimation change was needed.

New native actions initially inherited a generic eight-second weak-evidence
timeout. WPO and explicit rational-quadratic searches now receive the user's
60-second local ceiling, still capped by the root deadline. Action-priority
digests select successful native actions before obsolete searches without
assigning certification credit to unverified fragments.

The first sparse cvc5 queries exposed an SMT-LIB unary-addition portability
bug in the new sparsity constraint. The cardinality sum now uses binary sums
and omits vacuous constraints. Solver/encoding progress and optional full
query logging cover the rational-quadratic route.

## Verification and certification boundary

The complete optimized **parameter-only, no-fallback replay is 110/110**
(105 YES, five NO), up from 106 with no losses or polarity changes.
Every CPF passed two independent checks. `parameter-release/details.json`,
`parameter-release-comparison.json` and `parameter-release-rechecks.jsonl`
retain the complete evidence. The full category took 116 seconds under load.

| Newly recovered root | Full release replay, seconds |
| --- | ---: |
| CSR_04/Ex3_2_Luc97 | 14.234 |
| CSR_04/Ex5_7_Luc97 | 29.155 |
| CSR_04/ExIntrod_Zan97 | 76.241 |
| Maude_06/emmes | 15.936 |

These are not strict 60-second-root results: 108 roots finished within 60
seconds; ExIntrod and morse (69.139 seconds) exceeded it under concurrency.
The local processor ceiling is 60 seconds and the root ceiling is 300 seconds.

Final native oracle: `parameter-v22.jsonl`, SHA256
`2c0ba4ed87d8d8ae5e636ea71456652744eec39ee502cae3486eaa95753b92bb`.
Frozen optimized binary: `ferrum-release`, SHA256
`6d80059a79b3d192954903b2c6e1da60d135bba1b1d6308abc7bf2c70980eaff`.

The full library suite passes **990 tests, zero failed/ignored**
in both debug and release (`library-final.log`, `library-release.log`),
including native WPO, renaming, self-loop rejection,
CPF certification, sparse-shape and parser regressions. The focused Python
converter/materializer/exporter suite passes 25 tests (`python-tests.log`).

CeTA source and binary are unchanged. All certification uses
`/work/dfm/festschrift/CeTA-CSR/ceta`, main commit
`73662ec88a74f65187cba6986d300836564b6a59`, SHA256
`64597fcb0a8c1c09af1de0816283c66f474783df3010fc3e60ca30731f5090b7`.
The production oracle is unchanged at `oracle-v48-final.jsonl`. Its optimized
guard preserves **1,759/1,759 roots**: Standard 1,338 (1,039 YES, 299 NO),
Innermost 311 (301 YES, ten NO), CSR 110 (105 YES, five NO). All 1,759 CPFs
passed two independent checks. All **235/235 retained residuals** also replay
and certify twice. See `production-release/details.json`,
`production-release-comparison.json`, `production-release-rechecks.jsonl`,
`residual-release-checks.jsonl` and `child-release-checks.jsonl`.

The earlier `production-guard` debug run was deliberately stopped and replaced
by the optimized guard; its partial artifacts are retained, not counted as a
complete replay. Memory stayed below 600 GiB excluding reclaimable file cache.
No Isabelle builds or CeTA edits were needed.
