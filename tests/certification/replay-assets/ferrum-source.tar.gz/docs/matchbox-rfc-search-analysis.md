# Matchbox RFC Search Analysis

Date: 2026-07-23

This note records the local analysis of Matchbox/pure-matchbox for improving
Ferrum's SRS RFC match-bounds search.

## Source Trees

- Legacy Matchbox checkout: `/work/dfm/festschrift/matchbox`
- Pure Matchbox checkout: `/work/dfm/festschrift/pure-matchbox`
- Pure Matchbox license: GPLv3, from `/work/dfm/festschrift/pure-matchbox/LICENSE`

Because pure-matchbox is GPLv3, Ferrum should treat it as an algorithmic and
behavioral reference. Do not copy code into Ferrum unless the Ferrum licensing
decision explicitly allows that. The intended path is a clean Rust
implementation from the literature, source-level understanding, and checked
certificate obligations.

## Relevant Pure Matchbox Components

RFC match-bounds are implemented in two related layers.

`src/Matchbox/Decomp.hs` implements the exact match-bounds construction:

- `rfc_with` builds RFC rules by adding right-extension rules
  `l1 # -> r` for strict prefixes `l1` of an LHS.
- `builder_orig` creates one RHS path per RHS ending in a wildcard-tail loop.
- `common` repeatedly:
  - infers epsilon transitions from inverse-letter cancellation rules;
  - records redex paths;
  - adds reduct paths when the RHS path is absent or has insufficient height.
- The exported exact certificates keep only original-symbol transitions and
  epsilon transitions; inverse letters are an internal construction device.

`src/Matchbox/Barren.hs` implements the approximate/relative RFC construction
used by `RelRFCmb` skeletons:

- `Barr` stores RHS paths indexed by `(height, rule, position)`.
- `eps` is a transitively closed epsilon relation on these places.
- `wanted_for_ext_right` implements RFC right-extension closure.
- `wanted_for_inner` implements below-top rewriting closure.
- `At_Bound = Merge` keeps reducts at the height bound by adding epsilon links
  instead of rejecting immediately.
- The processor removes rules whose recorded top height stays below the bound
  and keeps rules that reach the bound.

Important caveat: pure-matchbox itself refuses CPF output for RFC/ROC unless
the method is exact FULL match-bounds. See
`src/Matchbox/Decomp/Working.hs`, where `cpf` plus non-`Exact FULL` returns
`Nothing`. Thus pure-matchbox does not provide a ready certified CPF design for
`RelRFCmb`; Ferrum's local CeTA-rfc extension is the certification basis.

## TermComp 2025 Evidence

The local TermComp proof corpus contains 803 Matchbox proof outputs with exact
RFC markers:

- `SRS_Standard`: 653 examples
- `SRS_Relative`: 150 examples

Across those proof texts:

- RFC height bound is almost always `2`; only 3 examples use bound `3`.
- Epsilon-transition counts can be large: p95 around 5,867, max 19,198.
- Visible state ids stay moderate: p95 around 100, max 191.
- The most common skeleton is direct `RelRFCmb`, but Matchbox frequently uses
  `Weight`, `Mirror`, `Strictify`, `Cleaner`, repeated `RelRFCmb`, and tiling
  around it.

Current Ferrum focused run after the first certified Matchbox-relative checker:

- Run: `target/termcomp-runs/20260722-srs-rfc-matchbox-capped-653-32w-30s`
- Result on the 653 SRS_Standard RFC-hit examples: 0 YES, 514 MAYBE,
  139 TIMEOUT, 0 certification failures.

This means the current blocker is Ferrum witness search, not CeTA rejection.

## Certification Constraint

Ferrum currently certifies `<rfcMatchboxRelativeBounds>` with the local
CeTA-rfc checker. The checker validates the emitted automaton and state
compatibility relation, including the open-tail initial-language obligations
used by the formal theorem.

Therefore an implementation must not merely mimic Matchbox's heuristic
epsilon graph. It must produce a witness accepted by Ferrum's validator and by
CeTA-rfc:

- initial RHS/open-tail language accepted in the required sense;
- Matchbox-style split closure for RFC redexes;
- lhs-suffix totality;
- no top redex at the bound;
- explicit state-compatibility relation for merge-at-bound.

## Implementation Backlog

High-impact next work:

1. Implement a clean `RelRFCmb` search constructor in Ferrum based on the
   `Barren.epsilontik` idea, but target Ferrum's checked
   `<rfcMatchboxRelativeBounds>` semantics directly.
2. Use place states `(height, rule_index, position)` for RHS paths and maintain
   transitive epsilon closure incrementally.
3. Add RFC right-extension obligations from strict LHS prefixes and inner-redex
   obligations from all current reachable LHS paths.
4. For `at-bound=merge`, translate top-height reduct merging into explicit
   state-compatibility pairs, then validate with
   `is_rfc_matchbox_closed`, `has_rfc_lhs_suffix_totality`, and
   `has_no_rfc_top_redex_at_bound`.
5. If partial deletion is needed, integrate the RFC-relative step with the
   existing residual proof recursion instead of requiring all rules to be
   removed at once.
6. Add a strategy branch that races:
   - direct `RelRFCmb`;
   - mirrored `RelRFCmb`;
   - cheap `Weight` or weighted rule removal followed by `RelRFCmb`;
   - `Cleaner`/`Strictify` followed by `RelRFCmb` once those steps are
     certifiable.

The first implementation milestone should be real examples from the 653-example
set that produce `CERTIFIED` with `.tools/ceta-relative-bounds`, not only
synthetic smoke tests.

## 2026-07-23 Ferrum Implementation Attempt

Ferrum now contains the first clean Rust place-state constructor for
`rfc-relative-match-bounds(...,at-bound=merge)`.

Implemented shape:

- place states `(height, rule_index, position)` over RHS paths;
- transitive epsilon closure for Matchbox-style right-extension and inner-redex
  obligations;
- RHS paths at all heights up to the requested bound;
- direct height-0 RHS paths from every state to the final state for the
  all-state initial-language obligation;
- explicit below-top strict compatibility saturation before export;
- final validation through Ferrum's checked Matchbox-relative conditions before
  CPF is emitted.

The first version incorrectly emitted a `z033` certificate that CeTA rejected
because a below-top strict LHS path at height 0 lacked the corresponding RHS
path at height 1. Ferrum now checks and saturates this obligation before export,
so `z033` is declined instead of producing an uncertified YES.

Verification:

```console
OPENSSL_DIR=/home/ucloud/miniforge3/envs/ferrum \
PKG_CONFIG_PATH=/home/ucloud/miniforge3/envs/ferrum/lib/pkgconfig \
cargo +1.95.0-x86_64-unknown-linux-gnu check --lib --jobs 64

OPENSSL_DIR=/home/ucloud/miniforge3/envs/ferrum \
PKG_CONFIG_PATH=/home/ucloud/miniforge3/envs/ferrum/lib/pkgconfig \
cargo +1.95.0-x86_64-unknown-linux-gnu test --lib rfc --jobs 64
```

Result: library check passed; RFC tests passed, `12 passed`.

Smoke tests:

- Synthetic existing fixture `target/rfc-matchbox-automaton-smoke/ab-c.ari`
  still emits `<rfcMatchboxRelativeBounds>` and certifies with
  `.tools/ceta-relative-bounds`.
- `SRS_Standard/Zantema_04/z033.ari` now returns `Unknown` instead of an
  invalid certificate.
- `SRS_Standard/Zantema_04/z049.ari` and `z061.ari` timed out under the narrow
  direct merge-RFC smoke strategy without surrounding SRS strategy branches.
- A 50-example prefix sample from the 653 Matchbox-RFC SRS_Standard hit list
  produced `0 YES`, `50 MAYBE`, and `0` certification failures with:

```fs
timeout(5s,
  rfc-relative-match-bounds(
    max-bound=3,
    max-words=10000,
    max-word-len=128,
    max-states=2000,
    max-transitions=200000,
    at-bound=merge))
```

Conclusion: this implementation is useful as a certification-safe base, but it
is not yet power-positive on the sampled TermCOMP examples. The next required
search work is to avoid the too-permissive all-state over-approximation and
construct the automaton closer to Matchbox's exact/approximate witness shape:
incremental cached word products, inverse-letter cancellation for exact RFC,
and a relative/partial-deletion strategy that can be certified in the presence
of residual weak rules.

## 2026-07-23 Partial-Deletion Probe

Ferrum now computes the Matchbox-style keep/delete split for the place-state
`RelRFCmb` constructor:

- rules whose recorded top height is below the bound are deleted;
- rules that reach the bound are kept as residual weak rules;
- deleted rules are saturated/checked for below-top strict compatibility and no
  top redex at the bound;
- kept rules are saturated/checked for weak match-bounds compatibility before
  CPF export.

Verification:

```console
OPENSSL_DIR=/home/ucloud/miniforge3/envs/ferrum \
PKG_CONFIG_PATH=/home/ucloud/miniforge3/envs/ferrum/lib/pkgconfig \
cargo +1.95.0-x86_64-unknown-linux-gnu check --lib --jobs 64

OPENSSL_DIR=/home/ucloud/miniforge3/envs/ferrum \
PKG_CONFIG_PATH=/home/ucloud/miniforge3/envs/ferrum/lib/pkgconfig \
cargo +1.95.0-x86_64-unknown-linux-gnu test --lib rfc --jobs 64

OPENSSL_DIR=/home/ucloud/miniforge3/envs/ferrum \
PKG_CONFIG_PATH=/home/ucloud/miniforge3/envs/ferrum/lib/pkgconfig \
cargo +1.95.0-x86_64-unknown-linux-gnu build --release --bin ferrum --jobs 64
```

Result: all checks passed; RFC tests passed, `12 passed`.

Current focused probe:

- Run: `target/termcomp-runs/20260723-srs-rfc-matchbox-partial-current-653-32w-20s`
- Input: the 653 `SRS_Standard` examples whose Matchbox TermCOMP 2025 output
  contains RFC markers.
- Strategy:

```fs
timeout(20s,rfc-relative-match-bounds(max-bound=3,max-words=10000,max-word-len=128,max-states=2000,max-transitions=200000,at-bound=merge))
```

Result:

| Total | YES | Certified YES | MAYBE | Timeout | Certification failures |
| ---: | ---: | ---: | ---: | ---: | ---: |
| 653 | 0 | 0 | 435 | 218 | 0 |

The existing exact finite-initial RFC witness is preserved:

```console
target/release/ferrum prove ../TPDB-ARI/SRS_Standard/Zantema_04/z061.ari \
  --strategy 'rfc-relative-match-bounds(max-bound=3,max-words=10000,max-word-len=128,max-states=2000,max-transitions=50000)' \
  --cpf-mode cpf30 \
  --cpf target/rfc-matchbox-partial-probe/z061-current.cpf3.xml

.tools/ceta-relative-bounds target/rfc-matchbox-partial-probe/z061-current.cpf3.xml
```

Result: `CERTIFIED`.

Interpretation: the partial-deletion plumbing is now locally validation-gated,
but the current place-state witness is still too weak/expensive for the
Matchbox RFC corpus. The main technical mismatch is the checker-side
all-automaton-state initial-language obligation. Matchbox's internal barren
automata do not need every internal place state to act as the tail valuation of
an initial RHS template. Recovering Matchbox power requires either:

- a stronger Ferrum construction that satisfies the existing all-state theorem
  without excessive over-approximation; or
- a certified CeTA theorem using only ground-inhabited tail states, together
  with an executable inhabited-state computation.

## 2026-07-23 Productive-Trim Attempt and Right-Barren Direction

The CeTA-rfc theory was changed to run the generic relative-bounds check for
`<rfcMatchboxRelativeBounds>` on the productive part of the supplied automaton.
The Isabelle session verified:

```console
AFP=/work/dfm/festschrift/ferrum/.tools/afp-current/thys \
/work/dfm/festschrift/ferrum/.tools/Isabelle2025-2/bin/isabelle build -j 16 -d thys -b RFC_Checker_Ext
```

The full `Code` session and Haskell executable rebuild also completed, and the
new binary was installed as `.tools/ceta-relative-bounds`.

Ferrum was then simplified so the Matchbox-style barren witness no longer adds
the old artificial initial/suffix paths. Validation:

```console
cargo +1.95.0-x86_64-unknown-linux-gnu fmt
OPENSSL_DIR=/home/ucloud/miniforge3/envs/ferrum \
PKG_CONFIG_PATH=/home/ucloud/miniforge3/envs/ferrum/lib/pkgconfig \
cargo +1.95.0-x86_64-unknown-linux-gnu check --lib --jobs 64

OPENSSL_DIR=/home/ucloud/miniforge3/envs/ferrum \
PKG_CONFIG_PATH=/home/ucloud/miniforge3/envs/ferrum/lib/pkgconfig \
cargo +1.95.0-x86_64-unknown-linux-gnu build --release --bin ferrum --jobs 64
```

Both passed.

Smoke example:

```console
target/release/ferrum prove ../TPDB-ARI/SRS_Standard/Zantema_04/z049.ari \
  --strategy 'rfc-relative-match-bounds(max-bound=2,max-words=10000,max-word-len=128,max-states=2000,max-transitions=50000,at-bound=merge)' \
  --cpf-mode cpf30 \
  --cpf target/rfc-matchbox-productive-smoke/z049.cpf3.xml
```

Ferrum now returns raw `Terminating` for `z049.ari` with a
`RfcMatchboxRelativeBounds` step. The rebuilt CeTA checker still rejects the
certificate:

```text
RFC Matchbox-relative initial language is not accepted by the automaton for all automaton states
```

This shows productive trimming alone is insufficient. The remaining theorem gap
is not a Ferrum witness-search failure for this example: Matchbox's
`src/Matchbox/Barren.hs` proves right-barren/RFC closure by maintaining the
language generated from RHS paths and adding epsilon transitions justified by
right-extension and inner-redex closure. It does not require every internal
place state to accept every initial RHS template.

Next certified target:

- add a dedicated CeTA/CPF right-barren `RelRFCmb` processor whose executable
  checks are:
  - RHS place-path initial automaton;
  - transitive epsilon closure;
  - right-extension closure, matching Matchbox `wanted_for_ext_right`;
  - inner-redex closure with merge-at-bound, matching Matchbox
    `wanted_for_inner`;
  - below-top strict compatibility and no top redex for deleted rules;
  - weak compatibility plus recursive proof for residual kept rules;
- update Ferrum to emit this dedicated proof step for
  `rfc-relative-match-bounds(...,at-bound=merge)`.

A first 20-candidate smoke probe was run under
`target/rfc-matchbox-productive-smoke20-20260723-111707` after memory pressure
dropped below the guard:

| Total | Raw YES | Certified YES | Unknown in this branch | Certification failures |
| ---: | ---: | ---: | ---: | ---: |
| 20 | 7 | 0 | 13 | 7 |

All 7 certification failures had the same cause:

```text
RFC Matchbox-relative initial language is not accepted by the automaton for all automaton states
```

This strengthens the conclusion: for small direct Matchbox RFC candidates,
Ferrum's current right-barren witness search already finds real raw proofs, and
the immediate blocker is the missing certified right-extension RFCmb theorem.

## 2026-07-23 Certified Right-Extension Matchbox RFC

The CeTA-rfc tree now verifies the executable theorem/checker for
`<rfcMatchboxRelativeBounds>` using the Matchbox-style right-extension condition
instead of the earlier all-automaton-state initial/suffix obligation. The
verified checker was rebuilt through Isabelle session `Code`, exported to
Haskell, compiled with GHC, and installed as Ferrum's local
`.tools/ceta-relative-bounds`.

Ferrum's `rfc-relative-match-bounds(...,at-bound=merge)` witness construction
was adjusted to emit certifiable automata:

- removed RHS words are accepted from the final state used by the RFC initial
  language check;
- right-extension obligations are satisfied by adding merged height-0 RHS paths
  ending in the existing prefix state, so identity state compatibility is
  sufficient and CeTA's coherence check remains valid;
- Ferrum locally validates below-top strict compatibility, weak residual-rule
  compatibility, Matchbox closure, right-extension closure, and no top redex
  before emitting the CPF proof.

Focused validation:

```console
AFP=/work/dfm/festschrift/ferrum/.tools/afp-current/thys \
/work/dfm/festschrift/ferrum/.tools/Isabelle2025-2/bin/isabelle build -j 16 -d thys -b RFC_Checker_Ext

AFP=/work/dfm/festschrift/ferrum/.tools/afp-current/thys \
/work/dfm/festschrift/ferrum/.tools/Isabelle2025-2/bin/isabelle build -j 16 -d thys -b Code

OPENSSL_DIR=/home/ucloud/miniforge3/envs/ferrum \
PKG_CONFIG_PATH=/home/ucloud/miniforge3/envs/ferrum/lib/pkgconfig \
cargo +1.95.0-x86_64-unknown-linux-gnu check --lib --jobs 64
```

The first real certified smoke example is
`SRS_Standard/Zantema_04/z049.ari`:

```console
target/release/ferrum prove ../TPDB-ARI/SRS_Standard/Zantema_04/z049.ari \
  --strategy 'rfc-relative-match-bounds(max-bound=2,max-words=10000,max-word-len=128,max-states=2000,max-transitions=50000,at-bound=merge)' \
  --cpf-mode cpf30 \
  --cpf target/rfc-matchbox-ext-right-smoke/z049.cpf3.xml

.tools/ceta-relative-bounds target/rfc-matchbox-ext-right-smoke/z049.cpf3.xml
```

CeTA result: `CERTIFIED`.

A direct-40 Matchbox-RFC candidate smoke run with full artifacts is stored in
`target/termcomp-runs/20260723-rfc-ext-right-direct40-32w-60s`.

| Total | YES | Certified YES | MAYBE | Timeout | Cert failures |
| ---: | ---: | ---: | ---: | ---: | ---: |
| 40 | 4 | 4 | 27 | 9 | 0 |

Certified examples:

- `SRS_Standard/Zantema_04/z049.ari`
- `SRS_Standard/Zantema_04/z055.ari`
- `SRS_Standard/Zantema_04/z062.ari`
- `SRS_Standard/Zantema_04/z063.ari`

The remaining direct-40 gap is now mostly search/runtime power. The next
productive search work is to reduce timeouts in the Matchbox-style completion
and add the preprocessing/strictification/reversal combinations used in
Matchbox proofs before the `RelRFCmb` step.

## 2026-07-23 Recursive RFC Residuals and Closure Modes

Ferrum now recursively tries the certified
`rfc-relative-match-bounds(...,at-bound=merge)` processor on the residual SRS
after a Matchbox-style relative RFC deletion. If recursive RFC does not solve
the residual, Ferrum falls back to the existing ordinary relative
match-bounds residual solver.

The barren completion has also been extended with the additional Matchbox-style
`ext_left` and `overlap` wanted-epsilon generators from pure-matchbox's
`Barren.hs`. These are exposed by the strategy parameter `closure=full`.
The default remains `closure=right`, which preserves the faster certified
right-extension profile:

```fs
rfc-relative-match-bounds(
  max-bound=2,
  max-words=10000,
  max-word-len=128,
  max-states=2000,
  max-transitions=50000,
  at-bound=merge
)
```

To run the stronger completion explicitly:

```fs
rfc-relative-match-bounds(
  max-bound=2,
  max-words=10000,
  max-word-len=128,
  max-states=2000,
  max-transitions=50000,
  at-bound=merge,
  closure=full
)
```

Focused validation:

- `target/termcomp-runs/20260723-rfc-recursive-certified4-8w-60s`: 4 YES,
  4 certified YES, 0 certification failures.
- `target/termcomp-runs/20260723-rfc-closure-param-default-direct40-32w-60s`:
  40 examples, 13 YES, 13 certified YES, 8 MAYBE, 19 timeout,
  0 certification failures.
- `target/termcomp-runs/20260723-rfc-ext-left-overlap-default-direct40-32w-60s`:
  `closure=full` produced the same 13 certified YES on this direct-40 set, but
  shifted two failures from MAYBE to timeout. This is currently an opt-in
  search-strengthening mode rather than a default branch.

## 2026-07-23 Partial Matchbox RFC Deletion

Ferrum now treats the set of rules removable by Matchbox-style barren
completion as a candidate pool instead of a single all-or-nothing deletion.
It tries validated deletion batches in decreasing heuristic order: all
removable rules, length-decreasing/non-growing subsets, length-threshold
subsets, prefixes, and singleton deletions. Every candidate is still checked by
the same local semantic validators and emitted as the same certified
`<rfcMatchboxRelativeBounds>` proof object, so this changes search only, not the
trusted certificate condition.

Focused result with full artifacts:

- `target/termcomp-runs/20260723-rfc-partial-deletion-default-direct40-32w-60s`:
  40 examples, 14 YES, 14 certified YES, 6 MAYBE, 20 timeout,
  0 certification failures.
- Compared with `target/termcomp-runs/20260723-rfc-closure-param-default-direct40-32w-60s`,
  there were no lost YESs and one extra certified YES:
  `SRS_Standard/ICFP_2010/3268.ari`.

The additional `3268` certificate is a reversed TRS/DP proof rather than an RFC
proof; the RFC search change affected the parallel search schedule enough for
that branch to complete in the benchmark run. An isolated
`string-reversal(timeout(55s, termination))` proof for the same example also
certifies with CeTA. A tested strategy change that delayed RFC branches by 2s
was worse on this slice:
`target/termcomp-runs/20260723-srs-delay-rfc-default-direct40-32w-60s` had
13 certified YES and 22 timeouts, so the default strategy was restored.

## 2026-07-23 653-Candidate Current Default Run

The current default strategy was run over the fixed 653 SRS candidate set from
`target/termcomp-runs/20260723-srs-rfc-matchbox-partial-current-653-32w-20s`.
The first attempts at 32 and 16 workers were stopped under the memory-pressure
guard when total RSS approached/exceeded the configured 2 TB limit. The
remaining examples were completed at 8 workers.

Combined artifacts:

- `target/termcomp-runs/20260723-srs-653-current-default-32w-60s`
- `target/termcomp-runs/20260723-srs-653-current-default-resume396-16w-60s`
- `target/termcomp-runs/20260723-srs-653-current-default-resume207-8w-60s`
- Combined summary:
  `target/termcomp-runs/20260723-srs-653-current-default-combined-60s/summary.md`

Combined result:

| Total | YES | Certified YES | NO | Certified NO | MAYBE | Timeout | Error | Cert failures |
| ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| 653 | 81 | 81 | 0 | 0 | 179 | 393 | 0 | 0 |

Operational note: this candidate set contains examples where a single Ferrum
process can consume tens or hundreds of GiB. For this slice, 8 workers was the
first observed concurrency level that completed without crossing the memory
guard. Future full SRS/RFC candidate runs should start at 8 workers or use a
memory-aware scheduler before increasing concurrency.

## 2026-07-23 Internal Automaton Caps and Cheap Preprocessing

Ferrum now applies the configured RFC automaton budgets during Matchbox-style
barren construction itself:

- `max-states` bounds the number of generated place states before the closure
  loop starts;
- `max-transitions` bounds the transitive epsilon closure maintained by the
  barren builder;
- exceeding either budget returns MAYBE for that processor attempt.

This is intentionally a search bound, not a proof rule. Any emitted CPF is
still checked against the same `<rfcMatchboxRelativeBounds>` obligations, and
oversized witnesses are simply not emitted.

The default SRS YES strategy now runs a short cheap certified preprocessing
portfolio before expensive RFC search and fallback termination:

- reversed `srs-weighted-rule-removal(max-weight=64)`;
- `poly(max-constant=1,max-coefficient=1)` and its string-reversed variant;
- `kbo(weight=2)` and its string-reversed variant;
- `path-order` and its string-reversed variant, each under a short timeout.

This sequencing matters. Running the cheap branches in the same long-lived
parallel portfolio as RFC and fallback termination starved the known
`string-reversal(timeout(55s, termination))` proof for
`SRS_Standard/ICFP_2010/3268.ari`; the preliminary cheap stage recovers that
default proof and CeTA certifies it.

Focused direct-40 result with full artifacts:

- `target/termcomp-runs/20260723-srs-caps-cheap-seq-direct40-8w-60s`:
  40 examples, 14 YES, 14 certified YES, 5 MAYBE, 21 timeout,
  0 certification failures.
- Compared with
  `target/termcomp-runs/20260723-rfc-partial-deletion-default-direct40-32w-60s`,
  the solved/certified set is unchanged. The only differences are MAYBE vs
  timeout classifications among unsolved examples.

Focused verification:

```console
cargo +1.95.0-x86_64-unknown-linux-gnu fmt

OPENSSL_DIR=/home/ucloud/miniforge3/envs/ferrum \
PKG_CONFIG_PATH=/home/ucloud/miniforge3/envs/ferrum/lib/pkgconfig \
cargo +1.95.0-x86_64-unknown-linux-gnu check --lib --jobs 32

OPENSSL_DIR=/home/ucloud/miniforge3/envs/ferrum \
PKG_CONFIG_PATH=/home/ucloud/miniforge3/envs/ferrum/lib/pkgconfig \
cargo +1.95.0-x86_64-unknown-linux-gnu test --lib strategy -- --nocapture

OPENSSL_DIR=/home/ucloud/miniforge3/envs/ferrum \
PKG_CONFIG_PATH=/home/ucloud/miniforge3/envs/ferrum/lib/pkgconfig \
cargo +1.95.0-x86_64-unknown-linux-gnu build --release --bin ferrum --jobs 64
```

## 2026-07-24 Paired-Tail Multi-Rule Certification

Ferrum's exact right-barren constructor now preserves one open-tail state per
strict RHS instead of forcing all RHS paths through one common tail. Missing
right-extension obligations are represented by epsilon links between existing
places. The emitted state-compatibility relation remains identity-only, so
CeTA's coherence check is not weakened.

The CeTA-rfc extension proves the paired-tail closure theorem and then applies
the generic accepted-start-set semantic theorem with a fresh constant chosen
for each tail. The executable checker requires:

- coverage of every strict RHS by the finite initial language;
- pairwise acceptance of each initial term from its supplied tail;
- every supplied tail to occur among the automaton RHS states; and
- all existing RFC closure, no-top-redex, and relative-bounds obligations.

Coverage is set-like (`rfc_initial_covers`), not list-order equality. This is
needed because CPF parsing normalizes rule order and is harmless: the checker
locates the matching RHS and uses the tail at that initial term's index.

Focused direct-`RelRFCmb{-1}` comparison:

| Run | YES | Certified YES | MAYBE | Timeout | Cert failed |
| --- | ---: | ---: | ---: | ---: | ---: |
| `20260723-rfc-tail-anchor-runtime-fixed-189-32w-20s` | 8 | 8 | 147 | 34 | 0 |
| `20260724-rfc-paired-v2-189-32w-20s` | 12 | 12 | 139 | 38 | 0 |

The four additional certified examples are
`ICFP_2010/{3770,4002,4046,64160}.ari`. This validates the paired-tail model
and removes certification as the blocker for this witness class. The larger
Matchbox gap remains in witness discovery: quotient/merge choices, richer
epsilon saturation, and certified SRS preprocessing around RFC.

## Large-witness signal

Raising the focused caps to 10,000 states and 250,000 transitions produces a
real bound-0 witness for `ICFP_2010/107193.ari` in about 11.5 seconds:

- 2,044 states;
- 1,971 symbol transitions;
- 3,471 epsilon transitions;
- 5,442 transitions in total.

After canonical identity-relation export and formally verified set-level
closure/right-extension checks, CeTA certifies this proof in about 155 seconds.
Thus both search and trusted certification work for this larger witness class.
The limiting factor is now witness/checking size, not missing semantics.

The next power-oriented strengthening should search quotient/merge choices
that reduce automaton size before adding more transitions. This simultaneously
improves Ferrum's cap headroom and CeTA's closure, extension, and no-top costs.
On the checker side, a verified unary-word reachability table would avoid
re-evaluating the same automaton words across rules and tail states.

The fixed-189 impact run confirms this prioritization:

| Configuration | YES | Certified in 40s | MAYBE | Checker timeout |
| --- | ---: | ---: | ---: | ---: |
| 2,000 states / 50,000 transitions | 12 | 12 | 139 | 0 |
| 10,000 states / 250,000 transitions | 155 | 101 | 34 | 54 |

There are 143 new YES results and no losses. All certification failures are
timeouts. Ferrum proof finding is therefore already strong on this direct RFC
slice; shrinking witnesses and accelerating the formally checked unary
automaton operations have higher immediate value than adding another RFC
candidate family.

## 2026-07-24 Batched Epsilon Closure and SCC Quotienting

Ferrum now avoids recomputing transitive epsilon closure after every
Matchbox-style extension edge. A completion round:

1. evaluates unary words through a dense bitset state index;
2. collects all required epsilon edges from one immutable automaton snapshot;
3. computes their joint transitive closure once with bitset Warshall; and
4. quotients mutually epsilon-reachable states before the next closure round.

The quotient remaps symbol transitions, explicit epsilon transitions, final
states, paired initial tails, and the state-compatibility relation. It therefore
preserves the accepted language represented by the automaton. Ferrum still
checks paired initial acceptance, Matchbox closure, right extension, no
top-level redex, and all configured size limits before emitting a proof. CeTA
then independently checks the resulting CPF certificate.

The direct unmodified right-barren automaton is also checked before adding
paired root-to-tail links. This is useful when the imported Matchbox witness
already satisfies the formally verified paired-initial condition and avoids
unnecessary completion work; the established linked construction remains the
fallback.

Focused verification:

- all 17 active `rfc_` tests pass; one diagnostic test remains ignored;
- dedicated tests compare batched closure with incremental closure and the
  bitset evaluator with the reference word evaluator;
- `ICFP_2010/64160.ari` produces a bound-0 paired-tail proof in 22 ms and the
  branch-built CeTA returns `CERTIFIED`.

Impact on the fixed 189 direct-`RelRFCmb{-1}` set at a 40-second external
timeout:

| Slice | YES | Certified YES | MAYBE | Losses | Cert failures |
| --- | ---: | ---: | ---: | ---: | ---: |
| previously solved 155 | 155 | 155 | 0 | 0 | 0 |
| previous 34 misses | 1 | 1 | 33 | 0 | 0 |
| combined | 156 | 156 | 33 | 0 | 0 |

The new certified result is `ICFP_2010/160263.ari`, previously a 30-second
UNKNOWN. It now completes proof search in 65 ms. Its automaton contracts from
316 to 306 states, and its batched extension closure takes 1 ms.

Full artifacts:

- `target/termcomp-runs/20260724-rfc-batched-epsilon-prevyes155-32w-40s`
- `target/termcomp-runs/20260724-rfc-batched-epsilon-unknown34-32w-40s-v2`
- `target/rfc-batched-epsilon-cert-20260724/64160`

## 2026-07-24 Strict Completion and Bound-Priority Search

The remaining gap was not an all-tail evaluator. ID-only bitset evaluation
reduced extension on `ICFP_2010/140639.ari` from roughly 211 ms to 27-40 ms and
exposed two semantic/search issues:

1. closure could find an accepted LHS with no RHS run and decline instead of
   adding an epsilon edge to the rule's canonical tail;
2. the paired-tail fixed point completed closure and extension but left strict
   below-top compatibility to the final validator.

Both obligations are now completed together. On `140639`, the bound-1 witness
adds 17 strict-compatibility transitions, reaches a fixed point in about
0.5 seconds, and produces a 1.14 MiB CPF accepted by the verified CeTA checker.

The final eight misses then revealed an ordering issue: after a bound-0 barren
candidate failed no-top, expensive fallback completion consumed the full
30-second processor timeout. Ferrum now tries barren completion at all bounds
before entering a second pass for the one-state and generic fallbacks. This
retains the same candidate families and solved all eight immediately.

Final impact on the fixed 189 direct-`RelRFCmb{-1}` examples:

| Slice | YES | Certified YES | MAYBE | Timeout | Cert failures |
| --- | ---: | ---: | ---: | ---: | ---: |
| retained prior YES | 155 | 155 | 0 | 0 | 0 |
| former misses | 34 | 34 | 0 | 0 | 0 |
| unified run | 189 | 189 | 0 | 0 | 0 |

The unified 32-worker run completed in 64 seconds. Full artifacts are in
`target/termcomp-runs/20260724-rfc-complete-certified189-32w-40s`.

## 2026-07-24 Broader Matchbox RFC Corpus

The same certified direct-RFC strategy was run on all 653 SRS Standard
problems for which the TermCOMP 2025 Matchbox proof corpus records RFC
evidence. The run used 32 workers, a 40-second external timeout, and a
30-second RFC processor timeout. It retained per-example commands, progress
events, stdout/stderr, CPF certificates, and CeTA output in:

```text
target/termcomp-runs/20260724-rfc-broader653-32w-40s
```

| Problems | YES | Certified YES | MAYBE | Timeout | Cert failures |
| ---: | ---: | ---: | ---: | ---: | ---: |
| 653 | 279 | 279 | 359 | 15 | 0 |

Correlating these results with
`target/termcomp-proof-corpus/y2025-rfc-srs-standard-supported-preprocessing-targets.csv`
shows where the remaining gap lies:

| Matchbox proof class | Problems | Ferrum YES | MAYBE | Timeout |
| --- | ---: | ---: | ---: | ---: |
| direct RFC | 471 | 277 | 192 | 2 |
| iterated RFC | 137 | 0 | 129 | 8 |
| needs tiling | 45 | 2 | 38 | 5 |

The direct class further separates by Matchbox's reported actual height:

| Direct mode | Problems | Ferrum YES | MAYBE | Timeout |
| --- | ---: | ---: | ---: | ---: |
| `RelRFCmb{-1}` | 294 | 265 | 28 | 1 |
| `RelRFCmb{1}` | 176 | 12 | 163 | 1 |
| `RelRFCmb{2}` | 1 | 0 | 1 | 0 |

The fixed plain one-step `RelRFCmb{-1}` slice accounts for 189 of the 189
certified successes documented above. The other 105 height-minus-one proofs
use a preceding weight transformation; Ferrum solves 76 of them.

This makes true height-aware barren completion the next direct RFC target.
Matchbox's `wanted_for_inner` links a redex path at minimum height `h` to the
rule's RHS places at `min(bound, h + 1)`, while merge mode retains exactly the
rules whose recorded top reaches the bound. Ferrum should preserve this
layered place/epsilon construction through CPF export instead of completing
the imported automaton with generic fresh RHS paths.

Two plausible shortcuts were tested and deliberately discarded:

- importing every RHS place level did not solve `Zantema_04/{z038,z040}` and
  increased the `z038` automaton from 382 to 444 states;
- satisfying below-top compatibility by adding only a state-relation pair
  produced a local `YES`, but CeTA rejected `z051` because that relation was
  not state-coherent;
- replacing the relation pair with a sound epsilon bridge retained CeTA
  certification where it completed, but caused a formerly fast `z051`
  witness to exceed 30 seconds through reachability feedback.

The production implementation was restored after these experiments. The next
implementation should therefore expose Matchbox's bounded layered merge
witness directly and test it first on the small actual-height-one misses
`Zantema_04/{z004,z006,z038,z040}`, while retaining
`Zantema_04/{z051,z053}` as certification and performance regressions.
