# Iterative TPDB and Canonical-State Campaign

Date: 2026-07-24

## Objective

Build an increasingly diverse processor-attempt corpus by alternating:

1. full Ferrum runs over TPDB root problems, which discover proof paths and
   current TRS/DP subproblems; and
2. canonical-state campaigns, which exploit, tighten, explore, and search for
   counterexamples on those subproblems.

After each phase, rebuild the canonical database and utility oracle. The next
full TPDB run then follows improved choices into different/deeper subproblems,
which seed the next canonical-state phase.

This is a closed loop:

```text
TPDB roots -> events -> canonical database -> state probes -> events
     ^                                                   |
     +--------------- rebuilt oracle/model -------------+
```

## Current Scale

Available TPDB categories:

| category | inputs |
|---|---:|
| TRS Standard | 1,528 |
| TRS Innermost | 366 |
| SRS Standard | 1,921 |
| TRS Context-sensitive | 108 |
| total | 3,923 |

There is no separate SRS Innermost directory in this TPDB checkout.

Current canonical database:

| state/evidence class | count |
|---|---:|
| canonical states | 24,790 |
| top-level states | 5,341 |
| DP states | 19,449 |
| states with any positive candidate | 4,834 |
| states with parameterized positive candidate | 3,340 |
| states with timeout evidence | 11,206 |
| states without positive evidence | 19,956 |

The previous 300-second event runs consumed about 331,568 aggregate
example-seconds. At eight workers this is an approximate 11.5-hour wall-clock
upper bound for one full four-category round. Compact content-addressed events
should substantially reduce the previous 21+ GiB event payload.

## Implementation

The resumable orchestrator is
`scripts/run_iterative_data_campaign.py`. It does not replace either existing
worker:

- `scripts/collect_processor_events.py` remains the isolated TPDB executor.
- `scripts/run_canonical_processor_campaign.py` remains the canonical probe
  executor.
- the orchestrator owns round manifests, immutable input lists, phase status,
  aggregation, oracle export, and promotion to the next phase.

`scripts/collect_processor_events.py` writes an atomic result record for each
root and resumes from those records. It accepts several `--category-root`
arguments, deterministically interleaves their inputs, passes the current
utility manifest and timeout multiplier to Ferrum, and retains CPF 3 and CeTA
output for decisive results.

Each aggregation starts from a fresh reflink/copy of the preceding immutable
SQLite generation. An interrupted aggregation is rebuilt from that generation,
so retrying cannot duplicate observations.

Every decisive root proof must retain CPF and CeTA output. Every decisive
canonical fragment should retain its DP/TRS witness and fragment-checker
result when supported. Diagnostic results must remain marked
`diagnostic_only`; they are evidence about a canonical state, not necessarily
a result that can be lifted through its originating branch.

The two initial rounds use:

| round | starting oracle | root multiplier | external root cap | fragment cap |
|---|---|---:|---:|---:|
| R00 | current utility-guidance v2 | 0.25 | 75 s | 250 ms |
| R01 | R00 final oracle | 0.50 | 150 s | 500 ms |

R01 promotes at most one timed-out R00 atom per canonical state. Known positive
atoms are retained in the oracle but not replayed by canonical probing.

```bash
python scripts/run_iterative_data_campaign.py \
  --campaign-dir target/data-campaign/oracle-two-round-20260724 \
  --jobs 8 \
  --rayon-threads 8
```

The command is safe to invoke again after interruption.

## Immutable Round Layout

```text
target/data-campaign/<campaign-id>/
  campaign.json
  canonical-cache.sqlite
  corpus/
    events.manifest.jsonl
    aggregate-rNN.sqlite
    oracle-rNN.jsonl
  rounds/rNN/
    root/
      task-ledger.sqlite
      <category>/per-problem/...
      events.jsonl.zst
      summary.json
    canonical/
      task-ledger.sqlite
      processor-events.jsonl.zst
      summary.json
    evaluation/
      termcomp-results.json
      certification-summary.json
    round-summary.json
```

Raw event files are immutable. Aggregation uses a materialized manifest of
their SHA-256 hashes, so rebuilding never accidentally ingests a file twice.
Canonicalization uses the persistent hash cache.

## One Round

### A. Full TPDB discovery

Run all 3,923 roots, interleaving categories in a deterministic shuffled order
instead of completing the long SRS category last. Use:

- 8 outer workers;
- at most 8 Rayon threads per Ferrum process;
- whole-process memory guard at 2 TiB system pressure;
- per-example process groups and hard external timeout;
- current utility oracle first, complete default strategy as fallback;
- full processor events, proof witnesses, stdout/stderr, progress, and CPF;
- immediate CeTA checking for YES/NO roots.

Interleaving should be weighted round-robin by remaining category size. This
provides early evidence from every problem class and more stable ETA/memory
signals.

### B. Aggregate and rebuild

1. Seal and hash the root event files.
2. Canonicalize only unseen CPF hashes using the persistent cache.
3. Join all accepted historical and current events.
4. Propagate proof-path credit.
5. Preserve validity masks and diagnostic labels.
6. Export utility-guidance v2.
7. Record state growth, candidate growth, and changed best candidates.

Certified proof-path imports record certification per observation and
aggregate it into `candidates.certified_count`. The runtime may tighten such a
favorite before replaying it, but must keep the exact certified atom in the
same portfolio. Uncertified historical positives remain usable evidence but
are not automatically tightened.

Raw hashes from every exact current CPF are exported as aliases to their
canonical record. Runtime lookup therefore checks the raw residual first and
only invokes canonicalization when a state has no known alias. Oracle guidance
is recursive: transformed top-level and DP obligations are queried again
before falling back to the normal strategy.

### C. Canonical-state interrogation

For each current canonical state, select tasks from four lanes:

| lane | eligibility | initial allocation |
|---|---|---:|
| exploit | positive evidence exists | best 1 untried-at-budget atom |
| tighten | parameterized positive evidence exists | best 2 smaller variants |
| explore | no attempt for candidate on state | 1 diverse under-tested atom |
| counterexample | validity mask contains 2 or 4 | required opposite decision |

Selection rules:

- Key trials by `(state, atom, processor revision, backend fingerprint,
  budget)`.
- Never rerun a solved or progress-producing trial at the same state, atom,
  processor revision, and backend merely because a new round started. Keep it
  in the oracle and let full root runs use it to reach deeper states.
- A success at one budget is also a success at every larger budget; do not
  rerun it only to raise the timeout.
- Revisit a positive only when tightening parameters, when its processor or
  backend implementation changed, when canonicalization/proof validation
  changed materially, or in a small explicit latency-calibration sample.
- A completed failure is semantic evidence at that parameter setting. Do not
  retry it with more time unless the backend reported `unknown` rather than a
  proved unsatisfiable/inapplicable result.
- A timeout is censored evidence, not a failure. Fork it into:
  1. the identical atom at the next timeout budget; and
  2. one or two smaller semantic search classes at the current budget.
- Label restricted timeout descendants `timeout-tighten`: their source atom is
  not known to contain a witness, unlike ordinary tightening.
- Promote a timed-out `(state, atom)` at most once per round and at most twice
  over the campaign unless it recorded measurable progress.
- Do not enlarge semantic bounds directly after a timeout. Enlarge after a
  completed unsatisfiable/failed search; after timeout, first retry with more
  time or a smaller search class.
- Prefer rare processor families during exploration until family coverage is
  approximately balanced.
- Within a family, prefer candidates with good global utility but low local
  attempt count.
- Keep at least 25% of exploration slots for globally rare leaf processors.
- Tightening stops along a parameter coordinate once a smaller value fails,
  unless another successful coordinate combination justifies reopening it.
- A successful tightened atom supersedes the looser atom in oracle ordering,
  but the looser witness remains in the corpus.
- Sound/incomplete states receive diagnostic NO search.
- Unsound/complete states receive diagnostic YES search.
- Diagnostic results never bypass branch validity checks.

Parameter-lattice policy:

| observation | next action |
|---|---|
| solved | descend toward a minimal witness |
| transformed | retain it and descend cautiously |
| failed/unsat | expand to the next larger proof class |
| timeout | promote time and separately restrict the proof class |
| solver unknown/error | try another backend before changing parameters |

The event/ledger schema must distinguish `unsat`, `inapplicable`, `unknown`,
`cancelled`, `timeout`, and backend error. A parallel sibling cancelled after
another branch succeeds is right-censored, not failed or timed out.

### D. Rebuild again

Aggregate canonical events immediately. This captures states produced inside
the exact processor probes and makes them available to the next root round.
Export the next oracle only after this second aggregation.

### E. Frozen evaluation

Run the TermCOMP 2025 Standard and Innermost sets with:

- 60-second score profile;
- 300-second capability profile;
- CeTA certification;
- oracle hit/success/fallback statistics;
- no ingestion of evaluation events into the current round.

Track YES, NO, certified YES/NO, MAYBE, timeout, certification gap, oracle
coverage, and wall time. Promotion requires no loss of certified results
unless a correctness fix intentionally removes an invalid proof.

## Budget Ladder

Use broad cheap rounds before expensive targeted rounds:

| round | full-root timeout multiplier | canonical atom budget | purpose |
|---|---:|---:|---|
| R00 | 0.25 | 250 ms | broad state/family coverage |
| R01 | 0.50 | 500 ms | verify quick progress and cheap tightening |
| R02 | 1.00 | 2 s | standard capability round |
| R03 | 0.25 | 4 s for promoted timeouts only | fresh roots, deeper ambiguous states |
| R04 | 1.00 | 8 s for promoted/rare candidates | consolidation |

After R04, repeat the R00-R04 shape with the new oracle, not the old task
set. Timeout multipliers 2 and 4 are targeted to unresolved root examples and
promoted candidates, rather than multiplying all 3,923 roots. Each fifth round
must still be a full 1.0 root run to measure global drift.

Canonical timeout promotion uses 250 ms, 500 ms, 2 s, 8 s, and optionally
30 s. The 30-second level is reserved for candidates that made progress before
timing out, succeeded on a structurally related state, or belong to a
high-yield family with systematic timeout pressure. Enforce a cumulative
promoted-time cap per state.

Expected initial canonical task count is roughly:

- up to 4,834 exploit trials;
- up to 6,680 tightening trials;
- up to 24,790 exploration trials;
- validity-dependent diagnostic trials.

This is about 36,000 tasks before counterexample probes, not the Cartesian
product of states and processors. At a 2-second hard bound and eight workers,
the absolute upper bound is about 2.5 hours; observed processor times suggest
substantially less.

## Exploration Policy

The exploration universe comes from the checked-in leaf-processor registry and
valid parameter templates, not only candidates already observed in the
database. Otherwise historically absent processors can never be discovered.
Filter by syntactic applicability (problem kind, level, rewrite strategy), but
never use the oracle outcome prediction as a hard applicability filter.

Allocate exploration slots within every `(problem kind, level)` stratum:

- 50% utility-weighted;
- 25% least-tried applicable processor families;
- 15% parameter neighbors around successful/failed boundaries;
- 10% uniform random applicable leaf families.

Choose utility-weighted candidates by:

```text
score =
    global_utility
  + rarity_bonus
  + state_family_novelty
  + uncertainty_bonus
  - expected_time_penalty
  - local_failure_penalty
  - timeout_penalty
```

Use deterministic seeded sampling from the resulting distribution, not always
the argmax. Store the score components and seed in the task ledger. This gives
diversity while preserving reproducibility.

Exploration safeguards:

- set a per-round attempt floor for each applicable family;
- cap one family at 20% of exploration within a stratum;
- group canonical duplicates before sampling;
- sample separately from unseen, negative-only, timeout-heavy, and positive
  state cohorts;
- reserve half of exploration on new states for families absent from the
  parent proof path;
- record each task's sampling probability for later propensity-weighted
  evaluation.

Report family coverage, family entropy, fraction outside the oracle top 3,
new-positive yield per CPU-second, timeout/cancellation rates, unseen
`(state, family)` pairs, and state growth attributable to exploration. If
entropy or outside-top-3 coverage declines for two rounds, increase the
least-tried and uniform allocations before increasing timeouts.

## Oracle Utility

### Dual canonical/raw index

The utility manifest keeps one authoritative evidence record per canonical CPF
state and emits aliases for every exact raw CPF hash in the persistent
canonicalization cache. At runtime Ferrum hashes the current, non-canonical
TRS or DP CPF first. An alias hit returns the canonical state's evidence
without invoking the standardizer. Only a raw miss triggers canonicalization
and a second lookup. Guidance events distinguish
`utility-lookup-raw` from `utility-lookup-canonical`.

This preserves name- and order-invariant learning while making repeated known
partial states cheap. New processor events contain the exact current
non-canonical CPF and are canonicalized offline; this grows both the canonical
evidence database and its raw alias index. DP fallback canonicalization jointly
standardizes the rules and dependency pairs, so their shared signature remains
consistent.

### Partial certification

Canonical probes request CPF output for every positive result. A solved partial
problem is checked as an ordinary complete CPF. A genuine transformation is
checked with the verified assumption-capable CeTA build and labeled
`certified-fragment`: this certifies the processor step and exact residual
obligation, not termination of the campaign root. The SQLite ledger records
checker status, return code, elapsed time, output, and retained certificate
path. Inputs, certificates, and checker logs are stored under the probe
round's sharded `artifacts/` directory.

Unsupported-only `Proof::unknown` values are failures, not transformations.
The ingestion pass repairs this historical event-labeling bug by recognizing
the old one-step `Unsupported` witness. New probes use checkable proof steps
directly, and rule-removal probes stop after one processor application instead
of spending their atom budget recursively solving the residual.

The current oracle does prefer faster successes, but only weakly:

```text
utility =
    sum(outcome rewards)
  - min(best_elapsed_ms / 1000, 300)
```

A solved observation contributes 1,000 points, so raw repeat counts can
overwhelm latency, and `best_elapsed_ms` favors a lucky fastest run. Before the
production campaign, replace this with a reliability- and time-aware estimate:

```text
expected_utility =
    P(solved) * solved_value
  + P(strong_progress) * progress_value
  + P(weak_progress) * weak_value
  - expected_wall_time_cost
  - failure_and_timeout_risk
```

Rank scheduling candidates primarily by expected utility per second, while
retaining an absolute expected-value floor so a very cheap but useless
processor cannot dominate. Estimate time from a robust median/EWMA by
`(state-shape, family, parameter class, backend, budget)`, treating timeouts
and cancellations as censored observations.

Deduplicate repeated deterministic successes before estimating reliability.
Full root rounds may encounter the same canonical `(state, atom)` many times;
those repetitions can update a separately maintained latency distribution but
must not add another 1,000-point success reward. Use a 1-2% stable calibration
cohort when fresh timing samples are needed.

## Counterexample Semantics

Validity masks describe how a canonical state was reached:

- mask 2 (sound/incomplete): search for NO. A found loop is evidence that the
  selected residual is nonterminating, but cannot establish NO for the
  ancestor across the incomplete transformation.
- mask 4 (unsound/complete): search for YES. A found termination proof is
  evidence about the residual, but cannot establish YES for the ancestor
  across the unsound transformation.

Whole TRS states use the regular termination/nontermination portfolios.
Stored DP states use their exact pair set. Selective bounded DP transforms
clear completeness, so their residuals naturally enter the mask-2 cohort.

## Round Metrics

Each `round-summary.json` records:

- root inputs completed by category and budget;
- YES/NO/MAYBE/timeout/error;
- certified YES/NO and certification failures;
- event rows and compressed bytes;
- canonical states before/after, split by top-level/DP and validity mask;
- newly seen states and canonical collisions;
- attempts/outcomes by processor family and lane;
- tightened successes and parameter deltas;
- diagnostic YES/NO discoveries;
- oracle queries, hits, successful guided closures, and fallback closures;
- elapsed CPU/wall time and peak system memory;
- number of promoted timeout tasks;
- frozen evaluation deltas from the previous round.

## Stop and Promotion Criteria

Continue rounds while any of the following holds:

- canonical states grow by at least 0.5%;
- positive states grow by at least 0.25%;
- a processor family gains at least 25 new solved/strong states;
- certified TermCOMP YES+NO improves;
- oracle successful-use rate improves by at least one percentage point.

Stop the current budget ladder when two consecutive full 1.0 rounds satisfy
none of those conditions. Before stopping, run one consolidation round over:

- all untried tightening variants adjacent to a successful bound;
- all mask-2/mask-4 states without an opposite-direction attempt;
- all timeout candidates promoted to their final allowed budget;
- all processor families below the target exploration floor.

## Initial Execution Order

1. Implement the resumable root task ledger and round orchestrator.
2. Run a 32-root mixed-category R00 smoke.
3. Rebuild the database and verify state/validity growth.
4. Run its canonical phase and rebuild again.
5. Verify decisive root CPF with CeTA and decisive fragments where supported.
6. Run full R00 over all 3,923 roots.
7. Run canonical R00.
8. Evaluate and inspect round metrics.
9. Proceed through R01-R04, adjusting only documented promotion thresholds,
   not ad hoc candidate lists.

## Next Campaign After R01

The next campaign is a consolidation and precision round:

1. Freeze the union of all previously certified positive root witnesses. Do
   not rerun deterministic positive `(state, atom, implementation hash)` tasks;
   recheck their retained CPF with CeTA and use them as protected regressions.
2. Rebuild the dual raw/canonical oracle from R00, R01, and the certification
   gap reruns. Keep raw aliases for zero-cost known-state lookup and
   canonical evidence as the authoritative aggregate.
3. Run the full TPDB root lane at timeout multipliers `0.5`, `1.0`, and `2.0`.
   Schedule `0.25` only for atoms whose robust runtime estimate is below the
   resulting cap; promote censored timeouts rather than repeating all roots.
4. On every newly reached canonical partial state, run exploitation,
   least-tried-family exploration, parameter tightening, and validity-directed
   counterexample search. Certify solved states and transformed fragments
   before promotion.
5. Add a targeted innermost lane for partial SCT deletion, immediate SCC
   re-decomposition, `U(D')` usable rules, and the rewriting/instantiation
   sequences observed in the remaining AProVE applicative proofs.
6. Evaluate on a frozen TermCOMP 2025 root set and a frozen canonical-state
   holdout. Report union YES/NO, current-run YES/NO, certified alignment,
   oracle raw/canonical hit rates, avoided atoms, new states, family entropy,
   utility per CPU-second, timeout/cancellation rates, and memory peaks.

Promotion requires a CeTA-certified proof or fragment, a retained witness, and
an implementation hash. A current batch miss never deletes an older certified
favorite; it updates latency/failure evidence and may lower scheduling rank.

### Consolidation campaign launched 2026-07-25

The non-CSR part of this plan is running under:

```text
target/data-campaign/consolidation-20260725
```

Before launch, `scripts/freeze_certified_campaign_union.py` deduplicated and
rechecked the R00/R01 root proofs and canonical fragments. All 7,381 collected
non-CSR obligations certified again; there were no failures or checker
timeouts. The frozen manifest and content-addressed artifacts are in
`certified-union/`.

The R01 database was reflinked as the seed corpus and exported again with the
dual-key oracle. The resulting manifest has 67,999 authoritative canonical
states and 70,280 raw-hash aliases, with no duplicate keys. The campaign runs
the 3,815 inputs from `TRS_Standard`, `TRS_Innermost`, and `SRS_Standard`.
Native `TRS_Contextsensitive` inputs were excluded from this historical launch
while CPF4 certification was still being developed. They were subsequently
added to the shared oracle by the CSR cycles documented below.

Configured rounds are:

| Round | Multiplier | Root cap | Canonical cap |
| --- | ---: | ---: | ---: |
| c00 | 0.5 | 150 s | 500 ms |
| c01 | 1.0 | 300 s | 1,000 ms |
| c02 | 2.0 | 600 s | 2,000 ms |

Each round uses eight isolated root jobs and eight Rayon threads per job. The
whole-system memory guard remains 2 TiB. The exact release binary is pinned as
`bin/ferrum` with SHA-256
`efedd58d4ee9700311e9c389296380237c6f1cfd582a312fc7577c137c1d07b5`,
so concurrent builds cannot change the implementation during the campaign.

Canonical trial keys now include that binary implementation hash. A prior
certified `(state, atom)` is skipped only when its recorded hash matches;
certified results from an older implementation remain protected evidence but
are eligible for a current-implementation rerun. The root collector and outer
driver also propagate `SIGINT`/`SIGTERM` through all active per-example process
groups, preventing interrupted campaigns from leaving prover or solver
processes behind.

Controlled-restart attempts are non-committing: partial artifacts are removed
before retry, `cancelled` result markers are ignored, and active process groups
are terminated as a batch. This preserves the invariant that each per-problem
event file describes one committed attempt. Legacy
`SrsRfcRelativeMatchBounds` debug labels are repaired during oracle export to
the executable `rfc-relative-match-bounds(...)` leaf; the correction takes
effect at the c00-to-c01 oracle rebuild rather than mutating c00's seed.

### Adaptive exploration trial on TermCOMP 2025 TRS Standard

Before enabling broader exploration in the consolidation rounds, a paired
trial was run over every canonical state reached by the TermCOMP 2025
`TRS_Standard` roots in the seed corpus. This comprised 1,528 roots and 7,379
distinct current subproblems. Each state received one stable baseline
exploration candidate. Frequent uncovered states with at least 100 source
occurrences received up to three additional candidates from distinct,
least-tried processor families, under a global budget of 6,000 extra probes.
The actual schedule contained 7,376 baseline and 5,514 extra probes across
1,838 frequent uncovered DP states.

The 500 ms probes used eight outer jobs and eight Rayon threads per job. Pool
construction took about 100 seconds and the probe phase took 194 seconds
(1,536.6 aggregate trial-seconds). Results were:

| Lane | Probes | Raw positive | Certified positive | Timeout |
| --- | ---: | ---: | ---: | ---: |
| Baseline exploration | 7,376 | 420 | 412 | 1,187 |
| Extra distinct-family exploration | 5,514 | 86 | 4 | 719 |

Within the 1,838-state extra-probe cohort, the baseline certified four states
and the extra lane certified four different states, so their union doubled
coverage from four to eight. The four additions were terminating
semantic-labeling proofs for partial states originating at:

```text
Strategy_removed_AG01/#4.22.ari
AProVE_04/IJCAR_1.ari
Secret_05_TRS/aprove5.ari
AG01/#3.21.ari
```

The raw-positive count must not be used as the promotion signal. Of the 86
extra raw positives, 62 were nontermination results without supported CPF
exports and 20 were semantic-labeling proofs rejected by CeTA; only four
certified. Future adaptive scheduling must therefore retain uncertified
results as diagnostic/training evidence while promoting only certified
results. It should also mix confidence-weighted productive-family probes with
least-tried-family exploration instead of assigning the entire extra budget to
novelty. The retained trial ledger and artifacts are in:

```text
target/data-campaign/adaptive-trs-standard-termcomp2025-20260725
```

### External-proof-guided TRS Standard iteration

The next lane used AProVE and MU-TERM 2025 proof artifacts as candidate
evidence for the 747 roots unresolved by the retained 609-certified-YES run.
Exact AProVE states were reconstructed from CPF, including lookup-table
expansion for compact rule indices, and canonicalized through the persistent
hash cache. All 2,479 final hint keys matched exploration-database states.

The canonical scheduler now joins `--hinted-only` keys in SQLite before
loading CPF text and skips global candidate-pool construction when exploration
is disabled. On the same 20-task smoke this reduced startup plus execution
from about 80 seconds and 17 GiB RSS to 5.8 seconds.

The full evidence lane used 64 jobs, two Rayon threads per job, a 5-second
atom timeout, three proof-derived hints, and two tightening slots. Its 3,720
trials produced 1,425 positive fragments. After fixing one residual
Q-orientation gap, all 1,425 certify. Imported proof outcomes are not promoted
directly: the runtime oracle is rebuilt only from prior Ferrum evidence,
current run events, and Ferrum/CeTA-certified probe events.

| Generation | Root mode | New certified YES | Remaining |
| --- | --- | ---: | ---: |
| R00 | oracle only | 4 | 743 |
| R00 | oracle + fallback | 13 | 734 |
| R01 | oracle only on R00 remainder | 2 | 732 |
| R01 | oracle + fallback on R01 remainder | 1 | 731 |

The union with the retained baseline is 625 certified YES and 172 certified
NO. R00 fallback recorded 606 successful utility-guidance closures at partial
states, which explains why its complete-root gain is substantially larger
than oracle-only search. R01 adds the resulting raw aliases and failed/timeout
evidence without deleting previous certified favorites. After ingesting both
R01 evaluation streams and their three exact certified proofs, R02 contains
72,770 canonical states and 74,610 raw aliases at
`target/data-campaign/trs-standard-external-evidence-20260725/oracle-r02.jsonl`.
An exact R02 oracle-only replay over the original 747 unresolved roots solved
11, all certified, for a standalone no-fallback total of 620 certified YES and
172 certified NO.

Future example campaigns are capped at 64 concurrent examples. Canonical
preprocessing may also use 64 workers, but it does not launch prover examples.

### Shared-oracle CSR cycles with CPF4 (2026-07-25)

CSR evidence is not maintained in a separate oracle. The two TermCOMP 2025
`TRS_Contextsensitive` cycles start from the strongest retained TRS Standard
database and R02 oracle:

```text
target/data-campaign/trs-standard-external-evidence-20260725/oracle-promotion.sqlite
target/data-campaign/trs-standard-external-evidence-20260725/oracle-r02.jsonl
```

This lets CSR states enrich the same cumulative store that will seed the next
TRS Standard cycle and, later, TRS Innermost. Oracle export is monotone: every
prior key and candidate is retained while new canonical states and raw aliases
are added. Positive atoms are placed in `prefer` or `possible` only when their
campaign evidence has a successful CeTA certification; uncertified positives
remain in the event corpus but cannot guide runtime proof search.

Before promotion, the complete 108-problem CSR slice was rerun with the CPF4
binary and `/work/dfm/festschrift/CeTA-CSR/ceta`. It produced 58 YES, all 58
certified, 50 MAYBE, and no timeout, error, or certification failure. The
validation artifacts are retained at:

```text
target/termcomp-runs/20260725-csr-cpf4-shared-oracle-gate
```

The two-cycle command was:

```console
RAYON_NUM_THREADS=4 python scripts/run_iterative_data_campaign.py \
  --campaign-dir target/data-campaign/shared-oracle-csr-cpf4-two-cycle-correct-20260725 \
  --source-db target/data-campaign/trs-standard-external-evidence-20260725/oracle-promotion.sqlite \
  --source-oracle target/data-campaign/trs-standard-external-evidence-20260725/oracle-r02.jsonl \
  --canonical-cache target/termcomp-proof-corpus/training/canonical-cpf-cache.sqlite \
  --category-root ../TPDB-ARI/TRS_Contextsensitive \
  --ferrum target/csr-oracle-cpf4-build/release/ferrum \
  --ceta /work/dfm/festschrift/CeTA-CSR/ceta \
  --fragment-ceta .tools/ceta-relative-bounds.bin \
  --jobs 32 --rayon-threads 4 \
  --canonical-current-round-only \
  --frequent-explore 3 --frequency-threshold 1 \
  --extra-exploration-budget 500 \
  --round r00,1.0,305,5000,2800 \
  --round r01,1.0,305,10000,2801
```

Both root runs held 58 YES and 58 certified YES. R00 scheduled 865 current-state
probes: 143 solved, 665 failed, and 57 timed out; 89 solved probes certified
fully. R01 scheduled 848 probes: 91 solved, 653 failed, and 104 timed out; 66
solved probes certified fully. R01 reused timeout evidence from R00 and used a
10-second atom cap rather than R00's 5-second cap.

The seed had 147,380 manifest rows. R00 grew it to 148,731. R01's cycle export
initially contained 148,990 rows; a final direct export from the cumulative
R01 database and the original seed removed empty states supported only by
uncertified positive evidence, leaving 148,899 runtime rows. An explicit audit
found zero lost seed keys and zero lost candidates, with 1,519 new keyed rows.
In R00, utility guidance successfully applied at 95 DP
states but still encountered canonical fallback misses. After raw aliases were
promoted, R01 had no canonical lookup misses, 105 successful guided
applications, and three successful top-level CSR proposals. The final shared
database and oracle are:

```text
target/data-campaign/shared-oracle-csr-cpf4-two-cycle-correct-20260725/rounds/r01/corpus/aggregate-r01-final.sqlite
target/data-campaign/shared-oracle-csr-cpf4-two-cycle-correct-20260725/rounds/r01/corpus/oracle-r01-final.jsonl
```

Exact canonicalization used eight jobs and the persistent cache with a
600-second cap per distinct CPF. R00 canonicalized 485 new states, with two
timeouts; R01 canonicalized all 178 new states. The long tail dominated cycle
runtime but preserved exact, name-independent keys.
