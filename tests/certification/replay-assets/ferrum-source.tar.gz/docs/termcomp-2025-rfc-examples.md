# TermComp 2025 RFC Examples

This note records examples in the local TermComp 2025 proof corpus whose proof output explicitly uses RFC/right-forward match-bounds.

## Data Source

- Database: `target/termcomp-proof-corpus/proofs.sqlite`
- Artefacts: `target/termcomp-proof-corpus/artefacts/Y2025`
- Exact RFC markers used for this scan:
  - `RFC-matchbounded`
  - `method_ = RFC`
  - `RFCMatchBoundsProcessor`

The exact hit list is stored in:

- `target/termcomp-proof-corpus/y2025-rfc-actual-hit-paths.txt`

The joined benchmark list is stored in:

- `target/termcomp-proof-corpus/y2025-rfc-actual-yes-examples.csv`

## Result

The exact scan found 803 TermComp 2025 YES proof outputs with actual RFC markers.

| Category | Tool | Result | Certification | Examples |
| --- | --- | ---: | --- | ---: |
| SRS_Standard | matchbox-tc25.0 | YES | uncertified | 653 |
| SRS_Relative | matchbox-tc25.0 | YES | uncertified | 150 |

These are Matchbox text proofs, not certified CPF proofs. The official downloaded proof corpus did not contain certified SRS proof outputs with these exact RFC markers. Therefore these examples are useful as proof-search targets for Ferrum's RFC processor, but they are not themselves certified evidence unless Ferrum emits CPF and our CeTA extension accepts it.

## Parameter Evidence

Matchbox's RFC proof text exposes the RFC height bound and epsilon-transition count. Across the 803 exact RFC hits:

| Metric | p50 | p75 | p90 | p95 | p99 | Max |
| --- | ---: | ---: | ---: | ---: | ---: | ---: |
| RFC height bound | 2 | 2 | 2 | 2 | 2 | 3 |
| Epsilon transitions | 393 | 1,715 | 3,136 | 5,867 | 9,619 | 19,198 |
| State ids seen in epsilon transitions | 41 | 75 | 99 | 100 | 110 | 191 |
| Matchbox runtime, seconds | 0.737 | 1.111 | 1.639 | 2.414 | 6.462 | 43.835 |

Bound distribution:

| RFC height bound | Examples |
| ---: | ---: |
| 2 | 800 |
| 3 | 3 |

Implications for Ferrum's current default RFC branch:

- `max-bound=5` is more than enough for this evidence, and probably wastes search when used as a linear ladder. A better portfolio is a cheap `max-bound=2` branch followed by a `max-bound=3` branch.
- `max-transitions=20000` is too close to the largest Matchbox witness, because Ferrum's CPF automata include ordinary transitions in addition to RFC-related transitions and currently have weaker merging. Use at least `50000`; `100000` is safer for benchmark runs.
- `max-states=2000` is not contradicted by the Matchbox evidence. It is much larger than the state ids visible in the Matchbox text, but Ferrum may need more states because its automaton construction is less merged.
- `max-word-len=64` is plausible for most examples but not justified by Matchbox's reported witness fields. A rough source-size scan found some rule sides longer than 64 symbols, so cap failures must be logged separately before treating 64 as adequate.
- A 10 second RFC local timeout covers 798/803 Matchbox RFC runtimes if Ferrum were as fast as Matchbox. Since Ferrum's RFC implementation is less optimized and also prepares CPF, this should be treated as a good default fast-branch timeout, not as an adequate high-recall timeout.

## Matchbox Proof Structure

All 803 exact hits report `method_ = RFC`; no other `method_ = ...` value was found in these proof texts. However, the Matchbox skeletons are not all direct RFC on the original SRS. They often combine RFC with preprocessing and transformations.

Skeleton step counts across the 803 hits:

| Skeleton step | Occurrences |
| --- | ---: |
| `RelRFCmb` | 1,039 |
| `Weight` | 226 |
| `Mirror` | 115 |
| `Strictify` | 98 |
| `Split` | 66 |
| `TileAllAll` | 66 |
| `Cleaner` | 56 |
| `Matrix` | 34 |
| `Natural` | 34 |

Most common skeleton combinations:

| Skeleton combination | Examples |
| --- | ---: |
| `RelRFCmb` | 346 |
| `Weight; RelRFCmb` | 115 |
| `Strictify; RelRFCmb` | 56 |
| `Cleaner; RelRFCmb` | 50 |
| `RelRFCmb; RelRFCmb` | 50 |
| `Mirror; RelRFCmb; Mirror; RelRFCmb` | 22 |
| `RelRFCmb; Mirror; RelRFCmb` | 19 |

So the evidence says RFC is the central successful bounds method, but Matchbox is often using it inside a stronger SRS/relative-bounds strategy with cleaning, strictification, mirroring/reversal, splitting/tiling, and weighted/matrix/natural transformations.

## Ferrum Focused RFC Run

After changing the default RFC branch to:

```fs
timeout(20s, rfc-match-bounds(max-bound=3,max-words=10000,max-word-len=128,max-states=2000,max-transitions=50000))
```

a focused RFC-only run on these 803 examples used:

- Run directory: `target/termcomp-runs/20260718-083940-rfc-matchbox-803-32w-b3-w128-t50000-20s`
- Workers: 32
- External timeout: 30 seconds
- Strategy: `timeout(20s, rfc-match-bounds(max-bound=3,max-words=10000,max-word-len=128,max-states=2000,max-transitions=50000))`

| Category | Total | YES | Certified YES | MAYBE | Timeout | Certification failures |
| --- | ---: | ---: | ---: | ---: | ---: | ---: |
| SRS_Standard | 653 | 2 | 1 | 650 | 1 | 1 |
| SRS_Relative | 150 | 0 | 0 | 150 | 0 | 0 |

The certified YES was `SRS_Standard/Zantema_04/z061.ari`. The uncertified YES was `SRS_Standard/ICFP_2010/25192.ari`; CeTA rejected it because the emitted RFC initial language was not closed under one-step right-forward narrowing. This confirmed that the remaining gap is not mainly the numeric RFC bounds. Ferrum is missing Matchbox's surrounding SRS/relative RFC strategy and had an RFC closure/certificate mismatch on at least one generated witness.

Follow-up fix:

- Ferrum now declines RFC initial closures where narrowing produces the same SRS word with a rule-side fresh tail variable instead of the common CPF tail variable.
- This is conservative for the current CeTA checker, whose `rfc_initial_closed` test is syntactic.
- `SRS_Standard/ICFP_2010/25192.ari` now returns `Unknown` for the RFC-only strategy instead of an uncertified YES.
- `SRS_Standard/Zantema_04/z061.ari` still emits an RFC proof and certifies with `.tools/ceta-relative-bounds`.
- The higher-power CeTA extension would be to canonicalize single-open-variable RFC templates, or check `rfc_initial_closed` modulo alpha-renaming of the single tail variable. That would accept mathematically equivalent finite initial languages without requiring Ferrum to enumerate variable-name variants.

## Certified RFC-Relative Smoke Test

On 2026-07-18, Ferrum and the local CeTA RFC fork gained a conservative
termination-side RFC-relative proof object:

```xml
<rfcRelativeBounds>
  <initialTerms>...</initialTerms>
  <bounds>...</bounds>
  <trs>deleted rules</trs>
  <trsTerminationProof>...</trsTerminationProof>
</rfcRelativeBounds>
```

The currently verified checker accepts this tag only when the deleted rules are
exactly all current strict rules, the weak and Q components are empty, and the
problem is full rewriting rather than innermost rewriting. Under those side
conditions it reuses the verified finite-initial-language RFC theorem and does
not require global `lift0(T(Sigma))` automaton acceptance.

Validated real TPDB example:

```console
target/release/ferrum prove \
  /work/dfm/festschrift/TPDB-ARI/SRS_Standard/Zantema_04/z061.ari \
  --strategy 'rfc-relative-match-bounds(max-bound=3,max-words=10000,max-word-len=128,max-states=2000,max-transitions=50000)' \
  --cpf-mode cpf30 \
  --cpf target/rfc-relative-probe/z061.cpf3.xml

.tools/ceta-relative-bounds target/rfc-relative-probe/z061.cpf3.xml
```

Result: `CERTIFIED`.

This is a certified base for RFC-relative proof objects, but it is not yet
Matchbox-level `RelRFCmb`: merge-at-bound/epsilon semantics and non-empty
residual relative RFC deletion still require a stronger CPF/CeTA theorem and
matching Ferrum search.

## 653-Example RFC-Relative Focused Run

After adding the conservative `<rfcRelativeBounds>` checker, Ferrum was run on
the 653 `SRS_Standard` examples where Matchbox's TermComp 2025 proof output
contains an RFC marker.

Run directory:

```text
target/termcomp-runs/20260718-srs-standard-653-rfc-relative-32w-20s-rerun
```

Strategy:

```fs
rfc-relative-match-bounds(max-bound=3,max-words=10000,max-word-len=128,max-states=2000,max-transitions=50000)
```

Result:

| Total | YES | Certified YES | MAYBE | NO | Timeout | Error |
| ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| 653 | 1 | 1 | 652 | 0 | 0 | 0 |

The single YES/CERTIFIED YES is:

- `SRS_Standard/Zantema_04/z061.ari`

This confirms that the all-strict, exact finite-initial-language
RFC-relative certificate is correct but not materially stronger than the direct
RFC path. The missing Matchbox power is the approximate `RelRFCmb` processor,
especially `implementation = Approximate {at_bound = Merge}` with explicit
epsilon transitions.

Implementation note from the first experiment: simply capping strict RHS
heights at `max-bound` inside Ferrum's existing certified match-bounds
completion is not sufficient. CeTA rejected the resulting ordinary/relative
certificates because the automaton compatibility side condition can fail. The
next implementation needs an explicit Matchbox-style merge/epsilon proof object
and a corresponding CeTA theorem/checker extension rather than changing the
existing certified `<bounds>` semantics.

## CeTA Support For Matchbox Wrapper Steps

Current CeTA/CPF support relevant to the Matchbox skeletons:

| Matchbox-style step | CeTA/CPF support status | Notes |
| --- | --- | --- |
| RFC match-bounds / `RelRFCmb` | Partial local extension | Ferrum's patched CeTA supports direct `<rfcBounds>` for full, right-linear, non-relative TRSs with empty Q/weak components. It also supports conservative all-strict deletion via `<rfcRelativeBounds>`. Matchbox-style merge-at-bound relative RFC is not yet supported. |
| Ordinary match-bounds | Supported | Standard `<bounds><match/></bounds>`. |
| Relative match-bounds | Supported, with local extensions used by Ferrum | `<relativeBounds>` is parsed and checked. Ferrum currently uses conservative all-strict/all-residual forms. |
| Mirroring / reversal | Supported for SRS-shaped TRSs | CeTA has `string_reversal_tt`, and Ferrum emits `<stringReversal>`. |
| Splitting | Supported | CeTA has `<split>` / `<splitProc>` support. |
| Weighted / polynomial orders | Supported as reduction-pair/rule-removal certificates | CPF parser/checker supports polynomial interpretations, precedence weights, `redPairProc`, `monoRedPairProc`, and `ruleRemoval`. |
| Matrix interpretations | Supported | CPF parser/checker supports `<matrixInterpretation>`. |
| Natural interpretations/domains | Supported as interpretation domains | CPF parser has naturals and related interpretation carriers. |
| Cleaning | Not found as a Matchbox-style top-level SRS cleaner | Some simplifications can be represented by split/rule-removal/relative proof steps, but a direct `Cleaner` processor is not apparent. |
| Strictification | Not found as a dedicated top-level `Strictify` SRS processor | Relative termination infrastructure exists, but Matchbox's strictification skeleton step is not directly mirrored as a named CPF/CeTA step. |
| Tiling / `TileAllAll` | Not found as a dedicated processor | This looks Matchbox-specific and would need either encoding through existing certified processors or a new certified extension. |

## Sample SRS Standard Targets

- `SRS_Standard/Bouchare_06/02.ari`
- `SRS_Standard/Bouchare_06/12.ari`
- `SRS_Standard/CirponsMitchellSmith_25/no_subst_ababaabaaa_baaba.ari`
- `SRS_Standard/CirponsMitchellSmith_25/no_subst_baaaaababa_aaa.ari`
- `SRS_Standard/CirponsMitchellSmith_25/no_subst_baaaaababa_abbaaa.ari`
- `SRS_Standard/CirponsMitchellSmith_25/no_subst_baaaaababa_abbaaaa.ari`
- `SRS_Standard/CirponsMitchellSmith_25/no_subst_baaaabaaaa_aaba.ari`
- `SRS_Standard/CirponsMitchellSmith_25/no_subst_baaaabaaba_abaa.ari`
- `SRS_Standard/CirponsMitchellSmith_25/no_subst_baaaababa_abbaaa.ari`
- `SRS_Standard/CirponsMitchellSmith_25/no_subst_baaabaabba_abaa.ari`
- `SRS_Standard/CirponsMitchellSmith_25/no_subst_baababa_a.ari`
- `SRS_Standard/CirponsMitchellSmith_25/no_subst_babaaababa_abbabaa.ari`
- `SRS_Standard/CirponsMitchellSmith_25/no_subst_bababa_abba.ari`
- `SRS_Standard/ICFP_2010/107193.ari`
- `SRS_Standard/ICFP_2010/107220.ari`
- `SRS_Standard/ICFP_2010/107236.ari`
- `SRS_Standard/ICFP_2010/123759.ari`
- `SRS_Standard/ICFP_2010/124211.ari`
- `SRS_Standard/ICFP_2010/124269.ari`
- `SRS_Standard/ICFP_2010/124791.ari`
- `SRS_Standard/ICFP_2010/128056.ari`
- `SRS_Standard/ICFP_2010/128182.ari`
- `SRS_Standard/ICFP_2010/128430.ari`
- `SRS_Standard/ICFP_2010/128486.ari`
- `SRS_Standard/ICFP_2010/130304.ari`

## Sample SRS Relative Targets

- `SRS_Relative/ICFP_2010_relative/107220.ari`
- `SRS_Relative/ICFP_2010_relative/107236.ari`
- `SRS_Relative/ICFP_2010_relative/123759.ari`
- `SRS_Relative/ICFP_2010_relative/124211.ari`
- `SRS_Relative/ICFP_2010_relative/124269.ari`
- `SRS_Relative/ICFP_2010_relative/124791.ari`
- `SRS_Relative/ICFP_2010_relative/127538.ari`
- `SRS_Relative/ICFP_2010_relative/128056.ari`
- `SRS_Relative/ICFP_2010_relative/128182.ari`
- `SRS_Relative/ICFP_2010_relative/128280.ari`
- `SRS_Relative/ICFP_2010_relative/128430.ari`
- `SRS_Relative/ICFP_2010_relative/128691.ari`
- `SRS_Relative/ICFP_2010_relative/131633.ari`
- `SRS_Relative/ICFP_2010_relative/131982.ari`
- `SRS_Relative/ICFP_2010_relative/132235.ari`
- `SRS_Relative/ICFP_2010_relative/132540.ari`
- `SRS_Relative/ICFP_2010_relative/132622.ari`
- `SRS_Relative/ICFP_2010_relative/132738.ari`
- `SRS_Relative/ICFP_2010_relative/132833.ari`
- `SRS_Relative/ICFP_2010_relative/132920.ari`
- `SRS_Relative/ICFP_2010_relative/132957.ari`
- `SRS_Relative/ICFP_2010_relative/132969.ari`
- `SRS_Relative/ICFP_2010_relative/133010.ari`
- `SRS_Relative/ICFP_2010_relative/133159.ari`
- `SRS_Relative/ICFP_2010_relative/133486.ari`

## Reproduction

Regenerate the exact hit paths:

```sh
find target/termcomp-proof-corpus/artefacts/Y2025 -type f \
  | rg -i 'SRS_(Standard|Relative)' \
  | xargs -r rg -i -l 'RFC-matchbounded|method_ = RFC|RFCMatchBoundsProcessor' \
  > target/termcomp-proof-corpus/y2025-rfc-actual-hit-paths.txt
```

Join them back to the proof database:

```sh
sqlite3 target/termcomp-proof-corpus/proofs.sqlite <<'SQL'
.mode tabs
DROP TABLE IF EXISTS temp_rfc_hits;
CREATE TEMP TABLE temp_rfc_hits(path text);
.import target/termcomp-proof-corpus/y2025-rfc-actual-hit-paths.txt temp_rfc_hits
.headers on
.mode csv
.output target/termcomp-proof-corpus/y2025-rfc-actual-yes-examples.csv
select p.category, p.benchmark, p.tool, p.result, p.certification, p.detected_format, p.local_path
from proofs p join temp_rfc_hits h on p.local_path = h.path
where p.year = 2025 and p.result in ('YES', 'CERTIFIED YES')
order by p.category, p.benchmark, p.tool;
SQL
```

Summarize:

```sh
sqlite3 target/termcomp-proof-corpus/proofs.sqlite <<'SQL'
.mode tabs
DROP TABLE IF EXISTS temp_rfc_hits;
CREATE TEMP TABLE temp_rfc_hits(path text);
.import target/termcomp-proof-corpus/y2025-rfc-actual-hit-paths.txt temp_rfc_hits
.headers on
.mode csv
select p.category, p.tool, p.result, p.certification, count(*) as n
from proofs p join temp_rfc_hits h on p.local_path = h.path
where p.year = 2025 and p.result in ('YES', 'CERTIFIED YES')
group by p.category, p.tool, p.result, p.certification
order by p.category, p.tool, p.result, p.certification;
SQL
```

## Separate Local AProVE Hits

A separate scan of local AProVE cert-run artefacts found four TRS Standard outputs mentioning RFC/match-bounds-related processors:

- `TRS_Standard/Secret_07_TRS/1.ari`
- `TRS_Standard/Secret_07_TRS/4.ari`
- `TRS_Standard/Zantema_05/z12.ari`
- `TRS_Standard/Zantema_05/z30.ari`

Those artefacts are raw CPF2/conversion-error cases in `target/aprove-cert-runs/20260715-090022`, so they should be treated as hints for processor coverage, not as confirmed certified RFC examples.

## Matchbox SRS Standard Skeleton Classification

The 653 Matchbox SRS Standard YES proofs with actual RFC markers were classified by proof skeleton in
`target/termcomp-proof-corpus/y2025-rfc-srs-standard-supported-preprocessing-targets.csv`.

| Group | Count | Interpretation |
|---|---:|---|
| `direct-rfc` | 471 | No unsupported preprocessing and exactly one `RelRFCmb` step. This includes plain `RelRFCmb`, `Weight; RelRFCmb`, and `Mirror; RelRFCmb` skeletons. |
| `iterated-rfc` | 137 | No unsupported preprocessing, but multiple `RelRFCmb` steps. Ferrum needs certified relative/iterated RFC removal to reproduce these directly. |
| `needs-tiling` | 45 | Matchbox uses `TileAllAll`; Ferrum does not yet have the corresponding SRS tiling transformation/certificate path. |

The smallest direct-RFC examples are mostly `Zantema_04` one-rule systems:

```text
SRS_Standard/Zantema_04/z049.ari
SRS_Standard/Zantema_04/z050.ari
SRS_Standard/Zantema_04/z055.ari
SRS_Standard/Zantema_04/z062.ari
SRS_Standard/Zantema_04/z063.ari
SRS_Standard/Zantema_04/z033.ari
SRS_Standard/Secret_06_SRS/multum4.ari
```

Focused run:

```text
target/termcomp-runs/20260718-085806-rfc-matchbox-653-srs-standard-default-32w-60s
```

Result on the 653 examples:

| Status | Count |
|---|---:|
| YES | 113 |
| Certified YES | 113 |
| Unknown | 534 |
| Timeout | 6 |
| Certification failures | 0 |

All logged examples reached the RFC processor early; most RFC attempts failed in milliseconds. The dominant blocker is therefore not preprocessing before RFC, but the strength and certificate shape of the RFC/relative-RFC processor.

## Small Direct-RFC Probe

Focused probes were run with:

```sh
target/release/ferrum prove TPDB-ARI/SRS_Standard/Zantema_04/z033.ari \
  --strategy 'srs-relative-match-bounds(max-bound=5,max-states=2000,max-transitions=20000)' \
  --cpf-mode cpf30 --cpf target/rfc-small-reverted-check/z033.rel.cpf3.xml

target/release/ferrum prove TPDB-ARI/SRS_Standard/Zantema_04/z033.ari \
  --strategy 'rfc-match-bounds(max-bound=3,max-words=10000,max-word-len=128,max-states=2000,max-transitions=50000)' \
  --cpf-mode cpf30 --cpf target/rfc-small-reverted-check/z033.rfc.cpf3.xml
```

Current certified behavior:

| Example | Matchbox skeleton | Ferrum relative bounds | Ferrum RFC bounds |
|---|---|---|---|
| `SRS_Standard/Zantema_04/z049.ari` | `(1,2)\RelRFCmb{-1}(0,0)[]` | `CERTIFIED` at bound 0 | `UNKNOWN` |
| `SRS_Standard/Zantema_04/z061.ari` | `(1,3)\RelRFCmb{-1}(0,0)[]` | `CERTIFIED` at bound 0 | `CERTIFIED` at bound 0 |
| `SRS_Standard/Zantema_04/z033.ari` | `(1,2)\RelRFCmb{-1}(0,0)[]` with two epsilon transitions | `CERTIFIED` at bound 0 | `UNKNOWN` |

An experimental implementation of Matchbox-style `at_bound = Merge` by simply saturating strict successor heights inside Ferrum's existing `<relativeBounds><match/>` certificate was rejected by `.tools/ceta-relative-bounds`. For `z033`, CeTA reported that the generated automaton was not compatible with the TRS because the RHS required height-1 transitions while the saturated one-state automaton only contained height-0 transitions.

Conclusion: the high-impact strengthening is not a silent change to ordinary bounds completion. Ferrum needs a first-class, certified Matchbox-style `RelRFCmb` processor with explicit merge/epsilon semantics, or a corresponding CeTA/CPF extension. Existing exact relative bounds already covers some small `RelRFCmb` cases (`z049`, `z061`), but not epsilon/merge cases such as `z033`.

## 2026-07-18 RFC Merge Plumbing

Implemented Ferrum-side proof-object plumbing needed for Matchbox-style RFC
certificates:

- `BoundsProof` now carries a `state_compatibility` relation.
- CPF3 bounds export emits `<criterion><stateCompatibility><relation>...` when
  this relation is non-empty; otherwise it keeps the old `<compatibility/>`
  output.
- `.tools/ceta-relative-bounds` certifies a smoke certificate with an explicit
  identity state-compatibility relation.
- SRS match-bounds completion now returns a completion object containing the
  automaton and the state relation.
- The strategy language accepts `at-bound=exact|merge` for
  `rfc-match-bounds(...)` and `rfc-relative-match-bounds(...)`; `exact` remains
  the default.

Verification:

```sh
cargo +1.95.0 test --lib match_bounds -- --nocapture
cargo +1.95.0 test --lib state_compatibility -- --nocapture
cargo +1.95.0 build --release --jobs 64
```

All passed.

Targeted smoke checks:

```sh
target/release/ferrum prove /work/dfm/festschrift/TPDB-ARI/SRS_Standard/Zantema_04/z061.ari \
  --strategy 'rfc-relative-match-bounds(max-bound=3,max-words=10000,max-word-len=128,max-states=2000,max-transitions=50000,at-bound=exact)' \
  --cpf-mode cpf30 --cpf /tmp/ferrum-z061-rfc-exact.cpf3.xml
.tools/ceta-relative-bounds /tmp/ferrum-z061-rfc-exact.cpf3.xml

target/release/ferrum prove /work/dfm/festschrift/TPDB-ARI/SRS_Standard/Zantema_04/z061.ari \
  --strategy 'rfc-relative-match-bounds(max-bound=3,max-words=10000,max-word-len=128,max-states=2000,max-transitions=50000,at-bound=merge)' \
  --cpf-mode cpf30 --cpf /tmp/ferrum-z061-rfc-merge.cpf3.xml
.tools/ceta-relative-bounds /tmp/ferrum-z061-rfc-merge.cpf3.xml
```

Both certify. The generated proof for `z061` does not actually need merge, so
this only confirms that the new parameter path did not regress existing RFC
certification.

Negative probes:

```text
SRS_Standard/Zantema_04/z031.ari
SRS_Standard/ICFP_2010/3927.ari
SRS_Standard/ICFP_2010/212774.ari
```

These still return `UNKNOWN` with
`rfc-relative-match-bounds(...,at-bound=merge)` even with larger
`max-words=100000,max-word-len=1024`. The blocker is not just transition-height
merging. Ferrum currently enumerates a finite RFC initial language and the
patched CeTA theorem checks `rfc_initial_closed`; Matchbox `RelRFCmb` proves
closure by automaton acceptance/epsilon-merge semantics. The next certified
step is therefore a CeTA/CPF extension for automaton-closed RFC, not broader
finite-list enumeration.

## 2026-07-22 Certified Automaton-Closed RFC Smoke

CeTA-rfc now proves and exports a checker equation for
`<rfcAutomatonClosedRelativeBounds>` via
`rfc_automaton_closed_relative_bounds_tt`. The executable checker must be
compiled from the Isabelle `Code` session export, not from the stale checked-in
`thys/Code/Bar` Haskell files.

Final export used for the smoke test:

```text
/work/dfm/festschrift/CeTA-rfc/thys/Code/Bar-rfc-final-20260722-184431/export1
```

Installed checker:

```text
/work/dfm/festschrift/ferrum/.tools/ceta-relative-bounds
```

Smoke run:

```text
target/rfc-certified-smoke-current-20260722-184244
```

Candidate examples were representative SRS systems where Matchbox/AProVE solve
the TermCOMP 2025 instance by bounds-style reasoning:

```text
SRS_Standard/Zantema_04/z061.ari
SRS_Standard/Zantema_04/z031.ari
SRS_Standard/Zantema_04/z114.ari
SRS_Standard/Bouchare_06/02.ari
SRS_Standard/Bouchare_06/03.ari
SRS_Standard/Bouchare_06/12.ari
SRS_Standard/Gebhardt_06/02.ari
SRS_Standard/Gebhardt_06/12.ari
SRS_Standard/ICFP_2010/25192.ari
SRS_Standard/ICFP_2010/123759.ari
SRS_Standard/ICFP_2010/107193.ari
SRS_Standard/ICFP_2010/124211.ari
```

Result with 30s per example:

| Mode | YES | Certified YES | MAYBE | Timeout |
| --- | ---: | ---: | ---: | ---: |
| `rfc-match-bounds(...,at-bound=exact)` | 1 | 1 | 6 | 5 |
| `rfc-relative-match-bounds(...,at-bound=exact)` | 1 | 1 | 11 | 0 |

The only certified example in this smoke set is still
`SRS_Standard/Zantema_04/z061.ari`; it certifies both as finite
`<rfcBounds>` and finite `<rfcRelativeBounds>`. The new executable checker does
not yet yield additional certified TermCOMP YESs from Ferrum's current witness
generation.

The older automaton-focused run

```text
target/termcomp-runs/20260718-srs-unsolved-256-rfc-automaton-64w-20s
```

contains 15 `<rfcAutomatonClosedBounds>` certificates generated by the earlier
merge-style approximation. Rechecking them with the final checker rejected all
15; the first failure is the certified `lhs suffix totality` condition on
`SRS_Standard/Bouchare_06/01.ari`. This is expected for those witnesses: they
are not valid for the conservative exact automaton-closed theorem. The
remaining high-impact proof-search/certification gap is still first-class
Matchbox-style merge/epsilon `RelRFCmb` semantics.

## 2026-07-22 Certified Matchbox Relative Bounds

Ferrum now has a distinct `ProofStep::RfcMatchboxRelativeBounds` and exports it
as a local CPF extension element:

```xml
<rfcMatchboxRelativeBounds>...</rfcMatchboxRelativeBounds>
```

The CeTA-rfc fork now parses this element and checks it through
`rfc_matchbox_relative_bounds_tt`. The entry point is backed by the verified
Matchbox-style merge/epsilon closure theorem: accepted proofs must satisfy
all-state initial acceptance, Matchbox split closure through the explicit
state-compatibility relation, lhs suffix totality, local bounds compatibility,
and no top-layer redex for the deleted rules. Ferrum constructs the required
state-compatibility pairs for
`rfc-relative-match-bounds(...,at-bound=merge)` and emits explicit identity
pairs whenever the compatibility relation is non-empty.

Verified build/export steps:

```text
isabelle build -v -o timeout=1800 -j 128 -d /work/dfm/festschrift/CeTA-rfc/thys RFC_Checker_Ext
isabelle build -v -o timeout=1800 -j 128 -d /work/dfm/festschrift/CeTA-rfc/thys Proof_Checker
isabelle build -v -o timeout=1800 -j 128 -d /work/dfm/festschrift/CeTA-rfc/thys Code
```

Fresh code export used for the installed checker:

```text
/tmp/ceta-rfc-matchbox-export-20260722-224238/export1
```

Smoke test:

```text
cat target/rfc-matchbox-automaton-smoke/ab-c.ari
(format TRS)
(fun a 1)
(fun b 1)
(fun c 1)
(rule (a (b x)) (c x))

cargo +1.95.0-x86_64-unknown-linux-gnu run -- prove \
  target/rfc-matchbox-automaton-smoke/ab-c.ari \
  --cpf target/rfc-matchbox-automaton-smoke/ab-c.cpf3.xml \
  --cpf-mode cpf30 \
  --strategy 'rfc-relative-match-bounds(max-bound=3,max-words=10,max-word-len=16,max-states=100,max-transitions=1000,at-bound=merge)'

.tools/ceta-relative-bounds target/rfc-matchbox-automaton-smoke/ab-c.cpf3.xml
```

Result:

```text
status: Terminating
step: RfcMatchboxRelativeBounds
CeTA: CERTIFIED
```

The current Ferrum search is still too weak/expensive on the 653
`SRS_Standard` examples where Matchbox's TermComp 2025 proof output contains
RFC markers. A focused rerun with the new checker used:

```text
target/termcomp-runs/20260722-srs-standard-653-rfc-matchbox-real-32w-30s
```

Command shape:

```text
python scripts/termcomp_trs_compare.py \
  --tpdb /work/dfm/festschrift/TPDB-ARI \
  --ferrum ./target/release/ferrum \
  --ceta ./.tools/ceta-relative-bounds \
  --category SRS_Standard \
  --file-list target/termcomp-runs/20260718-srs-standard-653-rfc-relative-32w-20s-rerun/input-examples.txt \
  --jobs 32 \
  --timeout 30 \
  --run-dir target/termcomp-runs/20260722-srs-standard-653-rfc-matchbox-real-32w-30s \
  --progress-interval 25 \
  --extra-arg=--strategy \
  --extra-arg='rfc-relative-match-bounds(max-bound=3,max-words=10000,max-word-len=128,max-states=2000,max-transitions=50000,at-bound=merge)'
```

Result:

| Total | YES | Certified YES | MAYBE | Timeout | Cert failed |
| ---: | ---: | ---: | ---: | ---: | ---: |
| 653 | 0 | 0 | 108 | 545 | 0 |

After adding summarized RFC reachability, exact-only finite RFC closure
generation, an aggressive one-state Matchbox candidate, and a bounded fallback
for the expensive merge saturation, the same focused set was rerun as:

```text
target/termcomp-runs/20260722-srs-rfc-matchbox-capped-653-32w-30s
```

Result:

| Total | YES | Certified YES | MAYBE | Timeout | Cert failed |
| ---: | ---: | ---: | ---: | ---: | ---: |
| 653 | 0 | 0 | 514 | 139 | 0 |

Interpretation: certification is no longer the immediate blocker for this proof
form. The new search changes remove most pathological timeouts, but do not yet
recover real TermComp YESs. The next SRS task is to implement stronger
Matchbox-level automaton construction: systematic quotient/merge search,
epsilon-closure guided transition insertion, and proof-guided parameter choices
from the Matchbox proof corpus.

The next real certification step is to extend this from automaton-closed RFC to
full Matchbox-style merge/epsilon RFC closure: prove that the checked
merge/epsilon closure implies acceptance of every term in the right-forward
closure, then use that acceptance theorem in the existing relative-bounds
semantic argument.

## Paired-Tail RFC Result

The first certified multi-rule slice is now complete. Ferrum preserves one
tail per strict RHS, performs epsilon-only right-extension completion, and
exports `<rfcMatchboxRelativeBounds>`. The branch-built CeTA checker verifies
the paired finite initial language modulo harmless rule reordering.

On the fixed 189 direct `RelRFCmb{-1}` examples:

| Run | YES | Certified YES | MAYBE | Timeout | Cert failed |
| --- | ---: | ---: | ---: | ---: | ---: |
| Common-tail baseline | 8 | 8 | 147 | 34 | 0 |
| Paired-tail checker and search | 12 | 12 | 139 | 38 | 0 |

New certified examples:

- `SRS_Standard/ICFP_2010/3770.ari`
- `SRS_Standard/ICFP_2010/4002.ari`
- `SRS_Standard/ICFP_2010/4046.ari`
- `SRS_Standard/ICFP_2010/64160.ari`

Full artifacts are retained under
`target/termcomp-runs/20260724-rfc-paired-v2-189-32w-20s`.

With larger automaton caps, Ferrum also proves and the set-level CeTA checker
certifies:

- `SRS_Standard/ICFP_2010/107193.ari`

The focused artifacts are in `target/rfc-set-ext-v6-probe-20260724`. Ferrum
finds the 2,044-state witness in about 11.5 seconds; certification currently
takes about 155 seconds. This is a real certified YES, but it is not yet a
60-second competition result.

The full fixed-189 large-cap run is retained at
`target/termcomp-runs/20260724-rfc-large-caps-189-32w-40s-v2`:

| YES | Certified YES | MAYBE | CeTA timeout | Other cert failure |
| ---: | ---: | ---: | ---: | ---: |
| 155 | 101 | 34 | 54 | 0 |

Compared with the 12/12 run, this adds 143 raw YES with no losses. Every
uncertified YES has a retained CPF and failed only because the checker reached
the 40-second budget.
