# SAT Polynomial Optimization Roadmap

Ferrum's DP `sat-poly` processor uses a bounded QF_BV encoding, invokes Z3,
decodes a concrete interpretation, and checks that interpretation independently
before accepting a proof. Solver behavior therefore affects search performance,
not proof soundness.

## Persistent Solver Sessions

### 2026-10-16 SRS encoding compatibility and linear-weight experiments

The globally shared Arctic encoding in `a273b75` changed solver models and
their downstream residuals. The v89 full replay lost 30 retained SRS roots,
11 Innermost roots, one CSR root and eight Standard roots. It failed the
retention gate and was **not** promoted. This was a search/replay regression,
not an accepted invalid certificate.

The original `arctic-matrix` action now retains the original unshared, six-bit
encoding. The new shared/dynamically sized encoding has its own explicit
`arctic-matrix-cached` action, including candidate-index round trips. Fresh
versioned evidence for the two Wenzel gains passed strict witness-free replay
and double production CeTA checks (`arctic-versioned-recovery-v91`). The
30/11/1 SRS/Innermost/CSR losses recovered and passed double certification;
seven of eight Standard losses recovered at 180 seconds. The remaining
`ExAppendixB_AEL03_GM` historically needed approximately 789 seconds and is
included with the original 1,200-second limit in the corrected v93 full replay.
The corrected v93 replay and all audits subsequently passed: 1,499 SRS roots,
all 1,338 Standard, 311 Innermost and 110 CSR roots, with zero retained losses.

The opt-in `srs-linear-weight-removal` solves homogeneous weight inequalities
over rationals, scales exact rational models to bounded integers, and rechecks
the live rules before proof construction. It rejects malformed or overflowing
models. It also normalizes proportional inequalities and algebraically combines
the strict-progress sum. Existing integer-weight atoms retain their encodings.
The original/renamed 150258 smoke proofs certified, but the 170-root v90
frontier wave found no new roots (168 Unknown, two harness timeouts).
Instrumentation on ICFP 149415 measured 1.7–2.6 seconds of canonicalization,
20–34 milliseconds of encoding, and solver-budget exhaustion; algebraic
simplification reduced its first query from 787,952 to 575,554 bytes but did
not close it within 60 seconds. These are diagnostic results, not new wins.

Validation: the encoding split and initial linear route passed all 1,168
library tests. All three focused linear tests pass after normalization. The
corrected full replay uses the frozen pre-normalization v93 binary. CeTA
sources and the production checker are unchanged.

Campaign selection was also corrected: sparse processor-count tags identified
only three of 82 unresolved roots whose cached Matchbox summaries explicitly
describe RFC match bounds. The v95 wave targets those actual RFC roots directly
without requiring a preceding weight-removal success.

An optional `min-bound` parameter now permits RFC search to start at a known
height; the default remains zero and legacy action serialization is unchanged.
Parser rejection and round-trip tests cover the new range. On ICFP 149415,
bound two reproduces Matchbox's 4,418 native epsilon transitions, but translating
the partial deletion to the canonical automaton still fails. Experimental
partial layered constructions (v98–v101) did not close that gap and were removed
from production source; their frozen artifacts remain for diagnosis. No
validation condition was relaxed. The v100 intermediate suite and final reduced
v103 source both passed all 1,170 library tests; the final release build passed.

The width-two (memory-one) labeling route with linear weights produced a new
double-CeTA-checked proof for Bouchare_06/01. Strict modular integration and
no-fallback replay passed in `bouchare-width2-v103` / `replay-bouchare-width2-v103`.
The incremental union is 1,500 local / 1,495 shared, not yet a full-replay total.
The broader memory-one waves are still running. The v105 wave corrects another
campaign-level problem: context closure is optional when the input already has
enough common prefix. A mandatory no-op transformation previously prevented
otherwise applicable shift labeling. The raw-summary-guided tiling wave also
retains mirror position and processor order, but imports no interpretation.

### Optional LP weight synthesis (2026-10-16)

`srs-lp-weight-removal(max-weight=65536)` is a distinct modular processor action.
It uses the same canonical homogeneous weight constraints as the rational SMT
route, but asks HiGHS for a numerical LP candidate. The embedded helper
`scripts/solve_srs_linear_weights.py` supports only this restricted encoding;
it is not a general SMT solver. It reconstructs bounded integer candidates and
checks every original inequality using exact rational/integer arithmetic.
Ferrum then independently checks the transported interpretation against the
actual live rules before producing an ordinary polynomial-removal CPF.
Solver status or floating-point feasibility alone can never promote a proof.

`all-strict=true` requests simultaneous strict orientation of every rule rather
than partial deletion. The default remains partial deletion. Both action forms
round-trip, and tests cover positive, renamed, nonorientable, and partially
orientable inputs. Missing optional dependencies yield no proof, not acceptance.

The backend uses Python 3 and the official
[HiGHS Python interface](https://ergo-code.github.io/HiGHS/stable/interfaces/python/).
The campaign installs `highspy==1.15.1` and `numpy==2.5.4` in the isolated
`target/srs-native-20261013/lp-tools-v107` directory. Set
`FERRUM_LP_PYTHONPATH` to its absolute path, or install those packages in the
Python environment used by Ferrum. This does not replace Z3 or alter its PATH.
The temporary solver-wrapper probes are diagnostic artifacts only and are
not used as oracle evidence.

On ICFP 183803, Z3 and cvc5 exhausted the sampled budgets; HiGHS candidate
search took approximately 0.7 seconds and the resulting CPF passed production
CeTA twice. The explicit-action v108 width-two wave discovered 25 new roots;
all 25 subsequently passed strict witness-free replay and double certification.
The width-three wave discovered 24 more; all 24 also passed strict witness-free
replay and double certification. A complete four-category retention replay is
running in `target/srs-native-20261013/full-expanded-v118/`.
These discoveries are not yet part of the frozen v93 high-water mark.

The first LP-enabled library run had 1,170 passes and one transient persistent-Z3
concurrency failure (`BrokenPipe`); that unchanged test passed when rerun alone.
The expanded LP/all-strict test passes. Complete v111 and v114 library runs each
passed all 1,171 tests. The all-strict path skips graph canonicalization because
every successful interpretation closes the entire state; short solver aliases
are mapped back and checked against the original rules. Partial deletion retains
the original canonical encoding to preserve residual replay fidelity.

The v117 backend uses integer arithmetic for the integral constraint encoding,
retaining exact rational reconstruction for floating-point candidate weights.
For all-strict queries it minimizes total weight instead of maximizing strict
gaps, avoiding unnecessarily large vertices that can frustrate bounded exact
reconstruction. It logs infeasibility separately from candidate rejection.
The focused native/exact-validation regression passes. The loaded v119 full
suite had 1,169 passes and two failures in unchanged SCT/pattern-search tests;
both passed isolated reruns (0.88s and 51.66s respectively). Certified discovery
and retention waves are running before promotion of this refinement.
The subsequent four-test-worker v125 full suite passed all 1,171 tests with
zero failures. The 26 exporter/root-correspondence tests also pass. Root audits
now stream through the complete XML while retaining only root obligations;
CeTA still checks the full proof and before/after hashes detect file changes.
This bounds audit memory for multi-gigabyte labeled proofs. Export/recheck/audit
tools accept an independent positive `--checker-timeout` (default 120 seconds);
the large-proof campaign uses 600 seconds without weakening acceptance checks.
CeTA source and production binary are unchanged.

Z3 QF_BV calls use a pool of persistent solver processes. Each query starts
with SMT-LIB `reset`, so unrelated concurrent DP branches remain isolated while
avoiding repeated process startup. Timed-out, cancelled, or broken sessions are
terminated instead of being returned to the pool. Protocol failures fall back
to the existing one-shot invocation. Set `FERRUM_DISABLE_PERSISTENT_SMT=1` to
force the one-shot path for comparison and diagnosis.

This first implementation does not preserve learned clauses between queries:
`reset` deliberately clears solver state. Incremental reuse across related SCCs
or coefficient bounds requires a separate common-base plus `push`/`pop`
protocol.

The pool now also has a leased-session API for related queries. A lease can
send one reset query and then retain assertions across incremental queries.
Disconnected stdout readers are rejected before reuse, reset-isolated queries
retry once with a fresh process, and incremental queries never retry without
their retained base. Concurrent-pool, timeout-poisoning, QF_BV, and QF_LIA
tests cover these cases.

The following cross-processor routes remain opt-in while performance results
are still workload-sensitive:

- `FERRUM_EXPERIMENTAL_INCREMENTAL_SCT_SMT=1` retains the polynomial
  size-change base and adds one rejected-model block per query;
- `FERRUM_EXPERIMENTAL_PERSISTENT_MATRIX_SMT=1` pools Z3 QF_BV matrix and
  Arctic calls while preserving Boolector's seeded one-shot path;
- `FERRUM_EXPERIMENTAL_PERSISTENT_LIA_SMT=1` pools reset-isolated DP KBO,
  path-order, rational, weak-polynomial, and CSR QF_LIA calls;
- `FERRUM_EXPERIMENTAL_PERSISTENT_TOP_SMT=1` does the same for top-level
  polynomial, KBO, and path-order calls.

All decoded interpretations continue through the existing native checks, so
the emitted proof format is unchanged. No CeTA or CeTA-CSR change is required.

## Strict-Pair Objective

The ordinary `sat-poly` encoding asks Z3 to maximize the number of strictly
oriented dependency pairs in the same solver query. This avoids accepting an
arbitrary weak model that leaves a needlessly difficult residual problem. Set
`FERRUM_SAT_POLY_DISABLE_MAXIMIZE_STRICT=1` to restore first-model behavior for
comparison. The objective is currently enabled only for Z3; other configured
SMT solvers retain the portable satisfaction-only encoding.

On `PALINDROME_complete_GM` with bounds `0..2`, the objective reduced the first
residual component from 25 pairs to 17 and reduced end-to-end time from 59.8 s
to 54.9 s in a paired run.

The encoding also asserts each pair's weak orientation only once. Since weak
orientation is already global, strictness in the removal objective needs only
the additional strict constant comparison. Removing the duplicated weak
formula reduced PALINDROME's first optimized script from 249 KB to 157 KB; the
resulting certified run left 16 residual pairs and completed in 56.1 s.

## Shared Finite-Domain Encoding

Ordinary `sat-poly` now caches interpreted terms and hash-conses canonical BV
additions and products into named definitions. Coefficients and constants use
their exact unsigned parameter width, while term values retain the wider width
needed to prevent arithmetic overflow. For coefficient bounds up to eight,
multiplication by an unknown coefficient is encoded as a finite selector over
constant shifts/products instead of a general BV multiplier.

The strict-pair objective uses an exact-width balanced adder tree. On
`PALINDROME_complete_GM`, these changes reduced the first formula to 152 KB and
the certified end-to-end run to 54.2 s. A paired 24-problem sample retained all
7 solves and reduced aggregate time from 123.8 s to 120.9 s. Diagnostic
fallbacks are available through
`FERRUM_SAT_POLY_DISABLE_EXPRESSION_SHARING=1`,
`FERRUM_SAT_POLY_DISABLE_FINITE_DOMAIN_PRODUCTS=1`, and
`FERRUM_SAT_POLY_DISABLE_NARROW_PARAMETERS=1`.

`FERRUM_SAT_POLY_MAX_VALUE_WIDTH=N` experimentally caps intermediate term
values at `N` bits, but never below the parameter width. The resulting modular
model is still checked as a natural-number interpretation before Ferrum accepts
it. On `PALINDROME_complete_GM`, a two-bit cap reduced the relevant formula from
81,326 to 73,826 bytes, while a controlled full-proof run changed only from
85.12 to 84.48 seconds. Both runs emitted the same CeTA-certified CPF. The cap
therefore remains diagnostic rather than a default until a broader benchmark
shows enough solver-time benefit to offset incomplete modular searches.

## Direct SAT Encoding

`FERRUM_SAT_POLY_DIRECT=1` enables a direct propositional encoding following
Fuhs et al. (SAT 2007), without an SMT or generic bit-vector frontend. It builds
exact natural-number circuits for abstract polynomial coefficients, ripple
addition, shift-add multiplication, and unsigned comparison; tracks expression
maximums to omit leading zero bits; hash-conses arithmetic and Boolean
subexpressions; converts the circuit to Tseitin CNF; and decodes the DIMACS
model. Ferrum still validates every decoded interpretation independently.
The backend is experimental and opt-in: it is not enabled by any shipped
strategy, and an unset `FERRUM_SAT_POLY_DIRECT` leaves the existing SAT/SMT
path unchanged.

The direct backend supports both complete and partial reduction-pair steps.
`FERRUM_DIRECT_SAT_STRICT_MODE` accepts `all`, `some`, or `all-then-some`.
The default `all-then-some` mode first asks for an interpretation making every
dependency pair strict. If that direct SAT query is UNSAT, it issues a second
direct query requiring all pairs weak and at least one pair strict. Operational
solver failures may still fall back to the existing backend.
`FERRUM_SAT_POLY_DIRECT_ONLY=1` disables that operational fallback for
diagnostics, and `FERRUM_DIRECT_SAT_SOLVER` selects the DIMACS solver.
`FERRUM_DIRECT_SAT_OBJECTIVE_SEARCH=adaptive` selects model-count ascent for
the strict-pair objective; `binary` selects the default model-aware binary
search.

The official SAT Competition 2025 `AE-Kissat2025-MAB` solver is available
locally as `.tools/kissat-sc2025`. On the 16-pair
`PALINDROME_complete_GM` state, the direct encoding had 8,075 variables and
25,489 clauses. Kissat solved it in 42 ms; the complete processor call took
743 ms instead of 895 ms for the QF_BV path, removed all 16 pairs, and emitted
a CeTA-certified CPF.

The full `PALINDROME_complete_GM` proof exposes the missing optimization in the
initial partial step. With the same three-stage DP strategy and a 90-second
budget, QF_BV completed in 44.392 seconds and its CPF passed CeTA. Direct-only
SAT without optimization timed out after 90.304 seconds. Its first model removed
only 28 of 73 pairs and left 45, while Z3's cardinality objective removed 56
and left 17.

The direct backend now builds a shared cardinality network. Its adaptive search
asks first for one strict pair and then for one more than the returned model's
actual strict count. On this problem that required 21 total solver calls and a
CeTA-certified full proof took 67.404 seconds: Kissat frequently returned
exactly the requested count near the optimum, while the final UNSAT query was
cheap. The default model-aware binary search also advances past the returned
model's actual count, required nine total solver calls, and proved the optimum
of 57 strict pairs. Its CeTA-certified full proof completed in 42.985 seconds,
with 743 ms in Kissat, versus 44.392 seconds for QF_BV.

Proof-state-local dependency-graph caching now reuses a completed parent graph
for reordered residual pair subsets when the TRS, active rules, CSR estimator,
and innermost LHS context are unchanged. PALINDROME produced 34 cache hits. The
CeTA-certified direct run fell from 42.985 to 24.559 seconds, while the matched
QF_BV run fell from 44.392 to 24.362 seconds. The graph cache accounts for the
gain; backend choice is within run noise after caching.

## Direct SAT Semantic Labeling

`FERRUM_EXPERIMENTAL_DIRECT_SAT_SEMANTIC_LABELING=1` adds an optional direct
CNF pre-search for carrier-two semantic algebras. It uses one-hot selectors for
the existing arithmetic-function candidates and Boolean circuits for sums and
products modulo two. Every decoded algebra is rechecked by the native model
condition and then passed to the unchanged labeled-DP proof search; failure
falls back to the existing enumerator.

Focused runs produced CeTA-certified proofs, including proof objects different
from enumeration, but were slower on the measured small cases (`jw34`: 0.030 s
to 0.250 s; `labeling`: 0.106 s to 0.123 s). The backend therefore remains
diagnostic and is not part of the default strategy.

## 2026-07-31 Cross-Processor Results

A same-binary run over all 108 `TRS_Contextsensitive` examples preserved 88
YES results. The reset/incremental routes certified 86 versus 84 in the paired
legacy run because two portfolio races selected ordinary certified proofs
instead of rejected safe-CS-DP variants. Aggregate per-example time changed
from 744.0 s to 662.8 s, but median speed improved only 3.2% and several
race-heavy examples varied substantially.

A representative run preserved 8/8 certified `TRS_Standard` and 5/6 certified
`TRS_Innermost` results. Aggregate times changed from 109.9 s to 105.3 s and
98.2 s to 89.3 s respectively. Eight hard `SRS_Standard` examples remained
unsolved in both modes with unchanged aggregate time; unknown/timeout labels
varied only at the 60-second boundary. PALINDROME emitted a byte-identical,
CeTA-certified CPF in both modes and measured 38.631 s versus 38.655 s because
its oracle-guided path did not exercise the new routes.

These measurements do not meet the 10% median default-promotion gate. The new
routes remain opt-in and `FERRUM_DISABLE_PERSISTENT_SMT=1` remains the global
diagnostic kill switch.

## Remaining Work

Ordered by expected value:

1. Benchmark a QF_BV solver portfolio. Compare Z3, Boolector, and cvc5 on the
   exact generated formulas before selecting defaults or time-sliced races.
2. Extend leased incremental solving from polynomial size-change model blocking
   to closely related residual components where the common-base equivalence can
   be checked directly.
3. Reuse a persistent SAT instance under assumptions and evaluate adaptive
   versus model-aware binary objective search on a broader corpus.
4. Add symmetry breaking and eliminate irrelevant parameters where a symbol or
   argument cannot influence any orientation constraint.

Interpretation-dependent usable-rule minimization was also measured through the
existing `poly` processor. It retained 7/24 solves but took 125.4 s, so it is
not merged into ordinary `sat-poly`. A `0..1` bound-deepening probe lost one
solve and took 124.4 s; blind bound deepening is therefore not enabled.

The main literature baseline is Fuhs et al., "SAT Solving for Termination
Analysis with Polynomial Interpretations" (SAT 2007). AProVE's later system
description emphasizes Boolean simplification, structural hashing, iterative
deepening, and dedicated SAT encodings as important implementation techniques.

## Acceptance Measurements

Every optimization should report:

- encoding time, serialized formula size, parameter width, and value width;
- solver time and selected backend;
- number of pairs and usable rules before and after the processor;
- successful, timed-out, and rejected models;
- full CPF/CeTA certification status.

Use `PALINDROME_complete_GM` as a large transformed-CSR stress case, but decide
defaults from a broader TRS Standard/Innermost corpus. Persistent sessions alone
are not expected to materially improve a proof dominated by one large SAT call.
