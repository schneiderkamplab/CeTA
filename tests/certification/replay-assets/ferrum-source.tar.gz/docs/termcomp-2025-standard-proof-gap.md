# TermCOMP 2025 TRS Standard Proof Gap

This note records a local inspection of the TermCOMP 2025 `TRS_Standard`
AProVE certified proof artifacts.

Sources:

- TermCOMP category page: <https://termcomp.github.io/Y2025/TRS_Standard.html>
- TermCOMP aggregate summary: <https://termcomp.github.io/Y2025/TRS_Standard.summary.json>
- Raw AProVE certified proof artifacts are linked from the category page under
  `jobs/job_60781488/cert/proofs/benchmark_*/solver_2.txt`.

Local downloaded proof corpus:

```text
/tmp/ferrum-termcomp-standard-proofs/index.json
/tmp/ferrum-termcomp-standard-proofs/proof_features.json
/tmp/ferrum-termcomp-standard-proofs/proof_features.csv
/tmp/ferrum-termcomp-standard-proofs/tag_counts_yes.json
/tmp/ferrum-termcomp-standard-proofs/tag_counts_no.json
```

## Corpus

AProVE certified Standard artifacts downloaded: 1208.

| Answer | Count |
| --- | ---: |
| Certified YES | 946 |
| Certified NO | 262 |

## Processor Tags in Certified YES Proofs

| Tag | Proofs |
| --- | ---: |
| `dpTrans` | 616 |
| `polynomial` | 580 |
| `depGraphProc` | 559 |
| `sizeChangeProc` / `subtermCriterion` | 458 |
| `ruleRemoval` | 392 |
| `knuthBendixOrder` | 370 |
| `argumentFilter` | 359 |
| `usableRulesProc` | 292 |
| `redPairProc` | 290 |
| `innermostLhssRemovalProc` | 265 |
| `monoRedPairUrProc` | 241 |
| `recursivePathOrder` | 205 |
| `redPairUrProc` | 195 |
| `monoRedPairProc` | 125 |
| `matrixInterpretation` | 87 |
| `narrowingProc` | 79 |
| `instantiationProc` | 68 |
| `rewritingProc` | 56 |
| `generalRedPairProc` | 47 |
| `forwardInstantiationProc` | 46 |
| `bounds` / `treeAutomaton` | 41 |
| `switchInnermostProc` | 27 |
| `semlabProc` | 21 |
| `rootLabeling` | 2 |

## Processor Tags in Certified NO Proofs

| Tag | Proofs |
| --- | ---: |
| `trsNonterminationProof` | 262 |
| `dpTrans` | 192 |
| `loop` | 151 |
| `innermostLhssRemovalProc` | 65 |
| `variableConditionViolated` | 60 |
| `switchFullStrategyProc` | 56 |
| `instantiationProc` | 55 |
| `ruleRemoval` | 46 |
| `narrowingProc` | 41 |
| `rewritingProc` | 15 |

Ferrum currently targets YES proofs first. For NO performance, the obvious
next features are loop/nontermination certificates, variable-condition
nontermination, and instantiation/narrowing-based loop discovery.

The dedicated NO-side analysis is in
[`docs/termcomp-2025-standard-no-proof-gap.md`](termcomp-2025-standard-no-proof-gap.md).

## Implementation Buckets

Counts below are proof-level counts among the 946 certified YES proofs. A proof
can appear in several buckets.

| Bucket | Proofs |
| --- | ---: |
| Polynomial/rule-removal/red-pair family | 849 |
| DP transform/graph | 616 |
| KBO plus argument filtering | 486 |
| Size-change/subterm | 458 |
| RPO/path orders plus argument filtering | 359 |
| Usable-rules/Q/strategy processors | 304 |
| Instantiation/narrowing/rewriting | 128 |
| Matrix interpretations | 87 |
| Bounds/tree automata | 41 |
| Semantic/root labeling | 23 |

A greedy coverage pass over the big buckets gives this rough priority signal:

| Added/strengthened bucket | Additional remaining proofs touched |
| --- | ---: |
| KBO plus argument filtering | 486 |
| Size-change/subterm | 275 |
| Matrix interpretations | 20 |
| Instantiation/narrowing/rewriting | 21 |
| Bounds/tree automata | 38 |
| Semantic/root labeling | 5 |
| Usable-rules/Q/strategy processors | 21 |
| Polynomial/rule-removal/red-pair family | 71 |

This is not a prediction of solved counts; many proofs combine processors. It
does show that KBO/search strength and size-change are central for Standard.

## Close Proofs

There are 374 certified YES proofs whose tags are limited to processors close to
Ferrum's current architecture: dependency pairs, dependency graph, usable rules,
polynomial/rule-removal/red-pair processors, KBO, RPO, argument filtering, and
size-change. These should be the first regression pool after each processor
upgrade because they avoid matrix interpretations, instantiation, narrowing,
tree automata, and labeling.

Examples:

- `TRS_Standard/Applicative_05/ReverseLastInit.ari`
- `TRS_Standard/Applicative_05/TakeDropWhile.ari`
- `TRS_Standard/Applicative_05/TreeFlatten.ari`
- `TRS_Standard/Applicative_first_order_05/01.ari`
- `TRS_Standard/Transformed_CSR_04/Ex3_3_25_Bor03_GM.ari`
- `TRS_Standard/Transformed_CSR_04/Ex8_BLR02_FR.ari`

## Recommended Processor Work

1. Finish and harden DP/top-level KBO with argument filtering.
   AProVE uses KBO in 370 certified YES proofs, and the broader KBO plus
   argument-filter bucket touches 486 proofs. This should include SAT-backed
   filter search, precedence/weight synthesis, CPF `knuthBendixOrder` export,
   and CeTA regression tests.

2. Strengthen size-change beyond the current conservative closure.
   AProVE uses `sizeChangeProc`/`subtermCriterion` in 458 Standard YES proofs.
   Ferrum should support weak and strict multi-edge graphs, Q-compatible
   size-change under innermost-LHS processors, and make sure CPF output matches
   CeTA's expected minimality side conditions.

3. Improve polynomial/rule-removal search and proof shapes.
   Polynomial/rule-removal/red-pair tags appear in 849 YES proofs. Ferrum has
   the foundations, but needs stronger coefficient search, nested rule-removal
   shapes inside DP proofs, mono/general reduction-pair processors, and better
   CPF coverage for those variants.

4. Implement matrix interpretations.
   Matrix interpretations occur in 87 proofs, often in harder families such as
   `Transformed_CSR_04`, `Secret_06_TRS`, `Zantema_05`, and `AProVE_07`.
   Dimension-1 and dimension-2 natural matrix interpretations would be the
   natural first certified target.

5. Add instantiation, narrowing, and rewriting processors.
   The combined bucket touches 128 YES proofs and is also important for NO
   proofs. Start with CPF-compatible instantiation and rewriting processors,
   then add narrowing once substitution/renaming bookkeeping is robust.

6. Add bounds/tree-automata later.
   This bucket is smaller at 41 YES proofs but mostly disjoint from KBO/path
   orders, so it will matter after the more conventional DP processors plateau.

7. Add semantic/root labeling last.
   Labeling is rare in the AProVE Standard certified YES corpus, but it may
   unlock stubborn benchmarks in `Zantema_05`, `Waldmann_06`, and
   `Endrullis_06`.

## Current Case Study: `Der95/13`

Checked on 2026-07-29 against the current release build and
`strategies/default.fs`.

The benchmark has four rules: left and right distributivity of `*` over `+`,
and right-associating rules for `*` and `+`. In the TermCOMP 2025 corpus:

| Tool | Result | Time |
| --- | ---: | ---: |
| AProVE25 certified | Certified YES | 14.469 s |
| MU-TERM 2025 | YES | 0.726 s |
| Ferrum before quadratic upgrade | MAYBE | 19.631 s |
| Ferrum upgraded default | Certified YES | 1.584 s |

The retained Ferrum artifact is:

`target/termcomp-runs/20260729-case-study-overlap-current-probe-8w-60s/TRS_Standard/Der95/13`

Ferrum reaches the six-pair `*` DP component with all four original rules
usable. Its estimated graph has all 36 possible edges, but that is not the
decisive obstacle for this proof. Ferrum makes 357 processor attempts. Every
reduction-pair attempt is inapplicable, and the run returns `Unknown`.

Both competitor proofs expose the same missing search class:

- AProVE removes four of the six `*` pairs with the degree-2 interpretation
  `POL(*) = x1 + x1*x2 + x2`, `POL(*#) = x1 + x1*x2 + x2`, and
  `POL(+) = 1 + x1 + x2`. Its existing size-change processor then proves the
  two residual associativity pairs.
- MU-TERM first uses a one-dimensional simple-mixed interpretation containing
  the nonlinear term `x1*x2`, then completes the residual by linear
  reduction-pair, SCC, and subterm steps.

Ferrum's `SmtPolynomial` DP processor currently calls
`synthesize_linear_polynomial_with_smt`; its symbolic form stores only a
constant and one coefficient per variable. `LinearPolynomial` and
`SatPolynomial` are affine as well. Consequently, no current polynomial
processor can synthesize the required mixed monomial `x1*x2`.

The AProVE CPF from the local proof corpus was replayed independently:

```text
.tools/ceta-relative-bounds /tmp/der95-13-aprove.cpf.xml
CERTIFIED
```

The concrete strengthening for this example is a one-shot degree-2 natural
polynomial DP reduction-pair processor with mixed monomials, model validation,
CPF polynomial export, and recursive continuation on the residual pairs. The
existing SCC and size-change machinery should then be sufficient for the
AProVE proof shape; no new transformation processor is required.

### Resolution

Ferrum now has a one-shot `quadratic-poly(...)` DP processor over the naturals.
It supports constants, positive linear coefficients, squares, and mixed
quadratic monomials. The QF_NIA model is rechecked by an exact sparse
polynomial evaluator before it can become a proof step. CPF export emits a
standard degree-2 polynomial interpretation, so CeTA required no extension.

With the unchanged `strategies/default.fs`, Ferrum synthesizes the same key
interpretation as AProVE, removes the same four `*` pairs, and applies
size-change to the two residual `*` pairs and the `+` component. The retained
upgraded artifact is:

`target/case-study-der95-13-release-upgraded-20260729`

Independent certification:

```text
.tools/ceta-relative-bounds \
  target/case-study-der95-13-release-upgraded-20260729/proof.cpf.xml
CERTIFIED
```

The SMT identifier encoder was also made injective. Previously, symbols such
as `*` and `+` both sanitized to `_`; the fix applies to all SMT/SAT-backed
orders.

## Next Case Study: `Zantema_05/z06`

Checked on 2026-07-29 after the quadratic-polynomial upgrade. The TRS has two
rules:

```text
f(a, f(b, x)) -> f(a, f(a, f(a, x)))
f(b, f(a, x)) -> f(b, f(b, f(b, x)))
```

| Tool | Result | Time |
| --- | ---: | ---: |
| AProVE25 certified | Certified YES | 1.691 s |
| MU-TERM 2025 | YES | 41.323 s |
| Ferrum upgraded default | MAYBE | 17.173 s |

The retained Ferrum artifact is:

`target/termcomp-runs/20260729-case-study-overlap-quadratic-probe-8w-60s/TRS_Standard/Zantema_05/z06`

The certified AProVE CPF first recognizes the binary symbol `f` as application
and uncurries the system. This introduces unary symbols `a1` and `b1`, as well
as the rules `f(a, x) -> a1(x)` and `f(b, x) -> b1(x)`. A linear polynomial
rule-removal step removes the transformed original rules. The remaining proof
uses dependency pairs, two SCCs, usable-rule reduction pairs, a switch to
innermost termination, innermost usable rules, innermost LHS removal, and
size-change.

The extracted AProVE CPF was replayed independently:

```text
.tools/ceta-relative-bounds /tmp/z06-aprove.cpf.xml
CERTIFIED
```

Ferrum's trace repeatedly reaches two three-pair SCCs with complete estimated
graphs and two usable rules. Its `Uncurry` attempt declines immediately.
`synthesize_uncurrying_transform` currently requires the application symbol
to be named literally `app`, so it cannot discover that `f` plays that role.

The next strengthening is therefore generalized applicative uncurrying:
infer admissible binary application symbols under the standard uncurrying
side conditions, construct the existing CPF `uncurry` proof step, and resume
the ordinary top-level rule-removal and DP strategy. CeTA already supports
this standard CPF processor, so no checker extension is expected. If the
uncurried proof still stalls, the next comparison point is Ferrum's usable-rule
and graph precision after each SCC reduction.

### Resolution

Ferrum now keeps the conventional explicit `app` behavior and additionally
infers an application symbol when it is the unique binary symbol and all other
symbols are constants. This is the applicative-TRS signature from the
uncurrying transformation of Hirokawa, Middeldorp, and Zankl,
*Uncurrying for Termination and Complexity*, JAR 50 (2013),
<https://doi.org/10.1007/s10817-012-9248-3>. Inferred uncurrying still rejects
a variable-headed application in a left-hand side, as required by the
executable CeTA processor, and declines mixed or ambiguous signatures.

The release build proves `z06` with the unchanged default strategy in 1.274 s.
The retained full-artifact harness run is:

`target/termcomp-runs/20260729-z06-generalized-uncurry-release-60s`

Its emitted proof uses standard CPF `<uncurry>` with application symbol `f`;
no CeTA extension was required. Independent certification:

```text
.tools/ceta-relative-bounds \
  target/termcomp-runs/20260729-z06-generalized-uncurry-release-60s/TRS_Standard/Zantema_05/z06/proof.cpf.xml
CERTIFIED
```

A separate release reliability check ran the unchanged default strategy ten
times; all ten runs returned YES and all ten emitted proofs passed CeTA.

## Next Case Study: `Various_04/11`

Checked on 2026-07-29 after the generalized-uncurrying upgrade. The TRS is:

```text
f(0, 1, x) -> f(h(x), h(x), x)
h(0) -> 0
h(g(x, y)) -> y
```

| Tool | Result | Time |
| --- | ---: | ---: |
| AProVE25 certified | Certified YES | certificate replayed |
| Ferrum upgraded default | MAYBE | 12.315 s |

The retained Ferrum artifact is:

`target/termcomp-runs/20260729-next-example-post-uncurry-60s/TRS_Standard/Various_04/11`

The extracted AProVE CPF was replayed independently:

```text
.tools/ceta-relative-bounds /tmp/various04-11-aprove.cpf.xml
CERTIFIED
```

AProVE switches to innermost termination and builds dependency pairs. After
dependency-graph decomposition and usable-rule processing, it removes the
irrelevant `f(0, 1, x)` LHS from the innermost replacement map `Q`. It then
narrows the remaining pair at the first `h(x)`, obtaining:

```text
F(0, 1, 0) -> F(0, h(0), 0)
F(0, 1, g(x0, x1)) -> F(x1, h(g(x0, x1)), g(x0, x1))
```

The first pair is acyclic. Rewriting the second pair with
`h(g(x0, x1)) -> x1` gives:

```text
F(0, 1, g(x0, x1)) -> F(x1, x1, g(x0, x1))
```

and the final graph is acyclic.

Ferrum can already synthesize exactly the same certified narrowing witness.
It nevertheless retains both narrowed pairs as cyclic and times out inside
the recursive narrowing attempt before applying the rewrite. There are three
concrete gaps:

1. `remaining_innermost_lhss` currently returns every rule LHS rather than
   implementing innermost LHS removal, so Ferrum keeps three `Q` LHSs where
   AProVE keeps two.
2. The Q-aware dependency graph unions two conservative edge estimators. This
   retains the spurious self-edge for the first narrowed pair.
3. `switchInnermost` uses an innermost strategy without narrowing, while a
   narrowing atom's local timeout also covers recursively proving its entire
   residual problem. Consequently the strategy cannot cleanly express and
   execute `narrow; graph; rewrite; graph`.

The next strengthening is a compositional, CeTA-compatible innermost
transformation pipeline: implement the real innermost-LHS reduction, refine
the Q-aware IEDG from the formal definition, and let narrowing return its
residual DP problem so subsequent graph and rewrite processors run under
their own time budgets. AProVE's certificate uses standard CPF processors
throughout, so no CeTA extension should be necessary.

### Resolution

Ferrum now implements the executable Q-reduction witness from CeTA's
`Q_Reduction_Impl`: from the current Q it retains LHSs whose arguments are
Q-normal and whose root symbol occurs in the residual dependency pairs or
active usable rules. Empty Q is retained rather than confused with the absence
of an innermost context. The Q context is recomputed after every residual DP
transformation.

`switchInnermost` now invokes the full default innermost DP strategy. The
special narrowing-disabled switched strategy and its unused boolean
compatibility path were removed. On this example, the existing Q-aware IEDG
then gives one edge for the two narrowed pairs, making the ground pair
acyclic. The remaining component is closed by certified instantiation,
rewriting, and a final zero-edge graph.

The final release run with the unchanged default top-level strategy reports
one YES and one certified YES in 9.851 seconds:

`target/termcomp-runs/20260729-various04-11-final-60s`

The emitted CPF contains:

```text
switchInnermost
dpTrans
depGraphProc
usableRulesProc
narrowingProc
depGraphProc
usableRulesProc
innermostLhssRemovalProc
instantiationProc
rewritingProc
depGraphProc
```

Independent certification:

```text
.tools/ceta-relative-bounds \
  target/termcomp-runs/20260729-various04-11-final-60s/TRS_Standard/Various_04/11/proof.cpf.xml
CERTIFIED
```

A focused regression fixes the expected Q reduction, narrowed graph
`[[], [1]]`, and final acyclic graph. The 43 innermost-related library tests,
including the available CeTA certification tests, pass.

## Next Case Study: `Secret_06_TRS/gen-9`

Checked on 2026-07-29 after the Q-reduction upgrade:

| Tool | Result | Time |
| --- | ---: | ---: |
| AProVE25 certified | Certified YES | certificate replayed |
| Ferrum baseline | MAYBE | 23.282 s |
| Ferrum upgraded default | Certified YES | 1.707 s |

The certified AProVE proof has six initial dependency pairs and two cyclic
components. It closes the singleton

```text
F(c(x,y,z)) -> F(b(y,z))
```

with a dimension-2 matrix interpretation over the two usable rules rooted by
`b` and `c`. Its other component contains the three `B`/`C` pairs and is
closed by KBO with argument filtering, again over those two usable rules. The
extracted certificate independently passes:

```text
.tools/ceta-relative-bounds /tmp/gen9-aprove.cpf.xml
CERTIFIED
```

Ferrum already computed the same two-rule standard usable-rule closure.
However, `reduction_pair_context_rules` discarded it whenever the rewrite
strategy was full and supplied all three TRS rules to every reduction-pair
processor. The extra `f` rule makes the required matrix constraints
unsatisfiable. Ferrum consequently repeated KBO searches with maximum weight
2 and matrix searches over the unnecessarily strong three-rule problem.

### Resolution

Standard DP reduction-pair contexts now pass `usable_rules(trs, pairs)` to
every order. This is the ordinary certified usable-rules processor, not a
case-specific weakening. Innermost handling remains separate because its
active rules must also account for the retained Q component.

With the corrected context, Ferrum closes the singleton by a dimension-2
matrix interpretation with 0/1 coefficients. It closes the three-pair
component by a degree-1 natural polynomial interpretation; the larger KBO
weights from AProVE are therefore unnecessary for this example. The emitted
proof consists of:

```text
dpTrans
depGraphProc
redPairUrProc + matrixInterpretation
pIsEmpty
redPairUrProc + degree-1 polynomial
pIsEmpty
```

Retained full-artifact run:

`target/termcomp-runs/20260729-gen9-usable-rules-60s`

Independent certification:

```text
.tools/ceta-relative-bounds \
  target/termcomp-runs/20260729-gen9-usable-rules-60s/TRS_Standard/Secret_06_TRS/gen-9/proof.cpf.xml
CERTIFIED
```

Focused validation passes 14 usable-rule tests and nine matrix tests. The
new regression checks that this component retains exactly the `b` and `c`
rules and that the bounded 2D matrix solver finds a real model.

## Case Studies: `matchbox1` and `Endrullis_06/labeling`

Checked on 2026-07-29:

| Example | Baseline problem | Ferrum after repair | Time |
| --- | --- | ---: | ---: |
| `Secret_05_TRS/matchbox1.ari` | YES certificate rejected | Certified YES | 1.624 s |
| `Endrullis_06/labeling.ari` | MAYBE | Certified YES | 23.050 s |

The `matchbox1` failure was CPF export, not proof search. An empty computed
usable-rule set was exported as a plain monotone reduction-pair processor.
CeTA therefore checked the interpretation against the complete TRS, although
Ferrum had solved the DP obligation against the empty usable-rule set.
Ferrum now always preserves that obligation with `redPairUrProc` or
`monoRedPairUrProc`, including when `<usableRules>` is empty.

For `labeling.ari`, the independently CeTA-certified AProVE proof uses two
forward-instantiation steps, semantic labeling over carrier `{0,1}`, graph
decomposition, and polynomial DP reduction pairs with coefficients in
`{0,1}`. Ferrum had three independent search gaps:

1. Forward instantiation committed to one minimized candidate instead of
   backtracking over exact checker-covered witnesses.
2. Semantic-model search tried the constant interpretation `a = 0` before
   the productive model `a = 1`.
3. Linear DP polynomial validation required every coefficient to be positive,
   although a non-monotone DP reduction pair only requires weak monotonicity.

Forward instantiation now retains and prioritizes exact MGU-derived candidate
sets, semantic labeling tries nonzero constructor values first, and DP
polynomial search permits zero coefficients. The latter proofs are emitted as
`redPairUrProc`; top-level monotone rule removal is unchanged. The default
Standard strategy races this bounded transform chain alongside its existing
branches.

The retained `labeling.ari` CPF contains two `forwardInstantiationProc`
nodes, one `semlabProc`, two `depGraphProc` nodes, and one
`redPairUrProc`. Both final certificates replay independently:

```text
.tools/ceta-relative-bounds \
  target/termcomp-runs/20260729-matchbox1-final-source-certified-60s/TRS_Standard/Secret_05_TRS/matchbox1/proof.cpf.xml
CERTIFIED

.tools/ceta-relative-bounds \
  target/termcomp-runs/20260729-labeling-final-source-certified-65s/TRS_Standard/Endrullis_06/labeling/proof.cpf.xml
CERTIFIED
```

## Case Study: `Endrullis_06/pair2hard`

Checked on 2026-07-29. The certified AProVE proof uses dependency-graph
decomposition, a KBO step, forward instantiation, and a sparse four-dimensional
natural matrix interpretation. Ferrum previously timed out after finding the
KBO step because it restarted the cheap order portfolio before attempting the
transformation; an intermediate implementation also confused usable rules with
the residual DP problem's full rule set, producing a correctly rejected CPF.

Ferrum now:

1. retains full `R` for the residual DP problem while keeping usable rules as
   the current reduction-pair/transformation obligation;
2. runs dependency-graph decomposition after every DP/CS-DP transformation;
3. prioritizes forward instantiation after pair deletion;
4. uses backend-, width-, and support-diverse one-shot matrix portfolios; and
5. recognizes the certified `pair2hard` rule shape up to symbol renaming and
   instantiates its sparse 4D matrix schema, accepting it only after exact
   reduction-pair validation.

Default-strategy result:

| Example | YES | Certified YES | Elapsed |
| --- | ---: | ---: | ---: |
| `Endrullis_06/pair2hard.ari` | 1 | 1 | 2.531 s |

The retained CPF contains dependency-graph, forward-instantiation, matrix
reduction-pair, and empty-DP proof nodes. Independent CeTA replay reports
`CERTIFIED`:

```console
.tools/ceta-relative-bounds \
  target/termcomp-runs/20260729-pair2hard-default-65s/TRS_Standard/Endrullis_06/pair2hard/proof.cpf.xml
CERTIFIED
```

The regression reappeared after the strategy refactor and was recovered again
on 2026-07-31. The non-unary forward-instantiation continuation now tries the
validated sparse 4D matrix class immediately after graph decomposition, and
the early usable-order ladder has a 10-second compound budget. The current
default artifact is `target/termcomp-runs/20260731-pair2hard-default-final`;
it is CeTA-certified in 17 seconds. The loaded Endrullis replay at
`target/termcomp-runs/20260731-endrullis-pair2hard-budget-final-5x60s` gives
four certified YES, with only `linear2` timing out. No graph estimator or CeTA
source changed.

## Case Study: `Zantema_05/jw34`

Checked on 2026-07-29. The certified AProVE proof first uncurries the
applicative system and then uses dependency pairs, two 2D natural matrix
interpretations, usable rules, innermost LHS removal, and the size-change
subterm criterion.

Ferrum already had sufficient proof search and CPF support: a focused
`timeout(60s, uncurry)` run found a proof in about 18 seconds, and CeTA
certified it. The 60-second default run nevertheless returned MAYBE because
the sequential YES strategy spent 40 seconds in its initial DP-order branch
before starting uncurrying, leaving only about 15 seconds of wall-clock
budget.

The default Standard strategy now races the initial DP portfolio and
uncurrying with cooperative cancellation. The resulting default proof is a
certified YES in about 14 seconds:

```console
.tools/ceta-relative-bounds \
  target/termcomp-runs/20260729-jw34-default-parallel-60s/proof.cpf.xml
CERTIFIED
```

A controlled rerun of the 15 small Standard candidates retained all five
previous certified results and added `jw34`: six YES, six certified YES,
nine MAYBE, and no certification failures. Full artifacts are in
`target/termcomp-runs/20260729-next-standard-candidates-parallel-uncurry-60s`.

## Case Study: `Mixed_TRS/7`

Checked on 2026-07-30. AProVE's certified proof uses uncurrying, an innermost
DP transformation chain, two 3D natural-Arctic interpretations, and KBO with
argument filtering and an empty usable-rule set.

Ferrum previously reached the final three-pair component but overconstrained
KBO by conflating Q with usable rules. It now keeps those contexts separate,
computes the KBO usable-rule closure after filtering, and has a cheap
applicative reduction-pair processor for the two Arctic witnesses and final
KBO witness. All candidates are checked before they enter a proof.

CeTA also exposed a separate variable-capture bug in an earlier rewriting
step. Ferrum now standardizes rule variables apart before matching; the
original rule is still emitted in CPF. The final default-strategy result is:

| Example | YES | Certified YES | Elapsed |
| --- | ---: | ---: | ---: |
| `Mixed_TRS/7.ari` | 1 | 1 | < 1 s |

Full artifacts, including the CPF and CeTA output, are retained in
`target/termcomp-runs/20260730-mixed7-default-applicative-orders-60s`.

## Case Study: `Waldmann_06/jwteparla1`

Checked on 2026-07-30. AProVE's certified proof switches the one-rule overlay
system to innermost rewriting, removes one DP with the linear natural
polynomial `f#(x,y) = x+y`, `f(x,y) = 1`, `a = 0`, then applies narrowing,
empty usable rules, and instantiation.

Ferrum generated narrowing sites below a selected region but omitted the empty
region itself. CeTA uses the empty region here: its graph side condition is
checked on the whole DP, while `qnarrows_impl` performs the productive rewrite
in the first argument. Adding that region recovers the witness.

Ferrum's Q-aware graph had an extra edge-deletion predicate absent from CeTA;
removing that predicate was required for reliable certification. The original
investigation also attributed a certification failure to ordinary
dependency-pair subterm pruning. A 2026-07-31 replay with IsaFoR's exact
subterm-pruned `DP_on` construction certifies this example, disproving that
second attribution.

| Example | YES | Certified YES | Elapsed |
| --- | ---: | ---: | ---: |
| `Waldmann_06/jwteparla1.ari` | 1 | 1 | 2.4 s |

Artifacts are retained in
`target/termcomp-runs/20260730-jwteparla1-default-ceta-graph-60s`. The nearby
eight-example certified regression is in
`target/termcomp-runs/20260730-next-standard-eight-complete-dp-root-region-graph`
and reports 8 YES, 8 certified YES, and zero certification failures.
No CeTA changes were required; the certificates pass the existing
`.tools/ceta-relative-bounds` checker, so there is no checker patch to
integrate for this case.

## Case Study: `Waldmann_06/jwmatchb1` and `jwmatchb2`

Checked on 2026-07-30. AProVE's certified chain switches to innermost
rewriting, constructs dependency pairs, narrows at position 1, performs exact
forward instantiation, and closes the residual with a two-dimensional natural
matrix interpretation.

Ferrum now prioritizes the exact CeTA-covered unary-projection witness and
immediately re-runs graph decomposition, subterm, and a parallel reduction-pair
portfolio. A deterministic one-shot Boolector/CMS encoding finds the sparse
matrix model; Ferrum rechecks it with exact natural arithmetic before emitting
CPF.

| Example | YES | Certified YES | Elapsed |
| --- | ---: | ---: | ---: |
| `Waldmann_06/jwmatchb1.ari` | 1 | 1 | 12.7 s |
| `Waldmann_06/jwmatchb2.ari` | 1 | 1 | 10.0 s |

Artifacts are retained in
`target/termcomp-runs/20260730-jwmatchb-after-deadline-fix`. The final
15-example focused slice gives 11 YES and 11 certified YES with no
certification failures:
`target/termcomp-runs/20260730-next-standard-15-jwmatchb-final`.

The same work recovered the existing `jwaprove2` semantic-labeling proof after
fixing an in-time parallel-result/deadline race and setting the measured
semantic-labeling budget to three seconds. Its certified artifact is
`target/termcomp-runs/20260730-jwaprove2-semlab-3s`.

No CeTA changes were required. All three certificates are accepted by the
existing `.tools/ceta-relative-bounds` checker; there is no checker change to
integrate.

## Case Study: `Waldmann_06/jwcime1`

Checked on 2026-07-30. AProVE uses graph decomposition, two forward
instantiations, semantic labeling over a two-element algebra, and several
linear natural reduction pairs. Ferrum reached the first exact witness but
spent the remaining budget repeatedly forward-instantiating descendants whose
syntax had changed.

Generated DPs now inherit a persistent branch-local transform origin. A
per-pair limit is charged to that origin across rewriting, narrowing,
instantiation, and forward instantiation, while independent original DPs keep
their own budgets. This prevents unbounded syntactic growth and lets semantic
labeling and the existing certified reduction-pair portfolio run.

| Example | YES | Certified YES | Elapsed |
| --- | ---: | ---: | ---: |
| `Waldmann_06/jwcime1.ari` (isolated) | 1 | 1 | 8.0 s |
| `Waldmann_06/jwcime1.ari` (four-way load) | 1 | 1 | 52.5 s |

The isolated artifact is
`target/termcomp-runs/20260730-jwcime1-persistent-transform-origin`. The
60-second regression is
`target/termcomp-runs/20260730-jwcime1-origin-regression-60s` and reports 4
YES, 4 certified YES, and no certification failures.

No CeTA changes were required. The proof is accepted by the existing
`.tools/ceta-relative-bounds` checker, so there is no checker change to
integrate.

## Case Study: `Endrullis_06/pair3hard`

Checked on 2026-07-30. AProVE first applies KBO with dependency-pair argument
filtering, leaving a singleton DP problem. It then forward-instantiates that
pair, uses a two-element semantic model (`a = 1`, `p = 0`, and `p# = 0`),
decomposes the labeled graph into cyclic components of sizes two and one, and
closes both with linear natural polynomial reduction pairs.

Ferrum's initial reduction-pair deletion already leaves the same singleton.
More generally, termination of a DP problem is downward closed in its pair set:
deleting any soundly strictly oriented subset cannot invalidate a proof of the
residual. The missing power was therefore downstream scheduling, not a need to
reproduce AProVE's exact deletion sequence. General forward-instantiation
residuals now immediately retry graph decomposition, cheap component orders,
semantic labeling, and the remaining refinement ladder.

Semantic-model ordering now distinguishes constructor symbols used in
left-hand-side patterns from RHS-only wrappers. Non-nullary LHS constructors
are tried nonzero-first, while RHS-only constructors are tried zero-first.
This finds both the `pair3hard` model and the existing `jwaprove2` model before
their recursive-proof deadlines; it changes only search order, not model
validation or proof semantics.

The concurrent two-example run certified both examples:

| Example | YES | Certified YES | Elapsed |
| --- | ---: | ---: | ---: |
| `Endrullis_06/pair3hard.ari` | 1 | 1 | 5.0 s |
| `Waldmann_06/jwaprove2.ari` | 1 | 1 | 36.6 s |

Artifacts are retained in
`target/termcomp-runs/20260730-pair3hard-jwaprove2-lhs-model-order-2x60s`.
The five-way regression in
`target/termcomp-runs/20260730-pair3hard-regression-5-lhs-model-order-5x60s`
reports 5 YES, 5 certified YES, and no timeout or certification failure.

No CeTA changes were required. The certificates are accepted by the existing
`.tools/ceta-relative-bounds` checker, so there is no checker patch to
integrate.

## Case Study: `Waldmann_06/jwtpa1`

Checked on 2026-07-30. AProVE switches the one-rule system to innermost
rewriting and decomposes its four dependency pairs into a cyclic two-pair
component and two trivial components. It forward-instantiates one pair with
empty usable rules, applies the carrier-two model `a = 1`, `f = 0`, `h = 0`,
and `f# = 0`, and closes the labeled components through repeated graph
decomposition and linear natural reduction pairs with usable rules.

Ferrum already synthesized the exact forward-instantiation and semantic model,
but its early innermost stage tried ordinary instantiation first. That produced
a larger residual and recursively consumed the branch before forward
instantiation was reached. Racing both transformations exposed a second
performance issue: the certified forward branch finished in 8.4 seconds, but
the scope waited roughly 29 seconds for the losing ordinary-instantiation
recursion to unwind.

The production schedule now tries forward instantiation first with a
10-second compound transform-and-proof budget. Ordinary instantiation follows
only when that attempt fails. This ordering is appropriate here because, unlike
sound reduction-pair deletion, the two transformations do not merely choose
different downward-closed subsets of the same DP problem.

| Example | YES | Certified YES | Isolated | Six-way load |
| --- | ---: | ---: | ---: | ---: |
| `Waldmann_06/jwtpa1.ari` | 1 | 1 | 7.5 s | 8.3 s |

The isolated artifact is
`target/termcomp-runs/20260730-jwtpa1-fi-first-10s`. The loaded regression is
`target/termcomp-runs/20260730-jwtpa1-regression-6x60s` and reports 6 YES,
6 certified YES, and no timeout or certification failure.

No CeTA changes were required. The certificate is accepted by the existing
`.tools/ceta-relative-bounds` checker, so there is no checker patch to
integrate.

## Recovered: `Zantema_05/z01`, `z03`, and `z30`

The retained TTT2 certificates for these examples use ordinary match-bounds.
Ferrum previously materialized each required reduct path directly, which
caused state explosion on context-heavy growing systems. It now implements the
Endrullis et al. FULL online construction with inverse context letters and
height-sensitive cancellation epsilon edges.

All three are now certified by the existing CeTA executable:

| Example | Bound | Result | Focused artifact |
|---|---:|---|---|
| `Zantema_05/z01` | 4 | certified YES | `target/termcomp-runs/20260730-z01-z03-decomp-batch-3x60s` |
| `Zantema_05/z03` | 2 | certified YES | `target/termcomp-runs/20260730-z01-z03-decomp-batch-3x60s` |
| `Zantema_05/z30` | 3 | certified YES | `target/termcomp-runs/20260730-z30-decomp-default-certified-r2-1x60s` |

`z02` is also certified in the three-example batch, but its winning branch is
an existing dependency-pair proof, so it is not counted as a match-bounds gain.
No CeTA changes were required.

## Case Study: `Zantema_05/z01`

Checked on 2026-07-30. AProVE's certified proof uses uncurrying, monotonic
polynomial rule removal, switch-to-innermost, dependency pairs, narrowing,
graph decomposition, forward instantiation, two four-dimensional natural
Arctic reduction pairs, semantic labeling over carrier two, and a final
usable-rule polynomial reduction pair.

Ferrum was missing three connected pieces. Its uncurrying continuation did not
attempt top-level monotonic polynomial deletion, its post-transform order
portfolios stopped at three-dimensional Arctic matrices, and its finite-model
language could not express AProVE's `f1(x) = 1 + x mod 2`. The production
search now attempts checked monotonic polynomial deletion on the uncurried TRS,
tries validated four-dimensional unary Arctic witnesses after graph
decomposition, and supports affine-offset finite-model functions.

All templates are candidates only. Ferrum validates every orientation and
finite-model equation before constructing a proof, and CeTA independently
checks the emitted CPF. Running the cheap Arctic candidate outside the generic
parallel order race reduced isolated runtime from 16.8 seconds to under one
second and eliminated a loaded-run MAYBE caused by waiting for losing solver
branches.

The final retained regression is
`target/termcomp-runs/20260730-z01-regression-final-7x60s`. It reports 7 YES,
7 certified YES, no MAYBE, timeout, or certification failure, and includes all
six previously recovered examples. The focused artifact is
`target/termcomp-runs/20260730-z01-sequential-arctic-template-60s`.

No CeTA changes were required. The proof is accepted by the existing
`.tools/ceta-relative-bounds` checker, so there is no checker source, branch,
or generated executable patch to integrate.

## Case Study: `AProVE_06/identity`

Checked on 2026-07-31. AProVE removes two rules by monotonic polynomial
interpretations, switches the overlay/WCR residual to innermost rewriting, and
uses a rational usable-rule reduction pair with quarter-grid coefficients and
delta `1/2`. The crucial usable set contains three `g` rules compatible with
the fixed `h` argument plus the `half` rule; it excludes the `g(d,...)` and
`double` rules.

Ferrum's former argument-filtered usable-rule computation retained every rule
with a reachable root symbol. It now implements the `matchCapRMBelow`
distinction used by CeTA: immediate argument caps select matching LHSs, while
the argument filter controls recursive descent. A checked structural rational
candidate recognizes the halving-recursion shape and validates the resulting
four-rule witness with exact arithmetic.

The unchanged default strategy now returns YES in about one second, and the
retained CPF at
`target/manual-probes/20260731-identity-default-certified-final/proof.xml`
returns `CERTIFIED`. Earlier rational recoveries `AProVE_07/thiemann40` and
`Beerendonk_07/7` remain certified. No CeTA changes were required.

The same build also newly certifies `AProVE_07/thiemann01` in about one second;
its full artifacts are under
`target/manual-probes/20260731-precise-usable-next8-60s/thiemann01`. Three
other newly found YES proofs in that slice (`otto02`, `otto06`, and `otto12`)
remain uncertified because CeTA retains Q-aware dependency-graph edges after
their DP transformations. They are not counted as certified recoveries, and
no graph-estimation change was made.

## Case Study: `AProVE_07/kabasci05`

Checked on 2026-07-31 against the refreshed 64-example AProVE-certified
frontier. The earlier run timed out. A current default replay decomposes the 14
dependency pairs into ten components. A natural polynomial reduction pair
closes the recursive `gcd#` singleton with the eight `min`, `max`, and `minus`
usable rules. Size change closes the simple recursive arithmetic components,
and a rational natural polynomial closes the remaining five-pair
`transform#`/`cons#` component.

The retained full artifact directory is:

```text
target/manual-probes/20260731-kabasci05-negative-guard-default
```

Ferrum returns YES in about 38 seconds and direct CeTA replay returns
`CERTIFIED`. The nearby negative-constant polynomial correction is independently
guarded by the certified `factorial1` replay at
`target/manual-probes/20260731-factorial1-negative-guard-regression`.

No CeTA changes were required. Both proofs are accepted by the existing
`.tools/ceta-relative-bounds` executable, so there is no checker source or
generated executable patch to integrate.

## Frontier Update: `AProVE_06/tower` and `factorial2`

Checked on 2026-07-31 in the retained eight-example run
`target/termcomp-runs/20260731-aprove06-next8-current-8w60s`. `tower`, which was
UNKNOWN in the refreshed 64-example frontier, now returns YES and is accepted
by CeTA. The other seven examples time out at 60 seconds.

`factorial2` is the next concrete integration target. AProVE's certified chain
narrows twice, rewrites twice, forward-instantiates, and closes by size change,
decomposing after every transformation. Ferrum's focused imitation does not
fail for lack of a processor; its hard-coded post-narrowing continuation fans
out into broad order and transformation portfolios. The retained event stream
contains 1,103 events and 211 graph attempts before timeout. Fixing this calls
for continuation-aware bounded transformation search, not a less conservative
dependency graph.

No CeTA source or generated-checker changes were made.

## Case Study: `Strategy_removed_AG01/#4.26`

Checked on 2026-07-31. AProVE's certified proof switches to innermost
rewriting, decomposes the DP problem, applies usable rules and innermost-LHS
removal, and uses a rational linear reduction pair on the two-pair component.
Ferrum reached the same five usable rules and validated the same quarter-grid
interpretation, but nonlinear SMT synthesis consumed about 20 seconds and
exhausted the switched branch.

Ferrum now derives that interpretation from the symbol-independent
predecessor/comparison shape before invoking SMT. The candidate is accepted
only by the existing exact rational orientation checker. The current default
solves the original Standard problem in 0.4 seconds and the unchanged CeTA
checker returns `CERTIFIED`; full artifacts are documented in
`docs/reproducibility.md`. No dependency-graph or CeTA change was made.

## Case Study: `Secret_05_TRS/teparla1`

Checked on 2026-07-31. AProVE's certificate uses dependency-graph
decomposition, weak compatibility with a monotonic natural polynomial, and
three ordinary DP instantiation steps. Ferrum reproduced this proof class in
83 ms with its existing processors; the miss was entirely in default strategy
scheduling.

The Standard strategy now races a five-second graph-first chain containing
monotonic polynomial compatibility and three one-step instantiation stages.
Graph decomposition follows every transformation. The retained default run at
`target/termcomp-runs/20260731-teparla1-default-instantiation-chain` is a
certified YES in under one second. The eight-example regression at
`target/termcomp-runs/20260731-next-small-certified-cluster-instantiation-chain-8x60s`
contains 6 certified YES, 1 certified NO, and only the `SK90/4.40` timeout.

No CeTA changes were required. The existing
`.tools/ceta-relative-bounds` checker accepts the emitted CPF.

## Case Study: `Secret_06_TRS/5` and `Secret_05_TRS/ttt1`

Checked on 2026-07-31. `Secret_06_TRS/5` was a search-integration miss rather
than a missing processor. AProVE removes the rule `c(c(y)) -> y` by a
monotonic linear polynomial, decomposes the resulting DP problem, removes two
cyclic pairs by a monotonic polynomial interpretation, and removes the last
pair by a 1D natural-Arctic interpretation. Ferrum now tries this focused
continuation for five seconds after top-level polynomial rule removal and
races that rule removal in the early Standard portfolio. The default artifact
at `target/termcomp-runs/20260731-secret06-5-default-focused-poly` is a
certified YES in under one second.

`Secret_05_TRS/ttt1` is nonterminating. AProVE's certificate instantiates the
first dependency pair with `x = cons(s(a),s(b))`, rewrites two arguments by
the relative projection rules, and returns to the DP left-hand side. Ferrum's
ground witness basis previously generated `s(a)` and `cons(a,b)` but not their
nesting. Its bounded basis now takes two unary/binary constructor-closure
rounds, capped at 512 distinct terms. The default artifact at
`target/termcomp-runs/20260731-ttt1-default-ground-dp-loop` is a certified NO
in about one second.

No CeTA changes were required. The existing
`.tools/ceta-relative-bounds` checker accepts both emitted CPFs.

## Case Study: `Strategy_removed_AG01/#4.12a` and `#4.4`

Checked on 2026-07-31. Both retained AProVE certificates prove nontermination
with mixed dependency-pair loops. `#4.12a` alternates two marked DP steps with
relative rewrites. `#4.4` first symbolically narrows by
`g(g(x)) -> g(x)` and then applies its marked `f#` pair; its closing
substitution grows the remaining variable.

Ferrum previously allowed exactly one marked step followed by ordinary
rewriting. Its bounded loop search now explores the mixed `P/R` relation,
including multiple marked root steps and symbolic narrowing when no ground
terms exist. Immediate closing successors are validated before recursive
search. The independent validator replays the complete sequence, checks every
marked rule modulo alpha-renaming against the active DP set, and checks every
relative rule against the TRS.

The final five-example artifact is
`target/termcomp-runs/20260731-strategy-removed-ag01-mixed-dp-loop-final-5x60s`.
It gives four certified NO and one certified YES, with no unknown or
certification gap. No graph estimator or CeTA source was changed; the existing
`.tools/ceta-relative-bounds` checker accepts both new certificates.

## Case Study: `Endrullis_06/pair3swap`

Checked on 2026-07-31. AProVE uses a monotonic natural polynomial DP reduction
followed by a rational polynomial reduction pair. Ferrum implemented the same
classes, but monotonic search was hidden behind the ordinary argument-filtered
polynomial search and therefore received no useful processor time.

Monotonic polynomial reduction is now a first-class `mono-poly` strategy atom
with coefficient, constant, symbol, and arity parameters. The default strategy
races a dedicated monotonic/graph/rational chain against the ordinary early
order ladder. Ferrum finds a stronger monotonic first step than AProVE,
deleting two of three DPs, and its existing rational processor closes the
singleton residual.

The default artifact
`target/termcomp-runs/20260731-pair3swap-default-dedicated-mono-rational`
returns YES in 37 seconds and is accepted by CeTA. The five-example loaded
replay at `target/termcomp-runs/20260731-endrullis-mono-rational-final-5x60s`
retains certified `quadruple1/2` and adds certified `pair3swap`; `pair2hard`
and `linear2` remain the next gaps. No graph-estimation or CeTA changes were
required.

## Case Study: `Endrullis_06/linear2`

Checked on 2026-07-31. AProVE decomposes the problem into two three-pair SCCs,
uses a monotonic natural polynomial reduction in each, and closes the
single-pair residuals with a 3D natural-Arctic interpretation and a 2D integer
matrix interpretation. The latter witness contains only nonnegative `0/1`
entries.

Ferrum now races a cheap graph/monotonic-polynomial/graph chain into its 3D
natural-Arctic and 2D natural-matrix processors. Both generated witnesses pass
Ferrum's exact validators and CeTA. Thus, the example does not require an
integer-matrix extension.

The focused default artifact is
`target/termcomp-runs/20260731-linear2-default-final`, which returns certified
YES in one second. The loaded replay at
`target/termcomp-runs/20260731-endrullis-cluster-all-certified-5x60s` gives
five certified YES out of five, with 4.5 seconds total wall time. No
graph-estimation or CeTA changes were required.

## Case Study: `AG01/#3.22` and `AG01/#3.40`

Checked on 2026-07-31. Both AProVE certificates use a precise usable-rule
restriction followed by nested monotonic polynomial reductions. `#3.40`
strictly removes rules over several `monoRedPairProc` steps; `#3.22` records
the smaller usable set `{2,4,5}` before further processing.

Ferrum formerly used a root-symbol usable-rule over-approximation and could
not synthesize the `#3.22` interpretation. It now implements CeTA's
`check_ur_P_closed_rm_af`/`tcapRM2` closure. Monotonic DP reductions also
delete strictly oriented rules, carry the exact residual `R`, and re-run graph
decomposition after each deletion. No-progress weak models are rejected unless
they establish a proper usable-rule restriction.

The default strategy now proves both examples immediately:

```text
target/termcomp-runs/20260731-ag01-322-default
target/termcomp-runs/20260731-ag01-340-default
```

Both certificates are accepted by CeTA. `#3.22` is closed more directly than
the retained AProVE proof: Ferrum's certified polynomial usable-rule reduction
removes all three pairs of its hard SCC, so its later switch-innermost step is
unnecessary. The existing `#3.18`, `#3.19`, and `#3.39` guard examples remain
certified. No CeTA changes were required.

## Case Study: `Endrullis_06/pair2simple2`

Checked on 2026-07-31. AProVE uses KBO with argument filtering followed by
lexicographic RPO with argument filtering. Ferrum was missing empty
non-collapsing filters for positive-arity symbols and did not enforce equal
statuses for symbols tied by a quasi-precedence. CeTA exposed the latter error
by rejecting Ferrum's first raw YES.

Both the one-shot SMT encoding and the independent model validator now enforce
status-compatible quasi-precedence classes. Empty non-collapsing filters are
part of the exact search domain. The focused proof at
`target/termcomp-runs/20260731-pair2simple2-status-compatible-path-order`
returns YES and is `CERTIFIED` by the existing checker. No CeTA change was
required.

The adjacent `AG01/#3.19` analysis found a separate construction issue:
Ferrum emitted a sound superset of IsaFoR's ordinary `DP_on` set by retaining
defined RHS calls that are proper subterms of the source LHS. Ferrum now uses
the exact subterm-pruned construction. A focused trace confirms the same
four-pair cyclic component as AProVE, and `jwteparla1` remains CeTA-certified.
Ferrum's RPO relation accepted AProVE's exact witness, but a separate
filtered-term-size heuristic rejected it because one rule grows in size.
Removing that non-RPO condition recovers `#3.19` as a certified YES in 1.05
seconds. No dependency-graph estimator or CeTA source was changed.

## Case Study: small relative DP loops

Checked on 2026-07-31. Seven small AProVE-certified NO proofs use the same
shape: dependency-pair transformation, optional sound pair/rule removal, and
a concrete loop with one marked DP step plus ordinary relative TRS rewrites.
The smallest witness is `AProVE_08/round_nonterm`, whose marked `f#` step is
closed by one rewrite of `round(0)`.

Ferrum now searches this proof class directly by grounding a dependency pair
with shallow signature terms and running bounded breadth-first rewriting from
its right-hand side. Accepted witnesses are independently replayed and
exported with CPF `<relative/>` markers. The run
`target/termcomp-runs/20260731-next-small-ground-dp-loop-final-12x60s` recovers all
seven as certified NO, alongside four certified YES; only
`Endrullis_06/pair2simple2` remains MAYBE.

No CeTA changes were required. The existing
`.tools/ceta-relative-bounds` checker certifies every new loop proof.

## Case Study: `Waldmann_06/jwteparla2`

Checked on 2026-07-31. AProVE's certificate uses uncurrying, switch-innermost,
a negative-constant natural polynomial reduction pair, root narrowing, graph
decomposition, forward instantiation, a two-dimensional matrix reduction
pair, usable rules, innermost-LHS removal, and size change.

Ferrum found a raw YES through semantic labeling, but CeTA rejected its final
graph decomposition because a labeled IEDG edge was missing. The implementation
had incorrectly required Ferrum's CAP/nonreachability approximation to approve
an edge already admitted by IEDG. IsaFoR proves that IEDG itself
over-approximates the dependency graph, so Ferrum now retains every IEDG edge
independently. The exact labeled checker state is covered by a regression.

The isolated artifact
`target/termcomp-runs/20260731-jwteparla2-qiedg-fix-1x60s` is certified YES in
14 seconds. The full Waldmann replay at
`target/termcomp-runs/20260731-next-waldmann-qiedg-fixed-final-15x60s` gives
11 certified YES and 4 certified NO with no certification gap. No CeTA source
or generated-checker change was required.

## Case Study: transformed-CSR `_C` siblings

Checked on 2026-07-31. AProVE's certified proofs for
`Transformed_CSR_04/Ex4_7_15_Bor03_C.ari` and
`Transformed_CSR_04/ExProp7_Luc06_C.ari` use repeated
`monoRedPairUrProc` steps. The first such step removes no DP and restricts the
22-rule component to 20 usable rules; after pair deletion, another usable-rule
step can restrict the residual further. The apparent integer-matrix gap was a
false lead: in the relevant CeTA CPF parser, natural and integer matrix
interpretations are checked through the same integer-matrix carrier, and the
AProVE matrices contain only zero and one entries.

Ferrum now recomputes usable rules relative to the current active `R`, not just
the original TRS. A zero-DP-deletion monotonic step is accepted only for a
strictly smaller certified rule component, and graph decomposition immediately
follows the transition. The transformed-CSR default strategy now tries a
compact parallel polynomial/matrix/KBO/size-change/subterm ladder early.

The retained final run is
`target/termcomp-runs/20260731-transformed-csr-default-certified-final-2x60s`.
It reports 2 YES and 2 certified YES in under one second per example, with no
certification gap. No CeTA source or generated-checker changes were needed;
the existing `.tools/ceta-relative-bounds` executable certifies both CPFs.
The sequential certification smoke at
`target/termcomp-runs/20260731-transformed-csr-mono-usable-sequential-2x15s`
also gives 2 certified YES and exercises five `monoRedPairUrProc` nodes in
each retained CPF. The winning default proofs instead combine usable-rule
restriction with matrix deletion in `redPairUrProc`; both standard CPF forms
are therefore covered.

## Case Study: `Beerendonk_07/7` and transformed-CSR narrowing

Checked on 2026-07-30. AProVE's certified `Beerendonk_07/7` proof switches to
innermost rewriting, decomposes the dependency graph into singleton SCCs,
deletes the hard `cond#` pair with five usable rules and a rational polynomial
reduction pair, and closes the remaining cycle by size change.

Ferrum's coefficient and strict-gap denominators had been coupled. The
rational processor now searches quarter-grid coefficients with an independent
delta of `1/16`, normalizes the witness to denominator 16, and validates the
exact inequalities before proof construction. Z3 is the direct default for
this integer/Boolean encoding; cvc5 remains an availability fallback. The
default retained run is
`target/termcomp-runs/20260730-beerendonk7-default-final-1x60s`, which gives
one certified YES in 2.8 seconds.

The subsequent historical-gap replay found two raw YES results rejected at
full-rewriting DP narrowing steps. Ferrum had applied CeTA's `icap` position
condition only to innermost narrowing. The checker theorem applies it in both
modes, with `Q = empty` for full rewriting. Ferrum now checks that exact
condition and selects the valid ancestor region instead of a descendant erased
by `icap`. The retained regression
`target/termcomp-runs/20260730-transformed-csr-narrowing-certified-2x60s`
gives 2 YES and 2 certified YES for `Ex6_9_Luc02c_iGM` and
`ExProp7_Luc06_iGM`.

No CeTA changes were required. All three certificates are accepted by the
existing `.tools/ceta` checker, so there is no checker patch to integrate.

The two remaining `_C` siblings were retained at
`target/termcomp-runs/20260730-transformed-csr-c-timeouts-isolated-2x60s`.
`Ex4_7_15_Bor03_C` times out and `ExProp7_Luc06_C` returns MAYBE. Their AProVE
certificates use the same graph-first pattern: monotonic polynomial usable-rule
deletion, a two-dimensional matrix interpretation over the integers, another
monotonic polynomial deletion, and KBO; the other SCCs close by size change.
Ferrum currently emits only natural-domain matrix interpretations. A
first-class integer-domain matrix reduction-pair processor is therefore the
next shared strengthening for these examples.

## Case Study: `Der95/30` and `AProVE_07/thiemann40`

Checked on 2026-07-30. A ten-example replay of historical certified misses
showed that eight were stale gaps already handled by current Ferrum. The two
live failures had distinct causes.

`Der95/30` is directly oriented by the existing top-level recursive path order,
but that cheap processor was starved inside the larger transformation race.
Ferrum now gives top-level path order an isolated early race against cheap DP
processors.

`thiemann40` requires AProVE's interpretation-dependent usable-rule argument:
a rational linear interpretation with delta `1/4` removes one pair while
requiring four rather than six usable rules. Ferrum's rational processor now
synthesizes the active positions and usable-symbol fixed point together with
the interpretation. It independently validates the returned model and emits a
CeTA-checkable rational `redPairUrProc`; graph decomposition closes the
remaining singleton.

The retained final run,
`target/termcomp-runs/20260730-der30-thiemann40-default-final-2x60s`, gives
2 certified YES in five seconds with no certification gap. No CeTA changes
were needed.

## Case Study: `Zantema_05/z05`

Checked on 2026-07-30. AProVE's certified proof uncurries the system, applies
two polynomial rule-removal steps, deletes three of six dependency pairs with
a polynomial reduction pair, narrows each residual origin once, and uses a
three-dimensional natural-Arctic interpretation with strict dimension one.
The final two pairs are acyclic.

Ferrum's former Arctic encoding interpreted strict dimension one as strictness
in every row. Both synthesis and exact validation now implement the CPF
semantics: row zero is strict and all remaining rows are weak. Ferrum also
removed an unintended global two-step narrowing cutoff, retained the proper
per-origin/per-kind budgets, and added a structurally derived Arctic candidate
for the resulting unary marked cycle. The candidate is never trusted without
the ordinary exact obligation checks.

The final artifact is
`target/termcomp-runs/20260730-zantema-siblings-final-2x60s`. Both `z05` and
its sibling `z07` are YES and `CERTIFIED`, with no certification gap. The
focused uncurrying-only artifact is
`target/termcomp-runs/20260730-z05-per-origin-one-uncurry-only-65s`.

No CeTA changes were required. The existing
`.tools/ceta-relative-bounds` checker accepts the generated CPF.

## Case Study: `Zantema_05/z22`

Checked on 2026-07-30. AProVE's certified proof combines KBO with a collapsing
argument filter, carrier-two semantic labeling, dependency-graph
decomposition, and repeated polynomial reduction pairs. Its finite model is
`a=1`, `b=c=0`, `f=0`, and `f#=0`.

Ferrum's specialized binary semantic-labeling search formerly covered only
two constants. It now handles the structural class of constants plus one
marked/unmarked binary pair and tries distinguished-constant models with
constant or projection interpretations for the binary symbol. Every candidate
is checked against all finite-model equations. Linear polynomial synthesis now
uses one Z3 Optimize query to maximize strict pair deletion while jointly
synthesizing the interpretation-dependent usable-rule closure. A parser fix
ensures Boolean usable-rule definitions cannot swallow following bit-vector
coefficients in optimized models.

The final regression at
`target/termcomp-runs/20260730-z22-semlab-regression-4w60s` gives 4 YES and
4 certified YES for `z01`, `z05`, `z19`, and `z22`. `z22` takes 49.277
seconds under four-worker load. No CeTA changes were required; the existing
`.tools/ceta-relative-bounds` checker accepts the generated CPF.

The related `z21` is now also certified. The polynomial query uses
lexicographic objectives (maximum strict deletion, minimum usable closure,
minimum parameter sum), and binary semantic models are ranked from the
residual DP signature. This selects AProVE's direct projection-shaped route
before the valid but expensive `a=b=1, f=f#=0` detour. The default artifact
`target/termcomp-runs/20260730-z21-ranked-semlab-r1-1x60s` is certified in
0.372 seconds. The earlier Arctic-containing raw proof remains rejected and is
not evidence for this result.

## Case Study: `Zantema_05/z27`

Checked on 2026-07-30. AProVE first uses KBO with a collapsing argument filter
to remove one of four dependency pairs. Ferrum already reaches the same
three-pair residual with KBO/AF or a polynomial reduction pair. AProVE then
uses the carrier-two model `0=0`, `1=1`, `g(x)=x`, and
`f(x,y,z)=f#(x,y,z)=0`, followed by graph decomposition and linear polynomial
closures.

Ferrum now proposes this symbol-name-independent structural model class for
two constants, one unary symbol, and a marked/unmarked pair of matching arity.
Both distinguished constants are considered, and the complete finite-model
and recursive proof checks remain mandatory. The default run at
`target/termcomp-runs/20260730-z27-structural-semlab-r1-1x60s` gives a
CeTA-certified YES in 1.116 seconds.

The combined loaded regression at
`target/termcomp-runs/20260730-z21-z27-semlab-regression-6x60s` gives 6/6
certified YES for `z01`, `z05`, `z19`, `z21`, `z22`, and `z27`, without a
certification gap. No CeTA changes were required; all proofs are accepted by
the existing `.tools/ceta-relative-bounds` checker.

## Case Study: `AProVE_04/JFP_Ex31`

Checked on 2026-07-30. AProVE's certified proof narrows the hard `top#`
component, decomposes it, applies a carrier-two semantic labeling that creates
39 rules and 18 dependency pairs, and repeatedly removes labeled pairs with
linear polynomial reduction pairs whose zero coefficients induce different
usable-rule subsets.

Ferrum already found the exact finite model, but its ordinary linear
polynomial processor first required the complete precomputed usable-rule set
to be weakly oriented. The processor now synthesizes coefficients and the
interpretation-dependent usable-rule reachability fixed point in one QF_BV
query. Every decoded interpretation, filtered closure, weak inequality, and
strict deletion is independently checked before CPF emission.

A generic solver-process bug also hid satisfiable models: Ferrum waited for
child exit before draining stdout/stderr, so a model larger than the pipe
capacity deadlocked. Managed solver children now drain both streams
concurrently, including during cancellation. The extracted hard query is
solved by Boolector and Z3 in under 0.1 seconds.

The default-strategy artifact is
`target/termcomp-runs/20260730-jfp-ex31-default-final/proof.cpf.xml`. Ferrum
returns YES and the existing `.tools/ceta-relative-bounds` checker returns
`CERTIFIED`.

During loaded regression, Ferrum also corrected narrowing certificates to
match CeTA's formal regional semantics: a CPF position is a lower bound `p`,
and the witness contains narrowings at every selected descendant position
`q >= p`. The focused `z01`/`jwaprove2` regression is 2/2 certified. The final
two-worker 12-example regression at
`target/termcomp-runs/20260730-jfp-ex31-regression-final-v3-12x60s` gives 10
certified YES and 2 certified NO, with no unknown, timeout, error, or
certification failure.

No CeTA changes were required. The existing checker accepts the JFP proof and
the repaired narrowing proofs, so there is no checker patch to integrate.

## Case Study: `AProVE_04/IJCAR_26` and `IJCAR_26a`

Checked on 2026-07-30. AProVE decomposes 20 dependency pairs. Its hard
four-pair `div#`/`quot#` SCC uses three KBO reduction-pair deletions with
collapsing argument filters and empty usable-rule closures, followed by size
change. The `a` variant adds only `p(0) -> 0`.

Ferrum's former one-shot KBO encoding oriented the unfiltered rule context,
which made these valid KBO classes appear UNSAT. KBO search now couples
precedence, weights, argument filters, weak/strict pair orientation, and
usable-symbol reachability in one SMT query. The decoded witness is not
trusted: Ferrum recomputes CeTA-style active-position usable rules and checks
admissibility plus every concrete KBO comparison.

The active-position detail matters. Every application root is checked for
defined rules before recursion continues through filter-selected arguments.
An early implementation instead erased roots under collapsing filters and was
rejected by CeTA on JFP and both `jwmatchb` examples. Those failures led to the
correct executable-definition-aligned implementation.

Both IJCAR examples now return default YES and `CERTIFIED`. The final
14-example regression at
`target/termcomp-runs/20260730-ijcar26-regression-final-v2-14x60s` gives 12
certified YES and 2 certified NO with no losses or checker failures.

No CeTA changes were required. The existing
`.tools/ceta-relative-bounds` checker accepts every retained certificate, so
there is no checker patch to integrate.

## Case Study: `AProVE_06/factorial1`

Checked on 2026-07-30. AProVE's certified proof switches to innermost rewriting
and decomposes ten dependency pairs into singleton SCCs. The cyclic `fac#`,
`times#`, and `plus#` pairs are deleted by negative-constant natural
polynomial reduction pairs with interpretation-dependent usable rules; `p#`
is closed by size change.

Ferrum's graph already exposed the same singleton cycles. The missing power was
the coupled reduction-pair search: its former `weak-poly` path clamped negative
constants to zero and oriented the larger pre-filter usable-rule set. Ferrum
now uses a one-shot quantified SMT encoding of recursive `max(0,p)` semantics.
Zero coefficients determine active argument positions, and Boolean closure
variables determine the usable rules in the same query. After model decoding,
Ferrum independently recomputes the usable-rule closure and uses QF_LIA
counterexample queries to validate every universal orientation claim.

The default Standard strategy proves the example through `switchInnermost` in
3.5 seconds. The focused artifact is
`target/termcomp-runs/20260730-factorial1-negative-max-polynomial/default-standard-final.cpf.xml`.
The 11-example loaded regression at
`target/termcomp-runs/20260730-factorial1-regression-11x60s` gives 9 certified
YES and 2 certified NO with no losses or certification failures.

No CeTA changes were required. The existing
`.tools/ceta-relative-bounds` checker accepts both the direct innermost and
default Standard certificates, so there is no checker patch to integrate.

## Case Study: `Zantema_05/z19`

Checked on 2026-07-30. AProVE's certified proof starts with five dependency
pairs. A monotonic linear polynomial reduction pair removes part of the
problem, using `f(x,y) = x + y`, `a = 2`, `b = 0`, and
`f#(x,y) = 2x + 2y`. A carrier-two semantic labeling with `a = 1` and all
other symbols zero then exposes smaller graph components, which are closed by
repeated linear polynomial deletion and graph decomposition.

Ferrum previously spent the residual budget on narrowing and forward
instantiation before returning to the ordinary graph/order portfolio. Full
DP residuals after reduction-pair deletion now retry that portfolio first.
Innermost DP problems retain their existing transform-first order. Ferrum also
tries the required semantic model for the exact structural class consisting of
two constants and one marked/unmarked binary pair. The candidate's
interpretations are validated against all model equations before any labeling
proof is accepted.

The final retained regression is
`target/termcomp-runs/20260730-z19-regression-final-v3-8x60s`. It gives 8 YES,
8 certified YES, and no MAYBE, timeout, error, or checker failure. Explicit
CeTA replay returns `CERTIFIED` for every stored CPF. A no-model control at
`target/termcomp-runs/20260730-z19-order-first-no-model-hint-60s` remains
MAYBE, establishing that residual scheduling alone does not account for the
recovery.

No CeTA changes were required. The proof is accepted by the existing
`.tools/ceta-relative-bounds` checker, so there is no checker source, branch,
or generated executable patch to integrate.
