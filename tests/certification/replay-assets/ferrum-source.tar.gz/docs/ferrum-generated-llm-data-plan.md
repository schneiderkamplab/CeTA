# Ferrum-Generated LLM Data Plan

This document records the next data-generation direction after the first HRM
strategy model experiments.

## Current HRM Result

We trained an XS HRM-Text model after excluding deterministic processor labels
from the direct strategy dataset. The excluded families were:

- `graph`
- `subterm`
- `size-change`

The remaining train split had 61,452 rows before length filtering and 58,261
packed rows after the 16k token cap. The final run was:

- Run: `ferrum-strategy-xs-nondet-ctx16k-10epoch-val-20260719-081814`
- Checkpoint: `/work/dfm/HRM-Text/checkpoints/ferrum_strategy_xs_nondet/ferrum-strategy-xs-nondet-ctx16k-10epoch-val-20260719-081814/fsdp2_epoch_10`
- HF export: `/work/dfm/HRM-Text/exports/ferrum/xs-nondet-epoch10-hf`
- Test input: `target/termcomp-proof-corpus/training/hrm-strategy-direct-nondet/ferrum.strategy.direct.nondet.test.jsonl.gz`

Results on the filtered nondeterministic test set:

| model | accuracy | exact accuracy | correct processor family |
|---|---:|---:|---:|
| baseline XS, trained on all processors | 0.94202 | 0.23459 | 0.52226 |
| XS, trained without deterministic processors | 0.95435 | 0.37671 | 0.72432 |

The useful signal is the processor-family score. Removing deterministic labels
made the model substantially better on the search-heavy processors.

## Goal

Generate additional supervised and ranking data by running Ferrum itself on
large benchmark sets, including:

- TRS Standard
- TRS Innermost
- SRS Standard
- CSR

For every processor application, record the exact subproblem before the
processor, the processor invocation, and one of four outcomes:

- `solved`
- `transformed`
- `failed`
- `timeout`

This gives training data for both choosing processors and choosing parameters.
Unlike proof-corpus extraction, it also records negative evidence.

Implemented command-line hooks:

- `--processor-events <path>` writes processor-attempt JSONL rows.
- `--timeout-multiplier <factor>` scales all parsed `timeout(...)` wrappers in
  the top-level, dependency-pair, and nontermination strategy trees.

The intended collection multipliers are `0.25`, `0.5`, `1.0`, `2.0`, and
`4.0`, using the same default strategy rather than maintaining separate
strategy files.

## Event Model

Each attempted processor application should emit one JSONL event. The event
should be written before returning from the processor wrapper so timeouts and
failures are observable even when the outer strategy continues.

Proposed schema:

```json
{
  "schema": "ferrum.processor-event.v1",
  "run_id": "20260719-...",
  "problem_id": "TPDB/TRS_Standard/...",
  "problem_format": "trs",
  "termination_mode": "standard",
  "strategy_path": "default.orders.poly",
  "node_id": "stable-subproblem-id",
  "parent_node_id": "stable-parent-id-or-null",
  "processor": "poly",
  "parameters": {
    "max_constant": 2,
    "max_coefficient": 2
  },
  "input": {
    "cpf": "<problem>...</problem>",
    "summary": {
      "rules": 12,
      "defined_symbols": 4,
      "constructors": 7,
      "dependency_pairs": 9,
      "scc_size": 3
    }
  },
  "outcome": "transformed",
  "soundness": {
    "termination_sound": true,
    "nontermination_complete": false,
    "preserves_no": false
  },
  "elapsed_ms": 37,
  "timeout_ms": 1000,
  "result": {
    "removed_pairs": 2,
    "removed_rules": 0,
    "new_subproblems": 1,
    "proof_fragment_cpf": "<proof>...</proof>"
  },
  "error": null
}
```

For `failed`, `result` should be null and `error` should identify the reason:
`unsat`, `no_model`, `inapplicable`, `unsupported_shape`, `solver_error`, etc.

For `timeout`, the event must include the configured timeout and elapsed time.
If a subprocess was spawned, the event should also record whether it was killed.

The first implemented schema logs these stable fields:

- `schema`: currently `ferrum.processor-event.v1`
- `level`: `top-level` or `dependency-pair`
- `problem_kind`: currently `trs` or `qdp`
- `strategy_atom` and `processor`: the concrete strategy leaf/debug atom
- `outcome`: `solved`, `transformed`, `failed`, or `timeout`
- `progress`: `closed`, `strong`, `weak`, or `none`
- `elapsed_ms`
- `input.cpf`: CPF3 `<trsInput>` for top-level rows and CPF3 `<dpInput>` for
  dependency-pair rows, describing the current refined subproblem before the
  processor attempt
- `metrics`: rule/pair counts and accumulated DP stats
- `witness`: proof steps or DP proof tree in Debug form when available
- `credit.status`: initially `pending`

The Debug witness is deliberately retained even before the final training
projection is fixed. It preserves coefficients, matrices, precedences,
argument filters, bounds artefacts, and loop/instantiation/narrowing witnesses
for later extractors.

## Outcome Semantics

`solved`:
The processor closed the current subproblem. For termination branches, this
means the processor produced a sound proof fragment. For nontermination
branches, the processor produced a complete-enough witness under the branch
history.

`transformed`:
The processor made progress but did not close the subproblem. Examples:
removed one or more DPs, removed rules, split SCCs, instantiated or narrowed to
new subproblems, or switched to a different problem mode.

`failed`:
The processor finished within its timeout and made no progress. This includes
SAT/SMT unsat, no compatible order found, no usable narrowing, and processor
preconditions not met.

`timeout`:
The processor did not finish within the configured per-processor timeout. This
is distinct from `failed` because it is a scheduling/resource signal, not a
semantic negative.

`closed`:
The processor proved or disproved the current subproblem.

`strong`:
The processor did not close the subproblem but made clear structural progress,
such as removing pairs/rules, splitting components, or proving a usable-rule
restriction.

`weak`:
The processor performed useful work or changed search state without a direct
decrease signal. This category is useful for ranking expensive attempts that
often prepare later successes.

`none`:
The processor was inapplicable, failed, or timed out without measurable
progress.

## Training Views

The raw processor-event log can be projected into several datasets.

### Strategy-Atom Choice

Input:

- CPF subproblem
- mode metadata
- cheap feature summary
- strategy context

Target:

- concrete Ferrum strategy atom, including parameters when available

Examples:

- `subterm`
- `size-change`
- `poly(max-constant=2,max-coefficient=2)`
- `matrix(dim=2,max-constant=1,max-coefficient=1)`
- `kbo(max-weight=2)`
- `path-order-af(status=lex,filter=...)`

This view intentionally combines processor-family and parameter prediction. A
model that predicts the fully parameterized atom can always be projected to a
coarser processor family by ignoring parameters, while the reverse projection
loses information. The training pipeline should therefore store the full
strategy atom as the primary label and derive these secondary labels:

- `processor_family`: `poly`, `matrix`, `kbo`, `path-order`, `subterm`, etc.
- `parameter_profile`: the normalized parameters for the family, or empty for
  deterministic processors
- `is_deterministic`: whether the family has no meaningful parameter choice

The coarse processor-family target is still useful for evaluation and for
models that only choose which solver/search module to run. It should be treated
as a projection of the full atom, not as the only label.

Positive rows are `solved` and useful `transformed` events. Negative rows are
`failed` and `timeout` events, but they should not be used as ordinary
next-token targets for the attempted atom. They should feed the ranking and
contrastive views below.

### Parameter Choice

Input:

- CPF subproblem
- selected processor family

Target:

- parameters that succeeded or made progress

Examples:

- `poly(max-constant=2,max-coefficient=2)`
- `matrix(dim=2,max-constant=1,max-coefficient=1)`
- `kbo(weight-bound=...)`
- `path-order-af(status=lex,filter=...)`

This separate view is optional once Strategy-Atom Choice is used. It remains
useful for targeted models that only tune parameters after a symbolic strategy
has already selected a processor family.

### Candidate Ranking

Input:

- CPF subproblem
- candidate processor invocation

Target:

- `solved`, `transformed`, `failed`, or `timeout`
- optional utility score

This is likely the most useful Ferrum integration target. The LLM can rank
candidates before the strategy spends solver time.

The ranking view is the main place where negative examples contribute. For a
fixed or near-duplicate subproblem, collect all attempted candidate atoms and
assign a utility score. A practical initial score is:

- `solved`: strong positive
- `transformed` with `progress=strong`: positive
- `transformed` with `progress=weak`: small positive or neutral
- `failed` with `progress=none`: negative
- `timeout`: strong negative for the observed timeout budget

The score should include time:

```text
utility = outcome_reward - time_penalty(elapsed_ms, timeout_ms)
```

For successful attempts, faster rows with smaller parameters should outrank
slower or larger ones that achieve the same progress. For timeouts, the label
means "bad at this budget", not "mathematically impossible"; timeout rows should
therefore remain tied to the configured timeout multiplier.

Recommended training formats:

- Pairwise: for the same subproblem, rank successful/progressing atoms above
  failed/timeouted atoms.
- Listwise: present a candidate set and train the model to order it by utility.
- Binary evaluator: input `(subproblem, candidate atom)` and predict
  success/progress probability plus expected cost.

This avoids the main imbalance problem: the raw event log has many more failed
attempts than successful ones, so plain SFT on all attempted atoms would teach
the model to imitate bad choices. Negatives should instead define what not to
rank highly.

### Witness Prediction

Input:

- CPF subproblem
- processor family and parameters

Target:

- coefficients
- matrices
- precedences
- statuses
- argument filters
- loop/narrowing/instantiation choices

This should be populated when the processor returns a concrete model or proof
fragment.

Witness rows should be high-trust. Prefer rows whose witness is independently
checkable by Ferrum and, when supported, by CPF/CeTA or the fragment checker.
Do not train coefficient/matrix/precedence witnesses from unchecked Debug text
unless the extractor validates the witness by replaying the corresponding
processor.

## Dataset Imbalance Handling

The collected processor-event dataset is intentionally imbalanced: most
processor attempts fail. This is expected for a prover strategy because proof
search tries many candidates and keeps only the useful ones.

The training pipeline should handle this by separating three questions:

1. What should be tried next?
2. Given a candidate, is it worth its cost?
3. If it is worth trying, what witness should be proposed?

For question 1, build positive SFT rows only from successful or credited
progressing attempts. Use backward credit propagation from final YES/NO branches
so intermediate `transformed` rows that contributed to a proof are positive,
while unproductive transformations are neutral or negative.

For question 2, use the full event log, including negatives, in a ranking or
binary-evaluator dataset. This is where the failed and timeout rows carry most
of their value.

For question 3, use only rows with checked witnesses or proof fragments.

Recommended balancing rules:

- Stratify by problem family, mode, processor family, and outcome.
- Downsample repeated easy failures from the same subproblem and processor
  family.
- Keep hard negatives: candidates that look plausible, ran for nontrivial time,
  or only fail after solver search.
- Keep timeout negatives separately by timeout multiplier.
- Oversample rare successful families such as matrix interpretations, path
  orders with argument filtering, match bounds, narrowing, and instantiation.
- Evaluate both exact strategy-atom accuracy and coarse processor-family
  accuracy, since family-correct but parameter-wrong predictions can still be
  useful online.
- Never turn a failed attempt into a target completion in direct SFT. Failed
  attempts are candidate-ranking evidence, not demonstrations.

The online integration should exploit this split: ask the model for a small
ranked list of fully parameterized strategy atoms, optionally collapse them to
processor families if confidence is low, then verify every returned candidate
with Ferrum's existing checkers.

## Status-Map SFT Dataset

The first Ferrum-generated SFT projection uses a status-to-atoms response. It
groups processor-event rows by `sha256(input.cpf)` and deduplicates candidates
by normalized strategy atom. Unlike the earlier positive-only direct datasets,
it includes unsolved subproblems: rows may contain only `failed:` and
`timeout:` sections.

The response format is plain HRM-Text `direct` text:

```json
{
  "condition": "direct",
  "instruction": "<input>\n<dpInput>...</dpInput>\n</input>",
  "response": "solved:\npoly(max-constant=2,max-coefficient=2)\n\nfailed:\nsubterm\n\ntimeout:\nmatrix(dim=2,max-constant=2,max-coefficient=1)"
}
```

Actual section labels are:

- `solved`
- `transformed_strong`
- `transformed_weak`
- `failed`
- `timeout`

Generation command:

```bash
python3 scripts/build_hrm_status_map_dataset.py \
  --input target/processor-event-runs/all.processor-events.jsonl \
  --out-prefix target/termcomp-proof-corpus/training/hrm-status-map/ferrum.status-map.direct \
  --sqlite target/termcomp-proof-corpus/training/hrm-status-map/status-map.sqlite \
  --summary target/termcomp-proof-corpus/training/hrm-status-map/ferrum.status-map.direct.summary.json \
  --progress-every 200000 \
  --keep-sqlite
```

Result:

| quantity | count |
|---|---:|
| input processor-event rows | 1,148,735 |
| grouped CPF subproblems / output rows | 26,141 |
| deduplicated candidates | 212,598 |
| train rows | 23,421 |
| validation rows | 1,348 |
| test rows | 1,372 |
| solved candidates | 7,532 |
| transformed strong candidates | 88 |
| transformed weak candidates | 33,656 |
| failed candidates | 155,166 |
| timeout candidates | 16,156 |

Output files:

```text
target/termcomp-proof-corpus/training/hrm-status-map/ferrum.status-map.direct.train.jsonl.gz
target/termcomp-proof-corpus/training/hrm-status-map/ferrum.status-map.direct.validation.jsonl.gz
target/termcomp-proof-corpus/training/hrm-status-map/ferrum.status-map.direct.test.jsonl.gz
target/termcomp-proof-corpus/training/hrm-status-map/ferrum.status-map.direct.summary.json
target/termcomp-proof-corpus/training/hrm-status-map/status-map.sqlite
```

Section coverage in the generated splits:

| split | rows | solved | transformed strong | transformed weak | failed | timeout |
|---|---:|---:|---:|---:|---:|---:|
| train | 23,421 | 3,715 | 63 | 4,509 | 14,519 | 9,851 |
| validation | 1,348 | 215 | 2 | 242 | 845 | 595 |
| test | 1,372 | 201 | 5 | 240 | 891 | 589 |

## Status-Map Tokenizer

The HRM BPE tokenizer was extended with atomic tokens for the status labels and
the normalized strategy atoms used by the status-map dataset, including
`sat-poly`, `weak-poly`, `rational-poly`, `semantic-labeling`, `uncurry`,
`rewrite`, `srs-weighted-length`, and `srs-weighted-rule-removal`.

Tokenizer command:

```bash
python3 scripts/build_hrm_bpe_tokenizer.py \
  --input \
    target/termcomp-proof-corpus/training/hrm-status-map/ferrum.status-map.direct.train.jsonl.gz \
    target/termcomp-proof-corpus/training/hrm-status-map/ferrum.status-map.direct.validation.jsonl.gz \
    target/termcomp-proof-corpus/training/hrm-status-map/ferrum.status-map.direct.test.jsonl.gz \
  --out-dir target/termcomp-proof-corpus/training/tokenizers/ferrum-status-map-bpe \
  --vocab-size 32000 \
  --min-frequency 2
```

Tokenizer result:

| quantity | count |
|---|---:|
| final vocab size | 9,662 |
| added atomic tokens | 122 |
| XML tag tokens | 33 |
| canonical symbol tokens | 27 |
| strategy/status word tokens | 81 |
| punctuation tokens | 10 |
| missing atomic tokens | 0 |

Output directory:

```text
target/termcomp-proof-corpus/training/tokenizers/ferrum-status-map-bpe
```

## XXS Status-Map Training Run

An XXS HRM-Text model was trained for 10 epochs on the status-map direct data.
The run used the `hrm` conda environment, one visible GPU, 16k token packing,
and W&B project `Ferrum-HRM`.

Packed training-data command:

```bash
python3 scripts/build_hrm_sampled_dataset.py \
  --input target/termcomp-proof-corpus/training/hrm-status-map/ferrum.status-map.direct.train.jsonl.gz \
  --tokenizer target/termcomp-proof-corpus/training/tokenizers/ferrum-status-map-bpe/tokenizer.json \
  --output /work/dfm/HRM-Text/data/sampled_ferrum_status_map_xxs_ctx16k_10epoch \
  --epochs 10 \
  --max-seq-tokens 16384 \
  --seed 0 \
  --progress-interval 5000
```

Packed training-data result:

| quantity | count |
|---|---:|
| rows seen | 23,421 |
| rows kept | 22,316 |
| skipped too long | 1,105 |
| skipped unknown-token rows | 0 |
| maximum sequence length | 16,382 |
| packed total token length | 34,957,007 |
| epochs | 10 |

Packed validation data was materialized with many epochs because HRM validation
uses epoch-indexed sampled directories during repeated validation calls:

```bash
python3 scripts/build_hrm_sampled_dataset.py \
  --input target/termcomp-proof-corpus/training/hrm-status-map/ferrum.status-map.direct.validation.jsonl.gz \
  --tokenizer target/termcomp-proof-corpus/training/tokenizers/ferrum-status-map-bpe/tokenizer.json \
  --output /work/dfm/HRM-Text/data/sampled_ferrum_status_map_validation_ctx16k \
  --epochs 600 \
  --max-seq-tokens 16384 \
  --seed 1 \
  --progress-interval 5000
```

Training command:

```bash
cd /work/dfm/HRM-Text
source /home/ucloud/miniforge3/etc/profile.d/conda.sh
conda activate hrm

CUDA_VISIBLE_DEVICES=2 torchrun --nproc_per_node=1 --master_port=29531 pretrain.py \
  arch/size@arch=XXS \
  data.path=data/sampled_ferrum_status_map_xxs_ctx16k_10epoch \
  +data.validation_path=data/sampled_ferrum_status_map_validation_ctx16k \
  +data.target_only=true \
  lr=2e-4 \
  lr_min_ratio=1.0 \
  lr_warmup_steps=5 \
  weight_decay=0.1 \
  beta1=0.9 \
  beta2=0.95 \
  ema=null \
  global_batch_size=32768 \
  gradient_accumulation_steps=1 \
  epochs=10 \
  distributed_strategy=ddp \
  ddp_params_precision=fp32 \
  ddp_find_unused_parameters=true \
  checkpoint_format=sharded \
  checkpoint_interval=1 \
  checkpoint_step_interval=null \
  ephemeral_checkpoint_step_interval=null \
  checkpoint_path=checkpoints/ferrum_status_map_xxs/ferrum-status-map-xxs-ctx16k-10epoch-20260722-084712 \
  compile_train_batch=false \
  fwd_bwd_dtype=bfloat16 \
  accelerator_type=sm100 \
  log_interval=1 \
  +validation_interval=20 \
  +validation_batches=8 \
  project_name=Ferrum-HRM \
  run_name=ferrum-status-map-xxs-ctx16k-10epoch-20260722-084712 \
  seed=0
```

Completed run:

| quantity | value |
|---|---|
| W&B run | `https://wandb.ai/peter-sk-sdu/Ferrum-HRM/runs/pqy46koz` |
| checkpoint root | `/work/dfm/HRM-Text/checkpoints/ferrum_status_map_xxs/ferrum-status-map-xxs-ctx16k-10epoch-20260722-084712` |
| final checkpoint | `fsdp2_epoch_10` |
| final checkpoint state | `checkpoint_state_epoch_10.json` |
| epoch | 10 |
| step | 11,565 |
| model parameters | 10,485,760 |
| final train accuracy | 0.96850 |
| final train exact accuracy | 0.58333 |
| final validation accuracy | 0.96818 |
| final validation exact accuracy | 0.44521 |
| final validation loss | 0.09282 |

The first HF export attempt exposed a DDP checkpoint-loading issue: the sharded
checkpoint stores tensors below `model.module.*`, while the inference/export
loader initially tried the unwrapped key names and silently exported randomly
initialized weights. The HRM loader was updated to handle the `module.` prefix
when loading sharded DDP checkpoints for inference/export.

Corrected HF export:

```bash
cd /work/dfm/HRM-Text
source /home/ucloud/miniforge3/etc/profile.d/conda.sh
conda activate hrm

python conversion/convert_to_hf.py \
  --ckpt_path checkpoints/ferrum_status_map_xxs/ferrum-status-map-xxs-ctx16k-10epoch-20260722-084712 \
  --ckpt_epoch 10 \
  --ckpt_use_ema false \
  --out_dir exports/ferrum/status-map-xxs-ctx16k-epoch10-hf-fixed \
  --tokenizer_path /work/dfm/festschrift/ferrum/target/termcomp-proof-corpus/training/tokenizers/ferrum-status-map-bpe
```

Full test evaluation command:

```bash
CUDA_VISIBLE_DEVICES=2 python scripts/eval_ferrum_hf.py \
  --model exports/ferrum/status-map-xxs-ctx16k-epoch10-hf-fixed \
  --input /work/dfm/festschrift/ferrum/target/termcomp-proof-corpus/training/hrm-status-map/ferrum.status-map.direct.test.jsonl.gz \
  --output target/ferrum-evals/status-map-xxs-test-epoch_10-fixed.json \
  --batch-size 64 \
  --device cuda \
  --dtype bfloat16
```

Full test result:

| quantity | value |
|---|---:|
| rows seen | 1,372 |
| rows kept | 1,301 |
| skipped too long | 71 |
| token accuracy | 0.96843 |
| exact status-map accuracy | 0.41430 |
| loss | 0.08919 |

Section-level status-map metrics:

| section | exact | precision | recall | F1 | gold | predicted |
|---|---:|---:|---:|---:|---:|---:|
| `solved` | 0.86626 | 0.26460 | 0.55325 | 0.35798 | 385 | 805 |
| `transformed_strong` | 0.99616 | n/a | 0.00000 | n/a | 5 | 0 |
| `transformed_weak` | 0.91007 | 0.93610 | 0.89203 | 0.91353 | 1,593 | 1,518 |
| `failed` | 0.53190 | 0.81845 | 0.73240 | 0.77304 | 7,657 | 6,852 |
| `timeout` | 0.87010 | 0.60990 | 0.74709 | 0.67156 | 858 | 1,051 |

The model should currently be used as a proposal source, not as a decision
procedure. In particular, the `solved` section has useful recall but low
precision, so Ferrum must still verify every proposed atom using the normal
sound processors and CPF/CeTA proof pipeline.

Important canonicalization note for the next training run:

- Top-level event rows use canonicalized CPF input: `standardize_trs` followed
  by CPF3 `<trsInput>` emission.
- Dependency-pair event rows currently use CPF3 `<dpInput>` emission for the
  current TRS and DP component without real symbol/variable standardization.
  This means the current status-map model was trained on raw serialized DP
  component names, not canonical `f0`, `f1`, `x0`, ... names.
- Runtime integration for this model should therefore preserve that behavior:
  canonicalize top-level TRS inputs, but leave DP inputs in the same raw
  serialized form.
- The next dataset/model should canonicalize the combined DP problem: TRS rules
  and active dependency pairs must be standardized together, then emitted as
  CPF3 `<dpInput>`. That will make DP guidance robust to symbol names and
  consistent with the top-level training convention.

Top-k proposal smoke command:

```bash
CUDA_VISIBLE_DEVICES=2 python scripts/generate_ferrum_status_map_proposals.py \
  --model exports/ferrum/status-map-xxs-ctx16k-epoch10-hf-fixed \
  --input /work/dfm/festschrift/ferrum/target/termcomp-proof-corpus/training/hrm-status-map/ferrum.status-map.direct.test.jsonl.gz \
  --output target/ferrum-evals/status-map-xxs-topk-smoke.jsonl \
  --max-rows 8 \
  --num-proposals 4 \
  --max-new-tokens 256 \
  --temperature 0.7 \
  --top-k 40 \
  --top-p 0.95 \
  --device cuda \
  --dtype bfloat16
```

## Runtime Integration

Ferrum now treats a supplied local model as an optional status-map processor
proposer:

- `--llm-model-dir <hf-export>` starts the configured local backend as before.
- `--llm-backend transformers-cpu` starts
  `scripts/transformers_cpu_openai_server.py`, a CPU-only OpenAI-compatible
  wrapper around a local Hugging Face causal-LM export. The launcher forces
  `CUDA_VISIBLE_DEVICES=""` for that subprocess.
- The status-map model is queried through the OpenAI-compatible completions API,
  not chat JSON. The prompt is the HRM direct format:
  `[BOS]<input>\nCPF\n</input>[SEP]`.
- Top-level TRS input is canonicalized before inference using the same
  `standardize_trs` plus CPF3 `<trsInput>` path used by the current top-level
  event dataset.
- DP input is currently kept as raw CPF3 `<dpInput>`, matching the current
  status-map training data. See the canonicalization note above for the next
  dataset.
- Ferrum parses `solved`, `transformed_strong`, and `transformed_weak` sections
  as candidate strategy atoms, deduplicates them, keeps the first eight valid
  atoms, wraps each in a small timeout, and runs them in parallel.
- If a guided branch proves the current problem/component, it cancels sibling
  branches through the existing parallel-strategy cancellation mechanism.
- If no guided branch proves the problem/component, Ferrum falls back to the
  configured strategy unchanged.
- Model output is never trusted as proof. Predicted atoms are only scheduling
  hints; the normal Ferrum processors construct the proof, and CPF/CeTA
  certification remains the correctness boundary.

Operational note: while developing on the shared machine, Rust builds/tests and
the first runtime smoke were run CPU-only with `CARGO_BUILD_JOBS=128` and
CPU-thread environment variables capped at 128. The runtime smoke used:

```bash
CUDA_VISIBLE_DEVICES="" \
OMP_NUM_THREADS=128 OPENBLAS_NUM_THREADS=128 MKL_NUM_THREADS=128 \
NUMEXPR_NUM_THREADS=128 RAYON_NUM_THREADS=128 \
cargo +1.95.0 run -- prove examples/dp-simple.trs \
  --strategy 'timeout(30s, dp)' \
  --llm-model-dir /work/dfm/HRM-Text/exports/ferrum/status-map-xxs-ctx16k-epoch10-hf-fixed \
  --llm-backend transformers-cpu \
  --processor-events target/llm-guided-smoke/dp-simple.cpu-llm.events.jsonl
```

The smoke completed with `status: Terminating`.

Follow-up timeout smoke after restoring fallback and adding LLM-guidance
statistics:

```bash
CUDA_VISIBLE_DEVICES="" \
OMP_NUM_THREADS=128 OPENBLAS_NUM_THREADS=128 MKL_NUM_THREADS=128 \
NUMEXPR_NUM_THREADS=128 RAYON_NUM_THREADS=128 \
timeout 305s cargo +1.95.0 run -- tpdb prove ../TPDB-ARI/TRS_Standard \
  --limit 16 --sample random --seed 42 --jobs 8 --progress-every 4 \
  --timeout-multiplier 0.2 \
  --llm-model-dir /work/dfm/HRM-Text/exports/ferrum/status-map-xxs-ctx16k-epoch10-hf-fixed \
  --llm-backend transformers-cpu \
  --processor-events target/llm-guided-smoke/.../events.jsonl
```

Result: `16/16` examples completed in `173095 ms`; `6` proved, `10`
unknown. The event log contained `61` LLM-guidance rows (`16` top-level,
`45` dependency-pair), with `11` solved guidance branches and `50` failed
guidance branches. This confirmed that fallback remains active while guidance
use is measurable. Processor-event CPF inputs are now content-addressed by
default, so the former `--processor-events-no-input` switch no longer exists.

The timeout fix has two parts:

- External solver/tool subprocesses are started in their own Unix process group
  and the whole process group is terminated on deadline/cancellation. This
  prevents a solver wrapper shell from exiting while a child still keeps pipes
  open.
- DP narrowing/instantiation/forward-instantiation candidate generation now
  receives the active deadline and cancellation scope. In particular, residual
  dependency-graph scoring no longer calls the uncapped graph builder while
  ranking instantiation candidates.

Regression tests:

- `cargo +1.95.0 test parallel_returns_without_waiting --lib`
- `cargo +1.95.0 test nested_parallel_cancels_inner_and_outer_smt_siblings --lib`
- `cargo +1.95.0 test residual_dp_graph_score_observes_expired_deadline --lib`
- `cargo +1.95.0 check`

## Implementation Notes

- Instrument the processor boundary, not individual solver internals first.
- Emit events for every strategy branch, including branches cancelled by
  cooperative parallel strategy execution.
- Track branch history soundness/completeness so NO/FAIL labels remain correct.
- Store artefacts by problem and node id, not just by run id, so individual
  examples can be inspected.
- Keep raw event logs immutable. Build derived datasets as separate JSONL files.
- Use stable hashes for subproblem ids. Hash canonical CPF input plus mode and
  Q/DP context.
- Record both wall time and configured timeout, because timeouts are also
  training signals for scheduling.
- Treat guidance failures followed by fallback successes as high-value
  counterfactual training data. For the same canonical CPF input, the model's
  predicted positive atoms are hard negatives when they fail, while the fallback
  atoms on the successful proof path are positives. Timing and progress labels
  should weight these rows: fast closures are stronger positives; timeouts are
  scheduling negatives; weak transformations receive credit only when later
  backward propagation reaches a final YES/NO.

## Credited Status-Map Datasets

The status-map target format is already sectioned/ranked rather than a single
processor label:

```text
solved:
poly(max-constant=2,max-coefficient=2)

transformed_strong:
subterm

failed:
matrix(dim=2,max-constant=2,max-coefficient=1)
```

The XS/XXS model should predict this text directly. Numeric utility is not a
separate supervised target for the current SFT model; it is a deterministic
derived score used by the dataset builder to order atoms within each status
section and decide which atoms survive the `--max-per-status` cap. This keeps
the data compatible with HRM-Text's `direct` format and with Ferrum's current
runtime parser.

`scripts/build_credited_status_map_dataset.py` now computes per-candidate
utility in its SQLite manifest:

- `solved`: large positive reward.
- credited `transformed_*`: positive reward only when the run/problem has a
  later solved event, unless explicitly overridden.
- downgraded transforms, ordinary failures, and failed positive LLM guidance:
  negative reward.
- timeouts: strong negative reward.
- elapsed time: capped negative penalty.

This utility is also suitable as the offline approximation for later preference
training or GRPO, but GRPO should use a live verified reward when practical:
sample a proposed status map, run the proposed atoms under controlled timeouts,
and reward only verified solved/transformed progress while penalizing failed or
timed-out branches.

The original Ferrum processor-event log was rebuilt with proof-path credit and
utility ordering:

```bash
python scripts/build_credited_status_map_dataset.py \
  --input target/processor-event-runs/all.processor-events.jsonl \
  --out-prefix target/termcomp-proof-corpus/training/hrm-status-map-credited-utility/ferrum.status-map.credited-utility.direct \
  --sqlite target/termcomp-proof-corpus/training/hrm-status-map-credited-utility/status-map-credited-utility.sqlite \
  --summary target/termcomp-proof-corpus/training/hrm-status-map-credited-utility/ferrum.status-map.credited-utility.direct.summary.json \
  --progress-every 100000 \
  --keep-sqlite
```

Summary:

| quantity | value |
|---|---:|
| event rows | 1,148,735 |
| CPF input rows | 26,141 |
| candidates | 212,598 |
| solved candidates | 7,532 |
| transformed strong candidates | 31 |
| transformed weak candidates | 7,498 |
| failed candidates | 197,537 |
| credited transform observations | 8,469 |
| downgraded transform observations | 29,731 |

The current LLM-guided sharded collector calls the same builder after
collection finishes, so the generated LLM-guided dataset will use the same
credited utility ordering and will additionally include failed LLM-guidance
proposals as hard-negative candidates.

### Recall-balanced proposer dataset

The 2026-07-24 recall-balanced export is:

```text
target/termcomp-proof-corpus/training/hrm-status-map-recall-balanced-v4-20260724/
```

It is derived from the same canonical, current-subproblem SQLite manifest as
the preceding `current-balanced-v3` dataset. Only the training split is
weighted:

- rows containing a solved candidate have a minimum replication factor of 4;
- rows containing a credited weak transformation have a minimum factor of 6;
- rows containing a credited strong transformation have a minimum factor of
  16;
- rare-positive-atom balancing remains enabled with a maximum factor of 16;
- these factors are combined with `max`, not multiplication;
- positive training rows retain up to 16 positive atoms, but only the four
  highest-utility failed atoms and four highest-utility timeout atoms;
- negative-only rows are retained once and keep the normal 16-atom cap;
- validation and test are neither replicated nor negative-capped.

The meta/self-reference atoms `llm`, `llm-guidance`, and `termination` are
excluded from every split. They describe model invocation or a composite
fallback rather than a useful leaf proposal for model-guided search.

Export summary:

| quantity | value |
|---|---:|
| source training subproblems | 21,684 |
| effective training rows | 39,679 |
| positive source rows | 4,074 |
| positive effective rows | 22,069 |
| negative-only source/effective rows | 17,610 |
| solved effective rows | 17,289 |
| transformed-weak effective rows | 8,008 |
| transformed-strong effective rows | 272 |
| validation rows | 1,207 |
| test rows | 1,183 |

The intent is asymmetric: missing a useful processor should cost the SFT model
more training loss than proposing one additional candidate. The validation and
test distributions remain natural so precision/recall measurements are not
distorted by this weighting.

The corresponding XS model was trained from scratch for 10 epochs with the
same architecture and optimization settings as `current-balanced-v3`:

```text
/work/dfm/HRM-Text/checkpoints/ferrum_status_map_xs_recall_balanced_v4/
  ferrum-status-map-recall-balanced-v4-xs-ctx16k-10epoch-20260724/
```

The Hugging Face export is:

```text
/work/dfm/HRM-Text/exports/ferrum/
  xs-status-map-recall-balanced-v4-epoch10-hf/
```

Packing retained 38,666 of 39,679 weighted training rows, skipped 1,013 rows
over the 16k context limit, and found no unknown tokens. The run used all eight
GPUs, DDP, a 262,144-token global batch, no gradient accumulation, and W&B
project `Ferrum-HRM`. Final training/validation metrics were:

| metric | train | validation |
|---|---:|---:|
| token accuracy | 0.9899 | 0.9584 |
| exact-map accuracy | 0.7521 | 0.3469 |
| loss | 0.0273 | 0.1983 |

On the natural v4 test split, teacher-forced evaluation improved substantially
over the preceding v3 XS checkpoint evaluated on the identical rows:

| metric | previous v3 | recall-balanced v4 |
|---|---:|---:|
| exact-map accuracy | 0.2549 | 0.3645 |
| solved precision | 0.1193 | 0.2493 |
| solved recall | 0.4370 | 0.5182 |
| transformed-weak precision | 0.3785 | 0.5304 |
| transformed-weak recall | 0.1731 | 0.4729 |
| timeout precision | 0.6431 | 0.6778 |
| timeout recall | 0.8005 | 0.7931 |

However, greedy autoregressive generation on the same first 31 usable test
rows did not yet improve the operational proposer signal. Exact maps improved
from 9 to 16, but useful positive coverage stayed at 3 of 8 positive rows and
positive-atom recall changed from 0.35 to 0.25. This distinction is important:
teacher-forced status classification is better, while deployed greedy
candidate generation still needs work.

### Possible TODO: candidate-conditioned ranking

Replace free-form status-map generation with a scorer over the finite set of
strategy atoms that are valid for the current proof level. Encode the
canonical CPF state once, score each candidate together with its parameters,
and train from grouped positive, negative, timeout, progress, and elapsed-time
observations. This avoids spending model capacity on strategy syntax and makes
top-k selection, calibration, and timeout-aware scheduling explicit. It is a
promising next model architecture, but is intentionally deferred while the
top-1 utility lookup experiment measures the ceiling provided by the existing
data.

### Top-1 utility lookup experiment

`scripts/export_utility_guidance_lookup.py` exports the highest-utility
positive atom for each canonical state in the aggregated SQLite dataset.
Runtime manifests contain SHA-256 keys rather than CPF copies. Raw-state hash
aliases from the persistent canonicalization cache let current DP states use
the offline canonical records without invoking the expensive SMT
canonicalizer online.

Ferrum accepts the resulting manifest through
`--utility-guidance-manifest`. At both the TRS and DP levels it:

1. serializes the current proof state as CPF3;
2. applies the same inexpensive runtime standardization currently used for
   model guidance;
3. tries exactly the one highest-utility positive atom on a lookup hit;
4. retains the ordinary strategy as fallback on a miss or failed attempt.

The lookup is an oracle-style scheduling experiment, not an LLM result.
Processor events therefore identify it as `UtilityGuidance` with
`guidance_source=utility-lookup`.

On a fixed-seed 32-problem TRS Standard smoke with quarter-scale timeouts, the
ordinary strategy completed with 8 YES in 227 seconds. The lookup arm reached
at least 13 YES among 24 completed problems before an incorrectly chosen
360-second batch-wide guard stopped the last worker wave. Top-level lookup hit
13 of 32 states and successfully closed six; DP lookup hit 32 of 88 queried
components spanning 12 problems, and all 32 hit attempts closed their
component. Sixteen problems had at least one successful guided query.

The apparent timeout problem in this smoke was a measurement error:
`--timeout-multiplier 0.25` scales the outer `timeout(300s, ...)` to 75 seconds
per problem, not 15 seconds. Four waves on eight workers can therefore
legitimately take about 300 seconds plus scheduling and cleanup. The TermCOMP
harness was nevertheless strengthened to enforce its 305-second boundary on
the complete Ferrum process group, including solver children, and retain
partial stdout/stderr on timeout.

The subsequent full TRS Standard utility-oracle run used 128 outer workers,
three Rayon workers per Ferrum process, a cooperative 300-second strategy
deadline, and a 305-second external process-group boundary. Its final result
was 582 certified YES, 172 certified NO, 727 unknown, 47 external timeouts,
and no errors or certification failures. The oracle was queried 6,153 times:
1,760 lookups hit and 1,400 hit attempts solved their current subproblem.
Hits occurred in 768 distinct input proofs, and 667 inputs had at least one
successful oracle-selected attempt. These figures measure processor-selection
potential on states represented in the collected data; they do not measure
held-out prediction quality.

### Ranked-evidence utility lookup

The second manifest format, `ferrum.utility-guidance.v2`, exports every
observed canonical state rather than only states with a successful candidate.
Its candidate groups are:

| group | runtime meaning |
|---|---|
| `prefer` | repeatedly useful solved or strong-transform candidates, ordered by utility |
| `possible` | weak transformations that may become useful in a larger proof path |
| `avoid` | observed failures, with counts distinguishing weak from repeated evidence |
| `timeout` | candidates whose best observed result exhausted their budget |

Ferrum tries the best candidate from `prefer`, then `possible`. Negative-only
states are still lookup hits and carry their avoidance evidence into the
processor-event witness, but the ordinary complete strategy remains the
fallback. In particular, `avoid` means "deprioritize for this exact canonical
state"; it is not a proof-theoretic assertion that the processor cannot work.

The current export contains 24,074 canonical states and 23,895 raw-hash
aliases. Of the canonical states, 3,771 have preferred candidates, 1,334 have
weak-transform candidates, 17,975 carry avoid evidence, and 11,206 carry
timeout evidence. There are 19,550 negative-only states; categories overlap.

Processor-event inputs are now content-addressed within each Ferrum process.
The first event for a current CPF state includes both its CPF and SHA-256
`problem_key`; subsequent events include the key and omit the repeated CPF.
An oracle miss always forces the current CPF inline. The dataset builder
resolves these references and rejects a key whose inline CPF has a different
hash.

### Canonical exploitation, tightening, and exploration campaign

`scripts/run_canonical_processor_campaign.py` turns the accumulated canonical
state database into new active experiments:

1. Extract every canonical `<trsInput>` and `<dpInput>` from `problems`.
2. Exploit the highest-utility local positive candidates.
3. Tighten successful parameterized atoms to seek smaller certified proof
   classes: constants toward 0; coefficients, matrix dimensions, weights,
   max-polynomial alternatives, and rational denominators toward 1; and weak
   polynomial lower constants toward 0.
4. Explore valid leaf atoms observed at the same proof level but never tried
   on that state.
5. Run the exact atom against the stored current CPF, with an independent
   processor budget and external process-group deadline.
6. Persist `(raw state, atom, implementation digest, timeout)` trials in a
   resumable SQLite database and merge ordinary processor-event rows.
7. Independently certify a solving certificate or transformed proof fragment.
   For a certified fragment, extract every guarded residual CPF input, retain
   the parent edge and proof fragment, and immediately enqueue the new state.
8. Propagate state coverage backwards once every child of a certified
   transformation has a certified terminal proof.

The companion `ferrum probe-cpf` command parses both whole-TRS and DP CPF
inputs. DP probes preserve the stored pair set instead of regenerating all
dependency pairs from the TRS. Exploration is deterministic under `--seed`;
changing the timeout creates a distinct trial, while rerunning the same
campaign skips completed trials.

`campaign.sqlite` is now also the persistent state registry. Its `states`,
`state_origins`, `transitions`, and `terminal_proofs` tables retain raw and
canonical hashes, complete CPF inputs, typed strategy context, all root
origins, certified parent edges, checker artifacts, and implementation
digests. `oracle_evidence` presents positive and negative evidence under both
raw and canonical keys. Certified transformed probes recursively schedule
previously unseen residuals by default; `--no-recursive-frontier` records the
same evidence without follow-up probes. Local timeouts are retried at 2x and
4x, capped at 300 seconds, and certified parameterized successes schedule
tighter variants.

Each run writes `summary.json` with raw/canonical state counts, coverage by
problem kind, probe outcomes by processor, certified transformations and
terminal proofs, generated children, timeout escalations, tightening gains,
and the count of reported solved answers that failed certification. A
campaign may use at most 64 direct workers; `--max-probes` provides a
resumable round budget without turning it into a root-proof timeout.
The runner returns a nonzero status when that uncertified-YES count is not
zero, unless a diagnostic run explicitly uses `--allow-uncertified-yes`.

This closes the improvement loop. Newly solved/transformed/failed/timed-out
attempts are fed through `build_credited_status_map_dataset.py`, joined with
the original corpus, and then re-exported as a stronger oracle or SFT/ranking
dataset. Failed and timeout evidence affects ordering and avoidance; successful
proof-path credit still propagates backward through transformations.

The production schedule for repeatedly alternating full TPDB discovery,
canonical-state interrogation, rebuilding, and frozen evaluation is specified
in `docs/iterative-data-campaign.md`.

Each tightening trial records its successful `source_candidate`. Operational
caps such as `max-states`, `max-transitions`, and `max-words` are deliberately
not minimized: lowering those tests resource starvation, not a simpler proof
witness.

Canonical states also carry a four-bit accumulated validity mask:

| bit | branch context |
|---:|---|
| 1 | sound and complete |
| 2 | sound but incomplete |
| 4 | unsound but complete |
| 8 | neither known sound nor known complete |

Selective bounded DP transformations (narrowing, rewriting, instantiation,
and forward instantiation) now preserve `sound_so_far` but clear
`complete_so_far` after their first selected transform. Ferrum may therefore
use their residual branch to establish termination, while any later
nontermination result is retained as diagnostic evidence rather than lifted
to the original DP problem.

With `--dual-probe` (the default), a top-level state observed in context 2 gets
a diagnostic nontermination portfolio trial. A top-level or DP state observed
in context 4 gets a diagnostic termination trial. Every resulting event has
`campaign.diagnostic_only=true`, its source validity mask, and a
`diagnostic-no` or `diagnostic-yes` selection label. Thus a decisive result is
useful state-level/counterfactual evidence but is not silently promoted across
a branch direction that does not preserve it.

Stored `<dpInput>` states use a direct nontermination portfolio over their
actual pair set: DP loop, DP rewriting, then DP instantiation.
This deliberately bypasses the older top-level wrapper that regenerates pairs
from a TRS. CPF already represents these witnesses as
`dpNonterminationProof`. The heavier DP nonloop constructor is not included in
short campaign probes because some of its candidate collections are not yet
incrementally cancellable; the external guard remains a backstop, but the
cooperative portfolio does not knowingly enter that phase. There are currently no production processors
explicitly marked unsound-but-complete, so diagnostic YES is future-ready but
normally empty.

### State-first unified campaign, 2026-07-26

The production state-first campaign is frozen at
`target/data-campaign/state-first-unified-20260726-094011`. Both 20,000-probe
cycles stopped after exhausting their finite frontiers: Cycle 1 used 1,993
probes and covered 147 states; the final Cycle 2 operated only on the 76-state
uncovered frontier, used 1,009 probes, certified 275 transformations and 152
assembled proofs, and materialized 62 new children. The exported monotone
oracle contains 149,244 records. Its promotion gate admitted 653 certified
evidence rows, rejected 57 uncertified positive rows, and promoted zero
uncertified YES answers.

The frozen union has 486 unique positive proofs, each independently certified
twice with deterministic results. CSR oracle-only replay certified 3 of 108
roots. Oracle plus fallback certified 62 of 108, including all 54 roots using
a CSR-DP transformation. TRS Standard replay certified 624 YES and 165 NO
answers over 1,528 problems with zero certificate failures.

The complete metrics, fallback registry comparison, binary hashes, and exact
artifact paths are in
`target/data-campaign/state-first-unified-20260726-094011/FINAL_REPORT.md`.

## Initial Benchmark Plan

1. Add a processor-event logger behind a strategy/run option. Done:
   `--processor-events`.
2. Add timeout scaling for collection runs. Done: `--timeout-multiplier`.
3. Run small smoke sets for TRS Standard and TRS Innermost.
4. Validate that emitted event rows are valid JSONL.
5. Run full TPDB/TermCOMP slices with artefact retention.
6. Build the first ranking dataset from positive and negative events.
7. Train a candidate-ranker model before attempting witness generation from
   Ferrum-generated data.
