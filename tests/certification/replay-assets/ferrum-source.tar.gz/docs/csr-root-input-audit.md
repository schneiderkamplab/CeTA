# Independent CSR root input audit (2026-09-15)

Implementation checkpoints: Ferrum `90480a809bee85f7cbbb4b936faff5b85bc08b6f`,
CeTA-CSR main `3ddffbdb322fd091fb80c2adb681f17004cd3134`.

Scope: the 110 certified CSR roots in
`target/csr-standalone-boundary-20260914/root-guard-final-v5/details.json`.
This is **105 termination proofs and five nontermination proofs**, not 110
termination proofs.

`scripts/audit_csr_root_correspondence.py` independently parses the ARI
benchmark and the CPF root input. It compares rule multisets modulo per-rule
variable renaming, preserves function names and arities, checks replacement
maps on the rule signature, and checks the property and answer. It does not
reuse Ferrum's parser or state canonicalization. Nine mutation/parser tests
cover rules, maps, polarity, function names, marked symbols, and ARI defaults.

The v2 audit matched **110/110** and rechecked every CPF with production
`CeTA-CSR/ceta`. Artifacts:

- `target/standalone-gaps-20260915/csr-root-correspondence-v2.json`
- `target/standalone-gaps-20260915-correspondence-v2.log`

After the repairs, a fresh oracle-only replay with the final v13 Ferrum binary
again certified **110/110 (105 YES, five NO)** in 48 seconds. Independent input
comparison also passed **110/110**, and every fresh certificate passed two
additional production-checker calls:

- `target/standalone-gaps-20260915/csr-final-v13/details.json`
- `target/standalone-gaps-20260915/csr-root-correspondence-final-v13.json`
- `target/standalone-gaps-20260915/csr-final-v13/twice-rechecked.jsonl`

## Formal scope and unused declarations

CeTA's CSR root specification is `SN (sig_step (funas_trs R) (csstep mu R))`
for YES and its negation for NO. This signature qualification must not be
silently confused with an unrestricted-signature claim.

108 benchmark signatures have no unused declarations. Gutierrez_26/secret2
(YES) and secret4 (NO) also declare unused `first/2`. ARI assigns all positions
when a declaration omits its replacement map. The original CPF omits this
unused declaration.

For secret2, the proof consists only of CSR rule removals ending in empty R.
`CSR_Checker.check_csr_termination_proof_sound` establishes the stronger
`SN (csstep (mu_of mu) (set R))` for this core proof language. A copy with the
full declared map for `first/2` explicitly inserted also returned CERTIFIED:
`target/standalone-gaps-20260915/secret2-full-declared-map.cpf`.
Thus this proof route is not dependent on restricting away `first`.

For secret4, nontermination on the rule signature already witnesses
nontermination on the larger declared signature: adding an unused symbol
does not remove any step of that witness.

This audit checks root input correspondence and the relevant formal scope.
It does not replace Isabelle's soundness proofs or claim that a raw Ferrum
Solved result without checker acceptance is certified. Standalone residual
certification repairs are recorded separately in
[standalone-csr-dp-certification.md](standalone-csr-dp-certification.md).
