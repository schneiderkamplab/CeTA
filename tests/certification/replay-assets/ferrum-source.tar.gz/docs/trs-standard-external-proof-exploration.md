# TRS Standard External-Proof Exploration Ranking

Unresolved Ferrum examples ranked by AProVE and MU-TERM proof evidence.
Certified evidence is preferred; unsupported proof steps reduce priority.

## Ferrum reproduction outcome

The corrected extraction found 1,077 external proofs for 526 of the 747
previously unresolved TermCOMP 2025 TRS Standard examples. It produced 3,528
processor events and 2,676 exact proof states; canonicalization merged these
to 2,479 distinct keys, all present in the exploration database. Compact
AProVE `<ruleIndex>` references are expanded through their CPF lookup tables.

A 64-job, 5-second-per-atom campaign tried 3,720 proof-derived or tightened
atoms. It found 1,298 solved and 127 transformed attempts. One initial
polynomial DP witness exposed a missing residual Q-orientation constraint.
After the constraint was added, the focused rerun certified; the final
positive total is 1,425/1,425 CeTA-certified.

Only reproduced Ferrum results were promoted. Imported AProVE and MU-TERM
outcomes selected candidates but did not directly become positive oracle
evidence.

| Oracle generation | Mode | Inputs | New certified YES |
| --- | --- | ---: | ---: |
| R00 | oracle only | 747 | 4 |
| R00 | oracle then default fallback | 747 | 13 |
| R01 | oracle only, remaining roots | 734 | 2 |
| R01 | oracle then default fallback, remaining roots | 732 | 1 |
| R02 | oracle only, original unresolved set | 747 | 11 |

The retained union is 625 certified YES and 172 certified NO. The last R01
gain is `Transformed_CSR_04/Ex6_9_Luc02c_iGM.ari`; its proof uses successful
raw oracle hits for three subterm steps, two size-change steps, one 2D matrix
step, and the enclosing DP step.

| Rank | Benchmark | Ferrum | External evidence | Suggested Ferrum atoms |
| ---: | --- | --- | --- | --- |
| 1 | `TRS_Standard/Transformed_CSR_04/ExAppendixB_AEL03_iGM.ari` | unknown | AProVE25 (cert) CERTIFIED YES certified, AProVE25 YES | `dp` |
| 2 | `TRS_Standard/Various_04/14.ari` | timeout | AProVE25 (cert) CERTIFIED YES certified, MU-TERM 2025 YES, AProVE25 YES | `poly(max-constant=2,max-coefficient=2,symbols=24,arity=3)` |
| 3 | `TRS_Standard/Transformed_CSR_04/MYNAT_nokinds_noand_iGM.ari` | unknown | AProVE25 (cert) CERTIFIED YES certified, AProVE25 YES | `dp` |
| 4 | `TRS_Standard/Transformed_CSR_04/Ex4_DLMMU04_iGM.ari` | unknown | AProVE25 (cert) CERTIFIED YES certified, AProVE25 YES | `dp` |
| 5 | `TRS_Standard/AProVE_07/kabasci01.ari` | unknown | AProVE25 (cert) CERTIFIED YES certified, AProVE25 YES | `dp` |
| 6 | `TRS_Standard/Transformed_CSR_04/Ex1_GL02a_C.ari` | certified YES | AProVE25 (cert) CERTIFIED YES certified, MU-TERM 2025 YES, AProVE25 YES | `dp` |
| 7 | `TRS_Standard/Transformed_CSR_04/Ex4_7_56_Bor03_iGM.ari` | certified YES | AProVE25 (cert) CERTIFIED YES certified, AProVE25 YES | `dp` |
| 8 | `TRS_Standard/Transformed_CSR_04/OvConsOS_nokinds_noand_iGM.ari` | unknown | AProVE25 (cert) CERTIFIED YES certified, AProVE25 YES | `dp` |
| 9 | `TRS_Standard/Transformed_CSR_04/PEANO_complete_noand_iGM.ari` | unknown | AProVE25 (cert) CERTIFIED YES certified, MU-TERM 2025 YES, AProVE25 YES | `dp` |
| 10 | `TRS_Standard/Transformed_CSR_04/Ex1_2_AEL03_GM.ari` | unknown | AProVE25 (cert) CERTIFIED YES certified, AProVE25 YES | `dp` |
| 11 | `TRS_Standard/Transformed_CSR_04/Ex49_GM04_iGM.ari` | unknown | AProVE25 (cert) CERTIFIED YES certified, MU-TERM 2025 YES, AProVE25 YES | `dp` |
| 12 | `TRS_Standard/Transformed_CSR_04/ExAppendixB_AEL03_GM.ari` | unknown | AProVE25 (cert) CERTIFIED YES certified, AProVE25 YES | `dp` |
| 13 | `TRS_Standard/Transformed_CSR_04/Ex49_GM04_C.ari` | unknown | AProVE25 (cert) CERTIFIED YES certified, MU-TERM 2025 YES, AProVE25 YES | `dp` |
| 14 | `TRS_Standard/Transformed_CSR_04/Ex6_9_Luc02c_iGM.ari` | certified YES | AProVE25 (cert) CERTIFIED YES certified, MU-TERM 2025 YES, AProVE25 YES | `dp` |
| 15 | `TRS_Standard/Transformed_CSR_04/Ex1_GL02a_iGM.ari` | certified YES | AProVE25 (cert) CERTIFIED YES certified, MU-TERM 2025 YES, AProVE25 YES | `dp` |
| 16 | `TRS_Standard/Transformed_CSR_04/Ex4_7_15_Bor03_iGM.ari` | certified YES | AProVE25 (cert) CERTIFIED YES certified, MU-TERM 2025 YES, AProVE25 YES | `dp` |
| 17 | `TRS_Standard/Transformed_CSR_04/Ex5_DLMMU04_iGM.ari` | certified YES | AProVE25 (cert) CERTIFIED YES certified, MU-TERM 2025 YES, AProVE25 YES | `poly(max-constant=2,max-coefficient=2,symbols=14,arity=2)` |
| 18 | `TRS_Standard/Transformed_CSR_04/LengthOfFiniteLists_nokinds_iGM.ari` | unknown | AProVE25 (cert) CERTIFIED YES certified, AProVE25 YES | `poly(max-constant=2,max-coefficient=2,symbols=14,arity=2)` |
| 19 | `TRS_Standard/Transformed_CSR_04/LengthOfFiniteLists_nokinds_noand_iGM.ari` | unknown | AProVE25 (cert) CERTIFIED YES certified, AProVE25 YES | `poly(max-constant=2,max-coefficient=2,symbols=21,arity=3)` |
| 20 | `TRS_Standard/Transformed_CSR_04/PEANO_nokinds_noand_iGM.ari` | certified YES | AProVE25 (cert) CERTIFIED YES certified, MU-TERM 2025 YES, AProVE25 YES | `dp` |
| 21 | `TRS_Standard/Transformed_CSR_04/Ex1_2_AEL03_iGM.ari` | unknown | AProVE25 (cert) CERTIFIED YES certified, AProVE25 YES | `dp` |
| 22 | `TRS_Standard/Transformed_CSR_04/Ex9_BLR02_C.ari` | certified YES | AProVE25 (cert) CERTIFIED YES certified, MU-TERM 2025 YES, AProVE25 YES | `dp` |
| 23 | `TRS_Standard/AProVE_04/Liveness6.4.ari` | unknown | AProVE25 (cert) CERTIFIED YES certified, AProVE25 YES | `poly(max-constant=2,max-coefficient=2,symbols=7,arity=2)` |
| 24 | `TRS_Standard/Transformed_CSR_04/ExProp7_Luc06_iGM.ari` | certified YES | AProVE25 (cert) CERTIFIED YES certified, MU-TERM 2025 YES, AProVE25 YES | `dp` |
| 25 | `TRS_Standard/Transformed_CSR_04/ExSec11_1_Luc02a_iGM.ari` | certified YES | AProVE25 (cert) CERTIFIED YES certified, AProVE25 YES | `dp` |
| 26 | `TRS_Standard/CiME_04/log2.ari` | certified YES | AProVE25 (cert) CERTIFIED YES certified, MU-TERM 2025 YES, AProVE25 YES | `poly(max-constant=2,max-coefficient=2,symbols=12,arity=3)` |
| 27 | `TRS_Standard/Transformed_CSR_04/Ex2_Luc02a_C.ari` | certified YES | AProVE25 (cert) CERTIFIED YES certified, AProVE25 YES | `dp` |
| 28 | `TRS_Standard/Transformed_CSR_04/ExProp7_Luc06_C.ari` | certified YES | AProVE25 (cert) CERTIFIED YES certified, MU-TERM 2025 YES, AProVE25 YES | `dp` |
| 29 | `TRS_Standard/Transformed_CSR_04/ExSec11_1_Luc02a_C.ari` | certified YES | AProVE25 (cert) CERTIFIED YES certified, AProVE25 YES | `dp` |
| 30 | `TRS_Standard/AProVE_04/JFP_Ex31.ari` | certified YES | AProVE25 (cert) CERTIFIED YES certified, AProVE25 YES | `dp` |
| 31 | `TRS_Standard/Hydras/worm_wrong.ari` | unknown | AProVE25 (cert) CERTIFIED YES certified, AProVE25 YES | `dp` |
| 32 | `TRS_Standard/MNZ_10/0.ari` | certified YES | AProVE25 (cert) CERTIFIED YES certified, MU-TERM 2025 YES, AProVE25 YES | `dp` |
| 33 | `TRS_Standard/MNZ_10/1.ari` | certified YES | AProVE25 (cert) CERTIFIED YES certified, AProVE25 YES | `dp` |
| 34 | `TRS_Standard/MNZ_10/2.ari` | certified YES | AProVE25 (cert) CERTIFIED YES certified, AProVE25 YES | `dp` |
| 35 | `TRS_Standard/MNZ_10/3.ari` | certified YES | AProVE25 (cert) CERTIFIED YES certified, AProVE25 YES | `dp` |
| 36 | `TRS_Standard/MNZ_10/8.ari` | certified YES | AProVE25 (cert) CERTIFIED YES certified, AProVE25 YES | `dp` |
| 37 | `TRS_Standard/Transformed_CSR_04/Ex16_Luc06_C.ari` | certified YES | AProVE25 (cert) CERTIFIED YES certified, AProVE25 YES | `dp` |
| 38 | `TRS_Standard/Transformed_CSR_04/Ex1_GM99_C.ari` | unknown | AProVE25 (cert) CERTIFIED YES certified, AProVE25 YES | `dp` |
| 39 | `TRS_Standard/Transformed_CSR_04/Ex2_Luc02a_iGM.ari` | certified YES | AProVE25 (cert) CERTIFIED YES certified, AProVE25 YES | `dp` |
| 40 | `TRS_Standard/Transformed_CSR_04/Ex4_DLMMU04_GM.ari` | unknown | AProVE25 (cert) CERTIFIED YES certified, AProVE25 YES | `dp` |
| 41 | `TRS_Standard/Transformed_CSR_04/ExIntrod_GM99_GM.ari` | certified YES | AProVE25 (cert) CERTIFIED YES certified, AProVE25 YES | `dp` |
| 42 | `TRS_Standard/AProVE_07/wiehe11.ari` | certified YES | AProVE25 (cert) CERTIFIED YES certified, AProVE25 YES | `dp` |
| 43 | `TRS_Standard/CiME_04/big.ari` | certified YES | AProVE25 (cert) CERTIFIED YES certified, MU-TERM 2025 YES, AProVE25 YES | `dp` |
| 44 | `TRS_Standard/HirokawaMiddeldorp_04/t009.ari` | timeout | AProVE25 (cert) CERTIFIED YES certified, AProVE25 YES | `poly(max-constant=2,max-coefficient=2,symbols=20,arity=7)` |
| 45 | `TRS_Standard/Secret_07_TRS/5.ari` | unknown | AProVE25 (cert) CERTIFIED YES certified, AProVE25 YES | `dp` |
| 46 | `TRS_Standard/Transformed_CSR_04/Ex5_DLMMU04_C.ari` | certified YES | AProVE25 (cert) CERTIFIED YES certified, MU-TERM 2025 YES, AProVE25 YES | `poly(max-constant=2,max-coefficient=2,symbols=17,arity=2)` |
| 47 | `TRS_Standard/AProVE_07/wiehe05.ari` | certified YES | AProVE25 (cert) CERTIFIED YES certified, AProVE25 YES | `dp` |
| 48 | `TRS_Standard/Applicative_first_order_05/13.ari` | certified YES | AProVE25 (cert) CERTIFIED YES certified, AProVE25 YES | `uncurry` |
| 49 | `TRS_Standard/Transformed_CSR_04/Ex16_Luc06_iGM.ari` | certified YES | AProVE25 (cert) CERTIFIED YES certified, AProVE25 YES | `dp` |
| 50 | `TRS_Standard/Transformed_CSR_04/Ex9_BLR02_FR.ari` | certified YES | AProVE25 (cert) CERTIFIED YES certified, AProVE25 YES | `dp` |
| 51 | `TRS_Standard/Transformed_CSR_04/LISTUTILITIES_nosorts_FR.ari` | certified YES | AProVE25 (cert) CERTIFIED YES certified, MU-TERM 2025 YES, AProVE25 YES | `dp` |
| 52 | `TRS_Standard/Transformed_CSR_04/LengthOfFiniteLists_complete_noand_GM.ari` | certified YES | AProVE25 (cert) CERTIFIED YES certified, MU-TERM 2025 YES, AProVE25 YES | `dp` |
| 53 | `TRS_Standard/Transformed_CSR_04/MYNAT_complete_noand_GM.ari` | unknown | AProVE25 (cert) CERTIFIED YES certified, AProVE25 YES | `dp` |
| 54 | `TRS_Standard/Transformed_CSR_04/MYNAT_nokinds_noand_GM.ari` | certified YES | AProVE25 (cert) CERTIFIED YES certified, MU-TERM 2025 YES, AProVE25 YES | `dp` |
| 55 | `TRS_Standard/Transformed_CSR_04/OvConsOS_complete_noand_GM.ari` | certified YES | AProVE25 (cert) CERTIFIED YES certified, MU-TERM 2025 YES, AProVE25 YES | `dp` |
| 56 | `TRS_Standard/Transformed_CSR_04/OvConsOS_nokinds_noand_GM.ari` | certified YES | AProVE25 (cert) CERTIFIED YES certified, MU-TERM 2025 YES, AProVE25 YES | `dp` |
| 57 | `TRS_Standard/Transformed_CSR_04/PEANO_complete_noand_GM.ari` | certified YES | AProVE25 (cert) CERTIFIED YES certified, MU-TERM 2025 YES, AProVE25 YES | `dp` |
| 58 | `TRS_Standard/Zantema_05/z26.ari` | certified YES | AProVE25 (cert) CERTIFIED YES certified, AProVE25 YES | `dp` |
| 59 | `TRS_Standard/AProVE_07/kabasci02.ari` | certified YES | AProVE25 (cert) CERTIFIED YES certified, AProVE25 YES | `dp` |
| 60 | `TRS_Standard/AProVE_07/wiehe12.ari` | certified YES | AProVE25 (cert) CERTIFIED YES certified, AProVE25 YES | `dp` |
| 61 | `TRS_Standard/CiME_04/filliatre3.ari` | certified YES | AProVE25 (cert) CERTIFIED YES certified, MU-TERM 2025 YES, AProVE25 YES | `dp` |
| 62 | `TRS_Standard/CiME_04/tree.ari` | certified YES | AProVE25 (cert) CERTIFIED YES certified, MU-TERM 2025 YES, AProVE25 YES | `dp` |
| 63 | `TRS_Standard/Secret_05_TRS/cime5.ari` | certified YES | AProVE25 (cert) CERTIFIED YES certified, MU-TERM 2025 YES, AProVE25 YES | `dp` |
| 64 | `TRS_Standard/Transformed_CSR_04/Ex4_7_56_Bor03_GM.ari` | certified YES | AProVE25 (cert) CERTIFIED YES certified, AProVE25 YES | `dp` |
| 65 | `TRS_Standard/Various_04/13.ari` | certified YES | AProVE25 (cert) CERTIFIED YES certified, MU-TERM 2025 YES, AProVE25 YES | `dp` |
| 66 | `TRS_Standard/Zantema_05/z07.ari` | certified YES | AProVE25 (cert) CERTIFIED YES certified, AProVE25 YES | `uncurry` |
| 67 | `TRS_Standard/AProVE_04/IJCAR_12.ari` | certified YES | AProVE25 (cert) CERTIFIED YES certified, MU-TERM 2025 YES, AProVE25 YES | `dp` |
| 68 | `TRS_Standard/AProVE_04/IJCAR_18.ari` | certified YES | AProVE25 (cert) CERTIFIED YES certified, MU-TERM 2025 YES, AProVE25 YES | `dp` |
| 69 | `TRS_Standard/AProVE_07/kabasci03.ari` | certified YES | AProVE25 (cert) CERTIFIED YES certified, AProVE25 YES | `dp` |
| 70 | `TRS_Standard/AProVE_07/wiehe01.ari` | certified YES | AProVE25 (cert) CERTIFIED YES certified, AProVE25 YES | `dp` |
| 71 | `TRS_Standard/AProVE_08/thiemann40_modified.ari` | certified YES | AProVE25 (cert) CERTIFIED YES certified, MU-TERM 2025 YES, AProVE25 YES | `dp` |
| 72 | `TRS_Standard/CiME_04/ternary-hard.ari` | certified YES | AProVE25 (cert) CERTIFIED YES certified, MU-TERM 2025 YES, AProVE25 YES | `dp` |
| 73 | `TRS_Standard/CiME_04/ternary.ari` | certified YES | AProVE25 (cert) CERTIFIED YES certified, MU-TERM 2025 YES, AProVE25 YES | `dp` |
| 74 | `TRS_Standard/Der95/13.ari` | certified YES | AProVE25 (cert) CERTIFIED YES certified, MU-TERM 2025 YES, AProVE25 YES | `dp` |
| 75 | `TRS_Standard/Secret_06_TRS/gen-18.ari` | certified YES | AProVE25 (cert) CERTIFIED YES certified, AProVE25 YES | `dp` |
| 76 | `TRS_Standard/Secret_06_TRS/gen-25.ari` | certified YES | AProVE25 (cert) CERTIFIED YES certified, AProVE25 YES | `dp` |
| 77 | `TRS_Standard/Transformed_CSR_04/Ex15_Luc98_FR.ari` | certified YES | AProVE25 (cert) CERTIFIED YES certified, MU-TERM 2025 YES, AProVE25 YES | `dp` |
| 78 | `TRS_Standard/Transformed_CSR_04/Ex1_Luc02b_FR.ari` | certified YES | AProVE25 (cert) CERTIFIED YES certified, MU-TERM 2025 YES, AProVE25 YES | `dp` |
| 79 | `TRS_Standard/Transformed_CSR_04/Ex2_Luc02a_GM.ari` | certified YES | AProVE25 (cert) CERTIFIED YES certified, AProVE25 YES | `dp` |
| 80 | `TRS_Standard/Transformed_CSR_04/Ex7_BLR02_FR.ari` | certified YES | AProVE25 (cert) CERTIFIED YES certified, MU-TERM 2025 YES, AProVE25 YES | `dp` |
| 81 | `TRS_Standard/Transformed_CSR_04/ExSec11_1_Luc02a_GM.ari` | certified YES | AProVE25 (cert) CERTIFIED YES certified, AProVE25 YES | `dp` |
| 82 | `TRS_Standard/Transformed_CSR_04/LISTUTILITIES_nosorts-noand_FR.ari` | certified YES | AProVE25 (cert) CERTIFIED YES certified, MU-TERM 2025 YES, AProVE25 YES | `dp` |
| 83 | `TRS_Standard/Transformed_CSR_04/LengthOfFiniteLists_complete_GM.ari` | certified YES | AProVE25 (cert) CERTIFIED YES certified, MU-TERM 2025 YES, AProVE25 YES | `dp` |
| 84 | `TRS_Standard/Waldmann_06/jwttt.ari` | certified YES | AProVE25 (cert) CERTIFIED YES certified, MU-TERM 2025 YES, AProVE25 YES | `dp` |
| 85 | `TRS_Standard/Zantema_05/z05.ari` | certified YES | AProVE25 (cert) CERTIFIED YES certified, AProVE25 YES | `poly(max-constant=2,max-coefficient=2,symbols=7,arity=2)` |
| 86 | `TRS_Standard/AG01/#3.40.ari` | certified YES | AProVE25 (cert) CERTIFIED YES certified, AProVE25 YES | `dp` |
| 87 | `TRS_Standard/AProVE_04/IJCAR_26.ari` | certified YES | AProVE25 (cert) CERTIFIED YES certified, MU-TERM 2025 YES, AProVE25 YES | `dp` |
| 88 | `TRS_Standard/AProVE_04/IJCAR_26a.ari` | certified YES | AProVE25 (cert) CERTIFIED YES certified, MU-TERM 2025 YES, AProVE25 YES | `dp` |
| 89 | `TRS_Standard/AProVE_06/tower_sizeChange.ari` | certified YES | AProVE25 (cert) CERTIFIED YES certified, AProVE25 YES | `switch-innermost` |
| 90 | `TRS_Standard/AProVE_07/kabasci04.ari` | certified YES | AProVE25 (cert) CERTIFIED YES certified, MU-TERM 2025 YES, AProVE25 YES | `dp` |
| 91 | `TRS_Standard/AProVE_07/thiemann09.ari` | certified YES | AProVE25 (cert) CERTIFIED YES certified, AProVE25 YES | `dp` |
| 92 | `TRS_Standard/AProVE_07/wiehe02.ari` | certified YES | AProVE25 (cert) CERTIFIED YES certified, AProVE25 YES | `dp` |
| 93 | `TRS_Standard/AProVE_07/wiehe03.ari` | certified YES | AProVE25 (cert) CERTIFIED YES certified, AProVE25 YES | `dp` |
| 94 | `TRS_Standard/AProVE_08/id_inc.ari` | certified YES | AProVE25 (cert) CERTIFIED YES certified, MU-TERM 2025 YES, AProVE25 YES | `dp` |
| 95 | `TRS_Standard/Applicative_first_order_05/#3.40.ari` | certified YES | AProVE25 (cert) CERTIFIED YES certified, AProVE25 YES | `uncurry` |
| 96 | `TRS_Standard/CiME_04/list-sum-prod-bin-assoc-distr-app.ari` | certified YES | AProVE25 (cert) CERTIFIED YES certified, MU-TERM 2025 YES, AProVE25 YES | `dp` |
| 97 | `TRS_Standard/HirokawaMiddeldorp_04/t001.ari` | certified YES | AProVE25 (cert) CERTIFIED YES certified, MU-TERM 2025 YES, AProVE25 YES | `dp` |
| 98 | `TRS_Standard/Transformed_CSR_04/Ex4_7_37_Bor03_FR.ari` | certified YES | AProVE25 (cert) CERTIFIED YES certified, MU-TERM 2025 YES, AProVE25 YES | `dp` |
| 99 | `TRS_Standard/Transformed_CSR_04/PALINDROME_complete_C.ari` | unknown | AProVE25 (cert) CERTIFIED YES certified, AProVE25 YES | `path-order` |
| 100 | `TRS_Standard/Applicative_05/Ex6Recursor.ari` | certified YES | AProVE25 (cert) CERTIFIED YES certified | `uncurry; switch-innermost; dp` |
