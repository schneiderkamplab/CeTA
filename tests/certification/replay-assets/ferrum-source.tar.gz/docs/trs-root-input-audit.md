# Standard and Innermost root-input audit

On 2026-09-15 an independent audit matched all **1,649 retained root
certificates** to their actual benchmarks and checked them again with
production CeTA-CSR:

| Category | Certified YES | Certified NO | Matched and checked |
| --- | ---: | ---: | ---: |
| TRS Standard | 1,039 | 299 | 1,338/1,338 |
| TRS Innermost | 301 | 10 | 311/311 |

This audits the previously certified root set, not every unresolved TPDB
example or newly discovered proofs. Combined with the separately completed
[110-root CSR audit](csr-root-input-audit.md), all 1,759 retained root inputs
have now been independently checked for correspondence.

## What is checked

`scripts/audit_trs_root_correspondence.py` parses ARI and CPF independently of
Ferrum's parser and canonicalizer. It checks exact rule multisets, symbol
arities, strategy, termination property, and YES/NO polarity. It permits only
per-rule variable renaming and quoted-identifier spelling aliases, never
arbitrary function renaming. Relative rules, altered Q contexts, marked input
symbols, duplicate root contexts, and changed strategy/polarity are rejected.
Spelling normalization is required to be injective: a CPF cannot split one
benchmark symbol into both `f` and `|f|`. The CSR audit was also tightened to
require consistent spellings between rules and their replacement-map entries.
The strengthened audits still pass all 1,649 TRS roots and all 110 CSR roots;
no retained proof was found to exploit the previous audit's missing check.

TPDB's Standard and Innermost files both declare `(format TRS)`; the category
directory supplies the intended strategy. The audit verifies that this
directory agrees with the recorded category. Standard CPFs have no strategy
restriction. Innermost CPFs have exactly `<innermost><nfs>true</nfs></innermost>`.
An omitted nfs flag is not silently accepted as true: CeTA's default is false.

Every benchmark/CPF is hashed before checking and required to remain unchanged
afterward. The production checker hash must also remain unchanged over the
whole audit. Expected category totals are explicit command-line arguments,
and duplicate benchmark paths are rejected. Nine focused Python tests include
mutations of rules, variable sharing, function names, strategy, nfs, property,
polarity, and extra contexts.

## Meaning of the checked proposition

CeTA's `Ceta_Problem_Spec.desired_property` for an `Inn_TRS_input Q R S`
termination decision is `b ↔ SN_qrel (nfs, Q, R, S)`. Here S is empty.
For Standard roots Q is empty, so this is exactly strong normalization of
ordinary rewriting by the benchmark R (or its negation for NO).
For Innermost roots Q is the set of left-hand sides of R, giving innermost
rewriting (`Q_Restricted_Rewriting.irstep_def`).

All 311 Innermost benchmarks have non-variable left-hand sides and no extra
right-hand-side variables. Consequently every rule-variable instance is a
proper subterm of the redex and must already be normal for an innermost step;
the explicit nfs=true adds no restriction in these inputs. The audit checks
these syntactic conditions rather than assuming this for arbitrary TRSs.
All 1,649 benchmarks also have no unused function declarations. Neither
Standard nor Innermost root correctness relies on substituting a transformed
system for the original input.

## Reproduction and artifacts

Input root set: `target/standalone-gaps-20260915/root-guard-v11/details.json`.
Final report:
`target/probe-summary-root-audit-20260915/trs-root-correspondence-injective.json`.
CSR revalidation with the same injectivity safeguard is in
`target/probe-summary-root-audit-20260915/csr-root-correspondence-injective.json`.

```sh
python3 scripts/audit_trs_root_correspondence.py \
  --details target/standalone-gaps-20260915/root-guard-v11/details.json \
  --output /path/to/new-report.json \
  --ceta /work/dfm/festschrift/CeTA-CSR/ceta \
  --expected-standard 1338 --expected-innermost 311 --jobs 16
```

CeTA-CSR is unchanged at `3ddffbdb322fd091fb80c2adb681f17004cd3134` on
`main`; production SHA256:
`2ebcb81adf0a62ceb539f5046c46da1d20d2a3fea013ad5cca34d778db85e96a`.
No Isabelle rebuild, oracle update, or processor change was needed.
Audit implementation: Ferrum `0b9eae5bacb507e352e51a3e25fbcb00fc5ba663`.
