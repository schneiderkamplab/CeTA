# Verified State of the Art

This page is the authoritative local ledger for campaign high-water marks.
Do not infer a baseline from chat history, an intermediate replay, an oracle
version number, or a raw Ferrum YES/NO count. A result belongs here only when
the complete category replay and its CeTA certification artifacts exist.

## 2026-10-17 ordered competitor recovery: Standard incremental union 1,340

Campaign priority (updated user instruction): TRS Standard AProVE misses,
other TRS Standard competitor misses, **SRS Standard competitor misses**,
TRS Innermost certified misses, then TRS Innermost raw misses. The SRS queue
currently contains 23 of the original 41 competitor misses; it is next after
the active Standard campaign, not after Innermost.

Second gain: `EEG_IJCAR_12/emmes-nonloop-ex3_4.ari`, certified NO in 1.81s
using native `nontermination(dp-nonloop)` synthesis. Strict witness-free replay,
two production CeTA checks, and original-input audit pass in
`target/competitor-recovery-20261017/pattern-replay-v14/`.
This raises the incremental Standard union to **1,340 (1,039 YES, 301 NO)**;
the complete category replay remains 1,338. Ferrum source commit: `8540786`.
Latest monotone oracle: `target/srs-native-20261013/integrated-pattern-v633/oracle.jsonl`,
SHA-256 `e117d7522ddf9f1c1a47446dd3027f2809bbfe0445483b6cd7200b2c061e0301`.
Audit: 573,619 states, 1,653,395 actions, zero forbidden actions.
CeTA is unchanged. The original 94-root competitor worklist now has 92 misses.

### First gain: projection-seeded symbolic loop

Follow-up search engineering: pattern-nonloop queue priorities are cached at
insertion rather than recomputed across the whole queue on each extraction.
The old priority and front/back tie order are preserved and regression-tested.
Optional `FERRUM_TRACE_PATTERN_SEARCH=1` reports helper construction and state
expansion timings. The speculative fairness change was measured and discarded.
All **1,235 library tests pass** in `full-tests-queue-v19.log`; the newly recovered
pattern root still passes strict replay and twice certification in
`pattern-queue-replay-v19/` (both under `target/competitor-recovery-20261017/`).
No additional roots are claimed from this queue change; four neighboring
guarded-arithmetic cases remain unresolved after the measured 60-second probes.

`TRS_Standard/Strategy_removed_AG01/#4.19.ari` is a new certified NO,
synthesized without a retained witness. A bounded search derives projection
symbols from live linear collapsing rules, seeds fresh symbolic arguments,
and searches one marked DP step followed by ordinary rewrites. The resulting
loop is independently replayed against the actual rules. No production
benchmark-name or symbol-name dispatch was added.

Native runtime: 0.762 seconds. Strict witness-free oracle-only replay, two
production CeTA checks, and the original-input audit all pass in
`target/competitor-recovery-20261017/projection-replay-v9/`.
The Standard incremental union is **1,339 (1,039 YES, 300 NO)**; the latest
complete Standard replay remains 1,338 below. SRS stays at the incremental
1,716, Innermost at 311, and CSR at 110. This is not a new full-category replay.

Binary: `target/competitor-recovery-20261017/ferrum-projection-v8`.
Monotone oracle: `target/srs-native-20261013/integrated-projection-v632/oracle.jsonl`.
SHA-256: `298968d9825f1dee960d5c3cb06d761df02687d8dfbd84b7ea7bc28e1818d23a`.
Audit: 573,619 states, 1,653,383 actions, zero forbidden actions.
CeTA is unchanged: production commit `17dbee4b822733cd25235a64178db2ccf590a10e`.

Verification: all **1,234 library tests pass** (zero failures/ignored), including
renaming, invalid-step rejection, and deadline regressions. Twelve protected
Standard/Innermost/CSR roots and all eleven recent SRS gains replay successfully
with the new binary and oracle; every retained guard proof passes CeTA twice.
Logs: `target/competitor-recovery-20261017/full-tests-projection-v10.log`,
`protected-v11/`, and `srs-guard-v12/` under that campaign directory.

The ordered competitor worklist is in
`target/competitor-recovery-20261017/standard-worklist.json`: 21 AProVE raw
misses, followed by 73 other-competitor misses (now 72 after this gain).
The complete 21-root default probe and three conditional-order waves produced
no gains. Retained proof inventory identifies algorithm/data-structure
induction and negative-slope max interpretations as concrete further targets;
these are not claims that more runtime alone will close the roots.
Cached 2025 Innermost comparison covers all 297 AProVE raw, all 268
AProVE-certified, and all 200 MuTerm successes. Do not conflate this with a
fresh 2026 comparison. The recorded 2026 proof-download URLs returned 404;
cached 2025 artifacts were used for proof analysis, with origins retained.

## 2026-10-13 SRS Standard witness-free campaign baseline

### 2026-10-17 fresh-path RFC completion: incremental SRS union 1,716

Eleven additional roots pass strict witness-free oracle-only replay, twice
production CeTA certification, and original-input audits in
`target/srs-native-20261013/replay-fresh-v631/`. The incremental local union is
**1,716/1,931 (1,437 YES, 279 NO)**; **23 of the original 41 competitor misses
remain**. This is not a new complete category replay; the complete totals below
remain authoritative for that measurement.

The general RFC completion route starts with separate RHS paths before merging
variable tails. It synthesizes automata from live rules, uses the recorded
layered budget capped at three seconds, and retains the existing independent
closure, right-extension, compatibility, and no-top-redex checks. There is no
experimental environment flag or supplied automaton witness in replay.

Binary: `target/srs-native-20261013/ferrum-fresh-v631`.
Oracle: `target/srs-native-20261013/integrated-fresh-v631/oracle.jsonl`, SHA-256
`dd7c0863dfd642878bab91d9d941f587ac6c69ec4189526a339dc3a5d0742f70`;
573,615 states, 1,653,370 actions, zero forbidden actions.
CeTA is unchanged from the production commit and binary documented below.
The focused renaming, looping-system rejection, and resource-limit test passes.
Full library verification: **1,233 passed, zero failed/ignored/filtered**, in
80.07 seconds, recorded in `full-tests-fresh-v631.log` under the same campaign
directory. All builds and tests used the `ferrum` conda environment.

### 2026-10-17 certified rule strengthening: incremental SRS union 1,705

Three additional Wenzel roots now pass native synthesis, strict witness-free
oracle-only replay, two production CeTA checks, and original-input audits:

- `Wenzel_16/aabaaabaaba-aaabaabaabaaab.srs.ari`;
- `Wenzel_16/abaabababa-aabababababaab.srs.ari`;
- `Wenzel_16/baabaabbaab-aabbaabaabaabb.srs.ari`.

The incremental union is **1,705/1,931 local / 1,699/1,921 shared**:
**1,426 YES, 279 NO** locally. **34 of the original 41 competitor misses
remain**, including four competitor-certified misses. This is an incremental
union, not a new complete 1,705-root replay. The complete unified category
replay below remains 1,701 SRS / 1,338 Standard / 311 Innermost / 110 CSR.
The reconciled per-root inventory and trial histories are in
`frontier-report-v628.json`; its shared score is computed against the cached
1,921-root official input set, not inferred from a total-score offset.

The general `srs-strip-contexts` processor exposes a strengthened child state,
with optional numeric `max-prefix`/`max-suffix` limits. It does not supply an
order, labeling, automaton, or complete proof. Root stripping, optional reversal,
RFC synthesis, and the terminal child are independently guided actions.
Native runtimes in `strip-bounded-matchbox-v623` are 0.037–0.039 seconds;
the three-root global-oracle replay completed in four seconds.

Ferrum source: `ef952d9e2125aac3f0f4feaa00a50dc5b9d529dc`.
Immutable binary: `ferrum-strip-limits-v622`, SHA-256
`369ea9c4150fcade344ed05619698c33e3ec91497f6fe9631f595a1c0128e190`.
Latest monotone oracle: `integrated-strip-v625/oracle.jsonl`, SHA-256
`c9215894226d571dab3442c07bb2f1b3701a65d629927a2f11186f5504b0abf0`;
573,570 states, 1,653,164 actions, zero forbidden composite/witness actions.
Replay, double checks, and input audit: `replay-strip-v625/`.

**CeTA changed**, on `/work/dfm/festschrift/CeTA-CSR` branch `main`, commit
`17dbee4b822733cd25235a64178db2ccf590a10e`. The production binary at `ceta`
has SHA-256 `19a4a6f14eb1d07891d149f8c8b464228c0044fa7b3f874b77eadb974cba8f73`.
It verifies one-step simulation of every original rule by the stronger system;
Q and weak-rule contexts are conservatively rejected. The existing absolute-RFC
entry point is preserved. `Proof_Checker_Base`, `Proof_Checker`, `Code`, the
absolute-RFC extension, fresh Haskell export, and `make haskell` passed using
an isolated Isabelle home. All **3,461 previously retained certificates passed
this exact binary twice**, recorded in `checker-regression-v618/COMPLETE.json`.
The original and renamed strengthening proofs pass; five invalid mutations
are rejected (`strip-mutation-production-v624`). The previous production
binary is retained in CeTA's `target/srs-strengthening-20261017/`.

Final Ferrum verification, in the **`ferrum` conda environment**:
**1,232 passed, zero failed/ignored/filtered** (`full-tests-production-v624.log`);
30 Python exporter/merge tests passed. Twelve protected Standard/Innermost/CSR
oracle-only guards and double checks pass in `strip-final-guard-v627`.
The initial base-environment suite lacked cvc5; its failures were rerun, not
ignored. The earlier mount outage also interrupted a build; no output from
that failed build was promoted.

The faithful bounded Drop/reversal/RFC follow-up and bound-3–5 escalation left
eleven related bound-two cases unresolved (`strip-bounded-matchbox-v623`,
`strip-higher-bounds-v626`). Matching Drop counts alone is insufficient:
native automaton completion/closure remains a concrete next target. These
Unknown outcomes are not nontermination claims. All abbreviated artifacts
above are under `target/srs-native-20261013/` unless stated otherwise.

### 2026-10-17 completed unified replay: 1,701 SRS plus one gated gain

`target/srs-native-20261013/unified-final-v593/COMPLETE.json` records a fully
finished strict witness-free oracle-only replay with **zero retained losses**:

| Category | Certified YES | Certified NO | Total |
| --- | ---: | ---: | ---: |
| SRS Standard | 1,422 | 279 | 1,701 |
| TRS Standard | 1,039 | 299 | 1,338 |
| TRS Innermost | 301 | 10 | 311 |
| CSR | 105 | 5 | 110 |

Every one of the 3,460 emitted certificates passed production CeTA twice.
The SRS original-input correspondence audit passed **1,701/1,701**, with no
failure. SRS double-check receipts are in `srs/rechecks-complete.jsonl`;
the protected receipts are in `protected/rechecks.jsonl`. The SRS check was
deliberately resumed from 261 completed receipts with 32 workers, preserving
all completed evidence; the original runner's SIGTERM log is an orchestration
handoff, not a certificate rejection. `finish-unified-v597.log` records the
successful completion. For future large-CPF correspondence audits use the
existing `--processes` option to avoid thread-bound Python XML parsing.

Ferrum source: `afb4acbd86412fbac3d27d5cd005ea5b3391d622`; immutable binary
`ferrum-weak-zero-v587`, SHA-256
`4b5bc681ceb60873ad1319ba4593841bf065701572387309e54fb7ffc6e2f355`.
Frozen replay oracle: `integrated-weak-zero-chains-v591/oracle.jsonl`, SHA-256
`207329cbeea5aa692d1b22d89ae466d1a2fb4823ee14194964e5f1ddce0147ed`.
CeTA-CSR remains unchanged at `1872a8c87996086a87151ec7352843e3d8e4d142`,
binary SHA-256 `f23285d852d5bce3828f50c4fdf8e6f0f571258e0ddf4d165c9eb9c37b2635fc`.

The separately fully gated reversal gain below extends the incremental union
to **1,702/1,931 local / 1,696/1,921 shared** (1,423 YES, 279 NO), thirteen
above the prior unified SRS replay. The latest monotone oracle is v595 below;
do not describe it as a complete 1,702-root replay. All bounded discovery waves
have finished. `frontier-report-v598.json` records the **37 remaining original
competitor misses**, including five certified competitor wins, and their
individual trial histories. Four of the original 41 were recovered; the other
nine incremental gains were outside that set. The 37 negative search outcomes
are not nontermination claims or proofs of missing processor support.
All abbreviated artifact paths here are relative to `target/srs-native-20261013/`.

### 2026-10-17 smaller-DP broad gains and exact-zero polynomial synthesis

Seven further roots have passed strict witness-free oracle-only replay, two
production CeTA checks, and original-input correspondence: five in
`replay-trimmed-broad-v586`, one in `replay-trimmed-extra-v588`, and
`Secret_06_SRS/aprove04` in `replay-weak-zero-chains-v591`.
The incremental union is **1,701 local / 1,695 shared** (1,422 YES, 279 NO),
leaving **38 of the original 41 competitor misses**. This is not a new full
category replay; the complete unified baseline below remains authoritative.

The opt-in smaller-DP implementation is committed as `6aa3239`. The subsequent
weak-polynomial change keeps the old query first and adds a fallback encoding
of CeTA's zero-coefficient normalization, with lexically shared constant
expressions. It supplies no model or example-specific witness; independent
orientation validation is unchanged. `aprove04` native runtime is 0.408s,
strict replay approximately four seconds. The release suite in
`full-tests-weak-zero-v590.log` passed **1,225/1,225**, no ignored tests.
Candidate immutable binary: `ferrum-weak-zero-v587`.
The twelve protected category guards (four each Standard, Innermost, CSR)
also pass strict replay and double certification in `weak-zero-guard-v592`.

Latest monotone oracle: `integrated-weak-zero-chains-v591/oracle.jsonl`, SHA-256
`207329cbeea5aa692d1b22d89ae466d1a2fb4823ee14194964e5f1ddce0147ed`;
573,538 states, 1,653,055 actions, zero forbidden composite/witness actions.
Production CeTA-CSR is unchanged at commit
`1872a8c87996086a87151ec7352843e3d8e4d142`, binary SHA-256
`f23285d852d5bce3828f50c4fdf8e6f0f571258e0ddf4d165c9eb9c37b2635fc`.
Paths above are relative to `target/srs-native-20261013/`.

The fix is committed as `afb4acb`. A further native reversal/smaller-DP search
recovered `CirponsMitchellSmith_25/no_subst_baabbaabba_aabbba` in 56.296s.
`replay-reversed-first-v595` passes strict replay (33s), double certification,
and input correspondence. The incremental union is now **1,702 local /
1,696 shared** (1,423 YES, 279 NO), with **37 original competitor misses**.
Oracle `integrated-reversed-first-v595/oracle.jsonl` has SHA-256
`18e56323cf1aed8994377ee9da4f495fea976f59f664a1e9f4756361327158ba`.
The running unified `unified-final-v593` freezes the preceding 1,701-root
SRS union and all 1,759 protected category roots; the reversal gain is separate.
CeTA remains unchanged.

### 2026-10-17 verified smaller-DP recovery

The opt-in native `dp-trimmed` transformation recovered competitor-certified
`Waldmann_06_SRS/jw3`: native YES/CERTIFIED in 2.537 seconds, strict witness-free
oracle-only replay, double certification, and input correspondence all pass.
Artifacts: `trimmed-frontier-v574/006`, `replay-trimmed-first-v576`, and
`trimmed-mutation-v581b` (required-pair deletion correctly rejected).
The incremental total becomes **1,693 local / 1,687 shared**
(1,414 YES, 279 NO locally); **40 of the original 41 competitor misses remain**.
`integrated-trimmed-first-v576/oracle.jsonl` has SHA-256
`477d23291a9e5aa1fb47e26502afd453902b067cf51492a1ec7e62ad0ccbdc03`.

Candidate binary: `ferrum-trimmed-v573`. Full release library run
`full-tests-trimmed-production-v579.log`: **1,223 passed, zero failed/ignored**.
It explicitly selects production CeTA-CSR with `CETA_CSR_BIN`, 32 MiB test
thread stacks, and eight test threads. Earlier debug runs hit a deep-term
stack overflow, selected a stock checker for some extension tests, and had
timing-sensitive failures under unrestricted test concurrency; these were
rerun, not skipped. Twelve oracle-only category guards (four each CSR,
Innermost, Standard) and their double checks pass in
`trimmed-protected-guard-v584`. Existing `dp` and default strategies are
unchanged. CeTA source/binary are unchanged.

The same discovery wave also recovered
`CirponsMitchellSmith_25/no_subst_ababaabba_baababa`. Its strict gate
`replay-trimmed-second-v582` passes (about 80 seconds), including double
certification and input correspondence. The updated incremental union is
**1,694 local / 1,688 shared** (1,415 YES, 279 NO), leaving **39 of the
original 41 competitor misses**. Latest oracle:
`integrated-trimmed-second-v582/oracle.jsonl`, SHA-256
`dba7e7f21b39371a985302bf1f1dbb2ad0c79de9aef0603c7d5721bb795b6077`.
The original 82-task frontier and additional bounded trimmed-DP searches
remain active.
All artifact paths in this section are relative to `target/srs-native-20261013/`.

### 2026-10-17 unified replay and competitor-frontier continuation

`target/srs-native-20261013/unified-final-v566/` completed proving with
**1,689/1,931 SRS**, **1,338 Standard**, **311 Innermost**, and **110 CSR**,
zero retained-root losses. All 3,448 retained CPFs passed two production
CeTA checks. The additional SRS correspondence audit passed 1,686 roots;
three checker invocations exceeded its separate 120-second limit despite
matching original rules/strategies and passing the longer double checks.
The 600-second audit retry subsequently passed **1,689/1,689**, with zero
failures (`srs/audit-600s.log`, `srs/root-correspondence-600s.json`). The initial
audit failures were checker time limits, not rule/strategy mismatches.

Three subsequent native weighted-labeling discoveries passed strict
witness-free oracle-only replay, double certification, and original-input
correspondence in `replay-late-weighted-v568/`:
`CirponsMitchellSmith_25/no_subst_baaaababa_abbaaaa`,
`no_subst_baaaabbaaa_aabaa`, and `no_subst_baaabababa_abbaaaba`.
The incremental union is therefore **1,692 local / 1,686 shared**
(1,413 YES, 279 NO locally), not yet a new full-category replay.
Oracle: `integrated-late-weighted-v568/oracle.jsonl`, SHA-256
`8551d54a432a86d01195bf42217922061d5c1b8772b39b38c2fef847e1d75e94`.
Binary and Ferrum implementation commit remain the v544/32770ec versions
documented below; production CeTA is unchanged.

An exact per-root comparison against cached official 2026 evidence leaves
**41 competitor wins** outside Ferrum's unified certified root set: Matchbox
34 (2 certified), AProVE 21 (7 certified), with overlap. All are YES claims.
These are distinct from the three late gains above. The complete selection
and evidence origins are in `competitor-frontier-v567/frontier.json`.
The finite 82-task orders/labeling campaign, targeted certified-proof controls
v569/v570, and strict discovery integration v571 are running; their results
must not be counted before the replay/certification/correspondence gates.
Shared aggregate coverage now exceeds Matchbox raw 1,685 by one, but this
does not imply set inclusion or equal-budget competition performance.

### 2026-10-17 active continuation: thirty-one further gated roots

The continuation starts from the **1,658 local / 1,652 shared** incremental
union below. Thirty-one additional roots (twenty-five YES, six NO) have now passed
witness-free oracle-only/no-fallback replay, double production CeTA checks,
and independent original-input correspondence: **1,689 local / 1,683 shared**
(1,410 YES and 279 NO locally).
This is an incremental union, not a new frozen full-category baseline.

The current-turn root ledger is `target/srs-native-20261013/ledger-v391.json`;
its starting root set is `baseline-v387.json`. New evidence is retained in
`replay-threshold-first-three-v396`, `replay-arctic-ladder-three-v403`,
`replay-partial-arctic-gain-v409`, `replay-signed-random-gain-v411`,
`replay-natural-random-gain-v412`, `replay-signed-un13-gain-v417`,
`replay-signed-random539-v419`, `replay-normalized-odd-three-v424`, and
`replay-normalized-next-three-v426`, `replay-labeled-arctic-gain-v430`
(faster replay in `replay-projected-labeled-v431`), and
`replay-signed-wenzel-gain-v433`, `replay-zantema03-gain-v491`,
`replay-shift-wenzel-gain-v498`, `replay-zantema05-gain-v502`,
`replay-shift-second-gain-v507`, `replay-shifted-four-gains-v511`, and
`replay-sparse-wenzel-gain-v523`, `replay-weighted-cirpons-gain-v540`, and
`replay-weighted-second-gain-v545`, and `replay-late-arctic-gain-v563`.
The thirty-one-gain union, including protected-category repairs, is
`integrated-late-arctic-gain-v563/oracle.jsonl` (SHA-256
`e1a48f2babc946fce9e614b7e2320f35d8bbd1fc1c847655386959b76d7a2ac4`). All paths here are under
`target/srs-native-20261013/`.

The previous full v378 SRS replay finished at 1,657, missing retained root
`Wenzel_16/aabbababa-abababaabbaab.srs`. It recovers with an explicit threshold
encoding in 7.2 seconds; `replay-retained-threshold-v397` passes strict replay,
double certification, and correspondence. This is recovery, not an addition.
The final committed-binary protected replay `protected-committed-v386` has
finished at **1,759/1,759**, with no retained losses and double checks passed.
CSR remains 110, Innermost 311, Standard 1,338.

The later SRS discoveries and gates also use immutable candidate binaries;
they are not all measurements of the committed `ferrum-final-v385` binary.
The active RFC optimization changes only search/validation implementation:
positive reachability caching, immutable bit-set reachability for closure and
compatibility checks, and early rejection of an irreversible top-redex failure.
The source including native finite weighted-labeling passes
**1,220 library tests, zero failed or ignored** (`full-tests-weighted-v535.log`).
`srs-weighted-labeling(carrier-size=3,max-weight=4)` jointly synthesizes a finite
unary model and nonnegative labeled weights in one SMT query, independently
checks both, and uses the existing finite semantic-labeling CPF rule. Neither
the model nor the weights are supplied by the oracle. Its Cirpons gains are
`no_subst_aababbbbaa_baaba` and `no_subst_abbabbabba_bbaabba`.
The optional minimum-progress percentage also passes its focused tests and
the further full run in `full-tests-progress-v551.log`: 1,220 passed, zero
failed or ignored. Sixteen Python native-export tests pass. Candidate binary
`ferrum-label-progress-v544` has SHA-256
`f4a85223a9d12bc3dd393dfb3fd994d30ed66158d7c69778c11bea469f2b838c`.
The tested implementation is committed as Ferrum `32770ec` on
`codex/aaecc-20260831`.
The reached-layer RFC optimization retains **345/345** affected roots in
`rfc-reached-guard-v460`. The stable-encoding nineteen-gain replay passes
**19/19** in `replay-stable-gains-v449`, with double checks.
Arctic parameter sharing remains opt-in: the experimental always-on build
changed search models and lost a retained root, so it is not the default.
The alias loader now resolves recorded alias chains independent of file order;
this does not identify different DP states with each other.

A protected Standard replay exposed an alternative 40-rule MYNAT residual.
Its separate native proof is twice checked in `probe-protected-residual-v467`;
`integrated-protected-40-v470` adds its modular search hints. This is recovery,
not an additional root. A complete protected replay of the candidate source
and that oracle finished in `protected-stable-v477`: **1,754/1,759**, including
**CSR 110/110**, **Innermost 311/311**, and Standard 1,333/1,338. Retain v386 as
the complete protected baseline. The five Standard timeouts are three
LISTUTILITIES systems, MYNAT_complete-noand_Z, and PEANO_complete_noand_C;
these are not waived regressions. Fresh native residual closure and strict
root replay recover LISTUTILITIES_complete_noand_C in
`protected-local-integration-v549` and MYNAT_complete-noand_Z in
`protected-mynat-residuals-v553`, with double checks. The remaining two
LISTUTILITIES roots recover in `protected-top-integration-v555`; PEANO recovers
in `protected-csr-integration-v560`. All five repairs pass independent original
input correspondence in `consolidated-v565/protected-repairs-correspondence.json`.
Thus the consolidated protected union is again 1,338 Standard, 311 Innermost,
and 110 CSR. This is not a claim that v477 itself had no losses.
The full SRS proof run `full-srs-v515` finished at **1,683/1,931**, with zero
certification failures and exactly two retained losses, compared against
`reference-expanded.json` (1,685 roots). Its second-check/correspondence pass
is still running. Four later additions have their own strict gates.
The two completed SRS losses (ICFP 4412 and 48686) were local-time exhaustion:
`srs-loss-repeat-v539` recovers both, and `replay-restored-srs-timings-v542`
passes strict replay, double checks, and correspondence with updated timing
hints. They are recoveries, not additional roots. The exact consolidated root
set and provenance are in `consolidated-v565/`; it is explicitly a union of
strict replays, not a single uniform run. A new unified replay is running in
`unified-final-v566` using the latest oracle and candidate binary: 1,931 SRS
inputs and all 1,759 protected roots, with explicit retained-root comparisons,
double checks, and a 2 TiB non-reclaimable-memory cutoff. Do not treat this run
as finished before its `COMPLETE.json` exists.
Local residual closures and
ongoing SRS discoveries do not count as new roots before strict root replay.
No CeTA source or production checker change was made in this continuation.
Production CeTA remains main commit `1872a8c87996086a87151ec7352843e3d8e4d142`.

### 2026-10-16 continuation: 32 further strictly replayed SRS roots

Beyond the 1,626-local / 1,620-shared incremental starting union below,
`replay-explicit-gains-v370/` adds **31 distinct roots: 25 YES and 6 NO**.
All 31 passed witness-free oracle-only/no-fallback replay, two production CeTA
checks, and original-input correspondence. `replay-explicit-gains-v375/` adds
one further certified YES (`baababaab-ababaabaabab.srs`), with its own double
checks and correspondence audit. The resulting incremental union is
**1,658 local / 1,652 shared**. The other v375 discovery did not replay within
its local allowance and is being retried with more headroom; do not count it.

Artifacts are under `target/srs-native-20261013/`. The explicit-backend oracle
is `integrated-explicit-gains-v370/oracle.jsonl`, SHA256
`b50bbd6387a9e36bedd0903a4773da821ee691fe8ad1ceee0304fd32fd0190d9`.
Replay uses `ferrum-explicit-arctic-v368`; the final source build is
`ferrum-final-v385` (SHA256
`4068cd2ae28a1fe07db073034d837d7364d6d78c89d4189d7a9e79a2141256d2`).
The latter includes the test-headroom refactoring; production limits are
unchanged. Ferrum implementation commit: **`56c1223`**. Backend selection is state-local; no global experimental
Arctic flag is needed. No CeTA source changes were made in this continuation.

This is **not yet a new frozen full-category baseline**. The full consolidation
is running in `full-expanded-v378/`. Preliminary protected runs omitted the
pinned LP dependency environment; those incomplete runs are not baselines.
The corrected `protected-baseline-env-v374/` still exposed a new path-order
residual for `PALINDROME_complete_noand_iGM`. The full replay also exposed
new residuals for Innermost `MYNAT_complete_GM` and `Ex5_7_Luc97_C`. All three
have recovered certified proofs in `protected-residuals-v381/0/`; their checked
modular evidence is in `integrated-protected-v384/`. All three pass strict
replay, double certification, and correspondence in `replay-protected-v384/`.
The refreshed CSR replay also passes all 110 double checks and independent
input/replacement-map audits under `full-expanded-v378/protected/TRS_Contextsensitive/`.
The earlier parallel suite hit the 60-second pattern-search test guard; a
serial run also hit the five-second concurrent SMT-pool test deadline. Both
correctness tests now have load headroom without changing production limits.
The complete suite passes **1,208 tests, zero failed or ignored** in
`full-tests-headroom-v382.log`. The release build succeeds
(`build-final-v385.log`, immutable binary `ferrum-final-v385`).
The final committed-binary protected replay is running in
`protected-committed-v386/` against the recovered modular oracle
`integrated-protected-v384/oracle.jsonl` (SHA256
`bc612411e9b3e4dfe14949c7c429f451431d3ba44489eb48af980e9167732b51`).

### 2026-10-16 preceding campaign: 32 additional strictly replayed roots

The active campaign has **32 distinct additions** beyond the v241 incremental
union: nine certified NOs and twenty-three certified YESs. Each addition has passed
witness-free oracle-only/no-fallback replay, two CeTA checks, and original-input
correspondence. This is an incremental **1,626 local / 1,620 shared** union, not a
replacement for a frozen full-category replay. The requested target was at
least thirty additional roots; that incremental target is reached. The fresh
full-category replay in `full-expanded-v313/` completed with **1,625 SRS roots
(1,358 YES, 267 NO), 306 unresolved, and zero retained losses**. Its final
double-check and independent-correspondence stages have now passed. The fully
frozen snapshot is `target/srs-native-20261013/final-witness-free-v313-20261015/`;
all 3,384 retained proofs passed both checks and the original-input audits.
The incremental ledger is `target/srs-native-20261013/gain-ledger-v301.json`.
The full replay covers the first 31 additions (1,625 local); the subsequently
gated `Wenzel_16/abababaababa-ababaababaabab.srs` is retained separately in
`replay-arctic-four-signed-gain-v314/` and
`integrated-arctic-four-signed-gain-v314/oracle.jsonl`. The replayed oracle is
immutable and was not changed to include this last root.

The addition replay directories under `target/srs-native-20261013/` are
`replay-pattern-final-v248`, `replay-arctic-symmetry-gains-v256`,
`replay-arctic-bv-recorded-v267`, `replay-arctic-recorded-gains-v270`,
`replay-arctic-recorded-lp-v272`, `replay-arctic-next-three-v274`,
`replay-arctic-projection-recorded-v276`, `replay-arctic-recorded-next-v277`,
`replay-arctic-unsorted-v289`, `replay-arctic-small-v294`, and
`replay-rfc-production-v298`, `replay-arctic-long-budget-v299`,
`replay-arctic-small-next-v300`, `replay-arctic-boolean-gain-v306`, and
`replay-arctic-long-next-v307`, `replay-arctic-long-extra-v311`, and
`replay-arctic-four-signed-gain-v314`.

CeTA-CSR **did change**: main commit `1872a8c` adds the Isabelle-proved RFC
deletion processor with absolute termination of the retained rules. The existing
checker remains the first route, and the new route does not admit assumptions.
Production checker SHA256:
`f23285d852d5bce3828f50c4fdf8e6f0f571258e0ddf4d165c9eb9c37b2635fc`.
All 3,352 frozen proofs passed two checks with the new checker implementation;
the four new RFC proofs passed production checks and self-loop mutations were
rejected. Artifacts: `rfc-checker-validation-v280/`,
`replay-rfc-production-v298/`, and CeTA-CSR `target/rfc-absolute-v298/`.

Ferrum source is committed as `9c3ae92`, with immutable binary `ferrum-final-v309`.
The current-source production-checker library test run is **1,199 passed, zero
failed or ignored** (`all-tests-v309-production.log`). An intermediate concurrent
SMT-pool test failure exposed a retry through another stale pooled solver; reset
recovery now starts a fresh process and has a deterministic regression. No tests
were skipped. The 345-root RFC/pattern guard passes without losses. Fresh protected
CSR, Innermost, and Standard replays are 110/110, 311/311, and 1,338/1,338.
The v313 protected replay has also passed two production checks for all 1,759
proofs and passed its final correspondence audit.

The 303-second Arctic discovery now passes strict replay with an explicit
`FERRUM_ORACLE_ATOM_MAX_SECONDS=1800` override. Normal runs retain the 300-second
ceiling. Long SRS campaign replays use that override and measured timing headroom;
final protected category replays preserve their original 300-second atom ceiling.
The last native Arctic proof has passed replay and is included above. The v313
consolidation starts from `integrated-arctic-long-extra-v311/oracle.jsonl` to
preserve all staged guidance. The earlier v312 bundle omitted two narrower
`srs-finite-context-loop(max-width=25)` actions (exact and canonical aliases),
although their wider `max-width=27` action remained. No running oracle was
modified; v313 independently replayed the complete monotone union. Its oracle
SHA256 is `d51729b8c96b1e984829e876354bbaa57538b4a9b7cb92618115f5b74e513f07`.
The separately integrated v314 union has 571,746 states, 1,649,126 actions,
zero forbidden actions, and SHA256
`0e9f36a2392b808c9575cd675aefc14e361eefc1884a7fba7c2342a6adc3ecad`.

### 2026-10-16 consolidated v240: 1,593 certified

This earlier fully frozen replay is **1,593/1,931 local SRS roots**
(1,336 YES, 257 NO), **1,587/1,921 shared**, with 338 unresolved and no
retained losses. Standard **1,338**, Innermost **311**, and CSR **110** remain
certified. All **3,352** retained proofs passed double production CeTA checks
and independent original-input correspondence audits.

- Frozen artifacts: `target/srs-native-20261013/final-witness-free-v240-20261015/`;
  full replay: `target/srs-native-20261013/full-expanded-v240/`.
- Ferrum source: `3bea7d8ab64ed8d26b04640d9ac5bdb3f63b8d53`, immutable binary
  `ferrum-final-v232`, SHA256
  `87a255135a3bac72190b6ffaeca89f0192b259123bca5db6075cd3e08a659f38`.
- Oracle SHA256: `d137edb8b5657cbadb2ecb462bf0a1d079cd684bc67dfe15f5a23f4826497b22`;
  571,516 states, 1,648,176 actions, zero forbidden actions.
- CeTA unchanged: main `73662ec88a74f65187cba6986d300836564b6a59`, binary
  SHA256 `64597fcb0a8c1c09af1de0816283c66f474783df3010fc3e60ca30731f5090b7`.

The v241 incremental union below additionally retains `Waldmann_23/1`, giving
1,594 local / 1,588 shared. Subsequent live waves are not a replacement for this
fully frozen baseline until consolidated and independently audited.

### 2026-10-16 consolidated v209: 1,591 certified

The newest **fully frozen** replay is **1,591/1,931 local SRS roots**
(1,336 YES, 255 NO), **1,586/1,921 shared**, with 340 unresolved and zero
retained losses. Standard **1,338**, Innermost **311**, and CSR **110** are
preserved. All **3,350** retained proofs passed double production CeTA checks
and independent original-input correspondence audits.

- Frozen artifacts: `target/srs-native-20261013/final-witness-free-v209-20261015/`.
- Full replay: `target/srs-native-20261013/full-expanded-v209/`.
- Ferrum source: `292fb3a3bf4fec1e1f229632c5a0734271490efb`;
  immutable binary `ferrum-finite-window-v200`, SHA256
  `6f5dc66949658b5ec15c9b09cb9186f24455e499aa12f36d5547b04891c2950a`.
- Oracle SHA256: `aaa0614a8b5332ea1f13d67d8229c3976612bb9c207716d3b692269af10acf68`;
  571,514 states, 1,648,154 actions, zero forbidden actions.
- CeTA is unchanged: main `73662ec88a74f65187cba6986d300836564b6a59`,
  executable SHA256 `64597fcb0a8c1c09af1de0816283c66f474783df3010fc3e60ca30731f5090b7`.

The preceding frozen v204 snapshot retained 1,587 local / 1,582 shared roots;
its artifacts remain in `final-witness-free-v204-20261015/`. Beyond the newer
v209 frozen set, three new certified NOs pass witness-free oracle-only replay, double production
CeTA checks, and independent input correspondence in
`replay-finite-wide-gains-v241/`:

| Root | Native discovery | Final-source strict replay | Discovered loop |
| --- | ---: | ---: | --- |
| `Waldmann_23/1` | 97.694 s | 30.642 s | 156 steps, 26-symbol source |
| `Waldmann_23/4` | 20.140 s | 5.608 s | 144 steps, 24-symbol source |
| `Waldmann_26/1` | 9.014 s | 16.753 s | 52 steps, 27-symbol source |

The incremental union is **1,594 local / 1,588 shared**; `Waldmann_26/1` is a
local extra, not a shared competition input. Do not confuse this union with
the fully frozen baseline above. Every participating tool in the cached 2026
results, including both AProVE and Matchbox configurations, misses the two
`Waldmann_23` roots. No retained loop word or rule sequence is supplied.

- Final implementation: Ferrum `3bea7d8`, binary `ferrum-final-v232`, SHA256
  `87a255135a3bac72190b6ffaeca89f0192b259123bca5db6075cd3e08a659f38`.
- Incremental oracle: `integrated-finite-wide-gains-v241/oracle.jsonl`, SHA256
  `f4f5740d6f313f28963579f1b06d3a5fb9af67b2a34001d316fe56d099548dcc`;
  571,516 states, 1,648,183 actions, zero forbidden actions.
- Release library suite: **1,188 passed, zero failed or ignored** in
  `all-tests-v232.log`. The prior nine-loop guard also passes in
  `final-loop-guard-v233/`. CeTA source and executable are unchanged.
- Final-source full consolidation `full-expanded-v240/` completed with the
  first two gains; `Waldmann_23/1` arrived subsequently and is not yet in that
  full-replay snapshot. The latest incremental oracle above includes all three.

The successful improvement packs graph colors into two bits, allowing wider
bounded word graphs. Additional shared symbolic-loop encoding, independent
source/derivation width bounds, beam search, and composed-derivation pilots
remain experimental: they have not yet added certified roots. In particular,
the 226-root composition wave `compose-frontier-v221` added none. These are not
default-strategy changes and must not be credited as coverage gains.

### 2026-10-16 consolidated v174: 1,583 certified

**Current verified high-water mark:** 1,583/1,931 local SRS roots (1,336 YES,
247 NO), 348 unresolved; **1,578 on the shared 1,921-input set**. Zero losses.
Standard 1,338, Innermost 311, and CSR 110 are retained. All **3,342** positive
proofs passed double production CeTA checks and independent original-input
correspondence audits. This remains witness-free oracle-only/no-fallback.

- Frozen artifacts: `target/srs-native-20261013/final-witness-free-v174-20261015/`.
- Full replay/audits: `target/srs-native-20261013/full-expanded-v174/`.
- Oracle SHA256: `54ab57557248d30b2062c2b0e753ae87b1662c11d7534870d2e17ff9e353832f`;
  571,514 states, 1,648,031 actions, zero forbidden actions.
- Ferrum binary source: `da6c893c9f240ee4b38a0731c060a88870050c5f`;
  immutable `ferrum-lp-maximal-v153`, SHA256
  `244e2198d3f4cfd44daabee39f60fdd284ebcc1b29169055413f370f30a13ff7`.
- CeTA unchanged: main `73662ec88a74f65187cba6986d300836564b6a59`, SHA256
  `64597fcb0a8c1c09af1de0816283c66f474783df3010fc3e60ca30731f5090b7`.
- The four gains over v152 are the Wenzel v164 root, `Trafo_06/un17`,
  `CirponsMitchellSmith_25/no_subst_baabaa_aba`, and `Zantema_06/while1`.

Beyond this frozen set, native finite-word/context graph search recovers
`Gebhardt_06/10` and `Waldmann_07_size12/size-12-alpha-3-num-{209,219,267}` as
certified NOs. All four pass strict witness-free replay and double checks in
`replay-finite-context-v197`. The generalized implementation additionally
recovers `Waldmann_07_size12/size-12-alpha-3-num-{210,291,292}` and
`Waldmann_19/random-278`; all four pass strict replay and double checks in
`replay-finite-small-gains-v206`. The deduplicated total is **1,591 local /
1,586 shared incrementally** (100 further roots needed to exceed Matchbox raw
1,685). All eight new roots independently pass original-input correspondence
audits in `native-loop-gains-v207/root-correspondence.json`.
This is a coverage comparison, not equal-time competition performance.
The eight-root union oracle is
`target/srs-native-20261013/integrated-finite-small-gains-v206/oracle.jsonl`,
SHA256 `aaa0614a8b5332ea1f13d67d8229c3976612bb9c207716d3b692269af10acf68`,
571,514 states / 1,648,154 actions / zero forbidden actions. Source commit
`292fb3a`, immutable binary `ferrum-finite-window-v200`, SHA256
`6f5dc66949658b5ec15c9b09cb9186f24455e499aa12f36d5547b04891c2950a`.
Cached 2026 official results report Matchbox timeouts (both configurations)
for three of these gains: `num-209`, `num-210`, and `random-278`.

The new route is not yet part of a completed full category consolidation;
v204 is running with the first four new roots and all protected categories.
The 230-root `finite-frontier-v202` sweep remains separate from that gate.
All 1,186
release library tests pass (zero failed/ignored, `all-tests-final-v200.log`).
CeTA unchanged.

### 2026-10-16 consolidated v152: 1,579 certified

**Previous verified high-water mark:** 1,579/1,931 local SRS roots (1,332 YES,
247 NO), 352 unresolved, **1,574 on the shared 1,921-input set**. Zero retained
losses; Standard 1,338, Innermost 311, and CSR 110 are retained. All 3,338
positive proofs passed double production CeTA checks and independent original
input correspondence audits. This is witness-free oracle-only/no-fallback.

- Frozen artifacts: `target/srs-native-20261013/final-witness-free-v152-20261015/`.
- Full replay and audits: `target/srs-native-20261013/full-expanded-v152/`.
- Oracle SHA256: `e86aea2645d5820a6c63ce6f904612af6a8dbd46f37635f81185a225c5b812f3`;
  571,462 states, 1,647,853 actions, zero forbidden actions.
- Ferrum binary source: `1de35de9473d923d94b9e1e910756084c1ffd893`;
  immutable `ferrum-lp-v117`, SHA256
  `359340e174cd69d617a57229490bd7386a3da1b054fb841ef7ac3efe05b64482`.
- CeTA unchanged: main `73662ec88a74f65187cba6986d300836564b6a59`, SHA256
  `64597fcb0a8c1c09af1de0816283c66f474783df3010fc3e60ca30731f5090b7`.
- LP backend: HiGHS 1.15.1, NumPy 2.5.4, as recorded in the manifest.

The following historical incremental gains are now included in v174 above.
`Wenzel_16/aabaaabaab-abaaabaabaaab` passed strict
oracle replay and double certification in `replay-wenzel-gain-v164`, supporting
**1,575 shared incrementally** at that stage.
Exceeding Matchbox raw 1,685 requires 111 further shared roots beyond that
incremental set. This is a coverage comparison, not equal-time performance.

The proof-specific Matchbox wave subsequently recovered `Trafo_06/un17` and
`CirponsMitchellSmith_25/no_subst_baabaa_aba`. Both pass strict witness-free
oracle replay and double CeTA checks in `replay-un17-gain-v170` and
`replay-cirpons-gain-v171`, supporting **1,577 shared incrementally**, 109 short
of exceeding Matchbox raw at that stage. Wave `matchbox-guided-v167` and the
Wenzel gain subsequently passed full v174 consolidation. CeTA is unchanged.

`Zantema_06/while1` subsequently passed strict witness-free oracle replay and
double production CeTA checks in `replay-while1-gain-v182`, supporting
**1,578 shared incrementally**, 108 short of exceeding Matchbox raw.
It belongs to the same v167 wave and is now included in frozen v174.

The recipe audit `matchbox-recipes-v166.json` reads cached Matchbox CPFs,
preserving preprocessing order and extracting only processor bounds. Of its
48 remaining cached certified-YES recipes, 16 need matrix upper bounds above
the previous campaign cutoff of four and 28 contain negative finite Arctic
entries. The top-level rule-removal steps in this slice are rational
polynomial, not Arctic. The archived 2026 proof URLs failed retrieval, so these
recipes use the available 2025 certificates, not claimed inspection of missing
2026 certificates.

### 2026-10-16 Matchbox certified-count parity: 1,564 certified

**Previous verified high-water mark:** 1,564/1,931 local SRS roots (1,317 YES,
247 NO), 367 unresolved, zero retained-root losses. On the shared 1,921-input
TermCOMP 2026 set this is **1,559 certified**, exceeding Matchbox's **1,558**.
This compares certified coverage counts, not equal-time competition performance
or inclusion of every Matchbox-solved root. The remaining cached certified
competitor misses are 68 Matchbox and 37 AProVE roots (90 in their union).

The complete witness-free, oracle-only/no-fallback replay retains Standard
**1,338**, Innermost **311**, and CSR **110**. All **3,323** retained proofs passed
double production CeTA certification and independent original-input
correspondence audits. No exact/composite actions were introduced.

- Source commit: `1de35de9473d923d94b9e1e910756084c1ffd893`, clean source state.
- Full replay: `target/srs-native-20261013/full-expanded-v128/`; completion log:
  `target/srs-native-20261013/full-expanded-v128.log`.
- Frozen oracle, root set, and manifest:
  `target/srs-native-20261013/final-witness-free-v128-20261015/`.
- Oracle SHA256: `6b47c0256c66336fad4d065fd0822f26629d54c74930e1745f91b581334e340c`;
  571,252 states, 1,647,202 actions, zero forbidden actions.
- Binary: `target/srs-native-20261013/ferrum-lp-v117`, SHA256
  `359340e174cd69d617a57229490bd7386a3da1b054fb841ef7ac3efe05b64482`.
- CeTA unchanged: main `73662ec88a74f65187cba6986d300836564b6a59`, binary SHA256
  `64597fcb0a8c1c09af1de0816283c66f474783df3010fc3e60ca30731f5090b7`.
- Optional candidate backend: HiGHS 1.15.1 and NumPy 2.5.4, recorded in the
  manifest. Set `FERRUM_LP_PYTHONPATH` to the isolated
  `target/srs-native-20261013/lp-tools-v107` directory when reproducing this run.

The gains use native LP weight synthesis after context closure/shift labeling.
Numerical candidates are reconstructed and exactly checked before CPF output;
the oracle contains processor actions and bounds, not supplied interpretations.
The final suite passed all 1,171 library tests; 26 exporter/audit tests passed.
The preceding v118 full replay was not promoted: a load-sensitive `57132`
failure was recovered with fresh native LP guidance and certifies in about six
seconds in v128. SRS replay used a 300-second search allowance; independent
large-proof rechecks/audits used 600 seconds. Streaming XML root audits kept a
3.4 GiB certificate's correspondence check to about 21 MiB of process memory.

There are **12 further individually discovered, strictly replayed, and
double-certified shared roots** in `native-lp-minimal-priority-v119` beyond this
frozen set, supporting 1,571 incrementally. They are not included in the above
high-water mark until a subsequent full consolidation/retention run.

#### 2026-10-16 ongoing consolidation and raw-count campaign

The v152 full replay has completed with **1,579 local certified roots
(1,332 YES, 247 NO), or 1,574 shared roots**, zero SRS retained-root losses,
and all 1,759 protected roots retained. Its double rechecks and independent
correspondence gates are still running; v128 above remains the frozen baseline
until those gates pass. The guarded `finalize-v152.py` freezes only after all
gates pass and revalidates the freeze manifest independently.

A further native discovery, `Wenzel_16/aabaaabaab-abaaabaabaaab`, passed CeTA
twice in `wenzel-refinement-v159/-2_3/`. It uses context closure, shift labeling,
reversal, polynomial deletion, and synthesized integer-Arctic matrices with
finite bounds -2 through 3. Modular extraction and strict replay are running
in `wenzel-gain-v164`; this root is **not yet counted** in the above totals.
CeTA is unchanged. The expanded Wenzel-family search is `wenzel-family-v165`.

Three further shared roots have native witness-free oracle-only replays and
double production CeTA checks: `Secret_06_SRS/multum1` (`replay-multum-v136`),
`Trafo_06/dup11` (`replay-optional-graph-gains-v143`), and `ICFP_2010/167310`
(`replay-new-2026-hints-m2-v139`). Together with the above twelve this supports
**1,574 incrementally**, not a new frozen category high-water mark. Exceeding
Matchbox raw 1,685 requires at least 112 further shared roots.

The v129 consolidation was not promoted: legacy weight search timed out on
`84977`. v142 recovered it but lost `149915` and `150839` to legacy weight
search deadlines. All three have fresh certified LP recoveries. Both runs
retained all 1,338 Standard, 311 Innermost and 110 CSR roots. To avoid repeated
one-root repairs, 45 slow retained ICFP roots were migrated to native LP
guidance (`legacy-lp-m1-v150`, `legacy-lp-m2-v150`); all 45 discoveries and strict
replays certify. Full v152 consolidation integrates those routes plus all
fifteen gains and must pass every retention/recheck/correspondence gate before
promotion. It uses the pinned v117 binary from source `1de35de9473d923d94b9e1e910756084c1ffd893`.

Broader discovery is recorded in `competitor-frontier-v130`,
`optional-graph-orders-v135`, `new-2026-hints-v139`, deeper shift searches
`native-lp-memory4-v132`/`native-lp-memory5-v146`, and `unhinted-lp-v149`.
The latter explicitly includes roots absent from the external-proof corpus.
The 97-root memory-three sweep and 111-root LP/RFC-interleaving sweep produced
no gains; these are not counted as successful coverage improvements.
CeTA source and production binary are unchanged.

### 2026-10-16 encoding-stable full replay: 1,499 certified

**Latest complete high-water mark:** 1,499/1,931 SRS roots (1,252 YES,
247 NO), 432 unresolved, zero retained-root losses. On the shared 1,921-root
2026 set this is **1,494**, 64 below Matchbox's 1,558 certified results.
Protected categories remain Standard **1,338**, Innermost **311**, CSR **110**.
All 3,258 retained proofs passed double production CeTA certification and
independent original-input correspondence audits.

- Full replay and audit log: `target/srs-native-20261013/full-expanded-v93/`
  and `full-expanded-v93.log`.
- Frozen oracle and manifest:
  `target/srs-native-20261013/final-witness-free-v93-20261015/`.
- Oracle SHA256: `0ef84f2bd2da5aa3372afcff456c97bbbb6c0550dba749ce7e7eed02b5101dff`;
  570,597 states, 1,645,412 actions, zero forbidden actions.
- Binary: `ferrum-encoding-split-v93`, SHA256
  `db37619a294cbeb1fb1da4132420e5f64bc9fd272b178b724c72870201fbed26`.
  Source head `966ded2a6191765a3ed96d6b1ab362dd23d0d572` plus recorded diff
  `2e0f58e760eabf92e6ce77138cfbb619e27ec4fedf0534e68f103eaaffb94ccb`.
- CeTA unchanged: main `73662ec88a74f65187cba6986d300836564b6a59`, binary
  SHA256 `64597fcb0a8c1c09af1de0816283c66f474783df3010fc3e60ca30731f5090b7`.

The two new Wenzel proofs use the separately named `arctic-matrix-cached`
action. Existing `arctic-matrix` guidance keeps its original encoding. The
preceding global-encoding experiment v89 failed its retention gate and was
not promoted; v93 recovers every lost root. Experimental later discovery
results are not included in these totals.

### 2026-10-16 consolidated late-wave replay: 1,497 certified

**Latest complete high-water mark:** 1,497/1,931 SRS roots (1,250 YES,
247 NO), 434 unresolved, zero retained-root losses. Standard **1,338**,
Innermost **311**, and CSR **110** remain intact. All 3,256 retained proofs
passed double CeTA checks and independent original-input correspondence audits.

- Frozen artifacts: `target/srs-native-20261013/final-witness-free-v68-20261015/`;
  full replay: `full-expanded-v68/` and `full-expanded-v68.log`.
- Oracle SHA256: `9b2d11138e5a0db3897c4256d75d0f71a8914ff2e6fa0a24f3c859947aac3e04`;
  570,583 states, 1,645,375 actions, zero forbidden actions.
- Same runtime binary and unchanged production CeTA as v65 below.
- On the shared 1,921-input 2026 set, Ferrum certifies 1,492 (five local
  certified extras excluded). Cached official per-root evidence gives Matchbox
  1,558 certified / 1,685 raw, AProVE 982 certified / 1,157 raw. Differences
  are 118 Matchbox-certified and 42 AProVE-certified misses, a union of 140;
  the raw runs add 79 distinct further targets. This compares coverage, not
  competition speed or equal resource limits.

### 2026-10-15 expanded native-search sweep: 1,494 certified

**Latest complete high-water mark:** 1,494/1,931 SRS roots, comprising
1,249 YES and 245 NO, with 437 unresolved and zero retained-root losses.
Protected Standard **1,338**, Innermost **311**, and CSR **110** all remain
certified. All 3,253 retained proofs pass double production certification
and independent original-input/CPF correspondence audits.

- Artifacts: `target/srs-native-20261013/full-expanded-v65/`; frozen oracle,
  manifest and root set: `final-witness-free-v65-20261015/`.
- Oracle SHA256: `42b770201d930899c1c8f397c554b25be1ff2d67d11aee380f0ef093361bf103`;
  570,544 states, 1,645,317 actions, zero forbidden witness/composite actions.
- Runtime: `ferrum-target-width-v64`, SHA256
  `167f6f48752d4da9a748a67de6a5575df1fb951b783a7f65869576b4542d48ef`.
  Built from `d5be99c6272e22dc6eefb2ac5a69aa7dd2d7244e` plus recorded source
  diff `ad1288061e2f62155d04677cc202b13eee2f392911fb3f2f59ae273b2c9b8561`;
  processor changes subsequently committed in `1275a5f`. The frozen manifest
  identifies this dirty build by head + diff rather than an inherited old
  binary source commit.
- CeTA unchanged: main `73662ec88a74f65187cba6986d300836564b6a59`, SHA256
  `64597fcb0a8c1c09af1de0816283c66f474783df3010fc3e60ca30731f5090b7`.

Three further individually replayed gains are undergoing the v68 full replay;
they are not yet part of this completed baseline.

### 2026-10-15 competitor-frontier consolidated sweep: 1,484 certified

**Latest complete high-water mark:** all 1,931 local SRS inputs replayed,
with **1,484 certified roots (1,240 YES, 244 NO)** and 447 unresolved.
There are **zero retained-root losses**. Protected categories remain
**TRS Standard 1,338, Innermost 311, CSR 110**. All 3,243 retained proofs
passed two production CeTA-CSR checks and independent original-input/CPF
correspondence audits.

- Full artifacts: `target/srs-native-20261013/full-expanded-v58` and
  `full-expanded-v58.log`.
- Frozen oracle, manifest, and certified root set:
  `target/srs-native-20261013/final-witness-free-v58-20261015/`.
- Oracle SHA256: `55e2519bd5c5525dbd8d03e81ace31f163987fddcae82e71d9f8f3f83dfdc0b1`;
  570,388 states, 1,644,960 actions, zero forbidden witness/composite actions.
- Runtime unchanged: `ferrum-final-v40`, source
  `9d7a48e5513f9eecd7ed0b72810c7974367ecfe2`; integration fixes/evidence
  committed in `d17e64f` and `6fac120`.
- CeTA unchanged: main `73662ec88a74f65187cba6986d300836564b6a59`, checker SHA256
  `64597fcb0a8c1c09af1de0816283c66f474783df3010fc3e60ca30731f5090b7`.

The 17 distinct gains comprise seven corrected external-parameter recoveries
and ten additional high-weight shift-labeling recoveries. These remain native
searches, not supplied interpretations. A separate noncanonical-weight wave
recovered 11 roots already present in this union, not 11 additional gains.
See the 2026-10-15 reproducibility entry for exact roots and exploratory
harness errors. Time ceilings and the coverage-versus-speed caveat below remain
unchanged.

### 2026-10-15 final consolidated sweep: 1,467 certified

**Authoritative completed high-water mark:** all **1,931 local SRS Standard
inputs** replayed with **1,467 certified roots: 1,223 YES and 244 NO**.
There are 464 unresolved inputs (462 MAYBE, two timeouts), **zero retained-root
losses**, and **zero certification failures**. This is **96 gains over 1,371
(93 YES, three NO)** and **489 gains over 978 (402 YES, 87 NO)**.

The same global oracle retains every protected root: **TRS Standard
1,338/1,338, Innermost 311/311, CSR 110/110**. All **3,226 retained root
certificates passed two independent production CeTA-CSR checks**. Independent
ARI/CPF correspondence audits additionally pass **3,226/3,226**, checking the
original rules, symbol arities, requested rewrite strategy, answer polarity,
and original replacement maps for CSR. No Ferrum parser/canonicalizer is
used for that comparison.

- Full replay and audits: `target/srs-native-20261013/full-expanded-v49`
  and `full-expanded-v49.log`; protected categories ran concurrently and
  launched historically slow roots first.
- Frozen global oracle and provenance:
  `target/srs-native-20261013/final-witness-free-v49-20261015/`
  (`oracle-global.jsonl`, `manifest.json`, `certified-roots.json`).
- Oracle SHA256: `5808567f17802a5e00cf72c55036497f28deddc949580a2424d24521a3645baf`.
  Audit: **570,073 states, 1,644,324 actions, zero forbidden witness/composite
  actions**. Guidance is state-local processor selection, parameters, and
  ordering; synthesized orders/loop traces are not supplied by the oracle.
- Ferrum runtime source: `9d7a48e5513f9eecd7ed0b72810c7974367ecfe2`;
  frozen binary `target/srs-native-20261013/ferrum-final-v40`, SHA256
  `148aa9d3e9d067b6734249d13fcf371194053e3ae2f6a9ab58cac2dc279880a8`.
- CeTA-CSR: **unchanged**, main `73662ec88a74f65187cba6986d300836564b6a59`;
  production checker SHA256
  `64597fcb0a8c1c09af1de0816283c66f474783df3010fc3e60ca30731f5090b7`.
- Verification: **1,159 release library tests passed**, zero failed/ignored
  (`full-tests-v40-serial.log`); **21 correspondence tests passed** again
  (`root-correspondence-tests-v49.log`); seven renamed/rule-permuted examples
  pass double checks (`renamed-{reverse-arctic,tight-loops}-v54`,
  `renamed-period7-v59`).

The 96 new roots are counted incrementally, not by summing overlapping wave
totals:

| Discovery family | Additional distinct roots |
|---|---:|
| Reversed bit-vector QPI | 21 |
| Reversed Arctic matrices, beyond those QPI results | 46 |
| Tighter closure-width loop search | 3 |
| Period-seven QPI with small coefficient bounds | 4 |
| Broader small-bound forward QPI | 17 |
| Small-bound reversed QPI | 5 |

Each successful discovery wave passed strict oracle-only replay and double
checks before its fresh shards entered the consolidated oracle. Period-seven
search illustrates the efficiency gain: reducing the bound from seven to one
recovers all four targeted roots in 2.0--9.6 seconds, versus one success and
three 60-second search misses at the wider bound. No new example-specific
production code or exact witnesses were added.

This is a witness-free, **no-fallback oracle replay**, not a competition-speed
default-strategy measurement. SRS root ceilings were 180 seconds; protected
regression ceilings were 1,200 seconds. Timing allowances retain the measured
headroom/load scaling recorded in `environment.json`. Three additional
139-input sweeps of 2026-only positive hints (tiling, QPI, Arctic) yielded no
new certifications; their misses remain in the frontier rather than being
promoted from external claims.

### 2026-10-15 completed timing-repaired sweep: 1,371 certified

`target/srs-native-20261013/full-expanded-v44/srs` completes all **1,931
inputs with 1,371 certified roots: 1,130 YES and 241 NO**, zero retained-root
losses, and zero certification failures. All 1,371 passed double production
CeTA-CSR checking and the independent ARI/CPF root-correspondence audit.
The same oracle retains **1,759/1,759 protected roots** (Standard 1,338,
Innermost 311, CSR 110), also checked twice. Completion is in
`full-expanded-v44.log`; there are 560 unresolved SRS inputs.

This adds Zantema_06/15 and repairs two load-sensitive RFC allowances without
changing action order, processor parameters, proof status, or evidence credit.
The timing changes and original observations are in
`observed-timeout-budget-v43/report.json`. Gain over 978: **393 roots
(309 YES, 84 NO)**.

- Ferrum runtime source and frozen binary: unchanged `9d7a48e5513f9eecd7ed0b72810c7974367ecfe2`,
  `target/srs-native-20261013/ferrum-final-v40`, SHA256
  `148aa9d3e9d067b6734249d13fcf371194053e3ae2f6a9ab58cac2dc279880a8`.
- Oracle: `target/srs-native-20261013/full-expanded-v44/oracle.jsonl`, SHA256
  `46b3c2de1862173288d8a7f01b7f31acd3157845a83b3d52c44f5302abbc3576`.
  Audit: 569,302 states, 1,641,127 actions, zero forbidden witness/composite actions.
- CeTA-CSR: unchanged main `73662ec88a74f65187cba6986d300836564b6a59`, binary SHA256
  `64597fcb0a8c1c09af1de0816283c66f474783df3010fc3e60ca30731f5090b7`.

Further discoveries were not included in this checkpoint: the 52-root
reversed-Arctic wave, three tighter-width loops, and a period-seven QPI root
passed strict replay and double checks. The reversed-QPI and follow-up
small-bound waves subsequently completed; their consolidated result is the
1,467-root `full-expanded-v49` high-water mark above.
Five renamed, rule-permuted samples pass double checks in
`renamed-{reverse-arctic,tight-loops}-v54`. Three 139-input sweeps of additional
2026-only positive hints (tiling, QPI, Arctic) returned no new certified roots;
these are search failures, not certification failures.

### 2026-10-15 completed full sweep: 1,370 certified

`target/srs-native-20261013/full-expanded-v40/srs` completes all **1,931
local inputs with 1,370 certified roots: 1,129 YES and 241 NO**. This is
**392 gains over 978 (308 YES, 84 NO)**, with zero retained-root losses and
zero certification failures. All 1,370 certificates passed two independent
production CeTA-CSR checks. The independent ARI/CPF root-correspondence audit
also passes **1,370/1,370**, checking the exact original rule multisets,
symbol arities, full rewrite strategy, and answer polarity without Ferrum's
parser or canonicalizer (`srs/root-correspondence.json`).

The same-oracle protected replay passes **1,759/1,759**, also checked twice:
TRS Standard 1,338, Innermost 311, and CSR 110. Artifacts and completion:
`full-expanded-v40/{srs,protected}` and `full-expanded-v40.log`.

- Ferrum source: `9d7a48e5513f9eecd7ed0b72810c7974367ecfe2`.
- Frozen binary: `target/srs-native-20261013/ferrum-final-v40`, SHA256
  `148aa9d3e9d067b6734249d13fcf371194053e3ae2f6a9ab58cac2dc279880a8`.
- Oracle: `target/srs-native-20261013/full-expanded-v40/oracle.jsonl`, SHA256
  `846ce905bfa694ba26879079385c597f521cd03b025ce825c065f1a07160a395`.
- Oracle audit: 569,280 states, 1,641,086 actions, **zero forbidden
  witness/composite actions**.
- Production CeTA-CSR: unchanged main `73662ec88a74f65187cba6986d300836564b6a59`,
  checker SHA256 `64597fcb0a8c1c09af1de0816283c66f474783df3010fc3e60ca30731f5090b7`.
- Full serial release library suite: **1,159 passed, zero failed/ignored**,
  `full-tests-v40-serial.log`; independent correspondence tests: 21 passed.

Follow-up: memory-three tiling additionally recovers **Zantema_06/15**, with
strict replay and double checks in `replay-native-memory3-frontier-v41`.
The first 1,371-root consolidation (`full-expanded-v42`) returned 1,369:
ICFP_2010/43603 and 43650 hit roughly eight-second local RFC budgets. Both
recovered with the identical oracle/binary in isolated strict replay
(`rfc-losses-isolated-v42`). `observed-timeout-budget-v43/report.json` raises
only their measured replay allowances and canonical aliases using the
observed timeout durations; action order, historical best times, proof
status, parameters, and evidence credit are unchanged. The fresh
`full-expanded-v44` subsequently completed successfully, as recorded above.

### 2026-10-15 full 1,931-input sweep: 978 certified

`target/srs-native-20261013/full-expanded-v30/srs` completes the full local
1,931-input SRS Standard sweep with **978 certified roots (821 YES, 157 NO)**,
zero losses against the 977-root pre-sweep union, and zero certification
failures. The additional shared-guidance gain is **Zantema_06/06**, separately
checked twice. There are 953 unresolved inputs; this is not a 978/978-only
retained-set measurement. Source commit: **`a8f4ce2`**, binary `ferrum-final-v30`.
Oracle SHA256:
`5380f3730acf7fe5ab5b146586ad692c40fabadcceffc5f22a20c28da40bd4d8`.
Production CeTA-CSR remains main `73662ec88a74f65187cba6986d300836564b6a59`;
checker SHA256 `64597fcb0a8c1c09af1de0816283c66f474783df3010fc3e60ca30731f5090b7`.
The aggregate double checks are complete: **978/978**. The same-oracle
protected replay passes **1,759/1,759** (1,338 Standard, 311 Innermost,
110 CSR), also checked twice, with zero losses. Completion is recorded in
`full-expanded-v30.log`.

The gain over 937 is **41 roots: 29 YES and 12 NO**. The YES gain comprises
25 forward full-tiling results, Zantema_04/z023 from QPI, two reversed-tiling
results (Waldmann_19/random-127 and random-141), and Zantema_06/06 above.
The remaining Matchbox-certified NO gap is 101 roots: 50
CirponsMitchellSmith_25, 45 Waldmann_07_size12, three size11, and one each
Gebhardt_06, Secret_06_SRS, and Waldmann_19.

Renaming robustness follow-up: `srs-canonical-weight-removal(max-weight=128)`
solves a canonical copy and transports weights back through the checked
symbol bijection. The live polynomial-removal validator still checks the
result. The legacy weighted-search atom is unchanged. All 28 tiling-route
roots are rediscovered and strictly replayed with this action, each checked
twice (`replay-native-canonical-{memory2,memory1,reverse}-v31`). A renamed z114
also needed fresh DP residual guidance, recovered by native search and
imported without interpretations (`renamed-z114-native-v33`).

The updated oracle passes **29/29 renamed-and-reversed-rule-order inputs**,
all checked twice (`renamed-new-processors-v33/report.json`). Its SHA256 is
`30ffdf796d6d316ecfa1843b114666bcb7bc4750435bfa0a663e33a7849daf72`, with zero
forbidden witness/composite actions. It adds 19 child-state keys and weak
hints at three existing states to `full-expanded-v32/oracle.jsonl`, without
changing existing preferred-action lists. The full library suite passes
**1,155 tests, zero failed and zero ignored** (`full-tests-v32.log`).
`full-expanded-v32` has also completed: **978/1,931 SRS certified**, zero
losses, and **1,759/1,759 protected roots**, with both sets checked twice.
Its oracle SHA256 is
`a05df1bc57c13d6356db33cc192f4ec382011e84d2619cb72d96db2de359357b`.
Canonical-weight source commit: **`ee68f0d423789e592047c297cf5d60253b9f8692`**;
frozen binary `ferrum-final-v32`, SHA256
`2d1b98d65bcd35bf15e7b0434a772ccd39d3bd6b0aa884df55dacfbf68696588`.
The newest monotone oracle is frozen at
`target/srs-native-20261013/final-witness-free-v33/oracle-global.jsonl`,
with the `30ffdf...` checksum above. This latest patch has the completed
29-variant audit; distinguish it from the fully replayed v32 snapshot.

The subsequent opt-in bounded-width closure wave `native-narrow-v35` finds
64 certified NOs, **38 new** relative to 978: ten CirponsMitchellSmith_25,
26 Waldmann_07_size12, one size11, and Waldmann_19/random-400.
`replay-native-narrow-v35` recovers all 64 without witnesses/fallback and
checks every certificate twice. This gives a checked batch union of 1,016;
it is not yet a new complete-category high-water mark. CeTA is unchanged.

### 2026-10-15 completed 937-root aggregate

`retained-expanded-v21` has now completed: **937/937 SRS roots (792 YES,
145 NO)** and **1,759/1,759 protected roots** (1,338 Standard, 311
Innermost, 110 CSR), with zero losses. Every certificate in both sets passed
two independent checks with production CeTA-CSR main
`73662ec88a74f65187cba6986d300836564b6a59`. Ferrum source: `4828cc9`.
The witness-free, no-fallback oracle SHA256 is
`c29177542bfdf025abea9f999ee133c130fef960d359de8f5cbb157d126cb131`.
Artifacts: `target/srs-native-20261013/retained-expanded-v21` and its sibling
`.log`. This is a complete retained-set replay, not a full 1,931-input sweep.
The pending statements below describe the earlier launch, now superseded.

Subsequent backward-closure discovery (`native-backward-v23`) certifies 68 NO
roots, of which **12 are new** (11 Waldmann_07_size12 and Secret_07_SRS/num-515).
`replay-native-backward-v23` passes all 68 witness-free, oracle-only; every
certificate passes twice. The checked batch union is now **949 (792 YES,
157 NO)**, pending consolidation. All 151 nontermination-filtered release
tests pass, including independent forward-rule validation of the backward
closure construction, renaming, deadline, and terminating-system rejection.
No CeTA changes.

The subsequent full-tiling waves `native-shift-v25` (memory two) and
`native-shift-memory1-v26` add **25 distinct YESs**, each replayed without
witnesses/fallback and checked twice. `native-qpi-v27` certifies four roots;
one is additional, **Zantema_04/z023** (1.035 seconds). Its four-root strict
replay and double checks pass. Thus the checked batch union is **975 (818 YES,
157 NO)** pending final consolidation. The memory-three wave
`native-shift-memory3-v28` adds zero results on its 120 selected roots; this
is recorded as a search miss, not processor or certificate rejection.
The full release library suite passes **1,154/1,154**, with zero ignored.
Additional QPI rejection/deadline/renaming tests pass. Production CeTA is
unchanged. New strategy atoms expose flat-context layers, shift labeling,
and QPI reduction-pair deletion separately; imported guidance retains only
their parameters and state-local order, not models or compound proofs.

Subsequent transport batch (not yet a consolidated category replay):
`native-transport-v21` finds 59 certified NOs on the 225-root frontier;
51 are new relative to 886, so the checked batch union is **937 (792 YES,
145 NO)**. `replay-native-transport-v21` passes all 59 witness-free and
without fallback, and all 59 certificates pass two independent checks.
The new roots are 36 Wenzel_16, 13 Waldmann_07_size12,
one Waldmann_07_size11, and one Secret_07_SRS. No earlier transport success
is lost. Artifacts are under `target/srs-native-20261013/`. CeTA is unchanged.
The consolidated run is `retained-expanded-v21` (937 SRS roots plus all
1,759 protected roots). It must complete before calling 937 a single-oracle
category high-water mark. All 150 release nontermination-filtered tests and
the focused CPF XML-equivalence regression pass.
Ferrum source commit: `4828cc9`. The running aggregate's audited oracle has
zero forbidden witness/composite actions and SHA256
`c29177542bfdf025abea9f999ee133c130fef960d359de8f5cbb157d126cb131`.

`target/srs-native-20261013/retained-expanded-v14` completed with **886/886
certified SRS roots (792 YES, 94 NO)** and zero losses. All 886 certificates
pass two independent checks. The same-oracle protected replay passes
**1,759/1,759** (1,338 Standard, 311 Innermost, 110 CSR), also checked twice.
Ferrum source: `f8f83ff`; CeTA-CSR main remains
`73662ec88a74f65187cba6986d300836564b6a59` (no checker changes).
Oracle SHA256:
`3baab80ee78a1e057e06fd446c68db771c836dac9142055d5e0c4184518f1c4e`.
This is the completed retained-set replay, not a fresh full 1,931-root sweep.
The 225-root nontermination frontier has 180 remaining misses after the
priority-closure wave; transport-system search is the next targeted addition.

### 2026-10-14 broad push

New checked nontermination batch: priority-ordered context-extension search
finds 45 certified NOs on the 225-root frontier in 54 seconds, retaining all
three prior context-extension successes and adding **42 roots**, all from the
missing Matchbox-certified set. `replay-native-priority-closure-v14` passes
45/45 witness-free, no-fallback, followed by 45/45 double checks. The source
passes all 145 release nontermination-filtered tests; no CeTA changes.
Artifacts: `target/srs-native-20261013/native-priority-closure-v14` and
`target/srs-native-20261013/replay-native-priority-closure-v14`.
With the two bounds/RFC gains below, the checked batch union is **886**
(792 YES, 94 NO); a consolidated 886-root replay is still required.

Completed follow-up: `target/srs-native-20261013/retained-expanded-v13`
passes **842/842 SRS roots (790 YES, 52 NO)** and **1,759/1,759 protected
roots** (1,338 Standard, 311 Innermost, 110 CSR), with zero losses; all
certificates pass two independent CeTA checks. This supersedes the pending
aggregate statements below. Ferrum source: `065a6ef` (documentation through
`c7de156`); CeTA-CSR main: `73662ec88a74f65187cba6986d300836564b6a59`.
Oracle SHA256:
`f699a10cccd6afad207979f8994a9e36baaac1102588ff9f64ec53d9947f2dba`.
Of these successes, 837 (787 YES, 50 NO) belong to the official 1,921-input
2026 set; the five extras are Hofbauer_26/mnm1 through mnm5.

The completed bounds/RFC frontier independently adds two strict-replay YESs
(`replay-bounds-rfc-frontier-v7`, both checked twice). They are not included
in the 842-root aggregate above until the next consolidated replay.

The 2026 Matchbox-certified NO set has **205 roots absent** from this replay
(not 204: the difference of total NO counts is not a set difference).
The archived 2025 corpus supplies certified Matchbox evidence for 193 of them:
all 193 contain ordinary loop certificates, 161 with at most 64 rewrite steps.
Wenzel_16 accounts for 34 archived cases, with 32–729 steps (median 128).
This identifies loop discovery, not a missing loop certificate checker, as
the immediate nontermination target. The 2026 proof links remain unavailable;
these proof-shape measurements explicitly use 2025 artifacts.

Latest checked batch union: **842 SRS roots (790 YES, 52 NO)**. The 835-root
single-oracle replay has passed all independent double checks. Subsequent gains
are three native context-extension NOs, two unindexed-Matchbox YESs, and two
ordinary semantic-labeling YESs (`replay-native-context-loop-v9`,
`replay-matchbox-closed-v12`, `replay-external-labeling-fixed-v11`), all strictly
replayed without witnesses/fallback and checked twice.

The Matchbox root `Waldmann_19/random-436` initially missed replay because
discovery-order guidance tried an explored preprocessing branch before the
recorded closed DP chain. The campaign importer now enables its existing
`--closed-chain-first` ranking; both Matchbox roots then replay and certify.
No compound strategy or interpretation witness was substituted.

Ordinary semantic labeling is committed as Ferrum `93bd633`; the relative
processor accepts a full ordinary input as the empty-weak-part case and retains
an ordinary child. Innermost inputs remain rejected by this bridge. Twenty-seven
semantic-labeling tests pass, and the synthetic full CPF passes CeTA twice.
The concrete recovered roots are `Bouchare_06/04` and `Waldmann_19/random-450`.
No CeTA changes were required.

The intermediate newest-binary replay missed `Bouchare_06/09` when its guided
narrowing attempt exhausted 401 ms. An isolated larger-local-budget replay
certified it; refreshed measured guidance then passed the normal strict replay
and two checks (`replay-bouchare09-timing-v12`). This timing refresh, the closed
chain ranking, and all seven additions are consolidated in the running
`retained-expanded-v12` 842-root replay and protected 1,759-root guard.
Do not promote this aggregate before those checks finish. The finite 320-root
bounds/RFC wave remains running; no gain has yet been established from it.

The v12 aggregate reproduced the Bouchare_06/09 miss, so the timing refresh
alone was not a sufficient fix. Its narrowing implementation imposed a separate
100 ms cap on every rule subset, independent of the guided outer budget.
Ferrum `065a6ef` now shares the remaining parent budget fairly across subsets,
with a one-second per-subset ceiling and the original 100 ms behavior when no
parent deadline exists. Five loaded no-fallback repetitions all certify, and
all **144 release nontermination tests pass**. The source state including this
fix is frozen as `ferrum-subset-budget-v13`; the authoritative follow-up is
`retained-expanded-v13` (842 SRS roots plus all 1,759 protected roots), not the
superseded v11/v12 timing-miss runs. CeTA is unchanged.

The full `full-expanded-v5` sweep completed with **797 certified SRS roots**
out of 1,931, retaining every prior success. All 797 certificates passed twice.
Its same-oracle protected replay passed **1,759/1,759** (1,338 Standard,
311 Innermost, 110 CSR), also twice checked with zero polarity changes.
The integer-matrix wave replayed 31/31 and the transformation wave 8/8,
with one overlap; this produces 38 additional roots. The consolidated
`retained-expanded-v7/srs` replay passes **835/835 (786 YES, 49 NO)** with
no losses. Its double checks and newest protected replay are still running.
Oracle SHA256:
`47a55a7d1b25735f46fe881114470bc1e5d3e0287207ed434976624646c092bd`.

Native context-extension search adds three certified NOs:
`Mixed_SRS/1`, `Waldmann_07_size12/size-12-alpha-3-num-195`, and
`Waldmann_07_size12/size-12-alpha-3-num-99`. All three pass witness-free
oracle-only replay and double certification (`replay-native-context-loop-v9`),
giving a checked batch union of **838**. Ferrum implementation commit:
`f53874cb09c10663bbe0838eca571d77f80aa664`; no CeTA changes.
The release nontermination suite passes 143 tests. Increasing the old fixed-seed
loop search to 256 steps recovered zero of 225 roots; dynamically extending
contexts recovered these three. Neither new search is added to the default.

The exact 2026 root-set audit is in `frontier-2026-v7`. At the 835-root union,
830 belong to the official 1,921 inputs; five Hofbauer_26 inputs are extra.
The linked 2026 proof files returned HTTP 404, so proof-family classification
uses explicitly identified archived 2025 evidence, not purported 2026 proofs.
Overlapping families among missing roots: matrix 863, path orders 851,
polynomial 255, loops 211, bounds/RFC 186, labeling 93, transformations 60;
217 remain unclassified (`frontier-campaign-v7/classified.json`).
Native bounds/RFC discovery is running on 320 roots. Further Matchbox CPF
extraction no longer treats an empty cached processor-tag list as proof that
the file lacks usable CPF evidence. The corresponding waves try native order
synthesis and supported preprocessing, not supplied interpretations.

The corrected recursive order campaign finished with **116 additional certified
YESs**. Its parameter-only oracle replay passed **116/116**, all independently
rechecked twice: `target/srs-native-20261013/replay-external-orders-recursive-v4`.
This gives a **796-root retained batch union (747 YES, 49 NO)**, not yet a
single-oracle 796-root measurement. The prior consolidated **680/680** replay
has now also passed every independent double recheck.

All twelve Standard misses from the shortened guard recovered at the original
1,200-second root cap, with unchanged polarity and two independent CeTA passes:
`protected-reference-cap-v4`. Together with `unified-retained-v3`, the corrected
guard retains all **1,338 Standard, 311 Innermost, and 110 CSR** roots. The
successful retry used 400% local scaling and eight workers; its 193–774-second
runtimes explain why these results must not be compared as 60-second scores.
The newest oracle additions still need their own guard.

`full-expanded-v5` now consolidates the fresh 116-root hint shards into the
680-root oracle and runs a full **1,931-input SRS** replay (180-second roots),
alongside all 1,759 protected roots (1,200-second roots). Both use no fallback,
400% local scaling, and independent double checks. A further native discovery
wave, `external-orders-transforms-v5`, targets the remaining 354 order-guided
misses with generic processors found in external proof shapes: monotonic rule
removal, DP innermost switching, usable rules, and innermost-LHS removal.
Only processor families and search bounds are supplied, never exact models.
Ferrum production code and CeTA are unchanged by these campaign adjustments.

An additional extraction gap was identified: the first order waves skipped
negative matrix coefficients although native integer(-Arctic) processors are
available. `external-orders-integer-v6` targets **162 unresolved roots** with
external dimensions 1–4 and coefficient ranges contained in [-4,4]. Only
dimensions/ranges are extracted, not interpretations. The corrected native
search already certifies `Zantema_04/z024`; oracle-only credit awaits export
and replay. The current consolidated oracle under full replay has SHA256
`5ff97bc4408112bd7e7aac50faba7c1e0b0fc830e6c46aeca51b57711ae97474`,
with zero forbidden actions in its witness-free audit.

The second external-order wave recovered **75 additional YESs**, all replayed
without witnesses or fallback and independently certified twice:
`target/srs-native-20261013/replay-external-orders-native-v2`.
The consolidated retained replay now passes **680/680 (631 YES, 49 NO)**,
with zero unknowns, timeouts, errors, or checker failures in 293 seconds:
`srs-retained-680-v4`. This uses one witness-free oracle, no fallback, a
180-second root cap, 24 workers, and 400% local-time scaling. Independent
double rechecks of this consolidated run are in progress; all contributing
605+75 batch certificates already passed twice. This is a retained-set replay,
not a full 1,931-input sweep. Consolidation uses only fresh modular hint shards. Its audited
oracle SHA256 is
`4b7190d4e5541f943d00e00a920e45941422bd44d7eea719bf79b1b1205dd59d`.
The native contextual-loop implementation and tests are committed as
Ferrum `4b25645`; CeTA-CSR remains `73662ec88a74f65187cba6986d300836564b6a59`.
No CeTA changes were needed. Another finite discovery wave retries 128
unresolved external-order targets with three-second per-atom allowances, so
one slow order family cannot consume the entire root budget before later
families are attempted (`external-orders-fair-v3`).

That 128-root scheduling retry recovered zero roots. Event inspection exposed
a more important recipe defect: `pipeline(graph; orders; ...)` requires graph
decomposition to transform the state, so a single unchanged SCC never reaches
the order processors. The corrected discovery wave uses the existing recursive
portfolio `dp(graph; bounded-orders)` instead, without changing processor
semantics or skipping residual graph validation. `external-orders-recursive-v4`
already produces new native CeTA-certified proofs; these are not credited to
the oracle-only total until parameter-only export and strict replay finish.

Protection-check correction: the established 1,759-root reference used
`timeout(1200s, fail)`, not the 60/180-second limits used by the new checks.
Both the old and new frozen binaries miss Liveness6.4, thiemann14, and labelled
with the old oracle at 60 seconds (`diagnose-protected.log`). These observations
do not establish a new binary regression. Misses still require replay under
the reference limits before any global promotion; neither congestion nor
timing alone is assumed to explain them.

The corrected consolidated oracle passed a **605/605 retained SRS replay:
556 certified YES, 49 certified NO**, with fallback disabled and no exact
witnesses. Artifacts: `target/srs-native-20261013/srs-retained-605-v3` (complete
605-root details, runtime summary, all certificates independently rechecked
twice). The root cap was
180 seconds; **603 finished within 60 seconds**, while `ICFP_2010/214011`
took 67.290 seconds and `ICFP_2010/150468` took 83.542 seconds. This is a
retained-root replay, not a new full 1,931-input sweep. Oracle SHA256:
`00c9079c9eb9f52ee4934008d0e36c50855ebc88b5d3740dcd7be4f4f3c32a09`.
The same run continues with all 1,759 protected Standard/Innermost/CSR roots
under `unified-retained-v3`; global promotion awaits clean guards.

The external order-bound wave added 25/25 independently rechecked witness-free
YES replays; a second wave targets 319 previously untried external proofs.
The deeper generic nontermination portfolio added `Waldmann_06_SRS/uni-2`
beyond the 19 contextual-loop gains. Together these account for the increase
from 579 to 605, without supplying interpretation or loop witnesses.

Consolidating whole historical oracle snapshots initially preserved obsolete
action order: `ICFP_2010/85650` spent 185 seconds under old polynomial removal
despite a six-second certified match-bounds route. Consolidation now promotes
only the new independently checked hint shards; its corrected proof certifies.
The earlier 60-second cross-category guard had misses and was not promoted.
The corrected unified guard is the relevant follow-up, with all misses retained
for investigation rather than attributed to contention without evidence.

The completed October 13 waves give **535 distinct witness-free oracle-only
successes (506 YES, 29 NO)**: baseline 411; RFC +57; complementary ordinary
bounds +60; native default +4 distinct; empty-lhs nontermination +2; extended
`ICFP_2010/214011` replay +1 (64 seconds). Batch CPFs were rechecked twice,
except the separate extended retry, whose double check remains outstanding.

The new `broad-bounds-native-v3` wave adds **25/25 certified witness-free
replays**, each rechecked twice, giving a **560-root batch union**. Its oracle
is `target/srs-native-20261013/integrated-broad-bounds-native-v3/oracle.jsonl`.
These are new native bounds searches, not supplied automata.

Native contextual SRS-loop synthesis adds **19/19 certified NOs**, all strictly
replayed witness-free and rechecked twice (`word-loops-context-oracle-v2`).
This raises the batch union to **579 (531 YES, 48 NO)**. The generic search
constructs at most 256 overlap/concatenation seeds from live lhs/rhs words,
searches up to 64 rewrite steps with the existing frontier and word-length
limits, and independently validates each loop. No retained start term, rule
sequence, or substitution is supplied. Increasing depth without contextual
seeds recovered zero of these 239 targets; the contextual pass recovered 19
in four seconds, with maximum solved-root runtime 0.134 seconds. A two-second
branch is added to the SRS strategy. Unary SRSs that also match the transformed
CSR heuristic receive that probe before the inverse-transformation portfolio.
The native CSR and innermost dispatch remain unchanged. All 19 new NO roots
also pass the final default-strategy replay, each independently checked twice
(`context-default-final-v4`); the whole batch took 11 seconds.

Focused SRS loop tests pass. The broader nontermination run reported 137 passed
and one failure, `pattern_multiplication_guard_certifies`, which also failed
a single-test repeat after about 60 seconds during the concurrent campaign.
The same test passes in release mode (44.29 seconds), establishing that this
test's fixed search budget is sensitive to debug-build performance. Six focused
SRS-loop tests and 17 default-strategy tests pass. The broad release-mode
nontermination suite passes **139 tests, zero failures/ignored** in 49.71 seconds;
the failed debug suite is not represented as a passing full suite. No CeTA
changes were required.

A complete 1,931-input replay with the newly built bounds-fix binary finished
with **530 certified (502 YES, 28 NO)**, 1,393 unknowns and eight timeouts:
`target/srs-native-20261013/consolidated-full-v2`. It targets the preceding
535-root union, not the 25 subsequent additions. Five prior successes missed
the 60-second run: `Bouchare_06/09` exhausted a short local attempt, while
`ICFP_2010/{150468,211960,214011,85650}` hit root/local ceilings. They are being
retried with 180-second roots and enlarged local budgets; no loss is dismissed
as mere contention without the repeat. Full-category CPFs are being checked
twice. The exact frozen binary and source commit are recorded in
`push-20261014-v1/provenance.json`. Consolidated oracle SHA256:
`26e54b121f18c99339ce144dba08627f570d6dae268002401a1b45e5402fde62`.

Further finite waves target 239 externally claimed NOs and 256 externally
documented order proofs. The latter extracts only processor families and numeric
search bounds, never order assignments. The protected 1,759-root Standard,
Innermost and CSR guard is running as `protected-srs-push-20261014-v1`.
No CeTA source changes were made.

Latest completed recovery batch: `rfc-broad-oracle-v2` certifies **57/58**
new YESs, bringing the replayed batch union to **470 witness-free oracle-only
roots (441 YES, 29 NO)** including the two new NOs below. The sole miss is
`ICFP_2010/214011`, also the snapshot miss; its extended retry is running.
This is a batch union, not a full 470-root aggregate. Double checks are running.
Oracle SHA256: `443b5b7ba3348e702567b991680b653e6bb281398979e38a8174c1495409dc93`
(`integrated-rfc-broad-v2/oracle.jsonl`, zero forbidden actions).

The subsequent native-NO wave raises the individually replayed certified union
to **411 roots (384 YES, 27 NO)**: `nontermination-oracle-v1` certified 26/26
NO roots, 15 absent from the RFC union below. All 26 passed two independent
CeTA checks. This remains a union, not a completed full-category replay.
Candidate oracle: `target/srs-native-20261013/integrated-no-v1/oracle.jsonl`,
SHA256 `663d71f15e112945e934eace303628f873fc223ac2c86477778d888a5897aa36`;
its witness-free audit has zero forbidden actions.

A matched full 1,931-input measurement completed with the frozen
binary/checker below: `witness-enabled-full-v1`, then `witness-free-full-v1`.
The witness-free run certified **411 (384 YES, 27 NO)**, with 1,512 unknown
and eight timeouts. The witness-enabled run certified **405 (379 YES, 26 NO)**,
with 1,499 unknown and 27 timeouts. Both had zero uncertified decisions; all
retained certificates passed twice. Thus 411 is now a full-category replay,
not merely the earlier batch union. Witness-enabled guidance added no roots.
The six witness-enabled losses comprise four timeouts and two unknown results;
their causes are not yet established. Exact differences are recorded in
`target/srs-native-20261013/matched-comparison-v1.json`.
Both use 60-second proofs, 65-second harness ceilings, 32 workers, two Rayon
threads, and no fallback. The witness-enabled candidate merges retained
**modular** witnesses behind current native guidance; its audit finds 21,379
witness definitions and zero complete proof actions, malformed records, or
dangling references. Oracle SHA256:
`c20221ad0916f37329295c3d5bfb1236faba1d8e035b8ef3b8f1ecd1b97f68ba`.
Launcher and
log: `target/srs-native-20261013/measure-witnesses.{py,log}`. The follow-up
`after-measurement.py` records the exact comparison and attempts fresh native
RFC discovery on unresolved roots, then exports only twice-checked discoveries
and tests strict witness-free replay. These outputs remain campaign candidates.

The completed broad native RFC wave yielded **58 fresh certified YESs** from
1,520 unresolved roots, plus 1,342 unknowns and 120 timeouts, with no checker
failures (`rfc-broad-native-v2/details.json`). Its full integration is running.
The first frozen snapshot contains 54 of these, in
`rfc-snapshot-native-v3/details.json`. Their parameter-only
integration and strict replay completed as `rfc-snapshot-oracle-v4` with
**53/54 certified YES**. `ICFP_2010/214011` exhausted its 60-second local
allowance; an isolated 180-second oracle-only retry is running. Together with
the two new NOs, this establishes a batch union of **466 witness-free oracle-only
roots (437 YES, 29 NO)**. The 411-root full replay remains the latest complete
category run; 466 is not a new full aggregate. Snapshot oracle SHA256:
`a70d28a602dbcd2066a395e720bc5947e84d60c4105a3ce86cba5879e2852c94`.
Independent double-checks and the full 58-discovery replay are in progress.
A complementary ordinary match-bounds
wave, `bounds-complement-native-v1`, targets 506 completed RFC misses without
an oracle or supplied witnesses. Both use the unchanged production checker.
The v3 snapshot replay selected zero roots because per-root result records had
an empty category; it is invalid as a coverage measurement. V4 supplies the
category, and the replay helper now asserts exact input-set equality.

The complementary probe exposed two rejected ordinary bounds positives,
`Hofbauer_26/mnm4` and `mnm5`: empty left-hand sides bypassed the redex-height
obligation. Neither has certification or oracle credit. A conservative guard
now rejects these rules in completion and exact ordinary/relative validation;
all eight focused and all 39 bounds-filtered tests pass. The debug build succeeds
and live match-bounds attempts on both inputs now return UNKNOWN, not YES.
Native nontermination search gives **two certified NOs** on those same inputs
(`empty-lhs-no-native-v1/details.json`); parameter-only oracle integration and
strict replay passed **2/2**, each rechecked twice (`empty-lhs-no-oracle-v1`).
These and the 58 RFC additions give an individually
certified search union of **471 (442 YES, 29 NO)**, not yet an oracle-only total.
The running discovery jobs use the original
frozen binary and remain gated by production CeTA. No CeTA changes were made.
The bounds guard and structural regression are committed as `df5768c`.

First completed recovery wave: **396 certified oracle-only roots (384 YES,
12 NO), +220 over baseline**, with all 176 baseline successes preserved.
This is the union of `rfc-oracle-v1` (279/279 certified YES) and
`baseline-guard-rfc-v1` (176/176 certified), not a new full 1,931-input replay.
Manifest: `target/srs-native-20261013/rfc-certified-union.json`.
Both batches use `target/srs-native-20261013/integrated-rfc-v1/oracle.jsonl`,
SHA256 `aa89fda2c1e4eab93f427c24f5aa323e0a3a858c173f8f8cc28fb0e318f8e370`.
The witness-free audit reports zero forbidden actions/witnesses. All 176
guard certificates and all 279 RFC replay certificates were rechecked twice
(`rfc-wave.log`).

The RFC-enriched oracle passed the complete 1,759-root guard: **1,338 Standard
(1,039 YES, 299 NO), 311 Innermost (301 YES, ten NO), and 110 CSR (105 YES,
five NO)**. All certificates passed twice, with no missing roots, losses,
polarity changes, or uncertified decisions. Artifacts are under
`target/standard-nonloops-20261012/protected-srs-rfc-20261013-v1`, with adjacent
`-comparison.json` and `-rechecks.jsonl`. This guard predates the NO additions.
The previous frozen global oracle is untouched. No production source or CeTA
changed.

The complete current TPDB SRS Standard set contains **1,931 inputs** (not the
historical TermCOMP 2025 set of 1,921). A strict witness-free oracle-only run
at 60 seconds per root, 65-second harness, 32 workers and two Rayon threads
completed with **176 certified: 164 YES, 12 NO**, plus **1,741 MAYBE and 14
timeouts**. There were zero checker failures or errors. This is a baseline
for the current parameter-only oracle, not a statement of native search power.
All **176 retained certificates passed twice** (`baseline-v2/rechecks.jsonl`).
Of the unresolved roots, 1,465 record no substantive processor attempt,
276 exhausted guided actions or reached uncovered residuals, and 14 hit the
root timeout. These diagnostic classes do not establish missing processor
implementations (`baseline-gap-{inventory,summary}.json`).

Artifacts: `target/srs-native-20261013/baseline-v2/{summary.md,details.json,
provenance.json,inputs.txt,run/}`. Implementation:
`3c5d3d121783189abed2c3b4cf3092a35223f971`; frozen binary
`target/standard-nonloops-20261012/ferrum-q-rule-final-v49`. Oracle:
`target/standard-nonloops-20261012/integrated-all49-v354/oracle.jsonl`, SHA256
`2826e2cab67dbcbfdff4e0880c27ed8553be7f5200866957b6e630df144bd184`.
Production CeTA is unchanged at `73662ec88a74f65187cba6986d300836564b6a59`;
its executable hash is in the provenance record. Input-content hashing was
deferred after a cold-file kernel I/O stall; the complete path manifest is
frozen. The affected input subsequently completed normally. The abandoned
`baseline-v1` directory is preflight only, not a replay result.

Fresh native RFC discovery reproduced **279/279 archived certified YESs**
(`target/srs-native-20261013/rfc-native-v1`). These overlap the baseline on
59 roots. All discovery proofs passed twice before parameter-only event
export; strict root replay then established the 220 additions recorded above.
A separate 266-root native nontermination wave uses locally retained 2025
external NO claims only to select targets; those claims carry no Ferrum
certification credit. No production source or CeTA change was needed to
start these waves. Existing CSR/Innermost/Standard strategies are untouched.

## 2026-10-13 all 49 targeted Standard recoveries closed

Tested implementation commit: `3c5d3d121783189abed2c3b4cf3092a35223f971`.
The protected guard's **1,758/1,758 retained certificates passed twice**.
Library verification: **1,135 passed, zero failed/ignored**
(`q-rule-v326-library.log`); `git diff --check` passed.

All three remaining roots now have complete witness-free modular oracle-only
proofs accepted by production CeTA:

- `Transformed_CSR_04/LengthOfFiniteLists_nokinds_iGM`: about five seconds,
  `length-live-root-v281`.
- `AProVE_04/AAECC-ring`: about 12 seconds, `aaecc-qrule-root-v328`.
- `Transformed_CSR_04/MYNAT_complete_noand_iGM`: about 32 seconds,
  `mynat22-root-v353`.

This completes **49/49** targeted recoveries and gives an individual Standard
union of **1,338 (1,039 YES, 299 NO)**. This is not yet a completed 1,338-root
aggregate. The current-source 1,758-root cross-category guard
`protected-final-v332` completed with **1,337 Standard (1,038 YES, 299 NO),
311 Innermost (301 YES, ten NO), and 110 CSR (105 YES, five NO)**, with zero
losses, missing inputs, polarity changes, or uncertified decisions. It uses
`integrated-final-three-v329/oracle.jsonl`, SHA256
`508d3b64f30f7056a2e548791c6ff9d090f57e89caa13be505c1ed2056b4c7c2`,
predating MYNAT's final integration. Exact comparison:
`protected-final-v332-comparison.json`; certificate rechecks:
`protected-final-v332-rechecks.jsonl`.

MYNAT required uniform-status LPO/RPO synthesis and explicit closure of live
residuals whose pair ordering differed from the historical local chain.
Certified local closures are retained in `mynat-current-long-v324`,
`mynat-live{48,56,44,29,22}-close-v{335,337,343,347,351}`. No interpretation
witness is supplied to search. Final integration: `integrated-all49-v354`;
three-root repeat: `final-three-v355` (**3/3 certified**, each rechecked twice;
5.673s Length, 13.418s AAECC-ring, 31.971s MYNAT). Final oracle SHA256:
`2826e2cab67dbcbfdff4e0880c27ed8553be7f5200866957b6e630df144bd184`.
`witness-free-v354-audit.json` checks 560,130 states and 1,607,813 actions:
**zero forbidden actions or witnesses**. Artifacts are under
`target/standard-nonloops-20261012/`. Frozen binary is
`ferrum-q-rule-final-v49`; production CeTA remains unchanged at
`73662ec88a74f65187cba6986d300836564b6a59`.

## 2026-10-13 individual recovery: AAECC-ring

`AAECC-ring` now has a complete witness-free modular oracle-only proof:
`aaecc-qrule-root-v328`, about 12 seconds, production CeTA certified and
independently rechecked twice by `integrated-final-three-v329`. This brings
the individual Standard union to **1,337**, targeted recovery **48/49**.
MYNAT's current local residual also certifies twice (`mynat-current-long-v324`),
but its complete root replay is still pending; it is not included in that count.

The generic changes expose bounded conditional-induction shapes and selected
Q-monotonic matrix rule removal. Interpretations are synthesized, not supplied.
Frozen binary: `ferrum-q-rule-final-v49`; full library suite:
**1,135 passed, zero failed/ignored** (`q-rule-v326-library.log`). CeTA is
unchanged. Paths are under `target/standard-nonloops-20261012/`.

Experimental aggregate runs `protected-length-v288` and `protected-stable-v310`
are not clean guards: globally changed arithmetic encodings altered model
selection. The current implementation preserves the established automatic
queries and scopes finite-coefficient encoding to explicit induction choices.
Their intermediate counts must not replace the last complete certified
aggregate below. Current-source targeted recovery and a new aggregate guard
are required before committing.

## 2026-10-13 individual recovery: LengthOfFiniteLists_nokinds_iGM

Full witness-free modular oracle-only replay now certifies this root in about
five seconds (`length-live-root-v281`). Its CPF was independently rechecked
twice during `integrated-length-root-v283`. This brings the targeted recovery
to **47/49**, an individual Standard union of **1,336**; AAECC-ring and
MYNAT_complete_noand_iGM remain unresolved. This is not yet a completed
1,336-root aggregate.

Native SAT synthesis jointly infers the constants of a conjunctive Boolean
labeling from rule equations; no supplied labeling is used. The live five-pair
states needed their own local proofs (`length-lean-label-v275`) because their
active-rule contexts differ from the historical local state. Frozen root
binary: `ferrum-induction-v41`. All paths are below
`target/standard-nonloops-20261012/`; CeTA remains unchanged at
`73662ec88a74f65187cba6986d300836564b6a59`.

The preceding `protected-z30-v247` guard completed: **1,334 Standard, 311
Innermost, 110 CSR**, all 1,755 certificates checked twice, no exact-set losses
or polarity changes (`protected-z30-v247-{comparison.json,rechecks.jsonl}`).
Its frozen `ferrum-bidirectional-v37` predates the newer rule-split, labeling,
and arithmetic-encoding changes; it is not their regression guard. The newer
1,757-root guard is `protected-length-v288`, still in progress. The new source
passes **1,135 library tests, zero failed/ignored** (`linear-v286-library.log`).

## 2026-10-13 individual recoveries: z30 and Secret_07_TRS/4

Two further roots have complete, production-CeTA-certified, witness-free
oracle-only proofs. This is **46/49** targeted recoveries and an individual
Standard union of **1,335**, not yet a completed 1,335-root aggregate.

- `Zantema_05/z30`: native search 0.78 seconds, strict oracle replay 4.714
  seconds. Bidirectional match-bounds path reuse discovers a bound-five
  automaton without a supplied witness.
- `Secret_07_TRS/4`: strict oracle replay 5.025 seconds. Native split search
  now includes ordinary-rule splits, formerly available only through exact
  replay. Both resulting obligations remain explicit and independently guided.

Artifacts under `target/standard-nonloops-20261012/`:
`z30-native-v242`, `z30-oracle-v244`, `secret4-rule-split-v258`, and
`integrated-secret4-v259`. The frozen implementation is `ferrum-rule-split-v38`;
CeTA is unchanged at `73662ec88a74f65187cba6986d300836564b6a59`.
`rule-split-v256-library.log`: **1,132 passed, zero failed, zero ignored**.
The 1,755-root intermediate guard `protected-z30-v247` is still running with
the preceding match-bounds build. Do not treat that run as a completed guard
for the newer rule-split build. The remaining roots are AAECC-ring,
LengthOfFiniteLists_nokinds_iGM, and MYNAT_complete_noand_iGM.

## 2026-10-13 complete split-conditional aggregate: 1,333 witness-free Standard roots

Complete modular witness-free oracle-only replay: **1,333 Standard (1,034 YES,
299 NO), 311 Innermost (301 YES, ten NO), and 110 CSR (105 YES, five NO)**.
All **1,754 proofs certify twice**, with no missing inputs, losses, polarity
changes, or uncertified decisions. Implementation commit:
`7c6eba4da4a6da807634f9404c891b13ceedc691`; frozen binary:
`target/standard-nonloops-20261012/ferrum-conditional-split-v35`.
CeTA-CSR is unchanged at `73662ec88a74f65187cba6986d300836564b6a59`.

Artifacts below `target/standard-nonloops-20261012/`:
`protected-aprove10-v221/{details.json,summary.md,run/}`,
`protected-aprove10-v221-comparison.json`, and
`protected-aprove10-v221-rechecks.jsonl`. Oracle:
`integrated-aprove10-root-v212/oracle.jsonl`, SHA256
`24fa549ee3bef1a7c1ad816091b03d1c72248d7a6b37b97202eb7fc7d108173e`.
`witness-free-v212-audit.json` reports zero forbidden actions/witnesses.
The targeted recovery remains **44/49**; the five unresolved roots are listed
in `remaining5-v212.json`. Later local probes are not additional root gains.

## 2026-10-13 complete conditional-induction aggregate: 1,332 witness-free Standard roots

Later individual recovery, pending complete aggregate: `Secret_07_TRS/aprove10`
now certifies witness-free and oracle-only in approximately 10 seconds
(`aprove10-root-v219`). This makes **44/49** targeted recoveries. Native
conditional synthesis independently chooses strict and bounded pair sets and
reconstructs both necessary child proofs; it also tries the opposite induction
order with constructor producers retained. No supplied interpretation is used,
and CeTA is unchanged. The local fixture is
`tests/fixtures/conditional_split_bound.dp.xml`; its test checks both residual
proofs and rejects missing conditional obligations.

The measured binary is `ferrum-conditional-split-v35`; the monotone oracle is
`integrated-aprove10-root-v212/oracle.jsonl` (paths under the artifact base
below). `conditional-split-v35-library.log` reports **1,127 passed, zero failed,
zero ignored**, and `conditional-guards-v219` certifies all eight guard roots.
The initial v33/v34 search changed `cade15`'s model/continuation; v35 preserves
the old merged query exactly and restores its certified replay. The superseded
v213 aggregate was stopped, not counted. Corrected aggregate
`protected-aprove10-v221` and its double rechecks subsequently completed;
see the newer aggregate above.

`remaining5-v212.json` lists AAECC-ring, Secret_07_TRS/4,
LengthOfFiniteLists_nokinds_iGM, MYNAT_complete_noand_iGM, and z30.

Complete modular witness-free oracle-only replay: **1,332 Standard (1,033 YES,
299 NO), 311 Innermost (301 YES, ten NO), and 110 CSR (105 YES, five NO)**.
All **1,753 roots certify twice**, with zero exact-set losses or polarity changes.
`GTSSK07/cade15` passes witness-free modular oracle-only replay and production
CeTA certification in about 16 seconds (`cade15-root-v191` under the artifact
base below). This makes **43/49** targeted recoveries. Native conditional
polynomial search now tries data-flow-selected induction conjuncts and permits
same-predicate induction when the selected conjunction has strictly fewer
premises. It synthesizes the order, not a retained witness. The four-pair local
proof (`cade15-stronger-induction-v189`) also independently certifies.
CeTA is unchanged at `73662ec88a74f65187cba6986d300836564b6a59`. Under
`target/standard-nonloops-20261012/`, frozen binary
`ferrum-conditional-dataflow-v32` and oracle
`integrated-cade15-root-v193/oracle.jsonl` produced `protected-cade15-v194`.
The oracle SHA256 is
`8998a5375ca410e525ebec5e37cfca746a74c2fa481518541d543dbf33abc05d`;
`witness-free-v193-audit.json` reports zero forbidden actions/witnesses.
Exact comparison and repeated checks are in
`protected-cade15-v194-comparison.json` and
`protected-cade15-v194-rechecks.jsonl`. The eight-root conditional guard also
certifies completely (`conditional-guards-v192`). Implementation commit is
recorded by the commit introducing this ledger entry and the conditional
search changes; the frozen binary identifies the measured build exactly.

Tests: 1,125 pass, one fails, none ignored in the two-worker library run.
`pattern_multiplication_guard_certifies` reaches its 60-second search deadline
and also fails in isolation (`multiplication-isolated-v195b.log`); this is not
a clean full-suite claim. Both new data-flow tests and conditional CeTA tests
pass. Remaining six roots are listed in `remaining6-v195.json`.

## 2026-10-13 complete residual-closure aggregate: 1,331 witness-free Standard roots

Complete modular, witness-free oracle-only replay: **1,331 Standard (1,032 YES,
299 NO), 311 Innermost (301 YES, ten NO), and 110 CSR (105 YES, five NO)**.
All **1,752 distinct roots** passed two additional production CeTA checks.
Exact-set comparison reports zero losses, missing roots, polarity changes,
or uncertified decisions. **42/49** targeted YES gaps are recovered.

Ferrum implementation remains **`a1d19de`**, frozen binary
`target/standard-nonloops-20261012/ferrum-q-local-map-v31`, SHA256
`ffe5426804447354b13f5d1c8fe922ecf01b7d7c81d89d3f0334235b5ce01981`.
CeTA-CSR is unchanged on main `73662ec88a74f65187cba6986d300836564b6a59`,
binary SHA256 `64597fcb0a8c1c09af1de0816283c66f474783df3010fc3e60ca30731f5090b7`.

Artifacts under `target/standard-nonloops-20261012/`:

- `protected-aprove01-v178/{details.json,summary.md,run/}`,
  `guard-reference-v178.json`, `protected-aprove01-v178-comparison.json`,
  and `protected-aprove01-v178-rechecks.jsonl`.
- `integrated-aprove01-v177/oracle.jsonl`: 559,638 states, 1,607,281 actions;
  SHA256 `1b069882e712bfa2bd299ddcb57a8d9417c2f84240ea42c2c3ad7eaac9769142`.
  `witness-free-v177-audit.json` reports zero forbidden witnesses/actions.
- `remaining7-v177.json`: AAECC-ring, cade15, Secret_07_TRS/4, aprove10,
  LengthOfFiniteLists_nokinds_iGM, MYNAT_complete_noand_iGM, and z30.

This supersedes the earlier 1,330-root aggregate below. The older eight-root
discovery `remaining-qmap-v167` had no gains; its `aprove01` miss is superseded
by the later integrated residual evidence and this complete replay.
Replay ceilings remain 1,200/1,205 seconds, not competition-cap totals.

## 2026-10-13 rule-specific Q orders: 1,330 witness-free Standard roots

Complete modular, witness-free oracle-only replay: **1,330 Standard (1,031 YES,
299 NO), 311 Innermost (301 YES, ten NO), and 110 CSR (105 YES, five NO)**.
All **1,751 distinct roots** passed two additional production CeTA checks.
Exact-set comparison reports zero losses, missing roots, polarity changes,
or uncertified decisions. This aggregate recovers **41/49** targeted YES gaps.
The later full-root `Secret_07_TRS/aprove01` replay brings individual coverage
to **42/49** (1,331 Standard), but is not included in this frozen aggregate.

Ferrum implementation commit: **`a1d19de`**. CeTA-CSR remains unchanged on main
`73662ec88a74f65187cba6986d300836564b6a59`, binary SHA256
`64597fcb0a8c1c09af1de0816283c66f474783df3010fc3e60ca30731f5090b7`.
Artifacts under `target/standard-nonloops-20261012/`:

- `protected-qmap-v166/{details.json,summary.md,run/}`,
  `guard-reference-v166.json`, `protected-qmap-v166-comparison.json`,
  and `protected-qmap-v166-rechecks.jsonl`.
- Frozen binary `ferrum-q-local-map-v31`, SHA256
  `ffe5426804447354b13f5d1c8fe922ecf01b7d7c81d89d3f0334235b5ce01981`.
- `integrated-aprove02-v165/oracle.jsonl`: 559,579 states, 1,607,215 actions,
  SHA256 `53abe799ef558daa6f7fa132b392030563578a8dc74d4e52eefae6eea55e38e4`.
  `witness-free-v165-audit.json` reports zero forbidden actions/witnesses.
- `q-local-map-v31-final-library.log`: **1,124 passed, zero failed/ignored**.
  `qmap-export-v169-tests.log`: **39 Python tests passed**.
  `qmap-mutation-v174.json`: two positive checks and a broken-order rejection.
- `aprove02-qmap-root-v164`: full root certified in **4.882 seconds**.
- `aprove01-live-root-v176`: later full root certified in **36.393 seconds**.
  Its twice-rechecked modular evidence is in `integrated-aprove01-v177`, oracle
  SHA256 `1b069882e712bfa2bd299ddcb57a8d9417c2f84240ea42c2c3ad7eaac9769142`.
  `witness-free-v177-audit.json`: 559,638 states, 1,607,281 actions, zero forbidden.
- `remaining7-v177.json` records the seven unresolved targets. The newer
  1,752-root guard `protected-aprove01-v178` was still running when this entry
  was written; do not treat it as a completed aggregate without its results.

The matrix fallback now uses a conservative rule-specific usable replacement
map and deletes only the rule whose monotonicity obligations were synthesized.
Ordinary graph estimation and CSR strategy are unchanged. Evidence conversion
preserves Q-monotonic affine rule removal via dimension-one matrix search.
No supplied orders or benchmark-specific production code were introduced.
Replay ceilings remain 1,200/1,205 seconds, not competition-cap totals.

## 2026-10-13 verified z12 aggregate: 1,329 witness-free Standard roots

Complete modular, witness-free oracle-only replay: **1,329 Standard (1,030 YES,
299 NO), 311 Innermost (301 YES, ten NO), and 110 CSR (105 YES, five NO)**.
All **1,750 distinct roots** passed two additional production CeTA checks.
Exact-set comparison has no losses, missing roots, polarity changes, or
uncertified decisions. **40/49** targeted YES gaps are recovered; nine remain
in `target/standard-nonloops-20261012/remaining9-v153.json`.

Ferrum implementation commit: **`3e4aded`**. CeTA-CSR remains unchanged on main
`73662ec88a74f65187cba6986d300836564b6a59`, binary SHA256
`64597fcb0a8c1c09af1de0816283c66f474783df3010fc3e60ca30731f5090b7`.
Artifacts under `target/standard-nonloops-20261012/`:

- `protected-conditional-v160/{details.json,summary.md,run/}`,
  `guard-reference-v160.json`, `protected-conditional-v160-comparison.json`,
  and `protected-conditional-v160-rechecks.jsonl`.
- Frozen binary `ferrum-conditional-normalization-v30`, SHA256
  `16f02739b0d64b133672bd19b2b387b6aa5d6cd62b70d019500a597da7549576`.
- `integrated-z12-v153/oracle.jsonl`: 559,566 states, 1,607,196 actions,
  SHA256 `9e6ae011f17a5a015cd6640909dc8264f0dd8fd07f1eae1b2f9f92a1d85d7313`.
  `witness-free-v153-audit.json` reports zero forbidden actions/witnesses.
- `conditional-normalization-v30-library-4threads.log`: **1,122 passed,
  zero failed or ignored**. The earlier parallel run had a timing-sensitive
  multiplication-guard failure; its isolated repeat and this full run passed.

Constructor contradictions now close before structural-budget exhaustion,
while respecting deadlines and defined-symbol restrictions. All seven existing
conditional guard roots remain certified. Replay ceilings remain 1,200/1,205
seconds; these are not competition-cap totals. No CeTA changes were needed.

## 2026-10-13 modular Q/SCT recovery: 1,328 witness-free Standard roots

Complete oracle-only replay: **1,328 Standard (1,029 YES, 299 NO),
311 Innermost (301 YES, ten NO), and 110 CSR (105 YES, five NO)**.
All **1,749** roots certified and passed two additional production CeTA checks.
Exact-set comparison reports zero losses, missing inputs, polarity changes,
or uncertified decisions. This aggregate recovers **39/49** targeted YES gaps.
The subsequent individual `Zantema_05/z12` recovery brings the individual
count to **40/49**; it is not included in this frozen aggregate.

Ferrum implementation commit: **`7c5514f`**. Frozen binary
`target/standard-nonloops-20261012/ferrum-q-iedg-sct-v29`, SHA256
`db985bcd1513226aa14cb49a2c53c7e1edfee07ebe25c60900a9abf18bb408a9`.
CeTA-CSR is unchanged on main
`73662ec88a74f65187cba6986d300836564b6a59`, binary SHA256
`64597fcb0a8c1c09af1de0816283c66f474783df3010fc3e60ca30731f5090b7`.

Artifacts under `target/standard-nonloops-20261012/`:

- `protected-iedg-sct-v145/{details.json,summary.md,run/}`,
  `guard-reference-v145.json`, `protected-iedg-sct-v145-comparison.json`,
  and `protected-iedg-sct-v145-rechecks.jsonl`.
- `integrated-double-v142/oracle.jsonl`: 559,565 states, 1,607,193 actions,
  SHA256 `b778d8c6b9a5284a7bd3ba99af125f1472fd05aa3eea371d7be56cd185dc32a5`.
  `witness-free-v142-audit.json`: zero exact witnesses, composite actions,
  pipelines, or unresolved witness references.
- `q-iedg-sct-v29-library-tests.log`: **1,121 passed**, zero failures/ignored.
  `modular-v153-python-tests.log`: **58 passed**.
- `double-root-v141`: certified YES in 3.733 seconds; `integrated-double-v142`
  retains the independently rechecked modular actions.
- `remaining-iedg-sct-v144`: `z12` certified in 111.015 seconds;
  `integrated-z12-v153` retains its twice-rechecked full proof's modular actions.
  `source-sct-roots-v156` repeats this gain in 108.666 seconds.
- `remaining9-v153.json`: the nine remaining targeted roots. All 49 are
  **not** recovered. `source-sct-native-v151` certifies 51 local terminal
  states across eight roots; local states do not count as root recoveries.

Native Q-aware SCT now uses the IEDG premise checked by CeTA instead of the
generic closure cache that deliberately ignores graph-decomposition edges.
SCT's pair-local usable-rule refinement stays separate from decomposition's
TCAP/gtcap filters. The stronger graph estimator is the explicit
`graph-refined` processor; existing `graph` and CSR behavior remain intact.
Canonical lookup admits unselected native transformation searches, not
presentation-dependent candidate ordinals. Inferred signature bounds are
repaired from complete typed inputs without changing recorded native bounds.

The rejected global graph-refinement experiment (`v23`, `v108`) is **not**
the promoted implementation. `cade14`'s alternate conditional residuals are
covered by `integrated-cade14-v133`; its earlier miss is not silently ignored.
Replay ceilings are 1,200/1,205 seconds, not a competition-cap claim.

## 2026-10-13 constructor-max recovery: 1,318 witness-free Standard roots

Complete oracle-only replay: **1,318 Standard (1,019 YES, 299 NO),
311 Innermost (301 YES, ten NO), and 110 CSR (105 YES, five NO)**.
All **1,739** roots certified and passed two additional CeTA checks.
Exact-set comparison reports zero losses, missing inputs, polarity changes,
or uncertified decisions. This aggregate recovers **29/49** targeted YES gaps.
Later individual recoveries kabasci01, t009, and Beerendonk_07/17 bring the
individual total to **32/49**, but are not part of this aggregate.

Ferrum implementation commit: **`491052d`**. Frozen binary
`target/standard-nonloops-20261012/ferrum-constructor-max-v21`, SHA256
`2077e2047e95903cb448c7742888a1f6b7cb666f4653af7f737333a3b6983bce`.
CeTA-CSR remains unchanged on main
`73662ec88a74f65187cba6986d300836564b6a59`, binary SHA256
`64597fcb0a8c1c09af1de0816283c66f474783df3010fc3e60ca30731f5090b7`.

Artifacts under `target/standard-nonloops-20261012/`:

- `protected-constructor-max-v75/{details.json,summary.md,run/}`;
  `guard-reference-v75.json`, `protected-constructor-max-v75-comparison.json`,
  and `protected-constructor-max-v75-rechecks.jsonl`.
- `integrated-cime1-v74/oracle.jsonl`: 559,211 states, 1,606,187 actions,
  SHA256 `2bf05d1c6790bf7d3419673811a1d3959300d0650bf438329ec232c1c3051763`.
  `witness-free-v74-audit.json`: zero forbidden exact witnesses, composite
  actions, pipelines or unresolved references.
- `constructor-max-v21-library-tests.log`: **1,117 passed**, zero
  failures/ignored. Python helper validation: 59 passed.
- `remaining17-v92.json`: remaining individual gaps, not aggregate misses.

The checked source adds native narrowing/rewriting candidate backtracking,
state-local transformation-depth independence, the WPO lexicographic
correction, and bounded constructor-max synthesis. No benchmark-specific
production code, supplied orders, or CeTA extension was introduced.
Later canonical-Q lookup work is separate and remains uncommitted pending
its own preservation replay. Ceilings remain 1,200/1,205 seconds, not a
competition-cap performance claim.

## 2026-10-13 native narrowing recovery: 1,316 witness-free Standard roots

Complete oracle-only replay: **1,316 Standard (1,017 YES, 299 NO),
311 Innermost (301 YES, ten NO), and 110 CSR (105 YES, five NO)**.
All 1,737 inputs certified, with zero missing inputs, losses, polarity
changes or uncertified decisions. All certificates passed two further
production CeTA checks. This aggregate recovers **27/49** targeted YES gaps.
AAECC, cime1, and kabasci01 are additional individually certified recoveries,
not part of this run. Thus 30/49 are individually recovered, with 19 remaining.
The 1,317-root v71 and 1,318-root v75 candidate replays are still pending;
the latter does not yet include kabasci01.

Artifacts under `target/standard-nonloops-20261012/`:

- `protected-narrowing-v62/{details.json,summary.md,run/}`;
  `guard-reference-v58.json`, `protected-narrowing-v62-comparison.json`,
  and `protected-narrowing-v62-rechecks.jsonl`.
- Frozen binary `ferrum-native-narrowing-v19`, SHA256
  `48bcaba0f56b9f7cf17f00806831dab5f994952608630bda755ee794cae3d228`.
- `integrated-wpo-tight-v61/oracle.jsonl`, SHA256
  `9901c7dd3c43efe23b1ef20315139e368cd7f5484b3fd9ee021ce0e6fd324f4a`;
  559,158 states, 1,606,117 actions; `witness-free-v61-audit.json`
  records zero forbidden witnesses, composite proofs, pipelines or references.
- `native-narrowing-v19-library-tests.log`: 1,115 passed, zero failed/ignored.
  The Python helper suites passed 59 tests.

Source provenance: implementation base `b553b37`, with the uncommitted WPO
lexicographic correction and native narrowing/backtracking changes documented
in the reproducibility log. **This frozen result is verified but not yet a
committed release**; newer rewriting/max-polynomial work remains under test.
Do not substitute an older committed total for this measured high-water mark,
or claim the newer source has passed this replay. CeTA-CSR is unchanged on main
`73662ec88a74f65187cba6986d300836564b6a59`, binary SHA256
`64597fcb0a8c1c09af1de0816283c66f474783df3010fc3e60ca30731f5090b7`.
The 1,200/1,205-second ceilings establish replayability, not competition-cap
performance. Remaining individual gaps are listed in `remaining19-v78.json`.

## 2026-10-13 conditional/WPO recovery: 1,310 witness-free Standard roots

The complete protected oracle-only replay certifies **1,310/1,338 Standard
roots: 1,011 YES and 299 NO**, preserving **311/311 Innermost** (301 YES,
10 NO) and **110/110 CSR** (105 YES, five NO). All **1,731** roots certified
on the first pass. Exact-set comparison reports zero missing inputs, losses,
polarity changes or uncertified decisions. Every certificate passed two
additional production CeTA checks.

Ferrum implementation commit: **`b553b37`**. Frozen binary:
`target/standard-nonloops-20261012/ferrum-discovery-fairness-v13`, SHA256
`c31a769150eb36a1c77b3a8cf8735d83736e4820614ad5656516e687b526c146`.
CeTA-CSR is unchanged on main `73662ec88a74f65187cba6986d300836564b6a59`,
binary SHA256 `64597fcb0a8c1c09af1de0816283c66f474783df3010fc3e60ca30731f5090b7`.

Artifacts under `target/standard-nonloops-20261012/`:

- `protected-final-candidate-v31/{details.json,summary.md,run/}`;
  32 workers, two Rayon threads, 1,200/1,205-second ceilings, no fallback.
- `guard-reference-v24.json`,
  `protected-final-candidate-v31-comparison.json`,
  `protected-final-candidate-v31-rechecks.jsonl`.
- `integrated-wpo-frontier-v22/oracle.jsonl`: 558,851 states, 1,605,733
  actions, SHA256
  `0e010316091a37a21b4f37bd4a8bed32c41cbcb618d3b110773096920441b004`.
- `witness-free-v22-audit.json`: zero forbidden exact witnesses, composite
  proofs, pipelines or unresolved references.
- `discovery-fairness-v13-library-tests.log`: **1,111 passed**, zero
  failures/ignored; 46 Python helper tests also pass.
- `conditional-guards-v28/` and its comparison/recheck files: all 53 affected
  roots certified and checked twice again.

An earlier candidate lost two roots after a mathematically equivalent WPO
encoding change. The compact-ground encoding is now opt-in for legacy
statuses; both losses are recovered in this complete run. New arbitrary
partial lexicographic statuses are synthesized jointly, not supplied or
enumerated. Conditional derivations retain existing successful proof shapes
before trying additional ones. The optional discovery branch-attempt budget
is **unset** in all protected replays. No CeTA or Isabelle changes were needed.

This aggregate recovers **21 of the original 49 YES-reference gaps**.
Three later individual gains, `Secret_07_TRS/aprove08`,
`AProVE_07/thiemann37`, and `OvConsOS_complete_noand_iGM`, also pass certified
oracle-only replay and two further CeTA checks (`live-frontier-root-v32/`,
`late-frontier-root-v36/`), but are **not yet included in this complete
aggregate**. Thus 28 gaps remain in the aggregate manifest and 25 remain
after these individual recoveries (`remaining25-v36.json`). The expanded
1,313 Standard + 311 Innermost + 110 CSR replay is `protected-expanded-v37/`.
Do not report it as complete until it has actually finished. The
generous ceilings establish replayability, not competition-cap performance.

## 2026-10-12 rational usable-rule matching: 1,294 witness-free Standard roots

The full protected oracle-only replay certifies **1,294/1,338 Standard roots:
995 YES and 299 NO**, with **311/311 Innermost** and **110/110 CSR** preserved.
All **1,715** inputs certified on the first pass, with no missing inputs,
losses, polarity changes or uncertified decisions. Every retained certificate
passed two additional production CeTA checks. **44 YES-reference gaps remain
in this aggregate run**; later individually recovered roots are not yet part
of this aggregate baseline.

Ferrum commit: `227eb95` (rational-only per-rule usable-rule synthesis).
CeTA-CSR remains unchanged on main `73662ec88a74f65187cba6986d300836564b6a59`,
binary SHA256 `64597fcb0a8c1c09af1de0816283c66f474783df3010fc3e60ca30731f5090b7`.
Frozen Ferrum: `target/standard-nonloops-20261012/ferrum-rule-aware-v3`, SHA256
`30e0ed9f31b239c6261951af96612244e2cf0671ff0bbfe0304c7bec747614c5`.

Artifacts under `target/standard-nonloops-20261012/`:

- `protected-refresh-v7/{details.json,summary.md,run/}`: full replay,
  32 workers, Rayon two, 1,200/1,205-second prover/harness ceilings.
- `guard-reference-v7.json`, `protected-refresh-v7-comparison.json`,
  `protected-refresh-v7-rechecks.jsonl`: exact root set and double rechecks.
- `parameter-refresh-v7.jsonl`: 558,693 states, 1,605,359 actions, SHA256
  `661794cfc3ab848bea59797f33d4f56ee7a47ddc1880c79aa9842c417323dc20`.
- `modular-refresh-v7-audit.json`, `witness-free-refresh-v7-audit.json`:
  no exact witnesses, composite proofs, pipelines or unresolved references.
- `rule-aware-v3-library-tests.log`: **1,104 passed**, zero failures/ignored.

The five aggregate gains are `AProVE_06/identity`, `Applicative_05/Ex9Maps`,
and transformed-CSR `ExIntrod_GM04_C`, `Ex3_12_Luc96a_C`, `Ex4_7_56_Bor03_C`.
Changed synthesized models exposed new residuals; those were independently
closed and integrated before this replay. No supplied interpretation was
restored. This is a generous-ceiling recovery measurement, not a 60-second
competition-cap claim. No CeTA changes or Isabelle builds were needed.

## 2026-10-12 constructor recurrence: 1,289 witness-free Standard roots

The full protected oracle-only replay certifies **1,289/1,338 Standard roots:
990 YES and all 299 NO**. **Innermost 311/311** (301 YES, ten NO) and
**CSR 110/110** (105 YES, five NO) are preserved. All **1,710** roots passed
on the first attempt, including `GTSSK07/cade14`; all retained certificates
passed two additional production CeTA checks. Exact-root comparisons report
no losses, missing inputs, polarity changes or uncertified promotions.

The two new NOs are `Zantema_15/ex14` and `payet_21/payet-nonloop-1`.
`nontermination(constructor-recurrence)` synthesizes a closed, normal-form-free
constructor language from live rules, rather than matching retained rule
templates or supplying automata. The `cade14` repair adds native guidance for
two independently certified residuals. Guidance remains modular and
witness-free. **49 YES-reference gaps remain in this aggregate baseline**;
subsequent individual recoveries must still undergo protected replay before
being incorporated into this baseline.

Ferrum implementation commit: `437e944`. CeTA-CSR is unchanged on main
`73662ec88a74f65187cba6986d300836564b6a59`; binary SHA256
`64597fcb0a8c1c09af1de0816283c66f474783df3010fc3e60ca30731f5090b7`.
The frozen Ferrum binary is
`target/standard-nonloops-20261012/ferrum-constructor-recurrence-v1`, SHA256
`204ea3b98891015a838d55affe3644c50ebd703cde461c50cb26c99a645146a0`.

Artifacts under `target/standard-nonloops-20261012/`:

- `recurrence-protected-v1/{details.json,summary.md,run/}`: complete first-pass
  category replay, 32 workers, Rayon two, 1,200/1,205-second ceilings.
- `constructor-recurrence-v1/{guard-reference.json,guard-comparison.json,guard-rechecks.jsonl}`:
  exact root-set comparison and duplicate independent certification.
- `constructor-recurrence-v1/oracle.jsonl`: 558,365 states, SHA256
  `58de6fee896ef72d52fe0148546a6cdcc550e761a8731af4ef1179db8ff87878`.
- `recurrence-oracle-only-v1/`: focused replay of both new NO roots.
- `cade14-frontier-refresh/` and `cade14-repair-replay1/`: residual recovery
  and full certified replay.

Verification: 1,103 release library tests and 22 exploration-helper tests
passed. No CeTA or Isabelle builds were required. Memory stayed below 2 TiB
excluding reclaimable file cache.

## 2026-10-12 all retained pattern nonloops: 1,287 witness-free Standard roots

**All 25 remaining pattern-nonloop gaps are closed: 43/43 retained nonloop
roots now replay with modular, witness-free oracle guidance and no fallback.**
Standard increases to **1,287/1,338 retained roots: 990 YES and 297 NO**.
**Innermost 311/311 (301 YES, ten NO)** and **CSR 110/110 (105 YES, five NO)**
remain certified with the same final binary and monotone oracle. All 1,708
retained certificates passed two additional production CeTA checks. Exact
root-set comparisons show no missing roots, polarity changes or uncertified
promotions. The remaining Standard frontier is **51 roots: 49 YES-reference
roots and two other NOs**, with no remaining gaps in this pattern inventory.

The Standard first pass certified **1,286/1,287**. `GTSSK07/cade14` returned
Unknown in 13.439 seconds after conditional polynomial synthesis reached an
uncovered residual. A separately recorded repeat with the **same binary,
oracle and ceilings** certified in **10.818 seconds**, following the known
continuation. Both attempts are retained; this is not a flawless single-pass
or competition-cap score. All **25 new roots certified on the first pass**,
with reported runtimes **3.971–49.020 seconds**, median **4.485 seconds**.
The protected run used 64 workers, two Rayon threads each and 1,200/1,205-second
prover/harness ceilings. Innermost and CSR needed no repeats.

Ferrum implementation: `0db5c7cf7d472efa0673a3e1f6a27c8d9e149403`.
CeTA-CSR is unchanged on main `73662ec88a74f65187cba6986d300836564b6a59`;
executable SHA256
`64597fcb0a8c1c09af1de0816283c66f474783df3010fc3e60ca30731f5090b7`.
No CeTA source changes or Isabelle builds were required.

Artifact base: `target/standard-nonloops-20261012/`:

- `consolidated-complete-final/{details.json,attempts.json}`: all 1,708 retained
  results, including explicit retry provenance. `all-complete-final/` and
  `repeat-complete-final/` preserve the original attempts.
- `all-comparison-complete-final.json`, category-specific comparisons and
  `all-complete-final-rechecks.jsonl`: exact-set checks and duplicate CeTA runs.
- `final-summary-complete.json`, `final-gaps-complete.json` and
  `remaining-nonloops-complete.json`: totals, the 51-root frontier and the empty
  remaining pattern-nonloop set.
- `parameter-complete-final.jsonl`: **558,363 states, 1,604,985 actions**, SHA256
  `f9e1ff39fb35757c23f59831993779ad89aa884d44341582530f8eff7b64eeae`.
  The `witness-free-complete-final-audit.json` and
  `modular-complete-final-audit.json` report zero exact witnesses, composite
  proof actions, unresolved references, pipelines or malformed records.
- Frozen `ferrum-complete-v22`, SHA256
  `1203955b9f99e458704ba4d8681c4f5acd333266a6a3593eb4f9aa11ac038be7`.
- `terminal-complete-v22.json`: **43/43 native terminals**, each checked twice.
  `discovery-complete-v20.json` records **43/43 native full-root discoveries**;
  the final binary's protected oracle-only run independently recovers all 43.
- `library-complete-v22.log`: **1,099 passed, zero failed or ignored**, including
  20 pattern-search tests. Six `python-complete-*.log` suites passed **260 tests**.
  Formatting and `git diff --check` passed; memory stayed below the 2 TiB limit
  excluding reclaimable file cache.

The new search uses live rules, checked context pumping, helper composition,
commuting substitution factorization, closing-parameter unification and
alpha-invariant state deduplication. No benchmark names, supplied pattern trees
or example-specific witnesses were added to production Ferrum code. These are
bounded general search operations, not completeness of the entire calculus.

## 2026-10-12 pattern rewriting: 1,262 witness-free Standard roots

**1,262 of the retained 1,338 Standard roots replay with modular, witness-free
oracle guidance and no fallback: 990 YES and 272 NO.** Native pattern rewriting
adds `EEG_IJCAR_12/emmes-nonloop-ex6_2`. Full native discovery certifies in
1.040 seconds; guidance contains no supplied order, pattern witness, or
composite proof. **Innermost 311/311 (301 YES, ten NO)** and
**CSR 110/110 (105 YES, five NO)** remain certified with the same final binary
and oracle. All 1,683 retained CPFs passed two additional production checks;
exact input/decision comparisons have no losses or polarity changes.

The Standard first pass certified **1,261/1,262**. `Ex3_2_Luc97_GM` returned
Unknown after 538.988 seconds: its previously successful WPO attempt timed
out locally, followed by unsuccessful broader guided attempts. A separately
recorded repeat using the **same binary, oracle and ceiling** certified in
**47.065 seconds**. Neither trace uses the new non-loop action. The complete
retained set includes that repeat, with both attempts preserved. This is not
a flawless single-pass or competition-cap score. The replay used 64 workers,
two Rayon threads each, and 1,200/1,205-second prover/harness ceilings.

Ferrum implementation: `99ce79463993f0064eaeefdeb9352a26bbf4a9c3`.
CeTA-CSR is unchanged on main `73662ec88a74f65187cba6986d300836564b6a59`;
executable SHA256
`64597fcb0a8c1c09af1de0816283c66f474783df3010fc3e60ca30731f5090b7`.
No CeTA source changes or Isabelle builds were needed.

Artifact base: `target/standard-nonloops-20261012/`:

- `consolidated-rewrite-final/{details.json,attempts.json}`: complete retained
  set with first-pass/retry provenance. `all-rewrite-final/` and
  `repeat-ex3-rewrite/` retain the original attempts.
- `all-comparison-rewrite-final.json` and category-specific comparisons;
  `all-rewrite-final-rechecks.jsonl`: all 1,683 CPFs checked twice additionally.
- `final-summary-rewrite.json`, `final-gaps-rewrite.json`, and
  `remaining-nonloops-rewrite.json`: **76 remaining Standard gaps**, comprising
  49 YES-reference roots, 25 pattern non-loops, and two other NOs.
- `parameter-rewrite-final.jsonl`: 558,333 states, 1,604,908 actions, SHA256
  `0ea7bf6ba5a6ad26370677abb96526808c0faa90bfb284e25e85db6b9b394b71`.
  Witness-free and modular `*-rewrite-final-audit.json` files report zero
  forbidden witnesses, composite actions, or pipelines.
- Frozen `ferrum-rewrite-v6`, SHA256
  `334198434600e5be6e5d17393f16a3e38097ff9f28ce6443c2dcbda47a7dcfa1`.
- `terminal-rewrite-v6.json` and `discovery-rewrite-v6.json`: 18/43 native
  terminal recoveries and 18/18 full-root discovery certifications, respectively,
  each with duplicate checks. No earlier recovery was lost.
- `library-rewrite-v6-production.log`: **1,090 passed, zero failed or ignored**.
  The four `python-rewrite-*.log` suites passed **49 tests**.
  An earlier library invocation omitted `CETA_CSR_BIN` and selected stock CeTA,
  causing six standalone CSR/relative-input parse failures; it is retained in
  `library-rewrite-v6.log`, not ignored or counted as a passing run.

The remaining pattern reference proofs divide into 16 rewriting/simplification
and nine context-growing pumping cases. Basic native rewriting and checked
simplification now exist, but general factorization and composition of
accelerated helper patterns remain incomplete. Merely adding the primitive
operations did not recover all proof chains using them.

## 2026-10-12 native pattern non-loops: 17 further Standard recoveries

**1,261 of the retained 1,338 Standard roots replay with modular, witness-free
oracle guidance and no fallback: 990 YES and 271 NO.** This adds 17 certified
NOs to the 1,244-root checkpoint. The same final binary and oracle preserve
**Innermost 311/311 (301 YES, ten NO)** and **CSR 110/110 (105 YES, five NO)**.
One complete replay passed all 1,682 roots, with no missing inputs, losses,
polarity changes, uncertified decisions, or checker failures. Every retained
CPF then passed two additional independent production CeTA checks.

This is retained-root recovery, not a full-TPDB or competition-cap score.
The final run used 64 workers, two Rayon threads per prover, a 1,200-second
prover ceiling and 1,205-second harness ceiling. No isolated retries were
needed in this final run. Guidance uses native state-local actions and bounds,
not exact witnesses, composite proofs, or compound strategy pipelines.

Ferrum implementation: `88f26bac2cc828e4a57ae1e364febbb01c6e0f0e`.
CeTA-CSR is unchanged on main `73662ec88a74f65187cba6986d300836564b6a59`;
executable SHA256
`64597fcb0a8c1c09af1de0816283c66f474783df3010fc3e60ca30731f5090b7`.
No CeTA source changes or Isabelle builds were needed.

Artifact base: `target/standard-nonloops-20261012/`:

- `all-v5/{details.json,summary.md,run/}`: complete final replay.
  `all-comparison-v5.json` and category-specific comparisons check exact sets;
  `all-v5-rechecks.jsonl` records the 1,682 duplicate CPF checks.
- `final-summary-v5.json`, `final-gaps-v5.json`, and
  `remaining-nonloops-v5.json`: gains and remaining inventory. There are
  **77 Standard gaps: 49 YES-reference, 26 pattern non-loops, two other NOs**.
- `parameter-v5.jsonl`: 558,332 states, 1,601,226 actions, SHA256
  `2f7c2062bda50ada2857672bbf6996dfe2c1190e3b8306a69f37543f7019c570`.
  `witness-free-v5-audit.json` and `modular-v5-audit.json` report zero forbidden
  witnesses, witness references, hex actions, composite proofs, or pipelines.
- Immutable optimized `ferrum-pattern-v4`, SHA256
  `23c328b50e7f9594aa1e7e088a6747acd4ac5017092ac6a50b43b51987a4cbc2`.
- `terminal-v4.json` and `discovery-complete-v4.json`: native terminal and
  full-root discovery, each checking new positive proofs twice.
- `library-v4.log`: **1,085 passed, zero failed or ignored**. Four focused
  Python suites passed **49 tests**. `git diff --check` passed.

The native processor recovers all 14 simplest pattern cases and three more
using live-rule pumping, domain equivalence, instantiation, pattern narrowing,
and substitution-power closure. No benchmark-specific templates were added.
The remaining 26 reference proofs divide into 17 rewriting/simplification
and nine context-growing pumping cases. These are useful next search targets,
not claims that alternative native proofs cannot exist.

The first preservation run (`all-v4/`) exposed a PALINDROME continuation gap.
The old frozen binary reproduced the same gap with that oracle; neither trace
called the new non-loop processor. A valid path-order result reached a different
residual, whose native path-order/DP/SCT continuation certified in 0.138 seconds.
Its state-local guidance was added to v5. `palindrome-new-residual-v4/` and
`palindrome-recovered-v5/` retain the repair; the latter full-root replay took
26.737 seconds, and the final complete replay also certified it. Earlier failed
attempts remain recorded and were not relabeled.

## 2026-10-12 all 23 Standard loop gaps recovered

**1,244 of the retained 1,338 Standard roots replay with modular, witness-free
oracle guidance and no fallback: 990 YES and 254 NO.** All 23 originally
missing loop roots are recovered, adding 23 NOs to the 1,221-root baseline
and 13 to the earlier 1,231-root checkpoint below. Exact input/decision
comparison reports no losses, missing inputs, polarity changes, or uncertified
decisions. The 94 remaining inventory rows comprise 49 YES-reference and
45 NO-reference roots; the latter are 43 pattern non-loops and two other
nontermination proofs, not remaining loop gaps.

The final Standard batch certified **1,243/1,244** under its 600-second prover
ceiling. `LISTUTILITIES_nokinds_noand_C` timed out, then certified in an
explicitly recorded isolated retry taking **606.313 seconds**, with a
1,200-second ceiling and the **same binary and oracle**. The complete retained
set includes that retry; this is not a single-pass competition-cap score.
No failed attempt was silently relabeled as certified.

The same final binary and oracle preserve **CSR 110/110 (105 YES, five NO)**
and **Innermost 311/311 (301 YES, ten NO)**. All 1,665 retained positive root
proofs passed two additional production CeTA checks. The focused loop replay
also passed **23/23**, with its own duplicate checks. Its root times were
3.599–60.912 seconds under 16-worker load.

Ferrum implementation: `69769349ce1ee62f7d16ef6d1c4bfa978ddc9563`.
CeTA-CSR remains unchanged on main
`73662ec88a74f65187cba6986d300836564b6a59`; executable SHA256
`64597fcb0a8c1c09af1de0816283c66f474783df3010fc3e60ca30731f5090b7`.
No CeTA source changes or Isabelle rebuilds were needed.

Artifact base: `target/standard-loops-20261012/`:

- `consolidated-certified-v52/{details.json,attempts.json}`: complete set,
  with explicit first-pass and retry provenance. Its
  `*-complete-comparison.json` verifies all 1,244 inputs and decisions.
- `consolidated-final-v52/` and `variable-retry-v52/`: unmodified first-pass
  and retry artifacts; their `*-rechecks.jsonl` files cover 1,243 plus one CPF.
- `guards-final-v52/` and `loops-final-v52/`: protected and focused replays,
  each with `*-complete-comparison.json` and `*-rechecks.jsonl`.
- `final-summary-v18.json`, `final-coverage-v18.json`, `final-gaps-v18.json`,
  `final-loop-coverage-v18.json`: certified inventory and all 23 loop gains.
  The unresolved rows retain prior bounded-scan observations.
- `parameter-v18.jsonl`: 558,320 states and 1,601,142 actions, SHA256
  `be2ede7b1512645953e8cf259f8b50c6a55623a06a9f6d0070c8be7d9e9961e2`.
  `witness-free-v18-audit.json` and `modular-v18-audit.json` report zero exact
  witnesses, witness references, hex actions, composite proofs, or pipelines.
  The exporter defect retaining DP discovery continuations is fixed; the
  28 intermediate entries were stripped before the final modular replay.
- Immutable optimized `ferrum-loops-v52`, SHA256
  `7c67ea83225d1ce2b6b5d77d0b775bd4082c99bdd6eefb7861aa85ac9bbc6b8f`.
- `library-release-v52.log`: **1,079 passed**, zero failed or ignored.
  Four focused Python suites passed **49 tests**; `git diff --check` passed.

## 2026-10-12 native loop Standard recovery (earlier checkpoint)

**1,231 of the retained 1,338 Standard roots replay without exact witnesses
or fallback: 990 YES and 241 NO.** One consolidated optimized replay preserved
all previous 1,221 certified roots and added ten NOs. Every positive passed
two additional production CeTA-CSR checks. This is retained-root recovery,
not a full-TPDB or competition-cap score. The 107 unresolved inventory rows
retain prior bounded-scan observations, not a uniform final replay.

The same binary and oracle preserve **311/311 Innermost (301 YES, ten NO)**
and **110/110 CSR (105 YES, five NO)**, each also checked twice more. Exact
input/decision comparisons show no losses, missing inputs, polarity changes,
or uncertified decisions.

Ferrum implementation: `e36fd204a9aa07a2129fe5a8bf5c1b7ae90e3e71`.
CeTA-CSR is unchanged on main
`73662ec88a74f65187cba6986d300836564b6a59`, checker SHA256
`64597fcb0a8c1c09af1de0816283c66f474783df3010fc3e60ca30731f5090b7`.
No CeTA source changes or Isabelle rebuilds were required.

Artifact base: `target/standard-loops-20261012/`:

- `consolidated-release-v22/{details.json,summary.md,run/}`: 1,231 roots,
  761 seconds elapsed; `consolidated-release-v22-rechecks.jsonl`: duplicate checks.
- `guards-release-v22/`, `guards-release-v22-rechecks.jsonl`: protected categories.
  Both replays have `*-complete-comparison.json` exact-set checks.
- `final-summary-v5.json`, `final-coverage-v5.json`, `final-gaps-v5.json`:
  scope, certified totals, gains, and remaining inventory.
- `parameter-v5.jsonl`, SHA256
  `e8f165f1e39a3d6c253318346a677d768e43854e29bd0216da04f351240a2cda`:
  557,903 states and 1,600,557 actions, with no exact witnesses, witness
  references, hex payloads, composite proofs, or compound pipelines
  (`modular-v5-audit.json`, `witness-free-v5-audit.json`).
- Optimized immutable binary `ferrum-loops-v22`, SHA256
  `f88ebf2855aad04ee30595b503ef3f581ada27da8b1bd2d5d7554e5cb7ede7de`.
- `library-release-v22.log`: **1,067 passed**, zero failed or ignored.
  The four focused Python suites passed **57 tests**; `git diff --check` passed.

The ten new NOs are Hydras/lepper_{2,3,4,5,6,8,9}, Secret_05_TRS/cime4,
Strategy_removed_AG01/#4.13, and Transformed_CSR_04/Ex6_15_AEL02_Z.
Native symbolic and backward DP search infer loops from live rules;
recursive DP probe export preserves NO polarity and context. Complete
proof actions remain retired. Standard configuration is 48 workers,
two Rayon threads, and 1,200/1,205-second root/harness limits; guards use
16 workers and 600/605 seconds. Guidance flags match the preceding entry.

The loop campaign remains open: 13 of its original 23 roots remain, seven
with certified native terminal loops but incomplete preprocessing chains,
and six needing stronger terminal search. Exploratory `parameter-v6.jsonl`
and `source-frontier-release-v22c/` are not this frozen high-water profile.
Early debug-build timing misses are documented in the reproducibility log
and must not be treated as optimized performance regressions.

## 2026-10-11 quadratic conditional Standard recovery

**1,221 of the retained 1,338 Standard roots now replay without exact witnesses
or fallback: 990 YES and 231 NO.** All 1,221 positives passed one consolidated
replay with the same binary and oracle, followed by two additional production
CeTA-CSR checks per certificate. This adds **nine YESs with zero losses** against
1,212. It is a retained-root recovery result, not a full-TPDB or competition-cap
score. The 117 unresolved inventory rows come from prior bounded scans, not a
uniform final replay of all 1,338 inputs.

The same final configuration preserves **311/311 Innermost (301 YES, ten NO)**
and **110/110 CSR (105 YES, five NO)**, also with two additional independent
checks per certificate. There are no missing inputs, polarity changes or
uncertified decisions in the consolidated and guard replays.

Ferrum implementation commit:
`4b82b493368ae98d696e079d401b9d173a257cea`.
CeTA-CSR is unchanged on main
`73662ec88a74f65187cba6986d300836564b6a59`, checker SHA256
`64597fcb0a8c1c09af1de0816283c66f474783df3010fc3e60ca30731f5090b7`.
No CeTA source changes or Isabelle rebuilds were required.

Artifact base: `target/standard-q-conditional-20261011/`:

- `consolidated-v17/{details.json,summary.md,run/}`: fresh 1,221-root replay,
  748 seconds elapsed; `consolidated-v17-rechecks.jsonl`: duplicate checks.
- `guards-v17/`, `guards-v17-rechecks.jsonl`: complete protected categories.
  Both runs have `*-complete-comparison.json` exact input/decision comparisons.
- `final-summary-v17.json`, `final-coverage-v17.json`, `final-gaps-v17.json`:
  scope, certified totals, nine gains and remaining 117 roots.
- `parameter-v17.jsonl`, SHA256
  `5570639d8fe1aac0a7ca4d3cb4a6df6d00d39053d38c4814565124842cc77643`.
  Its 557,893 state records and 1,600,500 actions contain no exact witnesses,
  witness references, hex payloads, composite proofs or compound pipelines
  (`profile-v17-audit.json`, `compound-audit-v17.json`).
- Immutable binary `ferrum-q12-conditional`, SHA256
  `d1c2de8fd63710e880a3b1e7d4940cfedc53665bce664d43e0227e4af12c700d`.
- `full-library-v12.log`: **1,056 passed**, zero failed or ignored.
  `python-tests-final.log`: **83 passed**. `git diff --check` passed.

Configuration remains 48 Standard workers, two Rayon threads each,
1,200/1,205-second root/harness limits; guards use 16 workers and 600/605-second
limits. Flags are `FERRUM_DIRECT_FILTER_PATH_ORDER=1`,
`FERRUM_DP_LLM_NO_FALLBACK=1`, `FERRUM_ORACLE_TIME_SCALE_PERCENT=200` and
`FERRUM_SEMANTIC_LABELING_CONTINUATION_ATTEMPTS=512`. Replays use
`timeout(..., fail)` and `--no-top-level-llm`.

New YESs: AProVE_07/{otto04,otto13,thiemann22}, Beerendonk_07/{14,24},
GTSSK07/{cade03,cade06,cade14}, and Secret_07_TRS/aprove06. Native quadratic
conditional synthesis now supports bounded predecessor/successor contexts,
shared arithmetic encodings, signed usable-rule checks and bounded
re-induction. The focused square template reduces cade14's replay from 94 to
about seven seconds. Native narrowing and recursive closure recover
Beerendonk_07/14. No supplied interpretations are retained.

An intermediate path-order replay exposed different unguided TRS residuals for
LISTUTILITIES_nosorts_noand_C. Seven local DP/SCT continuations certified; their
state-local integration restored the root in 10.8 seconds in the final batch.
Intermediate v13/v16 results are not the baseline.

The remaining **117 roots comprise 49 YES and 68 NO reference results**.
For 22 NOs, native Q-aware initialization, rule restriction, Q reduction and
full-strategy switching now reach terminal states, preserving the required
Q/NFS/minimality context. Native inductive pattern non-loop synthesis is still
missing: all 22 local trials remain open (`q-blockers.json`); no NO gain is
claimed from preprocessing alone. Further YES gains require stronger
conditional-induction/search capabilities or closing different residuals, not
restoring composite proofs. See `innermost-conditional-qaf.md` and
`processors-status.md` for processor limits.

## 2026-10-11 native Standard consolidated recovery

**1,212 of the retained 1,338 Standard roots are now recovered without exact
witnesses or fallback: 981 YES and 231 NO.** All 1,212 recovered roots passed
one consolidated replay with the same binary and oracle, followed by two
additional production CeTA-CSR checks per certificate. This is **178 gains
and zero losses** against the initial 1,034-root native baseline. It is a
retained-root recovery result, not a full-TPDB or competition-cap score.

The same configuration preserves **311/311 Innermost (301 YES, ten NO)** and
**110/110 CSR (105 YES, five NO)**. Both guard categories also pass two
additional independent checks. No uncertified decisions are counted.

Artifact base: `target/standard-native-20261010/`:

- `consolidated-v73/{details.json,summary.md,run/}`: fresh 1,212-root replay,
  665 seconds elapsed; `consolidated-v73-rechecks.jsonl`: duplicate checks.
- `guards-v73/` and `guards-v73-rechecks.jsonl`: complete protected categories.
- `final-coverage-v73.json` and `final-v73-gaps.json`: coverage inventory and
  unresolved-root diagnostics. The 126 unresolved rows come from the bounded
  `final-remainder-v67` scan; this inventory is explicitly **not** a single
  uniform-profile replay of all 1,338 roots. All counted positives use v73.
- `final-v73-summary.json`: scope, counts, checksums, and oracle audit.
- `parameter-v73.jsonl`, SHA256
  `44da723700dd87e48cd0f8e4f05f22ea08bab3cb9a900bf778dd7afb1693282c`.
- Immutable binary `ferrum-gm04-map`, SHA256
  `82b34913797b666386b8284bfb04bb14ceae512c25ea19b7df3adc75a4c28105`,
  from Ferrum `605adfc1dcf6973468bae885fb9ff23cbc879fa0`.

CeTA-CSR remains unchanged on main
`73662ec88a74f65187cba6986d300836564b6a59`, checker SHA256
`64597fcb0a8c1c09af1de0816283c66f474783df3010fc3e60ca30731f5090b7`.
No CeTA source changes or rebuilds were needed. Ferrum's full library suite
passed **1,048 tests**, and **77 focused Python tests** passed.

Configuration: 48 Standard workers, two Rayon threads each, 1,200/1,205-second
root/harness limits; guards used 16 workers and 600/605-second limits.
`FERRUM_DIRECT_FILTER_PATH_ORDER=1`, `FERRUM_DP_LLM_NO_FALLBACK=1`,
`FERRUM_ORACLE_TIME_SCALE_PERCENT=200`, and
`FERRUM_SEMANTIC_LABELING_CONTINUATION_ATTEMPTS=512`.
Counted replays use `timeout(..., fail)` and `--no-top-level-llm`.

The additional recoveries came from all-strict native WPO search, signed
integer-Arctic coefficients, tighter matrix search bounds, shared top-level
path-order encoding, and native DP exploration of TRS residuals. Parent
actions leading to closed children receive state-local priorities, never a
composite proof or supplied interpretation. The full GM04 CPF writer now
preserves the fresh auxiliary symbol's frozen replacement-map entry, matching
the standalone and innermost writers and graph estimation. An inner-loop
deadline check also prevents match-bound completion from overrunning its
local allowance.

The remaining **126 roots comprise 58 YES and 68 NO reference results**.
Twenty-two NO reference proofs contain Q-aware initialization actions without
native conversion; the other 46 NOs still need successful native loop/nonloop
synthesis or closing continuations. Two YES reference proofs use quadratic
conditional orders (`Beerendonk_07/24`, `GTSSK07/cade14`). The other 56 YESs
include open conditional-induction obligations, order synthesis, new residual
chains, and match-bound/RFC automaton searches. These are diagnostic leads,
not claims that exact witnesses are intrinsically required.

The final broad native-DP TRS-residual wave certified two of 111 local probes,
recovering `thiemann11` and `Strategy_removed_AG01/#4.30c`. Targeted closure
recovered `LISTUTILITIES_complete_noand_C` in 28 seconds. A backward priority
audit over 812 certified local states found only the two already-integrated
remaining-root routes (`closed-parent-frontier.log`), rather than another
unexploited closing chain. Further progress needs strengthening these searches
or context-aware processors, not re-enabling complete-proof actions.

## 2026-10-11 native Standard initial complete pass

Complete parameter-only, modular, no-fallback replay over the retained
1,338-root Standard set: **1,190 certified (959 YES, 231 NO)**, with
144 Unknowns and four timeouts. This is **156 gains and zero losses** against
the initial 1,034-root native replay, and three gains with zero losses against
the preceding complete 1,187-root run. There are no polarity changes or
uncertified decisions. All 1,190 certificates passed two additional independent
production CeTA-CSR checks. This is not a full-TPDB or competition-cap score.

The same binary and oracle preserve **311/311 Innermost and 110/110 CSR**;
all 421 guard certificates also passed two additional checks.

Artifact base: `target/standard-native-20261010/`:

- `full-v56/{details.json,summary.md,run/}` and `full-v56-rechecks.jsonl`:
  complete Standard replay, 1,526 seconds elapsed.
- `full-v56-v49-comparison.json` and `full-v56-start-comparison.json`:
  loss/gain comparisons; `full-v56-native-gap-report.json`: all 148 misses.
- `guards-v56/` and `guards-v56-rechecks.jsonl`: category guards.
- `parameter-v56.jsonl`, SHA256
  `1cd7ec267c286dc9b7f9501c6ac42a2f6e80d80abef6d692daf2a3ad9da34b63`.
  No exact-witness, hex-payload, or pipeline actions remain in this profile.
- Immutable binary `ferrum-search-recipe`, SHA256
  `816f1951f74fac1e3b4e387941a2156bd303c82fb25f65c3f9cc6c34899c976f`,
  built from Ferrum `113d7781ffb4f30d8e659a253d8c60dd1afb55ed`.

CeTA-CSR is unchanged on main commit
`73662ec88a74f65187cba6986d300836564b6a59`; production checker SHA256
`64597fcb0a8c1c09af1de0816283c66f474783df3010fc3e60ca30731f5090b7`.
No CeTA source changes or rebuilds were needed.

Configuration: 48 Standard workers, two Rayon threads each, root limit
1,200 seconds, harness limit 1,205 seconds, longest-first scheduling;
`FERRUM_DIRECT_FILTER_PATH_ORDER=1`, `FERRUM_DP_LLM_NO_FALLBACK=1`,
`FERRUM_ORACLE_TIME_SCALE_PERCENT=200`, and
`FERRUM_SEMANTIC_LABELING_CONTINUATION_ATTEMPTS=512`.
Guards used 16 workers and 600/605-second limits. Counted runs use
`timeout(..., fail)` and `--no-top-level-llm`, not a fallback portfolio.

Recovery fixes include canonical-alias preservation, state-local action
priority, recursive closure of newly synthesized children, measured local
time allowances, a shared continuation budget across semantic-model branches,
and preserving the actual native search recipe separately from its resulting
model. Oracle files are now published atomically. Models and local fragments
receive no inherited certification credit; only complete checked root proofs
contribute to the score.

The remaining report distinguishes unconverted source actions from failed
native searches. Twenty-two source proofs contain Q-aware initialization
actions without native conversion, and two contain quadratic conditional
orders. Other misses include open conditional-induction obligations, newly
synthesized residuals, and bounded order/loop/automaton searches. These are
investigation indicators, not proof that exact witnesses are necessary.

## 2026-10-10 complete native Innermost recovery

Complete parameter-only modular oracle replay: **311/311 (301 YES, ten NO)**,
with no fallback, supplied order/model witnesses, or composite-proof actions.
The complete run finished in 237 seconds. All five previous misses are now
certified; there are zero losses, missing inputs, polarity changes, or
uncertified decisions against the 306-root baseline. Every retained proof
passed two additional independent checks with production CeTA-CSR.

The final CSR guard is **110/110 (105 YES, five NO)**, in 146 seconds,
also with zero losses and two additional checks per certificate. These are
replays of the established 311-root Innermost and 110-root CSR sets, not a
claim that all TPDB Innermost inputs are solved.

Ferrum implementation: `a4799e0996dede1230c5ab19c03fd95bcfa6a382`
on `codex/aaecc-20260831`.
CeTA-CSR production checker is unchanged, from main commit
`73662ec88a74f65187cba6986d300836564b6a59`; binary SHA256
`64597fcb0a8c1c09af1de0816283c66f474783df3010fc3e60ca30731f5090b7`.
No CeTA source changes were made for this recovery. Unrelated working-tree
CeTA edits were not included or rebuilt.

Artifact base: `target/innermost-five-20261010/`:

- `full-v19/{details.json,summary.md,run/}`, `full-v19-comparison.json`,
  and `full-v19-rechecks.jsonl`: authoritative 311-root replay.
- `csr-guard-v19/`, `csr-guard-v19-comparison.json`, and
  `csr-guard-v19-rechecks.jsonl`: final 110-root guard.
- `parameter-v19.jsonl`: 524,285 records, zero `exact-` or `hex=` records;
  SHA256 `399ca4fcf7c72e6f8fb008bbf0ebb81c09282bc9334461f836d330b5df1fed12`.
- Immutable tested binary `ferrum-final-v9`, SHA256
  `b9324c085b3e55709c917bf3c87c1017a0876c9cc5d6f19af6ad993b0ad348be`.
- `final-library-tests.log`: **1,032 passed, zero failed, zero ignored**.
  Python canonical-alias, native-export, frontier, and merge suites:
  respectively 4, 6, 13, and 12 passing tests. `git diff --check` passes.

Replay configuration: `FERRUM_DIRECT_FILTER_PATH_ORDER=1`,
`FERRUM_DP_LLM_NO_FALLBACK=1`, two Rayon threads per process,
`--strategy 'timeout(600s, fail)' --no-top-level-llm`, and the above oracle.
Innermost used 16 workers; CSR used eight. Harness ceiling was 605 seconds.
Seven Innermost roots took over 60 seconds; the maximum was 179.806 seconds.
Thus this establishes complete replayability, not 311 solves at a 60-second cap.

The five recovered roots, all in `Transformed_CSR_innermost_04`, took:

| Root | Seconds |
| --- | ---: |
| LISTUTILITIES_complete_noand_C | 179.806 |
| MYNAT_complete_noand_GM | 8.610 |
| OvConsOS_nokinds_noand_iGM | 17.727 |
| PALINDROME_complete_noand_GM | 35.073 |
| PEANO_complete_noand_iGM | 17.037 |

Native order synthesis now supports state-local
`path-order(status=rpo,optimize=0)` (also `lpo`) and whole-TRS
`path-order(max-symbols=256,shared=1)`. Shared multiset constraints avoid
duplicated SMT encodings; models still pass the original independent checks.
The whole-TRS route preserves its positional-equivalence and safe-filter
boundary. Ordinary default encodings remain unchanged: applying the new
encoding globally changed residual models and caused five experimental
regressions, all recovered by making the encoding choice state-local.

OvCons and PEANO were recovered by recursively closing newly synthesized
residuals. MYNAT needed configured native RPO plus its newly exposed child.
Canonical alias export now recovers hash-only successful events from their
digest-checked, complete typed inputs, rather than losing their guidance.
LISTUTILITIES needed a measured graph allowance with 20% headroom and
`gm04-rpo` prioritized at 131 local component states. General path-order
search previously wasted eight seconds per component. The native GM04 order
is derived from transformation roles and checked on live obligations; the
two-pair terminal is discharged only within the verified source-CSR context.
The independently certified focused replay is in `list-v19/`.

## 2026-10-10 symbolic filtered orders: 306/311 parameter-only

Complete native-action, no-fallback replay: **306/311 (296 YES, ten NO)**
in 373 seconds. Three gains and zero losses against 303; zero missing inputs,
polarity changes or uncertified decisions. Every retained certificate passed
two additional independent production CeTA-CSR checks. Four Unknowns and one
timeout remain.

Gains, all `Transformed_CSR_innermost_04`: ExAppendixB_AEL03_GM,
ExAppendixB_AEL03_iGM, and LengthOfFiniteLists_nokinds_C. Appendix order search
uses shared symbolic argument filters; Length follows its existing native
CSR-to-GM route with corrected state-local action priority. No exact orders,
composite proofs, or benchmark-specific production code were introduced.
The oracle contains zero `exact-` or `hex=` candidate records.

Ferrum implementation: `9bfa55f56d32e5d72b9acc54e5dd28ab059f6eef`.
Enable `FERRUM_DIRECT_FILTER_PATH_ORDER=1`; default encoding selection is
unchanged. The immutable tested binary is `ferrum-direct-v3`, SHA256
`0c875e0a5c634c43f4a517b33a61ad2448c85d419b2ebbce35181495d766d59b`.
CeTA-CSR main is unchanged: `73662ec88a74f65187cba6986d300836564b6a59`.
Sixteen workers, two Rayon threads each, 300/305-second root/harness ceilings.
An explicit replay measurement restores MYNAT_nokinds_noand_iGM with 20%
timing headroom, preserving the historical best time and evidence credit.

Artifact base: `target/innermost-eight-20261010/`:

- `full-v9/{details.json,summary.md,run/}`, `full-v9-comparison.json`,
  `full-v9-rechecks.jsonl`.
- `parameter-v9.jsonl`, SHA256
  `02444888f6288e19d55b0806dc8fcc0c8e993181b9355344e5574d10bc9b46ae`.
- `direct-frontier-v2/`: six complete, twice-certified local closures.
- `length-v7/` and `length-v7-rechecks.jsonl`: focused Length recovery.
- `mynat-v9/` and `mynat-v9-rechecks.jsonl`: restored timing-sensitive root.
- CSR guard: **110/110** (105 YES, five NO), 72 seconds; `csr-guard/`,
  `csr-guard-comparison.json`, `csr-guard-rechecks.jsonl`.
- Witness-assisted Innermost guard: **311/311** (301 YES, ten NO), 183 seconds;
  `production-guard/`, its comparison and recheck files. Both guards used
  `ferrum-direct-v2`, before the timing-metadata-only update. All guard
  certificates passed two additional checks; zero losses.
- Final release library suite: **1,030 passed, zero failed, zero ignored**.
  Twelve frontier, six harness, five exporter and twelve merge tests pass.

Remaining five, all `Transformed_CSR_innermost_04`:

- LISTUTILITIES_complete_noand_C: timeout; expensive graph construction and
  roughly 548--554 MB local order encodings remain optimization targets.
- MYNAT_complete_noand_GM: order synthesis still exceeds the available budget.
- OvConsOS_nokinds_noand_iGM and PEANO_complete_noand_iGM: newly synthesized
  models leave residual chains not closed by the current native frontier.
- PALINDROME_complete_noand_GM: the first whole-TRS path-order removal still
  needs stronger or more efficient native synthesis.

## 2026-10-10 native residual integration: 303/311 parameter-only

Complete native-action, no-fallback replay: **303/311 (293 YES, ten NO)**
in 384 seconds. Four gains and zero losses against 299; no missing inputs,
polarity changes or uncertified decisions. All 303 certificates passed two
additional independent production CeTA-CSR checks. Seven Unknowns and one
timeout remain.

Gains, all `Transformed_CSR_innermost_04`: Ex1_2_AEL03_iGM,
LengthOfFiniteLists_nokinds_iGM, MYNAT_nokinds_noand_GM, and
MYNAT_nokinds_noand_iGM. They use native synthesis and separately addressed
residual continuations, not supplied orders or composite proof actions.
The exporter retains original search parameters as untried alternatives:
tightening bounds to a returned model can expose different uncovered children.

Unchanged prover: Ferrum `a6f76dc5f22925e3fced515387c17d709c5498fa`,
binary SHA256 `842047519f26ddff66f618bfee93a53670623af172393ee4d324dbaa4e41a29c`.
Extraction changes are committed in `5c8f16e`.
Unchanged CeTA-CSR main: `73662ec88a74f65187cba6986d300836564b6a59`.
Sixteen workers, two Rayon threads each, 300/305-second root/harness ceilings.

Artifact base: `target/innermost-native-closures-20261010/`:

- `full-v4/{details.json,summary.md,run/}`, `full-v4-comparison.json`,
  `full-v4-rechecks.jsonl`.
- `parameter-v4.jsonl`, SHA256
  `4ad1a640a91c421450e2822340a7a508cc234a7490af49edf593f6883f6488dd`.
- Fresh native CSR guard: **110/110** (105 YES, five NO), 76 seconds,
  `csr-guard/` and `csr-guard-rechecks.jsonl`; all certificates checked twice.
- Fresh witness-assisted production Innermost guard: **311/311** (301 YES,
  ten NO), 205 seconds, zero losses. Artifacts: `production-guard/`,
  `production-guard-comparison.json`, `production-guard-rechecks.jsonl`;
  all 311 certificates checked twice. Its existing production oracle is unchanged.
- The additional-closure profile also repeats **303/311**, zero losses, in
  380 seconds: `full-v5/`, `full-v5-comparison.json`, `full-v5-rechecks.jsonl`.
  All 303 repeat certificates passed two independent checks. Latest verified
  native profile: `parameter-v5.jsonl`, SHA256
  `d6f3cb9d39024f76f9fc6834373fd53b64596b1deec96a3270a5487268ee7b4a`.
- Five hint-exporter, eighteen frontier and eleven monotone-merge tests pass.
  No processor source changed; no new Rust suite or Isabelle build was needed.

Remaining eight, all `Transformed_CSR_innermost_04`:
ExAppendixB_AEL03_GM, ExAppendixB_AEL03_iGM,
LISTUTILITIES_complete_noand_C (timeout), LengthOfFiniteLists_nokinds_C,
MYNAT_complete_noand_GM, OvConsOS_nokinds_noand_iGM,
PALINDROME_complete_noand_GM, PEANO_complete_noand_iGM.

## 2026-10-10 verified residual continuation baseline: 299/311 parameter-only

The completed `2026-09-19` full-v8 replay certifies **299/311 (289 YES,
ten NO)** with native parameter guidance and no fallback. A fresh double
CeTA-CSR recheck on 2026-10-10 accepts all 299 certificates. Compared with
297: two gains, zero losses, no missing inputs, polarity changes or
uncertified decisions. Eleven Unknowns and one timeout remain.

Additional gains: `Transformed_CSR_innermost_04/LengthOfFiniteLists_complete_noand_GM`
and `Transformed_CSR_innermost_04/OvConsOS_complete_noand_GM`.
The unchanged prover is Ferrum `a6f76dc5f22925e3fced515387c17d709c5498fa`,
binary SHA256 `842047519f26ddff66f618bfee93a53670623af172393ee4d324dbaa4e41a29c`.
CeTA-CSR main remains `73662ec88a74f65187cba6986d300836564b6a59`.
Root/harness limits are 300/305 seconds, sixteen workers, two Rayon threads.
No exact interpretations or composite proof actions were added. The previous
same-binary CSR 110 and production Innermost 311 guards remain unchanged;
they have not been rerun for this data-only update.

- Replay: `target/innermost-sixteen-20260919/full-v8/`.
- Oracle: `target/innermost-sixteen-20260919/parameter-v8.jsonl`, SHA256
  `bb5c74890e1f5ca39746d541803bf8237a0d7ffd47847420033fab3d70451735`.
- Fresh verification: `target/innermost-native-closures-20261010/baseline-299-rechecks.jsonl`
  and `baseline-299-comparison.json` in the same directory.
- The remaining roots are the twelve uncertified entries in `full-v8/details.json`.

## 2026-09-19 residual continuation recovery: 297/311 parameter-only

Complete native-action, no-fallback replay: **297/311 (287 YES, ten NO)**,
380 seconds, **two gains and zero losses** against the 295 baseline.
No missing inputs, polarity changes or uncertified decisions. All 297 CPFs
passed two additional independent production CeTA-CSR checks.

Gains: `Transformed_CSR_innermost_04/Ex1_2_AEL03_GM` and
`Transformed_CSR_innermost_04/Ex4_DLMMU04_iGM`. Native residual closures and
state-local parameter hints suffice; no supplied interpretations were added.
Thirteen Unknowns and one timeout remain. A later individually certified
Length GM recovery is pending the next complete replay and is not counted here.

Unchanged immutable prover from Ferrum
`a6f76dc5f22925e3fced515387c17d709c5498fa`, with SHA256
`842047519f26ddff66f618bfee93a53670623af172393ee4d324dbaa4e41a29c`.
Unchanged CeTA-CSR main `73662ec88a74f65187cba6986d300836564b6a59`.
Sixteen workers, two Rayon threads each; 300-second root / 305-second harness.
The previous same-binary production Innermost 311 and native CSR 110 guards
remain the latest guards; they were not rerun for this data-only update.

Artifact base `target/innermost-sixteen-20260919/`:

- `full-v3/{details.json,summary.md,run/}`;
- `full-v3-comparison.json`, `full-v3-rechecks.jsonl`;
- `parameter-v3.jsonl`, SHA256
  `b4acf680ccc18358d7cdea7e77522ed0d5c4405405ad5ea90d2200615e283065`.

See [working recovery log](innermost-sixteen-recovery.md).

## 2026-09-17 measured-budget residual recovery: 295/311 parameter-only

Ferrum **`a6f76dc5f22925e3fced515387c17d709c5498fa`**, unchanged CeTA-CSR
main **`73662ec88a74f65187cba6986d300836564b6a59`**. Complete native-action,
no-fallback replay certifies **295/311 (285 YES, ten NO)** in 404 seconds.
Compared with 294: **one gain, zero losses**, no missing inputs, polarity
changes or uncertified decisions. Every retained certificate passed two
additional independent production CeTA-CSR checks.

Gain: `Transformed_CSR_innermost_04/PEANO_complete_noand_GM`, certified in
50.089 seconds in the full run. Recovery combines native residual closures,
discovery of exhausted guided states, and measured processor allowances with
20% headroom. No supplied interpretation was added. Sixteen workers, two
Rayon threads each, 300-second root / 305-second harness limits.

Same-binary guards: production Innermost **311/311** (301 YES, ten NO) and
compact native CSR **110/110** (105 YES, five NO), zero losses; all certificates
double rechecked. Standard was not rerun.

Artifact base: `target/innermost-residual-sharing-20260917/`.

- `full-v4/details.json`, `full-v4-comparison.json`, `full-v4-rechecks.jsonl`.
- `parameter-v15.jsonl`, SHA256
  `e38aa63f63f2710807fdf1eb84ae9aaa14f9504283936684b77fcbd6c923f1d0`.
- `ferrum-measured-v2`, SHA256
  `842047519f26ddff66f618bfee93a53670623af172393ee4d324dbaa4e41a29c`.
- `production-guard-v3/`, `csr-guard-v3/`, corresponding `production-v3-*`
  and `csr-v3-*` comparisons and double-check reports.
- `library-measured-v1.log`: **1,026 passed**, none failed/ignored. Subsequent
  timing-metadata filtering: all **29 lookup tests** pass. Python frontier
  suite: **47 passed**. Final release build and `git diff --check` pass.

Remaining 16, all in `TRS_Innermost/Transformed_CSR_innermost_04`:
Ex1_2_AEL03_GM, Ex1_2_AEL03_iGM, Ex4_DLMMU04_iGM,
ExAppendixB_AEL03_GM, ExAppendixB_AEL03_iGM,
LISTUTILITIES_complete_noand_C (timeout), LengthOfFiniteLists_complete_noand_GM,
LengthOfFiniteLists_nokinds_C, LengthOfFiniteLists_nokinds_iGM,
MYNAT_complete_noand_GM, MYNAT_nokinds_noand_GM, MYNAT_nokinds_noand_iGM,
OvConsOS_complete_noand_GM, OvConsOS_nokinds_noand_iGM,
PALINDROME_complete_noand_GM, PEANO_complete_noand_iGM.
The other 15 return Unknown. A longer diagnostic Length replay is not part
of this baseline. See [residual work](innermost-residual-sharing.md).

## 2026-09-17 shared-encoding residual recovery: 294/311 parameter-only

Ferrum **`07c941901c333da631f3e160a46ea72138225c05`**, unchanged CeTA-CSR
main **`73662ec88a74f65187cba6986d300836564b6a59`**. Complete native-action,
no-fallback replay certifies **294/311 (284 YES, ten NO)** in 393 seconds.
Compared with 293: **one gain, zero losses**, no missing inputs, polarity
changes or uncertified decisions. All 294 certificates passed two additional
independent CeTA checks. Remaining: **15 Unknown, two timeouts**.

Gain: `Transformed_CSR_innermost_04/Ex1_GM99_iGM`, recovered by closing its
actual native-generated residual and integrating native continuation actions.
The shared polynomial encoding and short query identifiers use no supplied
interpretations. Same-binary production Innermost **311/311** and compact CSR
**110/110** guards remain certified and twice rechecked. Standard was not rerun.

Artifact base: `target/innermost-residual-sharing-20260917/`.

- `full-v3/details.json`, `full-v3-comparison.json`,
  `full-v3-rechecks.jsonl`, `full-v3-witness-report.json` (remaining root list).
- `parameter-v8.jsonl`, SHA256
  `2261cad8ab5ce1e5f3748151ab04d6e98e0594b1d2d6bb79e2a5ba98901e933a`.
- `ferrum-v2`, SHA256
  `63460c5d1280ebd2d8c9612722300aff1b22accb0f76055e2ac42852c2140f80`.
- Guards: `production-guard-v2/`, `csr-guard-v2/`, corresponding
  `production-v2-*` and `csr-v2-*` comparisons and double-check reports.
- `library-v2.log`: **1,023 passed**, none failed/ignored;
  `python-tests.log`: **44 passed**. `git diff --check` passed.

Sixteen workers, two Rayon threads each, 300-second root / 305-second harness
ceilings; not a strict-60-second claim. The independent canonical-cycle-key
experiment is not included in this baseline. See
[encoding measurements and residual work](innermost-residual-sharing.md).

## 2026-09-17 residual closure: 293/311 parameter-only

Verified implementation follow-up: Ferrum
**`07c941901c333da631f3e160a46ea72138225c05`** retains the complete 293-root
native replay, production Innermost 311/311 and compact CSR 110/110, all with
exact comparisons and double rechecks. It adds shared polynomial usable-rule
encodings, reversible short solver identifiers, and nested marked-role
preservation. No CeTA changes. Artifacts and checksums are in
[the residual-sharing report](innermost-residual-sharing.md); its `full-v2/`
is the confirmed parity run. Later profiles are not baseline promotions until
their complete replay is checked.

Ferrum **`57c4c932098a4640a7950a10438bb6778cb5b967`**, unchanged CeTA-CSR
main **`73662ec88a74f65187cba6986d300836564b6a59`**. Complete native-action,
no-fallback replay certifies **293/311 (283 YES, ten NO)** in 394 seconds.
Compared with 292: one gain, **zero losses**, no missing inputs, polarity
changes or uncertified decisions. All 293 retained certificates passed two
additional independent CeTA checks. Remaining: **16 Unknown, two timeouts**.

Gain: `Transformed_CSR_innermost_04/PALINDROME_complete_noand_iGM`.
The profile adds native state-local continuation hints, not supplied models.
The orphan marked-symbol canonicalization fix preserves CSR residual roles
after rule deletion; Length itself remains unresolved.

Artifact base: `target/innermost-conditional-qaf-20260917/`.

- `full-v6/details.json`, `full-v6-comparison.json`,
  `full-v6-rechecks.jsonl`, `full-v6-witness-report.json` (includes unresolved roots).
- `parameter-v5.jsonl`, SHA256
  `9ad0aaaba7b308e56f64eb6c54610b0fbb1e3a944e93047bdf91de040f7ebaf5`.
- `ferrum-v10`, SHA256
  `1dd8f84c75bb5a57898be3dec4428da72e27004352f5249d91398ddc13970fc8`.
- Same-binary `production-guard-v10/`: **311/311**; `csr-guard-v10/`:
  **110/110**. Exact comparisons and double checks are recorded in
  `production-v10-comparison.json`, `production-v10-rechecks.jsonl`,
  `csr-v10-comparison.json`, `csr-v10-rechecks.jsonl`.
- `library-v10.log`: **1,022 passed**, none failed or ignored;
  `canonical-tests-v10.log`: 42 passed.

Replay uses 16 workers, two Rayon threads each, 300-second root / 305-second
harness ceilings, not a strict-60-second limit. Standard was not rerun.
Production oracle and compact CSR profile remain unchanged.

Next priorities: close the actual unguided children of the Ex1_2/ExAppendixB
and Ex4_DLMMU04 families, then the MYNAT/OvCons/PEANO continuations. Check
Length's remaining non-minimal residual independently. After closure work,
profile encoding versus solving: `LengthOfFiniteLists_nokinds_C` emits a
**675,283,835-byte polynomial query for two pairs and zero usable rules**;
this is concrete encoding-size evidence, not justification for simply raising
timeouts. Also separate the currently conflated `unsat-or-timeout` order results
and measure graph/labeling/solver phases before changing budgets.

## 2026-09-17 conditional/Q-aware recovery: 292/311 parameter-only

Ferrum **`ca1d17ef7ebf5adb528768764cc06431493a738f`**, unchanged CeTA-CSR
main **`73662ec88a74f65187cba6986d300836564b6a59`**. Complete native-action,
no-fallback Innermost replay certifies **292/311 (282 YES, ten NO)**.
Exact comparison against 289 finds **three gains, zero losses**, no missing
inputs, polarity changes or uncertified decisions. All 292 certificates passed
two further independent CeTA checks. Remaining: 17 Unknown and two timeouts.

Gains: `Mixed_innermost/cade05`, `cade13`, and `wiehe13`. Native conditional
orders use a joint SMT query; Q-aware KBO/RPO usable rules are independently
checked. The wiehe13 recovery includes new state-local guidance for its actual
synthesized residual. No supplied interpretation or composite action is needed.
See [implementation and limits](innermost-conditional-qaf.md).

Artifact base: `target/innermost-conditional-qaf-20260917/`.

- `full-v4/details.json`, `full-v4-comparison.json`,
  `full-v4-rechecks.jsonl`, `full-v4-witness-report.json`.
- `parameter-v4.jsonl`, SHA256
  `a06abf2879ef2d3430f88b6420f2866df214dd3035ae1b9fd53f9f349c47c429`.
- `ferrum-v9`, SHA256
  `4ec8ca9bed8213fa40f7f5e72dfb35f111de955d353a12aa33853b89a2d758a7`.
- Same-binary guards: `production-guard/` retains 311/311 and `csr-guard/`
  retains 110/110, exact comparisons and twice-rechecked proofs in
  `production-comparison.json`, `csr-comparison.json`,
  `production-rechecks.jsonl`, `csr-rechecks.jsonl`.
- `library-v9.log`: 1,021 passed, none failed or ignored; Python: 38 passed.

Full replay: 394 seconds, 16 workers, two Rayon threads each, 300-second root
and 305-second harness ceilings. This is not a strict-60-second result. Standard
was not rerun. Experimental later residual profiles and the separate marked-role
canonicalization follow-up are not included in this baseline. Production oracle
and compact CSR profile remain unchanged.

## 2026-09-17 follow-up: 289/311 parameter-only, three gains without losses

Ferrum **`715fdedbbc919e9849efc3953b675a72c39769e0`**, unchanged CeTA-CSR
main **`73662ec88a74f65187cba6986d300836564b6a59`**. Complete 311-root
no-fallback replay with native processor/parameter guidance certifies
**289 roots (279 YES, ten NO)**, versus 286 previously. Exact input/decision
comparison finds **three gains, zero losses**, no missing roots, no polarity
changes, and no uncertified decisions. All 289 proofs passed two additional
independent CeTA checks. The experimental profile was scanned: no `exact-*`
actions or supplied interpretations. Composite proof actions remain retired.

Gains: `Transformed_CSR_innermost_04/MYNAT_complete_iGM`,
`PEANO_complete_GM`, and `PEANO_complete_iGM`. The remaining **22 roots**
(20 Unknown, two timeouts) have source-state native synthesis probes and
[per-root diagnostic indicators](innermost-native-last25-diagnostics.md).
They are not claimed intrinsically dependent on exact witnesses.

Same-binary guards retain **production Innermost 311/311** (301 YES, ten NO)
and **compact native CSR 110/110** (105 YES, five NO), with exact root-set
comparisons and two additional checks of every certificate. Standard was not
rerun. Neither production oracle nor compact CSR profile was replaced.

Artifact base: `target/innermost-native-last25-20260917-045625/`.

- Full native replay: `full-v3/details.json`, `full-v3-comparison.json`,
  `full-v3-rechecks.jsonl`, `full-v3-witness-report.json`.
- Native profile: `parameter-v3.jsonl`, SHA256
  `b2da4881d0702d042e318ba45f224fa289e12b19365d11a8c5e91a64eed6e3d7`.
- Frozen executable: `ferrum-v2`, SHA256
  `7d3673503a15abc25cd5e3266bd23e2c598475672095674ddda6f8a6db888e39`.
- Guards: `production-guard/`, `csr-guard/`; comparisons:
  `production-comparison.json`, `csr-comparison.json`; double checks:
  `production-guard-rechecks.jsonl`, `csr-rechecks.jsonl`.
- Validation: `library-final.log`: **1,012 passed**, none failed/ignored;
  `python-tests.log`: **26 passed**; direct KBO/RPO CeTA tests and
  `git diff --check` passed.

Native replay: 400s, 16 workers, 300s root / 305s harness ceilings, two Rayon
threads per prover. This is not a strict-60-second claim. The first complete
`full-v2` replay certified 288; the second TRS-child frontier pass recovered
the additional PEANO root. Broad speculative DP hints did not improve the
targeted result and were slower, so they are not in the preferred profile.
Parser/budget repair and the full-R KBO alternative are general, not
benchmark-specific. Q and the innermost context remain intact.

## 2026-09-17 Innermost: 286/311 parameter-only, production and CSR retained

Ferrum **`e27b2ed7f507abd8f59024dab8e3b0085949f470`**, unchanged CeTA-CSR
main **`73662ec88a74f65187cba6986d300836564b6a59`**. Complete 311-root
no-fallback replay with native processor/parameter guidance certifies
**286 roots (276 YES, ten NO)**: **13 gains, zero losses** against 273.
All 286 certificates passed two additional independent CeTA checks. Exact
root-set comparisons show no missing inputs, polarity changes, or uncertified
decisions. The experimental profile contains no `exact-*` actions or supplied
interpretations; composite proof actions remain retired.

Fresh same-binary guards preserve **production Innermost 311/311**
(301 YES, ten NO) and **compact native CSR 110/110** (105 YES, five NO),
also with two additional checks of every certificate and zero root-set losses.
Standard's 1,338-root baseline was not rerun. The production oracle and compact
CSR profile are unchanged; the experimental native profile does not replace
the production oracle.

The gains come from complete TRS-child frontier collection, reuse of native
families from newer certified recoveries, consistent/memoized argument-filter
expansion, adequate native graph-analysis budgets, and ordinary full-R RPO
search that preserves Q. A separate native search closed Ex2_Luc02a_iGM's
22-pair residual; three state-local hints recover its complete root. No
example-specific production code or CeTA changes were introduced.

Artifact base: `target/innermost-native-20260917/`.

- Complete native replay: `replay-v6/details.json`; comparisons:
  `v6-comparison.json` (against 273), `v6-v5-comparison.json` (against 285).
  Independent checks: `v6-rechecks.jsonl`.
- Native profile: `parameter-v6.jsonl`, SHA256
  `a1fc2df7ad3de7e1039ec7e01b126bf1f3dd9af52d681bb2df166466ae1a6f08`.
- Frozen binary: `ferrum-v4`, SHA256
  `7284a6400db8ad59c58b691b15ffe58cdbcc2b01700063ee9d6ac77ee87d611d`.
- Guards: `production-guard-v4/`, `csr-guard-v4/`, and their corresponding
  `*-comparison.json` / `*-rechecks.jsonl` files.
- Validation: `library-v4.log` (**1,010 passed**, none failed/ignored),
  `python-final.log` (**50 passed**), and `git diff --check`.
- Remaining **25 roots (24 Unknown, one harness timeout)** and per-root
  processor diagnostics: `v6-witness-report.json`. Two require native
  conditional/general reduction-pair constraint-proof synthesis (`cade05`,
  `cade13`); the others still need search/continuation improvements. They are
  not claimed intrinsically dependent on exact witnesses.

Native replay: 397s, 16 workers, 300s root / 305s harness ceilings, two Rayon
threads per prover. Production/CSR guards: 351s/74s, eight workers. These are
not strict-60-second claims. Intermediate v3/v4 runs with two MYNAT losses
remain archived; v5/v6 recover both, rather than accepting the regressions.
See [implementation and campaign details](innermost-parameter-only-replay.md).

## 2026-09-16 Innermost: 273/311 parameter-only, production and CSR retained

Ferrum **`2f30530d4ec45002fbdd19ca10b706b3a263ffe1`**, unchanged CeTA main
**`73662ec88a74f65187cba6986d300836564b6a59`**. Complete 311-root no-fallback
replay without supplied oracle interpretations or composite actions:
**273 certified (263 YES, ten NO)**. Exact root-set comparison against the
previous 268 shows **five gains, zero losses**, zero polarity changes, and
zero uncertified decisions. All 273 certificates passed two independent
CeTA checks. The preferred lean v14 profile leaves 35 Unknowns and three
timeouts (38 roots); broad experimental v13 leaves 31 Unknowns and seven
timeouts, with exactly the same certified root set.

Native whole-TRS quasi-RPO with safe unary projection recovers
`MYNAT_nokinds_GM`, `MYNAT_nosorts_GM`, `MYNAT_nosorts_iGM`,
`MYNAT_nosorts_noand_GM`, and `PEANO_nokinds_GM`, all in
`TRS_Innermost/Transformed_CSR_innermost_04`.
Full-context canonical aliases remove pair-order lookup gaps. Exact symmetry
pruning reduces two previously timed-out canonicalizations to 0.833s/1.009s;
no context-erasing alias or example-specific production code was added.

Fresh preservation guards: **Innermost production 311/311** (301 YES, ten NO)
and **CSR 110/110** (105 YES, five NO), every proof checked twice. Standard's
1,338-root production baseline was not remeasured. The production oracle and
independent compact CSR profile are unchanged.

Artifact base: `target/innermost-native-remaining-20260916/`.

- Complete native replay: `replay-v14/details.json`, `v14-comparison.json`,
  `v14-rechecks.jsonl`; unresolved list: `v14-witness-report.json`.
- Preferred experimental native profile: `parameter-v14.jsonl`, SHA256
  `077788018b09c37ccf61514f25aa8f034a041a7a55a7046d911b844262f4b8e1`.
- Broader comparison: `replay-v13`, `v13-rechecks.jsonl`, and
  `v14-v13-comparison.json` (identical certified roots).
- Frozen executable: `ferrum-v2`, SHA256
  `a5daaf23709d50cc1f7bab8e8f5b041b68249c926c05d7b7b96155a0a3d73794`.
- Guards: `production-guard-v2`, `csr-guard-v2`, with corresponding
  `*-rechecks.jsonl` files. Production Innermost root-set comparison is
  `production-guard-v2-comparison.json`.
- Validation: `library-v2.log` (1,002 passed, none failed/ignored),
  `python-v2-final.log` (25 passed), `git diff --check`.

Lean native replay took 414s with 16 workers, versus 706s for the broad
exploratory profile in this comparison; guards took 406s/73s with eight
workers. All use 300s root / 305s harness ceilings, two Rayon threads per
prover. These totals are not strict-60-second claims or a statistical speedup
benchmark. Both native profiles have complete, twice-checked replay artifacts;
neither replaces the 311-root production oracle.
See [campaign details](innermost-parameter-only-replay.md) and
[canonicalization measurements](canonicalization-performance.md).

## 2026-09-16 Innermost: 268/311 parameter-only, production 311/311 retained

Ferrum **`daafd00ce8c25acfc8f96933ec1632ba9401ff11`**, unchanged CeTA main
**`73662ec88a74f65187cba6986d300836564b6a59`**. A complete no-fallback replay
without supplied oracle interpretations or composite actions certifies
**268/311 Innermost roots: 258 YES, ten NO**, up from 225. Exact root-set
comparison reports **43 gains, zero losses**, no polarity changes and no
uncertified decisions. All 268 certificates were independently checked twice.
The remaining frontier is **40 Unknowns and three timeouts**, not a claim that
these 43 inherently require exact witnesses. Category elapsed time: 369s;
300s root ceilings, 305s harness, 24 workers, two Rayon threads each.

The unchanged production oracle passes a fresh **311/311 Innermost** guard
(301 YES, ten NO), all twice checked, in 209s. The independent compact CSR
profile passes **110/110** (105 YES, five NO), all twice checked. Standard was
not remeasured; its previous 1,338-root production baseline is unchanged.
Do not replace the full production oracle with this experimental profile.

Artifacts under `target/innermost-native-20260916/`:

- `replay-v9/details.json`, `v9-comparison.json`, `replay-v9-rechecks.jsonl`;
- unresolved root list: `final-witness-report.json`;
- guards: `production-guard/details.json`, `production-guard-rechecks.jsonl`,
  `csr-guard-v3/details.json`, `csr-guard-v3-rechecks.jsonl`;
- profile `parameter-v9.jsonl`, SHA256
  `4cc258faf30df2cc95b2d2b8feb772d9afe2f113c81e29c75a79d21c8c1bad3f`;
- binary `ferrum-v3`, SHA256
  `bfff38080b4d994b502e511703b4b01a17e24e98c08c2646797b15927d51ba53`.

The full serial release suite passes **996/996**, zero ignored; 33 focused
Python tests pass. Native constant lifting and structurally recognized GM04
RPO replace supplied witnesses. GM04 source-proof export now preserves the
fresh frozen auxiliary map entry; its prior rejected certificate is retained
as a diagnostic, never counted or promoted. No graph-estimation or CeTA
change was necessary. See [the campaign record](innermost-parameter-only-replay.md).

## 2026-09-16 compact CSR profile: 110/110 with 1.74 MB guidance

Ferrum **`ef7ee67`**, unchanged CeTA main
**`73662ec88a74f65187cba6986d300836564b6a59`**. A separate compact CSR profile
preserves **110/110 parameter-only, no-fallback results (105 YES, five NO)**,
all independently checked twice, with no missing roots, losses, polarity
changes or uncertified decisions. No exact witness or composite proof action
is supplied. Actual runtime lookup tracing plus alias closure reduced the
429,107,566-byte parameter oracle to **1,735,544 bytes / 1,336 records**.

Category elapsed time: **62 seconds**; maximum root: **58.524 seconds**.
Every root finished within 60 seconds in this run, but the configured cap
was 300 seconds. This is not a separate strict-60-second benchmark.
The slice is validated for these 110 roots, not arbitrary unseen residuals.
Retain the larger parameter oracle for exploration and the unchanged
production oracle for Standard/Innermost; neither category was remeasured
in this compaction pass. Their previous 1,338/311 production guards remain
the authoritative results, not claims about this CSR-only slice.

Artifacts under `target/csr-native-wpo-sparse-20260916/`:

- Profile `csr-slice-v3.jsonl`, SHA256
  `563a2447503c4c78d4161f8657dfd48281a3d5030e022bd17fad75dbe16638af`.
- `csr-slice-replay-v3/details.json`, `csr-slice-v3-comparison.json`,
  `csr-slice-v3-rechecks.jsonl`: full replay and double checks.
- Frozen `ferrum-lookup-trace-release`, SHA256
  `f30ffc857a518f2c0348385eb7b7795944d459016f42040a802e5090d0f16526`.
- CeTA SHA256 unchanged:
  `64597fcb0a8c1c09af1de0816283c66f474783df3010fc3e60ca30731f5090b7`.

Six Python slicing tests and 29 Rust utility-lookup tests pass. No proof
processor, CeTA source or Isabelle heap changed. Source-relative standalone
MU-TERM export remains a separate pending integration, documented in
[the compaction/export follow-up](csr-oracle-compaction-and-local-export.md).

## 2026-09-16 native WPO and sparse rational synthesis: 110/110 parameter-only CSR

Validated Ferrum **`6f25f6000e10c526fc3ab6fcf466aace1c9d7b96`**, unchanged
production CeTA main **`73662ec88a74f65187cba6986d300836564b6a59`**.
The complete optimized **parameter-only, no-fallback** replay certifies
**110/110 CSR roots (105 YES, five NO)**, up from 106 with **zero losses**.
All 110 CPFs passed two independent checks. No unresolved roots remain in
this 110-input set. The parameter oracle contains no exact actions, hex
payloads or witness references: none of these CSR roots requires an exact
oracle witness in this replay. This is not a no-oracle default-strategy score.

The four gains are **Ex3_2_Luc97, Ex5_7_Luc97, ExIntrod_Zan97 and emmes**.
Native `wpo-max` jointly synthesizes its max algebra, precedence, collapsing
filters and partial lexicographic statuses. Restricted rational quadratic
search synthesizes assignments over a small global coefficient alphabet and
sparse monomial shapes. No benchmark-specific interpretation was added.
State-local native guidance closes newly exposed children; complete proof
wrappers and fallback remain disabled. See
[implementation and evidence](native-wpo-and-sparse-quadratic.md).

The full category takes 116 seconds under concurrent load. Root ceilings are
300 seconds, with 60-second local allowances for the new bounded processors.
108 roots finish within 60 seconds; ExIntrod takes 76.241 seconds and morse
69.139 seconds. **110/110 is therefore not a strict 60-second-root score.**

The final optimized production-oracle guard preserves **1,759/1,759 roots**:
Standard **1,338 (1,039 YES, 299 NO)**, Innermost **311 (301 YES, ten NO)**,
CSR **110 (105 YES, five NO)**. Every production CPF passes two independent
CeTA checks. All **235/235 retained residuals** also replay and certify twice.
Comparisons report no missing inputs, losses, polarity changes or uncertified
decisions. Full debug and release library suites each pass **990 tests** with
zero failures/ignored tests; the focused Python suite passes **25 tests**.

Artifacts under `target/csr-native-wpo-sparse-20260916/`:

- `parameter-release/details.json`, `parameter-release-comparison.json`,
  `parameter-release-rechecks.jsonl`: complete 110-root native replay.
- `production-release/details.json`, `production-release-comparison.json`,
  `production-release-rechecks.jsonl`: complete 1,759-root production guard.
- `residual-release-checks.jsonl`, `child-release-checks.jsonl`: 152 + 83
  retained residuals, all twice-certified.
- `library-final.log`, `library-release.log`, `python-tests.log`: tests.
- Native oracle `parameter-v22.jsonl`, SHA256
  `2c0ba4ed87d8d8ae5e636ea71456652744eec39ee502cae3486eaa95753b92bb`.
- Frozen binary `ferrum-release`, SHA256
  `6d80059a79b3d192954903b2c6e1da60d135bba1b1d6308abc7bf2c70980eaff`.

Production oracle remains
`target/residual-state-audit-20260915/oracle-v48-final.jsonl`, SHA256
`c73c52debd91ebe8ad0da4c0887f6ee3ac15cd98524034888ff9422b9a6071ea`.
CeTA binary remains `/work/dfm/festschrift/CeTA-CSR/ceta`, SHA256
`64597fcb0a8c1c09af1de0816283c66f474783df3010fc3e60ca30731f5090b7`.
No CeTA changes or Isabelle builds were required. Earlier debug guard artifacts
are partial and superseded by the complete optimized guard above.

## 2026-09-16 witness-free csrdiv recovery: 106/110

Validated Ferrum **`a7dd346`**, unchanged production CeTA main
**`73662ec88a74f65187cba6986d300836564b6a59`**. The complete parameter-only,
no-fallback replay certifies **106/110 CSR roots (101 YES, five NO)**, up from
105 with csrdiv recovered and **zero losses**. All 106 proofs passed two
independent CeTA checks. The four Unknown roots are Ex3_2_Luc97,
Ex5_7_Luc97, ExIntrod_Zan97 and emmes; none timed out in the final category run.

csrdiv's native graph processor now uses the same fresh-unhiding-symbol map
as CPF export and the existing exact-graph checker. Its new local states are
guided by native max orders, instantiation, graphs, SCT and rational orders,
without supplied interpretations. State-local parameter prioritization also
reduces OvConsOS_complete-noand's replay to 5.886 seconds; csrdiv takes 4.769
seconds. No composite proof action or retained pipeline was enabled.

The final production-oracle guard preserves **1,759/1,759 roots**:
Standard **1,338 (1,039 YES, 299 NO)**, Innermost **311 (301 YES, ten NO)**,
CSR **110 (105 YES, five NO)**. These production figures include retained
witnesses and must not be confused with the 106 witness-free CSR results.
Every production CPF passed two checks. All **235/235 independent residuals**
also replay and certify twice. Input comparison reports no losses, missing
inputs, polarity changes or uncertified decisions.

Artifacts under `target/csr-five-recovery-20260916/`:

- Parameter-only: `parameter-v3/details.json`, `parameter-v3-comparison.json`,
  `parameter-v3-rechecks.jsonl` (complete run: 113 seconds).
- Production: `production-v2/details.json`, `production-v2-comparison.json`,
  `production-v2-rechecks.jsonl`.
- Residuals: `residual-v2-checks.jsonl`, `child-v2-checks.jsonl`.
- Final library suite: `library-v2.log`, **985 passed, zero failed/ignored**,
  with `CETA_CSR_BIN=/work/dfm/festschrift/CeTA-CSR/ceta` explicitly set.
- Experimental parameter oracle: `parameter-v17.jsonl`, SHA256
  `63852c1eec196360b0738c99d8766765def961c445f32b234d8a2a9abf5d7450`.
- Final binary: `ferrum-graph-fixed-v2`, SHA256
  `769392ccbc730e95a81e2f445ba0475233f59e09ad5b8bc27bf1bc862aaa6112`.

Production oracle remains `target/residual-state-audit-20260915/oracle-v48-final.jsonl`,
SHA256 `c73c52debd91ebe8ad0da4c0887f6ee3ac15cd98524034888ff9422b9a6071ea`.
CeTA binary SHA256 remains
`64597fcb0a8c1c09af1de0816283c66f474783df3010fc3e60ca30731f5090b7`.
Parameter and production replay ceilings are respectively 300 and 180 seconds,
both without fallback. No CeTA changes or Isabelle builds were required.

Important corrected diagnosis: Ex3/Ex5's final retained steps are **filtered
weighted path orders**, not plain max-polynomial orders. Native WPO synthesis
is missing; the converter now rejects this misleading conversion. Ex3's
initial max phase needs constants only 1, not the source witness's 48,638.
Tighter quadratic bounds did not recover ExIntrod/emmes. See the
[detailed follow-up](csr-witness-free-five-followup.md), including the two
superseded aggregate runs and their resolved losses.

## 2026-09-16 seven further witness-free CSR recoveries

Validated Ferrum **`b29bcf4`**, unchanged production CeTA main
**`73662ec88a74f65187cba6986d300836564b6a59`**. The complete parameter-only,
no-fallback CSR replay now certifies **105/110 (100 YES, five NO)**, up from
98 with seven gains and zero losses. Every successful proof passed two
independent production CeTA checks. This is distinct from the retained
witness-enabled production score of **110/110 (105 YES, five NO)**.

Recovered: LISTUTILITIES_complete-noand, LISTUTILITIES_nokinds-noand,
LengthOfFiniteLists_complete-noand, LengthOfFiniteLists_complete,
MYNAT_complete-noand, OvConsOS_complete-noand, PALINDROME_complete-noand.
The five remaining parameter-only Unknown roots are CSR_04/Ex3_2_Luc97,
CSR_04/Ex5_7_Luc97, CSR_04/ExIntrod_Zan97, Maude_06/emmes and Maude_06/csrdiv.
They are search/continuation gaps, not evidence that exact witnesses are
inherently necessary. Standalone local MU-TERM context export remains separate
unfinished work; no fake parent or weakened checker was used for these gains.

The final production guard retains **1,759/1,759 certified roots**:
Standard **1,338 (1,039 YES, 299 NO)**, Innermost **311 (301 YES, ten NO)**,
CSR **110 (105 YES, five NO)**. All 1,759 proofs passed two checks; exact input
comparison found no losses, polarity changes, or uncertified decisions.
The preceding build with the same fixed-R/max-order changes also retained
**235/235 independent residuals**, all twice certified. The final library
suite passes **984 tests**, zero failed or ignored; 25 focused Python tests
pass. CeTA did not change and no Isabelle rebuild was needed.

Artifacts under `target/csr-native-twelve-20260916/`:

- Parameter replay: `parameter-final/details.json`,
  `parameter-final-comparison.json`, `parameter-final-rechecks.jsonl`.
- Production guard: `production-final/details.json`,
  `production-final-comparison.json`, `production-final-rechecks.jsonl`.
- Residual checks: `residual-checks.jsonl`, `child-checks.jsonl`.
- Tests: `library-final.log`, `python-final.log`.
- Experimental parameter oracle: `parameter-v11.jsonl`, SHA256
  `c6b0a0b1e5c6dace42e3aa914e463d73696126f1850ea09c877d8175ca56f9e6`.
  Native hints carry zero independent-event certification credit.
- Final binary: `ferrum-final`, SHA256
  `5660427aea38f08506a2a6f056684d1d54a10e0680c4b5bba88b0216d0f22399`.

Production oracle is unchanged:
`target/residual-state-audit-20260915/oracle-v48-final.jsonl`, SHA256
`c73c52debd91ebe8ad0da4c0887f6ee3ac15cd98524034888ff9422b9a6071ea`.
CeTA binary SHA256:
`64597fcb0a8c1c09af1de0816283c66f474783df3010fc3e60ca30731f5090b7`.
Production guard uses `timeout(180s, fail)`; the experimental parameter-only
guard uses `timeout(300s, fail)`. Both disable fallback. Native order search
may discover new models and residuals; the recorded score is a certified run,
not a guarantee that all subsequent searches will choose identical models.

## 2026-09-16 native-search CSR improvement

Validated Ferrum **`152bbe0`**, unchanged production CeTA main
**`73662ec88a74f65187cba6986d300836564b6a59`**. The complete parameter-only,
no-fallback CSR replay now certifies **98/110 (93 YES, five NO)**, up from
97 with no losses. Ex1_GM03 is the gain: native local usable rules followed
by native order synthesis, with no supplied interpretation. Ten roots remain
unknown and two time out; their exact identities and outcomes are retained
in `target/native-muterm-usable-20260916/csr-parameter-guard/details.json`.
All 98 proofs passed two independent CeTA rechecks.

The separate production-oracle guard retains **1,759/1,759 roots**:
Standard **1,338 (1,039 YES, 299 NO)**, Innermost **311 (301 YES, ten NO)**,
CSR **110 (105 YES, five NO)**. All proofs were checked twice, with zero
losses, missing inputs, polarity changes or uncertified decisions. The
retained **235/235 independent residuals** also replay and certify twice.
This is not a claim that all production replay is witness-free. Newly exposed
non-minimal MU-TERM children still lack standalone CPF export; their complete
parent certifies, but they are not counted among independent certified states.

Artifacts under `target/native-muterm-usable-20260916/`:

- Production replay: `production-guard/details.json`,
  `production-comparison.json`, `production-rechecks.jsonl`.
- Parameter-only CSR: `csr-parameter-guard/details.json`,
  `csr-parameter-rechecks.jsonl`; five additional Ex1 repeats:
  `repeat-{1,2,3,4,5}/ceta.log`.
- Residual checks: `residual-checks.jsonl`, `child-checks.jsonl`.
- All **977 library tests pass**, zero failures or ignored tests:
  `library-v3.log`. CeTA did not change; no Isabelle rebuild was required.

Production oracle remains `target/residual-state-audit-20260915/oracle-v48-final.jsonl`,
SHA256 `c73c52debd91ebe8ad0da4c0887f6ee3ac15cd98524034888ff9422b9a6071ea`.
Experimental parameter oracle: `target/native-muterm-usable-20260916/parameter-oracle-v2.jsonl`,
SHA256 `c54c160e3c60dc551a33a065e6966518ba248f5145945c90e4dfd01ffcbb131d`.
Validated release executable SHA256:
`eda5b814a0bd7fbb62aa69918499b23cd15e8c02e0e7193dd2dfc325cb15c1eb`.
CeTA executable SHA256:
`64597fcb0a8c1c09af1de0816283c66f474783df3010fc3e60ca30731f5090b7`.
Both root guards use `timeout(180s, fail)` with fallback disabled.

## 2026-09-15 complete modular residual closure

Validated Ferrum **`c622d59`**, production CeTA main **`73662ec`**.
The final oracle-only, no-fallback replay retains **1,759/1,759 certified
roots**, with no missing inputs, losses, polarity changes or uncertified
decisions. Every retained root CPF passed production CeTA twice.

| Category | Certified YES | Certified NO | Total |
| --- | ---: | ---: | ---: |
| TRS Standard | 1,039 | 299 | 1,338 |
| TRS Innermost | 301 | 10 | 311 |
| CSR | 105 | 5 | 110 |
| All three | 1,445 | 314 | 1,759 |

**All 152 independent residual audit gaps are closed.** Another 83 distinct
children exposed during recovery also independently replay without fallback:
**235/235 residual states, every proof certified twice**. These are child
closures, not additional benchmark roots. Complete TRS/DP proof oracle actions
remain disabled by assertions; the new GM04 processor exposes a genuine CSR
child and reconstructs its verified connection to the DP or TRS parent.

All **975 Rust library tests** and **238 focused Python tests** pass, with no
Rust failures or ignored tests. Seven GM04 production boundary tests pass,
including reduced R with fixed Q and four mutation-negative cases. Isabelle
`Proof_Checker`, isolated export from production `Code_CSR_Production`, and
production `make haskell` passed. See [the residual audit](residual-state-audit.md).

Artifacts below `target/residual-state-audit-20260915/`:

- Frozen monotone oracle: `oracle-v48-final.jsonl`, SHA256
  `c73c52debd91ebe8ad0da4c0887f6ee3ac15cd98524034888ff9422b9a6071ea`.
- Full root replay: `gm04-final-root-details-v3.json`, combining the disjoint
  `gm04-final-root-guard-v3-{standard,innermost,csr}/details.json` runs of the
  same binary, checker and oracle. Comparison:
  `gm04-final-root-comparison-v3.json`; twice-certification:
  `gm04-final-root-rechecks-v3.jsonl`.
- Residuals: `smoke-replay-v27/results.jsonl` and
  `smoke-checks-v27-production.jsonl`; additional children:
  `gm04-new-frontier-replay-v2/results.jsonl` and
  `gm04-new-frontier-checks-v2.jsonl`.
- Tests: `gm04-final-library-v3.log`, `gm04-final-python-v5.log`, and
  `gm04-bridge-boundary-tests-production-v4/results.jsonl`.

Ferrum executable SHA256:
`509c2f93f3bc375f724b6ca4d795fa8067c40535824bf6e533249a16c2eef5b7`.
Production CeTA executable SHA256:
`64597fcb0a8c1c09af1de0816283c66f474783df3010fc3e60ca30731f5090b7`.
Root verification used `timeout(180s, fail)`, `--no-top-level-llm`, and
`FERRUM_DP_LLM_NO_FALLBACK=1`; no default fallback was used to obtain these
counts. The checker extension and regenerated Haskell are committed in CeTA
main; unrelated pre-existing ROOT/outermost development files were preserved.

## 2026-09-15 modular residual recovery checkpoint

Ferrum `c69ebce`, production CeTA-CSR main `68bf6e9`: the complete
oracle-only root guard retains **1,759/1,759 certified roots**, no missing
inputs, losses, polarity changes or uncertified decisions. Standard **1,338**
(1,039 YES, 299 NO), Innermost **311** (301 YES, ten NO), CSR **110**
(105 YES, five NO). Every retained root CPF passed production CeTA twice.
The independent child replay now has **142/152 twice-certified**, zero
checker rejections and ten remaining gaps; these are not root losses.
All **967 Rust library tests** and **216 focused Python tests** pass.
CeTA did not change; no Isabelle rebuild was needed.

Validated oracle: `target/residual-state-audit-20260915/oracle-v32-candidate.jsonl`
(historical candidate suffix), SHA256
`ea184652ab27040a264b51daf817c552a1bca806b0ee48fe50a9b925cbb4e474`.
Artifacts under that directory: `native-binding-root-guard-v2/details.json`,
`native-binding-root-comparison-v2.json`, `native-binding-root-recheck-v2.jsonl`,
`smoke-replay-v20/results.jsonl`, `smoke-checks-v20.jsonl`,
`checkpoint-library-tests.log`, `checkpoint-python-tests.log`.
Complete-proof actions remain retired, and root fallback remains disabled.
Further source-proof/renaming integration candidates do not supersede this
checkpoint until checked. See [the residual audit](residual-state-audit.md).

## 2026-09-15 portable witness full replay checkpoint

Ferrum `9ad6e6d`, production CeTA-CSR main `68bf6e9`: a fresh single-build
oracle-only replay retains **1,759/1,759 certified roots**, with no missing
inputs, losses, polarity changes, or uncertified decisions. Standard:
**1,338** (1,039 YES, 299 NO); Innermost: **311** (301 YES, 10 NO);
CSR: **110** (105 YES, five NO). Every new root CPF subsequently passed
two independent production CeTA checks. All **961 Rust library tests** and
**211 Python extraction tests** pass. CeTA did not change.

Validated oracle: `target/residual-state-audit-20260915/oracle-v19-candidate.jsonl`
(the filename retains its historical candidate suffix), SHA256
`60010c8485abd3cafe3d516ceaf0d3fdbdbb1cf16efa02254f50de2b1ae2178a`.
Complete-proof actions remain retired; root fallback remains disabled.
Artifacts under `target/residual-state-audit-20260915/`:
`witness-portability-root-guard-v1/details.json`,
`witness-portability-root-comparison-final.json`, and
`witness-portability-root-recheck.jsonl`.

The subsequent **v20 candidate** adds 14 independently checked native
residual continuations. Its complete child replay has **125/152**
twice-certified children, zero checker rejections, and 27 remaining gaps.
This is not a new root score; v20 has not yet passed a full root guard.
See [the residual audit](residual-state-audit.md).

## 2026-09-15 typed MU-TERM residual certification checkpoint

Ferrum `664febc` independently exports collapsing typed MU-TERM residuals.
CeTA-CSR main `68bf6e9` adds their standalone input, executable checks and
soundness connection, with regenerated Haskell. Complete `Proof_Checker`,
isolated Haskell export, production `make haskell`, and all **958 Rust library
tests** pass. No tests failed or were ignored.

The 152-child smoke replay now has **109 twice-certified children** (up from
107), **zero checker rejections**, and 43 remaining guidance/applicability
gaps. These include unused alternatives and are not root losses.

The retained root baseline remains **1,759**: Standard **1,338**, Innermost
**311**, CSR **110** (105 YES + five NO). Every retained root CPF passes
production CeTA twice. This is certificate revalidation, **not a new complete
proof-search replay**. The oracle remains `target/renaming-fixes-20260914/oracle-v14.jsonl`,
SHA256 `84b778e6f56eecf260ad12300956a8b61cdef26fdb874822c2c91c0a15acc972`.
Production checker SHA256:
`68867d65836cbee37a1dfda80bdc9cdf3ce8f45d10118cccb76ec0ca898402c1`.

Artifacts under `target/residual-state-audit-20260915/`:
`smoke-replay-v9/results.jsonl`, `smoke-checks-v9.jsonl`,
`muterm-checks-production-v2.jsonl`, `muterm-production-root-recheck.jsonl`.
See [the residual audit](residual-state-audit.md) for scope and remaining work.

## 2026-09-15 residual replay and primitive relocation checkpoint

Ferrum `2f54062` fixes primitive loop/nonloop relocation, preserves explicit
Q/NFS in standalone DP NO export, and prunes only proven automorphisms during
exact canonicalization. CeTA-CSR remains `3ddffbd`; the oracle is unchanged.

The retained baseline remains **1,759 certified roots**: Standard **1,338**,
Innermost **311**, CSR **110** (105 YES + five NO). A complete guard plus
23 explicit corrective Standard reruns retains every root and polarity.
This is **mixed-run validation**, not a new single-build full replay.
All retained certificates subsequently pass two CeTA checks and independent
benchmark-to-CPF input correspondence audits.

All **8,561** transforming action pairs pass independent residual equivalence.
The 152-child smoke replay has **107 twice-certified** children, zero checker
rejections, and 45 explicitly classified guidance/export/applicability gaps.
These include unused search alternatives and are not root losses.
**957 library tests pass**, none failed or ignored. Exact artifacts and the
remaining typed MU-TERM export obligation are recorded in
[the residual audit](residual-state-audit.md).

## 2026-09-15 compact probes and complete root correspondence

Ferrum `0b9eae5bacb507e352e51a3e25fbcb00fc5ba663` adds diagnostic-only
`probe-cpf --summary` and independent root audits; no processor, strategy,
oracle, or CeTA change. CeTA-CSR remains `3ddffbd` on main.

The retained **1,759 certified-root baseline is unchanged**: Standard 1,338,
Innermost 311, CSR 110. This is not a new proof-search replay. Instead,
independent parsers matched and production CeTA rechecked all retained root
certificates against their actual benchmark rules, strategy/map, and polarity.
All **1,649 Standard/Innermost** and **110 CSR** inputs pass, including new
injective spelling checks. See [the TRS audit](trs-root-input-audit.md).

The complete compact action audit has **14,375 actions / 28,750 executions**:
11,627 twice-certified terminals, 17,120 open transformations, three local
timeouts, **zero uncertified terminals and zero certified losses**. All nine
previous harness-timeout executions now finish. The two remaining slow actions
recover matching original/renamed outcomes in 180-second repeats; their
nontermination proofs certify twice. Composite actions remain disabled.

Artifacts under `target/probe-summary-root-audit-20260915`:

- `full-action-summary-60s/{results.jsonl,comparison.json}`.
- `local-timeouts-summary-180s/results.jsonl`.
- `trs-root-correspondence-injective.json` and `csr-root-correspondence-injective.json`.
- `library-tests.log`: **949 passed**, none failed or ignored; 40 focused Python
  audit/comparison tests also pass.
- `ferrum-release-v1`, SHA256
  `95575ef8d9c1074e3c32552090804d9ea6551a871cad94cb65d013de994224c6`.

The unchanged oracle/checker checksums are recorded in the prior checkpoint
below. The normal full probe report retains all residual contexts; compact
reports run only after the same validation/export, and are not proof evidence.

## 2026-09-15 all recorded standalone gaps closed; CSR inputs audited

Ferrum implementation: `90480a809bee85f7cbbb4b936faff5b85bc08b6f`
on `codex/aaecc-20260831` (`ferrum-aaecc`). CeTA-CSR implementation and
verified Haskell export: `3ddffbdb322fd091fb80c2adb681f17004cd3134` on `main`.

The complete no-fallback guard retains **1,759/1,759 certified roots**:
Standard **1,338** (1,039 YES + 299 NO), Innermost **311** (301 YES + 10 NO),
CSR **110** (105 YES + five NO). Exact-set comparison found zero losses,
missing/extra roots, polarity changes, or uncertified decisions. Every retained
CPF was subsequently rechecked twice with the final production checker.

All three recorded standalone-certification gap classes are closed:
**43/43 actions, 86/86 original/renamed executions**, each certified twice.
The final standalone-only corrections were additionally checked with another
complete CSR oracle-only replay: **110/110**, with **110/110 independent
benchmark-to-CPF rule/map/answer matches** and another two checks per CPF.
This is preservation and stronger auditing of the certified set, not new roots.

Artifacts under `target/standalone-gaps-20260915`:

- `root-guard-v11/{details.json,comparison.json,twice-rechecked.jsonl}`.
- `all-gaps-v13/results.jsonl`.
- `csr-final-v13/{details.json,twice-rechecked.jsonl}` and
  `csr-root-correspondence-final-v13.json`.
- Final `ferrum-release-v13`, SHA256
  `097d44c6747696997df72da92655e39f14161b1ce6904a61b440907a3068460c`.

Production `CeTA-CSR/ceta` SHA256:
`2ebcb81adf0a62ceb539f5046c46da1d20d2a3fea013ad5cca34d778db85e96a`.
The oracle remains `target/renaming-fixes-20260914/oracle-v14.jsonl`, SHA256
`84b778e6f56eecf260ad12300956a8b61cdef26fdb874822c2c91c0a15acc972`.
**947 Rust library tests passed**, zero failures/ignored; independent audit
and comparison tests passed. Isabelle `Proof_Checker`, verified export,
`make haskell`, and `git diff --check` passed. No composite actions were enabled.

See [standalone gap details](standalone-csr-dp-certification.md) and the
[root audit's formal signature scope](csr-root-input-audit.md). Unrelated
CeTA ROOT/outermost work remains outside these commits.

Full post-repair modular-action audit (same frozen binary/checker): **14,375
actions / 28,750 executions**, with **11,627 twice-certified terminals**, 17,111
open transformations, zero uncertified terminals, and zero certified losses.
Twelve runtime-limited executions across nine actions all recover in a
four-worker, 180-second repeat, with matching original/renamed outcomes (eight
transformations and one twice-certified nontermination action). This does not
change the root baseline or claim universal 60-second replay. Results and
comparison: `target/standalone-gaps-20260915/full-action-audit-v13`; relaxed
repeat: `target/standalone-gaps-20260915/slow-action-audit-v13-180s`.

## 2026-09-15 standalone CSR-DP certification: certified-root parity

Ferrum implementation: `743c9a60fbef0ac7311f7bae671e2e8014784d66`
on `codex/aaecc-20260831`, in `ferrum-aaecc`.
CeTA-CSR implementation and refreshed verified Haskell export:
`58632f3b06095922b6443fee5e00662670ce9bcc` on `main`.

The final oracle-only, no-fallback guard preserves **1,759/1,759** certified
roots: Standard **1,338** (1,039 YES + 299 NO), Innermost **311** (301 YES +
10 NO), and CSR **110** (105 YES + 5 NO). No missing/extra roots, losses,
polarity changes, or uncertified decisions. Every final root CPF passed two
additional production-CeTA checks (3,518 checks), with stable hashes.
This preserves the certified-root set, not a new full-category coverage score.

Six improved-CSR modular actions now certify independently under original and
renamed symbols. The new typed standalone entry preserves the replacement
map, active rules, and CSR minimality; ordinary-DP context coercion is removed.
Other standalone CSR frameworks remain explicitly unsupported, not silently
reinterpreted. See [standalone-csr-dp-certification.md](standalone-csr-dp-certification.md)
for the full 14,375-action audit, its remaining gaps, and build timings.

Artifacts under `target/csr-standalone-boundary-20260914`:

- `root-guard-final-v5/{details.json,comparison.json,twice-rechecked.jsonl}`.
- `full-action-audit-v5/results.jsonl` and `full-action-audit-summary.json`.
- `production-full-tests-v5.log`: **944 passed**, none failed or ignored.
- `ferrum-release-v5`, SHA-256
  `59ac47d5126721518c1ba0c8ece5880a3cdae492b8242d85f18fbf2aa156fa07`.

The unchanged oracle is `target/renaming-fixes-20260914/oracle-v14.jsonl`,
SHA-256 `84b778e6f56eecf260ad12300956a8b61cdef26fdb874822c2c91c0a15acc972`.
The guard used 48 workers, two Rayon threads, and 180/185-second strategy/harness
ceilings. Composite proof strategy actions remain disabled.

Production checker: `/work/dfm/festschrift/CeTA-CSR/ceta`, SHA-256
`067a10b13250a0254b9ac5804e9d2400391c57a9c2464e286986231094a65cfa`.
The isolated `Proof_Checker` and Haskell-export sessions, `make haskell`,
positive/mutation-negative tests, and Python audit/comparison tests passed.
Unrelated dirty CeTA ROOT/outermost work was excluded from the commit.

## 2026-09-14 renaming and witness-transport recovery: certified-root parity

Ferrum implementation: `9d6adc3f3981dd82bff5e54f08781730536e050c`
on `codex/aaecc-20260831`, in `ferrum-aaecc`.
All **38 differing action cases** and **24 uncovered witness transports**
now recover matching original/renamed behavior. The combined audit is
**62/62 equal**, with 46 terminal proofs each checked twice. Its other
78 executions are open transformations, not certified terminal results.

The final state-local, no-fallback certified-root guard preserves
**1,759/1,759**: Standard **1,338** (1,039 YES + 299 NO), Innermost **311**
(301 YES + ten NO), and CSR **110** (105 YES + five NO). There are zero
missing inputs, losses, polarity changes, or uncertified decisions.
Every retained root CPF passed two additional CeTA checks (3,518 successful
checks), with stable hashes. This is preservation of the certified-root set,
**not a new full-category coverage score**.

Artifacts under `target/renaming-fixes-20260914`:

- `final-guard-v18-oracle-v14/{details.json,comparison.json,twice-rechecked.jsonl}`.
- `unified-62-v18/results.jsonl` and `unified-62-v18-equivalence.jsonl`.
- Latest monotone oracle: `oracle-v14.jsonl`, SHA-256
  `84b778e6f56eecf260ad12300956a8b61cdef26fdb874822c2c91c0a15acc972`.
- `oracle-v14-audit.json`: 517,541 states, 20,917 modular witnesses;
  no complete termination/nontermination actions, malformed records, or dangling references.
- Frozen executable `ferrum-v18`, SHA-256
  `f5efc40a06bc8d69ba96c47376ca87e8125025dfd23ab3a779c84bdcc66347bf`.

The guard used 48 workers, two Rayon threads, a 180-second strategy ceiling,
and a 185-second harness ceiling. One standalone renamed nontermination
search still takes about 74 seconds in isolation; recovery is not a claim
of timing invariance. All 942 Rust tests passed with four test threads,
none ignored; the earlier isolated concurrent SMT closed-pipe failure and
all Python verification are documented in
[renaming-audit-recovery.md](renaming-audit-recovery.md).

No CeTA changes were needed or made by this task. Production certification
used `/work/dfm/festschrift/CeTA-CSR/ceta`, unchanged SHA-256
`a6d8977c1738daa3e225f0e52443fb56659d09b175516d4215bcd77a3bf0ab46`,
at the `main` source checkpoint `b018e39ca3d4de9a1fe1e50df2b4feecd2ede6f5`.
Unrelated uncommitted work in that shared tree was left untouched.

## 2026-09-14 inherited-continuation retirement: certified-root parity

Ferrum implementation: `b3b32abd577d058b2d2eb8f4bc7ee9d258c02943`
on `codex/aaecc-20260831`, in `ferrum-aaecc`. Strict oracle-only replay now
discards inherited pipeline tails at residual boundaries and obtains the next
action from the child state. Ordinary non-oracle strategies are unchanged.

The unified state-local, no-fallback guard retains **1,759/1,759**:
Standard **1,338** (1,039 YES + 299 NO), Innermost **311**
(301 YES + ten NO), CSR **110** (105 YES + five NO). There are zero losses,
missing inputs, polarity changes, or uncertified decisions. Every retained
CPF passed two additional CeTA checks with unchanged hashes. This preserves
the certified-root set, **not a new full-category high-water mark**.

Artifacts under `target/state-local-modularity-20260914`:

- `final-replay-v1/details.json` and `comparison.json`: unified guard.
- `oracle-state-local-v1.jsonl`: monotone oracle, SHA-256
  `fd0d35f05132c29a1632b7a879a7f41cad2678ba3e1bd96e0650da6be1ce0fbf`.
- `oracle-audit-v1.json`: no composite proof actions or dangling references.
- `ferrum`: guard executable, SHA-256
  `36eec759470e663939d845e655ce274e09b677638c5551360398d9378d3c7190`.
  This initial executable used `FERRUM_ORACLE_STATE_LOCAL_ONLY=1`; the
  committed policy enables identical scheduling from the no-fallback flag.
- `ferrum-v4`: final independent-probe/export executable, SHA-256
  `990f76c331eedd0f1f4c2a4cd3ad1e6ccab620ae30c2929a883c5a3551090300`.
  Additional fixes affect standalone probe exports, not root proof search.

Production CeTA is unchanged at the checker/source checkpoint below.
939 Rust library tests passed; independent-action audits and their remaining
standalone-CSR/renaming boundaries are documented in
[state-local-modularity.md](state-local-modularity.md). Do not confuse open
action fragments or diagnostic probe failures with certified-root totals.

## 2026-09-09 wrapper retirement: certified-root parity

Verified Ferrum implementation commit:
`365315e65841dbff896292ffd0f972b87a9d4344` on `codex/aaecc-20260831`
in `ferrum-aaecc`. Complete TRS/DP termination **and nontermination** proof
actions now fail unconditional assertions at parsing and execution.

The unified oracle-only, no-fallback regression guard preserves all **1,759
previously certified roots**: Standard **1,338** (1,039 YES + 299 NO),
Innermost **311** (301 YES + ten NO), CSR **110** (105 YES + five NO).
Exact root sets and polarities match r985, with zero losses, input-set changes,
or uncertified decisions. Every certificate passed two additional production
CeTA checks (3,518 invocations); retained proof hashes were verified afterward.
Previously unresolved inputs were not rerun, so this is a baseline-preserving
certified-root guard, **not a new full-category high-water mark**. The complete
category denominators below remain authoritative.

Artifacts, relative to `ferrum-aaecc/target/guarded-role-ab-20260909/`:

- Replay: `final-certified-root-replay-v1/{details.json,comparison.json,run/}`.
- Oracle: `oracle-no-composite-v13.jsonl`, SHA-256
  `60f1e090e50db02f329ffc1d8c47fca2ec77e9c4a2e954c1afd2d2688c4a4297`.
- Audit: `no-composite-audit-v13.json`: 517,008 states, 20,762 witness
  definitions; zero complete proof actions, dangling references, or malformed
  records.
- Frozen binary: `ferrum-modular-no-v11`, SHA-256
  `bce5cce9b76bc8678f19c519251e79ed77c9d558494c6c55a1d930b173448759`.

CeTA-CSR unchanged at `b018e39ca3d4de9a1fe1e50df2b4feecd2ede6f5`, checker
SHA-256 `a6d8977c1738daa3e225f0e52443fb56659d09b175516d4215bcd77a3bf0ab46`.
Verification: 936 Rust library tests, binary/doc targets, 226 focused Python
tests, and `git diff --check` passed; no tests ignored. Root allowances:
300 seconds Standard/CSR, 1,200 seconds Innermost, five-second harness margins;
32 concurrent roots and two Rayon threads each. Details:
[oracle modularity and witness dependence](oracle-modularity-and-witness-dependence.md).

## 2026-09-09 complete modular oracle replay (r985)

Verified Ferrum source checkpoint: `9a881bd5952b470629921b427b37935d3a1e57f0`
on `codex/aaecc-20260831` in `ferrum-aaecc`.

Full oracle-only, **no-fallback** replay preserves **1,338/1,542 Standard**,
**311/366 Innermost**, and **110/110 CSR**, without any complete DP/TRS
termination-proof oracle atoms. These are identical certified root sets to
r982: zero losses, gains, polarity changes, input-set changes, or checker
failures. Standard: 1,039 YES + 299 NO; Innermost: 301 YES + ten NO;
CSR: 105 YES + five NO. All **1,759 certificates** passed two additional
independent production CeTA checks with unchanged proof digests.

Artifacts: `target/modular-recovery-r985/final-replay-v278/{standard,innermost,csr}`.
Each contains `details.json`, exact `comparison.json`, `rechecks.jsonl`, and
retained root CPFs/events. Unresolved: Standard 201 MAYBEs + three timeouts;
Innermost 55 MAYBEs; CSR none.

Frozen binary: `target/modular-recovery-r985/ferrum-v275`, SHA-256
`b9664c9a32e587394e5e0adf0ecb3784283461b84999c140e3e200c0c191d68a`.
Global modular oracle: `target/modular-recovery-r985/oracle-direct-native-v271.jsonl`,
SHA-256 `be9686532b358ad5ffab0f9b9f555e29341669b49c24350060920a76efb4fd3d`.
Audit: `target/modular-recovery-r985/oracle-audit-v274.json`; 515,798 state
records, 19,931 witness definitions, zero dangling witness references or
complete termination-proof atoms. Complete nontermination certificates were
outside this ablation and remain enabled.

CeTA-CSR unchanged on main at `b018e39ca3d4de9a1fe1e50df2b4feecd2ede6f5`,
binary SHA-256 `a6d8977c1738daa3e225f0e52443fb56659d09b175516d4215bcd77a3bf0ab46`.
Tests: 922 Rust tests passed, zero failed/ignored, plus binary/doc targets;
196 extraction tests and the focused recovery-script suites passed.
`git diff --check` passed. Configuration and recovery history:
[modular oracle recovery](modular-oracle-recovery.md).

Root allowances were 300 seconds Standard/CSR and 1,200 seconds Innermost,
with five-second harness margins. No 60-second replay or default-search
performance parity is claimed. The earlier production v54 file is retained;
the modular oracle above is the new verified replay artifact.

## 2026-09-08 complete post-cleanup oracle replay (r982)

Verified Ferrum source checkpoint: `4f97b3a5a4ccc3f70778951c1a11984e22bf7e62`
on `codex/aaecc-20260831` in `ferrum-aaecc`.

The final post-cleanup replay preserves **1,338/1,542 Standard**, **311/366
Innermost**, and **110/110 CSR** certified decisions. All category root sets
match their baselines, with zero losses, gains, polarity changes or checker
failures. Standard: 1,039 YES and 299 NO; Innermost: 301 YES and ten NO;
CSR: 105 YES and five NO. All 1,759 produced positive/negative certificates
also passed a second independent production CeTA check.

Artifacts: `target/embedded-cleanup-final-r982/{standard,innermost,csr}`;
exact comparison: `target/embedded-cleanup-final-r982/comparison.json`.
Oracle v54: `target/embedded-cleanup-ta-r976/oracle-v54.jsonl`, SHA-256
`778a4f08842209866538865d254da0a7503d8c9b67a69460ef7a3efc37e84c56`.
Ferrum binary SHA-256:
`3a7f6f8c324f4a28fe138fc832453c3216000afd64cc70f9de316b2482b23cb0`.
CeTA-CSR unchanged at `b018e39ca3d4de9a1fe1e50df2b4feecd2ede6f5`, binary
SHA-256 `a6d8977c1738daa3e225f0e52443fb56659d09b175516d4215bcd77a3bf0ab46`.
Configuration and test accounting: `docs/embedded-evidence-cleanup.md`.
No default-search performance parity is claimed.

## 2026-09-08 replay audit caveat (historical; resolved by r982)

**Post-removal verification:** r974 reproduced **1,338/1,542 certified**
(1,039 YES, 299 NO), with zero losses, gains, polarity changes or certification
failures against r973, in 665 seconds. Root sets are identical. The compiled
witness registries, implicit aabb dispatch and fixed pair2hard matrix shortcut
were absent from production. Artifacts: `target/embedded-cleanup-r974`.
The exact binary, checker and configuration are recorded in
`docs/embedded-evidence-cleanup.md`. This establishes Standard oracle replay
parity after these removals; structural audit and CSR/Innermost checks remain
unfinished. The earlier caveat below records the reason this replay was needed.

The subsequent complete r973 Standard replay certified **1,338/1,542**
(1,039 YES, 299 NO, 200 MAYBE, four timeouts, zero certification failures).
Artifacts: `target/standard-next-frontier-20260903/full-standard-r973-global1338-v53`.
The five gains are Hydras lepper_4, lepper_5, lepper_6, lepper_8 and lepper_9.
However, an audit found an implicit compiled aabb certificate attempted
before guidance. Consequently, strict oracle-only attribution of this and
earlier runs is provisional, even though the certified decisions remain valid.
Do not use these totals as a post-cleanup oracle-only baseline. The checkpoint
is `a73daad`; cleanup and fresh protected-category replays are tracked in
`docs/embedded-evidence-cleanup.md`.

## 2026-09-08 complete Standard replay: 1,333 certified roots

The previously reported complete strict oracle-only TRS Standard mark was
**1,333/1,542 certified decisions**: 1,039 YES, 294 NO, 205 MAYBE, and four
timeouts. On the exact published TermCOMP 2026 set this is **1,324/1,528**:
1,031 YES and 293 NO, eleven certified decisions above AProVE26's 1,313 raw
answers. Every reported YES/NO was accepted by production CeTA-CSR; there
were zero parse, processor, unsupported-feature, checker, checker-timeout, or
missing-CPF failures.

The two gains over the preceding complete 1,331 replay are
`Zantema_15/ex14.ari` and `payet_21/payet-nonloop-1.ari`. Ferrum recognizes
their renaming-invariant counter-transfer/duplication schemes and emits the
same two-state regular recurrent-language certificate. CeTA independently
proves that this language is nonempty, rewrite closed, and contains no normal
form. Exact root-set comparison has precisely these gains, no loss, and no
polarity change.

Integration exposed general residual-state defects: materialized DP states
lost the fact that active rules were a certified residual; exact rewriting
retained stale rule-local variable names; and mathematical-core aliases could
admit a generic transformation and override the recorded continuation.
Ferrum now serializes the residual marker, restores live rule spellings,
limits core aliases to recomputed terminal processors, and uses lookup-only
compatibility aliases for certified pre-marker states. Exact reduction-pair
projection retains the incoming mathematical R only below a genuine active
usable-rule restriction. Focused regression replay recovered all fourteen
temporarily displaced roots before the complete run.

Authoritative artifacts:

- complete replay:
  `target/standard-next-frontier-20260903/full-standard-r967-global1333-v52`;
- final monotone oracle:
  `target/standard-next-frontier-20260903/regular-ta-integrate-r966/oracle-v52.jsonl`;
- oracle SHA-256:
  `c754a77707557fbdff6c1e00a32a44261fe33c62bc5985b7f249e0b6bd54af28`;
- certified causal evidence and focused replay:
  `target/standard-next-frontier-20260903/post1329-low-effort-r938/Ex5-context-fix/oracle-root-v39`
  and `OvCons-iGM-aprove/strict-v51-60s`.

The complete run used 64 workers, two Rayon threads per worker, a 65-second
harness ceiling, `timeout(60s, fail)`, no top-level model, and
`FERRUM_DP_LLM_NO_FALLBACK=1`. The protected complete category baselines are
**110/110 CSR** and **311/366 Innermost**. The concurrent preservation run is
`protected-r968-global1333-v52`; its sole timeout was the known borderline
`PALINDROME_nokinds_iGM`, which then certified in the isolated replay
`palindrome-preserve-r969-v52`.

## 2026-09-06 root-input preservation correction

The latest certificate-preservation audit found that the generic
`switch-csr` exporter did not encode a transformation proof.  It silently
replaced the original full or innermost TRS in the CPF input by the recognized
context-sensitive child and then certified that different problem.  All such
evidence is quarantined.  Ferrum now refuses to schedule or serialize the
processor, and the oracle exporter can remove inherited `switch-csr`
candidates globally.

This correction supersedes the 1,284 Standard and 318 Innermost claims below.
Of the affected roots, four Innermost problems were recovered by
root-preserving proofs (three verified GM04 inversions and one direct loop).
Fresh complete strict replays establish the corrected totals:

- TRS Standard: **1,283/1,542** certified;
- TRS Innermost: **311/366** certified;
- CSR: **110/110** certified and unaffected.

The quarantined strict replay is
`target/standard-next-frontier-20260903/switch-csr-quarantine-r752`.
The four recovered roots replay oracle-only from
`target/standard-next-frontier-20260903/switch-csr-recover-r753`; all four
root-preserving CPFs passed CeTA.  Complete Innermost and CSR preservation
runs are under `root-preserving-full-r756`; the Innermost result is 301 YES,
10 NO, and 55 MAYBE, while CSR remains 105 YES and five NO.  The corrected
complete Standard run is `root-preserving-full-r757`, with 996 YES, 287 NO,
254 MAYBE, and five timeout results.  Every reported decision was accepted by
production CeTA, with zero parse, processor, checker, or missing-CPF failure.
The cleaned oracle is `oracle-r753-root-preserving.jsonl` (SHA-256
`1d4131d9b14d05cda07529bfa6bd9bea9308c26aded9dbd54b92dbc0946d1ad7`).
The historical sections remain below to document earlier runs, but their
headline totals are superseded by this correction.

## 2026-09-07 Hydras/lepper_3 Standard gain

The latest complete root-preserving Standard replay establishes
**1,284/1,542 certified decisions**: 996 YES, 288 NO, 252 MAYBE, and six
timeouts.  `Hydras/lepper_3.ari` is the sole new decision relative to the
corrected 1,283 replay; no prior certified root was lost.  Ferrum uses a
compact three-step mixed DP/TRS loop, checked against the live rules and
dependency pairs before certificate construction.  It is found by the
default strategy in 18 ms and replays recursively from three independent
oracle states (root DP, exact unused-pair removal, terminal DP loop).

The complete replay is
`target/standard-next-frontier-20260903/root-preserving-full-r760/standard`.
All 1,284 retained CPFs were then accepted twice by production CeTA
(2,568 checker invocations, zero failures) in `standard-ceta-twice-audit`.
The monotone oracle is
`target/standard-next-frontier-20260903/lepper3-integrate-r759/oracle-r759-global1284.jsonl`
(SHA-256
`d21f364b01408faae78939b3f8bce4298733b177d12e581fb916e0a2e6eb8f06`).
Focused strict preservation checks also retain CSR `Ex14_Luc06`, Innermost
`#4.29`, and Standard `MNZ_10/nvsr` with production certification.

## 2026-09-07 portable recursive-DP Standard gains

The latest complete root-preserving Standard replay establishes
**1,288/1,542 certified decisions**: 997 YES, 291 NO, 247 MAYBE, and seven
timeouts.  Relative to the preceding corrected 1,284 replay, the four new
decisions are:

- certified YES: `Transformed_CSR_04/LengthOfFiniteLists_complete_noand_iGM.ari`;
- certified NO: `Transformed_CSR_04/LengthOfFiniteLists_complete-noand_FR.ari`,
  `Transformed_CSR_04/LengthOfFiniteLists_complete-noand_Z.ari`, and
  `Transformed_CSR_04/OvConsOS_nokinds_FR.ari`.

The iGM proof is not retained as one opaque top-level proof.  Its root DP,
graph decompositions, and 95 sequential exact reduction-pair transformations
are replayed from independently canonicalized live residuals.  Portable exact
reduction pairs now extend a verified unmarked TRS symbol isomorphism to the
corresponding marked DP symbols and then recheck the complete pair and rule
multisets.  This recovers renamed residuals without weakening exact witness
validation.  The campaign materializer executes a certified historical chain
only to expose current live residuals; the exported guidance remains
state-local at every edge.

The complete strict replay is
`target/standard-next-frontier-20260903/full-standard-r824-global1286`.
It used 64 isolated workers, two Rayon threads each, a 65-second harness,
`timeout(60s, fail)`, no top-level model, and
`FERRUM_DP_LLM_NO_FALLBACK=1`.  Every one of the 1,288 generated decisions was
accepted by production CeTA-CSR, with zero parse, processor, checker, timeout,
or missing-CPF certification failures.  Full preservation replays against the
same oracle retain CSR at **110/110** (105 YES, five NO) in
`full-csr-r825-global1288` and Innermost at **311/366** (301 YES, ten NO) in
`full-innermost-r826-global1288`, also with zero certification failures.

`Transformed_CSR_04/MYNAT_complete_noand_iGM.ari` also replays with fallback
disabled and its complete 97-step recursive reduction-pair chain is accepted
twice by CeTA-CSR.  It takes 57 seconds in isolation but crossed the 60-second
prover boundary under the 64-worker replay, so it is recorded as replayable
evidence rather than included in the 1,288 high-water count.  The strict
artifacts for both large iGM proofs are in
`cpf2-integrate-r823/strict-complete-final`.

The monotone oracle is
`target/standard-next-frontier-20260903/cpf2-integrate-r823/oracle-complete-final-merged.jsonl`
(SHA-256
`ed7d30540ab38dfc4a7f7943531da6e3f5396305af4855d6e0d492e0b39cd3b8`).
Ferrum commit `ac28f90` contains the portable replay and strict-scheduler
fixes.  Production CeTA-CSR is commit `4cda18b`; no checker change was needed
for these gains.  The focused Python extraction/materialization suite passes
176 tests, the relevant top-level scheduler and exact-reduction Rust tests
pass, the release build succeeds, and `git diff --check` is clean.

## 2026-09-07 causal runtime-path integration and 1,289 Standard roots

The current complete root-preserving Standard replay establishes
**1,289/1,542 certified decisions**: 998 YES, 291 NO, 247 MAYBE, and six
timeouts.  `Transformed_CSR_04/MYNAT_complete_noand_iGM.ari` is the sole gain
relative to the corrected 1,288 replay, and no previously certified root is
lost.  Its complete 97-reduction-pair proof now replays under 64-worker load
in 29.1 seconds (20 seconds isolated), rather than crossing the 60-second
prover ceiling.

The integration defect was ambiguous residual attachment.  Thirty-seven
isomorphic-looking DP components each received 11--19 sibling exact witnesses,
causing 395 failed reduction-pair relocations before the correct choices were
found.  Ordinary-DP canonicalization now preserves the semantic association
between every marked symbol and its unmarked base.  A lookup-only legacy alias
keeps the older certified union reachable, while all new evidence uses the
safer identity.  More importantly, the new certified-runtime-path extractor
accepts only a uniquely closed causal tree: every residual must have a
continuation, no cycle is permitted, ambiguous complete continuations are
rejected, and disconnected/abandoned successful trials are excluded.  It
rechecks the complete CPF twice before emitting exact raw-state gates.  The two
large iGM proofs consequently produce 274 guidance rows for 274 distinct
states, with no cross-product pooling.  MYNAT now has zero failed exact-witness
attempts.

Authoritative artifacts:

- final oracle:
  `target/standard-next-frontier-20260903/cpf2-integrate-r823/oracle-global1289-preserved.jsonl`;
- oracle SHA-256:
  `cba39e0686ec42ed288b253882c928c7503f43c7689038a6583baaa037ca1fc4`;
- final Standard replay:
  `target/standard-next-frontier-20260903/final-r831-global1289/standard`
  (zero checker failures; exact root-set gain 1, loss 0);
- final CSR replay:
  `target/standard-next-frontier-20260903/final-r831-global1289/csr`
  (**110/110**, 105 YES and five NO, zero failures);
- final Innermost replay:
  `target/standard-next-frontier-20260903/preserve-r830-global1289/innermost`
  (**311/366**, 301 YES and ten NO, exact prior root-set parity, zero failures);
- causal rows, certification manifest, focused replays, and export reports:
  `target/standard-next-frontier-20260903/cpf2-integrate-r823`.

Production CeTA-CSR remains commit `4cda18b`; no checker source change was
needed.  The final MYNAT and Innermost Length CPFs were independently accepted
twice by that checker.

## Current TPDB-ARI Innermost TRS

### Strict oracle-only replay: 318/366 certified (twenty-one above AProVE raw parity)

Revalidated 2026-09-06 against TPDB-ARI commit `183f29db` and the current
monotone global oracle:

- certified YES: **309**;
- certified NO: **9**;
- MAYBE: **48**;
- timeout: **0**;
- error or certification failure: **0**;
- total certified decisions: **318/366**.

The current production-checker preservation replay is
`target/standard-next-frontier-20260903/gm04-preserve-r744/full-innermost`.
All 318 generated CPFs were accepted during replay and accepted twice again in
`full-innermost-ceta-twice-audit` (636 checker invocations, zero failures).

This is twenty-one decisions above AProVE 2025's raw 297/366 decisions (290 YES
and 7 NO) and 50 decisions above AProVE's 268/366 certified result. It extends
the preceding 310/366 v1494 high-water mark without losing any root or
producing a rejected certificate. The five gains are
`Transformed_CSR_innermost_04/Ex1_2_AEL03_C.ari` and
`Transformed_CSR_innermost_04/ExAppendixB_AEL03_C.ari`, plus
`Transformed_CSR_innermost_04/OvConsOS_nokinds_C.ari` and
`Transformed_CSR_innermost_04/Ex1_GM03_C.ari`, plus
`Transformed_CSR_innermost_04/ExIntrod_Zan97_C.ari`. All five use the
complete verified GM04 inverse transformation and close strictly from
recursively indexed oracle states; `Ex1_GM03_C` takes 5.01 seconds in the
complete replay and the others take under four seconds.

The newest gain is
`Transformed_CSR_innermost_04/Ex6_15_AEL02_C.ari`. Its complete GM04 source
obligation uses improved CS-DPs and graph decomposition. A stale ordinary-DP
fragment with an empty usable-rule set was rejected by Ferrum's native U3
reconstruction check and replaced by a certified three-dimensional Arctic U3
deletion, graph decomposition, polynomial deletion, and size-change closure.
The independent 131-pair transformed obligation decomposes into seventeen
SCCs; sixteen have ordinary certified closures and the exact two-pair top SCC
is discharged by the checker-verified complete-GM04 theorem. Strict replay
takes 12.116 seconds in isolation and 77.112 seconds under the 64-job load.

The preceding gain is
`Transformed_CSR_innermost_04/LISTUTILITIES_complete_C.ari`. Its verified
GM04 source obligation uses improved CS-DPs, graph decomposition, four
recursive two-dimensional natural-Arctic usable-rule deletions, and
graph/subterm/size-change closure; the independent transformed obligation is
closed by graph decomposition, usable rules, and exact path orders. Exact
recursive CSR replay now preserves the certified usable-rule component as its
typed child transformation context, matching the synthesizing processor and
making every continuation state directly addressable. The complete replay
lost no prior decision and certified this root in 24.022 seconds under load.

The subsequent gain is
`Transformed_CSR_innermost_04/LISTUTILITIES_nokinds_C.ari`.  Its source CSR
closes by improved CS-DPs, graph decomposition, instantiation, two recursive
U3 reduction-pair deletions, a second graph split, usable rules plus a
polynomial deletion, and subterm plus graph closure.  Every child is keyed
independently; strict replay uses `timeout(60s, fail)` with
`FERRUM_DP_LLM_NO_FALLBACK=1` and takes 8.507 seconds under the 64-job load.

The current preservation replay is
`target/innermost-gm04-integration-20260828/full-strict-v1599-ex6-15-ael02-c`.
It validates every exact CSR dependency-graph witness against
the live checker graph, including CeTA's default-active replacement map for a
fresh improved-CS-DP unhiding symbol. All 318 decisions are certified and no
positive-looking stale graph fragment is promoted.

The monotone oracle is
`target/innermost-gm04-integration-20260828/oracle-v1596-ex6-15-ael02-c-complete-proof.jsonl`
(SHA-256
`a604ed62bdfd419644aee73d3b5d440ee8612fff54c61bde5944d3b49088da40`).
Ferrum commit `9739fe9` contains the replay implementation; production CeTA
commit `e52c7ce` required no change.  The complete replay has zero fallback,
timeout, error, checker rejection, or prior-root loss. Its deterministic
audit rechecked the preceding 317 CPFs twice, and the new producing and strict
CPFs were each checked twice (zero failures).

Explicit verified GM04 routing also retains the earlier transformed-CSR `_C`
roots:

- `Ex3_2_Luc97_C.ari` and `Ex5_7_Luc97_C.ari`;
- `LISTUTILITIES_nokinds_noand_C.ari` and
  `LISTUTILITIES_nosorts_noand_C.ari`;
- `LengthOfFiniteLists_complete_C.ari` and
  `LengthOfFiniteLists_complete_noand_C.ari`;
- `MYNAT_complete_noand_C.ari`;
- `OvConsOS_complete_C.ari` and `OvConsOS_nokinds_noand_C.ari`;
- `PEANO_complete_noand_C.ari`.

Six further positive-looking explicit GM04 results were quarantined because
production CeTA rejected their processor chains. The monotone oracle therefore
contains no promotion from those rejected proofs. Exact dependency-graph
witnesses are additionally bound to their CSR replacement map, construction,
graph estimator, and QCS-usable-rules mode; a graph from another CSR context
cannot be relocated merely because its TRS and pair sets are isomorphic.

The v1453 gain consists of fifteen transformed-CSR `_C` encodings:

- `Ex14_Luc06_C.ari`, `Ex1_Luc02b_C.ari`, and `Ex3_12_Luc96a_C.ari`;
- `Ex4_7_37_Bor03_C.ari`, `Ex4_7_56_Bor03_C.ari`, `Ex4_DLMMU04_C.ari`,
  and `Ex4_Zan97_C.ari`;
- `Ex7_BLR02_C.ari`, `Ex8_BLR02_C.ari`, `Ex9_Luc04_C.ari`, and
  `ExIntrod_GM99_C.ari`;
- `ExSec4_2_DLMMU04_C.ari`, `LISTUTILITIES_nosorts_C.ari`,
  `LengthOfFiniteLists_nokinds_noand_C.ari`, and
  `MYNAT_nokinds_noand_C.ari`.

Ferrum recognizes the complete GM04 transformed encoding and invokes a verified
inverse transformation. The certificate contains two independent, complete
proof obligations: termination of the reconstructed source CSR and termination
of the transformed residual. Extraction materializes both typed children and
recursively indexes their proof chains. The `dpTrans` wrapper inside GM04 is
presentation syntax for the already established private residual, so its DP
child is indexed directly rather than promoting a context-losing root
fragment.

The strict scheduler treats only the exact GM04 residual assumption as terminal:
the verified enclosing checker matches its pairs, rules, Q context, symbols,
and source CSR proof. This is not a generic assumption escape hatch. Runtime
atoms are retained in proof-chain-only mode only when the same deterministic
processor family is structurally present in the twice-certified CPF, and all
nested states remain independently addressable.

Main CeTA now contains the complete mechanized GM04 transformation theorem,
its executable checker, top-level CPF parser wiring, and direct parsing of the
nested CSR proof used by `Ex14_Luc06_C`. `Proof_Checker`, `IsaFoR_3`, and `Code`
built successfully in an isolated Isabelle output. The 395-module Haskell
export compiled into the production checker.

Attested versions for the v1510 high-water mark:

- Ferrum: `78de242` (`Complete strict GM04 residual replay`);
- CeTA: `e52c7ce` (`Generalize complete GM04 residual certification`);
- TPDB-ARI: `183f29db` (`secret benchmarks 2026`).

The v1510 strict replay used `timeout(60s, fail)`, disabled the top-level LLM,
set `FERRUM_DP_LLM_NO_FALLBACK=1`, and ran 64 roots concurrently with two Rayon
threads per process. Every one of the 315 generated positive or negative CPFs
was accepted during the replay. A subsequent independent audit checked every
proof twice with production CeTA: 315/315 passed (630 checker invocations),
with no rejected proof.

Authoritative artifacts:

- oracle:
  `target/innermost-gm04-integration-20260828/oracle-v1510-exintrod-zan97-c.jsonl`;
- oracle SHA-256:
  `02235481683ef7de5e840021b3c90fd289261866580619e0a34a46c0980e1e07`;
- replay summary:
  `target/innermost-gm04-integration-20260828/full-strict-v1511-exintrod-zan97-c/summary.jsonl`;
- all per-root CPFs and processor events:
  `target/innermost-gm04-integration-20260828/full-strict-v1511-exintrod-zan97-c/per-problem`;
- independent twice-per-proof checker audit:
  `target/innermost-gm04-integration-20260828/full-strict-v1511-exintrod-zan97-c-twice-audit/{results.tsv,summary.txt}`;
- generated production checker:
  `../CeTA/target/gm04-signature-export-20260829/ceta-gm04-signature`;
- production checker SHA-256:
  `92f1a1453b29f45af2bcb28fcdce58967b73c61e5ffa256e9012aac3bcf558d5`.

Verification passed 126/126 focused extraction tests and all focused GM04
solver tests. The full Rust library suite passed 812 tests and had one
persistent-Z3 stdout closure under aggregate concurrency; that exact test
passed three immediate isolated repetitions. The release build,
repository-wide `cargo fmt --check`, and `git diff --check` passed. The source
theories built through `Proof_Checker`; the 395-module Haskell export compiled,
and the resulting executable is byte-identical to production `CeTA/ceta`.

The final integration defect was a lossy GM04 worklist cycle key. It hashed
only pair identity and boolean/cardinality summaries, so a valid reduction-pair
child or a distinct usable-rule residual could be discarded as an ancestral
cycle. The key now hashes every mutable residual component while excluding
only the immutable generated source context. Extraction also recognizes empty
terminal nodes, exact graph steps across private runtime bookkeeping, flat
category-qualified artifacts, content-addressed children, and the harmless
presence or absence of zero-arity replacement-map entries. These are exact
state bridges; replay still validates every atom against its live obligation.

The pooled v1431 experiment is quarantined and must not be used: a root-local
reduction-pair fragment was applied in the wrong live context and CeTA-CSR
rejected it. v1439 instead descends from clean v1429 through causal rounds of
twice-certified complete proof chains.

The following paragraphs retain the earlier campaign history for provenance.

The v1142 replay was four decisions above the preceding 233/366 high-water
mark. Relative to the immediately preceding 232-result reference run, v1138 added
`Ex1_Luc04b_iGM`, `Ex4_7_56_Bor03_iGM`, `MYNAT_complete_C`, and
`PALINDROME_complete_noand_iGM`, reaching 236 with no losses. The subsequent
recursive replay of the archived certified proof for `Ex24_Luc06_C` raised
v1142 to 237, again without a loss.

The v1143 monotone extension integrates ten newly generated default-strategy
proof traces. Seven roots already had an older strict proof, while the new
evidence closes Applicative AG01 `#4.3`, `#4.13`, and `#4.19`. The complete
strict replay therefore reaches 240 with no loss or checker failure.

The v1150 extension recursively materializes the live residuals exposed while
replaying three older manually documented proofs. It newly closes
`Transformed_CSR_innermost_04/Ex9_BLR02_C.ari`, raising the strict baseline to
241. The only status change besides that gain is the still-unresolved
`Ex5_DLMMU04_iGM`, which reached the harness deadline instead of returning
MAYBE. No formerly certified root was lost and no generated CPF was rejected.

The v1157 extension starts from the 27 official AProVE-certified roots absent
from v1150. All 27 official CPFs were independently checked twice by the
production CeTA-CSR binary. Three bounded materialization rounds then rebuilt
current Ferrum proofs and recursively indexed their live residual states. Nine
roots became strict oracle-only certified YES results: `Ex1_GM99_iGM`,
`Ex2_Luc02a_C`, `Ex2_Luc02a_GM`, `Ex49_GM04_C`, `ExIntrod_GM01_iGM`,
`ExSec11_1_Luc02a_C`, `ExSec11_1_Luc02a_GM`,
`MYNAT_complete_noand_GM`, and `MYNAT_nokinds_noand_GM`. The full replay has
no loss relative to v1150 and leaves 18 decisions to reach AProVE's 268/366
certified result.

The v1158 extension fixes one further representation boundary without
weakening processor checks. AProVE's `ExAppendixB_AEL03_GM` chain reached live
DP states with the same rule multisets but different rule order and private
reconstruction context. Exact processors independently accepted each live
state; after recursively materializing the complete chain, the reconstructed
current Ferrum proof was accepted twice by production CeTA-CSR. Refreezing
that proof makes every nested state independently findable and raises the
strict total to 251, leaving 17 decisions to AProVE parity.

Historical v1158 attested versions:

- Ferrum: `94500d4` (`Preserve certified recipes and bound oracle pooling`);
- CeTA-CSR/CeTA: `ae4ffbe` (`Certify nested CSR rule removal before improved DPs`);
- TPDB-ARI: `183f29db` (`secret benchmarks 2026`).

The strict replay used `timeout(60s, fail)`, disabled the top-level LLM, set
`FERRUM_DP_LLM_NO_FALLBACK=1`, and completed in 204 seconds with eight workers.
Every positive and negative result was accepted by CeTA. Its artifacts are:

- summary/details:
  `target/innermost-campaign-20260825/{innermost366-strict-v1142-r86-summary.md,innermost366-strict-v1142-r86-details.json}`;
- all CPFs and checker outputs:
  `target/termcomp-runs/innermost366-strict-v1142-r86-20260826`;
- oracle:
  `target/innermost-campaign-20260825/oracle-v1142-innermost-ex24-luc06-c-r84.jsonl`;
- oracle SHA-256:
  `b9680f029c928b7e7b444f92dac462af9ce013afc33cc2e267492479730d80cc`;
- same-oracle CSR preservation replay:
  `target/innermost-campaign-20260825/{csr110-strict-v1142-r87-summary.md,csr110-strict-v1142-r87-details.json}`.

The v1143 successor oracle and complete strict replay are:

- oracle:
  `target/innermost-campaign-20260826-default-gains/oracle-v1143-default-gains-r3.jsonl`;
- oracle SHA-256:
  `6e1ca0af42c1f869117efbcf125560438e4a6885b75e9697f4e83aefdc90dda3`;
- replay summary/details:
  `target/innermost-campaign-20260826-default-gains/{innermost366-strict-v1143-r5-summary.md,innermost366-strict-v1143-r5-details.json}`;
- all CPFs and checker outputs:
  `target/termcomp-runs/innermost366-strict-v1143-r5-20260826`.

The historical v1159 oracle and complete strict replay are:

- oracle:
  `target/innermost-campaign-20260826-aprove-parity/oracle-v1159-aprove-current11-r71.jsonl`;
- oracle SHA-256:
  `2a171eb4304d93ef23b68a4ff763a28938cd071388ab32e9ae118d2c76da69ff`;
- replay summary/details:
  `target/innermost-campaign-20260826-aprove-parity/{innermost366-strict-v1159-r73-summary.md,innermost366-strict-v1159-r73-details.json}`;
- all CPFs and checker outputs:
  `target/termcomp-runs/innermost366-strict-v1159-r73-20260826`.

The implementation preserves ordinary innermost DP strategy and minimality
through ordinary usable-rule and reduction-pair children, reconstructs
`monoRedPairProc` residual rules by subtracting the CPF's strictly oriented
rules modulo variable renaming, and consults exact raw state guidance before
expensive canonical fallback. All 779 release library tests and all 93 focused
oracle-extraction tests passed; `git diff --check` was clean. The same v1142
oracle retained the complete CSR high-water mark: 105 certified YES and five
certified NO results, or **110/110**, with zero certification failures.

### Default strategy without oracle: 171/366 certified

Recorded 2026-08-26 against the same TPDB-ARI checkout:

- certified YES: **169**;
- certified NO: **2**;
- MAYBE: **185**;
- timeout: **10**;
- certification failure: **0**;
- total certified decisions: **171/366**.

The preceding fresh default baseline was 159 certified YES plus two certified
NO, or 161/366. The Innermost-only scheduling change therefore adds ten
CeTA-certified roots with no loss. It stages a graph-first DP portfolio,
retries bounded polynomial rule removal, and restricts the extra
transformed-CSR work by rule count so a failed learned lane cannot consume the
allowance needed by established proofs. It does not modify `csr_standard` or
any CSR processor.

The authoritative replay artifacts are:

- baseline:
  `target/innermost-strategy-20260826/{baseline-default-r1-summary.md,baseline-default-r1-details.json}`;
- improved:
  `target/innermost-strategy-20260826/{improved-final-default-r24-summary.md,improved-final-default-r24-details.json}`;
- all improved CPFs and checker outputs:
  `target/termcomp-runs/innermost-improved-final-default-r24-20260826`;
- strict CSR preservation replay:
  `target/innermost-strategy-20260826/{csr110-regression-r25-summary.md,csr110-regression-r25-details.json}`.

The CSR preservation replay remains **110/110** (105 certified YES and five
certified NO). The release library suite passed 779/779 tests.

## Current TPDB-ARI Standard TRS

### Strict oracle-only replay: 1,284/1,542 certified

Recorded 2026-09-06 against TPDB-ARI commit `183f29db`:

- certified YES: **997**;
- certified NO: **287**;
- MAYBE: **253**;
- timeout: **5**;
- error or certification failure: **0**;
- total certified decisions: **1,284/1,542**.

The authoritative replay is
`target/standard-next-frontier-20260903/gm04-preserve-r744/full-standard`.
It used 64 process-isolated workers, a 65-second harness,
`timeout(60s, fail)`, no top-level model, and
`FERRUM_DP_LLM_NO_FALLBACK=1`. It preserves the preceding 1,280-root union and
adds four certified NO results through the verified complete-GM04 inverse:
`Transformed_CSR_04/{LengthOfFiniteLists_nosorts_C,
LengthOfFiniteLists_nosorts_noand_C,OvConsOS_nosorts_C,
OvConsOS_nosorts_noand_C}.ari`. There is no missing root, polarity change, or
checker failure. The independent audit accepted every retained CPF twice:
1,284/1,284 proofs, 2,568 checker invocations, zero failures.

The monotone oracle is
`target/standard-next-frontier-20260903/gm04-integrate-r739/oracle-r739-global1284.jsonl`
(SHA-256
`b16bb015a9aa225709caf0cbc1fd2e0f911eb21ef5045c19d41b98905aab8016`).
Each new root reconstructs the GM04 wrapper and its source CSR loop as separate
typed states; no opaque whole-proof atom is needed. Production CeTA-CSR has
SHA-256 `43ad99a28e75d9d372f21c575cba83f38586d577a973a9bd8b2daeb2ef7a77d8`.

This result supersedes the historical 1,280/1,542, 1,275/1,542, 1,273/1,542,
1,272/1,542, 1,270/1,542, 1,269/1,542, 1,268/1,542, 990/1528, and diagnosed 926/1542 subsections below;
those are retained as campaign history, not as current baselines.

### Certified oracle-only high-water mark: 990/1528

Recorded 2026-08-08 against the TermCOMP 2025 root set:

- certified YES: **764**;
- certified NO: **226**;
- certification failure: **0**;
- total certified decisions: **990/1528**.

This is a preservation replay of the certified roots known at that point, not
a complete 1528-root unresolved-frontier run.  It used the composition-free
atomic oracle
`target/oracle-integration-global-composition-free-20260808/oracle-global-v520-strict-atomic.jsonl`
(SHA-256
`a0ebedb92cd4c90ef3a5df7a669a3a356dbdf9d977fdf984c70979697125f804`).
The complete replay summary and per-root details are
`target/oracle-integration-global-composition-free-20260808/{final4-baseline-standard-v520-summary.md,final4-baseline-standard-v520-details.json}`;
all CPFs and checker outputs are under
`target/termcomp-runs/final4-baseline-standard-v520-20260808`.

Attested versions are Ferrum commit `2febe04`, CeTA commit `d4ec04d`, and
TPDB-ARI commit `0ced9f27` with the 1528-root TermCOMP 2025 set.  The replay
used `--strategy fail`, disabled top-level model fallback, and accepted every
generated YES/NO CPF.

### Current strict audit: 926/1542 certified; preservation repair required

Recorded 2026-08-29 against TPDB-ARI commit `183f29db` and the current
1542-root category:

- certified YES: **699**;
- certified NO: **227**;
- MAYBE: **611**;
- harness timeout: **5**;
- error or certification failure: **0**;
- total certified decisions: **926/1542**.

The audit used the current monotone global oracle
`target/innermost-gm04-integration-20260828/oracle-v1596-ex6-15-ael02-c-complete-proof.jsonl`
(SHA-256
`a604ed62bdfd419644aee73d3b5d440ee8612fff54c61bde5944d3b49088da40`),
`timeout(60s, fail)`, `FERRUM_DP_LLM_NO_FALLBACK=1`, no top-level model
fallback, 64 concurrent roots, two Rayon threads per root, and a 305-second
harness ceiling.  It completed in 1800 seconds.  Production CeTA commit
`e52c7ce` checked every generated decision; there were no rejected proofs.
The replay binary corresponds to Ferrum commit `9739fe9`; the subsequent
`10ce5bc` and `55c22ae` commits only update campaign documentation.

This run is a diagnosed replay regression, not a replacement high-water mark.
It retains 922 of the old 990 roots, loses 68 old roots to current
lookup/reconstruction drift, and adds four certified roots:

- `Transformed_CSR_04/Ex3_2_Luc97_GM.ari`;
- `Transformed_CSR_04/Ex5_7_Luc97_GM.ari`;
- `Transformed_CSR_04/OvConsOS_complete_GM.ari`;
- `Waldmann_06/jwno9.ari`.

A focused sample of the first eleven losses also returned `Unknown` when run
against the old v520 oracle with the current Ferrum binary.  This proves that
merely merging the old oracle is insufficient for at least those roots.  The
68 archived certified CPFs must be rebound to current live root and residual
states, checked, and frozen again as self-contained recursive chains.  The
manual-evidence ledger names 172 valid current Standard roots; 138 currently
replay strictly and 34 do not, although some of those 34 were explicitly
recorded as pending rather than previously strict.

The five aggregate timeouts were rerun with five isolated workers.  Four still
hit the 305-second ceiling (`Kaliszyk_19/{1long,longhl,shor}` and
`MNZ_10/labelled`), while `Kaliszyk_19/shornodot` returned MAYBE after 273
seconds.  None was part of the old 990-root baseline.  No one of the fourteen
new TPDB 2026 Standard roots is certified by the current strict oracle.

Authoritative current-audit artifacts:

- summary/details:
  `target/trs-standard-audit-20260829/{standard1542-strict-v1596-summary.md,standard1542-strict-v1596-details.json}`;
- all per-root CPFs, events, and checker outputs:
  `target/termcomp-runs/trs-standard-strict-v1596-full-20260829`;
- exact old-loss, new-gain, and manual-evidence gap lists:
  `target/trs-standard-audit-20260829/{old-v520-losses-under-v1596.txt,new-over-v520-certified-roots.txt,manual-evidence-not-currently-strict.txt}`;
- isolated timeout replay:
  `target/trs-standard-audit-20260829/{standard5-timeouts-isolated-summary.md,standard5-timeouts-isolated-details.json}`.

The next Standard gate is preservation-first: recover and twice-certify the 68
old chains, rerun all 990 old roots with no loss, and only then promote new
frontier gains or claim a Standard high-water increase.

## Current TPDB-ARI Context-Sensitive TRS

### Strict oracle-only replay: 110/110 certified

Recorded 2026-08-25 against TPDB-ARI commit `183f29db`:

- certified YES: **105**;
- certified NO: **5**;
- MAYBE, timeout, error, or certification failure: **0**;
- total certified decisions: **110/110**.

Revalidated 2026-09-06 with the current global oracle and production checker:
`target/standard-next-frontier-20260903/gm04-preserve-r744/full-csr` contains
105 certified YES and five certified NO, with zero failure. Its independent
twice audit accepted all 110 CPFs (220 checker invocations).

The two roots added after the TermCOMP 2025 set are
`Gutierrez_26/secret2.ari` and `Gutierrez_26/secret4.ari`. ARI declarations
without an explicit replacement-map entry now correctly default to all
argument positions. Consequently `f` is frozen in `secret2` but active in
`secret4`. Ferrum proves the former by two context-sensitive polynomial rule
removals and the latter by a contextual loop
`a -> if(S(a),f(a),a) -> if(true,f(a),a) -> f(a)`.

Attested versions:

- Ferrum: `2d3189e` (`Align typed MU-TERM applicability and graph checks`);
- CeTA-CSR: `ae4ffbe` (`Certify nested CSR rule removal before improved DPs`);
- TPDB-ARI: `183f29db` (`secret benchmarks 2026`).

The strict replay used `timeout(60s, fail)`, disabled the top-level LLM, set
`FERRUM_DP_LLM_NO_FALLBACK=1`, and completed in 37 seconds with 32 workers.
Its artifacts are:

- summary/details:
  `target/csr110-nested-removal-oracle-20260825/{replay-v1111-boundary-summary.md,replay-v1111-boundary-details.json}`;
- all CPFs and first checker outputs:
  `target/termcomp-runs/csr110-strict-v1111-boundary-20260825`;
- oracle:
  `target/csr110-nested-removal-oracle-20260825/oracle-global-v1108-self-contained.jsonl`;
- oracle SHA-256:
  `d425800be16d40e67b31abdd6b01176d433616e6daf5d81243235ee32ae461a1`;
- export report:
  `target/csr110-nested-removal-oracle-20260825/oracle-global-v1108-self-contained.report.json`;
- nested-state audit:
  `target/csr110-nested-removal-oracle-20260825/applicability-v1111-boundary.json`;
- deterministic checker repeats:
  `target/csr110-nested-removal-oracle-20260825/replay-v1111-boundary-double-ceta-recheck.json`.

CeTA-CSR now checks any finite sequence of exact context-sensitive rule
removals followed by improved CS-DPs as one recursive, context-preserving
proof. Ferrum emits that boundary for polynomial and matrix removals. The
oracle extractor retains matching live exact reduction-pair atoms, indexes
materialized children even when the parent run never attempted them, and
canonicalizes reconstructible improved-CS-DP unhiding map entries. The final
audit finds positive guidance for all 105 terminating roots and all
**353/353** nontrivial successful path states reached by the attested replay,
with zero missing roots, missing path nodes, or context-losing historical
nodes. Both independent checker passes accepted all 110 CPFs. The Rust
library suite passed 776/776 tests and 159 focused Python
extraction/dataset/oracle tests passed. Ferrum retains a focused, certified
structural MU-TERM route for `Ex1_GM03`; it is deliberately not offered as a
broad default lane because related roots can satisfy the search processors
without satisfying CeTA's typed conservativity boundary. Runtime MU-TERM
materialization now checks CeTA's four unhiding-safety clauses, and its graph
estimator preserves direct typed edges in addition to expanded representatives.

On the same binary, a 60-second default-strategy replay with no oracle found
91 certified YES and all 5 certified NO results, for **96/110** certified
decisions. The remaining 14 roots returned MAYBE; importantly, there were no
checker-rejected positives. Its summary/details and CPFs are under
`target/csr110-default-no-oracle-final-20260825` and
`target/termcomp-runs/csr110-default-no-oracle-final-20260825`.

## TermCOMP 2025 Context-Sensitive TRS

### Strict oracle-only replay: 108/108 certified

Recorded 2026-08-25:

- certified YES: **104**;
- certified NO: **4**;
- MAYBE: **0**;
- timeout, error, or certification failure: **0**;
- total certified decisions: **108/108**.

The corrected v1005 run used strict oracle guidance at every recursively
exposed state: fallback was disabled, the top-level LLM was disabled, and
every reported YES/NO was accepted by CeTA-CSR. There are no open roots or
unguided nontrivial states on the certified replay paths.

Attested source versions:

- Ferrum: `3ffd3a3ed98dc13ee2e6c069d1a29b17f6fb6d93`
  (`Add exact filtered WPO replay for DP residuals`);
- CeTA-CSR: `c7fc326` (`Certify recursive guarded improved CSR proofs`).

These are the commits checked out when the final replay completed. Later
commits may contain strict supersets of the implementation, but they do not
replace this attested pair until a complete 108-root replay establishes at
least the same certified set.

Authoritative artifacts:

- summary and per-root results:
  `target/csr108-live-refreeze-v1003-20260825/{csr108-strict-v1005-summary.md,csr108-strict-v1005-details.json}`;
- CPFs and checker outputs:
  `target/termcomp-runs/csr108-strict-v1005-minimal-generic-20260825`;
- oracle:
  `target/csr108-live-refreeze-v1003-20260825/oracle-global-v1005-minimal-generic.jsonl`;
- oracle SHA-256:
  `184fc5c17996d98b2f186971c7f8edd55b29934df74926116c232e33af6c6cc6`;
- export report:
  `target/csr108-live-refreeze-v1003-20260825/oracle-global-v1005-minimal-generic.report.json`;
- nested-state applicability audit:
  `target/csr108-live-refreeze-v1003-20260825/applicability-audit-v1005-final.json`;
- independent second checker pass:
  `target/csr108-live-refreeze-v1003-20260825/second-ceta-recheck-v1005.json`.

`CSR_04/Ex5_7_Luc97.ari` is the final added certified root. Its proof uses the
already certified GM context-sensitive transformation, dependency-graph
decomposition, one exact max-polynomial deletion, a second graph split, and
five singleton closures. Four singletons require WPO(Max) with collapsing
argument filters; the fifth uses an ordinary max-polynomial interpretation.
Ferrum now retains the filter separately from WPO status, filters every live
pair and rule before exact validation, and emits the standard CPF
`filteredRedPair` wrapper around `weightedPathOrder`. The production checker
accepted the producing proof and the strict replay proof twice.

The initial Ex5 extraction materialized 205 observations over 12 distinct
states. A subsequent whole-replay audit found five nontrivial states that
were still reached through explicit parent continuations: four in
`Maude_06/LISTUTILITIES_complete.ari` and the live GM child of Ex5. The v1005
minimal refreeze adds the certified generic graph, instantiation, and subterm
actions at exactly those live states, plus Ex5's exact DP action. It does not
globally substitute reconstructed `exact-*` variants, because doing so changes
child identities and ranking. The final audit reports positive guidance for
all 104 terminating roots and all **444/444** nontrivial successful path
states, with zero actionable gaps.

The complete strict replay used `timeout(60s, fail)`, disabled top-level LLM
fallback, set `FERRUM_DP_LLM_NO_FALLBACK=1`, and finished in 10 seconds with
104 certified YES and four certified NO. A fresh second checker pass accepted
all 108 CPFs. A clean repeat of the current Ferrum library suite passed
772/772 tests; the preceding run's sole persistent-Z3 broken-pipe failure also
passed on an immediate isolated rerun. The 139 focused extraction,
credited-dataset, and oracle-export Python tests pass, as do release/debug builds and
`git diff --check`. No CeTA-CSR source change was needed for the final root.

The preceding 107/108 high-water mark added
`Maude_06/OvConsOS_nokinds.ari` and left `CSR_04/Ex5_7_Luc97.ari` open.

`Maude_06/OvConsOS_nokinds.ari` was that replay's new certified root. Its
proof first removes three CSR rules with an exact polynomial interpretation,
constructs improved CS-DPs with an explicit fresh unhiding symbol, decomposes the graph,
reuses the existing certified matrix/U3/subterm continuations, and closes the
last two-pair component with the verified guarded-list terminal. The source
and strict replay CPFs were accepted twice by the production checker; the
strict root replay took 3.3 seconds with the fallback strategy literally set
to `fail`.

The oracle extractor now understands the recursive guarded CPF grammar and
the CSR/U3 reduction-pair wrapper. It materialized 15 distinct obligations
and promoted 14 directly certified state/action gates; no nested continuation
is hidden inside a root-only fragment. The v1001 export adds 82 positive
entries and 29 raw aliases, retains 68 lower-ranked weak exploration hints,
and explicitly rejects one uncertified `empty` event. The complete replay
finished in 15 seconds. A fresh twice-per-proof audit accepted all 107 CPFs.

The preceding 106/108 high-water mark added
`Maude_06/LISTUTILITIES_complete.ari`. Its proof uses
improved CS-DPs, graph decomposition, exact instantiation, Arctic reduction
pairs, subterm deletion, and size-change closure. The decisive correctness
fix preserves CeTA's exact instantiation residual instead of
alpha-deduplicating syntactically distinct source-pair spellings. The oracle
integration now optionally invokes Ferrum's production `canonicalize-cpf`
implementation, eliminating the former mismatch between Python training keys
and runtime keys. Oracle evidence order is also preserved: Ferrum no longer
silently moves an exact transformation ahead of a generic action when the
exact child lacks an independently indexed continuation. The newly attested strict replay
finished in 63 seconds with zero guidance misses; its CPF is byte-identical to
the producing proof and passed the fresh checker twice.

The preceding 105/108 high-water mark added
`Maude_06/LISTUTILITIES_nokinds.ari`. Its hard
components require recursively collapsing symbols below a replacement-map-
inactive marked-root argument. CeTA-CSR now proves that every connecting
CS-DP sequence preserves that frozen argument exactly, which makes an
arbitrary well-formed collapsing argument filter below it sound. Ferrum
implements the same applicability boundary and exact validation. The proof
uses improved CS-DPs, graph decomposition, three frozen-recursive subterm
deletions, and one bounded instantiation step. The direct and strict
oracle-only CPFs are byte-identical and each passed the fresh checker twice.

That v1000 export contains 32 positive evidence entries and 52 raw aliases. It
promoted no uncertified result: one uncertified `empty` event was explicitly
rejected. The complete second checker pass accepted all 106 retained CPFs.

The preceding 104/108 high-water mark added `CSR_04/Ex6_15_AEL02.ari`.
Human inspection of its
four-pair hard SCC suggested that the apparent recursion is structural rather
than productive: one bridge pair prevents a uniform projection, while the
other quote/selection cycles consume a leading successor or list constructor.
A 3-dimensional natural Arctic U3 reduction pair deletes that bridge; the
three-pair residual then closes by the subterm criterion. Ferrum now keeps the
residual inside the minimal CSR-DP proof language via recursive
`csrRedPairUrProc`, instead of losing minimality in an `ordinaryDpProof`
wrapper. The direct and strict-replay CPFs both passed the production checker
twice. No CeTA-CSR source change was required.

The v1001 verification comprised the complete 108-root strict replay, a
second fresh-checker pass over all 107 retained CPFs, 765/765 Rust library
tests, 111 focused Python extraction/oracle tests, 21 focused subterm tests,
active-root and missing-filter mutation negatives, release and debug builds,
isolated Isabelle `CSR_Checker_Extensions`, `Proof_Checker`, `IsaFoR_3`, and
`Code` sessions, compilation of all 388 generated Haskell modules, and
`git diff --check`. Representative older Ex14, Ex6, and recursive CSR proofs
also passed the fresh checker twice.

The earlier v991/v994 replay reported the previous 103/108 total, but inspection
of its event log found that five roots silently entered generic search after
oracle misses at nested states. It therefore was not a valid strict
no-fallback attestation. The v72 recovery extracted all recursive states from
the 103 certified proof trees, rechecked every complete root proof twice with
the production CeTA-CSR binary (103/103 accepted), and exported the missing
continuations as independently addressable oracle entries. The corrected v992
replay restores all five affected roots with `FERRUM_DP_LLM_NO_FALLBACK=1` and
the top-level fallback strategy set to `fail`; it contains no promoted
uncertified answer.

## TermCOMP 2025 TRS Standard

### Strict oracle-only replay: 1,256/1,542 certified

Recorded 2026-09-02:

- certified YES: **988**;
- certified NO: **268**;
- MAYBE: **277**;
- timeout: **9**;
- checker-rejected positives: **0**;
- total certified decisions: **1,256/1,542**.

This is the current complete-category high-water mark. It improves the r39
strict baseline of 1,090 certified decisions by **166 roots** and the preceding
1,241-root high-water mark by fifteen roots. The final r209 replay used 64
workers, a 65-second harness / 60-second prover allowance, the top-level
fallback strategy `fail`, `FERRUM_DP_LLM_NO_FALLBACK=1`, no top-level model,
and CeTA-CSR exclusively. It completed in 272 seconds and produced no parse,
processor, unsupported, checker, checker-timeout, missing-CPF, or other
certification failure.

The additional root is `TRS_Standard/Zantema_05/z23.ari`. Its oracle replay is
fully recursive rather than a stored whole-proof shortcut: AAECC innermost
switching, an ordinary DP transformation, usable-rule removal,
innermost-LHS removal, QDP-to-SRS, a second DP transformation, and the final
graph proof are each looked up at their own exact state. The strict focused
replay and the complete category replay both reconstructed fresh CPFs accepted
by production CeTA-CSR.

The monotone r191 oracle contains the certified `z30` match-bounds witness,
the recovered `Ex14_AEGL02_C` CSR-switch/polynomial chain, exact state-local
Arctic witnesses for `Ex9_BLR02_FR`, and the thirteen transformed-CSR gains
harvested since r157. Four roots absent from the preceding loaded run were
reconciled against the historical certified-set union:
`Kaliszyk_19/{1rwr,not_3258}`, `Transformed_CSR_04/Ex14_AEGL02_C`, and
`Transformed_CSR_04/Ex9_BLR02_FR`. A focused pruned-source replay certified
all four in twelve seconds.

Two scheduler defects caused the Kaliszyk losses. The worklist serialized and
hashed the complete state before every failed atom for a redundant global
negative-attempt cache, and it tried a retained one-rule exact proof against
every unrelated TRS. On these roots a serialization is roughly 100 MiB while
the successful loop search takes milliseconds. Failed atoms and terminal
proofs now avoid canonical cycle hashing, the redundant cache is gone, and the
one-rule witness has a necessary structural guard. Exact top-level polynomial
witnesses now pass the same monotonicity check as synthesized witnesses, which
eliminates the sole checker rejection from the diagnostic r169 replay.

The complete GM04 residual assumption is now explicitly restricted to the
innermost QDP boundary proved by the verified theorem. A syntactically similar
full-rewriting Standard residual must be closed by ordinary DP processors; it
cannot be promoted by the private assumption. The speculative full-GM04
Standard scheduling changes were removed before the final build and replay.

Authoritative current artifacts:

- oracle:
  `target/standard-transformed-c-direct-20260902/oracle-r207-union1256-z23-recursive.jsonl`;
- oracle SHA-256:
  `ac128b3bc1ea1966b92011a9f2fd442164c60a4868cd57f982c7e002e54eef35`;
- summary/details and per-root CPFs:
  `target/standard-transformed-c-direct-20260902/full-standard-oracle-only-r209-union1256`;
- deterministic twice-per-proof checker audit:
  `target/standard-transformed-c-direct-20260902/full-standard-oracle-only-r209-union1256-ceta-twice-audit`;
- focused recursive `z23` replay:
  `target/standard-transformed-c-direct-20260902/z23-strict-recursive-r208`;
- four-root preservation replay:
  `target/standard-transformed-c-direct-20260902/recover-union1255-pruned-r195`.

Ferrum commit `08f9a95` and CeTA-CSR commit `def4623` are attested against
TPDB-ARI commit `183f29db`. No CeTA-CSR source change was required. The
production checker SHA-256 remains
`8e7b9aefc430fdeb340ed349521b89e96f562be12a96db0865d3e79871b2ffb1`.

Verification passed all 848 Rust library tests, all eleven monotone-oracle
merge tests, the focused exact-polynomial and GM04-boundary regressions, the
release build, and `git diff --check`. The independent deterministic audit
invoked production CeTA-CSR twice for every retained proof: all 1,256 proofs
passed both checks (2,512 checker invocations, zero failures).

The following paragraphs retain the earlier 1,241-root campaign history.

The r139 replay first preserved all 1,232 decisions from the r137 replay and
then added `Secret_06_TRS/{logarithm,times}.ari`.  The corrected r140 alias
export added `Zantema_05/{z12,z13}.ari`; r142 then added
`Zantema_05/{z14,z15,z16}.ari`; r145 adds the modular non-AAECC route for
`z18.ari`; and r156 adds `AProVE_07/thiemann34.ari` through a conditional
bounded-increase reduction pair.  Every AAECC, DP, usable-rule, innermost-LHSS,
QDP-to-SRS, generated-SRS, bounded-increase, and SCT state is independently
keyed.  The r156 oracle explicitly excludes thiemann34's complete root proof.
The current-binary r157 replay returned 973 certified YES, 266 certified NO,
295 MAYBE, and eight timeouts under load; the two missing NO decisions are
timeout variance.  Its 1,239 retained proofs were each rechecked twice (2,478
checker invocations, zero failures).  Combining the 973 YES results with the
already attested 268 certified NO high-water mark gives 1,241 roots.  Its new
artifacts are:

- oracle:
  `target/standard-z12-z13-alias-fix-20260902/oracle-r156-thiemann34-fragments.jsonl`;
- oracle SHA-256:
  `be2b9ad350c8498c07475dd6301aa47493db15e7a75dc73937dd3c7e41c06727`;
- summary/details:
  `target/standard-z12-z13-alias-fix-20260902/{full-standard-strict-r157-thiemann34-summary.md,full-standard-strict-r157-thiemann34-details.json}`;
- per-root artifacts:
  `target/standard-z12-z13-alias-fix-20260902/full-standard-strict-r157-thiemann34`;
- twice-per-proof checker audit:
  `target/standard-z12-z13-alias-fix-20260902/full-standard-strict-r157-thiemann34-ceta-audit`.

Ferrum commit `dc5bf0e` and CeTA-CSR commit `def4623` were attested against
TPDB-ARI commit `183f29db`.  The production checker SHA-256 is
`8e7b9aefc430fdeb340ed349521b89e96f562be12a96db0865d3e79871b2ffb1`.

The extraction defect was a problem-identity bug: a generated problem label
ending in `.ari#qdp-to-srs` displaced the real root identity.  Identity now
truncates only the generated suffix after `.ari#`, while preserving legitimate
TPDB names such as `#3.15.ari`.  All 148 extractor tests pass.

Historically, the complete r95 replay against the frozen r93 oracle produced
exactly 960 certified YES and 268 certified NO in 272 seconds; the newer r111
replay and r109 oracle below supersede it.

The r109 extension adds `Zantema_05/z09.ari` and `Mixed_TRS/sigma.ari`.
Both use the same graph, bounded max-polynomial deletion, and size-change
chain; their complete CPFs were accepted twice by CeTA-CSR before oracle
export.  A scheduling defect had allowed broad DP branches to occupy the
worker pool before this sub-second lane ran.  The default Standard strategy
now gives the bounded lane a three-second uncontended head start for systems
with at most fifteen rules.  The focused default run is 2/2 certified in
under one second, targeted strict oracle replay is 2/2 certified in five
seconds, and the complete strict r111 replay returns 962 certified YES and
268 certified NO in 267 seconds with no checker failure.

The r93 extension makes five formerly load- and fallback-sensitive roots
self-contained by freezing their already certified complete r82 CPFs as exact
source-bound proofs: `Secret_05_TRS/teparla3.ari`,
`Transformed_CSR_04/Ex5_DLMMU04_iGM.ari`,
`Transformed_CSR_04/LengthOfFiniteLists_nokinds_iGM.ari`, and
`Zantema_05/{z19,z21}.ari`.  The preceding replay had only root advice for
some of these (for example, `dp`) and silently entered generic search after a
nested-state miss.  All five source CPFs were checked twice before import, and
strict replay now uses no such child fallback.

Eight additional current-portfolio proofs were harvested from the unresolved
frontier: `Saito_26/{HSTY26_fffgf,HSTY26_zip,SH25_echelon,
SK90_4.55_collapsing}`, `Secret_06_TRS/tpa02`, and
`Yamada_26/{YKS15-Ex10,YKS15-Ex12,YKS15-Ex13}`.  Their complete CPFs passed
two independent CeTA-CSR checks before import and all eight replayed strictly
in five seconds.  The recursive certified
`Transformed_CSR_04/Ex14_AEGL02_C.ari` conversion contributes one further
root; its six certified transitions and eleven open-but-sound continuation
hints remain separately typed in the oracle.  A focused 14-root preservation
replay was 14/14 certified in six seconds before the complete run.

The large jump comes from importing complete source-bound AProVE CPF proofs as
ordinary executable Ferrum strategy atoms.  Before accepting an atom Ferrum
checks that its recorded TRS is exactly the live root up to a signature
isomorphism, translates the retained proof through that isomorphism, emits an
ordinary CPF, and submits that CPF to CeTA-CSR.  This does not trust or copy an
external answer.  Existing independently keyed nested proof rows remain in the
oracle, so root-proof freezing does not discard residual-state guidance.

Every one of the 72 newly imported roots passed two additional independent
CeTA-CSR checks (144/144).  After the complete r60 replay, 1,200 generated
proofs below 2 MiB were checked twice again and frozen as direct root proofs.
The r61 export promotes 1,200 such entries and reports zero uncertified positive
promotions.  The sole rejected generated proof is
`AProVE_07/thiemann34.ari`; it remains outside the certified total because its
bounded-increase witness is rejected by the checker.  It is quarantined and
cannot promote a YES.

The final additional root is `MNZ_10/labelled.ari`.  Root-only extraction avoids
canonicalizing its enormous generated DP graph, while a current AProVE CPF3
artifact supplies the complete checked proof.  Ferrum re-emits it as an
ordinary source-bound CPF in 9.4 seconds; the source proof and both targeted
replay proofs passed CeTA-CSR, as did the complete replay proof.  No legacy
CPF2 parser relaxation was used.

Five more official AProVE-certified misses are imported from current CPF3
artifacts: `AG01/#3.15.ari` and
`Applicative_first_order_05/{#3.10,#3.13,#3.55,#3.57}.ari`.  The extractor now
recognizes StarExec's `sharp_3.xx` filename sanitization in both proof and
runtime paths.  Ferrum's signature-isomorphism translation also treats symbol
names as XML text rather than attributes, preserving apostrophes in the
application symbol.  All five source proofs were checked twice, their five
full-replay CPFs were checked twice again (10/10), and the complete replay has
zero new certification failures.

The newest root is `AProVE_07/otto04.ari`.  A current CPF3 artifact avoids the
variable-identity problem in the archived CPF2 lookup table and supplies a
complete source-bound instantiation chain.  The source proof passed the
extractor's two CeTA-CSR checks, targeted strict replay completed in 5.0
seconds, and both the targeted and complete-replay CPFs passed two further
independent CeTA-CSR checks.  The r70 complete replay consequently has one
fewer checker rejection and no loss of a prior certified decision.

Authoritative artifacts:

- repeat summary/details:
  `target/data-campaign/trs-standard-causal-chain-20260830/{full-standard-strict-r111-1230-summary.md,full-standard-strict-r111-1230-details.json}`;
- repeat CPFs and checker outputs:
  `target/termcomp-runs/standard-full-strict-r111-1230-20260830`;
- frozen oracle:
  `target/data-campaign/trs-standard-causal-chain-20260830/oracle-exploration-r109-strict-1230-certified.jsonl`;
- oracle SHA-256:
  `274b81c139dcc61835fd31bc6703e2cb2acabd489b4bd4ea35a28b2b7b7e312e`;
- export report:
  `target/data-campaign/trs-standard-causal-chain-20260830/oracle-exploration-r109-strict-1230-certified-report.json`;
- twice-checked frozen-root evidence and gate manifest:
  `target/data-campaign/trs-standard-causal-chain-20260830/{certified-fallback-r85-root-proofs.jsonl,certified-fallback-r85-root-proofs-manifest.jsonl}`.

The attested checker version is CeTA-CSR
`def46239bdb9f024126d714eff0485fc4de30ff7`.  No CeTA-CSR source change was
needed for this TRS Standard gain.  The Ferrum source commit is recorded after
the concurrent processor refactoring and verification described below is
committed.

## Updating this page

Before claiming a regression or a new high-water mark:

1. Read this page and compare root sets, not just totals.
2. Run the complete category with the intended strict/no-fallback settings.
3. Require zero uncertified promoted YES/NO and zero checker failures.
4. Record the exact Ferrum and CeTA-CSR commits, oracle checksum, summary,
   details, and artifact directory.
5. Replace the high-water entry only if the new run preserves every previously
   certified root and adds certified roots, or explicitly documents and fixes
   any real regression first.
