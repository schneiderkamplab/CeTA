# Oracle modularity and witness dependence

## Latest: 110/110 CSR without exact oracle witnesses

The subsequently validated CSR-only profile is **1.74 MB**, retaining all
110 twice-certified results without witnesses. This is a separate deployment
profile, not a global replacement for Standard/Innermost guidance. See
[compaction and standalone export](csr-oracle-compaction-and-local-export.md).

Ferrum `6f25f60` closes the final four gaps with native WPO and restricted
rational quadratic synthesis. The complete parameter-only, no-fallback replay
is **110/110 (105 YES, five NO)**, with every CPF independently checked twice.
None of these 110 roots requires an exact oracle witness in this replay.
The oracle supplies processor choices and bounds, not interpretations,
precedences, argument filters or statuses. The 300-second root ceiling is
deliberately lenient: 108 results finish within 60 seconds under concurrency.

See [the authoritative ledger](state-of-the-art.md) and
[native WPO/sparse rational evidence](native-wpo-and-sparse-quadratic.md).
The older checkpoints below explain the incremental recovery; their remaining
root lists are historical, not current blockers. The separate standalone
source-relative MU-TERM export limitation still exists and was not bypassed:
the new native actions were reconstructed and certified at the original roots.

The earlier [five-root follow-up](csr-witness-free-five-followup.md) records
csrdiv's live/materialized graph fix and the diagnosis that WPO cannot be
replaced by plain max-polynomial synthesis.

## 2026-09-16 twelve-root native recovery

The complete parameter-only, no-fallback CSR replay improved **98 → 105/110**
certified (100 YES, five NO), with zero losses. All 105 CPFs passed two
independent production CeTA checks. Seven recovered roots:

- LISTUTILITIES_complete-noand and LISTUTILITIES_nokinds-noand.
- LengthOfFiniteLists_complete-noand and LengthOfFiniteLists_complete.
- MYNAT_complete-noand, OvConsOS_complete-noand, PALINDROME_complete-noand.

The important code fix is retaining the fixed local R after non-minimal CSR
usable-rule removal. Native synthesis had been finding interpretations over
another filtered subset; the minimality guard correctly refused those
continuations. Two additional search changes require all pairs weak in the
max-polynomial query and expose direct rational quadratic synthesis. Neither
relaxes model checking. CPF-to-search conversion now recognizes max-affine,
rational quadratic, and natural weak-polynomial families, discards assignments,
and preserves numeric bounds/domain/gap information.

Different native models expose different children. Complete native probes
closed these children, their CPFs were checked twice, and their actions were
exported to **state-local weak guidance with zero event certification credit**.
No composite proof or retained pipeline was installed. In particular the
LengthOfFiniteLists_complete-noand exploratory matrix/polynomial ladder was
decomposed into nine addressed native-action states before oracle-only replay.

Artifacts: `target/csr-native-twelve-20260916/`.

- `full-parameter-v11/details.json`: complete 105/110 replay;
  `full-parameter-v11-rechecks.jsonl`: 105 twice-certified CPFs.
- `parameter-final/details.json`: repeat with the final integer-encoding build,
  again 105/110; `parameter-final-comparison.json` confirms seven gains and no
  losses; `parameter-final-rechecks.jsonl` checks all 105 proofs twice.
- `parameter-comparison.json`: exact input/polarity comparison against the
  previous 98/110 run, with seven gains and zero losses.
- `parameter-v11.jsonl`: experimental parameter oracle, SHA256
  `c6b0a0b1e5c6dace42e3aa914e463d73696126f1850ea09c877d8175ca56f9e6`.
  Its 1,390,834 actions contain no exact-action calls, `hex=` payloads or witness
  references. Inherited statistics are not fresh processor certification.
- `mynat-poly-v2.xml`, `palindrome-native{,-v2}.xml`, `length-native.xml`:
  independently certified new native residual closures.
- `length-noand-ladder.xml`: exploratory native proof;
  `length-noand-root.xml`: separately reconstructed no-fallback oracle proof.
- `production-final/details.json` and `production-final-comparison.json`:
  all 1,759 production-oracle roots retained (1,338 Standard, 311 Innermost,
  110 CSR), with no losses or uncertified decisions. The final binary SHA256 is
  `5660427aea38f08506a2a6f056684d1d54a10e0680c4b5bba88b0216d0f22399`.
  The 235 retained residuals also passed two checks using the preceding build
  with the same fixed-R and max-polynomial changes (`residual-checks.jsonl`,
  `child-checks.jsonl`).

The remaining five are **not proved to need witnesses**:

| Root | Observed search boundary |
| --- | --- |
| Ex3_2_Luc97 | GM04 transformed DP component; native max-polynomial synthesis |
| Ex5_7_Luc97 | Large transformed component; native max-polynomial synthesis |
| ExIntrod_Zan97 | Typed local MU-TERM component; rational quadratic synthesis |
| emmes | Typed local MU-TERM component; rational quadratic synthesis with quarter gap |
| csrdiv | Native max-polynomial/instantiation produces new residuals requiring closure |

The `native-default-five-v2/` run also returned five Unknown outcomes at a
120-second cap. The first `native-default-five/` run used the obsolete
`termination` alias and failed parsing; it provides no search evidence.
The unsupported standalone non-minimal MU-TERM context remains a separate
boundary, described below. No checker guard was bypassed to count a root.

Longer targeted max-polynomial trials did not close the remaining transformed
components: `ex3-long.log` timed out at 300 seconds; `ex5-long.log` returned
inapplicable after about 168 seconds. These outcomes concern the configured
search, not the existence of an interpretation or termination of the root.
The integer-only direct quadratic trials also exhausted their 120-second
budgets (`emmes-integer.log`, `exintrod-integer.log`). The direct quadratic
encoding has algebraic-equivalence, overflow-rejection, and production CeTA
integration tests. The final library suite passes all 984 tests; the 25 focused
Python tests pass. CeTA source and the production checker were unchanged.

## 2026-09-16 native MU-TERM search recovery

### Standalone local-context investigation

The remaining exporter boundary is not permission to turn the runtime
`minimal` bit back on. Production CeTA's
`check_muterm_recursive_dp_proof_sound` establishes
`muterm_i4.finite_muterm_i4_good_typed_dpp R mu P B`, relative to the
**source** R and a fixed local bridge set B. Local ordinary usable rules U
are order-checking obligations, not a replacement for source R in that
theorem. The current standalone typed input accepts only its minimal source
obligation, with the exact full bridge closure.

A proper standalone local input therefore needs source R and mu, current P,
the fixed local B, and U, separately. At the graph-component entry CeTA fixes
B using `muterm_component_unhiding_rules`; recursive pair deletion preserves
it. Recomputing B from a later, smaller P is not the same obligation. Ferrum's
current context retains the source CSR and active rules, but has no separate
field for that fixed local B. The next implementation must:

1. Record this context at local-usable entry and preserve it in successors,
   canonical keys and materialization/parser round trips.
2. Add a distinct standalone local input/checker boundary invoking the
   existing recursive theorem with its checked source/bridge assumptions.
3. Reconstruct and twice certify each new local state independently, with
   mutation-negative tests for changed source maps, bridges and usable rules.

Do not wrap the residual in a fabricated parent, coerce it to ordinary DPs,
or count its currently certified parent as independent child certification.
The exporter now reports this specific missing boundary; its rejection
regression passes (`local-boundary-test.log` in the directory below).
A parameter-only 2D matrix probe for ExIntrod_Zan97 returned Inapplicable in
68 ms (`exintrod-matrix2.log`), not a new certified gain. No CeTA source or
production oracle was changed by this investigation.

Ex1_GM03 now has a **parameter-only, no-fallback, CeTA-certified** replay
(5.186 seconds in the loaded CSR batch, plus five further certified repeats).
The complete CSR parameter-only guard now certifies **98/110** (93 YES,
five NO), up from 97/110 with no losses. All 98 certificates were checked
twice again by production CeTA. The remaining outcomes are ten unknown and
two timeouts. The retained 235-state residual guard also passes completely,
with every CPF independently certified twice.
No exact model, rule-set witness, or complete proof action is supplied by the
experimental oracle. The native search fixes are:

- Compute the typed MU-TERM local usable-rule set from the live input and
  generated unhiding bridges.
- Respect explicitly established local rules in subsequent reduction pairs;
  do not append duplicate bridges or compare that local R to the source CSR
  as if a new usable-rule reduction had occurred.
- Retain R and emit pair deletion through `redPairProc`. The existing
  recursive MU-TERM checker does not accept `monoRedPairProc` rule deletion.
- Add five weak parameter-only hints at the newly computed states. These
  are ordinary native rational/polynomial searches and the empty terminal,
  not retained interpretations.

All 977 library tests pass, with no failures or ignored tests. Two new tests
cover context preservation, non-minimal rejection of repeated usable rules,
native rational synthesis over the established R, and the supported
non-monotonic certificate shape. CeTA sources and binary did not change.

Artifacts: `target/native-muterm-usable-20260916/`. Experimental oracle:
`parameter-oracle-v2.jsonl`, SHA256
`c54c160e3c60dc551a33a065e6966518ba248f5145945c90e4dfd01ffcbb131d`.
Release binary SHA256:
`eda5b814a0bd7fbb62aa69918499b23cd15e8c02e0e7193dd2dfc325cb15c1eb`.
The complete CSR parameter replay is `csr-parameter-guard/`; the retained
production oracle is separately guarded in `production-guard/`: all 1,759
roots retain their certified decisions (Standard 1,338, Innermost 311,
CSR 110), with no missing inputs, losses or polarity changes. Every retained
CPF passed two further independent checks in `production-rechecks.jsonl`;
the exact root comparison is `production-comparison.json`.
`repeat-{1,2,3,4,5}/ceta.log` contains the extra certified Ex1_GM03 repeats.
Additional rechecks: `csr-parameter-rechecks.jsonl`, `residual-checks.jsonl`,
and `child-checks.jsonl`; full library log: `library-v3.log`.

Remaining boundaries are explicit: ExIntrod_Zan97's new local residual was
not closed by linear polynomial search, and its rational/quadratic search
hit the local 60-second limit. Also, the new non-minimal typed local children
are independently addressed and solved during replay, but their standalone
CPF export rejects this context. Their complete parent proof certifies;
**they are not counted as independently certified children**. The older
235-state retained residual corpus is guarded separately.

## 2026-09-15 current-oracle witness ablation

The certified production baseline remains **1,759 roots and 235 independent
residuals**, using Ferrum `c622d59`, CeTA main `73662ec`, and the frozen v48
oracle recorded in [the state-of-the-art ledger](state-of-the-art.md).
Modularity does not imply witness-free synthesis.

Experiment directory: `target/witness-dependence-20260915/`. The experimental
`parameter-only-v2.jsonl` replaces supported exact actions by native search
families and numeric bounds, removes unsupported exact actions, remaps action
ordering, and removes all witness definitions/references. A full scan found
zero remaining exact candidate actions, references, or `hex=` payloads.
SHA256: `8443296ee6a176d29e5f65d28f199ad21b05323bd404a526a5559418d522bbbf`.
Historical statistics in this experimental file describe the original actions:
**do not promote it as certified guidance**. Only fresh certificates count.

Converter improvements cover source-bound orders and labeling, Q reduction,
native DP rewriting/narrowing/instantiation families, and additional existing
numeric-order/labeling search converters. Assignments, source bindings, selected
substitutions and prescribed target states are discarded. The converter reports
unsupported witness definitions separately; a loss caused by discarded
vocabulary is not evidence that synthesis inherently needs a supplied model.

The 235-state ablation is complete with **184 independently twice-certified**:
105/152 original audit states and 79/83 additional children. The other states
report 35 `Inapplicable`, nine explicit unguided-child failures, and seven
local timeouts. There are no checker rejections among the 184 proofs.
Artifacts: `residual-replay-v2/results.jsonl`, `residual-checks-v2.jsonl`,
`new-child-replay-v2/results.jsonl`, `new-child-checks-v2.jsonl`.
Both runs disable fallback and use 180-second nominal limits; cooperative
cancellation can overshoot those limits (one residual took about 202 seconds).

Concrete investigation priorities:

- Ex1_GM03: the certified chain begins with typed MU-TERM local usable rules.
  The generic `usable-rules` processor returns inapplicable at that state,
  before order synthesis. The exact interface and native search interface
  therefore differ in supported contexts.
- Nine independent states successfully transform and then explicitly report
  an unguided child. Their origins include csrdiv, tpa03 (two states), aprove08,
  AAECC-ring, Ex2_8_1ConstSubstFix, SK90/4.40, z21, and
  OvConsOS_complete-noand_FR. These need new child guidance, not an assumption
  that a historical model is indispensable.
- Local timeouts require isolated, higher-budget experiments before making
  claims about synthesis completeness.

The first full root ablation `root-replay-v1` retained 1,315/1,759:
CSR 97/110 (92 YES + five NO), Innermost 222/311 (212 YES + ten NO), and
Standard 996/1,338 (781 YES + 215 NO). All 1,315 CPFs passed two further
production CeTA checks, with zero polarity changes or uncertified decisions.
V1 predates the native DP-transformation conversion correction.

The complete **v2** run retains **1,347/1,759**, all independently checked twice:

| Category | Witness-free YES | Witness-free NO | Total / retained baseline |
| --- | ---: | ---: | ---: |
| CSR | 92 | 5 | 97 / 110 |
| TRS Innermost | 214 | 10 | 224 / 311 |
| TRS Standard | 811 | 215 | 1,026 / 1,338 |

There are no uncertified decisions. Unrecovered outcomes are 12 unknown and
one timeout for CSR, 82 unknown and five timeouts for Innermost, and 309 unknown
and three timeouts for Standard. Limits were 180 seconds inside Ferrum and
185 seconds in the harness, with fallback disabled. V1 used 48 workers; v2
used 32, so timing differences must not be attributed solely to conversion.

V2 gained 33 roots and lost one relative to v1: Zantema_05/z19 certified in
143.184 seconds in v1 but returned unknown after 184.094 seconds in v2.
Thus **1,348 distinct roots have demonstrated witness-free replay across
these experiments**, not 1,348 in a single run. None of the other 411 is
proved to inherently require a supplied witness. The 13 missing CSR roots
are unchanged between these two runs.

Root artifacts: `root-replay-v2/{details.json,summary.md,run/}`,
`root-rechecks-v2.jsonl`, and `loss-report-v2.json`. Earlier run/recheck/report
artifacts have the v1 suffix. These experiments do not replace the certified
production oracle or lower its 1,759-root baseline. No prover or CeTA
source/binary was changed.

The subsequent v3 converter adds CPF-wrapped RPO and KBO search. An eight-root
exploratory Innermost slice recovered none, but a later regression test found
that plain-text CPF KBO weights were missed by this version. The converter
now reads those weights (excluding precedence ranks); the slice is therefore
not a definitive test of the corrected KBO search bounds. These follow-ups
do not alter the frozen v2 experiment or its counts. Remaining unconverted
CPF vocabulary is reported in each conversion log.

Twelve converter tests and three report tests pass. The report records exact
root sets, polarities, native event failures, and unsupported baseline actions
under the converter available when reporting. Successful baseline events can
include unused alternatives: these are investigation leads, not causal proof
that an exact witness is necessary.

## Complete termination proofs are retired

`exact-trs-proof` and `exact-dp-proof` now trigger an unconditional failing
assertion both during strategy parsing and at the processor execution boundary.
This applies to release builds and programmatically constructed processors;
there is no opt-in escape hatch. Historical certificate parsers/serializers
remain for data compatibility, not executable proof shortcuts.

Four focused rejection tests pass. Both release CLI entry points were checked
and panic with the retirement message. Nontermination wrappers now have the
same guard, as described below. CeTA is unchanged.

## Nontermination retirement and modular replay (completed)

Both `exact-trs-nontermination-proof` and `exact-dp-nontermination-proof`
now fail unconditionally at parsing and processor execution, like their
termination counterparts. There is no runtime opt-in. Eight retirement tests
cover the four action families and programmatic execution boundaries.

Recovery artifacts are in `target/guarded-role-ab-20260909/`. The initial
314-root baseline-NO replay certified 269 roots. Local recovery and merged
oracle repairs restored all 314. The first YES guard retained 1,444/1,445;
Ex9Maps was then recovered through independently keyed child states, without
restoring a complete proof action.

The final unified **oracle-only, no-fallback** guard certifies **1,759/1,759**:

| Category | Certified YES | Certified NO | Preserved roots |
| --- | ---: | ---: | ---: |
| TRS Standard | 1,039 | 299 | 1,338 |
| TRS Innermost | 301 | 10 | 311 |
| CSR | 105 | 5 | 110 |

Exact certified root sets and polarities match r985, with zero losses or
uncertified decisions. All 1,759 certificates passed two additional production
CeTA checks (3,518 invocations), and their digests were checked again after
the run. Previously unresolved inputs were **not** rerun: this is a complete
certified-root regression guard, not a new category high-water mark.

Final details, CPFs/events, and exact comparison:
`final-certified-root-replay-v1/{details.json,comparison.json,run/}`.
Global oracle: `oracle-no-composite-v13.jsonl`, SHA-256
`60f1e090e50db02f329ffc1d8c47fca2ec77e9c4a2e954c1afd2d2688c4a4297`.
Audit: `no-composite-audit-v13.json`: 517,008 states, 20,762 witness definitions,
zero complete termination/nontermination actions, dangling references, or
malformed records. Frozen binary: `ferrum-modular-no-v11`, SHA-256
`bce5cce9b76bc8678f19c519251e79ed77c9d558494c6c55a1d930b173448759`.
All paths above are relative to the artifact directory. Allowances remain
300 seconds Standard/CSR and 1,200 seconds Innermost, plus five-second harness
margins. Final concurrency: 32 roots, two Rayon threads each.

Modular fixes include Full-rewriting nontermination rule deletion, Q reduction
with its nontermination side conditions and loss of minimality, Q-aware
narrowing/rewriting continuation, causal child aliases preserving Q (including
empty Q), live-variable binding at DP transformation, and correct complete
instantiation semantics: replace P by the displayed simultaneous instances,
not append them. These are individual processors, not embedded proof chains.
Numeric-symbol quoting aliases also use the surviving DP signature when R is
empty. CeTA is unchanged.

The final Rust library suite has 936 passes, no failures/ignored tests;
binary/doc targets pass, as do 226 focused Python tests (including 202
extraction tests). `git diff --check` passes. One earlier loaded run hit a
persistent-Z3 stdout closure; its isolated repeat and subsequent full suites
passed. No test was ignored to obtain the final result.

CeTA-CSR is unchanged at `b018e39ca3d4de9a1fe1e50df2b4feecd2ede6f5`, checker
SHA-256 `a6d8977c1738daa3e225f0e52443fb56659d09b175516d4215bcd77a3bf0ab46`.
Unrelated CeTA worktree edits were not staged, reverted, or committed.

### Migration rationale

The previous ablation retired termination composites only. For nontermination,
first distinguish terminal evidence (a loop, pattern nonloop, or automaton)
from a proof containing preprocessing steps followed by such evidence. The
terminal witness is the evidence required by its processor, not a pipeline to
split artificially into individual rewrites. Preprocessing should become
ordinary state-local transformation events with independently addressable
residuals. Once these reproduce the certified baseline, retire the complete
nontermination wrappers with the same hard guard. The guards are now active;
the replay recovery is being completed as described above.

## Pipelines and ordering

Action ordering ranks alternative applicable processors at a state. It is
normal modular guidance: it does not replace the processors or their proofs.
`replay_order` contains atom hashes and only orders existing positive guidance.

A pipeline additionally carries a selected continuation across child states,
for example graph, usable rules, matrix, graph. Each step still executes and
produces a separate processor event, but this is stronger scheduling state
than a fresh oracle lookup at every child. The current DP scheduler can give
an explicit continuation precedence over generic child guidance; exact strong
guidance on full ordinary DP states has a special override, and GM04 has a
separate policy. This is an implementation/search dependency, not a theorem
requiring non-modular proofs. A fully state-first design would make inherited
continuations advisory alternatives, preserve the selected proof context, and
consult child-local guidance consistently, not only when it is exact.

## How to measure witness dependence

Do not count `exact-*` events as proof of dependence on imported witnesses.
For example, the native graph processor computes SCCs and emits an
`exact-graph` event recording the result for future training. It can do that
even when the input oracle contains no exact actions.

Two experimental oracles were made from the frozen v271 global oracle:

1. Remove all exact actions (including nested ones) and their references;
   retain existing generic guidance.
2. Replace supported exact actions with ordinary processors, retaining only
   dimensions and numeric search bounds, and strip unsupported exact actions.
   Preserve action order by remapping hashes. These are search experiments,
   not newly certified evidence: inherited statistics refer to the old actions.

Both use the identical 110-root CSR set, 16 workers, two Rayon threads per
process, `timeout(300s, fail)`, 305-second harness limits, disabled fallback,
and `/work/dfm/festschrift/CeTA-CSR/ceta`. Neither uses whole-proof replay.
Artifacts are in `target/guarded-role-ab-20260909/`:
`no-exact-replay`, `parameter-only-replay`, and their corresponding oracle
files and logs. Both oracles were scanned: zero retained exact candidate actions.

Frozen release binary SHA-256:
`ee7b06310ddc51b6149408664ce31483f399945207ff86cd56ed6d9914d9757c`.
No-exact oracle SHA-256:
`55283cd99dd0338a7aa976f7b59375d7db7577a0915c1eef4fb48b63d8691c89`.
Parameter-only oracle SHA-256:
`f9808ca49d154024ebdd209205085e3726ba111b7d0a7834d2a5592cecee04a0`.

A failure here means not recovered by these bounded searches and available
continuations. It does not prove intrinsic necessity of a supplied witness.
For example, `csrdiv` records a transformation producing an unguided residual;
that is a continuation-coverage failure, not a mathematical impossibility of
rediscovering the terminal model.

## Completed results (2026-09-09)

Follow-up in progress: enabling state-local priority for CSR DP states alone
recovered none of the 14 misses (`state-local-csr14`). The parameter converter
had missed native CPF `interpretation/type/polynomial` declarations. It now
derives actual polynomial degree, rational denominator/gap, and numeric bounds
without importing coefficient assignments. Six converter tests pass.
`parameter-cpf-fixed-csr14` recovered `Ex4_7_37_Bor03` in 3.407 seconds and
`MYNAT_complete-peanoSimple` in 3.970 seconds, certified by the production
checker. This establishes 98 distinct witness-free roots across experiments,
**not** a completed 98-root single-oracle replay. Twelve remain unrecovered
by these parameter-only experiments; the complete-witness baseline is 110/110.

Initial nontermination migration snapshot (superseded by the replay above):
299 Standard NO source proofs passed fresh checker
rechecks; extraction produced 943 events from 295 sources. Four sources yielded
no events and require recovery. The output includes 144 primitive TRS terminal
witness actions. The new terminal action rejects composite wrappers and binds
the witness to its source TRS; final witness validity still requires CeTA.
At that point 196 extraction tests passed and retirement/recovery were pending.
Artifacts: `nontermination-events.jsonl`,
`nontermination-gates.json`, and `nontermination-extraction.log` under the
experiment directory above. CeTA has not changed.

| Experiment | Certified YES | Certified NO | Total | Unresolved |
| --- | ---: | ---: | ---: | ---: |
| Exact actions removed | 87 | 5 | 92/110 | 18 |
| Ordinary processors with derived parameter bounds | 91 | 5 | 96/110 | 14 |

The second run preserves every success of the first. Both have zero
uncertified YES/NO decisions. All 188 retained certificates passed an
additional independent production CeTA invocation. These are ablation results,
not replacements for the full 110/110 exact-guidance baseline.

The 14 not recovered by either experiment are:

- CSR_04: `Ex1_GM03`, `Ex3_2_Luc97`, `Ex4_7_37_Bor03`, `Ex5_7_Luc97`,
  `ExIntrod_Zan97`.
- Maude_06: `LISTUTILITIES_complete-noand`, `LISTUTILITIES_nokinds-noand`,
  `LengthOfFiniteLists_complete`, `MYNAT_complete-noand`,
  `MYNAT_complete-peanoSimple`, `OvConsOS_complete-noand`,
  `PALINDROME_complete-noand`, `csrdiv`, `emmes`.

Thus 96 roots demonstrably do not require supplied exact witnesses. Fourteen
is an upper bound on current operational witness dependence, not a proof of
necessity: parameter search and generic child-guidance coverage remain
incomplete. The earlier count of 105 exact-event traces must not be used as
that dependence count; native computation itself can emit exact events.
