# TermCOMP 2025 TRS Standard NO Proof Gap

This note records a local inspection of the TermCOMP 2025 `TRS_Standard`
AProVE certified NO artifacts and compares them with Ferrum's current
nontermination capabilities.

Sources:

- TermCOMP category page: <https://termcomp.github.io/Y2025/TRS_Standard.html>
- TermCOMP aggregate summary: <https://termcomp.github.io/Y2025/TRS_Standard.summary.json>
- Raw AProVE certified proof artifacts are linked from the category page under
  `jobs/job_60781488/cert/proofs/benchmark_*/solver_2.txt`.

Local downloaded corpus:

```text
/tmp/ferrum-termcomp-standard-proofs/index.json
/tmp/ferrum-termcomp-standard-proofs/proof_features.json
/tmp/ferrum-termcomp-standard-proofs/proof_features.csv
/tmp/ferrum-termcomp-standard-proofs/tag_counts_no.json
```

The analysis below uses the 262 `CERTIFIED NO` artifacts in that corpus.

## Headline

Ferrum currently has essentially no certified NO engine. It can parse and
validate TRSs and it rejects extra right-hand-side variables as invalid input,
but it does not turn those cases into a `NO` answer with a CPF
`trsNonterminationProof`. It also does not search for or emit loop,
non-loop, narrowing, instantiation, DP nontermination, SRS, or transformation
based nontermination certificates.

The most immediate missing technique is therefore not a search heuristic but
the ability to represent, find, and certify nontermination proofs at all.

## Top-Level AProVE NO Shapes

The direct child under `trsNonterminationProof` gives the outermost proof
shape.

| Top-level proof shape | Certified NO proofs |
| --- | ---: |
| `innermostLhssIncrease` | 72 |
| `dpTrans` | 61 |
| `variableConditionViolated` | 60 |
| `ruleRemoval` | 40 |
| `constantToUnary` | 12 |
| `nonterminatingSRS` | 10 |
| `uncurry` | 7 |

These counts are disjoint because they count the outermost processor only.

## Technique Presence

The following counts are proof-level presence counts. They are not disjoint:
most useful NO proofs combine several processors before reaching a loop or
non-loop certificate.

| Technique or certificate | Certified NO proofs |
| --- | ---: |
| Dependency pairs for nontermination | 192 |
| Rule-removal or narrowing-search simplification | 178 |
| Rewriting processor | 171 |
| Loop certificate | 151 |
| Innermost LHS increase/removal family | 114 |
| Instantiation | 96 |
| Narrowing | 82 |
| Variable-condition violation | 60 |
| Non-loop / narrowing certificate | 41 |
| Constant-to-unary transform | 12 |
| String reversal | 12 |
| SRS nontermination | 10 |
| Derivation patterns | 10 |
| Uncurrying | 7 |

## Common Combinations

The largest exact feature combinations show that AProVE's NO side is mostly a
loop-finding pipeline around DP nontermination, rewriting, instantiation, and
narrowing.

| Exact feature set | Proofs |
| --- | ---: |
| Variable-condition violation only | 60 |
| DP + loop + rule removal + rewriting + instantiation + innermost LHS | 27 |
| DP + loop + rule removal + rewriting | 27 |
| DP + loop + rule removal + rewriting + narrowing | 23 |
| DP + non-loop + rule removal + narrowing + instantiation + innermost LHS | 20 |
| DP + non-loop + rule removal + rewriting + narrowing + instantiation + innermost LHS | 19 |
| DP + loop + rule removal + rewriting + innermost LHS | 18 |
| DP + loop + rule removal + rewriting + innermost LHS + constant-to-unary + string reversal | 11 |
| SRS nontermination + derivation patterns | 10 |
| DP + loop + rule removal + rewriting + instantiation | 10 |

## Representative Benchmarks

Variable-condition violation:

- `TRS_Standard/Transformed_CSR_04/Ex3_12_Luc96a_L.ari`
- `TRS_Standard/Transformed_CSR_04/Ex7_BLR02_L.ari`
- `TRS_Standard/Transformed_CSR_04/Ex8_BLR02_L.ari`
- `TRS_Standard/Transformed_CSR_04/ExAppendixB_AEL03_L.ari`

DP nontermination with loop certificates:

- `TRS_Standard/Transformed_CSR_04/Ex3_3_25_Bor03_FR.ari`
- `TRS_Standard/Applicative_05/termMonTypes.ari`
- `TRS_Standard/Applicative_05/TypeEx3.ari`
- `TRS_Standard/Applicative_05/TypeEx5.ari`

Non-loop / narrowing certificates:

- `TRS_Standard/AProVE_10/andIsNat.ari`
- `TRS_Standard/AProVE_10/double.ari`
- `TRS_Standard/AProVE_10/ex1.ari`
- `TRS_Standard/AProVE_10/ex2.ari`

Constant-to-unary plus string reversal:

- `TRS_Standard/HirokawaMiddeldorp_04/n003.ari`
- `TRS_Standard/HirokawaMiddeldorp_04/n004.ari`
- `TRS_Standard/Strategy_removed_CSR_05/Ex1_Zan97.ari`
- `TRS_Standard/Strategy_removed_CSR_05/Ex6_GM04.ari`

SRS nontermination:

- `TRS_Standard/Transformed_CSR_04/ExConc_Zan97_Z.ari`
- `TRS_Standard/HirokawaMiddeldorp_04/n002.ari`
- `TRS_Standard/HirokawaMiddeldorp_04/n005.ari`
- `TRS_Standard/Zantema_15/ex01.ari`

Uncurrying:

- `TRS_Standard/Applicative_05/termMonTypes.ari`
- `TRS_Standard/Transformed_CSR_04/Ex9_Luc04_L.ari`
- `TRS_Standard/AotoYamada_05/001.ari`
- `TRS_Standard/SK90/4.40.ari`

## Missing Ferrum Techniques

1. Certified NO proof objects and CPF export.
   Ferrum needs a parallel proof tree for nontermination, with CPF export for
   `trsNonterminationProof` and CeTA regression tests. Without this layer, even
   trivial NO discoveries cannot count as certified results.

2. `variableConditionViolated`.
   This should be the first implementation target. A TRS with a variable on a
   right-hand side that is absent from the left-hand side is nonterminating in
   the ordinary TRS setting accepted by CPF, and AProVE certifies 60 Standard
   NOs this way. Ferrum already detects the validation issue; it needs to
   classify it as NO when the benchmark category semantics allow it and emit
   the CPF proof.

3. Direct loop certificates.
   AProVE uses loop certificates in 151 Standard NO proofs. Ferrum needs a
   checked representation of a rewrite loop with context and substitution, a
   verifier for candidate loops, CPF `loop` export, and a bounded search that
   can be guided by LLM proposals.

4. DP-based nontermination.
   Dependency-pair nontermination appears in 192 proofs. Ferrum has DP
   machinery for YES proofs, but not the dual DP-chain search needed for NO
   proofs. The useful first target is: build DP problems, search SCCs for cyclic
   chains, extract a concrete loop or non-loop certificate, and keep every
   candidate checkable.

5. Rewriting, narrowing, and instantiation for loop discovery.
   Rewriting occurs in 171 proofs, instantiation in 96, and narrowing in 82.
   These are not optional polish: they are how AProVE reaches the loop/non-loop
   certificate in the bulk of the NO corpus.

6. Innermost LHS increase/removal family for nontermination.
   This family appears in 114 Standard NO proofs and is the most common
   top-level proof shape. Ferrum should study the exact CPF semantics before
   implementing it because it crosses the Standard/Innermost strategy boundary.

7. Non-loop certificates.
   AProVE uses non-loop certificates in 41 proofs, especially in the
   `AProVE_10` and `EEG_IJCAR_12` families. These should follow after direct
   loop certificates because they share much of the same substitution and
   narrowing infrastructure.

8. Transformational NO processors.
   Constant-to-unary and string reversal each occur in 12 proofs, SRS
   nontermination and derivation patterns in 10, and uncurrying in 7. These are
   lower-count than the DP/narrowing stack but are relatively self-contained
   once CPF nontermination export exists.

## Recommended Implementation Order

1. Add a nontermination proof enum, CLI result state, and CPF export for
   `variableConditionViolated`; certify the 60 simple NO cases.
2. Add a loop proof checker and CPF `loop` export before adding search. This
   lets Ferrum accept LLM-proposed loop witnesses and externally found loops
   while staying proof-checking first.
3. Add bounded direct loop search over the original TRS.
4. Add DP nontermination problems and SCC cyclic-chain search, with extraction
   to concrete loop witnesses where possible.
5. Add instantiation and narrowing processors for NO proof search.
6. Add non-loop certificates.
7. Add innermost-LHS nontermination processors after validating the CPF
   strategy side conditions against small AProVE proofs.
8. Add SRS/constant-to-unary/string-reversal/uncurrying processors as separate
   narrow improvements.

The first two items should be fast and highly certifiable. The main score
increase, however, will require the DP plus rewriting/narrowing/instantiation
pipeline because that is where most AProVE Standard NO proofs live.

## Implemented First Slice

Ferrum now implements the first certifiable NO slice:

- first-class `Nonterminating` proof status;
- CPF 3 `trsNonterminationProof` export;
- certified `variableConditionViolated`;
- checked CPF 3 `loop` certificates;
- direct self-embedding loop search;
- bounded symbolic narrowing and bounded concrete rewriting loop search;
- recursive dependency-pair nontermination proof trees exported through
  `dpTrans`;
- dependency-pair `dpRuleRemoval`, `rewritingProc`, and `instantiationProc`
  export, with small CeTA-certified smoke certificates;
- a `nonLoop` CPF data model and writer, currently without search or a
  certified synthetic witness.

CeTA accepted smoke certificates for:

- `examples/loop.ari`, via a CPF 3 loop proof;
- `TRS_Standard/Transformed_CSR_04/Ex3_12_Luc96a_L.ari`, via
  `variableConditionViolated`.

The main remaining gap is still the bulk AProVE NO stack: DP nontermination
with deeper nested strategy processors, full `narrowingProc` and
`instantiationProc` search, and generated `nonLoop` certificates.

## 2026-07-30 Certified SRS Derivation-Pattern Slice

Ferrum now represents and emits CPF `nonterminatingSRS` proofs. The initial
search recognizes the symbol-independent commuting-pump schema

```text
a L -> L a
R a -> a R
b L -> b R
R b -> L a b
```

and constructs the checked derivation pattern
`b R a^n b ->+ b R a^(n+1) b`. The chronological certificate uses `OC1`,
`OCintoDP1/2`, `DP_OC_3_2`, `DP_DP_2_1`, equivalence normalization, and
`DP_OC_1_2`, ending in a fitting `selfEmbeddingDP`.

This recovers `TRS_Standard/Zantema_15/ex01.ari`: the previous default run was
MAYBE after 55 seconds, while the new default result is NO and certified NO in
under 0.1 seconds. Artifacts are retained in
`target/termcomp-runs/20260730-zantema15-ex01-certified-60s`.

A processor-only run over all ten AProVE SRS-derivation-pattern proofs gives
1 certified NO and 9 MAYBE:

```text
target/termcomp-runs/20260730-srs-derivation-patterns-aprove10-10x10s
```

Accordingly, the high-impact next strengthening is general bounded
overlap-closure and derivation-pattern saturation with canonical word-pattern
normalization, premise indexing, and self-embedding detection. The current
processor should not be described as full SRS non-loop search.

No CeTA changes were required. The existing
`.tools/ceta-relative-bounds` checker accepts the generated proof.

## 2026-07-30 Word-Context Pumping and `Zantema_15/ex04`

The initial commuting-pump implementation required the left and right pumping
contexts to be single symbols. AProVE's `ex04` proof demonstrates the natural
generalization:

```text
a L -> L a
R a -> a R
P L -> P R
R Q -> L a Q
```

For arbitrary words `P` and `Q`, these rules derive
`P R a^n Q ->+ P R a^(n+1) Q`. Ferrum now extracts those words structurally
and emits their exact CPF contexts. In `ex04`, `P = a L` and `Q = R a`.

The focused processor now certifies two of AProVE's ten
`nonterminatingSRS` proofs:

```text
target/termcomp-runs/20260730-srs-derivation-patterns-word-contexts-aprove10-10x10s
```

The default portfolio certifies all ten because eight have simpler loop
certificates:

```text
target/termcomp-runs/20260730-aprove-nonterminating-srs-10-default-word-contexts-10s
```

The next derivation-pattern strengthening remains general canonical
overlap-closure saturation rather than another fixed pumping context.
No CeTA change was required.
