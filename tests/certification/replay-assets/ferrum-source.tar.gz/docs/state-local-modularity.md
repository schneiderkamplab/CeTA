# State-local continuation retirement and independent-action audit

Work started 2026-09-14, from `b46ee17`, against the baseline in
[state-of-the-art.md](state-of-the-art.md): Standard 1,338, Innermost 311,
CSR 110, all independently certified. These are retained certified roots,
not the entire unresolved benchmark set.

Implementation commit: `b3b32abd577d058b2d2eb8f4bc7ee9d258c02943`.

## Follow-up: renaming and witness transport recovered

Implementation `9d6adc3f3981dd82bff5e54f08781730536e050c` recovers all
38 differing child actions and 24 previously uncovered transports described
below. The final combined audit is 62/62 equal; the full state-local
oracle-only guard remains 1,759/1,759, including CSR 110/110. Every retained
root certificate passed two additional CeTA checks.

See [renaming-audit-recovery.md](renaming-audit-recovery.md) for the fixes,
remaining timing qualification, intermediate losses and their recovery, and
exact artifacts. Use the latest oracle/checkpoint in
[state-of-the-art.md](state-of-the-art.md), not the historical paths below.
The separate standalone CSR checker-entry boundary discussed below is not
claimed resolved by this renaming/transport work.

## Scheduling change

Strict oracle replay now drops inherited strategy tails at both top-level
and DP residual boundaries. A child retains its complete mathematical context
and its oracle, but must choose its own action. Ordinary fallback search and
explicit strategies without an oracle retain normal sequencing semantics.
`FERRUM_ORACLE_STATE_LOCAL_ONLY=1` also enables this policy for diagnostics.

The original ablation (`target/state-local-modularity-20260914/replay`)
retained 1,758/1,759: Standard 1,337/1,338, Innermost 311/311, CSR 110/110.
The only miss was `AG01/#3.21`. Its semantic-labeling child had exactly the
same runtime key as before, but its next action existed only in the inherited
pipeline. Exporting the observed actions at their live state keys recovered
the example; the fresh proof passed CeTA twice.

`scripts/export_runtime_local_action_hints.py` checks each retained source CPF
twice and verifies its stored hash. It imports scheduling hints with **zero
independent certification credit**, not certified intermediate proofs: a
certified root's trace can contain successful branches not used in that proof.
Every recovered root must still be reconstructed and checked. Whole-proof
and pipeline actions are rejected by this exporter.

The merged oracle is
`target/state-local-modularity-20260914/oracle-state-local-v1.jsonl`, SHA-256
`fd0d35f05132c29a1632b7a879a7f41cad2678ba3e1bd96e0650da6be1ce0fbf`.
Its audit contains 517,010 state records and 20,765 exact-witness definitions,
with zero composite proof actions, malformed records, or dangling references.
The unified guard is in `target/state-local-modularity-20260914/final-replay-v1`;
its completed comparison retains **1,759/1,759**, with zero missing inputs,
losses, polarity changes, or uncertified decisions. All 3,518 additional CeTA
rechecks passed. The guard binary has SHA-256
`36eec759470e663939d845e655ce274e09b677638c5551360398d9378d3c7190`.
It ran with the explicit diagnostic flag; the committed policy additionally
makes the same behavior automatic for strict no-fallback oracle replay.

## Independent child probes

`scripts/audit_independent_modular_actions.py` resolves content-addressed
inputs from saved runtime events, selects actual child states, and invokes one
recorded action through `probe-cpf`. No oracle, parent history, or inherited
strategy is supplied. Repeated identical state/action pairs are deduplicated.
Standalone positive certificates are checked twice. Open transformations
remain open, not independently certified successes.

Typed renaming transports XML symbol/variable occurrences, including Q,
replacement maps and marked-symbol structure. Supported exact-witness
schemas transport XML fragments or interpretation symbol fields without
changing numerical models, rule indices, or processor tags. Unknown schemas
are reported as uncovered, never guessed. `empty` is now independently
probeable through the existing mandatory empty-system processor; nonempty
inputs are still rejected.

`scripts/audit_modular_child_equivalence.py` compares multisets of full-context
canonical child inputs, obligation kinds, and outcomes. The initial 300-action
sample had 254 covered actions with identical canonical children, 41 unsupported
witness transports, and five missing `empty` entry points. The latter two
groups motivated the expanded transport and CLI fixes. The exhaustive audit
uses `target/state-local-modularity-20260914/child-audit-all-v2` and remains
separate from the certified-root regression guard. It covered 14,375 distinct
state/action pairs from 15,680 successful child events. Its first transport
pass compared 10,219 pairs equally, found 36 differences, and recorded 652
probe failures and 3,468 unsupported witness transports. Those failure counts
are **pre-fix diagnostic counts**, not remaining failures or root losses.

`child-audit-extra-transports` audits the previously unsupported group using
additional typed transports. `child-equivalence-bijection.jsonl` first tries
the explicitly known inverse input renaming (without changing any context or
indices), then falls back to full canonicalization. This avoids expensive
canonical searches where an explicit bijection already proves equality.

### Ordinary standalone export correction

The exhaustive audit found that ordinary DP terminal probes exported the
original R and implicit Q/minimality rather than the independently supplied
state. The new `write_cpf3_dp_termination_state` exports active R, explicit Q,
normal-form substitutions and minimality. It refuses CSR/outermost context
and relative DP obligations rather than silently projecting them away.
This uses existing CeTA's `innermostLhss` input format, not a checker extension.

Together with the `empty` entry-point repair, the focused recheck recovered
**1,589/1,617** previously failed or rejected probe variants. Remaining:
18 CSR-specific standalone certificate rejections/unsupported proofs and ten
`empty` variants whose relative DP inputs are not representable in this
standalone export. Both original and renamed variants are counted here.
See `export-rechecks-v4/results.jsonl` and the individual checker logs.

### Consolidated post-fix audit

`child-audit-final` reruns all 14,375 distinct actions with the repaired
`ferrum-v4` exporter and the numeric-alias-aware typed witness transport.
14,351 support renaming; 24 still contain witness symbols whose transport is
not implemented (principally generated/encoded polynomial symbols).

Across the 28,726 original/renamed probes:

- 11,551 terminal certificates passed CeTA twice.
- 17,120 produced open transformations, without certification promotion.
- 29 terminal/export cases remain unpromoted: 19 CSR-specific standalone
  cases and ten unrepresentable relative-DP empty-input variants.
- 19 actions were inapplicable, one reported a local timeout, and six hit
  the outer probe ceiling.

These are action/variant counts, **not root counts**. Outcomes from explored
branches need not correspond to the branch used in the retained root proof.
`child-equivalence-final.jsonl` records the residual comparison separately.
It reports 14,309 equal outcome/residual comparisons, 38 differences, 24
uncovered witness transports, and four comparisons blocked by probe failures
or ceilings. Equality here is not a certification status and can include two
matching inapplicable outcomes.
Remaining differences include synthesized-model/search variation and six
exact-witness cases (five subterm, one rational polynomial) requiring targeted
follow-up. A different residual is a diagnostic, not evidence of unsoundness:
complete positive proofs still require independent certification.

### Standalone CSR certificate boundary

Four graph-terminal actions in the initial sample were executed successfully
but their standalone CPFs were rejected (both before and after renaming).
Their enclosing CSR root proofs are certified. This is **not** counted as
independent certification or dismissed as a renaming failure.

CeTA's current top-level `DP_Termination_Proof` dispatch constructs an ordinary
DP problem (`thys/Proof_Checker/Proof_Checker.thy`, `DP_input` branch), whereas
the native CSR proof path uses the CSR-specific checker. A standalone CSR DP
certificate therefore needs a dedicated, semantically correct checker entry
point; emitting an ordinary DP proof does not supply that entry point.
The existing root certificates do not establish that this alternate standalone
encoding is accepted. No CeTA sources or checker binary were changed here.

## Verification and artifacts

- 939 Rust library tests passed, zero failures/ignored, including policy,
  independent-empty-probe and active-R/Q/minimality export coverage.
- 21 modular Python tests, 252 oracle Python tests, and two runtime-hint
  tests pass; `git diff --check` passes.
- `321-default-policy-v3.cpf.xml` certifies without the diagnostic flag: the
  strict no-fallback flag alone activates state-local scheduling.
- Production certification uses `/work/dfm/festschrift/CeTA-CSR/ceta` unchanged.
- Final standalone-probe binary `ferrum-v4` has SHA-256
  `990f76c331eedd0f1f4c2a4cd3ad1e6ccab620ae30c2929a883c5a3551090300`.
  Its additional changes affect independent CPF export/empty probing, not
  the root replay search. CeTA SHA-256 remains
  `a6d8977c1738daa3e225f0e52443fb56659d09b175516d4215bcd77a3bf0ab46`.
- Full-root guards use 32 workers and two Rayon threads; independent probes
  use 16 workers initially and 32 in the consolidated audit, with 60-second
  local ceilings.
- All artifacts are under `target/state-local-modularity-20260914`; earlier
  failed audit attempts are retained rather than overwritten.
