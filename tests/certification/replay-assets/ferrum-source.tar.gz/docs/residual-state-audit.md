# Independent residual audit, 2026-09-15

The retained certified-root baseline remains 1,759 (Standard 1,338,
Innermost 311, CSR 110). Closing children does not increase that root count.
The original audit used production CeTA-CSR main `3ddffbd`. The typed
MU-TERM standalone extension below is now integrated into production main.

All 8,561 transforming action pairs preserve equivalent typed residuals
under original/renamed execution. Independent comparisons preserve Q,
active rules, replacement maps, minimality, strict/weak roles and source-rule
associations. Of these, 7,420 match directly under the input bijection,
101 additionally need replacement-map entry ordering, 1,017 need local
variable alpha-equivalence, and 23 need generated-symbol/rule-order
isomorphism. Exact graph isomorphism, not a hash alone, verifies the last
group. All 10 Python audit tests pass.

Artifacts: `target/residual-state-audit-20260915/` contains
`strict-equivalence.jsonl`, `map-order-equivalence.jsonl`,
`alpha-equivalence.jsonl`, `isomorphism.jsonl`, and 24,022 unique retained
child CPFs in `states/`.

## Independent child closure: all 152 audit gaps closed

The final **v48 oracle** replays **152/152** originally unresolved audit
states without fallback, and every CPF passes production CeTA twice.
The two GM04 recoveries expose another **83 distinct child states**, all of
which also replay independently and certify twice: **235/235** across the
disjoint sets. No composite TRS/DP proof oracle action was enabled.

Production CeTA main is `73662ec`, executable SHA256
`64597fcb0a8c1c09af1de0816283c66f474783df3010fc3e60ca30731f5090b7`.
The frozen oracle is `oracle-v48-final.jsonl`, SHA256
`c73c52debd91ebe8ad0da4c0887f6ee3ac15cd98524034888ff9422b9a6071ea`.
All artifact paths in this section are below
`target/residual-state-audit-20260915/`.

The final ten recoveries since the 142-child checkpoint required:

- Source-bound Q choices and DP transformations, with complete P/R/Q,
  strict/weak-role and minimality checks during witness relocation.
- Structured root-label relocation and source-bound polynomial/matrix/KBO
  orders. CSR order transport checks the replacement map as well as rules.
- Deferred canonical alternatives after stale exact choices, plus fresh
  checked semantic-label continuations for two residuals.
- A native `gm04-source-csr` action that emits an independent source CSR
  child. The verified checker discharges its precise top-pair obligation;
  the surrounding DP or TRS proof remains modular and is reconstructed.

The new GM04 action checks Q multiplicities and exports Q explicitly when R
has been reduced. Seven production boundary tests pass: standalone DP,
nested TRS and reduced-R/fixed-Q positives, plus rejection of colliding roles,
missing source proofs, lost Q/normal-form conditions and changed maps.

Final residual artifacts: `smoke-replay-v27/results.jsonl`,
`smoke-checks-v27-production.jsonl`,
`gm04-new-frontier-replay-v2/results.jsonl`,
`gm04-new-frontier-checks-v2.jsonl`, and
`gm04-bridge-boundary-tests-production-v4/results.jsonl`.
All 975 Rust library tests pass (`gm04-final-library-v3.log`), without
failures or ignored tests, as do 238 focused Python tests
(`gm04-final-python-v5.log`). The final single-build root guard retains
**1,759/1,759** with no losses, missing inputs, polarity changes or uncertified
decisions. Its three concurrent category runs are combined without dropping
or duplicating inputs in `gm04-final-root-details-v3.json`; comparison is in
`gm04-final-root-comparison-v3.json`, and independent double certification in
`gm04-final-root-rechecks-v3.jsonl`. No new root gain is claimed by this child
closure. See the state-of-the-art ledger for the committed versions.

## Historical recovery checkpoints

### Earlier native recovery and strict/weak rule boundary

The later **v20 replay / v32 oracle checkpoint has 142/152 twice-certified
children**, zero checker rejections, and ten remaining gaps. The complete
single-build root guard retains **1,759/1,759** with no losses, missing inputs,
polarity changes or uncertified decisions. Artifacts:
`smoke-replay-v20/results.jsonl`, `smoke-checks-v20.jsonl`,
`native-binding-root-guard-v2/details.json`,
`native-binding-root-comparison-v2.json`.
Selected matrix candidate zero now retains native Q-monotonic rule-removal;
CSR lookup retains exact nested weak advice when canonical lookup has no
positive candidates. Both have focused regressions. The CLI also records
residual replay events and uncertified producer identity for later extraction.
All 967 Rust library tests passed before this final checkpoint verification.

Seven of eleven opposite-renaming counterparts independently replay and
certify twice (`counterpart-replay-v1`, `counterpart-checks-v1.jsonl`), including
one of the already recovered Arctic cases. Thus several remaining misses are
still witness relocation/integration defects, not missing proof power.
The exact innermost-Q payload currently lacks source-state function mapping;
the source and renamed canonical inputs match, but its legacy matcher only
handles numeric aliases and variable alpha-equivalence. Source-bound Q
witness support is the next correction. These observations are not claims
that all remaining ten states have recovered continuations.

The complete v17 residual replay reaches **134/152 twice-certified**, with
zero checker rejections (`smoke-replay-v17/results.jsonl`,
`smoke-checks-v17.jsonl`, oracle `oracle-v27-candidate.jsonl`). Native
exploration has additional checked continuations whose modular runtime
bindings are still being integrated. These are child gains, not root gains.
The v20 full root guard also finished at **1,759/1,759** with no losses
(`native-frontier-root-guard-v1/details.json`). A fresh guard for the current
source changes is running; no new source checkpoint is claimed yet.

Corrections include selected polynomial candidate zero preserving fixed
usable-rule contexts, recursive top-level `probe-cpf`, retention of SRS/TRS
children in DP event logs, content-addressed root input hydration guarded by
the exact digest, and standalone improved-CSR/relative-DP proof extraction.
Complete-proof actions remain disabled. Ambiguous/open native search traces
enter only weak guidance, never certified terminal evidence; compound
strategy wrappers are excluded from the new runtime overlay.

Two semantic-labeling candidates for original/renamed Secret_07_TRS/4
residuals initially failed CeTA. Investigation found two Ferrum bugs:
standalone relative-DP export duplicated strict rules into CPF's weak Rw,
and graph decomposition discharged weak-pair-only cyclic SCCs despite
remaining strict TRS rules. Export/import now partitions/restores the rule
roles, and graph decomposition retains those strict obligations in its
children. Both corrected full residual proofs are accepted by production
CeTA (`strict-labeling-graph-v3.cpf`, `strict-labeling-renamed-v3.cpf`).
Rejected intermediate proofs remain retained and were not promoted.

All **965 Rust library tests pass**, none failed or ignored
(`strict-graph-library-tests.log`). The extractor's 207 Python tests and
eight runtime-overlay tests pass. CeTA source and binary are unchanged
(`68bf6e9`); no Isabelle rebuild was needed.

### Portable witness recovery (candidate integration)

Ferrum fixes are committed as `9ad6e6d`. The v19 full root guard has now
finished: **1,759 certified**, no losses or polarity changes, and all new
root CPFs accepted twice. The validated oracle and exact artifacts are
recorded in the state-of-the-art ledger.

A bounded native graph/SCT/subterm probe subsequently recovered **14 of
the 41** gaps, including a state occurring beneath 13 recorded actions.
All 14 proofs passed production CeTA twice. Their state-local events add
21 runtime keys (seven local witnesses) to `oracle-v20-candidate.jsonl`.
The complete v12 oracle-only smoke replay recovers all 14: **125/152
twice-certified**, zero checker rejections, 27 remaining guidance gaps.
Artifacts: `native-frontier-v1/results.jsonl`,
`native-frontier-checks-v1.jsonl`, `native-frontier-overlay-v1.jsonl`,
`smoke-replay-v12/results.jsonl`, `smoke-checks-v12-complete.jsonl`.
A second direct SCT/subterm pass found no additional closures among the 27.
These are child gains, not additional roots; v20 still needs a full root guard.
No CeTA changes were needed. No relation to unresolved roots has yet been
established; repeated occurrences are only a measured reuse signal.

The complete 152-child v11 smoke replay has **111 twice-certified children**,
zero checker rejections, and 41 remaining guidance gaps. Both former witness
applicability gaps now close: general reduction-pair evidence carries its
source R/P for injective relocation, and usable-rule payloads can be rebound
structurally to live rules while still requiring the live usable closure.
Their newly exposed children close with graph decomposition and ordinary
size-change respectively. No complete-proof actions were enabled.

Artifacts in the audit directory: `smoke-replay-v11/results.jsonl`,
`smoke-checks-v11.jsonl`, and `oracle-v19-candidate.jsonl`. The production
oracle remains v14 pending the complete `witness-portability-root-guard-v1`
oracle-only regression. These two child recoveries are not new root gains.
CeTA source and production binary are unchanged from `68bf6e9`.

Failed worklist searches now retain an actual attempted state. Opt-in
`FERRUM_WORKLIST_TRACE_INPUTS=1` additionally records exact DP inputs;
`scripts/extract_worklist_trace_inputs.py` deduplicates these without
certifying or promoting them. A retained final failure need not be the
deepest blocked child, so the full trace is needed for branch diagnosis.

### Typed MU-TERM standalone certification

The two collapsing/unhiding children of action 191 now emit dedicated
`csrMutermTypedDpInput` / `csrMutermTypedDpProof` certificates, rather than
coercing them to ordinary or improved CSR-DPs. The input records P, R, the
lifted replacement map, minimality and the exact unhiding rules. This path
conservatively refuses additional Q/relative/semantic contexts or changed R.
The existing noncollapsing export path is unchanged.

The first emitted proofs were rejected: materialization wrapped an actual
graph decomposition in a redundant one-component graph over identical P.
The exporter now removes only that identical-obligation layer; it cannot
cross a rule, pair, or context-changing processor. Both original/renamed
children now certify twice with production CeTA in `muterm-replay-v2/` /
`muterm-checks-production-v2.jsonl` under the audit artifact directory.
The rejected `muterm-replay-v1/` remains recorded and was never promoted.

CeTA-CSR main commit `68bf6e9` exposes the existing typed innermost MU-TERM good-chain theorem
as a standalone claim, with executable side-condition checks. Positive,
extra-unhiding-rule, and dropped-minimality tests pass. Ferrum additionally
refuses added Q and changed active R instead of losing those contexts.
The release build and focused export/context tests pass.

CeTA build logs: `target/muterm-standalone-proof-checker*-20260915.log`.
The first two checks exposed interface typing and freshness-proof obligations,
not accepted unsound certificates. The corrected third check passed the complete
`Proof_Checker` session (5m49s wall time); the standalone soundness theory took
2.463s. Isolated Haskell export (5m14s) and production `make haskell` passed.
No dependency HOL/AFP heaps were rebuilt. Production checker SHA256:
`68867d65836cbee37a1dfda80bdc9cdf3ce8f45d10118cccb76ec0ca898402c1`.
All **1,759 retained root CPFs pass twice** with this production checker:
`muterm-production-root-recheck.jsonl`. This is certificate revalidation,
not a new full proof-search replay; the oracle remains unchanged.

The complete 152-child v9 smoke replay now has **109 twice-certified**
children, up from 107, with **zero checker rejections**. The remaining
43 are the existing 41 guidance gaps and two witness-applicability gaps;
no standalone export gaps remain in this smoke set. Artifacts:
`smoke-replay-v9/results.jsonl` and `smoke-checks-v9.jsonl`.
All **958 library tests pass**, none failed or ignored, against production
CeTA (`target/muterm-standalone-library-production-20260915.log`).
Frozen release semantics SHA256:
`71b412c2b8907b61c400fb5fca6edbb0f1f3aca62ba9d1f4a442d01a53cd5204`.

The diagnostic `replay-cpf-states` command imports typed residuals and uses
the production oracle-only worklist. Complete proof actions remain disabled.
Its output explicitly marks results uncertified; `check_residual_replay.py`
checks emitted proofs twice with stable proof/checker hashes and exact
CERTIFIED output. Two import/context regression tests pass.

A deterministic 152-child smoke selection spans processor family, input
kind, and original/renamed variants. The initial checkpoint certified 92
of 95 emitted proofs twice and rejected three. Other states include
inapplicable guidance, unsupported standalone export contexts, and explicit
witness mismatch failures. Unused alternative search children are included,
so these failures must not be interpreted as losses from the certified roots.

The three initially rejected proofs exposed symbol/variable relocation gaps in exact
DP loop/nonloop payloads. Translating function symbols alone is insufficient:
a focused repeat still rejects all three (some loop payload names differ
from their archived input, and the nonloop rule variables also need matching).
That insufficient intermediate change is retained in `rejected-replay-v2/`
and `rejected-checks-v2.jsonl`. No rejected result was promoted into the oracle.

## Implemented recovery

`nontermination_rebind.rs` now matches the primitive payload's own rules to
live pairs/active R, preserving pair versus ordinary-rule roles. Symbol
relocation is injective; pattern-proof variables and pumping/closing
substitutions are relocated consistently, freshening capture collisions.
Ordinary rewrite steps inside pattern proofs retain rule-local variables.
All three originally rejected child proofs certify twice in
`rejected-replay-v3/` / `rejected-checks-v3.jsonl`.

The ordinary DP NO exporter now explicitly preserves Q and NFS in CPF's
existing `innermostLhss` strategy. Five previously refused children certify
twice in `export-errors-v4/` / `export-checks-v4.jsonl`. A mutation regression
checks that CeTA accepts a loop with empty Q and rejects it with blocking Q.
No checker source or oracle changes were needed.

Two inputs spent hours canonicalizing symmetric TRSs. Exact transposition
automorphism pruning preserves the full canonical search result and reduces
their complete guidance lookups to 73 ms and 156 ms (`stalled-v5/`). Both
now finish as inapplicable guidance, not as false certified successes.

The complete v5 smoke run finishes all 152 states: 106 emitted proofs all
certify twice; 41 have no applicable guidance; two reject witness applicability;
two need standalone typed MU-TERM export; one exposed an overly strict
nonloop rewrite-step matcher. The latter is corrected in v7. The first
20 affected root regressions recover with 20 certified NOs in `guard-losses-v7/`.
The final v7 smoke replay completes **152/152** states: **107 twice-certified**,
41 with no applicable guidance, two witness-applicability rejections, and two
typed MU-TERM export gaps. There are **zero checker rejections**. Every gap
is linked to its source action/root in `gaps-v7.json`; unused alternatives
are not labelled certified-root regressions.

The complete cross-category v5 guard plus the explicit v7 corrective reruns
retains **1,759/1,759** baseline roots with identical answers: Standard 1,338,
Innermost 311, CSR 110 (105 YES + five NO). All 23 Standard losses from the
intermediate stricter matcher recover in `guard-losses-v7b/`; Innermost and
CSR have no losses. `composed-guard-v7/comparison.json` records every source
run. This is a **mixed-run guard**, not a claimed fresh single-build full replay.
All 1,759 retained CPFs were then rechecked twice (`composed-guard-v7/twice-rechecked.jsonl`).
Independent root correspondence audits also pass: 110/110 CSR and
1,649/1,649 Standard/Innermost, including actual rules, strategy/map, and
polarity (`csr-root-correspondence-v7.json`, `trs-root-correspondence-v7.json`).

The final library suite passes **957 tests**, none failed or ignored.
Ten focused Python audit tests also pass. The frozen processor build is
`ferrum-release-v7`, SHA256
`1a8bb86e948466f520e002523e7f241f259420f9e3d8c503b655aef3f6a09bc7`.
The subsequent audit-only CLI output change gives duplicate inputs distinct
artifact filenames; it does not alter proof search or certificates.
That change passes two CLI context tests and another twice-certified replay
of all three formerly rejected primitives (`rejected-checks-v8.jsonl`).

The two MU-TERM states are original/renamed children of action 191 from
Innermost `Transformed_CSR_innermost_04/Ex1_GM03_C`. Their collapsing/unhiding
semantics must use the typed MU-TERM obligation, not ordinary/improved DP
input. Existing root certification is not an independent certificate for
these child assumptions. The standalone typed input/checker interface is
still missing; its context must not be erased to report success.
