# Ferrum Reproducibility Log

This document records the concrete steps taken to create the current Ferrum prototype, install its external benchmark/certification tooling, and verify the results.

Date of log: 2026-07-10.

## 2026-10-17: general rule strengthening, three SRS gains, restored environment

Use `source /home/ucloud/miniforge3/etc/profile.d/conda.sh` followed by
`conda activate ferrum` for this campaign. The base environment omitted cvc5;
the correct environment provides Z3 4.15.4 and cvc5 1.3.5.dev. No failing
test was disabled to compensate for that environment difference.

Ferrum `ef952d9e2125aac3f0f4feaa00a50dc5b9d529dc` adds
`srs-strip-contexts(max-prefix=N,max-suffix=M)`, with unbounded defaults and
zero allowed. Shared context removal is linear in word length. Each child
is independently keyed, and only a terminating child reconstructs a parent.
The limits are structural processor parameters, not retained proof witnesses.
The new CeTA theorem proves `rstep R` is included in `rstep S` whenever every
original rule is a checked one-step rewrite under `S`. This general simulation
supports the CPF step without benchmark-specific facts.

CeTA-CSR main `17dbee4b822733cd25235a64178db2ccf590a10e` includes the theorem,
termination-checker soundness case, parser, and fresh generated Haskell.
Its original absolute-RFC entry point is retained. Verification artifacts:
`../CeTA-CSR/target/srs-strengthening-20261017/`. The isolated build uses
`USER_HOME=.../target/isabelle-user-srs-strengthening-20261017` and
`ISABELLE_IDENTIFIER=srs_strengthening_20261017`, cloning existing dependency
heaps instead of rebuilding HOL/AFP. Timed `Proof_Checker`/`Code` build:
17m11s; final RFC layer: 6m14s. Haskell code generation took approximately
264s and 260s respectively. The new general theorem itself checked in 0.264s.
No shared heap directory was modified.

All three discoveries, in `target/srs-native-20261013/strip-bounded-matchbox-v623`,
passed production certification, monotone export, strict witness-free replay
in `replay-strip-v625`, double checking, and original-input correspondence.
The global oracle is `integrated-strip-v625/oracle.jsonl`. Its exact checksums,
commits, totals, and remaining frontier are in `docs/state-of-the-art.md`.
All 3,461 retained certificates passed the candidate production binary twice
before installation. Final release library suite: 1,232 passed, zero failures
or ignored tests; all twelve protected replay guards certified twice.

Scope of the remaining related misses: the default maximal stripping can
overstrengthen children, but matching Matchbox's numeric Drop counts still
leaves eleven bound-two examples open. The remaining issue is therefore not
merely the choice of dropped context; native RFC automaton completion/closure
needs further investigation. Neither external raw YES nor a proof for an
unrelated strengthened system is promoted as a certified original root.

## 2026-10-16: remaining certified and raw SRS competitor targets

Follow-up: the periodic and expanded-order waves completed without gains.
The summed-weight wave also completed 170 roots without gains (169 Unknown,
one timeout); its original/renamed benchmark probes both failed to close.
The full suite nevertheless passed 1,163 tests. This is a tested optional
encoding, not an established coverage or performance improvement.

The next concrete Arctic encoding changes are dynamic evaluation bit widths
(previously fixed at six bits) and query-local sharing of identical subterms
across weak/strict obligations. Finite max-plus path weights are bounded from
term depth and coefficient/constant bounds; six bits remain the minimum.
The exact model checker is unchanged. For the first missing Wenzel root,
dimension-four SMT shrank from 2,545,622 bytes to 526,938 bytes (79.3%).
All 18 focused Arctic tests pass, including width and cache regressions.
`competitor-cached-orders-v85` measures recovery; `arctic-protected-replay-v85`
checks nine retained roots with strict oracle guidance and double checking.
All nine protected roots pass strict replay and double checking. Full-suite
output `full-tests-v85.log` records **1,165 passed, zero failed/ignored**.
`arctic-isolated-long-v86` probes four missing roots
with two workers and a 180-second local allowance; despite its historical
label, this is not whole-machine isolation because other campaigns run too.
Any gains must pass fresh native replay with the same recorded allowance.
CeTA is unchanged.

The longer native search recovered `Wenzel_16/abaaba-aabababaab.srs` in
67.941s and `Wenzel_16/abaababa-aabababaab.srs` in 74.875s, both CeTA-certified.
`snapshot-arctic-v87` exports modular parameters/timings: both roots now pass
strict witness-free replay at 180s and double checking, with no unresolved
roots and zero forbidden oracle actions. This yields an incremental verified
union of 1,499, not yet a complete category baseline. `consolidate-arctic-v89`
gates the full SRS/protected replay and freeze on those passing checks.
`arctic-long-frontier-v88` extends the same search to 33 remaining
Arctic-certificate targets with four workers. These timings show that the
short allocations were insufficient; they do not isolate how much speedup
comes from caching versus the longer budget. The 1,497 full-replay baseline
is unchanged pending consolidated replay.

`competitor-frontier-v77` recomputes exact set differences against the audited
v68 replay: Matchbox 118 certified misses, AProVE 42, overlap 20, hence 140
distinct certified targets. Raw-only evidence adds 79 targets (219 total).
Inspection found usable cached CPF evidence for 84 certified targets; 56 lack
an inspected local CPF. Three sampled advertised 2026 certified-proof URLs
still return HTTP 404. This does not imply that the reported results are false.

`competitor-expanded-orders-v78` selects 65 roots after extracting larger
matrix bounds and retaining up to 24 alternative atoms. `competitor-periodic-v79`
tests larger periodic weights on 65 roots. The RFC lane completed 65 roots
without gains. Corrected `competitor-loops-v80` completed all 21 NO targets
without gains (10 Unknown, 11 timeout). These failed attempts do not raise
the certified baseline or cause retained evidence to be removed.

Added opt-in `srs-summed-weight-removal`: under the retained individual weak
inequalities, positivity of the sum of gaps is equivalent to positivity of
at least one gap. This replaces a Boolean disjunction in the canonical compact
integer encoding, not its arithmetic constraints or exact live-model checker.
Old strategy atoms remain unchanged. Six focused weight tests pass, including
renaming, balanced rules, and an incompatible two-rule cycle. Release build
passes. Original/renamed production probes are `summed-weights-renaming-v81`;
the larger search is `native-summed-weights-m2-v82`. Full-suite log:
`full-tests-v81.log` (still running at this entry). No CeTA changes.

## 2026-10-15: deeper witness-free SRS searches after 1,484

The completed/frozen baseline is `final-witness-free-v58-20261015`: 1,484 SRS,
1,338 Standard, 311 Innermost, 110 CSR, with double certification and independent
root-correspondence audits. This section records subsequent experiments, not a
replacement high-water mark.

Implemented opt-in compact SRS weight synthesis (exact cancellation of common
counts and sharing duplicate inequalities), preserving the previous encodings
for old oracle atoms. Focused positive/negative and parser tests pass; the
full serial release suite passed **1,161/1,161**, zero ignored/failures
(`compact-weights-full-tests-v60.log`). Two-layer labeling recovered
`ICFP_2010/{140664,142157,150258}`, all strict replayed and double checked.

Extended native QPI/QPI-BV periods from eight to sixteen without changing
the overflow calculation or the independent integer-Arctic orientation checks.
The old long-word test plus new narrow-bound period 9/12/16 tests pass
(`qpi16-tests-v61b.log`). An initial wide-bound long-word stress run failed
to synthesize within its bounded test; it is recorded in `qpi16-tests-v61.log`, not silently
counted as a passing check. The three forward QPI discoveries and the three
compact-weight discoveries pass strict replay and double certification in
`replay-snapshot-new-search-v63b`. The first snapshot attempt omitted the
category field present in aggregate details; its input-set assertion failed
before any replay could be claimed. The corrected snapshot restores category
from the validated SRS path and preserves the failed attempt's artifacts.

Added source-width-prioritized loop closure, changing search order only. Four
loop tests pass (`target-width-tests-v64.log`), including renamed symbols,
invalid widths, expired deadlines, and a terminating negative. The production
checker certifies `target-width-smoke-v64.cpf.xml`; the first new benchmark NO
is `Waldmann_07_size11/size-11-alpha-3-num-4` (0.271s).
The final serial release suite covering all three changes also passed
**1,161/1,161**, zero ignored/failures (`full-tests-v64.log`).

All paths above are under `target/srs-native-20261013`. Active experimental
waves are `native-{compact-weights-m2-v60,legacy-highweights-m2-v62,
legacy-highweights-m3-v62,qpi16-forward-v61,qpi16-reverse-v61,target-width-v64,
target-small-v66,target-wide-v67}`. `full-expanded-v65.log` gates its selected
waves on complete strict replays before running full SRS and protected-category
replays plus correspondence audits. Further late-wave gains are not implicitly
part of that run. The new runtime binary is `ferrum-target-width-v64`.

No CeTA changes, exact witness imports, benchmark-name dispatch, or changes to
the tuned CSR/Innermost default strategies were made. Memory excluding
reclaimable cache stayed around 300 GiB during these waves.

Late closure probes additionally recovered
`Waldmann_07_size12/size-12-alpha-3-num-{7,408}` (0.755s and 16.724s);
both pass strict oracle-only replay and double checks in
`replay-native-target-{small-v66,wide-v67}`. These are distinct from the first
size-11 NO. Three-layer labeling also recovered `Waldmann_19/random-239`,
which now passes strict replay and double certification. Thus 13 distinct
incremental gains beyond 1,484 have passed these gates (ten YES, three NO).
The late-wave coordinator
`finalize-and-integrate-late-v68.py` waits for the v65 audits, freezes that
oracle, then includes the late widths and three-layer discoveries in another
full protected replay. Neither intermediate union is a completed baseline.

The v65 category replay reached 1,494 SRS and retained all 1,759 protected
roots; double certification passed for both sets. Independent correspondence
audits are still required before freezing this high-water mark. A further
width 11/17/28 loop-search wave is `native-target-middle-v73`.

Renaming audit `renamed-new-search-v69` certified the new QPI and loop cases,
but renamed ICFP_2010/150258 stalled at compact-weight synthesis. Increasing
the allowance (`renamed-compact-budget-v70`) and tightening weight bounds to
128 (`tight-compact-renaming-v71`) did not recover the renamed proof. The
opt-in canonical compact encoding now synthesizes a reduction for both original
and renamed inputs in approximately 15 seconds; both complete proofs pass two
production checks (`canonical-compact-renaming-v72`). Five weight-focused
tests pass. Modular export produced nine states, and the renamed/reordered
root passes strict oracle-only replay and double certification in
`renamed-canonical-compact-v76`. The full serial suite passes all 1,162 tests,
zero failed or ignored (`full-tests-v74.log`).
The broader tight-bound canonical sweep covers 112 remaining roots in
`native-canonical-compact-m2-v75`.

The 112-root canonical sweep and 30-root middle-width loop sweep completed
with zero gains; they are not evidence of additional coverage. The v68 full
replay instead confirms all 1,497 retained SRS roots, with all protected roots
and correspondence checks passing. Refreshed competitor sets are recorded in
`competitor-frontier-v77`: 140 certified targets and 79 additional raw-only
targets. `competitor-expanded-orders-v78` raises the extractor's old matrix
coefficient cutoff and six-action truncation while retaining exact native
model validation. Periodic and reversed/preprocessed RFC lanes are v79.
The first loop lane accidentally used a YES-only selector and selected zero
roots; no search result is attributed to it. The corrected v80 loop driver
uses the explicit 21-root input set and asserts input-set equality.

## 2026-10-15: certified SRS competitor-frontier recovery

Starting from the authoritative 1,467-root frozen SRS replay, the union of
missing Matchbox/AProVE certified 2026 results contains 170 roots. This is a
root-set difference, not a net score difference. The selection and cached
official provenance are in `target/srs-native-20261013/certified-frontier-v50`.

Fixed search-parameter extraction in `scripts/probe_witness_free_oracle.py`:
standalone CPF interpretations now yield polynomial bounds, and scalar
rational matrices can yield rational-polynomial bounds without losing their
domain, coefficient denominator, or strict gap. The conversion does not mutate
source XML or retain assignments; nonscalar dimensions are rejected. Focused
tests: 26 bounds/replacement tests and 15 hint-export tests passed.

`certified-corrected-orders-native-v53` produced seven fresh YESs, all passing
strict no-fallback, witness-free replay and two production CeTA-CSR checks in
`replay-certified-corrected-orders-native-v53`:

- `Waldmann_19/random-519`
- `Zantema_04/z103`, `Zantema_04/z119`
- `Zantema_06/10`
- `Waldmann_07_size12/size-12-alpha-3-num-548`
- `ICFP_2010/85675`, `ICFP_2010/85834`

The generated oracle contains zero forbidden witness/composite actions. Its
new state-local shards are in `integrated-certified-corrected-orders-native-v53`.
This is an incremental recovery result, **not a new complete-category baseline**;
the authoritative frozen baseline remains 1,467 until the merged full replay
finishes. `full-expanded-v58.log` records the gated full SRS/protected-category
replay and independent input-correspondence audits.

The campaign also lifted the external-proof scan's 2 MB cutoff and tested
larger shift-label weight bounds: sampled Matchbox certificates require weights
in the thousands, beyond the previous 128 search bound. Those separate waves
are `native-large-weight-v57` and `native-large-weight-raw-v59`.
The canonical-weight wave completed with 12 certified YESs, all 12 passing
strict witness-free replay and double checks in `replay-native-large-weight-v57`.
Two overlap the seven above, so there are **17 distinct verified incremental
gains**, for a retained-root union of 1,484 (pending the consolidated full run).
The ten additional roots are `ICFP_2010/{167636,86499,57132,86559,57852,85267,
48328,48262,41843,84977}`. No interpretation is supplied: the oracle specifies
context closure, shift labeling, weight-removal bounds (65,536), and residual
actions. The noncanonical comparison remains a separate measurement.

Two exploratory harness mistakes are retained transparently: v52 attempted
unsupported top-level `rat-poly` atoms (33 parse errors), corrected in v53;
v56 attempted top-level `empty` (65 parse errors), corrected in v57. Neither
mistake is a prover/checker rejection or evidence for an unresolved root.

Ferrum runtime remains the frozen `ferrum-final-v40` binary from source commit
`9d7a48e5513f9eecd7ed0b72810c7974367ecfe2`. CeTA did not change; every new
certificate uses `/work/dfm/festschrift/CeTA-CSR/ceta`. No exact interpretations,
composite proofs, or benchmark-specific production code were introduced.

## 2026-10-13: bidirectional bounds completion and native ordinary-rule splitting

`Zantema_05/z30` now certifies from native match-bounds synthesis in 0.78
seconds and from strict parameter-only oracle replay in 4.714 seconds.
Completion can reuse fixed-height paths from both ends, allocating only the
missing middle. It is a fallback after the existing constructor, and retains
the full strict/weak compatibility checks. The resulting bound-five unary
automaton has 104 states and 173 transitions before cons lifting. No automaton
is supplied. Two new tests cover completion and reuse at exactly the requested
height; production CeTA accepts the full binary-encoded root proof.

`Secret_07_TRS/4` exposed a vocabulary omission: native `split` only selected
dependency pairs, while the historical proof splits an ordinary rule. Native
search now appends active-rule alternatives after the existing pair choices.
It shares the exact replay construction: one relative child makes the selected
rule strict and pairs weak; the complementary child removes the selected
rule. Both children must close. Indexed split candidates preserve existing
pair indices. Tests check residual contexts, out-of-range rejection, and
rejection of a self-identical selected obligation. The full root now certifies
in 5.025 seconds with strict witness-free oracle guidance.

Artifacts below `target/standard-nonloops-20261012/`: `z30-native-v242`,
`z30-oracle-v244`, `secret4-split-chain-v254` (uncredited native transformation
hints), `secret4-rule-split-v258`, and `integrated-secret4-v259` (independently
rechecked root evidence). Library validation: **1,132 passed, zero failed,
zero ignored**, in `rule-split-v256-library.log`. CeTA source and binary are
unchanged. The complete protected replay is still pending; these are two
individual gains, not a new completed aggregate.

## 2026-10-13: remaining-five frontier scheduling and match-path diagnostics

The completed `protected-aprove10-v221` replay certifies all 1,754 selected
roots twice: 1,333 Standard, 311 Innermost, and 110 CSR. See the authoritative
state-of-the-art ledger for the exact implementation, oracle, and checksums.
This remains 44/49 targeted Standard recoveries, not 49/49.

`scripts/probe_native_event_frontier.py` now accepts
`--skip-certified-details`: only states with two successful recorded checker
passes are skipped, regardless of the next recipe or timeout. Previously a
changed recipe repeatedly selected already-closed two-pair Secret_07_TRS/4
states before reaching the open frontier. Duplicate local manifests now share
the original root's probe cap, and duplicate jobs do not consume another slot.
All 24 focused Python tests pass. This changes discovery scheduling only; it
does not promote evidence or bypass checker replay.

Strict match compatibility now quotients automaton runs by tail, head, and
minimum height, using dynamic reachability rather than enumerating complete
height vectors. Weak compatibility deliberately retains the full vectors,
since it distinguishes uniform heights. Branching/epsilon equivalence and
expired-deadline tests pass; the initial complete release library run reports
1,129 passed, zero failures or ignored tests (`match-minimum-v228-library.log`).
The final formatted source repeats **1,129 passed, zero failed, zero ignored**
in 114.75 seconds (`match-minimum-final-v238-library.log`).
Completion logs per-round elapsed time, paths, states, and transitions.

Under `target/standard-nonloops-20261012/`, `z30-timed-v226` shows exponential
state growth, reaching 63,849 states at round 18 without closure. Larger
prefix-sharing (`z30-prefix-v235.log`) and reversed-word completion
(`z30-reverse-unary-v236.log`) diagnostic experiments also did not close the
system. Their temporary diagnostic tests were removed, not ignored. No
alternative automaton-construction policy was promoted to production.
`aaecc-continuations-v229`, `length-children-v232`, and `mynat-children-v233`
did not certify their selected open residuals. These are search results, not
evidence of nontermination or impossibility. The corrected Secret_07_TRS/4
frontier wave is `secret4-open-v237`. CeTA is unchanged.

## 2026-10-13: rule-specific Q-monotonic synthesis

`Secret_07_TRS/aprove02` is recovered by witness-free modular oracle-only
replay in **4.882 seconds**, with production CeTA-CSR certification. This is
the 41st of the targeted 49 Standard recoveries, not a claim that all 49 work.
The formerly blocked two-pair residual closes natively in 1.093 seconds.

The matrix fallback now computes a conservative rule-specific usable
replacement map: it visits every contextual subterm from CeTA's finite
universe and retains positions whose usable closure contains the selected
strict rule. This over-approximates reachable positions; no symbol names or
supplied interpretations participate. Deletion is restricted to that selected
rule. Missing Q coverage retains the previous conservative map. Natural affine
`innermostMonoRedPairProc` evidence exports to native dimension-one matrix
search, preserving rule-removal capability instead of losing it as `poly`.

Artifacts under `target/standard-nonloops-20261012/`:

- `aprove02-qmap-recursive-v162`: native local proof and events.
- `aprove02-qmap-root-v164`: full oracle-only certified root replay.
- `integrated-aprove02-v165`: twice-rechecked modular evidence; the audit
  `witness-free-v165-audit.json` reports zero forbidden witnesses/actions.
- `q-local-map-v31-final-library.log`: 1,124 passed, zero failed/ignored;
  this includes the additional rule-RHS-context regression.
- `q-local-map-v168-tests.log`: four focused tests, including an additional
  rule-RHS-context regression, all pass.
- `qmap-export-v169-tests.log`: 39 Python tests pass.
- `qmap-mutation-v174.json`: two positive CeTA checks and rejection after
  zeroing the first rule-removal interpretation (without changing its type).

CeTA-CSR source and executable are unchanged. `protected-qmap-v166` is the
aggregate guard run; use the state-of-the-art ledger for its promoted status.
`aprove01` subsequently closes in **36.393 seconds** in the full oracle-only
replay `aprove01-live-root-v176`, bringing the individual count to **42/49**.
Its proof uses the independently certified fragments in `source-qmap-native-v169`
and three newly closed live residuals in `aprove01-live-qmap-v173`.
`integrated-aprove01-v177` retains the twice-rechecked modular root evidence;
`remaining7-v177.json` records the seven remaining targets. This later gain is
not included in the `protected-qmap-v166` aggregate.

## 2026-10-13 Standard 49-root recovery, ongoing

Latest follow-up: **32/49 individual recoveries**, 17 still unresolved.
The v21 implementation is committed as **491052d** after the complete
**1,318 Standard + 311 Innermost + 110 CSR** v75 replay and all 1,739
certificates passed two further checks. Later Q-lookup work remains separate.
The v62 complete aggregate now certifies **1,316 Standard + 311 Innermost +
110 CSR**, all 1,737 twice rechecked, with zero losses. This includes 27/49
recoveries; AAECC is the additional individual gain. The v37 complete attempt
certified 1,312 Standard + 311 Innermost + 110 CSR, preserving the entire
committed 1,310-root baseline; all 1,733 positives passed two further CeTA
checks. Its sole miss, `thiemann37`, subsequently replayed in 4.099 seconds
after state-local closure ranking (`thiemann37-closed-chain-v49/`).

Additional recoveries:

- `Ex9_Luc04_C`: inverse CSR transformation, `inverse-oracle-v39/`.
- `Endrullis_06/pair2hard`: sparse native 4D matrix search, 11.646 seconds
  oracle-only, `pair2hard-oracle-v50/`, twice rechecked.
- `Ex14_Luc06_C`: inverse transformation and existing CSR guidance,
  4.670 seconds oracle-only, `inverse-preserved-csr-v52/`, twice rechecked.
  Discovery hints had incorrectly outranked the already successful CSR
  root guidance. Restoring that priority fixed replay. Subsequent imports
  can promote only independently certified input roots, preserving existing
  nested-state order while retaining all additional hints.
- `AProVE_04/AAECC`: 23.990 seconds, `remaining22-narrowing-v63/`; its full
  CPF was checked twice again by `integrated-aaecc-v64/`.
- `Secret_05_TRS/cime1`: about seven seconds, `cime1-oracle-v74/`, full
  strict replay and two additional CeTA checks. Constructor-only max fallback
  synthesizes a reduction of 29/31 pairs; the remaining native polynomial
  states are independently closed and merged in `integrated-cime1-v74/`.
- `AProVE_07/kabasci01`: about six seconds, `matrix-root-v78/`, full strict
  replay and two additional CeTA checks. Broader sparse matrix discovery
  closes its two-pair residual (`matrix-frontier-v76/`).
- `HirokawaMiddeldorp_04/t009`: 11.104 seconds, `native-selections-root-v82/`,
  full CPF checked twice by `integrated-selections-v83/`.
- `Beerendonk_07/17`: 4.561 seconds, `live-native-root-v90/`, full CPF checked
  twice by `integrated-beer17-v92/`; a second replay takes 3.851 seconds.
  Native context priorities and recomputed candidate choices on live
  serializations recover the existing proof mechanism without supplied models.

The WPO lexicographic comparison previously stopped at a weak non-strict
head instead of checking the tail, contrary to CeTA's
`lex_ext_unbounded_mem`. Three new exploratory proofs were rejected and
never entered the oracle. Both synthesis and independent validation are
corrected; those cases now conservatively return Unknown. A small exact
reflexivity shortcut avoids duplicate comparisons. Optional
`ordered-alternatives=1` removes max-expression representation symmetry.
New WPO models required refreshing three covered roots: inverse CSR closes
`Ex4_Zan97_C`, five certified local states recover `Ex5_7_Luc97_GM`, and
native WPO with constants <=8 and two alternatives closes the
`Ex3_2_Luc97_GM` residual in 2.118 seconds. No supplied order was restored.

Generic narrowing now backtracks over native candidates rather than trying
only candidate zero. Strict state-local guidance no longer depends on
unserialized transformation-depth counters for narrowing and instantiation;
generic exploration retains its depth limits. All processor side conditions
and child-guidance requirements remain enforced. This recovers AAECC.

Current implementation validation: **1,115 Rust tests passed**, zero
failures/ignored, and **59 Python tests passed**. Candidate v19 is frozen at
`ferrum-native-narrowing-v19`, SHA256
`48bcaba0f56b9f7cf17f00806831dab5f994952608630bda755ee794cae3d228`.
`protected-narrowing-v62/` is complete; do not include the later AAECC gain
in its target. The follow-up v20 adds native rewriting candidate backtracking
and serialized `rewrite(candidate=N)` actions; 1,116 library tests pass.
`protected-rewriting-v71/` checks the expanded 1,317 + 311 + 110 target.
The cime1 max-polynomial encoding exceeded its expansion limit before entering
the solver. The new constructor-only max/defined-symbol affine subclass
recovers it, with identical alternatives removed before independent validation.
No supplied interpretation or benchmark-name dispatch is used.
All **1,117** v21 library tests pass. Frozen binary `ferrum-constructor-max-v21`
has SHA256 `2077e2047e95903cb448c7742888a1f6b7cb666f4653af7f737333a3b6983bce`.
`protected-constructor-max-v75/` is the complete 1,318 + 311 + 110 aggregate;
the later kabasci01, t009 and Beerendonk gains are not part of that target. `remaining17-v92.json`
is the current individual-gap manifest.

Diagnostic native transformation-choice recovery (`native-selections-v77`,
`v79`, `native-instantiation-v80`, `v81`) reproduced 283 source-local
narrowing/rewriting/instantiation actions with ordinary native candidate
selection, matching full-context canonical child states. One aprove01
instantiation remains unmatched. `native-selections-v82/` contains only
uncredited parameter-only priorities, no supplied models or proof actions;
`native-selections-root-v82/` must certify complete roots before any gains
are counted. This experiment is not yet the protected production oracle.
No CeTA changes or Isabelle builds were needed. Memory use
remained below 2 TiB excluding reclaimable file cache.

Earlier stages:

Of the 49 YES-reference gaps at the 1,289-root baseline, **24 now have
individually certified, witness-free oracle-only replays**. This is not yet a
new 1,313-root aggregate: the committed complete baseline is now 1,310
Standard, 311 Innermost and 110 CSR. Both v11 and the final v13 source repeat
certify this entire root set. Implementation commit: `b553b37`.
The two NO gaps
were already recovered by constructor recurrence before these 49 YES gaps.

Three WPO gains are transformed-CSR `Ex1_2_AEL03_C`,
`Ex5_7_Luc97_C`, and `LISTUTILITIES_nosorts_C`, with certified oracle-only
times 103.225, 66.717 and 68.297 seconds respectively. WPO now synthesizes
partial argument-status permutations jointly rather than enumerating them.
The independent order validator and unchanged production CeTA check every
result; no supplied order or complete-proof action was restored.

`Secret_07_TRS/aprove08` subsequently passed strict oracle-only replay in
57.033 seconds after two newly closed narrowing/matrix/SCT residual chains
were integrated. Its root CPF passed two further production CeTA checks.
Artifacts: `integrated-live-frontier-v32/` and `live-frontier-root-v32/`.
`AProVE_07/thiemann37` then passed strict certified replay in 343.082 seconds
using the same oracle, also with two additional CeTA checks. Neither is yet
included in the complete 1,310-root aggregate. Subsequently,
`OvConsOS_complete_noand_iGM` passed strict certified replay in 103.336 seconds
and two additional checks (`late-frontier-root-v36/`). That oracle also
reduces `aprove08` replay to 4.001 seconds. **25** original gaps remain;
`protected-expanded-v37/` is checking the expanded 1,313-root Standard union
and protected categories. This is generous-ceiling replayability, not a
60-second-cap claim.

Earlier conditional-calculus improvements recover `otto01` and preserve
context-rich quadratic proofs by trying their existing derivation first.
Unused fresh outputs, local unconditional leaves, capture-safe nested IH
matching, and a bounded independent-predicate fallback use existing CeTA
proof rules. A further premise-order matching improvement is under test.

Artifacts under `target/standard-nonloops-20261012/`:

- `wpo-permuted-c-native-v10/`: three direct certified discoveries.
- `wpo-permutations-oracle-v18/`: three strict root replays.
- `integrated-wpo-permutations-v18/oracle.jsonl`,
  `witness-free-v18-audit.json`: 558,817 states, no forbidden actions;
  SHA256 `dd9875464db448b53eca9b831d9fa3024cd844a47a35ec373e4c44b5b089a0e1`.
- `integrated-wpo-frontier-v22/oracle.jsonl`: subsequent local residual
  additions; local successes are not counted as recovered roots.
- `remaining28-v25.json`: exact remaining YES-reference set.
- `protected-compact-opt-in-v24/`, `guard-reference-v24.json`: complete
  1,310 Standard + 311 Innermost + 110 CSR replay, zero losses or checker
  failures. All 1,731 CPFs passed two additional CeTA rechecks.
- `protected-final-candidate-v31/`: complete repeat with the final v13 source;
  all 1,731 roots certified and independently checked twice, zero losses.

The first protected candidate (`protected-permutation-v17`) exposed search
regressions on `Ex3_2_Luc97_GM` and `Ex5_7_Luc97_GM`, both Unknown, not
checker-rejected proofs. Isolating the former residual showed the legacy
WPO encoding solving in 54.445 seconds (CeTA CERTIFIED), versus a 90-second
timeout after compacting ground max expressions. `compact-ground` is now
explicit: off for legacy statuses, on by default for the new permutation
lane, and independently overridable. Mathematically equivalent SMT encodings
are not assumed performance-equivalent. The failed candidate is not promoted.

`wpo-compact-opt-in-v11-library-tests.log`: 1,110 passed, zero failed/ignored.
Both exploration-helper suites pass (46 tests). The subsequent unordered-IH
change passes 14 focused tests and its full suite passes 1,111 tests with zero
failures/ignored. The optional discovery continuation budget passes 21 worklist
tests; it is unset in all protected replays. The final source's full library
suite passes 1,111 tests. Its 53-root conditional-processor guard slice is
fully certified, with exact-set comparison and two additional checks each.
No CeTA changes or
Isabelle builds were required. Memory excluding reclaimable cache reached
approximately 623 GiB during this wave, below the 2 TiB cutoff.

## 2026-10-12 Complete retained pattern-nonloop recovery

Implementation: `0db5c7cf7d472efa0673a3e1f6a27c8d9e149403`.
The previous inventory contained **25 remaining pattern-nonloop gaps**, not
254. All 25 now have native synthesized proofs, extending terminal coverage
from 18/43 to **43/43**. Every final terminal passed CeTA-CSR twice, as did all
43 explicit full-root discovery proofs. The final protected oracle-only replay
certified all 43 without fallback or supplied witnesses.

`src/proving/nontermination/pattern_search.rs` now supports context-growing
initial pumping with an explicit no-marked-step guard, commuting extensions,
safe free-parameter restriction, iteration-domain identification, bounded
pumping shifts, helper partial evaluation from live ground arguments, and
base/substitution rewrite chains. Closing factors are solved by matching;
free exit parameters are unified through checked base instantiation. Explicit
irrelevant-context equivalences establish global closure equations. Closing
context simplification checks both composition and commutation. Renaming-stable
keys and constructor/marked-root filters reduce repeated or dead search.
The local allowance is 60 seconds, bounded by the caller's deadline, with
three helper levels, ten main levels and a 2,048-entry main frontier.

No named-symbol dispatch, imported proof trees or hard-coded witnesses were
added. The rules are accepted by the existing `Nonloop_Impl` calculus;
**CeTA did not change**. Production checker: `../CeTA-CSR/ceta`, main commit
`73662ec88a74f65187cba6986d300836564b6a59`, SHA256
`64597fcb0a8c1c09af1de0816283c66f474783df3010fc3e60ca30731f5090b7`.
Unrelated existing CeTA worktree edits were left untouched.

Artifacts under `target/standard-nonloops-20261012/`:

- `terminal-complete-v22.json`: 43/43, duplicate production checks.
- `discovery-complete-v20.json`: 43/43 full-root native discoveries.
- `parameter-complete-final.jsonl`: monotone merge over the previous complete
  oracle, retaining CSR and Innermost guidance. Its two audits report no exact
  witnesses, composite actions, pipelines or malformed records.
- `all-complete-final/`: protected 64-worker replay, Rayon=2,
  `FERRUM_DP_LLM_NO_FALLBACK=1`, time scale 200%, 1,200/1,205-second ceilings.
  Standard first pass: 989 YES, 297 NO, one Unknown; Innermost: 301 YES, ten NO;
  CSR: 105 YES, five NO. All positive decisions certified.
- `repeat-complete-final/`: `GTSSK07/cade14` certified in 10.818 seconds with
  unchanged binary/oracle/ceilings. The first attempt took 13.439 seconds and
  exposed a different conditional-polynomial residual without guidance; the
  successful repeat used the known continuation. This variation is recorded,
  not hidden as a flawless first pass or attributed to the non-loop changes.
- `consolidated-complete-final/{details.json,attempts.json}` and
  `all-complete-final-rechecks.jsonl`: **1,708 retained roots**, each rechecked
  twice again; no exact-set losses or polarity changes. Standard is now
  **1,287/1,338 = 990 YES + 297 NO**. All 25 new roots certified on the first
  pass in 3.971–49.020 seconds (median 4.485).
- `library-complete-v22.log`: **1,099 passed, zero failed or ignored** using
  `CETA_CSR_BIN=/work/dfm/festschrift/CeTA-CSR/ceta`. The six Python export,
  merge, local-event, witness-free-probe, comparison and runtime-frontier
  suites passed **260 tests**. `rustfmt --check` on the changed module and
  `git diff --check` passed.

Final binary SHA256:
`1203955b9f99e458704ba4d8681c4f5acd333266a6a3593eb4f9aa11ac038be7`.
Final oracle SHA256:
`f9e1ff39fb35757c23f59831993779ad89aa884d44341582530f8eff7b64eeae`.
The remaining Standard frontier has 49 YES-reference roots and two other NOs;
the retained pattern-nonloop frontier is empty. See `docs/state-of-the-art.md`
for the authoritative complete replay totals and exact paths.

## 2026-10-12 Pattern rewriting and commuting simplification

Implementation commit: `99ce79463993f0064eaeefdeb9352a26bbf4a9c3`.
Native pattern search now rewrites the base and pumping/closing images using
explicit live-rule steps. A bounded 12-step base lane avoids charging each
ordinary rewrite against the four-level pattern-search bound; one-step
alternatives remain available. Simplification checks both CeTA equations:
closing-factor composition and commutation with pumping. It can identify
iteration variables with equal closing images and extracts commuting closing
entries by fixed-point pruning rather than subset enumeration. Identity
substitution entries are removed after rewriting. These operations follow
the existing `Nonloop_Impl` checker; no CeTA changes were made.

The 43-case terminal probe improved from 17 to **18 certified**, with no losses
or checker-rejected positives. The new `emmes-nonloop-ex6_2` terminal certified
in about 72 ms, but the first full-root attempt timed out at 60 seconds inside
the older elementary search. Scheduling now gives elementary search one second,
then tries bounded pattern synthesis, then resumes elementary search if needed.
Full-root discovery subsequently certified in **1.040 seconds**. All 18 full
roots passed two production checks. No benchmark-specific production code or
retained proof trees were introduced.

Artifact base: `target/standard-nonloops-20261012/`. `ferrum-rewrite-v6` and
`parameter-rewrite-final.jsonl` are the frozen verified binary/oracle pair.
The oracle is a monotone merge over the previous `parameter-v5.jsonl`.
The complete replay command was:

```sh
python target/standard-nonloops-20261012/replay_roots.py all-rewrite-final target/standard-nonloops-20261012/ferrum-rewrite-v6 --oracle target/standard-nonloops-20261012/parameter-rewrite-final.jsonl --details target/standard-nonloops-20261012/all-reference-rewrite-v6.json --all-categories --jobs 64 --timeout 1200
```

Standard's first pass certified 1,261/1,262, with one Unknown on
`Ex3_2_Luc97_GM`. Its identical-configuration repeat certified in 47.065 seconds;
`consolidated-rewrite-final/attempts.json` preserves both attempts. Retained
totals: **Standard 1,262 (990 YES, 272 NO), Innermost 311, CSR 110**. This is a
1,200-second retained-root replay, not competition-cap performance. The exact
comparisons and two additional CeTA checks passed for all 1,683 retained CPFs.
See the SOTA ledger for exact hashes, commits and unresolved inventories.

Verification: `CETA_CSR_BIN=/work/dfm/festschrift/CeTA-CSR/ceta
RUSTUP_HOME=/work/dfm/.rustup CARGO_TARGET_DIR=target/csr-native-twelve-build
cargo +1.95.0 test --release --lib -- --test-threads=1` passed **1,090 tests**,
none failed or ignored. An initial invocation without `CETA_CSR_BIN` selected
stock CeTA and failed six standalone-input parsing tests; the explicit
production-checker rerun passed them all. Five added tests cover checked
substitution rewriting and missing-rule mutations, list-growth certification,
rejecting variable-redex narrowing, commuting simplification instances, and
equal-domain factorization. The four focused Python suites passed **49 tests**;
formatting of the new module and `git diff --check` passed. Memory pressure
stayed below 2 TiB excluding reclaimable cache. No Isabelle process was started.

Remaining native non-loop work: 25 cases, including 16 reference proofs using
rewriting/simplification and nine context-growing pumping proofs. More general
helper composition and substitution factorization still need synthesis; these
are not solved merely by making their individual CPF constructors available.

## 2026-10-12 Native pattern non-loop synthesis and preservation replay

Implementation commit: `88f26bac2cc828e4a57ae1e364febbb01c6e0f0e`.
`src/proving/nontermination/pattern_search.rs` adds bounded live-rule synthesis
after elementary `dp-nonloop` search: renamed initial pumping with commutation
checks, explicit domain equivalence, safe instantiation, auxiliary exit chains,
pattern narrowing, and exact substitution-power closure. Repeated helper uses
receive fresh iteration domains. There are no supplied proof trees, symbol-name
dispatches, or benchmark templates. The existing Q/normal-form guards remain.

The campaign in `target/standard-nonloops-20261012/` recovered 17 of 43 missing
pattern non-loops, including all 14 simplest cases. Final `all-v5/` replay:
**Standard 1,261 (990 YES, 271 NO), Innermost 311, CSR 110**, all certified with
modular witness-free oracle guidance and no fallback. This uses a 1,200-second
prover allowance, not the competition cap. Exact-set comparison and two further
production checks passed for all 1,682 CPFs. `final-summary-v5.json` records
commits, hashes and gains; the SOTA ledger records the complete artifact list.

Reproduction (from this worktree, retained helper scripts/artifacts):

```sh
python target/standard-nonloops-20261012/replay_roots.py all-v5 target/standard-nonloops-20261012/ferrum-pattern-v4 --oracle target/standard-nonloops-20261012/parameter-v5.jsonl --details target/standard-nonloops-20261012/all-reference-v4.json --all-categories --jobs 64 --timeout 1200
python target/standard-nonloops-20261012/verify_replay.py
```

Use fresh output paths when rerunning; preserve existing evidence. The runner
sets no-fallback, two Rayon threads, oracle time scale 200%, direct filtered
path-order search and 512 semantic-labeling continuation attempts. The oracle
contains 558,332 states and 1,601,226 actions; both modular and witness-free
audits pass. The first v4 replay's PALINDROME failure was reproduced by the old
binary and repaired with native guidance for its newly observed residual, not
by importing an exact order. Diagnostic attempts are retained separately.

Verification: release library **1,085 passed, zero failed or ignored**;
focused Python suites **49 passed**; formatting of the new module and
`git diff --check` passed. New tests include renamed symbols, missing exits,
expired deadlines, noncommuting pumping rejection, bound-domain instantiation
rejection, repeated helper freshness, accelerated pumping, and a CeTA-negative
mutation removing a required rule. No CeTA changes/builds were needed;
production `CeTA-CSR/ceta` remains at main `73662ec88a74f65187cba6986d300836564b6a59`.
Memory pressure remained below 2 TiB excluding reclaimable file cache.

Remaining: 26 pattern non-loops (17 reference rewriting/simplification,
nine context-growing pumping), 49 YES-reference gaps and two other NOs.
Native terminal attempts for these 26 finished below 4.4 seconds; increasing
timeouts alone has not been shown to address the missing search operations.

## 2026-10-12 All 23 retained loop gaps: modular recovery

Implementation commit: `69769349ce1ee62f7d16ef6d1c4bfa978ddc9563`.
Final whole-set verification reached **1,244/1,338 Standard (990 YES, 254 NO)**,
with CSR **110/110** and Innermost **311/311** preserved. Standard's first
pass certified 1,243 roots; its sole timeout, `LISTUTILITIES_nokinds_noand_C`,
certified in 606.313 seconds in a 1,200-second isolated retry with unchanged
binary/oracle. `consolidated-certified-v52/attempts.json` records both attempts.
Every retained positive passed two additional CeTA checks. Final library tests:
**1,079 passed**, none failed or ignored; four focused Python suites:
**49 passed**. `git diff --check` passed. See the authoritative SOTA ledger for
the complete artifact and checksum list.

`target/standard-loops-20261012/loops-final-v52/details.json` replays all
23 originally missing Standard loop roots with native, witness-free,
state-local oracle guidance and no fallback: **23 certified NO, zero gaps**.
The exact-set comparison has no losses or polarity changes; every retained
CPF passed two additional checks using production `CeTA-CSR/ceta`.
This is a 600-second replay envelope, not a competition-cap claim. Observed
root times ranged from 3.599 to 60.912 seconds in the 16-worker run.

The final three recoveries were `OvConsOS_nokinds_FR`, `Ex1_GL02a_FR`, and
`Secret_07_TRS/7`. Native region narrowing and NO instantiation reconstruct
their preprocessing; canonical cycle restriction removes unrelated pairs.
Independent-argument loop search solves Ex1's relative prefix/marked-step
composition, with a final full-state witness check. Secret's nine-step loop
needs a larger backward frontier. Both small-frontier modes must finish
before widening, or Ex3's short inverse-collapsing route is starved.

The exporter audit caught 28 DP-continuation entries in intermediate
profiles. `parameter-v18.jsonl` replaces them with bare `dp` transformations;
their continuations are independently addressed nested-state actions. The
exporter now prevents this recurrence, with a focused regression. The final
23-root result above uses this cleaned profile, not the earlier pipelines.
`witness-free-v18-audit.json` and `modular-v18-audit.json` report zero witnesses,
references, hex actions, composite proofs, or compound pipelines. The oracle
has 558,320 states and 1,601,142 actions; SHA256:
`be2ede7b1512645953e8cf259f8b50c6a55623a06a9f6d0070c8be7d9e9961e2`.

Immutable optimized binary `ferrum-loops-v52`, SHA256
`7c67ea83225d1ce2b6b5d77d0b775bd4082c99bdd6eefb7861aa85ac9bbc6b8f`.
CeTA is unchanged: main `73662ec88a74f65187cba6986d300836564b6a59`, executable
SHA256 `64597fcb0a8c1c09af1de0816283c66f474783df3010fc3e60ca30731f5090b7`.
No Isabelle rebuild or CeTA source integration was required. Unrelated CeTA
worktree edits were left untouched. Consult `state-of-the-art.md` for the
latest completed whole-set replay rather than inferring it from these gains.

Intermediate v12–v21 exploration binaries were debug builds; their accepted
certificates remain valid, but their timings must not be compared with the
optimized v22-and-later replays. One optimized v40 consolidation missed
`OvConsOS_complete_C` after a different synthesis continuation. Its isolated
v49 replay certified in 40.475 seconds; this is recorded as variability, not
silently counted as a success in the failed consolidation.

## 2026-10-12 Native Standard loop recovery

Artifact base: `target/standard-loops-20261012/`. The retained missing-NO
inventory contains 23 loop proofs, 43 pattern non-loop proofs, and two other
nontermination proofs. This wave targets the 23 loops; it does not count
pattern non-loops as recovered loops.

Ten roots have passed witness-free, no-fallback replay across completed
runs: Hydras/lepper_{2,3,4,5,6,8,9}, Secret_05_TRS/cime4,
Strategy_removed_AG01/#4.13, and Transformed_CSR_04/Ex6_15_AEL02_Z.
Artifacts are `loops-v3/details.json` and `backward-gains-v5/details.json`.
Seven further roots have independently synthesized, twice-CeTA-checked
terminal DP loops but still lack complete preprocessing chains; six still
need stronger terminal search. `loop-coverage.json` distinguishes these
cases. Optimized consolidation subsequently confirmed all ten gains;
consult `state-of-the-art.md` for the frozen 1,231-root high-water mark.

Native actions `nontermination(dp-symbolic-loop)` and
`nontermination(dp-backward-loop)` search the live rules without supplied
loop witnesses. Backward search infers common predecessors of duplicated
arguments. All candidates pass independent native step replay. Unification
now propagates new bindings through existing substitution images. Recursive
DP probe export now preserves NO polarity and the complete DP context.
The loop input-state extractor explicitly discards the reference witness.

Build correction: snapshots v12–v21 were accidentally built in the debug
profile. Their certifications remain valid, but their timing misses must
not be compared directly with release v7 or promoted to regression claims.
Release v22 restores all seven Hydra discoveries under 60 seconds, including
lepper_9 in 54.7 seconds (`symbolic-release-v22/`). Use optimized snapshots
for subsequent campaign timing:

```sh
RUSTUP_HOME=/work/dfm/.rustup \
CARGO_TARGET_DIR=target/csr-native-twelve-build \
CETA_CSR_BIN=/work/dfm/festschrift/CeTA-CSR/ceta \
cargo +1.95.0 build --release --bin ferrum
```

`FERRUM_LOOP_TRACE=1` reports symbolic-search depth, starting-pair index,
elapsed time, and success/exhaustion. The final optimized serial library
suite passed all 1,067 tests (`library-release-v22.log`), with no failures
or ignored tests. Four focused Python suites passed 57 tests.
`consolidated-release-v22/` confirmed 1,231/1,231 selected Standard roots
(990 YES, 241 NO); `guards-release-v22/` confirmed all 421 protected roots.
Both used `parameter-v5.jsonl`, preserve their exact certified input sets,
and passed two additional CeTA checks per certificate. Implementation commit:
`e36fd204a9aa07a2129fe5a8bf5c1b7ae90e3e71`.

Exploration continues separately in `source-frontier-release-v22c/` and
`open-loops-release-v6/`. Five additional native Ex3_3_25_Bor03_FR DP states
were certified and imported into exploratory `parameter-v6.jsonl`. They
are not counted as new roots. The remaining chain gaps include reference
NO pair restrictions that cannot be replaced by the existing R-only
nontermination usable-rule restriction; selecting the relevant pair cycle
and reconstructing its native narrowing chain remain separate obligations.

CeTA-CSR is unchanged; all new certification uses
`/work/dfm/festschrift/CeTA-CSR/ceta`. No Isabelle rebuild was needed.

## 2026-10-10 Symbolic argument filters and the eight native Innermost gaps

The opt-in `FERRUM_DIRECT_FILTER_PATH_ORDER=1` route encodes filtered RPO
comparisons over original subterms, sharing Boolean comparison nodes rather
than expanding Cartesian products of filtered descendants. It applies to
DP reduction pairs and path-order size-change synthesis. Filter selectors,
usable-rule and Q obligations, independent model validation, and CPF output
remain unchanged. The construction follows RPO modulo argument filtering in
Codish et al., JAR 2012, Definition 16 and Section 4.3:
<https://imada.sdu.dk/u/petersk/papers/JAR12-rpo-sat.pdf>.

On retained source-proof inputs, Appendix B GM and iGM path-order probes
improved from 60-second timeouts to 1.29 and 1.03 seconds. For GM, the SMT
query shrank from 148,459,970 to 2,046,548 bytes. Six recursively reconstructed
Appendix residual proofs passed production CeTA-CSR twice. Native actions
and search bounds were exported as state-local guidance, with zero exact
witnesses or independent event-certification credit. Both original roots
then certified in the full replay, in 11.873 and 7.590 seconds respectively.

LengthOfFiniteLists_nokinds_C also certified after prioritizing the retained
native CSR-to-GM route over an unsuccessful improved-CSR-DP detour. Its
`length-v7` certificate passed two additional checker runs. This changes
guidance ordering, not the problem's minimality or replacement map.

Artifact base: `target/innermost-eight-20261010/`. `baseline-atoms` and
`direct-atoms-v1` contain 42 matched local diagnostics. `frontier-v1` retains
22 unsuccessful recursive probes; `direct-frontier-v2` contains six certified
closures among 15 probes. `parameter-v6.jsonl` integrates the Appendix
closures; `parameter-v7.jsonl` adds the native Length route. The initial
complete replay (`full-v6-complete.json`) has 304/311 certified: two gains
and one timing loss, MYNAT_nokinds_noand_iGM, compared with 303. Every retained
positive passed two independent checks. This is not a zero-loss replacement.

The MYNAT local order succeeds in 63.130 seconds under the new encoding,
exceeding its previous learned allowance. The attempted timeout wrapper in
`parameter-v8.jsonl` is correctly ignored by primitive-only oracle dispatch.
`parameter-v9.jsonl` instead records the actual observation in the optional
`replay_elapsed_ms` field. Lookup uses the larger of this allowance and the
historical best time, with existing 20% headroom; monotone merging preserves
the maximum explicit replay measurement and the minimum historical best.
Neither timing field promotes evidence credit. The focused `mynat-v9` root
replay certifies in 78.629 seconds and passes two additional checker runs.
The final `full-v9` replay certifies 306/311 (296 YES, ten NO), three gains
and zero losses against 303, in 373 seconds. All 306 retained certificates
pass two independent production checker reruns. The state-of-the-art ledger
records the exact profile, binary and remaining five roots. Implementation
commit: `9bfa55f56d32e5d72b9acc54e5dd28ab059f6eef`.

The replay harness now includes previous timeouts by default. The initial
310-root run and its disjoint one-root timeout supplement were merged with
exact root-set validation; no missing root is counted as success.

Verification: 1,030/1,030 release library tests with the flag enabled, plus
three new exhaustive bounded comparison/sharing/cancellation tests included
in that total. Twelve frontier, six harness, five hint-exporter and eleven
monotone-merge tests initially passed. The timing-metadata regression increases
the merge suite to twelve tests, all passing. A full-suite rerun exposed two
CeTA tests sharing a PID-only temporary filename; the helper now adds an
atomic per-process counter. The final 1,030-test run has no failures or ignored
tests. CSR guard: 110/110 (105 YES, five NO), 72 seconds.
Witness-assisted Innermost guard: 311/311 (301 YES, ten NO), 183 seconds.
All guard certificates passed two additional production CeTA-CSR checks.
CeTA did not change: main remains `73662ec88a74f65187cba6986d300836564b6a59`.
The immutable tested prover is `ferrum-direct-v2`, SHA256
`4d53bc32a617dc23245b7b212f53d22cd0a6b015a53dae0830b20d9b9ab54af7`.
The timing-metadata update is `ferrum-direct-v3`, SHA256
`0c875e0a5c634c43f4a517b33a61ad2448c85d419b2ebbce35181495d766d59b`.
Both guards use v2; v3 changes guidance timing only, with no additional
processor or checker changes.

The unresolved local diagnostics distinguish remaining work: LISTUTILITIES
still generates roughly 548--554 MB path-order queries and has expensive
graph construction; MYNAT_complete still times out in order synthesis;
OvCons and PEANO expose native-model residuals not closed by this wave;
PALINDROME still needs its first whole-TRS order search. Default encoding
selection remains unchanged while the opt-in route is evaluated.

## 2026-08-25 Complete 110-root current-TPDB CSR replay

TPDB-ARI commit `183f29db` adds `Gutierrez_26/secret2.ari` and `secret4.ari`
to the 108 context-sensitive systems used in the previous complete replay.
Ferrum commit `06fb30d` parses omitted ARI replacement-map entries as full,
while preserving explicit frozen entries and ignoring declarations absent
from the operational TRS signature. Two focused parser regressions exercise
the source files directly.

`secret2` is terminating because its frozen `f` argument prevents recursion;
two context-sensitive polynomial rule-removal steps produce a certified empty
residual. In `secret4`, `f` is active and Ferrum finds the certified contextual
loop `a -> if(S(a),f(a),a) -> if(true,f(a),a) -> f(a)`. Both focused defaults
were reproduced twice and accepted by the generated CeTA-CSR checker at
`CeTA-CSR-csr/target/csr-guarded-list-generic-export-v2-20260825/ceta-csr-guarded-list`.

The first oracle export exposed a genuine integration defect: CPF loop
extraction retained the untyped `nontermination(loop)` atom, which dispatches
to ordinary direct-loop search and cannot find a contextual loop. The
extractor now maps CSR loop nodes to `csr-loop`; its regression test covers
both a `problem_kind=csr` input and the context-sensitive category fallback.
The corrected monotone oracle is
`target/csr110-gutierrez-oracle-20260825/oracle-global-v1101-gutierrez-typed.jsonl`
(SHA-256 `9aaf9ba1255fb7e947579b77aafca22e6d087c9884d65143cf63707789543a5a`).

The exact-commit 64-worker replay used a 60-second `fail` strategy,
`--no-top-level-llm`, and `FERRUM_DP_LLM_NO_FALLBACK=1`. It returned 105
certified YES and five certified NO in 11 seconds, with no other result and no
checker failure. Artifacts are under
`target/termcomp-runs/csr110-strict-v1101-commit-06fb30d-20260825`; summary and
details are in `target/csr110-gutierrez-oracle-20260825`. Every CPF was then
accepted twice more by CeTA-CSR (110/110 on each pass). The applicability
audit reports 105/105 terminating roots and 445/445 successful nontrivial
path states with positive guidance and no missing or context-losing node.

Verification: release build; 775/775 Rust library tests; 79 extraction tests,
24 oracle-export tests, 33 credited-dataset tests, and seven monotone-merge
tests; `git diff --check`. CeTA-CSR required no new source change and remains
at `c03b830`.

## 2026-08-13 Relative Parity and Certification Alignment

After merging `main` into `codex/relative-performance-20260811`, Ferrum was
aligned with CeTA's executable definitions for ordinary relative match-bounds
and flat-context closure. All 94 historical SRS Relative CPFs were rechecked
before their exact processor paths were extracted. Raw structural state keys
are retained for this corpus because reversal is involutive and canonical
state pooling loses the path phase.

Final retained runs:

- TRS Relative, 140 problems: 45 certified YES, 13 certified NO, 82 MAYBE:
  `target/termcomp-runs/20260813-trs-relative-v864-oracle-only-full-8x60s`.
- SRS Relative, 461 problems: 95 certified YES, 366 MAYBE:
  `target/termcomp-runs/20260813-srs-relative-v865-oracle-only-full-8x60s`.
- Historical six-problem regression gate: 6 certified YES:
  `target/termcomp-runs/20260813-relative-v864-combined-six`.
- New Endrullis-26 certified replay:
  `target/termcomp-runs/20260813-srs-relative-v865-new-win-replay`.

There were no certification failures in any final retained run. The combined
oracle and its certification-gated evidence are under
`target/srs-relative-oracle-new-win-v865-20260813`.

## 2026-07-18 Certified RFC-Relative Bounds Smoke Test

Ferrum added an opt-in SRS processor
`rfc-relative-match-bounds(...)` that emits CPF3
`<rfcRelativeBounds>` certificates. The local CeTA RFC fork at
`/work/dfm/festschrift/CeTA-rfc` was extended with parser/checker support and
verified with Isabelle:

```console
AFP=/work/dfm/festschrift/ferrum/.tools/afp-current/thys \
ISABELLE_IDENTIFIER=ferrum_rfc_work \
/work/dfm/festschrift/ferrum/.tools/Isabelle2025-2/bin/isabelle build -j 64 \
  -d /work/dfm/festschrift/CeTA-rfc/thys Proof_Checker

AFP=/work/dfm/festschrift/ferrum/.tools/afp-current/thys \
ISABELLE_IDENTIFIER=ferrum_rfc_work \
/work/dfm/festschrift/ferrum/.tools/Isabelle2025-2/bin/isabelle build -j 64 \
  -d /work/dfm/festschrift/CeTA-rfc/thys Code
```

The checked Haskell code was exported, compiled with GHC, and installed as
`.tools/ceta-relative-bounds`.

Real TPDB smoke test:

```console
target/release/ferrum prove \
  /work/dfm/festschrift/TPDB-ARI/SRS_Standard/Zantema_04/z061.ari \
  --strategy 'rfc-relative-match-bounds(max-bound=3,max-words=10000,max-word-len=128,max-states=2000,max-transitions=50000)' \
  --cpf-mode cpf30 \
  --cpf target/rfc-relative-probe/z061.cpf3.xml

.tools/ceta-relative-bounds target/rfc-relative-probe/z061.cpf3.xml
```

Result: `CERTIFIED`.

Current certified scope: full rewriting, empty Q and weak components, and
deletion of exactly all current strict rules. Matchbox-style `RelRFCmb`
merge-at-bound/epsilon semantics and non-empty residual relative RFC deletion
remain future work.

## 2026-07-18 Automaton-Closed RFC Work

Ferrum now has a separate automaton-closed RFC proof step for SRS match-bounds.
The finite RFC checker remains unchanged and certified; the new path is emitted
as CPF3 `<rfcAutomatonClosedBounds>` so it cannot be confused with the older
finite-initial `<rfcBounds>` proof.

Ferrum validation:

```console
cargo +1.95.0 test --lib rfc_match_bounds -- --nocapture
cargo +1.95.0 check --lib --bins

target/release/ferrum prove \
  ../TPDB-ARI/SRS_Standard/Zantema_04/z031.ari \
  --strategy 'rfc-match-bounds(max-bound=3,max-words=10000,max-word-len=128,max-states=2000,max-transitions=50000,at-bound=merge)' \
  --cpf-mode cpf30 \
  --cpf target/rfc-automaton-z031.cpf3.xml
```

This emits `RfcAutomatonClosedBounds` and writes
`target/rfc-automaton-z031.cpf3.xml`.

CeTA-rfc validation:

```console
AFP=/work/dfm/festschrift/ferrum/.tools/afp-current/thys \
ISABELLE_IDENTIFIER=ferrum_rfc_work \
  /work/dfm/festschrift/ferrum/.tools/Isabelle2025-2/bin/isabelle build \
  -j 64 -d /work/dfm/festschrift/CeTA-rfc/thys Proof_Checker

AFP=/work/dfm/festschrift/ferrum/.tools/afp-current/thys \
ISABELLE_IDENTIFIER=ferrum_rfc_work \
  /work/dfm/festschrift/ferrum/.tools/Isabelle2025-2/bin/isabelle build \
  -j 64 -d /work/dfm/festschrift/CeTA-rfc/thys Code
```

The generated checker currently recognizes the new XML tag but still delegates
it to the conservative finite RFC checker. Therefore it rejects `z031` with
`RFC initial language is not closed under one-step right-forward narrowing`.
This is intentional until the Isabelle theorem for finite automaton closure
under SRS RFC splitting is added.

Follow-up on the same day: CeTA-rfc now also has the executable predicate that
the theorem will use. In
`/work/dfm/festschrift/CeTA-rfc/thys/Termination_and_Complexity/Matchbounds_Impl.thy`,
`rfc_automaton_closed_impl` checks unary/SRS rule shape and the Matchbox-style
split condition over the certificate automaton states. Validation:

```console
AFP=/work/dfm/festschrift/ferrum/.tools/afp-current/thys \
ISABELLE_IDENTIFIER=ferrum_rfc_work \
  /work/dfm/festschrift/ferrum/.tools/Isabelle2025-2/bin/isabelle build \
  -j 64 -d /work/dfm/festschrift/CeTA-rfc/thys Proof_Checker
```

Result: `Proof_Checker` finished successfully. Existing finite RFC
certification was also rechecked:

```console
/work/dfm/festschrift/ferrum/.tools/ceta-relative-bounds \
  /work/dfm/festschrift/ferrum/target/rfc-relative-probe/z061.cpf3.xml
```

Result: `CERTIFIED`.

2026-07-21 correction and smoke test:

- The candidate automaton-closed RFC theorem using only split closure was too
  strong. Prefix-overlap narrowing also needs a run for the strict remaining
  lhs suffix; otherwise the split condition can pass vacuously.
- `/work/dfm/festschrift/CeTA-rfc` now has an executable
  `rfc_lhs_suffix_total_impl` side condition in `Matchbounds_Impl.thy`; it also
  rejects empty lhs words for automaton-closed RFC.
- The split session `RFC_Checker_Ext` proves the word-level preservation
  theorem under split closure plus lhs suffix totality.
- A direct bridge from `rfc_narrows_impl` using only `mgu_vd_string_sound` was
  removed because it is too weak. The remaining automaton-closed certification
  step is a concrete `mgu_vd_string` shape lemma for unary word terms, or an
  equivalent certified word-level RFC closure theorem.

Finite RFC certification was rechecked end to end:

```console
target/debug/ferrum prove \
  /work/dfm/festschrift/TPDB-ARI/SRS_Standard/Zantema_04/z061.ari \
  --strategy 'rfc-match-bounds(max-bound=3,max-words=256,max-word-len=32,max-states=5000,max-transitions=50000)' \
  --cpf target/rfc-small-scan-20260721/Zantema_04__z061.manual.cpf3.xml \
  --cpf-mode cpf30

.tools/ceta-relative-bounds \
  target/rfc-small-scan-20260721/Zantema_04__z061.manual.cpf3.xml
```

Result: `CERTIFIED`.

Follow-up after correcting the executable automaton-closure checker to quantify
over all states mentioned by the certificate automaton, not just final states:

```console
AFP=/work/dfm/festschrift/ferrum/.tools/afp-current/thys \
ISABELLE_IDENTIFIER=ferrum_rfc_work \
/work/dfm/festschrift/ferrum/.tools/Isabelle2025-2/bin/isabelle build -j 64 \
  -d /work/dfm/festschrift/CeTA-rfc/thys Proof_Checker
```

Result:

```text
Finished IsaFoR_2 (0:04:51 elapsed time, 0:24:45 cpu time, factor 5.10)
Finished Proof_Checker (0:12:33 elapsed time, 0:26:21 cpu time, factor 2.10)
0:17:47 elapsed time, 0:51:07 cpu time, factor 2.87
```

Current proof-search signal after enabling Ferrum's
`RfcAutomatonClosedBounds` proof object:

```console
run=target/termcomp-runs/20260718-srs-unsolved-256-rfc-automaton-64w-20s
python scripts/termcomp_trs_compare.py \
  --tpdb ../TPDB-ARI \
  --ferrum target/release/ferrum \
  --ceta .tools/ceta-relative-bounds \
  --category SRS_Standard \
  --from-details target/termcomp-runs/srs-unsolved-fixed-256-from-20260715-151226.details.json \
  --include-status unknown \
  --jobs 64 \
  --timeout 20 \
  --run-dir "$run" \
  --output "$run/summary.md" \
  --progress-interval 16 \
  --extra-arg=--strategy \
  --extra-arg='rfc-match-bounds(max-bound=3,max-words=10000,max-word-len=128,max-states=2000,max-transitions=50000,at-bound=merge)'
```

Result on this fixed prior-unsolved slice: 15 raw YES, 0 certified YES,
100 MAYBE, 141 timeout, 15 certification failures. The certification failures
are expected because the bundled checker does not yet certify
`<rfcAutomatonClosedBounds>`.

The older run
`target/termcomp-runs/20260715-233647-srs-unsolved-256-rfc-match-bounds-64-10s`
contained 243 examples whose `ferrum_stdout` said `status: Terminating`, but
the run recorded them as errors because CPF export did not yet support RFC.
Rerunning the same fixed slice with the current implementation and the old RFC
parameters produced only 1 raw YES at 20s. A 64-example slice of old raw-YES
examples produced 0 YES at 60s. Therefore the old `243` number should be
treated as evidence that the earlier search was much more permissive, not as
current certifiable proof-search power.

For correctness, do not replace open-tail RFC templates by a single ground
end-marker instance unless the surrounding theorem proves the required
universal-tail property. SRS termination can be represented by a unary TRS over
ground strings with a fresh end marker, but RFC certificates for open-tail
templates must still prove acceptance/closure for all relevant continuations
or states.

## 2026-07-16 SMT-Lex Canonical CPF Training Dataset

The CPF-shaped training rows were rebuilt with the real SMT-backed
function-symbol lex minimizer in `scripts/audit_standardized_subproof_rows.py`.
The minimizer no longer enumerates candidate bijections. It creates integer
rank variables for the function symbols, constrains them to a bijection, orders
rules by function-name-erased rule shape, and incrementally fixes the
lexicographically minimal token stream with SMT satisfiability checks. The
resulting bijection is then applied to the problem XML, local context XML, and
proof-fragment XML.

The corpus canonicalizer now records the standardization method and applies a
per-unique-problem timeout so one unusually hard canonicalization problem cannot
block the whole database build.

Commands:

```console
python scripts/canonicalize_subproof_training_data.py \
  --input target/termcomp-proof-corpus/training/subproofs.cpf.jsonl.gz \
  --output target/termcomp-proof-corpus/training/subproofs.cpf.canonical.smt-lex.jsonl.gz \
  --summary target/termcomp-proof-corpus/training/subproofs.cpf.canonical.smt-lex.summary.json \
  --progress-interval 10000 \
  --max-symbols 0 \
  --standardization-timeout 5

python scripts/export_final_canonical_subproof_dataset.py \
  --input target/termcomp-proof-corpus/training/subproofs.cpf.canonical.smt-lex.jsonl.gz \
  --output target/termcomp-proof-corpus/training/subproofs.cpf.canonical.smt-lex.final.jsonl.gz \
  --summary target/termcomp-proof-corpus/training/subproofs.cpf.canonical.smt-lex.final.summary.json \
  --progress-interval 50000

python scripts/materialize_fragment_audit_dataset.py \
  --input target/termcomp-proof-corpus/training/subproofs.cpf.canonical.smt-lex.final.jsonl.gz \
  --output target/termcomp-proof-corpus/training/subproofs.cpf.canonical.smt-lex.fragment-audit.jsonl.gz \
  --summary target/termcomp-proof-corpus/training/subproofs.cpf.canonical.smt-lex.fragment-audit.summary.json \
  --progress-interval 50000

python scripts/audit_materialized_fragment_certificates.py \
  --jsonl target/termcomp-proof-corpus/training/subproofs.cpf.canonical.smt-lex.fragment-audit.jsonl.gz \
  --workers 64 \
  --timeout 30 \
  --out-dir target/termcomp-proof-corpus/fragment-audit/canonical-smt-lex-fragment-audit \
  --keep-certificates failures \
  --progress-interval 50000
```

Generated artefacts:

```text
target/termcomp-proof-corpus/training/subproofs.cpf.canonical.smt-lex.jsonl.gz
target/termcomp-proof-corpus/training/subproofs.cpf.canonical.smt-lex.summary.json
target/termcomp-proof-corpus/training/subproofs.cpf.canonical.smt-lex.final.jsonl.gz
target/termcomp-proof-corpus/training/subproofs.cpf.canonical.smt-lex.final.summary.json
target/termcomp-proof-corpus/training/subproofs.cpf.canonical.smt-lex.fragment-audit.jsonl.gz
target/termcomp-proof-corpus/training/subproofs.cpf.canonical.smt-lex.fragment-audit.summary.json
target/termcomp-proof-corpus/fragment-audit/canonical-smt-lex-fragment-audit/summary.json
target/termcomp-proof-corpus/fragment-audit/canonical-smt-lex-fragment-audit/results.jsonl.gz
```

Full canonicalization summary:

| Status | Rows |
| --- | ---: |
| `canonicalized` | 525,494 |
| `unchanged-unsupported` | 184,186 |
| `unchanged-no-problem-xml` | 93 |
| Total rows | 709,773 |

Method counts:

| Method | Rows |
| --- | ---: |
| `smt-lex` | 525,494 |
| `none` | 184,279 |

The final training-ready dataset contains the 525,494 canonicalized rows:

| Input form | Rows |
| --- | ---: |
| `ari-to-cpf-input` | 426,331 |
| `cpf-input-preserved` | 99,163 |

| Output form | Rows |
| --- | ---: |
| `aprove-step-to-cpf` | 339,712 |
| `cpf-output-preserved` | 99,163 |
| `aprove-obligation-step` | 72,080 |
| `aprove-removed-to-cpf` | 14,539 |

Fragment materialization and CeTA audit:

| Fragment audit status | Rows |
| --- | ---: |
| Materialized fragment certificates | 46,494 |
| Unsupported for fragment materialization | 479,000 |
| CeTA-certified materialized fragments | 10,518 |
| CeTA-failed materialized fragments | 35,976 |

The fragment audit used 64 workers, a 30 second per-fragment timeout, and
finished in 149.073 seconds wall time. The remaining failures are retained
under `target/termcomp-proof-corpus/fragment-audit/canonical-smt-lex-fragment-audit`
for inspection; many correspond to fragment assumptions that are still too weak
or too coarse for independent CeTA checking.

To isolate the standardization step from fragment-materialization failures, the
10,518 already-certifiable materialized fragments were standardized again and
checked with CeTA:

```console
python scripts/audit_standardized_materialized_fragments.py \
  --jsonl target/termcomp-proof-corpus/training/subproofs.cpf.canonical.smt-lex.fragment-audit.jsonl.gz \
  --certified-results target/termcomp-proof-corpus/fragment-audit/canonical-smt-lex-fragment-audit/results.jsonl.gz \
  --out-dir target/termcomp-proof-corpus/fragment-audit/canonical-smt-lex-standardized-fragment-audit \
  --ceta .tools/ceta-relative-bounds \
  --workers 64 \
  --timeout 30 \
  --progress-interval 1000 \
  --keep-certificates failures
```

Result:

| Status | Rows |
| --- | ---: |
| Standardized fragment certificates accepted by CeTA | 10,518 |
| Standardized fragment failures | 0 |

All 10,518 function-symbol mappings were identity mappings because the input
rows came from the already canonical SMT-lex final dataset. This is still a
useful idempotence signal: rerunning the standardizer and alpha-renaming pass
over every independently certifiable canonical fragment preserved CeTA
certifiability.

The nontrivial standardization signal uses the original, non-canonical
CPF-shaped rows:

```console
python scripts/materialize_fragment_audit_dataset.py \
  --input target/termcomp-proof-corpus/training/subproofs.cpf.jsonl.gz \
  --output target/termcomp-proof-corpus/training/subproofs.cpf.original.fragment-audit.jsonl.gz \
  --summary target/termcomp-proof-corpus/training/subproofs.cpf.original.fragment-audit.summary.json \
  --progress-interval 50000

python scripts/audit_materialized_fragment_certificates.py \
  --jsonl target/termcomp-proof-corpus/training/subproofs.cpf.original.fragment-audit.jsonl.gz \
  --workers 64 \
  --timeout 30 \
  --out-dir target/termcomp-proof-corpus/fragment-audit/original-fragment-audit \
  --keep-certificates failures \
  --progress-interval 50000

python scripts/audit_standardized_materialized_fragments.py \
  --jsonl target/termcomp-proof-corpus/training/subproofs.cpf.original.fragment-audit.jsonl.gz \
  --certified-results target/termcomp-proof-corpus/fragment-audit/original-fragment-audit/results.jsonl.gz \
  --out-dir target/termcomp-proof-corpus/fragment-audit/original-standardized-fragment-audit \
  --ceta .tools/ceta-relative-bounds \
  --workers 64 \
  --timeout 30 \
  --standardization-timeout 5 \
  --progress-interval 1000 \
  --keep-certificates failures
```

Results:

| Step | Count |
| --- | ---: |
| Original CPF-shaped rows processed | 709,773 |
| Original fragments materialized | 60,595 |
| Original materialized fragments CeTA-certified | 10,630 |
| Non-identity standardized fragments CeTA-certified | 10,609 |
| Standardization timeouts/failures | 21 |
| CeTA failures after successful standardization | 0 |

All 10,609 successful standardizations used non-identity function-symbol
mappings. The 21 failures were standardization timeouts at 5 seconds, mostly in
`dpTrans`, not CeTA rejections. This is the first clear nontrivial fragment-level
signal that renaming original proof fragments to canonical symbols preserves
CeTA certifiability.

The LLM-oriented proof-step dataset was then built from the canonical SMT-lex
rows and the audit trust labels:

```console
python scripts/build_llm_proofstep_dataset.py \
  --input target/termcomp-proof-corpus/training/subproofs.cpf.canonical.smt-lex.final.jsonl.gz \
  --output target/termcomp-proof-corpus/training/llm-proofsteps.smt-lex.jsonl.gz \
  --summary target/termcomp-proof-corpus/training/llm-proofsteps.smt-lex.summary.json \
  --canonical-fragment-results target/termcomp-proof-corpus/fragment-audit/canonical-smt-lex-fragment-audit/results.jsonl.gz \
  --original-standardized-results target/termcomp-proof-corpus/fragment-audit/original-standardized-fragment-audit/results.jsonl.gz \
  --progress-interval 50000
```

The full dataset has 525,494 rows. Each row contains the CPF subproblem, local
context, problem features, target processor, extracted parameter/witness
features, the proof-fragment XML label, and trust metadata. The high-trust split
was generated from the full dataset and contains 10,605 nontrivial
original-standardized CeTA-certified rows:

```text
target/termcomp-proof-corpus/training/llm-proofsteps.smt-lex.jsonl.gz
target/termcomp-proof-corpus/training/llm-proofsteps.smt-lex.summary.json
target/termcomp-proof-corpus/training/llm-proofsteps.smt-lex.certified.jsonl.gz
target/termcomp-proof-corpus/training/llm-proofsteps.smt-lex.nontrivial-certified.jsonl.gz
target/termcomp-proof-corpus/training/llm-proofsteps.smt-lex.splits.summary.json
```

All generated gzip files passed `gzip -t`.

The task-specific chat-style datasets were generated with:

```console
python scripts/build_llm_task_datasets.py \
  --input target/termcomp-proof-corpus/training/llm-proofsteps.smt-lex.jsonl.gz \
  --out-dir target/termcomp-proof-corpus/training \
  --prefix llm-task.smt-lex \
  --summary target/termcomp-proof-corpus/training/llm-task.smt-lex.summary.json \
  --processor-trust all \
  --parameters-trust nontrivial-certified \
  --witness-trust nontrivial-certified \
  --progress-interval 50000
```

Outputs:

```text
target/termcomp-proof-corpus/training/llm-task.smt-lex.processor.jsonl.gz
target/termcomp-proof-corpus/training/llm-task.smt-lex.parameters.jsonl.gz
target/termcomp-proof-corpus/training/llm-task.smt-lex.witness.jsonl.gz
target/termcomp-proof-corpus/training/llm-task.smt-lex.summary.json
```

Counts:

| Dataset | Rows |
| --- | ---: |
| Processor prediction | 525,494 |
| Parameter prediction | 10,605 |
| Witness suggestion | 10,605 |

The generated gzip files passed `gzip -t`.

Finally, minimal chat-template SFT JSONL files were generated:

```console
python scripts/build_sft_chat_datasets.py \
  --processor target/termcomp-proof-corpus/training/llm-task.smt-lex.processor.jsonl.gz \
  --parameters target/termcomp-proof-corpus/training/llm-task.smt-lex.parameters.jsonl.gz \
  --witness target/termcomp-proof-corpus/training/llm-task.smt-lex.witness.jsonl.gz \
  --out-dir target/termcomp-proof-corpus/training/sft \
  --summary target/termcomp-proof-corpus/training/sft/ferrum.sft.summary.json \
  --prefix ferrum \
  --validation-pct 1 \
  --test-pct 1 \
  --progress-interval 50000
```

Each row has the standard `{"messages": [...]}` shape expected by
`tokenizer.apply_chat_template`. Split counts:

| Dataset | Train | Validation | Test |
| --- | ---: | ---: | ---: |
| `ferrum.processor` | 514,852 | 5,270 | 5,372 |
| `ferrum.parameters` | 10,402 | 103 | 100 |
| `ferrum.witness` | 10,415 | 88 | 102 |

All SFT gzip files passed `gzip -t`.

The processor training split was then exported in HRM-Text's direct raw format:

```console
python scripts/build_hrm_direct_dataset.py \
  --input target/termcomp-proof-corpus/training/sft/ferrum.processor.sft.train.jsonl.gz \
  --output target/termcomp-proof-corpus/training/hrm-direct/ferrum.processor.direct.train.jsonl.gz \
  --summary target/termcomp-proof-corpus/training/hrm-direct/ferrum.processor.direct.train.summary.json \
  --condition direct \
  --progress-interval 50000
```

Generated artefacts:

```text
target/termcomp-proof-corpus/training/hrm-direct/ferrum.processor.direct.train.jsonl.gz
target/termcomp-proof-corpus/training/hrm-direct/ferrum.processor.direct.train.summary.json
```

Rows use `condition`, `instruction`, and `response` fields. The `instruction`
field is only the raw CPF input XML, e.g. `<input>...</input>`, with no system
prompt, task prompt, feature JSON, or wrapper. The `response` field is only the
bare processor name, e.g. `ruleRemoval`, not a JSON object. HRM-Text's local
condition-token mapping supports `direct`, `cot`, `noisy`, and `synth`, with
comma-composed conditions also supported by the evaluation engine. Ferrum uses
`direct` here because processor prediction is a direct instruction-to-response
task. The export wrote 514,852 rows, skipped 0 rows, had 0
non-`<input>...</input>` instructions, had 0 non-processor-name responses, and
passed `gzip -t`.

A strategy-labelled HRM direct dataset was then built from the canonical
proof-fragment dataset with full `output_xml` proof information, because the
processor-only SFT split does not retain the proof XML needed to recover bounds
such as polynomial coefficients, KBO weights, matrix dimensions, or
match-bounds:

```console
python scripts/build_hrm_strategy_direct_dataset.py \
  --input target/termcomp-proof-corpus/training/subproofs.cpf.canonical.smt-lex.final.jsonl.gz \
  --out-dir target/termcomp-proof-corpus/training/hrm-strategy-direct \
  --summary target/termcomp-proof-corpus/training/hrm-strategy-direct/ferrum.strategy.direct.summary.json \
  --prefix ferrum.strategy \
  --validation-pct 1 \
  --test-pct 1 \
  --progress-interval 50000
```

Generated artefacts:

```text
target/termcomp-proof-corpus/training/hrm-strategy-direct/ferrum.strategy.direct.train.jsonl.gz
target/termcomp-proof-corpus/training/hrm-strategy-direct/ferrum.strategy.direct.validation.jsonl.gz
target/termcomp-proof-corpus/training/hrm-strategy-direct/ferrum.strategy.direct.test.jsonl.gz
target/termcomp-proof-corpus/training/hrm-strategy-direct/ferrum.strategy.direct.summary.json
```

Rows still use only raw CPF XML as `instruction`. The `response` is a Ferrum
leaf processor label such as `poly(max-constant=2, max-coefficient=2,
symbols=3, arity=1)`, `kbo(weight=5, symbols=3)`, `matrix(...)`,
`path-order`, `path-order-af`, `graph`, `subterm`, or
`nontermination(loop)`. Structural aliases and sub-strategies such as `orders`,
`dp`, and `string-reversal(...)` are excluded. `path-order-af` is used when the
proof XML exposes an argument-filtered path-order witness; plain `path-order`
is used when no argument filter is present. The exporter is conservative and
skipped rows whose proof fragment could not be mapped to a valid leaf label
without inventing parameters. Numeric bounds are extracted only from leaf
`<integer>` nodes in actual witness processor XML roots. Structural wrappers
such as `<dpTrans>` are skipped, so nested proof text is not concatenated into
bogus parameters.

Counts:

| Split | Rows |
| --- | ---: |
| train | 118,167 |
| validation | 1,193 |
| test | 1,153 |
| total | 120,513 |

Label provenance:

| Source | Rows |
| --- | ---: |
| coarse processor atom | 55,219 |
| exact XML polynomial bounds | 29,497 |
| exact XML matrix bounds | 24,205 |
| exact XML subterm | 4,868 |
| exact XML top-level path order with AF | 3,331 |
| exact XML loop | 1,425 |
| exact XML KBO bounds | 1,358 |
| exact XML path order without AF | 287 |
| exact XML match bound | 281 |
| exact XML nonloop | 42 |

All generated gzip files passed `gzip -t`; a full validation scan found 0
malformed instructions, 0 JSON-object responses, and 0 labels with numeric
parameters larger than 10,000.

A domain-aware BPE tokenizer was then trained on the HRM strategy train split:

```console
python scripts/build_hrm_bpe_tokenizer.py \
  --input target/termcomp-proof-corpus/training/hrm-strategy-direct/ferrum.strategy.direct.train.jsonl.gz \
  --out-dir target/termcomp-proof-corpus/training/tokenizers/ferrum-strategy-bpe \
  --vocab-size 32000 \
  --min-frequency 2
```

Generated artefacts:

```text
target/termcomp-proof-corpus/training/tokenizers/ferrum-strategy-bpe/tokenizer.json
target/termcomp-proof-corpus/training/tokenizers/ferrum-strategy-bpe/tokenizer_config.json
target/termcomp-proof-corpus/training/tokenizers/ferrum-strategy-bpe/special_tokens_map.json
target/termcomp-proof-corpus/training/tokenizers/ferrum-strategy-bpe/atomic_tokens.txt
target/termcomp-proof-corpus/training/tokenizers/ferrum-strategy-bpe/summary.json
```

The tokenizer explicitly preserves observed XML tags, canonical symbols such as
`f0` and `x0`, Ferrum strategy atoms, strategy parameter names, and strategy
punctuation as atomic tokens. Complete parameterized response labels are not
atomic, so labels such as `poly(max-constant=2, max-coefficient=2, ...)` retain
shareable internal structure. The final usable vocabulary size is 549 tokens
(`len(tokenizer)`), while the base BPE vocabulary size reported by
`PreTrainedTokenizerFast.vocab_size` is 486. The atomic-token manifest contains
179 strings: 49 XML tags, 96 canonical `fN`/`xN` names, 122 strategy/word
tokens, and 10 punctuation tokens; these categories overlap. A full train-split
encoding scan found 0 `[UNK]` tokens.

## 2026-07-15 Canonical CPF Training Dataset and Certificate Audit

The CPF-shaped subproof corpus was canonicalized with unbounded `f0`, `f1`, ...
function-symbol names and `x0`, `x1`, ... variable names. The symbol renaming is
applied throughout proof fragments, including interpretations, KBO/path-order
entries, argument-filter entries, and ordinary term positions.

Commands:

```console
python scripts/canonicalize_subproof_training_data.py \
  --input target/termcomp-proof-corpus/training/subproofs.cpf.jsonl.gz \
  --output target/termcomp-proof-corpus/training/subproofs.cpf.canonical.v2.jsonl.gz \
  --summary target/termcomp-proof-corpus/training/subproofs.cpf.canonical.v2.summary.json \
  --progress-interval 25000

python scripts/export_final_canonical_subproof_dataset.py \
  --input target/termcomp-proof-corpus/training/subproofs.cpf.canonical.v2.jsonl.gz \
  --output target/termcomp-proof-corpus/training/subproofs.cpf.canonical.final.jsonl.gz \
  --summary target/termcomp-proof-corpus/training/subproofs.cpf.canonical.final.summary.json \
  --progress-interval 50000
```

Artefacts:

```text
target/termcomp-proof-corpus/training/subproofs.cpf.canonical.v2.jsonl.gz
target/termcomp-proof-corpus/training/subproofs.cpf.canonical.v2.summary.json
target/termcomp-proof-corpus/training/subproofs.cpf.canonical.final.jsonl.gz
target/termcomp-proof-corpus/training/subproofs.cpf.canonical.final.summary.json
```

The full v2 canonical file contains 709,773 rows:

| Status | Rows |
| --- | ---: |
| `canonicalized` | 529,627 |
| `unchanged-unsupported` | 180,053 |
| `unchanged-no-problem-xml` | 93 |

The final training-ready dataset contains exactly the 529,627 canonicalized
rows. Validation used `gzip -t` plus a complete JSONL parse of both gzip files.

Certificate-preservation audit:

```console
python scripts/audit_canonical_collision_certificates.py \
  --jsonl target/termcomp-proof-corpus/training/subproofs.cpf.canonical.v2.jsonl.gz \
  --rows 128 \
  --timeout 60 \
  --out-dir target/termcomp-proof-corpus/canonical-collision-audit-128
```

The audit searched for canonical collision classes among certified complete CPF
sources, transformed complete certificates with the same renaming, and checked
the transformed certificates with CeTA.

| Metric | Count |
| --- | ---: |
| Sampled transformed complete CPF certificates | 128 |
| CeTA-certified transformed certificates | 128 |
| Failures | 0 |
| Nontrivial certified complete CPF rows found | 7,814 |
| Rows in canonical collision groups | 7,557 |
| Collision groups | 1,188 |

The eligible nontrivial certified complete CPF rows under these audit predicates
are SRS rows: 6,537 `SRS_Standard` and 1,277 `SRS_Relative`. This reflects the
complete-source CPF subset available through this audit path; the final
canonical JSONL dataset itself also contains many TRS rows.

Measured transformed-CeTA time was 4.254 seconds total, 0.033 seconds mean,
0.011 seconds median, and 0.465 seconds max. The gzip index pass took 132.119
seconds. A full audit of the 7,557 collision-group rows is estimated at about
251 seconds of serial CeTA time plus indexing/transformation overhead; with a
reused manifest, the CeTA portion would be about 3.9 seconds on 64 workers or
2.0 seconds on 128 workers.

An additional non-collision audit over all nontrivial certified complete CPF
rows used:

```console
python scripts/audit_canonical_collision_certificates.py \
  --jsonl target/termcomp-proof-corpus/training/subproofs.cpf.canonical.v2.jsonl.gz \
  --rows 128 \
  --timeout 60 \
  --no-require-collision \
  --out-dir target/termcomp-proof-corpus/canonical-nontrivial-audit-128
```

It also certified 128/128 transformed complete CPF certificates.

## 2026-07-15 Patched CeTA Relative Bounds and SRS Benchmark

Ferrum now uses the locally maintained CeTA build with termination-side
relative match-bounds support by default:

```text
/work/dfm/festschrift/ferrum/.tools/ceta-relative-bounds
```

The patched CeTA source is maintained at:

```text
https://github.com/schneiderkamplab/CeTA
```

Local source/build helper:

```console
scripts/build_ceta_relative_bounds.sh
.tools/ceta-relative-bounds --version
```

The checker reports CeTA `3.9`; the local Isabelle/Haskell build includes the
Ferrum relative-bounds extension. The checked-in default SRS strategy uses
`relative-match-bounds(max-bound=5)` on the original SRS and under
`string-reversal(...)`.

Focused verification:

```console
cargo +1.95.0 test --lib relative_srs_match_bounds -- --nocapture
cargo +1.95.0 test --lib writes_cpf3_relative_match_bounds_certificate_shape -- --nocapture
```

Both focused tests passed. A release-binary smoke proof for
`SRS_Standard/ICFP_2010/264370.ari` emitted `<relativeBounds>` and certified
with `.tools/ceta-relative-bounds`.

Full SRS Standard benchmark:

```console
cargo +1.95.0 build --release
run=target/termcomp-runs/20260715-151226-srs-standard-relative-release-128-60s
python scripts/termcomp_trs_compare.py \
  --tpdb /work/dfm/festschrift/TPDB-ARI \
  --category SRS_Standard \
  --jobs 128 \
  --timeout 60 \
  --ceta .tools/ceta-relative-bounds \
  --run-dir "$run" \
  --details-output "$run/details.json" \
  --output "$run/summary.md" \
  --progress-interval 25
```

Result:

| Category | Timeout | YES | NO | Certified YES | Certified NO | MAYBE | Timeout results | Cert failed |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| SRS Standard | 60s | 194 | 11 | 194 | 11 | 1660 | 56 | 0 |

Relative-bounds proof usage in that run:

| CPF shape | Count |
| --- | ---: |
| `<relativeBounds>` | 11 |
| `<bounds>` | 51 |
| `<stringReversal>` | 42 |

All 11 generated `<relativeBounds>` CPF files were rechecked individually with
`.tools/ceta-relative-bounds` and certified. Compared with the earlier stale
release-binary SRS runs (`20260715-145401...` and `20260715-150328...`), the
current release run improved from 139 certified YES / 11 certified NO to 194
certified YES / 11 certified NO. The only old YES not reproduced in the 128
worker batch, `SRS_Standard/Waldmann_19/random-470.ari`, certified when rerun
alone, so it is recorded as a load/batch scheduling artefact rather than a
deterministic regression.

Follow-up SRS proof-search experiment:

```text
target/termcomp-runs/20260715-210200-srs-standard-rhs-alphabet-128-60s
```

This run restored the default SRS strategy after rejecting unproductive
partial-relative and larger-order portfolio changes. The only retained code
change was SRS bounds alphabet completion for symbols occurring only in SRS
words. Result:

| Category | Timeout | YES | NO | Certified YES | Certified NO | MAYBE | Timeout results | Cert failed |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| SRS Standard | 60s | 192 | 11 | 192 | 11 | 1569 | 149 | 0 |

Compared with `20260715-151226...`, this run gained
`SRS_Standard/Waldmann_19/random-470.ari` and
`SRS_Standard/Zantema_04/z117.ari`, but missed four previous YES examples
under heavier timeout/load conditions:

```text
SRS_Standard/ICFP_2010/3268.ari
SRS_Standard/Secret_06_SRS/6.ari
SRS_Standard/Trafo_06/hom01.ari
SRS_Standard/Waldmann_19/random-330.ari
```

There were no certification failures and no NO regressions. This is not a
headline score improvement over 194/11; it is primarily a correctness audit of
the attempted SRS search changes.

Stateful partial relative match-bounds follow-up:

- Added opt-in strategy atom
  `relative-match-bounds-removal(max-bound=N,max-states=N,max-transitions=N)`.
- The processor carries the strict SRS and accumulated weak rules through
  recursive nested `<relativeBounds>` proof search.
- The previous invalid nested example is now certified:

```text
(format TRS)
(fun a 1)
(fun b 1)
(fun c 1)
(rule (a x) (b x))
(rule (b x) (c x))
```

Smoke command:

```console
target/release/ferrum prove target/srs-partial-relative-smoke/small/input.ari \
  --strategy 'relative-match-bounds-removal(max-bound=1)' \
  --cpf target/srs-partial-relative-smoke/small/proof.cpf3.xml \
  --cpf-mode cpf30
.tools/ceta-relative-bounds target/srs-partial-relative-smoke/small/proof.cpf3.xml
```

CeTA output:

```text
CERTIFIED
```

Probe on previous SRS unknown/timeouts:

```text
target/termcomp-runs/20260715-213657-srs-prior-unsolved-partial-relative-state-128-20s
```

The probe was stopped after the first wave because it produced no early
certified wins and mostly timed out. The processor is therefore kept out of the
default strategy until the search is made more selective.

Follow-up batching/cancellation probe:

```text
target/termcomp-runs/20260715-214558-srs-unsolved-256-batched-relative-64-10s
```

This fixed subset was built from the first 256 `unknown`/`timeout` entries in
`target/termcomp-runs/20260715-151226-srs-standard-relative-release-128-60s/details.json`,
sorted by path, and run with:

```console
python scripts/termcomp_trs_compare.py \
  --tpdb /work/dfm/festschrift/TPDB-ARI \
  --category SRS_Standard \
  --from-details target/termcomp-runs/srs-unsolved-fixed-256-from-20260715-151226.details.json \
  --include-status unknown \
  --include-status timeout \
  --jobs 64 \
  --timeout 10 \
  --ceta .tools/ceta-relative-bounds \
  --run-dir target/termcomp-runs/20260715-214558-srs-unsolved-256-batched-relative-64-10s \
  --details-output target/termcomp-runs/20260715-214558-srs-unsolved-256-batched-relative-64-10s/details.json \
  --output target/termcomp-runs/20260715-214558-srs-unsolved-256-batched-relative-64-10s/summary.md \
  --progress-interval 25 \
  --extra-arg=--strategy \
  --extra-arg='relative-match-bounds-removal(max-bound=5,max-states=2000,max-transitions=20000)'
```

Result: `0 YES / 0 NO / 3 MAYBE / 253 TIMEOUT`, with no certification
failures. Batching and cancellation make the processor structurally safer, but
not yet productive enough for the default strategy.

RFC match-bounds opt-in probe:

```text
target/termcomp-runs/20260715-233647-srs-unsolved-256-rfc-match-bounds-64-10s
```

Command:

```console
python scripts/termcomp_trs_compare.py \
  --tpdb /work/dfm/festschrift/TPDB-ARI \
  --category SRS_Standard \
  --from-details target/termcomp-runs/srs-unsolved-fixed-256-from-20260715-151226.details.json \
  --include-status unknown \
  --include-status timeout \
  --jobs 64 \
  --timeout 10 \
  --ceta .tools/ceta-relative-bounds \
  --run-dir target/termcomp-runs/20260715-233647-srs-unsolved-256-rfc-match-bounds-64-10s \
  --details-output target/termcomp-runs/20260715-233647-srs-unsolved-256-rfc-match-bounds-64-10s/details.json \
  --output target/termcomp-runs/20260715-233647-srs-unsolved-256-rfc-match-bounds-64-10s/summary.md \
  --progress-interval 25 \
  --extra-arg=--strategy \
  --extra-arg='rfc-match-bounds(max-bound=5,max-words=10000,max-word-len=64,max-states=2000,max-transitions=20000)'
```

The comparison script reports `0 YES / 0 NO / 13 MAYBE / 243 ERROR` because
Ferrum proves 243 examples with the new `RfcBounds` proof step, then correctly
fails CPF export since CeTA does not yet support RFC bounds certificates. Raw
Ferrum stdout count from `details.json`: `243` terminating, `13` unknown.

Example raw proof command:

```console
target/release/ferrum prove /work/dfm/festschrift/TPDB-ARI/SRS_Standard/Bouchare_06/03.ari \
  --strategy 'rfc-match-bounds(max-bound=5,max-words=10000,max-word-len=64,max-states=2000,max-transitions=20000)'
```

This emits `status: Terminating` with an `RfcBounds` step. This processor must
remain out of the default strategy until CPF/CeTA support for RFC initial
languages is implemented and checked.

2026-07-16 update: after rebuilding `.tools/ceta-relative-bounds`, the same
example now exports CPF3 successfully, but the maintained CeTA checker still
rejects it because the finite initial language is represented by open unary SRS
terms over the common tail variable:

```console
target/release/ferrum prove /work/dfm/festschrift/TPDB-ARI/SRS_Standard/Bouchare_06/03.ari \
  --strategy 'rfc-match-bounds(max-bound=5,max-words=10000,max-word-len=64,max-states=2000,max-transitions=20000)' \
  --cpf target/rfc-cert-smoke/Bouchare_06_03.cpf3.xml \
  --cpf-mode cpf30
.tools/ceta-relative-bounds target/rfc-cert-smoke/Bouchare_06_03.cpf3.xml
```

CeTA rejection:

```console
RFC bounds finite initial language is currently certified only for ground terms
```

The maintained CeTA tree was verified after adding executable open-tail
acceptance predicates and auxiliary lemmas:

```console
AFP=/work/dfm/festschrift/ferrum/.tools/afp-current/thys \
ISABELLE_IDENTIFIER=ferrum_rfc_check \
/work/dfm/festschrift/ferrum/.tools/Isabelle2025-2/bin/isabelle build -j 32 \
  -d /work/dfm/festschrift/CeTA/thys Proof_Checker
```

Result:

```console
Finished Proof_Checker (0:04:45 elapsed time, 0:15:23 cpu time, factor 3.23)
```

No additional RFC YESs are certified yet. The next certification step is the
direct finite-initial/open-tail RFC match-bounds theorem described in
`docs/ceta-rfc-relative-bounds-plan.md`.

## 2026-07-15 Docker-Free TermCOMP Image Tooling

Straight Docker is unavailable in the current Linux environment, so daemonless
container/image tooling was installed into the active `ferrum` conda
environment:

```console
mamba install -y -n ferrum -c conda-forge apptainer skopeo crane oras
```

Installed binaries:

```text
/home/ucloud/miniforge3/envs/ferrum/bin/apptainer
/home/ucloud/miniforge3/envs/ferrum/bin/skopeo
/home/ucloud/miniforge3/envs/ferrum/bin/crane
/home/ucloud/miniforge3/envs/ferrum/bin/oras
```

The conda-forge `skopeo` package installed a legacy v1
`etc/containers/registries.conf`; it was replaced by the v2-compatible minimal
configuration:

```toml
unqualified-search-registries = ["docker.io", "quay.io", "registry.fedoraproject.org"]
```

`apptainer` can convert OCI layers to SIF, but this host currently refuses new
user namespaces:

```text
Failed to create user namespace: maximum number of user namespaces exceeded
```

As a Docker-free fallback, Ubuntu Noble's `proot` and its `libtalloc2`
dependency were unpacked under:

```text
/work/dfm/festschrift/.tools/proot/
```

Two local helpers were added and symlinked into `~/.local/bin`:

```text
tc-image-extract
tc-image-run
```

They use `crane export` to extract Docker/OCI images under
`.containers/rootfs/` and then run commands inside the extracted rootfs with
`proot`.

Smoke tests:

```console
skopeo inspect docker://akihisayamada/natt:termcomp2025.1
tc-image-run akihisayamada/natt:termcomp2025.1 solver --name
tc-image-run akihisayamada/natt:termcomp2025.1 solver --timeout=5 --category=TRS_Standard /work/dfm/festschrift/TPDB-ARI/TRS_Standard/Mixed_TRS/3.ari
```

Observed solver name:

```text
NaTT
```

Observed result for `Mixed_TRS/3.ari`:

```text
YES
```

Additional tools/dependencies installed on 2026-07-15:

```console
mamba install -y -n ferrum -c conda-forge sqlite libxslt openjdk=24
```

Additional TermCOMP images extracted:

```text
jckassing/aprove_solver:aprove_termcomp25_v7
jwaldmann/termcomp2025-mbox:27-08-2025.f
dieterhofbauer/multumnonmulta:3.24.3
```

Smoke tests:

```console
tc-image-run jckassing/aprove_solver:aprove_termcomp25_v7 solver --name
tc-image-run jwaldmann/termcomp2025-mbox:27-08-2025.f solver --name
java --enable-preview -jar /work/dfm/festschrift/.containers/rootfs/dieterhofbauer_multumnonmulta_3.24.3/bin/MnM-3.24.2.jar --name
```

Observed names:

```text
AProVE25
matchbox-tc25.0
MnM-3.24
```

AProVE certified-proof generation was tested on
`TRS_Standard/Der95/30.ari`, a benchmark for which the proof database did not
previously contain an AProVE certified proof for that ARI key. The TermCOMP
wrapper's `--cert` mode invokes `-C ceta`, which was not usable in this local
proot/extracted-rootfs setup. CPF generation itself worked with:

```console
java -ea -jar /work/dfm/festschrift/.containers/rootfs/jckassing_aprove_solver_aprove_termcomp25_v7/opt/bundle/aprove.jar -m wst -p cpf /work/dfm/festschrift/TPDB-ARI/TRS_Standard/Der95/30.ari
```

The emitted CPF2 certificate was converted to CPF3 using AProVE's bundled
converter and certified with local CeTA:

```console
/work/dfm/festschrift/.containers/rootfs/jckassing_aprove_solver_aprove_termcomp25_v7/opt/cpfconverter/cpf2_to_3.sh target/aprove-cert-attempts/Der95_30.aprove25.cpf2.xml > target/aprove-cert-attempts/Der95_30.aprove25.cpf3.xml
/work/dfm/festschrift/ferrum/.tools/ceta-relative-bounds target/aprove-cert-attempts/Der95_30.aprove25.cpf3.xml
```

CeTA output:

```text
CERTIFIED
```

The resulting CPF3 artefact was inserted into
`target/termcomp-proof-corpus/proofs.sqlite` with proof URL:

```text
local://generated/aprove25-cert/TRS_Standard/Der95/30.ari/cpf3
```

The first larger AProVE gap run used 128 workers with a 65 second per-example
timeout:

```console
python scripts/run_aprove_cert_gap.py --workers 128 --timeout 65
```

Run directory:

```text
target/aprove-cert-runs/20260715-090022/
```

Candidate selection:

- `TRS_Standard` benchmarks with historical uncertified AProVE `YES`;
- no existing certified AProVE `YES` record for the local ARI benchmark key;
- mapped to existing local files under `/work/dfm/festschrift/TPDB-ARI`;
- deduplicated by local ARI path.

Run summary:

| Metric | Count |
| --- | ---: |
| Runnable candidates | 85 |
| Certified CPF3 artefacts | 3 |
| Inserted/updated DB rows | 3 |
| CPF2-to-CPF3 conversion failures | 79 |
| Timeouts | 3 |

Inserted rows:

| Benchmark | Result |
| --- | --- |
| `TRS_Standard/Der95/30.ari` | `CERTIFIED YES` |
| `TRS_Standard/AProVE_07/wiehe07.ari` | `CERTIFIED YES` |
| `TRS_Standard/Secret_07_TRS/7.ari` | `CERTIFIED NO` |

The conversion failures are not AProVE proof-search failures: AProVE emitted
CPF2 with `YES` for those examples, but the bundled CPF2-to-CPF3 converter
rejected unsupported proof tags such as `flip_trs` and `flip_dps`. Local CeTA
does not accept the raw CPF2 files directly.

## 2026-07-14 TermCOMP Proof Corpus Import

The proof-corpus database is stored under:

```text
target/termcomp-proof-corpus/
```

The current import recovered proof artefacts from:

- TermCOMP result pages backed by directly downloadable artefacts;
- TermCOMP Zenodo raw-data archives for 2014-2024;
- the pre-2014 Zenodo raw archive `14410457`;
- original 2019 cache pages for `TRS_Standard`, because the new-presentation
  page had malformed `pairs//stdout` proof URLs.

Commands:

```console
python scripts/collect_termcomp_proofs.py --jobs 64 --resume --out target/termcomp-proof-corpus
python scripts/collect_termcomp_proofs.py --years 2018 2019 2020 2021 --index-only --jobs 64 --out target/termcomp-proof-corpus
python scripts/import_termcomp_zenodo_archives.py --year-start 2014 --year-end 2024 --jobs 1 --out target/termcomp-proof-corpus
python scripts/import_termcomp_pre2014_archives.py --out target/termcomp-proof-corpus
python scripts/import_termcomp_cache_page.py --year 2019 --category TRS_Standard --url https://termcomp.github.io/Y2019/caches/termination_33457.html --out target/termcomp-proof-corpus
python scripts/import_termcomp_cache_page.py --year 2019 --category TRS_Standard --certified --url https://termcomp.github.io/Y2019/caches/termination_33116.html --out target/termcomp-proof-corpus
```

Final snapshot:

| Metric | Count |
| --- | ---: |
| Total proof-link records | 354,030 |
| Local artefacts available | 342,101 |
| Remaining indexed-only records | 11,929 |
| CPF/XML artefacts | 11,868 |
| Text artefacts | 329,350 |
| Pre-2014 compressed `.bz2` artefacts kept compressed | 883 |

The remaining indexed-only records are only:

- 2019 `TRS_Standard`: 7,241 rows. Valid pair IDs were recovered from original
  cache pages, but the Zenodo record lacks the corresponding standard output
  archive and StarExec is unavailable.
- 2020 `TRS_Standard` uncertified: 4,688 rows. The Zenodo record contains
  certified standard TRS output but no uncertified `trs_output.zip`; StarExec is
  unavailable.

The 2019 `TRS_Standard` gap was probed against the Internet Archive Wayback CDX
API:

```console
python scripts/recover_termcomp_wayback.py \
  --out target/termcomp-proof-corpus \
  --year 2019 \
  --category TRS_Standard \
  --jobs 8 \
  --retries 0 \
  --progress-interval 250 \
  --import-found \
  --variant-mode exact
```

Observed result:

```text
probed: 7241
found: 0
imported: 0
```

A 100-row all-variant sample over `https`, `http`, `www.starexec.org`, and
`starexec.org` also found no captures. Coarse wildcard CDX probes for StarExec
pair stdout URLs returned no captures for the tested patterns, with occasional
CDX throttling/connection refusal. No 2019 proof bodies were recovered from
Wayback in this pass.

Normalized proof views were generated without modifying the original artefacts:

```console
python scripts/normalize_proof_outputs.py \
  --out target/termcomp-proof-corpus \
  --mode all \
  --max-text-bytes 8000000 \
  --progress-interval 1000
```

Observed normalized counts:

| Normalizer | Count |
| --- | ---: |
| `xml-in-text` | 59,706 |
| `aprove-text` | 23,445 |

`xml-in-text` strips timing prefixes and extracts embedded CPF/XML from old
certified text artefacts. `aprove-text` writes Ferrum XML summaries from
recognizable AProVE textual output. The first AProVE pass is useful for
processor sequences and some removal blocks, but coefficient-level polynomial
extraction still needs a stronger AProVE grammar; the strict `POL(...) = ...`
parser did not capture the modern AProVE polynomial blocks in this run.

Pre-2014 import result:

```text
imported_tool: 72121
imported_certified: 17844
missing_tool: 0
missing_certified: 0
```

For expansion-heavy pre-2014 `.bz2` members, Ferrum stores the original
compressed payload and records `detected_format = compressed-bz2`. This avoids
spending minutes expanding padding-heavy historical stdout while preserving the
recoverable artefact.

## 1. Starting Point

Workspace:

```text
/Users/petersk/Nobackup/festschrift
```

The workspace initially contained downloaded RTA/LOOP open-problem pages in `loop/`, but no Rust project.

Ferrum was created as a new Rust binary crate:

```sh
cd /Users/petersk/Nobackup/festschrift
cargo new ferrum --bin
cd ferrum
```

## 2. Toolchain

The current local toolchain used for development and verification:

```text
rustc 1.95.0 (59807616e 2026-04-14)
cargo 1.95.0 (f2d3ce0bd 2026-03-21)
GHC 9.12.2
CeTA 3.9
macOS Darwin arm64
```

Commands used to inspect the environment:

```sh
rustc --version
cargo --version
ghc --version
uname -a
./.tools/ceta-relative-bounds --version
```

## 3. Rust Dependencies

Ferrum currently uses:

```toml
anyhow = "1.0.100"
clap = { version = "4.5.49", features = ["derive"] }
reqwest = { version = "0.12.24", features = ["blocking", "json"] }
serde = { version = "1.0.228", features = ["derive"] }
serde_json = "1.0.145"
thiserror = "2.0.17"
walkdir = "2.5.0"
```

The generated `Cargo.lock` pins the exact resolved versions.

## 4. Project Structure

Current top-level source layout:

```text
src/cert/       CPF writing and certification helpers
src/cli/        CLI commands
src/core/       Terms, variables, symbols, substitutions, TRSs, validation
src/llm/        LLM proof-state export and proposal parsing
src/parsing/    Legacy TPDB `.trs` and first-order ARI `(format TRS)` parsers
src/proving/    Proof engine, proof steps, dependency pairs, interpretation checkers
src/tpdb/       TPDB benchmark discovery
examples/       Small replayable TRS/ARI/proposal examples
docs/           Reproducibility and project notes
```

Additional TermCOMP 2025 analysis notes:

- `docs/termcomp-2025-trs-comparison.md`
- `docs/termcomp-2025-innermost-proof-gap.md`
- `docs/termcomp-2025-standard-proof-gap.md`
- `docs/termcomp-2025-standard-no-proof-gap.md`

## 5. TPDB-ARI Download

The current TPDB-ARI benchmark set was cloned from TermCOMP:

```sh
cargo run -- tpdb clone-ari ../TPDB-ARI
```

This runs:

```sh
git clone --depth 1 https://github.com/TermCOMP/TPDB-ARI.git ../TPDB-ARI
```

Discovery result:

```sh
cargo run -- tpdb discover ../TPDB-ARI
```

Observed output:

```text
benchmarks: 13917
ari: 13917
trs: 0
xml: 0
```

TRS parse/validation scan:

```sh
cargo run -- tpdb check-parse ../TPDB-ARI
```

Observed output:

```text
parsed: 10698
invalid: 391
failed: 0
skipped-non-trs: 2828
```

Interpretation:

- `parsed`: first-order `(format TRS)` ARI files that parse and pass Ferrum's ordinary-TRS validation.
- `invalid`: syntactically parsed TRS files that violate Ferrum's current ordinary-TRS validation, mainly extra variables on right-hand sides in transformed benchmark families.
- `failed`: parser failures among attempted TRS files.
- `skipped-non-trs`: ARI files such as `(format LCTRS)` that are outside the current TRS-only scope.

## 6. Parsing Support

Implemented parsers:

- legacy textual TPDB `.trs` format with sections such as `(VAR ...)` and `(RULES ...)`;
- first-order ARI files with `(format TRS)`, `(fun ...)`, and `(rule ...)`.

Real TPDB-ARI format issue encountered and fixed:

- Real ARI files use leading metadata comments and symbols such as `|0|`.
- Real ARI variables are inferred from declarations: names declared via `(fun ...)` are function symbols; undeclared atoms in terms are variables.
- Non-TRS formats such as `(format LCTRS)` are explicitly unsupported in the TRS parser.

Example parse:

```sh
cargo run -- parse ../TPDB-ARI/TRS_Innermost/AG01_innermost/#4.20.ari
```

Observed output:

```text
name: ../TPDB-ARI/TRS_Innermost/AG01_innermost/#4.20.ari
variables: 1
rules: 2
symbols: 3
validation-issues: 0
```

## 7. TRS Validation

Ferrum currently validates:

- non-empty rule sets;
- no variable left-hand sides;
- no extra right-hand-side variables;
- no arity conflicts.

Validation is exposed through:

```sh
cargo run -- parse examples/linear.trs
cargo run -- llm state examples/linear.trs
cargo run -- tpdb check-parse ../TPDB-ARI
```

## 8. LLM-First Proof Interface

The design principle is:

1. Ferrum exports structured proof state.
2. An LLM proposes candidate proof artifacts or strategy choices as JSON.
3. Ferrum checks every candidate before accepting it.
4. Only checked proof steps become proof objects or certificates.

Proof-state export:

```sh
cargo run -- llm state examples/linear.trs
```

Prompt export:

```sh
cargo run -- llm prompt examples/linear.trs
```

Live LLM calls are opt-in. `--llm-model-dir` names a normal local model directory containing weights and model metadata such as `config.json`, `tokenizer_config.json`, tokenizer files, and shard files. Ferrum does not read, create, or require any Ferrum-specific config file inside that model directory.

Ferrum supports two local model backends:

- `--llm-backend mlx` starts the repo helper `scripts/mlx_openai_server.py` with `python` from the active environment. This is the preferred Apple Silicon backend.
- `--llm-backend vllm` starts `vllm serve` from the active environment. This is the Linux/CUDA backend.

In both cases, Ferrum chooses a free localhost port, waits for `/v1/models`, and calls the OpenAI-compatible `/v1/chat/completions` API. Ferrum sends the model directory path as the OpenAI-compatible `model` field.

The Python environment used for local model serving is:

```sh
conda env create -f environment.yml
```

During the Apple Silicon test, `mlx-lm 0.31.3` required pinning `transformers==5.12.1`; `transformers 5.13.0` failed during tokenizer registration. The checked environment was created directly as:

```sh
conda create -y -n ferrum python=3.12 pip
conda activate ferrum
python -m pip install mlx-lm fastapi uvicorn pydantic transformers==5.12.1
```

Example top-level proof search with live LLM proposals:

```sh
cargo run -- prove examples/linear.trs \
  --llm-model-dir /path/to/model-weights \
  --llm-backend mlx \
  --llm-iterations 2
```

Example DP search with automatic LLM proposals for each dependency-pair component:

```sh
cargo run -- prove examples/dp-simple.trs \
  --strategy 'dp' \
  --llm-model-dir /path/to/model-weights \
  --llm-backend mlx \
  --llm-iterations 2
```

On the local 96 GB M2 Max machine, the working MLX model directory is:

```text
/Users/petersk/Nobackup/festschrift/models/Qwen3.6-27B-MLX-8bit
```

The command below was tested end to end; Ferrum launched the MLX server through conda, obtained an LLM candidate, checked it locally, and proved `examples/linear.trs`:

```sh
cargo run -- prove examples/linear.trs \
  --llm-model-dir /Users/petersk/Nobackup/festschrift/models/Qwen3.6-27B-MLX-8bit \
  --llm-backend mlx \
  --llm-iterations 1
```

The local vLLM-Metal experiment loaded both `mlx-community/Qwen3.6-35B-A3B-8bit` and `unsloth/Qwen3.6-27B-MLX-8bit`, but generated garbled completions through `vllm serve`. Direct MLX generation from the same 27B checkpoint produced sane output after disabling Qwen thinking mode through the chat template, so Ferrum should use `--llm-backend mlx` on this Mac.

Ferrum treats the LLM as an untrusted candidate generator. It iterates by sending checker feedback after failed attempts, then falls back to bounded local synthesis and optional SMT exactly as before. Accepted LLM candidates are recorded as checked symbol-weight or linear-polynomial interpretations; supported proof shapes remain CPF/CeTA-certifiable.

Supported proposal kinds at this point:

### `symbol_weights`

Example:

```json
{
  "candidates": [
    {
      "kind": "symbol_weights",
      "weights": {
        "f": 1
      }
    }
  ]
}
```

Ferrum checks the interpretation:

```text
I(f(t1,...,tn)) = weight(f) + I(t1) + ... + I(tn)
```

### `linear_polynomial`

Example:

```json
{
  "candidates": [
    {
      "kind": "linear_polynomial",
      "interpretations": {
        "f": {
          "constant": 1,
          "coefficients": [1]
        },
        "g": {
          "constant": 0,
          "coefficients": [1]
        }
      }
    }
  ]
}
```

Ferrum checks:

```text
I(f(t1,...,tn)) = c_f + a_1 I(t1) + ... + a_n I(tn)
```

with non-negative constants/co-efficients and strict decrease for every rule.

## 9. Example Proofs

### Symbol Weights

Input:

```text
examples/subterm.trs
examples/subterm-proposal.json
```

Command:

```sh
cargo run -- prove examples/subterm.trs \
  --llm-proposals examples/subterm-proposal.json \
  --cpf /tmp/ferrum-cert-check.xml
```

Observed output:

```text
status: Terminating
step: LlmSymbolWeights { weights: [("f", 1)] }
cpf: /tmp/ferrum-cert-check.xml
```

### Linear Polynomial

Input:

```text
examples/linear.trs
examples/linear-proposal.json
```

Command:

```sh
cargo run -- prove examples/linear.trs \
  --llm-proposals examples/linear-proposal.json
```

Observed output:

```text
status: Terminating
step: LlmLinearPolynomial { interpretations: [("f", 1, [1]), ("g", 0, [1])] }
```

Current limitation:

- This proof is checked internally by Ferrum.
- CPF 3 export is supported for accepted top-level `LlmLinearPolynomial` and `LlmSymbolWeights` proofs.

## 10. CeTA Installation

Official source:

- IsaFoR/CeTA site: <https://isafor-ceta.uibk.ac.at/>
- CeTA 3 / CPF 3 page: <https://isafor-ceta.uibk.ac.at/cpf3.html>

This machine is Apple Silicon:

```sh
uname -m
```

Observed:

```text
arm64
```

CeTA 3.9 macOS ARM binary was downloaded from the official IsaFoR/CeTA site:

```sh
mkdir -p .tools
curl -L --fail --max-time 120 \
  https://isafor-ceta.uibk.ac.at/bin/macos_arm/ceta \
  -o .tools/ceta-relative-bounds
chmod +x .tools/ceta-relative-bounds
```

The first download timed out after receiving a partial file. It was resumed with:

```sh
curl -L -C - --fail --max-time 180 \
  https://isafor-ceta.uibk.ac.at/bin/macos_arm/ceta \
  -o .tools/ceta-relative-bounds
chmod +x .tools/ceta-relative-bounds
```

Verification:

```sh
./.tools/ceta-relative-bounds --version
```

Observed output:

```text
3.9
```

`.tools/` is ignored by git because it contains large downloaded binaries and generated helper tools.

## 11. CPF 2 to CPF 3 Converter Installation

CeTA 3.9 expects CPF 3.x input. Ferrum currently emits CPF 2.1-style certificates for the supported subset, so the official CPF 2-to-3 converter was installed.

Download:

```sh
mkdir -p .tools/cpf3
curl -L --fail --max-time 120 \
  https://isafor-ceta.uibk.ac.at/cpf3.tgz \
  -o /tmp/cpf3.tgz
tar -xzf /tmp/cpf3.tgz -C .tools/cpf3 --strip-components=0
```

Build:

```sh
cd .tools/cpf3/cpf3/xml
make
cd -
```

Observed build output included:

```text
ghc -O2 --make Main.hs -o cpf2_to_3_phase_1
Linking cpf2_to_3_phase_1
```

Installed files used by Ferrum:

```text
.tools/ceta-relative-bounds
.tools/cpf3/cpf3/xml/cpf2_to_3.sh
.tools/cpf3/cpf3/xml/cpf3.xsd
```

## 12. CPF and CeTA Workflow

Ferrum currently exports CPF for:

- `EmptySystem` proofs as `rIsEmpty`;
- `LlmSymbolWeights` and `SynthesizedSymbolWeights` proofs as CPF 2.1-style `trsTerminationProof` using `ruleRemoval`, `orderingConstraintProof`, `redPair`, and `knuthBendixOrder`, followed by an empty remaining TRS and `rIsEmpty`.

Ferrum refuses CPF export for unsupported proof steps instead of emitting fake XML.

Manual full chain:

```sh
cargo run -- prove examples/subterm.trs \
  --llm-proposals examples/subterm-proposal.json \
  --cpf /tmp/ferrum-ceta2.xml

.tools/cpf3/cpf3/xml/cpf2_to_3.sh \
  /tmp/ferrum-ceta2.xml > /tmp/ferrum-ceta3.xml

xmllint --huge --noout \
  --schema .tools/cpf3/cpf3/xml/cpf3.xsd \
  /tmp/ferrum-ceta3.xml

./.tools/ceta-relative-bounds /tmp/ferrum-ceta3.xml
```

Observed output:

```text
/tmp/ferrum-ceta3.xml validates
CERTIFIED
```

Ferrum command wrapping this workflow:

```sh
cargo run -- cert check /tmp/ferrum-ceta2.xml \
  --cpf3-out /tmp/ferrum-ceta3.xml
```

Observed output:

```text
cpf3: /tmp/ferrum-ceta3.xml
/tmp/ferrum-ceta3.xml validates
CERTIFIED
```

## 13. Test and Quality Checks

Current standard verification commands:

```sh
cargo fmt
cargo test
cargo clippy -- -D warnings
cargo run -- tpdb check-parse ../TPDB-ARI
```

Observed final status:

```text
cargo test: 20 passed
cargo clippy -- -D warnings: clean
tpdb check-parse:
  parsed: 10698
  invalid: 391
  failed: 0
  skipped-non-trs: 2828
```

## 14. Current Limitations

Ferrum is still a prototype. Important current limitations:

- CPF 3 export exists for top-level symbol-weight and linear polynomial rule-removal proofs.
- CPF 3 export exists for flexible dependency-pair traces using `dpTrans`, `depGraphProc`, and nested `redPairUrProc`, including polynomial interpretations and recursive path orders with argument filters.
- The current certified top-level polynomial checker requires positive argument coefficients so that CeTA accepts the interpretation as a monotone reduction pair.
- Ferrum accepts LLM proposals from JSON files and can launch local MLX or vLLM servers automatically when `--llm-model-dir` is supplied. The model directory contains only ordinary model files; Ferrum-specific config files are not used there.
- LCTRS, ITS, probabilistic rewriting, higher-order rewriting, and complexity proofs are intentionally out of scope for the current first-order TRS slice.
- The TPDB validation reports 391 parsed-but-invalid ordinary-TRS candidates because Ferrum currently enforces the standard variable condition.

## 15. TPDB Proving Benchmark and First Improvements

After adding CPF/CeTA support, we added a TPDB proving benchmark command:

```sh
cargo run --release -- tpdb prove ../TPDB-ARI
```

The command parses each ordinary first-order TRS, rejects invalid TRSs using Ferrum's validation checks, runs Ferrum's implemented proof search, and reports the proof step used for successful cases. Non-TRS ARI categories such as LCTRS are counted as skipped.

Baseline with local synthesis disabled:

```sh
cargo run --release -- tpdb prove ../TPDB-ARI \
  --no-synthesize-symbol-weights
```

Observed result:

```text
attempted-valid-trs: 10698
proved: 3
unknown: 10695
invalid: 391
failed: 0
skipped-non-trs: 2828
step.subterm-order: 3
```

First improvement: bounded checked symbol-weight synthesis. This keeps the LLM-first order: explicit LLM proposals are tried first, then Ferrum may enumerate a small local proposal space and accept only candidates that pass the same trusted checker.

```sh
cargo run --release -- tpdb prove ../TPDB-ARI
```

Observed result:

```text
attempted-valid-trs: 10698
proved: 121
unknown: 10577
invalid: 391
failed: 0
skipped-non-trs: 2828
synthesize-symbol-weights: true
max-symbol-weight: 2
max-synthesis-symbols: 8
step.synthesized-symbol-weights: 121
```

Second improvement: opt-in bounded checked linear-polynomial synthesis. This searches interpretations

```text
I(f(x1,...,xn)) = c_f + a1*x1 + ... + an*xn
```

with small non-negative constants and positive argument coefficients, then accepts only if Ferrum's interpretation checker proves strict decrease for every rule. The positivity requirement was added after CeTA rejected zero-coefficient interpretations as non-monotone for TRS rule removal.

```sh
cargo run --release -- tpdb prove ../TPDB-ARI \
  --synthesize-linear-polynomial
```

Observed result with the current opt-in defaults:

```text
attempted-valid-trs: 10698
proved: 121
unknown: 10577
invalid: 391
failed: 0
skipped-non-trs: 2828
synthesize-symbol-weights: true
max-symbol-weight: 2
max-synthesis-symbols: 8
synthesize-linear-polynomial: true
max-polynomial-constant: 2
max-polynomial-coefficient: 1
max-polynomial-symbols: 5
max-polynomial-arity: 2
step.synthesized-symbol-weights: 121
```

We also sampled a wider coefficient bound:

```sh
cargo run --release -- tpdb prove ../TPDB-ARI \
  --limit 500 \
  --synthesize-linear-polynomial \
  --max-polynomial-symbols 5 \
  --max-polynomial-constant 2 \
  --max-polynomial-coefficient 2
```

Observed result:

```text
attempted-valid-trs: 500
proved: 16
unknown: 484
step.synthesized-linear-polynomial: 8
step.synthesized-symbol-weights: 8
```

After adding the finite-domain pruning solver, the same 500-problem smoke slice took about 5.6 seconds. A full run with this bound now gives:

```sh
cargo run --release -- tpdb prove ../TPDB-ARI \
  --synthesize-linear-polynomial \
  --max-polynomial-symbols 5 \
  --max-polynomial-constant 2 \
  --max-polynomial-coefficient 2
```

Observed result:

```text
attempted-valid-trs: 10698
proved: 321
unknown: 10377
invalid: 391
failed: 0
skipped-non-trs: 2828
step.synthesized-linear-polynomial: 200
step.synthesized-symbol-weights: 121
```

## 16. Dependency Pair Processor

We added a first real dependency-pair processor. It now builds marked dependency pairs, approximates the dependency graph, decomposes it into SCCs, computes usable rules for each component, and tries to remove component pairs with checked reduction pairs. Candidate generation is bounded and proof-checking remains in Rust.

Implemented pieces:

- dependency pairs with source-rule tracking;
- dependency graph SCC decomposition;
- usable-rule closure from DP right-hand sides;
- flexible component-wise reduction-pair removal: a reduction pair may remove all pairs, one pair, or any non-empty subset of the current component, after which Ferrum continues proof search on the remaining subset;
- bounded symbol-weight and linear-polynomial candidate synthesis for components;
- optional SMT-LIB fallback through `z3` or `cvc5`, enabled explicitly with `--dp-smt-fallback`;
- checked path-order reduction pairs with LPO/RPO-style precedence search and per-symbol argument filtering;
- LLM proposals for dependency-pair components may now include `path_order` candidates with `order`, `precedence`, and `argument_filter`;
- proof steps reporting `DependencyPairProof`;
- CPF 3 output for `dpTrans`, `depGraphProc`, and nested `redPairUrProc` proof traces when the flexible component trace uses polynomial interpretations or recursive path orders.
- CPF 3 path-order output uses `<recursivePathOrder>` with status precedence and optional `<argumentFilter>`.
- A CeTA smoke test certifies a generated path-order DP certificate when `.tools/ceta-relative-bounds` is available.

Argument filtering boundary:

- Ferrum only uses argument filtering inside dependency-pair component processors.
- Top-level TRS rule-removal proof search does not accept path-order or argument-filter proposals.
- DP path-order proofs always record a complete per-symbol argument filter for the current DP component. Identity filters are recorded explicitly for symbols that are not projected.

Usable rules:

- Ferrum computes usable rules per current DP component/subproblem.
- It uses those rules inside CPF `redPairUrProc`, so reduction pairs only need to weakly orient the usable rules, not the whole TRS, for those DP reductions.
- For innermost TRSs, Ferrum also emits a standalone CPF `usableRulesProc` around each cyclic DP component proof, switching the DP problem to the computed usable rules before applying reduction pairs.
- A CeTA smoke test certifies a generated innermost DP certificate with `usableRulesProc` when `.tools/ceta-relative-bounds` is available.

Innermost support:

- textual TPDB `.trs` parsing now preserves `(STRATEGY INNERMOST)`;
- ARI parsing infers innermost strategy for TPDB-ARI paths under `TRS_Innermost`;
- `parse` and LLM proof-state output expose the rewrite strategy;
- CPF 3 input now emits `<strategy><innermost/></strategy>` for innermost TRSs;
- dependency-pair proofs for innermost TRSs now exploit usable rules via CPF `usableRulesProc`;
- the current DP processor remains conservative beyond usable rules: full termination proofs are accepted for innermost TRSs, and innermost metadata is carried through the proof-search and certificate interfaces. More specialized innermost processors such as innermost dependency-pair refinements, innermost usable replacement maps, and innermost left-hand-side processors remain next targets.

DP processing is currently opt-in because even bounded component search is still too slow for full-corpus default runs:

```sh
cargo run --release -- tpdb prove ../TPDB-ARI \
  --limit 100 \
  --strategy 'dp'
```

Observed result:

```text
attempted-valid-trs: 100
proved: 16
unknown: 84
invalid: 0
failed: 0
skipped-non-trs: 838
step.dependency-pair-proof: 8
step.synthesized-symbol-weights: 8
```

An attempted 500-problem DP run was interrupted after exceeding the desired interactive runtime. This is the next engineering target: replace most enumeration with a stronger SAT/SMT search path and add per-instance benchmark timeouts.

Certified DP smoke result:

```sh
cargo run --release -- tpdb certify ../TPDB-ARI \
  --limit 100 \
  --strategy 'dp'
```

Observed result:

```text
attempted-valid-trs: 100
proved: 12
cpf-supported: 12
cpf-unsupported: 0
certified: 12
certification-failed: 0
```

The DP CPF writer was also checked on a minimal DP-only TRS `f(s(x)) -> f(x)`, where Ferrum proves via dependency pairs and CeTA certifies the generated `dpTrans` proof.

Flexible DP regression tests added:

- one cyclic component whose pairs are removed in two separate reduction-pair steps;
- one component solved by the path-order backend after polynomial search is disabled, including CPF 3 path-order export;
- a conditional CeTA smoke test for CPF 3 path-order DP certificates;
- CPF 3 input strategy emission for innermost TRSs;
- CPF 3 `usableRulesProc` emission and CeTA certification for innermost DP proofs;
- parser tests for text `INNERMOST` strategy and TPDB-ARI `TRS_Innermost` path inference.

## 17. Certified Proof Counts

Ferrum now emits CPF 3 directly for top-level symbol-weight and linear-polynomial rule-removal proofs. The certified checker and synthesizer require positive argument coefficients for polynomial interpretations, matching CeTA's monotonicity requirement for TRS rule removal.

Default prover certification count:

```sh
cargo run --release -- tpdb certify ../TPDB-ARI
```

Observed result:

```text
attempted-valid-trs: 10698
proved: 121
cpf-supported: 121
cpf-unsupported: 0
certified: 121
certification-failed: 0
invalid: 391
failed: 0
skipped-non-trs: 2828
```

With opt-in top-level linear-polynomial synthesis:

```sh
cargo run --release -- tpdb certify ../TPDB-ARI \
  --synthesize-linear-polynomial
```

Observed result:

```text
attempted-valid-trs: 10698
proved: 121
cpf-supported: 121
cpf-unsupported: 0
certified: 121
certification-failed: 0
invalid: 391
failed: 0
skipped-non-trs: 2828
```

With the wider positive coefficient bound on the full TPDB-ARI valid TRS slice:

```sh
cargo run --release -- tpdb certify ../TPDB-ARI \
  --synthesize-linear-polynomial \
  --max-polynomial-coefficient 2 \
  --max-polynomial-symbols 5 \
  --max-polynomial-constant 2
```

Observed result:

```text
attempted-valid-trs: 10698
proved: 321
cpf-supported: 321
cpf-unsupported: 0
certified: 321
certification-failed: 0
invalid: 391
failed: 0
skipped-non-trs: 2828
```

The next certification target is broadening the dependency-pair proof shapes beyond one-step full component removal and parallelizing the remaining finite-domain search.

## 18. Useful Replay Commands

From `/Users/petersk/Nobackup/festschrift/ferrum`:

```sh
cargo test
cargo clippy -- -D warnings

cargo run -- tpdb discover ../TPDB-ARI
cargo run -- tpdb check-parse ../TPDB-ARI
cargo run --release -- tpdb prove ../TPDB-ARI --jobs 8 --progress-every 50
cargo run --release -- tpdb prove ../TPDB-ARI --jobs 8 --progress-every 50 --synthesize-linear-polynomial
cargo run --release -- tpdb prove ../TPDB-ARI --limit 100 --jobs 8 --progress-every 25 --strategy 'dp'
cargo run -- parse ../TPDB-ARI/TRS_Innermost/AG01_innermost/#4.20.ari
cargo run --release -- tpdb certify ../TPDB-ARI --jobs 8 --progress-every 50
cargo run --release -- tpdb certify ../TPDB-ARI --jobs 8 --progress-every 50 --synthesize-linear-polynomial

cargo run -- llm prompt examples/subterm.trs
cargo run -- prove examples/subterm.trs \
  --llm-model-dir /path/to/model-weights \
  --llm-iterations 2
cargo run -- prove examples/subterm.trs \
  --llm-proposals examples/subterm-proposal.json \
  --cpf /tmp/ferrum.cpf2.xml
cargo run -- cert check /tmp/ferrum.cpf2.xml \
  --cpf3-out /tmp/ferrum.cpf3.xml

cargo run -- prove examples/linear.trs \
  --llm-proposals examples/linear-proposal.json
```

TPDB benchmark execution notes:

- `tpdb prove` and `tpdb certify` now select the benchmark sample deterministically, then process the selected problems in parallel.
- `--jobs` controls the Rayon worker count. The default is `8`, matching the current intended local setting.
- `--progress-every N` prints progress to stderr every `N` completed selected problems, including elapsed time and ETA. Use `--progress-every 0` to suppress progress output.
- Parallel CeTA certification and ad-hoc `cert check` conversions use unique temp files named with the process id and an atomic counter, so concurrent checker invocations do not collide.

Latest 1000-problem parallel certification sample:

```console
cargo run --release -- tpdb certify ../TPDB-ARI \
  --limit 1000 \
  --jobs 8 \
  --progress-every 50 \
  --synthesize-linear-polynomial \
  --max-polynomial-coefficient 2 \
  --max-polynomial-symbols 5 \
  --max-polynomial-constant 2 \
  --strategy 'dp'

tpdb-certify-start selected=1000 skipped-non-trs=838 jobs=8 progress-every=50
attempted-valid-trs: 995
proved: 76
cpf-supported: 76
cpf-unsupported: 0
certified: 69
certification-failed: 7
invalid: 5
failed: 0
skipped-non-trs: 838
jobs: 8
elapsed-ms: 184861
```

TermCOMP 2025 TRS comparison:

- The local comparison table is in `docs/termcomp-2025-trs-comparison.md`.
- The local proof-gap analysis for AProVE's certified `TRS_Innermost` proofs is in `docs/termcomp-2025-innermost-proof-gap.md`.
- It combines official TermCOMP 2025 summary JSON rows for `TRS_Standard` and `TRS_Innermost` with local Ferrum runs over `../TPDB-ARI/TRS_Standard` and `../TPDB-ARI/TRS_Innermost`.
- The local TPDB-ARI category sizes match the published 2025 summary sizes: 1528 standard TRSs and 366 innermost TRSs.
- Ferrum is run through `scripts/termcomp_trs_compare.py`, which uses one subprocess per problem and a 60-second per-instance timeout so hard instances cannot block the whole category.
- The comparison harness prints progress every 10 completed examples by default
  (`--progress-interval N` changes this), including YES/NO/certified/MAYBE,
  timeout, error, certificate-failure, elapsed-time, and ETA counters.
- The harness keeps per-example artifacts by default in
  `target/termcomp-runs/<timestamp>` or in `--run-dir DIR`: Ferrum stdout/stderr,
  CPF proof files when produced, CeTA stdout/stderr, the per-problem command, and
  `result.json`. It also writes `details.json` and `summary.md` into the run
  directory. Use `--no-keep-artifacts` only for disposable runs.
- To iterate after a full run without wasting time on known timeout examples,
  pass `--from-details DETAILS.json`; by default this reruns only previous
  `yes`, `no`, `unknown`, and `error` cases. Add repeated `--include-status`
  flags to choose a different subset.

```console
cargo build --release
python3 scripts/termcomp_trs_compare.py \
  --jobs 8 \
  --timeout 60 \
  --output docs/termcomp-2025-trs-comparison.md
```

Innermost-focused processor update:

- Ferrum now uses a larger default DP component cap and bounded precedence-permutation search for DP path orders.
- Argument-filter candidates for DP path orders are generated through the Rust `varisat` SAT solver. The encoding chooses exactly one filter shape per symbol, currently identity or a single projection, enumerates satisfying models with blocking clauses, and then checks each resulting path-order candidate in Ferrum before accepting it.
- Ferrum also implements an innermost `removeNonApplicableRules` processor: if a rule's left-hand side contains a proper non-variable subterm that is an instance of some rule left-hand side, that rule can never fire at an innermost root, so Ferrum removes it and recursively proves the reduced TRS. This is still conservative beyond the direct non-applicability criterion.
- CPF 3 export supports this recursive proof shape through `removeNonApplicableRules`; a synthetic smoke test was accepted by CeTA.
- An intermediate run found 21 YES / 16 certified YES / 11 timeouts. The 5 certificate failures were caused by an over-permissive RPO checker: Ferrum allowed non-strict domination of right-hand-side arguments in the precedence branch, accepting comparisons such as `f(g(x), s(0)) >= f(g(x), g(x))` that CeTA correctly rejects.
- The RPO checker now requires strict domination of all right-hand-side
  arguments before using root precedence, and the multiset-status matcher uses
  backtracking rather than greedy matching.
- LPO/lex-status DP path-order candidates are now enabled and exported as
  `<recursivePathOrder>` entries with `<lex/>`. The checker has focused
  regressions for same-root lexicographic decrease and for an AProVE-style
  transformed-CSR component shape.
- The RPO-fixed rerun of the TermCOMP 2025 `TRS_Innermost` category with 8 jobs and a 60-second per-instance timeout gave 16 YES / 16 certified YES / 11 timeouts / 0 certificate failures.
- Ferrum now recomputes the residual DP graph after each strict DP removal and can emit a nested CPF `depGraphProc` when the remaining pairs are acyclic. The DP graph approximation was also changed from root-symbol reachability to a unification-based estimated dependency graph using `CAP(rhs)`.
- Rerunning `TRS_Innermost` after the estimated-graph change gives 21 YES / 21 certified YES / 13 timeouts / 0 certificate failures.
- The DP proof representation is now recursive, so after a reduction-pair step Ferrum can continue with a nested `depGraphProc` and solve each residual cyclic SCC separately. This is the required proof-tree shape for adding more DP processors.
- Ferrum now has a first certified size-change processor: a conservative projection-based `subtermCriterion` processor that fires when every DP in the current component strictly decreases under one selected argument projection. It is tried after DP graph splitting and before reduction-pair search because it is fast and structural. CPF 3 output uses `<sizeChangeProc><subtermCriterion/>...`; a synthetic certificate is accepted by CeTA.
- Rerunning `TRS_Innermost` after recursive DP proof trees and the conservative size-change/subterm processor gives 32 YES / 32 certified YES / 12 timeouts / 0 certificate failures.

```console
python3 scripts/termcomp_trs_compare.py \
  --category TRS_Innermost \
  --jobs 8 \
  --timeout 60 \
  --output /tmp/ferrum-innermost-after-ground-normal-graph.md \
  --details-output /tmp/ferrum-innermost-after-ground-normal-graph.json

# after the ground-normal proper RHS call innermost graph extension
# elapsed=1570s total=366
# yes=51 cert_yes=51 no=4 cert_no=4 maybe=143 timeout=168
# error=0 certification-failed=0

python3 scripts/termcomp_trs_compare.py \
  --category TRS_Innermost \
  --jobs 8 \
  --timeout 60 \
  --output /tmp/ferrum-innermost-subterm-first.md
```

An experimental direct innermost-normality dependency-graph pruning pass was
then benchmarked with:

```console
python3 scripts/termcomp_trs_compare.py \
  --category TRS_Innermost \
  --jobs 8 \
  --timeout 60 \
  --output /tmp/ferrum-innermost-after-innermost-normality-graph.md \
  --details-output /tmp/ferrum-innermost-after-innermost-normality-graph.json

# elapsed=1605s total=366
# yes=63 cert_yes=54 no=4 cert_no=4 maybe=131 timeout=168
# error=0 certification-failed=9
```

The nine certification failures were all CeTA rejections of dependency-graph
decompositions: Ferrum removed edges that CeTA's `depGraphProc` estimator still
requires. The direct-normality graph pruning was therefore disabled for
certified proof search rather than reported as progress. The rejected examples
were:

```text
TRS_Innermost/AG01_innermost/#4.17.ari
TRS_Innermost/Mixed_innermost/run_again1.ari
TRS_Innermost/Mixed_innermost/thiemann26i.ari
TRS_Innermost/Transformed_CSR_innermost_04/Ex16_Luc06_iGM.ari
TRS_Innermost/Transformed_CSR_innermost_04/Ex1_GM99_iGM.ari
TRS_Innermost/Transformed_CSR_innermost_04/Ex24_Luc06_iGM.ari
TRS_Innermost/Transformed_CSR_innermost_04/Ex9_Luc06_iGM.ari
TRS_Innermost/raML/appendAll.raml.ari
TRS_Innermost/raML/subtrees.raml.ari
```

After disabling that pruning, the same nine examples were rerun with retained
artifacts in:

```text
target/termcomp-runs/cert-failures-after-direct-pruning-disabled
```

Only the two raML examples still returned `YES`, and both were accepted by
CeTA; the other seven now return `Unknown`.

The next run deliberately excluded the previous timeout examples using the new
details-file filter:

```console
python3 scripts/termcomp_trs_compare.py \
  --category TRS_Innermost \
  --jobs 8 \
  --timeout 60 \
  --from-details /tmp/ferrum-innermost-after-innermost-normality-graph.json \
  --run-dir target/termcomp-runs/innermost-non-timeout-after-direct-pruning-disabled \
  --output /tmp/ferrum-innermost-non-timeout-after-direct-pruning-disabled.md \
  --details-output /tmp/ferrum-innermost-non-timeout-after-direct-pruning-disabled.json \
  --progress-interval 10

# elapsed=313s total=198
# yes=51 cert_yes=51 no=4 cert_no=4 maybe=143 timeout=0
# error=0 certification-failed=0
```

Combining that restricted rerun with the intentionally skipped 168 previous
timeouts gives the current full `TRS_Innermost` table row:

```text
total=366 yes=51 cert_yes=51 no=4 cert_no=4 maybe=143 timeout=168 error=0 certification-failed=0
```

Q-compatibility and innermost LHS follow-up:

- Ferrum now computes an innermost-LHS/Q context per innermost DP component and can try Q-aware DP proof search before falling back to the ordinary component search.
- Q-aware reduction-pair search is guarded by explicit compatibility checks. For polynomial reductions, Ferrum currently only accepts Q contexts whose LHS patterns are already syntactically minimal. For path orders, Ferrum checks the filtered Q LHS patterns are minimal and that collapsing filters for Q root symbols match their marked DP symbols.
- DP path-order argument filtering now supports true collapsing filters internally and in CPF 3 output. Internally, collapsing filters are represented by a sentinel vector; CPF export writes them as `<collapsing>i</collapsing>`.
- The optimistic Q-aware attempt is only recorded in the component certificate when it actually produced the accepted proof. If Ferrum falls back to ordinary search, the certificate is not wrapped in `innermostLhssRemovalProc`.
- Ferrum now allows `innermostLhssRemovalProc` around pure
  `sizeChangeProc` in the real innermost CPF shape, where `usableRulesProc`
  first restricts the DP problem. A CeTA regression covers a non-empty
  innermost-LHS/Q component.
- Regression checks:
  - `TRS_Innermost/AG01_innermost/#4.34.ari` and `TRS_Innermost/Mixed_innermost/innermost2.ari` now return `Unknown` instead of emitting the previously failing Q-reduction certificates.
  - `TRS_Innermost/AG01_innermost/#4.24.ari` certifies after fallback; its CPF contains real collapsing filters but no incorrect Q wrapper.
  - `TRS_Innermost/Mixed_innermost/cade12.ari` now returns `Unknown` instead of the previous Q-wrapped RPO certificate with inconsistent `f`/`f#` filtering.

Short targeted probe:

```console
# first 120 sorted TRS_Innermost ARI files, 10s per Ferrum/CeTA subprocess
yes=16 certified=16 certification-failed=0 unknown=104 timeout=0 q-wrapped=0
```

Verification commands used after this change:

```console
cargo fmt -- --check
cargo test
cargo clippy -- -D warnings
cargo build --release
```

## 2026-07-23 Certified Right-Barren Tail Anchors

Ferrum's exact bound-0 right-barren constructor now searches for a certified
epsilon anchor from a symbol-transition result state to the explicit open-tail
state. Every candidate is checked for Matchbox closure, right extension, and
absence of top-layer redexes before export. This satisfies CeTA's
fresh-constant premise without adding a language-changing unary self-loop.

The first generated certificate is:

```console
target/release/ferrum prove ../TPDB-ARI/SRS_Standard/Zantema_04/z033.ari \
  --strategy 'rfc-relative-match-bounds(max-bound=0,max-words=1,max-word-len=128,max-states=2000,max-transitions=50000,at-bound=merge,closure=right)' \
  --cpf /tmp/ferrum-z033-tail-anchor.cpf.xml --cpf-mode cpf30

.tools/ceta-relative-bounds /tmp/ferrum-z033-tail-anchor.cpf.xml
```

Observed result: `CERTIFIED`. The witness uses the checked epsilon transition
`rfc_0_0_0 -> rfc_0_0_10`. The branch-built checker installed at
`.tools/ceta-relative-bounds` has SHA-256
`d2fa3f0f55d780b28016cfc4f9bbe2176030b50ad155227011dd84bc4bee41db`.

Regression and build:

```console
cargo +1.95.0-x86_64-unknown-linux-gnu test --lib rfc_ --jobs 16
cargo +1.95.0-x86_64-unknown-linux-gnu build --release --jobs 32
```

## RFC checker unary-word specialization (2026-07-24)

The RFC extension now uses a proved specialized evaluator for lifted unary
words. The executable equation is proved equal to the existing general
`ta_res_impl` evaluation, so this changes checker performance rather than the
accepted proof semantics. Two additional sharing improvements keep each
right-extension RHS result across all split positions and construct the
declared-state set once per no-top rule.

The isolated formal builds succeeded:

```console
ISABELLE_IDENTIFIER=ferrum_rfc \
  /work/dfm/festschrift/ferrum/.tools/Isabelle2025-2/bin/isabelle build \
  -d /work/dfm/festschrift/CeTA-rfc/thys -j 16 RFC_Checker_Ext

ISABELLE_IDENTIFIER=ferrum_rfc \
  /work/dfm/festschrift/ferrum/.tools/Isabelle2025-2/bin/isabelle build \
  -d /work/dfm/festschrift/CeTA-rfc/thys -j 16 Proof_Checker Code
```

The final RFC layer took 12 seconds. The unified `Proof_Checker` and `Code`
build took 10m39s under concurrent machine load. The installed checker is:

```text
/work/dfm/festschrift/CeTA-rfc/thys/Code/Bar/ceta-rfc-word-share-v10-linux-20260724
sha256 ee4818b997f7bd4f3af16d917e5160bd66fa6b26c684a76b03875ac900b6817e
```

It is installed as `.tools/ceta-relative-bounds`. The prior v7 checker is
retained as `.tools/ceta-relative-bounds.pre-word-fast-v10-20260724`, SHA-256
`cb1e44ca316937d7a5447fa5a28d87799d44c3ccf409582f701fafc0deb10fdd`.

On the unchanged 2,044-state certificate for `ICFP_2010/107193.ari`, checker
time developed as follows:

| Checker | Elapsed | Result |
| --- | ---: | --- |
| set-closure v7 | about 155s | CERTIFIED |
| specialized unary evaluator v8 | 63.4s | CERTIFIED |
| shared right-extension RHS v9 | 56.2s | CERTIFIED |
| shared no-top state set v10 | 54.4s | CERTIFIED |

The final checker is about 65% faster on this large witness. On the 54
certificates that timed out in the fixed 189-example run, v10 certifies 18 at
the original 40-second checker limit and 40 at a 60-second limit. All 101
previously certified certificates still certify within 40 seconds. Thus the
same retained proof artifacts give 155 YES / 119 certified YES at 40 seconds,
up from 155 / 101, with no checker rejections.

Full checker-run artifacts:

```text
target/checker-runs/20260724-rfc-word-share-v10-prior-certified-40s
target/checker-runs/20260724-rfc-word-share-v10-former-timeouts-40s
target/checker-runs/20260724-rfc-word-share-v10-former-timeouts-60s
```

The remaining performance target is a verified transition index keyed by
lifted symbol and unary LHS state. The current evaluator avoids generic term
overhead but still scans every transition for a lifted symbol at each word
position.

## Utility-oracle TRS Standard run and timeout repair (2026-07-24)

Timeout investigation found three independent issues:

1. Rayon scopes waited for every spawned branch to join, but path-order
   encoding and argument-filter generation did not poll their cancellation
   deadline while constructing large formulas.
2. The top-level nontermination branch did not pass the enclosing strategy
   deadline into dependency-pair loop, rewriting, and instantiation searches.
3. The Python TermCOMP harness initially timed out only the direct Ferrum
   process. Its first process-group implementation still used an unbounded
   `wait()`/`communicate()` after `SIGKILL`, allowing kernel teardown and
   inherited pipes to extend recorded runs to 412-472 seconds.

Ferrum now polls cancellation in the affected reduction-pair builders and
nontermination searches. The harness starts Ferrum and CeTA in fresh process
sessions, sends TERM and then KILL to the complete process group, retains
partial output, and bounds the cleanup/drain phase. A deliberately
non-cooperative smoke stopped in 5.22 seconds under a five-second external
limit with no surviving Ferrum or solver process.

The post-fix full command was:

```console
RAYON_NUM_THREADS=3 python scripts/termcomp_trs_compare.py \
  --tpdb ../TPDB-ARI \
  --ferrum target/release/ferrum \
  --ceta .tools/ceta-relative-bounds \
  --jobs 128 \
  --timeout 305 \
  --category TRS_Standard \
  --ferrum-profile default \
  --extra-arg=--utility-guidance-manifest \
  --extra-arg=target/termcomp-proof-corpus/training/utility-guidance-v1/top1-positive.jsonl \
  --run-dir target/termcomp-runs/20260724-trs-standard-utility-oracle-timeout-fixed-128w-305s \
  --details-output target/termcomp-runs/20260724-trs-standard-utility-oracle-timeout-fixed-128w-305s/details.json \
  --output target/termcomp-runs/20260724-trs-standard-utility-oracle-timeout-fixed-128w-305s/summary.md \
  --progress-interval 25
```

The harness supplied `timeout(300s, default)` to Ferrum and retained a
five-second external cleanup margin. Results:

| result | count |
|---|---:|
| YES / certified YES | 582 / 582 |
| NO / certified NO | 172 / 172 |
| MAYBE | 727 |
| external timeout | 47 |
| error / certification failure | 0 / 0 |

All 47 external timeouts were recorded between 305.04 and 307.70 seconds. The
small post-305 interval is the bounded TERM/KILL and pipe-drain phase; the
previous unbounded 400-second outliers disappeared. The complete run took 764
seconds. Per-example commands, progress, processor events, partial output,
proofs, checker output, and result records are under the run directory.

Utility guidance made 1,528 top-level and 4,625 dependency-pair queries.
There were 1,760 lookup hits and 1,400 successful guided subproblem closures.
At least one hit occurred in 768 input proofs; 667 had a successful guided
attempt. This is an in-data oracle experiment followed by normal fallback,
not an LLM evaluation.

### Difference from the historical 620-YES run

Problem-by-problem comparison with
`target/termcomp-runs/default-300-trs-standard` found six new YES results and
44 lost YES results, for a net change from 620 to 582. The old 44 proofs were
not marginal timeout successes: 42 finished in under eight seconds, with a
3.35-second mean and an 11.77-second maximum.

Their certified proof shapes are:

| old top-level proof | lost examples |
|---|---:|
| dependency pairs | 32 |
| rule removal | 8 |
| uncurrying | 4 |

Across complete proof trees, 38 of the 44 use a matrix interpretation and 40
use both size change and the subterm criterion. The old benchmark also used a
larger embedded strategy: 275 seconds for uncurrying, 40 seconds for initial
polynomial processing, 20 seconds for DP order/transform portfolios, and 10
seconds for size change. The current defaults use 55, 8, 4, and 2 seconds.

A controlled rerun of all 44 with the old 300-second strategy, no utility
guidance, 16 outer workers, and eight Rayon workers recovered only six.
Therefore the shorter current budgets and utility lookup do not explain most
of the regression.

Two implementation effects were observed:

1. Current DP search nests multiple Rayon portfolios. With a small per-process
   Rayon pool, successful matrix/size-change branches can be delayed behind
   nested order and transformation branches. `AProVE_04/JFP_Ex51.ari` failed
   with eight Rayon workers but again produced a certified YES in 1.56 seconds
   with 64.
2. There was also a matrix-search backend regression independent of thread
   count. On `Transformed_CSR_04/Ex14_AEGL02_C.ari`, the historical
   dimension-2 matrix processor removed one of two pairs and the resulting
   one-pair component was closed by a dimension-1 matrix. The old CPF still
   records a valid certified witness.

The roughly 40-example score difference is consequently dominated by matrix
interpretation productivity plus nested-parallel scheduling, with reduced
strategy budgets as a secondary factor. It is not primarily an oracle-guidance
failure.

### Matrix backend diagnosis and repair (2026-07-24)

The matrix regression was reproduced with both the current executable and an
exact build of commit `c0a50e9`, which closely matches the historical run.
The Rust matrix encoding from that commit also fails when Z3 is selected, so
the regression was not caused by changed matrix semantics or proof checking.
It was caused by generic solver discovery preferring Z3 whenever both Z3 and
CVC5 were installed.

For the direct strategy
`timeout(10s,dp(graph;matrix(dimension=2,max-constant=2,max-coefficient=1)))`
on `Transformed_CSR_04/Ex14_AEGL02_C.ari`:

| executable / solver | result | DP processor time |
|---|---|---:|
| historical `c0a50e9` / Z3 4.15.4 | MAYBE | 10.000 s |
| current final binary / Z3 4.16.0 | MAYBE | 30.020 s |
| historical `c0a50e9` / CVC5 1.3.5 | YES | 4.821 s |
| current final binary / CVC5 1.3.5 | YES | 5.906 s |

Ferrum now honors an explicitly configured solver first, but otherwise prefers
CVC5 for the QF_BV matrix encodings and falls back to Z3 only when CVC5 is not
available. Other SMT-backed processors retain their existing solver choice. An
equisatisfiable experiment replacing multiplication by binary coefficients
with `ite` was rejected: despite the superficially simpler formula, it slowed
CVC5 on the regression component from 1.922 to 3.614 seconds and crossed the
two-second portfolio deadline. The final implementation retains the original
`bvmul` encoding.

The repaired ordinary-PATH run produced
`target/matrix-regression-ex14-final.cpf3.xml` in 5.906 seconds, and CeTA
returned `CERTIFIED`.

A second integration regression came from the generic top-level `termination`
atom forcing `DpStrategy::fast_default_for`. That strategy caps the complete
order portfolio at two seconds, whereas the historical implementation let an
unset DP strategy select the full default. Ferrum now restores the full default
for `termination`; the explicit `fast-dp` atom remains available when a
strategy deliberately requests the short portfolio. With both fixes and the
original `bvmul` encoding, `Ex14_AEGL02_C.ari` again produces a certified YES
through the actual `default-300.fs` strategy in 3.8 seconds.

The exact 44-example controlled set was rerun after both final fixes with the
same old `strategies/default-300.fs`, 16 outer workers, eight Rayon threads per
proof, and a 305-second external timeout:

```console
RAYON_NUM_THREADS=8 python scripts/termcomp_trs_compare.py \
  --tpdb ../TPDB-ARI \
  --ferrum target/release/ferrum \
  --ceta .tools/ceta-relative-bounds \
  --jobs 16 \
  --timeout 305 \
  --category TRS_Standard \
  --ferrum-profile default \
  --file-list target/termcomp-runs/20260724-lost44-matrix-cvc5-file-list.txt \
  --extra-arg=--strategy-file \
  --extra-arg=strategies/default-300.fs \
  --extra-arg=--no-top-level-llm \
  --run-dir target/termcomp-runs/20260724-lost44-matrix-final-fix-16w-305s
```

It obtained 18 certified YES, 23 MAYBE, and three timeouts, compared with six
certified YES in the pre-fix control. Fourteen results were new relative to
that control; 14 of the 18 final proofs use matrix interpretations, while four
additional proofs returned because `termination` again invokes the full DP
default. Two proofs found by the first control were displaced by nested
scheduling in this run. Rerunning precisely those two with 64 Rayon threads
recovered both as certified YES in at most two seconds. Across the two
scheduling settings, 20 distinct members of the old 44 are recovered, with no
certification failures. The remaining gap is therefore no longer a matrix
solver correctness issue; nested portfolio scheduling and broader strategy
productivity remain separate targets.

Result: 14 RFC tests passed and one diagnostic test remained ignored.

Focused direct-`RelRFCmb{-1}` runs used the fixed 189-example list stored in
each run directory and retained all per-example artifacts:

| Run | YES | Certified YES | MAYBE | Timeout | Cert failed |
| --- | ---: | ---: | ---: | ---: | ---: |
| `20260723-rfc-exact-right-barren-tail-anchor-189-32w-20s` | 8 | 8 | 114 | 67 | 0 |
| `20260723-rfc-tail-anchor-runtime-fixed-189-32w-20s` | 8 | 8 | 147 | 34 | 0 |
| `20260724-rfc-paired-189-32w-20s-r2` | 12 | 9 | 139 | 38 | 3 |
| `20260724-rfc-paired-v2-189-32w-20s` | 12 | 12 | 139 | 38 | 0 |

The final run certifies the original eight examples (`multum4.ari`,
`z033.ari`, `z049.ari`, `z050.ari`, `z055.ari`, `z061.ari`, `z062.ari`, and
`z063.ari`) plus `ICFP_2010/{3770,4002,4046,64160}.ari`.

The runtime improvement avoids enumerating partial deletion batches at bound 0,
where the exact constructor only supports deleting all rules. RFC progress
artifacts now record barren place/epsilon counts and every tail-anchor
candidate's state count, transition count, elapsed time, and failing predicate.

The former power gap was structural: all eight successes had one rule, while
the remaining examples have 7--100 rules. A single common tail requires every
RHS template to be accepted from that tail and introduces redexes absent from
Matchbox's place automaton. In `CeTA-rfc`, `RFC_Checker_Ext` now verifies:

- executable pairwise acceptance of `zip initialTerms tailStates`;
- recovery of the paired tail for each RHS by rule index; and
- preservation of that chosen tail through every RFC narrowing step.

The executable checker uses `rfc_initial_covers`, rather than list equality, so
CPF rule normalization may reorder strict rules without changing the witness.
Every explicit tail must occur in the automaton's RHS states. The semantic
bridge chooses a fresh constant independently for each paired tail and invokes
the generic accepted-start-set theorem. Ferrum emits the corresponding
multi-rule witness and realizes right-extension obligations with epsilon links,
while keeping state compatibility at identity.

The order-independent checker was built from
`/work/dfm/festschrift/CeTA-rfc` with:

```console
AFP=/work/dfm/festschrift/ferrum/.tools/afp-current/thys \
  /work/dfm/festschrift/ferrum/.tools/Isabelle2025-2/bin/isabelle build \
  -j 16 -d thys -b RFC_Checker_Ext

AFP=/work/dfm/festschrift/ferrum/.tools/afp-current/thys \
  /work/dfm/festschrift/ferrum/.tools/Isabelle2025-2/bin/isabelle build \
  -j 64 -d thys -b Proof_Checker Code
```

`RFC_Checker_Ext` rebuilt in about 38 seconds. The full `Proof_Checker` and
`Code` build took about 11 minutes. The installed checker is
`.tools/ceta-relative-bounds`, SHA-256
`f5bf82d80ac871d21c496f61e527e1df37818995cbb33ececaf8b90d0315fd5f`.
Before installation, the binary certified the three previously order-sensitive
proofs, `64160.ari`, and all eight established RFC regressions.

The final focused run used:

```console
python3 scripts/termcomp_trs_compare.py \
  --tpdb ../TPDB-ARI \
  --ferrum target/release/ferrum \
  --ceta .tools/ceta-relative-bounds \
  --jobs 32 --timeout 60 --category SRS_Standard \
  --from-details target/termcomp-runs/20260724-rfc-paired-189-32w-20s-r2/details.json \
  --include-status yes --include-status no --include-status unknown \
  --include-status timeout --include-status error \
  --extra-arg=--strategy \
  --extra-arg='timeout(20s,rfc-relative-match-bounds(max-bound=3,max-words=10000,max-word-len=128,max-states=2000,max-transitions=50000,at-bound=merge,closure=right))' \
  --run-dir target/termcomp-runs/20260724-rfc-paired-v2-189-32w-20s \
  --progress-interval 5
```

The run took about 160 seconds wall-clock. Its 189 per-example artifact
directories retain `command.json`, Ferrum output, `progress.jsonl`,
`proof.cpf3.xml` where applicable, CeTA output, and `result.json`.

## 2026-07-23 Exact Right-Barren RFC Tail States

The Matchbox `RelRFCmb{-1}` investigation used
`SRS_Standard/Zantema_04/z033.ari` as the first regression. Matchbox's
right-barren construction starts with the disjoint union of RHS paths and an
empty epsilon relation. Ferrum previously added edges between every RHS end
and every RHS start, then merged all starts into one synthetic final state.
That accepted arbitrary RHS concatenations, introduced an LHS path, and made
the resulting certificate fail CeTA's no-top-redex/extension conditions.

Ferrum's `SrsRfcBarrenBuilder` now:

- starts with only the level-0 RHS places and no synthetic cycle edges;
- represents Matchbox height `-1` as `top = None` and bound `0`;
- emits the original RHS paths and the completed barren epsilon relation;
- distinguishes the declared open-tail states (`BoundsProof.final_states`)
  from the tree automaton's accepting/root states;
- adds only a reflexive epsilon marker for each declared tail, which does not
  change epsilon-closed acceptance but witnesses that the tail occurs as an
  automaton result state for the generic bounds checker;
- skips the old synthetic bound-0 saturation fallback when the exact
  construction declines.

The CeTA executable predicate was generalized from
`rfc_matchbox_ext_right_impl TA rel states R` to
`rfc_matchbox_ext_right_impl TA rel tails states R`. The quantified base of a
right extension ranges over the explicitly declared tails; intermediate
states still range over all automaton states. The existing Isabelle semantic
proof was propagated with the fixed tail as an explicit assumption through
word overlap, narrowing, and right-forward closure.

The first exported checker still rejected the exact z033 witness because
`productive_tree_automaton` used ordinary ground-term productivity. A unary
open-tail word automaton over a signature without constants has no
ground-productive states, so this deleted the entire valid witness. The
Matchbox-relative checker now checks the supplied automaton directly. This is
conservative: every supplied state must satisfy closure, no-top-redex, and
match-bounds compatibility; Ferrum emits no irrelevant states.

Formal build commands:

```console
AFP=/work/dfm/festschrift/ferrum/.tools/afp-current/thys \
  /work/dfm/festschrift/ferrum/.tools/Isabelle2025-2/bin/isabelle build \
  -j 8 -d /work/dfm/festschrift/CeTA-rfc/thys \
  RFC_Checker_Ext Proof_Checker Code
```

Focused Rust verification:

```console
cargo +1.95.0-x86_64-unknown-linux-gnu test --lib rfc_ --jobs 16
```

Observed Rust result: 14 passed, 0 failed, and one ignored diagnostic. The
former minute-long bound-0 decline regression now finishes in one second.

The exact Matchbox height `-1` benchmark set is selected from
`target/termcomp-proof-corpus/y2025-rfc-srs-standard-supported-preprocessing-targets.csv`
by requiring group `direct-rfc`, a single `RelRFCmb` step, and a skeleton
containing `RelRFCmb{-1}`. This yields 189 SRS Standard examples.

## 2026-07-22: Certified Matchbox-Relative RFC Merge/Epsilon Smoke

CeTA tree:

```text
/work/dfm/festschrift/CeTA-rfc
```

Ferrum tree:

```text
/work/dfm/festschrift/ferrum
```

The RFC extension session, proof checker, and code session were rebuilt with:

```console
AFP=/work/dfm/festschrift/ferrum/.tools/afp-current/thys \
  /work/dfm/festschrift/ferrum/.tools/Isabelle2025-2/bin/isabelle build \
  -v -o timeout=1800 -j 64 \
  -d /work/dfm/festschrift/CeTA-rfc/thys RFC_Checker_Ext

AFP=/work/dfm/festschrift/ferrum/.tools/afp-current/thys \
  /work/dfm/festschrift/ferrum/.tools/Isabelle2025-2/bin/isabelle build \
  -v -o timeout=1800 -j 128 \
  -d /work/dfm/festschrift/CeTA-rfc/thys Proof_Checker Code
```

The checker was exported and installed as Ferrum's active checker:

```console
out=/tmp/ceta-rfc-matchbox-export-20260722-224238
ghcdir=/tmp/ceta-rfc-matchbox-ghc-20260722-224238

AFP=/work/dfm/festschrift/ferrum/.tools/afp-current/thys \
  /work/dfm/festschrift/ferrum/.tools/Isabelle2025-2/bin/isabelle export \
  -n -d /work/dfm/festschrift/CeTA-rfc/thys \
  -O "$out" -p 2 -x '*:code/export1/**' Code

cp /work/dfm/festschrift/CeTA-rfc/thys/Code/Bar/Main.hs "$out/export1/Main.hs"

/work/dfm/festschrift/ferrum/.tools/.ghcup/bin/ghc -O2 \
  -i"$out/export1" \
  -outputdir "$ghcdir" -hidir "$ghcdir" -odir "$ghcdir" \
  -o /work/dfm/festschrift/CeTA-rfc/thys/Code/Bar/ceta-rfc-matchbox-real-linux \
  "$out/export1/Main.hs"

cp /work/dfm/festschrift/CeTA-rfc/thys/Code/Bar/ceta-rfc-matchbox-real-linux \
  /work/dfm/festschrift/ferrum/.tools/ceta-relative-bounds
```

Ferrum verification:

```console
export OPENSSL_DIR=/home/ucloud/miniforge3/envs/ferrum
export OPENSSL_INCLUDE_DIR=/home/ucloud/miniforge3/envs/ferrum/include
export OPENSSL_LIB_DIR=/home/ucloud/miniforge3/envs/ferrum/lib
export PKG_CONFIG_PATH=/home/ucloud/miniforge3/envs/ferrum/lib/pkgconfig

cargo +1.95.0-x86_64-unknown-linux-gnu test --lib rfc --jobs 64
cargo +1.95.0-x86_64-unknown-linux-gnu build --release --jobs 64
```

Smoke certification:

```console
mkdir -p target/rfc-matchbox-real-smoke

./target/release/ferrum prove target/rfc-matchbox-automaton-smoke/ab-c.ari \
  --cpf target/rfc-matchbox-real-smoke/ab-c.cpf3.xml \
  --cpf-mode cpf30 \
  --strategy 'rfc-relative-match-bounds(max-bound=3,max-words=10,max-word-len=16,max-states=100,max-transitions=1000,at-bound=merge)'

.tools/ceta-relative-bounds target/rfc-matchbox-real-smoke/ab-c.cpf3.xml
```

Observed output:

```text
status: Terminating
step: RfcMatchboxRelativeBounds { ... state_compatibility: [("q0", "q0")] ... }
CERTIFIED
```

## 2026-07-22 CeTA-rfc Automaton-Closed Relative RFC Proof

Goal: certify CPF `<rfcAutomatonClosedRelativeBounds>` for non-empty residual
relative deletion in the local CeTA-rfc checker.

Working tree:

- `/work/dfm/festschrift/CeTA-rfc`

Implemented proof shape:

- prove an abstract bridge lemma:
  automaton-closed RFC termination of deleted rules `D` relative to kept rules
  `K`, plus the recursive residual proof `SN_rel K D`, implies
  `SN_rel D K`;
- prove the executable processor theorem
  `rfc_automaton_closed_relative_bounds_tt`;
- enable the CPF proof constructor in `Proof_Checker.Check_Termination`.

Verification commands:

```console
AFP=/work/dfm/festschrift/ferrum/.tools/afp-current/thys \
ISABELLE_IDENTIFIER=ferrum_rfc_work \
/work/dfm/festschrift/ferrum/.tools/Isabelle2025-2/bin/isabelle build \
  -v -o timeout=1800 -j 128 -d /work/dfm/festschrift/CeTA-rfc/thys RFC_Checker_Ext

AFP=/work/dfm/festschrift/ferrum/.tools/afp-current/thys \
ISABELLE_IDENTIFIER=ferrum_rfc_work \
/work/dfm/festschrift/ferrum/.tools/Isabelle2025-2/bin/isabelle build \
  -v -o timeout=1800 -j 128 -d /work/dfm/festschrift/CeTA-rfc/thys Proof_Checker
```

Observed results:

- `RFC_Checker_Ext`: passed in 0:24 elapsed.
- `Proof_Checker`: passed in 0:05:38 elapsed.

## RFC Automaton-Closed Exact Witnesses And Relative-Theorem Boundary

Date: 2026-07-22.

Ferrum change:

- `rfc-match-bounds(...)` now tries a conservative exact automaton-closed
  witness path after finite RFC closure fails.
- The exact path validates the generated automaton against the same certified
  conditions used by CeTA-rfc before exporting
  `<rfcAutomatonClosedBounds>`: all-state initial acceptance, automaton split
  closure, lhs suffix totality, and ordinary match-bounds local compatibility.
- Merge-style `at-bound=merge` automaton-closed witnesses are still not
  exported as certified YES proofs.

Smoke observations:

- `SRS_Standard/Zantema_04/z061.ari` still proves through finite
  `<rfcBounds>` and certifies with `.tools/ceta-relative-bounds`.
- `SRS_Standard/Zantema_04/z031.ari` remains `Unknown` under the conservative
  exact automaton-closed path; the old raw witness depended on merge-style
  semantics that are not yet formalized.
- A small Bouchare RFC sample likewise did not recover the old raw
  automaton-closed candidates.

CeTA status:

- `/work/dfm/festschrift/CeTA-rfc` builds `RFC_Checker_Ext`.
- `Proof_Checker` also builds after keeping
  `<rfcAutomatonClosedRelativeBounds>` intentionally rejected until the
  relative-chain theorem is certified.
- A direct attempt at a general relative RFC equivalence was not kept: it
  incorrectly tried to account for weak-only `K` steps as strict multiset
  decreases. The remaining formal task is a subsequence/chain extraction over
  infinitely many strict `D` steps, allowing weak stretches between them and
  producing infinitely many strict RFC narrowing steps.

Verification commands:

```console
cd /work/dfm/festschrift/CeTA-rfc
AFP=/work/dfm/festschrift/ferrum/.tools/afp-current/thys \
ISABELLE_IDENTIFIER=ferrum_rfc_work \
/work/dfm/festschrift/ferrum/.tools/Isabelle2025-2/bin/isabelle build \
  -v -o timeout=1800 -j 128 -d /work/dfm/festschrift/CeTA-rfc/thys \
  RFC_Checker_Ext

AFP=/work/dfm/festschrift/ferrum/.tools/afp-current/thys \
ISABELLE_IDENTIFIER=ferrum_rfc_work \
/work/dfm/festschrift/ferrum/.tools/Isabelle2025-2/bin/isabelle build \
  -v -o timeout=1800 -j 128 -d /work/dfm/festschrift/CeTA-rfc/thys \
  Proof_Checker

cd /work/dfm/festschrift/ferrum
env -u CC -u CFLAGS -u CPPFLAGS -u LDFLAGS \
cargo +1.95.0-x86_64-unknown-linux-gnu check --lib --bins --jobs 32

env -u CC -u CFLAGS -u CPPFLAGS -u LDFLAGS \
cargo +1.95.0-x86_64-unknown-linux-gnu test --lib rfc_match_bounds --jobs 32
```

Observed results:

- `RFC_Checker_Ext`: passed.
- `Proof_Checker`: passed in 5m18s elapsed / 16m54s CPU in the
  `ferrum_rfc_work` Isabelle home.
- Ferrum Rust check: passed.
- Focused Ferrum RFC tests: 4 passed, 0 failed, 290 filtered out, finished in
  118.20s.

## 2026-07-22 RFC Checker State

CeTA-rfc tree used:

```text
/work/dfm/festschrift/CeTA-rfc
```

The split RFC checker session verifies the absolute automaton-closed RFC
theorem and the top-level proof checker:

```console
AFP=/work/dfm/festschrift/ferrum/.tools/afp-current/thys \
ISABELLE_IDENTIFIER=ferrum_rfc_work \
/work/dfm/festschrift/ferrum/.tools/Isabelle2025-2/bin/isabelle build -v \
  -o timeout=1800 -j 128 \
  -d /work/dfm/festschrift/CeTA-rfc/thys RFC_Checker_Ext

AFP=/work/dfm/festschrift/ferrum/.tools/afp-current/thys \
ISABELLE_IDENTIFIER=ferrum_rfc_work \
/work/dfm/festschrift/ferrum/.tools/Isabelle2025-2/bin/isabelle build -v \
  -o timeout=1800 -j 128 \
  -d /work/dfm/festschrift/CeTA-rfc/thys Proof_Checker
```

Observed results:

```text
Finished RFC_Checker_Ext (0:00:08 elapsed time, 0:00:23 cpu time)
Finished Proof_Checker (0:05:23 elapsed time, 0:17:08 cpu time)
```

The older experimental relative RFC equivalence block in
`RFC_Matchbounds_Ext.thy` remains disabled. Re-enabling it fails exactly at the
invalid step where a weak `K`-only rewrite would be treated as a strict
relative step. Consequently, `<rfcAutomatonClosedRelativeBounds>` is currently
parsed but explicitly rejected by `Check_Termination.thy` until a proper
relative-chain/RFC theorem is proved. This keeps the trusted checker
conservative.

Fresh finite RFC smoke test:

```console
target/release/ferrum prove \
  /work/dfm/festschrift/TPDB-ARI/SRS_Standard/Zantema_04/z061.ari \
  --cpf /work/dfm/festschrift/ferrum/target/rfc-current-smoke/z061.cpf3.xml \
  --cpf-mode cpf30 \
  --no-top-level-llm \
  --strategy 'rfc-match-bounds(max-bound=3,max-words=10000,max-word-len=128,max-states=2000,max-transitions=50000,at-bound=exact)'

/work/dfm/festschrift/CeTA-rfc/thys/Code/Bar-rfc-bridge-20260722-074032/export1/ceta-rfc-bridge \
  /work/dfm/festschrift/ferrum/target/rfc-current-smoke/z061.cpf3.xml
```

Observed result: `CERTIFIED`.

Fresh Code export and executable build:

```console
AFP=/work/dfm/festschrift/ferrum/.tools/afp-current/thys \
ISABELLE_IDENTIFIER=ferrum_rfc_work \
/work/dfm/festschrift/ferrum/.tools/Isabelle2025-2/bin/isabelle build -v \
  -o timeout=1800 -j 128 \
  -d /work/dfm/festschrift/CeTA-rfc/thys Code

AFP=/work/dfm/festschrift/ferrum/.tools/afp-current/thys \
ISABELLE_IDENTIFIER=ferrum_rfc_work \
/work/dfm/festschrift/ferrum/.tools/Isabelle2025-2/bin/isabelle export \
  -d /work/dfm/festschrift/CeTA-rfc/thys \
  -x '*:**' \
  -O /work/dfm/festschrift/CeTA-rfc/thys/Code/Bar-rfc-current-20260722-143938 \
  Code

cp \
  /work/dfm/festschrift/CeTA-rfc/thys/Code/Bar-rfc-bridge-20260722-074032/export1/Main.hs \
  /work/dfm/festschrift/CeTA-rfc/thys/Code/Bar-rfc-current-20260722-143938/Code.Code_Haskell/code/export1/Main.hs

cd /work/dfm/festschrift/CeTA-rfc/thys/Code/Bar-rfc-current-20260722-143938/Code.Code_Haskell/code/export1
ghc -O2 -package array -XRankNTypes --make Main.hs -o ceta-rfc-current
```

Observed results:

```text
Finished Code (0:03:27 elapsed time, 0:03:31 cpu time)
Total Code build including IsaFoR_3: 0:10:43 elapsed time, 0:24:07 cpu time
GHC linked ceta-rfc-current
Peak observed system memory during this sequence stayed below 1.32 TB.
```

Fresh executable checks:

```console
./ceta-rfc-current \
  /work/dfm/festschrift/ferrum/target/rfc-current-smoke/z061.cpf3.xml

./ceta-rfc-current \
  /work/dfm/festschrift/ferrum/target/rfc-relative-probe/z061.cpf3.xml
```

Observed result for both: `CERTIFIED`.

Representative existing `<rfcAutomatonClosedBounds>` artifacts still reject
with `TA is not compatible with TRS`; for example
`target/termcomp-runs/20260718-srs-unsolved-256-rfc-automaton-64w-20s/SRS_Standard/17/proof.cpf3.xml`.
This means the executable checker is present, but Ferrum's old automaton-closed
certificates do not satisfy the current formal side conditions.

Ferrum production guard:

```console
env -u CC -u CFLAGS -u CPPFLAGS -u LDFLAGS \
cargo +1.95.0-x86_64-unknown-linux-gnu test --lib rfc_match_bounds --jobs 32

env -u CC -u CFLAGS -u CPPFLAGS -u LDFLAGS \
cargo +1.95.0-x86_64-unknown-linux-gnu run --quiet -- prove \
  /work/dfm/festschrift/TPDB-ARI/SRS_Standard/Zantema_04/z031.ari \
  --cpf /work/dfm/festschrift/ferrum/target/rfc-current-smoke/z031-after-disable.cpf3.xml \
  --cpf-mode cpf30 \
  --no-top-level-llm \
  --strategy 'rfc-match-bounds(max-bound=3,max-words=10000,max-word-len=128,max-states=2000,max-transitions=50000,at-bound=exact)'
```

Observed result:

```text
4 rfc_match_bounds tests passed.
z031 now reports status: Unknown; no invalid automaton-closed certified YES is emitted.
```

Installed checker:

```console
cp /work/dfm/festschrift/CeTA-rfc/thys/Code/Bar-rfc-current-20260722-143938/Code.Code_Haskell/code/export1/ceta-rfc-current \
  /work/dfm/festschrift/ferrum/.tools/ceta-relative-bounds

/work/dfm/festschrift/ferrum/.tools/ceta-relative-bounds \
  /work/dfm/festschrift/ferrum/target/rfc-current-smoke/z061.cpf3.xml
```

Observed result: `CERTIFIED`.

## CeTA RFC Automaton-Closed Relative Bounds, July 22, 2026

Work tree:

- `/work/dfm/festschrift/CeTA-rfc`
- Isabelle home identifier: `ferrum_rfc_work`

Verified theorem layer:

- `RFC_Checker_Ext.RFC_Matchbounds_Ext` now contains a checked
  automaton-closed RFC path.
- The executable checker
  `rfc_automaton_closed_relative_bounds_tt` is connected to
  `rfc_automaton_closed_relative_bounds_SN_on`.
- The proof uses:
  - finite initial RFC templates accepted for every tail state,
  - automaton closure under right-forward RFC steps,
  - suffix-total checks for left-hand-side overlaps,
  - `rfc_no_top_redex_impl` to lift below-top strict compatibility to full
    strict compatibility for unary/SRS rules,
  - `rfc_relative_bounds_impl_semantic` to obtain relative termination on the
    right-forward closure.

Important correction:

- An experimental relative analogue of the right-linear RFC equivalence theorem
  was disabled in the extension file. Its proof attempted to treat weak
  relative `K` substitution steps as strict multiset decreases, which is not
  valid in general. The automaton-closed relative bounds checker does not rely
  on that equivalence.

Verification command:

```console
AFP=/work/dfm/festschrift/ferrum/.tools/afp-current/thys \
ISABELLE_IDENTIFIER=ferrum_rfc_work \
/work/dfm/festschrift/ferrum/.tools/Isabelle2025-2/bin/isabelle build -v \
  -o timeout=1800 -j 128 \
  -d /work/dfm/festschrift/CeTA-rfc/thys RFC_Checker_Ext
```

Observed result:

```console
Finished RFC_Checker_Ext (0:00:08 elapsed time, 0:00:23 cpu time)
```

Integration verification:

```console
AFP=/work/dfm/festschrift/ferrum/.tools/afp-current/thys \
ISABELLE_IDENTIFIER=ferrum_rfc_work \
/work/dfm/festschrift/ferrum/.tools/Isabelle2025-2/bin/isabelle build -v \
  -o timeout=1800 -j 128 \
  -d /work/dfm/festschrift/CeTA-rfc/thys Proof_Checker
```

Observed result:

```console
Finished Proof_Checker (0:05:26 elapsed time, 0:17:23 cpu time)
```

### CeTA RFC Relative Bounds Development, July 22, 2026

RFC relative-bounds certification is being developed in:

- `/work/dfm/festschrift/CeTA-rfc/thys/RFC_Checker_Ext/RFC_Matchbounds_Ext.thy`

Verified progress:

- Added and checked `narrow_steps_to_infinite_rel_rsteps`.
- This is the colored version of the existing narrowing-to-rewriting tail
  argument: an infinite narrowing sequence over `D ∪ K` with infinitely many
  narrowing steps using strict rules `D` induces nontermination of
  `relto (rstep D) (rstep K)` from the corresponding narrowing closure.

Build command:

```console
AFP=/work/dfm/festschrift/ferrum/.tools/afp-current/thys \
ISABELLE_IDENTIFIER=ferrum_rfc_work \
/work/dfm/festschrift/ferrum/.tools/Isabelle2025-2/bin/isabelle build -j 128 \
  -d /work/dfm/festschrift/CeTA-rfc/thys RFC_Checker_Ext
```

Result:

```console
Finished RFC_Checker_Ext
```

Remaining formal obligation before the recursive RFC processor can be made
fully certified:

- Prove the relative RFC lifting theorem. The absolute proof cannot be copied
  directly: the relative first-root-step lemma returns a non-root prefix before
  the root step, so the proof needs a bridge showing that the root-step source
  obtained after that non-root prefix still has the required minimal-subterm
  termination property for the substitution argument.

## CeTA RFC Merge/Relative Development Layer (2026-07-22)

Work tree:

- CeTA RFC tree: `/work/dfm/festschrift/CeTA-rfc`
- Development theory: `thys/RFC_Checker_Ext/RFC_Matchbounds_Ext.thy`

Build command:

```console
AFP=/work/dfm/festschrift/ferrum/.tools/afp-current/thys \
ISABELLE_IDENTIFIER=ferrum_rfc_work \
/work/dfm/festschrift/ferrum/.tools/Isabelle2025-2/bin/isabelle build -j 128 \
  -d /work/dfm/festschrift/CeTA-rfc/thys RFC_Checker_Ext
```

Layering result:

- Editing `Termination_and_Complexity/Matchbounds_Impl.thy` invalidates
  `IsaFoR_2`; one observed rebuild took `0:04:47` elapsed.
- After moving new RFC merge/relative work into `RFC_Checker_Ext`, extension
  rebuilds took about `0:00:20` elapsed, with the RFC session itself taking
  `0:00:06` to `0:00:07`.

Verified in `RFC_Checker_Ext` so far:

- Height-parametric RFC word reachability predicates for automata.
- Executable no-top-redex predicate for removed rules at the cap layer.
- Filtered below-top strict compatibility list for Matchbox-style relative
  RFC merge semantics.
- Extraction theorem for the RFC-relative local-bounds checker, yielding
  below-top strict compatibility and full weak compatibility.
- Semantic relative RFC theorem for the case where full strict compatibility
  is available.
- Bridge theorem `rfc_no_top_redex_full_strict_compat`: below-top strict
  compatibility plus `rfc_no_top_redex_impl` implies full strict compatibility
  for the unary/SRS rules accepted by the automaton-closed RFC checker.
- The bridge is wired into
  `rfc_automaton_closed_relative_bounds_SN_on`: an accepted
  `rfc_automaton_closed_relative_bounds_tt` proof now yields
  `SN_on (relto (rstep deleted) (rstep kept))` on the right-forward closure of
  the current SRS/TRS.

Remaining proof obligation before wiring into the production CeTA checker:

- Prove or import the relative right-forward-closure lifting theorem needed by
  the recursive processor rule: for right-linear systems, RFC-local relative
  termination of deleted rules relative to kept rules should imply global
  relative termination. After that, combine the new RFC-local theorem with
  `SN_qrel_split` and the recursive proof of the residual problem.

CeTA RFC finite-initial checker refactor, 2026-07-18:

- Working tree:
  `/work/dfm/festschrift/CeTA-rfc`.
- Isabelle home:
  `ISABELLE_IDENTIFIER=ferrum_rfc_work`.
- Main verified theorem change:
  `rfc_bounds_impl` uses a fresh nullary constant substitution for the finite
  initial templates directly, and `rfc_bounds_tt` calls
  `check_bounds_generic_without_contains` instead of global
  `check_bounds_generic`.
- Verified sessions:

```console
AFP=/work/dfm/festschrift/ferrum/.tools/afp-current/thys \
ISABELLE_IDENTIFIER=ferrum_rfc_work \
/work/dfm/festschrift/ferrum/.tools/Isabelle2025-2/bin/isabelle build -j 64 \
  -d /work/dfm/festschrift/CeTA-rfc/thys IsaFoR_2

AFP=/work/dfm/festschrift/ferrum/.tools/afp-current/thys \
ISABELLE_IDENTIFIER=ferrum_rfc_work \
/work/dfm/festschrift/ferrum/.tools/Isabelle2025-2/bin/isabelle build -j 64 \
  -d /work/dfm/festschrift/CeTA-rfc/thys Proof_Checker Code
```

- Export/compile path:
  Isabelle `Code` exports to `/tmp/ceta-rfc-export/export1`, compiled with
  GHC 9.6.7 to `/tmp/ceta-rfc-linux`, then installed as
  `/work/dfm/festschrift/ferrum/.tools/ceta-relative-bounds`.
- Previous checker backup:
  `.tools/ceta-relative-bounds.pre-rfc-local-20260718-021631`.
- Ferrum follow-up:
  finite-initial RFC automata no longer seed final-state signature loops.
- Focused verification:

```console
cargo +1.95.0 fmt --check
cargo +1.95.0 test --lib rfc_match_bounds -- --nocapture
cargo +1.95.0 test --lib srs_rfc_initial_words -- --nocapture
```

- Extra probe:
  `SRS_Standard/Bouchare_06/03.ari` with
  `rfc-match-bounds(max-bound=4,max-words=512,max-word-len=8,max-states=20000,max-transitions=200000)`
  still timed out at 45s and emitted no CPF.
- Certified TPDB RFC witness after the refactor:
  `/work/dfm/festschrift/TPDB-ARI/SRS_Standard/Zantema_04/z061.ari`.

```console
target/debug/ferrum prove \
  /work/dfm/festschrift/TPDB-ARI/SRS_Standard/Zantema_04/z061.ari \
  --strategy 'rfc-match-bounds(max-bound=3,max-words=256,max-word-len=32,max-states=5000,max-transitions=50000)' \
  --cpf target/rfc-small-scan-20260718/Zantema_04__z061.manual.cpf3.xml \
  --cpf-mode cpf30

.tools/ceta-relative-bounds \
  target/rfc-small-scan-20260718/Zantema_04__z061.manual.cpf3.xml
```

The Ferrum proof is an RFC match-bounds proof with bound 0 and finite initial
word `abbcbca`; the rebuilt CeTA checker returns `CERTIFIED`.

## CeTA RFC Direct Finite-Initial Bounds Theorem, 2026-07-17

Work continued in the isolated CeTA tree:

```console
cd /work/dfm/festschrift/CeTA-rfc
```

The RFC open-tail helper lemmas were moved from the experimental
`thys/Proof_Checker/RFC_Bounds_Open_Tail.thy` file into
`thys/Termination_and_Complexity/Matchbounds_Impl.thy`, so the verified checker
no longer depends on a checker-local experimental theory.

Implemented and verified in `Matchbounds_Impl.thy`:

- `rfc_initial_funas`, an executable side condition requiring every finite RFC
  initial template to use only symbols in the checked stackable alphabet;
- extraction from the generated automaton, preserving the concrete certificate
  `qfin` needed by RFC tail-state acceptance;
- `rfc_bounds_impl`, a direct theorem for right-linear full TRSs: if the finite
  initial language covers all RHSs, is closed under executable RFC narrowing,
  has at most one variable per template, is accepted by the automaton for every
  selected tail state, and satisfies the usual match-bounds compatibility
  conditions, then `SN (rstep R)`;
- `rfc_bounds_tt`, the executable checker entry point, checks the finite RFC
  side conditions and uses the direct finite-initial theorem, but still obtains
  ordinary bounds facts via `check_bounds_generic`; current executable
  certificates therefore still need the global `lift0(T(Sigma))` automaton
  side condition.

Verification:

```console
AFP=/work/dfm/festschrift/ferrum/.tools/afp-current/thys \
ISABELLE_IDENTIFIER=ferrum_rfc_work \
/work/dfm/festschrift/ferrum/.tools/Isabelle2025-2/bin/isabelle build -j 64 \
  -d /work/dfm/festschrift/CeTA-rfc/thys IsaFoR_2

AFP=/work/dfm/festschrift/ferrum/.tools/afp-current/thys \
ISABELLE_IDENTIFIER=ferrum_rfc_work \
/work/dfm/festschrift/ferrum/.tools/Isabelle2025-2/bin/isabelle build -j 64 \
  -d /work/dfm/festschrift/CeTA-rfc/thys Proof_Checker

AFP=/work/dfm/festschrift/ferrum/.tools/afp-current/thys \
ISABELLE_IDENTIFIER=ferrum_rfc_work \
/work/dfm/festschrift/ferrum/.tools/Isabelle2025-2/bin/isabelle build -j 64 \
  -d /work/dfm/festschrift/CeTA-rfc/thys Code
```

Observed final run before the open-tail executable fix:

- `IsaFoR_2`: 0:03:23 elapsed, 0:22:09 CPU.
- `Proof_Checker`: 0:10:11 elapsed, 0:40:30 CPU, including dependency replay.
- `Code`: 0:10:13 elapsed, 0:22:33 CPU, including `IsaFoR_3`; the `Code`
  session itself took 0:03:24 elapsed, 0:03:28 CPU.

The checked-in Haskell files under
`/work/dfm/festschrift/CeTA-rfc/thys/Code/Bar` are still the old June snapshot,
so the Linux checker was compiled from Isabelle session exports rather than
from the checked-in generated sources:

```console
rm -rf /tmp/ceta-rfc-export && mkdir -p /tmp/ceta-rfc-export
ISABELLE_IDENTIFIER=ferrum_rfc_work \
/work/dfm/festschrift/ferrum/.tools/Isabelle2025-2/bin/isabelle export -n \
  -d /work/dfm/festschrift/CeTA-rfc/thys \
  -O /tmp/ceta-rfc-export -p 2 -x '*:code/export1/**' Code

cp /work/dfm/festschrift/CeTA-rfc/thys/Code/Bar/Main.hs \
  /tmp/ceta-rfc-export/export1/Main.hs

/work/dfm/festschrift/ferrum/.tools/.ghcup/bin/ghc -O2 \
  -i/tmp/ceta-rfc-export/export1 \
  -outputdir /tmp/ceta-rfc-ghc-rfc \
  -hidir /tmp/ceta-rfc-ghc-rfc \
  -odir /tmp/ceta-rfc-ghc-rfc \
  -o /work/dfm/festschrift/CeTA-rfc/thys/Code/Bar/ceta-rfc-linux \
  /tmp/ceta-rfc-export/export1/Main.hs
```

A local GHC 9.6.7 was installed under
`/work/dfm/festschrift/ferrum/.tools/.ghcup` for this compile. The resulting
RFC-capable checker was installed as Ferrum's active checker:

```console
cp /work/dfm/festschrift/CeTA-rfc/thys/Code/Bar/ceta-rfc-linux \
  /work/dfm/festschrift/ferrum/.tools/ceta-relative-bounds
```

The previous checker binary was kept as
`/work/dfm/festschrift/ferrum/.tools/ceta-relative-bounds.pre-rfc-20260717-173750`.

Follow-up on 2026-07-17:

- `rfc_term_accepted_with_tail_states_impl` was fixed to avoid executing
  partial `adapt_vars` on open templates. The executable check now maps template
  variables directly to automaton states before `ta_res_impl`.
- Rebuilt `Proof_Checker` and `Code` with
  `ISABELLE_IDENTIFIER=ferrum_rfc_work`; the final rebuild took 0:14:56 elapsed
  / 1:02:33 CPU.
- Re-exported generated Haskell, rebuilt the Linux checker, and reinstalled it
  as `/work/dfm/festschrift/ferrum/.tools/ceta-relative-bounds`.
- Ferrum's CPF state writer now encodes every automaton state by a non-empty
  injective name, avoiding invalid empty `<state>` elements.
- Ferrum's RFC automata are seeded with final-state height-0 signature loops,
  because the current executable checker still invokes `check_bounds_generic`.
- Focused verification passed:
  `cargo +1.95.0 test --lib rfc_match_bounds -- --nocapture` and
  `cargo +1.95.0 test --lib srs_rfc_initial_words -- --nocapture`.
- A bounded attempt on `SRS_Standard/Bouchare_06/03.ari` failed closed as
  `Unknown`; no uncertified RFC CPF was emitted.
- 2026-07-17 local-checker follow-up: CeTA-rfc now contains
  `check_bounds_generic_without_contains` plus
  `check_bounds_generic_without_contains_exact`. These executable/proof
  components extract well-formedness, final-state, determinism or
  raise-consistency, boundedness, RHS-state, and compatibility facts without
  invoking `ta_contains_impl`. `IsaFoR_2` verifies this split. The remaining
  theorem-level step is to refactor `rfc_bounds_impl` so the finite RFC proof
  uses a fresh-constant substitution argument directly instead of the older
  stackability/global-language argument.

## CeTA RFC Open-Tail Proof Work

Date: 2026-07-17.

To avoid conflicts with concurrent CeTA extension work, the maintained CeTA
tree was copied:

```console
cp -a /work/dfm/festschrift/CeTA /work/dfm/festschrift/CeTA-rfc
```

RFC proof development now uses:

```console
cd /work/dfm/festschrift/CeTA-rfc
AFP=/work/dfm/festschrift/ferrum/.tools/afp-current/thys \
ISABELLE_IDENTIFIER=ferrum_rfc_work \
/work/dfm/festschrift/ferrum/.tools/Isabelle2025-2/bin/isabelle build -j 32 \
  -d /work/dfm/festschrift/CeTA-rfc/thys Proof_Checker
```

`IsaFoR_2` was built once in this copied tree and then reused. Experimental
RFC lemmas live in `thys/Proof_Checker/RFC_Bounds_Open_Tail.thy`, which keeps
failed iterations out of the `IsaFoR_2` heap.

The current `Proof_Checker` build succeeds with checker-local lemmas for:

- semantic extraction from `rfc_term_accepted_with_tail_states_impl`;
- initial-language extraction;
- adapted lifted substitutions;
- open-tail single-variable template instances accepted via stackable states.

The remaining RFC certification blocker is the direct finite-initial-language
match-bounds theorem: use `e_bounds` with the RFC initial language, lift
ground-instance termination back with `SN_wf_ground`, then conclude full
termination through `right_linear_SN_rstep_RFC`.

## CeTA RFC Open-Tail Work, 2026-07-17

Maintained CeTA was rebuilt after adding conservative RFC open-tail helper
checks (`rfc_initial_single_var`) and keeping the executable open-tail
acceptance predicates.

```console
cd /work/dfm/festschrift/CeTA
AFP=/work/dfm/festschrift/ferrum/.tools/afp-current/thys \
ISABELLE_IDENTIFIER=ferrum_rfc_check \
/work/dfm/festschrift/ferrum/.tools/Isabelle2025-2/bin/isabelle build -j 32 \
  -d /work/dfm/festschrift/CeTA/thys Proof_Checker
```

Result:

```text
Finished IsaFoR_2 (0:13:07 elapsed time, 0:49:08 cpu time, factor 3.74)
Finished Proof_Checker (0:04:52 elapsed time, 0:15:25 cpu time, factor 3.16)
0:18:49 elapsed time, 1:04:34 cpu time, factor 3.43
```

The direct open-tail RFC soundness theorem is still pending. The incomplete
extraction lemmas were not kept in the build because generated code constants
introduced hidden `itself` arguments; see
`docs/ceta-rfc-relative-bounds-plan.md` for the next proof route.

## CeTA RFC Finite-Initial Checker

Date: 2026-07-16.

CeTA was extended so termination-side `<rfcBounds>` certificates are no longer
just parsed. The checker now verifies:

- finite initial terms are ground;
- every finite initial term is accepted by the supplied tree automaton;
- the finite initial language contains all right-hand sides;
- it is closed under the executable RFC narrowing step;
- the executable step is proved equal to IsaFoR's
  `right_forw_closure string_rename` narrowing relation.

The final executable `rfc_bounds_tt` termination proof is still conservative:
after the RFC side checks it invokes the existing global `check_bounds_generic`
path to obtain ordinary bounds facts. Thus this is a certified checker for the
finite RFC side condition, but it does not yet certify RFC-only automata that
fail global `lift0(T(Sigma))` acceptance.

Maintained CeTA verification:

```console
AFP=/work/dfm/festschrift/ferrum/.tools/afp-current/thys \
ISABELLE_IDENTIFIER=ferrum_rfc_check \
/work/dfm/festschrift/ferrum/.tools/Isabelle2025-2/bin/isabelle build -j 32 \
  -d /work/dfm/festschrift/CeTA/thys Proof_Checker
```

Ferrum bundled CeTA verification:

```console
AFP=/work/dfm/festschrift/ferrum/.tools/afp-current/thys \
ISABELLE_IDENTIFIER=ferrum_rfc_bundle_check \
.tools/Isabelle2025-2/bin/isabelle build -j 32 \
  -d .tools/CeTA-ferrum-rfc/thys Proof_Checker
```

Observed result: both `Proof_Checker` builds completed successfully. The bundled
fresh-home build took `0:30:32` elapsed time and `2:21:16` CPU time.

The Ferrum-facing checker binary was then regenerated from the bundled checked
source:

```console
ISABELLE_IDENTIFIER=ferrum_rfc_bundle_check \
AFP=/work/dfm/festschrift/ferrum/.tools/afp-current/thys \
CETA_ISABELLE_JOBS=32 \
CETA_GHC_JOBS=16 \
scripts/build_ceta_relative_bounds.sh
```

Observed result: the script rebuilt `Code`, compiled Haskell, and wrote
`.tools/ceta-relative-bounds`; `.tools/ceta-relative-bounds --version` reports
`3.9`.

## 2026-07-15 Subproof Training Data Export

The proof-corpus XML and normalized XML views were converted into supervised
subproblem/proof-fragment training rows with:

```console
python scripts/extract_subproof_training_data.py \
  --out target/termcomp-proof-corpus \
  --output target/termcomp-proof-corpus/training/subproofs.jsonl.gz \
  --source all \
  --progress-interval 1000 \
  --per-proof-progress \
  --per-proof-progress-log target/termcomp-proof-corpus/training/subproofs.progress.jsonl \
  --proof-row-progress-interval 1000 \
  --max-file-bytes 0 \
  --max-output-xml-bytes 2000000 \
  --max-input-xml-bytes 2000000 \
  --min-file-bytes 100
```

The first full pass failed at 40,000 scanned documents with a Python
`RecursionError` while serializing a deeply nested XML proof fragment. The
extractor now raises the Python recursion limit for this offline pass and emits
`proof_progress` events every 1,000 rows inside a single proof, so large
successful proofs show forward progress before their final `proof_done` event.

Final export artefacts:

```text
target/termcomp-proof-corpus/training/subproofs.jsonl.gz
target/termcomp-proof-corpus/training/subproofs.summary.json
target/termcomp-proof-corpus/training/subproofs.progress.jsonl
```

Final summary:

| Metric | Count |
| --- | ---: |
| Candidate XML documents | 42,253 |
| Parsed XML documents | 42,250 |
| Proof documents with rows | 40,762 |
| JSONL rows written | 709,773 |
| Parse skips | 3 |
| Oversized row skips | 1,888 |
| File-size skips | 0 |

Top extracted tags:

| Tag | Rows |
| --- | ---: |
| `step` | 569,154 |
| `interpretation` | 40,666 |
| `depGraphProc` | 17,063 |
| `removed` | 16,070 |
| `ruleRemoval` | 14,673 |
| `redPairProc` | 12,355 |
| `dpTrans` | 10,606 |
| `sizeChangeProc` | 8,352 |

Validation:

```console
gzip -t target/termcomp-proof-corpus/training/subproofs.jsonl.gz
python - <<'PY'
import gzip, json
count = 0
with gzip.open("target/termcomp-proof-corpus/training/subproofs.jsonl.gz", "rt", encoding="utf-8") as handle:
    for line in handle:
        json.loads(line)
        count += 1
print(count)
PY
```

Observed validation result:

```text
gzip-ok
709773
```

## 2026-07-15 Standardized Subproof Row Certification Audit

The subproof JSONL rows are not standalone CPF certificates. To check whether
standardizing row inputs preserves certifiability, the audit samples JSONL rows,
transforms the complete source CPF certificate for each sampled row, and checks
the transformed certificate with local CeTA.

Audit command:

```console
python scripts/audit_standardized_subproof_rows.py \
  --rows 128 \
  --seed 20260715 \
  --timeout 30 \
  --out-dir target/termcomp-proof-corpus/standardize-audit-128
```

The audit samples only TRS rows backed by complete CPF3 certificates whose
original stripped source certificate is accepted by local CeTA. Older CPF2-style
corpus certificates that local CeTA rejects before transformation are excluded
from this certification-preservation check. The transformer supports ordinary
`lhs`/`rhs` rules and compact CPF3 lookup-table rules.

Transformation:

- compute the function-symbol canonicalization using the proof-corpus
  standardization helper. Small inputs can use the brute-force exact
  lexicographic search for comparison; larger inputs use the uncapped
  SMT-backed structural assignment and record the method;
- rewrite all matching CPF function-symbol references, including sharp symbols
  and interpretations;
- alpha-rename variables consistently throughout the complete certificate;
- run local CeTA on the transformed full CPF.

Observed result:

| Metric | Count |
| --- | ---: |
| Sampled JSONL rows | 128 |
| Unique source certificates | 113 |
| CeTA-certified transformed certificates | 128 |
| Failures | 0 |

Sample composition:

| Category | Rows |
| --- | ---: |
| `TRS_Standard` | 78 |
| `TRS_Innermost` | 45 |
| `TRS_Outermost` | 3 |
| `TRS_Relative` | 2 |

Major processor tags:

| Tag | Rows |
| --- | ---: |
| `interpretation` | 22 |
| `usableRulesProc` | 21 |
| `ruleRemoval` | 16 |
| `sizeChangeProc` | 15 |
| `innermostLhssRemovalProc` | 13 |
| `depGraphProc` | 11 |

Audit artefacts:

```text
target/termcomp-proof-corpus/standardize-audit-128/summary.json
target/termcomp-proof-corpus/standardize-audit-128/sample-results.jsonl
```

## 2026-07-15 Canonical Subproof JSONL Export

A canonicalized copy of the full subproof JSONL dataset was generated with:

```console
python scripts/canonicalize_subproof_training_data.py \
  --progress-interval 25000 \
  --output target/termcomp-proof-corpus/training/subproofs.canonical.jsonl.gz \
  --summary target/termcomp-proof-corpus/training/subproofs.canonical.summary.json
```

The canonicalizer applies the proof-corpus function-symbol standardization
helper when a row's `input.problem_xml` contains a supported TRS/QDP-style
rules block. It then rewrites the row's problem XML, local-context XML, and
proof fragment XML with the same function-symbol bijection and alpha-renames
variables consistently inside each XML fragment. Unsupported rows are preserved
unchanged and annotated. As of 2026-07-16, `--max-symbols 0` is uncapped: small
inputs may use exact refinement, while larger inputs use the SMT-backed
structural assignment and store the method in `canonicalization.method`.

The first full attempt was interrupted after 500,000 rows because repeated
exact standardization for identical `problem_xml` strings was too slow. The
script now caches canonicalization plans by SHA-256 of `problem_xml`; the
completed run had 29,830 unique problem XML strings and 679,943 cache hits.

Output artefacts:

```text
target/termcomp-proof-corpus/training/subproofs.canonical.jsonl.gz
target/termcomp-proof-corpus/training/subproofs.canonical.summary.json
```

Final summary:

| Status | Rows |
| --- | ---: |
| `canonicalized` | 56,764 |
| `canonicalized-identity` | 13,949 |
| `unchanged-unsupported` | 638,967 |
| `unchanged-no-problem-xml` | 93 |
| Total | 709,773 |

Validation:

```console
gzip -t target/termcomp-proof-corpus/training/subproofs.canonical.jsonl.gz
python - <<'PY'
import gzip, json
count = 0
with gzip.open("target/termcomp-proof-corpus/training/subproofs.canonical.jsonl.gz", "rt", encoding="utf-8") as handle:
    for line in handle:
        json.loads(line)
        count += 1
print(count)
PY
```

Observed validation result:

```text
gzip-ok
709773
```

## Certified Simple DP Non-Loop Slice

Date: 2026-07-14.

Ferrum now generates a first narrow class of CPF `nonLoop` certificates inside
`dpNonterminationProof`.

Implemented shape:

- A DP pair must admit a pumping substitution `sigma` such that applying
  `sigma` once to the DP LHS gives the DP RHS.
- Every variable in the pumping substitution must still occur in its image,
  e.g. `x -> s(x)`.
- Ferrum emits a CPF pattern-rule derivation using:
  - `originalRule` for the DP pair;
  - `instantiation` on `pumping`;
  - `instantiation` on `closing`;
  - the outer non-loop application with `m = 1`, `b = 1`, and empty position.

This covers simple witnesses such as `F(x) -> F(s(x))`. It does not yet cover
the nested non-loop certificates found in AProVE proofs, which use combinations
of narrowing, rewriting, instantiation, initial pumping, and equivalence inside
the CPF `patternRule` derivation.

Validation:

```console
cargo +1.95.0 fmt --check
cargo +1.95.0 test --lib finds_simple_dp_nonloop -- --nocapture
cargo +1.95.0 test --lib ceta_certifies_cpf3_simple_nonloop_when_available -- --nocapture
cargo +1.95.0 test --lib --jobs 128
cargo +1.95.0 build --release
```

Observed result: 180 library tests passed, including a CeTA-certified simple
non-loop CPF certificate, and the release build succeeded.

## DP/SCT literature pass and KBO-backed size-change

Date: 2026-07-14.

Primary sources checked before accepting the size-change strengthening:

- René Thiemann and Jürgen Giesl, "The Size-Change Principle and Dependency
  Pairs for Termination of Term Rewriting", AAECC 2005.
- Nao Hirokawa and Aart Middeldorp, "Dependency Pairs Revisited", RTA 2004.
- Jürgen Giesl, René Thiemann, Peter Schneider-Kamp, and Stephan Falke,
  "Mechanizing and Improving Dependency Pairs", JAR 2007.

Implementation notes:

- Ferrum's `size-change` / `sct` DP processor keeps the closure/idempotent
  size-change check: accepted graph sets must have a strict self-loop in every
  bad idempotent closure candidate.
- Reduction-pair-backed SCT is used inside the DP framework, not as a
  whole-TRS argument-filtered processor. This matches the DP/SCT combination:
  standard proofs require the chosen reduction pair to weakly decrease all TRS
  rules; innermost proofs use the current usable-rule context. This is stronger
  than the paper's most precise innermost `U(D')` condition and therefore
  conservative.
- Innermost/Q contexts retain the existing filtered-Q guard before accepting
  path-order or KBO witnesses.
- KBO is now part of the expensive innermost SCT portfolio. It synthesizes one
  SMT/LIA model for precedence, weights, and argument filtering, validates the
  concrete model with Ferrum's KBO checker, builds size-change edges from
  argument comparisons, and exports the witness through CPF
  `<sizeChangeProc><reductionPair>...`.

Validation so far:

```console
cargo +1.95.0 check --lib
cargo +1.95.0 fmt --check
cargo +1.95.0 test --lib kbo_size_change_synthesizes_simple_component -- --nocapture
```

Full validation after the KBO-backed SCT change:

```console
cargo +1.95.0 fmt
cargo +1.95.0 test --lib --jobs 128
cargo +1.95.0 build --release
```

Result: 172 library tests passed and release build succeeded.

Fixed 128-example TermCOMP smoke run:

```console
python scripts/termcomp_trs_compare.py \
  --tpdb ../TPDB-ARI \
  --ferrum target/release/ferrum \
  --ceta .tools/ceta-relative-bounds \
  --ferrum-profile enhanced \
  --jobs 128 \
  --timeout 60 \
  --category TRS_Standard \
  --category TRS_Innermost \
  --from-details target/termcomp-runs/random-128-selector-seed-20260714.json \
  --include-status unknown \
  --progress-interval 8 \
  --run-dir target/termcomp-runs/20260714-random-128-kbo-sct \
  --details-output target/termcomp-runs/20260714-random-128-kbo-sct/details.json \
  --output target/termcomp-runs/20260714-random-128-kbo-sct/summary.md
```

Observed result:

| Set | Total | YES | NO | Certified YES | Certified NO | MAYBE | Timeout | Cert failed |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| TRS Standard | 99 | 32 | 13 | 32 | 13 | 3 | 51 | 0 |
| TRS Innermost | 29 | 8 | 0 | 8 | 0 | 0 | 21 | 0 |

Exact per-example status comparison against
`target/termcomp-runs/20260714-random-128-result-prop/details.json` found
0 status/certification changes.

## 2026-07-14 Shape-Dependent Top-Level Strategies

Ferrum's top-level strategy language now supports conditionals:

```text
if(condition, then_strategy, else_strategy)
```

Implemented conditions:

- `standard`: full/standard rewriting strategy.
- `innermost`: innermost rewriting strategy.
- `strict-srs`: TPDB-style SRS encoding with unary symbols and a shared tail
  variable on both sides of every rule.
- `unary-srs`: effective SRS after the complete unary TRS to SRS
  transformation.
- `srs`: either `strict-srs` or `unary-srs`.
- `not(...)`, `all(...)`, and `any(...)` combine conditions.

The checked-in `strategies/default.fs` now dispatches by problem shape:

```text
if(srs, srs_standard, if(innermost, trs_innermost, trs_standard))
```

This keeps category-specific policy in strategies rather than CLI flags or
hard-coded batch-run logic. It also means TPDB batch runs and library users get
the same SRS/TRS/innermost split when they use the default strategy.

Validation:

```console
cargo +1.95.0 fmt --check
cargo +1.95.0 test --lib top_level_strategy_conditions --jobs 128
cargo +1.95.0 check --lib
```

## 2026-07-14 SRS Match-Bounds and SRS NO Processors

Implemented SRS-specific processors:

- `srs-loop` nontermination processor. It performs bounded word rewriting on
  strict TPDB-style SRS encodings and reflects successful word loops back into
  ordinary unary-TRS `LoopProof` certificates. It now searches both the forward
  SRS orientation and the reversed string orientation; reversed candidates are
  reflected back to ordinary original-TRS loop steps before acceptance. CeTA
  therefore checks the usual CPF loop proof.
- SRS match-bounds YES processor. It performs bounded match-height completion
  for strict SRS encodings, emits CPF 3 `<bounds>` with `<match/>`, final states,
  and a closed tree automaton witness, and relies on CeTA to validate closure.
- Weighted SRS length YES processor. It uses one SMT query for positive symbol
  weights and emits the result as an ordinary linear polynomial interpretation.

CeTA smoke tests:

```console
tmp=$(mktemp /tmp/ferrum-srs-loop-XXXX.ari)
printf '(format TRS)\n(fun a 1)\n(fun b 1)\n(rule (a x) (b x))\n(rule (b x) (a x))\n' > "$tmp"
target/release/ferrum prove "$tmp" \
  --cpf /tmp/ferrum-srs-loop.cpf3.xml \
  --cpf-mode cpf30 \
  --strategy 'nontermination(srs-loop)' \
  --no-top-level-llm
.tools/ceta-relative-bounds /tmp/ferrum-srs-loop.cpf3.xml

tmp=$(mktemp /tmp/ferrum-srs-matchbounds-grow-XXXX.ari)
printf '(format TRS)\n(fun a 1)\n(fun b 1)\n(rule (a x) (b (b x)))\n(rule (b x) x)\n' > "$tmp"
target/release/ferrum prove "$tmp" \
  --cpf /tmp/ferrum-srs-matchbounds-grow.cpf3.xml \
  --cpf-mode cpf30 \
  --strategy 'termination' \
  --no-top-level-llm
.tools/ceta-relative-bounds /tmp/ferrum-srs-matchbounds-grow.cpf3.xml

printf '(format TRS)\n(fun a 1)\n(fun b 1)\n(fun c 1)\n(rule (a (b x)) (c (a (b x))))\n' \
  > /tmp/ferrum-srs-smoke/reversed-loop.ari
target/release/ferrum prove /tmp/ferrum-srs-smoke/reversed-loop.ari \
  --cpf /tmp/ferrum-srs-reversed-loop.cpf3.xml \
  --cpf-mode cpf30 \
  --no-top-level-llm
.tools/ceta-relative-bounds /tmp/ferrum-srs-reversed-loop.cpf3.xml
```

Observed results:

- `srs-loop` emitted `status: Nonterminating` and CeTA reported `CERTIFIED`.
- Match-bounds emitted `status: Terminating`, `<bound>1</bound>`, and CeTA
  reported `CERTIFIED`.
- The reversed-orientation SRS loop smoke emitted `status: Nonterminating` and
  CeTA reported `CERTIFIED`.

Negative validation:

- A deliberately false coarse match-bounds certificate for
  `a(x) -> b(x), b(x) -> a(x)` was rejected by CeTA with
  `TA is not compatible with TRS`. This confirms that Ferrum must emit the
  completed automaton witness; accepting all heights up to a bound is not a
  valid shortcut.

## 2026-07-14 Scoped Cancellation for Parallel Strategy Branches

## 2026-07-15 Certified SRS Reversal Match-Bounds

Ferrum now implements reversed match-bounds as the standard composition

```text
stringReversal(bounds(match))
```

instead of reversing the generated tree automaton back by hand. The strategy
language now exposes this as `string-reversal(strategy)`: Ferrum reverses a
strict SRS, runs the nested strategy on the reversed system, and wraps a
successful decisive YES or NO proof in CPF 3 `<stringReversal>`. CeTA checks
both the string-reversal transformation and the nested proof.

The checked-in default SRS strategy now races both YES and NO original/reversed
branches:

```text
let srs_no_base = nontermination(variable-condition; loop; srs-loop; timeout(500ms, rewriting); timeout(500ms, narrowing));
let srs_no = parallel(srs_no_base | string-reversal(srs_no_base));
let srs_yes_base = (poly(max-constant=2, max-coefficient=2, max-symbols=5, max-arity=2);
    termination);
let srs_yes = parallel(srs_yes_base | string-reversal(srs_yes_base));
```

Validation:

```console
cargo +1.95.0 test --lib string_reversal --jobs 128
cargo +1.95.0 test --lib ceta_certifies_cpf3_reversal_match_bounds_when_available \
  --jobs 128 -- --nocapture
cargo +1.95.0 test --lib ceta_certifies_cpf3_reversal_srs_loop_when_available \
  --jobs 128 -- --nocapture
cargo +1.95.0 test --lib default_strategy_is_loaded_from_checked_in_file --jobs 128
```

Observed result: the CPF shape tests passed and the CeTA-gated reversal
match-bounds and SRS-loop tests returned `CERTIFIED`; the checked-in default
strategy parsed successfully with the new parallel SRS branches.

## 2026-07-15 SRS Standard Full Baseline and Timeout Audit

Full local `SRS_Standard` run:

```console
python scripts/termcomp_trs_compare.py \
  --tpdb ../TPDB-ARI \
  --ferrum target/release/ferrum \
  --ceta .tools/ceta-relative-bounds \
  --ferrum-profile default \
  --jobs 128 \
  --timeout 60 \
  --category SRS_Standard \
  --progress-interval 10 \
  --run-dir target/termcomp-runs/20260715-084417-srs-standard-128-60s \
  --details-output target/termcomp-runs/20260715-084417-srs-standard-128-60s/details.json \
  --output target/termcomp-runs/20260715-084417-srs-standard-128-60s/summary.md
```

Observed Ferrum result:

| Category | Total | YES | NO | Certified YES | Certified NO | MAYBE | Timeout | Cert failed |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| SRS Standard | 1921 | 143 | 12 | 143 | 12 | 473 | 1293 | 0 |

Official TermCOMP 2025 comparison rows in the generated summary:

| Tool/config | YES | NO | Certified YES | Certified NO | Timeout | Error/Memout |
| --- | ---: | ---: | ---: | ---: | ---: | ---: |
| matchbox-tc25.0 uncert | 1425 | 249 | 0 | 0 | 242 | 5 |
| MnM-3.24 uncert | 1370 | 251 | 0 | 0 | 284 | 16 memout |
| matchbox-tc25.0 cert | 0 | 0 | 1223 | 240 | 448 | 5 |
| AProVE25 uncert | 1020 | 112 | 0 | 0 | 342 | 447 |
| AProVE25 cert | 2 | 0 | 827 | 112 | 340 | 640 |
| Ferrum | 143 | 12 | 143 | 12 | 1293 | 0 |

Timeout audit:

- 692 timeout rows last reported the generic `Termination` branch.
- 209 timeout rows last reported the SRS nontermination branch.
- 181 timeout rows last reported dimension-2 matrix interpretation.
- 123 timeout rows last reported top-level bounded linear polynomial search.
- 37 timeout rows last reported max-polynomial search.
- 34 timeout rows last reported KBO.

The nontermination timeout rows exposed a concrete bug: local
`timeout(500ms, rewriting)` and `timeout(500ms, narrowing)` only checked the
deadline before entering the processor. The actual SRS loop, bounded rewriting,
and bounded narrowing searches did not check the deadline internally.

Fix:

```console
cargo +1.95.0 fmt --check
cargo +1.95.0 check --lib
cargo +1.95.0 test --lib nontermination --jobs 128
cargo +1.95.0 build --release
```

The processors now receive the local deadline and poll it inside their search
loops. A fixed 128-example slice from the old timeout set was rerun:

```console
python scripts/termcomp_trs_compare.py \
  --tpdb ../TPDB-ARI \
  --ferrum target/release/ferrum \
  --ceta .tools/ceta-relative-bounds \
  --ferrum-profile default \
  --jobs 128 \
  --timeout 60 \
  --category SRS_Standard \
  --from-details target/termcomp-runs/20260715-084417-srs-standard-timeout-sample-128.json \
  --include-status timeout \
  --progress-interval 8 \
  --run-dir target/termcomp-runs/20260715-090021-srs-timeouts128-after-deadline-fix \
  --details-output target/termcomp-runs/20260715-090021-srs-timeouts128-after-deadline-fix/details.json \
  --output target/termcomp-runs/20260715-090021-srs-timeouts128-after-deadline-fix/summary.md
```

Observed result on this slice: 128 old timeouts became 128 `MAYBE` results,
with 0 timeouts and total elapsed time 13 seconds. This does not improve proof
power, but it removes a major runtime pathology and makes subsequent SRS
experiments practical.

## 2026-07-14 Scoped Cancellation for Parallel Strategy Branches

Ferrum now has operational cancellation for nested parallel strategy branches.
Each `parallel(...)` scope creates a cancellation token. When a branch returns a
decisive successful result, the token is set; sibling branches stop launching
new processors and running SMT/SAT solver subprocesses are killed by the shared
runtime wait loop.

This is scoped, so a strategy such as
`parallel(portfolio | narrow; portfolio)` behaves as intended:

- If the plain `portfolio` succeeds, the narrowing branch and its solver
  children are cancelled.
- If `narrow; portfolio` succeeds, the plain portfolio branch is cancelled.
- Inside either portfolio, the first successful reduction pair cancels the
  other order-search subprocesses.

Proof-result classification remains separate from operational cancellation.
For NO search, Ferrum must track whether the preceding processors were sound
and complete for reflecting a nontermination witness back to the original TRS.
A loop found after an incomplete transformation is a branch failure, not a
global NO. If a future NO-oriented abstraction is complete but unsound, that
must also be represented explicitly in the branch state before a NO result is
accepted.

Validation commands:

```console
cargo +1.95.0 fmt
cargo +1.95.0 check --lib
cargo +1.95.0 test --lib --jobs 128
cargo +1.95.0 build --release --jobs 128
```

Regression coverage now includes a runtime test that starts a long-running
child process and verifies that setting the cancellation token kills it before
the ordinary deadline.

Sanity examples after cancellation and nested transform portfolios:

```console
timeout 20s target/release/ferrum prove \
  ../TPDB-ARI/TRS_Standard/Zantema_05/jw27.ari \
  --cpf /tmp/ferrum-jw27-cancel.cpf3.xml \
  --cpf-mode cpf30 \
  --strategy 'timeout(19s, default)' \
  --no-top-level-llm

timeout 40s target/release/ferrum prove \
  '../TPDB-ARI/TRS_Innermost/AG01_innermost/#4.34.ari' \
  --cpf /tmp/ferrum-inner-4-34-cancel.cpf3.xml \
  --cpf-mode cpf30 \
  --strategy 'timeout(39s, default)' \
  --no-top-level-llm
```

Both commands returned `status: Terminating` and emitted CPF files with the
current release binary.

## 2026-07-14 Per-Pair DP Transform Budgets

Ferrum now tracks transform budgets per DP pair and transform kind instead of
using a single branch-wide narrowing counter. This is needed for AProVE-style
strategies where a single DP may be narrowed, instantiated, forward
instantiated, or rewritten only a bounded number of times, while other DPs in
the same branch remain eligible.

The strategy language accepts per-processor overrides:

```text
narrow(max-per-pair=1)
rewrite(3)
instantiate(per_pair=2)
forward-instantiation(max_per_pair=4)
```

The global `max_narrowing_steps` option is still respected as an overall
compatibility cap and as the on/off switch for these transformational DP
processors. Default per-pair limits are currently 2 for narrowing, rewriting,
instantiation, and forward instantiation.

The current budget key is the source rule plus marked lhs/rhs roots. This is
adequate for the existing conservative transformations, but richer future
transformers should assign explicit persistent DP origin IDs.

Validation commands:

```console
cargo +1.95.0 fmt
cargo +1.95.0 check --lib
cargo +1.95.0 test --lib --jobs 128
```

Regression coverage includes parser tests for the override syntax and a direct
unit test that verifies transform budgets are separated per pair and per
transform kind.

## 2026-07-14 SRS Standard and Unary TRS Constants

Ferrum now recognizes two SRS-related shapes:

- TPDB `SRS_Standard` ARI files that are already encoded as unary TRSs with
  the same tail variable on both sides, e.g. `a(b(x)) -> c(x)`.
- General unary TRSs whose symbols all have arity 0 or 1. These are transformed
  to SRS rules by reading unary symbols and constants left-to-right and ignoring
  variables.

The unary-TRS-to-SRS transformation is termination-equivalent: the original
unary TRS terminates iff the transformed SRS terminates. This is a complete
transformation, not merely a sound approximation. The currently implemented
SRS proof method after the transformation is strict length decrease, using the
certifiable linear polynomial interpretation `a(x)=x+1` and `c=1`; that proof
method is sound but not complete.

Validation:

```console
cargo +1.95.0 fmt
cargo +1.95.0 check --lib
cargo +1.95.0 test --lib --jobs 128
cargo +1.95.0 build --release --jobs 128
```

Smoke test with constants:

```console
tmp=$(mktemp /tmp/ferrum-srs-length-XXXX.ari)
printf '%s\n' \
  '(format TRS)' \
  '(fun a 1)' \
  '(fun b 1)' \
  '(fun c 0)' \
  '(fun d 0)' \
  '(rule (a (b c)) d)' > "$tmp"

target/release/ferrum parse "$tmp"
target/release/ferrum prove "$tmp" \
  --cpf /tmp/ferrum-srs-length.cpf3.xml \
  --cpf-mode cpf30 \
  --strategy 'termination' \
  --no-top-level-llm
.tools/ceta-relative-bounds /tmp/ferrum-srs-length.cpf3.xml
```

Observed result: `status: Terminating`, emitted a
`SynthesizedLinearPolynomial` proof, and CeTA returned `CERTIFIED`.

## 2026-07-14 Strategy Result Propagation

Ferrum's strategy evaluators now propagate explicit YES/NO/MAYBE-style results
instead of treating every non-unknown proof object as equally acceptable.

- Top-level strategy combinators (`sequence`, `choice`, `parallel`, and
  `timeout`) operate on `ProveStrategyResult`.
- Nontermination strategy combinators operate on `NonterminationStrategyResult`.
- Branch metadata records whether the current path is still sound for YES and
  complete for NO.
- A decisive result with invalid metadata is downgraded to UNKNOWN/MAYBE with
  its proof steps retained for inspection.

This keeps the public proof status vocabulary at three values:
`Terminating`, `Nonterminating`, and `Unknown`. No additional public status was
needed. Internally, DP proof search still distinguishes `Failed` from
`Inapplicable` where this is useful for operational search control.

Validation commands:

```console
cargo +1.95.0 fmt --check
cargo +1.95.0 check --lib
cargo +1.95.0 test --lib --jobs 128
```

Regression coverage includes:

- A nontermination strategy test that observes a typed `No` result with valid
  branch metadata.
- A top-level strategy-result test that verifies an invalid NO is downgraded to
  `Unknown` instead of being accepted by a meta-processor.

Random mixed TRS smoke benchmark after this change:

- Sample: 128 total ARI/TRS examples from `TRS_Standard` and `TRS_Innermost`.
- Seed: `20260714`.
- Selector:
  `target/termcomp-runs/random-128-selector-seed-20260714.json`.
- Run directory:
  `target/termcomp-runs/20260714-random-128-result-prop`.
- Per-example timeout: 60 seconds.
- Workers: 128.

Command:

```console
python scripts/termcomp_trs_compare.py \
  --tpdb ../TPDB-ARI \
  --ferrum target/release/ferrum \
  --ceta .tools/ceta-relative-bounds \
  --ferrum-profile enhanced \
  --jobs 128 \
  --timeout 60 \
  --category TRS_Standard \
  --category TRS_Innermost \
  --from-details target/termcomp-runs/random-128-selector-seed-20260714.json \
  --include-status unknown \
  --progress-interval 8 \
  --run-dir target/termcomp-runs/20260714-random-128-result-prop \
  --details-output target/termcomp-runs/20260714-random-128-result-prop/details.json \
  --output target/termcomp-runs/20260714-random-128-result-prop/summary.md
```

Observed result:

| Category | Sampled | YES | NO | Certified YES | Certified NO | MAYBE | Timeout | Error | Cert failed |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| TRS_Standard | 99 | 32 | 13 | 32 | 13 | 3 | 51 | 0 | 0 |
| TRS_Innermost | 29 | 8 | 0 | 8 | 0 | 0 | 21 | 0 | 0 |
| Combined | 128 | 40 | 13 | 40 | 13 | 3 | 72 | 0 | 0 |

All solved examples in the random smoke run were CeTA-certified.

## 2026-07-14 Canonical TRS/QDP Standardization Helper

Ferrum now has `src/standardize.rs`, a reusable exact standardization helper.
It supports:

- `standardize_trs` for ordinary TRSs.
- `standardize_problem` for grouped term-pair inputs such as QDP-style
  structures, where group labels represent semantic roles and pair order inside
  each group is canonicalized.
- `standardize_trs_with_bijection` and `standardize_problem_with_bijection`
  for proof-indexing workflows that need the symbol substitution.

The nontrivial part is deterministic rule sorting. Ferrum does not sort by
original function names or variable names. Instead, it searches all global
function-symbol bijections up to a configurable exact cap. For each candidate
bijection, every pair is variable-canonicalized locally by first occurrence
across lhs then rhs, pairs are sorted by their canonical encodings inside each
semantic group, and the lexicographically least whole-problem encoding is
selected. The final result is then renamed by first function-symbol occurrence
to `a`, `b`, `c`, ... and variables per pair to `x`, `y`, ...

The returned bijection maps original function symbols to canonical function
symbols. The result also carries the inverse canonical-to-original bijection,
which is the substitution needed to translate a proof retrieved from the
canonical proof index back to the actual input problem. Because rule/pair order
and variable names are also canonicalized, the result records per-rule/per-pair
metadata: original group/index, canonical group/index, original-to-canonical
variable bijection, and inverse variable bijection. Helper functions
`translate_term`, `translate_rule`, and `translate_pair` apply both function and
variable bijections to proof-side terms, rules, and pairs.

If the number of function symbols exceeds the exact-search cap, the helper
returns `TooManyFunctionSymbols` instead of using a heuristic that would not be
canonical.

Validation:

```console
cargo +1.95.0 fmt
cargo +1.95.0 check --lib
cargo +1.95.0 test --lib standardize --jobs 128
```

Regression coverage includes round-trip tests proving that every original TRS
rule and every original grouped QDP-style pair can be recovered from the
canonical item plus the recorded inverse function and variable bijections.

## 2026-07-14 TermCOMP Proof Corpus

Ferrum now includes `scripts/collect_termcomp_proofs.py` for collecting
TermCOMP proof-output artefacts for training-data construction. It distinguishes
certified and uncertified proof streams in both metadata and local paths.

Current corpus root:

```text
target/termcomp-proof-corpus
```

Commands used:

```console
python scripts/collect_termcomp_proofs.py --jobs 64 --resume --out target/termcomp-proof-corpus
python scripts/collect_termcomp_proofs.py --jobs 64 --resume --index-only --out target/termcomp-proof-corpus
```

The first command downloaded 23,963 raw-GitHub-backed 2025 YES/NO proof
artefacts with 64 workers and zero final download errors. The second command
indexed 150,121 older StarExec-backed YES/NO proof-output links as
`not-downloaded` records, preserving them for later retry without overwriting
the downloaded 2025 artefacts.

Older-year retry command:

```console
python scripts/collect_termcomp_proofs.py \
  --year-start 2014 \
  --year-end 2024 \
  --jobs 64 \
  --resume \
  --out target/termcomp-proof-corpus
```

The retry attempted all 150,121 older StarExec-backed proof-output URLs. All
failed with `URLError(gaierror(-3, 'Temporary failure in name resolution'))`
for `www.starexec.org` / `starexec.org` in the current environment. The DB
keeps the proof URLs and metadata for later retry.

See `docs/proof-corpus.md` for schema, counts, and extraction details.

## 2026-07-14 DP Component Portfolio Parallelism

Ferrum's DP default strategy was changed so that, after dependency-graph
decomposition, a component-level portfolio is run in parallel:

- `timeout(100ms, subterm)` for projection subterm.
- `timeout(500ms, size-change)` for pure SCT plus reduction-pair-backed SCT.
- The existing reduction-pair portfolio, whose branches already have local
  timeouts: symbol weights, polynomial interpretations, weak/max/rational
  polynomials, matrix interpretations, KBO, and path orders.

The parser now exposes `size-change`, `sizechange`, and `sct` as a separate DP
processor instead of aliasing them to `subterm`. The old combined behavior is
still present internally for regression tests, but the production strategy keeps
subterm and SCT distinct.

Validation:

```console
cargo +1.95.0 fmt
cargo +1.95.0 test --lib --jobs 128
cargo +1.95.0 build --release --jobs 128
```

Full 60s/128-worker TermCOMP 2025 run:

```console
python scripts/termcomp_trs_compare.py \
  --tpdb ../TPDB-ARI \
  --ferrum-profile enhanced \
  --jobs 128 \
  --timeout 60 \
  --run-dir target/termcomp-runs/20260714-component-portfolio-128-60s \
  --details-output target/termcomp-runs/20260714-component-portfolio-128-60s/details.json \
  --output target/termcomp-runs/20260714-component-portfolio-128-60s/summary.md
```

Observed result:

| Category | YES | NO | Certified YES | Certified NO | MAYBE | Timeout | Cert failed |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| TRS Standard | 471 | 170 | 471 | 170 | 55 | 832 | 0 |
| TRS Innermost | 114 | 3 | 114 | 3 | 2 | 247 | 0 |

Compared with `target/termcomp-runs/20260714-174942-full-128-60s-q-iedg`,
the component portfolio gains:

- `TRS_Innermost/AG01_innermost/#4.34.ari` as certified YES.
- `TRS_Innermost/Transformed_CSR_innermost_04/LengthOfFiniteLists_nosorts_noand_GM.ari`
  as certified NO.

The same 128-worker run reports two Standard losses:

- `TRS_Standard/Strategy_removed_AG01/#4.34.ari`
- `TRS_Standard/Zantema_05/jw27.ari`

Both prove with the current release binary when rerun directly under the same
outer strategy. `jw27` writes a CPF immediately in a direct run; the saturated
batch artifact contains a final progress event showing `Termination` finished
but no captured stdout/CPF, so that row is recorded as a high-load harness
artefact rather than a proof-search regression. This should be revisited when
adding cancellation/cooperative stopping for losing parallel branches.

## Q-aware estimated innermost dependency graph, 2026-07-14

Goal: implement the Q-aware estimated innermost dependency graph used under
`innermostLhssRemovalProc`, test it against CeTA on representative CPF proofs,
and run a max-60s TermCOMP 2025 TRS benchmark with 128 workers.

Literature basis checked before implementation:

- Arts and Giesl's dependency-pair method defines the ordinary estimated
  dependency graph using `REN(CAP(t))` unification with the next dependency-pair
  lhs.
- The estimated innermost dependency graph variant uses `CAP(t)` unification
  together with normality side conditions for the instantiated source and
  target call contexts.
- In the DP framework with a non-empty Q context, these normality checks are
  evaluated with respect to Q. Ferrum's Q source here is the active
  `innermostLhssRemovalProc` lhs set.

Implementation:

- In `src/proving/dependency_pairs.rs`, innermost dependency graph estimation
  now dispatches first to a Q-aware estimator whenever an innermost Q context is
  present.
- The Q-aware estimator caps proper rhs subterms rooted by defined symbols,
  unifies the capped rhs with the target DP lhs, and removes the edge if the
  instantiated source lhs or target lhs has a proper subterm that is definitely
  a Q-redex.
- The old guarded-Q path was removed. Without an active Q context, Ferrum keeps
  the existing conservative CeTA-shaped innermost graph behavior.

Focused validation:

```console
cargo +1.95.0 fmt
cargo +1.95.0 test --lib --jobs 128
cargo +1.95.0 build --release --jobs 128
```

Observed result:

```text
152 library tests passed
release build succeeded
```

CPF/CeTA smoke artifacts:

```text
target/q-aware-iedg-ceta-smoke
```

Representative smoke set:

- `TRS_Innermost/AG01_innermost/#4.14.ari`
- `TRS_Innermost/AG01_innermost/#4.16.ari`
- `TRS_Innermost/AG01_innermost/#4.17.ari`
- `TRS_Innermost/AG01_innermost/#4.24.ari`
- `TRS_Innermost/AG01_innermost/#4.25.ari`
- `TRS_Innermost/AG01_innermost/#4.29.ari`
- `TRS_Innermost/Transformed_CSR_innermost_04/MYNAT_nosorts_GM.ari`

All completed YES smoke proofs above were accepted by CeTA. The smoke wrapper
timed out on `#4.15`, `#4.26`, `cade12`, `narrow1`, and `Ex1_GM99_GM` under the
60s proof budget.

Full 60s/128-worker run:

```console
run_dir=target/termcomp-runs/20260714-174942-full-128-60s-q-iedg
python scripts/termcomp_trs_compare.py \
  --tpdb ../TPDB-ARI \
  --ferrum target/release/ferrum \
  --ceta .tools/ceta-relative-bounds \
  --jobs 128 \
  --timeout 60 \
  --category TRS_Standard \
  --category TRS_Innermost \
  --run-dir "$run_dir" \
  --details-output "$run_dir/details.json" \
  --output "$run_dir/summary.md" \
  --progress-interval 10
```

Observed Ferrum results:

| Category | YES | NO | Certified YES | Certified NO | MAYBE | Timeout | Cert failed |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| TRS Standard | 473 | 170 | 473 | 170 | 53 | 832 | 0 |
| TRS Innermost | 113 | 2 | 113 | 2 | 3 | 248 | 0 |

Compared with the 60s cut of
`target/termcomp-runs/20260714-120000-full-128-final/details.json`:

- TRS Standard: no path-level YES/NO changes.
- TRS Innermost: 14 additional certified YES, 1 missing certified YES, no
  certified NO changes.
- The missing innermost YES is
  `TRS_Innermost/AG01_innermost/#4.34.ari`. A single-example rerun with the
  current release binary and `timeout(59s, default)` proved and CeTA-certified
  it in 5.4s, so the full-run miss is attributed to 128-worker contention rather
  than a deterministic proof regression.

## 2026-07-14 merge-regression TermCOMP runs

After merging upstream processor changes, Ferrum was rebuilt and run with 128
workers and a 305 second per-problem harness timeout. The relevant fixes before
the final recorded rows were:

- Close SMT solver stdin after writing scripts, so one-shot SMT encodings do not
  wait for EOF until an external timeout.
- Return from top-level and DP-level parallel strategies when a decisive branch
  succeeds, instead of waiting for losing branches.
- Try the standard/full DP proof before `switchInnermost`; the switch remains a
  fallback.
- Restore CeTA-shaped dependency graph estimation and keep Q-aware innermost
  graph pruning conservative for certification.
- Reject negative constants in weak-polynomial DP certificates; the previous
  `TRS_Innermost/AG01_innermost/#4.25.ari` YES is now `Unknown` rather than an
  uncertified YES.

Final full run:

```console
python scripts/termcomp_trs_compare.py \
  --tpdb ../TPDB-ARI \
  --ferrum target/release/ferrum \
  --ceta .tools/ceta-relative-bounds \
  --jobs 128 \
  --timeout 305 \
  --category TRS_Standard \
  --category TRS_Innermost \
  --run-dir target/termcomp-runs/20260714-120000-full-128-final \
  --details-output target/termcomp-runs/20260714-120000-full-128-final/details.json \
  --output target/termcomp-runs/20260714-120000-full-128-final/summary.md \
  --progress-interval 10
```

Rows from that run:

| Category | YES | Certified YES | NO | Certified NO | MAYBE | Timeout | Error | Cert failed |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| TRS Standard | 475 | 475 | 180 | 180 | 94 | 779 | 0 | 0 |
| TRS Innermost | 101 | 101 | 5 | 5 | 14 | 246 | 0 | 0 |

## One-shot max-polynomial DP processor and processor inventory

Ferrum now has an explicit DP-only `max-polo` / `max-poly` processor instead of
hiding max-polynomial behavior inside `weak-poly`.

## Mixed-status DP path orders

Ferrum's DP path-order backend now synthesizes per-symbol recursive path-order
statuses in the one-shot SMT query. The SMT model contains:

- one precedence rank per symbol;
- one argument-filter choice per symbol;
- one status choice per symbol, with `0` meaning multiset/RPO status and `1`
  meaning lexicographic/LPO status.

Accepted candidates are still independently checked by Ferrum before proof
construction. CPF 3 export records the resulting per-symbol statuses in the
`statusPrecedence` entries. Existing all-RPO/all-LPO calls remain wrappers
around the same mixed-status checker.

The Q-aware innermost guard remains conservative: filtered Q LHS patterns must
be variables, and collapsing filters for unmarked symbols must agree with their
marked DP symbols. This keeps accepted proofs certifiable while leaving broader
literature-backed Q-RPO/Q-LPO compatibility as future work.

After a DP reduction-pair deletion, Ferrum proves the residual component by
re-entering the configured DP strategy. In the default strategy this starts
with dependency-graph decomposition, so SCCs are recomputed before subterm,
size-change, path orders, KBO, and polynomial processors are retried.

## Timeout/Solved Chart

The timeout sensitivity chart for the final 128-worker TermCOMP 2025 run is
generated from `target/termcomp-runs/20260714-120000-full-128-final/details.json`
with:

```console
python scripts/plot_timeout_solved_stack.py \
  target/termcomp-runs/20260714-120000-full-128-final/details.json \
  --svg docs/termcomp-2025-timeout-solved-stack.svg \
  --csv docs/termcomp-2025-timeout-solved-stack.csv
```

The SVG is a stacked bar chart with timeout on the x-axis and solved examples
on the y-axis, split into certified YES and certified NO counts. The CSV stores
the exact data used for the chart.

- The processor synthesizes a max of bounded affine polynomials for each symbol
  in one QF_NIA SMT query. There is no candidate-enumeration fallback.
- The accepted fragment uses nonnegative constants and coefficients, so CPF 3
  can emit the native `<maxPoly>` reduction pair.
- Ferrum rechecks the returned model before producing a proof. The current
  checker is sound but conservative: every RHS affine branch must be dominated
  by some LHS branch, and strictness requires strict constant progress in the
  dominating branch.
- `weak-poly` remains an ordinary polynomial processor with conservative guards;
  it no longer smuggles max semantics into CPF `<polynomial>` certificates.
- CPF 3 export now supports `<maxPoly>` for DP reduction-pair proofs.

Validation:

```console
cargo check
cargo test parses_dp_strategy_language --quiet
cargo test max_polynomial --quiet
```

On this machine, `.tools/ceta-relative-bounds` is installed, so the `max_polynomial` test filter
also ran the optional CeTA smoke test for the generated CPF 3 max-polynomial DP
certificate.

The current processor inventory and improvement roadmap is documented in
`docs/processors-status.md`.

## Strategy-only processor configuration

Ferrum no longer exposes top-level processor tuning flags for polynomial/KBO
search. Bounds and processor choices belong in `--strategy`, for example
`--strategy 'timeout(60s, parallel(nontermination | termination))'` or
`--strategy 'poly(const=2, coeff=2, symbols=25, arity=3); dp'`.

The removed top-level symbol-weight proof path has not been kept as an alias or
compatibility shim. At the TRS level, use monotone polynomial rule removal or
KBO rule removal. DP-level `weights` remains a separate DP component processor
inside `dp(...)`.

## Retired legacy top-level subterm preview

The old fallback `SubtermOrderProcessor` was removed. It only ran after the main
termination branch had already tried dependency pairs, and the real subterm /
size-change reasoning now lives in the certified DP strategy. The unused
`ProofStep::SubtermOrder` output variant and CLI step label were removed as
well.

## 2026-07-13 Full TermCOMP 2025 TRS Rerun

Command:

```console
python3 scripts/termcomp_trs_compare.py \
  --jobs 8 \
  --timeout 60 \
  --progress-interval 10 \
  --output docs/termcomp-2025-trs-comparison.md
```

Artifacts:

- `target/termcomp-runs/20260713-065307`
- `docs/termcomp-2025-trs-comparison.md`

Observed Ferrum results from that run:

| Set | Total | Ferrum YES | Certified YES | Ferrum NO | Certified NO | MAYBE | Timeout | Cert failed |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| TRS Standard | 1528 | 383 | 382 | 149 | 149 | 453 | 543 | 1 |
| TRS Innermost | 366 | 93 | 93 | 2 | 2 | 89 | 182 | 0 |

Timeout follow-up:

- The run used the external Python subprocess timeout as the only whole-example
  wall-clock budget.
- Ferrum's local DP processor timeouts bounded individual strategy nodes, but
  recursive DP components could repeatedly spend those local budgets until the
  harness killed the process.
- Ferrum now has a deadline-aware DP entry point,
  `prove_dependency_pairs_with_deadline`, and the TermCOMP comparison harness
  wraps the default top-level strategy as `timeout(timeout-1s, default)` when no
  explicit strategy is supplied.

Certification follow-up:

- The single Standard certification failure was
  `TRS_Standard/Secret_05_TRS/tpa2`.
- Ferrum emitted a negative-constant polynomial removal below an innermost
  usable-rules processor. CeTA rejected the CPF because the ordinary polynomial
  interpretation did not orient the DP problem in that proof context.
- Ferrum now rejects negative-constant weak-polynomial removals when usable
  rules or a non-empty innermost Q context are present, until an explicit CPF
  proof shape for that stronger semantics is implemented.
- A targeted rerun of `tpa2` with the patched binary returns `Unknown` instead
  of an uncertifiable `YES`.

Verification commands after the fixes:

```console
cargo fmt -- --check
cargo test parses_top_level_strategy_language --quiet
cargo test weak_polynomial --quiet
cargo test ceta_certifies_cpf3_negative_constant_polynomial_dp_certificate_when_available --quiet
cargo clippy -- -D warnings
cargo build --release
```

## Size-change reduction-pair context audit

Date: 2026-07-12.

Scope:

- Ferrum already had a DP size-change processor:
  - pure subterm/projection and generalized size-change graphs;
  - a polynomial-backed size-change fallback exported as CPF
    `<sizeChangeProc><reductionPair>...`.
- The polynomial-backed fallback was audited for the same correctness boundary
  as ordinary DP reduction-pair processors.

Change:

- Standard/full TRS polynomial size-change now checks the reduction pair against
  the full TRS rule context, not just the DP usable-rule subset.
- Innermost polynomial size-change keeps using the innermost/Q-compatible usable
  context when the Q-minimality guard succeeds.
- The processor stats now count the rules discharged by the size-change
  reduction pair.

Regression coverage:

- `polynomial_size_change_handles_non_subterm_decrease` covers the innermost
  usable-context case.
- `standard_polynomial_size_change_checks_full_rule_context` asserts that the
  standard/full case carries all TRS rules into the reduction-pair obligation.
- `cargo test size_change --quiet` passed after the change.

## SAT-backed matrix-interpretation search

Date: 2026-07-12.

Change:

- DP matrix interpretations now use a structural QF_BV encoding. Z3/cvc5
  bit-blasts this bounded bit-vector problem internally instead of Ferrum
  enumerating local assignments.
- The older hand-picked matrix enumerator and the intermediate local-assignment
  SAT encoder were removed from this processor.
- The encoding declares one bounded bit-vector variable for every vector
  constant entry and matrix coefficient entry.
- Weak usable/context-rule constraints and weak DP-pair constraints are encoded
  as bit-vector arithmetic over matrix/vector products and unsigned
  comparisons.
- Each DP pair gets a strictness literal, and the SAT instance requires at
  least one strict pair so the processor removes a non-empty subset.
- Accepted SAT models are still rechecked by Ferrum's ordinary
  `checked_component_removal_by_matrix` implementation before a proof is
  produced. CPF export remains the concrete matrix interpretation that CeTA
  checks.
- Accepted bit-vector models are still rechecked by Ferrum's ordinary
  unbounded-integer matrix checker before a proof is produced.

Regression coverage:

- `sat_matrix_search_synthesizes_matrix_candidate` checks that the SAT path
  produces a trusted removable matrix interpretation.
- `matrix_bv_script_uses_bounded_bitvector_entries` checks that matrix entries
  are declared and bounded as bit-vectors, not as canned matrix choices.
- `cargo test matrix --quiet` passed after the change.
- A CLI smoke proof with `dp(matrix(dim=1,const=1,coeff=1,symbols=4,arity=1))`
  produced a SAT-backed matrix interpretation and `.tools/ceta-relative-bounds` certified the
  emitted CPF 3 file.

## Bit-blasted POLO/MATO search

Date: 2026-07-13.

Literature basis:

- Fuhs et al., "SAT Solving for Termination Analysis with Polynomial
  Interpretations", SAT 2007.
- Endrullis, Waldmann, and Zantema, "Matrix Interpretations for Proving
  Termination of Term Rewriting", 2008.

Change:

- DP `sat-poly` / POLO no longer uses Ferrum's local-assignment CNF expansion.
  It emits a QF_BV formula for bounded polynomial interpretations: constants
  and coefficients are bit-vector variables, term interpretations are shared
  bit-vector arithmetic expressions, and weak/strict orientation constraints are
  unsigned bit-vector comparisons over the affine forms.
- DP `matrix` / MATO likewise emits a QF_BV formula over matrix entries and
  vector constants. Matrix-vector and matrix-matrix products are represented
  structurally with bit-vector addition/multiplication.
- Both processors parse the bit-vector model, then recheck the concrete
  interpretation with Ferrum's existing mathematical checker before accepting a
  proof. This recheck prevents bit-vector overflow artifacts from becoming
  unsound certificates.
- The previous local-assignment limits no longer apply to POLO or MATO. Ferrum
  computes a structural bit-width upper bound from the configured
  coefficient/constant domains and term shapes. There is no arbitrary upper
  cap on this width; the SMT-LIB formula still uses a concrete bit-vector width
  because QF_BV terms are typed. Ferrum parses wide bit-vector model literals
  as long as the bounded model values fit in Ferrum's proof representation.

## Weak/max-polynomial search without SAT enumeration

Date: 2026-07-13.

Change:

- The previous finite-domain SAT/local-assignment fallback for `weak-poly` was
  removed.
- The DP `weak-poly` processor now only accepts candidates synthesized by the
  structural SMT path and then rechecked by
  `checked_component_removal_by_weak_polynomial`.
- No sample-valuation SAT pruning, local polynomial assignment expansion, or
  `SAT_POLYNOMIAL_LOCAL_ASSIGNMENT_LIMIT` remains in the prover source.
- Proof export remains the same concrete polynomial interpretation in CPF, so
  CeTA checks the resulting proof independently of the synthesis backend.

Regression coverage:

- `weak_polynomial_synthesis_does_not_use_sat_enumeration_after_affine_smt_fails`
  verifies that Ferrum no longer accepts the old SAT-enumerated max-polynomial
  fallback when the structural affine SMT path fails.

## CeTA-Compatible Standard Dependency Graph Matching

Date: 2026-07-13.

We revisited the dependency graph decomposition implementation against the
published dependency-pair definitions and CeTA's generated checker code. The
local source files used as the executable definitions were:

- `.tools/CeTA-3.9/thys/Code/For_Module_Merge/Dependency_Graph_Impl.hs`
- `.tools/CeTA-3.9/thys/Code/For_Module_Merge/Tcap_Impl.hs`
- `.tools/CeTA-3.9/thys/Code/For_Module_Merge/Tcap_Dpp_Impl.hs`
- `.tools/CeTA-3.9/thys/Code/For_Module_Merge/Gtcap_Impl.hs`
- `.tools/CeTA-3.9/thys/Code/For_Module_Merge/Ground_Context_Impl.hs`

The important implementation correction is in ground-context matching.
CeTA's `Ground_Context.match` allows a non-hole ground context to match a term
variable and then merges the context requirements for repeated occurrences of
that variable. Ferrum's previous structural-only match could incorrectly omit
dependency graph edges, which led to CeTA rejections of `depGraphProc`
decompositions.

Ferrum now uses the CeTA-style `tcapRM`, reverse `tcapRM`, ground-context
matching, and `gtcapRM` non-reachability checks for standard TRS dependency
graph decomposition. For innermost TRSs, Ferrum currently keeps the prior
conservative supergraph behavior and adds CeTA-style edges, so existing
certified innermost proofs are preserved while avoiding omitted-edge
certification failures.

Focused regression-slice command:

```console
python scripts/termcomp_trs_compare.py \
  --ferrum target/release/ferrum \
  --ceta .tools/ceta-relative-bounds \
  --jobs 128 \
  --timeout 305 \
  --category TRS_Standard \
  --category TRS_Innermost \
  --from-details target/termcomp-runs/recovery-81-selector.json \
  --include-status unknown \
  --run-dir target/termcomp-runs/recovery-81-ceta-match \
  --details-output target/termcomp-runs/recovery-81-ceta-match/details.json \
  --output target/termcomp-runs/recovery-81-ceta-match/summary.md \
  --progress-interval 5
```

Observed focused-slice result:

| Slice | Total | YES | Certified YES | MAYBE | Timeout | Cert failed |
| --- | ---: | ---: | ---: | ---: | ---: | ---: |
| TRS Standard | 61 | 11 | 11 | 49 | 1 | 0 |
| TRS Innermost | 20 | 3 | 3 | 17 | 0 | 0 |

Artifacts:

- `target/termcomp-runs/recovery-81-ceta-match`
- `target/termcomp-runs/recovery-81-ceta-match/details.json`
- `docs/recovery-20260713-regression-slice.md`

## Matrix SAT Recovery and CLI Cleanup

Date: 2026-07-14.

Ferrum's matrix interpretation processor no longer uses the historical
candidate-walk fallback. It now first builds a bit-blasted SAT encoding for the
bounded matrix interpretation class requested by the active DP strategy:

- constants and matrix entries are represented as bounded unsigned bit-vectors;
- matrix/vector arithmetic is compiled to Boolean circuits;
- weak and strict reduction-pair constraints are asserted directly in SAT;
- any SAT model is reconstructed as an ordinary matrix interpretation and then
  validated by Ferrum's existing reduction-pair checker before a proof is
  emitted.

Regression target:

```console
target/release/ferrum prove ../TPDB-ARI/TRS_Standard/Zantema_05/jw02.ari \
  --cpf /tmp/ferrum-jw02.cpf3.xml \
  --cpf-mode cpf30 \
  --no-top-level-llm

.tools/ceta-relative-bounds /tmp/ferrum-jw02.cpf3.xml
```

Observed result:

```text
status: Terminating
CERTIFIED
```

Focused 81-example regression slice after the matrix SAT change:

```console
python scripts/termcomp_trs_compare.py \
  --ferrum target/release/ferrum \
  --ceta .tools/ceta-relative-bounds \
  --jobs 128 \
  --timeout 305 \
  --category TRS_Standard \
  --category TRS_Innermost \
  --from-details target/termcomp-runs/recovery-81-selector.json \
  --include-status unknown \
  --run-dir target/termcomp-runs/recovery-81-matrix-sat \
  --details-output target/termcomp-runs/recovery-81-matrix-sat/details.json \
  --output target/termcomp-runs/recovery-81-matrix-sat/summary.md \
  --progress-interval 5
```

Observed focused-slice result:

| Slice | Total | YES | Certified YES | MAYBE | Timeout | Cert failed |
| --- | ---: | ---: | ---: | ---: | ---: | ---: |
| TRS Standard | 61 | 28 | 28 | 33 | 0 | 0 |
| TRS Innermost | 20 | 3 | 3 | 17 | 0 | 0 |

The CLI proof-search tuning flags that duplicate strategy-language parameters
were removed from `prove`, `tpdb prove`, and `tpdb certify`. Current proof
search should be configured through `--strategy` and strategy atoms such as
`poly(...)`, `matrix(...)`, `kbo(...)`, and timeouts. Backend solver selection
uses internal defaults.

Current `ferrum prove --help` proof-search options are:

```text
--cpf <CPF>
--cpf-mode <CPF_MODE>
--llm-proposals <LLM_PROPOSALS>
--llm-model-dir <LLM_MODEL_DIR>
--llm-backend <LLM_BACKEND>
--no-top-level-llm
--llm-iterations <LLM_ITERATIONS>
--strategy <STRATEGY>
```

Verification commands:

```console
cargo +1.95.0 fmt
cargo +1.95.0 check --jobs 128
cargo +1.95.0 test --jobs 128 matrix_sat_synthesizes_jw02_component
cargo +1.95.0 build --release --jobs 128
```

## Linux Dependency Installation, 2026-07-13

The Linux `ferrum` conda environment was updated to include the runtime tools
used by proof search, certification, and local LLM serving.

Installed in the active `ferrum` environment:

```console
conda install -c conda-forge -y ffmpeg libxml2
python -m pip install 'fastapi<0.137' mlx mlx-lm pydantic \
  transformers==5.12.1 uvicorn vllm==0.25.0 z3-solver==4.15.4.0 cvc5==1.3.4
```

The `z3` executable is provided by `z3-solver`. The `cvc5` Python package
provides bindings but not the command-line binary, so the Linux x86_64 static
cvc5 binary was installed into the environment's `bin/` directory.

CeTA 3.9 is not a conda package. It was built from the official source archive
and installed as:

```text
.tools/ceta-relative-bounds
.tools/cpf3/cpf3/xml/cpf2_to_3.sh
.tools/cpf3/cpf3/xml/cpf3.xsd
```

The current Linux LLM backend is `vllm`. The MLX packages install on Linux, but
`mlx_lm` does not load successfully here because the MLX runtime is intended
for Apple Silicon.

## Full TermCOMP 2025 TRS Run with 128 Workers, 2026-07-13

Command:

```console
python3 scripts/termcomp_trs_compare.py \
  --tpdb ../TPDB-ARI \
  --ferrum target/release/ferrum \
  --ceta .tools/ceta-relative-bounds \
  --jobs 128 \
  --timeout 60 \
  --progress-interval 5 \
  --run-dir target/termcomp-runs/20260713-192105-full-128 \
  --details-output target/termcomp-runs/20260713-192105-full-128/details.json \
  --output docs/termcomp-2025-trs-comparison.md
```

Machine topology observed before the run summary:

```text
AMD EPYC 9655 96-Core Processor
2 sockets, 96 cores per socket, 2 threads per core
384 logical CPUs, 192 physical cores, 2 NUMA nodes
```

Observed local Ferrum rows:

| Set | Problems | YES | NO | Certified YES | Certified NO | MAYBE | Timeout | Error | Cert failed |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| TRS Standard | 1528 | 335 | 147 | 335 | 147 | 485 | 561 | 0 | 0 |
| TRS Innermost | 366 | 74 | 1 | 74 | 1 | 63 | 228 | 0 | 0 |

The run retained 1894 per-example artifact directories under
`target/termcomp-runs/20260713-192105-full-128`. Compared with the previous
local table, this 128-worker run had no certificate failures but substantially
more timeouts. The likely cause is throughput contention from running 128
independent Ferrum/CeTA/solver subprocess workloads under a fixed 60-second
per-example timeout.

## Certification-gap audit, 2026-07-12

Source run:

- Full TermCOMP 2025 TRS Standard/Innermost run:
  `target/termcomp-runs/20260712-152913`.
- Initial totals from that run:
  - `TRS_Standard`: 350 YES, 326 certified YES, 24 YES certificate failures.
  - `TRS_Innermost`: 102 YES, 91 certified YES, 11 YES certificate failures.
- Focused old-gap rerun artifacts:
  - `/tmp/ferrum-cert-gap-rerun-release`
  - `/tmp/ferrum-cert-gap-survivors-after-fixes`

Root causes found:

- Innermost usable-rule/Q context was incorrectly shrunk after recursive DP
  steps. This omitted closure rules required by CeTA, for example `pred` in
  `TRS_Standard/AG01/#3.2.ari`. Ferrum now keeps the full Q context through
  recursive DP proof search.
- Full/standard DP reduction-pair steps checked an empty rule context when no
  usable-rules processor was active. Ferrum now checks reduction pairs against
  all TRS rules for standard/full DP problems, and against the usable/Q context
  for innermost DP problems.
- The innermost dependency-graph estimator omitted edges that CeTA's graph
  estimator keeps. Ferrum now keeps every edge found by the standard CAP-based
  dependency-graph estimate, using innermost refinements only as additional
  edges.
- CPF export classified every matrix interpretation as a monotone reduction
  pair. Ferrum now emits matrix interpretations through the generic reduction
  pair processor unless stronger monotonicity is proved.

Focused post-fix result on the 10 examples that still emitted rejected
certificates after the first usable-rule fix:

| Result | Count | Examples |
| --- | ---: | --- |
| Certified | 3 | `Endrullis_06/pair2simple1.ari`, `SK90/4.41.ari`, `Mixed_TRS/motivation.ari` |
| Unknown | 6 | `AProVE_04/IJCAR_1.ari`, `Waldmann_06/jwteparla1.ari`, `Waldmann_06/jwteparla2.ari`, `Transformed_CSR_04/Ex4_7_37_Bor03_Z.ari`, `AG01/#3.53b.ari`, `Mixed_innermost/innermost3.ari` |
| Timeout | 1 | `Mixed_innermost/run_again1.ari` with a 180s focused timeout |
| CeTA rejected | 0 | none in this focused survivor set |

Interpretation:

- The certification gap was not one bug. Some old YES results were valid once
  CPF/rule-context emission was fixed; others were invalid proof-search claims
  and are now correctly reported as `Unknown` or timeout.
- The remaining difference between YES and certified YES in a future full run
  should be treated as a fresh audit target, not assumed to be the same
  rejected-proof set.

## Innermost Dependency Graph Source-normality Refinement

After the certified top-level rule-removal work, Ferrum reran the old
non-timeout `TRS_Innermost` unknowns from
`/tmp/ferrum-innermost-non-timeout-after-direct-pruning-disabled.json`:

```console
python3 scripts/termcomp_trs_compare.py \
  --category TRS_Innermost \
  --jobs 8 \
  --timeout 60 \
  --from-details /tmp/ferrum-innermost-non-timeout-after-direct-pruning-disabled.json \
  --include-status unknown \
  --output /tmp/ferrum-innermost-current-old-unknowns.md \
  --details-output /tmp/ferrum-innermost-current-old-unknowns.json \
  --run-dir target/termcomp-runs/innermost-current-old-unknowns \
  --progress-interval 5
```

Observed result on those 143 old unknowns:

```text
yes=24 cert_yes=24 maybe=115 timeout=4 error=0 cert_failed=0
```

The remaining AProVE-certified misses were again dominated by DP graph,
usable-rules, innermost-LHS, and size-change/subterm proof shapes. A small
AProVE proof for `TRS_Innermost/AG01_innermost/#4.14.ari` showed the immediate
gap: AProVE decomposes the two dependency pairs into singleton components, then
closes `g#(s(x)) -> g#(x)` by `sizeChangeProc`/`subtermCriterion`. Ferrum kept
a spurious self-edge on the other component,
`f#(g(x), s(0)) -> f#(g(x), g(x))`.

Implementation:

- The innermost dependency graph already used precise RHS/LHS unification
  without CAP when all proper defined RHS calls are known harmless.
- That source-normality refinement had accidentally been restricted to
  single-rule TRSs.
- The restriction was removed: when every proper defined RHS subterm is either
  a source-LHS subterm or otherwise innermost-normal under the existing guard,
  Ferrum may use the more precise innermost dependency edge check for
  multi-rule systems too.
- The redex-overlap test in that guard now standardizes the candidate RHS
  subterm and each rule LHS apart before unification. Without this, a term such
  as `half(s(x))` could fail to overlap `half(s(s(x)))` only because both sides
  happened to use the variable name `x`.
- The guard is target-aware: a proper RHS defined call that is not known normal
  blocks direct graph precision only when the target DP has structure at that
  position. If the target has a variable there, the call cannot create the
  missing edge. This recovers the certified `AG01_innermost/#4.15.ari` split
  while still keeping the `#4.29.ari` half/times edge required by CeTA.
- Target variables are considered harmless only when they are linear in the
  target LHS. `AG01_innermost/#4.25.ari` exposed the repeated-variable case:
  omitting the self-edge for `f#(x,x) -> f#(g(x),x)` produced a decomposition
  that CeTA rejected. Ferrum now keeps that edge and proves the example
  instead by an innermost `rewritingProc`, which CeTA certifies.
- Existing CeTA-driven graph safety regressions still pass, including the
  cases that keep edges for source-normality, target-normality, variable-redex
  uncertainty, and single-pair self-edge uncertainty.

Targeted checks:

```console
cargo test innermost_dependency_graph_ --quiet

cargo run --quiet -- prove \
  ../TPDB-ARI/TRS_Innermost/AG01_innermost/#4.14.ari \
  --strategy termination \
  --cpf /tmp/ferrum-414.cpf3.xml \
  --cpf-mode cpf30 \
  --no-top-level-llm

.tools/ceta-relative-bounds /tmp/ferrum-414.cpf3.xml

cargo run --quiet -- prove \
  ../TPDB-ARI/TRS_Innermost/AG01_innermost/#4.15.ari \
  --strategy termination \
  --cpf /tmp/ferrum-415.cpf3.xml \
  --cpf-mode cpf30 \
  --no-top-level-llm

.tools/ceta-relative-bounds /tmp/ferrum-415.cpf3.xml

cargo run --quiet -- prove \
  ../TPDB-ARI/TRS_Innermost/AG01_innermost/#4.16.ari \
  --strategy termination \
  --cpf /tmp/ferrum-416.cpf3.xml \
  --cpf-mode cpf30 \
  --no-top-level-llm

.tools/ceta-relative-bounds /tmp/ferrum-416.cpf3.xml
```

Observed result:

```text
#4.14.ari: status: Terminating, CERTIFIED
#4.15.ari: status: Terminating, CERTIFIED
#4.16.ari: status: Terminating, CERTIFIED
```

Certification guardrail:

- An ad hoc AG01-focused probe exposed `#4.29.ari` as a useful negative
  regression. The over-precise graph omitted CeTA's required edge from
  `if_times#(true, s(x), y) -> times#(half(s(x)), y)` to
  `times#(s(x), y) -> if_times#(even(s(x)), s(x), y)`.
- The standardized-apart redex-overlap fix keeps this edge, so Ferrum no
  longer reports the previous uncertifiable YES for `#4.29.ari`; it returns
  `Unknown` until a stronger, certifiable AProVE-style proof is implemented.
- Regression coverage includes
  `innermost_dependency_graph_keeps_ag01_4_29_half_times_edge_for_ceta`.

`#4.17.ari` was subsequently solved by the innermost DP rewriting/usable-rule
strengthening described below, so this graph-specific section now leaves
`#4.29.ari` as the relevant AG01 guardrail for over-precise graph estimates.

## Explicit-Cap Top-Level Rule-Removal Follow-Up

The strategy-language extension that allows `poly(c,a,s,m)` and related DP
forms was tested against the top-level `ruleRemoval` misses from the
TermCOMP/AProVE innermost proof-gap slice.

Focused run:

- Target selection: current non-timeout innermost unknowns whose AProVE proof
  features included top-level `ruleRemoval` and did not include `dpTrans`.
- Strategy:

```text
poly(2,2,17,3);
kbo(2,17);
dp(graph; subterm; poly(2,2,17,3); sat-poly(2,2,17,3); smt-poly(2,2,17,3); kbo(2))
```

- Run directory:
  `target/termcomp-runs/top-level-rule-removal-explicit-poly-caps`
- Per-instance timeout: 60 seconds.
- Result: 18 selected examples, 15 Ferrum YES, 15 CeTA-certified YES, 2
  unknown, 1 timeout, 0 certification failures.

Newly certified examples in this slice include:

- `TRS_Innermost/Transformed_CSR_innermost_04/Ex1_2_Luc02c_C.ari`
- `TRS_Innermost/Transformed_CSR_innermost_04/Ex4_4_Luc96b_C.ari`
- `TRS_Innermost/Transformed_CSR_innermost_04/Ex5_Zan97_GM.ari`
- `TRS_Innermost/Transformed_CSR_innermost_04/ExIntrod_GM04_GM.ari`
- `TRS_Innermost/Transformed_CSR_innermost_04/PALINDROME_nosorts_iGM.ari`
- `TRS_Innermost/Transformed_CSR_innermost_04/PEANO_nosorts_iGM.ari`

Remaining cases:

- `TRS_Innermost/Transformed_CSR_innermost_04/Ex15_Luc98_GM.ari` timed out
  under naive large-cap enumeration. AProVE's proof uses several large
  polynomial rule-removal steps over 17 symbols with arity up to 3, so this was
  a synthesis/search problem rather than a proof-language expressiveness
  problem. The later SMT-backed top-level polynomial search resolves this case.
- `TRS_Innermost/Transformed_CSR_innermost_04/LengthOfFiniteLists_nokinds_GM.ari`
  remains unknown.
- `TRS_Innermost/Transformed_CSR_innermost_04/MYNAT_nosorts_GM.ari` remains
  unknown; the inspected AProVE proof uses top-level RPO with argument
  filtering followed by KBO, which remains outside Ferrum's current top-level
  policy.

## SMT-backed top-level polynomial rule removal

Ferrum now has an explicit top-level SMT polynomial strategy atom:

```text
smt-poly(c,a,s,m)
```

Aliases `smt-polynomial(...)`, `smt(...)`, and bare `smt-poly`/`smt` forms are
accepted. The SMT solver is used only as an untrusted candidate generator:
Ferrum asks `z3` or `cvc5` for a bounded linear polynomial interpretation, then
accepts the result only through the existing checked top-level polynomial
rule-removal processor. The emitted CPF is still the ordinary certified
polynomial rule-removal proof; no SMT proof is trusted by CeTA.

Focused rerun:

- Target selection: the same 18 top-level `ruleRemoval` non-timeout innermost
  unknowns used in the explicit-cap run.
- Strategy:

```text
smt-poly(2,2,17,3);
poly(2,2,17,3);
kbo(2,17);
dp(graph; subterm; smt-poly(2,2,17,3); sat-poly(2,2,17,3); kbo(2))
```

- Run directory:
  `target/termcomp-runs/top-level-rule-removal-smt-poly`
- Per-instance timeout: 60 seconds.
- Result: 18 selected examples, 16 Ferrum YES, 16 CeTA-certified YES, 2
  unknown, 0 certification failures.

Newly certified compared with the explicit-cap run:

- `TRS_Innermost/Transformed_CSR_innermost_04/Ex15_Luc98_GM.ari`

Remaining cases:

- `TRS_Innermost/Transformed_CSR_innermost_04/LengthOfFiniteLists_nokinds_GM.ari`
  remained unknown in the 17-symbol focused run because the example has 20
  symbols.
- `TRS_Innermost/Transformed_CSR_innermost_04/MYNAT_nosorts_GM.ari` remains
  unknown; the inspected AProVE proof uses top-level RPO with argument
  filtering, which Ferrum still does not enable at the whole-TRS level.

Follow-up:

- The default YES/termination branch now includes a bounded SMT-backed
  top-level polynomial rule-removal pass with cap `(constant=2, coefficient=2,
  symbols=25, arity=3)`. The brute-force polynomial defaults remain small; this
  larger cap is used only for the external-SMT candidate generator and still
  passes through Ferrum's local reduction-pair checker before proof acceptance.
- `TRS_Innermost/Transformed_CSR_innermost_04/LengthOfFiniteLists_nokinds_GM.ari`
  is now proved by plain `--strategy termination` and CeTA-certified:

```console
cargo run --quiet -- prove \
  ../TPDB-ARI/TRS_Innermost/Transformed_CSR_innermost_04/LengthOfFiniteLists_nokinds_GM.ari \
  --strategy termination \
  --cpf /tmp/ferrum-length-default-smt.cpf3.xml \
  --cpf-mode cpf30 \
  --no-top-level-llm

./.tools/ceta-relative-bounds /tmp/ferrum-length-default-smt.cpf3.xml
```

Observed result:

```text
status: Terminating
CERTIFIED
```

- An intermediate focused rerun with the default `termination` branch is stored in
  `target/termcomp-runs/top-level-rule-removal-default-smt-poly`.
- Result: 18 selected examples, 17 Ferrum YES, 17 CeTA-certified YES, 1
  unknown, 0 certification failures.
- The only remaining unknown in this intermediate focused slice was
  `TRS_Innermost/Transformed_CSR_innermost_04/MYNAT_nosorts_GM.ari`, whose
  AProVE proof starts with top-level RPO plus a collapsing argument filter for
  `mark`.

## Certified top-level path-order rule removal

Ferrum now has a YES-branch top-level path-order rule-removal processor for
mixed-status recursive path orders with argument filtering. The implementation
is currently intentionally narrow and proof-guided:

- it generates checked candidates including the AProVE-style filter that
  collapses `mark(x)` to `x`;
- it supports quasi-precedence classes for activated/unactivated symbol
  families such as `a__plus`/`plus`;
- it supports per-symbol lexicographic or multiset status and emits the same
  mixed `<statusPrecedence>` shape in CPF 3;
- it accepts a step only after Ferrum locally checks weak orientation of every
  rule and strict orientation of at least one removed rule.

Smoke check:

```console
cargo run --quiet -- prove \
  ../TPDB-ARI/TRS_Innermost/Transformed_CSR_innermost_04/MYNAT_nosorts_GM.ari \
  --strategy termination \
  --cpf /tmp/ferrum-mynat-rpo.cpf3.xml \
  --cpf-mode cpf30 \
  --no-top-level-llm

./.tools/ceta-relative-bounds /tmp/ferrum-mynat-rpo.cpf3.xml
```

Observed result:

```text
status: Terminating
CERTIFIED
```

Focused rerun:

- Target selection: the same 18 top-level `ruleRemoval` non-timeout innermost
  unknowns.
- Strategy: default `termination` branch.
- Run directory:
  `target/termcomp-runs/top-level-rule-removal-default-smt-rpo`
- Per-instance timeout: 60 seconds.
- Result: 18 selected examples, 18 Ferrum YES, 18 CeTA-certified YES, 0
  unknown, 0 certification failures.

## Certified top-level KBO rule removal

Motivation:

- The TermCOMP/AProVE proof inspection for innermost misses showed several
  certified `ruleRemoval` proofs using `<knuthBendixOrder>` without
  `<argumentFilter>`.
- Representative inspected AProVE proof files:
  - `/tmp/ferrum-termcomp-innermost-proofs/benchmark_102.txt`
    (`Ex15_Luc98_GM`): nested rule removals with KBO and polynomial
    interpretations, no argument filter.
  - `/tmp/ferrum-termcomp-innermost-proofs/benchmark_362.txt`
    (`PEANO_nosorts_GM`): one top-level KBO rule-removal proof, no argument
    filter.
  - `/tmp/ferrum-termcomp-innermost-proofs/benchmark_344.txt`
    (`PALINDROME_nosorts_GM`): one top-level KBO rule-removal proof, no
    argument filter.
  - `/tmp/ferrum-termcomp-innermost-proofs/benchmark_308.txt`
    (`MYNAT_nosorts_GM`): outer RPO rule-removal proof with argument
    filtering, then nested KBO without argument filtering.

Implementation notes:

- Ferrum now has top-level KBO rule removal for the YES/termination branch.
  It is reached through `ProveStrategyProcessor::Termination` only.
- The default top-level strategy remains `parallel(no | yes)`. The NO branch
  uses `nontermination(...)`; it does not call the TRS-level KBO rule-removal
  processor. This preserves the policy that TRS-level incomplete processing is
  confined to the YES branch of the default strategy.
- No whole-TRS argument filtering was added. CPF output for top-level KBO
  passes `None` for the argument filter and emits no `<argumentFilter>`.
- KBO weight search now permits zero weights under the admissible KBO side
  conditions used by the checker and CeTA certificates: constants stay
  positive, unary zero-weight symbols must be maximal in the precedence, and
  non-constant symbols of arity greater than one may have weight zero.
- A checked heuristic precedence candidate is tried before brute-force
  precedence enumeration. The heuristic prioritizes `mark`, activated symbols
  such as `a__...`, marked DP symbols, then other non-constants and constants.
  It is only a search hint; Ferrum still accepts a candidate only after the
  local KBO comparison checker verifies every removed rule.

Smoke check:

```console
cargo build --release

target/release/ferrum prove \
  ../TPDB-ARI/TRS_Innermost/Transformed_CSR_innermost_04/PEANO_nosorts_GM.ari \
  --strategy termination \
  --cpf /tmp/ferrum-peano-kbo-zero.cpf3.xml \
  --cpf-mode cpf30 \
  --no-top-level-llm

./.tools/ceta-relative-bounds /tmp/ferrum-peano-kbo-zero.cpf3.xml
```

Observed result:

```text
status: Terminating
step: SynthesizedKbo { precedence: ["mark", "a__and", "a__plus", "and", "plus", "s", "tt", "|0|"], weights: [("a__and", 0), ("a__plus", 0), ("and", 0), ("mark", 0), ("plus", 0), ("s", 1), ("tt", 1), ("|0|", 1)] }
CERTIFIED
```

Focused target run:

- Target selection: current non-timeout innermost unknowns whose AProVE proof
  features included `ruleRemoval` and `knuthBendixOrder`, but not `dpTrans`.
- Source detail file:
  `/tmp/ferrum-innermost-non-timeout-after-direct-pruning-disabled.json`
- AProVE feature file:
  `/tmp/ferrum-termcomp-innermost-proofs/miss_features.csv`
- Run directory:
  `target/termcomp-runs/top-level-kbo-rule-removal-targets-after-zero-weight-heuristic`
- Result: 16 selected examples, 2 Ferrum YES, 2 CeTA-certified YES, 14
  unknown, 0 certification failures.
- Newly certified examples in this slice:
  - `TRS_Innermost/Transformed_CSR_innermost_04/Ex4_7_77_Bor03_GM.ari`
  - `TRS_Innermost/Transformed_CSR_innermost_04/PEANO_nosorts_GM.ari`

Verification after the change:

```console
cargo fmt
cargo test top_level_kbo --quiet
cargo test --quiet
cargo clippy -- -D warnings
cargo fmt -- --check
cargo build --release
```

## KBO/path-order argument-filter search strengthening

The SAT-backed DP path-order and KBO candidate generators no longer restrict
argument filters to only identity filters plus collapsing projections.

Updated behavior:

- For each symbol, Ferrum still includes the identity non-collapsing filter and
  every collapsing projection.
- For arity at most 8, Ferrum also includes every non-empty non-collapsing
  subset in natural order.
- For arity at most 4, Ferrum additionally includes permutations of those
  non-collapsing subsets, including full-arity permutations.
- For larger arities, Ferrum intentionally keeps only identity plus collapsing
  projections to avoid an explosive search space.

Soundness/certification note:

- This only expands the candidate-generation space. Every candidate still has
  to pass Ferrum's independent reduction-pair checker before a DP removal is
  accepted, and accepted proofs continue to be exported with explicit CPF
  argument filters for CeTA.

Regression coverage:

- `sat_argument_filter_domain_includes_subsets_and_permutations` checks that
  the SAT candidate domain includes representative projections,
  non-collapsing subsets, and permutations.
- `lpo_lex_status_accepts_same_root_lexicographic_decrease` checks the LPO
  lex-status branch directly.
- `lpo_accepts_aprove_ex1_gm99_component_shape` checks that the checker accepts
  an AProVE-style lex-status component with the transformed-CSR argument
  filter.

Current limitation:

- The sampled AProVE lex proof
  `TRS_Innermost/Transformed_CSR_innermost_04/Ex1_GM99_GM.ari` still returns
  `Unknown` in Ferrum. The LPO checker can validate the relevant three-pair
  component, but Ferrum's dependency graph currently does not isolate that
  component before path-order search. The next high-impact prerequisite for
  this proof family is therefore graph precision, not LPO checking.

Verification commands used after this change:

```console
cargo test --quiet
cargo clippy -- -D warnings
```

## Dependency graph EDG correction and standard-TRS use

Ferrum's dependency graph processor now uses the estimated dependency graph
approximation for standard TRSs as well as innermost TRSs, instead of falling
back to the complete graph for the standard setting.

Correctness fix:

- The standard EDG approximation is based on checking whether
  `REN(CAP(t))` unifies with the target DP left-hand side.
- `REN` must separate variable occurrences in the capped right-hand side. For
  example, a term shaped like `F(y,y)` is renamed like `F(y1,y2)`, not like
  `F(y1,y1)`.
- Ferrum now performs occurrence-renaming on the `CAP` side and only uses
  ordinary consistent standardization-apart for the target left-hand side.

Impact:

- This avoids unsoundly missing graph edges when a repeated variable occurrence
  in a DP right-hand side can later instantiate differently.
- It also lets standard TRS proofs benefit from safe SCC splitting instead of
  treating every DP as potentially connected to every other DP.

Regression coverage:

- `estimated_dependency_graph_ren_separates_variable_occurrences` checks the
  repeated-variable case directly.
- `standard_dependency_graph_uses_estimated_edges` checks that full-rewriting
  TRSs no longer use the complete dependency graph fallback.
- `dependency_pairs_skip_rhs_calls_that_are_lhs_subterms` checks that DP
  generation follows the candidate-term convention and omits RHS calls that
  already occur as proper subterms of the source rule LHS.
- `innermost_dependency_graph_uses_rhs_lhs_unification_without_cap` checks the
  certified-safe single-rule innermost graph estimate used for AG01-style
  examples where proper defined RHS subterms are known normal. An unrestricted
  direct innermost graph estimate was tried and rejected: CeTA found missing
  edges on several AG01 examples, so Ferrum falls back to `CAP` unless the
  single-rule normality guard holds.
- `innermost_dependency_graph_uses_ground_normal_rhs_calls_without_cap` checks
  the multi-rule extension where every proper defined RHS call is ground and
  syntactically normal. This certifies
  `TRS_Innermost/AG01_innermost/#4.21.ari` without reopening the
  over-permissive general innermost graph estimate.
- The innermost direct graph estimate now also checks the source rule LHS under
  the RHS/target unifier. If a proper source-LHS subterm becomes a ground
  redex, the edge is impossible in an innermost dependency chain and can be
  dropped. This certifies
  `TRS_Innermost/Mixed_innermost/innermost1.ari`: the spurious edge would force
  the source LHS to contain `a(b)`, while `a(b) -> c` is a rule.
- Dependency-graph components are now emitted in a stable topological order
  that breaks ties by the original DP index. This matters for CPF replay:
  CeTA may estimate additional forward edges that Ferrum's more precise local
  graph omitted, and those are accepted only when component order is compatible
  with the checker-side estimate.
- Regression coverage:
  `innermost_dependency_graph_uses_source_lhs_ground_redex_filter` and
  `dependency_graph_components_tie_break_by_original_pair_order`.
- Replay:

```console
cargo run --quiet -- prove ../TPDB-ARI/TRS_Innermost/Mixed_innermost/innermost1.ari \
  --strategy 'dp(graph)' \
  --cpf /tmp/ferrum-innermost1-graph.cpf3.xml \
  --cpf-mode cpf30 \
  --no-top-level-llm
.tools/ceta-relative-bounds /tmp/ferrum-innermost1-graph.cpf3.xml
# CERTIFIED
```

Follow-up blocker:

- AProVE's TermCOMP 2025 certificate for
  `TRS_Innermost/Mixed_innermost/bn111.ari` is a pure `depGraphProc` proof and
  is accepted by the local CeTA after stripping the leading `YES` line from the
  downloaded artifact. Ferrum can reproduce the singleton split if the
  innermost graph test is strengthened from "ground redex under the MGU" to
  "any proper source/target LHS subterm that unifies with a rule LHS under the
  MGU". However, enabling that broadly over-splits several AG01 examples
  (`#4.14`, `#4.15`, `#4.16`, `#4.26`) whose current certified proofs require
  those edges. The correct next step is therefore a faithful implementation of
  CeTA/AProVE's full Q-aware IEDG estimate, not a blanket syntactic-normality
  prune.

Verification command used after this change:

```console
cargo test dependency_graph --quiet
```

## Dimension-1 and dimension-2 matrix interpretation DP processor

Ferrum now has a certified DP reduction-pair processor for bounded matrix
interpretations over the naturals.

Implemented behavior:

- New strategy atom: `matrix`, also available as
  `matrix-interpretation` / `matrix-interpretations`.
- The default DP reduction-pair portfolio now includes a cheap dimension-1
  matrix interpretation slot before the dimension-2 slot.
- `matrix(c,a,s,m)` preserves the original positional syntax and uses dimension
  2 with maximum vector constant `c`, matrix coefficient `a`, optional symbol
  cap `s`, and optional arity cap `m`.
- Named syntax can request the dimension explicitly:
  `matrix(dim=1, const=c, coeff=a, symbols=s, arity=m)`.
- Aliases `matrix1` / `matrix-dim1` and `matrix2` / `matrix-dim2` select the
  default bounds with dimension 1 or 2 respectively.
- Matrix interpretations use the requested positive dimension and strict
  dimension 1.
- Function interpretations are affine vector functions:
  a vector constant plus one matrix coefficient per argument.
- Candidate matrices are nonnegative and drawn from a small bounded basis
  including identity, zero, diagonal/projection-like matrices, triangular
  matrices, and swap.
- The synthesizer uses a bounded attempt counter rather than a raw Cartesian
  product cutoff, so small examples with two or more symbols are not rejected
  before search starts.

Soundness/certification note:

- Ferrum independently checks componentwise weak decrease for all usable rules
  and all DPs, and requires a strict decrease in the first component for at
  least one removed DP.
- CPF 3 export emits `<matrixInterpretation>` with explicit dimension, strict
  dimension, vector constants, and matrix coefficients.
- Since all accepted matrices are nonnegative, matrix proofs are emitted through
  the monotone red-pair processor shape.

Smoke test:

```console
printf '(VAR x)\n(RULES\n  f(s(x)) -> f(x)\n)\n' > /tmp/ferrum-matrix-smoke.trs
cargo run --quiet -- prove /tmp/ferrum-matrix-smoke.trs \
  --strategy 'dp(matrix)' \
  --cpf /tmp/ferrum-matrix-smoke.cpf3.xml \
  --cpf-mode cpf30 \
  --no-top-level-llm \
  --no-synthesize-symbol-weights
.tools/ceta-relative-bounds /tmp/ferrum-matrix-smoke.cpf3.xml
```

Observed result:

```console
status: Terminating
cpf: /tmp/ferrum-matrix-smoke.cpf3.xml
CERTIFIED
```

Regression coverage:

- `synthesizes_matrix_interpretation_for_dp_component`
- `synthesizes_dimension_one_matrix_interpretation_for_dp_component`
- `writes_cpf3_matrix_interpretation_dp_certificate`

## DP polynomial interpretations with zero coefficients

Ferrum's DP polynomial reduction-pair processor no longer requires every
argument coefficient to be at least 1.

Updated behavior:

- Enumerative polynomial search now includes coefficients `0..=max`.
- SAT-backed polynomial search now includes coefficients `0..=max`.
- The DP polynomial checker accepts weakly monotone interpretations with zero
  coefficients, provided all usable rules and all DPs are weakly decreasing and
  at least one DP is strictly decreasing.

Soundness/certification note:

- This change applies to DP red-pair removal, where the CPF proof shape is the
  monotone red-pair processor.
- Ferrum still checks the oriented constraints independently before accepting a
  candidate.
- CPF output naturally represents zero coefficients by omitting the
  corresponding variable term from the linear polynomial.

Regression coverage:

- `polynomial_dp_removal_accepts_zero_coefficients` checks an explicit
  reduction-pair removal where the second argument of a marked symbol is
  ignored by a zero coefficient.

## Innermost DP rewriting processor

Ferrum now has a conservative certified YES-side dependency-pair
`rewritingProc`.

Implemented behavior:

- New DP strategy atoms: `rewrite` and `rewriting`.
- The default DP strategies try rewriting as a fallback before narrowing.
- The processor is currently innermost-only, matching the CPF/CeTA side
  condition observed during smoke testing.
- Ferrum rewrites the right-hand side of one DP below the root using a matched
  usable TRS rule. Rules may be non-ground and the rewrite need not be
  size-decreasing; the transformed DP problem is checked recursively and the
  emitted CPF proof is validated by CeTA.
- The transformed DP problem is then proved recursively, restarting with the
  configured DP strategy.
- DP usable-rule collection ignores the marked DP root and starts from defined
  symbols below the DP root. This avoids incorrectly adding the original `f`
  rule merely because a DP RHS root is `f#`.
- In innermost components, the innermost-LHS context is derived from the
  current usable-rule set. Recursive subproblems prune that context by symbols
  still occurring below DP roots.

Certification note:

- CPF 3 export emits `<rewritingProc>` with the original pair, rewrite step,
  rewritten pair, the current component usable-rule TRS, and nested
  `<dpProof>`.
- Rewriting and instantiation proof trees are treated as Q-certifiable when
  their continuation proof is Q-certifiable. This matches AProVE-certified
  innermost proofs where `rewritingProc` appears below
  `innermostLhssRemovalProc`.
- Rewriting now consumes the same bounded transformation budget as narrowing
  and instantiation. This keeps recursive rewrite search from becoming an
  unbounded benchmark path; local `timeout(...)` deadlines are also propagated
  into recursive DP subproblems.
- Matching a rule variable against the same problem variable is treated as an
  identity match rather than recording a cyclic substitution such as `x -> x`.
  This fixes a stack overflow in `AG01_innermost/#4.25.ari` after the graph
  guard correctly retained its self-edge.
- A later certification failure showed that CeTA also requires the emitted
  usable-rule TRS to satisfy the UNF side condition. Ferrum now guards
  rewriting with a conservative left-hand-side overlap check; if the current
  usable rules have a unifiable overlap, `rewritingProc` is skipped and proof
  search continues with later processors.

Smoke test:

```console
cat >/tmp/ferrum-dp-rewriting-yes.trs <<'EOF'
(STRATEGY INNERMOST)
(RULES
  h(a) -> a
  f(s(a)) -> f(h(a))
)
EOF
cargo run --quiet -- prove /tmp/ferrum-dp-rewriting-yes.trs \
  --strategy 'dp(rewrite; graph)' \
  --cpf /tmp/ferrum-dp-rewriting-yes.cpf3.xml \
  --cpf-mode cpf30 \
  --no-top-level-llm \
  --no-synthesize-symbol-weights
.tools/ceta-relative-bounds /tmp/ferrum-dp-rewriting-yes.cpf3.xml
```

Observed result:

```console
status: Terminating
cpf: /tmp/ferrum-dp-rewriting-yes.cpf3.xml
CERTIFIED
```

Regression coverage:

- `rewriting_then_subterm_proves_component`
- `rewriting_match_treats_identity_variable_binding_as_noop`
- `timeout_bounds_recursive_rewriting_strategy`
- `innermost_rewriting_handles_ag01_4_17_component`

Focused AG01 check:

```console
cargo run --quiet -- prove \
  ../TPDB-ARI/TRS_Innermost/AG01_innermost/#4.17.ari \
  --strategy termination \
  --cpf /tmp/ferrum-417.cpf3.xml \
  --cpf-mode cpf30 \
  --no-top-level-llm

.tools/ceta-relative-bounds /tmp/ferrum-417.cpf3.xml
```

Observed result:

```text
status: Terminating
CERTIFIED
```

Additional focused AG01 check:

```console
cargo run --quiet -- prove \
  ../TPDB-ARI/TRS_Innermost/AG01_innermost/#4.25.ari \
  --strategy termination \
  --cpf /tmp/ferrum-425.cpf3.xml \
  --cpf-mode cpf30 \
  --no-top-level-llm

.tools/ceta-relative-bounds /tmp/ferrum-425.cpf3.xml
```

Observed result:

```text
status: Terminating
CERTIFIED
```

## DP polynomial interpretations with zero coefficients

Ferrum's polynomial candidate generator still includes zero coefficients, so
search can explore interpretations with ignored arguments.

Certification status:

- CeTA rejects the current CPF shape when a certifying polynomial interpretation
  relies on a zero coefficient for monotonicity.
- To avoid uncertified YES answers, accepted DP polynomial removals currently
  require strictly positive argument coefficients for the symbols occurring in
  the current component and usable rules.
- Zero-coefficient polynomial removals should be re-enabled only with a
  CPF/CeTA-compatible proof shape for weak monotonicity.

Regression coverage:

- `polynomial_dp_removal_rejects_uncertifiable_zero_coefficients`
- `polynomial_choices_still_include_zero_coefficients`
- `polynomial_dp_removal_accepts_positive_coefficients`

Rational polynomial follow-up:

- Ferrum now supports CPF 3 export for rational linear DP polynomial
  interpretations and checks them with exact rational arithmetic before
  accepting a component removal. Candidate synthesis uses an SMT-first path
  over integer numerator variables interpreted as rationals, then keeps the
  SAT local-assignment path as a fallback for small constraints.
- The default innermost DP strategy now tries a bounded
  `timeout(10s, rat-poly(16,16,12,3,4))` stage after its cheap order
  portfolio.
- `AG01_innermost/#4.26.ari`, previously blocked on AProVE's rational
  weak-monotone red-pair under `innermostLhssRemovalProc`, is now proved and
  CeTA-certified:

```console
target/release/ferrum prove ../TPDB-ARI/TRS_Innermost/AG01_innermost/#4.26.ari \
  --strategy 'dp(graph; rat-poly(16,16,12,3,4); subterm)' \
  --cpf /tmp/ferrum-426.cpf3.xml \
  --cpf-mode cpf30 \
  --no-top-level-llm

./.tools/ceta-relative-bounds /tmp/ferrum-426.cpf3.xml
# CERTIFIED
```

Weak polynomial follow-up:

- Ferrum now has an explicit DP-only `weak-poly` processor for natural
  polynomial interpretations with possibly negative constants. Coefficients
  must be nonnegative. Ferrum checks candidates with the standard
  max-polynomial semantics used by CeTA/AProVE for negative constants over the
  naturals: each symbol interpretation is read as `max(0, p)`. The checker
  asks Z3/cvc5 for a natural counterexample to every weak and strict
  orientation obligation, so accepted candidates are validated independently
  of the synthesis heuristic.
- References checked while making this change:
  - IsaFoR/CeTA documents support for negative constants over naturals and
    rationals, including max-polynomial interpretations over natural numbers:
    <https://cl-informatik.uibk.ac.at/isafor/>
  - Hirokawa and Middeldorp, "Polynomial Interpretations with Negative
    Coefficients", explain that negative constants introduce max expressions
    and require different comparison/search treatment:
    <https://www.jaist.ac.jp/~hirokawa/materials/04aisc.pdf>
- CPF output now chooses `monoRedPairProc` for scalar polynomial DP reductions
  only when every constant is nonnegative and every argument coefficient is
  positive. CeTA rejects mono reduction pairs with negative constants or zero
  coefficients. Weakly monotone or negative-constant scalar polynomial
  reductions are emitted as ordinary `redPairProc` / `redPairUrProc`, which
  CeTA accepts for the checked smoke cases.
- Candidate search first uses the existing Z3/cvc5 bounded integer SMT
  encoding over raw affine constraints, then falls back to a bounded exact
  max-semantics enumerator for small components. The fallback is capped at
  50,000 complete interpretations per component; every candidate it returns is
  checked by the same SMT counterexample validator.
- The transformed-CSR AProVE proofs for
  `Ex2_Luc03b_GM.ari` and `Ex3_3_25_Bor03_GM.ari` still do not certify through
  Ferrum after this change. The trusted checker now models the right
  max-polynomial semantics, so the remaining gap is synthesis/search strength
  on larger components, not an accepted-proof soundness hole.
- Regression coverage:
  `weak_polynomial_dp_removal_accepts_negative_constant_when_terms_stay_natural`,
  `weak_polynomial_dp_removal_rejects_negative_valued_terms`, and
  `weak_polynomial_smt_synthesizes_negative_constant_component`, plus
  `weak_polynomial_synthesis_falls_back_to_max_semantics_enumeration` for a
  case where raw affine SMT misses a valid max-polynomial interpretation.
- CPF/CeTA regression coverage:
  `writes_weak_polynomial_dp_removal_as_non_mono_red_pair`,
  `writes_negative_constant_polynomial_dp_removal`,
  `ceta_certifies_cpf3_weak_polynomial_dp_certificate_when_available`, and
  `ceta_certifies_cpf3_negative_constant_polynomial_dp_certificate_when_available`.

Instantiation status:

- Ferrum already has NO-side DP instantiation proof/export support.
- Ferrum now has a first YES-side DP `instantiationProc`.
- The implementation follows the DP-framework instantiation processor shape:
  for a selected pair `s -> t`, Ferrum considers predecessors `v -> w`,
  unifies `s` with `cap_R(w)` (with variable renaming for full rewriting), and
  replaces the selected pair by the induced finite set `sµ -> tµ`.
- In innermost mode, Ferrum conservatively keeps only instantiations where
  both `sµ` and the predecessor left-hand side `vµ` are guaranteed normal by a
  syntactic no-unifiable-redex check.
- CPF 3 export emits `<instantiationProc>` with the original pair, the
  `<instantiations>` rule set, and the nested `<dpProof>`.
- Instantiation is tried after ordinary SCC decomposition, size-change, the
  reduction-pair portfolio, rewriting, and narrowing. It is currently bounded
  by the same transformation-step budget as narrowing.
- Ferrum now also implements a YES-side innermost-only
  `forwardInstantiationProc`. For a selected pair `s -> t`, it considers
  successor pairs `u -> v`, unifies `t` with `cap_R(u)`, and replaces the
  selected pair by the induced finite set `sµ -> tµ`. CeTA rejects this
  processor outside innermost rewriting, so Ferrum returns inapplicable for
  standard/full TRSs.
- CPF 3 export emits `<forwardInstantiationProc>` with the original pair, the
  `<instantiations>` rule set, the required `<usableRules>` payload, and the
  nested `<dpProof>`.

Regression coverage:

- `instantiation_uses_predecessor_cap_skeleton`
- `forward_instantiation_uses_successor_lhs_skeletons`
- `forward_instantiation_then_graph_decomposition_proves_component`
- `ceta_certifies_cpf3_forward_instantiation_processor_when_available`

## Reduction-pair size-change processor

Ferrum's size-change processor now has a reduction-pair-backed fallback in
addition to the existing subterm criterion.

Implemented behavior:

- The `subterm` / `size-change` DP strategy still tries the fast syntactic
  subterm criterion first.
- If that fails, Ferrum enumerates bounded scalar linear polynomial
  interpretations.
- Usable rules for the current DP component must be weakly oriented by the
  polynomial interpretation.
- Size-change graph edges are generated from polynomial comparisons between
  left and right DP arguments; strict polynomial decrease gives strict edges,
  weak decrease gives weak edges.
- The existing closure/idempotent SCT check is reused to ensure the graph set is
  size-change terminating before a proof is accepted.

Certification note:

- CPF 3 export now supports `<sizeChangeProc><reductionPair>...`.
- The reduction pair payload reuses Ferrum's ordinary CPF red-pair writer, and
  the processor emits the usable rules required by CPF.
- Reduction-pair size-change proofs may now be wrapped in
  `innermostLhssRemovalProc` when the existing polynomial Q-minimality guard
  holds. A CeTA regression covers the non-empty-Q shape under `usableRulesProc`.

Smoke test:

```console
cat >/tmp/ferrum-sizechange-redpair.trs <<'EOF'
(VAR x)
(RULES
  g(x) -> x
  f(s(x)) -> f(g(x))
)
EOF
cargo run --quiet -- prove /tmp/ferrum-sizechange-redpair.trs \
  --strategy 'dp(subterm)' \
  --cpf /tmp/ferrum-sizechange-redpair.cpf3.xml \
  --cpf-mode cpf30 \
  --no-top-level-llm \
  --no-synthesize-symbol-weights
.tools/ceta-relative-bounds /tmp/ferrum-sizechange-redpair.cpf3.xml
```

Observed result:

```console
status: Terminating
cpf: /tmp/ferrum-sizechange-redpair.cpf3.xml
CERTIFIED
```

Regression coverage:

- `polynomial_size_change_handles_non_subterm_decrease`

## Bounds/tree automata and semantic/root labeling status

CPF 3 supports both bounds/tree-automata processors and semantic/root-labeling
processors, but both require substantial explicit witnesses:

- `<bounds>` requires a bound type, numeric bound, final states, and a closed
  tree automaton witness.
- DP semantic labeling requires a model, transformed DPs, transformed TRS, and
  optionally transformed innermost left-hand sides.
- Root labeling additionally interacts with flat-context closure processors and
  transformed problems.

Ferrum does not implement these processors in this pass. This is intentional:
adding strategy atoms or heuristic claims without the required automata/model
witnesses would create uncertifiable or unsound YES answers. The next correct
implementation step is to add explicit internal automaton/model data structures
first, then CPF writers and CeTA smoke tests, and only then proof search.

Standard YES certification safety pass:

- The July 11 focused rerun of 114 `TRS_Standard` examples found cases where
  Ferrum reported `YES` but CeTA rejected the CPF. Cross-checking those
  examples against the downloaded TermCOMP 2025 AProVE certified corpus showed:
  - 65 are `CERTIFIED YES` by AProVE_cert.
  - 27 are `CERTIFIED NO` by AProVE_cert.
  - 22 are not present in the local AProVE_cert proof corpus.
- Because the set contains certified NO examples, these were treated as
  correctness bugs rather than merely missing CPF detail.
- Ferrum now keeps the following conservative policy:
  - dependency-pair narrowing is only applied for innermost TRSs;
  - the certified `sizeChangeProc` path only emits the projection-based
    `subtermCriterion` subset that CeTA accepts;
  - full-rewriting DP graph decomposition uses a complete graph until Ferrum has
    a proved-safe estimated dependency graph for the standard setting.
- Focused rerun command shape:

```console
target/release/ferrum prove PROBLEM \
  --cpf proof.cpf3.xml \
  --cpf-mode cpf30 \
  --no-top-level-llm
```

- Focused rerun output:
  `/tmp/ferrum-standard-certfail-after-safety-20260711`

| Set | Problems | Ferrum YES | CeTA-certified YES | Unknown | Timeout | Error | Certification failed |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| Previous Standard cert-failure set | 114 | 3 | 3 | 111 | 0 | 0 | 0 |

The three surviving certified YES examples are:

- `TRS_Standard/AG01/#3.15.ari`
- `TRS_Standard/Rubio_04/koen.ari`
- `TRS_Standard/SK90/2.02.ari`

All three are also AProVE_cert `CERTIFIED YES` examples. Ferrum proves them with
DP reduction-pair removal followed by the conservative projection
`subtermCriterion`.

Representative AProVE_cert proofs inspected:

- `TRS_Standard/AG01/#3.15.ari`
  (`/tmp/ferrum-termcomp-standard-proofs/benchmark_4.txt`) uses top-level
  `ruleRemoval` with KBO.
- `TRS_Standard/AG01/#3.21.ari`
  (`/tmp/ferrum-termcomp-standard-proofs/benchmark_11.txt`) uses
  `switchInnermost`, `dpTrans`, `depGraphProc`, `usableRulesProc`,
  `monoRedPairProc`, and `sizeChangeProc`/`subtermCriterion`.
- `TRS_Standard/AProVE_07/thiemann13.ari`
  (`/tmp/ferrum-termcomp-standard-proofs/benchmark_218.txt`) uses a much richer
  DP proof with `switchInnermost`, usable rules, innermost-LHS removal,
  narrowing, rewriting, instantiation, KBO with argument filtering, and
  polynomial `redPairUrProc`.

Proof-guided next targets for recovering certified YES power:

1. Add CPF-supported `switchInnermost` and the corresponding correctness checks.
2. Add `monoRedPairProc` / `monoRedPairUrProc` proof output instead of forcing
   every DP reduction into the current generic red-pair shape.
3. Strengthen certified KBO with argument filtering and top-level KBO
   `ruleRemoval`.
4. Reintroduce rewriting, instantiation, and standard narrowing only after their
   CPF side conditions are represented and checked locally.

Switch-innermost and mono-red-pair implementation:

- Ferrum now has a certified `switchInnermost` proof step.
- The step is only tried for full-rewriting TRSs after direct LLM/top-level
  polynomial attempts.
- Local correctness guards before emitting `switchInnermost`:
  - the TRS must be overlay, matching CeTA's accepted processor side condition;
  - all critical pairs must join by bounded full-rewriting BFS at depth 10,
    matching the emitted `<wcrProof><joinAutoBfs>10</joinAutoBfs></wcrProof>`;
  - the recursive proof is run on an innermost copy of the same TRS;
  - DP narrowing is disabled inside the switched proof for now, because many
    switched narrowing certificates still fail CeTA's exact narrowed-pair side
    conditions.
- CPF 3 output now emits `monoRedPairProc` / `monoRedPairUrProc` for polynomial
  DP reductions. For `monoRedPairUrProc`, Ferrum emits an empty strict `<trs>`
  section and the weak constraints under `<usableRules>`, which CeTA accepts for
  the current pair-removal-only DP reductions.
- Filtered path orders and KBO still use the generic `redPairProc` /
  `redPairUrProc` path.

Targeted CeTA checks after this change:

```console
cargo test
cargo clippy -- -D warnings
cargo build --release

target/release/ferrum prove ../TPDB-ARI/TRS_Standard/AG01/#3.21.ari \
  --cpf /tmp/ferrum-switch-321.cpf3.xml \
  --cpf-mode cpf30 \
  --no-top-level-llm
.tools/ceta-relative-bounds /tmp/ferrum-switch-321.cpf3.xml

target/release/ferrum prove ../TPDB-ARI/TRS_Standard/AG01/#3.15.ari \
  --strategy 'dp' \
  --cpf /tmp/ferrum-mono-315.cpf3.xml \
  --cpf-mode cpf30 \
  --no-top-level-llm
.tools/ceta-relative-bounds /tmp/ferrum-mono-315.cpf3.xml
```

Both targeted certificates were accepted by CeTA after the mono-red-pair XML
shape was corrected.

Focused rerun of the previous 114 Standard YES/certification-failure set:

- Output:
  `/tmp/ferrum-standard-certfail-after-switch-mono-tight-20260711`

| Set | Problems | Ferrum YES | CeTA-certified YES | Unknown | Timeout | Error | Certification failed |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| Previous Standard cert-failure set after tight switch/mono | 114 | 4 | 4 | 110 | 0 | 0 | 0 |

Certified YES problems in that focused rerun:

- `TRS_Standard/AG01/#3.15.ari`
  (`switchInnermost`, `monoRedPairUrProc`, `sizeChangeProc`,
  `usableRulesProc`)
- `TRS_Standard/AG01/#3.29.ari` (`switchInnermost`)
- `TRS_Standard/Rubio_04/koen.ari` (`switchInnermost`)
- `TRS_Standard/SK90/2.02.ari` (`monoRedPairUrProc`, `sizeChangeProc`)

An intermediate, less restrictive implementation solved 53 of the 114 but had
45 certification failures. The failures showed two important side conditions:
CeTA rejects `switchInnermost` on non-overlay systems, and switched proofs that
use Ferrum's current DP narrowing often fail the exact CPF narrowed-pair checks.
Those paths are now gated off rather than reported as uncertified YES answers.

AProVE-certified YES misses after the tight switch/mono repair:

- Standard comparison basis: the previous full `TRS_Standard` Ferrum result,
  patched with `/tmp/ferrum-standard-certfail-after-switch-mono-tight-20260711`
  for the old 114 certification failures.
- Innermost comparison basis:
  `/tmp/ferrum-termcomp-innermost-proofs/miss_features.csv`.

`TRS_Standard`:

- AProVE_cert certified YES proofs: 946.
- Ferrum certified YES inside that set after the repaired projection: 269.
- Remaining AProVE_cert YES / Ferrum non-certified-or-MAYBE cases: 677.

Most common tags among those 677 Standard misses:

| Tag or bucket | Misses touched |
| --- | ---: |
| polynomial / red-pair / rule-removal | 632 |
| usable rules / innermost-LHS / switch | 482 |
| size-change / subterm | 404 |
| KBO / argument filtering | 333 |
| instantiation / rewriting / narrowing | 126 |
| matrix interpretations | 87 |

Greedy bucket coverage in the order KBO/filtering, size-change, then
polynomial/red-pair leaves only a small residual:

| Bucket | Additional misses covered greedily |
| --- | ---: |
| KBO / argument filtering | 333 |
| size-change / subterm | 233 |
| polynomial / red-pair / rule-removal | 97 |

`TRS_Innermost`:

- Local AProVE_cert YES / Ferrum-miss rows in the current gap CSV: 240.
- Most common tags:

| Tag or bucket | Misses touched |
| --- | ---: |
| polynomial / red-pair / rule-removal | 200 |
| usable rules / innermost-LHS | 155 |
| size-change / subterm | 150 |
| KBO / argument filtering | 121 |
| instantiation | 28 |
| matrix interpretations | 27 |

Greedy bucket coverage with size-change first:

| Bucket | Additional misses covered greedily |
| --- | ---: |
| size-change / subterm | 150 |
| KBO / argument filtering | 60 |
| polynomial / red-pair / rule-removal | 13 |
| usable rules / innermost-LHS | 7 |

Conclusion for the next implementation target:

- For `TRS_Innermost`, strengthen the existing size-change/subterm processor
  first. It should support the full CPF `sizeChangeGraph` shape: multiple weak
  and strict edges per pair, closure/composition, use under `usableRulesProc`
  and `innermostLhssRemovalProc`, and correct non-empty-Q side conditions.
- For `TRS_Standard`, KBO with argument filtering and stronger polynomial/
  red-pair search are also very high leverage, but many Standard proofs combine
  those with size-change and usable/Q processors. So size-change/Q correctness is
  still the best foundational strengthening; KBO/filtering is the best next
  standalone search-power improvement.

Full `TRS_Standard` default-strategy benchmark:

- Strategy source: checked-in `strategies/default.fs`.
- Harness command:

```console
python3 scripts/termcomp_trs_compare.py \
  --category TRS_Standard \
  --ferrum-profile default \
  --jobs 8 \
  --timeout 60 \
  --output /tmp/ferrum-standard-default-defaultfs-20260711-154151.md
```

- Result table updated in `docs/termcomp-2025-trs-comparison.md`.
- Per-problem reconstructed NO lists:
  - `/tmp/ferrum-standard-default-no-problems.txt`
  - `/tmp/ferrum-standard-default-no-problems.csv`

Observed Ferrum row:

| Total | YES | NO | Certified YES | Certified NO | MAYBE | Timeout | Error | Cert failed |
| ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| 1528 | 379 | 165 | 265 | 165 | 630 | 354 | 0 | 114 |

Focused Standard YES certification-failure rerun:

- The original comparison table did not retain per-problem result details, so
  the failure set was reconstructed with the same default profile over
  `TRS_Standard`.
- Reconstruction output:
  `/tmp/ferrum-standard-certfail-rerun-20260711-191133`
- Focused rerun of only the reconstructed 114 certification failures:
  `/tmp/ferrum-standard-certfail-only-20260711-200936`
- Focused rerun result:

```text
yes=114
certified-yes=0
certification-failed=114
timeout=0
error=0
```

Summary file:

```text
/tmp/ferrum-standard-certfail-only-20260711-200936/summary.md
```

CeTA rejection classes in the focused rerun:

| Failing processor class | Count |
| --- | ---: |
| `narrowingProc` | 83 |
| `sizeChangeProc` | 24 |
| `depGraphProc` | 7 |

The dominant issue is unsound/over-permissive CPF emission for Standard/full
dependency-pair narrowing. CeTA rejects these proofs mainly because Ferrum's
narrowing step does not yet enforce all CPF side conditions for full rewriting:
linearity, capped-position/Q-normal requirements, required narrowed-pair
coverage, and overlap/variable-condition side conditions. The remaining
failures are over-permissive size-change/subterm and dependency-graph
decomposition certificates.

## SMT Solver Installation and Polynomial Benchmark, 2026-07-11

Installed solver binaries:

- Z3 via Homebrew:

```console
brew install z3
z3 --version
# Z3 version 4.16.0 - 64 bit
```

- cvc5 from the upstream macOS arm64 static release archive:

```console
mkdir -p .tools/cvc5-1.3.4
curl -L \
  https://github.com/cvc5/cvc5/releases/download/cvc5-1.3.4/cvc5-macOS-arm64-static.zip \
  -o /tmp/cvc5-macOS-arm64-static.zip
unzip -o /tmp/cvc5-macOS-arm64-static.zip -d .tools/cvc5-1.3.4
ln -sf cvc5-1.3.4/cvc5-macOS-arm64-static/bin/cvc5 .tools/cvc5
./.tools/cvc5 --version | head -n 2
# cvc5 1.3.4 [git f3b21c4 on branch HEAD]
```

Ferrum changes:

- Added `--dp-smt-solver <PATH>` to `prove`, `tpdb prove`, and
  `tpdb certify`.
- The SMT polynomial backend now uses solver-specific stdin/model flags:
  Z3 receives `-in`; cvc5 receives
  `-q --lang smt2 --produce-models --incremental`.
- SMT model parsing was made token-based so multiline Z3 models and cvc5
  models are both accepted.

Benchmark setup:

- Problem set: first 20 sorted `.ari` files under
  `../TPDB-ARI/TRS_Innermost`.
- Per-problem timeout: 5 seconds.
- Shared command options:

```console
target/release/ferrum prove PROBLEM \
  --no-top-level-llm \
  --strategy 'dp' \
  --max-polynomial-constant 2 \
  --max-polynomial-coefficient 1 \
  --max-polynomial-symbols 4 \
  --max-polynomial-arity 2
```

Solver-specific options:

```console
--strategy 'dp(sat-poly)'
--strategy 'dp(smt-poly)' --dp-smt-fallback --dp-smt-solver z3
--strategy 'dp(smt-poly)' --dp-smt-fallback --dp-smt-solver ./.tools/cvc5
```

Observed results on this machine:

| Backend | YES | Timeouts | Total time | Mean | Median | p95 |
| --- | ---: | ---: | ---: | ---: | ---: | ---: |
| SAT polynomial | 2 / 20 | 1 | 16.728s | 0.8364s | 0.0663s | 4.8042s |
| SMT polynomial, Z3 | 1 / 20 | 1 | 16.728s | 0.8364s | 0.0774s | 4.6654s |
| SMT polynomial, cvc5 | 1 / 20 | 1 | 16.649s | 0.8324s | 0.0775s | 4.6657s |

YES files:

- SAT polynomial:
  `AG01_innermost/#4.13.ari`,
  `AG01_innermost/#4.2.ari`.
- SMT polynomial with Z3:
  `AG01_innermost/#4.13.ari`.
- SMT polynomial with cvc5:
  `AG01_innermost/#4.13.ari`.

A longer 50-problem run with a 10 second timeout was started first. It
completed the SAT backend with 6 / 50 YES and 17 timeouts, but the combined
three-backend run exceeded the tool wall-clock limit before cvc5 started, so
the complete table above uses the smaller fixed sample.

Argument-filter and full size-change follow-up:

- The temporary sentinel encoding for collapsing path-order argument filters was replaced by explicit `DpArgumentFilterEntry::{NonCollapsing, Collapsing}` values.
- CPF 3 path-order export now emits real `<collapsing>i</collapsing>` entries from that representation.
- LLM path-order proposals still accept the existing JSON shape with arrays; those proposals are interpreted as non-collapsing filters for backward compatibility.
- The non-empty-Q path-order guard was tightened again after `TRS_Innermost/Mixed_innermost/narrow1.ari` exposed an uncertified case whose Q pattern filtered to a constant. Ferrum now only accepts Q path-order reductions when the filtered Q LHSs are variables and marked/unmarked collapsing choices agree.
- The size-change processor now tries the old fast projection check first, then
  a generalized subterm-based size-change graph closure check. Graph edges are
  generated from weak equality or strict proper-subterm descent between source
  and target arguments.
- The closure check follows Lee/Jones/Ben-Amram's size-change criterion as used
  in the TRS/DP adaptation by Thiemann and Giesl: compute the composition
  closure and reject exactly when an idempotent closure graph has no in-situ
  strict self-edge. A regression test covers the case where an initial cyclic
  graph has no strict self-edge but is still valid because it is not idempotent.
- The generalized size-change graphs reuse the CPF 3
  `<sizeChangeProc><subtermCriterion/>...` output only for subterm-generated
  edges, matching the local CPF 3 schema documentation. A CeTA regression test
  certifies a generalized subterm graph with both weak and strict edges.
- A partial `TRS_Innermost` benchmark run after generalized size-change found
  five uncertified YES results before the run was stopped:
  `AG01_innermost/#4.26.ari`, `#4.28.ari`, `#4.30.ari`, `#4.30a.ari`, and
  `#4.30b.ari`. All five were `narrowingProc` issues rather than
  `sizeChangeProc` issues.
- The narrowing fix has two parts:
  - TRS rules used for narrowing are now freshened away from variables already
    present in the current dependency pair. This fixes incomplete narrowed
    pair sets caused by names like `x__n2` colliding across nested narrowing
    steps.
  - Narrowing positions are rejected when the selected RHS subterm unifies
    with the same-position LHS subterm of any current DP, including the DP being
    narrowed, and that DP's variable condition holds under the unifier.
  - The emitted narrowed set now includes all one-step narrowings at or below
    the selected subterm. CeTA's `narrowingProc` replay expects this complete
    local narrowing family, not just root narrowing at the selected subterm.
- Rechecking the 17 old innermost certification failures after the
  instantiation/rewrite/narrowing certification fixes: 14 problems now produce
  CeTA-certified YES results, while
  `AG01_innermost/#4.26.ari`, `Mixed_innermost/innermost2.ari`,
  and `Mixed_innermost/narrow1.ari` return `Unknown` instead of uncertified
  YES.
- Ferrum now treats pure `sizeChangeProc` as Q-certifiable in the real
  innermost CPF shape, and treats reduction-pair size-change as Q-certifiable
  when the polynomial Q-minimality guard holds. Narrowing proof trees remain
  outside the Q-certifiable set for now. Rewriting and instantiation are allowed
  under `innermostLhssRemovalProc` when their nested continuation is
  Q-certifiable; this was later verified on `AG01_innermost/#4.17.ari`.

Full `TRS_Innermost` reruns:

```console
python3 scripts/termcomp_trs_compare.py \
  --category TRS_Innermost \
  --jobs 8 \
  --timeout 60 \
  --output /tmp/ferrum-innermost-after-safe-graph-candidates.md \
  --details-output /tmp/ferrum-innermost-after-safe-graph-candidates.json

# after standard DP candidate filtering and the safe single-rule innermost graph estimate
# elapsed=1517s total=366
# yes=49 cert_yes=49 no=4 cert_no=4 maybe=146 timeout=167
# error=0 certification-failed=0

python3 scripts/termcomp_trs_compare.py \
  --category TRS_Innermost \
  --jobs 8 \
  --timeout 60 \
  --output /tmp/ferrum-innermost-after-instantiation.md \
  --details-output /tmp/ferrum-innermost-after-instantiation.json

# after certification fixes and YES-side instantiation
# elapsed=1517s total=366
# yes=48 cert_yes=48 no=4 cert_no=4 maybe=147 timeout=167
# error=0 certification-failed=0

python3 scripts/termcomp_trs_compare.py \
  --category TRS_Innermost \
  --jobs 8 \
  --timeout 60 \
  --output /tmp/ferrum-innermost-q-enum.md

# after explicit argument-filter representation, before generalized size-change
yes=36 certified=36 timeout=1 certification-failed=0

python3 scripts/termcomp_trs_compare.py \
  --category TRS_Innermost \
  --jobs 8 \
  --timeout 60 \
  --output /tmp/ferrum-innermost-full-sizechange-safe.md

# after generalized size-change and the stricter Q path-order guard
yes=39 certified=39 timeout=1 certification-failed=0
```

DP KBO follow-up:

- Ferrum now has a dependency-pair KBO reduction-pair backend in addition to polynomial and RPO backends.
- The DP KBO checker runs after argument filtering and checks a conservative KBO condition: variable condition, weight decrease, or equal-weight precedence/lexicographic tie-break.
- The KBO search reuses the existing bounded argument-filter and precedence candidates, then tries small bounded weight assignments.
- DP KBO now permits zero symbol weights under the standard admissibility side
  condition used by KBO over `w0 = 1`: a zero-weight symbol must be unary and
  maximal in the precedence. Constants and non-unary symbols must have positive
  weight.
- CPF 3 export emits `<knuthBendixOrder>` with `<w0>1</w0>`, `<precedenceWeight>`, per-symbol weights, and any argument filter.
- KBO uses the same non-empty-Q compatibility gate as path orders.
- Regression coverage:
  `kbo_admissibility_allows_only_unary_zero_weight_maximal_symbols`,
  `kbo_admissibility_rejects_zero_weight_binary_symbols`, and
  `ceta_certifies_cpf3_zero_weight_dp_kbo_certificate_when_available`.

Full `TRS_Innermost` rerun:

```console
python3 scripts/termcomp_trs_compare.py \
  --category TRS_Innermost \
  --jobs 8 \
  --timeout 60 \
  --output /tmp/ferrum-innermost-kbo.md

yes=40 certified=40 timeout=1 certification-failed=0
```

SAT-backed KBO/RPO search follow-up:

- DP RPO and DP KBO no longer enumerate argument filters and then run a
  separate precedence search under each filter.
- DP RPO now asks one SAT problem for a complete candidate containing both the
  argument filter and precedence. The SAT variables include exact-one filter
  choices per symbol and exact-one rank choices per symbol, plus all-different
  precedence-rank clauses. One model is one complete order candidate.
- DP KBO now asks one SAT problem for a complete candidate containing the
  argument filter, precedence, and bounded positive symbol weights. One model
  is one complete KBO candidate.
- The current combined-SAT streams use blocking clauses to ask for additional
  complete models only after a full candidate has been checked and rejected.
  There is no outer product of filters, precedences, and weights in Rust.
- Rust's checked RPO/KBO comparisons remain the trusted acceptance gate. SAT
  finds complete candidates; Ferrum only emits a proof step after the local
  order checker verifies that the candidate weakly orients the usable rules and
  removes at least one DP.
- DP linear-polynomial reduction pairs now also have a SAT-backed bounded
  synthesis path before recursive enumeration. The encoding creates exact-one
  SAT variables for every interpretation constant and coefficient, with
  positive coefficient domains for CeTA-compatible monotonicity.
- Polynomial weak-orientation and strict-removal constraints are encoded into
  CNF by enumerating local assignments for the parameters that occur in each
  constraint and adding clauses that forbid exactly the assignments violating
  that constraint. This keeps SAT responsible for finding one complete
  polynomial interpretation rather than letting Rust enumerate symbol
  interpretations independently.
- The SAT polynomial backend is bounded by
  `SAT_POLYNOMIAL_LOCAL_ASSIGNMENT_LIMIT=100000` for any single local
  constraint expansion. If a local constraint would exceed that limit, Ferrum
  falls back to the older recursive or external SMT paths.
- The CLI now disables the experimental narrowing processor by default because
  several narrowing-plus-size-change CPF proofs in `TRS_Innermost` were rejected
  by CeTA. Library tests still cover narrowing through explicit `DpOptions`.
- `scripts/termcomp_trs_compare.py` now distinguishes `status: Terminating`
  from `status: Nonterminating`, so local comparison rows no longer count NO
  proofs as YES.

Full `TRS_Innermost` rerun:

```console
python3 scripts/termcomp_trs_compare.py \
  --category TRS_Innermost \
  --jobs 8 \
  --timeout 60 \
  --output /tmp/ferrum-innermost-sat-component-aware.md

yes=41 certified=41 timeout=2 certification-failed=0
```

After the combined-SAT correction and CLI narrowing disablement, a follow-up
full run was started with:

```console
python3 scripts/termcomp_trs_compare.py \
  --category TRS_Innermost \
  --jobs 8 \
  --timeout 60 \
  --output /tmp/ferrum-innermost-sat-combined-certified.md
```

That process exited early after the first progress line:

```text
TRS_Innermost: completed=50/366 yes=6 cert_yes=6 timeout=5 error=0 elapsed=77s
```

The partial run is not recorded in the comparison table because it did not
complete the category.

## 19. TermCOMP 2025 Proof-Corpus Analysis

Ferrum now keeps local notes comparing its roadmap with TermCOMP 2025
certified TRS proof artifacts:

- `docs/termcomp-2025-trs-comparison.md` records the TermCOMP Standard and
  Innermost result tables and Ferrum comparison rows.
- `docs/termcomp-2025-innermost-proof-gap.md` records the AProVE certified
  proof-tag analysis for `TRS_Innermost`.
- `docs/termcomp-2025-standard-proof-gap.md` records the AProVE certified
  proof-tag analysis for `TRS_Standard`.
- `docs/termcomp-2025-standard-no-proof-gap.md` records the AProVE certified
  NO proof-shape analysis for `TRS_Standard`.

The Standard AProVE certified corpus was downloaded from:

```text
https://termcomp.github.io/Y2025/TRS_Standard.html
https://termcomp.github.io/Y2025/TRS_Standard.summary.json
https://raw.githubusercontent.com/TermCOMP/TermCOMP.github.io/refs/heads/master/jobs/job_60781488/cert/proofs/benchmark_*/solver_2.txt
```

Local extracted artifacts for the Standard proof analysis:

```text
/tmp/ferrum-termcomp-standard-proofs/index.json
/tmp/ferrum-termcomp-standard-proofs/proof_features.json
/tmp/ferrum-termcomp-standard-proofs/proof_features.csv
/tmp/ferrum-termcomp-standard-proofs/tag_counts_yes.json
/tmp/ferrum-termcomp-standard-proofs/tag_counts_no.json
```

Observed Standard AProVE certified corpus:

```text
total artifacts: 1208
certified YES: 946
certified NO: 262
```

The main processor signal for Ferrum is that KBO with argument filtering,
size-change/subterm, stronger polynomial/rule-removal proof shapes, matrix
interpretations, and instantiation/narrowing/rewriting processors are the next
highest-value areas for `TRS_Standard`.

NO proof implementation follow-up:

- Ferrum now has a first-class `Nonterminating` proof status in addition to
  `Terminating` and `Unknown`.
- CPF 3 output supports `trsNonterminationProof` for:
  - `variableConditionViolated`;
  - checked `loop` certificates over the original TRS;
  - recursive dependency-pair nontermination proof trees via `dpTrans` and
    `dpNonterminationProof`.
- `prove` now tries NO processors before YES processors. This lets invalid
  ordinary TRSs with only a variable-condition violation become certified NO
  results instead of being dropped before proof search.
- TPDB prove/certify runs now allow validation issues that are themselves
  nontermination witnesses (`ExtraVariablesOnRhs` and variable left-hand sides)
  to reach the prover.
- The loop checker validates every accepted witness by replaying the rewrite
  sequence, checking the recorded intermediate terms, and checking the final
  context/substitution closure.
- NO-side loop discovery currently includes:
  - direct one-step self-embedding loop search;
  - bounded symbolic narrowing loop search;
  - bounded concrete rewriting loop search;
  - a conservative dependency-pair self-loop hook;
  - dependency-pair `dpRuleRemoval` wrappers for irrelevant extra pairs;
  - dependency-pair `rewritingProc` search when rewriting a DP RHS yields a
    checked loop;
  - dependency-pair `instantiationProc` proof-tree/export support.
- YES-side DP narrowing already existed and is searched by the DP termination
  prover before reduction-pair search.

NO proof smoke checks:

```console
cargo test
cargo clippy -- -D warnings
cargo fmt -- --check

cargo run -- prove examples/loop.ari \
  --cpf /tmp/ferrum-loop-no.cpf3.xml \
  --cpf-mode cpf30
./.tools/ceta-relative-bounds /tmp/ferrum-loop-no.cpf3.xml
# CERTIFIED

target/debug/ferrum prove \
  ../TPDB-ARI/TRS_Standard/Transformed_CSR_04/Ex3_12_Luc96a_L.ari \
  --cpf /tmp/ferrum-tpdb-varcond-no.cpf3.xml \
  --cpf-mode cpf30
./.tools/ceta-relative-bounds /tmp/ferrum-tpdb-varcond-no.cpf3.xml
# CERTIFIED
```

Additional DP-NO CPF checks:

- Ferrum now emits and CeTA-certifies small CPF 3 examples for DP
  `dpRuleRemoval`, `rewritingProc`, and `instantiationProc`.
- `nonLoop` has a CPF data model and writer, but no search procedure and no
  CeTA-certified synthetic witness yet. Real non-loop certificates require the
  CPF pattern-rule/pumping proof object, not just an ordinary loop.

Remaining NO-side gaps:

- NO-side narrowing exists as bounded symbolic loop discovery, and YES-side DP
  narrowing exists as a certified processor. Ferrum does not yet emit CPF
  `narrowingProc` inside `dpNonterminationProof`.
- The DP-NO search is still much smaller than AProVE's full stack: it lacks
  nested strategy processors such as `switchFullStrategyProc`, full
  instantiation/narrowing search, and generated `nonLoop` proofs.

DP narrowing follow-up:

- Ferrum now has a first dependency-pair `narrowingProc`.
- The processor is conservative: it narrows one DP RHS below the root at a
  non-variable position, emits all one-step narrowings at or below that
  selected subterm, replaces the selected DP by the finite set of narrowed DPs,
  and then recursively continues with the existing SCC decomposition and
  reduction processors.
- Narrowing attempts are bounded by `DpOptions::max_narrowing_steps` and
  `DpOptions::max_narrowings_per_step`. Ferrum first tries to solve the current
  cyclic component without narrowing: SCC decomposition, size-change/subterm,
  and reduction-pair processors. Narrowing is only attempted after those
  ordinary processors fail. If the narrowed subproblem cannot be proved, the
  component fails without recording a narrowing step.
- CPF 3 output emits the nested DP proof shape
  `<narrowingProc> ... <positionInTerm> ... <narrowings> ... <dpProof> ...`.
- Regression coverage includes a direct DP narrowing test, an automatic
  narrowing-then-size-change proof-search test, a CPF 3 `narrowingProc`
  emission test, a guard that reduction pairs are tried before narrowing when
  they suffice, and a conditional CeTA smoke test for the generated narrowing
  certificate.

Standard narrowing repair checkpoint:

- Ferrum now executes an explicit side-condition guard for standard/full
  narrowing candidates. Innermost narrowing remains unchanged. Full rewriting
  candidates are only considered when the selected DP target is linear, all TRS
  rule left-hand sides are linear, and the usable/TRS rules have no
  left-hand-side overlaps.
- The guard is local to the candidate DP instead of rejecting an entire
  component because of an unrelated non-linear pair. This matches the
  AProVE/CeTA proof shape more closely and keeps the processor from becoming
  unnecessarily weak.
- The rejected Ferrum certificate for
  `TRS_Standard__Strategy_removed_AG01__sharp4.25.ari` failed CeTA with
  `linearity of t in full rewriting case` for the attempted step
  `f#(x, x) -> f#(g(x), x)`. That target is now blocked before proof search can
  emit a `narrowingProc`. A targeted rerun on
  `../TPDB-ARI/TRS_Standard/Strategy_removed_AG01/#4.25.ari` now returns
  `Unknown` instead of producing the invalid certificate.
- AProVE certified `YES` proof `benchmark_581.txt` in
  `/tmp/ferrum-termcomp-standard-proofs` was inspected as a full-rewriting
  narrowing example. It uses `narrowingProc` under usable-rules and
  innermost-LHS-removal context, with linear DP targets such as
  `minus#(x, y) -> if#(le(x, y), x, y)` and
  `if#(false, x, y) -> minus#(p(x), y)`.
- Regression tests cover acceptance of a linear non-overlapping standard
  fragment and rejection of the non-linear-target shape that CeTA rejected.

Verification commands used after this change:

```console
cargo fmt
cargo test
cargo clippy -- -D warnings
```

DP strategy-language follow-up:

- Ferrum now has an AProVE-style dependency-pair strategy language carried by
  `DpOptions::strategy` and exposed through `dp(...)` inside the top-level
  `--strategy` language.
- Processor atoms:
  - `graph`: dependency-graph SCC decomposition.
  - `subterm` / `size-change`: size-change/subterm criterion.
  - `llm`: ask the configured LLM for a component reduction pair.
  - `weights`, `weights1`, `weights2`, or `weights(n)`: symbol-weight
    interpretations with the given maximum symbol weight.
  - `poly01`, `poly11`, `poly21`, `poly22`, `poly(c,a)`, or
    `poly(c,a,s,m)`: bounded linear polynomial interpretations with maximum
    constant `c`, coefficient `a`, optional symbol cap `s`, and optional arity
    cap `m`. Named form is also accepted:
    `poly(const=c, coeff=a, symbols=s, arity=m)`.
  - `rpo` / `path-order`: recursive path order with SAT-backed argument
    filtering.
  - `kbo` or `kbo(w)`: Knuth-Bendix order with SAT-backed argument filtering
    and maximum symbol weight `w`; bare `kbo` keeps the default `w = 2`.
    Named form is `kbo(weight=w)`.
  - `sat-poly`, `sat-poly(c,a)`, or `sat-poly(c,a,s,m)`: SAT-backed bounded
    linear polynomial search with maximum constant `c`, coefficient `a`,
    optional symbol cap `s`, and optional arity cap `m`; the bare atom keeps
    `c = 2, a = 1` and inherits the global symbol/arity caps. Named bounds use
    the same `const`, `coeff`, `symbols`, and `arity` keys as `poly`.
  - `smt-poly`, `smt-poly(c,a)`, or `smt-poly(c,a,s,m)`: external SMT-backed
    linear polynomial search with the same bounds as `sat-poly`.
  - `weak-poly`, `weak-poly(min,max,a)`, or `weak-poly(min,max,a,s,m)`:
    SMT-backed DP-only weak polynomial search with constants in
    `[min,max]`, nonnegative coefficients up to `a`, optional symbol/arity
    caps, and a checker-side natural-valuedness guard for all constrained
    terms. Named form is
    `weak-poly(min=min, max-constant=max, max-coefficient=a, max-symbols=s, max-arity=m)`.
  - `matrix`, `matrix(c,a)`, or `matrix(c,a,s,m)`: dimension-2 matrix
    interpretations with maximum vector constant `c`, matrix coefficient `a`,
    optional symbol cap `s`, and optional arity cap `m`. `matrix1` selects a
    dimension-1 matrix interpretation with default bounds. Named bounds use the
    same `const`, `coeff`, `symbols`, and `arity` keys as `poly`, plus optional
    `dim`.
  - `rat-poly`, `rat-poly(c,a,d)`, or `rat-poly(c,a,s,m,d)`: rational linear
    polynomial search with numerator bounds `c` and `a`, optional symbol/arity
    caps, and denominator `d`. The processor asks Z3/cvc5 for exact rational
    candidates first and falls back to SAT candidate enumeration for smaller
    local constraints; Ferrum's exact rational checker is still the trusted
    acceptance gate. Named form is
    `rat-poly(const=c, coeff=a, symbols=s, arity=m, denom=d)`.
  - `orders` / `red-pair`: alias that expands to the staged order sequence
    `llm; weights1; poly11; poly21; rpo; kbo; poly22; sat-poly; matrix;
    smt-poly; timeout(10s, rat-poly(16,16,12,3,4))`.
  - `narrow` / `narrowing`: bounded DP narrowing.
  - `instantiate` / `instantiation`: predecessor-based DP instantiation.
  - `forward-instantiate` / `forward-instantiation`: innermost-only
    successor-based DP forward instantiation.
- Combinators:
  - `a; b; c` or `a, b, c`: sequence/fallback in order.
  - `a | b`: choice/fallback branches.
  - `parallel(a | b | c)`: run strategy branches concurrently on the same
    DP component. Each branch receives independent proof statistics and the
    first successful branch in completion order supplies the committed proof.
  - `timeout(250ms, a)` or `timeout(2s, a)`: local processor timeout.
  - `repeat(3, a)` or `repeat(a)`: bounded repeated fallback, defaulting to
    16 iterations when no count is given.
- Local named sub-strategies may be declared at the front of a strategy string:
  - `let orders = parallel(rpo | kbo | sat-poly); graph; subterm; orders`
  - `def orders = parallel(rpo | kbo | sat-poly); graph; orders`
  - `orders := parallel(rpo | kbo | sat-poly); graph; orders`
  - A definition body containing a top-level sequence should be parenthesized,
    for example `let cheap = (graph; subterm); cheap; orders`.
  - User-defined names shadow built-in aliases such as `orders`.
- If `dp` is used without an explicit `dp(...)` body, Ferrum chooses a DP
  strategy from the input rewrite strategy.

DP parameter smoke check:

```console
printf '(VAR x)\n(RULES\n  f(s(x)) -> f(x)\n)\n' \
  > /tmp/ferrum-dp-param-strategy.trs

target/release/ferrum prove /tmp/ferrum-dp-param-strategy.trs \
  --strategy 'dp(graph; subterm; kbo(weight=1); sat-poly(const=1, coeff=1, symbols=4, arity=1); matrix(const=1, coeff=1, symbols=4, arity=1))' \
  --cpf /tmp/ferrum-dp-param-strategy.cpf3.xml \
  --cpf-mode cpf30 \
  --no-top-level-llm

./.tools/ceta-relative-bounds /tmp/ferrum-dp-param-strategy.cpf3.xml
```

Observed result:

```text
status: Terminating
step: DependencyPairProof { ... }
CERTIFIED
```

Default `TRS_Standard` / full-rewriting DP strategy:

```text
graph;
subterm;
timeout(250ms, llm);
timeout(2s, parallel(
  timeout(250ms, weights1) |
  timeout(500ms, poly11) |
  timeout(750ms, poly21) |
  timeout(1s, rpo) |
  timeout(1s, kbo) |
  timeout(2s, poly22) |
  timeout(2s, sat-poly) |
  timeout(2s, smt-poly)
));
timeout(2s, narrow)
```

Default `TRS_Innermost` DP strategy:

```text
graph;
subterm;
timeout(2s, parallel(
  timeout(250ms, weights1) |
  timeout(500ms, poly11) |
  timeout(750ms, poly21) |
  timeout(1s, rpo) |
  timeout(1s, kbo) |
  timeout(2s, poly22) |
  timeout(2s, sat-poly) |
  timeout(2s, smt-poly)
));
timeout(2s, narrow);
timeout(250ms, llm)
```

This means Ferrum first tries to solve the current cyclic DP component without
narrowing. Narrowing is only tried after dependency-graph decomposition,
subterm/size-change, and reduction-pair orders fail. If narrowing succeeds,
the narrowed residual recursively restarts the same strategy, so cheap
processors are tried first after the transformation.

Some processors are still outside this DP strategy language:

- Top-level direct order applications, currently LLM proposals, symbol weights,
  and linear polynomial interpretations, run before dependency pairs.
- For innermost TRSs, `removeNonApplicableRules` runs before the DP processor.
- Inside innermost DP proofs, `usableRulesProc` and
  `innermostLhssRemovalProc` are currently automatic wrappers/contexts rather
  than explicit strategy atoms. They influence the TRS rules/Q-context seen by
  reduction-pair processors.

These should eventually be lifted into a top-level strategy language and into
explicit DP context processors. DP component processing is now configured
through `dp(...)` inside the top-level `--strategy` language.

Nontermination strategy-language follow-up:

- Ferrum now has an explicit strategy for top-level nontermination search,
  embedded as `no(...)` / `nontermination(...)` inside the top-level
  `--strategy` language.
- Processor atoms:
  - `variable-condition`: malformed TRS variable-condition NO proof.
  - `loop` / `direct-loop`: one-step embedding loop search.
  - `narrowing` / `symbolic-narrowing`: bounded symbolic narrowing loop
    search.
  - `rewriting` / `bounded-rewriting`: bounded concrete rewriting loop search.
  - `dp-loop`: dependency-pair loop search, with `dpRuleRemovalProc` wrapping
    when extra dependency pairs are discarded.
  - `dp-rewriting`: dependency-pair rewriting followed by loop search.
  - `dp-instantiation`: dependency-pair instantiation followed by loop search.
  - `dp`: alias for `dp-loop; dp-rewriting; dp-instantiation`.
  - `all` / `default`: alias for the standard default NO strategy.
- Combinators match the DP strategy language:
  - `a; b; c` or `a, b, c`: sequence/fallback in order.
  - `a | b`: choice/fallback branches.
  - `timeout(250ms, a)` or `timeout(2s, a)`: local processor timeout.
  - `repeat(3, a)` or `repeat(a)`: bounded repeated fallback.

Default `TRS_Standard` and `TRS_Innermost` nontermination strategy:

```text
variable-condition;
loop;
timeout(1s, narrowing);
timeout(1s, rewriting);
dp-loop;
timeout(1s, dp-rewriting);
timeout(1s, dp-instantiation)
```

Top-level portfolio strategy follow-up:

- Ferrum now has a unified top-level strategy language, carried by
  `ProveOptions::strategy` and exposed as `--strategy`.
- Top-level primitive atoms:
  - `nontermination`: run the default NO strategy.
  - `nontermination(...)`: run the given NO sub-strategy.
  - `termination`: run the default YES branch.
  - `weights`, `weights1`, `weights2`, or `weights(n)`: run the top-level
    symbol-weight processor with maximum symbol weight `n`.
  - `poly01`, `poly11`, `poly21`, `poly22`, `poly(c,a)`,
    `poly(c,a,s,m)`, `polynomial(c,a)`, or `polynomial(c,a,s,m)`: run the
    top-level linear-polynomial rule-removal processor with maximum constant
    `c`, coefficient `a`, optional symbol cap `s`, and optional arity cap `m`.
    Named forms such as `poly(const=2, coeff=1, symbols=17, arity=3)` are
    accepted for reproducible benchmark strategies.
    This includes recursive partial rule removal when the polynomial weakly
    orients all rules and strictly removes a non-empty subset.
  - `kbo` or `kbo(w,s)`: run top-level KBO rule removal with maximum symbol
    weight `w` and symbol cap `s`; `kbo(w)` uses symbol cap 8. Named form is
    `kbo(weight=w, symbols=s)`.
  - `dp`: run the DP termination processor using the default DP strategy.
  - `dp(...)`: run the DP termination processor with the given DP sub-strategy.
    DP sub-strategy names are scoped inside the `dp(...)` body, for example
    `dp(let orders = parallel(weights1 | poly11 | sat-poly); orders)`.
- Top-level combinators:
  - `a; b; c` or `a, b, c`: sequence/fallback in order.
  - `a | b`: choice/fallback.
  - `parallel(a | b | c)`: run top-level proof branches concurrently.
  - `timeout(2s, a)` / `timeout(250ms, a)`: bounded top-level branch.
  - local names via `let p = parallel(nontermination | termination); p`,
    `def p = ...`, or `p := ...`.
- The default standard and innermost top-level strategy is checked in at
  `strategies/default.fs`:

Top-level parameter smoke check:

```console
printf '(RULES\n  a -> b\n)\n' > /tmp/ferrum-top-poly-strategy.trs
target/release/ferrum prove /tmp/ferrum-top-poly-strategy.trs \
  --strategy 'poly(1,1,2,0)' \
  --cpf /tmp/ferrum-top-poly-strategy.cpf3.xml \
  --cpf-mode cpf30 \
  --no-top-level-llm \
  --no-synthesize-symbol-weights

./.tools/ceta-relative-bounds /tmp/ferrum-top-poly-strategy.cpf3.xml
```

Observed result:

```text
status: Terminating
step: SynthesizedLinearPolynomial { interpretations: [("a", 1, []), ("b", 0, [])] }
CERTIFIED
```

```text
let no = nontermination(
    variable-condition;
    loop;
    timeout(1s, narrowing);
    timeout(1s, rewriting);
    dp-loop;
    timeout(1s, dp-rewriting);
    timeout(1s, dp-instantiation)
  );
let yes = termination;
parallel(no | yes)
```

- `ProveOptions::default()` parses `strategies/default.fs`; a regression test
  checks that this checked-in file parses and is the strategy used by default.
- In that default strategy, Ferrum launches a NO branch using the default
  nontermination strategy and a YES branch using the default termination
  strategy concurrently. It returns a nonterminating proof if the NO branch
  succeeds, otherwise a terminating proof if the YES branch succeeds, otherwise
  `Unknown`.
- There are no separate compatibility flags for nested proof strategies:
  top-level branching, NO sub-strategies, and DP sub-strategies are all
  expressed with `--strategy`.
- The default NO strategy enumerates every implemented nontermination
  processor, including the DP processors that previously lived behind one
  opaque dependency-pair hint. Innermost loop checks still validate the
  innermost side condition before accepting a loop proof.

Verified CLI example:

```console
cat >/tmp/ferrum-strategy-narrowing.trs <<'EOF'
(VAR x y)
(RULES
  f(s(x)) -> f(g(s(x)))
  g(s(y)) -> y
)
EOF

cargo run -- prove /tmp/ferrum-strategy-narrowing.trs \
  --no-synthesize-symbol-weights \
  --strategy 'dp(graph; subterm; weights(1); poly(1,1); rpo; kbo; sat-poly; smt-poly; timeout(2s, narrow))' \
  --cpf /tmp/ferrum-staged-strategy.cpf3.xml \
  --cpf-mode cpf30

xmllint --huge --noout \
  --schema .tools/cpf3/cpf3/xml/cpf3.xsd \
  /tmp/ferrum-staged-strategy.cpf3.xml

./.tools/ceta-relative-bounds /tmp/ferrum-staged-strategy.cpf3.xml
```

Observed result:

```text
status: Terminating
CPF contains narrowingProc followed by sizeChangeProc
/tmp/ferrum-staged-strategy.cpf3.xml validates
CERTIFIED
```

Regression coverage includes DP and NO strategy parsing, timeout parsing,
explicit order-atom parsing, orders-before-narrowing behavior, default NO
strategy processor coverage, and narrowing-then-size-change behavior.

TermCOMP 2025 VBS-NO benchmark run:

- Goal: run Ferrum on every TermCOMP 2025 TRS Standard or TRS Innermost
  benchmark for which at least one competition prover reported `NO`.
- Source pages:
  - `https://termcomp.github.io/Y2025/TRS_Standard.html`
  - `https://termcomp.github.io/Y2025/TRS_Innermost.html`
- Parsed problem list:
  - `/tmp/ferrum-vbs-no-list.json`
  - 353 total problems.
  - 345 from `TRS_Standard`.
  - 8 from `TRS_Innermost`.
- Ferrum mode: NO-focused search, with expensive YES-oriented processors
  disabled. This was chosen because the requested set is exactly the examples
  some prover proves nonterminating.
- Per-problem command shape:

```console
target/release/ferrum prove PROBLEM \
  --cpf proof.cpf3.xml \
  --cpf-mode cpf30 \
  --no-top-level-llm \
  --no-synthesize-symbol-weights
```

- Harness:
  - `/tmp/ferrum_run_vbs_no_chunk.py`
  - `TIMEOUT=10`
  - `JOBS=8`
  - chunks: `0-64`, `64-128`, `128-192`, `192-256`, `256-320`, `320-353`.
  - chunk result files: `/tmp/ferrum-vbs-no-focused-START-END.json`.
- Combined result file:
  - `/tmp/ferrum-termcomp-2025-vbs-no-no-focused-results.json`

Observed results after the innermost loop-certification fix:

| Set | Total VBS-NO | Ferrum NO | CeTA-certified NO | Unknown | Timeout |
| --- | ---: | ---: | ---: | ---: | ---: |
| TRS Standard | 345 | 165 | 165 | 124 | 56 |
| TRS Innermost | 8 | 4 | 4 | 2 | 2 |
| Combined | 353 | 169 | 169 | 126 | 58 |

NO proof-kind breakdown:

| Proof kind | Count |
| --- | ---: |
| Direct loop | 109 |
| Variable-condition violation | 60 |

Certification note:

- An earlier run found two innermost candidates,
  `TRS_Innermost/Mixed_innermost/run_again1.ari` and
  `TRS_Innermost/Mixed_innermost/run_again2.ari`, where Ferrum emitted
  symbolic loop certificates that CeTA rejected because the chosen root step
  was not an innermost step after applying the loop-closing substitution.
- Ferrum now checks symbolic loop proofs against the TRS strategy before
  reporting them. For innermost systems, every selected redex must have proper
  subterms in normal form under the original rules after applying the closing
  substitution.
- After this fix, all Ferrum `NO` results in this VBS-NO run are
  CeTA-certified.

Verification commands used after this change:

```console
cargo fmt -- --check
cargo test
cargo clippy -- -D warnings
cargo build --release
```
# Top-1 utility-guidance experiment (2026-07-24)

The compact top-1 manifest was exported from the canonical current-subproblem
SQLite aggregation:

```bash
python scripts/export_utility_guidance_lookup.py \
  --sqlite target/termcomp-proof-corpus/training/hrm-status-map-current-balanced-v3-20260723/ferrum.status-map.current-balanced-v3.sqlite \
  --canonical-cache target/termcomp-proof-corpus/training/canonical-cpf-cache.sqlite \
  --output target/termcomp-proof-corpus/training/utility-guidance-v1/top1-positive.jsonl
```

This produced 4,524 canonical positive states and 3,855 raw-state aliases,
8,379 manifest rows in total (about 2.2 MiB). Selection is deterministic:
positive status only, then descending utility and status rank, ascending known
elapsed time, and lexical candidate order. Meta-atoms are excluded.

The implementation was checked with:

```bash
export RUSTUP_HOME=/home/ucloud/.rustup
cargo +1.95.0 test utility_lookup

target/debug/ferrum prove ../TPDB-ARI/TRS_Standard/SK90/2.30.ari \
  --utility-guidance-manifest \
    target/termcomp-proof-corpus/training/utility-guidance-v1/top1-positive.jsonl \
  --processor-events target/utility-guidance-smoke-sk90-v2.jsonl

target/debug/ferrum prove ../TPDB-ARI/TRS_Standard/Secret_06_TRS/6.ari \
  --utility-guidance-manifest \
    target/termcomp-proof-corpus/training/utility-guidance-v1/top1-positive.jsonl \
  --processor-events target/utility-guidance-smoke-dp-v2.jsonl
```

`SK90/2.30` was closed by the single top-level polynomial suggestion.
`Secret_06_TRS/6` fell back after its top-level suggestion, then the selected
DP matrix processor closed the component. A separate miss smoke on
`Waldmann_06/jwno8` recorded lookup misses at both levels and continued into
the normal strategy. CPF3 proofs from both successful smokes were independently
accepted by CeTA:

```text
.tools/ceta target/utility-guidance-sk90-cpf3.xml
CERTIFIED
.tools/ceta target/utility-guidance-secret6-cpf3.xml
CERTIFIED
```

A paired fixed-seed smoke used 32 random TRS Standard inputs, eight workers,
seed `20260724`, and `--timeout-multiplier 0.25`:

| arm | completed | YES | unknown | wall time |
|---|---:|---:|---:|---:|
| ordinary strategy | 32/32 | 8 | 24 | 227 s |
| top-1 utility then fallback | 24/32 | at least 13 | 11 completed + 8 externally timed out | 369 s |

The lookup arm was stopped by a 360-second batch-wide guard. This was not
evidence of a per-problem timeout violation: the quarter multiplier scales the
outer 300-second strategy timeout to 75 seconds, so four eight-worker waves can
legitimately approach 300 seconds before scheduling overhead. Before the guard
it had already exceeded the baseline's final score by five YES results. Across
all 32 started problems, lookup coverage was:

| level | queries | hits | distinct hit problems | successful guided queries |
|---|---:|---:|---:|---:|
| top level | 32 | 13 | 13 | 6 |
| dependency pair | 88 | 32 | 12 | 32 |

Sixteen distinct problems had at least one successful guided query. This is
deliberately an in-dataset oracle measurement, so it is evidence for the
potential value of ranking, not a generalization score.

For the full evaluation, `scripts/termcomp_trs_compare.py` now launches every
Ferrum and CeTA invocation in a fresh process session. On timeout it sends
`SIGTERM` and then `SIGKILL` to the entire process group and stores partial
stdout/stderr before recording the result. This is the hard 305-second
per-example boundary; Rust's internal strategy deadlines remain cooperative
and provide a five-second cleanup margin through `timeout(300s, default)`.

## RFC set-level checker and large witness (2026-07-24)

The RFC checker development now uses the persistent isolated Isabelle home
`/home/ucloud/.isabelle/ferrum_rfc`. Its `etc/settings` points `AFP` at
`ferrum/.tools/afp-current/thys`. This avoids the shared session-database
collisions seen with concurrent CeTA work while retaining the copied dependency
heaps.

The formal checker was strengthened without changing the semantic theorem:

- Matchbox closure checks one automaton-result inclusion per rule and tail,
  then derives every split obligation with the proved word-append lemma.
- Right extension likewise checks inclusion between the complete prefix and
  RHS result sets instead of scanning every declared state.
- No-top checking intersects the LHS result with the declared-state set.
- Ferrum emits CPF `<compatibility/>` when an explicit relation is entirely
  reflexive. Non-identity relations remain explicit.

The identity canonicalization is important for large witnesses: the old CPF
encoded 2,044 reflexive relation entries and selected CeTA's general coherence
checker. The canonical CPF selects the equivalent identity checker directly.

Formal builds:

```console
ISABELLE_IDENTIFIER=ferrum_rfc \
  /work/dfm/festschrift/ferrum/.tools/Isabelle2025-2/bin/isabelle build \
  -d /work/dfm/festschrift/CeTA-rfc/thys -j 16 RFC_Checker_Ext

ISABELLE_IDENTIFIER=ferrum_rfc \
  /work/dfm/festschrift/ferrum/.tools/Isabelle2025-2/bin/isabelle build \
  -d /work/dfm/festschrift/CeTA-rfc/thys -j 16 Proof_Checker Code
```

The final RFC layer took 26 seconds; the loaded unified build took 13m43s under
heavy concurrent machine load. The verified source is committed on the local
CeTA-rfc branch `ferrum-rfc-bounds` as `cd08c1d`. The exported checker is:

```text
/work/dfm/festschrift/CeTA-rfc/thys/Code/Bar/ceta-rfc-set-closure-v7-linux-20260724
sha256 cb1e44ca316937d7a5447fa5a28d87799d44c3ccf409582f701fafc0deb10fdd
```

It is installed as `.tools/ceta-relative-bounds`. The previous paired-v2
checker is retained as
`.tools/ceta-relative-bounds.pre-set-closure-v7-20260724`, SHA-256
`f5bf82d80ac871d21c496f61e527e1df37818995cbb33ececaf8b90d0315fd5f`.

Ferrum's larger focused witness for
`SRS_Standard/ICFP_2010/107193.ari` used:

```console
target/release/ferrum prove \
  /work/dfm/festschrift/TPDB-ARI/SRS_Standard/ICFP_2010/107193.ari \
  --cpf target/rfc-set-ext-v6-probe-20260724/107193.cpf3.xml \
  --cpf-mode cpf30 \
  --processor-events target/rfc-set-ext-v6-probe-20260724/107193.progress.jsonl \
  --strategy \
  'timeout(30s,rfc-relative-match-bounds(max-bound=3,max-words=10000,max-word-len=128,max-states=10000,max-transitions=250000,at-bound=merge,closure=right))'
```

Ferrum found the bound-0 witness in 11.5 seconds. It has 2,044 states, 1,971
symbol transitions, and 3,471 epsilon transitions. The final checker reports
`CERTIFIED` in about 155 seconds. Stage tracing attributes roughly 25-30
seconds to RFC closure, 50-60 seconds to right extension, and 40-45 seconds to
no-top checking; generic relative-bounds checking is negligible. All 12 proofs
from `20260724-rfc-paired-v2-189-32w-20s` also certify with the new checker
under 60 seconds each.

The same fixed 189-example set was rerun with 32 workers, a 30-second RFC
processor budget, a 40-second outer/checker budget, and full artifacts:

```text
target/termcomp-runs/20260724-rfc-large-caps-189-32w-40s-v2
```

| Run | YES | Certified YES | MAYBE | CeTA timeout | Other cert failure |
| --- | ---: | ---: | ---: | ---: | ---: |
| 2,000 states / 50,000 transitions | 12 | 12 | 139 | 0 | 0 |
| 10,000 states / 250,000 transitions | 155 | 101 | 34 | 54 | 0 |

This is a gain of 143 raw YES with no losses. All 54 certification gaps are
literal `CeTA timeout` results; none is a rejected or malformed certificate.
The run completed in 244 seconds wall-clock and retained every CPF, progress
log, command, and checker output.

Rust verification:

```console
cargo +1.95.0-x86_64-unknown-linux-gnu fmt -- --check
cargo +1.95.0-x86_64-unknown-linux-gnu test --lib \
  canonical_identity_compatibility --jobs 16
cargo +1.95.0-x86_64-unknown-linux-gnu build --release --jobs 32
```

## Ranked utility evidence and canonical processor campaign (2026-07-24)

The positive-only utility manifest was replaced by ranked evidence over all
observed canonical states:

```console
python scripts/export_utility_guidance_lookup.py \
  --sqlite target/termcomp-proof-corpus/training/hrm-status-map-current-balanced-v3-20260723/ferrum.status-map.current-balanced-v3.sqlite \
  --canonical-cache target/termcomp-proof-corpus/training/canonical-cpf-cache.sqlite \
  --output target/termcomp-proof-corpus/training/utility-guidance-v2/ranked-evidence.jsonl
```

The output has 24,074 canonical rows and 23,895 raw-hash aliases. Canonical
rows retain ranked `prefer`, `possible`, `avoid`, and `timeout` evidence,
including attempt counts, outcome counts, elapsed time, and utility.

Canonical CPF inputs can now be probed directly and used to enlarge the event
corpus. This command runs one exploitation and one exploration trial per
state, with eight independent workers:

```console
python scripts/run_canonical_processor_campaign.py \
  --source-db target/termcomp-proof-corpus/training/hrm-status-map-current-balanced-v3-20260723/ferrum.status-map.current-balanced-v3.sqlite \
  --run-dir target/canonical-processor-campaign-2s \
  --ferrum target/release/ferrum \
  --jobs 8 \
  --exploit 1 \
  --tighten 2 \
  --explore 1 \
  --timeout-ms 2000 \
  --seed 0
```

`campaign.sqlite` is the resumable trial ledger and
`processor-events.jsonl` is directly consumable by the existing credited
status-map builder. The final smoke in
`target/canonical-campaign-smoke-v3` used eight source states and scheduled
nine trials: one solved, one transformed, six failed, and one timed out. Its
30 internal processor events described 12 distinct current CPF subproblems,
demonstrating that post-transformation states are retained. Thirteen rows
carried the first inline CPF and 17 referenced an earlier content hash. The
builder resolved all 17 references. Repeating the same campaign configuration
schedules zero work and does not duplicate event rows.

A focused validity/parameter smoke is retained in
`target/canonical-campaign-validity-smoke-v2`. It used one sound/incomplete
top-level state and one unsound/complete DP state. Six trials produced:

| lane | candidate | result |
|---|---|---|
| tighten | `sat-poly(max-constant=1,max-coefficient=1)` from `(2,1)` | terminating |
| tighten | `sat-poly(max-constant=0,max-coefficient=1)` from `(2,1)` | failed |
| tighten | `poly(max-constant=2,max-coefficient=1)` from `(2,2)` | transformed |
| tighten | `poly(max-constant=0,max-coefficient=1)` from `(2,2)` | transformed |
| diagnostic YES | DP `termination` | terminating |
| diagnostic NO | `nontermination` | timeout |

After credited-status-map ingestion, the two canonical states retained
validity masks 2 and 4 respectively. Campaign event rows include the source
candidate, validity mask, lane, and diagnostic-only flag.

The non-synthetic trace
`target/canonical-campaign-narrow-validity-v1` probes a stored DP state with
the selective narrowing processor. Its outer event has input mask 1 and
post-transform completeness false; the recursive residual event has input
mask 2. Re-ingestion in `status-map-v2.sqlite` materialized one state in each
mask, confirming that real transformed subproblems drive the diagnostic lane.
Feeding that database back through the campaign in
`target/canonical-campaign-narrow-dual-v3` scheduled exactly one
`diagnostic-no` trial on the mask-2 DP residual. The exact-pair
loop/rewriting/instantiation portfolio returned `Unknown` in 8 ms. An earlier
smoke exposed the combinatorial DP nonloop phase exceeding its cooperative
deadline; that phase was removed from short exact-QDP campaign probes rather
than relying on the external process kill.

A tightening-only sample over the first 100 canonical states is retained in
`target/canonical-campaign-tightening-100-v1`:

```console
python scripts/run_canonical_processor_campaign.py \
  --source-db target/termcomp-proof-corpus/training/hrm-status-map-current-balanced-v3-20260723/ferrum.status-map.current-balanced-v3.sqlite \
  --run-dir target/canonical-campaign-tightening-100-v1 \
  --ferrum target/release/ferrum \
  --jobs 8 --exploit 0 --tighten 2 --explore 0 \
  --no-dual-probe --timeout-ms 2000 --limit 100
```

Only 15 of the 100 states had untried variants among their first two
tightening candidates, producing 30 trials:

| outcome | trials |
|---|---:|
| solved | 6 |
| transformed | 9 |
| failed | 15 |

The six solved variants comprised two SAT-polynomial constant reductions
`2 -> 1`, two dimension-1 matrix constant reductions `2 -> 1`, one matrix
dimension reduction `2 -> 1`, and one polynomial coefficient reduction
`2 -> 1`. All 68 emitted internal events retained their source candidate.

Verification:

```console
cargo +1.95.0 test cpf_input
cargo +1.95.0 test utility_lookup
cargo +1.95.0 test compact_processor_events
python -m py_compile \
  scripts/run_canonical_processor_campaign.py \
  scripts/test_canonical_processor_campaign.py \
  scripts/build_credited_status_map_dataset.py \
  scripts/export_utility_guidance_lookup.py
python -m unittest scripts/test_canonical_processor_campaign.py
```

## Verified RFC transition index (2026-07-24)

The RFC checker now indexes every lifted unary-symbol transition bucket by its
LHS state with the verified `elem_list_to_rm` red-black-tree implementation.
For a word position, the checker constructs that index once and shares it over
all tail-state evaluations. Closure, right-extension, and no-top-redex checks
all use the batched evaluator.

The development theory proves the indexed step extensionally equal to the
former transition scan, lifts that equality through complete word evaluation,
and proves the three indexed Boolean checks equal to their original
specifications. The soundness theorem therefore remains stated through the
existing semantic predicates.

Formal builds:

```console
ISABELLE_IDENTIFIER=ferrum_rfc \
  /work/dfm/festschrift/ferrum/.tools/Isabelle2025-2/bin/isabelle build \
  -d /work/dfm/festschrift/CeTA-rfc/thys -j 16 RFC_Checker_Ext

ISABELLE_IDENTIFIER=ferrum_rfc \
  /work/dfm/festschrift/ferrum/.tools/Isabelle2025-2/bin/isabelle build \
  -d /work/dfm/festschrift/CeTA-rfc/thys -j 16 Proof_Checker Code
```

The RFC layer took 12 seconds. The loaded unified build took 10m33s:
`Proof_Checker` 5m35s, `IsaFoR_3` 6m45s in parallel, and `Code` 3m32s.
The Isabelle export was compiled with GHC 9.6.7 as:

```text
/work/dfm/festschrift/CeTA-rfc/thys/Code/Bar/ceta-rfc-index-v11-linux-20260724
sha256 c6f34b13cf45b5ff7449d3dfa75bba7125303e90b91b43ff696d4ec9e5ac6492
```

It is installed as `.tools/ceta-relative-bounds`. The former v10 checker is
retained as `.tools/ceta-relative-bounds.pre-index-v11-20260724`, SHA-256
`ee4818b997f7bd4f3af16d917e5160bd66fa6b26c684a76b03875ac900b6817e`.

On the unchanged 2.8 MiB, 2,044-state `ICFP_2010/107193.ari` certificate,
v11 reports `CERTIFIED` in 14.85 seconds, down from 54.4 seconds on v10.
The fixed 155 retained large-cap RFC certificates were checked with 32
workers and a 40-second per-certificate timeout:

| Certificates | Certified | Timeout | Rejected | Slowest |
| ---: | ---: | ---: | ---: | ---: |
| 155 | 155 | 0 | 0 | 34.45s |

Full stdout, stderr, elapsed time, exit status, and certificate paths are in:

```text
target/checker-runs/20260724-rfc-index-v11-fixed155-40s
```

## Certified strict RFC completion (2026-07-24)

Ferrum's paired-tail Matchbox RFC construction now computes strict below-top
compatibility in the same fixed point as closure and right extension. Missing
RHS runs discovered by closure are completed through the rule's canonical tail
before epsilon closure is recomputed. Candidate selection rechecks strict
compatibility, Matchbox closure, right extension, no top redex, and configured
size limits before CPF export.

RFC search is split into two passes. The bounded right-barren construction is
tried at every bound before the one-state and generic completion fallbacks are
run. This preserves the fallback search space while preventing an expensive
bound-0 fallback from consuming the processor deadline before a cheap bound-1
barren witness is attempted.

Verification:

```console
cargo +1.95.0-x86_64-unknown-linux-gnu test --lib rfc_ --jobs 32
cargo +1.95.0-x86_64-unknown-linux-gnu build --release --jobs 64
```

There are 18 active RFC tests, all passing, plus one ignored diagnostic test.
The regression `ICFP_2010/140639.ari` now produces a bound-1
`<rfcMatchboxRelativeBounds>` certificate. The installed verified checker
`.tools/ceta-relative-bounds` returns `CERTIFIED`.

The final fixed 189-example direct RFC run used 32 workers, a 40-second
external timeout, a 30-second processor timeout, and retained full artifacts:

```console
python scripts/termcomp_trs_compare.py \
  --tpdb /work/dfm/festschrift/TPDB-ARI \
  --ferrum target/release/ferrum \
  --ceta .tools/ceta-relative-bounds \
  --jobs 32 --timeout 40 --category SRS_Standard \
  --ferrum-profile default \
  --from-details target/termcomp-runs/20260724-rfc-large-caps-189-32w-40s-v2/details.json \
  --include-status yes --include-status unknown \
  --run-dir target/termcomp-runs/20260724-rfc-complete-certified189-32w-40s \
  --extra-arg=--strategy \
  '--extra-arg=timeout(30s,rfc-relative-match-bounds(max-bound=3,max-words=10000,max-word-len=128,max-states=10000,max-transitions=250000,at-bound=merge,closure=right))' \
  --extra-arg=--no-top-level-llm
```

| Problems | YES | Certified YES | MAYBE | Timeout | Cert failed |
| ---: | ---: | ---: | ---: | ---: | ---: |
| 189 | 189 | 189 | 0 | 0 | 0 |

The run completed in 64 seconds wall-clock. Per-example commands, progress
events, stdout/stderr, CPF files, and CeTA outputs are under
`target/termcomp-runs/20260724-rfc-complete-certified189-32w-40s`.
# Iterative oracle campaign (2026-07-24)

The first two exploitation/exploration rounds start from the current
canonical-state database and utility-guidance v2 manifest:

```bash
python scripts/run_iterative_data_campaign.py \
  --campaign-dir target/data-campaign/oracle-two-round-20260724 \
  --jobs 8 \
  --rayon-threads 8
```

The campaign interleaves TRS Standard, TRS Innermost, SRS Standard, and TRS
Context-sensitive roots. R00 uses timeout multiplier `0.25`; R01 starts from
R00's rebuilt oracle and uses `0.50`. Whole-system memory is guarded at 2 TiB,
and each root proof runs in its own process group. Progress and all root
artifacts are under `target/data-campaign/oracle-two-round-20260724/`.

The utility oracle is dual-indexed. Canonical CPF hashes own the evidence;
exact non-canonical hashes from `canonical-cache.sqlite` are aliases to those
records. Ferrum checks the current raw CPF first and canonicalizes only on a
miss. Guidance event sources report `utility-lookup-raw` or
`utility-lookup-canonical`. Future event logs retain raw current-state CPF and
the offline aggregation pass adds both its canonical state and raw alias.

Canonical processor probes now request CPF output and run CeTA before recording
a positive result. Complete subproblem proofs use
`.tools/ceta-relative-bounds`; transformed fragments use the verified
assumption-capable `.tools/ceta-relative-bounds.bin --allow-assumptions`.
The latter is recorded as `certified-fragment`, meaning that CeTA checked the
processor and residual obligation under an explicit assumption. Per-trial
certificate metadata is in `canonical/campaign.sqlite`, with the input,
certificate, and checker logs retained below `canonical/artifacts/`.

## Native Matchbox RFC checker layer (2026-07-24)

Height-aware Matchbox merge certification is being developed in the isolated
worktree `/work/dfm/festschrift/CeTA-rfc-native`, branch
`ferrum-rfc-native`. The first tracked milestones are:

- `5d12755`: boundary-sensitive executable RFC word evaluation and its proved
  equality with the abstract word-run semantics;
- `14ca479`: executable native closure, right-extension, and no-top predicates,
  with semantic elimination lemmas;
- `61290af`: bounded height-vector generation and the executable two-epsilon
  inner-splice obligation used by Matchbox merge.
- `54c633c`: decomposition of native runs over `prefix @ suffix`, proving that
  the only boundary effect is the checked epsilon closure between the two
  non-empty words.
- `9fb7280`: equivalence between an ordinary unary tree-automaton run and a
  native labeled run with epsilon closure at its two outer boundaries. This is
  the bridge needed to derive standard state compatibility from checked
  Matchbox splice obligations.

The development session deliberately uses the already built `IsaFoR_2` heap
from the main CeTA source catalog, while loading only the RFC theory from the
isolated worktree:

```console
AFP=/work/dfm/festschrift/ferrum/.tools/afp-current/thys \
ISABELLE_IDENTIFIER=ferrum_rfc \
/work/dfm/festschrift/ferrum/.tools/Isabelle2025-2/bin/isabelle build \
  -o timeout=1800 -j 4 \
  -d /work/dfm/festschrift/CeTA-rfc/thys \
  -d /work/dfm/festschrift/CeTA-rfc-native/dev \
  RFC_Native_Ext
```

This rebuilds the RFC layer in 12-14 seconds and does not rebuild `IsaFoR_1`
or `IsaFoR_2`. At `61290af` the executable obligations are verified, but the
full fixed-point-to-relative-match-boundedness theorem and CPF dispatch are
still pending. Consequently, these new height-aware witnesses must not yet be
reported as `CERTIFIED`; the existing 189-example certified RFC baseline is
unchanged.

### Native splice compatibility bridge (2026-07-24)

The native checker layer now also proves:

- correctness of `rfc_native_labeled_word_res_impl` for arbitrary per-symbol
  heights, not only uniform lifts;
- semantic elimination of the executable inner-splice predicate, including
  collapsing right-hand sides and the two permitted epsilon boundaries;
- exact-state (`Id`) compatibility for every checked labeled SRS rule; and
- full bounded strict compatibility by splitting below-top labeled words from
  the all-maximum-height case, where `rfc_native_no_top_redex_impl` rules out
  an accepting left-hand-side run.

The isolated verification command remains:

```console
AFP=/work/dfm/festschrift/ferrum/.tools/afp-current/thys \
ISABELLE_IDENTIFIER=ferrum_rfc \
/work/dfm/festschrift/ferrum/.tools/Isabelle2025-2/bin/isabelle build \
  -o timeout=1800 -j 4 \
  -d /work/dfm/festschrift/CeTA-rfc/thys \
  -d /work/dfm/festschrift/CeTA-rfc-native/dev \
  RFC_Native_Ext
```

The build succeeds without `sorry` or `oops`. This closes the
implementation-to-state-compatibility gap, but does not yet change the
certified benchmark score: a distinct native CPF processor must still combine
the theorem with the initial-language/right-forward-closure argument and then
be emitted by Ferrum.

### Unified native RFC checker and executable (2026-07-24)

The pending integration described above is complete on
`/work/dfm/festschrift/CeTA-rfc-native`, branch `ferrum-rfc-native`, commit
`12396ab`. The unified proof checker now parses
`<rfcNativeMatchboxRelativeBounds>`, dispatches it to the executable
`rfc_native_matchbox_relative_bounds_tt`, and derives strong normalization of
the relative RFC problem. The checker accepts only `Match` bounds; rejecting
`Roof` is necessary because the proved semantic theorem uses non-duplication.

The isolated RFC layer builds against the persistent `IsaFoR_2` heap in about
20 seconds:

```console
AFP=/work/dfm/festschrift/ferrum/.tools/afp-current/thys \
ISABELLE_IDENTIFIER=ferrum_rfc \
/work/dfm/festschrift/ferrum/.tools/Isabelle2025-2/bin/isabelle build \
  -o timeout=1800 -j 4 \
  -d /work/dfm/festschrift/CeTA-rfc-native/thys \
  RFC_Checker_Ext
```

The unified `Proof_Checker` build took 5 minutes 41 seconds on the loaded
machine. Code export and `make haskell GHC_ARGS='-j16'` produced
`/work/dfm/festschrift/CeTA-rfc-native/ceta`. The rebuilt executable certifies
the real TermCOMP problem `SRS_Standard/ICFP_2010/4046.ari` using Ferrum's
existing `<rfcMatchboxRelativeBounds>` proof:

```console
/work/dfm/festschrift/CeTA-rfc-native/ceta \
  target/rfc-native-certified-small-20260724/4046/proof.cpf3.xml
# CERTIFIED
```

Ferrum now emits the native tag only after independently evaluating all native
closure, right-extension, bounded inner-splice, and no-top-redex obligations.
Native inner-splice construction is speculative and stops after 16 automaton
updates per bound so that it cannot consume the whole processor budget before
the more productive relation-based certified constructor runs. This limit
affects proof search only; CeTA checks every emitted witness without truncation.
The native identity/epsilon checker is strictly more restrictive than the
relation-based `<rfcMatchboxRelativeBounds>` checker. Probes over 120 smallest
TPDB SRS files and 160 small Wenzel examples found no native witness, while 17
of the first set retained relation-based certified RFC witnesses. On
`Zantema_04/z051.ari`, native inner-splice completion reaches a fixed point,
but the added top-height paths create a top-layer redex. Thus relation-based
RFC remains the productive certified path; native completion is retained as a
sound search strengthening and is not counted as additional benchmark power.
All probe artifacts are under
`target/rfc-native-small-tpdb-probe-20260724/` and
`target/rfc-native-wenzel-probe-20260724/`.

### Relation-preserving native RFC checking (2026-07-25)

The native checker no longer has to discard a productive Matchbox state
relation. In `/work/dfm/festschrift/CeTA-rfc-native`, branch
`ferrum-rfc-native`, `rfc_native_rel_matchbox_relative_bounds_tt` checks native
word-run closure and paired-tail right extension using the certificate
relation. Paired tails must be closed under reflexive-transitive epsilon
reachability, which ensures that removing the outer epsilon boundary does not
leave the checked tail set. Its soundness theorem derives the existing
`rfc_matchbox_relative_bounds_tt` result using state coherence, then reuses the
established relative RFC strong-normalization theorem. Both
`RFC_Checker_Ext` and the unified `Proof_Checker` sessions build without
`sorry` or `oops`.

Ferrum independently validates the same native relational obligations before
emitting `<rfcNativeMatchboxRelativeBounds>`. Identity-native witnesses retain
their stronger bounded inner-splice check and erase the relation; relational
native witnesses retain it. Shared weak compatibility, below-top strict
compatibility, and no-top checks are now evaluated once.

A four-worker, full-artifact probe of the 20 smallest problems from the fixed
189-example direct RFC corpus is stored at:

```text
target/termcomp-runs/20260725-rfc-native-relational-direct20/
```

It produced 9 YES, 8 certifications with the previous identity-only executable,
11 timeouts, and one expected certification failure.
`SRS_Standard/Zantema_04/z061.ari` is that distinguishing example. Its recorded
obligations are:

```text
identity_ext_right=false
relational_closed=true
relational_tails_eps_closed=true
relational_ext_right=true
no_top=true
below_top_strict=true
weak_compatible=true
legacy_ext_right=true
```

The old executable rejects the native tag at right extension. The regenerated
relation-preserving executable certifies this retained CPF artifact:

```text
target/termcomp-runs/20260725-rfc-native-relational-direct20/\
SRS_Standard/z061/proof.cpf3.xml
```

Recertifying all nine YES artifacts with the regenerated executable gives
9 `CERTIFIED` and 0 rejected proofs. The per-example checker output and compact
result table are retained as `ceta-relational.{stdout,stderr}` and
`recertification-with-relational-ceta.tsv` inside the run directory.

The generated executable is installed as `.tools/ceta-relative-bounds`:

```text
sha256 0d32a53e9158ee2a17dc722e5f178b5b1a4bc0a73f910900b2f0772ed774bbe0
```
## 2026-07-25 Bounds proof normalization

This work is deliberately staged: no bounds processor, strategy atom, proof
variant, or CeTA checker form was removed.

Ferrum now supports the opt-in meta-strategy
`normalize-bounds(strategy)`. It runs the nested strategy unchanged and then
normalizes a successful termination proof:

- `<bounds>` becomes all-rule `<relativeBounds>` with an empty residual;
- `<rfcBounds>` becomes all-rule `<rfcRelativeBounds>`;
- `<rfcAutomatonClosedBounds>` becomes all-rule
  `<rfcAutomatonClosedRelativeBounds>`;
- `<rfcNativeMatchboxRelativeBounds>` becomes
  `<rfcMatchboxRelativeBounds>`;
- nested residual proofs are normalized after carrying the current TRS through
  polynomial, KBO, path-order, non-applicable-rule, relative-bounds, and string
  reversal steps.

The original proof objects and strategy processors remain available for direct
comparison. `scripts/normalize_bounds_cpf.py` applies the same normalization to
a retained CPF without rerunning proof search.
`scripts/check_bounds_normalization_corpus.py` preserves the source CPF,
normalized CPF, CeTA stdout/stderr, and JSON result for every checked
certificate.

Focused checks:

```console
cargo +1.95.0-x86_64-unknown-linux-gnu test --lib normalized_ --jobs 32
cargo +1.95.0-x86_64-unknown-linux-gnu test --lib bounds_normalization --jobs 32
cargo +1.95.0-x86_64-unknown-linux-gnu test --lib finite_rfc_normalization --jobs 32
cargo +1.95.0-x86_64-unknown-linux-gnu test --lib normalize_bounds_strategy --jobs 32
```

These include fresh CeTA checks for ordinary absolute match-bounds normalized
to relative bounds and finite RFC bounds normalized to finite relative RFC
bounds.

The retained certified corpus combines:

- `target/termcomp-runs/20260715-151226-srs-standard-relative-release-128-60s`;
- `target/termcomp-runs/20260724-rfc-broader653-32w-40s`.

It contains 330 certified proof artifacts over 319 distinct SRS problems: 51
ordinary/relative bounds proofs and 279 Matchbox-relative RFC proofs, with 11
problems occurring in both groups. The normalization recheck is retained in:

```text
target/termcomp-runs/20260725-bounds-normalization-certified330-ceta32
```

Observed result: 330/330 certificates certified, covering all 319 distinct
problems, with zero checker failures and zero checker timeouts.
Of these artifacts, 40 contained an absolute ordinary `<bounds>` leaf and were
actually changed to `<relativeBounds>`; the 11 existing relative proofs and 279
existing Matchbox-relative RFC proofs tested normalization idempotence and
recursive traversal.

Additional proof-form smoke checks used retained alternate witnesses:

- finite `<rfcBounds>` for `SRS_Standard/Zantema_04/z055.ari` certified before
  and after normalization to `<rfcRelativeBounds>`;
- native Matchbox-relative RFC for
  `SRS_Standard/Zantema_04/z061.ari` certified before and after normalization
  to `<rfcMatchboxRelativeBounds>` with the current regenerated checker;
- the historical automaton-closed witness for
  `SRS_Standard/Bouchare_06/01.ari` was rejected both before and after
  normalization, as expected from its already documented invalid suffix
  totality obligation.

The older run
`target/termcomp-runs/20260718-srs-unsolved-256-rfc-automaton-64w-20s`
is not part of the certified baseline. Its 15
`<rfcAutomatonClosedBounds>` witnesses were raw merge-style approximations and
all were already rejected by the final checker because they do not satisfy the
certified exact automaton-closure conditions.

An attempted search rerun on the 279 RFC examples was stopped after the first
60 results all timed out. Progress artifacts show that the old Matchbox
automata were constructed quickly, after which the current implementation
entered expensive native-witness validation. This is a current proof-search
performance regression, independent of certificate normalization, and should
be addressed separately instead of being counted as a normalization failure.

### Native RFC validation consolidation decision (2026-07-25)

The expensive native-witness validation is transitional and should not remain
in the reduced proof/processor design. The relation-preserving native theorem
derives the established Matchbox-relative checker result, while the older
identity-native checker is strictly more restrictive than that established
checker. All nine YES artifacts in
`target/termcomp-runs/20260725-rfc-native-relational-direct20` record
`legacy_ext_right=true`; eight already emitted the canonical form. The sole
native-tagged artifact, `Zantema_04/z061.ari`, certifies with its unchanged
witness after replacing `<rfcNativeMatchboxRelativeBounds>` with
`<rfcMatchboxRelativeBounds>`.

Consequently, there is no value in optimizing native validation itself.
Consolidation should instead make production RFC search validate and emit the
canonical Matchbox-relative form directly. Native proof variants, validators,
and tests are retained for now, as requested; this entry records the intended
later removal and explains why the current native-validation timeout is not an
optimization target.

### Canonical RFC production-path consolidation (2026-07-25)

The first consolidation step is implemented. Merge-style RFC production search
no longer runs native closure, mixed-height splice completion, or native
relational validation. The direct layered constructor now checks the canonical
Matchbox-relative obligations: initial acceptance, automaton closure,
right-extension closure, below-top strict compatibility, weak compatibility
for retained rules, and absence of a top redex for removed rules. Successful
search emits `<rfcMatchboxRelativeBounds>` directly. Native proof variants,
checker support, helpers, and unit tests remain in the source tree but are not
called by production RFC search.

Canonical validator reconstruction now inserts epsilon transitions in one
batch and computes their transitive closure with the existing bitset
implementation. This replaces repeated incremental closure computation and is
part of the retained canonical path, rather than an optimization of the
retired native path.

The CeTA native development is tracked in
`/work/dfm/festschrift/CeTA-rfc-native` on branch `ferrum-rfc-native`.
The verified relational checker is commit `2ee599c`, and commit `f619d7c`
adds narrow ignores for generated executable and Haskell build products.
Both the original native-tagged `z061` certificate and its normalized
canonical certificate return `CERTIFIED` with that tree's `ceta` executable.

Focused Ferrum regressions:

```console
cargo +1.95.0-x86_64-unknown-linux-gnu check --lib --jobs 32
cargo +1.95.0-x86_64-unknown-linux-gnu test --lib \
  rfc_epsilon_batch_matches_incremental_transitive_closure --jobs 32
cargo +1.95.0-x86_64-unknown-linux-gnu test --lib \
  rfc_match_bounds_emits_canonical_witness_for_z061 --jobs 32
cargo +1.95.0-x86_64-unknown-linux-gnu test --lib \
  rfc_match_bounds_emits_exact_right_barren_z033_witness --jobs 32
cargo +1.95.0-x86_64-unknown-linux-gnu test --lib \
  rfc_match_bounds_emits_paired_tail_witness_for_64160 --jobs 32
cargo +1.95.0-x86_64-unknown-linux-gnu test --lib \
  rfc_match_bounds_completes_strict_below_top_witness_for_140639 --jobs 32
```

All passed. The fixed 189-example direct RFC corpus was then rerun with 32
workers, 40-second outer timeouts, 30-second processor timeouts, and full
artifacts:

```text
target/termcomp-runs/20260725-rfc-canonical-consolidated189-v3-32w-40s
```

Result: 189 YES, 189 certified YES, 0 MAYBE, 0 timeout, 0 error, and 0
certification failure in 83 seconds wall clock. The previously timing-out
80-rule `ICFP_2010/132478.ari` completes and certifies in about 3.3 seconds.
The earlier `v2` run is retained as diagnostic evidence for the pre-constructor
consolidation state; it used a release binary that still entered native
completion and was intentionally interrupted after the bottleneck was
localized.

A full `cargo test --lib --jobs 32` was also attempted. All normalization tests
passed, but the suite contained unrelated failures in the concurrently changed
CSR, LLM, forward-instantiation, and cancellation tests. The run was stopped
after more than five minutes when
`rfc_match_bounds_completes_strict_below_top_witness_for_140639` remained in
the same expensive current RFC search path. Focused normalization tests and the
330-certificate CeTA campaign completed cleanly.

## 2026-07-25 Innermost certification-gap repair

The R01 campaign had 85 terminating roots without an ordinary CeTA
certification: 69 native CSR certificates unsupported by the current checker
and 16 innermost CPF certificates rejected by CeTA. The 16 ordinary CPF cases
were isolated under:

```text
target/cert-gap-rerun-20260725
```

The rejected proofs exposed three correctness/productivity issues:

1. CeTA's verified uncurrying processor creates a residual DP problem with
   empty `Q`. Ferrum now gives the uncurried residual full rewriting semantics
   instead of retaining `Innermost`.
2. Pure SCT closure now uses pair-indexed successors from the current
   dependency graph. Root-symbol composition was too coarse for applicative
   DPs, where every marked root is `app#`.
3. Q-aware IEDG reverse capping now uses the pair-local innermost usable-rule
   fixed point from CeTA's `inn_usable_rules_pair`, rather than all TRS rules.
   This removes spurious applicative edges while retaining the required
   `h`-pair self-edge.

Forward-instantiation export was also hardened: all generated groups must cover
every CeTA IEDG successor, the exact required set is considered, all candidate
groups are evaluated, and alpha-renamed identity steps are discarded.

Focused tests:

```console
cargo +1.95.0 test size_change -- --nocapture
cargo +1.95.0 test forward_instantiation -- --nocapture
cargo +1.95.0 test innermost_dependency_graph -- --nocapture
cargo +1.95.0 test strategy -- --nocapture
cargo +1.95.0 build --release
```

The direct regression
`TRS_Innermost/Applicative_AG01_innermost/#4.15.ari` now proves with
`dp(graph; subterm; size-change)`. Its 21 DPs decompose into the same component
shape as the certified AProVE proof, and
`target/cert-gap-rerun-20260725/direct-six/4.15.usable.cpf3.xml` is accepted by
`.tools/ceta-relative-bounds`.

The final focused batch used 8 workers, a 305-second external limit, and the
same `0.5` timeout multiplier as the earlier diagnostic batch:

```console
python scripts/termcomp_trs_compare.py \
  --tpdb /work/dfm/festschrift/TPDB-ARI \
  --ferrum target/release/ferrum \
  --ceta .tools/ceta-relative-bounds \
  --jobs 8 --timeout 305 \
  --category TRS_Innermost \
  --file-list target/cert-gap-rerun-20260725/focused-16.txt \
  --run-dir target/cert-gap-rerun-20260725/run5 \
  --details-output target/cert-gap-rerun-20260725/run5/details.json \
  --output target/cert-gap-rerun-20260725/run5/report.md \
  --strategy-file strategies/default.fs \
  --extra-arg=--timeout-multiplier --extra-arg=0.5
```

Result: 10 YES, 10 certified YES, 6 MAYBE, 0 timeout, and 0 certification
failures. Relative to the preceding focused run, the new direct route adds
certified proofs for applicative `#4.15` and `#4.34`, while sequential
uncurrying retains `#4.22`. `#4.8` was a batch-contention miss but proves and
CeTA-certifies in the retained isolated run
`target/cert-gap-rerun-20260725/direct-six/4.8.cached.cpf3.xml`. The union is
therefore 11 retained certified positives among the 16 formerly invalid CPF
cases. Per-example positive witnesses remain authoritative campaign evidence;
future comparisons must report both current-batch results and the retained
certified union.

## 2026-07-25 non-CSR consolidation campaign

The certified R00/R01 union was frozen and rechecked with:

```console
python scripts/freeze_certified_campaign_union.py \
  --campaign-dir target/data-campaign/oracle-two-round-20260724 \
  --output-dir target/data-campaign/consolidation-20260725/certified-union \
  --ceta .tools/ceta-relative-bounds \
  --fragment-ceta .tools/ceta-relative-bounds.bin \
  --jobs 8 --timeout 60 --progress-every 100
```

Result: 7,381 collected, 7,381 certified, 0 failed, 0 timeout. Native CSR
obligations were excluded. The seed oracle was regenerated from the R01 final
database and the persistent canonicalization cache:

```console
python scripts/export_utility_guidance_lookup.py \
  --sqlite target/data-campaign/consolidation-20260725/seed/aggregate-seed.sqlite \
  --canonical-cache \
    target/termcomp-proof-corpus/training/canonical-cpf-cache.sqlite \
  --output target/data-campaign/consolidation-20260725/seed/oracle-seed.jsonl
```

It contains 67,999 canonical records and 70,280 raw aliases. The campaign is
running resumably in tmux session `ferrum-consolidation-20260725`, using the
pinned binary `target/data-campaign/consolidation-20260725/bin/ferrum`
(`efedd58d4ee9700311e9c389296380237c6f1cfd582a312fc7577c137c1d07b5`).
The exact driver command is retained at the start of each phase log and in
`campaign.console.log`; `campaign.json` records phase completion and timings.

The first validated batch resumed at 28 completed roots. Its first fresh
results kept YES and certified YES aligned, and sampled event rows contained
the current transformed subproblem in CPF form. The three configured rounds
use multipliers `0.5`, `1.0`, and `2.0`, outer caps 150/300/600 seconds, and
canonical probe caps 500/1,000/2,000 milliseconds. There are eight outer jobs,
eight Rayon threads per job, and a 2 TiB whole-system memory cutoff.

### Campaign monitoring and resume repairs

Early c00 monitoring found two artifact-lifecycle issues caused by controlled
restarts, not by ordinary timeout completion:

1. A pending retry could append events to the partial JSONL left by its
   cancelled predecessor. Pending attempts now remove all partial event,
   stdout, stderr, CPF, checker, and result artifacts before starting.
2. A cancelled worker could commit an `outcome=cancelled` result marker, which
   the resume loader then treated as complete. Cancelled attempts now leave no
   result marker, and the loader also ignores older cancelled markers.

The eight roots affected by the first issue were removed from the result set
and rerun. Thirteen transient cancellation markers from the controlled repairs
were automatically excluded and have since been replaced or remain pending.
Cancellation of active process groups is now batched: TERM is sent to every
group first, followed by one shared grace interval and KILL only for remaining
groups. This reduced shutdown from one grace interval per worker to one grace
interval for the complete portfolio.

At the stable 206-root checkpoint, c00 had 62 YES, 9 NO, 25 timeouts, and
71/71 certified decisive results. For the 207 roots with an R01 comparison,
c00 had five additional decisive results and no losses. The gains were:

```text
SRS_Standard/ICFP_2010/3831.ari
SRS_Standard/ICFP_2010/85477.ari
TRS_Innermost/Transformed_CSR_innermost_04/Ex1_GL02a_iGM.ari
TRS_Standard/AotoYamada_05/011.ari
TRS_Standard/Zantema_05/jw15.ari
```

The first 796 utility-oracle queries comprised 728 raw-key hits and 68
canonical-key hits. There were 169 positive queries and 130 immediate guided
closures. Four positive candidates used the historical Rust debug spelling
`SrsRfcRelativeMatchBounds {...}` and therefore did not parse as strategy
atoms. Ingestion now normalizes that processor directly to
`rfc-relative-match-bounds(...)`, and oracle export repairs the legacy spelling
while deduplicating it against already normalized evidence. A preview export
contains 5,554 repaired occurrences and no legacy spellings. The c00 seed is
kept immutable; the repaired exporter will supply the corrected oracle to c01.

At the subsequent stable 276-root checkpoint, c00 had 83 YES, 11 NO, and 36
outer timeouts. All 94 decisive results were CeTA-certified. There were no
remaining cancellation markers, eight active isolated workers, and about
2.34 TiB system memory available.

### TermCOMP 2025 TRS Standard adaptive-state trial

The bounded paired exploration trial documented in
`docs/iterative-data-campaign.md` was run with:

```console
python scripts/run_canonical_processor_campaign.py \
  --source-db \
    target/data-campaign/consolidation-20260725/seed/aggregate-seed.sqlite \
  --run-dir \
    target/data-campaign/adaptive-trs-standard-termcomp2025-20260725 \
  --ferrum target/data-campaign/consolidation-20260725/bin/ferrum \
  --ceta .tools/ceta-relative-bounds \
  --fragment-ceta .tools/ceta-relative-bounds.bin \
  --jobs 8 --rayon-threads 8 \
  --exploit 0 --tighten 0 --explore 1 \
  --frequent-explore 4 --frequency-threshold 100 \
  --extra-exploration-budget 6000 \
  --run-problem-like '%TRS_Standard%' --no-dual-probe \
  --timeout-ms 500 --outer-grace 2 --seed 260725 \
  --progress-every 100
```

The executable candidate pool excludes the historical RFC debug spelling and
SRS-only atoms when `--run-problem-like` selects a TRS category. Scheduler
tests cover candidate normalization, domain filtering, stable baseline
inclusion, and distinct-family extras:

```console
python -m unittest scripts/test_canonical_processor_campaign.py
```

All eight tests passed. The final ledger contains 12,890 completed trials and
retains every positive CPF/checker artifact. The probe phase completed in 194
seconds; pool construction took approximately 100 seconds.

### Reconstructing the 582 certified TRS Standard proof paths

The retained 305-second TRS Standard run
`target/termcomp-runs/20260724-trs-standard-utility-oracle-timeout-fixed-128w-305s`
contains 582 CeTA-certified YES proofs. Its historical processor events omit
the current CPF, so they cannot populate a residual-state oracle. The proof
paths are reconstructed from the retained CPF files:

```console
python scripts/extract_local_cpf_oracle_events.py \
  --root \
    target/termcomp-runs/20260724-trs-standard-utility-oracle-timeout-fixed-128w-305s \
  --output \
    target/data-campaign/trs-standard-582-oracle-rebuild-20260725/cpf-proof-events.corrected.jsonl \
  --progress-every 200
```

This emits 2,499 exact current-subproblem events from all 582 certified YES
proofs: 1,121 top-level and 1,378 DP events. Exact child obligations are
reconstructed for rule removal, DP transformation/decomposition, usable
rules, reduction pairs, rewriting, narrowing, instantiation, switching, and
uncurrying. Automatic terminal nodes are not strategy candidates.

An initial extraction incorrectly let order witnesses leak from a
continuation: a top-level polynomial `ruleRemoval` could be labeled as a
matrix processor when a later nested DP proof used a matrix interpretation.
Order extraction now stops at the processor-local witness. The corrected
extraction contains zero spurious top-level matrix labels and 517 top-level
polynomial-removal events. `scripts/test_credited_status_map_dataset.py`
contains a regression test.

The corrected events are appended to a fresh copy of
`target/data-campaign/consolidation-20260725/seed/aggregate-seed.sqlite` using
`build_credited_status_map_dataset.py --append-sqlite
--canonicalize-inputs`. All 2,473 distinct current CPFs canonicalize
successfully. Each observation carries explicit certified provenance, and the
aggregated candidate records a `certified_count`. Runtime tightening is tried
only for a candidate with certified evidence; the exact certified favorite is
always retained after its tighter variants.

The final runtime manifest includes canonical keys and raw-input aliases, so
known residual states avoid online SMT canonicalization. Ferrum consults the
oracle at the root, at DP entry, after each DP transformation/SCC split, and
after successful top-level transformations. A miss or failed favorite
continues into the ordinary strategy, which supplies exploration data.

### External-proof-guided TRS Standard campaign (2026-07-25)

External evidence was ranked and converted to exact state hints with:

```console
python scripts/rank_external_proof_exploration.py \
  --details target/termcomp-runs/20260725-trs-standard-oracle-complete-128w-305s/details.json \
  --proof-db target/termcomp-proof-corpus/proofs.sqlite \
  --canonical-cache target/termcomp-proof-corpus/training/canonical-cpf-cache.sqlite \
  --output target/data-campaign/trs-standard-external-evidence-20260725/ranking.final.jsonl \
  --summary target/data-campaign/trs-standard-external-evidence-20260725/summary.final.json \
  --markdown docs/trs-standard-external-proof-exploration.md \
  --events-output target/data-campaign/trs-standard-external-evidence-20260725/external-proof-events.final.jsonl \
  --state-hints-output target/data-campaign/trs-standard-external-evidence-20260725/state-hints.final.jsonl
```

The source comprises 1,077 AProVE/MU-TERM proofs for 526 of 747 unresolved
examples. It yields 3,528 processor events and 2,479 canonical hint states.
All hint keys occur in
`target/data-campaign/trs-standard-external-evidence-20260725/exploration-source.expanded.sqlite`.

The certified probe command was:

```console
python scripts/run_canonical_processor_campaign.py \
  --source-db target/data-campaign/trs-standard-external-evidence-20260725/exploration-source.expanded.sqlite \
  --run-dir target/data-campaign/trs-standard-external-evidence-20260725/probes-r00 \
  --ferrum target/oracle-final-build/release/ferrum \
  --ceta .tools/ceta-relative-bounds \
  --fragment-ceta .tools/ceta-relative-bounds.bin \
  --jobs 64 --rayon-threads 2 \
  --exploit 0 --tighten 2 --explore 0 --frequent-explore 0 \
  --no-dual-probe --timeout-ms 5000 \
  --candidate-hints target/data-campaign/trs-standard-external-evidence-20260725/state-hints.final.jsonl \
  --hint-limit 3 --hinted-only --progress-every 100
```

The 3,720 trials produced 1,298 solved, 127 transformed, 1,878 failed, and
417 timeout outcomes. Initially 1,424/1,425 positives certified. The rejected
proof showed that a residual innermost polynomial reduction pair was searched
against an empty ordinary usable-rule set while the enclosing Q component
still contained four rules. `reduction_pair_context_rules` now unions the
rules represented by the retained Q-LHS set into every residual reduction-pair
context. The exact failed input then reproved in 30 ms and
`.tools/ceta-relative-bounds` returned `CERTIFIED`. Final alignment is
1,425/1,425.

The runtime oracle excludes imported external successes and was exported from
Ferrum/CeTA evidence as:

```text
target/data-campaign/trs-standard-external-evidence-20260725/oracle-r00.jsonl
target/data-campaign/trs-standard-external-evidence-20260725/oracle-r01.jsonl
target/data-campaign/trs-standard-external-evidence-20260725/oracle-r02.jsonl
```

R00 has 72,602 canonical states and 74,447 raw aliases. R01, after adding the
complete root run events and 77 exact certified proof-step events from a
focused positive replay, has 72,730 canonical states and 74,576 raw aliases.
R02 includes both R01 evaluation streams and their three certified proofs; it
has 72,770 canonical states and 74,610 raw aliases and is the next campaign
seed.

Root evaluation used at most 64 examples in parallel, a 305-second harness
cap, and the default strategy's 300-second outer timeout:

| Generation | Mode | Inputs | YES | Certified YES | Timeout | Cert failed |
| --- | --- | ---: | ---: | ---: | ---: | ---: |
| R00 | oracle only | 747 | 4 | 4 | 0 | 0 |
| R00 | oracle + fallback | 747 | 13 | 13 | 55 | 0 |
| R01 | oracle only | 734 | 2 | 2 | 0 | 0 |
| R01 | oracle + fallback | 732 | 1 | 1 | 53 | 0 |
| R02 | oracle only, original unresolved set | 747 | 11 | 11 | 0 | 0 |

The retained union is 625 certified YES and 172 certified NO.

### CPF4 CSR validation and cumulative oracle extension (2026-07-25)

Ferrum's CSR input/event path now serializes the complete current
context-sensitive problem as CPF, including its replacement map. `probe-cpf`
parses this representation, applies a CSR atom, and emits CPF4 for successful
proofs. CSR utility guidance is consulted both at the top level and in the
ordinary DP problems generated by safe or conservative CSR transformations.

The conservative CSR-DP branch now uses the complete replacement-map
dependency-pair set required by CeTA. It rejects minimality-dependent ordinary
DP processors: size change, size-change reduction pairs, and reduction pairs
serialized with a nonempty usable-rule set. Safe CSR dependency pairs remain
minimal and may use those processors. The usable-rule guard is deliberately
based on the serialized CPF constructor: any nonempty `usable_rules` field
selects `redPairUrProc` or `monoRedPairUrProc`.

Validation used:

```console
RAYON_NUM_THREADS=4 python scripts/termcomp_trs_compare.py \
  --tpdb ../TPDB-ARI \
  --ferrum target/csr-oracle-cpf4-build/release/ferrum \
  --ceta /work/dfm/festschrift/CeTA-CSR/ceta \
  --jobs 32 --timeout 305 \
  --category TRS_Contextsensitive \
  --run-dir target/termcomp-runs/20260725-csr-cpf4-shared-oracle-gate \
  --output target/termcomp-runs/20260725-csr-cpf4-shared-oracle-gate/summary.md \
  --details-output target/termcomp-runs/20260725-csr-cpf4-shared-oracle-gate/details.json
```

The result was 58 YES, 58 certified YES, 50 MAYBE, and zero timeouts, errors,
or certification failures. All 29 CSR-DP proofs certified completely.

The subsequent two CSR improvement cycles extended, rather than replaced, the
best TRS Standard oracle. Full commands and per-cycle statistics are recorded
in `docs/iterative-data-campaign.md`. The final cumulative oracle contains
148,899 runtime rows, preserves every one of the 147,380 seed rows and every
seed candidate, and adds 1,519 keys. It was re-exported directly from the
cumulative R01 database and the original seed so states supported only by
uncertified positive evidence do not appear as empty runtime entries:

```text
target/data-campaign/shared-oracle-csr-cpf4-two-cycle-correct-20260725/rounds/r01/corpus/oracle-r01-final.jsonl
```

Two harness defects were fixed during the audit. Explicit utility guidance is
no longer silently disabled by the historical enhanced profile's
`--no-top-level-llm`, and artifact paths resolve root/problem paths before
computing a relative directory. The latter prevents same-basename examples
such as `Beerendonk_07/6.ari` and `Secret_06_TRS/6.ari` from overwriting each
other. A focused replay retained all 13 R00 fallback proofs in distinct
directories; all 13 certified again and yielded 77 exact proof-step events.

### Residual-aware CSR composition and one-shot polynomial removal (2026-07-25)

CSR strategy execution now distinguishes a closed proof, a certified
transformation with a residual CSR problem, and failure. Sequences continue on
the residual. Parallel CSR branches run in Rayon child cancellation scopes; a
closed branch cancels siblings, including managed solver subprocesses. The
checked-in CSR strategy budget is 300 seconds and races direct QCS-DPs with
rule-removal and innermost-equivalence compositions.

The former Cartesian enumeration of CSR linear interpretations was removed.
Each `poly` application sends one QF_NIA optimization problem to Z3. It
enforces replacement-map monotonicity and weak orientation of every rule,
requires at least one strict rule, and maximizes the number of strict rules.
Ferrum independently validates the returned model before emitting CPF4.

Focused regression and CeTA checks:

```console
RUSTUP_TOOLCHAIN=1.95.0 cargo test -q csr_sequence_applies_polynomial_removal_to_the_residual_problem
RUSTUP_TOOLCHAIN=1.95.0 cargo test -q csr_parallel_cancels_a_running_sibling_after_a_closed_proof
RUSTUP_TOOLCHAIN=1.95.0 cargo test -q local_ceta_certifies_mu_only_csr_polynomial_rule_removal
RUSTUP_TOOLCHAIN=1.95.0 cargo test -q local_ceta_certifies_conservative_csr
```

The full retained-artifact CSR evaluation used the cumulative shared oracle:

```console
RAYON_NUM_THREADS=2 python scripts/termcomp_trs_compare.py \
  --tpdb ../TPDB-ARI \
  --ferrum target/release/ferrum \
  --ceta /work/dfm/festschrift/CeTA-CSR/ceta \
  --jobs 64 --timeout 305 \
  --category TRS_Contextsensitive \
  --run-dir target/termcomp-runs/20260725-csr-residual-smt-improved-full \
  --output target/termcomp-runs/20260725-csr-residual-smt-improved-full/summary.md \
  --details-output target/termcomp-runs/20260725-csr-residual-smt-improved-full/details.json \
  --progress-interval 5 \
  --extra-arg=--utility-guidance-manifest \
  --extra-arg=target/data-campaign/shared-oracle-csr-cpf4-two-cycle-correct-20260725/rounds/r01/corpus/oracle-r01-final.jsonl
```

Result: 64 YES, 64 certified YES, 44 MAYBE, zero timeout, zero error, and zero
certification failure. This adds six certified YES results to the 58/58 gate
with no losses. Five gains combine one CSR polynomial rule-removal step with a
native CSR-DP proof of the residual; `Ex15_Luc98.ari` closes after rule removal:

```text
CSR_04/Ex14_Luc06.ari
CSR_04/Ex15_Luc98.ari
CSR_04/Ex5_DLMMU04.ari
Transformed_outermost_08/cariboo_ex6.ari
Transformed_outermost_08/ex5.4.ari
Transformed_outermost_08/ex5.6.ari
```

`cargo check` and `git diff --check` pass. The two new CSR regressions and the
focused CeTA checks pass. The complete serial suite currently reports 339
passed, 14 failed, and 1 ignored. Those 14 pre-existing failures are outside
this CSR change: four use a CeTA binary without the native fixed-point
extensions, seven still request CPF3 for proofs now gated to CPF4, and three
are existing timing/global-state-sensitive Q-graph, nested-cancellation, and
LLM-proposal tests. The full 108-example CPF4 run is the certification gate for
this change and has zero checker failures.

### State-centric CSR guidance and certified transition recovery (2026-07-25)

Guidance now follows the same transition semantics used by the proof search:
`Solved`, `Transformed(residual, proof context)`, `Inapplicable`, `Failed`, and
`TimedOut`. CSR guidance can apply repeated strong transformations, query the
resulting CPF state again, and, when no faithful atom is available, continue
the ordinary strategy from that residual while retaining the transformation
contexts. DP guidance is no longer deliberately cleared after entering or
transforming a component.

The local CPF extractor now reads both CPF3 and CPF4 and reconstructs exact CSR
rule-removal obligations. It does not flatten the body of `csrDpProof` into an
ordinary `dpInput`: that loses Q/CSR conditions and produced two reproducible
CeTA failures. Likewise, a generic `dp` atom is not exported for a CSR-DP step
until the atom can represent the CSR-DP construction and nested strategy.
Runtime solved attempts inherit full-result certification only when their
logged CPF state is self-contained. Certified transformations remain positive
even when the extractor cannot emit a separate trivial terminal row.

Canonical CPF hashing now removes insignificant XML indentation before symbol
standardization and serialization. Fresh canonical-cache aliases take
precedence over inherited aliases. A regression compares compact and indented
representations and requires the same canonical result.

The accepted cumulative manifest is:

```text
target/data-campaign/shared-oracle-csr-residual-20260725/oracle-csr64-unified-v8.jsonl
```

Its 64-example replay is retained at:

```text
target/termcomp-runs/20260725-csr64-unified-oracle-v8-replay
```

The run used 64 workers, a 305-second external timeout, and
`/work/dfm/festschrift/CeTA-CSR/ceta`. Result: 64 YES, 64 certified YES, zero
MAYBE/timeout/error/certification failure, and 49 native CSR-DP proofs. All 64
proofs contain a successful guidance decision; 63 have successful root CSR
guidance, and 25 use a guided strong CSR transformation. `CSR_04/Ex1_GL02a`
is the sole root lookup miss and receives successful DP guidance after the
ordinary strategy enters its next state.

Validation:

```text
PYTHONPATH=scripts python -m unittest scripts.test_credited_status_map_dataset -q
RUSTUP_TOOLCHAIN=1.95.0 cargo test -q csr_guidance_chains_strong_transformations_without_fallback
git diff --check
```

The Python suite reports 10/10 passing; the focused Rust regression passes.

### CSR matrix removal and native projection subterm proofs (2026-07-26)

Ferrum now applies dimension-2 natural matrix interpretations directly as CSR
rule-removal processors. Synthesis is one QF_BV query; active replacement-map
arguments are constrained to be monotone, all rules are weakly oriented, and
at least one rule is strict. The returned interpretation is independently
validated before CPF4 export.

CeTA-CSR was extended in
`thys/Proof_Checker/CSR_Checker.thy` with a verified matrix
replacement-map-monotonicity check and a sound
`csr_int_mat_rule_removal_tt` rule. The generated checker was rebuilt with:

```console
AFP=/work/dfm/festschrift/ferrum/.tools/afp-current/thys
ISABELLE=/work/dfm/festschrift/ferrum/.tools/Isabelle2025-2/bin/isabelle
$ISABELLE build -d "$AFP" -d thys Proof_Checker
$ISABELLE build -d "$AFP" -d thys Code
$ISABELLE export -n -d "$AFP" -d thys \
  -O /tmp/ceta-csr-code-export \
  -x 'Code.Code_Haskell:code/export1/**' Code
cp /tmp/ceta-csr-code-export/Code.Code_Haskell/code/export1/CSR_Checker.hs \
  generated/Haskell/CSR_Checker.hs
make haskell
```

Both matrix fixtures certify, while changing an active matrix coefficient or
removing every strict decrease is rejected. The first complete retained run
after matrix removal is:

```text
target/termcomp-runs/20260726-csr108-matrix-v1
```

It has 67 YES, 67 certified YES, and 41 MAYBE. Relative to the preceding
63/63 guarded baseline, it adds four certified proofs and loses none:

```text
CSR_04/Ex1_2_Luc02c.ari
CSR_04/Ex6_9_Luc02c.ari
Transformed_outermost_08/cariboo_ex2.ari
Transformed_outermost_08/ex5.5.ari
```

The projection subterm processor now retains its actual projection instead of
encoding every success as size change. Projection selection is one QF_LIA
query with one bounded integer per marked root and no symbol cap. Safe/minimal
DP problems emit native CPF `<subtermProc>` proofs. For replacement-map
Q-CSDPs, Ferrum emits the verified CSR size-change/subterm form only when the
combined coarse closure validates; otherwise it continues with another
processor. This distinction is necessary because the two checker processors
have different minimality preconditions.

Focused validation:

```console
RUSTUP_TOOLCHAIN=1.95.0 cargo test projection_subterm_smt_has_no_symbol_cap --lib
RUSTUP_TOOLCHAIN=1.95.0 cargo test csr_matrix --lib
target/release/ferrum prove tests/fixtures/csr_subterm_projection.ari \
  --strategy 'csr(dp(subterm))' --cpf /tmp/csr-subterm.xml --cpf-mode cpf40
/work/dfm/festschrift/CeTA-CSR/ceta /tmp/csr-subterm.xml
```

The valid projection certifies. Changing `<collapsing>1</collapsing>` to an
out-of-range position is rejected. The AProVE 2025 proof for
`CSR_04/Ex1_2_AEL03.ari` confirms the next major gap: its successful route is
the LPAR'08 improved CS-DP construction followed by a Q-aware graph split and
four `QCSDPSubtermProof` steps. CeTA-CSR already contains the semantic
hiding/collapsing development, but the exact hidden-term Q-CSDP construction
and its executable certified checker are not yet complete. Ferrum therefore
keeps this case at MAYBE instead of accepting the coarser conservative graph
decomposition that CeTA rejects.

The final 64-worker certification gate, after validating the combined SCT
closure and restoring fallback on an invalid flattening candidate, is:

```text
target/termcomp-runs/20260726-csr108-matrix-subterm-v4
```

Result: 67 YES, 67 certified YES, 41 MAYBE, zero timeout, zero error, and zero
certification failure. It has the same four gains over the 63/63 guarded
baseline listed above, no losses, and no outcome difference from the first
67/67 matrix run.

### Certified Q-reduction and switched narrowing case study (2026-07-29)

The certified AProVE proof for `TRS_Standard/Various_04/11.ari` was extracted
and replayed before changing Ferrum:

```console
.tools/ceta-relative-bounds /tmp/various04-11-aprove.cpf.xml
CERTIFIED
```

Ferrum previously returned MAYBE in 12.315 seconds. Its trace showed that it
could synthesize AProVE's narrowing witness but retained all three original
TRS LHSs in Q, retained both narrowed self-edges, and did not run narrowing in
the DP strategy entered by `switchInnermost`.

The implementation now follows
`CeTA-rfc-native/thys/Termination_and_Complexity/Q_Reduction_Impl.thy`:

1. Start from the current Q-LHS set.
2. Keep LHSs whose arguments are Q-normal.
3. Keep only LHS roots occurring in the residual dependency pairs or active
   usable rules.
4. Preserve an empty Q as an explicit innermost context.
5. Recompute this context after every residual DP transformation.

The switched proof now uses `DpStrategy::default_for(Innermost)`, including
narrowing and the later rewriting/instantiation processors. The obsolete
`innermost_without_narrowing` strategy was removed.

Focused validation:

```console
cargo +1.95.0-x86_64-unknown-linux-gnu test --lib \
  various_04_11_q_reduction_exposes_narrowing_rewriting_pipeline --jobs 32
cargo +1.95.0-x86_64-unknown-linux-gnu test --lib innermost_ --jobs 64
```

The first command passes its single regression. The second passes all 43
innermost-related tests, including available CeTA smoke tests. A complete
library run during concurrent RFC/CSR development reported 372 passed, 17
failed, and one ignored. The Q-related expectation was corrected and all
innermost tests subsequently passed; the remaining complete-suite failures
were in concurrent RFC/CPF4, native forbidden-pattern CSR, LLM, and
cancellation work.

Final build and retained full-artifact run:

```console
cargo +1.95.0-x86_64-unknown-linux-gnu build --release --jobs 64
python scripts/termcomp_trs_compare.py \
  --tpdb /work/dfm/festschrift/TPDB-ARI \
  --ferrum target/release/ferrum \
  --ceta .tools/ceta-relative-bounds \
  --jobs 1 --timeout 60 --category TRS_Standard \
  --file-list <(printf '%s\n' 'TRS_Standard/Various_04/11.ari') \
  --run-dir target/termcomp-runs/20260729-various04-11-final-60s \
  --progress-interval 1
```

Result: one YES, one certified YES, zero MAYBE, timeout, error, or
certification failure. Independent replay:

```console
.tools/ceta-relative-bounds \
  target/termcomp-runs/20260729-various04-11-final-60s/TRS_Standard/Various_04/11/proof.cpf.xml
CERTIFIED
```

### Standard DP usable rules on `Secret_06_TRS/gen-9` (2026-07-29)

Baseline command:

```console
python scripts/termcomp_trs_compare.py \
  --tpdb /work/dfm/festschrift/TPDB-ARI \
  --ferrum target/release/ferrum \
  --ceta .tools/ceta-relative-bounds \
  --jobs 1 --timeout 60 --category TRS_Standard \
  --file-list <(printf '%s\n' 'TRS_Standard/Secret_06_TRS/gen-9.ari') \
  --run-dir target/termcomp-runs/20260729-gen9-next-baseline-60s \
  --progress-interval 1
```

Baseline result: MAYBE in 23.282 seconds. Ferrum generated the same six
initial pairs as AProVE. AProVE's extracted CPF was replayed independently:

```console
.tools/ceta-relative-bounds /tmp/gen9-aprove.cpf.xml
CERTIFIED
```

The proof evidence uses two usable rules, rooted at `b` and `c`, in both
cyclic components. Ferrum's `usable_rules` function computed that same set,
but `reduction_pair_context_rules` returned the entire TRS for standard/full
DP problems. Its trace therefore showed `usable_rules=3` for every matrix,
polynomial, path-order, and KBO attempt.

The standard branch of `reduction_pair_context_rules` now returns
`usable_rules(trs, pairs)`. The new
`gen9_standard_matrix_component_uses_only_usable_rules` regression checks the
exact two-rule set and requires the dimension-2 0/1 matrix search to succeed.

Validation:

```console
cargo +1.95.0-x86_64-unknown-linux-gnu test --lib \
  gen9_standard_matrix_component_uses_only_usable_rules --jobs 32
cargo +1.95.0-x86_64-unknown-linux-gnu test --lib usable --jobs 64
cargo +1.95.0-x86_64-unknown-linux-gnu test --lib matrix --jobs 64
cargo +1.95.0-x86_64-unknown-linux-gnu build --release --jobs 64
```

The focused regression, all 14 usable-rule tests, and all nine matrix tests
pass. Final retained run:

```console
python scripts/termcomp_trs_compare.py \
  --tpdb /work/dfm/festschrift/TPDB-ARI \
  --ferrum target/release/ferrum \
  --ceta .tools/ceta-relative-bounds \
  --jobs 1 --timeout 60 --category TRS_Standard \
  --file-list <(printf '%s\n' 'TRS_Standard/Secret_06_TRS/gen-9.ari') \
  --run-dir target/termcomp-runs/20260729-gen9-usable-rules-60s \
  --progress-interval 1
```

Result: one YES, one certified YES, zero MAYBE, timeout, error, or
certification failure in 1.707 seconds. The accepted CPF uses a dimension-2
matrix interpretation for the recursive `F` pair and a degree-1 polynomial
interpretation for the three-pair `B`/`C` component. Independent replay:

```console
.tools/ceta-relative-bounds \
  target/termcomp-runs/20260729-gen9-usable-rules-60s/TRS_Standard/Secret_06_TRS/gen-9/proof.cpf.xml
CERTIFIED
```

### `matchbox1` CPF regression and certified semantic labeling (2026-07-29)

Build:

```console
cargo +1.95.0-x86_64-unknown-linux-gnu build --release --jobs 64
```

The focused file lists contain:

```text
TRS_Standard/Secret_05_TRS/matchbox1.ari
TRS_Standard/Endrullis_06/labeling.ari
```

Final retained default-strategy runs:

```console
python scripts/termcomp_trs_compare.py \
  --tpdb /work/dfm/festschrift/TPDB-ARI \
  --ferrum target/release/ferrum \
  --ceta .tools/ceta-relative-bounds \
  --jobs 1 --timeout 60 --category TRS_Standard \
  --file-list target/termcomp-runs/20260729-matchbox1-regression-file-list.txt \
  --run-dir target/termcomp-runs/20260729-matchbox1-final-source-certified-60s \
  --progress-interval 1 --strategy-file strategies/default.fs

python scripts/termcomp_trs_compare.py \
  --tpdb /work/dfm/festschrift/TPDB-ARI \
  --ferrum target/release/ferrum \
  --ceta .tools/ceta-relative-bounds \
  --jobs 1 --timeout 65 --category TRS_Standard \
  --file-list target/termcomp-runs/20260729-labeling-file-list.txt \
  --run-dir target/termcomp-runs/20260729-labeling-final-source-certified-65s \
  --progress-interval 1 --strategy-file strategies/default.fs
```

Results:

| Example | YES | Certified YES | Elapsed |
| --- | ---: | ---: | ---: |
| `Secret_05_TRS/matchbox1.ari` | 1 | 1 | 1.624 s |
| `Endrullis_06/labeling.ari` | 1 | 1 | 23.050 s |

Independent checker replay:

```console
.tools/ceta-relative-bounds \
  target/termcomp-runs/20260729-matchbox1-final-source-certified-60s/TRS_Standard/Secret_05_TRS/matchbox1/proof.cpf.xml
CERTIFIED

.tools/ceta-relative-bounds \
  target/termcomp-runs/20260729-labeling-final-source-certified-65s/TRS_Standard/Endrullis_06/labeling/proof.cpf.xml
CERTIFIED
```

Focused validation:

```console
cargo +1.95.0-x86_64-unknown-linux-gnu test --lib polynomial_dp_removal --jobs 32
cargo +1.95.0-x86_64-unknown-linux-gnu test --lib forward_instantiation --jobs 32
cargo +1.95.0-x86_64-unknown-linux-gnu test --lib semantic_label --jobs 32
cargo +1.95.0-x86_64-unknown-linux-gnu test --lib \
  ceta_certifies_cpf3_weak_polynomial_dp_certificate_when_available --jobs 32
cargo +1.95.0-x86_64-unknown-linux-gnu test --lib \
  writes_only_strict_dp_pairs_in_each_red_pair_step --jobs 32
```

### Certified `pair2hard` regression

The 2026-07-29 default-strategy run retains the input command, progress events,
stdout/stderr, CPF, CeTA output, and JSON result:

```console
cargo +1.95.0-x86_64-unknown-linux-gnu build --release --jobs 64

python3 scripts/termcomp_trs_compare.py \
  --tpdb ../TPDB-ARI \
  --ferrum target/release/ferrum \
  --ceta .tools/ceta-relative-bounds \
  --jobs 1 --timeout 65 --category TRS_Standard \
  --file-list target/termcomp-runs/20260729-pair2hard-file-list.txt \
  --run-dir target/termcomp-runs/20260729-pair2hard-default-65s \
  --progress-interval 1
```

Result: `YES=1`, `Certified YES=1`, elapsed 2.531 seconds. Replay:

```console
.tools/ceta-relative-bounds \
  target/termcomp-runs/20260729-pair2hard-default-65s/TRS_Standard/Endrullis_06/pair2hard/proof.cpf.xml
CERTIFIED
```

Focused checks:

```console
cargo +1.95.0-x86_64-unknown-linux-gnu test --lib \
  forward_instantiation_handles_pair2hard_residual --jobs 32
cargo +1.95.0-x86_64-unknown-linux-gnu test --lib matrix_bv_script --jobs 32
```

All focused tests pass. A broader `test --lib polynomial` filter passed 43
tests and reported two unrelated expectation failures in concurrent work:
`standard_polynomial_size_change_checks_full_rule_context` still expects the
old full-TRS DP context, and
`accepts_llm_linear_polynomial_rule_removal_proposals` assumes a fixed first
top-level proof step.

## 2026-07-29 adaptive transformed-CSR baseline and usable-rule repairs

The fresh `Transformed_CSR_04` baseline covered all 516 inputs at a 60-second
Ferrum ceiling.  It reported 252 terminating, 80 nonterminating, 178 `Unknown`,
and six harness-level `unknown` results.  CeTA-CSR certified all 80 negative
answers but only 138 of the initial positive answers:

```text
target/data-campaign/state-first-adaptive-20260729-132133/transformed-csr-04/baseline
```

Of the 114 rejected positives, 113 failed CeTA's usable-rule closure check and
one failed its dependency-graph check.  The KBO implementation had incorrectly
computed the CPF usable-rule closure after applying its argument filter.  CPF
and CeTA compute the usable closure before filtering.  KBO now orients and
retains that complete closure.  A replay with the pinned corrected binary
recovered 23 certified roots; 90 former positives now soundly remain unknown
within 60 seconds, and the graph rejection remains quarantined:

```text
target/data-campaign/state-first-adaptive-20260729-132133/transformed-csr-04/baseline-recovery-kboclosure
target/data-campaign/state-first-adaptive-20260729-132133/bin/ferrum-post-r3-kboclosure-20260729-2225
SHA-256 2dcd92f9920d90ec1a9784125d89a4d03e7dd04e2e435eac0d75877c8ebb1a56
```

The corrected baseline is therefore 161 certified YES, 80 certified NO, and
275 unresolved.

The first adaptive round then exposed a second related state bug: a partial
`redPairUrProc`/`monoRedPairUrProc` proof restored the parent `R` in its
residual finiteness assumption.  Residual DP search and partial proof export now
preserve the exact certified usable-rule component, including `R = {}`.  The
focused campaign regression changed from a CeTA “strict/weak rule is missing”
rejection to:

```text
usableRules rules: 4
residual-assumption rules: 4
CeTA-CSR --allow-assumptions: CERTIFIED
```

Artifacts and the pinned recovery binary are:

```text
target/data-campaign/state-first-adaptive-20260729-132133/transformed-csr-04/rounds/r01/recheck-urstate2-32b3
target/data-campaign/state-first-adaptive-20260729-132133/bin/ferrum-post-r3-kboclosure-urstate2-20260729-2220
```

## 2026-07-29 `jw34` uncurrying schedule repair

The 15-example Standard candidate baseline was retained at:

```text
target/termcomp-runs/20260729-next-standard-candidates-default-60s
```

It produced five YES, all certified, and ten MAYBE. In particular,
`Zantema_05/jw34.ari` was MAYBE after 55.063 seconds. A focused run showed
that the existing uncurrying implementation was already sufficient:

```console
timeout 65s target/release/ferrum prove \
  ../TPDB-ARI/TRS_Standard/Zantema_05/jw34.ari \
  --strategy 'timeout(60s, uncurry)' \
  --cpf target/termcomp-runs/20260729-jw34-focused-uncurry-60s/proof.cpf.xml \
  --cpf-mode auto --no-top-level-llm \
  --processor-events \
  target/termcomp-runs/20260729-jw34-focused-uncurry-60s/progress.jsonl

.tools/ceta-relative-bounds \
  target/termcomp-runs/20260729-jw34-focused-uncurry-60s/proof.cpf.xml
```

Ferrum returned YES in about 18 seconds and CeTA returned `CERTIFIED`. The
default strategy was changed so `trs_initial_orders` and uncurrying run in
parallel and cooperatively cancel once either branch closes the proof. The
default-strategy validation returned YES in about 14 seconds and independently
certified:

```text
target/termcomp-runs/20260729-jw34-default-parallel-60s
```

The complete 15-example slice was then rerun with 15 workers, a 60-second
external limit, eight Rayon threads per proof, and full artifacts:

```console
RAYON_NUM_THREADS=8 python3 scripts/termcomp_trs_compare.py \
  --tpdb ../TPDB-ARI \
  --ferrum target/release/ferrum \
  --ceta .tools/ceta-relative-bounds \
  --jobs 15 --timeout 60 --category TRS_Standard \
  --ferrum-profile default \
  --file-list target/termcomp-runs/20260729-next-standard-candidates.txt \
  --extra-arg=--strategy --extra-arg='timeout(55s, default)' \
  --extra-arg=--no-top-level-llm \
  --run-dir \
  target/termcomp-runs/20260729-next-standard-candidates-parallel-uncurry-60s
```

Result: six YES, six certified YES, nine MAYBE, zero certification failures,
and no losses against the five baseline YES results.

`cargo +1.95.0-x86_64-unknown-linux-gnu build --release --jobs 32` passed.
The `proving::engine` test filter passed 79 tests but also exposed nine
pre-existing/concurrent failures in RFC CPF-version expectations, one LLM
proof-step expectation, and one nested-cancellation regression; none exercises
the strategy-file scheduling change. A later focused-test invocation could not
compile after concurrent, unfinished Arctic-matrix edits introduced missing
functions and non-exhaustive match arms. Those unrelated edits were left
untouched; both retained `jw34` proofs were produced by the successfully built
release binary and independently accepted by CeTA.

## 2026-07-29 adaptive Transformed-CSR round 1 recovery and replay

The first Transformed-CSR state campaign initially retained six transformed
DP fragments whose residual assumptions incorrectly replaced the parent rule
set with the pair-local usable rules.  The repair now distinguishes CPF's two
reduction-pair forms: a non-monotone `redPairUrProc` child retains the complete
parent `R`, while a monotone `monoRedPairUrProc` child may continue with the
explicit residual usable-rule set.  The formerly rejected
`6caf6526de3e...` polynomial probe then returned `CERTIFIED` under
`CeTA-CSR/ceta --allow-assumptions`.

Recovery was performed from
`campaign.pre-urstate4-recovery.sqlite` with the immutable binary
`bin/ferrum-post-r3-kboclosure-urstate4-20260729-2323`
(`0e254170134b0387cf22e5b8c0001674b1c7fcefed8479cea5e78dc017699b93`).
The recursively drained round contains 1,921 certified terminal proofs, 2,337
certified transformations, 801 certified assemblies, and 1,280 newly
materialized child states.  Both deterministic frozen-union passes rechecked
all 4,927 retained positives: 4,927 certified, zero failed, zero timeout.
Zero uncertified YES/NO results were promoted.  The remaining 34 rejected
partial fragments are exclusively top-level termination assumptions that the
current CeTA-CSR assumption parser does not represent; they remain excluded
from positive guidance.

The 275 unresolved baseline roots were then replayed with a 60-second prover
ceiling.  Strict oracle-only replay closed no root and recorded 3,664 guided
attempts.  Oracle-plus-default fallback closed 14 new roots—11 terminating and
3 nonterminating—all CeTA-CSR certified and then independently rechecked
twice.  The residual set is 261 roots.  Exact artifacts are under:

```text
target/data-campaign/state-first-adaptive-20260729-132133/transformed-csr-04/rounds/r01/
  frozen-certified-union/
  frozen-certified-union-recheck2/
  root-oracle-only/
  root-oracle-plus-fallback/
  oracle-r01-v2.jsonl
```

The strongest oracle after the manual `#4.31` arctic-matrix integration has
163,234 rows and SHA-256
`222943fb9ffec9f7e47bebbdd8e1357173ccaaeb70197df61c5d5ab16c26d355`.
Round 2 explicitly includes the new native dimension-3 arctic-matrix atom in
its dependency-pair frontier; the improved LPAR'08 CS-DP path remains reached
through the ordinary `dp` atom.

The subsequent, distinct `AG01_innermost/#4.36` Q-IEDG proof added 12 exact
certified events.  The monotone successor is `oracle-r01-v3.jsonl`, with
163,431 rows and SHA-256
`3fe24417bba2cb0d99f9671ab4786e5e1b8ae381ee7180edae8573c130f81d4f`.

## 2026-07-30 adaptive Transformed-CSR round 2 root replay

The 261 roots remaining after round 1 were replayed with the committed release
binary, 64 isolated provers, two Rayon threads per prover, a 60-second strategy
ceiling, and a 65-second harness ceiling.  Strict oracle-only replay completed
in 22.7 seconds, closed no root, and retained 38,500 processor events.  The
oracle-plus-default replay completed in 255.3 seconds and produced 15 YES and
2 NO candidates, with 13 harness timeouts and no harness failure.

CeTA-CSR certified 14 of the 17 decisive candidates.  The three rejected YES
results (`Ex16_Luc06_iGM`, `LengthOfFiniteLists_nosorts_GM`, and
`OvConsOS_nosorts_GM`) exposed sibling-state leakage in dependency-graph
search: an earlier SCC's empty usable-rule continuation was reused as the
graph-rule cache for a later sibling, although CPF semantics restore the
parent rule context between graph components.  Ferrum now restores the parent
active, graph, and transformation rule contexts independently for every
sibling SCC, at initial ordinary/CSR decomposition and at recursive graph
processors.  The exact 15-rule `a__length#(mark(L))` self-edge is covered by a
regression.  The previously certified forward-instantiation decomposition
remains available.

After the fix, all three rejected roots return honest `Unknown` with no CPF
under isolated 60-second replays.  The full library suite reports 423 passed,
zero failed, and five documented legacy-wrapper ignores.  No rejected result
is eligible for positive oracle guidance.  Exact artifacts are under:

```text
target/data-campaign/state-first-adaptive-20260729-132133/transformed-csr-04/rounds/r02/
  root-oracle-only-v3-60s/
  root-oracle-plus-fallback-v3-60s/
  recheck-sibling-context-20260730/
```

During the first Transformed-CSR round-2 wave, CeTA rejected ten forward
instantiation fragments with `innermost rewriting required`.  Ferrum had
incorrectly treated minimality or normal-form substitutions as sufficient to
emit the optional usable-rule restriction.  It now also applies CeTA's exact
criterion `NF(Q) ⊆ NF(R)`: every active `R` left-hand side must be non-normal
for `Q`.  In particular, explicit `Q = ∅` with nonempty `R` falls back to the
full-rule forward-instantiation processor.  Isolated replay of all ten rejected
states produced eight `CERTIFIED` transformations and two inapplicable results,
with zero rejection.  The focused regression
`forward_instantiation_does_not_emit_usable_rules_for_empty_q_and_nonempty_r`
passes.

The same wave exposed one `variableConditionViolated` proof on an innermost
problem, rejected by CeTA as an ill-formed strategy/normal-substitution
combination.  Ferrum now limits this CPF proof form to full rewriting; the
innermost regression returns inapplicable.  The pre-fix ledger is retained as
`campaign.pre-forward-nfq-nonterm-recovery.sqlite`; round 2 resumed with
`ferrum-r02-forward-nfq-nonterm-fix-20260729-2354`
(`25e22ef9513b1ab0fdc2c7cb71d2780296517971b2a93322b95d07800751605b`).

## 2026-07-30 `Mixed_TRS/7` certified recovery

The AProVE TermCOMP 2025 certificate for
`TRS_Standard/Mixed_TRS/7.ari` was used as processor evidence. Its productive
chain is uncurrying, switching to innermost rewriting, DP narrowing and
rewriting, four forward-instantiation steps, two 3D natural-Arctic reductions,
graph decomposition, KBO with argument filtering and empty usable rules, and
size change.

Ferrum was strengthened in four places:

1. Q is kept separate from the usable-rule component of a reduction pair.
2. The applicative KBO witness computes its usable rules after argument
   filtering, matching CeTA's formal `redPairUrProc` checker.
3. Degree-4 applicative Arctic/KBO witnesses are recognized structurally and
   accepted only after Ferrum rechecks all order obligations.
4. DP rewriting freshens TRS-rule variables away from DP variables before
   matching. The previous cyclic substitution for names `c` and `d` produced
   an invalid rewrite that CeTA correctly rejected.

The rejected intermediate certificate is retained under
`target/termcomp-runs/20260730-mixed7-af-usable-kbo-120s`; its CeTA diagnostic
pinpoints the invalid rewrite at position 2. After variable freshening, the
focused 120-second route returned one YES and one certified YES in 38 seconds:

```text
target/termcomp-runs/20260730-mixed7-rewrite-fresh-kbo-120s
```

The default strategy now tries the checked applicative reduction-pair
processor before launching the expensive parallel order portfolio. The final
60-second competition-style run returned one YES, one certified YES, zero
MAYBE, and zero certification failures:

```console
RAYON_NUM_THREADS=8 python3 scripts/termcomp_trs_compare.py \
  --tpdb ../TPDB-ARI --ferrum target/release/ferrum \
  --ceta .tools/ceta-relative-bounds --jobs 1 --timeout 65 \
  --category TRS_Standard \
  --file-list <(printf '%s\n' 'TRS_Standard/Mixed_TRS/7.ari') \
  --run-dir target/termcomp-runs/20260730-mixed7-default-applicative-orders-60s \
  --progress-interval 1
```

Focused validation passed the 16 rewriting tests, 14 KBO tests, the exact
Mixed7 Arctic/KBO residual regression, and CeTA's forward-instantiation CPF
regression. The release build with 32 jobs also passed.

## 2026-07-30 `Waldmann_06/jwteparla1` certified recovery

The TermCOMP 2025 AProVE certificate for
`TRS_Standard/Waldmann_06/jwteparla1.ari` uses `switchInnermost`, dependency
pairs, a linear natural polynomial reduction pair, narrowing with the empty
position as its region, empty usable rules, and instantiation. CeTA accepts
that archived certificate.

Ferrum was missing the empty narrowing region. CeTA's `qnarrows_impl` searches
rewrite sites throughout the selected region, so the empty position can
generate a rewrite below the marked root while checking the graph side
condition on the complete DP terms. Ferrum now includes this region and has an
exact regression for the AProVE witness.

The investigation also fixed two certification issues:

1. Q-aware graph decomposition now uses CeTA's executable
   `tcap && reverse-tcap && IEDG && !nonreach` condition without Ferrum's former
   extra Q-cap filter.
2. Ordinary `dpTrans` once again emits every standard dependency pair. Calls
   encompassed by LHS subterms may only be removed by an explicit certified
   processor, not silently during DP construction.

The default strategy races `switch-innermost` with the existing Standard
orders and uncurrying branches. The focused default run produced one YES and
one certified YES in 2.4 seconds:

```text
target/termcomp-runs/20260730-jwteparla1-default-ceta-graph-60s
```

A regression rerun of the eight previously certified nearby Standard
examples retained all results with exact alignment: 8 YES, 8 certified YES,
and zero certification failures:

```text
target/termcomp-runs/20260730-next-standard-eight-complete-dp-root-region-graph
```

No CeTA source or generated checker changes were needed for this recovery.
Certification used the existing `.tools/ceta-relative-bounds` executable, so
there is no CeTA branch or commit to integrate.

Validation passed all 17 narrowing/CPF-focused tests and the complete-DP
regression. A broad 422-test library run was stopped after more than five
minutes because an unrelated matrix/Z3 test did not return; that shared run
also showed unrelated concurrent CSR/RFC failures. No Isabelle build was
started. Future Isabelle verification from this thread must use a separate
`ISABELLE_OUTPUT` directory.

## 2026-07-30 `Waldmann_06/jwmatchb1/2` certified recovery

AProVE's TermCOMP 2025 certificates use
`switchInnermost -> dpTrans -> narrowingProc -> forwardInstantiationProc ->
redPairProc -> pIsEmpty`. The reduction pair is a two-dimensional natural
matrix interpretation. Ferrum already represented every proof node, but its
forward-instantiation ordering selected weaker minimized witnesses and its
higher-dimensional matrix search used solver/width variants whose performance
was unstable.

Ferrum now prioritizes exact CeTA-coverage witnesses and, among them, exact
unary projections. After such a transformation it immediately decomposes the
graph, tries subterm, and races size change, semantic labeling, sparse and
unrestricted matrices, Arctic matrices, path orders, and KBO. The sparse matrix
class used here has dimension 2, constants at most 1, coefficients at most 3,
and at most 12 nonzero entries.

The matrix encoding now always uses its exact overflow-free bit width. Search
is deterministic: cvc5 handles dimension 1, while dimensions greater than 1
use Boolector's functional engine with CryptoMiniSat. Ferrum removes
semantically irrelevant marked rows outside the strict dimension and fixes a
marked-root constant to zero only when that same marked root occurs on both
sides of every DP, where the constant cancels. Every model is rechecked using
unbounded natural arithmetic before CPF export.

The focused current-binary run produced two YES and two certified YES, with no
checker failure:

```text
target/termcomp-runs/20260730-jwmatchb-after-deadline-fix
```

`Waldmann_06/jwaprove2.ari` exposed a nearby timeout race. A DP parallel branch
could queue `Proved` just before its deadline, but the coordinator checked the
clock before draining the queue and discarded it. Branch results now carry a
completion timestamp: queued in-time proofs are accepted and late proofs are
rejected. Semantic labeling's measured recursive proof plus cooperative solver
cleanup takes about 1.7 seconds, so its default budget is now 3 seconds instead
of 1. The recovered certificate is retained at:

```text
target/termcomp-runs/20260730-jwaprove2-semlab-3s
```

The final 15-example regression slice reports 11 YES, 11 certified YES, one
MAYBE, three batch timeouts, and zero certification failures. The older
pre-strengthening slice had 6 YES and 6 certified YES. Artifacts are retained
under:

```text
target/termcomp-runs/20260730-next-standard-15-jwmatchb-final
```

Focused validation passed all 11 forward-instantiation and CPF tests, the
release build, the two-example `jwmatchb` run, and independent CeTA checking.
A broad dependency-pair test run passed 154 of 167 tests; 13 failures were in
concurrently changing CSR, Q-aware graph, instantiation, and existing parallel
test fixtures and are not treated as passing validation for this change.

No CeTA source or generated-checker change was needed. These certificates use
the existing `.tools/ceta-relative-bounds` executable, so there is no CeTA
branch or patch to integrate.

## 2026-07-30 `Waldmann_06/jwcime1` certified recovery

AProVE's TermCOMP 2025 certificate switches to innermost rewriting, decomposes
the initial DP graph, applies forward instantiation to separate original pairs,
uses a two-element semantic labeling, and closes the labeled components with
linear natural reduction pairs and further graph decomposition.

Ferrum found the same first forward-instantiation witness, but then repeatedly
transformed syntactically larger descendants of that pair. The previous
per-pair counter used the current canonical pair as its key, so every generated
shape received a fresh budget. Terms grew deeply and the proof timed out before
semantic labeling.

`DpBranchState` now maintains a branch-local map from every generated pair to
its persistent origin. Rewriting, narrowing, instantiation, and forward
instantiation register their generated pairs. Per-kind limits are charged to
the resolved origin, while unrelated original pairs retain separate budgets.
This changes search only; DP equality, proof terms, and CPF checking are
unchanged.

The isolated 85-second diagnostic closed and certified in 8 seconds:

```text
target/termcomp-runs/20260730-jwcime1-persistent-transform-origin
```

The 60-second four-example regression retained `jwaprove2`, `jwmatchb1`, and
`jwmatchb2` and added `jwcime1`: 4 YES, 4 certified YES, and zero checker
failures. Under four-way load, `jwcime1` took 52.5 seconds.

```text
target/termcomp-runs/20260730-jwcime1-origin-regression-60s
```

The transform-origin unit regression and all 11 forward-instantiation/CPF tests
pass. No CeTA change was needed; certification uses the existing
`.tools/ceta-relative-bounds` executable, with no checker branch or patch to
integrate.

## 2026-07-30 `Endrullis_06/pair3hard` certified recovery

AProVE's certified proof uses KBO with dependency-pair argument filtering,
forward instantiation, semantic labeling over carrier two, graph decomposition,
and linear polynomial deletion. Ferrum already obtained the relevant singleton
after its initial reduction-pair step. Since DP termination is downward closed
under sound reduction-pair deletion, the fix targets the residual search rather
than requiring AProVE's exact deletion history.

After a general forward-instantiation step, Ferrum now runs graph
decomposition, the cheap component portfolio, semantic labeling, and then its
remaining fallback. Semantic labeling prioritizes a nonzero constant for a
non-nullary constructor only when that constructor occurs in a rule or DP LHS.
This puts `a = 1, p = 0, p# = 0` first for `pair3hard`, while retaining
`a = 1, f = 0, f# = 0, h = 0` first for `jwaprove2`, whose `h` is RHS-only.
All candidates still undergo the existing finite-model validation and recursive
CPF proof construction.

Focused concurrent reproduction:

```console
python3 scripts/termcomp_trs_compare.py \
  --jobs 2 \
  --timeout 60 \
  --category TRS_Standard \
  --file-list target/termcomp-runs/20260730-pair3hard-jwaprove2-lhs-model-order-input.txt \
  --run-dir target/termcomp-runs/20260730-pair3hard-jwaprove2-lhs-model-order-2x60s \
  --extra-arg=--strategy \
  --extra-arg='timeout(55s, default)' \
  --progress-interval 1
```

This gives 2 YES and 2 certified YES. The five-way retained regression is:

```text
target/termcomp-runs/20260730-pair3hard-regression-5-lhs-model-order-5x60s
```

It gives 5 YES, 5 certified YES, zero timeouts, and zero checker failures.
The structural regression
`pair3hard_aprove_kbo_argument_filter_orients_ferrum_residual` passes, as does
the release build. No CeTA source or generated-checker change was needed;
certification uses `.tools/ceta-relative-bounds`, with no checker branch or
patch to integrate.

## 2026-07-30 `Waldmann_06/jwtpa1` certified recovery

The retained AProVE certificate switches to innermost rewriting, decomposes the
initial graph, forward-instantiates one pair, applies a two-element semantic
labeling, and repeatedly combines usable-rule linear polynomial deletion with
graph decomposition.

Ferrum synthesized the same witness, but the early innermost transform stage
previously committed to ordinary instantiation. A temporary parallel race
proved the forward branch in 8.4 seconds but took 39 seconds overall because
the scope joined the losing recursive instantiation branch. The final schedule
therefore gives forward instantiation a 10-second compound proof budget first
and runs the 250-millisecond ordinary-instantiation attempt only if needed.

Focused reproduction:

```console
python3 scripts/termcomp_trs_compare.py \
  --jobs 1 \
  --timeout 60 \
  --category TRS_Standard \
  --file-list target/termcomp-runs/20260730-jwtpa1-current-input.txt \
  --run-dir target/termcomp-runs/20260730-jwtpa1-fi-first-10s \
  --extra-arg=--strategy \
  --extra-arg='timeout(55s, default)' \
  --progress-interval 1
```

This gives one YES and one certified YES in 7.5 seconds. The six-example
concurrent regression is retained at:

```text
target/termcomp-runs/20260730-jwtpa1-regression-6x60s
```

It gives 6 YES, 6 certified YES, zero timeouts, and zero checker failures;
`jwtpa1` takes 8.3 seconds under load. The release build and
`innermost_forward_instantiation_uses_active_rules_and_preserves_q` regression
pass. No CeTA source or generated-checker change was needed; certification uses
the existing `.tools/ceta-relative-bounds` executable, with no checker patch to
integrate.

## 2026-07-30 `Zantema_05/z01` certified recovery

The retained AProVE CPF combines uncurrying, top-level polynomial rule removal,
switch-to-innermost, narrowing, dependency-graph decomposition, forward
instantiation, four-dimensional natural-Arctic reduction pairs, carrier-two
semantic labeling, and usable-rule polynomial deletion.

Ferrum now attempts monotonic polynomial removal on an uncurried Standard TRS,
supports affine-offset semantic-model functions such as `1 + x`, and tries two
independently checked four-dimensional unary Arctic witnesses in its cheap
applicative reduction-pair step. Ferrum rechecks every candidate against the
current usable-rule DP problem, and CeTA checks the emitted CPF.

The first generic dimension-four probe is retained at
`target/termcomp-runs/20260730-z01-arctic4-60s`; it timed out and exposed a
roughly 37 GB losing solver branch. The checked templates produced a certified
proof in 16.8 seconds at
`target/termcomp-runs/20260730-z01-affine-semlab-first-60s`. Moving the cheap
template attempt ahead of the generic parallel portfolio made the focused run
finish in under one second:

```console
python3 scripts/termcomp_trs_compare.py \
  --jobs 1 \
  --timeout 60 \
  --category TRS_Standard \
  --file-list target/termcomp-runs/20260730-z01-current-input.txt \
  --run-dir target/termcomp-runs/20260730-z01-sequential-arctic-template-60s \
  --extra-arg=--strategy \
  --extra-arg='timeout(55s, default)' \
  --progress-interval 1
```

The final seven-way regression is retained in
`target/termcomp-runs/20260730-z01-regression-final-7x60s`. It gives 7 YES,
7 certified YES, zero MAYBE, timeout, error, or certification failure in 16
seconds total. The
`unary_semantic_labeling_candidates_include_affine_offset_model` and
`unary_dimension4_arctic_templates_are_well_formed` unit regressions pass.
Direct replay of the focused and loaded CPFs returns `CERTIFIED`.

No CeTA source or generated-checker change was needed. Certification uses the
existing `.tools/ceta-relative-bounds` executable, with no checker branch or
patch to integrate.

## 2026-07-31 next six certified Standard frontier examples

The next focused replay first isolated `Various_04/13.ari` with a bare DP
strategy and then confirmed that the unchanged default strategy proves it in
under one second. Both CPFs are CeTA `CERTIFIED`:

```text
target/manual-probes/20260731-next-six-focused-60s/v13
target/manual-probes/20260731-v13-default-60s
```

A neighboring default-strategy batch recovered five more AProVE 2007 systems:

```text
target/manual-probes/20260731-next-aprove07-neighbors-5x60s
```

`AProVE_07/kabasci04.ari` and `AProVE_07/wiehe01.ari`, `wiehe02.ari`,
`wiehe03.ari`, and `wiehe05.ari` all return YES, emit full CPF artifacts, and
are CeTA `CERTIFIED`. Thus this pass adds six certified frontier recoveries,
with zero certification failures among them.

Two proof-skeleton probes are retained at:

```text
target/manual-probes/20260731-z05-z26-proof-skeletons-90s
```

They do not close. In particular, AProVE's short certified `Zantema_05/z26`
proof uses a monotonic natural polynomial deletion, a 2D integer-domain matrix
interpretation, and a final usable-rules polynomial/SCT closure. Ferrum still
lacks integer matrix synthesis, validation, and CPF export, making `z26` a
concrete regression target for that processor class. No graph-estimation or
CeTA source changes were made in this pass.

## 2026-07-31 exact CeTA weak-polynomial replay boundary

A later blanket guard against negative constants under usable rules or Q
regressed the already certified `AProVE_06/factorial1` and `tower` oracle
replays. The guard conflated two facts: negative constants are valid in these
CPF natural-polynomial proofs, while CeTA's executable comparison is a sound
but incomplete approximation of their max semantics.

Ferrum now mirrors CeTA's `Linear_Poly_Order` boundary directly. For an
obligation `l >= r`, it constructs CeTA's `Pleft l` and `Pright r`: constants
on the left are clamped only for ground subterms, and constants on the right
are clamped at every function application. Coefficients and constants of those
two affine bounds are then compared exactly. This restores the valid
negative-constant proofs while rejecting the historical uncertifiable `z07`
and `tpa2` candidates at the same obligation that CeTA reports.

The focused weak-polynomial suite has ten passing tests. With fallback disabled
and oracle v151, the current release proves both `factorial1` and `tower` in one
two-worker replay; each generated CPF was checked twice with
`/work/dfm/festschrift/CeTA-CSR/ceta` and returned `CERTIFIED` both times:

```text
target/manual-evidence-replay-v147-20260731/strict-v152-ceta-poly-boundary
```

## 2026-07-31 `AProVE_06/identity` certified recovery

AProVE's TermCOMP 2025 certificate first removes `id(x) -> f(x,s(0))` and
`f(s(0),y) -> y` by two monotonic natural polynomial interpretations. The
residual is overlay and WCR, so it switches to innermost rewriting. Its hard
singleton DP is

```text
f#(s(x),y) -> f#(half(s(x)),double(y)).
```

The decisive rational interpretation uses denominator four and delta one
half: `f#(x,y) = x/4`, `s(x) = 4+x`, `half(x) = x/2`, and
`g(x,y) = y/2`. CeTA's `matchCapRMBelow` usable-rule closure retains the
three compatible `g` rules and the `half` rule while excluding the
incompatible `g(d,s(x))` and `double` rules.

Ferrum previously used a root-symbol approximation after deriving an argument
filter, so reaching `g(h,x)` incorrectly activated every `g` rule and made the
witness impossible. The argument-filtered closure now uses all immediate
argument caps when matching rule LHSs and recurses only through active
positions. A checked, symbol-independent halving-recursion candidate supplies
the rational witness before the slower generic nonlinear SMT search. The
top-level polynomial residual continuation also retries `switchInnermost`
after exhaustive rule removal.

Retained artifacts:

```text
target/manual-probes/20260731-identity-ceta-usable-rational-fixed
target/manual-probes/20260731-identity-default-certified-final
target/manual-probes/20260731-rational-usable-regression-2x60s
```

The focused preprocessing proof and the unchanged default proof both return
YES and CeTA `CERTIFIED`; the default finishes in about one second. The
regression contains `AProVE_07/thiemann40` and `Beerendonk_07/7`; both remain
default-certified. All five rational-polynomial unit tests pass.

The same run also tested a bounded narrowing/rewriting continuation on seven
hard `AProVE_06` transformation examples. All seven still timed out at 90
seconds, so that scheduling change alone is not credited with a recovery.
Artifacts are retained under
`target/manual-probes/20260731-aprove06-next6-bounded-transform-90s` and
`target/manual-probes/20260731-factorial2-bounded-narrow-rewrite-90s`.

No CeTA changes were required. Both new `identity` certificates and both
rational regressions are accepted by `.tools/ceta-relative-bounds`; there is
no checker patch or branch to integrate.

The integration thread replayed both certificates twice with
`CeTA-CSR/ceta`, then refroze their current live processor states. Seven
complete state proofs and ten typed transformations were retained, with zero
checker rejections. The resulting monotone overlay is
`target/integration-identity-thiemann01-20260731/oracle-v146.jsonl` (SHA-256
`a277ea23e520c84ee194c24a96bb5ca98a9147c900a8ab0e9f95736d3ac5fb11`).
`identity` replays strictly oracle-only in 1.262 seconds. `thiemann01` remains
an efficiency task: its exact compound root recipe completed in 130.351
seconds under campaign load and the resulting proof certified twice. The
lenient monotone overlay is
`target/integration-identity-thiemann01-20260731/oracle-v147-thiemann01-lenient.jsonl`
(SHA-256
`e32538428f54999e6a778547328df197ac7b6d569e0f46aa14dd254a1172ab0c`).
It remains outside the 60-second strict target; no unchecked root
recommendation was promoted.

The first end-to-end guided attempt exposed an execution-policy mismatch:
ordinary explicit `dp(...)` atoms still inherited nested oracle guidance,
although the CSR dispatcher already disabled it. Ferrum now runs an explicit
compound DP recipe exactly and reserves recursive child lookup for a bare
`dp`. An isolated release build succeeded. With that fix, the v147 oracle-only
replay completes in 196 seconds under the active campaign and its CPF passes
two further CeTA-CSR checks. This establishes replayability within the
300-second hard atom cap while leaving the 60-second efficiency gap visible.

The neighboring eight-example AProVE 2007 replay is retained at:

```text
target/manual-probes/20260731-precise-usable-next8-60s
```

`thiemann01` is an additional default YES and CeTA `CERTIFIED` recovery in
about one second. It closes through component-level innermost switching,
narrowing, instantiation, forward instantiation, repeated graph decomposition,
and size change. `kabasci01`, `otto08`, `otto10`, and `otto13` time out.
`otto02`, `otto06`, and `otto12` produce top-level YES, but CeTA rejects their
transformed Q-aware graph decompositions because its IEDG retains a reported
edge. They are therefore certification failures, not certified gains. No graph
estimator change was made; those cases remain isolated for the separately
required theory-led graph investigation.

## 2026-07-31 next certified polynomial examples and DP transform ordering

The next short AProVE-certified Standard batch is retained at:

```text
target/manual-probes/20260731-next-short-certified-poly-6x60s
target/manual-probes/20260731-certified-gains-weak-poly-fixed-4x60s
```

With the final weak-polynomial guard in place, the unchanged default strategy
proves and CeTA certifies `Various_04/14.ari`, `CiME_04/log2.ari`, and
`AProVE_04/Liveness6.4.ari`. `Zantema_05/z07.ari` had initially produced an
uncertifiable weak-polynomial proof: a negative-constant interpretation was
used below usable rules. Ferrum again enforces the previously documented CPF
boundary that negative-constant weak polynomials are declined with non-empty
usable rules or Q. The `z07` regression now returns no proof at 60 seconds
instead of an uncertifiable YES. CeTA source changes were not needed.

The AProVE certificate for `AProVE_07/thiemann03.ari` uses the innermost DP
chain `narrowingProc`, `rewritingProc`, `narrowingProc`, followed by a small
polynomial reduction pair. Ferrum's transformation continuations now try
rewriting before repeated narrowing and permit one bounded narrowing after a
rewrite. The retained traces show Ferrum selecting the same regional
narrowing at position 1 and the same `head(add(...))` rewrite:

```text
target/manual-probes/20260731-thiemann03-narrow-rewrite-narrow-90s
target/manual-probes/20260731-thiemann03-early-narrow-chain-default-60s
```

The local transformed SCC closes, but the enclosing Standard strategy still
times out. This is a strategy result-propagation/cancellation issue rather than
a graph-estimation change; graph estimation was not modified in this work.

## 2026-07-31 negative-constant polynomial guard regression

Ferrum's exact weak-polynomial validator already implements the CPF natural
linear-polynomial semantics `max(0, c + sum(a_i x_i))` recursively and rejects
candidates by QF_LIA counterexample queries. A stale front-end guard nevertheless
rejected every interpretation containing a negative constant before that exact
validator ran. The guard was removed. This matches IsaFoR's formally verified
`Linear_Poly_Order.eval_termI` semantics and CeTA's existing CPF parser path for
degree-one natural polynomial interpretations.

The focused weak-polynomial unit suite now includes positive negative-constant
examples, a nested-max example, the former TPA2 candidate, and a genuinely
non-strict max-boundary rejection. CeTA's existing negative-constant CPF unit
certificate also passes.

Two real Standard regressions retain full artifacts:

```text
target/manual-probes/20260731-factorial1-negative-guard-regression
target/manual-probes/20260731-kabasci05-negative-guard-default
```

`factorial1` returns YES with three negative constants in its CPF and CeTA
returns `CERTIFIED`. `kabasci05` returns YES in about 38 seconds and CeTA also
returns `CERTIFIED`; its winning run uses a nonnegative natural polynomial for
the `gcd#` SCC and a rational polynomial for the final five-pair SCC.

No CeTA source or generated-checker change was needed. Both certificates are
accepted by `.tools/ceta-relative-bounds`, so there is no checker patch to
integrate.

## 2026-07-31 AProVE 2006 frontier slice

Eight formerly unresolved AProVE 2006 Standard examples were rerun with eight
workers and a 60-second per-example limit. Full per-example commands, progress
streams, stdout/stderr, CPF, checker output, and result records are retained at:

```text
target/termcomp-runs/20260731-aprove06-next8-current-8w60s
```

The result is one certified YES (`tower`) and seven timeouts. Together with the
separate `kabasci05` replay, this recovers two YES/CERTIFIED YES results from the
refreshed 64-example frontier.

The most actionable remaining example is `factorial2`. AProVE's certified CPF
uses switch-innermost, narrowing twice, rewriting twice, forward instantiation,
and size change, with dependency-graph decomposition after every DP
transformation. Ferrum has all of those processors, but a focused replay at

```text
target/manual-probes/20260731-factorial2-aprove-transform-chain-events-v2
```

times out after producing 1,103 processor events and 211 graph attempts. The
transformed residual portfolio reaches 48 pairs. The cause is transformation
continuation scheduling: a narrowing candidate recursively enters a broad
hard-coded portfolio rather than the explicit strategy tail, and unbounded
recursive transform atoms expand many alternatives. This is not evidence for
changing dependency-graph estimation. The next fix should make transformation
continuations bounded and strategy-driven while retaining enough lineage budget
for AProVE's required second narrowing.

No CeTA changes were made or required by this investigation.

## 2026-07-31 `Strategy_removed_AG01/#4.26` rational recovery

AProVE switches this eight-rule Standard TRS to innermost rewriting and splits
its five dependency pairs into two cyclic SCCs.  On the two-pair SCC it applies
usable rules and innermost-LHS removal, then deletes the `if# -> minus#` pair
with a rational linear interpretation over denominator four.  The residual
components are closed by graph decomposition and existing processors.

Ferrum already computed the same five usable rules and its independent exact
checker accepted AProVE's interpretation.  The generic nonlinear integer SMT
encoding nevertheless needed about 20 seconds even in its dedicated unit test,
which exhausted the switched branch.  `rat-poly` now first recognizes the
symbol-independent predecessor/comparison shape from the two pairs and five
rules.  It constructs the corresponding quarter-grid candidate and passes it
through the ordinary rational orientation checker; malformed shapes or invalid
orientations are declined.  The production residual probe falls from a timeout
to a transformed result in 1 ms.

The complete innermost artifact is:

```text
target/manual-probes/20260731-ag01-426-innermost-structural
```

The unmodified innermost default strategy is independently retained at
`target/manual-probes/20260731-ag01-426-innermost-default-structural`; it also
returns certified YES.  Older full Innermost runs repeatedly recorded this
problem as UNKNOWN or timeout, including the 60-second component-portfolio and
Q-aware-IEDG runs, so this is a gain in both TermCOMP categories rather than
only a Standard-switch recovery.

The original Standard problem, including the top-level innermost switch, is:

```text
target/manual-probes/20260731-ag01-426-standard-switch-structural
```

Both return YES and CeTA returns `CERTIFIED`.  The current default strategy also
returns a certified YES in the retained artifact
`target/manual-probes/20260731-ag01-426-default-structural`.

The five-example loaded regression is retained at
`target/termcomp-runs/20260731-next-rational-structural-regression-5x60s` with
full per-example artifacts.  It gives four certified YES (`#4.26`, `z25`,
`SK90/4.02`, and `aprove4`); `factorial1` is UNKNOWN at its 55-second inner
deadline under this load, while its earlier isolated and loaded certified
artifacts remain unchanged.  Thus the regression records the load-sensitive
performance result rather than claiming a five-of-five closure.

No CeTA source or generated-checker change was needed.  The proof is accepted
by the existing `.tools/ceta` executable, so there is no checker branch or
patch to integrate.

## 2026-07-31 transformed-CSR adaptive round 2 and strict replay

The second adaptive state-first round completed 17,316 probes with 1,519
certified terminal trials, 5,084 certified transformations, 4,604 typed
assembly transitions, and 366 complete certified assemblies.  The immutable
ledger and summary are retained under
`target/data-campaign/state-first-adaptive-20260731-transformed-csr-v115/rounds/r02-probes`.

Freezing deduplicated the terminal and assembled evidence to 1,478 unique CPF
proofs.  Every proof passed two independent `CeTA-CSR/ceta` checks; none was
rejected.  The freezer now emits a deduplicated manifest whose `origins` array
lists every covered database obligation.  The oracle exporter initially only
understood the older flat manifest and therefore rejected all promotions
safely.  It now accepts both schemas, with regression coverage.  The corrected
v136b export promoted 2,694 certified evidence rows, retained 4,238 weak
transformation hints, and promoted zero uncertified positives:

```text
target/data-campaign/state-first-adaptive-20260731-transformed-csr-v115/rounds/r02-frozen-union
target/data-campaign/state-first-adaptive-20260731-transformed-csr-v115/rounds/oracle-global-v136b-r02-manifest-fixed.jsonl
sha256 5a88a23f530d3f1414a8155865eb1b1f3180d7f142f90909e245c9fe6b7d7d82
```

Strict oracle-only replay over the 201 previously unresolved transformed-CSR
roots certified four new YES results.  Oracle-plus-default replay certified 12
roots (eight YES and four NO), with zero checker failures.  Every retained
decisive replay CPF was checked twice again.  The exact replay artifacts are:

```text
target/data-campaign/state-first-adaptive-20260731-transformed-csr-v115/rounds/r02-rerun-oracle-only-v139-60s
target/data-campaign/state-first-adaptive-20260731-transformed-csr-v115/rounds/r02-rerun-oracle-plus-fallback-v139-60s
```

After independently freezing the newly reported structural-rational and
negative-constant polynomial proof states, strict no-fallback replay is 5/5
for the former batch and 3/3 for the latter.  The current monotone overlay is:

```text
target/integration-negative-polynomial-20260731/oracle-global-v141-negative-polynomial-frozen.jsonl
sha256 806d5f0e3138bc3b9db5c415089d0c93e5caa2ed6bb1f6d6cb5ff8abad89c130
```

## 2026-07-31 strict oracle-only integration of `Secret_05_TRS/aprove4`

The final component-level `switchInnermostProc` proof was replayed with the
current release binary and certified twice by `CeTA-CSR/ceta`. Its root and CPF
proof-path states were combined with independently probed live residual states;
this is necessary because the root `dp` action has a complete reconstructed CPF
node while the executable nested continuation is keyed by Ferrum's live typed
states. The resulting monotone oracle is:

```text
target/integration-aprove4-dp-switch-20260731/oracle-global-v135-aprove4-combined.jsonl
sha256 3557ecd28bada1201ec3cbc6a33e305959e970a82dfac1d0a228d7e33ab7084d
```

With `FERRUM_DP_LLM_NO_FALLBACK=1` and the fallback strategy replaced by
`timeout(60s, fail)`, `aprove4` returns certified YES in about one second. The
strict replay CPF independently returns `CERTIFIED` twice. An earlier overlay
was intentionally superseded after the implementation began preserving the
NFS flag across the DP-level switch; those old and new child states are
genuinely different rather than a canonicalization collision. No CeTA change
was required.

## 2026-07-31 DP-level `switchInnermostProc` and `Secret_05_TRS/aprove4`

AProVE's certified proof for `Secret_05_TRS/aprove4` switches an individual
minimal DP component from full to innermost rewriting. The whole TRS does not
satisfy Ferrum's top-level switch criterion, so strengthening the top-level
processor would have modeled the wrong proof step.

Ferrum now implements the CPF/CeTA DP processor from
`Nontermination/Innermost_Switch_Impl.thy`. It applies only to ordinary,
minimal, full-rewriting DP states with empty `Q`; requires no overlap of an
active rewrite-rule left-hand side at any non-variable position of a DP
left-hand side; proves weak confluence of the active weak rules; and continues
with the unchanged pairs and rules under `Q = lhs(R)`. CPF export emits
`switchInnermostProc` with the checked `joinAutoBfs` depth and serializes the
child as an innermost DP proof.

The first probe intentionally exposed an overlap-direction defect: CeTA
rejected a switch over `le#(p(s(x)),x)` because `p(s(x))` is an `R` redex in
the pair left-hand side. The implementation was corrected to use the exact
CeTA direction, and a unit regression now covers it.

The corrected focused artifact is retained at:

```text
target/manual-probes/20260731-aprove4-dp-switch-v4-nfs-preserved
```

It returns YES and its CPF, containing one applicable component-level switch,
is accepted by `.tools/ceta` as `CERTIFIED`. The default-strategy artifact is:

```text
target/manual-probes/20260731-aprove4-default-dp-switch-final
```

It is likewise a certified YES. The eight-example regression at
`target/termcomp-runs/20260731-next-small-certified-cluster-dp-switch-8x60s`
reproduces 6 certified YES, 1 certified NO, and the pre-existing
`SK90/4.40` timeout, with no MAYBE, error, or certification failure.

A follow-up run over `Zantema_05/z12` through `z18` is retained at
`target/termcomp-runs/20260731-z12-z18-dp-switch-7x60s`. It produced no new
answer: all seven reached 60 seconds. Inspection of AProVE's CPF2 evidence
shows that these are not direct switch examples. Their switch occurs only
after an AAECC innermost transformation and a QDP-to-SRS transformation,
represented there by `unknownProof` nodes. Ferrum currently implements
neither transformation, so scheduling more post-switch search would not
reproduce those proofs. A six-second branch was also tested and was too tight
under system load, so the default retains the certified 15-second setting;
`aprove4` needs about four seconds in the retained focused run.

No CeTA source or generated-checker change was needed. This uses the existing
formally verified `switchInnermostProc` implementation in the standard CeTA
tree and the existing `.tools/ceta` executable.

## 2026-07-31 `Secret_05_TRS/teparla1` instantiation-chain recovery

AProVE's certified proof decomposes the five initial dependency pairs into
singleton components. The only cyclic component is weakly compatible with a
monotonic natural polynomial interpretation and is then eliminated by three
instantiation steps. Ferrum already implemented and exported every required
processor, but the Standard default strategy did not schedule repeated
ordinary instantiation early enough.

Two focused probes are retained at:

```text
target/manual-probes/20260731-teparla1-inst3
target/manual-probes/20260731-teparla1-mono-inst3
```

Both return YES and both CPFs are accepted by CeTA. The AProVE-shaped variant
finishes in 83 ms. The default strategy now races a five-second branch with
graph decomposition, monotonic polynomial compatibility, and three bounded
ordinary-instantiation stages. Every transformation is followed immediately
by dependency-graph decomposition.

The focused production run is:

```text
target/termcomp-runs/20260731-teparla1-default-instantiation-chain
```

It reports one certified YES in under one second. The final eight-example
regression is:

```text
target/termcomp-runs/20260731-next-small-certified-cluster-instantiation-chain-8x60s
```

It reports 6 certified YES, 1 certified NO, and one timeout, with no MAYBE,
error, or certification failure. Relative to the original baseline, the
cluster improves from four certified answers to seven. The sole remaining
timeout is `SK90/4.40`.

The complete live proof and every independently indexed residual are retained
under `target/integration-teparla1-20260731`. The producing CPF, recovered live
CPF, frozen terminal fragments, and strict replay CPF were checked twice with
`../CeTA-CSR/ceta`. Re-extracting the completed strict CPF promotes eight
transformation observations from weak placeholders to strong proof-path
evidence. The resulting monotone v128 oracle is
`target/integration-teparla1-20260731/oracle-global-v128-teparla1-reconstructed.jsonl`
(SHA-256
`f69574a233d115892e385132bf47d4d97ce04a50502b081ed18a58f0337f14cd`).
With the top-level strategy replaced by `timeout(60s, fail)` and DP fallback
disabled, strict oracle-only replay finishes in 1.12 seconds and CeTA-CSR
certifies the resulting CPF twice.

No CeTA source or generated-checker change was needed. Certification uses the
existing `.tools/ceta-relative-bounds` executable, so there is no checker
patch to integrate.

A follow-up probe over four old full-run misses with AProVE instantiation
certificates is retained at:

```text
target/termcomp-runs/20260731-next-instantiation-certified-cluster-4x60s
```

It gives one certified YES (`Waldmann_06/jwteparla1`) and three MAYBE
(`Secret_05_TRS/aprove2-4`). The `jwteparla1` winner is a `switchInnermost`
proof, not the new instantiation chain; a focused instantiation-only replay at
`target/manual-probes/20260731-jwteparla1-instantiation-chain` declines it.
The three remaining AProVE certificates require richer interleavings of graph
decomposition, forward and ordinary instantiation, narrowing, rewriting,
subterm/size-change, and KBO or polynomial orders.

## 2026-07-31 focused rule-removal tail and nested-ground DP loop

A fresh eight-example AProVE-certified Standard cluster was first run at:

```text
target/termcomp-runs/20260731-next-small-certified-cluster-baseline-8x60s
```

It produced 4 certified YES, 2 MAYBE, and 2 timeouts. AProVE's certificate for
`Secret_06_TRS/5` first removes one rule with a monotonic linear polynomial,
then uses graph decomposition, a monotonic polynomial DP reduction pair, and a
1D natural-Arctic reduction pair. Ferrum could reproduce and certify the DP
tail in 61 ms, but its top-level rule-removal processor was scheduled after a
55-second transformation race.

Ferrum now races top-level polynomial rule removal among the early orders.
After a successful removal, the processor tries the focused graph /
`mono-poly` / graph / 1D `arctic-matrix` / graph continuation for at most five
seconds before entering the broad residual portfolio. The default focused run
is retained at:

```text
target/termcomp-runs/20260731-secret06-5-default-focused-poly
```

It reports one YES and one certified YES in under one second.

AProVE's `Secret_05_TRS/ttt1` NO certificate instantiates a DP variable with
`cons(s(a),s(b))`, applies the two projection rules relatively, and closes the
DP loop. Ferrum's former ground basis stopped after one constructor layer.
The basis now performs two bounded unary/binary closure rounds, retaining at
most 512 terms. The production default run is:

```text
target/termcomp-runs/20260731-ttt1-default-ground-dp-loop
```

It reports one NO and one certified NO in about one second. The strengthened
eight-example run at
`target/termcomp-runs/20260731-next-small-certified-cluster-focused-poly-8x60s`
was performed before the DP-loop change and reports 5 certified YES, 1 MAYBE,
and 2 timeouts, with no certification failures.

The final post-change run is:

```text
target/termcomp-runs/20260731-next-small-certified-cluster-two-recoveries-8x60s
```

It reports 5 certified YES, 1 certified NO, and 2 timeouts. Relative to the
initial run, `Secret_06_TRS/5` changes from MAYBE to certified YES and
`Secret_05_TRS/ttt1` changes from MAYBE to certified NO. There are no losses,
uncertified decisive answers, or certification failures. The two remaining
timeouts are `SK90/4.40` and `Secret_05_TRS/teparla1`.

The six `dp_loop_` tests pass, including CeTA-facing CPF tests, constant-free
symbolic search, multiple marked steps, and the new nested-ground witness.
Ground substitution products larger than the existing 4096-state loop
frontier are skipped, preventing the deeper term basis from multiplying
multi-variable candidates without bound.

No CeTA source or generated-checker change was needed. Both new proof shapes
are accepted by the existing `.tools/ceta-relative-bounds` checker, so there
is no checker patch to integrate.

## 2026-07-31 Endrullis strict-oracle residual recovery

The five-example `Endrullis_06` cluster is now 5/5 certified under the current
default strategy:

```text
target/termcomp-runs/20260731-endrullis-cluster-all-certified-5x60s
```

The retained `linear2` and `pair3swap` certificates were checked twice with
`CeTA-CSR/ceta`. Their current monotonic-polynomial, forward-instantiation,
natural-Arctic, and natural-matrix residual states were then independently
replayed and added to the monotone oracle. The strict replay uses
`timeout(60s, fail)` with both top-level and nested fallback disabled:

```text
target/integration-endrullis-linear2-pair3swap-refresh-20260731/strict-v122-debug-60s
```

Both examples return certified YES, and both reconstructed CPFs pass two
additional deterministic CeTA-CSR checks. This also exposed and fixed a replay
policy mismatch: nested oracle-guided DP atoms still had hidden two-, four-,
or eight-second portfolio ceilings. Certified oracle atoms now inherit the
full 60-second local replay allowance. No CeTA source change was required.

The subsequent transformed-CSR state import exposed a separate preprocessing
scaling defect. Canonical CPF payloads as large as hundreds of MiB were sent
through a `multiprocessing.Queue`; receiving one giant pipe frame made
`get_nowait` block and prevented timely worker cancellation. Parallel
canonicalization now transfers the XML through per-worker temporary files and
uses the queue only for bounded metadata. The repaired 64-worker pass remained
responsive and imported 175,556 event rows. States exceeding the 60-second
canonicalization ceiling retain their raw content-addressed identity and are
reported as fallback inputs rather than being merged or discarded.

## 2026-07-31 mixed dependency-pair loops

The next five small AProVE-certified `Strategy_removed_AG01` examples were
recorded in:

```text
target/next-strategy-removed-ag01-5.list
target/termcomp-runs/20260731-next-strategy-removed-ag01-5x60s
```

The baseline gave two certified NO, one certified YES, and two MAYBE.
AProVE's retained certificates identify both misses as mixed dependency-pair
loops. `#4.12a` uses two marked DP steps separated by relative TRS rewrites.
`#4.4` has no constants and uses a symbolic relative rewrite before returning
to its marked pair.

Ferrum's DP loop search formerly fixed one marked step first and allowed only
relative TRS rewrites afterward. It now searches bounded mixed `P/R` cycles.
The ground path permits further marked root steps; the symbolic path narrows
with both DP and base rules and checks every immediate closing successor before
recursing. Before accepting a result, Ferrum independently replays the loop,
checks marked root rules modulo variable renaming against the active DP set,
and checks every relative rule against the original TRS.

The final retained replay is:

```text
target/termcomp-runs/20260731-strategy-removed-ag01-mixed-dp-loop-final-5x60s
```

It gives one certified YES and four certified NO in two seconds, with no
MAYBE, timeout, error, or certification failure. The two focused regressions
and the existing ground-relative DP-loop regression pass. No dependency-graph
code was changed.

No CeTA source or generated-checker change was required. The existing
`.tools/ceta-relative-bounds` executable accepts both new CPF loop proofs, so
there is no checker patch to integrate.

## 2026-07-31 first-class monotonic DP polynomials

A five-example Endrullis probe is retained at:

```text
target/next-endrullis-cluster-5.list
target/termcomp-runs/20260731-next-endrullis-cluster-baseline-5x60s
```

The baseline gave two certified YES, two MAYBE, and one timeout. The smallest
simple survivor, `Endrullis_06/pair3swap`, has an AProVE certificate consisting
of a monotonic linear polynomial DP reduction followed by a rational linear
reduction pair. Ferrum already implemented both proof forms, but attempted the
monotonic search only after its argument-filtering polynomial search had spent
the processor deadline.

Ferrum now exposes the monotonic class as the parameterized strategy processor
`mono-poly(max-constant=..., max-coefficient=..., symbols=..., arity=...)`.
The default Standard strategy races an isolated
`mono-poly; graph; rat-poly` chain against the ordinary early usable-order
ladder. This avoids duplicate recursive rational solver jobs while preserving
cooperative cancellation.

The focused default-strategy artifact is:

```text
target/termcomp-runs/20260731-pair3swap-default-dedicated-mono-rational
```

It returns a CeTA-certified YES in 37 seconds. Ferrum's proof is stronger than
the retained AProVE first step: its monotonic interpretation removes two of
three DPs, and the rational processor removes the remaining pair. The final
loaded replay is:

```text
target/termcomp-runs/20260731-endrullis-mono-rational-final-5x60s
```

It gives three certified YES, one MAYBE (`pair2hard`), and one timeout
(`linear2`), without certification failures. `quadruple1/2` remain certified.
No dependency-graph or CeTA source was changed, so there is no checker patch to
integrate.

## 2026-07-31 `pair2hard` default regression recovery

The July 29 default strategy certified `Endrullis_06/pair2hard` in 2.531
seconds, but the July 31 Endrullis replay returned MAYBE. The current run still
found the correct KBO deletion and exact forward-instantiation candidate. Its
non-unary continuation had lost the sparse four-dimensional natural-matrix
portfolio that closes the resulting singleton.

The general forward-instantiation continuation now performs graph
decomposition and then tries the checked sparse 4D class before its generic
component portfolio. The class uses exactly 11 nonzero entries, one nonzero
constant, and at most three nonzero entries per row. Ferrum's structural
candidate is still accepted only after exact matrix orientation checks.
Keeping this first attempt sequential avoids a parallel join delay observed
when the 1 ms winning matrix branch raced the generic portfolio.

The Standard usable-order ladder budget is 10 rather than 8 seconds. This is
enough for the existing KBO branch to delete a pair, forward instantiate the
residual, decompose it, and apply the sparse matrix without launching a second
global KBO race. The focused default run is:

```text
target/termcomp-runs/20260731-pair2hard-default-final
```

It gives one certified YES in 17 seconds. A two-example load guard at
`target/termcomp-runs/20260731-pair2hard-quadruple2-budget-guard` certifies
both `pair2hard` and `quadruple2`. The final five-example replay,
`target/termcomp-runs/20260731-endrullis-pair2hard-budget-final-5x60s`, gives
four certified YES and one timeout (`linear2`) with no certification failure.

No dependency-graph or CeTA source changed. Certification uses the existing
`.tools/ceta-relative-bounds` executable, so there is no checker patch to
integrate.

## 2026-07-31 `linear2` monotonic matrix chain

The retained AProVE certificate for `Endrullis_06/linear2` decomposes the DP
problem into two analogous three-pair SCCs. Each SCC first uses a monotonic
natural polynomial reduction. One residual is closed by a three-dimensional
natural-Arctic interpretation; the other certificate declares a
two-dimensional integer matrix, but every constant and matrix entry in that
witness is nonnegative and belongs to `{0,1}`.

Ferrum's focused strategy:

```text
target/linear2-mono-matrices.fs
target/termcomp-runs/20260731-linear2-mono-matrices-focused
```

proves the example in one second with existing certified processors. Ferrum
independently synthesizes and validates a 2D natural matrix for the second
component, so no integer-domain or checker extension is needed.

The default Standard strategy now includes an eight-second early branch:
graph decomposition, `mono-poly`, graph decomposition, and a parallel race
between 3D natural-Arctic and 2D natural matrices. The focused default artifact
is `target/termcomp-runs/20260731-linear2-default-final`.

The final five-example Endrullis replay is:

```text
target/termcomp-runs/20260731-endrullis-cluster-all-certified-5x60s
```

It gives five YES and five certified YES, with no MAYBE, timeout, error, or
certification failure. Wall time is 4.5 seconds with five workers. The new
branch also finds a certified natural-matrix continuation for `pair3swap` in
4.5 seconds, replacing the earlier 37-second rational route in the winning
default proof.

No dependency-graph or CeTA source changed. The existing
`.tools/ceta-relative-bounds` executable certifies every retained proof.

## 2026-07-31 AG01 precise usable rules and monotonic rule deletion

The retained AProVE certificates for `AG01/#3.22` and `AG01/#3.40` exposed two
related gaps. Ferrum's standard usable-rule computation grouped rules only by
reachable root symbols, while CeTA's executable processor uses
`check_ur_P_closed_rm_af` with `tcapRM2` matching below each RHS root.
Ferrum now computes that precise least fixed point. For `#3.22`, the hard
three-pair component therefore has exactly source rules 2, 4, and 5 as usable
rules, matching AProVE and CeTA.

Monotonic polynomial DP reductions now record every strictly oriented rule,
remove those rules from the residual `R`, and emit them in CPF
`monoRedPairProc` or `monoRedPairUrProc`. Dependency-graph decomposition runs
immediately on every resulting residual. A weak-only step is accepted only
when the usable-rule restriction itself strictly reduces `R`, preventing the
former repeated no-progress model.

Default-strategy artifacts:

```text
target/termcomp-runs/20260731-ag01-322-default
target/termcomp-runs/20260731-ag01-340-default
```

Both return YES immediately and both CPF files are accepted as `CERTIFIED` by
`.tools/ceta-relative-bounds`. The bounded diagnostic witnesses are retained
at `20260731-ag01-322-matchcap-usable` and
`20260731-ag01-340-matchcap-usable`. Guard runs for `#3.18`, `#3.19`, and
`#3.39` are retained in the corresponding
`20260731-ag01-*-matchcap-guard` directories and all remain certified.

The complete dependency-pair test module reports 200 passed and 0 failed.
No CeTA source or generated checker changes were needed; this work implements
the processor already formalized in
`Termination_and_Complexity/Usable_Rules_Impl.thy`.

The contemporaneous full `cargo test --lib` run reports 495 passed, 2 failed,
and 5 ignored. The failures are outside this change: a context-sensitive CPF
parser round-trip rejects replacement-map symbols, and an engine test still
expects `Unknown` although its top-level termination branch now independently
proves the example. Both focused AG01 certificates and the complete DP module
remain green.

## 2026-07-31 `Endrullis_06/pair2simple2` path-order recovery

AProVE's retained certificate applies two dependency-pair reduction pairs:
KBO with argument filtering removes one pair, then lexicographic RPO with a
collapsing marked filter and an empty non-collapsing filter for `b` removes
the residual pair. Ferrum's path-order domain did not contain the empty filter
for positive-arity symbols. Its first expanded SMT model also placed symbols
with different statuses in one quasi-precedence class. Ferrum's local checker
accepted that model, but CeTA correctly rejected the resulting CPF.

The one-shot path-order encoding now includes empty non-collapsing filters,
canonicalizes equal filtered terms while disjoining their conditions, and
requires status agreement inside every quasi-precedence equivalence class.
The same status condition is checked independently after model extraction.
A compact constructor-only non-collapsing domain is attempted first, followed
by the unrestricted exact domain. Historic caps on generated filtered-term
alternatives and SMT script bytes were removed rather than turning a complete
solver query into bounded enumeration.

The exact AProVE residual witness and the formerly invalid equal-rank/mixed-
status model are unit regressions. All 196 dependency-pair tests pass. The
focused artifact is:

```text
target/termcomp-runs/20260731-pair2simple2-status-compatible-path-order
```

Ferrum reports YES and `.tools/ceta-relative-bounds` reports `CERTIFIED`. No
CeTA source or generated-checker change was required. A twelve-example default
replay is retained at
`target/termcomp-runs/20260731-next-small-path-order-fixed-final-12x60s`; its
successful DP branch is currently lost to the separately tracked outer
parallel-timeout race, so that run still records this example as MAYBE.

After adopting IsaFoR's exact ordinary `DP_on` construction, the proof was
replayed and certified again at
`target/termcomp-runs/20260731-pair2simple2-dp-on-certified`.

### Ordinary DP-construction correction

Ferrum now implements the exact `DP_on` construction formalized in IsaFoR:
a defined-root RHS candidate `u` is omitted when `u` is a proper subterm of
the source left-hand side `l`. The former implementation constructed a sound
but unnecessarily large superset.

The difference is visible on `AG01/#3.19`. Its focused ordinary DP state now
contains the same four-pair cyclic component as AProVE's certified proof,
instead of the former five-pair component. The trace is retained at:

```text
target/termcomp-runs/20260731-ag01-319-dp-on-graph-progress.jsonl
```

A July 30 regression had deliberately restored the larger construction after
a certification failure attributed to subterm pruning. Replaying the cited
`Waldmann_06/jwteparla1` guardrail with the exact `DP_on` construction gives a
certified YES, so that attribution was incorrect. The retained two-example
run is:

```text
target/termcomp-runs/20260731-dp-on-certification-guardrail-2x60s
```

`jwteparla1` is accepted by `.tools/ceta-relative-bounds`. The subsequent
`#3.19` RPO audit found that Ferrum's comparison relation accepted AProVE's
complete witness, but the outer validator rejected it when any filtered rule
increased syntactic term size. That condition is not part of RPO. Removing it
lets the one-shot encoding close the four-pair component; the focused CPF at
`target/termcomp-runs/20260731-ag01-319-rpo-size-heuristic-removed` is
`CERTIFIED`.

The default five-example replay at
`target/termcomp-runs/20260731-ag01-rpo-size-heuristic-fixed-5x60s` proves
`#3.19` in 1.05 seconds and gives 3 certified YES, 2 MAYBE, and no
certification failures. No dependency-graph estimator was changed. All 198
dependency-pair tests pass; graph-specific fixtures that intentionally test
unpruned pair sets request that set explicitly.

## 2026-07-31 relative DP-loop strengthening

A twelve-example probe selected small AProVE-certified Standard proofs that
Ferrum's 2026-07-25 full run had not decided:

```text
target/next-small-aprove-certified-12.list
target/termcomp-runs/20260731-next-small-aprove-certified-12x60s
```

The baseline produced 4 certified YES and 8 MAYBE. Seven of the misses have
AProVE DP-loop proofs consisting of one marked dependency-pair step followed
by ordinary relative TRS rewrites. Ferrum's DP loop processor previously
recognized only an immediate embedding after the marked step.

Ferrum now instantiates the variables of each candidate dependency pair with
its existing shallow ground-term basis, takes the marked step, and performs
the bounded breadth-first rewriting search over base rules. Every returned
witness is replayed by `check_loop_proof_for_trs`; CPF marks every unmarked
base-rule step as `<relative/>`.

The retained post-change run is:

```text
target/termcomp-runs/20260731-next-small-ground-dp-loop-final-12x60s
```

It gives 4 certified YES, 7 certified NO, and one MAYBE, with no timeout,
error, or certification failure. The new certified NO examples are
`round_nonterm`, `Ex1_GM99`, `Ex24_GM04`, `toyama`, `Ex9_Luc04_FR`,
`Ex24_Luc06_FR`, and `Ex24_Luc06_GM`.

The remaining `Endrullis_06/pair2simple2` proof needs a coupled KBO-then-RPO
choice: Ferrum can delete one pair with either order, but its first KBO model
does not select the pair used by AProVE's certified continuation. A trial
heterogeneous residual schedule did not solve the problem and was removed.

No CeTA changes were required. All seven new certificates are accepted by
`.tools/ceta-relative-bounds`.

## 2026-07-31 `jwteparla2` Q-IEDG certification repair

The 15-example AProVE-certified Waldmann baseline is retained at:

```text
target/termcomp-runs/20260731-next-waldmann-aprove-certified-default-15x60s
```

It produced 11 YES and 4 NO. All four NO and ten YES results certified, but
`Waldmann_06/jwteparla2.ari` was rejected below a dependency-graph processor
after semantic labeling and Q/LHS reduction. Ferrum had found only one edge
between the two remaining labeled pairs and split them into acyclic
singletons; CeTA retained the missing edge.

The local IsaFoR theorem `Dependency_Graph.IEDG` proves
`DG nfs m P Q R ⊆ IEDG P Q R`. Ferrum nevertheless admitted an IEDG edge only
when its separate reimplementation of CeTA's CAP and nonreachability filters
also accepted it. Those filters are precision refinements and must not veto
the independently sound IEDG over-approximation. Ferrum now conservatively
retains every IEDG edge. A regression contains the exact two labeled pairs and
eight labeled rules from the checker diagnostic:

```text
cargo +1.95.0-x86_64-unknown-linux-gnu test --lib \
  labeled_jwteparla2_q_graph_keeps_ceta_iedg_edge --jobs 32
```

The isolated corrected run is:

```text
target/termcomp-runs/20260731-jwteparla2-qiedg-fix-1x60s
```

It returns certified YES in 14 seconds. Its proof no longer needs semantic
labeling: it uses uncurrying, switch-innermost, narrowing, three graph
decompositions, two reduction pairs, and forward instantiation.

The final family replay is:

```text
target/termcomp-runs/20260731-next-waldmann-qiedg-fixed-final-15x60s
```

It gives 11 certified YES and 4 certified NO, with no MAYBE, timeout, error,
or certification failure. Full commands, progress logs, CPFs, checker output,
and result JSON are retained per example. No CeTA change was required; the
existing `.tools/ceta-relative-bounds` executable certifies every result.

## 2026-07-31 repeated usable-rule reduction

AProVE's retained certificates for
`TRS_Standard/Transformed_CSR_04/Ex4_7_15_Bor03_C.ari` and
`TRS_Standard/Transformed_CSR_04/ExProp7_Luc06_C.ari` first use a monotonic
usable-rule reduction-pair processor that removes no dependency pair but
shrinks the active rule set from 22 to 20 rules. After a reduction-pair
deletion, they recompute usable rules and shrink again. Ferrum already had the
zero-deletion SMT witness and CPF exporter, but its reduction-pair context
treated every initialized `active_rules` cache as a final usable set and did
not recompute the closure.

The context now keeps the current input `R` and its recomputed usable closure
separately. The zero-deletion processor is enabled only when the closure is a
strict subset of `R`; this both permits repeated use and prevents no-progress
recursion. Every residual starts with graph decomposition. A focused AProVE
order ladder established the processor result:

```text
target/termcomp-runs/20260731-transformed-csr-aprove-ladder-2x60s
```

It gives 2 YES and 2 certified YES in about 0.6 seconds per example. The first
default run showed that these inputs select the dedicated transformed-CSR
strategy, rather than the ordinary Standard route:

```text
target/termcomp-runs/20260731-transformed-csr-default-certified-2x60s
```

The exact zero-deletion monotonic transition was also forced through a
sequential order strategy:

```text
target/termcomp-runs/20260731-transformed-csr-mono-usable-sequential-2x15s
```

Both examples are certified YES. Each retained CPF contains five
`monoRedPairUrProc` nodes, directly testing the standard checker form rather
than relying only on a competing matrix branch.

After adding the compact graph/order ladder to that route, the final default
run is:

```text
target/termcomp-runs/20260731-transformed-csr-default-certified-final-2x60s
```

It gives 2 YES, 2 certified YES, no MAYBE, timeout, error, or certification
failure. Full per-example stdout, stderr, progress logs, CPF, CeTA output,
commands, and result JSON are retained under that directory. The regression
tests are:

```text
cargo +1.95.0-x86_64-unknown-linux-gnu test --lib reduction_pair_context --jobs 32
```

No CeTA changes were required. The sequential proofs use CeTA's existing
`monoRedPairUrProc`; the winning default proofs use its existing
`redPairUrProc`. Both forms certify with `.tools/ceta-relative-bounds`, so
there is no checker patch or branch to integrate.

## 2026-07-30 Beerendonk rational and narrowing certification recovery

The focused default Beerendonk run retains all per-example artifacts:

```text
target/termcomp-runs/20260730-beerendonk7-default-final-1x60s
```

It reports 1 YES, 1 certified YES, and no timeout or certification failure.
The proof uses `switchInnermost`, graph decomposition, rational usable-rule
deletion with quarter-grid coefficients and delta `1/16`, and size change.

The 13-example historical-gap replay is retained at:

```text
target/termcomp-runs/20260730-next-certified-gap-batch-3-13x60s
```

It reports 11 YES, 9 certified YES, and two timeouts. Its two narrowing
certificate failures were repaired by applying CeTA's `icap` position
condition to full-rewriting DP narrowing as well as innermost narrowing. The
focused post-fix run is:

```text
target/termcomp-runs/20260730-transformed-csr-narrowing-certified-2x60s
```

It reports 2 YES and 2 certified YES for
`Transformed_CSR_04/Ex6_9_Luc02c_iGM.ari` and
`Transformed_CSR_04/ExProp7_Luc06_iGM.ari`. Certification used `.tools/ceta`;
no CeTA source or executable changes were required.

## 2026-07-30 `Der95/30` and `AProVE_07/thiemann40` certified recoveries

A fresh ten-example probe of historical certified gaps is retained at
`target/termcomp-runs/20260730-next-certified-gap-batch-10x60s`. Eight were
already default-certified. The two live gaps were `Der95/30` and
`AProVE_07/thiemann40`.

`Der95/30` has a one-rule recursive-path-order proof. Ferrum's existing
top-level path-order processor finds and certifies it in about one second when
run directly, but the default strategy previously launched it only after
solver-heavy DP transformations. The default strategy now runs a small initial
race between graph/subterm/size-change and top-level path order before starting
the transformation portfolio.

For `thiemann40`, AProVE's certified proof uses a rational DP interpretation
with delta `1/4`. Zero coefficients make only the `nonZero` and `p` rules
usable; the two `id_inc` rules are not required for the first reduction-pair
step. Ferrum formerly fixed the six-rule usable set before synthesis, making
this witness impossible. Its rational processor now encodes coefficient-driven
usable-symbol reachability and rational orientation in one SMT query. Ferrum
then reconstructs the argument filter and usable-rule closure, checks every
orientation with exact rational arithmetic, and emits a rational
natural-polynomial `redPairUrProc` proof with delta `1/4`.

The final default-strategy run is retained at:

```text
target/termcomp-runs/20260730-der30-thiemann40-default-final-2x60s
```

It reports 2 YES, 2 certified YES, zero MAYBE, timeout, error, or certification
failure, in five seconds wall-clock with two workers. The three rational
polynomial unit tests also pass.

No CeTA change was required. Both certificates are accepted by the existing
`.tools/ceta-relative-bounds` executable, so there is no checker patch or
branch to integrate.

## 2026-07-30 FULL/decomposing match-bounds recovery

Ferrum's ordinary SRS match-bounds search now implements the online FULL
construction from Endrullis et al. (2006), following the executable structure
in the GPLv3 Pure Matchbox source at
`../pure-matchbox/src/Matchbox/Decomp.hs`. For each endpoint pair it computes a
maximum-bottleneck LHS path, selects its first minimum-height transition, and
inserts the reduct at the next height between inverse encodings of the left and
right context. The two cancellation rules

```text
LeftInverse(c,h) Original(c,k) -> epsilon  when h <= k
Original(c,h) RightInverse(c,k) -> epsilon when h >= k
```

are saturated together with epsilon reachability. Inverse transitions are
search artifacts only. The emitted CPF contains original-symbol transitions
and epsilon transitions, and CeTA independently checks the ordinary
`<bounds><match/>` proof over the input TRS.

The construction is also used for the termination-equivalent cons encoding of
string systems. Ferrum lifts the completed word automaton back to the original
ranked signature before CPF export. No whole-TRS argument filtering or
uncertified transformation is involved.

The focused default-strategy recovery is retained at:

```text
target/termcomp-runs/20260730-z30-decomp-default-certified-r2-1x60s
```

It reports 1 YES and 1 certified YES in 21 seconds. The proof has match bound
3; the search completion records 743 word states, 797 labeled transitions, and
1,055 inferred epsilon edges before export and cons lifting.

The related three-example run is retained at:

```text
target/termcomp-runs/20260730-z01-z03-decomp-batch-3x60s
```

It reports 3 YES and 3 certified YES with no failure. `z01` is newly recovered
by FULL match-bounds at bound 4, and `z03` at bound 2. `z02` succeeds through
an existing dependency-pair proof and is not credited to this processor.
Together with `z30`, this is three certified recoveries from the new
construction.

The default SRS strategy gives ordinary original and reversed FULL
match-bounds 30 seconds each and delays the generic termination fallback by 35
seconds. RFC and relative-bounds budgets are unchanged. This avoids starting a
long generic sibling before the dedicated bounds portfolio has had enough time
to finish the retained bound-3 witness.

Verification:

```text
cargo +1.95.0-x86_64-unknown-linux-gnu test --lib match_bounds --jobs 32
cargo +1.95.0-x86_64-unknown-linux-gnu build --release --jobs 64
```

All 26 match-bounds tests pass, including the inverse-context cancellation
regression and the existing CeTA integration tests. Direct checking of the
focused `z30` CPF with `.tools/ceta-relative-bounds` prints `CERTIFIED`.

The final mixed regression is retained at:

```text
target/termcomp-runs/20260730-decomp-semlab-regression-6x60s
```

It reports 6 YES and 6 certified YES with no MAYBE, timeout, error, or
certification failure. It covers the three FULL match-bounds recoveries and
the recent semantic-labeling cases `z21`, `z27`, and `z28`. In this loaded
six-worker run `z30` completes and certifies in 5.244 seconds.

No CeTA source or generated-checker change was needed. Certification uses the
existing `.tools/ceta-relative-bounds` executable, so there is no checker
branch or patch to integrate.

## 2026-07-30 `Zantema_05/z05` certified recovery

AProVE's retained certificate first uncurries the applicative system, performs
two polynomial rule-removal steps, and constructs six dependency pairs. A
polynomial reduction pair deletes three pairs. Each remaining original pair is
narrowed once, after which a three-dimensional natural-Arctic interpretation
with `strictDimension = 1` removes one pair and graph decomposition proves the
two-pair residual acyclic.

Ferrum had three independent gaps:

1. Natural-Arctic validation and SAT synthesis incorrectly required strict
   decrease in every matrix row even when CPF requested strict dimension one.
   They now require strictness in row zero and weakness in the other rows.
2. DP narrowing had a global two-transform cutoff in addition to its proper
   per-origin counters. The global cutoff is removed. For the recognized unary
   three-cycle, candidates are selected canonically from the least-transformed
   origin, with one narrowing per origin; this avoids an inadmissible second
   descendant narrowing that CeTA correctly rejected.
3. A checked, name-independent 3D natural-Arctic candidate now covers this
   unary marked cycle. It is only a search seed: the normal concrete validator
   checks all pair and usable-rule obligations before proof construction.

The focused uncurrying-only check at
`target/termcomp-runs/20260730-z05-per-origin-one-uncurry-only-65s` gives one
YES and one certified YES in about two seconds. The final default sibling run
at `target/termcomp-runs/20260730-zantema-siblings-final-2x60s` gives 2 YES and
2 certified YES (`z05` and `z07`) in two seconds total, with no MAYBE, timeout,
error, or certification failure. The six focused Arctic unit tests pass.

The default strategy gives detected applicative systems' uncurrying branch a
five-second head start before starting the ordinary DP-order and
switch-innermost branches. A control using the unchanged simultaneous race at
`target/termcomp-runs/20260730-z05-engine-only-guardrail-2x60s` leaves both
`z05` and the already-currently-missing `JFP_Ex31` unknown. The delayed race
recovers `z05`; `z07` and `jwaprove2` remain certified, while `JFP_Ex31` and
`factorial1` remain current regressions independently of this scheduling
change and require separate investigation.

No CeTA source or generated-checker change was needed. The existing
`.tools/ceta-relative-bounds` executable accepts the proof, so there is no
checker branch or patch to integrate.

## 2026-07-30 `Zantema_05/z22` certified recovery

A fresh default sweep of `Zantema_05/z01` through `z30` is retained at
`target/termcomp-runs/20260730-zantema-z01-z30-current-16w60s`. Before this
change it produced 15 YES, all 15 certified, 12 MAYBE, and 3 timeouts.

The retained AProVE certified proof for `z22` uses dependency pairs, KBO with
a collapsing argument filter, and semantic labeling over carrier two with

```text
a = 1
b = 0
c = 0
f(x,y) = 0
f#(x,y) = 0
```

followed by graph decomposition and repeated polynomial reduction-pair
deletions. Ferrum's former structural binary candidate required exactly two
constants, so this model was reached only after an unproductive generic
enumeration. Ferrum now generates a finite family for signatures containing
constants and exactly one marked/unmarked binary pair: one constant is
distinguished with value one, the others and the marked symbol receive zero,
and the base binary symbol is tried as zero or an argument projection. These
are search candidates only. The complete finite-model equations are checked
before any labeled problem is accepted.

The linear polynomial processor now maximizes the number of strict pairs in
the same one-shot BV query that synthesizes coefficients and the usable-rule
fixed point. The Z3 model parser was also corrected to stop at each
`define-fun` boundary; previously a Boolean usable-rule definition could
consume the bit-vector value of a following coefficient. Exact concrete
orientation and usable-rule validation remain unchanged.

The final loaded regression at
`target/termcomp-runs/20260730-z22-semlab-regression-4w60s` gives 4 YES and
4 certified YES for `z01`, `z05`, `z19`, and `z22`, with no MAYBE, timeout,
error, or certification failure. `z22` takes 49.277 seconds under four-worker
load. Combining this result with the unresolved replay at
`target/termcomp-runs/20260730-zantema-unresolved-binary-semlab-maxpoly-14w60s`
raises the current `z01`--`z30` family score from 15/30 to 16/30.

An earlier focused `z21` proof at
`target/termcomp-runs/20260730-z21-semlab-focused.cpf.xml` is explicitly not
counted: it used a later Arctic deletion rejected by CeTA. The certified
recovery below supersedes that exploratory result.

No CeTA source or generated-checker change was needed. Certification uses the
existing `.tools/ceta-relative-bounds` executable.

## 2026-07-30 `Zantema_05/z21` and `z27` certified recoveries

For `z21`, AProVE uses two polynomial DP deletions, carrier-two semantic
labeling, graph decomposition, and further usable-rule polynomial deletions.
Ferrum could construct a certified proof in a focused run, but default runs
oscillated between 28-second success and exhausting the 55-second internal
deadline. The cause was search order: an equally valid coarse model
`a=b=1, f=f#=0` led to a long transformed residual before the direct
projection model was considered.

The one-shot polynomial query now uses explicit lexicographic objectives:
maximize strict DP deletion, minimize activated usable symbols, and then
minimize the sum of constants and coefficients. All arithmetic widths include
the complete objective range, and exact validation is unchanged. Structural
binary semantic-labeling candidates are ordered using the residual DP
signature, with constants absent from the residual tried first. Projection
models are tried before the coarser two-constant model. The successful default
run is retained at
`target/termcomp-runs/20260730-z21-ranked-semlab-r1-1x60s`; it reports
certified YES in 0.372 seconds.

For `z27`, Ferrum already matched AProVE's first step by deleting one of four
DPs with KBO/AF or a polynomial reduction pair. AProVE's residual model has
two constants, one unary identity symbol, and a marked/unmarked ternary pair:

```text
0 = 0
1 = 1
g(x) = x
f(x,y,z) = 0
f#(x,y,z) = 0
```

Ferrum now proposes this structural carrier-two class for any matching
signature, without relying on these symbol names. Both choices of
distinguished constant are generated. Every proposal must satisfy the full
finite-model equations and close the recursively labeled DP problem before it
can produce CPF. The focused default artifact is
`target/termcomp-runs/20260730-z27-structural-semlab-r1-1x60s`; it reports
certified YES in 1.116 seconds.

The final six-worker loaded regression is:

```text
target/termcomp-runs/20260730-z21-z27-semlab-regression-6x60s
```

It gives 6 YES and 6 certified YES for `z01`, `z05`, `z19`, `z21`, `z22`,
and `z27`, with no MAYBE, timeout, error, or certification failure. The
broader pre-existing eight-example semantic-labeling corpus was replayed at
`target/termcomp-runs/20260730-z21-z27-semlab-broad-regression-8x60s`; all
eight examples, including `pair3hard` and the retained Waldmann cases, remain
certified YES. The semantic-labeling suite (12 tests), the new `z27` model
regression, the
lexicographic BV objective test, and the usable-rule/model-parser regressions
pass. Relative to the retained 15/30 `z01`--`z30` baseline, the `z22`, `z21`,
and `z27` recoveries raise the family score to 18/30.

No CeTA source or generated-checker change was needed. All new CPF proofs are
accepted by the existing `.tools/ceta-relative-bounds` executable, so there
is no checker branch or patch to integrate.

## 2026-07-30 `AProVE_04/JFP_Ex31` certified recovery

AProVE's TermCOMP 2025 CPF first decomposes the ordinary dependency pairs. Its
hard `top#` component uses a no-deletion monotonic usable-rule polynomial,
narrows both pairs, decomposes again, and applies carrier-two semantic labeling.
The labeled problem has 39 rules and 18 pairs, with a 14-pair cyclic component.
AProVE then repeatedly alternates interpretation-dependent usable-rule
polynomial deletion and graph decomposition.

Ferrum was missing the coupled ordinary polynomial search. Its former
`LinearPolynomial` query oriented the complete precomputed usable set before
deriving the argument filter. It now uses one QF_BV query for coefficients,
pair orientation, coefficient activity, and Boolean usable-symbol reachability.
After decoding, Ferrum recomputes the exact filtered usable-rule closure and
rechecks every orientation with unbounded arithmetic before emitting
`redPairUrProc`.

The investigation also found a generic subprocess deadlock:
`run_command_with_input_deadline` waited for solver exit before reading piped
stdout and stderr. SAT models larger than the pipe capacity therefore appeared
to time out although Boolector and Z3 solved the extracted 14-pair query in
under 0.1 seconds. Ferrum now drains both streams concurrently while polling
the managed child, and still kills and drains it on deadline or cooperative
cancellation. A one-megabyte stdout/stderr regression covers this behavior.

The retained default-strategy command is:

```console
FERRUM_PROGRESS_LOG=target/termcomp-runs/20260730-jfp-ex31-default-final/progress.jsonl \
FERRUM_PROCESSOR_EVENT_LOG=target/termcomp-runs/20260730-jfp-ex31-default-final/processor-events.jsonl \
timeout 65s target/release/ferrum prove \
  /work/dfm/festschrift/TPDB-ARI/TRS_Standard/AProVE_04/JFP_Ex31.ari \
  --cpf target/termcomp-runs/20260730-jfp-ex31-default-final/proof.cpf.xml \
  --cpf-mode auto --strategy 'timeout(55s, default)' --no-top-level-llm

.tools/ceta-relative-bounds \
  target/termcomp-runs/20260730-jfp-ex31-default-final/proof.cpf.xml
```

Ferrum returns `Terminating`; CeTA returns `CERTIFIED` in 34 ms. The selected
proof reproduces the carrier-two expansion to 39 rules and 18 pairs and closes
the labeled components by graph decomposition plus filtered polynomial
deletions.

The loaded regression exposed a separate CPF narrowing issue. CeTA interprets
the narrowing position as a lower bound `p` and permits rewrite positions
`q >= p`; exact-position-only generation could omit required descendant
narrowings. Ferrum now unions the exact narrowings throughout the selected
region. All 19 narrowing-focused tests pass, including CeTA smoke tests and a
new descendant-region regression. `Zantema_05/z01` and
`Waldmann_06/jwaprove2` both return certified YES in the focused two-worker run:

```text
target/termcomp-runs/20260730-jfp-ex31-focused-regressions-2x60s
```

The final two-worker 12-example regression is retained at
`target/termcomp-runs/20260730-jfp-ex31-regression-final-v3-12x60s`. It gives
10 certified YES and 2 certified NO in 53 seconds, with no MAYBE, timeout,
error, or certification failure. A four-worker run at
`target/termcomp-runs/20260730-jfp-ex31-regression-final-v2-12x60s` has the
same certification behavior for every completed proof but leaves `jwtpa1`
UNKNOWN at its inner deadline; the isolated `jwtpa1` rerun certifies in 10
seconds. The initial 12-worker run is also retained: it demonstrates an
allocator failure under nested parallel load and the narrowing certificate
failure that motivated the regional fix.

No CeTA source or generated-checker change was needed. All successful proofs
are accepted by the existing `.tools/ceta-relative-bounds` executable, so
there is no checker branch or patch to integrate.

## 2026-07-30 `AProVE_04/IJCAR_26{,a}` certified recovery

AProVE's certified proofs create 20 dependency pairs and decompose them. The
hard four-pair `div#`/`quot#` component is reduced by three KBO
`redPairUrProc` steps. Their argument filters collapse the marked `div#` and
`quot#` symbols and induce empty usable-rule sets; size change closes the final
pair. `IJCAR_26a` differs only by the additional rule `p(0) -> 0`.

Ferrum's unrestricted one-shot KBO search previously oriented the complete
precomputed usable-rule set before choosing an argument filter. It now encodes
precedence, weights, filter alternatives, pair orientation, and Boolean
AF-dependent usable-symbol reachability in one QF_LIA query. The concrete
closure is then recomputed and all KBO obligations are checked independently.

CeTA's executable definition was used to correct an important detail during
regression. At an application, usable-rule closure checks the original root
before descending only through positions selected by the argument filter; a
collapsing filter does not erase that root for usable-rule purposes. Ferrum's
search and validator now implement this active-position traversal. The first
over-aggressive implementation and its three CeTA rejections are retained at
`target/termcomp-runs/20260730-ijcar26-regression-final-14x60s`; none of those
certificates is treated as certified evidence.

The corrected focused guardrail is:

```text
target/termcomp-runs/20260730-ijcar26-kbo-cert-guardrail-5x60s
```

It gives 5 certified YES, including both IJCAR examples and the three examples
that exposed the closure mismatch. The final expanded regression is:

```text
target/termcomp-runs/20260730-ijcar26-regression-final-v2-14x60s
```

It gives 12 certified YES and 2 certified NO in 38 seconds, with no MAYBE,
timeout, error, or certification failure. `IJCAR_26` certifies in 3.391
seconds and `IJCAR_26a` in 4.767 seconds. The 15 focused KBO tests and the
collapsing-root usable-rule regression pass.

One cancelled losing subprocess in the aggregate `z19` job printed a glibc
allocator assertion even though another branch produced the accepted certified
YES. The isolated replay at
`target/termcomp-runs/20260730-ijcar26-z19-clean-1x60s` has empty Ferrum
stderr and returns certified YES in four seconds. Thus this is retained as
nested-load/cancellation evidence, not counted as a proof or certification
failure.

No CeTA source or generated-checker change was needed. Certification uses the
existing `.tools/ceta-relative-bounds` executable, so there is no checker
branch or patch to integrate.

## 2026-07-30 `AProVE_06/factorial1` certified recovery

AProVE switches this nine-rule Standard TRS to innermost rewriting, creates ten
dependency pairs, and decomposes them into singleton SCCs. Its cyclic
`fac#`, `times#`, and `plus#` components use natural polynomial
`redPairUrProc` proofs with negative constants; the polynomial's zero
coefficients induce a smaller usable-rule closure containing only the two
`p` rules. The `p#` component is a size-change/subterm descent.

Ferrum already found the same graph decomposition, but `weak-poly(min=-2,...)`
silently clamped the minimum constant to zero and required all six initially
usable rules. The processor now implements CPF/CeTA's natural max-polynomial
semantics directly:

- each affine symbol interpretation denotes `max(0,p)` at every application;
- a single SMT formula universally quantifies all natural term variables;
- coefficient positivity controls active argument positions;
- Boolean reachability computes an interpretation-dependent usable-rule
  closure in the same formula;
- the decoded model is not trusted: Ferrum recomputes the exact filtered
  closure and asks for an existential natural counterexample to each weak and
  strict orientation obligation;
- only counterexample-free models become CPF polynomial
  `redPairUrProc` steps.

The default weak-polynomial class now uses constants in `[-2,2]` and
coefficients in `[0,2]`. The direct innermost proof is retained at
`target/termcomp-runs/20260730-factorial1-negative-max-polynomial/direct-innermost-v5.cpf.xml`.
The ordinary TRS Standard default proof is retained at
`target/termcomp-runs/20260730-factorial1-negative-max-polynomial/default-standard-final.cpf.xml`;
it returns YES in 3.5 seconds and CeTA returns `CERTIFIED`.

The loaded regression at
`target/termcomp-runs/20260730-factorial1-regression-11x60s` reports 9
certified YES and 2 certified NO, with no MAYBE, timeout, error, or
certification failure. Direct replay of all 11 stored CPF files returns
`CERTIFIED`. The focused weak-polynomial unit suite has seven passing tests,
including valid negative constants, a non-strict max-boundary rejection, and
an interpretation whose strict subset is determined by exact max semantics.

No CeTA source or generated-checker change was needed. Both new certificates
are accepted by the existing `.tools/ceta-relative-bounds` executable, so
there is no checker source, branch, or executable patch to integrate.

## 2026-07-30 `Zantema_15/ex01` certified NO recovery

AProVE certifies this unary TRS as nonterminating with CPF's
`nonterminatingSRS` processor. Its derivation patterns establish the family

```text
b R a^n b ->+ b R a^(n+1) b
```

from the four rules `a L -> L a`, `R a -> a R`, `b L -> b R`, and
`R b -> L a b`. The pattern is fitting and self-embedding, hence it represents
an infinite SRS derivation. The unary TRS/SRS correspondence then gives
nontermination of the original Standard TRS.

Ferrum now has typed proof objects and CPF output for the exact checked
derivation-step subset used here: `OC1`, `OCintoDP1`, `OCintoDP2`,
`DP_OC_3_2`, `DP_DP_2_1`, word-pattern equivalence, and `DP_OC_1_2`, followed
by `selfEmbeddingDP`. The synthesizer recognizes the rule schema by structural
symbol relationships; the names `a`, `L`, `R`, and `b` are not hard-coded.
The processor is Full-rewriting only, matching CeTA's empty-Q requirement.

The former default run is retained at
`target/termcomp-runs/20260730-zantema15-ex01-current-60s`; it reports MAYBE
after 55 seconds. The recovered default run is:

```text
target/termcomp-runs/20260730-zantema15-ex01-certified-60s
```

It reports one NO and one certified NO in under 0.1 seconds. The loaded
nine-example regression at
`target/termcomp-runs/20260730-zantema15-ex01-regression-9x60s` reports
8 certified YES, 1 certified NO, and no MAYBE, timeout, error, or certification
failure. Direct replay of all nine stored CPF files returns `CERTIFIED`.

The processor-only probe over all ten AProVE `nonterminatingSRS` Standard
proofs is retained at
`target/termcomp-runs/20260730-srs-derivation-patterns-aprove10-10x10s`.
It recovers `ex01` and declines the other nine immediately. This bounds the
current claim: Ferrum implements the certified commuting-pump slice, while
general overlap-closure derivation-pattern search remains future work.

No CeTA source or generated-checker change was needed. The unmodified existing
`.tools/ceta-relative-bounds` executable accepts Ferrum's CPF, so there is no
checker branch or patch to integrate.

## 2026-07-30 `Zantema_15/ex04` certified NO recovery

`ex04` uses the same derivation-pattern argument as `ex01`, but its pumping
contexts are words rather than single symbols. The four relevant SRS rules have
the general form

```text
a L -> L a
R a -> a R
P L -> P R
R Q -> L a Q
```

and imply `P R a^n Q ->+ P R a^(n+1) Q`. For `ex04`,
`P = a L` and `Q = R a`; the resulting self-embedding pattern is
`a L R a^n R a ->+ a L R a^(n+1) R a`.

Ferrum's commuting-pump synthesis now extracts arbitrary shared prefix `P` and
suffix `Q` from the switching and expansion rules. It constructs the same
chronological CPF operations as before, including the explicit word contexts
required by `DP_OC_3_2`, `DP_DP_2_1`, and `DP_OC_1_2`. The old single-letter
case is the specialization `P = Q = b`.

The previous ten-example default run at
`target/termcomp-runs/20260730-aprove-nonterminating-srs-10-default-10s`
gave 9 certified NO and left only `ex04` unknown. The strengthened run at
`target/termcomp-runs/20260730-aprove-nonterminating-srs-10-default-word-contexts-10s`
gives 10 certified NO, with no MAYBE, timeout, error, or checker failure. A
processor-only run at
`target/termcomp-runs/20260730-srs-derivation-patterns-word-contexts-aprove10-10x10s`
gives 2 certified NO (`ex01` and `ex04`) and immediately declines the other
eight.

The mixed loaded regression is retained at
`target/termcomp-runs/20260730-zantema15-ex04-regression-10x60s`. It reports
8 certified YES and 2 certified NO. Direct replay of every stored CPF returns
`CERTIFIED`, and both single-symbol and word-context synthesis unit tests pass.

No CeTA source or generated-checker change was needed. Certification uses the
existing `.tools/ceta-relative-bounds` executable, with no checker branch or
patch to integrate.

## 2026-07-30 `Zantema_05/z19` certified recovery

AProVE's retained certificate starts with dependency pairs and a monotonic
linear polynomial reduction pair, labels the residual over carrier two, and
repeatedly alternates dependency-graph decomposition with linear polynomial
deletion. Its semantic model is `a = 1`, `b = 0`, `f = 0`, and `f# = 0`.

Ferrum needed two search changes. After a sound reduction-pair deletion in a
Full-rewriting DP problem, the residual now retries the caller's graph-first
order strategy before narrowing or forward instantiation. This preserves the
existing innermost transform-first schedule. Semantic labeling also tries the
AProVE-shaped carrier-two model when, and only when, the constrained signature
contains exactly two constants and a marked/unmarked binary pair. Constants
occurring on a rule or DP left-hand side receive one and all other symbols
receive zero. This is only a candidate: the finite-model equations, recursive
DP proof, CPF export, and CeTA checking remain unchanged.

A control with the residual reordering but without this model candidate remains
MAYBE after 55 seconds:

```text
target/termcomp-runs/20260730-z19-order-first-no-model-hint-60s
```

The final eight-example loaded regression is:

```text
target/termcomp-runs/20260730-z19-regression-final-v3-8x60s
```

It reports 8 YES, 8 certified YES, zero MAYBE, timeout, error, or certification
failure. It includes `z19`, `z01`, `pair3hard`, and the five retained Waldmann
examples. Direct checker-only replay of all eight stored CPF files returns
`CERTIFIED`. The focused two-example structural guardrail is retained in
`target/termcomp-runs/20260730-z19-pair3hard-structural-model-2x60s`; both
examples are certified. The two semantic-labeling candidate unit tests pass.

No CeTA source or generated-checker change was needed. Certification uses the
existing `.tools/ceta-relative-bounds` executable, with no checker branch or
patch to integrate.
### Self-contained CSR DP oracle evidence and v156 replay

Parameterized CSR DP successes were formerly logged with Rust's `Debug`
representation.  The training normalizer could only recover a bare `dp` atom
from some such rows, so strict guidance restarted the default DP search rather
than executing the continuation that had actually certified.  A second generic
normalization path also changed whitespace inside an already executable
`dp(...)` atom into hyphens.

Ferrum now serializes every `DpStrategy` constructor and processor into the
public parser language, and CSR processor events retain it as
`dp(<complete continuation>)`.  The dataset pipeline preserves executable
structured atoms modulo insignificant whitespace.  Parser round-trip and
normalization regressions cover the full Ex14-style sequence with graph,
subterm, timeouts, parallel matrix/order branches, rewriting, instantiation,
forward instantiation, and size change.

The same executable serialization is used by ordinary top-level DP events.
Parameterized nontermination events likewise retain their full sequence,
choice, repeat, timeout, and processor atom as
`nontermination(<complete continuation>)`.  Round-trip coverage enumerates
every current DP and nontermination processor family, so new live evidence no
longer depends on reversing Rust debug output.

The release smoke artifacts are under
`target/manual-evidence-replay-v147-20260731/executable-event-smoke-v158`.
The top-level logs contain the exact atoms `dp(graph; path-order; size-change)`
and `nontermination(dp-loop)` respectively; both generated CPFs were accepted
twice by production CeTA-CSR.

Fresh release evidence is under
`target/manual-evidence-replay-v147-20260731/exact-self-contained-v156`.
`Ex14_Luc06` and `MYNAT_complete-noand` both produced complete CPFs accepted
twice by `/work/dfm/festschrift/CeTA-CSR/ceta`.  Oracle v156 is
`target/manual-evidence-replay-v147-20260731/oracle-v156-self-contained-csr.jsonl`
(SHA-256 `30e4db2419e37cb21b440ce01b3aed54a2cf85e22342ba20eadfc8c00d1cbf11`).
The two-root strict replay is 2/2 certified, and the full TermCOMP 2025 CSR
replay is 88/108 certified with 20 MAYBE, zero timeout, and zero certification
failure.  A current-default follow-up over those 20 gaps found no additional
root closure (19 MAYBE and one timeout), so they remain search gaps rather than
evidence-integration losses.

The subsequent v157 manual-registry replay covers 179 unique roots and
certifies 153 with no checker failures: 62/72 Standard, 62/78 Innermost, and
29/29 context-sensitive.  The manifest initially reported 180 rows because
`factorial1` appeared twice in the evolving documentation table.  The builder
now performs stable root deduplication and merges unique evidence locations;
its focused four-test suite passes.  Artifacts are under
`target/manual-evidence-replay-v147-20260731/strict-v157-full-manual180` (the
directory name records the pre-dedup launch count).

The next exact overlay repairs the nontermination replay boundary for
`Mixed_innermost/muladd` and `Mixed_innermost/n001`.  A parameterless
top-level nontermination request is now logged as its complete effective
portfolio, including every timeout and DP-loop continuation, rather than as
the non-executable placeholder `nontermination(loop)`.  The live states were
replayed by `freeze_live_manual_processor_evidence.py`; both reconstructed
complete CPFs passed production CeTA-CSR twice before promotion.  Oracle v158
is `target/manual-evidence-replay-v147-20260731/oracle-v158-window3-muladd-n001-exact.jsonl`
(SHA-256 `08f2c894ba645a4965cb5e148c37a25d74decea6ab0c47ab76851fa8ab99f0d1`).
With fallback set to `fail`, both roots replay as certified NO; each replay
CPF was then checked twice again.  Artifacts are under
`target/manual-evidence-replay-v147-20260731/strict-v159b-window3-muladd-n001`.

Oracle v159 adds exact current-code evidence for `Various_04/14`,
`CiME_04/log2`, and `AProVE_04/Liveness6.4`.  Freezing the live proof paths
retained 44 independently certified complete states and 28 typed
assembly-required transitions, with zero rejected trials.  The monotone
oracle is `target/manual-evidence-replay-v147-20260731/oracle-v159-standard-trio-exact.jsonl`
(SHA-256 `8ed1a24bc4138377b644053344fbbe9b4d0c698f970d00f39b984ac344ff73ba`).
Strict replay with fallback `fail` certifies all three roots in 1.683--1.965
seconds; every replay CPF passed production CeTA-CSR twice.  This reduces the
49.577-second producing search for `Liveness6.4` to a deterministic 1.683-second
guided replay.  Artifacts are under
`target/manual-evidence-replay-v147-20260731/strict-v159-standard-trio`.
## 2026-07-31 six additional certified Standard frontier recoveries

The retained comparison list still classified several examples as MAYBE or
timeout although the current default strategy closes them.  A focused default
run is retained at:

```text
target/manual-probes/20260731-z26-default-after-direct
```

`Zantema_05/z26.ari` is YES in about 0.3 seconds and its complete CPF is
accepted by `.tools/ceta-relative-bounds`.  The successful proof uses a
natural polynomial deletion, a 2D 0/1 matrix deletion, dependency-graph
decomposition, and size change.  AProVE declares its corresponding matrix
over the integers, but all entries are nonnegative and CeTA dispatches both
ordinary natural and integer matrix declarations to the same verified integer
matrix implementation.  No separate signed-matrix processor is needed for
this example.

A six-example parallel default sweep is retained at:

```text
target/manual-probes/20260731-next-six-default-60s
```

The following five examples are YES and independently CeTA-certified:

```text
TRS_Standard/AG01/#3.40.ari
TRS_Standard/AProVE_04/IJCAR_26.ari
TRS_Standard/AProVE_07/wiehe12.ari
TRS_Standard/CiME_04/filliatre3.ari
TRS_Standard/CiME_04/tree.ari
```

`AProVE_07/kabasci03.ari` exhausted the 60-second external allowance and
remains the next search gap.  Every directory retains processor events,
stdout, stderr, CPF where produced, and CeTA stdout/stderr.  No CeTA source or
generated-checker change was needed; there is no checker patch to integrate.

## 2026-07-31 exact v160 Standard integration

The four newly unique terminating roots (`z26`, `wiehe12`, `filliatre3`, and
`tree`) and ten new nonterminating roots were replayed from the current source
under `target/manual-evidence-replay-v147-20260731/producing-v160-new-standard`.
The default run produced 4 certified YES and 10 certified NO in seven seconds,
with no MAYBE, timeout, or checker failure.  Recursive freezing retained 72
independently certified complete states and 36 typed assembly-required
transitions, with zero checker rejection.  One `z26` local DP portfolio was
slowed by the concurrent campaign and exceeded 60 seconds in the first freeze;
an isolated 160-second retry closed it in 51.115 seconds and its CPF passed
production CeTA-CSR twice.  The clean overlay is
`target/manual-evidence-replay-v147-20260731/producing-v160-new-standard/z26-frozen-160s.jsonl`.

The resulting monotone oracle is
`target/manual-evidence-replay-v147-20260731/oracle-v160-new-standard-exact.jsonl`
(SHA-256 `4c6c40026e448e5517728435764da23957b84a5da45985a8a7e187d17a92aa8d`).
With the fallback strategy replaced by `fail`, all 14 roots replayed and
certified in eight seconds total: 4 YES and 10 NO.  All 14 reconstructed replay
CPFs were then checked twice again with `/work/dfm/festschrift/CeTA-CSR/ceta`.
Strict artifacts are under
`target/manual-evidence-replay-v147-20260731/strict-v160-new-standard`.

## 2026-07-31 transformed-CSR adaptive round 3 and CSR refresh

The third transformed-CSR round completed all 18,867 scheduled trials under
`target/data-campaign/state-first-adaptive-20260731-transformed-csr-v115/rounds/r03-probes`.
It recorded 1,789 solved probes, 6,032 transformations, 389 certified assembled
proofs, and three checker-rejected assemblies.  Replaying the exact rejected
states with current Ferrum made all three inapplicable, confirming that they
came from the stale negative weak-polynomial implementation.  The state-first
exporter now removes checker-rejected assemblies even from weak guidance unless
a certified reconstruction supersedes them.

The frozen r01--r03 union rechecked 4,426/4,426 retained proofs with production
CeTA-CSR, with zero rejection or timeout.  Oracle v161 is
`target/data-campaign/state-first-adaptive-20260731-transformed-csr-v115/rounds/oracle-global-v161-r03.jsonl`
(SHA-256 `8361fe5997435e466a3da53e543490b0006e3e34e21a442a8934af3af20feb9b`).
Strict rerun of the 197 prior unresolved roots certified three new roots with
fallback disabled: `Ex4_7_56_Bor03_GM` (YES), `ExIntrod_GM01_Z` (NO), and
`PALINDROME_complete_noand_GM` (YES).  Oracle-plus-fallback certified nine
additional roots (one YES and eight NO).  Artifacts are under the corresponding
`r03-rerun-oracle-{only,plus-fallback}-v161-60s` directories.

CeTA-CSR commit `e66a6da` adds proved usable-rule reduction pairs for minimal
CSR dependency-pair problems.  It was built through an isolated Isabelle
`Code` session, freshly exported to Haskell, compiled independently, and tested
against one positive U3 proof plus missing-closure and non-strict-pair
mutations.  Production `ceta` passes the same tests.  A fresh full native CSR
strict replay remains 88/108 certified, with 20 MAYBE and no checker failure;
current fallback also closes none of those 20.  Thus the remaining gap is
residual search/processor power, not checker acceptance or missing manual
evidence.  Artifacts are under
`target/manual-evidence-replay-v147-20260731/strict-v161-csr108-ceta-e66a6da`.

## 2026-07-31 `thiemann09` weak-polynomial default recovery

The certified AProVE proof for `TRS_Standard/AProVE_07/thiemann09.ari`
starts one SCC with a usable-rules natural polynomial interpretation containing
negative constants, notably `quot#(x,y,z) = max(0,x-1)` and
`p(x) = max(0,x-2)`.  Ferrum already had the CeTA-aligned exact validation for
this class, but `strategies/default.fs` did not schedule `weak-poly`.

A focused run showed that the first quantified synthesis query needs about
12.2 seconds.  Placing duplicate three-second queries in generic parallel
order portfolios did not help and increased contention.  The default strategy
now has one dedicated early 20-second DP chain, with 15 seconds for its first
negative-constant weak-polynomial query, followed by graph decomposition,
subterm, size change, further weak-polynomial deletion, monotonic polynomial,
and KBO.  The automatic default proof takes about 12.5 seconds and is retained
at:

```text
target/manual-probes/20260731-thiemann09-default-early-weak-60s
```

Its CPF is accepted by `.tools/ceta-relative-bounds`.  A six-example default
regression is retained at:

```text
target/manual-probes/20260731-six-certified-weak-poly-regression-60s
```

All six examples are YES and CeTA-certified: `thiemann09`, `IJCAR_26a`,
`id_inc`, `list-sum-prod-bin-assoc-distr-app`, `t001`, and
`Ex4_7_37_Bor03_FR`.  Each directory retains processor events, stdout, stderr,
CPF, and CeTA output.  No CeTA source or generated-checker change was needed;
there is no checker patch to integrate.

## 2026-07-31 relative match-bounds all-run compatibility guard

The fresh TermCOMP 2025 SRS baseline exposed one uncertifiable candidate on
`SRS_Standard/Mixed_SRS/3.ari`.  Incremental relative match-bounds completion
had completed one left-hand-side run, but a different run became reachable
later in the fixed point and had no compatible right-hand-side run.  Ferrum
therefore returned YES while CeTA-CSR correctly rejected the automaton.

`complete_srs_match_bounds_completion_from_builder` now performs a final
all-path strict and weak compatibility validation before constructing a proof.
The exact example is a focused regression.  The formerly successful explicit
`relative-match-bounds(5)` atom is now inapplicable, and the current default
returns Unknown at 60 seconds instead of emitting an uncertifiable CPF.  The
campaign promotion gate retained the rejected attempt only as a failure; it
never entered the monotone oracle.

## 2026-07-31 collapsing-rule eta-saturation guard

Current-code evidence replay exposed an uncertifiable uncurrying YES for
`TRS_Standard/Secret_05_TRS/ttt2.ari`.  Applicative eta-saturation incorrectly
required both sides of a rule to have a known applicative head.  For the
collapsing rule `+(0,x) -> x`, this omitted the mandatory expansion even though
the left-hand side still had positive applicative arity; CeTA correctly
reported the missing eta rule.

Eta expansion is now governed solely by the remaining applicative arity of the
left-hand side, while the same fresh argument is appended to an arbitrary
right-hand side, including a variable.  The exact collapsing case is covered
by a regression; all 13 uncurrying-focused tests pass.  The corrected default
returns the intended dependency-pair loop proof for `ttt2`, and its CPF passes
production CeTA-CSR twice.  The rejected terminating attempt is excluded from
oracle promotion.

## 2026-07-31 `gen-25` broader natural-Arctic recovery

The certified AProVE proof for `TRS_Standard/Secret_06_TRS/gen-25.ari` uses a
3D natural-Arctic matrix interpretation containing coefficient 3.  Ferrum's
default only searched the 0/1 class.  A focused replay with dimension 3,
constant bound 1, and coefficient bound 3 closed the DP problem in 3.6
seconds and produced a CPF accepted by `.tools/ceta-relative-bounds`:

```text
target/manual-probes/20260731-gen25-arctic3-coeff3-60s
```

The default strategy now retains the cheap 0/1 Arctic query and runs the
broader class in a separate eight-second early DP chain, followed by graph
decomposition, monotonic polynomial, subterm, and size change.  The automatic
default artifact is:

```text
target/manual-probes/20260731-gen25-default-arctic3-broad-60s
```

A seven-example current-default regression is retained at
`target/manual-probes/20260731-seven-certified-arctic3-regression-60s`.
`gen-25`, `ternary-hard`, `ternary`, `Der95/13`, `gen-18`,
`Ex1_Luc02b_FR`, and `Ex7_BLR02_FR` are all YES and CeTA-certified.  Each
directory retains processor events, stdout, stderr, CPF, and CeTA output.

Two focused misses delimit later work.  AProVE's certified
`AProVE_08/thiemann40_modified` proof uses a 1D Arctic interpretation over the
integers with finite `-1` entries, a domain Ferrum does not yet implement.
`Transformed_CSR_04/Ex15_Luc98_FR` uses rational coefficients with denominator
4 and gap `1/16`; even the exact bounds time out in Ferrum's current QF-NIA
synthesis at `target/manual-probes/20260731-ex15-rat4-focused-60s`.  This is
search-encoding evidence for the planned direct bit-vector rational encoding.

No CeTA source or generated-checker change was needed; there is no checker
patch to integrate.

## 2026-07-31 canonical retained-loop and residual-strategy replay guards

Strict replay of `Secret_05_TRS/cime4.ari` exposed a name-equivariance defect
in retained loop import: the raw state found and certified the stored DP loop
in 2 ms, while the semantically canonical representative timed out because
the fixture still used the original function names.  Retained loop fixtures
may now carry their source rules.  Ferrum standardizes those rules and the
live TRS, composes the two certified symbol bijections, imports the renamed
witness, and still runs the native mixed-DP-loop checker.  The canonical state
now solves in 2 ms and its CPF was accepted twice by CeTA-CSR.  The focused
raw/canonical retained-loop regressions pass.

DP probe residuals now also retain their rewrite strategy.  In particular, a
`switchInnermostProc` child is materialized as an innermost DP input rather
than silently reverting to full rewriting; the runtime child and CPF
assumption therefore have the same proof obligation.  A focused
`IJCAR_26a` regression covers the context transfer.

After freezing 133 manual campaign proofs and the corrected canonical
`cime4` proof, oracle `v164` replayed the latest 14 certified-NO roots with
fallback disabled as 14/14 certified NO.  The export promoted 243 manifest-
gated positive evidence rows, superseded 29 assembly placeholders, and
promoted zero uncertified results:

```text
target/data-campaign/state-first-adaptive-20260731-srs-v162/rounds/oracle-global-v164-manual-no14-canonical.jsonl
SHA-256 1a38417e65a68a6c3e693cfd904a401219237ea5476cc929e9669a504828df11
```

## 2026-07-31 quasi-RPO weak-equivalence recovery

AProVE's certified proof for
`TRS_Standard/Transformed_CSR_04/Ex2_Luc02a_GM.ari` exposed two completeness
defects in Ferrum's DP path-order search.  The weak part of a quasi-RPO had
been approximated by syntactic equality or strict order, so distinct symbols
in one quasi-precedence class could not be equivalent.  The multiset status
also used injective pairwise matching instead of the standard multiset
extension.  SMT synthesis and independent concrete validation now implement
the same quasi-term equivalence and full multiset extension.  Q-specific
marked/unmarked filter constraints are emitted only for innermost DP problems.

The exact AProVE witness is retained as a regression test.  All 15 path-order
tests pass.  Focused one-shot search removes all 28 DPs in about 0.7 seconds:

```text
target/manual-probes/20260731-ex2-path-order-quasiweak-30s
```

The cheap default portfolio now includes a three-second `dp(path-order)` race.
The resulting default proofs for `Ex2_Luc02a_GM` and the neighboring
`ExSec11_1_Luc02a_GM` are both accepted by `.tools/ceta-relative-bounds`:

```text
target/manual-probes/20260731-ex2-default-quasiweak-certified-final
target/manual-probes/20260731-quasi-rpo-neighbor-replay-4x25s
```

The same four-example replay retains the remaining `tower_sizeChange` and
applicative `#3.40` timeouts.  The preceding seven-example default run also
added certified YES results for `LISTUTILITIES_nosorts-noand_FR`,
`LengthOfFiniteLists_complete_GM`, and `Waldmann_06/jwttt` at:

```text
target/manual-probes/20260731-next-seven-middle-default-60s
```

No CeTA changes were required; these CPF proofs use the existing certified
recursive path-order checker.

## 2026-07-31 uncurrying continuation and next frontier batch

A six-example frontier replay produced new CeTA-certified default YES results
for `AProVE_07/kabasci04.ari`, `AProVE_07/wiehe02.ari`, and
`AProVE_07/wiehe03.ari`. Full artifacts are retained at:

```text
target/manual-probes/20260731-next-frontier-six-default-35s
```

`Zantema_05/z05.ari` was a known certified regression. It is recognized as an
effective SRS, whose generic termination fallback was delayed by 35 seconds,
while its retained proof used uncurrying. Bounded uncurrying is now part of
the fast SRS/effective-SRS portfolio. The uncurrying processor also always
tries a focused certified continuation before the configured broad fallback:
polynomial DP deletion, graph decomposition, three per-pair-one narrowing
steps with graph decomposition after each transformation, then a 3D
natural-Arctic reduction pair.

The current default closes `z05` in under two seconds, and
`.tools/ceta-relative-bounds` accepts the resulting CPF:

```text
target/manual-probes/20260731-z05-default-fast-srs-uncurry-regression-final
```

The exact TPDB problem and continuation are retained as a repository-local
regression. All 14 uncurrying-focused tests pass. No CeTA changes were needed.

## 2026-07-31 compositional DP transformation continuations

Inspection of AProVE's certified `Applicative_05/Ex6Recursor.ari` proof found
that Ferrum was discarding explicit DP strategies after reduction-pair
deletion, narrowing, rewriting, and forward instantiation. In particular, an
explicit `narrowing(per-pair=1)` continuation was replaced by an unbounded
historical narrowing ladder. Recursive transformation search now always
decomposes the graph and then retries the explicit caller strategy first.
Default/unconfigured searches retain their existing generic continuations.
The new behavior has a direct regression test, and all 227 dependency-pair
tests passed.

A retained 55-second focused `Ex6Recursor` trace now follows the certified
prefix through uncurrying, switching to innermost, 1D Arctic deletion,
narrowing, rewriting, two forward-instantiation steps, and two 3D Arctic
deletions. It remains UNKNOWN because the next transformed residual differs
from AProVE's candidate sequence. The focused route is capped at 20 seconds in
the default processor before the established fallback:

```text
target/manual-probes/20260731-ex6-applicative-focused-v4
```

An eight-example default-strategy frontier run retained full stdout, stderr,
processor events, progress logs, and CPFs at:

```text
target/manual-probes/20260731-next-eight-after-strategy-fix
```

Four previous gaps became YES and each CPF independently returned
`CERTIFIED` from `.tools/ceta-relative-bounds`:

```text
TRS_Standard/AProVE_07/wiehe05.ari
TRS_Standard/Transformed_CSR_04/LISTUTILITIES_nosorts_FR.ari
TRS_Standard/Transformed_CSR_04/LengthOfFiniteLists_complete_noand_GM.ari
TRS_Standard/Transformed_CSR_04/OvConsOS_complete_noand_GM.ari
```

The other four examples reached the 40-second external limit. A separate
60-second `tower_sizeChange.ari` replay also timed out, with full artifacts in
`target/manual-probes/20260731-tower-strategy-composition-fix`. No CeTA source
or checker changes were needed for this work.

## 2026-07-31 transformed-CSR monotonic/path-order ladder

AProVE's certified proofs for the remaining transformed-CSR family commonly
use graph decomposition, repeated monotonic polynomial deletion, one path-order
deletion, and SCT closure. An isolated Ferrum replay of that existing certified
processor family proved and certified both `Ex2_Luc02a_C.ari` and
`Ex9_BLR02_C.ari`:

```text
target/manual-probes/20260731-focused-monopoly-path-sct
```

Racing the ladder inside the broad early-order portfolio made
`Ex9_BLR02_C.ari` time out even in an isolated default run. Since Ferrum already
recognizes these generated systems with the `transformed-csr` strategy
condition, the checked-in default now runs bounded 35-second
graph/monotonic-polynomial/path-order/SCT and
graph/path-order/monotonic-polynomial/SCT ladders before its broad transformed
portfolio. The scoped default closes `Ex9_BLR02_C.ari` in about 12 seconds and
CeTA certifies the emitted CPF:

```text
target/manual-probes/20260731-ex9-default-transformed-priority
```

Two family sweeps produced ten further certified YES results beyond the four
recorded in the preceding section. Their full artifacts are retained in:

```text
target/manual-probes/20260731-transformed-csr-next-eight-45s
target/manual-probes/20260731-transformed-csr-next-twelve-45s
```

A 14-way concurrent default regression retained twelve YES results, and all
twelve emitted CPFs returned `CERTIFIED`:

```text
target/manual-probes/20260731-ten-new-certified-default-regression
```

`OvConsOS_complete_noand_GM.ari` and `ExIntrod_GM99_GM.ari` have independently
certified focused/default artifacts but timed out in that 14-way replay. The
two persistent family misses selected for later residual analysis are
`Ex9_BLR02_FR.ari` and `MYNAT_complete_noand_GM.ari`. No CeTA changes were
required.

The path-order-first variant subsequently closed
`MYNAT_nokinds_noand_GM.ari`; the focused and three-way concurrent default
replays both returned YES and CeTA certified both emitted CPFs:

```text
target/manual-probes/20260731-mynat-path-first
target/manual-probes/20260731-two-transformed-ladders-default
```

`MYNAT_complete_noand_GM.ari` remains open. The two-ladder concurrent default
regression also reconfirmed certified YES for `Ex2_Luc02a_C.ari` and
`Ex9_BLR02_C.ari`.

A subsequent 12-example default sweep over the next AProVE-certified
transformed-CSR frontier added three CeTA-certified YES results:
`Ex1_GL02a_C.ari`, `Ex1_GL02a_iGM.ari`, and `Ex6_9_Luc02c_iGM.ari`.
Every per-example result, progress trace, CPF, and CeTA log is retained under:

```text
target/manual-probes/20260731-next-transformed-cluster-default-65s
```

The remaining nine results were six MAYBE and three timeouts under concurrent
65-second harness limits. No CeTA source or checker changes were needed.

A seven-example polynomial-evidence batch then added two more default-strategy
CeTA-certified YES results, `CiME_04/log2.ari` and
`Transformed_CSR_04/Ex5_DLMMU04_C.ari`. Full artifacts are retained under:

```text
target/manual-probes/20260731-next-poly-cluster-default-65s
```

The other five examples returned MAYBE under the 65-second harness limit. No
CeTA changes were required.

Replaying the five residuals with the exact direct polynomial processor proved
and certified `Ex5_DLMMU04_iGM.ari` in 3.7 seconds:

```text
target/manual-probes/20260731-focused-poly-residual-35s
```

The transformed-CSR default strategy now tries that direct polynomial class
for six seconds before entering its DP ladders. A two-example default regression
proved and CeTA-certified both `Ex5_DLMMU04_iGM.ari` (3.5 seconds) and the
existing path-order case `Ex9_BLR02_C.ari` (28.4 seconds):

```text
target/manual-probes/20260731-direct-poly-default-regression
```

The final scoped-solver-portfolio release binary reconfirmed the new default
`Ex5_DLMMU04_iGM.ari` proof and certification in two seconds under:

```text
target/manual-probes/20260731-final-ex5-default-cert
```

No CeTA source or executable changes were needed.

The path-order search was also reduced from a restrictive preliminary query
plus unrestricted fallback to one unrestricted formula. That complete formula
now races Z3 and cvc5 with cooperative subprocess cancellation. The focused
unit regression passes, but the 67-pair `MYNAT_complete_noand_GM.ari` query
still exceeded a 70-second external limit:

```text
target/manual-probes/20260731-mynat-solver-portfolio
```

Inspection against AProVE's certified all-multiset witness and Sections 3-4 of
Schneider-Kamp et al., *Proving Termination Using Recursive Path Orders and SAT
Solving*, identifies the remaining cost: Ferrum expands filtered-term
alternatives, whereas the published polynomial encoding represents filtering
by per-position Boolean variables and shares recursive comparison formulas.
Implementing that direct encoding is the next path-order strengthening. The DP
graph was not changed. No CeTA changes were needed.

## 2026-07-31 top-level sequence residuals and three certified recoveries

Top-level `Sequence` had accidentally shared the executor path for `Choice`:
every atom received the original TRS, while a polynomial atom recursively
entered its own default residual search. The executor now probes non-final
rule-removal atoms, reconstructs their exact residual TRS, passes that residual
to the next atom, and nests the final proof under the retained certified
contexts. The supported contexts are polynomial, KBO, path-order, and
innermost non-applicable-rule removal. The focused regression
`top_level_sequence_passes_rule_removal_residual_to_its_continuation` passes.

The AProVE-shaped `LengthOfFiniteLists_nokinds_{,noand_}iGM` probes are retained
under:

```text
target/manual-probes/20260731-length-sequence-continuation-fix
target/manual-probes/20260731-length-sequence-continuation-fix-adjusted
target/manual-probes/20260731-length-sequence-continuation-dp
```

They confirm nested residual rule removal. Ferrum's maximizing polynomial
query reaches its fixed point in fewer steps than AProVE, but the resulting
15/17-pair Standard DP components remain unproved after about 46 seconds.
AProVE's certificates use a deeper reduction-pair chain including degree-two
polynomials, KBO with argument filtering, Arctic matrices, narrowing, and
repeated usable-rule reductions. No switch to innermost occurs in those
Standard certificates.

The next four-example default replay is retained at:

```text
target/manual-probes/20260731-next-standard-frontier-after-sequence
```

It adds three current-release certified YES results:

- `PEANO_nokinds_noand_iGM.ari`: 8.359 seconds, CeTA `CERTIFIED`.
- `ExSec11_1_Luc02a_iGM.ari`: 4.631 seconds, CeTA `CERTIFIED`.
- `ExSec11_1_Luc02a_C.ari`: 3.954 seconds, CeTA `CERTIFIED`.

All three use ordinary DP transformation, graph decomposition, and repeated
monotonic polynomial pair/usable-rule deletion. `Ex1_2_AEL03_iGM.ari` remains
UNKNOWN at 60.176 seconds; its trace records repeated failed one-dimensional
Arctic searches taking about 14.7 seconds. Every run retains stdout, stderr,
CPF when produced, processor events, progress events, elapsed time, exit code,
and CeTA output. The dependency graph was not changed. No CeTA source or
executable changes were required.

## 2026-07-31 next Standard frontier batches: four certified recoveries

Two current-release, default-strategy batches are retained with complete
per-example artifacts at:

```text
target/manual-probes/20260731-next-standard-frontier-batch2
target/manual-probes/20260731-next-standard-frontier-batch3
```

They add four CeTA-certified YES results:

- `Transformed_CSR_04/Ex2_Luc02a_iGM.ari`: 4.224 seconds; repeated usable-rule
  reduction pairs and graph decomposition.
- `CiME_04/big.ari`: 5.488 seconds; polynomial usable-rule reduction followed
  by eleven SCT/subterm component proofs.
- `AProVE_07/kabasci02.ari`: 49.572 seconds; a longer mixed monotonic and
  usable-rule polynomial reduction-pair chain.
- `Various_04/13.ari`: 1.304 seconds; polynomial cleanup followed by
  SCT/subterm.

CeTA prints `CERTIFIED` for all four CPFs. The other fourteen examples in these
batches remain UNKNOWN or reach the 65-second harness ceiling. In particular,
`JFP_Ex31`, `worm_wrong`, `MNZ_10/0`, `wiehe11`, and `Secret_07_TRS/5` consume
approximately the full 60-second strategy budget, while
`Applicative_first_order_05/13` reaches the external ceiling without a final
status line. Every example retains progress and processor-event JSONL, stdout,
stderr, elapsed time, exit status, CPF when produced, and CeTA output. No
dependency-graph or CeTA changes were made.

### DP sequence suffix experiment and rejection

Focused replays of AProVE's `Ex16_Luc06_C` and `Ex1_GM99_C` proof prefix showed
that an explicit `narrow(per-pair=1)` could recursively re-enter the containing
DP sequence. Passing only the unexecuted suffix to each DP sequence processor
removed that restart, but a seven-example regression then lost six existing
default proofs. The change was therefore fully reverted before the final
release rebuild. The experiment and its complete traces are retained at:

```text
target/manual-probes/20260731-ex16-ex1-double-narrow
target/manual-probes/20260731-ex16-ex1-double-narrow-capped
target/manual-probes/20260731-ex16-ex1-sequence-suffix-fix
target/manual-probes/20260731-ex16-ex1-sequence-suffix-final
target/manual-probes/20260731-dp-sequence-suffix-regression
target/manual-probes/20260731-dp-sequence-restored-regression
```

The result is architectural: DP strategies need a first-class residual-state
outcome before sequence suffixes can replace the existing recursive processor
contract without losing power. No graph-estimation change was attempted.

## 2026-08-01 first-class split and relative DP recovery

Ferrum now has a first-class DP `pipeline(...)` and CPF `<splitProc>` support.
The selected split branch is represented correctly as a relative DP problem:
the selected pairs remain strong and the complement remains present as weak
pairs. Semantic labeling preserves this partition. Polynomial reduction pairs
weakly orient the entire union while deleting only strong pairs, and ordinary
global SCT may close the relative branch by proving termination of the whole
union. Production CeTA tests cover both polynomial and SCT split continuations.

The initial implementation incorrectly omitted the weak complement; CeTA
rejected that certificate. Later graph-first attempts also omitted a required
weak self-loop and were rejected. Those rejected artifacts are retained under
the `20260801-ex16-dp-split*` probe directories. No rejected proof was counted.

A checked carrier-two semantic model family now combines a distinguished
constructor, a constructor projection, identity normalization wrappers, one
affine marking wrapper, and zero-valued control wrappers. It finds the AProVE
shape for `Transformed_CSR_04/Ex16_Luc06_C.ari` before generic enumeration.
The final focused artifact is:

```text
target/manual-probes/20260801-ex16-projection-affine-v4
```

Ferrum returns YES and `/work/dfm/festschrift/CeTA-CSR/ceta` prints
`CERTIFIED`. A subsequent default replay also recovered
`Transformed_CSR_04/Ex4_7_15_Bor03_iGM.ari`; its graph and polynomial
reduction-pair proof is retained at:

```text
target/manual-probes/20260801-ex4-7-15-next
```

CeTA prints `CERTIFIED` for that CPF as well. Focused regressions cover the
semantic model candidate, relative polynomial split, and relative split with
global SCT. No CeTA source or executable changes were required, and dependency
graph estimation was not changed.

## 2026-08-01 focused scheduling for small and applicative Standard TRSs

The AProVE 2025 certified proof for `Applicative_05/Ex6Recursor.ari` was
inspected locally. Its shape is uncurrying, a switch to innermost rewriting,
then a transformational DP proof using rewriting, narrowing, forward
instantiation, 3D Arctic matrices, KBO with argument filtering, and SCT.
Ferrum already implemented this continuation. A focused `uncurry` replay was
CeTA-certified, while the old default started the same branch late and slowed
it through solver-heavy sibling work. The Standard strategy now gives
applicative inputs a bounded isolated uncurrying attempt before fallback. The
default proof and complete artifacts are retained at:

```text
target/manual-probes/20260801-ex6recursor-default-prioritized-v2
```

The strategy language now also supports `rules-at-most(N)`. Standard and
transformed-CSR problems with at most 15 rules receive a bounded first-class
DP pipeline attempt before the broad portfolio. This makes the existing
certified `JFP_Ex31` focused proof available in the default strategy. Its final
artifact is:

```text
target/manual-probes/20260801-jfp-default-small-priority-25s
```

Production `/work/dfm/festschrift/CeTA-CSR/ceta` prints `CERTIFIED` for both
proofs. Applicative regressions `Zantema_05/z05` and
`Applicative_first_order_05/#3.40`, plus transformed/small regressions
`Ex16_Luc06_C`, `Ex4_7_15_Bor03_iGM`, and `Secret_05_TRS/matchbox1`, all remain
default YES and CeTA-certified. Their artifacts are under:

```text
target/manual-probes/20260801-applicative-priority-regression
target/manual-probes/20260801-small-pipeline-default-regression
```

An AProVE-shaped pipeline probe for `Secret_07_TRS/5.ari` reaches the expected
monotonic polynomial, instantiation, narrowing, forward-instantiation, and
polynomial processors, but explores too many forward-instantiation candidates
and remains UNKNOWN. The full diagnostic is retained at
`target/manual-probes/20260801-secret07-5-aprove-pipeline-v1`; sharper
proof-evidence-based candidate ordering is the next target. No CeTA or
dependency-graph implementation changes were made.

After restoring the previous DP executor, exact retained strategy replays were
run from the final rebuilt binary under:

```text
target/manual-probes/20260731-next-gains-exact-replay-current
```

`AProVE_07/kabasci02.ari` and `Various_04/13.ari` again produce YES and CeTA
`CERTIFIED`. `Ex2_Luc02a_iGM.ari` and `CiME_04/big.ari` remain UNKNOWN in this
later replay, although the earlier CPFs in frontier batches 2 and 3 are valid
and CeTA-certified. This exposes current default/graph runtime instability,
not an accepted checker or graph modification. No CeTA changes were needed.

## 2026-08-01 strict native-CSR complete-recipe replay

Complete top-level CSR sequences are now first-class oracle actions. The
runtime records a round-trippable parent recipe against the original root and
also records every residual action independently. The export path preserves
top-level composition and SQLite runtime aliases, local oracle lookup remains
active under `--no-top-level-llm`, and composed recipes receive the full
60-second replay allowance. Parameterized `csr-safe-dp(<dp strategy>)` makes
the residual continuation explicit instead of relying on a fresh default
search.

Focused direct and strict replays recovered `PALINDROME_complete-noand`,
`PALINDROME_complete`, and `MYNAT_complete-peanoSimple`; every CPF passed two
CeTA-CSR checks. The current monotone oracle is:

```text
target/manual-evidence-replay-v147-20260731/oracle-global-v312-csr-complete-recipes.jsonl
```

The final strict replay at
`target/manual-evidence-replay-v147-20260731/v314-csr108-strict-complete-recipes`
selected all 108 TermCOMP 2025 native CSR roots, disabled fallback with
`timeout(60s, fail)`, and used local oracle guidance with top-level model calls
disabled. Result: 85 certified YES, 4 certified NO, 19 MAYBE, zero timeout,
zero execution error, and zero certification failure. This is **89/108
certified oracle-only**, one above the previous 88-root high-water mark.

### f20 frontier gain

A fresh default pass over the 19 unresolved roots recovered
`Transformed_outermost_08/f20.ari` in 0.688 seconds. The full CPF is certified
by CeTA-CSR. Exact-proof extraction rechecked it twice and materialized the
complete root recipe plus five independently addressable residual states at:

```text
target/manual-evidence-replay-v147-20260731/v328-csr-f20-recovery
```

The monotone v329 oracle strictly reconstructed the proof in 1.521 seconds
with fallback set to `fail`; that CPF also passed CeTA-CSR twice. A strict
replay of all 19 former MAYBEs returned one certified YES (`f20`) and 18
MAYBEs, with no timeout, execution error, or certification failure. Combined
with v314, the native CSR score is therefore **90/108 oracle-only**: 86 YES,
4 NO, and 18 MAYBE. The retained oracle and audit are:

```text
target/manual-evidence-replay-v147-20260731/oracle-global-v329-csr-f20.jsonl
target/manual-evidence-replay-v147-20260731/v331-csr19-strict-f20
```

CeTA-CSR was rebuilt in the isolated user directory
`CeTA-CSR/target/isabelle-user-csr-loop-code-20260731k`. The `Proof_Checker`
and `Code` sessions pass. A fresh 367-module Haskell export under
`CeTA-CSR/target/csr-integrated-code-20260801` accepts the mixed-U3 proof,
Ex49 U3, all four valid CSR loops, and the three complete-recipe proofs; it
rejects the mutation whose loop step lies below an inactive argument.

## 2026-08-01 scalar-Arctic and broad-linear Standard frontier

The certified AProVE proof for `AProVE_07/wiehe11.ari` was reduced to its
component-level shape. Ferrum already closed every SCC except the four-pair
`plus#` component. A one-dimensional natural-Arctic interpretation with
entries bounded by 5, followed by a natural linear interpretation with the
same bound and size-change/subterm cleanup, closed the residual without any
dependency-graph change. The focused search and direct production-CeTA check
are retained under:

```text
target/manual-probes/20260801-next-standard-wiehe-arctic-chain
target/manual-probes/20260801-wiehe-arctic-poly-simplified
```

The proof-guided portfolio was then tested on eight unresolved AProVE-certified
Standard examples. Five produced fresh CPFs accepted by `../CeTA-CSR/ceta`:
`wiehe01`, `wiehe11`, `Ex9_BLR02_FR`, `Ex4_7_56_Bor03_iGM`, and
`Ex49_GM04_iGM`. Complete focused artifacts are in:

```text
target/manual-probes/20260801-standard-arctic-weak-frontier
target/manual-probes/20260801-ex49-simplified
target/manual-probes/20260801-scalar-arctic-simplified
```

The default strategy now keeps the useful searches in two cancellation
domains: a 20-second scalar-Arctic/broad-polynomial/SCT portfolio and a
30-second broad-linear/SCT portfolio. A rebuilt-default replay with five jobs
returned fresh CeTA-certified YES results for `wiehe01` (6.160 s), `wiehe11`
(16.053 s), `Ex4_7_56_Bor03_iGM` (8.120 s), and `Ex9_BLR02_FR` (8.212 s):

```text
target/manual-probes/20260801-standard-default-split-arctic-linear-replay
```

`Ex49_GM04_iGM` remains a focused-strategy certified YES (25.655 s with the
polynomial-only portfolio) but reached the 65-second harness ceiling under the
full default strategy, so it is not counted as a default gain. Earlier failed
or over-broad variants are retained in the neighboring `20260801-*` artifact
directories. No graph-estimation code and no CeTA source were changed.

### MYNAT strict CSR replay and CSR graph-cache repair

`Maude_06/MYNAT_complete-noand.ari` was already represented by a complete
certified proof, but strict oracle replay spent the entire 60-second allowance
constructing its 67-pair CSR dependency graph before any residual state could
query the oracle. The edge cache was the defect: every new edge was inserted
into a vector and every later lookup linearly compared against the growing
vector, including the full CSR context in each key.

Ferrum now precomputes unchanged forward, reverse, root, and target-argument
tcaps once per source or target. The CSR edge-cache path takes one snapshot,
computes misses locally, and merges them once. The edge criterion itself is
unchanged. The isolated `csr-safe-dp(graph)` graph went from a 60-second
timeout at source 34/67 before the fixes to completion in 94 ms. With bare
`csr-safe-dp`, v336 independently guided the exposed SCCs and produced a
complete proof in 6.210 seconds. The extracted exact-state evidence was merged
monotonically into:

```text
target/manual-evidence-replay-v147-20260731/oracle-global-v345-mynat-cache-fixed.jsonl
```

A fresh fallback-disabled replay against v345 terminated in 3.128 seconds and
its reconstructed CPF passed production CeTA-CSR twice:

```text
target/manual-evidence-replay-v147-20260731/v346-mynat-v345-strict
```

This raises native TermCOMP 2025 CSR strict oracle-only coverage to 91/108:
87 certified YES, 4 certified NO, and 17 MAYBE. The focused CSR graph and
dependency-graph suites pass, as do the release build and `git diff --check`.

## 2026-08-01 integer Arctic and iterated uncurrying removal

The sole AProVE 2025 certified Standard proof containing an Arctic matrix over
integers is `AProVE_08/thiemann40_modified.ari`. Ferrum now exposes
`integer-arctic-matrix(dimension=N,min-value=L,max-value=U)`. Its one-shot
QF_LIA encoding represents finiteness separately from each signed value,
exports CPF `<integers/>`, and rechecks the decoded interpretation in Rust.
The first model was correctly rejected by CeTA because Ferrum had required a
distinguished entry to be finite rather than nonnegative. Both the encoding
and validator were tightened before any default integration. The corrected
focused proof and actual-default replay are retained at:

```text
target/manual-probes/20260801-thiemann40-integer-arctic-positive
target/manual-probes/20260801-thiemann40-default-integer-arctic
```

The default replay terminated in 385 ms and `../CeTA-CSR/ceta` returned
`CERTIFIED`. A five-example regression retained `thiemann40_modified` plus the
four preceding scalar-Arctic/broad-linear default gains, all CeTA-certified:

```text
target/manual-probes/20260801-integer-arctic-default-regression-5x65s
```

For `Zantema_05/z07.ari`, AProVE's certificate uncarries the applicative TRS,
performs two monotonic polynomial rule removals, and then closes the residual
DP problem. Ferrum's uncurrying continuation now exhausts productive
polynomial removals before invoking its residual portfolio. A focused replay
terminated in 1.340 seconds and was CeTA-certified:

```text
target/manual-probes/20260801-z07-uncurry-iterated-poly
```

Because unary/applicative TRSs are dispatched through the effective-SRS path,
the default SRS strategy now races the main portfolio directly against the
preprocess-then-main path. Previously, failed preprocessing prevented the main
portfolio from running. Default replays now certify `z07` in 1.466 seconds and
retain `z05` in 1.753 seconds:

```text
target/manual-probes/20260801-srs-direct-core-z05-z07
```

Focused unit tests cover integer-Arctic parser round trips, signed-domain
well-formedness, positivity rejection, CPF integer-domain output, and the
existing `z05` uncurrying continuation. No dependency-graph criterion and no
CeTA source were changed.

## 2026-08-01 exact rational BV and large-system linear prelude

The linear fixed-denominator `rat-poly` search now uses one QF_BV formula
instead of nonlinear real arithmetic. The formula contains the polynomial
numerators, strict-pair choices, argument filter, and its usable-rule fixed
point. Denominator-aware term rescaling and a checked expression bound derive
the required bit width; there is no configured width cutoff. Ferrum rechecks
the decoded interpretation with its existing exact rational validator before
constructing CPF. The old denominator-64 `kabasci03` query took 55.045 seconds
without a result. The replacement found and certified the witness in 2.822
seconds in isolation:

```text
target/manual-probes/20260801-kabasci03-rational-bv64
```

The default strategy gives this denominator-64 proof shape an eight-second
branch. A six-example default regression retained all six prior certified
results, with `kabasci03` terminating in 6.509 seconds:

```text
target/manual-probes/20260801-rational64-default-regression-6x65s
target/manual-probes/20260801-large-prelude-default-regression-6x65s
```

`Secret_05_TRS/cime5.ari` needs repeated linear DP deletion on a 35-rule TRS.
The strategy language now supports `rules-at-least(N)`. For Standard TRSs with
at least 30 rules, the default strategy first gives the graph/deletion chain a
20-second sequential attempt and falls through to the unchanged YES/NO race
if it fails. Graph decomposition follows every deletion. The actual default
entry point closed `cime5` in 17.675 seconds and the emitted CPF was accepted
by `../CeTA-CSR/ceta`:

```text
target/manual-probes/20260801-cime5-default-large-linear-prelude
```

The next two unresolved AProVE-certified examples were then replayed with a
65-second external bound. `Applicative_first_order_05/#3.40.ari` became a
default certified YES through the existing uncurrying processor in 59.210
seconds. `AProVE_06/tower_sizeChange.ari` remained a timeout; its retained
events show several final polynomial searches receiving only about two
seconds, so it remains a scheduling/proof-sequence target rather than a
claimed SCT gain:

```text
target/manual-probes/20260801-next-two-after-linear-rational-2x65s
```

The rational-BV regression and both `rules-at-least` parser/evaluator tests
pass. No dependency-graph implementation and no CeTA source were changed.

## 2026-08-01 ordinary integer matrices and exact affine weak polynomials

Ferrum now has a separate DP reduction-pair processor for ordinary integer
matrix interpretations:

```text
integer-matrix(dimension=2,min-value=-2,max-value=3,max-symbols=64,max-arity=4)
```

It uses one signed QF_BV query, permits signed constant vectors, constrains
coefficient matrices componentwise nonnegative, decodes two's-complement
models, and independently replays the result. Both symbolic orientation and
replay implement CeTA's componentwise `Pleft`/`Pright` clamping. CPF output
uses `<matrixInterpretation><domain><integers/></domain>`. A production CeTA
unit smoke test accepts a complete DP certificate. The weak-polynomial search
was also changed from quantified nested-max constraints to a one-shot
quantifier-free encoding of CeTA's exact affine `Pleft`/`Pright` sufficient
comparison.

The default Standard strategy races two ten-second DP branches: weak
polynomial followed by integer matrix, and integer matrix first. Every
reduction is followed immediately by graph decomposition. The focused
four-example probes and their production-CeTA outputs are retained here:

```text
target/manual-probes/20260801-integer-matrix-small-cluster
target/manual-probes/20260801-integer-matrix-default-cluster-v2
```

The first attempted default harness used an unavailable `/usr/bin/time`, so
Ferrum did not start and each case returned 127. It is retained but not counted:

```text
target/manual-probes/20260801-integer-matrix-default-cluster
```

A 10-worker, 65-second external-timeout replay of all ten `TRS_Standard/MNZ_10`
examples preserves CPF, events, stdout, stderr, exit codes, wall times, and
CeTA output per example:

```text
target/manual-probes/20260801-mnz10-default-family
```

Examples 0, 1, 2, 3, 5, 7, 8, and 9 are terminating and `CERTIFIED`; 4 and 6
reach the external timeout. Six accepted proofs use ordinary integer matrices.
All ten were `unknown` in
`target/termcomp-runs/20260725-trs-standard-oracle-final-128w-305s`, so this is
an eight-certified-YES focused recovery. The AProVE-certified frontier entries
0, 1, 2, 3, and 8 are all recovered. The invalid pre-alignment exploratory
proof in `target/manual-probes/20260801-mnz10-integer-matrix-first` is not
counted: its CeTA rejection exposed the coefficient-domain mismatch that the
current implementation fixes.

The parameterized `switch-innermost(<DpStrategy>)` continuation and the
distinguished-constant semantic-labeling candidate independently recover and
certify `AProVE_06/tower_sizeChange.ari` under the default strategy. Artifacts:

```text
target/manual-probes/20260801-tower-parameterized-switch-distinguished-constant
target/manual-probes/20260801-tower-default-rule-switch-15s
```

No dependency-graph implementation and no CeTA source were changed. Formal
semantics were checked against `CeTA-CSR/thys/Orderings/Matrix_Poly.thy`,
`Reduction_Pair_Implementations.thy`, and the generated matrix-comparison and
linear-polynomial checker code.

The two remaining MNZ examples, 4 and 6, were also tested with larger signed
2D and 3D integer-matrix classes for 85 seconds. Neither produced a model, so
these expensive classes were not added to the default:

```text
target/manual-probes/20260801-mnz10-4-6-broader-integer-matrix
```

The next eight AProVE-certified frontier misses were replayed concurrently for
65 seconds each; all remained timeouts, confirming that the integer-matrix
gain is concentrated rather than accidental:

```text
target/manual-probes/20260801-next-eight-after-mnz-integer-matrix
```

For `AProVE_04/JFP_Ex31`, the retained certified proof spine is graph,
monotonic usable-rule polynomial deletion, two narrowing processors with graph
decomposition, semantic labeling, three linear reduction-pair stages, and SCT.
Two explicit-spine replays remained UNKNOWN because transformations currently
re-enter their historical recursive strategy instead of consuming the
unexecuted sequence suffix:

```text
target/manual-probes/20260801-jfp-aprove-spine-current
target/manual-probes/20260801-jfp-aprove-spine-semlab-continuation
```

A scoped experiment passed the explicit suffix only through semantic labeling.
It certified `z19`, but a default regression timed out on the previously known
`z21` and `z27` proofs. The code change was therefore fully reverted; only the
diagnostic artifacts remain:

```text
target/manual-probes/20260801-semlab-explicit-continuation-regression
target/manual-probes/20260801-semlab-continuation-default-regression
```

The next correct architectural step for JFP is first-class residual DP state
and continuations across every transformational processor, with the historical
fallback retained as a separate branch and a broad certified regression. It
must not be approximated by changing graph estimation. No graph or CeTA change
was made in any experiment above.

After the revert, the final release was rebuilt and replayed on `MNZ_10/9`,
`z21`, and `z27` with a 65-second external bound:

```text
target/manual-probes/20260801-final-integer-matrix-and-semlab-restoration
```

`MNZ_10/9` remains `CERTIFIED` and uses four integer-domain matrix
interpretations in this solver run. `z21` and `z27` also reached the external
bound after the revert, so their loaded default timing is not evidence against
the discarded continuation experiment; the semantic-labeling source change is
absent from the final tree and its complete focused CeTA test suite passes.

## 2026-08-01 SCC-aware transformation ranking and applicative recovery

Transformation candidates are now ranked first by the number of dependency
pairs that remain in cyclic SCCs, then by the size of the largest cyclic SCC,
edge count, and total pair count. This rewards transformations that expose
smaller independent components; it does not alter dependency-graph edges,
processor side conditions, or certificates. A unit regression compares one
four-pair cycle, two two-pair cycles, and a two-pair cycle plus acyclic pairs.
Narrowing ties that specialize nondeterministic calls retain original DP order.

The AProVE-shaped `Secret_07_TRS/5` probes reproduce its first three
instantiations and the narrowing at position 2, but still do not find the two
exact forward-instantiation witnesses within 90 seconds. Bounded rational and
integer-matrix cleanup does not remove this search gap. The retained evidence
is:

```text
target/manual-probes/20260801-secret07-5-aprove-pipeline-v2-orders
target/manual-probes/20260801-secret07-5-aprove-pipeline-v3-bounded-orders
target/manual-probes/20260801-secret07-5-aprove-pipeline-v4-scc-score
```

For `AProVE_04/Liveness6.4`, Ferrum follows the certified proof into repeated
narrowing and semantic labeling, but the labeled 60-pair graph consumes the
remaining 60-second budget. These negative diagnostics are retained under
`target/manual-probes/20260801-liveness64-aprove-pipeline-v{1,2}-*`.

The next applicative miss, `Applicative_first_order_05/13.ari`, is solved by
the existing uncurrying continuation in about 4.6 seconds. Both the focused
and checked-in default runs emit CPFs accepted as `CERTIFIED` by production
`/work/dfm/festschrift/CeTA-CSR/ceta`:

```text
target/manual-probes/20260801-applicative-first-order-13-uncurry
target/manual-probes/20260801-applicative-first-order-13-default
```

Default regressions `JFP_Ex31`, `Ex16_Luc06_C`, and
`Secret_05_TRS/matchbox1` remain CeTA-certified under
`target/manual-probes/20260801-transform-ranking-regression`. No CeTA source
or executable changes were required in this work.

## 2026-08-08 composition-free recursive oracle replay

Utility guidance now re-enters at every exposed DP residual. Atomic
alternatives use ordered backtracking, a branch-local active-state guard, and
a failed-state memo; a transformation is not accepted as a completed proof.
CPF extraction preserves exact affine, rational, max-polynomial, matrix,
semantic-labeling, and RPO/LPO models. Exact atoms carry only processor
parameters/witnesses and revalidate the complete live problem before changing
it. The consolidated strict oracle contains no sequence, pipeline, parallel,
choice, or continuation-bearing DP/CSR wrapper.

The final composition-free artifacts are under:

```text
target/oracle-integration-global-composition-free-20260808/
  oracle-global-v520-strict-atomic.jsonl
  final4-baseline-standard-v520-summary.md
  final3-baseline-csr-v520-summary.md
  final-baseline-outermost-v516-summary.md
  baseline-relative-v513-summary.md
  baseline-innermost-v513-summary.md
  baseline-srs-standard-v513-summary.md
```

The 155 roots initially lost by removing composed advice replay 155/155 with
CeTA certification. The complete retained TRS Standard baseline replays 764
certified YES and 226 certified NO with no misses or certification failures;
full CSR replay restores 94 certified YES and four certified NO. Two
historical outermost `NO` rows (`Zantema_08/ex6`, `ex7`)
were deliberately removed from the valid baseline: their old CPFs omitted the
outermost strategy and therefore certified unrestricted rewriting. Correctly
strategy-preserving CPFs are rejected, and both AProVE 2025 configurations
also report MAYBE for these roots. The remaining 155 historical outermost
answers replay and certify with the strategy present.

## 2026-08-11 relative-performance worktree and v722

Relative-performance development is isolated in
`/work/dfm/festschrift/ferrum-relative` on branch
`codex/relative-performance-20260811`, based on Ferrum commit `47c9d4e`.
The fixed starting oracle is:

```text
/work/dfm/festschrift/ferrum/target/universal-worklist-evidence-20260808/oracle-global-v722-no-bridge-complete.jsonl
sha256 2f4033ba3da58819b2ed62509281161e73e5ce51a9a0bf56a9059d8d36caf158
```

Relative string reversal now reverses both strict and weak rules and emits a
relative CPF continuation. Production `/work/dfm/festschrift/CeTA-CSR/ceta`
already contains the verified relative reversal theorem, so this work required
no CeTA source or executable change. A forced proof of
`SRS_Relative/Mixed_relative_SRS/zr03.ari` is retained under
`target/relative-reversal-smoke-v722` and returns `CERTIFIED`.

The first full official SRS Relative run used 32 workers, a 60-second Ferrum
allowance (65-second harness timeout), v722 plus normal fallback, and complete
per-example artifacts:

```text
target/termcomp-runs/20260811-srs-relative-v722-relative-reversal-32w-60s
```

It obtained 44 YES, 0 NO, 276 MAYBE, and 125 timeouts on 445 problems. All 44
YES proofs were CeTA-certified; there were no certification failures. The old
recorded baseline was 6 certified YES, so relative reversal and recursive
residual composition added 38 certified YES.

The follow-up build adds bounded relative flat-context closure and semantic
labeling to the default SRS race, exposes one-shot `integer-matrix(...)` search
as a strategy atom, and races natural/integer dimensions 2 and 3. Its complete
rerun artifacts are under
`target/termcomp-runs/20260811-srs-relative-v722-pipeline-matrices-32w-60s`.
It obtained 94 YES, 0 NO, 218 MAYBE, and 133 timeouts. All 94 YES proofs were
CeTA-certified, with no certification failure. Relative to the 44-YES reversal
run, it found 52 additional certified YES proofs and missed two prior YES
proofs. Both misses were recovered and certified by the final scheduling
regression gate below; they were caused by overly large explicit
nontermination timeouts on each transformed residual, not loss of proof power.

Relative SRS loop search now also seeds rewriting from overlaps of weak-rule
right-hand sides with strict-rule left-hand sides. Rewrite rules are freshened
before matching in both search and independent loop validation, respecting
the usual alpha-renaming of rule variables. This recovers AProVE's reversed
two-step relative loop for `Mixed_relative_SRS/zr13.ari`. The first focused
four-problem run is retained under
`target/termcomp-runs/20260811-relative-aprove-certified-no4-latest`: it gives
one certified NO (`zr13`) and three MAYBE results for the longer AProVE loops.

The final default strategy gives direct relative-loop search a 50 ms early
slice, then retains the established internally bounded aggregate
nontermination portfolio. This avoids spending 10--15 seconds on every
transformed residual. The final regression gate is retained under:

```text
target/termcomp-runs/20260811-srs-relative-regression-gate
```

It recovers and CeTA-certifies both full-run losses,
`Waldmann_23/size-8-alpha-3-num-{36,4}.ari`, and also reports a CeTA-certified
NO for `Mixed_relative_SRS/zr13.ari`. `cargo +1.95.0-x86_64-unknown-linux-gnu
fmt --all -- --check` and all 675 library tests pass. No CeTA source or binary
change was required anywhere in this work.
## 2026-08-11 Relative ADP Move-To-Main Probe

The relative ADP derelatification path was changed from the paper's splitting
DRP2 to a smaller processor that moves every annotated base ADP unchanged into
the main component. Isabelle checks its soundness as
`relative_adp_move_base_to_main` in
`/work/dfm/festschrift/CeTA-CSR-relative-adp/dev/Relative_ADP_Dev/Semantics/Processors/Relative_ADP_Processors.thy`.
The weak ADP relation is unchanged and the strict relation only grows. A later
DRP1 step still extracts one ordinary dependency pair for each annotated RHS
position, so no ordinary pair is lost.

Ferrum was rebuilt with Rust 1.95 and tested with:

```text
cargo +1.95.0-x86_64-unknown-linux-gnu test --lib relative_adp --jobs 32
cargo +1.95.0-x86_64-unknown-linux-gnu build --release --jobs 32
```

All seven relative-ADP unit tests passed. The 45 AProVE 2025 uncertified-only
TRS Relative YES gaps were then run with eight workers, a 10-second internal
`relative-adp` strategy timeout, and a 12-second external timeout. The result
was 24 terminating, 7 unknown, and 14 externally timed out/error exits. This
retains exactly the previous 24 raw relative-ADP YES results. Per-example
problem keys, stdout, stderr, and exit codes are retained under
`target/relative-adp-move-probe-20260811-v2`.

## 2026-08-11 Relative ADP Erasure Reduction Pairs

Ferrum now has a first-class DP-level monotone reduction-pair processor for
relative annotated dependency pairs. The implementation is in
`src/proving/processors/relative_adp/erasure_reduction_pair.rs`, with witness
construction in `src/proving/processors/relative_adp/mod.rs`. It requires all
erased ADPs to be weakly oriented, removes a nonempty strictly oriented subset,
and schedules dependency-graph decomposition immediately on the residual.

The formal development is isolated in
`/work/dfm/festschrift/CeTA-CSR-relative-adp` on branch
`codex/relative-adp-20260811`. `relative_adp_erasure_reduction_pair` proves the
semantic processor from a monotone reduction triple and the erasure simulation
of ADP steps. `check_relative_adp_erasure_redpair_sound` connects this theorem
to CeTA reduction-triple implementations, while
`check_relative_adp_termination_proof_sound` verifies recursively repeated
reduction-pair steps ending in an empty main component. The adapter and its
residual/rejection regressions replayed in the thin Isabelle console without
rebuilding IsaFoR parent heaps.

The first 100 official `TRS_Relative` problems were run with eight workers, a
10-second per-example timeout, and the explicit `relative-adp` strategy. The
run produced 40 raw YES results. Of these, 38 proof trees contain the new
erasure reduction-pair processor; 54 distinct problems produced a transformed
residual with it. Complete stdout, event streams, and lists of affected examples
are retained under:

```text
target/relative-adp-probe
target/relative-adp-probe/yes-using-erasure.txt
target/relative-adp-probe/erasure-transformed-problems.txt
```

These are deliberately not default-strategy or certified benchmark YES results
yet. Standard CPF has no relative-ADP proof production. Canonical
transformation, graph/DRP1 checking, and thin XML parser exposure remain before
the proved DP-level checker can certify complete top-level TPDB proofs.

Final verification used Rust 1.95:

```text
cargo +1.95.0-x86_64-unknown-linux-gnu fmt --all -- --check
cargo +1.95.0-x86_64-unknown-linux-gnu test --lib --jobs 32
cargo +1.95.0-x86_64-unknown-linux-gnu test --lib relative_adp --jobs 32
cargo +1.95.0-x86_64-unknown-linux-gnu build --release --jobs 32
```

The full suite passed 675 tests and had one concurrent persistent-Z3 broken
pipe; that exact test passed immediately in isolation. All eight focused
relative-ADP tests and the release build passed. A release-binary smoke proof
of `TRS_Relative/INVY_15/ex6.ari` is retained in
`target/relative-adp-erasure-smoke-graph`. Its events show graph decomposition,
the erasure reduction-pair transformation, rejection by the generic empty
processor while `graph_pending` is true, and final closure by the graph
processor.

## 2026-08-11 Relative ADP Certified Integration

The canonical relative-ADP transformation and monotone erasure reduction-pair
slice is now executable end to end. The complete branch, file, theorem, build,
and validation manifest is in `docs/relative-adp-integration-20260811.md`.

The earlier 40-YES/38-erasure figures above are retained as historical run
records but are retracted as correctness evidence: their solver encoding
allowed zero argument coefficients. The corrected one-shot encoding requires
strict monotonicity in every argument and revalidates the returned model.
Reprobing the old 38 examples produced zero erasure transformations. The first
genuine witness in a 200-smallest official probe is
`TRS_Relative/Relative_05/rt1-3.ari`.

Ferrum emitted a complete `<relativeAdpTerminationProof>` for that example and
the branch-built integrated CeTA returned `CERTIFIED`. The checker rejected an
out-of-range-index mutation and a zero-coefficient mutation, and accepted an
ordinary legacy CeTA certificate through its standard-checker fallback.
The retained one-example harness replay is
`target/termcomp-runs/20260811-relative-adp-certified-integration-smoke` and
reports 1 YES / 1 certified YES with no failure.

The attempted 45-candidate, 8-worker follow-up was stopped as required when
summed process RSS exceeded 2 TB. No aggregate score is claimed from the
interrupted run; future probes use lower concurrency.

## 2026-08-11 Relative ADP Dependency-Graph Foundation

Ferrum graph children were made content-addressable by retaining sorted
indices into `main ++ base`; reconstruction tests reject malformed selections.
No dependency-edge estimator was changed. Focused verification was:

```text
cargo +1.95.0-x86_64-unknown-linux-gnu test relative --lib --jobs 16
```

All 41 relative tests passed. In the isolated CeTA worktree
`/work/dfm/festschrift/CeTA-CSR-relative-adp`, the new thin theory
`Relative_ADP_Dependency_Graph.thy` was replayed against the already loaded
`Proof_Checker` parents as `Draft.Relative_ADP_Dependency_Graph_Test20`.
It checks Theorem 33 child reconstruction and proves annotation preservation,
labeled predecessor coverage for every target annotation, and finite canonical
origin branching. The same file was then loaded successfully with its real
production import hierarchy. The final thin replay took approximately 0.1
seconds once the parent theories were loaded.
Nontrivial graph CPF remains deliberately unsupported until the infinite-path
productive-SCC/minimal-lasso theorem and executable graph validation are both
proved.

## 2026-08-11 Relative ADP Selected-Origin Dichotomy

The CeTA worktree `/work/dfm/festschrift/CeTA-CSR-relative-adp` now contains a
proved finite-branching event dichotomy and a fixed-witness instantiation for
relative ADP chains. The fixed witness records the sharpness case, ADP, and
redex position selected for each chain step; strict indices preferentially
select their main ADP witness. This avoids the unsound proof shortcut of mixing
different witnesses that happen to realize the same source/target terms.

The final fast replay in the persistent isolated Isabelle console was
`Draft.Relative_ADP_Dependency_Graph_Test38`. It proves selected target
predecessors, root reachability, infinitely many selected main events, a heavy
initial marker, the main-path/offshoot dichotomy, and that a labeled origin edge
enters an annotated RHS position of its exact ADP. Total system memory at the
checkpoint was below 300 GiB used; no competing build or unrelated process was
started or stopped.

No Ferrum power figure changes at this checkpoint. CPF export continues to
reject nontrivial relative graph proofs until the below-root segment lemma,
finite SCC/minimal-lasso checker, and recursive proof exposure are complete.

The immediate follow-up replay, `Draft.Relative_ADP_Dependency_Graph_Test44`,
also proves the unlabeled-edge shape lemma: selected unlabeled origin edges are
marker-preserving or variable-transport edges and never root-creation edges at
the tracked marker.

## 2026-08-12 Certified Relative ADP Dependency Graphs

The IJCAR 2024 relative-ADP dependency-graph processor is now formalized,
executable, exposed through the recursive checker, and emitted by Ferrum. CeTA
checks a complete finite family consisting of main SCCs and the verified
branching-base predecessor-cone/corridor lasso candidates. Duplicate candidate
lists are removed before recursive checking; `set (remdups xs) = set xs`, so
this is a performance normalization and does not weaken coverage.

Generated-code testing found three Isabelle definitions that still forced
finite-set ordering during extraction. They now use executable root tests and
list membership. The final thin replays were
`Relative_ADP_Dependency_Graph_Impl_Test64`, checker adapter Test 9, parser Test
6, and Haskell export Test 7. The verified Haskell export took 226.94 seconds.

Ferrum's first implementation accidentally reused the ordinary-DP estimator,
which additionally applies reverse `TCAP` and `GTCAP` nonreachability pruning,
and marked terms whose relative sharpness was already represented by annotation
positions. CeTA rejected the resulting five-child certificate. Relative ADPs
now use a dedicated forward-`TCAP` edge exactly matching the formal definition,
without adding `#` symbols. Ordinary DP graph estimation is unchanged.

The final release-binary proof for
`TPDB-ARI/TRS_Relative/Relative_05/rt1-3.ari` contains one graph processor and
two recursively proved children. The newly extracted checker returned
`CERTIFIED`. Artifacts are retained under:

```text
target/relative-adp-graph-smoke/rt1-3-ceta-tcap.cpf.xml
target/relative-adp-graph-smoke/processor-events-ceta-tcap.jsonl
```

Focused verification used Rust 1.95 and passed all nine relative-ADP tests,
including a CPF-shape regression, followed by a successful release build.

## 2026-08-12 Relative ADP DRP1 And Com Foundation

Worktrees and branches:

```text
/work/dfm/festschrift/ferrum-relative
  codex/relative-performance-20260811
/work/dfm/festschrift/CeTA-CSR-relative-adp
  codex/relative-adp-20260811
```

The literature source is Kassing, Vartanyan, and Giesl, IJCAR 2024,
"A Dependency Pair Framework for Relative Termination of Term Rewriting".
The local source snapshot is under
`CeTA-CSR-relative-adp/target/literature/relative-adp`; Theorem 26 is DRP1 and
Theorem 36 is the `Com`-monotone reduction-pair processor.

Isabelle verification used the persistent isolated home
`target/isabelle-home-drp1-fast` and session identifier
`codex_ex1_layer_20260803`. The semantic Com child session rebuilt in about
five seconds. The complete generated integration build finished successfully
in 9 minutes 41 seconds elapsed (38 minutes 25 seconds aggregate CPU), and
`make ceta-relative-adp` produced the checked executable.

Ferrum's deterministic DRP1 replay was:

```text
target/release/ferrum prove target/drp1-smoke-trs.ari \
  --strategy relative-adp \
  --utility-guidance-manifest target/drp1-smoke-guidance.jsonl \
  --cpf target/drp1-smoke-trs-drp1.cpf.xml --cpf-mode cpf30

/work/dfm/festschrift/CeTA-CSR-relative-adp/ceta \
  target/drp1-smoke-trs-drp1.cpf.xml
```

The result was `CERTIFIED`. The proof contains graph decomposition followed by
`<relativeAdpDerelatification>` and a nested ordinary polynomial DP proof.
CeTA computes the ordinary DPP and checks its nonminimal DP proof; Ferrum's
recorded transformed pairs and guidance ranking are outside the trusted base.

A forced DRP1 attempt on `TRS_Relative/Relative_05/rt1-3.ari` exhausted the
ordinary DP search timeout and produced no certificate. Its existing graph
plus erasure proof remains certified. This failed attempt is not counted as a
power regression or benchmark result.

### Com Witness Soundness Checkpoint

The corrected finite ADP summary erases nested annotations and marks exactly
the root of each selected RHS subterm, matching `ann(r)` in Theorem 36. The
thin Isabelle session accepted the summary, arbitrary-chain annotation
component representation, and explicit Com discard interface in five seconds:

```text
HOME=$PWD/target/isabelle-home-com-fast \
ISABELLE_IDENTIFIER=codex_ex1_layer_20260803 \
AFP=/work/dfm/festschrift/ferrum/.tools/afp-current/thys \
/work/dfm/festschrift/ferrum/.tools/Isabelle2025-2/bin/isabelle build -j 64 \
  -d "$AFP" -d thys -d dev/Relative_ADP_Dev/Semantics \
  -d dev/Relative_ADP_Dev/Semantics/Reduction_Pair \
  Relative_ADP_Com_Reduction_Pair_Dev
```

Inspection of the paper's appendix found that the displayed proof drops
untransported annotation components without citing an order property. The
formal interface therefore requires `Com2(x,y) >= x`, `Com2(x,y) >= y`, and
`x >= Com0` in addition to Com monotonicity and invariance. Ferrum's SAT
encoding now fixes `Com0=0` and `Com2(x,y)=x+y`, which satisfies all of these
laws. The focused branching regression passed:

```text
cargo +1.95.0-x86_64-unknown-linux-gnu test --lib \
  polynomial_processor_uses_the_additive_compound_algebra --jobs 32
```

The official relative-ADP artifacts contain 11 distinct examples on which the
raw polynomial Com processor makes progress, including
`AProVE_24/{lessleaves,shuffle_a,shuffle_a2}.ari`. They remain raw YES evidence,
not certified power, until the executable step-lifting theorem is complete.
CPF export remains deliberately gated. A dedicated parser bridge has been
started with `<sharp>`, `<adpCom0/>`, and `<adpCom2/>` symbols so the eventual
certificate cannot collide with user-defined TRS names.

One integration-cache verification attempt was accidentally launched twice
against the same thread-local Isabelle home. The concurrent writers invalidated
only `target/isabelle-home-drp1-fast`; source files and shared dependency heaps
were unaffected. Subsequent integration work uses a separate physical copy of
the clean Com home and a single writer. System memory at the checkpoint was
129 GiB used of 3 TiB.

## 2026-08-12 Certified Relative ADP Com Reduction Pairs

The complete semantic, checker, parser, and Ferrum CPF path for the IJCAR 2024
Com reduction-pair processor was verified in isolated sessions. The focused
Rust gate was:

```text
cargo +1.95.0-x86_64-unknown-linux-gnu test --lib relative_adp --jobs 32
```

All 12 relative-ADP tests passed. Ferrum generated the retained real witness
with:

```text
target/debug/ferrum prove \
  /work/dfm/festschrift/TPDB-ARI/TRS_Relative/Relative_05/rt2-2.ari \
  --strategy relative-adp \
  --utility-guidance-manifest target/rt2-2-com-guidance.jsonl \
  --no-top-level-llm \
  --cpf target/relative-adp-com-certified-smoke/rt2-2-com.cpf.xml \
  --cpf-mode cpf30
```

The resulting XML is well formed and contains two
`relativeAdpComReductionPair` nodes, each with total `adpCom0` and `adpCom2`
interpretations. The guidance manifest is untrusted processor-order evidence;
the generated checker validates the complete proof independently.

The authoritative CeTA replay and negative mutation are retained beside the
CPF as `ceta-valid.{out,err}` and `ceta-invalid-com-law.{out,err}`. The invalid
copy replaces the second argument of the first `adpCom2` interpretation by
zero, violating the checked right-projection law; CeTA must reject it.

## 2026-08-13 Relative ADP Com Production Replay

The rebuilt production checker at
`/work/dfm/festschrift/CeTA-CSR-relative-adp/ceta` was run on the 11 official
TRS Relative examples for which retained processor events showed polynomial
Com progress. The isolated `relative-adp` strategy produced four CeTA-certified
proofs:

| Example | Com reduction-pair nodes |
| --- | ---: |
| `AProVE_24/lessleaves.ari` | 1 |
| `AProVE_24/shuffle_a.ari` | 3 |
| `Relative_05/rt2-2.ari` | 2 |
| `Relative_05/rt2-3.ari` | 4 |

The focused result was 4 certified YES, 4 MAYBE, 3 timeout, and zero
certification failures. Proofs, checker output, processor events, and timings
are retained in:

```text
target/termcomp-runs/20260813-relative-adp-com-progress11-8x60s
```

The older 24-example `relative-adp-move-probe-20260811-v2` raw-YES list was
also replayed. It yielded 0 YES, 20 MAYBE, and 4 timeout. Those historical
proof trees contain dependency-graph and empty nodes rather than Com nodes, so
they are graph-search history rather than the correct Com benchmark. Its
replay is retained in
`target/termcomp-runs/20260813-relative-adp-com-certified-raw24-8x60s`.

A full official 126-example run with the current default strategy gave 11
certified YES, 3 certified NO, 108 MAYBE, and 4 timeout, with no certification
failures. Complete artifacts are in
`target/termcomp-runs/20260813-trs-relative-full-com-certified-8x60s`.

This is a strategy-integration diagnostic, not a replacement for the 45/13
baseline. On all four focused Com successes, the nested default relative race
consumed the budget in recursive transformation branches without recording a
`relative-adp` attempt. The isolated atom closes each proof immediately. The
default race must give `relative-adp` its independent configured budget before
the official aggregate is rerun.

## 2026-08-11 TRS Innermost exact-state parity

Five focused evidence groups added exact `constantToUnary`, dependency-pair,
graph, usable-rule, innermost-LHS, transformational-DP, reduction-pair, and
conditional general-reduction-pair transitions.  The final composition-free
v851 oracle re-enters guidance at every returned residual and gives:

```text
focused recoveries:  10/10 YES, 10/10 CERTIFIED
v771 parity roots:     8/8 YES,   8/8 CERTIFIED
full TRS Innermost:  226 YES + 7 NO, all 233 CERTIFIED
certification failures: 0
v771 certified-root losses: 0
new certified roots over v771: 12
```

Every focused CPF was checked twice by
`/work/dfm/festschrift/CeTA-CSR/ceta`.  No CeTA changes were required.  The
artifacts and the consolidated oracle are in
`target/innermost-five-items-20260811`, especially
`oracle-v851-parity.jsonl`, `all-ten-v851-summary.md`, and
`full-strict-v851-summary.md`.

Against AProVE25_cert's 261 YES plus seven NO, 36 certified AProVE roots remain
outside the replayed intersection.  Their proof corpus is dominated by deep
combinations of argument-filtered RPO/KBO or matrix/polynomial deletion with
semantic labeling, splitting, narrowing, rewriting, and instantiation.  The
next strengthening targets are therefore complete exact extraction for those
deep chains, broader argument-filtered order witnesses, and residual-stable
semantic-label/split transformations; no additional checker feature is known
to be required for their existing CPF3 proofs.

### Consolidation into the global oracle

The v851 Innermost evidence was merged over the composition-free global v835
oracle with its independently certified ordering retained on touched exact
states.  Compact oracle metadata rows are preserved by the monotone merge
tool instead of being mistaken for malformed guidance records.  The resulting
candidate and its verification artifacts are:

```text
target/oracle-integration-global-innermost-v851-20260811/
  oracle-global-v854-innermost233-promoted.jsonl
  oracle-global-v854-innermost233-promoted-report.json
  full-strict-v854-summary.md
  csr108-strict-v854-summary.md
  trs-relative-strict-v854-summary.md
```

Strict oracle-only replay with fallback and top-level LLM disabled preserves
all three checked category baselines: TRS Innermost has 226 certified YES and
seven certified NO, CSR has 94 certified YES and four certified NO, and TRS
Relative has 45 certified YES and 13 certified NO.  All three runs have zero
certification failures.  No CeTA change was required.

## 2026-08-13 Consolidated Relative replay

The certified TRS Relative-ADP implementation and SRS Relative custom matrix
evidence were integrated over v854.  The monotone promoted union is:

```text
target/oracle-integration-global-relative-v869-20260813/
  oracle-global-v870-relative-wins.jsonl
  oracle-global-v870-relative-wins-report.json
```

Strict fallback-disabled replay with the integrated production checker gives:

```text
TRS Relative:   45 YES + 13 NO, all 58 CERTIFIED
SRS Relative:   98 YES, all CERTIFIED (current 461-root TPDB set)
CSR:            94 YES + 4 NO, all 98 CERTIFIED
TRS Innermost: 226 YES + 7 NO, all 233 CERTIFIED
certification failures: 0 in every category
```

The four custom SRS matrix roots (`r5`, `r6`, `r10`, and `dup03`) replay 4/4
through the global oracle.  The explicit native Relative-ADP route separately
replays `lessleaves`, `shuffle_a`, `rt1-3`, `rt2-2`, and `rt2-3` as 5/5
certified proofs containing the expected `<relativeAdp...>` nodes.  Artifacts
are the category summaries and run directories under the v870 directory.

CeTA-CSR commit `731ed9a` integrates the verified Relative-ADP checker while
preserving the ordinary CeTA command-line interface used for separate input,
property, answer, and proof fragments.  `make test-relative-adp`, all 690 Rust
library tests, and all 163 Python tests pass.
## Native innermost CSR active-SCT boundary

Native innermost CSR-DP states may use the existing size-change processor
without asserting global minimality when every active argument of every target
is an active proper subterm of the corresponding marked source.  Ferrum checks
this condition before scheduling SCT and again while retaining the proof;
CeTA-CSR has an independent executable check backed by a soundness theorem.

The positive regression `f#(s(X)) -> f#(X)` with both arguments active closes
by one SCT graph.  The Ex3-shaped pair
`sel#(s(X),cons(Y,Z)) -> sel#(X,Z)` is a mutation-negative guard: `s` and
`cons` are frozen, so neither target variable is source-covered and the
shortcut is rejected.  This deliberately does not claim to solve
`CSR_04/Ex3_2_Luc97`; that example still needs a source-restricted reduction
pair or another certified RTA08 continuation.

The reconstruction boundary now drops projection rules that were used only
while searching the native innermost problem.  Retaining them in
`auxiliaryRules` selected CeTA's older auxiliary-rule checker and bypassed the
new active-SCT/RTA08 dispatcher.  The corrected CPF is generated from the
original CSR rules, was accepted twice by the isolated generated checker, and
its frozen-argument mutation was rejected.  The focused regression
`native_active_sct_reconstructs_without_search_only_auxiliary_rules` guards
this exact runtime/CPF correspondence.

## 2026-08-11 state-local DP recipe restoration

The universal-worklist refactor had left a replay integration defect: the
top-level parser rejected composed `dp(...)`, `csr-*-dp(...)`, and
`csr-gm-transform(...)` atoms, while the DP scheduler ignored an explicit
continuation after the transformation materialized its child.  Consequently,
certified oracle evidence could select the correct transformation but lose the
known continuation at precisely the residual state where it was applicable.

These recipes are executable again without hiding residual obligations.  The
parser stores the nested `DpStrategy` in the top-level atom; the transformation
copies it into the materialized `DpProblemState`; and every later DP residual
uses the same state-local scheduler.  GM reconstruction converts the completed
DP tree back into an ordinary DP proof before wrapping it in the certified GM
CSR transformation.  Focused tests inspect the materialized ordinary, improved
CSR, and GM DP children and verify that the exact recipe is retained.

Production certification checks:

- `CSR_04/Ex1_Luc02b.ari` with
  `csr-improved-dp(graph;size-change)` produced
  `target/restored-recipes-smoke-20260811/ex1-proof.xml`, accepted twice by
  `/work/dfm/festschrift/CeTA-CSR/ceta`;
- `Maude_06/LengthOfFiniteLists_complete.ari` with an explicit GM DP recipe
  produced `target/restored-recipes-smoke-20260811/length-gm/proof.xml`, also
  accepted twice by the production checker.

The full library run reported 684 passes and one transient persistent-Z3
`BrokenPipe`; the failed test passed three consecutive isolated reruns.  There
were no CSR, DP, reconstruction, or CPF failures.

## 2026-08-11 compact-oracle and complete-recipe repair

The current v836 oracle contains 36 shared witness rows and 80
`candidate_ref` uses.  Ferrum's loader and the monotone Python exporter now
resolve these references independently of row order, reject missing or
conflicting witnesses, and re-emit long candidates through deterministic
SHA-256 witness identifiers.  This fixes the defect that previously made the
strongest oracle unreadable as soon as compact exact-model evidence appeared.

A strict 108-root CSR measurement of unmodified v836 produced 87 certified
YES and four certified NO, with zero checker failures.  Seven formerly
certified roots had regressed because atomization reached a residual state
whose current serialization was not aliased.  The first corrected case is
`Maude_06/csrdiv`: explicit DP sequences now advance their continuation on
each residual instead of restarting the whole sequence, and certified-proof
extraction retains both the independently keyed child actions and the exact
complete root recipe.  Complete solved recipes rank ahead of open root
transformations; state-first child guidance remains available underneath.
The strategy language keeps its historical distinction: a plain semicolon
sequence is a recursive portfolio, while `pipeline(...)` advances exactly
once through residual states.  This preserves the certified GM proof for
`LengthOfFiniteLists_complete` while preventing csrdiv's pipeline from
restarting its instantiation stage.

The v837 csrdiv export preserves all 301,292 v836 state records, adds one live
root record and 12 certification-gated positive state/action rows, and rejects
zero uncertified positives.  Strict replay used `--strategy fail`,
`FERRUM_DP_LLM_NO_FALLBACK=1`, and `--no-top-level-llm`; it terminated in 2.0
seconds and the resulting CPF was accepted twice by the production
`/work/dfm/festschrift/CeTA-CSR/ceta`.

Artifacts:

- v836 strict baseline:
  `target/csr-strict-v836-recipes-20260811-{summary.md,details.json}`;
- extraction, credited SQLite, export report, and strict replay:
  `target/csrdiv-continuation-integration-20260811`;
- promoted oracle:
  `target/csrdiv-continuation-integration-20260811/oracle-global-v837-csrdiv-recipe.jsonl`.

The same audit recovered `Maude_06/OvConsOS_complete-noand`.  Its certified
CPF is a strictly linear chain of eight context-sensitive rule removals (seven
exact polynomial witnesses and one exact matrix witness).  Top-level runtime
events record those residual-local actions separately, so the extractor now
also synthesizes their semicolon sequence at the root only when every proof
node is a uniquely nested `csrRuleRemoval`; branching, gaps, and mixed
processors are rejected.  Ferrum executes this certified sequence as one
checked processor, requiring one residual after every witness and an empty
final system before reconstructing the composed proof.

The monotone v841 export contains 301,314 records, promotes nine positive
rows, and rejects zero uncertified evidence.  Strict oracle-only replay closed
`OvConsOS_complete-noand` in 2.1 seconds, and the generated CPF was accepted
twice by the production CeTA-CSR checker.  Artifacts are in
`target/ovcons-complete-noand-integration-20260811`; the promoted oracle is
`oracle-global-v841-ovcons-complete-noand.jsonl` in that directory.

The complete 108-root strict v841 replay then produced **90 certified YES and
4 certified NO (94/108)**, with 14 MAYBE and zero timeout, error, or checker
failure.  It completed in 18 seconds with 64 prover processes and two Rayon
threads per prover.  Reports and per-root artifacts are
`target/csr-strict-v841-linear-recipes-20260811-{summary.md,details.json}` and
`target/termcomp-runs/csr-strict-v841-linear-recipes-20260811`.

Verification comprised 67 focused Python tests and 690 Rust library tests.
The library run had one transient persistent-Z3 closed-stdout failure; the
same test passed three consecutive isolated reruns.  No CSR, oracle,
reconstruction, or CPF test failed.

The next current-default frontier replay found three further complete proofs:
`MYNAT_complete-peanoSimple`, `PALINDROME_complete`, and `morse`.  All three
source CPFs passed two production CeTA-CSR checks.  Their v842 overlay promoted
20 certified rows, rejected zero uncertified positives, and each root then
replayed strictly with fallback disabled.  The complete v842 CSR replay was
**93 certified YES and 4 certified NO (97/108)**, with 11 MAYBE and no timeout,
error, or checker failure.  Artifacts are
`target/csr-v841-remaining-default-20260811-*`,
`target/csr-strict-v842-three-roots-20260811-*`, and
`target/oracle-global-v842-three-csr-roots-20260811.jsonl`.

`MYNAT_complete-noand` was then recovered from its archived v450 strict proof.
Recursive extraction rebased 51 proof events onto the current runtime states;
the v843 export promoted 14 certification-gated rows and rejected none.  Its
individual strict replay completed and certified in under three seconds.  The
final 108-root v843 measurement is **94 certified YES and 4 certified NO
(98/108)**, with 10 MAYBE and zero timeout, error, or checker failure.  Reports
and artifacts are `target/csr-strict-v843-mynat-recovered-20260811-*` and
`target/termcomp-runs/csr-strict-v843-mynat-recovered-20260811`; the oracle is
`target/oracle-global-v843-mynat-complete-noand-20260811.jsonl`.

## Frozen-recursive CSR subterm production check (2026-08-23)

The isolated Isabelle identifier `codex_csr_frozen_subterm_20260823` reused
the existing dependency heaps. The rebuilt sessions all returned zero:
`CSR_Checker_Extensions` in 110.221 s, `Proof_Checker` in 193.941 s,
`IsaFoR_3` in 417.697 s, and `Code` in 245.150 s. Exporting the generated code
produced 388 Haskell modules; GHC compiled and linked them in 41.233 s. The
fresh checker is
`CeTA-CSR-csr/target/csr-frozen-subterm-code-export-20260823/ceta-csr-frozen-subterm`
(SHA-256 `5751aff405bd2dd9c27916963faa9d156e03f0416b06cd350e5c585740e30c8a`).

The complete `LISTUTILITIES_nokinds` CPF passed twice in 29 ms and 25 ms.
Changing the frozen `and#` root projection to its active first argument and
removing the required inner `isLNat` collapse were both rejected with
`invalid frozen recursive CSR subterm criterion`. Representative Ex14, Ex6,
and recursive-csrdiv CPFs passed the new checker twice. Ferrum verification
comprised 21 focused subterm tests and 753/753 library tests.

The v994 strict 108-root replay completed with 101 certified YES, four
certified NO, three MAYBE, and no timeout, error, or certification failure. A
separate parallel second pass accepted all 105 retained CPFs. Full artifacts,
including the checker recheck ledger, are under
`target/csr-listutils-nokinds-frozen-subterm-integration-20260823`.

## Final two-root frontier and bounded instantiation (2026-08-23)

The clean v1000 checkpoint remains **102 certified YES plus four certified
NO (106/108)**.  The only open roots are `CSR_04/Ex5_7_Luc97.ari` and
`Maude_06/OvConsOS_nokinds.ari`; both also remain unsolved in the published
TermCOMP 2026 table.  Focused residual exploration is under
`target/ex5-focused2-20260823`, `target/ex5-singleton-20260823`, and
`target/ovcons-min15-20260823`.

For Ex5, the first hard improved-CS-DP component contains
`quote#(s(X)) -> quote#(X)`.  Its apparent descent lies below the frozen
argument of `s`; active-subterm and frozen-recursive-subterm certification
therefore both reject it.  Affine U3 polynomial constraints are genuinely
unsatisfiable, dimensions 2 through 5 of the componentwise natural matrix
processor fail, and an exact hand-built path-order filter still leaves two
weak-rule failures.  These are semantic/order-strength gaps rather than a
larger-bound issue.

For OvConsOS, two top-level rule removals expose a 15-rule residual. Improved
CS-DPs and graph decomposition produce a large SCC that is completely
closable by matrix deletion, graph recomputation, subterm deletion, and final
graph checks, plus a hard two-pair `length#/U11#` SCC.  Treating the frozen
list tail as an unconditional descent would be unsound: the source contains
`zeros -> cons(0,zeros)`, and the membership test is precisely what prevents
the false infinite chain.  The published analysis of OvConsOS likewise
identifies its sort check as essential.  The next sound processor therefore
needs to retain and certify that guard information (for example, a typed/GTRS
dependency-pair or equivalent semantic-labeling criterion), not weaken the
existing subterm checker.

The same exploration exposed a generic worklist defect.  Forward
instantiation previously used `require_graph_progress` both for graph-score
filtering and for bounding recursive transformation depth.  Attaching a
continuation disabled both, allowing successively larger Ex5 states until the
deadline.  `ForwardInstantiationProcessor` now has an independent
`require_depth_bound`: generic continuations remain depth-bounded, while an
explicitly selected oracle candidate remains replayable.  The focused Ex5
chain now tries its two parent candidates and stops instead of growing from 25
to 29 pairs.  Both regression tests and all 756 Rust library tests pass.

## Guarded CSR SCT theorem and OvCons transformation probe (2026-08-23)

CeTA-CSR commit `2332fe8` generalizes the CSR SCT correctness theorem by
separating the selected-subterm graph condition from the semantic obligation
that the corresponding chain instances are strongly normalizing.  The old
active-position SCT processor is derived unchanged as a corollary.  An
isolated `CSR_Checker_Extensions` build reused `CSR_Checker_Core` and passed in
2m25s; no HOL or AFP session was rebuilt.

This theorem alone does not accept a frozen proper-subterm edge: its current
measure still uses `mu_supt`.  The executable follow-up must additionally
provide a well-founded guarded measure for that edge; source-term SN by itself
would be insufficient because frozen descent can alternate with CSR steps.

The hard OvCons component still retains its relevant guard.  Its two pairs are
the `U11#(tt,L) -> length#(L)` continuation and the
`length#(cons(N,L)) -> U11#(and(isNatList(L),isNat(N)),L)` call.  Consequently
the next executable checker must validate the guarded transition rather than
accept a bare frozen-tail descent.

As an independent alternative, the root GM transformation was explored under
`target/ovcons-gm-root-20260823`.  It reduces the transformed ordinary DP
problem to two pairs over 43 rules, but the default 60-second portfolio and
separate 3D natural and Arctic matrix probes do not close it.  This confirms
that the transformation route is sound but is not yet a shortcut around the
guarded residual.

## Exact semantic-CSR continuation boundary (2026-08-23)

Ferrum commit `53d49ca` fixes a state-plumbing error after certified finite
semantic labeling.  CeTA's `check_csr_dp_ordinary_min` deliberately passes the
labeled child to the ordinary, nonminimal DP checker.  Ferrum retained the
source CSR as reconstruction metadata, but previously also reused it for
processor applicability and retained `minimal=true`.  Consequently an
independently replayed child could incorrectly enter CSR-specific U3,
instantiation, and subterm paths instead of the exact ordinary obligation.

The child now round-trips as ordinary and nonminimal while preserving the
source CSR only for reconstruction of the enclosing semantic-labeling proof.
Focused boundary tests and the complete Rust library suite pass (765/765).
The corrected retained OvCons labeled SCC was reprobed with polynomial,
quadratic-polynomial, 3D natural-matrix, 3D Arctic-matrix, and path-order
processors under 60-second local ceilings.  None closes the two-pair ordinary
overapproximation: in particular, its labeled rule component still contains
the productive `zeros -> cons(0,zeros)` behavior.  The certified CSR high-water
mark therefore remains 106/108; this fix removes replay drift but does not
replace the guarded typed/rank processor needed for OvCons.

CeTA-CSR commits `fbdb726` and `8f37f92` establish the next processor's
well-founded three-sort rank foundation and executable symbolic rank forms in
an isolated child session.  After the one-time parent heap materialization,
the child theory checks in 7--11 seconds (about 25--29 seconds including
Isabelle startup), without rebuilding HOL or AFP.

## Guarded OvConsOS production certification (2026-08-24)

`TRS_Contextsensitive/Maude_06/OvConsOS_nokinds.ari` now has a complete
self-contained proof. A polynomial CSR rule-removal step exposes the 15-rule
residual; improved LPAR'08 CS-DPs and dependency-graph decomposition then
close five components with the existing matrix, U3, subterm, and graph
processors. The remaining two-pair `length#`/`U11#` component is discharged
by the verified guarded-list rank checker.

The guarded proof language is recursive and preserves the improved-CS-DP
context across every graph component. Existing processor fragments are
therefore checked with improved-CS-DP semantics (including U3), rather than
being reinterpreted as nonminimal ordinary DP proofs. The fresh unhiding
symbol is explicit in the CPF and is revalidated by CeTA-CSR.

The checked-in default strategy produces the 129 KiB CPF in under one second:
`target/ovcons-guarded-default3-20260824/proof.cpf.xml`. Isabelle sessions
`CSR_Guarded_List_Measure_Check`, `Proof_Checker`, `IsaFoR_3`, and `Code` all
passed in the isolated `codex_csr_production_20260824` output directory. The
366-module generated Haskell checker compiled successfully, and the installed
production checker accepted the CPF twice. A truth-symbol mutation was
rejected. The category high-water mark is not updated here until the complete
strict oracle-only 108-root replay has incorporated this proof.

## Argument-filter-dependent path-order usable rules (2026-08-24)

Path-order replay already recomputed and exactly checked the usable-rule
closure induced by its argument filter, but fresh SMT synthesis still required
every input rule to be weak unconditionally. This prevented the solver from
discovering filters whose retained positions deliberately make a productive
rule unreachable. The path-order encoding now synthesizes the same symbolic
usable-root closure as the KBO encoding, while fixed-rule and strict-rule
contexts retain their full obligations. The parsed model is independently
validated using Ferrum's CeTA-style exact closure before a proof is built.

A regression combines a strictly decreasing marked pair with a productive
`from(x) -> cons(x,from(s(x)))` rule which cannot be weakly oriented by a
simplification order. Synthesis now collapses the marked root, obtains the
empty usable-rule set, and deletes the pair. All 17 path-order tests and the
complete 768-test Rust library suite pass. This general completeness repair
does not by itself close `CSR_04/Ex5_7_Luc97`: its direct improved-CS-DP state
has a fixed U3 rule obligation, and its surviving GM residuals need an
additional order or transformation.

## Ex5_7_Luc97 final-root order audit (2026-08-24)

The strict CSR oracle replay remains 103 certified YES plus four certified NO
(107/108). The sole open root is `CSR_04/Ex5_7_Luc97.ari`. Focused checks in
`target/ex5-7-luc97-last-root-20260824` establish these boundaries:

- the hard improved-CS-DP singleton is exactly
  `quote#(s(X)) -> quote#(X)` over the 17 source rules;
- polynomial, natural-matrix, Arctic-matrix, KBO, path-order, QCS usable-rule,
  rewriting, narrowing, instantiation, and forward-instantiation probes do not
  refine or close that singleton;
- root context-sensitive natural-matrix searches at dimensions 2 through 6
  and coefficient bounds through 7 are inapplicable; and
- the standard GM and innermost iGM variants retain respectively a 31-pair and
  a 26-pair cyclic residual, while the L and FR transformations are genuinely
  nonterminating and therefore cannot certify the source CSR.

The MU-TERM literature explains the affine obstruction on the shared
`from`/`sel` subsystem: its direct context-sensitive polynomial witness uses
fractional and mixed nonlinear coefficients (notably a term proportional to
`X^2*Y`), and CSRPO instead uses a marking map. A 60-second rational
degree-two synthesis check over the complete source-rule obligation found no
witness. Thus the remaining gap is not a larger affine or matrix bound. The
next sound implementation target is a certifiable context-sensitive recursive
path order (or an equivalent marking/type-introduction processor), followed by
an exact Ex5 regression; weakening frozen descent or dropping source rules
would be unsound.

## Ex5_7_Luc97 CSRPO audit (2026-08-24)

Ferrum has an executable implementation of the multiset/lexicographic CSRPO
comparison and marking-pair conditions from Borralleras--Lucas--Rubio, plus an
incremental QF_LIA witness synthesizer.  It reproduces the paper's
`from`/`sel` example, including the required mark below the frozen second
argument of `cons`, and independently replays every solver model.

An initial Ex5 candidate exposed a validator defect before any evidence was
promoted: the safe-variable test admitted equal-precedence lexicographic
heads.  CSRPO permits the equal-precedence case only when both extended
symbols have multiset status (with equal marking); the lexicographic case must
use strict precedence.  Synthesis and concrete validation now enforce that
condition and assign status independently to original and marked symbols, as
required on the extended signature.  The corrected 17-rule Ex5 query is
unsatisfiable in this CSRPO fragment.  Therefore no CSRPO proof or oracle entry
is claimed for Ex5, and the certified replay remains 107/108.

## Ex5_7_Luc97 filtered-WPO closure and 108/108 replay (2026-08-25)

The final root was closed through its already certified GM transformation.
NaTT's successful internal WPO models revealed that the remaining singleton
components use collapsing argument filters, especially `mark(x) -> x`. Its
temporary CPF printer had flattened that collapse into an ordinary singleton
WPO status, which is not the same order and was correctly rejected by CeTA.
Ferrum now represents the filter independently, applies it before exact WPO
validation on every pair and rule, and serializes the standard CPF3
`filteredRedPair` wrapper around `weightedPathOrder`.

The complete producing proof is
`target/ex5-gm-filtered-wpo-root-20260824/proof.cpf.xml`. It contains GM
transformation, dependency-graph decomposition, one exact max-polynomial
deletion, another graph split, four filtered WPO(Max) singletons, and one
max-polynomial singleton. Two independent invocations of
`/work/dfm/festschrift/CeTA-CSR/ceta` returned `CERTIFIED`.

`extract_local_cpf_oracle_events.py` materialized 205 observations over 12
distinct current proof states under
`target/ex5-gm-filtered-wpo-oracle-20260824`. The credited ledger was built
with `--canonicalize-inputs` and the production Ferrum canonicalizer. This is
required because a newly reconstructed GM child uses fresh generated names;
the canonical database and its 23 raw aliases connect that live spelling to
the archived structural state without transporting an exact witness to an
unrelated problem.

Oracle v1002 is
`target/ex5-gm-filtered-wpo-oracle-20260824/oracle-global-v1002-ex5-canonical.jsonl`
(SHA-256
`432bbf1936ef62d3a565ee0f5bc8e465608bab963b079f2420605bfb7539917c`).
The exporter promoted 16 certified positive state/action rows, retained 184
weak transformation hints, and rejected two uncertified automatic `empty`
events.

A strict focused replay first verified the final root. The subsequent complete
TermCOMP 2025 context-sensitive replay used `timeout(60s, fail)`,
`--no-top-level-llm`, and `FERRUM_DP_LLM_NO_FALLBACK=1`. Its summary, details,
and per-root artifacts are respectively:

```text
target/ex5-gm-filtered-wpo-oracle-20260824/csr108-strict-v1002-summary.md
target/ex5-gm-filtered-wpo-oracle-20260824/csr108-strict-v1002-details.json
target/termcomp-runs/csr108-strict-v1002-ex5-20260825
```

The result is 104 certified YES plus four certified NO, **108/108**, with no
MAYBE, timeout, error, or certification failure. Replay took 15 seconds. A
second independent production-checker pass accepted every one of the 108
generated CPFs; its audit is
`target/ex5-gm-filtered-wpo-oracle-20260824/second-ceta-recheck-v1002.json`.

Verification also includes 139 focused Python extraction/dataset/export
tests, a clean 772/772 Rust library suite repeat (the preceding run's single
persistent-Z3 broken-pipe failure passed immediately in isolation), the
filtered-WPO positive/negative regression, release and debug builds, and
`git diff --check`. No CeTA-CSR source change was required.

### Minimal live-state refreeze (v1005)

An applicability audit of the v1002 replay found five successful non-empty
states whose processors were supplied by explicit parent continuations rather
than an independent oracle lookup. Four belong to
`Maude_06/LISTUTILITIES_complete.ari`; the fifth is Ex5's post-GM DP state.

A broad first refreeze was deliberately rejected after executable validation:
it ranked reconstructed `exact-*` variants ahead of the certified generic
graph/instantiation/subterm actions. Those variants produced equivalent but
differently serialized children, and LISTUTILITIES exhausted its graph budget
while backtracking. The corrected v1005 refreeze starts from v1002 and adds
only the six observed actions at the five missing live keys. This preserves
the modular certified path instead of importing a whole-proof continuation.

The final oracle is
`target/csr108-live-refreeze-v1003-20260825/oracle-global-v1005-minimal-generic.jsonl`
(SHA-256
`184fc5c17996d98b2f186971c7f8edd55b29934df74926116c232e33af6c6cc6`).
Its strict 64-worker replay artifacts are:

```text
target/csr108-live-refreeze-v1003-20260825/csr108-strict-v1005-summary.md
target/csr108-live-refreeze-v1003-20260825/csr108-strict-v1005-details.json
target/termcomp-runs/csr108-strict-v1005-minimal-generic-20260825
```

The run finished in 10 seconds with 104 certified YES and four certified NO,
zero MAYBE/timeouts/errors/checker failures, and fallback disabled. A second
production-CeTA pass accepted 108/108 CPFs. The final applicability audit
reports 104/104 terminating roots and 444/444 nontrivial successful nested
states with positive guidance and zero missing/actionable states. Static
applicability remains a necessary check; the failed broad refreeze confirms
that only a complete strict replay validates candidate ranking and recursive
child identity.

### CSR exact-witness ablation and learned default portfolio (2026-08-25)

The 110-root oracle was replayed after removing every `exact-*` candidate.
Generic state-local guidance alone certified 89 YES and five NO, **94/110**,
with zero rejected certificates. Although 99 successful full-oracle traces
mention at least one exact atom, only the following 16 roots fail the strict
executable ablation: `Ex1_GM03`, `Ex3_2_Luc97`, `Ex4_7_37_Bor03`,
`Ex5_7_Luc97`, `ExIntrod_Zan97`, `LISTUTILITIES_complete-noand`,
`LISTUTILITIES_complete`, `LISTUTILITIES_nokinds-noand`,
`LengthOfFiniteLists_complete`, `MYNAT_complete-noand`,
`MYNAT_complete-peanoSimple`, `OvConsOS_complete-noand`,
`OvConsOS_complete`, `PALINDROME_complete-noand`, `csrdiv`, and `emmes`.
The ablated oracle and replay are:

```text
target/csr110-oracle-no-exact-20260825.jsonl
target/csr110-oracle-no-exact-20260825-summary.md
target/csr110-oracle-no-exact-20260825-details.json
target/termcomp-runs/csr110-oracle-no-exact-20260825
```

`scripts/learn_oracle_time_budgets.py` derives processor-family budgets from
successful events belonging to certified roots. It buckets states by
`pairs + rules` and refuses headroom below 20%. The retained measurement is
`target/csr110-oracle-learned-budgets-20pct-20260825.json`. The largest
observed graph validation was 1.730s, hence the early structural CSR lanes use
a three-second allowance. Search lanes receive deliberately larger 10s/20s
allowances, split at 64 source rules, because witness synthesis is more
expensive than replay validation.

The resulting staged default CSR portfolio certifies 89 YES and five NO,
**94/110 without oracle guidance**, up from 76 YES plus five NO. There are no
CeTA rejections. Its artifacts are:

```text
target/csr110-main-default-learned-v8-20260825-summary.md
target/csr110-main-default-learned-v8-20260825-details.json
target/termcomp-runs/csr110-main-default-learned-v8-20260825
```

Legacy automatic RTA'08 and innermost-RTA'08 fallbacks were removed from the
default race after staging made their checker-boundary failures reproducible.
They remain explicitly selectable, but cannot preempt the certification-clean
default portfolio.

### Innermost default-strategy expansion (2026-08-26)

A fresh 32-worker, 60-second-prover baseline over all 366 TPDB-ARI
`TRS_Innermost` roots certified 159 YES and two NO results. The revised
Innermost strategy adds a graph-first DP lane whose components race SCT,
subterm, bounded polynomials, weak polynomials, and 2D matrices, followed by a
second graph decomposition. A bounded repeated polynomial-removal ladder is
raced alongside it. The transformed-CSR dispatch uses the new work only for
small (at most 21 rules) or large (at least 60 rules) residuals, with the small
retry capped at two seconds. The existing context-sensitive strategy and CSR
processors are unchanged.

The final replay certified 169 YES and two NO results, **171/366**, with ten
new certified roots and no baseline loss. CeTA rejected no certificate. The
baseline and final artifacts are respectively:

```text
target/innermost-strategy-20260826/baseline-default-r1-summary.md
target/innermost-strategy-20260826/baseline-default-r1-details.json
target/innermost-strategy-20260826/improved-final-default-r24-summary.md
target/innermost-strategy-20260826/improved-final-default-r24-details.json
target/termcomp-runs/innermost-improved-final-default-r24-20260826
```

Strict oracle-only CSR regression with fallback disabled retained all 110
results (105 certified YES, five certified NO) in 43 seconds:

```text
target/innermost-strategy-20260826/csr110-regression-r25-summary.md
target/innermost-strategy-20260826/csr110-regression-r25-details.json
target/termcomp-runs/csr110-innermost-strategy-regression-r25-20260826
```

The production release build, strategy parser/dispatch tests, all 779 release
library tests, and `git diff --check` passed.

### Innermost default-proof oracle integration (2026-08-26)

The ten default-strategy gains above were extracted as 141 root and recursive
processor events from complete CPFs. Production CeTA rechecked all ten proofs
twice before export. The credited corpus contains 141 canonicalized
observations over 83 distinct CPF states; no run failed the stale-state quality
scan. One automatic empty-state observation without an independent
certification gate was correctly rejected rather than promoted.

The monotone v1143 oracle adds 93 records to v1142 and has SHA-256
`6e1ca0af42c1f869117efbcf125560438e4a6885b75e9697f4e83aefdc90dda3`:

```text
target/innermost-campaign-20260826-default-gains/oracle-v1143-default-gains-r3.jsonl
target/innermost-campaign-20260826-default-gains/oracle-v1143-default-gains-r3-report.json
```

A targeted strict replay certified all ten producing roots. The subsequent
complete 16-worker strict replay, with both top-level and DP fallback disabled,
certified 233 YES and seven NO results, **240/366**, with 126 MAYBE and zero
timeouts, errors, losses, or checker failures. It completed in 121 seconds:

```text
target/innermost-campaign-20260826-default-gains/innermost366-strict-v1143-r5-summary.md
target/innermost-campaign-20260826-default-gains/innermost366-strict-v1143-r5-details.json
target/termcomp-runs/innermost366-strict-v1143-r5-20260826
```

The subsequent oracle-plus-default replay of all 126 unresolved roots produced
no additional certified result: 98 returned MAYBE and 28 reached the harness
deadline. Its summary and details are
`target/innermost-campaign-20260826-default-gains/unresolved126-oracle-fallback-v1143-r6-{summary.md,details.json}`.

Four manually documented Innermost roots were absent from the v1143 strict
result. Three retained terminating CPFs were production-CeTA checked twice and
their recursive processor states were merged with the live states exposed by
a strict replay. The first import exposed an unsafe pooling boundary: an exact
forward-instantiation fragment and a subterm projection were offered to a
sibling DP residual, yielding a positive-looking assembled CPF that CeTA
rejected. It was not promoted. Root-local pooling now excludes exact DP
transformations and exact subterm projections unless structural state matching
places them at their original obligation; complete producing root recipes are
retained in addition to the independently indexed children.

The context-safe v1149 replay returned no checker failure and newly certified
`Transformed_CSR_innermost_04/Ex9_BLR02_C.ari`. Its current proof was checked
twice more and refrozen as v1150. The oracle has SHA-256
`919f34b4e57b115377b7681d6a87b280efd5c01b652a87921d70e291b7e85a8d`:

```text
target/innermost-campaign-20260826-default-gains/oracle-v1150-ex9-current-refreeze-r28.jsonl
target/innermost-campaign-20260826-default-gains/oracle-v1150-ex9-current-refreeze-r28-report.json
```

The complete 16-worker strict replay certified 234 YES and seven NO results,
**241/366**, with 124 MAYBE, one timeout, and zero errors, certification
failures, or formerly certified losses. The timeout is the still-unresolved
`Ex5_DLMMU04_iGM`; `ExIntrod_GM01_iGM` safely remains MAYBE. Artifacts are:

```text
target/innermost-campaign-20260826-default-gains/innermost366-strict-v1150-r30-summary.md
target/innermost-campaign-20260826-default-gains/innermost366-strict-v1150-r30-details.json
target/termcomp-runs/innermost366-strict-v1150-r30-20260826
```

Verification includes 159 focused extraction, dataset, export, and monotone
merge tests, all passing, plus `git diff --check`.

### AProVE-certified Innermost parity campaign (2026-08-26)

The official TermCOMP 2025 AProVE table has 268 certified decisions among the
366 Innermost inputs. Compared with strict oracle v1150, its exact additional
frontier contained 27 roots. Their official proof texts and exact benchmark
identities are archived under
`target/innermost-campaign-20260826-aprove-parity/official-cpfs`; production
CeTA-CSR accepted every one twice.

Importing only the foreign proof trees did not make the roots replayable. The
first extraction exposed a root-identity defect (`proof.cpf.xml` was used in
place of the original `.ari` path); after correcting the metadata, exact
usable-rule steps exposed live residual states absent from the foreign traces.
Three bounded oracle-plus-DP materialization rounds rebuilt those residual
chains with current Ferrum. One early positive-looking `Ex1_GM99_iGM` proof
was checker-rejected and excluded. A different proof found in the third round
was accepted and is the retained evidence.

The final v1157 export promoted 841 certified rows and zero uncertified rows.
All nine producing roots first passed a strict focused replay. The complete
16-worker strict replay used `timeout(60s, fail)`, disabled top-level and DP
fallback, and returned 243 certified YES plus seven certified NO results,
**250/366**, with 110 MAYBE, six timeouts, zero errors, zero checker failures,
and zero losses from v1150. It completed in 179 seconds. This closes nine of
the 27-result parity gap and leaves 18 AProVE-certified roots unreplayed.

```text
target/innermost-campaign-20260826-aprove-parity/oracle-v1157-aprove-current9-r56.jsonl
target/innermost-campaign-20260826-aprove-parity/oracle-v1157-aprove-current9-r56-report.json
target/innermost-campaign-20260826-aprove-parity/current9-strict-v1157-r57-summary.md
target/innermost-campaign-20260826-aprove-parity/current9-strict-v1157-r57-details.json
target/innermost-campaign-20260826-aprove-parity/innermost366-strict-v1157-r58-summary.md
target/innermost-campaign-20260826-aprove-parity/innermost366-strict-v1157-r58-details.json
target/termcomp-runs/innermost366-strict-v1157-r58-20260826
```

One of the remaining roots, `ExAppendixB_AEL03_GM`, exposed a more precise
lookup defect. Its certified exact processors applied to the live states, but
the imported child keys differed because CPF rule lists were reordered and
Ferrum's private reconstruction context was present only in the live form.
The complete live chain was recursively materialized, reconstructed as a
self-contained current Ferrum CPF, and accepted twice by production CeTA-CSR.
No temporary alias is retained in the final oracle: v1158 is extracted from
that accepted current proof and independently replays all of its nested states.

The complete v1158 strict replay returned 244 certified YES plus seven
certified NO results, **251/366**, with 109 MAYBE, six timeouts, zero errors,
zero checker failures, and zero losses from v1157. It completed in 179 seconds
and leaves 17 decisions to AProVE's 268-result certified total.

```text
target/innermost-campaign-20260826-aprove-parity/oracle-v1158-aprove-current10-r63.jsonl
target/innermost-campaign-20260826-aprove-parity/oracle-v1158-aprove-current10-r63-report.json
target/innermost-campaign-20260826-aprove-parity/innermost366-strict-v1158-r65-summary.md
target/innermost-campaign-20260826-aprove-parity/innermost366-strict-v1158-r65-details.json
target/termcomp-runs/innermost366-strict-v1158-r65-20260826
```

The next parity recovery, `Ex1_2_AEL03_GM`, exposed the same representation
boundary at greater depth.  Its current-state reconstruction consists of 19
independently applicable typed transitions (reduction pairs, dependency
graphs, usable rules, and size change), rather than a top-level proof replay.
The reconstructed current Ferrum CPF was accepted twice by production
CeTA-CSR.  Temporary structural aliases were then discarded, the accepted
proof was re-extracted, and every nested state became directly findable in
the frozen v1159 oracle.

The complete v1159 strict replay returned 245 certified YES plus seven
certified NO results, **252/366**, with 108 MAYBE, six timeouts, zero errors,
zero checker failures, and zero losses from v1158.  It completed in 180
seconds and leaves 16 decisions to AProVE's 268-result certified total.

```text
target/innermost-campaign-20260826-aprove-parity/oracle-v1159-aprove-current11-r71.jsonl
target/innermost-campaign-20260826-aprove-parity/oracle-v1159-aprove-current11-r71-report.json
target/innermost-campaign-20260826-aprove-parity/ex1-2-strict-v1159-r72-summary.md
target/innermost-campaign-20260826-aprove-parity/ex1-2-strict-v1159-r72-details.json
target/innermost-campaign-20260826-aprove-parity/innermost366-strict-v1159-r73-summary.md
target/innermost-campaign-20260826-aprove-parity/innermost366-strict-v1159-r73-details.json
target/termcomp-runs/innermost366-strict-v1159-r73-20260826
```

## Transformed-CSR Innermost bridge and 280/366 replay (2026-08-27)

After reaching AProVE's 268/366 certified Innermost total, a direct
`switch-csr` probe of the 98 unresolved roots found twelve additional
terminating transformed-CSR systems. Their original default schedule delayed
the switch behind ordinary DP atoms because unguided worklist candidates are
ordered by local atom timeout. The switch only recognizes and materializes a
CSR child; its local budget is not the recursive child's proof budget. The
transformed-CSR Innermost route therefore gives the switch a one-second local
budget while retaining the 60-second root ceiling.

A real checked-in-default replay, without oracle guidance, produced twelve
terminating CPFs in 0.50--6.51 seconds under four-way load, and production
CeTA-CSR accepted all twelve. `extract_local_cpf_oracle_events.py` then checked
each complete CPF twice and reconstructed 154 certified root and nested-state
events over 73 distinct canonical proof states. Exporting these over v1420
produced:

```text
target/innermost-campaign-20260827-beyond-parity/oracle-r20/oracle-v1421-switch-csr-12.jsonl
SHA-256 45d9a96fc4d2e77a240fc7ffb711c370b71e42c3cd8056012c738ea053ef70b5
```

A focused replay with `timeout(60s, fail)`, top-level fallback disabled, and
DP fallback disabled certified 12/12. The complete 64-worker replay then
returned 273 certified YES, seven certified NO, and 86 MAYBE results:
**280/366**, with no timeout, error, checker rejection, or loss from v1420.
An independent extractor audit invoked CeTA-CSR twice on every retained proof;
all 280 passed both checks. Artifacts are under:

```text
target/innermost-campaign-20260827-beyond-parity/default-switch-csr-gains12-r19
target/innermost-campaign-20260827-beyond-parity/strict12-v1421-r21
target/innermost-campaign-20260827-beyond-parity/full-strict-v1421-r22
```

Verification passed 799/799 Rust library tests and 127/127 focused extraction,
oracle-export, and monotone-merge tests. A broader 160-test Python invocation
had 159 passes and one pre-existing semantic-labeling child-count expectation
failure; none of the changed files are Python campaign tooling. Release build,
formatting, and `git diff --check` passed. No CeTA/CeTA-CSR source change was
needed; the production checker remains commit `c03b830` on `main`.

## Portable exact residual bridge and 281/366 replay (2026-08-27)

`Transformed_CSR_innermost_04/LengthOfFiniteLists_complete_noand_iGM.ari`
now reconstructs strictly from independently addressable oracle states. The
certified proof starts with 357 dependency pairs, decomposes into 38 SCCs, and
uses exact one-dimensional natural-Arctic reductions over 154 components,
deleting 221 pairs. The strict replay took 30.708 seconds, attempted no SMT
synthesis, and produced a 29 MiB CPF with SHA-256
`891c7608bee1b3db2e58f48b75d5b71feca7640a5b5e7fa504d4a474b2799dc5`.

The integration fixes a runtime/CPF representation boundary rather than
replaying an archived monolithic proof. Live DP states retain pair-source
provenance in `ferrumDpStateContext`; standard CPF proof nodes do not. Only
self-validating portable exact atoms are indexed by the contextless
mathematical state, and every application checks its source pairs, active
rules, symbol isomorphism, and claimed deletion before returning residuals.
Generic processor guidance remains context-bound. Exact alternatives are
ranked by certified deletion strength to avoid exponential sibling
backtracking. Canonical-cache entries now record a SHA-256 identity of the
canonicalizer implementation, preventing stale-key reuse after an executable
change.

The v1429 oracle is:

```text
target/innermost-campaign-20260827-beyond-parity/oracle-r29/oracle-v1429-length-contextless.jsonl
SHA-256 224414a7c35b6e1f5bab2544786513583787e59e8681faf4c90811e0863dd563
```

A 32-worker full replay with `timeout(60s, fail)`, top-level LLM disabled,
`FERRUM_DP_LLM_NO_FALLBACK=1`, and two Rayon threads per root returned 274
certified YES, seven certified NO, and 85 MAYBE results: **281/366**. There
were zero timeouts, errors, or checker failures and no root loss from v1421.
The independent extractor audit then checked all 281 retained CPFs twice with
`/work/dfm/festschrift/CeTA-CSR/ceta`; all 281 passed both checks.

Artifacts:

```text
target/innermost-campaign-20260827-beyond-parity/length-root-noevents-600s-r68
target/innermost-campaign-20260827-beyond-parity/oracle-r29
target/innermost-campaign-20260827-beyond-parity/full-strict-v1429-r49
```

Verification passed 801/801 Rust library tests, 125/125 focused Python tests,
the release build, and `git diff --check`. No CeTA source change was required;
CeTA-CSR remains commit `c03b830` on `main`.

## Recursive Q-monotonic matrix rule removal (2026-08-27)

Innermost DP matrix atoms now implement CPF3 `innermostMonoRedPairProc` as a
first-class residual processor. A candidate may strictly orient and delete a
rewrite rule even when no dependency pair is strict. Search uses conservative
Q-relevant active positions, exact unbounded-natural replay validates every
live pair and rule, and the residual retains Q and the reduced rule component.
The processor can therefore recur before later graph, reduction-pair, or
size-change processors.

Production CeTA-CSR independently accepted the exact, synthesized, and
two-step recursive artifacts:

```text
target/innermost-qmatrix-exact-20260827-r4/proof.cpf.xml
target/innermost-qmatrix-synth-recursive-20260827-r4/proof.cpf.xml
target/innermost-campaign-20260827-beyond-parity/innermost5-cert-r77/proof.cpf.xml
```

The dependency-pair suite passed 324/324 and the CPF suite passed 137/137.
The two usable-rule tests changed in this work now assert CeTA's exact
pair-local `icap_Q` closure rather than the obsolete broader root-completion
approximation. A five-second generic copy of the recursive lane is included in
the default innermost strategy; after rebuilding the binary it solved the
fixture and certified in under one second without an exact/oracle witness.
`cargo check --lib` and `git diff --check` pass.

## Strict Innermost v1439 replay (2026-08-28)

The recursive Q-monotonic rule-removal integration adds
`Mixed_innermost/innermost5.ari` without losing any v1429 result. Exact
usable-rule children retain the certified active rule universe; recursive
`innermostMonoRedPairProc` nodes are extracted and replayed as typed state
transitions rather than opaque top-level fragments. Forward instantiation
uses that same live R and cannot restore removed rules.

The final complete strict replay is
`target/innermost-campaign-20260828-r30/full-strict-v1439-final`: 275
certified YES, seven certified NO, 84 MAYBE, and no timeout, error, checker
failure, or fallback, for **282/366** certified decisions. The causal oracle
and export report are under
`target/innermost-campaign-20260828-r30/oracle-r39`. Independent twice-per-
proof checking is recorded in
`target/innermost-campaign-20260828-r30/full-strict-v1439-postfix-twice-audit`;
it accepted 282/282 proofs. The final replay CPFs are byte-identical to that
audited set.

Do not use
`target/innermost-campaign-20260828-r30/oracle-r31/oracle-v1431-current-states.jsonl`.
That pooled experiment is checker-rejected and quarantined. v1439 descends
from the clean v1429 oracle through causal, twice-certified proof-chain
materialization only.

## Strict Innermost v1502 replay: 312/366 (2026-08-29)

The complete oracle-only `TRS_Innermost` replay now certifies 304 terminating
and eight nonterminating roots, leaving 54 MAYBE and no timeout, error, fallback,
or checker rejection. Relative to v1494 it adds exactly
`Transformed_CSR_innermost_04/Ex1_2_AEL03_C.ari` and
`Transformed_CSR_innermost_04/ExAppendixB_AEL03_C.ari`, with no loss. Both
strict isolated replays finish in under four seconds.

The root cause was a lossy optimized cycle key for complete-GM04 residuals:
distinct active-rule and weak-pair states collided, suppressing a valid exact
path-order child. The key now includes every mutable residual component. The
proof extractor additionally preserves exact graph and empty-terminal runtime
atoms, content-addressed residual inputs, flat category identities, and
zero-arity replacement-map equivalence. All retained atoms remain tied to and
validated against their exact live state.

Artifacts:

```text
target/innermost-gm04-integration-20260828/oracle-v1502-global-gm04-terminal-children-compact.jsonl
target/innermost-gm04-integration-20260828/full-strict-v1504-two-new-roots
target/innermost-gm04-integration-20260828/full-strict-v1504-two-new-roots-twice-audit
```

The oracle SHA-256 is
`09e23c40898542499433565e2bcba7de5002c2973ce0abf172c0dd0d5d8e8b54`.
The independent audit accepted all 312 proofs twice (624 production-checker
invocations). CeTA `e52c7ce` built through `Proof_Checker`, and its 395-module
Haskell export produced the byte-identical production checker with SHA-256
`92f1a1453b29f45af2bcb28fcdce58967b73c61e5ffa256e9012aac3bcf558d5`.
Ferrum `78de242` passed 126 focused extractor tests, focused GM04 solver tests,
release compilation, formatting, and `git diff --check`. The 813-test aggregate
Rust run had one persistent-Z3 stdout closure; that exact test passed three
immediate isolated repetitions, while the other 812 tests passed.

## Strict Innermost v1506 replay: 313/366 (2026-08-29)

A 60-second default-strategy probe over the 54 unresolved v1502 roots found
one new current proof: `Transformed_CSR_innermost_04/OvConsOS_nokinds_C.ari`
terminates and certifies in 0.8 seconds. The complete CPF passed two additional
production-CeTA checks before extraction. Its 86 root and nested proof events
yielded 49 certified state/action records and no uncertified positive row.

The strict focused oracle-only replay closes the root in 3.95 seconds. The
subsequent complete 64-worker replay has 305 certified YES, eight certified NO,
53 MAYBE, and no timeout, error, fallback, checker rejection, or prior-root
loss: **313/366**. All 313 retained proofs then passed two independent
production-CeTA checks (626 checker invocations).

```text
target/innermost-gm04-integration-20260828/oracle-v1506-ovcons-nokinds-c.jsonl
target/innermost-gm04-integration-20260828/full-strict-v1507-ovcons-nokinds-c
target/innermost-gm04-integration-20260828/full-strict-v1507-ovcons-nokinds-c-twice-audit
```

The oracle SHA-256 is
`3f9060047f3838352a3941a259dde59d6b2ffadde3c79fe71cecb78932102f83`.

## Strict Innermost v1508 replay: 314/366 (2026-08-29)

`Transformed_CSR_innermost_04/Ex1_GM03_C.ari` is the next certified gain.
The verified GM04 inverse produces two independent children. Its source CSR
child was already completely guided; the missing transformed child had 50
pairs and decomposed into eight cyclic SCCs. Seven SCCs close by exact usable
rules and path orders, while the final administrative SCC is discharged by
the checked complete-GM04 residual theorem. A non-strict discovery replay
finished in 3.6 seconds and passed production CeTA twice. Extraction recovered
38 positive root and nested state/action rows and exported all 38 with zero
uncertified promotion. The resulting strict isolated replay also passed CeTA
twice.

The complete 64-worker strict replay returned 306 certified YES, eight
certified NO, and 52 MAYBE results: **314/366**, with no timeout, error,
fallback, checker rejection, or prior-root loss. It completed in 59 seconds;
the new root took 5.008 seconds. A lightweight independent audit invoked
production CeTA twice on every retained CPF and accepted all 314 proofs (628
checker invocations, zero failures). The more general extraction helper first
completed the same CeTA batch but was interrupted during its redundant nested
state extraction after exposing a CPU-bound performance issue; that partial
output is not used as certification evidence.

```text
target/innermost-gm04-integration-20260828/oracle-v1508-ex1-gm03-c.jsonl
target/innermost-gm04-integration-20260828/full-strict-v1509-ex1-gm03-c
target/innermost-gm04-integration-20260828/full-strict-v1509-ex1-gm03-c-twice-audit-light
```

The oracle SHA-256 is
`d02395c4b14b734749e942d07980b6e1d784df3d530010052dd7ed3e750c7759`.

## Strict Innermost v1510 replay: 315/366 (2026-08-29)

A focused verified-GM04 probe recovered
`Transformed_CSR_innermost_04/ExIntrod_Zan97_C.ari`. Its discovery CPF and
strict oracle-only reconstruction each passed production CeTA twice. The 79
proof events yielded 47 certified state/action records; the monotone exporter
promoted all 47 and rejected zero uncertified positives.

Three other probe results were correctly quarantined. `Ex6_15_AEL02_C` used
size change after losing minimality, while `LISTUTILITIES_complete_C` and
`LISTUTILITIES_nokinds_C` supplied CSR dependency graphs missing required
U-edges. Production CeTA rejected each proof twice, so none of their evidence
entered the oracle.

The complete strict replay returned 307 certified YES, eight certified NO,
and 51 MAYBE results: **315/366**, with no timeout, error, fallback, checker
failure, or prior-root loss. It completed in 61.5 seconds. The independent
twice-per-proof audit accepted all 315 retained CPFs (630 checker invocations,
zero failures).

```text
target/innermost-gm04-integration-20260828/oracle-v1510-exintrod-zan97-c.jsonl
target/innermost-gm04-integration-20260828/full-strict-v1511-exintrod-zan97-c
target/innermost-gm04-integration-20260828/full-strict-v1511-exintrod-zan97-c-twice-audit
```

The oracle SHA-256 is
`02235481683ef7de5e840021b3c90fd289261866580619e0a34a46c0980e1e07`.

## CSR-to-ordinary bridge soundness and strict replay restoration (2026-08-29)

An oracle-guided proof of transformed `Ex6_15_AEL02_C` exposed a runtime
context bug: a generic `<ordinaryDpProof>` reduction-pair bridge retained the
source CSR-DP minimality flag, allowing ordinary SCT after the checker had
already discarded that assumption. Ferrum now records this boundary as
`ordinaryBridgeLosesMinimality`, preserves it in materialized DP inputs and
worklist keys, and rejects ordinary SCT/subterm processors across it. The
pre-marker state spelling remains a lookup-only compatibility alias; every
selected processor still validates the marked live obligation. This retains
the certified exact graph continuation for `OvConsOS_complete_noand_C`
without admitting the rejected Ex6 continuation.

Focused checks produced the intended three-way result: transformed Ex6 is
`Unknown` under strict guidance, source `CSR_04/Ex6_15_AEL02.ari` is
certified twice, and transformed OvCons is certified. The complete strict
Innermost replay then restored the high-water mark: 307 certified YES plus
eight certified NO, **315/366**, with no timeout, error, fallback, checker
failure, or prior-root loss. A second audit accepted all 315 CPFs twice (630
production CeTA invocations, zero failures).

```text
target/innermost-gm04-integration-20260828/full-strict-v1518-bridge-soundness
target/innermost-gm04-integration-20260828/full-strict-v1518-bridge-soundness-twice-audit
target/innermost-gm04-integration-20260828/bridge-boundary-fix/ex6-source-strict
target/innermost-gm04-integration-20260828/bridge-boundary-fix/ov-strict-legacy-alias
```

The Rust library run passed 814 tests and hit one concurrency-only persistent
Z3 stdout-closure race; that test passed immediately when rerun alone. Release
build, formatting, and `git diff --check` passed.

## Checker-aligned fresh-unhiding graphs (2026-08-29)

The improved-CS-DP runtime materializes the fresh unhiding symbol with a
frozen argument so later transformations retain the intended internal state.
The CPF replacement map, however, does not mention that fresh symbol, and
CeTA's `mu_of` consequently assigns its default fully active map while
checking dependency graphs.  Ferrum previously reused the internal frozen
map in its graph estimator, which could omit a required unhiding edge and
leave final certification to reject an otherwise positive-looking chain.

Ferrum now uses the checker-visible default-active map for fresh-unhiding CAP
and root-tcap checks.  Exact CSR graph guidance is also validated against the
recomputed live graph before it can reconstruct a proof: every live cyclic
SCC must be contained in a retained proved component, no cyclic pair may be
omitted, and the retained component order may have no restored backward edge.
The focused `LISTUTILITIES_complete_noand_C` proof passed production CeTA
twice; the stale `LISTUTILITIES_nokinds_C` fragment is now `Unknown` and emits
no CPF.

The complete strict oracle-only preservation replay returned 307 certified
YES, eight certified NO, and 51 MAYBE results: **315/366**.  There were zero
timeouts, harness errors, certification failures, or prior-root losses.

```text
target/innermost-gm04-integration-20260828/full-strict-v1521-u-active-precise
target/innermost-gm04-integration-20260828/u-active-precise-LISTUTILITIES_complete_noand_C
target/innermost-gm04-integration-20260828/u-active-precise-LISTUTILITIES_nokinds_C
```

The Rust library run passed 815 tests; its sole persistent-Z3 stdout-closure
race passed immediately when rerun alone.  Focused CSR graph tests passed
9/9, the retained positive passed two deterministic CeTA rechecks, and
`git diff --check` passed.

## Recursive CSR reduction-chain replay: 316/366 (2026-08-29)

`Transformed_CSR_innermost_04/LISTUTILITIES_nokinds_C.ari` now reconstructs
strictly from independently addressed oracle states.  The source side of the
verified GM04 inverse uses improved CS-DPs, graph decomposition,
instantiation, two recursive `csrRedPairUrProc` steps, graph decomposition,
usable rules followed by a polynomial deletion, and a subterm/graph closure.
The transformed side retains its previously certified proof.

Three integration defects were fixed.  Exact recursive CSR/U3 reductions now
preserve the typed CSR child and serialize their continuation as
`csrDpProof`; the extractor binds an ordinary polynomial bridge by the exact
model plus its unique P/R obligation; and dependency-graph atoms retain the
successful live source ordering when duplicate pairs make CPF-to-index
reconstruction ambiguous.  The last bridge requires the exact raw state, a
unique successful adjacent graph atom, and the same cyclic-child
cardinalities.  The exact atom is still rerun on the live state, and the final
complete CPF is checked independently.

The focused strict run completed in 6.2 seconds and production CeTA accepted
its CPF twice.  The authoritative 64-job category replay returned 308
certified YES, eight certified NO, and 50 MAYBE: **316/366**, with zero
fallback, timeout, error, checker rejection, uncertified decision, or
prior-root loss.  The new root took 8.507 seconds under load; the former
load-sensitive `LISTUTILITIES_complete_noand_C` also certified in 64.029
seconds of harness time.  A deterministic audit checked all 316 retained CPFs
twice (632 invocations, zero failures).

```text
target/innermost-gm04-integration-20260828/oracle-v1533-list-nokinds-live-graphs.jsonl
target/innermost-gm04-integration-20260828/full-strict-v1533-live-graphs
target/innermost-gm04-integration-20260828/list-nokinds-reconstruction-v1522/root-strict-v1533-r1
target/innermost-gm04-integration-20260828/list-nokinds-reconstruction-v1522/certified-events-live-complete-r14.jsonl
```

The oracle SHA-256 is
`225cc1cf7acb57d0d3a573507714d7aaf691c58fd7bd12ecabe6d7f41e4f6df7`.
All 130 extractor tests and all 817 Rust library tests pass; formatting and
`git diff --check` pass.  Ferrum commit `0dc1f35` contains the implementation.
Production CeTA commit `e52c7ce` required no source change.

## Recursive AAECC Standard replay and 1,234/1,542 (2026-09-01)

The general verified AAECC switch and QDP-to-SRS continuation first produced
fresh certified proofs for `Zantema_05/z12.ari` and `z13.ari`.  Before counting
those focused proofs, the category was replayed against the last frozen r136
oracle.  That complete run returned 964 certified YES, 268 certified NO, 304
MAYBE, and six timeouts: **1,232/1,542**.  It also exposed an earlier focused
accounting error: `Strategy_removed_AG01/#4.25.ari` was already present in the
1,230-root r111 baseline, so only `Secret_05_TRS/cime1.ari` and
`Zantema_05/z10.ari` were new category gains.

The existing recursive AAECC evidence for
`Secret_06_TRS/{logarithm,times}.ari` was then layered onto r136.  Complete
root proofs remain excluded; strict replay selects `aaecc-innermost` and finds
each nested DP continuation independently.  Both roots passed a focused
strict replay before the second complete run.

The final 64-job, two-Rayon-thread replay used a 65-second harness, the
`timeout(60s, fail)` strategy, disabled top-level and DP fallback, and checked
every decision with production CeTA-CSR.  It completed in 271 seconds and
returned 966 certified YES, 268 certified NO, 301 MAYBE, and seven timeouts:
**1,234/1,542**.  Relative to the immediately preceding complete replay, the
only solved-status changes are the two AAECC YES gains.  No solved root was
lost.  The deterministic audit checked all 1,234 CPFs twice (2,468 checker
invocations, zero failures).  Peak machine use excluding reclaimable file
cache stayed far below the 2 TiB campaign threshold.

The z12/z13 complete proofs remain certified but are not yet strict-replay
gains.  Replay reaches the live post-usable-rule state, whose key is not
currently attached to the independently extracted `innermost-lhss` row.  The
generated SRS proof is separately keyed and usable; the remaining work is the
typed-child alias between those two processors.  The exporter deliberately
does not replace this missing recursive edge with a complete root proof.

```text
target/standard-full-replay-followup-20260901/oracle-r138-r136-plus-aaecc-four-recursive.jsonl
target/standard-full-replay-followup-20260901/full-standard-strict-r139-aaecc-summary.md
target/standard-full-replay-followup-20260901/full-standard-strict-r139-aaecc-details.json
target/standard-full-replay-followup-20260901/full-standard-strict-r139-aaecc
target/standard-full-replay-followup-20260901/full-standard-strict-r139-aaecc-ceta-audit
```

The oracle SHA-256 is
`b5d8168a134958bb35b49a89ab78b283614d6d9294c3a1a56882d98df2c8ade3`.
Attested versions are Ferrum `c2a27d6`, CeTA-CSR `67e9e34`, and TPDB-ARI
`183f29db`.

## z12--z16 recursive alias repair and 1,239/1,542 (2026-09-02)

The extractor previously treated a generated child label ending in
`.ari#qdp-to-srs` as the root problem identity.  It now removes only that
generated suffix and preserves real benchmark names containing `#` before the
`.ari` suffix.  All 148 focused extractor tests pass.

Fresh native proofs for `Zantema_05/{z14,z15,z16}.ari` use the complete chain
AAECC switch, dependency pairs, usable-rule restriction, innermost-LHSS
Q-removal, QDP-to-SRS, and an independently solved generated SRS.  The three
complete CPFs and every extracted positive were checked twice by production
CeTA-CSR.  Adding their typed recursive evidence to the corrected z12/z13
oracle gives 971 strict certified YES roots.  Together with the previously
attested 268 certified NO roots, the category high-water mark is
**1,239/1,542**.

The loaded r144 preservation run returned 971 YES, 266 NO, 295 MAYBE, and ten
timeouts in 275 seconds, with zero certification failure.  Its 1,237 retained
proofs passed 2,474 deterministic checker invocations.  The two absent NO
answers are search-time variance, not removed oracle rows.

```text
target/standard-z12-z13-alias-fix-20260902/oracle-r142-z12-z16.jsonl
target/standard-z12-z13-alias-fix-20260902/full-standard-strict-r144-z12-z16-summary.md
target/standard-z12-z13-alias-fix-20260902/full-standard-strict-r144-z12-z16-details.json
target/standard-z12-z13-alias-fix-20260902/full-standard-strict-r144-z12-z16
target/standard-z12-z13-alias-fix-20260902/full-standard-strict-r144-z12-z16-ceta-audit
```

Oracle SHA-256:
`b0584598f137a9ec5a996d9d5df3685ff275cec4c0cd27c81accbcb4cfb71b77`.
`z18` is not an instance of the same AAECC partition: its first rule changes
root `f` to `a` while retaining a nested `f`, so the verified AAECC side
conditions reject it.  It is nevertheless solved modularly by polynomial
rule removal, `switchInnermost`, dependency pairs, graph decomposition,
usable-rule restriction, innermost-LHSS removal, QDP-to-SRS, and the generated
SRS closure.  Its default CPF and strict oracle-only replay both certify.  The
r147 preservation replay returned 972 certified YES and 266 certified NO with
zero checker failure; all 1,238 retained proofs passed two deterministic CeTA
checks (2,476 invocations).

## Bounded-increase recursive replay and 1,241/1,542 (2026-09-02)

The certified AProVE proof for `AProVE_07/thiemann34.ari` exposed a reusable
innermost DP continuation: graph decomposition, usable-rule and LHSS
restriction, rewriting, a polynomial `generalRedPairProc` with a conditional
bounded-increase proof, followed by two recursively solved SCT obligations.
Ferrum now preserves the ordered identity of both general-reduction-pair
children.  The exact atom is bound to the requested live strict and bound
rules, so it cannot be applied to a same-sized sibling state.

One further fidelity defect was in exact SCT replay.  Retained graphs used
presentation indices even when reconstruction permuted the live pair order,
and Ferrum checked all graph compositions rather than the dependency-indexed
composition used by CeTA's precise SCT processor.  Exact replay now finds a
term-validated bijection from witness graphs to live pairs, rechecks every
edge, and checks the closure using the live CeTA-style Q dependency graph.
The generic synthesized SCT certificate boundary is unchanged.

The fragment-only r156 oracle explicitly excludes the complete root proof.
Strict replay reconstructs the full proof in 5.31 seconds from independently
addressable processor states, emits exactly one `generalRedPairProc`, and is
accepted twice by production CeTA-CSR.  The complete r157 replay returned 973
certified YES, 266 certified NO, 295 MAYBE, eight timeouts, and zero error or
checker failure in 270 seconds.  Combining its YES set with the already
attested 268-NO set establishes **1,241/1,542** certified roots.  Every one of
the r157 run's 1,239 CPFs passed two independent checker invocations (2,478
checks, zero failures).

```text
target/standard-z12-z13-alias-fix-20260902/oracle-r156-thiemann34-fragments.jsonl
target/standard-z12-z13-alias-fix-20260902/thiemann34-strict-r156-indexed-sct
target/standard-z12-z13-alias-fix-20260902/full-standard-strict-r157-thiemann34-summary.md
target/standard-z12-z13-alias-fix-20260902/full-standard-strict-r157-thiemann34-details.json
target/standard-z12-z13-alias-fix-20260902/full-standard-strict-r157-thiemann34
target/standard-z12-z13-alias-fix-20260902/full-standard-strict-r157-thiemann34-ceta-audit
```

Oracle SHA-256:
`be2b9ad350c8498c07475dd6301aa47493db15e7a75dc73937dd3c7e41c06727`.
Attested versions are Ferrum `dc5bf0e`, CeTA-CSR `def4623`, and TPDB-ARI
`183f29db`.  No CeTA source change was required.

## Bounded max-polynomial Standard lane and 1,230/1,542 replay (2026-08-30)

External AProVE evidence exposed a reusable `graph -> max-polynomial ->
size-change` chain.  Ferrum already implemented and CPF-certified every
processor, but the max-polynomial processor was absent from the default
Standard schedule.  An initial parallel insertion recovered
`Zantema_05/z09.ari` but not `Mixed_TRS/sigma.ari`: broad DP branches occupied
the available Rayon workers before the sub-second max-polynomial task was
scheduled.  The final schedule gives systems with at most fifteen rules a
bounded three-second head start, then starts the unchanged broad portfolio.
The analogous effective-SRS lane uses the same cap.

Both roots now terminate in about 0.3 seconds in focused default runs and
their generated CPF3 proofs are accepted by production CeTA-CSR.  Complete
proof extraction checked each proof twice before exporting the monotone r109
oracle; its report promotes two certified positive rows and rejects zero.
Targeted strict replay (`timeout(60s, fail)` and
`FERRUM_DP_LLM_NO_FALLBACK=1`) is 2/2 certified.

The authoritative 64-job full replay completed in 267 seconds with 962
certified YES, 268 certified NO, 306 MAYBE, six timeouts, and zero checker
failure: **1,230/1,542**.

```text
target/data-campaign/trs-standard-causal-chain-20260830/oracle-exploration-r109-strict-1230-certified.jsonl
target/data-campaign/trs-standard-causal-chain-20260830/maxpoly-strict-r110-summary.md
target/data-campaign/trs-standard-causal-chain-20260830/full-standard-strict-r111-1230-summary.md
target/termcomp-runs/standard-full-strict-r111-1230-20260830
```

Oracle SHA-256:
`274b81c139dcc61835fd31bc6703e2cb2acabd489b4bd4ea35a28b2b7b7e312e`.
The full library suite reported 827 passes and one load-sensitive direct-loop
failure; that test passed immediately in isolation.  Strategy parsing, release
build, formatting, and `git diff --check` pass.  No CeTA-CSR source change was
required.

## Broad Standard external-proof integration (2026-08-30)

The TermCOMP 2025 Standard reconciliation corpus contains 3,299 AProVE proof
outputs for 1,305 of the 1,542 local roots.  The extractor retained 9,683
exact CPF processor events and 10,869 typed state hints.  Of the evidenced
roots, 1,173 have at least one fully recognized proof, 125 have only partial
proofs, and seven have no recognized processor sequence.  Checker-certified
proofs are preferred evidence.  Uncertified proofs are scheduling hints only
and cannot promote a YES or NO.

Three adaptive live-state rounds followed the initial broad round.  After
each round every retained complete proof was checked twice with production
CeTA-CSR before export.  The freezes retained 893, 342, 1,983, and 1,594
unique proofs respectively, with zero deterministic-check rejection.  Live
replay residuals were materialized as independently addressable typed states;
their transformation manifests were deliberately not promoted as complete
proof evidence.  The final monotone oracle contains 395,047 records:

```text
target/data-campaign/trs-standard-external-all-20260830/oracle-global-r03-final.jsonl
SHA-256 9b98a0a7d033040c817f562f3e1ba5881ec1d6828a44f5597d4cf65ca72d6914
```

Strict oracle-only replay (`timeout(60s, fail)`, both top-level and DP
fallback disabled, 64 jobs, two Rayon threads) returned 736 certified YES and
227 certified NO: **963/1542**.  This is 22 certified gains over round zero's
941, with zero loss, error, checker rejection, or uncertified decision.  Two
additional roots, `Strategy_removed_mixed_05/bn111.ari` and
`Transformed_CSR_04/MYNAT_nokinds_noand_GM.ari`, certified in an isolated
two-job rerun, making **965/1542 replayable** under the lenient 60-second
criterion; both missed only in the loaded batch.

Oracle-plus-DP-fallback returned 764 certified YES and 227 certified NO:
**991/1542**.  Relative to strict mode this run had 39 gains and eleven
load/ranking losses (net +28), plus nineteen timeouts.  The strict oracle is
therefore the monotonicity gate; a fallback race's net total must not be used
to claim per-root preservation.

The historic v520 gap set fell from 53 roots to 31 in the authoritative loaded
strict replay (29 when the two isolated load-sensitive successes are counted).
All 31 have external evidence and all have at least one fully expressible
proof.  The remaining issue is composition: some roots still miss the exact
runtime key, while others select a certified transformation but expose another
unguided residual.  The campaign stopped after the third adaptive round as
required; its large state gain yielded only one additional loaded root in that
round.

```text
target/data-campaign/trs-standard-external-all-20260830/standard1542-oracle-only-r03-final-summary.md
target/data-campaign/trs-standard-external-all-20260830/standard1542-oracle-plus-fallback-r03-final-summary.md
target/data-campaign/trs-standard-external-all-20260830/load-sensitive-r03-isolated-summary.md
target/data-campaign/trs-standard-external-all-20260830/remaining53-oracle-only-r03-details.json
```

The reusable runtime-frontier collector is
`scripts/build_runtime_frontier_hints.py`.  Its focused test and the 27
canonical-campaign tests pass (28/28 total).  No CeTA-CSR source change was
needed; all certification used `/work/dfm/festschrift/CeTA-CSR/ceta`.

## Exact recursive CSR context and 317/366 Innermost replay (2026-08-29)

`Transformed_CSR_innermost_04/LISTUTILITIES_complete_C.ari` is the next
strict oracle-only gain. Discovery produced a complete GM04 proof whose source
side uses improved CS-DPs, graph decomposition, four recursive 2D
natural-Arctic usable-rule deletions, and graph/subterm/size-change closure.
Production CeTA accepted the producing and focused strict proofs twice.

Exact `csrRedPairUrProc` replay had omitted the certified usable-rule component
from its typed child, while the synthesizing processor retained it. This made
the runtime child differ from the independently indexed proof state. Ferrum
commit `9739fe9` aligns the exact transition with synthesis and adds a focused
typed-child regression. The older `LISTUTILITIES_nokinds_C` proof was then
reconstructed once against the corrected live graph boundary and freshly
frozen, rather than retaining a context-losing compatibility alias.

The 64-job, two-Rayon-thread replay used `timeout(60s, fail)`, disabled both
top-level and DP fallback, and completed in 69.4 seconds. It returned 309
certified YES, eight certified NO, and 49 MAYBE: **317/366**, with zero
timeout, error, checker rejection, uncertified decision, or prior-root loss.
Peak used memory excluding reclaimable cache was about 576 GiB. All 817 Rust
library tests and 154 focused extractor/exporter tests pass; formatting and
`git diff --check` pass. No CeTA source change was required.

```text
target/innermost-gm04-integration-20260828/oracle-v1553-list-complete-plus-nokinds-fresh.jsonl
target/innermost-gm04-integration-20260828/full-strict-v1555-list-complete-plus-nokinds-fresh
target/innermost-gm04-integration-20260828/full-strict-v1555-twice-audit
```

The oracle SHA-256 is
`2201d48de46aba70929936c3d7c3c7053952d7516e5618bd3ee77b0012a70582`.
The deterministic audit invoked production CeTA twice for each of the 317
retained CPFs (634 checker calls, zero failures).

## Ex6_15_AEL02_C and 318/366 Innermost replay (2026-08-29)

`Transformed_CSR_innermost_04/Ex6_15_AEL02_C.ari` is the next strict
oracle-only gain. The GM04 inverse produces a seven-component improved-CS-DP
source obligation and a 131-pair transformed obligation. The transformed
graph has seventeen cyclic SCCs: sixteen close with independently certified
size-change/order evidence, while the final two `top#` pairs are the exact
residual discharged by the checker-verified complete-GM04 theorem.

The source replay exposed and rejected an older ordinary-DP fragment whose
empty usable-rule set was not the required U3 closure. It was replaced by a
freshly certified 3D natural-Arctic U3 deletion, graph decomposition, a
polynomial deletion, and size-change closure. The producing 810 KiB CPF and
the strict 989 KiB CPF were each accepted twice by production CeTA. The
strict focused replay took 12.116 seconds.

The authoritative 64-job replay used two Rayon threads per root, a 60-second
prover strategy ceiling, a 305-second harness ceiling, `timeout(60s, fail)`,
and `FERRUM_DP_LLM_NO_FALLBACK=1`. It completed in 431.2 seconds and returned
310 certified YES, eight certified NO, and 48 MAYBE: **318/366**. There were
zero timeout, error, checker rejection, uncertified decision, fallback, or
prior-root loss; the only status delta from v1555 is this new certified YES.
Peak used memory excluding reclaimable cache was about 1.1 TiB.

```text
target/innermost-gm04-integration-20260828/oracle-v1596-ex6-15-ael02-c-complete-proof.jsonl
target/innermost-gm04-integration-20260828/ex6-15-ael02-c-producing-v1594
target/innermost-gm04-integration-20260828/ex6-15-ael02-c-strict-v1597
target/innermost-gm04-integration-20260828/full-strict-v1599-ex6-15-ael02-c
```

The oracle SHA-256 is
`a604ed62bdfd419644aee73d3b5d440ee8612fff54c61bde5944d3b49088da40`.
Production CeTA commit `e52c7ce` required no source change.
## Certified factorization of an A-transformation/RFC continuation (2026-09-02)

The two unsupported AProVE fragments in the `Secret_07_TRS/4.ari` proof were
isolated at their exact three-pair DP input. Ferrum now factors that combined
step into ordinary CPF processors:

```
uncurry -> uncurry-below -> mono-poly -> switch-to-trs
        -> relative-match-bounds
```

Ordinary uncurrying retains generated U rules as weak ordinary rules. The
monotonic usable-rules reduction pair removes those rules from the active
obligation, and `switchToTRS` preserves all remaining strict and weak pairs and
rules in a relative TRS. The universal worklist then gives the relative child
its own strategy and oracle lookup. This also fixed `probe-cpf --recursive`,
which had incorrectly restarted the root pipeline at every child.

The complete residual certificate is
`target/standard-z12-z13-alias-fix-20260902/secret07-a-route-r12/proof.xml`.
Production `/work/dfm/festschrift/CeTA-CSR/ceta` accepted it twice. Splicing it
into the archived AProVE root CPF does not yield a certified root: CeTA rejects
an earlier AProVE usable-rules polynomial witness. That rejected prefix remains
hint-only and is not promoted into the oracle; Ferrum must regenerate it with a
checked witness before `Secret_07_TRS/4.ari` can count as a new root.

The current strict Standard high-water remains **1,241/1,542** roots: 973
certified YES and 268 certified NO.  The factorization and continuation fixes
below improve proof-state fidelity but do not yet add a new certified root.

## Transformed-CSR `_C` safety and no-progress audit (2026-09-02)

The fresh 42-root `_C` exploration exposed two independent integration
defects.  First, a unary marked `top#` wrapper was accepted as an
applicative-top DP signature.  That is not an applicative encoding: the
resulting `<uncurryProc><applicativeTop>` steps produced 37 raw YES answers
which CeTA correctly rejected.  Applicative-top uncurrying now requires an
application symbol of arity at least two, with a focused transformed-CSR
regression.  A subsequent ordinary-TRS audit tightened this further: marked
first-order roots such as `log#(x,y)` and `f#(x,y,z)` are not application
symbols either.  The marked root must contain the corresponding unmarked
application spine, as in `app#(app(f,x),y)`.  No rejected answer is retained
or promoted.

Second, `relative-flat-context-closure` could return the same canonical CPF
state while adding only unused fresh variables to its internal variable
universe.  Recursive search then spent the root allowance revisiting the same
state.  The processor now declines rule-identical output, and the general
top-level worklist addresses cycles by canonical CPF digest plus stable
processor atom rather than Rust debug metadata.  On `Ex14_Luc06_C` the
reproduction falls from eighteen identical closure cycles to one real
transformation followed by one inapplicable result.

The guarded 42-root audit is retained at
`target/standard-z12-z13-alias-fix-20260902/transformed-c-no-cycle-r163`.
It contains no YES/NO and hence no certification rejection: 38 roots reach
the 65-second harness ceiling and four hit the deliberately restrictive
64-GiB per-process diagnostic limit while loading the 1.8-GiB oracle and
expanding large DP states.  An uncapped isolated retry showed that all four
are ordinary search timeouts at about 67 seconds, not persistent memory
errors.  Source CSR termination guidance remains useful for independently
matching internal order and graph states, but it cannot by itself certify
unrestricted termination of a complete transformed TRS.  In particular, the
existing complete-GM04 inverse checker soundly requires the innermost
boundary; administrative rewriting below wrappers prevents reusing it as a
Standard inverse theorem.

## RFC continuation boundary and signed max/monus audit (2026-09-02)

One-shot RFC relative match bounds previously materialized its child as a
relative SRS containing the already deleted rules as a weak component.  The
CPF processor proves the deleted rules terminating relative to the remaining
rules and nests an ordinary `<trsTerminationProof>` for that remaining SRS.
Ferrum now exposes exactly that absolute remaining SRS.  The universal
worklist can consequently apply RFC again or select another independently
guided SRS processor without a runtime/CPF state mismatch.  All eight RFC
tests pass; focused `Zantema_04/z061`, `SK90/4.35`, and `AG01/#3.33` proofs
were accepted twice by production CeTA-CSR.  The latter two roots were already
members of the 1,241-root high-water set, so this is a fidelity repair rather
than a category-count gain.

The unresolved AProVE `RFCMatchBoundsDPProof` steps are a different processor.
The certified `qdp-to-srs -> match-bounds` factorization remains available
when preceding processors have removed the active rules, but the inspected
`z30` and `Secret_07` residuals retain rules that current orders cannot first
delete.  CPF/CeTA currently has no direct DP match-bounds processor for that
state, so these fragments remain guidance only.

The max/min vocabulary audit likewise separated two boundaries.  Existing
`maxPoly` certifies maxima of nonnegative affine alternatives, while CPF
natural polynomials permit negative constants but reject negative variable
coefficients.  Exploratory witnesses for `AProVE_08/{round,log}` and
`Secret_06_TRS/tpa06` containing signed slopes were all rejected by production
CeTA and were not promoted.  Supporting `max(0,x-y)` therefore requires a new
verified substitution-stable, non-context-monotone root reduction triple for
`redPairUrProc`; explicit `min(x,y)` needs the corresponding ordered-algebra
extension or a different certified residual proof.  Merely broadening the
SMT coefficient range would be unsound and was reverted.

```text
target/standard-vocabulary-20260902/rfc-z061/proof.xml
target/standard-vocabulary-20260902/sk90-435/proof.xml
target/standard-vocabulary-20260902/ag01-333/proof.xml
```

## Recovered exact match-bounds witness for `z30` (2026-09-02)

The Standard high-water replay had lost `Zantema_05/z30.ari`, although the
July campaign retained a complete 791-KiB Ferrum CPF which production CeTA
had certified.  Re-extraction binds that complete match-bounds automaton to
the current canonical root state as one self-contained
`exact-match-bounds(...)` atom; it does not replay an opaque whole proof or
depend on an unstated continuation.

Strict oracle-only replay with `timeout(60s, fail)`, top-level model guidance
disabled, and DP fallback disabled returns `Terminating` immediately.  The
regenerated CPF was accepted twice by production CeTA-CSR in 0.361 and 0.354
seconds.  This raises the retained Standard union from **1,241/1,542** to
**1,242/1,542**: 974 certified YES and 268 certified NO.

```text
target/standard-vocabulary-20260902/z30-recovery-r164/events.jsonl
target/standard-vocabulary-20260902/z30-recovery-r164/gates.jsonl
target/standard-vocabulary-20260902/oracle-r164-z30.jsonl
target/standard-vocabulary-20260902/z30-strict-r164/proof.xml
```

Oracle SHA-256:
`8df87ea3792125155b7f95ce32b8ae20279c0f16428d14b439164311380ea74e`.

## Recovered CPF2 semantic-unlabeling proof for `Ex14_Luc06_C` (2026-09-02)

The Matchbox 2014 corpus contains a certified CPF2 proof for
`TRS_Standard/Transformed_CSR_04/Ex14_Luc06_C.ari`.  Its proof was not
directly reusable as CPF3 for two independent format reasons: CPF2 term
wrappers (`lhs`, `rhs`, and `arg`) leaked into the source-bound exact atom,
and the proof used the obsolete `unlabProc` constructor.  The extractor now
normalizes the shared root before constructing complete-root rows, with a
regression covering legacy CPF2 rule syntax.

The semantic-labeling boundary was translated as prescribed by the official
CPF2-to-CPF3 converter: the pair eliminated by the labeled relative proof is
made the first branch of a `splitProc`, and the unlabeled residual proof is
the second branch.  The official converter then translated CPF2 residual-set
reduction-pair payloads to CPF3 removed-set payloads.  The resulting current
CPF was accepted twice by production CeTA-CSR in 0.012 seconds.

Re-extraction retained 39 certified root and recursive-state actions.  With
those actions added monotonically to the `z30` oracle, strict oracle-only
replay (`timeout(60s, fail)`, no DP fallback, and no top-level model) produced
a fresh 121-KiB CPF in about five seconds.  Production CeTA-CSR accepted that
CPF twice in 0.023 and 0.022 seconds.  The retained Standard union is now
**1,243/1,542**: 975 certified YES and 268 certified NO.  The authoritative
complete-replay baseline remains unchanged until the next complete strict
category replay.

```text
target/standard-transformed-c-direct-20260902/ex14-matchbox/proof-converted-official.xml
target/standard-transformed-c-direct-20260902/ex14-matchbox/current-certified-events.jsonl
target/standard-transformed-c-direct-20260902/oracle-r166-z30-ex14c.jsonl
target/standard-transformed-c-direct-20260902/ex14-strict-r166/proof.xml
```

Oracle SHA-256:
`adcf763a360746963a67c86d9af5ae0b9852116a5a13cd4c3f05eae4daf956b7`.

## Standard retained-union recovery and 1,255/1,542 (2026-09-02)

The r169 diagnostic replay certified 1,251 roots and exposed one rejected
positive: `Transformed_CSR_04/Ex14_AEGL02_C` used an exact top-level
polynomial whose zero argument coefficient was strict on the rule but not
monotone in arbitrary contexts. Exact/oracle polynomial witnesses now pass
the same whole-TRS monotonicity check as synthesized witnesses, so this
candidate fails closed before CPF construction.

Comparison with every preceding complete strict replay identified four
members of the 1,255-root certified union that r169 had missed:
`Kaliszyk_19/{1rwr,not_3258}`, `Transformed_CSR_04/Ex14_AEGL02_C`, and
`Transformed_CSR_04/Ex9_BLR02_FR`. The Kaliszyk failures were scheduler
overhead, not missing proof vocabulary: a redundant negative-attempt cache
serialized and hashed their roughly 100-MiB CPF states before every atom, and
a retained one-rule exact witness was needlessly compared with every root.
The cache was removed, canonical cycle keys are now computed only for
successful nonterminal transformations, and the one-rule witness has a
necessary rule-count guard. Both Kaliszyk proofs again complete in
milliseconds once scheduling begins.

`Ex14_AEGL02_C` now follows its certified root `switch-csr` and source-CSR
polynomial deletion chain. `Ex9_BLR02_FR` uses the two exact Arctic witnesses
from its earlier twice-certified trace; generic Arctic synthesis had selected
a different valid first model whose residual did not follow the retained
continuation. Every promoted nested action remains keyed to its own live
state. The private complete-GM04 residual assumption was additionally guarded
by the innermost strategy boundary proved by CeTA-CSR; a full-rewriting
Standard residual cannot use it.

The final release-built r197 replay used 64 workers, a 65-second harness,
`timeout(60s, fail)`, `FERRUM_DP_LLM_NO_FALLBACK=1`, no top-level model, the
r191 oracle, and production CeTA-CSR. It completed in 281 seconds with 987
certified YES, 268 certified NO, 278 MAYBE, nine timeouts, and zero
certification failures: **1,255/1,542**.
All 846 Rust library tests and all eleven monotone-merge tests passed. A
separate audit then accepted every retained CPF twice: 1,255/1,255 proofs,
2,510 checker invocations, zero failures.

```text
target/standard-transformed-c-direct-20260902/oracle-r191-union1255-recovered.jsonl
target/standard-transformed-c-direct-20260902/recover-union1255-pruned-r195
target/standard-transformed-c-direct-20260902/full-standard-oracle-only-r197-union1255
target/standard-transformed-c-direct-20260902/full-standard-oracle-only-r197-union1255-ceta-twice-audit
```

Oracle SHA-256:
`5dd05b4f7582039926b8b15641bd0d05b17a9443eb8ab78e4cfbadd6bfabdffd`.
Attested versions are Ferrum `32aa67d`, CeTA-CSR `def4623`, and TPDB-ARI
`183f29db`. No CeTA-CSR source change was required.

## Recursive z23 integration and applicative-top hardening (2026-09-02)

A default/oracle exploration of all 287 roots unresolved by r197 produced six
raw YES answers. `Zantema_05/z23` was the sole immediately certified gain.
The other five were quarantined: `AotoYamada_05/Ex5TermProof` and
`Saito_26/JI` omitted mandatory applicative-top eta expansions, while
`Waldmann_06/{jwno2,jwno5,jwno8}` violated CeTA's `hvf_top` head-variable
side condition.

Ferrum now materializes the eta expansions as strict transformed dependency
pairs, keeps generated uncurrying rules weak, and checks `hvf_top` before
applying the processor. The two former eta candidates now remain unresolved
instead of emitting checker-rejected CPFs, and the three variable-headed
problems decline the inapplicable processor. Nineteen focused uncurrying tests
and the complete 848-test Rust library suite pass. No CeTA change was needed;
the implementation follows the already verified `uncurry_top_proc` contract.

`z23` was integrated without retaining its complete root proof or a complete
DP continuation. Its seven state-local actions are AAECC, DP, usable rules,
innermost-LHS removal, QDP-to-SRS, DP, and the terminal graph witness. A strict
focused replay with both fallback layers disabled reconstructed a fresh proof,
which production CeTA-CSR accepted twice.

The full r209 replay used 64 workers, a 65-second harness,
`timeout(60s, fail)`, `FERRUM_DP_LLM_NO_FALLBACK=1`, and no top-level model.
It completed in 272 seconds with 988 certified YES, 268 certified NO, 277
MAYBE, nine timeouts, and zero certification failures: **1,256/1,542**. The
independent audit accepted every retained proof twice (2,512 checker
invocations, zero failures).

```text
target/standard-transformed-c-direct-20260902/oracle-r207-union1256-z23-recursive.jsonl
target/standard-transformed-c-direct-20260902/z23-strict-recursive-r208
target/standard-transformed-c-direct-20260902/full-standard-oracle-only-r209-union1256
target/standard-transformed-c-direct-20260902/full-standard-oracle-only-r209-union1256-ceta-twice-audit
```

Oracle SHA-256:
`ac128b3bc1ea1966b92011a9f2fd442164c60a4868cd57f982c7e002e54eef35`.
Attested versions are Ferrum `08f9a95`, CeTA-CSR `def4623`, and TPDB-ARI
`183f29db`.

## 2026-09-02 Standard monotone replay at 1,262/1,542

The final r277 strict oracle-only replay completed all 1,542 TPDB-ARI Standard
roots in 278 seconds with 988 certified YES, 274 certified NO, 272 MAYBE, eight
timeouts, and zero checker failures. Compared with r255 (1,260 certified), the
exact set delta is two gains and no losses:
`Transformed_CSR_04/OvConsOS_complete-noand_FR.ari` and
`Transformed_CSR_04/OvConsOS_nokinds_Z.ari`.

The integration exposed two distinct replay defects. First, the DP scheduler
mistook an exact-guidance override for its appended default fallback and
cost-sorted away the certified causal order. Second, a retained terminal loop
cannot be lifted backward through forward instantiation merely as opaque XML.
Ferrum now supports a source-bound complete DP-nontermination continuation for
one independently keyed residual. It matches the live TRS and complete pair
multiset modulo the checked signature isomorphism; CeTA remains responsible
for checking the full nested CPF proof. Extraction materializes these
continuations systematically in addition to granular terminal loops.

Artifacts:

- oracle: `target/standard-2026-oracle-gains-r253/next-ovcons-r274/oracle-r275-union1262.jsonl`;
- replay: `target/standard-2026-oracle-gains-r253/full-r277`;
- twice-per-proof audit: `target/standard-2026-oracle-gains-r253/full-r277-ceta-twice-audit`.

The audit reports 1,262/1,262 proofs accepted twice (2,524 checker invocations,
zero failures). No CeTA-CSR source change was required.

## 2026-09-02 Standard recursive-continuation replay at 1,266/1,542

An oracle-plus-default replay of the 280 unresolved r277 roots exposed a real
scheduler defect. When an exact oracle processor replaced the current member
of an inherited DP pipeline, Ferrum retained the explicit strategy only as a
sibling at the parent. After the exact transformation succeeded, the matching
pipeline tail was absent from the child. Ferrum now attaches every matching
explicit tail as a checked alternative to the exact processor's own
continuation. This retains independently keyed oracle guidance while allowing
the caller's residual cleanup to continue; repeated occurrences of the same
processor family remain separate alternatives.

The corrected exploration found four complete certified nontermination
proofs:

- `Transformed_CSR_04/Ex14_Luc06_iGM.ari`;
- `Transformed_CSR_04/Ex6_15_AEL02_FR.ari`;
- `Transformed_CSR_04/LengthOfFiniteLists_nosorts_noand_iGM.ari`;
- `Transformed_CSR_04/OvConsOS_nosorts_noand_iGM.ari`.

The first, third, and fourth close with exact terminal DP loops. `Ex6_15` uses
DP transformation, graph decomposition, narrowing, another exact graph,
switch-to-TRS, and a bounded rewriting loop. Extraction checked each complete
source CPF twice, then materialized 20 certified actions over 12 distinct root
and residual states. The monotone exporter promoted all 20 positive rows,
rejected none, and retained all base records.

The final release-built r282 strict oracle-only replay used 64 workers, two
Rayon threads per root, a 65-second harness, `timeout(60s, fail)`,
`FERRUM_DP_LLM_NO_FALLBACK=1`, no top-level model, and production CeTA-CSR. It
completed all 1,542 roots with 988 certified YES, 278 certified NO, 270 MAYBE,
six timeouts, and zero checker failures: **1,266/1,542**. Exact root-set
comparison with r277 reports four gains and no losses. The independent audit
then accepted all 1,266 retained CPFs twice (2,532 checker invocations, zero
failures). All 855 Rust library tests pass.

Artifacts:

- oracle:
  `target/standard-2026-oracle-gains-r253/frontier-r278/integrate-r280/oracle-r280-union1266.jsonl`;
- full replay:
  `target/standard-2026-oracle-gains-r253/frontier-r278/integrate-r280/full-standard-r282`;
- twice-per-proof audit:
  `target/standard-2026-oracle-gains-r253/frontier-r278/integrate-r280/full-standard-r282-ceta-twice-audit`;
- four-root source replay and extraction:
  `target/standard-2026-oracle-gains-r253/frontier-r278/{unresolved-default-r279,integrate-r280}`.

Oracle SHA-256:
`c3fa299a871270e88e70f6e08aa759eb4d23d2d8c063c2312be6f681e6452841`.
Attested versions are Ferrum `cf2d4ce`, CeTA-CSR `def4623`, and TPDB-ARI
`183f29db`. No CeTA-CSR source change was required.

## Trivial critical pairs in innermost DP rewriting (2026-09-02)

Ferrum's DP-rewriting discovery previously required usable-rule left-hand
sides to have no overlaps. This was stronger than the CPF/CeTA processor,
which accepts joinable innermost critical pairs. Discovery now admits the
sound, efficiently checkable subcase in which both critical-pair contractions
are syntactically identical. Nontrivial critical pairs remain rejected.

This reproduces the exact seven DP-rewriting steps in AProVE's
`TRS_Standard/Secret_06_TRS/tpa06.ari` proof after switch-to-innermost, usable
rules, and Q reduction. The resulting single-pair residual is not yet closed:
AProVE uses a genuine binary minimum together with maximum, while CPF3
`maxPoly` and Ferrum's current natural-polynomial vocabulary cannot represent
that interpretation. The failed alternatives were independently validated;
encoding `min` as zero violates one usable rule, and encoding it as addition
does not orient the final pair. No uncertified result was promoted.

A synthetic full proof containing the newly admitted trivial overlap is
accepted by production CeTA-CSR. The complete Rust library suite passes
858/858, and the four newly recovered strict Standard roots remain 4/4
certified with the r280 oracle and fallback disabled.

Artifacts:

- exact `tpa06` seven-rewrite trace:
  `target/standard-2026-oracle-gains-r253/frontier-r278/tpa06-innermost-r291/events.jsonl`;
- strict four-root regression:
  `target/standard-2026-oracle-gains-r253/frontier-r278/integrate-r280/strict-four-trivial-cp-r295`.

## Arctic usable-rule recovery for `wiehe07` and 1,267/1,542 (2026-09-02)

The raw AProVE proof for `TRS_Standard/AProVE_07/wiehe07.ari` uses scalar
natural-Arctic orders whose finite distinguished coefficients induce an
argument filter. Ferrum formerly validated exact Arctic witnesses against the
unfiltered usable-rule approximation, so it rejected the intended witnesses
and chose a different deletion that could not reach AProVE's narrowing chain.

Exact Arctic replay now computes the argument-filter-dependent usable-rule
fixed point, validates every retained rule and pair, and emits the resulting
`redPairUrProc`. A focused synthetic proof in which an otherwise incompatible
rule occurs only below a filtered argument is accepted by production CeTA.
AProVE's all-minus-infinity auxiliary `gt` interpretation is not a valid CeTA
carrier interpretation; replacing it by the observationally equivalent
constant zero makes the exact witness well formed without changing any active
comparison.

The complete proof decomposes the initial graph into three SCCs. The singleton
closes by size change; the PLUS SCC uses two exact scalar-Arctic deletions and
size change; the TIMES SCC uses the corrected scalar-Arctic usable-rule step,
three narrowings with two graph recomputations, a synthesized 3D Arctic
deletion, and size change. The source run and strict replay are both certified.
The extractor materialized 34 certified actions over 20 canonical states, and
the monotone export promoted all 34 with zero rejected evidence.

Strict replay uses `timeout(60s, fail)`, no top-level model, and
`FERRUM_DP_LLM_NO_FALLBACK=1`; its regenerated CPF was accepted twice by
production CeTA. This raises the Standard oracle-only high water to
**1,267/1,542**: 989 certified YES and 278 certified NO.

Artifacts:

- source proof: `target/standard-2026-oracle-gains-r253/frontier-r278/wiehe07-source-r301`;
- strict replay: `target/standard-2026-oracle-gains-r253/frontier-r278/wiehe07-strict-r302`;
- five-root no-regression replay: `target/standard-2026-oracle-gains-r253/frontier-r278/wiehe07-strict-five-r303`;
- oracle: `target/standard-2026-oracle-gains-r253/frontier-r278/wiehe07-integrate-r300/oracle-r300-union1267.jsonl`.

Oracle SHA-256:
`0fc72ea7d3dc64b5719e229dd7c61877da14325bfbfbb2d208e794f5e275c07a`.

The subsequent full 64-worker strict replay completed all 1,542 Standard
roots with 989 certified YES, 278 certified NO, 268 MAYBE, seven timeouts,
and zero errors or checker failures: **1,267/1,542**.  Exact root-set
comparison against r282 reports `AProVE_07/wiehe07.ari` as the sole gain and
no losses or polarity changes.  One unresolved root moved from MAYBE to
timeout under load, without affecting the certified set.  The independent
audit then accepted all 1,267 retained CPFs twice (2,534 production-checker
invocations, zero failures).

Full attestation artifacts:

- replay:
  `target/standard-2026-oracle-gains-r253/frontier-r278/full-standard-r304-union1267`;
- detailed results:
  `target/standard-2026-oracle-gains-r253/frontier-r278/full-standard-r304-union1267-details.json`;
- twice-per-proof audit:
  `target/standard-2026-oracle-gains-r253/frontier-r278/full-standard-r304-union1267-ceta-twice-audit`.

## Recursive monotone residual recovery for `Secret_07_TRS/3` and 1,268/1,542 (2026-09-02)

`Secret_07_TRS/3.ari` had a complete production-CeTA-certified proof, but its
monotone usable-rule reduction and following narrowing step were indexed under
different spellings of the child DP state. Two extraction defects caused the
drift. Exact reduction-pair model atoms were not registered as causal wrapper
children, and static CPF reconstruction represented a monotone rule-removal
child as the original TRS plus an active-rule override. Ferrum's runtime instead
uses the residual rules as the child TRS itself and records them as the
transformation context.

The corrected extractor now follows the live state shape and the strict replay
finds the entire recursive chain. The campaign export explicitly excludes
`exact-dp-proof`, `exact-termination-proof`, and `exact-trs-proof`; the gain is
therefore not an opaque whole-proof replay. The regenerated CPF was accepted
twice by production CeTA. All 158 focused extractor tests pass.

The complete 64-worker replay finished in 279 seconds with 990 certified YES,
278 certified NO, 267 MAYBE, seven timeouts, and zero errors or checker
failures: **1,268/1,542**. Exact comparison with r304 identifies
`Secret_07_TRS/3.ari` as the only gain and reports no loss or polarity change.
The independent audit accepted all 1,268 retained CPFs twice (2,536 checker
invocations, zero failures). Ferrum commit `616a3ba` contains the integration
fix; CeTA-CSR remains at `def4623` and TPDB-ARI at `183f29db`.

Artifacts:

- source proof and extracted events:
  `target/standard-2026-oracle-gains-r253/frontier-r278/secret07-3-source-r317`;
- strict recursive replay:
  `target/standard-2026-oracle-gains-r253/frontier-r278/secret07-3-strict-r319`;
- oracle:
  `target/standard-2026-oracle-gains-r253/frontier-r278/secret07-3-integrate-r318/oracle-r318-union1268-recursive.jsonl`;
- oracle SHA-256:
  `5526000a5597045a8c3b568ba1ac4dbfe07e97ec6401efd8b639012e388de833`;
- full replay and details:
  `target/standard-2026-oracle-gains-r253/frontier-r278/full-standard-r321-union1268`
  and `target/standard-2026-oracle-gains-r253/frontier-r278/full-standard-r321-union1268-details.json`;
- twice-per-proof audit:
  `target/standard-2026-oracle-gains-r253/frontier-r278/full-standard-r321-union1268-ceta-twice-audit`.

## Recursive split and relative-bounds recovery for `Secret_07_TRS/4` and 1,269/1,542 (2026-09-02)

`Secret_07_TRS/4.ari` requires two independently solved children after an exact
generalized DP split. One child closes through semantic labeling, graph
decomposition, usable rules, and monotone polynomial deletion. The complement
uses DP-level uncurrying, uncurrying below, polynomial deletion,
`switchToTRS`, and relative match bounds.

The complete proof already certified, but extraction lost enough runtime
semantics that neither branch was reliably reconstructible. The fixes retain
top-level versus DP uncurrying, materialize exact split residuals, reconstruct
the strict/weak `switchToTRS` partition, and prefer a live checked model or
relative-bounds atom when its exact source and residual agree with the checked
CPF edge. The corresponding Rust processors now materialize the same residual
TRS and active-rule context that the extractor indexes. Complete-root proof
atoms remain excluded.

The strict root replay uses `timeout(60s, fail)`, no top-level model, and
`FERRUM_DP_LLM_NO_FALLBACK=1`; it completes in 5.9 seconds and its CPF was
accepted twice by production CeTA-CSR. The oracle export contains 493,231
records, promotes 41 newly certified positive entries, retains zero weak
transformations, and rejects zero positive evidence.

The complete 64-worker replay finishes with 991 certified YES, 278 certified
NO, 266 MAYBE, seven timeouts, and no error or certification failure:
**1,269/1,542**. Exact comparison with the 1,268 replay identifies
`Secret_07_TRS/4.ari` as the sole change, with no loss or polarity change. The
independent audit accepted all 1,269 CPFs twice (2,538 checker invocations).
Ferrum commit `aceab55` contains the processor and extraction fixes.
Production CeTA-CSR remains at `def4623`; no checker change was required.

Artifacts:

- producing root and extracted evidence:
  `target/standard-2026-oracle-gains-r253/frontier-r278/secret07-4-root-r382`;
- strict recursive root replay:
  `target/standard-2026-oracle-gains-r253/frontier-r278/secret07-4-strict-r385`;
- oracle:
  `target/standard-2026-oracle-gains-r253/frontier-r278/secret07-4-root-r382/oracle-r384-union1269-recursive.jsonl`;
- oracle SHA-256:
  `e6925981b490bf513970091792b22a6dcab8ce2aaedd915fb5e8446b1c6c11c5`;
- full replay and details:
  `target/standard-2026-oracle-gains-r253/frontier-r278/full-standard-r386-union1269`
  and `target/standard-2026-oracle-gains-r253/frontier-r278/full-standard-r386-union1269-details.json`;
- twice-per-proof audit:
  `target/standard-2026-oracle-gains-r253/frontier-r278/full-standard-r386-union1269-ceta-twice-audit`.

## Recursive QDP-to-SRS recovery for `Zantema_05/z24` and 1,270/1,542 (2026-09-02)

`Zantema_05/z24.ari` follows the native AAECC and QDP-to-SRS route. The
generated three-rule unary SRS had a complete certified DP proof, but the
isolated producing event stream lacked a problem identity and the static CPF
walker did not materialize the `qdpToSrs` child. Consequently its nested DP
states were stored under anonymous keys and could not guide the live root.

The extractor now accepts an adjacent `result.json` as the explicit identity
for an otherwise anonymous isolated event stream. It does not infer benchmark
identity from directory names. The exact fragment walker also reconstructs the
general two-stack QDP-to-SRS child deterministically, so the generated SRS and
all of its DP residuals have their own runtime-compatible keys. Complete-root
atoms remain excluded.

The strict replay uses `timeout(60s, fail)`, no top-level model, and
`FERRUM_DP_LLM_NO_FALLBACK=1`; it completes in 5.2 seconds and its CPF was
accepted twice by production CeTA-CSR. The complete 64-worker replay reports
992 certified YES, 278 certified NO, 265 MAYBE, seven timeouts, and no error or
checker failure: **1,270/1,542**. Exact comparison with r386 identifies z24 as
the sole gain, with no losses or polarity changes. The independent audit
accepted all 1,270 proofs twice (2,540 checker invocations).

Artifacts:

- generated-SRS proof and explicit identity:
  `target/standard-2026-oracle-gains-r253/frontier-r278/z24-srs-direct-r392/f40027ef`;
- strict root replay:
  `target/standard-2026-oracle-gains-r253/frontier-r278/z24-oracle-only-r401`;
- oracle:
  `target/standard-2026-oracle-gains-r253/frontier-r278/z24-root-integrate-r400/oracle-r400-union1270-recursive.jsonl`;
- oracle SHA-256:
  `d70774e6aa29277c09dfcd199429551201e4cfe2e82f633d5b196d193d641e41`;
- full replay and details:
  `target/standard-2026-oracle-gains-r253/frontier-r278/full-standard-r402-union1270`
  and `target/standard-2026-oracle-gains-r253/frontier-r278/full-standard-r402-union1270-details.json`;
- twice-per-proof audit:
  `target/standard-2026-oracle-gains-r253/frontier-r278/full-standard-r402-union1270-ceta-twice-audit`.

## Current-state Secret_07_TRS/7 recovery and 1,272/1,542 (2026-09-03)

`Secret_07_TRS/7.ari` exposed two integration defects.  First, exact
nontermination transformations reconstructed only termination children, so a
narrowing or instantiation step could not propagate a terminal DP loop back to
the root.  Second, content-addressed child events store their CPF in the
producing transition's residual witness; the credited dataset builder looked
only at the following event's intentionally omitted input CPF and orphaned the
continuation.  Exact transformations now propagate nontermination proofs,
CPF-style instantiation retains the parent pairs and adds the displayed
instances, and residual CPFs participate in canonicalization and aliasing.

The certified extractor also prefers a live exact transformation when its
source and residual keys are precisely the edge reconstructed from the checked
CPF.  This replaces presentation-dependent monolithic payloads with six
independently replayable actions.  Endpoint matching prevents a successful
backtracked branch from inheriting certification.  Complete TRS and DP proof
fragments are excluded from the exported oracle.

The strict replay uses `timeout(60s, fail)`, no top-level model, and no DP
fallback.  Its exact observed chain is `dp`, subproblem selection, narrowing,
subproblem selection, instantiation, and loop.  The resulting CPF was accepted
twice by production CeTA-CSR.  Oracle export promoted six certified positive
entries, rejected zero positives, and has SHA-256
`93d9b879b2f171785938a553a655a9489d51552906020e90e32ec2837faa95d8`.

An in-process 64-worker category replay completed every expected certified
root before 42 unresolved searches exposed a separate non-cooperative timeout
and memory-retention defect.  The process was stopped below the 2 TiB safety
limit.  The authoritative process-isolated replay then completed all 1,542
roots under an external 125-second harness and the same internal 60-second
proof cap.  Its 1,272 certified paths exactly equal the prior 1,271 union plus
`Secret_07_TRS/7.ari`: no missing path, extra path, polarity change, or checker
failure.  The total is **993 certified YES and 279 certified NO**, with 265
MAYBE and five timeouts.  A fresh deterministic audit accepted all 1,272 CPFs
twice (2,544 checker invocations, zero failures).

Artifacts:

- producing proof and current live events:
  `target/standard-next-frontier-20260902/secret07-7-exact-boundaries-r433`;
- certified recursive evidence and oracle:
  `target/standard-next-frontier-20260902/secret07-7-runtime-bound-certified-r444`;
- strict root replay:
  `target/standard-next-frontier-20260902/secret07-7-strict-oracle-r445`;
- exact 1,272-path set comparison:
  `target/standard-next-frontier-20260903/full-standard-r447-union1272`;
- process-isolated full replay:
  `target/standard-next-frontier-20260903/full-standard-r448-union1272-isolated`;
- twice-per-proof production checker audit:
`target/standard-next-frontier-20260903/full-standard-r448-union1272-isolated-ceta-twice-audit`.

## Recursive `MNZ_10/nvsr` recovery and 1,273/1,542 (2026-09-03)

`MNZ_10/nvsr.ari` exposed presentation-sensitive narrowing selection. Candidate
ranking previously ended in insertion order, so the same residual with a
different parent dependency-pair order could assign a different numeric
candidate to an otherwise identical narrowing. Narrowing now uses the
canonical selected-pair key and sorted canonical generated-pair keys as final
tie breakers; the regression constructs both parent orders and requires the
complete candidate sequence to agree.

The live proof first reduces 26 dependency pairs through graph and polynomial
steps, then applies six narrowing/graph stages. A checked three-dimensional
natural-Arctic interpretation deletes the two additional ground pairs in
Ferrum's sound 26-pair residual and reaches the source-aligned recursive proof
tree. The first graph split has a large cyclic component and a singleton, so
the continuation is represented as a tree rather than a misleading linear
pipeline. Each component is solved independently by the applicable graph,
polynomial, matrix, or size-change continuation.

Certified extraction recorded 487 observations over 35 canonical states and
71 proof-path gates. Oracle export promoted 37 certified positive entries,
rejected zero uncertified positives, and excluded complete `exact-dp-proof`,
`exact-termination-proof`, and `exact-trs-proof` fragments. The resulting
oracle has SHA-256
`565260d722462ce2e06c360d4b3f51a632e534329b40bdaf6c287fb81395b752`.
Strict replay with `timeout(60s, fail)`, no top-level model, and
`FERRUM_DP_LLM_NO_FALLBACK=1` certified the root in about six seconds without
selecting a complete-proof atom.

The process-isolated 64-worker category replay completed all 1,542 roots in
289.2 seconds. It reports **994 certified YES, 279 certified NO, 265 MAYBE,
and four timeouts**, with no error or checker failure: **1,273/1,542**. Exact
set comparison against the prior r448 baseline has no loss and exactly one
gain, `MNZ_10/nvsr.ari`. A deterministic production-CeTA audit accepted all
1,273 CPFs twice (2,546 checker invocations, zero failures). The library suite
passes 866/866 tests, and the focused oracle extraction/export/status suite
passes 229/229 tests.

Artifacts:

- producing proof: `target/standard-next-frontier-20260903/nvsr-full-tree-r516`;
- extracted evidence and credited database:
  `target/standard-next-frontier-20260903/nvsr-integrate-r517`;
- strict root replay: `target/standard-next-frontier-20260903/nvsr-strict-r518`;
- full replay:
  `target/standard-next-frontier-20260903/full-standard-r519-union1273-nvsr`;
- twice-per-proof audit:
  `target/standard-next-frontier-20260903/full-standard-r519-union1273-nvsr-ceta-twice-audit`.

## Current-state `MNZ_10/{5,7}` recovery and 1,275/1,542 (2026-09-03)

The July/August ledger said `MNZ_10/5.ari` and `MNZ_10/7.ari` were certified,
but neither belonged to the current strict union. Their archived CPFs still
passed production CeTA twice. Direct extraction nevertheless could not replay
them: those proofs began with 26 and 22 dependency pairs, while the current
complete construction soundly generates 33 and 27. The archived exact graph
and reduction-pair transitions were therefore inapplicable and were not
promoted as current positives.

A current graph exposes 25 and 21-pair cyclic obligations. Fresh synthesis on
those states recovered both complete proofs. Root 5 uses recursive graph
decomposition and six 2D integer-matrix reductions over `[-2,3]`. Root 7 uses
a natural polynomial deletion, graph decomposition, and four such
integer-matrix reductions. The producing proofs take about ten seconds each
and passed production CeTA twice. Extraction promotes 26 certified positive
rows, rejects zero uncertified positives, and excludes 21 complete-proof
fragments. Strict oracle-only replay reconstructs each proof in about 0.3
seconds without fallback or a complete-proof atom.

The 64-worker preservation replay completed all 1,542 roots in 299 seconds.
It reports **996 certified YES, 279 certified NO, 263 MAYBE, and four
timeouts**: **1,275/1,542**. Exact set comparison with r519 has no loss and
exactly the two intended gains. All 1,275 CPFs passed production CeTA twice
(2,550 checker invocations, zero failures). The oracle SHA-256 is
`ff06c8d3dc1a77e665b8142f394d32d74188f5d29161cd7213ed70d91f6d5f89`.

Artifacts:

- producing current proofs:
  `target/standard-next-frontier-20260903/mnz5-7-resynthesize-r526`;
- extracted current evidence and oracle:
  `target/standard-next-frontier-20260903/mnz5-7-integrate-r527`;
- strict two-root replay:
  `target/standard-next-frontier-20260903/mnz5-7-strict-r528`;
- full replay:
  `target/standard-next-frontier-20260903/full-standard-r529-union1275-mnz5-7`;
- twice-per-proof audit:
  `target/standard-next-frontier-20260903/full-standard-r529-union1275-mnz5-7-ceta-twice-audit`.
## Complete GM04 nontermination inversion and 1,284/1,542 (2026-09-06)

Four complete GM04 transformed Standard systems are nonterminating because
their reconstructed source CSRs have certified context-sensitive loops:
`LengthOfFiniteLists_nosorts_C`, `LengthOfFiniteLists_nosorts_noand_C`,
`OvConsOS_nosorts_C`, and `OvConsOS_nosorts_noand_C`. Ferrum emits a native
`gm04CompleteNonterminationTransformation` node and materializes the source CSR
loop as an independently keyed child state. The oracle does not use an opaque
complete-proof atom.

The mechanized checker validates the exact complete-GM04 schema and symbol
roles, then reflects the checked source CSR loop to full rewriting of the
transformed system. During production integration, category preservation found
and repaired three omitted source-history items: ordinary nontermination parser
fallback, nested CSR rule-removal-before-improved-DP support, and the previously
verified generalized GM04/AAECC/QDP-to-SRS checker vocabulary. The isolated
`Proof_Checker` build and 397-module Haskell export passed. Two mutations—an
incorrect active symbol and a changed source-loop symbol—were rejected.

Strict oracle-only replays use 64 workers, two Rayon threads, a 65-second
harness, `timeout(60s, fail)`, no top-level model, and
`FERRUM_DP_LLM_NO_FALLBACK=1`. Final results are 1,284/1,542 Standard (997 YES,
287 NO), 110/110 CSR (105 YES, five NO), and 318/366 Innermost (309 YES, nine
NO), with zero checker failure. All 1,712 retained CPFs passed production CeTA
twice (3,424 checker invocations). The Ferrum library suite is
872/872.

Artifacts:

- oracle: `target/standard-next-frontier-20260903/gm04-integrate-r739/oracle-r739-global1284.jsonl`;
- oracle SHA-256: `b16bb015a9aa225709caf0cbc1fd2e0f911eb21ef5045c19d41b98905aab8016`;
- final category replays and audits: `target/standard-next-frontier-20260903/gm04-preserve-r744`;
- producing proofs and negative mutations: `target/standard-next-frontier-20260903/gm04-nonterm-r738`;
- production checker SHA-256: `43ad99a28e75d9d372f21c575cba83f38586d577a973a9bd8b2daeb2ef7a77d8`.
## Root-input preservation audit and `switch-csr` quarantine (2026-09-06)

Auditing the newly proposed transformed-CSR `_C` gains exposed a root identity
failure in generic `switch-csr` CPF export.  The writer replaced the original
TRS input with the restricted CSR child, so CeTA's `CERTIFIED` result applied
to a different rewrite relation.  Seventeen inherited oracle candidates were
removed, the atom was made unschedulable, and CPF export now rejects the proof
instead of changing its input.

The audit found one affected Standard and eleven affected Innermost decisions
in the previous complete replay.  Valid fallback recovered four Innermost
roots: `Ex24_GM04_C`, `LengthOfFiniteLists_nokinds_C`, and
`PEANO_nokinds_noand_C` via the verified GM04 inverse wrapper, plus
`LengthOfFiniteLists_nosorts_noand_iGM` by a direct certified loop.  Their
reconstructed oracle-only replay is 4/4 certified.  Corrected conservative
totals are Standard 1,283/1,542 (996 YES, 287 NO), Innermost 311/366
(301 YES, 10 NO), and unaffected CSR 110/110 (105 YES, five NO).  Fresh
complete strict replays are under `root-preserving-full-r757/standard` and
`root-preserving-full-r756/{innermost,csr}`; they have zero certification
failure.  Artifacts are under
`target/standard-next-frontier-20260903/switch-csr-quarantine-r752` and
`target/standard-next-frontier-20260903/switch-csr-recover-r753`.

## Hydras/lepper_3 compact certified loop (2026-09-07)

`TRS_Standard/Hydras/lepper_3.ari` now has a native, retained three-step
mixed DP/TRS loop.  The witness uses only two generated dependency pairs and
one original projection rule, is matched against the live problem, and is
independently replayed before CPF construction.  Production CeTA accepts the
default proof, which is found in 18 ms after adding a 100 ms checked DP-loop
lane before the expensive Standard nontermination portfolio.

Proof-chain-only extraction binds the root DP transformation, exact unused-pair
removal, and terminal loop to three independently addressable states.  The
first extraction exposed a stale child identity; rebinding against the strict
runtime residual repaired it.  The final strict oracle-only replay passes with
fallback disabled, and production CeTA accepts it twice.  The monotone oracle
is `target/standard-next-frontier-20260903/lepper3-integrate-r759/oracle-r759-global1284.jsonl`
(SHA-256 `d21f364b01408faae78939b3f8bce4298733b177d12e581fb916e0a2e6eb8f06`).
Focused preservation checks for `CSR_04/Ex14_Luc06`, Innermost `#4.29`, and
Standard `MNZ_10/nvsr` all remain oracle-only and CeTA-certified.  The fresh
complete 64-worker Standard replay under `root-preserving-full-r760/standard`
returns 996 YES and 288 NO, hence 1,284/1,542 certified decisions, with zero
checker failure and no loss of a prior decision.  Its 1,284 retained CPFs all
passed the deterministic twice-per-proof audit (2,568 checker invocations).

## Causal runtime-path oracle integration (2026-09-07)

The historical CPF2 conversions for
`Transformed_CSR_04/{LengthOfFiniteLists,MYNAT}_complete_noand_iGM` expose 95
and 97 sequential exact reduction-pair transformations.  Structural proof
extraction had pooled automorphic component witnesses: MYNAT tried 395
inapplicable exact witnesses and took 57--67 seconds despite spending only a
few seconds inside successful processors.

`scripts/extract_certified_runtime_path_events.py` now freezes a completed
runtime proof only after CeTA accepts its CPF twice and the event graph has one
uniquely closed causal continuation.  It rejects open residuals, cycles, and
ambiguous completed continuations; no-op transformations and successful
abandoned branches are excluded.  The resulting two-root dataset has exactly
274 certified rows for 274 distinct runtime states.  On the exported oracle,
MYNAT takes 20 seconds isolated with zero failed exact witness, while Length
takes 15 seconds.  Both CPFs pass production CeTA twice.

Ordinary DP canonicalization additionally pins marked symbols to the canonical
names of their unmarked base symbols.  A compatibility lookup for the old
unpinned representation preserves the certified historical union.  The final
64-worker strict replay (`timeout(60s, fail)`, two Rayon threads, no top-level
model, `FERRUM_DP_LLM_NO_FALLBACK=1`) is 998 YES plus 291 NO =
**1,289/1,542 Standard**, with zero certification failure and exactly one gain
(`MYNAT_complete_noand_iGM`) over the corrected 1,288 root set.  Final
preservation is **110/110 CSR** and **311/366 Innermost**, also checker-clean.

The frozen oracle is
`target/standard-next-frontier-20260903/cpf2-integrate-r823/oracle-global1289-preserved.jsonl`
(SHA-256
`cba39e0686ec42ed288b253882c928c7503f43c7689038a6583baaa037ca1fc4`).
Final category artifacts are under
`target/standard-next-frontier-20260903/final-r831-global1289` and
`target/standard-next-frontier-20260903/preserve-r830-global1289`.

Focused extraction/materialization verification passes 179 tests before the
new causal-ambiguity regression and 180 after it.  The full Rust library run is
874 passed and one failed: the 32-way persistent-Z3 pool test observed a
solver broken pipe; its immediate isolated rerun passed.  The long narrowing
budget regression also passed after 201 seconds for the complete suite.
`git diff --check`, the release build, and Python byte compilation pass.
`cargo fmt --check` still reports formatting-only drift in the pre-existing
`nontermination.rs` and `general_red_pair.rs` changes; those files were not
reformatted as part of this integration.

## Secret_07_TRS/aprove02 branch-safe recursive replay (2026-09-07)

The converted complete proof for `TRS_Standard/Secret_07_TRS/aprove02.ari`
was decomposed into independently executable AAECC, DP, graph, usable-rule,
innermost-LHS, reduction-pair, instantiation, and terminal graph steps. A
causal-extraction defect had treated a `<component>` container as the parent
processor and consequently pooled automorphic sibling SCCs. The extractor now
retains the executable graph step plus its branch index. Identity graph
wrappers are suppressed and their live child identity is attached directly to
the continuation.

A second defect was fail-late exact instantiation replay: a retained child set
could look like a one-pair replacement even when CPF's selected source pair
belonged to a sibling SCC. Exact instantiation now parses and checks the CPF
selected pair and displayed instance set before accepting the transition. A
diagnostic reconstructed proof was correctly rejected by CeTA; the unsafe
three aliases were removed. The final strict no-fallback CPF is
`target/standard-next-frontier-20260903/secret07-wave-r836/aprove02-strict-oracle-only-final-safe/proof.cpf.xml`
and production CeTA-CSR accepted it twice. The safe monotone oracle is
`target/standard-next-frontier-20260903/secret07-wave-r836/oracle-global1302-final-safe.jsonl`
(SHA-256
`c30a5d82d5b07b8b2e8d30ad53fd9678a32bace663fc012707c8ff9a2a3843ff`).
It promotes 45 certified state-local candidates and zero uncertified positive
candidate. Focused extractor tests pass 179/179 and the Rust `exact_` filter
passes 88/88. The complete-category high-water mark is not changed until a
fresh full strict replay preserves its entire certified root set.

## Native root labeling and `tpa03` recursive replay (2026-09-07)

The raw AProVE proof for `TRS_Standard/Secret_06_TRS/tpa03.ari` exposed one
remaining recognized processor that Ferrum could not execute: CPF root
labeling between an Arctic DP deletion and a finite semantic-labeling chain.
Ferrum now materializes root-labeled rule instances as a native worklist
transition and emits standard CPF `<rootLabeling/>` with symbol labels. The
default strategy proves the example in 0.344 seconds and production CeTA-CSR
accepts the proof.

Strict integration exposed two general round-trip defects. The fragment
extractor incorrectly cleared ordinary DP minimality after semantic/root
labeling, and CPF input parsing encoded `<symbolLabel>` as an empty numeric
label, collapsing distinct root-labeled symbols. Both boundaries now preserve
the live state exactly. Exact reduction-pair replay also recognizes an
alpha-identical labeled source before attempting portable symbol renaming.
Focused parser, exact-reduction-pair, root-labeling, and all 182 extractor tests
pass.

The final strict proof is
`target/standard-next-frontier-20260903/tpa03-integrate-r860/strict-v10/proof.cpf.xml`.
It uses seven independently addressed transformations with fallback disabled
and was accepted twice by production CeTA-CSR. The monotone oracle is
`target/standard-next-frontier-20260903/tpa03-integrate-r860/oracle-global1303-rootlab-v7.jsonl`
(SHA-256
`84af73996a1d24d51a7ddca01b4dba96b1d697742c70607a4d52025108110ba7`).
This raises the focused union after the complete r840 replay from 1,302 to
1,303; the official complete-replay high-water mark remains 1,299 until a new
1,542-root run finishes.

## Complete 1,303-root Standard replay after Length-Z recovery (2026-09-08)

The strict 64-worker replay against the repaired monotone oracle completed all
1,542 TPDB-ARI Standard roots with 1,012 certified YES, 291 certified NO, 233
MAYBE, and six timeouts.  All 1,303 positive decisions passed production
CeTA-CSR and there were zero certification failures of any kind.  The result
is in
`target/standard-next-frontier-20260903/full-standard-r888-global1303-v8`.

The causal runtime path for
`Transformed_CSR_04/LengthOfFiniteLists_complete-noand_Z.ari` contains 33 live
states, 32 strong transformations, and one terminal decision.  The strict
oracle-only replay finishes in 41.779 seconds and its CPF is accepted by
production CeTA-CSR in 0.022 seconds.  Comparing the complete r884 and r888
certified root sets yields exactly this one gain and no losses, resolving the
temporary discrepancy between four focused gains and the unchanged 1,302
aggregate.

The final oracle is
`target/standard-next-frontier-20260903/length-z-integrate-r887/oracle-global1303-length-z-v8.jsonl`
(SHA-256
`00665b9d69153c61b12e0af3b0d95d16d81e11476ee2e5b8944122d276ebe411`).
The run used `timeout(60s, fail)`, a 65-second harness, 64 workers, two Rayon
threads per worker, no top-level model, and
`FERRUM_DP_LLM_NO_FALLBACK=1`.

## Complete 1,304-root Standard replay after full GM04 recovery (2026-09-08)

`Transformed_CSR_04/PEANO_complete_noand_C.ari` now has a complete verified
full-GM04 proof.  The transformation creates two recursive obligations: the
recovered source CSR and the ordinary administrative TRS.  Both close, and a
freshly exported 397-module Haskell checker accepts the resulting CPF twice.

Two integration defects had prevented strict replay.  First, a successful
top-level polynomial deletion exposed `poly(...candidate=N)`, so a later SMT
model could delete a different rule set.  It now exposes the exact validated
interpretation and deletion indices.  Second, Ferrum's administrative schema
used alpha-equivalent private variable names while CPF rule subtraction is
syntactic; the generated rules now use IsaFoR's `x1`, `x2`, ... convention.
The frozen causal path contains 13 distinct states (11 strong
transformations and two terminal actions), has no open residual, and is
certified twice before export.  Strict replay takes 7.9 seconds.

The complete final replay in
`target/standard-next-frontier-20260903/final-r915-global1304-v16` reports:

- Standard: **1,304/1,542**, 1,013 YES and 291 NO;
- CSR: **110/110**, 105 YES and five NO;
- Innermost: **311/366**, 301 YES and ten NO.

There are zero certification failures in all three categories.  Comparison
with the 1,303 Standard run shows exactly the PEANO gain and no loss.  The
monotone oracle is
`target/standard-next-frontier-20260903/innermost-listutilities-exact-r914/oracle-global1304-preserved-v16.jsonl`
(SHA-256
`e65f02c5d4fd95230738a57cd6b4293bee708b92a2f17e450feb6ceed0619889`).

The final preservation pass also repaired two performance-sensitive replay
boundaries.  Complete CSR proof atoms are accepted only when the live rule
multiset and replacement map match exactly; proof-local frozen symbols are
removed from the applicability input but remain in the checked proof.  The
same source-bound exact mechanism avoids 60-second contention failures for
two large Innermost transformed-CSR proofs.  Every reconstructed root CPF is
still checked by CeTA-CSR; these atoms do not promote unchecked solver output.

## Complete 1,305-root Standard replay after archived NO recovery (2026-09-08)

`Transformed_CSR_04/OvConsOS_complete-noand_Z.ari` had already produced a
strict nontermination CPF under
`target/standard-next-frontier-20260903/cpf2-integrate-r820/strict`, and both
the stock and current production CeTA-CSR binaries accept it. The proof was
nevertheless absent from later unions because this flat manual artifact had
no adjacent `result.json`, and its benchmark-named directory did not contain
the flattened full category path expected by the extractor.

The extractor now recognizes a benchmark basename, with or without `.ari`,
only when it identifies exactly one requested TPDB root. Ambiguous basenames
are rejected. The recovered source-bound exact proof replays strictly
oracle-only in eight seconds and its regenerated CPF was checked twice.

The complete 64-worker replay is
`target/standard-next-frontier-20260903/full-standard-r917-global1305-v18`.
It reports **1,013 certified YES, 292 certified NO, 232 MAYBE, and five
timeouts: 1,305/1,542**, with zero certification failure. Exact set comparison
against r915 shows the single OvConsOS gain and no loss. The monotone oracle
is
`target/standard-next-frontier-20260903/post1304-isolated-r916/oracle-global1305-ovcons-z-v18.jsonl`
(SHA-256
`912fc8d89d57166bc4f4737a15b2adeada6f1bdab7d28b18babf63e0e635560d`).

## Complete 1,306-root Standard replay after Ex4 full-GM04 recovery (2026-09-08)

`TRS_Standard/Transformed_CSR_04/Ex4_DLMMU04_C.ari` now has a complete
full-GM04 inverse proof. The source CSR obligation closes through improved
CS-DPs. The second, 63-rule administrative obligation is independently
solved by an exact polynomial deletion, ordinary dependency pairs, graph
decomposition, and twelve size-change components. Its standalone and full
root CPFs were each accepted twice by production CeTA-CSR.

The generic `qtrs-to-csr` spelling incorrectly selected the one-child inverse
processor, whose sound conclusion is source-to-target nontermination. It now
selects the two-obligation full-termination processor; the explicit
`gm04-inverse-csr` spelling retains its original nontermination semantics.
The strict root replay takes 7.9 seconds.

The complete 64-worker replay is
`target/standard-next-frontier-20260903/full-standard-r920-global1306-v20`:
1,014 certified YES, 292 certified NO, 231 MAYBE, and five timeouts, with zero
certification failures. Exact comparison with the 1,305 replay shows only
the Ex4 gain and no loss. A first preservation pass exposed one
load-sensitive Innermost SCT recomputation; an isolated replay certified, and
freezing its source-bound complete proof restored the final preservation run
in `protected-r922-global1306-v21` to 110/110 CSR and 311/366 Innermost.

The final monotone oracle is
`target/standard-next-frontier-20260903/post1305-c-wave-r919/oracle-global1306-preserved-v21.jsonl`
(SHA-256
`20a222e8f8e5faae17403bee4421c43d969978d57f978d6ad20b817a4d60f51f`).

## Complete 1,308-root Standard replay from two further full-GM04 proofs (2026-09-08)

The repaired `qtrs-to-csr` route also recovers
`Transformed_CSR_04/LengthOfFiniteLists_nokinds_C.ari` and
`Transformed_CSR_04/OvConsOS_nokinds_noand_C.ari`. In both cases the source
CSR chain already existed in the monotone oracle. Isolating the second child
showed that polynomial rule removal followed by ordinary DP processing closes
the administrative TRS in 0.33 and 0.20 seconds respectively. Both child
proofs and both reconstructed full-root proofs passed production CeTA twice.

The complete 64-worker run in
`target/standard-next-frontier-20260903/full-standard-r924-global1308-v23`
reports 1,016 certified YES, 292 certified NO, 229 MAYBE, five timeouts, and
zero certification failures. Exact comparison with the 1,306 replay yields
only these two gains and no loss. The same final oracle preserves CSR at
110/110 and Innermost at 311/366 in `protected-r925-global1308-v23`.

The final oracle is
`target/standard-next-frontier-20260903/post1306-c-wave-r923/oracle-global1308-c-two-v23.jsonl`
(SHA-256
`b39f8c11fb38a2bb26285394e24cb8e899e7c96898c93d066171d1827a4b9053`).

## Complete 1,310-root Standard replay from deeper full-GM04 proofs (2026-09-08)

Two further complete transformed-CSR roots now replay strictly:
`Transformed_CSR_04/LengthOfFiniteLists_complete_noand_C.ari` and
`Transformed_CSR_04/OvConsOS_complete_noand_C.ari`. Their source CSR
obligations were already certified. The separately materialized
administrative TRSs close by path order, ordinary dependency pairs, graph
decomposition, and recursive terminal processors. Both administrative CPFs,
both producing full-root CPFs, and both strict CPFs were accepted twice by
production CeTA-CSR.

The complete 64-worker replay in
`target/standard-next-frontier-20260903/full-standard-r926-global1310-v25`
reports 1,018 certified YES, 292 certified NO, 227 MAYBE, and five timeouts:
**1,310/1,542**, with zero certification failure. Exact comparison with the
1,308 run shows precisely these two gains and no loss or polarity change.
The same oracle preserves **110/110 CSR** and **311/366 Innermost** in
`protected-r927-global1310-v25`.

The monotone oracle is
`target/standard-next-frontier-20260903/post1306-c-wave-r923/oracle-global1310-c-two-v25.jsonl`
(SHA-256
`262bd3d83bd856635f09ce9670988a52600655a5486b55c18f8c06949ba855c8`).

## Complete 1,314-root Standard replay from the next full-GM04 wave (2026-09-08)

The same independently materialized administrative-obligation method recovers
four further transformed-CSR roots:

- `Ex4_7_37_Bor03_C.ari`;
- `Ex6_15_AEL02_C.ari`;
- `ExAppendixB_AEL03_C.ari`;
- `LISTUTILITIES_complete_C.ari`.

For each root, its existing certified source-CSR chain and a fresh exact
path-order proof of the administrative TRS close the two full-GM04 children.
Every administrative proof, producing full-root proof, and final strict proof
was accepted twice by production CeTA-CSR. The complete replay in
`target/standard-next-frontier-20260903/full-standard-r930-global1314-v29`
reports 1,022 certified YES, 292 certified NO, 223 MAYBE, and five timeouts:
**1,314/1,542**, with zero certification failure. Exact comparison with r926
shows precisely these four gains, no loss, and no polarity change.

The protected replay in `protected-r931-global1314-v29` retains **110/110
CSR** and **311/366 Innermost**. The monotone oracle is
`target/standard-next-frontier-20260903/post1310-c-wave-r928/oracle-global1314-c-four-v29.jsonl`
(SHA-256
`3101e598fe1cf5b03f01248176fb75c7c1cc44c6ebab7652230f5d3a1d606401`).

## Complete 1,318-root Standard replay from the LISTUTILITIES full-GM04 wave (2026-09-08)

Four further `Transformed_CSR_04` roots now replay strictly:
`LISTUTILITIES_complete_noand_C.ari`, `LISTUTILITIES_nokinds_C.ari`,
`LISTUTILITIES_nokinds_noand_C.ari`, and
`LISTUTILITIES_nosorts_noand_C.ari`. The full-GM04 transformation exposes an
already certified source CSR and an administrative TRS ranging up to 666
rules. A cheap exact path order closes each administrative obligation before
the generic portfolio can spend the root allowance on less suitable searches.

All four administrative, producing-root, and strict CPFs passed production
CeTA-CSR twice. The complete run in
`target/standard-next-frontier-20260903/full-standard-r933-global1318-v31`
reports 1,026 certified YES, 292 certified NO, 219 MAYBE, and five timeouts:
**1,318/1,542**, with zero certification failure. Exact comparison with r930
shows only these four gains and no loss or polarity change. Preservation in
`protected-r934-global1318-v31` remains **110/110 CSR** and **311/366
Innermost**.

The oracle is
`target/standard-next-frontier-20260903/post1314-c-wave-r932/oracle-global1318-list-four-v31.jsonl`
(SHA-256
`40b3bfc50fa8f69eebd1b071378f6f860e0a099d5972f341ba9e6e26919b3bc1`).

## Complete 1,329-root Standard replay and official 2026 lead (2026-09-08)

All eleven remaining official unresolved `Transformed_CSR_04/*_C.ari` roots
were recovered by separating the full-GM04 obligations. Their source CSRs
already had certified oracle paths. Each administrative TRS, ranging from 11
to 194 rules, closes with an exact checked path order and its recursive
residual continuation. The roots cover `Ex1_GM03`, `Ex24_GM04`, two
`ExIntrod`, two `LengthOfFiniteLists`, two `MYNAT`, two `OvConsOS`, and
`PEANO_nokinds_noand` variants.

All administrative proofs, producing full-root proofs, and strict replays
were checked twice. The complete replay in
`target/standard-next-frontier-20260903/full-standard-r936-global1329-v33`
reports 1,037 certified YES, 292 certified NO, 209 MAYBE, and four timeouts:
**1,329/1,542**, with zero certification failure. Exact root-set comparison
against r933 yields eleven gains, no loss, and no polarity change.

Intersecting the details with the 1,528 published TermCOMP 2026 Standard
paths gives **1,321 certified decisions** (1,029 YES and 292 NO), eight above
AProVE26's 1,313 raw answers. The protected replay in
`protected-r937-global1329-v33` retains **110/110 CSR** and **311/366
Innermost**. The oracle is
`target/standard-next-frontier-20260903/post1318-official-wave-r935/oracle-global1329-official1321-v33.jsonl`
(SHA-256
`7526d570380830872f20a2f3ff2e81018931d2506e652fdc30eba1355efbe67a`).

## Complete 1,331-root Standard replay and AProVE-certified parity (2026-09-08)

The final two AProVE-certified roots missing from strict oracle replay are now
integrated: `AotoYamada_05/Ex5TermProof.ari` and
`Transformed_CSR_04/OvConsOS_complete_noand_iGM.ari`. They certified in
40.441 and 49.433 seconds respectively under the complete 64-worker replay.
Both focused reconstructed CPFs were independently accepted twice by
production CeTA-CSR.

The complete strict replay in
`target/standard-next-frontier-20260903/full-standard-r947-global1331-v51`
reports 1,039 certified YES, 292 certified NO, 207 MAYBE, and four timeouts:
**1,331/1,542**, with zero certification failure. Exact comparison with r936
shows precisely the two gains, no loss, and no polarity change. On the 1,528
published TermCOMP 2026 roots this is **1,323 certified decisions**, ten above
AProVE26's 1,313 raw answers.

The first broad integration attempt exposed fourteen regressions. They were
caused by two representation bugs rather than lost proof power: the new
`activeRulesAreResidual` progress marker lacked a pre-marker oracle alias, and
monotonic reduction-pair children retained the incoming mathematical R even
when no usable-rule projection existed. The compatibility alias is now used
for both ordinary and context-sensitive DP lookup; R is retained only below a
genuine active residual. Semantic-core lookup also excludes generic
transformations, preventing portable `usable-rules` advice from replacing a
recorded continuation. The focused gate in
`post1329-low-effort-r938/losses-final-fixed-r946` recovered all displaced
roots before r947.

The protected run `protected-r948-global1331-v51` retains **110/110 CSR**.
Innermost returned 310/366 under 64-way load because the sole borderline root
`PALINDROME_nokinds_iGM` reached the harness ceiling; its isolated replay in
`palindrome-preserve-r949-v51` completed within the 60-second prover allowance
and certified, retaining the **311/366** protected set. The final oracle is
`target/standard-next-frontier-20260903/post1329-low-effort-r938/oracle-ex5-ovcons-v51-candidate.jsonl`
(SHA-256
`00d487362ec50a5ce75d3a22a47d5f83346e2beec4da70b5159a2f5b845e640f`).

## 2026-09-08 regular-language nontermination gains and 1,333/1,542

Current NTI was run over the 32 unresolved roots for which NTI25 had reported
raw NO. All 32 remain reproducibly nonterminating. Most use recurrent-pair or
pattern-unfolding criteria not currently present in CPF, but two expose the
same small certificate already supported by production CeTA:
`Zantema_15/ex14.ari` and `payet_21/payet-nonloop-1.ari` each admit a two-state
tree automaton whose accepted language is nonempty, rewrite closed, and has no
normal form.

Ferrum now recognizes the two underlying rule schemes modulo symbol and
variable renaming, reconstructs the automaton from the live signature, and
emits native CPF3 `notWNTreeAutomaton`. A mutation of either defining rule is
rejected by the recognizer. Both default and strict oracle-only proofs were
accepted twice by production CeTA-CSR. The complete 64-worker strict replay
reports 1,039 certified YES, 294 certified NO, 205 MAYBE, and four timeouts:
**1,333/1,542**, with zero certification failures. Exact comparison with r947
shows these two gains and no losses or polarity changes. The published 2026
set contains `Zantema_15/ex14` but not the older `payet_21` duplicate, so its
corresponding high-water mark is **1,324/1,528**.

Artifacts:

- producing proofs: `target/standard-next-frontier-20260903/regular-ta-r965-default`;
- certified extraction and strict replay: `target/standard-next-frontier-20260903/regular-ta-integrate-r966`;
- full replay: `target/standard-next-frontier-20260903/full-standard-r967-global1333-v52`;
- protected replay: `target/standard-next-frontier-20260903/protected-r968-global1333-v52`;
- isolated Innermost recovery: `target/standard-next-frontier-20260903/palindrome-preserve-r969-v52`;
- oracle: `target/standard-next-frontier-20260903/regular-ta-integrate-r966/oracle-v52.jsonl`;
- oracle SHA-256: `c754a77707557fbdff6c1e00a32a44261fe33c62bc5985b7f249e0b6bd54af28`.

No CeTA source change was required. The remaining NTI frontier separates into
regular-language certificates needing general automaton synthesis and
LOPSTR'25 recurrent-pair certificates needing a new verified proof vocabulary.

## Ordered competitor recovery and pattern search (2026-10-17)

The exact 2026 Standard worklist contains 94 competitor successes absent from
the protected 1,338-root replay: 21 AProVE raw roots and 73 other-competitor
roots. All AProVE-certified Standard roots were already covered. Cached 2025
Innermost comparison finds no missing AProVE raw/certified or MuTerm success;
that is not a fresh 2026 comparison. The newer manifest's proof URLs returned
404, so retained 2025 proofs are used with their original provenance.

Two Standard NO roots are now independently certified, exported as modular
witness-free actions, strictly replayed, checked twice, and input-audited:

- `Strategy_removed_AG01/#4.19`: 0.762s, generic projection-seeded DP loops;
- `EEG_IJCAR_12/emmes-nonloop-ex3_4`: 1.81s, existing native pattern synthesis.

Artifacts are under `target/competitor-recovery-20261017/`, particularly
`projection-replay-v9/`, `pattern-replay-v14/`, and `frontier-report.json`.
The incremental Standard union is 1,340; consult the state-of-the-art ledger
for the latest completed full replay, rather than treating this union as one.
The newest global oracle is `integrated-pattern-v633/oracle.jsonl` under
`target/srs-native-20261013/`; earlier category evidence remains included.
CeTA is unchanged. The projection implementation is committed as `8540786`.

The complete 21-root default probe and conditional-order variants did not
close an AProVE raw miss. Proof inspection distinguishes algorithm/data-
structure induction, signed-slope max/monus, genuine min/max interpretations,
and DP match-bound continuations. In particular, the old `tpa06` trace reaches
the final residual but lacks its binary minimum interpretation. Increasing
nonnegative coefficient bounds does not supply these missing capabilities.
For other competitors, some retained NaTT outputs contain only `YES`; those
do not justify identifying a particular missing processor.

The guarded-arithmetic pattern probes construct helpers in milliseconds but
spend their budget in continuation exploration. A fair-queue experiment found
no additional root and was discarded. Cached immutable priorities now avoid
rescanning every pattern substitution on each queue extraction, preserving
the original stable ordering. Timing instrumentation is opt-in through
`FERRUM_TRACE_PATTERN_SEARCH=1`. The queue regression and all 1,235 library
tests pass; the new pattern root still passes strict replay and two CeTA checks.
Implementation commit: `88a0479`. No additional root is claimed from this
optimization.

Per the updated campaign order, the 23 remaining SRS competitor misses are
queued immediately after Standard and before Innermost. Their exact roots
and retained proof inventory are `queued-srs-frontier.json` and
`queued-srs-proof-inventory.json` in the current campaign directory. Several
Matchbox traces use repeated relative RFC removal; the retained MnM proof for
`no_subst_abbbababa_baabbba` instead uses DP transformation, 2D matrices, and
large sparse tiling/untiling stages. These are different continuation gaps,
not evidence that simply increasing a matrix dimension will solve them.

The queued RFC experiment exposes `fresh-seconds` on
`rfc-relative-match-bounds`, independently of the existing `layered-seconds`.
Allowed values are 0 through 300; zero skips fresh-path completion. When
omitted, it remains `min(layered-seconds, 3)`, preserving every old strategy's
budget. Nondefault values survive strategy-atom serialization, so successful
exploration can be reproduced by modular oracle guidance without an environment
flag. The root deadline still bounds the call. No checker or acceptance test
was weakened.

Verification: 32 RFC-filtered tests and all 1,236 library tests pass; all eleven
recent SRS gains replay strictly and certify twice with unchanged defaults.
Artifacts: `rfc-tests-fresh-budget-v21.log`, `full-tests-fresh-budget-v23.log`,
and `srs-guard-v23/` in the current campaign directory. The queued `v22` wave
allocates 60 seconds to fresh-path synthesis, retains progress traces, and
waits for both Standard discovery waves to finish before launching.
