# Remaining native-guidance synthesis gaps, 2026-09-17

This is a diagnostic campaign, not a replacement for the authoritative complete
replay ledger in [state-of-the-art.md](state-of-the-art.md). Production evidence
already certifies these roots. The question is whether native processors can
rediscover their orders using only families and parameter bounds.

Artifact base: `target/innermost-native-last25-20260917-045625/`.
`misses-v2/details.json` replays all 25 previous misses with no fallback and no
exact actions: two certified YES, 21 Unknown, two harness timeouts, and zero
certification failures. `baseline-atoms-v2/details.json` records 69 independent
probes of native families on the inputs of retained successful modular actions.
These probes supply no retained interpretations. Transformed probe fragments
are diagnostic evidence, **not certified root gains**. Probing one action per
family is not an exhaustive replay of the original chain.

## Root-by-root indicators

Names below are under `TRS_Innermost/Transformed_CSR_innermost_04`, except the
three explicitly marked Mixed roots. Times are measured under concurrent load.
An indicator identifies a demonstrated obstruction or a concrete next test;
it is not a proof that no alternative native proof exists.

| Root | Evidence and next step |
| --- | --- |
| Mixed/cade05 | No native conversion for conditional general reduction pairs. Retained proof uses negative variable coefficients and constraint implication proofs; ordinary weak-polynomial bounds are insufficient. Implement conditional constraint synthesis, not a supplied order. |
| Mixed/cade13 | Same missing conditional reduction-pair synthesis. Production proof remains available and certified. |
| Mixed/wiehe13 | Native KBO produces a model rejected by Q/filter compatibility; the full-R alternative is unsatisfiable. Other source-state rewrite, Arctic and weak-polynomial steps succeed. Investigate CeTA's Q-aware argument-filtered usable-rule closure without dropping Q. |
| Ex1_2_AEL03_GM | Native Arctic transforms the source state; native RPO solves a later source state in 59.2s. Connect the newly synthesized residuals to applicable continuation hints. |
| Ex1_2_AEL03_iGM | Full-R KBO now transforms a retained state (21.9s); Arctic/weak polynomial work, but source RPO reaches 60s. Both continuation coverage and RPO search remain. |
| Ex1_GM99_iGM | Native instantiation, narrowing, rewriting, forward instantiation and now KBO all transform recorded states. A whole native chain still needs residual-local guidance. |
| Ex4_DLMMU04_iGM | Source polynomial/Arctic/weak-poly transformations succeed and instantiation solves a source residual. New model/residual continuation coverage is the next test. |
| ExAppendixB_AEL03_GM | Arctic transforms, source RPO times out at 60s. Restrict/optimize native filter search and guide the new residual. |
| ExAppendixB_AEL03_iGM | Arctic/weak polynomial transform and instantiation solves a source state; KBO and RPO reach 60s. |
| LISTUTILITIES_complete_noand_C | Root reaches the harness limit; graph attempts dominate recorded live trials. Source polynomial solves in 0.4s, while source RPO reaches 60s. Profile graph analysis and seek the polynomial residual directly. |
| LengthOfFiniteLists_complete_noand_GM | Source polynomial transforms in 11.3s; root consumes its 300s allowance without a closing chain. Local polynomial allowance and new-child guidance need separating. |
| LengthOfFiniteLists_nokinds_C | Source polynomial and RPO terminals finish below 0.4s; whole root times out on different intermediate states. Compare live residuals against these terminals. |
| LengthOfFiniteLists_nokinds_iGM | Most native source transformations work, but RPO is inapplicable after 32.1s and narrowing is inapplicable. Live polynomial exploration consumes 300s. Inspect filtering rejection and repeated child exploration. |
| MYNAT_complete_iGM | **Recovered**, certified root in 4.8s with additional TRS-child guidance. |
| MYNAT_complete_noand_GM | Native source RPO reaches 60s; root nearly consumes 300s. Filter synthesis is a concrete bottleneck. |
| MYNAT_nokinds_noand_GM | Native source RPO transforms at 58.8s, close to the local ceiling. Needs both adequate search allowance and residual continuation. |
| MYNAT_nokinds_noand_iGM | Source weak-poly/Arctic transform, polynomial solves, RPO transforms in 33.5s. Whole root exits Unknown much earlier; inspect missing state-local actions. |
| OvConsOS_complete_noand_GM | Source weak-poly/poly transform in 4.5/11.9s, but root consumes 300s. Diagnose new residual chain and repeated polynomial attempts. |
| OvConsOS_nokinds_noand_iGM | Source weak-poly/poly/Arctic transform below 0.4s. Native-generated children still lack a closing guided chain. |
| PALINDROME_complete_noand_GM | Top-level source RPO returns inapplicable at 60s; later source polynomial/KBO steps work. Encoding/search timeout needs distinction from true unsatisfiability. |
| PALINDROME_complete_noand_iGM | Source top-level RPO transforms in 18s after parser repair, but whole root remains Unknown. Compare the actual child with retained continuation states. |
| PEANO_complete_GM | Source RPO transforms in 0.6s; initially Unknown. **Recovered in the next targeted pass** after adding native hints on newly exposed TRS children (`misses-v3`). |
| PEANO_complete_iGM | **Recovered**, certified root in 4.7s with additional TRS-child guidance. |
| PEANO_complete_noand_GM | Source polynomial transforms in 23.4s; root fails to close the resulting chain. Existing short local polynomial allowances and child guidance are candidates. |
| PEANO_complete_noand_iGM | Source weak-poly/poly transform below 0.4s; live continuation remains incomplete. |

## Implemented, versus deliberately not implemented

- Parse the parameterized top-level `path-order(max-symbols=...)` form already
  emitted by events (including RPO/LPO aliases); regression coverage included.
- Raise guided native top-level KBO/RPO allowance from four to 60 seconds.
- Add a native full-R KBO alternative, like the existing full-R RPO route.
  This orients all active rules and preserves the original Q and strategy;
  it does not reinterpret an innermost problem as full rewriting.
- Record distinct KBO weight-admissibility and Q/filter rejections.
- Add a repeatable, digest-checked native-source-state diagnostic tool and tests.

No Q/filter validation was weakened. A proposed filtered Q-aware usable-rule
route was not enabled: it first needs exact closure/normal-form side-condition
checks and positive/mutation-negative certification tests. Relevant verified
definitions are `smart_usable_rules_checker_impl` in
`Generic_Usable_Rules_Impl.thy` and `is_ur_closed_term_af_impl` in
`Innermost_Usable_Rules_Impl.thy`. In particular, filtering recursive descent
does not suppress root rule matching, and every supplied usable rule's RHS
must be closed. An approximate ordinary usable-rule set is not enough.

CeTA-CSR was not changed. Broad DP-frontier hint insertion (`misses-v1`) found
the same two gains but took 677s, versus 308s with TRS-only frontier additions;
it is not selected as the preferred profile. Further work should prioritize
specific live residuals instead of adding every processor at every state.

Validation: `library-final.log` has 1,012 passing release library tests, none
failed or ignored. This includes context-preservation and cyclic rejection
tests for both full-R order alternatives and separate CeTA certification tests
for KBO/RPO. The four focused Python modules have 26 passing tests
(`python-tests.log`), including digest rejection and model-free bound extraction.
The complete first native replay (`full-v2`) certifies 288/311, two gains and
zero losses against 286. All 288 were independently checked twice. Same-binary
production Innermost and compact CSR guards retain 311/311 and 110/110, also
independently checked twice. Standard was not rerun. The final follow-up profile
and any additional complete replay result are recorded in the SOTA ledger.
