# TermCOMP 2025 TRS Innermost Proof Gap

This note records a local inspection of the TermCOMP 2025 `TRS_Innermost`
certified proof artifacts against Ferrum's current prover.

Sources:

- TermCOMP category page: <https://termcomp.github.io/Y2025/TRS_Innermost.html>
- TermCOMP aggregate summary: <https://termcomp.github.io/Y2025/TRS_Innermost.summary.json>
- Raw proof artifacts are linked from the category page under
  `jobs/job_60792801/cert/proofs/benchmark_*/solver_1.txt`.

Local downloaded proof corpus:

```text
/tmp/ferrum-termcomp-innermost-proofs/index.json
/tmp/ferrum-termcomp-innermost-proofs/ferrum_results_recursive_sizechange.json
/tmp/ferrum-termcomp-innermost-proofs/miss_features.csv
```

Ferrum command used for the comparison:

```sh
target/release/ferrum prove PROBLEM \
  --no-top-level-llm \
  --synthesize-linear-polynomial \
  --max-polynomial-coefficient 2 \
  --max-polynomial-symbols 5 \
  --max-polynomial-constant 2 \
  --strategy 'yes'
```

## Headline Counts

TermCOMP/AProVE certified YES proofs for `TRS_Innermost`: 261.

Ferrum on those same 261 instances:

| Ferrum status | Count |
| --- | ---: |
| YES | 51 |
| Unknown | 120 |
| Timeout | 90 |

The currently published Ferrum full-category row is therefore consistent with
the proof-corpus comparison: Ferrum's 51 YES results are all inside AProVE's
certified YES set.

## AProVE Processor Tags

The most frequent CPF processor/proof tags among the 261 certified YES proofs:

| Tag | Proofs |
| --- | ---: |
| `dpTrans` | 189 |
| `depGraphProc` | 181 |
| `usableRulesProc` | 162 |
| `polynomial` | 160 |
| `sizeChangeProc` / `sizeChangeGraph` | 157 |
| `subtermCriterion` | 157 |
| `innermostLhssRemovalProc` / `innermostLhss` | 153 |
| `ruleRemoval` | 103 |
| `redPairProc` | 101 |
| `knuthBendixOrder` | 101 |
| `argumentFilter` | 90 |
| `recursivePathOrder` | 56 |
| `monoRedPairProc` | 48 |
| `redPairUrProc` | 46 |
| `instantiationProc` | 28 |
| `matrixInterpretation` | 27 |
| `bounds` / `treeAutomaton` | 9 |

The biggest gap is not just stronger search. AProVE's certified proofs lean
heavily on processors Ferrum does not yet implement, especially the innermost
LHS processor, size-change/subterm criterion processors, KBO, matrix
interpretations, instantiation, and tree-automata bounds.

## Close Misses

The list below is a historical close-miss sample. It is still useful for
regression targeting, but the exact counts have shifted as Ferrum gained
instantiation, matrix interpretations, LPO support, and safer graph/candidate
handling.

### Pure DP Graph Precision

AProVE closes these by `dpTrans` plus `depGraphProc`, with no later reduction
pair step visible in the CPF. Ferrum should target these first by improving the
dependency graph approximation.

- `TRS_Innermost/Mixed_innermost/bn111.ari`
- `TRS_Innermost/Mixed_innermost/tricky1.ari`

Resolved from this sample:

- `TRS_Innermost/AG01_innermost/#4.18.ari` certifies via the single-rule
  innermost direct graph estimate.
- `TRS_Innermost/AG01_innermost/#4.20.ari` certifies via innermost dependency
  graph decomposition.
- `TRS_Innermost/AG01_innermost/#4.21.ari` certifies via the ground-normal
  proper RHS call extension.
- `TRS_Innermost/Mixed_innermost/gkg.ari` certifies via innermost dependency
  graph decomposition.
- `TRS_Innermost/Mixed_innermost/innermost1.ari` certifies via the source-LHS
  ground-redex filter for innermost dependency graph edges. The formerly
  cyclic edge would require the source rule LHS to contain the ground redex
  `a(b)`, so it cannot occur in an innermost chain.

Current blocker notes:

- `bn111.ari`: the downloaded AProVE CPF 3 certificate is accepted by local
  CeTA after removing the leading `YES` line. Ferrum can recreate the singleton
  split with a stronger syntactic normal-form check under the dependency-edge
  MGU, but that same broad check over-splits several AG01 examples that CeTA
  rejects. The implemented repair is Q-aware IEDG pruning inside active
  innermost/Q contexts rather than a global normality prune.

### DP Plus Nested Rule Removal

These use `dpTrans`, `depGraphProc`, and a polynomial `ruleRemoval` subproof.
Ferrum has DP reductions and top-level polynomial rule removal, but it does not
yet search this nested shape as AProVE records it.

- `TRS_Innermost/Transformed_CSR_innermost_04/Ex1_Zan97_iGM.ari`
- `TRS_Innermost/Transformed_CSR_innermost_04/Ex6_GM04_iGM.ari`
- `TRS_Innermost/Mixed_innermost/innermost2.ari`
- `TRS_Innermost/AG01_innermost/#4.20a.ari`

### DP Red Pair Polynomial

These are close to Ferrum's component-wise polynomial DP reductions, but
Ferrum's current search does not find the AProVE certificates.

- `TRS_Innermost/Transformed_CSR_innermost_04/Ex2_Luc03b_GM.ari`
- `TRS_Innermost/Transformed_CSR_innermost_04/Ex3_3_25_Bor03_GM.ari`

### Top-Level Rule Removal

These use top-level `ruleRemoval` with polynomial interpretations, KBO, or RPO
with argument filtering. Ferrum now has certified recursive top-level
polynomial and KBO rule removal without argument filtering. After adding
strategy-level symbol/arity caps such as `poly(2,2,17,3)`, a focused
18-example slice gained 15 CeTA-certified YES results. After adding
SMT-backed top-level polynomial synthesis through `smt-poly(2,2,17,3)`, the
same slice gained 16 CeTA-certified YES results with 0 certification failures.
After adding a default YES-branch SMT polynomial pass capped at 25 symbols and
arity 3, the slice rose to 17 CeTA-certified YES results. After adding
certified top-level mixed-status path-order rule removal with the
AProVE-style `mark` collapsing argument filter, the slice reached 18
CeTA-certified YES results.

Remaining top-level rule-removal blockers:

- `TRS_Innermost/Transformed_CSR_innermost_04/Ex15_Luc98_GM.ari` is now solved
  and CeTA-certified by SMT-backed top-level polynomial synthesis.
- `TRS_Innermost/Transformed_CSR_innermost_04/LengthOfFiniteLists_nokinds_GM.ari`
  is now solved and CeTA-certified by the default YES-branch SMT polynomial
  pass; the earlier focused run missed it because the strategy capped top-level
  polynomial search at 17 symbols, while the problem has 20.
- `TRS_Innermost/Transformed_CSR_innermost_04/MYNAT_nosorts_GM.ari` uses
  top-level RPO with argument filtering in AProVE's proof and is now solved
  and CeTA-certified by Ferrum's mixed-status path-order rule-removal
  processor. This processor is confined to the YES branch and emits CPF 3
  certificates.

- `TRS_Innermost/Transformed_CSR_innermost_04/PALINDROME_nokinds_noand_iGM.ari`
- `TRS_Innermost/Transformed_CSR_innermost_04/PALINDROME_nosorts_iGM.ari`
- `TRS_Innermost/Transformed_CSR_innermost_04/PEANO_nosorts_noand_iGM.ari`
- `TRS_Innermost/Transformed_CSR_innermost_04/MYNAT_nosorts_C.ari`

## Implementation Priority

For immediate YES improvement without opening a huge new proof language:

1. Improve DP dependency graph precision.
   The first estimated dependency graph pass, based on unifying `CAP(rhs)` with
   target left-hand sides, raised Ferrum from 16 to 21 certified YES and solved
   `TRS_Innermost/AG01_innermost/#4.4.ari`. The remaining 7 pure
   `dpTrans`/`depGraphProc` misses need still more precise graph estimation.
2. Generalize the size-change/subterm processor.
   The first conservative implementation raised Ferrum from 21 to 32 certified
   YES. It is tried before reduction pairs because the check is fast and
   structural. It only fires when every DP in a component strictly decreases
   under a selected projection. The next step is the real size-change
   criterion: build graphs with weak and strict edges and check that every
   cycle has a strict descent.
3. Revisit DP polynomial search on the 2 `redPairProc` polynomial misses.
   These should be good regression cases for SMT/SAT-backed coefficient search.
4. Add support for nested polynomial `ruleRemoval` shapes inside DP proofs or
   translate them into Ferrum's existing component-removal trace when sound.
5. Continue generalizing top-level path-order rule removal beyond the current
   proof-guided mixed-status/argument-filter candidates, while keeping it
   confined to certified YES-branch proof search.

Current LPO/lex-status note:

- Ferrum now has DP LPO/lex-status checking and CPF export. A focused
  regression validates an AProVE-style transformed-CSR lex component.
- The sampled AProVE lex proof `Ex1_GM99_GM.ari` is still not solved because
  Ferrum's graph processor does not isolate the same component before path-order
  search. Treat graph precision as the blocker for that proof family.

For larger gains, implement the innermost-specific processors next:

- `innermostLhssRemovalProc`;
- size-change/subterm criterion processors;
- KBO and matrix interpretations;
- instantiation processor;
- tree-automata bounds, later.

## Next Oracle-Replay Batches (2026-08-11)

The composition-free v851 replay certifies 226 YES and seven NO among all 366
TermCOMP 2025 Innermost roots.  Its intersection with AProVE25_cert contains
approximately 232 of AProVE's 268 certified answers, leaving 36 certified
AProVE roots to recover.  Work on those roots should proceed in the following
batches.

### 1. Argument-filtered reduction orders

Start with residual components whose AProVE proofs close by RPO, KBO, matrix,
or polynomial deletion under an argument filter.  Extend exact extraction and
live validation of the filter, symbol status, precedence or interpretation,
usable-rule obligation, and exact deletion mask.  Every successful processor
must return its residual DP/TRS states to the ordinary worklist; the oracle is
queried again on each child.  Prefer this batch first because it uses existing
CPF3/CeTA processors and should not require a checker extension.

### 2. Deep transformation chains

Recover proofs that interleave dependency-graph decomposition with narrowing,
rewriting, instantiation, forward instantiation, usable-rule restriction, and
later reduction-pair deletion.  The central requirement is exact residual
fidelity: preserve Q/R, minimality, active rules, strategy, variable
freshening, and component membership after every transformation.  Extract and
replay one processor transition at a time rather than retaining a composed
strategy or whole-proof continuation.

### 3. Semantic labeling and splitting

Handle roots whose useful residual is exposed only after semantic labeling or
a split/relative transformation.  Make both processors residual-stable and
extract their exact models, labeled Q/R systems, strict/weak partitions, and
child components.  Each returned child must have an independently canonical
problem key and independently findable oracle advice.  This batch follows the
transformation work because the labeled or split problems commonly require
the reduction-order and residual-chain processors from batches 1 and 2.

For every batch, promotion requires a complete reconstructed CPF accepted by
production CeTA-CSR twice.  After each gain, rerun the affected root strictly
oracle-only and run the full 366-root parity audit.  The acceptance criteria
are an increased AProVE-certified intersection, zero certification failures,
and no loss among the 233 roots certified by v851.
