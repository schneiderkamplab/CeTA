# Innermost parameter-only replay

2026-09-16. This campaign removes supplied interpretations from the 311-root
Innermost production replay, not roots from the retained production oracle.
Production remains 301 certified YES and ten certified NO. The independent
CSR profile remains 105 YES and five NO.

All artifacts below are under `target/innermost-native-20260916/`. Replays use
`FERRUM_DP_LLM_NO_FALLBACK=1`, `timeout(300s, fail)`, two Rayon threads per
process, 24 workers, and the production CeTA-CSR checker. These are not
strict-60-second measurements. No CeTA source or checker change was needed.

| Completed replay | Certified YES | Certified NO | Unknown | Timeout |
|---|---:|---:|---:|---:|
| `baseline` | 215 | 10 | 81 | 5 |
| `replay-v2` | 220 | 10 | 76 | 5 |
| `replay-v4` | 232 | 10 | 63 | 6 |
| `replay-v6` | 249 | 10 | 48 | 4 |
| `replay-v7` | 250 | 10 | 46 | 5 |
| `replay-v8` | 256 | 10 | 41 | 3 |
| `replay-v9` | 258 | 10 | 40 | 3 |

The corrected v9 complete replay is **268/311**, zero certification failures,
43 gains and zero losses against baseline. Category elapsed time is 369 seconds.
The remaining 43 are not proved to require exact witnesses: they are the
current native-synthesis/guidance frontier, listed in `final-witness-report.json`.

v8 additionally contains one rejected raw YES (excluded from these certified
totals). Its source-CSR map export is repaired below. v8 has 41 certified
gains and zero losses against the initial parameter-only baseline; it is not
a production replacement while that rejected decision remains.

All 242 v4 certificates passed two independent checks
(`replay-v4-rechecks.jsonl`). Exact set comparison reports 18 gains and one
loss versus baseline, not an unqualified monotone gain. The lost
`PEANO_nokinds_noand_iGM` is restored by prioritizing its previously successful
native actions at their own states; `peano-v7.cpf` passes CeTA twice.
The full v7 replay validates that ranking change, retained in v9.

## Native processors and evidence export

- `constant-to-unary` selects constants by arity and introduces fresh symbols
  and a fresh variable. It retains the input rewriting strategy. No supplied
  symbol mapping is needed; the existing transformation implementation checks
  freshness and constructs the CPF.
- `gm04-rpo` recovers administrative roles from the structural GM04 schema
  (or the live transformation context), constructs the role-based RPO, and
  validates it against the actual DP obligations. A temporary recognition
  context proposes an order only; it does not authorize a source-CSR theorem
  or change live P/R/Q. Renaming and incomplete-schema regressions pass.
- The isolated Ex1_2_AEL03_C administrative residual closes in 6 ms with
  `gm04-rpo`; its standalone CPF and the complete native-guided root certify.
- `export_native_replay_hints.py` twice rechecks source proofs before exporting
  search-family/bound hints. Event hints receive zero independent certification
  credit. A source root's certificate does not certify its explored events.
- Compound DP/CSR continuations are reduced to the parent transformation;
  nested events address child states independently. Arbitrary sequences are
  omitted. `normalize_native_oracle_actions.py` applies this to a separate
  experimental profile, remaps action ordering, and demotes modified preferred
  evidence. The production oracle and compact CSR profile are not rewritten.
- The v5 replay was an export-validation failure, not a prover regression:
  modified weak evidence was incorrectly left in the preferred bucket. All
  roots rejected that file at loading. The normalizer now demotes it correctly;
  v6/v7 load successfully. The failed artifacts are retained transparently.

## 2026-09-17: residual discovery and native path orders

Artifacts for this continuation are in `target/innermost-native-20260917/`.
The starting complete baseline was 273/311, not the production oracle's
311/311. This campaign continues to exclude supplied interpretations and
composite proof actions; generated processor events can name an `exact-*`
action to describe a model **found by synthesis**, which is not evidence
that the model was supplied by the oracle.

Three generic changes address the remaining frontier:

- Collect top-level TRS children whose only attempted action was the failed
  empty-system check. Such children previously escaped the DP-oriented
  unresolved-state collector. Content digests are still checked. The exporter
  can combine native families from multiple certified baseline runs, including
  newer native recoveries. These suggestions receive no certification credit
  and contain neither models nor compound strategies.
- Eliminate inconsistent argument-filter choices before expanding filtered
  terms or comparing alternatives. The same symbol cannot use two different
  filters at different occurrences. Memoization prevents exponential repeated
  expansion in nested terms. When equivalent terms' Boolean conditions are
  merged, only assignments necessary in **all** disjuncts are retained for
  pruning. Exhaustive small-assignment tests compare the expansion with the
  native filtering semantics. Native graph guidance now gets a 60-second
  analysis allowance rather than repeatedly restarting at two seconds.
- Try an ordinary full-R path-order reduction pair when the Q-restricted
  search fails and the current usable rules equal all active rules. This
  alternative orients every active R rule and preserves live Q, strategy,
  and minimality; it does not remove Q or use an innermost usable-rule
  shortcut. CSR and strict-rule-deletion obligations are excluded. CeTA's
  `generic_ur_af_redtriple_proc` calls `smart_usable_rules_checker_impl` with
  `U_opt=None` for `redPairProc`; that case uses all R without the usable-rule
  Q side conditions. The unchanged checker certifies the synthetic regression
  `tests/fixtures/innermost_full_rule_path_order.ari` and newly synthesized
  Ex2/ExSec proofs. Positive, cyclic-pair rejection, and Q-preservation tests
  cover the route.

Intermediate v3 recovers seven roots but loses two MYNAT roots after model
changes expose different children. It is retained as a diagnostic run, not a
replacement baseline. The subsequent profile incorporates native families
from the previous successful parameter-only baseline to cover those children.
See the authoritative final totals and artifact checksums in
[`state-of-the-art.md`](state-of-the-art.md).

The subsequent standalone frontier pass tried the smallest exposed DP state
per unresolved root, using only native processor families from prior evidence
(eight workers, 60-second local ceiling). One of 15 probes closed and certified:
the 22-pair `Ex2_Luc02a_iGM` residual. Its three local event states were exported
as native hints, with zero independent event-certification credit and no
supplied interpretation. `parameter-v6.jsonl` incorporates those hints; the
separate whole-root check in `ex2-igm-v6/` certifies successfully. Unsuccessful
probe outputs remain in `dp-frontier-v4/`; they are not promoted to evidence.

The frozen `ferrum-v4` binary passes **1,010 library tests** (none failed or
ignored) and the modified export/replay scripts pass **50 focused Python
tests**. Logs are `library-v4.log` and `python-final.log`. Fresh preservation
guards are `production-guard-v4/` (311/311 Innermost) and `csr-guard-v4/`
(110/110); both have exact root-set comparisons with zero losses/polarity
changes and two additional checks of every certificate. CeTA is unchanged.
The Standard category was not rerun in this continuation.

## Verification and remaining work

### Nested GM04 source-map repair

`LISTUTILITIES_nokinds_C` exposed a context mismatch in CPF export: the
GM04 source replacement map omitted the frozen fresh improved-DP U symbol,
although both the live graph processor and standalone CSR exporter used it.
CeTA therefore required an additional edge under its default active position.
The GM04 exporter now explicitly carries that fresh map entry. No source-rule
symbol position, graph estimator, or CeTA implementation was changed.
`listutilities-map-fixed.cpf` passes two CeTA checks; the pre-fix v8 certificate
is retained as the rejection artifact. A focused serialization regression
checks both preservation of source positions and freezing of the fresh U.

Corrected binary `ferrum-v3` SHA256:
`bfff38080b4d994b502e511703b4b01a17e24e98c08c2646797b15927d51ba53`.
Final validation profile `parameter-v9.jsonl` SHA256:
`4cc258faf30df2cc95b2d2b8feb772d9afe2f113c81e29c75a79d21c8c1bad3f`.
It adds the third frontier pass's native hints without replacing the retained
production oracle. Complete validation is in `replay-v9`.
The full serial release suite passes **996/996**, zero ignored
(`library-serial-v3.log`). The corrected binary's compact CSR guard remains
**110/110**, all twice checked (`csr-guard-v3-rechecks.jsonl`).
All **268** native-guided certificates passed two independent checks
(`replay-v9-rechecks.jsonl`). The retained production Innermost oracle also
passes a fresh **311/311** guard (301 YES, ten NO, zero checker failures),
in 209 seconds (`production-guard/details.json`). Standard was not rerun in
this pass; its unchanged production oracle retains the previously recorded
1,338-root baseline.

`ferrum-v2` SHA256:
`45a596dc6603c477f00524727ab9db9efc4940d8a5041925784ca1e8197e02a5`.
The serial release library suite passes **995/995**, zero ignored
(`library-serial-v2.log`). The fresh compact-CSR guard certifies **110/110**
and all 110 proofs pass two further checks (`csr-guard-v2`,
`csr-guard-v2-rechecks.jsonl`). Earlier concurrent tests showed two persistent
solver lifecycle failures; both passed isolated repeats and the complete
serial suite. Their cause has not been established as CPU congestion.

Most remaining misses are transformed-CSR Innermost roots: native models
expose new states, and some larger states still need stronger synthesis or
better state-local scheduling. `cade05`/`cade13` additionally use the
`exact-general-red-pair` family for which this exporter has no native synthesis
replacement. Do not silently weaken its conditional/negative-polynomial
obligations. Local frontier certificates are discovery results, not additional
certified roots until a complete no-fallback replay succeeds.

Do not retire the retained production Innermost witnesses yet. The CSR-only
compact profile is independently validated and does not depend on finishing
this Innermost campaign.

## September 16 follow-up: native RPO and exact canonical aliases

The next native RPO improvement permits quasi-precedence ties and unary
projection in whole-TRS rule removal. Higher-arity filters still retain every
argument. Weak equivalence is respected in the SMT comparisons and independent
validation; the multiset encoding uses full common-submultiset cancellation.
Every synthesized interpretation is independently checked before constructing
the proof.

Five previously missing roots certify in the targeted 43-root run and the
complete 311-root `replay-v13`:
`MYNAT_nokinds_GM`, `MYNAT_nosorts_GM`, `MYNAT_nosorts_iGM`,
`MYNAT_nosorts_noand_GM`, and `PEANO_nokinds_GM` (all in
`Transformed_CSR_innermost_04`). The complete replay reaches **273/311**
(263 YES, ten NO), with five gains, zero losses, zero polarity changes, and
zero uncertified decisions against the previous 268-root baseline. All 273
certificates pass two independent CeTA checks. The remaining 38 are 31
Unknowns and seven timeouts; elapsed time is 706 seconds with 16 workers,
300-second root / 305-second harness ceilings. This is not a strict-60-second
claim. `v13-comparison.json`, `v13-rechecks.jsonl`, and
`v13-witness-report.json` retain the comparisons, checks, and unresolved list.

An actual lookup mismatch was traced to pair ordering: two serializations of
the same 37-pair state, with their source-rule indices moved consistently,
have the same full-context canonical key. The native exporter now records
these canonical aliases in deterministic source-event order. No ordering or
context fields are simply dropped. Two highly symmetric PALINDROME inputs
initially exceeded the canonicalization deadline; exact coordinated-symmetry
pruning and indexed refinement now process them in about one second each.
See [canonicalization measurements](canonicalization-performance.md).

The `target/innermost-native-remaining-20260916/` artifact directory contains:

- `misses-v1`, `misses-v2`, `misses-v3`: the exploratory 43-root passes, each
  with five certified closures and no rejected positive certificates.
- `canonical-native-hints-v2.jsonl` and its `.checks.json` sidecar: all 43
  source proofs checked twice, 1,186 aliases, no canonicalization failures.
- `parameter-v13.jsonl`: broad untried native-family suggestions on exposed
  child states, with zero independent certification credit.
- `parameter-v14.jsonl`: a leaner comparison retaining canonical hints but
  omitting those speculative child-state suggestions. Neither experimental
  profile replaces the full production oracle.
- `production-guard-v2`: 311/311 retained (301 YES, ten NO), zero losses,
  independently checked twice; 406 seconds with eight workers.
- `csr-guard-v2`: 110/110 retained (105 YES, five NO), independently checked
  twice; 73 seconds with eight workers.
- `library-v2.log`: 1,002 serial release library tests passed, none ignored.
- `python-v2-final.log`: 25 focused Python tests passed.

The frozen executable is `ferrum-v2`, SHA256
`a5daaf23709d50cc1f7bab8e8f5b041b68249c926c05d7b7b96155a0a3d73794`.
CeTA was not changed; the checked binary remains SHA256
`64597fcb0a8c1c09af1de0816283c66f474783df3010fc3e60ca30731f5090b7`.
Standard was not remeasured in this follow-up.

The complete lean `replay-v14` also certifies **273/311**, with exactly the
same certified roots, now in 414 seconds. It leaves 35 Unknowns and three
timeouts. All 273 proofs were checked twice (`v14-rechecks.jsonl`); root-set
comparisons against both the 268 baseline and broad v13 have no losses or
polarity changes (`v14-comparison.json`, `v14-v13-comparison.json`). Prefer
this lean experimental profile for the next native campaign; retain broad
v13 as a diagnostic, not as a demonstrated power improvement. The timing
comparison is a pair of runs, not a statistical speedup claim.
Profile v14 SHA256:
`077788018b09c37ccf61514f25aa8f034a041a7a55a7046d911b844262f4b8e1`.
The 38-root unresolved frontier is recorded in `v14-witness-report.json`.
