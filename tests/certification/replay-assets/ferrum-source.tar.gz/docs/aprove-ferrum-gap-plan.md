# AProVE-vs-Ferrum Gap Plan

Baseline: `target/termcomp-runs/20260715-030144-full-128-305s-ceta39/details.json`.
AProVE source: `target/termcomp-proof-corpus/proofs.sqlite`, TermCOMP 2025 `AProVE25 (cert)` certified proofs.

Current Ferrum baseline after the stack-overflow fix is expected to change `TRS_Innermost/Mixed_innermost/wiehe14.ari` from error to timeout; the full run before the fix had 474/180 certified YES/NO for Standard and 114/5 certified YES/NO for Innermost.

## Bug Fix: Cyclic Substitution Stack Overflow

Example: `TRS_Innermost/Mixed_innermost/wiehe14.ari`.

Observed failure: stack overflow during innermost DP proof search, after the rewrite transform branch started on a two-pair component. GDB showed infinite recursion in `apply_substitution` through a cyclic substitution.

Fix implemented:

- `bind_unification_variable` now checks transitive reachability through the current substitution, not only direct variable occurrence.
- `apply_substitution` now carries an expansion set and is defensive against already-corrupt cyclic substitutions.
- DP transform state now also tracks branch-wide transform depth, using the existing `max_narrowing_steps` as a total transform budget.

Validation:

- `cargo +1.95.0 test --lib --jobs 128`: 187 passed.
- `wiehe14` no longer aborts; it now reaches timeout/proof-search exhaustion behavior instead of crashing.

## Systematic Work Plan

### 1. Transformed CSR and innermost exploitation

Impact:

- Standard YES gap: 153 missed AProVE-certified examples from `TRS_Standard/Transformed_CSR_04`.
- Innermost YES gap: 113 missed AProVE-certified examples from `TRS_Innermost/Transformed_CSR_innermost_04`.

Representative divergences:

| Example | AProVE proof shape | Ferrum behavior | Weakness |
|---|---|---|---|
| `TRS_Innermost/Transformed_CSR_innermost_04/Ex23_Luc06_C.ari` | `dpTrans -> depGraphProc -> usableRulesProc -> innermostLhssRemovalProc -> redPairProc -> usableRulesProc -> innermostLhssRemovalProc -> monoRedPairProc`, plus size-change on other SCCs | `unknown`; termination branch exhausts after small innermost components | We do not nest usable/LHSS refinement deeply enough inside each SCC before trying red pairs/SCT. |
| `TRS_Innermost/Transformed_CSR_innermost_04/Ex14_AEGL02_C.ari` | `depGraphProc`, `usableRulesProc`, `innermostLhssRemovalProc`, `sizeChangeProc`, `redPairProc`, `monoRedPairProc`, `narrowingProc` | timeout | Transform-CSR examples need repeated innermost-context simplification before transforms; current search spends time in generic orders. |
| `TRS_Standard/Transformed_CSR_04/Ex15_Luc06_C.ari` | DP proof with graph/SCT/mono-red-pair | `unknown`; Ferrum quickly fails termination, then nontermination branch runs long | Standard CSR cases need sound switch-to-innermost/component-local innermost reasoning where AProVE can introduce innermost contexts. |

Next implementation target:

1. Make innermost usable rules and innermost LHSS removal an explicit cheap prelude before every SCC order/SCT attempt, not only a wrapper recorded opportunistically.
2. Recompute dependency graph after each usable/LHSS refinement and after every pair deletion.
3. Add a CSR-focused strategy branch: `graph; repeat(usable-rules; innermost-lhss; graph; parallel(subterm | sct | orders))` under the correct Q context.

### 2. Size-change and DP graph integration

Impact in unmatched AProVE YES proofs:

- Standard: `sizeChangeProc` appears in 342/474 gaps; `depGraphProc` in 396/474.
- Innermost: `sizeChangeProc` appears in 111/147 gaps; `depGraphProc` in 120/147.

Representative divergences:

| Example | AProVE proof shape | Ferrum behavior | Weakness |
|---|---|---|---|
| `TRS_Standard/AG01/#3.21.ari` | Switches into innermost-style DP component, then usable rules/LHSS/SCT | `unknown`; final Ferrum component is `pairs=1 rules=4 strategy=Innermost` and LLM/order attempts fail | Ferrum has the component but misses the exact Q/minimality assumptions under which SCT is valid. Too conservative or not deriving AProVE's Q set. |
| `TRS_Innermost/AG01_innermost/#4.31.ari` | `depGraphProc`, `usableRulesProc`, `innermostLhssRemovalProc`, `redPairProc`, `sizeChangeProc` | `unknown` on 4-pair component | Graph decomposition/SCT not precise enough after LHSS filtering; likely keeps edges/components AProVE separates. |
| `TRS_Innermost/AG01_innermost/#4.15.ari` | Graph + innermost LHSS + SCT | timeout; one KBO attempt runs ~90s | Strategy scheduling problem: cheap SCT/LHSS evidence is being hidden behind expensive order branches. |

Next implementation target:

1. Instrument SCC sizes before/after every graph and LHSS step.
2. Compare Ferrum SCCs to AProVE components on `AG01_innermost/#4.15`, `#4.31`, and `Ex23_Luc06_C`.
3. Strengthen Q-aware IEDG and SCT guards to use the same usable-rule/LHSS context; where Ferrum is conservative, record the exact edge reason.
4. Move expensive KBO/path/matrix branches behind cheap subterm/SCT in each SCC or run them with strict cooperative cancellation.

### 3. Reduction pairs inside DP components

Impact in unmatched AProVE YES proofs:

- Standard: `redPairProc` in 196 gaps; `monoRedPairProc` in 98.
- Innermost: `redPairProc` in 83 gaps; `monoRedPairProc` in 39.

Representative divergences:

| Example | AProVE proof shape | Ferrum behavior | Weakness |
|---|---|---|---|
| `TRS_Standard/AProVE_04/Liveness_WRS.ari` | DP graph plus red-pair/mono-red-pair | `unknown`; all current order attempts inapplicable | Search class too restrictive: AProVE uses a polynomial red pair Ferrum's bounded one-shot classes do not find. |
| `TRS_Standard/HirokawaMiddeldorp_04/t004.ari` | `redPairProc` after DP graph | `unknown`; small 2-pair innermost component, max-polynomial and LLM fail | Need stronger one-shot polynomial/matrix/path orders or better usable-rule context before orders. |
| `TRS_Standard/Endrullis_06/pair2hard.ari` | `forwardInstantiationProc` plus `redPairProc` | `unknown`; path order consumes tens of seconds and fails | Order search is both too slow and too weak after transformation; needs better filters/statuses and scheduling. |

Next implementation target:

1. Extract concrete interpretations from AProVE CPF for selected red-pair gaps and replay-check whether Ferrum's checker would accept them.
2. If accepted, the issue is synthesis/search; strengthen one-shot encodings.
3. If rejected, the issue is context/processor shape; fix usable rules/LHSS/argument filtering/Q wrapper before changing solver search.
4. Add proof-import regression tests using AProVE interpretation data for at least three examples.

### 4. Instantiation, narrowing, rewriting, forward instantiation

Impact in unmatched AProVE YES proofs:

- Standard YES: narrowing 78, instantiation 56, forward instantiation 46.
- Innermost YES: instantiation 17, narrowing 12, forward instantiation 3.

Representative divergences:

| Example | AProVE proof shape | Ferrum behavior | Weakness |
|---|---|---|---|
| `TRS_Standard/AProVE_04/forward_instantiation.ari` | `instantiationProc` under usable/LHSS context | `unknown`; Ferrum reaches a 2-pair innermost component and fails | Our instantiation skeleton is too restrictive or not applied after the same innermost preprocessing. |
| `TRS_Innermost/Mixed_innermost/innermost3.ari` | `instantiationProc` plus innermost usable/LHSS | `unknown` | Same issue in a small innermost example; good regression target. |
| `TRS_Standard/Endrullis_06/labeling.ari` / `pair2hard.ari` | `forwardInstantiationProc` followed by red pairs | `unknown`; path order branches dominate runtime | Forward instantiation exists but is not finding AProVE's instantiation, or subsequent order context is too weak. |

Next implementation target:

1. Add per-transform diagnostics: selected pair, position, number of generated residual pairs, and rejection reason.
2. Compare AProVE instantiated/narrowed pairs from CPF against Ferrum-generated candidates.
3. Implement max-per-DP counters as branch-state keys over actual DP identity plus transformation kind; keep the new branch-wide cap.
4. Apply transforms in parallel with plain orders, but make the transform branch return `FAIL` for incomplete NO and preserve YES only if all prior processors are sound.

### 5. Certified NO proofs: loops, DP nontermination, nonLoop

Impact:

- Standard certified NO gap: 85 examples.
- Main families: `EEG_IJCAR_12` has 32, `Transformed_CSR_04` has 25.
- AProVE tags: `dpTrans` in 83/85, `loop` in 43/85, narrowing/instantiation in 25/85.

Representative divergences:

| Example | AProVE proof shape | Ferrum behavior | Weakness |
|---|---|---|---|
| `TRS_Standard/EEG_IJCAR_12/enger-nonloop-isList.ari` | Certified `dpTrans` with deep `nonLoop` pattern-rule proof using narrowing, instantiation, equivalence/domain-renaming/irrelevance | `unknown`; Ferrum has only simple DP nonLoop slice | Missing general nonLoop pattern-rule construction. |
| `TRS_Standard/AProVE_10/double.ari` | Certified DP nontermination | `unknown`; small 1-pair component | Need DP nontermination beyond direct self-embedding/simple pumping. |
| `TRS_Innermost/Mixed_innermost/run_again1.ari` | `dpTrans`, `loop`, `narrowingProc`, `innermostLhssRemovalProc` | `unknown` | Innermost nontermination needs narrowing followed by loop detection under correct completeness tracking. |

Next implementation target:

1. Generalize `nonLoop` from simple pumping pairs to CPF pattern-rule chains with base/pumping/closing substitutions, domain renaming, and irrelevance equivalences.
2. Add DP nontermination search over transformation sequences: narrowing/instantiation/rewrite followed by loop/nonLoop detection.
3. Track branch validity: `NO` is global only if all previous processors were complete; otherwise return branch `FAIL`.
4. Prioritize EEG nonloop examples because they are small and CPF proof structure is explicit.

## Priority Order

1. Fix remaining timeout/cancellation leak for long-running transform branches. The stack overflow is fixed, but `wiehe14` still demonstrates that some nested parallel threads can outlive the intended strategy deadline.
2. Strengthen innermost usable/LHSS/SCC/SCT integration, using `Ex23_Luc06_C`, `AG01/#3.21`, and `AG01_innermost/#4.31` as the first regression set.
3. Extract and replay AProVE red-pair interpretations to decide whether order synthesis or context is the bottleneck.
4. Add transform diagnostics and compare generated candidates with AProVE instantiation/narrowing CPF steps.
5. Implement general CPF-style nonLoop construction for EEG examples.
