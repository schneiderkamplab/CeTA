# Modular oracle recovery (r985, complete)

## Verified completion: v278

The single frozen full replay recovered **1,338/1,542 Standard** (1,039 YES,
299 NO), **311/366 Innermost** (301 YES, ten NO), and **110/110 CSR** (105 YES,
five NO). Exact comparisons against r982 show zero missing/extra inputs,
certified losses, gains, polarity changes, or uncertified promoted decisions.
All **1,759 certificates passed two additional independent CeTA checks**, with
unchanged proof digests. Standard took 527 seconds for the full category run.

Artifacts: `target/modular-recovery-r985/final-replay-v278/{standard,innermost,csr}`;
each contains `details.json`, `comparison.json`, `rechecks.jsonl`, and the
retained per-root proof/events. Frozen Ferrum: `ferrum-v275` in the campaign
directory, SHA-256 `b9664c9a32e587394e5e0adf0ecb3784283461b84999c140e3e200c0c191d68a`.
Oracle: `oracle-direct-native-v271.jsonl` in the same directory, SHA-256
`be9686532b358ad5ffab0f9b9f555e29341669b49c24350060920a76efb4fd3d`.
The audit (`oracle-audit-v274.json`) confirms zero complete DP/TRS termination
proof atoms and zero dangling witness references. Complete nontermination
certificates were outside this ablation and remain enabled.

No fallback was enabled. Root allowances were 300 s Standard/CSR and 1,200 s
Innermost, with five-second harness margins; no 60-second performance parity
is claimed. The full Rust suite passes **922 tests, zero failures/ignored**
(`full-tests-v277.log`), plus binary/doc targets. Focused Python extraction
passes 196 tests; retention, comparison, merge, ablation, normalization,
terminal certification and probe tests also pass. `git diff --check` passes.

CeTA source/binary were not changed by this recovery. Production checker:
`/work/dfm/festschrift/CeTA-CSR/ceta`, main commit
`b018e39ca3d4de9a1fe1e50df2b4feecd2ede6f5`, binary SHA-256
`a6d8977c1738daa3e225f0e52443fb56659d09b175516d4215bcd77a3bf0ab46`.
The sections below retain the diagnostic history, including failed attempts;
their pending-state statements are historical, not the completion status.

## Final guard rerun: v275–v278 (pending)

v273 completed at **1,337 Standard**, **311 Innermost**, **110 CSR**. The
sole loss was an OvConsOS_complete_noand_GM timeout caused by the unsuccessful
v213 experiment that disabled raw lookup on small states. Restoring the raw
shortcut for explicitly ordered local guidance recovers it in **7.136 s**,
CeTA-certified (v276). This is a lookup-latency correction, not a new witness
or a changed proof obligation. The exact forward reconstruction policy remains
available independently and preserves Ex9Maps.

Final frozen binary is now `target/modular-recovery-r985/ferrum-v275`, SHA-256
`b9664c9a32e587394e5e0adf0ecb3784283461b84999c140e3e200c0c191d68a`.
Oracle v271 and production CeTA are unchanged. The full Rust suite v277 passes
922 tests; extraction tests now pass 196, including recognition that the
direct forward policy emits the same native CPF rule. Full category artifacts
are `target/modular-recovery-r985/final-replay-v278/{standard,innermost,csr}`.
Do not commit or replace the authoritative baseline before completion.

## Latest verification: v268–v274 (full replays pending)

v266 retained **110/110 CSR** and **311/366 Innermost**, with exact root-set
and polarity parity. Standard exposed an Ex9Maps interaction: bounded native
forward discovery changes the residual representation of that retained exact
chain. An explicit `forwardInstantiationProcDirect` replay policy now selects
checked exact reconstruction, without changing the CPF proof rule or other
roots' native search. Ex9Maps certifies in v270. The strategy round-trip test
and full Rust suite pass: **922 tests, zero failed/ignored**, plus binary/doc
targets (v272).

Final candidate binary: `target/modular-recovery-r985/ferrum-v268`, SHA-256
`2b36fbf0713ed81135514e1788a47adae2440abf32508c00a0b438e666fd0dac`.
Final oracle: `target/modular-recovery-r985/oracle-direct-native-v271.jsonl`,
SHA-256 `be9686532b358ad5ffab0f9b9f555e29341669b49c24350060920a76efb4fd3d`.
Audit v274: 515,798 states, 19,931 witness definitions, no dangling witness
references, malformed records, or complete DP/TRS termination-proof atoms.

Same-artifact full no-fallback guards are running under
`target/modular-recovery-r985/final-replay-v273/{standard,innermost,csr}`.
Standard uses 64 workers, Innermost 16, CSR eight; two Rayon threads per
process. Root caps remain 300/1,200/300 seconds respectively, with five-second
harness margins. Reclaimable file cache is excluded from pressure monitoring.
No new SOTA claim or commit until these runs and double certificate checks
finish.

## 2026-09-09 final recovery candidates (v219–v267)

The v211/v204 full replays finished at **1,318 Standard** and **307
Innermost**, respectively. Their 20 and four losses were real regression
checks; the earlier union of targeted results was not a frozen full replay.

Every lost identity now has a new certified modular replay across the focused
runs. This still requires confirmation by the single-artifact v266 full runs.
Recovery mechanisms:

- Restore bounded native forward-instantiation enumeration (500 ms shared
  across candidates), then use exact reconstruction for expensive searches.
  v217 recovered three Standard losses and v219 recovered twelve more.
- Re-materialize local CPF steps starting with the recorded **live root**.
  This keeps numeric aliases and resulting Q/R contexts aligned with runtime.
  v244/v248 recovered Ex5TermProof; v255 recovered Beerendonk 11/12,
  thiemann29, aprove10 and Innermost LengthOfFiniteLists_nokinds_iGM.
- Materialize the current semantic-labeling child and retain independently
  keyed size-change guidance. Ex1_GM99_C then certifies (v239).
- Rebind unbound reduction-pair deletion payloads to live variable names,
  matching runtime's alpha-equivalent rule selection. Before this fix CeTA
  correctly rejected the empty continuation because literal CPF deletion
  had left a strict pair. Ex16_Luc06_C now certifies (v263); its unchanged
  order is a weak local hint until the reconstructed root is checked.

Final candidate: frozen `target/modular-recovery-r985/ferrum-v261`, SHA-256
`ef5cec18b83178581508c2c71b4f89c038091f76c8f9a19a14602ba2b59335fe`;
oracle `target/modular-recovery-r985/oracle-direct-native-v264.jsonl`, SHA-256
`03afddd2b844757745e29413ad5886026a85098fbb79c954fe14ee857ed5ef39`.
The oracle audit v267 finds 515,798 state records, 19,915 witness definitions,
zero unresolved references and zero complete DP/TRS termination-proof atoms.
Production CeTA-CSR binary is unchanged. The full Rust suite v265 passes
**921 tests**, zero failures/ignored tests; binary and doc-test targets pass.

Full no-fallback runs, with this same binary/oracle/checker, are under
`target/modular-recovery-r985/final-replay-v266/{standard,innermost,csr}`.
They include all baseline input statuses, including old timeouts. Root caps:
Standard/CSR 300 seconds, Innermost 1,200 seconds; performance parity within
60 seconds is not claimed. Certification and exact identity/polarity checks
must complete before updating the authoritative SOTA ledger or committing.

## 2026-09-09 frozen replay validation (v203–v218, incomplete)

All 1,338 Standard baseline identities have certified modular replays across
the diagnostic and targeted runs, but this is **not yet a successful single
frozen full replay**. Full Standard v211 exposes additional losses with binary
v191. Full Innermost v204 also has three completed baseline losses, with one
root still running at this checkpoint. Do not replace the r982 SOTA baseline.

Full CSR v203 retained **110/110** (105 YES, five NO), with all certificates
rechecked twice. Standard v211 uses oracle v209; CSR v203 and Innermost v204
use v201. Final same-artifact guard replays remain required.

Event comparison for `MNZ_10/nrvsq` identifies a concrete regression: skipping
native forward-instantiation enumeration changes the residual representation,
and the exact reconstructed child has no discoverable continuation. v216
restores native enumeration under a shared 500 ms budget before checked exact
reconstruction. Focused seven-root oracle-only validation is v217. Restricting
the small-state raw-lookup shortcut alone (v213/v215) did not recover these
seven roots; it must not be reported as a verified fix.

Full Rust v212: 920 library tests passed; the only additional failure was an
indented precedence description treated as Rust by rustdoc. It is now inline
text, and doc tests pass (v214). Python extraction: 195 passed; overlay: six;
probe helper: eleven. Production CeTA binary is unchanged. Other dirty CeTA
source files exist in the shared tree and are not changes from this recovery.
No commit is made while full modular recovery remains incomplete.

## Latest continuation: v83–v110

- Full CSR v83: **110/110**, 105 YES and five NO, 100 seconds; all 110
  certificates passed two further independent checks.
- Full Innermost v76: **309/366**, 299 YES and ten NO, no checker failures.
  The two losses were Ex1_GM99_C and Ex1_GM99_iGM. Both subsequently
  certified in v96 (the 57 previously Unknown roots yielded two YES).
  A final single frozen-binary full replay is still required.
- Standard v80 recovered Ex14_Luc06_C and Ex9_Luc04_C using native
  conditional semantic-label models. v89 recovered three further roots
  after top-level rule-removal extraction used alpha-equivalent multiset
  subtraction instead of literal XML equality. No complete-proof shortcuts
  were restored.
- Exact rewriting now freshens rewrite-rule variables away from live pair
  variables before substitution. The focused capture regression passes;
  broad diagnostic v101 certifies Mixed_TRS/7, tpa1 and otto04 again.
- Cons-encoded match-bounds is reachable through the native synthesis atom.
  Exact replay can also reconstruct a unary automaton candidate from a
  ranked witness, independently validate SRS compatibility, and lift it back
  using the existing ranked construction. Deduplicating candidate transitions
  reduced the z30 certificate from 31 MiB to 697 KiB. The resulting native
  terminal passed CeTA twice (`z30-certified-terminal-v104`); oracle-root
  replay v110 is running. The synthesis diagnostic was stopped after
  overrunning its local allowance; it is not credited as solved.
- Narrowing now uses certified active R for both search and exact replay,
  while retaining the independent Q context. This fixes AAECC-ring's local
  step 18; full-chain extraction is `aaecc-active-direct-v109`.
- Serial v106 tests: **914 passed, zero failed, zero ignored**. This
  predates the latest active-R narrowing change, whose tests are separate.

The broad v101 Standard run is diagnostic: its selection omitted the four
baseline timeouts (1,538 rather than 1,542 inputs), and the release path was
rebuilt during the run. Do not publish it as a frozen category high-water
mark. Final validation must explicitly include every baseline status and
use an immutable binary. A frozen pre-narrowing binary is `ferrum-v104`,
SHA-256 `35f8804e07793d889a34495a60cecb12f1b8796560a8d20c3aee38f63010f51b`.
Latest merged experimental oracle: v105. Production oracle and CeTA are
unchanged, and nothing is committed while full recovery remains incomplete.

## Latest continuation: v59–v67

**v72 Innermost recovery:** LengthOfFiniteLists_nokinds_iGM now completes
oracle-only in 164 seconds and its full CPF passed CeTA, followed by two
additional independent checks. The explicit alpha-merge at direct step 35
restored all 60 transformations and 12 terminal steps. Full Innermost v76
is running to verify complete-category parity rather than infer it from
this isolated result.

**v73 native vocabulary:** added finite-model `IfEqual` to the semantic
labeling proof model, evaluator, CPF writer, direct-SAT/SMT model evaluation,
and local CPF extraction. Evaluation matches CeTA's carrier-reduced
comparison in `Semantic_Labeling_Carrier.thy`; there are no checker changes.
The focused conditional regression, 25 semantic-labeling tests, 191 Python
extractor tests, cargo check and release build pass. Direct v74 extraction
now executes semantic labeling for Ex14_Luc06_C and Ex9_Luc04_C, where it
previously reported missing-local-action. Full root certification remains
pending; Ex9 still has an open local empty-pair step.

v65 added no roots over v59. The remaining 26 Standard roots are now being
tested using explicit-alpha diagnostics v71 and conditional-model evidence.
The exporter retains newly observed alpha-merge actions as weak guidance,
never source-certified solved states. New experimental union: v79.

The v59 remaining-Standard replay certified 11 of the 37 selected roots,
with 19 Unknown, seven timeouts and zero certification failures. This is a
lost-root slice, not a new complete-category total. Artifacts:
`target/modular-recovery-r985/remaining-standard-v59`.

The latest serial library suite passed **911 tests, zero failures and zero
ignored**, in 131.57 seconds (`full-library-serial-v59.log`). CSR remains
verified at 110/110 in v52, with all certificates rechecked twice. The
four-root Innermost v51 replay finished 3/4; LengthOfFiniteLists_nokinds_iGM
still timed out at 1,200 seconds.

Fixed terminal recovery stopping at the first Ferrum-positive but
checker-rejected candidate. It now tries remaining native candidates and
promotes only after two successful checks of an unchanged certificate.
Attempt-specific rejection logs are retained. The focused mocked regression
checks rejection followed by a twice-certified alternative. The corrected
v60 pass certified 190/208 sampled terminal states (v56: 183/204; v60 also
includes a later completed root). These are local states, not root gains.
The monotone experimental union is `oracle-direct-native-v63.jsonl`;
the next 26-root no-fallback Standard replay is `remaining-standard-v65`.

Direct live-input extraction for the remaining Innermost root reached a
concrete mismatch: local step 38 expects 27 source pairs but the live state
has 35, with 36 active rules on both sides. No side condition was relaxed.
`innermost-live-alpha-v67` tests the existing explicit alpha-merge processor
before these actions; this is a diagnostic hypothesis, not yet a recovery.
`innermost-live-length-v61` and `innermost-terminals-v64` retain the original
live chain and its 11/12 independently certified terminal attempts.

Production oracle and CeTA remain unchanged. No commit or full-recovery
claim is made while the remaining losses are unresolved.

## Latest modular recovery checkpoint (2026-09-09, v40 in progress)

### Subsequent v40–v50 diagnostics

**Resolved in v52:** full CSR replay is again **110/110 (105 YES, five NO)**,
with zero checker failures, in 96 seconds. All 110 CPFs passed two additional
independent checks (`full-csr-v52/rechecks.jsonl`). `csrdiv-v52` certifies its
recursive typed proof in about seven seconds. Source/live graph comparison
now agrees on the explicitly emitted auxiliary replacement map; absent maps
still retain the conservative default-active edge. No CeTA change was needed.

The experimental union has advanced to `oracle-direct-native-v53.jsonl`,
promoting source-gated modular actions from the six certified alpha-guard roots
and the recovered csrdiv proof. It contains no complete termination actions.
The 37 remaining Standard roots are being replayed in `remaining-standard-v53`.
`direct-live-roots-v54` also explores those source CPFs from the actual recorded
live root inputs, retaining runtime order and generated-symbol effects.
The final Innermost loss is still running in `innermost-losses-v51` with a
1,200-second allowance; its other three roots certify.

Python regression subset now has 216 passes. Later concurrent library runs
had isolated nontermf/incremental-SMT failures which passed immediate isolated
repeats. `full-library-serial-v52.log` records the serial full-suite check still
in progress; these tests are not ignored. No commit yet: full recovery and
final stable verification remain outstanding.

**v56–v59 update:** all three Applicative_first_order_05/#3.10,#3.55,#3.57
now certify (`uncurry-v56`). The missing #3.10 leaf closes with freshly
computed native SCT, independently checked twice. The broader native terminal
batch has certified 183/204 sampled local states across 35 roots, twice each;
failed alternatives were not promoted. These local entries and live-root
observations form `oracle-direct-native-v58.jsonl`; the next unresolved-root
replay is `remaining-standard-v59`.

The serial v52 full suite completed with 911 passes and no ignored tests.
It also exposed needless expensive canonicalization in narrowing candidate
deduplication/ordering. Cheap literal/variable-alpha deduplication and term-tree
shape buckets now precede exact symbol canonicalization; exact canonical keys
remain the authority for ambiguous buckets and sorting ties. The existing
nine-alternative narrowing regression dropped from minutes to under 0.01s.
The established Innermost candidate key order is preserved. A superseded owned
v57 test process was stopped after the newer regression passed; artifacts were
retained. `full-library-serial-v59.log` checks the final optimization.

- The completed v40 Standard loss slice certified 104/141. Against v32 it
  recovered MNZ_10/1,2,3,8,labelled, but lost Secret_07_TRS/5 and aprove01.
  Isolated t009 also certifies (31 seconds), but timed out in the loaded slice.
  Thus 100% recovery is not yet established, even on the fixed loss slice.
- `labelled` passed the independent second CeTA check. Measured end-to-end
  replay fell from roughly 357 seconds to 164, 135, and finally 49 seconds as
  immutable queued inputs, retained certificates and exact ancestry strings
  were shared across alternatives. No search branch or proof check was removed.
- Adding recursive top-level `uncurry` rows and canonical native-action hints
  recovered Applicative_first_order_05/#3.55 and #3.57 (`uncurry-v44`). #3.10
  reaches its DP proof but still has an unguided residual.
- Full CSR v40 was 109/110, losing csrdiv. Its legacy ordinary-proof wrapper
  invokes CSR U3 and CSR instantiation inside CeTA, not unrestricted ordinary
  instantiation. `normalize_recursive_csr_cpf.py` translated the recognized
  recursive syntax into typed CSR processors; source and translation each
  passed CeTA twice (`csrdiv-typed-source-v45`). This is not yet a claim of
  recovered root replay.
- The typed path exposed a frozen-map bug: materialization discarded an
  explicit fresh-U replacement-map entry, while graph checks assumed the
  absent/default-active case. Parser and graph checks now distinguish these
  contexts. Exact graph validation uses the explicit frozen map emitted by
  the CSR root/input writers. The prior default-active edge regression still
  passes, and its explicit-frozen counterpart rejects that edge. Canonical
  materialization is again idempotent after preserving the auxiliary entry.
- All local csrdiv actions now have a linked native path through graph,
  U3, instantiation and terminal leaves (`direct-csrdiv-live-v49`). Complete
  oracle lookup/reconstruction is still under test in `csrdiv-v50`.
- Full library v41: 910 passed. The later v49 suite exposed two failures:
  auxiliary-map canonicalization (fixed and individually passing), and an
  old shape-only test that replaced an arbitrary self-loop with an uncovered
  constructor instance. The latter now explicitly tests rejection under the
  coverage check; it is not ignored. A new complete suite remains required.
  Python regression subset: 214 passed. CeTA sources remain unchanged.

The latest experimental union is `oracle-direct-native-v50.jsonl`; production
v54 and the committed r982 baseline remain untouched. No commit has been made.

The authoritative complete-proof-enabled baseline remains r982; none of the
partial modular runs below replaces it. Complete DP/TRS termination atoms stay
disabled, and no CeTA source or production oracle was changed.

- Full modular CSR replay `full-csr-v32` retains 110/110 certified decisions.
- Full modular Innermost replay `full-innermost-v13` retains 310/366; the
  remaining baseline loss is `LengthOfFiniteLists_nokinds_iGM`.
- The 141-root Standard loss slice reached 103 certified in v23. Version v32
  had 101: it gained thiemann06 and Beerendonk_07/18 but lost MNZ_10/1,2,3,8.
  These are slice counts, not fresh full Standard totals.
- `alpha-guard-v38` recovers t009 with a complete modular proof, CeTA-certified
  in 31.48 seconds. The MNZ losses are missing guidance at newly literal
  narrowing child boundaries, not grounds for reverting context preservation.
- Alpha-equivalent pair merging is now a separate `alpha-merge` processor,
  reconstructed with native CPF instantiation. It does not change indexed
  ordinary instantiation candidate ordering. Exact instantiation now checks
  instancehood and CeTA-compatible coverage before returning a child.
- MNZ_10/labelled has 560 independently certified native SCT child proofs
  (`labelled-native-terminals-v34`) plus three runtime representation variants
  (`labelled-three-live-certified-v35`). Each passed CeTA twice. All 560 runtime
  child keys are covered. The 300-second run closed 436 leaves before timeout;
  the longer v38 run reached all 560. Root certification is still pending.
- Timing exposed deep copies of queued immutable states when retaining
  worklist alternatives. Sharing those inputs with `Arc` leaves independent
  cursors, ancestry and backtracking intact. Sixteen worklist-filtered tests
  passed; a dedicated sharing regression and affected-root replay are running.

The current experimental union is `oracle-direct-native-v40.jsonl`. Direct
CPF extraction from the remaining roots contributes 1,603 state records and
676 local witnesses, source-gated by two independent full-CPF checks; open
transformations remain weak hints, not certified solved states. Standalone
alpha-merge observations are similarly weak. No complete termination atom is
reintroduced. Final category replays, all-root second checks, and a stable
commit remain outstanding.

All paths in this section are below `target/modular-recovery-r985`.

Goal: recover r982's 1338 Standard, 311 Innermost and 110 CSR decisions without
`exact-trs-proof` or `exact-dp-proof`, and without fallback. Production v54 is
untouched. CeTA source/binary is unchanged; certification uses CeTA-CSR/ceta.
This page is a work log, not a new high-water mark.

## Verified progress

The r984 ablation lost 141 Standard roots, four Innermost timeout roots and
CSR `Maude_06/csrdiv`. See `complete-trs-proof-ablation.md` for the full baseline.

On those same 146 roots, with a 180-second strategy/185-second harness:

| Recovery replay | Standard recovered | Innermost recovered | CSR recovered | Checker failures |
| --- | ---: | ---: | ---: | ---: |
| r985 replay-v1 | 14 | 3 | 0 | 0 |
| r985 replay-v2 | 22 | 3 | 0 | 0 |
| r985 replay-v3 | 28 | 3 | 0 | 0 |
| r985 replay-v4 | 38 | 3 | 0 | 0 |
| r985 replay-v5 | 41 | 3 | 0 | 0 |
| r985 replay-v6 | 46 | 3 | 1 | 0 |
| r985 replay-v7 | 54 | 3 | 1 | 0 |
| r985 replay-v8 | 56 | 3 | 1 | 1 |
| r985 replay-v9 | 63 | 3 | 1 | 0 |
| r985 replay-v10 | 66 | 3 | 1 | 2 |
| r985 replay-v11 | 71 | 3 | 1 | 0 |
| r985 replay-v12 | 73 | 3 | 1 | 0 |
| r985 replay-v13 | 75 | 3 | 1 | 0 |
| r985 replay-v14 | 77 | 3 | 1 | 0 |
| r985 replay-v15 | 79 | 3 | 1 | 0 |
| r985 replay-v16 | 79 | 3 | 1 | 0 |
| direct-native-v4 | 83 | 3 | 1 | 0 |
| direct-canonical-v5 | 84 | 3 | 1 | 0 |
| direct-native-v13 | 95 | (full guard below) | (full guard below) | 0 |
| direct-native-v19 | 100 | (lenient guard running) | (new guard due) | 0 |
| direct-native-v23 | 103 | (310-root guard below) | 110/110 full guard | 0 |

v23 gained three roots with no losses against v19. The outstanding t009 loss
also timed out at 600 seconds (`t009-guard-v22`); it remains unresolved.
`innermost-lenient-v19` recovered three of the four ablated roots, but
LengthOfFiniteLists_nokinds_iGM still timed out at 600 seconds. No full
Standard parity or final commit is claimed.

`direct-labelled-sct-v24` exports the 560 independently checked native SCT
leaf actions as weak hints after two source checks. Bounded per-state
canonicalization parallelism replaces its superseded serial v20 job (stopped;
artifacts retained). `direct-remaining-v22` has completed 37 source shards;
`direct-remaining-weak-v23` imports their observed corrected states.

The narrowing reconstruction now uses the selected CPF pair and complete
narrowing set to reconstruct its literal child, preserving alpha-variant
rules like instantiation. thiemann06 step 58 now transforms, but the next
graph/continuation remains unresolved; do not claim its 72-step chain closed.
Inapplicable one-child wrappers may supply a search attempt for the next
action on the unchanged full native state. No skipped wrapper is credited
as a transformation. Every action and final root must still validate.
202 Python tests pass. CeTA is unchanged.

v19 has six gains and one timeout loss (`HirokawaMiddeldorp_04/t009`) against
v13. The loss remains a regression until independently restored; it is not
erased by the net gain. `direct-remaining-v22` directly re-materializes the
41 unresolved Standard roots using the corrected native boundaries.

`replay-direct-native-v13/standard` gained eleven roots and lost none against
direct-canonical-v5. `full-csr-v13` certified 110/110 (also 110 independent
second checks). `full-innermost-v13` certified 310/366, preserving all but
`LengthOfFiniteLists_nokinds_iGM` from the 311-root baseline; that root timed
out. A lenient 600-second focused guard is running. These guards predate the
subsequent graph-completeness fix.

The source-direct exporter now supports `--baseline --ceta`: it derives
local actions directly from each retained CPF after two checks, records the
source digest/check outputs, and verifies that the source did not change.
`direct-source-all-v17.sources.json` records all 146 checks. The emitted
native-state hints remain weak, with zero certification credit.

Two targeted thiemann06 reconstructions (`thiemann06-source-v16` and
`thiemann06-literal-boundary-v18`) were **checker-rejected**, not recovered.
Instantiation now retains literally distinct alpha-variant rules, and exact
graph replay recomputes a complete local graph when the extracted partition
omits live pairs. The targeted `thiemann06-total-graph-v19` is UNKNOWN with
no checker rejection; its newly exposed continuation needs guidance.
Regression coverage checks both the literal instantiation child and inclusion
of the omitted acyclic component in graph reconstruction. 94 exact-filtered
Rust tests, 28 lookup tests, the graph-shape test, and 201 Python tests pass.

Exact SCT aliases now retain the local witness: the native processor already
bijectively reassigns its graphs to live pairs, rechecks every subterm edge,
and checks closure against the live dependency graph. It does not trust the
source indices. Exact subterm witnesses still remain representation-bound.

These are recoveries in the fixed lost-root slice, not new full-category
totals. The separate `full-csr-v6` modular replay certified all 110 CSR roots
(105 YES, five NO). Complete category guards after the newest lookup changes
remain outstanding.

The direct-native v13 overlay also retains 560 independently addressable
children from MNZ/labelled's large graph probe. Its source was checked twice;
the child hints carry **zero certified credit**. Native probe observations
add full-context canonical aliases. Source action identity ignores XML
indentation only, preserving names and all context/witness data. An unmatched
usable-rule witness is not promoted: a source-family-gated native
`usable-rules` hint recomputes the live closure instead. This addresses the
missing step 29 in thiemann06's direct chain; successful root replay is still
required. No complete termination-proof shortcut is enabled.

## Direct CPF decomposition, September 9

Root-replay waves stalled at v16. `probe_complete_cpf_steps.py` now walks
the retained complete CPF and independently materializes its local actions.
With `--follow-children`, each continuation receives the native predecessor's
child, retaining runtime contexts that cannot be recovered by just copying
the printed CPF fields. Unavailable parent links are explicitly recorded;
they are not counted as complete connected chains. No composite termination
action is admitted. The source-checking extractor remains the promotion gate.

This recovered z12: `z12-direct-linked-replay` is certified YES, and
`z12-direct-linked-recheck-{1,2}.log` both say CERTIFIED. Independent probing
of disconnected CPF states alone did not recover this root. The linked
native-state propagation is essential.

Fixed a concrete `probe-cpf` boundary defect: both DP probe paths silently
filtered non-DP children out of their residual vectors. QDP-to-SRS therefore
failed with "transformed probe CPF did not expose child obligations".
They now serialize every typed child. The z12 QDP-to-SRS local probe transforms
successfully. Existing probe contract tests (3) and Python tests (196) pass.

Nested CSR-GM child construction now optionally executes its native local
transformation directly; it no longer requires a historical runtime trace.
The direct batch is `direct-all-linked-v2`; diagnostics carry no certification
credit, and only twice-source-checked extractor output can enter an overlay.
No CeTA changes. Full category parity is not yet established.

The direct audit exposed two additional extraction defects:

- `normalized_rule_signature` discarded structured symbol labels, and
  `subtract_alpha_equivalent_rules` deliberately used an unlabeled signature.
  Both now preserve label identity during subtraction. The label regression
  checks that deleting a rule labeled 1 retains the distinct rule labeled 0.
  z21's previously missing graph actions now materialize through to a solved
  final size-change step (`direct-z21-label-fixed`); full replay remains due.
- Diagnostic child events initially used a re-canonicalized hash rather than
  the native serialized-CPF hash used in runtime events. The clean-room
  `replay-direct-label-safe-snapshot` therefore is NOT a parity replay or new
  baseline. `rekey_direct_cpf_events.py` recovers native addresses from existing
  diagnostics without rerunning probes; `direct-native-keys-v4` rechecks source
  CPFs and re-exports those records. No source proof or production oracle was
  overwritten. The next overlay is monotone over v16 to retain established
  replay coverage while adding the directly reconstructed continuations.

Current focused verification: 198 Python tests, four native probe-contract
tests, release build and diff checks pass. Two obsolete direct passes were
terminated with their artifacts retained; the corrected pass remains active.

`replay-direct-native-v4` finished with 83/141 Standard recoveries, 3/4
Innermost and 1/1 CSR, zero checker failures. This is still the lost-root slice.
For thiemann06, the missing live state's full canonical CPF exactly equals
the directly materialized state at step 19, but no canonical alias had been
exported after raw-state rebinding. `export_canonical_modular_aliases.py`
exports full-context aliases only for the source-bound local exact DP,
graph, transformation, reduction-pair and semantic-labeling actions. Source
payloads remain unchanged and native applicability checks remain mandatory.
`direct-canonical-aliases-v5` is the source-gated alias pass; no context field
is stripped. The resulting replay is pending.

On September 9, waves 14–16 continue the growing frontier. Six extraction
timeouts from v13 receive a separate two-worker, 900-second-per-root retry
(`slow-shards-v13-retry`); incomplete timed-out shards are never integrated.

z12 exposed another missing standalone domain: flat-context closure accepted
relative systems but not ordinary full-rewriting TRSs/SRSs. The ordinary case
now uses an empty weak partition and returns an ordinary child. Innermost
inputs remain inapplicable. All four closure tests pass; a generated ordinary
proof passed production CeTA twice (`flat-context-synthetic.ceta-*.log`).
The initial z12 replay remains Unknown, with newly exposed children awaiting
extraction (`z12-flat-context-extracted`). No CeTA changes were needed.

The v8 Ex8_BLR02_C rejection was a transported-witness symbol collision;
freshening unused colliding symbols fixed it, and the focused replay passed
two independent CeTA checks (`collision-replay`, `collision-recheck-*.log`).
The v10 Beerendonk_07/{11,12} rejections are under investigation: strict/bound
pair witnesses must use the live rule variables, not merely select pairs
modulo alpha equivalence. Rejected results are excluded from recovery counts.
The repaired exporter recovered both in `general-split-replay` (2/2 certified);
both certificates subsequently passed two independent CeTA checks each.
All 20 general reduction-pair unit tests pass. These two focused recoveries
are additional to v10's 66; a new combined replay is still required.

Native whole-TRS root labeling is now implemented as `trs-root-labeling`.
The root-preserving model regression passes, its synthetic native proof passed
CeTA twice (`trs-root-label-positive2.ceta-*.log`), and z12's retained step
materializes a child. Full z12 continuation recovery remains pending.

The subsequent `csr-r6-replay` independently recovered and certified `csrdiv`.
Its final graph child had been suppressed by strict replay's unguided-child
guard; reconstructing encoded children exposed the exact missing state. This
closes the ablated CSR loss. The subsequent full `full-csr-v6` replay achieved
110/110 certified (105 YES, 5 NO), zero timeouts and zero checker failures, in
88 seconds aggregate wall time with eight workers. Both complete termination
proof kinds remained disabled. This is an experimental modular-only control,
not a replacement for the committed production oracle.

These are recoveries in the lost-root slice, not full-category certified totals.
Production-oracle controls with the modified binary retained CSR 110/110;
Innermost retained 310/366 in batch with one timeout and no checker failures;
the unchanged 60/65-second isolated PALINDROME repeat certified, restoring the
control root set to 311/366. No claim of restored modular parity is made yet.

## Standalone processor audit

Four retained certified Standard proofs contain `complexConstantRemovalProc`,
which is absent from Ferrum's standalone processor vocabulary and from the
extractor's child-state reconstruction: AProVE_07/{thiemann19, thiemann23,
thiemann32, thiemann33}. Asked the user whether to implement a general modular
processor (recommended) or first search for alternative proofs with existing
processors. The user authorized implementing this and any other missing
standalone processor found in retained TRS/DP composites.

Complex-constant removal now has a native one-step validator and residual
builder, accessed through `exact-dp-transform`. The local payload contains a
ground term and pair map, never a recursive proof. All four independently
materialized retained steps return a transformed child. Two positive/rejection
Rust tests pass. A native reconstruction/positive plus mutation-negative CeTA
test also passes (the positive is checked twice). Wave seven recovered complete
modular `thiemann19` and `thiemann23` proofs; both were independently rechecked
twice, all CERTIFIED. The other two roots still require continuation recovery.
The current confluence branch supports ground normal forms or weakly orthogonal
active rules; nontrivial innermost critical-pair joining remains an explicit
completeness limitation. No CeTA change is required.

DP-level Q increase is now a first-class nontermination proof node and native
one-step action. It unions Q, preserves NFS, drops minimality, and merges P/Pw
and R/Rw exactly as CeTA's processor specifies. Reconstruction rejects YES
children. All three retained steps independently materialize their child;
the context/polarity regression passes. Their full modular replay remains due.

`materialize_modular_processor_probes.py` records standalone input/action probes.
Its optional diagnostic retained-continuation mode is **not oracle evidence**.
Those early diagnostic compositions currently fail at the retained whole-child
proof matcher; they were not integrated or counted as certified. Native complete
oracle reconstruction for thiemann19/23 and the synthetic CeTA regression provide
the successful certification checks instead.

An inventory of r982 CPF children found 4 `complexConstantRemovalProc`,
3 `innermostLhssIncreaseProc`, 2 `notWNTreeAutomaton`, and 2
`nonterminatingSRS` occurrences. The latter three tags are still being audited
for standalone execution/extraction. Existing `bounds`, `relativeBounds`,
`flatContextClosure`, semantic labeling, and general reduction pairs also need
boundary-level checks; occurrence of a tag alone does not establish a missing
native processor. `finitenessAssumption` inside the older GM04 encoding is a
theorem-private obligation, not a standalone solved processor.

## Changes

- `exact-path-order-removal` optionally carries `source-hex`, a complete source
  TRS input. Replay checks source/live isomorphism and transports model symbols
  and deletion indices together. Selected actions carry the live source onward.
- Legacy deletion witnesses missing the live signature are rejected rather than
  emitting the known invalid uncurrying/path-order CPF. The previously rejected
  `Applicative_first_order_05/30` now replays modularly and passes CeTA.
- Full-CSR materialization no longer unconditionally asserts normal-form
  substitutions. That default invented an empty-Q/NF restriction after an
  ordinary-DP bridge. Explicit Q is retained. A focused regression covers this.
- Contextless matching strips provenance before canonicalizing, preserves Q,
  then normalizes serialization whitespace. Full state validation still belongs
  to each processor; this helper is not itself a runtime oracle key.
- Explicit runtime event files are not discarded by benchmark-path filtering.
- Extraction runs in independent root shards. Large unrelated encoded-child
  reconstruction can be skipped while all recorded live input/residual states
  remain indexed. Pure exact-action fingerprints have bounded caches.
- Full GM04 inverse certificates now expose the source CSR and the non-top
  administrative TRS as separate children, in native processor order. This
  previously missing extraction path produced no local events for three roots.
  A renamed-symbol regression covers administrative rule deletion and child
  indexing. The new extraction produces events from twice-certified sources;
  successful complete replay of these chains is still being tested.

## 2026-09-09 integration recovery (v101–v161, incomplete)

The broad v101 diagnostic replay certified 1,320 Standard roots, with 18 losses
against r982 and no gains. It covered only 1,538 inputs (the default details
selector omitted four baseline timeouts), and its binary changed during the
run. It is not an authoritative frozen full-category replay.

Subsequent global no-fallback modular checks recovered twelve of those losses:

- v129: AAECC-ring; v130: Beerendonk_07/19.
- v137: factorial2, thiemann01, aprove4, double, jwteparla1, jwteparla2.
- v147: tower_sizeChange, LengthOfFiniteLists_complete_noand_C,
  OvConsOS_complete_noand_C.
- v159: Ex5_DLMMU04_iGM (also retained AAECC-ring and Beerendonk/19).

This establishes cumulative targeted coverage of 1,332/1,338 baseline roots,
not a new full replay score. Liveness6.4 additionally passes isolated modular
replay; its latest global check is still required. The other remaining roots
are thiemann02, Ex9Maps, MYNAT_complete_C, OvConsOS_complete_noand_GM, and
OvConsOS_nokinds_FR. No complete DP/TRS termination atom was re-enabled.

The integration defect was dropping live nested-state keys when replacing a
tested modular oracle by its CPF re-extraction. Credit manifests now retain
checksummed tested guidance alongside checked structural extraction, without
promoting weak guidance. They also retain checksummed event logs for explicit
state-local replay ordering. `replay_order` only orders already-positive
candidates: it cannot import an action, promote a weak transformation, or
override a checker invalidation. This recovers the tested alpha-merge chain
before older expansive transformations. CPF alias variants sharing a row id
are no longer collapsed during structural transition-edge matching.

Other corrections: semantic-label extraction clears stale unlabeled active R;
DP switchInnermost extraction establishes innermost strategy and the native
active-R/Q context; exact top-level path-order removal supplies the unique
empty filter for omitted constants while rejecting missing non-nullary
filters. The existing native exact-KBO atom now receives retained top-level
KBO witnesses (only supported variable weight one, without filtering).

CSR v83 remains a full 110/110 replay, all checked twice. Innermost v76 plus
v96 covers all 311 baseline certified roots; a final single full run remains
required. Final binary/oracle freezing, all-category replay and full tests are
still outstanding. Latest frozen test binary: `ferrum-v158`; global modular
oracle: `oracle-direct-native-v156.jsonl`, both under the artifact tree below.
No CeTA changes and no commits in this recovery pass.

## Evidence handling and artifacts

`scripts/build_modular_proof_overlay.py` requires a matching state/action gate
from a source proof checked twice, rejects whole termination-proof actions, and
retains multiple actions per state. It does not invent aliases. Monotone merges
preserve older evidence and append recovered local candidates.

`scripts/extract_modular_recovery_shards.py` runs bounded-concurrency per-root
extractions, keeping independent logs and manifests. Completed shards can be
consumed before expensive roots finish. Superseded serial jobs and duplicate
historical MNZ/labelled scans were stopped; partial artifacts were retained.

Root artifact tree: `target/modular-recovery-r985`.

- `shards`, `shards-v2`, `shards-v3`, `shards-v4`: successive source-proof
  extraction and live-state binding.
- `replay-v1`, `replay-v2`, `replay-v3`: certified lost-root replay details.
- `oracle-shards-v1.jsonl`, `oracle-shards-v2.jsonl`, `oracle-shards-v3.jsonl`:
  experimental modular-only unions.
- `csr-source-probe`, `csr-fixed-replay`: CSR boundary diagnostics. An open
  source-checked reduction-pair probe is explicitly weak evidence, not a solved
  state or certified root.
- `production-guard`: unchanged-v54 control replays.

Verification so far: 21 path-order tests, 141 CSR-filtered tests, the focused
full-CSR materialization regression, and 190 Python tests pass. Full parity and
final full-suite verification remain outstanding. Changes are not committed.
