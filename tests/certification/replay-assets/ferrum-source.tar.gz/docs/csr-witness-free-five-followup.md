# Five remaining witness-free CSR roots: follow-up

Historical checkpoint. The remaining WPO and rational-synthesis gaps described
below are subsequently recovered by native synthesis; see
[the WPO/sparse-quadratic follow-up](native-wpo-and-sparse-quadratic.md) and
[the authoritative current totals](state-of-the-art.md).

Artifacts: `target/csr-five-recovery-20260916/`.
Starting baseline: 105/110 parameter-only, no-fallback, certified CSR roots.
The separate production oracle already covers all 110 with retained witnesses.

**Final complete replay: 106/110 (101 YES, five NO), zero losses.** The gain
is csrdiv. All 106 CPFs certify twice; four roots remain Unknown and none
time out. Artifacts: `parameter-v3/details.json`,
`parameter-v3-comparison.json`, `parameter-v3-rechecks.jsonl`.
This run takes 113 seconds overall; csrdiv takes 4.769 seconds and the
prioritized OvConsOS_complete-noand takes 5.886 seconds including harness
overhead. Both use only parameterized state-local actions and no fallback.

## csrdiv: matching residuals and native closure

The four-pair child `d98b838e1821…` is byte-identical to a state in the retained
certified proof, not merely similar modulo renaming. Its recorded continuation
is graph decomposition, size change on one SCC, and a rational polynomial
order on the other, followed by another graph step. Native synthesis reproduces
this closure in 108 ms (`csrdiv-known-child.*`). Instantiating its predecessor
also closes in 108 ms (`csrdiv-close.*`). All these proofs passed production
CeTA twice. No supplied order interpretation is used.

Starting earlier, native max-polynomial deletion reduces the seven-pair
component through six/five/four-pair states. Instantiation then reaches that
known child. The full local chain certifies (`csrdiv-seven.*`). Its successful
actions were converted to state-local parameter guidance with zero independent
event certification credit, not a retained pipeline or composite proof.

The root replay initially still failed: native graph search used the source
map's default activity for the fresh improved-CS-DP unhiding wrapper, whereas
the CPF writers and exact-graph validator explicitly freeze that wrapper.
This made identical serialized residuals behave differently live and after
materialization. Both graph processors now share `checker_graph_stats`, using
the existing emitted/checker map. Source rules
and original-symbol replacement-map entries are not altered. A synthetic
regression checks live/materialized agreement and source-map immutability.

`csrdiv-root-fixed.xml` is a complete original-root, parameter-only,
no-fallback proof accepted twice by unchanged production CeTA-CSR.

The first implementation also detached native CSR graph caches unnecessarily.
The initial aggregate run therefore lost LISTUTILITIES_complete: a reordered
78-pair graph component perturbed Arctic synthesis and exposed unguided
children. The final implementation preserves native context-keyed cache
reuse; only exact-witness validation retains its existing fresh graph check.
Both `list-v2.xml` and `csrdiv-v2.xml` certify twice with the final build.
The earlier aggregate 105/110 run is retained, not counted as an improvement.

The next aggregate restored LISTUTILITIES but exhausted the deadline on
OvConsOS_complete-noand's earlier search alternatives. Tracing the previous
certified proof identifies native polynomial candidate 9 at the original
root, then a bounded 2D matrix action at child `25ad74da1143…`. Both actions
remain parameter-only and carry zero independent certification credit.
State-local `replay_order` digests now prioritize them; no pipeline or model
assignment was retained. `ovcons-digest-ordered.xml` certifies twice; its first
two synthesis steps take about 84 ms and 121 ms. `parameter-v17.jsonl` records
this ordering. The exploratory v16 mistakenly used action strings rather
than digests and is superseded, not promoted.

## Ex5: not a checker rejection

`ex5-long.events.jsonl` in the preceding campaign shows successful native pair
deletions. Its final `Inapplicable` summary meant that the restricted recursive
continuation did not close; it did not mean the first interpretation was
rejected. Raising the constant bound from 3 to the recorded successor bound 4
did not resolve the singleton component (`ex5-bound4.*`).

The concrete discrepancy is processor vocabulary. The retained singleton
proofs use **filtered weighted path orders**, whose algebraic component is a
max polynomial. The converter incorrectly extracted that component alone as
`max-poly`. The inspected singleton's pure max query is UNSAT
(`ex5-single.progress.jsonl`), while the retained WPO proof certifies.
Native path-order/polynomial alternatives also did not close it.
The later bounded usable-rules/path-order/polynomial/matrix probes on the
Ex3 and Ex5 singleton components also remained inapplicable
(`ex3-alternatives.*`, `ex5-alternatives.*`).

Ferrum can validate/export exact WPO-max witnesses, but has no corresponding
native WPO-max synthesis atom. The converter now declines weighted path orders
and filtered max orders instead of claiming to reproduce them with plain
max-polynomial synthesis. Regression tests cover both wrappers. This fixes a
guidance/search classification defect, not a checker soundness defect.

## Tighter bounds

`tight-results.jsonl` records 14 trials; `small-constant-results.jsonl` records
12 additional trials with Z3 and cvc5. Budgets are 60 seconds per recursive
probe, with two Rayon threads, at most six concurrent probes.

| Root | Result |
| --- | --- |
| Ex3_2_Luc97 | Constants **1**, coefficients **1**, two max alternatives reduce 10 pairs to 5, then 2, then the exact retained singleton `7e82014600e6…`. The three successful synthesis steps total about 286 ms. The old extracted initial constant bound was 48,638. |
| ExIntrod_Zan97 | Tested smaller numerator bounds at denominator 2. Constant 0 is inapplicable; constants 1–2 with coefficient bound 2 still time out with both Z3 and cvc5. No full recovery. |
| emmes | At denominator 4/strict gap 1/4, coefficient numerator bound 2 and constant bound 4 give SMT UNSAT in the existing encoding. Constants 1–2 with coefficient bound 4 still time out with both solvers. No full recovery. |

Ex3's remaining singleton also uses a filtered WPO in the retained proof.
Thus its initial large-constant bottleneck is avoidable, but plain max search
does not implement the final recorded processor. These trials neither prove
that exact witnesses are necessary nor establish global lower bounds on all
possible interpretations. They concern the configured native encodings.

## Verification and checker identity

CeTA source and binary did not change. Certification uses
`/work/dfm/festschrift/CeTA-CSR/ceta` on main at
`73662ec88a74f65187cba6986d300836564b6a59`.
The final library run explicitly sets `CETA_CSR_BIN` to that path and passes
**985 tests**, zero failed or ignored (`library-v2.log`).
The first run had four failures because the test helper preferred the separate
`CeTA/ceta`, which lacks the required CSR/relative-DP input extensions. These
were not ignored; all four pass in the complete production-checker run.
The focused converter/materializer/exporter suite passes 23 Python tests.

The final production guard (`production-v2/details.json`) retains all
**1,759/1,759** roots: 1,338 Standard, 311 Innermost and 110 CSR, with no
missing inputs, losses, polarity changes or uncertified decisions.
`production-v2-rechecks.jsonl` checks every proof twice. The final residual
guards retain **235/235**, also twice certified (`residual-v2-checks.jsonl`,
`child-v2-checks.jsonl`).

Final executable: `ferrum-graph-fixed-v2`, SHA256
`769392ccbc730e95a81e2f445ba0475233f59e09ad5b8bc27bf1bc862aaa6112`.
Experimental parameter oracle: `parameter-v17.jsonl`, SHA256
`63852c1eec196360b0738c99d8766765def961c445f32b234d8a2a9abf5d7450`.
It has no exact strategy atoms, witness references or `hex=` model payloads.
The separate production oracle remains the unchanged v48 snapshot.
