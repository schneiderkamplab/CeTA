# Remaining native Innermost roots: 2026-09-19

Starting complete baseline: 295/311, recorded in `state-of-the-art.md`.
This is a working log, not a replacement for that full-category baseline.

Artifact base: `target/innermost-sixteen-20260919/`.
Prover: `../innermost-residual-sharing-20260917/ferrum-measured-v2`
relative to that artifact base. Production CeTA-CSR is unchanged.
All root runs use native parameter guidance, no fallback; no exact
interpretations or composite proof actions were added.

New individually certified roots:

| Root (Transformed_CSR_innermost_04) | Seconds | Artifact |
| --- | ---: | --- |
| Ex4_DLMMU04_iGM | 6.218 | roots-v1/ |
| Ex1_2_AEL03_GM | 33.915 | roots-v1/ |
| LengthOfFiniteLists_complete_noand_GM | 15.374 | continuations-v5/ |
| OvConsOS_complete_noand_GM | approximately 46 | ovcons-v8/ |

The first two certificates were independently checked twice in
`new-roots-v1-rechecks.jsonl`; the third in
`continuations-v5-rechecks.jsonl`. This gives 298 individually demonstrated
roots before the later OvCons recovery, pending a complete no-loss replay. The earlier `full-v3` run does
not contain the later Length recovery.

Discovery: `probes-v1` certified 13/37 local residuals. Recursive follow-up
`ovcons-probes-v2` closed a five-pair residual, but the subsequent full OvCons
root remained Unknown. `length-probes-v2` closed three further residuals;
their native actions recovered the complete Length GM root. Local residual
certification is never counted as a root result.

`parameter-v6.jsonl` monotonically combines these native hints with the
previous profile. PALINDROME also receives weak, uncertified search hints
for exhausted top-level states; it remains Unknown. The exporter now has
an opt-in `--include-exhausted` option, with a regression verifying that
such hints receive zero certification credit.

An experimental search-local semantic-model candidate cache passed 1,028
library tests, but had zero hits in the targeted Length C run and did not
recover the root. It was removed from the working source; its patch and
test/build logs remain under this artifact base. A started direct-filter
RPO encoding experiment was also removed before use: no incomplete encoder
is enabled or shipped.

Concrete unresolved issues include the non-minimal two-pair semantic-CSR
Length C residual, expensive path-order searches, a 1,158-pair graph in
LISTUTILITIES, and remaining native-generated continuation states. Do not
weaken minimality, Q, or replacement-map obligations to make these pass.

## OvCons search-bound fidelity

The repeated five-pair local closure had exactly the same input key as the
failed guided attempt. Export had tightened the successful weak-polynomial
search from `min-constant=-2` to `-1`, based on the returned model. Keeping
the original native bounds (`max-constant=2,max-coefficient=2`, signature
limits 118/4) recovered the root with no supplied interpretation.
`ovcons-v8-rechecks.jsonl` independently checks its certificate twice.
Four original misses are now individually recovered (299 cumulative).

`parameter-v8.jsonl` contains this correction; `full-v8/` is the complete
no-loss replay. Do not use `parameter-v7`: its experimental timeout wrapper
was not dispatched as a DP atom. `probes-v4/` separately explores the current
remaining frontier with 60-second local allowances and 240-second probe caps.
These runs were still active when this working-log update was written.

## Native closure integration on 2026-10-10

`full-v8` completed at 299/311 with no losses. All 299 proofs passed two
fresh production CeTA-CSR checks. The current integration artifacts are in
`target/innermost-native-closures-20261010/`.

The first targeted integration recovered LengthOfFiniteLists_nokinds_iGM
in 6.852 seconds and MYNAT_nokinds_noand_GM in 49.355 seconds. Both passed
two independent certificate checks (`roots-v1-rechecks.jsonl`).

Ex1_2_AEL03_iGM initially reached an unguided child after native weak-poly
selected a different model under tightened bounds. The hint exporter now
optionally reads the original flat probe recipe using `--search-strategy`.
It retains same-family native parameters as additional untried state-local
hints, without copying models, supplying a compound strategy, assigning
certification credit, or attributing observed timing to untried actions.
Invalid recipes and exact witness atoms are rejected. Five exporter tests
and eighteen frontier tests pass.

With the original bounds retained, Ex1_2_AEL03_iGM certifies in 41.186 seconds
(`roots-v2`). This establishes three new individually certified roots beyond
299, not yet a complete 302 baseline. `full-v3` is the complete replay in
progress. Additional MYNAT iGM residual closures are in `probes-v2` and
`parameter-v4.jsonl`; `mynat-v4` tests their full-root reconstruction.

No Ferrum processor or CeTA source changes were required. The frozen prover
and production checker are unchanged. This update modifies extraction and
oracle data only; complete proof actions remain retired.

The completed `full-v4` replay establishes **303/311**, four gains and zero
losses against 299. All 303 certificates passed two independent rechecks.
MYNAT_nokinds_noand_iGM closed after integrating its 17-pair residuals;
the full-category run certified it in 56.658 seconds. Ex1_2_AEL03_iGM took
136.606 seconds in that run, versus 41 seconds in targeted tests, but closed
without fallback. Native CSR remains 110/110 in a fresh, twice-checked guard.
The baseline ledger records the frozen profile and exact checksums.
