# TermCOMP 2025 Relative Comparison

Run date: 2026-08-13. Ferrum used a 60-second proof-search allowance, an
external 65-second harness ceiling, and 8 workers. Every Ferrum answer was
checked by `/work/dfm/festschrift/CeTA-CSR-relative-adp/ceta`.

The current exact-oracle evaluations cover every problem in the current TPDB
checkout. They retain all per-example output, CPF, checker output, processor
events, commands, and result JSON by default.

## TRS Relative

The TermCOMP 2025 category page lists 126 examples. Ferrum was also run on all
140 examples in the current TPDB checkout; the table restricts Ferrum to the
official 126-example set.

| Tool/configuration | Problems | YES | NO | Certified YES | Certified NO | MAYBE | Timeout | Error |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| AProVE25 uncertified | 126 | 88 | 12 | 0 | 0 | 0 | 11 | 15 |
| AProVE25 certified | 126 | 0 | 0 | 45 | 11 | 0 | 12 | 58 |
| Ferrum, 60 s, 8 workers | 126 | 45 | 13 | 45 | 13 | 3 | 65 | 0 |

The current all-140 exact-oracle replay obtains **45 certified YES, 13
certified NO, and 82 MAYBE**, with no timeout, error, or certification failure.
Artifacts are in
`target/termcomp-runs/20260813-trs-relative-v864-oracle-only-full-8x60s`.

The earlier all-140 run, before relative matrix removal, obtained 7 YES, 1 NO,
38 MAYBE, and 94 timeouts. Matrix removal first raised the official result to
42 YES and 1 NO. Certified transformations and native relative-loop search now
produce 45 YES, 13 NO, 3 MAYBE, and 65 timeouts. There were no certification
failures.

Among AProVE's 45 certified YES examples, the initial Ferrum run certified 7.
The 38 initial misses all use rule removal; 33 use matrix interpretations, 5
use RPO, 4 use semantic labeling, 3 use flat-context closure, and 2 use string
reversal. These counts overlap because proofs combine processors.

The 2026-08-03 relative matrix implementation directly closes 31 of the 33
matrix-proof misses, all CeTA-certified. It supports natural and integer dimension-2
matrices, deletes strictly oriented rules from either the strict or weak
component, and races matrix domains plus the recursive relative processor
portfolio. The focused run is retained at
`target/termcomp-runs/20260803-relative-matrix-parallel-weak33`. The two
initially residual matrix examples, `Relative_05/rt3-4.ari` and
`rt3-5.ari`, now certify after Ferrum's flat-context closure and semantic
labeling transformations. Root-equivalent semantic labeling also closes
`AProVE_24/depGraph.ari`. A prior-miss rerun is recorded below and determines
the updated aggregate score.

AProVE has 11 certified NO proofs, all using loop certificates. Ferrum now
certifies all 11 using native relative loops in which weak steps may connect
strict steps. Grounded rule-side/subterm seeds, fair shallow rewriting, and
weak-first contextual narrowing recover witnesses of length 1 through 5.
Path-sensitive symbolic closure also recovers
`Mixed_relative_TRS/assoc.ari`, whose loop uses a recursive closing
substitution. Ferrum additionally certifies `INVY_15/{ex3,ex6}.ari`, the two NO
answers present in AProVE25's uncertified answer set but absent from its
accepted certified set. Thus Ferrum covers the union of both AProVE NO sets:
13 distinct examples, with CeTA certificates for every one.

### AProVE answers without accepted certificates

Comparing problem keys, rather than only the headline counts, finds 47 AProVE25
answers with no accepted AProVE25_cert artifact: 45 YES and 2 NO. The two NOs
are now recovered certifiedly as described above. All 45 YES examples remain
timeouts in Ferrum's current official result.

AProVE's textual proof evidence makes the missing termination machinery clear:

| Uncertified-only YES class | Examples | Missing certified capability |
| --- | ---: | --- |
| IJCAR 2024 relative annotated dependency pairs | 44 | Canonical relative ADP transformation and dependency graph; first derelatifying processor in 43 proofs; relative ADP reduction pairs for `AProVE_24/divMinusExchange.ari` |
| General finite semantic labeling | 1 | Carrier-two/Boolean model synthesis and full symbol labeling for `Relative_05/rtL-pwl.ari`; Ferrum currently has only root-equivalent labeling |

The relative ADP terminology and processor boundary follow Kassing, Vartanyan,
and Giesl, *A Dependency Pair Framework for Relative Termination of Term
Rewriting* (IJCAR 2024; [paper](https://arxiv.org/abs/2404.15248)).

The 44 ADP proofs combine relative dependency-graph decomposition with ordinary
orders after derelatification: polynomial interpretations occur in all 44, RPO
in 42, usable rules/argument filtering in 22, and KBO in 8. Counts overlap.
Ferrum can reuse those existing certified DP order processors once the
derelatifying step has produced an ordinary DP problem.

Upstream CPF/CeTA does not provide the IJCAR 2024 relative-ADP framework. The
local verified extension described below now covers canonical transformation
and monotone erasure reduction pairs, but not the productive relative graph,
derelatifying processor, or annotated reduction-pair processor. Ordinary
relative `dpTrans` merges `R` and `S` and loses the
distinction on which these proofs rely. Recovering the 44 examples faithfully
therefore requires corresponding CPF syntax and Isabelle/CeTA theorems, not
just more Ferrum search. The semantic-labeling example should require no CeTA
extension because standard CPF semantic labeling already represents the needed
proof shape.

An August 13 production-checker probe confirms that the new annotated Com
reduction-pair path adds four certified proofs when invoked directly:
`AProVE_24/{lessleaves,shuffle_a}.ari` and
`Relative_05/{rt2-2,rt2-3}.ari`. The focused 11-example run has 4 certified
YES, 4 MAYBE, 3 timeout, and no certification failures; its artifacts are in
`target/termcomp-runs/20260813-relative-adp-com-progress11-8x60s`.

A same-day full default-strategy diagnostic produced only 11 certified YES
and 3 certified NO. This is a strategy-scheduling regression, not the updated
official score: processor events show that the nested relative race did not
start `relative-adp` on the four direct successes before recursive
transformation branches consumed the budget. Complete diagnostic artifacts
are retained in
`target/termcomp-runs/20260813-trs-relative-full-com-certified-8x60s`; the
45/13 row above remains the last comparable official baseline until the race
gives every top-level branch its configured budget.

### Relative ADP integration update (2026-08-11)

The canonical A1/A2 transformation and monotone erasure reduction-pair slice
are now exposed through a verified custom CeTA/CPF production. Ferrum and the
integrated checker certify `Relative_05/rt1-3.ari` end to end. This does not
change the table's 45 certified YES score because the same example was already
certified by top-level polynomial rule removal.

The earlier experimental 40-YES/38-erasure report is not valid power evidence:
the old solver encoding allowed zero argument coefficients and therefore did
not satisfy the monotonicity premise. Corrected reprobes retain no such old
erasure witness. Productive SCC/minimal-lasso graph certificates, annotated
`Com` reduction pairs, and DRP1 remain necessary before the 44 AProVE
uncertified-only ADP proofs can be recovered certifiedly. See
`docs/relative-adp-integration-20260811.md` for the exact integration manifest.

## SRS Relative

The category page lists 445 examples, while the final TermCOMP summary contains
443 completed rows and 2 outstanding jobs. The Ferrum row below uses all 445
examples from the page. The current TPDB additionally contains 16
`Endrullis_26` examples.

| Tool/configuration | Problems | YES | NO | Certified YES | Certified NO | MAYBE | Timeout | Error/unsupported |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| Matchbox uncertified | 443 | 341 | 20 | 0 | 0 | 0 | 82 | 0 |
| Matchbox certified | 443 | 0 | 0 | 304 | 21 | 0 | 113 | 5 |
| AProVE25 uncertified | 443 | 77 | 2 | 0 | 0 | 0 | 215 | 149 |
| AProVE25 certified | 443 | 0 | 0 | 164 | 4 | 0 | 75 | 200 |
| Ferrum, certified source replay | 445 | 94 | 0 | 94 | 0 | 351 | 0 | 0 |

On all 461 current TPDB examples, the final v865 replay obtains **95 YES, all
95 certified, and 366 MAYBE**, with no timeout, parse error, or certification
failure. The additional certified current-TPDB win is
`Endrullis_26/Endrullis_2026_SRS_6.ari`. Artifacts are in
`target/termcomp-runs/20260813-srs-relative-v865-oracle-only-full-8x60s`.

### Evidence on the 366 residuals (2026-08-13)

An attempted 300-second search was stopped after 120 of the 366 residuals had
finished: it produced 0 YES, 0 NO, 15 MAYBE, and 105 harness timeouts. The
partial artifacts are retained in
`target/termcomp-runs/20260813-srs-relative-residual366-expensive-8x300s`.
Accumulated processor events show that the extra budget was consumed mainly
by KBO, bounded narrowing, DP loop/nonloop search, rule-subset narrowing, and
large families of polynomial candidates. Increasing the global timeout
without changing the proof classes or their scheduling is therefore not a
productive next step.

The TermCOMP proof corpus was intersected by exact problem key with these 366
residuals. The corpus is retained at
`/work/dfm/festschrift/ferrum/target/termcomp-proof-corpus/artefacts/Y2025/SRS_Relative`.

| Competing result on a Ferrum residual | YES | NO |
| --- | ---: | ---: |
| AProVE25 uncertified | 33 | 2 |
| AProVE25 certified | 99 | 4 |
| Matchbox uncertified | 247 | 20 |
| Matchbox certified | 212 | 21 |
| MnM uncertified | 235 | 19 |
| NaTT uncertified | 15 | 0 |
| Union of accepted AProVE/Matchbox certificates | **217** | **23** |

For certified YES, the union consists of 5 AProVE-only examples, 118
Matchbox-only examples, and 94 examples certified by both. The accepted NO
proofs consist of 2 AProVE-only, 19 Matchbox-only, and 2 shared examples. All
23 certified NO witnesses are explicit relative loops; one first applies
string reversal. This is evidence for strengthening relative loop discovery,
especially longer contextual loops, rather than adding a new checker proof
form.

The 99 certified AProVE YES proofs use the following overlapping processor
classes: rule removal in all 99, root labeling in 81, flat-context closure in
80, polynomial interpretations in 72, string reversal in 66, equality removal
in 42, matrix interpretations in 37, and KBO in 22. Six use a conventional DP
transformation. The common proof shape is reversal and/or flat-context closure,
then root labeling, followed by repeated rule-removal steps. AProVE's root
labeling is not Ferrum's current finite-model semantic-labeling processor.

Of the 212 certified Matchbox YES proofs, 210 parsed into the detailed feature
analysis. All use interpretations; 178 use flat-context closure, 135 finite
semantic labeling, 71 equality removal, 69 reversal, 55 splitting, and 40 a
conventional DP transformation with graph decomposition. Matchbox searches
finite-model carrier sizes 2 through 9, with sizes 4 and 6 especially common;
Ferrum currently schedules only carrier size 2. Its interpretations include
rational matrices in 167 proofs and arctic matrices in 83, with dimensions 1
through 6. Ferrum's present natural/integer dimension-2/3 search covers only a
small part of that class.

The uncertified Matchbox skeletons identify another complementary route. In
the intersecting residual evidence, relative RFC occurs in 122 proofs,
strictification in 101, weighted removal in 84, cleaning in 73, tiling in 63,
mirroring in 63, and context closure in 45. A representative direct case is
`ICFP_2010_relative/107220.ari`: Matchbox strictifies 65 strict plus 8 weak
rules and then closes a relative RFC match-bounds automaton with merge height
2 and 2,886 epsilon transitions. Ferrum lacks the strictification step and its
current RFC witness search is much smaller.

The evidence-ranked next additions are therefore:

1. Root labeling for relative SRSs, nested after reversal and flat-context
   closure and followed by repeated rule removal.
2. Finite semantic-labeling synthesis with carrier sizes 3 through 6 first,
   then up to 9.
3. One-shot rational and arctic matrix rule removal, dimensions 1 through 6,
   plus broader natural/integer matrices.
4. Equality removal and a top-level split processor.
5. Conventional relative/SRS DP transformation, graph decomposition, and
   usable-rule reduction pairs.
6. Certified strictification/cleaning followed by large merge/epsilon relative
   RFC search; then width-2 tiling and weighted transformations.
7. Stronger direct relative-loop construction and a reversal-plus-loop branch
   to recover the 23 already-certified NO residuals.

The standard CPF processors in items 1 through 5 already have accepted CeTA
proof evidence in this corpus. They should primarily require Ferrum synthesis
and CPF emission, not new checker semantics. Matchbox-specific
strictification, cleaning, tiling, and richer RFC witnesses need a separate
audit against the current Ferrum/CeTA RFC extension.

### External-proof-guided custom replays

The first four residuals were replayed one by one using the exact processor
chain and numerical matrix class found in AProVE's accepted CPF:

| Example | AProVE processor chain and parameters | Ferrum custom result | Search diagnosis |
| --- | --- | --- | --- |
| `Waldmann_06_relative/r6.ari` | integer matrix, dimension 3, entries through 3; then dimension 2, entries through 2 | certified YES in 0.105 s | Ferrum synthesized a stronger first matrix which removed both strict rules |
| `Waldmann_06_relative/r10.ari` | reversal; integer matrix, dimension 6, entries 0/1 | certified YES | bounded 6D synthesis timed out at 60 s; AProVE's exact witness closed immediately |
| `Waldmann_06_relative/r5.ari` | reversal; integer matrix, dimension 6, entries 0/1 | certified YES | exact AProVE witness replay |
| `Mixed_relative_SRS/dup03.ari` | integer matrix, dimension 3, entries through 3; then dimension 2, entries through 2 | certified YES | bounded synthesis timed out at 60 s; the exact two-matrix chain closed immediately |

This exercise exposed and fixed a general strategy-continuation defect:
explicit top-level sequences were replaced by the built-in default strategy
after a transformation. Explicit sequences are now retained on residuals;
the existing non-sequential worklist behavior is unchanged. The regression is
`explicit_sequence_is_retained_on_transformed_residuals`.

All four complete CPFs were independently accepted twice while extracting
oracle evidence. The promoted v869 oracle then replayed all four with
`--strategy fail`: 4 certified YES, no fallback, timeout, or checker failure.
No CeTA change was required.

Artifacts:

- custom producing runs:
  `target/termcomp-runs/20260813-srs-relative-custom-aprove-{r6,r10-exact-r3,r5-exact,dup03-exact}`;
- failed broad-search evidence:
  `target/termcomp-runs/20260813-srs-relative-custom-aprove-{r10,dup03}`;
- frozen evidence database and manifests:
  `target/srs-relative-custom-oracle-v866-20260813`;
- promoted oracle:
  `target/srs-relative-custom-oracle-v866-20260813/oracle-global-v869-srs-relative-custom.jsonl`;
- strict replay:
  `target/termcomp-runs/20260813-srs-relative-custom-v869-oracle-only`.

Two correctness fixes were required before importing the historical proofs.
CPF `<relativeBounds>` moves `Rdelete` from strict rules into weak rules and
recurses on `(R \\ Rdelete)/(Rw union Rdelete)`; Ferrum had temporarily used an
ordinary residual. CeTA's executable `fcc_tt` also preserves the strict/weak
partition after flat-context closure; flattening its child to an ordinary
union was an unnecessarily strong obligation. Relative match-bounds now uses
CeTA's complete strict cover check and exact `Weak_TRS c_opt` height rule, so
invalid candidates are rejected inside Ferrum rather than at certification.

Ferrum's production SRS-relative strategy reaches every currently implemented
processor applicable to a relative SRS, including reversal, flat-context
closure, finite semantic labeling, relative order removal, relative ADP, and
relative RFC/match-bounds. The remaining difference is proof-class power and
nested scheduling, not a disabled relative processor. The exact residual
analysis above supersedes the older aggregate comparison against all AProVE
proofs.

## Remaining Relative Gaps

Ordered by expected certified-score impact:

1. Add relative-SRS root labeling and strengthen finite semantic labeling to
   carriers 3 through 9; nest both after reversal/flat-context closure and
   before repeated order removal.
2. Add rational and arctic matrices and broaden matrix dimensions and
   coefficients; then add equality removal and splitting.
3. Strengthen Matchbox-style relative RFC/match-bounds with certified
   strictification/cleaning and substantially larger merge/epsilon automata.
4. Add a conventional relative-SRS DP route with graph decomposition and
   usable-rule reduction pairs, alongside the relative-ADP route.
5. Strengthen relative loop construction, including reversal followed by loop
   search; 23 residual NO examples already have accepted loop certificates.
6. Implement the IJCAR 2024 relative annotated-DP framework in Ferrum and add
   its transformation, graph, derelatifying, and reduction-pair processors to
   CPF/CeTA. This is required for 44 AProVE uncertified-only TRS Relative YESs.

## Artifacts

- Updated TRS Relative:
  `target/termcomp-runs/20260803-trs-relative-parallel-matrix-official-8w-60s`
- Transformation prior-miss rerun:
  `target/termcomp-runs/20260803-trs-relative-fcc-semlab-orders-prior-misses-8w-60s`
- Relative-loop corpus and final residual:
  `target/termcomp-runs/20260803-relative-final-loop-portfolio-no11` and
  `target/termcomp-runs/20260803-relative-loop-20s-shallow-residual2`
- Final coherent 11-example certified-NO replay:
  `target/termcomp-runs/20260803-relative-final-no11-assoc-fixed`
- Additional AProVE uncertified-only NO replay:
  `target/termcomp-runs/20260803-relative-assoc-and-uncertified-no3`
- Initial TRS Relative: `target/termcomp-runs/20260802-relative-60s-8/TRS_Relative`
- SRS Relative: `target/termcomp-runs/20260802-srs-relative-60s-8-scheduled`
- SRS summary and details: `summary.md` and `details.json` in the SRS run
  directory
- Final combined relative oracle:
  `target/srs-relative-oracle-new-win-v865-20260813/oracle-global-v865-relative-new-win.jsonl`
- Corrected 94-proof SRS evidence and raw-state replay:
  `target/srs-relative-oracle-raw-v863-20260813`
- Extracted official problem lists:
  `target/termcomp-runs/20260802-TRS_Relative-official-files.txt` and
  `target/termcomp-runs/20260802-SRS_Relative-official-files.txt`
