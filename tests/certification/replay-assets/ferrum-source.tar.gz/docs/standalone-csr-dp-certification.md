# Standalone CSR-DP certification

Latest update: **the full 14,375-action audit has zero uncertified terminals
and zero certified losses**. All three recorded gap classes are closed. See
[the compact-report follow-up](#compact-report-follow-up),
[the full audit](#2026-09-15-full-post-repair-action-audit),
[the final repair results](#2026-09-15-all-three-recorded-gap-classes-closed)
and [the independent 110-root input audit](csr-root-input-audit.md).

## Earlier checkpoint

Verified 2026-09-15 (artifacts retain their 20260914 start date). The final
guard preserves all 1,759 certified roots, including 110 CSR roots. This is
certification-boundary repair, not a new full-category coverage score.

Implementation commits: Ferrum `743c9a60fbef0ac7311f7bae671e2e8014784d66`
(`codex/aaecc-20260831`), CeTA-CSR
`58632f3b06095922b6443fee5e00662670ce9bcc` (`main`). The refreshed Haskell
export also synchronizes previously committed QDP-to-SRS/GM04 source changes;
unrelated uncommitted ROOT/outermost files were not integrated or committed.

## Boundary and semantics

Four terminal graph actions (audit indices 3, 8, 12, 34) reconstruct certified
CSR root proofs but fail as standalone ordinary DP certificates. These are
Ex16_Luc06, Ex1_GM99, Ex24_GM04, and Ex9_Luc04. The ordinary checker ignores
the restriction on rewriting represented by the replacement map when building
its graph. An unrestricted nonminimal proof can establish a stronger result,
but CSR minimality must not be silently treated as ordinary DP minimality.
The old strategy coercion has therefore been removed, not retained as a
certification shortcut.

The new explicit extension uses `csrImprovedDpInput` and
`csrImprovedDpProof/csrDpProof`. Its claim is
`finite_min_csr_dpp Sharp (mu_of mu) (set P) (set R)`, not termination of R
and not ordinary DP finiteness. P is the residual pair set. It need not contain
the pairs already deleted by upstream processors. R is the actual active rule
set. Input minimality must be true; it denotes CSR chain minimality. The
internal ordinary DPP record uses False for its ordinary minimality flag,
exactly as the existing improved-CSR root checker does.

`CSR_Standalone_DP_Checker.thy` checks well-formed rules, absence of defined
marked/unhiding symbols, and an unmarked unhiding symbol, then calls the
existing recursive improved-CSR checker with assumptions disabled. The
soundness wrapper is derived from
`check_improved_csr_dp_termination_proof_sound`. It does not reconstruct or
replay an entire root proof. Other CSR frameworks, nonempty Q, relative
obligations, normal-form substitutions, and semantic-label contexts are
explicitly rejected by this first exporter instead of being silently erased.

The source implementation is in `ferrum-aaecc`; CeTA changes are being made
on `CeTA-CSR/main`. Unrelated dirty ROOT and outermost work is not part of
this task. The verified checker has now been installed with `make haskell`;
the previous binary is retained at
`CeTA-CSR/target/csr-standalone-export-20260914/ceta-production-before`.
The final root guard and action audit completed successfully as recorded below.

## Verification checkpoint

- Original baseline reproduced: four actions, eight original/renamed terminal
  executions, all rejected by the ordinary standalone checker.
- New standalone soundness wrapper checked in an isolated Isabelle console
  against a reusable CSR heap; the successful focused check took 1.153 s.
- Rust build passed. Nine existing/new standalone tests passed before adding
  the production-checker mutation test.
- Typed exporter reproduces all eight terminal actions. Old production CeTA
  reports the expected unsupported new input tag, not a certified result.
- A broader historical census finds nine uncertified terminal actions of CSR
  origin, not just the first four graph cases: eight improved-CSR inputs
  (one nonminimal) and one ordinary DP input. The broader focused probe is
  `nine-actions-v3`; nonminimal/framework extensions are not claimed solved.
- Added production-checker tests for the frozen-argument graph, activation of
  the frozen argument (creating a cycle), false minimality, and a defined
  unhiding symbol. These await the new verified production binary.

Artifacts:

- `target/csr-standalone-boundary-20260914/{four-actions,typed-v1,typed-v2}`.
- `target/csr-standalone-boundary-20260914/standalone-tests.log`.
- CeTA: `target/csr-standalone-production-20260914.log`.
- Isolated build home: CeTA
  `target/isabelle-user-csr-standalone-20260914`.
- Export session: CeTA `target/csr-standalone-export-20260914`.

The reusable September 6 cache lacks IsaFoR_1. The September 2 cache loads
for the focused theorem but is too old for current production source
(it lacks Zantema_To_SRS_Proc). Therefore production is rebuilding the
necessary IsaFoR layers above the cached HOL-AFP heap, with eight threads,
separate writable heaps, and per-theory timing output. No HOL-AFP rebuild was
started. Final certification, full modular-action audit, root guards, and
commits remain pending.

The first root-guard attempt accidentally used a debug executable. Its first
32 completed roots certified, but oracle loading alone took about 80 seconds.
That run was stopped, with artifacts retained under `root-guard`; it is not
a performance result. The replacement run uses frozen `ferrum-release-v4`,
48 workers, the baseline's 180/185-second ceilings and oracle-v14, and writes
to `root-guard-release`. It initially checks with the unchanged production
CeTA; all retained root certificates must subsequently be checked twice with
the newly verified checker before declaring parity.

The replacement release guard has now completed: **1,759/1,759 certified**
with the existing production checker, zero missing/extra inputs, zero losses,
zero polarity changes, and zero uncertified decisions. Exact totals are
Standard 1,338 (1,039 YES + 299 NO), Innermost 311 (301 YES + 10 NO), and
CSR 110 (105 YES + 5 NO). See `root-guard-release/comparison.json`.
Frozen release SHA-256:
`8167c643ea68bf3fe8cbdcada5da326096b4630064fd8263a6c1a7e2bde727de`.
The new-checker double recheck is still pending.

Frontend integration uncovered an import-name collision: importing the CSR
theory exposed the AC `cstep` abbreviation, which captured two existing
conditional-TRS clauses in `desired_property`. These now explicitly use
`Conditional_Rewriting.cstep`, preserving the previous meaning. An isolated
interactive reload confirmed that the two spurious type parameters disappeared.
Production `Proof_Checker` verification passed in
`csr-standalone-production-20260914-v5.log`: 5:01 including heap saving,
with eight threads. The standalone wrapper took approximately 1.5 seconds;
the main checker theory took 93.642 seconds. Haskell export and executable
certificate checks followed as recorded below.

Subsequent executable verification:

- Haskell export passed (257.600 s), and all 398 compilation units compiled.
- All 944 Rust library tests passed, none ignored, using the staged checker.
- The staged checker accepted all 1,759 retained root certificates twice.
- Production `make haskell` passed; all ten standalone-filtered Rust tests
  passed with `/work/dfm/festschrift/CeTA-CSR/ceta` explicitly selected.
- Six improved-CSR actions now independently certify twice in both original
  and renamed form: 3, 8, 12, 34, 1490, 3789. The latter two required restoring
  the standard sharp-symbol replacement-map extension in the standalone exporter.
- Historical gaps 2714 (guarded-list terminal), 3764 (nonminimal CSR context),
  and the original variant of 3756 (ordinary DP usable-rule obligation) remain.

Final frozen Ferrum executable: `ferrum-release-v5`, SHA-256
`59ac47d5126721518c1ba0c8ece5880a3cdae492b8242d85f18fbf2aa156fa07`.
Production CeTA SHA-256:
`067a10b13250a0254b9ac5804e9d2400391c57a9c2464e286986231094a65cfa`.
The final runs use `full-action-audit-v5` and `root-guard-final-v5` beneath
`target/csr-standalone-boundary-20260914`.

## Final verification and remaining boundaries

The final release-v5 oracle-only/no-fallback guard certified **1,759/1,759**:
Standard 1,338 (1,039 YES + 299 NO), Innermost 311 (301 YES + 10 NO),
CSR 110 (105 YES + 5 NO). There are no missing/extra roots, losses, polarity
changes, or uncertified decisions. All final root certificates passed two
additional production-CeTA checks (3,518 checks), with unchanged hashes.
See `root-guard-final-v5/{comparison.json,twice-rechecked.jsonl}`.

All **944 library tests** passed again with production CeTA, with none ignored;
14 Python action-audit tests and two replay-comparison tests passed.
Both repository diffs pass `git diff --check`.

The full independent audit contains **14,375 actions / 28,750 executions**:

- 11,541 terminal executions certified twice.
- 17,106 open transformations, not promoted to solved.
- 85 raw solved executions not certified: 80 refused exports and five checker
  rejections. The refused exports comprise 22 safe-CSR, 20 native-CSR,
  22 nonminimal improved-CSR, six MuTerm-unhiding, and ten other QDP contexts.
- Four local timeouts and 14 harness timeouts, not certified results.

The five checker rejections are original/renamed guarded-list terminal 2714,
original/renamed ordinary Arctic usable-rule action 3352, and original ordinary
usable-rule action 3756. These remain separate follow-up work. Supporting
other CSR frameworks requires a sound typed entry or a proved stronger
obligation, not restoring the old context-erasing coercion. In particular,
previously accepted ordinary wrappers are not a valid acceptance baseline
when they imported CSR minimality as ordinary minimality.

Exact diagnostics: `full-action-audit-summary.json`; its retained generating
script is `summarize-audit.py`. Comparison fields in that report use the older
pre-renaming-repair audit and must not all be attributed to this change.
No oracle records or search strategies were changed, and no composite
termination/nontermination strategy action was re-enabled.
# 2026-09-15: all three recorded gap classes closed

The previous 85 uncertified terminal executions came from 43 distinct actions
(one renamed variant already certified). The consolidated final audit now has
**43/43 actions, 86/86 executions certified twice**, no remaining failures:
`target/standalone-gaps-20260915/all-gaps-v13/results.jsonl`.

The fixes preserve each processor's actual obligation:

- **Usable rules:** Arctic argument dependence checks every coefficient-matrix
  entry, not just `(0,0)`, and closure starts from the live full rule set unless
  an earlier processor fixed it. Standalone exact reduction-pair payloads bind
  rule variables literally to the active input, without applying an absent
  enclosing GM transformation's variable convention.
- **Guarded-list entry:** the standalone parser/checker now uses the existing
  verified guarded CSR proof language and its soundness theorem. A mutation
  requesting nonminimality is rejected; no assumption or composite proof
  action was enabled.
- **Other contexts:** native minimal CSR obligations use the typed CSR entry.
  Safe CS-DPs use their theorem's ordinary minimal DP obligation, not CSR
  minimality. Noncollapsing MU-TERM components reuse the verified CSR-chain
  implication; collapsing components cannot silently discard unhiding.
  Nonminimal CSR input has its own sound core-checker branch. Its graphs retain
  the replacement map while ordinary terminal processors prove a stronger
  full-DP obligation. Relative DP inputs explicitly preserve P/Pw, Q, R/Rw,
  minimality, and normal-form substitutions. The runtime union of strict/weak
  pairs is split correctly on export and restored on import.

This closes the **recorded census**, not a claim that every conceivable typed
framework/proof constructor is supported. Unrepresentable contexts remain
explicit errors. Complete TRS/DP composite actions remain disabled and the
oracle is unchanged (`target/renaming-fixes-20260914/oracle-v14.jsonl`).

Verification:

- Full Rust library: **947 passed**, zero failed or ignored
  (`target/standalone-gaps-full-tests-v13.log`).
- Nine independent CSR correspondence tests and two replay-comparison tests.
- Isabelle `Proof_Checker` passed; new nonminimal wrapper checked in 0.626s
  against the reused parent heap. Full session: 5m18s, export child: 4m44s.
  Builds used the isolated `isabelle-user-csr-standalone-20260914` home.
- Verified Haskell export and `make haskell` passed. Production checker SHA256:
  `2ebcb81adf0a62ceb539f5046c46da1d20d2a3fea013ad5cca34d778db85e96a`.
- Fresh final CSR oracle-only replay: **110/110**, independently input-audited
  and twice rechecked. See [the root audit](csr-root-input-audit.md).
- Full category guard is in `target/standalone-gaps-20260915/root-guard-v11`;
  the final standalone-only corrections and relative-input import were then
  verified with `ferrum-release-v13`, the complete gap audit, full library
  suite, and another complete CSR replay.

Final standalone/CSR Ferrum binary:
`target/standalone-gaps-20260915/ferrum-release-v13`, SHA256
`097d44c6747696997df72da92655e39f14161b1ce6904a61b440907a3068460c`.

## 2026-09-15 full post-repair action audit

The complete independent replay of the saved modular actions used the frozen
`ferrum-release-v13` above and production CeTA-CSR `3ddffbd`, with 48 workers,
two Rayon threads per probe, and 60-second processor limits. No oracle or
root history was supplied to these probes.

- **14,375 actions, 28,750 original/renamed executions**.
- **11,627 terminal executions independently certified twice**.
- **17,111 open transformations**, not promoted to solved.
- **Zero uncertified terminals; zero previously certified losses**.
- All actions have supported witness transport; no missing actions, variants,
  or changed action identities were found.
- Three local timeouts and nine harness timeouts remain across nine actions.
  Six actions differ between original and renamed outcomes only because one
  variant reaches a runtime limit.

Relative to `full-action-audit-v5`, there are 86 newly certified executions:
the 85 repaired uncertified terminals, plus one previously timed-out execution.
Open transformations increased by five and runtime-limited executions fell
from 18 to 12. These are action-level results, not additional certified roots.

Artifacts: `target/standalone-gaps-20260915/full-action-audit-v13/`
contains `results.jsonl`, all inputs/action files/proofs/checker logs, and
`comparison.json`. The comparison was generated by
`scripts/compare_standalone_audits.py` against the immediately preceding full
audit, not the older pre-renaming audit. Six comparison tests and 14 existing
action-audit tests pass. No Ferrum processor or CeTA changes were needed for
this full revalidation.

The nine runtime-limited actions were repeated at four workers with 180-second
processor limits in `target/standalone-gaps-20260915/slow-action-audit-v13-180s`.
**All nine recover matching original/renamed outcomes:** eight transformations
(16 executions) and one nontermination terminal (two executions, each certified
twice). No error or timeout remains in that repeat. This establishes replayability
under relaxed limits, not universal 60-second performance or an isolated claim
that concurrency alone caused the original limits. The full run plus these
replacement observations covers 11,628 certified terminals and 17,122 open
transformations across the original 28,750 executions.

There is a concrete diagnostic-output bottleneck worth fixing next: action 783
(`MNZ_10/labelled`, exact graph, 560 children) writes 5.9 GiB original and
7.2 GiB renamed JSON stdout. Its input CPF is only 3.4/4.1 MiB. Repeated residual
contexts in the report amplify output and Python JSON parsing costs. These
artifacts are retained; no contexts were dropped to make the audit pass.
Other recovered graph/red-pair actions report local processor runtimes of
238–3,515 ms in their renamed repeats, far below the original harness limits.

## Compact-report follow-up

Ferrum `0b9eae5bacb507e352e51a3e25fbcb00fc5ba663` adds opt-in
`probe-cpf --summary`, consumed by `audit_independent_modular_actions.py
--summary`. It emits a distinct diagnostic schema with outcome, typed outcome,
child count, elapsed time, and CPF export status/path/reason. It does not claim
certification or serialize a reconstruction manifest. The normal full report
is unchanged. Importantly, summary selection occurs **after** the existing
residual materialization, child-bijection validation, and terminal CPF export;
no context/validation obligation is discarded to obtain these results.

The audit additionally records subprocess wall time and stdout byte count,
separately from the probe's local elapsed time. Action 783 retains all 560
children internally but now emits **275 bytes** per variant, instead of
6,310,005,692 / 7,687,696,922 bytes. Under 48-worker load its original/renamed
wall times were 13.915 / 15.039 seconds, both below the 60-second limit.

Full repeat: **14,375 actions / 28,750 executions**, 11,627 twice-certified
terminals, 17,120 open transformations, zero uncertified terminals, zero
certified losses, zero missing/untransported actions, **zero harness timeouts**.
Three local-timeout executions remain: both variants of action 1260 path-order
search, and renamed action 8989 nontermination search. Both actions recover in
the new binary's 180-second repeat: path-order transforms in 63.1 / 81.4s;
nontermination certifies twice in both variants, in 12.5 / 73.0s.
There are no unresolved replayability failures in this recorded action set
under the relaxed allowance. This does not claim universal 60-second search.

Artifacts: `target/probe-summary-root-audit-20260915/`
`full-action-summary-60s/{results.jsonl,comparison.json}` and
`local-timeouts-summary-180s/results.jsonl`. All **949 Rust library tests** and
40 focused Python audit/comparison tests pass; release build and diff checks
pass. CeTA and the oracle are unchanged. The normal report still has large
residual payloads; summary mode specifically removes unnecessary audit-report
I/O and parsing, not the materialization cost required by normal consumers.
