# 2026-07-13 Regression Slice Recovery Run

This note records the focused 81-example recovery runs against the previous
`383 / 93` artefacts in:

```text
target/termcomp-runs/20260713-065307
```

The regression slice was reconstructed in:

```text
target/termcomp-runs/recovery-81-input/details.json
```

## Commands

Certifiable aligned run:

```bash
python3 -u scripts/termcomp_trs_compare.py \
  --tpdb ../TPDB-ARI \
  --ferrum target/release/ferrum \
  --ceta .tools/ceta-relative-bounds \
  --jobs 128 \
  --timeout 305 \
  --progress-interval 5 \
  --ferrum-profile enhanced \
  --from-details target/termcomp-runs/recovery-81-input/details.json \
  --include-status unknown \
  --run-dir target/termcomp-runs/recovery-81-aligned \
  --output target/termcomp-runs/recovery-81-aligned/summary.md
```

Diagnostic graph-refinement run:

```text
target/termcomp-runs/recovery-81-current
```

That diagnostic run temporarily used a stronger standard dependency-graph
refinement. It recovered more YES results, but CeTA rejected several graph
decompositions, so this refinement is not part of the default certifiable
strategy.

## Results

Aligned, certifiable run:

| Slice | Old YES in slice | Ferrum YES | Certified YES | Certification failures | Missing old YES |
|---|---:|---:|---:|---:|---:|
| TRS Standard | 61 | 2 | 2 | 0 | 59 |
| TRS Innermost | 20 | 3 | 3 | 0 | 17 |

Diagnostic standard graph-refinement run:

| Slice | Old YES in slice | Ferrum YES | Certified YES | Certification failures | Missing old YES |
|---|---:|---:|---:|---:|---:|
| TRS Standard | 61 | 18 | 10 | 8 | 43 |
| TRS Innermost | 20 | 3 | 3 | 0 | 17 |

CeTA-definition graph run after correcting Ferrum's ground-context matcher:

```bash
python scripts/termcomp_trs_compare.py \
  --ferrum target/release/ferrum \
  --ceta .tools/ceta-relative-bounds \
  --jobs 128 \
  --timeout 305 \
  --category TRS_Standard \
  --category TRS_Innermost \
  --from-details target/termcomp-runs/recovery-81-selector.json \
  --include-status unknown \
  --run-dir target/termcomp-runs/recovery-81-ceta-match \
  --details-output target/termcomp-runs/recovery-81-ceta-match/details.json \
  --output target/termcomp-runs/recovery-81-ceta-match/summary.md \
  --progress-interval 5
```

| Slice | Old YES in slice | Ferrum YES | Certified YES | Certification failures | Missing old YES |
|---|---:|---:|---:|---:|---:|
| TRS Standard | 61 | 11 | 11 | 0 | 50 |
| TRS Innermost | 20 | 3 | 3 | 0 | 17 |

Matrix SAT run after replacing matrix enumeration with a bit-blasted SAT
encoding:

```bash
python scripts/termcomp_trs_compare.py \
  --ferrum target/release/ferrum \
  --ceta .tools/ceta-relative-bounds \
  --jobs 128 \
  --timeout 305 \
  --category TRS_Standard \
  --category TRS_Innermost \
  --from-details target/termcomp-runs/recovery-81-selector.json \
  --include-status unknown \
  --run-dir target/termcomp-runs/recovery-81-matrix-sat \
  --details-output target/termcomp-runs/recovery-81-matrix-sat/details.json \
  --output target/termcomp-runs/recovery-81-matrix-sat/summary.md \
  --progress-interval 5
```

| Slice | Old YES in slice | Ferrum YES | Certified YES | Certification failures | Missing old YES |
|---|---:|---:|---:|---:|---:|
| TRS Standard | 61 | 28 | 28 | 0 | 33 |
| TRS Innermost | 20 | 3 | 3 | 0 | 17 |

## Recovered In Aligned Run

TRS Standard:

```text
../TPDB-ARI/TRS_Standard/AG01/#3.4.ari
../TPDB-ARI/TRS_Standard/AG01/#3.53b.ari
```

TRS Innermost:

```text
../TPDB-ARI/TRS_Innermost/AG01_innermost/#4.17.ari
../TPDB-ARI/TRS_Innermost/Transformed_CSR_innermost_04/Ex4_4_Luc96b_iGM.ari
../TPDB-ARI/TRS_Innermost/Transformed_CSR_innermost_04/Ex4_4_Luc96b_GM.ari
```

## Recovered In CeTA-Definition Graph Run

TRS Standard:

```text
../TPDB-ARI/TRS_Standard/AG01/#3.4.ari
../TPDB-ARI/TRS_Standard/AG01/#3.53b.ari
../TPDB-ARI/TRS_Standard/AProVE_04/improved_usable.ari
../TPDB-ARI/TRS_Standard/Rubio_04/lindau.ari
../TPDB-ARI/TRS_Standard/Strategy_removed_AG01/#4.21.ari
../TPDB-ARI/TRS_Standard/Strategy_removed_mixed_05/tricky1.ari
../TPDB-ARI/TRS_Standard/Transformed_CSR_04/Ex23_Luc06_iGM.ari
../TPDB-ARI/TRS_Standard/Transformed_CSR_04/Ex4_4_Luc96b_iGM.ari
../TPDB-ARI/TRS_Standard/Transformed_CSR_04/ExConc_Zan97_iGM.ari
../TPDB-ARI/TRS_Standard/Zantema_05/jw14.ari
../TPDB-ARI/TRS_Standard/Zantema_05/jw35.ari
```

TRS Innermost:

```text
../TPDB-ARI/TRS_Innermost/AG01_innermost/#4.17.ari
../TPDB-ARI/TRS_Innermost/Transformed_CSR_innermost_04/Ex4_4_Luc96b_GM.ari
../TPDB-ARI/TRS_Innermost/Transformed_CSR_innermost_04/Ex4_4_Luc96b_iGM.ari
```

## Findings

The default certifiable strategy keeps YES and CERTIFIED YES aligned on this
slice.

A temporary stronger standard dependency-graph refinement recovered additional
Standard YES results quickly, but CeTA rejected eight of them because its
EDG/IEDG estimators could not validate the decomposition. Those proofs must not
be counted as certified YES.

The relevant CeTA implementation is
`.tools/CeTA-3.9/thys/Code/For_Module_Merge/Dependency_Graph_Impl.hs`,
with `tcapRM` in `Tcap_Impl.hs`, reverse `tcapRM` in `Tcap_Dpp_Impl.hs`,
`gtcapRM` in `Gtcap_Impl.hs`, and ground-context matching in
`Ground_Context_Impl.hs`. The important correction was that
`Ground_Context.match` does not fail when a non-hole ground context is matched
against a term variable. Instead, it records that variable's required ground
context and merges requirements for repeated occurrences. Ferrum's earlier
structural-only matcher therefore omitted edges that CeTA still requires, for
example the self-edge in `TRS_Standard/Zantema_05/jw02.ari`.

Ferrum now uses the CeTA-style dependency graph estimator for standard TRSs.
For innermost TRSs, Ferrum keeps the previous conservative supergraph behavior
and additionally admits CeTA-style edges. This preserves the current certified
innermost results while avoiding uncertified edge omissions.

The dominant matrix regression class was fixed by replacing the historical
candidate-walk fallback with a bit-blasted SAT encoding for matrix
interpretation parameters. The regression target
`TRS_Standard/Zantema_05/jw02.ari` now proves and CeTA certifies again with a
SAT-backed matrix interpretation. The 81-example slice improved from
`11 / 11` certified Standard YES after the graph fix to `28 / 28` certified
Standard YES after the matrix SAT fix.
