# AAECC innermost switch: certified implementation

The processor is the full-to-innermost switch of Giesl and Arts, Theorem 16
(`AAECC` in AProVE proof output).  It is not the existing Gramlich switch:
AAECC permits a non-confluent top layer `R2` when a signature-separated,
non-overlapping lower layer `R1` satisfies the theorem's conditions.

The certified processor implements the published criterion together with
AProVE's locally-confluent-`R1` generalization:

- `R = R1 union R2`;
- `R1` is overlay and locally confluent, with an explicit CPF joinability
  witness;
- every right-hand side in `R2` is non-collapsing;
- rules in `R2` form no critical pairs with rules in `R1`;
- `Sigma` contains the root symbols of both sides of every `R2` rule;
- `R1` contains no `Sigma` symbol; and
- no `R2` side contains a `Sigma` symbol below its root.

The Ferrum atom is `aaecc-innermost`.  It materializes the complete
innermost TRS as an ordinary child state and records `R1`, `R2`, and `Sigma`
explicitly.  It does not hide or inline the child proof.  Its CPF element
`<aaeccInnermost>` also records the local-confluence search bound.  CeTA-CSR
rechecks the partition, signature separation, overlay and directed-overlap
premises, critical-pair joinability, and the independent recursive innermost
proof.

The witness implementation now checks the published directed overlap premise
directly: an `R1` left-hand side must not unify with any non-variable position
of an `R2` left-hand side (root included, variables renamed apart).  It no
longer relies on a whole-TRS overlay test as a proxy.  Five focused partition
and overlap tests pass.

The CeTA theory verifies the semantic core through the complete
normalized root-chain contradiction.  In particular, it proves that
signature-free `R1` terms terminate, that their `R1` normal forms are unique,
that an `R1` redex inside a normalized `R2` left-hand side would induce a
forbidden critical pair, and that the resulting `R2` step is innermost in
`R1 union R2`.  The theorem `aaecc_no_infinite_R2_root_chain` then rules out
every infinite sequence of such `R2` root steps separated by `R1*` blocks.
The same theory proves that an `R2` step changes exactly one alien while
leaving the cleaned `R1` skeleton unchanged, and extracts the required root
chain from arbitrary nontermination using CeTA's existing
`Signature_Extension` alien decomposition.  The development contains no
`sorry` or `quick_and_dirty` escape.

On the 24 examined TRS Standard roots whose AProVE 2025 traces mention AAECC,
the original criterion applies to 22.  `Secret_06_TRS/times.ari` and
`Secret_07_TRS/aprove02.ari` require the locally-confluent-`R1`
generalization, which is now represented and checked.  With Ferrum's current innermost processors,
`Secret_06_TRS/logarithm.ari` already closes after the switch.  The remaining
children expose additional processor gaps, notably QDP-to-SRS and match-bound
processors in the Zantema family.

A fresh release replay closes `Secret_06_TRS/logarithm.ari` in about one second
with `aaecc-innermost; timeout(60s, dp)`.  The complete CPF and processor events
are under `target/aaecc-logarithm-production-final/`.  The freshly exported
production checker accepted the certificate twice through
`/work/dfm/festschrift/CeTA-CSR/ceta`; sigma and missing-joinability mutations
were rejected.  This evidence is therefore eligible for oracle promotion.

The certified proof was flattened into 65 state-first observations covering
22 distinct canonical obligations, with 54 certified positive candidates and
28 certified transformations.  The monotone recursive oracle is
`target/aaecc-logarithm-oracle-integration-20260831/oracle-global-plus-aaecc-recursive.jsonl`
(SHA-256 `e51f6cfdc5d1a0fa6168815e39fc598e36d78e5e17db84ce91f9d4d6f195f3a1`).
Its strict replay deliberately excludes the complete root
`exact-trs-proof`: with `timeout(60s, fail)`, top-level model guidance off,
and `FERRUM_DP_LLM_NO_FALLBACK=1`, Ferrum instead executes the
`aaecc-innermost` root transition and recursively looks up the independently
materialized DP states.  The replay finished in 3.7 seconds and its CPF at
`target/aaecc-logarithm-oracle-integration-20260831/strict-recursive-1/proof.xml`
was accepted twice by the production checker.

`Secret_06_TRS/times.ari` is the second production-certified root.  Its
explicit AAECC run produces a 252 KB CPF without processor timeouts and the
production checker accepts it twice.  After adding its 97 extracted events,
the current two-root monotone recursive oracle is
`target/aaecc-logarithm-oracle-integration-20260831/oracle-global-plus-aaecc-two-recursive.jsonl`
(SHA-256 `8f81641ed9ce2c480f835349c6d516d8c62741a9240170823822d37db0c61200`).
It exports 132 certified positive entries, rejects no uncertified positive,
and excludes both monolithic root proofs.  Strict no-fallback replay closes
`times` in 3.9 seconds and a preservation replay closes `logarithm` again;
all four resulting checker invocations return `CERTIFIED`.

The Zantema two-stack continuation is now certified as well.  After AAECC,
ordinary innermost DPs, usable rules, and Q removal, the new `qdp-to-srs`
processor recognizes productive pairs
`f(x,C(y)) -> f(D(x),y)` and transfer pairs
`f(a(x),y) -> f(x,a(y))`.  It materializes the generated string system
`C -> reverse(D)` as an ordinary child, so the child is independently
findable and may use any SRS proof.  Isabelle proves the transformation by a
lexicographic measure combining generated-SRS rewriting with the left-stack
depth; the executable checker rejects nonempty Q/R contexts and malformed
pair shapes.

The default strategy now closes both `Zantema_05/z12.ari` and
`Zantema_05/z13.ari`.  Their generated `aabb -> bbbaaa` child uses a retained,
renaming-portable complete CPF proof (string reversal, flat-context closure,
semantic labeling, DPs, graphs, usable rules, and reduction pairs), not a
top-level assumption.  The isolated freshly exported checker at
`CeTA-aaecc/target/qdp-code-export-20260901/ceta-qdp-srs` accepted each full
root CPF twice.  The default z12 replay took 3.7 seconds; z13 also completed
well inside the 60-second campaign ceiling.
