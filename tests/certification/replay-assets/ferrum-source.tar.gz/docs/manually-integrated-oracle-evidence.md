# Manually integrated oracle evidence

## 2026-09-08 archived Standard NO recovery

- `TRS_Standard/Transformed_CSR_04/OvConsOS_complete-noand_Z.ari`: strict
  `Nonterminating`, production CeTA-CSR certified twice. Source proof:
  `target/standard-next-frontier-20260903/cpf2-integrate-r820/strict/OvConsOS_complete-noand_Z/proof.cpf.xml`;
  current oracle-only replay:
  `target/standard-next-frontier-20260903/post1304-isolated-r916/ovcons-z-v18`.

This page is the durable registry for examples whose certified proof evidence was
manually added during the adaptive 2026-07-29 campaign.  Keep an entry here even
after the evidence is absorbed into a later frozen union.  The registry exists
so that a release audit can verify two independent properties:

1. the strongest monotone oracle can retrieve the certified proof path for the
   original problem and its materialized intermediate states; and
2. the then-current default strategy can find a CeTA-CSR-certified proof without
   relying on the recorded processor sequence as a hard-coded strategy.

All positive certificates listed here were checked exclusively with
`/work/dfm/festschrift/CeTA-CSR/ceta`.  “2x” means two deterministic independent
checker invocations returned `CERTIFIED`.

## Evidence registry

### SRS Relative custom matrix chains (v869)

Four TermCOMP residuals were recovered from accepted AProVE CPF evidence:
`Waldmann_06_relative/{r5,r6,r10}.ari` and
`Mixed_relative_SRS/dup03.ari`. Their exact integer-matrix witnesses and
string-reversal steps are retained under
`target/srs-relative-custom-oracle-v866-20260813`. Every producing CPF was
checked twice by `/work/dfm/festschrift/CeTA-CSR-relative-adp/ceta`; the v869
oracle-only replay with fallback `fail` recovered 4/4 certified YES in
`target/termcomp-runs/20260813-srs-relative-custom-v869-oracle-only`.

The concrete chains use dimensions 2, 3, and 6 with entries through 3. Broad
synthesis found `r6` but timed out on `r10` and `dup03`, while the exact
witnesses apply immediately. No CeTA changes were required. Ferrum now retains
explicit strategy sequences across top-level transformations, which was needed
for reversal-plus-matrix and repeated-matrix custom strategies.

| Problem | Certified proof evidence | Proof shape / processors retained | CeTA-CSR | First oracle containing it | Current default observation | Future oracle lookup audit | Future default audit |
|---|---|---|---|---|---|---|---|
| `TRS_Contextsensitive/CSR_04/Ex14_Luc06.ari` | original: `target/data-campaign/state-first-unified-20260729-053014-oracle-growth/ex14-luc06-promotion/captured-proof.cpf.xml`; current: `target/csr-next8/CSR_04_Ex14_Luc06-fixed.cpf4.xml` | Complete CSR proof and recovered state aliases. Empty usable-rule reduction pairs now preserve their minimality obligation, so CPF emits `csrSafeDependencyPairs` rather than the unsound ordinary wrapper. | certified, 2x | global adaptive oracle v80 | current default certified in 5.75 s | pending refreshed strict replay after the v80 export | Ferrum positive and mutation-negative regression added; no CeTA changes required |
| `TRS_Contextsensitive/CSR_04/Ex1_2_AEL03.ari` | refreshed proof: `target/data-campaign/state-first-adaptive-20260729-132133/staged-csr-ex1-2-ael03-refresh-20260730/TRS_Contextsensitive/CSR_04/Ex1_2_AEL03/proof.cpf.xml`; strict replay: `target/data-campaign/state-first-adaptive-20260729-132133/manual-evidence-recursive-20260730/v28b-full-registry-strict/TPDB-ARI__TRS_Contextsensitive__CSR_04__Ex1_2_AEL03.cpf.xml` | Exact LPAR'08 improved CS-DPs with a fresh unsharp symbol; graph decomposition; three cyclic SCCs closed by size change. The root, graph state, and all four certificate size-change nodes are independently keyed. | certified, 2x | adaptive manual-evidence oracle v5; refreshed states already present in r03 v28 | current default certified in 107 ms | passed, strict oracle-only in 0.91 s; reconstructed CPF certified 2x | pending release-default rerun; CeTA changes: none |
| `TRS_Contextsensitive/CSR_04/ExAppendixB_AEL03.ari` | `target/data-campaign/state-first-adaptive-20260729-132133/staged-csr04-lpar08/TRS_Contextsensitive/CSR_04/ExAppendixB_AEL03/proof.cpf.xml` | Same exact LPAR'08 improved-CS-DP, graph, and four-component size-change pipeline | certified, 2x | adaptive manual-evidence oracle v5 | solved automatically in 0.52 s | pending post-r01 strict replay | pending release-default rerun |
| `TRS_Innermost/AG01_innermost/#4.29.ari` | `target/data-campaign/state-first-adaptive-20260729-132133/staged-innermost-429/proof.cpf.xml` | Innermost DP; graph decomposition; dimension-2 matrix reduction pair with five usable rules; singleton SCCs by size change | certified, 2x | adaptive r01 oracle after `innermost-429` integration | solved with explicit `termination` portfolio | passed, strict oracle-only, 2x certified | pending |
| `TRS_Standard/Der95/13.ari` | `target/data-campaign/state-first-adaptive-20260729-132133/staged-der95-13/TRS_Standard/Der95/13/proof.cpf.xml` | DP; one-shot degree-2 natural polynomial interpretation (`x+y+xy`); residual SCCs by size change | certified, 2x | adaptive r01 oracle after `der95-13` integration | solved by current default in about 1.584 s | passed, strict oracle-only, 2x certified | pending release rerun |
| `TRS_Innermost/Mixed_innermost/innermost3.ari` | `target/data-campaign/state-first-adaptive-20260729-132133/staged-innermost3/TRS_Innermost/Mixed_innermost/innermost3/proof.cpf.xml` | Innermost DP with Q kept separate from usable R; two CeTA-compatible instantiations; dependency graph closure | certified, 2x | adaptive r01 oracle after `innermost3` integration | solved by current default in about 1 s | passed, strict oracle-only, 2x certified | pending release rerun |
| `TRS_Standard/Zantema_05/z06.ari` | `target/data-campaign/state-first-adaptive-20260729-132133/staged-z06/TRS_Standard/Zantema_05/z06/proof.cpf.xml` | Generalized applicative uncurrying followed by DP and size change | certified, 2x | adaptive r01 oracle after `z06` integration | 10/10 current-default runs certified; representative 1.274 s | passed, strict oracle-only, 2x certified | pending release rerun |
| `TRS_Standard/Zantema_05/jw34.ari` | `target/data-campaign/state-first-adaptive-20260729-132133/staged-jw34/TRS_Standard/Zantema_05/jw34/proof.cpf.xml` | Uncurrying raced against the main DP portfolio; DP, two graph states, semantic labeling, and size-change closure. Six exact certified proof-state events are retained. | certified, 2x | adaptive manual-evidence oracle v4 | solved by current release default in 22.411 s; candidate batch improved from 5/15 to 6/15 with no losses | pending post-r01 strict replay | pending release rerun |
| `TRS_Innermost/Applicative_AG01_innermost/#4.15.ari` | `target/data-campaign/state-first-adaptive-20260729-132133/staged-innermost-415/TRS_Innermost/Applicative_AG01_innermost/sharp_4.15/proof.cpf.xml` | Innermost DP; dependency graph; subterm closures; complete reconstructed proof retained alongside raw processor events | certified, 2x | adaptive post-r02 manual-evidence oracle | solved by current debug default in 0.374 s | passed, strict oracle-only; reconstructed CPF certified 2x | pending release rerun |
| `TRS_Standard/Various_04/11.ari` | `target/data-campaign/state-first-adaptive-20260729-132133/staged-various04-11/TRS_Standard/Various_04/11/proof.cpf.xml` | `switchInnermost`; executable CeTA Q-reduction; innermost DP graph; usable rules; narrowing, instantiation, DP rewriting, and residual graph closure | certified, 2x | adaptive post-r02 manual-evidence oracle | solved by current default in 9.851 s | root and all recorded states found; strict reconstruction remains open because live post-preprocessing states do not exactly match two CPF node boundaries | pending release rerun |
| `TRS_Innermost/Applicative_AG01_innermost/#4.17.ari` | `target/data-campaign/state-first-adaptive-20260729-132133/staged-innermost-417/TRS_Innermost/Applicative_AG01_innermost/sharp_4.17/proof.cpf.xml` | Innermost DP and graph/subterm closures in the retained run; bounded DP rewriting was added to the default portfolio that produced the closure; complete 142 KiB CPF retained | certified, 2x | adaptive post-r02 manual-evidence oracle | solved by current debug default in 2.709 s (reported release observation: 2.84 s) | root and main SCC found; strict singleton reconstruction remains open where runtime size change is serialized as CPF subterm | pending release rerun |
| `TRS_Innermost/Applicative_AG01_innermost/#4.19.ari` | earlier proof: `target/data-campaign/state-first-adaptive-20260729-132133/staged-innermost-419/TRS_Innermost/Applicative_AG01_innermost/sharp_4.19/proof.cpf.xml`; recovered icap_Q proof: `target/data-campaign/state-first-adaptive-20260729-132133/staged-applicative-419-icapq-20260730/TRS_Innermost/Applicative_AG01_innermost/#4.19/proof.cpf.xml` | Native uncurrying/innermost DP path; CeTA-style source-preserving `icap_Q` avoids the false symmetric SCC; seven extracted proof-state events close the graph, usable-rule, subterm, and size-change residuals | both certified, 2x | adaptive Transformed-CSR r01 oracle v7 | current default about 3 s | pending strict replay | pending release rerun |
| `TRS_Standard/Secret_06_TRS/gen-9.ari` | `target/data-campaign/state-first-adaptive-20260729-132133/staged-secret06-gen9/TRS_Standard/Secret_06_TRS/gen-9/proof.cpf.xml` | DP graph; dimension-2 matrix interpretation and linear polynomial interpretation, each over the certified two-rule usable-rule closure | certified, 2x | pending adaptive post-r03 export | solved by current default in 1.707 s | pending post-r03 strict replay | pending release rerun |
| `TRS_Standard/Secret_06_TRS/5.ari` | producing proof: `target/termcomp-runs/20260731-next-small-certified-cluster-two-recoveries-8x60s/TRS_Standard/Secret_06_TRS/5/proof.cpf.xml`; live residual recovery and strict replay: `target/integration-secret5-ttt1-20260731` | Polynomial rule removal followed by independently indexed DP, graph, monotonic-polynomial, and dimension-1 natural-Arctic states. | certified, 2x on producing, live, and replay proofs | global adaptive oracle v126 and later | current default certified YES in 0.50 s | passed strict oracle-only in 1.34 s with fallback replaced by `fail`; replay CPF certified 2x | CeTA changes: none |
| `TRS_Standard/Secret_05_TRS/matchbox1.ari` | `target/data-campaign/state-first-adaptive-20260729-132133/staged-matchbox1/TRS_Standard/Secret_05_TRS/matchbox1/proof.cpf.xml` | Complete DP proof retaining empty usable-rule obligations as `redPairUrProc`/`monoRedPairUrProc`; extracted path also records graph, forward instantiation, semantic labeling, matrix, and subterm states | certified, 2x | pending adaptive post-r03 export | solved by current default in 1.624 s | pending post-r03 strict replay | pending release rerun |
| `TRS_Standard/Secret_05_TRS/ttt1.ari` | producing proof: `target/termcomp-runs/20260731-next-small-certified-cluster-two-recoveries-8x60s/TRS_Standard/Secret_05_TRS/ttt1/proof.cpf.xml`; strict replay: `target/integration-secret5-ttt1-20260731` | Bounded ground-term generation finds `cons(s(a),s(b))`; the executable retained action is a certified mixed DP-loop witness. | certified NO, 2x on producing and replay proofs | global adaptive oracle v126 and later | current default certified NO in 1.77 s | passed strict oracle-only in 1.21 s with fallback replaced by `fail`; replay CPF certified 2x | CeTA changes: none |
| `TRS_Standard/Secret_05_TRS/teparla1.ari` | producing proof: `target/termcomp-runs/20260731-next-small-certified-cluster-instantiation-chain-8x60s/TRS_Standard/Secret_05_TRS/teparla1/proof.cpf.xml`; live recovery, reconstructed proof-path extraction, and strict replay: `target/integration-teparla1-20260731` | Complete five-pair DP generation; graph decomposition; monotonic usable-rules polynomial compatibility; three bounded instantiation stages with graph recomputation. Each retained residual is independently indexed, and the certified reconstructed path supersedes the earlier weak placeholders. | certified, 2x on producing, live, frozen terminal, and strict-replay proofs | global adaptive oracle v128 and later | current default certified YES in 0.46 s | passed strict oracle-only in 1.12 s with the top-level fallback replaced by `fail` and DP fallback disabled; replay CPF certified 2x | CeTA changes: none |
| `TRS_Standard/Secret_05_TRS/aprove4.ari` | final producing proof: `target/manual-probes/20260731-aprove4-default-dp-switch-final/proof.xml`; current-binary live recovery and strict replay: `target/integration-aprove4-dp-switch-20260731` | Root DP and graph decomposition; component-level `switchInnermostProc`; narrowing and graph recomputation; usable-rule, subterm, instantiation, forward-instantiation, matrix, and size-change closures. Reconstructed CPF nodes provide the certified root/path evidence while independently replayed live states provide executable nested lookup keys. | certified, 2x on final producing, live, and strict-replay proofs | global adaptive oracle v135 and later | current default certified YES; focused current-binary proof in 8.2 s | passed strict oracle-only in about 1 s with the top-level fallback replaced by `fail` and DP fallback disabled; replay CPF certified 2x | CeTA changes: none |
| `TRS_Standard/Strategy_removed_AG01/#4.26.ari` | producing proof: `target/manual-probes/20260731-ag01-426-default-structural/proof.xml`; live-state freeze and strict replay: `target/integration-rational-structural-20260731` | Top-level DP; graph decomposition; structurally synthesized and exactly validated rational polynomial step; independently certified residual graph/order closures. | certified, 2x on producing, frozen terminal, and strict-replay proofs | global adaptive oracle v139 and later | current default certified; structural candidate discovery is about 1 ms | passed strict oracle-only under 60 s; replay CPF certified 2x | CeTA changes: none |
| `TRS_Innermost/AG01_innermost/#4.26.ari` | producing proof: `target/manual-probes/20260731-ag01-426-innermost-default-structural/proof.xml`; live-state freeze and strict replay: `target/integration-rational-structural-20260731` | Innermost DP with independently frozen graph, narrowing, subterm, matrix, arctic-matrix, and rational-order descendants. | certified, 2x on producing, frozen terminal, and strict-replay proofs | global adaptive oracle v139 and later | current default certified | passed strict oracle-only under 60 s; replay CPF certified 2x | CeTA changes: none |
| `TRS_Standard/Zantema_05/z25.ari` | producing proof: `target/manual-probes/20260731-z25-uncurry-current/proof.xml`; live-state freeze and strict replay: `target/integration-rational-structural-20260731` | Applicative uncurrying with independently certified size-change, subterm, symbol-weight, polynomial, and max-polynomial descendants. | certified, 2x on producing, frozen terminal, and strict-replay proofs | global adaptive oracle v139 and later | current default certified | passed strict oracle-only under 60 s; replay CPF certified 2x | CeTA changes: none |
| `TRS_Standard/SK90/4.02.ari` | producing proof: `target/manual-probes/20260731-sk90-402-rpo-current/proof.xml`; strict replay: `target/integration-rational-structural-20260731` | Direct checked path-order witness. | certified, 2x on producing and strict-replay proofs | global adaptive oracle v139 and later | current default certified | passed strict oracle-only under 60 s; replay CPF certified 2x | CeTA changes: none |
| `TRS_Standard/Endrullis_06/pair2simple1.ari` | producing proof: `target/manual-probes/20260731-pair2simple1-path-current/proof.xml`; strict replay: `target/integration-rational-structural-20260731` | Direct checked path-order witness. | certified, 2x on producing and strict-replay proofs | global adaptive oracle v139 and later | current default certified | passed strict oracle-only under 60 s; replay CPF certified 2x | CeTA changes: none |
| `TRS_Standard/AProVE_07/kabasci05.ari` | producing proof: `target/manual-probes/20260731-kabasci05-negative-guard-default/proof.cpf.xml`; live recovery and strict replay: `target/integration-negative-polynomial-20260731` | DP/order path using a CeTA-supported natural polynomial with negative constants; exact live root and residual states are frozen independently. | certified, 2x on producing, live, frozen terminal, and strict-replay proofs | global adaptive oracle v141 and later | current default certified; live recovery needed 120 s under campaign load | passed strict oracle-only in 10.156 s; replay CPF certified 2x | CeTA changes: none |
| `TRS_Standard/AProVE_06/tower.ari` | producing proof: `target/termcomp-runs/20260731-aprove06-next8-current-8w60s/TRS_Standard/AProVE_06/tower/proof.cpf.xml`; live recovery and strict replay: `target/integration-negative-polynomial-20260731` | DP graph with independently frozen usable-rule, order, and residual closures; negative constants are retained in the certified natural-polynomial witness. | certified, 2x on producing, live, frozen terminal, and strict-replay proofs | global adaptive oracle v141 and later | current default certified in about 50 s | passed strict oracle-only in 1.689 s; replay CPF certified 2x | CeTA changes: none |
| `TRS_Standard/AProVE_06/factorial1.ari` | producing proof: `target/manual-probes/20260731-factorial1-negative-guard-regression/proof.cpf.xml`; live recovery and strict replay: `target/integration-negative-polynomial-20260731` | Certified natural-polynomial proof with negative constants plus exact live DP/order residual states. | certified, 2x on producing, live, frozen terminal, and strict-replay proofs | global adaptive oracle v141 and later | current default remains certified after removing the stale negative-constant guard | passed strict oracle-only in 1.795 s; replay CPF certified 2x | CeTA changes: none |
| `TRS_Standard/AProVE_06/identity.ari` | producing proof and events: `target/manual-probes/20260731-identity-default-certified-final`; frozen states and strict replay: `target/integration-identity-thiemann01-20260731` | Precise argument-filtered usable rules via CeTA-style `matchCapRMBelow`; checked rational halving candidate; graph-first rewriting and a switched-innermost residual. | certified, 2x on producing, frozen, and replay proof | global adaptive oracle v146 and later | current default certified in about 1 s | passed strict oracle-only in 1.262 s; replay CPF certified | CeTA changes: none |
| `TRS_Standard/AProVE_07/thiemann01.ari` | producing proof and events: `target/manual-probes/20260731-precise-usable-next8-60s/thiemann01`; frozen states and lenient strict replay: `target/integration-identity-thiemann01-20260731` | Component-level innermost switching, narrowing, instantiation, forward instantiation, repeated graph decomposition, and size-change closure. | certified, 2x on producing, exact compound root, and replay proof; zero checker rejects | global adaptive oracle v147 and later | current default certified in about 1 s | passed oracle-only in 196 s under campaign load after explicit DP recipes stopped being overridden by nested guidance; strict 60 s remains an efficiency miss | CeTA changes: none; `otto02`, `otto06`, and `otto12` remain quarantined after checker rejection |
| `TRS_Standard/Endrullis_06/labeling.ari` | `target/data-campaign/state-first-adaptive-20260729-132133/staged-labeling/TRS_Standard/Endrullis_06/labeling/proof.cpf.xml` | DP graph; two forward-instantiation steps; semantic labeling; labeled graph; weakly monotone polynomial interpretation with zero coefficients | certified, 2x | pending adaptive post-r03 export | solved by current default in 23.050 s | pending post-r03 strict replay | pending release rerun |
| `TRS_Standard/Endrullis_06/pair2hard.ari` | producing proof: `target/termcomp-runs/20260731-endrullis-pair2hard-budget-final-5x60s/TRS_Standard/Endrullis_06/pair2hard/proof.cpf.xml`; frozen evidence and strict replay: `target/integration-endrullis-pair2hard-20260731` | Dependency graph; matrix reduction; forward instantiation; graph decomposition; sparse dimension-4 matrix and polynomial residual closures. | certified, 2x on producing proof and replay | global adaptive oracle v117 and later | current default certified YES in 8.6 s under load | passed strict oracle-only in 1 s with fallback replaced by `fail`; replay CPF certified 2x | CeTA changes: none |
| `TRS_Standard/Endrullis_06/linear2.ari` | producing proof: `target/termcomp-runs/20260731-endrullis-cluster-all-certified-5x60s/TRS_Standard/Endrullis_06/linear2/proof.cpf.xml`; live residual recovery and strict replay: `target/integration-endrullis-linear2-pair3swap-refresh-20260731` | Dependency graph; monotonic polynomial deletion; independently indexed residuals closed by a dimension-3 natural-Arctic matrix and a dimension-2 natural matrix. | certified, 2x on producing, live, and replay proofs | global adaptive oracle v122 and later | current default certified YES in 1.5 s under five-worker load | passed strict oracle-only under 60 s with fallback replaced by `fail`; replay CPF certified 2x | CeTA changes: none |
| `TRS_Standard/Endrullis_06/pair3swap.ari` | producing proof: `target/termcomp-runs/20260731-endrullis-cluster-all-certified-5x60s/TRS_Standard/Endrullis_06/pair3swap/proof.cpf.xml`; live residual recovery and strict replay: `target/integration-endrullis-linear2-pair3swap-refresh-20260731` | Dependency graph; monotonic polynomial deletion; forward instantiation; graph decomposition; sparse dimension-4 natural matrix closure. The current mono and instantiation children are indexed independently. | certified, 2x on producing, live, and replay proofs | global adaptive oracle v122 and later | current default certified YES in 4.5 s | passed strict oracle-only under 60 s with fallback replaced by `fail`; replay CPF certified 2x | CeTA changes: none |
| `TRS_Innermost/Applicative_AG01_innermost/#4.26.ari` | earlier proof: `target/data-campaign/state-first-adaptive-20260729-132133/staged-innermost-applicative-batch/TRS_Innermost/Applicative_AG01_innermost/sharp_4.26/proof.cpf.xml`; dispatch proof: `target/data-campaign/state-first-adaptive-20260729-132133/staged-applicative-426-dispatch-20260730/TRS_Innermost/Applicative_AG01_innermost/#4.26/proof.cpf.xml` | Native uncurrying; explicit `switchInnermost`; DP graph/subterm closures; focused rational polynomial and residual size-change branches. Applicability dispatch now selects uncurrying before the general innermost portfolio. | both certified, 2x | adaptive Transformed-CSR r01 oracle v8 | improved from 111 s to about 17 s | pending strict replay | pending release rerun |
| `TRS_Innermost/Applicative_AG01_innermost/#4.28.ari` | recovered replay: `target/data-campaign/state-first-adaptive-20260729-132133/staged-applicative-426-dispatch-20260730/TRS_Innermost/Applicative_AG01_innermost/#4.28/proof.cpf.xml` | Applicative dispatch; native uncurrying; `switchInnermost`; DP graph and certified residual closures | certified, 2x | adaptive Transformed-CSR r01 oracle v8 | recovered with the current 60-second default after the reported artifact was absent | pending strict replay | pending release rerun |
| `TRS_Innermost/Applicative_AG01_innermost/#4.34.ari` | earlier proof: `target/data-campaign/state-first-adaptive-20260729-132133/staged-innermost-applicative-batch/TRS_Innermost/Applicative_AG01_innermost/sharp_4.34/proof.cpf.xml`; recovered dispatch replay: `target/data-campaign/state-first-adaptive-20260729-132133/staged-applicative-426-dispatch-20260730/TRS_Innermost/Applicative_AG01_innermost/#4.34/proof.cpf.xml` | Native uncurrying; explicit `switchInnermost`; DP graph with usable-rule, subterm, polynomial, and size-change closures | both certified, 2x | adaptive Transformed-CSR r01 oracle v8 | recovered with the current 60-second default after the reported artifact was absent | pending strict replay | pending release rerun |
| `TRS_Innermost/Applicative_AG01_innermost/#4.36.ari` | `target/data-campaign/state-first-adaptive-20260729-132133/staged-innermost-applicative-batch/TRS_Innermost/Applicative_AG01_innermost/sharp_4.36/proof.cpf.xml` | Native uncurrying; explicit `switchInnermost`; DP graph with repeated subterm and size-change closures | certified, 2x | pending adaptive post-r03 export | solved by pinned post-r03 release default under concurrent load | pending post-r03 strict replay | pending release rerun |
| `TRS_Innermost/Applicative_AG01_innermost/#4.8.ari` | `target/data-campaign/state-first-adaptive-20260729-132133/staged-innermost-408/TRS_Innermost/Applicative_AG01_innermost/sharp_4.8/proof.cpf.xml`; recovered Q-CAP path: `target/data-campaign/state-first-adaptive-20260729-132133/staged-applicative-ag01-qcap-20260730/TRS_Innermost/Applicative_AG01_innermost/#4.8/proof.cpf.xml` | Original DP graph and semantic-labeling proof with all 96 Q terms; the later proof records the tighter CeTA-reachability plus Q-normal-CAP graph path, usable rules, and subterm closure | both certified, 2x | adaptive Transformed-CSR r01 oracle v5 | recovered automatically by the current Q-CAP graph implementation | pending strict replay | pending release rerun |
| `TRS_Innermost/AG01_innermost/#4.30.ari` | `target/data-campaign/state-first-adaptive-20260729-132133/staged-innermost-430/TRS_Innermost/AG01_innermost/sharp_4.30/proof.cpf.xml` | Innermost DP; ranked/backtracking narrowing; repeated usable-rule, graph, subterm, and size-change states. Fourteen extracted events include all five certified usable-rule transitions. | certified, 2x | adaptive manual-evidence oracle v4 | solved by current release default in about 43 s | pending post-r01 strict replay | pending release rerun; also recheck `#4.29`, `#4.30a`, and `#4.30b` |
| `TRS_Innermost/AG01_innermost/#4.31.ari` | `target/data-campaign/state-first-adaptive-20260729-132133/staged-innermost-431/TRS_Innermost/AG01_innermost/sharp_4.31/proof.cpf.xml`; strict replay: `target/data-campaign/state-first-adaptive-20260729-132133/manual-evidence-recursive-20260730/v13-strict-ag431/proof.cpf.xml` | String reversal; WCR-checked `switchInnermost`; DP and graph decomposition; two SAT-backed dimension-3 arctic matrix steps with usable-rule and innermost-LHS reduction between them. Native, normalized, and both live residual arctic states are independently keyed. | certified, 2x | adaptive Transformed-CSR r03 oracle v11 and later | strict replay finishes in about 1 s | passed, strict oracle-only with fallback disabled; reconstructed CPF certified 2x | pending release rerun |
| `TRS_Innermost/AG01_innermost/#4.36.ari` | `target/data-campaign/state-first-adaptive-20260729-132133/staged-ag01-436-qiedg/TRS_Innermost/AG01_innermost/sharp_4.36/proof.cpf.xml` | Q-aware IEDG with the realizable `replace# -> if_replace#` edge; DP graph followed by five certified usable-rule contexts and size-change/subterm component closures. Twelve exact proof-state events are retained. | certified, 2x | adaptive Transformed-CSR r01 oracle v3 | solved by the current implementation; `#4.33`–`#4.35` retained certified | pending strict replay | pending release rerun |
| `TRS_Standard/Mixed_TRS/7.ari` | `target/data-campaign/state-first-adaptive-20260729-132133/staged-mixed-trs-7/TRS_Standard/Mixed_TRS/7/proof.cpf.xml` | Applicative uncurrying; DP and graph decomposition; AF-aware usable rules; checked dimension-3 arctic and KBO witnesses; correctly freshened narrowing/forward-instantiation states | certified, 2x | adaptive Transformed-CSR r01 oracle v4 | current default certified in 0.835 s | pending strict replay | pending release rerun |
| `TRS_Innermost/Applicative_AG01_innermost/#4.2.ari` | `target/data-campaign/state-first-adaptive-20260729-132133/staged-applicative-ag01-qcap-20260730/TRS_Innermost/Applicative_AG01_innermost/#4.2/proof.cpf.xml` | Innermost DP; dependency graph combining CeTA reachability with Q-normal CAP admissibility; usable rules and subterm closure | certified, 2x | adaptive Transformed-CSR r01 oracle v5 | recovered automatically by the current implementation | pending strict replay | pending release rerun |
| `TRS_Innermost/Applicative_AG01_innermost/#4.3.ari` | `target/data-campaign/state-first-adaptive-20260729-132133/staged-applicative-ag01-qcap-20260730/TRS_Innermost/Applicative_AG01_innermost/#4.3/proof.cpf.xml` | Recovered innermost DP graph, usable-rule, and subterm path under the Q-normal-CAP graph criterion | certified, 2x | adaptive Transformed-CSR r01 oracle v5 | recovered automatically by the current implementation | pending strict replay | pending release rerun |
| `TRS_Innermost/Applicative_AG01_innermost/#4.5.ari` | `target/data-campaign/state-first-adaptive-20260729-132133/staged-applicative-ag01-qcap-20260730/TRS_Innermost/Applicative_AG01_innermost/#4.5/proof.cpf.xml` | Recovered innermost DP graph, usable-rule, and subterm path under the Q-normal-CAP graph criterion | certified, 2x | adaptive Transformed-CSR r01 oracle v5 | recovered automatically by the current implementation | pending strict replay | pending release rerun |
| `TRS_Innermost/Applicative_AG01_innermost/#4.7.ari` | `target/data-campaign/state-first-adaptive-20260729-132133/staged-applicative-ag01-qcap-20260730/TRS_Innermost/Applicative_AG01_innermost/#4.7/proof.cpf.xml` | Recovered innermost DP graph, usable-rule, and subterm path under the Q-normal-CAP graph criterion | certified, 2x | adaptive Transformed-CSR r01 oracle v5 | recovered automatically by the current implementation | pending strict replay | pending release rerun |
| `TRS_Innermost/Applicative_AG01_innermost/#4.10.ari` | `target/data-campaign/state-first-adaptive-20260729-132133/staged-applicative-ag01-qcap-20260730/TRS_Innermost/Applicative_AG01_innermost/#4.10/proof.cpf.xml` | Recovered innermost DP graph, usable-rule, narrowing, and subterm path under the Q-normal-CAP graph criterion | certified, 2x | adaptive Transformed-CSR r01 oracle v5 | recovered automatically by the current implementation | pending strict replay | pending release rerun |
| `TRS_Innermost/Applicative_AG01_innermost/#4.13.ari` | `target/data-campaign/state-first-adaptive-20260729-132133/staged-applicative-ag01-qcap-20260730/TRS_Innermost/Applicative_AG01_innermost/#4.13/proof.cpf.xml` | Recovered innermost DP graph, usable-rule, and subterm path under the Q-normal-CAP graph criterion | certified, 2x | adaptive Transformed-CSR r01 oracle v5 | recovered automatically by the current implementation | pending strict replay | pending release rerun |
| `TRS_Contextsensitive/CSR_04/Ex9_Luc04.ari` | `target/data-campaign/state-first-adaptive-20260729-132133/staged-csr-ex9-luc04-20260730/TRS_Contextsensitive/CSR_04/Ex9_Luc04/proof.cpf.xml` | Improved context-sensitive dependency pairs; the impossible self-edge is removed by frozen/shared-argument equality propagation and a tcap rewrite refutation | certified, 2x | adaptive Transformed-CSR r01 oracle v6 | reproduced by current debug default in under 0.2 s | pending strict replay | pending release rerun |
| `TRS_Contextsensitive/CSR_04/Ex9_Luc06.ari` | earlier proof: `target/data-campaign/state-first-adaptive-20260729-132133/staged-csr-ex9-luc06-20260730/TRS_Contextsensitive/CSR_04/Ex9_Luc06/proof.cpf.xml`; refreshed proof: `target/data-campaign/state-first-adaptive-20260729-132133/staged-window-evidence-20260730/TRS_Contextsensitive/CSR_04/Ex9_Luc06/proof.cpf.xml` | Exact improved CS-DPs, including the required hidden `U(b) -> b#` pair; graph decomposition; direct LPAR'08 context-sensitive instantiation; residual graph closure. Ferrum now rejects the uncertifiable usable-rule reduction-pair sibling before it can displace this proof. | both certified, 2x | adaptive Transformed-CSR r02 oracle v5; refreshed evidence in r03 v39 | current default certified in 1.368 s | root and most children retained; standalone QCS graph/instantiation fragment certification remains blocked by CPF's top-level `<csrDpProof>` representability gap and is not promoted from the rejected probes | pending release rerun; current proof needs no CeTA source change |
| `TRS_Standard/Waldmann_06/jwteparla1.ari` | producing proof: `target/data-campaign/state-first-adaptive-20260729-132133/staged-jwteparla1-20260730/TRS_Standard/Waldmann_06/jwteparla1/proof.cpf.xml`; strict replay: `target/data-campaign/state-first-adaptive-20260729-132133/manual-evidence-recursive-20260730/v35-open-roots-strict/TRS_Standard/Waldmann_06/jwteparla1/proof.cpf.xml` | `switchInnermost`; complete standard DPs; Q-aware graph decomposition; polynomial reduction; CeTA-compatible empty-region narrowing; final graph closure | certified, 2x | adaptive Transformed-CSR r03 oracle v35 | current default certified in about 2.5 s | passed, strict oracle-only in 2.068 s; reconstructed CPF certified 2x | pending release rerun; CeTA changes: none |
| `TRS_Innermost/Mixed_innermost/innermost2.ari` | `target/data-campaign/state-first-adaptive-20260729-132133/staged-innermost2-qrewrite-20260730/TRS_Innermost/Mixed_innermost/innermost2/proof.cpf.xml` | Innermost DP; graph decomposition; Q-preserving DP rewriting of `a(b)` to `d`; residual graph closure. The corrected exact extractor retains all four `dp`, `graph`, `rewrite`, `graph` states. | certified, 2x | adaptive Transformed-CSR r01 oracle v11 | current release default certified in 0.039 s; `#4.19`, `#4.26`, and `#4.36` remained certified in the producing regression | pending strict replay | pending release rerun; CeTA changes: none |
| `TRS_Innermost/Mixed_innermost/run_again1.ari` | `target/data-campaign/state-first-adaptive-20260729-132133/staged-run-again1-switch-full-20260730/TRS_Innermost/Mixed_innermost/run_again1/proof.cpf.xml` | Orthogonality justifies `switchFullStrategy`; the full-rewriting residual closes by a native loop. Both the strong transformation and terminal `nontermination(loop)` state are retained. | certified NO, 2x | adaptive Transformed-CSR r01 oracle v12 | current release default returns certified nontermination | pending strict replay | pending release rerun; CeTA changes: none |
| `TRS_Innermost/Mixed_innermost/run_again2.ari` | producing proof: `target/innermost-gm04-integration-20260828/ordinary-frontier-run-again2-default-60/proof.cpf.xml`; strict replay: `target/innermost-gm04-integration-20260828/run-again2-v1489-strict-60/proof.cpf.xml` | Orthogonality justifies `switchFullStrategy`; the full-rewriting residual closes by the native `run_again(init) -> run_again(init)` loop. The exact root action is regenerated rather than replaying an opaque CPF fragment. | certified NO, 2x on producing and strict proofs | innermost oracle v1489 | explicit nontermination search 3.05 s; strict oracle-only 4.74 s | passed strict oracle-only with fallback `fail`; both CPFs certified twice by production CeTA | CeTA changes: none; AProVE 2025 timed out, so this is a new raw-parity gain |
| `TRS_Standard/Waldmann_06/jwcime1.ari` | `target/termcomp-runs/20260730-jwcime1-origin-regression-60s/TRS_Standard/Waldmann_06/jwcime1/proof.cpf.xml` | Standard DP; graph decomposition; bounded forward instantiation with persistent source origins; semantic labeling; certified reduction pairs and residual size-change closure. Persistent origins keep transformed descendants from resetting per-pair exploration counters. | certified, 2x | adaptive Transformed-CSR r02 oracle v3 | current release default certified in 8 s isolated and 52.499 s under four-way load; nearby regression 4/4 certified | pending strict replay | pending release rerun; CeTA changes: none |
| `TRS_Standard/Endrullis_06/pair3hard.ari` | `target/data-campaign/state-first-adaptive-20260729-132133/staged-pair3hard-20260730/TRS_Standard/Endrullis_06/pair3hard/proof.cpf.xml` | Standard DP; reduction-pair deletion; forward instantiation; graph decomposition; semantic labeling; polynomial residual closures. All transformed descendants are retained independently, without depending on AProVE's exact deletion history. | certified, 2x | pending next monotone export | current default certified in 5.041 s under the retained five-way regression | pending strict replay | pending release rerun; CeTA changes: none |
| `TRS_Innermost/AG01_innermost/#4.37a.ari` | `target/data-campaign/state-first-adaptive-20260729-132133/staged-ag01-437a-20260730/TRS_Innermost/AG01_innermost/sharp_4.37a/proof.cpf.xml` | Innermost DP graph with two independently addressable polynomial-backed size-change components | certified, 2x | pending next monotone export | current default certified within 60 s after the speculative narrowing heuristic was removed | pending strict replay | pending release rerun; CeTA changes: none |
| `TRS_Contextsensitive/CSR_04/ExIntrod_GM99.ari` | `target/data-campaign/state-first-adaptive-20260729-132133/staged-csr-exintrod-gm99-20260730/TRS_Contextsensitive/CSR_04/ExIntrod_GM99/proof.cpf.xml` | Refined Gutiérrez–Lucas hiding search; conservative improved-CS-DP certificate parent; certificate-only unhiding projections grouped into an independently indexed subterm component | certified, 2x | pending next monotone export | current debug default certified in 0.095 s | pending strict replay | pending release rerun; CeTA changes: none |
| `TRS_Innermost/AG01_innermost/#4.18.ari` | `target/data-campaign/state-first-adaptive-20260729-132133/staged-ag01-418-20260730/TRS_Innermost/AG01_innermost/sharp_4.18/proof.cpf.xml` | Innermost DP followed by a graph proof with three independently indexed acyclic components | certified, 2x | pending next monotone export | current release default certified in 1.43 s after top-level polling stopped executing a long cancelled sibling | pending strict replay | pending release rerun; CeTA changes: none |
| `TRS_Standard/Waldmann_06/jwtpa1.ari` | `target/data-campaign/state-first-adaptive-20260729-132133/staged-jwtpa1-20260730/TRS_Standard/Waldmann_06/jwtpa1/proof.cpf.xml` | `switchInnermost`; graph decomposition; bounded forward instantiation; carrier-two semantic labeling; repeated usable-rule polynomial and graph closures, with every live typed descendant retained | certified, 2x | pending next monotone export | current release default certified in 7.5 s isolated and 8.3 s under six-way load | pending strict replay | pending release rerun; CeTA changes: none |
| `TRS_Innermost/AG01_innermost/#4.25.ari` | `target/data-campaign/state-first-adaptive-20260729-132133/staged-ag01-425-20260730/TRS_Innermost/AG01_innermost/sharp_4.25/proof.cpf.xml` | Innermost DP; active-usable-rule rewriting of `g(x)` to `s(x)`; empty CeTA-compatible instantiation closure. Five exact proof states and four runtime-canonical DP aliases are retained so each continuation is independently addressable. | certified, 2x | adaptive Transformed-CSR r02 oracle v25 and later | current debug default certified in under 1 s; producing release run was 44 ms | passed, strict oracle-only, reconstructed CPF certified 2x | pending release rerun; CeTA changes: none |
| `TRS_Innermost/Transformed_CSR_innermost_04/ExConc_Zan97_iGM.ari` | `target/data-campaign/state-first-adaptive-20260729-132133/staged-exconc-zan97-igm-20260730/TRS_Innermost/Transformed_CSR_innermost_04/ExConc_Zan97_iGM/proof.cpf.xml` | Innermost DP dispatch before the unary-SRS portfolio; graph decomposition; four usable-rule/size-change residual components. Ten exact proof nodes and nine runtime-canonical DP aliases make every continuation independently addressable. | certified, 2x | adaptive Transformed-CSR r02 oracle v31 | current default certified in 79 ms; seven-example peer slice remained certified | passed, strict oracle-only; byte-identical reconstructed CPF certified 2x | pending release rerun; CeTA changes: none |
| `TRS_Standard/Zantema_05/z01.ari` | `target/data-campaign/state-first-adaptive-20260729-132133/staged-zantema-z01-20260730/TRS_Standard/Zantema_05/z01/proof.cpf.xml` | Uncurrying; polynomial rule removal; `switchInnermost`; DP graph; narrowing; arctic matrix; forward instantiation; semantic labeling; usable rules and polynomial closure. Certified live probe chains are retained in oracle v38. | certified, 2x | adaptive Transformed-CSR r02 oracle v32, recursively extended through v38 | current default reproduced the byte-identical proof | pending: strict replay continues to expose additional labeled live variants | pending release rerun; extractor wrapper-ranking bug fixed during integration |
| `TRS_Standard/Zantema_05/z19.ari` | `target/termcomp-runs/20260730-z19-regression-final-v3-8x60s/TRS_Standard/Zantema_05/z19/proof.cpf.xml`; strict replay: `target/data-campaign/state-first-adaptive-20260729-132133/manual-evidence-recursive-20260730/v69-z19-strict-no-fallback/proof.cpf.xml` | Full DP; graph/order retry after reduction-pair deletion; carrier-two semantic labeling; exact replayable polynomial, graph, and terminal size-change/subterm descendants. Successful utility events now retain their input CPF, and one-shot probes no longer pre-decompose the requested state. | certified, 2x | adaptive Transformed-CSR r02 oracle v40; complete strict chain in v69 | current default certified in 18.477 s; regression 8/8 certified | passed, strict oracle-only with fallback disabled; reconstructed CPF certified 2x | pending release rerun; CeTA changes: none |
| `TRS_Contextsensitive/CSR_04/Ex4_Zan97.ari` | `target/data-campaign/state-first-adaptive-20260729-132133/staged-ex4-zan97-20260730/TRS_Contextsensitive/CSR_04/Ex4_Zan97/proof.cpf.xml` | Exact improved CS-DPs; graph decomposition into three cyclic singleton obligations; size-change closure for each. | certified, 2x | adaptive Transformed-CSR r02 oracle v40 | current default certified in about 0.7 s | pending: strict guidance detects a same-root CSR transformation cycle | pending release rerun; CeTA changes: none |
| `TRS_Contextsensitive/CSR_04/Ex8_BLR02.ari` | `target/data-campaign/state-first-adaptive-20260729-132133/staged-ex8-blr02-20260730/TRS_Contextsensitive/CSR_04/Ex8_BLR02/proof.cpf.xml`; strict replay: `target/data-campaign/state-first-adaptive-20260729-132133/manual-evidence-recursive-20260730/v71-ex8-strict-no-fallback/proof.cpf.xml` | Exact improved CS-DPs; graph decomposition; three independently keyed cyclic singleton obligations closed by size change. The root recommendation is the executable compound atom `dp(size-change)`, and each cyclic QCS child is independently keyed as `size-change`. | certified, 2x | adaptive Transformed-CSR r02 oracle v46; compound root guidance in v71 | current default certified in 0.172 s | passed, strict oracle-only with fallback disabled; reconstructed CPF certified 2x | pending release rerun; CeTA-CSR parser support committed as `934e971` |
| `TRS_Innermost/Transformed_CSR_innermost_04/LengthOfFiniteLists_nosorts_GM.ari` | `target/data-campaign/state-first-adaptive-20260729-132133/staged-rule-subset-nosorts-20260730/TRS_Innermost/Transformed_CSR_innermost_04/LengthOfFiniteLists_nosorts_GM/proof.cpf.xml` | Ranked small-rule-subset narrowing discovers a loop that is revalidated against the complete original innermost TRS. The final CPF is a direct full-TRS loop and has no open child obligation. | certified NO, 2x | adaptive Transformed-CSR r02 oracle v39 | current default certified in 0.613 s | passed, strict oracle-only, 2x certified | pending release rerun; CeTA changes: none |
| `TRS_Innermost/Transformed_CSR_innermost_04/LengthOfFiniteLists_nosorts_noand_GM.ari` | `target/data-campaign/state-first-adaptive-20260729-132133/staged-rule-subset-nosorts-20260730/TRS_Innermost/Transformed_CSR_innermost_04/LengthOfFiniteLists_nosorts_noand_GM/proof.cpf.xml` | Same full-TRS-validated subset-narrowing loop family; the retained executable recommendation includes the complete bounded nontermination sequence. | certified NO, 2x | adaptive Transformed-CSR r02 oracle v39 | current default certified in 0.466 s | passed, strict oracle-only, 2x certified | pending release rerun; CeTA changes: none |
| `TRS_Innermost/Transformed_CSR_innermost_04/OvConsOS_nosorts_GM.ari` | `target/data-campaign/state-first-adaptive-20260729-132133/staged-rule-subset-nosorts-20260730/TRS_Innermost/Transformed_CSR_innermost_04/OvConsOS_nosorts_GM/proof.cpf.xml` | Ranked rule-subset narrowing followed by validation of the loop against the full original innermost relation. | certified NO, 2x | adaptive Transformed-CSR r02 oracle v39 | current default certified in 1.17 s | passed, strict oracle-only, 2x certified | pending release rerun; CeTA changes: none |
| `TRS_Innermost/Transformed_CSR_innermost_04/OvConsOS_nosorts_noand_GM.ari` | `target/data-campaign/state-first-adaptive-20260729-132133/staged-ovcons-nosorts-noand-20260730/TRS_Innermost/Transformed_CSR_innermost_04/OvConsOS_nosorts_noand_GM/proof.cpf.xml` | Dependency-ranked five-rule subset narrowing finds a five-step innermost loop, then revalidates it against all 31 original rules. The terminal loop has no nested obligation. | certified NO, 2x | adaptive Transformed-CSR r02 oracle v48 | current default certified in about 10 s | passed, strict oracle-only, byte-identical CPF certified 2x after fixing the guided-family timeout | pending release rerun; CeTA changes: none |
| `TRS_Standard/Zantema_15/ex01.ari` | `target/data-campaign/state-first-adaptive-20260729-132133/staged-zantema15-ex01-20260730/TRS_Standard/Zantema_15/ex01/proof.cpf.xml` | Native CPF `nonterminatingSRS` derivation-pattern proof for the symbol-independent commuting-pump schema; the root proof is terminal and has no residual child. | certified NO, 2x | adaptive Transformed-CSR r02 oracle v47 | current default certified in under 0.1 s | passed, strict oracle-only, 2x certified | pending release rerun; CeTA changes: none |
| `TRS_Standard/Zantema_15/ex04.ari` | `target/data-campaign/state-first-adaptive-20260729-132133/staged-zantema15-ex04-20260730/TRS_Standard/Zantema_15/ex04/proof.cpf.xml` | Native CPF `nonterminatingSRS` derivation-pattern proof for the generalized word-context pumping schema. The terminal root proof has no residual child and retains `nontermination(srs-derivation-patterns)` as its executable recommendation. | certified NO, 2x | adaptive Transformed-CSR r02 oracle v55; live-root alias in v56 | current default certified in under 0.1 s; the retained ten-example SRS-NO slice is 10/10 certified | passed, strict oracle-only, reconstructed CPF certified 2x | pending release rerun; CeTA changes: none |
| `TRS_Innermost/Transformed_CSR_innermost_04/PALINDROME_nokinds_noand_iGM.ari` | `target/data-campaign/state-first-adaptive-20260729-132133/staged-palindrome-peano-ex1luc02b-20260730/TRS_Innermost/Transformed_CSR_innermost_04/PALINDROME_nokinds_noand_iGM/proof.cpf.xml`; strict replay: `target/data-campaign/state-first-adaptive-20260729-132133/manual-evidence-recursive-20260730/v73-strict-no-fallback/palindrome/proof.cpf.xml` | The live root closes with bounded SMT linear polynomial synthesis, `smt-poly(max-constant=2,max-coefficient=2)`. It is terminal in the producing and strict-guided runs, so there is no residual obligation to index. | certified, 2x | adaptive Transformed-CSR r02 oracle v72; live-root alias in v73 | current default certified in about 2.54 s | passed, strict oracle-only with fallback disabled; reconstructed CPF certified 2x | pending release rerun; CeTA changes: none |
| `TRS_Innermost/Transformed_CSR_innermost_04/PEANO_nosorts_noand_iGM.ari` | `target/data-campaign/state-first-adaptive-20260729-132133/staged-palindrome-peano-ex1luc02b-20260730/TRS_Innermost/Transformed_CSR_innermost_04/PEANO_nosorts_noand_iGM/proof.cpf.xml`; strict replay: `target/data-campaign/state-first-adaptive-20260729-132133/manual-evidence-recursive-20260730/v73-strict-no-fallback/peano/proof.cpf.xml` | The live root closes with bounded SMT linear polynomial synthesis, `smt-poly(max-constant=2,max-coefficient=2)`. It is terminal in the producing and strict-guided runs, so there is no residual obligation to index. | certified, 2x | adaptive Transformed-CSR r02 oracle v72; live-root alias in v73 | current default certified in about 2.45 s | passed, strict oracle-only with fallback disabled; reconstructed CPF certified 2x | pending release rerun; CeTA changes: none |
| `TRS_Contextsensitive/CSR_04/Ex1_Luc02b.ari` | `target/data-campaign/state-first-adaptive-20260729-132133/staged-palindrome-peano-ex1luc02b-20260730/TRS_Contextsensitive/CSR_04/Ex1_Luc02b/proof.cpf.xml`; strict replay: `target/data-campaign/state-first-adaptive-20260729-132133/manual-evidence-recursive-20260730/v73-strict-no-fallback/ex1-luc02b/proof.cpf.xml` | Exact improved CS-DPs; graph decomposition; two cyclic singleton obligations closed by size change. The executable root is `dp(graph;size-change)` and both live QCS-DP children are independently keyed as `size-change`. | certified, 2x | adaptive Transformed-CSR r02 oracle v72 | current default certified in 0.091 s | passed, strict oracle-only with fallback disabled; root and both live children independently found; reconstructed CPF certified 2x | pending release rerun; CeTA changes: none |
| `TRS_Contextsensitive/CSR_04/Ex4_7_56_Bor03.ari` | `target/data-campaign/state-first-adaptive-20260729-132133/staged-csr-ex4-7-56-bor03-20260730/TRS_Contextsensitive/CSR_04/Ex4_7_56_Bor03/proof.cpf.xml`; strict replay: `target/data-campaign/state-first-adaptive-20260729-132133/manual-evidence-recursive-20260730/r03-v2-ex4-7-56-strict/proof.cpf.xml` | Innermost reasoning guides search, but the retained certificate is a full improved-CS-DP CSR proof with no innermost-LHSS or ordinary-DP wrapper. The executable root is `dp(graph;size-change)` and its live QCS-DP child is independently keyed as `size-change`. | certified, 2x | adaptive Transformed-CSR r03 oracle v2 | current default certified in 0.119 s | passed, strict oracle-only with fallback disabled; root and live child independently found; reconstructed CPF certified 2x | pending release rerun; CeTA changes: none |
| `TRS_Contextsensitive/CSR_04/Ex3_12_Luc96a.ari` | `target/data-campaign/state-first-adaptive-20260729-132133/manual-evidence-recursive-20260730/ex3-12-luc96a-explicit/proof.cpf.xml`; strict replay: `target/data-campaign/state-first-adaptive-20260729-132133/manual-evidence-recursive-20260730/r03-v4-ex3-12-strict/proof.cpf.xml` | Refined improved-CS-DP search has one cyclic SCC; certificate reconstruction restores the second certificate-only U-projection SCC. The executable root is `dp(graph;size-change)` and the live child is independently keyed as `size-change`. | certified, 2x | adaptive Transformed-CSR r03 oracle v4 | current default certified in 0.088 s | passed, strict oracle-only with fallback disabled; root and live child independently found; reconstructed CPF certified 2x | pending release rerun; CeTA changes: none |
| `TRS_Contextsensitive/CSR_04/Ex7_BLR02.ari` | producing proof: `target/data-campaign/state-first-adaptive-20260729-132133/staged-csr-ex7-blr02-20260730/TRS_Contextsensitive/CSR_04/Ex7_BLR02/proof.cpf.xml`; strict replay: `target/data-campaign/state-first-adaptive-20260729-132133/manual-evidence-recursive-20260730/v16-strict-ex7/proof.cpf.xml` | Exact improved CS-DPs; graph decomposition; live `sel#` and unhiding-symbol singleton obligations independently close by size change. Root-DP extraction was corrected so the oracle selects CS-DPs rather than a generic termination placeholder. | certified, 2x | adaptive Transformed-CSR r03 oracle v16 | producing default 0.097 s; strict replay under 1 s | passed, strict oracle-only with fallback disabled; root and both live cyclic children independently found; reconstructed CPF certified 2x | pending release rerun; CeTA changes: none |
| `TRS_Innermost/Transformed_CSR_innermost_04/Ex49_GM04_GM.ari` | `target/data-campaign/state-first-adaptive-20260729-132133/staged-ex49-gm04-gm-20260730/TRS_Innermost/Transformed_CSR_innermost_04/Ex49_GM04_GM/proof.cpf.xml` | Innermost DPs; polynomial/matrix reduction; narrowing; forward instantiation; dependency graphs; usable rules; size-change. Nine current nested states replayed and certified independently. | certified, 2x | adaptive Transformed-CSR r03 oracle v16 | producing default 14.284 s | open: current root `dp` and explicit producing sequence now time out at 60 s, while retained child evidence remains usable | replay-fidelity/runtime regression retained visibly; CeTA changes: none |
| `TRS_Innermost/Transformed_CSR_innermost_04/Ex14_AEGL02_iGM.ari` | producing proof: `target/data-campaign/state-first-adaptive-20260729-132133/staged-ex14-aegl02-igm-20260730/TRS_Innermost/Transformed_CSR_innermost_04/Ex14_AEGL02_iGM/proof.cpf.xml`; strict replay: `target/data-campaign/state-first-adaptive-20260729-132133/manual-evidence-recursive-20260730/v28b-full-registry-strict/TPDB-ARI__TRS_Innermost__Transformed_CSR_innermost_04__Ex14_AEGL02_iGM.cpf.xml` | Innermost DP; dimension-2 matrix interpretation; graph decomposition; forward instantiation; residual matrix/subterm/terminal closures. Every live transformed descendant in the current chain is independently keyed. | certified, 2x | adaptive Transformed-CSR r03 oracle v28 | current default proof retained | passed, strict oracle-only in 1.49 s; reconstructed CPF certified 2x | pending release rerun; CeTA changes: none |
| `TRS_Contextsensitive/CSR_04/ExSec4_2_DLMMU04.ari` | producing proof: `target/data-campaign/state-first-adaptive-20260729-132133/staged-csr-exsec4-2-dlmmu04-20260730/TRS_Contextsensitive/CSR_04/ExSec4_2_DLMMU04/proof.cpf.xml`; strict replay: `target/data-campaign/state-first-adaptive-20260729-132133/manual-evidence-recursive-20260730/v28b-full-registry-strict/TPDB-ARI__TRS_Contextsensitive__CSR_04__ExSec4_2_DLMMU04.cpf.xml` | Improved CS-DPs; graph decomposition; the live `splitAt# -> splitAt#` singleton closes by size change. The root and live QCS-DP child are independently keyed. | certified, 2x | adaptive Transformed-CSR r03 oracle v28 | current default proof retained | passed, strict oracle-only in 0.93 s; reconstructed CPF certified 2x | pending release rerun; CeTA changes: none |
| `TRS_Standard/AProVE_06/factorial1.ari` | producing proof: `target/data-campaign/state-first-adaptive-20260729-132133/manual-evidence-recursive-20260730/factorial1-current-default/proof.cpf.xml`; strict replay: `target/data-campaign/state-first-adaptive-20260729-132133/manual-evidence-recursive-20260730/v31-factorial1-strict/proof.cpf.xml` | Standard DPs; live one-pair components close by weak polynomial, linear polynomial, dimension-2 matrices, and subterm. A newly exposed residual is closed directly by a terminal dimension-2 matrix rather than retaining its open polynomial transformation. | certified, 2x | adaptive Transformed-CSR r03 oracle v31 | current default certified in 2.5 s | passed, strict oracle-only in 7.4 s; reconstructed CPF certified 2x | pending release rerun; CeTA changes: none |
| `TRS_Innermost/Transformed_CSR_innermost_04/Ex6_9_Luc02c_iGM.ari` | `target/data-campaign/state-first-adaptive-20260729-132133/staged-ex6-9-luc02c-igm-20260730/TRS_Innermost/Transformed_CSR_innermost_04/Ex6_9_Luc02c_iGM/proof.cpf.xml` | Innermost DP; graph decomposition; narrowing with complete obligations below the selected position; alpha-equivalent residual deduplication; usable-rule matrix, subterm, and terminal graph closures. Twelve certified nested states are independently indexed. | certified, 2x | adaptive Transformed-CSR r03 oracle v32 | producing run certified in about 3 s | open: the current root DP probe timed out at 60 s; certified child guidance is retained without a root overclaim | pending release rerun; CeTA changes: none |
| `TRS_Standard/AProVE_04/JFP_Ex31.ari` | `target/data-campaign/state-first-adaptive-20260729-132133/staged-jfp-ex31-20260730/TRS_Standard/AProVE_04/JFP_Ex31/proof.cpf.xml` | Standard DPs; dependency graphs; interpretation-dependent usable-rule polynomial deletion; regional narrowing; semantic labeling; residual polynomial and size-change closures. All sixteen proof-path states replayed independently and certified twice. | certified, 2x | adaptive Transformed-CSR r03 oracle v35 | producing default certified in 29.4 s | open: strict replay reaches a current ten-rule usable-rules residual not present in the producing twelve-rule proof chain; the stale raw aliases for the root and initial SCC were corrected | pending release rerun; CeTA changes: none |
| `TRS_Standard/AProVE_04/IJCAR_26.ari` | producing proof: `target/data-campaign/state-first-adaptive-20260729-132133/staged-window-evidence-20260730/TRS_Standard/AProVE_04/IJCAR_26/proof.cpf.xml`; strict replay: `target/data-campaign/state-first-adaptive-20260729-132133/manual-evidence-recursive-20260730/v43-ijcar-strict/TRS_Standard/AProVE_04/IJCAR_26/proof.cpf.xml` | Standard DPs; graph decomposition; jointly synthesized KBO, argument filtering, and filter-dependent usable-rule closure; final size-change/subterm components. CeTA's root-before-active-position semantics are reproduced exactly. A weak-polynomial model with an unrepresentable negative constant was rejected before proof construction, and the replay found an alternate certifiable chain. | certified, 2x | adaptive Transformed-CSR r03 oracle v43 | producing default certified in 3.391 s; corrected fallback replay certified in 4.039 s | passed, strict oracle-only in 1.697 s with fallback disabled; all 46 current IJCAR proof-path trials independently certified twice; reconstructed CPF certified 2x | pending release rerun; CeTA changes: none |
| `TRS_Standard/AProVE_04/IJCAR_26a.ari` | producing proof: `target/data-campaign/state-first-adaptive-20260729-132133/staged-window-evidence-20260730/TRS_Standard/AProVE_04/IJCAR_26a/proof.cpf.xml`; strict replay: `target/data-campaign/state-first-adaptive-20260729-132133/manual-evidence-recursive-20260730/v43-ijcar-strict/TRS_Standard/AProVE_04/IJCAR_26a/proof.cpf.xml` | Same joint KBO/filter/usable-rule construction as `IJCAR_26`, with the additional `p(0) -> 0` rule; graph and residual matrix/size-change closures are retained. | certified, 2x | adaptive Transformed-CSR r03 oracle v43 | producing default certified in 4.767 s; corrected fallback replay certified in 11.829 s | passed, strict oracle-only in 2.157 s with fallback disabled; every current nested state is independently findable; reconstructed CPF certified 2x | pending release rerun; CeTA changes: none |
| `TRS_Innermost/Transformed_CSR_innermost_04/Ex14_Luc06_GM.ari` | original: `target/data-campaign/state-first-adaptive-20260729-132133/staged-window-evidence-20260730/TRS_Innermost/Transformed_CSR_innermost_04/Ex14_Luc06_GM/proof.cpf.xml`; current: `target/next-regression-96/default.cpf`; strict replay: `target/integration-window3-ex14-luc06-gm-20260730/strict-v83/per-problem/TRS_Innermost__Transformed_CSR_innermost_04__Ex14_Luc06_GM.cpf.xml` | Innermost DP; bounded polynomial, narrowing, and instantiation phase; graph, usable-rule, matrix, semantic-labeling, and residual closures. The current trace contributes three independently certified terminal states and ten typed transformations. | certified, 2x | adaptive global oracle v83 | current default recovered and certified in 2 s | passed strict oracle-only in 1.5 s with fallback disabled; reconstructed CPF certified 2x | CeTA changes: none |
| `TRS_Innermost/Transformed_CSR_innermost_04/Ex3_3_25_Bor03_C.ari` | producing proof: `target/data-campaign/state-first-adaptive-20260729-132133/staged-window3-followup-20260730/TRS_Innermost/Transformed_CSR_innermost_04/Ex3_3_25_Bor03_C/proof.cpf.xml`; strict replay: `target/data-campaign/state-first-adaptive-20260729-132133/manual-evidence-recursive-20260730/v47-window3-compound-root-strict/TRS_Innermost/Transformed_CSR_innermost_04/Ex3_3_25_Bor03_C/proof.cpf.xml` | Cheap transformed-CSR DP lane: graph, bounded polynomial reduction, graph, size change, and subterm. The complete compound root action and every required certifiable descendant are retained. Two non-self-contained isolated polynomial assumptions remain quarantined. | certified, 2x | adaptive Transformed-CSR r03 oracle v47 | current default certified in 2.0 s | passed, strict oracle-only in 3.786 s with fallback disabled; reconstructed CPF certified 2x | pending release rerun; CeTA changes: none |
| `TRS_Innermost/Transformed_CSR_innermost_04/Ex3_3_25_Bor03_GM.ari` | producing proof: `target/data-campaign/state-first-adaptive-20260729-132133/staged-window3-followup-20260730/TRS_Innermost/Transformed_CSR_innermost_04/Ex3_3_25_Bor03_GM/proof.cpf.xml`; strict replay: `target/data-campaign/state-first-adaptive-20260729-132133/manual-evidence-recursive-20260730/v47-window3-compound-root-strict/TRS_Innermost/Transformed_CSR_innermost_04/Ex3_3_25_Bor03_GM/proof.cpf.xml` | Same cheap transformed-CSR graph/polynomial/size-change pipeline; all required live descendants are independently addressed. | certified, 2x | adaptive Transformed-CSR r03 oracle v47 | current default certified in 8.5 s | passed, strict oracle-only in 12.760 s with fallback disabled; reconstructed CPF certified 2x | pending release rerun; CeTA changes: none |
| `TRS_Innermost/Transformed_CSR_innermost_04/Ex49_GM04_iGM.ari` | producing proof: `target/data-campaign/state-first-adaptive-20260729-132133/staged-window3-followup-20260730/TRS_Innermost/Transformed_CSR_innermost_04/Ex49_GM04_iGM/proof.cpf.xml`; strict replay: `target/data-campaign/state-first-adaptive-20260729-132133/manual-evidence-recursive-20260730/v47-window3-compound-root-strict/TRS_Innermost/Transformed_CSR_innermost_04/Ex49_GM04_iGM/proof.cpf.xml` | Cheap transformed-CSR polynomial lane followed by graph, forward instantiation, usable-rule reductions, and residual closure. The independently certified compound root action avoids depending on an over-broad generic DP probe. | certified, 2x | adaptive Transformed-CSR r03 oracle v47 | current default certified in 27.3 s | passed, strict oracle-only in 3.470 s with fallback disabled; reconstructed CPF certified 2x; the one non-self-contained polynomial assumption remains quarantined | pending release rerun; CeTA changes: none |
| `TRS_Standard/Zantema_05/z05.ari` | producing proof: `target/termcomp-runs/20260730-z05-delayed-uncurry-default-60s/TRS_Standard/Zantema_05/z05/proof.cpf.xml`; strict replay: `target/data-campaign/state-first-adaptive-20260729-132133/manual-evidence-recursive-20260730/v46-z05-strict/TRS_Standard/Zantema_05/z05/proof.cpf.xml` | Applicative uncurrying receives a bounded scheduling head start; DP graph, three per-origin narrowing steps, polynomial reductions, and a dimension-3 arctic matrix close the transformed residuals. | certified, 2x | adaptive Transformed-CSR r03 oracle v46 | current default certified in 2.902 s | passed, strict oracle-only in 9.497 s with fallback disabled; seven independently certified current states retained; reconstructed CPF certified 2x | pending release regression batch; CeTA changes: none |
| `TRS_Standard/Zantema_05/z07.ari` | producing proof: `target/termcomp-runs/20260730-zantema-siblings-final-2x60s/TRS_Standard/Zantema_05/z07/proof.cpf.xml`; strict replay: `target/data-campaign/state-first-adaptive-20260729-132133/manual-evidence-recursive-20260730/v51-z07-strict/TRS_Standard/Zantema_05/z07/proof.cpf.xml` | Sibling validation of the delayed applicative uncurrying race; six exact proof-path states independently certify. | certified, 2x | adaptive Transformed-CSR r03 oracle v51 | current default certified in 1.857 s | passed, strict oracle-only in 3.986 s with fallback disabled; reconstructed CPF certified 2x | pending release rerun; CeTA changes: none |
| `TRS_Standard/Zantema_05/z22.ari` | producing proof: `target/termcomp-runs/20260730-z22-semlab-regression-4w60s/TRS_Standard/Zantema_05/z22/proof.cpf.xml`; strict replay: `target/data-campaign/state-first-adaptive-20260729-132133/manual-evidence-recursive-20260730/v56-windows1-3-strict/z22/proof.cpf.xml` | Structural carrier-two semantic labeling followed by certified polynomial and graph closures. The replayable root action is the direct `dp(semantic-labeling)` route, avoiding the producer's scheduling delay. Its certifiable labeled descendants are independently indexed in v56. | certified, 2x | adaptive Transformed-CSR r03 oracle v56 | current default certified in 49.277 s under four-worker load | passed, strict oracle-only in 0.156 s with fallback disabled; reconstructed CPF certified 2x | pending release rerun; CeTA changes: none |
| `TRS_Innermost/Transformed_CSR_innermost_04/Ex4_7_15_Bor03_iGM.ari` | producing proof: `target/next-example-arctic-default-171.cpf`; strict replay: `target/data-campaign/state-first-adaptive-20260729-132133/manual-evidence-recursive-20260730/v56-windows1-3-strict/bor171/proof.cpf.xml` | Innermost DP sequence combining graph decomposition, polynomial/KBO reductions, bounded instantiation, and residual size-change closure. Its certifiable descendants are independently indexed in v56. | certified, 2x | adaptive Transformed-CSR r03 oracle v56 | current default certified in 1.494 s | passed, strict oracle-only in 6.738 s with fallback disabled; reconstructed CPF certified 2x | pending release rerun; CeTA changes: none |
| `TRS_Innermost/Transformed_CSR_innermost_04/Ex4_7_56_Bor03_GM.ari` | producing proof: `target/next-example-arctic-default-177.cpf`; strict replay: `target/data-campaign/state-first-adaptive-20260729-132133/manual-evidence-recursive-20260730/v56-windows1-3-strict/bor177/proof.cpf.xml` | Repeated dimension-one Arctic DP reductions followed by graph, size-change, and subterm closure. Its certifiable descendants are independently indexed in v56. | certified, 2x | adaptive Transformed-CSR r03 oracle v56 | current default certified in 12.076 s | passed, strict oracle-only in 5.558 s with fallback disabled; reconstructed CPF certified 2x | pending release rerun; CeTA changes: none |
| `TRS_Innermost/Transformed_CSR_innermost_04/Ex4_7_56_Bor03_iGM.ari` | producing proof: `target/next-example-arctic-default-178.cpf`; focused proof: `target/next-example-178-graph-arctic.cpf` | Graph-guided repeated dimension-one Arctic reductions; the retained producer and focused CPFs are both independently CeTA-certified. | certified, 2x | evidence staged for adaptive Transformed-CSR r03 | focused run certified in 6.898 s; default certified in 45.881 s | open: the exact action timed out twice at the current shared release state, including once in isolation, so it was not promoted into v55 | recover current replay fidelity before promotion; CeTA changes: none |
| `TRS_Contextsensitive/Maude_06/LISTUTILITIES_nosorts.ari` | producing proof: `target/csr-mixed-batch-LISTUTILITIES_nosorts.cpf4.xml`; strict replay: `target/data-campaign/state-first-adaptive-20260729-132133/manual-evidence-recursive-20260730/v57-window4-mixed-csr-strict/list/proof.cpf.xml` | Improved CS-DPs with mixed active/frozen size-change graphs: strict descent originates at an active position while equality is preserved through frozen arguments. Root action `dp(graph;size-change)` and all certifiable QCS descendants are independently indexed. | certified, 2x | adaptive Transformed-CSR r03 oracle v57 | producing Ferrum result YES | passed, strict oracle-only in 3 ms with fallback disabled; reconstructed CPF certified 2x | CeTA-CSR mixed active/frozen theorem and generated checker integrated in commit `84ee1e0` |
| `TRS_Contextsensitive/Maude_06/LISTUTILITIES_nosorts-noand.ari` | producing proof: `target/csr-mixed-batch-LISTUTILITIES_nosorts-noand.cpf4.xml`; strict replay: `target/data-campaign/state-first-adaptive-20260729-132133/manual-evidence-recursive-20260730/v57-window4-mixed-csr-strict/list-noand/proof.cpf.xml` | Same formally checked mixed active/frozen CSR size-change route; root and certifiable descendants are independently indexed. | certified, 2x | adaptive Transformed-CSR r03 oracle v57 | producing Ferrum result YES | passed, strict oracle-only in 10 ms with fallback disabled; reconstructed CPF certified 2x | CeTA-CSR mixed active/frozen theorem and generated checker integrated in commit `84ee1e0` |
| `TRS_Contextsensitive/Maude_06/LengthOfFiniteLists_complete-noand.ari` | original proof: `target/data-campaign/state-first-adaptive-20260729-132133/staged-window4-csr-rule-removal-20260730/TRS_Contextsensitive/Maude_06/LengthOfFiniteLists_complete-noand/proof.cpf.xml`; mixed-size-change proof: `target/csr-mixed-batch-LengthOfFiniteLists_complete-noand.cpf4.xml` | Deadline-aware exhaustive CSR polynomial/matrix rule removal remains the current strict route. The updated checker also certifies an alternative mixed active/frozen size-change proof. | certified, 2x | adaptive Transformed-CSR r03 oracle v57 | current default and alternative proof certify | open after one strict-guided transformation; 25 isolated rule-removal fragments are not self-contained and remain quarantined | continue recursive residual aliases; CeTA-CSR mixed active/frozen theorem integrated |
| `TRS_Contextsensitive/Maude_06/LengthOfFiniteLists_nokinds-noand.ari` | original proof: `target/data-campaign/state-first-adaptive-20260729-132133/staged-window4-csr-rule-removal-20260730/TRS_Contextsensitive/Maude_06/LengthOfFiniteLists_nokinds-noand/proof.cpf.xml`; mixed-size-change proof: `target/csr-mixed-batch-LengthOfFiniteLists_nokinds-noand.cpf4.xml`; strict replay: `target/data-campaign/state-first-adaptive-20260729-132133/manual-evidence-recursive-20260730/v57-window4-mixed-csr-strict/length-nokinds/proof.cpf.xml` | Exhaustive rule-removal ladder remains replayable, and the updated checker independently certifies the alternative mixed active/frozen size-change proof. | certified, 2x | adaptive Transformed-CSR r03 oracle v57 | current default and alternative proof certify | passed, strict oracle-only; reconstructed CPF certified 2x | CeTA-CSR mixed active/frozen theorem integrated |
| `TRS_Contextsensitive/Maude_06/OvConsOS_complete-noand.ari` | `target/data-campaign/state-first-adaptive-20260729-132133/staged-window4-csr-rule-removal-20260730/TRS_Contextsensitive/Maude_06/OvConsOS_complete-noand/proof.cpf.xml` | Exhaustive CSR polynomial/matrix rule removal; six strictly shrinking steps. | certified, 2x | adaptive Transformed-CSR r03 oracle v49 | explicit compound strategy certified in 31.019 s | open after one strict-guided transformation; the newly exposed residual is independently certified and retained | continue recursive residual aliases; CeTA changes: none |
| `TRS_Contextsensitive/Maude_06/OvConsOS_nokinds-noand.ari` | `target/data-campaign/state-first-adaptive-20260729-132133/staged-window4-csr-rule-removal-20260730/TRS_Contextsensitive/Maude_06/OvConsOS_nokinds-noand/proof.cpf.xml` | Same exhaustive CSR rule-removal ladder, with five strictly shrinking steps. | certified, 2x | adaptive Transformed-CSR r03 oracle v49 | explicit compound strategy certified in 0.908 s | passed, strict oracle-only; reconstructed CPF certified | pending release rerun; CeTA changes: none |
| `TRS_Innermost/Transformed_CSR_innermost_04/Ex5_DLMMU04_GM.ari` | `target/data-campaign/state-first-adaptive-20260729-132133/staged-windows3-4-followup-20260730/ex5-dlmmu04-gm/proof.cpf.xml` | Direct active-to-mark transformed-CSR recognition, rule removal, then innermost DP residual closure. | certified, 2x | staged for next monotone oracle export | current default about 7.6 s | pending strict oracle-only replay and independent child indexing | CeTA changes: none |
| `TRS_Innermost/Transformed_CSR_innermost_04/Ex5_DLMMU04_iGM.ari` | `target/data-campaign/state-first-adaptive-20260729-132133/staged-windows3-4-followup-20260730/ex5-dlmmu04-igm/proof.cpf.xml` | Direct active-to-mark recognition and the retained exact certified processor chain. | certified, 2x | staged for next monotone oracle export | retained producer about 14.9 s; current search exceeds 60 s | pending strict oracle-only replay; proof is replayable and current slowdown is tracked separately | CeTA changes: none |
| `TRS_Innermost/Transformed_CSR_innermost_04/Ex5_Zan97_iGM.ari` | `target/data-campaign/state-first-adaptive-20260729-132133/staged-windows3-4-followup-20260730/ex5-zan97-igm/proof.cpf.xml` | Corrected direct transformed-CSR dispatch followed by the certified innermost DP route. | certified, 2x | staged for next monotone oracle export | current default 1.2 s | pending strict oracle-only replay and independent child indexing | CeTA changes: none |
| `TRS_Innermost/Transformed_CSR_innermost_04/Ex6_Luc98_C.ari` | `target/data-campaign/state-first-adaptive-20260729-132133/staged-windows3-4-followup-20260730/ex6-luc98-c/proof.cpf.xml` | Corrected direct transformed-CSR dispatch and certified residual DP closure. | certified, 2x | staged for next monotone oracle export | current default 3.2 s | pending strict oracle-only replay and independent child indexing | CeTA changes: none |
| `TRS_Innermost/Transformed_CSR_innermost_04/Ex6_Luc98_iGM.ari` | `target/data-campaign/state-first-adaptive-20260729-132133/staged-windows3-4-followup-20260730/ex6-luc98-igm/proof.cpf.xml` | Corrected direct transformed-CSR dispatch and certified residual DP closure. | certified, 2x | staged for next monotone oracle export | current default 0.6 s | pending strict oracle-only replay and independent child indexing | CeTA changes: none |
| `TRS_Innermost/Transformed_CSR_innermost_04/Ex9_BLR02_C.ari` | `target/data-campaign/state-first-adaptive-20260729-132133/staged-windows3-4-followup-20260730/ex9-blr02-c/proof.cpf.xml` | Corrected transformed-CSR dispatch followed by the certified innermost processor chain. | certified, 2x | staged for next monotone oracle export | current default 37.4 s | pending strict oracle-only replay and independent child indexing | CeTA changes: none |
| `TRS_Innermost/Transformed_CSR_innermost_04/Ex9_Luc04_GM.ari` | `target/data-campaign/state-first-adaptive-20260729-132133/staged-windows3-4-followup-20260730/ex9-luc04-gm/proof.cpf.xml` | Corrected transformed-CSR dispatch followed by the certified innermost processor chain. | certified, 2x | staged for next monotone oracle export | current default 10.0 s | pending strict oracle-only replay and independent child indexing | CeTA changes: none |
| `TRS_Contextsensitive/CSR_04/Ex4_DLMMU04.ari` | `target/data-campaign/state-first-adaptive-20260729-132133/staged-windows3-4-followup-20260730/ex4-dlmmu04/proof.cpf.xml` | Complete CSR polynomial/matrix rule-removal ladder ending in the empty system. | certified, 2x | staged for next monotone oracle export | current default 0.989 s | pending strict oracle-only replay and independent residual indexing | CeTA changes: none |
| `TRS_Contextsensitive/Transformed_outermost_08/morse.ari` | `target/data-campaign/state-first-adaptive-20260729-132133/staged-windows3-4-followup-20260730/morse/proof.cpf.xml` | CSR polynomial rule removal followed by three matrix rule-removal stages, ending in the empty system. | certified, 2x | staged for next monotone oracle export | current default 4.49 s | pending strict oracle-only replay and independent residual indexing | CeTA changes: none |
| `TRS_Standard/Zantema_05/z21.ari` | `target/data-campaign/state-first-adaptive-20260729-132133/staged-window1-z21-z27-20260730/z21/proof.cpf.xml` | Deterministic lexicographic polynomial objectives and the resulting certified DP residual closure. | certified, 2x | staged for next monotone oracle export | current default 0.37 s | pending strict oracle-only replay and independent child indexing | CeTA changes: none |
| `TRS_Standard/Zantema_05/z27.ari` | `target/data-campaign/state-first-adaptive-20260729-132133/staged-window1-z21-z27-20260730/z27/proof.cpf.xml` | Residual-aware semantic labeling, including the required ternary/unary model, followed by certified residual closure. | certified, 2x | staged for next monotone oracle export | current default 1.12 s | pending strict oracle-only replay and independent child indexing | CeTA changes: none |
| `TRS_Contextsensitive/CSR_04/Ex15_Luc98.ari` | `target/csr-next6/Ex15_Luc98.cpf4.xml` | Context-sensitive polynomial rule removal. | certified, 2x | frozen with the window-4 `csr-next6` batch for the next monotone export | current default 0.157 s | pending strict oracle-only replay | CeTA changes: none |
| `TRS_Contextsensitive/CSR_04/Ex1_2_Luc02c.ari` | `target/csr-next6/Ex1_2_Luc02c.cpf4.xml` | Improved CS-DPs, refined dependency graphs, and active size-change closure. | certified, 2x | frozen with the window-4 `csr-next6` batch for the next monotone export | current default 0.079 s | pending strict oracle-only replay and independent child indexing | CeTA changes: none |
| `TRS_Contextsensitive/CSR_04/Ex5_DLMMU04.ari` | `target/csr-next6/Ex5_DLMMU04.cpf4.xml` | Improved CS-DPs, refined dependency graphs, and active size-change closure. | certified, 2x | frozen with the window-4 `csr-next6` batch for the next monotone export | current default 0.120 s | pending strict oracle-only replay and independent child indexing | CeTA changes: none |
| `TRS_Contextsensitive/CSR_04/Ex6_9_Luc02c.ari` | `target/csr-next6/Ex6_9_Luc02c.cpf4.xml` | Improved CS-DPs, refined dependency graphs, and active size-change closure. | certified, 2x | frozen with the window-4 `csr-next6` batch for the next monotone export | current default 1.09 s | pending strict oracle-only replay and independent child indexing | CeTA changes: none |
| `TRS_Innermost/Transformed_CSR_innermost_04/ExIntrod_GM01_C.ari` | `target/next-exintrod/ExIntrod_GM01_C.cpf` | Current transformed-CSR innermost DP path and certified residual closure. | certified, 2x | frozen with the latest window-3/4 batch | current default certified | pending strict oracle-only replay and independent child indexing | CeTA changes: none |
| `TRS_Innermost/Transformed_CSR_innermost_04/ExIntrod_GM01_GM.ari` | `target/next-exintrod/ExIntrod_GM01_GM.cpf` | Current transformed-CSR innermost DP path and certified residual closure. | certified, 2x | frozen with the latest window-3/4 batch | current default certified | pending strict oracle-only replay and independent child indexing | CeTA changes: none |
| `TRS_Innermost/Transformed_CSR_innermost_04/ExIntrod_GM01_iGM.ari` | `target/next-exintrod/ExIntrod_GM01_iGM.cpf` | Current transformed-CSR innermost DP path and certified residual closure. | certified, 2x | frozen with the latest window-3/4 batch | current default certified | pending strict oracle-only replay and independent child indexing | CeTA changes: none |
| `TRS_Innermost/Transformed_CSR_innermost_04/ExIntrod_GM04_C.ari` | `target/next-exintrod/ExIntrod_GM04_C.cpf` | Current transformed-CSR innermost DP path and certified residual closure. | certified, 2x | frozen with the latest window-3/4 batch | current default certified | pending strict oracle-only replay and independent child indexing | CeTA changes: none |
| `TRS_Innermost/Transformed_CSR_innermost_04/ExProp7_Luc06_iGM.ari` | `target/next-exprop-sec11/ExProp7_Luc06_iGM.cpf` | Certified transformed-CSR DP/reduction-pair residual chain. | certified, 2x | frozen with the latest window-3/4 batch | current default certified | pending strict oracle-only replay and independent child indexing | CeTA changes: none |
| `TRS_Innermost/Transformed_CSR_innermost_04/LengthOfFiniteLists_complete_GM.ari` | `target/next-length-lists/LengthOfFiniteLists_complete_GM.cpf` | Certified transformed-CSR polynomial/DP residual chain. | certified, 2x | frozen with the latest window-3/4 batch | current default certified | pending strict oracle-only replay and independent child indexing | CeTA changes: none |
| `TRS_Innermost/Transformed_CSR_innermost_04/OvConsOS_nokinds_noand_GM.ari` | `target/next-ovcons/OvConsOS_nokinds_noand_GM.cpf` | Certified transformed-CSR polynomial/usable-rule residual chain. | certified, 2x | frozen with the latest window-3/4 batch | current default 33 s | pending strict oracle-only replay and independent child indexing | CeTA changes: none |
| `TRS_Innermost/Transformed_CSR_innermost_04/PEANO_complete_noand_GM.ari` | `target/next-peano/PEANO_complete_noand_GM.cpf` | Certified transformed-CSR dependency-pair and polynomial/usable-rule decomposition. | certified, 2x | frozen with the latest window-3/4 batch | current default 93 s; replayability counts independently of efficiency | pending strict oracle-only replay and independent child indexing | CeTA changes: none |
| `TRS_Innermost/Transformed_CSR_innermost_04/PEANO_nokinds_noand_iGM.ari` | `target/next-peano/PEANO_nokinds_noand_iGM.cpf` | Certified transformed-CSR dependency-pair and polynomial/usable-rule decomposition. | certified, 2x | frozen with the latest window-3/4 batch | current default 12 s | pending strict oracle-only replay and independent child indexing | CeTA changes: none |
| `TRS_Contextsensitive/Transformed_outermost_08/cariboo_ex2.ari` | `target/csr-next7/Transformed_outermost_08_cariboo_ex2.cpf4.xml` | CSR rule removal followed by ordinary improved CS-DP graph/size-change closure. | certified, 2x | frozen with the latest window-3/4 batch | current default 0.300 s | pending strict oracle-only replay and independent child indexing | CeTA changes: none |
| `TRS_Contextsensitive/Transformed_outermost_08/cariboo_ex6.ari` | `target/csr-next7/Transformed_outermost_08_cariboo_ex6.cpf4.xml` | CSR rule removal followed by ordinary improved CS-DP graph/size-change closure. | certified, 2x | frozen with the latest window-3/4 batch | current default 0.134 s | pending strict oracle-only replay and independent child indexing | CeTA changes: none |
| `TRS_Contextsensitive/Transformed_outermost_08/ex5.4.ari` | `target/csr-next7/Transformed_outermost_08_ex5.4.cpf4.xml` | CSR rule removal followed by ordinary improved CS-DP graph/size-change closure. | certified, 2x | frozen with the latest window-3/4 batch | current default 0.833 s | pending strict oracle-only replay and independent child indexing | CeTA changes: none |
| `TRS_Contextsensitive/Transformed_outermost_08/ex5.6.ari` | `target/csr-next7/Transformed_outermost_08_ex5.6.cpf4.xml` | CSR rule removal followed by ordinary improved CS-DP graph/size-change closure. | certified, 2x | frozen with the latest window-3/4 batch | current default 0.124 s | pending strict oracle-only replay and independent child indexing | CeTA changes: none |
| `TRS_Standard/Zantema_05/z03.ari` | `target/termcomp-runs/20260730-decomp-semlab-regression-6x60s/TRS_Standard/Zantema_05/z03/proof.cpf.xml` | FULL online match-bounds construction with inverse contexts and height-sensitive epsilon cancellation; bound 2. | certified, 2x | global adaptive oracle v80 | current default certified | pending strict oracle-only replay | CeTA changes: none |
| `TRS_Standard/Zantema_05/z30.ari` | `target/termcomp-runs/20260730-decomp-semlab-regression-6x60s/TRS_Standard/Zantema_05/z30/proof.cpf.xml` | Same FULL match-bounds construction; bound 3. | certified, 2x | global adaptive oracle v80 | current default certified in 5.244 s under six-way load | pending strict oracle-only replay | CeTA changes: none |
| `TRS_Innermost/raML/queue.raml.ari` | `target/integration-windows1-3-4-20260730/queue_raml.cpf.xml` | Current innermost default proof and all emitted nested processor states. | certified, 2x | global adaptive oracle v80 | current default certified in about 4 s | pending strict oracle-only replay and independent child audit | CeTA changes: none |
| `TRS_Innermost/Transformed_CSR_innermost_04/Ex15_Luc98_iGM.ari` | `target/next-transformed-earlier/Ex15_Luc98_iGM.cpf` | Current transformed-CSR innermost DP proof and certified residual chain. | certified, 2x | global adaptive oracle v80 | current default certified | pending strict oracle-only replay and independent child audit | CeTA changes: none |
| `TRS_Innermost/Transformed_CSR_innermost_04/Ex16_Luc06_iGM.ari` | `target/next-transformed-earlier/Ex16_Luc06_iGM.cpf` | Current transformed-CSR innermost DP proof and certified residual chain. | certified, 2x | global adaptive oracle v80 | current default certified | pending strict oracle-only replay and independent child audit | CeTA changes: none |
| `TRS_Innermost/Transformed_CSR_innermost_04/Ex26_Luc03b_C.ari` | `target/next-transformed-earlier/Ex26_Luc03b_C.cpf` | Current transformed-CSR innermost DP proof and certified residual chain. | certified, 2x | global adaptive oracle v80 | current default certified | pending strict oracle-only replay and independent child audit | CeTA changes: none |
| `TRS_Innermost/Transformed_CSR_innermost_04/Ex26_Luc03b_iGM.ari` | `target/next-transformed-earlier/Ex26_Luc03b_iGM.cpf` | Current transformed-CSR innermost DP proof and certified residual chain. | certified, 2x | global adaptive oracle v80 | current default certified | pending strict oracle-only replay and independent child audit | CeTA changes: none |
| `TRS_Innermost/Transformed_CSR_innermost_04/Ex1_2_Luc02c_iGM.ari` | `target/next-transformed-matrix/Ex1_2_Luc02c_iGM.cpf` | Current transformed-CSR innermost matrix/DP proof and certified residual chain. | certified, 2x | global adaptive oracle v80 | current default certified in about 1 s | pending strict oracle-only replay and independent child audit | CeTA changes: none |
| `TRS_Innermost/Transformed_CSR_innermost_04/Ex1_GL02a_C.ari` | `target/next-transformed-matrix/Ex1_GL02a_C.cpf` | Current transformed-CSR innermost matrix/DP proof and certified residual chain. | certified, 2x | global adaptive oracle v80 | current default certified in about 14 s | pending strict oracle-only replay and independent child audit | CeTA changes: none |
| `TRS_Standard/Der95/30.ari` | `target/integration-window1-der30-thiemann40-20260730/der95_30.cpf.xml` | Direct top-level recursive path order, scheduled before the solver-heavy transformation race. The retained root proof is terminal. | certified, 2x | global adaptive oracle v84 | current default certified in 0.164 s | pending strict oracle-only replay | CeTA changes: none |
| `TRS_Standard/AProVE_07/thiemann40.ari` | `target/integration-window1-der30-thiemann40-20260730/thiemann40.cpf.xml` | Standard DP transformation; coefficient-induced usable-rule closure jointly synthesized with a denominator-4 rational polynomial interpretation; final graph closure. The terminal child states are independently retained while the two transformations remain typed weak guidance pending full reconstruction. | certified, 2x | global adaptive oracle v84 | current default certified in 5.569 s | pending strict oracle-only replay and complete chain reconstruction | CeTA changes: none |
| `TRS_Innermost/Transformed_CSR_innermost_04/LengthOfFiniteLists_complete_noand_GM.ari` | producing proof: `target/next-progressive-race-default/LengthOfFiniteLists_complete_noand_GM.cpf`; frozen states: `target/integration-window3-length-complete-noand-gm-20260730` | Progressive DP chain with three bounded polynomial reductions, graph recomputation, size change, and subterm attempts. Four terminal nested states certify independently and two transformations are retained as typed assembly obligations. | certified, 2x | global adaptive oracle v89; round-7 frontier in v90 | current default certified in 65 s | exact oracle-only root chain reached the 60 s boundary at 60.997 s; retained as replayable with an efficiency gap, not counted as a strict 60 s closure | CeTA changes: none |
| `TRS_Innermost/Transformed_CSR_innermost_04/Ex9_BLR02_iGM.ari` | producing proof: `target/next-medium-progressive/Ex9_BLR02_iGM.cpf`; frozen states and strict replay: `target/integration-window3-ex9-blr02-igm-20260730` | Progressive DP chain with graph decomposition, repeated polynomial and matrix reductions, forward instantiation, narrowing, subterm, and usable/LHSS processing. Fifteen terminal states certify independently and thirty-nine typed transformations are retained. | certified, 2x | global adaptive oracle v92 | current default certified in 51 s | passed strict oracle-only in 45.5 s with fallback disabled; reconstructed CPF certified 2x | CeTA changes: none |
| `TRS_Innermost/Transformed_CSR_innermost_04/Ex2_Luc03b_iGM.ari` | producing evidence: `target/next-small-kbo-current/Ex2_Luc03b_iGM.jsonl`; frozen states, v95, and strict replay: `target/integration-window3-small-kbo-20260731` | Certified innermost DP/KBO path recovered from the live processor trace. Its terminal and typed child states are retained independently. | certified, 2x | global adaptive oracle v95 | producing default certified in about 2 s | passed strict oracle-only in 3.165 s with fallback disabled; reconstructed CPF certified 2x | CeTA changes: none |
| `TRS_Innermost/Transformed_CSR_innermost_04/Ex3_3_25_Bor03_iGM.ari` | producing evidence: `target/next-small-kbo-current/Ex3_3_25_Bor03_iGM.jsonl`; frozen states, v95, and strict replay: `target/integration-window3-small-kbo-20260731` | Certified innermost DP/KBO path recovered from the live processor trace. Its terminal and typed child states are retained independently. | certified, 2x | global adaptive oracle v95 | producing default certified in about 4 s | passed strict oracle-only in 4.145 s with fallback disabled; reconstructed CPF certified 2x | CeTA changes: none |
| `TRS_Standard/Transformed_CSR_04/Ex4_7_15_Bor03_C.ari` | producing proof: `target/termcomp-runs/20260731-transformed-csr-default-certified-final-2x60s/TRS_Standard/Transformed_CSR_04/Ex4_7_15_Bor03_C/proof.cpf.xml`; frozen states and strict replay: `target/integration-window1-repeated-usable-rules-20260731` | Repeated usable-rule restriction in the active DP rule component, followed by certified matrix deletion, graph decomposition, and size-change residual closures. | certified, 2x | global adaptive oracle v96 and later | producing default certified in under 1 s | passed strict oracle-only under v96 with fallback disabled; reconstructed CPF certified 2x | CeTA changes: none |
| `TRS_Standard/Transformed_CSR_04/ExProp7_Luc06_C.ari` | producing proof: `target/termcomp-runs/20260731-transformed-csr-default-certified-final-2x60s/TRS_Standard/Transformed_CSR_04/ExProp7_Luc06_C/proof.cpf.xml`; frozen states and strict replay: `target/integration-window1-repeated-usable-rules-20260731` | Repeated usable-rule restriction in the active DP rule component, followed by certified matrix deletion, graph decomposition, and size-change residual closures. | certified, 2x | global adaptive oracle v96 and later | producing default certified in under 1 s | passed strict oracle-only under v96 with fallback disabled; reconstructed CPF certified 2x | CeTA changes: none |
| `TRS_Innermost/Transformed_CSR_innermost_04/Ex6_9_Luc02c_GM.ari` | producing proof and live evidence: `target/next-matrix-current/Ex6_9_Luc02c_GM.cpf`, `target/next-matrix-current/Ex6_9_Luc02c_GM.jsonl`; frozen states and strict replay: `target/integration-window3-ex6-9-luc02c-gm-20260731` | Innermost transformed-CSR matrix/DP chain. Eleven terminal states certify independently and fifty-seven typed transformations are retained for recursive assembly. | certified, 2x | global adaptive oracle v97 | producing default certified in 6 s | passed strict oracle-only under v97 with fallback disabled; reconstructed CPF certified 2x | CeTA changes: none |
| `TRS_Innermost/Mixed_innermost/wiehe13.ari` | producing proof and live evidence: `target/next-wiehe-focused/wiehe13.cpf`, `target/next-wiehe-focused/wiehe13.jsonl`; frozen states and strict replay: `target/integration-window3-wiehe13-20260731` | Graph decomposition, two filtered KBO reductions, matrix and polynomial reduction, and size-change closure. Twenty-one terminal states certify independently and eleven typed transformations are retained; fifteen positive-looking live attempts fail exact isolated replay and remain unpromoted. | certified, 2x | global adaptive oracle v98 | focused producing run certified in 40 s; the same search is nondeterministic in the default parallel portfolio | passed strict oracle-only under v98 in 22 s with fallback disabled; reconstructed CPF certified 2x | CeTA changes: none |
| `TRS_Innermost/Mixed_innermost/thiemann26i.ari` | current default proof: `target/next-examples-20260731/thiemann26i-default/proof.cpf.xml`; focused proof and events: `target/next-examples-20260731/thiemann26i-final`; strict replay: `target/manual-evidence-replay-v147-20260731/strict-v157-full-manual180/TRS_Innermost/Mixed_innermost/thiemann26i` | Q-admissible innermost DP narrowing, rewriting, graph decomposition, polynomial-assisted size change, and singleton SCT closure. | certified, replay CPF rechecked 2x | oracle v157 and later | 2.9 s producing; 4.788 s strict replay | passed strict oracle-only with fallback disabled; reconstructed CPF certified | CeTA changes: none |
| `TRS_Innermost/Mixed_innermost/thiemann28i.ari` | current default proof: `target/next-examples-20260731/thiemann28i-default/proof.cpf.xml`; focused proof and events: `target/next-examples-20260731/thiemann28i-final`; strict replay: `target/manual-evidence-replay-v147-20260731/strict-v157-full-manual180/TRS_Innermost/Mixed_innermost/thiemann28i` | Q-admissible innermost DP narrowing and rewriting followed by graph and size-change closure. | certified, replay CPF rechecked 2x | oracle v157 and later | 2.5 s producing; 3.969 s strict replay | passed strict oracle-only with fallback disabled; reconstructed CPF certified | CeTA changes: none |
| `TRS_Innermost/Mixed_innermost/muladd.ari` | producing proof: `target/next-examples-20260731/certified-no-next/muladd/proof.cpf.xml`; exact frozen event and strict replay: `target/manual-evidence-replay-v147-20260731/window3-muladd-n001-v158-expanded`, `target/manual-evidence-replay-v147-20260731/strict-v159b-window3-muladd-n001` | Direct innermost rewrite loop; the retained root action is the complete effective nontermination portfolio rather than the old ambiguous `nontermination(loop)` fragment. | certified NO, 2x on producing/frozen/replay proof | oracle v158 | 1.20 s producing run; about 2 s loaded strict pair replay | passed strict oracle-only with fallback `fail`; reconstructed CPF certified 2x | CeTA changes: none |
| `TRS_Innermost/Mixed_innermost/n001.ari` | producing proof: `target/next-examples-20260731/certified-no-next/n001/proof.cpf.xml`; exact frozen event and strict replay: `target/manual-evidence-replay-v147-20260731/window3-muladd-n001-v158-expanded`, `target/manual-evidence-replay-v147-20260731/strict-v159b-window3-muladd-n001` | Direct innermost rewrite loop; the retained root action is the complete effective nontermination portfolio rather than the old ambiguous `nontermination(loop)` fragment. | certified NO, 2x on producing/frozen/replay proof | oracle v158 | under 0.01 s producing run | passed strict oracle-only with fallback `fail`; reconstructed CPF certified 2x | CeTA changes: none |
| `TRS_Standard/CiME_04/log2.ari` | producing proof and events: `target/manual-evidence-replay-v147-20260731/pending-standard-trio-current-v159b/TRS_Standard/CiME_04/log2`; frozen states and strict replay: `target/manual-evidence-replay-v147-20260731/pending-standard-trio-current-v159b`, `target/manual-evidence-replay-v147-20260731/strict-v159-standard-trio` | Dependency-pair decomposition with checked usable-rule polynomial reductions and residual graph closure. Terminal residuals are independently indexed. | certified, 2x on frozen and replay proof | oracle v159 | 0.964 s producing; 1.965 s strict replay | passed strict oracle-only with fallback `fail`; reconstructed CPF certified 2x | CeTA changes: none |
| `TRS_Standard/Transformed_CSR_04/Ex1_GL02a_C.ari` | `target/manual-probes/20260731-next-transformed-cluster-default-65s/TRS_Standard/Transformed_CSR_04/Ex1_GL02a_C/proof.cpf.xml` | Current complete DP recipe plus independently indexed graph/order residuals. | certified, 2x | oracle v254 | current default certified | passed strict oracle-only under v254; replay CPF certified 2x | CeTA changes: none |
| `TRS_Standard/Transformed_CSR_04/Ex1_GL02a_iGM.ari` | `target/manual-probes/20260731-next-transformed-cluster-default-65s/TRS_Standard/Transformed_CSR_04/Ex1_GL02a_iGM/proof.cpf.xml` | Current complete DP recipe plus independently indexed graph/order residuals. | certified, 2x | oracle v254 | current default certified | passed strict oracle-only under v254; replay CPF certified 2x | CeTA changes: none |
| `TRS_Standard/Transformed_CSR_04/Ex5_DLMMU04_C.ari` | `target/manual-probes/20260731-next-poly-cluster-default-65s/TRS_Standard/Transformed_CSR_04/Ex5_DLMMU04_C/proof.cpf.xml` | Direct polynomial removal followed by its typed DP continuation and residual closures. | certified, 2x | oracle v254 | current default certified | retained; strict replay still needs the composed root sequence rather than its separate certified atoms | CeTA changes: none |
| `TRS_Standard/Transformed_CSR_04/Ex5_DLMMU04_iGM.ari` | `target/manual-probes/20260731-final-ex5-default-cert/TRS_Standard/Transformed_CSR_04/Ex5_DLMMU04_iGM/proof.cpf.xml` | Direct polynomial removal followed by its typed DP continuation and residual closures. | certified, 2x | oracle v254 | 2.2 s current default | retained; explicit composed replay certifies, while strict oracle composition remains pending | CeTA changes: none |
| `TRS_Standard/AProVE_04/Liveness6.4.ari` | producing proof and events: `target/manual-evidence-replay-v147-20260731/pending-standard-trio-current-v159b/TRS_Standard/AProVE_04/Liveness6.4`; frozen states and strict replay: `target/manual-evidence-replay-v147-20260731/pending-standard-trio-current-v159b`, `target/manual-evidence-replay-v147-20260731/strict-v159-standard-trio` | Exact DP graph/polynomial/semantic-labeling continuation, with all complete residual closures independently indexed. | certified, 2x on frozen and replay proof | oracle v159 | 49.577 s producing; 1.683 s strict replay | passed strict oracle-only with fallback `fail`; reconstructed CPF certified 2x | CeTA changes: none |
| `TRS_Standard/Various_04/14.ari` | producing proof and events: `target/manual-evidence-replay-v147-20260731/pending-standard-trio-current-v159b/TRS_Standard/Various_04/14`; frozen states and strict replay: `target/manual-evidence-replay-v147-20260731/pending-standard-trio-current-v159b`, `target/manual-evidence-replay-v147-20260731/strict-v159-standard-trio` | Exact graph-first DP portfolio with independently indexed polynomial, matrix, KBO, size-change, and subterm residual states. | certified, 2x on frozen and replay proof | oracle v159 | 1.404 s producing; 1.689 s strict replay | passed strict oracle-only with fallback `fail`; reconstructed CPF certified 2x | CeTA changes: none |
| `TRS_Standard/Beerendonk_07/7.ari` | producing proof: `target/termcomp-runs/20260730-beerendonk7-default-final-1x60s/TRS_Standard/Beerendonk_07/7/proof.cpf.xml`; recovered states: `target/integration-window1-beerendonk7-ex6-exprop-20260731` | Switch to innermost followed by the certified DP/order chain. Exact CPF decomposition retains its terminal and transformation states. | certified, 2x | global adaptive oracle v93 and later | producing default certified in 2.8 s | current default and strict v93 replay fail; retained with an explicit scheduling/replay-fidelity gap | CeTA changes: none |
| `TRS_Standard/Transformed_CSR_04/Ex6_9_Luc02c_iGM.ari` | producing proof: `target/termcomp-runs/20260730-transformed-csr-narrowing-certified-2x60s/TRS_Standard/Transformed_CSR_04/Ex6_9_Luc02c_iGM/proof.cpf.xml`; recovered states: `target/integration-window1-beerendonk7-ex6-exprop-20260731` | Full DP chain with graph, arctic matrix, narrowing, polynomial, size-change, and residual closures recovered directly from the certified CPF. | certified, 2x | global adaptive oracle v93 and later | producing default certified | current default and strict v93 replay reach the 60 s boundary; retained with an efficiency/reconstruction gap | CeTA changes: none |
| `TRS_Standard/Transformed_CSR_04/ExProp7_Luc06_iGM.ari` | producing proof: `target/termcomp-runs/20260730-transformed-csr-narrowing-certified-2x60s/TRS_Standard/Transformed_CSR_04/ExProp7_Luc06_iGM/proof.cpf.xml`; strict replay: `target/integration-window1-beerendonk7-ex6-exprop-20260731/strict-v93` | Full DP narrowing with exact CeTA icap checks, graph recomputation, polynomial/matrix reductions, and terminal residual closure. | certified, 2x | global adaptive oracle v93 and later | producing default certified | passed strict oracle-only in 3.9 s with fallback disabled | CeTA changes: none |
| `TRS_Standard/AProVE_08/round_nonterm.ari` | producing proof: `target/termcomp-runs/20260731-next-small-ground-dp-loop-final-12x60s/TRS_Standard/AProVE_08/round_nonterm/proof.cpf.xml`; strict replay: `target/integration-windows1-3-20260731/strict-v102-standard/TRS_Standard/AProVE_08/round_nonterm/proof.cpf.xml` | Ground-instantiated DP loop with relative base-rule rewriting. The executable local root recommendation is `nontermination(dp-loop)`, not terminating `dp`. | certified NO, 2x | global adaptive oracle v102 and later | current default certified | passed strict oracle-only under 60 s; replay CPF certified 2x | CeTA changes: none |
| `TRS_Standard/Strategy_removed_CSR_05/Ex1_GM99.ari` | producing proof under `target/termcomp-runs/20260731-next-small-ground-dp-loop-final-12x60s`; strict replay under `target/integration-windows1-3-20260731/strict-v102-standard` | Ground-instantiated DP loop with relative base-rule rewriting, independently regenerated by `nontermination(dp-loop)`. | certified NO, 2x | global adaptive oracle v102 and later | current default certified | passed strict oracle-only under 60 s; replay CPF certified 2x | CeTA changes: none |
| `TRS_Standard/Strategy_removed_CSR_05/Ex24_GM04.ari` | producing proof under `target/termcomp-runs/20260731-next-small-ground-dp-loop-final-12x60s`; strict replay under `target/integration-windows1-3-20260731/strict-v102-standard` | Ground-instantiated DP loop with relative base-rule rewriting, independently regenerated by `nontermination(dp-loop)`. | certified NO, 2x | global adaptive oracle v102 and later | current default certified | passed strict oracle-only under 60 s; replay CPF certified 2x | CeTA changes: none |
| `TRS_Standard/Strategy_removed_mixed_05/toyama.ari` | producing proof under `target/termcomp-runs/20260731-next-small-ground-dp-loop-final-12x60s`; strict replay under `target/integration-windows1-3-20260731/strict-v102-standard` | Ground-instantiated DP loop with relative base-rule rewriting, independently regenerated by `nontermination(dp-loop)`. | certified NO, 2x | global adaptive oracle v102 and later | current default certified | passed strict oracle-only under 60 s; replay CPF certified 2x | CeTA changes: none |
| `TRS_Standard/Transformed_CSR_04/Ex9_Luc04_FR.ari` | producing proof under `target/termcomp-runs/20260731-next-small-ground-dp-loop-final-12x60s`; strict replay under `target/integration-windows1-3-20260731/strict-v102-standard` | Ground-instantiated DP loop with relative base-rule rewriting, independently regenerated by `nontermination(dp-loop)`. | certified NO, 2x | global adaptive oracle v102 and later | current default certified | passed strict oracle-only under 60 s; replay CPF certified 2x | CeTA changes: none |
| `TRS_Standard/Transformed_CSR_04/Ex24_Luc06_FR.ari` | producing proof under `target/termcomp-runs/20260731-next-small-ground-dp-loop-final-12x60s`; strict replay under `target/integration-windows1-3-20260731/strict-v102-standard` | Ground-instantiated DP loop with relative base-rule rewriting, independently regenerated by `nontermination(dp-loop)`. | certified NO, 2x | global adaptive oracle v102 and later | current default certified | passed strict oracle-only under 60 s; replay CPF certified 2x | CeTA changes: none |
| `TRS_Standard/Transformed_CSR_04/Ex24_Luc06_GM.ari` | producing proof under `target/termcomp-runs/20260731-next-small-ground-dp-loop-final-12x60s`; strict replay under `target/integration-windows1-3-20260731/strict-v102-standard` | Ground-instantiated DP loop with relative base-rule rewriting, independently regenerated by `nontermination(dp-loop)`. | certified NO, 2x | global adaptive oracle v102 and later | current default certified | passed strict oracle-only under 60 s; replay CPF certified 2x | CeTA changes: none |
| `TRS_Standard/Waldmann_06/jwteparla2.ari` | producing proof: `target/termcomp-runs/20260731-jwteparla2-qiedg-fix-1x60s/TRS_Standard/Waldmann_06/jwteparla2/proof.cpf.xml`; strict replay: `target/integration-windows1-3-20260731/strict-v102-standard/TRS_Standard/Waldmann_06/jwteparla2/proof.cpf.xml` | Uncurrying/switch-innermost, DPs, conservative Q-aware graph decomposition, narrowing, instantiation, and reduction-pair residual closures. Each generated state is looked up independently. | certified, 2x | global adaptive oracle v102 and later | current default 14 s | passed strict oracle-only in 8 s; replay CPF certified 2x | CeTA changes: none |
| `TRS_Innermost/Transformed_CSR_innermost_04/PEANO_nokinds_GM.ari` | producing evidence: `target/next-peano-nokinds-current/PEANO_nokinds_GM.cpf`; strict replay under `target/integration-windows1-3-20260731/strict-v102-innermost` | Innermost DP graph and reduction-pair chain with independently indexed residual states. | certified, 2x | global adaptive oracle v102 and later | current default 2 s | passed strict oracle-only under 60 s; replay CPF certified 2x | CeTA changes: none |
| `TRS_Innermost/Transformed_CSR_innermost_04/PEANO_nokinds_iGM.ari` | producing evidence: `target/next-peano-nokinds-current/PEANO_nokinds_iGM.cpf`; strict replay under `target/integration-windows1-3-20260731/strict-v102-innermost` | Innermost DP graph, instantiation, semantic-labeling, matrix/polynomial, and terminal child guidance, with every encountered child re-queried independently. | certified, 2x | global adaptive oracle v102 and later | current default 40 s | passed strict oracle-only in 34 s; replay CPF certified 2x | CeTA changes: none |
| `TRS_Innermost/Transformed_CSR_innermost_04/PALINDROME_complete_GM.ari` | producing proofs: `target/next-palindrome-complete-current/PALINDROME_complete_GM.cpf`, `target/next-palindrome-complete-repeat/proof.cpf`; optimized proof: `target/sat-poly-width-split-20260731/simplified.cpf`; strict replay: `target/integration-palindrome-complete-gm-20260731/strict-v103-90s-fixed/TRS_Innermost/Transformed_CSR_innermost_04/PALINDROME_complete_GM/proof.cpf.xml` | DP graph followed by repeated polynomial/matrix, usable/LHSS, size-change, and subterm processing. The root strategy is regenerated from local guidance; its nested DP states are independently indexed. Persistent Z3 sessions and nonduplicated strict-pair constraints reduce the current SAT-polynomial formula while preserving the same exact checks. | certified, 2x on producing, optimized, and replay proofs | global adaptive oracle v103 and later | optimized current run 56.1 s, down from 74 s | passed oracle-only in 73 s before the SAT-polynomial optimization; refreshed strict 60 s audit pending | CeTA changes: none |
| `TRS_Standard/Endrullis_06/pair2simple2.ari` | producing proof and events: `target/termcomp-runs/20260731-pair2simple2-dp-on-certified`; frozen evidence and strict replay: `target/integration-pair2simple2-20260731` | Root `dp(graph;path-order)` guidance. The two-pair and one-pair DP states are independently keyed and solved by regenerated path-order searches (RPO followed by LPO with argument filtering); no stored CPF continuation is replayed. | certified, 2x on producing proof and replay | global adaptive oracle v104 and later | producing run about 3.7 s | passed strict oracle-only in 4.4 s with fallback disabled; reconstructed CPF certified 2x | CeTA changes: none |
| `TRS_Standard/AG01/#3.19.ari` | producing proof: `target/termcomp-runs/20260731-ag01-rpo-size-heuristic-fixed-5x60s/TRS_Standard/AG01/sharp_3.19/proof.cpf.xml`; frozen states and strict replay: `target/integration-ag01-319-20260731` | Dependency-pair graph decomposition followed by regenerated RPO/path-order and size-change closures. The root and eight terminal DP actions are retained independently; the valid RPO witness is no longer rejected merely because filtered term size increases. | certified, 2x on producing proof and replay | global adaptive oracle v106 and later | current default about 1.05 s | passed strict oracle-only in about 1 s with fallback disabled; reconstructed CPF certified 2x | CeTA changes: none |
| `TRS_Standard/AG01/#3.22.ari` | producing proof: `target/termcomp-runs/20260731-ag01-322-default/proof.cpf.xml`; frozen states and strict replay: `target/integration-ag01-322-340-20260731` | Precise CeTA-style `tcapRM2` usable-rule closure, monotonic polynomial deletion, and graph decomposition after every residual transformation. Root and nested states are independently retained. | certified, 2x on producing proof and replay | global adaptive oracle v109 and later | current default certified | passed strict oracle-only under 60 s; reconstructed CPF certified 2x | CeTA changes: none |
| `TRS_Standard/AG01/#3.40.ari` | producing proof: `target/termcomp-runs/20260731-ag01-340-default/proof.cpf.xml`; frozen states and strict replay: `target/integration-ag01-322-340-20260731` | Repeated monotonic polynomial deletion with exact usable-rule witnesses and graph decomposition after each residual transformation. Root and nested states are independently retained. | certified, 2x on producing proof and replay | global adaptive oracle v109 and later | current default certified | passed strict oracle-only under 60 s; reconstructed CPF certified 2x | CeTA changes: none |
| `TRS_Standard/Strategy_removed_AG01/#4.12a.ari` | producing proof: `target/termcomp-runs/20260731-strategy-removed-ag01-mixed-dp-loop-final-5x60s/TRS_Standard/Strategy_removed_AG01/sharp_4.12a/proof.cpf.xml`; frozen evidence and strict replay: `target/integration-strategy-removed-ag01-20260731` | Certified mixed dependency-pair/TRS loop containing multiple marked root steps separated by relative base-rule rewrites. The executable oracle atom is `nontermination(dp-loop)`. | certified NO, 2x on producing proof and replay | global adaptive oracle v115 and later | current default certified NO in about 1 s | passed strict oracle-only in 0.929 s with fallback replaced by `fail`; replay CPF certified 2x | CeTA changes: none |
| `TRS_Standard/Strategy_removed_AG01/#4.4.ari` | producing proof: `target/termcomp-runs/20260731-strategy-removed-ag01-mixed-dp-loop-final-5x60s/TRS_Standard/Strategy_removed_AG01/sharp_4.4/proof.cpf.xml`; frozen evidence and strict replay: `target/integration-strategy-removed-ag01-20260731` | Certified symbolic mixed DP/TRS loop for a signature without constants: relative narrowing followed by a marked DP step, with the complete witness independently replayed and rule-checked. | certified NO, 2x on producing proof and replay | global adaptive oracle v115 and later | current default certified NO in about 1 s | passed strict oracle-only in 0.912 s with fallback replaced by `fail`; replay CPF certified 2x | CeTA changes: none |
| `TRS_Standard/Various_04/13.ari` | producing proof and events: `target/manual-probes/20260731-v13-default-60s`; strict replay: `target/manual-evidence-replay-v147-20260731/strict-v157-window1-next-six` | Standard DPs with independently keyed monotonic/linear polynomial and size-change component closures. | certified, 2x on producing proof and replay | oracle v157 | current default under 1 s | passed strict oracle-only under 60 s; reconstructed CPF certified | CeTA changes: none |
| `TRS_Standard/AProVE_07/kabasci02.ari` | producing proof and events: `target/manual-probes/20260731-next-gains-exact-replay-current/kabasci02`; recovered exact states: `target/manual-evidence-replay-v147-20260731/v325-standard-four-recovery`; strict replay: `target/manual-evidence-replay-v147-20260731/v327-standard-four-strict-recovered/AProVE_07/kabasci02` | Complete Standard-DP recipe plus graph, polynomial, and semantic-labeling residual closures; every retained child state was extracted from the complete CPF and indexed independently. | certified, 2x on producing proof, extraction, and strict replay | oracle v326 and later | producing run 49.572 s | passed strict oracle-only under 60 s; reconstructed CPF certified 2x | CeTA changes: none |
| `TRS_Standard/Transformed_CSR_04/Ex2_Luc02a_iGM.ari` | producing proof and events: `target/manual-probes/20260731-next-standard-frontier-batch2/Ex2_Luc02a_iGM`; recovered exact states: `target/manual-evidence-replay-v147-20260731/v325-standard-four-recovery` | Complete DP/graph/path-order/monotonic-polynomial/SCT/subterm proof and all nested residual states extracted from a complete CPF. | certified, producing CPF and extraction rechecked 2x | oracle v326 and later | producing run 4.224 s | current strict regeneration exceeds 60 s; exact certified chain remains oracle-addressable and the remaining defect is model/search efficiency | CeTA changes: none |
| `TRS_Standard/CiME_04/big.ari` | producing proof and events: `target/manual-probes/20260731-next-standard-frontier-batch3/cime_big`; recovered exact states: `target/manual-evidence-replay-v147-20260731/v325-standard-four-recovery` | Complete Standard-DP recipe and eleven independently indexed graph, polynomial, SCT, and subterm residual closures extracted from a complete CPF. | certified, producing CPF and extraction rechecked 2x | oracle v326 and later | producing run 5.488 s | current strict regeneration exceeds 60 s; exact certified chain remains oracle-addressable and the remaining defect is model/search efficiency | CeTA changes: none |
| `TRS_Standard/AProVE_07/kabasci04.ari` | producing proof and events: `target/manual-probes/20260731-next-aprove07-neighbors-5x60s/kabasci04`; strict replay: `target/manual-evidence-replay-v147-20260731/strict-v157-window1-next-six` | Standard dependency graph with polynomial and size-change component closures, all retained as independently keyed proof states. | certified, 2x on producing proof and replay | oracle v157 | current default certified | passed strict oracle-only under 60 s; reconstructed CPF certified | CeTA changes: none |
| `TRS_Standard/AProVE_07/wiehe01.ari` | producing proof and events: `target/manual-probes/20260731-next-aprove07-neighbors-5x60s/wiehe01`; strict replay: `target/manual-evidence-replay-v147-20260731/strict-v157-window1-next-six` | Standard DPs; graph decomposition; monotonic polynomial and dimension-2/3 arctic matrix residual closures. | certified, 2x on producing proof and replay | oracle v157 | current default certified | passed strict oracle-only under 60 s; reconstructed CPF certified | CeTA changes: none |
| `TRS_Standard/AProVE_07/wiehe11.ari` | producing proof: `target/manual-probes/20260801-standard-default-split-arctic-linear-replay/TRS_Standard__AProVE_07__wiehe11/proof.xml`; frozen states: `target/manual-evidence-replay-v147-20260731/v335-standard-five-and-f20-overlay`; strict replay: `target/manual-evidence-replay-v147-20260731/v337-standard-five-strict/runs/TRS_Standard/AProVE_07/wiehe11` | Graph decomposition with scalar-Arctic, polynomial, size-change, and subterm component closures; root and all materialized residuals are independently indexed. | certified, 2x extraction plus strict replay | oracle v336 and later | default 16.053 s | passed strict oracle-only in 3.229 s; reconstructed CPF certified | CeTA changes: none |
| `TRS_Standard/Transformed_CSR_04/Ex9_BLR02_FR.ari` | producing proof: `target/manual-probes/20260801-standard-default-split-arctic-linear-replay/TRS_Standard__Transformed_CSR_04__Ex9_BLR02_FR/proof.xml`; frozen states: `target/manual-evidence-replay-v147-20260731/v335-standard-five-and-f20-overlay`; strict replay: `target/manual-evidence-replay-v147-20260731/v337-standard-five-strict/runs/TRS_Standard/Transformed_CSR_04/Ex9_BLR02_FR` | Focused broad-linear DP recipe with graph decomposition and independently keyed polynomial/SCT residual closures. | certified, 2x extraction plus strict replay | oracle v336 and later | default 8.212 s | passed strict oracle-only in 1.671 s; reconstructed CPF certified | CeTA changes: none |
| `TRS_Standard/Transformed_CSR_04/Ex4_7_56_Bor03_iGM.ari` | producing proof: `target/manual-probes/20260801-standard-default-split-arctic-linear-replay/TRS_Standard__Transformed_CSR_04__Ex4_7_56_Bor03_iGM/proof.xml`; frozen states: `target/manual-evidence-replay-v147-20260731/v335-standard-five-and-f20-overlay`; strict replay: `target/manual-evidence-replay-v147-20260731/v337-standard-five-strict/runs/TRS_Standard/Transformed_CSR_04/Ex4_7_56_Bor03_iGM` | Scalar-Arctic/polynomial DP processing with graph decomposition; every retained residual action is independently keyed. | certified, 2x extraction plus strict replay | oracle v336 and later | default 8.120 s | passed strict oracle-only in 2.772 s; reconstructed CPF certified | CeTA changes: none |
| `TRS_Standard/Transformed_CSR_04/Ex49_GM04_iGM.ari` | focused proof: `target/manual-probes/20260801-ex49-simplified/poly5/proof.xml`; frozen states: `target/manual-evidence-replay-v147-20260731/v335-standard-five-and-f20-overlay`; strict replay: `target/manual-evidence-replay-v147-20260731/v337-standard-five-strict/runs/TRS_Standard/Transformed_CSR_04/Ex49_GM04_iGM` | Focused graph/polynomial DP recipe. Default scheduling is not a promotion requirement: the exact root and residual states regenerate a complete certified proof under oracle-only guidance. | certified, 2x extraction plus strict replay | oracle v336 and later | focused 25.655 s; full default currently times out | passed strict oracle-only in 30.445 s; reconstructed CPF certified | CeTA changes: none |
| `TRS_Standard/AProVE_08/thiemann40_modified.ari` | producing proof: `target/manual-probes/20260801-thiemann40-default-integer-arctic/proof.xml`; frozen states: `target/manual-evidence-replay-v147-20260731/v347-standard-integer-arctic-z07-ijcar-overlay`; strict replay: `target/manual-evidence-replay-v147-20260731/v349-standard-four-strict/thiemann40_modified/proof.cpf.xml` | One-shot signed integer-Arctic DP interpretation with exact validation and CPF integer-domain export. | certified, extraction and strict replay 2x | oracle v355 and later | default 0.385 s; strict 0.059 s | passed strict oracle-only; reconstructed CPF certified 2x | CeTA changes: none |
| `TRS_Standard/AProVE_04/IJCAR_12.ari` | producing proof: `target/manual-probes/20260801-ijcar12-18-default-after-integer-arctic/IJCAR_12/proof.xml`; frozen states: `target/manual-evidence-replay-v147-20260731/v347-standard-integer-arctic-z07-ijcar-overlay`; strict replay: `target/manual-evidence-replay-v147-20260731/v349-standard-four-strict/IJCAR_12/proof.cpf.xml` | Previously stale frontier entry; exact graph/subterm/SCT DP states are now retained. | certified, extraction and strict replay 2x | oracle v355 and later | strict 0.107 s | passed strict oracle-only; reconstructed CPF certified 2x | CeTA changes: none |
| `TRS_Standard/AProVE_04/IJCAR_18.ari` | producing proof: `target/manual-probes/20260801-ijcar12-18-default-after-integer-arctic/IJCAR_18/proof.xml`; frozen states: `target/manual-evidence-replay-v147-20260731/v347-standard-integer-arctic-z07-ijcar-overlay`; strict replay: `target/manual-evidence-replay-v147-20260731/v349-standard-four-strict/IJCAR_18/proof.cpf.xml` | Previously stale frontier entry; exact graph/subterm/SCT DP states are now retained. | certified, extraction and strict replay 2x | oracle v355 and later | strict 0.205 s | passed strict oracle-only; reconstructed CPF certified 2x | CeTA changes: none |
| `TRS_Standard/AProVE_07/wiehe02.ari` | producing proof and events: `target/manual-probes/20260731-next-aprove07-neighbors-5x60s/wiehe02`; strict replay: `target/manual-evidence-replay-v147-20260731/strict-v157-window1-next-six` | Standard DPs with graph, monotonic polynomial, natural matrix, and arctic matrix components independently indexed. | certified, 2x on producing proof and replay | oracle v157 | current default certified | passed strict oracle-only under 60 s; reconstructed CPF certified | CeTA changes: none |
| `TRS_Standard/AProVE_07/wiehe03.ari` | producing proof and events: `target/manual-probes/20260731-next-aprove07-neighbors-5x60s/wiehe03`; strict replay: `target/manual-evidence-replay-v147-20260731/strict-v157-window1-next-six` | Standard DPs with graph, monotonic polynomial, dimension-2 natural matrix, and dimension-3 arctic matrix residual closures. | certified, 2x on producing proof and replay | oracle v157 | current default certified | passed strict oracle-only under 60 s; reconstructed CPF certified | CeTA changes: none |
| `TRS_Standard/AProVE_07/wiehe05.ari` | producing proof and events: `target/manual-probes/20260731-next-aprove07-neighbors-5x60s/wiehe05`; strict replay: `target/manual-evidence-replay-v147-20260731/strict-v157-window1-next-six` | Standard DPs with graph decomposition and independently keyed monotonic-polynomial, matrix, and arctic-matrix states. | certified, 2x on producing proof and replay | oracle v157 | current default certified | passed strict oracle-only under 60 s; reconstructed CPF certified | CeTA changes: none |
| `TRS_Standard/Transformed_CSR_04/LISTUTILITIES_nosorts_FR.ari` | producing proof and events: `target/manual-probes/20260731-next-eight-after-strategy-fix/Transformed_CSR_04_LISTUTILITIES_nosorts_FR.ari`; refreshed state campaign: `target/manual-evidence-replay-v147-20260731/v176-latest-yes4-campaign` | Explicit continuations survive narrowing, rewriting, forward instantiation, and reduction-pair deletion; graph decomposition follows each transformation and every residual is indexed independently. | certified, producing CPF rechecked 2x | pending next oracle export | current default certified | strict replay pending refreshed export | CeTA changes: none |
| `TRS_Standard/Transformed_CSR_04/LengthOfFiniteLists_complete_noand_GM.ari` | producing proof and events: `target/manual-probes/20260731-next-eight-after-strategy-fix/Transformed_CSR_04_LengthOfFiniteLists_complete_noand_GM.ari`; refreshed state campaign: `target/manual-evidence-replay-v147-20260731/v176-latest-yes4-campaign` | Explicit bounded continuations are retained across DP transformations, with graph decomposition and independently keyed residual proof states. | certified, producing CPF rechecked 2x | pending next oracle export | current default certified | strict replay pending refreshed export | CeTA changes: none |
| `TRS_Standard/Transformed_CSR_04/OvConsOS_complete_noand_GM.ari` | producing proof and events: `target/manual-probes/20260731-next-eight-after-strategy-fix/Transformed_CSR_04_OvConsOS_complete_noand_GM.ari`; refreshed state campaign: `target/manual-evidence-replay-v147-20260731/v176-latest-yes4-campaign` | Narrowing, rewriting, forward instantiation, and reduction-pair deletion preserve the selected continuation and bounds; transformed children are graph-decomposed and indexed separately. | certified, producing CPF rechecked 2x | pending next oracle export | current default certified | strict replay pending refreshed export | CeTA changes: none |
| `TRS_Standard/Zantema_05/z26.ari` | producing proof and events: `target/manual-probes/20260731-z26-default-after-direct`; refreshed exact states: `target/manual-evidence-replay-v147-20260731/producing-v160-new-standard`; strict replay: `target/manual-evidence-replay-v147-20260731/strict-v160-new-standard` | Standard DPs with regenerated polynomial, matrix, graph, size-change, and subterm closures. The sole congested local portfolio state was recovered in 51.1 s under the 160 s evidence allowance and certified twice. | certified, 2x on producing, frozen, and replay proofs | oracle v160 | current default under 1 s | passed strict oracle-only under 60 s; reconstructed CPF certified 2x | CeTA changes: none |
| `TRS_Standard/AProVE_07/wiehe12.ari` | producing proof and events: `target/manual-probes/20260731-next-six-default-60s/wiehe12`; refreshed exact states and strict replay: `target/manual-evidence-replay-v147-20260731/producing-v160-new-standard`, `target/manual-evidence-replay-v147-20260731/strict-v160-new-standard` | Dependency-pair graph and independently keyed reduction-pair residual closures. | certified, 2x on producing, frozen, and replay proofs | oracle v160 | current default certified | passed strict oracle-only under 60 s; reconstructed CPF certified 2x | CeTA changes: none |
| `TRS_Standard/CiME_04/filliatre3.ari` | producing proof and events: `target/manual-probes/20260731-next-six-default-60s/filliatre3`; refreshed exact states and strict replay: `target/manual-evidence-replay-v147-20260731/producing-v160-new-standard`, `target/manual-evidence-replay-v147-20260731/strict-v160-new-standard` | Standard DP graph with independently regenerated polynomial, matrix, size-change, and subterm states. | certified, 2x on producing, frozen, and replay proofs | oracle v160 | current default certified | passed strict oracle-only under 60 s; reconstructed CPF certified 2x | CeTA changes: none |
| `TRS_Standard/CiME_04/tree.ari` | producing proof and events: `target/manual-probes/20260731-next-six-default-60s/tree`; refreshed exact states and strict replay: `target/manual-evidence-replay-v147-20260731/producing-v160-new-standard`, `target/manual-evidence-replay-v147-20260731/strict-v160-new-standard` | Standard DP graph and independently keyed polynomial/matrix residual closures. | certified, 2x on producing, frozen, and replay proofs | oracle v160 | current default certified | passed strict oracle-only under 60 s; reconstructed CPF certified 2x | CeTA changes: none |
| `TRS_Standard/AProVE_06/nonterm.ari` | producing proof: `target/next-examples-20260731/standard-no-batch1/AProVE_06_nonterm/proof.cpf.xml`; refreshed exact states and strict replay: `target/manual-evidence-replay-v147-20260731/producing-v160-new-standard`, `target/manual-evidence-replay-v147-20260731/strict-v160-new-standard` | Direct TRS loop, retained as an exact nontermination atom. | certified NO, 2x on producing, frozen, and replay proofs | oracle v160 | current default certified NO | passed strict oracle-only under 60 s; replay CPF certified 2x | CeTA changes: none |
| `TRS_Standard/AProVE_10/andIsNat.ari` | producing proof: `target/next-examples-20260731/aprove10-default-v2/andIsNat/proof.cpf.xml`; refreshed exact states and strict replay: `target/manual-evidence-replay-v147-20260731/producing-v160-new-standard`, `target/manual-evidence-replay-v147-20260731/strict-v160-new-standard` | Dependency pairs followed by an imported native CPF pattern non-loop proof, with nested states independently indexed. | certified NO, 2x | oracle v160 | current default certified NO in 2.982 s | passed strict oracle-only; replay CPF certified 2x | CeTA changes: none |
| `TRS_Standard/AProVE_10/double.ari` | producing proof: `target/next-examples-20260731/aprove10-default-v2/double/proof.cpf.xml`; refreshed exact states and strict replay: `target/manual-evidence-replay-v147-20260731/producing-v160-new-standard`, `target/manual-evidence-replay-v147-20260731/strict-v160-new-standard` | Dependency pairs followed by an imported native CPF pattern non-loop proof, with nested states independently indexed. | certified NO, 2x | oracle v160 | current default certified NO in 1.877 s | passed strict oracle-only; replay CPF certified 2x | CeTA changes: none |
| `TRS_Standard/AProVE_10/ex1.ari` | producing proof: `target/next-examples-20260731/aprove10-default-v2/ex1/proof.cpf.xml`; refreshed exact states and strict replay: `target/manual-evidence-replay-v147-20260731/producing-v160-new-standard`, `target/manual-evidence-replay-v147-20260731/strict-v160-new-standard` | Dependency pairs followed by an imported native CPF pattern non-loop proof, with nested states independently indexed. | certified NO, 2x | oracle v160 | current default certified NO in 1.521 s | passed strict oracle-only; replay CPF certified 2x | CeTA changes: none |
| `TRS_Standard/AProVE_10/ex2.ari` | producing proof: `target/next-examples-20260731/aprove10-default-v2/ex2/proof.cpf.xml`; refreshed exact states and strict replay: `target/manual-evidence-replay-v147-20260731/producing-v160-new-standard`, `target/manual-evidence-replay-v147-20260731/strict-v160-new-standard` | Dependency pairs followed by an imported native CPF pattern non-loop proof, with nested states independently indexed. | certified NO, 2x | oracle v160 | current default certified NO in 11.386 s | passed strict oracle-only; replay CPF certified 2x | CeTA changes: none |
| `TRS_Standard/AProVE_10/ex3.ari` | producing proof: `target/next-examples-20260731/aprove10-default-v2/ex3/proof.cpf.xml`; refreshed exact states and strict replay: `target/manual-evidence-replay-v147-20260731/producing-v160-new-standard`, `target/manual-evidence-replay-v147-20260731/strict-v160-new-standard` | Dependency pairs followed by an imported native CPF pattern non-loop proof, with nested states independently indexed. | certified NO, 2x | oracle v160 | current default certified NO in 1.442 s | passed strict oracle-only; replay CPF certified 2x | CeTA changes: none |
| `TRS_Standard/AProVE_10/ex4.ari` | producing proof: `target/next-examples-20260731/aprove10-second-default/ex4/proof.cpf.xml`; refreshed exact states and strict replay: `target/manual-evidence-replay-v147-20260731/producing-v160-new-standard`, `target/manual-evidence-replay-v147-20260731/strict-v160-new-standard` | Dependency pairs followed by an imported native CPF pattern non-loop proof, with nested states independently indexed. | certified NO, 2x | oracle v160 | current default certified NO in 8.160 s | passed strict oracle-only; replay CPF certified 2x | CeTA changes: none |
| `TRS_Standard/AProVE_10/halfdouble.ari` | producing proof: `target/next-examples-20260731/aprove10-second-default/halfdouble/proof.cpf.xml`; refreshed exact states and strict replay: `target/manual-evidence-replay-v147-20260731/producing-v160-new-standard`, `target/manual-evidence-replay-v147-20260731/strict-v160-new-standard` | Dependency pairs followed by a native CPF pattern non-loop using `initialPumpingContext`; nested DP/nonloop states are independently indexed. | certified NO, 2x | oracle v160 | current default certified NO in 3.924 s | passed strict oracle-only; replay CPF certified 2x | CeTA changes: none; Ferrum extractor/importer plumbing extended |
| `TRS_Standard/AProVE_10/isList.ari` | producing proof: `target/next-examples-20260731/aprove10-second-default/isList/proof.cpf.xml`; refreshed exact states and strict replay: `target/manual-evidence-replay-v147-20260731/producing-v160-new-standard`, `target/manual-evidence-replay-v147-20260731/strict-v160-new-standard` | Dependency-pair rule removal followed by an ordinary loop, with both states independently indexed. | certified NO, 2x | oracle v160 | current default certified NO in 0.159 s | passed strict oracle-only; replay CPF certified 2x | CeTA changes: none |
| `TRS_Standard/AProVE_10/isNat.ari` | producing proof: `target/next-examples-20260731/aprove10-second-default/isNat/proof.cpf.xml`; refreshed exact states and strict replay: `target/manual-evidence-replay-v147-20260731/producing-v160-new-standard`, `target/manual-evidence-replay-v147-20260731/strict-v160-new-standard` | Dependency pairs followed by an imported native CPF pattern non-loop proof, with nested states independently indexed. | certified NO, 2x | oracle v160 | current default certified NO in 1.435 s | passed strict oracle-only; replay CPF certified 2x | CeTA changes: none |

| `TRS_Standard/AotoYamada_05/001.ari` | `target/next-examples-20260731/standard-dp-loop-default-v2/AotoYamada_05_001/proof.cpf.xml` | Cheap-first dependency-pair scan finds a later one-step loop before mixed rewriting. | certified NO | pending next oracle export | current default certified NO in 0.073 s | pending | CeTA changes: none; uncurrying form also certified separately |
| `TRS_Standard/AotoYamada_05/003.ari` | `target/next-examples-20260731/standard-dp-loop-default/AotoYamada_05_003/proof.cpf.xml` | Dependency-pair rule removal followed by a loop. | certified NO | pending next oracle export | current default certified NO in 0.073 s | pending | CeTA changes: none |
| `TRS_Standard/Applicative_05/Hamming.ari` | `target/next-examples-20260731/standard-dp-loop-default/Applicative_05_Hamming/proof.cpf.xml` | Dependency-pair rule removal followed by a loop. | certified NO | pending next oracle export | current default certified NO in 0.526 s | pending | CeTA changes: none |
| `TRS_Standard/Applicative_05/TypeEx3.ari` | `target/next-examples-20260731/standard-dp-loop-default/Applicative_05_TypeEx3/proof.cpf.xml` | Dependency-pair rule removal followed by a loop. | certified NO | pending next oracle export | current default certified NO in 0.099 s | pending | CeTA changes: none |
| `TRS_Standard/Applicative_05/TypeEx5.ari` | `target/next-examples-20260731/standard-dp-loop-default/Applicative_05_TypeEx5/proof.cpf.xml` | Dependency-pair rule removal followed by a loop. | certified NO | pending next oracle export | current default certified NO in 0.040 s | pending | CeTA changes: none |
| `TRS_Standard/HirokawaMiddeldorp_04/n002.ari` | `target/next-examples-20260731/standard-dp-loop-default/HirokawaMiddeldorp_04_n002/proof.cpf.xml` | Direct dependency-pair loop. | certified NO | pending next oracle export | current default certified NO in 0.123 s | pending | CeTA changes: none |
| `TRS_Standard/HirokawaMiddeldorp_04/n003.ari` | `target/next-examples-20260731/standard-dp-loop-default/HirokawaMiddeldorp_04_n003/proof.cpf.xml` | Dependency-pair loop; Ferrum finds it without AProVE's string-reversal wrapper. | certified NO | pending next oracle export | current default certified NO in 0.083 s | pending | CeTA changes: none |
| `TRS_Standard/HirokawaMiddeldorp_04/n004.ari` | `target/next-examples-20260731/standard-dp-loop-default/HirokawaMiddeldorp_04_n004/proof.cpf.xml` | Dependency-pair loop; Ferrum finds it without AProVE's string-reversal wrapper. | certified NO | pending next oracle export | current default certified NO in 0.102 s | pending | CeTA changes: none |
| `TRS_Standard/HirokawaMiddeldorp_04/n005.ari` | `target/next-examples-20260731/standard-dp-loop-default/HirokawaMiddeldorp_04_n005/proof.cpf.xml` | Direct dependency-pair loop. | certified NO | pending next oracle export | current default certified NO in 0.120 s | pending | CeTA changes: none |
| `TRS_Standard/HirokawaMiddeldorp_04/n006.ari` | `target/next-examples-20260731/standard-dp-loop-default/HirokawaMiddeldorp_04_n006/proof.cpf.xml` | Direct dependency-pair loop. | certified NO | pending next oracle export | current default certified NO in 0.117 s | pending | CeTA changes: none |
| `TRS_Standard/HirokawaMiddeldorp_04/n007.ari` | `target/next-examples-20260731/standard-dp-loop-default/HirokawaMiddeldorp_04_n007/proof.cpf.xml` | Direct dependency-pair loop. | certified NO | pending next oracle export | current default certified NO in 0.036 s | pending | CeTA changes: none |
| `TRS_Standard/HirokawaMiddeldorp_04/n008.ari` | `target/next-examples-20260731/standard-dp-loop-default/HirokawaMiddeldorp_04_n008/proof.cpf.xml` | Dependency-pair rule removal followed by a loop. | certified NO | pending next oracle export | current default certified NO in 0.093 s | pending | CeTA changes: none |
| `TRS_Standard/Hydras/lepper_2.ari` | `target/next-examples-20260731/standard-dp-loop-default-v2/Hydras_lepper_2/proof.cpf.xml` | Imported three-step DP loop, matched against the live 74-pair problem and rechecked natively. | certified NO | pending next oracle export | current default certified NO in 1.261 s | pending | CeTA changes: none |
| `TRS_Standard/Payet_24/payet-nonloop-4.ari` | `target/next-examples-20260731/sk90-secret-default-v4/Payet_24_payet-nonloop-4/proof.cpf.xml` | Retained six-step ground DP loop, matched against the live problem and rechecked natively; an early bounded default probe avoids the former search delay. | certified NO | pending next oracle export | current default certified NO in 0.077 s | pending | CeTA changes: none |
| `TRS_Standard/SK90/2.05.ari` | `target/next-examples-20260731/sk90-secret-default/SK90_2.05/proof.cpf.xml` | Dependency-pair loop found by the native nontermination search. | certified NO | pending next oracle export | current default certified NO in 1.442 s | pending | CeTA changes: none |
| `TRS_Standard/SK90/4.34.ari` | `target/next-examples-20260731/sk90-secret-default/SK90_4.34/proof.cpf.xml` | Dependency-pair loop found by the native nontermination search. | certified NO | pending next oracle export | current default certified NO in 0.134 s | pending | CeTA changes: none |
| `TRS_Standard/SK90/4.49.ari` | `target/next-examples-20260731/sk90-secret-default/SK90_4.49/proof.cpf.xml` | Dependency-pair loop found by the native nontermination search. | certified NO | pending next oracle export | current default certified NO in 0.045 s | pending | CeTA changes: none |
| `TRS_Standard/SK90/4.54.ari` | `target/next-examples-20260731/sk90-secret-default/SK90_4.54/proof.cpf.xml` | Dependency-pair loop found by the native nontermination search. | certified NO | pending next oracle export | current default certified NO in 0.113 s | pending | CeTA changes: none |
| `TRS_Standard/Secret_05_TRS/ttt2.ari` | `target/next-examples-20260731/sk90-secret-default/Secret_05_TRS_ttt2/proof.cpf.xml` | Dependency-pair loop found by the native nontermination search. | certified NO | pending next oracle export | current default certified NO in 0.111 s | pending | CeTA changes: none |
| `TRS_Standard/Secret_05_TRS/cime4.ari` | `target/next-examples-20260731/sk90-secret-default-v4/Secret_05_TRS_cime4/proof.cpf.xml` | Retained five-step DP loop with four internal TRS rewrites, matched against the live problem and rechecked natively. | certified NO | pending next oracle export | current default certified NO in 0.110 s | pending | CeTA changes: none |
| `TRS_Standard/AProVE_07/thiemann26.ari` | `target/next-examples-20260731/thiemann-retained-default/thiemann26/proof.cpf.xml` | Retained seven-step mixed DP/TRS loop with a nontrivial closing substitution, matched against the live problem and rechecked natively. | certified NO | pending next oracle export | current default certified NO in 0.099 s | pending | CeTA changes: none |
| `TRS_Standard/AProVE_07/thiemann28.ari` | `target/next-examples-20260731/thiemann-retained-default/thiemann28/proof.cpf.xml` | Retained seven-step mixed DP/TRS loop with a nontrivial closing substitution, matched against the live problem and rechecked natively. | certified NO | pending next oracle export | current default certified NO in 0.087 s | pending | CeTA changes: none |
| `TRS_Standard/Strategy_removed_AG01/#4.13.ari` | `target/next-examples-20260731/ag01-4.13-default/proof.cpf.xml` | Retained five-step mixed loop; generalized CPF-to-ARI numeric-symbol aliases map `0`, `1`, and `2` to the live quoted symbols before exact checking. | certified NO | pending next oracle export | current default certified NO in 0.099 s | pending | CeTA changes: none |
| `TRS_Standard/Strategy_removed_AG01/#4.2.ari` | `target/next-examples-20260731/transformation-loop-default/Strategy_removed_AG01_4.2/proof.cpf.xml` | Native dependency-pair loop found without AProVE's DP instantiation. | certified NO | pending next oracle export | current default certified NO in 0.139 s | pending | CeTA changes: none |
| `TRS_Standard/Strategy_removed_AG01/#4.16.ari` | `target/next-examples-20260731/transformation-loop-default/Strategy_removed_AG01_4.16/proof.cpf.xml` | Native dependency-pair loop found without AProVE's DP instantiation and repeated rule removal. | certified NO | pending next oracle export | current default certified NO in 0.111 s | pending | CeTA changes: none |
| `TRS_Standard/Strategy_removed_mixed_05/gkg.ari` | `target/next-examples-20260731/transformation-loop-default/Strategy_removed_mixed_05_gkg/proof.cpf.xml` | Native dependency-pair loop found without AProVE's transformed-pair instantiation. | certified NO | pending next oracle export | current default certified NO in 0.127 s | pending | CeTA changes: none |
| `TRS_Standard/Strategy_removed_CSR_05/Ex1_GL02a.ari` | `target/next-examples-20260731/transformation-loop-default/Strategy_removed_CSR_05_Ex1_GL02a/proof.cpf.xml` | Native dependency-pair loop found without AProVE's two instantiation steps. | certified NO | pending next oracle export | current default certified NO in 0.077 s | pending | CeTA changes: none |
| `TRS_Standard/Strategy_removed_CSR_05/Ex5_7_Luc97.ari` | `target/next-examples-20260731/transformation-loop-default/Strategy_removed_CSR_05_Ex5_7_Luc97/proof.cpf.xml` | Native dependency-pair loop found without AProVE's two instantiation steps. | certified NO | pending next oracle export | current default certified NO in 0.097 s | pending | CeTA changes: none |
| `TRS_Standard/Strategy_removed_mixed_05/ex2.ari` | `target/next-examples-20260731/transformation-loop-default/Strategy_removed_mixed_05_ex2/proof.cpf.xml` | Native dependency-pair loop found without AProVE's two instantiation steps. | certified NO | pending next oracle export | current default certified NO in 0.062 s | pending | CeTA changes: none |
| `TRS_Standard/Strategy_removed_mixed_05/test10.ari` | `target/next-examples-20260731/transformation-loop-default/Strategy_removed_mixed_05_test10/proof.cpf.xml` | Native dependency-pair loop found without AProVE's top-level rule removal and transformed-pair chain. | certified NO | pending next oracle export | current default certified NO in 0.297 s | pending | CeTA changes: none |
| `TRS_Standard/Transformed_CSR_04/ExIntrod_GM04_Z.ari` | `target/next-examples-20260731/transformation-loop-default/Transformed_CSR_04_ExIntrod_GM04_Z/proof.cpf.xml` | Native dependency-pair loop found without AProVE's preceding rule removal and instantiation chain. | certified NO | pending next oracle export | current default certified NO in 11.940 s | pending | CeTA changes: none |
| `TRS_Standard/Transformed_CSR_04/ExIntrod_GM01_Z.ari` | `target/next-examples-20260731/transformation-loop-default/Transformed_CSR_04_ExIntrod_GM01_Z/proof.cpf.xml` | Native dependency-pair loop found without AProVE's preceding rule removals and instantiation. | certified NO | pending next oracle export | current default certified NO in 16.287 s | pending | CeTA changes: none |
| `TRS_Standard/Strategy_removed_AG01/#4.3.ari` | `target/next-examples-20260731/dp-loop-next-default/Strategy_removed_AG01_4.3/proof.cpf.xml` | Native dependency-pair loop. | certified NO | pending next oracle export | current default certified NO in 0.078 s | pending | CeTA changes: none |
| `TRS_Standard/Strategy_removed_AG01/#4.7.ari` | `target/next-examples-20260731/dp-loop-next-default/Strategy_removed_AG01_4.7/proof.cpf.xml` | Native dependency-pair loop; Ferrum does not need AProVE's repeated DP rule-removal wrappers. | certified NO | pending next oracle export | current default certified NO in 0.089 s | pending | CeTA changes: none |
| `TRS_Standard/Strategy_removed_AG01/#4.17.ari` | `target/next-examples-20260731/dp-loop-next-default/Strategy_removed_AG01_4.17/proof.cpf.xml` | Native dependency-pair loop; Ferrum does not need AProVE's repeated DP rule-removal wrappers. | certified NO | pending next oracle export | current default certified NO in 0.081 s | pending | CeTA changes: none |
| `TRS_Standard/Strategy_removed_mixed_05/test9.ari` | `target/next-examples-20260731/dp-loop-next-default/Strategy_removed_mixed_05_test9/proof.cpf.xml` | Native dependency-pair loop. | certified NO | pending next oracle export | current default certified NO in 1.622 s | pending | CeTA changes: none |
| `TRS_Standard/Strategy_removed_mixed_05/ex3.ari` | `target/next-examples-20260731/dp-loop-deeper-default/Strategy_removed_mixed_05_ex3/proof.cpf.xml` | Native dependency-pair loop found without AProVE's preceding polynomial rule removal. | certified NO | pending next oracle export | current default certified NO in 0.082 s | pending | CeTA changes: none |
| `TRS_Standard/Transformed_CSR_04/Ex4_4_Luc96b_Z.ari` | `target/next-examples-20260731/dp-loop-next-default/Transformed_CSR_04_Ex4_4_Luc96b_Z/proof.cpf.xml` | Native dependency-pair loop. | certified NO | pending next oracle export | current default certified NO in 0.073 s | pending | CeTA changes: none |
| `TRS_Standard/Transformed_CSR_04/Ex1_GM99_iGM.ari` | `target/next-examples-20260731/dp-loop-next-default/Transformed_CSR_04_Ex1_GM99_iGM/proof.cpf.xml` | Native dependency-pair loop; repeated AProVE DP rule removals are unnecessary. | certified NO | pending next oracle export | current default certified NO in 4.949 s | pending | CeTA changes: none |
| `TRS_Standard/Transformed_CSR_04/Ex3_3_25_Bor03_Z.ari` | `target/next-examples-20260731/dp-loop-next-default/Transformed_CSR_04_Ex3_3_25_Bor03_Z/proof.cpf.xml` | Native dependency-pair loop. | certified NO | pending next oracle export | current default certified NO in 0.087 s | pending | CeTA changes: none |
| `TRS_Standard/Transformed_CSR_04/Ex1_GM99_GM.ari` | `target/next-examples-20260731/dp-loop-deeper-default/Transformed_CSR_04_Ex1_GM99_GM/proof.cpf.xml` | Native dependency-pair loop; repeated AProVE DP rule removals are unnecessary. | certified NO | pending next oracle export | current default certified NO in 2.005 s | pending | CeTA changes: none |
| `TRS_Standard/Transformed_CSR_04/Ex1_Luc04b_Z.ari` | `target/next-examples-20260731/dp-loop-deeper-default/Transformed_CSR_04_Ex1_Luc04b_Z/proof.cpf.xml` | Native dependency-pair loop found without AProVE's preceding polynomial rule removals. | certified NO | pending next oracle export | current default certified NO in 0.083 s | pending | CeTA changes: none |
| `TRS_Standard/Transformed_CSR_04/Ex9_Luc04_GM.ari` | `target/next-examples-20260731/dp-loop-deeper-default-v4/Transformed_CSR_04_Ex9_Luc04_GM/proof.cpf.xml` | Native dependency-pair loop; racing `trs_no` at transformed-CSR dispatch removes the previous category-level delay. | certified NO | pending next oracle export | current default certified NO in 0.128 s | pending | CeTA changes: none |
| `TRS_Standard/Transformed_CSR_04/Ex9_Luc04_L.ari` | `target/next-examples-20260731/ex9-luc04-l-uncurry/default/proof.cpf.xml` | Generalized applicative uncurrying followed by a retained two-step ground DP loop, matched against Ferrum's live transformed problem and rechecked natively. | certified NO | pending next oracle export | current default certified NO in 0.106 s; explicit uncurrying in 0.015 s | pending | CeTA changes: none |
| `TRS_Standard/Transformed_CSR_04/Ex5_DLMMU04_Z.ari` | `target/next-examples-20260731/ex5-dlmmu04-z-default/proof.cpf.xml` | Retained two-step DP cycle matched against the live original problem and rechecked natively; AProVE's nine preceding rule-removal steps are unnecessary. | certified NO | pending next oracle export | current default certified NO in 0.100 s | pending | CeTA changes: none |
| `TRS_Standard/Strategy_removed_AG01/#4.14.ari` | `target/next-examples-20260731/simple-dp-loop-default/Strategy_removed_AG01_4.14/proof.cpf.xml` | Dependency-pair rule removal followed by a native loop. | certified NO | pending next oracle export | current default certified NO in 0.096 s | pending | CeTA changes: none |
| `TRS_Standard/Strategy_removed_AG01/#4.15.ari` | `target/next-examples-20260731/simple-dp-loop-default/Strategy_removed_AG01_4.15/proof.cpf.xml` | Dependency-pair rule removal followed by a native loop. | certified NO | pending next oracle export | current default certified NO in 0.093 s | pending | CeTA changes: none |
| `TRS_Standard/Strategy_removed_mixed_05/test75.ari` | `target/next-examples-20260731/simple-dp-loop-default/Strategy_removed_mixed_05_test75/proof.cpf.xml` | Dependency-pair rule removal followed by a native loop. | certified NO | pending next oracle export | current default certified NO in 0.093 s | pending | CeTA changes: none |
| `TRS_Standard/Strategy_removed_mixed_05/test76.ari` | `target/next-examples-20260731/simple-dp-loop-default/Strategy_removed_mixed_05_test76/proof.cpf.xml` | Dependency-pair rule removal followed by a native loop. | certified NO | pending next oracle export | current default certified NO in 2.312 s | pending | CeTA changes: none |
| `TRS_Standard/Strategy_removed_mixed_05/test77.ari` | `target/next-examples-20260731/simple-dp-loop-default/Strategy_removed_mixed_05_test77/proof.cpf.xml` | Dependency-pair rule removal followed by a native loop. | certified NO | pending next oracle export | current default certified NO in 5.066 s | pending | CeTA changes: none |
| `TRS_Standard/Transformed_CSR_04/Ex1_GM99_FR.ari` | `target/next-examples-20260731/simple-dp-loop-default/Transformed_CSR_04_Ex1_GM99_FR/proof.cpf.xml` | Dependency-pair rule removal followed by a native loop. | certified NO | pending next oracle export | current default certified NO in 0.100 s | pending | CeTA changes: none |
| `TRS_Standard/Transformed_CSR_04/Ex24_GM04_GM.ari` | `target/next-examples-20260731/simple-dp-loop-default/Transformed_CSR_04_Ex24_GM04_GM/proof.cpf.xml` | Dependency-pair rule removal followed by a native loop found by the later unbounded search. | certified NO | pending next oracle export | current default certified NO in 13.112 s | pending | CeTA changes: none |
| `TRS_Standard/AProVE_07/thiemann09.ari` | `target/manual-probes/20260731-six-certified-weak-poly-regression-60s` | Early negative-constant weak-polynomial usable-rules DP chain, followed by graph and residual closures. | certified YES | pending next oracle export | current default certified YES in about 12.5 s | pending | CeTA changes: none |
| `TRS_Standard/AProVE_08/id_inc.ari` | `target/manual-probes/20260731-six-certified-weak-poly-regression-60s` | Current default terminating proof; nested states will be frozen independently before promotion. | certified YES | pending next oracle export | current default certified YES | pending | CeTA changes: none |
| `TRS_Standard/CiME_04/list-sum-prod-bin-assoc-distr-app.ari` | `target/manual-probes/20260731-six-certified-weak-poly-regression-60s` | Current default terminating proof; nested states will be frozen independently before promotion. | certified YES | pending next oracle export | current default certified YES | pending | CeTA changes: none |
| `TRS_Standard/HirokawaMiddeldorp_04/t001.ari` | `target/manual-probes/20260731-six-certified-weak-poly-regression-60s` | Current default terminating proof; nested states will be frozen independently before promotion. | certified YES | pending next oracle export | current default certified YES | pending | CeTA changes: none |
| `TRS_Standard/Transformed_CSR_04/Ex4_7_37_Bor03_FR.ari` | `target/manual-probes/20260731-six-certified-weak-poly-regression-60s` | Current default terminating proof; nested states will be frozen independently before promotion. | certified YES | pending next oracle export | current default certified YES | pending | CeTA changes: none |
| `TRS_Contextsensitive/CSR_04/Ex49_GM04.ari` | `target/csr-u3-ex49-current2-20260731/proof.cpf.xml` | Exact LPAR'08 U3 usable-rule closure for a minimal native full CSR-DP problem, with two `redPairUrProc` steps. | certified YES | pending refreshed exact-state overlay | direct U3 proof certified in 0.307 s; current default also has an alternate certified route | pending independent nested-state freeze | CeTA-CSR commit `e66a6da`; isolated Isabelle Code/export, production Haskell build, positive and two mutation-negative tests passed |
| `TRS_Standard/Secret_06_TRS/gen-25.ari` | `target/manual-probes/20260731-seven-certified-arctic3-regression-60s/gen25/proof.cpf3.xml` | Dedicated 3D natural-Arctic DP search with coefficient bound 3 and certified residual closure. | certified YES, 2x source replay | pending next oracle export | current default certified YES in about 4.2 s | pending recursive freeze | CeTA changes: none |
| `TRS_Standard/Secret_06_TRS/gen-18.ari` | `target/manual-probes/20260731-seven-certified-arctic3-regression-60s/gen18/proof.cpf3.xml` | Current default terminating proof; nested states will be frozen independently before promotion. | certified YES, 2x source replay | pending next oracle export | current default certified YES | pending recursive freeze | CeTA changes: none |
| `TRS_Standard/CiME_04/ternary-hard.ari` | `target/manual-probes/20260731-seven-certified-arctic3-regression-60s/ternary-hard/proof.cpf3.xml` | Current default terminating proof; nested states will be frozen independently before promotion. | certified YES, 2x source replay | pending next oracle export | current default certified YES | pending recursive freeze | CeTA changes: none |
| `TRS_Standard/CiME_04/ternary.ari` | `target/manual-probes/20260731-seven-certified-arctic3-regression-60s/ternary/proof.cpf3.xml` | Current default terminating proof; nested states will be frozen independently before promotion. | certified YES, 2x source replay | pending next oracle export | current default certified YES | pending recursive freeze | CeTA changes: none |
| `TRS_Standard/Transformed_CSR_04/Ex1_Luc02b_FR.ari` | `target/manual-probes/20260731-seven-certified-arctic3-regression-60s/ex1-fr/proof.cpf3.xml` | Current default terminating proof; nested states will be frozen independently before promotion. | certified YES, 2x source replay | pending next oracle export | current default certified YES | pending recursive freeze | CeTA changes: none |
| `TRS_Standard/Transformed_CSR_04/Ex7_BLR02_FR.ari` | `target/manual-probes/20260731-seven-certified-arctic3-regression-60s/ex7-fr/proof.cpf3.xml` | Current default terminating proof; nested states will be frozen independently before promotion. | certified YES, 2x source replay | pending next oracle export | current default certified YES | pending recursive freeze | CeTA changes: none |
| `TRS_Standard/Transformed_CSR_04/Ex2_Luc02a_GM.ari` | `target/manual-probes/20260731-ex2-default-quasiweak-certified-final/proof.cpf3.xml` | Quasi-RPO DP proof using induced weak equivalence and the full multiset extension. | certified YES, 2x source replay | pending next oracle export | current default certified YES | pending recursive freeze | CeTA changes: none |
| `TRS_Standard/Transformed_CSR_04/ExSec11_1_Luc02a_GM.ari` | `target/manual-probes/20260731-quasi-rpo-neighbor-replay-4x25s/exsec11/proof.cpf3.xml` | Current default quasi-RPO/DP proof with certified residual closure. | certified YES, 2x source replay | pending next oracle export | current default certified YES | pending recursive freeze | CeTA changes: none |
| `TRS_Standard/Transformed_CSR_04/LISTUTILITIES_nosorts-noand_FR.ari` | `target/manual-probes/20260731-next-seven-middle-default-60s/listutils-fr/proof.cpf3.xml` | Current default terminating proof; nested states will be frozen independently before promotion. | certified YES, 2x source replay | pending next oracle export | current default certified YES | pending recursive freeze | CeTA changes: none |
| `TRS_Standard/Transformed_CSR_04/LengthOfFiniteLists_complete_GM.ari` | `target/manual-probes/20260731-next-seven-middle-default-60s/length-gm/proof.cpf3.xml` | Current Standard terminating proof, retained separately from the earlier innermost evidence. | certified YES, 2x source replay | pending next oracle export | current default certified YES | pending recursive freeze | CeTA changes: none |
| `TRS_Standard/Waldmann_06/jwttt.ari` | `target/manual-probes/20260731-next-seven-middle-default-60s/jwttt/proof.cpf3.xml` | Current default terminating proof; nested states will be frozen independently before promotion. | certified YES, 2x source replay | pending next oracle export | current default certified YES | pending recursive freeze | CeTA changes: none |
| `TRS_Contextsensitive/CSR_04/Ex4_7_37_Bor03.ari` | direct proof: `target/manual-evidence-replay-v147-20260731/v275-csr-five-direct/Ex4_7_37_Bor03/proof.xml`; strict replay: `target/manual-evidence-replay-v147-20260731/v283-csr-five-strict/Ex4_7_37_Bor03/proof.xml` | Certified mixed marked/fresh-unhiding U3 reduction pairs; the live proof uses a complete independently replayable CSR route. | certified YES, 2x direct and strict replay | oracle v282 and later | strict oracle-only certified | passed; replay CPF certified 2x | CeTA-CSR mixed-U3 checker extension integrated; isolated Isabelle/export verification retained under `CeTA-CSR/target/codex-csr-ur-code-20260731` |
| `TRS_Contextsensitive/Maude_06/LengthOfFiniteLists_nosorts.ari` | direct proof: `target/manual-evidence-replay-v147-20260731/v275-csr-five-direct/LengthOfFiniteLists_nosorts/proof.xml`; strict replay: `target/manual-evidence-replay-v147-20260731/v283-csr-five-strict/LengthOfFiniteLists_nosorts/proof.xml` | Native replacement-map-respecting CSR loop. | certified NO, 2x direct and strict replay | oracle v282 and later | strict oracle-only certified NO | passed; replay CPF certified 2x | CeTA-CSR native CSR-loop checker and soundness proof integrated |
| `TRS_Contextsensitive/Maude_06/LengthOfFiniteLists_nosorts-noand.ari` | direct proof: `target/manual-evidence-replay-v147-20260731/v275-csr-five-direct/LengthOfFiniteLists_nosorts-noand/proof.xml`; strict replay: `target/manual-evidence-replay-v147-20260731/v283-csr-five-strict/LengthOfFiniteLists_nosorts-noand/proof.xml` | Native replacement-map-respecting CSR loop. | certified NO, 2x direct and strict replay | oracle v282 and later | strict oracle-only certified NO | passed; replay CPF certified 2x | CeTA-CSR native CSR-loop checker and soundness proof integrated |
| `TRS_Contextsensitive/Maude_06/OvConsOS_nosorts.ari` | direct proof: `target/manual-evidence-replay-v147-20260731/v275-csr-five-direct/OvConsOS_nosorts/proof.xml`; strict replay: `target/manual-evidence-replay-v147-20260731/v283-csr-five-strict/OvConsOS_nosorts/proof.xml` | Native replacement-map-respecting CSR loop. | certified NO, 2x direct and strict replay | oracle v282 and later | strict oracle-only certified NO | passed; replay CPF certified 2x | CeTA-CSR native CSR-loop checker and soundness proof integrated |
| `TRS_Contextsensitive/Maude_06/OvConsOS_nosorts-noand.ari` | direct proof: `target/manual-evidence-replay-v147-20260731/v275-csr-five-direct/OvConsOS_nosorts-noand/proof.xml`; strict replay: `target/manual-evidence-replay-v147-20260731/v283-csr-five-strict/OvConsOS_nosorts-noand/proof.xml` | Native replacement-map-respecting CSR loop. | certified NO, 2x direct and strict replay | oracle v282 and later | strict oracle-only certified NO | passed; replay CPF certified 2x | CeTA-CSR native CSR-loop checker and soundness proof integrated |
| `TRS_Contextsensitive/Transformed_outermost_08/f20.ari` | producing proof: `target/next-csr-19-direct-20260801/TRS_Contextsensitive/Transformed_outermost_08/f20/proof.cpf.xml`; recovered states: `target/manual-evidence-replay-v147-20260731/v328-csr-f20-recovery`; strict replay: `target/manual-evidence-replay-v147-20260731/v330-csr-f20-strict/proof.cpf.xml` | Context-sensitive matrix/polynomial rule removal followed by a complete CSR-DP continuation; the root recipe and all five materialized residual states are independently indexed. | certified YES, 2x producing, extraction, and strict replay | oracle v329 and later | direct 0.688 s; strict 1.521 s in the 19-root batch | passed strict oracle-only under 60 s; reconstructed CPF certified 2x | CeTA changes: none |
| `TRS_Contextsensitive/Maude_06/MYNAT_complete-noand.ari` | producing strict proof: `target/manual-evidence-replay-v147-20260731/v343-mynat-oracle-nested-after-cache-fix/proof.cpf.xml`; frozen states: `target/manual-evidence-replay-v147-20260731/v344-mynat-certified-overlay`; final strict replay: `target/manual-evidence-replay-v147-20260731/v346-mynat-v345-strict/proof.cpf.xml` | Safe CS-DPs followed by independently guided graph, SCT, usable-rule, and polynomial residual closures. CSR graph tcaps are precomputed per source/target and edge-cache misses are merged in one batch, removing quadratic cache bookkeeping without changing the edge criterion. | certified YES, producing and final replay both checked 2x | oracle v345 and later | strict 3.128 s | passed strict oracle-only with fallback disabled; reconstructed CPF certified 2x | CeTA changes: none |
| `TRS_Contextsensitive/Transformed_outermost_08/f30.ari` | producing proof: `target/smt-opt-category-20260731/csr-runs/TRS_Contextsensitive/Transformed_outermost_08/f30/proof.cpf.xml`; extracted states: `target/next-csr-f30-f40-oracle-20260801/events-native-ceta.jsonl`; final strict replay: `target/manual-evidence-replay-v147-20260731/v356-v355-final-gates/f30/proof.cpf.xml` | Complete certified CSR recipe supplied by window 3, rebased on the integrating thread's current oracle and independently gated again after the combined export. | certified YES, producing and strict replay 2x | oracle v355 and later | strict about 2 s | passed strict oracle-only with fallback disabled; reconstructed CPF certified 2x | CeTA changes: none |
| `TRS_Contextsensitive/Transformed_outermost_08/f40.ari` | producing proof: `target/smt-opt-category-20260731/csr-runs/TRS_Contextsensitive/Transformed_outermost_08/f40/proof.cpf.xml`; extracted states: `target/next-csr-f30-f40-oracle-20260801/events-native-ceta.jsonl`; final strict replay: `target/manual-evidence-replay-v147-20260731/v356-v355-final-gates/f40/proof.cpf.xml` | Complete certified CSR recipe supplied by window 3, rebased on the integrating thread's current oracle and independently gated again after the combined export. | certified YES, producing and strict replay 2x | oracle v355 and later | strict about 3.5 s | passed strict oracle-only with fallback disabled; reconstructed CPF certified 2x | CeTA changes: none |

The 2026-08-11 current-state audit rebased the retained
`MYNAT_complete-noand` proof once more.  The archived v450 CPF passed the
production checker twice, 51 recursive events were mapped to current runtime
states, and v843 strict oracle-only replay certified in under three seconds.
Together with fresh certified proofs for `MYNAT_complete-peanoSimple`,
`PALINDROME_complete`, and `morse`, this raises the complete strict CSR score
to 98/108 without fallback or checker failures.  Current artifacts are under
`target/csr-v842-mynat-complete-noand-20260811-*` and
`target/csr-strict-v843-mynat-recovered-20260811-*`.

## Processor-only certified evidence

The following evidence is retained for intermediate-state guidance but does not
claim that a named TermCOMP root has been solved.

| Evidence | Certified proof | What it establishes | Root status |
|---|---|---|---|
| Synthetic applicative-top DP uncurrying | `target/data-campaign/state-first-adaptive-20260729-132133/staged-dp-applicative-top-synthetic/TRS_Standard/Synthetic/dp-applicative-top/proof.cpf.xml` | CPF 3 `uncurryProc` with `applicativeTop`; transformed DP problem and continuation are accepted by CeTA-CSR | certified 2x; processor evidence only |

## Required final audit

For every row above, the final campaign audit must:

- resolve the original benchmark spelling (including `#` versus `sharp_`
  artifact names) to the expected canonical root state;
- assert that every typed proof-path child state is independently addressable
  in the final oracle; retaining only a root proof or reconstructable fragment
  does not satisfy this audit;
- run `fail` as the fallback strategy so an oracle miss cannot be hidden;
- check the reconstructed CPF twice with CeTA-CSR;
- run the new release default with no oracle, check its CPF twice, and record
  elapsed time and processor sequence; and
- leave a failure visible in this table rather than deleting the historical
  evidence entry.

### Latest full strict replay

The corrected 2026-07-30 v28b registry-wide replay ran all 64 registered roots
with `fail` as fallback. It produced 45 certified YES, 7 certified NO, and 12
Unknown. All 52 positive CPFs passed two independent CeTA-CSR invocations;
there were zero uncertified promoted results. The earlier v28 launcher attempt
passed a literal placeholder argument and is excluded from all counts.

After recursively freezing the newly exposed `factorial1`, Ex6_9, and JFP
states, strict coverage was 54/66. The subsequent three-row window-evidence
addition closes both IJCAR roots oracle-only while `Ex14_Luc06_GM` remains
open, bringing the strict count to 56/69. The next three transformed-CSR rows
add one strict closure, and `Zantema_05/z05` adds another, for a current count
of 58/73. Certified compound root actions then close the other two new
transformed-CSR rows, bringing that count to 60/73. The multi-instance additions
register five more roots; two CSR roots and `z07` close strictly, giving 63/78.
The window-1/window-3 integration registers four further roots. Three newly
certified compound actions (`z22`, `Ex4_7_15_Bor03_iGM`, and
`Ex4_7_56_Bor03_GM`) close with fallback disabled, giving 66/82. Their source
event logs yield 142 independently rechecked positive fragments across 89
distinct raw states; 142 certify twice and one additional attempted fragment
fails locally and remains unpromoted. The fourth,
`Ex4_7_56_Bor03_iGM`, remains registered but unpromoted because its previously
certified 6.9-second action now times out at the current shared release state.
Window 4 registers two additional LISTUTILITIES roots. Both close under strict
oracle guidance, raising the current count to 68/84. Its four traces contribute
25 further independently certified states. Forty-four isolated
LengthOfFiniteLists rule-removal outputs are open transitions rather than
proofs and remain unpromoted. The freezer and campaign runner now record these
only as exact typed, assembly-required transitions. A transition becomes
preferred evidence only after every child has an independently certified proof,
the children are substituted into the parent CPF, and the complete reconstructed
CPF is accepted twice by production CeTA-CSR.
Subsequent replay work has independently certified the currently exposed
residuals of both longer CSR ladders, which remain open pending further levels.
Ex6_9 adds twelve and JFP adds sixteen
certified independently addressable child states, but neither current root
chain closes under fallback-free guidance, so they are intentionally not
counted as strict root replays. The twelve still-open strict roots are:

- `CSR_04/Ex14_Luc06.ari`
- `CSR_04/Ex4_Zan97.ari`
- `Applicative_AG01_innermost/#4.26.ari`
- `Transformed_CSR_innermost_04/Ex49_GM04_GM.ari`
- `Endrullis_06/pair3hard.ari`
- `Mixed_TRS/7.ari`
- `Various_04/11.ari`
- `Waldmann_06/jwtpa1.ari`
- `Zantema_05/z01.ari`
- `Zantema_05/z19.ari`
- `Transformed_CSR_innermost_04/Ex6_9_Luc02c_iGM.ari`
- `AProVE_04/JFP_Ex31.ari`

Artifacts and the machine-readable summary are under
`target/data-campaign/state-first-adaptive-20260729-132133/manual-evidence-recursive-20260730/v28b-full-registry-strict`.

The current full TermCOMP 2025 CSR audit supersedes the older partial CSR
counts above. Oracle v94 was replayed over all 108
`TRS_Contextsensitive` inputs with `timeout(60s, fail)` and fallback disabled.
It produced 88 certified YES and 20 Unknown, with no timeout, checker failure,
or uncertified promotion. This monotonically preserves all 75 v83 closures and
adds thirteen: `Ex14_Luc06`, `Ex1_2_AEL03`, `Ex2_Luc02a`, `Ex4_Zan97`,
`Ex8_BLR02`, `Ex9_Luc06`, the three `MYNAT_*_noand` variants,
`PALINDROME_complete-noand`, `cariboo_ex3`, `Ex7_BLR02`, and
`ExSec4_2_DLMMU04`. All 88 CPFs passed two additional deterministic production
CeTA-CSR checks. The retained audit is:

`target/data-campaign/state-first-adaptive-20260729-132133/csr/final-oracle-only-v94-108-60s`

All 29 manually documented native `TRS_Contextsensitive` roots occur in those
88 certified results. There are therefore no manually evidenced native CSR
roots outside the accepted strict set; the remaining 20 are campaign/search
gaps rather than dropped manual integrations.

The v156 current-code audit restores this 88/108 result after two temporary
replay regressions in `Ex14_Luc06` and `MYNAT_complete-noand`.  CSR processor
events now serialize a parameterized DP strategy in Ferrum's executable parser
language instead of Rust debug syntax, and dataset normalization preserves the
structured atom instead of changing spaces into hyphens.  The independently
certified root actions are a polynomial removal followed by the exact DP
continuation for `Ex14_Luc06`, and that exact DP continuation directly for
`MYNAT_complete-noand`.  Both producing CPFs and both strict oracle-only replay
CPFs passed production CeTA-CSR twice.  The full replay again reports 88
certified YES, 20 Unknown, and zero checker failures:

`target/manual-evidence-replay-v147-20260731/strict-v156-csr108`

The v157 registry-wide audit resolves 179 unique manually evidenced roots:
72 Standard, 78 Innermost, and 29 context-sensitive.  The manifest builder now
deduplicates repeated documentation rows while merging their artifact paths;
the prior raw count of 180 counted `factorial1` twice.  Strict replay certifies
153/179 roots: 62/72 Standard, 62/78 Innermost, and 29/29 CSR.  There are zero
checker failures.  Oracle v157 also includes the newly certified
`Various_04/13`, `AProVE_07/kabasci04`, and `AProVE_07/wiehe01`, `wiehe02`,
`wiehe03`, and `wiehe05`; their focused strict replay is 6/6 certified.

`target/manual-evidence-replay-v147-20260731/strict-v157-full-manual180`

The corrected registry-wide v98 audit includes all 133 currently documented
manual roots. The manifest builder now emits the category required by
`--from-details`; its previous omission silently selected zero roots. With
`timeout(60s, fail)`, v98 strictly replays 111/133 roots: 24/35 Standard,
58/69 Innermost, and 29/29 Context-sensitive. Every positive result is
CeTA-CSR certified and all 111 retained CPFs passed two additional
deterministic production checks, with zero certification failures. The remaining 21
Unknown and one timeout divide exactly into:

- ten root lookup/alias gaps with no executable positive root action;
- six roots with only a transformation fragment and no complete promoted
  recursive continuation; and
- six roots whose retained root atom is marked solved but reruns search and
  fails to reproduce the original witness or sequence under the current
  runtime and load.

The full audit is retained under
`target/manual-evidence-replay-v98-20260731`.

The strongest currently exported oracle containing all manual evidence plus the
certified frontier is v161. Since v98 it adds the window-1 relative DP-loop
batch, `jwteparla2`, both `PEANO_nokinds` variants,
`PALINDROME_complete_GM`, `pair2simple2`, the AG01 `#3.19`, `#3.22`, and
`#3.40` proofs, the exact-Q/R CSR recovery frontier, CSR campaign round 3, and
the mixed-loop proofs for `Strategy_removed_AG01/#4.12a` and `#4.4`, the
refreshed `pair2hard` chain, live recursive residual coverage for `linear2`
and `pair3swap`, the first transformed-CSR adaptive-round union, `teparla1`,
and the current component-level `switchInnermostProc` proof for `aprove4`, the
second transformed-CSR adaptive-round union, the dual-category AG01 `#4.26`
proofs, `z25`, `SK90/4.02`, `pair2simple1`, `kabasci05`, `tower`, and
`factorial1`. Round 2 contributed 1,478 unique proofs checked twice and 2,694
promoted certified evidence rows; eleven malformed
unmarked-DP loop CPFs were excluded from the original ledger and overlaid only
after their corrected CPFs passed CeTA-CSR twice. The
extractor now distinguishes the executable
nontermination atom `nontermination(dp-loop)` from terminating `dp`.
Ferrum-runtime canonical aliases are produced by the same canonicalizer used
for live lookup; this replaced benchmark-path root aliases for ordinary TRS
and DP states. In the focused eleven-root audit, ten roots replay strictly
under 60 seconds and all ten reconstructed CPFs certify twice.
`PALINDROME_complete_GM` replays oracle-only and certifies twice in 73 seconds
under the deliberately lenient 90-second audit, so it is replayable but remains
an efficiency miss for the 60-second campaign ceiling. These additions do not
change the last accepted 88/108 full native-CSR count or the 29/29 manually
evidenced native-CSR count:

`target/data-campaign/state-first-adaptive-20260731-transformed-csr-v115/rounds/oracle-global-v161-r03.jsonl`

Current SHA-256:

`8361fe5997435e466a3da53e543490b0006e3e34e21a442a8934af3af20feb9b`

Update that pointer after every manual-evidence export and again when the final
frozen certified union is produced.

## External evidence for the 20-root native-CSR frontier

The TermCOMP 2025 primary result corpus supplies usable proof evidence for 13
of the 20 roots left open by the v161 strict replay.  These rows are scheduling
hints only until Ferrum emits a complete CPF accepted by CeTA-CSR; no external
YES or NO is promoted directly.

- `CSR_04/Ex1_GM03`, `CSR_04/ExIntrod_Zan97`, and `Maude_06/emmes` use
  MU-TERM's orthogonal CSR-to-innermost-CSR switch followed by dependency
  pairs.  The retained competition proofs are benchmarks 10, 50, and 55,
  solver 2, in TermCOMP job `60792768`.

`CSR_04/Ex1_GM03` is now complete and production-certified. Ferrum's default
strategy keeps the five native typed pairs at the root, decomposes them with
the typed graph estimator, and proves the collapsing component with the exact
extended-basic usable-rule boundary plus both unhiding bridges. Every nested
state is explicit; there is no assumption fragment or whole-proof replay.
The final artifact is
`target/csr-ex1-gm03-production-certified-v26-20260820/proof.cpf.xml` (SHA-256
`1823f399dbd69a8f5e45f7b0309b602a566cdf01e0050fad0371fe1f6dfce5de`).
Default release runtime was 6.092 seconds, and the freshly exported CeTA-CSR
checker accepted the CPF twice in 0.031 and 0.012 seconds. This evidence is
eligible for promotion into the monotone oracle.

The 2026-08-16 production audit additionally established that this is not a
mere parser or closure-computation omission. Exact U3 adds the recursive
`diff` rule and both `if` rules, which the retained model cannot orient. The
five-rule component is also inapplicable under the basic innermost usable-rule
theorem because its false-branch pair is not context-sensitively conservative.
The preserved MU-TERM output and Ferrum reconstruction remain useful search
guidance, but promotion now explicitly requires either a conservative
narrowed residual chain or a separately proved typed collapsing theorem.

The complete MU-TERM output was recovered again on 2026-08-18 from TermCOMP
job `60792768`, benchmark 10, solver 2.  Its exact continuation after the
orthogonality switch is: five native MU-TERM pairs and two unhiding rules;
graph decomposition; projection of the `LEQ` singleton; the retained rational
linear interpretation over the five `leq`/`p` rules; graph decomposition; and
the retained natural linear interpretation over the same five rules.  Ferrum
reconstructs that chain in under one second.  A focused serialization probe at
`target/csr-ex1-gm03-expanded-usable-production-20260818/proof.cpf.xml`
confirmed the old checker boundary: the five-rule closure succeeded, but the
expanded-innermost wrapper rejected the non-conservative false collapsing
target. The production extension now lifts the proved step-local invariant to
the restricted recursive reduction-pair checker; U3 was not weakened and the
target condition was not deleted.
- `Maude_06/csrdiv` uses the same switch followed by QCS-DPs, dependency
  graphs, reduction pairs, instantiation, and subterm closure (benchmark 54,
  solver 1).  A direct 60-second Ferrum probe currently overruns its deadline,
  so this is also a cancellation/performance regression target.
- `Maude_06/LISTUTILITIES_complete-noand` and
  `Maude_06/LISTUTILITIES_nokinds-noand` use QCS-DPs, graph decomposition,
  QCS usable rules, mu-monotonic polynomials, and subterm closure (benchmarks
  63 and 65, solver 1).
- `Maude_06/LengthOfFiniteLists_complete` first performs six CSR rule-removal
  steps and then uses the Giesl--Middeldorp transformation and ordinary QDP
  orders (benchmark 56, solver 1).  `LengthOfFiniteLists_nokinds` uses four CSR
  rule removals, the orthogonal switch, QCS-DPs, usable rules, a mu-monotonic
  polynomial, and a reduction pair (benchmark 58, solver 1).
- `Maude_06/LengthOfFiniteLists_nosorts`,
  `LengthOfFiniteLists_nosorts-noand`, `OvConsOS_nosorts`, and
  `OvConsOS_nosorts-noand` are certified NO externally after zero to three CSR
  rule-removal steps and a context-sensitive loop (benchmarks 60, 61, 84, and
  85, solver 1).  Ferrum and the verified CeTA-CSR checker now find, export,
  and certify all four loops directly.
- `CSR_04/Ex4_7_37_Bor03` has both AProVE and MU-TERM YES evidence.  Ferrum's
  mixed marked/fresh-unhiding U3 proof is accepted by the newly verified
  CeTA-CSR checker; the live alternate route remains preferred when it also
  passes the production checker.

The other seven roots have no TermCOMP 2025 VBS closure:
`Ex3_2_Luc97`, `Ex5_7_Luc97`, `Ex6_15_AEL02`, `LISTUTILITIES_complete`,
`LISTUTILITIES_nokinds`, `OvConsOS_complete`, and `OvConsOS_nokinds`.
`Ex3_2_Luc97` remains the motivating case for the separately represented
orthogonal CSR-to-innermost-CSR processor; the invalid shortcut that silently
weakened full-CSR U3 obligations stays removed.

Machine outputs for the local extraction attempt are retained under
`target/manual-evidence-replay-v147-20260731/v266-csr20-external-evidence`.
The fourteen selected primary proof texts (both available Ex4 witnesses and
one witness for each of the other twelve externally closed roots), their result
rows, and checksums are retained below that directory in
`termcomp-2025-job-60792768` so this evidence does not depend on the temporary
TermCOMP checkout.
The generic proof database currently indexes zero of these CSR proofs, which is
why this targeted primary-corpus recovery was necessary.

### 2026-08-11 RTA08 replay boundary

The committed source-restricted innermost-RTA08 route reconstructs the exact
seven-pair root problem for `CSR_04/ExIntrod_Zan97`, but its certified terminal
reduction-pair theorem deliberately checks the source rules, projection rules,
and marking rules.  MU-TERM's retained proof uses a stronger framework: three
specialized unhiding rules allow its hard three-pair component to keep only the
`p` and `zero` source rules.  Its first rational quadratic witness is therefore
valid for the retained MU-TERM problem but is not a witness for Ferrum's
stronger current RTA08 obligation.  The focused regression
`exintrod_rta08_external_quadratic_witness_needs_certified_usable_rules`
prevents that distinction from being lost again.

Ferrum commit `5673bfa` adds the independently rechecked atomic strategy form
`exact-rat-natural-poly(...)`.  Rational degree-two witnesses now round-trip
through processor events and can be looked up on residual states without
replaying an enclosing proof.  Completing `ExIntrod_Zan97` still requires a
mechanized specialized-unhiding/usable-rule processor; the exact witness atom
does not weaken the existing checker boundary.

The same audit found that `CSR_04/Ex3_2_Luc97` reaches the singleton residual
`SEL(s(x),cons(y,z)) -> SEL(x,z)`.  Its second active target argument is below
the frozen `cons` argument in the source.  Consequently the residual does not
satisfy the verified source-coverage premise for promoting ordinary minimal
SCT to the innermost-CSR mode.  This is a processor-theorem gap, not a timeout
or an oracle lookup miss.

## 2026-08-01 complete CSR recipes and strict 108-root replay

The oracle integration defect that kept the native CSR score oscillating
between 85 and 88 has been fixed.  A successful top-level CSR `Sequence` now
emits one executable parent recipe against the original state while retaining
every residual processor event under its own canonical state key.  Dataset
normalization preserves the complete parser-language composition, dataset
aliases are exported automatically, local utility guidance remains enabled
with `--no-top-level-llm`, and the 60-second replay allowance applies to the
whole composed recipe rather than only its first processor.

The new parameterized form `csr-safe-dp(<dp strategy>)` records the certified
continuation explicitly.  This recovers three complete root-to-terminal
recipes that were previously split into non-executable fragments:

- `PALINDROME_complete-noand`: 2D matrix rule removal followed by safe CS-DPs;
- `PALINDROME_complete`: the same complete parent-to-child shape; and
- `MYNAT_complete-peanoSimple`: safe CS-DPs followed by the exact graph,
  size-change, polynomial, and final graph continuation.

All three direct proofs and strict oracle-only reconstructions were checked
twice by CeTA-CSR.  The strongest monotone oracle is:

`target/manual-evidence-replay-v147-20260731/oracle-global-v355-standard-three-f30-f40.jsonl`

The corresponding full TermCOMP 2025 native-CSR replay uses fallback `fail`,
`--no-top-level-llm`, and the 60-second proof ceiling.  The v314 baseline plus
the v331 unresolved-root replay plus the v346 MYNAT and v356 f30/f40 strict
replays reports **93/108 certified oracle-only decisions**: 89 YES, 4 NO, 15
MAYBE, no runtime error, and no certification failure. All three newly closed
CSR proofs are below 60 seconds; all retained positive proofs are certified.
Artifacts are retained at:

`target/manual-evidence-replay-v147-20260731/v314-csr108-strict-complete-recipes`

`target/manual-evidence-replay-v147-20260731/v331-csr19-strict-f20`

`target/manual-evidence-replay-v147-20260731/v346-mynat-v345-strict`

`target/manual-evidence-replay-v147-20260731/v356-v355-final-gates`

The manual native-CSR registry contains 36 unique roots and all 36 are covered
by certified strict replay evidence.  Thus the remaining 18 roots are search
or missing-processor gaps, not lost manual integrations.

## 2026-08-01 cime5, kabasci03, and applicative #3.40

Three newly certified Standard roots are integrated into the monotone oracle:

- `Secret_05_TRS/cime5.ari`: repeated linear DP deletion;
- `AProVE_07/kabasci03.ari`: denominator-64 rational DP orders; and
- `Applicative_first_order_05/#3.40.ari`: uncurrying followed by a recursively
  guided DP proof.

The source CPFs were extracted at
`target/manual-evidence-replay-v147-20260731/v377-standard-three-extraction`.
For `#3.40`, strict replay exposed two integration defects: uncurrying erased
guidance before its transformed TRS, and dataset aliases omitted Ferrum's
formatting-insensitive structural XML key.  Both are fixed.  A fresh current-
state proof was recovered in 1.9 seconds and checked twice by CeTA-CSR at
`target/manual-evidence-replay-v147-20260731/v387-app340-current-uncurry-refind`;
its complete live state closure is frozen at
`target/manual-evidence-replay-v147-20260731/v394-app340-live-state-closure`.

All three roots replay with fallback `fail`, no top-level LLM, and a 60-second
ceiling against
`target/manual-evidence-replay-v147-20260731/oracle-global-v395-standard-three-app340-live-closure.jsonl`.
The final cime5 and kabasci03 replays are under
`target/manual-evidence-replay-v147-20260731/v397-standard-three-final-strict`;
the final `#3.40` replay is under
`target/manual-evidence-replay-v147-20260731/v396-standard-app340-strict-live-closure`.
Every resulting CPF was accepted twice by production CeTA-CSR.

## 2026-08-01 MNZ integer-matrix family

Eight `TRS_Standard/MNZ_10` roots are retained as default-strategy,
CeTA-CSR-certified YES evidence: `0`, `1`, `2`, `3`, `5`, `7`, `8`, and `9`.
The proofs exercise ordinary signed integer-matrix DP reduction pairs and the
corrected weak-polynomial affine semantics; six of the eight use integer
matrices.  Roots `4` and `6` remain timeouts and are not promoted.

The complete proof, processor-event, stdout, timing, and checker artifacts are
under:

`target/manual-probes/20260801-mnz10-default-family`

All eight retained CPFs report `CERTIFIED` with the production
`CeTA-CSR/ceta`; an additional direct replay of root `0` was also certified.
No CeTA or dependency-graph change was required for this batch.

## 2026-08-01 Applicative first-order 13

`TRS_Standard/Applicative_first_order_05/13.ari` is integrated as eight exact
root/residual events and eight Ferrum-runtime canonical aliases.  Its proof is
`uncurry`, dependency pairs and graph decomposition, quadratic-polynomial
deletion, size change, and symbol weights.  The source proof and every
promoted state were recovered from:

`target/manual-probes/20260801-applicative-first-order-13-default`

The source CPF and the strict oracle-only reconstructed CPF were each checked
twice by CeTA-CSR.  The monotone oracle and strict replay are:

`target/data-campaign/state-first-adaptive-20260801-standard-789-integration/oracle-global-v405-applicative-first-order-13.jsonl`

`target/data-campaign/state-first-adaptive-20260801-standard-789-integration/v405-applicative-first-order-13/strict-replay-direct`

The export contains 246,647 exact/alias records, rejected no positive
evidence, and has SHA-256
`c804a296c3281bc7114dea7e422f085d39c0c0b459fac5b963cf6c6d8c07e106`.

The current isolated Ferrum replay over the 789-root Standard integration set
certifies 603 YES and 162 NO within 60 seconds, with no checker failures:

`target/data-campaign/state-first-adaptive-20260801-standard-789-integration/full-strict-replay-v405-current`

A fallback-disabled 300-second replay of the 24-root tail certifies seven more
YES results, leaving eight MAYBEs and nine timeouts.  Thus 772/789 roots are
currently oracle-only replayable; 765/789 meet the 60-second efficiency bound
in this loaded run.  The lenient artifacts are:

`target/data-campaign/state-first-adaptive-20260801-standard-789-integration/lenient-replay-v405-unresolved`

## 2026-08-01 newest-checker CSR replay correction

The earlier 93/108 CSR projection above combined results from several replay
shards checked by an older checker and did not disable the DP engine's local
fallback in every shard.  A fresh 108-root audit with the newest isolated
CeTA-CSR union exposed both issues.  It must not be quoted as current strict
coverage.

The integration pipeline now supports auditable current-checker invalidation.
Exact rejected root/canonical keys are removed before merging twice-certified
replacement evidence.  When no replacement exists, an explicit negative
tombstone prevents structural or canonical aliases from resurrecting the
rejected positive.  Ferrum's utility lookup honors that tombstone before
canonical merging.

Five recovered roots (`Ex1_2_Luc02c`, `Ex4_7_56_Bor03`,
`MYNAT_nosorts-noand-peanoSimple`, `Transformed_outermost_08/ex5.4`, and
`Transformed_outermost_08/f20`) replay strict oracle-only and certify 5/5 with
the newest checker.  The MYNAT proof uses the deterministic focused recipe
`dp(graph;poly(1,1);poly(2,2))`, replacing a scheduler-sensitive broad DP
portfolio.

Artifacts:

- corrected oracle: `target/data-campaign/state-first-adaptive-20260801-standard-789-integration/oracle-global-v414-current-checker-clean.jsonl`;
- five-root strict gate: `target/data-campaign/state-first-adaptive-20260801-standard-789-integration/csr-five-recovered-v407/strict-v409`;
- end-to-end strict 108-root replay: `target/data-campaign/state-first-adaptive-20260801-standard-789-integration/csr108-strict-v414`.

With top-level fallback set to `fail` and
`FERRUM_DP_LLM_NO_FALLBACK=1`, the fresh full replay has 79 certified YES, 4
certified NO, 25 MAYBE, and zero timeouts, errors, or checker failures.  The
current strict score is therefore **83/108 certified decisions**.  The
remaining work is
state-chain coverage and missing processor power, not permission to count raw
YES output.

### Recursive-state integration and QCS export correction

The CPF evidence extractor now attaches exact runtime-state aliases at every
nested proof state while preserving the TRS, dependency pairs, Q/minimality,
and CSR replacement map.  Certified size-change and subterm proofs are also
materialized for matching runtime SCC subsets; these processors are
downward-closed in the dependency-pair set.  This repairs strict replay when
the recorded CPF contains one global proof but the live engine eagerly
decomposes the same state into singleton SCCs.

This recovered strict, newest-checker replays for `ExAppendixB_AEL03`,
`ExSec11_1_Luc02a`, and `MYNAT_nokinds-peanoSimple`.

A second defect was in Ferrum's CPF output for QCS usable rules: internal proof
validation used the certificate-grade QCS closure, but serialization
recomputed a weaker search-oriented closure.  CPF output now uses the same
certificate-grade closure as validation.  Fresh proofs for
`Transformed_outermost_08/{cariboo_ex1,cariboo_ex3,f4}` certify with the newest
CeTA-CSR and replay with both top-level and DP fallback disabled.

Current artifacts:

- oracle: `target/data-campaign/state-first-adaptive-20260801-standard-789-integration/oracle-global-v423-qcs-export-three.jsonl` (SHA-256 `72eb539b813ca1a4377493fa0bd298eecbcae35824dcccc2a253010584ec070b`);
- QCS source replay: `target/data-campaign/state-first-adaptive-20260801-standard-789-integration/csr-qcs-export-three-v421`;
- QCS strict gate: `target/data-campaign/state-first-adaptive-20260801-standard-789-integration/csr-qcs-export-three-strict-v423`;
- end-to-end strict replay: `target/data-campaign/state-first-adaptive-20260801-standard-789-integration/csr108-strict-v423`.

The v423 full replay has 85 certified YES, 4 certified NO, 19 MAYBE, and zero
timeouts, errors, or checker failures.  The current strict CSR score is thus
**89/108 certified decisions**.

The subsequent `Ex6_15_AEL02` audit found that projection subterm proofs were
not applying CeTA-CSR's active-subterm restriction.  Ferrum now rejects frozen
marked-argument projections unless they are the exact improved-CS-DP unhiding
case.  The formerly positive-looking `Ex6_15_AEL02` route consequently returns
MAYBE instead of producing a rejected CPF.  Valid active and improved-unhiding
subterm regressions still pass.  The full strict replay with this stronger
boundary retains all 89 certified decisions and has no checker failures:

`target/data-campaign/state-first-adaptive-20260801-standard-789-integration/csr108-strict-v428-subterm-boundary`

This historical MAYBE was resolved on 2026-08-22 without weakening that
active-subterm restriction. Inspection of the final four-pair SCC showed that
one bridge pair obstructed an otherwise valid active projection. A certified
3-dimensional natural Arctic U3 reduction pair deletes precisely that bridge;
the remaining three pairs then close by an active subterm projection. Ferrum
now serializes the nonterminal U3 step as recursive `csrRedPairUrProc`, keeping
the minimal CSR-DP obligation for its child. The direct and strict-oracle CPFs
were each accepted twice by production CeTA-CSR. Evidence, extracted nested
states, v993 oracle, and complete 104/108 replay are under
`target/csr-ex6-oracle-integration-20260822`; no CeTA-CSR change was required.

The next 18-root sweep (excluding window 3's claimed `Ex3_2_Luc97`) recovered
`Maude_06/MYNAT_complete` in 9.1 seconds.  Its complete proof was checked twice,
its recursive states were exported, and a fallback-disabled strict replay
certified from oracle guidance alone.  The resulting oracle is
`target/data-campaign/state-first-adaptive-20260801-standard-789-integration/oracle-global-v431-mynat-complete.jsonl`
(SHA-256 `a3110fb9b92c9fe0ee583d9666e494d2089557f1d45ef1673a692fa3e5498c63`).
The authoritative full replay at
`target/data-campaign/state-first-adaptive-20260801-standard-789-integration/csr108-strict-v431`
has 86 certified YES, 4 certified NO, and 18 MAYBE, raising strict CSR coverage
to **90/108** with no timeouts, errors, or checker failures.

### Native GM CSR transformation and v432 strict replay

`Maude_06/LengthOfFiniteLists_complete` now has a self-contained native CPF
proof for the Giesl--Middeldorp CSR-to-TRS transformation.  CeTA-CSR
recomputes the transformed TRS from the original rules, replacement map, mark
symbol, ground constant, and complete defined-to-active symbol mapping; it
then checks the nested ordinary TRS termination proof with assumptions
disabled.  The generated checker certified the focused proof twice and
rejected mutations of both the ground constant and active-symbol mapping.

The certified recipe
`csr-gm-transform(graph;poly(max-constant=2,max-coefficient=2);graph;size-change;subterm)`
was promoted through the certification-gated state-first pipeline.  A fresh
fallback-disabled strict replay solved and certified the root in under two
seconds, and its CPF was independently checked twice.

Artifacts:

- oracle: `target/data-campaign/state-first-adaptive-20260801-standard-789-integration/oracle-global-v432-csr-gm-length.jsonl` (SHA-256 `fb6ba5f004c8a57f632dda0c167bbba897e87ab326f6bcbda13744ac3ca431f0`);
- evidence and mutation gates: `target/data-campaign/state-first-adaptive-20260801-standard-789-integration/v432-csr-gm-length`;
- full strict replay: `target/data-campaign/state-first-adaptive-20260801-standard-789-integration/csr108-strict-v432`.

The authoritative v432 replay has 87 certified YES, 4 certified NO, and 17
MAYBE: **91/108 strict oracle-only certified decisions**, with zero timeouts,
errors, or checker failures.

The 2026-08-11 audit recovered the same GM recipe into the compact v838
oracle.  Plain semicolon recipes retain their historical recursive-portfolio
meaning, distinct from the state-advancing `pipeline(...)` used by csrdiv.
The fresh fallback-disabled replay completed in 5.8 seconds and
`target/length-complete-integration-20260811/strict-v838-final.cpf.xml` passed
the production checker twice.  The directory also contains the six-row
certification manifest, credited database, and monotone v838 export.

### OvConsOS complete-noand recovery and v433

The post-integration recovery sweep produced a fresh complete proof for
`Maude_06/OvConsOS_complete-noand`.  Production CeTA-CSR accepted the source
CPF twice.  Ten root/residual events were extracted, all positive evidence was
certification-gated, and the resulting v433 oracle contains no uncertified
positive rows.  A fresh replay with top-level fallback and DP fallback both
disabled reconstructed the complete proof in 6.8 seconds; CeTA-CSR accepted
that CPF twice.

Artifacts:

- oracle: `target/data-campaign/state-first-adaptive-20260801-standard-789-integration/oracle-global-v433-ovcons-complete-noand.jsonl` (SHA-256 `4bbacffaa6cd3c06da39db870c4ede1ad75cd9cf3b5be7d10a1095ec4972172b`);
- evidence, credited database, and strict replay: `target/data-campaign/state-first-adaptive-20260801-standard-789-integration/v433-ovcons-complete-noand`;
- committed-state 17-root recovery sweep: `target/data-campaign/state-first-adaptive-20260801-standard-789-integration/csr17-recovery-committed-v432`.

This projects strict CSR coverage to **92/108** (88 YES and 4 NO) pending the
next complete 108-root replay.  The same sweep exposed two uncertified MYNAT
positives that partially deleted improved-CS-DPs with `subtermProc`.  Ferrum
now refuses that runtime/CPF mismatch: only a complete improved-CS-DP
projection closure, which the exporter converts to the verified CSR
size-change processor, may be promoted.

### Monotone MYNAT recovery and v434

The cleanup audit found that `Maude_06/MYNAT_complete-noand` had a retained
twice-certified strict proof, but a later root-key invalidation had replaced
all of its positive guidance with failed observations.  The oracle merge and
state-first export paths now reconcile candidates across all four buckets:
once a `(state, candidate)` has certified solved evidence, later failures can
increase its failure count but cannot demote it from `prefer`.

Replaying the restored recipe exposed a second runtime/CPF mismatch.  A
monotone interpretation below improved CS-DPs was serialized as CPF's ordinary
`monoRedPairUrProc`, whose minimality premise is not supplied by the improved
framework.  Ferrum continues to use the verified CSR U3 extension there, but
only through its certified non-monotone `redPairUrProc` form; incompatible
monotone U3 candidates are rejected before proof construction.  The final
fallback-disabled replay finished in 22 seconds and production CeTA-CSR
certified it.

Artifacts:

- oracle: `target/data-campaign/state-first-adaptive-20260801-standard-789-integration/oracle-global-v434-monotone-mynat-restored.jsonl` (SHA-256 `a97878a4e7ecbd28a28e4df4ea6a8bec34acdf298ee57a5986c8633fc02908de`);
- strict replay: `target/data-campaign/state-first-adaptive-20260801-standard-789-integration/mynat-strict-v434-final`;
- pre-fix negative controls: `target/data-campaign/state-first-adaptive-20260801-standard-789-integration/mynat-soundness-rerun-v433` and `mynat-strict-v434-u3-fixed`.

The projected strict score is now **93/108** (89 YES and 4 NO), pending the
complete 108-root v434 replay.

The complete v434 replay instead measured **92/108** (88 YES and 4 NO): both
MYNAT and OvConsOS gains were present, but `CSR_04/ExAppendixB_AEL03` exposed a
model-dependent U3 serialization regression.  Ferrum's proof object now
records when an otherwise monotone interpretation must remain in the verified
non-monotone CSR U3 processor, so runtime residual handling and CPF output use
the same boundary.  It also records whether an ordinary reduction-pair node
has already been emitted: U3 may begin an ordinary proof below the CSR wrapper,
but cannot be introduced later where the generic CPF recursion would lose the
CSR-minimal context.  A fresh default proof was checked twice, extracted into
v435, and then replayed with fallback disabled in one second.  A focused
two-root replay of ExAppendixB and MYNAT then produced two certified YESs with
zero checker failures.

- authoritative v434 replay: `target/data-campaign/state-first-adaptive-20260801-standard-789-integration/csr108-strict-v434`;
- v435 oracle: `target/data-campaign/state-first-adaptive-20260801-standard-789-integration/oracle-global-v435-exappendixb-explicit-u3.jsonl` (SHA-256 `b89c70d2bc7b127013c1b73024220c64d90e80746d42689dc12e9fce9e75aeef`);
- v435 certification-gated evidence: `target/data-campaign/state-first-adaptive-20260801-standard-789-integration/v435-exappendixb-explicit-u3`;
- v435 strict replay: `target/data-campaign/state-first-adaptive-20260801-standard-789-integration/exappendixb-strict-v435`.
- focused U3-boundary replay: `target/data-campaign/state-first-adaptive-20260801-standard-789-integration/u3-boundary-two-strict-v435`.

The final complete v435 replay confirms **93/108 strict oracle-only certified
decisions**: 89 YES, 4 NO, 15 MAYBE, zero timeouts, zero errors, and zero
checker failures.  Its artifacts are in
`target/data-campaign/state-first-adaptive-20260801-standard-789-integration/csr108-strict-v435-final`.

### Current-runtime Standard recanonicalization and v438

The first current-runtime replay of the 789-root Standard evidence set exposed
an integration regression: v435 retained the CSR additions but recovered only
672 certified decisions (510 YES and 162 NO), whereas the earlier v405 run had
765 twice-certified decisions.  Every one of the 765 retained CPFs was checked
twice with the current production CeTA-CSR; none was rejected.  Re-extracting
those CPFs and canonicalizing their states with the current Ferrum binary
produced v437 and restored 725 strict decisions (563 YES and 162 NO), with zero
checker failures.

The remaining losses are not all stale aliases.  For example, the retained
`AG01/#3.37` polynomial witness deletes thirteen pairs at once, while current
bounded synthesis selects a different valid model that deletes ten and reaches
a different residual.  This establishes the remaining architectural gap:
processor names and bounds do not uniquely identify solver witnesses.  Full
direct replay therefore needs certified witness-aware oracle actions, with the
resulting residual states still looked up independently.

An additional current-default sweep over the 64 unresolved v437 roots found
seven certified results.  After certification-gated extraction, v438 strictly
recovers three of them within the 60-second prover allowance.  The complete
v438 measurements are:

- Standard: **728/789 strict oracle-only certified decisions** (566 YES,
  162 NO, 52 MAYBE, 9 timeouts, zero errors or checker failures);
- CSR: **93/108 strict oracle-only certified decisions** (89 YES, 4 NO,
  15 MAYBE, zero timeouts, errors, or checker failures).

Artifacts:

- v437 oracle: `target/data-campaign/state-first-adaptive-20260801-standard-789-integration/oracle-global-v437-recanonicalized-standard765.jsonl`;
- v438 oracle: `target/data-campaign/state-first-adaptive-20260801-standard-789-integration/oracle-global-v438-standard-current-recoveries.jsonl` (SHA-256 `c8014be197095f28d608c9b2607552553b5729149f1ce3d99af0bf29491ea5b5`);
- twice-certified source events: `target/data-campaign/state-first-adaptive-20260801-standard-789-integration/standard-v405-recanonicalized/events-ceta-twice.jsonl`;
- final Standard replay: `target/data-campaign/state-first-adaptive-20260801-standard-789-integration/standard789-strict-v438-final`;
- final CSR replay: `target/data-campaign/state-first-adaptive-20260801-standard-789-integration/csr108-strict-v438-final`.

The CPF extractor now accepts repeatable `--runtime-root` inputs.  It adds a
current raw-state alias only when canonical structure proves equality; it does
not alias structurally different residuals merely because they belong to the
same root or processor family.

### Exact polynomial actions, correct residuals, and v442

The next replay pass fixed two integration defects rather than adding a
whole-proof playback mechanism.  First, CPF `ruleRemoval/trs` contains the
strictly removed rules; the extractor had treated that payload as the child
TRS.  Child states are now the actual set difference between the current TRS
and those rules.  Second, a strong raw or whitespace-independent structural
oracle hit is now used before attempting semantic canonicalization.  This
avoids an exponential canonicalization path on large symmetric residuals
without weakening canonical fallback on a genuine raw miss.

Ferrum now accepts an `exact-poly(hex=...)` action at both top-level and DP
states.  The encoded affine natural interpretation is independently checked
against the live state, performs exactly one rule-removal step, and then makes
a fresh oracle lookup for the residual.  It is therefore witness replay, not
whole-proof replay.  The source extractor emits such actions only for direct,
degree-one natural interpretations and refuses rational, nonlinear,
negative, malformed, or nested-continuation models.  Promotion to strong
guidance additionally requires the exact state/action pair in the manifest of
source CPFs checked twice by the current production CeTA-CSR.

All 765 retained Standard CPFs were checked twice while building v442.  The
final full strict replays, with top-level and DP fallback disabled, report:

- Standard: **742/789 certified decisions** (578 YES, 164 NO, 40 MAYBE,
  7 timeouts, zero errors or checker failures), a net gain of fourteen roots
  over v438 with no losses;
- CSR: **93/108 certified decisions** (89 YES, 4 NO, 15 MAYBE, zero timeouts,
  errors, or checker failures).

Artifacts:

- oracle: `target/data-campaign/state-first-adaptive-20260801-standard-789-integration/oracle-global-v442-correct-residual-standard765.jsonl` (SHA-256 `f6d51cabf3f64f1445ff4d2f4fe253cc35506428b33b800f1d8066c2cac0ba7b`);
- twice-checked extraction, credited database, and deterministic manifest:
  `target/data-campaign/state-first-adaptive-20260801-standard-789-integration/standard-v405-correct-residual-v442`;
- final Standard replay:
  `target/data-campaign/state-first-adaptive-20260801-standard-789-integration/standard789-strict-v442-raw-fastpath-final`;
- final CSR replay:
  `target/data-campaign/state-first-adaptive-20260801-standard-789-integration/csr108-strict-v442-raw-fastpath-final`.

### Marked DP models, innermost Q context, and v445

The next unresolved replay slice exposed two further extraction omissions.
Polynomial interpretations for marked DP symbols were being discarded because
CPF represents `f#` as `<sharp><name>f</name></sharp>`, not as a direct name.
They are now retained as exact `f#` witness entries.  More importantly, the
child of top-level `switchInnermost` now preserves `<nfs>true</nfs>`.  This is
the Q-normal-form context used by Ferrum's native innermost DP problem; the
previous context-losing child could not match independently certified graph,
usable-rules, instantiation, and SCT continuations.

The repaired chain adds eleven strict Standard YES replays:
`HirokawaMiddeldorp_04/{t002,t008}`, `SK90/4.30`,
`Strategy_removed_AG01/{#4.28,#4.30a}`,
`Transformed_CSR_04/{Ex15_Luc06_FR,Ex15_Luc06_GM,Ex4_7_15_Bor03_GM,ExProp7_Luc06_GM}`,
and `Various_04/{15,24}`.  A current default CSR sweep also recovered
`Maude_06/MYNAT_nokinds-noand`; its CPF was checked twice, extracted, and then
reconstructed under strict oracle-only settings in 17 seconds.

The complete v445 measurements are:

- Standard: **753/789 certified decisions** (589 YES, 164 NO, 31 MAYBE,
  5 timeouts, zero errors or checker failures);
- CSR: **94/108 certified decisions** (90 YES, 4 NO, 14 MAYBE, zero timeouts,
  errors, or checker failures).

Artifacts:

- oracle: `target/data-campaign/state-first-adaptive-20260801-standard-789-integration/oracle-global-v445-sharp-nfs-exact-plus-mynat.jsonl` (SHA-256 `2b80de39fdf54b6b6118dd29bd8cec379f063d1f87e3378a1d0d0a7ae78f19b2`);
- twice-checked Standard extraction:
  `target/data-campaign/state-first-adaptive-20260801-standard-789-integration/standard-v405-sharp-nfs-exact-v445`;
- MYNAT evidence and strict replay:
  `target/data-campaign/state-first-adaptive-20260801-standard-789-integration/csr-mynat-nokinds-noand-v444`;
- full Standard replay:
  `target/data-campaign/state-first-adaptive-20260801-standard-789-integration/standard789-strict-v445-final`;
- full CSR replay:
  `target/data-campaign/state-first-adaptive-20260801-standard-789-integration/csr108-strict-v445-final`.

### Exact natural-matrix actions and v447

Natural matrix interpretations in retained CPF proofs are now extracted as
`exact-matrix(hex=...)` DP actions.  As with exact polynomial actions, Ferrum
independently validates the supplied interpretation against the live DP state,
performs one certified deletion, and obtains the continuation through a fresh
oracle lookup.  Malformed models, non-natural domains, Arctic interpretations,
and unsupported strict dimensions are rejected rather than promoted.

All 765 retained Standard CPFs were checked twice with the current production
CeTA-CSR before extraction.  This produced 278 exact natural-matrix actions;
the full strict replay recovered `Endrullis_06/linear1` with no losses:

- Standard: **754/789 certified decisions** (590 YES, 164 NO, 30 MAYBE,
  5 timeouts, zero errors or checker failures);
- CSR: **94/108 certified decisions** (90 YES, 4 NO, 14 MAYBE, zero timeouts,
  errors, or checker failures).

Artifacts:

- oracle: `target/data-campaign/state-first-adaptive-20260801-standard-789-integration/oracle-global-v447-exact-natural-matrices.jsonl` (SHA-256 `93d3d7e900d219f188e5d5e82244f12b3edfcee27a0d0e1f65701b49809771c2`);
- twice-checked extraction and credited evidence:
  `target/data-campaign/state-first-adaptive-20260801-standard-789-integration/standard-v405-exact-matrix-v447`;
- focused `linear1` replay:
  `target/data-campaign/state-first-adaptive-20260801-standard-789-integration/standard-linear1-exact-matrix-v446`;
- full Standard replay:
  `target/data-campaign/state-first-adaptive-20260801-standard-789-integration/standard789-strict-v447-final`;
- full CSR replay:
  `target/data-campaign/state-first-adaptive-20260801-standard-789-integration/csr108-strict-v447-final`.

### Exact Arctic matrices and recursive CSR extraction (v450)

Arctic matrix interpretations are now available as `exact-arctic(hex=...)`
actions.  The action preserves the natural-versus-integer Arctic domain and
the minus-infinity element, rejects malformed encodings, and rechecks every
weak and strict obligation on the live DP state before deleting pairs.  The
765 retained Standard proofs were again checked twice; 87 Arctic steps were
extracted exactly.  This recovered
`Transformed_CSR_04/Ex4_7_77_Bor03_iGM` in 2.5 seconds.

The first combined regression exposed that `Maude_06/MYNAT_complete-noand`
still depended on model-sensitive search inside a broad root recipe.  All 94
retained certified CSR proofs were therefore checked twice and recursively
extracted as well.  With their child-state actions present,
`MYNAT_complete-noand` replays in 2.53 seconds instead of reaching the
65-second ceiling.

The final v450 measurements are:

- Standard: **755/789 certified decisions** (591 YES, 164 NO, 29 MAYBE,
  5 timeouts, zero errors or checker failures);
- CSR: **94/108 certified decisions** (90 YES, 4 NO, 14 MAYBE, zero timeouts,
  errors, or checker failures).

Artifacts:

- oracle: `target/data-campaign/state-first-adaptive-20260801-standard-789-integration/oracle-global-v450-exact-csr94.jsonl` (SHA-256 `b41b0f1b8611a403097cb8950a040550e8e628af7c0798f9f2a3e82f19e4feea`);
- twice-checked Standard Arctic extraction:
  `target/data-campaign/state-first-adaptive-20260801-standard-789-integration/standard-v405-exact-arctic-v448`;
- credited Standard evidence:
  `target/data-campaign/state-first-adaptive-20260801-standard-789-integration/standard-v405-exact-arctic-v449`;
- twice-checked recursive CSR extraction and credited evidence:
  `target/data-campaign/state-first-adaptive-20260801-standard-789-integration/csr94-exact-v450`;
- full Standard replay:
  `target/data-campaign/state-first-adaptive-20260801-standard-789-integration/standard789-strict-v450-final`;
- full CSR replay:
  `target/data-campaign/state-first-adaptive-20260801-standard-789-integration/csr108-strict-v450-final`.

### Parent-TRS and active-rule separation (v451)

Residual construction after a non-monotone reduction pair no longer conflates
the parent TRS with an enclosing usable-rules processor's active rule set.
CPF retains the parent R while carrying the active usable rules as a separate
component; replacing R by an empty active set had produced context-losing
children that could not match the independently extracted continuation.

The correction recovers two strict, certified Standard roots without changing
the v450 oracle: `AotoYamada_05/002` (2.03 seconds in the focused sweep) and
`Applicative_first_order_05/#3.6` (2.89 seconds).  Full regression results:

- Standard: **757/789 certified decisions** (593 YES, 164 NO, 26 MAYBE,
  6 timeouts, zero errors or checker failures), two gains and no losses;
- CSR: **94/108 certified decisions** (90 YES, 4 NO, 14 MAYBE, zero timeouts,
  errors, or checker failures).

Artifacts:

- focused residual regression:
  `target/data-campaign/state-first-adaptive-20260801-standard-789-integration/standard34-context-fix-v451`;
- full Standard replay:
  `target/data-campaign/state-first-adaptive-20260801-standard-789-integration/standard789-strict-v451-final`;
- full CSR replay:
  `target/data-campaign/state-first-adaptive-20260801-standard-789-integration/csr108-strict-v451-final`.

### Fourteen-root CSR frontier audit and GM child guidance

The v451 frontier contains 14 MAYBE roots.  A fresh 14-root, 14-worker default
discovery replay with 60-second prover and 65-second harness ceilings produced
no complete proof, so no positive from that sweep was promoted.  The artifacts
are in
`target/data-campaign/state-first-adaptive-20260801-standard-789-integration/csr14-discovery-v452`.

The audit found a real recursive-replay defect at the native Giesl--Middeldorp
CSR transformation boundary.  `csr-gm-transform` disabled both model guidance
and the certified utility oracle before starting its generated ordinary DP
problem.  It now continues to disable model inference, but preserves the
utility oracle for a bare transformation and for an explicitly delegating
recipe.  Fully explicit DP recipes remain isolated from guidance.  This makes
the transformed DP state independently addressable, consistently with QCS-DP
and ordinary DP residuals.  Focused policy and GM transformation tests pass.

The current v450 oracle has no matching continuation for the newly probed GM
states, so this correction alone does not change the authoritative score of
**94/108** (90 YES, 4 NO, 14 MAYBE).  The failed lookups and generated DP
states are retained under `csr-gm-guided-four-v452` and
`csr-gm-guided-five-v452`; future promotion must canonicalize their complete
CPF states and add both raw compatibility aliases and whitespace-independent
structural aliases.  Direct GM and CSR-rule-removal-then-GM probes also remain
open.  The two `LISTUTILITIES_*noand` roots still require the graph-first
RTA'08 usable-rule processor rather than the currently verified global-first
form.

### Exact top-level CSR matrices, safe aliases, and replay stabilization (v457)

`Transformed_outermost_08/morse` exposed two independent integration defects.
The CPF extractor retained natural matrix interpretations exactly only for DP
inputs, so top-level CSR matrix steps were reduced to parameter bounds and
could select different models. Ferrum now accepts the same
`exact-matrix(hex=...)` action at a CSR rule-removal state, rechecks the full
live interpretation, replacement-map monotonicity, and weak/strict rule
obligations, and derives the residual instead of trusting archived metadata.

The first promotion attempt also showed that the twice-certified manifest
named the source serialization while the credited database named its
whitespace/name-independent canonical state. The state-first exporter now
follows only the database's content-checked raw-to-canonical alias when
matching that certification gate. It does not broaden certification across
unproved state similarity.

After applying the five retained witnesses once, all current residuals were
materialized and independently indexed. A fallback-disabled strict replay
then terminated, and production CeTA-CSR certified its reconstructed CPF
twice. `morse` was already counted in the prior 94-root baseline, so this
improves replay fidelity and runtime without changing the root count.

The first union exposed a more general alias defect: reconciling a newly
content-checked alias copied its evidence into an older alpha-normalized
canonical target. Model-sensitive evidence could consequently alter unrelated
raw states with the same normalized shape. Aliases now become authoritative
direct records, exact witnesses rank ahead of parameter-only synthesis, and
evidence is never copied backwards across canonical generations.

Five previously certified roots then exposed the remaining nondeterminism:
their parameterized matrix atoms selected different valid models and reached
unindexed residuals. Their retained v450 CPFs were rechecked twice, yielding
25 exact root/residual actions. Two CPF extension proofs additionally required
decomposing `csrRuleRemovalThenImproved` into an exact polynomial step followed
by a bare improved-QCS-DP transformation, whose child state consults the
independently materialized oracle. Manifest candidates are normalized by the
same parser normalization used by the credited database.

The final v457 replay is **94/108** (90 certified YES, 4 certified NO, 14
MAYBE), with zero timeouts, errors, or certification failures.

Artifacts:

- oracle: `target/data-campaign/state-first-adaptive-20260801-standard-789-integration/oracle-global-v457-csr-combined-exact-normalized.jsonl` (SHA-256 `7ace49cb1faafce66aec2f59bc621107a32b0d0cde1010d272c43e9deb610070`);
- recovered current proof and exact residual chain: `target/morse-exact-matrix-20260802/current-chain`;
- twice-checked extraction and credited evidence: `target/morse-exact-matrix-20260802/current-chain-extracted`;
- strict oracle-only replay: `target/morse-exact-matrix-20260802/strict-v3`.
- five-root exact recovery: `target/csr-five-exact-recovery-20260802`;
- full strict replay: `target/data-campaign/state-first-adaptive-20260801-standard-789-integration/csr108-strict-v457-final`.

CeTA changes: none; the existing production checker accepted both current
proofs unchanged.

### LISTUTILITIES noand pair: improved graph and mixed subterm recovery

`TRS_Contextsensitive/Maude_06/LISTUTILITIES_nokinds-noand.ari` and
`LISTUTILITIES_complete-noand.ari` are recovered by the improved LPAR'08 CS-DP
path.  Its CAP/Ren dependency-graph approximation preserves variable sharing
below frozen positions and separates the generated problems into independent
components.  Polynomial deletion and graph decomposition expose the hard
components; projection deletes their mixed marked/fresh-unhiding pairs, and
size change or residual polynomial orders close the remaining components.

CeTA-CSR commit `c70bccb` adds the executable mixed-subterm checker and its
Isabelle soundness proof.  The `CSR_Checker_Extensions`, `Proof_Checker`, and
`Code` sessions build without `sorry` or `quick_and_dirty`; the exported
Haskell checker and production `ceta` build succeed.  The production checker
accepts the retained proof twice and rejects mutations of both the projection
and the deleted-pair set.  Ferrum keeps only the minimal-chain precondition
locally and leaves the complete processor obligation to CeTA-CSR.

The extraction records each compound root recipe and every nonempty residual
action separately.  The seven `nokinds-noand` states are exactly alpha-
canonicalized.  The larger 246-pair `complete-noand` states exceed the
alpha-canonicalizer's 300-second ceiling, so their promotion uses the existing
content-checked, whitespace-independent structural aliases rather than raw-only
hashes.  The resulting v460 oracle has SHA-256
`e6f80300d40d8a93e0da93dd502f4ca008989763c894aead4b338faf6d1bb010`.

An initial full replay exposed an over-broad Ferrum dispatch: an all-marked
MYNAT component was incorrectly sent to the new mixed processor.  Ferrum now
requires the fresh unhiding symbol to occur before using that theorem; MYNAT
then takes its previously certified alternative route.  The final strict
fallback-disabled replay is **96/108** (92 certified YES, 4 certified NO, 12
MAYBE), with zero timeouts, errors, or certification failures.  The two new
roots replay in 2.57 and 12 seconds respectively, and each reconstructed CPF is
accepted twice by the production checker.

Artifacts:

- promoted oracle: `target/data-campaign/state-first-adaptive-20260801-standard-789-integration/oracle-global-v460-listutils-two-structural-normalized.jsonl`;
- extraction, credited databases, and canonicalization reports: `target/listutils-nokinds-noand-certified-20260802` and `target/listutils-complete-noand-probe-20260802`;
- two-root safety replay: `target/listutils-nokinds-noand-certified-20260802/strict-v459-safe-two`;
- strict `complete-noand` replay: `target/listutils-complete-noand-probe-20260802/strict-v460`;
- authoritative 108-root replay: `target/listutils-complete-noand-probe-20260802/csr108-strict-v460`.

### LengthOfFiniteLists_nokinds: certified direct GM replay

`TRS_Contextsensitive/Maude_06/LengthOfFiniteLists_nokinds.ari` now replays
strictly from the oracle with fallback and the top-level LLM disabled.  The
official AProVE proof (`job_60792768`, benchmark 58) first performs four CSR
polynomial rule removals and then uses the orthogonal innermost/improved-CS-DP
path.  Ferrum reproduces those four exact models, including the negative-
constant weak polynomial witness.  This investigation found and fixed a real
search/checker mismatch: when the DP state fixes its usable-rule set, the SMT
encoding must orient every such rule unconditionally rather than guard it by a
fresh selectable-usable Boolean.  Exact weak-polynomial atoms are now
serializable, parseable, and independently rechecked on the live state.

The retained oracle recipe uses the already verified direct GM CSR-to-TRS
transformation instead.  It is both shorter and stronger: GM recomputes the
transformed TRS, then the explicit continuation
`graph;poly(3,3);graph;size-change;subterm` closes it.  The reconstructed CPF
was accepted twice by the current production CeTA-CSR checker (SHA-256
`0594a844844424a85f6e9e3b0f94e7cfc7ce0f9256ba1bd9c6e5016f23745351`).
No new CeTA source change was required; the production binary was refreshed
from the already committed current-source Haskell export containing GM and the
mixed-subterm checker.

Oracle v461 has SHA-256
`e3534266429da399421888a349e967ad55f2fb3bc430d8e2703765369459b8cf`.
The strict root replay takes 1.6 seconds.  The authoritative 108-root replay is
**97/108**: 93 certified YES, 4 certified NO, and 11 MAYBE, with zero timeouts,
errors, or certification failures.

Artifacts:

- official-shape and direct-GM probes, extraction, credited database, strict
  CPF, and double CeTA outputs:
  `target/next-csr-length-nokinds-20260802`;
- promoted oracle:
  `target/data-campaign/state-first-adaptive-20260801-standard-789-integration/oracle-global-v461-length-nokinds-gm.jsonl`;
- authoritative replay:
  `target/next-csr-length-nokinds-20260802/csr108-strict-v461`.

### Maude_06/csrdiv: exact improved-QCS-DP continuation

`TRS_Contextsensitive/Maude_06/csrdiv.ari` now replays strictly from the
oracle with fallback and the top-level LLM disabled.  The recovered proof
follows the AProVE evidence structurally: improved LPAR'08 CS-DPs, graph
decomposition, two U3 reduction pairs around context-sensitive
instantiation, a rational U3 deletion, and subterm closure of the fresh
unhiding component.  Ferrum preserves the exact residual pipeline after the
instantiation instead of restarting the parent recipe, tries alternative
instantiation candidates after a failed continuation, and emits the fresh
unhiding symbol as frozen in the CPF replacement map.

CeTA-CSR commit `1c090a7` proves and implements the two missing minimal-U3
continuation cases.  A fresh unsharp unhiding component whose arguments
strictly descend is terminating even without a minimality assumption, and a
U3 reduction-pair proof inside a dependency-graph component may continue to a
checker-validated acyclic graph.  `CSR_Checker_Extensions`, `Code`, and
`Proof_Checker` build in the isolated heap without `sorry` or
`quick_and_dirty`; the generated Haskell checker and production `ceta` build
successfully.  Both the directly generated and strict-replay CPFs are accepted
twice, while a mutation that removes the required unhiding pair from the graph
decomposition is rejected.

The certification-gated extraction contributes 11 positive root/residual
actions.  All 11 inputs were canonicalized before aggregation; the v462 export
contains zero uncertified promotions and zero canonicalization failures.  The
strict replay takes 1.3 seconds.  Its CPF SHA-256 is
`c724d5fcaf5777c90f5aed5bf73172e018df3c1d7d29aef812fb34cdcba6ade8`.

Artifacts:

- direct exact proof: `target/next-csr-csrdiv-20260802/frozen-u-exact-pipeline-v4`;
- extraction, credited SQLite, canonicalization report, promoted oracle, and
  strict replay: `target/next-csr-csrdiv-oracle-20260802`;
- oracle SHA-256:
  `bd52d656a35e6b00ccc1c384836dce2d00231b6963af5489c7478dbee5416b4e`;
- Ferrum integration commit: `43b5db2`;
- CeTA-CSR integration commit: `1c090a7`.

The 2026-08-11 replay audit recovered this evidence again after later oracle
atomization and DP-scheduler changes.  The old complete CPF still passed the
current production checker, but explicit sequences incorrectly restarted at
every child and the compact v836 oracle's `candidate_ref` rows were not
loadable.  Both integration defects are fixed.  The freshly reconstructed
strict oracle-only proof is
`target/csrdiv-continuation-integration-20260811/strict-v837-recipe.cpf.xml`;
it passed production CeTA twice.  The same directory contains the 12-row
certification manifest, credited database, v837 oracle, and export report.
No proof fragment is treated as terminal: the root recipe is promoted only
because its newly reconstructed complete CPF was deterministically certified.

### Maude_06/OvConsOS_complete-noand linear rule-removal replay

The current default proof and its eight exact rule-removal witnesses were
frozen under `target/ovcons-complete-noand-integration-20260811/fresh-source`.
The source CPF and the strict oracle-only reconstruction both passed
`/work/dfm/festschrift/CeTA-CSR/ceta` twice.  The oracle retains every nested
state action independently and a conservative complete root sequence, emitted
only because the CPF is a single nested `csrRuleRemoval` chain ending in an
empty system.  The v841 strict replay takes 2.1 seconds with fallback disabled.

### TRS Outermost: 63 certified native loop replays

The complete 279-root TermCOMP 2025 Outermost run contributes 63 certified
nontermination roots.  The proofs use native outermost cycles and contextual
loops already supported by CeTA; 22 contain non-root rewrite steps and 14
have a nonempty repeated context.  Every source CPF was rechecked twice by
the production CeTA-CSR checker before promotion.

The integration extracted 63 certified root actions, canonicalized all 63
inputs without a failure, and merged them monotonically on top of v462.  A
strict replay with `--strategy fail`, no top-level LLM, and fallback disabled
recovered **63/63 certified NO**, with zero MAYBE, timeout, error, or
certification failure.  Thus these are oracle-replayable results rather than
documentation-only evidence.

Artifacts:

- source 279-root run: `target/termcomp-runs/20260802-outermost-native-v6`;
- extraction, double-check manifest, canonical cache, and credited SQLite:
  `target/oracle-integration-outermost-native-v6-20260803`;
- promoted v463 oracle:
  `target/oracle-integration-outermost-native-v6-20260803/oracle-global-v463-outermost63.jsonl`
  (SHA-256 `01bbb3c148be7c38456e7d4c8a00eeb3fe96df1d7e03308cefc0e13414963f6a`);
- strict replay:
  `target/oracle-integration-outermost-native-v6-20260803/strict-replay-summary.md`.

### TRS Outermost: 98 additional certified native loop replays

The exact remaining AProVE-certified-NO intersection contributed 98 more
Ferrum outermost loop certificates.  All 98 complete CPFs passed the active
CeTA-CSR checker twice.  Canonicalization is formatting-independent and has no
raw fallback: the former 47 KiB outlier now canonicalizes in 9 ms after the
redundant quadratic SMT bijection was replaced by its equivalent direct
structural ordering.

The monotone v464 export adds 98 certified positives and 196 exact
raw/structural aliases to v463, with zero uncertified promotions.  A strict
replay using `--strategy fail`, no top-level LLM, and fallback disabled
recovered **98/98 certified NO** in three seconds.  Together with the prior 63,
the oracle now replays 161 certified Outermost NO roots.

Artifacts:

- source CPF list: `target/outermost-new-certified-no-98-cpfs.txt`;
- certification, canonicalization, credited SQLite, and strict replay:
  `target/oracle-integration-outermost-new98-20260803`;
- promoted v464 oracle:
  `target/oracle-integration-outermost-new98-20260803/oracle-global-v464-outermost161.jsonl`
  (SHA-256 `7cae813c31f007d1e01e6d015bdfccbde6eb1d7b9d037d9ba357d30862a27b24`).

### TRS Relative: 43 certified exact residual chains

The official 126-root Relative run contributed 42 certified YES and one
certified NO.  Every complete CPF passed CeTA-CSR twice.  The integration also
fixed two defects exposed by strict replay: relative rule removal now
reconstructs deletions from both strict and weak rule components, and
`prove_relative` now actually consults oracle guidance and recursively carries
the residual relative state.  Ordinary signed matrix domains are retained as
exact executable witnesses rather than degraded to an open-ended matrix
search.  Structural lookup additionally normalizes equivalent apostrophe
entity spellings such as `&apos;` and `'`.

The v465 export promotes 96 certified terminal/transformation states with zero
uncertified positives.  Strict replay with `--strategy fail`, no top-level LLM,
and fallback disabled recovered **43/43** roots in one second: 42 certified YES
and one certified NO, with no MAYBE, timeout, error, or checker failure.

Artifacts:

- source run:
  `target/termcomp-runs/20260803-trs-relative-parallel-matrix-official-8w-60s`;
- extraction, canonical cache, credited SQLite, and v4 strict replay:
  `target/oracle-integration-relative-official43-20260803`;
- promoted v465 oracle:
  `target/oracle-integration-relative-official43-20260803/oracle-global-v465-relative43.jsonl`
  (SHA-256 `62dd30e7e1da210acfa7792e734c7ad01784e6921a85f35a960d0c9776b7beca`).

### TRS Innermost: representation-exact deletion chains

`Transformed_CSR_innermost_04/PALINDROME_complete_C.ari` and
`PALINDROME_complete_noand_C.ari` now replay with fallback disabled and
`--strategy fail`.  Their independently checked chains consist of exact
path-order deletion, exact affine-polynomial deletions, and exact KBO closure.
Both reconstructed CPFs were accepted twice by CeTA-CSR.

This integration introduced rule-removal atoms that retain the certified
strict-rule subset instead of deleting every rule that happens to be strict
under the same model.  It also normalizes the equivalent CPF forms
`<innermost/>` and `<innermost><nfs>true</nfs></innermost>`, extracts exact KBO
models, and accepts the standard admissible zero weights for symbols of arity
at least two.  The same corpus pass recovered 519 independently executable
exact size-change steps from twice-rechecked AProVE certificates.

Artifacts are under `target/innermost-exact-sct-20260811`; the strict replay
certificates are `replay-pal-c-kbo-fixed/proof.cpf.xml` and
`replay-pal-noand-c-closed/proof.cpf.xml`.  The current promoted oracle is
`oracle-v782-pal-noand-c.jsonl`; its final 85-root strict slice has 44 certified
YES, raising the full AProVE-certified replay to 216 YES plus seven NO.

### TRS Innermost: exact residual parity and five focused recoveries

The composition-free worklist now retains the exact child state for dependency
pairs, dependency-graph components, usable rules, innermost LHS removal, DP
rewriting/narrowing/instantiation transformations, top-level
`constantToUnary`, ordinary reduction pairs, and conditional
`generalRedPairProc`.  These atoms do not replay an archived whole strategy:
each validates one live processor transition, returns its residual states, and
causes utility guidance to be queried again for every child.

The five requested groups recover ten strict oracle-only roots:

- `constantToUnary`: `Ex15_Luc06_C`, `Ex1_Zan97_C`, and `Ex6_GM04_C`;
- conditional general reduction pairs: `Mixed_innermost/cade05` and `cade13`;
- PALINDROME: `PALINDROME_complete_noand_GM` and `_iGM`;
- exact graph/deletion/transformation state fidelity throughout those chains;
- runtime-sensitive chains: `AG01_innermost/#4.30b`,
  `Ex1_2_Luc02c_iGM`, and `Ex24_GM04_iGM`.

All ten reconstructed CPFs pass production CeTA-CSR, including an independent
second checker pass.  Export now assigns new campaign evidence a priority
strictly above the maximum already present in the base oracle, and runtime
replay preserves the exporter's authoritative ordering.  This prevents stale
generic solved atoms from displacing newer exact transformations.

The v851 full 366-root audit reports **226 certified YES and seven certified
NO**, zero certification failures, and no loss from the previous v771 root
set; twelve additional roots are certified.  The eight older roots initially
masked by newer alternatives were re-extracted from their twice-certified
v771 CPFs and now replay 8/8 again.

Artifacts are under `target/innermost-five-items-20260811`.  The consolidated
oracle is `oracle-v851-parity.jsonl`; focused and full reports are
`all-ten-v851-summary.md`, `v771-lost-eight-v851-summary.md`, and
`full-strict-v851-summary.md`.

## 2026-08-27 LengthOfFiniteLists complete-noand iGM integration

- Root:
  `TRS_Innermost/Transformed_CSR_innermost_04/LengthOfFiniteLists_complete_noand_iGM.ari`.
- Result: strict oracle-only YES in 30.708 seconds, with no fallback and no SMT
  synthesis; production CeTA-CSR certified the CPF during replay and twice in
  the independent audit.
- Proof: ordinary innermost DP transformation with 357 pairs, exact graph
  decomposition, and 154 recursively findable exact natural-Arctic residual
  closures deleting 221 pairs.
- Oracle:
  `target/innermost-campaign-20260827-beyond-parity/oracle-r29/oracle-v1429-length-contextless.jsonl`.
- Replay artifact:
  `target/innermost-campaign-20260827-beyond-parity/full-strict-v1429-r49/TRS_Innermost/Transformed_CSR_innermost_04/LengthOfFiniteLists_complete_noand_iGM`.
- CPF SHA-256:
  `891c7608bee1b3db2e58f48b75d5b71feca7640a5b5e7fa504d4a474b2799dc5`.

## 2026-08-23 frozen-recursive CSR subterm integration

`TRS_Contextsensitive/Maude_06/LISTUTILITIES_nokinds.ari` now has a direct,
self-contained improved-CS-DP proof. Three hard SCCs close with collapsing
argument filters applied recursively below replacement-map-inactive marked
root arguments; a fourth transformation is bounded instantiation. The new
CeTA-CSR theorem proves that connecting CS-DP sequences preserve the selected
frozen argument exactly, while both CeTA-CSR and Ferrum reject active-root
projections and incomplete recursive filters.

The source proof and strict oracle-only reconstruction are byte-identical
(SHA-256 `ec7dcc1ebcf6db1a1190d1f67a07c34395034ffd831d64f26a16e712dd148648`)
and each passed the fresh generated checker twice. Extraction produced 21
events over 20 independently addressable states. The monotone v994 export
promoted 19 certified positive rows, retained one weak hint, and rejected zero
uncertified positives. With `--strategy fail`, top-level LLM disabled, and
`FERRUM_DP_LLM_NO_FALLBACK=1`, the root reconstructs and certifies in 3.884 s.

Artifacts are under
`target/csr-listutils-nokinds-frozen-subterm-integration-20260823`; the source
proof is under `target/csr-frozen-recursive-certified-20260823-simple`, and the
strict proof is under
`target/termcomp-runs/csr-listnok-strict-v994-20260823`. The complete 108-root
strict replay preserves every earlier result and reaches 101 certified YES
plus four certified NO, or **105/108**, with three MAYBE and no timeout, error,
or checker failure.

## 2026-08-24 guarded OvConsOS evidence

| Problem | Producing artifact | Complete proof recipe | Certification | Default replay | Oracle obligation | CeTA changes |
|---|---|---|---|---|---|---|
| `TRS_Contextsensitive/Maude_06/OvConsOS_nokinds.ari` | producing: `target/ovcons-oracle-integration-20260824/producing-run/TRS_Contextsensitive/Maude_06/OvConsOS_nokinds/proof.cpf.xml`; strict replay: `target/termcomp-runs/csr108-strict-v1001-ovcons-20260824/TRS_Contextsensitive/Maude_06/OvConsOS_nokinds/proof.cpf.xml` | CSR polynomial rule removal; improved CS-DPs with explicit unhiding symbol; dependency graph; existing matrix/U3/subterm/graph continuations; verified guarded-list terminal for the exact two-pair residual. The extractor records every recursive obligation independently. | source, extracted gates, and strict replay checked 2x by production CeTA-CSR | producing under 1 s; strict oracle-only 3.3 s | passed in the complete 107/108 v1001 replay with fallback `fail`; 14 certified state/action gates and 29 raw aliases exported | recursive guarded improved-CS-DP parser, checker, and soundness bridge in CeTA-CSR commit `c7fc326`; Ferrum integration/extraction through `072ed1e` |

The terminal processor was generalized on 2026-08-25. The explicit witness
assigns the semantic symbol roles, whose use is constrained by the two guarded
pairs, but the checker no longer compares the rules with the 15-rule OvCons
residual. It symbolically checks every live rule: successful guards must be
preserved backwards, and natural/list/infinite-list rank obligations must be
preserved (including the sound finite-list-to-infinite-list implication).
Consequently it accepts renamings and safe additions or transformed residuals
satisfying those obligations, while
mutation tests reject lost guard and lost-rank obligations. Ferrum emits the
generic `csrGuardedListTerminal` CPF tag; the checker retains the historical
`csrGuardedOvConsTerminal` spelling as an input-only compatibility alias.
The generated production checker is at
`CeTA-CSR-csr/target/csr-guarded-list-generic-export-v2-20260825/ceta-csr-guarded-list`.
It certified the fresh generic-tag OvCons proof twice, accepted all five
previously certified legacy-tag proofs, rejected the archived bad and
mutated-truth proofs, and rechecked all 108 retained strict CSR certificates
successfully (slowest check: 245 ms).

## 2026-08-25 final Ex5_7_Luc97 evidence

| Problem | Producing artifact | Complete proof recipe | Certification | Default replay | Oracle obligation | CeTA changes |
|---|---|---|---|---|---|---|
| `TRS_Contextsensitive/CSR_04/Ex5_7_Luc97.ari` | producing: `target/ex5-gm-filtered-wpo-root-20260824/proof.cpf.xml`; strict replay: `target/termcomp-runs/csr108-strict-v1005-minimal-generic-20260825/TRS_Contextsensitive/CSR_04/Ex5_7_Luc97/proof.cpf.xml` | Certified GM transformation; dependency graph; exact max-polynomial deletion; graph decomposition; four singleton WPO(Max) closures with collapsing argument filters and one plain max-polynomial closure. | producing and strict CPFs checked 2x by production CeTA-CSR | focused exact recipe under 1 s; strict oracle-only about 2 s | passed in the complete 108/108 v1005 replay with fallback `fail`; the post-GM child and every other nontrivial nested replay state are independently findable (444/444 audited) | none; standard CPF3 `filteredRedPair` plus `weightedPathOrder` is already supported |

## 2026-08-25 Gutierrez 2026 CSR evidence

| Problem | Producing artifact | Complete proof recipe | Certification | Default replay | Oracle obligation | CeTA changes |
|---|---|---|---|---|---|---|
| `TRS_Contextsensitive/Gutierrez_26/secret2.ari` | producing: `target/csr110-secret2-default-1-fresh-20260825/proof.cpf.xml`; strict: `target/termcomp-runs/csr110-strict-v1101-commit-06fb30d-20260825/TRS_Contextsensitive/Gutierrez_26/secret2/proof.cpf.xml` | With `f` frozen by its explicit empty map, one exact polynomial step deletes the false branch and a second exact polynomial min-delete step removes the remaining three rules. The empty residual is certified inside the complete proof rather than retained as an independent positive. | producing proof checked 2x; strict proof checked in the batch and 2x independently | two fresh default runs certified in 81--125 ms | exact root compound and both residual polynomial actions are independently keyed; strict fallback is `fail` | none |
| `TRS_Contextsensitive/Gutierrez_26/secret4.ari` | producing: `target/csr110-secret4-default-1-fresh-20260825/proof.cpf.xml`; strict: `target/termcomp-runs/csr110-strict-v1101-commit-06fb30d-20260825/TRS_Contextsensitive/Gutierrez_26/secret4/proof.cpf.xml` | Since the omitted map for unary `f` defaults to full, the contextual loop is `a -> if(S(a),f(a),a) -> if(true,f(a),a) -> f(a)` with context `f([])`. | producing proof checked 2x; strict proof checked in the batch and 2x independently | two fresh default runs certified in 22--23 ms | certified CPF loop evidence is typed as executable `csr-loop`, fixing the former ordinary direct-loop mismatch | none |

## 2026-08-29 LISTUTILITIES nokinds transformed-CSR integration

| Problem | Producing artifact | Complete proof recipe | Certification | Strict replay | Oracle obligation | CeTA changes |
|---|---|---|---|---|---|---|
| `TRS_Innermost/Transformed_CSR_innermost_04/LISTUTILITIES_nokinds_C.ari` | producing: `target/innermost-gm04-integration-20260828/list-nokinds-reconstruction-v1522/root-recursive-fallback-v1528-r1/proof.cpf.xml`; strict: `target/innermost-gm04-integration-20260828/list-nokinds-reconstruction-v1522/root-strict-v1533-r1/proof.cpf.xml` | Verified GM04 inverse; source improved CS-DPs; graph; instantiation; two recursive U3 reduction pairs; graph; one-pair usable-rules/polynomial closure; 23-pair subterm/graph closure; existing transformed child proof. | producing and strict CPFs accepted twice by production CeTA; full 316-proof audit passed 632/632 checker invocations | certified in 8.507 s under the authoritative 64-job strict replay | every root, event, and residual state is independently keyed; live graph atoms preserve their duplicate-pair source ordering; no DP fallback | none; production CeTA commit `e52c7ce` accepted the proof unchanged |

## 2026-08-29 LISTUTILITIES complete transformed-CSR integration

| Problem | Producing artifact | Complete proof recipe | Certification | Strict replay | Oracle obligation | CeTA changes |
|---|---|---|---|---|---|---|
| `TRS_Innermost/Transformed_CSR_innermost_04/LISTUTILITIES_complete_C.ari` | producing: `target/innermost-gm04-integration-20260828/list-complete-c-arctic-v1540-180/proof.cpf.xml`; strict: `target/innermost-gm04-integration-20260828/full-strict-v1555-list-complete-plus-nokinds-fresh/per-problem/TRS_Innermost__Transformed_CSR_innermost_04__LISTUTILITIES_complete_C.cpf.xml` | Verified GM04 inverse; improved CS-DPs; graph decomposition; four recursive 2D natural-Arctic usable-rule deletions; graph/subterm/size-change closure; independent transformed obligation closed by graph, usable rules, and exact path orders. | producing, focused strict, and batch CPFs accepted by production CeTA; all 317 batch CPFs rechecked twice | strict oracle-only 24.022 s under the 64-job replay | exact CSR usable-rule replay preserves the certified residual transformation-rule context; every nested state is independently keyed and fallback is `fail` | none; production CeTA commit `e52c7ce` accepted the proof unchanged |

## 2026-08-29 Ex6_15_AEL02_C transformed-CSR integration

| Problem | Producing artifact | Complete proof recipe | Certification | Strict replay | Oracle obligation | CeTA changes |
|---|---|---|---|---|---|---|
| `TRS_Innermost/Transformed_CSR_innermost_04/Ex6_15_AEL02_C.ari` | producing: `target/innermost-gm04-integration-20260828/ex6-15-ael02-c-producing-v1594/proof.cpf.xml`; strict: `target/innermost-gm04-integration-20260828/ex6-15-ael02-c-strict-v1597/proof.cpf.xml` | Verified GM04 inverse; source improved CS-DPs and graph; certified 3D natural-Arctic U3 deletion; graph/polynomial/size-change closure. The transformed 131-pair obligation decomposes into seventeen SCCs, with the exact terminal top component discharged by the complete-GM04 theorem. | producing and strict CPFs accepted twice by production CeTA; the 366-root preservation replay accepted all 318 decisions | focused strict 12.116 s; 77.112 s under the 64-job replay | every nonterminal root, source, transformed, event, and residual action is independently indexed; an archived empty-U3 ordinary fragment is lower-ranked and cannot reconstruct a CSR proof | none; production CeTA commit `e52c7ce` accepted the proof unchanged |

## 2026-08-31 AAECC innermost-switch integration

| Problem | Producing artifact | Complete proof recipe | Certification | Explicit replay | Oracle obligation | CeTA changes |
|---|---|---|---|---|---|---|
| `TRS_Standard/Secret_06_TRS/logarithm.ari` | producing: `ferrum-aaecc/target/aaecc-logarithm-production-final/proof.xml`; strict recursive replay: `ferrum-aaecc/target/aaecc-logarithm-oracle-integration-20260831/strict-recursive-1/proof.xml` | Certified AAECC full-to-innermost switch with explicit `R1`, `R2`, `Sigma`, overlay/local-confluence witness, and an independently materialized innermost child; the child closes by a recursively indexed DP/graph/usable-rules/LHSS/transformation/size-change chain. | Producing and strict CPFs accepted repeatedly, including two deterministic checks of each by `/work/dfm/festschrift/CeTA-CSR/ceta`; malformed sigma and missing-WCR mutations were rejected. | Explicit production replay is about one second; strict oracle-only recursive replay is 3.7 seconds. | Passed with `timeout(60s, fail)`, no top-level model, `FERRUM_DP_LLM_NO_FALLBACK=1`, and the complete root proof excluded. The 65 extracted observations cover 22 canonical states and promote 54 certified candidates; oracle SHA-256 is `e51f6cfdc5d1a0fa6168815e39fc598e36d78e5e17db84ce91f9d4d6f195f3a1`. | CeTA-CSR commit `40ff181`, rebased onto current main history as `1f4a7c7`; generic soundness theorem, executable checks, CPF parser, and exported Haskell checker. |
| `TRS_Standard/Secret_06_TRS/times.ari` | producing: `ferrum-aaecc/target/aaecc-times-production-final/proof.xml`; strict recursive replay: `ferrum-aaecc/target/aaecc-logarithm-oracle-integration-20260831/strict-times-1/proof.xml` | The locally confluent AAECC variant materializes the innermost child, which closes through independently indexed DP transformations and five terminal residuals. | Producing and strict CPFs each accepted twice by `/work/dfm/festschrift/CeTA-CSR/ceta`; zero processor timeout in the producing run. | Explicit production replay is about 15 seconds; strict oracle-only replay is 3.9 seconds. | Passed with `timeout(60s, fail)`, no top-level model, and DP fallback disabled. The two-root recursive oracle exports 132 certified positive entries, excludes both monolithic root proofs, and has SHA-256 `8f81641ed9ce2c480f835349c6d516d8c62741a9240170823822d37db0c61200`; `logarithm` also re-certified under this enlarged oracle. | Same AAECC checker as `logarithm`; no additional CeTA change. |

## 2026-09-01 certified QDP-to-SRS continuation

| Problem | Producing artifact | Complete proof recipe | Certification | Default replay | Recursive obligation | CeTA changes |
|---|---|---|---|---|---|---|
| `TRS_Standard/Zantema_05/z12.ari` | `ferrum-aaecc/target/z12-aaecc-default-parallel-final-20260901/proof.xml` | AAECC switch; innermost DPs; graph; usable rules; Q removal; general two-stack QDP-to-SRS; independently solved generated SRS. | Fresh exported checker accepted the complete CPF twice; the retained generated-SRS CPF was also accepted twice by the preceding production checker. | 3.7 seconds. | The generated SRS is a typed ordinary child, and its complete retained proof is selected only under exact or renaming-isomorphic rule matching. | General Isabelle theorem, executable check, CPF parser, Haskell export; no benchmark-name test. |
| `TRS_Standard/Zantema_05/z13.ari` | `ferrum-aaecc/target/z13-aaecc-default-certified-20260901/proof.xml` | Same processor vocabulary and independently matched generated SRS as z12. | Fresh exported checker accepted the default CPF twice. | Under the 60-second ceiling. | Same typed child and exact/portable-isomorphism boundary as z12. | Same general checker extension. |

## 2026-09-02 z12--z16 recursive replay integration

| Problems | Producing artifact | Complete proof recipe | Certification | Strict replay | Oracle obligation | CeTA changes |
|---|---|---|---|---|---|---|
| `TRS_Standard/Zantema_05/{z12,z13}.ari` | `ferrum-aaecc/target/standard-z12-z13-alias-fix-20260902` | AAECC; DP; usable rules; innermost-LHSS; QDP-to-SRS; generated SRS closure. | Complete and replay CPFs accepted twice. | 2/2 certified; included in the complete replay. | Fixed `.ari#qdp-to-srs` identity handling; the live post-usable-rule and LHSS states are independently findable. | none |
| `TRS_Standard/Zantema_05/{z14,z15,z16}.ari` | `ferrum-aaecc/target/standard-z12-z13-alias-fix-20260902/z14-z18-explicit-r2` | The same native AAECC/QDP-to-SRS vocabulary, with each generated SRS solved separately. | 3/3 complete CPFs and all retained positives accepted twice. | 3/3 strict oracle-only, fallback `fail`; complete-category YES total rises to 971. | 36 observations, 21 credited transformations, zero suspicious rows; no complete root proof retained. | none |
| `TRS_Standard/Zantema_05/z18.ari` | `ferrum-aaecc/target/standard-z12-z13-alias-fix-20260902/z18-default-modular-r8/proof.xml` | Polynomial rule removal; switch innermost; DP/graph/usable-rules/LHSS; QDP-to-SRS; generated SRS closure. | Default and strict CPFs accepted twice; r147 audit accepted all 1,238 category proofs twice. | Default 11.3 seconds; strict r146 5.0 seconds. | Uses independently keyed residual states; no complete root proof is needed. | none |
| `TRS_Standard/AProVE_07/thiemann34.ari` | `ferrum-aaecc/target/standard-z12-z13-alias-fix-20260902/thiemann34-strict-r156-indexed-sct/proof.xml` | Switch innermost; DP/graph; usable rules and LHSS; rewriting; conditional bounded-increase general reduction pair; two recursive graph/SCT branches. | Fragment-only CPF accepted twice; complete r157 proof accepted and the 1,239-proof audit passed 2,478/2,478 checks. | 5.31 seconds focused; 8.66 seconds in the 64-job replay. | Complete root proof excluded. Branch-indexed children, live-rule binding, pair-order-independent edge validation, and dependency-indexed SCT make every continuation independently findable. | none |

## 2026-09-02 Secret_07_TRS/4 recursive split integration

| Problem | Producing artifact | Complete proof recipe | Certification | Strict replay | Oracle obligation | CeTA changes |
|---|---|---|---|---|---|---|
| `TRS_Standard/Secret_07_TRS/4.ari` | producing: `target/standard-2026-oracle-gains-r253/frontier-r278/secret07-4-root-r382/proof.xml`; strict: `target/standard-2026-oracle-gains-r253/frontier-r278/secret07-4-strict-r385/proof.xml` | Exact generalized split. Selected child: semantic labeling, graph, usable rules, and monotone polynomial deletion. Complement: DP uncurrying, uncurrying below, polynomial deletion, `switchToTRS`, and relative match bounds. | Producing and strict CPFs accepted twice; included in the 1,269-proof audit with 2,538 successful checker invocations. | 5.9 seconds with `timeout(60s, fail)` and fallback disabled. | Every split branch and transformation child is independently keyed. Whole-proof atoms are excluded; 41 certified entries were promoted and no uncertified positive was accepted. | none; production CeTA-CSR `def4623` accepted the proofs unchanged. |

## 2026-09-02 OvCons Standard nontermination integration

| Problem | Producing artifact | Complete proof recipe | Certification | Strict replay | Oracle obligation | CeTA changes |
|---|---|---|---|---|---|---|
| `TRS_Standard/Transformed_CSR_04/OvConsOS_complete-noand_FR.ari` | `target/standard-2026-oracle-gains-r253/full-r277/TRS_Standard/Transformed_CSR_04/OvConsOS_complete-noand_FR/proof.cpf.xml` | Exact DP restrictions, three narrowing steps, and a source-bound terminal DP loop. | Included in the 1,262-proof audit and accepted twice. | Certified NO under the 64-worker oracle-only replay. | Every transformation child is independently keyed; the terminal loop is bound to its complete live DP obligation. | none |
| `TRS_Standard/Transformed_CSR_04/OvConsOS_nokinds_Z.ari` | `target/standard-2026-oracle-gains-r253/full-r277/TRS_Standard/Transformed_CSR_04/OvConsOS_nokinds_Z/proof.cpf.xml` | Exact DP restrictions, recursive narrowing, and a source-bound terminal DP loop. | Included in the 1,262-proof audit and accepted twice. | Certified NO under the 64-worker oracle-only replay. | Every transformation child is independently keyed; the terminal loop is bound to its complete live DP obligation. | none |

## 2026-09-03 Secret_07_TRS/7 recursive nontermination integration

| Problem | Producing artifact | Complete proof recipe | Certification | Strict replay | Oracle obligation | CeTA changes |
|---|---|---|---|---|---|---|
| `TRS_Standard/Secret_07_TRS/7.ari` | producing: `target/standard-next-frontier-20260902/secret07-7-exact-boundaries-r433/proof.xml`; strict: `target/standard-next-frontier-20260902/secret07-7-strict-oracle-r445/proof.xml` | Ordinary DPs; exact nontermination subproblem selection; narrowing; a second subproblem selection; additive instantiation; terminal DP loop. | Producing and strict CPFs were each accepted twice by production CeTA-CSR. | Strict oracle-only replay completed in 52.3 seconds wall time, of which about 51 seconds was one-time parsing of the 1.8 GB oracle; proof search itself completed immediately after loading. | The root and all five nested DP states have independent live keys. Only `dp`, two exact subproblem transitions, narrowing, instantiation, and the terminal loop are preferred; complete TRS/DP nontermination fragments are excluded. | none; production CeTA-CSR `def4623` accepted the proof unchanged. |

## 2026-09-02 z24 recursive QDP-to-SRS integration

| Problem | Producing artifact | Complete proof recipe | Certification | Strict replay | Oracle obligation | CeTA changes |
|---|---|---|---|---|---|---|
| `TRS_Standard/Zantema_05/z24.ari` | root: `target/standard-2026-oracle-gains-r253/frontier-r278/z24-strict-r397/proof.xml`; generated SRS: `target/standard-2026-oracle-gains-r253/frontier-r278/z24-srs-direct-r392/f40027ef/proof.xml`; final strict: `target/standard-2026-oracle-gains-r253/frontier-r278/z24-oracle-only-r401/proof.xml` | AAECC; DP; graph and usable-rule processing; Q removal; general QDP-to-SRS; independently solved three-rule generated SRS. | Producing, generated-child, and final strict CPFs accepted twice by production CeTA-CSR. | 5.2 seconds with fallback `fail`; included as the sole gain in the 1,270-root full replay. | The isolated child has an explicit adjacent result identity; QDP-to-SRS is a typed transition and its deterministic child plus all nested DP states are independently keyed. No complete root or whole-DP proof atom is retained. | none; production CeTA-CSR `def4623` accepted all proofs unchanged. |

## 2026-09-03 MNZ nvsr recursive proof-tree integration

| Problem | Producing artifact | Complete proof recipe | Certification | Strict replay | Oracle obligation | CeTA changes |
|---|---|---|---|---|---|---|
| `TRS_Standard/MNZ_10/nvsr.ari` | producing: `target/standard-next-frontier-20260903/nvsr-full-tree-r516/proof.xml`; strict: `target/standard-next-frontier-20260903/nvsr-strict-r518/proof.xml` | DP graph and two polynomial deletions; six deterministic narrowing/graph stages; a targeted 3D natural-Arctic deletion aligns the residual with the external 26-pair proof; the remaining proof is a recursive graph tree whose components close by polynomial, matrix, and size-change processors. | Producing and strict CPFs accepted twice; the complete 1,273-proof audit passed 2,546/2,546 checker invocations. | About 6 seconds with `timeout(60s, fail)`, no top-level model, and DP fallback disabled. | The 35 live states and every branch continuation are independently keyed. Canonical narrowing tie breakers remove parent-pair-order drift. Complete TRS/DP proof atoms are excluded; 37 certified positive entries were promoted and no uncertified positive was accepted. Oracle SHA-256: `565260d722462ce2e06c360d4b3f51a632e534329b40bdaf6c287fb81395b752`. | none; production CeTA-CSR `def4623` accepted all proofs unchanged. |

## 2026-09-03 MNZ 5 and 7 current-state recovery

| Problems | Producing artifact | Complete proof recipe | Certification | Strict replay | Oracle obligation | CeTA changes |
|---|---|---|---|---|---|---|
| `TRS_Standard/MNZ_10/{5,7}.ari` | producing: `target/standard-next-frontier-20260903/mnz5-7-resynthesize-r526`; strict: `target/standard-next-frontier-20260903/mnz5-7-strict-r528` | Current complete DPs and graph decomposition. Root 5 closes through six recursive 2D integer-matrix deletions and graph splits; root 7 uses a natural polynomial deletion followed by four 2D integer-matrix deletions across two graph components. | Archived, producing, and strict CPFs accepted twice; the complete 1,275-proof audit passed 2,550/2,550 checker invocations. | Both strict no-fallback replays complete in about 0.3 seconds. | Archived proofs began from obsolete 26/22-pair sets while current Ferrum generates 33/27 sound DPs. Inapplicable archived transitions were rejected; fresh live 25/21-pair graph children and all later residuals are independently keyed. Complete proof atoms are excluded. Oracle SHA-256: `ff06c8d3dc1a77e665b8142f394d32d74188f5d29161cd7213ed70d91f6d5f89`. | none; production CeTA-CSR `def4623` accepted all proofs unchanged. |
## 2026-09-06 complete-GM04 nontermination inversions

The following four Standard roots have certified complete-GM04 inverse
nontermination evidence and strict recursive oracle replay:

- `TRS_Standard/Transformed_CSR_04/LengthOfFiniteLists_nosorts_C.ari`;
- `TRS_Standard/Transformed_CSR_04/LengthOfFiniteLists_nosorts_noand_C.ari`;
- `TRS_Standard/Transformed_CSR_04/OvConsOS_nosorts_C.ari`;
- `TRS_Standard/Transformed_CSR_04/OvConsOS_nosorts_noand_C.ari`.

Producing CPFs are under
`target/standard-next-frontier-20260903/gm04-nonterm-r738/four`; extracted root
and source-CSR-loop states are under `gm04-integrate-r739`; strict focused
replay is `gm04-strict-r740`; and the complete preservation replay is
`gm04-preserve-r744`. Every producing and replay CPF was accepted twice by
production CeTA-CSR. The active-symbol and source-loop mutations were rejected.

## 2026-09-07 Hydras/lepper_3 retained DP-loop integration

| Problem | Producing artifact | Complete proof recipe | Certification | Strict replay | Oracle obligation | CeTA changes |
|---|---|---|---|---|---|---|
| `TRS_Standard/Hydras/lepper_3.ari` | producing: `target/standard-next-frontier-20260903/lepper3-retained-r758/proof.cpf.xml`; strict: `target/standard-next-frontier-20260903/lepper3-integrate-r759/strict/proof.cpf.xml` | Ordinary DPs; exact removal of every unused pair; a three-step mixed DP/TRS loop `J2# -> P# -> P# -> J2#`. This is the compact original-pair realization of NTI's much larger unfolded semi-unification witness. | Producing CPF accepted by production CeTA; strict CPF accepted twice. The retained witness is independently replayed against the live TRS and generated dependency pairs before use. | Strict oracle-only replay succeeds with `timeout(60s, fail)`, no top-level model, and DP fallback disabled. | Root `dp`, exact pair restriction, and terminal exact DP loop are separately keyed. Runtime-child rebinding fixes the live residual identity; no monolithic root proof is retained. Oracle SHA-256: `d21f364b01408faae78939b3f8bce4298733b177d12e581fb916e0a2e6eb8f06`. | none |

## 2026-09-07 Secret_07_TRS/aprove02 recursive integration

| Problem | Producing artifact | Complete proof recipe | Certification | Strict replay | Oracle obligation | CeTA changes |
|---|---|---|---|---|---|---|
| `TRS_Standard/Secret_07_TRS/aprove02.ari` | converted source: `target/standard-next-frontier-20260903/secret07-wave-r836/aprove02-certified-artifact/proof.cpf.xml`; strict: `target/standard-next-frontier-20260903/secret07-wave-r836/aprove02-strict-oracle-only-final-safe/proof.cpf.xml` | AAECC innermost switching; ordinary DPs; graph decomposition; usable-rule and innermost-LHS restrictions; reduction pairs; four exact instantiations on the final three-pair SCC; terminal graph closure. | Source proof and the fresh strict CPF were accepted twice by production CeTA-CSR. | Strict no-fallback replay returns certified YES with `timeout(60s, fail)`. Most wall time is one-time parsing of the 4.8-GB global oracle; the state-local processor chain itself is short. | Sixty certified observations address 40 live states. Graph branch identity is retained, identity graph wrappers are flattened, and every final instantiation was independently executed on its own child. Three sibling-SCC instantiation aliases were rejected and excluded. Oracle SHA-256: `c30a5d82d5b07b8b2e8d30ad53fd9678a32bace663fc012707c8ff9a2a3843ff`. | none; production CeTA-CSR `4cda18b` accepted the proof unchanged. |

## 2026-09-07 Secret_06_TRS/tpa03 native root-labeling integration

| Problem | Producing artifact | Complete proof recipe | Certification | Strict replay | Oracle obligation | CeTA changes |
|---|---|---|---|---|---|---|
| `TRS_Standard/Secret_06_TRS/tpa03.ari` | default: `target/standard-next-frontier-20260903/tpa03-default-root-r858/proof.cpf.xml`; strict: `target/standard-next-frontier-20260903/tpa03-integrate-r860/strict-v10/proof.cpf.xml` | Ordinary DPs; one-dimensional natural-Arctic deletion; native CPF root labeling; graph decomposition; monotone polynomial rule deletion; finite semantic labeling; terminal graph decomposition. | Default and strict CPFs accepted twice by production CeTA-CSR. | Strict oracle-only replay completes in about eight seconds with `timeout(60s, fail)`, no top-level model, and DP fallback disabled. | All seven actions run at independently keyed live states. Extraction preserves minimality across ordinary root/finite labeling, nested symbol labels round-trip without collapsing distinct roots, and exact reduction pairs accept alpha-identical labeled obligations before attempting a renaming bridge. The focused post-r840 union reaches 1,303 roots; a complete replay is still required before promoting that number to the category high-water mark. Oracle: `target/standard-next-frontier-20260903/tpa03-integrate-r860/oracle-global1303-rootlab-v7.jsonl`, SHA-256 `84af73996a1d24d51a7ddca01b4dba96b1d697742c70607a4d52025108110ba7`. | none; production CeTA-CSR `4cda18b` accepted the proof unchanged. |

## 2026-09-08 Ex4 full-GM04 Standard integration

| Problem | Producing artifact | Complete proof recipe | Certification | Strict replay | Oracle obligation | CeTA changes |
|---|---|---|---|---|---|---|
| `TRS_Standard/Transformed_CSR_04/Ex4_DLMMU04_C.ari` | administrative: `target/standard-next-frontier-20260903/post1305-c-wave-r919/admin-full-poly-dp/proof.cpf.xml`; full root: `ex4-c-qtrs-v19/proof.cpf.xml`; strict: `ex4-c-strict-v20/proof.cpf.xml` | Full GM04 inverse transformation; improved-CS-DP source proof; exact polynomial deletion on the 63-rule administrative TRS; ordinary DPs, graph decomposition, and twelve SCT components. | Administrative and complete root CPFs accepted twice by production CeTA-CSR; the complete 1,306-root replay has zero certification failures. | 7.9 seconds with `timeout(60s, fail)`, no top-level model, and DP fallback disabled. | The source CSR and administrative TRS are first-class child states. All 31 administrative actions were frozen before the complete source-bound root proof was retained. The final oracle also contains the independently findable nested chain. | CeTA-CSR main `b018e39` adds the verified full-GM04 parser and checker; the freshly exported production binary accepts the proof. |

## 2026-09-08 two further full-GM04 Standard integrations

| Problems | Producing artifact | Complete proof recipe | Certification | Strict replay | Oracle obligation | CeTA changes |
|---|---|---|---|---|---|---|
| `TRS_Standard/Transformed_CSR_04/LengthOfFiniteLists_nokinds_C.ari`, `OvConsOS_nokinds_noand_C.ari` | administrative proofs: `target/standard-next-frontier-20260903/post1306-c-wave-r923/admin-explicit`; full roots: `root-qtrs-v22`; strict: `strict-v23` | Full GM04 inverse transformation; existing source CSR chains; polynomial administrative rule removal; ordinary DPs and recursively solved graph components. | Both administrative, both full-root, and both strict CPFs accepted twice by production CeTA-CSR. The complete 1,308-root replay has zero certification failures. | Both strict roots finish in about eight seconds with fallback disabled. | Administrative evidence was extracted under distinct run/problem identities. Nested administrative states remain independently findable, while complete proofs are source-bound to their exact live roots. | none beyond CeTA-CSR main `b018e39`, already integrated for the full-GM04 theorem. |

## 2026-09-08 deeper full-GM04 Standard integrations

| Problems | Producing artifact | Complete proof recipe | Certification | Strict replay | Oracle obligation | CeTA changes |
|---|---|---|---|---|---|---|
| `TRS_Standard/Transformed_CSR_04/LengthOfFiniteLists_complete_noand_C.ari`, `OvConsOS_complete_noand_C.ari` | administrative proofs: `target/standard-next-frontier-20260903/post1306-c-wave-r923/admin-deep`; full roots: `root-deep-qtrs-v24`; strict: `strict-deep-v25` | Full GM04 inverse transformation; existing source CSR chains; path-order administrative rule removal; ordinary DPs and recursively solved graph components. | Both administrative, both full-root, and both strict CPFs accepted twice by production CeTA-CSR. The complete 1,310-root replay has zero certification failures. | Both strict roots finish in under nine seconds with `timeout(60s, fail)` and fallback disabled. | Each administrative proof was extracted under a distinct run identity. Its path-order, DP, graph, and terminal children remain independently keyed; complete roots are additionally source-bound. | none beyond CeTA-CSR main `b018e39`, already integrated for the full-GM04 theorem. |

## 2026-09-08 next full-GM04 Standard wave

| Problems | Producing artifact | Complete proof recipe | Certification | Strict replay | Oracle obligation | CeTA changes |
|---|---|---|---|---|---|---|
| `TRS_Standard/Transformed_CSR_04/Ex4_7_37_Bor03_C.ari`, `Ex6_15_AEL02_C.ari`, `ExAppendixB_AEL03_C.ari`, `LISTUTILITIES_complete_C.ari` | administrative: `target/standard-next-frontier-20260903/post1310-c-wave-r928/admin-probes`; roots: `root-qtrs-v26` and `root-next-two-v28`; strict: `strict-v27` and `strict-v29` | Full GM04 inverse transformation; existing certified source-CSR paths; exact path-order deletion of the administrative TRSs and recursive residual closure. | All administrative, producing-root, and strict CPFs accepted twice. The complete r930 replay is 1,314/1,542 with zero failure. | All four close under `timeout(60s, fail)`, no top-level model, and disabled DP fallback. | Source, administrative, and every transformed residual remain independently keyed; root proofs are source-bound only after the recursive trees certify. | none beyond CeTA-CSR main `b018e39`. |

## 2026-09-08 LISTUTILITIES full-GM04 wave

| Problems | Producing artifact | Complete proof recipe | Certification | Strict replay | Oracle obligation | CeTA changes |
|---|---|---|---|---|---|---|
| `TRS_Standard/Transformed_CSR_04/LISTUTILITIES_complete_noand_C.ari`, `LISTUTILITIES_nokinds_C.ari`, `LISTUTILITIES_nokinds_noand_C.ari`, `LISTUTILITIES_nosorts_noand_C.ari` | administrative: `target/standard-next-frontier-20260903/post1314-c-wave-r932/admin-path`; roots: `root-list-four-v30`; strict: `strict-v31` | Full GM04 inverse transformation; existing source CSR chains; exact path-order deletion of administrative TRSs up to 666 rules and recursive residual closure. | Every administrative, root, and strict CPF passed production CeTA-CSR twice; complete r933 is 1,318/1,542 with zero failure. | Four of four close under strict no-fallback replay. | Each child and nested state is independently keyed before the source-bound root proof is retained. | none beyond CeTA-CSR main `b018e39`. |

## 2026-09-08 official-2026 full-GM04 lead wave

| Problems | Producing artifact | Complete proof recipe | Certification | Strict replay | Oracle obligation | CeTA changes |
|---|---|---|---|---|---|---|
| Eleven remaining official unresolved `Transformed_CSR_04/*_C.ari` roots (`Ex1_GM03`, `Ex24_GM04`, two `ExIntrod`, two `LengthOfFiniteLists`, two `MYNAT`, two `OvConsOS`, and `PEANO_nokinds_noand`) | administrative: `target/standard-next-frontier-20260903/post1318-official-wave-r935/admin-path`; roots: `root-eleven-v32`; strict: `strict-v33` | Verified full GM04 inversion; independently findable source CSR proof; exact path-order administrative proof and recursive residual closure. | Every administrative, producing-root, and strict CPF accepted twice. Complete r936 replay: 1,329/1,542 locally and 1,321/1,528 on the official set, zero failures. | Eleven of eleven close under strict `timeout(60s, fail)` with both fallback mechanisms disabled. | One hundred distinct live states were canonicalized from the complete root trees. Source and administrative children remain independently keyed; no root is promoted before its entire tree certifies. | none beyond CeTA-CSR main `b018e39`. |

## 2026-09-08 final AProVE-certified Standard pair

| Problems | Producing artifact | Complete proof recipe | Certification | Strict replay | Oracle obligation | CeTA changes |
|---|---|---|---|---|---|---|
| `TRS_Standard/AotoYamada_05/Ex5TermProof.ari`, `TRS_Standard/Transformed_CSR_04/OvConsOS_complete_noand_iGM.ari` | Ex5: `target/standard-next-frontier-20260903/post1329-low-effort-r938/Ex5-context-fix/oracle-root-v39`; OvCons: `post1329-low-effort-r938/OvCons-iGM-aprove/strict-v51-60s` | Ex5 follows its certified recursive DP chain. OvCons uses the retained usable-rule mathematical R, exact reduction-pair projection, graph decomposition, and independently recomputed size-change/subterm terminal children. | Both producing and strict CPFs accepted twice by production CeTA-CSR. Complete r947 has zero certification failures. | 40.441s and 49.433s under the complete 64-worker strict replay. | Every transformed child is independently keyed. Context-free aliases are certification-manifest gated and limited to terminal processors that recompute their witness; exact state-bound reductions remain bound to their full source state. | none |

## 2026-09-08 regular recurrent-language Standard pair

| Problems | Producing artifact | Complete proof recipe | Certification | Strict replay | Oracle obligation | CeTA changes |
|---|---|---|---|---|---|---|
| `TRS_Standard/Zantema_15/ex14.ari`, `TRS_Standard/payet_21/payet-nonloop-1.ari` | `target/standard-next-frontier-20260903/regular-ta-r965-default`; strict: `regular-ta-integrate-r966/strict` | Renaming-invariant recognition of the counter-transfer and counter-duplication schemes; a two-state bottom-up automaton accepts all binary-root terms whose arguments are unary counter chains. | Both producing CPFs and both strict CPFs accepted twice by production CeTA-CSR. Complete r967 has zero certification failures. | Both roots close under `timeout(60s, fail)`, no top-level model, and disabled DP fallback. | The independently certified root-local action is `nontermination(direct-loop)`; the processor recomputes and structurally validates the automaton witness from the live rules. | none; existing CPF3 `notWNTreeAutomaton` support is used. |
