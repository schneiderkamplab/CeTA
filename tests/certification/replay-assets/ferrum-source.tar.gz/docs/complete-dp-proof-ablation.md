# Complete DP termination proof ablation (r983)

Recovery is complete: see [modular oracle recovery](modular-oracle-recovery.md)
for the verified full no-fallback replay with both termination-proof shortcuts
disabled. The results below describe the original diagnostic ablation.

This experiment removes only `exact-dp-proof` from the verified v54 oracle.
It does not disable complete TRS proofs, DP nontermination proofs, or exact
single-processor witnesses. The production oracle and Ferrum code are unchanged.

## Configuration and integrity

- Ferrum source: `4f97b3a5a4ccc3f70778951c1a11984e22bf7e62`; ledger HEAD
  `aa39e7c10a32631622ebcac01240d141faf3d9e0`.
- Binary SHA-256: `3a7f6f8c324f4a28fe138fc832453c3216000afd64cc70f9de316b2482b23cb0`.
- Input oracle: `target/embedded-cleanup-ta-r976/oracle-v54.jsonl`.
- Ablated oracle: `target/complete-dp-ablation-r983/oracle-no-complete-dp.jsonl`.
- Ablated SHA-256: `b2dff50a7e67a091d5ef59ca84b1cd8786d7bc235a0e233d1159afe8cb0e835d`.
- Removed 2,275 unique payloads and 4,463 entries (4,457 preferred, six possible)
  across 3,971 state records. No dangling references or remaining executable
  `exact-dp-proof` atoms. File size fell from 4,944,233,883 to 2,291,428,208 bytes.
- `timeout(60s, fail)`, `FERRUM_DP_LLM_NO_FALLBACK=1`, no top-level LLM,
  65s harness, two Rayon threads; Standard/Innermost/CSR workers: 64/24/12.
- Certification exclusively by `/work/dfm/festschrift/CeTA-CSR/ceta`, unchanged
  SHA-256 `a6d8977c1738daa3e225f0e52443fb56659d09b175516d4215bcd77a3bf0ab46`.

Reproduction: `scripts/ablate_complete_dp_proofs.py`. The script creates a new
output exclusively and leaves every nonmatching candidate unchanged.

## Root results

| Category | Baseline certified | Ablation batch | After isolated repeat |
| --- | ---: | ---: | ---: |
| Standard | 1338/1542 | 1338/1542 | 1338/1542 |
| Innermost | 311/366 | 310/366 | 311/366 |
| CSR | 110/110 | 110/110 | 110/110 |

All root sets match after normalizing absolute/relative TPDB paths. No polarity
changes, gains or checker failures. Standard retains 1,039 YES and 299 NO;
CSR retains 105 YES and five NO. Innermost batch has 300 YES and ten NO,
55 MAYBEs and one timeout. Artifacts:
`target/complete-dp-ablation-r983/{standard,innermost,csr}`.

The sole batch loss was
`TRS_Innermost/Transformed_CSR_innermost_04/PALINDROME_nokinds_iGM.ari`:
baseline 62.301s, ablation batch timed out at 65.231s. The unchanged ablated
oracle and limits certified it in the isolated repeat (59s harness elapsed)
at `target/complete-dp-ablation-r983/palindrome-isolated`.
Its trace contains no successful complete-DP action. The timed-out prefix
enters a fruitless DP branch before returning to an exact top-level path-order
continuation. This is timing sensitivity, not a missing DP-proof decomposition.

## Actual use and the concrete replacement

Baseline event audit found one root with a successful `exact-dp-proof` event:
`TRS_Standard/Secret_06_TRS/times.ari`. There were also 59 unsuccessful
complete-DP attempts in Standard, and none in Innermost or CSR.

The successful packaged continuation is a single size-change proof for
`inc#(s(x)) -> inc#(x)`, at state
`21b6d8d748726f2f199fe19bbc4ab1e1cb1ea481d055546b2da269ed3a4c3602`.
That state already has both `exact-size-change` and `size-change` guidance.
The ablated replay successfully selects `exact-size-change` at this state.
Focused certified reproduction: `target/complete-dp-ablation-r983/times-isolated`.
Thus no additional extraction, processor implementation or proof reconstruction
was necessary for the only observed successful complete-DP call.

## Stored decomposition gaps not exposed by root loss

Of the 3,971 affected state records, 3,906 retain at least one processor-specific
or search action. 934 lose all preferred actions; 65 lose both preferred and
possible actions. These 65 keys reference 43 distinct complete-DP payloads.
Their first required processor is:

| First CPF processor | State keys | Existing modular action family |
| --- | ---: | --- |
| rewritingProc | 16 | exact-dp-transform |
| innermostLhssRemovalProc | 16 | exact-innermost-lhss |
| narrowingProc | 9 | exact-dp-transform |
| redPairProc | 12 | exact-red-pair / exact-general-red-pair |
| semlabProc | 4 | exact-semantic-labeling |
| instantiationProc | 6 | exact-dp-transform |
| depGraphProc | 2 | exact-graph |

Inventory, exact state keys, payload IDs and proof summaries:
`target/complete-dp-ablation-r983/stranded-states.json`.
The concrete missing item at these keys is a bound modular first action,
followed by verification of every resulting child continuation. All seven
processor families exist; this inventory does not establish that every model
variant or context can already be imported correctly. Nor does merely having
an alternative action at the other 3,906 keys establish recursive closure.

All 2,275 packaged payloads parsed successfully. 266 have no nested DP proof
(226 size-change leaves and 40 graph closures); 2,009 contain nested DP proofs.

## Interpretation

No reproducible root loss was exposed by disabling complete DP termination
proofs. This is not proof that all packaged continuations are decomposed:
baseline traces show complete TRS termination actions in 997 Standard roots,
six Innermost roots and one CSR root. Those actions remain enabled and can
hide further DP obligations. A separate complete-TRS ablation is needed to
measure those gaps; it was deliberately not included in this experiment.
