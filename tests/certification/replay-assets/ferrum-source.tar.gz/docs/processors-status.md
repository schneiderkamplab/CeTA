# Ferrum Processor Status

Last updated: 2026-10-17.

`srs-strip-contexts` is an opt-in, symbol-independent strengthening processor
for full-rewriting unary TRSs/SRSs. It strips shared rule prefixes and suffixes
while retaining a nonempty left side, then exposes the strengthened system as
an independently keyed child. Optional `max-prefix` and `max-suffix` bounds
include zero and avoid unnecessarily strengthening the child; omitted bounds
strip as much as possible. Only a terminating child reconstructs a proof;
a nonterminating strengthened system says nothing about the original system.
The new CeTA `ruleStrengthening` step checks that every original rule is an
actual one-step rewrite of the supplied stronger system, then checks its child
proof. Its Isabelle theorem is general TRS simulation by context/substitution
closure, not a benchmark-specific string pattern. Q and weak-rule contexts are
conservatively rejected. Defaults, CSR and innermost strategies are unchanged.
No orders, automata, or complete proofs are supplied by oracle guidance.

`dp-trimmed` is an opt-in, state-local root transformation for well-formed
full-rewriting TRSs/SRSs. It implements the existing verified CeTA
`DP_Transformation_Impl.DP_list` construction: omit a defined RHS call only
when it is a proper subterm of the original, unmarked LHS. Equal calls are
retained. This is not a deletion processor on arbitrary residual DP states.
The resulting DP problem is exposed to ordinary independent child guidance;
`dp-trimmed(...)` discovery continuations are stripped during oracle export
and rejected as composite runtime guidance. Existing `dp`, CSR, innermost,
and default strategy behavior are unchanged. `Waldmann_06_SRS/jw3` now has
a certified native proof in 2.537 seconds and strict witness-free replay.
The unchanged production CeTA accepts it and rejects a mutation removing a
required pair. Full release library verification: 1,223 passed, no failures
or ignored tests, with `CETA_CSR_BIN` set to production CeTA-CSR, a 32 MiB
test-thread stack, two Rayon threads, and eight test threads. No CeTA changes.

`srs-weighted-labeling(carrier-size=3,max-weight=4)` jointly synthesizes a finite
unary model and labeled additive weights in one QF_LIA query. Carrier bounds
are 2–8 and weight bounds 1–128. Optional `strict-percent=0..100` requires a
minimum fraction of strictly oriented labeled rule instances (zero means at
least one). Native code independently rechecks the model, weak inequalities,
and requested progress before emitting existing finite semantic-labeling CPF.
The model and weights are not supplied by the oracle; later rule-removal and
DP actions remain separately addressed. This recovers two Cirpons roots in
strict witness-free replay, with no CeTA change.

RFC validation now shares positive RHS reachability and immutable bit-set
closure results, tries reached layers before full layers, and rejects
irreversible top-redex failures early. The affected 345-root guard passes.
Alias chains are resolved in dependency order, with cycle/duplicate rejection;
this does not identify distinct DP contexts. Matrix term sharing, bit-product
encoding, Arctic threshold sharing, and shared joint-labeling encodings remain
opt-in because equivalent formulas can change solver models and residuals.
The latest full library run passes 1,220 tests with none failed or ignored.
See the state-of-the-art ledger for certified totals and active replay repairs.

The ongoing SRS campaign adds opt-in `encoding=threshold` for natural and
integer Arctic matrix actions. Query-local caches share subterm circuits and
Boolean threshold gates; all solver models still pass independent exact order
validation. Backend selection is part of the modular action, not a global
default change. Small signed ranges, homogeneous natural interpretations
(`max-constant=-1`), integer `strict=all`, and row sparsity
(`max-finite-per-row`) provide structural search restrictions without supplying
interpretations. Natural Arctic strict constraints now cover every coordinate,
matching the independent validator and CeTA. Legacy affine search keeps its
finite-constant restriction; the new threshold backend permits bottom constants.

`nontermination(srs-normalized-loop(width=N,max-width=M))` extends overlap
derivations with bounded non-growing endpoint rewriting. Both leftmost and
rightmost normalization are explored; every shortcut is expanded into original
rule steps and independently checked. It has recovered six certified NO roots
in `target/srs-native-20261013/replay-normalized-six-v369/`. These routes are
symbol-independent and do not embed supplied loops. Current integration and
protected-category checks remain in progress; see the state-of-the-art ledger
for frozen totals. No CeTA changes are needed for these processors.

Bounded native SRS loop search now packs vertex colors into two bits (up to
512 million vertices / 128 MB for the color table). For systems without
length-increasing rules it searches one fixed-length graph: every shorter
cycle embeds in that context, and strictly length-decreasing steps cannot
belong to a loop. All reported traces are reconstructed and independently
checked against the original rules. This recovers `Waldmann_23/4` and the local
extra `Waldmann_26/1`, both certified by unchanged production CeTA. The former
also replays in 3.83 seconds after the fixed-length optimization, versus about
20 seconds with the initial packed-table implementation.

Experimental loop routes now share SMT word-update circuits and accept
independent `start-width` / `max-width` bounds. `srs-overlap-loop-beam` limits
local branching; `srs-compose-loop` composes discovered derivations while
retaining their full original-rule traces. Neither supplied words nor supplied
rewrite sequences are used. These experimental routes have **not** added
campaign roots in the current pilots and are not enabled in the default
strategy. Final release library suite: **1,188 passed, zero failed/ignored**;
nine recent roots pass strict replay and independent correspondence in
`target/srs-native-20261013/final-loop-guard-v233/`. Both newest roots pass those
checks in `replay-finite-wide-gains-v235/`. See the state-of-the-art ledger for
the distinction between frozen and incremental counts.

Opt-in `arctic-matrix-cached` sizes evaluation bit vectors from term depth
and weight bounds (six bits minimum) and shares identical subterm encodings
within each query. Existing `arctic-matrix` keeps its legacy encoding: the
initial global replacement lost replay coverage and was withdrawn. The two
new Wenzel roots and all protected roots are retained in the audited v128
replay; see `state-of-the-art.md` for exact counts and artifacts.

`srs-context-closure` and `srs-shift-labeling` now accept depth/memory up to eight.
The existing 256-element carrier and 100,000 labeled-rule limits remain;
incomplete context models are still rejected. Renaming, incomplete-layer,
parser-boundary, and carrier-cap tests pass. A native depth-four smoke proof
certifies with unchanged production CeTA-CSR in
`target/srs-native-20261013/memory4-smoke-v132/` and
`memory5-smoke-v146/`. No default strategy changed.

RFC strict and maximum-height weak compatibility now quotient automaton runs
by exactly the endpoints and label extremum used by each obligation. The
uniform-height weak checks retain full paths. Tests compare the quotients
against exhaustive branching/epsilon runs; per-path cancellation and phase
timings are included. All 336 retained RFC-dependent roots pass oracle-only
replay (`rfc-extrema-guard-v144`). The final library suite passes 1,172/1,172
with the optional LP backend enabled (`final-tests-v151.log`). An earlier
loaded run had two unrelated failures (persistent Z3 and a pattern-search
deadline); both passed individually and in the final suite. The speculative
bidirectional partial-RFC construction produced no new proof and was removed.

Campaign recipes must not require a no-progress graph step in a strict
`pipeline(...)`: use a recursive processor portfolio or explicitly optional
graph branches. Correcting this recovered `Secret_06_SRS/multum1` without
an exact witness. `replay-multum-v136` has a successful oracle-only replay
and two independent production CeTA checks; the next full consolidation is
still pending for this individual gain.

Opt-in `srs-canonical-compact-weight-removal` fixes a renaming-sensitive
weight search by synthesizing on canonical symbols and validating transported
weights against the live rules. The renamed root passes strict replay.
`srs-summed-weight-removal` further replaces the strict-progress disjunction
with positivity of the sum of individually nonnegative gaps. It passes unit
tests but has not demonstrated a benchmark gain and is not a default action.

New opt-in `srs-compact-weight-removal(max-weight=N)` uses the existing
exact-checked polynomial rule-removal processor with a compact QF_LIA query:
cancel common symbol occurrences and deduplicate identical difference vectors.
It preserves the requirement that all rules orient weakly and at least one
strictly. Legacy weight atoms retain their original encodings/models.
Two-layer shift labeling with this atom recovered three certified ICFP roots;
all pass strict witness-free replay. The 1,484-root frozen baseline is separate
from these incremental gains.

`srs-overlap-loop-target(width=1..64)` changes the bounded closure search's
priority toward the requested source width, with word limit twice that width.
It retains the one-million-state frontier, 1,024-step depth, fair directional
time split, and independent reconstruction/checking of original forward steps.
No starting word, alphabet, or rule sequence is prescribed. The synthetic
renamed positive tests, parser/deadline/negative tests, and a fresh
production CeTA smoke proof pass. This found a new certified NO for
`Waldmann_07_size11/size-11-alpha-3-num-4` in 0.271 seconds.

New opt-in SRS closure atoms `srs-overlap-loop-narrow` and
`srs-overlap-loop-wide` use 15/25-symbol closure bounds, a one-million-pair
frontier, and 1,024-step depth. They prioritize short source/target words
linearly and reserve half the parent budget for each search direction.
Neither replaces a recorded legacy recipe. Candidates are reconstructed as
forward steps of the original system and independently checked. The narrow
wave adds 38 NO roots beyond the 978 full sweep, all 64 discoveries passing
strict witness-free replay and two production CeTA checks
(`replay-native-narrow-v35`). No CeTA changes.

`srs-overlap-loop(max-width=1..128)` exposes the same fair two-direction
search with a native width parameter. This permits larger contexts without
changing legacy search recipes. Width and depth are search bounds, never
retained loop words or rule sequences. A 70-symbol synthetic two-step loop
regression checks both successful width-96 search and failure at width 40.
All 152 nontermination-filtered release tests pass with production CeTA
pinned (`nontermination-tests-v38.log`); the width parser/deadline and long
word tests also pass (`width-test-v39.log`, `width-long-test-v39.log`).

`qpi-bv(period=1..16,max-weight=0..64)` is the bit-vector version of the
existing quasi-periodic search. Width is derived from maximum term depth and
the bounded interpretation values so evaluation cannot wrap. Shared
subterm/residue nodes are retained, and the synthesized integer-Arctic
interpretation passes the same independent validation as `qpi`. Arctic
validation now merges alternatives having the same variable component by
their maximum coefficient, using `max(c+x,d+x)=max(c,d)+x`; it no longer
enumerates exponentially many equivalent matrix-product paths. This is an
exact representation change, not a weaker order check.
Periods 9--16 are opt-in search-range extensions; both QPI encodings support
them. Wider-period tests use narrow coefficient bounds, while retaining the
original long-word overflow regressions through period eight. Three new Wenzel
roots pass strict witness-free replay with this extension. No CeTA changes.

Search parameters matter independently of available proof power. The four
dimension-seven Wenzel targets in `native-period7-v53` gave one certified YES
and three 60-second search misses at `max-weight=7`. The smaller, symbol-
independent `max-weight=1` bound recovers all four in 2.0--9.6 seconds
(`native-period7-tight-v56`), with strict witness-free replay and double
production checks. The oracle stores only `dp`, `graph`, `qpi-bv` parameters,
and `empty` at their respective states, never the synthesized matrices.
Two alphabet-renamed copies also pass double certification
(`renamed-period7-v59`). Wider bounds should follow, not replace, cheap tight
bounds; include period seven rather than skipping from six to eight.

Verification artifacts are under `target/srs-native-20261013`: the QPI
arithmetic/BV tests pass (`qpi-bv-test-v36d.log`), including long words,
periods 1,2,3,4,5,8, and rejection of actual self-cycles. The release library
run with `CETA_CSR_BIN=/work/dfm/festschrift/CeTA-CSR/ceta`, two Rayon threads
and four test workers has 1,157 passes and one timed-out multiplication-pattern
search (`full-tests-v37-production.log`); that test passes alone in 58.30s
(`multiplication-isolated-v37.log`). No test is ignored. The earlier unpinned
run selected `CeTA/ceta` through the test helper and rejected six standalone
CSR/relative input forms; all six pass with production CeTA-CSR pinned.
The unbounded-concurrency run was superseded by this controlled run.
The subsequent **full serial release suite passes all 1,159 tests**, with
zero failures and zero ignored tests, in 215.92 seconds
(`full-tests-v40-serial.log`). Production CeTA-CSR was explicitly pinned.

`nontermination(srs-transport-loop)` is an opt-in, native, witness-free SRS
search. It synthesizes a pivot, a small block alphabet and locally checked
derivations `x p ->* p phi(x)`, then freezes a recurring prefix and transports
the productive suffix to obtain a concrete loop. Forward and reversed searches
share the parent deadline. Limits are four block types, 2,048 alphabets per
pivot, three steps per local move, 4,096 expanded steps and 4,096 symbols per
word. The expanded loop is reconstructed with original rules and independently
rechecked; no new checker axiom, retained loop, symbol-name dispatch, or
benchmark-specific production code is used. Only full ordinary SRS rewriting
is accepted. Reference: Waldmann's AJRW 2007 transport-system construction,
https://www.imn.htwk-leipzig.de/~waldmann/talk/07/ajrw/main.pdf .

The final 225-root frontier finds **59 certified NOs**, including **51 new
roots** relative to the completed 886-root replay: all 36 Wenzel roots in this
frontier, 13 Waldmann_07_size12, one size11, and one Secret_07_SRS. All 59 pass
witness-free, no-fallback replay and double certification in
`replay-native-transport-v21` under
`target/srs-native-20261013`. No previous transport success is lost.

Two general implementation bottlenecks were removed: subterm replacement now
rebuilds its path once instead of repeatedly cloning the replaced branch;
CPF loop-term indentation is capped, without changing XML elements or root/
state serialization. The large `cabababa-ababababccccca` certificate shrinks
from 8.6 GiB to 198 MiB and completes/certifies in 7.92 seconds in the final
batch. Tests cover original-rule replay after reversal, renaming, restricted
strategy rejection, nonempty loops, deadlines, long one-rule transport,
replacement siblings/invalid positions, and XML element equivalence. No CeTA
changes were required.
All 150 release nontermination-filtered tests and the focused CPF
XML-equivalence regression pass.

Rule-subset narrowing now shares its parent processor budget across remaining
subsets, capped at one second per subset, instead of always imposing 100 ms.
Without a parent deadline it retains the 100 ms default. This removes an inner
ceiling that ignored learned oracle budgets. Bouchare_06/09 passes five loaded
oracle-only repetitions with CeTA, and all 144 release nontermination tests
pass. Search acceptance and certificate validation are unchanged.

Standalone `relative-semantic-labeling` now also accepts full ordinary TRSs/SRSs
as the empty-weak-part case and keeps their labeled residual ordinary. The exact
model action has the same state-kind handling. Innermost inputs remain rejected
by this bridge. This fixes the applicability boundary after flat-context
closure; it does not add or weaken a labeling theorem. Twenty-seven semantic
labeling tests pass, and a synthesized ordinary labeling-to-SCT certificate
passes production CeTA twice (`ordinary-labeling-smoke.cpf.xml`). No CeTA changes.

`nontermination(srs-overlap-loop)` performs bounded context-extension search:
it extends a concrete derivation at either word boundary when this enables a
new redex, and also explores internal rewrites. Limits are 64 rewrite steps,
64-symbol generated words, and 16,384 distinct source/target pairs. Accepted
loops are reconstructed and independently checked against the live TRS; no
benchmark names, retained starts, or external substitutions enter the search.
Three previously unresolved SRS roots pass native search, witness-free oracle
replay, and two CeTA checks (`replay-native-context-loop-v9`). The processor
remains opt-in. The release nontermination suite passes 143 tests.

The next search lane preserves that breadth-first pass, then prioritizes deep
closures with narrow source contexts, up to 1,024 steps and 131,072 distinct
source/target pairs (same 64-symbol word cap and parent deadline). Ties use
insertion order, not symbol names. The 225-root frontier yields 45 certified
NOs, retaining the previous three and adding **42 new roots**. All 45 pass
witness-free, no-fallback replay and two independent CeTA checks in
`target/srs-native-20261013/replay-native-priority-closure-v14`.
All 145 release nontermination-filtered tests pass. No CeTA changes.
Replacing breadth-first outright failed the existing
multistage-context regression, so the inexpensive original lane is retained.
All candidate acceptance and production CeTA checks are unchanged.

Matchbox parity audit (2026-10-14): 205 of its officially certified SRS NO
roots are missing from the 842-root Ferrum replay. Archived 2025 Matchbox
certified proofs cover 193 of those roots, all using ordinary `<loop>`;
161 have at most 64 steps, while the maximum is 729. Thus the checked loop
format already covers this evidence. Dedicated transport-system loop search
is still absent from Ferrum; increasing fixed-seed depth is not a substitute.
Matchbox also uses specialized full-tiling/shift-algebra and quasi-periodic
interpretation searches. Generic semantic labeling and Arctic matrix support
do not establish parity with those specialized searches. Reference:
https://www.imn.htwk-leipzig.de/~waldmann/talk/22/wst-cert/main.8.pdf

2026-10-15 follow-up: these specialized searches now have native opt-in atoms:

- `srs-context-closure(depth=1..3)` adds one complete layer of flat contexts
  to rules whose common prefix is shorter than the requested depth. Each
  layer is a separate guided state and standard CPF flat-context step.
- `srs-shift-labeling(memory=1..3)` constructs the full shift algebra directly
  from the live unary alphabet. It checks the model against every rule before
  emitting ordinary semantic labeling. Carrier size is capped at 256 and
  labeled-rule expansion at 100,000. No model enumeration or supplied labeling
  witness is used. Weighted SRS deletion now accepts the ordinary unary TRS
  residual emitted by labeling as well as a typed SRS state.
- DP `qpi(period=1..8,max-weight=0..64)` synthesizes monotone slope-one periodic
  functions in one QF_LIA query. Named, shared subterm/residue nodes avoid
  duplicated word encodings. The candidate is converted to integer-Arctic
  matrices and must pass the existing independent weak/strict orientation and
  well-formedness checks. No new certificate rule is trusted. This follows
  the representation in Koprowski–Waldmann, *Max/plus tree automata for
  termination of term rewriting*, Acta Cybernetica 19(2), 2009, section 9:
  https://cyber.bibl.u-szeged.hu/index.php/actcybern/article/view/3772

`native-shift-v25` and `native-shift-memory1-v26` add 25 distinct YES roots;
all pass witness-free oracle-only replay and two CeTA-CSR checks. Backward
closure exploration adds another 12 NO roots (`replay-native-backward-v23`).
The full release library suite passes 1,154 tests with none ignored. No default
strategy changes, benchmark-specific production data, or CeTA changes are
introduced. Quasi-periodic and deeper-tiling frontier runs are recorded under
`target/srs-native-20261013/`; only independently certified replays count as
oracle recoveries.

The QPI wave certifies four roots, with **Zantema_04/z023** new beyond the
tiling gains (1.035 seconds). All four pass witness-free replay and double
checks (`replay-native-qpi-v27`). The memory-three tiling wave adds no roots
on its 120-input slice. These measurements do not establish Matchbox parity.

`srs-canonical-weight-removal(max-weight=128)` is the renaming-stable weight
search used by the refreshed tiling guidance. It solves a canonical TRS,
maps weights back by the inverse symbol bijection, and independently validates
deletion on the live rules. The old weighted-search recipe is preserved.
All 28 tiling-route roots replay, and all 29 combined symbol-renaming/rule-order
tests certify twice after adding the newly exposed z114 DP continuation.
The updated full release suite passes 1,155 tests, none ignored. No CeTA or
default-strategy changes are required.

`nontermination(srs-loop(max-steps=N))` exposes the existing fixed-seed search
depth, with N between 1 and 1024. Renaming, parameter rejection, deadline, and
65-step-cycle regressions pass. Raising this limit to 256 alone recovered no
roots in the 225-root frontier; the successful context-extension search above
addresses a different limitation. No CeTA changes were needed.

`nontermination(srs-loop-deep)` synthesizes string loops using up to 256
overlap/concatenation contexts derived from live rule sides and up to 64 rewrite
steps. It retains the existing word-length/frontier limits and independently
rechecks every candidate against the input TRS. No start term, substitution,
or rule sequence is supplied by the oracle. The two-second default probe also
covers unary systems that match the transformed-CSR heuristic, without changing
native CSR or innermost dispatch. Nineteen previously unresolved SRS roots pass
both explicit and default search and CeTA rechecking. See the SOTA ledger for
artifact paths, replay scope, and the separate cross-category guard.

Native synthesis controls added in the final Standard recovery:

- `conditional-poly(induction=0)` preserves the automatic portfolio. Values
  1–3 select context, independent, or dataflow induction with merged bounds;
  4–6 select those shapes with split bounds; 7 combines independent and
  dataflow induction with split bounds. Explicit linear shapes with coefficient
  bounds at most two use shared finite-coefficient expressions, followed by
  the existing exact interpretation check.
- For ordinary minimal Q-DP states with normal-form substitutions and no weak
  pairs, `matrix(candidate=N,...)` can select ordinary-rule deletion directly.
  Candidates 1 through the strong-pair count retain their existing meaning;
  subsequent candidates address the active rule list. The existing certified
  Q-monotonic rule-removal processor checks the synthesized interpretation.
- Semantic labeling can jointly synthesize a nontrivial Boolean constant
  partition under conjunctive positive-arity interpretations. This uses rule
  equations and symbol arities, not benchmark names or supplied models.

These changes require no CeTA extension and do not restore composite proofs
or exact interpretation witnesses as oracle actions.

Native WPO weak lexicographic comparison now follows CeTA's complete tuple
check after a weak non-strict head; synthesis and exact validation agree.
Optional `ordered-alternatives=1` breaks only max-alternative representation
symmetry. Generic DP narrowing now backtracks across candidates, retaining
the existing active-R/Q checks. Strict oracle actions are independent of
search-local transformation-depth counters. The 1,115-test library suite
passes; the expanded cross-category replay remains the promotion gate.

Rational BV polynomial usable-rule search now activates individual
rules using the existing CeTA-style root-preserving cap/matching criterion,
rather than activating every rule with the same defined symbol. Active
argument traversal remains coefficient-induced. Matching is memoized across
repeated terms within each encoding; fixed usable-rule sets remain mandatory,
and synthesized interpretations still undergo the independent exact check.
This recovers `AProVE_06/identity` without its historical halving witness:
native discovery and two production CeTA checks pass, as does witness-free
oracle-only replay (`target/standard-nonloops-20261012/identity-rule-aware-v1/`
and `identity-rule-aware-oracle-v2/`). The full protected replay
`protected-refresh-v7/` certifies 1,294 Standard, 311 Innermost and 110 CSR
roots on the first pass. All 1,104 library tests pass. Native synthesis can
choose new models and residuals, so newly exposed states were independently
closed before this replay. An experimental extension to natural polynomials
was separated out rather than promoted; its artifacts remain in
`rule-aware-protected-v2/`. The production change is rational-only.
CeTA unchanged.

`nontermination(constructor-recurrence)` synthesizes a regular recurrent
language from live rules: a defined root over arbitrary ground constructor
arguments. It requires a nonempty constructor language, exhaustive shallow
linear constructor-pattern coverage, and preservation of the language by
every root rule. Constructor arities and defined-root arities are unrestricted;
there are no benchmark names or retained automata in the search. The resulting
`notWNTreeAutomaton` uses the existing CeTA decision procedure. Both retained
automaton gaps (`Zantema_15/ex14`, `payet_21/payet-nonloop-1`) pass independent
double certification and witness-free oracle-only replay. Full protected
replay establishes 1,289 Standard, 311 Innermost and 110 CSR certified roots,
all on the first attempt and independently rechecked twice.
Artifacts: `target/standard-nonloops-20261012/constructor-recurrence-v1/` and
`target/standard-nonloops-20261012/recurrence-oracle-only-v1/`. CeTA unchanged.

Native modular NO search now includes `nontermination-cycle(candidate=N,
min-length=L,max-length=U,repeated=0|1)`, `nontermination-narrow(candidate=N,
lookahead=0|1,all=0|1,below=0|1)`, and `nontermination-instance(candidate=N,
constants=0|1,all=0|1)`. Cycle restriction selects live pairs canonically;
`repeated=1` permits several pairs with the same marked root. NO narrowing
supports individual and region narrowings without incorrectly importing
termination-side linearity/coverage requirements. NO instantiation synthesizes
overlap unifiers or substitutions by live signature constants. These
transformations reconstruct only NO children; narrowing/instantiation require
empty Q and refuse unsupported relative/CSR contexts. Structural
`nontermination-rule-filter(max-lhs=N,max-rhs=M,collapsing=0|1)` is also NO-only.

`nontermination(dp-fork-loop)` derives fork seeds from live rule overlaps;
`nontermination(dp-fair-loop)` schedules bounded per-pair symbolic searches
and separately solves independent argument cycles before reconstructing a
checked whole-state loop. Backward loop search tries both 4,096-state modes
before widening to 65,536 states. All generated loops are independently
replayed and rule-checked, then certified with unchanged production CeTA-CSR.
These are explicit search lanes, not benchmark dispatch or supplied witnesses;
the CSR and Innermost default strategies are unchanged. Oracle exports retain
bare DP transformations and state-local nested actions, never discovery
pipelines attached to a root.

Native `conditional-poly(max-coefficient=N)` synthesizes conditional DP
reduction pairs with signed usable rules in one joint SMT query. Optional
`degree=2` includes squares and mixed monomials. `before=N,after=N` selects
bounded DP context (each at most three, total at most three); `reinduct=N`
allows at most three fresh inductions after explicitly deleting unusable
hypotheses. The default remains affine, with one predecessor and no
re-induction. `degree=2,squares=1` restricts rewrite symbols to affine
interpretations and DP-only roots to squares of homogeneous linear forms
plus constants. These are symbol-independent search restrictions, not supplied
interpretations. Arithmetic DAG sharing avoids duplicate SMT expressions;
every model undergoes independent checked arithmetic validation. Mixed-sign
positions require both usable-rule orientations. Square bounds are used only
where CeTA supports them, not to weaken usable-rule compatibility.

Conditional proof construction preserves enclosing inductions when an open
branch can instead discharge a stronger unconditional arithmetic obligation.
Unused fresh rewrite outputs are deleted explicitly; nested hypotheses match
modulo local binders with capture checks. If the ordinary context-rich proof
shape fails, a second, deadline-sharing shape can induct on an independent
predicate without unrelated premises. Both use existing CeTA proof rules;
neither supplies an interpretation. The context-rich shape remains first to
preserve quadratic predecessor proofs.
Nested induction implications additionally match premise permutations under
a shared substitution, with a bounded matching budget and capture checks.
This mirrors CeTA's premise-set semantics without changing the proof rules.

Exploration can set `FERRUM_DP_EXPLORATION_CONTINUATION_ATTEMPTS` (or the
frontier helper's `--continuation-attempts`) to bound the total descendant
attempts of each alternative. On exhaustion, the existing worklist resumes
untried siblings. Mandatory normalization is unaffected. The option is unset
in production and protected oracle replays; it changes search only, not
certification or processor applicability.

Native NO preprocessing now exposes `innermost-lhss-dp`,
`nontermination-usable-rules`, and `nontermination-innermost-lhss` as modular
actions. They preserve Q/NFS contexts, drop minimality where required, and
reconstruct only NO children. `switch-full-nontermination` checks overlay,
directed rule/pair overlaps, Q normal-form inclusion and weak confluence;
native loop search refuses unestablished normal-form substitution obligations.
These actions close the representation gap in 22 retained Standard NO proofs,
but do not themselves synthesize their inductive pattern non-loop terminals.

`nontermination(dp-nonloop)` now also performs bounded native pattern-rule
synthesis after a one-second elementary probe, then resumes the broader
elementary search if needed. It derives initial pumping substitutions
by renamed unification, checks commutation, normalizes pattern domains with
explicit equivalence proofs, combines auxiliary exit chains by pattern narrowing,
and supports consecutive marked steps at the root. Independent uses of a helper
receive fresh iteration variables. Closing checks the exact substitution-power
relation, including different left/right pumping rates; free variables are never
confused with bound iteration variables. Search is limited to 60 seconds (or
the caller's earlier deadline), three auxiliary exit levels, ten main levels,
and a 2,048-entry main frontier.
All seeds are live rules/pairs, with no imported witness trees or named-symbol
dispatch. CeTA's existing `Nonloop_Impl` accepts the native CPF operations;
no checker changes are required. Native rewriting searches the base and
pumping/closing images with explicit bounded live-rule rewrite chains.
Simplification factors closing contexts and equal iteration domains only when
composition and commutation hold. Context-growing initial pumping checks that
its seed contains no marked steps. Helper composition supports checked pumping
shifts, free-parameter restriction, and commuting extensions through closing
aliases. Closure unifies free exit parameters and explicitly proves irrelevant
context extensions before checking the global substitution equations.
Ground helper arguments are propagated from live calls, not enumerated or
supplied by the oracle. Alpha-invariant state keys suppress renamed duplicates;
constructor clashes and marked-root reachability prune dead search branches.
The complete 43-case retained pattern-nonloop inventory now has native certified
terminal and full-root proofs, recovering all 25 gaps left by the previous
18-case campaign. This is bounded synthesis, not a completeness claim for the
entire pattern calculus. See the SOTA ledger for protected oracle-only totals.

KBO/RPO
also have independently checked Q-aware argument-filtered usable-rule synthesis.
Both preserve residual contexts and use unchanged CeTA. See
[implementation limits and certification tests](innermost-conditional-qaf.md).

Polynomial usable-rule synthesis now shares arithmetic expressions and uses
reversible short query identifiers for long symbol names. Nested semantic-label
marked roles survive CSR residual import. See
[measurements, residual progress, and guards](innermost-residual-sharing.md).

This file is an implementation inventory, not a benchmark result. "AProVE count"
means the number of TermCOMP 2025 certified AProVE YES proofs in the local proof
corpus whose CPF contains the named processor/tag. Counts overlap because one
proof can use several processors.

Bounds normalization is currently opt-in and non-destructive. The
`normalize-bounds(strategy)` meta-strategy preserves all existing search
processors and rewrites only a successful proof: absolute bounds become
all-rule relative bounds, absolute RFC bounds become their relative forms, and
native Matchbox-relative RFC becomes the established Matchbox-relative form.
The retained regression corpus has 330 certified bounds proof artifacts over
319 distinct SRS examples. All 330 normalized artifacts re-certified with zero
checker failures and zero checker timeouts. Processor and proof-form removal
remains deferred while the independent current RFC native-validation search
regression is investigated. That investigation found that native validation
need not remain after consolidation: relation-preserving native witnesses
reduce to the established Matchbox-relative checker, and the identity-native
form is strictly more restrictive. Production RFC search now validates and
emits canonical Matchbox-relative proofs directly. Native checker support,
proof variants, helper code, and tests remain available but are no longer
called by the production search path.

## Implemented Processors

Native improved-CS-DP graph search now uses the explicitly frozen fresh
unhiding wrapper already used by CPF export and exact-graph validation. It
retains context-keyed native graph caches; only exact-witness validation
forces its existing fresh graph check. This restores live/materialized
agreement and enables a parameter-only csrdiv root proof. No source rule or
original-symbol replacement-map entry is changed, and CeTA is unchanged.
See [the five-root follow-up](csr-witness-free-five-followup.md).

**Native WPO synthesis:** `wpo-max` jointly synthesizes a max-polynomial base,
precedence, identity/collapsing argument filters, and partial left-to-right
lexicographic statuses. Optional `permutations=1` jointly synthesizes arbitrary
partial lexicographic statuses using bounded position variables and shared
comparison DAGs, not permutation enumeration. Multiset statuses remain outside
this search. `compact-ground=1` shares ground max subterms through exact scalar
SMT nodes, avoiding redundant expansion. It defaults on for the new permutation
lane and off for legacy statuses: the equivalent compact encoding can still
make existing solver queries harder. Either setting is available explicitly.
Its models pass the independent WPO evaluator before CPF
construction. Native search recovers Ex3_2_Luc97 and Ex5_7_Luc97; both complete
root CPFs pass CeTA twice. The witness-free converter keeps the WPO family
rather than incorrectly replacing it with plain `max-poly`.
See [native WPO and sparse quadratic synthesis](native-wpo-and-sparse-quadratic.md).

Non-minimal CSR order search now treats an explicitly established local R as
fixed, rather than attempting another argument-filtered usable-rule reduction.
This recovers native polynomial continuations previously rejected at their
minimality boundary. Max-polynomial synthesis now constrains **every** pair
weakly outside the strict-pair disjunction. For 0/1 coefficients it uses an
equivalent conditional encoding in linear integer arithmetic, retaining the
independent model validator.

`rat-quadratic-poly(max-constant=4,max-coefficient=4,denominator=2,delta-denominator=2,solver=z3)`
is an explicit degree-two rational search entry, bypassing affine-first
scheduling. `solver` is optional (`z3` or `cvc5`). This direct route clears
denominators exactly to integer constraints; checked scaling overflow declines
the encoding. Optional `coefficients=0+1+2+4` restricts the global numerator
alphabet, `quadratic-terms=1` limits nonzero quadratic monomials per symbol,
and `quadratic-shape=multilinear|unary-squares` excludes squares globally or
permits them only for unary symbols. These assign no symbol's interpretation;
all choices are synthesized. Restricted native search recovers ExIntrod_Zan97
and emmes with twice-certified complete root proofs. The existing `rat-poly`
portfolio is unchanged. Model validation
and CPF certification remain mandatory. The converter preserves small strict
gaps by selecting a common coefficient/gap denominator, and supports CPF
max-polynomial and natural weak-polynomial search bounds without assignments.
These are general processor changes, with no benchmark-name dispatch or
retained order embedded in Ferrum. CeTA did not change.

Native `usable-rules` now supports typed MU-TERM components, computing the
pair-local obligation from live rules and generated unhiding bridges.
Subsequent reduction pairs retain an explicitly established local R instead
of re-appending bridges or inventing another usable-rule restriction.
The recursive MU-TERM route deletes pairs only and emits `redPairProc`,
matching the existing verified checker rather than emitting unsupported
monotonic rule deletion. Ex1_GM03 has a full CeTA-certified parameter-only
oracle replay with five further certified repeats. Standalone CPF export for
its new non-minimal typed local children remains unsupported; no independent
child-certification credit is claimed. See
[the witness-dependence audit](oracle-modularity-and-witness-dependence.md).
CeTA is unchanged.

`gm04-source-csr` is a native, name-independent DP transformation for the
GM04 top-pair residual. It checks the transformation schema, active rules,
Q and chain conditions, then exposes the source CSR as an independently
guided child. Production CeTA main `73662ec` checks that CSR proof and
discharges the precise DP premise; standalone DP and nested TRS certificates
both work. Missing source proofs and changes to roles, Q or the replacement
map are rejected. This is not a complete-proof oracle action.

Source-bound modular Q choices, DP transformations and top-level polynomial,
matrix and KBO witnesses now relocate through a complete state isomorphism.
CSR order relocation additionally checks the replacement map. Exact-key
advice remains first, with portable canonical alternatives available after
failed choices. No benchmark-specific dispatch or production witness was added.

Complete TRS/DP proof oracle actions, for both termination and nontermination,
are retired with unconditional parser/execution assertions. Primitive NO
terminals remain source-bound modular witnesses. Newly exposed standalone NO
boundaries include full-TRS rule deletion (retained rules must be a subset),
Q reduction using CeTA's signature/NF criterion (minimality is cleared), and
rewriting/narrowing with explicit Q coverage. Complete NO instantiation uses
CeTA's replacement semantics and independently checks every displayed pair
as a simultaneous instance of an original pair. These use existing CeTA
processors; no checker extension was required. Replay status and limitations:
[oracle modularity](oracle-modularity-and-witness-dependence.md).

| Area | Processor | Certification status | Current limitations / improvement needed |
| --- | --- | --- | --- |
| Top-level YES | Empty system | CPF-certified | Complete for empty TRSs. |
| Top-level YES | Linear polynomial rule removal | CPF-certified | Recursive monotone rule removal with one-shot SMT synthesis for each residual TRS. After a successful removal, a five-second focused DP continuation tries graph decomposition, monotonic polynomial deletion, graph decomposition, and a 1D natural-Arctic order before the broad residual portfolio. This AProVE-shaped continuation recovers `Secret_06_TRS/5`; the default strategy races rule removal among the early orders. Still linear naturals; next improvement is broader polynomial/max-polynomial classes. |
| Top-level YES | KBO rule removal | CPF-certified | Monotone full-TRS KBO rule removal with no argument filtering. Precedence and weights are synthesized in one QF_LIA solver query, then rechecked by Ferrum before CPF export. |
| Top-level YES | Path-order rule removal | CPF-certified | YES branch only; argument-filter use is restricted to known sound top-level cases and should remain audited against CPF/CeTA. |
| Top-level YES | Applicative uncurrying | CPF-certified | Supports an explicit binary `app` symbol and conservatively infers a differently named application symbol when it is the unique binary symbol and every other symbol is nullary. Left-hand sides with variable-headed application are rejected. Ferrum emits standard CPF `<uncurry>` information and CeTA recomputes the transformed TRS. The Standard continuation exhausts productive monotonic polynomial rule removals before entering its residual DP portfolio; this matches the certified AProVE shape for `Zantema_05/z07` and also retains `z05`. A separately capped 20-second switched-innermost continuation covers the certified AProVE shape using 1D Arctic deletion, bounded narrowing/rewriting/forward instantiation, and repeated 3D Arctic/KBO/SCT cleanup. The default Standard and effective-SRS strategies race bounded uncurrying against their other processors. Broader mixed-signature inference is intentionally not attempted without additional applicative-signature evidence. |
| Top-level YES | Unary TRS to SRS transformation | CPF-certified when followed by certified processor | Complete and sound for termination: a TRS over only 0-ary and 1-ary symbols terminates iff the transformed SRS terminates. Constants are treated as string letters; variables are ignored. Currently used by the strict string-length processor below. |
| DP transformation | Two-stack QDP to SRS | CPF/CeTA-CSR-certified | Applies only after Q, strict/weak rules, and weak pairs are empty. Productive pairs `f(x,C(y)) -> f(D(x),y)` generate `C -> reverse(D)`; transfer pairs `f(a(x),y) -> f(x,a(y))` decrease the secondary left-stack measure. The generated SRS is a typed ordinary child with independent strategy/oracle lookup. The default AAECC route certifies `Zantema_05/{z12,z13}`; malformed stack shapes are rejected before proof construction and by the executable checker. |
| Top-level YES | SRS match-bounds and string reversal | CPF-certified with `<bounds><match/>` and `<stringReversal>` | Implements the FULL online construction of Endrullis et al. (2006): maximum-bottleneck redex paths, minimum-height pivots, left/right inverse context transitions, and height-sensitive cancellation to epsilon closure. Only original-symbol and epsilon transitions are exported, and CeTA rechecks the resulting ordinary bounds certificate. Strict TPDB SRSs and cons-encoded TRSs use the same construction; the latter are lifted back to their original ranked signature before certification. String reversal is first-class for ordinary and relative SRSs: relative reversal preserves and records both strict and weak components, and CPF recursion remains relative. Successful involutive cycles are suppressed independently of timeout wrappers. The 2026-08-11 v722 SRS Relative portfolio obtains 94 certified YES with no certification failure, up from 6 before this work. Remaining Matchbox-level gaps are compact state quotienting, preprocessing/strictification, and tighter RFC integration. |
| Top-level YES | SRS RFC match-bounds | Finite RFC, automaton-closed RFC, and Matchbox-style relative RFC witnesses are CeTA-certified in the local checker | Implements finite right-forward-closure match-bounds for strict TPDB-style SRS encodings via `rfc-match-bounds(...)`. The finite path computes the bounded RHS forward closure, fails instead of truncating when word/count caps are exceeded, and emits CPF3 `<rfcBounds>` certificates. The CeTA-rfc tree has verified `<rfcAutomatonClosedBounds>`, `<rfcAutomatonClosedRelativeBounds>`, and `<rfcMatchboxRelativeBounds>` checkers. Ferrum constructs Matchbox-style place-state `RelRFCmb` witnesses for `rfc-relative-match-bounds(...,at-bound=merge)`, including RHS initial acceptance, below-top strict compatibility, right-extension closure, no top redex for deleted rules, weak compatibility of residual rules, and recursive proof of the residual. The paired-tail fixed point uses indexed bitset word evaluation, batched epsilon closure, epsilon-SCC quotienting, canonical-tail completion for missing RHS runs, and strict compatibility completion. It tries barren witnesses across all bounds before expensive one-state/generic fallbacks. Every candidate is revalidated before CPF export. Canonical validator reconstruction also computes epsilon closure in one bitset batch instead of incrementally. The fixed 189 direct RFC examples give 189 YES and 189 certified YES with no timeout or checker failure in the consolidated run. The `ferrum-rfc-native` CeTA branch and Ferrum source retain `<rfcNativeMatchboxRelativeBounds>` support, identity/epsilon witnesses, mixed-height splice checking, and relation-preserving native word-run witnesses, but production search no longer invokes or emits that redundant native form. Remaining Matchbox-power gaps are preprocessing/strictification, reversal/RFC integration, stronger transformations, and broader partial deletion outside this direct RFC slice. |
| Top-level YES | SRS relative match-bounds | CPF/CeTA-certified | Ferrum emits `<relativeBounds>` and always recurses on the relative residual `(R \\ Rdelete)/(Rw union Rdelete)`, including when the input was initially ordinary. Strict compatibility checks every bounded cover redex; weak-rule heights follow CeTA's exact `Weak_TRS c_opt` definition. Empty-word left-hand sides are declined because CPF's unary-TRS representation fails CeTA's well-formedness condition. Real certified `SRS_Relative` examples include `Mixed_relative_SRS/{zr03,zr05,zr06}` and `Waldmann_06_relative/r9`. Next work is stronger state merging and Matchbox/AProVE-guided branch ordering. |
| Top-level YES | Relative monotone polynomial rule removal | CPF/CeTA-certified | First-class `TRS_Relative` and `SRS_Relative` inputs partition ARI rules by `:cost 0`. One SMT query weakly orients every rule in `R union S`, strictly orients at least one rule in that union, and deletes every strictly oriented rule from its strict or weak component. Solver models are rechecked in Rust before `<ruleRemoval>` is emitted. Relative polynomial, matrix, and SRS-bounds branches race after every successful deletion. Real certified examples include `TRS_Relative/Relative_05/{rt1-1,rt1-2,rt1-5,rt2-7}.ari`. |
| Top-level YES | Relative matrix rule removal | CPF/CeTA-certified | One-shot QF_BV synthesis supports configurable natural and integer matrix interpretations with strict dimension 1 and full monotonicity on every argument; no whole-TRS argument filtering is used. `matrix(...)` and `integer-matrix(...)` are distinct strategy atoms, and the SRS Relative default races bounded dimensions 2 and 3 after reversal, flat-context closure, and semantic labeling. Every rule in `R union S` is weakly oriented, and every strictly oriented rule may be deleted from either component. Exact Rust replay rejects invalid solver models, and the winning domain is emitted in ordinary CPF `<ruleRemoval>`. On the earlier 33 AProVE-certified matrix-proof gaps, Ferrum obtained 31 certified YES with no checker failure. Remaining matrix work is stronger model objectives and broader literature-backed matrix classes. |
| Top-level YES | Relative KBO and path-order rule removal | CPF/CeTA-certified | One-shot SMT synthesis weakly orients `R union S` and deletes strict rules from either relative component. KBO searches admissible symbol weights and precedence. Path orders search precedence plus lexicographic/multiset status with identity non-collapsing filters only; no whole-TRS argument filtering is performed. Both branches use exact Rust replay and run in the recursive parallel relative portfolio. |
| Top-level YES | Relative finite root-equivalent semantic labeling | CPF/CeTA-certified | Builds a finite model whose carrier represents function roots and whose interpretation maps each symbol to its own root. Every variable valuation is labeled, strict/weak membership is preserved, and the complete labeled union is emitted through CPF `<semlab>`. The transformed problem is sent once through the full parallel relative portfolio, with repeated semantic labeling disabled on that branch. `TRS_Relative/AProVE_24/depGraph.ari` now certifies in 0.118 seconds. Remaining semantic-labeling work is broader finite/quasi-model synthesis. |
| Top-level YES | Relative flat-context closure | CPF/CeTA-certified | Constructs the complete set of one-hole flat contexts for every symbol argument position. Root-preserving rules remain unchanged; every root-altering strict or weak rule is closed under every generated context, with strict/weak ownership preserved. CPF emits native `<flatContextClosure>`, after which semantic labeling and the recursive relative order portfolio run. This certifies `TRS_Relative/Relative_05/{rt3-4,rt3-5}.ari`, closing the two transformation-assisted matrix residuals. |
| Top-level YES | IJCAR 2024 relative annotated dependency pairs | CPF-certified: canonical construction, productive graph decomposition, monotone erasure reduction pairs, polynomial `Com` reduction pairs, and DRP1 | Ferrum constructs canonical A1/A2 ADPs and schedules dependency-graph processing after every ADP transformation. CeTA recomputes graph children and all processor residuals. The `Com` processor checks weak orientation of every flattened ADP and annotation-summary constraint, strict orientation of every selected constraint, and the finite commutativity, associativity, projection, and empty-summary laws. Its fully mechanized step-lifting proof covers marked and unmarked steps, fresh and transported annotations, duplicated RHS variables, rewriting above or parallel to annotations, and discarded annotations. Ferrum emits total additive witnesses with `Com0=0` and `Com2(x,y)=x+y`. DRP1 computes `(DP(P), flat(P union B))` inside CeTA and invokes the ordinary nonminimal DP checker recursively. |
| Top-level NO | Relative loop | CPF/CeTA-certified | Runs concurrently with the relative termination portfolio and searches `R union S`. A witness is accepted only if every rewrite step belongs to the union and at least one step uses a strict rule from `R`; weak-only steps are emitted with CPF `<relative/>`. Search combines grounded rule-side and proper-subterm seeds, fair shallow strict-state-aware rewriting, weak-first contextual narrowing, and path-sensitive recursive symbolic closure before deeper rewriting. Cancellation stops sibling order solvers when a certified NO is found. Ferrum certifies all 11 AProVE_cert TRS Relative NOs plus both uncertified-only AProVE NOs (13 distinct examples). |
| Top-level YES | SRS strict / weighted length decrease and weighted rule removal | CPF-certified as linear polynomial / polynomial rule removal | SRS/unary fast paths using fixed length, SMT-synthesized weighted length, and `srs-weighted-rule-removal(max-weight=N)`. The rule-removal variant weakly orients every SRS rule, removes all strictly decreasing rules, and recursively proves the residual system with ordinary certified processors. Symbol weights may be zero when accepted by the polynomial certificate. Sound but not complete as proof methods. |
| Top-level YES | Dependency pairs | CPF-certified when subproof processors are certified | Main production path; strategy language controls nested DP processors, parallel portfolios, and local timeouts. Parallel branches now use scoped cancellation: the first successful branch cancels siblings and kills their running solver subprocesses. Full 60s/128-worker TermCOMP runs `target/termcomp-runs/20260714-174942-full-128-60s-q-iedg` and `target/termcomp-runs/20260714-component-portfolio-128-60s` had 0 YES/NO certification failures. |
| Top-level YES | CSR polynomial rule removal | CPF4/CeTA-CSR certified | A single QF_NIA optimization query enforces weak orientation of every rule and replacement-map monotonicity, maximizes the number of strictly oriented rules, and returns one model that Ferrum rechecks. The residual CSR is passed to arbitrary later CSR processors; repeated rule removal is strategy composition, not recursive enumeration. |
| Top-level YES | CSR matrix rule removal | CPF4/CeTA-CSR certified | One-shot QF_BV synthesis supports natural matrix interpretations on active replacement-map positions. Ferrum validates the model and removes every strictly oriented rule. CeTA-CSR has a verified active-position monotonicity checker and rejects both inactive/invalid coefficients and certificates without a strict rule. Dimension 2 adds four certified YES results on the 2025 CSR slice. |
| Top-level YES | CSR strategy composition | CPF4/CeTA-CSR certified when the selected leaves certify | CSR processors return closed, transformed-residual, or failed outcomes. Sequences operate on the current residual; choices retain the strongest residual; parallel branches use Rayon child scopes and cooperative subprocess cancellation. The default 300-second CSR portfolio races direct QCS-DPs, rule-removal then QCS-DPs, innermost equivalence then QCS-DPs, and their composition. |
| Search architecture | Typed processor transitions | Recursive DP/CSR/TRS guidance implemented; remaining adapters tracked | The common scheduler vocabulary is `Solved`, `Transformed(residual, context)`, `Inapplicable`, `Failed`, and `TimedOut`. TRS, SRS, CSR, and DP are typed proof states rather than separate notions of search. Every exposed DP residual re-enters utility guidance, with branch-local cycle detection and failed-state memoization. Ranked atomic alternatives backtrack when a transformed child cannot close instead of treating transformation as success. A processor atom is reusable across states only when its applicability theorem and complete checker-relevant state are represented; for example, a CSR-DP proof must not be flattened to an underspecified ordinary `dp` atom. |
| Top-level YES | Native, safe, conservative, and improved CSR dependency pairs | CPF4/CeTA-CSR certified | Native replacement-map DPs are tried first, followed by safe ordinary DPs and verified conservative and improved LPAR'08 constructions. The improved path includes the CAP/Ren graph approximation and certified mixed marked/fresh-unhiding subterm deletion for minimal chains. The conservative construction remains available for systems outside the improved processor's applicability conditions. |
| DP | Ordinary dependency-pair transformation | CPF-certified | Implements IsaFoR's exact `DP_on` construction: a defined-root RHS candidate is omitted when it is already a proper subterm of the source LHS. This is the standard subterm-pruned classical DP variant checked by CeTA, not a dependency-graph approximation. Specialized conservative CSR construction continues to retain its deliberately complete pair set. |
| Top-level YES | `switchInnermostProc` / innermost switch | CPF-supported in selected proofs | Overlay plus WCR guard with increasing `joinAutoBfs` depths up to 32. The residual innermost problem now uses the full default innermost DP portfolio, including Q-aware narrowing, instantiation, rewriting, graph decomposition, and reduction pairs. The previous narrowing-disabled switched strategy was removed. The WCR/applicability test remains conservative. |
| DP | `switchInnermostProc` | CPF-certified | Implements CeTA's DP-level switch for ordinary minimal DP problems with empty `Q` and no strict rewrite rules. It rejects every rewrite-rule overlap at a non-variable position of a DP left-hand side, certifies weak confluence of the active weak rules with `joinAutoBfs`, and continues with `Q = lhs(R)` under innermost rewriting. The Standard strategy applies it after SCC decomposition and immediately decomposes again after every subsequent DP transformation. This recovers `Secret_05_TRS/aprove4`. |
| Top-level YES | Innermost non-applicable rule removal | CPF-oriented | Removes innermost rules whose LHS contains a proper non-variable subterm that is an instance of a rule LHS, so the rule can never fire at an innermost root. Still conservative beyond this direct non-applicability criterion. |
| Top-level NO | Variable condition violation | CPF-certified | Complete for this simple NO witness. |
| Top-level NO | Direct loops / bounded loop discovery | CPF-certified for supported loop shape | Direct one-step loops plus BFS bounded rewriting loops up to 6 steps, SRS word loops in both forward and reversed string orientations, symbolic narrowing loops, DP loop hints, DP rewriting, and DP instantiation over a bounded two-round unary/binary ground-term closure (at most 512 terms). The second closure round exposes nested witnesses such as `cons(s(a),s(b))` and recovers `Secret_05_TRS/ttt1`. Reversed SRS search is reflected into an ordinary loop over the original TRS before being accepted, and the default SRS NO strategy also races the original branch against certified strategy-level `<stringReversal>`. |
| Top-level NO | SRS derivation patterns | CPF-certified | Emits native CPF `<nonterminatingSRS>` proofs with chronological derivation-pattern steps and a fitting self-embedding pattern. The symbol-independent search schema recognizes word-context commuting pumps `aL -> La`, `Ra -> aR`, `P L -> P R`, and `R Q -> L a Q`, proving `P R a^n Q ->+ P R a^(n+1) Q`. It certifies `Zantema_15/ex01` and `ex04`; the processor-only AProVE ten-example SRS-NO slice gives 2 certified NO and 8 MAYBE. Ferrum's complete default portfolio certifies all ten because ordinary loop processors already handle the other eight. General overlap-closure/pattern saturation remains to be implemented. |
| DP | Dependency graph SCC decomposition | CPF-certified | Uses EDG for standard TRSs, a conservative Q-aware IEDG inside innermost/Q contexts, and replacement-map-aware graph estimation for native QCS-DPs. Both cap directions and the pair-local usable-rule reverse direction are computed for precision, but every IEDG edge is retained independently: IsaFoR proves `DG ⊆ IEDG`, while requiring Ferrum's separately reimplemented CAP/nonreachability filters to agree caused an uncertifiable `jwteparla2` split. Residual Q is recomputed after DP transformations. Remaining work is preserving the exact QCS context through every context-sensitive transformational DP step. |
| DP | Split processor | CPF-certified | First-class `split` partitions a DP problem into a selected relative branch and its residual branch. The selected branch retains the complement as weak pairs, both branches receive the remaining pipeline continuation independently, and CPF emits native `<splitProc>`. Reduction pairs and semantic labeling preserve the strong/weak partition; absolute SCT over the union is also accepted as a sound proof of the relative branch. Production CeTA regressions cover polynomial and SCT continuations. |
| DP strategy | Pipeline | Proof-producing meta processor | `pipeline(...)` passes only the unexecuted suffix to recursive DP processors, so transformations compose without restarting the enclosing strategy. Every DP/CS-DP transformation is followed by an explicit graph stage when that stage appears in the strategy. This is distinct from the legacy recursive sequence behavior and is used for proof-evidence-shaped narrowing/split/labeling chains. |
| DP | Ordinary uncurrying and DP-to-relative-TRS | CPF-certified | `uncurry-below` applies CPF's ordinary uncurrying processor below applicative-top uncurrying, including an injective mapping for symbols that occur only in dependency pairs. Generated uncurrying rules remain weak ordinary rules, so a subsequent certified usable-rules reduction pair can remove them from the live obligation. `switch-to-trs` then preserves strict/weak pairs and rules exactly as a relative TRS and hands the child to the relative portfolio. On the exact `Secret_07_TRS/4` A/RFC residual, `uncurry; uncurry-below; mono-poly; switch-to-trs; relative-match-bounds` replaces AProVE's opaque A-transformation/RFC fragments with a complete CPF accepted twice by production CeTA-CSR. Root recovery still requires regenerating AProVE's earlier checker-rejected usable-rules witness with a valid Ferrum witness. |
| Top-level strategy | Shape predicates and focused scheduling | Strategy meta processing | Conditions include TRS kind, SRS/applicative/transformed-CSR shape, `rules-at-least(N)`, and `rules-at-most(N)`. Applicative Standard TRSs receive an isolated bounded uncurrying attempt before the broad portfolio. Small Standard and transformed-CSR systems receive a bounded first-class DP pipeline attempt. These schedules recover default certified proofs for `Ex6Recursor`, `Applicative_first_order_05/13`, and `JFP_Ex31` without changing processor semantics. |
| DP | Usable rules processor | CPF-certified | Standard full-rewriting DP contexts compute CeTA's precise `check_ur_P_closed_rm_af` closure: an omitted rule is added only when its LHS matches the root-preserving `tcapRM2` of an active DP/usable-rule RHS subterm. Argument-filtered reduction pairs use all immediate argument caps for this LHS match and recurse only through filter-active positions, matching `matchCapRMBelow` instead of collapsing to a root-symbol approximation. The closure is recomputed in every residual `R`; empty certified closures are preserved explicitly. Innermost Q remains a separate normal-form/minimality context. Remaining work is broader usable-replacement-map support. |
| DP | Innermost LHS removal / Q context | CPF-certified for accepted nested proofs | Implements CeTA's executable `q_reduction_proc_min_inn` witness construction: retain current Q-LHSs whose arguments are Q-normal, then retain only roots occurring in the current dependency pairs or active usable rules. Empty residual Q is preserved as a real context. The result is consumed by Q-aware IEDG and recomputed after narrowing, instantiation, rewriting, and pair deletion. Every residual polynomial/algebraic reduction-pair search includes rules represented by retained Q, even when ordinary DP usable rules are empty. Path-order Q compatibility remains guarded separately. |
| DP | Subterm criterion / size-change | CPF-certified | Split into a projection `subterm` processor and a separate `size-change`/`sct` processor. Projection selection is a one-shot QF_LIA query with no symbol cap; the concrete model is rechecked. Safe/minimal DP problems emit native CPF `subtermProc`. Replacement-map improved Q-CSDPs use CeTA-CSR's dedicated size-change proof or the mixed marked/fresh-unhiding subterm checker; Ferrum requires minimality and delegates the concrete projection obligation to that executable checker. Native innermost CSR-DPs may also use SCT without a global minimality flag when every active target argument is an active proper subterm of its pair source; CeTA-CSR checks this coverage independently. Pure SCT first checks the ordinary global closure over all pairs, then may use the current Q-aware IEDG successor relation. The global check also safely closes relative DP states when the union of strong and weak pairs terminates, as certified in a production CeTA regression. Remaining work is partial relative SCT deletion and further usable-rule refinements. |
| DP | Symbol weights | CPF-certified through polynomial encoding | Useful cheap reduction pair; lower priority than KBO/path orders/polynomials. |
| DP | Linear polynomial (`poly`, `sat-poly`, `mono-poly`) | CPF-certified | One-shot BV search over natural linear interpretations. A single Z3 Optimize query jointly synthesizes coefficients, weak/strict pair orientation, and the interpretation-dependent usable-rule fixed point induced by positive coefficients. Its explicit lexicographic objectives maximize strict DP deletion, minimize activated usable symbols, and minimize the sum of interpretation parameters; every objective width covers its full range. The decoded model and exact filtered closure are rechecked before CPF emission. Fully monotonic residual search is also a first-class parameterized `mono-poly` strategy processor rather than a deadline-starved fallback. It can remove strict rules as well as strict DPs, emits their exact sets in `monoRedPairProc`/`monoRedPairUrProc`, immediately decomposes the residual graph, and repeats. A pure usable-rule restriction is accepted as progress only when it strictly reduces the current `R`. The default Standard strategy races both the existing small-coefficient searches and a separate 30-second graph/polynomial/SCT portfolio with constants and coefficients up to 5. Keeping the latter separate from scalar-Arctic synthesis reduces solver contention and recovers the focused certified `Ex49_GM04_iGM` witness, although that example still misses the full default wall-clock budget under contention. Top-level rule removal still requires the monotonicity needed by its processor. |
| DP | Quadratic natural polynomial (`quadratic-poly`) | CPF 3/CeTA-certified | One-shot QF_NIA synthesis supports constants, every linear monomial, squares, and mixed monomials such as `x1*x2`. Linear coefficients are positive and all other coefficients nonnegative, ensuring monotonicity. Ferrum exactly rechecks every solver model before emitting a degree-2 CPF polynomial interpretation. The processor is part of the default parallel DP order portfolio. Higher degrees and sparse monomial selection remain future work. |
| DP | Weak polynomial (`weak-poly`) | CPF 3/CeTA-certified | One-shot quantifier-free SMT search synthesizes affine interpretations with constants in `[-2,2]` and coefficients in `[0,2]` directly against CeTA's executable `Pleft`/`Pright` sufficient comparison. Left constants are clamped only for ground subterms and right constants at every application; Ferrum independently replays those exact constraints before proof construction. This supports the negative constants used by certified proofs such as `factorial1`, `tower`, `AProVE_07/thiemann09`, and the first reduction of `MNZ_10/9`, while rejecting the former uncertifiable `tpa2` and `Zantema_05/z07` witnesses. The default strategy retains its dedicated early chain and also pairs it with ordinary integer matrices in a bounded branch. |
| DP | Max-polynomial (`max-polo`, `max-poly`) | CPF 3 `<maxPoly>` certified by CeTA smoke test | New one-shot QF_NIA search over max of affine nonnegative branches. Current orientation is sound but conservative: every RHS branch must be dominated by an LHS branch with strict constant progress for strictness. |
| DP | Rational polynomial (`rat-poly`) | CPF-certified | Checked structural candidates are tried before solver synthesis, matching Ferrum's LLM-first candidate/validator architecture. Linear fixed-denominator search is one exact QF_BV query: it jointly synthesizes numerators, strict deletion, argument filtering, and the induced `matchCapRMBelow` usable-rule fixed point. Nested terms are rescaled exactly, the bit width is derived from checked expression bounds rather than capped, and every decoded model is independently rechecked over exact rationals before CPF emission. Coefficient and strict-gap denominators remain independently configurable (`denom` and `delta-denom`); accepted models are normalized to one common denominator and emitted as rational natural-polynomial `redPairUrProc` proofs. This recovers the denominator-64 AProVE shape for `AProVE_07/kabasci03` in about three seconds in isolation and as a default CeTA-certified YES. Quadratic rational search remains nonlinear SMT. |
| DP | Matrix interpretations (`matrix`, `matrix1`, `matrix2`) | CPF-certified | One-shot QF_BV search supports bounded natural matrices including dimension 4. Arithmetic uses the exact overflow-free width for the requested finite class; reconstructed models are validated with unbounded natural arithmetic. Dimension-1 jobs use cvc5 and higher-dimensional jobs use deterministic Boolector/CMS search. In innermost/Q states, the same atoms can synthesize Q-monotonic rule deletion without requiring a dependency pair to be strict; Ferrum independently rechecks the complete live pair/rule orientation and emits CPF3 `innermostMonoRedPairProc` with the exact deleted rules. Recursive residual rule deletion is supported and production CeTA-CSR certified both exact and synthesized multi-step proofs. Marked-symbol rows outside the strict dimension, and cancelling marked-root constants, are normalized soundly. A sparse 2D class with at most 12 nonzero entries recovers the certified `jwmatchb1/2` witnesses. The early Standard strategy also races a cheap `mono-poly`/graph continuation into 3D natural-Arctic and 2D natural matrices. This closes both components of `Endrullis_06/linear2`; AProVE's second witness is declared over integers but contains only nonnegative `0/1` entries, and Ferrum independently validates a natural-domain witness. The same branch finds a faster certified natural-matrix continuation for `pair3swap`. |
| DP | Integer matrix interpretations (`integer-matrix`) | CPF 3/CeTA-certified | One-shot signed QF_BV synthesis supports integer constant vectors and componentwise nonnegative coefficient matrices, exactly the carrier accepted by CeTA's generic reduction-pair implementation. Symbolic orientation and independent concrete replay implement CeTA's componentwise `Pleft`/`Pright` clamping. This is a DP reduction pair, so it does not impose the strict monotonicity condition required by top-level `monoRedPairProc`. CPF emits an explicit `<integers/>` domain. The default Standard strategy races weak-polynomial-then-integer-matrix and integer-matrix-first branches, with graph decomposition after every deletion. Production CeTA certifies the resulting `MNZ_10/9`, `Secret_06_TRS/6`, `Zantema_05/z26`, and `Endrullis_06/linear1` proofs. Larger dimensions and broader finite coefficient classes remain search-strengthening opportunities. |
| DP | Arctic matrix interpretations (`arctic-matrix`, `integer-arctic-matrix`) | CPF-certified | Natural Arctic uses one-shot bounded synthesis followed by exact concrete validation. Exact natural-Arctic witnesses now derive the usable-rule closure from precisely those argument positions whose distinguished matrix entry is finite, then independently orient that closure before emitting `redPairUrProc`; production CeTA accepts the focused positive proof and the complete `AProVE_07/wiehe07` chain. The integer-domain processor uses one QF_LIA query with separate finiteness bits and signed finite values, so `-infinity` is never conflated with a finite sentinel. Decoded models are independently rechecked, including CeTA's requirement that every interpretation have a nonnegative distinguished constant or `(1,1)` argument entry. CPF export selects `<naturals/>` or `<integers/>` explicitly. The tightly bounded 1D integer branch recovers `AProVE_08/thiemann40_modified` as a default CeTA-certified YES. The natural branch retains the certified scalar and 3D gains for `wiehe11`, `wiehe01`, `Ex9_BLR02_FR`, and `Ex4_7_56_Bor03_iGM`. Joint synthesis of the interpretation and its induced usable-rule fixed point, plus signed dimensions above one, remain future work. |
| DP | RPO/LPO with argument filtering | CPF-certified | One complete SMT search jointly chooses precedence, argument filter, per-symbol lexicographic or multiset status, and the argument-filter-dependent usable-rule closure. Rules are required weak only when their defined root is symbolically reachable through retained positions; the resulting model is then rechecked against the exact CeTA-style usable-rule closure before proof construction. Fixed-rule and strict-rule contexts still orient every required rule. Z3 and cvc5 race on the same formula and a decisive result kills the sibling subprocess. Certified models can be retained as `exact-path-order` atoms; replay rechecks the complete live weak/strict, usable-rule, Q, status, and filtering obligations before deletion, eliminating solver-race residual drift. Empty non-collapsing filters are supported. Symbols equivalent in a quasi-precedence have compatible statuses, and weak orientation uses induced term equivalence rather than syntactic equality. Multiset status uses the full multiset extension. Every DP deletion is followed by dependency-graph decomposition. The generic synthesis formula still expands filtered-term alternatives; a polynomial-size per-position Boolean encoding remains desirable for fresh search. |
| DP | KBO with argument filtering | CPF-certified | One-shot SMT search jointly synthesizes precedence, filter, weights, weak/strict pair orientation, and the AF-dependent usable-rule fixed point. Ferrum independently recomputes the active-position closure and validates admissibility and every KBO comparison before emitting CPF. This recovers both `AProVE_04/IJCAR_26` variants and their collapsing-filter/empty-usable-rule proofs. A checked applicative path still supplies validated 3D/4D natural-Arctic and KBO witnesses for recurring uncurrying shapes such as `Zantema_05/z01`. More AProVE proof regression coverage and larger-weight strategy classes remain useful. |
| DP | Rewriting processor | CPF-certified for accepted YES shape | Innermost-oriented and conservative; tried after ordinary processors fail. Rule variables are standardized apart from DP variables before matching, preventing cyclic substitutions when names coincide. It can create graph opportunities now exploited by Q-aware IEDG. Transform budgets are tracked per original DP pair and can be overridden in strategies with `rewrite(max-per-pair=N)`. Recursive search now performs mandatory graph decomposition and preserves an explicit caller continuation instead of replacing it with an unbounded historical ladder. Needs full standard-TRS correctness audit before broadening. |
| DP | Narrowing processor | CPF-certified for accepted YES shape | Must remain fallback after direct loop/ordinary DP processors. Candidate regions include the empty/root region required by CeTA's `qnarrows_impl`; a CPF position is treated as the lower bound `p`, and Ferrum emits narrowings from every rewrite position `q` with `p <= q`, while checking the exact `icap`/Q-normal side condition at the region root for both innermost and full rewriting. Exact-position generation is retained internally, then unioned and alpha-deduplicated for the complete regional witness. Transform candidates are ranked by the number of pairs remaining in cyclic SCCs and then the largest cyclic SCC, so useful decomposition is preferred without changing graph estimation; nondeterministic-call ties retain original DP order. Transform budgets are tracked per original DP origin and transform kind and can be overridden with `narrow(max-per-pair=N)`. Recursive search performs mandatory graph decomposition and preserves the configured continuation and bounds. |
| DP | Instantiation / forward instantiation | CPF-certified for accepted YES shapes | Bounded skeleton search. Forward instantiation checks the full CeTA outgoing-edge coverage obligation in standard and innermost/Q contexts, backtracks over every candidate group, and retains both minimized and exact checker-required instantiation sets. Exact candidates are prioritized; residuals with fewer cyclic pairs and smaller largest cyclic SCCs rank first. Explicit strategies are preserved recursively after mandatory graph decomposition. Without an explicit continuation, exact unary-projection candidates retain the graph-first sparse-matrix portfolio and other shapes retain the broader checked continuation. The early Standard strategy also races a five-second AProVE-shaped chain: graph, monotonic polynomial compatibility, and up to three one-step ordinary instantiations, with graph decomposition after every transformation. Generated pairs inherit a persistent branch-local origin key, so syntactic growth cannot reset a per-pair transform counter. This recovers `jwmatchb1/2`, `jwaprove2`, `jwcime1`, `pair2hard`, `pair3hard`, `jwtpa1`, and `Secret_05_TRS/teparla1`. |
| DP | Semantic labeling (`semlabProc`) | CPF-certified | Synthesizes finite algebra models, including affine-offset functions such as `1 + x` over finite carriers, expands rules and pairs over carrier assignments, and emits CPF labeled symbols and semantic-labeling proofs. Strong and weak DP instances are expanded separately in relative states. Nullary constants remain nonzero-first. Checked carrier-two candidates include constructor projection plus normalization identities and an affine marking wrapper; this recovers the certified `Ex16_Luc06_C` split/labeling/SCT proof without generic model enumeration. Existing families cover unary marked/base models, role-derived binary models, and marked/unmarked higher-arity classes. Every candidate must satisfy all finite-model equations before recursive proof search. |
| DP | LLM proposal hook | Not a proof processor by itself | Can ask for candidate reductions, but every accepted proof must pass Ferrum's checker and CPF/CeTA where supported. Needs real vLLM model-loading integration in the background LLM thread. |
| DP NO | DP loop / rewriting / instantiation nontermination | CPF-certified for accepted shapes | In addition to symbolic one-step DP loops, the loop processor grounds DP variables with a bounded two-round unary/binary constructor closure and searches bounded mixed `P/R` cycles containing multiple marked root steps and relative base-rule steps. Ground substitution products larger than the 4096-state loop frontier are skipped, and constant-free signatures retain the symbolic search schedule. Every witness is replayed, marked steps are checked modulo variable renaming against the DP set, and relative steps against the TRS before CPF export. This recovers the seven earlier small AProVE-certified Standard NO examples, `Strategy_removed_AG01/#4.12a` and `#4.4`, and the projection loop in `Secret_05_TRS/ttt1`. Search remains bounded and still needs deeper transformational nesting, narrowingProc export for NO, and broader instantiation/search. |
| DP NO | Native pattern non-loop synthesis | CPF-certified for supported calculus | Live-rule initial/context pumping, checked domain equivalence, instantiation, nested pattern narrowing, base/substitution rewrite chains, commuting context factorization, and substitution-power closure. All 43 retained pattern-nonloop roots have native certified proofs without imported witnesses; search remains bounded. See the SOTA ledger for protected replay totals. |

## Implemented But High-Priority Strengthening

| Priority | Processor/class | Why it matters |
| --- | --- | --- |
| 1 | Improved Q-CSDPs for CSR | The remaining AProVE CSR proofs repeatedly use `CSDependencyPairsProof`, `QCSDependencyGraphProof`, and `QCSDPSubtermProof`. CeTA-CSR already contains the semantic LPAR'08 hiding/collapsing development, but still needs an executable hidden-term/projection checker and the Q/minimal-chain soundness bridge. |
| 2 | Partial size-change deletion and usable-rule refinement | AProVE uses `sizeChangeProc` / `subtermCriterion` in 458 Standard and 157 Innermost certified YES proofs. Ferrum now has precise IEDG-indexed SCT closure; the next gap is deleting only the decreasing subset, immediately re-decomposing, and computing `U(D')` for each residual component. |
| 3 | KBO/RPO/LPO with argument filtering | AProVE Standard proofs heavily use KBO plus filtering; Ferrum has one-shot encodings but still needs broader status/filter coverage and regression-driven strengthening. |
| 4 | Matrix interpretations | Now implemented for dimensions 1 and 2, but AProVE uses matrix interpretations in 87 Standard and 27 Innermost certified YES proofs. |
| 5 | Instantiation, narrowing, rewriting | Implemented conservatively; AProVE combines them deeply, especially in DP and NO proof search. |
| 6 | Dependency graph and innermost graph estimation | Pair-local-usable-rule Q-aware IEDG is implemented and certifies. Remaining impact is replacement-map-aware variants and preserving/refining the exact Q context after transformational DP steps. |
| 7 | Max-polynomial reasoning | New `max-polo` is sound and certifiable but conservative; completeness should be improved using the max-polynomial literature and CPF-supported semantics. |

## Not Yet Implemented Processor Classes

| Missing processor/class | AProVE certified Standard YES tag count | AProVE certified Innermost YES tag count | Notes |
| --- | ---: | ---: | --- |
| Bounds / tree automata | 41 | 9 | Requires explicit tree automata/bounds witnesses in CPF. Likely lower immediate impact than graph, size-change, KBO, and matrix, but mostly disjoint later. |
| Root labeling | 2 | 0 observed in local Innermost gap table | Rare in Standard YES corpus; implement after semantic labeling unless a targeted example demands it. |
| RFC match-bounds for SRS | SRS YES | SRS YES | Direct finite RFC initial-language generation emits CPF3 `<rfcBounds>` certificates accepted by the patched CeTA checker when the bounded initial language is closed. CeTA-rfc has verified conservative `<rfcAutomatonClosedBounds>`, `<rfcAutomatonClosedRelativeBounds>`, and first-class Matchbox-style `<rfcMatchboxRelativeBounds>` checkers. The first certified real TPDB examples are `SRS_Standard/Zantema_04/{z049,z055,z062,z063}.ari`. Remaining gaps are search/productivity rather than checker soundness for this fragment: Matchbox-level state merging, preprocessing/strictification, reversal/RFC integration, and broader partial deletion. Reversed RFC remains opt-in because SK90 examples showed a closure mismatch against CeTA's executable narrowing relation; ordinary reversed match-bounds remains certified and enabled. |
| General/conditional reduction-pair processor (`generalRedPairProc`) | 47 | Exact retained support recovers Innermost `cade05` and `cade13` | Ferrum can import a certified conditional interpretation and constraint proof, validate it against the exact live DP state, preserve its residual components, and emit the native CPF shape. Open-ended synthesis of new conditional constraint proofs remains unimplemented. |
| Full usable replacement maps | Included in usable/Q/strategy buckets, not isolated | Included in usable/Q/strategy buckets, not isolated | Needed to exploit innermost and context-sensitive reductions beyond current usable-rule filtering. |
| Non-loop certificates | NO-side only; all 43 retained Standard pattern-nonloop roots now replay witness-free | Not in YES counts | Required for serious certified NO performance; outside this YES-focused table. |
| Transformational NO processors | NO-side only | NO-side only | Includes SRS/string/uncurrying-style transformations; reversed SRS loop search is implemented with original-loop reflection, while broader transformational NO processors remain future work after the DP NO pipeline is stronger. |

## Strategy Notes

The top-level strategy language supports shape-dependent branching with
`if(condition, then, else)`. Current conditions are `standard`, `innermost`,
`strict-srs`, `unary-srs`, `srs`, and `rules-at-least(N)`, with `not(...)`,
`all(...)`, and `any(...)` combinators. `string-reversal` is an atomic
transformation: the universal worklist applies the checked-in default strategy
to its residual and wraps a successful decisive YES or NO proof in CPF
`<stringReversal>`. The checked-in default strategy uses this to dispatch
SRS-shaped systems to an SRS branch, innermost TRSs to an innermost branch, and
remaining TRSs to the standard branch. This is the right place for category
policy: CLI flags should not encode category-specific proof search.

Top-level sequence and choice have distinct operational semantics. `a; b`
applies `a` to the current problem and passes the exact residual of a certified
rule-removal step to `b`; the eventual proof is nested back under the retained
rule-removal certificate. `a | b` retains backtracking behavior and starts each
alternative from the same input. Polynomial, KBO, path-order, and innermost
non-applicable-rule removal are supported residual contexts. A failed sequence
does not silently restart its continuation on the original TRS.

The default SRS YES strategy races its main bounds/uncurrying portfolio directly
against a second path that first applies cheap certified preprocessing and then
continues on the exact residual. This ensures that inapplicable preprocessing
does not suppress the main search. The preprocessing stage includes
strict/weighted length, weighted rule removal, reversed weighted rule removal,
small polynomial removal, KBO, path order, and reversed variants under short
local timeouts.

The default DP strategy performs graph decomposition first, then runs a
component portfolio in parallel: cheap projection subterm, SCT, and the
reduction-pair order portfolio (`weights`, polynomial, weak/max/rational
polynomials, quadratic natural polynomials, matrix interpretations, KBO, and
path orders), each under local timeouts. A later transform portfolio races plain reduction pairs with
transform-then-portfolio branches such as `narrow; portfolio`. Scoped
cancellation means success in any nested branch cancels sibling branches at the
same scope and kills their running SMT/SAT subprocesses. After any pair removal,
Ferrum decomposes the residual graph again and retries the component portfolio.

DP `Sequence` remains coupled to processors that recursively prove their
transformed child. A 2026-07-31 experiment that passed only the unexecuted
strategy suffix into those recursive calls correctly prevented prefix restart,
but regressed several existing certified defaults because graph and
reduction-pair processors also rely on the current recursive contract. The
experiment was reverted. A future change must introduce an explicit DP
residual-state outcome, migrate graph splitting and every transformation
together, and regression-test the full certified corpus; adjusting narrowing
continuations alone is not sufficient.
Parallel DP branches timestamp completion. The coordinator drains a queued
result before declaring a deadline, but accepts a proof only when its completion
timestamp is within the branch deadline. This avoids losing valid near-deadline
proofs without accepting late solver results.
For TRSs recognized as transformed CSR encodings, the default strategy first
tries a six-second direct polynomial proof and then races two 35-second
graph-first ladders: monotonic-polynomial/path-order/SCT and
path-order/monotonic-polynomial/SCT. The direct attempt recovers
`Ex5_DLMMU04_iGM`; successful DP deletions recursively restart the same ladder,
matching the two common AProVE certified proof shapes without contending with
the broader transformed portfolio. Ordinary Standard and Innermost TRSs do not
pay this scheduling cost.
Argument filtering is a DP component technique by default; whole-TRS filtering
must stay restricted to audited YES-branch processors with explicit CPF support.

All termination-oriented processors must be sound and should be as complete as
the literature-supported implementation permits. In doubtful cases, prefer a
smaller certified fragment over a larger uncertified YES result, then strengthen
the fragment with proof-corpus regression tests.

Strategy evaluation now propagates explicit YES/NO/MAYBE results through
top-level and nontermination strategy combinators. Branch results carry
`sound_so_far` and `complete_so_far` metadata. A YES is accepted only if the
branch is still sound; a NO is accepted only if the branch is still complete, so
a loop discovered after an incomplete transformation is downgraded to MAYBE
rather than reported as a global NO. If an unsound but complete NO-oriented
abstraction is ever added, its result must likewise be classified using this
metadata rather than as an unconditional proof.

Transform processors use AProVE-style per-origin counters in addition to the
global branch limit. Each generated pair inherits the canonical origin key of
its selected parent through rewriting, narrowing, instantiation, and forward
instantiation. Independent original pairs therefore retain independent budgets,
while a growing descendant chain cannot evade its limit by changing syntax.
The origin map is branch-local search metadata and does not alter DP equality or
CPF proof terms.

SMT identifiers are encoded injectively from symbol bytes. This avoids the
former collision between operator symbols such as `*` and `+`, and applies to
all existing SMT/SAT-backed DP orders, not only quadratic polynomials.

## Latest Validation Snapshot

Run: `target/termcomp-runs/20260714-174942-full-128-60s-q-iedg`.

| Category | Timeout | YES | NO | Certified YES | Certified NO | Cert failed |
| --- | ---: | ---: | ---: | ---: | ---: | ---: |
| TRS Standard | 60s | 473 | 170 | 473 | 170 | 0 |
| TRS Innermost | 60s | 113 | 2 | 113 | 2 | 0 |

Compared with the previous 60s cut of
`target/termcomp-runs/20260714-120000-full-128-final`, Q-aware IEDG left
Standard unchanged and improved Innermost by 14 additional certified YES with 1
batch-contention miss. The missed example,
`TRS_Innermost/AG01_innermost/#4.34.ari`, proves and CeTA-certifies in 5.4s
when run alone with the same release binary.

Experimental component-portfolio run:
`target/termcomp-runs/20260714-component-portfolio-128-60s`.

| Category | Timeout | YES | NO | Certified YES | Certified NO | Cert failed |
| --- | ---: | ---: | ---: | ---: | ---: | ---: |
| TRS Standard | 60s | 471 | 170 | 471 | 170 | 0 |
| TRS Innermost | 60s | 114 | 3 | 114 | 3 | 0 |

Compared with the Q-aware baseline, this run gains
`TRS_Innermost/AG01_innermost/#4.34.ari` and
`TRS_Innermost/Transformed_CSR_innermost_04/LengthOfFiniteLists_nosorts_noand_GM.ari`.
It reports two Standard batch losses,
`TRS_Standard/Strategy_removed_AG01/#4.34.ari` and
`TRS_Standard/Zantema_05/jw27.ari`; both prove with the current release binary
when rerun directly, so they are recorded as 128-worker load artefacts rather
than deterministic proof regressions.

SRS Standard relative-bounds run:
`target/termcomp-runs/20260715-151226-srs-standard-relative-release-128-60s`.

| Category | Timeout | YES | NO | Certified YES | Certified NO | Cert failed |
| --- | ---: | ---: | ---: | ---: | ---: | ---: |
| SRS Standard | 60s | 194 | 11 | 194 | 11 | 0 |

This run used the rebuilt release binary and `.tools/ceta-relative-bounds`.
Generated proof artefacts include 11 `<relativeBounds>` certificates, all of
which certify individually with the patched CeTA. Compared with the prior
stale-release SRS runs at 139 certified YES / 11 certified NO, this adds 56
batch YES results and loses one batch YES. The lost example,
`SRS_Standard/Waldmann_19/random-470.ari`, proves and certifies when rerun
alone, so the current deterministic proof power is at least the 194 batch YES
plus that load-sensitive case.

Focused Matchbox-RFC direct-40 smoke after internal automaton caps and
preliminary cheap SRS preprocessing:
`target/termcomp-runs/20260723-srs-caps-cheap-seq-direct40-8w-60s`.

| Category | Timeout | YES | NO | Certified YES | Certified NO | Cert failed |
| --- | ---: | ---: | ---: | ---: | ---: | ---: |
| SRS Standard direct-40 | 60s | 14 | 0 | 14 | 0 | 0 |

## RFC Matchbox Relative Bounds

| Capability | Status | Next strengthening |
| --- | --- | --- |
| One-rule exact right-barren, actual height `-1` | Certified; eight real TermCOMP 2025 examples | Retain as the cheap first branch |
| Explicit epsilon tail anchor | Certified by the branch-built CeTA checker | Search is deterministic and fully revalidated |
| Multi-rule right-barren | Certified end to end with one explicit tail per strict RHS; the large-cap direct-189 run finds 155 YES and the verified indexed unary-word checker certifies all 155 within 40 seconds | Broaden quotient/merge search and reduce witness size to leave more time for proof search |
| Relative deletion at positive heights | Existing conservative completion only | Reuse paired tails, then certify residual weak compatibility |
| Search metrics | Barren, paired-tail, saturation, phase-time, state, transition, and epsilon metrics retained in run artifacts | Aggregate failure predicates over larger candidate runs |

The 189 direct `RelRFCmb{-1}` benchmark formerly gave 12 YES. With 10,000
states, 250,000 transitions, and a 30-second processor budget it now gives 155
YES. The verified indexed unary-word checker certifies all 155 within a
40-second checker budget, with no timeouts or checker rejections.
`ICFP_2010/107193.ari` now certifies in 14.85 seconds, compared with 54.4
seconds before indexing and about 155 seconds before specialization. The next
high-impact work is quotient/merge search that constructs smaller automata.
The broader gap includes
cleaning, strictification, mirroring, splitting/tiling, and
weighted/matrix/natural transformations.

## Repeated Monotonic Usable-Rule Reduction

Ferrum's ordinary minimal DP reduction-pair processors now recompute the
usable-rule closure inside the current active rule component `R`, including
after earlier DP deletions. A monotonic polynomial processor may emit a
`monoRedPairUrProc` step with no strictly oriented dependency pair when its
certified usable rules are a strict subset of the current `R`. The child DP
problem then uses that smaller rule component, starts with dependency-graph
decomposition, and can repeat the construction after later pair deletion.

The strict-subset check is the progress guard: an unchanged usable-rule set is
declined, so a zero-deletion step cannot loop. The existing minimality guard
remains in force. CPF export uses the standard CeTA
`monoRedPairUrProc`; no checker extension is involved.

The default Standard and transformed-CSR strategies contain an early
graph-first parallel order ladder with polynomial, dimension-two matrix, KBO,
size-change, and subterm processors. On 2026-07-31 this recovered both
`Transformed_CSR_04/Ex4_7_15_Bor03_C.ari` and
`Transformed_CSR_04/ExProp7_Luc06_C.ari` as certified YES in under one second
each.

## Conservative IEDG Certification Guard

The innermost dependency graph retains every edge accepted by Ferrum's
implementation of IsaFoR's IEDG criterion. Optional direct, one-step, CAP, and
nonreachability estimates may add precision or additional conservative edges,
but can no longer veto IEDG. This follows the formal theorem
`Dependency_Graph.IEDG: DG nfs m P Q R ⊆ IEDG P Q R`.

The regression reproduces the two labeled DPs and eight labeled rules from
`Waldmann_06/jwteparla2.ari` after semantic labeling and Q/LHS reduction. The
old graph omitted a checker-visible edge and produced a raw YES rejected by
CeTA. The corrected default proof avoids that split and certifies using
uncurrying, switching to innermost, narrowing, graph decomposition, reduction
pairs, and forward instantiation.
# SRS campaign search and audit update (2026-10-16)

Native `srs-finite-loop(max-width=N)` searches the finite graph of words up to
the bound using radix-coded words and a global DFS color table. Each word is
expanded at most once; a 32-million-vertex ceiling limits the table to 32 MB
(the DFS stack is additional). Absence of a cycle is only Unknown, never YES.
`srs-finite-context-loop(max-width=N)` additionally searches context-trimming
edges. Trims are not rewrite steps: reconstruction retains all removed letters
as surrounding contexts, lifts subsequent original-rule rewrites through them,
and independently checks the resulting ordinary loop. Long RHSs can enter via
bounded contiguous windows without discarding their surrounding proof context.
No names, seed words, rewrite traces or external models are supplied.

The native context graph recovers certified NOs for `Gebhardt_06/10` and
`Waldmann_07_size12/size-12-alpha-3-num-{209,219,267}`. All four pass strict
witness-free oracle-only replay and two production CeTA checks in
`target/srs-native-20261013/replay-finite-context-v197/`. Discovery times are
2.033s, 1.431s, 0.161s and 0.139s respectively. The generalized window variant
and broader frontier are measured separately in `finite-window-v201` and
`finite-frontier-v202`. CeTA is unchanged.
The small-alphabet frontier additionally recovers `size-12-alpha-3-num-210`,
`num-291`, `num-292`, and `Waldmann_19/random-278` in 4.942s, 0.779s, 1.463s,
and 2.380s. All four pass witness-free strict replay and double certification
in `replay-finite-small-gains-v206`. All eight new roots pass independent
original-input correspondence checks (`native-loop-gains-v207`).
All 1,186 release library tests pass with four test workers, zero failed or
ignored (`all-tests-final-v200.log`). An earlier fully parallel run hit the
one-second native SCT test deadline; that test passed isolated and in the
complete bounded-worker reruns. No test was disabled.

Optional `srs-smt-loop(steps=N,max-width=M,solver=z3|cvc5)` performs one-shot
bit-vector/array synthesis of a start word and bounded rewrite sequence, with
independent native replay before CPF construction. Positive, negative,
multi-step and renaming tests pass; the synthetic CPF is production-CeTA
certified. The 16 external-frontier probes timed out, so this is not claimed
as a coverage gain or enabled by default (`smt-loops-v189`).

`arctic-target-cached(...,strict=all,solver=z3|cvc5|boolector)` resolves its
strictness target against every pair in the live state, without retained pair
positions or models. It shares term encodings and derives a safe minimal
evaluation width from term depth and coefficient bounds. Legacy Arctic actions
retain their previous encoding. Parser and independent exact-orientation tests
pass. Closure/sparsity/backend pilots are `arctic-close-v187`,
`arctic-sparse-v191`, and `arctic-backends-v203`; no coverage gain is asserted
merely from adding these search options.

A partial-barren RFC suffix-sharing experiment failed to close all three
targeted roots (`target/srs-native-20261013/compact-rfc-v184/`). The unsuccessful
import option was removed; the focused regression for the existing compact
builder remains. State explosion, not reachability lookup alone, is still the
bottleneck. No certified gain is claimed and CeTA is unchanged.

`FERRUM_EXPERIMENTAL_RFC_WEAK_INDEX=1` reuses positive fixed-height reachability
answers during weak RFC completion. Snapshot misses still use the live
automaton, so inserted transitions cannot invalidate a negative cache entry;
no negative entry is trusted. Focused tests compare epsilon reachability and
the exact resulting automaton with the legacy construction. All 1,177 release
library tests pass with this option enabled. Per-rule timing, cache hits, live
checks and state counts are logged. The first three tight-bound probes still
show substantial state growth, so this is not claimed as a new certified gain.
Artifacts: `target/srs-native-20261013/rfc-weak-index-*-v181*` and
`raw-rfc-indexed-v183/`. CeTA is unchanged.

`integer-arctic-matrix(...,solver=cvc5)` and `solver=z3` now record an explicit
solver choice in modular actions, including selected-candidate continuations.
Omitting the parameter preserves previous behavior. Both backends synthesize
independently validated signed interpretations; unknown solver names are
rejected. Seven focused tests and all 1,175 release library tests pass.
The native negative-Arctic smoke proof in
`target/srs-native-20261013/arctic-solver-smoke-v176.xml` passes production CeTA.
The `cvc5-retry-v177` campaign measures coverage; no gain is claimed merely
from adding a backend. CeTA is unchanged.

`FERRUM_EXPERIMENTAL_SHARED_INTEGER_ARCTIC=1` enables query-local sharing of
integer-Arctic term encodings across weak/strict obligations. Keys preserve
the exact term, variable identities, and dimension; caches never cross queries.
Existing search behavior stays unchanged unless enabled. On the Wenzel probe
the query shrank from 985,171 to 302,825 bytes; the shared run completed in
208.6 seconds and passed CeTA twice. Six focused tests include solver-checked
equivalence of shared/unshared constraints and variable/dimension separation.
The release library suite passed all 1,174 tests with sharing enabled.

Validation artifacts: `target/srs-native-20261013/shared-arctic-*-v168*`.
The debug suite needed a 16 MiB test-thread stack for its existing deep-XML
test, then reached 1,173 passes with the multiplication-pattern search hitting
its 60-second deadline. That same debug failure reproduces with sharing
disabled; the optimized full suite passes without exclusions. CeTA is unchanged.

`srs-lp-weight-removal(maximal=true)` optionally maximizes clipped orientation
progress, then minimizes weights while retaining that objective. This is a
candidate-selection heuristic, not a claim of globally maximal rule deletion.
All candidates still undergo exact validation; existing actions retain their
old objective. The full library suite passed 1,172 tests, and all 15 roots in
the focused existing-LP oracle replay remained certified. No additional root
gain is claimed for this option yet. CeTA is unchanged.

Original-input correspondence audits support `--processes` for parallel
CPU-bound streaming XML validation. Eleven audit tests and a real process-mode
certificate audit passed; the default threaded behavior remains available.
