# Relative ADP Integration Manifest

Date: 2026-08-11

## Repositories

- Ferrum worktree: `/work/dfm/festschrift/ferrum-relative`
- Ferrum branch: `codex/relative-performance-20260811`
- CeTA worktree: `/work/dfm/festschrift/CeTA-CSR-relative-adp`
- CeTA branch: `codex/relative-adp-20260811`
- CeTA integration commit: `de72b6b`
- CeTA graph semantics commits: `af6ea1f`, `03aad26`
- Isabelle checker session: `Relative_ADP_Checker_Dev`
- Isabelle integration session: `Relative_ADP_Ceta_Dev`

No changes from the concurrent CSR worktree are required by this slice.

## Certified Semantics

`Relative_ADP_Checker_Adapter.thy` provides executable canonical A1/A2
reconstruction, recursive erasure-reduction-pair and dependency-graph
checkers, and the top-level
bridge from a well-formed relative TRS with a nonduplicating base to
`SN_rel (rstep R) (rstep B)`. The main theorem chain is:

1. `canonical_relative_adp_problem_list_sound`
2. `check_relative_adp_erasure_redpair_sound`
3. `relative_adp_estimated_graph_processor`
4. `check_relative_adp_termination_proof_sound`
5. `check_relative_adp_from_trs_sound`
6. `check_relative_adp_cert_problem_sound`

Thus a `CERTIFIED` result from the integrated executable has the ordinary CeTA
trusted base: Isabelle's kernel, generated-code correctness, the Haskell
runtime/compiler, and XML/input handling. Ferrum's search and graph estimator
are not trusted.

## Executable Integration

`Relative_ADP_Ceta.thy` adds the custom recursive XML production and delegates
all non-relative-ADP certificates to standard `certify_proof`. The generated
entry point is `certify_proof_integrated`.

`Relative_ADP_Code_Haskell.thy` deliberately uses
`Code_Target.produce_code ... false`. Ordinary `export_code` reaches irrelevant
real-domain parser equations and fails a sort check; the low-level extraction
is the route that produced the replayed checker. The generated module is
`generated/Haskell/Ceta_Relative.hs`, and `make ceta-relative-adp` builds the
worktree-local `ceta`. `make test-relative-adp` replays the retained real
certificate.

Ferrum prefers `../CeTA-CSR-relative-adp/ceta` when present and falls back to
`../CeTA-CSR/ceta`. An explicit backend path remains available for benchmark
reproducibility.

## Ferrum Integration

- `src/proving/processors/relative_adp/erasure_reduction_pair.rs`: worklist
  processor and mandatory graph-pending residual.
- `src/proving/dependency_pairs/reduction_pair.rs`: one-shot QF_BV synthesis
  with every argument coefficient constrained to at least one for this
  monotone processor; the returned model is revalidated in Rust.
- `src/cert/cpf.rs`: custom CPF3 production with first-class recursive
  `<relativeAdpDependencyGraph>` nodes.
- `src/proving/processors/top_level/solver.rs`: recursive relative-ADP atoms.
- `strategies/default.fs`: relative dispatch and bounded relative portfolio.

Ferrum implements the checker definition directly: forward `TCAP` matching on
erased annotated subterms, verified SCC decomposition, and the complete
main-SCC plus redex-creation-lasso candidate family. It does not apply the
additional reverse-`TCAP`/`GTCAP` pruning used by the ordinary DP estimator.
CeTA recomputes candidates and graph children; Ferrum's graph metadata is not
trusted.

## Validation

Real TPDB example:

```text
TPDB-ARI/TRS_Relative/Relative_05/rt1-3.ari
Ferrum: Terminating
Integrated CeTA: CERTIFIED
```

The checked interpretation is `f(x)=x+2`, `g(x)=x+2`, and
`t(x,y,z)=x+y+z+2`. Mutating the first main index to 99 is rejected as out of
range. Mutating an argument coefficient to zero is rejected as non-monotone.
An ordinary CeTA certificate (`examples/gramlich_pcp.proof.xml`) is still
accepted through the fallback path.

The full retained-artifact harness replay is at
`target/termcomp-runs/20260811-relative-adp-certified-integration-smoke`:
1 YES, 1 certified YES, and no timeout, error, or certification failure.

The graph-specific replay is retained at:

```text
target/relative-adp-graph-smoke/rt1-3-ceta-tcap.cpf.xml
target/relative-adp-graph-smoke/processor-events-ceta-tcap.jsonl
```

The proof contains one first-class graph processor with two recursively proved
children. The checker extracted by
`Draft.Relative_ADP_Code_Haskell_Test7` returned `CERTIFIED`. A previous
five-child proof built with Ferrum's stronger ordinary-DP graph estimator was
rejected by the checker, leading to the dedicated relative forward-`TCAP`
implementation.

Rust verification:

```text
cargo +1.95.0-x86_64-unknown-linux-gnu test relative_adp --lib --jobs 16
cargo +1.95.0-x86_64-unknown-linux-gnu build --release --jobs 64
```

The production extraction shape was replayed in the existing isolated
Proof_Checker console. A catalog build was intentionally stopped when it began
rebuilding `HOL-Library`; this was a build-database mismatch, not a failed
theory proof.

## Corrected Benchmark Evidence

The historical 40-YES/38-erasure probe is invalid as power evidence. Its
encoding allowed zero argument coefficients, contradicting the monotonicity
premise of the formal processor. With strict monotonicity enforced, none of
those 38 old witnesses remains an erasure reduction pair. A 200-smallest
official probe found the first genuine witness at `Relative_05/rt1-3.ari`.

An attempted 45-candidate replay with 8 workers was stopped by the standing
memory rule when summed process RSS reached 2.187 TB. The interrupted aggregate
is not reported as a benchmark result. It used the CLI certification driver,
which does not retain the required per-example artifact set, so it is not a
reproducible benchmark run. Future relative-ADP probes must use the retained-
artifact TermCOMP harness and lower outer concurrency while the unbounded
one-shot solver instances retain this memory profile.

## Remaining Verified Work

1. Finish the step-lifting part of the paper's `Com`-monotone and
   `Com`-invariant annotated reduction-pair theorem and export its compound
   interpretation. The residual/deletion theorem is already formalized.

DRP1/derelatification is now exposed and recursively reuses ordinary certified
DP proofs; see the 2026-08-12 checkpoint below.

## DRP1 And Com Checkpoint (2026-08-12)

Theorem 26 (DRP1) is implemented end to end. The verified theory
`Relative_ADP_Derelatification.thy` extracts every ordinary dependency pair
from an ADP-chain edge under the paper's annotation-free-base premise and
proves termination transfer to the nonminimal ordinary DPP
`(DP(P), flat(P union B))`. The executable checker normalizes annotated base
ADPs into the main component, checks that the residual base is flat, computes
the ordinary DPP itself, and invokes the existing CeTA DP checker. CPF uses the
first-class recursive node `<relativeAdpDerelatification>`; the certificate
does not supply or control the transformed DPP.

The complete generated integration session and checker binary accepted this
smoke proof:

```text
target/drp1-smoke-trs.ari
target/drp1-smoke-trs-drp1.cpf.xml
CeTA-CSR-relative-adp/ceta: CERTIFIED
```

Its strict rule is `f(s(x),y) -> f(x,y)`, its weak rule is `s(x) -> x`, and
the nested ordinary DP proof removes `F(s(x),y) -> F(x,y)` by a polynomial
reduction pair. A utility-guidance witness selects DRP1 only after the mandatory
ADP graph decomposition; guidance is untrusted and CeTA recomputes every
problem transformation.

For Theorem 36, `Relative_ADP_Com_Reduction_Pair.thy` now proves the semantic
tail/deletion result: if all ADP steps are weak, selected annotated-root steps
are strict, and the residual after flattening the selected ADPs terminates,
then the original relative ADP problem terminates. Ferrum already synthesizes
the finite polynomial constraints and now fixes the complete compound algebra
to `Com0=0` and `Com2(x,y)=x+y`. The Rust regression uses a branching ADP and
checks the returned solver model, including the zero constant and both unit
coefficients.

The Isabelle interface also makes explicit three discard laws:
`Com2(x,y) >= x`, `Com2(x,y) >= y`, and `x >= Com0`. The soundness proof in the
paper's appendix silently uses these laws when it removes annotations that are
not transported by the VRF; commutativity, associativity, and strict
Com-monotonicity alone do not imply them for an arbitrary reduction pair. They
hold immediately for the additive natural interpretation used by Ferrum.
Concrete Com certificates remain disabled until the formal step-lifting proof
derives the step-level assumptions from weak orientation of
`flat(P union B)`, the finite `l# >= ann(r)` constraints, and these explicit
discard laws. The CPF symbol bridge under development uses real `<sharp>`
symbols and dedicated `adpCom0`/`adpCom2` tags rather than collision-prone
reserved TRS names.

## Certified Com Reduction Pairs (2026-08-12)

The step-lifting bridge is complete. The theorem
`relative_adp_com_reduction_pair_finite` derives the semantic processor from
finite constraints checked by CeTA. Its proof covers fixed valid VRFs,
including duplicated right-hand-side variables, fresh and transported
annotations, rewriting above marked components, parallel preserved markers,
and deletion of untransported markers through the explicit discard laws. No
axiom or admitted Isabelle fact is used.

The executable node is `<relativeAdpComReductionPair>`. It contains a standard
CeTA reduction triple over ordinary symbols, sharp symbols, and dedicated
`<adpCom0/>`/`<adpCom2/>` symbols, followed by zero-based selected main/base
indices and a recursive relative-ADP proof. CeTA checks all flattened ADPs and
all annotation summaries weakly, selected summaries strictly, monotonicity,
and finite schemas for compound commutativity, associativity, projections, and
the empty summary. Ferrum emits `Com0=0` and `Com2(x,y)=x+y` even when one of
the symbols did not occur in the solver constraints, making each certificate
interpretation total for the checked laws.

The retained real TPDB replay is:

```text
TPDB-ARI/TRS_Relative/Relative_05/rt2-2.ari
target/rt2-2-com-guidance.jsonl
target/relative-adp-com-certified-smoke/rt2-2-com.cpf.xml
```

It performs graph decomposition followed by two polynomial Com deletions. The
guidance file only fixes processor order for reproducibility; CeTA ignores it
and reconstructs every graph child, selected set, constraint, and residual.

The first lifting layer is checked as well: pointwise weak replacement of
annotation components lifts through the right-associated compound summary;
an arbitrary component can be deleted using the discard laws; and adjacent
components can be exchanged using associativity, commutativity, and context
closure. These lemmas are the list-level algebra needed to normalize the
source/target annotation partitions in the concrete ADP-step proof.

## Dependency-Graph Foundation Checkpoint

Ferrum proof trees now retain each graph child's sorted indices into
`main ++ base`. Reconstruction rejects empty, duplicate, unsorted, and
out-of-range selections, and deterministically reconstructs the Theorem 33
child
`(P intersect Q, (B intersect Q) union flat((P union B) - Q))`. This changes
proof data only; it does not change Ferrum's dependency-edge estimator.

The isolated CeTA worktree now contains
`dev/Relative_ADP_Dev/Semantics/Dependency_Graph/Relative_ADP_Dependency_Graph.thy`.
Its thin-session proofs establish:

- executable child reconstruction has exactly the Theorem 33 set semantics;
- the semantic graph edge uses flat ADP steps below a marked root, matching
  Definition 30 of the IJCAR 2024 paper;
- canonical origin edges preserve marked positions;
- every marked target of an ADP step has a marked predecessor labeled by the
  exact applied ADP, covering preserved, root-created, and variable-transport
  cases; and
- every marked source has finitely many canonical origin successors.

The source was first replayed as `Draft.Relative_ADP_Dependency_Graph_Test20`
and then loaded directly under its production imports in the persistent
isolated `Proof_Checker` console. The final thin theory itself took about 0.1
seconds after loading the parent. No axiom, `sorry`, or unverified graph
assumption is used.
This historical foundation checkpoint is superseded by the verified executable
SCC/lasso processor and first-class CPF node described above.

## Selected-Origin Dichotomy Checkpoint

The dependency-graph semantics now selects one concrete application witness
for every step. This is necessary: taking the union of all rule/redex witnesses
for the same term transition preserves marker reachability, but could mix
incompatible witnesses when labels are mapped to dependency-graph nodes. The
selection prefers a sharp main-ADP witness whenever the `ideriv` marks the index
strict, so infinitely many strict indices remain infinitely many main events.

The new generic `Finite_Branching_Dichotomy.thy` proves that infinitely many
reachable events in a finitely branching relation yield a heavy path with
either infinitely many events on the path or infinitely many event-bearing
offshoots. `Relative_ADP_Dependency_Graph.thy` instantiates this result for the
selected canonical origin graph and proves:

- every selected target marker has a predecessor under that exact application;
- every selected marker is reachable from a marker in the initial term;
- strict `ideriv` indices induce infinitely many selected main events;
- one finite initial marker is heavy; and
- the resulting path has infinitely many main events or infinitely many
  main-event offshoots.

The first labeling bridge is also proved: if ADP left-hand sides are rooted by
function symbols, an outgoing selected origin edge at a labeled node enters a
statically annotated position of that exact ADP's right-hand side. The theory
was replayed in the persistent isolated console as
`Draft.Relative_ADP_Dependency_Graph_Test38`; loading the completed scratch
theory confirms that no `sorry` or admitted fact is involved. This work changes
only CeTA's proof layer, not Ferrum's graph estimator or accepted certificates.

The remaining semantic bridge must show that the unlabeled origin segment
between two labeled nodes is a sequence of below-root steps by flattened ADPs.
After that, finite graph/SCC/minimal-lasso validation can consume the proved
dichotomy.

As a first decomposition of that bridge, the checker theory now proves that an
unlabeled selected origin edge cannot apply at the tracked marker. Such an edge
is therefore either marker-preserving or a variable-transport edge. This lemma
was replayed in `Draft.Relative_ADP_Dependency_Graph_Test44`; the remaining
local argument is to map those two cases to zero or one below-root flattened
ADP steps on the marked subterm projection.
