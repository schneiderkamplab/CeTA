# TermCOMP Proof Corpus

Last updated: 2026-07-16.

Ferrum now has a reproducible proof-corpus collector:

```console
python scripts/collect_termcomp_proofs.py --jobs 64 --resume --out target/termcomp-proof-corpus
```

The collector scans TermCOMP result pages, records every linked proof-output
artefact whose cell result is `YES`, `NO`, `CERTIFIED YES`, or `CERTIFIED NO`,
and downloads artefacts with at most 64 concurrent workers. It is intentionally
tool-agnostic: AProVE, NaTT, NTI, MU-TERM, matchbox, MnM, T2, LoAT, KoAT,
VeryMax, and other participants are all collected when their result cells expose
proof output.

## Certified vs Uncertified

Certified and uncertified artefacts are separate records.

- `certification = certified`: result cell is certified or the proof URL is in a
  certified proof stream. These often contain CPF XML and checker-oriented proof
  output.
- `certification = uncertified`: ordinary solver proof output, usually text or
  HTML-style stdout.
- `detected_format = cpf-or-xml`: downloaded artefact appears to contain CPF/XML
  after the first result line.
- `detected_format = text`: downloaded artefact is ordinary proof text/stdout.
- `detected_format = not-downloaded`: metadata-only record. This is used for
  older StarExec stdout URLs when the URL is discoverable but the body was not
  downloaded in the current run.

This distinction is important for training data. A certified CPF proof provides
machine-checkable processor structure, whereas an uncertified proof can contain
richer human-readable hints such as processor names, intermediate obligations,
coefficients, precedences, matrix entries, or loop witnesses that still need
validation before becoming labels.

## Output Layout

Default output root:

```text
target/termcomp-proof-corpus/
  proofs.sqlite
  manifest.jsonl
  summary.json
  artefacts/
```

The SQLite table `proofs` contains one row per proof URL:

```text
year, category, benchmark, benchmark_url,
tool, result, certification,
proof_url, error_url,
runtime_seconds, cert_runtime_seconds,
local_path, sha256, bytes,
first_line, detected_format, extracted_json,
download_error, downloaded_at
```

Downloaded artefacts are stored under:

```text
artefacts/Y<year>/<category>/<certified|uncertified>/<tool>/<benchmark>/...
```

## Current Corpus Snapshot

Current import commands:

```console
python scripts/collect_termcomp_proofs.py --jobs 64 --resume --out target/termcomp-proof-corpus
python scripts/collect_termcomp_proofs.py --years 2018 2019 2020 2021 --index-only --jobs 64 --out target/termcomp-proof-corpus
python scripts/import_termcomp_zenodo_archives.py --year-start 2014 --year-end 2024 --jobs 1 --out target/termcomp-proof-corpus
python scripts/import_termcomp_pre2014_archives.py --out target/termcomp-proof-corpus
python scripts/import_termcomp_cache_page.py --year 2019 --category TRS_Standard --url https://termcomp.github.io/Y2019/caches/termination_33457.html --out target/termcomp-proof-corpus
python scripts/import_termcomp_cache_page.py --year 2019 --category TRS_Standard --certified --url https://termcomp.github.io/Y2019/caches/termination_33116.html --out target/termcomp-proof-corpus
```

The main alternative source for offline StarExec links is TermCOMP's Zenodo
raw-data archive series. The importer maps StarExec pair IDs to raw-data archive
members. For older archive layouts without pair IDs in output paths, it joins
the corresponding `*_info.zip` CSV on `(benchmark, solver, configuration)`.

Pre-2014 uses a different archive layout:

- `competition_results_2008_to_2013.tgz` supplies tool and certification
  metadata with result IDs.
- `zipped_proofs.tar` supplies `proofs/<Tool Result Id>.txt.bz2`.
- `zipped_Coq_scripts.tar` supplies some accepted certifier artefacts as
  `Coq_scripts/<Certification Result Id>.txt.bz2`.

Totals after the import:

| Status | Count |
| --- | ---: |
| Total proof-link records | 354,030 |
| Local artefacts available | 342,101 |
| Remaining indexed-only records | 11,929 |
| Text artefacts | 329,350 |
| CPF/XML artefacts | 11,868 |
| Pre-2014 compressed `.bz2` artefacts kept compressed | 883 |

Records by certification/result:

| Certification | Result | Count |
| --- | --- | ---: |
| certified | `CERTIFIED YES` | 48,570 |
| certified | `CERTIFIED NO` | 8,599 |
| certified | `YES` | 16,081 |
| certified | `NO` | 1,772 |
| uncertified | `YES` | 218,355 |
| uncertified | `NO` | 53,413 |

Year coverage:

| Year | Local artefacts | Records | Indexed-only |
| --- | ---: | ---: | ---: |
| 2008 | 13,083 | 13,083 | 0 |
| 2009 | 6,848 | 6,848 | 0 |
| 2010 | 7,519 | 7,519 | 0 |
| 2011 | 32,579 | 32,579 | 0 |
| 2012 | 4,929 | 4,929 | 0 |
| 2013 | 25,007 | 25,007 | 0 |
| 2014 | 15,705 | 15,705 | 0 |
| 2015 | 19,156 | 19,156 | 0 |
| 2016 | 19,167 | 19,167 | 0 |
| 2017 | 20,776 | 20,776 | 0 |
| 2018 | 19,558 | 19,558 | 0 |
| 2019 | 15,953 | 23,194 | 7,241 |
| 2020 | 18,578 | 23,266 | 4,688 |
| 2021 | 23,963 | 23,963 | 0 |
| 2022 | 26,133 | 26,133 | 0 |
| 2023 | 29,038 | 29,038 | 0 |
| 2024 | 20,146 | 20,146 | 0 |
| 2025 | 23,963 | 23,963 | 0 |

Remaining indexed-only rows are limited to:

| Year | Category | Certification | Result | Count | Reason |
| --- | --- | --- | --- | ---: | --- |
| 2019 | `TRS_Standard` | certified | `YES` | 1,703 | original cache page has valid pair IDs, but StarExec is offline and the Zenodo record has no `trs_output.zip`/standard proof archive for these bodies |
| 2019 | `TRS_Standard` | certified | `NO` | 464 | same |
| 2019 | `TRS_Standard` | uncertified | `YES` | 4,008 | same |
| 2019 | `TRS_Standard` | uncertified | `NO` | 1,066 | same |
| 2020 | `TRS_Standard` | uncertified | `YES` | 3,668 | Zenodo has `trs_certified_output.zip` but no uncertified `trs_output.zip`; StarExec is offline |
| 2020 | `TRS_Standard` | uncertified | `NO` | 1,020 | same |

The 2019 new-presentation page emitted malformed proof URLs of the form
`pairs//stdout`. These were not used as proof identifiers. The original 2019
cache pages were indexed instead, which recovers valid pair IDs for metadata and
future retry.

## Current SMT-Lex Training Dataset

The current canonical CPF training dataset uses the SMT-backed function-symbol
lex minimizer and is stored at:

```text
target/termcomp-proof-corpus/training/subproofs.cpf.canonical.smt-lex.final.jsonl.gz
```

Build inputs and summaries:

```text
target/termcomp-proof-corpus/training/subproofs.cpf.canonical.smt-lex.jsonl.gz
target/termcomp-proof-corpus/training/subproofs.cpf.canonical.smt-lex.summary.json
target/termcomp-proof-corpus/training/subproofs.cpf.canonical.smt-lex.final.summary.json
target/termcomp-proof-corpus/training/subproofs.cpf.canonical.smt-lex.fragment-audit.summary.json
target/termcomp-proof-corpus/fragment-audit/canonical-smt-lex-fragment-audit/summary.json
```

The full canonicalization pass processed 709,773 CPF-shaped rows:

| Status | Rows |
| --- | ---: |
| `canonicalized` | 525,494 |
| `unchanged-unsupported` | 184,186 |
| `unchanged-no-problem-xml` | 93 |

All supported rows used `canonicalization.method = smt-lex`. The final dataset
contains 525,494 canonicalized rows. Fragment materialization produced 46,494
standalone checker inputs; the 64-worker CeTA audit certified 10,518 of them,
failed 35,976, and marked 479,000 final rows as unsupported for independent
fragment checking.

The 10,518 CeTA-certifiable materialized fragments were then re-standardized
with the same SMT-lex helper and checked again:

```text
target/termcomp-proof-corpus/fragment-audit/canonical-smt-lex-standardized-fragment-audit/summary.json
target/termcomp-proof-corpus/fragment-audit/canonical-smt-lex-standardized-fragment-audit/results.jsonl.gz
```

Result: 10,518/10,518 standardized fragments certified by CeTA. All function
mappings were identity mappings because this audit starts from the canonical
SMT-lex final dataset; the test is therefore an idempotence and alpha-renaming
preservation check for the fragment certificates.

The nontrivial check starts from the original, non-canonical CPF-shaped rows:

```text
target/termcomp-proof-corpus/training/subproofs.cpf.original.fragment-audit.jsonl.gz
target/termcomp-proof-corpus/fragment-audit/original-fragment-audit/summary.json
target/termcomp-proof-corpus/fragment-audit/original-standardized-fragment-audit/summary.json
target/termcomp-proof-corpus/fragment-audit/original-standardized-fragment-audit/results.jsonl.gz
```

It materialized 60,595 original fragments and CeTA-certified 10,630 before
standardization. After applying non-identity SMT-lex standardization mappings,
10,609/10,630 certified again with CeTA; the remaining 21 were 5 second
standardization timeouts, with zero CeTA failures after successful
standardization.

## LLM Proof-Step Dataset

The LLM-oriented proof-step dataset is derived from the canonical SMT-lex final
rows and joins the fragment-audit results as trust labels:

```console
python scripts/build_llm_proofstep_dataset.py \
  --input target/termcomp-proof-corpus/training/subproofs.cpf.canonical.smt-lex.final.jsonl.gz \
  --output target/termcomp-proof-corpus/training/llm-proofsteps.smt-lex.jsonl.gz \
  --summary target/termcomp-proof-corpus/training/llm-proofsteps.smt-lex.summary.json \
  --canonical-fragment-results target/termcomp-proof-corpus/fragment-audit/canonical-smt-lex-fragment-audit/results.jsonl.gz \
  --original-standardized-results target/termcomp-proof-corpus/fragment-audit/original-standardized-fragment-audit/results.jsonl.gz \
  --progress-interval 50000
```

Each row contains:

- `input.problem_xml` and `input.local_context_xml`;
- `input.problem_features` such as rule count, dependency-pair count, function
  symbols, and XML tag counts;
- `target.processor` for next-processor prediction;
- `target.parameters` with extracted numeric constants, removed-rule counts,
  component sizes, path-order symbols, and interpretation summaries where
  available;
- `target.proof_suggestion_xml`, the checker-facing proof fragment label;
- `trust`, with canonical-fragment and nontrivial original-standardized
  fragment audit status.

Current full dataset:

| Metric | Rows |
| --- | ---: |
| LLM proof-step rows | 525,494 |
| Canonical fragment certified | 10,518 |
| Canonical fragment CeTA failed | 35,976 |
| Complete/text-only or unsupported as standalone fragment | 479,000 |
| Nontrivial original-standardized certified rows retained in canonical set | 10,605 |

Main processor labels in the full dataset:

| Processor | Rows |
| --- | ---: |
| `proofStep` | 291,496 |
| `redPairProc` | 53,660 |
| `depGraphProc` | 36,700 |
| `interpretation` | 33,738 |
| `ruleRemoval` | 26,638 |
| `usableRulesProc` | 25,940 |
| `sizeChangeProc` | 21,140 |
| `dpTrans` | 20,654 |
| `stringReversal` | 3,366 |
| `innermostLhssRemovalProc` | 2,616 |

High-trust training splits:

```text
target/termcomp-proof-corpus/training/llm-proofsteps.smt-lex.certified.jsonl.gz
target/termcomp-proof-corpus/training/llm-proofsteps.smt-lex.nontrivial-certified.jsonl.gz
target/termcomp-proof-corpus/training/llm-proofsteps.smt-lex.splits.summary.json
```

Both high-trust split files currently contain 10,605 rows. These are the rows
in the canonical dataset whose original non-canonical fragment was standardized
with a non-identity mapping and then accepted by CeTA.

Task-specific chat-style JSONL datasets are generated with:

```console
python scripts/build_llm_task_datasets.py \
  --input target/termcomp-proof-corpus/training/llm-proofsteps.smt-lex.jsonl.gz \
  --out-dir target/termcomp-proof-corpus/training \
  --prefix llm-task.smt-lex \
  --summary target/termcomp-proof-corpus/training/llm-task.smt-lex.summary.json \
  --processor-trust all \
  --parameters-trust nontrivial-certified \
  --witness-trust nontrivial-certified \
  --progress-interval 50000
```

Outputs:

| Dataset | Rows | Target |
| --- | ---: | --- |
| `llm-task.smt-lex.processor.jsonl.gz` | 525,494 | next processor JSON |
| `llm-task.smt-lex.parameters.jsonl.gz` | 10,605 | processor plus structured parameter/witness features |
| `llm-task.smt-lex.witness.jsonl.gz` | 10,605 | processor plus checker-facing proof-fragment XML |

The processor dataset uses all rows because processor-choice labels are useful
even when a fragment is not independently certifiable. Parameter and witness
datasets are restricted to the nontrivial standardized CeTA-certified split.

Supervised fine-tuning files in chat-template format are generated with:

```console
python scripts/build_sft_chat_datasets.py \
  --processor target/termcomp-proof-corpus/training/llm-task.smt-lex.processor.jsonl.gz \
  --parameters target/termcomp-proof-corpus/training/llm-task.smt-lex.parameters.jsonl.gz \
  --witness target/termcomp-proof-corpus/training/llm-task.smt-lex.witness.jsonl.gz \
  --out-dir target/termcomp-proof-corpus/training/sft \
  --summary target/termcomp-proof-corpus/training/sft/ferrum.sft.summary.json \
  --prefix ferrum \
  --validation-pct 1 \
  --test-pct 1 \
  --progress-interval 50000
```

Each SFT row has only:

```json
{"messages": [{"role": "system", "content": "..."}, {"role": "user", "content": "..."}, {"role": "assistant", "content": "..."}]}
```

This can be passed directly to `tokenizer.apply_chat_template(row["messages"],
tokenize=True, ...)`.

SFT split counts:

| Dataset | Train | Validation | Test |
| --- | ---: | ---: | ---: |
| `ferrum.processor` | 514,852 | 5,270 | 5,372 |
| `ferrum.parameters` | 10,402 | 103 | 100 |
| `ferrum.witness` | 10,415 | 88 | 102 |

The processor training split was also converted to HRM-Text's old direct
pre-tokenization format:

```console
python scripts/build_hrm_direct_dataset.py \
  --input target/termcomp-proof-corpus/training/sft/ferrum.processor.sft.train.jsonl.gz \
  --output target/termcomp-proof-corpus/training/hrm-direct/ferrum.processor.direct.train.jsonl.gz \
  --summary target/termcomp-proof-corpus/training/hrm-direct/ferrum.processor.direct.train.summary.json \
  --condition direct \
  --progress-interval 50000
```

Each row has exactly:

```json
{"condition": "direct", "instruction": "...", "response": "..."}
```

The `instruction` field is only the raw CPF input XML, e.g.
`<input>...</input>`; it intentionally does not include a system prompt, task
prompt, feature JSON, or any other wrapper. The `response` field is only the
bare processor name, e.g. `ruleRemoval`, not a JSON object.

`/work/dfm/HRM-Text/evaluation/engines.py` maps HRM conditions `direct`,
`cot`, `noisy`, and `synth` to condition tokens and supports comma-composed
conditions such as `synth,cot`. The Ferrum processor-choice dataset uses
`direct` because it is a plain instruction-to-JSON-response task. The generated
file contains 514,852 rows, skipped 0 rows, has 0 non-`<input>...</input>`
instructions, has 0 non-processor-name responses, and passed `gzip -t`.

A second HRM direct dataset uses Ferrum leaf-processor labels instead of bare
processor names. It is built from the canonical proof-fragment dataset with
full `output_xml` proof information, not from the stripped processor SFT split,
because leaf labels need the proof XML witness and parameter information that
the processor-only SFT rows intentionally discard:

```console
python scripts/build_hrm_strategy_direct_dataset.py \
  --input target/termcomp-proof-corpus/training/subproofs.cpf.canonical.smt-lex.final.jsonl.gz \
  --out-dir target/termcomp-proof-corpus/training/hrm-strategy-direct \
  --summary target/termcomp-proof-corpus/training/hrm-strategy-direct/ferrum.strategy.direct.summary.json \
  --prefix ferrum.strategy \
  --validation-pct 1 \
  --test-pct 1 \
  --progress-interval 50000
```

Rows again use only raw CPF XML as `instruction`, but `response` is a valid
Ferrum leaf processor label, for example `poly(max-constant=2,
max-coefficient=2, symbols=3, arity=1)`, `kbo(weight=5, symbols=3)`,
`matrix(max-constant=2, max-coefficient=2, symbols=3, arity=1, dim=2)`,
`path-order`, `path-order-af`, `graph`, `subterm`, or `nontermination(loop)`.
Structural aliases and sub-strategies such as `orders`, `dp`, and
`string-reversal(...)` are excluded. `path-order-af` is used when the proof XML
exposes an argument-filtered path-order witness; plain `path-order` is used
when no argument filter is present.

The exporter is conservative: it emits rows only when the proof fragment can be
mapped to a Ferrum leaf processor without inventing information. Numeric
bounds are extracted only from leaf `<integer>` nodes in actual witness
processor XML roots. Structural wrappers such as `<dpTrans>` are skipped, so
nested proof text is not concatenated into bogus parameters. This produced
120,513 rows from 525,494 canonical proof-fragment rows:

| Split | Rows |
| --- | ---: |
| train | 118,167 |
| validation | 1,193 |
| test | 1,153 |

Label provenance:

| Source | Rows |
| --- | ---: |
| coarse processor atom | 55,219 |
| exact XML polynomial bounds | 29,497 |
| exact XML matrix bounds | 24,205 |
| exact XML subterm | 4,868 |
| exact XML top-level path order with AF | 3,331 |
| exact XML loop | 1,425 |
| exact XML KBO bounds | 1,358 |
| exact XML path order without AF | 287 |
| exact XML match bound | 281 |
| exact XML nonloop | 42 |

All three strategy-label gzip files passed `gzip -t`; a full scan found 0
malformed `<input>...</input>` instructions, 0 JSON-object responses, and 0
labels with numeric parameters larger than 10,000.
The full strategy-label count table is kept in
`docs/hrm-strategy-dataset-processors.md`.

The HRM strategy dataset also has a domain-aware BPE tokenizer:

```console
python scripts/build_hrm_bpe_tokenizer.py \
  --input target/termcomp-proof-corpus/training/hrm-strategy-direct/ferrum.strategy.direct.train.jsonl.gz \
  --out-dir target/termcomp-proof-corpus/training/tokenizers/ferrum-strategy-bpe \
  --vocab-size 32000 \
  --min-frequency 2
```

Artefacts:

```text
target/termcomp-proof-corpus/training/tokenizers/ferrum-strategy-bpe/tokenizer.json
target/termcomp-proof-corpus/training/tokenizers/ferrum-strategy-bpe/tokenizer_config.json
target/termcomp-proof-corpus/training/tokenizers/ferrum-strategy-bpe/special_tokens_map.json
target/termcomp-proof-corpus/training/tokenizers/ferrum-strategy-bpe/atomic_tokens.txt
target/termcomp-proof-corpus/training/tokenizers/ferrum-strategy-bpe/summary.json
```

The tokenizer uses direct atomic tokens for observed XML tags, canonical
function and variable names such as `f0` and `x0`, Ferrum strategy atoms and
parameter names such as `poly`, `matrix`, `graph`, `size-change`,
`max-constant`, and `max-coefficient`, plus strategy punctuation. Complete
response labels are not added as atomic tokens, so parameterized labels still
share structure. The final usable vocabulary size is 549 tokens: 486 base BPE
tokens plus added domain tokens. The atomic-token manifest contains 179 strings
including 49 XML tags and 96 canonical `fN`/`xN` names. A full train-split
encoding scan found 0 `[UNK]` tokens.

## Wayback Probe

The unresolved 2019 `TRS_Standard` StarExec stdout URLs were also checked
against the Internet Archive CDX API:

```console
python scripts/recover_termcomp_wayback.py \
  --out target/termcomp-proof-corpus \
  --year 2019 \
  --category TRS_Standard \
  --jobs 8 \
  --retries 0 \
  --progress-interval 250 \
  --import-found \
  --variant-mode exact
```

Result:

```text
probed: 7241
found: 0
imported: 0
```

A 100-row all-variant sample over `https`, `http`, `www.starexec.org`, and
`starexec.org` also found no captures:

```text
probed: 100
found: 0
imported: 0
```

Coarse wildcard CDX queries for StarExec pair stdout URLs likewise returned no
captures for the tested patterns. CDX occasionally throttles or refuses
connections, so `scripts/recover_termcomp_wayback.py` keeps a `wayback_probes`
cache table and supports `--retry-cached-errors` for later retries. At the time
of this run, Wayback did not recover any of the missing 2019 proof bodies.

## Feature Extraction

For CPF/XML artefacts, the collector records counts of CPF processor tags such
as `depGraphProc`, `usableRulesProc`, `redPairProc`, `monoRedPairProc`,
`subtermCriterionProc`, `sizeChangeProc`, `instantiationProc`,
`forwardInstantiationProc`, `switchInnermostProc`, `polynomialOrder`,
`matrixOrder`, `pathOrder`, `kbo`, `rpo`, and `lpo`.

For text artefacts, it records simple processor-name counts for phrases such as
`DependencyPairsProof`, `DependencyGraphProof`, `UsableRulesProof`,
`QReductionProof`, `QDPSizeChangeProof`, `QDPOrderProof`, `Polynomial`,
`Matrix`, `KBO`, `LPO`, `RPO`, `Instantiation`, `Narrowing`, `Rewriting`,
`Loop`, and `TreeAutomata`.

Both formats also receive a small numeric-constant histogram. This is only a
first extraction pass; the next step is to add proper CPF normalization and
tool-specific text parsers for coefficients, precedences, statuses, argument
filters, matrix entries, and DP/usable-rule contexts.

## Normalized Proof Views

Original artefacts are preserved unchanged. Additional normalized XML-oriented
views are written under:

```text
target/termcomp-proof-corpus/normalized/
```

and indexed in the SQLite table `normalized_proofs`.

Normalization command:

```console
python scripts/normalize_proof_outputs.py \
  --out target/termcomp-proof-corpus \
  --mode all \
  --max-text-bytes 8000000 \
  --progress-interval 1000
```

Current normalized views:

| Normalizer | Format | Count | Purpose |
| --- | --- | ---: | --- |
| `xml-in-text` | `cpf-or-xml-normalized` | 59,706 | Strips old timing prefixes such as `0.27/0.63\t` and extracts embedded CPF/XML from certified text artefacts |
| `aprove-text` | `ferrum-aprove-text-xml` | 23,445 | Converts parseable AProVE textual output into a Ferrum XML summary |

The `aprove-text` first pass currently extracts:

- proof metadata;
- AProVE processor sequence where the modern `(n) Processor [CLASS, time]`
  form is present;
- removed-rule / removed-pair blocks when recognizable;
- explicit polynomial interpretation blocks when they use direct
  `POL(...) = ...` lines.

Current AProVE summary counts:

| Extracted signal | Count |
| --- | ---: |
| summaries with processor steps | 22,686 |
| summaries with removed-rule/pair blocks | 5,595 |
| summaries with strict `POL(...) = ...` polynomial blocks | 0 |

The zero strict-polynomial count is a parser limitation, not evidence that the
source proofs lack coefficients. Modern AProVE text contains polynomial blocks,
but the first-pass parser needs a stronger grammar for wrapped/HTML-ish and
newer textual variants before these become coefficient-level training labels.

## Subproof Training Data

Structured subproblem/proof-fragment training rows are exported from both:

- original CPF/XML artefacts (`proofs.detected_format = 'cpf-or-xml'`);
- normalized XML views in `normalized_proofs`.

Export command:

```console
python scripts/extract_subproof_training_data.py \
  --out target/termcomp-proof-corpus \
  --output target/termcomp-proof-corpus/training/subproofs.jsonl.gz \
  --source all \
  --progress-interval 1000 \
  --per-proof-progress \
  --per-proof-progress-log target/termcomp-proof-corpus/training/subproofs.progress.jsonl \
  --proof-row-progress-interval 1000 \
  --max-file-bytes 0 \
  --max-output-xml-bytes 2000000 \
  --max-input-xml-bytes 2000000 \
  --min-file-bytes 100
```

Each JSONL row is one supervised example:

```json
{
  "id": "...",
  "source": {"kind": "original|normalized", "normalizer": null},
  "metadata": {"processor_tag": "redPairProc", "tool": "..."},
  "input": {"problem_xml": "...", "local_context_xml": "..."},
  "output_xml": "<redPairProc>...</redPairProc>"
}
```

The exporter sorts candidate XML documents by file size. This keeps the early
part of a run high-signal and makes the final large-proof tail explicit. It
prints aggregate progress every 1,000 documents and writes per-proof progress
to:

```text
target/termcomp-proof-corpus/training/subproofs.progress.jsonl
```

For large successful proofs, it also emits `proof_progress` events every 1,000
exported rows inside that proof. This is necessary because some normalized
AProVE textual proofs produce thousands of rows from a single XML document.

Current full export:

| Metric | Count |
| --- | ---: |
| Candidate XML documents | 42,253 |
| Parsed XML documents | 42,250 |
| Proof documents with at least one row | 40,762 |
| JSONL rows written | 709,773 |
| Parse skips | 3 |
| File-size skips | 0 |
| Oversized row skips | 1,888 |

Output artefacts:

```text
target/termcomp-proof-corpus/training/subproofs.jsonl.gz
target/termcomp-proof-corpus/training/subproofs.summary.json
target/termcomp-proof-corpus/training/subproofs.progress.jsonl
```

The gzip stream was validated with `gzip -t`, and the JSONL was streamed back
through `json.loads`; both checks succeeded and the streamed count matched the
summary count exactly.

Rows by extracted proof-fragment tag:

| Tag | Rows |
| --- | ---: |
| `step` | 569,154 |
| `interpretation` | 40,666 |
| `depGraphProc` | 17,063 |
| `removed` | 16,070 |
| `ruleRemoval` | 14,673 |
| `redPairProc` | 12,355 |
| `dpTrans` | 10,606 |
| `sizeChangeProc` | 8,352 |
| `usableRulesProc` | 4,431 |
| `innermostLhssRemovalProc` | 4,361 |
| `stringReversal` | 3,942 |
| `pathOrder` | 2,275 |
| `loop` | 1,779 |
| `monoRedPairProc` | 1,244 |
| `narrowingProc` | 987 |
| `instantiationProc` | 743 |
| `bounds` | 328 |
| `forwardInstantiationProc` | 324 |
| `switchInnermostProc` | 246 |
| `equalityRemoval` | 91 |
| `nonLoop` | 83 |

The dominant `step` rows are from normalized AProVE text. They are useful for
processor-choice sequence learning, but coefficient/precedence/matrix labels
will require stronger tool-specific text normalization before they are suitable
as fine-grained parameter targets.

## Standardization Audit

This section records an earlier smoke audit. The current nontrivial
certificate-preservation audit for canonical collision classes is documented in
the next section and is the relevant check for the final canonical CPF dataset.

The current `standardize` helper's function-symbol canonicalization was checked
against complete CPF certificates backing randomly sampled JSONL rows. Because
individual JSONL rows are proof fragments rather than standalone certificates,
the audit transforms the complete source CPF for each sampled row and asks CeTA
to certify the transformed certificate.

Audit command:

```console
python scripts/audit_standardized_subproof_rows.py \
  --rows 128 \
  --seed 20260715 \
  --timeout 30 \
  --out-dir target/termcomp-proof-corpus/standardize-audit-128
```

Sampling scope:

- rows from TRS categories;
- rows backed by complete CPF3 XML certificates;
- source certificates that local CeTA certifies after stripping the TermCOMP
  result prefix such as `YES`;
- compact CPF3 lookup-table rules and ordinary CPF2-style `lhs`/`rhs` rules are
  both parsed for the standardization input.

The audit canonicalizes function symbols using the proof-corpus
standardization helper, alpha-renames variables consistently throughout the
certificate, and then runs local CeTA on the transformed complete CPF. Small
inputs can still be compared against brute-force exact search; larger inputs
use the SMT-backed lex minimizer and record that method in the row metadata.

Result:

| Metric | Count |
| --- | ---: |
| Sampled JSONL rows | 128 |
| Unique source certificates | 113 |
| Transformed certificates certified by CeTA | 128 |
| Transformed certificate failures | 0 |

Sampled rows by category:

| Category | Rows |
| --- | ---: |
| `TRS_Standard` | 78 |
| `TRS_Innermost` | 45 |
| `TRS_Outermost` | 3 |
| `TRS_Relative` | 2 |

Sampled rows by major processor tag:

| Tag | Rows |
| --- | ---: |
| `interpretation` | 22 |
| `usableRulesProc` | 21 |
| `ruleRemoval` | 16 |
| `sizeChangeProc` | 15 |
| `innermostLhssRemovalProc` | 13 |
| `depGraphProc` | 11 |
| `redPairProc` | 6 |
| `dpTrans` | 6 |

Audit artefacts:

```text
target/termcomp-proof-corpus/standardize-audit-128/summary.json
target/termcomp-proof-corpus/standardize-audit-128/sample-results.jsonl
```

## Canonical CPF JSONL Dataset

The current training-ready canonical dataset is CPF-shaped before
canonicalization and contains only rows whose CPF input and proof fragment were
rewritten by the current SMT-lex standardizer:

```text
target/termcomp-proof-corpus/training/subproofs.cpf.canonical.smt-lex.final.jsonl.gz
target/termcomp-proof-corpus/training/subproofs.cpf.canonical.smt-lex.final.summary.json
```

It was produced through the intermediate full canonical file:

```text
target/termcomp-proof-corpus/training/subproofs.cpf.canonical.smt-lex.jsonl.gz
target/termcomp-proof-corpus/training/subproofs.cpf.canonical.smt-lex.summary.json
```

Commands:

```console
python scripts/canonicalize_subproof_training_data.py \
  --input target/termcomp-proof-corpus/training/subproofs.cpf.jsonl.gz \
  --output target/termcomp-proof-corpus/training/subproofs.cpf.canonical.smt-lex.jsonl.gz \
  --summary target/termcomp-proof-corpus/training/subproofs.cpf.canonical.smt-lex.summary.json \
  --progress-interval 10000 \
  --max-symbols 0 \
  --standardization-timeout 5

python scripts/export_final_canonical_subproof_dataset.py \
  --input target/termcomp-proof-corpus/training/subproofs.cpf.canonical.smt-lex.jsonl.gz \
  --output target/termcomp-proof-corpus/training/subproofs.cpf.canonical.smt-lex.final.jsonl.gz \
  --summary target/termcomp-proof-corpus/training/subproofs.cpf.canonical.smt-lex.final.summary.json \
  --progress-interval 50000
```

The canonicalizer preserves the original row as a source reference:

- `source_row_id` contains the original row id;
- `id` is recomputed from the canonical row content;
- `canonicalization.status` records whether and how the row was transformed;
- `canonicalization.function_bijection` records the original-to-canonical
  function-symbol mapping.

The current standardizer has no function-symbol cap. It uses deterministic
`f0`, `f1`, ... names for function symbols and `x0`, `x1`, ... names for
variables, and applies the induced renaming to the CPF problem, local context,
and proof fragment. Symbol names are rewritten throughout CPF proof objects,
including interpretations, KBO/path-order/filter entries, and ordinary term
positions.

On 2026-07-16 the proof-corpus canonicalizer removed the old eight-symbol
standardization cap for the default corpus build. `--max-symbols 0` now uses the
SMT-backed lex minimizer and records `canonicalization.method = smt-lex`.
Positive `--max-symbols` values are retained only for legacy brute-force and
refinement comparison runs.

Validation smoke:

```console
python scripts/canonicalize_subproof_training_data.py \
  --input target/termcomp-proof-corpus/training/subproofs.cpf.jsonl.gz \
  --output target/termcomp-proof-corpus/training/subproofs.cpf.canonical.uncapped-smoke.jsonl.gz \
  --summary target/termcomp-proof-corpus/training/subproofs.cpf.canonical.uncapped-smoke.summary.json \
  --limit 5000 \
  --progress-interval 1000 \
  --max-symbols 0
```

Smoke result: 4,059/5,000 rows canonicalized; 1,149 rows had more than eight
function symbols and all supported rows were canonicalized via `smt-lex`.

Certificate-preservation smoke for uncapped rows sampled 16 certified CPF3/SRS
sources with 9-19 function symbols, transformed each complete certificate with
`--max-symbols 0`, and local CeTA certified all 16 transformed certificates.

Full canonical pass summary:

| Status | Rows |
| --- | ---: |
| `canonicalized` | 525,494 |
| `unchanged-unsupported` | 184,186 |
| `unchanged-no-problem-xml` | 93 |
| Total | 709,773 |

Final training-ready dataset summary:

| Metric | Rows |
| --- | ---: |
| Rows written | 525,494 |
| `ari-to-cpf-input` rows | 426,331 |
| `cpf-input-preserved` rows | 99,163 |

Proof-fragment output status in the final dataset:

| Output status | Rows |
| --- | ---: |
| `aprove-step-to-cpf` | 339,712 |
| `cpf-output-preserved` | 99,163 |
| `aprove-obligation-step` | 72,080 |
| `aprove-removed-to-cpf` | 14,539 |

Validation:

```console
gzip -t target/termcomp-proof-corpus/training/subproofs.cpf.canonical.smt-lex.jsonl.gz
gzip -t target/termcomp-proof-corpus/training/subproofs.cpf.canonical.smt-lex.final.jsonl.gz
```

Summary files record 709,773 rows in the full SMT-lex canonical file and
525,494 rows in the final file.

### Nontrivial Certificate-Preservation Audit

The important certificate-preservation check samples canonical collision
classes: different original certified CPF inputs that standardize to the same
canonical CPF input. For each sampled row, the complete source CPF certificate
is transformed with the same function-symbol and variable renaming, then
checked with CeTA.

Command:

```console
python scripts/audit_canonical_collision_certificates.py \
  --jsonl target/termcomp-proof-corpus/training/subproofs.cpf.canonical.v2.jsonl.gz \
  --rows 128 \
  --timeout 60 \
  --out-dir target/termcomp-proof-corpus/canonical-collision-audit-128
```

Result:

| Metric | Count |
| --- | ---: |
| Sampled transformed complete CPF certificates | 128 |
| CeTA-certified transformed certificates | 128 |
| Failures | 0 |
| Nontrivial certified complete CPF rows found | 7,814 |
| Rows in canonical collision groups | 7,557 |
| Collision groups | 1,188 |

The eligible nontrivial certified complete CPF rows under these audit predicates
are currently SRS rows: 6,537 `SRS_Standard` and 1,277 `SRS_Relative`. This is a
limitation of the complete-source CPF subset available through this audit path,
not of the final canonical JSONL dataset, which also contains many TRS rows.

CeTA time for the transformed certificates in the sample:

| Metric | Seconds |
| --- | ---: |
| Total | 4.254 |
| Mean | 0.033 |
| Median | 0.011 |
| Max | 0.465 |

The index scan over the compressed JSONL took 132.119 seconds. Based on the
sample mean, checking all 7,557 collision-group rows would cost about 251
seconds of serial CeTA time, plus the index scan and XML transformation
overhead. With 64 or 128 workers, the CeTA portion is estimated at about 3.9 or
2.0 seconds respectively; in practice the gzip index pass dominates unless a
manifest is reused.

A second audit sampled all nontrivial certified complete CPF rows rather than
only collision groups:

```console
python scripts/audit_canonical_collision_certificates.py \
  --jsonl target/termcomp-proof-corpus/training/subproofs.cpf.canonical.v2.jsonl.gz \
  --rows 128 \
  --timeout 60 \
  --no-require-collision \
  --out-dir target/termcomp-proof-corpus/canonical-nontrivial-audit-128
```

It also certified 128/128 transformed certificates with CeTA. The sample was
again SRS-only because the eligible complete-source CPF population under the
audit predicates is SRS-only.

## Fragment Audit Dataset

Updated 2026-07-16.

Ferrum now materializes a fragment-audit version of the canonical TRS/SRS
subproof dataset:

```console
python scripts/materialize_fragment_audit_dataset.py \
  --output target/termcomp-proof-corpus/training/subproofs.cpf.canonical.fragment-audit.jsonl.gz \
  --summary target/termcomp-proof-corpus/training/subproofs.cpf.canonical.fragment-audit.summary.json
```

Output:

```text
target/termcomp-proof-corpus/training/subproofs.cpf.canonical.fragment-audit.jsonl.gz
target/termcomp-proof-corpus/training/subproofs.cpf.canonical.fragment-audit.summary.json
```

Each row keeps the original canonical training fields and adds
`fragment_audit`. If a standalone fragment certificate can be constructed,
`fragment_audit.cpf3_certificate` contains a CPF3 certificate checked with CeTA
using `--allow-assumptions`. Otherwise, `fragment_audit.reason` records the
missing repair/reconstruction class.

The fragment checker is backed by CeTA's verified checker, not by a Python-side
trust decision. The local CeTA fork was extended so `terminationAssumption` for
standard/innermost TRS inputs is parsed and verified; DP `finitenessAssumption`
was already supported. The Isabelle `Code` session was rebuilt successfully and
Haskell was exported from the session database before compiling the checker.

The initial materialization/audit baseline was:

| Status | Rows |
| --- | ---: |
| Rows processed | 529,627 |
| Materialized standalone fragment CPF3 certificates | 27,807 |
| Unsupported/requires further repair | 501,820 |

Unsupported reasons at materialization time:

| Reason | Rows |
| --- | ---: |
| `non_cpf_output:aprove-step-to-cpf` | 342,499 |
| `non_cpf_output:aprove-obligation-step` | 72,327 |
| `cannot_build_dp_assumption` | 33,643 |
| `context_not_proof_obligation:interpretation` | 30,945 |
| `non_cpf_output:aprove-removed-to-cpf` | 14,632 |
| other context/parse reasons | 7,774 |

Full bounded audit command:

```console
python scripts/audit_materialized_fragment_certificates.py \
  --jsonl target/termcomp-proof-corpus/training/subproofs.cpf.canonical.fragment-audit.jsonl.gz \
  --workers 64 \
  --timeout 30 \
  --out-dir target/termcomp-proof-corpus/fragment-audit/canonical-fragment-audit-full-bounded
```

Audit result:

| Status | Rows |
| --- | ---: |
| Certified by CeTA | 2,129 |
| Materialized but rejected/unsupported by CeTA | 25,678 |
| Not materialized | 501,820 |

The main remaining materialized-failure classes are:

| Class | Rows | Meaning |
| --- | ---: | --- |
| `REJECTED` | 14,179 | The CPF parsed, but the assumption did not subsume the real residual obligation. This requires exact residual-problem construction per processor instead of assuming the current problem. |
| old polynomial interpretation syntax | 6,866 | CPF2-style polynomial payloads need deeper CPF3 expression repair. |
| old relative proof wrappers | 2,413 | `relativeTerminationProof` fragments need conversion to the CPF3 proof constructors accepted by this CeTA build. |
| old dependency graph component syntax | 1,308 | `realScc`/component syntax needs CPF3 repair. |
| old DP transformation/nontermination syntax | 487 | `markedSymbols`-based DP transformations need CPF3 repair. |

Follow-up repair pass, also on 2026-07-16:

- Normalized old CPF2/early-CPF proof syntax:
  - expression-level `<polynomial>` wrappers under interpretations
  - `<coefficient>` wrappers around numeric coefficients
  - missing rational-domain `<delta>` payloads, defaulting to `1`
  - `relativeTerminationProof` wrappers to `trsTerminationProof`
  - obsolete `markedSymbols` in `dpTrans`
  - obsolete `realScc`/`arcs` dependency-graph component metadata
  - old two-`trs` `stringReversal` payloads
- Added CPF wrapper classification for more CeTA-supported DP proof steps:
  `subtermProc`, `narrowingProc`, `instantiationProc`,
  `forwardInstantiationProc`, `semlabProc`, `switchInnermostProc`, and
  `splitProc`.
- Built exact fragment assumptions where the residual obligation is explicitly
  recoverable from the proof step:
  - `dpTrans`: child `dpInput` from the declared dependency pairs
  - `ruleRemoval`: child TRS by subtracting removed rules from the current TRS
  - `stringReversal`: child TRS by reversing unary string terms, including
    relative rules
  - `depGraphProc` components: child `dpInput` from the component pairs
  - `usableRulesProc`: child `dpInput` with the declared usable rules
  - `redPairProc`, `redPairUrProc`, `monoRedPairProc`,
    `monoRedPairUrProc`, and `subtermProc`: child `dpInput` from remaining
    pairs, and usable/TRS rules where declared

Previous v3 materialization command:

```console
python scripts/materialize_fragment_audit_dataset.py \
  --output target/termcomp-proof-corpus/training/subproofs.cpf.canonical.fragment-audit.v3.jsonl.gz \
  --summary target/termcomp-proof-corpus/training/subproofs.cpf.canonical.fragment-audit.v3.summary.json \
  --progress-interval 50000
```

Previous v3 materialization summary:

| Status | Rows |
| --- | ---: |
| Rows processed | 529,627 |
| Materialized standalone fragment CPF3 certificates | 47,328 |
| Unsupported/requires further repair | 482,299 |

Previous v3 unsupported reasons:

| Reason | Rows |
| --- | ---: |
| `non_cpf_output:aprove-step-to-cpf` | 342,499 |
| `non_cpf_output:aprove-obligation-step` | 72,327 |
| `context_not_proof_obligation:interpretation` | 30,945 |
| `non_cpf_output:aprove-removed-to-cpf` | 14,632 |
| `cannot_build_red_pair_child_input` | 10,066 |
| `cannot_build_dp_assumption` | 3,437 |
| `cannot_build_usable_rules_child_input` | 2,690 |
| `context_not_proof_obligation:recursivePathOrder` | 2,275 |
| `cannot_build_mono_red_pair_child_input` | 1,983 |
| `cannot_build_red_pair_ur_child_input` | 1,279 |

Previous v3 full audit command:

```console
python scripts/audit_materialized_fragment_certificates.py \
  --jsonl target/termcomp-proof-corpus/training/subproofs.cpf.canonical.fragment-audit.v3.jsonl.gz \
  --workers 64 \
  --timeout 30 \
  --out-dir target/termcomp-proof-corpus/fragment-audit/canonical-fragment-audit-v3 \
  --keep-certificates failures \
  --progress-interval 50000
```

Previous v3 audit result:

| Status | Rows |
| --- | ---: |
| Certified by CeTA | 13,770 |
| Materialized but rejected/unsupported by CeTA | 33,558 |
| Not materialized | 482,299 |

Certified fragments by leading processor in v3:

| Processor | Certified rows |
| --- | ---: |
| `dpTrans` | 5,228 |
| `stringReversal` | 3,317 |
| `ruleRemoval` | 3,095 |
| `loop` | 972 |
| `depGraphProc` | 421 |
| `interpretation` | 319 |
| `redPairProc` | 257 |
| `bounds` | 116 |
| `equalityRemoval` | 43 |
| `monoRedPairProc` | 2 |

Main v3 materialized-failure classes:

| Class | Rows | Meaning |
| --- | ---: | --- |
| `REJECTED` | 33,254 | The CPF parsed, but CeTA rejected the proof obligation. Many remaining cases need exact local DP/TRS obligations from the full proof tree or proof-normalization repairs for renamed symbols/status/filter data. |
| old direct child under `subtermProc` | 73 | Fixed in the working tree after the v3 run; the affected rows now classify as missing exact DP input rather than parser failures. |
| incomplete XML from historical text normalization | 100+ | Small residual class from old textual AProVE normalization; these should be handled in the text-to-CPF normalizer, not by the fragment checker. |
| old nontermination WCR syntax | 60+ | `joinableCriticalPairsBFS` and related old nontermination proof payloads need CPF3 repair if we want NO-fragment coverage. |
| old loop redex syntax | 6 | Remaining loop encodings not covered by the current redex-to-rewrite-sequence repair. |

The main correctness gap is now structural rather than syntactic: many rows do
not contain the local DP/QDP/TRS obligation of the extracted proof fragment.
Those obligations must be recorded during extraction by walking the complete
proof tree and updating the current problem after each processor. Reconstructing
them from the isolated JSONL row is not sound in general.

Important scripts:

```text
scripts/build_canonical_audit_manifest.py
scripts/materialize_fragment_audit_dataset.py
scripts/audit_materialized_fragment_certificates.py
scripts/audit_canonical_fragments.py
```
