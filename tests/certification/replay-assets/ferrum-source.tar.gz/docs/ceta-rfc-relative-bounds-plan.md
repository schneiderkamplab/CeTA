# CeTA RFC / Relative SRS Bounds Plan

Last updated: 2026-07-18.

## Source Snapshot

- Official IsaFoR/CeTA site: <https://isafor-ceta.uibk.ac.at/>
- Current release: CeTA 3.9, released 2026-06-16.
- Release source archive downloaded from:
  <https://isafor-ceta.uibk.ac.at/src/CeTA.tgz>
- Local unpacked source:
  `.tools/CeTA-source-3.9/CeTA-3.9`
- Local working fork for Ferrum's certified extension:
  `/work/dfm/festschrift/CeTA-rfc`
- The official development repository is Mercurial:
  <http://cl2-informatik.uibk.ac.at/rewriting/mercurial.cgi/IsaFoR>
  but cloning from this machine failed with `No route to host`. The release
  source archive is therefore the current local source baseline.
- Verification toolchain:
  - Isabelle 2025-2:
    <https://isabelle.in.tum.de/website-Isabelle2025-2/dist/Isabelle2025-2_linux.tar.gz>
  - AFP current:
    <https://isa-afp.org/release/afp-current.tar.gz>

Relevant files:

- `thys/Termination_and_Complexity/Matchbounds_Impl.thy`
- `thys/Right_Forward_Closures/Right_Forward_Closure.thy`
- `thys/Proof_Checker/Check_Termination.thy`
- `thys/Proof_Checker/Check_Complexity.thy`
- `thys/Proof_Checker/CPF_Proof_Parser.thy`
- `thys/Proof_Checker/CPF_Input_Parser.thy`

## Current CeTA State

CeTA already supports ordinary termination bounds:

- `trs_termination_proof` has constructor `Bounds bounds_info`.
- CPF parsing maps a `<bounds>` proof directly to `Bounds`.
- `check_trs_termination_proof ... (Bounds info)` calls
  `bounds_tt J info tp`.
- `bounds_tt` calls:

```isabelle
check_bounds_generic info r [] f f
```

where `r = tp_ops.rules I tp` and `f = funas_trs_list r`.

This means ordinary termination bounds require the automaton to accept
`lift0(T(Sigma))`, i.e. all ground terms over the current signature, and to be
compatible with all current rules as strict rules.

CeTA also already has relative match-bounds machinery for complexity:

- `complexity_proof` has constructor `Matchbounds_Rel_Complexity`.
- CPF parsing accepts `<relativeBounds>`.
- `bounds_complexity_rel` calls:

```isabelle
check_bounds_generic info Rdelete (Rw @ R2) ...
```

and moves `Rdelete` from strict rules into weak rules after a subproof proves
the residual problem.

There is no corresponding termination proof constructor for relative bounds,
and there is no RFC-specific termination bounds constructor.

## Implementation Status

The working fork `/work/dfm/festschrift/CeTA-rfc` now contains the first relative
termination-bounds implementation and an initial RFC proof-object surface:

- `Matchbounds_Impl.thy` adds `bounds_rel_tt`.
- `Check_Termination.thy` adds:

```isabelle
| Relative_Bounds bounds_info "('f, 'l, 'v) trsLL" "('f, 'l, 'v) trs_termination_proof"
```

- `CPF_Proof_Parser.thy` accepts termination-side `<relativeBounds>`.
- `CPF_Proof_Parser.thy` accepts termination-side `<rfcBounds>` with explicit
  `<initialTerms>` and a nested `<bounds>` object.
- `CPF_Proof_Parser.thy` accepts termination-side `<rfcRelativeBounds>` with
  explicit `<initialTerms>`, nested `<bounds>`, deleted `<trs>`, and a residual
  `<trsTerminationProof>`.
- `Check_Termination.thy` has constructor `Rfc_Bounds`.
- `Check_Termination.thy` has constructor `Rfc_Relative_Bounds`.
- `Matchbounds_Impl.thy` has a conservative `rfc_bounds_tt` entry point that
  checks finite initial-language groundness, automaton acceptance, RHS
  coverage, and closure under executable RFC narrowing. The executable step is
  proved equal to IsaFoR's `right_forw_closure string_rename` narrowing
  relation.
- `Matchbounds_Impl.thy` has a conservative `rfc_relative_bounds_tt` entry
  point. It currently accepts only the all-strict-rule deletion case with empty
  weak and Q components and full rewriting. Its soundness theorem reduces this
  case to the verified direct RFC theorem, so it does not require the old
  global `lift0(T(Sigma))` acceptance side condition.
- The verified patch against the CeTA 3.9 source snapshot is stored as
  `docs/ceta-relative-bounds.patch`.

The soundness proof is intended to:

1. use the existing relative match-bounds checker to bound deleted rules
   relative to retained rules;
2. lift the finite-signature relative SN fact with
   `sig_ext_relative_rewriting_var_cond`;
3. combine it with the residual proof via `SN_qrel_split`.

This implementation has passed local Isabelle checking:

```bash
.tools/Isabelle2025-2/bin/isabelle build -j 32 -d .tools/CeTA-ferrum-rfc/thys Proof_Checker
.tools/Isabelle2025-2/bin/isabelle build -j 32 -d .tools/CeTA-ferrum-rfc/thys Code
```

Ferrum now has a tracked build path for the patched checker:

```bash
scripts/build_ceta_relative_bounds.sh
```

The script verifies the Isabelle sessions, exports the checked Haskell code, and
builds `.tools/ceta-relative-bounds`. The active conda environment currently
contains GHC 8.2.2, which is too old for Isabelle 2025-2 generated Haskell, so
the script prepends `/home/ucloud/.ghcup/bin` when that GHC 9.6.7 toolchain is
available.

Ferrum CPF emission is enabled for the conservative all-rules relative case:

```xml
<relativeBounds>
  <bounds>...</bounds>
  <trs>all strict rules</trs>
  <trsTerminationProof><rIsEmpty/></trsTerminationProof>
</relativeBounds>
```

This is not yet RFC match-bounds and does not yet partition a non-empty residual
TRS. It is the first certifiable termination-side relative-bounds path.

Ferrum CPF emission is also enabled for opt-in RFC match-bounds candidates:

```xml
<rfcBounds>
  <initialTerms>...</initialTerms>
  <bounds>...</bounds>
</rfcBounds>
```

The emitted initial terms are strict unary SRS terms reconstructed over the
original tail variable. The patched CeTA parses `Rfc_Bounds` and checks the
finite RFC side conditions without the stronger global `lift0(T(Sigma))`
acceptance condition.

Ferrum CPF emission is also enabled for conservative RFC-relative candidates:

```xml
<rfcRelativeBounds>
  <initialTerms>...</initialTerms>
  <bounds>...</bounds>
  <trs>all current strict rules</trs>
  <trsTerminationProof><rIsEmpty/></trsTerminationProof>
</rfcRelativeBounds>
```

This proof shape is certified only for full rewriting problems with empty Q and
weak components and deletion of exactly all strict rules. It is a verified
base for relative RFC certificates, not a complete Matchbox `RelRFCmb`
implementation.

Validation completed on 2026-07-16:

```bash
cargo +1.95.0 fmt --check
cargo +1.95.0 test --lib rfc_match_bounds_emits_cpf3_rfc_bounds_certificate_object -- --nocapture
cargo +1.95.0 check --lib
.tools/Isabelle2025-2/bin/isabelle build -j 32 -d .tools/CeTA-ferrum-rfc/thys Proof_Checker
```

Additional Isabelle validation for the RFC finite-initial checker:

```bash
AFP=/work/dfm/festschrift/ferrum/.tools/afp-current/thys \
ISABELLE_IDENTIFIER=ferrum_rfc_check \
/work/dfm/festschrift/ferrum/.tools/Isabelle2025-2/bin/isabelle build -j 32 \
  -d /work/dfm/festschrift/CeTA/thys Proof_Checker

AFP=/work/dfm/festschrift/ferrum/.tools/afp-current/thys \
ISABELLE_IDENTIFIER=ferrum_rfc_bundle_check \
.tools/Isabelle2025-2/bin/isabelle build -j 32 \
  -d .tools/CeTA-ferrum-rfc/thys Proof_Checker
```

Both `Proof_Checker` builds passed. The bundled fresh-home build took `0:30:32`
elapsed time.

Validated real TPDB examples:

| TPDB file | Ferrum proof | Checker |
| --- | --- | --- |
| `SRS_Standard/Zantema_04/z061.ari` | `target/relative-matchbounds-real/Zantema_04-z061.cpf3.xml` | `.tools/ceta-relative-bounds`: `CERTIFIED` |
| `SRS_Standard/ICFP_2010/25192.ari` | `target/relative-matchbounds-real/ICFP_2010-25192.cpf3.xml` | `.tools/ceta-relative-bounds`: `CERTIFIED` |
| `SRS_Standard/ICFP_2010/264370.ari` | `target/relative-matchbounds-real/ICFP_2010-264370.cpf3.xml` | `.tools/ceta-relative-bounds`: `CERTIFIED` |
| `SRS_Standard/ICFP_2010/54622.ari` | `target/relative-matchbounds-real/ICFP_2010-54622.cpf3.xml` | `.tools/ceta-relative-bounds`: `CERTIFIED` |
| `SRS_Standard/ICFP_2010/264405.ari` | `target/relative-matchbounds-real/ICFP_2010-264405.cpf3.xml` | `.tools/ceta-relative-bounds`: `CERTIFIED` |
| `SRS_Standard/Zantema_04/z061.ari` | `target/rfc-relative-probe/z061.cpf3.xml` | `.tools/ceta-relative-bounds`: `CERTIFIED` for `<rfcRelativeBounds>` |

Additional 2026-07-18 validation:

```bash
AFP=/work/dfm/festschrift/ferrum/.tools/afp-current/thys \
ISABELLE_IDENTIFIER=ferrum_rfc_work \
/work/dfm/festschrift/ferrum/.tools/Isabelle2025-2/bin/isabelle build -j 64 \
  -d /work/dfm/festschrift/CeTA-rfc/thys Proof_Checker

AFP=/work/dfm/festschrift/ferrum/.tools/afp-current/thys \
ISABELLE_IDENTIFIER=ferrum_rfc_work \
/work/dfm/festschrift/ferrum/.tools/Isabelle2025-2/bin/isabelle build -j 64 \
  -d /work/dfm/festschrift/CeTA-rfc/thys Code
```

Both sessions passed. The generated checker was exported, compiled with GHC,
and installed as `/work/dfm/festschrift/ferrum/.tools/ceta-relative-bounds`.

## Existing Theory To Reuse For RFC

`Right_Forward_Closure.thy` defines:

```isabelle
right_forw_closure R = (narrow_step ren R)^* `` rhss R
```

and proves:

- For right-linear TRSs:

```isabelle
SN (rstep R) \<longleftrightarrow> SN_on (rstep R) (right_forw_closure R)
```

- For locally confluent overlay TRSs:

```isabelle
SN (rstep R) \<longleftrightarrow> SN_on (rstep R) (right_forw_closure R)
```

So an RFC-bounds termination processor should not be unconditional. It needs a
checked side condition such as right-linearity, or the existing WCR+overlay
criterion.

## Recommended Extension

Add two separate termination proof constructors instead of changing existing
`Bounds` semantics:

```isabelle
| Relative_Bounds bounds_info "('f, 'l, 'v) trsLL" "('f, 'l, 'v) trs_termination_proof"
| RFC_Bounds bounds_info "('f, 'l, 'v) term list"
```

The second argument of `RFC_Bounds` is an explicit finite initial language,
represented as terms. Ferrum can emit this as the finite right-forward closure
candidate it used to build the automaton.

### Relative Bounds Semantics

For termination, mirror the complexity relative-bounds shape:

1. Certificate gives `Rdelete`.
2. CeTA checks `Rdelete \<subseteq> rules tp`.
3. Let `R2 = R - Rdelete`.
4. CeTA checks:

```isabelle
check_bounds_generic info Rdelete (Rw @ R2) F F
```

where `F = funas_trs_list (rules tp)` or the existing appropriate signature
measure.

5. CeTA recursively checks termination of the residual problem where `Rdelete`
   is moved out of the strict component:

```isabelle
mk (NFS tp) (Q tp) R2 (list_union Rw Rdelete)
```

6. Soundness target:

```isabelle
SN_qrel (qreltrs residual) \<Longrightarrow> SN_qrel (qreltrs original)
```

This should follow the same proof skeleton as `bounds_complexity_rel`, but with
termination instead of complexity bounds. The key theorem needed from
match-bounds is that a bounded strict component admits only finitely many strict
steps relative to the weak component; combined with SN of the residual strict
component, this yields SN of the original.

This is likely the lowest-risk CeTA extension because most checking code already
exists.

### RFC Bounds Semantics

For SRS/TRS termination via RFC:

1. Certificate gives:
   - `bounds_info`
   - finite initial language `I`
   - side-condition selector, initially only `rightLinear`.

2. CeTA checks:
   - `wf_trs R`
   - every RHS is linear, for the initial version;
   - every RHS of every rule is included in `I`;
   - `I` is explicitly checked as a finite over-approximation of the
     right-forward closure, rather than trusted from Ferrum.

3. CeTA checks bounds on `I` rather than `T(Sigma)`.

The current `check_bounds_generic` hardcodes acceptance of
`lift0(T(Sigma))` via `ta_contains_impl` over function symbols. We should factor
that acceptance condition out:

```isabelle
check_bounds_generic_with_initial info R S accepted_roots accepted_targets
```

or more directly:

```isabelle
check_bounds_generic_terms info R S initial_terms
```

For ordinary bounds, `initial_terms = T(Sigma)`. For RFC bounds,
`initial_terms = I`.

4. Soundness target for the first version:

```isabelle
right_linear R \<Longrightarrow>
right_forw_closure R \<subseteq> Lang(TA) \<Longrightarrow>
bounds-compatible TA R \<Longrightarrow>
SN (rstep R)
```

using `right_linear_SN_rstep_RFC`.

### How To Certify The Finite RFC Initial Language

There are two options.

Preferred, more powerful:

- Add a checker for finite RFC over-approximation:
  - all RHSs are in `I`;
  - for every `s in I`, for every one-step narrowing successor `t`, either
    `t in I` or it is recognized by the same automaton/language;
  - then prove `right_forw_closure R \<subseteq> I` or directly
    `right_forw_closure R \<subseteq> Lang(TA)`.

Simpler first milestone:

- Require the certificate to provide `I`.
- Check all RHSs are in `I`.
- Check `I` is closed under one-step narrowing up to alpha-equivalence.
- Then `right_forw_closure R \<subseteq> I` follows by induction.

This should be enough for the Matchbox-style RFC match-bounds Ferrum wants:
Ferrum already computes finite RHS/narrowing closure candidates.

## CPF Shape Proposal

Do not overload existing `<bounds>`.

Suggested termination tags:

```xml
<relativeBounds>
  <bounds> ... existing bounds_info ... </bounds>
  <trs> ... deleted strict rules ... </trs>
  <trsTerminationProof> ... proof of residual ... </trsTerminationProof>
</relativeBounds>
```

This mirrors the existing complexity `<relativeBounds>` parser.

For RFC:

```xml
<rfcBounds>
  <sideCondition><rightLinear/></sideCondition>
  <initialLanguage>
    <term>...</term>
    ...
  </initialLanguage>
  <bounds> ... existing bounds_info ... </bounds>
</rfcBounds>
```

Later variants can add:

```xml
<sideCondition><locallyConfluentOverlay>...</locallyConfluentOverlay></sideCondition>
```

using the existing theorem `WCRO_SN_rstep_RFC`.

## Ferrum Work After CeTA Extension

1. Add proof AST variants:
   - `RelativeBounds { proof, removed, subproof }`
   - `RfcBounds { proof, initial_language, side_condition }`
2. Extend CPF export with the tags above.
3. Turn current RFC finite-initial match-bounds candidate machinery into a
   directly certified finite-initial YES processor only when:
   - side condition is right-linear initially;
   - finite closure check succeeds;
   - match-bounds termination is proved on the finite initial language rather
     than by global `lift0(T(Sigma))` acceptance;
   - generated CPF is accepted by the extended CeTA.
4. Add CeTA smoke tests before enabling in the default SRS strategy.

Current Ferrum status:

- `RelativeBounds` is implemented and certified by the patched CeTA.
- `RfcBounds` is implemented as an opt-in internal proof step through
  `rfc-match-bounds(...)`.
- Ferrum computes a finite SRS RHS forward closure, fails on closure caps, and
  runs match-bounds completion from that finite initial language.
- CPF export emits `RfcBounds`; the CeTA-rfc tree now checks the finite RFC
  side conditions and contains a direct finite-initial-language match-bounds
  theorem. The executable checker still extracts ordinary bounds facts through
  `check_bounds_generic`, so currently certified RFC proofs must also satisfy
  the global `lift0(T(Sigma))` automaton side condition.
- A fixed 256-example prior-unsolved SRS probe produced 243 raw Ferrum YES
  candidates with `RfcBounds`; certification power is currently blocked by the
  remaining executable dependency on global `check_bounds_generic` and by the
  need for stronger RFC automata/search.
- 2026-07-16 check: `SRS_Standard/Bouchare_06/03.ari` exports an `RfcBounds`
  CPF3 proof. The older conservative checker rejected this shape because the
  finite initial language was represented by open unary SRS terms over a common
  tail variable. The CeTA-rfc checker now accepts the corresponding proof shape
  in principle: every initial template must have at most one variable, and the
  automaton must accept each template for every selected final/tail state.
- A first implementation pass added executable open-tail acceptance predicates
  and auxiliary stackable-state lemmas to `Matchbounds_Impl.thy`; the maintained
  CeTA built with those helpers.
- 2026-07-17 follow-up: CeTA now additionally contains an executable
  `rfc_initial_single_var` predicate and lemmas recording that every checked
  finite RFC initial template has at most one distinct variable. This matches
  Ferrum's open-tail SRS certificates and is the right conservative side
  condition for the current `rfc_initial_accepted_with_tail_states_impl` check.
- 2026-07-17 later follow-up: the RFC proof work was duplicated from
  `/work/dfm/festschrift/CeTA` into
  `/work/dfm/festschrift/CeTA-rfc` to avoid interfering with other CeTA
  extension threads. Experimental lemmas now live in
  `thys/Proof_Checker/RFC_Bounds_Open_Tail.thy`, so failed proof iterations do
  not invalidate the `IsaFoR_2` heap.
- The helper lemmas were moved into
  `thys/Termination_and_Complexity/Matchbounds_Impl.thy`; the old
  `RFC_Bounds_Open_Tail.thy` file is no longer imported by `Proof_Checker`.
  The integrated theory now proves:
  - extraction from `rfc_term_accepted_with_tail_states_impl` to a semantic
    final-state `ta_res` witness;
  - the corresponding initial-language extraction lemma;
  - `adapt_vars_lift_term_subst`;
  - acceptance of a ground instance when a chosen tail state accepts every
    substituted variable;
  - acceptance of single-variable open RFC initial templates using
    `ta_contains_stackable_state`;
  - a direct `rfc_bounds_impl` theorem: for right-linear full TRSs with empty
    `Q` and no weak rules, finite RFC initial templates that cover all RHSs,
    are closed under executable RFC narrowing, use only the checked stackable
    alphabet, and are accepted for all tail states imply `SN (rstep R)`;
  - `rfc_bounds_tt`, the executable proof-checker entry point, now calls the
    direct theorem.
- Verification:
  `AFP=/work/dfm/festschrift/ferrum/.tools/afp-current/thys`
  `ISABELLE_IDENTIFIER=ferrum_rfc_work`
  `/work/dfm/festschrift/ferrum/.tools/Isabelle2025-2/bin/isabelle build -j 64 -d /work/dfm/festschrift/CeTA-rfc/thys IsaFoR_2`
  finished successfully in about 3:23 elapsed / 22:09 CPU on the final run.
  The subsequent
  `/work/dfm/festschrift/ferrum/.tools/Isabelle2025-2/bin/isabelle build -j 64 -d /work/dfm/festschrift/CeTA-rfc/thys Proof_Checker`
  finished successfully in about 10:11 elapsed / 40:30 CPU including dependency
  replay.
- The Isabelle executable-code session also builds:
  `/work/dfm/festschrift/ferrum/.tools/Isabelle2025-2/bin/isabelle build -j 64 -d /work/dfm/festschrift/CeTA-rfc/thys Code`
  finished successfully in about 10:13 elapsed / 22:33 CPU including
  `IsaFoR_3`; the `Code` phase itself took about 3:24 elapsed.
- The checked-in generated Haskell files in
  `/work/dfm/festschrift/CeTA-rfc/thys/Code/Bar` are still the old June
  snapshot, so the RFC-capable Linux checker was compiled from Isabelle
  session exports using `ISABELLE_IDENTIFIER=ferrum_rfc_work` and GHC 9.6.7.
  The resulting binary was installed as Ferrum's active checker at
  `/work/dfm/festschrift/ferrum/.tools/ceta-relative-bounds`; the previous
  checker was kept at
  `/work/dfm/festschrift/ferrum/.tools/ceta-relative-bounds.pre-rfc-20260717-173750`.
- 2026-07-17 executable follow-up: `rfc_term_accepted_with_tail_states_impl`
  was fixed to avoid partial `adapt_vars` on open templates, Ferrum now emits
  non-empty injective CPF state names, and RFC automata are seeded with
  final-state signature loops so simple non-empty unary RFC certificates pass
  CeTA. Focused tests:
  `cargo +1.95.0 test --lib rfc_match_bounds -- --nocapture` and
  `cargo +1.95.0 test --lib srs_rfc_initial_words -- --nocapture`.
- 2026-07-17 local-checker follow-up: CeTA-rfc now contains
  `check_bounds_generic_without_contains` plus
  `check_bounds_generic_without_contains_exact`. These extract all ordinary
  local bounds facts needed by RFC, except global `ta_contains_impl`, and
  `IsaFoR_2` verifies the split.
- 2026-07-18 follow-up: `rfc_bounds_impl` now uses the fresh-constant
  substitution argument directly. `rfc_bounds_tt` consumes
  `check_bounds_generic_without_contains`, so RFC certificates no longer need
  the automaton to accept global `lift0(T(Sigma))`. The exported checker was
  rebuilt and installed as Ferrum's active `.tools/ceta-relative-bounds`.
  Ferrum's finite-initial RFC automata no longer seed final-state signature
  loops; they encode the finite initial language directly.
- Remaining engineering gap: handle empty-word RFC narrowing certificates, then
  rerun Ferrum's RFC SRS examples and update certified SRS benchmark numbers.

## Practical Order

1. Implement and prove termination `Relative_Bounds` first. It reuses the
   complexity relative-bounds checker structure and is the smaller proof.
2. Refactor `check_bounds_generic` so the initial-language acceptance check can
   be parameterized.
3. Replace the conservative `RFC_Bounds` theorem with a direct finite-initial
   match-bounds theorem under the right-linear side condition.
4. Add overlay/WCR side condition later if benchmarks show it matters.
