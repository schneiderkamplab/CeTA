# Complete TRS and DP termination proof ablation (r984)

Recovery is complete: see [modular oracle recovery](modular-oracle-recovery.md).
The full modular replay preserves all r982 certified root sets. The results
below describe the original diagnostic ablation, not the current baseline.

This diagnostic disables both `exact-trs-proof` and `exact-dp-proof`, without
fallback. Complete nontermination certificates and processor-specific witnesses
remain enabled. Neither the production oracle nor the prover/checker changed.
This is an ablation result, not a replacement for the production high-water mark.

## Configuration

Baseline: the complete r982 replay in `docs/state-of-the-art.md`, Ferrum source
`4f97b3a5a4ccc3f70778951c1a11984e22bf7e62`, ledger HEAD
`aa39e7c10a32631622ebcac01240d141faf3d9e0`.
Certification exclusively uses `/work/dfm/festschrift/CeTA-CSR/ceta`, unchanged.

Input: r983's `target/complete-dp-ablation-r983/oracle-no-complete-dp.jsonl`.
Output: `target/complete-trs-ablation-r984/oracle-no-complete-termination.jsonl`.
SHA-256: `cb76201070c65da93d5200dae3e841ca7d1732f957485781a8f7c5de7a4bcea5`.
Size: 1,856,373,051 bytes. In addition to the previously removed 2,275 complete
DP payloads, this removes 1,065 complete TRS payloads and 3,116 preferred entries
across 3,052 state records. Integrity audit: zero forbidden actions, zero dangling
references, 15,357 retained witness definitions, including 297 complete TRS and
six complete DP nontermination witnesses.

Reproduction uses `scripts/ablate_complete_dp_proofs.py` with both
`--disable-atom exact-dp-proof --disable-atom exact-trs-proof`. Its focused test
checks selected removal, preservation of nontermination/local actions and source
data, and refusal to overwrite an existing output.

Replay: `timeout(60s, fail)`, 65-second harness,
`FERRUM_DP_LLM_NO_FALLBACK=1`, no top-level LLM, two Rayon threads, workers
64/24/12 for Standard/Innermost/CSR. Artifact root:
`target/complete-trs-ablation-r984/{standard,innermost,csr}`.

## Full batch results

| Category | Production baseline | Both complete termination kinds disabled | Lost roots |
| --- | ---: | ---: | ---: |
| Standard | 1338/1542 | 1197/1542 (898 YES, 299 NO) | 141 |
| Innermost | 311/366 | 307/366 (297 YES, 10 NO) | 4 |
| CSR | 110/110 | 109/110 (104 YES, 5 NO) | 1 |

No gains or polarity changes. All nontermination results survive. Standard's
141 losses comprise 122 Unknowns, 18 timeouts and one checker-rejected YES.
All four Innermost losses are timeouts; CSR's loss is Unknown.
All 1,613 retained batch certificates passed a second independent CeTA check:
`target/complete-trs-ablation-r984/second-ceta.json`.

Exact root inventories and compact baseline/ablation traces are in
`target/complete-trs-ablation-r984/comparison.json`, produced by
`scripts/report_complete_proof_ablation.py`. It normalizes TPDB path prefixes
and requires each replay root to exist in the baseline.

### Relaxed-time repeats

All 18 lost Standard timeouts and all four lost Innermost timeouts were repeated
with `timeout(180s, fail)`, a 185-second harness, unchanged ablated oracle and
no fallback. Standard's repeats used 13 and five workers; Innermost used four.
These are relaxed-time results, not improvements to the 60-second batch score.

- Standard recovered only `Transformed_CSR_04/MYNAT_complete_noand_GM`
  (67.776s). Four others returned Unknown and 13 still timed out.
- Innermost recovered `LISTUTILITIES_complete_noand_C` (155.031s),
  `LengthOfFiniteLists_complete_noand_iGM` (63.247s), and
  `PALINDROME_nokinds_iGM` (64.497s), all in
  `Transformed_CSR_innermost_04`. `LengthOfFiniteLists_nokinds_iGM` still timed
  out at 185.316s. A timeout alone does not establish an impossible continuation.
- All four recovered certificates passed a second independent CeTA check.

Taking the union with these repeats gives **1198 Standard, 310 Innermost,
109 CSR** certified: **140 / 1 / 1** roots still missing against production.
Repeat artifacts: `target/complete-trs-ablation-r984/standard-relaxed`,
`standard-relaxed-late`, and `innermost-relaxed`.

## Concrete decomposition gaps

The following are overlapping trace symptoms, not an exclusive causal partition:
115 Standard losses encounter a zero-candidate guidance lookup; 73 explicitly
report an unguided residual after transformation; 26 encounter an isomorphism
rejection for an exact usable-rules source. Other recorded rejections include
graph source-pair mismatch and changes to the active rule context.

- `Applicative_05/Ex9Maps`: reaches an unguided 21-pair, three-rule full DP state
  `1d19c94eba302b5e484ecf406ee3d2026f7bc7aecc2963d4f3e22774d96e68d2`.
- `Beerendonk_07/13`: a local general reduction pair reaches an unguided
  seven-pair/eight-rule innermost state
  `6ed7e895e282b228188bde0b78f93dc7b6feb8c947b72206f091f100326e39c2`.
- `Beerendonk_07/17`: transformations reach unguided children; other candidate
  usable-rule witnesses are rejected because their source is not isomorphic to
  the live state. Matching must preserve Q/R/minimality, not merely pair counts.
- CSR `Maude_06/csrdiv`: reaches unguided innermost DP state
  `242a7bad5f7b2279dc362ee9f961d55b4023e3d95d0457e81b429fd15908e598`
  (ten pairs, 19 rules). Its retained certified proof includes reduction pairs,
  instantiation, dependency graphs and size change.
- `Applicative_first_order_05/30`: modular uncurrying followed by exact
  path-order removal emits a rejected CPF. The emitted argument filter omits
  transformed symbols such as `filter2_0` and `|:|2`; CeTA cannot orient the
  resulting rules. The retained whole proof certifies. This is a concrete
  witness/reconstruction discrepancy requiring a symbol-transport audit, not
  evidence that the original system fails to terminate.

Fresh decomposition of five representative Standard proofs, each rechecked
twice by production CeTA, yielded 161 local events with complete-proof actions
excluded. These include uncurrying, strategy switching, DP generation,
reduction pairs, DP transformations, graph decomposition, usable rules,
innermost LHSS removal, path order and size change. Artifacts:
`target/complete-trs-ablation-r984/diagnostic-extraction` and
`target/complete-trs-ablation-r984/diagnostic-roots.txt`.
This establishes available extraction vocabulary for those proofs, not yet
successful independently guided execution of every extracted chain.

## Repair order

1. Repair transformed-symbol transport for the rejected uncurrying/path-order
   certificate, retaining checker rejection until reconstruction is correct.
2. Export and bind every node of the retained full proofs to independently
   findable live states, starting with `csrdiv` and representative Standard gaps.
3. Require recursive closure under strict no-fallback replay; preserve complete
   state context and reject unsafe aliases. Do not substitute whole proofs.
4. Treat slow but successful repeats as scheduling/efficiency work, separately
   from missing continuations. Keep production v54 and its verified totals intact.
