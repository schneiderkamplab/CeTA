# Native conditional orders and Q-aware usable rules

Implementation and verification, 2026-09-17. Artifact base:
`target/innermost-conditional-qaf-20260917/`. CeTA source and production
checker are unchanged; certification uses `/work/dfm/festschrift/CeTA-CSR/ceta`.

## Conditional polynomial synthesis

`conditional-poly(max-coefficient=N)` synthesizes affine integer interpretations
using one bounded QF_NIA query, jointly selecting the interpretation, signed
usable-rule obligations, and dependency pairs to delete. It does not enumerate
interpretations or import the source proof's model. Structural induction builds
the constraint proof following CeTA's `Bounded_Increase_Impl.check_cc_prf`;
arithmetic and signed usable-rule closure are independently checked before CPF
construction. Existing modular general-reduction-pair reconstruction exports
the freshly synthesized action and exposes its residuals.

Initial September scope: ordinary minimal innermost DP states with nonempty suitable Q,
at most 16 pairs, affine interpretations, and coefficient bounds 1–16. These
are conservative synthesis limits, not claims that larger problems cannot use
conditional orders. Structural proof generation is also bounded. Failure to
construct the constraint proof or solve the query returns no transformation.

### October extension for Standard roots

The same native processor now supports degree-two interpretations, including
mixed monomials. `before` and `after` select up to three adjacent DP steps in
total. All sequences are covered, conservatively overapproximating the graph;
search is limited to 4,096 sequences and 16 pairs. One bounded SMT query selects
coefficients and deleted pairs. Term expansions are cached and shared through
SMT definitions, with independent checked-integer validation of the result.

`squares=1` is a focused degree-two template: rewrite/Q symbols are affine,
while DP-only roots are squares of homogeneous linear forms plus constants.
No symbol names or retained coefficients are used. The wider quadratic search
remains available. CeTA's exact square criterion is used for supported weak
conditional/bound obligations only; usable-rule orientations still require
coefficient-wise compatibility. Mixed coefficient signs require both rule
directions rather than an assumed monotonicity sign.

`reinduct=N` permits bounded fresh induction when constructor substitution has
made an existing induction hypothesis unusable. It emits explicit deletion of
the old hypothesis before re-induction; node, depth and time limits remain in
force. Defaults retain affine synthesis, one predecessor and no re-induction.

Artifacts are under `target/standard-q-conditional-20261011/`. The focused
`family-root-v13/` replay certifies eight previously missing Standard YESs,
including `Beerendonk_07/24` and `GTSSK07/cade14`; `beer14-root-v16/` certifies
`Beerendonk_07/14` after additional native narrowing/residual closure. These
runs use state-local, parameter-only guidance with fallback disabled. Consult
`state-of-the-art.md` for the consolidated baseline, rather than summing local
probe successes. CeTA is unchanged. `full-library-v12.log` records 1,056 passed
tests with zero failures or ignored tests; `python-tests-final.log` records 83
focused passing tests.

Both full `Mixed_innermost/cade05` and `cade13` proofs certify, including renamed
test inputs. Missing-condition and missing-interpretation mutations are rejected.
The complete `full-v2/` no-fallback replay recovers both roots: 291/311 versus
289/311, zero losses. This is parameter/native-only guidance, not supplied
interpretations. The complete replay uses 300-second root ceilings.

## Q-aware argument-filtered usable rules

Native KBO/RPO search can jointly synthesize filtering and usable rules without
imposing the older restrictive Q-filter condition, provided the independently
checked CeTA innermost criterion holds. The actual Q, nfs, minimality and active
rule context are preserved. Matching at a term's root is mandatory even for a
collapsing filter; the filter controls descent into arguments. Supplied usable
rules themselves must be closed. Independent capped arguments use distinct
fresh variables.

The hard `wiehe13` source DP state now has a certified native KBO-to-polynomial
continuation. Its initial full replay exposed a different unguided child; that
actual child also closes natively in `wiehe13-live-closure.xml` and passed two
CeTA checks. These local proofs are not counted as full-root recovery until the
root replay succeeds. The subsequent complete `full-v4/` replay does recover
wiehe13: **292/311**, three gains and zero losses against 289, with all 292
certificates independently rechecked twice. Exported event hints receive no independent certification
credit and contain only native actions and bounds.

## Verification and ongoing residual closure

- `library-v9.log`: 1,021 passed, zero failed or ignored.
- `python-tests.log`: 38 passed.
- `conditional-ceta-tests.log`: full and renamed proofs plus negative mutations.
- `qaf-ceta-tests-v2.log`: full native chain and unchecked-rule mutation.
- `production-guard/`: 311/311, exact comparison without losses; all proofs
  independently rechecked twice in `production-rechecks.jsonl`.
- `csr-guard/`: 110/110, all independently rechecked twice in `csr-rechecks.jsonl`.

Residual exploration continues separately from timing optimization. The first
39-state wave closed four local states, including a PEANO child. Guidance is
merged monotonically into experimental parameter profiles; production and CSR
profiles are not replaced. No broad timing or enumeration-based search changes
are part of this implementation.

## Follow-up: marked roles after rule deletion

The Length frontier exposed a separate canonicalization defect: when all
occurrences of an unmarked companion disappear, its marked DP symbol was renamed
as an ordinary symbol. CSR import then attempted legacy alias recovery using an
obsolete source-rule index. Canonicalization now preserves the sharp role even
without a remaining companion. The source-rule metadata and parser validation
are not discarded or relaxed. A synthetic empty-R semantic-CSR regression
exercises this boundary.

Verification with `ferrum-v10`: 42 canonicalization tests and all 1,022 library
tests pass; production Innermost 311/311 and CSR 110/110 remain certified with
exact comparisons and additional double checks (`production-v10-*`, `csr-v10-*`).
The Length root itself is not claimed recovered: another retained non-minimal
child remained inapplicable to the tested native order families. The full native
`full-v6/` replay is separate from the committed 292-root baseline above.
