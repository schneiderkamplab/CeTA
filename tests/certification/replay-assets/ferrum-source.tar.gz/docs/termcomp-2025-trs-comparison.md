# TermCOMP 2025 TRS Comparison

Official rows are read from `https://termcomp.github.io/Y2025` summary JSON files.
Ferrum rows are local runs over the selected TPDB-ARI categories.
Rows inside each category are sorted by total solved/certified answers, descending.
`CSR-DP proofs` counts Ferrum proofs containing a native `<csrDependencyPairs>`, `<csrSafeDependencyPairs>`, or `<csrConservativeDependencyPairs>` processor. `CSR-DP transform cert` counts full certifications and failures that CeTA reports below the CSR-DP processor, which means the CSR-DP transformation itself was accepted even if the remaining DP proof was not. `CSR-DP full cert` requires the whole CPF/CeTA proof to certify.
Ferrum per-example artifacts are in `target/termcomp-runs/20260731-aprove06-next8-current-8w60s`.

## TRS_Standard

| Tool/config | Total | YES | NO | Certified YES | Certified NO | MAYBE | Timeout | Memout | Error | Cert failed | CSR-DP proofs | CSR-DP transform cert | CSR-DP transform fail | CSR-DP full cert | CSR-DP cert failed | CSR-DP parse fail | CSR-DP proc fail | CSR-DP unsupported | CSR-DP checker fail |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| AProVE25_uncert | 1528 | 1030 | 272 | 0 | 0 | 0 | 135 | 0 | 91 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| AProVE25_cert | 1528 | 0 | 0 | 946 | 262 | 0 | 153 | 0 | 167 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| NaTT_uncert | 1528 | 877 | 169 | 0 | 0 | 436 | 46 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| MU-TERM 2025_uncert | 1528 | 693 | 96 | 0 | 0 | 21 | 718 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| NTI25_uncert | 1528 | 291 | 269 | 0 | 0 | 885 | 74 | 9 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| Ferrum enhanced timeout=60s | 8 | 1 | 0 | 1 | 0 | 0 | 7 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
