# Embedded evidence cleanup

## Guarded-list role discovery (2026-09-09 follow-up)

The production graph processor still contained a literal symbol/variable
selector for the guarded-list terminal theorem. Replaced it with bounded,
injective structural role discovery in
`src/proving/processors/dp/guarded_list.rs`:

- The exact two-pair language supplies the descent, continuation, conjunction,
  predicate roles, and live element/tail variables.
- Independent local constructor/predicate laws identify the remaining roles;
  this is not a whole-TRS template or an exact signature/rule-count match.
- Ambiguous or missing required roles, malformed pairs, and invalid guard/tail
  replacement maps decline the processor. Discovery has explicit work and
  candidate bounds.
- If rule removal deletes the empty-list continuation, a fresh unused symbol
  supplies that optional witness role. No deleted symbol name is assumed.
- The terminal route requires minimality and no weak pairs. CeTA retains its
  unchanged complete residual-rule semantic-rank checks; role discovery alone
  is not a substitute for certification.

Focused verification: the original default proof, an extension with an
unrelated safe rule, and a fully symbol/variable-renamed, rule-reordered
extension all certify with `/work/dfm/festschrift/CeTA-CSR/ceta`. Wrong truth
and wrong tail-variable witnesses are rejected. Recognizer tests cover missing
and ambiguous roles, malformed pairs, invalid replacement maps, removed
continuations, pair order, and XML escaping. CeTA sources/checker unchanged.
This is affected-case verification, not a fresh complete-category replay.

Focused release A/B oracle-only measurement:
`target/guarded-role-ab-20260909/{results,summary}.json`. Three alternating
trials per version of `Maude_06/OvConsOS_nokinds.ari`, unchanged global v271
oracle, Rayon=2, `FERRUM_DP_LLM_NO_FALLBACK=1`, `timeout(300s, fail)`:

- Before: 6.524, 6.775, 6.827 seconds; median 6.775 seconds.
- After: 11.482, 6.825, 6.875 seconds; median 6.875 seconds (+1.5%).
- Both versions: 3/3 certified; all six CPFs passed two independent CeTA
  checks. Each trace has 19 events; the affected graph event reports 0 ms
  at millisecond resolution in every trial.
- CPF differences are confined to the fresh unused continuation symbol and
  semantically unused legacy variable fields. The proof structure is unchanged.

The first after-trial was slower; these six measurements alone do not establish
its cause or statistical significance. No affected-root coverage loss was found.
The report records binary/oracle/checker hashes; no full-category timing claim
is made. Changed release binary SHA-256:
`5dfec90e19f82336bf75207fb26883f2512903648f949b28959c88eb6de201ad`.

Checkpoint before cleanup: Ferrum `a73daad` (2026-09-08). This includes the
new AG01 #4.19 retained loop. Its native witness test passed; it was not part
of the completed r973 replay. That replay certified 1,039 YES and 299 NO out
of 1,542 roots, with no checker failures. These results predate the removal
of implicit embedded evidence and must not be described as a clean
oracle-only baseline until the following audit is complete.

## Confirmed production evidence

- Top-level scheduler: Zantema aabb complete proof, attempted before guidance.
  The implicit scheduler branch has been removed in the cleanup worktree.
  Its proof files remain available for migration into external evidence.
- Nontermination: 17 compiled pattern proof trees (nine Enger, eight AProVE10).
- Nontermination: 10 compiled loop witnesses, including the checkpointed
  AG01 #4.19 addition.

## Structural candidates requiring review

- `hydras_projection_loop`: removed from production and retained test-only.
  Its seven affected available Hydras roots remain oracle-certified in r975.
- `synthesize_pair2hard_shape_matrix`: confirmed overly specific fixed matrix
  entries. Removed from production; retained only for validator tests. Search
  now proceeds through the existing general bounded matrix encoding.
- Counter-transfer automaton schemes and degree-four/unary matrix templates:
  review naming independence and the size of the represented problem class.
  The counter-transfer recognizer is now test-only. Its two affected roots
  regressed to Unknown in r975: v53 requested direct-loop instead of retaining
  the automaton action. Their preserved certificates were migrated in
  `target/embedded-cleanup-ta-r976` into oracle v54. The focused r976 replay
  (`target/embedded-cleanup-no-r976`) then certified all nine affected roots,
  with zero failures in 26 seconds. The two automata are terminal witnesses;
  no hidden residual chain is replaced. No full-category replay was run for
  this step, per user request.

## Fixed matrix-template removal (r977)

Removed production calls to the cyclic unary 3D, unary 3D/4D, degree-four
uncurrying Arctic and degree-four KBO candidates. Their literal witnesses
remain test-only. The public `applicative-reduction-pair` atom now delegates
to general bounded KBO synthesis with the live context, required strict rules,
options and deadline; general Arctic synthesis no longer tries fixed seeds.
This preserves the atom's syntax, not its previous default-search performance.

Only affected examples were replayed with v54, fallback disabled, and
production CeTA-CSR:

- `target/embedded-cleanup-matrix-standard-r977`: z01, z05 and Mixed_TRS/7,
  three certified YES, zero failures.
- `target/embedded-cleanup-matrix-innermost-r977`: AG01_innermost/#4.31,
  one certified YES, zero failures.

Release build and all 12 Arctic-filtered tests passed; `git diff --check`
passed. CeTA was unchanged. These focused checks establish oracle coverage
for the identified affected roots, not general default-search parity or an
exhaustive repository-wide absence of other special cases.

## Fixed rational-template removal (r978)

Removed production dispatch to `muterm_ex1_gm03_rational_candidate`,
`muterm_exintrod_zan97_rational_candidate`, `halving_rational_candidate`,
and `predecessor_comparison_rational_candidate`; all four are test-only.
The first two explicitly match benchmark symbol names and carry literal
interpretations. The latter two reconstruct fixed interpretations for narrow
residual shapes. Rational processing now directly uses the existing general
linear/usable-rule solver and quadratic solver continuation, with unchanged
exact validation.

Release build, ten rational-filtered tests and diff checks passed. Focused
v54 oracle-only replays with production CeTA-CSR certified seven YESs:

- `target/embedded-cleanup-rational-standard-r978`: Strategy_removed_AG01/#4.26,
  AProVE_06/identity and AProVE_07/thiemann01 (3/3).
- `target/embedded-cleanup-rational-innermost-r978`: ordinary and applicative
  AG01_innermost/#4.26 (2/2).
- `target/embedded-cleanup-rational-csr-r978`: Ex1_GM03 and ExIntrod_Zan97 (2/2).

No checker failures and no CeTA changes. Default-search performance has not
been established after removing these seeds.

## Semantic-labeling selector generalization (r979)

Replaced four signature-specific production selectors (binary/two-constant,
binary marked, marked/unary identity and unary affine) with a bounded
low-support affine family. It enumerates a distinguished constant (or none),
an arbitrary symbol/argument projection, and a carrier offset. Remaining
symbols receive zero interpretations. There is no exact symbol-count,
arity-pattern or benchmark-name gate. Candidate generation respects the
existing model count limit, and all candidates still pass through the normal
full semantic-model validity check before use. Historical selector tests
remain test-only; more general constructor-role families remain unchanged.

The new renamed/extended-signature, arbitrary-argument and limit regression
passes, as do all 19 semantic-labeling-filtered tests and the release build.
Focused affected-root replay is recorded at
`target/embedded-cleanup-semantic-r979` (v54, no fallback, production CeTA-CSR).
It retains all four certified YESs (z01, z21, z22, z27); z20 remains the
pre-existing Unknown. Exact comparison with r974 has no losses or gains,
and there are zero certification failures.
No CeTA changes. This does not claim default-search timing parity.

## Structural transformed-CSR recognition (r980)

Removed literal wrapper names and the `a__` prefix from production recognition.
GM04 roles are inferred from paired outer-wrapper transitions, then checked
against the unchanged complete generated-rule schema. The replacement-map
heuristic infers wrapper transport and activated symbols directly from rules.
It remains a proposal, not a stand-alone termination justification.

Conservative limitation: GM04 role discovery requires both outer transitions;
systems missing either decline this route, although the underlying theorem
allows subsets. No name-based fallback remains.

All four recognition tests pass, including renamed roles/replacement maps,
foreign-rule rejection after renaming, prefix-free activated symbols and
name-only rejection. Release build and diff check passed. Focused v54
oracle-only replay `target/embedded-cleanup-recognition-r980` certified all
four roots: Ex1_2_AEL03_C, Ex16_Luc06_C, ExConc_Zan97_C and Ex1_Luc02b_FR.
Zero certification failures; CeTA unchanged. No full-category replay run.

## Final validation work (r982)

The first library run had 890 passes and three failures. Two were cleanup
integration issues: the guarded-add test still expected an implicit witness
lookup (now an explicit fixture-import test), and strategy classification
missed reciprocal unary-wrapper transitions (now detected structurally).
Both focused repeats passed. The concurrent persistent-Z3 test failed once
and passed in isolation. The final serial library run passed 892 tests with
zero failures; it filtered only the unchanged slow narrowing-alternative test,
which had already passed in the first complete run. Nothing was newly ignored.
Logs: `target/embedded-cleanup-final-tests.log`,
`target/embedded-cleanup-final-serial-tests.log`, and the corresponding
`embedded-cleanup-{dispatch-fix-test,explicit-import-test,z3-repeat}.log` files.

Preliminary r981 replay processes were stopped when the structural dispatch
fix changed production code. Artifacts were preserved; they are not a final
baseline. The final r982 replay uses one rebuilt binary throughout.

## Completion gates (overall cleanup, outstanding verification)

1. Preserve complete source certificates and extract individually keyed
   processor actions, including nested states, into the external oracle.
2. Remove compiled example registries; keep generic witness parsers and
   independent validators available to explicit oracle actions.
3. Replace benchmark search shortcuts with general bounded searches where
   practical; record default-search losses separately from oracle losses.
4. Replay Standard, CSR and Innermost with fallback disabled. Account for
   every loss against the checkpoint; do not count an implicit retained proof
   as oracle guidance.

The identified production shortcuts have been removed or generalized. The scheduler shortcut and production calls to
both compiled witness registries have been removed. All 27 JSON constants
and registry dispatch functions are now test-only. Generic parsing and
validation remain available; the projection-loop recognizer and reviewed
fixed matrix-template functions are now test-only as described above.
Compilation and final three-category replays pass. This is not a claim of
exhaustive absence of all conceivable example-specific patterns, nor of
default-search performance parity.

## Final complete post-cleanup oracle replay

Committed source checkpoint: `4f97b3a5a4ccc3f70778951c1a11984e22bf7e62`
(`codex/aaecc-20260831`, worktree `ferrum-aaecc`).

All final r982 category root sets match their certified baselines, with zero
losses, gains, polarity changes or certification failures:

| Category | Certified YES | Certified NO | Total | MAYBE | Timeout |
| --- | ---: | ---: | ---: | ---: | ---: |
| Standard | 1039 | 299 | 1338/1542 | 200 | 4 |
| Innermost | 301 | 10 | 311/366 | 55 | 0 |
| CSR | 105 | 5 | 110/110 | 0 | 0 |

Artifacts: `target/embedded-cleanup-final-r982/{standard,innermost,csr}`.
Each contains `details.json`, `summary.md`, produced proofs, and a
`second-ceta.json`: every one of the 1,759 retained certificates passed a
second independent production CeTA invocation. The root-set comparison is
`target/embedded-cleanup-final-r982/comparison.json` (absolute/relative paths
normalized to TPDB-relative identities).

Prover ceiling 60s (`timeout(60s, fail)`), harness 65s, no fallback and no
top-level LLM. Workers: Standard 64, Innermost 12, CSR 8; Rayon threads: two.
Elapsed times: 808s, 907s, 501s respectively under concurrent category load.
Ferrum binary SHA-256:
`3a7f6f8c324f4a28fe138fc832453c3216000afd64cc70f9de316b2482b23cb0`.
Oracle: `target/embedded-cleanup-ta-r976/oracle-v54.jsonl`, SHA-256
`778a4f08842209866538865d254da0a7503d8c9b67a69460ef7a3efc37e84c56`.
CeTA-CSR is unchanged: commit `b018e39ca3d4de9a1fe1e50df2b4feecd2ede6f5`,
binary SHA-256 `a6d8977c1738daa3e225f0e52443fb56659d09b175516d4215bcd77a3bf0ab46`.
Unrelated dirty files in the shared CeTA-CSR worktree were not touched or committed.

## Completed post-removal Standard replay

`target/embedded-cleanup-r974/details.json` reproduces all 1,338 certified
decisions on the identical 1,542-root set: 1,039 YES, 299 NO, 200 MAYBE,
four timeouts, zero certification failures. Runtime: 665 seconds. Exact
comparison with r973 gives zero losses, zero gains and zero polarity changes.
Thus removing the registries, implicit aabb dispatch and fixed pair2hard
matrix shortcut did not reduce this Standard oracle-guided result set.
This does not establish default-search parity or complete structural cleanup.

Configuration: oracle-v53, `timeout(60s, fail)`,
`FERRUM_DP_LLM_NO_FALLBACK=1`, `--no-top-level-llm`, 64 jobs, two Rayon
threads, 65-second harness limit. Ferrum is the uncommitted cleanup atop
`a73daad`; executable SHA-256:
`b213833178fcc0a4de4ec9332d55d18a94cb23960193a0369bf7ef0ecb69f776`.
Production CeTA-CSR commit: `b018e39ca3d4de9a1fe1e50df2b4feecd2ede6f5`;
checker SHA-256:
`a6d8977c1738daa3e225f0e52443fb56659d09b175516d4215bcd77a3bf0ab46`.
CeTA was not changed. CSR and Innermost were pending at r974; final r982
results above supersede that intermediate verification state.
