# CeTA 3.9 to CeTA-CSR Extension Review

Date: 2026-08-03

This review compares the imported CeTA 3.9 source commit `8e6e5f9` with the
last committed CeTA-CSR revision `1c090a7`. It deliberately excludes newer
uncommitted Isabelle work.

## Executive Summary

- CeTA 3.9 already represented context-sensitive rewriting as a special case
  of forbidden-pattern rewriting, but its positive forbidden-pattern proof
  datatype contained only assumption plumbing. It did not provide a standalone
  native CSR termination processor pipeline.
- CeTA-CSR adds native CSR rule removal, several CS-DP constructions, minimal
  CS-DP reasoning, CSR-aware graph/usable-rule/subterm/size-change processors,
  the GM transformation, and direct CSR loop certificates.
- The current top-level CSR proof syntax was grown in three layers. It should
  be replaced by one recursive datatype. This removes the special
  `CSR_Rule_Removal_Then_Improved` composition constructor without losing power.
- The RFC/Matchbounds extension added seven termination-proof constructors.
  Two are demonstrably redundant in proof power, while several implementation
  variants are connected by equality or implication theorems and should be
  normalized behind one public checker interface.
- `CSR_Innermost_Switch.thy` proves a useful theorem, but the committed checker
  has no proof datatype whose soundness conclusion is innermost CSR
  termination. Its current orthogonality wrapper therefore checks a full CSR
  proof and adds no power.

## CSR Proof Datatypes

The committed tree has four CSR-specific proof datatypes:

| Datatype | Purpose |
| --- | --- |
| `csr_dp_termination_proof` | Recursive native CS-DP proof language |
| `csr_termination_proof` | Empty CSR, rule removal, native DPs, safe DPs |
| `extended_csr_termination_proof` | Improved/conservative DPs and orthogonality wrapper |
| `gm_extended_csr_termination_proof` | Previous proof language or GM transformation |

The latter three are successive wrappers rather than three distinct semantic
problem types. The semantic predicates used underneath are:

- `finite_csr_dpp` for unrestricted CSR chains;
- `finite_min_csr_dpp` for minimal CSR chains;
- ordinary `finite_dpp` after a construction permits an ordinary DP proof.

### Recommended Unified Datatype

Replace the three top-level datatypes with one recursive datatype containing:

```isabelle
datatype csr_termination_proof =
    CSR_Empty
  | CSR_Rule_Removal redtriple rules csr_termination_proof
  | CSR_Native_DPs pairs csr_dp_termination_proof
  | CSR_Safe_DPs pairs csr_dp_termination_proof
  | CSR_Improved_DPs symbol pairs csr_dp_termination_proof
  | CSR_Conservative_DPs symbol pairs auxiliary_rules csr_dp_termination_proof
  | CSR_GM_Transformation mark constant active_map trs_termination_proof
```

The unified soundness theorem should conclude the public, source-signature
property

```isabelle
SN (sig_step (funas_trs R) (csstep mu R)).
```

Branches that establish unrestricted `SN (csstep mu R)` simply weaken their
result. Rule removal can then recurse into every other CSR processor, making
the combination-specific `CSR_Rule_Removal_Then_Improved` unnecessary.

### Compatibility and Evidence Migration

Keep old CPF elements as parser-level compatibility aliases:

- parse `<csrRuleRemovalThenImproved>` as a nested `CSR_Rule_Removal` followed
  by `CSR_Improved_DPs`;
- parse the old conservative and GM wrappers directly into unified
  constructors;
- emit only the canonical nested form from new Ferrum versions.

Ferrum utility-guidance JSONL manifests do not themselves contain serialized
proof trees. They contain hashes of raw/structurally canonicalized input states
and candidate names such as `graph`, `poly`, or `subterm`. The wider oracle
evidence system does retain CPF text, however:

- campaign databases store source problem states in `problems(problem_key,
  cpf)`;
- replay databases may store them in `replay_cpf_cache(problem_key, cpf)`;
- canonicalization caches store `canonical_cpf_cache(raw_key,
  canonical_cpf)`;
- campaign artifact directories retain generated proof CPFs and checker
  diagnostics.

This is the corpus used by `scripts/upgrade_oracle_canonical_keys.py` when it
re-runs `ferrum canonicalize-cpf`. Most key material is an input-state CPF, not
a termination-proof tree, so changing proof constructors should not change raw
or canonical oracle keys if the input serializer remains unchanged. Generated
proof artifacts can contain the old XML constructors and must remain readable.

Keep old tags as parser aliases, make the new emitter produce one canonical
form, and test that canonical input-state hashes remain unchanged. An optional
normalizer may materialize migrated proof artifacts or caches separately; do
not rewrite immutable campaign ledgers in place.

## Matchbounds Before the Extension

CeTA 3.9 supported:

1. `Bounds bounds_info` in ordinary TRS termination proofs.
2. Both `Roof` and `Match` bound types.
3. Matchbounds complexity certificates.
4. Relative Matchbounds for complexity through
   `Matchbounds_Rel_Complexity` and `<relativeBounds>`.
5. The abstract right-forward-closure definition and its termination theorem
   in `Right_Forward_Closure.thy`.

It did not support relative bounds as a termination processor, nor a CPF
termination certificate based on a finite RFC initial language. In particular,
the executable `rfc_bounds_tt` checker and its CPF route are additions, not
CeTA 3.9 functionality.

## Matchbounds Added by CeTA-CSR

The extension added these ordinary termination-proof constructors:

| Constructor | Meaning |
| --- | --- |
| `Relative_Bounds` | Move bounded strict rules to the weak component and prove the residual |
| `Rfc_Bounds` | Direct finite-initial-language RFC bounds proof |
| `Rfc_Automaton_Closed_Bounds` | Direct RFC proof using checked automaton closure |
| `Rfc_Relative_Bounds` | Conservative RFC-relative wrapper |
| `Rfc_Automaton_Closed_Relative_Bounds` | Partial deletion plus residual proof using automaton closure |
| `Rfc_Matchbox_Relative_Bounds` | Matchbox-style split/right-extension relative certificate |
| `Rfc_Native_Matchbox_Relative_Bounds` | Native evaluator witness for the Matchbox-relative obligations |

The extension also formalized finite RFC initial languages, executable RFC
narrowing, paired tail-state acceptance, automaton closure, suffix/right
extension checks, no-top-redex checks, inner-splice checks, and relative
deletion followed by a residual proof.

### Proven and Effective Redundancy

1. `rfc_native_rel_matchbox_relative_bounds_imp` proves that every accepted
   native-relative certificate is accepted by the generic Matchbox-relative
   checker. Thus the native-relative format has no additional proof power. It
   remains useful only as an efficient witness/checking representation.
2. The proof of `rfc_relative_bounds_tt` derives acceptance of the older
   direct `Matchbounds_Impl.rfc_bounds_tt`. Its checker also requires deletion
   of exactly all strict rules. Consequently `Rfc_Relative_Bounds` adds no
   termination power over `Rfc_Bounds`; it is historical composition plumbing.
3. Indexed and unindexed Matchbox closure and right-extension implementations
   are connected by explicit equality lemmas. They should not be exposed as
   different certificate notions.
4. The fast no-top-redex implementation has a sound implication into the
   reference implementation. It is an implementation optimization, not a new
   proof method.

`Rfc_Automaton_Closed_Bounds` appears to be the all-rules terminal special case
of `Rfc_Automaton_Closed_Relative_Bounds`, but the committed development does
not state a checker-level implication theorem. Prove that implication before
removing the direct constructor.

No committed theorem establishes that automaton-closed relative certificates
and Matchbox-style relative certificates subsume one another. Their closure
obligations differ, so both should remain.

### Recommended Matchbounds Shape

Separate three concerns that are currently mixed in the proof datatype:

1. the processor semantics: ordinary bounds or RFC-relative bounds;
2. the RFC closure criterion: explicit RFC narrowing, automaton closure, or
   Matchbox closure/right extension;
3. the witness/checker implementation: native versus generic, indexed versus
   unindexed, and fast versus reference checks.

The public proof tree should expose only the first two. A suitable target is:

```isabelle
datatype rfc_closure_certificate =
    RFC_Explicit initial_terms
  | RFC_Automaton_Closed initial_terms
  | RFC_Matchbox initial_terms matchbox_witness

datatype trs_termination_proof =
    ...
  | Bounds bounds_info
  | Relative_Bounds bounds_info deleted trs_termination_proof
  | RFC_Relative_Bounds rfc_closure_certificate bounds_info deleted
      trs_termination_proof
```

Use delete-all plus the empty residual proof as the canonical terminal RFC
form. Normalize a native Matchbox witness to the same semantic obligations as
the generic Matchbox certificate before entering the recursive checker. Keep
indexed tables, native evaluators, and fast no-top-redex tests behind that
interface as executable refinements with proved equality or implication to a
single reference predicate.

The cleanup sequence should be proof preserving:

- first prove the missing direct-to-relative implication for automaton-closed
  bounds;
- add normalization theorems and positive/mutation-negative tests for every old
  constructor;
- parse all old XML tags into the canonical representation;
- switch Ferrum to emit only the canonical form;
- only then remove the redundant internal constructors.

Do not collapse automaton-closed and Matchbox closure into one criterion: no
subsumption theorem currently connects them. Also retain ordinary
`Relative_Bounds`; it is not an RFC witness variant.

## Why CSR_Innermost_Switch Exists

The intended processor is mathematically useful. The theory establishes:

```isabelle
csr_switch_overlay R
  ==> wf_trs R
  ==> SN (innermost_csstep mu R)
  ==> SN (csstep mu R).
```

It formalizes the AProVE-style observation that, under the checked
orthogonality/overlay conditions, proving innermost CSR termination is enough
to prove full CSR termination. This can be a large power and performance win
because innermost CS-DP problems may have fewer relevant chains.

The committed checker cannot exploit it. `Orthogonality_Checked_CSR_Proof`
contains a `csr_termination_proof`, whose soundness theorem already proves full
`SN (csstep mu R)`. The branch checks orthogonality and then proves exactly the
original goal with its child. It never calls
`csr_switch_overlay_innermost_termination`.

To make the theory useful:

1. introduce an `innermost_csr_termination_proof` datatype, or a mode-indexed
   CSR/CSDP proof datatype;
2. give its checker a theorem concluding
   `SN (innermost_csstep mu R)`;
3. change the switch constructor to contain that proof;
4. check `csr_switch_overlay R` and apply the established switch theorem;
5. only then expose the constructor in CPF.

A mode-indexed CSDP problem is preferable if the same graph, reduction-pair,
usable-rule, and SCT processors are sound in both modes. It avoids building a
second mostly duplicated proof language.

### Expected Practical Power

Innermost CSR/CSDP should add practical power on the eligible overlay/orthogonal
fragment, not merely improve presentation. The innermost restriction can
remove candidate chains and graph edges before SCC decomposition, and then all
downstream usable-rule, reduction-pair, subterm, and SCT processors see smaller
problems. AProVE has used exactly this switch on CSR examples before applying
its termination machinery.

### Isolated Implementation Status

The cleanup and innermost development are isolated from the shared CeTA tree:

- worktree: `/work/dfm/festschrift/CeTA-CSR-codex-rfc-innermost`;
- branch: `codex/rfc-innermost-cleanup`;
- RFC cleanup commit: `f5e433c`;
- experimental child session:
  `experimental/CSR_Innermost_Mode/CSR_Innermost_Mode_Dev.thy`.

The RFC cleanup replaces six internal RFC proof constructors with one
criterion-indexed representation while retaining every old CPF tag as a parser
alias. The isolated generated checker accepts all 330 frozen certified
Matchbounds/RFC certificates (319 distinct examples) and all eight previously
certified native-Matchbox certificates. Thus the representation cleanup has no
observed proof-power regression. The native tag is normalized to the generic
Matchbox criterion using the proved native-to-generic implication.

The thin innermost child first proved the missing semantic foundation rather
than merely changing a DP flag:

```isabelle
finite_mode_csr_dpp CSR_Innermost mu (mu_CSDP_on shp mu D R) R
  ==> SN (innermost_csstep mu R)
```

under the standard well-formedness, right-hand-side active-variable, and
defined-symbol coverage conditions. It also proves the useful final rule:

```isabelle
csr_switch_overlay R
  ==> finite_mode_csr_dpp CSR_Innermost mu (mu_CSDP_on shp mu D R) R
  ==> SN (csstep mu R)
```

The proof defines an innermost CSDP transition carrying the exact active-redex
normal-form obligation from `innermost_csstep`. It establishes root/non-root
decomposition, marked simulation of non-root steps, first-root progress for
minimal innermost-nonterminating terms, preservation of minimality, extraction
of active defined RHS subterms, and the resulting CSDP chain. Consequently the
theorem proves strong normalization of the intended innermost CSR relation and
uses the overlay switch only for the final lift to full CSR termination.

That foundation has since been promoted into the production extension session.
The isolated branch now contains commits `b22d7ce`, `9aacbf2`, and `925adb5`
for the innermost CSR dependency-pair foundation, chain refinement, and sharper
innermost graph approximation. The experimental child session has been removed;
the production theories are:

- `CSR_Innermost_DP_Checker.thy`, for the mode-sensitive chain and graph layer;
- `CSR_Innermost_Unhiding_Checker.thy`, for the direct Alarcon-Lucas
  hidden-term/unhiding construction;
- `CSR_GM_Transformation.thy`, for the top-level CSR integration;
- `CPF_Proof_Parser.thy`, which accepts `<csrInnermostDependencyPairs>`.

The direct construction checks coverage of replacement-map CSDPs, collapsing
CSDPs, hidden-term pairs, original weak rules, and required unhiding
projections. Its child is deliberately a full ordinary DP problem:

```isabelle
dpp_ops.mk J False False P [] [] []
  (R @ direct_projection_rules_list mu (defined_list R) R)
```

Thus the final theorem derives `SN (csstep (mu_of mu) (set R))` from ordinary
DP finiteness; it does not silently substitute innermost DP finiteness for the
required full relation. The projection TRS is reconstructed internally with
the proved executable characterization `hides_position_list_correct`.
CPF-supplied auxiliary rules are coverage evidence only: they must contain the
original rules and every exact required projection, while redundant
projections are ignored by the transformed DP problem.

This exact reconstruction matters on `CSR_04/Ex1_GM03.ari`. The preserved
legacy proof supplied many redundant projections but its first usable-rule
reduction-pair step omitted the exact required rule `s(x) -> x`. Marking the
ordinary DPP as minimal, or accepting the empty usable-rule set, would be
unsound. Ferrum now emits a typed recursive MU-TERM proof whose collapsing SCC
carries the exact extended-basic usable-rule reduction triples and whose
noncollapsing SCCs retain native CSR semantics. CeTA-CSR checks the five native
typed pairs, the two exact unhiding bridges, graph coverage, each recursive
reduction-pair deletion, and the final transfer back to `SN (csstep mu R)`.

A production-gate audit on 2026-08-16 sharpened this boundary. The exact U3
closure of the hard expanded component contains all eight source rules, not
the five `p`/`leq` rules printed by MU-TERM. The retained rational model then
fails on the recursive `diff` rule. Conversely, the basic innermost
context-sensitive usable-rule theorem requires both the pairs and the usable
rules to be context-sensitively conservative. The hard false branch is not:
variables frozen below `IF` on its left become active below `DIFF` on its
right. This premise cannot be removed from CeTA's checker.

The production extension implements the latter sound route: an invariant
graph checker establishes the typed collapsing premises once, then a bounded
recursive checker accepts only full `Redpair_Proc` steps and a terminal graph.
The executable closure includes the two unhiding bridges in every synthesized
weak obligation. Ferrum therefore cannot emit a model that CeTA subsequently
checks against a larger rule set.

On 2026-08-20, the default release strategy proved Ex1_GM03 in 6.092 seconds.
The freshly exported checker certified the resulting CPF twice in 0.031 and
0.012 seconds. The retained production artifact is
`target/csr-ex1-gm03-production-certified-v26-20260820/proof.cpf.xml` (SHA-256
`1823f399dbd69a8f5e45f7b0309b602a566cdf01e0050fad0371fe1f6dfce5de`).
Its root is `<csrMutermTypedDependencyPairs>`; it contains no assumption or
flattened `<expandedCsrProof>` boundary.

Verified regression evidence is in the isolated CeTA worktree:

- `examples/csr_innermost_unhiding_empty_dps.cpf.xml` is a terminal empty-DP
  positive fixture;
- `examples/csr_innermost_unhiding_projection.cpf.xml` is a nontrivial positive
  fixture with an inactive RHS context, a hidden pair, and an exact projection;
- the two `.reject.cpf.xml` mutations omit respectively the projection and the
  hidden pair and are rejected at the intended checks.

The isolated Isabelle home is selected with
`USER_HOME=/work/dfm/festschrift/.isabelle-codex-rfc-innermost-home`.
`CSR_Checker_Extensions`, `CSR_GM_Ext`, `Proof_Checker`, and `Code` all build
successfully under Isabelle 2025-2. The verified Haskell export and `ceta`
binary rebuild also succeed.

The gain remains conditional. It does not apply to non-overlay or ill-formed TRSs,
and it adds no power if an "innermost" child simply rechecks the unrestricted
CSDP problem. Implement mode-sensitive chain construction and graph
approximation, make overlay/well-formedness checks cheap, and benchmark the
eligible CSR subset with and without the branch. Record residual pair counts,
SCC/edge counts, YES deltas, and runtime; run the branch early when applicable
or in parallel with the full CSR path.

## Was Native CSR Work Necessary?

Yes, for useful independently certified YES proofs.

CeTA 3.9 translates a context-sensitive replacement map into forbidden
patterns and proves the relation equivalence. That supplies a semantic carrier
and permits generic assumptions and nontermination machinery. However,
`fptrs_termination_proof` had only `Assume_FP_SN`; there was no standalone
forbidden-pattern rule-removal or DP proof language capable of deriving a CSR
YES result without already assuming the desired termination fact.

The native work contributes the missing proof-producing methods: CSR-monotone
interpretations, CS-DP transformations, minimal chains, CSR graph and usable
rules, active SCT, and transformations to ordinary proof obligations.

For NO, the old forbidden-pattern loop machinery was already substantially
useful because CSR steps are representable as forbidden-pattern steps. The new
CSR loop route mainly gives direct CSR syntax, source-signature alignment, and
clean integration with the new top-level CSR proof branch.

### Other Provers and Competition Certification

AProVE and MuTerm are established powerful CSR provers. That is separate from
competition certification. An audit of the published TermCOMP result archive
found no certified CSR category and no certified CSR result:

- 2004--2006 predate the introduction of TermCOMP certified categories in
  2007;
- the 2008--2013 archive has `TRS_Contextsensitive` result pages, while its
  certified pages are separately named and none is CSR;
- the 2014--2024 CSR summaries report zero certification time and zero
  `CERTIFIED YES`/`CERTIFIED NO` for every participant;
- the 2025 CSR run contains only `AProVE25_uncert` and
  `MU-TERM 2025_uncert`, again with zero certified answers;
- the 2026 result data currently in the TermCOMP results repository contains
  only `AProVE26_uncert` and `MU-TERM 2025_uncert`, with zero certified answers.

The 2014 registration page does list CeTA as a *verification participant* for
CSR, but the solver category is explicitly uncertified and the published result
summary contains no certified answers. Verifier registration is not evidence
of a certified competition result.

Thus, within the official TermCOMP record, CeTA-CSR provides CSR certification
that no previous competition entry demonstrated. This does not claim that no
research prototype or proof-assistant development outside TermCOMP has ever
certified a CSR theorem.

## Forbidden Patterns and Outermost Development

Forbidden-pattern plumbing remains useful for outermost rewriting:

- CeTA already translates outermost rewriting to forbidden patterns and has a
  proved equivalence between `ostep` and the resulting `fpstep` relation.
- Generic forbidden-pattern loop checking can be reused for outermost NO
  certificates.
- The `fpstep` semantics is a useful common endpoint for proving the soundness
  of outermost transformations.

It is not a substitute for an outermost termination processor. As with CSR,
the old positive forbidden-pattern proof datatype provides assumptions rather
than a proof-producing framework. The current outermost development still
needs its RZ transformation and/or an outermost DP framework. Forbidden
patterns should be reused for semantic bridges and NO proofs, while specialized
outermost processors provide YES power.

## Cleanup Order

1. Introduce the unified top-level CSR datatype and checker.
2. Keep all old CSR XML tags as parser aliases; switch Ferrum emission to the
   canonical nested syntax.
3. Remove the redundant orthogonality wrapper until an innermost CSR proof
   checker is connected.
4. Remove `Rfc_Relative_Bounds` as an internal proof constructor while retaining
   its parser alias.
5. Replace the RFC constructor family with one closure-certificate sum and one
   recursive relative processor.
6. Normalize native/optimized RFC witnesses into common semantic checker
   predicates.
7. Prove whether direct automaton-closed RFC bounds are a checker-level special
   case of the relative processor before removing that constructor.

## External Reference Points

- Termination Competition CSR category and semantics:
  <https://termination-portal.org/wiki/TRS_Contextsensitive>
- Historical 2014 solver/verifier and certified-category registration:
  <https://termination-portal.org/wiki/Termination_Competition_2014_Registration>
- Published TermCOMP result archive: <https://termcomp.github.io/>
- TermCOMP 2025 CSR summary:
  <https://raw.githubusercontent.com/TermCOMP/termcomp.github.io/master/docs/Y2025/TRS_Context_Sensitive.summary.json>
- TermCOMP 2026 CSR summary:
  <https://raw.githubusercontent.com/TermCOMP/termcomp.github.io/master/docs/Y2026/TRS_Context_Sensitive.summary.json>
- Current AProVE command-line documentation for CPF output and CeTA-restricted
  strategies: <https://aprove.informatik.rwth-aachen.de/index.php/usage>
- AProVE improved CS-DP implementation and evaluation:
  <https://aprove.informatik.rwth-aachen.de/eval/CS-DPs/>
