let trs_no = nontermination(
    variable-condition;
    loop;
    timeout(5s, narrowing);
    timeout(5s, rewriting);
    dp-loop;
    timeout(5s, dp-rewriting);
    timeout(5s, dp-instantiation)
  );
let trs_yes = parallel(
    timeout(275s, uncurry) |
    timeout(10s, path-order) |
    (timeout(40s, poly(max-constant=2, max-coefficient=2));
      termination)
  );
let trs_standard = timeout(300s, parallel(trs_no | trs_yes));
let trs_innermost = timeout(300s, parallel(trs_no | trs_yes));
let csr_dp = dp(
    graph;
    subterm;
    timeout(10s, size-change);
    timeout(20s, parallel(
        matrix(dimension=1, max-constant=2, max-coefficient=1) |
        matrix(dimension=2, max-constant=1, max-coefficient=1) |
        path-order |
        kbo(weight=2) |
        poly(max-constant=2, max-coefficient=2)
      ));
    timeout(20s, parallel(
        rewrite(per-pair=2) |
        instantiate(per-pair=2) |
        forward-instantiate(per-pair=2)
      ));
    timeout(10s, size-change);
    graph;
    subterm
  );
let csr_standard = timeout(300s, csr(parallel(
    timeout(120s, csr_dp) |
    (timeout(15s, poly(max-constant=2, max-coefficient=2));
      timeout(120s, csr_dp)) |
    (timeout(2s, csr-innermost);
      timeout(120s, csr_dp)) |
    (timeout(15s, poly(max-constant=2, max-coefficient=2));
      timeout(2s, csr-innermost);
      timeout(120s, csr_dp))
  )));
let srs_no = parallel(
    nontermination |
    nontermination(variable-condition) |
    nontermination(loop) |
    nontermination(srs-loop) |
    string-reversal |
    nontermination(timeout(2500ms, rewriting)) |
    nontermination(timeout(2500ms, narrowing))
  );
let srs_yes_fast = parallel(
    srs-length |
    srs-weighted-length(max-weight=64) |
    srs-weighted-rule-removal(max-weight=64) |
    timeout(10s, rfc-match-bounds()) |
    timeout(10s, string-reversal) |
    timeout(10s, relative-match-bounds()) |
    timeout(10s, string-reversal) |
    timeout(10s, poly(max-constant=2, max-coefficient=2)) |
    timeout(10s, kbo(weight=2))
  );
let srs_yes_fallback = parallel(
    timeout(275s, parallel(dp | kbo(weight=2) | poly(max-constant=2,max-coefficient=1) | path-order | switch-innermost)) |
    timeout(275s, string-reversal)
  );
let srs_yes = (srs_yes_fast; srs_yes_fallback);
let srs_standard = timeout(300s, parallel(srs_no | srs_yes));
let transformed_csr_standard = timeout(300s, parallel(trs_no | trs_yes | srs_no | srs_yes_fast));
if(csr, csr_standard, if(transformed-csr, transformed_csr_standard, if(srs, srs_standard, if(innermost, trs_innermost, trs_standard))))
