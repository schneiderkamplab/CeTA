let trs_no =
  timeout(100ms, nontermination(dp-loop)) |
  timeout(100ms, nontermination(loop)) |
  nontermination;
let trs_aaecc_qdp_to_srs = timeout(20s,
  aaecc-innermost;
  dp(pipeline(
    usable-rules;
    innermost-lhss;
    qdp-to-srs
  ))
);
let trs_modular_rule_removal_qdp_to_srs = timeout(20s,
  dp(pipeline(
    mono-poly(max-constant=2, max-coefficient=2);
    switch-innermost;
    qdp-to-srs
  ))
);
let trs_qdp_to_srs_frontier = parallel(
  trs_aaecc_qdp_to_srs |
  trs_modular_rule_removal_qdp_to_srs
);
let trs_termination_atoms = parallel(
  remove-non-applicable-rules |
  dp |
  kbo(weight=2) |
  poly(max-constant=2, max-coefficient=1) |
  path-order |
  switch-innermost
);
let trs_yes_fallback = parallel(
    timeout(2s, path-order) |
    timeout(8s, poly(max-constant=2, max-coefficient=2)) |
    trs_termination_atoms
  );
let trs_initial_orders = timeout(40s, dp);
let trs_forward_labeling = timeout(55s, dp);
let trs_poly_labeling = timeout(60s, dp);
let trs_transform_race = if(
  applicative,
  parallel(
    timeout(55s, uncurry) |
    trs_poly_labeling |
    delay(5s, trs_initial_orders) |
    delay(5s, timeout(50s, switch-innermost))
  ),
  parallel(
    trs_initial_orders |
    trs_poly_labeling |
    timeout(55s, uncurry) |
    timeout(55s, switch-innermost)
  )
);
let trs_cheap_orders = parallel(
  timeout(2s, dp) |
  timeout(3s, path-order) |
  timeout(3s, dp)
);
let trs_usable_order_ladder = timeout(10s, dp);
let trs_transformed_direct_poly = timeout(6s,
  poly(max-constant=2, max-coefficient=2)
);
let trs_monotonic_path_sct = timeout(35s, dp);
let trs_path_monotonic_sct = timeout(35s, dp);
let trs_monotonic_rational = timeout(45s, dp);
let trs_rational64 = timeout(8s, dp);
let trs_monotonic_matrices = timeout(8s, dp);
let trs_weak_polynomial = timeout(20s, dp);
let trs_max_polynomial_small = if(
  rules-at-most(15),
  timeout(3s,
    dp(pipeline(
      graph;
      max-poly(
        max-constant=1,
        max-coefficient=1,
        alternatives=2,
        symbols=10,
        arity=3
      );
      size-change
    ))
  ),
  fail
);
let trs_max_polynomial = timeout(2s,
  dp(pipeline(
    graph;
    max-poly(
      max-constant=1,
      max-coefficient=1,
      alternatives=2,
      symbols=32,
      arity=4
    );
    graph;
    size-change
  ))
);
let trs_integer_matrix = timeout(10s, parallel(
  dp |
  dp
));
let trs_jfp_pipeline = timeout(35s, dp);
let trs_split_labeling_pipeline = timeout(25s, dp);
let trs_arctic3_broad = timeout(8s, dp);
let trs_integer_arctic = timeout(5s, dp);
let trs_scalar_arctic_poly = timeout(20s, dp);
let trs_root_labeling = if(
  rules-at-most(5),
  timeout(20s,
    dp(pipeline(
      arctic-matrix(dimension=1, max-constant=2, max-coefficient=2);
      root-labeling;
      graph;
      poly(max-constant=3, max-coefficient=3);
      semantic-labeling;
      graph
    ))
  ),
  fail
);
let trs_broad_linear = timeout(30s, dp);
let trs_large_linear = timeout(20s, dp);
let trs_polynomial_rule_removal = timeout(8s,
  poly(max-constant=2, max-coefficient=2)
);
let trs_rule_removal_switch_innermost = timeout(15s,
  poly(max-constant=2, max-coefficient=2);
  switch-innermost
);
let trs_instantiation_chain = timeout(5s, dp);
let trs_dp_switch_innermost = timeout(15s, dp);
let trs_early_orders = parallel(
  trs_usable_order_ladder |
  trs_weak_polynomial |
  trs_max_polynomial_small |
  trs_max_polynomial |
  trs_integer_matrix |
  trs_jfp_pipeline |
  trs_split_labeling_pipeline |
  trs_arctic3_broad |
  trs_integer_arctic |
  trs_scalar_arctic_poly |
  trs_root_labeling |
  trs_broad_linear |
  trs_monotonic_matrices |
  trs_monotonic_rational |
  trs_polynomial_rule_removal |
  trs_rule_removal_switch_innermost |
  trs_instantiation_chain |
  trs_dp_switch_innermost
);
let trs_yes =
  trs_cheap_orders |
  trs_rational64 |
  trs_max_polynomial_small |
  trs_early_orders |
  trs_transform_race |
  trs_forward_labeling |
  trs_yes_fallback;
let trs_small_pipeline = if(
  rules-at-most(15),
  timeout(25s, trs_jfp_pipeline),
  fail
);
let trs_standard_yes = if(
  applicative,
  timeout(35s, uncurry) | trs_small_pipeline | trs_yes,
  trs_small_pipeline | trs_yes
);
let trs_standard_core = parallel(trs_no | trs_standard_yes);
let trs_small_standard_core = parallel(
  trs_max_polynomial_small |
  delay(3s, trs_standard_core)
);
let trs_standard = timeout(300s, if(
  rules-at-most(15),
  parallel(
    trs_qdp_to_srs_frontier |
    trs_root_labeling |
    delay(500ms, trs_small_standard_core)
  ),
  parallel(trs_qdp_to_srs_frontier | if(
    rules-at-least(30),
    trs_large_linear | trs_standard_core,
    trs_standard_core
  ))
));
let trs_innermost_transform = timeout(90s, dp);
let trs_innermost_early = if(
  applicative,
  timeout(25s, uncurry) | trs_innermost_transform,
  trs_innermost_transform
);
let trs_bounded_narrowing_core = dp;
let trs_bounded_narrowing = timeout(50s, trs_bounded_narrowing_core);
let trs_transformed_poly = timeout(75s, dp);
let trs_transformed_arctic = timeout(15s, dp);
let trs_transformed_rule_removal = timeout(35s,
  poly(max-constant=2, max-coefficient=2);
  poly(max-constant=2, max-coefficient=2);
  poly(max-constant=2, max-coefficient=2);
  poly(max-constant=2, max-coefficient=2);
  dp
);
let trs_transformed_cheap = parallel(
  trs_transformed_poly |
  trs_transformed_arctic
);
let trs_transformed_initial = parallel(
  trs_transformed_rule_removal |
  trs_transformed_cheap
);
let trs_innermost_yes =
  timeout(2s, dp) |
  timeout(5s, smt-poly(max-constant=2, max-coefficient=2)) |
  timeout(15s, string-reversal) |
  timeout(20s, dp) |
  trs_bounded_narrowing |
  trs_innermost_early |
  timeout(5s, dp) |
  timeout(10s, dp) |
  trs_yes;
let trs_innermost_focused_dp_core =
  dp(pipeline(
    graph;
    parallel(
      size-change |
      subterm |
      poly(max-constant=2, max-coefficient=2) |
      weak-poly(min-constant=-2, max-constant=2, max-coefficient=2) |
      matrix(dimension=2, max-constant=2, max-coefficient=1)
    );
    graph;
    parallel(
      size-change |
      subterm |
      poly(max-constant=2, max-coefficient=2) |
      matrix(dimension=2, max-constant=2, max-coefficient=1)
    )
  ));
let trs_innermost_focused_dp =
  timeout(5s, trs_innermost_focused_dp_core) |
  timeout(20s, trs_innermost_focused_dp_core);
let trs_innermost_focused_dp_after_poly = timeout(2s,
  trs_innermost_focused_dp_core
);
let trs_innermost_q_matrix_rule_removal = timeout(5s,
  dp(pipeline(
    graph;
    parallel(
      size-change |
      pipeline(
        usable-rules;
        innermost-lhss;
        matrix(dimension=1, max-constant=2, max-coefficient=2, max-symbols=12, max-arity=4);
        matrix(dimension=1, max-constant=2, max-coefficient=2, max-symbols=12, max-arity=4);
        usable-rules;
        poly(max-constant=2, max-coefficient=2)
      )
    )
  ))
);
let trs_innermost_poly_ladder = timeout(20s,
  poly(max-constant=2, max-coefficient=2);
  poly(max-constant=2, max-coefficient=2);
  poly(max-constant=2, max-coefficient=2);
  poly(max-constant=2, max-coefficient=2);
  poly(max-constant=2, max-coefficient=2);
  poly(max-constant=2, max-coefficient=2);
  poly(max-constant=2, max-coefficient=2);
  poly(max-constant=2, max-coefficient=2);
  poly(max-constant=2, max-coefficient=2);
  poly(max-constant=2, max-coefficient=2);
  poly(max-constant=2, max-coefficient=2);
  poly(max-constant=2, max-coefficient=2)
);
let trs_innermost_learned =
  trs_innermost_q_matrix_rule_removal |
  trs_innermost_focused_dp |
  trs_innermost_poly_ladder;
let trs_innermost = timeout(300s,
  timeout(250ms, nontermination(direct-loop)) |
  trs_innermost_learned |
  delay(100ms, parallel(trs_no | trs_innermost_yes))
);
let csr_dp_full = parallel(
  csr-improved-dp |
  csr-safe-dp |
  csr-native-dp |
  csr-native-ordinary-dp |
  csr-conservative-dp
);
let csr_dp_innermost = parallel(
  csr-safe-dp |
  csr-improved-dp |
  csr-native-dp |
  csr-native-ordinary-dp |
  csr-conservative-dp
);
let csr_dp = if(innermost, csr_dp_innermost, csr_dp_full);
let csr_rational_dp = timeout(45s, csr_dp);
let csr_rule_removal = timeout(45s, (
    poly(max-constant=2, max-coefficient=2) |
    matrix(dimension=2, max-constant=2, max-coefficient=2)
  ));
let csr_instantiation_chain = timeout(16s, (
  poly(max-constant=2, max-coefficient=2);
  csr-improved-dp(pipeline(
    forward-instantiation;
    usable-rules;
    instantiate(per-pair=2);
    graph
  ))
));
let csr_guarded_components = if(
  rules-at-least(18),
  timeout(5s, (
    poly(max-constant=2, max-coefficient=2, candidate=0);
    csr-improved-dp(pipeline(
      graph;
      parallel(
        graph |
        pipeline(
          (matrix(dimension=2, max-constant=2, max-coefficient=2,
             candidate=0, max-symbols=64, max-arity=4) |
           matrix(dimension=2, max-constant=2, max-coefficient=2,
             candidate=1, max-symbols=64, max-arity=4));
          graph;
          parallel(
            pipeline(subterm; graph) |
            pipeline(usable-rules;
              matrix(dimension=2, max-constant=2, max-coefficient=2,
                candidate=0, max-symbols=64, max-arity=4))
          )
        )
      )
    ))
  )),
  fail
);
let csr_small = if(
  rules-at-most(4),
  parallel(
    timeout(1s, csr-loop) |
    timeout(5s, (
      poly(max-constant=3, max-coefficient=3);
      poly-min-delete(max-constant=3, max-coefficient=3,
        min-delete=3, residual-budget=1)
    ))
  ),
  fail
);
let csr_certified_fast = parallel(
  timeout(2s, csr-loop) |
  timeout(8s, csr-improved-dp(pipeline(
    graph;
    size-change
  )))
);
let csr_direct_dp_fast = parallel(
  timeout(3s, csr-native-dp(pipeline(graph; size-change)))
);
let csr_rule_removal_step = (
  poly(max-constant=2, max-coefficient=2) |
  matrix(dimension=2, max-constant=2, max-coefficient=2)
);
let csr_rule_removal_ladder = if(
  rules-at-most(64),
  timeout(10s,
    csr_rule_removal_step;
    csr_rule_removal_step;
    csr_rule_removal_step;
    csr_rule_removal_step;
    csr_rule_removal_step;
    csr_rule_removal_step;
    csr_rule_removal_step;
    csr_rule_removal_step;
    csr_rule_removal_step
  ),
  timeout(20s,
    csr_rule_removal_step;
    csr_rule_removal_step;
    csr_rule_removal_step;
    csr_rule_removal_step;
    csr_rule_removal_step;
    csr_rule_removal_step;
    csr_rule_removal_step;
    csr_rule_removal_step;
    csr_rule_removal_step
  )
);
let csr_rule_removal_safe_dp = timeout(12s,
  poly(max-constant=2, max-coefficient=2);
  poly(max-constant=2, max-coefficient=2);
  csr-safe-dp(pipeline(graph; size-change))
);
let csr_improved_mixed_components = timeout(20s,
  csr-improved-dp(pipeline(
    graph;
    parallel(
      size-change |
      subterm |
      poly(max-constant=2, max-coefficient=2) |
      matrix(dimension=2, max-constant=2, max-coefficient=2)
    );
    graph;
    size-change
  ))
);
let csr_safe_mixed_components = if(
  rules-at-least(10),
  timeout(20s,
    csr-safe-dp(pipeline(
      graph;
      parallel(
        size-change |
        subterm |
        poly(max-constant=2, max-coefficient=2) |
        matrix(dimension=2, max-constant=2, max-coefficient=2)
      );
      graph;
      size-change
    ))
  ),
  fail
);
let csr_small_instantiation = if(
  rules-at-most(4),
  timeout(12s,
    csr-improved-dp(pipeline(
      graph;
      usable-rules;
      instantiate(per-pair=2);
      graph;
      size-change
    ))
  ),
  fail
);
let csr_learned_front = parallel(
    csr_certified_fast |
    csr_direct_dp_fast |
    csr_rule_removal_ladder |
    csr_rule_removal_safe_dp |
    csr_improved_mixed_components |
    csr_safe_mixed_components |
    csr_small_instantiation |
    csr_small |
    csr_guarded_components |
    csr_instantiation_chain
);
let csr_broad_fallback = parallel(
    timeout(5s, csr-loop) |
    timeout(15s, dp) |
    (csr_rule_removal;
      timeout(120s, csr_dp)) |
    timeout(120s, csr_dp) |
    csr_rational_dp |
    (timeout(15s, poly(max-constant=2, max-coefficient=2));
      timeout(120s, csr_dp)) |
    (timeout(15s, matrix(dimension=2, max-constant=1, max-coefficient=1));
      timeout(120s, csr_dp)) |
    (timeout(15s, poly(max-constant=2, max-coefficient=2));
      timeout(15s, matrix(dimension=2, max-constant=1, max-coefficient=1));
      timeout(120s, csr_dp)) |
    (timeout(15s, matrix(dimension=2, max-constant=1, max-coefficient=1));
      timeout(15s, poly(max-constant=2, max-coefficient=2));
      timeout(15s, poly(max-constant=2, max-coefficient=2));
      timeout(120s, csr_dp))
);
let csr_standard = timeout(300s,
  csr_learned_front |
  csr_broad_fallback
);
let srs_no = parallel(
    timeout(50ms, nontermination(direct-loop)) |
    timeout(2s, nontermination(srs-loop-deep)) |
    nontermination |
    nontermination |
    nontermination |
    nontermination |
    nontermination |
    string-reversal |
    nontermination |
    nontermination
  );
let srs_yes_preprocess = parallel(
    srs-length |
    srs-weighted-length(max-weight=64) |
    srs-weighted-rule-removal(max-weight=64) |
    string-reversal |
    timeout(1s, poly(max-constant=1, max-coefficient=1)) |
    timeout(1s, string-reversal) |
    timeout(1s, kbo(weight=2)) |
    timeout(1s, string-reversal) |
    timeout(1s, path-order) |
    timeout(1s, string-reversal)
  );
let srs_max_polynomial_small = timeout(3s, dp(pipeline(
      graph;
      max-poly(
        max-constant=1,
        max-coefficient=1,
        alternatives=2,
        symbols=10,
        arity=3
      );
      size-change
    )));
let srs_yes_fast = parallel(
    srs_max_polynomial_small |
    timeout(5s, relative-flat-context-closure) |
    timeout(15s, relative-semantic-labeling) |
    timeout(8s, matrix(dimension=2,max-constant=1,max-coefficient=1)) |
    timeout(8s, integer-matrix(dimension=2,min-value=0,max-value=1)) |
    timeout(15s, matrix(dimension=3,max-constant=1,max-coefficient=1)) |
    timeout(15s, integer-matrix(dimension=3,min-value=0,max-value=1)) |
    timeout(10s, uncurry) |
    timeout(30s, match-bounds(max-bound=5,max-states=2000,max-transitions=50000)) |
    timeout(30s, string-reversal) |
    timeout(20s, rfc-match-bounds(max-bound=3,max-words=10000,max-word-len=128,max-states=2000,max-transitions=50000)) |
    timeout(20s, string-reversal) |
    timeout(20s, rfc-relative-match-bounds(max-bound=2,max-words=10000,max-word-len=128,max-states=2000,max-transitions=50000,at-bound=merge)) |
    timeout(20s, string-reversal) |
    timeout(2s, relative-match-bounds(max-bound=5,max-states=2000,max-transitions=20000)) |
    timeout(2s, string-reversal) |
    timeout(2s, poly(max-constant=2, max-coefficient=2)) |
    timeout(2s, kbo(weight=2)) |
    timeout(2s, string-reversal)
  );
let srs_yes_fallback = parallel(
    timeout(55s, parallel(
      remove-non-applicable-rules |
      match-bounds |
      srs-length |
      srs-weighted-length(max-weight=64) |
      srs-weighted-rule-removal(max-weight=64) |
      dp |
      kbo(weight=2) |
      poly(max-constant=2, max-coefficient=1) |
      path-order |
      switch-innermost
    )) |
    timeout(55s, string-reversal)
  );
let srs_yes_core = parallel(srs_yes_fast | delay(35s, srs_yes_fallback));
let srs_yes =
  parallel(
    srs_max_polynomial_small |
    delay(3s,
    (srs_yes_preprocess; srs_yes_core) |
    srs_yes_core
    )
  );
let srs_standard = timeout(300s, parallel(srs_no | srs_yes));
let relative_yes = parallel(
  timeout(3s, relative-match-bounds(max-bound=12,max-states=50000,max-transitions=1000000)) |
  timeout(30s, relative-adp) |
  timeout(15s, relative-semantic-labeling) |
  timeout(5s, relative-flat-context-closure) |
  timeout(15s, poly(max-constant=2, max-coefficient=2)) |
  timeout(15s, matrix(dimension=2,max-constant=1,max-coefficient=1)) |
  timeout(10s, kbo(weight=2)) |
  timeout(10s, path-order) |
  if(srs, srs_yes, fail)
);
let relative_standard = timeout(300s, parallel(nontermination | relative_yes));
let transformed_csr_core = parallel(
  trs_no |
  (
    trs_transformed_direct_poly |
    trs_small_pipeline |
    parallel(trs_monotonic_path_sct | trs_path_monotonic_sct) |
    trs_usable_order_ladder |
    trs_transformed_initial |
    timeout(120s, trs_bounded_narrowing_core) |
    parallel(trs_yes | srs_no | srs_yes_fast)
  )
);
let transformed_csr_innermost_inverse = timeout(250ms, gm04-inverse-csr);
let transformed_csr_full_inverse = parallel(
  timeout(60s, gm04-inverse-csr-full) |
  timeout(60s, gm04-inverse-csr)
);
let transformed_csr_innermost_learned = if(
  rules-at-most(21),
  transformed_csr_innermost_inverse |
  trs_innermost_focused_dp_after_poly,
  if(
    rules-at-least(60),
    transformed_csr_innermost_inverse |
    trs_innermost_focused_dp |
    trs_innermost_poly_ladder,
    transformed_csr_innermost_inverse
  )
);
let transformed_csr_standard = timeout(300s,
  if(
    innermost,
    transformed_csr_innermost_learned | transformed_csr_core,
    if(srs,
      timeout(2s, nontermination(srs-loop-deep)) | transformed_csr_full_inverse | transformed_csr_core,
      transformed_csr_full_inverse | transformed_csr_core
    )
  )
);
if(relative, relative_standard, if(csr, csr_standard, if(transformed-csr, transformed_csr_standard, if(innermost, trs_innermost, if(srs, srs_standard, trs_standard)))))
