# Ferrum

Ferrum is a Rust-based, LLM-first termination prover for first-order term rewriting systems.

The design principle is:

1. expose structured proof states to an LLM or agent;
2. let the LLM propose ranking functions, orderings, argument filters, processors, and strategies;
3. check every proposal inside Ferrum or an external certified checker;
4. emit proof objects on a path toward CPF/CeTA certification.

## Current Slice

- Parses legacy TPDB `.trs` files.
- Parses first-order `(format TRS)` files from `TPDB-ARI`.
- Downloads the current `TPDB-ARI` repository.
- Discovers local TPDB benchmark trees.
- Exports LLM proof-state JSON.
- Accepts LLM proposal JSON.
- Checks LLM-proposed symbol-weight linear interpretations.
- Checks LLM-proposed linear polynomial interpretations.
- Extracts dependency pairs.
- Emits CPF 2.1-style certificates for the currently supported KBO/rule-removal subset.

CeTA round-trip verification is still a separate milestone. Ferrum refuses CPF export for proof steps whose CPF encoding is not implemented yet, such as the current checked linear-polynomial proposal path.

## Commands

```sh
cargo run -- tpdb clone-ari ../TPDB-ARI
cargo run -- tpdb discover ../TPDB-ARI
cargo run -- tpdb check-parse ../TPDB-ARI --limit 200

cargo run -- parse examples/subterm.trs
cargo run -- dp examples/loop.ari

cargo run -- llm state examples/subterm.trs
cargo run -- llm prompt examples/subterm.trs
cargo run -- prove examples/subterm.trs \
  --llm-proposals examples/subterm-proposal.json \
  --cpf /tmp/ferrum.cpf.xml

cargo run -- cert check /tmp/ferrum.cpf.xml

cargo run -- prove examples/linear.trs \
  --llm-proposals examples/linear-proposal.json
```

## LLM Proposal Format

```json
{
  "candidates": [
    {
      "kind": "symbol_weights",
      "weights": {
        "f": 1
      }
    }
  ]
}
```

```json
{
  "candidates": [
    {
      "kind": "linear_polynomial",
      "interpretations": {
        "f": {
          "constant": 1,
          "coefficients": [1]
        },
        "g": {
          "constant": 0,
          "coefficients": [1]
        }
      }
    }
  ]
}
```

Future proposal kinds should follow the same pattern: the LLM proposes, Ferrum validates.

## CPF Status

CeTA 3.9 is expected at `.tools/ceta` by default. Since CeTA 3.x consumes CPF 3.x, Ferrum's `cert check` command converts Ferrum's CPF 2.1-style output via the official CPF 2-to-3 converter expected at `.tools/cpf3/cpf3/xml/cpf2_to_3.sh`, validates the result with `xmllint` when available, and then invokes CeTA.

Installed local tool layout:

```text
.tools/ceta
.tools/cpf3/cpf3/xml/cpf2_to_3.sh
.tools/cpf3/cpf3/xml/cpf3.xsd
```

Currently supported CPF export and CeTA checking:

- `LlmSymbolWeights` proofs are exported as CPF 2.1 `trsTerminationProof` certificates using `ruleRemoval` with a `knuthBendixOrder` reduction pair, followed by `rIsEmpty`.
- Empty systems are exported directly as `rIsEmpty`.

Not yet exported to CPF:

- Linear polynomial interpretations.
- Dependency-pair proofs.
- Subterm-order proofs.
- Multi-step proofs.

## Near-Term Roadmap

- CeTA round-trip checking.
- CPF encoding for linear polynomial interpretations.
- Argument filtering proposals.
- Polynomial interpretations with arbitrary coefficients.
- Matrix interpretations.
- LPO/KBO proposal checking.
- Dependency-pair graph approximation and SCC processing.
- SMT-backed validation after LLM candidate generation.
- Agent strategy API for processor selection and repair loops.
