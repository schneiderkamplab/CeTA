import unittest
import json
import subprocess
import sys
import tempfile
from pathlib import Path
from slice_parameter_oracle import alias_closure, assert_parameter_only, state_keys, cpf_keys


class SliceTests(unittest.TestCase):
    def test_aliases_both_directions_and_cycles(self):
        self.assertEqual(alias_closure({'b'}, [('a', 'b'), ('b', 'c'), ('c', 'a'),
                                             ('x', 'y')]), {'a', 'b', 'c'})

    def test_nested_state_keys(self):
        value = {'input': {'problem_key': 'root'},
                 'witness': {'residuals': [{'problem_key': 'child'}]},
                 'diagnostic': '<problem_key>not-a-key</problem_key>'}
        self.assertEqual(set(state_keys(value)), {'root', 'child'})

    def test_runtime_structural_keys(self):
        self.assertTrue(cpf_keys("<a>\n <b />\n</a>") & cpf_keys('<a><b/></a>'))
        self.assertTrue(cpf_keys('<name>&apos;</name>') & cpf_keys("<name>'</name>"))

    def test_refuse_witnesses(self):
        for row in [{'schema': 'ferrum.utility-guidance.witness.v1'},
                    {'prefer': [{'candidate_ref': 'id'}]},
                    {'prefer': [{'candidate': 'timeout(1s, exact-matrix(hex=00))'}]}]:
            with self.assertRaises(ValueError):
                assert_parameter_only(row)

    def test_native_parameters(self):
        assert_parameter_only({'prefer': [{'candidate': 'wpo-max(max-constant=4)'}]})

    def test_slice_preserves_records_and_trace_only_keys(self):
        with tempfile.TemporaryDirectory() as directory:
            base = Path(directory)
            (base / 'processor-events.jsonl').write_text(json.dumps(
                {'input': {'problem_key': 'root'}}) + '\n')
            details = base / 'details.json'
            details.write_text(json.dumps([{'certified': True, 'status': 'yes',
                                            'artifact_dir': str(base)}]))
            trace = base / 'trace'
            trace.mkdir()
            hidden = 'a' * 64
            (trace / '1.jsonl').write_text(json.dumps([hidden, 'b' * 64]) + '\n')
            rows = [{'problem_key': 'root', 'canonical_problem_key': 'target'},
                    {'problem_key': 'target', 'replay_order': ['digest'],
                     'current_checker_invalidation': True, 'avoid': [
                         {'candidate': 'size-change', 'status': 'failed'}]},
                    {'problem_key': hidden, 'prefer': [{'candidate': 'graph'}]},
                    {'problem_key': 'unused'}]
            oracle = base / 'oracle.jsonl'
            oracle.write_text(''.join(json.dumps(row) + '\n' for row in rows))
            output = base / 'slice.jsonl'
            command = [sys.executable, str(Path(__file__).with_name('slice_parameter_oracle.py')),
                       '--oracle', str(oracle), '--details', str(details),
                       '--output', str(output), '--lookup-trace-dir', str(trace)]
            subprocess.run(command, check=True, capture_output=True)
            self.assertEqual([json.loads(line) for line in output.read_text().splitlines()],
                             rows[:3])
            self.assertNotEqual(subprocess.run(command, capture_output=True).returncode, 0)


if __name__ == '__main__':
    unittest.main()
