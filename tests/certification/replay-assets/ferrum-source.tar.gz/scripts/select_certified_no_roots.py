#!/usr/bin/env python3
"""Write a deterministic source selection for modular NO evidence extraction."""
import argparse
import json
from pathlib import Path

p = argparse.ArgumentParser(description=__doc__)
p.add_argument('--baseline', type=Path, required=True)
p.add_argument('--output', type=Path, required=True)
a = p.parse_args()
paths = set()
for category in ('standard', 'innermost', 'csr'):
    for row in json.loads((a.baseline/category/'details.json').read_text()):
        if row['certified'] and row['status'] == 'no':
            paths.add(row['path'])
with a.output.open('x') as stream:
    stream.write('\n'.join(sorted(paths)) + '\n')
print(len(paths))
