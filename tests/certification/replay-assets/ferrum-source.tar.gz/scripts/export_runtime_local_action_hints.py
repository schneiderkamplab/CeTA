#!/usr/bin/env python3
"""Recover state-local scheduling hints from certified runtime traces.

Source certificates are checked twice. Recorded intermediate actions receive
ZERO independent certification credit: a successful root may include explored
branches which were not used in its proof. Fresh reconstructed root certification
is mandatory before claiming recovery. No composite proof/pipeline is imported.
"""
import argparse
from collections import defaultdict
import hashlib
import json
from pathlib import Path
import subprocess


def build(events):
    states, witnesses = defaultdict(dict), {}
    for event in events:
        if event.get('outcome') not in ('solved', 'transformed'):
            continue
        atom = event.get('strategy_atom', '')
        key = (event.get('input') or {}).get('problem_key')
        if not key or not atom or atom == 'empty':
            continue
        if any(s in atom for s in ('exact-trs-proof(', 'exact-dp-proof(',
                                  'exact-trs-nontermination-proof(',
                                  'exact-dp-nontermination-proof(', 'pipeline(')):
            raise ValueError('Composite action in atomic runtime trace')
        identity = hashlib.sha256(atom.encode()).hexdigest()
        if atom.startswith('exact-'):
            witnesses[identity] = atom
            candidate = dict(candidate_ref=identity)
        else:
            candidate = dict(candidate=atom)
        states[key][identity] = dict(candidate, status='transformed_weak',
            utility_score=2000, attempts=1, certified_count=0, solved_count=0,
            transformed_count=1, failed_count=0, timeout_count=0,
            best_elapsed_ms=event.get('elapsed_ms', 0))
    return ([dict(schema='ferrum.utility-guidance.witness.v1', witness_id=key, candidate=atom)
             for key, atom in sorted(witnesses.items())] +
            [dict(schema='ferrum.utility-guidance.v2', problem_key=key,
                  replay_order=list(actions), prefer=[], possible=list(actions.values()),
                  avoid=[], timeout=[]) for key, actions in sorted(states.items())])


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--details', type=Path, required=True)
    p.add_argument('--root', action='append', default=[])
    p.add_argument('--ceta', type=Path, required=True)
    p.add_argument('--output', type=Path, required=True)
    args = p.parse_args()
    args.output.mkdir(parents=True, exist_ok=False)
    events, gates = [], []
    for row in json.loads(args.details.read_text()):
        if not row['certified'] or (args.root and not any(row['path'].endswith(s) for s in args.root)):
            continue
        directory = Path(row['artifact_dir'])
        proof = directory / 'proof.cpf.xml'
        digest = hashlib.sha256(proof.read_bytes()).hexdigest()
        if digest != row['proof_sha256']:
            raise ValueError(f'Stale baseline certificate: {proof}')
        checks = []
        for repeat in range(2):
            check = subprocess.run([str(args.ceta), str(proof)], capture_output=True, text=True, timeout=60)
            (args.output / f'check-{len(gates)}-{repeat}.log').write_text(check.stdout + check.stderr)
            checks.append(check.returncode == 0 and 'CERTIFIED' in check.stdout.splitlines())
        if checks != [True, True] or hashlib.sha256(proof.read_bytes()).hexdigest() != digest:
            raise ValueError(f'Source certification failed: {proof}')
        trace = directory / 'processor-events.jsonl'
        data = trace.read_bytes()
        events.extend(map(json.loads, data.splitlines()))
        gates.append(dict(path=row['path'], proof=str(proof), proof_sha256=digest,
                          events=str(trace), events_sha256=hashlib.sha256(data).hexdigest(),
                          independent_rechecks=checks))
    if not gates:
        raise ValueError('No matching certified sources')
    rows = build(events)
    (args.output / 'sources.json').write_text(json.dumps(gates, indent=2))
    with (args.output / 'oracle.jsonl').open('x') as out:
        for row in rows:
            print(json.dumps(row), file=out)
    print(json.dumps(dict(sources=len(gates), records=len(rows), independent_positive_promotions=0)))


if __name__ == '__main__':
    main()
