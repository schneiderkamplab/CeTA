"""Export unambiguous closed runtime action trees from twice-checked native proofs.

Reject ambiguous/search-alternative logs instead of crediting all successful
portfolio trials. Every positive event must belong to the root's closed tree.
This is guidance evidence only; future reconstructed proofs still need CeTA.
"""
import argparse
import hashlib
import json
from pathlib import Path
import subprocess
import sys


def closed_tree(events, root_key):
    positive = {}
    for event in events:
        if event.get("outcome") not in {"solved", "transformed"}:
            continue
        key = event["input"]["problem_key"]
        if key in positive:
            raise ValueError("ambiguous successful alternatives for one state")
        positive[key] = event
    active, seen = set(), set()

    def visit(key):
        if key in active:
            raise ValueError("cyclic runtime continuation")
        if key in seen:
            return
        if key not in positive:
            raise ValueError("open runtime continuation")
        active.add(key)
        event = positive[key]
        witness = event.get("witness") or {}
        if witness.get("kind") != "problem_states":
            raise ValueError("missing explicit residual vector")
        children = witness["residuals"]
        if event["outcome"] == "solved" and children:
            raise ValueError("terminal event has residuals")
        for child in children:
            if hashlib.sha256(child["cpf"].strip().encode()).hexdigest() != child["problem_key"]:
                raise ValueError("child digest mismatch")
            visit(child["problem_key"])
        active.remove(key)
        seen.add(key)

    visit(root_key)
    if seen != positive.keys():
        raise ValueError("unused positive alternatives outside certified tree")
    return len(seen)


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--checks", type=Path, action="append", required=True)
    p.add_argument("--output", type=Path, required=True)
    p.add_argument("--skip-unclosed", action="store_true",
                   help="report and omit ambiguous/open traces; never promote them")
    args = p.parse_args()
    if args.output.exists():
        p.error("output already exists")
    paths = []
    for checks in args.checks:
        for row in map(json.loads, checks.read_text().splitlines()):
            if not row.get("certified") or len(row.get("checks", [])) != 2:
                raise ValueError("proof not twice-certified")
            if not all(c.get("accepted") for c in row["checks"]):
                raise ValueError("proof check rejected")
            proof = Path(row["proof"])
            if hashlib.sha256(proof.read_bytes()).hexdigest() != row["sha256"]:
                raise ValueError("checked proof changed")
            events = proof.with_suffix(".events.jsonl")
            root_key = hashlib.sha256(Path(row["input"]).read_text().strip().encode()).hexdigest()
            try:
                closed_tree(list(map(json.loads, events.read_text().splitlines())), root_key)
            except ValueError as error:
                if not args.skip_unclosed:
                    raise
                print(json.dumps(dict(deferred=str(events), reason=str(error))), file=sys.stderr)
                continue
            paths.append(events)
    command = [sys.executable, "scripts/build_certified_runtime_atom_overlay.py",
               "--atom-prefix", "", "--on-conflict", "first", "--output", str(args.output)]
    for path in paths:
        command.extend(["--events", str(path)])
    subprocess.run(command, check=True)


if __name__ == "__main__":
    main()
