#!/usr/bin/env python3
"""Generate semantics-preserving CSR inputs for oracle replay robustness tests."""

from __future__ import annotations

import argparse
import json
from dataclasses import dataclass
from pathlib import Path


@dataclass(frozen=True)
class Token:
    value: str
    start: int
    end: int


@dataclass(frozen=True)
class Form:
    start: int
    end: int
    tokens: tuple[Token, ...]


def scan(source: str) -> tuple[list[Token], list[Form]]:
    tokens: list[Token] = []
    forms: list[Form] = []
    form_start: int | None = None
    form_token_start = 0
    depth = 0
    cursor = 0
    while cursor < len(source):
        char = source[cursor]
        if char == ";":
            newline = source.find("\n", cursor)
            cursor = len(source) if newline < 0 else newline + 1
            continue
        if char.isspace():
            cursor += 1
            continue
        if char == "(":
            if depth == 0:
                form_start = cursor
                form_token_start = len(tokens)
            tokens.append(Token(char, cursor, cursor + 1))
            depth += 1
            cursor += 1
            continue
        if char == ")":
            if depth == 0:
                raise ValueError(f"unmatched ')' at byte {cursor}")
            tokens.append(Token(char, cursor, cursor + 1))
            depth -= 1
            cursor += 1
            if depth == 0:
                assert form_start is not None
                forms.append(Form(form_start, cursor, tuple(tokens[form_token_start:])))
                form_start = None
            continue
        start = cursor
        while cursor < len(source):
            char = source[cursor]
            if char.isspace() or char in "();":
                break
            cursor += 1
        if cursor == start:
            raise ValueError(f"cannot tokenize byte {cursor}")
        tokens.append(Token(source[start:cursor], start, cursor))
    if depth != 0:
        raise ValueError("unterminated top-level form")
    return tokens, forms


def form_head(form: Form) -> str | None:
    if len(form.tokens) >= 2 and form.tokens[0].value == "(":
        return form.tokens[1].value
    return None


def symbol_mapping(forms: list[Form]) -> dict[str, str]:
    symbols: list[str] = []
    for form in forms:
        if form_head(form) == "fun" and len(form.tokens) >= 3:
            symbol = form.tokens[2].value
            if symbol in symbols:
                raise ValueError(f"duplicate function declaration: {symbol}")
            symbols.append(symbol)
    if not symbols:
        raise ValueError("input has no function declarations")
    generated = {f"csr_sym_{index:04d}" for index in range(1, len(symbols) + 1)}
    collisions = generated.intersection(symbols)
    if collisions:
        raise ValueError(f"generated symbol collision: {sorted(collisions)}")
    return {
        symbol: f"csr_sym_{index:04d}"
        for index, symbol in enumerate(symbols, start=1)
    }


def renamed_source(source: str, tokens: list[Token], mapping: dict[str, str]) -> str:
    pieces: list[str] = []
    cursor = 0
    for token in tokens:
        replacement = mapping.get(token.value)
        if replacement is None:
            continue
        pieces.append(source[cursor:token.start])
        pieces.append(replacement)
        cursor = token.end
    pieces.append(source[cursor:])
    return "".join(pieces)


def reordered_source(source: str, forms: list[Form]) -> tuple[str, list[int]]:
    rules = [form for form in forms if form_head(form) == "rule"]
    permutation = list(reversed(range(len(rules))))
    if len(rules) < 2:
        return source, permutation
    original = [source[form.start:form.end] for form in rules]
    pieces: list[str] = []
    cursor = 0
    for slot, form in enumerate(rules):
        pieces.append(source[cursor:form.start])
        pieces.append(original[permutation[slot]])
        cursor = form.end
    pieces.append(source[cursor:])
    return "".join(pieces), permutation


def write_variant(path: Path, source: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(source)


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("source", type=Path)
    parser.add_argument("output", type=Path)
    args = parser.parse_args()

    inputs = sorted(args.source.rglob("*.ari"))
    if not inputs:
        parser.error(f"no .ari files below {args.source}")

    manifest = []
    for path in inputs:
        relative = path.relative_to(args.source)
        source = path.read_text()
        tokens, forms = scan(source)
        mapping = symbol_mapping(forms)
        reordered, permutation = reordered_source(source, forms)
        renamed = renamed_source(source, tokens, mapping)
        renamed_path = args.output / "renamed" / args.source.name / relative
        reordered_path = args.output / "reordered" / args.source.name / relative
        write_variant(renamed_path, renamed)
        write_variant(reordered_path, reordered)
        manifest.append(
            {
                "source": str(path.resolve()),
                "relative_path": str(relative),
                "renamed": str(renamed_path.resolve()),
                "reordered": str(reordered_path.resolve()),
                "symbol_mapping": mapping,
                "rule_permutation": permutation,
            }
        )

    (args.output / "manifest.json").write_text(
        json.dumps(manifest, indent=2, sort_keys=True) + "\n"
    )
    print(f"generated {len(manifest)} renamed and {len(manifest)} reordered inputs")
    print(args.output / "manifest.json")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
