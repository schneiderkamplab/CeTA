#!/usr/bin/env python3
"""Prune exact witnesses never selected by successful strict replays.

Generic processor guidance is never changed.  An exact witness is retained if
it appears in any processor-event stream whose sibling ``result.json`` says
that CeTA certified the root.  This includes failed exact attempts on an
eventually certified chain, preserving the observed deterministic schedule.
"""

from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path

WITNESS_SCHEMA = "ferrum.utility-guidance.witness.v1"
GROUPS = ("prefer", "possible", "avoid", "timeout")


def witness_id(candidate: str) -> str:
    return hashlib.sha256(candidate.encode("utf-8")).hexdigest()


def selected_exact_candidates(run_dirs: list[Path]) -> tuple[set[str], int]:
    selected = set()
    certified_roots = 0
    for run_dir in run_dirs:
        for result_path in run_dir.rglob("result.json"):
            result = json.loads(result_path.read_text(encoding="utf-8"))
            if not result.get("certified"):
                continue
            certified_roots += 1
            events_path = result_path.with_name("processor-events.jsonl")
            if not events_path.exists():
                continue
            with events_path.open(encoding="utf-8") as events:
                for line in events:
                    event = json.loads(line)
                    candidate = event.get("processor")
                    if isinstance(candidate, str) and candidate.startswith("exact-"):
                        selected.add(candidate)
    return selected, certified_roots


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("input", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("--run-dir", type=Path, action="append", required=True)
    parser.add_argument(
        "--drop-all-exact",
        action="store_true",
        help=(
            "remove every exact-* witness; useful for measuring how many "
            "certified roots genuinely require stored witnesses"
        ),
    )
    args = parser.parse_args()

    selected, certified_roots = selected_exact_candidates(args.run_dir)
    if args.drop_all_exact:
        selected.clear()
    selected_ids = {witness_id(candidate) for candidate in selected}

    definitions = {}
    with args.input.open(encoding="utf-8") as source:
        for line in source:
            row = json.loads(line)
            if row.get("schema") == WITNESS_SCHEMA:
                definitions[row["witness_id"]] = row["candidate"]

    removed_occurrences = 0
    retained_occurrences = 0
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with args.output.open("w", encoding="utf-8") as output:
        with args.input.open(encoding="utf-8") as source:
            for line in source:
                row = json.loads(line)
                if row.get("schema") == WITNESS_SCHEMA:
                    if row["witness_id"] not in selected_ids:
                        continue
                else:
                    for group in GROUPS:
                        retained = []
                        for evidence in row.get(group) or []:
                            candidate = evidence.get("candidate")
                            reference = evidence.get("candidate_ref")
                            exact = (
                                isinstance(candidate, str)
                                and candidate.startswith("exact-")
                            ) or reference in definitions
                            if exact and (
                                (reference or witness_id(candidate)) not in selected_ids
                            ):
                                removed_occurrences += 1
                                continue
                            if exact:
                                retained_occurrences += 1
                            retained.append(evidence)
                        if group in row or retained:
                            row[group] = retained
                print(
                    json.dumps(row, separators=(",", ":"), sort_keys=True),
                    file=output,
                )

    input_bytes = args.input.stat().st_size
    output_bytes = args.output.stat().st_size
    print(
        json.dumps(
            {
                "input": str(args.input),
                "output": str(args.output),
                "certified_trace_roots": certified_roots,
                "selected_exact_witnesses": len(selected),
                "retained_exact_occurrences": retained_occurrences,
                "removed_exact_occurrences": removed_occurrences,
                "input_bytes": input_bytes,
                "output_bytes": output_bytes,
                "saved_bytes": input_bytes - output_bytes,
                "saved_percent": round(
                    100.0 * (input_bytes - output_bytes) / input_bytes, 2
                ),
            },
            sort_keys=True,
        )
    )


if __name__ == "__main__":
    main()
