#!/usr/bin/env python3
"""Run the ordered, adaptive CSR/Transformed-CSR/SRS/TRS oracle campaign.

The driver is deliberately resumable: every external command is recorded
before execution and marked complete atomically afterwards.  ``--prepare-only``
creates a fresh, fully specified campaign tree without launching the expensive
benchmark rounds.
"""

from __future__ import annotations

import argparse
from datetime import datetime
import hashlib
import json
import os
from pathlib import Path
import shutil
import sys
from typing import Any, NamedTuple


ROUND_BASE_MS = (10_000, 20_000, 40_000)
SELECTED_STATUSES = ("unknown", "timeout", "error")
CATEGORIES = (
    ("csr", Path("../TPDB-ARI/TRS_Contextsensitive"), False),
    ("transformed-csr-04", Path("../TPDB-ARI/TRS_Standard/Transformed_CSR_04"), True),
    ("srs-standard", Path("../TPDB-ARI/SRS_Standard"), True),
    ("trs-standard", Path("../TPDB-ARI/TRS_Standard"), True),
)


def write_json_atomic(path: Path, value: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(path.suffix + ".tmp")
    temporary.write_text(json.dumps(value, indent=2, sort_keys=True) + "\n")
    temporary.replace(path)


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def copy_seed(source: Path, destination: Path) -> None:
    if destination.exists():
        return
    destination.parent.mkdir(parents=True, exist_ok=True)
    try:
        os.link(source, destination)
    except OSError:
        shutil.copy2(source, destination)


class RoundMetrics(NamedTuple):
    new_certified_roots: int = 0
    new_certified_states: int = 0
    unresolved_states_before: int = 0
    unresolved_states_after: int = 0
    new_children_with_untried_families: int = 0
    timeout_frontier_below_next_allowance: int = 0
    rerun_stalled: bool = False


def adaptive_reasons(metrics: RoundMetrics, has_next_round: bool = True) -> list[str]:
    """Return the independently auditable reasons for continuing a category."""
    if not has_next_round or metrics.rerun_stalled:
        return []
    reasons: list[str] = []
    if metrics.new_certified_roots >= 1:
        reasons.append("new-certified-root")
    additional_coverage = max(
        0, metrics.unresolved_states_before - metrics.unresolved_states_after
    )
    coverage_ratio = (
        additional_coverage / metrics.unresolved_states_before
        if metrics.unresolved_states_before
        else 0.0
    )
    if metrics.new_certified_states >= 10 or coverage_ratio >= 0.01:
        reasons.append("certified-frontier-growth")
    if metrics.new_children_with_untried_families >= 25:
        reasons.append("untried-child-frontier")
    if metrics.timeout_frontier_below_next_allowance > 0:
        reasons.append("timeout-frontier")
    return reasons


def campaign_command(
    script: Path,
    ferrum: Path,
    ceta: Path,
    root: Path,
    run_dir: Path,
    oracle: Path,
    details: Path | None,
    seed: int,
) -> list[str]:
    command = [
        sys.executable,
        str(script),
        "--ferrum",
        str(ferrum),
        "--category-root",
        str(root),
        "--run-dir",
        str(run_dir),
        "--jobs",
        "64",
        "--rayon-threads",
        "2",
        "--timeout",
        "305",
        "--prover-timeout",
        "300",
        "--timeout-multiplier",
        "1",
        "--utility-guidance-manifest",
        str(oracle),
        "--ceta",
        str(ceta),
        "--ceta-timeout",
        "300",
        "--seed",
        str(seed),
    ]
    if details is not None:
        command.extend(["--from-details", str(details)])
        for status in SELECTED_STATUSES:
            command.extend(["--include-status", status])
    return command


def canonical_command(
    script: Path,
    source_db: Path,
    cache: Path,
    ferrum: Path,
    ceta: Path,
    run_dir: Path,
    timeout_ms: int,
    prior_ledgers: list[Path],
    hints: list[Path],
    seed: int,
) -> list[str]:
    command = [
        sys.executable,
        str(script),
        "--source-db",
        str(source_db),
        "--canonical-cache",
        str(cache),
        "--run-dir",
        str(run_dir),
        "--ferrum",
        str(ferrum),
        "--ceta",
        str(ceta),
        "--fragment-ceta",
        str(ceta),
        "--ceta-timeout",
        "300",
        "--jobs",
        "64",
        "--rayon-threads",
        "2",
        "--timeout-ms",
        str(timeout_ms),
        "--outer-grace",
        "5",
        "--max-probes",
        "20000",
        "--recursive-frontier",
        "--frontier-atom-limit",
        "8",
        "--exploit",
        "1",
        "--tighten",
        "2",
        "--explore",
        "1",
        "--frequent-explore",
        "4",
        "--extra-exploration-budget",
        "20000",
        "--seed",
        str(seed),
    ]
    for ledger in prior_ledgers:
        command.extend(["--prior-ledger", str(ledger)])
    for hint in hints:
        command.extend(["--candidate-hints", str(hint)])
    return command


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--campaign-dir", type=Path)
    parser.add_argument("--seed-oracle", type=Path, required=True)
    parser.add_argument("--seed-union", type=Path, required=True)
    parser.add_argument("--canonical-cache", type=Path, required=True)
    parser.add_argument("--source-db", type=Path, required=True)
    parser.add_argument("--ferrum", type=Path, default=Path("target/release/ferrum"))
    parser.add_argument(
        "--ceta", type=Path, default=Path("../CeTA-CSR/ceta")
    )
    parser.add_argument(
        "--csr-details",
        type=Path,
        help="prior CSR details used to select the initially unresolved roots",
    )
    parser.add_argument("--candidate-hints", type=Path, action="append", default=[])
    parser.add_argument("--prepare-only", action="store_true")
    args = parser.parse_args()

    cwd = Path.cwd().resolve()
    stamp = datetime.now().strftime("%Y%m%d-%H%M%S")
    campaign_dir = (
        args.campaign_dir.resolve()
        if args.campaign_dir
        else cwd / "target/data-campaign" / f"state-first-adaptive-{stamp}"
    )
    required = [
        args.seed_oracle,
        args.seed_union,
        args.canonical_cache,
        args.source_db,
        args.ferrum,
        args.ceta,
    ]
    if args.csr_details:
        required.append(args.csr_details)
    required.extend(args.candidate_hints)
    for path in required:
        if not path.resolve().exists():
            parser.error(f"required input does not exist: {path}")
    state_path = campaign_dir / "campaign.json"
    if campaign_dir.exists() and not state_path.exists():
        parser.error(f"refusing to overwrite non-campaign directory: {campaign_dir}")
    campaign_dir.mkdir(parents=True, exist_ok=True)

    seed_dir = campaign_dir / "seed"
    oracle = seed_dir / "oracle.jsonl"
    union = seed_dir / "certified-union.manifest.jsonl"
    copy_seed(args.seed_oracle.resolve(), oracle)
    copy_seed(args.seed_union.resolve(), union)
    state = (
        json.loads(state_path.read_text())
        if state_path.exists()
        else {
            "schema": "ferrum.adaptive-four-frontier.v1",
            "created_at": datetime.now().astimezone().isoformat(),
            "category_order": [row[0] for row in CATEGORIES],
            "limits": {
                "rounds_per_category": 3,
                "probes_per_round": 20000,
                "jobs": 64,
                "rayon_threads": 2,
                "prover_timeout_seconds": 300,
                "harness_timeout_seconds": 305,
                "round_base_timeout_ms": list(ROUND_BASE_MS),
                "round_escalation_cap_ms": [value * 4 for value in ROUND_BASE_MS],
                "hard_atom_cap_ms": 300000,
                "canonicalization_timeout_seconds": 60,
                "allocation": {
                    "unseen": 0.35,
                    "external_hints": 0.25,
                    "escalation": 0.20,
                    "tightening": 0.15,
                    "opposite_polarity": 0.05,
                },
            },
            "certifier": str(args.ceta.resolve()),
            "seed": {
                "oracle": str(oracle),
                "oracle_sha256": sha256(oracle),
                "certified_union": str(union),
                "certified_union_sha256": sha256(union),
            },
            "phases": {},
            "round_decisions": {},
        }
    )
    state["limits"]["canonicalization_timeout_seconds"] = 60
    write_json_atomic(state_path, state)

    # Emit the exact first-round commands even in prepare-only mode.  Later
    # rounds are generated after metrics.json has made the adaptive decision.
    collector = cwd / "scripts/collect_processor_events.py"
    canonical = cwd / "scripts/run_canonical_processor_campaign.py"
    planned: dict[str, Any] = {}
    for index, (name, raw_root, needs_baseline) in enumerate(CATEGORIES):
        root = raw_root.resolve()
        category_dir = campaign_dir / name
        baseline_details = (
            args.csr_details.resolve()
            if name == "csr" and args.csr_details
            else None
        )
        root_command = campaign_command(
            collector,
            args.ferrum.resolve(),
            args.ceta.resolve(),
            root,
            category_dir / ("baseline" if needs_baseline else "rounds/r01/root"),
            oracle,
            baseline_details,
            4100 + index * 10,
        )
        canonical_run = canonical_command(
            canonical,
            args.source_db.resolve(),
            args.canonical_cache.resolve(),
            args.ferrum.resolve(),
            args.ceta.resolve(),
            category_dir / "rounds/r01/probes",
            ROUND_BASE_MS[0],
            [],
            [path.resolve() for path in args.candidate_hints],
            4101 + index * 10,
        )
        planned[name] = {
            "root": str(root),
            "fresh_baseline": needs_baseline,
            "selected_statuses": list(SELECTED_STATUSES),
            "baseline_or_unresolved_command": root_command,
            "round_1_probe_command": canonical_run,
        }
    write_json_atomic(campaign_dir / "planned-commands.json", planned)
    if args.prepare_only:
        print(json.dumps({"campaign": str(campaign_dir), "status": "prepared"}))
        return 0

    # Expensive execution is intentionally phase-driven.  A category baseline
    # must first be aggregated into its source database; the generated command
    # manifest is the stable handoff used by operators and batch schedulers.
    print(
        json.dumps(
            {
                "campaign": str(campaign_dir),
                "status": "prepared",
                "next": "execute planned phases and record per-round metrics",
            }
        )
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
