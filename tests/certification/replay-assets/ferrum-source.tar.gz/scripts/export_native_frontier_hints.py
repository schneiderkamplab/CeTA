"""Scaffold open typed states using native families from their root evidence.

These are untried search hints, never certified processor results. No model,
pair deletion mask, proof fragment, or compound strategy is exported.
"""
import argparse
import json
from pathlib import Path
import xml.etree.ElementTree as ET

from probe_native_event_frontier import native_atoms, unresolved_states, fit_signature


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--baseline', type=Path, required=True)
    parser.add_argument('--additional-baseline', type=Path, action='append', default=[],
                        help='Also reuse native families from later certified recoveries')
    parser.add_argument('--current', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--state-kind', choices=['all', 'trs', 'dp'], default='all')
    parser.add_argument('--include-exhausted', action='store_true',
                        help='Also scaffold states whose existing guidance exhausted all attempts')
    args = parser.parse_args()
    prior = {}
    for source in [args.baseline, *args.additional_baseline]:
        for row in json.loads(source.read_text()):
            if row.get('certified'):
                prior.setdefault(row['path'], []).append(row)
    rows = {}
    for root in json.loads(args.current.read_text()):
        if root.get('certified'):
            continue
        atoms = []
        top_level_dp = False
        for old in prior.get(root['path'], []):
            old_events = Path(old['artifact_dir']) / 'processor-events.jsonl'
            recorded = list(map(json.loads, old_events.read_text().splitlines()))
            top_level_dp |= any((e.get('strategy_atom') or e.get('processor', '')).split('(', 1)[0]
                               in ('dp', 'exact-dp') for e in recorded
                               if e.get('outcome') in ('solved', 'transformed'))
            for atom in native_atoms(recorded):
                if atom not in atoms:
                    atoms.append(atom)
        if not atoms:
            continue
        events = Path(root['artifact_dir']) / 'processor-events.jsonl'
        states = unresolved_states(map(json.loads, events.read_text().splitlines()),
                                   include_trs=True, include_exhausted=args.include_exhausted)
        for key, (_, cpf) in states.items():
            kind = 'trs' if ET.fromstring(cpf).tag == 'trsInput' else 'dp'
            if args.state_kind != 'all' and args.state_kind != kind:
                continue
            row = rows.setdefault(key, dict(schema='ferrum.utility-guidance.v2',
                problem_key=key, prefer=[], possible=[], avoid=[], timeout=[]))
            known = {item['candidate'] for item in row['possible']}
            for atom in atoms + (['dp'] if kind == 'trs' and top_level_dp else []):
                atom = fit_signature(atom, cpf)
                if atom in known:
                    continue
                if 'exact-' in atom or 'hex=' in atom or ';' in atom:
                    raise ValueError('non-native frontier hint')
                row['possible'].append(dict(candidate=atom, status='transformed_weak',
                    utility_score=1.0, attempts=0, certified_count=0, solved_count=0,
                    transformed_count=0, failed_count=0, timeout_count=0))
                known.add(atom)
    with args.output.open('x') as out:
        for row in rows.values():
            print(json.dumps(row), file=out)
    print(json.dumps(dict(states=len(rows), certified_credit=0)))


if __name__ == '__main__':
    main()
