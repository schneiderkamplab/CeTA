#!/usr/bin/env python3
"""Extract subproof training rows from original and normalized XML artefacts.

Each JSONL row has one XML proof fragment as the output and the available
problem/context XML as the input. The extractor is intentionally conservative:
it preserves XML fragments verbatim after ElementTree normalization and does not
try to prove semantic equivalence between consecutive subproblems.
"""

from __future__ import annotations

import argparse
import gzip
import hashlib
import json
import sqlite3
import sys
import xml.etree.ElementTree as ET
from copy import copy
from pathlib import Path
from typing import Any, Iterable


CPF_PROOF_FRAGMENT_TAGS = {
    "dpTrans",
    "depGraphProc",
    "usableRulesProc",
    "innermostLhssRemovalProc",
    "redPairProc",
    "monoRedPairProc",
    "subtermCriterionProc",
    "sizeChangeProc",
    "instantiationProc",
    "forwardInstantiationProc",
    "csrForwardInstantiationProc",
    "narrowingProc",
    "rewriteProc",
    "switchInnermostProc",
    "ruleRemovalProc",
    "ruleRemoval",
    "equalityRemoval",
    "stringReversal",
    "interpretation",
    "polynomialOrder",
    "matrixOrder",
    "pathOrder",
    "kbo",
    "lpo",
    "rpo",
    "loop",
    "nonLoop",
    "bounds",
}

FERRUM_NORMALIZED_TAGS = {
    "step",
    "polynomialInterpretation",
    "removed",
}


def local_name(tag: str) -> str:
    return tag.rsplit("}", 1)[-1]


def xml_bytes(elem: ET.Element) -> bytes:
    return ET.tostring(elem, encoding="utf-8")


def strip_result_prefix(text: str) -> str:
    stripped = text.lstrip()
    if stripped.startswith(("YES\n", "NO\n", "MAYBE\n")):
        return "\n".join(stripped.splitlines()[1:])
    return text


def load_xml(path: str, max_file_bytes: int | None) -> ET.Element | None:
    try:
        file_path = Path(path)
        if max_file_bytes is not None and file_path.stat().st_size > max_file_bytes:
            return None
        text = file_path.read_text(errors="replace")
    except OSError:
        return None
    text = strip_result_prefix(text)
    start_candidates = [idx for idx in (text.find("<?xml"), text.find("<certificationProblem"), text.find("<ferrumTextProofNormalization")) if idx >= 0]
    if start_candidates:
        text = text[min(start_candidates) :]
    try:
        return ET.fromstring(text.encode())
    except ET.ParseError:
        return None


def first_child(root: ET.Element, name: str) -> ET.Element | None:
    for child in root:
        if local_name(child.tag) == name:
            return child
    return None


def child_text(parent: ET.Element | None, name: str) -> str | None:
    if parent is None:
        return None
    child = first_child(parent, name)
    if child is None:
        return None
    return "".join(child.itertext()).strip()


def parent_map(root: ET.Element) -> dict[int, ET.Element]:
    return {id(child): parent for parent in root.iter() for child in parent}


def path_to(root: ET.Element, elem: ET.Element, parents: dict[int, ET.Element]) -> list[str]:
    path = [local_name(elem.tag)]
    current = elem
    while id(current) in parents:
        current = parents[id(current)]
        path.append(local_name(current.tag))
        if current is root:
            break
    return list(reversed(path))


def local_context(parent: ET.Element | None, elem: ET.Element) -> str | None:
    if parent is None:
        return None
    parent_copy = ET.Element(local_name(parent.tag), dict(parent.attrib))
    for child in list(parent):
        if child is elem:
            hole = ET.Element("proofHole", {"tag": local_name(elem.tag)})
            parent_copy.append(hole)
        else:
            parent_copy.append(copy(child))
    return xml_bytes(parent_copy).decode("utf-8", "replace")


def fetch_dicts(conn: sqlite3.Connection, query: str) -> list[dict[str, Any]]:
    cursor = conn.execute(query)
    columns = [description[0] for description in cursor.description]
    return [dict(zip(columns, row)) for row in cursor]


def source_rows(
    conn: sqlite3.Connection,
    source: str,
    limit: int | None,
    min_file_bytes: int,
    progress: bool = False,
) -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    if source in {"original", "all"}:
        query = """
            select 'original' as source_kind, proof_url, year, category, benchmark, tool,
                   result, certification, local_path as xml_path, detected_format as xml_format,
                   null as normalizer
            from proofs
            where download_error is null
              and detected_format = 'cpf-or-xml'
              and local_path != ''
            order by year, category, tool, benchmark
        """
        rows.extend(fetch_dicts(conn, query))
        if progress:
            print(json.dumps({"event": "source_loaded", "kind": "original", "rows": len(rows)}, sort_keys=True), flush=True)
    if source in {"normalized", "all"}:
        query = """
            select 'normalized' as source_kind, p.proof_url, p.year, p.category, p.benchmark, p.tool,
                   p.result, p.certification, n.normalized_path as xml_path,
                   n.normalized_format as xml_format, n.normalizer
            from normalized_proofs n
            join proofs p using(proof_url)
            order by p.year, p.category, p.tool, p.benchmark, n.normalizer
        """
        before = len(rows)
        rows.extend(fetch_dicts(conn, query))
        if progress:
            print(
                json.dumps(
                    {"event": "source_loaded", "kind": "normalized", "rows": len(rows) - before, "rows_total": len(rows)},
                    sort_keys=True,
                ),
                flush=True,
            )
    def size_key(row: dict[str, Any]) -> int:
        try:
            return Path(row["xml_path"]).stat().st_size
        except OSError:
            return 10**18

    if progress:
        print(json.dumps({"event": "source_sort_started", "rows": len(rows)}, sort_keys=True), flush=True)
    rows.sort(key=size_key)
    if min_file_bytes > 0:
        before = len(rows)
        rows = [row for row in rows if size_key(row) >= min_file_bytes]
        if progress:
            print(
                json.dumps(
                    {
                        "event": "source_tiny_filtered",
                        "before": before,
                        "after": len(rows),
                        "min_file_bytes": min_file_bytes,
                    },
                    sort_keys=True,
                ),
                flush=True,
            )
    if progress:
        print(json.dumps({"event": "source_sort_done", "rows": len(rows)}, sort_keys=True), flush=True)
    if limit is not None:
        return rows[:limit]
    return rows


def iter_training_rows(source_row: dict[str, Any], root: ET.Element) -> Iterable[dict[str, Any]]:
    tags = FERRUM_NORMALIZED_TAGS if local_name(root.tag) == "ferrumTextProofNormalization" else CPF_PROOF_FRAGMENT_TAGS
    parents = parent_map(root)
    global_input = first_child(root, "input")
    metadata = first_child(root, "metadata")
    problem_xml = xml_bytes(global_input).decode("utf-8", "replace") if global_input is not None else None
    if problem_xml is None and metadata is not None:
        problem_xml = xml_bytes(metadata).decode("utf-8", "replace")
    for elem in root.iter():
        tag = local_name(elem.tag)
        if tag not in tags:
            continue
        output = xml_bytes(elem).decode("utf-8", "replace")
        parent = parents.get(id(elem))
        context = local_context(parent, elem)
        row_id_material = f"{source_row['proof_url']}\0{source_row.get('normalizer') or ''}\0{tag}\0{output}".encode()
        yield {
            "id": hashlib.sha256(row_id_material).hexdigest(),
            "source": {
                "kind": source_row["source_kind"],
                "proof_url": source_row["proof_url"],
                "xml_path": source_row["xml_path"],
                "xml_format": source_row["xml_format"],
                "normalizer": source_row.get("normalizer"),
            },
            "metadata": {
                "year": source_row["year"],
                "category": source_row["category"],
                "benchmark": source_row["benchmark"],
                "tool": source_row["tool"],
                "result": source_row["result"],
                "certification": source_row["certification"],
                "processor_tag": tag,
                "path": path_to(root, elem, parents),
                "normalized_tool": child_text(metadata, "tool") if metadata is not None else None,
            },
            "input": {
                "problem_xml": problem_xml,
                "local_context_xml": context,
            },
            "output_xml": output,
        }


def open_output(path: Path):
    path.parent.mkdir(parents=True, exist_ok=True)
    if path.suffix == ".gz":
        return gzip.open(path, "wt", encoding="utf-8")
    return path.open("w", encoding="utf-8")


def emit_progress(event: dict[str, Any], progress_handle: Any | None = None, to_stdout: bool = True) -> None:
    line = json.dumps(event, sort_keys=True)
    if progress_handle is not None:
        progress_handle.write(line + "\n")
        progress_handle.flush()
    if to_stdout:
        print(line, flush=True)


def main() -> int:
    # Certified proof trees can be deeply nested; ElementTree serialization is
    # recursive, so Python's default recursion limit is too small for this
    # offline corpus extraction pass.
    sys.setrecursionlimit(max(sys.getrecursionlimit(), 200_000))

    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--out", type=Path, default=Path("target/termcomp-proof-corpus"))
    parser.add_argument(
        "--output",
        type=Path,
        default=Path("target/termcomp-proof-corpus/training/subproofs.jsonl.gz"),
    )
    parser.add_argument("--source", choices=["original", "normalized", "all"], default="all")
    parser.add_argument("--limit-docs", type=int)
    parser.add_argument("--max-output-xml-bytes", type=int, default=2_000_000)
    parser.add_argument("--max-input-xml-bytes", type=int, default=2_000_000)
    parser.add_argument("--min-file-bytes", type=int, default=100)
    parser.add_argument("--max-file-bytes", type=int, default=25_000_000, help="skip XML source files larger than this; use 0 for no limit")
    parser.add_argument("--progress-interval", type=int, default=1000)
    parser.add_argument("--per-proof-progress", action="store_true")
    parser.add_argument(
        "--proof-row-progress-interval",
        type=int,
        default=1000,
        help="when per-proof progress is enabled, report every N exported rows inside a single proof; use 0 to disable",
    )
    parser.add_argument(
        "--per-proof-progress-log",
        type=Path,
        help="write per-proof progress JSONL here; stdout still receives periodic summaries",
    )
    args = parser.parse_args()

    conn = sqlite3.connect(args.out / "proofs.sqlite")
    docs = source_rows(conn, args.source, args.limit_docs, args.min_file_bytes, progress=True)
    print(json.dumps({"event": "source_ready", "docs": len(docs), "source": args.source}, sort_keys=True), flush=True)
    written = 0
    parsed = 0
    skipped_parse = 0
    skipped_file_size = 0
    skipped_large = 0
    proofs_with_rows = 0
    by_tag: dict[str, int] = {}
    max_file_bytes = None if args.max_file_bytes == 0 else args.max_file_bytes
    progress_handle = args.per_proof_progress_log.open("w", encoding="utf-8") if args.per_proof_progress_log else None
    with open_output(args.output) as handle:
        for idx, source_row in enumerate(docs, start=1):
            path = Path(source_row["xml_path"])
            file_size = path.stat().st_size if path.exists() else None
            if args.per_proof_progress:
                emit_progress(
                    {
                        "event": "proof_started",
                        "doc_index": idx,
                        "docs_total": len(docs),
                        "source_kind": source_row["source_kind"],
                        "normalizer": source_row.get("normalizer"),
                        "year": source_row["year"],
                        "category": source_row["category"],
                        "tool": source_row["tool"],
                        "benchmark": source_row["benchmark"],
                        "xml_path": source_row["xml_path"],
                        "file_bytes": file_size,
                        "rows_written_total": written,
                        "proofs_with_rows": proofs_with_rows,
                    },
                    progress_handle,
                    to_stdout=progress_handle is None,
                )
            if file_size is not None and file_size < args.min_file_bytes:
                skipped_file_size += 1
                root = None
            elif max_file_bytes is not None and path.exists() and path.stat().st_size > max_file_bytes:
                skipped_file_size += 1
                root = None
            else:
                root = load_xml(source_row["xml_path"], max_file_bytes)
            if root is None:
                skipped_parse += 1
                if args.per_proof_progress:
                    emit_progress(
                        {
                            "event": "proof_skipped",
                            "doc_index": idx,
                            "reason": "parse_or_file_size",
                            "file_bytes": file_size,
                            "docs_parsed": parsed,
                            "rows_written_total": written,
                            "skipped_parse": skipped_parse,
                            "skipped_file_size": skipped_file_size,
                        },
                        progress_handle,
                        to_stdout=progress_handle is None,
                    )
                continue
            parsed += 1
            proof_rows = 0
            proof_skipped_large = 0
            try:
                for row in iter_training_rows(source_row, root):
                    output_bytes = len(row["output_xml"].encode())
                    input_bytes = len((row["input"].get("problem_xml") or "").encode()) + len((row["input"].get("local_context_xml") or "").encode())
                    if output_bytes > args.max_output_xml_bytes or input_bytes > args.max_input_xml_bytes:
                        skipped_large += 1
                        proof_skipped_large += 1
                        continue
                    handle.write(json.dumps(row, sort_keys=True) + "\n")
                    written += 1
                    proof_rows += 1
                    tag = row["metadata"]["processor_tag"]
                    by_tag[tag] = by_tag.get(tag, 0) + 1
                    if (
                        args.per_proof_progress
                        and args.proof_row_progress_interval > 0
                        and proof_rows % args.proof_row_progress_interval == 0
                    ):
                        emit_progress(
                            {
                                "event": "proof_progress",
                                "doc_index": idx,
                                "docs_total": len(docs),
                                "docs_parsed": parsed,
                                "source_kind": source_row["source_kind"],
                                "normalizer": source_row.get("normalizer"),
                                "year": source_row["year"],
                                "category": source_row["category"],
                                "tool": source_row["tool"],
                                "benchmark": source_row["benchmark"],
                                "file_bytes": file_size,
                                "rows_exported_for_proof": proof_rows,
                                "rows_skipped_large_for_proof": proof_skipped_large,
                                "rows_written_total": written,
                                "proofs_with_rows": proofs_with_rows,
                                "skipped_large_total": skipped_large,
                            },
                            progress_handle,
                            to_stdout=progress_handle is None,
                        )
            except (RecursionError, ET.ParseError, ValueError) as error:
                skipped_parse += 1
                if args.per_proof_progress:
                    emit_progress(
                        {
                            "event": "proof_error",
                            "doc_index": idx,
                            "docs_total": len(docs),
                            "docs_parsed": parsed,
                            "source_kind": source_row["source_kind"],
                            "normalizer": source_row.get("normalizer"),
                            "year": source_row["year"],
                            "category": source_row["category"],
                            "tool": source_row["tool"],
                            "benchmark": source_row["benchmark"],
                            "file_bytes": file_size,
                            "error_type": type(error).__name__,
                            "error": str(error),
                            "rows_exported_for_proof": proof_rows,
                            "rows_written_total": written,
                            "skipped_parse": skipped_parse,
                        },
                        progress_handle,
                        to_stdout=progress_handle is None,
                    )
            if proof_rows:
                proofs_with_rows += 1
            if args.per_proof_progress:
                emit_progress(
                    {
                        "event": "proof_done",
                        "doc_index": idx,
                        "docs_total": len(docs),
                        "docs_parsed": parsed,
                        "source_kind": source_row["source_kind"],
                        "normalizer": source_row.get("normalizer"),
                        "year": source_row["year"],
                        "category": source_row["category"],
                        "tool": source_row["tool"],
                        "benchmark": source_row["benchmark"],
                        "file_bytes": file_size,
                        "rows_exported_for_proof": proof_rows,
                        "rows_skipped_large_for_proof": proof_skipped_large,
                        "rows_written_total": written,
                        "proofs_with_rows": proofs_with_rows,
                        "skipped_large_total": skipped_large,
                    },
                    progress_handle,
                    to_stdout=progress_handle is None,
                )
            if idx % max(1, args.progress_interval) == 0:
                print(
                    json.dumps(
                        {
                            "docs_scanned": idx,
                            "docs_total": len(docs),
                            "docs_parsed": parsed,
                            "rows_written": written,
                            "proofs_with_rows": proofs_with_rows,
                            "skipped_parse": skipped_parse,
                            "skipped_file_size": skipped_file_size,
                            "skipped_large": skipped_large,
                        },
                        sort_keys=True,
                    ),
                    flush=True,
                )
    summary = {
        "docs_total": len(docs),
        "docs_parsed": parsed,
        "rows_written": written,
        "proofs_with_rows": proofs_with_rows,
        "skipped_parse": skipped_parse,
        "skipped_file_size": skipped_file_size,
        "skipped_large": skipped_large,
        "by_tag": dict(sorted(by_tag.items(), key=lambda item: (-item[1], item[0]))),
        "output": str(args.output),
    }
    (args.output.parent / "subproofs.summary.json").write_text(json.dumps(summary, indent=2, sort_keys=True))
    if progress_handle is not None:
        progress_handle.close()
    print(json.dumps(summary, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
