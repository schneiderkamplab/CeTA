import unittest

from audit_csr_root_correspondence import compare, read_ari


class CorrespondenceTests(unittest.TestCase):
    source = '(format CSTRS) (fun f 1 :replacement-map (1)) (rule (f X) X)'
    certificate = '''<certificationProblem><input><trsInput><trs><rules>
      <rule><funapp><name>f</name><var>Y</var></funapp><var>Y</var></rule>
      </rules></trs><strategy><contextSensitive><replacementMapEntry>
      <name>f</name><arity>1</arity><position>1</position>
      </replacementMapEntry></contextSensitive></strategy></trsInput></input>
      <property><termination/></property><answer><yes/></answer></certificationProblem>'''

    def test_alpha_renaming(self):
        self.assertTrue(compare(self.source, self.certificate, 'yes')['rule_multiset_equal'])

    def test_changed_rule(self):
        with self.assertRaises(ValueError):
            compare(self.source, self.certificate.replace('</funapp><var>Y', '</funapp><var>Z'), 'yes')

    def test_changed_map(self):
        with self.assertRaises(ValueError):
            compare(self.source, self.certificate.replace('<position>1</position>', ''), 'yes')

    def test_changed_polarity(self):
        with self.assertRaises(ValueError):
            compare(self.source, self.certificate, 'no')

    def test_function_names_are_not_alpha_renamed(self):
        with self.assertRaises(ValueError):
            compare(self.source, self.certificate.replace('<name>f</name>', '<name>g</name>'), 'yes')

    def test_marked_root_symbols_are_rejected(self):
        with self.assertRaises(ValueError):
            compare(self.source, self.certificate.replace('<name>f</name>', '<sharp><name>f</name></sharp>', 1), 'yes')

    def test_unused_marked_map_entry_is_harmless(self):
        extra = '<replacementMapEntry><sharp><name>f</name></sharp><arity>1</arity></replacementMapEntry>'
        result = compare(self.source, self.certificate.replace('</contextSensitive>', extra + '</contextSensitive>'), 'yes')
        self.assertEqual(len(result['unused_cpf_map_entries']), 1)

    def test_omitted_map_defaults_to_full(self):
        self.assertEqual(read_ari('(format CSTRS) (fun f 2)')[1], {'f': (1, 2)})

    def test_invalid_declarations(self):
        for declaration in ('(fun f 1 :replacement-map (2))', '(fun f 1) (fun f 1)'):
            with self.assertRaises(ValueError):
                read_ari('(format CSTRS) ' + declaration)

    def test_rule_and_map_spellings_must_agree(self):
        consistent = self.certificate.replace('<name>f</name>', '<name>|f|</name>')
        self.assertTrue(compare(self.source, consistent, 'yes')['rule_multiset_equal'])
        with self.assertRaisesRegex(ValueError, 'distinct CPF symbols'):
            compare(self.source, consistent.replace('<name>|f|</name>', '<name>f</name>', 1), 'yes')

    def test_spelling_normalization_cannot_merge_two_rule_symbols(self):
        source = '(format CSTRS) (fun f 0) (rule f f)'
        cpf = self.certificate.replace(
            '<funapp><name>f</name><var>Y</var></funapp><var>Y</var>',
            '<funapp><name>f</name></funapp><funapp><name>|f|</name></funapp>')
        with self.assertRaisesRegex(ValueError, 'distinct CPF symbols'):
            compare(source, cpf, 'yes')


if __name__ == '__main__':
    unittest.main()
