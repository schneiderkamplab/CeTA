#!/usr/bin/env python3
"""Replace exact rational models with one-result minimum-deletion searches."""

from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path

from build_credited_status_map_dataset import canonicalize_cpf_input, compact_xml_for_key
from replace_weak_polynomial_with_residual_targets import cpf_pairs, deleted_indices


WITNESS_SCHEMA = "ferrum.utility-guidance.witness.v1"
GROUPS = ("avoid", "possible", "prefer", "timeout")


def decode_bounds(candidate: str) -> tuple[int, int, int, int, int]:
    prefix = "exact-rat-poly(hex="
    denominator, witness = json.loads(bytes.fromhex(candidate[len(prefix) : -1]))
    if denominator <= 0 or not witness:
        raise ValueError("invalid rational-polynomial witness")
    constants = [constant for _, constant, _ in witness]
    coefficients = [coefficient for _, _, args in witness for coefficient in args]
    if min(constants, default=0) < 0 or min(coefficients, default=0) < 0:
        raise ValueError("rational natural-polynomial witness has negative parameters")
    return (
        denominator,
        max(constants, default=0),
        max(coefficients, default=0),
        len(witness),
        max((len(args) for _, _, args in witness), default=0),
    )


def atom(bounds: tuple[int, int, int, int, int], min_delete: int | None) -> str:
    denominator, constant, coefficient, symbols, arity = bounds
    name = "rat-poly-target" if min_delete is not None else "rat-poly"
    args = [
        f"max-constant={constant}",
        f"max-coefficient={coefficient}",
        f"max-symbols={symbols}",
        f"max-arity={arity}",
        f"denominator={denominator}",
        f"delta-denominator={denominator}",
    ]
    if min_delete is not None:
        args.extend((f"min-delete={min_delete}", "residual-budget=1"))
    return f"{name}({','.join(args)})"


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("input", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("--run-dir", type=Path, required=True)
    parser.add_argument("--events-jsonl", type=Path, action="append", default=[])
    parser.add_argument("--affected-roots-output", type=Path)
    args = parser.parse_args()

    rows = [json.loads(line) for line in args.input.open(encoding="utf-8")]
    definitions = {
        row["witness_id"]: row["candidate"]
        for row in rows
        if row.get("schema") == WITNESS_SCHEMA
        and row.get("candidate", "").startswith("exact-rat-poly(")
    }
    bounds = {identifier: decode_bounds(candidate) for identifier, candidate in definitions.items()}
    candidate_ids = {candidate: identifier for identifier, candidate in definitions.items()}
    targets = {}
    affected_roots = set()
    selected_events = 0
    events = []
    for result_path in args.run_dir.rglob("result.json"):
        result = json.loads(result_path.read_text(encoding="utf-8"))
        if not result.get("certified"):
            continue
        events_path = result_path.parent / "processor-events.jsonl"
        if not events_path.exists():
            continue
        for line in events_path.open(encoding="utf-8"):
            events.append((result["path"], json.loads(line)))
    for events_path in args.events_jsonl:
        for line in events_path.open(encoding="utf-8"):
            event = json.loads(line)
            certification = event.get("certification") or {}
            if certification.get("status", "").startswith(("accepted", "certified")):
                events.append((event["problem_id"], event))

    for root, event in events:
        identifier = candidate_ids.get(event.get("processor", ""))
        if identifier is None:
            continue
        if event.get("level") != "dependency-pair":
            raise ValueError("retained rational witness is not DP-local")
        residuals = (event.get("witness") or {}).get("residuals") or []
        if len(residuals) > 1:
            raise ValueError("rational event has multiple residuals")
        event_input = event["input"]
        canonical, error = canonicalize_cpf_input(event_input["cpf"])
        if error is not None:
            raise ValueError(f"cannot canonicalize selected DP state: {error}")
        keys = (
            event_input["problem_key"],
            hashlib.sha256(compact_xml_for_key(event_input["cpf"]).encode()).hexdigest(),
            hashlib.sha256(canonical.encode()).hexdigest(),
        )
        minimum = (
            len(deleted_indices(event_input["cpf"], residuals[0]["cpf"]))
            if residuals
            else len(cpf_pairs(event_input["cpf"]))
        )
        selected = atom(bounds[identifier], minimum)
        for key in keys:
            identity = (key, identifier)
            if identity in targets and targets[identity] != selected:
                raise ValueError("one canonical state/witness has conflicting deletion counts")
            targets[identity] = selected
        affected_roots.add(root)
        selected_events += 1

    targeted = generic = 0
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with args.output.open("w", encoding="utf-8") as output:
        for row in rows:
            if row.get("schema") == WITNESS_SCHEMA and row.get("witness_id") in definitions:
                continue
            if row.get("schema") != WITNESS_SCHEMA:
                key = row.get("problem_key", "")
                for group in GROUPS:
                    retained = []
                    seen = set()
                    for evidence in row.get(group) or []:
                        reference = evidence.get("candidate_ref")
                        if reference in definitions:
                            candidate = targets.get((key, reference), atom(bounds[reference], None))
                            evidence = {
                                **{k: v for k, v in evidence.items() if k != "candidate_ref"},
                                "candidate": candidate,
                            }
                            targeted += candidate.startswith("rat-poly-target(")
                            generic += candidate.startswith("rat-poly(")
                        identity = (evidence.get("candidate"), evidence.get("candidate_ref"), evidence.get("status"))
                        if identity not in seen:
                            seen.add(identity)
                            retained.append(evidence)
                    if group in row or retained:
                        row[group] = retained
            print(json.dumps(row, separators=(",", ":"), sort_keys=True), file=output)

    if args.affected_roots_output is not None:
        args.affected_roots_output.write_text("\n".join(sorted(affected_roots)) + "\n", encoding="utf-8")
    print(json.dumps({
        "definitions_removed": len(definitions),
        "selected_events": selected_events,
        "targeted_state_replacements": targeted,
        "generic_replacements": generic,
        "affected_roots": len(affected_roots),
    }, sort_keys=True))


if __name__ == "__main__":
    main()
