"""Retain exact DP worklist inputs from opt-in diagnostic traces, without promotion."""
import argparse
import hashlib
import json
from pathlib import Path
import xml.etree.ElementTree as ET


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("trace", type=Path)
    parser.add_argument("output", type=Path)
    args = parser.parse_args()
    args.output.mkdir()
    seen = set()
    with args.trace.open() as trace, (args.output / "inputs.txt").open("x") as inputs, \
            (args.output / "states.jsonl").open("x") as records:
        for line in trace:
            if not line.startswith("worklist-input "):
                continue
            xml = json.loads(line[len("worklist-input "):])
            digest = hashlib.sha256(xml.encode()).hexdigest()
            if digest in seen:
                continue
            seen.add(digest)
            root = ET.fromstring(xml)
            path = args.output / f"{digest}.cpf"
            path.write_text(xml)
            print(path.resolve(), file=inputs)
            print(json.dumps(dict(path=str(path), sha256=digest,
                pairs=len(root.findall(".//dps/rules/rule")),
                rules=len(root.findall(".//trs/rules/rule")),
                active_rules=len(root.findall(".//usableRules/rules/rule")),
                certified=False)), file=records)
    print(json.dumps(dict(unique_states=len(seen))))


if __name__ == "__main__":
    main()
