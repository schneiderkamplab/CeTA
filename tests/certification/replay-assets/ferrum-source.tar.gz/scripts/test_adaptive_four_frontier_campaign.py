#!/usr/bin/env python3

import importlib.util
import json
from pathlib import Path
import tempfile
import unittest


ADAPTIVE_PATH = Path(__file__).with_name("run_adaptive_four_frontier_campaign.py")
SPEC = importlib.util.spec_from_file_location("adaptive", ADAPTIVE_PATH)
assert SPEC is not None and SPEC.loader is not None
ADAPTIVE = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(ADAPTIVE)

COLLECTOR_PATH = Path(__file__).with_name("collect_processor_events.py")
COLLECTOR_SPEC = importlib.util.spec_from_file_location("collector", COLLECTOR_PATH)
assert COLLECTOR_SPEC is not None and COLLECTOR_SPEC.loader is not None
COLLECTOR = importlib.util.module_from_spec(COLLECTOR_SPEC)
COLLECTOR_SPEC.loader.exec_module(COLLECTOR)


class AdaptiveStoppingTest(unittest.TestCase):
    def test_frontier_growth_continues_without_new_root(self) -> None:
        metrics = ADAPTIVE.RoundMetrics(
            new_certified_states=11,
            unresolved_states_before=100,
            unresolved_states_after=99,
        )
        self.assertIn("certified-frontier-growth", ADAPTIVE.adaptive_reasons(metrics))

    def test_untried_children_and_timeout_frontier_continue(self) -> None:
        metrics = ADAPTIVE.RoundMetrics(
            new_children_with_untried_families=25,
            timeout_frontier_below_next_allowance=3,
        )
        self.assertEqual(
            ADAPTIVE.adaptive_reasons(metrics),
            ["untried-child-frontier", "timeout-frontier"],
        )

    def test_stalled_rerun_stops_even_with_other_signals(self) -> None:
        metrics = ADAPTIVE.RoundMetrics(
            new_certified_roots=1,
            new_certified_states=20,
            rerun_stalled=True,
        )
        self.assertEqual(ADAPTIVE.adaptive_reasons(metrics), [])


class DetailsSelectionTest(unittest.TestCase):
    def test_selects_only_requested_statuses(self) -> None:
        with tempfile.TemporaryDirectory() as raw:
            directory = Path(raw)
            unknown = directory / "unknown.ari"
            solved = directory / "solved.ari"
            details = directory / "details.json"
            details.write_text(
                json.dumps(
                    [
                        {"path": str(unknown), "status": "unknown"},
                        {"path": str(solved), "status": "yes"},
                    ]
                )
            )
            self.assertEqual(
                COLLECTOR.selected_detail_paths([details], {"unknown"}),
                {unknown.resolve()},
            )


if __name__ == "__main__":
    unittest.main()
