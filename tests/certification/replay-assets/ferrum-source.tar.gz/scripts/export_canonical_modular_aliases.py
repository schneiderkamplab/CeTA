#!/usr/bin/env python3
"""Export full-context canonical aliases of source-bound, gated local witnesses.

The encoded source/witness is unchanged. Native exact processors must still
validate/transport it to the live state. No context field is stripped.
"""
import argparse
from concurrent.futures import ThreadPoolExecutor, as_completed
import hashlib
import json
from pathlib import Path

from build_credited_status_map_dataset import canonicalize_with_ferrum


PORTABLE = ('exact-dp-transform(', 'exact-dp(', 'exact-graph(',
            'exact-red-pair(', 'exact-semantic-labeling(', 'exact-usable-rules(',
            'exact-innermost-lhss(', 'exact-size-change(')


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--shards', type=Path, required=True)
    p.add_argument('--output', type=Path, required=True)
    p.add_argument('--ferrum', required=True)
    p.add_argument('--jobs', type=int, default=8)
    args = p.parse_args()
    args.output.mkdir(parents=True, exist_ok=False)
    tasks = [json.loads(s) for s in (args.shards / 'results.jsonl').read_text().splitlines()
             if json.loads(s)['returncode'] == 0]

    def convert(task):
        source = Path(task['output'])
        destination = args.output / Path(task['path']).with_suffix('')
        destination.mkdir(parents=True)
        manifest = {(r['problem_key'], r['candidate']): r for r in map(json.loads,
            (source / 'manifest.jsonl').read_text().splitlines())
            if r.get('recheck_status') == 'certified' and r.get('deterministic_rechecks', 0) >= 2}
        cache, seen, failures = {}, set(), []
        with (destination / 'events.jsonl').open('x') as events, (destination / 'manifest.jsonl').open('x') as gates:
            for event in map(json.loads, (source / 'events.jsonl').read_text().splitlines()):
                atom = event.get('strategy_atom', '')
                gate = manifest.get((event['input']['problem_key'], atom))
                if gate is None or not atom.startswith(PORTABLE):
                    continue
                cpf = event['input']['cpf']
                if cpf not in cache:
                    try:
                        cache[cpf] = canonicalize_with_ferrum(cpf, args.ferrum, 60)
                    except Exception as error:
                        failures.append(type(error).__name__)
                        cache[cpf] = None
                canonical = cache[cpf]
                if canonical is None:
                    continue
                key = hashlib.sha256(canonical.strip().encode()).hexdigest()
                if (key, atom) in seen:
                    continue
                seen.add((key, atom))
                event['input'] = dict(cpf=canonical, problem_key=key)
                event['canonical_alias'] = 'full-context-source-bound'
                print(json.dumps(event), file=events)
                print(json.dumps(dict(gate, problem_key=key)), file=gates)
        (destination / 'canonicalization-failures.json').write_text(json.dumps(failures))
        return dict(path=task['path'], output=str(destination), returncode=0,
                    aliases=len(seen), canonicalization_failures=len(failures))

    with ThreadPoolExecutor(max_workers=args.jobs) as pool:
        with (args.output / 'results.jsonl').open('x') as out:
            for future in as_completed([pool.submit(convert, task) for task in tasks]):
                row = future.result()
                print(json.dumps(row), file=out, flush=True)
                print(json.dumps(row), flush=True)


if __name__ == '__main__':
    main()
