import json
import unittest
from modularize_nontermination_leaves import PATTERN, replace_leaf


class LeafMigrationTests(unittest.TestCase):
    def migrate(self, kind, proof):
        atom = 'exact-' + kind + '-nontermination-proof(hex=' + json.dumps(
            ['source-context', proof]).encode().hex() + ')'
        return atom, PATTERN.sub(replace_leaf, atom)

    def test_trs_leaf_keeps_source_and_terminal_only(self):
        old, new = self.migrate('trs', '<trsNonterminationProof><loop><rewriteSequence/></loop></trsNonterminationProof>')
        self.assertNotEqual(old, new)
        self.assertTrue(new.startswith('exact-trs-nontermination-terminal('))
        source, terminal = json.loads(bytes.fromhex(new.split('hex=')[1][:-1]))
        self.assertEqual(source, 'source-context')
        self.assertTrue(terminal.startswith('<loop>'))
        self.assertNotIn('NonterminationProof', terminal)

    def test_dp_leaf_becomes_existing_atomic_processor(self):
        _, new = self.migrate('dp', '<dpNonterminationProof><nonLoop/></dpNonterminationProof>')
        self.assertTrue(new.startswith('exact-dp-nonloop('))

    def test_never_relabels_preprocessing_as_terminal(self):
        for xml in ['<trsNonterminationProof><uncurry><trsNonterminationProof><loop/></trsNonterminationProof></uncurry></trsNonterminationProof>',
                    '<trsNonterminationProof><loop><dpNonterminationProof/></loop></trsNonterminationProof>']:
            old, new = self.migrate('trs', xml)
            self.assertEqual(old, new)


if __name__ == '__main__':
    unittest.main()
