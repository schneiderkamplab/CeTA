#!/usr/bin/env python3
"""Replace exact natural-Arctic models with certified DP deletion targets."""

from __future__ import annotations

import argparse
import hashlib
import json
from collections import Counter
from pathlib import Path
import xml.etree.ElementTree as ET

from build_credited_status_map_dataset import canonicalize_cpf_input, compact_xml_for_key


WITNESS_SCHEMA = "ferrum.utility-guidance.witness.v1"
GROUPS = ("avoid", "possible", "prefer", "timeout")
ARCTIC_MINUS_INFINITY = -(2**63)


def cpf_pairs(cpf: str) -> list[bytes]:
    root = ET.fromstring(cpf)
    result = []
    for rule in root.findall("./dps/rules/rule"):
        rule.tail = None
        result.append(ET.tostring(rule, encoding="utf-8"))
    return result


def deleted_indices(input_cpf: str, residual_cpf: str) -> list[int]:
    source = cpf_pairs(input_cpf)
    residual = Counter(cpf_pairs(residual_cpf))
    deleted = []
    for index, pair in enumerate(source):
        if residual[pair] > 0:
            residual[pair] -= 1
        else:
            deleted.append(index)
    if any(residual.values()) or not deleted:
        raise ValueError("residual DPs are not a strict input submultiset")
    return deleted


def decode_bounds(candidate: str) -> tuple[int, int, int, int, int]:
    prefix = "exact-arctic(hex="
    integer_domain, witness = json.loads(bytes.fromhex(candidate[len(prefix) : -1]))
    if integer_domain or not witness:
        raise ValueError("target extraction expects a nonempty natural-Arctic witness")
    dimensions = {len(constant) for _, constant, _ in witness}
    if len(dimensions) != 1:
        raise ValueError("inconsistent Arctic witness dimensions")
    constants = [value for _, constant, _ in witness for value in constant if value != ARCTIC_MINUS_INFINITY]
    coefficients = [
        value
        for _, _, arguments in witness
        for matrix in arguments
        for row in matrix
        for value in row
        if value != ARCTIC_MINUS_INFINITY
    ]
    return (
        dimensions.pop(),
        max(constants, default=0),
        max(coefficients, default=0),
        len(witness),
        max((len(arguments) for _, _, arguments in witness), default=0),
    )


def is_natural_arctic(candidate: str) -> bool:
    prefix = "exact-arctic(hex="
    integer_domain, _ = json.loads(bytes.fromhex(candidate[len(prefix) : -1]))
    return not integer_domain


def atom(bounds: tuple[int, int, int, int, int], target: list[int] | None) -> str:
    dimension, constant, coefficient, symbols, arity = bounds
    name = "arctic-target" if target is not None else "arctic-matrix"
    args = [
        f"dimension={dimension}",
        f"max-constant={constant}",
        f"max-coefficient={coefficient}",
        f"max-symbols={symbols}",
        f"max-arity={arity}",
    ]
    if target is not None:
        args.append("strict=" + "+".join(map(str, target)))
    return f"{name}({','.join(args)})"


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("input", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("--run-dir", type=Path, required=True)
    parser.add_argument("--events-jsonl", type=Path, action="append", default=[])
    parser.add_argument("--affected-roots-output", type=Path)
    args = parser.parse_args()

    rows = [json.loads(line) for line in args.input.open(encoding="utf-8")]
    definitions = {
        row["witness_id"]: row["candidate"]
        for row in rows
        if row.get("schema") == WITNESS_SCHEMA
        and row.get("candidate", "").startswith("exact-arctic(")
        and is_natural_arctic(row["candidate"])
    }
    bounds = {identifier: decode_bounds(candidate) for identifier, candidate in definitions.items()}
    candidate_ids = {candidate: identifier for identifier, candidate in definitions.items()}
    targets = {}
    affected_roots = set()
    selected_events = 0
    events = []
    for result_path in args.run_dir.rglob("result.json"):
        result = json.loads(result_path.read_text(encoding="utf-8"))
        if not result.get("certified"):
            continue
        events_path = result_path.parent / "processor-events.jsonl"
        if not events_path.exists():
            continue
        for line in events_path.open(encoding="utf-8"):
            events.append((result["path"], json.loads(line)))
    for events_path in args.events_jsonl:
        for line in events_path.open(encoding="utf-8"):
            event = json.loads(line)
            certification = event.get("certification") or {}
            if certification.get("status", "").startswith(("accepted", "certified")):
                events.append((event["problem_id"], event))

    for root, event in events:
            identifier = candidate_ids.get(event.get("processor", ""))
            if identifier is None:
                continue
            if event.get("level") != "dependency-pair":
                raise ValueError("retained natural-Arctic witness is not DP-local")
            residuals = (event.get("witness") or {}).get("residuals") or []
            if len(residuals) > 1:
                raise ValueError("Arctic event has multiple residuals")
            event_input = event["input"]
            canonical, error = canonicalize_cpf_input(event_input["cpf"])
            if error is not None:
                raise ValueError(f"cannot canonicalize selected DP state: {error}")
            keys = (
                event_input["problem_key"],
                hashlib.sha256(compact_xml_for_key(event_input["cpf"]).encode()).hexdigest(),
                hashlib.sha256(canonical.encode()).hexdigest(),
            )
            target = (
                deleted_indices(event_input["cpf"], residuals[0]["cpf"])
                if residuals
                else list(range(len(cpf_pairs(event_input["cpf"]))))
            )
            selected = atom(bounds[identifier], target)
            for key in keys:
                identity = (key, identifier)
                if identity in targets and targets[identity] != selected:
                    raise ValueError("one canonical state/witness has conflicting residuals")
                targets[identity] = selected
            affected_roots.add(root)
            selected_events += 1

    targeted = generic = 0
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with args.output.open("w", encoding="utf-8") as output:
        for row in rows:
            if row.get("schema") == WITNESS_SCHEMA and row.get("witness_id") in definitions:
                continue
            if row.get("schema") != WITNESS_SCHEMA:
                key = row.get("problem_key", "")
                for group in GROUPS:
                    retained = []
                    seen = set()
                    for evidence in row.get(group) or []:
                        reference = evidence.get("candidate_ref")
                        if reference in definitions:
                            candidate = targets.get((key, reference), atom(bounds[reference], None))
                            evidence = {
                                **{k: v for k, v in evidence.items() if k != "candidate_ref"},
                                "candidate": candidate,
                            }
                            targeted += candidate.startswith("arctic-target(")
                            generic += candidate.startswith("arctic-matrix(")
                        identity = (evidence.get("candidate"), evidence.get("candidate_ref"), evidence.get("status"))
                        if identity not in seen:
                            seen.add(identity)
                            retained.append(evidence)
                    if group in row or retained:
                        row[group] = retained
            print(json.dumps(row, separators=(",", ":"), sort_keys=True), file=output)

    if args.affected_roots_output is not None:
        args.affected_roots_output.write_text("\n".join(sorted(affected_roots)) + "\n", encoding="utf-8")
    print(json.dumps({
        "definitions_removed": len(definitions),
        "selected_events": selected_events,
        "targeted_state_replacements": targeted,
        "generic_replacements": generic,
        "affected_roots": len(affected_roots),
    }, sort_keys=True))


if __name__ == "__main__":
    main()
