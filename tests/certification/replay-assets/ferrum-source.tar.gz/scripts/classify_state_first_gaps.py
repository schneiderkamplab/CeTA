#!/usr/bin/env python3
"""Classify state-first campaign gaps by evidence rather than by root status."""

from __future__ import annotations

import argparse
from collections import Counter, defaultdict
import json
from pathlib import Path
import sqlite3


def family(atom: str) -> str:
    return atom.split("(", 1)[0]


def failure_class(certification: str, stdout: str, stderr: str) -> str:
    text = f"{certification}\n{stdout}\n{stderr}".lower()
    if "timeout" in text:
        return "checker-timeout-failure"
    if "parse" in text or "malformed" in text:
        return "ceta-parse-failure"
    if "unsupported" in text:
        return "unsupported-feature"
    if "stale" in text and "digest" in text:
        return "stale-digest-failure"
    if "context-invalid" in text or "validity" in text:
        return "processor-validity-failure"
    return "checker-rejected"


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--source-db", type=Path, required=True)
    parser.add_argument("--campaign-sqlite", type=Path, required=True)
    parser.add_argument(
        "--isolated-repeat-sqlite",
        type=Path,
        action="append",
        default=[],
        help="isolated-repeat ledgers used to confirm CPU-congestion gaps",
    )
    parser.add_argument("--state-hints", type=Path)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--summary", type=Path, required=True)
    args = parser.parse_args()

    hints: dict[str, list[str]] = {}
    if args.state_hints:
        for line in args.state_hints.read_text(encoding="utf-8").splitlines():
            if not line.strip():
                continue
            row = json.loads(line)
            atoms = [
                item.get("atom") if isinstance(item, dict) else item
                for item in row.get("suggested_atoms", [])
            ]
            hints[str(row.get("problem_key"))] = [
                atom for atom in atoms if isinstance(atom, str)
            ]

    source = sqlite3.connect(args.source_db)
    campaign = sqlite3.connect(args.campaign_sqlite)
    isolated_successes: set[tuple[str, str]] = set()
    for repeat_path in args.isolated_repeat_sqlite:
        with sqlite3.connect(repeat_path) as repeat:
            isolated_successes.update(
                repeat.execute(
                    """
                    SELECT problem_key, candidate FROM trials
                    WHERE state='completed'
                      AND outcome IN ('solved','transformed')
                      AND certification_status IN (
                        'certified-full','certified-fragment','assembly-required'
                      )
                    """
                )
            )
    rows: list[dict] = []
    counts: Counter[str] = Counter()
    for raw_hash, source_key, kind, level in campaign.execute(
        "SELECT raw_hash, source_problem_key, problem_kind, level FROM states"
    ):
        trial_columns = {
            row[1] for row in campaign.execute("PRAGMA table_info(trials)")
        }
        stdout_column = "COALESCE(stdout, '')" if "stdout" in trial_columns else "''"
        checker_stderr_column = (
            "COALESCE(ceta_stderr, '')"
            if "ceta_stderr" in trial_columns
            else "''"
        )
        trials = list(
            campaign.execute(
                f"""
                SELECT candidate, outcome, certification_status, timeout_ms,
                       {stdout_column}, {checker_stderr_column}
                FROM trials WHERE problem_key IN (?, ?)
                """,
                (raw_hash, source_key),
            )
        )
        external = hints.get(source_key, [])
        certified = [
            atom
            for atom, outcome, certification, *_ in trials
            if outcome in {"solved", "transformed"}
            and certification in {"certified-full", "certified-fragment"}
        ]
        checker_rejected = [
            (
                atom,
                failure_class(str(certification), str(stdout), str(stderr)),
            )
            for atom, outcome, certification, _, stdout, stderr in trials
            if outcome in {"solved", "transformed"}
            and certification
            not in {"certified-full", "certified-fragment", "assembly-required"}
        ]
        timed_out = [atom for atom, outcome, *_ in trials if outcome == "timeout"]
        transformed_open = [
            atom
            for atom, outcome, certification, *_ in trials
            if outcome == "transformed" and certification == "assembly-required"
        ]
        tried_families = {family(atom) for atom, *_ in trials}
        external_families = {family(atom) for atom in external}
        congestion_atoms = sorted(
            {
                atom
                for atom in timed_out
                if (raw_hash, atom) in isolated_successes
                or (source_key, atom) in isolated_successes
            }
        )
        if certified:
            classification = "covered"
        elif checker_rejected:
            classification = checker_rejected[0][1]
        elif congestion_atoms:
            classification = "cpu-congestion-confirmed"
        elif transformed_open:
            classification = "open-residual-reconstruction-chain"
        elif timed_out:
            classification = "local-timeout-or-parameter-range"
        elif any(atom.startswith(("external:", "unrepresentable:")) for atom in external):
            classification = "external-evidence-not-representable"
        elif external_families - tried_families:
            classification = "missing-processor-family-or-parameterization"
        elif external:
            classification = "wrong-sequencing-or-oracle-ranking"
        else:
            classification = "exhausted-search-no-known-evidence"
        counts[classification] += 1
        rows.append(
            {
                "classification": classification,
                "external_hints": external,
                "kind": kind,
                "level": level,
                "raw_hash": raw_hash,
                "source_problem_key": source_key,
                "certified_atoms": certified,
                "checker_rejected_atoms": [atom for atom, _ in checker_rejected],
                "checker_failure_classes": sorted(
                    {reason for _, reason in checker_rejected}
                ),
                "cpu_congestion_confirmed_atoms": congestion_atoms,
                "open_transform_atoms": transformed_open,
                "timed_out_atoms": timed_out,
                "untried_external_families": sorted(external_families - tried_families),
            }
        )
    source.close()
    campaign.close()
    rows.sort(key=lambda row: (row["classification"], row["raw_hash"]))
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with args.output.open("w", encoding="utf-8") as stream:
        for row in rows:
            stream.write(json.dumps(row, sort_keys=True, separators=(",", ":")) + "\n")
    summary = {
        "schema": "ferrum.state-first-gap-classification.v1",
        "states": len(rows),
        "classifications": dict(sorted(counts.items())),
        "output": str(args.output),
    }
    args.summary.write_text(json.dumps(summary, indent=2, sort_keys=True) + "\n")
    print(json.dumps(summary, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
