"""Produce a separate atomic-action profile; never alter the production oracle."""
import argparse
import hashlib
import json
from pathlib import Path
from export_native_replay_hints import atomic_candidate


def normalize(row, add_gm04=False):
    mapping = {}
    demoted = []
    for field in ('prefer', 'possible', 'avoid', 'timeout'):
        kept = []
        for item in row.get(field, []):
            old = item['candidate']
            atom = atomic_candidate(old)
            digest = hashlib.sha256(old.encode()).hexdigest()
            if atom is None:
                mapping[digest] = None
                continue
            mapping[digest] = hashlib.sha256(atom.encode()).hexdigest()
            if atom != old:
                item = {**item, 'candidate': atom, 'certified_count': 0,
                        'solved_count': 0, 'status': 'transformed_weak'}
                if field == 'prefer':
                    demoted.append(item)
                    continue
                if field in ('avoid', 'timeout'):
                    continue
            if not any(x['candidate'] == atom for x in kept):
                kept.append(item)
        row[field] = kept
    known = {item['candidate'] for item in row['possible']}
    row['possible'].extend(item for item in demoted if item['candidate'] not in known)
    if 'replay_order' in row:
        row['replay_order'] = list(dict.fromkeys(
            mapping.get(key, key) for key in row['replay_order']
            if mapping.get(key, key) is not None))
    if add_gm04 and any(item['candidate'].split('(', 1)[0] == 'path-order'
                        for field in ('prefer', 'possible') for item in row[field]):
        if not any(item['candidate'] == 'gm04-rpo'
                   for field in ('prefer', 'possible') for item in row[field]):
            row['possible'].append(dict(candidate='gm04-rpo', status='transformed_weak',
                utility_score=1.0, attempts=0, certified_count=0, solved_count=0,
                transformed_count=0, failed_count=0, timeout_count=0))
        key = hashlib.sha256(b'gm04-rpo').hexdigest()
        row['replay_order'] = [key] + [k for k in row.get('replay_order', []) if k != key]
    return row


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--input', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--gm04-rpo', action='store_true',
                        help='Try structurally checked GM04 RPO at path-order states')
    args = parser.parse_args()
    with args.input.open() as source, args.output.open('x') as target:
        for line in source:
            print(json.dumps(normalize(json.loads(line), args.gm04_rpo)), file=target)


if __name__ == '__main__':
    main()
