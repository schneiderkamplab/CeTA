#!/usr/bin/env python3
"""Build task-specific LLM datasets from proof-step rows."""

from __future__ import annotations

import argparse
import gzip
import json
from pathlib import Path
from typing import Any


def open_input(path: Path):
    return gzip.open(path, "rt", encoding="utf-8") if path.suffix == ".gz" else path.open("r", encoding="utf-8")


def open_output(path: Path):
    path.parent.mkdir(parents=True, exist_ok=True)
    return gzip.open(path, "wt", encoding="utf-8") if path.suffix == ".gz" else path.open("w", encoding="utf-8")


def compact_json(value: Any) -> str:
    return json.dumps(value, sort_keys=True, separators=(",", ":"))


def trust_rank(row: dict[str, Any]) -> str:
    trust = row.get("trust") or {}
    if trust.get("original_standardized_fragment_trust") == "certified_fragment":
        return "certified_nontrivial_standardized_fragment"
    if trust.get("canonical_fragment_trust") == "certified_fragment":
        return "certified_canonical_fragment"
    if trust.get("canonical_fragment_trust") == "fragment_ceta_failed":
        return "fragment_ceta_failed"
    return "complete_or_text_only"


def common_user_payload(row: dict[str, Any]) -> dict[str, Any]:
    inp = row.get("input") or {}
    return {
        "problem_xml": inp.get("problem_xml"),
        "local_context_xml": inp.get("local_context_xml"),
        "problem_features": inp.get("problem_features"),
        "available_processors": inp.get("available_processors"),
    }


def make_messages(task: str, row: dict[str, Any]) -> list[dict[str, str]]:
    target = row.get("target") or {}
    processor = target.get("processor")
    user_payload = common_user_payload(row)
    if task == "processor":
        instruction = "Choose the next termination proof processor for this CPF subproblem. Return JSON only."
        answer = {"processor": processor}
    elif task == "parameters":
        instruction = "Given the CPF subproblem and chosen processor, predict useful processor parameters or witness features. Return JSON only."
        user_payload["chosen_processor"] = processor
        answer = {"processor": processor, "parameters": target.get("parameters")}
    elif task == "witness":
        instruction = "Given the CPF subproblem and chosen processor, propose the checker-facing proof fragment. Return JSON only."
        user_payload["chosen_processor"] = processor
        user_payload["parameters"] = target.get("parameters")
        answer = {
            "processor": processor,
            "proof_suggestion_xml": target.get("proof_suggestion_xml"),
        }
    else:
        raise ValueError(f"unknown task {task}")
    return [
        {
            "role": "system",
            "content": (
                "You suggest TRS termination proof steps for Ferrum. "
                "Ferrum verifies every suggestion with internal checks and CeTA; do not include prose."
            ),
        },
        {"role": "user", "content": instruction + "\n" + compact_json(user_payload)},
        {"role": "assistant", "content": compact_json(answer)},
    ]


def make_example(task: str, row: dict[str, Any]) -> dict[str, Any]:
    return {
        "id": f"{task}:{row.get('id')}",
        "task": task,
        "messages": make_messages(task, row),
        "metadata": {
            "row_id": row.get("row_id"),
            "source_row_id": row.get("source_row_id"),
            "processor": (row.get("target") or {}).get("processor"),
            "trust": trust_rank(row),
            "category": (row.get("metadata") or {}).get("category"),
            "tool": (row.get("metadata") or {}).get("tool"),
            "year": (row.get("metadata") or {}).get("year"),
        },
    }


def keep_for_task(task: str, row: dict[str, Any], min_trust: str) -> bool:
    rank = trust_rank(row)
    if min_trust == "all":
        return True
    if min_trust == "canonical-certified":
        return rank in {"certified_nontrivial_standardized_fragment", "certified_canonical_fragment"}
    if min_trust == "nontrivial-certified":
        return rank == "certified_nontrivial_standardized_fragment"
    raise ValueError(f"unknown min trust {min_trust}")


def build_task(input_path: Path, output_path: Path, task: str, min_trust: str, limit: int | None, progress_interval: int) -> dict[str, Any]:
    rows = 0
    written = 0
    processors: dict[str, int] = {}
    trust_counts: dict[str, int] = {}
    with open_input(input_path) as source, open_output(output_path) as sink:
        for line in source:
            row = json.loads(line)
            rows += 1
            if not keep_for_task(task, row, min_trust):
                continue
            example = make_example(task, row)
            sink.write(compact_json(example) + "\n")
            written += 1
            proc = str(example["metadata"].get("processor") or "unknown")
            trust = str(example["metadata"].get("trust") or "unknown")
            processors[proc] = processors.get(proc, 0) + 1
            trust_counts[trust] = trust_counts.get(trust, 0) + 1
            if progress_interval > 0 and written % progress_interval == 0:
                print(
                    compact_json(
                        {
                            "event": "progress",
                            "task": task,
                            "input_rows_seen": rows,
                            "rows_written": written,
                            "processors": processors,
                            "trust": trust_counts,
                        }
                    ),
                    flush=True,
                )
            if limit is not None and written >= limit:
                break
    return {
        "task": task,
        "input": str(input_path),
        "output": str(output_path),
        "min_trust": min_trust,
        "input_rows_seen": rows,
        "rows_written": written,
        "processor_counts": dict(sorted(processors.items())),
        "trust_counts": dict(sorted(trust_counts.items())),
    }


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--input", type=Path, required=True)
    parser.add_argument("--out-dir", type=Path, required=True)
    parser.add_argument("--prefix", default="llm-task.smt-lex")
    parser.add_argument("--summary", type=Path, required=True)
    parser.add_argument("--processor-trust", choices=["all", "canonical-certified", "nontrivial-certified"], default="all")
    parser.add_argument("--parameters-trust", choices=["all", "canonical-certified", "nontrivial-certified"], default="nontrivial-certified")
    parser.add_argument("--witness-trust", choices=["all", "canonical-certified", "nontrivial-certified"], default="nontrivial-certified")
    parser.add_argument("--limit", type=int)
    parser.add_argument("--progress-interval", type=int, default=50000)
    args = parser.parse_args()

    args.out_dir.mkdir(parents=True, exist_ok=True)
    tasks = [
        ("processor", args.processor_trust),
        ("parameters", args.parameters_trust),
        ("witness", args.witness_trust),
    ]
    summaries = []
    for task, min_trust in tasks:
        output = args.out_dir / f"{args.prefix}.{task}.jsonl.gz"
        summaries.append(build_task(args.input, output, task, min_trust, args.limit, args.progress_interval))
    summary = {"input": str(args.input), "outputs": summaries}
    args.summary.write_text(json.dumps(summary, indent=2, sort_keys=True), encoding="utf-8")
    print(compact_json(summary), flush=True)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
