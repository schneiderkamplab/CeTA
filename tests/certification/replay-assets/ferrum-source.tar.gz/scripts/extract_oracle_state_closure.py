#!/usr/bin/env python3
"""Extract exact oracle records and their canonical-alias targets."""

from __future__ import annotations

import argparse
import json
from pathlib import Path
import sqlite3


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--oracle", type=Path, required=True)
    parser.add_argument("--keys", type=Path, required=True)
    parser.add_argument("--sqlite", type=Path, action="append", default=[])
    parser.add_argument("--aliases", type=Path, action="append", default=[])
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--report", type=Path, required=True)
    args = parser.parse_args()

    requested = {
        line.strip()
        for line in args.keys.read_text(encoding="utf-8").splitlines()
        if line.strip()
    }
    for database in args.sqlite:
        with sqlite3.connect(database) as connection:
            tables = {
                row[0]
                for row in connection.execute(
                    "SELECT name FROM sqlite_master WHERE type='table'"
                )
            }
            if "problems" in tables:
                requested.update(
                    row[0] for row in connection.execute("SELECT problem_key FROM problems")
                )
            if "problem_aliases" in tables:
                requested.update(
                    value
                    for row in connection.execute(
                        "SELECT raw_problem_key, problem_key FROM problem_aliases"
                    )
                    for value in row
                )
    for aliases in args.aliases:
        with aliases.open(encoding="utf-8") as stream:
            for line in stream:
                row = json.loads(line)
                requested.update(
                    value
                    for value in (
                        row.get("raw_key"),
                        row.get("canonical_problem_key"),
                    )
                    if isinstance(value, str)
                )
    records: dict[str, dict] = {}
    metadata_records = 0
    witnesses: dict[str, dict] = {}
    with args.oracle.open(encoding="utf-8") as stream:
        for line_number, line in enumerate(stream, 1):
            row = json.loads(line)
            key = row.get("problem_key")
            if not isinstance(key, str):
                # Monotone production oracles may begin with provenance and
                # schema records.  They are not state records and therefore
                # cannot participate in a key closure.
                metadata_records += 1
                witness_id = row.get("witness_id")
                if isinstance(witness_id, str):
                    witnesses[witness_id] = row
                continue
            if key in records:
                raise RuntimeError(f"duplicate oracle problem_key: {key}")
            records[key] = row

    closure = set(requested)
    while True:
        targets = {
            records[key].get("canonical_problem_key")
            for key in closure & records.keys()
            if isinstance(records[key].get("canonical_problem_key"), str)
        }
        expanded = closure | targets
        if expanded == closure:
            break
        closure = expanded

    selected = {key: records[key] for key in closure if key in records}
    referenced_witnesses = {
        item["candidate_ref"]
        for row in selected.values()
        for bucket in ("prefer", "possible", "avoid")
        for item in row.get(bucket, [])
        if isinstance(item, dict) and isinstance(item.get("candidate_ref"), str)
    }
    missing_witnesses = referenced_witnesses - witnesses.keys()
    if missing_witnesses:
        raise RuntimeError(
            "oracle closure refers to missing witnesses: "
            + ", ".join(sorted(missing_witnesses)[:10])
        )
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with args.output.open("w", encoding="utf-8") as stream:
        for witness_id in sorted(referenced_witnesses):
            stream.write(
                json.dumps(
                    witnesses[witness_id], sort_keys=True, separators=(",", ":")
                )
                + "\n"
            )
        for key in sorted(selected):
            stream.write(json.dumps(selected[key], sort_keys=True, separators=(",", ":")) + "\n")
    positives = sum(
        len(row.get(bucket, []))
        for row in selected.values()
        for bucket in ("prefer", "possible")
    )
    report = {
        "schema": "ferrum.oracle-state-closure-extract.v1",
        "oracle": str(args.oracle.resolve()),
        "requested_keys": len(requested),
        "matched_requested_keys": len(requested & records.keys()),
        "canonical_targets_added": len(closure - requested),
        "output_records": len(selected),
        "metadata_records_skipped": metadata_records,
        "witness_records_retained": len(referenced_witnesses),
        "positive_items": positives,
        "missing_keys": sorted(requested - records.keys()),
        "output": str(args.output.resolve()),
    }
    args.report.write_text(json.dumps(report, indent=2, sort_keys=True) + "\n")
    print(json.dumps(report, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
