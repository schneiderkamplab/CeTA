import json
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest


class TraceExtractionTests(unittest.TestCase):
    def test_exact_context_deduplication_and_no_overwrite(self):
        script = Path(__file__).with_name("extract_worklist_trace_inputs.py")
        xml = '<input><dpInput><dps><rules><rule/></rules></dps><trs><rules><rule/></rules></trs><usableRules><rules/></usableRules><q><rules><rule/></rules></q><minimal>false</minimal></dpInput></input>'
        with tempfile.TemporaryDirectory() as temporary:
            base = Path(temporary)
            trace = base / "trace.log"
            trace.write_text("irrelevant line\n" + ("worklist-input " + json.dumps(xml) + "\n") * 2)
            output = base / "states"
            command = [sys.executable, str(script), str(trace), str(output)]
            subprocess.run(command, check=True, capture_output=True)
            paths = (output / "inputs.txt").read_text().splitlines()
            self.assertEqual(len(paths), 1)
            self.assertEqual(Path(paths[0]).read_text(), xml)
            record = json.loads((output / "states.jsonl").read_text())
            self.assertFalse(record["certified"])
            self.assertEqual((record["pairs"], record["rules"], record["active_rules"]), (1, 1, 0))
            self.assertNotEqual(subprocess.run(command, capture_output=True).returncode, 0)
            self.assertEqual(Path(paths[0]).read_text(), xml)


if __name__ == "__main__":
    unittest.main()
