"""Diagnose native synthesis on inputs of previously certified modular actions.

No retained model is executed. Bounds/families are extracted, and probes are
diagnostic only: a transformed fragment is not a certified root recovery.
"""
import argparse
from collections import Counter
from concurrent.futures import ThreadPoolExecutor, as_completed
import hashlib
import json
import os
from pathlib import Path
import subprocess
import time
import xml.etree.ElementTree as ET

from export_native_frontier_hints import fit_signature
from materialize_processor_event_input import find_inline_cpf
from probe_witness_free_oracle import replace


def selected_atoms(events, per_family=1):
    seen = Counter()
    for index, event in enumerate(events):
        atom = event.get('strategy_atom') or event.get('processor', '')
        if event.get('outcome') not in ('solved', 'transformed') or not atom.startswith('exact-'):
            continue
        native = replace(atom)
        family = native.split('(', 1)[0] if native else atom.split('(', 1)[0]
        if family in {'dp', 'graph', 'size-change', 'subterm', 'usable-rules', 'innermost-lhss'}:
            continue
        key = (event.get('level'), family)
        if seen[key] >= per_family:
            continue
        seen[key] += 1
        state = (event.get('input') or {}).get('problem_key')
        found = find_inline_cpf(events, state)
        if found is None:
            raise ValueError(f'missing source input {state}')
        cpf = found[1]
        if hashlib.sha256(cpf.strip().encode()).hexdigest() != state:
            raise ValueError('source digest mismatch')
        if native:
            native = fit_signature(native, cpf)
            if ET.fromstring(cpf).tag == 'trsInput' and native == 'path-order':
                native = 'path-order(max-symbols=256)'
            if 'exact-' in native or 'hex=' in native or ';' in native:
                raise ValueError('non-native or composite diagnostic action')
        yield dict(event_index=index, problem_key=state, family=family,
                   source_family=atom.split('(', 1)[0], native=native, cpf=cpf)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--baseline', type=Path, required=True)
    parser.add_argument('--current', type=Path, required=True)
    parser.add_argument('--ferrum', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--jobs', type=int, default=8)
    parser.add_argument('--timeout', type=int, default=60)
    parser.add_argument('--per-family', type=int, default=1)
    parser.add_argument('--family', action='append', default=[],
                        help='Restrict diagnostic probes to these native families.')
    args = parser.parse_args()
    prior = {row['path']: row for row in json.loads(args.baseline.read_text()) if row.get('certified')}
    jobs = []
    for row in json.loads(args.current.read_text()):
        if row.get('certified'):
            continue
        events_path = Path(prior[row['path']]['artifact_dir']) / 'processor-events.jsonl'
        events = list(map(json.loads, events_path.read_text().splitlines()))
        for job in selected_atoms(events, args.per_family):
            if args.family and job['family'] not in args.family:
                continue
            jobs.append(dict(job, root=row['path'], source_events=str(events_path)))
    args.output.mkdir(parents=True, exist_ok=False)
    print(json.dumps(dict(probes=len(jobs), roots=len({j['root'] for j in jobs}))), flush=True)

    def run(job):
        identity = hashlib.sha256((job['root'] + str(job['event_index'])).encode()).hexdigest()
        directory = args.output / identity
        directory.mkdir()
        source = directory / 'input.cpf'
        source.write_text(job['cpf'])
        result = {k: v for k, v in job.items() if k != 'cpf'}
        result.update(artifact_dir=str(directory), certified=False, diagnostic_only=True)
        if not job['native']:
            return dict(result, outcome='missing-native-conversion')
        env = dict(os.environ, RAYON_NUM_THREADS='2',
                   FERRUM_PROGRESS_LOG=str(directory / 'progress.jsonl'))
        env.pop('FERRUM_DP_LLM_NO_FALLBACK', None)
        started = time.monotonic()
        try:
            proc = subprocess.run([str(args.ferrum.resolve()), 'probe-cpf', str(source),
                '--summary', '--strategy', job['native'], '--timeout-ms', str(args.timeout * 1000),
                '--processor-events', str(directory / 'processor-events.jsonl'),
                '--cpf', str(directory / 'fragment.cpf.xml')],
                capture_output=True, text=True, timeout=args.timeout + 5, env=env)
            (directory / 'stdout').write_text(proc.stdout)
            (directory / 'stderr').write_text(proc.stderr)
            try:
                summary = json.loads(proc.stdout)
            except ValueError:
                summary = dict(outcome='invalid-output')
            result.update(summary=summary, outcome=summary.get('typed_outcome', summary.get('outcome')),
                          returncode=proc.returncode)
        except subprocess.TimeoutExpired:
            result['outcome'] = 'harness-timeout'
        result['elapsed_seconds'] = time.monotonic() - started
        return result

    results = []
    with (args.output / 'results.jsonl').open('x') as out, ThreadPoolExecutor(max_workers=args.jobs) as pool:
        for future in as_completed([pool.submit(run, job) for job in jobs]):
            row = future.result()
            results.append(row)
            print(json.dumps(row), file=out, flush=True)
            print(json.dumps(dict(done=len(results), root=row['root'], family=row['family'],
                                  outcome=row['outcome'])), flush=True)
    (args.output / 'details.json').write_text(json.dumps(results, indent=2))


if __name__ == '__main__':
    main()
