import unittest
import json
from pathlib import Path
import tempfile
from audit_modular_child_equivalence import inverse_input_mapping, normalized_xml, streamed_children


class ChildEquivalenceTests(unittest.TestCase):
    def test_explicit_bijection_preserves_q_and_marking(self):
        a = '<dpInput><q><sharp><name>f</name></sharp><var>x</var></q><minimal>false</minimal></dpInput>'
        b = '<dpInput><q><sharp><name>g</name></sharp><var>y</var></q><minimal>false</minimal></dpInput>'
        inverse = inverse_input_mapping(a, b)
        self.assertIsNotNone(inverse)
        self.assertEqual(normalized_xml(a), normalized_xml(b, inverse))
        self.assertIsNone(inverse_input_mapping(a, b.replace('false', 'true')))

    def test_noninjective_renaming_rejected(self):
        a = '<x><name>f</name><name>g</name></x>'
        b = '<x><name>h</name><name>h</name></x>'
        self.assertIsNone(inverse_input_mapping(a, b))

    def test_every_context_field_is_retained(self):
        for tag in ('minimal', 'nfs', 'activeRulesAreResidual', 'ordinaryBridgeLosesMinimality'):
            a = f'<dpInput><{tag}>true</{tag}></dpInput>'
            self.assertNotEqual(normalized_xml(a), normalized_xml(a.replace('true', 'false')))
        for tag in ('q', 'weakDps', 'strictRules', 'graphRules', 'transformationRules'):
            a = f'<dpInput><{tag}><name>f</name></{tag}></dpInput>'
            self.assertNotEqual(normalized_xml(a), normalized_xml(a.replace('>f<', '>g<')))

    def test_map_entry_order_but_not_positions_is_irrelevant(self):
        x = '<replacementMapEntry><name>f</name><arity>1</arity><position>1</position></replacementMapEntry>'
        y = '<replacementMapEntry><name>g</name><arity>0</arity></replacementMapEntry>'
        a = '<contextSensitive>' + x + y + '</contextSensitive>'
        b = '<contextSensitive>' + y + x + '</contextSensitive>'
        self.assertEqual(normalized_xml(a), normalized_xml(b))
        self.assertNotEqual(normalized_xml(a), normalized_xml(b.replace('<position>1</position>', '')))
        with self.assertRaises(ValueError):
            normalized_xml('<contextSensitive>' + x + x + '</contextSensitive>')

    def test_stream_checks_count_and_reads_only_child_records(self):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / 'report.json'
            children = [{'cpf': '<dpInput/>', 'context': {'minimal': True}}, {'cpf': '<trsInput/>'}]
            path.write_text(json.dumps({'children': children, 'details': {'children': children}}))
            self.assertEqual(list(streamed_children(path, 2)), children)
            with self.assertRaises(ValueError):
                list(streamed_children(path, 1))

    def test_rule_alpha_renaming_preserves_sharing(self):
        a = '<rule><funapp><name>f</name><var>x</var><var>x</var></funapp><var>x</var></rule>'
        self.assertEqual(normalized_xml(a), normalized_xml(a.replace('>x<', '>fresh_name<')))
        self.assertNotEqual(normalized_xml(a), normalized_xml(a.replace('>x<', '>different<', 1)))


if __name__ == '__main__':
    unittest.main()
