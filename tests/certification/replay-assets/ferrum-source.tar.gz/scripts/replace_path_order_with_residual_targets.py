#!/usr/bin/env python3
"""Replace exact DP path-order models with certified target deletion sets."""

from __future__ import annotations

import argparse
import hashlib
import json
from collections import Counter
from pathlib import Path
import xml.etree.ElementTree as ET

from build_credited_status_map_dataset import canonicalize_cpf_input, compact_xml_for_key


WITNESS_SCHEMA = "ferrum.utility-guidance.witness.v1"
GROUPS = ("avoid", "possible", "prefer", "timeout")


def cpf_rules(cpf: str, section: str) -> list[bytes]:
    root = ET.fromstring(cpf)
    rules = root.findall(f"./{section}/rules/rule")
    canonical = []
    for rule in rules:
        # ElementTree includes indentation after </rule> in ``tail``.  The
        # input and residual CPFs can use different indentation even though
        # their rule terms are identical, so exclude this non-semantic text.
        rule.tail = None
        canonical.append(ET.tostring(rule, encoding="utf-8"))
    return canonical


def deleted_pair_indices(input_cpf: str, residual_cpf: str) -> list[int]:
    source = cpf_rules(input_cpf, "dps")
    residual = Counter(cpf_rules(residual_cpf, "dps"))
    deleted = []
    for index, rule in enumerate(source):
        if residual[rule] > 0:
            residual[rule] -= 1
        else:
            deleted.append(index)
    if any(residual.values()) or not deleted:
        raise ValueError("residual DP rules are not a strict submultiset of the input")
    return deleted


def target_atom(indices: list[int]) -> str:
    return "path-order-target(strict=" + "+".join(map(str, indices)) + ")"


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("input", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("--run-dir", type=Path, required=True)
    parser.add_argument("--affected-roots-output", type=Path)
    args = parser.parse_args()

    rows = [json.loads(line) for line in args.input.open(encoding="utf-8")]
    definitions = {
        row["witness_id"]: row["candidate"]
        for row in rows
        if row.get("schema") == WITNESS_SCHEMA
        and row.get("candidate", "").startswith("exact-path-order(")
    }
    candidate_ids = {candidate: identifier for identifier, candidate in definitions.items()}

    certified_dirs = {
        result.parent
        for result in args.run_dir.rglob("result.json")
        if json.loads(result.read_text(encoding="utf-8")).get("certified")
    }
    targets: dict[tuple[str, str], str] = {}
    affected_roots = set()
    selected_events = 0
    for artifact_dir in certified_dirs:
        events_path = artifact_dir / "processor-events.jsonl"
        if not events_path.exists():
            continue
        result = json.loads((artifact_dir / "result.json").read_text(encoding="utf-8"))
        for line in events_path.open(encoding="utf-8"):
            event = json.loads(line)
            candidate = event.get("processor", "")
            identifier = candidate_ids.get(candidate)
            if identifier is None:
                continue
            if event.get("level") != "dependency-pair":
                raise ValueError("a retained exact path-order witness is not DP-local")
            residuals = (event.get("witness") or {}).get("residuals") or []
            if len(residuals) != 1:
                raise ValueError("path-order event does not have exactly one residual")
            event_input = event.get("input") or {}
            problem_key = event_input.get("problem_key")
            if not problem_key:
                raise ValueError("path-order event has no input problem key")
            canonical_cpf, error = canonicalize_cpf_input(event_input["cpf"])
            if error is not None:
                raise ValueError(f"cannot canonicalize selected DP state: {error}")
            canonical_key = hashlib.sha256(canonical_cpf.encode("utf-8")).hexdigest()
            structural_key = hashlib.sha256(
                compact_xml_for_key(event_input["cpf"]).encode("utf-8")
            ).hexdigest()
            atom = target_atom(
                deleted_pair_indices(event_input["cpf"], residuals[0]["cpf"])
            )
            for state_key in (problem_key, structural_key, canonical_key):
                key = (state_key, identifier)
                if key in targets and targets[key] != atom:
                    raise ValueError(
                        "one canonical state/witness pair has conflicting certified residuals"
                    )
                targets[key] = atom
            affected_roots.add(result["path"])
            selected_events += 1

    replaced_targeted = 0
    replaced_generic = 0
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with args.output.open("w", encoding="utf-8") as output:
        for row in rows:
            if row.get("schema") == WITNESS_SCHEMA and row.get("witness_id") in definitions:
                continue
            if row.get("schema") != WITNESS_SCHEMA:
                problem_key = row.get("problem_key", "")
                for group in GROUPS:
                    retained = []
                    seen = set()
                    for evidence in row.get(group) or []:
                        reference = evidence.get("candidate_ref")
                        if reference in definitions:
                            candidate = targets.get((problem_key, reference), "path-order")
                            evidence = {
                                **{
                                    key: value
                                    for key, value in evidence.items()
                                    if key != "candidate_ref"
                                },
                                "candidate": candidate,
                            }
                            if candidate == "path-order":
                                replaced_generic += 1
                            else:
                                replaced_targeted += 1
                        identity = (
                            evidence.get("candidate"),
                            evidence.get("candidate_ref"),
                            evidence.get("status"),
                        )
                        if identity not in seen:
                            seen.add(identity)
                            retained.append(evidence)
                    if group in row or retained:
                        row[group] = retained
            print(json.dumps(row, separators=(",", ":"), sort_keys=True), file=output)

    if args.affected_roots_output is not None:
        args.affected_roots_output.parent.mkdir(parents=True, exist_ok=True)
        args.affected_roots_output.write_text(
            "\n".join(sorted(affected_roots)) + ("\n" if affected_roots else ""),
            encoding="utf-8",
        )
    print(
        json.dumps(
            {
                "definitions_removed": len(definitions),
                "selected_events": selected_events,
                "targeted_state_replacements": replaced_targeted,
                "generic_replacements": replaced_generic,
                "target_atoms": len(set(targets.values())),
                "affected_roots": len(affected_roots),
            },
            sort_keys=True,
        )
    )


if __name__ == "__main__":
    main()
