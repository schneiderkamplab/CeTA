#!/usr/bin/env python3
"""Deterministically check every retained CPF in a run directory twice."""

from __future__ import annotations

import argparse
import concurrent.futures
import json
import subprocess
from pathlib import Path


def check(ceta: Path, root: Path, cpf: Path) -> tuple[str, str, int]:
    relative = str(cpf.relative_to(root))
    for _round in range(2):
        result = subprocess.run(
            [str(ceta), str(cpf)], text=True, capture_output=True
        )
        if result.returncode != 0 or "CERTIFIED" not in result.stdout:
            detail = (result.stdout + result.stderr).strip().replace("\n", " ")
            return "FAIL", f"{relative}\t{detail}", _round + 1
    return "PASS", relative, 2


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--ceta", type=Path, required=True)
    parser.add_argument("--root", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--jobs", type=int, default=16)
    parser.add_argument(
        "--certified-details",
        type=Path,
        help="when supplied, audit only artifact directories marked certified",
    )
    args = parser.parse_args()

    if args.certified_details:
        details = json.loads(args.certified_details.read_text(encoding="utf-8"))
        cpfs = sorted(
            Path(row["artifact_dir"]) / "proof.cpf.xml"
            for row in details
            if row.get("certified")
        )
    else:
        # Nested TermCOMP runs use ``proof.cpf.xml`` while the isolated event
        # collector writes one flat ``<problem>.cpf.xml`` per root.  Both are
        # complete retained certificates and must pass the same twice-per-CPF
        # audit; limiting discovery to the nested spelling silently skipped
        # every proof in newer flat campaign directories.
        cpfs = sorted(
            {
                *args.root.rglob("proof.cpf.xml"),
                *args.root.rglob("*.cpf.xml"),
            }
        )
    if not cpfs:
        raise SystemExit(f"no proof.cpf.xml files below {args.root}")
    with concurrent.futures.ThreadPoolExecutor(max_workers=args.jobs) as pool:
        results = list(pool.map(lambda cpf: check(args.ceta, args.root, cpf), cpfs))
    args.output.mkdir(parents=True, exist_ok=True)
    result_path = args.output / "results.tsv"
    result_path.write_text(
        "".join(f"{status}\t{detail}\n" for status, detail, _count in results),
        encoding="utf-8",
    )
    failures = sum(status != "PASS" for status, _detail, _count in results)
    invocations = sum(count for _status, _detail, count in results)
    summary = (
        f"proofs={len(cpfs)} twice_certified={len(cpfs) - failures} "
        f"checker_invocations={invocations} failures={failures}\n"
    )
    (args.output / "summary.txt").write_text(summary, encoding="utf-8")
    print(summary, end="")
    return int(failures != 0)


if __name__ == "__main__":
    raise SystemExit(main())
