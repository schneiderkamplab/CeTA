#!/usr/bin/env python3
"""Convert Ferrum chat-template SFT rows to HRM-Text direct JSONL.

HRM-Text's older direct data format uses one JSON object per row:

    {"condition": "direct", "instruction": "...", "response": "..."}

This script extracts the CPF ``problem_xml`` from the user message and the
processor label from the assistant answer in Ferrum SFT ``messages`` rows, then
writes that direct schema. The HRM instruction is deliberately only the raw
CPF/XML input, with no system prompt, task prompt, or JSON feature wrapper. The
response is deliberately only the bare processor name.
"""

from __future__ import annotations

import argparse
import gzip
import json
import re
from pathlib import Path
from typing import Any


def open_input(path: Path):
    return gzip.open(path, "rt", encoding="utf-8") if path.suffix == ".gz" else path.open("r", encoding="utf-8")


def open_output(path: Path):
    path.parent.mkdir(parents=True, exist_ok=True)
    return gzip.open(path, "wt", encoding="utf-8") if path.suffix == ".gz" else path.open("w", encoding="utf-8")


def compact_json(value: Any) -> str:
    return json.dumps(value, sort_keys=True, separators=(",", ":"))


PROBLEM_XML_RE = re.compile(r'\\"problem_xml\\":\\"((?:\\\\.|[^\\"])*)\\"')


def decode_json_string_payload(payload: str) -> str | None:
    try:
        return json.loads('"' + payload + '"')
    except json.JSONDecodeError:
        return None


def extract_processor_name(content: str) -> str | None:
    content = content.strip()
    if not content:
        return None
    try:
        payload = json.loads(content)
    except json.JSONDecodeError:
        return content
    if isinstance(payload, dict):
        processor = payload.get("processor")
        if isinstance(processor, str) and processor.strip():
            return processor.strip()
    if isinstance(payload, str) and payload.strip():
        return payload.strip()
    return None


def extract_json_string_after(line: str, start: int) -> tuple[str, int] | None:
    pos = start
    pieces = []
    while pos < len(line):
        ch = line[pos]
        if ch == '"':
            return "".join(pieces), pos + 1
        if ch == "\\":
            if pos + 1 >= len(line):
                return None
            pieces.append(line[pos:pos + 2])
            pos += 2
            continue
        pieces.append(ch)
        pos += 1
    return None


def extract_assistant_content(line: str) -> str | None:
    role_marker = '"role":"assistant"'
    content_marker = '"content":"'
    role_pos = line.find(role_marker)
    if role_pos < 0:
        return None
    object_start = line.rfind("{", 0, role_pos)
    object_end = line.find("}", role_pos)
    if object_start < 0 or object_end < 0:
        return None
    content_pos = line.find(content_marker, object_start, object_end)
    if content_pos < 0:
        return None
    payload_start = content_pos + len(content_marker)
    extracted = extract_json_string_after(line, payload_start)
    if extracted is None:
        return None
    return decode_json_string_payload(extracted[0])


def extract_direct_fast(line: str, condition: str) -> dict[str, str] | None:
    problem_match = PROBLEM_XML_RE.search(line)
    if problem_match is None:
        return None
    instruction = decode_json_string_payload(problem_match.group(1))
    response_content = extract_assistant_content(line)
    response = extract_processor_name(response_content) if response_content is not None else None
    if not instruction or not response:
        return None
    return {"condition": condition, "instruction": instruction.strip(), "response": response.strip()}


def extract_problem_xml(content: str) -> str | None:
    json_start = content.find("{")
    if json_start < 0:
        return None
    try:
        payload = json.loads(content[json_start:])
    except json.JSONDecodeError:
        return None
    if not isinstance(payload, dict):
        return None
    problem_xml = payload.get("problem_xml")
    if isinstance(problem_xml, str) and problem_xml.strip():
        return problem_xml.strip()
    return None


def extract_direct(row: dict[str, Any], condition: str) -> dict[str, str] | None:
    messages = row.get("messages")
    if not isinstance(messages, list):
        return None
    instruction = None
    assistant_parts = []
    for message in messages:
        if not isinstance(message, dict):
            continue
        role = message.get("role")
        content = message.get("content")
        if not isinstance(content, str):
            continue
        if role == "user" and instruction is None:
            instruction = extract_problem_xml(content)
        elif role == "assistant":
            assistant_parts.append(content.strip())
    response = "\n\n".join(part for part in assistant_parts if part)
    processor = extract_processor_name(response)
    if not instruction or not processor:
        return None
    return {"condition": condition, "instruction": instruction, "response": processor}


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--input", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--summary", type=Path, required=True)
    parser.add_argument("--condition", default="direct")
    parser.add_argument("--limit", type=int)
    parser.add_argument("--progress-interval", type=int, default=50000)
    args = parser.parse_args()

    rows = 0
    written = 0
    skipped = 0
    with open_input(args.input) as source, open_output(args.output) as sink:
        for line in source:
            rows += 1
            direct = extract_direct_fast(line, args.condition)
            if direct is None:
                row = json.loads(line)
                direct = extract_direct(row, args.condition)
            if direct is None:
                skipped += 1
            else:
                sink.write(compact_json(direct) + "\n")
                written += 1
            if args.progress_interval > 0 and rows % args.progress_interval == 0:
                print(compact_json({"event": "progress", "rows": rows, "written": written, "skipped": skipped}), flush=True)
            if args.limit is not None and rows >= args.limit:
                break

    summary = {
        "input": str(args.input),
        "output": str(args.output),
        "condition": args.condition,
        "rows": rows,
        "written": written,
        "skipped": skipped,
        "format": {"condition": "direct", "instruction": "string", "response": "string"},
    }
    args.summary.write_text(json.dumps(summary, indent=2, sort_keys=True), encoding="utf-8")
    print(compact_json(summary), flush=True)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
