import hashlib
import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

from materialize_event_children import main


class MaterializeChildrenTests(unittest.TestCase):
    def run_events(self, root, events, extra=()):
        source = root / 'events.jsonl'
        source.write_text('\n'.join(map(json.dumps, events)))
        output = root / 'children'
        with patch('sys.argv', ['materialize', '--events', str(source), '--problem', 'parent',
                               '--output', str(output), *extra]):
            main()
        return output

    def event(self, cpf, key=None, processor='graph', problem='parent'):
        return dict(problem_id=problem, outcome='transformed', processor=processor,
                    input=dict(problem_key='parent-key'),
                    witness=dict(residuals=[dict(cpf=cpf, problem_key=key or
                        hashlib.sha256(cpf.strip().encode()).hexdigest())]))

    def test_typed_payload_and_all_origins_are_preserved_without_credit(self):
        cpf = '<dpInput><strategy><innermostLhss><nfs>false</nfs></innermostLhss></strategy><minimal>false</minimal></dpInput>'
        with tempfile.TemporaryDirectory() as temporary:
            output = self.run_events(Path(temporary), [self.event(cpf), self.event(cpf, processor='rewrite')])
            rows = json.loads((output / 'inventory.json').read_text())['records']
            self.assertEqual(len(rows), 1)
            self.assertFalse(rows[0]['certified'])
            self.assertEqual(len(rows[0]['origins']), 2)
            self.assertEqual(Path(rows[0]['input']).read_text(), cpf)

    def test_stale_digest_is_rejected(self):
        with tempfile.TemporaryDirectory() as temporary:
            with self.assertRaisesRegex(ValueError, 'digest mismatch'):
                self.run_events(Path(temporary), [self.event('<dpInput/>', key='stale')])

    def test_other_roots_are_not_collected(self):
        with tempfile.TemporaryDirectory() as temporary:
            output = self.run_events(Path(temporary), [self.event('<dpInput/>', problem='another')])
            self.assertEqual(json.loads((output / 'inventory.json').read_text())['records'], [])

    def test_unguided_children_are_explicit_opt_in_not_failed_positive_credit(self):
        event = self.event('<dpInput/>')
        event.update(outcome='failed', failure_reason='strict oracle transformation produced an unguided residual')
        with tempfile.TemporaryDirectory() as temporary:
            output = self.run_events(Path(temporary), [event])
            self.assertEqual(json.loads((output / 'inventory.json').read_text())['records'], [])
        with tempfile.TemporaryDirectory() as temporary:
            rejected = dict(event, failure_reason='checker rejected')
            output = self.run_events(Path(temporary), [event, rejected], ['--include-unguided'])
            rows = json.loads((output / 'inventory.json').read_text())['records']
            self.assertEqual(len(rows), 1)
            self.assertFalse(rows[0]['certified'])


if __name__ == '__main__':
    unittest.main()
