#!/usr/bin/env python3
"""Certify local terminal alternatives over completed direct-recovery shards."""
import argparse
from concurrent.futures import ThreadPoolExecutor, as_completed
import json
from pathlib import Path
import subprocess
import sys


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--shards', type=Path, required=True)
    p.add_argument('--output', type=Path, required=True)
    p.add_argument('--ferrum', required=True)
    p.add_argument('--ceta', required=True)
    p.add_argument('--jobs', type=int, default=4)
    args = p.parse_args()
    args.output.mkdir(parents=True, exist_ok=False)
    rows = [json.loads(line) for line in (args.shards/'results.jsonl').open()]
    rows = [row for row in rows if row['returncode'] == 0]
    def run(task):
        index, row = task
        output = args.output/str(index)
        with (args.output/f'{index}.log').open('x') as log:
            result = subprocess.run([sys.executable, 'scripts/certify_modular_terminals.py',
                '--root', str(Path(row['output'])/'steps'), '--output', str(output),
                '--ferrum', args.ferrum, '--ceta', args.ceta, '--jobs', '2',
                '--include-open-terminals', '--candidate', 'size-change',
                '--candidate', 'subterm', '--candidate', 'graph'],
                stdout=log, stderr=subprocess.STDOUT, timeout=600)
        return dict(path=row['path'], output=str(output), returncode=result.returncode)
    with ThreadPoolExecutor(max_workers=args.jobs) as pool, (args.output/'results.jsonl').open('x') as log:
        for future in as_completed([pool.submit(run, task) for task in enumerate(rows)]):
            print(json.dumps(future.result()), file=log, flush=True)


if __name__ == '__main__':
    main()
