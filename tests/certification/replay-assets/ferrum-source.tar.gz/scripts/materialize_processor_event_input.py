#!/usr/bin/env python3
"""Materialize one content-addressed input from a processor-event stream."""

from __future__ import annotations

import argparse
import json
from pathlib import Path
from typing import Any, Iterable


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("--events", type=Path, required=True)
    parser.add_argument("--problem-key", required=True)
    parser.add_argument("--output", type=Path, required=True)
    return parser.parse_args()


def find_inline_cpf(
    events: Iterable[dict[str, Any]], problem_key: str
) -> tuple[int, str] | None:
    """Return the first inline input or residual CPF for ``problem_key``."""
    for line_number, event in enumerate(events, 1):
        candidates = [event.get("input") or {}]
        candidates.extend((event.get("witness") or {}).get("residuals") or [])
        for candidate in candidates:
            if candidate.get("problem_key") != problem_key:
                continue
            cpf = candidate.get("cpf")
            if isinstance(cpf, str):
                return line_number, cpf
    return None


def main() -> None:
    args = parse_args()
    with args.events.open(encoding="utf-8") as stream:
        found = find_inline_cpf((json.loads(line) for line in stream), args.problem_key)
    if found is not None:
        line_number, cpf = found
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(cpf, encoding="utf-8")
        print(
            f"materialized {args.problem_key} from line {line_number} "
            f"to {args.output}"
        )
        return
    raise SystemExit(f"no inline CPF found for problem key {args.problem_key}")


if __name__ == "__main__":
    main()
