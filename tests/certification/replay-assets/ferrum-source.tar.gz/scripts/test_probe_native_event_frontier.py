import hashlib
import json
import unittest
import contextlib
import io
import tempfile
from pathlib import Path
from unittest.mock import patch
from types import SimpleNamespace
from probe_native_event_frontier import native_recipe, unresolved_states, tried_recipes, native_atoms, recipe_from_atoms, typed_frontier, native_top_recipe, certified_state_keys


class FrontierTests(unittest.TestCase):
    def test_closed_state_filter_requires_two_checker_passes(self):
        check = dict(returncode=0, stdout='CERTIFIED\n')
        good = dict(key='closed', certified=True, status='yes', checks=[check, check])
        rows = [good, dict(good, key='one', checks=[check]),
                dict(good, key='rejected', checks=[check, dict(returncode=1, stdout='CERTIFIED\n')]),
                dict(good, key='substring', checks=[check, dict(returncode=0, stdout='NOT CERTIFIED\n')]),
                dict(good, key='unknown', status='unknown'),
                dict(good, key='raw', certified=False)]
        self.assertEqual(certified_state_keys(rows), {'closed'})

    def test_native_residual_normalization_and_uncurrying_are_not_dropped(self):
        families = ['alpha-merge', 'uncurry', 'uncurry-below', 'switch-to-trs']
        events = [dict(processor=f, outcome='transformed') for f in families]
        atoms = native_atoms(events)
        for family in families:
            self.assertIn(family, atoms)
            self.assertIn(family, native_recipe([], additional_atoms=[family]))

    def test_innermost_switch_is_retained_before_conditional_search(self):
        events = [dict(processor='switch-innermost', outcome='transformed'),
                  dict(processor='conditional-poly', outcome='solved')]
        atoms = native_atoms(events)
        self.assertIn('switch-innermost', atoms)
        self.assertLess(atoms.index('switch-innermost'), atoms.index('conditional-poly'))
        self.assertIn('switch-innermost', native_recipe([], additional_atoms=['switch-innermost']))

    def test_trs_frontier_does_not_mix_dp_contexts(self):
        def event(cpf):
            return dict(processor='empty', outcome='failed', input=dict(
                cpf=cpf, problem_key=hashlib.sha256(cpf.encode()).hexdigest()))
        trs = '<trsInput><trs><rules/></trs></trsInput>'
        dp = '<dpInput><dps><rules/></dps></dpInput>'
        events = [event(trs), event(dp)]
        self.assertEqual([v[1] for v in typed_frontier(events, 'trs', True).values()], [trs])
        self.assertEqual([v[1] for v in typed_frontier(events, 'dp', True).values()], [dp])
        with self.assertRaises(ValueError):
            typed_frontier(events, 'unknown')

    def test_trs_discovery_recipe_rejects_supplied_proofs(self):
        recipe = 'path-order(shared=1); matrix(dimension=2)'
        self.assertEqual(native_top_recipe(recipe), recipe)
        for forbidden in [None, '', 'exact-trs-proof(hex=00)', 'poly(hex=00)']:
            with self.assertRaises(ValueError):
                native_top_recipe(forbidden)

    def test_additional_searches_can_precede_historical_bounds(self):
        events = [dict(processor='poly', outcome='solved')]
        recipe = native_recipe(events, additional_atoms=['path-order(status=rpo,optimize=0)'],
                               additional_first=True)
        self.assertTrue(recipe.startswith('graph | size-change | subterm | '))
        self.assertLess(recipe.index('path-order'), recipe.index('poly'))

    def test_reused_native_atoms_are_immutable_and_match_event_conversion(self):
        events = [dict(processor='poly', outcome='solved')]
        atoms = native_atoms(events)
        original = list(atoms)
        self.assertEqual(recipe_from_atoms(atoms, additional_atoms=['matrix']),
                         native_recipe(events, additional_atoms=['matrix']))
        self.assertEqual(atoms, original)
        self.assertEqual(recipe_from_atoms(atoms), native_recipe(events))

    def test_state_limit_applies_after_skipping_previous_trials(self):
        from probe_native_event_frontier import main
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            old, current = root / 'old', root / 'current'
            old.mkdir()
            current.mkdir()
            source_events = [dict(processor='poly', outcome='solved')]
            (old / 'processor-events.jsonl').write_text(json.dumps(source_events[0]) + '\n')
            events = []
            for name in ('first', 'second'):
                cpf = f'<dpInput><dps><rules><rule/></rules></dps><name>{name}</name></dpInput>'
                events.append(dict(processor='utility-guidance', outcome='failed',
                                   input=dict(cpf=cpf, problem_key=hashlib.sha256(cpf.encode()).hexdigest())))
            (current / 'processor-events.jsonl').write_text('\n'.join(map(json.dumps, events)))
            for name, directory in [('baseline', old), ('current', current)]:
                (root / (name + '.json')).write_text(json.dumps([dict(path='root.ari', artifact_dir=str(directory), certified=False)]))
            current_rows = json.loads((root / 'current.json').read_text())
            current_rows.append(dict(path='outside-selected-baseline.ari', artifact_dir='must-not-open', certified=False))
            (root / 'current.json').write_text(json.dumps(current_rows))
            (root / 'tried').write_text(json.dumps([dict(key=events[0]['input']['problem_key'],
                recipe=native_recipe(source_events, events[0]['input']['cpf']), status='unknown')]))
            argv = ['probe', '--baseline', str(root / 'baseline.json'), '--current', str(root / 'current.json'),
                    '--ferrum', str(root / 'ferrum'), '--ceta', str(root / 'ceta'),
                    '--output', str(root / 'output'), '--states-per-root', '1', '--skip-details', str(root / 'tried')]
            with patch('sys.argv', argv), patch('probe_native_event_frontier.subprocess.run',
                return_value=SimpleNamespace(returncode=0)), contextlib.redirect_stdout(io.StringIO()):
                main()
            rows = json.loads((root / 'output/details.json').read_text())
            self.assertEqual([r['key'] for r in rows], [events[1]['input']['problem_key']])
            # A certified state stays closed even with a different recipe and
            # a larger time allowance; it must not consume the frontier cap.
            (root / 'closed').write_text(json.dumps([dict(key=events[0]['input']['problem_key'],
                recipe='different', status='yes', certified=True, probe_timeout_seconds=1,
                checks=[dict(returncode=0, stdout='CERTIFIED\n')] * 2)]))
            argv[argv.index(str(root / 'output'))] = str(root / 'output-closed')
            argv[-2:] = ['--skip-certified-details', str(root / 'closed')]
            with patch('sys.argv', argv), patch('probe_native_event_frontier.subprocess.run',
                return_value=SimpleNamespace(returncode=0)), contextlib.redirect_stdout(io.StringIO()):
                main()
            rows = json.loads((root / 'output-closed/details.json').read_text())
            self.assertEqual([r['key'] for r in rows], [events[1]['input']['problem_key']])
            # Multiple local manifests for one original root share its cap.
            # Otherwise each duplicate manifest could add another full batch.
            second = root / 'second'
            second.mkdir()
            cpf = '<dpInput><dps><rules><rule/></rules></dps><name>third</name></dpInput>'
            event = dict(processor='utility-guidance', outcome='failed',
                         input=dict(cpf=cpf, problem_key=hashlib.sha256(cpf.encode()).hexdigest()))
            (second / 'processor-events.jsonl').write_text(json.dumps(event) + '\n')
            current_rows.append(dict(path='root.ari', artifact_dir=str(second), certified=False))
            (root / 'current.json').write_text(json.dumps(current_rows))
            argv[argv.index(str(root / 'output-closed'))] = str(root / 'output-cap')
            with patch('sys.argv', argv), patch('probe_native_event_frontier.subprocess.run',
                return_value=SimpleNamespace(returncode=0)), contextlib.redirect_stdout(io.StringIO()):
                main()
            rows = json.loads((root / 'output-cap/details.json').read_text())
            self.assertEqual([r['key'] for r in rows], [events[1]['input']['problem_key']])

    def test_prior_trials_do_not_suppress_escalation_or_error_retries(self):
        rows = [dict(key='state', recipe='poly', status='unknown', probe_timeout_seconds=90),
                dict(key='other', recipe='matrix', status='error', probe_timeout_seconds=90)]
        self.assertEqual(tried_recipes(rows, 90), {('state', 'poly')})
        self.assertEqual(tried_recipes(rows, 180), set())

    def test_broader_probe_accepts_parameters_but_not_retained_models(self):
        atom = 'matrix(dim=2,max-coefficient=2)'
        recipe = native_recipe([], additional_atoms=[atom, atom])
        self.assertEqual(recipe.count(atom), 1)
        for invalid in ('exact-matrix(hex=00)', 'matrix(hex=00)',
                        'poly; graph', 'poly | matrix', 'unknown'):
            with self.assertRaises(ValueError):
                native_recipe([], additional_atoms=[invalid])

    def test_top_level_no_hint_becomes_separate_native_dp_searches(self):
        recipe = native_recipe([dict(processor='nontermination', outcome='solved')])
        self.assertIn('nontermination(dp-loop)', recipe)
        self.assertIn('nontermination(dp-nonloop)', recipe)

    def test_size_change_budget_is_explicit_and_local(self):
        events = [dict(processor='poly', outcome='transformed')]
        self.assertEqual(native_recipe(events, size_change_timeout=2),
                         native_recipe(events).replace('size-change', 'timeout(2s, size-change)'))
        with self.assertRaises(ValueError):
            native_recipe(events, size_change_timeout=0)

    def test_preferred_family_only_reorders_existing_native_actions(self):
        events = [dict(processor=atom, outcome='transformed') for atom in
                  ['poly(max-coefficient=2)', 'path-order', 'matrix(dimension=2)']]
        original = native_recipe(events)
        preferred = native_recipe(events, prefer_families=['path-order'])
        self.assertEqual(sorted(original.split(' | ')), sorted(preferred.split(' | ')))
        self.assertEqual(preferred.split(' | ')[:4],
                         ['graph', 'size-change', 'subterm', 'timeout(8s, path-order)'])
        self.assertEqual(native_recipe(events, prefer_families=['kbo']), original)
        with self.assertRaises(ValueError):
            native_recipe(events, prefer_families=['exact-path-order'])

    def test_exporter_can_scaffold_exhausted_trs_without_certification_credit(self):
        from export_native_frontier_hints import main
        cpf = '<trsInput><trs><rules><rule/></rules></trs></trsInput>'
        state = dict(cpf=cpf, problem_key=hashlib.sha256(cpf.encode()).hexdigest())
        with tempfile.TemporaryDirectory() as tmp:
            base = Path(tmp)
            old, current = base / 'old', base / 'current'
            old.mkdir()
            current.mkdir()
            (old / 'processor-events.jsonl').write_text(json.dumps(dict(
                processor='poly(max-coefficient=2)', outcome='transformed')) + '\n')
            (current / 'processor-events.jsonl').write_text(json.dumps(dict(
                processor='poly', outcome='failed', input=state)) + '\n')
            for name, directory, certified in [('baseline', old, True), ('current', current, False)]:
                (base / (name + '.json')).write_text(json.dumps([dict(
                    path='root.ari', artifact_dir=str(directory), certified=certified)]))
            for exhausted in (False, True):
                output = base / f'hints-{exhausted}.jsonl'
                argv = ['export', '--baseline', str(base / 'baseline.json'),
                        '--current', str(base / 'current.json'), '--output', str(output),
                        '--state-kind', 'trs']
                if exhausted:
                    argv.append('--include-exhausted')
                with patch('sys.argv', argv), contextlib.redirect_stdout(io.StringIO()):
                    main()
                rows = list(map(json.loads, output.read_text().splitlines()))
                self.assertEqual(len(rows), int(exhausted))
                if rows:
                    self.assertEqual(rows[0]['problem_key'], state['problem_key'])
                    self.assertEqual(rows[0]['prefer'], [])
                    self.assertTrue(all(h['certified_count'] == 0 for h in rows[0]['possible']))

    def test_exhausted_guided_frontier_is_opt_in_and_excludes_progress(self):
        e = self.event()
        e['processor'] = 'poly'
        self.assertEqual(unresolved_states([e]), {})
        self.assertEqual(len(unresolved_states([e], include_exhausted=True)), 1)
        for outcome in ('solved', 'transformed'):
            positive = dict(e, outcome=outcome)
            self.assertEqual(unresolved_states([e, positive], include_exhausted=True), {})

    def test_processor_budget_changes_only_search_allowance(self):
        events = [dict(processor='path-order', outcome='solved')]
        default = native_recipe(events)
        extended = native_recipe(events, processor_timeout=60)
        self.assertEqual(extended, default.replace('timeout(8s,', 'timeout(60s,'))
        self.assertTrue(extended.startswith('graph | size-change | subterm | '))
        for invalid in (0, -1):
            with self.assertRaises(ValueError):
                native_recipe(events, processor_timeout=invalid)

    def event(self):
        cpf = '<dpInput><dps><rules><rule/></rules></dps></dpInput>'
        return dict(processor='utility-guidance', outcome='failed',
                    input=dict(cpf=cpf, problem_key=hashlib.sha256(cpf.encode()).hexdigest()))

    def test_collects_unguided_typed_input(self):
        states = unresolved_states([self.event()])
        self.assertEqual(len(states), 1)
        self.assertEqual(next(iter(states.values()))[0], 1)

    def test_rejects_stale_digest(self):
        e = self.event()
        e['input']['cpf'] += '<extra/>'
        with self.assertRaises(ValueError):
            unresolved_states([e])

    def test_trs_frontier_is_opt_in_and_content_checked(self):
        cpf = '<trsInput><trs><rules><rule/><rule/></rules></trs></trsInput>'
        e = dict(processor='utility-guidance', outcome='failed',
                 input=dict(cpf=cpf, problem_key=hashlib.sha256(cpf.encode()).hexdigest()))
        self.assertEqual(unresolved_states([e]), {})
        states = unresolved_states([e], include_trs=True)
        self.assertEqual(list(states.values()), [(2, cpf)])
        e['input']['cpf'] = cpf.replace('<rule/>', '')
        with self.assertRaisesRegex(ValueError, 'digest mismatch'):
            unresolved_states([e], include_trs=True)

    def test_resolves_content_addressed_guidance_input(self):
        e = self.event()
        prior = dict(processor='graph', outcome='transformed',
                     witness={'residuals': [dict(e['input'])]})
        e['processor'] = 'UtilityGuidance'
        e['strategy_atom'] = 'utility-guidance'
        e['input']['cpf'] = None
        self.assertEqual(len(unresolved_states([prior, e])), 1)

    def test_recipe_discards_assignments_and_names(self):
        recipes = []
        for symbol in ('original', 'renamed'):
            atom = 'exact-poly(hex=' + json.dumps([[symbol, 2, [1]]]).encode().hex() + ')'
            recipes.append(native_recipe([dict(processor=atom, outcome='solved')]))
        self.assertEqual(recipes[0], recipes[1])
        self.assertIn('poly(max-constant=2', recipes[0])
        self.assertNotIn('exact-', recipes[0])
        self.assertNotIn('hex=', recipes[0])

    def test_recipe_fits_live_signature_without_increasing_coefficients(self):
        cpf = '<dpInput><funapp><name>f</name><funapp><name>a</name></funapp><var>x</var></funapp></dpInput>'
        event = dict(processor='poly(max-constant=1,max-coefficient=2,max-symbols=1,max-arity=1)', outcome='solved')
        recipe = native_recipe([event], cpf)
        self.assertIn('max-symbols=2,max-arity=2', recipe)
        self.assertIn('max-constant=1,max-coefficient=2', recipe)

    def test_signature_fitting_deduplicates_identical_searches(self):
        cpf = '<dpInput><funapp><name>f</name><funapp><name>a</name></funapp></funapp></dpInput>'
        events = [dict(processor=f'poly(max-coefficient=2,max-symbols={n})',
                       outcome='solved') for n in (1, 2)]
        events.append(dict(processor='poly(max-coefficient=3,max-symbols=1)', outcome='solved'))
        recipe = native_recipe(events, cpf)
        self.assertEqual(recipe.count('max-coefficient=2'), 1)
        self.assertEqual(recipe.count('max-coefficient=3'), 1)

    def test_collects_top_level_child_with_only_empty_check(self):
        cpf = '<trsInput><trs><rules><rule/></rules></trs></trsInput>'
        state = dict(cpf=cpf, problem_key=hashlib.sha256(cpf.encode()).hexdigest())
        parent = dict(processor='poly', outcome='transformed', witness=dict(residuals=[state]))
        child = dict(processor='empty', outcome='failed', input=dict(problem_key=state['problem_key']))
        self.assertEqual(unresolved_states([parent, child]), {})
        self.assertEqual(unresolved_states([parent, child], include_trs=True),
                         {state['problem_key']: (1, cpf)})
        child['outcome'] = 'solved'
        self.assertEqual(unresolved_states([parent, child], include_trs=True), {})


if __name__ == '__main__':
    unittest.main()
