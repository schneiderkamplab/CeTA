#!/usr/bin/env python3
"""Transfer successful atoms between related encodings as hints only."""

from __future__ import annotations

import argparse
from collections import defaultdict
import json
from pathlib import Path
import re
import sqlite3


VARIANT = re.compile(
    r"(?:_(?:complete|nokinds|nosorts)(?:-?noand)?(?:-?peanoSimple)?)"
    r"|(?:_(?:i?GM|FR|C|L|Z))(?=\.ari|\.xml|$)"
)


def instance_family(problem_id: str) -> str:
    name = problem_id.rsplit("/", 1)[-1]
    name = VARIANT.sub("", name)
    return name.rsplit(".", 1)[0]


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--source-db", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--max-atoms", type=int, default=8)
    args = parser.parse_args()

    connection = sqlite3.connect(args.source_db)
    family_atoms: dict[str, dict[str, tuple[int, float]]] = defaultdict(dict)
    problems = list(
        connection.execute(
            "SELECT problem_key, COALESCE(first_problem_id, '') FROM problems"
        )
    )
    for problem_key, problem_id in problems:
        group = instance_family(problem_id)
        for atom, rank, utility in connection.execute(
            """
            SELECT candidate, best_rank, utility_score FROM candidates
            WHERE problem_key=? AND best_status IN
              ('solved','transformed_strong','transformed_weak')
            """,
            (problem_key,),
        ):
            previous = family_atoms[group].get(atom)
            score = (int(rank), float(utility))
            if previous is None or score > previous:
                family_atoms[group][atom] = score

    args.output.parent.mkdir(parents=True, exist_ok=True)
    emitted = 0
    with args.output.open("w", encoding="utf-8") as stream:
        for problem_key, problem_id in sorted(problems):
            group = instance_family(problem_id)
            ranked = sorted(
                family_atoms[group].items(),
                key=lambda item: (-item[1][0], -item[1][1], item[0]),
            )[: args.max_atoms]
            if not ranked:
                continue
            stream.write(
                json.dumps(
                    {
                        "problem_key": problem_key,
                        "family": group,
                        "source_problem_id": problem_id,
                        "suggested_atoms": [
                            {
                                "atom": atom,
                                "evidence": "cross-instance-hint-only",
                                "rank": rank,
                                "utility": utility,
                            }
                            for atom, (rank, utility) in ranked
                        ],
                    },
                    sort_keys=True,
                    separators=(",", ":"),
                )
                + "\n"
            )
            emitted += 1
    connection.close()
    print(json.dumps({"families": len(family_atoms), "states": emitted}, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
