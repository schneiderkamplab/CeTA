#!/usr/bin/env python3
"""Translate AProVE CPF2 proofs with two known opaque wrappers to native CPF3.

This importer is intentionally narrow and fail-closed.  It accepts an outer
AAECC innermost wrapper and one or more Q-monotonic reduction-pair wrappers,
preserving the complete concrete proof below every transformation.
"""

from __future__ import annotations

import argparse
import copy
import re
import subprocess
import tempfile
import xml.etree.ElementTree as ET
from pathlib import Path


AAECC = "aprove.DPFramework.TRSProblem.Processors.AAECCInnermostProcessor.AAECCInnermostProof"
QMONO = "aprove.DPFramework.DPProblem.Processors.QDPQMonotonicMRRProcessor.QDPQMonotonicMRRProof"


def unknown(root: ET.Element, description: str) -> ET.Element:
    hits = [u for u in root.findall(".//unknownProof") if u.findtext("description") == description]
    if len(hits) != 1:
        raise ValueError(f"expected exactly one {description}, found {len(hits)}")
    return hits[0]


def unknowns(root: ET.Element, description: str) -> list[ET.Element]:
    return [u for u in root.findall(".//unknownProof") if u.findtext("description") == description]


def replace(root: ET.Element, old: ET.Element, new: ET.Element) -> None:
    for parent in root.iter():
        for index, child in enumerate(parent):
            if child is old:
                parent[index] = new
                return
    raise ValueError("element to replace is not below root")


def convert(converter: Path, root: ET.Element) -> ET.Element:
    with tempfile.TemporaryDirectory(prefix="ferrum-aprove-cpf-") as directory:
        source = Path(directory) / "proof.cpf2.xml"
        source.write_bytes(ET.tostring(root, encoding="utf-8", xml_declaration=True))
        completed = subprocess.run(
            [str(converter), str(source)],
            check=True,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
        )
    return ET.fromstring(completed.stdout)


def standalone(root: ET.Element, input_element: ET.Element, proof_element: ET.Element) -> ET.Element:
    result = copy.deepcopy(root)
    input_parent = result.find("input")
    proof_parent = result.find("proof")
    assert input_parent is not None and proof_parent is not None
    input_parent.clear()
    input_parent.append(copy.deepcopy(input_element))
    proof_parent.clear()
    proof_parent.append(copy.deepcopy(proof_element))
    return result


def term_symbols(term: ET.Element) -> set[str]:
    return {name.text or "" for name in term.findall(".//name")}


def root_name(side: ET.Element) -> str | None:
    funapp = side.find("funapp")
    return None if funapp is None else funapp.findtext("name")


def aaecc_partition(rule_elements: list[ET.Element]) -> tuple[list[int], list[int], set[str]]:
    non_sigma: set[str] = set()
    r1: list[int] = []
    r2: list[int] = []
    for index, rule in enumerate(rule_elements):
        left = root_name(rule.find("lhs"))
        right = root_name(rule.find("rhs"))
        if left is None or right is None or left in non_sigma or right in non_sigma:
            r1.append(index)
            non_sigma |= term_symbols(rule)
        else:
            r2.append(index)
            for side in (rule.find("lhs"), rule.find("rhs")):
                funapp = side.find("funapp")
                for arg in funapp.findall("arg"):
                    non_sigma |= term_symbols(arg)
    while True:
        moved = [index for index in r2 if root_name(rule_elements[index].find("lhs")) in non_sigma or root_name(rule_elements[index].find("rhs")) in non_sigma]
        if not moved:
            break
        for index in moved:
            r2.remove(index)
            r1.append(index)
            non_sigma |= term_symbols(rule_elements[index])
    all_symbols = set().union(*(term_symbols(rule) for rule in rule_elements))
    return sorted(r1), sorted(r2), all_symbols - non_sigma


def rules_container(tag: str, rules: list[ET.Element]) -> ET.Element:
    outer = ET.Element(tag)
    inner = ET.SubElement(outer, "rules")
    for rule in rules:
        inner.append(copy.deepcopy(rule))
    return outer


def resolved_rules(document: ET.Element, path: str) -> list[ET.Element]:
    result = []
    for item in document.findall(path):
        if item.tag == "rule":
            result.append(item)
            continue
        if item.tag != "ruleIndex":
            raise ValueError(f"unexpected rule reference {item.tag}")
        matches = [
            entry.find("rule")
            for entry in document.findall("./lookupTables/ruleTable/indexToRule")
            if entry.findtext("index") == item.text
        ]
        if len(matches) != 1 or matches[0] is None:
            raise ValueError(f"cannot resolve rule index {item.text}")
        result.append(matches[0])
    return result


def expand_rule_indices(element: ET.Element, document: ET.Element) -> None:
    table = {
        entry.findtext("index"): entry.find("rule")
        for entry in document.findall("./lookupTables/ruleTable/indexToRule")
    }
    for parent in list(element.iter()):
        for index, child in enumerate(list(parent)):
            if child.tag != "ruleIndex":
                continue
            rule = table.get(child.text)
            if rule is None:
                raise ValueError(f"cannot expand rule index {child.text}")
            parent[index] = copy.deepcopy(rule)


def restore_aprove_marked_aliases(document: ET.Element) -> None:
    """Turn AProVE's all-uppercase marked aliases back into CPF sharp symbols."""
    base_by_upper = {}
    for name in document.findall(".//name"):
        text = name.text or ""
        if any(character.isalpha() for character in text) and text.upper() != text:
            base_by_upper.setdefault(text.upper(), text)
    for parent_tag in ("funapp", "interpret"):
        for parent in document.iter(parent_tag):
            name = parent.find("name")
            if name is None:
                continue
            text = name.text or ""
            if not any(character.isalpha() for character in text) or text.upper() != text:
                continue
            parent.remove(name)
            sharp = ET.Element("sharp")
            ET.SubElement(sharp, "name").text = base_by_upper.get(text, text.lower())
            parent.insert(0, sharp)


def polynomial(constant: int, coefficients: list[int]) -> ET.Element:
    total = ET.Element("sum")
    ET.SubElement(total, "integer").text = str(constant)
    for index, coefficient in enumerate(coefficients, 1):
        if coefficient == 0:
            continue
        product = ET.SubElement(total, "product")
        ET.SubElement(product, "integer").text = str(coefficient)
        ET.SubElement(product, "variable").text = str(index)
    return total


def cpf2_polynomial(constant: int, coefficients: list[int]) -> ET.Element:
    terms: list[ET.Element] = []

    def wrapped(body: ET.Element) -> ET.Element:
        result = ET.Element("polynomial")
        result.append(body)
        return result

    coefficient = ET.Element("coefficient")
    ET.SubElement(coefficient, "integer").text = str(constant)
    terms.append(wrapped(coefficient))
    for index, value in enumerate(coefficients, 1):
        if value == 0:
            continue
        product = ET.Element("product")
        factor = ET.SubElement(product, "polynomial")
        factor_coefficient = ET.SubElement(factor, "coefficient")
        ET.SubElement(factor_coefficient, "integer").text = str(value)
        variable = ET.SubElement(product, "polynomial")
        ET.SubElement(variable, "variable").text = str(index)
        terms.append(wrapped(product))
    result = ET.Element("polynomial")
    if len(terms) == 1:
        result.append(terms[0][0])
    else:
        total = ET.SubElement(result, "sum")
        total.extend(terms)
    return result


def interpretation() -> ET.Element:
    # Exact model printed by AProVE for Secret_07_TRS/aprove01.
    model = [
        (False, "0", 0, 0, []),
        (True, "ifsum", 4, 0, [2, 0, 2, 0]),
        (True, "ifsum2", 3, 0, [0, 2, 0]),
        (True, "sum2", 2, 0, [2, 0]),
        (False, "cons", 2, 0, [2, 1]),
        (False, "false", 0, 0, []),
        (False, "isZero", 1, 1, [0]),
        (False, "p", 1, 0, [2]),
        (False, "s", 1, 2, [0]),
        (False, "true", 0, 0, []),
    ]
    result = ET.Element("interpretation")
    typ = ET.SubElement(result, "type")
    poly = ET.SubElement(typ, "polynomial")
    domain = ET.SubElement(poly, "domain")
    ET.SubElement(domain, "naturals")
    ET.SubElement(poly, "degree").text = "1"
    for marked, name, arity, constant, coefficients in model:
        item = ET.SubElement(result, "interpret")
        if marked:
            sharp = ET.SubElement(item, "sharp")
            ET.SubElement(sharp, "name").text = name
        else:
            ET.SubElement(item, "name").text = name
        ET.SubElement(item, "arity").text = str(arity)
        item.append(polynomial(constant, coefficients))
    return result


def cpf2_ordering_constraint(model: list[tuple[str, int, int, list[int]]]) -> ET.Element:
    constraint = ET.Element("orderingConstraintProof")
    red_pair = ET.SubElement(constraint, "redPair")
    result = ET.SubElement(red_pair, "interpretation")
    typ = ET.SubElement(result, "type")
    poly = ET.SubElement(typ, "polynomial")
    domain = ET.SubElement(poly, "domain")
    ET.SubElement(domain, "naturals")
    ET.SubElement(poly, "degree").text = "1"
    for name, arity, constant, coefficients in model:
        item = ET.SubElement(result, "interpret")
        ET.SubElement(item, "name").text = name
        ET.SubElement(item, "arity").text = str(arity)
        item.append(cpf2_polynomial(constant, coefficients))
    return constraint


def parse_linear_polynomial(expression: str, arity: int) -> tuple[int, list[int]]:
    constant = 0
    coefficients = [0] * arity
    for raw_term in expression.replace(" ", "").replace("-", "+-").split("+"):
        if not raw_term:
            continue
        variable = re.fullmatch(r"(?:(-?\d+)\*)?(-?)x_(\d+)", raw_term)
        if variable:
            coefficient = int(variable.group(1) or ("-1" if variable.group(2) else "1"))
            index = int(variable.group(3)) - 1
            if index < 0 or index >= arity:
                raise ValueError(f"variable index outside arity in {expression}")
            coefficients[index] += coefficient
        elif re.fullmatch(r"-?\d+", raw_term):
            constant += int(raw_term)
        else:
            raise ValueError(f"unsupported polynomial term {raw_term!r}")
    return constant, coefficients


def qmono_models(
    plain: Path,
) -> list[tuple[set[str], list[tuple[str, int, int, list[int]]]]]:
    text = plain.read_text(encoding="utf-8", errors="replace")
    blocks = re.findall(
        r"(QDPQMonotonicMRRProof \(EQUIVALENT\).*?Used ordering: Polynomial interpretation \[POLO\]:\s*.*?)(?=\n\s*-{20,})",
        text,
        flags=re.DOTALL,
    )
    models = []
    for block in blocks:
        polynomial_block = block.split("Used ordering: Polynomial interpretation [POLO]:", 1)[1]
        model = []
        for name, arguments, expression in re.findall(
            r"^\s*POL\(([^()\s]+)(?:\(([^()]*)\))?\)\s*=\s*(.+?)\s*$",
            polynomial_block,
            flags=re.MULTILINE,
        ):
            arity = 0 if not arguments.strip() else len(arguments.split(","))
            constant, coefficients = parse_linear_polynomial(expression, arity)
            model.append((name, arity, constant, coefficients))
        if not model:
            raise ValueError("Q-monotonic proof block has no linear model")
        before_ordering = block.split("Used ordering:", 1)[0]
        strict_roots = set(
            re.findall(r"^\s+([A-Za-z0-9_|#]+)\([^\n]*\)\s*->", before_ordering, re.MULTILINE)
        )
        models.append((strict_roots, model))
    return models


def complete_model_with_zero_defaults(
    model: list[tuple[str, int, int, list[int]]], dp_input: ET.Element
) -> list[tuple[str, int, int, list[int]]]:
    present = {name for name, _, _, _ in model}
    signature: dict[str, int] = {}
    for funapp in dp_input.findall(".//funapp"):
        sharp = funapp.find("sharp")
        name = (
            (sharp.findtext("name") or "").upper()
            if sharp is not None
            else (funapp.findtext("name") or "")
        )
        signature[name] = len(funapp.findall("arg"))
    return model + [
        (name, arity, 0, [0] * arity)
        for name, arity in sorted(signature.items())
        if name not in present
    ]


def canonical_rule(rule: ET.Element) -> tuple:
    variables: dict[str, int] = {}

    def canonical_term(container: ET.Element) -> tuple:
        variable = container if container.tag == "var" else (
            container.find("var") if container.tag not in {"funapp", "sharp"} else None
        )
        if variable is not None:
            name = variable.text or ""
            if name not in variables:
                variables[name] = len(variables)
            return ("v", variables[name])
        funapp = container if container.tag == "funapp" else container.find("funapp")
        if funapp is None:
            raise ValueError("term contains neither var nor funapp")
        sharp = funapp.find("sharp")
        if sharp is not None:
            name = (sharp.findtext("name") or "").upper()
        else:
            name = funapp.findtext("name") or ""
        arguments = funapp.findall("arg")
        if not arguments:
            arguments = [child for child in funapp if child.tag in {"var", "funapp"}]
        return (name, tuple(canonical_term(arg) for arg in arguments))

    lhs = rule.find("lhs")
    rhs = rule.find("rhs")
    if lhs is None or rhs is None:
        terms = [child for child in rule if child.tag in {"var", "funapp"}]
        if len(terms) != 2:
            raise ValueError("rule contains neither CPF2 lhs/rhs nor two CPF3 terms")
        lhs, rhs = terms
    return canonical_term(lhs), canonical_term(rhs)


def explicit_rule_indices(document: ET.Element, subtree: ET.Element) -> None:
    """Inline CPF3 rule-table references before moving a proof subtree."""
    table = {
        item.findtext("index"): item.find("rule")
        for item in document.findall("./lookupTables/ruleTable/indexToRule")
    }
    for parent in subtree.iter():
        for index, child in enumerate(list(parent)):
            if child.tag != "ruleIndex":
                continue
            source = table.get(child.text)
            if source is None:
                raise ValueError(f"residual proof has unresolved rule index {child.text!r}")
            parent[index] = copy.deepcopy(source)


def splice_innermost_qmono_residual(
    converted: ET.Element,
    original_q_wrappers: list[ET.Element],
    residual_document: ET.Element,
) -> None:
    """Replace the final foreign Q-monotonic suffix by a certified CPF3 proof.

    The replacement is accepted only when the residual proof input is exactly
    the child obligation of the innermost opaque Q-monotonic wrapper (modulo
    variable names and AProVE's uppercase encoding of marked symbols).
    """
    if not original_q_wrappers:
        raise ValueError("cannot splice a Q-monotonic residual without a wrapper")
    expected = original_q_wrappers[-1].find("./subProof/dpInput")
    actual = residual_document.find("./input/dpInput")
    proof = residual_document.find("./proof/dpProof")
    if expected is None or actual is None or proof is None:
        raise ValueError("malformed Q-monotonic residual CPF")

    def rule_keys(problem: ET.Element, part: str) -> list[tuple]:
        return sorted(canonical_rule(rule) for rule in problem.findall(f"./{part}/rules/rule"))

    for part in ("trs", "dps"):
        if rule_keys(expected, part) != rule_keys(actual, part):
            raise ValueError(f"residual CPF {part} does not match Q-monotonic child")

    processors = converted.findall(".//innermostMonoRedPairProc")
    if len(processors) != len(original_q_wrappers):
        raise ValueError(
            "converted Q-monotonic processor count does not match opaque wrappers"
        )
    replacement = copy.deepcopy(proof)
    explicit_rule_indices(residual_document, replacement)
    target = processors[-1].find("dpProof")
    if target is None:
        raise ValueError("converted innermost Q-monotonic processor has no child proof")
    target.clear()
    target.extend(copy.deepcopy(list(replacement)))


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("cpf2", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("--converter", type=Path, required=True)
    parser.add_argument("--plain", type=Path)
    parser.add_argument(
        "--qmono-residual-cpf",
        type=Path,
        help="certified CPF3 proof for the final Q-monotonic child obligation",
    )
    parser.add_argument("--wcr-depth", type=int, default=8)
    args = parser.parse_args()

    original = ET.parse(args.cpf2).getroot()
    outer = unknown(original, AAECC)
    q_wrappers = unknowns(original, QMONO)
    models = qmono_models(args.plain) if args.plain else []
    if len(models) != len(q_wrappers):
        raise ValueError(
            f"found {len(q_wrappers)} Q-monotonic wrappers but {len(models)} plain-proof models"
        )

    inner_input = outer.find("./subProof/trsInput")
    inner_proof = outer.find("./subProof/trsTerminationProof")
    if inner_input is None or inner_proof is None:
        raise ValueError("malformed AAECC wrapper")
    inner_document = standalone(original, inner_input, inner_proof)
    for _ in range(len(models)):
        inner_q = unknowns(inner_document, QMONO)[0]
        q_parent = inner_q.find("dpInput")
        q_child_input = inner_q.find("./subProof/dpInput")
        q_child_proof = inner_q.find("./subProof/dpProof")
        if q_parent is None or q_child_input is None or q_child_proof is None:
            raise ValueError("malformed Q-monotonic wrapper")
        parent_pairs = q_parent.findall("./dps/rules/rule")
        child_pair_keys = {canonical_rule(rule) for rule in q_child_input.findall("./dps/rules/rule")}
        deleted_pairs = [rule for rule in parent_pairs if canonical_rule(rule) not in child_pair_keys]
        parent_rules = q_parent.findall("./trs/rules/rule")
        child_rule_keys = {canonical_rule(rule) for rule in q_child_input.findall("./trs/rules/rule")}
        deleted_rules = [rule for rule in parent_rules if canonical_rule(rule) not in child_rule_keys]
        if not deleted_pairs and not deleted_rules:
            raise ValueError("Q-monotonic wrapper deletes neither pairs nor rules")
        deleted_roots = {
            (root_name(rule.find("lhs")) or "").replace("#", "").upper()
            for rule in deleted_pairs + deleted_rules
        }
        candidates = [
            (index, model)
            for index, (strict_roots, model) in enumerate(models)
            if deleted_roots & {root.replace("#", "").upper() for root in strict_roots}
        ]
        if len(candidates) != 1:
            raise ValueError(
                f"cannot uniquely bind Q-monotonic model for deleted roots {sorted(deleted_roots)}"
            )
        model_index, model = candidates[0]
        models.pop(model_index)
        q_proc_cpf2 = ET.Element("innermostMonoRedPairProc")
        q_proc_cpf2.append(
            cpf2_ordering_constraint(complete_model_with_zero_defaults(model, q_parent))
        )
        removed = ET.SubElement(q_proc_cpf2, "strictRules")
        removed.append(rules_container("dps", deleted_pairs))
        removed.append(rules_container("trs", deleted_rules))
        q_proc_cpf2.append(copy.deepcopy(q_child_proof))
        replace(inner_document, inner_q, q_proc_cpf2)
    converted_inner = convert(args.converter, inner_document)
    restore_aprove_marked_aliases(converted_inner)
    if q_wrappers and converted_inner.find(".//innermostMonoRedPairProc") is None:
        raise ValueError("converted proof lost the Q-monotonic processor")
    if args.qmono_residual_cpf:
        residual_document = ET.parse(args.qmono_residual_cpf).getroot()
        splice_innermost_qmono_residual(converted_inner, q_wrappers, residual_document)
        # The independently generated Ferrum fragment uses AProVE's residual
        # uppercase symbols verbatim.  Resolve them against the complete
        # document after splicing, where their original mixed-case bases are
        # available.
        restore_aprove_marked_aliases(converted_inner)

    # Restore the full root input and wrap the converted innermost proof in the
    # native, independently checked AAECC transformation.
    empty_termination = ET.Element("trsTerminationProof")
    ET.SubElement(empty_termination, "rIsEmpty")
    converted_root = convert(
        args.converter,
        standalone(original, original.find("./input/trsInput"), empty_termination),
    )
    normalized_root_input = converted_root.find("./input/trsInput")
    normalized_root_rules = resolved_rules(converted_root, "./input/trsInput/trs/rules/*")
    normalized_root_input.find("./trs/rules").clear()
    for rule in normalized_root_rules:
        normalized_root_input.find("./trs/rules").append(copy.deepcopy(rule))
    # Keep the inner conversion's lookup table: all of its processor-local rule
    # indices refer to that table.  The root rules above are embedded explicitly.
    converted_inner_proof = copy.deepcopy(converted_inner.find("./proof/trsTerminationProof")[0])
    converted_root = converted_inner
    converted_root.find("input").clear()
    converted_root.find("input").append(copy.deepcopy(normalized_root_input))
    proof_parent = converted_root.find("proof")
    proof_parent.clear()
    termination = ET.SubElement(proof_parent, "trsTerminationProof")
    wrapper = ET.SubElement(termination, "aaeccInnermost")
    cpf2_rules = original.findall("./input/trsInput/trs/rules/rule")
    cpf3_rules = normalized_root_rules
    r1, r2, sigma = aaecc_partition(cpf2_rules)
    wrapper.append(rules_container("r1", [cpf3_rules[i] for i in r1]))
    wrapper.append(rules_container("r2", [cpf3_rules[i] for i in r2]))
    sigma_element = ET.SubElement(wrapper, "sigma")
    for name in sorted(sigma):
        symbol = ET.SubElement(sigma_element, "symbol")
        ET.SubElement(symbol, "name").text = name
    wcr = ET.SubElement(wrapper, "wcrProof")
    ET.SubElement(wcr, "joinAutoBfs").text = str(args.wcr_depth)
    nested = ET.SubElement(wrapper, "trsTerminationProof")
    nested.append(converted_inner_proof)

    ET.indent(converted_root, space="  ")
    args.output.write_bytes(ET.tostring(converted_root, encoding="utf-8", xml_declaration=True))


if __name__ == "__main__":
    main()
