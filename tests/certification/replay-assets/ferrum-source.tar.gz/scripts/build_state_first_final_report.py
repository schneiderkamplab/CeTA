#!/usr/bin/env python3
"""Build the immutable summary for the state-first unified campaign."""

from __future__ import annotations

import hashlib
import json
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
RUN = ROOT / "target/data-campaign/state-first-unified-20260726-094011"


def load(relative: str) -> dict:
    return json.loads((RUN / relative).read_text(encoding="utf-8"))


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as source:
        for block in iter(lambda: source.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def main() -> None:
    cycle1 = load("cycle1/summary-final.json")
    prototype_cycle2 = load("cycle2/summary-final.json")
    cycle2 = load("cycle2-final-implementation/summary.json")
    oracle = load("final/oracle-export-report-final-implementation.json")
    frozen = load("final/certified-union-final-implementation/summary.json")
    registry = load(
        "validation/csr-oracle-fallback-final-implementation/registry-coverage.json"
    )

    binaries = [
        RUN / "bin/ferrum-validation-dp-final",
        RUN / "bin/ceta-validation-nfs-final",
    ]
    manifest = {
        "schema": "ferrum.state-first-final-manifest.v1",
        "artifact_root": str(RUN),
        "binaries": [
            {"path": str(path), "sha256": sha256(path)} for path in binaries
        ],
        "oracle": str(RUN / "final/oracle-global-final-implementation.jsonl"),
        "oracle_records": oracle["output_records"],
        "certified_unique_proofs": frozen["unique_proofs"],
        "deterministic_certified_twice": frozen["deterministic_certified"],
        "uncertified_promoted_yes": (
            cycle1["uncertified_promoted_yes"]
            + prototype_cycle2["uncertified_promoted_yes"]
            + cycle2["uncertified_promoted_yes"]
        ),
    }
    (RUN / "final/manifest.json").write_text(
        json.dumps(manifest, indent=2, sort_keys=True) + "\n", encoding="utf-8"
    )

    report = f"""# State-first unified oracle campaign

Artifact root: `{RUN}`

## Outcome

- Cycle 1 exhausted its frontier after {sum(cycle1["direct_probes_by_outcome"].values()):,} of 20,000 allowed probes: {cycle1["covered_states"]} states covered, {cycle1["uncovered_states"]} uncovered.
- Cycle 2 ran only on the uncovered frontier with the final implementation and exhausted it after {sum(cycle2["direct_probes_by_outcome"].values()):,} probes: {cycle2["covered_states"]} states covered, {cycle2["new_child_states"]} new children materialized, and {cycle2["uncovered_states"]} states left uncovered.
- The monotone oracle contains {oracle["output_records"]:,} records. It promoted {oracle["certified_positive_evidence_rows_promoted"]} certified evidence rows and rejected {oracle["uncertified_positive_evidence_rows_rejected"]} uncertified positive rows.
- The frozen union contains {frozen["unique_proofs"]} unique proofs. All {frozen["deterministic_certified"]} certified twice identically; {frozen["rejected"]} were rejected.
- Uncertified promoted YES answers: {manifest["uncertified_promoted_yes"]}.

## Cycle metrics

| Metric | Cycle 1 | Cycle 2 |
| --- | ---: | ---: |
| Solved probe outcomes | {cycle1["direct_probes_by_outcome"]["solved"]} | {cycle2["direct_probes_by_outcome"]["solved"]} |
| Transformed outcomes | {cycle1["direct_probes_by_outcome"]["transformed"]} | {cycle2["direct_probes_by_outcome"]["transformed"]} |
| Failed outcomes | {cycle1["direct_probes_by_outcome"]["failed"]} | {cycle2["direct_probes_by_outcome"]["failed"]} |
| Timed out outcomes | {cycle1["direct_probes_by_outcome"]["timeout"]} | {cycle2["direct_probes_by_outcome"]["timeout"]} |
| Certified terminal proof rows | {cycle1["certified_terminal_proofs"]} | {cycle2["certified_terminal_proofs"]} |
| Certified tightening gains | {cycle1["certified_tightening_gains"]} | {cycle2["certified_tightening_gains"]} |
| Uncertified solved attempts | {cycle1["uncertified_solved_attempts"]} | {cycle2["uncertified_solved_attempts"]} |
| Certified transformations | {cycle1["certified_transformations"]} | {cycle2["certified_transformations"]} |
| Certified assembled proofs | {cycle1["assembled_proofs_certified"]} | {cycle2["assembled_proofs_certified"]} |

The scheduler used quotas of 35% unseen, 25% hints, 20% escalation, 15% tightening, and 5% opposite polarity. Both cycles stopped because their finite frontiers were exhausted, not because the 20,000-probe caps were reached. Probe concurrency was capped at {cycle1["direct_probe_concurrency_cap"]}; the hard timeout cap was {cycle1["probe_timeout_cap_ms"] // 1000} seconds.

Problem-kind state coverage was:

| Kind | Cycle 1 covered/uncovered | Cycle 2 covered/uncovered |
| --- | ---: | ---: |
| cs-trs | {cycle1["states_by_problem_kind"]["cs-trs"]["covered"]}/{cycle1["states_by_problem_kind"]["cs-trs"]["uncovered"]} | {cycle2["states_by_problem_kind"]["cs-trs"]["covered"]}/{cycle2["states_by_problem_kind"]["cs-trs"]["uncovered"]} |
| qdp | {cycle1["states_by_problem_kind"]["qdp"]["covered"]}/{cycle1["states_by_problem_kind"]["qdp"]["uncovered"]} | {cycle2["states_by_problem_kind"]["qdp"]["covered"]}/{cycle2["states_by_problem_kind"]["qdp"]["uncovered"]} |

## Validation

| Replay | Total | Certified YES | Certified NO | MAYBE | Timeout | Error | Certificate failures |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| CSR oracle-only | 108 | 3 | 0 | 105 | 0 | 0 | 0 |
| CSR oracle + fallback | 108 | 62 | 0 | 46 | 0 | 0 | 0 |
| TRS Standard oracle + fallback | 1,528 | 624 | 165 | 691 | 48 | 0 | 0 |

All 54 CSR fallback proofs using a CSR-DP transformation certified completely. Every decisive answer in the final Standard replay certified.

The fallback comparison observed {registry["unique_event_states"]} unique event states: {registry["present_states"]} were already represented and {registry["absent_states"]} were absent. The exact absent-state list is `validation/csr-oracle-fallback-final-implementation/absent-states.jsonl`.

## Checker and regression gates

- Isabelle `Proof_Checker`: passed.
- Isabelle `Code`: passed.
- Haskell export: completed; the repository's merged CSR module boundary was preserved while synchronizing the generated parser semantics.
- `make haskell`: passed.
- CeTA production `make test`: completed with its known forbidden-pattern and outermost example failures; all other examples passed.
- Python campaign discovery: 29/29 passed.
- Focused typed-outcome, child-context, residual, NFS transition, graph, usable-rule, improved-Q-CSDP positive, and mutation-negative Rust tests passed.
- Full serial Rust suite: 351 passed, 16 known baseline failures, 1 ignored. The failures include generalized size-change, timing-sensitive parallel, RFC/CPF-mode, and native forbidden-pattern parser tests. No failing result is used as promoted evidence.

## Principal artifacts

- Seed oracle: `seed/oracle-monotone.jsonl`
- Cycle databases: `cycle1/campaign.sqlite`, `cycle2-final-implementation/campaign.sqlite`
- Retained prototype Cycle 2: `cycle2/campaign.sqlite`
- Final oracle: `final/oracle-global-final-implementation.jsonl`
- Oracle export gate: `final/oracle-export-report-final-implementation.json`
- Frozen proof union: `final/certified-union-final-implementation/summary.json`
- CSR oracle-only summary: `validation/csr-oracle-only-final-implementation/summary.md`
- CSR fallback summary: `validation/csr-oracle-fallback-final-implementation/summary.md`
- TRS Standard summary: `validation/trs-standard-final-implementation/summary.md`
- Fallback registry comparison: `validation/csr-oracle-fallback-final-implementation/registry-coverage.json`
- Binary/hash manifest: `final/manifest.json`
"""
    (RUN / "FINAL_REPORT.md").write_text(report, encoding="utf-8")


if __name__ == "__main__":
    main()
