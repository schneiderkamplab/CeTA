#!/usr/bin/env python3

import json
import hashlib
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest
from unittest.mock import patch

import add_runtime_canonical_aliases as aliases


class RuntimeCanonicalAliasTest(unittest.TestCase):
    def test_success_without_inline_cpf_receives_canonical_alias(self):
        cpf = '<dpInput><trs/><dps/></dpInput>'
        key = hashlib.sha256(cpf.encode()).hexdigest()
        canonical = '<dpInput><dps/><trs/></dpInput>'
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            source, output = root / 'events', root / 'aliases'
            rows = [{'input': {'cpf': cpf, 'problem_key': key}, 'outcome': 'failed'},
                    {'input': {'problem_key': key}, 'outcome': 'solved'}]
            source.write_text(''.join(json.dumps(row) + '\n' for row in rows))
            with patch.object(sys, 'argv', ['aliases', '--input', str(source),
                    '--output', str(output), '--ferrum', str(root/'ferrum')]), \
                 patch.object(aliases, 'canonicalize', return_value=canonical):
                aliases.main()
            emitted = list(map(json.loads, output.read_text().splitlines()))
            self.assertEqual(len(emitted), 4)
            self.assertEqual(emitted[2], rows[1])
            self.assertEqual(emitted[3]['outcome'], 'solved')
            self.assertEqual(emitted[3]['input']['cpf'], canonical)
            self.assertEqual(emitted[3]['input']['problem_key'], hashlib.sha256(canonical.encode()).hexdigest())

    def test_recovers_interned_context_and_rejects_stale_digest(self):
        cpf = '<dpInput><trs/><dps/><ferrumDpStateContext/></dpInput>'
        key = hashlib.sha256(cpf.encode()).hexdigest()
        rows = [{'input': {'problem_key': key, 'cpf': cpf}},
                {'input': {'problem_key': key}, 'outcome': 'transformed'}]
        self.assertEqual(aliases.inline_inputs(rows), {key: cpf})
        rows[0]['input']['cpf'] += 'x'
        with self.assertRaisesRegex(ValueError, 'digest'):
            aliases.inline_inputs(rows)

    def test_accepts_every_typed_trs_and_dp_state(self) -> None:
        self.assertTrue(
            aliases.is_runtime_canonicalizable_event(
                {"input": {"cpf": "<trsInput><trs/></trsInput>"}}
            )
        )
        self.assertTrue(
            aliases.is_runtime_canonicalizable_event(
                {"input": {"cpf": "<dpInput><trs/><dps/></dpInput>"}}
            )
        )
        self.assertTrue(
            aliases.is_runtime_canonicalizable_event(
                {
                    "input": {
                        "cpf": "<trsInput><trs/><contextSensitive/></trsInput>"
                    }
                }
            )
        )

    def test_timeout_skips_only_expensive_state(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            source = root / "events.jsonl"
            output = root / "aliases.jsonl"
            rows = [
                {
                    "input": {
                        "cpf": f"<dpInput><trs/><dps><rules><rule><var>{name}</var>"
                        f"<var>{name}</var></rule></rules></dps></dpInput>"
                    }
                }
                for name in ("slow", "fast")
            ]
            source.write_text(
                "".join(json.dumps(row) + "\n" for row in rows),
                encoding="utf-8",
            )
            canonical = "<dpInput><trs/><dps><rules/></dps></dpInput>"
            argv = [
                "add_runtime_canonical_aliases.py",
                "--input",
                str(source),
                "--output",
                str(output),
                "--ferrum",
                str(root / "ferrum"),
            ]

            with (
                patch.object(sys, "argv", argv),
                patch.object(
                    aliases,
                    "canonicalize",
                    side_effect=[
                        subprocess.TimeoutExpired(["ferrum"], 10),
                        canonical,
                    ],
                ),
            ):
                self.assertEqual(aliases.main(), 0)

            emitted = [
                json.loads(line)
                for line in output.read_text(encoding="utf-8").splitlines()
            ]
            self.assertEqual(len(emitted), 3)
            self.assertEqual(emitted[:2], rows)
            self.assertEqual(emitted[2]["input"]["cpf"], canonical)
            self.assertTrue(emitted[2]["metrics"]["runtime_canonical_alias"])


if __name__ == "__main__":
    unittest.main()
