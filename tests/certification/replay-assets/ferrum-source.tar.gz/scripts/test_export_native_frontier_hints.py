import contextlib
import hashlib
import io
import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

from export_native_frontier_hints import fit_signature, main


class ExportFrontierTests(unittest.TestCase):
    def test_signature_bounds_are_floors_not_model_values(self):
        cpf = '<trsInput><funapp><name>f</name><funapp><name>a</name></funapp><var>x</var></funapp></trsInput>'
        self.assertEqual(fit_signature('poly(max-symbols=1,max-arity=1,max-coefficient=1)', cpf),
                         'poly(max-symbols=2,max-arity=2,max-coefficient=1)')
        self.assertEqual(fit_signature('kbo(max-symbols=100,max-weight=3)', cpf),
                         'kbo(max-symbols=100,max-weight=3)')

    def test_additional_certified_sources_supply_families_not_witnesses(self):
        with tempfile.TemporaryDirectory() as tmp:
            base = Path(tmp)
            cpf = '<trsInput><trs><rules><rule/></rules></trs></trsInput>'
            key = hashlib.sha256(cpf.encode()).hexdigest()
            sources = []
            for i, (certified, atom) in enumerate([
                (True, 'kbo(max-weight=2)'),
                (True, 'exact-poly(hex=' + json.dumps([['renamable', 2, [1]]]).encode().hex() + ')'),
                (False, 'path-order'),
                (True, 'dp(pipeline(graph; size-change))'),
            ]):
                directory = base / str(i)
                directory.mkdir()
                (directory / 'processor-events.jsonl').write_text(
                    json.dumps(dict(processor=atom, outcome='solved')) + '\n')
                details = base / f'{i}.json'
                details.write_text(json.dumps([dict(path='root', certified=certified,
                                                    artifact_dir=str(directory))]))
                sources.append(details)
            current_dir = base / 'current'
            current_dir.mkdir()
            (current_dir / 'processor-events.jsonl').write_text(json.dumps(dict(
                processor='empty', outcome='failed', input=dict(cpf=cpf, problem_key=key))) + '\n')
            current = base / 'current.json'
            current.write_text(json.dumps([dict(path='root', certified=False,
                                                artifact_dir=str(current_dir))]))
            output = base / 'out.jsonl'
            args = ['export', '--baseline', str(sources[0]),
                    '--additional-baseline', str(sources[1]),
                    '--additional-baseline', str(sources[2]),
                    '--additional-baseline', str(sources[3]),
                    '--current', str(current), '--state-kind', 'trs', '--output', str(output)]
            with patch('sys.argv', args), contextlib.redirect_stdout(io.StringIO()):
                main()
            row = json.loads(output.read_text())
            candidates = [item['candidate'] for item in row['possible']]
            self.assertIn('kbo(max-weight=2)', candidates)
            self.assertTrue(any(atom.startswith('poly(') for atom in candidates))
            self.assertNotIn('path-order', candidates)
            self.assertIn('dp', candidates)
            self.assertFalse(any('pipeline' in atom for atom in candidates))
            self.assertNotIn('renamable', output.read_text())
            self.assertNotIn('hex=', output.read_text())
            self.assertTrue(all(item['certified_count'] == 0 for item in row['possible']))


if __name__ == '__main__':
    unittest.main()
