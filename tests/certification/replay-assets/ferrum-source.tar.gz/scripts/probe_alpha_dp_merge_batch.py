#!/usr/bin/env python3
"""Bounded, diverse native alpha-merge exploration over direct CPF states."""
import argparse
from concurrent.futures import ThreadPoolExecutor, as_completed
import hashlib
import json
from pathlib import Path
import subprocess
import sys
from probe_alpha_dp_merges import pair_signature


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--root', type=Path, required=True)
    p.add_argument('--output', type=Path, required=True)
    p.add_argument('--ferrum', required=True)
    p.add_argument('--jobs', type=int, default=8)
    p.add_argument('--max-states', type=int, default=128)
    p.add_argument('--per-root', type=int, default=4)
    args = p.parse_args()
    args.output.mkdir(parents=True, exist_ok=False)
    tasks, seen, counts = [], set(), {}
    paths = sorted(args.root.rglob('input.cpf'), key=lambda path: (str(path.parents[2]), int(path.parent.name) if path.parent.name.isdigit() else 0))
    for path in paths:
        root = str(path.parents[2])
        if counts.get(root, 0) >= args.per_root:
            continue
        cpf = path.read_text()
        key = hashlib.sha256(cpf.strip().encode()).hexdigest()
        if key in seen:
            continue
        count, signature = pair_signature(cpf)
        if count == len(signature):
            continue
        seen.add(key)
        counts[root] = counts.get(root, 0) + 1
        tasks.append((path, args.output/str(len(tasks))))
        if len(tasks) >= args.max_states:
            break

    def run(task):
        source, output = task
        result = subprocess.run([sys.executable, 'scripts/probe_alpha_dp_merges.py',
            '--input', str(source), '--output', str(output), '--ferrum', args.ferrum],
            capture_output=True, text=True, timeout=180)
        return dict(input=str(source), output=str(output), returncode=result.returncode,
                    stdout=result.stdout, stderr=result.stderr)

    by_key = {}
    with ThreadPoolExecutor(max_workers=args.jobs) as pool, (args.output/'results.jsonl').open('x') as log, (args.output/'hints.jsonl').open('x') as hints:
        for future in as_completed([pool.submit(run, task) for task in tasks]):
            row = future.result()
            print(json.dumps(row), file=log, flush=True)
            path = Path(row['output'])/'hints.jsonl'
            if row['returncode'] == 0 and path.exists():
                for line in path.open():
                    record = json.loads(line)
                    by_key[record['problem_key']] = record
        for key in sorted(by_key):
            print(json.dumps(by_key[key]), file=hints)
    print(json.dumps(dict(states=len(tasks), roots=len(counts))))


if __name__ == '__main__':
    main()
