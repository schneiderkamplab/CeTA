import json
import sqlite3
import tempfile
import unittest
from pathlib import Path

from export_utility_guidance_lookup import (
    add_contextless_portable_exact_states,
    apply_dataset_aliases,
    apply_explicit_aliases,
    candidate_is_executable_atomic,
    candidate_evidence,
    merge_base_oracle,
    merged_state_evidence,
    retain_base_alias_evidence,
)


class ExplicitAliasTests(unittest.TestCase):
    def test_contextless_bridge_only_copies_self_validating_exact_processors(self):
        with tempfile.TemporaryDirectory() as temporary:
            database = Path(temporary) / "evidence.sqlite"
            context = (
                "<dpInput><trs><rules/></trs>"
                "<ferrumDpStateContext><minimal>true</minimal>"
                "</ferrumDpStateContext><dps><rules/></dps></dpInput>"
            )
            contextless = (
                "<dpInput><trs><rules/></trs><dps><rules/></dps></dpInput>"
            )
            key = __import__("hashlib").sha256(contextless.encode()).hexdigest()
            with sqlite3.connect(database) as connection:
                connection.execute("CREATE TABLE problems(problem_key TEXT, cpf TEXT)")
                connection.execute("INSERT INTO problems VALUES ('runtime', ?)", (context,))
            exact = {
                "candidate": "exact-red-pair(hex=00)",
                "status": "solved",
                "utility_score": 1,
                "best_elapsed_ms": 1,
                "attempts": 1,
                "solved_count": 1,
                "transformed_count": 0,
                "failed_count": 0,
                "timeout_count": 0,
                "certified_count": 1,
            }
            generic = {**exact, "candidate": "graph"}
            evidence = {
                "runtime": {
                    "prefer": [exact, generic],
                    "possible": [],
                    "avoid": [],
                    "timeout": [],
                }
            }

            added = add_contextless_portable_exact_states(database, evidence)

            self.assertEqual(added, 1)
            self.assertEqual(
                [row["candidate"] for row in evidence[key]["prefer"]],
                ["exact-red-pair(hex=00)"],
            )

    def test_top_level_dp_is_an_executable_worklist_processor(self):
        self.assertTrue(candidate_is_executable_atomic("dp"))
        self.assertFalse(candidate_is_executable_atomic("dp(graph;size-change)"))

    def test_dataset_runtime_alias_inherits_canonical_evidence(self):
        with tempfile.TemporaryDirectory() as temporary:
            database = Path(temporary) / "evidence.sqlite"
            with sqlite3.connect(database) as connection:
                connection.execute(
                    "CREATE TABLE problem_aliases(raw_problem_key TEXT, problem_key TEXT)"
                )
                connection.execute(
                    "INSERT INTO problem_aliases VALUES ('runtime', 'canonical')"
                )
            candidate = {
                "candidate": "csr-safe-dp(graph;size-change)",
                "status": "solved",
                "utility_score": 1,
                "best_elapsed_ms": 1,
                "attempts": 1,
                "solved_count": 1,
                "transformed_count": 0,
                "failed_count": 0,
                "timeout_count": 0,
                "certified_count": 1,
            }
            evidence = {
                "canonical": {
                    "prefer": [candidate],
                    "possible": [],
                    "avoid": [],
                    "timeout": [],
                },
                "runtime": {
                    "prefer": [],
                    "possible": [],
                    "avoid": [],
                    "timeout": [],
                },
            }

            merged = apply_dataset_aliases(
                database, evidence, {}, prefer_alias_evidence=True
            )

            self.assertEqual(merged, 1)
            self.assertEqual(evidence["runtime"]["prefer"][0], candidate)

    def test_dataset_runtime_alias_preserves_exact_evidence_structurally(self):
        with tempfile.TemporaryDirectory() as temporary:
            database = Path(temporary) / "evidence.sqlite"
            with sqlite3.connect(database) as connection:
                connection.execute(
                    "CREATE TABLE problem_aliases(raw_problem_key TEXT, problem_key TEXT)"
                )
                connection.execute(
                    "INSERT INTO problem_aliases VALUES ('runtime', 'canonical')"
                )
            exact = {
                "candidate": "exact-poly(hex=00)",
                "status": "solved",
                "utility_score": 1,
                "best_elapsed_ms": 1,
                "attempts": 1,
                "solved_count": 1,
                "transformed_count": 0,
                "failed_count": 0,
                "timeout_count": 0,
                "certified_count": 1,
            }
            evidence = {
                "canonical": {
                    "prefer": [exact],
                    "possible": [],
                    "avoid": [],
                    "timeout": [],
                }
            }
            aliases = {"runtime": ("semantic-other", "semantic")}

            merged = apply_dataset_aliases(
                database, evidence, aliases, prefer_alias_evidence=True
            )

            self.assertEqual(merged, 1)
            self.assertNotIn("runtime", evidence)
            self.assertEqual(aliases["runtime"], ("canonical", "structural"))

    def test_monotone_merge_keeps_prior_working_action_first(self):
        def candidate(name, utility):
            return {
                "candidate": name,
                "status": "solved",
                "utility_score": utility,
                "best_elapsed_ms": 1,
                "attempts": 1,
                "solved_count": 1,
                "transformed_count": 0,
                "failed_count": 0,
                "timeout_count": 0,
                "certified_count": 1,
            }

        prior = {
            "prefer": [candidate("dp", 1)],
            "possible": [],
            "avoid": [],
            "timeout": [],
        }
        incoming = {
            "prefer": [candidate("dp(graph;size-change)", 100)],
            "possible": [],
            "avoid": [],
            "timeout": [],
        }

        merged = merged_state_evidence(
            prior, incoming, preserve_left_order=True
        )

        self.assertEqual(
            [row["candidate"] for row in merged["prefer"]],
            ["dp", "dp(graph;size-change)"],
        )

    def test_monotone_merge_preserves_compact_witness_references(self):
        referenced = {
            "candidate_ref": "witness-sha256",
            "status": "transformed_strong",
            "utility_score": 300,
            "best_elapsed_ms": 2,
            "attempts": 1,
            "solved_count": 0,
            "transformed_count": 1,
            "failed_count": 0,
            "timeout_count": 0,
            "certified_count": 1,
        }
        empty = {group: [] for group in ("prefer", "possible", "avoid", "timeout")}
        incoming = {**empty, "prefer": [referenced]}

        merged = merged_state_evidence(empty, incoming, preserve_left_order=True)

        self.assertEqual(merged["prefer"], [referenced])

    def test_targeted_recovery_overlay_can_put_incoming_action_first(self):
        def candidate(name):
            return {
                "candidate": name,
                "status": "solved",
                "utility_score": 1,
                "best_elapsed_ms": 1,
                "attempts": 1,
                "solved_count": 1,
                "transformed_count": 0,
                "failed_count": 0,
                "timeout_count": 0,
                "certified_count": 1,
            }

        with tempfile.TemporaryDirectory() as temporary:
            base = Path(temporary) / "base.jsonl"
            base.write_text(
                json.dumps(
                    {
                        "problem_key": "state",
                        "prefer": [candidate("old-action")],
                        "possible": [],
                        "avoid": [],
                        "timeout": [],
                    }
                )
                + "\n",
                encoding="utf-8",
            )
            evidence = {
                "state": {
                    "prefer": [candidate("recovered-action")],
                    "possible": [],
                    "avoid": [],
                    "timeout": [],
                }
            }

            merge_base_oracle(base, evidence, prefer_incoming=True)

        self.assertEqual(
            [row["candidate"] for row in evidence["state"]["prefer"]],
            ["recovered-action", "old-action"],
        )

    def test_uncertified_weak_transition_remains_possible_not_preferred(self):
        with tempfile.TemporaryDirectory() as temporary:
            database = Path(temporary) / "evidence.sqlite"
            with sqlite3.connect(database) as connection:
                connection.execute(
                    """
                    CREATE TABLE candidates(
                      problem_key TEXT, candidate TEXT, best_status TEXT,
                      utility_score REAL, best_elapsed_ms INTEGER, best_rank INTEGER,
                      attempts INTEGER, solved_count INTEGER, transformed_count INTEGER,
                      failed_count INTEGER, timeout_count INTEGER, certified_count INTEGER,
                      hard_negative_count INTEGER
                    )
                    """
                )
                connection.execute(
                    "INSERT INTO candidates VALUES "
                    "('state', 'graph', 'transformed_weak', 80, 3, 2, "
                    "1, 0, 1, 0, 0, 0, 0)"
                )

            evidence = candidate_evidence(database)["state"]

            self.assertEqual(evidence["prefer"], [])
            self.assertEqual(evidence["possible"][0]["candidate"], "graph")
            self.assertEqual(evidence["possible"][0]["certified_count"], 0)

    def test_resolves_explicit_alias_through_canonical_cache_alias(self):
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            alias_map = root / "aliases.jsonl"
            live = "a" * 64
            retained = "b" * 64
            canonical = "c" * 64
            alias_map.write_text(
                json.dumps(
                    {
                        "raw_key": live,
                        "canonical_problem_key": retained,
                    }
                )
                + "\n",
                encoding="utf-8",
            )
            evidence = {
                canonical: {
                    "prefer": [],
                    "possible": [],
                    "avoid": [],
                    "timeout": [],
                }
            }
            aliases = {retained: (canonical, "semantic")}

            apply_explicit_aliases(alias_map, evidence, aliases)

            self.assertEqual(aliases[live], (canonical, "semantic"))

    def test_canonicalizer_change_retains_inherited_positive_on_current_key(self):
        raw = "a" * 64
        old = "b" * 64
        current = "c" * 64
        positive = {
            "candidate": "poly(max-constant=2,max-coefficient=2)",
            "status": "transformed_strong",
            "utility_score": 299.0,
            "best_elapsed_ms": 1,
            "attempts": 1,
            "solved_count": 0,
            "transformed_count": 1,
            "failed_count": 0,
            "timeout_count": 0,
            "certified_count": 1,
        }
        empty = {"prefer": [], "possible": [], "avoid": [], "timeout": []}
        evidence = {
            old: {**empty, "prefer": [positive]},
            current: {**empty, "avoid": []},
        }
        aliases = {raw: (current, "semantic")}

        merged = retain_base_alias_evidence(
            {raw: (old, "semantic")}, evidence, aliases
        )

        self.assertEqual(merged, 1)
        self.assertEqual(evidence[current]["prefer"], [positive])
        self.assertEqual(aliases[raw], (current, "semantic"))


if __name__ == "__main__":
    unittest.main()
