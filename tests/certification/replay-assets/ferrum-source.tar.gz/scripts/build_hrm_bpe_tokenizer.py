#!/usr/bin/env python3
"""Train a BPE tokenizer for Ferrum HRM direct datasets.

The tokenizer is trained on HRM JSONL rows with fields

    {"condition": "direct", "instruction": "<input>...</input>", "response": "..."}

and then augmented with deterministic atomic tokens that matter for Ferrum:

* XML tags such as ``<trsInput>`` and ``</trsInput>``;
* canonical function and variable names such as ``f0`` and ``x0``;
* Ferrum strategy atoms and parameter names such as ``poly``, ``matrix``,
  ``graph``, ``size-change``, ``max-constant``, and ``max-coefficient``;
* punctuation used by strategy labels.

Complete response labels are intentionally not added as atomic tokens. Keeping
``poly(max-constant=2, ...)`` decomposed lets the model share structure across
related parameter choices instead of memorizing one token per observed label.
"""

from __future__ import annotations

import argparse
import gzip
import json
import re
from collections import Counter
from pathlib import Path
from typing import Iterable, Iterator

from tokenizers import AddedToken, Regex, Tokenizer
from tokenizers.models import BPE
from tokenizers.pre_tokenizers import Sequence, Split, WhitespaceSplit
from tokenizers.trainers import BpeTrainer
from transformers import PreTrainedTokenizerFast


XML_TAG_RE = re.compile(r"</?[A-Za-z_][A-Za-z0-9_.:-]*\s*/?>")
CANONICAL_SYMBOL_RE = re.compile(r"\b[fx][0-9]+\b")
STRATEGY_WORD_RE = re.compile(r"[A-Za-z][A-Za-z0-9_-]*")

BASE_SPECIAL_TOKENS = ["[PAD]", "[UNK]", "[BOS]", "[EOS]", "[SEP]"]
BASE_STRATEGY_TOKENS = [
    "solved",
    "transformed_strong",
    "transformed_weak",
    "failed",
    "timeout",
    "poly",
    "sat-poly",
    "rational-poly",
    "weak-poly",
    "max-poly",
    "matrix",
    "kbo",
    "graph",
    "size-change",
    "subterm",
    "path-order",
    "path-order-af",
    "match-bounds",
    "relative-match-bounds",
    "symbol-weights",
    "srs-length",
    "srs-weighted-length",
    "srs-weighted-rule-removal",
    "semantic-labeling",
    "uncurry",
    "rewrite",
    "nontermination",
    "direct-loop",
    "srs-loop",
    "variable-condition",
    "loop",
    "dp-nonloop",
    "llm",
    "termination",
    "narrow",
    "instantiate",
    "forward-instantiate",
    "min-constant",
    "max-constant",
    "max-coefficient",
    "symbols",
    "arity",
    "dim",
    "weight",
    "max-weight",
    "max-bound",
    "max-words",
    "max-states",
    "per-pair",
    "max-per-pair",
    "denominator",
    "alternatives",
]
BASE_ATOMIC_TOKENS = ["f", "x", "(", ")", ",", "=", ";", ":", "+", "-"]


def open_text(path: Path):
    return gzip.open(path, "rt", encoding="utf-8") if path.suffix == ".gz" else path.open("r", encoding="utf-8")


def iter_rows(paths: Iterable[Path], limit: int | None = None) -> Iterator[dict[str, str]]:
    seen = 0
    for path in paths:
        with open_text(path) as source:
            for line in source:
                row = json.loads(line)
                if isinstance(row.get("instruction"), str) and isinstance(row.get("response"), str):
                    yield row
                    seen += 1
                    if limit is not None and seen >= limit:
                        return


def iter_training_texts(paths: list[Path], limit: int | None = None) -> Iterator[str]:
    for row in iter_rows(paths, limit):
        yield row["instruction"]
        yield row["response"]


def collect_atomic_tokens(paths: list[Path], limit: int | None = None) -> tuple[list[str], dict[str, int]]:
    counts: Counter[str] = Counter()
    for row in iter_rows(paths, limit):
        for field in (row["instruction"], row["response"]):
            counts.update(XML_TAG_RE.findall(field))
            counts.update(CANONICAL_SYMBOL_RE.findall(field))
        counts.update(STRATEGY_WORD_RE.findall(row["response"]))
    for token in BASE_STRATEGY_TOKENS + BASE_ATOMIC_TOKENS:
        counts[token] += 1

    special = set(BASE_SPECIAL_TOKENS)
    atomic = sorted(token for token in counts if token and token not in special)
    summary = {
        "xml_tag_tokens": sum(1 for token in atomic if XML_TAG_RE.fullmatch(token)),
        "canonical_symbol_tokens": sum(1 for token in atomic if CANONICAL_SYMBOL_RE.fullmatch(token)),
        "strategy_or_word_tokens": sum(1 for token in atomic if STRATEGY_WORD_RE.fullmatch(token)),
        "punctuation_tokens": sum(1 for token in atomic if token in BASE_ATOMIC_TOKENS),
        "atomic_tokens": len(atomic),
    }
    return atomic, summary


def write_text_list(path: Path, values: list[str]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text("\n".join(values) + "\n", encoding="utf-8")


def build_tokenizer(args: argparse.Namespace) -> dict[str, object]:
    input_paths = [Path(path) for path in args.input]
    out_dir = Path(args.out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)

    atomic_tokens, atomic_summary = collect_atomic_tokens(input_paths, args.limit)

    tokenizer = Tokenizer(BPE(unk_token="[UNK]"))
    tokenizer.pre_tokenizer = Sequence(
        [
            Split(Regex(r"</?[A-Za-z_][A-Za-z0-9_.:-]*\s*/?>"), behavior="isolated"),
            Split(Regex(r"\b[fx][0-9]+\b"), behavior="isolated"),
            Split(Regex(r"[A-Za-z][A-Za-z0-9_-]*"), behavior="isolated"),
            Split(Regex(r"[(),=;:+-]"), behavior="isolated"),
            WhitespaceSplit(),
        ]
    )

    trainer = BpeTrainer(
        vocab_size=args.vocab_size,
        min_frequency=args.min_frequency,
        special_tokens=BASE_SPECIAL_TOKENS,
        show_progress=not args.no_progress,
    )
    tokenizer.train_from_iterator(iter_training_texts(input_paths, args.limit), trainer=trainer)
    added_count = tokenizer.add_tokens([AddedToken(token, normalized=False, special=False) for token in atomic_tokens])

    tokenizer_path = out_dir / "tokenizer.json"
    tokenizer.save(str(tokenizer_path))
    fast = PreTrainedTokenizerFast(
        tokenizer_object=tokenizer,
        unk_token="[UNK]",
        pad_token="[PAD]",
        bos_token="[BOS]",
        eos_token="[EOS]",
        sep_token="[SEP]",
    )
    fast.save_pretrained(out_dir)
    (out_dir / "special_tokens_map.json").write_text(
        json.dumps(
            {
                "unk_token": "[UNK]",
                "pad_token": "[PAD]",
                "bos_token": "[BOS]",
                "eos_token": "[EOS]",
                "sep_token": "[SEP]",
            },
            indent=2,
            sort_keys=True,
        ),
        encoding="utf-8",
    )
    write_text_list(out_dir / "atomic_tokens.txt", atomic_tokens)

    vocab = tokenizer.get_vocab()
    missing_atomic = sorted(token for token in atomic_tokens if token not in vocab)
    summary: dict[str, object] = {
        "inputs": [str(path) for path in input_paths],
        "limit": args.limit,
        "vocab_size_requested": args.vocab_size,
        "min_frequency": args.min_frequency,
        "tokenizer_json": str(tokenizer_path),
        "atomic_tokens_file": str(out_dir / "atomic_tokens.txt"),
        "base_special_tokens": BASE_SPECIAL_TOKENS,
        "added_atomic_tokens": added_count,
        "final_vocab_size": tokenizer.get_vocab_size(with_added_tokens=True),
        "missing_atomic_tokens": missing_atomic,
        **atomic_summary,
    }
    (out_dir / "summary.json").write_text(json.dumps(summary, indent=2, sort_keys=True), encoding="utf-8")
    return summary


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--input", nargs="+", required=True, help="HRM direct JSONL/JSONL.gz files")
    parser.add_argument("--out-dir", required=True, help="output tokenizer directory")
    parser.add_argument("--vocab-size", type=int, default=32000)
    parser.add_argument("--min-frequency", type=int, default=2)
    parser.add_argument("--limit", type=int, help="optional row limit for debugging")
    parser.add_argument("--no-progress", action="store_true")
    args = parser.parse_args()

    summary = build_tokenizer(args)
    print(json.dumps(summary, indent=2, sort_keys=True), flush=True)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
