#!/usr/bin/env python3
"""Re-execute one recorded local action and bounded native child processors."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import subprocess
from materialize_processor_event_input import find_inline_cpf


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--events', type=Path, required=True)
    p.add_argument('--atom-digest', required=True)
    p.add_argument('--ferrum', required=True)
    p.add_argument('--output', type=Path, required=True)
    p.add_argument('--terminal', action='append', default=[])
    args = p.parse_args()
    events = list(map(json.loads, args.events.read_text().splitlines()))
    event = next(e for e in events if hashlib.sha256(
        e.get('strategy_atom', '').encode()).hexdigest().startswith(args.atom_digest))
    atom = event['strategy_atom']
    if atom.startswith(('exact-dp-proof(', 'exact-trs-proof(')):
        raise ValueError('composite termination proof forbidden')
    found = find_inline_cpf(events, event['input']['problem_key'])
    if found is None:
        raise ValueError('missing recorded input')
    args.output.mkdir(parents=True, exist_ok=False)
    observed = []
    def probe(cpf, atom, directory):
        directory.mkdir()
        source = directory/'input.cpf'
        source.write_text(cpf)
        (directory/'atom.fs').write_text(atom)
        env = dict(os.environ, RAYON_NUM_THREADS='2')
        result = subprocess.run([args.ferrum, 'probe-cpf', str(source),
            '--strategy-file', str(directory/'atom.fs'), '--timeout-ms', '60000'], env=env,
            capture_output=True, text=True, timeout=65)
        (directory/'stdout').write_text(result.stdout)
        (directory/'stderr').write_text(result.stderr)
        if result.returncode:
            return []
        record = json.loads(result.stdout)
        outcome = record.get('typed_outcome')
        print(directory.name, outcome, flush=True)
        if outcome in ('Transformed', 'Solved'):
            observed.append(dict(strategy_atom=atom, outcome=outcome.lower(),
                credit={'status':'diagnostic-only'},
                input=dict(cpf=cpf, problem_key=hashlib.sha256(cpf.strip().encode()).hexdigest()),
                witness=dict(residuals=record.get('children', []))))
        return record.get('children', [])
    children = probe(found[1], atom, args.output/'transition')
    for index, child in enumerate(children):
        for number, terminal in enumerate(args.terminal):
            probe(child['cpf'], terminal, args.output/f'child-{index}-{number}')
    with (args.output/'events.jsonl').open('x') as stream:
        for row in observed:
            print(json.dumps(row), file=stream)


if __name__ == '__main__':
    main()
