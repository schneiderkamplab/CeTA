#!/usr/bin/env python3
"""Bind certified terminal aliases to exact native graph-child addresses.

Requires full-context canonical equality and a twice-checked source terminal.
No context stripping or whole-proof action is permitted.
"""
import argparse
from concurrent.futures import ThreadPoolExecutor, as_completed
import hashlib
import json
from pathlib import Path
import ijson
from build_credited_status_map_dataset import canonicalize_with_ferrum


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--probe', type=Path, required=True)
    p.add_argument('--terminals', type=Path, required=True)
    p.add_argument('--output', type=Path, required=True)
    p.add_argument('--ferrum', required=True)
    p.add_argument('--jobs', type=int, default=8)
    args = p.parse_args()
    args.output.mkdir(parents=True, exist_ok=False)
    approved = set()
    for line in (args.terminals/'results.jsonl').open():
        row = json.loads(line)
        if not row.get('certified') or row.get('deterministic_rechecks') != 2:
            continue
        proof = Path(row['proof'])
        if hashlib.sha256(proof.read_bytes()).hexdigest() != row['sha256']:
            raise RuntimeError(f'Stale certificate: {proof}')
        if any('CERTIFIED' not in (proof.parent/f'ceta-{repeat}.log').read_text().splitlines()
               for repeat in (1, 2)):
            raise RuntimeError(f'Missing source certification: {proof}')
        approved.update(row['keys'])
    records, witnesses = {}, {}
    for line in (args.terminals/'oracle.jsonl').open():
        row = json.loads(line)
        if row.get('schema') == 'ferrum.utility-guidance.witness.v1':
            witnesses[row['witness_id']] = row
        elif row.get('problem_key') in approved:
            records[row['problem_key']] = row

    def bind(index, cpf):
        path = args.output/f'{index}.cpf'
        path.write_text(cpf)
        key = hashlib.sha256(cpf.strip().encode()).hexdigest()
        try:
            canonical = canonicalize_with_ferrum(cpf, args.ferrum, 60)
        except Exception as error:
            return dict(index=index, problem_key=key, error=type(error).__name__)
        source = hashlib.sha256(canonical.strip().encode()).hexdigest()
        prefer = []
        for entry in records.get(source, {}).get('prefer', []):
            atom = witnesses.get(entry.get('candidate_ref'), {}).get('candidate', entry.get('candidate', ''))
            if atom.startswith('exact-size-change(') and entry.get('certified_count', 0) >= 2 and entry.get('status') == 'solved':
                prefer.append(entry)
        return dict(index=index, problem_key=key, source_key=source, prefer=prefer)

    outcome, futures, rows = None, [], []
    with ThreadPoolExecutor(max_workers=args.jobs) as pool:
        with args.probe.open('rb') as stream:
            for prefix, event, value in ijson.parse(stream):
                if prefix == 'children.item.cpf' and event == 'string':
                    futures.append(pool.submit(bind, len(futures), value))
                elif prefix == 'typed_outcome' and event == 'string':
                    outcome = value
        for future in as_completed(futures):
            rows.append(future.result())
    if outcome != 'Transformed':
        raise RuntimeError('Native graph probe was not a successful transformation')
    with (args.output/'oracle.jsonl').open('x') as out:
        for key in sorted(witnesses):
            print(json.dumps(witnesses[key]), file=out)
        for row in sorted(rows, key=lambda row: row['problem_key']):
            if row.get('prefer'):
                print(json.dumps(dict(schema='ferrum.utility-guidance.v2', problem_key=row['problem_key'],
                    certification_source_key=row['source_key'], prefer=row['prefer'], possible=[], avoid=[], timeout=[])), file=out)
    (args.output/'report.json').write_text(json.dumps(rows, indent=2))
    print(json.dumps(dict(children=len(rows), certified_aliases=sum(bool(row.get('prefer')) for row in rows))))


if __name__ == '__main__':
    main()
