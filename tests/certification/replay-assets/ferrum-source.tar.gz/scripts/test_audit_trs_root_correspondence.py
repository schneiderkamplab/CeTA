import unittest
import io
import xml.etree.ElementTree as ET
from audit_trs_root_correspondence import compare, read_ari, root_metadata


class TrsCorrespondenceTests(unittest.TestCase):
    source = '(format TRS) (fun f 1) (fun |0| 0) (rule (f X) X)'
    cpf = '''<certificationProblem><input><trsInput><trs><rules>
    <rule><funapp><name>f</name><var>Y</var></funapp><var>Y</var></rule>
    </rules></trs></trsInput></input><property><termination/></property>
    <answer><yes/></answer></certificationProblem>'''
    inner = '<strategy><innermost><nfs>true</nfs></innermost></strategy>'

    def test_streamed_metadata_preserves_obligations_and_checks_eof(self):
        expanded = self.cpf.replace('</certificationProblem>',
            '<proof>' + '<node><child/></node>' * 10000 + '</proof></certificationProblem>')
        root = root_metadata(io.BytesIO(expanded.encode()))
        self.assertEqual(len(root.find('proof')), 0)
        self.assertEqual(compare(self.source, root, 'yes', 'SRS_Standard'),
                         compare(self.source, self.cpf, 'yes', 'SRS_Standard'))
        duplicate = expanded.replace('</answer>', '</answer><answer><yes/></answer>')
        with self.assertRaises(ValueError):
            compare(self.source, root_metadata(io.BytesIO(duplicate.encode())), 'yes', 'SRS_Standard')
        with self.assertRaises(ET.ParseError):
            root_metadata(io.BytesIO((expanded + '<broken').encode()))

    def test_full_alpha_renaming_and_unused_symbols(self):
        result = compare(self.source, self.cpf, 'yes', 'TRS_Standard')
        self.assertTrue(result['rule_multiset_equal'])
        self.assertEqual(result['unused_benchmark_declarations'], ['0'])

    def test_srs_checks_the_same_full_rewrite_relation(self):
        self.assertTrue(compare(self.source, self.cpf, 'yes', 'SRS_Standard')['strategy_equal'])
        for modified in (self.cpf.replace('</trsInput>', self.inner + '</trsInput>'),
                         self.cpf.replace('<name>f</name>', '<name>other</name>'),
                         self.cpf.replace('<yes/>', '<no/>')):
            with self.assertRaises(ValueError):
                compare(self.source, modified, 'yes', 'SRS_Standard')

    def test_innermost(self):
        cpf = self.cpf.replace('</trsInput>', self.inner + '</trsInput>')
        self.assertTrue(compare(self.source, cpf, 'yes', 'TRS_Innermost')['strategy_equal'])
        with self.assertRaises(ValueError):
            compare(self.source, cpf, 'yes', 'TRS_Standard')
        for modified in (self.cpf, cpf.replace('<nfs>true</nfs>', ''), cpf.replace('true', 'false')):
            with self.assertRaises(ValueError):
                compare(self.source, modified, 'yes', 'TRS_Innermost')

    def test_rule_variable_sharing(self):
        with self.assertRaises(ValueError):
            compare(self.source, self.cpf.replace('</funapp><var>Y', '</funapp><var>Z'), 'yes', 'TRS_Standard')

    def test_symbol_renaming_is_not_allowed(self):
        with self.assertRaises(ValueError):
            compare(self.source, self.cpf.replace('<name>f</name>', '<name>g</name>'), 'yes', 'TRS_Standard')

    def test_polarity_and_property(self):
        for cpf in (self.cpf.replace('<yes/>', '<no/>'), self.cpf.replace('<termination/>', '<confluence/>'),
                    self.cpf.replace('</answer>', '</answer><answer><yes/></answer>')):
            with self.assertRaises(ValueError):
                compare(self.source, cpf, 'yes', 'TRS_Standard')

    def test_context_cannot_be_added(self):
        for extra in ('<relativeRules><rules/></relativeRules>', '<strategy><innermostLhss/></strategy>', '<trs><rules/></trs>'):
            with self.assertRaises(ValueError):
                compare(self.source, self.cpf.replace('</trsInput>', extra + '</trsInput>'), 'yes', 'TRS_Standard')

    def test_quoted_spelling_only(self):
        source = '(format TRS) (fun |0| 0) (rule |0| |0|)'
        cpf = self.cpf.replace('<rule><funapp><name>f</name><var>Y</var></funapp><var>Y</var></rule>',
                               '<rule><funapp><name>|0|</name></funapp><funapp><name>|0|</name></funapp></rule>')
        self.assertTrue(compare(source, cpf, 'yes', 'TRS_Standard')['rule_multiset_equal'])
        with self.assertRaisesRegex(ValueError, 'distinct CPF symbols'):
            compare(source, cpf.replace('<name>|0|</name>', '<name>0</name>', 1), 'yes', 'TRS_Standard')

    def test_strict_format_and_arity(self):
        for source in ('(format CSTRS)', '(format TRS) (format TRS)',
                       '(format TRS) (fun f 1) (rule f X)', '(format TRS) (fun f 1) (fun f 1)'):
            with self.assertRaises(ValueError):
                read_ari(source)

    def test_innermost_nfs_not_assumed_redundant_for_extra_variables(self):
        cpf = self.cpf.replace('</trsInput>', self.inner + '</trsInput>')
        with self.assertRaisesRegex(ValueError, 'nfs equivalence'):
            compare(self.source.replace('(rule (f X) X)', '(rule (f X) Z)'), cpf, 'yes', 'TRS_Innermost')


if __name__ == '__main__':
    unittest.main()
