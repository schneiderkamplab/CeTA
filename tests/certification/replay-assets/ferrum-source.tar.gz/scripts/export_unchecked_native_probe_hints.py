#!/usr/bin/env python3
"""Export native probe actions as UNCHECKED search hints, never positive evidence.

Useful when a local CPF cannot express a source-relative obligation. Only a
subsequent complete, independently certified root replay can establish a gain.
Unlike export_witness_free_probe_hints.py this does not certify anything.
"""
import argparse
import hashlib
import json
from export_witness_free_probe_hints import collect
from probe_witness_free_oracle import replace


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--events', required=True)
    parser.add_argument('--output', required=True)
    parser.add_argument('--replace-family')
    parser.add_argument('--native-action')
    parser.add_argument('--prioritize', action='store_true')
    args = parser.parse_args()
    if bool(args.replace_family) != bool(args.native_action):
        parser.error('--replace-family and --native-action must be provided together')
    if args.native_action and (replace(args.native_action) != args.native_action
                              or 'exact-' in args.native_action or 'hex=' in args.native_action):
        parser.error('override must be a native action without a supplied witness')
    with open(args.events) as source:
        events = list(map(json.loads, source))
    if args.native_action:
        for event in events:
            if event.get('strategy_atom', '').split('(', 1)[0] == args.replace_family:
                event['strategy_atom'] = args.native_action
    rows = collect(events)
    for row in rows:
        if args.prioritize:
            row['replay_order'] = [hashlib.sha256(item['candidate'].encode()).hexdigest()
                                   for item in row['possible']]
        for item in row['possible']:
            assert item['certified_count'] == item['solved_count'] == 0
            item['evidence_origin'] = 'unchecked-native-probe; root certification required'
    with open(args.output, 'x') as target:
        for row in rows:
            print(json.dumps(row), file=target)
    print(json.dumps(dict(states=len(rows), certified_roots=0, certified_states=0)))


if __name__ == '__main__':
    main()
