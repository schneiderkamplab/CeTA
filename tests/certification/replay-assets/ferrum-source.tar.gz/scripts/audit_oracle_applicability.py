#!/usr/bin/env python3
"""Audit executable positive oracle guidance on certified fallback paths."""

from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path
import sqlite3

from build_credited_status_map_dataset import compact_xml_for_key


POSITIVE = {"solved", "transformed_strong", "transformed_weak"}


def load_oracle(path: Path) -> dict[str, dict]:
    records: dict[str, dict] = {}
    witnesses: dict[str, str] = {}
    for line in path.read_text(encoding="utf-8").splitlines():
        if not line.strip():
            continue
        row = json.loads(line)
        witness_id = row.get("witness_id")
        candidate = row.get("candidate")
        if isinstance(witness_id, str) and isinstance(candidate, str):
            witnesses[witness_id] = candidate
        # Large exact atoms are interned as content-addressed witness rows in
        # production oracles. They are metadata, not state records.
        problem_key = row.get("problem_key")
        if isinstance(problem_key, str):
            records[problem_key] = row
    for row in records.values():
        for bucket in ("prefer", "possible", "avoid", "timeout"):
            for item in row.get(bucket, []):
                reference = item.get("candidate_ref")
                if (
                    item.get("candidate") is None
                    and isinstance(reference, str)
                    and reference in witnesses
                ):
                    item["candidate"] = witnesses[reference]
    return records


def resolved_record(records: dict[str, dict], key: str) -> dict | None:
    seen: set[str] = set()
    while key not in seen:
        seen.add(key)
        row = records.get(key)
        if row is None:
            return None
        canonical = row.get("canonical_problem_key")
        if not canonical:
            return row
        key = str(canonical)
    return None


def positive_atoms(row: dict | None) -> list[str]:
    if row is None:
        return []
    return [
        str(item.get("candidate") or item.get("candidate_ref"))
        for bucket in ("prefer", "possible")
        for item in row.get(bucket, [])
        if item.get("status") in POSITIVE
        and (item.get("candidate") is not None or item.get("candidate_ref") is not None)
    ]


def positive_atoms_for_input(records: dict[str, dict], key: str, cpf: str) -> list[str]:
    raw_atoms = positive_atoms(resolved_record(records, key))
    # Match UtilityGuidanceLookup::predict: byte-exact strong evidence is more
    # specific than a formatting alias and suppresses the latter's candidates.
    if raw_atoms:
        raw_record = resolved_record(records, key)
        if raw_record is not None and any(
            item.get("status") in {"solved", "transformed_strong"}
            for bucket in ("prefer", "possible")
            for item in raw_record.get(bucket, [])
        ):
            return raw_atoms
    atoms = list(raw_atoms)
    structural_key = hashlib.sha256(
        compact_xml_for_key(cpf).encode("utf-8")
    ).hexdigest()
    if structural_key != key:
        atoms.extend(positive_atoms(resolved_record(records, structural_key)))
    return list(dict.fromkeys(atoms))


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--details", type=Path, required=True)
    parser.add_argument("--oracle", type=Path, required=True)
    parser.add_argument("--campaign-sqlite", type=Path)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--missing-jsonl", type=Path, required=True)
    args = parser.parse_args()

    records = load_oracle(args.oracle)
    details = json.loads(args.details.read_text(encoding="utf-8"))
    roots: dict[str, tuple[str, str]] = {}
    evidenced_nodes: dict[str, str] = {}
    origins: dict[str, set[str]] = {}
    for result in details:
        if result.get("status") != "yes" or not result.get("certified"):
            continue
        artifact = Path(result["artifact_dir"])
        events_path = artifact / "processor-events.jsonl"
        root_key = None
        for line in events_path.read_text(encoding="utf-8").splitlines():
            event = json.loads(line)
            key = event.get("input", {}).get("problem_key")
            cpf = event.get("input", {}).get("cpf")
            if not isinstance(key, str) or not isinstance(cpf, str):
                continue
            if root_key is None:
                root_key = (key, cpf)
            if (
                event.get("outcome") in {"solved", "transformed"}
                and event.get("strategy_atom") != "empty"
            ):
                evidenced_nodes.setdefault(key, cpf)
                origins.setdefault(key, set()).add(str(result["path"]))
        if root_key is not None:
            roots[str(result["path"])] = root_key

    missing_roots = {
        path: key
        for path, (key, cpf) in roots.items()
        if not positive_atoms_for_input(records, key, cpf)
    }
    missing_nodes = sorted(
        key
        for key, cpf in evidenced_nodes.items()
        if not positive_atoms_for_input(records, key, cpf)
    )
    rejected_context_losing: dict[str, list[dict]] = {}
    if args.campaign_sqlite is not None:
        with sqlite3.connect(args.campaign_sqlite) as connection:
            tables = {
                row[0]
                for row in connection.execute(
                    "SELECT name FROM sqlite_master WHERE type='table'"
                )
            }
            for key in missing_nodes:
                if {"states", "trials"} <= tables:
                    rows = connection.execute(
                        """
                        SELECT t.candidate, t.outcome, t.certification_status
                        FROM states s JOIN trials t ON t.problem_key=s.raw_hash
                        WHERE s.source_problem_key=?
                          AND t.outcome IN ('solved','transformed')
                        """,
                        (key,),
                    )
                elif {"problem_aliases", "candidates"} <= tables:
                    rows = connection.execute(
                        """
                        SELECT c.candidate, c.best_status,
                               CASE WHEN c.certified_count > 0
                                    THEN 'certified-full' ELSE NULL END
                        FROM problem_aliases a
                        JOIN candidates c ON c.problem_key=a.problem_key
                        WHERE a.raw_problem_key=?
                          AND c.best_status IN
                              ('solved','transformed_strong','transformed_weak')
                        """,
                        (key,),
                    )
                else:
                    rows = []
                trials = [
                    {
                        "candidate": candidate,
                        "outcome": outcome,
                        "certification_status": certification,
                    }
                    for candidate, outcome, certification in rows
                ]
                if trials and all(
                    trial["certification_status"]
                    not in {"certified-full", "certified-fragment", "assembly-required"}
                    for trial in trials
                ):
                    rejected_context_losing[key] = trials
    actionable_missing_nodes = [
        key for key in missing_nodes if key not in rejected_context_losing
    ]
    args.output.parent.mkdir(parents=True, exist_ok=True)
    report = {
        "schema": "ferrum.oracle-applicability-audit.v1",
        "certified_yes_roots": len(roots),
        "roots_with_positive_guidance": len(roots) - len(missing_roots),
        "missing_roots": len(missing_roots),
        "successful_path_nodes": len(evidenced_nodes),
        "path_nodes_with_positive_guidance": len(evidenced_nodes) - len(missing_nodes),
        "missing_path_nodes": len(missing_nodes),
        "rejected_context_losing_historical_nodes": len(rejected_context_losing),
        "actionable_missing_path_nodes": len(actionable_missing_nodes),
    }
    args.output.write_text(
        json.dumps(report, indent=2, sort_keys=True) + "\n", encoding="utf-8"
    )
    with args.missing_jsonl.open("w", encoding="utf-8") as stream:
        for key in missing_nodes:
            stream.write(
                json.dumps(
                    {
                        "problem_key": key,
                        "origins": sorted(origins.get(key, set())),
                        "classification": (
                            "rejected-context-losing-historical-event"
                            if key in rejected_context_losing
                            else "missing-positive-guidance"
                        ),
                        "replay_trials": rejected_context_losing.get(key, []),
                    },
                    sort_keys=True,
                )
                + "\n"
            )
    print(json.dumps(report, sort_keys=True))
    return int(bool(missing_roots or actionable_missing_nodes))


if __name__ == "__main__":
    raise SystemExit(main())
