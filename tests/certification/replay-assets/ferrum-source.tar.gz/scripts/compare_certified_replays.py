#!/usr/bin/env python3
"""Compare exact input and certified-decision sets, not only replay totals."""
import argparse
from collections import Counter
import json
from pathlib import Path


def compare(baseline, current, category=None):
    if category is not None:
        baseline = [row for row in baseline if row.get('category') == category]
        current = [row for row in current if row.get('category') == category]
        if not baseline or not current:
            raise ValueError('selected category must be nonempty in both replays')
    def index(rows):
        result = {}
        for row in rows:
            key = row['path'].split('TPDB-ARI/')[-1]
            if key in result:
                raise ValueError(f'duplicate input: {key}')
            result[key] = row
        return result
    old, new = index(baseline), index(current)
    certified_old = {k for k, r in old.items() if r.get('certified')}
    certified_new = {k for k, r in new.items() if r.get('certified')}
    return dict(inputs=len(new), certified=len(certified_new),
        certified_statuses=dict(Counter(new[k]['status'] for k in certified_new)),
        statuses=dict(Counter(r['status'] for r in new.values())),
        missing_inputs=sorted(old.keys()-new.keys()), extra_inputs=sorted(new.keys()-old.keys()),
        losses=sorted(certified_old-certified_new), gains=sorted(certified_new-certified_old),
        polarity_changes=sorted(k for k in certified_old & certified_new if old[k]['status'] != new[k]['status']),
        uncertified_decisions=sorted(k for k, r in new.items() if r['status'] in ('yes','no') and not r.get('certified')))


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--baseline', type=Path, required=True)
    p.add_argument('--current', type=Path, required=True)
    p.add_argument('--output', type=Path, required=True)
    p.add_argument('--category', help='Compare only this category in both replay manifests')
    args = p.parse_args()
    report = compare(json.loads(args.baseline.read_text()), json.loads(args.current.read_text()), args.category)
    with args.output.open('x') as stream:
        json.dump(report, stream, indent=2)
    print(json.dumps(report))
    if any(report[k] for k in ('missing_inputs','extra_inputs','losses','polarity_changes','uncertified_decisions')):
        raise SystemExit(1)


if __name__ == '__main__':
    main()
