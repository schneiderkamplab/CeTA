#!/usr/bin/env python3
"""Independently certify native terminal steps twice before solved promotion."""
import argparse
from concurrent.futures import ThreadPoolExecutor, as_completed
import hashlib
import json
from pathlib import Path
import subprocess
from build_credited_status_map_dataset import canonicalize_with_ferrum
from export_canonical_modular_aliases import PORTABLE


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--root', type=Path, required=True)
    p.add_argument('--output', type=Path, required=True)
    p.add_argument('--ferrum', required=True)
    p.add_argument('--ceta', required=True)
    p.add_argument('--jobs', type=int, default=8)
    p.add_argument('--native-inputs', action='store_true', help='Read numbered native child .cpf files.')
    p.add_argument('--witness-oracle', type=Path)
    p.add_argument('--raw-only', action='store_true')
    p.add_argument('--candidate', action='append', default=[],
                   help='Additional native terminal actions to recompute on the complete live state.')
    p.add_argument('--include-open-terminals', action='store_true')
    p.add_argument('--probe-timeout', type=float, default=60)
    args = p.parse_args()
    args.output.mkdir(parents=True, exist_ok=False)
    candidate_atoms = []
    if args.native_inputs:
        if not args.witness_oracle:
            p.error('--native-inputs requires --witness-oracle')
        for line in args.witness_oracle.open():
            row = json.loads(line)
            if row.get('candidate', '').startswith('exact-size-change('):
                candidate_atoms.append(row['candidate'])
        candidate_atoms = sorted(set(candidate_atoms))
        tasks = sorted(int(path.stem) for path in args.root.glob('*.cpf') if path.stem.isdigit())
    else:
        with (args.root/'results.jsonl').open() as source_rows:
            rows = [json.loads(line) for line in source_rows]
        tasks = [row['index'] for row in rows if row.get('outcome') == 'Solved'
                 or (args.include_open_terminals and row.get('processor') in
                     {'sizeChangeProc', 'subtermProc', 'pIsEmpty', 'rIsEmpty', 'bounds', 'loop', 'nonLoop'})]

    def certify(index):
        source, output = args.root/str(index), args.output/str(index)
        output.mkdir()
        input_path = args.root/f'{index}.cpf' if args.native_inputs else source/'input.cpf'
        atoms = candidate_atoms if args.native_inputs else [(source/'atom.fs').read_text().strip()]
        atoms = list(dict.fromkeys(atoms + args.candidate))
        cpf = input_path.read_text()
        try:
            for attempt, atom in enumerate(atoms):
                if atom.startswith(('exact-dp-proof(', 'exact-trs-proof(')):
                    continue
                atom_path = output/f'atom-{attempt}.fs'
                atom_path.write_text(atom)
                proof = output/f'proof-{attempt}.cpf.xml'
                probe = output/f'probe-{attempt}.json'
                with probe.open('x') as out, (output/f'probe-{attempt}.log').open('x') as err:
                    proc = subprocess.run([args.ferrum, 'probe-cpf', str(input_path),
                        '--strategy-file', str(atom_path), '--timeout-ms', str(int(args.probe_timeout * 1000)),
                        '--cpf', str(proof)], stdout=out, stderr=err, timeout=args.probe_timeout + 5)
                if not proc.returncode and proof.exists() and json.loads(probe.read_text()).get('typed_outcome') == 'Solved':
                    digest = hashlib.sha256(proof.read_bytes()).hexdigest()
                    accepted = True
                    for repeat in (1, 2):
                        checked = subprocess.run([args.ceta, str(proof)], capture_output=True, text=True, timeout=60)
                        (output/f'ceta-{attempt}-{repeat}.log').write_text(checked.stdout + checked.stderr)
                        if checked.returncode or 'CERTIFIED' not in checked.stdout.splitlines():
                            accepted = False
                            break
                    if hashlib.sha256(proof.read_bytes()).hexdigest() != digest:
                        raise RuntimeError('Certificate changed during checking')
                    if accepted:
                        break
            else:
                return dict(index=index, certified=False, reason='no candidate certified the native state')
            if input_path.read_text() != cpf:
                return dict(index=index, certified=False, reason='source input changed')
            keys = {hashlib.sha256(cpf.strip().encode()).hexdigest()}
            if not args.raw_only and (atom.startswith(PORTABLE) or atom in {'size-change', 'subterm', 'graph', 'empty'}):
                canonical = canonicalize_with_ferrum(cpf, args.ferrum, 60)
                keys.add(hashlib.sha256(canonical.strip().encode()).hexdigest())
            return dict(index=index, certified=True, proof=str(proof), sha256=digest,
                        deterministic_rechecks=2, keys=sorted(keys), atom=atom)
        except subprocess.TimeoutExpired:
            return dict(index=index, certified=False, reason='probe/check/canonicalization timeout')

    states, witnesses, results = {}, {}, []
    with ThreadPoolExecutor(max_workers=args.jobs) as pool, (args.output/'results.jsonl').open('x') as log:
        for future in as_completed([pool.submit(certify, index) for index in tasks]):
            row = future.result()
            if row['certified']:
                atom = row.pop('atom')
                reference = hashlib.sha256(atom.encode()).hexdigest()
                if atom.startswith('exact-'):
                    witnesses[reference] = atom
                    candidate = dict(candidate_ref=reference)
                else:
                    candidate = dict(candidate=atom)
                for key in row['keys']:
                    states.setdefault(key, {})[reference] = dict(candidate, status='solved',
                        utility_score=100000, attempts=1, certified_count=2, solved_count=1,
                        transformed_count=0, failed_count=0, timeout_count=0, best_elapsed_ms=0)
            results.append(row)
            print(json.dumps(row), file=log, flush=True)
    with (args.output/'oracle.jsonl').open('x') as out:
        for reference, atom in sorted(witnesses.items()):
            print(json.dumps(dict(schema='ferrum.utility-guidance.witness.v1', witness_id=reference, candidate=atom)), file=out)
        for key, entries in sorted(states.items()):
            print(json.dumps(dict(schema='ferrum.utility-guidance.v2', problem_key=key,
                prefer=[entries[reference] for reference in sorted(entries)],
                possible=[], avoid=[], timeout=[])), file=out)
    print(json.dumps(dict(checked=len(results), certified=sum(row['certified'] for row in results), states=len(states))))


if __name__ == '__main__':
    main()
