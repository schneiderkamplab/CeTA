import json
import unittest
from probe_witness_free_oracle import replace
from probe_witness_free_oracle import cpf_polynomial_bounds, cpf_scalar_matrix_bounds
import xml.etree.ElementTree as ET


class WitnessFreeTests(unittest.TestCase):
    def test_standalone_polynomial_interpretation_bounds(self):
        node = ET.fromstring('<interpretation><type><polynomial><domain><naturals/></domain><degree>1</degree></polynomial></type><interpret><name>private</name><arity>1</arity><sum><variable>1</variable><integer>130</integer></sum></interpret></interpretation>')
        self.assertEqual(cpf_polynomial_bounds(node), 'poly(max-constant=130,max-coefficient=1,max-symbols=1,max-arity=1)')

    def test_scalar_rational_matrix_bounds_preserve_domain(self):
        node = ET.fromstring('<interpretation><type><matrixInterpretation><domain><rationals><delta><rational><numerator>1</numerator><denominator>4</denominator></rational></delta></rationals></domain><dimension>1</dimension></matrixInterpretation></type><interpret><name>private</name><arity>1</arity><sum><product><matrix><vector><rational><numerator>1</numerator><denominator>2</denominator></rational></vector></matrix><variable>1</variable></product><vector><integer>1</integer></vector></sum></interpret></interpretation>')
        original = ET.tostring(node)
        self.assertEqual(cpf_scalar_matrix_bounds(node), 'rat-poly(max-constant=2,max-coefficient=1,max-symbols=1,max-arity=1,denominator=2,delta-denominator=4)')
        self.assertEqual(ET.tostring(node), original)
        node.find('type/matrixInterpretation/dimension').text = '2'
        self.assertIsNone(cpf_scalar_matrix_bounds(node))

    def test_native_q_initialization_discards_the_selected_state(self):
        atom = 'exact-innermost-lhss-dp(hex=' + json.dumps('<dpInput>private state</dpInput>').encode().hex() + ')'
        self.assertEqual(replace(atom), 'innermost-lhss-dp')

    def test_cpf_matrix_integer_domains_keep_signed_search_bounds(self):
        for domain, kind in [
            ('<integers/>', 'integer-matrix'),
            ('<arctic><domain><integers/></domain></arctic>', 'integer-arctic-matrix'),
        ]:
            xml = ('<interpretation><type><matrixInterpretation><domain>' + domain +
                   '</domain><dimension>1</dimension></matrixInterpretation></type>'
                   '<interpret><name>private</name><integer>-1</integer>'
                   '<integer>2</integer></interpret></interpretation>')
            atom = 'exact-red-pair(hex=' + json.dumps(['redPairUrProc', xml]).encode().hex() + ')'
            self.assertEqual(replace(atom), kind +
                '(dimension=1,min-value=-1,max-value=2,max-symbols=256,max-arity=16)')
            self.assertNotIn('private', replace(atom))

    def test_nonnegative_cpf_matrix_bounds_are_not_padded(self):
        xml = ('<interpretation><type><matrixInterpretation><domain><integers/>'
               '</domain><dimension>4</dimension></matrixInterpretation></type>'
               '<interpret><name>private</name><integer>0</integer>'
               '<integer>1</integer></interpret></interpretation>')
        atom = 'exact-red-pair(hex=' + json.dumps(['redPairProc', xml]).encode().hex() + ')'
        self.assertEqual(replace(atom),
            'matrix(dimension=4,max-constant=1,max-coefficient=1,max-symbols=256,max-arity=16)')

    def test_nontermination_discovery_discards_witnesses_and_subsets(self):
        for family, native in {
            'dp-loop': 'nontermination(dp-loop)',
            'dp-nonloop': 'nontermination(dp-nonloop)',
            'dp-no-rule-removal': 'nontermination-usable-rules',
            'trs-no-rule-removal': 'nontermination',
            'trs-nontermination-terminal': 'nontermination',
        }.items():
            payload = json.dumps(['private symbol', '<loop/>', '<residual/>']).encode().hex()
            self.assertEqual(replace(f'exact-{family}(hex={payload})'), native)
        self.assertIsNone(replace('exact-dp-nontermination-proof(hex=00)'))

    def test_conditional_order_keeps_only_coefficient_bound(self):
        payload = '<interpretation><type><polynomial><domain><naturals/></domain><degree>1</degree></polynomial></type><interpret><name>secret</name><integer>-2</integer></interpret></interpretation>'
        atom = 'exact-general-red-pair(hex=' + json.dumps([payload, [1], [1], True, '<source/>']).encode().hex() + ')'
        self.assertEqual(replace(atom), 'conditional-poly(max-coefficient=2)')
        self.assertNotIn('secret', replace(atom))
        quadratic = 'exact-general-red-pair(hex=' + json.dumps([payload.replace('<degree>1</degree>', '<degree>2</degree>'), [1], [1], True, '<source/>']).encode().hex() + ')'
        self.assertEqual(replace(quadratic), 'conditional-poly(max-coefficient=2,degree=2)')
        with_depth = payload + '<condRedPairProof><before>2</before><after>0</after></condRedPairProof>'
        self.assertEqual(replace('exact-general-red-pair(hex=' + json.dumps([with_depth, [1], [1], True, '<source/>']).encode().hex() + ')'),
                         'conditional-poly(max-coefficient=2,before=2)')
        forward = with_depth.replace('<before>2</before>', '<before>0</before>').replace('<after>0</after>', '<after>1</after>')
        self.assertEqual(replace('exact-general-red-pair(hex=' + json.dumps([forward, [1], [1], True, '<source/>']).encode().hex() + ')'),
                         'conditional-poly(max-coefficient=2,before=0,after=1)')

    def cpf_atom(self, domain, expression):
        xml = ('<interpretation><type><polynomial><domain>' + domain +
               '</domain><degree>2</degree></polynomial></type><interpret>'
               '<name>arbitrary</name><arity>1</arity>' + expression +
               '</interpret></interpretation>')
        return 'exact-red-pair(hex=' + json.dumps(['redPairProc', xml]).encode().hex() + ')'

    def test_native_cpf_polynomial_tag_and_actual_degree(self):
        atom = replace(self.cpf_atom('<naturals/>', '<variable>1</variable>'))
        self.assertEqual(atom, 'poly(max-constant=0,max-coefficient=1,max-symbols=1,max-arity=1)')

    def test_q_monotonic_affine_rule_removal_keeps_native_search_mode(self):
        ordinary = self.cpf_atom('<naturals/>', '<variable>1</variable>')
        payload = json.loads(bytes.fromhex(ordinary.split('hex=')[1][:-1]).decode())
        payload[0] = 'innermostMonoRedPairProc'
        native = replace('exact-red-pair(hex=' + json.dumps(payload).encode().hex() + ')')
        self.assertEqual(native, 'matrix(dimension=1,max-constant=0,max-coefficient=1,max-symbols=1,max-arity=1)')
        self.assertNotIn('arbitrary', native)

    def test_rational_domain_and_gap_are_not_lost(self):
        half = '<rational><numerator>1</numerator><denominator>2</denominator></rational>'
        atom = replace(self.cpf_atom('<rationals><delta>' + half + '</delta></rationals>',
                                    '<sum>' + half + '<variable>1</variable></sum>'))
        self.assertEqual(atom, 'rat-poly(max-constant=1,max-coefficient=2,max-symbols=1,max-arity=1,denominator=2,delta-denominator=2)')
        self.assertNotIn('arbitrary', atom)

    def test_natural_quadratic_and_unsupported_negative(self):
        square = '<product><variable>1</variable><variable>1</variable></product>'
        self.assertTrue(replace(self.cpf_atom('<naturals/>', square)).startswith('quadratic-poly('))
        self.assertEqual(replace(self.cpf_atom('<naturals/>', '<integer>-1</integer>')),
                         'weak-poly(min-constant=-1,max-constant=0,max-coefficient=0,max-symbols=1,max-arity=1)')
        self.assertIsNone(replace(self.cpf_atom('<naturals/>',
            '<product><integer>-1</integer><variable>1</variable></product>')))

    def test_keeps_bounds_but_not_model_assignments(self):
        payload = json.dumps([['f', 2, [3, 1]]]).encode().hex()
        atom = replace('exact-poly(hex=' + payload + ')')
        self.assertEqual(atom, 'poly(max-constant=2,max-coefficient=3,max-symbols=1,max-arity=2)')
        self.assertNotIn('hex=', atom)

    def test_rational_quadratic_native_continuation_is_available(self):
        domain = '<rationals><delta><integer>1</integer></delta></rationals>'
        square = '<product><variable>1</variable><variable>1</variable></product>'
        self.assertTrue(replace(self.cpf_atom(domain, square)).startswith('rat-quadratic-poly('))

    def test_quadratic_conversion_preserves_small_strict_gap(self):
        quarter = '<rational><numerator>1</numerator><denominator>4</denominator></rational>'
        half = '<rational><numerator>1</numerator><denominator>2</denominator></rational>'
        atom = replace(self.cpf_atom('<rationals><delta>' + quarter + '</delta></rationals>',
            '<product>' + half + '<variable>1</variable><variable>1</variable></product>'))
        self.assertEqual(atom, 'rat-quadratic-poly(max-constant=0,max-coefficient=2,max-symbols=1,max-arity=1,denominator=4,delta-denominator=4)')

    def test_cpf_max_bounds_discard_symbols_and_choices(self):
        def atom(expression):
            xml = ('<maxPoly><interpret><name>secret</name><arity>1</arity>' +
                   expression + '</interpret></maxPoly>')
            return 'exact-red-pair(hex=' + json.dumps(['redPairProc', xml]).encode().hex() + ')'
        result = replace(atom('<max><variable>1</variable><sum><variable>1</variable>'
                              '<constant>500</constant></sum></max>'))
        self.assertEqual(result, 'max-poly(max-constant=500,max-coefficient=1,alternatives=2,max-symbols=1,max-arity=1)')
        self.assertIsNone(replace(atom('<constant>-1</constant>')))
        self.assertIsNone(replace(atom('<variable>2</variable>')))
        self.assertIsNone(replace(atom('<product><variable>1</variable></product>')))
        self.assertIn('max-constant=117584', replace(atom('<constant>117584</constant>')))
        self.assertIsNone(replace(atom('<constant>1048577</constant>')))

    def test_replaces_nested_structural_actions(self):
        self.assertEqual(replace('pipeline(exact-graph(hex=00); exact-size-change(hex=00))'),
                         'pipeline(graph; size-change)')

    def test_max_base_is_not_a_weighted_path_order(self):
        model = ('<maxPoly><interpret><name>f</name><arity>1</arity>'
                 '<variable>1</variable></interpret></maxPoly>')
        xml = '<weightedPathOrder>' + model + '</weightedPathOrder>'
        atom = 'exact-red-pair(hex=' + json.dumps(['redPairProc', xml]).encode().hex() + ')'
        self.assertEqual(replace(atom), 'wpo-max(max-constant=0,max-coefficient=1,alternatives=1,max-symbols=1,max-arity=1)')
        reordered = xml.replace('</weightedPathOrder>',
            '<precedenceStatus><precedenceStatusEntry><name>other</name><status>'
            '<position>2</position><position>1</position></status></precedenceStatusEntry>'
            '</precedenceStatus></weightedPathOrder>')
        reordered_atom = 'exact-red-pair(hex=' + json.dumps(['redPairProc', reordered]).encode().hex() + ')'
        self.assertEqual(replace(reordered_atom),
                         'wpo-max(max-constant=0,max-coefficient=1,alternatives=1,max-symbols=1,max-arity=1,permutations=1)')
        xml = '<filteredRedPair><argumentFilter/>' + model + '</filteredRedPair>'
        atom = 'exact-red-pair(hex=' + json.dumps(['redPairProc', xml]).encode().hex() + ')'
        self.assertIsNone(replace(atom))

    def test_drops_unsupported_composites(self):
        self.assertIsNone(replace('exact-trs-proof(hex=00)'))
        self.assertEqual(replace('timeout(60s, matrix(dimension=2))'),
                         'timeout(60s, matrix(dimension=2))')

    def test_source_bound_order_discards_source_and_assignment(self):
        inner = 'exact-poly(hex=' + json.dumps([['secret', 2, [3]]]).encode().hex() + ')'
        atom = 'exact-trs-order(hex=' + json.dumps(['<source/>', inner]).encode().hex() + ')'
        self.assertEqual(replace(atom), 'poly(max-constant=2,max-coefficient=3,max-symbols=1,max-arity=1)')

    def test_source_bound_labeling_retains_only_supported_carrier(self):
        def atom(carrier):
            return 'exact-semantic-labeling(hex=' + json.dumps([
                {'carrier_size': carrier, 'interpretations': {'secret': [1]}}, '<source/>'
            ]).encode().hex() + ')'
        self.assertEqual(replace(atom(2)), 'semantic-labeling')
        self.assertIsNone(replace(atom(3)))

    def test_q_choice_is_recomputed(self):
        atom = 'exact-innermost-lhss(hex=' + json.dumps(['<q/>', '<source/>']).encode().hex() + ')'
        self.assertEqual(replace(atom), 'innermost-lhss')

    def test_source_and_target_bound_labeling_discards_both_states(self):
        atom = 'exact-semantic-labeling(hex=' + json.dumps([
            {'carrier_size': 2}, '<source/>', '<target/>'
        ]).encode().hex() + ')'
        self.assertEqual(replace(atom), 'semantic-labeling')

    def test_native_structural_transformations_drop_selections(self):
        for family in ('split', 'constant-to-unary'):
            atom = 'exact-' + family + '(hex=' + json.dumps(['selection']).encode().hex() + ')'
            self.assertEqual(replace(atom), family)

    def test_transform_drops_position_substitution_and_child(self):
        for tag, expected in [('rewritingProc', 'rewrite'), ('narrowingProc', 'narrow'),
                              ('complexConstantRemovalProc', 'complex-constant-removal'),
                              ('instantiationProc', 'instantiate'),
                              ('forwardInstantiationProc', 'forward-instantiate')]:
            atom = 'exact-dp-transform(hex=' + json.dumps([
                tag, '<selected-witness/>', '<child/>', '<source/>'
            ]).encode().hex() + ')'
            self.assertEqual(replace(atom), expected)

    def test_cpf_path_order_discards_precedence_and_filter(self):
        atom = 'exact-red-pair(hex=' + json.dumps([
            'redPairUrProc', '<recursivePathOrder><secretPrecedence/></recursivePathOrder>'
        ]).encode().hex() + ')'
        self.assertEqual(replace(atom), 'path-order')

    def test_cpf_kbo_uses_text_weights_not_precedence(self):
        atom = 'exact-red-pair(hex=' + json.dumps([
            'redPairProc', '<knuthBendixOrder><w0>1</w0><precedenceWeight>'
            '<precedenceWeightEntry><precedence>99</precedence><weight>7</weight>'
            '</precedenceWeightEntry></precedenceWeight></knuthBendixOrder>'
        ]).encode().hex() + ')'
        self.assertEqual(replace(atom), 'kbo(max-weight=7,max-symbols=256)')


if __name__ == '__main__':
    unittest.main()
