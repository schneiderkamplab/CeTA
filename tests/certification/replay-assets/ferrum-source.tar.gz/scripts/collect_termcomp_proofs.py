#!/usr/bin/env python3
"""Collect TermCOMP proof artefacts for downstream training data.

The collector intentionally distinguishes certified and uncertified proof
streams. Certified artefacts usually live below `/cert/proofs/` and may contain
CPF XML; uncertified artefacts usually live below `/uncert/proofs/` and often
contain human-readable tool output. Both are useful, but they must not be
collapsed into one signal.
"""

from __future__ import annotations

import argparse
import concurrent.futures
import hashlib
import json
import re
import sqlite3
import sys
import time
import urllib.error
import urllib.parse
import urllib.request
import xml.etree.ElementTree as ET
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Any


DEFAULT_BASE_URL = "https://termcomp.github.io"
RESULTS_OF_INTEREST = {"YES", "NO", "CERTIFIED YES", "CERTIFIED NO"}
CERTIFIED_RESULTS = {"CERTIFIED YES", "CERTIFIED NO"}
HTTP_TIMEOUT = 60
DEFAULT_YEAR_PATHS = {
    2018: "Y2018-1",
    2019: "Y2019-1",
    2020: "Y2020-2",
    2021: "Y2021-2",
}


@dataclass(frozen=True)
class ProofLink:
    year: int
    category: str
    benchmark: str
    benchmark_url: str
    tool: str
    tool_column: int
    result: str
    certification: str
    proof_url: str
    error_url: str | None
    runtime_seconds: float | None
    cert_runtime_seconds: float | None


@dataclass(frozen=True)
class DownloadedProof:
    link: ProofLink
    local_path: str
    sha256: str
    bytes: int
    first_line: str
    detected_format: str
    extracted: dict[str, Any]
    downloaded_at: float
    error: str | None = None


def normalize_ws(text: str) -> str:
    return re.sub(r"\s+", " ", text.replace("\u200b", "")).strip()


def strip_tags(text: str) -> str:
    text = re.sub(r"<wbr\s*/?>", "", text, flags=re.IGNORECASE)
    text = re.sub(r"<[^>]+>", " ", text)
    return normalize_ws(text)


def parse_attrs(start_tag: str) -> dict[str, str]:
    attrs = {}
    for key, quote, value in re.findall(r"([A-Za-z_:][-A-Za-z0-9_:.]*)\s*=\s*(['\"])(.*?)\2", start_tag):
        attrs[key] = value
    for key, value in re.findall(r"([A-Za-z_:][-A-Za-z0-9_:.]*)\s*=\s*([^\s>]+)", start_tag):
        attrs.setdefault(key, value.strip("'\""))
    return attrs


def parse_cell(start_tag: str, body: str) -> dict[str, Any]:
    links = []
    for href, inner in re.findall(
        r"<a\s+[^>]*href=[\"']([^\"']+)[\"'][^>]*>(.*?)</a>",
        body,
        flags=re.IGNORECASE | re.DOTALL,
    ):
        links.append({"href": href, "text": strip_tags(inner)})
    # Current TermCOMP pages display proof artifacts through JavaScript
    # buttons.  Preserve them as ordinary link records for the downstream
    # collector instead of silently producing an empty corpus.
    for button_tag, inner in re.findall(
        r"(<button\b[^>]*>)(.*?)</button>",
        body,
        flags=re.IGNORECASE | re.DOTALL,
    ):
        onclick = parse_attrs(button_tag).get("onclick", "")
        proof = re.search(r"\bshow_proof\(\s*(['\"])(.*?)\1\s*\)", onclick)
        if proof:
            links.append({"href": proof.group(2), "text": strip_tags(inner)})
    spans = []
    for span_tag, inner in re.findall(
        r"(<span\b[^>]*>)(.*?)</span>",
        body,
        flags=re.IGNORECASE | re.DOTALL,
    ):
        spans.append({"class": parse_attrs(span_tag).get("class", ""), "text": strip_tags(inner)})
    return {
        "class": parse_attrs(start_tag).get("class", ""),
        "text": strip_tags(body),
        "links": links,
        "spans": spans,
    }


def split_cells(row_html: str) -> list[dict[str, Any]]:
    matches = list(re.finditer(r"<t[dh]\b[^>]*>", row_html, flags=re.IGNORECASE))
    cells = []
    for index, match in enumerate(matches):
        end = matches[index + 1].start() if index + 1 < len(matches) else len(row_html)
        cells.append(parse_cell(match.group(0), row_html[match.end() : end]))
    return cells


def parse_category_table(text: str) -> tuple[list[str], list[list[dict[str, Any]]]]:
    row_chunks = re.findall(r"<tr\b[^>]*>.*?(?=<tr\b|</table>|</body>|$)", text, flags=re.IGNORECASE | re.DOTALL)
    headers: list[str] = []
    rows: list[list[dict[str, Any]]] = []
    for row_html in row_chunks:
        if re.search(r'<tr\b[^>]*class=["\'][^"\']*\bhead\b', row_html, flags=re.IGNORECASE):
            headers = [cell["text"] for cell in split_cells(row_html)]
        else:
            cells = split_cells(row_html)
            if cells:
                rows.append(cells)
    return headers, rows


def fetch_text(url: str) -> str:
    req = urllib.request.Request(url, headers={"User-Agent": "ferrum-proof-corpus/0.1"})
    with urllib.request.urlopen(req, timeout=HTTP_TIMEOUT) as response:
        return response.read().decode("utf-8", "replace")


def fetch_bytes(url: str) -> bytes:
    req = urllib.request.Request(url, headers={"User-Agent": "ferrum-proof-corpus/0.1"})
    with urllib.request.urlopen(req, timeout=HTTP_TIMEOUT) as response:
        return response.read()


def year_path(year: int, year_paths: dict[int, str] | None = None) -> str:
    if year_paths and year in year_paths:
        return year_paths[year].strip("/")
    return DEFAULT_YEAR_PATHS.get(year, f"Y{year}").strip("/")


def parse_year_path_overrides(values: list[str] | None) -> dict[int, str]:
    paths = dict(DEFAULT_YEAR_PATHS)
    for value in values or []:
        if "=" not in value:
            raise ValueError(f"invalid --year-path value {value!r}; expected YEAR=PATH")
        year_text, path = value.split("=", 1)
        paths[int(year_text)] = path.strip("/")
    return paths


def category_names(base_url: str, year: int, year_paths: dict[int, str] | None = None) -> list[str]:
    index_url = f"{base_url.rstrip('/')}/{year_path(year, year_paths)}/"
    try:
        text = fetch_text(index_url)
    except urllib.error.URLError:
        return []
    names = set(re.findall(r'loadURL\("([^"]+)\.summary\.json"', text))
    return sorted(names)


def discover_years(base_url: str, start: int, end: int, year_paths: dict[int, str] | None = None) -> list[int]:
    years = []
    for year in range(start, end + 1):
        if category_names(base_url, year, year_paths):
            years.append(year)
    return years


def parse_category(
    base_url: str,
    year: int,
    category: str,
    year_paths: dict[int, str] | None = None,
) -> list[ProofLink]:
    page_url = f"{base_url.rstrip('/')}/{year_path(year, year_paths)}/{category}.html"
    headers, rows = parse_category_table(fetch_text(page_url))
    if not headers:
        return []
    links: list[ProofLink] = []
    for row in rows:
        if not row:
            continue
        benchmark_cell = row[0]
        benchmark_link = first_link(benchmark_cell)
        if benchmark_link is None:
            continue
        benchmark = benchmark_from_url(benchmark_link["href"], benchmark_link["text"])
        benchmark_url = benchmark_link["href"]
        for column_index, cell in enumerate(row[2:], start=2):
            result = cell_result(cell)
            if result not in RESULTS_OF_INTEREST:
                continue
            proof_link = proof_href(cell)
            if proof_link is None:
                continue
            tool = clean_tool_name(headers[column_index]) if column_index < len(headers) else f"col{column_index}"
            error_link = error_href(cell)
            runtime, cert_runtime = cell_times(cell)
            certification = "certified" if result in CERTIFIED_RESULTS or "/cert/" in proof_link else "uncertified"
            links.append(
                ProofLink(
                    year=year,
                    category=category,
                    benchmark=benchmark,
                    benchmark_url=benchmark_url,
                    tool=tool,
                    tool_column=column_index,
                    result=result,
                    certification=certification,
                    proof_url=proof_link,
                    error_url=error_link,
                    runtime_seconds=runtime,
                    cert_runtime_seconds=cert_runtime,
                )
            )
    return links


def first_link(cell: dict[str, Any]) -> dict[str, str] | None:
    return cell["links"][0] if cell.get("links") else None


def proof_href(cell: dict[str, Any]) -> str | None:
    for link in cell.get("links", []):
        href = link.get("href", "")
        text = normalize_ws(link.get("text", ""))
        if proof_like_href(href) and text in {"YES", "NO", "MAYBE", "SAST", "PAST", "AST", "UP", "LOW"}:
            return href
    for link in cell.get("links", []):
        href = link.get("href", "")
        if proof_like_href(href):
            return href
    return None


def proof_like_href(href: str) -> bool:
    return "/proofs/" in href or "/stdout/" in href


def error_href(cell: dict[str, Any]) -> str | None:
    for link in cell.get("links", []):
        href = link.get("href", "")
        if "/errors/" in href:
            return href
    return None


def cell_result(cell: dict[str, Any]) -> str:
    classes = set(cell.get("class", "").split())
    if "CERTIFIED" in classes and "YES" in classes:
        return "CERTIFIED YES"
    if "CERTIFIED" in classes and "NO" in classes:
        return "CERTIFIED NO"
    if "YES" in classes:
        return "YES"
    if "NO" in classes:
        return "NO"
    text = normalize_ws(cell.get("text", ""))
    for result in sorted(RESULTS_OF_INTEREST, key=len, reverse=True):
        if text.startswith(result):
            return result
    return ""


def cell_times(cell: dict[str, Any]) -> tuple[float | None, float | None]:
    times = []
    for span in cell.get("spans", []):
        if "time" not in span.get("class", ""):
            continue
        text = normalize_ws(span.get("text", ""))
        text = text.split("/", 1)[0]
        try:
            times.append(float(text))
        except ValueError:
            pass
    runtime = times[0] if times else None
    cert_runtime = times[1] if len(times) > 1 else None
    return runtime, cert_runtime


def clean_tool_name(header: str) -> str:
    header = re.sub(r"\s+--\s+YES\s+NO\s+MAYBE.*$", "", header)
    header = re.sub(r"\s+filteredTable\.register.*$", "", header)
    return normalize_ws(header)


def benchmark_from_url(url: str, fallback_text: str) -> str:
    parsed = urllib.parse.urlparse(url)
    query = urllib.parse.parse_qs(parsed.query)
    if "path" in query and query["path"]:
        return query["path"][0]
    return normalize_ws(fallback_text).replace("/ ", "/")


def safe_name(value: str, max_len: int = 160) -> str:
    value = urllib.parse.unquote(value)
    value = value.replace("#", "sharp_")
    value = re.sub(r"[^A-Za-z0-9_.=-]+", "_", value).strip("_")
    if len(value) <= max_len:
        return value or "unnamed"
    digest = hashlib.sha256(value.encode()).hexdigest()[:12]
    return f"{value[: max_len - 13]}_{digest}"


def proof_local_path(root: Path, link: ProofLink) -> Path:
    parsed = urllib.parse.urlparse(link.proof_url)
    raw_parts = [part for part in parsed.path.split("/") if part]
    benchmark_match = re.search(r"/benchmark_([^/]+)/solver_([^/]+)\.txt$", parsed.path)
    suffix = f"benchmark_{benchmark_match.group(1)}__solver_{benchmark_match.group(2)}.txt" if benchmark_match else safe_name(Path(parsed.path).name)
    return (
        root
        / f"Y{link.year}"
        / safe_name(link.category)
        / link.certification
        / safe_name(link.tool)
        / safe_name(link.benchmark)
        / suffix
    )


PROCESSOR_PATTERNS = [
    "DependencyPairsProof",
    "DependencyGraphProof",
    "UsableRulesProof",
    "QReductionProof",
    "QDPSizeChangeProof",
    "QDPOrderProof",
    "SizeChangeProof",
    "OrderProof",
    "Polynomial",
    "Matrix",
    "KBO",
    "LPO",
    "RPO",
    "MPO",
    "WPO",
    "Subterm",
    "Instantiation",
    "ForwardInstantiation",
    "Narrowing",
    "Rewriting",
    "Loop",
    "NonLoop",
    "Bounds",
    "TreeAutomata",
    "SemanticLabeling",
    "RootLabeling",
    "Uncurrying",
]

CPF_PROCESSOR_TAGS = {
    "dpTrans",
    "depGraphProc",
    "usableRulesProc",
    "innermostLhssRemovalProc",
    "redPairProc",
    "monoRedPairProc",
    "subtermCriterionProc",
    "sizeChangeProc",
    "instantiationProc",
    "forwardInstantiationProc",
    "csrForwardInstantiationProc",
    "narrowingProc",
    "rewriteProc",
    "switchInnermostProc",
    "ruleRemovalProc",
    "polynomialOrder",
    "matrixOrder",
    "pathOrder",
    "kbo",
    "rpo",
    "lpo",
    "loop",
}


def detect_format(data: bytes) -> tuple[str, str]:
    text = data.decode("utf-8", "replace")
    stripped = text.lstrip()
    if stripped.startswith("YES\n<?xml") or stripped.startswith("NO\n<?xml") or stripped.startswith("<?xml"):
        return "cpf-or-xml", text
    return "text", text


def extract_features(data: bytes) -> tuple[str, dict[str, Any]]:
    detected_format, text = detect_format(data)
    first_line = text.splitlines()[0].strip() if text.splitlines() else ""
    features: dict[str, Any] = {
        "first_line": first_line,
        "processor_counts": {},
        "numeric_constants": {},
        "cpf_tags": {},
        "tool_infos": [],
    }
    if detected_format == "cpf-or-xml":
        xml_text = text
        if first_line in {"YES", "NO", "MAYBE"}:
            xml_text = "\n".join(text.splitlines()[1:])
        try:
            root = ET.fromstring(xml_text.encode("utf-8"))
            tag_counts: dict[str, int] = {}
            for elem in root.iter():
                tag = elem.tag.rsplit("}", 1)[-1]
                if tag in CPF_PROCESSOR_TAGS:
                    tag_counts[tag] = tag_counts.get(tag, 0) + 1
                if tag == "toolInfo" and elem.text:
                    features["tool_infos"].append(elem.text[:1000])
            features["cpf_tags"] = tag_counts
            features["processor_counts"] = tag_counts
        except ET.ParseError as error:
            features["xml_parse_error"] = str(error)
    else:
        counts: dict[str, int] = {}
        for pattern in PROCESSOR_PATTERNS:
            count = len(re.findall(re.escape(pattern), text, flags=re.IGNORECASE))
            if count:
                counts[pattern] = count
        features["processor_counts"] = counts
    integers = [int(match) for match in re.findall(r"(?<![A-Za-z0-9_])-?\d+(?![A-Za-z0-9_])", text[:200_000])]
    if integers:
        features["numeric_constants"] = {
            "count": len(integers),
            "min": min(integers),
            "max": max(integers),
            "small_histogram": {str(n): integers.count(n) for n in sorted(set(integers)) if -10 <= n <= 20},
        }
    return detected_format, features


def download_one(root: Path, link: ProofLink) -> DownloadedProof:
    destination = proof_local_path(root, link)
    try:
        data = fetch_bytes(link.proof_url)
        destination.parent.mkdir(parents=True, exist_ok=True)
        destination.write_bytes(data)
        sha = hashlib.sha256(data).hexdigest()
        detected_format, features = extract_features(data)
        return DownloadedProof(
            link=link,
            local_path=str(destination),
            sha256=sha,
            bytes=len(data),
            first_line=features.get("first_line", ""),
            detected_format=detected_format,
            extracted=features,
            downloaded_at=time.time(),
        )
    except Exception as error:  # noqa: BLE001 - record downloader failures.
        return DownloadedProof(
            link=link,
            local_path=str(destination),
            sha256="",
            bytes=0,
            first_line="",
            detected_format="error",
            extracted={},
            downloaded_at=time.time(),
            error=repr(error),
        )


def index_only_record(link: ProofLink) -> DownloadedProof:
    return DownloadedProof(
        link=link,
        local_path="",
        sha256="",
        bytes=0,
        first_line="",
        detected_format="not-downloaded",
        extracted={},
        downloaded_at=time.time(),
        error="not downloaded; index-only record",
    )


def init_db(path: Path) -> sqlite3.Connection:
    path.parent.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(path)
    conn.execute(
        """
        create table if not exists proofs (
            year integer not null,
            category text not null,
            benchmark text not null,
            tool text not null,
            tool_column integer not null,
            result text not null,
            certification text not null,
            proof_url text primary key,
            error_url text,
            benchmark_url text,
            runtime_seconds real,
            cert_runtime_seconds real,
            local_path text,
            sha256 text,
            bytes integer,
            first_line text,
            detected_format text,
            extracted_json text,
            download_error text,
            downloaded_at real
        )
        """
    )
    conn.execute("create index if not exists idx_proofs_problem on proofs(category, benchmark)")
    conn.execute("create index if not exists idx_proofs_tool on proofs(tool, certification, result)")
    return conn


def write_db(conn: sqlite3.Connection, proof: DownloadedProof) -> None:
    link = proof.link
    conn.execute(
        """
        insert or replace into proofs (
            year, category, benchmark, tool, tool_column, result, certification,
            proof_url, error_url, benchmark_url, runtime_seconds, cert_runtime_seconds,
            local_path, sha256, bytes, first_line, detected_format, extracted_json,
            download_error, downloaded_at
        ) values (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """,
        (
            link.year,
            link.category,
            link.benchmark,
            link.tool,
            link.tool_column,
            link.result,
            link.certification,
            link.proof_url,
            link.error_url,
            link.benchmark_url,
            link.runtime_seconds,
            link.cert_runtime_seconds,
            proof.local_path,
            proof.sha256,
            proof.bytes,
            proof.first_line,
            proof.detected_format,
            json.dumps(proof.extracted, sort_keys=True),
            proof.error,
            proof.downloaded_at,
        ),
    )


def load_existing_urls(db_path: Path) -> set[str]:
    if not db_path.exists():
        return set()
    conn = sqlite3.connect(db_path)
    try:
        return {row[0] for row in conn.execute("select proof_url from proofs where download_error is null")}
    finally:
        conn.close()


def write_jsonl(path: Path, rows: list[dict[str, Any]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w") as handle:
        for row in rows:
            handle.write(json.dumps(row, sort_keys=True) + "\n")


def summarize(conn: sqlite3.Connection) -> dict[str, Any]:
    summary: dict[str, Any] = {}
    for row in conn.execute(
        """
        select year, category, certification, result, count(*), coalesce(sum(bytes), 0)
        from proofs
        group by year, category, certification, result
        order by year, category, certification, result
        """
    ):
        year, category, cert, result, count, total_bytes = row
        summary.setdefault(str(year), {}).setdefault(category, {}).setdefault(cert, {})[result] = {
            "count": count,
            "bytes": total_bytes,
        }
    errors = conn.execute("select count(*) from proofs where download_error is not null").fetchone()[0]
    total = conn.execute("select count(*) from proofs").fetchone()[0]
    summary["_totals"] = {"proofs": total, "download_errors": errors}
    return summary


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--base-url", default=DEFAULT_BASE_URL)
    parser.add_argument("--out", type=Path, default=Path("target/termcomp-proof-corpus"))
    parser.add_argument("--years", nargs="*", type=int)
    parser.add_argument("--year-start", type=int, default=2014)
    parser.add_argument("--year-end", type=int, default=2026)
    parser.add_argument(
        "--year-path",
        action="append",
        help="override result directory for a competition year, e.g. 2020=Y2020-2",
    )
    parser.add_argument("--categories", nargs="*")
    parser.add_argument("--jobs", type=int, default=64)
    parser.add_argument("--limit", type=int)
    parser.add_argument("--resume", action="store_true")
    parser.add_argument(
        "--index-only",
        action="store_true",
        help="record proof links and metadata without downloading artefact bodies",
    )
    args = parser.parse_args()

    jobs = max(1, min(args.jobs, 64))
    year_paths = parse_year_path_overrides(args.year_path)
    years = args.years or discover_years(args.base_url, args.year_start, args.year_end, year_paths)
    args.out.mkdir(parents=True, exist_ok=True)
    db_path = args.out / "proofs.sqlite"

    all_links: list[ProofLink] = []
    for year in years:
        categories = args.categories or category_names(args.base_url, year, year_paths)
        for category in categories:
            try:
                links = parse_category(args.base_url, year, category, year_paths)
            except Exception as error:  # noqa: BLE001 - continue other categories.
                print(f"warn: failed to parse {year_path(year, year_paths)}/{category}: {error}", file=sys.stderr)
                continue
            all_links.extend(links)
            print(f"discovered {year_path(year, year_paths)}/{category}: {len(links)} YES/NO proof links", flush=True)

    seen: set[str] = set()
    unique_links = []
    for link in all_links:
        if link.proof_url in seen:
            continue
        seen.add(link.proof_url)
        unique_links.append(link)
    if args.resume:
        existing = load_existing_urls(db_path)
        unique_links = [link for link in unique_links if link.proof_url not in existing]
    if args.limit is not None:
        unique_links = unique_links[: args.limit]

    manifest_path = args.out / "manifest.jsonl"
    write_jsonl(manifest_path, [asdict(link) for link in unique_links])

    conn = init_db(db_path)
    completed = 0
    started = time.monotonic()
    if args.index_only:
        for link in unique_links:
            write_db(conn, index_only_record(link))
            completed += 1
            if completed % 1000 == 0 or completed == len(unique_links):
                conn.commit()
                print(f"indexed {completed}/{len(unique_links)}", flush=True)
    else:
        with concurrent.futures.ThreadPoolExecutor(max_workers=jobs) as executor:
            futures = [
                executor.submit(download_one, args.out / "artefacts", link)
                for link in unique_links
            ]
            for future in concurrent.futures.as_completed(futures):
                proof = future.result()
                write_db(conn, proof)
                completed += 1
                if completed % 100 == 0 or completed == len(futures):
                    conn.commit()
                    rate = completed / max(0.001, time.monotonic() - started)
                    print(f"downloaded {completed}/{len(futures)} ({rate:.1f}/s)", flush=True)
    conn.commit()
    summary = summarize(conn)
    (args.out / "summary.json").write_text(json.dumps(summary, indent=2, sort_keys=True))
    print(json.dumps(summary.get("_totals", {}), sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
