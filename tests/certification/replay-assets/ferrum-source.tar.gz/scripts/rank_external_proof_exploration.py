#!/usr/bin/env python3
"""Rank unresolved Ferrum examples using AProVE and MU-TERM proof evidence."""

from __future__ import annotations

import argparse
import hashlib
import json
import re
import sqlite3
import xml.etree.ElementTree as ET
from collections import Counter
from copy import deepcopy
from pathlib import Path

from extract_exact_fragment_training_data import iter_exact_rows
from extract_local_cpf_oracle_events import event_outcome, strategy_atom, unwrap_input
from extract_subproof_training_data import load_xml


MU_PROCESSORS = {
    "Innermost Equivalent Processor": "switch-innermost",
    "Dependency Pairs Processor": "dp",
    "SCC Processor": "graph",
    "Subterm Processor": "subterm",
    "Narrowing Processor": "narrow(max-per-pair=2)",
    "Forward Instantiation Processor": "forward-instantiate(max-per-pair=2)",
    "Instantiation Processor": "instantiate(max-per-pair=2)",
    "Infiniteness Processor": "nontermination",
    "Extra Variables Processor": "variable-condition",
}

# These CPF leaves close the current obligation.  They are useful when
# determining whether the preceding processor solved a state, but they are not
# strategy atoms and must not be reported as missing Ferrum processors.
TERMINAL_PROCESSORS = {"pIsEmpty", "rIsEmpty", "sIsEmpty"}

# AProVE's text formatter interleaves proof processors with names for the
# current problem, Boolean composition, and terminal results.  The latter are
# useful when reading the proof, but are not executable Ferrum strategy atoms.
APROVE_TEXT_STRUCTURAL = {
    "AND",
    "Case",
    "Conditional",
    "CSR",
    "Formula",
    "GTRS",
    "Hypothesis",
    "Incomplete",
    "Induction",
    "Inverse",
    "NO",
    "Overlay",
    "QDP",
    "QCSDP",
    "QTRS",
    "Strip",
    "Symbolic",
    "TRUE",
    "YES",
}

APROVE_TEXT_TERMINAL = {
    "PIsEmptyProof",
    "PisEmptyProof",
    "RisEmptyProof",
}

# Only processors with a direct, executable Ferrum counterpart belong here.
# The normalized text is not a CPF and contains no self-contained child
# states, so these atoms are deliberately root-level weak guidance only.
APROVE_TEXT_ATOMS = {
    "DependencyPairsProof": "dp",
    "DependencyGraphProof": "graph",
    "QCSDependencyGraphProof": "graph",
    "UsableRulesProof": "usable-rules",
    "QCSUsableRulesProof": "usable-rules",
    "QDPSizeChangeProof": "size-change",
    "QCSDPSubtermProof": "subterm",
    "QDPOrderProof": "orders",
    "QDPQMonotonicMRRProof": "orders",
    "UsableRulesReductionPairsProof": "orders",
    "QCSDPReductionPairProof": "orders",
    "QCSDPMuMonotonicPoloProof": "mono-poly",
    "QDPApplicativeOrderProof": "applicative-reduction-pair",
    "QReductionProof": "innermost-lhss",
    "CSDependencyPairsProof": "csr-improved-dp",
    "SplitQDPProof": "split",
    "MRRProof": "orders",
    "NonMonReductionPairProof": "orders",
    "QCSDPInstantiationProcessor": "instantiate(max-per-pair=2)",
    "QCSDependencyForwardInstantiationProcessor": (
        "forward-instantiate(max-per-pair=2)"
    ),
    "QCSDPForwardInstantiationProcessor": "forward-instantiate(max-per-pair=2)",
    "SemLabProof": "semantic-labeling",
    "NonTerminationLoopProof": "nontermination(loop)",
    "ContextSensitiveLoopProof": "csr-loop",
    "NonLoopProof": "nontermination(dp-nonloop)",
    "CSRInnermostProof": "csr-innermost",
    "QTRSToCSRProof": "qtrs-to-csr",
    "RFCMatchBoundsTRSProof": "rfc-match-bounds",
}

APROVE_TEXT_DETAIL_ATOMS = {
    ("TransformationProof", "narrowing"): "narrow(max-per-pair=2)",
    ("TransformationProof", "rewriting"): "rewrite(max-per-pair=2)",
    ("TransformationProof", "instantiation"): "instantiate(max-per-pair=2)",
    ("TransformationProof", "forward-instantiation"): (
        "forward-instantiate(max-per-pair=2)"
    ),
    ("CSRRRRProof", "polynomial"): "poly(max-constant=4,max-coefficient=4)",
    ("CSRRRRProof", "matrix"): "matrix",
    ("CSRRRRProof", "kbo"): "kbo",
    ("CSRRRRProof", "path-order"): "path-order",
    ("QTRSRRRProof", "polynomial"): "poly(max-constant=4,max-coefficient=4)",
    ("QTRSRRRProof", "matrix"): "matrix",
    ("QTRSRRRProof", "kbo"): "kbo",
    ("QTRSRRRProof", "path-order"): "path-order",
}


def compact_atom(atom: str) -> str:
    """Render retained exact witnesses without embedding their full CPF hex."""
    if len(atom) <= 120:
        return atom
    if "(" in atom:
        return f"{atom.split('(', 1)[0]}(<retained-witness>)"
    return f"{atom[:117]}..."


def benchmark_from_path(path: str) -> str:
    marker = "TRS_Standard/"
    return marker + path.split(marker, 1)[1] if marker in path else path


def expand_rule_indices(problem_xml: str, lookup_xml: str | None) -> str:
    if "<ruleIndex" not in problem_xml or not lookup_xml:
        return problem_xml
    problem = ET.fromstring(problem_xml)
    lookup = ET.fromstring(lookup_xml)
    rules_by_index: dict[str, ET.Element] = {}
    for entry in lookup.iter():
        if entry.tag.rsplit("}", 1)[-1] != "indexToRule":
            continue
        index = next(
            (
                child
                for child in entry
                if child.tag.rsplit("}", 1)[-1] == "index"
            ),
            None,
        )
        rule = next(
            (
                child
                for child in entry
                if child.tag.rsplit("}", 1)[-1] == "rule"
            ),
            None,
        )
        if index is not None and index.text and rule is not None:
            rules_by_index[index.text.strip()] = rule
    for rules in problem.iter():
        if rules.tag.rsplit("}", 1)[-1] != "rules":
            continue
        expanded = []
        for child in list(rules):
            if child.tag.rsplit("}", 1)[-1] != "ruleIndex":
                expanded.append(child)
                continue
            key = (child.text or "").strip()
            if key not in rules_by_index:
                raise ValueError(f"missing ruleIndex {key}")
            expanded.append(deepcopy(rules_by_index[key]))
        rules[:] = expanded
    return ET.tostring(problem, encoding="unicode", short_empty_elements=True)


def canonical_key(
    raw_key: str, cache: sqlite3.Connection
) -> str:
    cached = cache.execute(
        """
        SELECT canonical_cpf, note FROM canonical_cpf_cache
        WHERE raw_key = ?
        """,
        (raw_key,),
    ).fetchone()
    if cached is None or cached[1] is not None:
        return raw_key
    return hashlib.sha256(cached[0].encode()).hexdigest()


def runtime_root_input(
    artifact_dir: str, cache: sqlite3.Connection
) -> tuple[str | None, str | None]:
    events = Path(artifact_dir) / "processor-events.jsonl"
    if not events.exists():
        return None, None
    fallback: tuple[str, str] | None = None
    with events.open(encoding="utf-8", errors="replace") as source:
        for line in source:
            event = json.loads(line)
            if event.get("level") != "top-level":
                continue
            raw_key = (event.get("input") or {}).get("problem_key")
            cpf = (event.get("input") or {}).get("cpf")
            if not isinstance(raw_key, str) or not isinstance(cpf, str):
                continue
            candidate = (canonical_key(raw_key, cache), cpf)
            if event.get("strategy_atom") == "utility-guidance":
                return candidate
            if fallback is None:
                fallback = candidate
    return fallback or (None, None)


def mu_term_evidence(path: Path) -> tuple[list[str], list[str]]:
    text = path.read_text(encoding="utf-8", errors="replace")
    atoms: list[str] = []
    unsupported: list[str] = []
    for heading in re.findall(r"(?m)^\s*([^\n:]+ Processor):\s*$", text):
        atom = MU_PROCESSORS.get(heading.strip())
        if atom is None:
            if heading.strip() not in {"Reduction Pair Processor", "Reduction Pairs Processor"}:
                unsupported.append(heading.strip())
        else:
            atoms.append(atom)

    blocks = re.split(r"(?m)^\s*Reduction Pairs? Processor:\s*$", text)[1:]
    for block in blocks:
        block = block.split("\nProblem ", 1)[0]
        kind_match = re.search(r"->Interpretation type:\s*\n\s*([^\n]+)", block)
        bound_match = re.search(r"->Bound:\s*\n\s*(\d+)", block)
        dimension_match = re.search(r"->Dimension:\s*\n\s*(\d+)", block)
        kind = kind_match.group(1).strip().lower() if kind_match else ""
        bound = int(bound_match.group(1)) if bound_match else 2
        dimension = int(dimension_match.group(1)) if dimension_match else 1
        if kind == "linear" and dimension == 1:
            atoms.append(f"poly(max-constant={bound},max-coefficient={bound})")
        elif kind == "linear" and dimension in {1, 2}:
            atoms.append(
                f"matrix(dim={dimension},max-constant={bound},max-coefficient={bound})"
            )
        elif kind:
            unsupported.append(f"interpretation:{kind}:dimension={dimension}:bound={bound}")
        else:
            unsupported.append("reduction-pair:unparsed")
    return list(dict.fromkeys(atoms)), list(dict.fromkeys(unsupported))


def local_name(tag: str) -> str:
    return tag.rsplit("}", 1)[-1]


def aprove_text_evidence(root: ET.Element) -> tuple[list[str], list[str], list[dict]]:
    """Extract conservative strategy hints from normalized AProVE text.

    Unlike CPF, AProVE's human-readable proof does not serialize the input and
    output problem at each processor.  Consequently this function must never
    create processor events or independently keyed residual-state hints.
    """
    atoms: list[str] = []
    unsupported: list[str] = []
    sequence = next(
        (child for child in root if local_name(child.tag) == "processorSequence"),
        None,
    )
    if sequence is None:
        return [], ["aprove-text:missing-processor-sequence"], []
    for step in sequence:
        processor = next(
            (child for child in step if local_name(child.tag) == "processor"),
            None,
        )
        detail_element = next(
            (child for child in step if local_name(child.tag) == "detail"),
            None,
        )
        name = (processor.text or "").strip() if processor is not None else ""
        detail = (
            (detail_element.text or "").strip() if detail_element is not None else ""
        )
        if not name:
            unsupported.append("aprove-text:missing-processor")
        elif name in APROVE_TEXT_STRUCTURAL or name in APROVE_TEXT_TERMINAL:
            continue
        elif (name, detail) in APROVE_TEXT_DETAIL_ATOMS:
            atoms.append(APROVE_TEXT_DETAIL_ATOMS[(name, detail)])
        elif name in APROVE_TEXT_ATOMS:
            atoms.append(APROVE_TEXT_ATOMS[name])
        else:
            suffix = f":{detail}" if detail else ""
            unsupported.append(f"aprove-text:{name}{suffix}")
    return list(dict.fromkeys(atoms)), list(dict.fromkeys(unsupported)), []


def aprove_evidence(
    proof: sqlite3.Row,
) -> tuple[list[str], list[str], list[dict]]:
    path_value = proof["normalized_path"] or proof["local_path"]
    if not path_value:
        return [], ["proof-not-local"], []
    root = load_xml(path_value, 100_000_000)
    if root is None:
        return [], ["proof-not-xml"], []
    if (
        local_name(root.tag) == "ferrumTextProofNormalization"
        and root.attrib.get("sourceToolFamily") == "AProVE"
    ):
        return aprove_text_evidence(root)
    source = {
        "proof_url": proof["proof_url"],
        "normalizer": proof["normalizer"],
        "source_kind": "external-proof-ranking",
        "xml_path": path_value,
        "xml_format": proof["normalized_format"] or proof["detected_format"] or "xml",
        "year": proof["year"],
        "category": proof["category"],
        "benchmark": proof["benchmark"],
        "tool": proof["tool"],
        "result": proof["result"],
        "certification": proof["certification"],
    }
    rows, reasons = iter_exact_rows(source, root)
    atoms: list[str] = []
    unsupported: list[str] = []
    steps: list[dict] = []
    for row in rows:
        atom = strategy_atom(row)
        if atom is None:
            processor_tag = str(row["metadata"]["processor_tag"])
            if processor_tag not in TERMINAL_PROCESSORS:
                unsupported.append(processor_tag)
        else:
            atoms.append(atom)
            cpf = unwrap_input(
                expand_rule_indices(
                    str(row["input"]["problem_xml"]),
                    row["input"].get("lookup_tables_xml"),
                )
            )
            if cpf is not None:
                outcome, progress = event_outcome(
                    str(row["metadata"]["processor_tag"]),
                    str(row["output_xml"]),
                )
                steps.append(
                    {
                        "atom": atom,
                        "cpf": cpf,
                        "level": (
                            "dependency-pair" if "<dpInput" in cpf else "top-level"
                        ),
                        "outcome": outcome,
                        "progress": progress,
                        "processor_tag": row["metadata"]["processor_tag"],
                        "proof_path": row["metadata"]["path"],
                        "witness_xml": row["output_xml"],
                    }
                )
    unsupported.extend(
        key for key, count in reasons.items() if count and key.startswith("unsupported_")
    )
    return (
        list(dict.fromkeys(atoms)),
        list(dict.fromkeys(unsupported)),
        steps,
    )


def evidence_score(item: dict) -> float:
    result = item["result"].upper()
    certified = item["certification"] == "certified"
    base = 1000.0 if certified else 500.0
    if "NO" in result:
        base -= 50.0
    supported = len(item["atoms"])
    unsupported = len(item["unsupported"])
    return base + 30.0 * supported - 80.0 * unsupported


def selected_detail_rows(details: list[dict], statuses: list[str]) -> dict[str, dict]:
    """Select roots without conflating externally certified and local results."""
    wanted = {status.lower() for status in statuses}
    include_all = "all" in wanted
    return {
        benchmark_from_path(row["path"]): row
        for row in details
        if include_all or str(row["status"]).lower() in wanted
    }


def add_root_hint_votes(
    votes: dict[str, Counter[str]], problem_key: str, evidence: list[dict]
) -> None:
    """Attach text-proof guidance to the live canonical root of any tool."""
    for item in evidence:
        weight = 2 if item["certification"] == "certified" else 1
        for atom in item["root_atoms"]:
            votes.setdefault(problem_key, Counter())[atom] += weight


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--details", type=Path, required=True)
    parser.add_argument("--proof-db", type=Path, required=True)
    parser.add_argument("--canonical-cache", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--summary", type=Path, required=True)
    parser.add_argument("--markdown", type=Path, required=True)
    parser.add_argument("--events-output", type=Path, required=True)
    parser.add_argument("--state-hints-output", type=Path, required=True)
    parser.add_argument(
        "--statuses",
        nargs="+",
        default=["unknown", "timeout"],
        help=(
            "Ferrum baseline statuses to include, or 'all'. The default keeps "
            "the historical unresolved-only behavior."
        ),
    )
    args = parser.parse_args()

    details = json.loads(args.details.read_text(encoding="utf-8"))
    unresolved = selected_detail_rows(details, args.statuses)
    connection = sqlite3.connect(args.proof_db)
    connection.row_factory = sqlite3.Row
    placeholders = ",".join("?" for _ in unresolved)
    query = f"""
        SELECT p.*, n.normalizer, n.normalized_format, n.normalized_path
        FROM proofs p
        LEFT JOIN normalized_proofs n ON n.proof_url = p.proof_url
        WHERE p.year = 2025
          AND p.category = 'TRS_Standard'
          AND p.benchmark IN ({placeholders})
          AND (
            lower(p.tool) LIKE '%aprove%'
            OR lower(p.tool) LIKE '%muterm%'
            OR lower(p.tool) LIKE '%mu-term%'
          )
          AND upper(p.result) IN ('YES', 'NO', 'CERTIFIED YES', 'CERTIFIED NO')
        ORDER BY p.benchmark, (p.certification = 'certified') DESC, p.tool
    """
    proof_rows = connection.execute(query, tuple(sorted(unresolved))).fetchall()
    connection.close()
    cache = sqlite3.connect(args.canonical_cache)

    evidence_by_benchmark: dict[str, list[dict]] = {}
    external_events: list[dict] = []
    state_atom_votes: dict[str, Counter[str]] = {}
    state_cpfs: dict[str, str] = {}
    for proof in proof_rows:
        tool = str(proof["tool"])
        if "mu-term" in tool.lower() or "muterm" in tool.lower():
            if not proof["local_path"]:
                atoms, unsupported = [], ["proof-not-local"]
            else:
                atoms, unsupported = mu_term_evidence(Path(proof["local_path"]))
            steps = []
        else:
            atoms, unsupported, steps = aprove_evidence(proof)
        for step in steps:
            raw_key = hashlib.sha256(step["cpf"].strip().encode()).hexdigest()
            problem_key = canonical_key(raw_key, cache)
            weight = 2 if proof["certification"] == "certified" else 1
            state_atom_votes.setdefault(problem_key, Counter())[step["atom"]] += weight
            state_cpfs.setdefault(problem_key, step["cpf"])
            external_events.append(
                {
                    "schema": "ferrum.processor-event.v1",
                    "run_id": "termcomp-2025-external-proof-evidence",
                    "problem_id": proof["benchmark"],
                    "category": "TRS_Standard",
                    "level": step["level"],
                    "problem_kind": "qdp" if step["level"] == "dependency-pair" else "trs",
                    "processor": step["atom"],
                    "strategy_atom": step["atom"],
                    "outcome": step["outcome"],
                    "progress": step["progress"],
                    "elapsed_ms": None,
                    "input": {
                        "format": "cpf3-xml",
                        "cpf": step["cpf"],
                        "problem_key": raw_key,
                    },
                    "metrics": {
                        "proof_path": step["proof_path"],
                        "processor_tag": step["processor_tag"],
                        "external_tool": tool,
                    },
                    "witness": {
                        "kind": "cpf-proof-fragment",
                        "xml": step["witness_xml"],
                    },
                    "certification": {
                        "status": (
                            "certified-full-source"
                            if proof["certification"] == "certified"
                            else "uncertified-external-proof"
                        ),
                        "checker": "CeTA" if proof["certification"] == "certified" else None,
                    },
                    "credit": {
                        "status": (
                            "proof-path-certified"
                            if proof["certification"] == "certified"
                            else "external-proof-hint"
                        )
                    },
                }
            )
        item = {
            "tool": tool,
            "result": proof["result"],
            "certification": proof["certification"],
            "atoms": atoms,
            "unsupported": unsupported,
            "proof_url": proof["proof_url"],
            "local_path": proof["normalized_path"] or proof["local_path"],
            "root_atoms": [
                step["atom"]
                for step in steps
                if step["level"] == "top-level"
            ][:1]
            or atoms[:1],
        }
        item["score"] = evidence_score(item)
        evidence_by_benchmark.setdefault(proof["benchmark"], []).append(item)

    output_rows = []
    for benchmark, ferrum in unresolved.items():
        evidence = evidence_by_benchmark.get(benchmark, [])
        root_problem_key, root_cpf = runtime_root_input(
            ferrum["artifact_dir"], cache
        )
        atom_votes: Counter[str] = Counter()
        for item in evidence:
            weight = 2 if item["certification"] == "certified" else 1
            for atom in item["root_atoms"]:
                atom_votes[atom] += weight
        if root_problem_key and root_cpf:
            add_root_hint_votes(state_atom_votes, root_problem_key, evidence)
            state_cpfs.setdefault(root_problem_key, root_cpf)
        best_score = max((item["score"] for item in evidence), default=-1000.0)
        row = {
            "benchmark": benchmark,
            "problem_key": root_problem_key,
            "ferrum_status": ferrum["status"],
            "ferrum_elapsed_seconds": ferrum["elapsed_seconds"],
            "priority": best_score + min(200.0, 10.0 * sum(atom_votes.values())),
            "suggested_atoms": [
                {"atom": atom, "votes": votes}
                for atom, votes in atom_votes.most_common()
            ],
            "external_evidence": sorted(
                evidence, key=lambda item: item["score"], reverse=True
            ),
        }
        output_rows.append(row)
    cache.close()

    args.events_output.parent.mkdir(parents=True, exist_ok=True)
    with args.events_output.open("w", encoding="utf-8") as sink:
        for event in external_events:
            print(json.dumps(event, separators=(",", ":"), sort_keys=True), file=sink)
    with args.state_hints_output.open("w", encoding="utf-8") as sink:
        for problem_key in sorted(state_atom_votes):
            print(
                json.dumps(
                    {
                        "problem_key": problem_key,
                        "cpf": state_cpfs.get(problem_key),
                        "suggested_atoms": [
                            {"atom": atom, "votes": votes}
                            for atom, votes in state_atom_votes[problem_key].most_common()
                        ],
                    },
                    separators=(",", ":"),
                    sort_keys=True,
                ),
                file=sink,
            )
    output_rows.sort(key=lambda row: (-row["priority"], row["benchmark"]))

    args.output.parent.mkdir(parents=True, exist_ok=True)
    with args.output.open("w", encoding="utf-8") as sink:
        for row in output_rows:
            print(json.dumps(row, separators=(",", ":"), sort_keys=True), file=sink)

    rows_with_evidence = sum(bool(row["external_evidence"]) for row in output_rows)
    rows_with_supported = sum(bool(row["suggested_atoms"]) for row in output_rows)
    summary = {
        "selected_statuses": args.statuses,
        "unresolved": len(unresolved),
        "external_proofs": len(proof_rows),
        "examples_with_external_evidence": rows_with_evidence,
        "examples_with_supported_atom_evidence": rows_with_supported,
        "external_processor_events": len(external_events),
        "hinted_canonical_states": len(state_atom_votes),
        "output": str(args.output),
    }
    args.summary.write_text(
        json.dumps(summary, indent=2, sort_keys=True) + "\n", encoding="utf-8"
    )

    lines = [
        "# TRS Standard External-Proof Exploration Ranking",
        "",
        "Unresolved Ferrum examples ranked by AProVE and MU-TERM proof evidence.",
        "Certified evidence is preferred; unsupported proof steps reduce priority.",
        "",
        "| Rank | Benchmark | Ferrum | External evidence | Suggested Ferrum atoms |",
        "| ---: | --- | --- | --- | --- |",
    ]
    for index, row in enumerate(output_rows[:100], start=1):
        evidence = ", ".join(
            f"{item['tool']} {item['result']}"
            + (" certified" if item["certification"] == "certified" else "")
            for item in row["external_evidence"][:3]
        )
        atoms = ", ".join(
            compact_atom(item["atom"]) for item in row["suggested_atoms"][:5]
        )
        lines.append(
            f"| {index} | `{row['benchmark']}` | {row['ferrum_status']} | "
            f"{evidence or '-'} | `{atoms}` |"
        )
    args.markdown.write_text("\n".join(lines) + "\n", encoding="utf-8")
    print(json.dumps(summary, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
