#!/usr/bin/env python3
"""Sample subproof rows and check standardized source CPFs with CeTA.

The training JSONL rows are proof fragments, not standalone CPF certificates.
This audit samples rows, transforms the complete source CPF for each sampled
row, and checks the transformed full certificate with CeTA.

The transformation follows the current standardization helper's function-symbol
choice for TRS inputs. Small inputs can still use the legacy brute-force exact
search for comparison; ``--max-symbols 0`` uses the direct lex minimizer.
Variables are alpha-renamed consistently across the certificate.
That is sufficient for this certificate-preservation audit; exact row-local
variable canonicalization is a separate normalization problem because CPF
variable scopes occur in many nested rule and substitution contexts.
"""

from __future__ import annotations

import argparse
import gzip
import json
import random
import subprocess
import sys
import tempfile
import time
import xml.etree.ElementTree as ET
from copy import deepcopy
from pathlib import Path
from typing import Any


TERM_TAGS = {"lhs", "rhs", "startTerm", "endTerm"}
SYMBOL_PARENT_TAGS = {"funapp", "sharp", "interpret"}


class StandardizationSearchLimit(RuntimeError):
    pass


def local_name(tag: str) -> str:
    return tag.rsplit("}", 1)[-1]


def strip_result_prefix(text: str) -> str:
    stripped = text.lstrip()
    if stripped.startswith(("YES\n", "NO\n", "MAYBE\n")):
        return "\n".join(stripped.splitlines()[1:])
    return text


def load_xml(path: Path) -> ET.Element:
    text = strip_result_prefix(path.read_text(errors="replace"))
    starts = [idx for idx in (text.find("<?xml"), text.find("<certificationProblem")) if idx >= 0]
    if starts:
        text = text[min(starts) :]
    return ET.fromstring(text.encode())


def first_child(elem: ET.Element, name: str) -> ET.Element | None:
    for child in elem:
        if local_name(child.tag) == name:
            return child
    return None


def child_text(elem: ET.Element, name: str) -> str | None:
    child = first_child(elem, name)
    if child is None:
        return None
    return "".join(child.itertext()).strip()


def funapp_args(elem: ET.Element) -> list[ET.Element]:
    args = []
    for child in elem:
        name = local_name(child.tag)
        if name in {"name", "sharp"}:
            continue
        if name == "arg":
            if len(child):
                args.append(child[0])
        elif name in {"funapp", "var"}:
            args.append(child)
    return args


def rule_sides(rule: ET.Element) -> tuple[ET.Element | None, ET.Element | None]:
    lhs = first_child(rule, "lhs")
    rhs = first_child(rule, "rhs")
    if lhs is not None and rhs is not None and len(lhs) and len(rhs):
        return lhs[0], rhs[0]
    terms = [child for child in rule if local_name(child.tag) in {"funapp", "var"}]
    if len(terms) >= 2:
        return terms[0], terms[1]
    return None, None


def term_key(term: ET.Element, assignment: dict[str, str], variables: dict[str, str]) -> str:
    name = local_name(term.tag)
    if name == "var":
        value = "".join(term.itertext()).strip()
        if value not in variables:
            variables[value] = canonical_variable_name(len(variables))
        return f"V{variables[value]}"
    if name == "funapp":
        sharp = first_child(term, "sharp")
        symbol = child_text(sharp, "name") if sharp is not None else child_text(term, "name")
        if symbol is None:
            symbol = ""
        canon = assignment.get(symbol, symbol)
        arg_keys = []
        for arg in funapp_args(term):
            arg_keys.append(term_key(arg, assignment, variables))
        return f"F{canon}#{len(arg_keys)}({','.join(arg_keys)})"
    return "".join(term.itertext()).strip()


def collect_fun_symbols_from_term(term: ET.Element, out: set[str]) -> None:
    if local_name(term.tag) == "funapp":
        sharp = first_child(term, "sharp")
        symbol = child_text(sharp, "name") if sharp is not None else child_text(term, "name")
        if symbol:
            out.add(symbol)
    for child in term:
        collect_fun_symbols_from_term(child, out)


def input_rules(root: ET.Element) -> list[ET.Element]:
    result = []
    rule_table: dict[str, ET.Element] = {}
    for index_to_rule in root.iter():
        if local_name(index_to_rule.tag) != "indexToRule":
            continue
        index = child_text(index_to_rule, "index")
        rule = first_child(index_to_rule, "rule")
        if index and rule is not None:
            rule_table[index] = rule
    input_elem = root if local_name(root.tag) == "input" else first_child(root, "input")
    if input_elem is None:
        return result
    for rules in input_elem.iter():
        if local_name(rules.tag) != "rules":
            continue
        for rule in rules:
            if local_name(rule.tag) == "rule":
                result.append(rule)
            elif local_name(rule.tag) == "ruleIndex":
                index = "".join(rule.itertext()).strip()
                if index in rule_table:
                    result.append(rule_table[index])
        if result:
            return result
    return result


def assignment_bijection(symbols: list[str], assignment: tuple[int, ...]) -> dict[str, str]:
    return {symbol: canonical_symbol_name(index) for symbol, index in zip(symbols, assignment)}


def assignment_key(rules: list[ET.Element], assignment: dict[str, str]) -> tuple[str, list[str], dict[str, str]]:
    keys = []
    for rule in rules:
        variables: dict[str, str] = {}
        lhs, rhs = rule_sides(rule)
        if lhs is None or rhs is None:
            continue
        keys.append(f"{term_key(lhs, assignment, variables)}->{term_key(rhs, assignment, variables)}")
    keys.sort()
    renumbered, renumbering = renumber_by_first_occurrence_in_keys(keys)
    return ";".join(renumbered), renumbered, renumbering


def renumber_by_first_occurrence_in_keys(keys: list[str]) -> tuple[list[str], dict[str, str]]:
    seen: dict[str, str] = {}
    rewritten = []
    for key in keys:
        out = []
        i = 0
        while i < len(key):
            if key[i] == "F":
                j = i + 1
                while j < len(key) and key[j] != "#":
                    j += 1
                symbol = key[i + 1 : j]
                if symbol not in seen:
                    seen[symbol] = canonical_symbol_name(len(seen))
                out.append("F" + seen[symbol])
                i = j
            else:
                out.append(key[i])
                i += 1
        rewritten.append("".join(out))
    return rewritten, seen


def shape_key(term: ET.Element, variables: dict[str, str]) -> str:
    name = local_name(term.tag)
    if name == "var":
        value = "".join(term.itertext()).strip()
        if value not in variables:
            variables[value] = canonical_variable_name(len(variables))
        return f"V{variables[value]}"
    if name == "funapp":
        args = [shape_key(arg, variables) for arg in funapp_args(term)]
        return f"F#{len(args)}({','.join(args)})"
    return local_name(term.tag)


def rule_shape_key(rule: ET.Element) -> str:
    variables: dict[str, str] = {}
    lhs, rhs = rule_sides(rule)
    if lhs is None or rhs is None:
        return ""
    return f"{shape_key(lhs, variables)}->{shape_key(rhs, variables)}"


def assign_symbols_by_shape_order(rules: list[ET.Element]) -> dict[str, str]:
    mapping: dict[str, str] = {}

    def visit(term: ET.Element) -> None:
        if local_name(term.tag) == "funapp":
            sharp = first_child(term, "sharp")
            symbol = child_text(sharp, "name") if sharp is not None else child_text(term, "name")
            if symbol and symbol not in mapping:
                mapping[symbol] = canonical_symbol_name(len(mapping))
        for arg in funapp_args(term):
            visit(arg)

    indexed = list(enumerate(rules))
    indexed.sort(key=lambda item: (rule_shape_key(item[1]), item[0]))
    for _, rule in indexed:
        lhs, rhs = rule_sides(rule)
        if lhs is not None:
            visit(lhs)
        if rhs is not None:
            visit(rhs)
    return mapping


def brute_force_standardize_function_bijection(root: ET.Element, max_symbols: int) -> dict[str, str]:
    rules = input_rules(root)
    if not rules:
        raise ValueError("no input rules")
    symbols: set[str] = set()
    for rule in rules:
        lhs, rhs = rule_sides(rule)
        if lhs is not None:
            collect_fun_symbols_from_term(lhs, symbols)
        if rhs is not None:
            collect_fun_symbols_from_term(rhs, symbols)
    ordered = sorted(symbols)
    if len(ordered) > max_symbols:
        raise ValueError(f"exact factorial search needs {len(ordered)} symbols; cap is {max_symbols}")
    best_key = None
    best_assignment = None
    import itertools

    for assignment in itertools.permutations(range(len(ordered))):
        direct = assignment_bijection(ordered, assignment)
        key, _, _ = assignment_key(rules, direct)
        if best_key is None or key < best_key:
            best_key = key
            best_assignment = direct
    if best_assignment is None:
        return {}
    _, _, renumbering = assignment_key(rules, best_assignment)
    return {old: renumbering.get(mid, mid) for old, mid in best_assignment.items()}


def symbol_occurrences(term: ET.Element, side: str, path: tuple[int, ...], out: dict[str, list[tuple[str, tuple[int, ...]]]]) -> None:
    if local_name(term.tag) != "funapp":
        return
    sharp = first_child(term, "sharp")
    symbol = child_text(sharp, "name") if sharp is not None else child_text(term, "name")
    if symbol:
        out.setdefault(symbol, []).append((side, path))
    for index, arg in enumerate(funapp_args(term)):
        symbol_occurrences(arg, side, (*path, index), out)


def term_partition_key(term: ET.Element, colors: dict[str, int], variables: dict[str, str]) -> str:
    name = local_name(term.tag)
    if name == "var":
        value = "".join(term.itertext()).strip()
        if value not in variables:
            variables[value] = canonical_variable_name(len(variables))
        return f"V{variables[value]}"
    if name == "funapp":
        sharp = first_child(term, "sharp")
        symbol = child_text(sharp, "name") if sharp is not None else child_text(term, "name")
        color = colors.get(symbol or "", -1)
        args = [term_partition_key(arg, colors, variables) for arg in funapp_args(term)]
        return f"C{color}#{len(args)}({','.join(args)})"
    return local_name(term.tag)


def rule_partition_key(rule: ET.Element, colors: dict[str, int]) -> str:
    variables: dict[str, str] = {}
    lhs, rhs = rule_sides(rule)
    if lhs is None or rhs is None:
        return ""
    return f"{term_partition_key(lhs, colors, variables)}->{term_partition_key(rhs, colors, variables)}"


def refine_symbol_colors(rules: list[ET.Element], symbols: list[str], colors: dict[str, int]) -> dict[str, int]:
    current = dict(colors)
    while True:
        occurrence_contexts: dict[str, list[str]] = {symbol: [] for symbol in symbols}
        for rule_index, rule in enumerate(rules):
            lhs, rhs = rule_sides(rule)
            if lhs is None or rhs is None:
                continue
            base = rule_partition_key(rule, current)
            occurrences: dict[str, list[tuple[str, tuple[int, ...]]]] = {}
            symbol_occurrences(lhs, "L", (), occurrences)
            symbol_occurrences(rhs, "R", (), occurrences)
            for symbol, positions in occurrences.items():
                for side, path in positions:
                    occurrence_contexts.setdefault(symbol, []).append(f"{base}@{rule_index}:{side}:{'.'.join(map(str, path))}")
        signatures = {
            symbol: (
                current.get(symbol, 0),
                tuple(sorted(occurrence_contexts.get(symbol, []))),
            )
            for symbol in symbols
        }
        ordered_signatures = {signature: index for index, signature in enumerate(sorted(set(signatures.values()), key=repr))}
        refined = {symbol: ordered_signatures[signatures[symbol]] for symbol in symbols}
        if refined == current:
            return refined
        current = refined


def candidate_from_color_order(rules: list[ET.Element], symbols: list[str], colors: dict[str, int]) -> tuple[str, dict[str, str]]:
    ordered = sorted(symbols, key=lambda symbol: (colors[symbol], symbol))
    direct = {symbol: canonical_symbol_name(index) for index, symbol in enumerate(ordered)}
    key, _, renumbering = assignment_key(rules, direct)
    return key, {old: renumbering.get(mid, mid) for old, mid in direct.items()}


def lower_bound_from_colors(rules: list[ET.Element], symbols: list[str], colors: dict[str, int]) -> str:
    cell_order = {color: index for index, color in enumerate(sorted(set(colors.values())))}
    direct = {symbol: canonical_symbol_name(cell_order[colors[symbol]]) for symbol in symbols}
    key, _, _ = assignment_key(rules, direct)
    return key


def refined_exact_standardize_function_bijection(root: ET.Element, node_limit: int = 20_000, seconds: float = 5.0) -> dict[str, str]:
    rules = input_rules(root)
    if not rules:
        raise ValueError("no input rules")
    symbols_set: set[str] = set()
    for rule in rules:
        lhs, rhs = rule_sides(rule)
        if lhs is not None:
            collect_fun_symbols_from_term(lhs, symbols_set)
        if rhs is not None:
            collect_fun_symbols_from_term(rhs, symbols_set)
    symbols = sorted(symbols_set)
    if not symbols:
        return {}

    initial = {symbol: 0 for symbol in symbols}
    best_key: str | None = None
    best_mapping: dict[str, str] | None = None
    seen: set[tuple[tuple[str, int], ...]] = set()
    nodes = 0
    started = time.monotonic()

    def search(colors: dict[str, int]) -> None:
        nonlocal best_key, best_mapping, nodes
        nodes += 1
        if nodes > node_limit or time.monotonic() - started > seconds:
            raise StandardizationSearchLimit(f"refined exact search exceeded {node_limit} nodes or {seconds:g}s")
        colors = refine_symbol_colors(rules, symbols, colors)
        state = tuple(sorted(colors.items()))
        if state in seen:
            return
        seen.add(state)
        if best_key is not None and lower_bound_from_colors(rules, symbols, colors) > best_key:
            return
        cells: dict[int, list[str]] = {}
        for symbol, color in colors.items():
            cells.setdefault(color, []).append(symbol)
        if all(len(cell) == 1 for cell in cells.values()):
            key, mapping = candidate_from_color_order(rules, symbols, colors)
            if best_key is None or key < best_key:
                best_key = key
                best_mapping = mapping
            return
        _, cell = min((len(cell), cell) for cell in cells.values() if len(cell) > 1)
        next_color = max(colors.values()) + 1
        for symbol in sorted(cell):
            branched = dict(colors)
            branched[symbol] = next_color
            search(branched)

    search(initial)
    if best_mapping is None:
        return assign_symbols_by_shape_order(rules)
    return best_mapping


def smt_refined_standardize_function_bijection(root: ET.Element) -> dict[str, str]:
    try:
        import z3
    except Exception as exc:  # noqa: BLE001
        raise RuntimeError(f"z3 is required for uncapped SMT standardization: {exc}") from exc

    rules = input_rules(root)
    if not rules:
        raise ValueError("no input rules")
    symbols_set: set[str] = set()
    for rule in rules:
        lhs, rhs = rule_sides(rule)
        if lhs is not None:
            collect_fun_symbols_from_term(lhs, symbols_set)
        if rhs is not None:
            collect_fun_symbols_from_term(rhs, symbols_set)
    symbols = sorted(symbols_set)
    if not symbols:
        return {}

    occurrence_contexts: dict[str, list[str]] = {symbol: [] for symbol in symbols}
    neutral_colors = {symbol: 0 for symbol in symbols}
    for rule_index, rule in enumerate(rules):
        lhs, rhs = rule_sides(rule)
        if lhs is None or rhs is None:
            continue
        base = rule_partition_key(rule, neutral_colors)
        occurrences: dict[str, list[tuple[str, tuple[int, ...]]]] = {}
        symbol_occurrences(lhs, "L", (), occurrences)
        symbol_occurrences(rhs, "R", (), occurrences)
        for symbol, positions in occurrences.items():
            for side, path in positions:
                occurrence_contexts.setdefault(symbol, []).append(f"{base}@{rule_index}:{side}:{'.'.join(map(str, path))}")
    signatures = {symbol: tuple(sorted(occurrence_contexts.get(symbol, []))) for symbol in symbols}
    signature_order = {signature: index for index, signature in enumerate(sorted(set(signatures.values()), key=repr))}
    colors = {symbol: signature_order[signatures[symbol]] for symbol in symbols}
    ranks = {symbol: z3.Int(f"rank_{index}") for index, symbol in enumerate(symbols)}
    solver = z3.Solver()
    for symbol in symbols:
        solver.add(ranks[symbol] >= 0, ranks[symbol] < len(symbols))
    solver.add(z3.Distinct([ranks[symbol] for symbol in symbols]))
    for i, left in enumerate(symbols):
        for right in symbols[i + 1 :]:
            if colors[left] < colors[right]:
                solver.add(ranks[left] < ranks[right])
            elif colors[right] < colors[left]:
                solver.add(ranks[right] < ranks[left])
    if solver.check() != z3.sat:
        raise RuntimeError("SMT standardization constraints are unsatisfiable")
    model = solver.model()
    direct = {
        symbol: canonical_symbol_name(model.eval(ranks[symbol], model_completion=True).as_long())
        for symbol in symbols
    }
    _, _, renumbering = assignment_key(rules, direct)
    return {old: renumbering.get(mid, mid) for old, mid in direct.items()}


def direct_lex_standardize_function_bijection(root: ET.Element) -> dict[str, str]:
    raw_rules = input_rules(root)
    rules: list[ET.Element] = []
    seen_rules: set[bytes] = set()
    for rule in raw_rules:
        key = ET.tostring(rule, encoding="utf-8")
        if key in seen_rules:
            continue
        seen_rules.add(key)
        rules.append(rule)
    rules.sort(key=rule_shape_key)
    if not rules:
        raise ValueError("no input rules")
    symbols_set: set[str] = set()
    for rule in rules:
        lhs, rhs = rule_sides(rule)
        if lhs is not None:
            collect_fun_symbols_from_term(lhs, symbols_set)
        if rhs is not None:
            collect_fun_symbols_from_term(rhs, symbols_set)
    symbols = sorted(symbols_set)
    if not symbols:
        return {}

    unknown_tag_ids: dict[str, int] = {}

    def stable_tag_id(tag: str) -> int:
        if tag not in unknown_tag_ids:
            unknown_tag_ids[tag] = len(unknown_tag_ids)
        return unknown_tag_ids[tag]

    def symbolic_term_tokens(term: ET.Element, variables: dict[str, int]) -> list[tuple[str, int | str]]:
        name = local_name(term.tag)
        if name == "var":
            value = "".join(term.itertext()).strip()
            if value not in variables:
                variables[value] = len(variables)
            return [("const", 1), ("const", variables[value])]
        if name == "funapp":
            sharp = first_child(term, "sharp")
            symbol = child_text(sharp, "name") if sharp is not None else child_text(term, "name")
            args = funapp_args(term)
            tokens: list[tuple[str, int | str]] = [("const", 2), ("rank", symbol or ""), ("const", len(args))]
            for arg in args:
                tokens.extend(symbolic_term_tokens(arg, variables))
            tokens.append(("const", 3))
            return tokens
        return [("const", 4), ("const", stable_tag_id(local_name(term.tag)))]

    rule_tokens: list[list[tuple[str, int | str]]] = []
    seen_rule_token_keys: set[tuple[tuple[str, int | str], ...]] = set()
    for rule in rules:
        lhs, rhs = rule_sides(rule)
        if lhs is None or rhs is None:
            continue
        variables: dict[str, int] = {}
        tokens = [("const", 10)]
        tokens.extend(symbolic_term_tokens(lhs, variables))
        tokens.append(("const", 11))
        tokens.extend(symbolic_term_tokens(rhs, variables))
        tokens.append(("const", 12))
        token_key = tuple(tokens)
        if token_key in seen_rule_token_keys:
            continue
        seen_rule_token_keys.add(token_key)
        rule_tokens.append(tokens)
    if not rule_tokens:
        return {}

    # The old SMT lex objective had only permutation constraints on rank variables.
    # For a fixed symbolic token stream, the lex-minimal permutation is obtained
    # greedily by assigning the next smallest rank at first symbolic occurrence.
    direct: dict[str, str] = {}
    for token_kind, token_value in (token for tokens in rule_tokens for token in tokens):
        if token_kind != "rank":
            continue
        symbol = str(token_value)
        if symbol not in direct:
            direct[symbol] = canonical_symbol_name(len(direct))
    for symbol in symbols:
        direct.setdefault(symbol, canonical_symbol_name(len(direct)))
    return direct


def smt_lex_standardize_function_bijection(root: ET.Element) -> dict[str, str]:
    return direct_lex_standardize_function_bijection(root)


def standardize_function_bijection_with_info(root: ET.Element, max_symbols: int = 0) -> tuple[dict[str, str], str]:
    rules = input_rules(root)
    if not rules:
        raise ValueError("no input rules")
    symbols: set[str] = set()
    for rule in rules:
        lhs, rhs = rule_sides(rule)
        if lhs is not None:
            collect_fun_symbols_from_term(lhs, symbols)
        if rhs is not None:
            collect_fun_symbols_from_term(rhs, symbols)
    ordered = sorted(symbols)
    if max_symbols > 0 and len(ordered) <= max_symbols:
        return brute_force_standardize_function_bijection(root, max_symbols), "bruteforce-exact"
    if max_symbols <= 0:
        return direct_lex_standardize_function_bijection(root), "direct-lex"
    try:
        return refined_exact_standardize_function_bijection(root), "refinement-exact"
    except StandardizationSearchLimit:
        return smt_refined_standardize_function_bijection(root), "smt-refinement"


def standardize_function_bijection(root: ET.Element, max_symbols: int = 0) -> dict[str, str]:
    return standardize_function_bijection_with_info(root, max_symbols)[0]


def canonical_symbol_name(index: int) -> str:
    return f"f{index}"


def canonical_variable_name(index: int) -> str:
    return f"x{index}"


def alphabetic_name(index: int, base: int) -> str:
    chars = []
    while True:
        chars.append(chr(base + (index % 26)))
        index //= 26
        if index == 0:
            break
        index -= 1
    return "".join(reversed(chars))


def parent_map(root: ET.Element) -> dict[int, ET.Element]:
    return {id(child): parent for parent in root.iter() for child in parent}


def rewrite_symbol_names(root: ET.Element, mapping: dict[str, str]) -> None:
    for elem in root.iter():
        if local_name(elem.tag) != "name" or elem.text is None:
            continue
        text = elem.text.strip()
        if text in mapping:
            elem.text = mapping[text]


def rewrite_variables_globally(root: ET.Element) -> None:
    variables: dict[str, str] = {}
    for elem in root.iter():
        if local_name(elem.tag) != "var" or elem.text is None:
            continue
        old = elem.text.strip()
        if old not in variables:
            variables[old] = canonical_variable_name(len(variables))
        elem.text = variables[old]


def transform_certificate(path: Path, max_symbols: int) -> tuple[ET.Element, dict[str, str]]:
    root = load_xml(path)
    mapping = standardize_function_bijection(root, max_symbols)
    root = deepcopy(root)
    rewrite_symbol_names(root, mapping)
    rewrite_variables_globally(root)
    return root, mapping


def quick_candidate_source(path: str, cache: dict[str, bool]) -> bool:
    if path in cache:
        return cache[path]
    try:
        text = strip_result_prefix(Path(path).read_text(errors="replace")[:200_000])
    except OSError:
        cache[path] = False
        return False
    start = text.find("<certificationProblem")
    if start < 0:
        cache[path] = False
        return False
    first_input = text.find("<input", start)
    first_cpf = text.find("<cpfVersion>", start)
    ok = first_cpf >= 0 and (first_input < 0 or first_cpf < first_input)
    ok = ok and "<cpfVersion>3" in text[start : start + 5000]
    ok = ok and "<trsInput" in text
    cache[path] = ok
    return ok


def sample_rows(path: Path, count: int, seed: int) -> list[dict[str, Any]]:
    rng = random.Random(seed)
    sample: list[dict[str, Any]] = []
    eligible = 0
    source_cache: dict[str, bool] = {}
    with gzip.open(path, "rt", encoding="utf-8") as handle:
        for line in handle:
            row = json.loads(line)
            if not str(row["metadata"]["category"]).startswith("TRS"):
                continue
            if row["source"]["xml_format"] not in {"cpf-or-xml", "cpf-or-xml-normalized"}:
                continue
            if row["metadata"]["certification"] != "certified":
                continue
            if not quick_candidate_source(row["source"]["xml_path"], source_cache):
                continue
            eligible += 1
            if len(sample) < count:
                sample.append(row)
            else:
                j = rng.randrange(eligible)
                if j < count:
                    sample[j] = row
    if len(sample) < count:
        raise RuntimeError(f"only found {len(sample)} eligible CPF3/TRS rows, requested {count}")
    return sample


def ceta_check_path(ceta: Path, path: Path, timeout: int) -> tuple[bool, str]:
    proc = subprocess.run(
        [str(ceta), str(path)],
        text=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        timeout=timeout,
    )
    return proc.returncode == 0 and "CERTIFIED" in proc.stdout, proc.stdout[-4000:]


def materialize_stripped_xml(source: Path, target: Path) -> None:
    text = strip_result_prefix(source.read_text(errors="replace"))
    starts = [idx for idx in (text.find("<?xml"), text.find("<certificationProblem")) if idx >= 0]
    if starts:
        text = text[min(starts) :]
    target.write_text(text, encoding="utf-8")


def ceta_check(ceta: Path, xml: ET.Element, out_path: Path, timeout: int) -> tuple[bool, str]:
    out_path.write_bytes(ET.tostring(xml, encoding="utf-8", xml_declaration=True, short_empty_elements=True))
    proc = subprocess.run(
        [str(ceta), str(out_path)],
        text=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        timeout=timeout,
    )
    return proc.returncode == 0 and "CERTIFIED" in proc.stdout, proc.stdout[-4000:]


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--jsonl", type=Path, default=Path("target/termcomp-proof-corpus/training/subproofs.jsonl.gz"))
    parser.add_argument("--rows", type=int, default=128)
    parser.add_argument("--seed", type=int, default=20260715)
    parser.add_argument("--ceta", type=Path, default=Path(".tools/ceta-relative-bounds"))
    parser.add_argument("--out-dir", type=Path, default=Path("target/termcomp-proof-corpus/standardize-audit"))
    parser.add_argument(
        "--max-symbols",
        type=int,
        default=0,
        help="legacy brute-force exact threshold; 0 uses direct lex standardization",
    )
    parser.add_argument("--timeout", type=int, default=30)
    parser.add_argument("--require-original-ceta", action=argparse.BooleanOptionalAction, default=True)
    args = parser.parse_args()

    args.out_dir.mkdir(parents=True, exist_ok=True)
    rows = sample_rows(args.jsonl, args.rows, args.seed)
    results = []
    cache: dict[str, dict[str, Any]] = {}
    with tempfile.TemporaryDirectory(dir=args.out_dir) as tmp:
        tmp_path = Path(tmp)
        for index, row in enumerate(rows, start=1):
            source_path = row["source"]["xml_path"]
            if source_path in cache:
                source_result = cache[source_path]
            else:
                target = tmp_path / f"sample-{len(cache) + 1:04}.xml"
                try:
                    if args.require_original_ceta:
                        original_target = tmp_path / f"sample-{len(cache) + 1:04}.original.xml"
                        materialize_stripped_xml(Path(source_path), original_target)
                        original_certified, original_output = ceta_check_path(args.ceta, original_target, args.timeout)
                        if not original_certified:
                            source_result = {
                                "status": "original_not_ceta_certified",
                                "ceta_tail": original_output,
                            }
                            cache[source_path] = source_result
                            raise StopIteration
                    xml, mapping = transform_certificate(Path(source_path), args.max_symbols)
                    certified, output = ceta_check(args.ceta, xml, target, args.timeout)
                    source_result = {
                        "status": "certified" if certified else "cert_failed",
                        "function_symbols": len(mapping),
                        "mapping": mapping,
                        "ceta_tail": output if not certified else "",
                        "transformed_path": str(target) if not certified else None,
                    }
                except Exception as error:  # noqa: BLE001 - audit records exact failure class.
                    if isinstance(error, StopIteration):
                        pass
                    else:
                        source_result = {
                            "status": "unsupported_or_error",
                            "error_type": type(error).__name__,
                            "error": str(error),
                        }
                cache[source_path] = source_result
            item = {
                "sample_index": index,
                "row_id": row["id"],
                "processor_tag": row["metadata"]["processor_tag"],
                "category": row["metadata"]["category"],
                "benchmark": row["metadata"]["benchmark"],
                "tool": row["metadata"]["tool"],
                "source_path": source_path,
                **source_result,
            }
            results.append(item)
            print(json.dumps({"event": "sample_done", **{k: item[k] for k in ("sample_index", "status", "processor_tag", "category")}}, sort_keys=True), flush=True)
    summary: dict[str, Any] = {
        "rows_sampled": len(rows),
        "seed": args.seed,
        "unique_source_certificates": len(cache),
        "counts": {},
    }
    for item in results:
        summary["counts"][item["status"]] = summary["counts"].get(item["status"], 0) + 1
    (args.out_dir / "sample-results.jsonl").write_text("\n".join(json.dumps(item, sort_keys=True) for item in results) + "\n")
    (args.out_dir / "summary.json").write_text(json.dumps(summary, indent=2, sort_keys=True))
    print(json.dumps(summary, sort_keys=True))
    return 0


if __name__ == "__main__":
    sys.setrecursionlimit(max(sys.getrecursionlimit(), 200_000))
    raise SystemExit(main())
