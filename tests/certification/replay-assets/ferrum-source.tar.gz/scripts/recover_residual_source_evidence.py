"""Re-extract checked modular source chains for an unresolved residual inventory."""
import argparse
from concurrent.futures import ThreadPoolExecutor
import json
from pathlib import Path
import subprocess
import sys


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--inventory", type=Path, required=True)
    p.add_argument("--replay", type=Path, required=True)
    p.add_argument("--root-run", type=Path, required=True)
    p.add_argument("--output", type=Path, required=True)
    p.add_argument("--ceta", type=Path, required=True)
    p.add_argument("--jobs", type=int, default=2)
    args = p.parse_args()
    unresolved = {r["input"] for r in map(json.loads, args.replay.read_text().splitlines()) if "proof" not in r}
    sources = sorted({o["source_events"].split("/run/", 1)[1].rsplit("/", 1)[0]
                      for r in json.loads(args.inventory.read_text())["records"] if r["input"] in unresolved
                      for o in r["origins"]})
    args.output.mkdir()

    def recover(source):
        root = args.root_run / source
        destination = args.output / source
        destination.mkdir(parents=True)
        if not (root / "result.json").exists():
            return dict(source=source, error="missing retained root")
        events, manifest, overlay = [destination / n for n in ("events.jsonl", "manifest.json", "overlay.jsonl")]
        commands = [
            [sys.executable, "scripts/extract_local_cpf_oracle_events.py", "--root", str(root),
             "--ceta", str(args.ceta), "--proof-chain-only", "--exclude-complete-proof-atoms",
             "--output", str(events), "--certified-manifest-output", str(manifest)],
            [sys.executable, "scripts/build_modular_proof_overlay.py", "--events", str(events),
             "--manifest", str(manifest), "--output", str(overlay)],
        ]
        with (destination / "log").open("x") as log:
            for command in commands:
                result = subprocess.run(command, stdout=log, stderr=log)
                if result.returncode:
                    return dict(source=source, error="extraction failed", exit_code=result.returncode)
        return dict(source=source, overlay=str(overlay))

    with (args.output / "results.jsonl").open("x") as out, ThreadPoolExecutor(max_workers=args.jobs) as pool:
        for result in pool.map(recover, sources):
            print(json.dumps(result), file=out, flush=True)
            print(json.dumps(result), flush=True)


if __name__ == "__main__":
    main()
