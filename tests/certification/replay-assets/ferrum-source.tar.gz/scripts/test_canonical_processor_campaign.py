#!/usr/bin/env python3

import importlib.util
import json
from pathlib import Path
import sqlite3
import tempfile
import unittest
from unittest import mock


SCRIPT = Path(__file__).with_name("run_canonical_processor_campaign.py")
SPEC = importlib.util.spec_from_file_location("canonical_campaign", SCRIPT)
assert SPEC is not None and SPEC.loader is not None
CAMPAIGN = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(CAMPAIGN)


class TighteningVariantsTest(unittest.TestCase):
    def test_new_uncurry_quadratic_and_arctic_processors_are_frontier_families(self) -> None:
        self.assertIn("uncurry", CAMPAIGN.DEFAULT_FRONTIER_ATOMS["top-level"])
        quadratic = "quadratic-poly(max-constant=1,max-coefficient=1)"
        self.assertIn(
            quadratic,
            CAMPAIGN.DEFAULT_FRONTIER_ATOMS["dependency-pair"],
        )
        self.assertEqual(
            CAMPAIGN.processor_family(quadratic),
            "quadratic-polynomial",
        )
        arctic = "arctic-matrix(dimension=3,max-constant=1,max-coefficient=1)"
        self.assertIn(
            arctic,
            CAMPAIGN.DEFAULT_FRONTIER_ATOMS["dependency-pair"],
        )
        self.assertEqual(CAMPAIGN.processor_family(arctic), "arctic-matrix")

    def test_recursive_frontier_backtracks_across_transform_candidates(self) -> None:
        atoms = CAMPAIGN.DEFAULT_FRONTIER_ATOMS["dependency-pair"]
        for processor in ("narrow", "instantiate", "forward-instantiate"):
            self.assertIn(f"{processor}(candidate=1,per-pair=2)", atoms)
            self.assertIn(f"{processor}(candidate=8,per-pair=2)", atoms)

    def test_bounds_large_diagnostics_while_retaining_both_ends(self) -> None:
        value = "START" + ("x" * 2_000_000) + "END"
        bounded = CAMPAIGN.bounded_diagnostic_text(value)
        self.assertLess(len(bounded.encode()), 1_000_200)
        self.assertTrue(bounded.startswith("START"))
        self.assertTrue(bounded.endswith("END"))
        self.assertIn("diagnostic bytes omitted", bounded)

    def test_normalizes_historical_rfc_debug_atom(self) -> None:
        self.assertEqual(
            CAMPAIGN.normalize_candidate(
                "SrsRfcRelativeMatchBounds-{-max_bound:-2,-max_words:-10000,"
                "-max_word_len:-128,-max_states:-2000,-max_transitions:-50000,"
                "-at_bound:-Merge,-closure:-Right-}"
            ),
            "rfc-relative-match-bounds(max-bound=2,max-words=10000,"
            "max-word-len=128,max-states=2000,max-transitions=50000,"
            "at-bound=merge,closure=right)",
        )

    def test_normalizes_csr_loop_debug_atom(self) -> None:
        self.assertEqual(CAMPAIGN.normalize_candidate("CsrLoop"), "csr-loop")

    def test_excludes_srs_only_atoms_from_trs_campaigns(self) -> None:
        self.assertFalse(
            CAMPAIGN.candidate_applicable(
                "srs-weighted-length(max-weight=64)", "%TRS_Standard%"
            )
        )
        self.assertFalse(
            CAMPAIGN.candidate_applicable(
                "rfc-relative-match-bounds(max-bound=2)", "%TRS_Standard%"
            )
        )
        self.assertTrue(
            CAMPAIGN.candidate_applicable(
                "relative-match-bounds(max-bound=5,max-states=2000)",
                "%TRS_Standard%",
            )
        )

    def test_tightens_polynomial_bounds_without_zero_coefficients(self) -> None:
        self.assertEqual(
            CAMPAIGN.tightening_variants(
                "poly(max-constant=2,max-coefficient=2)"
            )[:3],
            [
                "poly(max-constant=0,max-coefficient=1)",
                "poly(max-constant=2,max-coefficient=1)",
                "poly(max-constant=0,max-coefficient=2)",
            ],
        )

    def test_tightens_matrix_dimension(self) -> None:
        self.assertEqual(
            CAMPAIGN.tightening_variants(
                "matrix(dim=2,max-constant=2,max-coefficient=1)"
            )[:2],
            [
                "matrix(dim=1,max-constant=0,max-coefficient=1)",
                "matrix(dim=1,max-constant=2,max-coefficient=1)",
            ],
        )

    def test_does_not_tighten_operational_caps(self) -> None:
        self.assertEqual(
            CAMPAIGN.tightening_variants(
                "relative-match-bounds(max-bound=5,max-states=2000)"
            ),
            [],
        )

    def test_expands_supported_parameters_after_timeout(self) -> None:
        self.assertEqual(
            CAMPAIGN.parameter_expansion_variants(
                "matrix(dim=2,max-constant=2,max-coefficient=1)"
            ),
            [
                "matrix(dim=4,max-constant=2,max-coefficient=1)",
                "matrix(dim=2,max-constant=4,max-coefficient=1)",
                "matrix(dim=2,max-constant=2,max-coefficient=2)",
            ],
        )
        self.assertEqual(
            CAMPAIGN.parameter_expansion_variants("forward-instantiate(per-pair=2)"),
            ["forward-instantiate(per-pair=4)"],
        )

    def test_tightens_weak_range_and_rational_denominator(self) -> None:
        weak = CAMPAIGN.tightening_variants(
            "weak-poly(min-constant=-1,max-constant=2,max-coefficient=1)"
        )
        rational = CAMPAIGN.tightening_variants(
            "rational-poly(max-constant=16,max-coefficient=16,denominator=4)"
        )
        self.assertIn(
            "weak-poly(min-constant=0,max-constant=2,max-coefficient=1)", weak
        )
        self.assertIn(
            "rational-poly(max-constant=16,max-coefficient=16,denominator=1)",
            rational,
        )


class CertifiedReuseTest(unittest.TestCase):
    def test_reuses_only_matching_implementation(self) -> None:
        with tempfile.TemporaryDirectory() as raw_directory:
            directory = Path(raw_directory)
            source = sqlite3.connect(directory / "source.sqlite")
            source.executescript(
                """
                CREATE TABLE problems(
                    problem_key TEXT PRIMARY KEY, cpf TEXT, validity_mask INTEGER,
                    rows INTEGER
                );
                CREATE TABLE candidates(
                    problem_key TEXT, candidate TEXT, best_status TEXT,
                    utility_score REAL, attempts INTEGER, best_rank INTEGER,
                    best_elapsed_ms INTEGER
                );
                INSERT INTO problems VALUES(
                    'state', '<trsInput/>', 0, 1
                );
                INSERT INTO candidates VALUES(
                    'state', 'poly(max-constant=2,max-coefficient=2)',
                    'solved', 1.0, 1, 4, 10
                );
                """
            )
            prior_path = directory / "prior.sqlite"
            prior = sqlite3.connect(prior_path)
            prior.executescript(
                """
                CREATE TABLE trials(
                    problem_key TEXT, candidate TEXT, state TEXT, outcome TEXT,
                    timeout_ms INTEGER, certification_status TEXT,
                    implementation_hash TEXT
                );
                INSERT INTO trials VALUES(
                    'state', 'poly(max-constant=2,max-coefficient=2)',
                    'completed', 'solved', 1000, 'certified-full', 'same'
                );
                """
            )
            prior.close()

            matching = sqlite3.connect(":memory:")
            CAMPAIGN.initialize_results(matching)
            scheduled, _ = CAMPAIGN.schedule_tasks(
                source,
                matching,
                [prior_path],
                1,
                0,
                0,
                0,
                1,
                0,
                False,
                1000,
                1,
                None,
                "same",
                None,
                {},
                {},
                0,
                False,
            )
            self.assertEqual(scheduled, 0)

            changed = sqlite3.connect(":memory:")
            CAMPAIGN.initialize_results(changed)
            scheduled, _ = CAMPAIGN.schedule_tasks(
                source,
                changed,
                [prior_path],
                1,
                0,
                0,
                0,
                1,
                0,
                False,
                1000,
                1,
                None,
                "changed",
                None,
                {},
                {},
                0,
                False,
            )
            self.assertEqual(scheduled, 1)
            source.close()

    def test_frequent_uncovered_state_gets_distinct_family_exploration(self) -> None:
        source = sqlite3.connect(":memory:")
        source.executescript(
            """
            CREATE TABLE problems(
                problem_key TEXT PRIMARY KEY, cpf TEXT, validity_mask INTEGER,
                rows INTEGER
            );
            CREATE TABLE candidates(
                problem_key TEXT, candidate TEXT, best_status TEXT,
                utility_score REAL, attempts INTEGER, best_rank INTEGER,
                best_elapsed_ms INTEGER
            );
            INSERT INTO problems VALUES('state', '<dpInput/>', 0, 100);
            INSERT INTO candidates VALUES
                ('state', 'poly(max-constant=2,max-coefficient=2)',
                 'failed', 0.0, 0, 1, 1),
                ('state', 'sat-poly(max-constant=2,max-coefficient=1)',
                 'failed', 0.0, 0, 1, 1),
                ('state', 'matrix(dim=2,max-constant=2,max-coefficient=1)',
                 'failed', 0.0, 0, 1, 1),
                ('state', 'path-order', 'failed', 0.0, 0, 1, 1),
                ('state', 'kbo(max-weight=2)', 'failed', 0.0, 0, 1, 1),
                ('state', 'subterm', 'failed', 0.0, 0, 1, 1);
            """
        )
        results = sqlite3.connect(":memory:")
        CAMPAIGN.initialize_results(results)
        scheduled, _ = CAMPAIGN.schedule_tasks(
            source,
            results,
            [],
            0,
            0,
            1,
            4,
            50,
            3,
            False,
            1000,
            7,
            None,
            "implementation",
            None,
            {},
            {},
            0,
            False,
        )
        rows = results.execute(
            "SELECT candidate, selection FROM trials ORDER BY selection, candidate"
        ).fetchall()
        self.assertEqual(scheduled, 4)
        self.assertEqual(sum(selection == "explore" for _, selection in rows), 1)
        extras = [
            candidate
            for candidate, selection in rows
            if selection == "explore-frequent"
        ]
        self.assertEqual(len(extras), 3)
        self.assertEqual(
            len({CAMPAIGN.processor_family(candidate) for candidate in extras}),
            3,
        )
        source.close()

    def test_self_contained_hint_schedules_state_missing_from_source_db(self) -> None:
        source = sqlite3.connect(":memory:")
        source.executescript(
            """
            CREATE TABLE problems(
                problem_key TEXT PRIMARY KEY, cpf TEXT, validity_mask INTEGER,
                rows INTEGER
            );
            CREATE TABLE candidates(
                problem_key TEXT, candidate TEXT, best_status TEXT,
                utility_score REAL, attempts INTEGER, best_rank INTEGER,
                best_elapsed_ms INTEGER
            );
            """
        )
        results = sqlite3.connect(":memory:")
        CAMPAIGN.initialize_results(results)
        scheduled, cpfs = CAMPAIGN.schedule_tasks(
            source,
            results,
            [],
            0,
            0,
            0,
            0,
            1,
            0,
            False,
            60_000,
            0,
            None,
            "implementation",
            None,
            {"hint-state": ["dp"]},
            {"hint-state": "<trsInput/>"},
            3,
            True,
        )
        self.assertEqual(scheduled, 1)
        self.assertEqual(cpfs["hint-state"], "<trsInput/>")
        self.assertEqual(
            results.execute("SELECT candidate, selection FROM trials").fetchone(),
            ("dp", "external-proof-hint"),
        )
        source.close()

    def test_requested_allocation_is_exact_and_caps_each_lane(self) -> None:
        self.assertEqual(
            CAMPAIGN.allocation_quotas(20_000),
            {
                "unseen": 7_000,
                "hints": 5_000,
                "escalation": 4_000,
                "tightening": 3_000,
                "opposite": 1_000,
            },
        )
        connection = sqlite3.connect(":memory:")
        CAMPAIGN.initialize_results(connection)
        selections = [
            ("a", "explore"),
            ("b", "frontier-unseen"),
            ("c", "external-proof-hint"),
            ("d", "timeout-escalate"),
            ("e", "tighten"),
            ("f", "diagnostic-yes"),
        ]
        for task_key, selection in selections:
            connection.execute(
                """
                INSERT INTO trials(
                    task_key, problem_key, candidate, selection, timeout_ms
                ) VALUES (?, 'p', ?, ?, 1000)
                """,
                (task_key, task_key, selection),
            )
        retained = CAMPAIGN.enforce_initial_allocation(connection, 5)
        self.assertLessEqual(retained["unseen"], 3)
        self.assertLessEqual(retained["hints"], 1)
        self.assertLessEqual(retained["escalation"], 1)
        self.assertLessEqual(retained["tightening"], 0)
        self.assertLessEqual(retained["opposite"], 0)


class StateRegistryTest(unittest.TestCase):
    CPF = """<trsInput>
      <trs><rules><rule><funapp><name>f</name><arg><var>x</var></arg></funapp>
      <var>x</var></rule></rules></trs>
      <strategy><full/></strategy>
    </trsInput>"""

    def test_registry_deduplicates_raw_state_and_keeps_all_origins(self) -> None:
        connection = sqlite3.connect(":memory:")
        CAMPAIGN.initialize_results(connection)
        first_hash, inserted = CAMPAIGN.register_state(
            connection, self.CPF, canonical_hash="canonical", origin="root-a"
        )
        second_hash, inserted_again = CAMPAIGN.register_state(
            connection, self.CPF, canonical_hash="canonical", origin="root-b"
        )
        self.assertEqual(first_hash, second_hash)
        self.assertTrue(inserted)
        self.assertFalse(inserted_again)
        self.assertEqual(
            connection.execute("SELECT COUNT(*) FROM states").fetchone()[0], 1
        )
        self.assertEqual(
            connection.execute("SELECT COUNT(*) FROM state_origins").fetchone()[0],
            2,
        )

    def test_imports_runtime_raw_aliases_from_source_registry(self) -> None:
        source = sqlite3.connect(":memory:")
        source.executescript(
            """
            CREATE TABLE problems(
              problem_key TEXT PRIMARY KEY, cpf TEXT, validity_mask INTEGER);
            CREATE TABLE problem_aliases(
              raw_problem_key TEXT PRIMARY KEY, problem_key TEXT, source TEXT);
            INSERT INTO problems VALUES(
              'canonical-source', '<trsInput><trs/><strategy><full/></strategy></trsInput>', 1);
            INSERT INTO problem_aliases VALUES(
              'runtime-raw', 'canonical-source', 'event-content-address');
            """
        )
        results = sqlite3.connect(":memory:")
        CAMPAIGN.initialize_results(results)
        cpfs = {
            key: cpf
            for key, cpf in source.execute("SELECT problem_key, cpf FROM problems")
        }
        raw_by_source = CAMPAIGN.import_source_registry(source, results, cpfs)
        self.assertEqual(
            results.execute(
                "SELECT state_raw_hash, alias_kind FROM state_aliases "
                "WHERE alias_raw_hash='runtime-raw'"
            ).fetchone(),
            (raw_by_source["canonical-source"], "event-content-address"),
        )

    def test_imports_ferrum_runtime_canonical_key(self) -> None:
        source = sqlite3.connect(":memory:")
        source.executescript(
            """
            CREATE TABLE problems(
              problem_key TEXT PRIMARY KEY, cpf TEXT, validity_mask INTEGER);
            INSERT INTO problems VALUES(
              'semantic-source', '<trsInput><trs/><strategy><full/></strategy></trsInput>', 1);
            """
        )
        results = sqlite3.connect(":memory:")
        CAMPAIGN.initialize_results(results)
        cpfs = {
            key: cpf
            for key, cpf in source.execute("SELECT problem_key, cpf FROM problems")
        }
        with mock.patch.object(
            CAMPAIGN, "runtime_canonical_hash", return_value="runtime-canonical"
        ):
            raw_by_source = CAMPAIGN.import_source_registry(
                source, results, cpfs, ferrum=Path("ferrum")
            )
        self.assertEqual(
            results.execute(
                "SELECT canonical_hash, canonicalization_status FROM states "
                "WHERE raw_hash=?",
                (raw_by_source["semantic-source"],),
            ).fetchone(),
            ("runtime-canonical", "ferrum-runtime"),
        )

    def test_merges_runtime_equivalent_source_serializations(self) -> None:
        source = sqlite3.connect(":memory:")
        source.executescript(
            """
            CREATE TABLE problems(
              problem_key TEXT PRIMARY KEY, cpf TEXT, validity_mask INTEGER);
            INSERT INTO problems VALUES(
              'first', '<trsInput><trs/><strategy><full/></strategy></trsInput>', 1);
            INSERT INTO problems VALUES(
              'second', '<trsInput><trs><rules/></trs><strategy><full/></strategy></trsInput>', 1);
            """
        )
        results = sqlite3.connect(":memory:")
        CAMPAIGN.initialize_results(results)
        cpfs = {
            key: cpf
            for key, cpf in source.execute("SELECT problem_key, cpf FROM problems")
        }
        with mock.patch.object(
            CAMPAIGN, "runtime_canonical_hash", return_value="same-runtime-key"
        ):
            CAMPAIGN.import_source_registry(
                source, results, cpfs, ferrum=Path("ferrum")
            )
        self.assertEqual(
            results.execute(
                "SELECT COUNT(DISTINCT canonical_hash) FROM states"
            ).fetchone()[0],
            1,
        )

    def test_extracts_each_materialized_residual_assumption(self) -> None:
        certificate = f"""<certificationProblem><proof>
          <ruleRemoval><trsTerminationProof>
            <terminationAssumption>{self.CPF}</terminationAssumption>
          </trsTerminationProof></ruleRemoval>
        </proof></certificationProblem>"""
        children = CAMPAIGN.extract_child_problems(certificate)
        self.assertEqual(len(children), 1)
        self.assertEqual(CAMPAIGN.problem_kind(children[0]), "trs")
        self.assertIn("<trsInput", children[0])

    def test_composes_internal_csr_reconstruction_marker(self) -> None:
        child_input = (
            "<trsInput><trs><rules/></trs><strategy><contextSensitive/>"
            "</strategy></trsInput>"
        )
        fragment = f"""<certificationProblem><proof><csrTerminationProof>
          <csrRuleRemoval><trs><rules/></trs>
            <csrTerminationAssumption>{child_input}</csrTerminationAssumption>
          </csrRuleRemoval>
        </csrTerminationProof></proof></certificationProblem>"""
        child_proof = """<certificationProblem><proof><csrTerminationProof>
          <rIsEmpty/>
        </csrTerminationProof></proof></certificationProblem>"""
        with tempfile.TemporaryDirectory() as raw_directory:
            path = Path(raw_directory) / "child.xml"
            path.write_text(child_proof, encoding="utf-8")
            composed, error = CAMPAIGN.compose_certified_fragment(
                fragment, [("csrTerminationAssumption", str(path))]
            )
        self.assertEqual(error, "")
        self.assertIsNotNone(composed)
        assert composed is not None
        self.assertNotIn("csrTerminationAssumption", composed)
        self.assertIn("<csrTerminationProof>", composed)
        self.assertIn("<rIsEmpty", composed)

    def test_typed_context_distinguishes_all_supported_problem_kinds(self) -> None:
        cases = {
            "trs": "<trsInput><trs/><strategy><full/></strategy></trsInput>",
            "innermost-trs": (
                "<trsInput><trs/><strategy><innermost/></strategy></trsInput>"
            ),
            "srs": "<trsInput><trs/><string/></trsInput>",
            "cs-trs": (
                "<trsInput><trs/><strategy><contextSensitive/>"
                "</strategy></trsInput>"
            ),
            "dp": "<dpInput><trs/><dps/><minimal>false</minimal></dpInput>",
            "qdp": "<dpInput><trs/><dps/><minimal>true</minimal></dpInput>",
            "csdp": (
                "<dpInput><trs/><dps/><strategy><contextSensitive/>"
                "</strategy><minimal>false</minimal></dpInput>"
            ),
            "qcs-dp": (
                "<dpInput><trs/><dps/><strategy><contextSensitive/>"
                "</strategy><minimal>true</minimal></dpInput>"
            ),
        }
        self.assertEqual(
            {kind: CAMPAIGN.problem_kind(cpf) for kind, cpf in cases.items()},
            {kind: kind for kind in cases},
        )

    def test_context_retains_replacement_map_q_usable_and_extensions(self) -> None:
        cpf = """<dpInput><trs/><dps/><strategy><contextSensitive>
          <replacementMapEntry><name>f</name><position>2</position></replacementMapEntry>
        </contextSensitive></strategy><minimal>true</minimal>
        <usableRules><rules/></usableRules><q><rules/></q>
        <originContext><name>x</name></originContext></dpInput>"""
        context = CAMPAIGN.typed_problem_context(cpf)
        self.assertEqual(context["kind"], "qcs-dp")
        self.assertEqual(context["replacement_map"][0]["positions"], [2])
        self.assertIsNotNone(context["usable_rules"])
        self.assertIsNotNone(context["q"])
        self.assertEqual(len(context["transformation_context"]), 1)

    def test_rejects_context_losing_or_nonstandalone_child(self) -> None:
        valid, reason = CAMPAIGN.validate_materialized_child(
            "<certificationProblem><trsInput><trs/></trsInput></certificationProblem>"
        )
        self.assertFalse(valid)
        self.assertIn("standalone", reason)

    def test_oracle_prefers_raw_evidence_before_canonical_alias(self) -> None:
        connection = sqlite3.connect(":memory:")
        CAMPAIGN.initialize_results(connection)
        raw, _ = CAMPAIGN.register_state(
            connection, self.CPF, canonical_hash="shared"
        )
        alias_cpf = self.CPF.replace("<name>f</name>", "<name>g</name>")
        alias, _ = CAMPAIGN.register_state(
            connection, alias_cpf, canonical_hash="shared"
        )
        for state, atom, elapsed in (
            (raw, "subterm", 20),
            (alias, "matrix(dim=2)", 1),
        ):
            CAMPAIGN.enqueue_trial(
                connection, state, atom, "test", 1000, "impl", 1
            )
            connection.execute(
                """
                UPDATE trials SET state='completed', outcome='transformed',
                    certification_status='certified-fragment', elapsed_ms=?
                WHERE problem_key=? AND candidate=?
                """,
                (elapsed, state, atom),
            )
        self.assertEqual(
            CAMPAIGN.oracle_candidates(connection, raw, "impl"),
            ["subterm", "matrix(dim=2)"],
        )

    def test_certified_transition_enqueues_child_but_does_not_fake_assembly(self) -> None:
        connection = sqlite3.connect(":memory:")
        CAMPAIGN.initialize_results(connection)
        parent = "<trsInput><trs><rules/></trs><strategy><full/></strategy></trsInput>"
        parent_key = CAMPAIGN.raw_problem_hash(parent)
        CAMPAIGN.register_state(connection, parent, source_problem_key=parent_key)
        task_key = "transition-task"
        connection.execute(
            """
            INSERT INTO trials(
                task_key, problem_key, candidate, selection, validity_mask,
                timeout_ms, state, implementation_hash
            ) VALUES (?, ?, 'poly(max-constant=2,max-coefficient=2)',
                      'explore', 1, 1000, 'completed', 'impl')
            """,
            (task_key, parent_key),
        )
        child = self.CPF
        row = {
            "task_key": task_key,
            "problem_key": parent_key,
            "candidate": "poly(max-constant=2,max-coefficient=2)",
            "decision": "Unknown",
            "outcome": "transformed",
            "certification_status": "certified-fragment",
            "cpf_path": "/tmp/fragment.xml",
            "elapsed_ms": 10,
            "child_problems": [child],
        }
        discovered, scheduled = CAMPAIGN.record_certified_result(
            connection,
            row,
            parent,
            "impl",
            {
                "top-level": ["kbo(max-weight=2)"],
                "context-sensitive": [],
                "dependency-pair": [],
            },
            1,
            1000,
        )
        self.assertGreaterEqual(scheduled, 1)
        self.assertEqual(
            connection.execute(
                "SELECT COUNT(*) FROM trials WHERE selection='frontier-unseen'"
            ).fetchone()[0],
            1,
        )
        self.assertEqual(len(discovered), 1)
        child_hash = next(iter(discovered))
        connection.execute(
            """
            INSERT INTO terminal_proofs(
                raw_hash, task_key, processor_atom, certification_status,
                proof_path, implementation_hash
            ) VALUES (?, 'terminal-task', 'kbo', 'certified-full',
                      '/tmp/full.xml', 'impl')
            """,
            (child_hash,),
        )
        connection.execute(
            """
            INSERT INTO trials(
                task_key, problem_key, candidate, selection, validity_mask,
                timeout_ms, state, implementation_hash
            ) VALUES ('parameter-task', ?,
                      'poly(max-constant=4,max-coefficient=2)',
                      'parameter-escalate', 1, 2000, 'completed', 'impl')
            """,
            (parent_key,),
        )
        summary = CAMPAIGN.campaign_summary(connection)
        self.assertEqual(summary["certified_transformations"], 1)
        self.assertEqual(summary["covered_states"], 1)
        self.assertEqual(summary["uncovered_states"], 1)
        self.assertEqual(summary["allocation_lanes"]["escalation"], 1)
        json.dumps(summary)

    def test_residual_manifest_registers_child_without_certified_transition(self) -> None:
        connection = sqlite3.connect(":memory:")
        CAMPAIGN.initialize_results(connection)
        parent = "<trsInput><trs><rules/></trs><strategy><full/></strategy></trsInput>"
        parent_key = CAMPAIGN.raw_problem_hash(parent)
        CAMPAIGN.register_state(connection, parent, source_problem_key=parent_key)
        connection.execute(
            """
            INSERT INTO trials(
                task_key, problem_key, candidate, selection, validity_mask,
                timeout_ms, state, outcome, certification_status,
                implementation_hash
            ) VALUES ('manifest-task', ?, 'dp', 'external-proof-hint', 1,
                      1000, 'completed', 'transformed',
                      'residual-manifest', 'impl')
            """,
            (parent_key,),
        )
        row = {
            "task_key": "manifest-task",
            "problem_key": parent_key,
            "candidate": "dp",
            "decision": "Unknown",
            "outcome": "transformed",
            "certification_status": "residual-manifest",
            "cpf_path": None,
            "elapsed_ms": 10,
            "child_problems": [self.CPF],
        }

        # Imported evidence can pre-register a residual without having queued
        # any processor trial for it.  Rediscovering that state must still
        # schedule its frontier; enqueue_trial handles duplicate suppression.
        CAMPAIGN.register_state(connection, self.CPF)

        discovered, scheduled = CAMPAIGN.record_certified_result(
            connection,
            row,
            parent,
            "impl",
            {
                "top-level": ["kbo(max-weight=2)"],
                "context-sensitive": [],
                "dependency-pair": [],
            },
            1,
            1000,
        )

        self.assertEqual(len(discovered), 1)
        self.assertEqual(scheduled, 1)
        self.assertEqual(connection.execute("SELECT COUNT(*) FROM transitions").fetchone()[0], 0)
        self.assertEqual(
            connection.execute(
                "SELECT COUNT(*) FROM state_origins WHERE root_problem "
                "LIKE 'residual-manifest:%'"
            ).fetchone()[0],
            1,
        )

    def test_semantic_cache_precedes_structural_canonicalization(self) -> None:
        connection = sqlite3.connect(":memory:")
        CAMPAIGN.initialize_results(connection)
        cache = sqlite3.connect(":memory:")
        cache.execute(
            """
            CREATE TABLE canonical_cpf_cache(
                raw_key TEXT PRIMARY KEY, canonical_cpf TEXT, note TEXT
            )
            """
        )
        canonical = "<trsInput><trs/><strategy><full/></strategy></trsInput>"
        cache.execute(
            "INSERT INTO canonical_cpf_cache VALUES (?, ?, NULL)",
            (CAMPAIGN.raw_problem_hash(self.CPF), canonical),
        )
        raw_hash, _ = CAMPAIGN.register_state(
            connection, self.CPF, canonical_cache=cache
        )
        row = connection.execute(
            """
            SELECT canonical_hash, canonicalization_status FROM states
            WHERE raw_hash=?
            """,
            (raw_hash,),
        ).fetchone()
        self.assertEqual(
            row,
            (
                CAMPAIGN.hashlib.sha256(canonical.encode()).hexdigest(),
                "semantic-cache",
            ),
        )


if __name__ == "__main__":
    unittest.main()
