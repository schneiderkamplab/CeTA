#!/usr/bin/env python3
"""Copy an oracle without selected complete termination actions; preserve all others."""
import argparse
import collections
import hashlib
import json
import re
from pathlib import Path


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--input", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--disable-all-exact", action="store_true",
                        help="Experimental witness-free ablation, including nested exact actions")
    parser.add_argument("--disable-atom", action="append",
                        choices=("exact-dp-proof", "exact-trs-proof",
                                 "exact-dp-nontermination-proof", "exact-trs-nontermination-proof"),
                        help="Repeat to remove both kinds; defaults to exact-dp-proof")
    args = parser.parse_args()
    atoms = args.disable_atom or ["exact-dp-proof"]
    pattern = re.compile(r"(?<![A-Za-z0-9_-])(?:" +
                         (r"exact-[A-Za-z0-9_-]+" if args.disable_all_exact else "|".join(map(re.escape, atoms))) + r")\s*\(")
    blocked = set()
    definitions = 0
    with args.input.open() as stream:
        for line in stream:
            row = json.loads(line)
            if row.get("schema") == "ferrum.utility-guidance.witness.v1" and pattern.search(row["candidate"]):
                blocked.add(row["witness_id"])
                definitions += 1
    args.output.parent.mkdir(parents=True, exist_ok=True)
    removed = collections.Counter()
    changed_states = 0
    payloads = set(blocked)
    # Exclusive creation prevents overwriting an earlier campaign artifact.
    with args.output.open("x") as output, args.input.open() as stream:
        for line in stream:
            row = json.loads(line)
            if row.get("schema") == "ferrum.utility-guidance.witness.v1":
                if row["witness_id"] not in blocked:
                    output.write(line)
                continue
            changed = False
            for bucket in ("prefer", "possible", "avoid", "timeout"):
                kept = []
                for item in row.get(bucket, []):
                    candidate = item.get("candidate", "")
                    if item.get("candidate_ref") in blocked or pattern.search(candidate):
                        removed[bucket] += 1
                        changed = True
                        if candidate:
                            payloads.add(hashlib.sha256(candidate.encode()).hexdigest())
                    else:
                        kept.append(item)
                if bucket in row:
                    row[bucket] = kept
            if changed:
                changed_states += 1
                output.write(json.dumps(row, separators=(",", ":")) + "\n")
            else:
                output.write(line)
    print(json.dumps({"input": str(args.input), "output": str(args.output),
        "disabled_atoms": ["exact-*"] if args.disable_all_exact else atoms,
        "removed_witness_definitions": definitions, "removed_unique_payloads": len(payloads),
        "changed_state_records": changed_states, "removed_entries": dict(removed)}, indent=2))


if __name__ == "__main__":
    main()
