#!/usr/bin/env python3
"""Replay live processor states and retain complete proofs or typed transitions.

Only complete proofs are positive certified evidence.  A transformation with
residual states is retained as an assembly-required transition; it is not
promoted until every child has an independently certified proof and the
reconstructed parent proof passes production CeTA twice.
"""

from __future__ import annotations

import argparse
import concurrent.futures
import hashlib
import json
import os
import subprocess
from collections import Counter
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from build_credited_status_map_dataset import normalized_event_candidate


@dataclass(frozen=True)
class Trial:
    problem_id: str
    category: str
    problem_key: str
    cpf: str
    candidate: str


TOP_LEVEL_TRANSFORMATIONS = {
    "string-reversal",
    "switch-full",
    "switch-innermost",
    "uncurry",
}


def retained_outcome(candidate: str, probe_outcome: str) -> str:
    """Keep continuation-bearing top-level processors below terminal proofs.

    ``probe-cpf`` may close a transformation by running its ordinary fallback
    continuation and report ``solved``.  Oracle replay supplies a different
    continuation, so retaining that observation as terminal can rank the
    transformation ahead of a complete root proof and destroy executable
    monotonicity.
    """
    if candidate in TOP_LEVEL_TRANSFORMATIONS and probe_outcome == "solved":
        return "transformed"
    return probe_outcome


def load_trials(summary: Path) -> tuple[list[Trial], Counter[str]]:
    counts: Counter[str] = Counter()
    trials: dict[tuple[str, str], Trial] = {}
    text = summary.read_text(encoding="utf-8")
    if text.lstrip().startswith("["):
        parsed = json.loads(text)
        if not isinstance(parsed, list):
            raise ValueError(f"expected a JSON array in {summary}")
        results = parsed
    else:
        results = [
            json.loads(line)
            for line in text.splitlines()
            if line.strip()
        ]
    for result in results:
        if result.get("certified") is not True:
            counts["uncertified_roots_skipped"] += 1
            continue
        event_name = result.get("event_path")
        if event_name is None and result.get("artifact_dir") is not None:
            artifact_dir = Path(result["artifact_dir"])
            event_name = next(
                (
                    path
                    for path in (
                        artifact_dir / "processor-events.jsonl",
                        artifact_dir / "progress.jsonl",
                    )
                    if path.is_file()
                ),
                None,
            )
        if event_name is None:
            counts["certified_roots_without_events"] += 1
            continue
        event_path = Path(event_name)
        if not event_path.is_file():
            counts["certified_roots_without_events"] += 1
            continue
        events = [
            json.loads(event_line)
            for event_line in event_path.read_text(
                encoding="utf-8", errors="replace"
            ).splitlines()
            if event_line.strip()
        ]
        cpf_by_key = {
            str((event.get("input") or {}).get("problem_key")): cpf
            for event in events
            if isinstance(cpf := (event.get("input") or {}).get("cpf"), str)
            and cpf.strip()
        }
        for event in events:
            if event.get("outcome") not in {"solved", "transformed"}:
                continue
            if event.get("strategy_atom") in {
                "utility-guidance",
                "llm-guidance",
            }:
                continue
            candidate = normalized_event_candidate(event)
            key = (event.get("input") or {}).get("problem_key")
            if not isinstance(candidate, str) or not isinstance(key, str):
                counts["positive_without_candidate_or_key"] += 1
                continue
            cpf = (event.get("input") or {}).get("cpf") or cpf_by_key.get(key)
            if not isinstance(cpf, str) or not cpf.strip():
                counts["positive_without_hydratable_cpf"] += 1
                continue
            trials.setdefault(
                (key, candidate),
                Trial(
                    problem_id=str(
                        event.get("problem_id")
                        or result.get("problem_id")
                        or result.get("path")
                    ),
                    category=str(event.get("category") or result.get("category")),
                    problem_key=key,
                    cpf=cpf,
                    candidate=candidate,
                ),
            )
    counts["trials"] = len(trials)
    return sorted(
        trials.values(), key=lambda trial: (trial.problem_key, trial.candidate)
    ), counts


def run_checked(
    trial: Trial,
    ferrum: Path,
    ceta: Path,
    proofs: Path,
    timeout_seconds: float,
    rayon_threads: int,
) -> tuple[dict[str, Any] | None, str]:
    trial_id = hashlib.sha256(
        f"{trial.problem_key}\0{trial.candidate}".encode()
    ).hexdigest()
    input_path = proofs / f"{trial_id}.input.xml"
    proof_path = proofs / f"{trial_id}.cpf.xml"
    input_path.write_text(trial.cpf, encoding="utf-8")
    environment = os.environ.copy()
    environment["RAYON_NUM_THREADS"] = str(rayon_threads)
    try:
        probe = subprocess.run(
            [
                str(ferrum),
                "probe-cpf",
                str(input_path),
                "--strategy",
                trial.candidate,
                "--timeout-ms",
                str(int(timeout_seconds * 1000)),
                "--cpf",
                str(proof_path),
            ],
            text=True,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            timeout=timeout_seconds + 5,
            env=environment,
        )
    except subprocess.TimeoutExpired:
        return None, "probe-timeout"
    if probe.returncode != 0:
        return None, "probe-failed"
    try:
        payload = json.loads(probe.stdout.splitlines()[-1])
    except (IndexError, json.JSONDecodeError):
        return None, "probe-invalid-json"
    probe_outcome = payload.get("outcome")
    if probe_outcome not in {"solved", "transformed"} or not proof_path.is_file():
        return None, f"probe-{probe_outcome or 'not-positive'}"
    outcome = retained_outcome(trial.candidate, probe_outcome)
    children = payload.get("children")
    if outcome == "transformed":
        if not isinstance(children, list) or not children:
            return None, "transition-without-materialized-children"
        certification_status = "assembly-required"
        checker_replays = 0
    else:
        checker_command = [str(ceta), str(proof_path)]
        for attempt in range(2):
            try:
                checked = subprocess.run(
                    checker_command,
                    text=True,
                    stdout=subprocess.PIPE,
                    stderr=subprocess.STDOUT,
                    timeout=timeout_seconds,
                )
            except subprocess.TimeoutExpired:
                return None, f"checker-timeout-{attempt + 1}"
            if checked.returncode != 0 or "CERTIFIED" not in checked.stdout:
                return None, f"checker-rejected-{attempt + 1}"
        certification_status = "certified-full"
        checker_replays = 2
    event = {
        "schema": "ferrum.processor-event.v1",
        "run_id": "manual-live-fragment-freeze",
        "problem_id": trial.problem_id,
        "category": trial.category,
        "level": payload.get("level"),
        "problem_kind": payload.get("problem_kind"),
        "processor": trial.candidate,
        "strategy_atom": trial.candidate,
        "outcome": outcome,
        "progress": "closed" if outcome == "solved" else "weak",
        "elapsed_ms": payload.get("elapsed_ms"),
        "input": {
            "format": "cpf-xml",
            "cpf": trial.cpf,
            "problem_key": trial.problem_key,
        },
        "metrics": {
            "retained_proof_path": str(proof_path),
            "checker_replays": checker_replays,
            "materialized_children": len(children or []),
        },
        "witness": {
            "kind": (
                "certified-complete-proof"
                if outcome == "solved"
                else "typed-transition-awaiting-assembly"
            ),
            "path": str(proof_path),
            "children": children or [],
        },
        "certification": {
            "status": certification_status,
            "checker": str(ceta) if outcome == "solved" else None,
        },
        "credit": {
            "status": (
                "proof-path-certified"
                if outcome == "solved"
                else "pending-complete-assembly"
            )
        },
    }
    return event, (
        "certified-complete" if outcome == "solved" else "assembly-required"
    )


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--summary", type=Path, required=True)
    parser.add_argument("--ferrum", type=Path, required=True)
    parser.add_argument("--ceta", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--proof-dir", type=Path, required=True)
    parser.add_argument("--jobs", type=int, default=32)
    parser.add_argument("--rayon-threads", type=int, default=2)
    parser.add_argument("--timeout", type=float, default=60.0)
    args = parser.parse_args()

    trials, counts = load_trials(args.summary)
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.proof_dir.mkdir(parents=True, exist_ok=True)
    results: list[dict[str, Any]] = []
    audit_rows: list[dict[str, str]] = []
    with concurrent.futures.ThreadPoolExecutor(max_workers=args.jobs) as executor:
        futures = {
            executor.submit(
                run_checked,
                trial,
                args.ferrum.resolve(),
                args.ceta.resolve(),
                args.proof_dir,
                args.timeout,
                args.rayon_threads,
            ): trial
            for trial in trials
        }
        for index, future in enumerate(
            concurrent.futures.as_completed(futures), start=1
        ):
            trial = futures[future]
            event, status = future.result()
            counts[status] += 1
            audit_rows.append(
                {
                    "problem_id": trial.problem_id,
                    "problem_key": trial.problem_key,
                    "candidate": trial.candidate,
                    "status": status,
                }
            )
            if event is not None:
                results.append(event)
            if index % 25 == 0 or index == len(futures):
                print(
                    f"manual-fragment-freeze {index}/{len(futures)} "
                    f"complete={counts['certified-complete']} "
                    f"pending={counts['assembly-required']} "
                    f"rejected={sum(value for key, value in counts.items() if key.startswith('checker-'))}",
                    flush=True,
                )
    with args.output.open("w", encoding="utf-8") as sink:
        for event in sorted(
            results,
            key=lambda row: (
                row["input"]["problem_key"],
                row["strategy_atom"],
            ),
        ):
            sink.write(json.dumps(event, sort_keys=True, separators=(",", ":")) + "\n")
    audit_path = args.output.with_suffix(args.output.suffix + ".audit.jsonl")
    with audit_path.open("w", encoding="utf-8") as sink:
        for row in sorted(
            audit_rows,
            key=lambda item: (item["problem_key"], item["candidate"]),
        ):
            sink.write(json.dumps(row, sort_keys=True, separators=(",", ":")) + "\n")
    summary = {
        "schema": "ferrum.manual-live-fragment-freeze.v1",
        "counts": dict(sorted(counts.items())),
        "output": str(args.output),
        "audit": str(audit_path),
        "proof_dir": str(args.proof_dir),
    }
    args.output.with_suffix(args.output.suffix + ".summary.json").write_text(
        json.dumps(summary, indent=2, sort_keys=True) + "\n", encoding="utf-8"
    )
    print(json.dumps(summary, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
