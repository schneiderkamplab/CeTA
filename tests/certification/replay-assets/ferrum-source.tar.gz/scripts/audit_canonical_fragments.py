#!/usr/bin/env python3
"""Audit canonical proof-fragment rows with CeTA.

The training rows are local proof fragments.  This checker reconstructs a
standalone CPF certificate when the row contains enough local context to do so,
normalizes simple CPF2 term syntax to CPF3 where possible, and then invokes
CeTA with ``--allow-assumptions``.  The verification kernel is therefore CeTA's
existing verified checker; this script only builds candidate audit certificates
and records precise unsupported/failure classes.
"""

from __future__ import annotations

import argparse
import concurrent.futures
import gzip
import hashlib
import json
import os
import re
import subprocess
import tempfile
import time
import xml.etree.ElementTree as ET
from dataclasses import dataclass
from pathlib import Path
from typing import Any


TOP_LEVEL_PROOF_TAGS = {
    "trsTerminationProof",
    "trsNonterminationProof",
    "relativeNonterminationProof",
    "dpProof",
    "dpNonterminationProof",
}

TERMINATION_PROCESSORS = {
    "dpTrans",
    "ruleRemoval",
    "stringReversal",
    "bounds",
    "relativeBounds",
    "rfcBounds",
    "split",
    "assumeSN",
}

NONTERMINATION_PROCESSORS = {"loop", "nonLoop"}

TRS_PROOF_STEP_TAGS = {
    "rIsEmpty",
    "ruleRemoval",
    "dpTrans",
    "stringReversal",
    "equalityRemoval",
    "bounds",
    "relativeBounds",
    "rfcBounds",
    "terminationAssumption",
}

DP_PROOF_STEP_TAGS = {
    "pIsEmpty",
    "narrowingProc",
    "instantiationProc",
    "forwardInstantiationProc",
    "csrForwardInstantiationProc",
    "rewriteProc",
    "rewritingProc",
    "semlabProc",
    "subtermProc",
    "redPairProc",
    "redPairUrProc",
    "monoRedPairProc",
    "monoRedPairUrProc",
    "usableRulesProc",
    "depGraphProc",
    "sizeChangeProc",
    "switchInnermostProc",
    "splitProc",
    "finitenessAssumption",
}


def open_input(path: Path):
    return gzip.open(path, "rt", encoding="utf-8") if path.suffix == ".gz" else path.open("r", encoding="utf-8")


def local_name(tag: str) -> str:
    return tag.rsplit("}", 1)[-1]


def first_child(elem: ET.Element, name: str) -> ET.Element | None:
    for child in list(elem):
        if local_name(child.tag) == name:
            return child
    return None


def term_child(elem: ET.Element) -> ET.Element | None:
    for child in list(elem):
        if local_name(child.tag) in {"funapp", "var", "termIndex"}:
            return child
    return None


def clone(elem: ET.Element) -> ET.Element:
    return ET.fromstring(ET.tostring(elem, encoding="utf-8"))


def term_equal(a: ET.Element, b: ET.Element) -> bool:
    return ET.tostring(a, encoding="utf-8") == ET.tostring(b, encoding="utf-8")


def match_term(pattern: ET.Element, term: ET.Element, subst: dict[str, ET.Element]) -> bool:
    if local_name(pattern.tag) == "var":
        name = "".join(pattern.itertext()).strip()
        if name in subst:
            return term_equal(subst[name], term)
        subst[name] = clone(term)
        return True
    if local_name(pattern.tag) != local_name(term.tag):
        return False
    if local_name(pattern.tag) == "funapp":
        pname = first_child(pattern, "name")
        tname = first_child(term, "name")
        psharp = first_child(pattern, "sharp")
        tsharp = first_child(term, "sharp")
        if (pname is None) != (tname is None) or (psharp is None) != (tsharp is None):
            return False
        if pname is not None and "".join(pname.itertext()).strip() != "".join(tname.itertext()).strip():
            return False
        if psharp is not None and ET.tostring(psharp, encoding="utf-8") != ET.tostring(tsharp, encoding="utf-8"):
            return False
        pargs = [c for c in list(pattern) if local_name(c.tag) in {"funapp", "var", "termIndex"}]
        targs = [c for c in list(term) if local_name(c.tag) in {"funapp", "var", "termIndex"}]
        return len(pargs) == len(targs) and all(match_term(p, t, subst) for p, t in zip(pargs, targs))
    return term_equal(pattern, term)


def apply_subst(term: ET.Element, subst: dict[str, ET.Element]) -> ET.Element:
    if local_name(term.tag) == "var":
        name = "".join(term.itertext()).strip()
        return clone(subst[name]) if name in subst else clone(term)
    out = ET.Element(term.tag, dict(term.attrib))
    out.text = term.text
    out.tail = term.tail
    for child in list(term):
        if local_name(child.tag) in {"funapp", "var", "termIndex"}:
            out.append(apply_subst(child, subst))
        else:
            out.append(clone(child))
    return out


def positions(position_elem: ET.Element | None) -> list[int]:
    if position_elem is None:
        return []
    return [int("".join(child.itertext()).strip()) for child in list(position_elem) if local_name(child.tag) == "position"]


def subterm_at(term: ET.Element, pos: list[int]) -> ET.Element | None:
    current = term
    for index in pos:
        args = [c for c in list(current) if local_name(c.tag) in {"funapp", "var", "termIndex"}]
        if index < 1 or index > len(args):
            return None
        current = args[index - 1]
    return current


def replace_subterm(term: ET.Element, pos: list[int], replacement: ET.Element) -> ET.Element:
    if not pos:
        return clone(replacement)
    out = clone(term)
    current = out
    for index in pos[:-1]:
        args = [c for c in list(current) if local_name(c.tag) in {"funapp", "var", "termIndex"}]
        current = args[index - 1]
    args = [c for c in list(current) if local_name(c.tag) in {"funapp", "var", "termIndex"}]
    old = args[pos[-1] - 1]
    child_index = list(current).index(old)
    current.remove(old)
    current.insert(child_index, clone(replacement))
    return out


def repair_old_loop(elem: ET.Element) -> None:
    if local_name(elem.tag) != "loop":
        return
    redexes = [child for child in list(elem) if local_name(child.tag) == "redex"]
    if not redexes:
        return
    start = term_child(redexes[0])
    if start is None:
        return
    seq = ET.Element("rewriteSequence")
    st = ET.SubElement(seq, "startTerm")
    st.append(clone(start))
    current = clone(start)
    for redex in redexes:
        rule_elem = first_child(redex, "rule")
        pos_elem = first_child(redex, "positionInTerm")
        if rule_elem is None or len(rule_elem) < 2:
            return
        lhs, rhs = rule_elem[0], rule_elem[1]
        pos = positions(pos_elem)
        target = subterm_at(current, pos)
        if target is None:
            return
        subst: dict[str, ET.Element] = {}
        if not match_term(lhs, target, subst):
            return
        after = replace_subterm(current, pos, apply_subst(rhs, subst))
        step = ET.SubElement(seq, "rewriteStep")
        step.append(clone(pos_elem) if pos_elem is not None else ET.Element("positionInTerm"))
        step.append(clone(rule_elem))
        step.append(clone(after))
        current = after
    idx = list(elem).index(redexes[0])
    for redex in redexes:
        elem.remove(redex)
    elem.insert(idx, seq)


def sha256_text(text: str) -> str:
    return hashlib.sha256(text.encode()).hexdigest()


def replace_proof_hole(context_xml: str, output_xml: str) -> str:
    if "<proofHole" not in context_xml:
        raise ValueError("context has no proofHole")
    return re.sub(r"<proofHole\b[^>]*/>", output_xml, context_xml, count=1)


def normalize_cpf2_terms(elem: ET.Element) -> None:
    """Normalize common CPF2 term syntax to CPF3 syntax in-place.

    CPF2 commonly encodes rules as ``<rule><lhs>t</lhs><rhs>u</rhs></rule>``
    and function arguments as ``<arg>t</arg>``.  CPF3 uses direct term children.
    This does not attempt to translate all historical proof payload changes;
    CeTA remains the authority on whether the result is accepted.
    """
    for child in list(elem):
        normalize_cpf2_terms(child)
    name = local_name(elem.tag)
    if name == "relativeTerminationProof":
        elem.tag = "trsTerminationProof"
    if name == "coefficient" and len(elem) == 1:
        child = elem[0]
        elem.tag = child.tag
        elem.attrib.clear()
        elem.text = child.text
        elem.tail = child.tail
        elem[:] = list(child)
        name = local_name(elem.tag)
    if name == "rationals" and first_child(elem, "delta") is None:
        delta = ET.Element("delta")
        rat = ET.SubElement(delta, "rational")
        ET.SubElement(rat, "numerator").text = "1"
        ET.SubElement(rat, "denominator").text = "1"
        elem.insert(0, delta)
    if name == "dpTrans":
        elem[:] = [child for child in list(elem) if local_name(child.tag) != "markedSymbols"]
        for child in list(elem):
            if local_name(child.tag) in DP_PROOF_STEP_TAGS:
                idx = list(elem).index(child)
                elem.remove(child)
                wrapper = ET.Element("dpProof")
                wrapper.append(child)
                elem.insert(idx, wrapper)
                break
    if name == "component":
        elem[:] = [child for child in list(elem) if local_name(child.tag) not in {"realScc", "arcs"}]
    expression_tags = {"integer", "rational", "algebraic", "minusInfinity", "variable", "sum", "product", "vector", "matrix"}
    if name != "type":
        rewritten = []
        changed = False
        for child in list(elem):
            if local_name(child.tag) == "polynomial" and len(child) == 1 and local_name(child[0].tag) in expression_tags:
                rewritten.append(child[0])
                changed = True
            else:
                rewritten.append(child)
        if changed:
            elem[:] = rewritten
    if local_name(elem.tag) == "funapp":
        rewritten = []
        for child in list(elem):
            if local_name(child.tag) == "arg" and len(child) == 1:
                rewritten.append(child[0])
            else:
                rewritten.append(child)
        elem[:] = rewritten
    if local_name(elem.tag) == "rule":
        lhs = None
        rhs = None
        rest = []
        for child in list(elem):
            name = local_name(child.tag)
            if name == "lhs" and len(child) == 1:
                lhs = child[0]
            elif name == "rhs" and len(child) == 1:
                rhs = child[0]
            else:
                rest.append(child)
        if lhs is not None and rhs is not None:
            elem[:] = [lhs, rhs, *rest]
    if local_name(elem.tag) == "stringReversal":
        children = list(elem)
        proof_idx = next((i for i, child in enumerate(children) if local_name(child.tag) in {"trsTerminationProof", "trsNonterminationProof"}), None)
        if proof_idx is not None:
            trs_before_proof = [i for i, child in enumerate(children[:proof_idx]) if local_name(child.tag) == "trs"]
            for idx in reversed(trs_before_proof[1:]):
                elem.remove(children[idx])
    if local_name(elem.tag) == "ruleRemoval":
        children = list(elem)
        proof_idx = next((i for i, child in enumerate(children) if local_name(child.tag) in {"trsTerminationProof", "trsNonterminationProof"}), None)
        if proof_idx is not None:
            trs_before_proof = [i for i, child in enumerate(children[:proof_idx]) if local_name(child.tag) == "trs"]
            for idx in reversed(trs_before_proof[1:]):
                elem.remove(children[idx])
    if local_name(elem.tag) == "pathOrder":
        elem.tag = "recursivePathOrder"
    if local_name(elem.tag) == "orderingConstraintProof" and len(elem) == 1:
        child = elem[0]
        if local_name(child.tag) == "redPair" and len(child) == 1:
            elem.tag = child[0].tag
            elem.attrib.clear()
            elem[:] = list(child[0])
        elif local_name(child.tag) in {"pathOrder", "recursivePathOrder", "interpretation", "knuthBendixOrder"}:
            elem.tag = child.tag
            elem.attrib.clear()
            elem[:] = list(child)
    if local_name(elem.tag) == "redPair" and len(elem) == 1:
        child = elem[0]
        elem.tag = child.tag
        elem.attrib.clear()
        elem[:] = list(child)
    if local_name(elem.tag) in {"ruleRemoval", "stringReversal", "equalityRemoval", "removeNonApplicableRules"}:
        for child in list(elem):
            if local_name(child.tag) in TRS_PROOF_STEP_TAGS:
                idx = list(elem).index(child)
                elem.remove(child)
                wrapper = ET.Element("trsTerminationProof")
                wrapper.append(child)
                elem.insert(idx, wrapper)
                break
    repair_old_loop(elem)
    if local_name(elem.tag) in {
        "narrowingProc",
        "instantiationProc",
        "forwardInstantiationProc",
        "csrForwardInstantiationProc",
        "semlabProc",
        "subtermProc",
        "redPairProc",
        "redPairUrProc",
        "monoRedPairProc",
        "monoRedPairUrProc",
        "usableRulesProc",
        "innermostLhssRemovalProc",
        "rewritingProc",
        "switchInnermostProc",
        "splitProc",
    }:
        for child in list(elem):
            if local_name(child.tag) in DP_PROOF_STEP_TAGS:
                idx = list(elem).index(child)
                elem.remove(child)
                wrapper = ET.Element("dpProof")
                wrapper.append(child)
                elem.insert(idx, wrapper)
                break


def parse_normalized_fragment(xml: str) -> ET.Element:
    elem = ET.fromstring(xml.encode())
    normalize_cpf2_terms(elem)
    return elem


def result_answer(result: str) -> str | None:
    upper = result.upper()
    if "YES" in upper:
        return "yes"
    if "NO" in upper:
        return "no"
    return None


def wrap_top_level_proof(proof_elem: ET.Element, answer: str) -> ET.Element:
    """Ensure CPF3 proof has a recognized top-level proof constructor."""
    if local_name(proof_elem.tag) != "proof":
        proof = ET.Element("proof")
        proof.append(proof_elem)
        proof_elem = proof
    if len(proof_elem) == 1:
        child = proof_elem[0]
        child_name = local_name(child.tag)
        if child_name not in TOP_LEVEL_PROOF_TAGS:
            if child_name in DP_PROOF_STEP_TAGS:
                wrapper = ET.Element("dpProof" if answer == "yes" else "dpNonterminationProof")
            else:
                wrapper = ET.Element("trsTerminationProof" if answer == "yes" else "trsNonterminationProof")
            proof_elem.remove(child)
            wrapper.append(child)
            proof_elem.append(wrapper)
    return proof_elem


def make_cpf3_certificate(row: dict[str, Any]) -> tuple[str | None, str | None]:
    audit = row.get("fragment_audit") or {}
    if audit.get("status") == "unsupported":
        return None, str(audit.get("reason") or "fragment_materializer_unsupported")
    existing = audit.get("cpf3_certificate")
    if existing:
        return str(existing), None
    metadata = row.get("metadata") or {}
    norm = row.get("cpf_normalization") or {}
    input_obj = row.get("input") or {}
    output_xml = row.get("output_xml") or ""
    context_xml = input_obj.get("local_context_xml") or ""
    problem_xml = input_obj.get("problem_xml") or ""

    if not str(problem_xml).lstrip().startswith("<input"):
        return None, f"unsupported_input_not_cpf:{norm.get('input_status')}"
    if norm.get("output_status") != "cpf-output-preserved":
        return None, f"unsupported_output_status:{norm.get('output_status')}"
    if not problem_xml or not context_xml or not output_xml:
        return None, "unsupported_missing_xml"
    answer = result_answer(str(metadata.get("result") or ""))
    if answer is None:
        return None, "unsupported_no_yes_no_answer"

    try:
        replaced = replace_proof_hole(context_xml, output_xml)
        input_elem = parse_normalized_fragment(problem_xml)
        proof_elem = wrap_top_level_proof(parse_normalized_fragment(replaced), answer)
    except Exception as exc:
        return None, f"unsupported_xml_parse:{type(exc).__name__}"

    if local_name(input_elem.tag) != "input":
        return None, "unsupported_problem_not_input"
    if local_name(proof_elem.tag) != "proof":
        return None, "unsupported_context_not_proof"

    root = ET.Element("certificationProblem")
    ET.SubElement(root, "cpfVersion").text = "3.0"
    ET.SubElement(root, "lookupTables")
    root.append(input_elem)
    prop = ET.SubElement(root, "property")
    ET.SubElement(prop, "termination")
    ans = ET.SubElement(root, "answer")
    ET.SubElement(ans, answer)
    root.append(proof_elem)
    meta = ET.SubElement(root, "metaInformation")
    ET.SubElement(meta, "toolInfos")
    xml = ET.tostring(root, encoding="utf-8", xml_declaration=True, short_empty_elements=True).decode()
    return xml, None


@dataclass(frozen=True)
class WorkItem:
    row_index: int
    row: dict[str, Any]


def ceta_check(ceta: Path, xml: str, work_dir: Path, row_id: str, timeout: int, keep: str) -> tuple[str, str, float, Path | None]:
    digest = sha256_text(xml)[:16]
    out_path = work_dir / f"{row_id[:16]}-{digest}.cpf3.xml"
    out_path.write_text(xml, encoding="utf-8")
    start = time.monotonic()
    try:
        proc = subprocess.run(
            [str(ceta), "--allow-assumptions", str(out_path)],
            text=True,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            timeout=timeout,
        )
        elapsed = time.monotonic() - start
        output = proc.stdout[-4000:]
        if proc.returncode == 0 and "CERTIFIED" in proc.stdout:
            status = "certified"
        else:
            status = "ceta_failed"
    except subprocess.TimeoutExpired as exc:
        elapsed = time.monotonic() - start
        output = (exc.stdout or "")[-4000:] if isinstance(exc.stdout, str) else "timeout"
        status = "timeout"

    keep_file = keep == "all" or (keep == "failures" and status != "certified")
    if not keep_file:
        try:
            out_path.unlink()
            saved = None
        except OSError:
            saved = out_path
    else:
        saved = out_path
    return status, output, elapsed, saved


def audit_one(args: tuple[WorkItem, str, str, int, str]) -> dict[str, Any]:
    item, ceta_s, work_dir_s, timeout, keep = args
    row = item.row
    metadata = row.get("metadata") or {}
    result = {
        "row_index": item.row_index,
        "row_id": row.get("id"),
        "source_row_id": row.get("source_row_id"),
        "category": metadata.get("category"),
        "benchmark": metadata.get("benchmark"),
        "tool": metadata.get("tool"),
        "year": metadata.get("year"),
        "processor_tag": metadata.get("processor_tag"),
        "result": metadata.get("result"),
        "source_path": (row.get("source") or {}).get("xml_path"),
    }
    xml, reason = make_cpf3_certificate(row)
    if xml is None:
        result.update({"status": "unsupported", "reason": reason})
        return result
    status, output, elapsed, saved = ceta_check(Path(ceta_s), xml, Path(work_dir_s), str(row.get("id") or "row"), timeout, keep)
    result.update(
        {
            "status": status,
            "elapsed_sec": round(elapsed, 6),
            "certificate_path": str(saved) if saved is not None else None,
            "ceta_tail": output if status != "certified" else "",
        }
    )
    return result


def category_is_trs_srs(category: str) -> bool:
    return "TRS" in category or "SRS" in category or "Rewriting" in category


def load_manifest_filter(path: Path | None) -> set[str] | None:
    if path is None:
        return None
    ids: set[str] = set()
    with open_input(path) as handle:
        for line in handle:
            item = json.loads(line)
            row_id = item.get("row_id")
            if row_id:
                ids.add(row_id)
    return ids


def iter_work_items(jsonl: Path, manifest_ids: set[str] | None, limit: int | None):
    yielded = 0
    with open_input(jsonl) as handle:
        for row_index, line in enumerate(handle, start=1):
            row = json.loads(line)
            row_id = row.get("id")
            if manifest_ids is not None and row_id not in manifest_ids:
                continue
            category = str((row.get("metadata") or {}).get("category") or "")
            if not category_is_trs_srs(category):
                continue
            yielded += 1
            yield WorkItem(row_index=row_index, row=row)
            if limit is not None and yielded >= limit:
                return


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--jsonl", type=Path, default=Path("target/termcomp-proof-corpus/training/subproofs.cpf.canonical.final.jsonl.gz"))
    parser.add_argument("--manifest", type=Path, default=Path("target/termcomp-proof-corpus/audit-manifests/canonical-trs-srs-manifest.jsonl.gz"))
    parser.add_argument("--no-manifest", action="store_true", help="scan JSONL without filtering by manifest row IDs")
    parser.add_argument("--out-dir", type=Path, default=Path("target/termcomp-proof-corpus/fragment-audit/canonical-final"))
    parser.add_argument("--ceta", type=Path, default=Path(".tools/ceta-relative-bounds"))
    parser.add_argument("--workers", type=int, default=max(1, min(64, os.cpu_count() or 1)))
    parser.add_argument("--timeout", type=int, default=30)
    parser.add_argument("--limit", type=int)
    parser.add_argument("--progress-interval", type=int, default=1000)
    parser.add_argument("--keep-certificates", choices=["none", "failures", "all"], default="failures")
    args = parser.parse_args()

    args.out_dir.mkdir(parents=True, exist_ok=True)
    work_dir = args.out_dir / "certificates"
    work_dir.mkdir(exist_ok=True)
    results_path = args.out_dir / "results.jsonl.gz"
    summary_path = args.out_dir / "summary.json"

    manifest_ids = None if args.no_manifest else load_manifest_filter(args.manifest)
    counts: dict[str, int] = {}
    reason_counts: dict[str, int] = {}
    processor_counts: dict[str, int] = {}
    elapsed_total = 0.0
    processed = 0
    started = time.monotonic()

    with gzip.open(results_path, "wt", encoding="utf-8") as sink:
        work = ((item, str(args.ceta), str(work_dir), args.timeout, args.keep_certificates) for item in iter_work_items(args.jsonl, manifest_ids, args.limit))
        with concurrent.futures.ProcessPoolExecutor(max_workers=args.workers) as pool:
            for result in pool.map(audit_one, work, chunksize=8):
                processed += 1
                status = str(result.get("status"))
                counts[status] = counts.get(status, 0) + 1
                if result.get("reason"):
                    reason = str(result["reason"])
                    reason_counts[reason] = reason_counts.get(reason, 0) + 1
                if result.get("processor_tag"):
                    proc = str(result["processor_tag"])
                    processor_counts[proc] = processor_counts.get(proc, 0) + 1
                elapsed_total += float(result.get("elapsed_sec") or 0.0)
                sink.write(json.dumps(result, sort_keys=True, separators=(",", ":")) + "\n")
                if args.progress_interval > 0 and processed % args.progress_interval == 0:
                    print(
                        json.dumps(
                            {
                                "event": "progress",
                                "processed": processed,
                                "counts": counts,
                                "elapsed_wall_sec": round(time.monotonic() - started, 3),
                            },
                            sort_keys=True,
                        ),
                        flush=True,
                    )

    summary = {
        "jsonl": str(args.jsonl),
        "manifest": None if args.no_manifest else str(args.manifest),
        "results": str(results_path),
        "processed": processed,
        "counts": dict(sorted(counts.items())),
        "reason_counts": dict(sorted(reason_counts.items())),
        "processor_counts": dict(sorted(processor_counts.items())),
        "ceta_elapsed_total_sec": round(elapsed_total, 6),
        "wall_elapsed_sec": round(time.monotonic() - started, 6),
        "workers": args.workers,
        "timeout": args.timeout,
    }
    summary_path.write_text(json.dumps(summary, indent=2, sort_keys=True), encoding="utf-8")
    print(json.dumps(summary, sort_keys=True), flush=True)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
