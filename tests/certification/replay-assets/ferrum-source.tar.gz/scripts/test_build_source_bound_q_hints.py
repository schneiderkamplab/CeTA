import json
import hashlib
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch
from types import SimpleNamespace

from build_source_bound_q_hints import portable_atom, main


class SourceBoundHintsTests(unittest.TestCase):
    def test_q_binds_actual_runtime_source(self):
        old = 'exact-innermost-lhss(hex=' + json.dumps('<q/>').encode().hex() + ')'
        bound = portable_atom(old, '<dpInput/>')
        self.assertEqual(json.loads(bytes.fromhex(bound.split('hex=')[1][:-1])),
                         ['<q/>', '<dpInput/>'])
        rebound = portable_atom(bound, '<live/>')
        self.assertEqual(json.loads(bytes.fromhex(rebound.split('hex=')[1][:-1])),
                         ['<q/>', '<live/>'])

    def test_other_atoms_are_explicitly_opt_in(self):
        self.assertIsNone(portable_atom('graph', '<dpInput/>'))
        self.assertEqual(portable_atom('graph', '<dpInput/>', True), 'graph')

    def test_top_order_gets_source_binding_not_a_pipeline(self):
        atom = 'exact-kbo(hex=00)'
        bound = portable_atom(atom, '<trsInput/>', True)
        self.assertEqual(json.loads(bytes.fromhex(bound.split('hex=')[1][:-1])), ['<trsInput/>', atom])
        self.assertEqual(portable_atom(atom, '<dpInput/>', True), atom)

    def test_compound_strategies_are_never_exported(self):
        for atom in ['graph; size-change', 'timeout(60s, graph)', 'dp(graph)',
                     'parallel(graph, size-change)', 'exact-dp-proof(hex=00)',
                     'exact-trs-nontermination-proof(hex=00)']:
            self.assertIsNone(portable_atom(atom, '<dpInput/>', True))

    def test_semantic_models_and_transformations_retain_their_source(self):
        for family, payload in [('exact-semantic-labeling', {'carrier_size': 2}),
                                ('exact-dp-transform', ['narrowingProc', '<payload/>', '<child/>'])]:
            atom = family + '(hex=' + json.dumps(payload).encode().hex() + ')'
            bound = portable_atom(atom, '<dpInput/>', True)
            result = json.loads(bytes.fromhex(bound.split('hex=')[1][:-1]))
            self.assertEqual(result, [payload, '<dpInput/>'] if isinstance(payload, dict)
                             else [*payload, '<dpInput/>'])
            self.assertEqual(portable_atom(bound, '<different/>', True), bound)

    def test_csr_linear_and_matrix_actions_are_bound_individually(self):
        for atom in ['exact-poly(hex=00)', 'exact-matrix(hex=00)']:
            source = '<trsInput><strategy><contextSensitive/></strategy></trsInput>'
            bound = portable_atom(atom, source, True)
            self.assertEqual(json.loads(bytes.fromhex(bound.split('hex=')[1][:-1])), [source, atom])

    def test_native_atom_is_inline_and_never_gets_certified_credit(self):
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            proof = root / 'proof.xml'
            proof.write_text('checked proof')
            checks = root / 'checks.jsonl'
            checks.write_text(json.dumps(dict(certified=True, input='source', proof=str(proof),
                sha256=hashlib.sha256(proof.read_bytes()).hexdigest(),
                checks=[dict(accepted=True), dict(accepted=True)])) + '\n')
            source = '<dpInput/>'
            events = root / 'events.jsonl'
            events.write_text(json.dumps(dict(problem_id='source', outcome='solved', processor='graph',
                input=dict(cpf=source, problem_key=hashlib.sha256(source.encode()).hexdigest()))) + '\n')
            output = root / 'output.jsonl'
            with patch('sys.argv', ['hints', '--checks', str(checks), '--events', str(events),
                                   '--ferrum', '/unused', '--output', str(output), '--all-modular']), \
                 patch('build_source_bound_q_hints.subprocess.run', return_value=SimpleNamespace(stdout=source)):
                main()
            rows = list(map(json.loads, output.read_text().splitlines()))
            self.assertEqual(len(rows), 1)
            self.assertEqual(rows[0]['prefer'], [])
            candidate = rows[0]['possible'][0]
            self.assertEqual(candidate['candidate'], 'graph')
            self.assertNotIn('candidate_ref', candidate)
            self.assertEqual(candidate['certified_count'], 0)
            self.assertEqual(candidate['solved_count'], 0)


if __name__ == '__main__':
    unittest.main()
