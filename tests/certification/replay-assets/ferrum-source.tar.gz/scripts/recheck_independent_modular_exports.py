#!/usr/bin/env python3
"""Repeat failed probes/rejected standalone positives with a repaired binary."""
import argparse
from concurrent.futures import ThreadPoolExecutor, as_completed
import json
from pathlib import Path
import subprocess


def main():
    p = argparse.ArgumentParser(description=__doc__)
    for name in ('audit-root', 'output', 'ferrum', 'ceta'):
        p.add_argument('--' + name, type=Path, required=True)
    p.add_argument('--jobs', type=int, default=16)
    args = p.parse_args()
    args.output.mkdir(parents=True, exist_ok=False)
    rows = [json.loads(line) for line in (args.audit_root / 'results.jsonl').open()]
    tasks = [(row, variant) for row in rows for variant in row['results']
             if variant.get('returncode') or
             (variant.get('typed_outcome') == 'Solved' and not variant['certified'])]

    def run(task):
        row, variant = task
        index, name = row['index'], variant['variant']
        source = args.audit_root / str(index)
        output = args.output / f'{index}-{name}'
        output.mkdir()
        result = dict(index=index, variant=name, family=row['family'])
        try:
            with (output / 'stdout').open('x') as stdout, (output / 'stderr').open('x') as stderr:
                proc = subprocess.run([str(args.ferrum), 'probe-cpf', str(source / f'{name}.input.cpf'),
                    '--strategy-file', str(source / f'{name}.atom.fs'), '--timeout-ms', '60000',
                    '--cpf', str(output / 'proof.cpf')], stdout=stdout, stderr=stderr, timeout=65)
            checks = []
            data = json.loads((output / 'stdout').read_text()) if proc.returncode == 0 else {}
            if data.get('outcome') == 'solved' and (output / 'proof.cpf').exists():
                for repeat in range(2):
                    check = subprocess.run([str(args.ceta), str(output / 'proof.cpf')],
                                           capture_output=True, text=True, timeout=60)
                    (output / f'ceta-{repeat}.log').write_text(check.stdout + check.stderr)
                    checks.append(check.returncode == 0 and 'CERTIFIED' in check.stdout.splitlines())
            return dict(result, returncode=proc.returncode, checks=checks, certified=checks == [True, True],
                        outcome=data.get('outcome'), children=len(data.get('children', [])))
        except (subprocess.TimeoutExpired, json.JSONDecodeError) as error:
            return dict(result, error=type(error).__name__)

    with ThreadPoolExecutor(max_workers=args.jobs) as pool, (args.output / 'results.jsonl').open('x') as log:
        for future in as_completed([pool.submit(run, task) for task in tasks]):
            print(json.dumps(future.result()), file=log, flush=True)


if __name__ == '__main__':
    main()
