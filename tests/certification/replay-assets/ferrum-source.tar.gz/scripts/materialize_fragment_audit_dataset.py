#!/usr/bin/env python3
"""Materialize an improved canonical dataset with fragment-audit artefacts.

Each output row is the original canonical training row plus a ``fragment_audit``
object.  When possible, ``fragment_audit.cpf3_certificate`` contains a
standalone CPF3 certificate for checking the row as a proof fragment with
CeTA's verified ``--allow-assumptions`` mode.
"""

from __future__ import annotations

import argparse
import gzip
import json
import re
import xml.etree.ElementTree as ET
from copy import deepcopy
from pathlib import Path
from typing import Any

from audit_canonical_fragments import (
    DP_PROOF_STEP_TAGS,
    TRS_PROOF_STEP_TAGS,
    local_name,
    make_cpf3_certificate,
    normalize_cpf2_terms,
    parse_normalized_fragment,
    replace_proof_hole,
    result_answer,
    sha256_text,
    wrap_top_level_proof,
)


def open_input(path: Path):
    return gzip.open(path, "rt", encoding="utf-8") if path.suffix == ".gz" else path.open("r", encoding="utf-8")


def open_output(path: Path):
    path.parent.mkdir(parents=True, exist_ok=True)
    return gzip.open(path, "wt", encoding="utf-8") if path.suffix == ".gz" else path.open("w", encoding="utf-8")


def first_child(elem: ET.Element, name: str) -> ET.Element | None:
    for child in list(elem):
        if local_name(child.tag) == name:
            return child
    return None


def child_rules_from_input(input_elem: ET.Element) -> tuple[ET.Element | None, ET.Element | None, ET.Element | None]:
    trs_input = first_child(input_elem, "trsInput")
    if trs_input is None:
        return None, None, None
    trs = first_child(trs_input, "trs")
    strategy = first_child(trs_input, "strategy")
    relative = first_child(trs_input, "relativeRules")
    return trs, strategy, relative


def trs_input_from_input(input_elem: ET.Element) -> ET.Element | None:
    return first_child(input_elem, "trsInput")


def inner_problem_input(input_elem: ET.Element) -> ET.Element | None:
    name = local_name(input_elem.tag)
    if name in {"trsInput", "dpInput"}:
        return input_elem
    if name == "input":
        trs_input = first_child(input_elem, "trsInput")
        if trs_input is not None:
            return trs_input
        return first_child(input_elem, "dpInput")
    return None


def dp_input_from_trs_and_dps(input_elem: ET.Element, dps_elem: ET.Element) -> ET.Element | None:
    trs, strategy, _relative = child_rules_from_input(input_elem)
    if trs is None:
        return None
    dp_input = ET.Element("input")
    inner = ET.SubElement(dp_input, "dpInput")
    inner.append(deepcopy(trs))
    inner.append(deepcopy(dps_elem))
    if strategy is not None:
        inner.append(deepcopy(strategy))
    minimal = ET.SubElement(inner, "minimal")
    minimal.text = "true"
    return dp_input


def dp_input_from_parts(trs_elem: ET.Element, dps_elem: ET.Element, strategy_elem: ET.Element | None = None) -> ET.Element:
    inner = ET.Element("dpInput")
    trs_copy = deepcopy(trs_elem)
    if local_name(trs_copy.tag) == "usableRules":
        trs_copy.tag = "trs"
    inner.append(trs_copy)
    inner.append(deepcopy(dps_elem))
    if strategy_elem is not None:
        inner.append(deepcopy(strategy_elem))
    minimal = ET.SubElement(inner, "minimal")
    minimal.text = "true"
    return inner


def trs_input_like(input_elem: ET.Element, trs_elem: ET.Element) -> ET.Element | None:
    current = inner_problem_input(input_elem)
    if current is None or local_name(current.tag) != "trsInput":
        return None
    inner = ET.Element("trsInput")
    inner.append(deepcopy(trs_elem))
    strategy = first_child(current, "strategy")
    relative = first_child(current, "relativeRules")
    if strategy is not None:
        strategy_copy = deepcopy(strategy)
        context_sensitive = first_child(strategy_copy, "contextSensitive")
        if context_sensitive is not None:
            # A CSR rule-removal residual has a smaller signature.  Ferrum
            # reconstructs its CsrTrs and therefore emits replacement-map
            # entries only for symbols still occurring in the residual TRS.
            # Keeping entries from the parent signature makes the extracted
            # state unparsable and, consequently, impossible to match at
            # runtime.
            residual_symbols = {
                (node.text or "").strip()
                for node in trs_elem.iter()
                if local_name(node.tag) == "name" and (node.text or "").strip()
            }
            for entry in list(context_sensitive):
                if local_name(entry.tag) != "replacementMapEntry":
                    continue
                name = next(
                    (
                        (node.text or "").strip()
                        for node in entry.iter()
                        if local_name(node.tag) == "name"
                        and (node.text or "").strip()
                    ),
                    None,
                )
                if name not in residual_symbols:
                    context_sensitive.remove(entry)
        inner.append(strategy_copy)
    if relative is not None:
        inner.append(deepcopy(relative))
    return inner


def dp_input_like(input_elem: ET.Element, dps_elem: ET.Element | None = None, trs_elem: ET.Element | None = None) -> ET.Element | None:
    current = inner_problem_input(input_elem)
    if current is None:
        return None
    if local_name(current.tag) == "dpInput":
        trs = trs_elem if trs_elem is not None else first_child(current, "trs")
        dps = dps_elem if dps_elem is not None else first_child(current, "dps")
        strategy = first_child(current, "strategy")
        if trs is None or dps is None:
            return None
        result = dp_input_from_parts(trs, dps, strategy)
        usable_rules = first_child(current, "usableRules")
        if usable_rules is not None:
            minimal = first_child(result, "minimal")
            insertion_index = (
                list(result).index(minimal) if minimal is not None else len(result)
            )
            result.insert(insertion_index, deepcopy(usable_rules))
        weak_dps = first_child(current, "ferrumWeakDps")
        if weak_dps is not None:
            minimal = first_child(result, "minimal")
            insertion_index = (
                list(result).index(minimal) if minimal is not None else len(result)
            )
            result.insert(insertion_index, deepcopy(weak_dps))
        current_minimal = first_child(current, "minimal")
        result_minimal = first_child(result, "minimal")
        if current_minimal is not None and result_minimal is not None:
            result.remove(result_minimal)
            result.append(deepcopy(current_minimal))
        context = first_child(current, "ferrumCsrDpContext")
        if context is not None:
            result.append(deepcopy(context))
        runtime_context = first_child(current, "ferrumDpStateContext")
        if runtime_context is not None:
            result.append(deepcopy(runtime_context))
        return result
    if local_name(current.tag) == "trsInput":
        trs = trs_elem or first_child(current, "trs")
        strategy = first_child(current, "strategy")
        if trs is None or dps_elem is None:
            return None
        return dp_input_from_parts(trs, dps_elem, strategy)
    return None


def rule_key(rule: ET.Element) -> bytes:
    serialized = ET.tostring(rule, encoding="unicode", short_empty_elements=True)
    serialized = re.sub(r">\s+<", "><", serialized.strip())
    serialized = re.sub(r"\s+/>", "/>", serialized)
    return serialized.encode("utf-8")


def subtract_rules_element(current: ET.Element, removed_elem: ET.Element, result_tag: str) -> ET.Element:
    removed = {rule_key(rule) for rules in list(removed_elem) if local_name(rules.tag) == "rules" for rule in list(rules) if local_name(rule.tag) == "rule"}
    result = ET.Element(result_tag)
    rules_out = ET.SubElement(result, "rules")
    for rules in list(current):
        if local_name(rules.tag) != "rules":
            continue
        for rule in list(rules):
            if local_name(rule.tag) == "rule" and rule_key(rule) not in removed:
                rules_out.append(deepcopy(rule))
    return result


def subtract_dps(current_dps: ET.Element, removed_dps: ET.Element) -> ET.Element:
    return subtract_rules_element(current_dps, removed_dps, "dps")


def subtract_trs(current_trs: ET.Element, removed_trs: ET.Element) -> ET.Element:
    return subtract_rules_element(current_trs, removed_trs, "trs")


def rules_container_empty(container: ET.Element) -> bool:
    rules = first_child(container, "rules")
    if rules is None:
        return True
    return not any(local_name(rule.tag) in {"rule", "ruleIndex"} for rule in list(rules))


def reverse_unary_term(term: ET.Element) -> ET.Element:
    chain: list[ET.Element] = []
    cursor = term
    while local_name(cursor.tag) == "funapp":
        children = list(cursor)
        term_children = [child for child in children if local_name(child.tag) != "name"]
        if len(term_children) != 1:
            return deepcopy(term)
        name = first_child(cursor, "name")
        if name is None:
            return deepcopy(term)
        chain.append(deepcopy(name))
        cursor = term_children[0]
    result = deepcopy(cursor)
    for name in chain:
        fun = ET.Element("funapp")
        fun.append(name)
        fun.append(result)
        result = fun
    return result


def reverse_rules_container(container: ET.Element, result_tag: str) -> ET.Element:
    result = ET.Element(result_tag)
    rules_out = ET.SubElement(result, "rules")
    rules = first_child(container, "rules")
    if rules is None:
        return result
    for rule in list(rules):
        if local_name(rule.tag) != "rule" or len(rule) < 2:
            continue
        out_rule = ET.SubElement(rules_out, "rule")
        out_rule.append(reverse_unary_term(rule[0]))
        out_rule.append(reverse_unary_term(rule[1]))
    return result


def reversed_string_trs_input(input_elem: ET.Element) -> ET.Element | None:
    current = inner_problem_input(input_elem)
    if current is None or local_name(current.tag) != "trsInput":
        return None
    trs = first_child(current, "trs")
    if trs is None:
        return None
    inner = ET.Element("trsInput")
    inner.append(reverse_rules_container(trs, "trs"))
    strategy = first_child(current, "strategy")
    relative = first_child(current, "relativeRules")
    if strategy is not None:
        inner.append(deepcopy(strategy))
    if relative is not None:
        inner.append(reverse_rules_container(relative, "relativeRules"))
    return inner


def assumption_input_for_problem(input_elem: ET.Element, proof_kind: str) -> ET.Element | None:
    if proof_kind == "trsTerminationProof":
        trs_input = trs_input_from_input(input_elem)
        return deepcopy(trs_input) if trs_input is not None else None
    if proof_kind == "dpProof":
        inner = first_child(input_elem, "dpInput")
        return deepcopy(inner) if inner is not None else None
    return None


def make_trs_assumption(input_elem: ET.Element) -> ET.Element | None:
    assm_input = assumption_input_for_problem(input_elem, "trsTerminationProof")
    if assm_input is None:
        return None
    proof = ET.Element("trsTerminationProof")
    assm = ET.SubElement(proof, "terminationAssumption")
    assm.append(assm_input)
    return proof


def make_dp_assumption(input_elem: ET.Element) -> ET.Element | None:
    assm_input = assumption_input_for_problem(input_elem, "dpProof")
    if assm_input is None:
        return None
    proof = ET.Element("dpProof")
    assm = ET.SubElement(proof, "finitenessAssumption")
    assm.append(assm_input)
    return proof


def make_trs_assumption_for_input(assm_input: ET.Element | None) -> ET.Element | None:
    if assm_input is None:
        return None
    proof = ET.Element("trsTerminationProof")
    assm = ET.SubElement(proof, "terminationAssumption")
    assm.append(assm_input)
    return proof


def make_dp_assumption_for_input(assm_input: ET.Element | None) -> ET.Element | None:
    if assm_input is None:
        return None
    proof = ET.Element("dpProof")
    assm = ET.SubElement(proof, "finitenessAssumption")
    assm.append(assm_input)
    return proof


def exact_child_assumption(parent: ET.Element, child: ET.Element, input_elem: ET.Element) -> tuple[ET.Element | None, str | None]:
    parent_name = local_name(parent.tag)
    child_name = local_name(child.tag)
    if child_name == "trsTerminationProof" and parent_name == "ruleRemoval":
        payload = first_child(parent, "trs")
        if payload is None:
            return None, "cannot_find_rule_removal_residual_trs"
        residual = payload
        child_step = next(iter(list(child)), None)
        if child_step is not None and local_name(child_step.tag) == "rIsEmpty" and not rules_container_empty(payload):
            current = inner_problem_input(input_elem)
            current_trs = first_child(current, "trs") if current is not None else None
            if current_trs is None:
                return None, "cannot_find_rule_removal_current_trs"
            residual = subtract_trs(current_trs, payload)
        return make_trs_assumption_for_input(trs_input_like(input_elem, residual)), None
    if child_name == "trsTerminationProof" and parent_name == "stringReversal":
        return make_trs_assumption_for_input(reversed_string_trs_input(input_elem)), None
    if child_name == "dpProof" and parent_name == "dpTrans":
        dps = first_child(parent, "dps")
        if dps is None:
            return None, "cannot_find_dp_trans_dps"
        return make_dp_assumption_for_input(dp_input_like(input_elem, dps_elem=dps)), None
    if child_name == "dpProof" and parent_name == "component":
        dps = first_child(parent, "dps")
        if dps is None:
            return None, "cannot_find_component_dps"
        return make_dp_assumption_for_input(dp_input_like(input_elem, dps_elem=dps)), None
    if child_name == "dpProof" and parent_name == "usableRulesProc":
        usable = first_child(parent, "usableRules")
        current = inner_problem_input(input_elem)
        current_dps = first_child(current, "dps") if current is not None else None
        if usable is None or current_dps is None:
            return None, "cannot_build_usable_rules_child_input"
        return make_dp_assumption_for_input(dp_input_like(input_elem, dps_elem=current_dps, trs_elem=usable)), None
    if child_name == "dpProof" and parent_name in {"redPairProc", "subtermProc"}:
        removed = first_child(parent, "dps")
        current = inner_problem_input(input_elem)
        current_dps = first_child(current, "dps") if current is not None else None
        if removed is None or current_dps is None:
            return None, "cannot_build_red_pair_child_input"
        return make_dp_assumption_for_input(dp_input_like(input_elem, dps_elem=subtract_dps(current_dps, removed))), None
    if child_name == "dpProof" and parent_name == "redPairUrProc":
        removed = first_child(parent, "dps")
        usable = first_child(parent, "usableRules")
        current = inner_problem_input(input_elem)
        current_dps = first_child(current, "dps") if current is not None else None
        if removed is None or usable is None or current_dps is None:
            return None, "cannot_build_red_pair_ur_child_input"
        return make_dp_assumption_for_input(dp_input_like(input_elem, dps_elem=subtract_dps(current_dps, removed), trs_elem=usable)), None
    if child_name == "dpProof" and parent_name in {"monoRedPairProc", "monoRedPairUrProc"}:
        removed = first_child(parent, "dps")
        child_trs = first_child(parent, "usableRules")
        if child_trs is None:
            child_trs = first_child(parent, "trs")
        current = inner_problem_input(input_elem)
        current_dps = first_child(current, "dps") if current is not None else None
        if removed is None or child_trs is None or current_dps is None:
            return None, "cannot_build_mono_red_pair_child_input"
        return make_dp_assumption_for_input(dp_input_like(input_elem, dps_elem=subtract_dps(current_dps, removed), trs_elem=child_trs)), None
    if child_name == "trsTerminationProof":
        return make_trs_assumption(input_elem), None
    if child_name == "dpProof":
        return make_dp_assumption(input_elem), None
    return None, f"unsupported_child_proof:{child_name}"


def replace_child_proofs_with_assumptions(proof_elem: ET.Element, input_elem: ET.Element) -> tuple[ET.Element, int, str | None]:
    """Replace recursive termination subproofs by assumptions.

    The assumption carries the current fragment input.  CeTA's assumption checker
    requires that this input subsumes the child problem computed by the parent
    processor; if it does not, the generated certificate fails.
    """
    replaced = 0
    root = deepcopy(proof_elem)

    def visit(parent: ET.Element, is_root: bool = False) -> str | None:
        nonlocal replaced
        for child in list(parent):
            name = local_name(child.tag)
            if not is_root and name == "trsTerminationProof":
                assm, reason = exact_child_assumption(parent, child, input_elem)
                if reason:
                    return reason
                if assm is None:
                    return "cannot_build_trs_assumption"
                idx = list(parent).index(child)
                parent.remove(child)
                parent.insert(idx, assm)
                replaced += 1
                continue
            if not is_root and name == "dpProof":
                assm, reason = exact_child_assumption(parent, child, input_elem)
                if reason:
                    return reason
                if assm is None:
                    return "cannot_build_dp_assumption"
                idx = list(parent).index(child)
                parent.remove(child)
                parent.insert(idx, assm)
                replaced += 1
                continue
            reason = visit(child, False)
            if reason:
                return reason
        return None

    reason = visit(root, True)
    return root, replaced, reason


def certificate_from_parts(input_elem: ET.Element, proof_elem: ET.Element, answer: str, lookup_tables: ET.Element | None = None) -> str:
    root = ET.Element("certificationProblem")
    ET.SubElement(root, "cpfVersion").text = "3.0"
    root.append(deepcopy(lookup_tables) if lookup_tables is not None else ET.Element("lookupTables"))
    root.append(input_elem)
    prop = ET.SubElement(root, "property")
    ET.SubElement(prop, "termination")
    ans = ET.SubElement(root, "answer")
    ET.SubElement(ans, answer)
    root.append(proof_elem)
    meta = ET.SubElement(root, "metaInformation")
    ET.SubElement(meta, "toolInfos")
    return ET.tostring(root, encoding="utf-8", xml_declaration=True, short_empty_elements=True).decode()


def make_fragment_certificate(row: dict[str, Any]) -> tuple[str | None, dict[str, Any]]:
    metadata = row.get("metadata") or {}
    answer = result_answer(str(metadata.get("result") or ""))
    if answer is None:
        return None, {"status": "unsupported", "reason": "no_yes_no_answer"}
    if (row.get("cpf_normalization") or {}).get("output_status") != "cpf-output-preserved":
        return None, {"status": "unsupported", "reason": f"non_cpf_output:{(row.get('cpf_normalization') or {}).get('output_status')}"}
    input_obj = row.get("input") or {}
    try:
        input_elem = parse_normalized_fragment(input_obj.get("problem_xml") or "")
        lookup_tables = None
        if input_obj.get("lookup_tables_xml"):
            lookup_tables = parse_normalized_fragment(input_obj.get("lookup_tables_xml") or "")
        context = replace_proof_hole(input_obj.get("local_context_xml") or "", row.get("output_xml") or "")
        context_elem = parse_normalized_fragment(context)
        allowed_roots = {
            "proof",
            "trsTerminationProof",
            "trsNonterminationProof",
            "relativeTerminationProof",
            "relativeNonterminationProof",
            "dpProof",
            "dpNonterminationProof",
            *TRS_PROOF_STEP_TAGS,
            *DP_PROOF_STEP_TAGS,
        }
        if local_name(context_elem.tag) not in allowed_roots:
            return None, {"status": "unsupported", "reason": f"context_not_proof_obligation:{local_name(context_elem.tag)}"}
        proof_elem = wrap_top_level_proof(context_elem, answer)
    except Exception as exc:
        return None, {"status": "unsupported", "reason": f"xml_parse:{type(exc).__name__}"}

    if local_name(input_elem.tag) != "input":
        return None, {"status": "unsupported", "reason": "problem_not_input"}
    truncated, assumptions, reason = replace_child_proofs_with_assumptions(proof_elem, input_elem)
    if reason:
        return None, {"status": "unsupported", "reason": reason}
    xml = certificate_from_parts(input_elem, truncated, answer, lookup_tables)
    return xml, {"status": "materialized", "assumptions_inserted": assumptions}


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--input", type=Path, default=Path("target/termcomp-proof-corpus/training/subproofs.cpf.canonical.final.jsonl.gz"))
    parser.add_argument("--output", type=Path, default=Path("target/termcomp-proof-corpus/training/subproofs.cpf.canonical.fragment-audit.jsonl.gz"))
    parser.add_argument("--summary", type=Path, default=Path("target/termcomp-proof-corpus/training/subproofs.cpf.canonical.fragment-audit.summary.json"))
    parser.add_argument("--limit", type=int)
    parser.add_argument("--progress-interval", type=int, default=50000)
    args = parser.parse_args()

    counts: dict[str, int] = {}
    reasons: dict[str, int] = {}
    rows = 0
    with open_input(args.input) as source, open_output(args.output) as sink:
        for line in source:
            rows += 1
            row = json.loads(line)
            xml, audit = make_fragment_certificate(row)
            if xml is not None:
                audit["cpf3_certificate"] = xml
                audit["cpf3_sha256"] = sha256_text(xml)
            status = str(audit.get("status"))
            counts[status] = counts.get(status, 0) + 1
            if audit.get("reason"):
                reason = str(audit["reason"])
                reasons[reason] = reasons.get(reason, 0) + 1
            row["fragment_audit"] = audit
            sink.write(json.dumps(row, sort_keys=True, separators=(",", ":")) + "\n")
            if args.progress_interval > 0 and rows % args.progress_interval == 0:
                print(json.dumps({"event": "progress", "rows": rows, "counts": counts}, sort_keys=True), flush=True)
            if args.limit is not None and rows >= args.limit:
                break

    summary = {
        "input": str(args.input),
        "output": str(args.output),
        "rows": rows,
        "counts": dict(sorted(counts.items())),
        "reason_counts": dict(sorted(reasons.items())),
    }
    args.summary.parent.mkdir(parents=True, exist_ok=True)
    args.summary.write_text(json.dumps(summary, indent=2, sort_keys=True), encoding="utf-8")
    print(json.dumps(summary, sort_keys=True), flush=True)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
