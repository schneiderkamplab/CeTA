#!/usr/bin/env python3

import json
from pathlib import Path
import tempfile
import unittest

from build_credited_status_map_dataset import normalized_event_candidate
from freeze_live_manual_processor_evidence import load_trials, retained_outcome


class FreezeLiveManualProcessorEvidenceTest(unittest.TestCase):
    def test_top_level_transformation_does_not_outrank_terminal_root(self) -> None:
        self.assertEqual(
            retained_outcome("switch-innermost", "solved"),
            "transformed",
        )
        self.assertEqual(retained_outcome("uncurry", "solved"), "transformed")
        self.assertEqual(retained_outcome("dp", "solved"), "solved")

    def test_quadratic_debug_processor_normalizes_to_executable_atom(self) -> None:
        self.assertEqual(
            normalized_event_candidate(
                {
                    "strategy_atom": (
                        "QuadraticPolynomial { max_constant: 2, "
                        "max_coefficient: 1, max_symbols: None, max_arity: None }"
                    )
                }
            ),
            "quadratic-poly(max-constant=2,max-coefficient=1)",
        )

    def test_hydrates_content_addressed_positive_state(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            events = root / "events.jsonl"
            cpf = "<dpInput><trs/><dps/><minimal>true</minimal></dpInput>"
            events.write_text(
                "\n".join(
                    [
                        json.dumps(
                            {
                                "outcome": "failed",
                                "input": {"problem_key": "k", "cpf": cpf},
                            }
                        ),
                        json.dumps(
                            {
                                "outcome": "solved",
                                "strategy_atom": "DependencyGraph",
                                "input": {"problem_key": "k", "cpf": None},
                                "problem_id": "x",
                            }
                        ),
                    ]
                )
                + "\n",
                encoding="utf-8",
            )
            summary = root / "summary.jsonl"
            summary.write_text(
                json.dumps(
                    {
                        "certified": True,
                        "event_path": str(events),
                        "problem_id": "x",
                        "category": "TRS_Standard",
                    }
                )
                + "\n",
                encoding="utf-8",
            )

            trials, counts = load_trials(summary)

            self.assertEqual(counts["trials"], 1)
            self.assertEqual(trials[0].cpf, cpf)
            self.assertEqual(trials[0].candidate, "graph")

    def test_accepts_termcomp_details_json_and_infers_event_path(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            artifact = root / "artifact"
            artifact.mkdir()
            cpf = "<trsInput><trs/></trsInput>"
            (artifact / "progress.jsonl").write_text(
                json.dumps(
                    {
                        "outcome": "solved",
                        "strategy_atom": "SizeChange",
                        "input": {"problem_key": "current", "cpf": cpf},
                    }
                )
                + "\n",
                encoding="utf-8",
            )
            details = root / "details.json"
            details.write_text(
                json.dumps(
                    [
                        {
                            "certified": True,
                            "artifact_dir": str(artifact),
                            "path": "../TPDB-ARI/TRS_Innermost/example.ari",
                            "category": "TRS_Innermost",
                        }
                    ]
                ),
                encoding="utf-8",
            )

            trials, counts = load_trials(details)

            self.assertEqual(counts["trials"], 1)
            self.assertEqual(trials[0].problem_key, "current")
            self.assertEqual(trials[0].candidate, "size-change")
            self.assertEqual(
                trials[0].problem_id,
                "../TPDB-ARI/TRS_Innermost/example.ari",
            )


if __name__ == "__main__":
    unittest.main()
