import unittest
from repair_native_replay_aliases import linked_row


class NativeAliasTests(unittest.TestCase):
    def records(self):
        return {'raw': dict(problem_key='raw', replay_order=['order'], possible=[
                    dict(candidate='poly(max-coefficient=1)', status='transformed_weak', certified_count=0)]),
                'canonical': dict(problem_key='canonical', possible=[
                    dict(candidate='poly(max-coefficient=2)', status='transformed_weak')])}

    def test_preserves_candidates_and_credit_and_does_not_mutate_source(self):
        records = self.records()
        row = linked_row(records, 'raw', 'canonical')
        self.assertEqual(row['canonical_problem_key'], 'canonical')
        self.assertEqual(row['possible'], records['raw']['possible'])
        self.assertEqual(row['replay_order'], ['order'])
        self.assertNotIn('canonical_problem_key', records['raw'])

    def test_rejects_witness_transport_and_cycles(self):
        records = self.records()
        records['canonical']['possible'][0]['candidate'] = 'exact-poly(hex=00)'
        with self.assertRaises(ValueError):
            linked_row(records, 'raw', 'canonical')
        records = self.records()
        records['canonical']['canonical_problem_key'] = 'raw'
        with self.assertRaises(ValueError):
            linked_row(records, 'raw', 'canonical')

    def test_does_not_invent_missing_targets_or_self_aliases(self):
        self.assertIsNone(linked_row(self.records(), 'raw', 'missing'))
        self.assertIsNone(linked_row(self.records(), 'raw', 'raw'))
