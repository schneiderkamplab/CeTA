#!/usr/bin/env python3
"""Retain state-local search hints from twice-rechecked complete root replays.

Root certification does not independently certify every explored action. All
imported actions therefore remain weak; replay_order only schedules them.
"""
import argparse
import hashlib
import json
from pathlib import Path
import subprocess
from concurrent.futures import ThreadPoolExecutor


def direct_forward_atom(atom):
    if not atom.startswith('exact-dp-transform(hex='):
        return atom
    payload = json.loads(bytes.fromhex(atom.split('hex=')[1][:-1]))
    if payload[0] != 'forwardInstantiationProc':
        return atom
    payload[0] = 'forwardInstantiationProcDirect'
    return 'exact-dp-transform(hex=' + json.dumps(payload, separators=(',', ':')).encode().hex() + ')'


def local_hints(events):
    events = list(events)
    inputs = {}
    for event in events:
        for source in [event.get('input', {}), *event.get('witness', {}).get('residuals', [])]:
            cpf, key = source.get('cpf'), source.get('problem_key')
            if cpf and key:
                if hashlib.sha256(cpf.strip().encode()).hexdigest() != key:
                    raise ValueError('event input digest mismatch')
                inputs[key] = cpf
    states, witnesses = {}, {}
    for event in events:
        if event.get('outcome') not in ('transformed', 'solved'):
            continue
        atom = event.get('strategy_atom', '')
        if atom.startswith(('exact-dp-proof(', 'exact-trs-proof(')):
            raise ValueError('complete termination proof is not a local hint')
        source = event.get('input', {})
        key = source.get('problem_key')
        cpf = source.get('cpf') or inputs.get(key)
        if not atom or not cpf or not key:
            continue
        if hashlib.sha256(cpf.strip().encode()).hexdigest() != key:
            raise ValueError('event input digest mismatch')
        digest = hashlib.sha256(atom.encode()).hexdigest()
        if atom.startswith('exact-'):
            witnesses[digest] = atom
            candidate = dict(candidate_ref=digest)
        else:
            candidate = dict(candidate=atom)
        row = states.setdefault(key, dict(schema='ferrum.utility-guidance.v2', problem_key=key, prefer=[], possible=[],
                                          avoid=[], timeout=[], replay_order=[]))
        if digest in row['replay_order']:
            continue
        row['replay_order'].append(digest)
        row['possible'].append(dict(**candidate, status='transformed_weak',
            utility_score=100, attempts=1, certified_count=0, solved_count=0,
            transformed_count=1, failed_count=0, timeout_count=0,
            best_elapsed_ms=event.get('elapsed_ms', 0)))
    return [dict(schema='ferrum.utility-guidance.witness.v1', witness_id=k,
                 candidate=v) for k, v in witnesses.items()] + list(states.values())


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--details', type=Path, required=True)
    parser.add_argument('--file-list', type=Path, required=True)
    parser.add_argument('--ceta', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--audit', type=Path, required=True)
    parser.add_argument('--extra-events', type=Path, action='append', default=[],
                        help='Native local probes, restricted to observed source action vocabulary.')
    parser.add_argument('--ferrum', help='Also export complete-context canonical portable hints.')
    parser.add_argument('--direct-forward', action='store_true',
                        help='Propose deterministic exact forward reconstruction; remains weak guidance.')
    args = parser.parse_args()
    selected = set(args.file_list.read_text().splitlines())
    rows = [r for r in json.loads(args.details.read_text()) if r['path'] in selected]
    if {r['path'] for r in rows} != selected:
        raise ValueError('selected root missing from details')
    all_events, audit = [], []
    for row in rows:
        if not row.get('certified'):
            raise ValueError('uncertified source root')
        root = Path(row['artifact_dir'])
        proof, events = root/'proof.cpf.xml', root/'processor-events.jsonl'
        proof_hash = hashlib.sha256(proof.read_bytes()).hexdigest()
        event_data = events.read_bytes()
        checks = []
        for _ in range(2):
            result = subprocess.run([str(args.ceta), str(proof)], text=True,
                                    capture_output=True, timeout=120)
            if result.returncode or 'CERTIFIED' not in result.stdout.splitlines():
                raise ValueError(f'source proof rejected: {proof}: {result.stderr[-1000:]}')
            checks.append(dict(returncode=result.returncode, stdout=result.stdout))
        if hashlib.sha256(proof.read_bytes()).hexdigest() != proof_hash:
            raise ValueError('source proof changed during checks')
        all_events.extend(map(json.loads, event_data.splitlines()))
        audit.append(dict(path=row['path'], proof=str(proof), sha256=proof_hash,
            events_sha256=hashlib.sha256(event_data).hexdigest(), checks=checks))
    allowed = {e.get('strategy_atom') for e in all_events
               if e.get('outcome') in ('transformed', 'solved')}
    for path in args.extra_events:
        extra = list(map(json.loads, path.read_text().splitlines()))
        # These are search hints only. Unrecognized processor atoms cannot
        # enter through this source-gated retention path.
        all_events.extend(e for e in extra if e.get('strategy_atom') in allowed)
        audit.append(dict(extra_events=str(path),
                          sha256=hashlib.sha256(path.read_bytes()).hexdigest()))
    if args.ferrum:
        from build_credited_status_map_dataset import canonicalize_with_ferrum
        from export_direct_native_hints import canonical_candidate
        inputs = {}
        for event in all_events:
            for source in [event.get('input', {}), *event.get('witness', {}).get('residuals', [])]:
                if source.get('cpf') and source.get('problem_key'):
                    inputs[source['problem_key']] = source['cpf']
        selected_events = [e for e in all_events if e.get('outcome') in ('transformed', 'solved')
                           and canonical_candidate(e.get('strategy_atom', ''))
                           and e.get('input', {}).get('problem_key') in inputs]
        keys = {e['input']['problem_key'] for e in selected_events}
        def canonicalize(key):
            try:
                return key, canonicalize_with_ferrum(inputs[key], args.ferrum, 60)
            except Exception as error:
                return key, None
        with ThreadPoolExecutor(max_workers=4) as pool:
            canonical = dict(pool.map(canonicalize, sorted(keys)))
        for event in selected_events:
            cpf = canonical[event['input']['problem_key']]
            if cpf:
                all_events.append(dict(event, strategy_atom=canonical_candidate(event['strategy_atom']),
                    input=dict(cpf=cpf, problem_key=hashlib.sha256(cpf.strip().encode()).hexdigest())))
        audit.append(dict(canonical_states=len(keys),
                          canonicalization_failures=sum(v is None for v in canonical.values())))
    if args.direct_forward:
        all_events = [dict(e, strategy_atom=direct_forward_atom(e.get('strategy_atom', '')))
                      for e in all_events]
    output = local_hints(all_events)
    with args.output.open('x') as stream:
        for row in output:
            print(json.dumps(row, separators=(',', ':')), file=stream)
    with args.audit.open('x') as stream:
        json.dump(audit, stream, indent=2)
    print(json.dumps(dict(roots=len(rows), records=len(output))))


if __name__ == '__main__':
    main()
