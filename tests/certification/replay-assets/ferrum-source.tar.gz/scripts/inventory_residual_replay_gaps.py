"""Join residual replay outcomes to their recorded parent actions and roots."""
import argparse
from collections import Counter, defaultdict
import json
from pathlib import Path


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--audit", type=Path, required=True)
    parser.add_argument("--actions", type=Path, required=True)
    parser.add_argument("--replay", type=Path, required=True)
    parser.add_argument("--checks", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    actions = {r["index"]: r for r in map(json.loads, args.actions.read_text().splitlines())}
    origins = defaultdict(list)
    for row in map(json.loads, (args.audit / "strict-equivalence.jsonl").read_text().splitlines()):
        for child in row.get("observations", []):
            origins[child["sha256"]].append(dict(index=row["index"], family=row["family"],
                variant=child["variant"], child=child["child"],
                source_events=actions[row["index"]]["source_events"]))
    checked = {r["input"]: r for r in map(json.loads, args.checks.read_text().splitlines())}
    records = []
    for row in map(json.loads, args.replay.read_text().splitlines()):
        if row["input"] in checked:
            gap = "certified" if checked[row["input"]]["certified"] else "checker-rejected"
        elif "proof" in row:
            gap = "awaiting-check"
        elif "error" in row:
            gap = "standalone-export" if "CPF output" in row["error"] else "harness-error"
        elif row.get("worklist_failure") == "Inapplicable":
            gap = "no-applicable-guidance"
        elif row.get("worklist_failure") == "TimedOut":
            gap = "local-timeout"
        else:
            gap = "witness-or-reconstruction-rejection"
        records.append(dict(row, gap=gap, origins=origins[row["sha256"]]))
    result = dict(scope="Sample includes unused alternative actions; gaps are not certified-root losses.",
        counts=dict(Counter(row["gap"] for row in records)), records=records)
    with args.output.open("x") as output:
        json.dump(result, output, indent=2)
    print(result["counts"])


if __name__ == "__main__":
    main()
