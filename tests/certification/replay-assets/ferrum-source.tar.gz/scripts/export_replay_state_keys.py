"""Collect typed state keys exercised by retained certified replays.

Useful for preserving established action priorities while extending a shared
oracle. This exports identities only, not certification credit or witnesses.
"""
import argparse
from concurrent.futures import ThreadPoolExecutor
import hashlib
import json
from pathlib import Path
import re
from add_runtime_canonical_aliases import canonicalize


def state_keys(events, cpfs=None):
    keys = set()
    for event in events:
        for state in [event.get('input') or {}, *((event.get('witness') or {}).get('residuals') or [])]:
            key = state.get('problem_key')
            if key is None:
                continue
            if not re.fullmatch('[0-9a-f]{64}', key):
                raise ValueError('invalid state key')
            if state.get('cpf') and hashlib.sha256(state['cpf'].strip().encode()).hexdigest() != key:
                raise ValueError('state digest mismatch')
            keys.add(key)
            if cpfs is not None and state.get('cpf'):
                cpfs[key] = state['cpf']
    return keys


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--details', type=Path, action='append', required=True)
    parser.add_argument('--path-suffix')
    parser.add_argument('--canonical-ferrum', type=Path)
    parser.add_argument('--jobs', type=int, default=8)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    keys, roots, cpfs = set(), 0, {}
    for details in args.details:
        for row in json.loads(details.read_text()):
            if not row.get('certified') or (args.path_suffix and not row['path'].endswith(args.path_suffix)):
                continue
            with (Path(row['artifact_dir']) / 'processor-events.jsonl').open() as events:
                keys.update(state_keys(map(json.loads, events), cpfs))
            roots += 1
    if not roots or not keys:
        raise ValueError('no certified replay states selected')
    if args.canonical_ferrum:
        def canonical_key(cpf):
            return hashlib.sha256(canonicalize(args.canonical_ferrum.resolve(), cpf, 60).encode()).hexdigest()
        with ThreadPoolExecutor(max_workers=args.jobs) as pool:
            keys.update(pool.map(canonical_key, cpfs.values()))
    with args.output.open('x') as output:
        for key in sorted(keys):
            print(key, file=output)
    print(json.dumps(dict(roots=roots, states=len(keys))))


if __name__ == '__main__':
    main()
