"""Optional LP candidate backend for Ferrum's SRS weight processor.
This supports only Ferrum's homogeneous linear-weight encoding, not general
SMT. Candidates are checked with exact arithmetic here and again in Rust.
"""
import sys,re,math,os,json,time
from fractions import Fraction
if extra_path := os.environ.get('FERRUM_LP_PYTHONPATH'):
 sys.path.insert(0, extra_path)
import highspy
import numpy as np
started=time.monotonic()
def diagnostic(event,details):
 path=os.getenv('FERRUM_PROGRESS_LOG')
 if path:
  with open(path,'a') as stream:stream.write(json.dumps({'kind':'srs-lp','event':event,'name':'highs','elapsed_ms':round(1000*(time.monotonic()-started)),'details':details})+'\n')
tokens=iter(re.findall(r'\(|\)|[^\s()]+',sys.stdin.read()))
def parse(t):
 if t!='(':return t
 result=[]
 for t in tokens:
  if t==')':return result
  result.append(parse(t))
 raise ValueError('unclosed expression')
forms=[parse(t) for t in tokens]
names=[x[1] for x in forms if x[0]=='declare-const' and x[2]=='Real'];ids={n:i for i,n in enumerate(names)}
assert names and len(names)==len(ids)
def expr(x):
 if isinstance(x,str):
  return ({ids[x]:1},0) if x in ids else ({},int(x))
 if x[0]=='*' and len(x)==3:
  factor=int(x[1]);a,c=expr(x[2]);return ({i:factor*v for i,v in a.items()},factor*c)
 if x[0] in ['+','-']:
  a={};c=0
  for j,item in enumerate(x[1:]):
   aa,cc=expr(item);sign=-1 if x[0]=='-' and (j>0 or len(x)==2) else 1
   for i,v in aa.items():a[i]=a.get(i,0)+sign*v
   c+=sign*cc
  return a,c
 raise ValueError('unsupported arithmetic')
constraints=[]
progress_rows=[]
def assertion(x,orientation=True):
 if x[0]=='and':
  for y in x[1:]:assertion(y,False)
  return
 assert x[0] in ['>=','>','<=','<']
 a,c=expr(['-',x[1],x[2]])
 sign=-1 if x[0] in ['<=','<'] else 1
 constraints.append(({i:sign*v for i,v in a.items()},sign*c,x[0] in ['>','<']))
 if orientation and c==0 and x[0]=='>=':progress_rows.append(a)
for x in forms:
 if x[0]=='assert':assertion(x[1])
h=highspy.Highs();h.setOptionValue('output_flag',False);h.setOptionValue('threads',1);h.setOptionValue('time_limit',45.0)
h.addVars(len(names),np.zeros(len(names)),np.full(len(names),highspy.kHighsInf))
objective=np.zeros(len(names))
for a,c,strict in constraints:
 ii=np.array(list(a),dtype=np.int32);vv=np.array([float(a[i]) for i in a],dtype=float)
 h.addRow(float(-c)+(1.0 if strict else 0.0),highspy.kHighsInf,len(a),ii,vv)
 if strict:
  for i,v in a.items():objective[i]-=float(v)
if '--all-strict' in sys.argv:objective=np.ones(len(names))
maximal='--maximize-removal' in sys.argv
if maximal:
 assert '--all-strict' not in sys.argv
 # Clipped progress rewards deleting many inequalities, rather than making
 # one inequality enormous. These are candidate-search objectives only.
 h.addVars(len(progress_rows),np.zeros(len(progress_rows)),np.ones(len(progress_rows)))
 for j,a in enumerate(progress_rows):
  ii=np.array(list(a)+[len(names)+j],dtype=np.int32)
  vv=np.array([float(a[i]) for i in a]+[-1.0],dtype=float)
  h.addRow(0.0,highspy.kHighsInf,len(ii),ii,vv)
 objective=np.zeros(len(names))
 h.changeColsCost(len(progress_rows),np.arange(len(names),len(names)+len(progress_rows),dtype=np.int32),-np.ones(len(progress_rows)))
h.changeColsCost(len(names),np.arange(len(names),dtype=np.int32),objective)
h.run()
if h.getModelStatus()!=highspy.HighsModelStatus.kOptimal:
 diagnostic('no-candidate',str(h.getModelStatus()))
 print('unknown');sys.exit(0)
values=list(h.getSolution().col_value[:len(names)])
if maximal and progress_rows:
 optimum=-h.getObjectiveValue()
 target=round(optimum) if abs(optimum-round(optimum))<1e-6 else max(0.0,optimum-1e-7)
 h.addRow(float(target),highspy.kHighsInf,len(progress_rows),np.arange(len(names),len(names)+len(progress_rows),dtype=np.int32),np.ones(len(progress_rows)))
 h.changeColsCost(len(progress_rows),np.arange(len(names),len(names)+len(progress_rows),dtype=np.int32),np.zeros(len(progress_rows)))
 h.changeColsCost(len(names),np.arange(len(names),dtype=np.int32),np.ones(len(names)))
 h.setOptionValue('time_limit',max(0.001,45.0-(time.monotonic()-started)))
 h.run()
 if h.getModelStatus()==highspy.HighsModelStatus.kOptimal:values=list(h.getSolution().col_value[:len(names)])
 diagnostic('progress-objective',f'clipped_progress={optimum} rows={len(progress_rows)}')
fractions=[Fraction(v).limit_denominator(65536) for v in values]
den=math.lcm(*(v.denominator for v in fractions))
ints=[int(v*den) for v in fractions];g=math.gcd(*ints) or 1
candidates=[[v//g for v in ints]]+[[round(v*s) for v in values] for s in [1,2,4,8,16,64,256,1024]]
for candidate in candidates:
 if all(sum(v*candidate[i] for i,v in a.items())+c > 0 if strict else sum(v*candidate[i] for i,v in a.items())+c >= 0 for a,c,strict in constraints):
  print('sat\n(model')
  for n,v in zip(names,candidate):print(f' (define-fun {n} () Real {v}.0)')
  diagnostic('exact-candidate',f'variables={len(names)} constraints={len(constraints)} max_weight={max(candidate)}')
  print(')');sys.exit(0)
diagnostic('candidate-rejected',f'variables={len(names)} constraints={len(constraints)} denominator_bits={den.bit_length()}')
print('unknown')
