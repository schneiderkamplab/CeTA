import unittest
from unittest.mock import patch

from report_witness_dependence import report


class ReportTests(unittest.TestCase):
    def row(self, status='yes', certified=True):
        return dict(category='CSR', path='arbitrary.ari', status=status,
                    certified=certified, artifact_dir='unused')

    def test_success_requires_same_certified_polarity(self):
        result = report([self.row()], [self.row()])
        self.assertEqual(result['categories']['CSR']['certified_yes'], 1)
        with patch('report_witness_dependence.events', return_value=[]):
            result = report([self.row()], [self.row('no')])
        self.assertTrue(result['losses'][0]['polarity_change'])

    def test_missing_and_duplicate_roots_are_not_silent_losses(self):
        with self.assertRaises(ValueError):
            report([self.row()], [])
        with self.assertRaises(ValueError):
            report([self.row(), self.row()], [self.row()])

    def test_unknown_is_not_an_uncertified_decision(self):
        with patch('report_witness_dependence.events', return_value=[]):
            result = report([self.row()], [self.row('unknown', False)])
        self.assertFalse(result['losses'][0]['uncertified_decision'])


if __name__ == '__main__':
    unittest.main()
