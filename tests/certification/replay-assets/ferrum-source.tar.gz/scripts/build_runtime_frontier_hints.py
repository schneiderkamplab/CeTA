#!/usr/bin/env python3
"""Materialize typed root/event/residual states from unresolved replay results.

External proofs describe useful archived states, while a live Ferrum processor
may expose an equivalent but differently shaped residual.  This collector
turns those live states into candidate-hint rows so the state-first campaign
can solve them independently.  Existing external suggestions are retained
when their exact key matches; otherwise a small problem-kind-specific
portfolio supplies the exploration vocabulary.
"""

from __future__ import annotations

import argparse
from collections import defaultdict
import hashlib
import json
from pathlib import Path
import xml.etree.ElementTree as ET


PORTFOLIO = {
    "top-level": (
        "fast-dp",
        "poly(max-constant=2,max-coefficient=2)",
        "matrix(dim=2,max-constant=2,max-coefficient=1)",
        "path-order",
        "kbo(max-weight=2)",
        "uncurry",
        "switch-innermost",
        "nontermination",
    ),
    "dependency-pair": (
        "graph",
        "usable-rules",
        "subterm",
        "sct",
        "poly(max-constant=2,max-coefficient=2)",
        "quadratic-poly(max-constant=1,max-coefficient=1)",
        "matrix(dim=2,max-constant=2,max-coefficient=1)",
        "arctic-matrix(dimension=3,max-constant=1,max-coefficient=1)",
        "path-order",
        "kbo(max-weight=2)",
        "rewriting",
        "instantiation",
        "forward-instantiation",
        "narrowing",
        "switch-innermost",
        "nontermination",
    ),
}


def canonical_key(cpf: str) -> str:
    try:
        canonical = ET.canonicalize(cpf.strip(), strip_text=True)
    except (ET.ParseError, ValueError):
        canonical = cpf.strip()
    return hashlib.sha256(canonical.encode()).hexdigest()


def level(cpf: str) -> str:
    return "dependency-pair" if "<dpInput" in cpf else "top-level"


def load_external(paths: list[Path]) -> dict[str, list[str]]:
    suggestions: dict[str, list[str]] = defaultdict(list)
    for path in paths:
        with path.open(encoding="utf-8") as source:
            for line in source:
                row = json.loads(line)
                key = row.get("problem_key")
                if not isinstance(key, str):
                    continue
                for item in row.get("suggested_atoms") or []:
                    atom = item.get("atom") if isinstance(item, dict) else item
                    if isinstance(atom, str) and atom not in suggestions[key]:
                        suggestions[key].append(atom)
    return suggestions


def collect(
    details: list[dict], statuses: set[str], external: dict[str, list[str]]
) -> list[dict]:
    states: dict[str, dict] = {}

    def retain(cpf: object, key: object, origin: str) -> None:
        if not isinstance(cpf, str) or not cpf.strip():
            return
        try:
            ET.fromstring(cpf)
        except ET.ParseError:
            return
        actual_key = key if isinstance(key, str) and key else canonical_key(cpf)
        row = states.setdefault(
            actual_key,
            {
                "problem_key": actual_key,
                "cpf": cpf,
                "suggested_atoms": [],
                "root_origins": [],
            },
        )
        if row["cpf"] != cpf:
            # Content-addressed keys must never silently merge different typed
            # contexts.  The structural key keeps both states independently
            # addressable until semantic canonicalization establishes an alias.
            actual_key = canonical_key(cpf)
            row = states.setdefault(
                actual_key,
                {
                    "problem_key": actual_key,
                    "cpf": cpf,
                    "suggested_atoms": [],
                    "root_origins": [],
                },
            )
        atoms = external.get(actual_key, []) + list(PORTFOLIO[level(cpf)])
        for atom in atoms:
            if atom not in row["suggested_atoms"]:
                row["suggested_atoms"].append(atom)
        if origin not in row["root_origins"]:
            row["root_origins"].append(origin)

    for result in details:
        if result.get("status") not in statuses:
            continue
        origin = str(result.get("path") or result.get("problem") or "unknown")
        events_path = Path(result["artifact_dir"]) / "processor-events.jsonl"
        if not events_path.exists():
            continue
        with events_path.open(encoding="utf-8", errors="replace") as source:
            for line_text in source:
                try:
                    event = json.loads(line_text)
                except json.JSONDecodeError:
                    continue
                event_input = event.get("input") or {}
                retain(event_input.get("cpf"), event_input.get("problem_key"), origin)
                for residual in (event.get("witness") or {}).get("residuals") or []:
                    retain(residual.get("cpf"), residual.get("problem_key"), origin)

    for row in states.values():
        row["suggested_atoms"] = [
            {"atom": atom, "source": "external-or-runtime-frontier"}
            for atom in row["suggested_atoms"]
        ]
        row["root_origins"].sort()
    return sorted(states.values(), key=lambda row: row["problem_key"])


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--details", type=Path, required=True)
    parser.add_argument("--status", action="append", default=[])
    parser.add_argument("--external-hints", type=Path, action="append", default=[])
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    statuses = set(args.status or ["maybe", "timeout", "unknown"])
    details = json.loads(args.details.read_text(encoding="utf-8"))
    rows = collect(details, statuses, load_external(args.external_hints))
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with args.output.open("w", encoding="utf-8") as sink:
        for row in rows:
            sink.write(json.dumps(row, separators=(",", ":"), sort_keys=True) + "\n")
    summary = {
        "details": str(args.details),
        "statuses": sorted(statuses),
        "states": len(rows),
        "roots": len({origin for row in rows for origin in row["root_origins"]}),
        "output": str(args.output),
    }
    args.output.with_suffix(args.output.suffix + ".summary.json").write_text(
        json.dumps(summary, indent=2, sort_keys=True) + "\n", encoding="utf-8"
    )
    print(json.dumps(summary, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
