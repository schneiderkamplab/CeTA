#!/usr/bin/env python3
"""Independently recheck retained certified roots without promoting raw results."""
import argparse
from concurrent.futures import ThreadPoolExecutor
import hashlib
import json
from pathlib import Path
import subprocess


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--details', type=Path, required=True)
    p.add_argument('--ceta', required=True)
    p.add_argument('--output', type=Path, required=True)
    p.add_argument('--jobs', type=int, default=8)
    p.add_argument('--checker-timeout', type=float, default=120)
    args = p.parse_args()
    if not 0 < args.checker_timeout < float('inf'):
        p.error('--checker-timeout must be finite and positive')
    rows = [r for r in json.loads(args.details.read_text()) if r.get('certified')]
    def check(row):
        proof = Path(row['artifact_dir'])/'proof.cpf.xml'
        digest = hashlib.sha256(proof.read_bytes()).hexdigest()
        checks = []
        for _ in range(2):
            result = subprocess.run([args.ceta, str(proof)], capture_output=True, text=True, timeout=args.checker_timeout)
            checks.append(dict(returncode=result.returncode, stdout=result.stdout, stderr=result.stderr))
            if result.returncode or 'CERTIFIED' not in result.stdout.splitlines():
                raise RuntimeError(f'CeTA rejected {proof}')
            if hashlib.sha256(proof.read_bytes()).hexdigest() != digest:
                raise RuntimeError(f'Proof changed during recheck: {proof}')
        return dict(path=row['path'], proof=str(proof), sha256=digest, checks=checks)
    with args.output.open('x') as out, ThreadPoolExecutor(max_workers=args.jobs) as pool:
        for row in pool.map(check, rows):
            print(json.dumps(row), file=out, flush=True)
    print(json.dumps(dict(certified_twice=len(rows))))


if __name__ == '__main__':
    main()
