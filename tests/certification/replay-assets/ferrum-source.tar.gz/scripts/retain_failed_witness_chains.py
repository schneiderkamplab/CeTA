#!/usr/bin/env python3
"""Retain complete exact-witness chains only for failed replacement probes."""

from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path

from build_credited_status_map_dataset import canonicalize_cpf_input, compact_xml_for_key


WITNESS_SCHEMA = "ferrum.utility-guidance.witness.v1"
GROUPS = ("avoid", "possible", "prefer", "timeout")


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("original", type=Path)
    parser.add_argument("probe", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("--candidate-prefix", required=True)
    parser.add_argument("--baseline-run-dir", type=Path, required=True)
    parser.add_argument("--probe-details", type=Path, action="append", required=True)
    parser.add_argument("--failed-roots-output", type=Path)
    args = parser.parse_args()

    original_rows = [json.loads(line) for line in args.original.open(encoding="utf-8")]
    probe_rows = [json.loads(line) for line in args.probe.open(encoding="utf-8")]
    definitions = {
        row["candidate"]: row["witness_id"]
        for row in original_rows
        if row.get("schema") == WITNESS_SCHEMA
        and row.get("candidate", "").startswith(args.candidate_prefix)
    }
    definition_ids = set(definitions.values())
    failed_roots = {
        result["path"]
        for details_path in args.probe_details
        for result in json.loads(details_path.read_text(encoding="utf-8"))
        if result.get("status") != "yes" or not result.get("certified")
    }

    baseline_artifacts = {}
    for result_path in args.baseline_run_dir.rglob("result.json"):
        result = json.loads(result_path.read_text(encoding="utf-8"))
        baseline_artifacts[result.get("path")] = result_path.parent

    retained_ids = set()
    restore_keys = set()
    selected_events = 0
    for root in failed_roots:
        artifact_dir = baseline_artifacts.get(root)
        if artifact_dir is None:
            raise ValueError(f"failed root has no baseline artifact: {root}")
        events_path = artifact_dir / "processor-events.jsonl"
        for line in events_path.open(encoding="utf-8"):
            event = json.loads(line)
            event_input = event.get("input") or {}
            raw_key = event_input.get("problem_key")
            cpf = event_input.get("cpf")
            if raw_key:
                restore_keys.add(raw_key)
            if isinstance(cpf, str):
                restore_keys.add(hashlib.sha256(compact_xml_for_key(cpf).encode()).hexdigest())
                canonical, error = canonicalize_cpf_input(cpf)
                if error is None:
                    restore_keys.add(hashlib.sha256(canonical.encode()).hexdigest())
            identifier = definitions.get(event.get("processor", ""))
            if identifier is not None:
                retained_ids.add(identifier)
                selected_events += 1

    probe_by_key = {
        row["problem_key"]: row
        for row in probe_rows
        if row.get("schema") != WITNESS_SCHEMA
    }
    original_by_key = {
        row["problem_key"]: row
        for row in original_rows
        if row.get("schema") != WITNESS_SCHEMA
    }
    pending = list(restore_keys)
    while pending:
        key = pending.pop()
        row = original_by_key.get(key)
        canonical_key = row.get("canonical_problem_key") if row is not None else None
        if isinstance(canonical_key, str) and canonical_key not in restore_keys:
            restore_keys.add(canonical_key)
            pending.append(canonical_key)

    restored_rows = restore_keys & original_by_key.keys()
    for key in restored_rows:
        for group in GROUPS:
            for evidence in original_by_key[key].get(group) or []:
                reference = evidence.get("candidate_ref")
                if reference in definition_ids:
                    retained_ids.add(reference)

    def merge_retained_family(original: dict, probe: dict) -> dict:
        merged = dict(probe)
        for group in GROUPS:
            retained = [
                item
                for item in original.get(group) or []
                if item.get("candidate_ref") in retained_ids
            ]
            combined = []
            seen = set()
            for item in [*retained, *(probe.get(group) or [])]:
                identity = (
                    item.get("candidate"),
                    item.get("candidate_ref"),
                    item.get("status"),
                )
                if identity not in seen:
                    seen.add(identity)
                    combined.append(item)
            if group in original or group in probe or combined:
                merged[group] = combined
        return merged

    args.output.parent.mkdir(parents=True, exist_ok=True)
    with args.output.open("w", encoding="utf-8") as output:
        emitted_witnesses = set()
        for row in probe_rows:
            if row.get("schema") == WITNESS_SCHEMA:
                emitted_witnesses.add(row["witness_id"])
                print(json.dumps(row, separators=(",", ":"), sort_keys=True), file=output)
        for row in original_rows:
            if (
                row.get("schema") == WITNESS_SCHEMA
                and row["witness_id"] in retained_ids
                and row["witness_id"] not in emitted_witnesses
            ):
                emitted_witnesses.add(row["witness_id"])
                print(json.dumps(row, separators=(",", ":"), sort_keys=True), file=output)
        for key, row in original_by_key.items():
            probe = probe_by_key.get(key, row)
            selected = merge_retained_family(row, probe) if key in restored_rows else probe
            print(json.dumps(selected, separators=(",", ":"), sort_keys=True), file=output)
        for key, row in probe_by_key.items():
            if key not in original_by_key:
                print(json.dumps(row, separators=(",", ":"), sort_keys=True), file=output)

    if args.failed_roots_output is not None:
        args.failed_roots_output.parent.mkdir(parents=True, exist_ok=True)
        args.failed_roots_output.write_text(
            "\n".join(sorted(failed_roots)) + ("\n" if failed_roots else ""),
            encoding="utf-8",
        )
    print(json.dumps({
        "failed_roots": len(failed_roots),
        "retained_definitions": len(retained_ids),
        "retained_selected_events": selected_events,
        "restored_state_rows": len(restored_rows),
    }, sort_keys=True))


if __name__ == "__main__":
    main()
