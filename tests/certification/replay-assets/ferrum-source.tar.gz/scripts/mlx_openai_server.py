#!/usr/bin/env python3
"""Minimal OpenAI-compatible chat server backed by mlx-lm."""

from __future__ import annotations

import argparse
import time
import uuid
from pathlib import Path
from typing import Literal

import uvicorn
from fastapi import FastAPI
from pydantic import BaseModel, Field

from mlx_lm import generate, load
from mlx_lm.sample_utils import make_sampler


class ChatMessage(BaseModel):
    role: Literal["system", "user", "assistant"]
    content: str


class ChatCompletionRequest(BaseModel):
    model: str
    messages: list[ChatMessage]
    temperature: float = 0.0
    max_tokens: int = Field(default=2048, alias="max_tokens")


def _render_prompt(tokenizer, messages: list[ChatMessage]) -> str:
    serializable = [message.model_dump() for message in messages]
    if hasattr(tokenizer, "apply_chat_template"):
        try:
            return tokenizer.apply_chat_template(
                serializable,
                tokenize=False,
                add_generation_prompt=True,
                enable_thinking=False,
            )
        except Exception:
            pass
    return "\n".join(f"{message.role}: {message.content}" for message in messages) + "\nassistant:"


def create_app(model_dir: Path) -> FastAPI:
    model, tokenizer = load(str(model_dir))
    app = FastAPI()
    model_id = str(model_dir)

    @app.get("/health")
    def health() -> dict[str, str]:
        return {"status": "ok"}

    @app.get("/v1/models")
    def models() -> dict[str, object]:
        return {
            "object": "list",
            "data": [
                {
                    "id": model_id,
                    "object": "model",
                    "created": int(time.time()),
                    "owned_by": "ferrum-mlx",
                }
            ],
        }

    @app.post("/v1/chat/completions")
    def chat_completions(request: ChatCompletionRequest) -> dict[str, object]:
        prompt = _render_prompt(tokenizer, request.messages)
        text = generate(
            model,
            tokenizer,
            prompt,
            verbose=False,
            max_tokens=request.max_tokens,
            sampler=make_sampler(temp=request.temperature),
        )
        return {
            "id": f"chatcmpl-{uuid.uuid4().hex}",
            "object": "chat.completion",
            "created": int(time.time()),
            "model": model_id,
            "choices": [
                {
                    "index": 0,
                    "message": {"role": "assistant", "content": text},
                    "finish_reason": "stop",
                }
            ],
        }

    return app


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--model-dir", type=Path, required=True)
    parser.add_argument("--host", default="127.0.0.1")
    parser.add_argument("--port", type=int, required=True)
    args = parser.parse_args()

    app = create_app(args.model_dir)
    uvicorn.run(app, host=args.host, port=args.port, log_level="warning")


if __name__ == "__main__":
    main()
