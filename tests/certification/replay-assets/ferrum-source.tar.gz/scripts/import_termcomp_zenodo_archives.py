#!/usr/bin/env python3
"""Import TermCOMP raw-data archives from Zenodo into the proof corpus.

Older TermCOMP pages link proof output through StarExec stdout URLs. Those URLs
can be unavailable when StarExec DNS/service is down, but TermCOMP also
publishes yearly raw-data archives on Zenodo. The output archives contain files
named by StarExec pair id, so a URL like

    .../pairs/629711778/stdout/1?limit=-1

can be recovered from an archive member ending in `/629711778.txt`.
"""

from __future__ import annotations

import argparse
import concurrent.futures
import csv
import hashlib
import io
import json
import posixpath
import re
import sqlite3
import time
import urllib.request
import zipfile
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from collect_termcomp_proofs import detect_format, extract_features, init_db, proof_local_path


MAX_INLINE_EXTRACT_BYTES = 2_000_000


ZENODO_RECORDS = {
    2014: 14453503,
    2015: 14453637,
    2016: 14453695,
    2017: 14453735,
    2018: 14442237,
    2019: 14442386,
    2020: 14442517,
    2021: 14442715,
    2022: 14444062,
    2023: 14444408,
    2024: 14444682,
}


@dataclass(frozen=True)
class ArchiveFile:
    year: int
    key: str
    url: str
    size: int
    files_by_key: dict[str, dict[str, Any]]


def fetch_json(url: str) -> dict[str, Any]:
    req = urllib.request.Request(url, headers={"User-Agent": "ferrum-proof-corpus/0.1"})
    with urllib.request.urlopen(req, timeout=60) as response:
        return json.load(response)


def download_file(url: str, destination: Path) -> None:
    destination.parent.mkdir(parents=True, exist_ok=True)
    tmp = destination.with_suffix(destination.suffix + ".tmp")
    req = urllib.request.Request(url, headers={"User-Agent": "ferrum-proof-corpus/0.1"})
    with urllib.request.urlopen(req, timeout=300) as response, tmp.open("wb") as handle:
        while True:
            chunk = response.read(1024 * 1024)
            if not chunk:
                break
            handle.write(chunk)
    tmp.replace(destination)


def zenodo_output_archives(year: int) -> list[ArchiveFile]:
    record = ZENODO_RECORDS[year]
    data = fetch_json(f"https://zenodo.org/api/records/{record}")
    files_by_key = {item.get("key", ""): item for item in data.get("files", [])}
    archives = []
    for file_info in data.get("files", []):
        key = file_info.get("key", "")
        if not key.endswith("_output.zip"):
            continue
        archives.append(
            ArchiveFile(
                year=year,
                key=key,
                url=file_info["links"]["self"],
                size=int(file_info.get("size", 0)),
                files_by_key=files_by_key,
            )
        )
    return sorted(archives, key=lambda archive: archive.key)


def ensure_archive(cache: Path, archive: ArchiveFile) -> Path:
    destination = cache / f"Y{archive.year}" / archive.key
    if destination.exists() and destination.stat().st_size > 0:
        return destination
    download_file(archive.url, destination)
    return destination


def ensure_named_file(cache: Path, archive: ArchiveFile, key: str) -> Path | None:
    file_info = archive.files_by_key.get(key)
    if file_info is None:
        return None
    named_archive = ArchiveFile(
        year=archive.year,
        key=key,
        url=file_info["links"]["self"],
        size=int(file_info.get("size", 0)),
        files_by_key=archive.files_by_key,
    )
    return ensure_archive(cache, named_archive)


def pair_rows_for_year(conn: sqlite3.Connection, year: int) -> dict[str, dict[str, Any]]:
    rows_by_pair: dict[str, dict[str, Any]] = {}
    keys = [
        "year",
        "category",
        "benchmark",
        "tool",
        "tool_column",
        "result",
        "certification",
        "proof_url",
        "error_url",
        "benchmark_url",
        "runtime_seconds",
        "cert_runtime_seconds",
    ]
    for row in conn.execute(
        """
        select year, category, benchmark, tool, tool_column, result, certification,
               proof_url, error_url, benchmark_url, runtime_seconds, cert_runtime_seconds
        from proofs
        where year = ?
          and (download_error is not null or detected_format in ('error', 'not-downloaded'))
        """,
        (year,),
    ):
        record = dict(zip(keys, row))
        url = record["proof_url"]
        match = re.search(r"/pairs/(\d+)/stdout/", url)
        if match:
            rows_by_pair[match.group(1)] = record
    return rows_by_pair


def normalize_archive_path(value: str) -> str:
    value = value.strip().replace("\\", "/")
    value = re.sub(r"/+", "/", value)
    return value.lstrip("./")


def load_info_lookup(cache: Path, archive: ArchiveFile) -> dict[tuple[str, str, str], str]:
    info_key = archive.key.removesuffix("_output.zip") + "_info.zip"
    info_path = ensure_named_file(cache, archive, info_key)
    if info_path is None:
        return {}
    lookup: dict[tuple[str, str, str], str] = {}
    with zipfile.ZipFile(info_path) as zf:
        for member in zf.namelist():
            if not member.endswith(".csv"):
                continue
            text = zf.read(member).decode("utf-8", "replace")
            for row in csv.DictReader(io.StringIO(text)):
                pair_id = row.get("pair id", "").strip()
                benchmark = normalize_archive_path(row.get("benchmark", ""))
                solver = row.get("solver", "").strip()
                configuration = row.get("configuration", "").strip()
                if pair_id and benchmark and solver:
                    lookup[(benchmark, solver, configuration)] = pair_id
    return lookup


def pair_id_from_member_path(
    member: str,
    info_lookup: dict[tuple[str, str, str], str],
) -> str | None:
    parts = posixpath.normpath(member).split("/")
    if len(parts) < 4:
        return None
    payload = parts[1:]
    solver_index = next((idx for idx, part in enumerate(payload) if "___" in part), None)
    if solver_index is None:
        return None
    solver, configuration = payload[solver_index].split("___", 1)
    benchmark = normalize_archive_path(
        "/".join([*payload[:solver_index], *payload[solver_index + 1 :]])
    )
    return info_lookup.get((benchmark, solver, configuration))


def ensure_archive_columns(conn: sqlite3.Connection) -> None:
    columns = {row[1] for row in conn.execute("pragma table_info(proofs)")}
    if "archive_url" not in columns:
        conn.execute("alter table proofs add column archive_url text")
    if "archive_member" not in columns:
        conn.execute("alter table proofs add column archive_member text")


def link_row(conn: sqlite3.Connection, pair_id: str) -> dict[str, Any] | None:
    row = conn.execute(
        """
        select year, category, benchmark, tool, tool_column, result, certification,
               proof_url, error_url, benchmark_url, runtime_seconds, cert_runtime_seconds
        from proofs
        where proof_url like ?
        """,
        (f"%/pairs/{pair_id}/stdout/%",),
    ).fetchone()
    if row is None:
        return None
    keys = [
        "year",
        "category",
        "benchmark",
        "tool",
        "tool_column",
        "result",
        "certification",
        "proof_url",
        "error_url",
        "benchmark_url",
        "runtime_seconds",
        "cert_runtime_seconds",
    ]
    return dict(zip(keys, row))


def update_from_archive_member(
    conn: sqlite3.Connection,
    corpus_root: Path,
    archive: ArchiveFile,
    member: str,
    row: dict[str, Any],
    data: bytes,
) -> bool:
    link_like = type("ProofLinkLike", (), row)
    destination = proof_local_path(corpus_root / "artefacts", link_like)
    destination.parent.mkdir(parents=True, exist_ok=True)
    destination.write_bytes(data)
    sha = hashlib.sha256(data).hexdigest()
    if len(data) > MAX_INLINE_EXTRACT_BYTES:
        detected_format, text = detect_format(data[: min(len(data), 4096)])
        first_line = text.splitlines()[0].strip() if text.splitlines() else ""
        extracted = {
            "first_line": first_line,
            "extraction_skipped": "artefact exceeds inline extraction size limit",
            "bytes": len(data),
        }
    else:
        detected_format, extracted = extract_features(data)
    first_line = extracted.get("first_line", "")
    conn.execute(
        """
        update proofs
        set local_path = ?,
            sha256 = ?,
            bytes = ?,
            first_line = ?,
            detected_format = ?,
            extracted_json = ?,
            download_error = null,
            downloaded_at = ?,
            archive_url = ?,
            archive_member = ?
        where proof_url = ?
        """,
        (
            str(destination),
            sha,
            len(data),
            first_line,
            detected_format,
            json.dumps(extracted, sort_keys=True),
            time.time(),
            archive.url,
            member,
            row["proof_url"],
        ),
    )
    return True


def import_archive(
    db_path: Path,
    corpus_root: Path,
    cache: Path,
    archive: ArchiveFile,
) -> tuple[str, int, int, str | None]:
    conn = sqlite3.connect(db_path, timeout=60)
    conn.execute("pragma busy_timeout = 60000")
    ensure_archive_columns(conn)
    rows_by_pair = pair_rows_for_year(conn, archive.year)
    if not rows_by_pair:
        conn.close()
        return (archive.key, 0, 0, None)
    imported = 0
    seen = 0
    try:
        archive_path = ensure_archive(cache, archive)
        info_lookup: dict[tuple[str, str, str], str] | None = None
        with zipfile.ZipFile(archive_path) as zf:
            for member in zf.namelist():
                match = re.search(r"/(\d+)\.txt$", member)
                if match:
                    pair_id = match.group(1)
                else:
                    if info_lookup is None:
                        info_lookup = load_info_lookup(cache, archive)
                    pair_id = pair_id_from_member_path(member, info_lookup)
                    if pair_id is None:
                        continue
                row = rows_by_pair.get(pair_id)
                if row is None:
                    continue
                seen += 1
                if update_from_archive_member(
                    conn,
                    corpus_root,
                    archive,
                    member,
                    row,
                    zf.read(member),
                ):
                    imported += 1
                if imported % 1000 == 0:
                    conn.commit()
        conn.commit()
        return (archive.key, seen, imported, None)
    except Exception as error:  # noqa: BLE001 - record archive-level failures.
        conn.rollback()
        return (archive.key, seen, imported, repr(error))
    finally:
        conn.close()


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--out", type=Path, default=Path("target/termcomp-proof-corpus"))
    parser.add_argument("--years", nargs="*", type=int)
    parser.add_argument("--year-start", type=int, default=2014)
    parser.add_argument("--year-end", type=int, default=2024)
    parser.add_argument("--jobs", type=int, default=4)
    parser.add_argument("--archive-filter", nargs="*")
    args = parser.parse_args()

    years = args.years or [
        year
        for year in range(args.year_start, args.year_end + 1)
        if year in ZENODO_RECORDS
    ]
    db_path = args.out / "proofs.sqlite"
    cache = args.out / "zenodo-cache"
    conn = sqlite3.connect(db_path, timeout=60)
    conn.execute("pragma busy_timeout = 60000")
    init_db(db_path).close()
    ensure_archive_columns(conn)
    conn.commit()
    conn.close()

    archives: list[ArchiveFile] = []
    for year in years:
        year_archives = zenodo_output_archives(year)
        if args.archive_filter:
            year_archives = [
                archive
                for archive in year_archives
                if any(pattern in archive.key for pattern in args.archive_filter)
            ]
        archives.extend(year_archives)
        print(f"Y{year}: {len(year_archives)} output archives", flush=True)

    completed = 0
    imported_total = 0
    jobs = max(1, args.jobs)
    with concurrent.futures.ThreadPoolExecutor(max_workers=jobs) as executor:
        futures = [
            executor.submit(import_archive, db_path, args.out, cache, archive)
            for archive in archives
        ]
        for future in concurrent.futures.as_completed(futures):
            key, seen, imported, error = future.result()
            completed += 1
            imported_total += imported
            status = f"imported {imported}/{seen}"
            if error:
                status += f" error={error}"
            print(f"[{completed}/{len(futures)}] {key}: {status}", flush=True)
    print(json.dumps({"archives": len(archives), "imported": imported_total}, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
