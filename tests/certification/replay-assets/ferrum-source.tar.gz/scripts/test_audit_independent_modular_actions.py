import json
from pathlib import Path
import tempfile
import subprocess
import sys
import unittest
import xml.etree.ElementTree as ET

from audit_independent_modular_actions import collect, rename_input, renamed_action


class IndependentModularityTests(unittest.TestCase):
    def test_missing_requested_indices_fail_instead_of_reporting_empty_success(self):
        with tempfile.TemporaryDirectory() as directory:
            result = subprocess.run([
                sys.executable, str(Path(__file__).with_name('audit_independent_modular_actions.py')),
                '--root', directory, '--output', str(Path(directory) / 'audit'),
                '--ferrum', 'unused', '--ceta', 'unused', '--indices', '2693',
            ], capture_output=True, text=True)
            self.assertEqual(result.returncode, 2)
            self.assertIn('requested action indices missing', result.stderr)
            self.assertFalse((Path(directory) / 'audit/results.jsonl').exists())

    def test_path_order_removal_transports_explicit_source_and_keeps_rule_indices(self):
        xml = '<trsInput><name>f</name></trsInput>'
        payload = [{'f': 'Rpo'}, ['f'], {'f': 0}, {'f': {'NonCollapsing': [0]}}, [2, 4]]
        atom = ('exact-path-order-removal(hex=' + json.dumps(payload).encode().hex()
                + ',source-hex=' + xml.encode().hex() + ')')
        renamed, action = renamed_action(xml, atom)
        model_hex, source_hex = action.split('hex=', 1)[1][:-1].split(',source-hex=')
        self.assertEqual(json.loads(bytes.fromhex(model_hex))[-1], [2, 4])
        self.assertEqual(bytes.fromhex(source_hex).decode(), renamed)

    def test_unused_model_symbols_stay_fresh_and_do_not_alias_live_functions(self):
        payload = [['G', 0, [1]], ['g#', 0, [1]], ['G#', 0, [1]]]
        atom = 'exact-mono-poly(hex=' + json.dumps(payload).encode().hex() + ')'
        _, action = renamed_action('<dpInput><sharp><name>g</name></sharp></dpInput>', atom)
        actual = json.loads(bytes.fromhex(action.split('hex=')[1][:-1]))
        self.assertEqual(actual[0][0], 'audit_witness_symbol_0')
        self.assertEqual(actual[1][0], 'audit_symbol_0#')
        self.assertEqual(actual[2][0], 'audit_witness_symbol_0#')

    def test_model_symbol_starting_with_angle_bracket_is_not_xml(self):
        payload = [['<=', -1, [1, 2]], ['<name>', 0, []]]
        atom = 'exact-weak-poly(hex=' + json.dumps(payload).encode().hex() + ')'
        _, action = renamed_action('<dpInput><name>&lt;=</name><name>&lt;name&gt;</name></dpInput>', atom)
        actual = json.loads(bytes.fromhex(action.split('hex=')[1][:-1]))
        self.assertEqual(actual, [['audit_symbol_0', -1, [1, 2]], ['audit_symbol_1', 0, []]])

    def test_number_labeled_model_uses_typed_symbol_identity(self):
        xml = '<dpInput><labeledSymbol><sharp><name>f</name></sharp><numberLabel><number>1</number></numberLabel></labeledSymbol></dpInput>'
        payload = [['__ferrum_sl__6623__1', 2, [1]]]
        atom = 'exact-mono-poly(hex=' + json.dumps(payload).encode().hex() + ')'
        _, action = renamed_action(xml, atom)
        actual = json.loads(bytes.fromhex(action.split('hex=')[1][:-1]))
        self.assertEqual(actual, [['__ferrum_sl__' + 'audit_symbol_0#'.encode().hex() + '__1', 2, [1]]])

    def test_fresh_csr_wrapper_uses_imported_runtime_identity(self):
        xml = '''<dpInput><trs><rules><rule><funapp><name>f</name></funapp>
          <funapp><name>f</name></funapp></rule></rules></trs>
          <dps><rules><rule><funapp><name>fresh</name><var>x</var></funapp>
          <funapp><name>fresh</name><var>x</var></funapp></rule></rules></dps>
          <strategy><contextSensitive><replacementMapEntry><name>fresh</name>
          <arity>1</arity></replacementMapEntry></contextSensitive></strategy>
          <ferrumCsrDpContext><construction>improved</construction>
          </ferrumCsrDpContext></dpInput>'''
        atom = 'exact-subterm(hex=' + json.dumps([['fresh', 1, 0]]).encode().hex() + ')'
        renamed, action = renamed_action(xml, atom)
        self.assertNotIn('<name>fresh</name>', renamed)
        self.assertEqual(json.loads(bytes.fromhex(action.split('hex=')[1][:-1])),
                         [['__CSR_U0', 1, 0]])
        # A live source symbol is never mistaken for a generated wrapper.
        _, action = renamed_action(xml.replace('<name>f</name>', '<name>fresh</name>'), atom)
        self.assertNotIn('__CSR_U', bytes.fromhex(action.split('hex=')[1][:-1]).decode())

    def test_numeric_alias_is_not_split_by_witness_transport(self):
        xml = '<dpInput><name>|0|</name></dpInput>'
        payload = '<innermostLhss><funapp><name>0</name></funapp></innermostLhss>'
        atom = 'exact-innermost-lhss(hex=' + json.dumps(payload).encode().hex() + ')'
        renamed, action = renamed_action(xml, atom)
        target = json.loads(bytes.fromhex(action.split('hex=')[1][:-1]))
        self.assertEqual(ET.fromstring(renamed).find('name').text,
                         ET.fromstring(target).find('funapp/name').text)

    def test_size_change_indices_are_not_symbol_names(self):
        xml = '<dpInput><name>1</name><name>f</name></dpInput>'
        payload = [[0, [[1, True, 2]]]]
        atom = 'exact-size-change(hex=' + json.dumps(payload).encode().hex() + ')'
        _, action = renamed_action(xml, atom)
        self.assertEqual(json.loads(bytes.fromhex(action.split('hex=')[1][:-1])), payload)

    def test_path_order_transports_keys_not_order_kind(self):
        xml = '<dpInput><name>Rpo</name></dpInput>'
        payload = [{'Rpo': 'Rpo'}, ['Rpo'], {'Rpo': 2}, {'Rpo': {'NonCollapsing': [0]}}]
        atom = 'exact-path-order(hex=' + json.dumps(payload).encode().hex() + ')'
        _, action = renamed_action(xml, atom)
        actual = json.loads(bytes.fromhex(action.split('hex=')[1][:-1]))
        self.assertEqual(actual, [{'audit_symbol_0': 'Rpo'}, ['audit_symbol_0'],
                                 {'audit_symbol_0': 2}, {'audit_symbol_0': {'NonCollapsing': [0]}}])

    def test_multi_element_xml_witness_does_not_gain_a_wrapper(self):
        xml = '<dpInput><name>f</name></dpInput>'
        payload = ['instantiationProc', '<rule><name>f</name></rule><rule><name>f</name></rule>', xml]
        atom = 'exact-dp-transform(hex=' + json.dumps(payload).encode().hex() + ')'
        _, action = renamed_action(xml, atom)
        actual = json.loads(bytes.fromhex(action.split('hex=')[1][:-1]))
        self.assertNotIn('auditFragment', actual[1])
        self.assertEqual(actual[1].count('audit_symbol_0'), 2)
        self.assertEqual(actual[0], 'instantiationProc')

    def test_exact_graph_transports_source_not_indices(self):
        xml = '<dpInput><name>f</name><sharp><name>g</name></sharp></dpInput>'
        components = [[[0, 1], True]]
        atom = 'exact-graph(hex=' + json.dumps([xml, components]).encode().hex() + ')'
        renamed, action = renamed_action(xml, atom)
        source, actual = json.loads(bytes.fromhex(action.split('hex=')[1][:-1]))
        self.assertEqual(source, renamed)
        self.assertEqual(actual, components)

    def test_exact_matrix_transports_marked_symbol_without_changing_numbers(self):
        xml = '<dpInput><name>f</name><sharp><name>f</name></sharp></dpInput>'
        payload = [['f#', [1], [[[2]]]]]
        atom = 'exact-matrix(hex=' + json.dumps(payload).encode().hex() + ')'
        _, action = renamed_action(xml, atom)
        self.assertEqual(json.loads(bytes.fromhex(action.split('hex=')[1][:-1])),
                         [['audit_symbol_0#', [1], [[[2]]]]])

    def test_rename_preserves_roles_context_and_symbol_sharing(self):
        source = '<dpInput><name>f</name><name>f</name><name>g</name><var>f</var><var>x</var><minimal/><q><name>f</name></q><replacementMap><entry><name>g</name><position>1</position></entry></replacementMap></dpInput>'
        root = ET.fromstring(rename_input(source))
        self.assertEqual([n.text for n in root.findall('name')],
                         ['audit_symbol_0', 'audit_symbol_0', 'audit_symbol_1'])
        self.assertEqual(root.find('var').text, 'audit_variable_0')
        self.assertEqual(root.find('q/name').text, 'audit_symbol_0')
        self.assertIsNotNone(root.find('minimal'))
        self.assertEqual(root.find('replacementMap/entry/position').text, '1')

    def test_collect_requires_an_actual_child_and_resolves_content_address(self):
        rows = [dict(input=dict(problem_key='root', cpf='<trsInput/>'),
                     witness=dict(residuals=[dict(problem_key='child', cpf='<dpInput/>')]),
                     outcome='transformed', strategy_atom='dp'),
                dict(input=dict(problem_key='child', cpf=None), witness={},
                     outcome='solved', strategy_atom='size-change')]
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / 'events.jsonl'
            path.write_text('\n'.join(map(json.dumps, rows)))
            self.assertEqual(list(collect(path)), [('<dpInput/>', 'size-change', 'solved', 'child')])


if __name__ == '__main__':
    unittest.main()
