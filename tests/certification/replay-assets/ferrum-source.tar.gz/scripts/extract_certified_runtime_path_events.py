#!/usr/bin/env python3
"""Freeze an unambiguous completed runtime proof tree as exact oracle evidence.

This adapter is intentionally stricter than ordinary event ingestion.  It
requires one successful action per reachable state, requires every residual to
be closed by another recorded action, rejects disconnected successful trials,
and rechecks the resulting complete CPF twice.  Thus abandoned Choice branches
cannot accidentally become preferred oracle guidance.
"""

from __future__ import annotations

import argparse
import json
import subprocess
from pathlib import Path


def check_twice(ceta: Path, proof: Path, timeout: float) -> None:
    for attempt in range(1, 3):
        try:
            checked = subprocess.run(
                [str(ceta), str(proof)],
                text=True,
                stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT,
                timeout=timeout,
            )
        except subprocess.TimeoutExpired as error:
            raise SystemExit(f"CeTA recheck {attempt} timed out: {proof}") from error
        if checked.returncode != 0 or "CERTIFIED" not in checked.stdout.upper():
            raise SystemExit(
                f"CeTA recheck {attempt} rejected {proof}: {checked.stdout[-1000:]}"
            )


def residual_keys(event: dict) -> tuple[str, ...]:
    witness = event.get("witness") or {}
    residuals = witness.get("residuals") or []
    keys = []
    for residual in residuals:
        key = residual.get("problem_key") if isinstance(residual, dict) else None
        if not isinstance(key, str) or not key:
            raise SystemExit("transformed event has a residual without a problem_key")
        keys.append(key)
    return tuple(keys)


def successful_runtime_path(events_path: Path) -> list[dict]:
    state_inputs: dict[str, dict] = {}
    success_trials: dict[str, list[dict]] = {}
    roots: set[str] = set()
    for line in events_path.open(encoding="utf-8"):
        event = json.loads(line)
        input_record = event.get("input") or {}
        key = input_record.get("problem_key")
        if not isinstance(key, str) or not key:
            continue
        if input_record.get("cpf"):
            state_inputs.setdefault(key, input_record)
        for residual in (event.get("witness") or {}).get("residuals") or []:
            if not isinstance(residual, dict):
                continue
            residual_key = residual.get("problem_key")
            residual_cpf = residual.get("cpf")
            if isinstance(residual_key, str) and residual_key and residual_cpf:
                state_inputs.setdefault(
                    residual_key,
                    {
                        "format": input_record.get("format", "cpf3"),
                        "problem_key": residual_key,
                        "cpf": residual_cpf,
                    },
                )
        if event.get("outcome") not in {"solved", "transformed"}:
            continue
        success_trials.setdefault(key, []).append(event)
        if event.get("level") == "top-level":
            roots.add(key)

    child_keys = {
        child
        for trials in success_trials.values()
        for event in trials
        if event.get("outcome") == "transformed"
        for child in residual_keys(event)
        if child != event.get("input", {}).get("problem_key")
    }
    roots.difference_update(child_keys)
    if len(roots) != 1:
        raise SystemExit(f"expected exactly one successful top-level root, found {len(roots)}")
    root = next(iter(roots))
    memo: dict[str, dict[str, dict] | None] = {}

    def closed_tree(key: str, active: set[str]) -> dict[str, dict] | None:
        if key in memo:
            return memo[key]
        if key in active:
            return None
        by_signature: dict[tuple, dict] = {}
        for event in success_trials.get(key, []):
            children = residual_keys(event) if event.get("outcome") == "transformed" else ()
            # A graph/split probe that returns only its input state made no
            # progress and is not a causal proof step.  Historical logs called
            # this ``transformed``; ignore it when selecting the completed path.
            if children == (key,):
                continue
            signature = (event.get("outcome"), event.get("processor"), children)
            by_signature.setdefault(signature, event)
        complete: list[dict[str, dict]] = []
        for event in by_signature.values():
            tree = {key: event}
            if event.get("outcome") == "transformed":
                children = residual_keys(event)
                if not children:
                    continue
                for child in children:
                    child_tree = closed_tree(child, active | {key})
                    if child_tree is None:
                        break
                    tree.update(child_tree)
                else:
                    complete.append(tree)
            else:
                complete.append(tree)
        if len(complete) > 1:
            raise SystemExit(
                f"ambiguous completed runtime continuations for state {key}: "
                f"{len(complete)}"
            )
        result = complete[0] if complete else None
        memo[key] = result
        return result

    selected_by_key = closed_tree(root, set())
    if selected_by_key is None:
        raise SystemExit(f"open residual without a complete successful continuation: {root}")

    selected = []
    for key in sorted(selected_by_key):
        event = dict(selected_by_key[key])
        input_record = dict(event.get("input") or {})
        if not input_record.get("cpf"):
            stored = state_inputs.get(key)
            if stored is None or not stored.get("cpf"):
                raise SystemExit(f"no materialized CPF input for runtime state {key}")
            input_record["cpf"] = stored["cpf"]
        event["input"] = input_record
        event["certification"] = {
            "status": "certified-full-source",
            "checker": "CeTA",
        }
        event["credit"] = {"status": "proof-path-certified"}
        selected.append(event)
    return selected


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--events", type=Path, action="append", required=True)
    parser.add_argument("--proof", type=Path, action="append", required=True)
    parser.add_argument("--ceta", type=Path, required=True)
    parser.add_argument("--ceta-timeout", type=float, default=60.0)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--certified-manifest-output", type=Path, required=True)
    args = parser.parse_args()
    if len(args.events) != len(args.proof):
        parser.error("--events and --proof must occur the same number of times")

    output_rows: list[dict] = []
    manifest_rows: list[dict] = []
    for events, proof in zip(args.events, args.proof, strict=True):
        check_twice(args.ceta, proof, args.ceta_timeout)
        rows = successful_runtime_path(events)
        output_rows.extend(rows)
        for row in rows:
            manifest_rows.append(
                {
                    "scope": "canonical",
                    "problem_key": row["input"]["problem_key"],
                    "candidate": row["processor"],
                    "recorded_implementation_hash": None,
                    "recheck_status": "certified",
                    "deterministic_rechecks": 2,
                    "source_proof": str(proof),
                    "checker": str(args.ceta),
                }
            )

    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(
        "".join(json.dumps(row, separators=(",", ":")) + "\n" for row in output_rows),
        encoding="utf-8",
    )
    args.certified_manifest_output.parent.mkdir(parents=True, exist_ok=True)
    args.certified_manifest_output.write_text(
        "".join(json.dumps(row, separators=(",", ":")) + "\n" for row in manifest_rows),
        encoding="utf-8",
    )
    print(
        json.dumps(
            {
                "proofs_certified_twice": len(args.proof),
                "runtime_path_events": len(output_rows),
                "unique_states": len({row["input"]["problem_key"] for row in output_rows}),
            },
            sort_keys=True,
        )
    )


if __name__ == "__main__":
    main()
