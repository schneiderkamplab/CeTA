#!/usr/bin/env python3
"""Replay baseline certified NO roots without fallback, then recheck each CPF."""
import argparse
from concurrent.futures import ThreadPoolExecutor, as_completed
import hashlib
import json
import os
from pathlib import Path
import subprocess
from termcomp_trs_compare import run_one, result_to_dict, safe_problem_dir
from compare_certified_replays import compare


def main():
    p = argparse.ArgumentParser(description=__doc__)
    for name in ('baseline', 'oracle', 'output', 'ferrum', 'ceta'):
        p.add_argument('--' + name, type=Path, required=True)
    p.add_argument('--jobs', type=int, default=16)
    p.add_argument('--polarity', choices=('no', 'yes', 'all'), default='no',
                   help='Use all for the full previously certified cross-category guard')
    p.add_argument('--retry-details', type=Path,
                   help='Retry only uncertified roots from a completed preceding replay')
    args = p.parse_args()
    args.output.mkdir(parents=True, exist_ok=False)
    os.environ['FERRUM_DP_LLM_NO_FALLBACK'] = '1'
    os.environ['RAYON_NUM_THREADS'] = '2'
    os.environ.pop('FERRUM_STATE_LOCAL_PRIORITY', None)
    tasks = []
    for category in ('standard', 'innermost', 'csr'):
        for row in json.loads((args.baseline/category/'details.json').read_text()):
            if row['certified'] and (args.polarity == 'all' or row['status'] == args.polarity):
                tasks.append(row)
    if args.retry_details:
        missing = {row['path'] for row in json.loads(args.retry_details.read_text())
                   if not row['certified']}
        tasks = [row for row in tasks if row['path'] in missing]

    def run(row):
        path = Path(row['path'])
        category = next(x for x in path.parts if x.startswith('TRS_'))
        root = Path(*path.parts[:path.parts.index(category)+1])
        allowance = 1200 if category == 'TRS_Innermost' else 300
        result = run_one(args.ferrum, args.ceta, root, path, allowance + 5,
                         ['--strategy', f'timeout({allowance}s, fail)',
                          '--utility-guidance-manifest', str(args.oracle),
                          '--no-top-level-llm'], True, args.output/'run'/category)
        record = result_to_dict(category, result)
        cpf = safe_problem_dir(root, path, args.output/'run'/category)/'proof.cpf.xml'
        record['independent_rechecks'] = []
        if record['certified']:
            digest = hashlib.sha256(cpf.read_bytes()).hexdigest()
            for _ in range(2):
                checked = subprocess.run([str(args.ceta), str(cpf)], capture_output=True,
                                         text=True, timeout=60)
                ok = checked.returncode == 0 and 'CERTIFIED' in checked.stdout
                record['independent_rechecks'].append(ok)
            record['proof_sha256'] = digest
            record['certified'] = (record['status'] == row['status']
                                   and all(record['independent_rechecks'])
                                   and digest == hashlib.sha256(cpf.read_bytes()).hexdigest())
        return record

    results = []
    with ThreadPoolExecutor(max_workers=args.jobs) as pool, (args.output/'results.jsonl').open('x') as log:
        for future in as_completed([pool.submit(run, row) for row in tasks]):
            row = future.result()
            results.append(row)
            print(json.dumps(row), file=log, flush=True)
            print(json.dumps({k: row[k] for k in ('path', 'status', 'certified', 'elapsed_seconds')}), flush=True)
    (args.output/'details.json').write_text(json.dumps(results, indent=2))
    comparison = compare(tasks, results)
    (args.output/'comparison.json').write_text(json.dumps(comparison, indent=2))
    print(json.dumps({'total': len(results), 'certified': sum(r['certified'] for r in results)}), flush=True)
    if any(comparison[k] for k in ('missing_inputs', 'extra_inputs', 'losses',
                                    'polarity_changes', 'uncertified_decisions')):
        raise SystemExit(1)


if __name__ == '__main__':
    main()
