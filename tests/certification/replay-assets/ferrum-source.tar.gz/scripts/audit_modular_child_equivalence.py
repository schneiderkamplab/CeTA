#!/usr/bin/env python3
"""Compare full-context canonical children of original/renamed action probes."""
import argparse
from concurrent.futures import ThreadPoolExecutor, as_completed
import hashlib
import json
from pathlib import Path
import threading
import xml.etree.ElementTree as ET
import ijson
from build_credited_status_map_dataset import canonicalize_with_ferrum


def inverse_input_mapping(original, renamed):
    left, right = list(ET.fromstring(original).iter()), list(ET.fromstring(renamed).iter())
    if len(left) != len(right):
        return None
    mapping = {}
    for a, b in zip(left, right):
        if a.tag != b.tag or a.attrib != b.attrib:
            return None
        if a.tag in ('name', 'var'):
            key = (a.tag, b.text)
            if key in mapping and mapping[key] != a.text:
                return None
            mapping[key] = a.text
        elif (a.text or '').strip() != (b.text or '').strip():
            return None
    if len(set((kind, name) for (kind, _), name in mapping.items())) != len(mapping):
        return None
    return mapping


def normalized_xml(xml, inverse=None):
    root = ET.fromstring(xml)
    for node in root.iter():
        node.text = (inverse or {}).get((node.tag, node.text), node.text)
        if node.text is not None and not node.text.strip():
            node.text = None
        if node.tail is not None and not node.tail.strip():
            node.tail = None
    for node in root.iter('contextSensitive'):
        if not all(entry.tag == 'replacementMapEntry' and len(entry) for entry in node):
            raise ValueError('unsupported replacement-map structure')
        keys = [ET.tostring(entry[0], encoding='unicode') for entry in node]
        if len(set(keys)) != len(keys):
            raise ValueError('duplicate replacement-map symbol')
        # A map's unique entries may be emitted in symbol-sorted order, which
        # changes after renaming. Retain every entry, arity and position.
        node[:] = sorted(node, key=lambda entry: ET.tostring(entry, encoding='unicode'))
    # Variables are bound locally to a rewrite rule (or to one Q pattern).
    # Freshening names such as x__n2 must not be confused with a changed rule.
    scopes = list(root.iter('rule'))
    for q in root.iter('innermostLhss'):
        scopes.extend(term for term in q if term.tag in ('funapp', 'var'))
    for scope in scopes:
        names = {}
        for variable in scope.iter('var'):
            variable.text = f'v{names.setdefault(variable.text, len(names))}'
    return ET.tostring(root, encoding='unicode')


def streamed_children(path, count):
    """Read only top-level children, not duplicated details/transition payloads."""
    if count == 0:
        return
    with path.open('rb') as stream:
        found = 0
        builder = None
        for prefix, event, value in ijson.parse(stream):
            if prefix == 'children' and event == 'end_array':
                if found != count:
                    raise ValueError(f'expected {count} full children, found {found}: {path}')
                return
            if prefix == 'children.item' and event == 'start_map':
                builder = ijson.common.ObjectBuilder()
            if builder is not None:
                builder.event(event, value)
                if prefix == 'children.item' and event == 'end_map':
                    found += 1
                    yield builder.value
                    builder = None
        raise ValueError(f'missing complete children array: {path}')


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--audit-root', type=Path, required=True)
    p.add_argument('--ferrum', required=True)
    p.add_argument('--output', type=Path, required=True)
    p.add_argument('--jobs', type=int, default=8)
    p.add_argument('--override-root', type=Path, action='append', default=[],
                   help='Replace observations with complete focused repeats')
    p.add_argument('--strict', action='store_true',
                   help='Only accept explicit input-bijection equality, not canonical-key equality')
    p.add_argument('--states-dir', type=Path,
                   help='Retain unique raw child CPFs by content hash')
    p.add_argument('--recheck-differences', type=Path,
                   help='Only recheck cases not already proven equal in this prior report')
    args = p.parse_args()
    rows = [json.loads(line) for line in (args.audit_root / 'results.jsonl').open()]
    by_index = {row['index']: row for row in rows}
    directories = {row['index']: args.audit_root / str(row['index']) for row in rows}
    for override in args.override_root:
        for row in map(json.loads, (override / 'results.jsonl').open()):
            old = by_index[row['index']]
            if any(old[k] != row[k] for k in ('problem_key', 'family', 'source_events')):
                raise ValueError('focused repeat changed action identity')
            if (directories[row['index']] / 'atom.fs').read_bytes() != (override / str(row['index']) / 'atom.fs').read_bytes():
                raise ValueError('focused repeat changed the action')
            by_index[row['index']] = row
            directories[row['index']] = override / str(row['index'])
    rows = list(by_index.values())
    if args.recheck_differences:
        wanted = {row['index'] for row in map(json.loads, args.recheck_differences.open())
                  if row['status'] not in ('equal', 'terminal-no-children')}
        rows = [row for row in rows if row['index'] in wanted]
    state_lock = threading.Lock()
    retained = set()
    if args.states_dir:
        args.states_dir.mkdir(parents=True, exist_ok=False)

    def retain(xml):
        digest = hashlib.sha256(xml.encode()).hexdigest()
        if args.states_dir:
            with state_lock:
                if digest not in retained:
                    with (args.states_dir / (digest + '.cpf')).open('x') as stream:
                        stream.write(xml)
                    retained.add(digest)
        return digest

    def compare(row):
        result = dict(index=row['index'], family=row['family'])
        if not row['rename_supported']:
            return dict(result, status='unsupported-witness-transport')
        if any(r.get('returncode') != 0 for r in row['results']):
            return dict(result, status='probe-failed')
        directory = directories[row['index']]
        signatures = []
        observations = []
        try:
            variants = {r['variant']: r for r in row['results']}
            if set(variants) != {'original', 'renamed'}:
                raise ValueError('missing variant')
            if all(r.get('outcome') == 'solved' and r.get('certified') for r in variants.values()):
                return dict(result, status='terminal-no-children', observations=[])
            inverse = inverse_input_mapping((directory / 'original.input.cpf').read_text(),
                                            (directory / 'renamed.input.cpf').read_text())
            direct_signatures = []
            for variant, mapping in [('original', None), ('renamed', inverse)]:
                children = []
                for index, child in enumerate(streamed_children(directory / f'{variant}.stdout', variants[variant]['children'])):
                    digest = retain(child['cpf'])
                    normalized = hashlib.sha256(normalized_xml(child['cpf'], mapping).encode()).hexdigest()
                    children.append((child['problem_kind'], child.get('assumption_kind'), normalized))
                    observations.append(dict(variant=variant, child=index, sha256=digest,
                        normalized_sha256=normalized, problem_kind=child['problem_kind'],
                        assumption_kind=child.get('assumption_kind')))
                direct_signatures.append((variants[variant]['outcome'], sorted(children)))
            if inverse is not None and direct_signatures[0] == direct_signatures[1]:
                return dict(result, status='equal', comparison_method='explicit-input-bijection',
                            observations=observations)
            if args.strict:
                return dict(result, status='needs-inspection', observations=observations,
                            input_bijection=inverse is not None)
            for variant in ('original', 'renamed'):
                children = []
                for child in streamed_children(directory / f'{variant}.stdout', variants[variant]['children']):
                    canonical = canonicalize_with_ferrum(child['cpf'], args.ferrum, 60)
                    children.append((child['problem_kind'], child.get('assumption_kind'),
                                     hashlib.sha256(canonical.encode()).hexdigest()))
                signatures.append((variants[variant]['outcome'], sorted(children)))
            return dict(result, status='equal' if signatures[0] == signatures[1] else 'different',
                        signatures=signatures, observations=observations,
                        comparison_method='production-canonicalizer')
        except Exception as error:
            return dict(result, status='comparison-failed', reason=str(error)[:400], observations=observations)

    with ThreadPoolExecutor(max_workers=args.jobs) as pool, args.output.open('x') as log:
        for future in as_completed([pool.submit(compare, row) for row in rows]):
            print(json.dumps(future.result()), file=log, flush=True)


if __name__ == '__main__':
    main()
