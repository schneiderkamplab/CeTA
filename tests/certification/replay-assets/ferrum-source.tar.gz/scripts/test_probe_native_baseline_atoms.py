import hashlib
import json
import unittest

from probe_native_baseline_atoms import selected_atoms


class NativeBaselineAtomsTests(unittest.TestCase):
    def event(self, cpf='<trsInput><trs/></trsInput>'):
        return dict(level='trs', outcome='solved',
                    processor='exact-poly(hex=' + json.dumps([['private_name', 2, [1]]]).encode().hex() + ')',
                    input=dict(cpf=cpf, problem_key=hashlib.sha256(cpf.encode()).hexdigest()))

    def test_extracts_bounds_not_interpretations(self):
        [job] = list(selected_atoms([self.event()]))
        self.assertTrue(job['native'].startswith('poly('))
        self.assertNotIn('private_name', job['native'])
        self.assertNotIn('hex=', job['native'])

    def test_per_family_limit_and_failed_evidence(self):
        event = self.event()
        self.assertEqual(len(list(selected_atoms([event, event]))), 1)
        event['outcome'] = 'failed'
        self.assertEqual(list(selected_atoms([event])), [])

    def test_bad_digest_is_not_used(self):
        event = self.event()
        event['input']['problem_key'] = '0' * 64
        with self.assertRaises(ValueError):
            list(selected_atoms([event]))


if __name__ == '__main__':
    unittest.main()
