"""Export state-local search parameters from twice-rechecked root event streams.

No event inherits root certification credit. Unsupported witness conversions
are reported and omitted. The new guidance needs an independent root replay.
"""
import argparse
import collections
from concurrent.futures import ThreadPoolExecutor
import hashlib
import json
import re
from pathlib import Path
import subprocess

from export_witness_free_probe_hints import collect, search_atoms, attach_canonical_alias
from add_runtime_canonical_aliases import canonicalize
from atomic_artifact import atomic_text_output


def atomic_candidate(candidate):
    """Keep transformation choice, leaving continuation to child-state hints."""
    for atom in ('csr-improved-dp', 'csr-native-dp', 'csr-safe-dp', 'dp-trimmed', 'dp'):
        if candidate.startswith(atom + '('):
            return atom
    if re.search(r'\b(?:pipeline|repeat|timeout|delay|choice)\s*\(', candidate):
        return None
    if any(separator in candidate for separator in (';', '|')):
        return None
    return candidate


def collect_supported(events, original_atoms=(), prefer_latest=False, prefer_terminal=False,
                      candidate_families=(), shared_top_path_order=False):
    # A late successful trial is often the continuation reached after earlier
    # branches failed. This is only a ranking heuristic: it confers no proof
    # credit, and all earlier alternatives remain available.
    if prefer_latest:
        events = reversed(list(events))
    if prefer_terminal:
        # Prefer a native search that previously closed this state over one
        # that merely exposed children. This remains weak search guidance.
        events = sorted(events, key=lambda event: event.get('outcome') != 'solved')
    rows = {}
    omitted = collections.Counter()
    for event in events:
        # These two are orchestration diagnostics, not executable processors.
        if event.get('processor') in ('utility-guidance', 'llm'):
            continue
        try:
            incoming = collect([event], original_atoms)
        except ValueError as error:
            if str(error) != 'unsupported native action conversion':
                raise
            omitted[event.get('processor', '').split('(', 1)[0]] += 1
            continue
        for row in incoming:
            native = []
            for candidate in row['possible']:
                atom = atomic_candidate(candidate['candidate'])
                if atom is None:
                    omitted['compound-strategy'] += 1
                    continue
                if candidate_families and atom.split('(', 1)[0] not in candidate_families:
                    continue
                if shared_top_path_order and event.get('level') == 'top-level' and atom.split('(', 1)[0] == 'path-order':
                    native.append(dict(candidate='path-order(max-symbols=256,shared=1)',
                        status='transformed_weak', utility_score=1.0, attempts=0,
                        certified_count=0, solved_count=0, transformed_count=0,
                        failed_count=0, timeout_count=0))
                native.append({**candidate, 'candidate': atom})
            row['possible'] = native
            if not native:
                continue
            # A role-based construction is an independent native alternative,
            # not the interpretation contained in the recorded order. It
            # declines non-GM04 inputs and rechecks every live obligation.
            for candidate in list(row['possible']):
                if candidate['candidate'] == 'path-order':
                    row['possible'].insert(0, dict(candidate='gm04-rpo',
                        status='transformed_weak', utility_score=1.0, attempts=0,
                        certified_count=0, solved_count=0, transformed_count=0,
                        failed_count=0, timeout_count=0))
                if candidate['candidate'] == 'complex-constant-removal':
                    row['possible'].append(dict(candidate='complex-constant-removal-largest',
                        status='transformed_weak', utility_score=1.0, attempts=0,
                        certified_count=0, solved_count=0, transformed_count=0,
                        failed_count=0, timeout_count=0))
            target = rows.setdefault(row['problem_key'], row)
            if target is row:
                continue
            known = {c['candidate'] for c in target['possible']}
            target['possible'].extend(c for c in row['possible'] if c['candidate'] not in known)
    for row in rows.values():
        row['replay_order'] = [hashlib.sha256(c['candidate'].encode()).hexdigest()
                               for c in row['possible']]
    return rows, omitted


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--details', type=Path, required=True)
    parser.add_argument('--category')
    parser.add_argument('--path-suffix', help='Restrict evidence to matching root paths')
    parser.add_argument('--candidate-family', action='append', default=[],
                        help='Export only this native processor family; repeatable')
    parser.add_argument('--level', choices=['top-level', 'dependency-pair'],
                        help='Restrict native hints to this typed processor level')
    parser.add_argument('--shared-top-path-order', action='store_true',
                        help='Try the shared encoding at top-level path-order states')
    parser.add_argument('--unresolved-details', type=Path)
    parser.add_argument('--canonical-ferrum', type=Path)
    parser.add_argument('--canonical-jobs', type=int, default=8)
    parser.add_argument('--retain-probe-recipes', action='store_true',
                        help='Keep flat native discovery bounds as untried state-local hints')
    parser.add_argument('--record-replay-timings', action='store_true',
                        help='Preserve observed native action times separately from historical minima')
    parser.add_argument('--prefer-latest-success', action='store_true',
                        help='Rank later successful trials first; retain every earlier alternative')
    parser.add_argument('--prefer-terminal', action='store_true',
                        help='Prioritize native searches that previously closed their local state')
    parser.add_argument('--ceta', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    unresolved = None if not args.unresolved_details else {
        r['path'] for r in json.loads(args.unresolved_details.read_text()) if not r.get('certified')}
    roots = [r for r in json.loads(args.details.read_text()) if r.get('certified')
             and (not args.category or r.get('category') == args.category)
             and (unresolved is None or r['path'] in unresolved)
             and (not args.path_suffix or r['path'].endswith(args.path_suffix))]
    if not roots:
        raise ValueError('no certified roots selected')
    rows, omitted, checks, cpfs = {}, collections.Counter(), [], {}
    for root in roots:
        directory = Path(root['artifact_dir'])
        proof = directory / 'proof.cpf.xml'
        digest = hashlib.sha256(proof.read_bytes()).hexdigest()
        results = []
        for _ in range(2):
            result = subprocess.run([str(args.ceta.resolve()), str(proof.resolve())],
                                    capture_output=True, text=True, timeout=120)
            if result.returncode or 'CERTIFIED' not in result.stdout.splitlines():
                raise ValueError(f'CeTA rejected {proof}')
            if hashlib.sha256(proof.read_bytes()).hexdigest() != digest:
                raise ValueError(f'proof changed: {proof}')
            results.append(dict(returncode=result.returncode, stdout=result.stdout, stderr=result.stderr))
        checks.append(dict(path=root['path'], proof=str(proof), sha256=digest, checks=results))
        with (directory / 'processor-events.jsonl').open() as source:
            events = list(map(json.loads, source))
        for event in events:
            for state in [event.get('input') or {}, *((event.get('witness') or {}).get('residuals') or [])]:
                if state.get('cpf'):
                    key = hashlib.sha256(state['cpf'].strip().encode()).hexdigest()
                    if key != state.get('problem_key'):
                        raise ValueError('state digest mismatch')
                    cpfs[key] = state['cpf']
        originals = search_atoms((directory / 'strategy.fs').read_text()) if args.retain_probe_recipes else ()
        selected_events = [e for e in events if not args.level or e.get('level') == args.level]
        local, unsupported = collect_supported(selected_events, originals, args.prefer_latest_success,
                                               args.prefer_terminal, args.candidate_family,
                                               args.shared_top_path_order)
        omitted.update(unsupported)
        for key, row in local.items():
            target = rows.setdefault(key, row)
            if target is not row:
                known = {c['candidate'] for c in target['possible']}
                target['possible'].extend(c for c in row['possible'] if c['candidate'] not in known)
                target['replay_order'] = list(dict.fromkeys(target['replay_order'] + row['replay_order']))
    canonical_failures, aliases = [], 0
    if args.canonical_ferrum:
        def convert(key):
            try:
                cpf = canonicalize(args.canonical_ferrum.resolve(), cpfs[key], 15)
                return key, hashlib.sha256(cpf.encode()).hexdigest(), None
            except (RuntimeError, subprocess.TimeoutExpired) as error:
                return key, None, str(error)[:250]
        with ThreadPoolExecutor(max_workers=args.canonical_jobs) as pool:
            futures = [pool.submit(convert, key) for key in list(rows) if key in cpfs]
            # Preserve input/event ordering regardless of worker completion.
            for future in futures:
                key, canonical_key, error = future.result()
                if error:
                    canonical_failures.append(dict(problem_key=key, error=error))
                    continue
                if canonical_key == key:
                    continue
                attach_canonical_alias(rows, key, canonical_key)
                aliases += 1
    with atomic_text_output(args.output, exclusive=True) as out:
        for row in rows.values():
            if args.record_replay_timings:
                for candidate in row['possible']:
                    if candidate.get('attempts', 0) and 'best_elapsed_ms' in candidate:
                        candidate['replay_elapsed_ms'] = candidate['best_elapsed_ms']
            print(json.dumps(row), file=out)
    # The check manifest is a completion marker, never a signal to read an
    # oracle that is still being written.
    with atomic_text_output(args.output.with_suffix('.checks.json'), exclusive=True) as out:
        json.dump(dict(roots=checks, omitted=dict(omitted), canonical_aliases=aliases,
                       canonical_failures=canonical_failures), out)
    print(json.dumps(dict(roots=len(roots), states=len(rows), omitted=dict(omitted),
                          independent_event_certification_credit=0)))


if __name__ == '__main__':
    main()
