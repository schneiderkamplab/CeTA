#!/usr/bin/env python3
"""CPU-only OpenAI-compatible server for local HF causal LM exports."""

from __future__ import annotations

import argparse
import os
from pathlib import Path
from typing import Any

os.environ["CUDA_VISIBLE_DEVICES"] = ""

import torch
import uvicorn
from fastapi import FastAPI
from pydantic import BaseModel
from transformers import AutoModelForCausalLM, AutoTokenizer


class CompletionRequest(BaseModel):
    model: str
    prompt: str
    max_tokens: int = 256
    temperature: float = 0.0
    top_k: int | None = None
    top_p: float | None = None
    stop: list[str] | None = None


class ChatMessage(BaseModel):
    role: str
    content: str


class ChatCompletionRequest(BaseModel):
    model: str
    messages: list[ChatMessage]
    max_tokens: int = 256
    temperature: float = 0.0


def dtype_from_name(name: str) -> torch.dtype:
    return {
        "float32": torch.float32,
        "bfloat16": torch.bfloat16,
        "float16": torch.float16,
    }.get(name, torch.float32)


def completion_text(
    model,
    tokenizer,
    prompt: str,
    max_tokens: int,
    temperature: float,
    top_k: int | None,
    top_p: float | None,
    stop: list[str] | None,
) -> str:
    encoded = tokenizer(prompt, return_tensors="pt", add_special_tokens=False)
    prompt_ids = encoded["input_ids"][0].tolist()
    generated: list[int] = []
    eos_id = tokenizer.convert_tokens_to_ids("[EOS]")
    pad_id = tokenizer.pad_token_id
    if pad_id is None:
        pad_id = 0
    if eos_id is None:
        eos_id = tokenizer.eos_token_id
    tokenizer_vocab_size = len(tokenizer)
    for _ in range(max_tokens):
        ids = prompt_ids + generated
        input_ids = torch.tensor([ids], dtype=torch.long)
        token_type_ids = torch.tensor([[1] * len(prompt_ids) + [0] * len(generated)], dtype=torch.long)
        attention_mask = torch.ones_like(input_ids)
        with torch.inference_mode():
            logits = model(
                input_ids=input_ids,
                attention_mask=attention_mask,
                token_type_ids=token_type_ids,
            ).logits[0, -1].to(torch.float32)
        logits = logits.detach().clone()
        if tokenizer_vocab_size < logits.shape[-1]:
            logits[tokenizer_vocab_size:] = -torch.inf
        if temperature and temperature > 0.0:
            logits = logits / temperature
            if top_k is not None and top_k > 0 and top_k < logits.shape[-1]:
                keep = torch.topk(logits, top_k).indices
                masked = torch.full_like(logits, -torch.inf)
                masked[keep] = logits[keep]
                logits = masked
            if top_p is not None and 0.0 < top_p < 1.0:
                sorted_logits, sorted_indices = torch.sort(logits, descending=True)
                probs = torch.softmax(sorted_logits, dim=-1)
                cumulative = torch.cumsum(probs, dim=-1)
                remove = cumulative > top_p
                remove[1:] = remove[:-1].clone()
                remove[0] = False
                sorted_logits[remove] = -torch.inf
                logits = torch.full_like(logits, -torch.inf).scatter(0, sorted_indices, sorted_logits)
            next_id = int(torch.multinomial(torch.softmax(logits, dim=-1), num_samples=1).item())
        else:
            next_id = int(torch.argmax(logits).item())
        if next_id == eos_id:
            break
        generated.append(next_id)
    text = tokenizer.decode(generated, skip_special_tokens=True).strip()
    for marker in stop or []:
        index = text.find(marker)
        if index >= 0:
            text = text[:index]
    return text


def create_app(model_dir: Path, dtype: torch.dtype) -> FastAPI:
    tokenizer = AutoTokenizer.from_pretrained(model_dir, use_fast=True, trust_remote_code=True)
    model = AutoModelForCausalLM.from_pretrained(model_dir, torch_dtype=dtype, trust_remote_code=True).to("cpu").eval()
    model_id = str(model_dir)
    app = FastAPI()

    @app.get("/v1/models")
    def models() -> dict[str, object]:
        return {
            "object": "list",
            "data": [{"id": model_id, "object": "model", "owned_by": "ferrum"}],
        }

    @app.post("/v1/completions")
    def completions(request: CompletionRequest) -> dict[str, object]:
        text = completion_text(
            model,
            tokenizer,
            request.prompt,
            request.max_tokens,
            request.temperature,
            request.top_k,
            request.top_p,
            request.stop,
        )
        return {
            "id": "ferrum-transformers-cpu",
            "object": "text_completion",
            "model": model_id,
            "choices": [{"index": 0, "text": text, "finish_reason": "stop"}],
        }

    @app.post("/v1/chat/completions")
    def chat_completions(request: ChatCompletionRequest) -> dict[str, object]:
        prompt = "\n".join(message.content for message in request.messages)
        text = completion_text(
            model,
            tokenizer,
            prompt,
            request.max_tokens,
            request.temperature,
            None,
            None,
            None,
        )
        return {
            "id": "ferrum-transformers-cpu-chat",
            "object": "chat.completion",
            "model": model_id,
            "choices": [
                {
                    "index": 0,
                    "message": {"role": "assistant", "content": text},
                    "finish_reason": "stop",
                }
            ],
        }

    return app


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--model-dir", type=Path, required=True)
    parser.add_argument("--host", default="127.0.0.1")
    parser.add_argument("--port", type=int, required=True)
    parser.add_argument("--dtype", default="float32")
    args = parser.parse_args()
    torch.set_num_threads(int(os.environ.get("OMP_NUM_THREADS", "1")))
    app = create_app(args.model_dir, dtype_from_name(args.dtype))
    uvicorn.run(app, host=args.host, port=args.port, log_level="warning")


if __name__ == "__main__":
    main()
