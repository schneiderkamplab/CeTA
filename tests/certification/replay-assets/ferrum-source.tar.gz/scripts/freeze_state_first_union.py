#!/usr/bin/env python3
"""Freeze and deterministically recheck certified state-first campaign proofs."""

from __future__ import annotations

import argparse
import concurrent.futures
import hashlib
import json
import os
import shutil
import sqlite3
import subprocess
import time
from pathlib import Path


def digest(path: Path) -> str:
    value = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            value.update(chunk)
    return value.hexdigest()


def check(path: Path, ceta: Path, timeout: float) -> dict:
    results = []
    for _ in range(2):
        started = time.monotonic()
        try:
            completed = subprocess.run(
                [str(ceta), str(path)],
                text=True,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                timeout=timeout,
            )
            results.append(
                {
                    "return_code": completed.returncode,
                    "elapsed_ms": int((time.monotonic() - started) * 1000),
                    "stdout": completed.stdout,
                    "stderr": completed.stderr,
                    "certified": completed.returncode == 0
                    and "CERTIFIED" in completed.stdout.upper(),
                }
            )
        except subprocess.TimeoutExpired as error:
            results.append(
                {
                    "return_code": None,
                    "elapsed_ms": int((time.monotonic() - started) * 1000),
                    "stdout": error.stdout or "",
                    "stderr": error.stderr or "",
                    "certified": False,
                }
            )
    return {
        "proof_path": str(path),
        "proof_sha256": digest(path),
        "checks": results,
        "deterministic_certified": all(row["certified"] for row in results),
    }


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--campaign-sqlite", type=Path, action="append", required=True)
    parser.add_argument("--ceta", type=Path, required=True)
    parser.add_argument("--output-dir", type=Path, required=True)
    parser.add_argument("--jobs", type=int, default=16)
    parser.add_argument("--timeout", type=float, default=60.0)
    args = parser.parse_args()

    origins: dict[str, list[dict]] = {}
    paths: dict[str, Path] = {}
    for database in args.campaign_sqlite:
        with sqlite3.connect(database) as connection:
            rows = connection.execute(
                """
                SELECT raw_hash, task_key, processor_atom, proof_path,
                       implementation_hash
                FROM terminal_proofs
                WHERE certification_status='certified-full'
                UNION ALL
                SELECT raw_hash, transition_task_key, 'assembled', proof_path,
                       implementation_hash
                FROM assembled_proofs
                WHERE checker_result='CERTIFIED' AND deterministic_recheck=1
                """
            )
            for raw_hash, task_key, atom, raw_path, implementation in rows:
                path = Path(raw_path)
                if not path.exists():
                    continue
                proof_hash = digest(path)
                paths[proof_hash] = path
                origins.setdefault(proof_hash, []).append(
                    {
                        "campaign_sqlite": str(database),
                        "raw_hash": raw_hash,
                        "task_key": task_key,
                        "processor_atom": atom,
                        "implementation_hash": implementation,
                    }
                )

    args.output_dir.mkdir(parents=True, exist_ok=True)
    checked = []
    with concurrent.futures.ThreadPoolExecutor(max_workers=args.jobs) as executor:
        futures = [executor.submit(check, path, args.ceta, args.timeout) for path in paths.values()]
        for future in concurrent.futures.as_completed(futures):
            checked.append(future.result())

    with (args.output_dir / "manifest.jsonl").open("w", encoding="utf-8") as stream:
        for row in sorted(checked, key=lambda item: item["proof_sha256"]):
            row["origins"] = origins[row["proof_sha256"]]
            if row["deterministic_certified"]:
                retained = (
                    args.output_dir
                    / "artifacts"
                    / row["proof_sha256"][:2]
                    / row["proof_sha256"]
                    / "proof.cpf.xml"
                )
                retained.parent.mkdir(parents=True, exist_ok=True)
                if not retained.exists():
                    try:
                        os.link(row["proof_path"], retained)
                    except OSError:
                        shutil.copy2(row["proof_path"], retained)
                row["retained_proof_path"] = str(retained)
            stream.write(json.dumps(row, sort_keys=True) + "\n")
    summary = {
        "schema": "ferrum.state-first-certified-union.v1",
        "evidence_rows": sum(len(rows) for rows in origins.values()),
        "unique_proofs": len(checked),
        "deterministic_certified": sum(row["deterministic_certified"] for row in checked),
        "rejected": sum(not row["deterministic_certified"] for row in checked),
        "campaign_sqlite": [str(path) for path in args.campaign_sqlite],
    }
    (args.output_dir / "summary.json").write_text(
        json.dumps(summary, indent=2, sort_keys=True) + "\n"
    )
    print(json.dumps(summary, sort_keys=True))
    return int(summary["rejected"] != 0)


if __name__ == "__main__":
    raise SystemExit(main())
