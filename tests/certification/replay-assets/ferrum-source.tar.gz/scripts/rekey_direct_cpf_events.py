#!/usr/bin/env python3
"""Copy diagnostic events using native serialized-state addresses, without reprobes."""
import argparse
import hashlib
import json
from pathlib import Path


def native_key(cpf):
    return hashlib.sha256(cpf.strip().encode()).hexdigest()


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--root', type=Path, required=True)
    p.add_argument('--output', type=Path, required=True)
    args = p.parse_args()
    args.output.mkdir(parents=True, exist_ok=False)
    count = 0
    skipped_native = 0
    with (args.output / 'processor-events.jsonl').open('x') as output:
        for path in sorted(args.root.rglob('processor-events.jsonl')):
            for line in path.read_text().splitlines():
                event = json.loads(line)
                if event.get('credit', {}).get('status') != 'diagnostic-only':
                    # A failed native probe may leave its own trace. It was
                    # not synthesized by this diagnostic exporter; do not
                    # rewrite or import it through this conversion.
                    skipped_native += 1
                    continue
                states = [event['input']] + event.get('witness', {}).get('residuals', [])
                for state in states:
                    state['problem_key'] = native_key(state['cpf'])
                print(json.dumps(event), file=output)
                count += 1
    print(json.dumps({'events': count, 'skipped_native_records': skipped_native}))


if __name__ == '__main__':
    main()
