#!/usr/bin/env python3
"""Intern applied atomic witnesses on their exact runtime-state keys.

This is deliberately narrower than proof-fragment extraction.  It consumes a
processor-event log, retains only successful applications of one requested
atomic family, and writes a utility-guidance overlay. In the default mode the
caller must already have checked the complete proof twice. The explicit weak
mode is for an open campaign frontier: it never claims that an atom or root is
certified. No canonical or semantic aliases are invented: every row is keyed
by the exact input hash recorded at runtime.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import re
from pathlib import Path


WITNESS_SCHEMA = "ferrum.utility-guidance.witness.v1"
GUIDANCE_SCHEMA = "ferrum.utility-guidance.v2"


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--events",
        type=Path,
        action="append",
        help="processor-event log; repeat to build one certified union",
    )
    parser.add_argument(
        "--certified-details",
        type=Path,
        help="also consume processor-events.jsonl for every certified details row",
    )
    parser.add_argument("--atom-prefix", required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--modular-only", action="store_true",
                        help="omit compound strategy wrappers and retain state-local atoms only")
    parser.add_argument(
        "--certified-key-alias",
        action="append",
        default=[],
        metavar="SOURCE=TARGET",
        help=(
            "also bind SOURCE's certified atom to TARGET; repeat for explicitly "
            "validated runtime-state migrations"
        ),
    )
    parser.add_argument(
        "--status",
        choices=("certified", "transformed_weak"),
        default="certified",
        help=(
            "use certified outcome-derived statuses, or retain successful "
            "applications only as open-frontier weak guidance"
        ),
    )
    parser.add_argument(
        "--on-conflict",
        choices=("error", "first", "last"),
        default="error",
        help="how to handle multiple successful atoms for one runtime key",
    )
    args = parser.parse_args()

    key_aliases: dict[str, list[str]] = {}
    for specification in args.certified_key_alias:
        source, separator, target = specification.partition("=")
        if not separator or not source or not target:
            parser.error("--certified-key-alias must have the form SOURCE=TARGET")
        targets = key_aliases.setdefault(source, [])
        if target not in targets:
            targets.append(target)

    events_paths = list(args.events or [])
    if args.certified_details:
        details = json.loads(args.certified_details.read_text(encoding="utf-8"))
        events_paths.extend(
            Path(row["artifact_dir"]) / "processor-events.jsonl"
            for row in details
            if row.get("certified")
        )
    if not events_paths:
        parser.error("at least one --events or --certified-details input is required")

    by_key: dict[str, tuple[str, str]] = {}
    for events_path in events_paths:
        with events_path.open(encoding="utf-8") as source:
            for line_number, line in enumerate(source, start=1):
                try:
                    event = json.loads(line)
                except json.JSONDecodeError as error:
                    raise SystemExit(
                        f"invalid JSON in {events_path} on line {line_number}: {error}"
                    )
                atom = event.get("processor")
                key = (event.get("input") or {}).get("problem_key")
                outcome = event.get("outcome")
                if (
                    not isinstance(atom, str)
                    or not atom.startswith(args.atom_prefix)
                    or not isinstance(key, str)
                    or outcome not in {"solved", "transformed"}
                ):
                    continue
                if args.modular_only and not re.fullmatch(r"[a-z][a-z0-9-]*(?:\([^();]*\))?", atom):
                    continue
                status = (
                    "transformed_weak"
                    if args.status == "transformed_weak"
                    else ("solved" if outcome == "solved" else "transformed_strong")
                )
                previous = by_key.get(key)
                if previous is None or args.on_conflict == "last":
                    by_key[key] = (atom, status)
                elif previous != (atom, status) and args.on_conflict == "error":
                    raise SystemExit(
                        f"conflicting successful atoms for runtime key {key}"
                    )

    for source, targets in key_aliases.items():
        source_atom = by_key.get(source)
        if source_atom is None:
            raise SystemExit(
                f"certified key alias source has no successful matching atom: {source}"
            )
        for target in targets:
            previous = by_key.get(target)
            if previous is None or args.on_conflict == "last":
                by_key[target] = source_atom
            elif previous != source_atom and args.on_conflict == "error":
                raise SystemExit(
                    f"certified key alias conflicts with runtime key {target}"
                )

    if not by_key:
        raise SystemExit(f"no successful {args.atom_prefix!r} events found")
    witnesses = {
        hashlib.sha256(atom.encode()).hexdigest(): atom
        for atom, _status in by_key.values()
        if atom.startswith("exact-")
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with args.output.open("w", encoding="utf-8") as output:
        for witness_id, atom in sorted(witnesses.items()):
            print(
                json.dumps(
                    {
                        "schema": WITNESS_SCHEMA,
                        "witness_id": witness_id,
                        "candidate": atom,
                    },
                    separators=(",", ":"),
                    sort_keys=True,
                ),
                file=output,
            )
        for key, (atom, status) in sorted(by_key.items()):
            candidate = (
                {"candidate_ref": hashlib.sha256(atom.encode()).hexdigest()}
                if atom.startswith("exact-")
                else {"candidate": atom}
            )
            print(
                json.dumps(
                    {
                        "schema": GUIDANCE_SCHEMA,
                        "problem_key": key,
                        ("possible" if status == "transformed_weak" else "prefer"): [
                            {
                                **candidate,
                                "status": status,
                                "utility_score": 2000.0,
                                "best_elapsed_ms": 0,
                                "attempts": 1,
                                "solved_count": int(status == "solved"),
                                "transformed_count": int(status == "transformed_strong"),
                                "failed_count": 0,
                                "timeout_count": 0,
                                "certified_count": int(args.status == "certified"),
                            }
                        ],
                        ("prefer" if status == "transformed_weak" else "possible"): [],
                        "avoid": [],
                        "timeout": [],
                    },
                    separators=(",", ":"),
                    sort_keys=True,
                ),
                file=output,
            )
    print(
        json.dumps(
            {
                "events": [str(path) for path in events_paths],
                "output": str(args.output),
                "runtime_keys": len(by_key),
                "witnesses": len(witnesses),
                "certified_key_aliases": sum(len(v) for v in key_aliases.values()),
            },
            sort_keys=True,
        )
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
