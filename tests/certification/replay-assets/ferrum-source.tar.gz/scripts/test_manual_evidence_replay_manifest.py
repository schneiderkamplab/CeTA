#!/usr/bin/env python3

from pathlib import Path
import tempfile
import unittest

from build_manual_evidence_replay_manifest import (
    registered_evidence,
    registered_problems,
    resolve_problem,
)


class ManualEvidenceReplayManifestTest(unittest.TestCase):
    def test_reads_only_registry_problem_rows(self) -> None:
        self.assertEqual(
            registered_problems(
                "| Problem | Evidence |\n"
                "|---|---|\n"
                "| `TRS_Standard/A/x.ari` | proof |\n"
            ),
            ["TRS_Standard/A/x.ari"],
        )

    def test_duplicate_documentation_rows_form_one_root_with_merged_evidence(self) -> None:
        text = (
            "| `TRS_Standard/A/x.ari` | first: `target/one/proof.xml` | certified |\n"
            "| `TRS_Standard/A/x.ari` | second: `target/two/proof.xml`; "
            "again: `target/one/proof.xml` | certified |\n"
        )
        self.assertEqual(registered_problems(text), ["TRS_Standard/A/x.ari"])
        self.assertEqual(
            registered_evidence(text),
            {
                "TRS_Standard/A/x.ari": [
                    "target/one/proof.xml",
                    "target/two/proof.xml",
                ]
            },
        )

    def test_unique_category_search_recovers_omitted_subdirectory(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            tpdb = Path(directory)
            target = tpdb / "TRS_Contextsensitive" / "CSR_04" / "x.ari"
            target.parent.mkdir(parents=True)
            target.touch()
            self.assertEqual(
                resolve_problem(tpdb, "TRS_Contextsensitive/x.ari"),
                target.resolve(),
            )

    def test_records_only_artifact_locations_from_evidence_cell(self) -> None:
        text = (
            "| `TRS_Standard/A/x.ari` | producing: `target/run/proof.xml`; "
            "shape: `dp(graph)`; old: `/tmp/x.cpf` | certified |\n"
        )
        self.assertEqual(
            registered_evidence(text),
            {
                "TRS_Standard/A/x.ari": [
                    "target/run/proof.xml",
                    "/tmp/x.cpf",
                ]
            },
        )


if __name__ == "__main__":
    unittest.main()
