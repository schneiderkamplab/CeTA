#!/usr/bin/env python3
"""Bounded, artifact-isolated extract/merge/replay waves; never enables fallback."""
import argparse
import concurrent.futures
import json
import os
from pathlib import Path
import subprocess
import sys


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--campaign', type=Path, required=True)
    p.add_argument('--baseline', type=Path, required=True)
    p.add_argument('--oracle', type=Path, required=True)
    p.add_argument('--previous-run', type=Path, required=True)
    p.add_argument('--first-wave', type=int, required=True)
    p.add_argument('--rounds', type=int, default=3)
    p.add_argument('--ferrum', type=Path, required=True)
    p.add_argument('--ceta', type=Path, required=True)
    p.add_argument('--tpdb', type=Path, required=True)
    args = p.parse_args()
    env = dict(os.environ, FERRUM_DP_LLM_NO_FALLBACK='1', RAYON_NUM_THREADS='2', PYTHONPATH='scripts')

    def run(command, log):
        with log.open('x') as stream:
            subprocess.run(command, env=env, stdout=stream, stderr=subprocess.STDOUT, check=True)

    previous, oracle = args.previous_run, args.oracle
    for wave in range(args.first_wave, args.first_wave + args.rounds):
        # Linux MemAvailable includes reclaimable page cache. Do not confuse
        # cached evidence files with non-reclaimable memory pressure.
        memory = {line.split(':')[0]: int(line.split()[1]) for line in Path('/proc/meminfo').read_text().splitlines()}
        if memory['MemTotal'] - memory['MemAvailable'] > 2 * 1024**3:
            raise RuntimeError('Non-reclaimable memory pressure exceeds 2 TiB; no new wave launched')
        comparison = previous / 'comparison.json'
        if not comparison.exists():
            run([sys.executable, 'scripts/report_complete_proof_ablation.py', '--baseline', str(args.baseline), '--run', str(previous)], comparison)
        shards = args.campaign / f'shards-v{wave}'
        run([sys.executable, 'scripts/extract_modular_recovery_shards.py', '--baseline', str(args.baseline), '--ablation', str(previous), '--output', str(shards), '--ferrum', str(args.ferrum), '--ceta', str(args.ceta), '--jobs', '12', '--extraction-timeout', '120'], args.campaign / f'shards-v{wave}.log')
        overlay = args.campaign / f'overlay-v{wave}.jsonl'
        run([sys.executable, 'scripts/build_modular_proof_overlay.py', '--shards', str(shards), '--output', str(overlay)], args.campaign / f'overlay-v{wave}.log')
        next_oracle = args.campaign / f'oracle-shards-v{wave}.jsonl'
        run([sys.executable, 'scripts/merge_monotone_oracle_records.py', '--base', str(oracle), '--incoming', str(overlay), '--output', str(next_oracle), '--report', str(args.campaign / f'merge-v{wave}.json')], args.campaign / f'merge-v{wave}.log')
        replay = args.campaign / f'replay-v{wave}'
        if replay.exists():
            raise RuntimeError(f'Refusing to overwrite {replay}')

        def replay_category(category, directory, jobs):
            command = [sys.executable, 'scripts/termcomp_trs_compare.py', '--tpdb', str(args.tpdb), '--ferrum', str(args.ferrum), '--ceta', str(args.ceta), '--jobs', str(jobs), '--timeout', '185', '--category', category, '--file-list', str(args.campaign / 'losses.txt'), '--output', str(replay / directory / 'summary.md'), '--details-output', str(replay / directory / 'details.json'), '--run-dir', str(replay / directory / 'run'), '--progress-interval', '10', '--extra-arg=--strategy', '--extra-arg=timeout(180s, fail)', '--extra-arg=--utility-guidance-manifest', '--extra-arg=' + str(next_oracle), '--extra-arg=--no-top-level-llm']
            run(command, args.campaign / f'replay-v{wave}-{directory}.log')
            rows = json.loads((replay / directory / 'details.json').read_text())
            return directory, sum(bool(r.get('certified')) for r in rows)
        with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:
            futures = [pool.submit(replay_category, *task) for task in [('TRS_Standard', 'standard', 32), ('TRS_Innermost', 'innermost', 4), ('TRS_Contextsensitive', 'csr', 1)]]
            totals = dict(f.result() for f in futures)
        print(json.dumps({'wave': wave, 'recovered': totals, 'oracle': str(next_oracle)}), flush=True)
        previous, oracle = replay, next_oracle


if __name__ == '__main__':
    main()
