import unittest
from merge_disjoint_replay_details import merge


class MergeReplayTests(unittest.TestCase):
    def test_keeps_failed_decisions_and_exact_coverage(self):
        rows = [dict(category='CSR', path='a', certified=True),
                dict(category='TRS', path='b', certified=False)]
        self.assertEqual(merge([[rows[1]], [rows[0]]], rows), rows)

    def test_rejects_duplicate_roots(self):
        row = dict(category='CSR', path='a', certified=True)
        with self.assertRaisesRegex(ValueError, 'duplicate'):
            merge([[row], [row]], [row])

    def test_rejects_missing_roots(self):
        with self.assertRaisesRegex(ValueError, 'coverage mismatch'):
            merge([], [dict(category='CSR', path='a')])


if __name__ == '__main__':
    unittest.main()
