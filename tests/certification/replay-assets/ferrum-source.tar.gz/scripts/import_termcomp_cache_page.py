#!/usr/bin/env python3
"""Index YES/NO proof links from old TermCOMP cache result pages."""

from __future__ import annotations

import argparse
import json
import sqlite3
import time
from pathlib import Path

from collect_termcomp_proofs import (
    RESULTS_OF_INTEREST,
    benchmark_from_url,
    cell_result,
    cell_times,
    clean_tool_name,
    error_href,
    fetch_text,
    first_link,
    init_db,
    parse_category_table,
    proof_href,
)


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--out", type=Path, default=Path("target/termcomp-proof-corpus"))
    parser.add_argument("--year", type=int, required=True)
    parser.add_argument("--category", required=True)
    parser.add_argument("--url", required=True)
    parser.add_argument("--certified", action="store_true")
    args = parser.parse_args()

    text = fetch_text(args.url)
    headers, rows = parse_category_table(text)
    if not headers and rows:
        headers = [cell["text"] for cell in rows[0]]
        rows = rows[1:]

    db_path = args.out / "proofs.sqlite"
    conn = init_db(db_path)
    inserted = 0
    for row in rows:
        if not row:
            continue
        benchmark_link = first_link(row[0])
        if benchmark_link is None:
            continue
        benchmark = benchmark_from_url(benchmark_link["href"], benchmark_link["text"])
        for column_index, cell in enumerate(row[1:], start=1):
            result = cell_result(cell)
            if result not in RESULTS_OF_INTEREST:
                continue
            proof_url = proof_href(cell)
            if proof_url is None or "/pairs//stdout/" in proof_url:
                continue
            tool = clean_tool_name(headers[column_index]) if column_index < len(headers) else f"col{column_index}"
            runtime, cert_runtime = cell_times(cell)
            certification = "certified" if args.certified else "uncertified"
            before = conn.total_changes
            conn.execute(
                """
                insert or ignore into proofs (
                    year, category, benchmark, tool, tool_column, result, certification,
                    proof_url, error_url, benchmark_url, runtime_seconds, cert_runtime_seconds,
                    local_path, sha256, bytes, first_line, detected_format, extracted_json,
                    download_error, downloaded_at
                ) values (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    args.year,
                    args.category,
                    benchmark,
                    tool,
                    column_index,
                    result,
                    certification,
                    proof_url,
                    error_href(cell),
                    benchmark_link["href"],
                    runtime,
                    cert_runtime,
                    "",
                    "",
                    0,
                    "",
                    "not-downloaded",
                    json.dumps({"source_cache_page": args.url}, sort_keys=True),
                    "not downloaded; cache-page index-only record",
                    time.time(),
                ),
            )
            inserted += conn.total_changes - before
    conn.commit()
    print(json.dumps({"indexed": inserted, "url": args.url}, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
