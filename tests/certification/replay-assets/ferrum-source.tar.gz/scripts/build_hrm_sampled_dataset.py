#!/usr/bin/env python3
"""Build an HRM-Text sampled dataset from Ferrum HRM direct JSONL rows."""

from __future__ import annotations

import argparse
import gzip
import json
from pathlib import Path
from typing import Iterator

import numpy as np
from tokenizers import Tokenizer


def open_text(path: Path):
    return gzip.open(path, "rt", encoding="utf-8") if path.suffix == ".gz" else path.open("r", encoding="utf-8")


def iter_rows(path: Path, limit: int | None) -> Iterator[dict[str, str]]:
    seen = 0
    with open_text(path) as source:
        for line in source:
            row = json.loads(line)
            if isinstance(row.get("instruction"), str) and isinstance(row.get("response"), str):
                yield row
                seen += 1
                if limit is not None and seen >= limit:
                    return


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--input", type=Path, required=True)
    parser.add_argument("--tokenizer", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--epochs", type=int, default=1)
    parser.add_argument("--max-seq-tokens", type=int, default=4096)
    parser.add_argument("--limit", type=int)
    parser.add_argument("--seed", type=int, default=0)
    parser.add_argument("--progress-interval", type=int, default=10000)
    args = parser.parse_args()

    if args.epochs < 1:
        raise SystemExit("--epochs must be >= 1")
    if args.max_seq_tokens < 4:
        raise SystemExit("--max-seq-tokens must be >= 4")

    tokenizer = Tokenizer.from_file(str(args.tokenizer))
    bos_id = tokenizer.token_to_id("[BOS]")
    eos_id = tokenizer.token_to_id("[EOS]")
    sep_id = tokenizer.token_to_id("[SEP]")
    unk_id = tokenizer.token_to_id("[UNK]")
    if None in (bos_id, eos_id, sep_id, unk_id):
        raise SystemExit("tokenizer must define [BOS], [EOS], [SEP], and [UNK]")
    vocab_size = tokenizer.get_vocab_size(with_added_tokens=True)

    args.output.mkdir(parents=True, exist_ok=True)
    tokens: list[int] = []
    inst_start: list[int] = []
    inst_len: list[int] = []
    resp_start: list[int] = []
    resp_len: list[int] = []
    seen = kept = skipped_too_long = skipped_unk = 0
    max_row_len = 0
    total_length = 0

    for row in iter_rows(args.input, args.limit):
        seen += 1
        inst = [bos_id] + tokenizer.encode(row["instruction"]).ids + [sep_id]
        resp = tokenizer.encode(row["response"]).ids + [eos_id]
        row_len = len(inst) + len(resp)
        if row_len > args.max_seq_tokens:
            skipped_too_long += 1
            continue
        if unk_id in inst or unk_id in resp:
            skipped_unk += 1
            continue
        inst_start.append(len(tokens))
        inst_len.append(len(inst))
        tokens.extend(inst)
        resp_start.append(len(tokens))
        resp_len.append(len(resp))
        tokens.extend(resp)
        kept += 1
        max_row_len = max(max_row_len, row_len)
        total_length += row_len - 1
        if args.progress_interval > 0 and seen % args.progress_interval == 0:
            print(json.dumps({"seen": seen, "kept": kept, "skipped_too_long": skipped_too_long, "skipped_unk": skipped_unk}), flush=True)

    if kept == 0:
        raise SystemExit("no rows kept")

    token_dtype = np.uint16 if vocab_size <= np.iinfo(np.uint16).max else np.uint32
    np.save(args.output / "tokens.npy", np.asarray(tokens, dtype=token_dtype))
    inst_start_arr = np.asarray(inst_start, dtype=np.uint64)
    inst_len_arr = np.asarray(inst_len, dtype=np.uint32)
    resp_start_arr = np.asarray(resp_start, dtype=np.uint64)
    resp_len_arr = np.asarray(resp_len, dtype=np.uint32)

    rng = np.random.default_rng(args.seed)
    for epoch in range(args.epochs):
        order = rng.permutation(kept)
        epoch_dir = args.output / f"epoch_{epoch}"
        epoch_dir.mkdir(exist_ok=True)
        np.save(epoch_dir / "inst_start.npy", inst_start_arr[order])
        np.save(epoch_dir / "inst_len.npy", inst_len_arr[order])
        np.save(epoch_dir / "resp_start.npy", resp_start_arr[order])
        np.save(epoch_dir / "resp_len.npy", resp_len_arr[order])

    metadata = {
        "tokenizer_info": {
            "vocab_size": vocab_size,
            "tokenizer_path": str(args.tokenizer.parent.resolve()),
            "bos": "[BOS]",
            "eos": "[EOS]",
            "sep": "[SEP]",
            "pad": "[PAD]",
            "unk": "[UNK]",
            "condition_mapping": {"direct": ""},
        },
        "vocab_size": None,
        "max_seq_len": int(max_row_len + 1),
        "total_length": int(total_length),
        "source": str(args.input),
        "rows_seen": seen,
        "rows_kept": kept,
        "skipped_too_long": skipped_too_long,
        "skipped_unk": skipped_unk,
        "max_seq_tokens_cap": args.max_seq_tokens,
        "epochs": args.epochs,
    }
    (args.output / "metadata.json").write_text(json.dumps(metadata, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    print(json.dumps(metadata, indent=2, sort_keys=True), flush=True)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
