#!/usr/bin/env python3
"""Build HRM direct SFT rows from Ferrum processor-event logs.

Each output row maps one current CPF subproblem to a status-grouped list of
strategy atoms:

    {
      "condition": "direct",
      "instruction": "<input>...CPF...</input>",
      "response": "solved:\\npoly(...)\\n\\nfailed:\\nsubterm"
    }

The script groups raw event rows by ``sha256(input.cpf)`` and deduplicates
candidate attempts by normalized strategy atom. Negative attempts are retained
inside the status map. Rows without any positive candidate are included by
default, so unsolved subproblems still contribute avoid/failure evidence.
"""

from __future__ import annotations

import argparse
import ast
import gzip
import hashlib
import json
import re
import sqlite3
import sys
import time
from collections import Counter
from pathlib import Path
from typing import Any


STATUS_ORDER = ["solved", "transformed_strong", "transformed_weak", "failed", "timeout"]
STATUS_RANK = {name: len(STATUS_ORDER) - i for i, name in enumerate(STATUS_ORDER)}
POSITIVE_STATUSES = {"solved", "transformed_strong", "transformed_weak"}


def compact_xml_for_key(xml: str) -> str:
    """Canonicalize formatting-only XML differences for runtime lookup keys."""
    compact = re.sub(r">\s+<", "><", xml.strip())
    return re.sub(r"\s+/>", "/>", compact)


def open_text(path: Path):
    return gzip.open(path, "rt", encoding="utf-8") if path.suffix == ".gz" else path.open("r", encoding="utf-8")


def open_output(path: Path):
    path.parent.mkdir(parents=True, exist_ok=True)
    return gzip.open(path, "wt", encoding="utf-8") if path.suffix == ".gz" else path.open("w", encoding="utf-8")


def split_for_id(identifier: str, validation_pct: int, test_pct: int) -> str:
    bucket = int(hashlib.sha256(identifier.encode()).hexdigest()[:8], 16) % 10_000
    test_cutoff = test_pct * 100
    validation_cutoff = test_cutoff + validation_pct * 100
    if bucket < test_cutoff:
        return "test"
    if bucket < validation_cutoff:
        return "validation"
    return "train"


def wrap_input(cpf: str) -> str:
    cpf = cpf.strip()
    return f"<input>\n{cpf}\n</input>"


def parse_bool_none(value: str) -> str | None:
    if value == "None":
        return None
    return value


def parse_fields(atom: str) -> dict[str, str]:
    match = re.search(r"\{(.*)\}", atom)
    if not match:
        return {}
    fields: dict[str, str] = {}
    for part in match.group(1).split(","):
        if ":" not in part:
            continue
        key, value = part.split(":", 1)
        fields[key.strip()] = value.strip()
    return fields


def maybe_int(value: str | None) -> int | None:
    if value is None:
        return None
    value = parse_bool_none(value)
    if value is None:
        return None
    some_match = re.fullmatch(r"Some\((-?\d+)\)", value)
    if some_match:
        return int(some_match.group(1))
    try:
        return int(value)
    except ValueError:
        return None


def args_suffix(parts: list[tuple[str, Any]]) -> str:
    kept = [(name, value) for name, value in parts if value is not None]
    if not kept:
        return ""
    return "(" + ",".join(f"{name}={value}" for name, value in kept) + ")"


def split_debug_list(value: str) -> list[str] | None:
    """Split a Rust debug list without splitting nested processor arguments."""
    parts: list[str] = []
    start = 0
    depth = 0
    for index, character in enumerate(value):
        if character in "([{":
            depth += 1
        elif character in ")]}":
            depth -= 1
            if depth < 0:
                return None
        elif character == "," and depth == 0:
            parts.append(value[start:index].strip())
            start = index + 1
    if depth != 0:
        return None
    parts.append(value[start:].strip())
    return parts if all(parts) else None


def normalize_dp_debug_strategy(value: str) -> str | None:
    processor = re.fullmatch(r"Processor\((.+)\)", value)
    if processor is not None:
        return normalize_atom(processor.group(1))
    sequence = re.fullmatch(r"Sequence\(\[(.*)\]\)", value)
    if sequence is not None:
        parts = split_debug_list(sequence.group(1))
        if parts is None:
            return None
        normalized = [normalize_dp_debug_strategy(part) for part in parts]
        if any(part is None for part in normalized):
            return None
        return ";".join(part for part in normalized if part is not None)
    parallel = re.fullmatch(r"Parallel\(\[(.*)\]\)", value)
    if parallel is not None:
        parts = split_debug_list(parallel.group(1))
        if parts is None:
            return None
        normalized = [normalize_dp_debug_strategy(part) for part in parts]
        if any(part is None for part in normalized):
            return None
        return "parallel(" + "|".join(
            part for part in normalized if part is not None
        ) + ")"
    return None


def normalize_atom(atom: Any) -> str | None:
    if not isinstance(atom, str) or not atom.strip():
        return None
    atom = atom.strip()

    # Processor events use Rust's Debug syntax for retained exact models.
    # Its tuple/list/string subset is valid Python literal syntax, so preserve
    # the selected model byte-for-byte in the executable oracle atom instead
    # of degrading it to another synthesis search (which may expose a
    # different residual state).
    for prefix, target in (
        ("ExactLinearPolynomial", "exact-poly"),
        ("ExactWeakPolynomial", "exact-weak-poly"),
        ("ExactMaxPolynomial", "exact-max-poly"),
    ):
        match = re.fullmatch(
            rf"{prefix} \{{ interpretation: (.+) \}}",
            atom,
            re.DOTALL,
        )
        if match is not None:
            try:
                witness = ast.literal_eval(match.group(1))
            except (SyntaxError, ValueError):
                return None
            encoded = json.dumps(
                witness, ensure_ascii=False, separators=(",", ":")
            ).encode("utf-8").hex()
            return f"{target}(hex={encoded})"
    rational = re.fullmatch(
        r"ExactRationalPolynomial \{ denominator: (-?\d+), interpretation: (.+) \}",
        atom,
        re.DOTALL,
    )
    if rational is not None:
        try:
            witness = [int(rational.group(1)), ast.literal_eval(rational.group(2))]
        except (SyntaxError, ValueError):
            return None
        encoded = json.dumps(
            witness, ensure_ascii=False, separators=(",", ":")
        ).encode("utf-8").hex()
        return f"exact-rat-poly(hex={encoded})"

    # Current Ferrum event producers emit executable parser-language atoms.
    # Preserve their internal punctuation and only remove insignificant
    # whitespace.  Sending these through the generic last-resort spelling
    # conversion used to turn `dp(graph; subterm)` into the invalid
    # `dp(graph;-subterm)` and discarded the certified continuation.
    if re.fullmatch(
        r"[a-z][a-z0-9\-();|,=.\s]*",
        atom,
        re.DOTALL,
    ):
        return re.sub(r"\s+", "", atom)
    fields = parse_fields(atom)

    if atom == "DependencyGraph":
        return "graph"
    if atom == "Subterm":
        return "subterm"
    if atom == "SizeChange":
        return "size-change"
    if atom.startswith("PathOrder"):
        return "path-order"
    if atom.startswith("SemanticLabeling"):
        return "semantic-labeling"
    if atom.startswith("Uncurry"):
        return "uncurry"
    if atom.startswith("SwitchInnermost"):
        return "switch-innermost"
    if atom.startswith("CsrInnermostEquivalence"):
        return "csr-innermost"
    if atom == "CsrLoop":
        return "csr-loop"
    if atom.startswith("FastDependencyPairs"):
        return "fast-dp"
    dp_strategy = re.fullmatch(
        r"DependencyPairs\(Some\((.+)\)\)",
        atom,
    )
    if dp_strategy is not None:
        nested = normalize_dp_debug_strategy(dp_strategy.group(1))
        if nested is not None:
            return f"dp({nested})"
    if atom.startswith("DependencyPairs"):
        return "dp"
    if atom.startswith("Rewriting"):
        return "rewrite" + args_suffix([("max-per-pair", maybe_int(fields.get("max_per_pair")))])
    if atom.startswith("SrsWeightedLength"):
        return "srs-weighted-length" + args_suffix([("max-weight", maybe_int(fields.get("max_weight")))])
    if atom.startswith("SrsWeightedRuleRemoval"):
        return "srs-weighted-rule-removal" + args_suffix(
            [("max-weight", maybe_int(fields.get("max_weight")))]
        )
    if atom == "Llm":
        return "llm"
    if atom == "Termination":
        return "termination"
    if atom == "SrsLength":
        return "srs-length"
    if atom.startswith("Nontermination"):
        inner = atom.lower()
        if "srsloop" in inner:
            return "nontermination(srs-loop)"
        if "directloop" in inner:
            return "nontermination(direct-loop)"
        if "variablecondition" in inner:
            return "nontermination(variable-condition)"
        return "nontermination"

    if atom.startswith("LinearPolynomial"):
        return "poly" + args_suffix(
            [
                ("max-constant", maybe_int(fields.get("max_constant"))),
                ("max-coefficient", maybe_int(fields.get("max_coefficient"))),
            ]
        )
    if atom.startswith("MonotonicPolynomial"):
        return "mono-poly" + args_suffix(
            [
                ("max-constant", maybe_int(fields.get("max_constant"))),
                ("max-coefficient", maybe_int(fields.get("max_coefficient"))),
                ("symbols", maybe_int(fields.get("max_symbols"))),
                ("arity", maybe_int(fields.get("max_arity"))),
            ]
        )
    if atom.startswith("QuadraticPolynomial"):
        return "quadratic-poly" + args_suffix(
            [
                ("max-constant", maybe_int(fields.get("max_constant"))),
                ("max-coefficient", maybe_int(fields.get("max_coefficient"))),
            ]
        )
    if atom.startswith("SmtPolynomial") or atom.startswith("SatPolynomial"):
        return "sat-poly" + args_suffix(
            [
                ("max-constant", maybe_int(fields.get("max_constant"))),
                ("max-coefficient", maybe_int(fields.get("max_coefficient"))),
            ]
        )
    if atom.startswith("RationalPolynomial"):
        return "rational-poly" + args_suffix(
            [
                ("max-constant", maybe_int(fields.get("max_constant"))),
                ("max-coefficient", maybe_int(fields.get("max_coefficient"))),
                ("denominator", maybe_int(fields.get("denominator"))),
            ]
        )
    if atom.startswith("WeakPolynomial"):
        return "weak-poly" + args_suffix(
            [
                ("min-constant", maybe_int(fields.get("min_constant"))),
                ("max-constant", maybe_int(fields.get("max_constant"))),
                ("max-coefficient", maybe_int(fields.get("max_coefficient"))),
            ]
        )
    if atom.startswith("MaxPolynomial"):
        return "max-poly" + args_suffix(
            [
                ("max-constant", maybe_int(fields.get("max_constant"))),
                ("max-coefficient", maybe_int(fields.get("max_coefficient"))),
                ("alternatives", maybe_int(fields.get("alternatives"))),
            ]
        )
    if atom.startswith("ArcticMatrixInterpretation"):
        return "arctic-matrix" + args_suffix(
            [
                ("dimension", maybe_int(fields.get("dimension"))),
                ("max-constant", maybe_int(fields.get("max_constant"))),
                ("max-coefficient", maybe_int(fields.get("max_coefficient"))),
            ]
        )
    if atom.startswith("MatrixInterpretation"):
        return "matrix" + args_suffix(
            [
                ("dim", maybe_int(fields.get("dimension"))),
                ("max-constant", maybe_int(fields.get("max_constant"))),
                ("max-coefficient", maybe_int(fields.get("max_coefficient"))),
                ("min-nonzero", maybe_int(fields.get("min_nonzero"))),
                ("max-nonzero", maybe_int(fields.get("max_nonzero"))),
                (
                    "max-nonzero-constants",
                    maybe_int(fields.get("max_nonzero_constants")),
                ),
                (
                    "max-nonzero-per-row",
                    maybe_int(fields.get("max_nonzero_per_row")),
                ),
                ("symbols", maybe_int(fields.get("max_symbols"))),
                ("arity", maybe_int(fields.get("max_arity"))),
            ]
        )
    if atom.startswith("Kbo"):
        symbols = maybe_int(fields.get("max_symbols"))
        if symbols == 18446744073709551615:
            symbols = None
        return "kbo" + args_suffix(
            [
                ("max-weight", maybe_int(fields.get("max_weight"))),
                ("symbols", symbols),
            ]
        )
    if atom.startswith("Narrowing"):
        return "narrow" + args_suffix([("max-per-pair", maybe_int(fields.get("max_per_pair")))])
    if atom.startswith("Instantiation"):
        return "instantiate" + args_suffix([("max-per-pair", maybe_int(fields.get("max_per_pair")))])
    if atom.startswith("ForwardInstantiation"):
        return "forward-instantiate" + args_suffix([("max-per-pair", maybe_int(fields.get("max_per_pair")))])
    if atom.startswith("SrsRfcRelativeMatchBounds"):
        return "rfc-relative-match-bounds" + args_suffix(
            [
                ("max-bound", maybe_int(fields.get("max_bound"))),
                ("max-words", maybe_int(fields.get("max_words"))),
                ("max-word-len", maybe_int(fields.get("max_word_len"))),
                ("max-states", maybe_int(fields.get("max_states"))),
                ("max-transitions", maybe_int(fields.get("max_transitions"))),
                ("at-bound", (fields.get("at_bound") or "").lower() or None),
                ("closure", (fields.get("closure") or "").lower() or None),
            ]
        )
    if atom.startswith("SrsRfcMatchBounds") or atom.startswith("SrsMatchBounds"):
        return "match-bounds" + args_suffix(
            [
                ("max-bound", maybe_int(fields.get("max_bound"))),
                ("max-words", maybe_int(fields.get("max_words"))),
            ]
        )
    if atom.startswith("SrsRelativeMatchBounds"):
        return "relative-match-bounds" + args_suffix(
            [
                ("max-bound", maybe_int(fields.get("max_bound"))),
                ("max-states", maybe_int(fields.get("max_states"))),
            ]
        )
    if atom.startswith("SymbolWeights"):
        return "symbol-weights" + args_suffix([("max-weight", maybe_int(fields.get("max_weight")))])

    # Last resort: keep a stable, parseable spelling instead of losing rare
    # processor atoms. This should be audited in the summary.
    return re.sub(r"\s+", "-", atom)


def bucket_for_event(outcome: Any, progress: Any) -> str | None:
    if outcome == "solved":
        return "solved"
    if outcome == "transformed":
        if progress == "strong":
            return "transformed_strong"
        return "transformed_weak"
    if outcome == "timeout":
        return "timeout"
    if outcome == "failed":
        return "failed"
    return None


def candidate_sort_key(row: sqlite3.Row) -> tuple[int, int, int, str]:
    status = row["best_status"]
    rank = STATUS_RANK.get(status, 0)
    elapsed = row["best_elapsed_ms"] if row["best_elapsed_ms"] is not None else 10**12
    attempts = row["attempts"] if row["attempts"] is not None else 0
    return (-rank, elapsed, attempts, row["candidate"])


def response_for_candidates(rows: list[sqlite3.Row], max_per_status: int) -> tuple[str, Counter[str]]:
    by_status: dict[str, list[sqlite3.Row]] = {status: [] for status in STATUS_ORDER}
    for row in rows:
        status = row["best_status"]
        if status in by_status:
            by_status[status].append(row)
    counts = Counter({status: len(values) for status, values in by_status.items()})
    sections: list[str] = []
    for status in STATUS_ORDER:
        values = sorted(by_status[status], key=candidate_sort_key)
        if max_per_status > 0:
            values = values[:max_per_status]
        if not values:
            continue
        sections.append(status + ":\n" + "\n".join(row["candidate"] for row in values))
    return "\n\n".join(sections), counts


def create_schema(conn: sqlite3.Connection) -> None:
    conn.executescript(
        """
        PRAGMA journal_mode=WAL;
        PRAGMA synchronous=NORMAL;
        CREATE TABLE IF NOT EXISTS problems (
            problem_key TEXT PRIMARY KEY,
            cpf TEXT NOT NULL,
            first_problem_id TEXT,
            rows INTEGER NOT NULL DEFAULT 0
        );
        CREATE TABLE IF NOT EXISTS candidates (
            problem_key TEXT NOT NULL,
            candidate_key TEXT NOT NULL,
            candidate TEXT NOT NULL,
            best_status TEXT NOT NULL,
            best_rank INTEGER NOT NULL,
            best_elapsed_ms INTEGER,
            attempts INTEGER NOT NULL DEFAULT 0,
            solved_count INTEGER NOT NULL DEFAULT 0,
            transformed_count INTEGER NOT NULL DEFAULT 0,
            failed_count INTEGER NOT NULL DEFAULT 0,
            timeout_count INTEGER NOT NULL DEFAULT 0,
            PRIMARY KEY (problem_key, candidate_key)
        );
        CREATE INDEX IF NOT EXISTS candidates_problem_key_idx ON candidates(problem_key);
        """
    )


def ingest_events(args: argparse.Namespace, conn: sqlite3.Connection) -> Counter[str]:
    stats: Counter[str] = Counter()
    started = time.monotonic()
    insert_problem = """
        INSERT INTO problems(problem_key, cpf, first_problem_id, rows)
        VALUES (?, ?, ?, 1)
        ON CONFLICT(problem_key) DO UPDATE SET rows = rows + 1
    """
    select_candidate = """
        SELECT best_rank, best_elapsed_ms, solved_count, transformed_count, failed_count, timeout_count, attempts
        FROM candidates WHERE problem_key = ? AND candidate_key = ?
    """
    insert_candidate = """
        INSERT INTO candidates(
            problem_key, candidate_key, candidate, best_status, best_rank, best_elapsed_ms,
            attempts, solved_count, transformed_count, failed_count, timeout_count
        ) VALUES (?, ?, ?, ?, ?, ?, 1, ?, ?, ?, ?)
    """
    update_candidate = """
        UPDATE candidates SET
            best_status = ?, best_rank = ?, best_elapsed_ms = ?,
            attempts = ?,
            solved_count = ?, transformed_count = ?, failed_count = ?, timeout_count = ?
        WHERE problem_key = ? AND candidate_key = ?
    """
    with open_text(args.input) as source:
        for line in source:
            stats["event_rows"] += 1
            try:
                event = json.loads(line)
            except json.JSONDecodeError:
                stats["bad_json"] += 1
                continue
            cpf = (event.get("input") or {}).get("cpf")
            if not isinstance(cpf, str) or not cpf.strip():
                stats["missing_cpf"] += 1
                continue
            candidate = normalize_atom(event.get("strategy_atom") or event.get("processor"))
            if candidate is None:
                stats["missing_candidate"] += 1
                continue
            bucket = bucket_for_event(event.get("outcome"), event.get("progress"))
            if bucket is None:
                stats["unknown_status"] += 1
                continue
            problem_key = hashlib.sha256(
                compact_xml_for_key(cpf).encode("utf-8")
            ).hexdigest()
            candidate_key = candidate
            rank = STATUS_RANK[bucket]
            elapsed = event.get("elapsed_ms")
            if not isinstance(elapsed, int):
                elapsed = None
            conn.execute(insert_problem, (problem_key, cpf.strip(), event.get("problem_id")))
            current = conn.execute(select_candidate, (problem_key, candidate_key)).fetchone()
            solved = 1 if bucket == "solved" else 0
            transformed = 1 if bucket.startswith("transformed") else 0
            failed = 1 if bucket == "failed" else 0
            timeout = 1 if bucket == "timeout" else 0
            if current is None:
                conn.execute(
                    insert_candidate,
                    (
                        problem_key,
                        candidate_key,
                        candidate,
                        bucket,
                        rank,
                        elapsed,
                        solved,
                        transformed,
                        failed,
                        timeout,
                    ),
                )
            else:
                best_rank = current["best_rank"]
                best_elapsed = current["best_elapsed_ms"]
                best_status = bucket if rank > best_rank else None
                if rank == best_rank:
                    if elapsed is not None and (best_elapsed is None or elapsed < best_elapsed):
                        best_status = bucket
                if best_status is None:
                    best_status = conn.execute(
                        "SELECT best_status FROM candidates WHERE problem_key = ? AND candidate_key = ?",
                        (problem_key, candidate_key),
                    ).fetchone()[0]
                    rank = best_rank
                    elapsed = best_elapsed
                conn.execute(
                    update_candidate,
                    (
                        best_status,
                        max(rank, best_rank),
                        elapsed if best_status == bucket else best_elapsed,
                        current["attempts"] + 1,
                        current["solved_count"] + solved,
                        current["transformed_count"] + transformed,
                        current["failed_count"] + failed,
                        current["timeout_count"] + timeout,
                        problem_key,
                        candidate_key,
                    ),
                )
            if stats["event_rows"] % args.progress_every == 0:
                conn.commit()
                elapsed_s = time.monotonic() - started
                print(
                    f"ingest-progress rows={stats['event_rows']} usable={stats['event_rows'] - stats['missing_cpf'] - stats['missing_candidate'] - stats['unknown_status']} elapsed={elapsed_s:.1f}s",
                    file=sys.stderr,
                    flush=True,
                )
            if args.limit is not None and stats["event_rows"] >= args.limit:
                break
    conn.commit()
    return stats


def export_rows(args: argparse.Namespace, conn: sqlite3.Connection) -> Counter[str]:
    def split_path(split: str) -> Path:
        return args.out_prefix.parent / f"{args.out_prefix.name}.{split}.jsonl.gz"

    outputs = {
        "train": open_output(split_path("train")),
        "validation": open_output(split_path("validation")),
        "test": open_output(split_path("test")),
    }
    stats: Counter[str] = Counter()
    bucket_counts: Counter[str] = Counter()
    try:
        problem_rows = conn.execute("SELECT problem_key, cpf FROM problems ORDER BY problem_key")
        for problem in problem_rows:
            rows = conn.execute(
                "SELECT * FROM candidates WHERE problem_key = ?",
                (problem["problem_key"],),
            ).fetchall()
            if not rows:
                continue
            counts = Counter(row["best_status"] for row in rows)
            has_positive = any(counts[status] for status in POSITIVE_STATUSES)
            if args.require_positive and not has_positive:
                stats["skipped_no_positive"] += 1
                continue
            response, full_counts = response_for_candidates(rows, args.max_per_status)
            if not response:
                stats["skipped_empty_response"] += 1
                continue
            split = split_for_id(problem["problem_key"], args.validation_pct, args.test_pct)
            row = {
                "condition": args.condition,
                "instruction": wrap_input(problem["cpf"]),
                "response": response,
            }
            outputs[split].write(json.dumps(row, sort_keys=True) + "\n")
            stats[f"{split}_rows"] += 1
            stats["output_rows"] += 1
            for status, count in full_counts.items():
                bucket_counts[f"{status}_candidates"] += count
            if stats["output_rows"] % args.progress_every == 0:
                print(f"export-progress rows={stats['output_rows']}", file=sys.stderr, flush=True)
    finally:
        for output in outputs.values():
            output.close()
    stats.update(bucket_counts)
    return stats


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--input", type=Path, required=True, help="processor-event JSONL/JSONL.gz")
    parser.add_argument("--out-prefix", type=Path, required=True, help="output prefix without split suffix")
    parser.add_argument("--sqlite", type=Path, required=True, help="temporary/materialized SQLite database")
    parser.add_argument("--summary", type=Path, required=True)
    parser.add_argument("--condition", default="direct")
    parser.add_argument("--validation-pct", type=int, default=5)
    parser.add_argument("--test-pct", type=int, default=5)
    parser.add_argument("--max-per-status", type=int, default=16)
    parser.add_argument("--progress-every", type=int, default=100000)
    parser.add_argument("--limit", type=int)
    parser.add_argument("--keep-sqlite", action="store_true")
    parser.add_argument(
        "--require-positive",
        action="store_true",
        help="skip rows that only contain failed/timeout candidates",
    )
    args = parser.parse_args()

    args.sqlite.parent.mkdir(parents=True, exist_ok=True)
    args.out_prefix.parent.mkdir(parents=True, exist_ok=True)
    if args.sqlite.exists():
        args.sqlite.unlink()
    conn = sqlite3.connect(args.sqlite)
    conn.row_factory = sqlite3.Row
    create_schema(conn)
    ingest_stats = ingest_events(args, conn)
    problem_count = conn.execute("SELECT COUNT(*) FROM problems").fetchone()[0]
    candidate_count = conn.execute("SELECT COUNT(*) FROM candidates").fetchone()[0]
    export_stats = export_rows(args, conn)
    summary = {
        "input": str(args.input),
        "out_prefix": str(args.out_prefix),
        "sqlite": str(args.sqlite),
        "condition": args.condition,
        "validation_pct": args.validation_pct,
        "test_pct": args.test_pct,
        "max_per_status": args.max_per_status,
        "require_positive": args.require_positive,
        "problem_count": problem_count,
        "candidate_count": candidate_count,
        "ingest": dict(ingest_stats),
        "export": dict(export_stats),
    }
    args.summary.parent.mkdir(parents=True, exist_ok=True)
    args.summary.write_text(json.dumps(summary, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    print(json.dumps(summary, indent=2, sort_keys=True), flush=True)
    conn.close()
    if not args.keep_sqlite and args.sqlite.exists():
        args.sqlite.unlink()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
