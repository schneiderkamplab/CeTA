#!/usr/bin/env python3
"""Build HRM-Text direct rows whose response is a Ferrum strategy atom.

Input rows are Ferrum canonical proof-fragment rows from
``subproofs.cpf.canonical.smt-lex.final.jsonl.gz`` or derived proof-step rows.
Each output row is:

    {"condition": "direct", "instruction": "<input>...</input>", "response": "poly(...)"}

The exporter is intentionally conservative. It emits a row only when the proof
step can be mapped to a leaf processor used by ``strategies/default.fs`` without
inventing parameters. Parameterized polynomial, matrix, KBO, and bounds labels
are derived from the proof XML witness where possible; structural sub-strategies
and aliases such as ``orders`` are skipped.
"""

from __future__ import annotations

import argparse
import gzip
import hashlib
import json
import re
import xml.etree.ElementTree as ET
from collections import Counter
from pathlib import Path
from typing import Any


def open_input(path: Path):
    return gzip.open(path, "rt", encoding="utf-8") if path.suffix == ".gz" else path.open("r", encoding="utf-8")


def open_output(path: Path):
    path.parent.mkdir(parents=True, exist_ok=True)
    return gzip.open(path, "wt", encoding="utf-8") if path.suffix == ".gz" else path.open("w", encoding="utf-8")


def compact_json(value: Any) -> str:
    return json.dumps(value, sort_keys=True, separators=(",", ":"))


def split_for_id(identifier: str, validation_pct: int, test_pct: int) -> str:
    bucket = int(hashlib.sha256(identifier.encode()).hexdigest()[:8], 16) % 10_000
    test_cutoff = test_pct * 100
    validation_cutoff = test_cutoff + validation_pct * 100
    if bucket < test_cutoff:
        return "test"
    if bucket < validation_cutoff:
        return "validation"
    return "train"


def local_name(tag: str) -> str:
    return tag.rsplit("}", 1)[-1]


def all_tags(root: ET.Element) -> set[str]:
    return {local_name(elem.tag) for elem in root.iter()}


def integer_texts(root: ET.Element) -> list[int]:
    values: list[int] = []
    for elem in root.iter():
        if local_name(elem.tag) != "integer":
            continue
        text = "".join(elem.itertext()).strip()
        if re.fullmatch(r"-?\d+", text):
            values.append(int(text))
    return values


def arities(root: ET.Element) -> list[int]:
    values: list[int] = []
    for elem in root.iter():
        if local_name(elem.tag) == "arity":
            text = "".join(elem.itertext()).strip()
            if re.fullmatch(r"\d+", text):
                values.append(int(text))
    return values


def symbol_names(root: ET.Element) -> set[str]:
    names: set[str] = set()
    for elem in root.iter():
        if local_name(elem.tag) == "name":
            text = "".join(elem.itertext()).strip()
            if text:
                names.add(text)
    return names


def interpreted_symbol_count(root: ET.Element) -> int | None:
    """Count interpretation entries, keeping sharp and unsharp symbols distinct.

    CPF writes ``f`` and ``f#`` with the same nested ``<name>f</name>`` text,
    so counting unique name strings underestimates Ferrum's symbol bound.
    Every ``<interpret>`` node denotes one interpretation-table entry and is
    therefore the correct replay bound.
    """
    entries = sum(1 for elem in root.iter() if local_name(elem.tag) == "interpret")
    return entries or len(symbol_names(root)) or None


def max_bound(root: ET.Element, tag: str) -> int | None:
    values: list[int] = []
    for elem in root.iter():
        if local_name(elem.tag) == tag:
            text = "".join(elem.itertext()).strip()
            if re.fullmatch(r"-?\d+", text):
                values.append(int(text))
    return max(values) if values else None


def polynomial_strategy(root: ET.Element) -> tuple[str, str] | None:
    tags = all_tags(root)
    ints = integer_texts(root)
    max_constant = max([abs(v) for v in ints], default=0)
    max_coefficient = max([abs(v) for v in ints], default=1)
    max_symbols = interpreted_symbol_count(root)
    max_arity = max(arities(root), default=None)
    suffix = f"max-constant={max_constant}, max-coefficient={max_coefficient}"
    if max_symbols is not None:
        suffix += f", symbols={max_symbols}"
    if max_arity is not None:
        suffix += f", arity={max_arity}"
    if {"matrix", "matrixInterpretation", "matrixInterpretations"} & tags:
        dim = max_bound(root, "dimension") or max_bound(root, "dim")
        dim_part = f", dim={dim}" if dim else ""
        return (f"matrix({suffix}{dim_part})", "exact_xml_matrix_bounds")
    if "maxPoly" in tags or "maxPolynomial" in tags:
        alternatives = max(2, sum(1 for elem in root.iter() if local_name(elem.tag) in {"max", "maximum"}))
        return (f"max-poly({suffix}, alternatives={alternatives})", "exact_xml_max_poly_bounds")
    if "interpretation" in tags:
        return (f"poly({suffix})", "exact_xml_polynomial_bounds")
    return None


def kbo_strategy(root: ET.Element) -> tuple[str, str] | None:
    tags = all_tags(root)
    if "kbo" not in {tag.lower() for tag in tags} and "weight" not in tags:
        return None
    weights: list[int] = []
    for elem in root.iter():
        if local_name(elem.tag).lower() == "weight":
            text = "".join(elem.itertext()).strip()
            if re.fullmatch(r"-?\d+", text):
                weights.append(abs(int(text)))
    max_weight = max(weights, default=2)
    symbols = len(symbol_names(root))
    if symbols:
        return (f"kbo(weight={max_weight}, symbols={symbols})", "exact_xml_kbo_bounds")
    return (f"kbo(weight={max_weight})", "exact_xml_kbo_bounds")


def has_argument_filter(root: ET.Element) -> bool:
    tags = all_tags(root)
    return any("argumentFilter" in tag or tag in {"usableArgumentFilter"} for tag in tags)


def is_dp_problem_xml(problem_xml: str) -> bool:
    return "<dpInput" in problem_xml or "<dps" in problem_xml or "<dependencyPairs" in problem_xml


def path_order_strategy(root: ET.Element, problem_xml: str) -> tuple[str, str] | None:
    tags = all_tags(root)
    if "pathOrder" in tags or "statusPrecedence" in tags:
        if is_dp_problem_xml(problem_xml):
            return ("path-order", "exact_xml_dp_path_order")
        if has_argument_filter(root):
            return ("path-order", "top_level_monotonic_path_order_family")
        return ("path-order", "exact_xml_path_order")
    return None


def bounds_strategy(root: ET.Element) -> tuple[str, str] | None:
    tags = all_tags(root)
    if "bounds" not in tags:
        return None
    bound = max_bound(root, "bound")
    if bound is None:
        return ("match-bounds", "coarse_bounds")
    return (f"match-bounds(max-bound={bound})", "exact_xml_match_bound")


def processor_order_witness(root: ET.Element) -> ET.Element:
    witness_tags = {
        "bounds",
        "interpretation",
        "kbo",
        "pathOrder",
        "relativeBounds",
        "statusPrecedence",
    }
    continuation_tags = {
        "dpProof",
        "proof",
        "relativeTerminationProof",
        "trsTerminationProof",
    }

    def search(elem: ET.Element) -> ET.Element | None:
        if local_name(elem.tag) in witness_tags:
            return elem
        for child in elem:
            if local_name(child.tag) in continuation_tags:
                continue
            witness = search(child)
            if witness is not None:
                return witness
        return None

    witness = search(root)
    return witness if witness is not None else root


def strategy_from_xml(processor: str, xml: str, problem_xml: str) -> tuple[str, str] | None:
    try:
        root = ET.fromstring(xml)
    except ET.ParseError:
        return None
    root_tag = local_name(root.tag)
    order_witness_roots = {
        "bounds",
        "interpretation",
        "kbo",
        "monoRedPairProc",
        "monoRedPairUrProc",
        "pathOrder",
        "relativeBounds",
        "redPairProc",
        "redPairUrProc",
        "ruleRemoval",
        "csrRuleRemoval",
        "csrRuleRemovalThenImproved",
    }
    if root_tag in order_witness_roots:
        root = processor_order_witness(root)
        for extractor in (kbo_strategy, bounds_strategy, polynomial_strategy):
            strategy = extractor(root)
            if strategy is not None:
                return strategy
        strategy = path_order_strategy(root, problem_xml)
        if strategy is not None:
            return strategy
    tags = all_tags(root)
    if processor == "sizeChangeProc":
        if "subtermCriterion" in tags:
            return ("subterm", "exact_xml_subterm")
        return ("size-change", "coarse_processor")
    if processor == "depGraphProc":
        return ("graph", "coarse_processor")
    if processor in {
        "csrDependencyPairs",
        "csrSafeDependencyPairs",
        "csrConservativeDependencyPairs",
    }:
        return ("dp", "coarse_processor")
    if processor == "csrInnermost":
        return ("csr-innermost", "coarse_processor")
    if processor == "loop":
        return ("nontermination(loop)", "exact_xml_loop")
    if processor == "nonLoop":
        return ("nontermination(dp-nonloop)", "exact_xml_nonloop")
    if processor == "instantiationProc":
        return ("instantiate(per-pair=2)", "coarse_processor")
    if processor == "forwardInstantiationProc":
        return ("forward-instantiate(per-pair=2)", "coarse_processor")
    if processor == "csrForwardInstantiationProc":
        return ("forward-instantiate(per-pair=2)", "coarse_processor")
    if processor == "uncurry":
        return ("uncurry", "coarse_processor")
    return None


def row_problem_xml(row: dict[str, Any]) -> str | None:
    problem_xml = row.get("input", {}).get("problem_xml")
    return problem_xml if isinstance(problem_xml, str) else None


def row_output_xml(row: dict[str, Any]) -> str | None:
    target = row.get("target")
    if isinstance(target, dict) and isinstance(target.get("proof_suggestion_xml"), str):
        return target["proof_suggestion_xml"]
    output_xml = row.get("output_xml")
    return output_xml if isinstance(output_xml, str) else None


def row_processor(row: dict[str, Any], proof_xml: str) -> str | None:
    target = row.get("target", {})
    if isinstance(target, dict) and isinstance(target.get("processor"), str):
        return target["processor"]
    try:
        return local_name(ET.fromstring(proof_xml).tag)
    except ET.ParseError:
        return None


def build_row(row: dict[str, Any], condition: str) -> tuple[dict[str, str], str] | None:
    problem_xml = row_problem_xml(row)
    proof_xml = row_output_xml(row)
    if not isinstance(problem_xml, str) or not problem_xml.startswith("<input>"):
        return None
    if not isinstance(proof_xml, str):
        return None
    processor = row_processor(row, proof_xml)
    if not isinstance(processor, str):
        return None
    strategy = strategy_from_xml(processor, proof_xml, problem_xml)
    if strategy is None:
        return None
    label, source = strategy
    return ({"condition": condition, "instruction": problem_xml.strip(), "response": label}, source)


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--input", type=Path, required=True)
    parser.add_argument("--out-dir", type=Path, required=True)
    parser.add_argument("--summary", type=Path, required=True)
    parser.add_argument("--prefix", default="ferrum.strategy")
    parser.add_argument("--condition", default="direct")
    parser.add_argument("--validation-pct", type=int, default=1)
    parser.add_argument("--test-pct", type=int, default=1)
    parser.add_argument("--limit", type=int)
    parser.add_argument("--progress-interval", type=int, default=50000)
    args = parser.parse_args()

    if args.validation_pct < 0 or args.test_pct < 0 or args.validation_pct + args.test_pct >= 100:
        raise SystemExit("validation/test percentages must be nonnegative and sum to less than 100")

    outputs = {
        "train": args.out_dir / f"{args.prefix}.direct.train.jsonl.gz",
        "validation": args.out_dir / f"{args.prefix}.direct.validation.jsonl.gz",
        "test": args.out_dir / f"{args.prefix}.direct.test.jsonl.gz",
    }
    counts = Counter()
    source_counts = Counter()
    label_counts = Counter()
    skipped_by_processor = Counter()
    input_rows = 0
    skipped = 0
    with open_input(args.input) as source:
        sinks = {split: open_output(path) for split, path in outputs.items()}
        try:
            for line in source:
                row = json.loads(line)
                input_rows += 1
                built = build_row(row, args.condition)
                if built is None:
                    skipped += 1
                    skipped_by_processor[str(row.get("target", {}).get("processor"))] += 1
                else:
                    direct, label_source = built
                    identifier = str(row.get("id") or row.get("row_id") or input_rows)
                    split = split_for_id("strategy:" + identifier, args.validation_pct, args.test_pct)
                    sinks[split].write(compact_json(direct) + "\n")
                    counts[split] += 1
                    source_counts[label_source] += 1
                    label_counts[direct["response"]] += 1
                if args.progress_interval > 0 and input_rows % args.progress_interval == 0:
                    print(
                        compact_json(
                            {
                                "event": "progress",
                                "input_rows": input_rows,
                                "written": dict(counts),
                                "skipped": skipped,
                            }
                        ),
                        flush=True,
                    )
                if args.limit is not None and input_rows >= args.limit:
                    break
        finally:
            for sink in sinks.values():
                sink.close()

    summary = {
        "input": str(args.input),
        "outputs": {split: str(path) for split, path in outputs.items()},
        "format": {"condition": args.condition, "instruction": "<input>...</input>", "response": "ferrum strategy atom"},
        "input_rows": input_rows,
        "written": dict(counts),
        "written_total": sum(counts.values()),
        "skipped": skipped,
        "label_source_counts": dict(source_counts.most_common()),
        "top_labels": dict(label_counts.most_common(50)),
        "top_skipped_processors": dict(skipped_by_processor.most_common(50)),
    }
    args.summary.parent.mkdir(parents=True, exist_ok=True)
    args.summary.write_text(json.dumps(summary, indent=2, sort_keys=True), encoding="utf-8")
    print(compact_json(summary), flush=True)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
