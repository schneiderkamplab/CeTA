import unittest
from build_modular_proof_overlay import build, retain_tested_guidance, attach_replay_order


class ModularOverlayTests(unittest.TestCase):
    def event(self, atom, key='state'):
        return {'input': {'problem_key': key}, 'strategy_atom': atom, 'outcome': 'transformed'}

    def gate(self, atom, checks=2, key='state'):
        return {'problem_key': key, 'candidate': atom, 'recheck_status': 'certified',
                'deterministic_rechecks': checks}

    def test_requires_two_checks_and_exact_state_action_pair(self):
        self.assertEqual(build([self.event('dp')], [self.gate('dp', checks=1)]), [])
        self.assertEqual(build([self.event('dp')], [self.gate('dp', key='other')]), [])
        self.assertEqual(build([self.event('dp')], [self.gate('graph')]), [])

    def test_preserves_multiple_actions_and_required_schema_fields(self):
        rows = build([self.event('dp'), self.event('graph')], [self.gate('dp'), self.gate('graph')])
        self.assertEqual(len(rows), 1)
        self.assertEqual([item['candidate'] for item in rows[0]['prefer']], ['dp', 'graph'])
        for item in rows[0]['prefer']:
            for key in ['attempts', 'certified_count', 'failed_count', 'timeout_count', 'best_elapsed_ms']:
                self.assertIn(key, item)

    def test_rejects_whole_proofs_of_both_polarities(self):
        for atom in ['exact-trs-proof(hex=00)', 'exact-dp-proof(hex=00)',
                     'exact-trs-nontermination-proof(hex=00)', 'exact-dp-nontermination-proof(hex=00)']:
            with self.assertRaises(ValueError):
                build([self.event(atom)], [self.gate(atom)])

    def test_retains_missing_live_keys_without_promoting_weak_actions(self):
        weak = {'schema': 'ferrum.utility-guidance.v2', 'problem_key': 'live-child',
                'possible': [{'candidate': 'narrow(candidate=1)', 'status': 'transformed_weak'}]}
        extracted = build([self.event('graph')], [self.gate('graph')])
        rows = retain_tested_guidance(extracted, [weak])
        live = next(row for row in rows if row.get('problem_key') == 'live-child')
        self.assertEqual(live['prefer'], [])
        self.assertEqual(live['possible'][0]['status'], 'transformed_weak')
        self.assertEqual(len(rows), 2)

    def test_rejects_complete_proof_in_tested_witness_table(self):
        with self.assertRaises(ValueError):
            retain_tested_guidance([], [{'schema': 'ferrum.utility-guidance.witness.v1',
                'witness_id': 'bad', 'candidate': 'exact-trs-proof(hex=00)'}])

    def test_replay_order_neither_imports_nor_promotes_actions(self):
        row = {'problem_key': 'state', 'possible': [
            {'candidate': 'alpha-merge', 'status': 'transformed_weak'}]}
        attach_replay_order([row], [self.event('alpha-merge'), self.event('unrecorded')])
        self.assertEqual(len(row['replay_order']), 2)
        self.assertEqual(row['possible'], [{'candidate': 'alpha-merge', 'status': 'transformed_weak'}])
        self.assertNotIn('prefer', row)


if __name__ == '__main__':
    unittest.main()
