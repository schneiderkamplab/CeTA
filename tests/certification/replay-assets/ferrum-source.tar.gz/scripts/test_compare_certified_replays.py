import unittest
from compare_certified_replays import compare


class ReplayComparisonTests(unittest.TestCase):
    def test_category_projection_does_not_report_other_categories_as_losses(self):
        row = dict(path='a', category='TRS_Standard', status='yes', certified=True)
        other = dict(path='b', category='TRS_Innermost', status='yes', certified=True)
        result = compare([row, other], [row], 'TRS_Standard')
        self.assertEqual(result['inputs'], 1)
        self.assertEqual(result['losses'], [])
        self.assertEqual(result['missing_inputs'], [])
        with self.assertRaisesRegex(ValueError, 'nonempty'):
            compare([row, other], [row], 'TRS_Innermost')

    def test_equal_totals_do_not_hide_root_loss(self):
        old = [dict(path='TPDB-ARI/a', status='yes', certified=True),
               dict(path='TPDB-ARI/b', status='unknown', certified=False)]
        new = [dict(path='a', status='unknown', certified=False),
               dict(path='b', status='yes', certified=True)]
        result = compare(old, new)
        self.assertEqual(result['losses'], ['a'])
        self.assertEqual(result['gains'], ['b'])
        self.assertEqual(result['missing_inputs'], [])

    def test_detects_polarity_and_uncertified_decisions(self):
        result = compare([dict(path='a', status='yes', certified=True)],
                         [dict(path='a', status='no', certified=True),
                          dict(path='b', status='yes', certified=False)])
        self.assertEqual(result['polarity_changes'], ['a'])
        self.assertEqual(result['uncertified_decisions'], ['b'])
