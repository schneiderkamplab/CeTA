#!/usr/bin/env python3
"""Create a canonicalized copy of the subproof JSONL dataset.

The input rows are proof-fragment training examples. This script applies the
same function-symbol canonicalization helper used by the certificate audit when
the row's ``input.problem_xml`` contains a parseable TRS/QDP-style rules block.
With ``--max-symbols 0`` the helper uses the direct lex minimizer. Positive
``--max-symbols`` values keep the legacy small brute-force path for comparison
and use the refinement/SMT structural path above that threshold. The resulting
function-symbol bijection is applied to the row's problem, local context, and
proof fragment XML. Variables are alpha-renamed consistently inside each XML
fragment.

Rows outside that currently supported shape are preserved unchanged and
annotated with a canonicalization status.
"""

from __future__ import annotations

import argparse
import contextlib
import gzip
import hashlib
import json
import signal
import sys
import xml.etree.ElementTree as ET
from copy import deepcopy
from pathlib import Path
from typing import Any

from audit_standardized_subproof_rows import (
    SYMBOL_PARENT_TAGS,
    first_child,
    input_rules,
    local_name,
    parent_map,
    rewrite_symbol_names,
    rewrite_variables_globally,
    standardize_function_bijection_with_info,
)


class StandardizationTimeout(TimeoutError):
    pass


@contextlib.contextmanager
def standardization_timer(seconds: float):
    if seconds <= 0:
        yield
        return
    old_handler = signal.getsignal(signal.SIGALRM)
    old_timer = signal.setitimer(signal.ITIMER_REAL, seconds)

    def on_timeout(signum, frame):  # noqa: ARG001
        raise StandardizationTimeout(f"standardization exceeded {seconds:g}s")

    signal.signal(signal.SIGALRM, on_timeout)
    try:
        yield
    finally:
        signal.setitimer(signal.ITIMER_REAL, old_timer[0], old_timer[1])
        signal.signal(signal.SIGALRM, old_handler)


def parse_xml_fragment(text: str | None) -> ET.Element | None:
    if not text:
        return None
    try:
        return ET.fromstring(text.encode())
    except ET.ParseError:
        return None


def rewrite_fragment(text: str | None, mapping: dict[str, str]) -> str | None:
    if text is None:
        return None
    root = parse_xml_fragment(text)
    if root is None:
        return text
    root = deepcopy(root)
    rewrite_symbol_names(root, mapping)
    rewrite_variables_globally(root)
    return ET.tostring(root, encoding="unicode", short_empty_elements=True)


def identity_mapping(mapping: dict[str, str]) -> bool:
    return all(old == new for old, new in mapping.items())


def problem_plan(problem_xml: str | None, max_symbols: int, standardization_timeout: float) -> dict[str, Any]:
    root = parse_xml_fragment(problem_xml)
    status = "unchanged-no-problem-xml"
    mapping: dict[str, str] = {}
    error = None
    method = None
    rule_count = 0
    if root is not None:
        try:
            rules = input_rules(root)
            rule_count = len(rules)
            with standardization_timer(standardization_timeout):
                mapping, method = standardize_function_bijection_with_info(root, max_symbols)
            status = "canonicalized-identity" if identity_mapping(mapping) else "canonicalized"
        except Exception as exc:  # noqa: BLE001 - status is recorded in the row.
            status = "unchanged-unsupported"
            error = f"{type(exc).__name__}: {exc}"
            mapping = {}
    elif problem_xml:
        status = "unchanged-unparseable-problem-xml"
    plan = {
        "status": status,
        "mapping": mapping,
        "rule_count": rule_count,
    }
    if method is not None:
        plan["method"] = method
    if error is not None:
        plan["error"] = error
    return plan


def canonicalize_row(
    row: dict[str, Any],
    max_symbols: int,
    standardization_timeout: float,
    plan_cache: dict[str, dict[str, Any]],
) -> tuple[dict[str, Any], str, bool]:
    canonical = deepcopy(row)
    original_id = row["id"]
    canonical["source_row_id"] = original_id
    problem_xml = row.get("input", {}).get("problem_xml")
    cache_key = hashlib.sha256((problem_xml or "").encode()).hexdigest()
    cache_hit = cache_key in plan_cache
    plan = plan_cache.get(cache_key)
    if plan is None:
        plan = problem_plan(problem_xml, max_symbols, standardization_timeout)
        plan_cache[cache_key] = plan
    status = str(plan["status"])
    mapping = dict(plan.get("mapping") or {})
    rule_count = int(plan.get("rule_count") or 0)

    if mapping:
        canonical["input"]["problem_xml"] = rewrite_fragment(row["input"].get("problem_xml"), mapping)
        canonical["input"]["local_context_xml"] = rewrite_fragment(row["input"].get("local_context_xml"), mapping)
        canonical["output_xml"] = rewrite_fragment(row.get("output_xml"), mapping)
    elif status == "canonicalized-identity":
        canonical["input"]["problem_xml"] = rewrite_fragment(row["input"].get("problem_xml"), mapping)
        canonical["input"]["local_context_xml"] = rewrite_fragment(row["input"].get("local_context_xml"), mapping)
        canonical["output_xml"] = rewrite_fragment(row.get("output_xml"), mapping)

    canonical["canonicalization"] = {
        "status": status,
        "max_exact_symbols": max_symbols,
        "standardization_timeout_seconds": standardization_timeout,
        "method": plan.get("method"),
        "function_bijection": mapping,
        "rule_count": rule_count,
        "problem_cache_hit": cache_hit,
    }
    if "error" in plan:
        canonical["canonicalization"]["error"] = plan["error"]
    canonical["id"] = canonical_row_id(canonical)
    return canonical, status, cache_hit


def canonical_row_id(row: dict[str, Any]) -> str:
    material = {
        "source_row_id": row.get("source_row_id"),
        "source": row.get("source"),
        "metadata": row.get("metadata"),
        "input": row.get("input"),
        "output_xml": row.get("output_xml"),
        "canonicalization": row.get("canonicalization"),
    }
    return hashlib.sha256(json.dumps(material, sort_keys=True, separators=(",", ":")).encode()).hexdigest()


def open_input(path: Path):
    if path.suffix == ".gz":
        return gzip.open(path, "rt", encoding="utf-8")
    return path.open("r", encoding="utf-8")


def open_output(path: Path):
    path.parent.mkdir(parents=True, exist_ok=True)
    if path.suffix == ".gz":
        return gzip.open(path, "wt", encoding="utf-8")
    return path.open("w", encoding="utf-8")


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--input", type=Path, default=Path("target/termcomp-proof-corpus/training/subproofs.jsonl.gz"))
    parser.add_argument("--output", type=Path, default=Path("target/termcomp-proof-corpus/training/subproofs.canonical.jsonl.gz"))
    parser.add_argument("--summary", type=Path, default=Path("target/termcomp-proof-corpus/training/subproofs.canonical.summary.json"))
    parser.add_argument(
        "--max-symbols",
        type=int,
        default=0,
        help="legacy brute-force exact threshold; 0 uses direct lex standardization",
    )
    parser.add_argument(
        "--standardization-timeout",
        type=float,
        default=10.0,
        help="per-unique-problem standardization timeout in seconds; 0 disables it",
    )
    parser.add_argument("--progress-interval", type=int, default=10000)
    parser.add_argument("--limit", type=int)
    args = parser.parse_args()

    counts: dict[str, int] = {}
    method_counts: dict[str, int] = {}
    rows = 0
    cache_hits = 0
    plan_cache: dict[str, dict[str, Any]] = {}
    with open_input(args.input) as source, open_output(args.output) as sink:
        for line in source:
            row = json.loads(line)
            canonical, status, cache_hit = canonicalize_row(
                row,
                args.max_symbols,
                args.standardization_timeout,
                plan_cache,
            )
            sink.write(json.dumps(canonical, sort_keys=True, separators=(",", ":")) + "\n")
            rows += 1
            if cache_hit:
                cache_hits += 1
            counts[status] = counts.get(status, 0) + 1
            method = str((canonical.get("canonicalization") or {}).get("method") or "none")
            method_counts[method] = method_counts.get(method, 0) + 1
            if args.progress_interval > 0 and rows % args.progress_interval == 0:
                print(
                    json.dumps(
                        {
                            "event": "progress",
                            "rows": rows,
                            "counts": counts,
                            "methods": method_counts,
                            "unique_problem_xml": len(plan_cache),
                            "problem_cache_hits": cache_hits,
                        },
                        sort_keys=True,
                    ),
                    flush=True,
                )
            if args.limit is not None and rows >= args.limit:
                break

    summary = {
        "input": str(args.input),
        "output": str(args.output),
        "rows_written": rows,
        "max_exact_symbols": args.max_symbols,
        "standardization_timeout_seconds": args.standardization_timeout,
        "counts": dict(sorted(counts.items())),
        "method_counts": dict(sorted(method_counts.items())),
        "unique_problem_xml": len(plan_cache),
        "problem_cache_hits": cache_hits,
    }
    args.summary.write_text(json.dumps(summary, indent=2, sort_keys=True))
    print(json.dumps(summary, sort_keys=True), flush=True)
    return 0


if __name__ == "__main__":
    sys.setrecursionlimit(max(sys.getrecursionlimit(), 200_000))
    raise SystemExit(main())
