#!/usr/bin/env python3
"""Extract lost roots independently so one expensive proof cannot stall the batch."""
import argparse
import concurrent.futures
import json
import subprocess
import sys
from pathlib import Path


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--baseline', type=Path, required=True)
    p.add_argument('--ablation', type=Path)
    p.add_argument('--replay-details', type=Path,
                   help='Recover failed rows from a flat modular replay instead of comparison.json')
    p.add_argument('--output', type=Path, required=True)
    p.add_argument('--ferrum', type=Path, required=True)
    p.add_argument('--ceta', type=Path, required=True)
    p.add_argument('--jobs', type=int, default=8)
    p.add_argument('--retry-results', type=Path,
                   help='Only retry unsuccessful roots from an earlier results.jsonl.')
    p.add_argument('--extraction-timeout', type=float, default=300,
                   help='Per-root wall ceiling; timed-out partial shards are not integrated.')
    p.add_argument('--runtime-explicit-states-only', action='store_true',
                   help='Fast first pass; omit on frontier recovery passes to reconstruct unrecorded children.')
    args = p.parse_args()
    if not args.ablation and not args.replay_details:
        p.error('supply --ablation or --replay-details')
    runtime_overrides = {}
    if args.replay_details:
        comparison = {}
        category_names = {'TRS_Standard': 'standard', 'TRS_Innermost': 'innermost',
                          'TRS_Contextsensitive': 'csr'}
        for row in json.loads(args.replay_details.read_text()):
            if row['certified']:
                continue
            name = row['path'].split('TPDB-ARI/', 1)[-1]
            category = category_names[row['category']]
            comparison.setdefault(category, {'losses': []})['losses'].append({'path': name})
            runtime_overrides[name] = Path(row['artifact_dir'])
    else:
        comparison = json.loads((args.ablation / 'comparison.json').read_text())
    tasks = []
    retry = None
    if args.retry_results:
        retry = {row['path'] for row in map(json.loads, args.retry_results.read_text().splitlines())
                 if row['returncode'] != 0}
    for category, report in comparison.items():
        baseline = {r['path'].split('TPDB-ARI/', 1)[-1]: r for r in
                    json.loads((args.baseline / category / 'details.json').read_text())}
        for loss in report['losses']:
            if retry is not None and loss['path'] not in retry:
                continue
            tasks.append((category, loss['path'], baseline[loss['path']]))
    args.output.mkdir(parents=True, exist_ok=False)

    def extract(task):
        category, name, baseline = task
        source = Path(baseline['artifact_dir'])
        runtime = (runtime_overrides[name] if name in runtime_overrides else
                   args.ablation / category / 'run' / Path(name).with_suffix(''))
        output = args.output / Path(name).with_suffix('')
        output.mkdir(parents=True)
        command = [sys.executable, 'scripts/extract_local_cpf_oracle_events.py',
                   '--root', str(source), '--runtime-root', str(runtime),
                   '--ferrum-canonicalizer', str(args.ferrum), '--ceta', str(args.ceta),
                   '--ceta-timeout', '60', '--output', str(output / 'events.jsonl'),
                   '--certified-manifest-output', str(output / 'manifest.jsonl'),
                   '--run-id', 'modular-recovery-shard', '--proof-chain-only',
                   '--exclude-complete-proof-atoms', '--progress-every', '1']
        if args.runtime_explicit_states_only:
            command.append('--runtime-explicit-states-only')
        with (output / 'log').open('w') as log:
            try:
                result = subprocess.run(command, stdout=log, stderr=subprocess.STDOUT,
                                        timeout=args.extraction_timeout)
            except subprocess.TimeoutExpired:
                return {'path': name, 'returncode': 124, 'output': str(output),
                        'reason': 'extraction-timeout; retained partial artifacts, not integrated'}
        return {'path': name, 'returncode': result.returncode, 'output': str(output)}

    with concurrent.futures.ThreadPoolExecutor(max_workers=args.jobs) as pool:
        with (args.output / 'results.jsonl').open('x') as output:
            for future in concurrent.futures.as_completed([pool.submit(extract, t) for t in tasks]):
                row = future.result()
                print(json.dumps(row), file=output, flush=True)
                print(json.dumps(row), flush=True)


if __name__ == '__main__':
    main()
