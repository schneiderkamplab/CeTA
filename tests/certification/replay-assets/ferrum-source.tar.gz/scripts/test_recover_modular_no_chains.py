import hashlib
import json
import unittest

from recover_modular_no_chains import add_direct_forward_hints


class DirectForwardHintsTest(unittest.TestCase):
    def test_policy_proposals_remain_weak_and_share_witnesses(self):
        atom = 'exact-dp-transform(hex=' + json.dumps(
            ['forwardInstantiationProc', '<rule/>', '<dpInput/>']).encode().hex() + ')'
        digest = hashlib.sha256(atom.encode()).hexdigest()
        rows = [dict(schema='ferrum.utility-guidance.witness.v1', witness_id=digest, candidate=atom)]
        rows += [dict(problem_key=key, prefer=[dict(candidate_ref=digest, status='transformed_strong')],
                      possible=[], replay_order=[digest]) for key in ('one', 'two')]
        result = add_direct_forward_hints(rows)
        definitions = [r['witness_id'] for r in result if 'witness_id' in r]
        self.assertEqual(len(definitions), 2)
        for row in [r for r in result if 'problem_key' in r]:
            self.assertEqual(row['possible'][0]['status'], 'transformed_weak')
            self.assertEqual(row['possible'][0]['certified_count'], 0)
            self.assertEqual(row['replay_order'][0], row['possible'][0]['candidate_ref'])
        add_direct_forward_hints(result)
        self.assertEqual(len([r for r in result if 'witness_id' in r]), 2)


if __name__ == '__main__':
    unittest.main()
