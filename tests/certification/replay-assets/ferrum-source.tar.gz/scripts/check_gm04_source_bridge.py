"""Exercise standalone and nested GM04 CSR discharge, including negative mutations."""
import argparse
import copy
import hashlib
import json
from pathlib import Path
import subprocess
import xml.etree.ElementTree as ET


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--dp-proof', type=Path, required=True)
    parser.add_argument('--trs-proof', type=Path, required=True)
    parser.add_argument('--checker', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    args.output.mkdir()
    dp = ET.parse(args.dp_proof).getroot()
    context = dp.find('./proof/gm04StandaloneDpProof')
    if context is None:
        raise ValueError('expected a standalone GM04 certificate')
    trs = ET.parse(args.trs_proof).getroot()
    transformed = trs.find('./proof/trsTerminationProof/gm04CompleteTransformation/transformedProof')
    if transformed is None:
        raise ValueError('expected a retained complete transformation for the TRS boundary test')
    ordinary = ET.Element('trsTerminationProof')
    ordinary.extend(copy.deepcopy(list(transformed)))
    outer = ET.Element('gm04StandaloneTrsProof')
    outer.append(copy.deepcopy(context))
    outer.append(ordinary)
    root_proof = trs.find('proof')
    root_proof.clear()
    root_proof.append(outer)
    cases = [('standalone', dp, True), ('nested-trs', trs, True)]

    reduced = copy.deepcopy(dp)
    premise = reduced.find('./proof/gm04StandaloneDpProof/transformedProof//finitenessAssumption/dpInput')
    if premise is not None and premise.find('./strategy/innermostLhss') is not None:
        # The source theorem admits R subsets, but Q must remain the original
        # normal-form context. Exercise that boundary without recomputing Q.
        for obligation in [reduced.find('./input/dpInput'), premise]:
            rules = obligation.find('./trs/rules')
            rules.remove(rules.find('rule'))
        cases.append(('reduced-r-with-fixed-q', reduced, True))

    bad = copy.deepcopy(dp)
    wrapper = bad.find('./proof/gm04StandaloneDpProof')
    symbol = wrapper.find('./sourceTrs/rules/rule/lhs/funapp/name')
    if symbol is None:
        symbol = wrapper.find('./sourceTrs/rules/rule/funapp/name')
    if symbol is None:
        raise ValueError('source rule has no function symbol')
    role = wrapper.find('activeSymbol')
    role.clear()
    role.append(copy.deepcopy(symbol))
    cases.append(('colliding-role', bad, False))

    bad = copy.deepcopy(dp)
    source = bad.find('./proof/gm04StandaloneDpProof/sourceProof')
    source.clear()
    source.append(ET.fromstring('<csrTerminationProof><rIsEmpty/></csrTerminationProof>'))
    cases.append(('missing-source-proof', bad, False))

    bad = copy.deepcopy(dp)
    strategy = bad.find('./input/dpInput/strategy')
    strategy.clear()
    q = ET.SubElement(strategy, 'innermostLhss')
    ET.SubElement(q, 'nfs').text = 'false'
    cases.append(('lost-q-and-normal-form-condition', bad, False))

    bad = copy.deepcopy(dp)
    entries = bad.findall('./proof/gm04StandaloneDpProof/sourceReplacementMap/contextSensitive/replacementMapEntry')
    entry = next(e for e in entries if int(e.findtext('arity')) > 0)
    position = entry.find('position')
    if position is not None:
        entry.remove(position)
    else:
        ET.SubElement(entry, 'position').text = '1'
    cases.append(('changed-replacement-map', bad, False))

    checker_hash = hashlib.sha256(args.checker.read_bytes()).hexdigest()
    with (args.output / 'results.jsonl').open('x') as output:
        for name, tree, expected in cases:
            proof = args.output / (name + '.cpf.xml')
            ET.ElementTree(tree).write(proof, encoding='utf-8', xml_declaration=True)
            checks = []
            for _ in range(2):
                result = subprocess.run([str(args.checker.resolve()), str(proof.resolve())],
                    capture_output=True, text=True, timeout=60)
                accepted = result.returncode == 0 and result.stdout.strip() == 'CERTIFIED'
                checks.append(dict(exit_code=result.returncode, accepted=accepted,
                                   stdout=result.stdout, stderr=result.stderr))
            record = dict(case=name, proof=str(proof), expected=expected,
                          sha256=hashlib.sha256(proof.read_bytes()).hexdigest(),
                          checker_sha256=checker_hash, checks=checks,
                          passed=all(c['accepted'] == expected for c in checks))
            print(json.dumps(record), file=output, flush=True)
            if not record['passed']:
                raise RuntimeError(f'GM04 boundary regression: {name}')


if __name__ == '__main__':
    main()
