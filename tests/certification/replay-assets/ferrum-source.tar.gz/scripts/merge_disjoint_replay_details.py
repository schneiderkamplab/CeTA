"""Combine independently run categories without hiding missing or duplicate roots."""
import argparse
import json
from pathlib import Path


def merge(parts, baseline):
    key = lambda row: (row['category'], row['path'])
    rows = {}
    for part in parts:
        for row in part:
            identity = key(row)
            if identity in rows:
                raise ValueError(f'duplicate replay root: {identity}')
            rows[identity] = row
    expected = {key(row) for row in baseline}
    if set(rows) != expected:
        raise ValueError(f'replay coverage mismatch: missing={len(expected-set(rows))}, extra={len(set(rows)-expected)}')
    # Preserve every original decision and certification result verbatim.
    return [rows[k] for k in sorted(rows)]


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--details', type=Path, action='append', required=True)
    p.add_argument('--baseline', type=Path, required=True)
    p.add_argument('--output', type=Path, required=True)
    args = p.parse_args()
    rows = merge([json.loads(path.read_text()) for path in args.details],
                 json.loads(args.baseline.read_text()))
    with args.output.open('x') as output:
        json.dump(rows, output, indent=2)
    print(json.dumps(dict(roots=len(rows), certified=sum(bool(r['certified']) for r in rows))))


if __name__ == '__main__':
    main()
