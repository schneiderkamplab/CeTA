#!/usr/bin/env python3
"""Map live root CPF hashes to retained certified-proof canonical states."""

from __future__ import annotations

import argparse
import glob
import hashlib
import json
import sqlite3
from pathlib import Path


def normalized_problem_id(problem_id: str) -> str:
    value = problem_id.replace("\\", "/")
    for marker in (
        "TRS_Contextsensitive/",
        "TRS_Innermost/",
        "TRS_Outermost/",
        "TRS_Standard/",
    ):
        if marker in value:
            value = value.split(marker, 1)[1]
            break
    value = value.removesuffix("/proof.cpf3.xml")
    value = value.removesuffix("/proof.cpf.xml")
    value = value.removesuffix(".ari")
    parts = [part for part in value.split("/") if part not in {"", "."}]
    if parts and parts[-1].startswith("sharp_"):
        parts[-1] = f"#{parts[-1][len('sharp_'):]}"
    return "/".join(parts[-2:])


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--proof-events", type=Path, required=True)
    parser.add_argument("--runtime-run", type=Path, action="append", required=True)
    parser.add_argument(
        "--canonical-cache",
        type=Path,
        help=(
            "optional raw-to-canonical cache; without it, alias the live root "
            "directly to the retained certified root record"
        ),
    )
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()

    retained_candidates: dict[str, tuple[int, str]] = {}
    with args.proof_events.open(encoding="utf-8") as source:
        for line in source:
            event = json.loads(line)
            if event.get("level") not in {"top-level", "context-sensitive"}:
                continue
            problem_id = event.get("problem_id")
            cpf = (event.get("input") or {}).get("cpf")
            if isinstance(problem_id, str) and isinstance(cpf, str):
                normalized = normalized_problem_id(problem_id)
                proof_path = (event.get("metrics") or {}).get("proof_path")
                depth = len(proof_path) if isinstance(proof_path, list) else 2**31
                candidate = (depth, hashlib.sha256(cpf.strip().encode()).hexdigest())
                current = retained_candidates.get(normalized)
                if current is None or candidate[0] < current[0]:
                    retained_candidates[normalized] = candidate
    retained_raw = {
        problem_id: candidate[1]
        for problem_id, candidate in retained_candidates.items()
    }

    live_raw: dict[str, str] = {}
    live_fallback: dict[str, str] = {}
    for runtime_run in args.runtime_run:
        event_paths = set(
            glob.iglob(
                str(runtime_run / "**" / "processor-events.jsonl"),
                recursive=True,
            )
        ) | set(
            glob.iglob(
                str(runtime_run / "**" / "*.processor-events.jsonl"),
                recursive=True,
            )
        )
        for event_path in sorted(event_paths):
            with open(event_path, encoding="utf-8") as source:
                for line in source:
                    event = json.loads(line)
                    if event.get("level") not in {"top-level", "context-sensitive"}:
                        continue
                    problem_id = event.get("problem_id")
                    problem_key = (event.get("input") or {}).get("problem_key")
                    if isinstance(problem_id, str) and isinstance(problem_key, str):
                        normalized = normalized_problem_id(problem_id)
                        live_fallback.setdefault(normalized, problem_key)
                        if event.get("strategy_atom") == "utility-guidance":
                            live_raw.setdefault(normalized, problem_key)
                            break
    for problem_id, problem_key in live_fallback.items():
        live_raw.setdefault(problem_id, problem_key)

    cache = sqlite3.connect(args.canonical_cache) if args.canonical_cache else None
    rows = []
    matched: list[tuple[str, str, str]] = [
        (problem_id, retained_raw[problem_id], live_raw[problem_id])
        for problem_id in sorted(retained_raw.keys() & live_raw.keys())
    ]
    matched_ids = {problem_id for problem_id, _, _ in matched}
    for retained_id, retained_key in sorted(retained_raw.items()):
        if retained_id in matched_ids:
            continue
        basename = retained_id.rsplit("/", 1)[-1]
        candidates = [
            (live_id, live_key)
            for live_id, live_key in live_raw.items()
            if live_id.rsplit("/", 1)[-1] == basename
        ]
        if len(candidates) == 1:
            live_id, live_key = candidates[0]
            matched.append((live_id, retained_key, live_key))

    for problem_id, retained_key, live_key in sorted(matched):
        if cache is None:
            canonical_problem_key = retained_key
        else:
            cached = cache.execute(
                "SELECT canonical_cpf, note FROM canonical_cpf_cache WHERE raw_key = ?",
                (retained_key,),
            ).fetchone()
            if cached is None or cached[1] is not None:
                continue
            canonical_problem_key = hashlib.sha256(cached[0].encode()).hexdigest()
        rows.append(
            {
                "problem_id": problem_id,
                "problem_key": live_key,
                "raw_key": live_key,
                "canonical_problem_key": canonical_problem_key,
                "schema": "ferrum.utility-guidance.v2",
            }
        )
    if cache is not None:
        cache.close()

    args.output.parent.mkdir(parents=True, exist_ok=True)
    with args.output.open("w", encoding="utf-8") as output:
        for row in rows:
            print(json.dumps(row, separators=(",", ":"), sort_keys=True), file=output)
    print(
        json.dumps(
            {
                "retained_roots": len(retained_raw),
                "live_roots": len(live_raw),
                "aliases": len(rows),
                "output": str(args.output),
            },
            sort_keys=True,
        )
    )


if __name__ == "__main__":
    main()
