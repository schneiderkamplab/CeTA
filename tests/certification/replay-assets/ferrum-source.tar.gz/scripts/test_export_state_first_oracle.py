#!/usr/bin/env python3

import hashlib
import json
from pathlib import Path
import sqlite3
import subprocess
import tempfile
import unittest

from export_state_first_oracle import (
    certified_state_first_prefix,
    compact_record_candidates,
    normalize_record_evidence,
    replay_priority,
)


SCRIPT = Path(__file__).with_name("export_state_first_oracle.py")


class StateFirstOracleExportTest(unittest.TestCase):
    def test_exclude_base_candidate_prefix_removes_inherited_evidence(self) -> None:
        with tempfile.TemporaryDirectory() as raw_directory:
            directory = Path(raw_directory)
            base = directory / "base.jsonl"
            database = directory / "credited.sqlite"
            output = directory / "oracle.jsonl"
            report = directory / "report.json"
            key = "a" * 64
            base.write_text(
                json.dumps(
                    {
                        "problem_key": key,
                        "schema": "ferrum.utility-guidance.v2",
                        "prefer": [
                            {"candidate": "switch-csr", "status": "solved"},
                            {"candidate": "graph", "status": "solved"},
                        ],
                        "possible": [{"candidate": "switch-csr; default"}],
                        "avoid": [],
                        "timeout": [],
                    }
                )
                + "\n",
                encoding="utf-8",
            )
            with sqlite3.connect(database) as connection:
                connection.executescript(
                    """
                    CREATE TABLE problems(problem_key TEXT PRIMARY KEY, cpf TEXT NOT NULL);
                    CREATE TABLE candidates(
                      problem_key TEXT, candidate TEXT, best_status TEXT,
                      certified_count INTEGER, best_elapsed_ms INTEGER);
                    CREATE TABLE problem_aliases(
                      raw_problem_key TEXT PRIMARY KEY, problem_key TEXT);
                    """
                )
            subprocess.run(
                [
                    "python3", str(SCRIPT), "--base-oracle", str(base),
                    "--campaign-sqlite", str(database),
                    "--exclude-base-candidate-prefix=switch-csr",
                    "--output", str(output), "--report", str(report),
                ],
                check=True,
            )
            records = {
                row["problem_key"]: row
                for row in map(json.loads, output.read_text().splitlines())
                if "problem_key" in row
            }
            self.assertEqual(
                [item["candidate"] for item in records[key]["prefer"]], ["graph"]
            )
            self.assertEqual(records[key]["possible"], [])
            self.assertEqual(json.loads(report.read_text())["excluded_base_candidates"], 2)

    def test_compaction_keeps_legacy_debug_candidates_inline(self) -> None:
        legacy = "ExactLinearPolynomial-{interpretation:" + "x" * 600 + "}"
        record = {
            "prefer": [{"candidate": legacy, "status": "solved"}],
            "possible": [],
            "avoid": [],
            "timeout": [],
        }
        witnesses = {}

        compacted = compact_record_candidates(record, witnesses)

        self.assertEqual(compacted["prefer"][0]["candidate"], legacy)
        self.assertEqual(witnesses, {})

    def test_metadata_and_untouched_state_order_survive_filtered_campaign(self) -> None:
        with tempfile.TemporaryDirectory() as raw_directory:
            directory = Path(raw_directory)
            base = directory / "base.jsonl"
            database = directory / "credited.sqlite"
            output = directory / "oracle.jsonl"
            report = directory / "report.json"
            untouched_key = "a" * 64
            campaign_key = "b" * 64
            metadata_candidate = "exact-poly(hex=5b5d)"
            metadata = {
                "schema": "ferrum.utility-guidance.witness.v1",
                "witness_id": hashlib.sha256(metadata_candidate.encode()).hexdigest(),
                "candidate": metadata_candidate,
            }
            untouched = {
                "problem_key": untouched_key,
                "schema": "ferrum.utility-guidance.v2",
                "prefer": [
                    {"candidate": "second", "status": "solved", "utility_score": 1},
                    {"candidate": "first", "status": "solved", "utility_score": 2},
                ],
                "possible": [],
                "avoid": [],
                "timeout": [],
            }
            base.write_text(
                "\n".join(map(json.dumps, (metadata, untouched))) + "\n",
                encoding="utf-8",
            )
            with sqlite3.connect(database) as connection:
                connection.executescript(
                    """
                    CREATE TABLE problems(problem_key TEXT PRIMARY KEY, cpf TEXT NOT NULL);
                    CREATE TABLE candidates(
                      problem_key TEXT, candidate TEXT, best_status TEXT,
                      certified_count INTEGER, best_elapsed_ms INTEGER);
                    CREATE TABLE problem_aliases(
                      raw_problem_key TEXT PRIMARY KEY, problem_key TEXT);
                    """
                )
                connection.execute(
                    "INSERT INTO problems VALUES (?, '<trsInput/>')", (campaign_key,)
                )
                connection.executemany(
                    "INSERT INTO candidates VALUES (?, ?, 'solved', 1, 4)",
                    (
                        (campaign_key, "exact-poly(hex=5b5d)"),
                        (campaign_key, "graph"),
                    ),
                )
            subprocess.run(
                [
                    "python3", str(SCRIPT), "--base-oracle", str(base),
                    "--campaign-sqlite", str(database),
                    "--exclude-candidate-prefix=exact-", "--output", str(output),
                    "--report", str(report),
                ],
                check=True,
            )
            rows = list(map(json.loads, output.read_text().splitlines()))
            self.assertEqual(rows[0], metadata)
            records = {row["problem_key"]: row for row in rows if "problem_key" in row}
            self.assertEqual(records[untouched_key], untouched)
            self.assertEqual(
                [item["candidate"] for item in records[campaign_key]["prefer"]],
                ["graph"],
            )
            report_data = json.loads(report.read_text())
            self.assertEqual(report_data["base_metadata_records"], 1)
            self.assertEqual(report_data["excluded_campaign_candidates"], 1)

    def test_compact_witness_reference_is_order_independent_and_preserved(self) -> None:
        with tempfile.TemporaryDirectory() as raw_directory:
            directory = Path(raw_directory)
            base = directory / "base.jsonl"
            database = directory / "credited.sqlite"
            output = directory / "oracle.jsonl"
            report = directory / "report.json"
            key = "a" * 64
            candidate = "exact-model(" + "x" * 600 + ")"
            witness_id = hashlib.sha256(candidate.encode()).hexdigest()
            base.write_text(
                json.dumps(
                    {
                        "problem_key": key,
                        "schema": "ferrum.utility-guidance.v2",
                        "prefer": [{"candidate_ref": witness_id, "status": "solved"}],
                        "possible": [],
                        "avoid": [],
                        "timeout": [],
                    }
                )
                + "\n"
                + json.dumps(
                    {
                        "candidate": candidate,
                        "schema": "ferrum.utility-guidance.witness.v1",
                        "witness_id": witness_id,
                    }
                )
                + "\n",
                encoding="utf-8",
            )
            with sqlite3.connect(database) as connection:
                connection.executescript(
                    """
                    CREATE TABLE problems(problem_key TEXT PRIMARY KEY, cpf TEXT NOT NULL);
                    CREATE TABLE candidates(
                      problem_key TEXT, candidate TEXT, best_status TEXT,
                      certified_count INTEGER, best_elapsed_ms INTEGER);
                    CREATE TABLE problem_aliases(
                      raw_problem_key TEXT PRIMARY KEY, problem_key TEXT);
                    """
                )
            subprocess.run(
                [
                    "python3", str(SCRIPT), "--base-oracle", str(base),
                    "--campaign-sqlite", str(database), "--output", str(output),
                    "--report", str(report),
                ],
                check=True,
            )
            rows = [json.loads(line) for line in output.read_text().splitlines()]
            witness_rows = [row for row in rows if row.get("witness_id") == witness_id]
            record_rows = [row for row in rows if row.get("problem_key") == key]
            self.assertEqual(len(witness_rows), 1)
            self.assertEqual(record_rows[0]["prefer"][0]["candidate_ref"], witness_id)

    def test_certified_dp_composition_exposes_state_first_prefix(self) -> None:
        self.assertEqual(certified_state_first_prefix("dp(graph;size-change)"), "dp")
        self.assertIsNone(certified_state_first_prefix("graph;size-change"))

    def test_certification_manifest_follows_content_checked_canonical_alias(self) -> None:
        with tempfile.TemporaryDirectory() as raw_directory:
            directory = Path(raw_directory)
            base = directory / "base.jsonl"
            database = directory / "credited.sqlite"
            manifest = directory / "certified.jsonl"
            output = directory / "oracle.jsonl"
            report = directory / "report.json"
            raw = "a" * 64
            canonical = "b" * 64
            candidate = "exact-matrix(hex=5b5b2266222c5b315d2c5b5d5d5d)"
            base.write_text("", encoding="utf-8")
            manifest.write_text(
                json.dumps(
                    {
                        "scope": "canonical",
                        "problem_key": raw,
                        "candidate": candidate,
                        "recorded_implementation_hash": None,
                        "recheck_status": "certified",
                    }
                )
                + "\n",
                encoding="utf-8",
            )
            with sqlite3.connect(database) as connection:
                connection.executescript(
                    """
                    CREATE TABLE problems(problem_key TEXT PRIMARY KEY, cpf TEXT NOT NULL);
                    CREATE TABLE candidates(
                      problem_key TEXT, candidate TEXT, best_status TEXT,
                      certified_count INTEGER, best_elapsed_ms INTEGER);
                    CREATE TABLE problem_aliases(
                      raw_problem_key TEXT PRIMARY KEY, problem_key TEXT);
                    """
                )
                connection.execute(
                    "INSERT INTO problems VALUES (?, '<trsInput/>')", (canonical,)
                )
                connection.execute(
                    "INSERT INTO candidates VALUES (?, ?, 'transformed_strong', 1, 4)",
                    (canonical, candidate),
                )
                connection.execute(
                    "INSERT INTO problem_aliases VALUES (?, ?)", (raw, canonical)
                )
            subprocess.run(
                [
                    "python3", str(SCRIPT), "--base-oracle", str(base),
                    "--campaign-sqlite", str(database),
                    "--certified-manifest", str(manifest), "--output", str(output),
                    "--report", str(report),
                ],
                check=True,
            )
            records = {
                row["problem_key"]: row
                for row in map(json.loads, output.read_text().splitlines())
            }
            self.assertEqual(
                [item["candidate"] for item in records[canonical]["prefer"]],
                [candidate],
            )
            self.assertEqual(
                json.loads(report.read_text())["uncertified_positive_evidence_rows_rejected"],
                0,
            )

    def test_current_checker_rejection_invalidates_stale_base_record(self) -> None:
        with tempfile.TemporaryDirectory() as raw_directory:
            directory = Path(raw_directory)
            base = directory / "base.jsonl"
            invalidations = directory / "invalidations.txt"
            database = directory / "credited.sqlite"
            output = directory / "oracle.jsonl"
            report = directory / "report.json"
            key = "a" * 64
            base.write_text(
                json.dumps(
                    {
                        "problem_key": key,
                        "schema": "ferrum.utility-guidance.v2",
                        "prefer": [{"candidate": "stale", "status": "solved"}],
                        "possible": [],
                        "avoid": [],
                        "timeout": [],
                    }
                )
                + "\n",
                encoding="utf-8",
            )
            invalidations.write_text(f"# rejected by current checker\n{key}\n", encoding="utf-8")
            with sqlite3.connect(database) as connection:
                connection.executescript(
                    """
                    CREATE TABLE problems(
                      problem_key TEXT PRIMARY KEY, cpf TEXT NOT NULL);
                    CREATE TABLE candidates(
                      problem_key TEXT, candidate TEXT, best_status TEXT,
                      certified_count INTEGER, best_elapsed_ms INTEGER);
                    CREATE TABLE problem_aliases(
                      raw_problem_key TEXT PRIMARY KEY, problem_key TEXT);
                    """
                )
                connection.execute(
                    "INSERT INTO problems VALUES (?, '<dpInput/>')", (key,)
                )
                connection.execute(
                    "INSERT INTO candidates VALUES (?, 'replacement', "
                    "'solved', 1, 4)",
                    (key,),
                )
            subprocess.run(
                [
                    "python3",
                    str(SCRIPT),
                    "--base-oracle",
                    str(base),
                    "--invalidate-base-key-file",
                    str(invalidations),
                    "--campaign-sqlite",
                    str(database),
                    "--output",
                    str(output),
                    "--report",
                    str(report),
                ],
                check=True,
            )
            records = {
                row["problem_key"]: row
                for row in map(json.loads, output.read_text().splitlines())
            }
            self.assertEqual(
                [item["candidate"] for item in records[key]["prefer"]],
                ["replacement"],
            )
            self.assertTrue(records[key]["current_checker_invalidation"])
            report_data = json.loads(report.read_text())
            self.assertEqual(report_data["invalidated_base_records"], 1)
            self.assertEqual(report_data["invalidated_base_problem_keys"], [key])
            self.assertEqual(report_data["missing_invalidated_base_problem_keys"], [])
            self.assertEqual(
                report_data["current_checker_invalidation_replacements"], 1
            )

    def test_replace_campaign_keys_removes_cross_state_base_candidates(self) -> None:
        with tempfile.TemporaryDirectory() as raw_directory:
            directory = Path(raw_directory)
            base = directory / "base.jsonl"
            database = directory / "credited.sqlite"
            output = directory / "oracle.jsonl"
            report = directory / "report.json"
            key = "a" * 64
            base.write_text(
                json.dumps(
                    {
                        "problem_key": key,
                        "schema": "ferrum.utility-guidance.v2",
                        "prefer": [
                            {"candidate": "pooled-from-another-state", "status": "solved"}
                        ],
                        "possible": [],
                        "avoid": [],
                        "timeout": [],
                    }
                )
                + "\n",
                encoding="utf-8",
            )
            with sqlite3.connect(database) as connection:
                connection.executescript(
                    """
                    CREATE TABLE problems(problem_key TEXT PRIMARY KEY, cpf TEXT NOT NULL);
                    CREATE TABLE candidates(
                      problem_key TEXT, candidate TEXT, best_status TEXT,
                      certified_count INTEGER, best_elapsed_ms INTEGER);
                    CREATE TABLE problem_aliases(
                      raw_problem_key TEXT PRIMARY KEY, problem_key TEXT);
                    """
                )
                connection.execute("INSERT INTO problems VALUES (?, '<dpInput/>')", (key,))
                connection.execute(
                    "INSERT INTO candidates VALUES (?, 'graph', 'solved', 1, 4)",
                    (key,),
                )
            subprocess.run(
                [
                    "python3", str(SCRIPT), "--base-oracle", str(base),
                    "--replace-campaign-keys", "--campaign-sqlite", str(database),
                    "--output", str(output), "--report", str(report),
                ],
                check=True,
            )
            record = json.loads(output.read_text())
            self.assertEqual(
                [item["candidate"] for item in record["prefer"]], ["graph"]
            )
            self.assertEqual(
                json.loads(report.read_text())["replaced_campaign_base_records"], 1
            )

    def test_replace_campaign_keys_prunes_dangling_base_alias(self) -> None:
        with tempfile.TemporaryDirectory() as raw_directory:
            directory = Path(raw_directory)
            base = directory / "base.jsonl"
            database = directory / "credited.sqlite"
            output = directory / "oracle.jsonl"
            report = directory / "report.json"
            canonical = "a" * 64
            alias = "b" * 64
            replacement = "c" * 64
            base.write_text(
                json.dumps(
                    {
                        "problem_key": canonical,
                        "schema": "ferrum.utility-guidance.v2",
                        "prefer": [], "possible": [], "avoid": [], "timeout": [],
                    }
                )
                + "\n"
                + json.dumps(
                    {
                        "problem_key": alias,
                        "canonical_problem_key": canonical,
                        "schema": "ferrum.utility-guidance.v2",
                        "prefer": [], "possible": [], "avoid": [], "timeout": [],
                    }
                )
                + "\n",
                encoding="utf-8",
            )
            with sqlite3.connect(database) as connection:
                connection.executescript(
                    """
                    CREATE TABLE problems(problem_key TEXT PRIMARY KEY, cpf TEXT NOT NULL);
                    CREATE TABLE candidates(
                      problem_key TEXT, candidate TEXT, best_status TEXT,
                      certified_count INTEGER, best_elapsed_ms INTEGER);
                    CREATE TABLE problem_aliases(
                      raw_problem_key TEXT, problem_key TEXT,
                      PRIMARY KEY(raw_problem_key, problem_key));
                    """
                )
                connection.execute(
                    "INSERT INTO problems VALUES (?, '<dpInput/>')", (canonical,)
                )
                connection.execute(
                    "INSERT INTO problems VALUES (?, '<dpInput/>')", (replacement,)
                )
                connection.execute(
                    "INSERT INTO candidates VALUES (?, 'stale', 'solved', 0, 1)",
                    (canonical,),
                )
                connection.execute(
                    "INSERT INTO candidates VALUES (?, 'graph', 'solved', 1, 1)",
                    (replacement,),
                )
            subprocess.run(
                [
                    "python3", str(SCRIPT), "--base-oracle", str(base),
                    "--replace-campaign-keys", "--campaign-sqlite", str(database),
                    "--output", str(output), "--report", str(report),
                ],
                check=True,
            )
            records = {
                row["problem_key"]: row
                for row in map(json.loads, output.read_text().splitlines())
            }
            self.assertNotIn(alias, records)
            self.assertEqual(
                json.loads(report.read_text())["dangling_base_aliases_pruned"], 1
            )

    def test_invalidation_without_replacement_emits_shadowing_tombstone(self) -> None:
        with tempfile.TemporaryDirectory() as raw_directory:
            directory = Path(raw_directory)
            key = "d" * 64
            base = directory / "base.jsonl"
            invalidations = directory / "invalidations.txt"
            database = directory / "credited.sqlite"
            output = directory / "oracle.jsonl"
            report = directory / "report.json"
            base.write_text(
                json.dumps(
                    {
                        "problem_key": key,
                        "schema": "ferrum.utility-guidance.v2",
                        "prefer": [{"candidate": "rejected", "status": "solved"}],
                        "possible": [], "avoid": [], "timeout": [],
                    }
                ) + "\n"
            )
            invalidations.write_text(key + "\n")
            with sqlite3.connect(database) as connection:
                connection.executescript(
                    """
                    CREATE TABLE problems(problem_key TEXT PRIMARY KEY, cpf TEXT NOT NULL);
                    CREATE TABLE candidates(
                      problem_key TEXT, candidate TEXT, best_status TEXT,
                      certified_count INTEGER, best_elapsed_ms INTEGER);
                    """
                )
            subprocess.run(
                [
                    "python3", str(SCRIPT), "--base-oracle", str(base),
                    "--invalidate-base-key-file", str(invalidations),
                    "--campaign-sqlite", str(database), "--output", str(output),
                    "--report", str(report),
                ],
                check=True,
            )
            record = json.loads(output.read_text())
            self.assertEqual(record["problem_key"], key)
            self.assertEqual(record["prefer"], [])
            self.assertEqual(
                [item["candidate"] for item in record["avoid"]], ["rejected"]
            )
            self.assertTrue(record["current_checker_invalidation"])
            self.assertEqual(
                json.loads(report.read_text())["current_checker_invalidation_tombstones"],
                1,
            )

    def test_atomic_state_transition_precedes_certified_whole_search(self) -> None:
        items = [
            {
                "candidate": "dp(graph;timeout(60s,parallel(poly|matrix)))",
                "certified_count": 1,
                "best_elapsed_ms": 1,
            },
            {
                "candidate": "dp",
                "certified_count": 0,
                "best_elapsed_ms": 10,
            },
        ]
        items.sort(key=replay_priority)
        self.assertEqual(items[0]["candidate"], "dp")

    def test_exact_max_polynomial_precedes_open_ended_synthesis(self) -> None:
        items = [
            {
                "candidate": "max-poly(max-constant=4,max-coefficient=4)",
                "certified_count": 1,
                "best_elapsed_ms": 0,
            },
            {
                "candidate": "exact-max-poly(hex=5b5d)",
                "certified_count": 0,
                "best_elapsed_ms": 0,
            },
        ]
        items.sort(key=replay_priority)
        self.assertEqual(items[0]["candidate"], "exact-max-poly(hex=5b5d)")

    def test_complete_reduction_pair_fragment_precedes_model_only_witness(self) -> None:
        items = [
            {
                "candidate": "exact-poly(hex=5b5d)",
                "source_priority": 2,
            },
            {
                "candidate": "exact-red-pair(hex=5b5d)",
                "source_priority": 2,
            },
        ]
        items.sort(key=replay_priority)
        self.assertEqual(items[0]["candidate"], "exact-red-pair(hex=5b5d)")

        size_change_items = [
            {"candidate": "exact-poly(hex=5b5d)", "source_priority": 2},
            {
                "candidate": "exact-size-change(hex=5b5d)",
                "source_priority": 2,
            },
        ]
        size_change_items.sort(key=replay_priority)
        self.assertEqual(
            size_change_items[0]["candidate"], "exact-size-change(hex=5b5d)"
        )

    def test_state_normalization_precedes_exact_reduction_pair(self) -> None:
        items = [
            {"candidate": "exact-matrix(hex=5b5d)", "source_priority": 2},
            {"candidate": "usable-rules", "source_priority": 2},
        ]
        items.sort(key=replay_priority)
        self.assertEqual(items[0]["candidate"], "usable-rules")

    def test_relative_transformations_precede_child_reduction_pairs(self) -> None:
        for transformation in (
            "relative-flat-context-closure",
            "exact-relative-semantic-labeling(carrier-size=2,hex=5b5d)",
        ):
            items = [
                {"candidate": "exact-matrix(hex=5b5d)", "source_priority": 2},
                {"candidate": transformation, "source_priority": 2},
            ]
            items.sort(key=replay_priority)
            self.assertEqual(items[0]["candidate"], transformation)

    def test_reversal_precedes_flat_context_then_reduction_pair(self) -> None:
        items = [
            {"candidate": "exact-matrix(hex=5b5d)", "source_priority": 2},
            {"candidate": "relative-flat-context-closure", "source_priority": 2},
            {"candidate": "string-reversal", "source_priority": 2},
        ]
        items.sort(key=replay_priority)
        self.assertEqual(
            [item["candidate"] for item in items],
            [
                "string-reversal",
                "relative-flat-context-closure",
                "exact-matrix(hex=5b5d)",
            ],
        )

    def test_newer_certified_campaign_precedes_older_exact_witness(self) -> None:
        items = [
            {
                "candidate": "exact-matrix(hex=5b5d)",
                "certified_count": 1,
                "best_elapsed_ms": 1,
                "source_priority": 1,
            },
            {
                "candidate": "exact-poly(hex=5b5d)",
                "certified_count": 1,
                "best_elapsed_ms": 10,
                "source_priority": 2,
            },
        ]
        items.sort(key=replay_priority)
        self.assertEqual(items[0]["candidate"], "exact-poly(hex=5b5d)")

    def test_certified_candidate_cannot_remain_in_avoid(self) -> None:
        record = {
            "prefer": [
                {
                    "candidate": "dp",
                    "status": "solved",
                    "certified_count": 1,
                    "solved_count": 1,
                    "failed_count": 0,
                    "attempts": 1,
                    "utility_score": 2000.0,
                    "best_elapsed_ms": 20,
                }
            ],
            "possible": [],
            "avoid": [
                {
                    "candidate": "dp",
                    "status": "failed",
                    "certified_count": 0,
                    "solved_count": 0,
                    "failed_count": 1,
                    "attempts": 1,
                    "utility_score": -60.0,
                    "best_elapsed_ms": 10,
                }
            ],
            "timeout": [],
        }
        normalize_record_evidence(record)
        self.assertEqual(len(record["prefer"]), 1)
        self.assertEqual(record["prefer"][0]["status"], "solved")
        self.assertEqual(record["avoid"], [])

    def test_accepts_credited_status_map_database_directly(self) -> None:
        with tempfile.TemporaryDirectory() as raw_directory:
            directory = Path(raw_directory)
            base = directory / "base.jsonl"
            database = directory / "credited.sqlite"
            output = directory / "oracle.jsonl"
            report = directory / "report.json"
            solved = "a" * 64
            transformed = "b" * 64
            alias = "c" * 64
            weak = "d" * 64
            base.write_text("", encoding="utf-8")
            with sqlite3.connect(database) as connection:
                connection.executescript(
                    """
                    CREATE TABLE problems(
                      problem_key TEXT PRIMARY KEY, cpf TEXT NOT NULL);
                    CREATE TABLE candidates(
                      problem_key TEXT, candidate TEXT, best_status TEXT,
                      certified_count INTEGER, best_elapsed_ms INTEGER);
                    CREATE TABLE problem_aliases(
                      raw_problem_key TEXT PRIMARY KEY, problem_key TEXT);
                    """
                )
                connection.executemany(
                    "INSERT INTO problems VALUES (?, '<dpInput/>')",
                    [(solved,), (transformed,), (weak,)],
                )
                connection.execute(
                    "INSERT INTO candidates VALUES (?, 'size-change', "
                    "'solved', 1, 4)",
                    (solved,),
                )
                connection.execute(
                    "INSERT INTO candidates VALUES (?, 'graph', "
                    "'transformed_strong', 1, 2)",
                    (transformed,),
                )
                connection.execute(
                    "INSERT INTO problem_aliases VALUES (?, ?)",
                    (alias, solved),
                )
                connection.execute(
                    "INSERT INTO candidates VALUES (?, 'usable-rules', "
                    "'transformed_weak', 0, 1)",
                    (weak,),
                )
            subprocess.run(
                [
                    "python3",
                    str(SCRIPT),
                    "--base-oracle",
                    str(base),
                    "--campaign-sqlite",
                    str(database),
                    "--output",
                    str(output),
                    "--report",
                    str(report),
                ],
                check=True,
            )
            records = {
                row["problem_key"]: row
                for row in map(json.loads, output.read_text(encoding="utf-8").splitlines())
            }
            self.assertEqual(records[solved]["prefer"][0]["candidate"], "size-change")
            self.assertEqual(records[transformed]["possible"][0]["candidate"], "graph")
            self.assertEqual(records[weak]["possible"][0]["candidate"], "usable-rules")
            self.assertEqual(records[weak]["possible"][0]["status"], "transformed_weak")
            self.assertNotIn("canonical_problem_key", records[alias])
            self.assertEqual(
                records[alias]["prefer"][0]["candidate"], "size-change"
            )
            self.assertEqual(
                json.loads(report.read_text(encoding="utf-8"))[
                    "uncertified_positive_evidence_rows_rejected"
                ],
                0,
            )

    def test_rejected_assembly_cannot_remain_weak_guidance(self) -> None:
        with tempfile.TemporaryDirectory() as raw_directory:
            directory = Path(raw_directory)
            base = directory / "base.jsonl"
            database = directory / "campaign.sqlite"
            output = directory / "oracle.jsonl"
            report = directory / "report.json"
            raw = "a" * 64
            base.write_text("", encoding="utf-8")
            with sqlite3.connect(database) as connection:
                connection.executescript(
                    """
                    CREATE TABLE states(
                      raw_hash TEXT PRIMARY KEY, canonical_hash TEXT NOT NULL);
                    CREATE TABLE trials(
                      task_key TEXT PRIMARY KEY, candidate TEXT NOT NULL);
                    CREATE TABLE assembled_proofs(
                      raw_hash TEXT, transition_task_key TEXT, elapsed_ms INTEGER,
                      checker_result TEXT, deterministic_recheck INTEGER);
                    CREATE TABLE evidence(
                      raw_hash TEXT, canonical_hash TEXT, processor_atom TEXT,
                      outcome TEXT, certification_status TEXT, elapsed_ms INTEGER);
                    CREATE VIEW oracle_evidence AS SELECT * FROM evidence;
                    """
                )
                connection.execute("INSERT INTO states VALUES (?, ?)", (raw, raw))
                connection.execute(
                    "INSERT INTO trials VALUES ('bad-transform', "
                    "'weak-poly(min-constant=-2,max-constant=8,max-coefficient=8)')"
                )
                connection.execute(
                    "INSERT INTO evidence VALUES (?, ?, "
                    "'weak-poly(min-constant=-2,max-constant=8,max-coefficient=8)', "
                    "'transformed', 'assembly-required', 7)",
                    (raw, raw),
                )
                connection.execute(
                    "INSERT INTO assembled_proofs VALUES "
                    "(?, 'bad-transform', 11, 'REJECTED', 0)",
                    (raw,),
                )
            subprocess.run(
                [
                    "python3",
                    str(SCRIPT),
                    "--base-oracle",
                    str(base),
                    "--campaign-sqlite",
                    str(database),
                    "--output",
                    str(output),
                    "--report",
                    str(report),
                ],
                check=True,
            )
            self.assertEqual(output.read_text(encoding="utf-8"), "")
            report_data = json.loads(report.read_text(encoding="utf-8"))
            self.assertEqual(
                report_data["uncertified_positive_evidence_rows_rejected"], 1
            )
            self.assertEqual(
                report_data["uncertified_positive_evidence_examples"][0]["reason"],
                "checker_rejected_assembly",
            )

    def test_residual_manifest_is_retained_as_weak_guidance(self) -> None:
        with tempfile.TemporaryDirectory() as raw_directory:
            directory = Path(raw_directory)
            base = directory / "base.jsonl"
            database = directory / "campaign.sqlite"
            output = directory / "oracle.jsonl"
            report = directory / "report.json"
            raw = "a" * 64
            candidate = "exact-dp-transform(hex=5b5d)"
            base.write_text("", encoding="utf-8")
            with sqlite3.connect(database) as connection:
                connection.executescript(
                    """
                    CREATE TABLE evidence(
                      raw_hash TEXT, canonical_hash TEXT, processor_atom TEXT,
                      outcome TEXT, certification_status TEXT, elapsed_ms INTEGER,
                      implementation_hash TEXT);
                    CREATE VIEW oracle_evidence AS SELECT * FROM evidence;
                    """
                )
                connection.execute(
                    "INSERT INTO evidence VALUES (?, ?, ?, 'transformed', "
                    "'residual-manifest', 7, NULL)",
                    (raw, raw, candidate),
                )
            subprocess.run(
                [
                    "python3", str(SCRIPT), "--base-oracle", str(base),
                    "--campaign-sqlite", str(database), "--output", str(output),
                    "--report", str(report),
                ],
                check=True,
            )
            record = json.loads(output.read_text(encoding="utf-8").splitlines()[0])
            self.assertEqual(record["problem_key"], raw)
            self.assertEqual(record["possible"][0]["candidate"], candidate)
            self.assertEqual(record["possible"][0]["status"], "transformed_weak")
            report_data = json.loads(report.read_text(encoding="utf-8"))
            self.assertEqual(report_data["positive_evidence_entries_exported"], 1)
            self.assertEqual(report_data["uncertified_positive_evidence_rows_rejected"], 0)

    def test_accepts_deduplicated_frozen_union_manifest(self) -> None:
        with tempfile.TemporaryDirectory() as raw_directory:
            directory = Path(raw_directory)
            base = directory / "base.jsonl"
            database = directory / "campaign.sqlite"
            manifest = directory / "manifest.jsonl"
            output = directory / "oracle.jsonl"
            report = directory / "report.json"
            raw = "a" * 64
            implementation = "c" * 64
            base.write_text("", encoding="utf-8")
            manifest.write_text(
                json.dumps(
                    {
                        "deterministic_certified": True,
                        "origins": [
                            {
                                "raw_hash": raw,
                                "task_key": "terminal-task",
                                "processor_atom": "poly",
                                "implementation_hash": implementation,
                            },
                            {
                                "raw_hash": raw,
                                "task_key": "assembled-task",
                                "processor_atom": "assembled",
                                "implementation_hash": implementation,
                            },
                        ],
                    }
                )
                + "\n",
                encoding="utf-8",
            )
            with sqlite3.connect(database) as connection:
                connection.executescript(
                    """
                    CREATE TABLE states(
                      raw_hash TEXT PRIMARY KEY, canonical_hash TEXT NOT NULL);
                    CREATE TABLE trials(
                      task_key TEXT PRIMARY KEY, candidate TEXT NOT NULL);
                    CREATE TABLE assembled_proofs(
                      raw_hash TEXT, transition_task_key TEXT, elapsed_ms INTEGER,
                      checker_result TEXT, deterministic_recheck INTEGER,
                      implementation_hash TEXT);
                    CREATE TABLE evidence(
                      raw_hash TEXT, canonical_hash TEXT, processor_atom TEXT,
                      outcome TEXT, certification_status TEXT, elapsed_ms INTEGER,
                      implementation_hash TEXT);
                    CREATE VIEW oracle_evidence AS SELECT * FROM evidence;
                    """
                )
                connection.execute("INSERT INTO states VALUES (?, ?)", (raw, raw))
                connection.execute(
                    "INSERT INTO trials VALUES ('assembled-task', 'graph')"
                )
                connection.execute(
                    "INSERT INTO evidence VALUES (?, ?, 'poly', 'solved', "
                    "'certified-full', 5, ?)",
                    (raw, raw, implementation),
                )
                connection.execute(
                    "INSERT INTO assembled_proofs VALUES (?, 'assembled-task', 7, "
                    "'CERTIFIED', 1, ?)",
                    (raw, implementation),
                )
            subprocess.run(
                [
                    "python3",
                    str(SCRIPT),
                    "--base-oracle",
                    str(base),
                    "--campaign-sqlite",
                    str(database),
                    "--certified-manifest",
                    str(manifest),
                    "--output",
                    str(output),
                    "--report",
                    str(report),
                ],
                check=True,
            )
            record = json.loads(output.read_text(encoding="utf-8"))
            self.assertEqual(
                {row["candidate"] for row in record["prefer"]}, {"poly", "graph"}
            )
            report_data = json.loads(report.read_text(encoding="utf-8"))
            self.assertEqual(report_data["certified_positive_evidence_rows_promoted"], 2)
            self.assertEqual(report_data["uncertified_positive_evidence_rows_rejected"], 0)

    def test_exports_exact_transform_and_assembled_solution(self) -> None:
        with tempfile.TemporaryDirectory() as raw_directory:
            directory = Path(raw_directory)
            base = directory / "base.jsonl"
            database = directory / "campaign.sqlite"
            output = directory / "oracle.jsonl"
            report = directory / "report.json"
            raw = "a" * 64
            canonical = "b" * 64
            base.write_text(
                json.dumps(
                    {
                        "schema": "ferrum.utility-guidance.v2",
                        "problem_key": raw,
                        "canonical_problem_key": canonical,
                    }
                )
                + "\n"
                + json.dumps(
                    {
                        "schema": "ferrum.utility-guidance.v2",
                        "problem_key": canonical,
                        "prefer": [
                            {
                                "candidate": "poly",
                                "status": "transformed_weak",
                                "best_elapsed_ms": None,
                            }
                        ],
                        "possible": [],
                        "avoid": [],
                        "timeout": [],
                    }
                )
                + "\n",
                encoding="utf-8",
            )
            with sqlite3.connect(database) as connection:
                connection.executescript(
                    """
                    CREATE TABLE states(
                      raw_hash TEXT PRIMARY KEY, canonical_hash TEXT NOT NULL);
                    CREATE TABLE trials(
                      task_key TEXT PRIMARY KEY, candidate TEXT NOT NULL);
                    CREATE TABLE assembled_proofs(
                      raw_hash TEXT, transition_task_key TEXT, elapsed_ms INTEGER,
                      checker_result TEXT, deterministic_recheck INTEGER);
                    CREATE TABLE evidence(
                      raw_hash TEXT, canonical_hash TEXT, processor_atom TEXT,
                      outcome TEXT, certification_status TEXT, elapsed_ms INTEGER);
                    CREATE VIEW oracle_evidence AS SELECT * FROM evidence;
                    """
                )
                connection.execute("INSERT INTO states VALUES (?, ?)", (raw, canonical))
                connection.execute(
                    "INSERT INTO trials VALUES ('transform', 'csr-innermost')"
                )
                connection.execute(
                    "INSERT INTO evidence VALUES (?, ?, 'poly', 'transformed', "
                    "'certified-fragment', 7)",
                    (raw, canonical),
                )
                connection.execute(
                    "INSERT INTO assembled_proofs VALUES (?, 'transform', 11, "
                    "'CERTIFIED', 1)",
                    (raw,),
                )
            subprocess.run(
                [
                    "python3",
                    str(SCRIPT),
                    "--base-oracle",
                    str(base),
                    "--campaign-sqlite",
                    str(database),
                    "--output",
                    str(output),
                    "--report",
                    str(report),
                ],
                check=True,
            )
            records = {
                row["problem_key"]: row
                for row in map(json.loads, output.read_text(encoding="utf-8").splitlines())
            }
            exact = records[raw]
            self.assertNotIn("canonical_problem_key", exact)
            self.assertEqual(exact["prefer"][0]["candidate"], "csr-innermost")
            self.assertEqual(exact["prefer"][0]["status"], "solved")
            self.assertEqual(exact["possible"][0]["candidate"], "poly")
            self.assertEqual(exact["possible"][0]["status"], "transformed_weak")
            self.assertEqual(exact["possible"][0]["best_elapsed_ms"], 7)

    def test_exports_runtime_raw_alias_to_certified_state(self) -> None:
        with tempfile.TemporaryDirectory() as raw_directory:
            directory = Path(raw_directory)
            base = directory / "base.jsonl"
            database = directory / "campaign.sqlite"
            output = directory / "oracle.jsonl"
            report = directory / "report.json"
            raw = "a" * 64
            runtime_alias = "c" * 64
            base.write_text("", encoding="utf-8")
            with sqlite3.connect(database) as connection:
                connection.executescript(
                    """
                    CREATE TABLE states(
                      raw_hash TEXT PRIMARY KEY, canonical_hash TEXT NOT NULL);
                    CREATE TABLE trials(
                      task_key TEXT PRIMARY KEY, candidate TEXT NOT NULL);
                    CREATE TABLE assembled_proofs(
                      raw_hash TEXT, transition_task_key TEXT, elapsed_ms INTEGER,
                      checker_result TEXT, deterministic_recheck INTEGER);
                    CREATE TABLE state_aliases(
                      alias_raw_hash TEXT PRIMARY KEY, state_raw_hash TEXT NOT NULL,
                      alias_kind TEXT NOT NULL);
                    CREATE TABLE evidence(
                      raw_hash TEXT, canonical_hash TEXT, processor_atom TEXT,
                      outcome TEXT, certification_status TEXT, elapsed_ms INTEGER);
                    CREATE VIEW oracle_evidence AS SELECT * FROM evidence;
                    """
                )
                connection.execute("INSERT INTO states VALUES (?, ?)", (raw, raw))
                connection.execute(
                    "INSERT INTO evidence VALUES (?, ?, 'poly', 'solved', "
                    "'certified-full', 5)",
                    (raw, raw),
                )
                connection.execute(
                    "INSERT INTO evidence VALUES (?, ?, 'kbo', 'solved', "
                    "'failed', 6)",
                    (raw, raw),
                )
                connection.execute(
                    "INSERT INTO state_aliases VALUES (?, ?, 'event-content-address')",
                    (runtime_alias, raw),
                )
            subprocess.run(
                [
                    "python3",
                    str(SCRIPT),
                    "--base-oracle",
                    str(base),
                    "--campaign-sqlite",
                    str(database),
                    "--output",
                    str(output),
                    "--report",
                    str(report),
                ],
                check=True,
            )
            records = {
                row["problem_key"]: row
                for row in map(json.loads, output.read_text(encoding="utf-8").splitlines())
            }
            self.assertNotIn("canonical_problem_key", records[runtime_alias])
            self.assertEqual(records[raw]["prefer"][0]["candidate"], "poly")
            report_data = json.loads(report.read_text())
            self.assertEqual(report_data["raw_aliases_exported"], 1)
            self.assertEqual(
                report_data["uncertified_positive_evidence_rows_rejected"], 1
            )
            self.assertEqual(
                report_data["uncertified_positive_evidence_examples"][0]["reason"],
                "positive_without_certification",
            )

    def test_runtime_alias_merges_into_existing_direct_record(self) -> None:
        with tempfile.TemporaryDirectory() as raw_directory:
            directory = Path(raw_directory)
            base = directory / "base.jsonl"
            database = directory / "campaign.sqlite"
            output = directory / "oracle.jsonl"
            report = directory / "report.json"
            raw = "a" * 64
            runtime_alias = "c" * 64
            base.write_text(
                json.dumps(
                    {
                        "problem_key": runtime_alias,
                        "schema": "ferrum.utility-guidance.v2",
                        "prefer": [{"candidate": "dp", "status": "solved"}],
                        "possible": [],
                        "avoid": [],
                        "timeout": [],
                    }
                )
                + "\n",
                encoding="utf-8",
            )
            with sqlite3.connect(database) as connection:
                connection.executescript(
                    """
                    CREATE TABLE states(
                      raw_hash TEXT PRIMARY KEY, canonical_hash TEXT NOT NULL);
                    CREATE TABLE trials(
                      task_key TEXT PRIMARY KEY, candidate TEXT NOT NULL);
                    CREATE TABLE assembled_proofs(
                      raw_hash TEXT, transition_task_key TEXT, elapsed_ms INTEGER,
                      checker_result TEXT, deterministic_recheck INTEGER);
                    CREATE TABLE state_aliases(
                      alias_raw_hash TEXT PRIMARY KEY, state_raw_hash TEXT NOT NULL,
                      alias_kind TEXT NOT NULL);
                    CREATE TABLE evidence(
                      raw_hash TEXT, canonical_hash TEXT, processor_atom TEXT,
                      outcome TEXT, certification_status TEXT, elapsed_ms INTEGER);
                    CREATE VIEW oracle_evidence AS SELECT * FROM evidence;
                    """
                )
                connection.execute("INSERT INTO states VALUES (?, ?)", (raw, raw))
                connection.execute(
                    "INSERT INTO evidence VALUES (?, ?, 'dp(graph;size-change)', "
                    "'solved', 'certified-full', 5)",
                    (raw, raw),
                )
                connection.execute(
                    "INSERT INTO state_aliases VALUES (?, ?, 'runtime-raw')",
                    (runtime_alias, raw),
                )
            subprocess.run(
                [
                    "python3",
                    str(SCRIPT),
                    "--base-oracle",
                    str(base),
                    "--campaign-sqlite",
                    str(database),
                    "--output",
                    str(output),
                    "--report",
                    str(report),
                ],
                check=True,
            )
            records = {
                row["problem_key"]: row
                for row in map(
                    json.loads, output.read_text(encoding="utf-8").splitlines()
                )
            }
            candidates = {
                item["candidate"] for item in records[runtime_alias]["prefer"]
            }
            self.assertEqual(candidates, {"dp", "dp(graph;size-change)"})
            self.assertEqual(
                json.loads(report.read_text())["raw_aliases_merged_into_direct_records"],
                1,
            )

    def test_runtime_alias_does_not_contaminate_historical_canonical_target(self) -> None:
        with tempfile.TemporaryDirectory() as raw_directory:
            directory = Path(raw_directory)
            base = directory / "base.jsonl"
            database = directory / "campaign.sqlite"
            output = directory / "oracle.jsonl"
            report = directory / "report.json"
            raw = "a" * 64
            old_canonical = "b" * 64
            runtime_alias = "c" * 64
            rows = [
                {
                    "problem_key": old_canonical,
                    "schema": "ferrum.utility-guidance.v2",
                    "prefer": [{"candidate": "dp", "status": "solved"}],
                    "possible": [], "avoid": [], "timeout": [],
                },
                {
                    "problem_key": runtime_alias,
                    "canonical_problem_key": old_canonical,
                    "schema": "ferrum.utility-guidance.v2",
                    "prefer": [], "possible": [], "avoid": [], "timeout": [],
                },
            ]
            base.write_text(
                "".join(json.dumps(row) + "\n" for row in rows),
                encoding="utf-8",
            )
            with sqlite3.connect(database) as connection:
                connection.executescript(
                    """
                    CREATE TABLE states(
                      raw_hash TEXT PRIMARY KEY, canonical_hash TEXT NOT NULL);
                    CREATE TABLE trials(
                      task_key TEXT PRIMARY KEY, candidate TEXT NOT NULL);
                    CREATE TABLE assembled_proofs(
                      raw_hash TEXT, transition_task_key TEXT, elapsed_ms INTEGER,
                      checker_result TEXT, deterministic_recheck INTEGER);
                    CREATE TABLE state_aliases(
                      alias_raw_hash TEXT PRIMARY KEY, state_raw_hash TEXT NOT NULL,
                      alias_kind TEXT NOT NULL);
                    CREATE TABLE evidence(
                      raw_hash TEXT, canonical_hash TEXT, processor_atom TEXT,
                      outcome TEXT, certification_status TEXT, elapsed_ms INTEGER);
                    CREATE VIEW oracle_evidence AS SELECT * FROM evidence;
                    """
                )
                connection.execute("INSERT INTO states VALUES (?, ?)", (raw, raw))
                connection.execute(
                    "INSERT INTO evidence VALUES (?, ?, "
                    "'dp(graph;size-change)', 'solved', 'certified-full', 5)",
                    (raw, raw),
                )
                connection.execute(
                    "INSERT INTO state_aliases VALUES (?, ?, 'runtime-raw')",
                    (runtime_alias, raw),
                )
            subprocess.run(
                [
                    "python3", str(SCRIPT), "--base-oracle", str(base),
                    "--campaign-sqlite", str(database), "--output", str(output),
                    "--report", str(report),
                ],
                check=True,
            )
            records = {
                row["problem_key"]: row
                for row in map(json.loads, output.read_text().splitlines())
            }
            historical_candidates = {
                item["candidate"] for item in records[old_canonical]["prefer"]
            }
            self.assertEqual(historical_candidates, {"dp"})
            runtime_candidates = {
                item["candidate"] for item in records[runtime_alias]["prefer"]
            }
            self.assertIn("dp(graph;size-change)", runtime_candidates)
            self.assertNotIn("canonical_problem_key", records[runtime_alias])


if __name__ == "__main__":
    unittest.main()
