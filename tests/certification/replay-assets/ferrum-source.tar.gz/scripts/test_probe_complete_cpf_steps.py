import unittest
import json
import xml.etree.ElementTree as ET
from unittest.mock import patch
from probe_complete_cpf_steps import local_action, source_identity_signature, may_probe_unchanged_continuation, native_recovery_candidates
from extract_exact_fragment_training_data import normalized_rule_signature, subtract_alpha_equivalent_rules, iter_exact_rows
from rekey_direct_cpf_events import native_key
from export_direct_native_hints import canonical_candidate, source_action_identity


class DirectCpfTests(unittest.TestCase):
    def test_native_recovery_is_bounded_and_never_uses_complete_proofs(self):
        self.assertEqual(native_recovery_candidates('rewritingProc'), ['rewrite'])
        candidates = native_recovery_candidates('forwardInstantiationProc')
        self.assertEqual(len(candidates), 16)
        self.assertEqual(candidates[0], 'forward-instantiate(candidate=0,max-per-pair=128)')
        self.assertEqual(candidates[-1], 'forward-instantiate(candidate=15,max-per-pair=128)')
        self.assertEqual(native_recovery_candidates('unknown'), [])

    def test_uncurry_emits_a_local_action_and_links_its_continuation(self):
        source = dict(proof_url='test', xml_path='test', source_kind='test',
                      xml_format='3.0', year=2026, category='test', benchmark='test',
                      tool='test', result='YES', certification='test')
        root = ET.fromstring('<certificationProblem><input><trsInput>'
            '<trs><rules/></trs><strategy>FULL</strategy></trsInput></input>'
            '<proof><trsTerminationProof><uncurry><trs><rules/></trs>'
            '<trsTerminationProof><rIsEmpty/></trsTerminationProof>'
            '</uncurry></trsTerminationProof></proof></certificationProblem>')
        rows, _ = iter_exact_rows(source, root)
        parent = next(r for r in rows if r['metadata']['processor_tag'] == 'uncurry')
        child = next(r for r in rows if r['metadata']['processor_tag'] == 'rIsEmpty')
        self.assertEqual(local_action(parent), 'uncurry')
        self.assertEqual(child['metadata']['causal_parent_row_id'], parent['id'])

    def test_unchanged_continuation_search_does_not_replace_real_children(self):
        self.assertTrue(may_probe_unchanged_continuation('Inapplicable', {0}))
        for outcome, branches in [('Transformed', {0}), ('Failed', {0}),
                                  ('Inapplicable', {0, 1}), ('Inapplicable', set())]:
            self.assertFalse(may_probe_unchanged_continuation(outcome, branches))

    def test_source_action_identity_only_ignores_xml_indentation(self):
        def atom(xml):
            return 'exact-usable-rules(hex=' + json.dumps([xml]).encode().hex() + ')'
        plain = atom('<q><var>x</var><name>f</name></q>')
        spaced = atom('<q>\n <var>x</var>\n <name>f</name>\n</q>')
        self.assertEqual(source_action_identity(plain), source_action_identity(spaced))
        for changed in ('<q/>', '<q><var>y</var><name>f</name></q>',
                        '<q><var>x</var><name>g</name></q>'):
            self.assertNotEqual(source_action_identity(plain), source_action_identity(atom(changed)))

    def test_index_witness_aliases_use_native_family_not_relocated_indices(self):
        self.assertEqual(canonical_candidate('uncurry'), 'uncurry')
        self.assertIsNone(canonical_candidate('instantiate(candidate=3)'))
        self.assertEqual(canonical_candidate('exact-size-change(hex=00)'), 'exact-size-change(hex=00)')
        self.assertEqual(canonical_candidate('exact-subterm(hex=00)'), 'subterm')
        self.assertIsNone(canonical_candidate('exact-dp-proof(hex=00)'))

    def test_identity_wrapper_check_preserves_q_and_symbol_names(self):
        a = '<input><dpInput><q><name>f</name></q></dpInput></input>'
        b = '<dpInput>\n <q><name>f</name></q>\n</dpInput>'
        self.assertEqual(source_identity_signature(a), source_identity_signature(b))
        self.assertNotEqual(source_identity_signature(a), source_identity_signature(b.replace('f', 'g')))
        self.assertNotEqual(source_identity_signature(a), source_identity_signature('<dpInput><q/></dpInput>'))

    def test_native_key_uses_serialized_bytes_not_symbol_renaming(self):
        self.assertEqual(native_key(' <trsInput/>\n'), native_key('<trsInput/>'))
        self.assertNotEqual(native_key('<name>f</name>'), native_key('<name>g</name>'))

    def test_labeled_symbols_remain_distinct_when_subtracting_rules(self):
        def rule(label):
            return ET.fromstring(f'<rule><funapp><labeledSymbol><name>f</name>'
                f'<numberLabel><number>{label}</number></numberLabel></labeledSymbol>'
                '<var>x</var></funapp><var>x</var></rule>')
        first, second = rule(0), rule(1)
        self.assertNotEqual(normalized_rule_signature(first), normalized_rule_signature(second))
        source = ET.Element('dps'); ET.SubElement(source, 'rules').extend([first, second])
        removed = ET.Element('dps'); ET.SubElement(removed, 'rules').append(rule(1))
        residual = subtract_alpha_equivalent_rules(source, removed)
        self.assertEqual(len(residual.find('rules')), 1)
        self.assertEqual(normalized_rule_signature(residual.find('rules')[0]), normalized_rule_signature(first))

    def test_empty_terminal_nodes_have_local_actions(self):
        for tag, atom in (('pIsEmpty', 'graph'), ('rIsEmpty', 'empty')):
            self.assertEqual(local_action({'metadata': {'processor_tag': tag}}), atom)

    def test_composite_termination_shortcuts_are_never_admitted(self):
        for atom in ('exact-trs-proof(hex=00)', 'exact-dp-proof(hex=00)'):
            with patch('probe_complete_cpf_steps.strategy_atom', return_value=atom):
                self.assertIsNone(local_action({}))

    def test_local_witness_is_preserved(self):
        with patch('probe_complete_cpf_steps.strategy_atom', return_value='exact-red-pair(hex=00)'):
            self.assertEqual(local_action({}), 'exact-red-pair(hex=00)')
