#!/usr/bin/env python3
"""Convert Ferrum task datasets to minimal chat-template SFT JSONL.

Each output row has the standard shape expected by Hugging Face tokenizer chat
templates:

    {"messages": [{"role": "system", "content": "..."}, ...]}

The source task datasets may contain metadata, ids, and auxiliary fields; those
are intentionally stripped from the SFT files so trainers can pass
``row["messages"]`` directly to ``tokenizer.apply_chat_template``.
"""

from __future__ import annotations

import argparse
import gzip
import hashlib
import json
from pathlib import Path
from typing import Any


def open_input(path: Path):
    return gzip.open(path, "rt", encoding="utf-8") if path.suffix == ".gz" else path.open("r", encoding="utf-8")


def open_output(path: Path):
    path.parent.mkdir(parents=True, exist_ok=True)
    return gzip.open(path, "wt", encoding="utf-8") if path.suffix == ".gz" else path.open("w", encoding="utf-8")


def compact_json(value: Any) -> str:
    return json.dumps(value, sort_keys=True, separators=(",", ":"))


def valid_messages(messages: Any) -> bool:
    if not isinstance(messages, list) or not messages:
        return False
    for message in messages:
        if not isinstance(message, dict):
            return False
        if message.get("role") not in {"system", "user", "assistant"}:
            return False
        if not isinstance(message.get("content"), str):
            return False
    return True


def split_for_id(identifier: str, validation_pct: int, test_pct: int) -> str:
    bucket = int(hashlib.sha256(identifier.encode()).hexdigest()[:8], 16) % 10_000
    test_cutoff = test_pct * 100
    validation_cutoff = test_cutoff + validation_pct * 100
    if bucket < test_cutoff:
        return "test"
    if bucket < validation_cutoff:
        return "validation"
    return "train"


def convert_one(
    input_path: Path,
    out_dir: Path,
    name: str,
    validation_pct: int,
    test_pct: int,
    limit: int | None,
    progress_interval: int,
) -> dict[str, Any]:
    outputs = {
        "train": out_dir / f"{name}.sft.train.jsonl.gz",
        "validation": out_dir / f"{name}.sft.validation.jsonl.gz",
        "test": out_dir / f"{name}.sft.test.jsonl.gz",
    }
    counts = {split: 0 for split in outputs}
    rows = 0
    skipped = 0
    with open_input(input_path) as source:
        sinks = {split: open_output(path) for split, path in outputs.items()}
        try:
            for line in source:
                row = json.loads(line)
                rows += 1
                messages = row.get("messages")
                if not valid_messages(messages):
                    skipped += 1
                    continue
                identifier = str(row.get("id") or row.get("metadata", {}).get("row_id") or rows)
                split = split_for_id(identifier, validation_pct, test_pct)
                sinks[split].write(compact_json({"messages": messages}) + "\n")
                counts[split] += 1
                if progress_interval > 0 and rows % progress_interval == 0:
                    print(
                        compact_json(
                            {
                                "event": "progress",
                                "dataset": name,
                                "input_rows": rows,
                                "written": counts,
                                "skipped": skipped,
                            }
                        ),
                        flush=True,
                    )
                if limit is not None and rows >= limit:
                    break
        finally:
            for sink in sinks.values():
                sink.close()
    return {
        "name": name,
        "input": str(input_path),
        "outputs": {split: str(path) for split, path in outputs.items()},
        "input_rows": rows,
        "written": counts,
        "skipped": skipped,
    }


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--processor", type=Path, required=True)
    parser.add_argument("--parameters", type=Path, required=True)
    parser.add_argument("--witness", type=Path, required=True)
    parser.add_argument("--out-dir", type=Path, required=True)
    parser.add_argument("--summary", type=Path, required=True)
    parser.add_argument("--prefix", default="ferrum")
    parser.add_argument("--validation-pct", type=int, default=1)
    parser.add_argument("--test-pct", type=int, default=1)
    parser.add_argument("--limit", type=int)
    parser.add_argument("--progress-interval", type=int, default=50000)
    args = parser.parse_args()

    if args.validation_pct < 0 or args.test_pct < 0 or args.validation_pct + args.test_pct >= 100:
        raise SystemExit("validation/test percentages must be nonnegative and sum to less than 100")

    args.out_dir.mkdir(parents=True, exist_ok=True)
    datasets = [
        ("processor", args.processor),
        ("parameters", args.parameters),
        ("witness", args.witness),
    ]
    summaries = [
        convert_one(
            input_path,
            args.out_dir,
            f"{args.prefix}.{name}",
            args.validation_pct,
            args.test_pct,
            args.limit,
            args.progress_interval,
        )
        for name, input_path in datasets
    ]
    summary = {
        "format": {"messages": [{"role": "system|user|assistant", "content": "string"}]},
        "validation_pct": args.validation_pct,
        "test_pct": args.test_pct,
        "datasets": summaries,
    }
    args.summary.write_text(json.dumps(summary, indent=2, sort_keys=True), encoding="utf-8")
    print(compact_json(summary), flush=True)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
