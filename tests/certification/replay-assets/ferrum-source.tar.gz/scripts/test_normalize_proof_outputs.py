#!/usr/bin/env python3

import unittest

from normalize_proof_outputs import xml_payload_from_text


class NormalizeProofOutputsTests(unittest.TestCase):
    def test_uses_the_declaration_attached_to_the_embedded_cpf(self) -> None:
        raw = """wrapper output
<?xml version="1.0" encoding="UTF-8" standalone="no"?>
more wrapper output
YES
<?xml version="1.0" encoding="UTF-8" standalone="no"?><?xml-stylesheet type="text/xsl" href="cpfHTML.xsl"?>
<certificationProblem><answer><yes/></answer></certificationProblem>
trailing statistics
"""

        self.assertEqual(
            xml_payload_from_text(raw),
            '<?xml version="1.0" encoding="UTF-8" standalone="no"?>'
            '<?xml-stylesheet type="text/xsl" href="cpfHTML.xsl"?>\n'
            '<certificationProblem><answer><yes/></answer></certificationProblem>',
        )

    def test_preserves_a_single_declaration_and_discards_trailing_text(self) -> None:
        raw = """0.10/0.20\tYES
0.10/0.20\t<?xml version="1.0"?>
0.10/0.20\t<certificationProblem></certificationProblem>
0.10/0.20\tDONE
"""

        self.assertEqual(
            xml_payload_from_text(raw),
            '<?xml version="1.0"?>\n'
            '<certificationProblem></certificationProblem>',
        )


if __name__ == "__main__":
    unittest.main()
