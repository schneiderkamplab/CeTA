#!/usr/bin/env python3
import argparse
import concurrent.futures
import hashlib
import json
import os
import signal
import sqlite3
import subprocess
import sys
import tempfile
import time
import urllib.request
import urllib.error
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path
from typing import Any


TERMCOMP_2025 = "https://termcomp.github.io/Y2025"
HARNESS_CLEANUP_MARGIN_SECONDS = 5
DEFAULT_REPLAY_STATUSES = frozenset({"yes", "no", "unknown", "timeout", "error"})
SUPPORTED_CATEGORIES = [
    "TRS_Standard",
    "TRS_Innermost",
    "TRS_Relative",
    "SRS_Standard",
    "SRS_Relative",
    "TRS_Contextsensitive",
    "TRS_Outermost",
]


@dataclass
class FerrumResult:
    path: Path
    status: str
    certified: bool
    artifact_dir: Path | None = None
    cert_stdout: str = ""
    cert_stderr: str = ""
    ferrum_stdout: str = ""
    ferrum_stderr: str = ""
    elapsed_seconds: float = 0.0
    progress_events: int = 0
    last_progress_event: str = ""
    processor_starts: int = 0
    processor_finishes: int = 0
    processor_time_ms: int = 0
    has_csr_dp: bool = False
    csr_dp_full_certified: bool = False
    csr_dp_transform_certified: bool = False
    csr_dp_transform_failed: bool = False
    csr_dp_cert_failed: bool = False
    cert_failure_kind: str = ""
    csr_dp_failure_kind: str = ""


@dataclass
class ManagedProcessResult:
    returncode: int | None
    stdout: str
    stderr: str
    timed_out: bool


def terminate_process_group(process: subprocess.Popen[str]) -> None:
    if process.poll() is not None:
        return
    try:
        os.killpg(process.pid, signal.SIGTERM)
    except ProcessLookupError:
        return
    try:
        process.wait(timeout=0.5)
        return
    except subprocess.TimeoutExpired:
        pass
    try:
        os.killpg(process.pid, signal.SIGKILL)
    except ProcessLookupError:
        return
    try:
        process.wait(timeout=1.0)
    except subprocess.TimeoutExpired:
        process.kill()


def timeout_output(value: str | bytes | None) -> str:
    if value is None:
        return ""
    if isinstance(value, bytes):
        return value.decode(errors="replace")
    return value


def run_managed_process(
    command: list[str],
    timeout: int,
    env: dict[str, str] | None = None,
) -> ManagedProcessResult:
    try:
        process = subprocess.Popen(
            command,
            text=True,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            env=env,
            start_new_session=True,
        )
    except OSError as error:
        # A missing or otherwise unlaunchable prover/checker is a failure of
        # this one run, not a reason to discard every completed result in a
        # long parallel campaign.
        return ManagedProcessResult(127, "", f"failed to launch {command[0]}: {error}", False)
    try:
        stdout, stderr = process.communicate(timeout=timeout)
        return ManagedProcessResult(process.returncode, stdout, stderr, False)
    except subprocess.TimeoutExpired as timeout_error:
        terminate_process_group(process)
        stdout = timeout_output(timeout_error.output)
        stderr = timeout_output(timeout_error.stderr)
        try:
            completed_stdout, completed_stderr = process.communicate(timeout=1.0)
            stdout = completed_stdout
            stderr = completed_stderr
        except subprocess.TimeoutExpired:
            # The process group has received SIGKILL. Do not turn slow kernel
            # teardown or an inherited pipe into an unbounded harness wait.
            pass
        return ManagedProcessResult(process.returncode, stdout, stderr, True)


def progress_summary(path: Path | None) -> dict[str, int | str]:
    if path is None:
        return {
            "progress_events": 0,
            "last_progress_event": "",
            "processor_starts": 0,
            "processor_finishes": 0,
            "processor_time_ms": 0,
        }
    progress = path / "progress.jsonl"
    if not progress.exists():
        return {
            "progress_events": 0,
            "last_progress_event": "",
            "processor_starts": 0,
            "processor_finishes": 0,
            "processor_time_ms": 0,
        }
    events = 0
    starts = 0
    finishes = 0
    time_ms = 0
    last = ""
    with progress.open(errors="replace") as handle:
        for line in handle:
            line = line.strip()
            if not line:
                continue
            events += 1
            last = line
            try:
                event = json.loads(line)
            except json.JSONDecodeError:
                continue
            if event.get("event") == "start":
                starts += 1
            elif event.get("event") == "finish":
                finishes += 1
                time_ms += int(event.get("elapsed_ms", 0))
    return {
        "progress_events": events,
        "last_progress_event": last,
        "processor_starts": starts,
        "processor_finishes": finishes,
        "processor_time_ms": time_ms,
    }


def safe_problem_dir(root: Path, problem: Path, artifacts_root: Path) -> Path:
    try:
        relative = problem.resolve().relative_to(root.resolve())
    except ValueError:
        relative = Path(problem.name)
    parts = [part.replace("#", "sharp_") for part in relative.with_suffix("").parts]
    return artifacts_root.joinpath(*parts)


def uses_utility_guidance(extra_args: list[str]) -> bool:
    return any(
        arg == "--utility-guidance-manifest"
        or arg.startswith("--utility-guidance-manifest=")
        for arg in extra_args
    )


def write_text(path: Path, text: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary: Path | None = None
    try:
        with tempfile.NamedTemporaryFile(
            mode="w",
            encoding="utf-8",
            dir=path.parent,
            prefix=f".{path.name}.",
            suffix=".tmp",
            delete=False,
        ) as output:
            temporary = Path(output.name)
            output.write(text)
            output.flush()
            os.fsync(output.fileno())
        os.replace(temporary, path)
    finally:
        if temporary is not None:
            temporary.unlink(missing_ok=True)


def write_json(path: Path, value: Any) -> None:
    write_text(path, json.dumps(value, indent=2, sort_keys=True))


def has_arg(extra_args: list[str], needle: str) -> bool:
    return any(
        arg == needle or arg.startswith(f"{needle}=") for arg in extra_args
    )


def copy_artifact(source: Path, destination: Path) -> None:
    if source.exists():
        destination.parent.mkdir(parents=True, exist_ok=True)
        destination.write_bytes(source.read_bytes())


def open_replay_cpf_cache(path: Path) -> sqlite3.Connection:
    path.parent.mkdir(parents=True, exist_ok=True)
    connection = sqlite3.connect(path)
    connection.execute("PRAGMA journal_mode=WAL")
    connection.execute(
        """
        CREATE TABLE IF NOT EXISTS replay_cpf_cache (
            problem_key TEXT PRIMARY KEY,
            cpf TEXT NOT NULL,
            first_artifact TEXT NOT NULL,
            last_artifact TEXT NOT NULL,
            occurrences INTEGER NOT NULL DEFAULT 1
        )
        """
    )
    connection.commit()
    return connection


def capture_processor_event_cpfs(
    connection: sqlite3.Connection, artifact_dir: Path | None
) -> tuple[int, int]:
    if artifact_dir is None:
        return 0, 0
    events = artifact_dir / "processor-events.jsonl"
    if not events.exists():
        return 0, 0
    inserted = 0
    observed = 0
    for line in events.read_text(errors="replace").splitlines():
        try:
            event = json.loads(line)
        except json.JSONDecodeError:
            continue
        input_data = event.get("input")
        if not isinstance(input_data, dict) or not isinstance(input_data.get("cpf"), str):
            continue
        cpf = input_data["cpf"].strip()
        problem_key = hashlib.sha256(cpf.encode("utf-8")).hexdigest()
        event_key = input_data.get("problem_key")
        if isinstance(event_key, str) and event_key != problem_key:
            raise RuntimeError(
                f"processor-event CPF hash mismatch in {events}: "
                f"event={event_key} computed={problem_key}"
            )
        observed += 1
        existed = connection.execute(
            "SELECT 1 FROM replay_cpf_cache WHERE problem_key = ?", (problem_key,)
        ).fetchone()
        connection.execute(
            """
            INSERT INTO replay_cpf_cache
                (problem_key, cpf, first_artifact, last_artifact, occurrences)
            VALUES (?, ?, ?, ?, 1)
            ON CONFLICT(problem_key) DO UPDATE SET
                cpf = excluded.cpf,
                last_artifact = excluded.last_artifact,
                occurrences = replay_cpf_cache.occurrences + 1
            """,
            (problem_key, cpf, str(artifact_dir), str(artifact_dir)),
        )
        inserted += existed is None
    connection.commit()
    return inserted, observed


def cpf_contains_tag(path: Path, tag: str) -> bool:
    if not path.exists():
        return False
    needle_open = f"<{tag}"
    needle_close = f"</{tag}>"
    try:
        text = path.read_text(errors="replace")
    except OSError:
        return False
    return needle_open in text or needle_close in text


def classify_ceta_failure(stdout: str, stderr: str) -> str:
    text = f"{stdout}\n{stderr}".lower()
    if not text.strip():
        return ""
    if (
        "unsupported" in text
        and (
            "parse error on <" in text
            or "parse error" in text
            or "expecting [" in text
        )
    ):
        return "unsupported"
    if (
        "xml" in text
        or "parse" in text
        or "expected" in text
        or "malformed" in text
        or "invalid xml" in text
    ):
        return "parse"
    if (
        "not applied correctly" in text
        or "error when applying" in text
        or "error below" in text
        or "does not appear" in text
        or "invalid conservative csr-dp transformation" in text
    ):
        return "processor"
    if "unsupported" in text or "unknown" in text:
        return "unsupported"
    return "checker"


def csr_dp_transform_cert_status(certified: bool, stdout: str, stderr: str) -> tuple[bool, bool]:
    if certified:
        return True, False
    text = f"{stdout}\n{stderr}".lower()
    if (
        "error below csr dependency pairs" in text
        or "error below conservative csr dependency pairs" in text
    ):
        return True, False
    if (
        "error when switching from csr to a cs-dp problem" in text
        or "cs-dp transformation is not applied correctly" in text
        or "safe cs-dp transformation is not applied correctly" in text
        or "invalid conservative csr-dp transformation" in text
        or "the cs-dp" in text and "does not appear in the dp problem" in text
    ):
        return False, True
    return False, False


def official_rows(category: str) -> list[dict[str, int | str]]:
    try:
        with urllib.request.urlopen(f"{TERMCOMP_2025}/{category}.summary.json") as response:
            data = json.load(response)
    except (urllib.error.URLError, urllib.error.HTTPError, TimeoutError) as error:
        print(
            f"warning: could not read official TermCOMP summary for {category}: {error}",
            file=sys.stderr,
        )
        return []
    rows = []
    for name, entry in data["participants"].items():
        rows.append(
            {
                "category": category,
                "tool": name,
                "total": entry["done"],
                "yes": entry.get("YES", 0),
                "no": entry.get("NO", 0),
                "cert_yes": entry.get("CERTIFIED YES", 0),
                "cert_no": entry.get("CERTIFIED NO", 0),
                "maybe": entry.get("MAYBE", 0),
                "timeout": entry.get("timeout", 0),
                "memout": entry.get("memout", 0),
                "error": entry.get("error", 0),
                "cert_failed": 0,
            }
        )
    return rows


def run_one(
    ferrum: Path,
    ceta: Path,
    root: Path,
    problem: Path,
    timeout: int,
    extra_args: list[str],
    disable_llm: bool,
    artifacts_root: Path | None,
) -> FerrumResult:
    problem_artifact_dir = (
        safe_problem_dir(root, problem, artifacts_root) if artifacts_root is not None else None
    )
    if problem_artifact_dir is not None:
        problem_artifact_dir.mkdir(parents=True, exist_ok=True)
        write_json(
            problem_artifact_dir / "command.json",
            {
                "problem": str(problem),
                "timeout_seconds": timeout,
                "extra_args": extra_args,
                "disable_llm": disable_llm,
            },
        )
    with tempfile.TemporaryDirectory(prefix="ferrum-termcomp-") as tmp:
        cpf = Path(tmp) / "proof.cpf.xml"
        command = [
            str(ferrum),
            "prove",
            str(problem),
            "--cpf",
            str(cpf),
            "--cpf-mode",
            "auto",
            *extra_args,
        ]
        has_strategy_arg = any(
            arg == "--strategy"
            or arg.startswith("--strategy=")
            or arg == "--strategy-file"
            or arg.startswith("--strategy-file=")
            for arg in extra_args
        )
        if not has_strategy_arg:
            strategy_timeout = max(1, timeout - HARNESS_CLEANUP_MARGIN_SECONDS)
            command.extend(["--strategy", f"timeout({strategy_timeout}s, default)"])
        utility_guidance_enabled = uses_utility_guidance(extra_args)
        if (
            disable_llm
            and not utility_guidance_enabled
            and not has_arg(extra_args, "--no-top-level-llm")
        ):
            command.append("--no-top-level-llm")
        if problem_artifact_dir is not None and "--processor-events" not in extra_args:
            command.extend(
                [
                    "--processor-events",
                    str(problem_artifact_dir / "processor-events.jsonl"),
                ]
            )
        env = None
        if problem_artifact_dir is not None:
            env = dict(**os.environ)
            env["FERRUM_PROGRESS_LOG"] = str(problem_artifact_dir / "progress.jsonl")
            write_json(
                problem_artifact_dir / "command.json",
                {
                    "problem": str(problem),
                    "timeout_seconds": timeout,
                    "extra_args": extra_args,
                    "disable_llm": disable_llm,
                    "command": command,
                },
            )
        started = time.monotonic()
        completed = run_managed_process(command, timeout, env)
        if completed.timed_out:
            summary = progress_summary(problem_artifact_dir)
            result = FerrumResult(
                problem,
                "timeout",
                False,
                artifact_dir=problem_artifact_dir,
                ferrum_stdout=completed.stdout,
                ferrum_stderr=completed.stderr,
                elapsed_seconds=round(time.monotonic() - started, 3),
                **summary,
            )
            if problem_artifact_dir is not None:
                write_text(problem_artifact_dir / "ferrum.stdout", completed.stdout)
                write_text(problem_artifact_dir / "ferrum.stderr", completed.stderr)
                copy_artifact(cpf, problem_artifact_dir / "proof.cpf.xml")
                write_json(problem_artifact_dir / "result.json", result_to_dict("", result))
            return result
        if problem_artifact_dir is not None:
            write_text(problem_artifact_dir / "ferrum.stdout", completed.stdout)
            write_text(problem_artifact_dir / "ferrum.stderr", completed.stderr)
            copy_artifact(cpf, problem_artifact_dir / "proof.cpf.xml")
        output = f"{completed.stdout}\n{completed.stderr}"
        if completed.returncode != 0:
            if "status: Unknown" in output:
                result = FerrumResult(
                    problem,
                    "unknown",
                    False,
                    artifact_dir=problem_artifact_dir,
                    ferrum_stdout=completed.stdout,
                    ferrum_stderr=completed.stderr,
                    elapsed_seconds=round(time.monotonic() - started, 3),
                    **progress_summary(problem_artifact_dir),
                )
                if problem_artifact_dir is not None:
                    write_json(problem_artifact_dir / "result.json", result_to_dict("", result))
                return result
            result = FerrumResult(
                problem,
                "error",
                False,
                artifact_dir=problem_artifact_dir,
                ferrum_stdout=completed.stdout,
                ferrum_stderr=completed.stderr,
                elapsed_seconds=round(time.monotonic() - started, 3),
                **progress_summary(problem_artifact_dir),
            )
            if problem_artifact_dir is not None:
                write_json(problem_artifact_dir / "result.json", result_to_dict("", result))
            return result
        if "status: Nonterminating" in output:
            status = "no"
        elif "status: Terminating" in output:
            status = "yes"
        else:
            status = "unknown"
        certified = False
        cert_stdout = ""
        cert_stderr = ""
        ceta_failure_kind = ""
        if cpf.exists():
            checked = run_managed_process([str(ceta), str(cpf)], timeout)
            if checked.timed_out:
                certified = False
                cert_stdout = checked.stdout
                cert_stderr = f"{checked.stderr}\nCeTA timeout".strip()
                ceta_failure_kind = "timeout"
            else:
                certified = checked.returncode == 0
                cert_stdout = checked.stdout
                cert_stderr = checked.stderr
                if not certified:
                    ceta_failure_kind = classify_ceta_failure(cert_stdout, cert_stderr)
            if problem_artifact_dir is not None:
                write_text(problem_artifact_dir / "ceta.stdout", cert_stdout)
                write_text(problem_artifact_dir / "ceta.stderr", cert_stderr)
        else:
            cert_stderr = "proof file missing"
            ceta_failure_kind = "missing-cpf"
        has_csr_dp = (
            cpf_contains_tag(cpf, "csrDependencyPairs")
            or cpf_contains_tag(cpf, "csrSafeDependencyPairs")
            or cpf_contains_tag(cpf, "csrConservativeDependencyPairs")
        )
        csr_dp_transform_certified, csr_dp_transform_failed = csr_dp_transform_cert_status(
            certified, cert_stdout, cert_stderr
        )
        result = FerrumResult(
            problem,
            status,
            certified,
            artifact_dir=problem_artifact_dir,
            cert_stdout=cert_stdout,
            cert_stderr=cert_stderr,
            ferrum_stdout=completed.stdout,
            ferrum_stderr=completed.stderr,
            elapsed_seconds=round(time.monotonic() - started, 3),
            has_csr_dp=has_csr_dp,
            csr_dp_full_certified=has_csr_dp and certified,
            csr_dp_transform_certified=has_csr_dp and csr_dp_transform_certified,
            csr_dp_transform_failed=has_csr_dp and csr_dp_transform_failed,
            csr_dp_cert_failed=has_csr_dp and not certified,
            cert_failure_kind=ceta_failure_kind,
            csr_dp_failure_kind=classify_ceta_failure(cert_stdout, cert_stderr)
            if has_csr_dp and not certified
            else "",
            **progress_summary(problem_artifact_dir),
        )
        if problem_artifact_dir is not None:
            write_json(problem_artifact_dir / "result.json", result_to_dict("", result))
        return result


def result_to_dict(category: str, result: FerrumResult) -> dict[str, int | str | bool]:
    return {
        "category": category,
        "path": str(result.path),
        "status": result.status,
        "certified": result.certified,
        "artifact_dir": str(result.artifact_dir) if result.artifact_dir is not None else "",
        "cert_stdout": result.cert_stdout,
        "cert_stderr": result.cert_stderr,
        "ferrum_stdout": result.ferrum_stdout,
        "ferrum_stderr": result.ferrum_stderr,
        "elapsed_seconds": result.elapsed_seconds,
        "progress_events": result.progress_events,
        "last_progress_event": result.last_progress_event,
        "processor_starts": result.processor_starts,
        "processor_finishes": result.processor_finishes,
        "processor_time_ms": result.processor_time_ms,
        "has_csr_dp": result.has_csr_dp,
        "csr_dp_full_certified": result.csr_dp_full_certified,
        "csr_dp_transform_certified": result.csr_dp_transform_certified,
        "csr_dp_transform_failed": result.csr_dp_transform_failed,
        "csr_dp_cert_failed": result.csr_dp_cert_failed,
        "cert_failure_kind": result.cert_failure_kind,
        "csr_dp_failure_kind": result.csr_dp_failure_kind,
    }


def problems_from_previous_details(
    details_path: Path,
    category: str,
    include_statuses: set[str],
    longest_first: bool = False,
) -> list[Path]:
    details = json.loads(details_path.read_text())
    problems = []
    elapsed = {}
    for entry in details:
        if entry.get("category") != category:
            continue
        if entry.get("status") not in include_statuses:
            continue
        path = Path(str(entry["path"]))
        if path.exists():
            problems.append(path)
            elapsed[path] = max(elapsed.get(path, 0), float(entry.get('elapsed_seconds') or 0))
    return sorted(set(problems), key=lambda path:
                  (-elapsed[path], str(path)) if longest_first else (0, str(path)))


def problems_from_file_list(file_list: Path, root: Path) -> list[Path]:
    problems = []
    root_resolved = root.resolve()
    for raw_line in file_list.read_text().splitlines():
        line = raw_line.strip()
        if not line or line.startswith("#"):
            continue
        path = Path(line)
        candidates = [path]
        if not path.is_absolute():
            candidates.append(root / path)
            if root.name in path.parts:
                candidates.append(root.parent / path)
        existing = next((candidate for candidate in candidates if candidate.exists()), None)
        if existing is None:
            continue
        try:
            existing.resolve().relative_to(root_resolved)
        except ValueError:
            continue
        problems.append(existing)
    return sorted(set(problems))


def ferrum_row(
    category: str,
    root: Path,
    ferrum: Path,
    ceta: Path,
    jobs: int,
    timeout: int,
    extra_args: list[str],
    profile: str,
    disable_llm: bool,
    artifacts_root: Path | None,
    progress_interval: int,
    previous_details: Path | None,
    file_list: Path | None,
    include_statuses: set[str],
    replay_cpf_cache: Path | None,
    longest_first: bool = False,
) -> tuple[dict[str, int | str], list[FerrumResult]]:
    if previous_details is not None:
        problems = problems_from_previous_details(previous_details, category, include_statuses, longest_first)
    elif file_list is not None:
        problems = problems_from_file_list(file_list, root)
    else:
        problems = sorted(root.rglob("*.ari"))
    started = time.monotonic()
    counts = {
        "yes": 0,
        "no": 0,
        "cert_yes": 0,
        "cert_no": 0,
        "timeout": 0,
        "error": 0,
        "maybe": 0,
        "cert_failed": 0,
        "cert_parse_failed": 0,
        "cert_processor_failed": 0,
        "cert_unsupported_failed": 0,
        "cert_checker_failed": 0,
        "cert_timeout_failed": 0,
        "cert_missing_cpf_failed": 0,
        "cert_other_failed": 0,
        "csr_dp": 0,
        "csr_dp_full_certified": 0,
        "csr_dp_transform_certified": 0,
        "csr_dp_transform_failed": 0,
        "csr_dp_cert_failed": 0,
        "csr_dp_parse_failed": 0,
        "csr_dp_processor_failed": 0,
        "csr_dp_unsupported_failed": 0,
        "csr_dp_checker_failed": 0,
    }
    completed = 0
    results: list[FerrumResult] = []
    replay_cache_connection = (
        open_replay_cpf_cache(replay_cpf_cache) if replay_cpf_cache is not None else None
    )
    replay_cpfs_inserted = 0
    replay_cpfs_observed = 0
    with concurrent.futures.ThreadPoolExecutor(max_workers=jobs) as pool:
        futures = [
            pool.submit(
                run_one,
                ferrum,
                ceta,
                root,
                problem,
                timeout,
                extra_args,
                disable_llm,
                artifacts_root / category if artifacts_root is not None else None,
            )
            for problem in problems
        ]
        for future in concurrent.futures.as_completed(futures):
            result = future.result()
            results.append(result)
            if replay_cache_connection is not None:
                inserted, observed = capture_processor_event_cpfs(
                    replay_cache_connection, result.artifact_dir
                )
                replay_cpfs_inserted += inserted
                replay_cpfs_observed += observed
            completed += 1
            if result.status == "yes":
                counts["yes"] += 1
                if result.certified:
                    counts["cert_yes"] += 1
                else:
                    counts["cert_failed"] += 1
                    if result.cert_failure_kind == "parse":
                        counts["cert_parse_failed"] += 1
                    elif result.cert_failure_kind == "processor":
                        counts["cert_processor_failed"] += 1
                    elif result.cert_failure_kind == "unsupported":
                        counts["cert_unsupported_failed"] += 1
                    elif result.cert_failure_kind == "checker":
                        counts["cert_checker_failed"] += 1
                    elif result.cert_failure_kind == "timeout":
                        counts["cert_timeout_failed"] += 1
                    elif result.cert_failure_kind == "missing-cpf":
                        counts["cert_missing_cpf_failed"] += 1
                    else:
                        counts["cert_other_failed"] += 1
            elif result.status == "no":
                counts["no"] += 1
                if result.certified:
                    counts["cert_no"] += 1
                else:
                    counts["cert_failed"] += 1
                    if result.cert_failure_kind == "parse":
                        counts["cert_parse_failed"] += 1
                    elif result.cert_failure_kind == "processor":
                        counts["cert_processor_failed"] += 1
                    elif result.cert_failure_kind == "unsupported":
                        counts["cert_unsupported_failed"] += 1
                    elif result.cert_failure_kind == "checker":
                        counts["cert_checker_failed"] += 1
                    elif result.cert_failure_kind == "timeout":
                        counts["cert_timeout_failed"] += 1
                    elif result.cert_failure_kind == "missing-cpf":
                        counts["cert_missing_cpf_failed"] += 1
                    else:
                        counts["cert_other_failed"] += 1
            elif result.status == "timeout":
                counts["timeout"] += 1
            elif result.status == "unknown":
                counts["maybe"] += 1
            else:
                counts["error"] += 1
            if result.has_csr_dp:
                counts["csr_dp"] += 1
                if result.csr_dp_full_certified:
                    counts["csr_dp_full_certified"] += 1
                if result.csr_dp_transform_certified:
                    counts["csr_dp_transform_certified"] += 1
                if result.csr_dp_transform_failed:
                    counts["csr_dp_transform_failed"] += 1
                if result.csr_dp_cert_failed:
                    counts["csr_dp_cert_failed"] += 1
                    if result.csr_dp_failure_kind == "parse":
                        counts["csr_dp_parse_failed"] += 1
                    elif result.csr_dp_failure_kind == "processor":
                        counts["csr_dp_processor_failed"] += 1
                    elif result.csr_dp_failure_kind == "unsupported":
                        counts["csr_dp_unsupported_failed"] += 1
                    else:
                        counts["csr_dp_checker_failed"] += 1
            if completed == len(problems) or completed % progress_interval == 0:
                elapsed = int(time.monotonic() - started)
                rate = completed / elapsed if elapsed else 0.0
                remaining = len(problems) - completed
                eta = int(remaining / rate) if rate else 0
                print(
                    f"{category}: completed={completed}/{len(problems)} "
                    f"yes={counts['yes']} cert_yes={counts['cert_yes']} "
                    f"no={counts['no']} cert_no={counts['cert_no']} "
                    f"maybe={counts['maybe']} timeout={counts['timeout']} "
                    f"error={counts['error']} cert_failed={counts['cert_failed']} "
                    f"(parse={counts['cert_parse_failed']} "
                    f"processor={counts['cert_processor_failed']} "
                    f"unsupported={counts['cert_unsupported_failed']} "
                    f"checker={counts['cert_checker_failed']} "
                    f"timeout={counts['cert_timeout_failed']} "
                    f"missing={counts['cert_missing_cpf_failed']} "
                    f"other={counts['cert_other_failed']}) "
                    f"csr_dp={counts['csr_dp']} csr_dp_cert={counts['csr_dp_full_certified']} "
                    f"csr_dp_transform_cert={counts['csr_dp_transform_certified']} "
                    f"elapsed={elapsed}s eta={eta}s",
                    file=sys.stderr,
                    flush=True,
                )
    if replay_cache_connection is not None:
        replay_cache_connection.close()
        print(
            f"{category}: replay CPF cache inserted={replay_cpfs_inserted} "
            f"observed={replay_cpfs_observed} path={replay_cpf_cache}",
            file=sys.stderr,
            flush=True,
        )
    return (
        {
            "category": category,
            "tool": f"Ferrum {profile} timeout={timeout}s",
            "total": len(problems),
            "yes": counts["yes"],
            "no": counts["no"],
            "cert_yes": counts["cert_yes"],
            "cert_no": counts["cert_no"],
            "maybe": counts["maybe"],
            "timeout": counts["timeout"],
            "memout": 0,
            "error": counts["error"],
            "cert_failed": counts["cert_failed"],
            "cert_parse_failed": counts["cert_parse_failed"],
            "cert_processor_failed": counts["cert_processor_failed"],
            "cert_unsupported_failed": counts["cert_unsupported_failed"],
            "cert_checker_failed": counts["cert_checker_failed"],
            "cert_timeout_failed": counts["cert_timeout_failed"],
            "cert_missing_cpf_failed": counts["cert_missing_cpf_failed"],
            "cert_other_failed": counts["cert_other_failed"],
            "csr_dp": counts["csr_dp"],
            "csr_dp_full_certified": counts["csr_dp_full_certified"],
            "csr_dp_transform_certified": counts["csr_dp_transform_certified"],
            "csr_dp_transform_failed": counts["csr_dp_transform_failed"],
            "csr_dp_cert_failed": counts["csr_dp_cert_failed"],
            "csr_dp_parse_failed": counts["csr_dp_parse_failed"],
            "csr_dp_processor_failed": counts["csr_dp_processor_failed"],
            "csr_dp_unsupported_failed": counts["csr_dp_unsupported_failed"],
            "csr_dp_checker_failed": counts["csr_dp_checker_failed"],
            "replay_cpfs_inserted": replay_cpfs_inserted,
            "replay_cpfs_observed": replay_cpfs_observed,
        },
        results,
    )


def row_score(row: dict[str, int | str]) -> tuple[int, int, int, str]:
    yes = int(row["yes"])
    no = int(row["no"])
    cert_yes = int(row["cert_yes"])
    cert_no = int(row["cert_no"])
    return (yes + no + cert_yes + cert_no, cert_yes + cert_no, yes + no, str(row["tool"]))


def sorted_rows(rows: list[dict[str, int | str]]) -> list[dict[str, int | str]]:
    return sorted(rows, key=row_score, reverse=True)


def markdown_table(rows: list[dict[str, int | str]]) -> str:
    headers = [
        "Tool/config",
        "Total",
        "YES",
        "NO",
        "Certified YES",
        "Certified NO",
        "MAYBE",
        "Timeout",
        "Memout",
        "Error",
        "Cert failed",
        "Cert parse fail",
        "Cert proc fail",
        "Cert unsupported",
        "Cert checker fail",
        "Cert timeout",
        "Cert missing CPF",
        "Cert other fail",
        "CSR-DP proofs",
        "CSR-DP transform cert",
        "CSR-DP transform fail",
        "CSR-DP full cert",
        "CSR-DP cert failed",
        "CSR-DP parse fail",
        "CSR-DP proc fail",
        "CSR-DP unsupported",
        "CSR-DP checker fail",
    ]
    keys = [
        "tool",
        "total",
        "yes",
        "no",
        "cert_yes",
        "cert_no",
        "maybe",
        "timeout",
        "memout",
        "error",
        "cert_failed",
        "cert_parse_failed",
        "cert_processor_failed",
        "cert_unsupported_failed",
        "cert_checker_failed",
        "cert_timeout_failed",
        "cert_missing_cpf_failed",
        "cert_other_failed",
        "csr_dp",
        "csr_dp_transform_certified",
        "csr_dp_transform_failed",
        "csr_dp_full_certified",
        "csr_dp_cert_failed",
        "csr_dp_parse_failed",
        "csr_dp_processor_failed",
        "csr_dp_unsupported_failed",
        "csr_dp_checker_failed",
    ]
    lines = [
        "| " + " | ".join(headers) + " |",
        "| " + " | ".join(["---"] * len(headers)) + " |",
    ]
    for row in sorted_rows(rows):
        lines.append("| " + " | ".join(str(row.get(key, 0)) for key in keys) + " |")
    return "\n".join(lines)


def markdown_category_tables(rows: list[dict[str, int | str]], categories: list[str]) -> str:
    sections = []
    for category in categories:
        category_rows = [row for row in rows if row["category"] == category]
        sections.extend([f"## {category}", "", markdown_table(category_rows), ""])
    return "\n".join(sections).rstrip()


def comparison_report(
    rows: list[dict[str, int | str]],
    categories: list[str],
    artifacts_root: Path | None,
) -> str:
    return "\n".join(
        [
            "# TermCOMP 2025 TRS Comparison",
            "",
            f"Official rows are read from `{TERMCOMP_2025}` summary JSON files.",
            "Ferrum rows are local runs over the selected TPDB-ARI categories.",
            "Rows inside each category are sorted by total solved/certified answers, descending.",
            (
                "`CSR-DP proofs` counts Ferrum proofs containing a native `<csrDependencyPairs>`, "
                "`<csrSafeDependencyPairs>`, or `<csrConservativeDependencyPairs>` "
                "processor. `CSR-DP transform cert` counts full certifications and failures that "
                "CeTA reports below the CSR-DP processor, which means the CSR-DP transformation "
                "itself was accepted even if the remaining DP proof was not. `CSR-DP full cert` "
                "requires the whole CPF/CeTA proof to certify."
            ),
            (
                f"Ferrum per-example artifacts are in `{artifacts_root}`."
                if artifacts_root is not None
                else "Ferrum per-example artifacts were not retained."
            ),
            "",
            markdown_category_tables(rows, categories),
            "",
        ]
    )


def write_comparison_checkpoint(
    output: Path,
    details_output: Path | None,
    artifacts_root: Path | None,
    rows: list[dict[str, int | str]],
    details: list[dict[str, int | str | bool]],
    categories: list[str],
) -> str:
    body = comparison_report(rows, categories, artifacts_root)
    write_text(output, body)
    if details_output is not None:
        write_json(details_output, details)
    elif artifacts_root is not None:
        write_json(artifacts_root / "details.json", details)
    if artifacts_root is not None:
        write_text(artifacts_root / "summary.md", body)
    return body


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument('--longest-first', action='store_true',
                        help='With --from-details, launch previously slow roots first to reduce the final worker tail')
    parser.add_argument("--tpdb", type=Path, default=Path("../TPDB-ARI"))
    parser.add_argument("--ferrum", type=Path, default=Path("target/release/ferrum"))
    parser.add_argument("--ceta", type=Path, default=Path(".tools/ceta-relative-bounds"))
    parser.add_argument("--jobs", type=int, default=8)
    parser.add_argument(
        "--timeout",
        type=int,
        default=305,
        help=(
            "per-root harness ceiling in seconds; the implicit Ferrum strategy "
            f"ceiling is this value minus {HARNESS_CLEANUP_MARGIN_SECONDS} seconds "
            "(for example, use 65 for a 60-second prover allowance)"
        ),
    )
    parser.add_argument("--output", type=Path, default=Path("docs/termcomp-2025-trs-comparison.md"))
    parser.add_argument(
        "--ferrum-profile",
        choices=["default", "enhanced"],
        default="enhanced",
        help="Ferrum strategy profile: default passes no extra prove flags; enhanced matches the local comparison profile",
    )
    parser.add_argument(
        "--category",
        action="append",
        choices=SUPPORTED_CATEGORIES,
        help="category to run; may be supplied more than once",
    )
    parser.add_argument("--skip-ferrum", action="store_true")
    parser.add_argument(
        "--details-output",
        type=Path,
        help="write per-problem Ferrum and CeTA results as JSON",
    )
    parser.add_argument(
        "--run-dir",
        type=Path,
        help="directory for per-example results and artifacts; defaults to target/termcomp-runs/<timestamp>",
    )
    parser.add_argument(
        "--no-keep-artifacts",
        action="store_true",
        help="do not keep per-example stdout/stderr, CPF, CeTA output, and result.json artifacts",
    )
    parser.add_argument(
        "--progress-interval",
        type=int,
        default=10,
        help="print progress every N completed examples",
    )
    parser.add_argument(
        "--from-details",
        type=Path,
        help="rerun only problems selected from a previous details JSON file",
    )
    parser.add_argument(
        "--file-list",
        type=Path,
        help="run only ARI paths listed in this file; blank lines and # comments are ignored",
    )
    parser.add_argument(
        "--include-status",
        action="append",
        choices=["yes", "no", "unknown", "timeout", "error"],
        help=(
            "status to include when --from-details is used; may be repeated; "
            "defaults to all statuses, including previous timeouts"
        ),
    )
    parser.add_argument(
        "--extra-arg",
        action="append",
        default=[],
        help="additional argument passed through to each Ferrum prove invocation; repeat for multiple argv entries",
    )
    parser.add_argument(
        "--strategy-file",
        type=Path,
        help="Ferrum strategy file passed through to each prove invocation",
    )
    parser.add_argument(
        "--replay-cpf-cache",
        type=Path,
        help=(
            "collect every inline processor-event CPF in a reusable SQLite "
            "cache keyed by Ferrum's whitespace-normalized runtime hash"
        ),
    )
    args = parser.parse_args()
    if args.progress_interval < 1:
        parser.error("--progress-interval must be at least 1")
    if args.from_details is not None and args.file_list is not None:
        parser.error("--from-details and --file-list cannot be used together")
    include_statuses = set(args.include_status or DEFAULT_REPLAY_STATUSES)

    categories = args.category or SUPPORTED_CATEGORIES
    run_dir = args.run_dir
    if run_dir is None and not args.no_keep_artifacts:
        stamp = datetime.now().strftime("%Y%m%d-%H%M%S")
        run_dir = Path("target") / "termcomp-runs" / stamp
    artifacts_root = None if args.no_keep_artifacts else run_dir
    if artifacts_root is not None:
        artifacts_root.mkdir(parents=True, exist_ok=True)
    rows: list[dict[str, int | str]] = []
    details: list[dict[str, int | str | bool]] = []
    for category in categories:
        rows.extend(official_rows(category))

    if not args.skip_ferrum:
        if args.ferrum_profile == "default":
            extra_args = []
            disable_llm = False
        else:
            extra_args = []
            disable_llm = True
        if args.strategy_file is not None:
            extra_args.extend(["--strategy-file", str(args.strategy_file)])
        extra_args.extend(args.extra_arg)
        for category in categories:
            row, category_results = ferrum_row(
                category,
                args.tpdb / category,
                args.ferrum,
                args.ceta,
                args.jobs,
                args.timeout,
                extra_args,
                args.ferrum_profile,
                disable_llm,
                artifacts_root,
                args.progress_interval,
                args.from_details,
                args.file_list,
                include_statuses,
                args.replay_cpf_cache,
                args.longest_first,
            )
            rows.append(row)
            for result in sorted(category_results, key=lambda result: str(result.path)):
                details.append(result_to_dict(category, result))
            write_comparison_checkpoint(
                args.output,
                args.details_output,
                artifacts_root,
                rows,
                details,
                categories,
            )

    body = write_comparison_checkpoint(
        args.output,
        args.details_output,
        artifacts_root,
        rows,
        details,
        categories,
    )
    print(args.output)
    if artifacts_root is not None:
        print(artifacts_root)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
