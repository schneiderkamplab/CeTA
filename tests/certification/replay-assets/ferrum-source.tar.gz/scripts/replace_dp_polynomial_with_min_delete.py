#!/usr/bin/env python3
"""Replace exact polynomials with one-result minimum deletion."""

from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path

from build_credited_status_map_dataset import canonicalize_cpf_input, compact_xml_for_key
from replace_polynomial_with_residual_targets import (
    bounded_atom,
    cpf_rules,
    decode_bounds,
    deleted_indices,
)


WITNESS_SCHEMA = "ferrum.utility-guidance.witness.v1"
GROUPS = ("avoid", "possible", "prefer", "timeout")


def target_atom(bounds: tuple[int, int, int, int], minimum: int) -> str:
    constant, coefficient, symbols, arity = bounds
    return (
        f"poly-min-delete(max-constant={constant},max-coefficient={coefficient},"
        f"max-symbols={symbols},max-arity={arity},min-delete={minimum},"
        "residual-budget=1)"
    )


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("input", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("--run-dir", type=Path, required=True)
    parser.add_argument(
        "--events-jsonl",
        type=Path,
        action="append",
        default=[],
        help="additional certified extracted processor events",
    )
    parser.add_argument("--affected-roots-output", type=Path)
    parser.add_argument(
        "--include-top-level",
        action="store_true",
        help="also replace witnesses selected exclusively at top level",
    )
    args = parser.parse_args()

    rows = [json.loads(line) for line in args.input.open(encoding="utf-8")]
    all_definitions = {
        row["witness_id"]: row["candidate"]
        for row in rows
        if row.get("schema") == WITNESS_SCHEMA
        and row.get("candidate", "").startswith("exact-poly(")
    }
    candidate_ids = {candidate: identifier for identifier, candidate in all_definitions.items()}
    events = []
    levels = {identifier: set() for identifier in all_definitions}
    for result_path in args.run_dir.rglob("result.json"):
        result = json.loads(result_path.read_text(encoding="utf-8"))
        if not result.get("certified"):
            continue
        events_path = result_path.parent / "processor-events.jsonl"
        if not events_path.exists():
            continue
        for line in events_path.open(encoding="utf-8"):
            event = json.loads(line)
            identifier = candidate_ids.get(event.get("processor", ""))
            if identifier is not None:
                levels[identifier].add(event.get("level"))
                events.append((result["path"], event, identifier))

    for events_path in args.events_jsonl:
        for line in events_path.open(encoding="utf-8"):
            event = json.loads(line)
            certification = event.get("certification") or {}
            if not certification.get("status", "").startswith(("accepted", "certified")):
                continue
            identifier = candidate_ids.get(event.get("processor", ""))
            if identifier is not None:
                levels[identifier].add(event.get("level"))
                events.append((event["problem_id"], event, identifier))

    allowed_levels = {"dependency-pair"}
    if args.include_top_level:
        allowed_levels.update(("top-level", "context-sensitive"))
    eligible = {
        identifier
        for identifier, selected_levels in levels.items()
        if selected_levels and selected_levels <= allowed_levels
    }
    definitions = {identifier: all_definitions[identifier] for identifier in eligible}
    bounds = {identifier: decode_bounds(candidate) for identifier, candidate in definitions.items()}
    targets = {}
    affected_roots = set()
    selected_events = 0
    for root, event, identifier in events:
        if identifier not in eligible:
            continue
        residuals = (event.get("witness") or {}).get("residuals") or []
        if len(residuals) > 1:
            raise ValueError("DP polynomial event has multiple residuals")
        event_input = event["input"]
        canonical, error = canonicalize_cpf_input(event_input["cpf"])
        if error is not None:
            raise ValueError(f"cannot canonicalize selected DP state: {error}")
        keys = (
            event_input["problem_key"],
            hashlib.sha256(compact_xml_for_key(event_input["cpf"]).encode()).hexdigest(),
            hashlib.sha256(canonical.encode()).hexdigest(),
        )
        section = "dps" if event.get("level") == "dependency-pair" else "trs"
        minimum = (
            len(deleted_indices(event_input["cpf"], residuals[0]["cpf"], section))
            if residuals
            else len(cpf_rules(event_input["cpf"], section))
        )
        selected = target_atom(bounds[identifier], minimum)
        for key in keys:
            identity = (key, identifier)
            if identity in targets and targets[identity] != selected:
                raise ValueError("one canonical state/witness has conflicting deletion counts")
            targets[identity] = selected
        affected_roots.add(root)
        selected_events += 1

    targeted = generic = 0
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with args.output.open("w", encoding="utf-8") as output:
        for row in rows:
            if row.get("schema") == WITNESS_SCHEMA and row.get("witness_id") in definitions:
                continue
            if row.get("schema") != WITNESS_SCHEMA:
                key = row.get("problem_key", "")
                for group in GROUPS:
                    retained = []
                    seen = set()
                    for evidence in row.get(group) or []:
                        reference = evidence.get("candidate_ref")
                        if reference in definitions:
                            candidate = targets.get((key, reference), bounded_atom(bounds[reference]))
                            evidence = {
                                **{k: v for k, v in evidence.items() if k != "candidate_ref"},
                                "candidate": candidate,
                            }
                            targeted += candidate.startswith("poly-min-delete(")
                            generic += candidate.startswith("poly(")
                        identity = (evidence.get("candidate"), evidence.get("candidate_ref"), evidence.get("status"))
                        if identity not in seen:
                            seen.add(identity)
                            retained.append(evidence)
                    if group in row or retained:
                        row[group] = retained
            print(json.dumps(row, separators=(",", ":"), sort_keys=True), file=output)

    if args.affected_roots_output is not None:
        args.affected_roots_output.write_text("\n".join(sorted(affected_roots)) + "\n", encoding="utf-8")
    print(json.dumps({
        "definitions_removed": len(definitions),
        "definitions_retained": len(all_definitions) - len(definitions),
        "selected_events": selected_events,
        "targeted_state_replacements": targeted,
        "generic_replacements": generic,
        "affected_roots": len(affected_roots),
    }, sort_keys=True))


if __name__ == "__main__":
    main()
