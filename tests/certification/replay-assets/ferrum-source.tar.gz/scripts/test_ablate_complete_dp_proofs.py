import json
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path


class AblationTests(unittest.TestCase):
    def test_all_exact_removes_nested_and_referenced_actions_but_keeps_parameters(self):
        with tempfile.TemporaryDirectory() as directory:
            source = Path(directory) / "source.jsonl"
            output = Path(directory) / "output.jsonl"
            source.write_text(json.dumps({"schema": "ferrum.utility-guidance.witness.v1",
                "witness_id": "w", "candidate": "exact-matrix(hex=00)"}) + "\n" +
                json.dumps({"problem_key": "s", "prefer": [
                    {"candidate_ref": "w"},
                    {"candidate": "pipeline(graph; exact-size-change(hex=00))"},
                    {"candidate": "matrix(dimension=2,max-coefficient=3)"}]}) + "\n")
            subprocess.run([sys.executable, str(Path(__file__).with_name("ablate_complete_dp_proofs.py")),
                "--input", str(source), "--output", str(output), "--disable-all-exact"],
                check=True, capture_output=True)
            rows = [json.loads(line) for line in output.read_text().splitlines()]
            self.assertEqual(len(rows), 1)
            self.assertEqual(rows[0]["prefer"], [{"candidate": "matrix(dimension=2,max-coefficient=3)"}])

    def test_removes_selected_actions_and_preserves_nontermination(self):
        with tempfile.TemporaryDirectory() as directory:
            source = Path(directory) / "source.jsonl"
            output = Path(directory) / "output.jsonl"
            atoms = ["exact-dp-proof", "exact-trs-proof", "exact-trs-nontermination-proof", "exact-size-change"]
            definitions = [{"schema": "ferrum.utility-guidance.witness.v1",
                            "witness_id": atom, "candidate": atom + "(hex=00)"} for atom in atoms]
            state = {"problem_key": "state", "prefer": [{"candidate_ref": atom} for atom in atoms],
                     "possible": [{"candidate": "exact-trs-proof(hex=01)"}]}
            original = "".join(json.dumps(row) + "\n" for row in definitions + [state])
            source.write_text(original)
            command = [sys.executable, str(Path(__file__).with_name("ablate_complete_dp_proofs.py")),
                       "--input", str(source), "--output", str(output),
                       "--disable-atom", "exact-dp-proof", "--disable-atom", "exact-trs-proof"]
            subprocess.run(command, check=True, capture_output=True)
            rows = [json.loads(line) for line in output.read_text().splitlines()]
            self.assertEqual([row["witness_id"] for row in rows[:-1]], atoms[2:])
            self.assertEqual(rows[-1]["prefer"], [{"candidate_ref": atom} for atom in atoms[2:]])
            self.assertEqual(rows[-1]["possible"], [])
            self.assertEqual(source.read_text(), original)
            retained = output.read_text()
            self.assertNotEqual(subprocess.run(command, capture_output=True).returncode, 0)
            self.assertEqual(output.read_text(), retained)


if __name__ == "__main__":
    unittest.main()
