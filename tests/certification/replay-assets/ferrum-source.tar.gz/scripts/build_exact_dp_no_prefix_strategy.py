#!/usr/bin/env python3
"""Build a focused Ferrum strategy from a CPF's leading DP-NO restrictions.

The generated strategy contains no terminal proof and trusts no archived
answer.  Each retained ``dpRuleRemoval`` is replayed by Ferrum's checked exact
processor against the live state; search for the eventual nontermination
witness remains native and independently certified.
"""

from __future__ import annotations

import argparse
import copy
import json
from pathlib import Path
import xml.etree.ElementTree as ET

from extract_exact_fragment_training_data import iter_exact_rows
from extract_local_cpf_oracle_events import strategy_atom
from extract_subproof_training_data import load_xml


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("cpf", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("--limit", type=int, required=True)
    parser.add_argument(
        "--continuation", default="nontermination(bounded-narrowing)"
    )
    parser.add_argument(
        "--retain-pairs",
        help="after the CPF prefix, retain these zero-based live pair indices",
    )
    parser.add_argument(
        "--retain-rules",
        help="with --retain-pairs, retain these zero-based live rule indices",
    )
    args = parser.parse_args()

    root = load_xml(str(args.cpf), None)
    if root is None:
        raise SystemExit(f"cannot parse {args.cpf}")
    source = {
        "source_kind": "focused-external-hint",
        "proof_url": args.cpf.resolve().as_uri(),
        "xml_path": str(args.cpf.resolve()),
        "xml_format": "cpf",
        "normalizer": "focused",
        "year": 0,
        "category": "TRS_Standard",
        "benchmark": args.cpf.name,
        "tool": "external",
        "result": "NO",
        "certification": "external-hint",
    }
    rows, _counts = iter_exact_rows(source, root)
    atoms = [
        atom
        for row in rows
        if row["metadata"]["processor_tag"] == "dpRuleRemoval"
        and (atom := strategy_atom(row)) is not None
    ][: args.limit]
    if len(atoms) != args.limit:
        raise SystemExit(
            f"wanted {args.limit} leading restrictions, recovered {len(atoms)}"
        )
    if args.retain_pairs:
        # The last exact atom's child is the source of this additional checked
        # restriction.  Decode it directly so the generated strategy remains
        # a sequence of ordinary, source-bound processors.
        _previous_source, live_xml = json.loads(
            bytes.fromhex(atoms[-1].split("hex=", 1)[1][:-1]).decode("utf-8")
        )
        live = ET.fromstring(live_xml)
        dps = next(
            element for element in live.iter() if element.tag.rsplit("}", 1)[-1] == "dps"
        )
        rules = next(
            element for element in dps if element.tag.rsplit("}", 1)[-1] == "rules"
        )
        indices = [int(value) for value in args.retain_pairs.split(",")]
        selected = [copy.deepcopy(list(rules)[index]) for index in indices]
        rules[:] = selected
        if args.retain_rules:
            trs = next(
                element
                for element in live.iter()
                if element.tag.rsplit("}", 1)[-1] == "trs"
            )
            trs_rules = next(
                element
                for element in trs
                if element.tag.rsplit("}", 1)[-1] == "rules"
            )
            rule_indices = [int(value) for value in args.retain_rules.split(",")]
            trs_rules[:] = [
                copy.deepcopy(list(trs_rules)[index]) for index in rule_indices
            ]
        retained_xml = ET.tostring(live, encoding="unicode", short_empty_elements=True)
        encoded = json.dumps(
            [live_xml, retained_xml], ensure_ascii=False, separators=(",", ":")
        ).encode("utf-8").hex()
        atoms.append(f"exact-dp-no-rule-removal(hex={encoded})")
    body = ";\n    ".join([*atoms, args.continuation])
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(f"dp(pipeline(\n    {body}\n))\n", encoding="utf-8")
    print(f"wrote {len(atoms)} checked restrictions to {args.output}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
