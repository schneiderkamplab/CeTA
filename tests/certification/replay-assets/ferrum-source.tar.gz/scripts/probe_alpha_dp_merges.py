#!/usr/bin/env python3
"""Probe explicit identity-instantiation merges; export only weak native hints."""
import argparse
import hashlib
import json
from pathlib import Path
import subprocess
import xml.etree.ElementTree as ET
from build_credited_status_map_dataset import canonicalize_with_ferrum
from extract_exact_fragment_training_data import normalized_rule_signature


def pair_signature(cpf):
    root = ET.fromstring(cpf)
    pairs = root.find('.//dps')
    if pairs is None:
        return 0, set()
    rules = pairs.findall('.//rule')
    return len(rules), {repr(normalized_rule_signature(rule)) for rule in rules}


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--input', type=Path, required=True)
    p.add_argument('--output', type=Path, required=True)
    p.add_argument('--ferrum', required=True)
    args = p.parse_args()
    args.output.mkdir(parents=True, exist_ok=False)
    cpf, keys = args.input.read_text(), set()
    for index in range(64):
        count, signature = pair_signature(cpf)
        if count == len(signature):
            break
        source = args.output / f'{index}.cpf'
        source.write_text(cpf)
        with (args.output/f'{index}.json').open('x') as out, (args.output/f'{index}.log').open('x') as err:
            proc = subprocess.run([args.ferrum, 'probe-cpf', str(source),
                '--strategy', 'alpha-merge', '--timeout-ms', '10000'], stdout=out, stderr=err, timeout=15)
        result = json.loads((args.output/f'{index}.json').read_text())
        if proc.returncode or result.get('typed_outcome') != 'Transformed' or len(result.get('children', [])) != 1:
            break
        child = result['children'][0]['cpf']
        child_count, child_signature = pair_signature(child)
        if child_count >= count or child_signature != signature:
            raise RuntimeError('Expected a decreasing alpha-equivalent pair merge')
        keys.add(hashlib.sha256(cpf.strip().encode()).hexdigest())
        canonical = canonicalize_with_ferrum(cpf, args.ferrum, 10)
        keys.add(hashlib.sha256(canonical.strip().encode()).hexdigest())
        cpf = child
    (args.output/'residual.cpf').write_text(cpf)
    with (args.output/'hints.jsonl').open('x') as out:
        for key in sorted(keys):
            print(json.dumps(dict(schema='ferrum.utility-guidance.v2', problem_key=key,
                prefer=[dict(candidate='alpha-merge', status='transformed_weak', utility_score=1500,
                    attempts=1, certified_count=0, solved_count=0, transformed_count=1,
                    failed_count=0, timeout_count=0, best_elapsed_ms=0)],
                possible=[], avoid=[], timeout=[])), file=out)
    print(json.dumps(dict(hint_states=len(keys), residual_pairs=pair_signature(cpf)[0], certified_promotions=0)))


if __name__ == '__main__':
    main()
