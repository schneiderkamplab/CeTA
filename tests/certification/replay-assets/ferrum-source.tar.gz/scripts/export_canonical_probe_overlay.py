#!/usr/bin/env python3
"""Export weak, state-local oracle guidance from canonical probe results.

Canonical transformed probes are open proof fragments: they identify a sound
next processor and an exact typed child, but they are not a certified complete
proof until recursive assembly succeeds.  Consequently this exporter places
them in ``possible`` rather than promoting them to certified ``prefer``.
"""

from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path


SCHEMA = "ferrum.utility-guidance.v2"


def compact_xml_for_key(xml: str) -> str:
    """Mirror Ferrum's whitespace/entity normalization for structural keys."""
    data = xml.strip().encode()
    result = bytearray()
    index = 0
    while index < len(data):
        if data[index] == ord(">"):
            result.append(data[index])
            index += 1
            whitespace_start = index
            while index < len(data) and chr(data[index]).isspace():
                index += 1
            if index >= len(data) or data[index] != ord("<"):
                result.extend(data[whitespace_start:index])
            continue
        if data[index : index + 2] == b"/>":
            while result and chr(result[-1]).isspace():
                result.pop()
        result.append(data[index])
        index += 1
    return (
        result.decode()
        .replace("&apos;", "'")
        .replace("&#39;", "'")
        .replace("&#x27;", "'")
        .replace("&#X27;", "'")
    )


def digest(text: str) -> str:
    return hashlib.sha256(text.encode()).hexdigest()


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("probe", nargs="+", type=Path)
    parser.add_argument("--output", required=True, type=Path)
    args = parser.parse_args()

    evidence: dict[str, list[dict[str, object]]] = {}
    for path in args.probe:
        row = json.loads(path.read_text(encoding="utf-8"))
        if row.get("schema") != "ferrum.canonical-probe.v1":
            raise ValueError(f"{path}: not a canonical probe")
        if row.get("outcome") not in {"transformed", "solved"}:
            raise ValueError(f"{path}: probe is not positive")
        candidate = row.get("strategy_atom")
        source = (row.get("context") or {}).get("source_cpf")
        if not isinstance(candidate, str) or not candidate:
            raise ValueError(f"{path}: missing strategy atom")
        if not isinstance(source, str) or not source.strip():
            raise ValueError(f"{path}: missing source CPF")
        item = {
            "candidate": candidate,
            "status": "transformed_weak",
            "utility_score": 1.0,
            "best_elapsed_ms": row.get("elapsed_ms"),
            "attempts": 1,
            "solved_count": 0,
            "transformed_count": 1,
            "failed_count": 0,
            "timeout_count": 0,
            "certified_count": 0,
        }
        for key in {digest(source.strip()), digest(compact_xml_for_key(source))}:
            values = evidence.setdefault(key, [])
            if not any(value["candidate"] == candidate for value in values):
                values.append(item)

    args.output.parent.mkdir(parents=True, exist_ok=True)
    with args.output.open("w", encoding="utf-8") as output:
        for key, possible in sorted(evidence.items()):
            print(
                json.dumps(
                    {
                        "schema": SCHEMA,
                        "problem_key": key,
                        "prefer": [],
                        "possible": possible,
                        "avoid": [],
                        "timeout": [],
                    },
                    separators=(",", ":"),
                    sort_keys=True,
                ),
                file=output,
            )


if __name__ == "__main__":
    main()
