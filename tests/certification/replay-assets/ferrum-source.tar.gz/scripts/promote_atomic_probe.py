#!/usr/bin/env python3
"""Run one processor atom, retain every child state, and emit oracle evidence."""

from __future__ import annotations

import argparse
import hashlib
import json
import subprocess
from pathlib import Path


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--ferrum", type=Path, required=True)
    parser.add_argument("--ceta", type=Path, required=True)
    input_group = parser.add_mutually_exclusive_group(required=True)
    input_group.add_argument("--input", type=Path)
    input_group.add_argument(
        "--event-residual",
        metavar="EVENTS_JSONL:PROBLEM_KEY",
        help="materialize the matching residual CPF from a processor event log",
    )
    input_group.add_argument(
        "--event-input",
        metavar="EVENTS_JSONL:PROBLEM_KEY",
        help="materialize the matching processor-event input problem",
    )
    atom_group = parser.add_mutually_exclusive_group(required=True)
    atom_group.add_argument("--atom")
    atom_group.add_argument(
        "--atom-file",
        type=Path,
        help="load a processor atom from a file (avoids command-line size limits)",
    )
    atom_group.add_argument(
        "--atom-event",
        metavar="EVENTS_JSONL:PROBLEM_KEY",
        help="load the processor atom from the event whose input has this key",
    )
    parser.add_argument("--timeout-ms", type=int, default=60_000)
    parser.add_argument(
        "--utility-score",
        type=float,
        default=3_000.0,
        help="oracle score for this independently replayed atomic result",
    )
    parser.add_argument("--output-dir", type=Path, required=True)
    args = parser.parse_args()
    args.output_dir.mkdir(parents=True, exist_ok=True)
    atom = args.atom
    if args.atom_file:
        atom = args.atom_file.read_text(encoding="utf-8").strip()
    if args.atom_event:
        event_path_text, separator, problem_key = args.atom_event.rpartition(":")
        if not separator or not event_path_text or not problem_key:
            raise SystemExit("--atom-event must be EVENTS_JSONL:PROBLEM_KEY")
        for line in Path(event_path_text).read_text(encoding="utf-8").splitlines():
            event = json.loads(line)
            if (
                (event.get("input") or {}).get("problem_key") == problem_key
                and event.get("outcome") in {"solved", "transformed"}
            ):
                atom = event.get("processor")
                break
        if atom is None:
            raise SystemExit(
                f"processor for input {problem_key} not found in {event_path_text}"
            )
    assert atom is not None
    input_path = args.input
    event_selector = args.event_residual or args.event_input
    if event_selector:
        event_path_text, separator, problem_key = event_selector.rpartition(":")
        if not separator or not event_path_text or not problem_key:
            raise SystemExit("--event-residual must be EVENTS_JSONL:PROBLEM_KEY")
        event_path = Path(event_path_text)
        serialized = None
        for line in event_path.read_text(encoding="utf-8").splitlines():
            event = json.loads(line)
            if args.event_input:
                event_input = event.get("input") or {}
                if event_input.get("problem_key") == problem_key:
                    serialized = event_input.get("cpf")
            else:
                for residual in (event.get("witness") or {}).get("residuals", []):
                    if residual.get("problem_key") == problem_key:
                        serialized = residual.get("cpf")
                        break
            if serialized is not None:
                break
        if serialized is None:
            raise SystemExit(f"residual {problem_key} not found in {event_path}")
        suffix = ".json" if serialized.lstrip().startswith("{") else ".xml"
        input_path = args.output_dir / f"input-{problem_key}{suffix}"
        input_path.write_text(serialized.strip() + "\n", encoding="utf-8")
    assert input_path is not None
    fragment = args.output_dir / "fragment.xml"
    strategy_args = ["--strategy", atom]
    if args.atom_event or args.atom_file or len(atom) > 64_000:
        atom_path = args.output_dir / "atom.strategy"
        atom_path.write_text(atom + "\n", encoding="utf-8")
        strategy_args = ["--strategy-file", str(atom_path)]
    command = [
        str(args.ferrum), "probe-cpf", str(input_path), *strategy_args,
        "--timeout-ms", str(args.timeout_ms), "--cpf", str(fragment),
    ]
    completed = subprocess.run(command, check=True, text=True, capture_output=True)
    result = json.loads(completed.stdout)
    outcome = result["outcome"]
    if outcome not in {"solved", "transformed"}:
        (args.output_dir / "probe.json").write_text(
            json.dumps(result, indent=2, sort_keys=True) + "\n", encoding="utf-8"
        )
        raise SystemExit(f"atomic probe did not make positive progress: {outcome}")
    certified_count = 0
    if outcome == "solved":
        for _ in range(2):
            checked = subprocess.run(
                [str(args.ceta), str(fragment)], text=True, capture_output=True, check=False
            )
            if checked.returncode != 0 or "CERTIFIED" not in checked.stdout:
                raise SystemExit(
                    "solved atomic fragment was not certified by CeTA:\n"
                    + checked.stdout + checked.stderr
                )
            certified_count += 1
    (args.output_dir / "probe.json").write_text(
        json.dumps(result, indent=2, sort_keys=True) + "\n", encoding="utf-8"
    )
    input_text = input_path.read_text(encoding="utf-8").strip()
    input_key = hashlib.sha256(input_text.encode()).hexdigest()
    canonicalized = subprocess.run(
        [str(args.ferrum), "canonicalize-cpf", str(input_path)],
        check=True,
        text=True,
        capture_output=True,
    ).stdout.strip()
    canonical_key = hashlib.sha256(canonicalized.encode()).hexdigest()
    children = []
    for index, child in enumerate(result.get("children", [])):
        serialized = child["cpf"].strip()
        key = hashlib.sha256(serialized.encode()).hexdigest()
        suffix = ".json" if serialized.startswith("{") else ".xml"
        path = args.output_dir / f"child-{index}-{key}{suffix}"
        path.write_text(serialized + "\n", encoding="utf-8")
        children.append({"problem_key": key, "path": str(path.resolve())})
    status = "solved" if outcome == "solved" else "transformed_strong"
    selected = result["strategy_atom"]
    record = {
        "schema": "ferrum.utility-guidance.v2",
        "problem_key": input_key,
        "prefer": [{
            "candidate": selected,
            "status": status,
            "utility_score": args.utility_score,
            "best_elapsed_ms": result.get("elapsed_ms"),
            "attempts": 1,
            "solved_count": int(status == "solved"),
            "transformed_count": int(status == "transformed_strong"),
            "failed_count": 0,
            "timeout_count": 0,
            "certified_count": certified_count,
        }],
        "possible": [], "avoid": [], "timeout": [],
    }
    records = [record]
    if canonical_key != input_key:
        canonical_record = dict(record)
        canonical_record["problem_key"] = canonical_key
        records.append(canonical_record)
    (args.output_dir / "oracle-incoming.jsonl").write_text(
        "".join(
            json.dumps(row, sort_keys=True, separators=(",", ":")) + "\n"
            for row in records
        ),
        encoding="utf-8",
    )
    print(json.dumps({"input_key": input_key, "canonical_key": canonical_key, "selected_atom": selected, "status": status, "children": children}, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
