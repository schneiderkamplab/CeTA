#!/usr/bin/env python3

import sys
import copy
import unittest
import xml.etree.ElementTree as ET
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))

from import_aprove_aaecc_qmono import (
    aaecc_partition,
    canonical_rule,
    explicit_rule_indices,
    parse_linear_polynomial,
    restore_aprove_marked_aliases,
    splice_innermost_qmono_residual,
)


def rule(left: str, right: str) -> ET.Element:
    return ET.fromstring(
        f"<rule><lhs><funapp><name>{left}</name></funapp></lhs>"
        f"<rhs><funapp><name>{right}</name></funapp></rhs></rule>"
    )


class AProVEAaeccQMonotonicImporterTests(unittest.TestCase):
    def test_linear_polynomial_parser_handles_signed_terms(self) -> None:
        self.assertEqual(
            parse_linear_polynomial("2 + 3*x_1 - x_2 + x_1", 2),
            (2, [4, -1]),
        )

    def test_linear_polynomial_parser_rejects_nonlinear_terms(self) -> None:
        with self.assertRaisesRegex(ValueError, "unsupported polynomial term"):
            parse_linear_polynomial("x_1*x_2", 2)

    def test_canonical_rule_is_invariant_under_variable_renaming(self) -> None:
        first = ET.fromstring(
            "<rule><lhs><funapp><name>f</name><arg><var>x</var></arg></funapp></lhs>"
            "<rhs><funapp><name>g</name><arg><var>x</var></arg></funapp></rhs></rule>"
        )
        second = ET.fromstring(
            "<rule><lhs><funapp><name>f</name><arg><var>z</var></arg></funapp></lhs>"
            "<rhs><funapp><name>g</name><arg><var>z</var></arg></funapp></rhs></rule>"
        )
        self.assertEqual(canonical_rule(first), canonical_rule(second))

    def test_uppercase_aprove_alias_becomes_sharp_symbol(self) -> None:
        document = ET.fromstring(
            "<root><funapp><name>plus</name></funapp>"
            "<funapp><name>PLUS</name></funapp>"
            "<interpret><name>PLUS</name></interpret></root>"
        )
        restore_aprove_marked_aliases(document)
        self.assertEqual(
            [item.findtext("sharp/name") for item in document.findall("funapp")],
            [None, "plus"],
        )
        self.assertEqual(document.findtext("interpret/sharp/name"), "plus")

    def test_aaecc_partition_keeps_connected_symbols_outside_sigma(self) -> None:
        variable_rhs = ET.fromstring(
            "<rule><lhs><funapp><name>f</name><arg><var>x</var></arg></funapp></lhs>"
            "<rhs><var>x</var></rhs></rule>"
        )
        rules = [variable_rhs, rule("f", "g"), rule("g", "a"), rule("b", "c")]
        r1, r2, sigma = aaecc_partition(rules)
        self.assertEqual(r1, [0, 1, 2])
        self.assertEqual(r2, [3])
        self.assertEqual(sigma, {"b", "c"})

    def test_canonical_rule_accepts_cpf3_direct_terms(self) -> None:
        cpf2 = ET.fromstring(
            "<rule><lhs><funapp><name>f</name><arg><var>x</var></arg></funapp></lhs>"
            "<rhs><funapp><name>g</name><arg><var>x</var></arg></funapp></rhs></rule>"
        )
        cpf3 = ET.fromstring(
            "<rule><funapp><name>f</name><var>z</var></funapp>"
            "<funapp><name>g</name><var>z</var></funapp></rule>"
        )
        self.assertEqual(canonical_rule(cpf2), canonical_rule(cpf3))

    def test_rule_indices_are_inlined_before_splicing(self) -> None:
        document = ET.fromstring(
            "<certificationProblem><lookupTables><ruleTable><indexToRule>"
            "<index>7</index><rule><funapp><name>f</name></funapp>"
            "<funapp><name>g</name></funapp></rule></indexToRule></ruleTable>"
            "</lookupTables><proof><dpProof><depGraphProc><component><dps><rules>"
            "<ruleIndex>7</ruleIndex></rules></dps></component></depGraphProc>"
            "</dpProof></proof></certificationProblem>"
        )
        proof = copy.deepcopy(document.find("./proof/dpProof"))
        explicit_rule_indices(document, proof)
        self.assertEqual(proof.findtext(".//rule/funapp/name"), "f")
        self.assertIsNone(proof.find(".//ruleIndex"))

    def test_residual_splice_rejects_a_different_child_state(self) -> None:
        wrapper = ET.fromstring(
            "<unknownProof><subProof><dpInput><trs><rules>"
            "<rule><lhs><funapp><name>r</name></funapp></lhs>"
            "<rhs><funapp><name>s</name></funapp></rhs></rule>"
            "</rules></trs><dps><rules /></dps></dpInput></subProof></unknownProof>"
        )
        converted = ET.fromstring(
            "<root><innermostMonoRedPairProc><dpProof /></innermostMonoRedPairProc></root>"
        )
        residual = ET.fromstring(
            "<certificationProblem><input><dpInput><trs><rules>"
            "<rule><funapp><name>x</name></funapp><funapp><name>y</name></funapp></rule>"
            "</rules></trs><dps><rules /></dps></dpInput></input>"
            "<proof><dpProof><pIsEmpty /></dpProof></proof></certificationProblem>"
        )
        with self.assertRaisesRegex(ValueError, "does not match"):
            splice_innermost_qmono_residual(converted, [wrapper], residual)


if __name__ == "__main__":
    unittest.main()
