"""Report bounded witness-free replay evidence, without claiming intrinsic dependence."""
import argparse
import collections
import json
from pathlib import Path

from probe_witness_free_oracle import replace


def events(row):
    path = Path(row['artifact_dir']) / 'processor-events.jsonl'
    if not path.exists():
        return []
    return [json.loads(line) for line in path.open()]


def report(baseline, current):
    def indexed(rows):
        result = {(r['category'], r['path']): r for r in rows}
        if len(result) != len(rows):
            raise ValueError('duplicate roots')
        return result
    before, after = indexed(baseline), indexed(current)
    if before.keys() != after.keys():
        raise ValueError('root sets differ')
    categories = collections.defaultdict(collections.Counter)
    losses = []
    for key, old in before.items():
        if not old.get('certified') or old['status'] not in ('yes', 'no'):
            raise ValueError('baseline must contain only certified decisions')
        row = after[key]
        counts = categories[key[0]]
        counts['baseline'] += 1
        if row.get('certified') and row['status'] == old['status']:
            counts['certified_' + row['status']] += 1
            continue
        counts['unrecovered'] += 1
        trace = events(row)
        unsupported = collections.Counter()
        for event in events(old):
            atom = event.get('processor', '')
            if event.get('outcome') in ('solved', 'transformed') and replace(atom) is None:
                unsupported[atom.split('(', 1)[0]] += 1
        failures = collections.Counter()
        timeouts = []
        transformed = 0
        for event in trace:
            atom = event.get('processor', '').split('(', 1)[0]
            reason = event.get('failure_reason') or ''
            if event.get('outcome') == 'transformed':
                transformed += 1
            if reason:
                failures[atom + ': ' + reason] += 1
            timing_text = (event.get('outcome', '') + ' ' + reason).lower().replace('_', ' ')
            if 'timeout' in timing_text or 'timed out' in timing_text:
                timeouts.append({'processor': atom, 'elapsed_ms': event.get('elapsed_ms'),
                                 'state': event.get('input', {}).get('problem_key')})
        losses.append({'category': key[0], 'path': key[1], 'status': row['status'],
                       'elapsed_seconds': row.get('elapsed_seconds'),
                       'uncertified_decision': row['status'] in ('yes', 'no') and not row.get('certified'),
                       'polarity_change': row['status'] in ('yes', 'no') and row['status'] != old['status'],
                       'baseline_actions_without_current_conversion': dict(unsupported),
                       'local_timeouts': timeouts, 'transformation_events': transformed,
                       'failures': dict(failures), 'artifact_dir': row['artifact_dir']})
    return {'interpretation': 'Bounded search losses are not proof that exact witnesses are necessary. '
            'Unsupported baseline actions use the converter available when this report runs, '
            'which may be newer than the replay oracle. They are converter/search-vocabulary gaps; runtime traces '
            'alone do not distinguish synthesis incompleteness from an unguided new residual. '
            'Successful baseline events can include unused alternatives; these are investigation '
            'leads, not causal attribution of a root loss.',
            'categories': {k: dict(v) for k, v in categories.items()}, 'losses': losses}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--baseline', type=Path, required=True)
    parser.add_argument('--current', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--category', help='compare only this category on both sides')
    args = parser.parse_args()
    baseline = json.loads(args.baseline.read_text())
    current = json.loads(args.current.read_text())
    if args.category:
        baseline = [r for r in baseline if r.get('category') == args.category]
        current = [r for r in current if r.get('category') == args.category]
        if not baseline or not current:
            raise ValueError('selected category must be nonempty in both runs')
    result = report(baseline, current)
    with args.output.open('x') as out:
        json.dump(result, out, indent=2)
        out.write('\n')
    print(json.dumps(result['categories']))


if __name__ == '__main__':
    main()
