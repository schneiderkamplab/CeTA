#!/usr/bin/env python3
"""Materialize independent processor inputs/actions from retained CPF proofs."""
import argparse
import json
from pathlib import Path
import xml.etree.ElementTree as ET

from extract_exact_fragment_training_data import iter_exact_rows, child_input_for
from extract_local_cpf_oracle_events import strategy_atom


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--root', type=Path, required=True)
    parser.add_argument('--processor', required=True)
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--diagnostic-retained-continuation', action='store_true',
                        help='Certification-only harness, NOT oracle evidence: close the local step with its retained child proof.')
    parser.add_argument('--runtime-probes', type=Path,
                        help='Bind diagnostic continuation to the actual independently probed child input.')
    args = parser.parse_args()
    args.output.mkdir(parents=True, exist_ok=False)
    count = 0
    for path in args.root.rglob('proof.cpf.xml'):
        root = ET.parse(path).getroot()
        if not any(node.tag == args.processor for node in root.iter()):
            continue
        source = dict(proof_url=str(path), normalizer=None,
                      source_kind='local-certified-cpf', xml_path=str(path),
                      xml_format='4.0', year=2026, category='retained',
                      benchmark=str(path), tool='Ferrum',
                      result='NO' if root.find('proof/trsNonterminationProof') is not None else 'YES',
                      certification='retained-not-rechecked-by-this-script')
        rows, reasons = iter_exact_rows(source, root)
        for row in rows:
            if row['metadata']['processor_tag'] != args.processor:
                continue
            atom = strategy_atom(row)
            if atom is None:
                raise RuntimeError(f'No modular action: {path}: {reasons}')
            directory = args.output / str(count)
            directory.mkdir()
            (directory / 'input.cpf').write_text(row['input']['problem_xml'])
            (directory / 'atom.fs').write_text(atom)
            (directory / 'source.json').write_text(json.dumps({'source': str(path), 'row_id': row['id']}))
            if args.diagnostic_retained_continuation:
                step = ET.fromstring(row['output_xml'])
                proof = step.find('dpProof')
                if proof is None:
                    proof = step.find('dpNonterminationProof')
                if proof is None:
                    raise RuntimeError('Diagnostic continuation requires a DP child')
                child, error = child_input_for(step, proof, ET.fromstring(row['input']['problem_xml']))
                if error or child is None:
                    raise RuntimeError(error)
                child_xml = ET.tostring(child, encoding='unicode')
                if args.runtime_probes:
                    runtime = json.loads((args.runtime_probes / str(count) / 'stdout').read_text())
                    children = runtime.get('children', [])
                    if len(children) != 1:
                        raise RuntimeError('Expected one probed child')
                    child_xml = children[0]['cpf']
                payload = json.dumps([child_xml,
                                      ET.tostring(proof, encoding='unicode')]).encode().hex()
                kind = 'exact-dp-proof' if proof.tag == 'dpProof' else 'exact-dp-nontermination-proof'
                (directory / 'diagnostic.fs').write_text(f'pipeline({atom}; {kind}(hex={payload}))')
            count += 1
    print(json.dumps({'probes': count, 'output': str(args.output)}))


if __name__ == '__main__':
    main()
