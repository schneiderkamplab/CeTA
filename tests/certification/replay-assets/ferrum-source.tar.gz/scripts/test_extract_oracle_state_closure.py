#!/usr/bin/env python3

import json
import subprocess
import tempfile
import unittest
from pathlib import Path


SCRIPT = Path(__file__).with_name("extract_oracle_state_closure.py")


class OracleStateClosureTest(unittest.TestCase):
    def test_retains_only_witness_metadata_referenced_by_selected_state(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            oracle = root / "oracle.jsonl"
            roots = root / "roots.txt"
            output = root / "closure.jsonl"
            report = root / "report.json"
            oracle.write_text(
                "\n".join(
                    json.dumps(row)
                    for row in (
                        {"schema": "provenance"},
                        {"witness_id": "used", "candidate": "exact-red-pair(hex=00)"},
                        {"witness_id": "unused", "candidate": "exact-graph(hex=00)"},
                        {
                            "problem_key": "root",
                            "prefer": [{"candidate_ref": "used"}],
                            "possible": [],
                            "avoid": [],
                            "timeout": [],
                        },
                    )
                )
                + "\n",
                encoding="utf-8",
            )
            roots.write_text("root\n", encoding="utf-8")

            completed = subprocess.run(
                [
                    "python3",
                    str(SCRIPT),
                    "--oracle",
                    str(oracle),
                    "--keys",
                    str(roots),
                    "--output",
                    str(output),
                    "--report",
                    str(report),
                ],
                text=True,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
            )

            self.assertEqual(completed.returncode, 0, completed.stderr)
            rows = [json.loads(line) for line in output.read_text().splitlines()]
            self.assertEqual([row.get("witness_id") for row in rows[:-1]], ["used"])
            self.assertEqual(rows[-1]["problem_key"], "root")

    def test_rejects_missing_referenced_witness(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            oracle = root / "oracle.jsonl"
            roots = root / "roots.txt"
            output = root / "closure.jsonl"
            report = root / "report.json"
            oracle.write_text(
                json.dumps(
                    {
                        "problem_key": "root",
                        "prefer": [{"candidate_ref": "missing"}],
                        "possible": [],
                        "avoid": [],
                        "timeout": [],
                    }
                )
                + "\n",
                encoding="utf-8",
            )
            roots.write_text("root\n", encoding="utf-8")

            completed = subprocess.run(
                [
                    "python3",
                    str(SCRIPT),
                    "--oracle",
                    str(oracle),
                    "--keys",
                    str(roots),
                    "--output",
                    str(output),
                    "--report",
                    str(report),
                ],
                text=True,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
            )

            self.assertNotEqual(completed.returncode, 0)
            self.assertIn("missing witnesses", completed.stderr)


if __name__ == "__main__":
    unittest.main()
