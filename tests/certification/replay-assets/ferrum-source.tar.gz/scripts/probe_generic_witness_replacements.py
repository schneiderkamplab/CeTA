#!/usr/bin/env python3
"""Build an experimental oracle replacing bounded exact witnesses generically.

This does not promote evidence: candidate statistics still belong to the exact
witness and the output is only a replay probe.  Successful processor events
must pass through the normal CeTA-gated evidence pipeline before a generic atom
may enter the production oracle.
"""

from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path

WITNESS_SCHEMA = "ferrum.utility-guidance.witness.v1"
GROUPS = ("prefer", "possible", "avoid", "timeout")


def witness_id(candidate: str) -> str:
    return hashlib.sha256(candidate.encode("utf-8")).hexdigest()


def bounded_payload(candidate: str, family: str) -> list | None:
    prefix = f"exact-{family}(hex="
    if not candidate.startswith(prefix) or not candidate.endswith(")"):
        return None
    return json.loads(bytes.fromhex(candidate[len(prefix) : -1]))


def polynomial_replacement(
    candidate: str,
    *,
    max_constant_limit: int,
    max_coefficient_limit: int,
    max_symbols_limit: int,
    max_arity_limit: int,
) -> str | None:
    interpretation = bounded_payload(candidate, "poly")
    if interpretation is None:
        return None
    max_constant = max((item[1] for item in interpretation), default=0)
    max_coefficient = max(
        (value for item in interpretation for value in item[2]), default=0
    )
    max_symbols = len(interpretation)
    max_arity = max((len(item[2]) for item in interpretation), default=0)
    if any(
        value < 0
        for item in interpretation
        for value in (item[1], *item[2])
    ):
        return None
    if (
        max_constant > max_constant_limit
        or max_coefficient > max_coefficient_limit
        or max_symbols > max_symbols_limit
        or max_arity > max_arity_limit
    ):
        return None
    return (
        f"poly(max-constant={max_constant},max-coefficient={max_coefficient},"
        f"max-symbols={max_symbols},max-arity={max_arity})"
    )


def matrix_replacement(
    candidate: str,
    *,
    max_constant_limit: int,
    max_coefficient_limit: int,
    max_symbols_limit: int,
    max_arity_limit: int,
) -> str | None:
    interpretation = bounded_payload(candidate, "matrix")
    if interpretation is None:
        return None
    dimensions = {len(item[1]) for item in interpretation}
    if len(dimensions) != 1:
        return None
    dimension = next(iter(dimensions))
    values = [
        value
        for item in interpretation
        for value in (*item[1], *(entry for matrix in item[2] for row in matrix for entry in row))
    ]
    max_constant = max(
        (value for item in interpretation for value in item[1]), default=0
    )
    max_coefficient = max(
        (
            value
            for item in interpretation
            for matrix in item[2]
            for row in matrix
            for value in row
        ),
        default=0,
    )
    max_symbols = len(interpretation)
    max_arity = max((len(item[2]) for item in interpretation), default=0)
    if any(value < 0 for value in values):
        return None
    if (
        max_constant > max_constant_limit
        or max_coefficient > max_coefficient_limit
        or max_symbols > max_symbols_limit
        or max_arity > max_arity_limit
    ):
        return None
    return (
        f"matrix(max-constant={max_constant},max-coefficient={max_coefficient},"
        f"max-symbols={max_symbols},max-arity={max_arity},dimension={dimension})"
    )


def arctic_replacement(
    candidate: str,
    *,
    max_constant_limit: int,
    max_coefficient_limit: int,
    max_symbols_limit: int,
    max_arity_limit: int,
) -> str | None:
    payload = bounded_payload(candidate, "arctic")
    if payload is None:
        return None
    integer_domain, interpretation = payload
    if integer_domain:
        return None
    dimensions = {len(item[1]) for item in interpretation}
    if len(dimensions) != 1:
        return None
    dimension = next(iter(dimensions))
    minus_infinity = -(2**63)
    constants = [
        value
        for item in interpretation
        for value in item[1]
        if value != minus_infinity
    ]
    coefficients = [
        value
        for item in interpretation
        for matrix in item[2]
        for row in matrix
        for value in row
        if value != minus_infinity
    ]
    if any(value < 0 for value in (*constants, *coefficients)):
        return None
    max_constant = max(constants, default=0)
    max_coefficient = max(coefficients, default=0)
    max_symbols = len(interpretation)
    max_arity = max((len(item[2]) for item in interpretation), default=0)
    if (
        max_constant > max_constant_limit
        or max_coefficient > max_coefficient_limit
        or max_symbols > max_symbols_limit
        or max_arity > max_arity_limit
    ):
        return None
    return (
        f"arctic-matrix(dimension={dimension},max-constant={max_constant},"
        f"max-coefficient={max_coefficient},max-symbols={max_symbols},"
        f"max-arity={max_arity})"
    )


def integer_arctic_replacement(
    candidate: str,
    *,
    max_constant_limit: int,
    max_coefficient_limit: int,
    max_symbols_limit: int,
    max_arity_limit: int,
) -> str | None:
    payload = bounded_payload(candidate, "arctic")
    if payload is None:
        return None
    integer_domain, interpretation = payload
    if not integer_domain:
        return None
    dimensions = {len(item[1]) for item in interpretation}
    if len(dimensions) != 1:
        return None
    dimension = next(iter(dimensions))
    minus_infinity = -(2**63)
    values = [
        value
        for item in interpretation
        for value in (
            *item[1],
            *(entry for matrix in item[2] for row in matrix for entry in row),
        )
        if value != minus_infinity
    ]
    min_value = min(values, default=0)
    max_value = max(values, default=0)
    max_symbols = len(interpretation)
    max_arity = max((len(item[2]) for item in interpretation), default=0)
    if (
        abs(min_value) > max_constant_limit
        or abs(max_value) > max_coefficient_limit
        or max_symbols > max_symbols_limit
        or max_arity > max_arity_limit
    ):
        return None
    return (
        f"integer-arctic-matrix(dimension={dimension},min-value={min_value},"
        f"max-value={max_value},max-symbols={max_symbols},max-arity={max_arity})"
    )


def path_order_replacement(
    candidate: str,
    *,
    max_constant_limit: int,
    max_coefficient_limit: int,
    max_symbols_limit: int,
    max_arity_limit: int,
) -> str | None:
    del max_constant_limit, max_coefficient_limit, max_arity_limit
    payload = bounded_payload(candidate, "path-order")
    if payload is None:
        return None
    if len(payload) == 5:
        _, statuses, precedence, precedence_ranks, argument_filter = payload
    elif len(payload) == 4:
        statuses, precedence, precedence_ranks, argument_filter = payload
    else:
        return None
    symbols = (
        set(statuses)
        | set(precedence)
        | set(precedence_ranks)
        | set(argument_filter)
    )
    if len(symbols) > max_symbols_limit:
        return None
    return "path-order"


def integer_matrix_replacement(
    candidate: str,
    *,
    max_constant_limit: int,
    max_coefficient_limit: int,
    max_symbols_limit: int,
    max_arity_limit: int,
) -> str | None:
    interpretation = bounded_payload(candidate, "integer-matrix")
    if interpretation is None:
        return None
    dimensions = {len(item[1]) for item in interpretation}
    if len(dimensions) != 1:
        return None
    dimension = next(iter(dimensions))
    values = [
        value
        for item in interpretation
        for value in (
            *item[1],
            *(entry for matrix in item[2] for row in matrix for entry in row),
        )
    ]
    min_value = min(values, default=0)
    max_value = max(values, default=0)
    max_symbols = len(interpretation)
    max_arity = max((len(item[2]) for item in interpretation), default=0)
    if (
        abs(min_value) > max_constant_limit
        or abs(max_value) > max_coefficient_limit
        or max_symbols > max_symbols_limit
        or max_arity > max_arity_limit
    ):
        return None
    return (
        f"integer-matrix(dimension={dimension},min-value={min_value},"
        f"max-value={max_value},max-symbols={max_symbols},max-arity={max_arity})"
    )


def rational_polynomial_replacement(
    candidate: str,
    *,
    max_constant_limit: int,
    max_coefficient_limit: int,
    max_symbols_limit: int,
    max_arity_limit: int,
) -> str | None:
    payload = bounded_payload(candidate, "rat-poly")
    if payload is None:
        return None
    denominator, interpretation = payload
    max_constant = max((item[1] for item in interpretation), default=0)
    max_coefficient = max(
        (value for item in interpretation for value in item[2]), default=0
    )
    max_symbols = len(interpretation)
    max_arity = max((len(item[2]) for item in interpretation), default=0)
    if any(value < 0 for item in interpretation for value in (item[1], *item[2])):
        return None
    if (
        max_constant > max_constant_limit
        or max_coefficient > max_coefficient_limit
        or max_symbols > max_symbols_limit
        or max_arity > max_arity_limit
    ):
        return None
    return (
        f"rat-poly(max-constant={max_constant},max-coefficient={max_coefficient},"
        f"max-symbols={max_symbols},max-arity={max_arity},"
        f"denominator={denominator},delta-denominator={denominator})"
    )


def weak_polynomial_replacement(
    candidate: str,
    *,
    max_constant_limit: int,
    max_coefficient_limit: int,
    max_symbols_limit: int,
    max_arity_limit: int,
) -> str | None:
    payload = bounded_payload(candidate, "weak-poly")
    if payload is None:
        return None
    min_constant = min((item[1] for item in payload), default=0)
    max_constant = max((item[1] for item in payload), default=0)
    max_coefficient = max(
        (value for item in payload for value in item[2]), default=0
    )
    max_symbols = len(payload)
    max_arity = max((len(item[2]) for item in payload), default=0)
    if any(value < 0 for item in payload for value in item[2]):
        return None
    if (
        abs(min_constant) > max_constant_limit
        or abs(max_constant) > max_constant_limit
        or max_coefficient > max_coefficient_limit
        or max_symbols > max_symbols_limit
        or max_arity > max_arity_limit
    ):
        return None
    return (
        f"weak-poly(min-constant={min_constant},max-constant={max_constant},"
        f"max-coefficient={max_coefficient},max-symbols={max_symbols},"
        f"max-arity={max_arity})"
    )


def monotonic_polynomial_replacement(
    candidate: str,
    *,
    max_constant_limit: int,
    max_coefficient_limit: int,
    max_symbols_limit: int,
    max_arity_limit: int,
) -> str | None:
    payload = bounded_payload(candidate, "mono-poly")
    if payload is None:
        return None
    max_constant = max((item[1] for item in payload), default=0)
    max_coefficient = max(
        (value for item in payload for value in item[2]), default=0
    )
    max_symbols = len(payload)
    max_arity = max((len(item[2]) for item in payload), default=0)
    if any(value < 0 for item in payload for value in (item[1], *item[2])):
        return None
    if (
        max_constant > max_constant_limit
        or max_coefficient > max_coefficient_limit
        or max_symbols > max_symbols_limit
        or max_arity > max_arity_limit
    ):
        return None
    return (
        f"mono-poly(max-constant={max_constant},max-coefficient={max_coefficient},"
        f"max-symbols={max_symbols},max-arity={max_arity})"
    )


def max_polynomial_replacement(
    candidate: str,
    *,
    max_constant_limit: int,
    max_coefficient_limit: int,
    max_symbols_limit: int,
    max_arity_limit: int,
) -> str | None:
    payload = bounded_payload(candidate, "max-poly")
    if payload is None:
        return None
    alternatives = [alternative for item in payload for alternative in item[1]]
    max_constant = max((alternative[0] for alternative in alternatives), default=0)
    max_coefficient = max(
        (value for alternative in alternatives for value in alternative[1]), default=0
    )
    max_alternatives = max((len(item[1]) for item in payload), default=1)
    max_symbols = len(payload)
    max_arity = max(
        (len(alternative[1]) for alternative in alternatives), default=0
    )
    if any(
        value < 0
        for alternative in alternatives
        for value in (alternative[0], *alternative[1])
    ):
        return None
    if (
        max_constant > max_constant_limit
        or max_coefficient > max_coefficient_limit
        or max_symbols > max_symbols_limit
        or max_arity > max_arity_limit
    ):
        return None
    return (
        f"max-poly(max-constant={max_constant},max-coefficient={max_coefficient},"
        f"max-symbols={max_symbols},max-arity={max_arity},"
        f"alternatives={max_alternatives})"
    )


def subterm_replacement(
    candidate: str,
    *,
    max_constant_limit: int,
    max_coefficient_limit: int,
    max_symbols_limit: int,
    max_arity_limit: int,
) -> str | None:
    del (
        max_constant_limit,
        max_coefficient_limit,
        max_symbols_limit,
        max_arity_limit,
    )
    return "subterm" if bounded_payload(candidate, "subterm") is not None else None


def kbo_replacement(
    candidate: str,
    *,
    max_constant_limit: int,
    max_coefficient_limit: int,
    max_symbols_limit: int,
    max_arity_limit: int,
) -> str | None:
    del max_constant_limit, max_arity_limit
    payload = bounded_payload(candidate, "kbo")
    if payload is None or len(payload) != 3:
        return None
    precedence_order, precedence, weights = payload
    symbols = set(precedence_order) | set(precedence) | set(weights)
    max_weight = max(weights.values(), default=0)
    if (
        any(value < 0 for value in weights.values())
        or max_weight > max_coefficient_limit
        or len(symbols) > max_symbols_limit
    ):
        return None
    return f"kbo(max-weight={max_weight},max-symbols={len(symbols)})"


def semantic_labeling_replacement(
    candidate: str,
    *,
    max_constant_limit: int,
    max_coefficient_limit: int,
    max_symbols_limit: int,
    max_arity_limit: int,
) -> str | None:
    del max_constant_limit, max_coefficient_limit, max_symbols_limit, max_arity_limit
    payload = bounded_payload(candidate, "semantic-labeling")
    if not isinstance(payload, dict) or payload.get("carrier_size") != 2:
        return None
    return "semantic-labeling"


def relative_semantic_labeling_replacement(
    candidate: str,
    *,
    max_constant_limit: int,
    max_coefficient_limit: int,
    max_symbols_limit: int,
    max_arity_limit: int,
) -> str | None:
    del max_constant_limit, max_coefficient_limit, max_symbols_limit, max_arity_limit
    prefix = "exact-relative-semantic-labeling(carrier-size="
    if not candidate.startswith(prefix) or not candidate.endswith(")"):
        return None
    header, separator, encoded = candidate.partition(",hex=")
    if not separator:
        return None
    try:
        carrier_size = int(header[len(prefix) :])
        payload = json.loads(bytes.fromhex(encoded[:-1]))
    except (ValueError, json.JSONDecodeError):
        return None
    if carrier_size < 1 or not payload:
        return None
    return (
        "relative-semantic-labeling"
        if carrier_size == 2
        else f"relative-semantic-labeling(carrier-size={carrier_size})"
    )


def match_bounds_replacement(
    candidate: str,
    *,
    max_constant_limit: int,
    max_coefficient_limit: int,
    max_symbols_limit: int,
    max_arity_limit: int,
) -> str | None:
    del max_constant_limit, max_coefficient_limit, max_symbols_limit, max_arity_limit
    payload = bounded_payload(candidate, "match-bounds")
    if not isinstance(payload, dict) or payload.get("bounds_type") != "Match":
        return None
    bound = payload.get("bound")
    if not isinstance(bound, int) or bound < 0:
        return None
    return f"match-bounds(max-bound={bound})"


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("input", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument(
        "--family",
        choices=(
            "poly",
            "matrix",
            "arctic",
            "integer-arctic",
            "path-order",
            "integer-matrix",
            "rat-poly",
            "weak-poly",
            "mono-poly",
            "max-poly",
            "subterm",
            "kbo",
            "semantic-labeling",
            "relative-semantic-labeling",
            "match-bounds",
        ),
        default="poly",
    )
    parser.add_argument("--max-constant", type=int, required=True)
    parser.add_argument("--max-coefficient", type=int, required=True)
    parser.add_argument("--max-symbols", type=int, required=True)
    parser.add_argument("--max-arity", type=int, required=True)
    parser.add_argument("--run-dir", type=Path, action="append", default=[])
    parser.add_argument(
        "--retain-witnesses",
        type=Path,
        help="newline-separated exact candidates or witness identifiers not to replace",
    )
    parser.add_argument("--affected-roots-output", type=Path)
    args = parser.parse_args()

    definitions = {}
    with args.input.open(encoding="utf-8") as source:
        for line in source:
            row = json.loads(line)
            if row.get("schema") == WITNESS_SCHEMA:
                definitions[row["witness_id"]] = row["candidate"]

    retained_ids = set()
    if args.retain_witnesses is not None:
        for line in args.retain_witnesses.read_text(encoding="utf-8").splitlines():
            value = line.strip()
            if value:
                retained_ids.add(
                    value
                    if len(value) == 64 and all(char in "0123456789abcdef" for char in value)
                    else witness_id(value)
                )

    replacements = {}
    for identifier, candidate in definitions.items():
        if identifier in retained_ids:
            continue
        replacement_function = {
            "poly": polynomial_replacement,
            "matrix": matrix_replacement,
            "arctic": arctic_replacement,
            "integer-arctic": integer_arctic_replacement,
            "path-order": path_order_replacement,
            "integer-matrix": integer_matrix_replacement,
            "rat-poly": rational_polynomial_replacement,
            "weak-poly": weak_polynomial_replacement,
            "mono-poly": monotonic_polynomial_replacement,
            "max-poly": max_polynomial_replacement,
            "subterm": subterm_replacement,
            "kbo": kbo_replacement,
            "semantic-labeling": semantic_labeling_replacement,
            "relative-semantic-labeling": relative_semantic_labeling_replacement,
            "match-bounds": match_bounds_replacement,
        }[args.family]
        replacement = replacement_function(
            candidate,
            max_constant_limit=args.max_constant,
            max_coefficient_limit=args.max_coefficient,
            max_symbols_limit=args.max_symbols,
            max_arity_limit=args.max_arity,
        )
        if replacement is not None:
            replacements[identifier] = replacement

    occurrences = 0
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with args.output.open("w", encoding="utf-8") as output:
        with args.input.open(encoding="utf-8") as source:
            for line in source:
                row = json.loads(line)
                if row.get("schema") == WITNESS_SCHEMA:
                    if row["witness_id"] in replacements:
                        continue
                else:
                    for group in GROUPS:
                        seen = set()
                        retained = []
                        for evidence in row.get(group) or []:
                            reference = evidence.get("candidate_ref")
                            if reference in replacements:
                                evidence = {
                                    **{
                                        key: value
                                        for key, value in evidence.items()
                                        if key != "candidate_ref"
                                    },
                                    "candidate": replacements[reference],
                                }
                                occurrences += 1
                            identity = (
                                evidence.get("candidate"),
                                evidence.get("candidate_ref"),
                                evidence.get("status"),
                            )
                            if identity in seen:
                                continue
                            seen.add(identity)
                            retained.append(evidence)
                        if group in row or retained:
                            row[group] = retained
                print(
                    json.dumps(row, separators=(",", ":"), sort_keys=True),
                    file=output,
                )

    affected = set()
    target_candidates = {
        definitions[identifier] for identifier in replacements
    }
    for run_dir in args.run_dir:
        for result_path in run_dir.rglob("result.json"):
            result = json.loads(result_path.read_text(encoding="utf-8"))
            if not result.get("certified"):
                continue
            events_path = result_path.with_name("processor-events.jsonl")
            if not events_path.exists():
                continue
            if any(
                json.loads(line).get("processor") in target_candidates
                for line in events_path.open(encoding="utf-8")
            ):
                affected.add(result["path"])
    if args.affected_roots_output is not None:
        args.affected_roots_output.parent.mkdir(parents=True, exist_ok=True)
        args.affected_roots_output.write_text(
            "\n".join(sorted(affected)) + ("\n" if affected else ""),
            encoding="utf-8",
        )

    print(
        json.dumps(
            {
                "input": str(args.input),
                "output": str(args.output),
                "replaced_witnesses": len(replacements),
                "retained_witnesses": len(retained_ids & definitions.keys()),
                "replacement_atoms": len(set(replacements.values())),
                "replaced_occurrences": occurrences,
                "affected_roots": len(affected),
                "affected_roots_output": (
                    str(args.affected_roots_output)
                    if args.affected_roots_output is not None
                    else None
                ),
            },
            sort_keys=True,
        )
    )


if __name__ == "__main__":
    main()
