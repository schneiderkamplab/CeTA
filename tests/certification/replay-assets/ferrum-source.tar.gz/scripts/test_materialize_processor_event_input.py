#!/usr/bin/env python3

import sys
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))

from materialize_processor_event_input import find_inline_cpf


class ProcessorEventMaterializationTests(unittest.TestCase):
    def test_recovers_predecessor_residual(self) -> None:
        events = [
            {
                "input": {"problem_key": "parent", "cpf": "<parent/>"},
                "witness": {
                    "residuals": [
                        {"problem_key": "child", "cpf": "<child/>"}
                    ]
                },
            },
            {"input": {"problem_key": "child"}},
        ]
        self.assertEqual(find_inline_cpf(events, "child"), (1, "<child/>"))

    def test_prefers_first_content_addressed_copy(self) -> None:
        events = [
            {"input": {"problem_key": "state", "cpf": "<first/>"}},
            {"input": {"problem_key": "state", "cpf": "<second/>"}},
        ]
        self.assertEqual(find_inline_cpf(events, "state"), (1, "<first/>"))


if __name__ == "__main__":
    unittest.main()
