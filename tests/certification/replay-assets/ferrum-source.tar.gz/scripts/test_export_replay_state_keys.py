import hashlib
import unittest
from export_replay_state_keys import state_keys


class ReplayKeysTests(unittest.TestCase):
    def test_includes_typed_children_and_hash_only_references(self):
        cpf = '<dpInput/>'
        key = hashlib.sha256(cpf.encode()).hexdigest()
        self.assertEqual(state_keys([dict(input=dict(problem_key=key)),
            dict(witness=dict(residuals=[dict(problem_key=key, cpf=cpf)]))]), {key})

    def test_rejects_stale_context(self):
        with self.assertRaisesRegex(ValueError, 'digest mismatch'):
            state_keys([dict(input=dict(problem_key='a' * 64, cpf='<changed/>'))])


if __name__ == '__main__':
    unittest.main()
