#!/usr/bin/env python3
"""Normalize retained certified bounds CPFs and recheck them with CeTA."""

from __future__ import annotations

import argparse
import concurrent.futures
import json
import subprocess
from pathlib import Path

from normalize_bounds_cpf import normalize_file


BOUNDS_TAGS = (
    "<bounds>",
    "<relativeBounds>",
    "<rfcBounds>",
    "<rfcAutomatonClosedBounds>",
    "<rfcRelativeBounds>",
    "<rfcAutomatonClosedRelativeBounds>",
    "<rfcMatchboxRelativeBounds>",
    "<rfcNativeMatchboxRelativeBounds>",
)


def retained_certificates(details_files: list[Path]) -> list[dict]:
    certificates = []
    seen = set()
    for details_file in details_files:
        for row in json.loads(details_file.read_text()):
            if (
                row.get("status") != "yes"
                or not row.get("certified")
                or not row.get("path")
            ):
                continue
            artifact_dir = Path(row.get("artifact_dir", ""))
            if not artifact_dir.is_absolute():
                artifact_dir = Path.cwd() / artifact_dir
            cpf = artifact_dir / "proof.cpf3.xml"
            if not cpf.is_file():
                continue
            text = cpf.read_text(errors="ignore")
            if not any(tag in text for tag in BOUNDS_TAGS):
                continue
            key = (str(Path(row["path"]).resolve()), str(cpf.resolve()))
            if key in seen:
                continue
            seen.add(key)
            certificates.append(
                {
                    "problem": key[0],
                    "source_cpf": key[1],
                    "source_details": str(details_file),
                }
            )
    return certificates


def check_one(
    index: int,
    certificate: dict,
    output_dir: Path,
    ceta: Path,
    timeout: float,
) -> dict:
    artifact = output_dir / f"{index:04d}"
    artifact.mkdir(parents=True, exist_ok=True)
    normalized = artifact / "proof.normalized.cpf3.xml"
    result = dict(certificate)
    result["artifact_dir"] = str(artifact)
    try:
        normalize_file(Path(certificate["source_cpf"]), normalized)
        completed = subprocess.run(
            [str(ceta), str(normalized)],
            capture_output=True,
            text=True,
            timeout=timeout,
            check=False,
        )
        (artifact / "ceta.stdout").write_text(completed.stdout)
        (artifact / "ceta.stderr").write_text(completed.stderr)
        result["returncode"] = completed.returncode
        result["certified"] = completed.returncode == 0
        result["timeout"] = False
    except subprocess.TimeoutExpired as error:
        (artifact / "ceta.stdout").write_text(error.stdout or "")
        (artifact / "ceta.stderr").write_text(error.stderr or "")
        result["returncode"] = None
        result["certified"] = False
        result["timeout"] = True
    except Exception as error:  # Preserve malformed artifacts for diagnosis.
        (artifact / "error.txt").write_text(f"{type(error).__name__}: {error}\n")
        result["returncode"] = None
        result["certified"] = False
        result["timeout"] = False
        result["error"] = str(error)
    (artifact / "result.json").write_text(json.dumps(result, indent=2) + "\n")
    return result


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--details", type=Path, action="append", required=True)
    parser.add_argument("--output-dir", type=Path, required=True)
    parser.add_argument("--ceta", type=Path, required=True)
    parser.add_argument("--jobs", type=int, default=32)
    parser.add_argument("--timeout", type=float, default=60.0)
    args = parser.parse_args()

    certificates = retained_certificates(args.details)
    args.output_dir.mkdir(parents=True, exist_ok=True)
    results = []
    with concurrent.futures.ThreadPoolExecutor(max_workers=args.jobs) as executor:
        futures = [
            executor.submit(
                check_one,
                index,
                certificate,
                args.output_dir,
                args.ceta.resolve(),
                args.timeout,
            )
            for index, certificate in enumerate(certificates)
        ]
        for completed, future in enumerate(
            concurrent.futures.as_completed(futures), start=1
        ):
            results.append(future.result())
            if completed % 10 == 0 or completed == len(futures):
                certified = sum(result["certified"] for result in results)
                print(
                    f"completed={completed}/{len(futures)} certified={certified} "
                    f"failed={completed - certified}",
                    flush=True,
                )

    results.sort(key=lambda result: (result["problem"], result["source_cpf"]))
    (args.output_dir / "details.json").write_text(json.dumps(results, indent=2) + "\n")
    summary = {
        "total_certificates": len(results),
        "unique_problems": len({result["problem"] for result in results}),
        "certified": sum(result["certified"] for result in results),
        "timeouts": sum(result["timeout"] for result in results),
        "failed": sum(not result["certified"] for result in results),
    }
    (args.output_dir / "summary.json").write_text(json.dumps(summary, indent=2) + "\n")
    print(json.dumps(summary, sort_keys=True))


if __name__ == "__main__":
    main()
