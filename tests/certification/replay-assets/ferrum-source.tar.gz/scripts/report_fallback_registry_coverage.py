#!/usr/bin/env python3
"""Report processor-event states absent from a state-first registry/oracle."""

from __future__ import annotations

import argparse
import hashlib
import json
import sqlite3
from pathlib import Path


def raw_hash(cpf: str) -> str:
    return hashlib.sha256(cpf.strip().encode()).hexdigest()


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--events-root", type=Path, required=True)
    parser.add_argument("--campaign-sqlite", type=Path, action="append", default=[])
    parser.add_argument("--oracle", type=Path, required=True)
    parser.add_argument("--canonical-cache", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--absent-jsonl", type=Path, required=True)
    args = parser.parse_args()

    known: set[str] = set()
    for database in args.campaign_sqlite:
        with sqlite3.connect(database) as connection:
            for row in connection.execute(
                "SELECT raw_hash, canonical_hash, source_problem_key FROM states"
            ):
                known.update(value for value in row if value)
    with args.oracle.open(encoding="utf-8") as stream:
        for line in stream:
            if line.strip():
                record = json.loads(line)
                known.add(record["problem_key"])
                if record.get("canonical_problem_key"):
                    known.add(record["canonical_problem_key"])

    cache = sqlite3.connect(args.canonical_cache)
    seen: dict[str, dict] = {}
    event_paths = set(args.events_root.rglob("processor-events.jsonl")) | set(
        args.events_root.rglob("*.processor-events.jsonl")
    )
    for path in sorted(event_paths):
        with path.open(encoding="utf-8", errors="replace") as stream:
            for line_number, line in enumerate(stream, 1):
                try:
                    event = json.loads(line)
                except json.JSONDecodeError:
                    continue
                input_row = event.get("input") or {}
                cpf = input_row.get("cpf")
                key = input_row.get("problem_key")
                if cpf:
                    key = raw_hash(cpf)
                if not key:
                    continue
                canonical = None
                cached = cache.execute(
                    "SELECT canonical_cpf, note FROM canonical_cpf_cache WHERE raw_key=?",
                    (key,),
                ).fetchone()
                if cached is not None and cached[1] is None:
                    canonical = hashlib.sha256(cached[0].encode()).hexdigest()
                entry = seen.setdefault(
                    key,
                    {
                        "raw_hash": key,
                        "canonical_hash": canonical,
                        "cpf": cpf,
                        "origins": [],
                    },
                )
                entry["origins"].append(
                    {
                        "event_file": str(path),
                        "line": line_number,
                        "problem_id": event.get("problem_id"),
                        "problem_kind": event.get("problem_kind"),
                        "strategy_atom": event.get("strategy_atom"),
                    }
                )
    cache.close()

    absent = [
        entry
        for entry in seen.values()
        if entry["raw_hash"] not in known
        and (not entry["canonical_hash"] or entry["canonical_hash"] not in known)
    ]
    absent.sort(key=lambda entry: entry["raw_hash"])
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.absent_jsonl.parent.mkdir(parents=True, exist_ok=True)
    with args.absent_jsonl.open("w", encoding="utf-8") as stream:
        for entry in absent:
            stream.write(json.dumps(entry, sort_keys=True, separators=(",", ":")) + "\n")
    report = {
        "schema": "ferrum.fallback-registry-coverage.v1",
        "unique_event_states": len(seen),
        "present_states": len(seen) - len(absent),
        "absent_states": len(absent),
        "event_files": len(event_paths),
        "absent_jsonl": str(args.absent_jsonl),
    }
    args.output.write_text(json.dumps(report, indent=2, sort_keys=True) + "\n")
    print(json.dumps(report, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
