import hashlib
import unittest
from normalize_native_oracle_actions import normalize


class NormalizeTests(unittest.TestCase):
    def test_role_proposal_has_no_inherited_credit(self):
        row = normalize(dict(possible=[dict(candidate='path-order')]), add_gm04=True)
        role = row['possible'][-1]
        self.assertEqual(role['candidate'], 'gm04-rpo')
        self.assertEqual(role['certified_count'], 0)
        self.assertEqual(role['attempts'], 0)
        self.assertEqual(row['replay_order'], [hashlib.sha256(b'gm04-rpo').hexdigest()])

    def test_maps_order_without_inheriting_certificate_credit(self):
        atom = 'csr-improved-dp(pipeline(graph; size-change))'
        row = normalize(dict(prefer=[dict(candidate=atom, certified_count=1, solved_count=1)],
                             replay_order=[hashlib.sha256(atom.encode()).hexdigest()]))
        self.assertEqual(row['prefer'], [])
        self.assertEqual(row['possible'][0]['candidate'], 'csr-improved-dp')
        self.assertEqual(row['possible'][0]['certified_count'], 0)
        self.assertEqual(row['possible'][0]['solved_count'], 0)
        self.assertEqual(row['replay_order'],
                         [hashlib.sha256(b'csr-improved-dp').hexdigest()])

    def test_drops_unaddressed_sequences_and_preserves_atomic_parameters(self):
        row = normalize(dict(possible=[dict(candidate='matrix(dimension=2)'),
                                       dict(candidate='graph; size-change')]))
        self.assertEqual(row['possible'], [dict(candidate='matrix(dimension=2)')])


if __name__ == '__main__':
    unittest.main()
