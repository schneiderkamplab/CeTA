#!/usr/bin/env python3
"""Import TermCOMP 2008-2013 proof artefacts from the Zenodo raw-data archive."""

from __future__ import annotations

import argparse
import bz2
import csv
import hashlib
import json
import re
import sqlite3
import tarfile
import time
import urllib.request
from pathlib import Path
from typing import Any

from collect_termcomp_proofs import detect_format, extract_features, init_db, safe_name
from import_termcomp_zenodo_archives import MAX_INLINE_EXTRACT_BYTES, ensure_archive_columns


ZENODO_RECORD = 14410457
PRE2014_INLINE_EXTRACT_BYTES = 256_000
PRE2014_MAX_DECOMPRESSED_BYTES = 4_000_000
FILES = {
    "results": "competition_results_2008_to_2013.tgz",
    "proofs": "zipped_proofs.tar",
    "coq": "zipped_Coq_scripts.tar",
}


def fetch_record() -> dict[str, Any]:
    url = f"https://zenodo.org/api/records/{ZENODO_RECORD}"
    req = urllib.request.Request(url, headers={"User-Agent": "ferrum-proof-corpus/0.1"})
    with urllib.request.urlopen(req, timeout=60) as response:
        return json.load(response)


def download(url: str, destination: Path) -> None:
    destination.parent.mkdir(parents=True, exist_ok=True)
    tmp = destination.with_suffix(destination.suffix + ".tmp")
    req = urllib.request.Request(url, headers={"User-Agent": "ferrum-proof-corpus/0.1"})
    with urllib.request.urlopen(req, timeout=300) as response, tmp.open("wb") as handle:
        while True:
            chunk = response.read(1024 * 1024)
            if not chunk:
                break
            handle.write(chunk)
    tmp.replace(destination)


def ensure_files(cache: Path) -> dict[str, Path]:
    record = fetch_record()
    by_key = {item["key"]: item["links"]["self"] for item in record.get("files", [])}
    paths = {}
    for label, key in FILES.items():
        path = cache / key
        if not path.exists() or path.stat().st_size == 0:
            download(by_key[key], path)
        paths[label] = path
    return paths


def competition_year(value: str) -> int:
    match = re.search(r"\b(20\d\d)\b", value)
    if not match:
        raise ValueError(f"cannot determine competition year from {value!r}")
    return int(match.group(1))


def normalized_result(value: str) -> str | None:
    text = value.strip().upper()
    if text.startswith("YES"):
        return "YES"
    if text.startswith("NO"):
        return "NO"
    return None


def tar_members(path: Path, prefix: str) -> dict[str, str]:
    members = {}
    with tarfile.open(path) as tf:
        for member in tf:
            if not member.isfile() or not member.name.startswith(prefix) or not member.name.endswith(".txt.bz2"):
                continue
            result_id = Path(member.name).name.removesuffix(".txt.bz2")
            members[result_id] = member.name
    return members


def read_bz2_member(tf: tarfile.TarFile, member_name: str) -> tuple[bytes, bool]:
    handle = tf.extractfile(member_name)
    if handle is None:
        raise FileNotFoundError(member_name)
    compressed = handle.read()
    decompressor = bz2.BZ2Decompressor()
    chunks = []
    produced = 0
    for offset in range(0, len(compressed), 64 * 1024):
        chunk = decompressor.decompress(compressed[offset : offset + 64 * 1024])
        produced += len(chunk)
        if produced > PRE2014_MAX_DECOMPRESSED_BYTES:
            return compressed, True
        chunks.append(chunk)
    return b"".join(chunks), False


def feature_summary(data: bytes) -> tuple[str, str, dict[str, Any]]:
    inline_limit = min(MAX_INLINE_EXTRACT_BYTES, PRE2014_INLINE_EXTRACT_BYTES)
    if len(data) > inline_limit:
        detected, text = detect_format(data[: min(len(data), 4096)])
        first_line = text.splitlines()[0].strip() if text.splitlines() else ""
        return detected, first_line, {
            "first_line": first_line,
            "extraction_skipped": "artefact exceeds inline extraction size limit",
            "bytes": len(data),
            "inline_extract_limit": inline_limit,
        }
    detected, features = extract_features(data)
    return detected, features.get("first_line", ""), features


def destination(root: Path, year: int, category: str, certification: str, tool: str, problem: str, name: str) -> Path:
    return (
        root
        / "artefacts"
        / f"Y{year}"
        / safe_name(category)
        / certification
        / safe_name(tool)
        / safe_name(problem)
        / safe_name(name)
    )


def insert_row(
    conn: sqlite3.Connection,
    root: Path,
    *,
    year: int,
    category: str,
    problem: str,
    tool: str,
    result: str,
    certification: str,
    proof_url: str,
    runtime: float | None,
    cert_runtime: float | None,
    archive_url: str,
    archive_member: str,
    data: bytes,
    stored_compressed: bool = False,
) -> None:
    local_name = Path(archive_member).name if stored_compressed else Path(archive_member).name.removesuffix(".bz2")
    local_path = destination(root, year, category, certification, tool, problem, local_name)
    local_path.parent.mkdir(parents=True, exist_ok=True)
    local_path.write_bytes(data)
    if stored_compressed:
        detected = "compressed-bz2"
        first_line = ""
        features = {
            "archive_member": archive_member,
            "compressed_bz2": True,
            "extraction_skipped": "decompressed artefact exceeds pre-2014 size limit",
            "max_decompressed_bytes": PRE2014_MAX_DECOMPRESSED_BYTES,
        }
    else:
        detected, first_line, features = feature_summary(data)
    conn.execute(
        """
        insert or replace into proofs (
            year, category, benchmark, tool, tool_column, result, certification,
            proof_url, error_url, benchmark_url, runtime_seconds, cert_runtime_seconds,
            local_path, sha256, bytes, first_line, detected_format, extracted_json,
            download_error, downloaded_at, archive_url, archive_member
        ) values (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """,
        (
            year,
            category,
            problem,
            tool,
            -1,
            result,
            certification,
            proof_url,
            None,
            "",
            runtime,
            cert_runtime,
            str(local_path),
            hashlib.sha256(data).hexdigest(),
            len(data),
            first_line,
            detected,
            json.dumps(features, sort_keys=True),
            None,
            time.time(),
            archive_url,
            archive_member,
        ),
    )


def load_tool_rows(results_archive: Path) -> dict[str, dict[str, str]]:
    with tarfile.open(results_archive, "r:gz") as tf:
        handle = tf.extractfile("competition_tool_results.csv")
        if handle is None:
            raise FileNotFoundError("competition_tool_results.csv")
        rows = {}
        for row in csv.DictReader(line.decode("utf-8", "replace") for line in handle):
            result_id = row.get("Result Id", "").strip()
            if result_id:
                rows[result_id] = row
        return rows


def load_cert_rows(results_archive: Path) -> list[dict[str, str]]:
    with tarfile.open(results_archive, "r:gz") as tf:
        handle = tf.extractfile("competition_certification_results.csv")
        if handle is None:
            raise FileNotFoundError("competition_certification_results.csv")
        return list(csv.DictReader(line.decode("utf-8", "replace") for line in handle))


def parse_float(value: str) -> float | None:
    try:
        return float(value)
    except ValueError:
        return None


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--out", type=Path, default=Path("target/termcomp-proof-corpus"))
    args = parser.parse_args()

    cache = args.out / "zenodo-cache" / "pre2014"
    paths = ensure_files(cache)
    proof_members = tar_members(paths["proofs"], "proofs/")
    coq_members = tar_members(paths["coq"], "Coq_scripts/")

    db_path = args.out / "proofs.sqlite"
    conn = init_db(db_path)
    ensure_archive_columns(conn)
    existing = {
        row[0]
        for row in conn.execute(
            """
            select proof_url from proofs
            where proof_url like 'zenodo://termcomp/14410457/%'
              and download_error is null
            """
        )
    }

    tool_rows = load_tool_rows(paths["results"])
    imported_tool = 0
    missing_tool = 0
    with tarfile.open(paths["proofs"]) as proof_tar:
        for result_id, row in tool_rows.items():
            result = normalized_result(row.get("Result", ""))
            member = proof_members.get(result_id)
            proof_url = f"zenodo://termcomp/{ZENODO_RECORD}/tool-result/{result_id}"
            if result is None or member is None:
                if result is not None:
                    missing_tool += 1
                continue
            if proof_url in existing:
                imported_tool += 1
                continue
            data, stored_compressed = read_bz2_member(proof_tar, member)
            year = competition_year(row["Competition"])
            insert_row(
                conn,
                args.out,
                year=year,
                category=row["Category"],
                problem=row["Problem"],
                tool=row["Tool"],
                result=result,
                certification="uncertified",
                proof_url=proof_url,
                runtime=parse_float(row.get("Time", "")),
                cert_runtime=None,
                archive_url=f"zenodo://records/{ZENODO_RECORD}/{FILES['proofs']}",
                archive_member=member,
                data=data,
                stored_compressed=stored_compressed,
            )
            imported_tool += 1
            if imported_tool % 1000 == 0:
                conn.commit()
                print(f"imported tool proofs {imported_tool}", flush=True)

    cert_rows = load_cert_rows(paths["results"])
    imported_cert = 0
    missing_cert = 0
    with tarfile.open(paths["proofs"]) as proof_tar, tarfile.open(paths["coq"]) as coq_tar:
        for row in cert_rows:
            if row.get("Certification Result", "").strip().upper() != "ACCEPT":
                continue
            tool_row = tool_rows.get(row.get("Tool Result Id", "").strip())
            if tool_row is None:
                missing_cert += 1
                continue
            result = normalized_result(tool_row.get("Result", ""))
            if result is None:
                missing_cert += 1
                continue
            cert_id = row.get("Certication Result Id", "").strip()
            proof_url = f"zenodo://termcomp/{ZENODO_RECORD}/certification-result/{cert_id or row.get('Tool Result Id', '').strip()}"
            if proof_url in existing:
                imported_cert += 1
                continue
            member = coq_members.get(cert_id)
            source_tar = coq_tar
            archive_file = FILES["coq"]
            if member is None:
                member = proof_members.get(row.get("Tool Result Id", "").strip())
                source_tar = proof_tar
                archive_file = FILES["proofs"]
            if member is None:
                missing_cert += 1
                continue
            data, stored_compressed = read_bz2_member(source_tar, member)
            year = competition_year(row["Competition"])
            certifier = row.get("Certifier", "").strip()
            insert_row(
                conn,
                args.out,
                year=year,
                category=row["Category"],
                problem=row["Problem"],
                tool=f"{row['Tool']} / {certifier}",
                result=result,
                certification="certified",
                proof_url=proof_url,
                runtime=parse_float(tool_row.get("Time", "")),
                cert_runtime=parse_float(row.get("Certification Time", "")),
                archive_url=f"zenodo://records/{ZENODO_RECORD}/{archive_file}",
                archive_member=member,
                data=data,
                stored_compressed=stored_compressed,
            )
            imported_cert += 1
            if imported_cert % 1000 == 0:
                conn.commit()
                print(f"imported certified proofs {imported_cert}", flush=True)

    conn.commit()
    print(json.dumps({
        "imported_tool": imported_tool,
        "missing_tool": missing_tool,
        "imported_certified": imported_cert,
        "missing_certified": missing_cert,
    }, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
