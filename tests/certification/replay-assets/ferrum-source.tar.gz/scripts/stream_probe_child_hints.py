#!/usr/bin/env python3
"""Stream a large native child manifest into weak local-processor hints.

Requires ijson. A retained complete source is checked twice, but the new
child hints have zero certification credit until reconstructed proofs certify.
"""
import argparse
import hashlib
import json
from pathlib import Path
import subprocess
import ijson


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--probe', type=Path, required=True)
    p.add_argument('--source', type=Path, required=True)
    p.add_argument('--ceta', required=True)
    p.add_argument('--atom', required=True)
    p.add_argument('--output', type=Path, required=True)
    args = p.parse_args()
    for repeat in (1, 2):
        result = subprocess.run([args.ceta, str(args.source)], capture_output=True, text=True, timeout=120)
        args.output.with_suffix(f'.source-check-{repeat}.log').write_text(result.stdout + result.stderr)
        if result.returncode or 'CERTIFIED' not in result.stdout.splitlines():
            raise RuntimeError('Source certificate did not certify')
    keys, outcome = set(), None
    with args.probe.open('rb') as stream:
        for prefix, event, value in ijson.parse(stream):
            if prefix == 'children.item.cpf' and event == 'string':
                keys.add(hashlib.sha256(value.strip().encode()).hexdigest())
            elif prefix == 'typed_outcome' and event == 'string':
                outcome = value
    if outcome != 'Transformed' or not keys:
        raise RuntimeError('Expected a complete transformed native probe result')
    with args.output.open('x') as out:
        for key in sorted(keys):
            print(json.dumps(dict(schema='ferrum.utility-guidance.v2', problem_key=key,
                prefer=[dict(candidate=args.atom, status='transformed_weak', utility_score=1500,
                    attempts=1, certified_count=0, solved_count=0, transformed_count=1,
                    failed_count=0, timeout_count=0, best_elapsed_ms=0)], possible=[], avoid=[], timeout=[])), file=out)
    print(json.dumps({'child_states': len(keys), 'certified_promotions': 0}))


if __name__ == '__main__':
    main()
