#!/usr/bin/env python3
"""Summarize AProVE CPF witnesses for selected Ferrum gap examples.

The exact-obligation extractor stores local CPF fragments as JSONL rows.  This
script pulls the interesting DP processors for named benchmarks and reports the
kind of witness AProVE used without dumping full certificates.
"""

from __future__ import annotations

import argparse
import gzip
import json
import xml.etree.ElementTree as ET
from pathlib import Path
from typing import Any


DEFAULT_BENCHMARKS = {
    "TRS_Standard/AProVE_04/Liveness_WRS.ari",
    "TRS_Standard/HirokawaMiddeldorp_04/t004.ari",
    "TRS_Standard/Endrullis_06/pair2hard.ari",
}

INTERESTING_PROCESSORS = {
    "redPairProc",
    "redPairUrProc",
    "monoRedPairProc",
    "monoRedPairUrProc",
    "sizeChangeProc",
    "forwardInstantiationProc",
    "csrForwardInstantiationProc",
}


def local_name(tag: str) -> str:
    return tag.rsplit("}", 1)[-1]


def first_child(elem: ET.Element, name: str) -> ET.Element | None:
    for child in list(elem):
        if local_name(child.tag) == name:
            return child
    return None


def text(elem: ET.Element | None) -> str | None:
    if elem is None:
        return None
    value = "".join(elem.itertext()).strip()
    return value or None


def direct_rule_indices(elem: ET.Element | None) -> list[str]:
    if elem is None:
        return []
    rules = first_child(elem, "rules")
    if rules is None:
        return []
    return [text(child) or "" for child in list(rules) if local_name(child.tag) == "ruleIndex"]


def find_direct_order(elem: ET.Element) -> ET.Element | None:
    order_tags = {
        "interpretation",
        "knuthBendixOrder",
        "pathOrder",
        "recursivePathOrder",
        "reductionPair",
    }
    for child in list(elem):
        if local_name(child.tag) in order_tags:
            return child
    return None


def interpretation_summary(order: ET.Element) -> dict[str, Any]:
    kind: dict[str, Any] = {"kind": "interpretation"}
    type_elem = first_child(order, "type")
    if type_elem is not None:
        matrix = next((child for child in type_elem.iter() if local_name(child.tag) == "matrixInterpretation"), None)
        polynomial = next((child for child in type_elem.iter() if local_name(child.tag) == "polynomial"), None)
        if matrix is not None:
            domain = first_child(matrix, "domain")
            kind["domain"] = "integers" if domain is not None and first_child(domain, "integers") is not None else None
            kind["family"] = "matrix"
            kind["dimension"] = text(first_child(matrix, "dimension"))
            kind["strict_dimension"] = text(first_child(matrix, "strictDimension"))
        elif polynomial is not None:
            kind["family"] = "polynomial"
            kind["degree"] = text(first_child(polynomial, "degree"))
    kind["symbols"] = [
        {
            "name": text(first_child(interp, "name"))
            or text(first_child(first_child(interp, "sharp") if first_child(interp, "sharp") is not None else interp, "name")),
            "sharp": first_child(interp, "sharp") is not None,
            "arity": text(first_child(interp, "arity")),
        }
        for interp in list(order)
        if local_name(interp.tag) == "interpret"
    ]
    return kind


def kbo_summary(order: ET.Element) -> dict[str, Any]:
    entries = []
    weights = first_child(order, "precedenceWeight")
    if weights is not None:
        for entry in list(weights):
            if local_name(entry.tag) != "precedenceWeightEntry":
                continue
            entries.append(
                {
                    "name": text(first_child(entry, "name")),
                    "arity": text(first_child(entry, "arity")),
                    "precedence": text(first_child(entry, "precedence")),
                    "weight": text(first_child(entry, "weight")),
                }
            )
    filters = []
    filt = first_child(order, "argumentFilter")
    if filt is not None:
        for entry in list(filt):
            if local_name(entry.tag) != "argumentFilterEntry":
                continue
            collapsing = text(first_child(entry, "collapsing"))
            non_collapsing = first_child(entry, "nonCollapsing")
            filters.append(
                {
                    "name": text(first_child(entry, "name"))
                    or text(first_child(first_child(entry, "sharp") if first_child(entry, "sharp") is not None else entry, "name")),
                    "sharp": first_child(entry, "sharp") is not None,
                    "arity": text(first_child(entry, "arity")),
                    "collapsing": collapsing,
                    "positions": [
                        text(pos)
                        for pos in (list(non_collapsing) if non_collapsing is not None else [])
                        if local_name(pos.tag) == "position"
                    ],
                }
            )
    return {"kind": "kbo", "w0": text(first_child(order, "w0")), "entries": entries, "filters": filters}


def summarize_row(row: dict[str, Any]) -> dict[str, Any]:
    output = ET.fromstring(row["output_xml"])
    order = find_direct_order(output)
    if order is None:
        order_summary = None
    elif local_name(order.tag) == "interpretation":
        order_summary = interpretation_summary(order)
    elif local_name(order.tag) == "knuthBendixOrder":
        order_summary = kbo_summary(order)
    else:
        order_summary = {"kind": local_name(order.tag)}
    return {
        "benchmark": row["metadata"]["benchmark"],
        "processor": row["metadata"]["processor_tag"],
        "path": "/".join(row["metadata"]["path"]),
        "removed_dps": direct_rule_indices(first_child(output, "dps")),
        "usable_rules": direct_rule_indices(first_child(output, "usableRules")),
        "order": order_summary,
    }


def open_rows(path: Path):
    return gzip.open(path, "rt", encoding="utf-8") if path.suffix == ".gz" else path.open("r", encoding="utf-8")


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--input",
        type=Path,
        default=Path("target/termcomp-proof-corpus/training/subproofs.exact-obligations.original.jsonl.gz"),
    )
    parser.add_argument("--benchmark", action="append", dest="benchmarks")
    parser.add_argument("--processor", action="append", dest="processors")
    args = parser.parse_args()

    benchmarks = set(args.benchmarks or DEFAULT_BENCHMARKS)
    processors = set(args.processors or INTERESTING_PROCESSORS)
    summaries: list[dict[str, Any]] = []
    with open_rows(args.input) as handle:
        for line in handle:
            row = json.loads(line)
            metadata = row.get("metadata", {})
            if metadata.get("benchmark") not in benchmarks:
                continue
            if metadata.get("processor_tag") not in processors:
                continue
            summaries.append(summarize_row(row))
    print(json.dumps(summaries, indent=2, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
