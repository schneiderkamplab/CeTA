#!/usr/bin/env python3
"""Merge certified campaign evidence into a monotone utility-guidance oracle."""

from __future__ import annotations

import argparse
import hashlib
import json
import sqlite3
from collections import defaultdict
from pathlib import Path

from build_hrm_status_map_dataset import normalize_atom

STATUS_RANK = {
    "timeout": 0,
    "failed": 1,
    "transformed_weak": 2,
    "transformed_strong": 3,
    "solved": 4,
}
WITNESS_CANDIDATES: dict[str, str] = {}

WITNESS_SCHEMA = "ferrum.utility-guidance.witness.v1"
WITNESS_COMPACTION_THRESHOLD = 512

def candidate_value(item: dict) -> str:
    candidate = item.get("candidate")
    if candidate is not None:
        return str(candidate)
    reference = item.get("candidate_ref")
    if reference is not None:
        return WITNESS_CANDIDATES.get(str(reference), f"@witness:{reference}")
    return ""


def load_base(path: Path) -> tuple[dict[str, dict], dict[str, str]]:
    records: dict[str, dict] = {}
    witnesses: dict[str, str] = {}
    deferred_records: list[tuple[int, dict]] = []
    with path.open(encoding="utf-8") as stream:
        for line_number, line in enumerate(stream, start=1):
            if line.strip():
                row = json.loads(line)
                if row.get("schema") == WITNESS_SCHEMA:
                    witness_id = str(row.get("witness_id", ""))
                    candidate = row.get("candidate")
                    if not witness_id or not isinstance(candidate, str):
                        raise ValueError(f"malformed witness row on line {line_number}")
                    expected = hashlib.sha256(candidate.encode("utf-8")).hexdigest()
                    if not candidate.startswith("exact-") or witness_id != expected:
                        raise ValueError(f"invalid witness row on line {line_number}")
                    previous = witnesses.get(witness_id)
                    if previous is not None and previous != candidate:
                        raise ValueError(
                            f"conflicting witness {witness_id!r} on line {line_number}"
                        )
                    witnesses[witness_id] = candidate
                else:
                    deferred_records.append((line_number, row))
    for line_number, row in deferred_records:
        problem_key = row.get("problem_key")
        if not isinstance(problem_key, str):
            raise ValueError(f"missing problem_key on line {line_number}")
        for bucket in ("avoid", "possible", "prefer", "timeout"):
            for item in row.get(bucket, []):
                candidate = item.get("candidate")
                candidate_ref = item.pop("candidate_ref", None)
                if isinstance(candidate, str):
                    continue
                if not isinstance(candidate_ref, str):
                    raise ValueError(
                        f"candidate without candidate/candidate_ref on line {line_number}"
                    )
                try:
                    item["candidate"] = witnesses[candidate_ref]
                except KeyError as error:
                    raise ValueError(
                        f"unknown candidate_ref {candidate_ref!r} on line {line_number}"
                    ) from error
        records[problem_key] = row
    return records, witnesses


def compact_record_candidates(record: dict, witnesses: dict[str, str]) -> dict:
    """Return a JSON record with large candidates replaced by stable references."""
    compacted = dict(record)
    for bucket in ("avoid", "possible", "prefer", "timeout"):
        compacted_items = []
        for source_item in record.get(bucket, []):
            item = dict(source_item)
            candidate = item.get("candidate")
            # Witness rows have a deliberately strict executable schema.  A
            # few old monotone oracles still contain long Rust-Debug spellings
            # as ordinary (usually inapplicable) historical evidence.  Keep
            # those inline: interning them would manufacture a witness row
            # that the runtime correctly rejects before any lookup occurs.
            if (
                isinstance(candidate, str)
                and candidate.startswith("exact-")
                and len(candidate) >= WITNESS_COMPACTION_THRESHOLD
            ):
                witness_id = hashlib.sha256(candidate.encode("utf-8")).hexdigest()
                previous = witnesses.get(witness_id)
                if previous is not None and previous != candidate:
                    raise ValueError(f"SHA-256 witness collision for {witness_id}")
                witnesses[witness_id] = candidate
                item.pop("candidate", None)
                item["candidate_ref"] = witness_id
            compacted_items.append(item)
        compacted[bucket] = compacted_items
    return compacted


def evidence_item(
    candidate: str,
    outcome: str,
    elapsed_ms: int | None,
    source_priority: int = 0,
) -> dict:
    elapsed = max(0, elapsed_ms or 0)
    solved = int(outcome == "solved")
    transformed = int(outcome in {"transformed_strong", "transformed_weak"})
    failed = int(outcome == "failed")
    timed_out = int(outcome == "timeout")
    return {
        "attempts": 1,
        "best_elapsed_ms": elapsed,
        "candidate": candidate,
        "certified_count": solved,
        "failed_count": failed,
        "solved_count": solved,
        "status": outcome,
        "source_priority": source_priority,
        "timeout_count": timed_out,
        "transformed_count": transformed,
        "utility_score": (
            2000.0 - elapsed / 1000.0
            if solved
            else 1200.0 - elapsed / 1000.0
            if outcome == "transformed_strong"
            else 600.0 - elapsed / 1000.0
            if outcome == "transformed_weak"
            else -20.0 - elapsed / 1000.0
            if timed_out
            else -60.0 - elapsed / 1000.0
        ),
    }


def merge_item(items: list[dict], incoming: dict) -> None:
    incoming_candidate = candidate_value(incoming)
    current = next(
        (item for item in items if candidate_value(item) == incoming_candidate), None
    )
    if current is None:
        items.append(incoming)
        return
    for field in (
        "attempts",
        "certified_count",
        "failed_count",
        "solved_count",
        "timeout_count",
        "transformed_count",
    ):
        current[field] = int(current.get(field, 0)) + int(incoming.get(field, 0))
    elapsed_values = [
        int(value)
        for value in (
            current.get("best_elapsed_ms"),
            incoming.get("best_elapsed_ms"),
        )
        if value is not None
    ]
    current["best_elapsed_ms"] = min(elapsed_values) if elapsed_values else None
    if STATUS_RANK[incoming["status"]] > STATUS_RANK.get(current["status"], -1):
        current["status"] = incoming["status"]
    current["utility_score"] = max(
        float(current.get("utility_score", -1e30)), incoming["utility_score"]
    )
    current["source_priority"] = max(
        int(current.get("source_priority", 0)),
        int(incoming.get("source_priority", 0)),
    )


def replay_priority(item: dict) -> tuple:
    """Rank complete certified recipes, then self-contained processor steps.

    An explicitly retained compound recipe is solved evidence for the exact
    state: it reconstructed a complete CPF which passed deterministic checker
    replay.  It must outrank an open transformation at the same state because
    an unresolved child does not currently backtrack to another root action.
    Atomic state-first evidence remains next, ahead of open-ended historical
    searches and generic synthesizers.
    """
    candidate = candidate_value(item)
    # Every exact-* atom replays a fully specified, independently validated
    # model. It must precede an open-ended synthesizer for the same family;
    # otherwise a long search can consume the root deadline before the
    # retained model is tried (max-polynomial CSR proofs exposed this bug).
    exact_witness = candidate.startswith("exact-")
    # A complete serialized processor node fixes not only the model but also
    # the processor variant, usable-rule obligation, deleted pairs, and child
    # boundary.  Prefer it to model-only exact atoms when both are available:
    # the latter may intentionally derive a different filtering or residual.
    complete_processor_fragment = candidate.startswith(
        (
            "exact-red-pair(",
            "exact-general-red-pair(",
            "exact-size-change(",
            "exact-dp-loop(",
            "exact-dp-nontermination-proof(",
            "exact-dp-proof(",
            "exact-trs-proof(",
            "exact-trs-nontermination-proof(",
        )
    )
    # These processors normalize or expose the typed state without searching
    # for a model.  They must precede reduction-pair witnesses broadcast as
    # root-local hints: e.g. usable-rules changes the certified DP obligation,
    # while applying an otherwise valid matrix first creates a different
    # residual and loses the archived continuation.
    state_normalizer = candidate in {
        "dp",
        "graph",
        "usable-rules",
        "innermost-lhss",
        "switch-innermost",
        "switch-full",
        "switch-full-nontermination",
        "uncurry",
        "string-reversal",
        "remove-non-applicable-rules",
        "csr-improved-dp",
        "csr-safe-dp",
        "csr-innermost-dp",
        "csr-rta08-dp",
        "csr-conservative-dp",
    } or candidate.startswith(
        (
            "exact-dp(",
            "exact-dp-transform(",
            "exact-dp-no-rule-removal(",
            "exact-graph(",
            "exact-usable-rules(",
            "exact-innermost-lhss(",
            "exact-constant-to-unary(",
            "exact-dp-loop(",
            "exact-dp-nontermination-proof(",
            "exact-dp-proof(",
            "exact-trs-proof(",
            "exact-trs-nontermination-proof(",
        )
    )
    obligation_transformer = candidate == "relative-flat-context-closure" or candidate.startswith(
        "exact-relative-semantic-labeling("
    )
    retained_nontermination_search = (
        candidate.startswith("nontermination(")
        and candidate not in {"nontermination(loop)", "nontermination(direct-loop)"}
    )
    compound = ";" in candidate or "parallel(" in candidate or "choice(" in candidate
    complete_recipe = (
        compound
        or candidate.startswith(
            (
                "exact-trs-proof(",
                "exact-trs-nontermination-proof(",
            )
        )
    ) and item.get("status") == "solved"
    return (
        -int(item.get("source_priority", 0)),
        not complete_recipe,
        not retained_nontermination_search,
        not state_normalizer,
        not obligation_transformer,
        not complete_processor_fragment,
        not exact_witness,
        compound,
        -int(item.get("certified_count", 0)),
        item.get("best_elapsed_ms")
        if item.get("best_elapsed_ms") is not None
        else 2**63 - 1,
        candidate,
    )


def normalize_record_evidence(record: dict) -> None:
    """Deduplicate candidates across buckets with certified success absorbing."""
    by_candidate: dict[str, dict] = {}
    for bucket in ("prefer", "possible", "avoid", "timeout"):
        for item in record.get(bucket, []):
            candidate = candidate_value(item)
            current = by_candidate.get(candidate)
            if current is None:
                by_candidate[candidate] = dict(item)
            else:
                merge_item([current], item)
    buckets = {name: [] for name in ("prefer", "possible", "avoid", "timeout")}
    for item in by_candidate.values():
        status = str(item.get("status"))
        bucket = (
            "prefer"
            if status in {"solved", "transformed_strong"}
            else "possible"
            if status == "transformed_weak"
            else "timeout"
            if status == "timeout"
            else "avoid"
        )
        buckets[bucket].append(item)
    record.update(buckets)


def certified_state_first_prefix(candidate: str) -> str | None:
    """Expose a certified whole DP recipe as its independently guided step.

    Re-running ``dp(graph;...)`` resynthesizes every model inside the archived
    composition and can therefore diverge from the checked proof.  The DP
    transformation itself is deterministic; after it, utility lookup on the
    materialized DP state selects the separately recorded child evidence.
    """
    normalized = candidate.strip()
    if normalized.startswith("dp("):
        return "dp"
    return None


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--base-oracle", type=Path, required=True)
    parser.add_argument(
        "--invalidate-base-key-file",
        type=Path,
        action="append",
        default=[],
        help=(
            "remove exact problem keys whose retained positive evidence is "
            "rejected by the current checker before merging replacement evidence"
        ),
    )
    parser.add_argument(
        "--replace-campaign-keys",
        action="store_true",
        help=(
            "replace base records for every exact/canonical state present in "
            "the supplied campaign databases; use this when older evidence "
            "was incorrectly pooled across distinct states"
        ),
    )
    parser.add_argument("--campaign-sqlite", type=Path, action="append", required=True)
    parser.add_argument(
        "--exclude-candidate-prefix",
        action="append",
        default=[],
        help=(
            "do not import campaign candidates beginning with this prefix; "
            "repeatable and useful when learning residual states without "
            "reintroducing synthesized exact witnesses"
        ),
    )
    parser.add_argument(
        "--exclude-base-candidate-prefix",
        action="append",
        default=[],
        help=(
            "remove inherited base-oracle candidates beginning with this prefix; "
            "repeatable and intended for globally invalidated processor evidence"
        ),
    )
    parser.add_argument(
        "--certified-manifest",
        action="append",
        default=[],
        type=Path,
        help=(
            "CeTA-CSR union manifest used to gate solved and strongly transformed "
            "evidence; assembly-required transitions remain non-proof weak hints"
        ),
    )
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--report", type=Path, required=True)
    args = parser.parse_args()

    base_records, witnesses = load_base(args.base_oracle)
    WITNESS_CANDIDATES.clear()
    WITNESS_CANDIDATES.update(witnesses)
    excluded_base_candidates = 0
    for record in base_records.values():
        for bucket in ("avoid", "possible", "prefer", "timeout"):
            retained = []
            for item in record.get(bucket, []):
                candidate = candidate_value(item)
                if any(
                    candidate.startswith(prefix)
                    for prefix in args.exclude_base_candidate_prefix
                ):
                    excluded_base_candidates += 1
                else:
                    retained.append(item)
            record[bucket] = retained
    records = dict(base_records)
    # Campaign evidence is newer than every retained base record.  Preserve
    # that ordering explicitly instead of restarting priorities at one: a
    # consolidated base may already contain several campaign generations,
    # and equal priorities otherwise leave stale exact witnesses tied with
    # their certified replacements.
    base_max_source_priority = max(
        (
            int(item.get("source_priority", 0))
            for record in base_records.values()
            for bucket in ("avoid", "possible", "prefer", "timeout")
            for item in record.get(bucket, [])
        ),
        default=0,
    )
    invalidation_keys: set[str] = set()
    for path in args.invalidate_base_key_file:
        with path.open(encoding="utf-8") as stream:
            invalidation_keys.update(
                line.strip()
                for line in stream
                if line.strip() and not line.lstrip().startswith("#")
            )
    invalidated_base_keys = sorted(invalidation_keys.intersection(records))
    invalidated_base_sources = {
        key: records[key] for key in invalidated_base_keys
    }
    missing_invalidation_keys = sorted(invalidation_keys.difference(records))
    for key in invalidated_base_keys:
        del records[key]
    certified_canonical: set[tuple[str, str, str | None]] = set()
    certified_assembled: set[tuple[str, str]] = set()
    for certified_manifest in args.certified_manifest:
        with certified_manifest.open(encoding="utf-8") as stream:
            for line in stream:
                row = json.loads(line)
                # The current freezer deduplicates identical proof files and
                # records every database obligation in an ``origins`` array.
                # Continue to accept the older flat manifest as well so old
                # frozen unions remain usable as monotone export gates.
                if row.get("deterministic_certified") is True:
                    for origin in row.get("origins", []):
                        raw_hash = str(origin.get("raw_hash"))
                        task_key = str(origin.get("task_key"))
                        raw_processor_atom = str(origin.get("processor_atom"))
                        processor_atom = normalize_atom(raw_processor_atom) or raw_processor_atom
                        implementation_hash = origin.get("implementation_hash")
                        if processor_atom == "assembled":
                            certified_assembled.add((raw_hash, task_key))
                        else:
                            certified_canonical.add(
                                (raw_hash, processor_atom, implementation_hash)
                            )
                    continue
                if row.get("recheck_status") != "certified":
                    continue
                if row.get("scope") == "canonical":
                    raw_candidate = str(row.get("candidate"))
                    candidate = normalize_atom(raw_candidate) or raw_candidate
                    certified_canonical.add(
                        (
                            str(row.get("problem_key")),
                            candidate,
                            row.get("recorded_implementation_hash"),
                        )
                    )
                elif row.get("scope") == "assembled":
                    parts = str(row.get("obligation_key", "")).split("\0")
                    if len(parts) == 3:
                        certified_assembled.add((parts[1], parts[2]))
    evidence: dict[str, list[tuple[str, str, int | None, int]]] = defaultdict(list)
    rejected_positive = 0
    rejected_positive_examples: list[dict] = []
    uncertified_weak_hints_retained = 0
    excluded_campaign_candidates = 0
    assembly_required_rows_superseded = 0
    aliases: dict[str, set[str]] = {}
    campaign_keys: set[str] = set()
    certified_assembled_actions: set[tuple[str, str]] = set()
    checker_rejected_assembled_actions: set[tuple[str, str]] = set()
    for database in args.campaign_sqlite:
        with sqlite3.connect(database) as connection:
            tables = {
                row[0]
                for row in connection.execute(
                    "SELECT name FROM sqlite_master WHERE type='table'"
                )
            }
            if {"assembled_proofs", "trials"} <= tables:
                certified_assembled_actions.update(
                    connection.execute(
                        """
                        SELECT a.raw_hash, t.candidate
                        FROM assembled_proofs a
                        JOIN trials t ON t.task_key=a.transition_task_key
                        WHERE a.checker_result='CERTIFIED'
                          AND a.deterministic_recheck=1
                        """
                    )
                )
                checker_rejected_assembled_actions.update(
                    connection.execute(
                        """
                        SELECT a.raw_hash, t.candidate
                        FROM assembled_proofs a
                        JOIN trials t ON t.task_key=a.transition_task_key
                        WHERE a.checker_result='REJECTED'
                        """
                    )
                )
    # A later deterministic certified reconstruction supersedes an earlier
    # rejected attempt for the same exact state/action.  Otherwise the
    # rejection proves that the supposedly sound open transformation cannot
    # be retained even as weak scheduling guidance.
    checker_rejected_assembled_actions.difference_update(
        certified_assembled_actions
    )
    for source_priority, database in enumerate(
        args.campaign_sqlite, start=base_max_source_priority + 1
    ):
        with sqlite3.connect(database) as connection:
            tables = {
                row[0]
                for row in connection.execute(
                    "SELECT name FROM sqlite_master WHERE type='table'"
                )
            }
            if "state_aliases" in tables:
                database_alias_pairs = list(connection.execute(
                    "SELECT alias_raw_hash, state_raw_hash FROM state_aliases"
                ))
            elif "problem_aliases" in tables:
                database_alias_pairs = list(connection.execute(
                    "SELECT raw_problem_key, problem_key FROM problem_aliases"
                ))
            else:
                database_alias_pairs = []
            database_aliases: dict[str, set[str]] = {}
            for alias, target in database_alias_pairs:
                database_aliases.setdefault(alias, set()).add(target)
                aliases.setdefault(alias, set()).add(target)
            campaign_keys.update(database_aliases)
            campaign_keys.update(
                target for targets in database_aliases.values() for target in targets
            )
            # Complete-proof extraction records the exact source serialization,
            # while the credited builder may subsequently canonicalize that
            # state. Treat the database's content-checked alias as part of the
            # certification identity; otherwise sound whitespace/name
            # canonicalization silently downgrades certified transformations
            # to weak hints.
            translated_certification = {
                (target, candidate, implementation_hash)
                for problem_key, candidate, implementation_hash in certified_canonical
                if problem_key in database_aliases
                for target in database_aliases[problem_key]
            }
            certified_canonical.update(translated_certification)
            objects = {
                row[0]
                for row in connection.execute(
                    "SELECT name FROM sqlite_master WHERE type IN ('table', 'view')"
                )
            }
            if "oracle_evidence" in objects:
                evidence_columns = {
                    row[1]
                    for row in connection.execute("PRAGMA table_info(oracle_evidence)")
                }
                evidence_implementation = (
                    "implementation_hash"
                    if "implementation_hash" in evidence_columns
                    else "NULL"
                )
                rows = list(
                    connection.execute(
                        f"""
                        SELECT raw_hash, canonical_hash, processor_atom, outcome,
                               certification_status, elapsed_ms,
                               {evidence_implementation}, NULL
                        FROM oracle_evidence
                        WHERE outcome IN ('solved', 'transformed', 'failed', 'timeout')
                        """
                    )
                )
            elif {"problems", "candidates"} <= tables:
                # The credited status-map builder is also a supported campaign
                # source.  Its rows have already been grouped by exact CPF
                # content and certification status, but use training-oriented
                # names instead of the canonical campaign ledger schema.
                rows = list(
                    connection.execute(
                        """
                        SELECT p.problem_key, p.problem_key, c.candidate,
                               CASE c.best_status
                                 WHEN 'transformed_strong' THEN 'transformed'
                                 WHEN 'transformed_weak' THEN 'transformed'
                                 ELSE c.best_status
                               END,
                               CASE
                                 WHEN c.best_status='solved'
                                      AND c.certified_count > 0
                                   THEN 'certified-full'
                                 WHEN c.best_status='transformed_strong'
                                      AND c.certified_count > 0
                                   THEN 'certified-path'
                                 WHEN c.best_status='transformed_weak'
                                   THEN 'assembly-required'
                                 ELSE NULL
                               END,
                               c.best_elapsed_ms, NULL, NULL
                        FROM problems p
                        JOIN candidates c ON c.problem_key=p.problem_key
                        WHERE c.best_status IN
                          ('solved', 'transformed_strong', 'transformed_weak',
                           'failed', 'timeout')
                        """
                    )
                )
            else:
                raise RuntimeError(
                    f"{database} has neither oracle_evidence nor credited "
                    "problems/candidates tables"
                )
            campaign_keys.update(str(row[0]) for row in rows)
            campaign_keys.update(str(row[1]) for row in rows)
            # A certified fragment is an applicable solution of its exact
            # parent state once every child has been closed, the complete CPF
            # has been reconstructed, and two checker runs agree.  Export the
            # parent processor as solved evidence; otherwise the oracle would
            # know the children but have no action capable of reaching them.
            if {"assembled_proofs", "states", "trials"} <= tables:
                assembled_columns = {
                    row[1]
                    for row in connection.execute(
                        "PRAGMA table_info(assembled_proofs)"
                    )
                }
                assembled_implementation = (
                    "a.implementation_hash"
                    if "implementation_hash" in assembled_columns
                    else "NULL"
                )
                rows.extend(
                    connection.execute(
                        f"""
                        SELECT s.raw_hash, s.canonical_hash, t.candidate, 'solved',
                               'certified-full', a.elapsed_ms,
                               {assembled_implementation}, a.transition_task_key
                        FROM assembled_proofs a
                        JOIN states s ON s.raw_hash=a.raw_hash
                        JOIN trials t ON t.task_key=a.transition_task_key
                        WHERE a.checker_result='CERTIFIED'
                          AND a.deterministic_recheck=1
                        """
                    )
                )
            for (
                raw_hash,
                canonical_hash,
                candidate,
                outcome,
                certification,
                elapsed,
                implementation_hash,
                assembled_task_key,
            ) in rows:
                candidate = str(candidate)
                if any(
                    candidate.startswith(prefix)
                    for prefix in args.exclude_candidate_prefix
                ):
                    excluded_campaign_candidates += 1
                    continue
                if outcome == "solved":
                    if certification != "certified-full":
                        rejected_positive += 1
                        if len(rejected_positive_examples) < 100:
                            rejected_positive_examples.append(
                                {
                                    "candidate": candidate,
                                    "certification_status": certification,
                                    "database": str(database),
                                    "outcome": outcome,
                                    "raw_hash": raw_hash,
                                    "reason": "positive_without_certification",
                                }
                            )
                        continue
                elif outcome == "transformed":
                    if (raw_hash, candidate) in checker_rejected_assembled_actions:
                        rejected_positive += 1
                        if len(rejected_positive_examples) < 100:
                            rejected_positive_examples.append(
                                {
                                    "candidate": candidate,
                                    "certification_status": certification,
                                    "database": str(database),
                                    "outcome": outcome,
                                    "raw_hash": raw_hash,
                                    "reason": "checker_rejected_assembly",
                                }
                            )
                        continue
                    if certification == "certified-path":
                        # A processor recovered from a completely certified
                        # source proof is strong only when the deterministic
                        # manifest names this exact state/action.  The
                        # credited adapter retains the proof-path bit, while
                        # the manifest prevents an isolated fragment or stale
                        # state alias from being promoted accidentally.
                        path_certified = (
                            bool(args.certified_manifest)
                            and (raw_hash, candidate, implementation_hash)
                            in certified_canonical
                        )
                        if path_certified:
                            outcome = "transformed_strong"
                        else:
                            outcome = "transformed_weak"
                    elif certification in {
                        "certified-fragment",
                        "assembly-required",
                        "residual-manifest",
                    }:
                        # Executable node-level guidance, but not a claim that
                        # the parent is closed.  It remains in the lower-ranked
                        # possible bucket until complete assembly certifies it.
                        if (raw_hash, candidate) in certified_assembled_actions:
                            assembly_required_rows_superseded += 1
                            continue
                        outcome = "transformed_weak"
                    else:
                        rejected_positive += 1
                        if len(rejected_positive_examples) < 100:
                            rejected_positive_examples.append(
                                {
                                    "candidate": candidate,
                                    "certification_status": certification,
                                    "database": str(database),
                                    "outcome": outcome,
                                    "raw_hash": raw_hash,
                                    "reason": "transformation_without_certification",
                                }
                            )
                        continue
                if args.certified_manifest and outcome in {
                    "solved",
                    "transformed_strong",
                }:
                    certified = (
                        (raw_hash, str(assembled_task_key)) in certified_assembled
                        if assembled_task_key is not None
                        else (raw_hash, candidate, implementation_hash)
                        in certified_canonical
                    )
                    if not certified:
                        rejected_positive += 1
                        if len(rejected_positive_examples) < 100:
                            rejected_positive_examples.append(
                                {
                                    "candidate": candidate,
                                    "certification_status": certification,
                                    "database": str(database),
                                    "implementation_hash": implementation_hash,
                                    "outcome": outcome,
                                    "raw_hash": raw_hash,
                                    "reason": "not_in_certified_manifest",
                                }
                            )
                        continue
                elif (
                    args.certified_manifest
                    and outcome == "transformed_weak"
                ):
                    # This is scheduling evidence only: it cannot close a node,
                    # contributes no certified count, and every eventual root
                    # proof is still checked by CeTA-CSR.
                    uncertified_weak_hints_retained += 1
                derived_prefix = (
                    certified_state_first_prefix(candidate)
                    if outcome == "solved"
                    else None
                )
                for key in {raw_hash, canonical_hash}:
                    evidence[key].append(
                        (candidate, outcome, elapsed, source_priority)
                    )
                    if derived_prefix is not None:
                        evidence[key].append(
                            (
                                derived_prefix,
                                "transformed_strong",
                                elapsed,
                                source_priority,
                            )
                        )

    replaced_campaign_keys: list[str] = []
    if args.replace_campaign_keys:
        replaced_campaign_keys = sorted(campaign_keys.intersection(records))
        for key in replaced_campaign_keys:
            del records[key]

    promoted = 0
    certified_promoted = 0
    for key, rows in evidence.items():
        record = records.setdefault(
            key,
            {
                "avoid": [],
                "possible": [],
                "prefer": [],
                "problem_key": key,
                "schema": "ferrum.utility-guidance.v2",
                "timeout": [],
            },
        )
        # A raw alias becomes an authoritative raw-state record as soon as the
        # campaign has direct evidence for that exact serialization.
        record.pop("canonical_problem_key", None)
        for bucket in ("avoid", "possible", "prefer", "timeout"):
            record.setdefault(bucket, [])
        for candidate, outcome, elapsed, source_priority in rows:
            bucket = (
                "prefer"
                if outcome in {"solved", "transformed_strong"}
                else "possible"
                if outcome == "transformed_weak"
                else "timeout"
                if outcome == "timeout"
                else "avoid"
            )
            merge_item(
                record[bucket],
                evidence_item(candidate, outcome, elapsed, source_priority),
            )
            if outcome in {"solved", "transformed_strong", "transformed_weak"}:
                promoted += 1
                if outcome != "transformed_weak":
                    certified_promoted += 1
        normalize_record_evidence(record)
        record["prefer"].sort(key=replay_priority)
        record["avoid"].sort(key=lambda item: (-item["utility_score"], candidate_value(item)))
        record["possible"].sort(key=replay_priority)
        record["timeout"].sort(key=lambda item: (-item["utility_score"], candidate_value(item)))

    def merge_record_evidence(destination: dict, source: dict) -> None:
        """Monotonically copy every ranked candidate between equivalent states."""
        for bucket in ("avoid", "possible", "prefer", "timeout"):
            destination.setdefault(bucket, [])
            for item in source.get(bucket, []):
                merge_item(destination[bucket], item)
        destination["prefer"].sort(key=replay_priority)
        destination["avoid"].sort(
            key=lambda item: (-item["utility_score"], candidate_value(item))
        )
        destination["possible"].sort(key=replay_priority)
        destination["timeout"].sort(
            key=lambda item: (-item["utility_score"], candidate_value(item))
        )

    aliases_exported = 0
    aliases_shadowed = 0
    aliases_merged = 0
    aliases_without_target = 0
    for alias, targets in sorted(aliases.items()):
        targets = {target for target in targets if target != alias}
        if not targets:
            aliases_shadowed += 1
            continue
        available = [records[target] for target in sorted(targets) if target in records]
        if not available:
            aliases_without_target += 1
            continue
        had_direct_record = alias in records
        if not had_direct_record:
            records[alias] = {
                "avoid": [],
                "possible": [],
                "prefer": [],
                "problem_key": alias,
                "schema": "ferrum.utility-guidance.v2",
                "timeout": [],
            }
            aliases_exported += 1
        else:
            # A historical direct record at the runtime raw key must not
            # suppress newly certified evidence attached to any canonical
            # source state. Merge all targets monotonically into the direct
            # record;
            # otherwise a stale bare `dp` recommendation wins forever and a
            # newly recovered complete recipe is invisible at runtime.
            aliases_merged += 1
        direct = records[alias]
        # The alias is now authoritative and may merge several independently
        # checked source states, so it cannot point through one arbitrary
        # canonical target.
        # Runtime records are deliberately self-contained.  A pointer-only
        # alias makes lookup order-dependent, permits dangling chains after a
        # monotone replacement, and prevents independent replay of the live
        # state.  Copy all target evidence below and remove any inherited
        # pointer regardless of target cardinality.
        direct.pop("canonical_problem_key", None)
        for canonical in available:
            merge_record_evidence(direct, canonical)

    # Keep an explicit empty record when current-checker invalidation has no
    # certified replacement.  Absence would allow lookup to fall through to a
    # historical canonical alias and resurrect the rejected positive.  A
    # tombstone is not negative proof evidence; it only shadows obsolete
    # guidance at this exact runtime serialization.
    invalidation_tombstones = 0
    invalidation_replacements = 0
    for key in sorted(invalidation_keys):
        if key in records:
            # A current-checker-certified replacement is still an
            # invalidation boundary.  Marking the replacement record makes
            # runtime lookup prefer it exclusively over another matching
            # raw/structural/canonical hash that still carries the rejected
            # historical witness.
            records[key]["current_checker_invalidation"] = True
            invalidation_replacements += 1
            continue
        source = invalidated_base_sources.get(key, {})
        rejected_candidates: list[dict] = []
        for bucket in ("prefer", "possible"):
            for item in source.get(bucket, []):
                rejected = dict(item)
                rejected["status"] = "failed"
                rejected["certified_count"] = 0
                rejected["solved_count"] = 0
                rejected["transformed_count"] = 0
                rejected["failed_count"] = max(
                    1, int(rejected.get("failed_count", 0))
                )
                rejected["utility_score"] = min(
                    -60.0, float(rejected.get("utility_score", -60.0))
                )
                merge_item(rejected_candidates, rejected)
        records[key] = {
            "avoid": rejected_candidates,
            "current_checker_invalidation": True,
            "possible": [],
            "prefer": [],
            "problem_key": key,
            "schema": "ferrum.utility-guidance.v2",
            "timeout": [],
        }
        invalidation_tombstones += 1

    # Replacing a campaign state can remove the canonical target of an alias
    # inherited from the base oracle.  Such an alias is neither loadable nor
    # sound: retaining its copied evidence would resurrect exactly the stale
    # cross-state guidance that replacement is meant to discard.  Campaign
    # aliases have already been rebuilt above, so remove only the remaining
    # dangling base aliases.
    dangling_base_aliases: list[str] = []
    while True:
        layer = sorted(
            key
            for key, record in records.items()
            if isinstance(record.get("canonical_problem_key"), str)
            and record["canonical_problem_key"] not in records
        )
        if not layer:
            break
        dangling_base_aliases.extend(layer)
        for key in layer:
            del records[key]

    # Evidence rows and aliases are normalized at their mutation sites above.
    # Do not re-rank inherited records globally: candidate order is executable
    # replay evidence, and an unrelated campaign must leave untouched states
    # byte-for-byte equivalent to the base oracle.

    args.output.parent.mkdir(parents=True, exist_ok=True)
    with args.output.open("w", encoding="utf-8") as stream:
        compacted_records = {
            key: compact_record_candidates(record, witnesses)
            for key, record in records.items()
        }
        for witness_id in sorted(witnesses):
            stream.write(
                json.dumps(
                    {
                        "candidate": witnesses[witness_id],
                        "schema": WITNESS_SCHEMA,
                        "witness_id": witness_id,
                    },
                    sort_keys=True,
                    separators=(",", ":"),
                )
                + "\n"
            )
        for key in sorted(records):
            stream.write(
                json.dumps(
                    compacted_records[key], sort_keys=True, separators=(",", ":")
                )
                + "\n"
            )
    report = {
        "schema": "ferrum.state-first-oracle-export.v1",
        "base_records": len(base_records),
        "base_metadata_records": len(witnesses),
        "invalidated_base_records": len(invalidated_base_keys),
        "replaced_campaign_base_records": len(replaced_campaign_keys),
        "invalidated_base_problem_keys": invalidated_base_keys,
        "missing_invalidated_base_problem_keys": missing_invalidation_keys,
        "current_checker_invalidation_tombstones": invalidation_tombstones,
        "current_checker_invalidation_replacements": invalidation_replacements,
        "dangling_base_aliases_pruned": len(dangling_base_aliases),
        "output_records": len(records),
        "positive_evidence_entries_exported": promoted,
        "certified_positive_evidence_rows_promoted": certified_promoted,
        "uncertified_weak_transformation_hints_retained": (
            uncertified_weak_hints_retained
        ),
        "excluded_campaign_candidates": excluded_campaign_candidates,
        "excluded_candidate_prefixes": args.exclude_candidate_prefix,
        "excluded_base_candidates": excluded_base_candidates,
        "excluded_base_candidate_prefixes": args.exclude_base_candidate_prefix,
        "assembly_required_rows_superseded_by_certified_assembly": (
            assembly_required_rows_superseded
        ),
        "uncertified_positive_evidence_rows_rejected": rejected_positive,
        "uncertified_positive_evidence_examples": rejected_positive_examples,
        "raw_aliases_exported": aliases_exported,
        "raw_aliases_merged_into_direct_records": aliases_merged,
        "raw_aliases_shadowed_by_direct_records": aliases_shadowed,
        "raw_aliases_without_oracle_target": aliases_without_target,
        "campaign_sqlite": [str(path) for path in args.campaign_sqlite],
    }
    args.report.write_text(json.dumps(report, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    print(json.dumps(report, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
