#!/usr/bin/env python3
"""Expose legacy CSR ordinary-proof wrappers as recursive typed CSR nodes.

This is certificate translation, not a certification assertion. Both source
and translated output must pass the chosen checker before evidence is used.
Unsupported subtrees remain unchanged; no rewrite relation is weakened.
"""
import argparse
from copy import deepcopy
import hashlib
import json
from pathlib import Path
import subprocess
import xml.etree.ElementTree as ET


def typed_dp(proof):
    if proof.tag != 'dpProof' or len(proof) != 1:
        return None
    result = deepcopy(proof)
    result.tag = 'csrDpProof'
    step = result[0]
    if step.tag in {'pIsEmpty', 'sizeChangeProc', 'subtermProc', 'instantiationProc', 'redPairUrProc'}:
        if step.tag == 'redPairUrProc':
            step.tag = 'csrRedPairUrProc'
        for index, child in enumerate(list(step)):
            if child.tag == 'dpProof':
                converted = typed_dp(child)
                if converted is None:
                    return None
                step.remove(child)
                step.insert(index, converted)
        return result
    if step.tag == 'depGraphProc':
        for component in step.findall('component'):
            for index, child in enumerate(list(component)):
                if child.tag == 'dpProof':
                    converted = typed_dp(child)
                    if converted is None:
                        return None
                    component.remove(child)
                    component.insert(index, converted)
        return result
    return None


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--proof', type=Path, required=True)
    p.add_argument('--output', type=Path, required=True)
    p.add_argument('--ceta', required=True)
    args = p.parse_args()
    args.output.mkdir(parents=True, exist_ok=False)
    tree = ET.parse(args.proof)
    count = 0
    for wrapper in tree.getroot().iter('csrDpProof'):
        if len(wrapper) == 1 and wrapper[0].tag == 'ordinaryDpProof':
            ordinary = wrapper[0].find('dpProof')
            converted = typed_dp(ordinary) if ordinary is not None else None
            if converted is not None:
                wrapper.remove(wrapper[0])
                wrapper.append(converted[0])
                count += 1
    target = args.output/'proof.cpf.xml'
    tree.write(target, encoding='utf-8', xml_declaration=True)
    checks = []
    for label, path in [('source', args.proof), ('translated', target)]:
        for repeat in (1, 2):
            result = subprocess.run([args.ceta, str(path)], capture_output=True, text=True, timeout=120)
            (args.output/f'{label}-{repeat}.log').write_text(result.stdout + result.stderr)
            if result.returncode or 'CERTIFIED' not in result.stdout.splitlines():
                raise RuntimeError(f'{label} certification failed; translation is not usable evidence')
            checks.append(dict(kind=label, repeat=repeat, sha256=hashlib.sha256(path.read_bytes()).hexdigest()))
    (args.output/'audit.json').write_text(json.dumps(dict(converted=count, checks=checks), indent=2))
    print(json.dumps(dict(converted=count, certified_twice=True)))


if __name__ == '__main__':
    main()
