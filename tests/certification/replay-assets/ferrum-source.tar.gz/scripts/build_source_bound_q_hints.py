"""Bind retained Q choices to their actual runtime states; export weak modular hints."""
import argparse
import hashlib
import json
import re
from pathlib import Path
import subprocess
import tempfile

from extract_local_cpf_oracle_events import hydrate_content_addressed_probe_input


def portable_atom(atom, source, all_modular=False):
    if not isinstance(atom, str) or not re.fullmatch(r'[a-z][a-z0-9-]*(?:\([^();]*\))?', atom):
        return None
    if atom.split('(', 1)[0] in {'timeout', 'parallel', 'choice', 'sequence', 'dp',
                               'repeat', 'try', 'if', 'race', 'exact-dp-proof',
                               'exact-trs-proof', 'exact-dp-nontermination-proof',
                               'exact-trs-nontermination-proof'}:
        return None
    if atom.startswith('exact-innermost-lhss(hex='):
        payload = json.loads(bytes.fromhex(atom.split('hex=', 1)[1][:-1]))
        if isinstance(payload, list):
            payload = payload[0]
        if not isinstance(payload, str):
            raise ValueError('invalid retained Q payload')
        return 'exact-innermost-lhss(hex=' + json.dumps([payload, source], separators=(',', ':')).encode().hex() + ')'
    if all_modular and atom.startswith(('exact-poly-removal(', 'exact-kbo(', 'exact-poly(', 'exact-matrix(')) and '<trsInput' in source:
        return 'exact-trs-order(hex=' + json.dumps([source, atom], separators=(',', ':')).encode().hex() + ')'
    if all_modular and atom.startswith('exact-semantic-labeling(hex='):
        value = json.loads(bytes.fromhex(atom.split('hex=')[1][:-1]))
        if isinstance(value, dict):
            return 'exact-semantic-labeling(hex=' + json.dumps([value, source], separators=(',', ':')).encode().hex() + ')'
    if all_modular and atom.startswith('exact-dp-transform(hex='):
        value = json.loads(bytes.fromhex(atom.split('hex=')[1][:-1]))
        if isinstance(value, list) and len(value) == 3:
            return 'exact-dp-transform(hex=' + json.dumps([*value, source], separators=(',', ':')).encode().hex() + ')'
    # These remain weak suggestions; each processor must independently validate
    # applicability and relocate its own witness against the live state.
    return atom if all_modular else None


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--events', type=Path, required=True)
    p.add_argument('--checks', type=Path, required=True)
    p.add_argument('--ferrum', type=Path, required=True)
    p.add_argument('--output', type=Path, required=True)
    p.add_argument('--all-modular', action='store_true',
                   help='also retain other atomic actions as weak canonical hints')
    args = p.parse_args()
    certified = set()
    for row in map(json.loads, args.checks.read_text().splitlines()):
        if row.get('certified') and len(row.get('checks', [])) == 2 and all(c.get('accepted') for c in row['checks']):
            if hashlib.sha256(Path(row['proof']).read_bytes()).hexdigest() != row['sha256']:
                raise ValueError('checked source proof changed')
            certified.add(str(Path(row['input']).resolve()))
    events = list(map(json.loads, args.events.read_text().splitlines()))
    inputs = {}
    for event in events:
        hydrate_content_addressed_probe_input(event)
        for state in [event.get('input') or {}, *(event.get('witness') or {}).get('residuals', [])]:
            cpf, key = state.get('cpf'), state.get('problem_key')
            if isinstance(cpf, str) and isinstance(key, str):
                if hashlib.sha256(cpf.strip().encode()).hexdigest() != key:
                    raise ValueError('recorded input digest mismatch')
                inputs[key] = cpf
    records, witnesses = {}, {}
    with tempfile.TemporaryDirectory(prefix='ferrum-q-hints-') as temporary:
        for event in events:
            atom = event.get('processor', '')
            identity = event.get('problem_id')
            if not isinstance(identity, str) or str(Path(identity).resolve()) not in certified or event.get('outcome') not in {'solved', 'transformed'}:
                continue
            key = event['input']['problem_key']
            source = inputs[key]
            bound = portable_atom(atom, source, args.all_modular)
            if bound is None:
                continue
            witness = hashlib.sha256(bound.encode()).hexdigest()
            if bound.startswith('exact-'):
                witnesses[witness] = bound
            path = Path(temporary) / 'input.cpf'
            path.write_text(source)
            canonical = subprocess.run([str(args.ferrum.resolve()), 'canonicalize-cpf', str(path)],
                capture_output=True, text=True, check=True, timeout=60).stdout
            canonical_key = hashlib.sha256(canonical.strip().encode()).hexdigest()
            for alias in {key, canonical_key}:
                candidate = dict(candidate_ref=witness) if bound.startswith('exact-') else dict(candidate=bound)
                records.setdefault(alias, {})[witness] = dict(**candidate,
                    status='transformed_weak', utility_score=1000.0, best_elapsed_ms=0,
                    attempts=1, solved_count=0, transformed_count=1,
                    failed_count=0, timeout_count=0, certified_count=0)
    with args.output.open('x') as output:
        for witness, atom in sorted(witnesses.items()):
            print(json.dumps(dict(schema='ferrum.utility-guidance.witness.v1', witness_id=witness, candidate=atom)), file=output)
        for key, candidates in sorted(records.items()):
            print(json.dumps(dict(schema='ferrum.utility-guidance.v2', problem_key=key,
                prefer=[], possible=list(candidates.values()), avoid=[], timeout=[])), file=output)
    print(json.dumps(dict(states=len(records), witnesses=len(witnesses), credit='weak-only')))


if __name__ == '__main__':
    main()
