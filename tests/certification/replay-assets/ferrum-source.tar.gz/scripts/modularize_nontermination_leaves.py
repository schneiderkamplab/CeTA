#!/usr/bin/env python3
"""Replace leaf-only complete NO atoms without losing their established state aliases."""
import argparse
import collections
import hashlib
import json
import re
import xml.etree.ElementTree as ET
from pathlib import Path

PATTERN = re.compile(r'exact-(trs|dp)-nontermination-proof\(hex=([0-9a-fA-F]+)\)')


def replace_leaf(match):
    kind, encoded = match.groups()
    source, proof = json.loads(bytes.fromhex(encoded))
    root = ET.fromstring(proof)
    if root.tag != kind + 'NonterminationProof' or len(root) != 1:
        return match[0]
    child = root[0]
    allowed = {'loop', 'nonLoop', 'notWNTreeAutomaton', 'variableConditionViolated', 'nonterminatingSRS'} if kind == 'trs' else {'loop', 'nonLoop'}
    if child.tag not in allowed:
        return match[0]
    if any(node.tag in {'trsNonterminationProof', 'dpNonterminationProof', 'trsTerminationProof',
                       'dpProof', 'dpTrans', 'uncurry', 'ruleRemoval'}
           for node in list(child.iter())[1:]):
        return match[0]
    family = ('exact-trs-nontermination-terminal' if kind == 'trs' else
              'exact-dp-loop' if child.tag == 'loop' else 'exact-dp-nonloop')
    payload = json.dumps([source, ET.tostring(child, encoding='unicode')],
                         ensure_ascii=False, separators=(',', ':')).encode().hex()
    return f'{family}(hex={payload})'


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--input', type=Path, required=True)
    p.add_argument('--output', type=Path, required=True)
    args = p.parse_args()
    changes = {}
    counts = collections.Counter()
    with args.input.open() as stream:
        for line in stream:
            row = json.loads(line)
            if row.get('schema') == 'ferrum.utility-guidance.witness.v1':
                atom = PATTERN.sub(replace_leaf, row['candidate'])
                if atom != row['candidate']:
                    changes[row['witness_id']] = (hashlib.sha256(atom.encode()).hexdigest(), atom)
                    counts[atom.split('(', 1)[0]] += 1
    with args.input.open() as stream, args.output.open('x') as out:
        seen = set()
        for line in stream:
            row = json.loads(line)
            if row.get('witness_id') in changes:
                row['witness_id'], row['candidate'] = changes[row['witness_id']]
            if row.get('schema') == 'ferrum.utility-guidance.witness.v1':
                if row['witness_id'] in seen:
                    continue
                seen.add(row['witness_id'])
            for bucket in ('prefer', 'possible', 'avoid', 'timeout'):
                for item in row.get(bucket, []):
                    if item.get('candidate_ref') in changes:
                        item['candidate_ref'] = changes[item['candidate_ref']][0]
                    if 'candidate' in item:
                        old = item['candidate']
                        item['candidate'] = PATTERN.sub(replace_leaf, old)
                        if old != item['candidate']:
                            changes[hashlib.sha256(old.encode()).hexdigest()] = (
                                hashlib.sha256(item['candidate'].encode()).hexdigest(), item['candidate'])
            if 'replay_order' in row:
                row['replay_order'] = [changes.get(key, (key, None))[0] for key in row['replay_order']]
            print(json.dumps(row, separators=(',', ':')), file=out)
    print(json.dumps(counts))


if __name__ == '__main__':
    main()
