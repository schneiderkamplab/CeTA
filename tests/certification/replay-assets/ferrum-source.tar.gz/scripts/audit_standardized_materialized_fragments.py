#!/usr/bin/env python3
"""Standardize already-certifiable materialized fragments and recheck CeTA."""

from __future__ import annotations

import argparse
import concurrent.futures
import contextlib
import gzip
import json
import signal
import subprocess
import time
import xml.etree.ElementTree as ET
from copy import deepcopy
from pathlib import Path
from typing import Any

from audit_canonical_fragments import sha256_text
from audit_standardized_subproof_rows import (
    rewrite_symbol_names,
    rewrite_variables_globally,
    standardize_function_bijection,
)


class StandardizationTimeout(TimeoutError):
    pass


@contextlib.contextmanager
def standardization_timer(seconds: float):
    if seconds <= 0:
        yield
        return
    old_handler = signal.getsignal(signal.SIGALRM)
    old_timer = signal.setitimer(signal.ITIMER_REAL, seconds)

    def on_timeout(signum, frame):  # noqa: ARG001
        raise StandardizationTimeout(f"standardization exceeded {seconds:g}s")

    signal.signal(signal.SIGALRM, on_timeout)
    try:
        yield
    finally:
        signal.setitimer(signal.ITIMER_REAL, old_timer[0], old_timer[1])
        signal.signal(signal.SIGALRM, old_handler)


def open_input(path: Path):
    return gzip.open(path, "rt", encoding="utf-8") if path.suffix == ".gz" else path.open("r", encoding="utf-8")


def load_certified_row_ids(results_path: Path) -> set[str]:
    row_ids: set[str] = set()
    with open_input(results_path) as handle:
        for line in handle:
            result = json.loads(line)
            if result.get("status") == "certified" and result.get("row_id"):
                row_ids.add(str(result["row_id"]))
    return row_ids


def base_result(row_index: int, row: dict[str, Any]) -> dict[str, Any]:
    metadata = row.get("metadata") or {}
    return {
        "row_index": row_index,
        "row_id": row.get("id"),
        "source_row_id": row.get("source_row_id"),
        "category": metadata.get("category"),
        "benchmark": metadata.get("benchmark"),
        "tool": metadata.get("tool"),
        "year": metadata.get("year"),
        "processor_tag": metadata.get("processor_tag"),
        "result": metadata.get("result"),
        "source_path": (row.get("source") or {}).get("xml_path"),
    }


def standardize_certificate(certificate: str, max_symbols: int) -> tuple[str, dict[str, str]]:
    root = ET.fromstring(certificate.encode())
    mapping = standardize_function_bijection(root, max_symbols)
    transformed = deepcopy(root)
    rewrite_symbol_names(transformed, mapping)
    rewrite_variables_globally(transformed)
    text = ET.tostring(transformed, encoding="unicode", xml_declaration=True, short_empty_elements=True)
    return text, mapping


def ceta_job(
    ceta: str,
    work_dir: str,
    timeout: int,
    keep: str,
    result: dict[str, Any],
    transformed: str,
) -> dict[str, Any]:
    start = time.monotonic()
    try:
        digest = sha256_text(transformed)[:16]
        row_id = str(result.get("row_id") or "row")
        path = Path(work_dir) / f"{row_id[:16]}-{digest}.standardized.cpf3.xml"
        path.write_text(transformed, encoding="utf-8")
        proc = subprocess.run(
            [ceta, "--allow-assumptions", str(path)],
            text=True,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            timeout=timeout,
        )
        if proc.returncode == 0 and "CERTIFIED" in proc.stdout:
            status = "certified"
        else:
            status = "ceta_failed"
        tail = proc.stdout[-4000:]
    except subprocess.TimeoutExpired as exc:
        path = None  # type: ignore[assignment]
        status = "timeout"
        tail = (exc.stdout or "")[-4000:] if isinstance(exc.stdout, str) else "timeout"
    except Exception as exc:  # noqa: BLE001 - recorded as audit result.
        path = None  # type: ignore[assignment]
        status = "standardization_failed"
        tail = f"{type(exc).__name__}: {exc}"

    elapsed = time.monotonic() - start
    keep_file = keep == "all" or (keep == "failures" and status != "certified")
    cert_path: str | None
    if path is not None and keep_file:
        cert_path = str(path)
    elif path is not None:
        try:
            path.unlink()
        except OSError:
            pass
        cert_path = None
    else:
        cert_path = None
    result.update(
        {
            "status": status,
            "elapsed_sec": round(elapsed, 6),
            "certificate_path": cert_path,
            "ceta_tail": "" if status == "certified" else tail,
        }
    )
    return result


def write_result(sink, result: dict[str, Any], counts: dict[str, int], processors: dict[str, int]) -> None:
    status = str(result.get("status"))
    counts[status] = counts.get(status, 0) + 1
    proc = result.get("processor_tag")
    if proc:
        processors[str(proc)] = processors.get(str(proc), 0) + 1
    sink.write(json.dumps(result, sort_keys=True, separators=(",", ":")) + "\n")


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--jsonl", type=Path, required=True)
    parser.add_argument("--certified-results", type=Path, required=True)
    parser.add_argument("--out-dir", type=Path, required=True)
    parser.add_argument("--ceta", type=Path, default=Path(".tools/ceta-relative-bounds"))
    parser.add_argument("--workers", type=int, default=64)
    parser.add_argument("--timeout", type=int, default=30)
    parser.add_argument("--standardization-timeout", type=float, default=5.0)
    parser.add_argument("--max-symbols", type=int, default=0)
    parser.add_argument("--limit", type=int)
    parser.add_argument("--progress-interval", type=int, default=1000)
    parser.add_argument("--keep-certificates", choices=["none", "failures", "all"], default="failures")
    args = parser.parse_args()

    args.out_dir.mkdir(parents=True, exist_ok=True)
    cert_dir = args.out_dir / "certificates"
    cert_dir.mkdir(exist_ok=True)
    results_path = args.out_dir / "results.jsonl.gz"
    summary_path = args.out_dir / "summary.json"

    eligible_ids = load_certified_row_ids(args.certified_results)
    counts: dict[str, int] = {}
    processors: dict[str, int] = {}
    processed = 0
    scanned = 0
    elapsed_total = 0.0
    identity_mappings = 0
    nonidentity_mappings = 0
    started = time.monotonic()
    max_pending = max(1, args.workers * 2)
    pending: set[concurrent.futures.Future] = set()

    with gzip.open(results_path, "wt", encoding="utf-8") as sink, concurrent.futures.ThreadPoolExecutor(max_workers=args.workers) as pool:
        def drain_one(wait: bool = False) -> None:
            nonlocal elapsed_total, identity_mappings, nonidentity_mappings
            if not pending:
                return
            done, _ = concurrent.futures.wait(
                pending,
                timeout=None if wait else 0,
                return_when=concurrent.futures.FIRST_COMPLETED,
            )
            for fut in done:
                pending.remove(fut)
                result = fut.result()
                elapsed_total += float(result.get("elapsed_sec") or 0.0)
                if result.get("function_mapping_identity"):
                    identity_mappings += 1
                else:
                    nonidentity_mappings += 1
                write_result(sink, result, counts, processors)

        with open_input(args.jsonl) as handle:
            for row_index, line in enumerate(handle, start=1):
                scanned += 1
                row = json.loads(line)
                row_id = str(row.get("id") or "")
                if row_id not in eligible_ids:
                    continue
                processed += 1
                if args.limit is not None and processed > args.limit:
                    break
                audit = row.get("fragment_audit") or {}
                cert = audit.get("cpf3_certificate")
                result = base_result(row_index, row)
                if not cert:
                    result.update({"status": "missing_certificate", "elapsed_sec": 0.0})
                    write_result(sink, result, counts, processors)
                    continue
                try:
                    with standardization_timer(args.standardization_timeout):
                        transformed, mapping = standardize_certificate(str(cert), args.max_symbols)
                    result["function_mapping_size"] = len(mapping)
                    result["function_mapping_identity"] = all(old == new for old, new in mapping.items())
                except Exception as exc:  # noqa: BLE001 - recorded as audit result.
                    result.update(
                        {
                            "status": "standardization_failed",
                            "elapsed_sec": 0.0,
                            "function_mapping_size": 0,
                            "function_mapping_identity": False,
                            "ceta_tail": f"{type(exc).__name__}: {exc}",
                        }
                    )
                    write_result(sink, result, counts, processors)
                    continue
                while len(pending) >= max_pending:
                    drain_one(wait=True)
                pending.add(
                    pool.submit(
                        ceta_job,
                        str(args.ceta),
                        str(cert_dir),
                        args.timeout,
                        args.keep_certificates,
                        result,
                        transformed,
                    )
                )
                drain_one(wait=False)
                if args.progress_interval > 0 and processed % args.progress_interval == 0:
                    print(
                        json.dumps(
                            {
                                "event": "progress",
                                "eligible_processed": processed,
                                "scanned": scanned,
                                "pending": len(pending),
                                "counts": counts,
                                "elapsed_wall_sec": round(time.monotonic() - started, 3),
                            },
                            sort_keys=True,
                        ),
                        flush=True,
                    )
        while pending:
            drain_one(wait=True)

    summary = {
        "jsonl": str(args.jsonl),
        "certified_results": str(args.certified_results),
        "results": str(results_path),
        "eligible_input_rows": len(eligible_ids),
        "eligible_processed": processed if args.limit is None else min(processed, args.limit),
        "rows_scanned": scanned,
        "counts": dict(sorted(counts.items())),
        "processor_counts": dict(sorted(processors.items())),
        "identity_mappings": identity_mappings,
        "nonidentity_mappings": nonidentity_mappings,
        "ceta_elapsed_total_sec": round(elapsed_total, 6),
        "wall_elapsed_sec": round(time.monotonic() - started, 6),
        "workers": args.workers,
        "timeout": args.timeout,
        "standardization_timeout_seconds": args.standardization_timeout,
        "max_symbols": args.max_symbols,
    }
    summary_path.write_text(json.dumps(summary, indent=2, sort_keys=True), encoding="utf-8")
    print(json.dumps(summary, sort_keys=True), flush=True)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
