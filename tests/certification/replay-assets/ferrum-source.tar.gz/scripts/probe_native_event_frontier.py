"""Explore unguided typed DP/TRS states with native search processors.

Discovery only: supplied interpretations are discarded, every exported local
certificate is checked twice, and root recovery requires a separate replay.
"""
import argparse
import collections
from concurrent.futures import ThreadPoolExecutor, as_completed
import hashlib
from functools import lru_cache
import json
import os
import re
from pathlib import Path
import subprocess
import time
import xml.etree.ElementTree as ET

from probe_witness_free_oracle import replace

FAMILIES = {'graph-refined', 'poly', 'matrix', 'arctic-matrix', 'integer-matrix', 'arctic-int',
            'rat-poly', 'rat-quadratic-poly', 'quadratic-poly', 'weak-poly',
            'mono-poly', 'path-order', 'kbo', 'max-poly', 'wpo-max', 'conditional-poly',
            'narrow', 'rewrite', 'instantiate', 'forward-instantiate',
            'usable-rules', 'innermost-lhss', 'semantic-labeling', 'split', 'complex-constant-removal',
            'nontermination', 'nontermination-cycle', 'nontermination-narrow', 'nontermination-instance', 'nontermination-rule-filter', 'nontermination-usable-rules', 'nontermination-innermost-lhss', 'switch-full-nontermination',
            'complex-constant-removal-largest', 'switch-innermost', 'alpha-merge',
            'uncurry', 'uncurry-below', 'switch-to-trs'}


def native_atoms(events):
    atoms = ['graph', 'size-change', 'subterm']
    for e in events:
        if e.get('outcome') not in ('solved', 'transformed'):
            continue
        atom = replace(e.get('strategy_atom') or e.get('processor', ''))
        if not atom or atom.split('(', 1)[0] not in FAMILIES or ';' in atom:
            continue
        if atom == 'nontermination':
            # This helper builds DP recipes; the unqualified top-level
            # portfolio is not an atomic DP strategy.
            for native in ('nontermination(dp-loop)', 'nontermination(dp-nonloop)'):
                if native not in atoms:
                    atoms.append(native)
            continue
        if atom not in atoms:
            atoms.append(atom)
    return atoms


@lru_cache(maxsize=32)
def signature_bounds(cpf):
    root = ET.fromstring(cpf)
    signature = set()
    max_arity = 0
    for term in root.iter('funapp'):
        if len(term):
            signature.add(''.join(ET.tostring(term[0], encoding='unicode').split()))
            max_arity = max(max_arity, len(term) - 1)
    return len(signature), max_arity


def fit_signature(atom, cpf):
    symbols, arity = signature_bounds(cpf)
    for name, minimum in [('max-symbols', symbols), ('max-arity', arity)]:
        atom = re.sub(rf'\b{name}=(\d+)',
                      lambda m: f'{name}={max(int(m[1]), minimum)}', atom)
    return atom


def native_recipe(events, cpf=None, processor_timeout=8, prefer_families=(), size_change_timeout=None,
                  additional_atoms=(), additional_first=False):
    return recipe_from_atoms(native_atoms(events), cpf, processor_timeout, prefer_families,
                             size_change_timeout, additional_atoms, additional_first)


def recipe_from_atoms(source_atoms, cpf=None, processor_timeout=8, prefer_families=(),
                      size_change_timeout=None, additional_atoms=(), additional_first=False):
    if processor_timeout <= 0:
        raise ValueError('processor timeout must be positive')
    atoms = list(source_atoms)
    extras = []
    for atom in additional_atoms:
        if (atom.split('(', 1)[0] not in FAMILIES or any(x in atom for x in (';', '|', 'hex=', 'exact-'))
                or not re.fullmatch(r'[a-z][a-z-]*(?:\([a-z0-9=,\-]+\))?', atom)):
            raise ValueError('additional atom must be a native parameter-only action')
        extras.append(atom)
    atoms = atoms[:3] + extras + atoms[3:] if additional_first else atoms + extras
    if cpf is not None:
        atoms = [fit_signature(atom, cpf) for atom in atoms]
    # Distinct source bounds can become identical after fitting the live
    # signature. Do not spend the root budget repeating the same search.
    atoms = list(dict.fromkeys(atoms))
    unknown = set(prefer_families) - FAMILIES
    if unknown:
        raise ValueError(f'unknown preferred families: {sorted(unknown)}')
    priority = {family: index for index, family in enumerate(prefer_families)}
    atoms[3:] = sorted(atoms[3:], key=lambda atom:
        priority.get(atom.split('(', 1)[0], len(priority)))
    if size_change_timeout is not None:
        if size_change_timeout <= 0:
            raise ValueError('size-change timeout must be positive')
        atoms[1] = f'timeout({size_change_timeout}s, size-change)'
    return ' | '.join(atoms[:3] + [f'timeout({processor_timeout}s, {atom})' for atom in atoms[3:]])


def unresolved_states(events, include_trs=False, include_exhausted=False):
    events = list(events)
    productive = {(e.get('input') or {}).get('problem_key') for e in events
                  if e.get('outcome') in ('solved', 'transformed')}
    inline = {}
    for event in events:
        for state in [event.get('input') or {}, *((event.get('witness') or {}).get('residuals') or [])]:
            if state.get('cpf'):
                inline[state.get('problem_key')] = state['cpf']
    states = {}
    for e in events:
        if e.get('outcome') != 'failed':
            continue
        candidates = []
        # A state can have guidance yet exhaust every applicable attempt.
        # Missing-guidance events alone do not expose that frontier. Exclude
        # states with positive local progress: follow their children instead.
        if include_exhausted:
            state = e.get('input') or {}
            if state.get('problem_key') not in productive:
                candidates.append(state)
        # The top-level worklist can reach an unguided TRS child and only
        # attempt its unconditional empty-system check. It does not emit the
        # DP-specific UtilityGuidance failure event in that case.
        if include_trs and (e.get('strategy_atom') or e.get('processor')) == 'empty':
            state = e.get('input') or {}
            cpf = state.get('cpf') or inline.get(state.get('problem_key'))
            if cpf and ET.fromstring(cpf).tag == 'trsInput':
                candidates.append(state)
        if (e.get('strategy_atom') or e.get('processor')) in ('utility-guidance', 'UtilityGuidance'):
            candidates.append(e.get('input') or {})
        if e.get('failure_reason') == 'strict oracle transformation produced an unguided residual':
            candidates.extend((e.get('witness') or {}).get('residuals') or [])
        for state in candidates:
            key = state.get('problem_key')
            cpf = state.get('cpf') or inline.get(key)
            if not cpf:
                continue
            if hashlib.sha256(cpf.strip().encode()).hexdigest() != key:
                raise ValueError('frontier state digest mismatch')
            xml = ET.fromstring(cpf)
            dp = xml if xml.tag in ('dpInput', 'relativeDpInput') else xml.find('.//dpInput')
            if dp is None and not (include_trs and xml.tag == 'trsInput'):
                continue
            pairs = len(dp.findall('./dps/rules/rule')) if dp is not None else len(xml.findall('./trs/rules/rule'))
            states[key] = (pairs, cpf)
    return states


def tried_recipes(rows, timeout):
    # Legacy wave manifests did not record their root ceiling. The caller's
    # explicit --skip-details assertion covers those; recorded smaller
    # budgets never suppress an escalation, and infrastructure errors retry.
    return {(r['key'], r['recipe']) for r in rows
            if r.get('status') != 'error' and r.get('probe_timeout_seconds', timeout) >= timeout}


def certified_state_keys(rows):
    """Discovery scheduling only: avoid spending another slot on a closed state.

    Require both recorded checker passes, not just a positive prover status.
    This does not import evidence or promote the containing root.
    """
    return {r['key'] for r in rows
            if r.get('key') and r.get('certified') and r.get('status') in ('yes', 'no')
            and len(r.get('checks', [])) == 2
            and all(c.get('returncode') == 0 and 'CERTIFIED' in c.get('stdout', '').splitlines()
                    for c in r['checks'])}


def typed_frontier(events, state_kind='dp', include_exhausted=False):
    if state_kind not in ('dp', 'trs'):
        raise ValueError('unsupported frontier state kind')
    states = unresolved_states(events, include_trs=state_kind == 'trs',
                               include_exhausted=include_exhausted)
    return {key: item for key, item in states.items()
            if (ET.fromstring(item[1]).tag == 'trsInput') == (state_kind == 'trs')}


def native_top_recipe(recipe):
    if not recipe or not recipe.strip() or 'exact-' in recipe or 'hex=' in recipe:
        raise ValueError('TRS discovery requires a native search strategy')
    return recipe


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--additional-first', action='store_true',
                   help='Try additional bounded native searches before historical families, after cheap terminal checks')
    p.add_argument('--baseline', type=Path, required=True)
    p.add_argument('--current', type=Path, required=True)
    p.add_argument('--ferrum', type=Path, required=True)
    p.add_argument('--ceta', type=Path, required=True)
    p.add_argument('--output', type=Path, required=True)
    p.add_argument('--jobs', type=int, default=8)
    p.add_argument('--continuation-attempts', type=int,
                   help='Opt-in shared descendant attempt budget per alternative, preserving sibling search')
    p.add_argument('--timeout', type=int, default=60)
    p.add_argument('--processor-timeout', type=int, default=8,
                   help='Per-family search allowance in seconds (root timeout still applies).')
    p.add_argument('--states-per-root', type=int, default=3)
    p.add_argument('--root-status', choices=['yes', 'no'],
                   help='Restrict discovery to this certified source polarity')
    p.add_argument('--state-kind', choices=['dp', 'trs'], default='dp')
    p.add_argument('--trs-strategy', help='Native discovery strategy for TRS states; never exported as a pipeline')
    p.add_argument('--size-change-timeout', type=int,
                   help='Optional local bound to avoid repeatedly exhausting time in SCT.')
    p.add_argument('--prefer-family', action='append', choices=sorted(FAMILIES), default=[],
                   help='Try this existing evidence family earlier; does not supply a model.')
    p.add_argument('--additional-atom', action='append', default=[],
                   help='Bounded native search alternative for a later broader discovery wave.')
    p.add_argument('--include-exhausted', action='store_true',
                   help='Also probe guided states whose recorded attempts all failed.')
    p.add_argument('--skip-details', type=Path, action='append', default=[],
                   help='Skip identical state/recipe trials from earlier waves; use only with equal or larger prior budgets.')
    p.add_argument('--skip-certified-details', type=Path, action='append', default=[],
                   help='Skip independently certified states from prior local waves, regardless of recipe or budget.')
    args = p.parse_args()
    if args.processor_timeout <= 0 or args.states_per_root <= 0:
        p.error('--processor-timeout and --states-per-root must be positive')
    if args.continuation_attempts is not None and args.continuation_attempts <= 0:
        p.error('--continuation-attempts must be positive')
    if args.state_kind == 'trs':
        native_top_recipe(args.trs_strategy)
    prior = {r['path']: r for r in json.loads(args.baseline.read_text())}
    tried = set()
    for details in args.skip_details:
        tried.update(tried_recipes(json.loads(details.read_text()), args.timeout))
    closed = set()
    for details in args.skip_certified_details:
        closed.update(certified_state_keys(json.loads(details.read_text())))
    jobs = {}
    root_selected = collections.Counter()
    for root in json.loads(args.current.read_text()):
        if root.get('certified') or root['path'] not in prior:
            continue
        if args.root_status and prior[root['path']]['status'] != args.root_status:
            continue
        if root_selected[root['path']] >= args.states_per_root:
            continue
        path = Path(root['artifact_dir']) / 'processor-events.jsonl'
        with path.open() as source:
            states = typed_frontier(map(json.loads, source), args.state_kind, args.include_exhausted)
        original = Path(prior[root['path']]['artifact_dir']) / 'processor-events.jsonl'
        with original.open() as source:
            # Decode witness-derived parameter bounds only once per root,
            # rather than again for every old and new residual state.
            source_atoms = native_atoms(map(json.loads, source))
        for key, (count, cpf) in sorted(states.items(), key=lambda kv: kv[1][0]):
            if key in closed:
                continue
            recipe = args.trs_strategy if args.state_kind == 'trs' else recipe_from_atoms(
                source_atoms, cpf, args.processor_timeout, args.prefer_family,
                args.size_change_timeout, args.additional_atom, args.additional_first)
            if (key, recipe) in tried:
                continue
            # Different roots can offer different continuation families.
            identity = hashlib.sha256((key + recipe).encode()).hexdigest()
            if identity in jobs:
                continue
            jobs[identity] = dict(key=key, cpf=cpf, pairs=count, recipe=recipe,
                                  root=root['path'])
            root_selected[root['path']] += 1
            if root_selected[root['path']] >= args.states_per_root:
                break
    args.output.mkdir(parents=True, exist_ok=False)
    print(json.dumps(dict(probes=len(jobs))), flush=True)

    def run(item):
        identity, job = item
        directory = args.output / identity
        directory.mkdir()
        source, proof = directory / 'input.cpf', directory / 'proof.cpf.xml'
        source.write_text(job['cpf'])
        (directory / 'strategy.fs').write_text(job['recipe'])
        env = dict(os.environ, RAYON_NUM_THREADS='2')
        env.pop('FERRUM_DP_LLM_NO_FALLBACK', None)
        if args.continuation_attempts is not None:
            env['FERRUM_DP_EXPLORATION_CONTINUATION_ATTEMPTS'] = str(args.continuation_attempts)
        started = time.monotonic()
        command = [str(args.ferrum.resolve()), 'probe-cpf', str(source), '--recursive', '--summary',
                   '--strategy', job['recipe'], '--timeout-ms', str(args.timeout * 1000),
                   '--processor-events', str(directory / 'processor-events.jsonl'), '--cpf', str(proof)]
        with (directory / 'stdout').open('x') as stdout, (directory / 'stderr').open('x') as stderr:
            try:
                status = subprocess.run(command, env=env, stdout=stdout, stderr=stderr,
                                        timeout=args.timeout + 5).returncode
            except subprocess.TimeoutExpired:
                status = 'timeout'
        row = {k: v for k, v in job.items() if k != 'cpf'}
        row.update(artifact_dir=str(directory), elapsed_seconds=time.monotonic()-started,
                   status='timeout' if status == 'timeout' else 'unknown' if status == 0 else 'error',
                   exit_code=status, certified=False, probe_timeout_seconds=args.timeout)
        if status == 0 and proof.exists():
            checks = []
            for _ in range(2):
                try:
                    result = subprocess.run([str(args.ceta.resolve()), str(proof)],
                                            capture_output=True, text=True, timeout=120)
                    checks.append(dict(returncode=result.returncode, stdout=result.stdout, stderr=result.stderr))
                except subprocess.TimeoutExpired:
                    checks.append(dict(returncode=None, stdout='', stderr='checker timeout'))
            row['checks'] = checks
            row['certified'] = all(c['returncode'] == 0 and 'CERTIFIED' in c['stdout'].splitlines() for c in checks)
            if row['certified']:
                proof_node = ET.parse(proof).getroot().find('proof')
                row['status'] = 'no' if proof_node is not None and any(
                    child.tag.endswith('NonterminationProof') for child in proof_node) else 'yes'
                row['path'] = str(source)
        return row

    results = []
    with (args.output / 'results.jsonl').open('x') as out, ThreadPoolExecutor(max_workers=args.jobs) as pool:
        for future in as_completed([pool.submit(run, item) for item in jobs.items()]):
            row = future.result()
            results.append(row)
            print(json.dumps(row), file=out, flush=True)
            print(json.dumps(dict(done=len(results), certified=sum(r['certified'] for r in results),
                                  root=row['root'], pairs=row['pairs'])), flush=True)
    (args.output / 'details.json').write_text(json.dumps(results))


if __name__ == '__main__':
    main()
