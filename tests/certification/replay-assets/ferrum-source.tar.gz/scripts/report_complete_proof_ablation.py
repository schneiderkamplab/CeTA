#!/usr/bin/env python3
"""Compare complete or in-progress ablation results with a certified baseline."""
import argparse
import collections
import json
from pathlib import Path


def key(row):
    return row["path"].split("TPDB-ARI/", 1)[-1]


def trace(path):
    result = []
    if path.exists():
        for line in path.open():
            row = json.loads(line)
            result.append({"atom": row.get("strategy_atom", "").split("(", 1)[0],
                           "outcome": row.get("outcome"),
                           "state": row.get("input", {}).get("problem_key"),
                           "failure_reason": row.get("failure_reason"),
                           "metrics": row.get("metrics")})
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--baseline", type=Path, required=True)
    parser.add_argument("--run", type=Path, required=True)
    args = parser.parse_args()
    report = {}
    for category in ("standard", "innermost", "csr"):
        baseline = {key(row): row for row in json.loads((args.baseline / category / "details.json").read_text())}
        details = args.run / category / "details.json"
        if details.exists():
            rows = json.loads(details.read_text())
        else:
            rows = [json.loads(path.read_text()) for path in (args.run / category / "run").rglob("result.json")]
        losses, gains, changes = [], [], []
        for row in rows:
            old = baseline[key(row)]
            if old["certified"] and not row["certified"]:
                losses.append({"path": key(row), "status": row["status"],
                               "elapsed_seconds": row["elapsed_seconds"],
                               "baseline_seconds": old["elapsed_seconds"],
                               "baseline_trace": trace(Path(old["artifact_dir"]) / "processor-events.jsonl"),
                               "ablation_trace": trace(Path(row["artifact_dir"]) / "processor-events.jsonl")})
            if row["certified"] and not old["certified"]:
                gains.append(key(row))
            if row["certified"] and old["certified"] and row["status"] != old["status"]:
                changes.append(key(row))
        report[category] = {"completed": len(rows), "expected": len(baseline),
                            "certified": sum(row["certified"] for row in rows),
                            "statuses": dict(collections.Counter(row["status"] for row in rows)),
                            "losses": losses, "gains": gains, "polarity_changes": changes}
    print(json.dumps(report, indent=2))


if __name__ == "__main__":
    main()
