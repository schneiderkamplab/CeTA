"""Expose unresolved audit inputs to source-proof hint extraction, without positive credit."""
import argparse
import hashlib
import json
from pathlib import Path


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--inventory', type=Path, required=True)
    parser.add_argument('--replay', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    unresolved = {r['input'] for r in map(json.loads, args.replay.read_text().splitlines())
                  if 'proof' not in r}
    identities = {}
    with args.output.open('x') as output:
        for row in json.loads(args.inventory.read_text())['records']:
            if row['input'] not in unresolved:
                continue
            raw = Path(row['input']).read_bytes()
            if hashlib.sha256(raw).hexdigest() != row['sha256']:
                raise ValueError('audited input changed: ' + row['input'])
            cpf = raw.decode()
            for origin in row['origins']:
                source = origin['source_events']
                if source not in identities:
                    with Path(source).open() as events:
                        event = next(json.loads(line) for line in events if line.strip())
                    identities[source] = (event['problem_id'], event.get('category'))
                identity, category = identities[source]
                print(json.dumps(dict(schema='ferrum.processor-event.v1',
                    problem_id=identity, category=category, processor='audit-registry',
                    outcome='failed', level='dependency-pair',
                    input=dict(problem_key=hashlib.sha256(cpf.strip().encode()).hexdigest(),
                               cpf=cpf, standardized=False),
                    provenance=dict(audit_input=row['input'], source_events=source,
                                    credit='none'))), file=output)


if __name__ == '__main__':
    main()
