"""Try retained finite models as freshly checked local transformations, not proofs."""
import argparse
import json
from pathlib import Path
import subprocess
import xml.etree.ElementTree as ET
from extract_local_cpf_oracle_events import interpretation_symbol_name


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--overlay', type=Path)
    p.add_argument('--constructor-model', action='store_true')
    p.add_argument('--input', type=Path, required=True)
    p.add_argument('--output', type=Path, required=True)
    p.add_argument('--ferrum', type=Path, required=True)
    p.add_argument('--timeout-ms', type=int, default=180000)
    args = p.parse_args()
    args.output.mkdir()
    models = {}
    if not args.overlay and not args.constructor_model:
        p.error('select retained models or the generic constructor model')
    if args.constructor_model:
        arities = {}
        for node in ET.fromstring(args.input.read_text()).iter('funapp'):
            symbol = interpretation_symbol_name(node)
            if symbol is None:
                raise ValueError('unsupported live symbol')
            arity = len(node) - 1
            if symbol in arities and arities[symbol] != arity:
                raise ValueError('inconsistent live arity')
            arities[symbol] = arity
        model = dict(carrier_size=2, arities=arities,
                     interpretations={s: dict(Constant=int(a == 0)) for s, a in arities.items()})
        models[json.dumps(model, sort_keys=True)] = model
    for row in map(json.loads, args.overlay.read_text().splitlines() if args.overlay else []):
        atom = row.get('candidate', '')
        if atom.startswith('exact-semantic-labeling(hex='):
            value = json.loads(bytes.fromhex(atom.split('hex=')[1][:-1]))
            model = value[0] if isinstance(value, list) else value
            models[json.dumps(model, sort_keys=True)] = model
    with (args.output / 'results.jsonl').open('x') as results:
        for index, model in enumerate(models.values()):
            # Drop the old transition's expected child, not any live obligation.
            # Ferrum must validate this finite model on the actual R and label
            # every live P/R/Q/strict/weak component afresh.
            atom = 'exact-semantic-labeling(hex=' + json.dumps(model).encode().hex() + ')'
            proof = args.output / f'{index}.cpf'
            events = args.output / f'{index}.events.jsonl'
            command = [str(args.ferrum.resolve()), 'probe-cpf', str(args.input), '--recursive',
                       '--strategy', atom + '; graph; portfolio', '--timeout-ms', str(args.timeout_ms),
                       '--cpf', str(proof), '--processor-events', str(events), '--summary']
            with (args.output / f'{index}.stdout').open('x') as out, (args.output / f'{index}.stderr').open('x') as err:
                try:
                    code = subprocess.run(command, stdout=out, stderr=err,
                                          timeout=args.timeout_ms / 1000 + 5).returncode
                except subprocess.TimeoutExpired:
                    code = 'harness-timeout'
            row = dict(input=str(args.input.resolve()), exit_code=code, certified=False)
            if proof.exists() and proof.stat().st_size:
                row['proof'] = str(proof)
            print(json.dumps(row), file=results, flush=True)


if __name__ == '__main__':
    main()
