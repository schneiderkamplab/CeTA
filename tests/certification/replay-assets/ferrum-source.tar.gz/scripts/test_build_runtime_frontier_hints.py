import json
from pathlib import Path
import tempfile
import unittest

from build_runtime_frontier_hints import collect


class RuntimeFrontierHintTests(unittest.TestCase):
    def test_collects_event_input_and_typed_residual_for_selected_status(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            artifact = Path(temporary)
            trs = "<trsInput><trs><rules /></trs></trsInput>"
            dp = "<dpInput><trs><rules /></trs><dps><rules /></dps><minimal>true</minimal></dpInput>"
            event = {
                "input": {"problem_key": "root", "cpf": trs},
                "witness": {
                    "residuals": [{"problem_key": "child", "cpf": dp}]
                },
            }
            (artifact / "processor-events.jsonl").write_text(
                json.dumps(event) + "\n", encoding="utf-8"
            )
            rows = collect(
                [
                    {
                        "status": "maybe",
                        "path": "TRS_Standard/example.ari",
                        "artifact_dir": str(artifact),
                    },
                    {
                        "status": "yes",
                        "path": "ignored.ari",
                        "artifact_dir": str(artifact),
                    },
                ],
                {"maybe"},
                {"child": ["exact-child"]},
            )
            self.assertEqual([row["problem_key"] for row in rows], ["child", "root"])
            child = rows[0]
            atoms = [item["atom"] for item in child["suggested_atoms"]]
            self.assertEqual(atoms[0], "exact-child")
            self.assertIn("graph", atoms)
            self.assertEqual(child["root_origins"], ["TRS_Standard/example.ari"])


if __name__ == "__main__":
    unittest.main()
