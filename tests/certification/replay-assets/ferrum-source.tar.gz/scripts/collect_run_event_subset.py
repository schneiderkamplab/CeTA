#!/usr/bin/env python3
"""Collect retained per-example processor events selected by result status."""

from __future__ import annotations

import argparse
import json
from collections import Counter
from pathlib import Path


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--details", type=Path, required=True)
    parser.add_argument(
        "--status",
        action="append",
        default=[],
        help="result status to retain; repeatable",
    )
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument(
        "--certify-solved-attempts",
        action="store_true",
        help=(
            "mark solved processor attempts from certified result rows as "
            "independently certified positive evidence"
        ),
    )
    args = parser.parse_args()
    statuses = set(args.status or ["unknown", "timeout"])
    details = json.loads(args.details.read_text(encoding="utf-8"))
    selected = [row for row in details if row.get("status") in statuses]
    counts: Counter[str] = Counter()
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with args.output.open("w", encoding="utf-8") as sink:
        for row in selected:
            events = Path(row["artifact_dir"]) / "processor-events.jsonl"
            if not events.exists():
                counts["missing_event_file"] += 1
                continue
            with events.open(encoding="utf-8", errors="replace") as source:
                for line in source:
                    try:
                        event = json.loads(line)
                    except json.JSONDecodeError:
                        counts["invalid_event"] += 1
                        continue
                    if (
                        args.certify_solved_attempts
                        and row.get("certified") is True
                        and event.get("outcome") == "solved"
                        and not (
                            (
                                row.get("category") == "TRS_Contextsensitive"
                                or event.get("category") == "TRS_Contextsensitive"
                            )
                            and (
                                event.get("level") == "dependency-pair"
                                or str(event.get("processor", "")).startswith(
                                    "DependencyPairs"
                                )
                            )
                        )
                    ):
                        event["certification"] = {
                            "status": "certified-full-result",
                            "checker": row.get("certifier") or "CeTA",
                        }
                        event["credit"] = {"status": "proof-path-certified"}
                        sink.write(
                            json.dumps(event, separators=(",", ":"), sort_keys=True)
                            + "\n"
                        )
                        counts["certified_solved_attempts"] += 1
                    else:
                        if (
                            args.certify_solved_attempts
                            and row.get("certified") is True
                            and event.get("outcome") == "solved"
                            and (
                                event.get("level") == "dependency-pair"
                                or str(event.get("processor", "")).startswith(
                                    "DependencyPairs"
                                )
                            )
                        ):
                            counts["uncertified_non_self_contained_dp_attempts"] += 1
                        sink.write(line if line.endswith("\n") else line + "\n")
                    counts["events"] += 1
            counts[f"status:{row['status']}"] += 1
            counts["examples"] += 1
    summary = {
        "details": str(args.details),
        "statuses": sorted(statuses),
        "output": str(args.output),
        "counts": dict(sorted(counts.items())),
    }
    args.output.with_suffix(args.output.suffix + ".summary.json").write_text(
        json.dumps(summary, indent=2, sort_keys=True) + "\n",
        encoding="utf-8",
    )
    print(json.dumps(summary, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
