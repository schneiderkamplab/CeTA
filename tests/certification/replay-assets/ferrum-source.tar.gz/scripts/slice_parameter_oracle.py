"""Slice witness-free guidance by observed states, preserving alias components.

This is a replay candidate, not proof that unobserved states are unnecessary.
Validate the complete intended root set before adopting the output.
"""
import argparse
import collections
import hashlib
import json
import re
from pathlib import Path


def cpf_keys(cpf):
    raw = cpf.strip()
    compact = re.sub(r'>[\t\n\v\f\r ]+<', '><', raw)
    compact = re.sub(r'[\t\n\v\f\r ]+/>', '/>', compact)
    for entity in ('&apos;', '&#39;', '&#x27;', '&#X27;'):
        compact = compact.replace(entity, "'")
    return {hashlib.sha256(text.encode()).hexdigest() for text in (raw, compact)}


def state_keys(value):
    if isinstance(value, dict):
        for key, child in value.items():
            if key in ('problem_key', 'canonical_problem_key') and isinstance(child, str):
                yield child
            elif key == 'cpf' and isinstance(child, str):
                yield from cpf_keys(child)
            elif isinstance(child, (dict, list)):
                yield from state_keys(child)
    elif isinstance(value, list):
        for child in value:
            yield from state_keys(child)


def alias_closure(seeds, edges):
    neighbors = collections.defaultdict(set)
    for a, b in edges:
        neighbors[a].add(b)
        neighbors[b].add(a)
    selected = set(seeds)
    pending = list(selected)
    while pending:
        for neighbor in neighbors[pending.pop()]:
            if neighbor not in selected:
                selected.add(neighbor)
                pending.append(neighbor)
    return selected


def assert_parameter_only(value):
    if isinstance(value, dict):
        if value.get('schema') == 'ferrum.utility-guidance.witness.v1':
            raise ValueError('input contains witness definitions')
        for key, child in value.items():
            if key == 'candidate_ref':
                raise ValueError('input contains a witness reference')
            if key == 'candidate' and isinstance(child, str):
                if 'exact-' in child or 'hex=' in child:
                    raise ValueError('input contains an exact/payload action')
            assert_parameter_only(child)
    elif isinstance(value, list):
        for child in value:
            assert_parameter_only(child)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--oracle', type=Path, required=True)
    parser.add_argument('--details', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--lookup-trace-dir', type=Path)
    args = parser.parse_args()
    roots = json.loads(args.details.read_text())
    seeds = set()
    for root in roots:
        if not root.get('certified') or root.get('status') not in ('yes', 'no'):
            raise ValueError('all source roots must be certified decisions')
        events = Path(root['artifact_dir']) / 'processor-events.jsonl'
        root_keys = set()
        with events.open() as source:
            for line in source:
                root_keys.update(state_keys(json.loads(line)))
        if not root_keys:
            raise ValueError(f'no observed states: {events}')
        seeds.update(root_keys)
    if args.lookup_trace_dir:
        traces = list(args.lookup_trace_dir.glob('*.jsonl'))
        if not traces:
            raise ValueError('lookup trace directory is empty')
        for path in traces:
            with path.open() as source:
                for line in source:
                    keys = json.loads(line)
                    if not isinstance(keys, list) or len(keys) != 2 or not all(
                            isinstance(key, str) and len(key) == 64 and
                            all(c in '0123456789abcdef' for c in key) for key in keys):
                        raise ValueError(f'invalid lookup trace: {path}')
                    seeds.update(keys)
    edges = []
    with args.oracle.open() as source:
        for line in source:
            row = json.loads(line)
            assert_parameter_only(row)
            if row.get('canonical_problem_key'):
                edges.append((row['problem_key'], row['canonical_problem_key']))
    selected = alias_closure(seeds, edges)
    count = 0
    with args.output.open('x') as out, args.oracle.open() as source:
        for line in source:
            row = json.loads(line)
            if row.get('problem_key') in selected:
                out.write(line)
                count += 1
    print(json.dumps({'roots': len(roots), 'observed_keys': len(seeds),
                      'alias_closed_keys': len(selected), 'retained_rows': count,
                      'input_bytes': args.oracle.stat().st_size,
                      'output_bytes': args.output.stat().st_size}))


if __name__ == '__main__':
    main()
