"""Select deterministic, diverse retained children, without benchmark dispatch."""
import argparse
import json
from pathlib import Path


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("audit", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("--rejected-checks", type=Path)
    parser.add_argument("--unfinished-results", type=Path, action="append", default=[])
    parser.add_argument("--export-errors", type=Path)
    parser.add_argument("--uncertified-run", type=Path)
    args = parser.parse_args()
    if args.uncertified_run:
        rows = [json.loads(path.read_text()) for path in args.uncertified_run.rglob("result.json")]
        with args.output.open("x") as output:
            output.writelines(row["path"] + "\n" for row in rows if not row.get("certified"))
        return
    if args.export_errors:
        rows = [json.loads(line) for line in args.export_errors.read_text().splitlines()]
        with args.output.open("x") as output:
            output.writelines(row["input"] + "\n" for row in rows if "error" in row)
        return
    if args.rejected_checks:
        rows = [json.loads(line) for line in args.rejected_checks.read_text().splitlines()]
        paths = sorted({row["input"] for row in rows if not row["certified"]})
        with args.output.open("x") as output:
            output.writelines(path + "\n" for path in paths)
        print(f"Selected {len(paths)} rejected states")
        return
    groups = {}
    for line in (args.audit / "strict-equivalence.jsonl").open():
        row = json.loads(line)
        for child in row.get("observations", []):
            key = (row["family"], child["problem_kind"], child["variant"])
            groups.setdefault(key, set()).add(child["sha256"])
    selected = sorted({min(values) for values in groups.values()})
    paths = [(args.audit / "states" / (digest + ".cpf")).resolve() for digest in selected]
    if args.unfinished_results:
        done = {json.loads(line)["input"] for report in args.unfinished_results
                for line in report.read_text().splitlines()}
        paths = [path for path in paths if str(path) not in done]
    assert all(path.is_file() for path in paths)
    with args.output.open("x") as output:
        output.writelines(str(path) + "\n" for path in paths)
    print(f"Selected {len(paths)} unique states from {len(groups)} family/kind/variant groups")


if __name__ == "__main__":
    main()
