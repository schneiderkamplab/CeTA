#!/usr/bin/env python3

import importlib.util
import hashlib
import json
from pathlib import Path
import sqlite3
import subprocess
import tempfile
import unittest


FAMILY_SCRIPT = Path(__file__).with_name("build_family_transfer_hints.py")
SPEC = importlib.util.spec_from_file_location("family_hints", FAMILY_SCRIPT)
assert SPEC is not None and SPEC.loader is not None
FAMILY = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(FAMILY)
CLASSIFIER = Path(__file__).with_name("classify_state_first_gaps.py")
AUDIT_SPEC = importlib.util.spec_from_file_location(
    "oracle_applicability", Path(__file__).with_name("audit_oracle_applicability.py")
)
assert AUDIT_SPEC is not None and AUDIT_SPEC.loader is not None
AUDIT = importlib.util.module_from_spec(AUDIT_SPEC)
AUDIT_SPEC.loader.exec_module(AUDIT)


class FamilyHintsTest(unittest.TestCase):
    def test_related_encodings_share_family_but_not_state_identity(self) -> None:
        names = [
            "Maude_06/LengthOfFiniteLists_complete-noand.ari",
            "Maude_06/LengthOfFiniteLists_nokinds.ari",
            "Transformed_CSR_04/LengthOfFiniteLists_nosorts_iGM.ari",
        ]
        self.assertEqual(
            {FAMILY.instance_family(name) for name in names},
            {"LengthOfFiniteLists"},
        )


class OracleApplicabilityTest(unittest.TestCase):
    def test_compact_witness_rows_are_metadata_and_references_are_positive(self) -> None:
        with tempfile.TemporaryDirectory() as raw_directory:
            oracle = Path(raw_directory) / "oracle.jsonl"
            oracle.write_text(
                "\n".join(
                    [
                        json.dumps(
                            {
                                "schema": "ferrum.utility-guidance.witness.v1",
                                "witness_id": "witness",
                                "candidate": "exact-dp(hex=00)",
                            }
                        ),
                        json.dumps(
                            {
                                "problem_key": "state",
                                "prefer": [
                                    {
                                        "candidate_ref": "witness",
                                        "status": "solved",
                                    }
                                ],
                            }
                        ),
                    ]
                )
                + "\n"
            )
            records = AUDIT.load_oracle(oracle)
            self.assertEqual(set(records), {"state"})
            self.assertEqual(
                AUDIT.positive_atoms(records["state"]), ["exact-dp(hex=00)"]
            )

    def test_structural_alias_guides_a_differently_indented_input(self) -> None:
        cpf = "<input>\n  <trsInput/>\n</input>"
        structural = hashlib.sha256(
            AUDIT.compact_xml_for_key(cpf).encode("utf-8")
        ).hexdigest()
        records = {
            structural: {
                "problem_key": structural,
                "prefer": [{"candidate": "dp", "status": "solved"}],
            }
        }
        self.assertEqual(
            AUDIT.positive_atoms_for_input(records, "raw-key", cpf), ["dp"]
        )


class GapClassifierTest(unittest.TestCase):
    def test_distinguishes_checker_failure_from_timeout(self) -> None:
        with tempfile.TemporaryDirectory() as raw_directory:
            directory = Path(raw_directory)
            source = directory / "source.sqlite"
            campaign = directory / "campaign.sqlite"
            output = directory / "gaps.jsonl"
            summary = directory / "summary.json"
            sqlite3.connect(source).close()
            with sqlite3.connect(campaign) as connection:
                connection.executescript(
                    """
                    CREATE TABLE states(
                      raw_hash TEXT, source_problem_key TEXT,
                      problem_kind TEXT, level TEXT);
                    CREATE TABLE trials(
                      problem_key TEXT, candidate TEXT, outcome TEXT,
                      certification_status TEXT, timeout_ms INTEGER);
                    INSERT INTO states VALUES
                      ('raw-a', 'source-a', 'qdp', 'dependency-pair'),
                      ('raw-b', 'source-b', 'trs', 'top-level');
                    INSERT INTO trials VALUES
                      ('raw-a', 'size-change', 'solved', 'failed', 1000),
                      ('raw-b', 'path-order', 'timeout', 'not-positive', 1000);
                    """
                )
            subprocess.run(
                [
                    "python3",
                    str(CLASSIFIER),
                    "--source-db",
                    str(source),
                    "--campaign-sqlite",
                    str(campaign),
                    "--output",
                    str(output),
                    "--summary",
                    str(summary),
                ],
                check=True,
            )
            classifications = {
                row["raw_hash"]: row["classification"]
                for row in map(json.loads, output.read_text().splitlines())
            }
            self.assertEqual(classifications["raw-a"], "checker-rejected")
            self.assertEqual(
                classifications["raw-b"], "local-timeout-or-parameter-range"
            )


if __name__ == "__main__":
    unittest.main()
