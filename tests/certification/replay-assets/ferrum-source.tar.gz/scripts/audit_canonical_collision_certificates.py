#!/usr/bin/env python3
"""CeTA-audit nontrivial canonicalization of complete CPF certificates.

The row dataset contains proof fragments.  This audit therefore samples rows
that are backed by complete certified CPF files, transforms the complete source
certificate using the same symbol canonicalization as the canonical JSONL, and
checks the transformed complete certificate with CeTA.

The sampler focuses on canonical collision classes: at least two distinct
original CPF inputs standardize to the same canonical input.
"""

from __future__ import annotations

import argparse
import gzip
import hashlib
import json
import random
import subprocess
import sys
import time
import xml.etree.ElementTree as ET
from copy import deepcopy
from pathlib import Path
from typing import Any

from audit_standardized_subproof_rows import (
    input_rules,
    load_xml,
    local_name,
    quick_candidate_source,
    rewrite_symbol_names,
    rewrite_variables_globally,
    standardize_function_bijection,
    strip_result_prefix,
)


def sha256_text(text: str | None) -> str:
    return hashlib.sha256((text or "").encode()).hexdigest()


def open_input(path: Path):
    return gzip.open(path, "rt", encoding="utf-8") if path.suffix == ".gz" else path.open("r", encoding="utf-8")


def identity_mapping(mapping: dict[str, str]) -> bool:
    return all(old == new for old, new in mapping.items())


def row_is_certified_complete_cpf(row: dict[str, Any], source_cache: dict[str, bool]) -> bool:
    metadata = row.get("metadata") or {}
    source = row.get("source") or {}
    if metadata.get("certification") != "certified":
        return False
    if source.get("xml_format") not in {"cpf-or-xml", "cpf-or-xml-normalized"}:
        return False
    source_path = source.get("xml_path")
    if not source_path:
        return False
    return quick_candidate_source(source_path, source_cache)


def original_problem_identity(row: dict[str, Any]) -> str:
    metadata = row.get("metadata") or {}
    source = row.get("source") or {}
    material = {
        "category": metadata.get("category"),
        "benchmark": metadata.get("benchmark"),
        "source_path": source.get("xml_path"),
        "source_row_id": row.get("source_row_id"),
    }
    return hashlib.sha256(json.dumps(material, sort_keys=True, separators=(",", ":")).encode()).hexdigest()


def index_candidates(
    path: Path,
    max_rows: int | None = None,
    require_collision: bool = True,
) -> tuple[dict[str, list[dict[str, Any]]], dict[str, Any]]:
    groups: dict[str, list[dict[str, Any]]] = {}
    original_hashes: dict[str, set[str]] = {}
    source_cache: dict[str, bool] = {}
    counts: dict[str, int] = {
        "rows_seen": 0,
        "canonicalized_rows": 0,
        "certified_complete_cpf_rows": 0,
        "nontrivial_rows": 0,
    }
    with open_input(path) as handle:
        for line in handle:
            row = json.loads(line)
            counts["rows_seen"] += 1
            if max_rows is not None and counts["rows_seen"] > max_rows:
                break
            canon = row.get("canonicalization") or {}
            if canon.get("status") != "canonicalized":
                continue
            counts["canonicalized_rows"] += 1
            mapping = dict(canon.get("function_bijection") or {})
            if not mapping or identity_mapping(mapping):
                continue
            if not row_is_certified_complete_cpf(row, source_cache):
                continue
            counts["certified_complete_cpf_rows"] += 1
            problem_xml = row.get("input", {}).get("problem_xml")
            canonical_hash = sha256_text(problem_xml)
            original_hash = original_problem_identity(row)
            original_hashes.setdefault(canonical_hash, set()).add(original_hash)
            groups.setdefault(canonical_hash, []).append(row)
            counts["nontrivial_rows"] += 1
    collision_groups = {
        key: rows
        for key, rows in groups.items()
        if len(original_hashes.get(key, set())) >= 2
    }
    summary = {
        **counts,
        "candidate_groups": len(groups),
        "collision_groups": len(collision_groups),
        "candidate_rows_in_collision_groups": sum(len(rows) for rows in collision_groups.values()),
        "candidate_rows_sampled_from": sum(len(rows) for rows in (collision_groups if require_collision else groups).values()),
        "noncollision_sampling": not require_collision,
    }
    return (collision_groups if require_collision else groups), summary


def ceta_check(ceta: Path, xml: ET.Element, out_path: Path, timeout: int) -> tuple[bool, str, float]:
    out_path.write_bytes(ET.tostring(xml, encoding="utf-8", xml_declaration=True, short_empty_elements=True))
    start = time.monotonic()
    proc = subprocess.run(
        [str(ceta), str(out_path)],
        text=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        timeout=timeout,
    )
    elapsed = time.monotonic() - start
    return proc.returncode == 0 and "CERTIFIED" in proc.stdout, proc.stdout[-4000:], elapsed


def ceta_check_original(ceta: Path, source_path: str, out_path: Path, timeout: int) -> tuple[bool, str, float]:
    text = strip_result_prefix(Path(source_path).read_text(errors="replace"))
    starts = [idx for idx in (text.find("<?xml"), text.find("<certificationProblem")) if idx >= 0]
    if starts:
        text = text[min(starts) :]
    out_path.write_text(text, encoding="utf-8")
    start = time.monotonic()
    proc = subprocess.run(
        [str(ceta), str(out_path)],
        text=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        timeout=timeout,
    )
    elapsed = time.monotonic() - start
    return proc.returncode == 0 and "CERTIFIED" in proc.stdout, proc.stdout[-4000:], elapsed


def transform_complete_certificate(source_path: str, max_symbols: int) -> tuple[ET.Element, dict[str, str], int]:
    root = load_xml(Path(source_path))
    mapping = standardize_function_bijection(root, max_symbols)
    transformed = deepcopy(root)
    rewrite_symbol_names(transformed, mapping)
    rewrite_variables_globally(transformed)
    return transformed, mapping, len(input_rules(root))


def sample_collision_rows(groups: dict[str, list[dict[str, Any]]], count: int, seed: int) -> list[tuple[str, dict[str, Any]]]:
    rng = random.Random(seed)
    items = []
    for canonical_hash, rows in groups.items():
        for row in rows:
            items.append((canonical_hash, row))
    if len(items) <= count:
        rng.shuffle(items)
        return items
    return rng.sample(items, count)


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--jsonl", type=Path, default=Path("target/termcomp-proof-corpus/training/subproofs.cpf.canonical.jsonl.gz"))
    parser.add_argument("--rows", type=int, default=128)
    parser.add_argument("--seed", type=int, default=20260715)
    parser.add_argument("--ceta", type=Path, default=Path(".tools/ceta-relative-bounds"))
    parser.add_argument("--out-dir", type=Path, default=Path("target/termcomp-proof-corpus/canonical-collision-audit-128"))
    parser.add_argument("--max-symbols", type=int, default=0)
    parser.add_argument("--timeout", type=int, default=60)
    parser.add_argument("--require-original-ceta", action=argparse.BooleanOptionalAction, default=True)
    parser.add_argument(
        "--require-collision",
        action=argparse.BooleanOptionalAction,
        default=True,
        help="sample only canonical collision classes; disable to sample all nontrivial certified complete CPF rows",
    )
    args = parser.parse_args()

    args.out_dir.mkdir(parents=True, exist_ok=True)
    index_start = time.monotonic()
    groups, index_summary = index_candidates(args.jsonl, require_collision=args.require_collision)
    index_elapsed = time.monotonic() - index_start
    samples = sample_collision_rows(groups, args.rows, args.seed)

    results = []
    counts: dict[str, int] = {}
    transformed_dir = args.out_dir / "transformed"
    transformed_dir.mkdir(exist_ok=True)
    original_cache: dict[str, dict[str, Any]] = {}
    for index, (canonical_hash, row) in enumerate(samples, start=1):
        source_path = row["source"]["xml_path"]
        item: dict[str, Any] = {
            "sample_index": index,
            "row_id": row["id"],
            "source_row_id": row.get("source_row_id"),
            "canonical_problem_hash": canonical_hash,
            "source_path": source_path,
            "category": (row.get("metadata") or {}).get("category"),
            "benchmark": (row.get("metadata") or {}).get("benchmark"),
            "tool": (row.get("metadata") or {}).get("tool"),
            "processor_tag": (row.get("metadata") or {}).get("processor_tag"),
        }
        try:
            if args.require_original_ceta:
                if source_path not in original_cache:
                    ok, out, elapsed = ceta_check_original(
                        args.ceta,
                        source_path,
                        transformed_dir / f"sample-{index:04}.original.xml",
                        args.timeout,
                    )
                    original_cache[source_path] = {
                        "original_certified": ok,
                        "original_ceta_seconds": elapsed,
                        "original_ceta_tail": "" if ok else out,
                    }
                item.update(original_cache[source_path])
                if not item["original_certified"]:
                    item["status"] = "original_not_ceta_certified"
                    item["ceta_tail"] = item["original_ceta_tail"]
                    raise StopIteration
            xml, mapping, rule_count = transform_complete_certificate(source_path, args.max_symbols)
            item["mapping"] = mapping
            item["function_symbols"] = len(mapping)
            item["rule_count"] = rule_count
            item["nonidentity_mapping"] = not identity_mapping(mapping)
            target = transformed_dir / f"sample-{index:04}.canonical.xml"
            ok, out, elapsed = ceta_check(args.ceta, xml, target, args.timeout)
            item["status"] = "certified" if ok else "cert_failed"
            item["canonical_ceta_seconds"] = elapsed
            item["transformed_path"] = str(target)
            item["ceta_tail"] = "" if ok else out
        except Exception as exc:  # noqa: BLE001 - audit must record all failures.
            if not isinstance(exc, StopIteration):
                item["status"] = "error"
                item["error_type"] = type(exc).__name__
                item["error"] = str(exc)
        counts[item["status"]] = counts.get(item["status"], 0) + 1
        results.append(item)
        print(
            json.dumps(
                {
                    "event": "sample_done",
                    "sample_index": index,
                    "status": item["status"],
                    "category": item.get("category"),
                    "seconds": item.get("canonical_ceta_seconds"),
                },
                sort_keys=True,
            ),
            flush=True,
        )

    ceta_times = [float(item["canonical_ceta_seconds"]) for item in results if "canonical_ceta_seconds" in item]
    original_times = [float(item["original_ceta_seconds"]) for item in results if "original_ceta_seconds" in item]
    def stats(values: list[float]) -> dict[str, float]:
        if not values:
            return {}
        sorted_values = sorted(values)
        return {
            "count": len(values),
            "total_seconds": sum(values),
            "mean_seconds": sum(values) / len(values),
            "p50_seconds": sorted_values[len(values) // 2],
            "max_seconds": sorted_values[-1],
        }

    full_rows = index_summary["candidate_rows_in_collision_groups"]
    mean = (sum(ceta_times) / len(ceta_times)) if ceta_times else 0.0
    summary = {
        "jsonl": str(args.jsonl),
        "rows_requested": args.rows,
        "rows_sampled": len(samples),
        "seed": args.seed,
        "require_collision": args.require_collision,
        "max_exact_symbols": args.max_symbols,
        "index_seconds": index_elapsed,
        "index": index_summary,
        "counts": dict(sorted(counts.items())),
        "canonical_ceta": stats(ceta_times),
        "original_ceta": stats(original_times),
        "estimated_full_audit": {
            "rows": full_rows,
            "serial_canonical_ceta_seconds": full_rows * mean,
            "parallel_64_canonical_ceta_seconds": (full_rows * mean) / 64 if mean else 0.0,
            "parallel_128_canonical_ceta_seconds": (full_rows * mean) / 128 if mean else 0.0,
        },
    }
    (args.out_dir / "sample-results.jsonl").write_text("\n".join(json.dumps(item, sort_keys=True) for item in results) + "\n")
    (args.out_dir / "summary.json").write_text(json.dumps(summary, indent=2, sort_keys=True))
    print(json.dumps(summary, sort_keys=True), flush=True)
    return 0 if counts.get("cert_failed", 0) == 0 and counts.get("error", 0) == 0 else 1


if __name__ == "__main__":
    sys.setrecursionlimit(max(sys.getrecursionlimit(), 200_000))
    raise SystemExit(main())
