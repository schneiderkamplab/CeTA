#!/usr/bin/env python3

import importlib.util
import json
from pathlib import Path
import subprocess
import tempfile
import unittest
from unittest import mock
import xml.etree.ElementTree as ET

from extract_exact_fragment_training_data import (
    child_input_for,
    inner_input,
    iter_exact_rows,
    normalize_root,
)


SCRIPT = Path(__file__).with_name("extract_local_cpf_oracle_events.py")
SPEC = importlib.util.spec_from_file_location("extract_local_cpf_oracle_events", SCRIPT)
assert SPEC is not None and SPEC.loader is not None
EXTRACT = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(EXTRACT)


class CsrDependencyPairEvidenceTest(unittest.TestCase):
    def test_q_witness_freezes_complete_source_before_runtime_rebinding(self):
        source = '<dpInput><trs><rules/></trs><dps><rules/></dps><minimal>true</minimal><strategy><innermostLhss><funapp><name>source_only</name><var>x</var></funapp></innermostLhss></strategy></dpInput>'
        row = dict(id='q-step', input=dict(problem_xml=source),
                   metadata=dict(processor_tag='innermostLhssRemovalProc'),
                   output_xml='<innermostLhssRemovalProc><innermostLhss/><dpProof><pIsEmpty/></dpProof></innermostLhssRemovalProc>')
        EXTRACT.freeze_portable_atoms_before_runtime_rebind([row])
        frozen = EXTRACT.strategy_atom(row)
        payload, bound_source = json.loads(bytes.fromhex(frozen.split('hex=', 1)[1][:-1]))
        self.assertIn('source_only', bound_source)
        self.assertIn('innermostLhss', payload)
        row['input']['problem_xml'] = source.replace('source_only', 'live_only')
        self.assertEqual(EXTRACT.strategy_atom(row), frozen)

    def test_standalone_relative_dp_wrapper_keeps_both_rule_roles(self):
        rule = '<rule><lhs><funapp><name>{}</name></funapp></lhs><rhs><var>x</var></rhs></rule>'
        root = ET.fromstring('''<certificationProblem><input><relativeDpInput>
          <trs><rules>{}</rules></trs><strictRules><rules>{}</rules></strictRules>
          <dps><rules/></dps><weakDps><rules>{}</rules></weakDps><minimal>false</minimal>
          </relativeDpInput></input><proof><relativeDpProof><dpProof><pIsEmpty/>
          </dpProof></relativeDpProof></proof></certificationProblem>'''.format(
              rule.format('weak'), rule.format('strict'), rule.format('pair')))
        source = dict(proof_url='local://test', normalizer=None,
                      source_kind='local-certified-cpf', xml_path='proof.xml',
                      xml_format='3.0', year=2026, category='DP', benchmark='generic',
                      tool='Ferrum', result='YES', certification='certified')
        rows, reasons = iter_exact_rows(source, root)
        self.assertEqual(len(rows), 1, reasons)
        state = ET.fromstring(rows[0]['input']['problem_xml']).find('dpInput')
        self.assertEqual(len(state.findall('trs/rules/rule')), 2)
        self.assertEqual(len(state.findall('dps/rules/rule')), 1)
        self.assertEqual(len(state.findall('ferrumWeakDps/rules/rule')), 1)
        self.assertEqual(state.findtext('ferrumDpStateContext/strictRules/rules/rule/funapp/name'), 'strict')
        self.assertEqual(state.findtext('minimal'), 'false')

    def test_omitted_probe_input_requires_exact_file_digest(self):
        import hashlib
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / 'state.cpf'
            cpf = '<dpInput><minimal>false</minimal><usableRules><rules/></usableRules></dpInput>'
            path.write_text(cpf)
            event = dict(problem_id=str(path), input=dict(cpf=None, content_addressed=True,
                         problem_key=hashlib.sha256(cpf.encode()).hexdigest()))
            EXTRACT.hydrate_content_addressed_probe_input(event)
            self.assertEqual(event['input']['cpf'], cpf)
            event['input']['cpf'] = None
            event['input']['problem_key'] = 'different-child'
            EXTRACT.hydrate_content_addressed_probe_input(event)
            self.assertIsNone(event['input']['cpf'])

    def test_standalone_improved_dp_wrapper_preserves_obligation(self):
        root = ET.fromstring('''<certificationProblem><input><csrImprovedDpInput>
          <trs><rules/></trs><dps><rules/></dps><usableRules><rules/></usableRules>
          <strategy><contextSensitive><replacementMapEntry><name>f</name>
          <arity>1</arity><position>1</position></replacementMapEntry>
          </contextSensitive></strategy><minimal>false</minimal>
          <unhidingSymbol><name>u</name></unhidingSymbol>
          </csrImprovedDpInput></input><proof><csrImprovedDpProof>
          <csrDpProof><pIsEmpty/></csrDpProof></csrImprovedDpProof></proof>
          </certificationProblem>''')
        source = dict(proof_url='local://standalone-test', normalizer=None,
                      source_kind='local-certified-cpf', xml_path='proof.xml',
                      xml_format='4.0', year=2026, category='CSR-DP',
                      benchmark='generic', tool='Ferrum', result='YES', certification='certified')
        rows, reasons = iter_exact_rows(source, root)
        self.assertEqual(len(rows), 1, reasons)
        state = ET.fromstring(rows[0]['input']['problem_xml']).find('dpInput')
        self.assertEqual(state.findtext('minimal'), 'false')
        self.assertIsNotNone(state.find('usableRules'))
        self.assertEqual(state.findtext('strategy/contextSensitive/replacementMapEntry/position'), '1')
        self.assertEqual(state.findtext('unhidingSymbol/name'), 'u')
        self.assertEqual(state.findtext('ferrumCsrDpContext/construction'), 'improved')
        # A mismatched ordinary input must not be silently relabeled CSR.
        root.find('input/csrImprovedDpInput').tag = 'dpInput'
        rows, reasons = iter_exact_rows(source, root)
        self.assertFalse(rows)
        self.assertIn('csrImprovedDpProof_missing_typed_input_or_proof', reasons)

    def test_runtime_shard_filter_accepts_tpdb_prefixed_manifest_paths(self):
        event = Path('target/run/TRS_Standard/Group/sharp_3.6/processor-events.jsonl')
        self.assertTrue(EXTRACT.runtime_event_path_matches_problems(
            event, {'../TPDB-ARI/TRS_Standard/Group/#3.6.ari'}))
        self.assertFalse(EXTRACT.runtime_event_path_matches_problems(
            event, {'../TPDB-ARI/TRS_Standard/Group/#3.7.ari'}))

    def test_reduction_pair_model_hint_ignores_deletion_indices_but_keeps_model(self):
        fragment = '''<interpretation><type><matrixInterpretation>
          <domain><naturals/></domain><dimension>1</dimension><strictDimension>1</strictDimension>
          </matrixInterpretation></type><interpret><name>f</name><arity>0</arity>
          <vector><integer>2</integer></vector></interpret></interpretation>'''
        payload = ['redPairProc', fragment, [7], '<dps/>', '<usableRules/>']
        atom = 'exact-red-pair(hex=' + json.dumps(payload).encode().hex() + ')'
        models = EXTRACT.reduction_pair_model_atoms(atom)
        self.assertEqual(len(models), 1)
        self.assertTrue(models[0].startswith('exact-matrix('))
        self.assertEqual(json.loads(bytes.fromhex(models[0].split('hex=')[1][:-1])), [['f', [2], []]])
        row = {'metadata': {'processor_tag': 'redPairProc', 'reduction_pair_model_hint': True,
                            'strategy_atom': models[0]}, 'output_xml': fragment}
        self.assertEqual(EXTRACT.strategy_atom(row), models[0])
        self.assertEqual(EXTRACT.reduction_pair_model_atoms('exact-red-pair(hex=00)'), [])
        self.assertEqual(EXTRACT.reduction_pair_model_atoms('exact-dp-proof(hex=00)'), [])

    def test_no_instantiation_replaces_pairs_and_clears_minimality(self):
        rule = '<rule><funapp><name>f</name><var>x</var></funapp><var>x</var></rule>'
        instance = rule.replace('<var>x</var>', '<funapp><name>a</name></funapp>')
        current = ET.fromstring('<input><dpInput><trs><rules/></trs><dps><rules>' + rule +
                                '</rules></dps><minimal>true</minimal></dpInput></input>')
        step = ET.fromstring('<instantiationProc><dps><rules>' + instance +
                             '</rules></dps><dpNonterminationProof><loop/></dpNonterminationProof></instantiationProc>')
        child, error = child_input_for(step, step.find('dpNonterminationProof'), current)
        self.assertIsNone(error)
        self.assertEqual(len(child.findall('dpInput/dps/rules/rule')), 1)
        self.assertIsNone(child.find('dpInput/dps/rules/rule/var'))
        self.assertEqual(child.findtext('dpInput/minimal'), 'false')

    def test_contextless_bridge_preserves_explicit_empty_q(self):
        live = '<dpInput><trs><rules/></trs><dps><rules/></dps><ferrumDpStateContext><innermostLhss/></ferrumDpStateContext></dpInput>'
        with mock.patch.object(EXTRACT, 'runtime_state_signature', return_value=live):
            result = ET.fromstring(EXTRACT.contextless_runtime_state_signature(live))
        self.assertIsNotNone(result.find('strategy/innermostLhss'))
        self.assertEqual(len(result.findall('strategy/innermostLhss')), 1)

    def test_contextless_bridge_keeps_q_reintroduced_by_canonicalizer(self):
        q = '<innermostLhss><funapp><name>canonical</name></funapp></innermostLhss>'
        live = '<dpInput><trs><rules/></trs><dps><rules/></dps><ferrumDpStateContext>' + q + '</ferrumDpStateContext></dpInput>'
        with mock.patch.object(EXTRACT, 'runtime_state_signature', return_value=live):
            result = ET.fromstring(EXTRACT.contextless_runtime_state_signature(live))
        self.assertEqual(result.findtext('strategy/innermostLhss/funapp/name'), 'canonical')
        self.assertIsNone(result.find('ferrumDpStateContext'))

    def test_nontermination_container_preserves_causal_parent_binding(self):
        problem = '<dpInput><trs><rules/></trs><dps><rules/></dps><minimal>true</minimal></dpInput>'
        identity = 'TRS_Standard/Test/Example.ari'
        row = {'metadata': {'processor_tag': 'loop', 'strategy_atom': 'exact-dp-loop(hex=00)',
                            'path': ['dpRuleRemoval', 'dpNonterminationProof', 'loop']},
               'input': {'problem_xml': problem}}
        keys = {(EXTRACT.CAUSAL_CHILD_CONTEXT_PREFIX + 'dpRuleRemoval\0' + identity,
                 EXTRACT.contextless_runtime_state_signature(problem)): {'actual-child'}}
        with tempfile.TemporaryDirectory() as directory:
            proof = Path(directory)/'TRS_Standard/Test/Example/proof.cpf.xml'
            proof.parent.mkdir(parents=True)
            proof.write_text('unused')
            EXTRACT.attach_runtime_state_keys([row], proof, identity, keys, [])
        self.assertEqual(row['metadata']['runtime_raw_problem_key'], 'actual-child')

    def test_trs_nontermination_rule_removal_is_one_boundary(self):
        first = '<rule><funapp><name>f</name></funapp><var>x</var></rule>'
        second = '<rule><funapp><name>a</name></funapp><funapp><name>b</name></funapp></rule>'
        source = '<input><trsInput><trs><rules>' + first + second + '</rules></trs></trsInput></input>'
        step = '<ruleRemoval><trs><rules>' + second + '</rules></trs><trsNonterminationProof><loop/></trsNonterminationProof></ruleRemoval>'
        atom = EXTRACT.strategy_atom({'metadata': {'processor_tag': 'ruleRemoval'},
                                     'input': {'problem_xml': source}, 'output_xml': step})
        self.assertTrue(atom.startswith('exact-trs-no-rule-removal('))
        encoded_source, residual = json.loads(bytes.fromhex(atom.split('hex=')[1][:-1]))
        self.assertEqual(encoded_source, source)
        self.assertEqual(len(ET.fromstring(residual).findall('.//rule')), 1)
        self.assertNotIn('Proof', residual)

    def test_nontermination_uncurry_keeps_the_explicit_residual(self):
        current = ET.fromstring('<input><trsInput><trs><rules/></trs>'
                                '<strategy><full/></strategy></trsInput></input>')
        step = ET.fromstring('<uncurry><uncurryInformation/><trs><rules><rule>'
                            '<funapp><name>fresh</name></funapp><funapp><name>fresh</name></funapp>'
                            '</rule></rules></trs><trsNonterminationProof><loop/>'
                            '</trsNonterminationProof></uncurry>')
        child, error = child_input_for(step, step.find('trsNonterminationProof'), current)
        self.assertIsNone(error)
        self.assertEqual(child.findtext('.//rule/funapp/name'), 'fresh')
        self.assertIsNotNone(child.find('.//strategy/full'))

    def test_direct_forward_policy_keeps_the_native_cpf_rule(self) -> None:
        self.assertEqual(EXTRACT.cpf_processor_tag_for_runtime('forwardInstantiationProcDirect'),
                         'forwardInstantiationProc')
        self.assertEqual(EXTRACT.cpf_processor_tag_for_runtime('narrowingProc'), 'narrowingProc')

    def test_dp_switch_innermost_changes_strategy_and_uses_active_R(self):
        rule = '<rule><funapp><name>f</name><var>x</var></funapp><var>x</var></rule>'
        extra = rule.replace('<name>f</name>', '<name>g</name>')
        current = ET.fromstring('<input><dpInput><trs><rules>' + rule + extra
            + '</rules></trs><dps><rules/></dps><usableRules><rules>' + rule
            + '</rules></usableRules><strategy><full/></strategy><minimal>true</minimal></dpInput></input>')
        step = ET.fromstring('<switchInnermostProc><wcrProof/><dpProof><pIsEmpty/></dpProof></switchInnermostProc>')
        child, error = child_input_for(step, step.find('dpProof'), current)
        self.assertIsNone(error)
        inner = inner_input(child)
        self.assertEqual(inner.findtext('strategy/innermost/nfs'), 'true')
        self.assertIsNone(inner.find('strategy/full'))
        self.assertIsNone(inner.find('usableRules'))
        self.assertEqual(len(inner.findall('trs/rules/rule')), 1)
        self.assertEqual(inner.findtext('ferrumDpStateContext/rewriteStrategy'), 'innermost')

    def test_finite_labeling_does_not_copy_unlabeled_active_rules(self):
        old = '<rules><rule><funapp><name>f</name><var>x</var></funapp><var>x</var></rule></rules>'
        labeled = old.replace('<name>f</name>', '<labeledSymbol><name>f</name><numberLabel><number>0</number></numberLabel></labeledSymbol>')
        current = ET.fromstring('<input><dpInput><trs>' + old + '</trs><dps><rules/></dps><usableRules>'
                                + old + '</usableRules><minimal>true</minimal></dpInput></input>')
        step = ET.fromstring('<semlabProc><model/><dps><rules/></dps><trs>' + labeled
                             + '</trs><dpProof><pIsEmpty/></dpProof></semlabProc>')
        child, error = child_input_for(step, step.find('dpProof'), current)
        self.assertIsNone(error)
        self.assertIsNone(inner_input(child).find('usableRules'))
        self.assertIsNotNone(inner_input(child).find('.//trs/rules/rule/funapp/labeledSymbol'))

    def test_finite_model_conditional_extraction_and_arity_rejection(self):
        branch = '<arithFunction><natural>1</natural></arithFunction>'
        parsed = EXTRACT._semantic_arithmetic_function(ET.fromstring(
            '<arithFunction><ifEqual>' + branch * 4 + '</ifEqual></arithFunction>'))
        self.assertEqual(parsed, {'IfEqual': [{'Constant': 1}] * 4})
        self.assertIsNone(EXTRACT._semantic_arithmetic_function(ET.fromstring(
            '<arithFunction><ifEqual>' + branch * 3 + '</ifEqual></arithFunction>')))

    def test_general_red_pair_membership_is_alpha_invariant(self):
        rule = '<rule><funapp><name>F</name><var>x</var></funapp><funapp><name>G</name><var>x</var></funapp></rule>'
        renamed = rule.replace('<var>x</var>', '<var>freshened</var>')
        row = dict(metadata={'processor_tag': 'generalRedPairProc'},
            input={'problem_xml': f'<input><dpInput><trs><rules/></trs><dps><rules>{renamed}</rules></dps></dpInput></input>'},
            output_xml=f'<generalRedPairProc><interpretation/><strict><rules>{rule}</rules></strict><bound><rules>{rule}</rules></bound><dpProof><pIsEmpty/></dpProof></generalRedPairProc>')
        atom = EXTRACT.strategy_atom(row)
        self.assertTrue(atom.startswith('exact-general-red-pair('))
        payload = json.loads(bytes.fromhex(atom.removeprefix('exact-general-red-pair(hex=').removesuffix(')')))
        self.assertEqual(payload[1:3], [[0], [0]])
        self.assertEqual(payload[4], row['input']['problem_xml'])

    def test_q_increase_is_a_nontermination_only_union_boundary(self):
        current = ET.fromstring('<input><dpInput><trs><rules/></trs><dps><rules/></dps>'
            '<minimal>true</minimal><ferrumDpStateContext><innermostLhss>'
            '<funapp><name>old</name></funapp></innermostLhss></ferrumDpStateContext></dpInput></input>')
        step = ET.fromstring('<innermostLhssIncreaseProc><innermostLhss><funapp><name>new</name>'
            '</funapp></innermostLhss><dpNonterminationProof><loop/></dpNonterminationProof>'
            '</innermostLhssIncreaseProc>')
        child, error = child_input_for(step, step.find('dpNonterminationProof'), current)
        self.assertIsNone(error)
        self.assertEqual(child.find('dpInput/minimal').text, 'false')
        self.assertEqual([x.text for x in child.findall('dpInput/ferrumDpStateContext/innermostLhss/funapp/name')], ['old', 'new'])
        row = dict(metadata={'processor_tag': 'innermostLhssIncreaseProc'},
                   input={'problem_xml': ET.tostring(current, encoding='unicode')},
                   output_xml=ET.tostring(step, encoding='unicode'))
        atom = EXTRACT.strategy_atom(row)
        payload = json.loads(bytes.fromhex(atom.removeprefix('exact-dp-transform(hex=').removesuffix(')')))
        self.assertNotIn('dpNonterminationProof', payload[1])

    def test_complex_constant_mapping_requires_complete_pair_coverage(self):
        rule = '<rule><funapp><name>F</name><var>x</var></funapp><funapp><name>G</name><var>x</var></funapp></rule>'
        current = ET.fromstring(f'<input><dpInput><trs><rules/></trs><dps><rules>{rule}</rules></dps><minimal>true</minimal></dpInput></input>')
        step = ET.fromstring(f'<complexConstantRemovalProc><funapp><name>c</name></funapp><ruleMap><ruleMapEntry>{rule}{rule}</ruleMapEntry></ruleMap><dpProof><pIsEmpty/></dpProof></complexConstantRemovalProc>')
        child, error = child_input_for(step, step.find('dpProof'), current)
        self.assertIsNone(error)
        self.assertEqual(len(child.findall('dpInput/dps/rules/rule')), 1)
        step.find('ruleMap').clear()
        child, error = child_input_for(step, step.find('dpProof'), current)
        self.assertIsNone(child)
        self.assertIn('incomplete_mapping', error)

    def test_full_gm04_exposes_source_and_non_top_administrative_rules(self):
        root = ET.fromstring('''<certificationProblem><input><trsInput><trs><rules>
          <rule><funapp><name>wrapper</name><var>x</var></funapp><var>x</var></rule>
          <rule><funapp><name>worker</name><var>x</var></funapp><var>x</var></rule>
          </rules></trs></trsInput></input><proof><trsTerminationProof>
          <gm04CompleteFullTransformation><topSymbol><name>wrapper</name></topSymbol>
          <sourceTrs><rules/></sourceTrs><sourceReplacementMap><contextSensitive/>
          </sourceReplacementMap><sourceProof><csrImprovedDependencyPairs>
          <dps><rules/></dps><csrDpProof><pIsEmpty/></csrDpProof>
          </csrImprovedDependencyPairs></sourceProof><administrativeProof>
          <dpTrans><dps><rules/></dps><dpProof><pIsEmpty/></dpProof></dpTrans>
          </administrativeProof></gm04CompleteFullTransformation>
          </trsTerminationProof></proof></certificationProblem>''')
        source = dict(proof_url='local://test', normalizer=None,
                      source_kind='local-certified-cpf', xml_path='proof.xml',
                      xml_format='4.0', year=2026, category='TRS_Standard',
                      benchmark='generic', tool='Ferrum', result='YES',
                      certification='certified')
        rows, reasons = iter_exact_rows(source, root)
        by_tag = {row['metadata']['processor_tag']: row for row in rows}
        self.assertEqual(EXTRACT.strategy_atom(by_tag['gm04CompleteFullTransformation']),
                         'gm04-inverse-csr-full')
        self.assertIn('contextSensitive', by_tag['csrImprovedDependencyPairs']['input']['problem_xml'])
        admin = by_tag['dpTrans']['input']['problem_xml']
        self.assertIn('worker', admin)
        self.assertNotIn('wrapper', admin)
        self.assertEqual(by_tag['dpTrans']['metadata']['causal_parent_branch_index'], 1)
        self.assertFalse(reasons)

    def test_contextless_binding_strips_provenance_before_canonicalizing_but_keeps_q(self):
        source = (
            '<dpInput><trs><rules/></trs><dps><rules/></dps><minimal>true</minimal>'
            '<ferrumDpStateContext><pairSourceRules><sourceRule>7</sourceRule>'
            '</pairSourceRules><innermostLhss><funapp><name>q</name></funapp>'
            '</innermostLhss></ferrumDpStateContext></dpInput>'
        )
        with mock.patch.object(EXTRACT, 'FERRUM_CANONICALIZER', 'test-canonicalizer'), \
             mock.patch.object(EXTRACT, 'canonicalize_with_ferrum', side_effect=lambda xml, *_: xml) as canonicalize:
            result = EXTRACT.contextless_runtime_state_signature(source)
        self.assertNotIn('ferrumDpStateContext', canonicalize.call_args.args[0])
        self.assertIn('<name>q</name>', canonicalize.call_args.args[0])
        self.assertIn('<minimal>true</minimal>', result)
        self.assertIn('<innermostLhss>', result)
        self.assertNotIn('sourceRule', result)

    def test_native_root_labeling_is_not_misread_as_a_finite_model(self) -> None:
        row = {
            "metadata": {"processor_tag": "semlabProc", "strategy_atom": None},
            "input": {"problem_xml": "<input><dpInput/></input>"},
            "output_xml": (
                "<semlabProc><model><rootLabeling/></model>"
                "<dps><rules/></dps><trs><rules/></trs>"
                "<dpProof><pIsEmpty/></dpProof></semlabProc>"
            ),
        }

        self.assertEqual(EXTRACT.strategy_atom(row), "root-labeling")

    def test_native_root_labeling_preserves_minimality_in_residual(self) -> None:
        current = ET.fromstring(
            "<input><dpInput><trs><rules><rule/></rules></trs>"
            "<dps><rules><rule/></rules></dps><minimal>true</minimal>"
            "</dpInput></input>"
        )
        processor = ET.fromstring(
            "<semlabProc><model><rootLabeling/></model>"
            "<dps><rules><rule/></rules></dps>"
            "<trs><rules><rule/></rules></trs>"
            "<dpProof><pIsEmpty/></dpProof></semlabProc>"
        )

        residual, error = child_input_for(
            processor, processor.find("dpProof"), current
        )

        self.assertIsNone(error)
        self.assertIsNotNone(residual)
        self.assertEqual(inner_input(residual).findtext("minimal"), "true")

    def test_interpretation_symbol_keeps_nested_root_and_number_labels(self) -> None:
        interpretation = ET.fromstring(
            "<interpret><labeledSymbol><labeledSymbol><sharp><name>f</name>"
            "</sharp><symbolLabel><name>a</name><name>f</name></symbolLabel>"
            "</labeledSymbol><numberLabel><number>1</number></numberLabel>"
            "</labeledSymbol><arity>2</arity></interpret>"
        )
        root = "__ferrum_rl__6623__61_66"
        expected = f"__ferrum_sl__{root.encode().hex()}__1"
        self.assertEqual(EXTRACT.interpretation_symbol_name(interpretation), expected)

    def test_identity_graph_wrapper_is_flattened_to_its_continuation(self) -> None:
        source = (
            "<dpInput><trs><rules/></trs><dps><rules>"
            "<rule><var>x</var><var>x</var></rule>"
            "</rules></dps><minimal>true</minimal></dpInput>"
        )
        atom = "exact-graph(hex=" + json.dumps(
            [source, [[[0], True]]], separators=(",", ":")
        ).encode().hex() + ")"
        graph = {
            "id": "graph-row",
            "metadata": {
                "processor_tag": "depGraphProc",
                "strategy_atom": atom,
                "runtime_raw_problem_key": "live-state",
                "path": ["proof", "dpProof", "depGraphProc"],
            },
            "input": {"problem_xml": source},
            "output_xml": "<depGraphProc/>",
        }
        child = {
            "id": "child-row",
            "metadata": {
                "processor_tag": "redPairProc",
                "strategy_atom": "exact-red-pair(hex=00)",
                "runtime_raw_problem_key": "archived-child",
                "path": [
                    "proof",
                    "dpProof",
                    "depGraphProc",
                    "component",
                    "dpProof",
                    "redPairProc",
                ],
            },
            "input": {"problem_xml": source},
            "output_xml": "<redPairProc/>",
        }
        rows = [graph, child]

        self.assertEqual(EXTRACT.flatten_identity_graph_wrappers(rows), 1)
        self.assertTrue(graph["metadata"]["identity_graph_wrapper"])
        self.assertTrue(
            any(
                row["id"] == "child-row"
                and row["metadata"].get("runtime_raw_problem_key") == "live-state"
                for row in rows
            )
        )

    def test_graph_with_a_proper_component_is_not_flattened(self) -> None:
        source = (
            "<dpInput><trs><rules/></trs><dps><rules>"
            "<rule><var>x</var><var>x</var></rule>"
            "<rule><var>y</var><var>y</var></rule>"
            "</rules></dps><minimal>true</minimal></dpInput>"
        )
        atom = "exact-graph(hex=" + json.dumps(
            [source, [[[0], True]]], separators=(",", ":")
        ).encode().hex() + ")"
        self.assertFalse(EXTRACT.exact_graph_is_identity_wrapper(atom))

    def test_runtime_signature_survives_rejected_synthetic_child(self) -> None:
        problem = "<dpInput><trs><rules/></trs><dps><rules/></dps><minimal>true</minimal></dpInput>"
        previous = EXTRACT.FERRUM_CANONICALIZER
        EXTRACT.FERRUM_CANONICALIZER = Path("/nonexistent/ferrum")
        try:
            with mock.patch.object(
                EXTRACT,
                "canonicalize_with_ferrum",
                side_effect=subprocess.CalledProcessError(1, ["ferrum"]),
            ):
                signature = EXTRACT.runtime_state_signature(problem)
        finally:
            EXTRACT.FERRUM_CANONICALIZER = previous

        self.assertIsNotNone(signature)
        self.assertIn("<dpInput>", signature)

    def test_problem_selection_accepts_absolute_and_suite_relative_identity(self) -> None:
        wanted = {
            "/work/dfm/festschrift/TPDB-ARI/TRS_Innermost/AG01_innermost/#4.26.ari"
        }
        self.assertEqual(
            EXTRACT.problem_selection_matches("AG01_innermost/#4.26.ari", wanted),
            next(iter(wanted)),
        )

    def test_problem_selection_does_not_suffix_match_applicative_peer(self) -> None:
        wanted = {"TRS_Innermost/AG01_innermost/#4.26.ari"}
        self.assertIsNone(
            EXTRACT.problem_selection_matches(
                "Applicative_AG01_innermost/#4.26.ari", wanted
            )
        )

    def test_runtime_trace_filter_skips_unselected_termcomp_problem(self) -> None:
        selected = {"TRS_Standard/AProVE_04/JFP_Ex31.ari"}
        self.assertTrue(
            EXTRACT.runtime_event_path_matches_problems(
                Path("run/TRS_Standard/AProVE_04/JFP_Ex31/processor-events.jsonl"),
                selected,
            )
        )
        self.assertFalse(
            EXTRACT.runtime_event_path_matches_problems(
                Path("run/TRS_Standard/MNZ_10/labelled/processor-events.jsonl"),
                selected,
            )
        )
        self.assertTrue(
            EXTRACT.runtime_event_path_matches_problems(
                Path("flattened/events.jsonl"), selected
            )
        )

    def test_flattened_termcomp_artifact_maps_to_requested_tpdb_path(self) -> None:
        wanted = {"TRS_Standard/AProVE_04/JFP_Ex31.ari"}
        proof = Path(
            "/proofs/TRS_Standard_AProVE_04_JFP_Ex31.ari/benchmark_161__solver_2.txt"
        )
        self.assertEqual(
            EXTRACT.flattened_artifact_problem_identity(proof, wanted),
            "TRS_Standard/AProVE_04/JFP_Ex31.ari",
        )

    def test_flattened_sharp_artifact_maps_to_hash_named_tpdb_path(self) -> None:
        wanted = {"TRS_Standard/AG01/#3.15.ari"}
        proof = Path(
            "/proofs/TRS_Standard_AG01_sharp_3.15.ari/benchmark_4__solver_2.txt"
        )
        self.assertEqual(
            EXTRACT.flattened_artifact_problem_identity(proof, wanted),
            "TRS_Standard/AG01/#3.15.ari",
        )

    def test_detached_double_underscore_cpf_maps_to_requested_tpdb_path(self) -> None:
        wanted = {
            "TRS_Standard/Transformed_CSR_04/"
            "LengthOfFiniteLists_complete-noand_FR.ari"
        }
        proof = Path(
            "/converted/Transformed_CSR_04__"
            "LengthOfFiniteLists_complete-noand_FR.cpf.xml"
        )
        self.assertEqual(
            EXTRACT.flattened_artifact_problem_identity(proof, wanted),
            next(iter(wanted)),
        )

    def test_manual_benchmark_directory_maps_to_requested_tpdb_path(self) -> None:
        wanted = {
            "TRS_Standard/Transformed_CSR_04/OvConsOS_complete-noand_Z.ari"
        }
        proof = Path(
            "/manual/strict/OvConsOS_complete-noand_Z/proof.cpf.xml"
        )
        self.assertEqual(
            EXTRACT.flattened_artifact_problem_identity(proof, wanted),
            next(iter(wanted)),
        )

    def test_manual_benchmark_directory_rejects_ambiguous_basename(self) -> None:
        wanted = {
            "TRS_Standard/Family_A/shared.ari",
            "TRS_Standard/Family_B/shared.ari",
        }
        proof = Path("/manual/strict/shared.ari/proof.cpf.xml")
        self.assertIsNone(
            EXTRACT.flattened_artifact_problem_identity(proof, wanted)
        )

    def test_sanitized_sharp_runtime_path_matches_hash_named_problem(self) -> None:
        self.assertTrue(
            EXTRACT.runtime_event_path_matches_problems(
                Path(
                    "run/TRS_Standard/AG01/sharp_3.15/processor-events.jsonl"
                ),
                {"TRS_Standard/AG01/#3.15.ari"},
            )
        )

    def test_cpf_instantiations_replay_as_deterministic_candidates(self) -> None:
        self.assertEqual(
            EXTRACT.DIRECT_ATOMS["instantiationProc"],
            "instantiate(max-per-pair=2,candidate=0)",
        )
        self.assertEqual(
            EXTRACT.DIRECT_ATOMS["forwardInstantiationProc"],
            "forward-instantiate(max-per-pair=2,candidate=0)",
        )
        self.assertEqual(
            EXTRACT.DIRECT_ATOMS["csrForwardInstantiationProc"],
            "forward-instantiate(max-per-pair=2,candidate=0)",
        )

    def test_exact_normalization_expands_rule_table_references(self) -> None:
        root = ET.fromstring("""
          <certificationProblem>
            <input><dpInput><trs><rules><ruleIndex>7</ruleIndex></rules></trs>
              <dps><rules><ruleIndex>7</ruleIndex></rules></dps></dpInput></input>
            <proof><dpProof><narrowingProc><ruleIndex>7</ruleIndex>
              <narrowings><rules><ruleIndex>7</ruleIndex></rules></narrowings>
              <dpProof><pIsEmpty/></dpProof></narrowingProc></dpProof></proof>
            <lookupTables><ruleTable><indexToRule><index>7</index>
              <rule><funapp><name>f</name><var>x</var></funapp><var>x</var></rule>
            </indexToRule></ruleTable></lookupTables>
          </certificationProblem>
        """)

        normalized = normalize_root(root)

        self.assertEqual(len(normalized.findall(".//ruleIndex")), 0)
        narrowing = normalized.find("proof/dpProof/narrowingProc")
        self.assertIsNotNone(narrowing)
        self.assertIsNotNone(narrowing.find("rule"))
        self.assertIsNotNone(narrowing.find("narrowings/rules/rule"))

    def test_complete_root_materialization_expands_nested_rewrite_index(self) -> None:
        root = ET.fromstring("""
          <certificationProblem>
            <lookupTables><ruleTable><indexToRule><index>7</index>
              <rule><funapp><name>f</name><var>x</var></funapp><var>x</var></rule>
            </indexToRule></ruleTable></lookupTables>
            <proof><trsTerminationProof><dpTrans><dps><rules/></dps><dpProof>
              <rewritingProc><rewriteStep><positionInTerm/>
                <ruleIndex>7</ruleIndex><var>x</var>
              </rewriteStep><dpProof><pIsEmpty/></dpProof></rewritingProc>
            </dpProof></dpTrans></trsTerminationProof></proof>
          </certificationProblem>
        """)

        expanded = EXTRACT.materialize_rule_table_references(root)

        self.assertEqual(expanded.findall(".//ruleIndex"), [])
        self.assertIsNotNone(
            expanded.find(".//rewritingProc/rewriteStep/rule")
        )

    def test_legacy_cpf2_root_input_is_normalized_for_exact_replay(self) -> None:
        root = ET.fromstring("""
          <certificationProblem>
            <input><trsInput><trs><rules><rule>
              <lhs><funapp><name>f</name><arg><var>x</var></arg></funapp></lhs>
              <rhs><var>x</var></rhs>
            </rule></rules></trs></trsInput></input>
            <proof><trsTerminationProof><rIsEmpty/></trsTerminationProof></proof>
          </certificationProblem>
        """)

        expanded = EXTRACT.materialize_rule_table_references(root)
        EXTRACT.normalize_cpf2_terms(expanded)
        source = EXTRACT.unwrap_input(
            ET.tostring(expanded.find("input"), encoding="unicode")
        )
        row = EXTRACT.exact_complete_trs_proof_row(expanded, source, "root-key")

        self.assertIsNotNone(row)
        self.assertNotIn("<lhs>", row["input"]["problem_xml"])
        self.assertNotIn("<rhs>", row["input"]["problem_xml"])
        self.assertNotIn("<arg>", row["input"]["problem_xml"])
        normalized = ET.fromstring(row["input"]["problem_xml"])
        rule = normalized.find("trs/rules/rule")
        self.assertIsNotNone(rule)
        self.assertEqual(
            [EXTRACT.local_name(child.tag) for child in rule],
            ["funapp", "var"],
        )

    def test_complete_root_yes_and_no_rows_are_source_bound(self) -> None:
        root = ET.fromstring("""
          <certificationProblem><proof>
            <trsTerminationProof><rIsEmpty/></trsTerminationProof>
          </proof></certificationProblem>
        """)
        source = "<trsInput><trs><rules/></trs></trsInput>"
        yes = EXTRACT.exact_complete_trs_proof_row(root, source, "root-key")
        self.assertIsNotNone(yes)
        self.assertTrue(
            EXTRACT.strategy_atom(yes).startswith("exact-trs-proof(hex=")
        )
        self.assertEqual(
            yes["metadata"]["runtime_raw_problem_key"], "root-key"
        )

        no_root = ET.fromstring("""
          <certificationProblem><proof>
            <trsNonterminationProof><variableConditionViolated/>
            </trsNonterminationProof>
          </proof></certificationProblem>
        """)
        no = EXTRACT.exact_complete_trs_nontermination_proof_row(
            no_root, source, "root-key"
        )
        self.assertIsNotNone(no)
        self.assertTrue(
            EXTRACT.strategy_atom(no).startswith(
                "exact-trs-nontermination-proof(hex="
            )
        )

    def test_complete_csr_root_drops_only_proof_local_map_symbols(self) -> None:
        root = ET.fromstring("""
          <certificationProblem><proof>
            <csrImprovedDependencyPairs><csrDpProof><pIsEmpty/></csrDpProof>
            </csrImprovedDependencyPairs>
          </proof></certificationProblem>
        """)
        source = """
          <trsInput><trs><rules><rule>
            <funapp><name>f</name><var>x</var></funapp><var>x</var>
          </rule></rules></trs><strategy><contextSensitive>
            <replacementMapEntry><name>f</name><arity>1</arity><position>1</position>
            </replacementMapEntry>
            <replacementMapEntry><name>__CSR_U0</name><arity>1</arity>
            </replacementMapEntry>
          </contextSensitive></strategy></trsInput>
        """
        row = EXTRACT.exact_complete_trs_proof_row(root, source, "root-key")
        self.assertIsNotNone(row)
        encoded = EXTRACT.strategy_atom(row).removeprefix(
            "exact-trs-proof(hex="
        ).removesuffix(")")
        bound_source, proof = json.loads(bytes.fromhex(encoded))
        self.assertIn("<name>f</name>", bound_source)
        self.assertNotIn("__CSR_U0", bound_source)
        self.assertIn("csrImprovedDependencyPairs", proof)

    def test_complete_proof_exclusion_flag_is_documented(self) -> None:
        source = Path(EXTRACT.__file__).read_text(encoding="utf-8")
        self.assertIn('"--exclude-complete-proof-atoms"', source)
        self.assertIn("elif not args.exclude_complete_proof_atoms:", source)

    def test_cpf2_polarity_is_inferred_from_complete_proof_root(self) -> None:
        yes = ET.fromstring(
            "<certificationProblem><proof><trsTerminationProof>"
            "<rIsEmpty/></trsTerminationProof></proof></certificationProblem>"
        )
        no = ET.fromstring(
            "<certificationProblem><proof><trsNonterminationProof>"
            "<loop/></trsNonterminationProof></proof></certificationProblem>"
        )
        self.assertEqual(EXTRACT.proof_polarity(yes), "YES")
        self.assertEqual(EXTRACT.proof_polarity(no), "NO")

    def test_dp_loop_is_extracted_as_source_bound_exact_witness(self) -> None:
        source = "<dpInput><trs><rules/></trs><dps><rules/></dps></dpInput>"
        row = {
            "metadata": {"processor_tag": "loop", "path": ["dpNonterminationProof"]},
            "input": {"problem_xml": source},
            "output_xml": "<loop><rewriteSequence/></loop>",
        }
        atom = EXTRACT.strategy_atom(row)
        self.assertIsNotNone(atom)
        self.assertTrue(atom.startswith("exact-dp-loop(hex="))
        encoded = atom.removeprefix("exact-dp-loop(hex=").removesuffix(")")
        decoded = json.loads(bytes.fromhex(encoded).decode("utf-8"))
        self.assertEqual(decoded, [source, row["output_xml"]])

    def test_complete_dp_nontermination_continuation_is_source_bound(self) -> None:
        source = "<dpInput><trs><rules/></trs><dps><rules/></dps></dpInput>"
        fragment = "<narrowingProc><dpNonterminationProof><loop/></dpNonterminationProof></narrowingProc>"
        rows = [{
            "metadata": {
                "processor_tag": "narrowingProc",
                "path": ["proof", "dpNonterminationProof", "narrowingProc"],
            },
            "input": {"problem_xml": source},
            "output_xml": fragment,
        }]
        exact = EXTRACT.exact_complete_dp_nontermination_proof_rows(rows)
        self.assertEqual(len(exact), 1)
        atom = EXTRACT.strategy_atom(exact[0])
        self.assertTrue(atom.startswith("exact-dp-nontermination-proof(hex="))
        encoded = atom.removeprefix(
            "exact-dp-nontermination-proof(hex="
        ).removesuffix(")")
        decoded_source, decoded_proof = json.loads(
            bytes.fromhex(encoded).decode("utf-8")
        )
        self.assertEqual(decoded_source, source)
        self.assertEqual(
            decoded_proof,
            f"<dpNonterminationProof>{fragment}</dpNonterminationProof>",
        )

    def test_legacy_cpf_root_order_is_repaired_without_changing_proof(self) -> None:
        root = ET.fromstring(
            "<certificationProblem><input><trsInput/></input>"
            "<cpfVersion>2.1</cpfVersion><proof><trsTerminationProof>"
            "<rIsEmpty/></trsTerminationProof></proof><origin/>"
            "</certificationProblem>"
        )
        ordered = EXTRACT.cpf_root_in_schema_order(root)
        self.assertEqual(
            [EXTRACT.local_name(child.tag) for child in ordered],
            ["cpfVersion", "lookupTables", "input", "proof", "origin"],
        )
        self.assertIsNotNone(ordered.find("proof/trsTerminationProof/rIsEmpty"))

    def test_legacy_cpf_checker_normalization_preserves_rule_terms(self) -> None:
        root = ET.fromstring(
            "<certificationProblem><input><trsInput><trs><rules><rule>"
            "<lhs><funapp><name>f</name><arg><var>x</var></arg></funapp></lhs>"
            "<rhs><var>x</var></rhs></rule></rules></trs></trsInput></input>"
            "<cpfVersion>2.1</cpfVersion><proof><trsTerminationProof>"
            "<rIsEmpty/></trsTerminationProof></proof><origin/>"
            "</certificationProblem>"
        )
        ordered = EXTRACT.cpf_root_in_schema_order(root)
        EXTRACT.normalize_cpf2_terms(ordered)
        rule = ordered.find("input/trsInput/trs/rules/rule")
        self.assertIsNotNone(rule)
        self.assertEqual(
            [EXTRACT.local_name(child.tag) for child in rule],
            ["funapp", "var"],
        )
        self.assertEqual(
            [EXTRACT.local_name(child.tag) for child in rule[0]],
            ["name", "var"],
        )
        self.assertIsNotNone(ordered.find("proof/trsTerminationProof/rIsEmpty"))

    def test_cpf21_dp_no_rule_removal_keeps_listed_subproblem(self) -> None:
        root = ET.fromstring(
            "<certificationProblem><input><trsInput><trs><rules/></trs>"
            "</trsInput></input><cpfVersion>2.1</cpfVersion><proof>"
            "<trsNonterminationProof><dpTrans><dps><rules>"
            "<rule><funapp><name>p</name></funapp><funapp><name>p</name></funapp></rule>"
            "<rule><funapp><name>q</name></funapp><funapp><name>q</name></funapp></rule>"
            "</rules></dps><dpNonterminationProof><dpRuleRemoval>"
            "<dps><rules><rule><funapp><name>p</name></funapp>"
            "<funapp><name>p</name></funapp></rule></rules></dps>"
            "<trs><rules/></trs><dpNonterminationProof><loop/>"
            "</dpNonterminationProof></dpRuleRemoval></dpNonterminationProof>"
            "</dpTrans></trsNonterminationProof></proof></certificationProblem>"
        )
        normalized = normalize_root(root)
        step = normalized.find("proof/trsNonterminationProof/dpTrans")
        self.assertIsNotNone(step)
        initial = EXTRACT.input_wrapper(
            EXTRACT.dp_input_like(
                normalized.find("input"), dps_elem=step.find("dps")
            )
        )
        removal = step.find("dpNonterminationProof/dpRuleRemoval")
        recursive = removal.find("dpNonterminationProof")
        child, error = child_input_for(removal, recursive, initial)
        self.assertIsNone(error)
        self.assertIsNotNone(child)
        rules = child.findall("dpInput/dps/rules/rule")
        self.assertEqual(len(rules), 1)
        self.assertEqual("".join(rules[0].itertext()), "pp")

    def test_innermost_lhss_removal_materializes_reduced_q_context(self) -> None:
        current = ET.fromstring("""
          <input><dpInput><trs><rules/></trs><dps><rules><rule/></rules></dps>
            <strategy><innermost><nfs>true</nfs></innermost></strategy>
            <minimal>true</minimal>
            <ferrumDpStateContext><rewriteStrategy>innermost</rewriteStrategy>
              <innermostLhss><funapp><name>old</name></funapp></innermostLhss>
            </ferrumDpStateContext>
          </dpInput></input>
        """)
        wrapper = ET.fromstring("""
          <innermostLhssRemovalProc>
            <innermostLhss><funapp><name>kept</name></funapp></innermostLhss>
            <dpProof><pIsEmpty/></dpProof>
          </innermostLhssRemovalProc>
        """)

        child, error = child_input_for(wrapper, wrapper.find("dpProof"), current)

        self.assertIsNone(error)
        inner = inner_input(child)
        self.assertIsNotNone(inner)
        names = [
            node.text
            for node in inner.findall(
                "ferrumDpStateContext/innermostLhss/funapp/name"
            )
        ]
        self.assertEqual(names, ["kept"])
        self.assertIsNotNone(inner.find("strategy/innermost"))

        transform = ET.fromstring("""
          <narrowingProc><rule/><positionInTerm><position>1</position></positionInTerm>
            <narrowings><rules><rule/></rules></narrowings>
            <dpProof><pIsEmpty/></dpProof>
          </narrowingProc>
        """)
        transformed, transform_error = child_input_for(
            transform, transform.find("dpProof"), child
        )
        self.assertIsNone(transform_error)
        transformed_inner = inner_input(transformed)
        self.assertIsNotNone(transformed_inner)
        transformed_names = [
            node.text
            for node in transformed_inner.findall(
                "ferrumDpStateContext/innermostLhss/funapp/name"
            )
        ]
        self.assertEqual(transformed_names, ["kept"])

    def test_narrowing_nontermination_materializes_its_recursive_dp_state(self) -> None:
        current = ET.fromstring("""
          <input><dpInput><trs><rules/></trs><dps><rules>
            <rule><funapp><name>f</name><var>x</var></funapp>
              <funapp><name>g</name><var>x</var></funapp></rule>
          </rules></dps><minimal>true</minimal></dpInput></input>
        """)
        wrapper = ET.fromstring("""
          <narrowingProc>
            <rule><funapp><name>f</name><var>x</var></funapp>
              <funapp><name>g</name><var>x</var></funapp></rule>
            <positionInTerm/>
            <narrowings><rules><rule>
              <funapp><name>f</name><funapp><name>a</name></funapp></funapp>
              <funapp><name>g</name><funapp><name>a</name></funapp></funapp>
            </rule></rules></narrowings>
            <dpNonterminationProof><loop/></dpNonterminationProof>
          </narrowingProc>
        """)

        child, error = child_input_for(
            wrapper, wrapper.find("dpNonterminationProof"), current
        )

        self.assertIsNone(error)
        inner = inner_input(child)
        self.assertIsNotNone(inner)
        self.assertEqual(len(inner.findall("dps/rules/rule")), 1)
        self.assertEqual(
            inner.findtext("dps/rules/rule/funapp/funapp/name"), "a"
        )

    def test_ordinary_innermost_red_pair_preserves_strategy(self) -> None:
        current = ET.fromstring("""
          <input><dpInput><trs><rules><rule/></rules></trs>
            <dps><rules><rule/><rule/></rules></dps>
            <strategy><innermost><nfs>true</nfs></innermost></strategy>
            <minimal>true</minimal>
          </dpInput></input>
        """)
        wrapper = ET.fromstring("""
          <redPairProc><interpretation/><dps><rules><rule/></rules></dps>
            <dpProof><pIsEmpty/></dpProof></redPairProc>
        """)
        child_proof = wrapper.find("dpProof")
        self.assertIsNotNone(child_proof)

        child, error = child_input_for(wrapper, child_proof, current)

        self.assertIsNone(error)
        inner = inner_input(child)
        self.assertIsNotNone(inner)
        strategy = inner.find("strategy")
        self.assertIsNotNone(strategy)
        self.assertIsNotNone(strategy.find("innermost"))

    def test_mono_red_pair_subtracts_strict_rules_from_active_rules(self) -> None:
        current = ET.fromstring("""
          <input><dpInput><trs><rules>
            <rule><funapp><name>f</name><var>x</var></funapp><var>x</var></rule>
            <rule><funapp><name>g</name><var>x</var></funapp><var>x</var></rule>
          </rules></trs><dps><rules><rule/><rule/></rules></dps>
            <strategy><innermost><nfs>true</nfs></innermost></strategy>
            <minimal>true</minimal>
          </dpInput></input>
        """)
        wrapper = ET.fromstring("""
          <monoRedPairProc><interpretation/><dps><rules><rule/></rules></dps>
            <trs><rules><rule><funapp><name>f</name><var>y</var></funapp>
              <var>y</var></rule></rules></trs>
            <dpProof><pIsEmpty/></dpProof></monoRedPairProc>
        """)
        child_proof = wrapper.find("dpProof")
        self.assertIsNotNone(child_proof)

        child, error = child_input_for(wrapper, child_proof, current)

        self.assertIsNone(error)
        inner = inner_input(child)
        self.assertIsNotNone(inner)
        active = inner.find("trs/rules")
        self.assertIsNotNone(active)
        names = [element.text for element in active.findall("rule/funapp/name")]
        self.assertEqual(names, ["g"])
        self.assertIsNone(inner.find("usableRules"))
        transformed = inner.find("ferrumDpStateContext/transformationRules/rules")
        self.assertIsNotNone(transformed)
        transformed_names = [
            element.text for element in transformed.findall("rule/funapp/name")
        ]
        self.assertEqual(transformed_names, ["g"])
        self.assertIsNotNone(inner.find("strategy/innermost"))

    def test_innermost_mono_red_pair_recurses_on_rule_residual(self) -> None:
        current = ET.fromstring("""
          <input><dpInput><trs><rules>
            <rule><funapp><name>f</name><var>x</var></funapp><var>x</var></rule>
            <rule><funapp><name>g</name><var>x</var></funapp><var>x</var></rule>
          </rules></trs><dps><rules><rule/><rule/></rules></dps>
            <strategy><innermost><nfs>true</nfs></innermost></strategy>
            <minimal>true</minimal>
          </dpInput></input>
        """)
        wrapper = ET.fromstring("""
          <innermostMonoRedPairProc><interpretation/>
            <dps><rules><rule/></rules></dps>
            <trs><rules><rule><funapp><name>f</name><var>y</var></funapp>
              <var>y</var></rule></rules></trs>
            <dpProof><pIsEmpty/></dpProof></innermostMonoRedPairProc>
        """)

        child, error = child_input_for(wrapper, wrapper.find("dpProof"), current)

        self.assertIsNone(error)
        inner = inner_input(child)
        self.assertIsNotNone(inner)
        # Both deliberately identical placeholder pairs are removed by the
        # CPF rule-set subtraction; the rule residual is the assertion that
        # matters for this processor.
        self.assertEqual(len(inner.findall("dps/rules/rule")), 0)
        self.assertIsNone(inner.find("usableRules"))
        self.assertEqual(
            [element.text for element in inner.findall("trs/rules/rule/funapp/name")],
            ["g"],
        )
        self.assertEqual(
            [
                element.text
                for element in inner.findall(
                    "ferrumDpStateContext/transformationRules/rules/rule/funapp/name"
                )
            ],
            ["g"],
        )
        self.assertIsNotNone(inner.find("strategy/innermost"))

    def test_nonmonotonic_usable_red_pair_preserves_parent_rules(self) -> None:
        current = ET.fromstring("""
          <input><dpInput><trs><rules>
            <rule><funapp><name>f</name><var>x</var></funapp><var>x</var></rule>
            <rule><funapp><name>g</name><var>x</var></funapp><var>x</var></rule>
          </rules></trs><dps><rules><rule/><rule/></rules></dps>
            <strategy><innermost><nfs>true</nfs></innermost></strategy>
            <minimal>true</minimal>
          </dpInput></input>
        """)
        wrapper = ET.fromstring("""
          <redPairUrProc><interpretation/><dps><rules><rule/></rules></dps>
            <usableRules><rules><rule><funapp><name>f</name><var>y</var></funapp>
              <var>y</var></rule></rules></usableRules>
            <dpProof><pIsEmpty/></dpProof></redPairUrProc>
        """)

        child, error = child_input_for(wrapper, wrapper.find("dpProof"), current)

        self.assertIsNone(error)
        inner = inner_input(child)
        self.assertIsNotNone(inner)
        self.assertIsNone(inner.find("usableRules"))
        self.assertEqual(len(inner.findall("trs/rules/rule")), 2)

    def test_monotonic_usable_red_pair_carries_usable_residual(self) -> None:
        current = ET.fromstring("""
          <input><dpInput><trs><rules>
            <rule><funapp><name>f</name><var>x</var></funapp><var>x</var></rule>
            <rule><funapp><name>g</name><var>x</var></funapp><var>x</var></rule>
            <rule><funapp><name>h</name><var>x</var></funapp><var>x</var></rule>
          </rules></trs><dps><rules><rule/><rule/></rules></dps>
            <minimal>true</minimal>
          </dpInput></input>
        """)
        wrapper = ET.fromstring("""
          <monoRedPairUrProc><interpretation/><dps><rules><rule/></rules></dps>
            <trs><rules><rule><funapp><name>f</name><var>z</var></funapp>
              <var>z</var></rule></rules></trs>
            <usableRules><rules>
              <rule><funapp><name>f</name><var>y</var></funapp><var>y</var></rule>
              <rule><funapp><name>g</name><var>y</var></funapp><var>y</var></rule>
            </rules></usableRules>
            <dpProof><pIsEmpty/></dpProof></monoRedPairUrProc>
        """)

        child, error = child_input_for(wrapper, wrapper.find("dpProof"), current)

        self.assertIsNone(error)
        inner = inner_input(child)
        self.assertIsNotNone(inner)
        self.assertIsNone(inner.find("usableRules"))
        names = [element.text for element in inner.findall("trs/rules/rule/funapp/name")]
        self.assertEqual(names, ["g"])
        self.assertEqual(
            [
                element.text
                for element in inner.findall(
                    "ferrumDpStateContext/transformationRules/rules/rule/funapp/name"
                )
            ],
            ["g"],
        )

    def test_ordinary_dp_wrapper_drops_only_the_csr_context(self) -> None:
        current = ET.fromstring("""
          <input><dpInput><trs><rules/></trs><dps><rules><rule/></rules></dps>
            <strategy><contextSensitive/></strategy><minimal>true</minimal>
            <ferrumCsrDpContext><construction>improved</construction>
              <graphEstimator>context-sensitive</graphEstimator>
            </ferrumCsrDpContext>
            <ferrumDpStateContext><pairSourceRules><sourceRule>2</sourceRule>
              </pairSourceRules></ferrumDpStateContext>
          </dpInput></input>
        """)
        wrapper = ET.fromstring("<ordinaryDpProof><dpProof><pIsEmpty/>"
                                "</dpProof></ordinaryDpProof>")
        child_proof = wrapper.find("dpProof")
        self.assertIsNotNone(child_proof)

        child, error = child_input_for(wrapper, child_proof, current)

        self.assertIsNone(error)
        inner = inner_input(child)
        self.assertIsNotNone(inner)
        tags = [element.tag for element in inner]
        self.assertNotIn("strategy", tags)
        self.assertNotIn("ferrumCsrDpContext", tags)
        self.assertIn("minimal", tags)
        self.assertIn("ferrumDpStateContext", tags)

    def test_gm_transformed_identity_maps_only_to_its_native_csr_root(self) -> None:
        transformed = "TRS_Standard/Transformed_CSR_04/Ex3_2_Luc97_GM.ari"
        native = "TRS_Contextsensitive/CSR_04/Ex3_2_Luc97.ari"
        self.assertEqual(
            EXTRACT.equivalent_runtime_identities(transformed),
            {transformed, native},
        )
        self.assertEqual(
            EXTRACT.equivalent_runtime_identities(native),
            {native, transformed},
        )
        unrelated = "TRS_Standard/Transformed_CSR_04/Ex3_2_Luc97_iGM.ari"
        self.assertEqual(EXTRACT.equivalent_runtime_identities(unrelated), {unrelated})

    def test_lookup_table_rules_are_materialized_before_exact_atom_extraction(self) -> None:
        root = ET.fromstring("""
          <certificationProblem><lookupTables><ruleTable>
            <indexToRule><index>1</index><rule><funapp><name>f</name></funapp>
              <funapp><name>g</name></funapp></rule></indexToRule>
          </ruleTable></lookupTables><input><dpInput><trs><rules/></trs><dps><rules>
            <ruleIndex>1</ruleIndex></rules></dps><minimal>true</minimal></dpInput></input>
          <proof><dpProof><redPairUrProc><filteredRedPair><weightedPathOrder/>
            </filteredRedPair><dps><rules><ruleIndex>1</ruleIndex></rules></dps>
            <usableRules><rules/></usableRules><dpProof><pIsEmpty/></dpProof>
          </redPairUrProc></dpProof></proof></certificationProblem>
        """)

        expanded = EXTRACT.materialize_rule_table_references(root)

        self.assertEqual(len(expanded.findall(".//input/dpInput/dps/rules/rule")), 1)
        self.assertEqual(len(expanded.findall(".//redPairUrProc/dps/rules/rule")), 1)
        self.assertEqual(len(expanded.findall(".//ruleIndex")), 0)

    def test_runtime_rebinding_aligns_numeric_symbols_in_exact_witness(self) -> None:
        rows = [{
            "metadata": {"runtime_raw_problem_key": "live"},
            "input": {"problem_xml": "<dpInput/>"},
            "output_xml": "<redPairUrProc><dps><rules><rule>"
                "<funapp><name>0</name></funapp><funapp><name>f</name></funapp>"
                "</rule></rules></dps></redPairUrProc>",
        }]
        live = "<dpInput><trs><rules><rule><funapp><name>|0|</name></funapp>"
        live += "<funapp><name>f</name></funapp></rule></rules></trs>"
        live += "<dps><rules/></dps><minimal>true</minimal></dpInput>"

        EXTRACT.rebind_rows_to_runtime_inputs(rows, {"live": live})

        self.assertEqual(rows[0]["input"]["problem_xml"], live)
        self.assertIn("<name>|0|</name>", rows[0]["output_xml"])
        self.assertTrue(rows[0]["metadata"]["runtime_input_rebound"])

    def test_runtime_rebinding_keeps_exact_graph_source_with_its_indices(self) -> None:
        archived = (
            "<dpInput><trs><rules/></trs><dps><rules>"
            "<rule><funapp><name>f</name></funapp><funapp><name>g</name></funapp></rule>"
            "<rule><funapp><name>g</name></funapp><funapp><name>f</name></funapp></rule>"
            "</rules></dps><minimal>true</minimal></dpInput>"
        )
        live = archived.replace("<name>f</name>", "<name>liveF</name>").replace(
            "<name>g</name>", "<name>liveG</name>"
        )
        # A different live presentation may also use a different pair order.
        live_root = ET.fromstring(live)
        live_rules = live_root.find("./dps/rules")
        self.assertIsNotNone(live_rules)
        live_rules[:] = list(reversed(list(live_rules)))
        live = ET.tostring(live_root, encoding="unicode")
        encoded = json.dumps([archived, [[[0], True], [[1], False]]], separators=(",", ":")).encode().hex()
        atom = f"exact-graph(hex={encoded})"
        rows = [{
            "metadata": {
                "runtime_raw_problem_key": "live",
                "strategy_atom": atom,
            },
            "input": {"problem_xml": archived},
            "output_xml": "<depGraphProc/>",
        }]

        EXTRACT.rebind_rows_to_runtime_inputs(rows, {"live": live})

        self.assertEqual(rows[0]["input"]["problem_xml"], live)
        self.assertEqual(rows[0]["metadata"]["strategy_atom"], atom)

    def test_local_usable_rules_is_a_first_class_active_rule_transition(self) -> None:
        current = ET.fromstring("""
          <input><dpInput><trs><rules>
            <rule><funapp><name>f</name><var>X</var></funapp><var>X</var></rule>
            <rule><funapp><name>g</name><var>X</var></funapp><var>X</var></rule>
          </rules></trs><dps><rules><rule/></rules></dps>
          <minimal>true</minimal><ferrumCsrDpContext>
            <construction>muterm-unhiding</construction>
            <graphEstimator>ordinary</graphEstimator>
          </ferrumCsrDpContext></dpInput></input>
        """)
        processor = ET.fromstring("""
          <localUsableRulesProc><usableRules><rules>
            <rule><funapp><name>f</name><var>X</var></funapp><var>X</var></rule>
          </rules></usableRules><dpProof><pIsEmpty/></dpProof>
          </localUsableRulesProc>
        """)
        child = next(
            element for element in processor if EXTRACT.local_name(element.tag) == "dpProof"
        )

        residual, error = child_input_for(processor, child, current)

        self.assertIsNone(error)
        self.assertIsNotNone(residual)
        inner = inner_input(residual)
        self.assertIsNotNone(inner)
        self.assertEqual(len(inner.findall("./trs/rules/rule")), 2)
        self.assertEqual(len(inner.findall("./usableRules/rules/rule")), 1)

        row = {
            "metadata": {
                "processor_tag": "localUsableRulesProc",
                "strategy_atom": None,
            },
            "input": {"problem_xml": ET.tostring(current, encoding="unicode")},
            "output_xml": ET.tostring(processor, encoding="unicode"),
        }
        self.assertTrue(EXTRACT.strategy_atom(row).startswith("exact-usable-rules("))

        runtime_hint = {
            "metadata": {
                "processor_tag": "certifiedRuntimeAtom",
                "strategy_atom": "rat-poly(max-constant=4)",
            },
            "input": {"problem_xml": ET.tostring(current, encoding="unicode")},
        }
        self.assertEqual(
            EXTRACT.discard_runtime_atoms_shadowed_by_local_context(
                [row], [runtime_hint]
            ),
            [],
        )

        exact_runtime_atom = {
            "metadata": {
                "processor_tag": "certifiedRuntimeAtom",
                "strategy_atom": "exact-rat-natural-poly(hex=5b5d)",
                "runtime_atom_certified_source": True,
                "runtime_atom_pool_only": False,
            },
            "input": {"problem_xml": ET.tostring(current, encoding="unicode")},
        }
        self.assertEqual(
            EXTRACT.discard_runtime_atoms_shadowed_by_local_context(
                [row], [exact_runtime_atom]
            ),
            [],
        )

    def test_csr_usable_rules_child_stays_typed_but_nonminimal(self) -> None:
        current = ET.fromstring("""
          <input><dpInput><trs><rules><rule/></rules></trs>
            <dps><rules><rule/></rules></dps>
            <strategy><contextSensitive/></strategy><minimal>true</minimal>
            <ferrumCsrDpContext><construction>improved</construction>
              <graphEstimator>context-sensitive</graphEstimator>
            </ferrumCsrDpContext></dpInput></input>
        """)
        processor = ET.fromstring("""
          <usableRulesProc><usableRules><rules/></usableRules>
            <dpProof><pIsEmpty/></dpProof></usableRulesProc>
        """)
        child = next(
            element for element in processor
            if EXTRACT.local_name(element.tag) == "dpProof"
        )

        residual, error = child_input_for(processor, child, current)

        self.assertIsNone(error)
        inner = inner_input(residual)
        self.assertIsNotNone(inner)
        self.assertEqual(inner.findtext("minimal"), "false")
        self.assertIsNotNone(inner.find("ferrumCsrDpContext"))
        self.assertIsNotNone(inner.find("strategy"))
        self.assertEqual(len(inner.findall("./usableRules/rules/rule")), 0)

    def test_plain_red_pair_child_crosses_the_ordinary_dp_boundary(self) -> None:
        current = ET.fromstring("""
          <input><dpInput><trs><rules><rule/></rules></trs>
            <dps><rules><rule><var>X</var><var>X</var></rule></rules></dps>
            <usableRules><rules><rule/></rules></usableRules>
            <strategy><contextSensitive/></strategy><minimal>true</minimal>
            <ferrumCsrDpContext><construction>improved</construction>
            </ferrumCsrDpContext></dpInput></input>
        """)
        processor = ET.fromstring("""
          <redPairProc><dps><rules><rule><var>X</var><var>X</var></rule></rules></dps>
            <dpProof><pIsEmpty/></dpProof></redPairProc>
        """)
        child = next(
            element for element in processor
            if EXTRACT.local_name(element.tag) == "dpProof"
        )

        residual, error = child_input_for(processor, child, current)

        self.assertIsNone(error)
        inner = inner_input(residual)
        self.assertIsNotNone(inner)
        self.assertEqual(inner.findtext("minimal"), "true")
        self.assertIsNone(inner.find("ferrumCsrDpContext"))
        self.assertIsNone(inner.find("strategy"))
        self.assertEqual(len(inner.findall("./usableRules/rules/rule")), 1)

    def test_muterm_local_usable_rules_keeps_type_but_drops_minimality(self) -> None:
        current = ET.fromstring("""
          <input><dpInput><trs><rules><rule/></rules></trs>
            <dps><rules><rule/></rules></dps>
            <strategy><contextSensitive/></strategy><minimal>true</minimal>
            <ferrumCsrDpContext><construction>muterm-unhiding</construction>
            </ferrumCsrDpContext></dpInput></input>
        """)
        processor = ET.fromstring("""
          <localUsableRulesProc><usableRules><rules/></usableRules>
            <dpProof><pIsEmpty/></dpProof></localUsableRulesProc>
        """)
        child = next(
            element for element in processor
            if EXTRACT.local_name(element.tag) == "dpProof"
        )

        residual, error = child_input_for(processor, child, current)

        self.assertIsNone(error)
        inner = inner_input(residual)
        self.assertIsNotNone(inner)
        self.assertEqual(inner.findtext("minimal"), "false")
        self.assertEqual(
            inner.findtext("./ferrumCsrDpContext/construction"),
            "muterm-unhiding",
        )

    def test_runtime_signature_identifies_explicit_and_default_full_strategy(self) -> None:
        implicit = "<trsInput><trs><rules><rule><var>X</var><var>X</var></rule></rules></trs></trsInput>"
        explicit = "<trsInput><trs><rules><rule><var>Y</var><var>Y</var></rule></rules></trs><strategy><full/></strategy></trsInput>"
        self.assertEqual(
            EXTRACT.runtime_state_signature(implicit),
            EXTRACT.runtime_state_signature(explicit),
        )

    def test_runtime_signature_ignores_zero_arity_replacement_map_entries(self) -> None:
        absent = (
            "<dpInput><trs><rules/></trs><dps><rules/></dps><strategy>"
            "<contextSensitive/></strategy><minimal>true</minimal></dpInput>"
        )
        explicit = absent.replace(
            "<contextSensitive/>",
            "<contextSensitive><replacementMapEntry><name>nil</name>"
            "<arity>0</arity></replacementMapEntry></contextSensitive>",
        )

        self.assertEqual(
            EXTRACT.runtime_state_signature(absent),
            EXTRACT.runtime_state_signature(explicit),
        )

    def test_runtime_aliases_include_unattempted_materialized_residuals(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            events = Path(temporary) / "processor-events.jsonl"
            root = "<trsInput><trs><rules/></trs></trsInput>"
            child = (
                "<dpInput><trs><rules/></trs><dps><rules/></dps>"
                "<minimal>true</minimal></dpInput>"
            )
            events.write_text(
                json.dumps(
                    {
                        "problem_id": "TRS_Contextsensitive/Test/X.ari",
                        "category": "TRS_Contextsensitive",
                        "input": {"cpf": root, "problem_key": "root-key"},
                        "witness": {
                            "residuals": [
                                {"cpf": child, "problem_key": "child-key"}
                            ]
                        },
                    }
                )
                + "\n",
                encoding="utf-8",
            )

            aliases, _, inputs = EXTRACT.read_runtime_state_aliases([events])

            identity = "TRS_Contextsensitive/Test/X.ari"
            signature = EXTRACT.runtime_state_signature(child)
            self.assertIn("child-key", aliases[(identity, signature)])
            self.assertEqual(inputs["child-key"], child)

    def test_runtime_aliases_use_adjacent_result_for_anonymous_isolated_run(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            events = root / "events.jsonl"
            child = (
                "<dpInput><trs><rules/></trs><dps><rules/></dps>"
                "<minimal>true</minimal></dpInput>"
            )
            events.write_text(
                json.dumps(
                    {
                        "input": {"cpf": child, "problem_key": "child-key"},
                        "outcome": "failed",
                    }
                )
                + "\n",
                encoding="utf-8",
            )
            (root / "result.json").write_text(
                json.dumps(
                    {
                        "problem_id": "Zantema_05/z24.ari#qdp-to-srs",
                        "category": "TRS_Standard",
                    }
                ),
                encoding="utf-8",
            )

            aliases, _, _ = EXTRACT.read_runtime_state_aliases([events])

            identity = "TRS_Standard/Zantema_05/z24.ari"
            signature = EXTRACT.runtime_state_signature(child)
            self.assertIn("child-key", aliases[(identity, signature)])

    def test_structural_red_pair_supersedes_runtime_model_atom(self) -> None:
        proof_row = {
            "metadata": {"processor_tag": "redPairProc"},
            "input": {"problem_xml": "<input><dpInput/></input>"},
        }
        runtime_model = {
            "metadata": {
                "processor_tag": "certifiedRuntimeAtom",
                "strategy_atom": "exact-rat-natural-poly(hex=5b5d)",
                "runtime_atom_certified_source": True,
            },
            "input": {"problem_xml": "<input><dpInput/></input>"},
        }

        self.assertEqual(
            EXTRACT.discard_runtime_atoms_shadowed_by_local_context(
                [proof_row], [runtime_model]
            ),
            [],
        )

    def test_exact_live_red_pair_edge_supersedes_reconstructed_wrapper(self) -> None:
        proof_rows = [
            {
                "id": "red",
                "metadata": {
                    "processor_tag": "monoRedPairProc",
                    "strategy_atom": "exact-red-pair(hex=5b5d)",
                    "runtime_raw_problem_key": "parent",
                },
                "input": {"problem_xml": "<input><dpInput/></input>"},
            },
            {
                "id": "child",
                "metadata": {
                    "processor_tag": "pIsEmpty",
                    "causal_parent_row_id": "red",
                    "runtime_raw_problem_key": "child",
                },
                "input": {"problem_xml": "<input><dpInput/></input>"},
            },
        ]
        runtime = {
            "metadata": {
                "processor_tag": "certifiedRuntimeAtom",
                "strategy_atom": "exact-mono-poly(hex=5b5d)",
                "runtime_raw_problem_key": "parent",
                "runtime_residual_problem_keys": ["child"],
                "runtime_atom_certified_source": True,
                "runtime_atom_external_hint": False,
            },
            "input": {"problem_xml": "<input><dpInput/></input>"},
        }

        retained = EXTRACT.discard_runtime_atoms_shadowed_by_local_context(
            proof_rows, [runtime]
        )

        self.assertEqual(retained, [runtime])
        self.assertEqual([row["id"] for row in proof_rows], ["child"])
        self.assertTrue(
            runtime["metadata"]["runtime_matches_structural_red_pair"]
        )

    def test_exact_live_relative_bounds_edge_supersedes_reverse_parsing(self) -> None:
        proof_rows = [
            {
                "id": "bounds",
                "metadata": {
                    "processor_tag": "relativeBounds",
                    "strategy_atom": "exact-relative-match-bounds(hex=5b5d)",
                    "runtime_raw_problem_key": "relative-parent",
                },
                "input": {"problem_xml": "<input><trsInput/></input>"},
            },
            {
                "id": "empty",
                "metadata": {
                    "processor_tag": "rIsEmpty",
                    "causal_parent_row_id": "bounds",
                    "runtime_raw_problem_key": "relative-child",
                },
                "input": {"problem_xml": "<input><trsInput/></input>"},
            },
        ]
        runtime = {
            "metadata": {
                "processor_tag": "certifiedRuntimeAtom",
                "strategy_atom": (
                    "relative-match-bounds(max-bound=12,max-states=50000,"
                    "max-transitions=1000000)"
                ),
                "runtime_raw_problem_key": "relative-parent",
                "runtime_residual_problem_keys": ["relative-child"],
                "runtime_atom_certified_source": False,
                "runtime_atom_external_hint": True,
            },
            "input": {"problem_xml": "<input><trsInput/></input>"},
        }

        retained = EXTRACT.discard_runtime_atoms_shadowed_by_local_context(
            proof_rows, [runtime]
        )

        self.assertEqual(retained, [runtime])
        self.assertEqual([row["id"] for row in proof_rows], ["empty"])
        self.assertTrue(runtime["metadata"]["runtime_atom_certified_source"])
        self.assertFalse(runtime["metadata"]["runtime_atom_external_hint"])

    def test_exact_live_dp_transformation_edge_supersedes_recursive_payload(self) -> None:
        proof_rows = [
            {
                "id": "narrow",
                "metadata": {
                    "processor_tag": "narrowingProc",
                    "strategy_atom": "exact-dp-transform(hex=7374727563747572616c)",
                    "runtime_raw_problem_key": "parent",
                },
                "input": {"problem_xml": "<input><dpInput/></input>"},
            },
            {
                "id": "child",
                "metadata": {
                    "processor_tag": "instantiationProc",
                    "causal_parent_row_id": "narrow",
                    "runtime_raw_problem_key": "child",
                },
                "input": {"problem_xml": "<input><dpInput/></input>"},
            },
        ]
        runtime = {
            "metadata": {
                "processor_tag": "certifiedRuntimeAtom",
                "strategy_atom": "exact-dp-transform(hex=6c697665)",
                "runtime_raw_problem_key": "parent",
                "runtime_residual_problem_keys": ["child"],
                "runtime_atom_certified_source": False,
                "runtime_atom_external_hint": True,
            },
            "input": {"problem_xml": "<input><dpInput/></input>"},
        }

        retained = EXTRACT.discard_runtime_atoms_shadowed_by_local_context(
            proof_rows, [runtime]
        )

        self.assertEqual(retained, [runtime])
        self.assertEqual([row["id"] for row in proof_rows], ["child"])
        self.assertTrue(
            runtime["metadata"]["runtime_matches_structural_transition"]
        )
        self.assertTrue(runtime["metadata"]["runtime_atom_certified_source"])
        self.assertFalse(runtime["metadata"]["runtime_atom_external_hint"])

    def test_alpha_merge_requires_the_checked_instantiation_edge(self) -> None:
        for child_key in ["child", "unrelated"]:
            proof_rows = [
                {"id": "merge", "metadata": {"processor_tag": "instantiationProc",
                    "runtime_raw_problem_key": "parent"},
                 "input": {"problem_xml": "<input><dpInput/></input>"}},
                {"id": "child", "metadata": {"processor_tag": "pIsEmpty",
                    "causal_parent_row_id": "merge", "runtime_raw_problem_key": "child"},
                 "input": {"problem_xml": "<input><dpInput/></input>"}},
            ]
            runtime = {"metadata": {"processor_tag": "certifiedRuntimeAtom",
                "strategy_atom": "alpha-merge", "runtime_raw_problem_key": "parent",
                "runtime_residual_problem_keys": [child_key],
                "runtime_atom_certified_source": False, "runtime_atom_external_hint": True},
                "input": {"problem_xml": "<input><dpInput/></input>"}}
            # A later alias with the same CPF row id must not erase the
            # exact runtime parent used by this checked edge.
            proof_rows.append({"id": "merge", "metadata": {
                "processor_tag": "instantiationProc", "runtime_raw_problem_key": "other-alias"},
                "input": {"problem_xml": "<input><dpInput/></input>"}})
            EXTRACT.discard_runtime_atoms_shadowed_by_local_context(proof_rows, [runtime])
            self.assertEqual(runtime["metadata"]["runtime_atom_certified_source"], child_key == "child")

    def test_exact_live_dp_transform_does_not_match_wrong_residual(self) -> None:
        proof_rows = [
            {
                "id": "narrow",
                "metadata": {
                    "processor_tag": "narrowingProc",
                    "strategy_atom": "exact-dp-transform(hex=7374727563747572616c)",
                    "runtime_raw_problem_key": "parent",
                },
                "input": {"problem_xml": "<input><dpInput/></input>"},
            },
            {
                "id": "child",
                "metadata": {
                    "processor_tag": "pIsEmpty",
                    "causal_parent_row_id": "narrow",
                    "runtime_raw_problem_key": "checked-child",
                },
                "input": {"problem_xml": "<input><dpInput/></input>"},
            },
        ]
        runtime = {
            "metadata": {
                "processor_tag": "certifiedRuntimeAtom",
                "strategy_atom": "exact-dp-transform(hex=6c697665)",
                "runtime_raw_problem_key": "parent",
                "runtime_residual_problem_keys": ["other-child"],
                "runtime_atom_certified_source": True,
                "runtime_atom_external_hint": False,
            },
            "input": {"problem_xml": "<input><dpInput/></input>"},
        }

        retained = EXTRACT.discard_runtime_atoms_shadowed_by_local_context(
            proof_rows, [runtime]
        )

        self.assertEqual(len(retained), 1)
        self.assertFalse(
            retained[0]["metadata"]["runtime_atom_certified_source"]
        )
        self.assertTrue(retained[0]["metadata"]["runtime_atom_external_hint"])

    def test_exact_live_dp_loop_supersedes_reconstructed_terminal(self) -> None:
        proof_rows = [
            {
                "id": "loop",
                "metadata": {
                    "processor_tag": "loop",
                    "strategy_atom": "exact-dp-loop(hex=7374727563747572616c)",
                    "runtime_raw_problem_key": "loop-state",
                },
                "input": {"problem_xml": "<input><dpInput/></input>"},
            }
        ]
        runtime = {
            "metadata": {
                "processor_tag": "certifiedRuntimeAtom",
                "strategy_atom": "exact-dp-loop(hex=6c697665)",
                "runtime_raw_problem_key": "loop-state",
                "runtime_atom_certified_source": False,
                "runtime_atom_external_hint": True,
            },
            "input": {"problem_xml": "<input><dpInput/></input>"},
        }

        retained = EXTRACT.discard_runtime_atoms_shadowed_by_local_context(
            proof_rows, [runtime]
        )

        self.assertEqual(retained, [runtime])
        self.assertEqual(proof_rows, [])
        self.assertTrue(runtime["metadata"]["runtime_atom_certified_source"])
        self.assertFalse(runtime["metadata"]["runtime_atom_external_hint"])

    def test_matching_live_legacy_red_pair_bridges_structural_state_drift(self) -> None:
        payload = "<interpretation><type><polynomial /></type></interpretation><dps />"

        def atom(fields: list[object]) -> str:
            encoded = json.dumps(fields, separators=(",", ":")).encode().hex()
            return f"exact-red-pair(hex={encoded})"

        structural = atom(
            ["redPairUrProc", payload, [0], "<dps />", "<usableRules />"]
        )
        runtime = atom(
            [
                "redPairUrProc",
                "<interpretation> <type><polynomial/></type> </interpretation><dps/>",
                [0],
            ]
        )
        proof_row = {
            "metadata": {
                "processor_tag": "redPairUrProc",
                "strategy_atom": structural,
            },
            "input": {"problem_xml": "<input><dpInput/></input>"},
        }
        runtime_row = {
            "metadata": {
                "processor_tag": "certifiedRuntimeAtom",
                "strategy_atom": runtime,
                "runtime_atom_certified_source": True,
                "runtime_atom_external_hint": False,
            },
            "input": {"problem_xml": "<input><dpInput/></input>"},
        }

        rows = EXTRACT.discard_runtime_atoms_shadowed_by_local_context(
            [proof_row], [runtime_row]
        )

        self.assertEqual(len(rows), 1)
        self.assertTrue(rows[0]["metadata"]["runtime_atom_certified_source"])
        self.assertFalse(rows[0]["metadata"]["runtime_atom_external_hint"])

    def test_ordinary_usable_rules_child_preserves_minimality(self) -> None:
        current = ET.fromstring("""
          <input><dpInput><trs><rules><rule><funapp><name>f</name>
            <var>X</var></funapp><var>X</var></rule></rules></trs>
            <dps><rules><rule/></rules></dps><strategy><innermost/></strategy>
            <minimal>true</minimal></dpInput></input>
        """)
        processor = ET.fromstring("""
          <usableRulesProc><usableRules><rules/></usableRules>
            <dpProof><sizeChangeProc/></dpProof></usableRulesProc>
        """)
        child = next(
            element for element in processor if EXTRACT.local_name(element.tag) == "dpProof"
        )

        residual, error = child_input_for(processor, child, current)

        self.assertIsNone(error)
        inner = inner_input(residual)
        self.assertIsNotNone(inner)
        minimal = next(
            element for element in inner if EXTRACT.local_name(element.tag) == "minimal"
        )
        self.assertEqual(minimal.text, "true")

    def test_backtracked_runtime_atom_is_not_credited_by_final_cpf(self) -> None:
        proof_row = {
            "metadata": {
                "processor_tag": "csrDependencyPairs",
                "strategy_atom": "csr-native-dp",
            },
            "input": {"problem_xml": "<input><trsInput/></input>"},
        }
        runtime_model = {
            "metadata": {
                "processor_tag": "certifiedRuntimeAtom",
                "strategy_atom": "exact-matrix(hex=5b5d)",
                "runtime_atom_certified_source": True,
                "runtime_atom_external_hint": False,
            },
            "input": {"problem_xml": "<input><trsInput/></input>"},
        }

        rows = EXTRACT.discard_runtime_atoms_shadowed_by_local_context(
            [proof_row], [runtime_model]
        )

        self.assertEqual(len(rows), 1)
        self.assertFalse(rows[0]["metadata"]["runtime_atom_certified_source"])
        self.assertTrue(rows[0]["metadata"]["runtime_atom_external_hint"])

    def test_generic_runtime_atom_matches_exact_structural_family(self) -> None:
        proof_row = {
            "metadata": {
                "processor_tag": "depGraphProc",
                "strategy_atom": "exact-graph(hex=5b5d)",
            },
            "input": {"problem_xml": "<input><dpInput/></input>"},
        }
        runtime_graph = {
            "metadata": {
                "processor_tag": "certifiedRuntimeAtom",
                "strategy_atom": "graph",
                "runtime_atom_certified_source": True,
                "runtime_atom_external_hint": False,
            },
            "input": {"problem_xml": "<input><dpInput/></input>"},
        }

        rows = EXTRACT.discard_runtime_atoms_shadowed_by_local_context(
            [proof_row], [runtime_graph]
        )

        self.assertEqual(len(rows), 1)
        self.assertTrue(rows[0]["metadata"]["runtime_atom_certified_source"])
        self.assertFalse(rows[0]["metadata"]["runtime_atom_external_hint"])

    def test_runtime_empty_matches_structural_empty_terminal(self) -> None:
        proof_row = {
            "metadata": {"processor_tag": "pIsEmpty"},
            "input": {"problem_xml": "<input><dpInput/></input>"},
        }
        runtime_empty = {
            "metadata": {
                "processor_tag": "certifiedRuntimeAtom",
                "strategy_atom": "empty",
                "runtime_atom_certified_source": True,
                "runtime_atom_external_hint": False,
            },
            "input": {"problem_xml": "<input><dpInput/></input>"},
        }

        rows = EXTRACT.discard_runtime_atoms_shadowed_by_local_context(
            [proof_row], [runtime_empty]
        )

        self.assertEqual(len(rows), 1)
        self.assertTrue(rows[0]["metadata"]["runtime_atom_certified_source"])
        self.assertFalse(rows[0]["metadata"]["runtime_atom_external_hint"])

    def test_live_exact_graph_matches_structural_graph_without_private_context(self) -> None:
        structural_source = (
            "<dpInput><trs><rules/></trs><dps><rules><rule/></rules></dps>"
            "<minimal>true</minimal></dpInput>"
        )
        live_source = structural_source.replace(
            "</dpInput>",
            "<ferrumDpStateContext><ordinaryReductionStarted>false"
            "</ordinaryReductionStarted></ferrumDpStateContext></dpInput>",
        )

        def graph_atom(source: str) -> str:
            payload = json.dumps(
                [source, [[[0], False]]], separators=(",", ":")
            ).encode().hex()
            return f"exact-graph(hex={payload})"

        proof_row = {
            "metadata": {
                "processor_tag": "depGraphProc",
                "strategy_atom": graph_atom(structural_source),
            },
            "input": {"problem_xml": f"<input>{structural_source}</input>"},
        }
        runtime_graph = {
            "metadata": {
                "processor_tag": "certifiedRuntimeAtom",
                "strategy_atom": graph_atom(live_source),
                "runtime_atom_certified_source": True,
                "runtime_atom_external_hint": False,
            },
            "input": {"problem_xml": f"<input>{live_source}</input>"},
        }

        rows = EXTRACT.discard_runtime_atoms_shadowed_by_local_context(
            [proof_row], [runtime_graph]
        )

        self.assertEqual(len(rows), 1)
        self.assertTrue(rows[0]["metadata"]["runtime_atom_certified_source"])
        self.assertFalse(rows[0]["metadata"]["runtime_atom_external_hint"])

    def test_generic_innermost_lhss_matches_exact_structural_family(self) -> None:
        proof_row = {
            "metadata": {
                "processor_tag": "innermostLhssRemovalProc",
                "strategy_atom": "exact-innermost-lhss(hex=5b5d)",
            },
            "input": {"problem_xml": "<input><dpInput/></input>"},
        }
        runtime_lhss = {
            "metadata": {
                "processor_tag": "certifiedRuntimeAtom",
                "strategy_atom": "innermost-lhss",
                "runtime_atom_certified_source": True,
                "runtime_atom_external_hint": False,
            },
            "input": {"problem_xml": "<input><dpInput/></input>"},
        }

        rows = EXTRACT.discard_runtime_atoms_shadowed_by_local_context(
            [proof_row], [runtime_lhss]
        )

        self.assertEqual(len(rows), 1)
        self.assertTrue(rows[0]["metadata"]["runtime_atom_certified_source"])
        self.assertFalse(rows[0]["metadata"]["runtime_atom_external_hint"])

    def test_runtime_signature_preserves_processor_semantic_dp_context(self) -> None:
        plain = "<dpInput><trs><rules/></trs><dps><rules/></dps><minimal>true</minimal></dpInput>"
        runtime = "<dpInput><trs><rules/></trs><dps><rules/></dps><minimal>true</minimal><ferrumDpStateContext><pairSourceRules><sourceRule>7</sourceRule></pairSourceRules><ordinaryReductionStarted>false</ordinaryReductionStarted></ferrumDpStateContext></dpInput>"
        self.assertNotEqual(
            EXTRACT.runtime_state_signature(plain),
            EXTRACT.runtime_state_signature(runtime),
        )

    def test_runtime_signature_uses_cpf_default_false_for_empty_dp_nfs(self) -> None:
        implicit = (
            "<dpInput><trs><rules/></trs><dps><rules/></dps>"
            "<strategy><innermost/></strategy><minimal>true</minimal></dpInput>"
        )
        explicit = implicit.replace(
            "<innermost/>", "<innermost><nfs>false</nfs></innermost>"
        )
        self.assertEqual(
            EXTRACT.runtime_state_signature(implicit),
            EXTRACT.runtime_state_signature(explicit),
        )

    def test_runtime_signature_ignores_dp_input_field_order(self) -> None:
        first = (
            "<dpInput><trs><rules/></trs><dps><rules/></dps>"
            "<strategy><innermost><nfs>false</nfs></innermost></strategy>"
            "<usableRules><rules/></usableRules><minimal>true</minimal></dpInput>"
        )
        second = first.replace(
            "<strategy><innermost><nfs>false</nfs></innermost></strategy>"
            "<usableRules><rules/></usableRules>",
            "<usableRules><rules/></usableRules>"
            "<strategy><innermost><nfs>false</nfs></innermost></strategy>",
        )
        self.assertEqual(
            EXTRACT.runtime_state_signature(first),
            EXTRACT.runtime_state_signature(second),
        )

    def test_runtime_signature_distinguishes_dp_source_provenance(self) -> None:
        first = "<dpInput><trs><rules><rule/></rules></trs><dps><rules><rule/></rules></dps><minimal>true</minimal><ferrumDpStateContext><rewriteStrategy>innermost</rewriteStrategy><pairSourceRules><sourceRule>0</sourceRule></pairSourceRules><ordinaryReductionStarted>false</ordinaryReductionStarted></ferrumDpStateContext></dpInput>"
        second = first.replace(
            "<sourceRule>0</sourceRule>", "<sourceRule>1</sourceRule>"
        )
        self.assertNotEqual(
            EXTRACT.runtime_state_signature(first),
            EXTRACT.runtime_state_signature(second),
        )

    def test_runtime_signature_distinguishes_rewrite_strategy(self) -> None:
        innermost = "<dpInput><trs><rules/></trs><dps><rules/></dps><minimal>true</minimal><ferrumDpStateContext><rewriteStrategy>innermost</rewriteStrategy><pairSourceRules/><ordinaryReductionStarted>false</ordinaryReductionStarted></ferrumDpStateContext></dpInput>"
        full = innermost.replace(
            "<rewriteStrategy>innermost</rewriteStrategy>",
            "<rewriteStrategy>full</rewriteStrategy>",
        )
        self.assertNotEqual(
            EXTRACT.runtime_state_signature(innermost),
            EXTRACT.runtime_state_signature(full),
        )

    def test_runtime_signature_identifies_redundant_full_usable_rules(self) -> None:
        rule = "<rule><funapp><name>f</name><var>X</var></funapp><var>X</var></rule>"
        implicit = (
            f"<dpInput><trs><rules>{rule}</rules></trs><dps><rules/></dps>"
            "<minimal>true</minimal></dpInput>"
        )
        explicit = (
            f"<dpInput><trs><rules>{rule}</rules></trs><dps><rules/></dps>"
            f"<usableRules><rules>{rule}</rules></usableRules>"
            "<minimal>true</minimal></dpInput>"
        )
        proper_subset = (
            f"<dpInput><trs><rules>{rule}</rules></trs><dps><rules/></dps>"
            "<usableRules><rules/></usableRules>"
            "<minimal>true</minimal></dpInput>"
        )

        self.assertEqual(
            EXTRACT.runtime_state_signature(implicit),
            EXTRACT.runtime_state_signature(explicit),
        )
        self.assertNotEqual(
            EXTRACT.runtime_state_signature(implicit),
            EXTRACT.runtime_state_signature(proper_subset),
        )

    def test_improved_csr_signature_ignores_derived_unhiding_map_entry(self) -> None:
        base = (
            "<dpInput><trs><rules/></trs><dps><rules/></dps>"
            "<strategy><contextSensitive/></strategy><minimal>true</minimal>"
            "<ferrumCsrDpContext><construction>improved</construction>"
            "<graphEstimator>context-sensitive</graphEstimator>"
            "</ferrumCsrDpContext></dpInput>"
        )
        explicit = base.replace(
            "<contextSensitive/>",
            "<contextSensitive><replacementMapEntry><name>__CSR_U0</name>"
            "<arity>1</arity></replacementMapEntry></contextSensitive>",
        )
        self.assertEqual(
            EXTRACT.runtime_state_signature(base),
            EXTRACT.runtime_state_signature(explicit),
        )

    def test_runtime_signature_preserves_active_usable_rules(self) -> None:
        full = "<dpInput><trs><rules><rule/></rules></trs><dps><rules/></dps><minimal>true</minimal></dpInput>"
        active = "<dpInput><trs><rules><rule/></rules></trs><dps><rules/></dps><usableRules><rules/></usableRules><minimal>true</minimal></dpInput>"
        self.assertNotEqual(
            EXTRACT.runtime_state_signature(full),
            EXTRACT.runtime_state_signature(active),
        )

    def test_effective_rule_count_prefers_active_usable_rules(self) -> None:
        full = """<dpInput><trs><rules><rule/><rule/></rules></trs>
          <dps><rules/></dps></dpInput>"""
        active_empty = """<dpInput><trs><rules><rule/><rule/></rules></trs>
          <dps><rules/></dps><usableRules><rules/></usableRules></dpInput>"""

        self.assertEqual(EXTRACT.effective_rule_count(full), 2)
        self.assertEqual(EXTRACT.effective_rule_count(active_empty), 0)

    def test_exact_red_pair_processor_tag_decodes_monotone_form(self) -> None:
        payload = json.dumps(
            ["monoRedPairProc", "<interpretation/>", [0]],
            separators=(",", ":"),
        ).encode().hex()

        self.assertEqual(
            EXTRACT.exact_red_pair_processor_tag(
                f"exact-red-pair(hex={payload})"
            ),
            "monoRedPairProc",
        )

    def test_exact_red_pair_context_bound_requires_complete_source_state(self) -> None:
        legacy = json.dumps(
            ["redPairProc", "<interpretation/>", [0]], separators=(",", ":")
        ).encode().hex()
        bound = json.dumps(
            [
                "redPairProc",
                "<interpretation/>",
                [0],
                "<dps><rules/></dps>",
                "<trs><rules/></trs>",
            ],
            separators=(",", ":"),
        ).encode().hex()

        self.assertFalse(
            EXTRACT.exact_red_pair_is_context_bound(
                f"exact-red-pair(hex={legacy})"
            )
        )
        self.assertTrue(
            EXTRACT.exact_red_pair_is_context_bound(
                f"exact-red-pair(hex={bound})"
            )
        )

    def test_context_bound_red_pair_rebinds_numeric_live_alias(self) -> None:
        payload = [
            "redPairUrProc",
            "<filteredRedPair><name>0</name></filteredRedPair>",
            [0],
            "<dps><rules><rule><funapp><name>0</name></funapp><funapp><name>f</name></funapp></rule></rules></dps>",
            "<usableRules><rules><rule><funapp><name>0</name></funapp><funapp><name>g</name></funapp></rule></rules></usableRules>",
        ]
        atom = "exact-red-pair(hex=" + json.dumps(
            payload, separators=(",", ":")
        ).encode().hex() + ")"
        rebound = EXTRACT.rebind_context_bound_red_pair_atom(
            atom, "<dpInput><trs><rules/><name>|0|</name></trs></dpInput>"
        )
        decoded = json.loads(bytes.fromhex(rebound.split("hex=", 1)[1][:-1]))
        self.assertIn("<name>|0|</name>", decoded[1])
        self.assertIn("<name>|0|</name>", decoded[3])
        self.assertIn("<name>|0|</name>", decoded[4])

    def test_runtime_signature_ignores_qcs_processor_availability(self) -> None:
        old = """<dpInput><trs><rules/></trs><dps><rules/></dps>
          <minimal>true</minimal><ferrumCsrDpContext>
            <construction>improved</construction>
            <graphEstimator>context-sensitive</graphEstimator>
            <qcsUsableRules>false</qcsUsableRules>
          </ferrumCsrDpContext></dpInput>"""
        current = old.replace(
            "<qcsUsableRules>false</qcsUsableRules>",
            "<qcsUsableRules>true</qcsUsableRules>",
        )
        self.assertEqual(
            EXTRACT.runtime_state_signature(old),
            EXTRACT.runtime_state_signature(current),
        )

    def test_muterm_signature_ignores_checker_generated_map_entries(self) -> None:
        common = """<dpInput><trs><rules/></trs><dps><rules/></dps>
          <strategy><contextSensitive>
            <replacementMapEntry><name>f</name><arity>1</arity><position>1</position></replacementMapEntry>
          {extra}</contextSensitive></strategy><minimal>true</minimal>
          <ferrumCsrDpContext><construction>muterm-unhiding</construction>
            <graphEstimator>ordinary</graphEstimator></ferrumCsrDpContext></dpInput>"""
        live = common.format(extra="")
        checker = common.format(extra="""
            <replacementMapEntry><sharp><name>f</name></sharp><arity>1</arity><position>1</position></replacementMapEntry>
            <replacementMapEntry><name>__CSR_U0</name><arity>1</arity></replacementMapEntry>
        """)
        self.assertEqual(
            EXTRACT.runtime_state_signature(live),
            EXTRACT.runtime_state_signature(checker),
        )

    def test_adjacent_event_identity_prefers_solved_event(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            proof = root / "proof.cpf.xml"
            proof.write_text("<certificationProblem />", encoding="utf-8")
            events = [
                {
                    "problem_id": "CSR_04/first.ari",
                    "category": "TRS_Contextsensitive",
                    "outcome": "failed",
                },
                {
                    "problem_id": (
                        "../TPDB-ARI/TRS_Contextsensitive/CSR_04/Ex1_GM03.ari"
                    ),
                    "category": "TRS_Contextsensitive",
                    "outcome": "solved",
                },
            ]
            (root / "events.jsonl").write_text(
                "".join(json.dumps(event) + "\n" for event in events),
                encoding="utf-8",
            )

            self.assertEqual(
                EXTRACT.adjacent_event_identity(proof),
                (
                    "TRS_Contextsensitive/CSR_04/Ex1_GM03.ari",
                    "TRS_Contextsensitive",
                ),
            )

    def test_generated_qdp_to_srs_event_keeps_root_benchmark_identity(self) -> None:
        self.assertEqual(
            EXTRACT.problem_identity(
                "TRS_Standard/Zantema_05/z12.ari#qdp-to-srs"
            ),
            "TRS_Standard/Zantema_05/z12.ari",
        )
        # A literal sharp in the actual benchmark filename is not a generated
        # child suffix and must remain part of the identity.
        self.assertEqual(
            EXTRACT.problem_identity("TRS_Standard/AG01/#3.15.ari"),
            "TRS_Standard/AG01/#3.15.ari",
        )

    def test_qdp_to_srs_child_is_reconstructed_as_an_independent_trs(self) -> None:
        source = ET.fromstring("""
          <input><dpInput><trs><rules/></trs><dps><rules>
            <rule>
              <funapp><sharp><name>f</name></sharp><var>x</var>
                <funapp><name>a</name><funapp><name>b</name><var>y</var></funapp></funapp>
              </funapp>
              <funapp><sharp><name>f</name></sharp>
                <funapp><name>a</name><funapp><name>b</name><var>x</var></funapp></funapp>
                <var>y</var>
              </funapp>
            </rule>
            <rule>
              <funapp><sharp><name>f</name></sharp><funapp><name>a</name><var>x</var></funapp><var>y</var></funapp>
              <funapp><sharp><name>f</name></sharp><var>x</var><funapp><name>a</name><var>y</var></funapp></funapp>
            </rule>
          </rules></dps><minimal>true</minimal></dpInput></input>
        """)

        child = child_input_for(
            ET.fromstring("<qdpToSrs/>"),
            ET.fromstring("<trsTerminationProof/>"),
            source,
        )[0]

        self.assertIsNotNone(child)
        xml = ET.tostring(child, encoding="unicode")
        self.assertIn("<trsInput>", xml)
        self.assertIn("<name>a</name>", xml)
        self.assertIn("<name>b</name>", xml)
        self.assertEqual(xml.count("<rule>"), 1)

    def test_flat_collector_filename_contributes_only_its_category(self) -> None:
        proof = Path(
            "/tmp/per-problem/"
            "TRS_Contextsensitive__CSR_04__Ex1_GM03.cpf.xml"
        )
        self.assertEqual(
            EXTRACT.proof_problem_identity(proof, "CSR_04/Ex1_GM03.ari"),
            "TRS_Contextsensitive/CSR_04/Ex1_GM03.ari",
        )

    def test_flat_residual_proof_uses_result_category_hint(self) -> None:
        proof = Path("/tmp/standalone-residual/proof.cpf.xml")
        self.assertEqual(
            EXTRACT.proof_problem_identity(
                proof,
                "Transformed_CSR_innermost_04/OvConsOS_complete_noand_GM.ari",
                "TRS_Innermost",
            ),
            (
                "TRS_Innermost/Transformed_CSR_innermost_04/"
                "OvConsOS_complete_noand_GM.ari"
            ),
        )

    def test_flat_residual_unknown_category_preserves_event_identity(self) -> None:
        proof = Path("/tmp/standalone-residual/proof.cpf.xml")
        self.assertEqual(
            EXTRACT.proof_problem_identity(
                proof, "/tmp/live-dp-state.xml", "unknown"
            ),
            "/tmp/live-dp-state.xml",
        )

    def test_flat_collector_event_file_is_discovered(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            proof = root / "TRS_Standard__A__b.cpf.xml"
            events = root / "TRS_Standard__A__b.processor-events.jsonl"
            proof.write_text("<certificationProblem/>", encoding="utf-8")
            events.write_text("{}\n", encoding="utf-8")
            self.assertEqual(EXTRACT.adjacent_event_file(proof), events)
            self.assertIn(events, EXTRACT.runtime_event_paths([root]))

    def test_unique_live_exact_atom_preserves_typed_reduction_wrapper(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory) / "TRS_Contextsensitive" / "CSR_04" / "case"
            root.mkdir(parents=True)
            proof = root / "proof.xml"
            proof.write_text("<certificationProblem/>", encoding="utf-8")
            atom = "exact-rat-natural-poly(hex=5b322c312c5b5d5d)"
            (root / "events.jsonl").write_text(
                json.dumps(
                    {
                        "problem_id": "CSR_04/case.ari",
                        "category": "TRS_Contextsensitive",
                        "outcome": "transformed",
                        "processor": atom,
                        "input": {"problem_key": "live-key"},
                    }
                )
                + "\n",
                encoding="utf-8",
            )
            rows = [
                {
                    "metadata": {
                        "processor_tag": "redPairProc",
                        "runtime_raw_problem_key": "live-key",
                    }
                }
            ]

            EXTRACT.bind_runtime_exact_reduction_atoms(
                rows, proof, "CSR_04/case.ari"
            )

            self.assertEqual(rows[0]["metadata"]["strategy_atom"], atom)

    def test_graph_binding_uses_semantic_pairs_across_duplicate_reindexing(self) -> None:
        def graph_atom(pair_names, components):
            rules = "".join(
                f"<rule><funapp><name>{name}</name></funapp>"
                f"<funapp><name>{name}</name></funapp></rule>"
                for name in pair_names
            )
            source = (
                "<dpInput><trs><rules/></trs><dps><rules>"
                f"{rules}</rules></dps><minimal>true</minimal></dpInput>"
            )
            payload = json.dumps([source, components], separators=(",", ":"))
            return f"exact-graph(hex={payload.encode().hex()})"

        archived = graph_atom(
            ["a", "b", "b", "c"],
            [[[0], True], [[1, 2], True], [[3], False]],
        )
        live = graph_atom(
            ["a", "b", "b", "c"],
            [[[2, 1], True], [[1], False], [[0], True]],
        )
        self.assertFalse(EXTRACT.exact_graph_same_step(archived, live))
        self.assertEqual(
            EXTRACT.exact_graph_cyclic_shape(archived),
            EXTRACT.exact_graph_cyclic_shape(live),
        )

        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory) / "TRS_Innermost" / "Suite" / "case"
            root.mkdir(parents=True)
            proof = root / "proof.xml"
            proof.write_text("<certificationProblem/>", encoding="utf-8")
            (root / "events.jsonl").write_text(
                json.dumps(
                    {
                        "problem_id": "Suite/case.ari",
                        "category": "TRS_Innermost",
                        "outcome": "transformed",
                        "processor": live,
                        "input": {"problem_key": "live-key"},
                    }
                )
                + "\n",
                encoding="utf-8",
            )
            rows = [
                {
                    "metadata": {
                        "processor_tag": "depGraphProc",
                        "runtime_raw_problem_key": "live-key",
                        "strategy_atom": archived,
                    },
                    "input": {"problem_xml": "<input/>"},
                    "output_xml": "<depGraphProc/>",
                }
            ]

            EXTRACT.bind_runtime_exact_graph_atoms(
                rows, proof, "Suite/case.ari"
            )

            self.assertEqual(rows[0]["metadata"]["strategy_atom"], live)
            self.assertTrue(
                rows[0]["metadata"]["runtime_exact_graph_atom_bound"]
            )
            original = rows[0]["metadata"]["strategy_atom"]
            EXTRACT.rebind_rows_to_runtime_inputs(
                rows,
                {
                    "live-key": (
                        "<input><dpInput><trs><rules/></trs><dps><rules/>"
                        "</dps><minimal>true</minimal></dpInput></input>"
                    )
                },
            )
            self.assertEqual(rows[0]["metadata"]["strategy_atom"], original)

    def test_unique_model_and_core_bind_portable_red_pair_to_live_state(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory) / "TRS_Contextsensitive" / "CSR_04" / "case"
            root.mkdir(parents=True)
            proof = root / "proof.xml"
            proof.write_text("<certificationProblem/>", encoding="utf-8")
            atom = "exact-poly(hex=5b5b226623222c302c5b315d5d5d)"
            problem = (
                "<dpInput><trs><rules/></trs><dps><rules/></dps>"
                "<minimal>false</minimal></dpInput>"
            )
            (root / "events.jsonl").write_text(
                json.dumps(
                    {
                        "problem_id": "CSR_04/case.ari",
                        "category": "TRS_Contextsensitive",
                        "outcome": "solved",
                        "processor": atom,
                        "input": {
                            "problem_key": "live-key",
                            "cpf": problem,
                        },
                    }
                )
                + "\n",
                encoding="utf-8",
            )
            rows = [
                {
                    "metadata": {
                        "processor_tag": "monoRedPairProc",
                        "portable_model_atom": atom,
                    },
                    "input": {"problem_xml": f"<input>{problem}</input>"},
                    "output_xml": "<monoRedPairProc/>",
                }
            ]

            EXTRACT.bind_runtime_exact_reduction_atoms(
                rows, proof, "CSR_04/case.ari"
            )

            self.assertEqual(
                rows[0]["metadata"]["runtime_raw_problem_key"], "live-key"
            )
            self.assertTrue(rows[0]["metadata"]["runtime_model_state_bound"])

    def test_srs_loop_uses_word_search_atom(self) -> None:
        self.assertEqual(
            EXTRACT.typed_strategy_atom("nontermination(loop)", "srs"),
            "nontermination(srs-loop)",
        )
        self.assertEqual(
            EXTRACT.typed_strategy_atom(
                "nontermination(loop)", "trs", "SRS_Standard"
            ),
            "nontermination(srs-loop)",
        )
        self.assertEqual(
            EXTRACT.typed_strategy_atom("nontermination(loop)", "trs"),
            "nontermination(loop)",
        )

    def test_csr_loop_uses_context_sensitive_search_atom(self) -> None:
        self.assertEqual(
            EXTRACT.typed_strategy_atom("nontermination(loop)", "csr"),
            "csr-loop",
        )
        self.assertEqual(
            EXTRACT.typed_strategy_atom(
                "nontermination(loop)", "trs", "TRS_Contextsensitive"
            ),
            "csr-loop",
        )

    def test_rule_removal_child_subtracts_the_recorded_strict_rules(self) -> None:
        current = ET.fromstring("""
            <input><trsInput><trs><rules>
              <rule><funapp><name>f</name><var>x</var></funapp><funapp><name>|0|</name></funapp></rule>
              <rule><funapp><name>g</name></funapp><funapp><name>b</name></funapp></rule>
            </rules></trs></trsInput></input>
        """)
        processor = ET.fromstring("""
            <ruleRemoval><trs><rules>
              <rule><funapp><name>f</name><var>renamed</var></funapp><funapp><name>0</name></funapp></rule>
            </rules></trs><trsTerminationProof><rIsEmpty/></trsTerminationProof></ruleRemoval>
        """)
        child = next(
            element
            for element in processor
            if element.tag == "trsTerminationProof"
        )

        residual, error = child_input_for(processor, child, current)

        self.assertIsNone(error)
        self.assertIsNotNone(residual)
        residual_xml = ET.tostring(inner_input(residual), encoding="unicode")
        self.assertNotIn("<name>f</name>", residual_xml)
        self.assertIn("<name>g</name>", residual_xml)

    def test_ignore_relative_part_child_drops_only_weak_rules(self) -> None:
        current = ET.fromstring("""
            <input><trsInput><trs><rules>
              <rule><funapp><name>f</name></funapp><funapp><name>f</name></funapp></rule>
            </rules></trs><relativeRules><rules>
              <rule><funapp><name>g</name></funapp><funapp><name>g</name></funapp></rule>
            </rules></relativeRules></trsInput></input>
        """)
        processor = ET.fromstring("""
            <ignoreRelativePart><trsNonterminationProof><loop/></trsNonterminationProof>
            </ignoreRelativePart>
        """)
        child = next(iter(processor))

        residual, error = child_input_for(processor, child, current)

        self.assertIsNone(error)
        self.assertIsNotNone(residual)
        residual_xml = ET.tostring(inner_input(residual), encoding="unicode")
        self.assertIn("<name>f</name>", residual_xml)
        self.assertNotIn("relativeRules", residual_xml)
        self.assertNotIn("<name>g</name>", residual_xml)

    def test_relative_rule_removal_subtracts_from_strict_and_weak_parts(self) -> None:
        current = ET.fromstring("""
            <input><trsInput><trs><rules>
              <rule><funapp><name>f</name></funapp><funapp><name>a</name></funapp></rule>
              <rule><funapp><name>h</name></funapp><funapp><name>c</name></funapp></rule>
            </rules></trs><relativeRules><rules>
              <rule><funapp><name>g</name></funapp><funapp><name>b</name></funapp></rule>
              <rule><funapp><name>h</name></funapp><funapp><name>c</name></funapp></rule>
            </rules></relativeRules></trsInput></input>
        """)
        processor = ET.fromstring("""
            <ruleRemoval><trs><rules>
              <rule><funapp><name>f</name></funapp><funapp><name>a</name></funapp></rule>
              <rule><funapp><name>g</name></funapp><funapp><name>b</name></funapp></rule>
            </rules></trs><trsTerminationProof><rIsEmpty/></trsTerminationProof></ruleRemoval>
        """)
        child = next(element for element in processor if element.tag == "trsTerminationProof")

        residual, error = child_input_for(processor, child, current)

        self.assertIsNone(error)
        self.assertIsNotNone(residual)
        residual_xml = ET.tostring(inner_input(residual), encoding="unicode")
        self.assertNotIn("<name>f</name>", residual_xml)
        self.assertNotIn("<name>g</name>", residual_xml)
        self.assertEqual(residual_xml.count("<name>h</name>"), 2)

    def test_relative_bounds_moves_removed_strict_rules_to_weak(self) -> None:
        current = ET.fromstring("""
            <input><trsInput><trs><rules>
              <rule><funapp><name>f</name></funapp><funapp><name>a</name></funapp></rule>
              <rule><funapp><name>g</name></funapp><funapp><name>b</name></funapp></rule>
            </rules></trs><relativeRules><rules>
              <rule><funapp><name>w</name></funapp><funapp><name>c</name></funapp></rule>
            </rules></relativeRules></trsInput></input>
        """)
        processor = ET.fromstring("""
            <relativeBounds><bounds/><trs><rules>
              <rule><funapp><name>f</name></funapp><funapp><name>a</name></funapp></rule>
            </rules></trs><trsTerminationProof><rIsEmpty/></trsTerminationProof></relativeBounds>
        """)
        child = next(element for element in processor if element.tag == "trsTerminationProof")

        residual, error = child_input_for(processor, child, current)

        self.assertIsNone(error)
        self.assertIsNotNone(residual)
        inner = inner_input(residual)
        strict_xml = ET.tostring(next(child for child in inner if child.tag == "trs"), encoding="unicode")
        weak_xml = ET.tostring(next(child for child in inner if child.tag == "relativeRules"), encoding="unicode")
        self.assertNotIn("<name>f</name>", strict_xml)
        self.assertIn("<name>g</name>", strict_xml)
        self.assertIn("<name>f</name>", weak_xml)
        self.assertIn("<name>w</name>", weak_xml)

    def test_switch_to_trs_preserves_strict_and_weak_dp_parts(self) -> None:
        rule = lambda left, right: (
            f"<rule><funapp><name>{left}</name></funapp>"
            f"<funapp><name>{right}</name></funapp></rule>"
        )
        current = ET.fromstring(f"""
          <input><dpInput>
            <trs><rules>{rule('r1', 'r2')}{rule('w1', 'w2')}</rules></trs>
            <dps><rules>{rule('p1', 'p2')}{rule('q1', 'q2')}</rules></dps>
            <ferrumWeakDps><rules>{rule('q1', 'q2')}</rules></ferrumWeakDps>
            <minimal>true</minimal>
            <ferrumDpStateContext><strictRules><rules>
              {rule('r1', 'r2')}
            </rules></strictRules></ferrumDpStateContext>
          </dpInput></input>
        """)
        processor = ET.fromstring(
            "<switchToTRS><trsTerminationProof><rIsEmpty/>"
            "</trsTerminationProof></switchToTRS>"
        )
        child_proof = next(iter(processor))

        residual, error = child_input_for(processor, child_proof, current)

        self.assertIsNone(error)
        self.assertIsNotNone(residual)
        inner = inner_input(residual)
        strict_xml = ET.tostring(
            next(child for child in inner if child.tag == "trs"),
            encoding="unicode",
        )
        weak_xml = ET.tostring(
            next(child for child in inner if child.tag == "relativeRules"),
            encoding="unicode",
        )
        self.assertIn("<name>p1</name>", strict_xml)
        self.assertIn("<name>r1</name>", strict_xml)
        self.assertNotIn("<name>q1</name>", strict_xml)
        self.assertNotIn("<name>w1</name>", strict_xml)
        self.assertIn("<name>q1</name>", weak_xml)
        self.assertIn("<name>w1</name>", weak_xml)
        self.assertNotIn("<name>p1</name>", weak_xml)
        self.assertNotIn("<name>r1</name>", weak_xml)

    def test_flat_context_closure_child_preserves_relative_partition(self) -> None:
        current = ET.fromstring("""
            <input><trsInput><trs><rules>
              <rule><funapp><name>f</name></funapp><funapp><name>a</name></funapp></rule>
            </rules></trs><relativeRules><rules>
              <rule><funapp><name>g</name></funapp><funapp><name>b</name></funapp></rule>
            </rules></relativeRules></trsInput></input>
        """)
        processor = ET.fromstring("""
            <flatContextClosure><flatContexts/>
              <trs><rules>
                <rule><funapp><name>f</name></funapp><funapp><name>a</name></funapp></rule>
                <rule><funapp><name>g</name></funapp><funapp><name>b</name></funapp></rule>
              </rules></trs>
              <trsTerminationProof><rIsEmpty/></trsTerminationProof>
            </flatContextClosure>
        """)
        child = next(
            element for element in processor if element.tag == "trsTerminationProof"
        )

        residual, error = child_input_for(processor, child, current)

        self.assertIsNone(error)
        self.assertIsNotNone(residual)
        residual_xml = ET.tostring(inner_input(residual), encoding="unicode")
        self.assertIn("<name>f</name>", residual_xml)
        self.assertIn("<name>g</name>", residual_xml)
        self.assertIn("relativeRules", residual_xml)

        row = {
            "metadata": {
                "processor_tag": "flatContextClosure",
                "strategy_atom": None,
            },
            "input": {"problem_xml": ET.tostring(current, encoding="unicode")},
            "output_xml": ET.tostring(processor, encoding="unicode"),
        }
        self.assertEqual(
            EXTRACT.strategy_atom(row), "relative-flat-context-closure"
        )

    def test_relative_semantic_labeling_preserves_exact_model_and_child(self) -> None:
        current = ET.fromstring("""
            <input><trsInput><trs><rules><rule>
              <funapp><name>f</name><var>x</var></funapp><var>x</var>
            </rule></rules></trs><relativeRules><rules/></relativeRules></trsInput></input>
        """)
        processor = ET.fromstring("""
            <semlab><model><finiteModel><carrierSize>2</carrierSize>
              <interpret><name>f</name><arity>1</arity><arithFunction>
                <sum><natural>1</natural><variable>1</variable></sum>
              </arithFunction></interpret>
            </finiteModel></model><trs><rules><rule>
              <funapp><labeledSymbol><name>f</name><numberLabel><number>0</number>
              </numberLabel></labeledSymbol><var>x</var></funapp><var>x</var>
            </rule></rules></trs><trsTerminationProof><rIsEmpty/></trsTerminationProof></semlab>
        """)
        child = next(element for element in processor if element.tag == "trsTerminationProof")
        residual, error = child_input_for(processor, child, current)
        self.assertIsNone(error)
        residual_xml = ET.tostring(inner_input(residual), encoding="unicode")
        self.assertIn("labeledSymbol", residual_xml)
        self.assertIn("relativeRules", residual_xml)

        row = {
            "metadata": {"processor_tag": "semlab", "strategy_atom": None},
            "input": {"problem_xml": ET.tostring(current, encoding="unicode")},
            "output_xml": ET.tostring(processor, encoding="unicode"),
        }
        atom = EXTRACT.strategy_atom(row)
        self.assertTrue(atom.startswith("exact-relative-semantic-labeling(carrier-size=2,hex="))
        encoded = atom.split("hex=", 1)[1][:-1]
        self.assertEqual(
            json.loads(bytes.fromhex(encoded)),
            [["f", 1, {"Sum": [{"Constant": 1}, {"Argument": 0}]}]],
        )

    def test_labeled_interpretation_symbol_uses_runtime_spelling(self) -> None:
        interpretation = ET.fromstring("""
          <interpret><labeledSymbol><name>f</name><numberLabel>
            <number>0</number><number>1</number>
          </numberLabel></labeledSymbol></interpret>
        """)
        self.assertEqual(
            EXTRACT.interpretation_symbol_name(interpretation),
            "__ferrum_sl__66__0_1",
        )

    def test_max_polynomial_witness_preserves_all_affine_alternatives(self) -> None:
        fragment = """
          <redPairUrProc><maxPoly>
            <interpret><sharp><name>f</name></sharp><arity>2</arity>
              <max>
                <sum><constant>1</constant><variable>1</variable></sum>
                <sum><variable>1</variable><variable>2</variable></sum>
              </max>
            </interpret>
            <interpret><name>a</name><arity>0</arity><constant>2</constant></interpret>
          </maxPoly><dps><rules/></dps><dpProof><pIsEmpty/></dpProof></redPairUrProc>
        """
        self.assertEqual(
            EXTRACT.max_polynomial_witness(fragment),
            [
                ["f#", [[1, [1, 0]], [0, [1, 1]]]],
                ["a", [[2, []]]],
            ],
        )
        row = {
            "metadata": {"processor_tag": "redPairUrProc", "strategy_atom": None},
            "input": {"problem_xml": "<input><dpInput/></input>"},
            "output_xml": fragment,
        }
        atom = EXTRACT.strategy_atom(row)
        self.assertIsNotNone(atom)
        assert atom is not None
        self.assertTrue(atom.startswith("exact-max-poly(hex="))

    def test_top_level_kbo_witness_preserves_weights_and_rejects_other_w0(self) -> None:
        fragment = '''<ruleRemoval><knuthBendixOrder><w0>1</w0><precedenceWeight>
          <precedenceWeightEntry><name>f</name><precedence>9</precedence><weight>0</weight></precedenceWeightEntry>
          <precedenceWeightEntry><name>c</name><precedence>2</precedence><weight>3</weight></precedenceWeightEntry>
          </precedenceWeight></knuthBendixOrder></ruleRemoval>'''
        self.assertEqual(EXTRACT.top_level_kbo_witness(fragment), [['f', 'c'], {'f': 0, 'c': 1}, {'f': 0, 'c': 3}])
        self.assertIsNone(EXTRACT.top_level_kbo_witness(fragment.replace('<w0>1</w0>', '<w0>2</w0>')))
        self.assertIsNone(EXTRACT.top_level_kbo_witness(fragment.replace('</knuthBendixOrder>', '<argumentFilter/></knuthBendixOrder>')))

    def test_path_order_witness_preserves_precedence_status_and_filter(self) -> None:
        fragment = """
          <redPairUrProc><recursivePathOrder><statusPrecedence>
            <statusPrecedenceEntry><name>f</name><arity>2</arity>
              <precedence>7</precedence><mul/></statusPrecedenceEntry>
            <statusPrecedenceEntry><sharp><name>g</name></sharp><arity>1</arity>
              <precedence>3</precedence><lex/></statusPrecedenceEntry>
          </statusPrecedence><argumentFilter>
            <argumentFilterEntry><name>f</name><arity>2</arity>
              <nonCollapsing><position>2</position><position>1</position></nonCollapsing>
            </argumentFilterEntry>
            <argumentFilterEntry><sharp><name>g</name></sharp><arity>1</arity>
              <collapsing>1</collapsing></argumentFilterEntry>
          </argumentFilter></recursivePathOrder><dps><rules/></dps>
          <dpProof><pIsEmpty/></dpProof></redPairUrProc>
        """
        self.assertEqual(
            EXTRACT.path_order_witness(fragment),
            [
                "Rpo",
                {"f": "Rpo", "g#": "Lpo"},
                ["f", "g#"],
                {"f": 0, "g#": 1},
                {
                    "f": {"NonCollapsing": [1, 0]},
                    "g#": {"Collapsing": 0},
                },
            ],
        )

    def test_relative_nontermination_root_is_an_executable_loop_atom(self) -> None:
        root = ET.fromstring("""
            <certificationProblem>
              <input><trsInput><trs><rules/></trs><relativeRules><rules/></relativeRules>
              </trsInput></input>
              <proof><relativeNonterminationProof><ignoreRelativePart>
                <trsNonterminationProof><loop/></trsNonterminationProof>
              </ignoreRelativePart></relativeNonterminationProof></proof>
            </certificationProblem>
        """)

        row = EXTRACT.root_direct_processor_row(root)

        self.assertIsNotNone(row)
        assert row is not None
        self.assertEqual(row["metadata"]["processor_tag"], "ignoreRelativePart")
        self.assertEqual(EXTRACT.strategy_atom(row), "nontermination(loop)")

    def test_reads_claimed_cpf_answer_polarity(self) -> None:
        self.assertEqual(
            EXTRACT.proof_polarity(
                ET.fromstring("<certificationProblem><answer><yes/></answer></certificationProblem>")
            ),
            "YES",
        )
        self.assertEqual(
            EXTRACT.proof_polarity(
                ET.fromstring("<certificationProblem><answer><no/></answer></certificationProblem>")
            ),
            "NO",
        )

    def test_direct_proof_file_is_discovered(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            proof = Path(directory) / "proof.xml"
            proof.write_text("<certificationProblem/>", encoding="utf-8")
            self.assertEqual(EXTRACT.proof_files(proof), {proof})
            self.assertEqual(EXTRACT.proof_files(Path(directory)), {proof})

    def test_termcomp_status_wrapped_cpf_is_discovered(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            proof = Path(directory) / "benchmark_1__solver_2.txt"
            proof.write_text(
                "YES\n<?xml version='1.0'?><certificationProblem/>",
                encoding="utf-8",
            )
            log = Path(directory) / "stdout.txt"
            log.write_text("YES\nplain solver log", encoding="utf-8")
            self.assertEqual(EXTRACT.proof_files(Path(directory)), {proof})

    def test_selects_unresolved_and_uncertified_details_roots(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            details = Path(directory) / "details.json"
            details.write_text(
                json.dumps(
                    [
                        {"path": "../TPDB-ARI/TRS_Standard/A/a.ari", "status": "timeout", "certified": False},
                        {"path": "../TPDB-ARI/TRS_Standard/B/b.ari", "status": "yes", "certified": False},
                        {"path": "../TPDB-ARI/TRS_Standard/C/c.ari", "status": "yes", "certified": True},
                    ]
                ),
                encoding="utf-8",
            )
            self.assertEqual(
                EXTRACT.unresolved_problem_paths_from_details(
                    details, {"timeout"}, True
                ),
                {
                    "TRS_Standard/A/a.ari",
                    "TRS_Standard/B/b.ari",
                },
            )

    def test_run_relative_identity_is_qualified_from_proof_path(self) -> None:
        proof = Path("runs/TRS_Standard/Transformed_CSR_04/Example/proof.cpf.xml")
        self.assertEqual(
            EXTRACT.proof_problem_identity(
                proof, "Transformed_CSR_04/Example.ari"
            ),
            "TRS_Standard/Transformed_CSR_04/Example.ari",
        )

    def test_certified_runtime_atoms_use_qualified_problem_identity(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            proof = (
                Path(directory)
                / "TRS_Standard"
                / "Transformed_CSR_04"
                / "Example"
                / "proof.cpf.xml"
            )
            proof.parent.mkdir(parents=True)
            proof.write_text(
                "<certificationProblem><proof><trsTerminationProof>"
                "<rIsEmpty/></trsTerminationProof></proof></certificationProblem>",
                encoding="utf-8",
            )
            proof.with_name("processor-events.jsonl").write_text(
                json.dumps(
                    {
                        "category": "TRS_Standard",
                        "level": "dependency-pair",
                        "outcome": "solved",
                        "problem_id": "Transformed_CSR_04/Example.ari",
                        "strategy_atom": "size-change",
                        "input": {
                            "problem_key": "live-child",
                            "cpf": "<dpInput><trs><rules/></trs>"
                            "<dps><rules/></dps><minimal>true</minimal></dpInput>",
                        },
                    }
                )
                + "\n",
                encoding="utf-8",
            )

            rows = EXTRACT.certified_runtime_atom_rows(
                proof, "Transformed_CSR_04/Example.ari"
            )

            self.assertEqual(len(rows), 1)
            self.assertEqual(
                rows[0]["metadata"]["runtime_raw_problem_key"], "live-child"
            )
            self.assertEqual(rows[0]["metadata"]["strategy_atom"], "size-change")

    def test_certified_runtime_atom_recovers_cpf_by_exact_state_key(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            proof = Path(directory) / "TRS_Standard" / "Example" / "proof.cpf.xml"
            proof.parent.mkdir(parents=True)
            proof.write_text(
                "<certificationProblem><proof><trsTerminationProof>"
                "<rIsEmpty/></trsTerminationProof></proof></certificationProblem>",
                encoding="utf-8",
            )
            cpf = (
                "<dpInput><trs><rules/></trs><dps><rules/></dps>"
                "<minimal>true</minimal></dpInput>"
            )
            events = [
                {
                    "category": "TRS_Standard",
                    "level": "dependency-pair",
                    "outcome": "failed",
                    "problem_id": "Example.ari",
                    "strategy_atom": "empty",
                    "input": {"problem_key": "child", "cpf": cpf},
                },
                {
                    "category": "TRS_Standard",
                    "level": "dependency-pair",
                    "outcome": "solved",
                    "problem_id": "Example.ari",
                    "strategy_atom": "size-change",
                    "input": {"problem_key": "child"},
                },
            ]
            proof.with_name("processor-events.jsonl").write_text(
                "\n".join(json.dumps(event) for event in events) + "\n",
                encoding="utf-8",
            )

            rows = EXTRACT.certified_runtime_atom_rows(proof, "Example.ari")

            self.assertEqual(len(rows), 1)
            self.assertFalse(rows[0]["metadata"]["runtime_atom_pool_only"])
            self.assertFalse(rows[0]["metadata"]["runtime_atom_external_hint"])
            self.assertTrue(rows[0]["metadata"]["runtime_atom_certified_source"])
            self.assertIn("<dpInput>", rows[0]["input"]["problem_xml"])

    def test_certified_runtime_atoms_qualify_flat_artifact_identity(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            proof = Path(directory) / "flat-run" / "proof.cpf.xml"
            proof.parent.mkdir(parents=True)
            proof.write_text(
                "<certificationProblem><proof><trsTerminationProof>"
                "<rIsEmpty/></trsTerminationProof></proof></certificationProblem>",
                encoding="utf-8",
            )
            proof.with_name("events.jsonl").write_text(
                json.dumps(
                    {
                        "category": "TRS_Innermost",
                        "level": "dependency-pair",
                        "outcome": "transformed",
                        "problem_id": "Transformed_CSR_innermost_04/Example.ari",
                        "strategy_atom": "usable-rules",
                        "input": {
                            "problem_key": "live-child",
                            "cpf": "<dpInput><trs><rules/></trs>"
                            "<dps><rules/></dps><minimal>true</minimal></dpInput>",
                        },
                    }
                )
                + "\n",
                encoding="utf-8",
            )

            rows = EXTRACT.certified_runtime_atom_rows(
                proof, "Transformed_CSR_innermost_04/Example.ari"
            )

            self.assertEqual(len(rows), 1)
            self.assertEqual(
                rows[0]["metadata"]["runtime_raw_problem_key"], "live-child"
            )
            self.assertTrue(
                rows[0]["metadata"]["runtime_atom_certified_source"]
            )

    def test_certified_runtime_atom_recovers_content_addressed_residual(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            proof = Path(directory) / "TRS_Innermost" / "Example" / "proof.cpf.xml"
            proof.parent.mkdir(parents=True)
            proof.write_text(
                "<certificationProblem><proof><trsTerminationProof>"
                "<rIsEmpty/></trsTerminationProof></proof></certificationProblem>",
                encoding="utf-8",
            )
            child = (
                "<dpInput><trs><rules/></trs><dps><rules/></dps>"
                "<minimal>true</minimal></dpInput>"
            )
            events = [
                {
                    "category": "TRS_Innermost",
                    "level": "dependency-pair",
                    "outcome": "transformed",
                    "problem_id": "Example.ari",
                    "strategy_atom": "usable-rules",
                    "input": {
                        "problem_key": "parent",
                        "cpf": child,
                    },
                    "witness": {
                        "kind": "problem_states",
                        "residuals": [
                            {
                                "problem_key": "child",
                                "cpf": child,
                                "format": "cpf3",
                            }
                        ],
                    },
                },
                {
                    "category": "TRS_Innermost",
                    "level": "dependency-pair",
                    "outcome": "solved",
                    "problem_id": "Example.ari",
                    "strategy_atom": "size-change",
                    "input": {
                        "problem_key": "child",
                        "cpf": None,
                        "content_addressed": True,
                    },
                },
            ]
            proof.with_name("processor-events.jsonl").write_text(
                "\n".join(json.dumps(event) for event in events) + "\n",
                encoding="utf-8",
            )

            rows = EXTRACT.certified_runtime_atom_rows(proof, "Example.ari")

            child_rows = [
                row
                for row in rows
                if row["metadata"]["runtime_raw_problem_key"] == "child"
            ]
            self.assertEqual(len(child_rows), 1)
            self.assertFalse(child_rows[0]["metadata"]["runtime_atom_pool_only"])
            self.assertTrue(
                child_rows[0]["metadata"]["runtime_atom_certified_source"]
            )
            self.assertIn("<dpInput>", child_rows[0]["input"]["problem_xml"])

    def test_certified_dp_loop_is_rebound_before_relative_search_switch(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            proof = Path(directory) / "TRS_Standard" / "Example" / "proof.cpf.xml"
            proof.parent.mkdir(parents=True)
            proof.write_text(
                "<certificationProblem><proof><trsNonterminationProof>"
                "<dpTrans><dpNonterminationProof><loop/></dpNonterminationProof>"
                "</dpTrans></trsNonterminationProof></proof></certificationProblem>",
                encoding="utf-8",
            )
            dp_input = (
                "<dpInput><trs><rules/></trs><dps><rules/></dps>"
                "<minimal>true</minimal></dpInput>"
            )
            relative_input = (
                "<relativeInput><trs><rules/></trs><relativeRules><rules/>"
                "</relativeRules></relativeInput>"
            )
            events = [
                {
                    "category": "TRS_Standard",
                    "level": "dependency-pair",
                    "outcome": "transformed",
                    "problem_id": "Example.ari",
                    "strategy_atom": "switch-to-trs",
                    "input": {"problem_key": "final-dp", "cpf": dp_input},
                },
                {
                    "category": "TRS_Standard",
                    "level": "top-level",
                    "outcome": "solved",
                    "problem_id": "Example.ari",
                    "strategy_atom": "nontermination(bounded-rewriting)",
                    "input": {
                        "problem_key": "relative-child",
                        "cpf": relative_input,
                    },
                },
            ]
            proof.with_name("processor-events.jsonl").write_text(
                "\n".join(json.dumps(event) for event in events) + "\n",
                encoding="utf-8",
            )

            rows = EXTRACT.certified_runtime_atom_rows(proof, "Example.ari")

            rebound = [
                row
                for row in rows
                if row["metadata"].get("runtime_terminal_dp_loop_rebound")
            ]
            self.assertEqual(len(rebound), 1)
            self.assertEqual(
                rebound[0]["metadata"]["runtime_raw_problem_key"], "final-dp"
            )
            self.assertEqual(
                rebound[0]["metadata"]["strategy_atom"],
                "nontermination(dp-loop)",
            )
            self.assertTrue(
                rebound[0]["metadata"]["runtime_atom_certified_source"]
            )
            self.assertNotIn(
                "relativeInput", rebound[0]["input"]["problem_xml"]
            )

    def test_certified_runtime_root_recipe_is_retained_as_complete_recipe(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            proof = Path(directory) / "TRS_Contextsensitive" / "Example" / "proof.cpf.xml"
            proof.parent.mkdir(parents=True)
            proof.write_text("<certificationProblem/>", encoding="utf-8")
            recipe = "csr-improved-dp(pipeline(graph; size-change))"
            proof.with_name("processor-events.jsonl").write_text(
                json.dumps(
                    {
                        "category": "TRS_Contextsensitive",
                        "level": "context-sensitive",
                        "outcome": "solved",
                        "problem_id": "Example.ari",
                        "strategy_atom": recipe,
                        "input": {
                            "problem_key": "live-root",
                            "cpf": "<trsInput><trs><rules/></trs></trsInput>",
                        },
                    }
                )
                + "\n",
                encoding="utf-8",
            )

            row = EXTRACT.certified_runtime_root_recipe_row(
                proof, "Example.ari", "live-root"
            )

            self.assertIsNotNone(row)
            assert row is not None
            self.assertEqual(
                row["metadata"]["strategy_atom"], EXTRACT.normalize_atom(recipe)
            )
            self.assertEqual(row["metadata"]["outcome"], "solved")
            self.assertTrue(row["metadata"]["preserve_composed_recipe"])
            self.assertIn("<trsInput>", row["input"]["problem_xml"])

    def test_certified_linear_csr_rule_removals_form_root_recipe(self) -> None:
        base = ["certificationProblem", "proof", "csrTerminationProof"]
        rows = []
        for index, atom in enumerate(("exact-poly(hex=00)", "exact-matrix(hex=11)")):
            rows.append(
                {
                    "metadata": {
                        "processor_tag": "csrRuleRemoval",
                        "strategy_atom": atom,
                        "path": base
                        + ["csrRuleRemoval"]
                        + ["csrTerminationProof", "csrRuleRemoval"] * index,
                    },
                    "input": {"problem_xml": "<trsInput/>"},
                    "output_xml": "<csrRuleRemoval/>",
                }
            )

        row = EXTRACT.certified_linear_root_recipe_row(
            rows, "<trsInput/>", "live-root"
        )

        self.assertIsNotNone(row)
        assert row is not None
        self.assertEqual(
            row["metadata"]["strategy_atom"],
            "exact-poly(hex=00);exact-matrix(hex=11)",
        )
        self.assertEqual(row["metadata"]["outcome"], "solved")
        self.assertTrue(row["metadata"]["preserve_composed_recipe"])

    def test_certified_linear_root_recipe_rejects_branch_or_mixed_chain(self) -> None:
        base = ["certificationProblem", "proof", "csrTerminationProof"]
        branch = [
            {
                "metadata": {
                    "processor_tag": "csrRuleRemoval",
                    "strategy_atom": "exact-poly(hex=00)",
                    "path": base + ["csrRuleRemoval"],
                }
            },
            {
                "metadata": {
                    "processor_tag": "csrRuleRemoval",
                    "strategy_atom": "exact-poly(hex=11)",
                    "path": base + ["csrRuleRemoval"],
                }
            },
        ]
        mixed = [
            branch[0],
            {
                "metadata": {
                    "processor_tag": "dpTrans",
                    "strategy_atom": "dp",
                    "path": base
                    + ["csrRuleRemoval", "csrTerminationProof", "dpTrans"],
                }
            },
        ]

        self.assertIsNone(
            EXTRACT.certified_linear_root_recipe_row(
                branch, "<trsInput/>", "live-root"
            )
        )
        self.assertIsNone(
            EXTRACT.certified_linear_root_recipe_row(
                mixed, "<trsInput/>", "live-root"
            )
        )

    def test_exact_subterm_is_not_safe_for_root_local_pooling(self) -> None:
        self.assertFalse(
            EXTRACT.root_local_atom_is_portable("exact-subterm(hex=00)")
        )
        self.assertTrue(EXTRACT.root_local_atom_is_portable("subterm"))

    def test_exact_dp_transform_is_guarded_for_root_local_pooling(self) -> None:
        # The executable processor independently reconstructs the selected
        # native transformation and compares its complete child with the
        # retained residual.  Pooling only offers the witness; it cannot make
        # a source-inapplicable transformation succeed.
        self.assertTrue(
            EXTRACT.root_local_atom_is_portable("exact-dp-transform(hex=00)")
        )

    def test_exact_usable_rules_is_safe_for_root_local_pooling(self) -> None:
        # Ferrum recomputes the applicable CeTA closure against every live
        # pair/rule state before accepting the archived usable-rule superset.
        self.assertTrue(
            EXTRACT.root_local_atom_is_portable("exact-usable-rules(hex=00)")
        )

    def test_source_bound_semantic_labeling_is_safe_for_root_local_pooling(self) -> None:
        self.assertTrue(
            EXTRACT.root_local_atom_is_portable(
                "exact-semantic-labeling(hex=00)"
            )
        )

    def test_root_local_exact_atom_shape_gate(self) -> None:
        def dp(rules: int, pairs: int) -> str:
            rule = "<rule><var>X</var><var>X</var></rule>"
            return (
                "<dpInput><trs><rules>"
                + rule * rules
                + "</rules></trs><dps><rules>"
                + rule * pairs
                + "</rules></dps><minimal>true</minimal></dpInput>"
            )

        self.assertTrue(
            EXTRACT.root_local_atom_shape_compatible(
                "exact-red-pair(hex=00)", dp(3, 4), dp(3, 4)
            )
        )
        self.assertFalse(
            EXTRACT.root_local_atom_shape_compatible(
                "exact-red-pair(hex=00)", dp(3, 4), dp(3, 5)
            )
        )
        self.assertFalse(
            EXTRACT.root_local_atom_shape_compatible(
                "exact-semantic-labeling(hex=00)", dp(3, 4), dp(3, 5)
            )
        )
        self.assertTrue(
            EXTRACT.root_local_atom_shape_compatible(
                "exact-dp-transform(hex=00)", dp(3, 4), dp(3, 4)
            )
        )
        self.assertFalse(
            EXTRACT.root_local_atom_shape_compatible(
                "exact-dp-transform(hex=00)", dp(3, 4), dp(3, 5)
            )
        )
        self.assertTrue(
            EXTRACT.root_local_atom_shape_compatible(
                "exact-graph(hex=00)", dp(3, 4), dp(3, 5)
            )
        )
        self.assertTrue(
            EXTRACT.root_local_atom_is_portable(
                "forward-instantiate(max-per-pair=1)"
            )
        )

    def test_live_root_key_ignores_stale_appended_invocation(self) -> None:
        root = ET.fromstring(
            """
            <certificationProblem>
              <input><trsInput><trs><rules/></trs></trsInput></input>
              <proof><trsTerminationProof><dpTrans>
                <dps><rules/></dps><dpProof><pIsEmpty/></dpProof>
              </dpTrans></trsTerminationProof></proof>
            </certificationProblem>
            """
        )
        with tempfile.TemporaryDirectory() as directory:
            proof = Path(directory) / "proof.cpf.xml"
            proof.write_text("unused", encoding="utf-8")
            proof.with_name("processor-events.jsonl").write_text(
                "\n".join(
                    [
                        '{"level":"top-level","outcome":"failed",'
                        '"strategy_atom":"dp","input":{"problem_key":"stale",'
                        '"cpf":"<trsInput><trs><rules><rule/></rules></trs></trsInput>"}}',
                        '{"level":"top-level","outcome":"failed",'
                        '"strategy_atom":"utility-guidance","input":{'
                        '"problem_key":"current","cpf":"<trsInput><trs><rules/></trs></trsInput>"}}',
                        '{"level":"top-level","outcome":"solved",'
                        '"strategy_atom":"dp(graph;size-change)",'
                        '"input":{"problem_key":"current","cpf":null}}',
                    ]
                )
                + "\n",
                encoding="utf-8",
            )

            key = EXTRACT.live_root_problem_key(root, proof)

        self.assertEqual(key, "current")

    def test_nested_csr_state_rejects_pair_only_runtime_alias(self) -> None:
        row = {
            "metadata": {"processor_tag": "sizeChangeProc"},
            "input": {
                "problem_xml": """
                <dpInput><trs><rules/></trs><dps><rules><rule/></rules></dps>
                  <strategy><contextSensitive><replacementMapEntry>
                    <name>f</name><arity>1</arity><position>1</position>
                  </replacementMapEntry></contextSensitive></strategy>
                  <minimal>true</minimal><ferrumCsrDpContext>
                    <construction>improved</construction>
                  </ferrumCsrDpContext></dpInput>
                """
            },
        }
        with tempfile.TemporaryDirectory() as directory:
            proof = Path(directory) / "proof.cpf.xml"
            proof.write_text("unused", encoding="utf-8")
            proof.with_name("processor-events.jsonl").write_text(
                json.dumps(
                    {
                        "input": {
                            "problem_key": "runtime-key",
                            "cpf": """
                            <dpInput><trs><rules/></trs>
                              <dps><rules><rule/></rules></dps>
                              <usableRules><rules/></usableRules>
                              <strategy><contextSensitive><replacementMapEntry>
                                <name>f</name><arity>1</arity><position>1</position>
                              </replacementMapEntry></contextSensitive></strategy>
                              <minimal>true</minimal><ferrumCsrDpContext>
                                <construction>safe</construction>
                              </ferrumCsrDpContext></dpInput>
                            """,
                        }
                    }
                )
                + "\n",
                encoding="utf-8",
            )
            EXTRACT.attach_runtime_state_keys([row], proof, "")

        self.assertNotIn("runtime_raw_problem_key", row["metadata"])

    def test_external_replay_state_gets_runtime_alias(self) -> None:
        problem = "<trsInput><trs><rules/></trs></trsInput>"
        row = {
            "metadata": {"processor_tag": "dpTrans"},
            "input": {"problem_xml": problem},
        }
        with tempfile.TemporaryDirectory() as directory:
            proof = Path(directory) / "proof.cpf.xml"
            proof.write_text("unused", encoding="utf-8")
            external = Path(directory) / "current-events.jsonl"
            external.write_text(
                json.dumps(
                    {
                        "input": {
                            "problem_key": "current-runtime-key",
                            "cpf": problem,
                        }
                    }
                )
                + "\n",
                encoding="utf-8",
            )
            keys, dp_states, runtime_inputs = EXTRACT.read_runtime_state_aliases(
                [external]
            )
            self.assertEqual(runtime_inputs["current-runtime-key"], problem)
            EXTRACT.attach_runtime_state_keys(
                [row], proof, "", keys, dp_states
            )

        self.assertEqual(
            row["metadata"]["runtime_raw_problem_key"],
            "current-runtime-key",
        )

    def test_flat_proof_structural_row_uses_category_hint_for_alias(self) -> None:
        problem = "<trsInput><trs><rules/></trs></trsInput>"
        row = {
            "metadata": {"processor_tag": "dpTrans"},
            "input": {"problem_xml": problem},
        }
        with tempfile.TemporaryDirectory() as directory:
            proof = Path(directory) / "flat-run" / "proof.cpf.xml"
            proof.parent.mkdir(parents=True)
            proof.write_text("unused", encoding="utf-8")
            external = Path(directory) / "current-events.jsonl"
            external.write_text(
                json.dumps(
                    {
                        "category": "TRS_Innermost",
                        "problem_id": "Suite/Example.ari",
                        "input": {
                            "problem_key": "qualified-runtime-key",
                            "cpf": problem,
                        },
                    }
                )
                + "\n",
                encoding="utf-8",
            )
            keys, dp_states, _ = EXTRACT.read_runtime_state_aliases([external])
            EXTRACT.attach_runtime_state_keys(
                [row],
                proof,
                "Suite/Example.ari",
                keys,
                dp_states,
                category_hint="TRS_Innermost",
            )

        self.assertEqual(
            row["metadata"]["runtime_raw_problem_key"],
            "qualified-runtime-key",
        )

    def test_contextless_archive_bridges_to_unique_live_dp_context(self) -> None:
        archived = "<dpInput><trs><rules/></trs><dps><rules/></dps><minimal>true</minimal></dpInput>"
        live = archived.replace(
            "</dpInput>",
            "<ferrumDpStateContext><rewriteStrategy>innermost</rewriteStrategy>"
            "<pairSourceRules/><ordinaryReductionStarted>false</ordinaryReductionStarted>"
            "</ferrumDpStateContext></dpInput>",
        )
        row = {
            "metadata": {"processor_tag": "sizeChangeProc", "path": [0, 1, 2, 3]},
            "input": {"problem_xml": archived},
        }
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            proof = root / "proof.cpf.xml"
            proof.write_text("unused", encoding="utf-8")
            # The archived run may have recorded the same contextless state
            # under an obsolete raw key.  It must not mask the current live
            # child selected below by exact-transform causality.
            (root / "processor-events.jsonl").write_text(
                json.dumps(
                    {
                        "problem_id": "TRS_Innermost/Test/X.ari",
                        "input": {
                            "problem_key": "archived-contextless",
                            "cpf": archived,
                        },
                    }
                )
                + "\n",
                encoding="utf-8",
            )
            events = root / "current-events.jsonl"
            events.write_text(
                json.dumps(
                    {
                        "problem_id": "TRS_Innermost/Test/X.ari",
                        "input": {"problem_key": "live-child", "cpf": live},
                    }
                )
                + "\n",
                encoding="utf-8",
            )
            keys, dp_states, _ = EXTRACT.read_runtime_state_aliases([events])
            EXTRACT.attach_runtime_state_keys(
                [row], proof, "TRS_Innermost/Test/X.ari", keys, dp_states
            )
        self.assertEqual(row["metadata"]["runtime_raw_problem_key"], "live-child")

    def test_exact_graph_partial_context_bridges_to_unique_live_context(self) -> None:
        base = (
            "<dpInput><trs><rules/></trs><dps><rules/></dps>"
            "<minimal>true</minimal>{context}</dpInput>"
        )
        archived = base.format(
            context="<ferrumDpStateContext><innermostLhss/>"
            "</ferrumDpStateContext>"
        )
        live = base.format(
            context="<ferrumDpStateContext>"
            "<rewriteStrategy>innermost</rewriteStrategy>"
            "<pairSourceRules/><innermostLhss/>"
            "<ordinaryReductionStarted>false</ordinaryReductionStarted>"
            "</ferrumDpStateContext>"
        )
        row = {
            "metadata": {
                "processor_tag": "depGraphProc",
                "strategy_atom": "exact-graph(hex=00)",
                "path": [0, 1, 2, 3],
            },
            "input": {"problem_xml": archived},
        }
        with tempfile.TemporaryDirectory() as directory:
            proof = Path(directory) / "TRS_Innermost" / "Example" / "proof.cpf.xml"
            proof.parent.mkdir(parents=True)
            proof.write_text("unused", encoding="utf-8")
            events = Path(directory) / "events.jsonl"
            events.write_text(
                json.dumps(
                    {
                        "category": "TRS_Innermost",
                        "problem_id": "Example.ari",
                        "input": {"problem_key": "live-child", "cpf": live},
                    }
                )
                + "\n",
                encoding="utf-8",
            )
            keys, dp_states, _ = EXTRACT.read_runtime_state_aliases([events])
            EXTRACT.attach_runtime_state_keys(
                [row], proof, "Example.ari", keys, dp_states
            )

        self.assertEqual(row["metadata"]["runtime_raw_problem_key"], "live-child")

    def test_graph_component_wrapper_uses_graph_as_causal_parent(self) -> None:
        problem = (
            "<dpInput><trs><rules/></trs><dps><rules/></dps>"
            "<minimal>true</minimal></dpInput>"
        )
        core = EXTRACT.contextless_runtime_state_signature(problem)
        identity = "TRS_Innermost/Test/Example.ari"
        row = {
            "metadata": {
                "processor_tag": "usableRulesProc",
                "strategy_atom": "exact-usable-rules(hex=00)",
                "path": [
                    "depGraphProc",
                    "component",
                    "dpProof",
                    "usableRulesProc",
                ],
            },
            "input": {"problem_xml": problem},
        }
        keys = {
            (
                EXTRACT.CAUSAL_CHILD_CONTEXT_PREFIX
                + "depGraphProc\0"
                + identity,
                core,
            ): {"component-child"}
        }
        with tempfile.TemporaryDirectory() as directory:
            proof = (
                Path(directory)
                / "TRS_Innermost"
                / "Test"
                / "Example"
                / "proof.cpf.xml"
            )
            proof.parent.mkdir(parents=True)
            proof.write_text("unused", encoding="utf-8")
            EXTRACT.attach_runtime_state_keys(
                [row], proof, identity, keys, []
            )

        self.assertEqual(
            row["metadata"]["runtime_raw_problem_key"], "component-child"
        )

    def test_contextless_archive_does_not_bridge_ambiguous_live_contexts(self) -> None:
        archived = "<dpInput><trs><rules><rule/></rules></trs><dps><rules><rule/></rules></dps><minimal>true</minimal></dpInput>"
        context = (
            "<ferrumDpStateContext><rewriteStrategy>innermost</rewriteStrategy>"
            "<pairSourceRules><sourceRule>{source}</sourceRule></pairSourceRules>"
            "<ordinaryReductionStarted>false</ordinaryReductionStarted>"
            "</ferrumDpStateContext>"
        )
        row = {
            "metadata": {"processor_tag": "sizeChangeProc", "path": [0, 1, 2, 3]},
            "input": {"problem_xml": archived},
        }
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            proof = root / "proof.cpf.xml"
            proof.write_text("unused", encoding="utf-8")
            events = root / "current-events.jsonl"
            events.write_text(
                "\n".join(
                    json.dumps(
                        {
                            "problem_id": "TRS_Innermost/Test/X.ari",
                            "input": {
                                "problem_key": f"live-{source}",
                                "cpf": archived.replace(
                                    "</dpInput>", context.format(source=source) + "</dpInput>"
                                ),
                            },
                        }
                    )
                    for source in (0, 1)
                )
                + "\n",
                encoding="utf-8",
            )
            keys, dp_states, _ = EXTRACT.read_runtime_state_aliases([events])
            EXTRACT.attach_runtime_state_keys(
                [row], proof, "TRS_Innermost/Test/X.ari", keys, dp_states
            )
        self.assertNotIn("runtime_raw_problem_key", row["metadata"])

    def test_guarded_exact_atoms_bridge_all_provenance_variants(self) -> None:
        archived = "<dpInput><trs><rules><rule/></rules></trs><dps><rules><rule/></rules></dps><minimal>true</minimal></dpInput>"
        context = (
            "<ferrumDpStateContext><rewriteStrategy>innermost</rewriteStrategy>"
            "<pairSourceRules><sourceRule>{source}</sourceRule></pairSourceRules>"
            "<ordinaryReductionStarted>false</ordinaryReductionStarted>"
            "</ferrumDpStateContext>"
        )
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            proof = root / "proof.cpf.xml"
            proof.write_text("unused", encoding="utf-8")
            events = root / "current-events.jsonl"
            events.write_text(
                "".join(
                    json.dumps(
                        {
                            "problem_id": "TRS_Innermost/Test/X.ari",
                            "input": {
                                "problem_key": f"live-{source}",
                                "cpf": archived.replace(
                                    "</dpInput>", context.format(source=source) + "</dpInput>"
                                ),
                            },
                        }
                    )
                    + "\n"
                    for source in (0, 1)
                ),
                encoding="utf-8",
            )
            keys, dp_states, _ = EXTRACT.read_runtime_state_aliases([events])
            for processor_tag, strategy_atom in (
                ("depGraphProc", "exact-graph(hex=00)"),
                ("narrowingProc", "exact-dp-transform(hex=00)"),
                ("usableRulesProc", "exact-usable-rules(hex=00)"),
            ):
                with self.subTest(strategy_atom=strategy_atom):
                    rows = [
                        {
                            "metadata": {
                                "processor_tag": processor_tag,
                                "strategy_atom": strategy_atom,
                                "path": [0, 1, 2, 3],
                            },
                            "input": {"problem_xml": archived},
                        }
                    ]
                    EXTRACT.attach_runtime_state_keys(
                        rows,
                        proof,
                        "TRS_Innermost/Test/X.ari",
                        keys,
                        dp_states,
                    )
                    self.assertEqual(
                        {
                            candidate["metadata"]["runtime_raw_problem_key"]
                            for candidate in rows
                        },
                        {"live-0", "live-1"},
                    )

    def test_explicitly_disabled_portable_alias_does_not_broadcast(self) -> None:
        archived = (
            "<dpInput><trs><rules/></trs><dps><rules/></dps>"
            "<minimal>true</minimal></dpInput>"
        )
        context = (
            "<ferrumDpStateContext><rewriteStrategy>innermost</rewriteStrategy>"
            "<pairSourceRules><sourceRule>{source}</sourceRule></pairSourceRules>"
            "</ferrumDpStateContext>"
        )
        row = {
            "metadata": {
                "processor_tag": "redPairProc",
                "strategy_atom": "exact-red-pair(hex=00)",
            },
            "input": {"problem_xml": archived},
        }
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            proof = root / "proof.cpf.xml"
            proof.write_text("unused", encoding="utf-8")
            events = root / "current-events.jsonl"
            events.write_text(
                "".join(
                    json.dumps(
                        {
                            "problem_id": "TRS_Innermost/Test/X.ari",
                            "input": {
                                "problem_key": f"live-{source}",
                                "cpf": archived.replace(
                                    "</dpInput>",
                                    context.format(source=source) + "</dpInput>",
                                ),
                            },
                        }
                    )
                    + "\n"
                    for source in (0, 1)
                ),
                encoding="utf-8",
            )
            keys, dp_states, _ = EXTRACT.read_runtime_state_aliases([events])
            EXTRACT.attach_runtime_state_keys(
                [row],
                proof,
                "TRS_Innermost/Test/X.ari",
                keys,
                dp_states,
                allow_portable_ambiguous_aliases=False,
            )

        self.assertNotIn("runtime_raw_problem_key", row["metadata"])

    def test_exact_transform_child_disambiguates_legacy_context_causally(self) -> None:
        archived = "<dpInput><trs><rules><rule/></rules></trs><dps><rules><rule/></rules></dps><minimal>true</minimal></dpInput>"
        context = (
            "<ferrumDpStateContext><rewriteStrategy>innermost</rewriteStrategy>"
            "<pairSourceRules><sourceRule>{source}</sourceRule></pairSourceRules>"
            "<ordinaryReductionStarted>false</ordinaryReductionStarted>"
            "</ferrumDpStateContext>"
        )
        produced = archived.replace(
            "</dpInput>", context.format(source=7) + "</dpInput>"
        )
        competing = archived.replace(
            "</dpInput>", context.format(source=2) + "</dpInput>"
        )
        encoded = json.dumps(
            ["narrowingProc", "<rule/>", archived], separators=(",", ":")
        ).encode("utf-8").hex()
        row = {
            "metadata": {
                "processor_tag": "sizeChangeProc",
                "path": ["narrowingProc", "dpProof", "sizeChangeProc"],
            },
            # The archived rule index is presentation-dependent and differs
            # from the live source-rule index after signature translation.
            "input": {"problem_xml": competing},
        }
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            proof = root / "proof.cpf.xml"
            proof.write_text("unused", encoding="utf-8")
            (root / "processor-events.jsonl").write_text(
                json.dumps(
                    {
                        "problem_id": "TRS_Innermost/Test/X.ari",
                        "input": {
                            "problem_key": "archived-contextless",
                            "cpf": archived,
                        },
                    }
                )
                + "\n",
                encoding="utf-8",
            )
            events = root / "current-events.jsonl"
            event_rows = [
                {
                    "problem_id": "TRS_Innermost/Test/X.ari",
                    "input": {
                        "problem_key": "stale-contextless",
                        "cpf": archived,
                    },
                },
                {
                    "problem_id": "TRS_Innermost/Test/X.ari",
                    "input": {"problem_key": "competing", "cpf": competing},
                },
                {
                    "problem_id": "TRS_Innermost/Test/X.ari",
                    "error": "utility lookup miss after canonical merge",
                    "input": {"problem_key": "produced", "cpf": produced},
                },
                {
                    "problem_id": "TRS_Innermost/Test/X.ari",
                    "strategy_atom": f"exact-dp-transform(hex={encoded})",
                    "failure_reason": (
                        "strict oracle transformation produced an unguided residual"
                    ),
                    "input": {"problem_key": "parent", "cpf": "<dpInput/>"},
                },
            ]
            events.write_text(
                "".join(json.dumps(event) + "\n" for event in event_rows),
                encoding="utf-8",
            )
            keys, dp_states, _ = EXTRACT.read_runtime_state_aliases([events])
            EXTRACT.attach_runtime_state_keys(
                [row], proof, "TRS_Innermost/Test/X.ari", keys, dp_states
            )

        self.assertEqual(row["metadata"]["runtime_raw_problem_key"], "produced")

    def test_exact_transform_child_requires_adjacent_lookup_miss(self) -> None:
        archived = "<dpInput><trs><rules/></trs><dps><rules/></dps><minimal>true</minimal></dpInput>"
        context = (
            "<ferrumDpStateContext><rewriteStrategy>innermost</rewriteStrategy>"
            "<pairSourceRules><sourceRule>{source}</sourceRule></pairSourceRules>"
            "<ordinaryReductionStarted>false</ordinaryReductionStarted>"
            "</ferrumDpStateContext>"
        )
        live = archived.replace(
            "</dpInput>", context.format(source=7) + "</dpInput>"
        )
        competing = archived.replace(
            "</dpInput>", context.format(source=2) + "</dpInput>"
        )
        encoded = json.dumps(
            ["narrowingProc", "<rule/>", archived], separators=(",", ":")
        ).encode("utf-8").hex()
        with tempfile.TemporaryDirectory() as directory:
            events = Path(directory) / "events.jsonl"
            event_rows = [
                {
                    "problem_id": "TRS_Innermost/Test/X.ari",
                    "input": {"problem_key": "competing", "cpf": competing},
                },
                {
                    "problem_id": "TRS_Innermost/Test/X.ari",
                    "error": "utility lookup miss after canonical merge",
                    "input": {"problem_key": "child", "cpf": live},
                },
                {
                    "problem_id": "TRS_Innermost/Test/X.ari",
                    "input": {"problem_key": "unrelated", "cpf": "<trsInput/>"},
                },
                {
                    "problem_id": "TRS_Innermost/Test/X.ari",
                    "strategy_atom": f"exact-dp-transform(hex={encoded})",
                    "failure_reason": (
                        "strict oracle transformation produced an unguided residual"
                    ),
                    "input": {"problem_key": "parent", "cpf": "<dpInput/>"},
                },
            ]
            events.write_text(
                "".join(json.dumps(event) + "\n" for event in event_rows),
                encoding="utf-8",
            )
            keys, _, _ = EXTRACT.read_runtime_state_aliases([events])

        core = EXTRACT.contextless_runtime_state_signature(archived)
        self.assertNotIn(
            (EXTRACT.LEGACY_UNIQUE_CONTEXT_PREFIX +
             "TRS_Innermost/Test/X.ari", core),
            keys,
        )

    def test_residual_bearing_exact_transform_records_explicit_causal_child(self) -> None:
        archived = "<dpInput><trs><rules/></trs><dps><rules/></dps><minimal>true</minimal></dpInput>"
        context = (
            "<ferrumDpStateContext><rewriteStrategy>innermost</rewriteStrategy>"
            "<pairSourceRules><sourceRule>7</sourceRule></pairSourceRules>"
            "<ordinaryReductionStarted>false</ordinaryReductionStarted>"
            "</ferrumDpStateContext>"
        )
        live = archived.replace("<trs>", "<trs><signatureAlias/>").replace(
            "</dpInput>", context + "</dpInput>"
        )
        encoded = json.dumps(
            ["narrowingProc", "<rule/>", archived], separators=(",", ":")
        ).encode("utf-8").hex()
        for outcome in ("transformed", "failed"):
            with self.subTest(outcome=outcome), tempfile.TemporaryDirectory() as directory:
                events = Path(directory) / "events.jsonl"
                events.write_text(
                    json.dumps(
                        {
                            "problem_id": "TRS_Innermost/Test/X.ari",
                            "strategy_atom": f"exact-dp-transform(hex={encoded})",
                            "outcome": outcome,
                            "input": {"problem_key": "parent", "cpf": "<dpInput/>"},
                            "witness": {
                                "residuals": [
                                    {"problem_key": "live-child", "cpf": live}
                                ]
                            },
                        }
                    )
                    + "\n",
                    encoding="utf-8",
                )
                keys, _, _ = EXTRACT.read_runtime_state_aliases([events])

            core = EXTRACT.contextless_runtime_state_signature(archived)
            self.assertEqual(
                keys[
                    (
                        EXTRACT.CAUSAL_CHILD_CONTEXT_PREFIX
                        + "narrowingProc\0TRS_Innermost/Test/X.ari",
                        core,
                    )
                ],
                {"live-child"},
            )

    def test_exact_root_dp_records_its_live_child_for_recursive_guidance(self) -> None:
        archived = "<dpInput><trs><rules/></trs><dps><rules/></dps><minimal>true</minimal></dpInput>"
        live = archived.replace(
            "</dpInput>",
            "<ferrumDpStateContext><rewriteStrategy>full</rewriteStrategy>"
            "<ordinaryReductionStarted>false</ordinaryReductionStarted>"
            "</ferrumDpStateContext></dpInput>",
        )
        encoded = json.dumps(archived, separators=(",", ":")).encode("utf-8").hex()
        with tempfile.TemporaryDirectory() as directory:
            events = Path(directory) / "events.jsonl"
            events.write_text(
                json.dumps(
                    {
                        "problem_id": "TRS_Standard/Test/X.ari",
                        "level": "top-level",
                        "strategy_atom": f"exact-dp(hex={encoded})",
                        "outcome": "transformed",
                        "input": {"problem_key": "parent", "cpf": "<trsInput/>"},
                        "witness": {
                            "residuals": [
                                {"problem_key": "live-child", "cpf": live}
                            ]
                        },
                    }
                )
                + "\n",
                encoding="utf-8",
            )
            keys, _, _ = EXTRACT.read_runtime_state_aliases([events])

        core = EXTRACT.contextless_runtime_state_signature(archived)
        self.assertEqual(
            keys[
                (
                    EXTRACT.CAUSAL_CHILD_CONTEXT_PREFIX
                    + "dpTrans\0TRS_Standard/Test/X.ari",
                    core,
                )
            ],
            {"live-child"},
        )

    def test_relocated_exact_semantic_labeling_records_archived_child_core(self) -> None:
        archived = (
            "<dpInput><trs><rules/></trs><dps><rules><rule/></rules></dps>"
            "<minimal>true</minimal></dpInput>"
        )
        live = archived.replace("<rule/>", "<rule><renamedSymbol/></rule>")
        encoded = json.dumps(
            [{"carrier_size": 2, "arities": [], "interpretations": []}, "<dpInput/>", archived],
            separators=(",", ":"),
        ).encode("utf-8").hex()
        atom = f"exact-semantic-labeling(hex={encoded})"
        with tempfile.TemporaryDirectory() as directory:
            events = Path(directory) / "events.jsonl"
            events.write_text(
                json.dumps(
                    {
                        "problem_id": "TRS_Standard/Test/X.ari",
                        "processor": atom,
                        "outcome": "failed",
                        "failure_reason": (
                            "strict oracle transformation produced an unguided residual"
                        ),
                        "input": {"problem_key": "parent", "cpf": "<dpInput/>"},
                        "witness": {
                            "residuals": [
                                {"problem_key": "live-child", "cpf": live}
                            ]
                        },
                    }
                )
                + "\n",
                encoding="utf-8",
            )
            keys, _, _ = EXTRACT.read_runtime_state_aliases([events])

        parent_tag = EXTRACT.exact_semantic_model_discriminator(atom)
        archived_core = EXTRACT.contextless_runtime_state_signature(archived)
        self.assertEqual(
            keys[
                (
                    EXTRACT.CAUSAL_CHILD_CONTEXT_PREFIX
                    + parent_tag
                    + "\0TRS_Standard/Test/X.ari",
                    archived_core,
                )
            ],
            {"live-child"},
        )

    def test_exact_usable_red_pair_child_matches_csr_wrapper(self) -> None:
        archived = (
            "<dpInput><trs><rules/></trs><dps><rules><rule/></rules></dps>"
            "<minimal>true</minimal></dpInput>"
        )
        live = archived.replace(
            "</dpInput>",
            "<ferrumDpStateContext><rewriteStrategy>context-sensitive</rewriteStrategy>"
            "<ordinaryReductionStarted>false</ordinaryReductionStarted>"
            "</ferrumDpStateContext></dpInput>",
        )
        encoded = json.dumps(
            ["redPairUrProc", "<interpretation/>", [], "<dps/>", "<trs/>", "<q/>", archived],
            separators=(",", ":"),
        ).encode("utf-8").hex()
        row = {
            "metadata": {
                "processor_tag": "sizeChangeProc",
                "path": ["csrRedPairUrProc", "csrDpProof", "sizeChangeProc"],
            },
            "input": {"problem_xml": archived},
        }
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            proof = root / "proof.cpf.xml"
            proof.write_text("unused", encoding="utf-8")
            events = root / "events.jsonl"
            events.write_text(
                json.dumps(
                    {
                        "problem_id": "TRS_Innermost/Test/X.ari",
                        "processor": f"exact-red-pair(hex={encoded})",
                        "failure_reason": (
                            "strict oracle transformation produced an unguided residual"
                        ),
                        "input": {"problem_key": "parent", "cpf": None},
                        "witness": {
                            "residuals": [
                                {"problem_key": "live-child", "cpf": live}
                            ]
                        },
                    }
                )
                + "\n",
                encoding="utf-8",
            )
            keys, dp_states, _ = EXTRACT.read_runtime_state_aliases([events])
            EXTRACT.attach_runtime_state_keys(
                [row], proof, "TRS_Innermost/Test/X.ari", keys, dp_states
            )

        self.assertEqual(
            row["metadata"]["runtime_raw_problem_key"], "live-child"
        )

    def test_successful_innermost_lhss_records_explicit_causal_child(self) -> None:
        child = (
            "<dpInput><trs><rules/></trs><dps><rules/></dps>"
            "<minimal>true</minimal><ferrumDpStateContext>"
            "<rewriteStrategy>innermost</rewriteStrategy>"
            "<innermostLhss/><ordinaryReductionStarted>false</ordinaryReductionStarted>"
            "</ferrumDpStateContext></dpInput>"
        )
        with tempfile.TemporaryDirectory() as directory:
            events = Path(directory) / "events.jsonl"
            events.write_text(
                json.dumps(
                    {
                        "problem_id": "TRS_Innermost/Test/X.ari",
                        "strategy_atom": "innermost-lhss",
                        "outcome": "transformed",
                        "input": {"problem_key": "parent", "cpf": "<dpInput/>"},
                        "witness": {
                            "residuals": [
                                {"problem_key": "live-child", "cpf": child}
                            ]
                        },
                    }
                )
                + "\n",
                encoding="utf-8",
            )
            keys, _, _ = EXTRACT.read_runtime_state_aliases([events])

        core = EXTRACT.contextless_runtime_state_signature(child)
        self.assertEqual(
            keys[
                (
                    EXTRACT.CAUSAL_CHILD_CONTEXT_PREFIX
                    + "innermostLhssRemovalProc\0TRS_Innermost/Test/X.ari",
                    core,
                )
            ],
            {"live-child"},
        )

    def test_exact_model_reduction_pair_records_wrapper_causal_child(self) -> None:
        child = (
            "<dpInput><trs><rules/></trs><dps><rules/></dps>"
            "<minimal>true</minimal><ferrumDpStateContext>"
            "<pairSourceRules/><transformationRules><rules/></transformationRules>"
            "<ordinaryReductionStarted>false</ordinaryReductionStarted>"
            "</ferrumDpStateContext></dpInput>"
        )
        with tempfile.TemporaryDirectory() as directory:
            events = Path(directory) / "events.jsonl"
            events.write_text(
                json.dumps(
                    {
                        "problem_id": "TRS_Standard/Test/X.ari",
                        "strategy_atom": "exact-mono-poly(hex=5b5d)",
                        "outcome": "transformed",
                        "input": {
                            "problem_key": "parent",
                            "cpf": "<dpInput><trs><rules/></trs><dps><rules/></dps>"
                            "<minimal>true</minimal></dpInput>",
                        },
                        "witness": {
                            "residuals": [
                                {"problem_key": "live-child", "cpf": child}
                            ]
                        },
                    }
                )
                + "\n",
                encoding="utf-8",
            )
            keys, _, _ = EXTRACT.read_runtime_state_aliases([events])

        self.assertEqual(
            keys[
                (
                    EXTRACT.CAUSAL_PARENT_RAW_PREFIX
                    + "monoRedPairUrProc\0TRS_Standard/Test/X.ari",
                    "parent",
                )
            ],
            {"live-child"},
        )

    def test_uncurry_and_dp_switch_record_typed_causal_children(self) -> None:
        child = "<trsInput><trs><rules/></trs></trsInput>"
        dp_child = (
            "<dpInput><trs><rules/></trs><dps><rules/></dps>"
            "<minimal>true</minimal></dpInput>"
        )
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            events = root / "events.jsonl"
            events.write_text(
                "".join(
                    json.dumps(event) + "\n"
                    for event in (
                        {
                            "problem_id": "TRS_Standard/Test/X.ari",
                            "level": "top-level",
                            "strategy_atom": "uncurry",
                            "outcome": "transformed",
                            "input": {"problem_key": "root", "cpf": "<trsInput/>"},
                            "witness": {
                                "residuals": [
                                    {"problem_key": "uncurried", "cpf": child}
                                ]
                            },
                        },
                        {
                            "problem_id": "TRS_Standard/Test/X.ari",
                            "level": "dependency-pair",
                            "strategy_atom": "switch-innermost",
                            "outcome": "failed",
                            "failure_reason": (
                                "strict oracle transformation produced an unguided residual"
                            ),
                            "input": {"problem_key": "dp", "cpf": "<dpInput/>"},
                            "witness": {
                                "residuals": [
                                    {"problem_key": "switched", "cpf": dp_child}
                                ]
                            },
                        },
                    )
                ),
                encoding="utf-8",
            )
            keys, dp_states, _ = EXTRACT.read_runtime_state_aliases([events])
            proof = root / "proof.xml"
            proof.write_text("unused", encoding="utf-8")
            uncurry_row = {
                "metadata": {
                    "processor_tag": "switchInnermost",
                    "causal_parent_input_xml": "<trsInput/>",
                    "path": ["trsTerminationProof", "uncurry", "trsTerminationProof", "switchInnermost"]
                },
                "input": {
                    "problem_xml": "<trsInput><trs><rules/><freshArchived/></trs></trsInput>"
                },
            }
            switch_row = {
                "metadata": {
                    "processor_tag": "usableRulesProc",
                    "causal_parent_input_xml": "<dpInput><archivedContext/></dpInput>",
                    "path": ["depGraphProc", "component", "dpProof", "switchInnermostProc", "dpProof", "usableRulesProc"]
                },
                "input": {
                    "problem_xml": dp_child.replace(
                        "<minimal>true</minimal>", "<minimal>false</minimal>"
                    )
                },
            }
            EXTRACT.attach_runtime_state_keys(
                [uncurry_row, switch_row],
                proof,
                "TRS_Standard/Test/X.ari",
                keys,
                dp_states,
            )

        self.assertEqual(
            uncurry_row["metadata"]["runtime_raw_problem_key"], "uncurried"
        )
        self.assertEqual(
            switch_row["metadata"]["runtime_raw_problem_key"], "switched"
        )

    def test_dp_uncurry_records_each_runtime_step_independently(self) -> None:
        source = (
            "<dpInput><trs><rules/></trs><dps><rules/></dps>"
            "<minimal>true</minimal></dpInput>"
        )
        intermediate = source.replace(
            "</dpInput>", "<ferrumDpStateContext><uncurry>top</uncurry>"
            "</ferrumDpStateContext></dpInput>"
        )
        final = intermediate.replace("top", "below")
        identity = "TRS_Standard/Test/X.ari"
        with tempfile.TemporaryDirectory() as directory:
            events = Path(directory) / "events.jsonl"
            events.write_text(
                "".join(
                    json.dumps(event) + "\n"
                    for event in (
                        {
                            "problem_id": identity,
                            "level": "dependency-pair",
                            "strategy_atom": "uncurry",
                            "outcome": "transformed",
                            "input": {"problem_key": "source", "cpf": source},
                            "witness": {
                                "residuals": [
                                    {
                                        "problem_key": "intermediate",
                                        "cpf": intermediate,
                                    }
                                ]
                            },
                        },
                        {
                            "problem_id": identity,
                            "level": "dependency-pair",
                            "strategy_atom": "uncurry-below",
                            "outcome": "transformed",
                            "input": {
                                "problem_key": "intermediate",
                                "cpf": intermediate,
                            },
                            "witness": {
                                "residuals": [
                                    {"problem_key": "final", "cpf": final}
                                ]
                            },
                        },
                    )
                ),
                encoding="utf-8",
            )
            keys, _, _ = EXTRACT.read_runtime_state_aliases([events])

        self.assertEqual(
            keys[
                (
                    EXTRACT.CAUSAL_PARENT_RAW_PREFIX
                    + "uncurryProc\0"
                    + identity,
                    "source",
                )
            ],
            {"intermediate"},
        )
        self.assertEqual(
            keys[
                (
                    EXTRACT.CAUSAL_PARENT_RAW_PREFIX
                    + "uncurryProc\0"
                    + identity,
                    "intermediate",
                )
            ],
            {"final"},
        )

    def test_runtime_root_index_excludes_later_top_level_residuals(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            events = Path(directory) / "processor-events.jsonl"
            rows = [
                {
                    "category": "TRS_Contextsensitive",
                    "problem_id": "CSR_04/example.ari",
                    "level": "top-level",
                    "input": {"problem_key": "root", "cpf": "<trsInput/>"},
                },
                {
                    "category": "TRS_Contextsensitive",
                    "problem_id": "CSR_04/example.ari",
                    "level": "top-level",
                    "input": {"problem_key": "residual", "cpf": "<trsInput/>"},
                },
            ]
            events.write_text(
                "".join(json.dumps(row) + "\n" for row in rows), encoding="utf-8"
            )
            roots = EXTRACT.read_runtime_root_keys([events])

        self.assertEqual(
            roots["TRS_Contextsensitive/CSR_04/example.ari"], {"root"}
        )

    def test_global_size_change_does_not_borrow_runtime_scc_aliases(self) -> None:
        row = {
            "metadata": {"processor_tag": "sizeChangeProc"},
            "input": {"problem_xml": """
              <dpInput><trs><rules/></trs><dps><rules>
                <rule><var>A</var><var>A</var></rule>
                <rule><var>B</var><var>B</var></rule>
              </rules></dps><strategy><contextSensitive/></strategy>
              <minimal>true</minimal></dpInput>
            """},
        }
        with tempfile.TemporaryDirectory() as directory:
            proof = Path(directory) / "proof.cpf.xml"
            proof.write_text("unused", encoding="utf-8")
            events = []
            for key, variable in (("scc-a", "A"), ("scc-b", "B")):
                events.append(json.dumps({"input": {
                    "problem_key": key,
                    "cpf": f"""<dpInput><trs><rules/></trs><dps><rules>
                      <rule><var>{variable}</var><var>{variable}</var></rule>
                    </rules></dps><usableRules><rules/></usableRules>
                    <strategy><contextSensitive/></strategy>
                    <minimal>true</minimal><ferrumCsrDpContext>
                      <construction>native</construction>
                    </ferrumCsrDpContext></dpInput>""",
                }}))
            proof.with_name("processor-events.jsonl").write_text(
                "\n".join(events) + "\n", encoding="utf-8"
            )
            rows = [row]
            EXTRACT.attach_runtime_state_keys(rows, proof, "")

        self.assertEqual(len(rows), 1)
        self.assertNotIn("runtime_raw_problem_key", rows[0]["metadata"])

    def test_typed_problem_kind_preserves_csr_dp_context(self) -> None:
        self.assertEqual(
            EXTRACT.typed_problem_kind(
                "<dpInput><trs/><dps/><strategy><contextSensitive/>"
                "</strategy><minimal>true</minimal></dpInput>"
            ),
            ("context-sensitive-dependency-pair", "qcs-dp"),
        )

    def test_root_local_pool_context_separates_csr_dp_constructions(self) -> None:
        def problem(construction: str, qcs_usable: str) -> str:
            return (
                "<dpInput><trs/><dps/><strategy><contextSensitive/>"
                "</strategy><minimal>true</minimal><ferrumCsrDpContext>"
                f"<construction>{construction}</construction>"
                "<graphEstimator>context-sensitive</graphEstimator>"
                f"<qcsUsableRules>{qcs_usable}</qcsUsableRules>"
                "</ferrumCsrDpContext></dpInput>"
            )

        improved = EXTRACT.typed_pool_context(problem("improved", "true"))
        safe = EXTRACT.typed_pool_context(problem("safe", "false"))

        self.assertNotEqual(improved, safe)
        self.assertEqual(improved[2:], ("improved", "context-sensitive"))
        self.assertEqual(safe[2:], ("safe", "context-sensitive"))

    def test_accepts_certified_flat_collector_results(self) -> None:
        proof = Path("/tmp/Transformed_CSR_04__example.cpf.xml")
        self.assertEqual(
            EXTRACT.result_path_for_proof(proof),
            Path("/tmp/Transformed_CSR_04__example.result.json"),
        )
        self.assertEqual(
            EXTRACT.certified_result_polarity(
                {"status": "Terminating", "certified": True}
            ),
            "YES",
        )
        self.assertEqual(
            EXTRACT.certified_result_polarity(
                {"status": "Nonterminating", "certified": True}
            ),
            "NO",
        )
        self.assertIsNone(
            EXTRACT.certified_result_polarity(
                {"status": "Terminating", "certified": False}
            )
        )

    def test_terminal_csr_dp_processors_replay_as_solved_dp_atoms(self) -> None:
        for processor, expected in (
            ("csrDependencyPairs", "csr-native-dp"),
            ("csrImprovedDependencyPairs", "csr-improved-dp"),
            ("csrSafeDependencyPairs", "csr-safe-dp"),
            ("csrConservativeDependencyPairs", "csr-conservative-dp"),
        ):
            with self.subTest(processor=processor):
                self.assertEqual(EXTRACT.strategy_atom({
                    "metadata": {"processor_tag": processor},
                    "output_xml": f"<{processor}/>",
                    "input": {"problem_xml": "<trsInput/>"},
                }), expected)
                self.assertEqual(
                    EXTRACT.event_outcome(processor, f"<{processor}/>"),
                    ("solved", "closed"),
                )

    def test_csr_dp_processor_with_nonterminal_continuation_is_transformed(self) -> None:
        fragment = """
            <csrImprovedDependencyPairs>
              <dps><rules><rule/></rules></dps>
              <csrDpProof><depGraphProc>
                <component><dps><rules><rule/></rules></dps>
                  <csrDpProof><sizeChangeProc/></csrDpProof>
                </component>
              </depGraphProc></csrDpProof>
            </csrImprovedDependencyPairs>
        """

        self.assertEqual(
            EXTRACT.event_outcome("csrImprovedDependencyPairs", fragment),
            ("transformed", "strong"),
        )

    def test_exact_graph_marks_csr_component_with_nested_proof_as_open(self) -> None:
        first = """
          <rule><funapp><name>f</name><var>X</var></funapp>
            <funapp><name>g</name><var>X</var></funapp></rule>
        """
        second = """
          <rule><funapp><name>g</name><var>X</var></funapp>
            <funapp><name>h</name><var>X</var></funapp></rule>
        """
        row = {
            "metadata": {"processor_tag": "depGraphProc"},
            "output_xml": f"""
              <depGraphProc>
                <component><dps><rules>{first}</rules></dps>
                  <csrDpProof><sizeChangeProc/></csrDpProof>
                </component>
                <component><dps><rules>{second}</rules></dps></component>
              </depGraphProc>
            """,
            "input": {
                "problem_xml": f"""
                  <dpInput><trs><rules/></trs><dps><rules>{first}{second}</rules></dps>
                    <minimal>true</minimal></dpInput>
                """,
            },
        }

        candidate = EXTRACT.strategy_atom(row)

        self.assertIsNotNone(candidate)
        encoded = candidate.removeprefix("exact-graph(hex=").removesuffix(")")
        source, components = json.loads(bytes.fromhex(encoded))
        self.assertIn("<dpInput>", source)
        self.assertEqual(components, [[[0], True], [[1], False]])

    def test_exact_graph_component_matching_is_alpha_invariant(self) -> None:
        live = (
            "<rule><funapp><name>f</name><var>live_x</var><var>live_y</var>"
            "</funapp><funapp><name>g</name><var>live_y</var><var>live_x</var>"
            "</funapp></rule>"
        )
        archived = live.replace("live_x", "old_a").replace("live_y", "old_b")
        row = {
            "metadata": {"processor_tag": "depGraphProc"},
            "output_xml": (
                "<depGraphProc><component><dps><rules>"
                + archived
                + "</rules></dps><dpProof><sizeChangeProc/></dpProof>"
                "</component></depGraphProc>"
            ),
            "input": {
                "problem_xml": (
                    "<dpInput><trs><rules/></trs><dps><rules>"
                    + live
                    + "</rules></dps><minimal>true</minimal></dpInput>"
                )
            },
        }

        candidate = EXTRACT.strategy_atom(row)

        self.assertIsNotNone(candidate)
        encoded = candidate.removeprefix("exact-graph(hex=").removesuffix(")")
        _, components = json.loads(bytes.fromhex(encoded))
        self.assertEqual(components, [[[0], True]])

        EXTRACT.freeze_portable_atoms_before_runtime_rebind([row])
        row["input"]["problem_xml"] = row["input"]["problem_xml"].replace(
            "<name>f</name>", "<name>renamed_f</name>"
        ).replace("<name>g</name>", "<name>renamed_g</name>")
        self.assertEqual(EXTRACT.strategy_atom(row), candidate)

    def test_nontermination_rule_removal_freezes_traversed_child(self) -> None:
        source = (
            "<dpInput><trs><rules/></trs><dps><rules>"
            "<rule><funapp><name>p</name></funapp><funapp><name>p</name></funapp></rule>"
            "<rule><funapp><name>q</name></funapp><funapp><name>q</name></funapp></rule>"
            "</rules></dps><minimal>true</minimal></dpInput>"
        )
        child = source.replace(
            "<rule><funapp><name>q</name></funapp><funapp><name>q</name></funapp></rule>",
            "",
        )
        placeholder = json.dumps([source, source], separators=(",", ":")).encode().hex()
        parent = {
            "id": "parent",
            "metadata": {
                "processor_tag": "dpRuleRemoval",
                "strategy_atom": f"exact-dp-no-rule-removal(hex={placeholder})",
            },
            "output_xml": "<dpRuleRemoval/>",
            "input": {"problem_xml": source},
        }
        recursive = {
            "id": "child",
            "metadata": {"causal_parent_row_id": "parent"},
            "input": {"problem_xml": child},
        }

        EXTRACT.freeze_portable_atoms_before_runtime_rebind([parent, recursive])

        atom = parent["metadata"]["strategy_atom"]
        encoded = atom.removeprefix("exact-dp-no-rule-removal(hex=").removesuffix(")")
        frozen_source, frozen_child = json.loads(bytes.fromhex(encoded))
        self.assertEqual(frozen_source, source)
        self.assertEqual(frozen_child, child)

    def test_portable_graph_freeze_upgrades_generic_runtime_hint(self) -> None:
        rule = (
            "<rule><funapp><sharp><name>f</name></sharp><var>X</var></funapp>"
            "<funapp><sharp><name>f</name></sharp><var>X</var></funapp></rule>"
        )
        row = {
            "metadata": {
                "processor_tag": "depGraphProc",
                "strategy_atom": "graph",
            },
            "output_xml": (
                f"<depGraphProc><component><dps><rules>{rule}</rules></dps>"
                "<dpProof><sizeChangeProc/></dpProof></component></depGraphProc>"
            ),
            "input": {
                "problem_xml": (
                    f"<dpInput><trs><rules/></trs><dps><rules>{rule}</rules></dps>"
                    "<minimal>true</minimal></dpInput>"
                )
            },
        }

        EXTRACT.freeze_portable_atoms_before_runtime_rebind([row])

        atom = row["metadata"]["strategy_atom"]
        self.assertTrue(atom.startswith("exact-graph(hex="), atom)

    def test_exact_graph_preserves_omitted_acyclic_pairs(self) -> None:
        def rule(name: str) -> str:
            return (
                f"<rule><funapp><sharp><name>{name}</name></sharp><var>X</var></funapp>"
                f"<funapp><sharp><name>{name}</name></sharp><var>X</var></funapp></rule>"
            )

        retained, omitted = rule("f"), rule("g")
        row = {
            "metadata": {"processor_tag": "depGraphProc"},
            "output_xml": (
                f"<depGraphProc><component><dps><rules>{retained}</rules></dps>"
                "<dpProof><sizeChangeProc/></dpProof></component></depGraphProc>"
            ),
            "input": {
                "problem_xml": (
                    "<dpInput><trs><rules/></trs><dps><rules>"
                    f"{retained}{omitted}</rules></dps><minimal>true</minimal></dpInput>"
                )
            },
        }

        atom = EXTRACT.strategy_atom(row)

        self.assertIsNotNone(atom)
        assert atom is not None
        encoded = atom.removeprefix("exact-graph(hex=").removesuffix(")")
        _, components = json.loads(bytes.fromhex(encoded))
        self.assertEqual(components, [[[0], True]])

    def test_exact_dp_child_is_frozen_before_runtime_root_rebind(self) -> None:
        pair = (
            "<rule><funapp><sharp><name>f</name></sharp><var>X</var></funapp>"
            "<funapp><sharp><name>f</name></sharp><var>X</var></funapp></rule>"
        )
        row = {
            "metadata": {"processor_tag": "dpTrans"},
            "output_xml": f"<dpTrans><dps><rules>{pair}</rules></dps></dpTrans>",
            "input": {
                "problem_xml": (
                    "<input><dpInput><trs><rules/></trs><dps><rules/></dps>"
                    "<strategy><innermost /></strategy><minimal>true</minimal>"
                    "</dpInput></input>"
                )
            },
        }

        EXTRACT.freeze_portable_atoms_before_runtime_rebind([row])
        candidate = EXTRACT.strategy_atom(row)
        self.assertIsNotNone(candidate)
        self.assertTrue(candidate.startswith("exact-dp("))
        row["input"]["problem_xml"] = row["input"]["problem_xml"].replace(
            "<innermost />", "<innermost><nfs>true</nfs></innermost>"
        )
        self.assertEqual(EXTRACT.strategy_atom(row), candidate)
        encoded = candidate.removeprefix("exact-dp(hex=").removesuffix(")")
        child = json.loads(bytes.fromhex(encoded))
        self.assertNotIn("<nfs>true</nfs>", child)

    def test_exact_dp_rebind_aligns_numeric_alias_without_changing_nfs(self) -> None:
        row = {
            "metadata": {
                "processor_tag": "dpTrans",
                "runtime_raw_problem_key": "live",
            },
            "output_xml": "<dpTrans><dps><rules/></dps></dpTrans>",
            "input": {
                "problem_xml": (
                    "<input><dpInput><trs><rules><rule>"
                    "<funapp><name>0</name></funapp><funapp><name>f</name></funapp>"
                    "</rule></rules></trs><dps><rules/></dps>"
                    "<strategy><innermost /></strategy><minimal>true</minimal>"
                    "</dpInput></input>"
                )
            },
        }
        EXTRACT.freeze_portable_atoms_before_runtime_rebind([row])
        live = row["input"]["problem_xml"].replace("<name>0</name>", "<name>|0|</name>")
        live = live.replace(
            "<innermost />", "<innermost><nfs>true</nfs></innermost>"
        )

        EXTRACT.rebind_rows_to_runtime_inputs([row], {"live": live})

        atom = EXTRACT.strategy_atom(row)
        encoded = atom.removeprefix("exact-dp(hex=").removesuffix(")")
        child = json.loads(bytes.fromhex(encoded))
        self.assertIn("<name>|0|</name>", child)
        self.assertNotIn("<nfs>true</nfs>", child)

    def test_exact_instantiation_replaces_numeric_alias_with_alpha_renaming(self) -> None:
        selected = (
            "<rule><funapp><sharp><name>f</name></sharp>"
            "<funapp><name>0</name></funapp><var>x0</var></funapp>"
            "<funapp><sharp><name>g</name></sharp><var>x0</var></funapp></rule>"
        )
        retained = (
            "<rule><funapp><sharp><name>h</name></sharp><var>y</var></funapp>"
            "<funapp><sharp><name>h</name></sharp><var>y</var></funapp></rule>"
        )
        instance = selected.replace("<name>0</name>", "<name>s</name>")
        row = {
            "metadata": {"processor_tag": "instantiationProc"},
            "output_xml": (
                f"<instantiationProc>{selected}<instantiations><rules>{instance}"
                "</rules></instantiations><dpProof><pIsEmpty/></dpProof>"
                "</instantiationProc>"
            ),
            "input": {
                "problem_xml": (
                    "<input><dpInput><trs><rules/></trs><dps><rules>"
                    + selected.replace("<name>0</name>", "<name>|0|</name>")
                    .replace("x0", "liveVariable")
                    + retained
                    + "</rules></dps><minimal>true</minimal></dpInput></input>"
                )
            },
        }

        atom = EXTRACT.strategy_atom(row)

        self.assertIsNotNone(atom)
        encoded = atom.removeprefix("exact-dp-transform(hex=").removesuffix(")")
        _, _, child_xml, source_xml = json.loads(bytes.fromhex(encoded))
        self.assertEqual(source_xml, row['input']['problem_xml'])
        child = ET.fromstring(child_xml)
        rules = child.findall("./dpInput/dps/rules/rule")
        self.assertEqual(len(rules), 2)
        serialized = [ET.tostring(rule, encoding="unicode") for rule in rules]
        self.assertTrue(any("<name>h</name>" in rule for rule in serialized))
        self.assertTrue(any("<name>s</name>" in rule for rule in serialized))
        self.assertFalse(any("liveVariable" in rule for rule in serialized))

        EXTRACT.freeze_portable_atoms_before_runtime_rebind([row])
        frozen = EXTRACT.strategy_atom(row)
        self.assertIsNotNone(frozen)
        row["metadata"]["runtime_raw_problem_key"] = "live"
        EXTRACT.rebind_rows_to_runtime_inputs(
            [row],
            {
                "live": (
                    "<dpInput><trs><rules/></trs><dps><rules>"
                    + retained
                    + "</rules></dps><minimal>true</minimal></dpInput>"
                )
            },
        )
        self.assertEqual(EXTRACT.strategy_atom(row), frozen)

    def test_exact_split_matches_numeric_alias_with_alpha_renaming(self) -> None:
        selected = (
            "<rule><funapp><sharp><name>f</name></sharp>"
            "<funapp><name>0</name></funapp><var>x0</var></funapp>"
            "<funapp><sharp><name>g</name></sharp><var>x0</var></funapp></rule>"
        )
        live_selected = selected.replace("<name>0</name>", "<name>|0|</name>").replace(
            "x0", "liveVariable"
        )
        retained = (
            "<rule><funapp><sharp><name>h</name></sharp><var>y</var></funapp>"
            "<funapp><sharp><name>h</name></sharp><var>y</var></funapp></rule>"
        )
        row = {
            "metadata": {"processor_tag": "splitProc"},
            "output_xml": (
                f"<splitProc><dps><rules>{selected}</rules></dps><trs><rules/></trs>"
                "<dpProof><pIsEmpty/></dpProof><dpProof><pIsEmpty/></dpProof>"
                "</splitProc>"
            ),
            "input": {
                "problem_xml": (
                    "<input><dpInput><trs><rules/></trs><dps><rules>"
                    + live_selected
                    + retained
                    + "</rules></dps><minimal>true</minimal></dpInput></input>"
                )
            },
        }

        atom = EXTRACT.strategy_atom(row)

        self.assertIsNotNone(atom)
        encoded = atom.removeprefix("exact-split(hex=").removesuffix(")")
        selected_pair, selected_rule, _ = json.loads(bytes.fromhex(encoded))
        self.assertEqual(selected_pair, 0)
        self.assertIsNone(selected_rule)

    def test_exact_split_is_frozen_before_runtime_rebind(self) -> None:
        selected = (
            "<rule><funapp><sharp><name>f</name></sharp><var>X</var></funapp>"
            "<funapp><sharp><name>g</name></sharp><var>X</var></funapp></rule>"
        )
        retained = (
            "<rule><funapp><sharp><name>h</name></sharp><var>Y</var></funapp>"
            "<funapp><sharp><name>h</name></sharp><var>Y</var></funapp></rule>"
        )
        row = {
            "metadata": {"processor_tag": "splitProc"},
            "output_xml": (
                f"<splitProc><dps><rules>{selected}</rules></dps>"
                "<trs><rules/></trs><dpProof><pIsEmpty/></dpProof>"
                "<dpProof><pIsEmpty/></dpProof></splitProc>"
            ),
            "input": {
                "problem_xml": (
                    "<input><dpInput><trs><rules/></trs><dps><rules>"
                    + selected
                    + retained
                    + "</rules></dps><minimal>true</minimal></dpInput></input>"
                )
            },
        }

        EXTRACT.freeze_portable_atoms_before_runtime_rebind([row])
        frozen = EXTRACT.strategy_atom(row)
        self.assertIsNotNone(frozen)
        self.assertTrue(frozen.startswith("exact-split("))

        # This live residual is intentionally not a state from which the CPF
        # fragment could be re-encoded syntactically.  The already frozen
        # atom remains self-contained and will perform its guarded portable
        # state check at execution time.
        live = (
            "<dpInput><trs><rules/></trs><dps><rules>"
            + retained
            + "</rules></dps><minimal>true</minimal></dpInput>"
        )
        EXTRACT.rebind_rows_to_runtime_inputs([row], {"live": live})
        self.assertEqual(EXTRACT.strategy_atom(row), frozen)

    def test_context_bound_red_pair_is_frozen_before_runtime_rebind(self) -> None:
        pair = (
            "<rule><funapp><sharp><name>f</name></sharp><var>X</var></funapp>"
            "<funapp><sharp><name>g</name></sharp><var>X</var></funapp></rule>"
        )
        rule = (
            "<rule><funapp><name>h</name><var>X</var></funapp>"
            "<var>X</var></rule>"
        )
        row = {
            "metadata": {
                "processor_tag": "monoRedPairUrProc",
                "strategy_atom": "exact-poly(hex=5b5d)",
            },
            "output_xml": (
                "<monoRedPairUrProc><interpretation/>"
                f"<dps><rules>{pair}</rules></dps><dpProof/>"
                "</monoRedPairUrProc>"
            ),
            "input": {
                "problem_xml": (
                    "<input><dpInput>"
                    f"<trs><rules>{rule}</rules></trs>"
                    f"<dps><rules>{pair}</rules></dps>"
                    f"<usableRules><rules>{rule}</rules></usableRules>"
                    "<minimal>true</minimal></dpInput></input>"
                )
            },
        }

        EXTRACT.freeze_portable_atoms_before_runtime_rebind([row])
        candidate = EXTRACT.strategy_atom(row)
        self.assertIsNotNone(candidate)
        self.assertTrue(candidate.startswith("exact-red-pair("))
        self.assertEqual(
            row["metadata"]["portable_model_atom"],
            "exact-poly(hex=5b5d)",
        )
        row["input"]["problem_xml"] = row["input"]["problem_xml"].replace(
            "<name>f</name>", "<name>renamed_f</name>"
        )
        self.assertEqual(EXTRACT.strategy_atom(row), candidate)

    def test_exact_graph_marks_muterm_typed_component_as_open(self) -> None:
        rule = """
          <rule><funapp><sharp><name>f</name></sharp><var>X</var></funapp>
            <funapp><sharp><name>f</name></sharp><var>X</var></funapp></rule>
        """
        row = {
            "metadata": {"processor_tag": "depGraphProc"},
            "output_xml": f"""
              <depGraphProc><component><dps><rules>{rule}</rules></dps>
                <mutermTypedDpProof><noncollapsingCsrProof/></mutermTypedDpProof>
              </component></depGraphProc>
            """,
            "input": {
                "problem_xml": f"""
                  <dpInput><trs><rules/></trs><dps><rules>{rule}</rules></dps>
                    <minimal>true</minimal></dpInput>
                """,
            },
        }

        candidate = EXTRACT.strategy_atom(row)

        self.assertIsNotNone(candidate)
        encoded = candidate.removeprefix("exact-graph(hex=").removesuffix(")")
        source, components = json.loads(bytes.fromhex(encoded))
        self.assertIn("<dpInput>", source)
        self.assertEqual(components, [[[0], True]])

    def test_dp_transformation_with_empty_child_is_terminal(self) -> None:
        fragment = """
            <dpTrans><dps><rules/></dps>
              <dpProof><pIsEmpty/></dpProof>
            </dpTrans>
        """

        self.assertEqual(
            EXTRACT.event_outcome("dpTrans", fragment),
            ("solved", "closed"),
        )

    def test_degree_two_natural_polynomial_keeps_quadratic_family(self) -> None:
        row = {
            "metadata": {"processor_tag": "monoRedPairUrProc"},
            "output_xml": """
                <monoRedPairUrProc>
                  <interpretation>
                    <type><polynomial><domain><naturals/></domain><degree>2</degree>
                    </polynomial></type>
                    <interpret><name>f</name><arity>1</arity>
                      <sum><variable>1</variable></sum>
                    </interpret>
                  </interpretation>
                </monoRedPairUrProc>
            """,
            "input": {
                "problem_xml": """
                    <dpInput><trs><rules/></trs><dps><rules/></dps>
                    <minimal>true</minimal></dpInput>
                """,
            },
        }

        candidate = EXTRACT.strategy_atom(row)

        self.assertIsNotNone(candidate)
        self.assertTrue(candidate.startswith("quadratic-poly("), candidate)

    def test_linear_monotonic_processor_keeps_mono_poly_family(self) -> None:
        row = {
            "metadata": {"processor_tag": "monoRedPairProc"},
            "output_xml": """
                <monoRedPairProc>
                  <interpretation><type><polynomial>
                    <domain><naturals/></domain><degree>1</degree>
                  </polynomial></type></interpretation>
                </monoRedPairProc>
            """,
            "input": {"problem_xml": "<dpInput/>"},
        }

        candidate = EXTRACT.strategy_atom(row)

        self.assertIsNotNone(candidate)
        self.assertTrue(candidate.startswith("mono-poly("), candidate)

    def test_monotonic_reduction_pair_with_residual_is_exact(self) -> None:
        row = {
            "metadata": {"processor_tag": "monoRedPairProc"},
            "output_xml": """
                <monoRedPairProc>
                  <interpretation><type><polynomial>
                    <domain><naturals/></domain><degree>2</degree>
                  </polynomial></type></interpretation>
                  <dps><rules><rule><funapp><name>f</name></funapp>
                    <funapp><name>g</name></funapp></rule></rules></dps>
                  <trs><rules/></trs><dpProof><pIsEmpty/></dpProof>
                </monoRedPairProc>
            """,
            "input": {"problem_xml": """
                <dpInput><trs><rules/></trs><dps><rules>
                  <rule><funapp><name>f</name></funapp>
                    <funapp><name>g</name></funapp></rule>
                </rules></dps><minimal>true</minimal></dpInput>
            """},
        }

        candidate = EXTRACT.strategy_atom(row)

        self.assertIsNotNone(candidate)
        assert candidate is not None
        self.assertTrue(candidate.startswith("exact-red-pair(hex="), candidate)
        payload = json.loads(bytes.fromhex(candidate[19:-1]))
        self.assertEqual(payload[0], "monoRedPairProc")
        self.assertEqual(payload[2], [0])
        self.assertEqual(len(payload), 7)
        self.assertIn("<dps>", payload[3])
        self.assertIn("<usableRules>", payload[4])
        self.assertIn("<dps", payload[5])
        self.assertIn("<rules", payload[5])
        self.assertIn("<usableRules", payload[6])
        self.assertIn("<rules", payload[6])

    def test_innermost_q_monotonic_reduction_pair_with_residual_is_exact(self) -> None:
        row = {
            "metadata": {"processor_tag": "innermostMonoRedPairProc"},
            "output_xml": """
                <innermostMonoRedPairProc>
                  <interpretation><type><matrixInterpretation>
                    <domain><naturals/></domain><dimension>1</dimension>
                  </matrixInterpretation></type></interpretation>
                  <dps><rules><rule><funapp><name>f</name></funapp>
                    <funapp><name>g</name></funapp></rule></rules></dps>
                  <trs><rules><rule><funapp><name>h</name></funapp>
                    <funapp><name>k</name></funapp></rule></rules></trs>
                  <dpProof><pIsEmpty/></dpProof>
                </innermostMonoRedPairProc>
            """,
            "input": {"problem_xml": """
                <dpInput><trs><rules><rule><funapp><name>h</name></funapp>
                  <funapp><name>k</name></funapp></rule></rules></trs>
                  <dps><rules><rule><funapp><name>f</name></funapp>
                    <funapp><name>g</name></funapp></rule></rules></dps>
                  <strategy><innermost><nfs>true</nfs></innermost></strategy>
                  <minimal>true</minimal></dpInput>
            """},
        }

        candidate = EXTRACT.strategy_atom(row)

        self.assertIsNotNone(candidate)
        assert candidate is not None
        self.assertTrue(candidate.startswith("exact-red-pair(hex="), candidate)
        payload = json.loads(bytes.fromhex(candidate[19:-1]))
        self.assertEqual(payload[0], "innermostMonoRedPairProc")
        self.assertEqual(payload[2], [0])

    def test_linear_natural_polynomial_retains_exact_witness(self) -> None:
        row = {
            "metadata": {"processor_tag": "ruleRemoval"},
            "output_xml": """
                <ruleRemoval><interpretation><type><polynomial>
                  <domain><naturals/></domain><degree>1</degree>
                </polynomial></type>
                <interpret><name>f</name><arity>2</arity><sum>
                  <integer>1</integer><variable>1</variable>
                  <product><integer>2</integer><variable>2</variable></product>
                </sum></interpret>
                <interpret><sharp><name>f</name></sharp><arity>2</arity><sum>
                  <variable>1</variable><variable>2</variable>
                </sum></interpret>
                <interpret><name>z</name><arity>0</arity><integer>3</integer>
                </interpret></interpretation>
                <trsTerminationProof><ruleRemoval><interpretation><type><polynomial>
                  <domain><naturals/></domain><degree>1</degree>
                </polynomial></type>
                <interpret><name>f</name><arity>2</arity><sum>
                  <variable>1</variable><variable>2</variable>
                </sum></interpret></interpretation></ruleRemoval></trsTerminationProof>
                </ruleRemoval>
            """,
            "input": {"problem_xml": "<trsInput/>"},
        }

        candidate = EXTRACT.strategy_atom(row)

        self.assertIsNotNone(candidate)
        self.assertTrue(candidate.startswith("exact-poly(hex="), candidate)
        encoded = candidate.removeprefix("exact-poly(hex=").removesuffix(")")
        self.assertEqual(
            json.loads(bytes.fromhex(encoded)),
            [["f", 1, [1, 2]], ["f#", 0, [1, 1]], ["z", 3, []]],
        )

    def test_combined_csr_rule_removal_uses_exact_model_and_bare_child(self) -> None:
        row = {
            "metadata": {"processor_tag": "csrRuleRemovalThenImproved"},
            "output_xml": """
                <csrRuleRemovalThenImproved>
                  <interpretation><type><polynomial>
                    <domain><naturals/></domain><degree>1</degree>
                  </polynomial></type>
                  <interpret><name>f</name><arity>1</arity><sum>
                    <integer>1</integer><variable>1</variable>
                  </sum></interpret></interpretation>
                  <trs><rules/></trs><dps><rules/></dps>
                  <csrDpProof><pIsEmpty/></csrDpProof>
                </csrRuleRemovalThenImproved>
            """,
            "input": {"problem_xml": "<trsInput/>"},
        }

        candidate = EXTRACT.strategy_atom(row)

        self.assertIsNotNone(candidate)
        self.assertTrue(candidate.startswith("exact-poly(hex="), candidate)
        self.assertNotIn(";", candidate)
        self.assertNotIn("llm", candidate)

    def test_rational_polynomial_keeps_denominator_parameters(self) -> None:
        row = {
            "metadata": {"processor_tag": "redPairProc"},
            "output_xml": """
                <redPairProc><interpretation><type><polynomial>
                  <domain><rationals><delta><rational>
                    <numerator>1</numerator><denominator>16</denominator>
                  </rational></delta></rationals></domain>
                  <degree>2</degree>
                </polynomial></type>
                <interpret><name>f</name><arity>1</arity><product>
                  <rational><numerator>7</numerator><denominator>4</denominator>
                  </rational><variable>1</variable>
                </product></interpret>
                </interpretation></redPairProc>
            """,
            "input": {"problem_xml": "<dpInput/>"},
        }

        atom = EXTRACT.strategy_atom(row)
        self.assertIsNotNone(atom)
        assert atom is not None
        self.assertTrue(atom.startswith("exact-rat-poly(hex="), atom)
        encoded = atom.removeprefix("exact-rat-poly(hex=").removesuffix(")")
        self.assertEqual(json.loads(bytes.fromhex(encoded)), [4, [["f", 0, [7]]]])

    def test_natural_dp_matrix_retains_exact_marked_witness(self) -> None:
        row = {
            "metadata": {"processor_tag": "redPairProc"},
            "output_xml": """
                <redPairProc><interpretation><type><matrixInterpretation>
                  <domain><naturals/></domain><dimension>2</dimension>
                  <strictDimension>1</strictDimension>
                </matrixInterpretation></type>
                <interpret><sharp><name>f</name></sharp><arity>1</arity><sum>
                  <vector><integer>1</integer><integer>0</integer></vector>
                  <product><matrix>
                    <vector><integer>1</integer><integer>0</integer></vector>
                    <vector><integer>0</integer><integer>2</integer></vector>
                  </matrix><variable>1</variable></product>
                </sum></interpret></interpretation></redPairProc>
            """,
            "input": {"problem_xml": "<dpInput/>"},
        }

        candidate = EXTRACT.strategy_atom(row)

        self.assertTrue(candidate.startswith("exact-matrix(hex="), candidate)
        encoded = candidate.removeprefix("exact-matrix(hex=").removesuffix(")")
        self.assertEqual(
            json.loads(bytes.fromhex(encoded)),
            [["f#", [1, 0], [[[1, 0], [0, 2]]]]],
        )

    def test_natural_top_level_csr_matrix_retains_exact_witness(self) -> None:
        row = {
            "metadata": {"processor_tag": "redPairProc"},
            "output_xml": """
                <redPairProc><interpretation><type><matrixInterpretation>
                  <domain><naturals/></domain><dimension>2</dimension>
                  <strictDimension>1</strictDimension>
                </matrixInterpretation></type>
                <interpret><name>f</name><arity>1</arity><sum>
                  <vector><integer>1</integer><integer>0</integer></vector>
                  <product><matrix>
                    <vector><integer>1</integer><integer>0</integer></vector>
                    <vector><integer>0</integer><integer>2</integer></vector>
                  </matrix><variable>1</variable></product>
                </sum></interpret></interpretation></redPairProc>
            """,
            "input": {"problem_xml": "<trsInput><trs/></trsInput>"},
        }

        candidate = EXTRACT.strategy_atom(row)

        self.assertTrue(candidate.startswith("exact-matrix(hex="), candidate)
        encoded = candidate.removeprefix("exact-matrix(hex=").removesuffix(")")
        self.assertEqual(
            json.loads(bytes.fromhex(encoded)),
            [["f", [1, 0], [[[1, 0], [0, 2]]]]],
        )

    def test_arctic_dp_matrix_retains_domain_and_minus_infinity(self) -> None:
        row = {
            "metadata": {"processor_tag": "redPairProc"},
            "output_xml": """
                <redPairProc><interpretation><type><matrixInterpretation>
                  <domain><arctic><domain><naturals/></domain></arctic></domain>
                  <dimension>1</dimension><strictDimension>1</strictDimension>
                </matrixInterpretation></type>
                <interpret><sharp><name>f</name></sharp><arity>1</arity><sum>
                  <vector><integer>1</integer></vector><product><matrix>
                    <vector><minusInfinity/></vector>
                  </matrix><variable>1</variable></product>
                </sum></interpret></interpretation></redPairProc>
            """,
            "input": {"problem_xml": "<dpInput/>"},
        }

        candidate = EXTRACT.strategy_atom(row)

        self.assertTrue(candidate.startswith("exact-arctic(hex="), candidate)
        encoded = candidate.removeprefix("exact-arctic(hex=").removesuffix(")")
        self.assertEqual(
            json.loads(bytes.fromhex(encoded)),
            [False, [["f#", [1], [[[-(1 << 63)]]]]]],
        )

    def test_sharp_and_unsharp_interpretations_count_as_distinct_symbols(self) -> None:
        row = {
            "metadata": {"processor_tag": "redPairProc"},
            "output_xml": """
                <redPairProc><orderingConstraintProof><redPair>
                  <interpretation>
                    <type><polynomial><domain><naturals/></domain><degree>2</degree>
                    </polynomial></type>
                    <interpret><name>f</name><arity>1</arity>
                      <sum><variable>1</variable></sum>
                    </interpret>
                    <interpret><sharp><name>f</name></sharp><arity>1</arity>
                      <sum><variable>1</variable></sum>
                    </interpret>
                  </interpretation>
                </redPair></orderingConstraintProof></redPairProc>
            """,
            "input": {"problem_xml": "<dpInput/>"},
        }

        candidate = EXTRACT.strategy_atom(row)

        self.assertIsNotNone(candidate)
        self.assertIn("symbols=2", candidate)

    def test_arctic_matrix_is_not_replayed_as_natural_matrix(self) -> None:
        row = {
            "metadata": {"processor_tag": "redPairProc"},
            "output_xml": """
                <redPairProc><orderingConstraintProof><redPair>
                  <interpretation><type><matrixInterpretation>
                    <domain><arctic/></domain><dimension>3</dimension>
                  </matrixInterpretation></type></interpretation>
                </redPair></orderingConstraintProof></redPairProc>
            """,
            "input": {
                "problem_xml": """
                    <dpInput><trs><rules/></trs><dps><rules/></dps>
                    <minimal>true</minimal></dpInput>
                """,
            },
        }

        candidate = EXTRACT.strategy_atom(row)

        self.assertIsNotNone(candidate)
        self.assertTrue(candidate.startswith("arctic-matrix("), candidate)

    def test_string_reversal_keeps_its_native_strategy_atom(self) -> None:
        row = {
            "metadata": {"processor_tag": "stringReversal"},
            "output_xml": "<stringReversal/>",
            "input": {"problem_xml": "<trsInput/>"},
        }

        self.assertEqual(EXTRACT.strategy_atom(row), "string-reversal")

    def test_native_subterm_and_size_change_keep_distinct_atoms(self) -> None:
        for processor, expected in (
            ("subtermProc", "subterm"),
            ("sizeChangeProc", "size-change"),
        ):
            with self.subTest(processor=processor):
                self.assertEqual(
                    EXTRACT.strategy_atom(
                        {
                            "metadata": {"processor_tag": processor},
                            "output_xml": f"<{processor}/>",
                            "input": {"problem_xml": "<dpInput/>"},
                        }
                    ),
                    expected,
                )

    def test_dp_switch_innermost_keeps_executable_dp_atom(self) -> None:
        row = {
            "metadata": {"processor_tag": "switchInnermostProc"},
            "output_xml": (
                "<switchInnermostProc><wcrProof><joinAutoBfs>1</joinAutoBfs>"
                "</wcrProof><dpProof><pIsEmpty/></dpProof>"
                "</switchInnermostProc>"
            ),
            "input": {"problem_xml": "<dpInput/>"},
        }

        self.assertEqual(EXTRACT.strategy_atom(row), "switch-innermost")
        self.assertEqual(
            EXTRACT.event_outcome("switchInnermostProc", row["output_xml"]),
            ("transformed", "strong"),
        )

    def test_aaecc_switch_keeps_executable_atom_and_materializes_innermost_child(self) -> None:
        current_input = ET.fromstring(
            "<input><trsInput><trs><rules/></trs></trsInput></input>"
        )
        step = ET.fromstring(
            "<aaeccInnermost><r1><rules/></r1><r2><rules/></r2>"
            "<sigma><entry/></sigma><wcrProof><joinAutoBfs>1</joinAutoBfs></wcrProof>"
            "<trsTerminationProof><rIsEmpty/></trsTerminationProof>"
            "</aaeccInnermost>"
        )
        child = step.find("trsTerminationProof")
        self.assertIsNotNone(child)

        child_input, reason = child_input_for(step, child, current_input)

        self.assertIsNone(reason)
        self.assertIsNotNone(child_input)
        self.assertIsNotNone(inner_input(child_input).find("strategy/innermost"))
        row = {
            "metadata": {"processor_tag": "aaeccInnermost"},
            "output_xml": ET.tostring(step, encoding="unicode"),
            "input": {"problem_xml": ET.tostring(current_input, encoding="unicode")},
        }
        self.assertEqual(EXTRACT.strategy_atom(row), "aaecc-innermost")
        self.assertEqual(
            EXTRACT.event_outcome("aaeccInnermost", row["output_xml"]),
            ("transformed", "strong"),
        )

    def test_switch_full_loop_uses_executable_nontermination_guidance(self) -> None:
        switch_row = {
            "metadata": {"processor_tag": "switchFullStrategy"},
            "output_xml": (
                "<switchFullStrategy><trsNonterminationProof><loop/>"
                "</trsNonterminationProof></switchFullStrategy>"
            ),
            "input": {"problem_xml": "<trsInput/>"},
        }
        loop_row = {
            "metadata": {"processor_tag": "loop"},
            "output_xml": "<loop/>",
            "input": {"problem_xml": "<trsInput/>"},
        }

        self.assertEqual(
            EXTRACT.strategy_atom(switch_row), "nontermination(loop)"
        )
        self.assertEqual(
            EXTRACT.event_outcome(
                "switchFullStrategy", switch_row["output_xml"]
            ),
            ("transformed", "strong"),
        )
        self.assertEqual(
            EXTRACT.strategy_atom(loop_row).split("(")[0], "exact-trs-nontermination-terminal"
        )
        self.assertEqual(
            EXTRACT.event_outcome("loop", loop_row["output_xml"]),
            ("solved", "closed"),
        )

    def test_recovers_root_uncurry_transformation(self) -> None:
        root = ET.fromstring("""
            <certificationProblem>
              <input><trsInput><trs><rules/></trs></trsInput></input>
              <proof><trsTerminationProof><uncurry>
                <uncurryInformation/>
                <trsTerminationProof><rIsEmpty/></trsTerminationProof>
              </uncurry></trsTerminationProof></proof>
            </certificationProblem>
        """)

        row = EXTRACT.root_uncurry_row(root)

        self.assertIsNotNone(row)
        self.assertEqual(EXTRACT.strategy_atom(row), "uncurry")
        self.assertEqual(
            EXTRACT.event_outcome("uncurry", row["output_xml"]),
            ("transformed", "strong"),
        )

    def test_recovers_dp_applicative_top_uncurry_transformation(self) -> None:
        root = ET.fromstring("""
            <certificationProblem>
              <input><dpInput><trs><rules/></trs><dps><rules/></dps>
                <minimal>true</minimal></dpInput></input>
              <proof><dpProof><uncurryProc>
                <applicativeTop>2</applicativeTop>
                <uncurryInformation/>
                <dps><rules/></dps><trs><rules/></trs>
                <dpProof><pIsEmpty/></dpProof>
              </uncurryProc></dpProof></proof>
            </certificationProblem>
        """)

        row = EXTRACT.root_dp_uncurry_row(root)

        self.assertIsNotNone(row)
        self.assertEqual(EXTRACT.strategy_atom(row), "uncurry")
        self.assertEqual(
            EXTRACT.event_outcome("uncurryProc", row["output_xml"]),
            ("transformed", "strong"),
        )

    def test_recovers_root_dp_transformation_below_trs_wrapper(self) -> None:
        root = ET.fromstring("""
            <certificationProblem>
              <input><trsInput><trs><rules/></trs></trsInput></input>
              <proof><trsTerminationProof><dpTrans>
                <dps><rules/></dps><dpProof><pIsEmpty/></dpProof>
              </dpTrans></trsTerminationProof></proof>
            </certificationProblem>
        """)

        row = EXTRACT.root_direct_processor_row(root)

        self.assertIsNotNone(row)
        self.assertEqual(EXTRACT.strategy_atom(row), "dp")

        EXTRACT.freeze_portable_atoms_before_runtime_rebind([row])
        self.assertTrue(row["metadata"]["strategy_atom"].startswith("exact-dp(hex="))

    def test_recovers_recursive_dp_transformation_below_nontermination_wrapper(self) -> None:
        root = ET.fromstring("""
            <certificationProblem>
              <input><trsInput><trs><rules/></trs></trsInput></input>
              <proof><trsNonterminationProof><dpTrans>
                <dps><rules><rule/></rules></dps>
                <dpNonterminationProof><loop/></dpNonterminationProof>
              </dpTrans></trsNonterminationProof></proof>
            </certificationProblem>
        """)

        row = EXTRACT.root_direct_processor_row(root)

        self.assertIsNotNone(row)
        self.assertEqual(EXTRACT.strategy_atom(row), "dp")

    def test_recovers_root_improved_csr_dp_transformation(self) -> None:
        root = ET.fromstring("""
            <certificationProblem>
              <input><trsInput><trs><rules/></trs>
                <strategy><contextSensitive/></strategy></trsInput></input>
              <proof><csrImprovedDependencyPairs>
                <dps><rules/></dps><csrDpProof><pIsEmpty/></csrDpProof>
              </csrImprovedDependencyPairs></proof>
            </certificationProblem>
        """)

        row = EXTRACT.root_direct_processor_row(root)

        self.assertIsNotNone(row)
        self.assertEqual(EXTRACT.strategy_atom(row), "csr-improved-dp")

    def test_recovers_root_gm04_inverse_transformation(self) -> None:
        root = ET.fromstring("""
            <certificationProblem>
              <input><trsInput><trs><rules/></trs>
                <strategy><innermost/></strategy></trsInput></input>
              <proof><trsTerminationProof><gm04CompleteTransformation>
                <sourceTrs><rules/></sourceTrs>
                <transformedProof><dpTrans><dps><rules/></dps>
                  <dpProof><pIsEmpty/></dpProof></dpTrans></transformedProof>
                <sourceProof><rIsEmpty/></sourceProof>
              </gm04CompleteTransformation></trsTerminationProof></proof>
            </certificationProblem>
        """)

        row = EXTRACT.root_direct_processor_row(root)

        self.assertIsNotNone(row)
        self.assertEqual(EXTRACT.strategy_atom(row), "gm04-inverse-csr")
        self.assertEqual(
            EXTRACT.event_outcome(
                "gm04CompleteTransformation", row["output_xml"]
            ),
            ("transformed", "strong"),
        )

    def test_gm04_materializes_both_independent_child_obligations(self) -> None:
        root = ET.fromstring("""
            <certificationProblem>
              <input><trsInput><trs><rules><rule><var>x</var><var>x</var></rule></rules></trs>
                <strategy><innermost><nfs>true</nfs></innermost></strategy></trsInput></input>
              <proof><trsTerminationProof><gm04CompleteTransformation>
                <sourceReplacementMap><contextSensitive>
                  <replacementMapEntry><name>f</name><arity>1</arity><position>1</position>
                  </replacementMapEntry>
                </contextSensitive></sourceReplacementMap>
                <sourceTrs><rules><rule><funapp><name>f</name><var>x</var></funapp>
                  <var>x</var></rule></rules></sourceTrs>
                <transformedProof><dpTrans><dps><rules/></dps>
                  <dpProof><pIsEmpty/></dpProof></dpTrans></transformedProof>
                <sourceProof><csrImprovedDependencyPairs><dps><rules/></dps>
                  <csrDpProof><pIsEmpty/></csrDpProof>
                </csrImprovedDependencyPairs></sourceProof>
              </gm04CompleteTransformation></trsTerminationProof></proof>
            </certificationProblem>
        """)
        source = {
            "proof_url": "local://gm04/proof.xml",
            "normalizer": None,
            "source_kind": "local-certified-cpf",
            "xml_path": "proof.xml",
            "xml_format": "4.0",
            "year": 2025,
            "category": "TRS_Innermost",
            "benchmark": "Transformed_CSR_innermost_04/example_C.ari",
            "tool": "Ferrum",
            "result": "YES",
            "certification": "certified",
        }

        rows, reasons = iter_exact_rows(source, root)

        by_tag = {row["metadata"]["processor_tag"]: row for row in rows}
        self.assertNotIn("dpTrans", by_tag)
        self.assertIn("pIsEmpty", by_tag)
        self.assertIn("csrImprovedDependencyPairs", by_tag)
        transformed_row = next(
            row
            for row in rows
            if row["metadata"]["processor_tag"] == "pIsEmpty"
            and row["metadata"]["causal_parent_processor_tag"]
            == "gm04CompleteTransformation"
        )
        transformed_input = ET.fromstring(
            transformed_row["input"]["problem_xml"]
        )
        source_input = ET.fromstring(
            by_tag["csrImprovedDependencyPairs"]["input"]["problem_xml"]
        )
        self.assertIsNotNone(transformed_input.find("dpInput/strategy/innermost"))
        self.assertIsNotNone(source_input.find("trsInput/strategy/contextSensitive"))
        self.assertEqual(reasons.get("unsupported_transition", 0), 0)

    def test_gm04_nontermination_materializes_independent_source_loop(self) -> None:
        root = ET.fromstring("""
            <certificationProblem>
              <input><trsInput><trs><rules/></trs><strategy><full/></strategy>
                </trsInput></input>
              <proof><trsNonterminationProof>
                <gm04CompleteNonterminationTransformation>
                  <sourceReplacementMap><contextSensitive>
                    <replacementMapEntry><name>f</name><arity>1</arity>
                      <position>1</position></replacementMapEntry>
                  </contextSensitive></sourceReplacementMap>
                  <sourceTrs><rules><rule><funapp><name>f</name><var>x</var></funapp>
                    <funapp><name>f</name><var>x</var></funapp></rule></rules></sourceTrs>
                  <sourceProof><loop><rewriteSequence>
                    <startTerm><funapp><name>f</name><var>x</var></funapp></startTerm>
                  </rewriteSequence><substitution/><box/></loop></sourceProof>
                </gm04CompleteNonterminationTransformation>
              </trsNonterminationProof></proof>
            </certificationProblem>
        """)
        source = {
            "proof_url": "local://gm04/nontermination.xml",
            "normalizer": None,
            "source_kind": "local-certified-cpf",
            "xml_path": "proof.xml",
            "xml_format": "4.0",
            "year": 2025,
            "category": "TRS_Standard",
            "benchmark": "Transformed_CSR_04/example_C.ari",
            "tool": "Ferrum",
            "result": "NO",
            "certification": "certified",
        }

        root_row = EXTRACT.root_direct_processor_row(root)
        rows, reasons = iter_exact_rows(source, root)

        self.assertIsNotNone(root_row)
        self.assertEqual(EXTRACT.strategy_atom(root_row), "gm04-inverse-csr")
        by_tag = {row["metadata"]["processor_tag"]: row for row in rows}
        self.assertIn("loop", by_tag)
        source_input = ET.fromstring(by_tag["loop"]["input"]["problem_xml"])
        self.assertIsNotNone(source_input.find("trsInput/strategy/contextSensitive"))
        self.assertEqual(reasons.get("unsupported_transition", 0), 0)

    def test_general_red_pair_children_retain_ordered_branch_identity(self) -> None:
        rule = lambda left, right: (
            f"<rule><funapp><name>{left}</name></funapp>"
            f"<funapp><name>{right}</name></funapp></rule>"
        )
        pairs = rule("a", "b") + rule("c", "d") + rule("e", "f")
        root = ET.fromstring(f"""
          <certificationProblem>
            <input><dpInput><trs><rules/></trs><dps><rules>{pairs}</rules></dps>
              <minimal>true</minimal></dpInput></input>
            <proof><dpProof><generalRedPairProc><interpretation/>
              <strict><rules>{rule("e", "f")}</rules></strict>
              <bound><rules>{rule("c", "d")}</rules></bound>
              <condRedPairProof/>
              <dpProof><pIsEmpty/></dpProof>
              <dpProof><pIsEmpty/></dpProof>
            </generalRedPairProc></dpProof></proof>
          </certificationProblem>
        """)
        source = {
            "proof_url": "local://general-red-pair/proof.xml",
            "normalizer": None,
            "source_kind": "local-certified-cpf",
            "xml_path": "proof.xml",
            "xml_format": "3.0",
            "year": 2025,
            "category": "TRS_Standard",
            "benchmark": "example.ari",
            "tool": "AProVE",
            "result": "YES",
            "certification": "certified",
        }

        rows, _ = iter_exact_rows(source, root)
        children = [
            row
            for row in rows
            if row["metadata"]["processor_tag"] == "pIsEmpty"
            and row["metadata"]["causal_parent_processor_tag"]
            == "generalRedPairProc"
        ]

        self.assertEqual(
            [row["metadata"]["causal_parent_branch_index"] for row in children],
            [0, 1],
        )

    def test_graph_children_retain_graph_parent_and_branch_identity(self) -> None:
        rule = lambda left, right: (
            f"<rule><funapp><name>{left}</name></funapp>"
            f"<funapp><name>{right}</name></funapp></rule>"
        )
        first = rule("a", "b")
        second = rule("c", "d")
        root = ET.fromstring(f"""
          <certificationProblem>
            <input><dpInput><trs><rules/></trs><dps><rules>{first}{second}</rules></dps>
              <minimal>true</minimal></dpInput></input>
            <proof><dpProof><depGraphProc>
              <component><dps><rules>{first}</rules></dps>
                <dpProof><pIsEmpty/></dpProof></component>
              <component><dps><rules>{second}</rules></dps>
                <dpProof><pIsEmpty/></dpProof></component>
            </depGraphProc></dpProof></proof>
          </certificationProblem>
        """)
        source = {
            "proof_url": "local://graph-branches/proof.xml",
            "normalizer": None,
            "source_kind": "local-certified-cpf",
            "xml_path": "proof.xml",
            "xml_format": "3.0",
            "year": 2025,
            "category": "TRS_Standard",
            "benchmark": "example.ari",
            "tool": "AProVE",
            "result": "YES",
            "certification": "certified",
        }

        rows, _ = iter_exact_rows(source, root)
        children = [
            row for row in rows if row["metadata"]["processor_tag"] == "pIsEmpty"
        ]

        self.assertEqual(
            [row["metadata"]["causal_parent_processor_tag"] for row in children],
            ["depGraphProc", "depGraphProc"],
        )
        self.assertEqual(
            [row["metadata"]["causal_parent_branch_index"] for row in children],
            [0, 1],
        )

    def test_general_red_pair_causal_fingerprint_ignores_numeric_alias_spelling(self) -> None:
        def atom(symbol: str, strict_index: int, bound_index: int) -> str:
            witness = [
                f"<strict><rules><rule><funapp><name>{symbol}</name></funapp>"
                "<funapp><name>f</name></funapp></rule></rules></strict>"
                "<bound><rules><rule><funapp><name>g</name></funapp>"
                "<funapp><name>h</name></funapp></rule></rules></bound>",
                [strict_index],
                [bound_index],
                False,
            ]
            encoded = json.dumps(witness, separators=(",", ":")).encode().hex()
            return f"exact-general-red-pair(hex={encoded})"

        self.assertEqual(
            EXTRACT.exact_causal_atom_fingerprint(atom("0", 0, 1)),
            EXTRACT.exact_causal_atom_fingerprint(atom("|0|", 1, 0)),
        )

    def test_legacy_bare_dp_event_uses_explicit_csr_proof_construction(self) -> None:
        proof = ET.fromstring("""
            <proof><csrImprovedDependencyPairs>
              <dps><rules/></dps><csrDpProof><pIsEmpty/></csrDpProof>
            </csrImprovedDependencyPairs></proof>
        """)

        self.assertEqual(
            EXTRACT.explicit_csr_dp_atom_from_proof(proof),
            "csr-improved-dp",
        )


if __name__ == "__main__":
    unittest.main()
