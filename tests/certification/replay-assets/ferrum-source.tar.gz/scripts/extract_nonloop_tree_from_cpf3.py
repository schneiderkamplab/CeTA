#!/usr/bin/env python3
"""Extract Ferrum's compact pattern nonLoop JSON from a CPF3 proof."""

from __future__ import annotations

import argparse
import json
import sys
import xml.etree.ElementTree as ET
from pathlib import Path

RULE_TABLE = {}


def tag(element: ET.Element) -> str:
    return element.tag.rsplit("}", 1)[-1]


def children(element: ET.Element, name: str | None = None) -> list[ET.Element]:
    return [child for child in list(element) if name is None or tag(child) == name]


def first_child(element: ET.Element, name: str) -> ET.Element:
    matches = children(element, name)
    if not matches:
        raise ValueError(f"missing <{name}> under <{tag(element)}>")
    return matches[0]


def first_descendant(element: ET.Element, name: str) -> ET.Element:
    for descendant in element.iter():
        if tag(descendant) == name:
            return descendant
    raise ValueError(f"missing descendant <{name}>")


def text(element: ET.Element) -> str:
    value = element.text or ""
    return value.strip()


def term_children(element: ET.Element) -> list[ET.Element]:
    result = []
    for child in children(element):
        child_tag = tag(child)
        if child_tag in {"funapp", "var"}:
            result.append(child)
        elif child_tag == "arg":
            result.extend(grandchild for grandchild in children(child) if tag(grandchild) in {"funapp", "var"})
    return result


def term(node: ET.Element):
    node_tag = tag(node)
    if node_tag == "var":
        return ["v", text(node)]
    if node_tag != "funapp":
        raise ValueError(f"expected term, got <{node_tag}>")
    sharp = children(node, "sharp")
    name_node = first_child(sharp[0], "name") if sharp else first_child(node, "name")
    symbol = text(name_node)
    if sharp:
        symbol += "#"
    args = [term(child) for child in term_children(node)]
    return ["a", symbol, args]


def substitution(node: ET.Element):
    entries = []
    for entry in children(node, "substEntry"):
        entry_children = children(entry)
        variable = next(child for child in entry_children if tag(child) == "var")
        value = next(child for child in entry_children[entry_children.index(variable) + 1 :] if tag(child) in {"funapp", "var"})
        entries.append([text(variable), term(value)])
    return entries


def position(node: ET.Element):
    return [int(text(entry)) for entry in children(node, "position")]


def pattern_term(node: ET.Element):
    term_node = next(child for child in children(node) if tag(child) in {"funapp", "var"})
    substitutions = children(node, "substitution")
    while len(substitutions) < 2:
        substitutions.append(ET.Element("substitution"))
    return [term(term_node), substitution(substitutions[0]), substitution(substitutions[1])]


def rule_pattern_from_original(node: ET.Element):
    rule = first_child(node, "rule")
    lhs = first_child(first_child(rule, "lhs"), "funapp")
    rhs_parent = first_child(rule, "rhs")
    rhs = next(child for child in children(rhs_parent) if tag(child) in {"funapp", "var"})
    empty = []
    return [[term(lhs), empty, empty], [term(rhs), empty, empty]]


def rule_terms(node: ET.Element):
    terms = [child for child in children(node) if tag(child) in {"funapp", "var"}]
    if len(terms) == 2:
        return [term(terms[0]), term(terms[1])]
    lhs = first_child(first_child(node, "lhs"), "funapp")
    rhs_parent = first_child(node, "rhs")
    rhs = next(child for child in children(rhs_parent) if tag(child) in {"funapp", "var"})
    return [term(lhs), term(rhs)]


def pattern_rule(node: ET.Element):
    pattern_terms = children(node, "patternTerm")
    if len(pattern_terms) < 2:
        raise ValueError(f"patternRule needs two patternTerm children, got {len(pattern_terms)}")
    pattern = [pattern_term(pattern_terms[0]), pattern_term(pattern_terms[1])]
    proof_node = next(
        (
            child
            for child in children(node)
            if tag(child)
            in {
                "originalRule",
                "instantiation",
                "equivalence",
                "narrowing",
                "initialPumping",
                "initialPumpingContext",
                "rewriting",
            }
        ),
        None,
    )
    if proof_node is None:
        raise ValueError("patternRule has no supported proof node")
    proof_tag = tag(proof_node)
    if proof_tag == "originalRule":
        return {
            "k": "originalRule",
            "p": pattern,
            "pair": text(first_child(proof_node, "isPair")) == "true",
        }
    if proof_tag == "instantiation":
        target = next(
            tag(child)
            for child in children(proof_node)
            if tag(child) in {"base", "pumping", "closing"}
        )
        return {
            "k": "instantiation",
            "p": pattern,
            "child": pattern_rule(first_child(proof_node, "patternRule")),
            "subst": substitution(first_child(proof_node, "substitution")),
            "target": target,
        }
    if proof_tag == "equivalence":
        eq_node = first_child(proof_node, "patternEquivalence")
        eq_child = next(child for child in children(eq_node) if tag(child) in {"domainRenaming", "irrelevant", "simplification"})
        substs = children(eq_child, "substitution")
        while len(substs) < 2:
            substs.append(ET.Element("substitution"))
        side = "left" if children(proof_node, "left") else "right"
        return {
            "k": "equivalence",
            "p": pattern,
            "child": pattern_rule(first_child(proof_node, "patternRule")),
            "side": side,
            "eq": tag(eq_child),
            "substs": [substitution(substs[0]), substitution(substs[1])],
        }
    if proof_tag == "narrowing":
        rules = children(proof_node, "patternRule")
        if len(rules) < 2:
            raise ValueError("narrowing needs child and narrowing rule")
        return {
            "k": "narrowing",
            "p": pattern,
            "child": pattern_rule(rules[0]),
            "rule": pattern_rule(rules[1]),
            "pos": position(first_child(proof_node, "positionInTerm")),
        }
    if proof_tag == "rewriting":
        target_node = next(
            child for child in children(proof_node) if tag(child) in {"base", "pumping", "closing"}
        )
        variable = children(target_node, "var")
        return {
            "k": "rewriting",
            "p": pattern,
            "child": pattern_rule(first_child(proof_node, "patternRule")),
            "start": term(
                next(
                    child
                    for child in children(first_child(proof_node, "rewriteSequence"), "startTerm")[0]
                    if tag(child) in {"funapp", "var"}
                )
            ),
            "steps": rewrite_steps(first_child(proof_node, "rewriteSequence")),
            "target": tag(target_node),
            "var": text(variable[0]) if variable else None,
        }
    if proof_tag == "initialPumping":
        substs = children(proof_node, "substitution")
        while len(substs) < 2:
            substs.append(ET.Element("substitution"))
        return {
            "k": "initialPumping",
            "p": pattern,
            "child": pattern_rule(first_child(proof_node, "patternRule")),
            "substs": [substitution(substs[0]), substitution(substs[1])],
        }
    if proof_tag == "initialPumpingContext":
        return {
            "k": "initialPumpingContext",
            "p": pattern,
            "child": pattern_rule(first_child(proof_node, "patternRule")),
            "subst": substitution(first_child(proof_node, "substitution")),
            "pos": position(first_child(proof_node, "positionInTerm")),
            "var": text(first_child(proof_node, "var")),
        }
    raise ValueError(f"unsupported proof tag <{proof_tag}>")


def rewrite_steps(node: ET.Element):
    result = []
    for step in children(node, "rewriteStep"):
        rule_nodes = children(step, "rule")
        if rule_nodes:
            rule = rule_terms(rule_nodes[0])
        else:
            rule_index = int(text(first_child(step, "ruleIndex")))
            rule = RULE_TABLE[rule_index]
        result_node = next(child for child in children(step) if tag(child) in {"funapp", "var"})
        result.append(
            {
                "pos": position(first_child(step, "positionInTerm")),
                "rule": rule,
                "result": term(result_node),
            }
        )
    return result


def load_rule_table(root: ET.Element):
    for table in root.iter():
        if tag(table) != "ruleTable":
            continue
        for entry in children(table, "indexToRule"):
            RULE_TABLE[int(text(first_child(entry, "index")))] = rule_terms(first_child(entry, "rule"))


def nonloop(node: ET.Element):
    pattern = first_child(node, "patternRule")
    substitutions = children(node, "substitution")
    naturals = children(node, "natural")
    if len(substitutions) < 2 or len(naturals) < 2:
        raise ValueError("nonLoop needs two substitutions and two naturals")
    return {
        "nonloop": {
            "pattern": pattern_rule(pattern),
            "pump": substitution(substitutions[0]),
            "close": substitution(substitutions[1]),
            "m": int(text(naturals[0])),
            "b": int(text(naturals[1])),
            "pos": position(first_child(node, "positionInTerm")),
        }
    }


def loop(node: ET.Element):
    sequence = first_child(node, "rewriteSequence")
    start = first_child(sequence, "startTerm")
    start_term = next(child for child in children(start) if tag(child) in {"funapp", "var"})
    context = children(node)[-1]
    if tag(context) != "box":
        raise ValueError("loop extraction currently requires a root-closing <box/>")
    return {
        "loop": {
            "start": term(start_term),
            "steps": rewrite_steps(sequence),
            "subst": substitution(first_child(node, "substitution")),
            "pos": [],
        }
    }


def parse_cpf_or_solver_output(path: Path) -> ET.Element:
    encoded = path.read_text()
    xml_start = encoded.find("<?xml")
    if xml_start < 0:
        xml_start = encoded.find("<certificationProblem")
    if xml_start < 0:
        raise ValueError(f"no CPF XML document found in {path}")
    return ET.fromstring(encoded[xml_start:])


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("cpf3", type=Path)
    parser.add_argument("-o", "--output", type=Path)
    parser.add_argument("--loop", action="store_true", help="extract the first root-closing loop")
    args = parser.parse_args()

    root = parse_cpf_or_solver_output(args.cpf3)
    load_rule_table(root)
    data = (
        loop(first_descendant(root, "loop"))
        if args.loop
        else nonloop(first_descendant(root, "nonLoop"))
    )
    encoded = json.dumps(data, separators=(",", ":"), sort_keys=True)
    if args.output is None:
        print(encoded)
    else:
        args.output.write_text(encoded + "\n")
    return 0


if __name__ == "__main__":
    sys.exit(main())
