#!/usr/bin/env python3
"""Recover indexed TermCOMP proof outputs from the Internet Archive Wayback Machine."""

from __future__ import annotations

import argparse
import concurrent.futures
import hashlib
import json
import re
import sqlite3
import time
import urllib.error
import urllib.parse
import urllib.request
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from collect_termcomp_proofs import extract_features, proof_local_path
from import_termcomp_zenodo_archives import ensure_archive_columns


USER_AGENT = "ferrum-proof-corpus/0.1"


@dataclass(frozen=True)
class ProofRow:
    year: int
    category: str
    benchmark: str
    tool: str
    tool_column: int
    result: str
    certification: str
    proof_url: str
    error_url: str | None
    benchmark_url: str
    runtime_seconds: float | None
    cert_runtime_seconds: float | None


def fetch_text(url: str, timeout: int = 30) -> str:
    req = urllib.request.Request(url, headers={"User-Agent": USER_AGENT})
    with urllib.request.urlopen(req, timeout=timeout) as response:
        return response.read().decode("utf-8", "replace")


def fetch_bytes(url: str, timeout: int = 60) -> bytes:
    req = urllib.request.Request(url, headers={"User-Agent": USER_AGENT})
    with urllib.request.urlopen(req, timeout=timeout) as response:
        return response.read()


def url_variants(url: str, mode: str = "exact") -> list[str]:
    if mode == "exact":
        return [url]
    parsed = urllib.parse.urlparse(url)
    hosts = [parsed.netloc]
    if parsed.netloc == "www.starexec.org":
        hosts.append("starexec.org")
    elif parsed.netloc == "starexec.org":
        hosts.append("www.starexec.org")
    schemes = [parsed.scheme or "https"]
    schemes.append("http" if schemes[0] == "https" else "https")
    variants = []
    for scheme in schemes:
        for host in hosts:
            variants.append(urllib.parse.urlunparse((scheme, host, parsed.path, "", parsed.query, "")))
    return list(dict.fromkeys(variants))


def cdx_url(url: str) -> str:
    return "https://web.archive.org/cdx?" + urllib.parse.urlencode(
        {
            "url": url,
            "output": "json",
            "fl": "timestamp,original,statuscode,mimetype,digest,length",
            "filter": "statuscode:200",
            "collapse": "digest",
        }
    )


def query_cdx(url: str, retries: int, delay: float) -> list[dict[str, str]]:
    last_error: str | None = None
    for attempt in range(retries + 1):
        try:
            text = fetch_text(cdx_url(url))
            rows = json.loads(text)
            if not rows:
                return []
            header = rows[0]
            return [dict(zip(header, row)) for row in rows[1:]]
        except Exception as error:  # noqa: BLE001 - stored in probe cache.
            last_error = repr(error)
            if attempt < retries:
                time.sleep(delay * (attempt + 1))
    return [{"error": last_error or "unknown CDX error"}]


def replay_url(capture: dict[str, str]) -> str:
    return f"https://web.archive.org/web/{capture['timestamp']}id_/{capture['original']}"


def plausible_stdout(data: bytes, expected_result: str) -> bool:
    text = data[:4096].decode("utf-8", "replace").lstrip()
    if text.startswith("<!DOCTYPE html") or text.startswith("<html"):
        return False
    expected = "YES" if "YES" in expected_result else "NO" if "NO" in expected_result else ""
    return not expected or text.startswith(expected)


def ensure_tables(conn: sqlite3.Connection) -> None:
    ensure_archive_columns(conn)
    conn.execute(
        """
        create table if not exists wayback_probes (
            proof_url text not null,
            variant_url text not null,
            checked_at real not null,
            status text not null,
            captures_json text not null,
            primary key (proof_url, variant_url)
        )
        """
    )


def cached_probe(
    conn: sqlite3.Connection,
    proof_url: str,
    variant_url: str,
    retry_errors: bool,
) -> list[dict[str, str]] | None:
    row = conn.execute(
        "select status, captures_json from wayback_probes where proof_url = ? and variant_url = ?",
        (proof_url, variant_url),
    ).fetchone()
    if row is None:
        return None
    status, captures_json = row
    if status == "error":
        if retry_errors:
            return None
        return [{"error": json.loads(captures_json).get("error", "cached error")}]
    return json.loads(captures_json)


def store_probe(
    conn: sqlite3.Connection,
    proof_url: str,
    variant_url: str,
    captures: list[dict[str, str]],
) -> None:
    status = "error" if captures and "error" in captures[0] else "ok"
    payload: Any = {"error": captures[0]["error"]} if status == "error" else captures
    conn.execute(
        """
        insert or replace into wayback_probes
            (proof_url, variant_url, checked_at, status, captures_json)
        values (?, ?, ?, ?, ?)
        """,
        (proof_url, variant_url, time.time(), status, json.dumps(payload, sort_keys=True)),
    )


def load_rows(conn: sqlite3.Connection, year: int, category: str, limit: int | None) -> list[ProofRow]:
    query = """
        select year, category, benchmark, tool, tool_column, result, certification,
               proof_url, error_url, benchmark_url, runtime_seconds, cert_runtime_seconds
        from proofs
        where year = ?
          and category = ?
          and download_error is not null
        order by proof_url
    """
    if limit is not None:
        query += " limit ?"
        raw_rows = conn.execute(query, (year, category, limit)).fetchall()
    else:
        raw_rows = conn.execute(query, (year, category)).fetchall()
    return [ProofRow(*row) for row in raw_rows]


def probe_one(
    db_path: Path,
    row: ProofRow,
    retries: int,
    delay: float,
    use_cache: bool,
    variant_mode: str,
    retry_cached_errors: bool,
) -> tuple[str, list[dict[str, str]]]:
    conn = sqlite3.connect(db_path, timeout=60)
    ensure_tables(conn)
    all_captures: list[dict[str, str]] = []
    errors: list[str] = []
    for variant in url_variants(row.proof_url, variant_mode):
        captures = cached_probe(conn, row.proof_url, variant, retry_cached_errors) if use_cache else None
        if captures is None:
            captures = query_cdx(variant, retries, delay)
            store_probe(conn, row.proof_url, variant, captures)
            conn.commit()
        if captures and "error" in captures[0]:
            errors.append(captures[0]["error"])
            continue
        all_captures.extend(captures)
    conn.close()
    if not all_captures and errors:
        return row.proof_url, [{"error": "; ".join(errors[:3])}]
    return row.proof_url, all_captures


def update_from_wayback(conn: sqlite3.Connection, root: Path, row: ProofRow, data: bytes, capture: dict[str, str]) -> None:
    link_like = type("ProofLinkLike", (), row.__dict__)
    destination = proof_local_path(root / "artefacts", link_like)
    destination.parent.mkdir(parents=True, exist_ok=True)
    destination.write_bytes(data)
    detected_format, features = extract_features(data)
    conn.execute(
        """
        update proofs
        set local_path = ?,
            sha256 = ?,
            bytes = ?,
            first_line = ?,
            detected_format = ?,
            extracted_json = ?,
            download_error = null,
            downloaded_at = ?,
            archive_url = ?,
            archive_member = ?
        where proof_url = ?
        """,
        (
            str(destination),
            hashlib.sha256(data).hexdigest(),
            len(data),
            features.get("first_line", ""),
            detected_format,
            json.dumps(features, sort_keys=True),
            time.time(),
            replay_url(capture),
            f"wayback:{capture.get('timestamp', '')}",
            row.proof_url,
        ),
    )


def import_captures(
    conn: sqlite3.Connection,
    root: Path,
    rows_by_url: dict[str, ProofRow],
    variant_mode: str,
) -> tuple[int, int]:
    imported = 0
    rejected = 0
    for proof_url, row in rows_by_url.items():
        captures: list[dict[str, str]] = []
        for variant in url_variants(proof_url, variant_mode):
            cached = cached_probe(conn, proof_url, variant, retry_errors=False)
            if cached and "error" not in cached[0]:
                captures.extend(cached)
        captures.sort(key=lambda capture: capture.get("timestamp", ""), reverse=True)
        for capture in captures:
            try:
                data = fetch_bytes(replay_url(capture), timeout=60)
            except Exception:  # noqa: BLE001 - try older captures if available.
                rejected += 1
                continue
            if not plausible_stdout(data, row.result):
                rejected += 1
                continue
            update_from_wayback(conn, root, row, data, capture)
            imported += 1
            break
    conn.commit()
    return imported, rejected


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--out", type=Path, default=Path("target/termcomp-proof-corpus"))
    parser.add_argument("--year", type=int, default=2019)
    parser.add_argument("--category", default="TRS_Standard")
    parser.add_argument("--jobs", type=int, default=4)
    parser.add_argument("--limit", type=int)
    parser.add_argument("--retries", type=int, default=2)
    parser.add_argument("--delay", type=float, default=2.0)
    parser.add_argument("--variant-mode", choices=["exact", "all"], default="exact")
    parser.add_argument("--progress-interval", type=int, default=10)
    parser.add_argument("--no-cache", action="store_true")
    parser.add_argument("--retry-cached-errors", action="store_true")
    parser.add_argument("--import-found", action="store_true")
    args = parser.parse_args()

    db_path = args.out / "proofs.sqlite"
    conn = sqlite3.connect(db_path, timeout=60)
    ensure_tables(conn)
    rows = load_rows(conn, args.year, args.category, args.limit)
    print(json.dumps({"to_probe": len(rows), "year": args.year, "category": args.category}, sort_keys=True), flush=True)
    conn.close()

    completed = 0
    found_urls: set[str] = set()
    errors = 0
    with concurrent.futures.ThreadPoolExecutor(max_workers=max(1, args.jobs)) as executor:
        futures = [
            executor.submit(
                probe_one,
                db_path,
                row,
                args.retries,
                args.delay,
                not args.no_cache,
                args.variant_mode,
                args.retry_cached_errors,
            )
            for row in rows
        ]
        for future in concurrent.futures.as_completed(futures):
            proof_url, captures = future.result()
            completed += 1
            if captures and "error" in captures[0]:
                errors += 1
            elif captures:
                found_urls.add(proof_url)
            if completed % max(1, args.progress_interval) == 0 or completed == len(rows):
                print(
                    json.dumps(
                        {
                            "probed": completed,
                            "found": len(found_urls),
                            "errors": errors,
                            "remaining": len(rows) - completed,
                        },
                        sort_keys=True,
                    ),
                    flush=True,
                )

    imported = 0
    rejected = 0
    if args.import_found and found_urls:
        conn = sqlite3.connect(db_path, timeout=60)
        ensure_tables(conn)
        rows_by_url = {row.proof_url: row for row in rows if row.proof_url in found_urls}
        imported, rejected = import_captures(conn, args.out, rows_by_url, args.variant_mode)
        conn.close()

    print(
        json.dumps(
            {
                "probed": completed,
                "found": len(found_urls),
                "errors": errors,
                "imported": imported,
                "rejected_captures": rejected,
            },
            sort_keys=True,
        )
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
