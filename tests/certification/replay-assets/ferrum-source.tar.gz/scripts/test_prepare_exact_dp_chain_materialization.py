import json
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path


class PrepareExactDpChainMaterializationTest(unittest.TestCase):
    def test_extracts_live_residual_and_following_red_pair_chain(self) -> None:
        with tempfile.TemporaryDirectory() as raw_tmp:
            tmp = Path(raw_tmp)
            runtime = tmp / "runtime.jsonl"
            proof = tmp / "proof.jsonl"
            output_input = tmp / "input.xml"
            output_strategy = tmp / "strategy.fs"
            runtime.write_text(
                json.dumps(
                    {
                        "witness": {
                            "residuals": [
                                {"problem_key": "live", "cpf": "<input><dpInput/></input>"}
                            ]
                        }
                    }
                )
                + "\n",
                encoding="utf-8",
            )
            proof.write_text(
                "\n".join(
                    json.dumps(row)
                    for row in [
                        {
                            "input": {"problem_key": "source"},
                            "processor": "exact-red-pair(hex=00)",
                        },
                        {"strategy_atom": "exact-red-pair(hex=11)"},
                        {"processor": "exact-red-pair(hex=22)"},
                        {"processor": "exact-graph(hex=33)"},
                    ]
                )
                + "\n",
                encoding="utf-8",
            )

            completed = subprocess.run(
                [
                    sys.executable,
                    str(Path(__file__).with_name("prepare_exact_dp_chain_materialization.py")),
                    "--runtime-events",
                    str(runtime),
                    "--live-key",
                    "live",
                    "--proof-events",
                    str(proof),
                    "--after-source-key",
                    "source",
                    "--output-input",
                    str(output_input),
                    "--output-strategy",
                    str(output_strategy),
                ],
                check=True,
                capture_output=True,
                text=True,
            )

            self.assertEqual(output_input.read_text(), "<input><dpInput/></input>")
            self.assertEqual(
                output_strategy.read_text(),
                "pipeline(exact-red-pair(hex=11);\nexact-red-pair(hex=22))\n",
            )
            self.assertEqual(json.loads(completed.stdout)["atoms"], 2)


if __name__ == "__main__":
    unittest.main()
