import hashlib
import unittest
import json
from retain_certified_replay_hints import local_hints, direct_forward_atom
from export_direct_native_hints import same_unbound_redpair_hint


class RetainedHintsTests(unittest.TestCase):
    def test_direct_forward_changes_policy_not_witness(self):
        payload = ['forwardInstantiationProc', '<witness/>', '<child/>']
        atom = 'exact-dp-transform(hex=' + json.dumps(payload).encode().hex() + ')'
        updated = json.loads(bytes.fromhex(direct_forward_atom(atom).split('hex=')[1][:-1]))
        self.assertEqual(updated, ['forwardInstantiationProcDirect', *payload[1:]])
        self.assertEqual(direct_forward_atom('size-change'), 'size-change')

    def test_rebound_order_requires_identical_order_and_removal_data(self):
        def atom(payload):
            return 'exact-red-pair(hex=' + json.dumps(payload).encode().hex() + ')'
        source = ['redPairProc', '<order/>', [0], '<source/>']
        self.assertTrue(same_unbound_redpair_hint(atom(source[:3]), atom(source)))
        self.assertFalse(same_unbound_redpair_hint(atom(['redPairProc', '<other/>', [0]]), atom(source)))

    def test_hydrates_but_never_promotes_observed_actions(self):
        cpf = '<input/>'
        key = hashlib.sha256(cpf.encode()).hexdigest()
        events = [dict(outcome='failed', input=dict(cpf=cpf, problem_key=key)),
                  dict(outcome='solved', strategy_atom='size-change',
                       input=dict(cpf=None, problem_key=key))]
        row = next(r for r in local_hints(events) if 'problem_key' in r)
        self.assertEqual(row['prefer'], [])
        self.assertEqual(row['schema'], 'ferrum.utility-guidance.v2')
        self.assertEqual(row['possible'][0]['certified_count'], 0)
        self.assertEqual(row['possible'][0]['status'], 'transformed_weak')
        self.assertEqual(row['possible'][0]['candidate'], 'size-change')
        self.assertEqual(len(row['replay_order']), 1)

    def test_rejects_composite_and_stale_input(self):
        with self.assertRaises(ValueError):
            local_hints([dict(outcome='solved', strategy_atom='exact-dp-proof(hex=00)')])
        with self.assertRaises(ValueError):
            local_hints([dict(input=dict(cpf='<input/>', problem_key='wrong'))])
