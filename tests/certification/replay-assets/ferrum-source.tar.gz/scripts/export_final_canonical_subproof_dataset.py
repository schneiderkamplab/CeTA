#!/usr/bin/env python3
"""Export the final canonical subproof dataset.

The canonicalizer writes every input row, including unsupported rows preserved
unchanged.  This script writes the training-ready subset: rows whose CPF input
and proof fragment were canonicalized by the current standardizer.
"""

from __future__ import annotations

import argparse
import gzip
import json
from pathlib import Path
from typing import Any


def open_input(path: Path):
    return gzip.open(path, "rt", encoding="utf-8") if path.suffix == ".gz" else path.open("r", encoding="utf-8")


def open_output(path: Path):
    path.parent.mkdir(parents=True, exist_ok=True)
    return gzip.open(path, "wt", encoding="utf-8") if path.suffix == ".gz" else path.open("w", encoding="utf-8")


def keep_row(row: dict[str, Any], include_identity: bool) -> bool:
    status = (row.get("canonicalization") or {}).get("status")
    if status == "canonicalized":
        return True
    return include_identity and status == "canonicalized-identity"


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--input", type=Path, default=Path("target/termcomp-proof-corpus/training/subproofs.cpf.canonical.jsonl.gz"))
    parser.add_argument("--output", type=Path, default=Path("target/termcomp-proof-corpus/training/subproofs.cpf.canonical.final.jsonl.gz"))
    parser.add_argument("--summary", type=Path, default=Path("target/termcomp-proof-corpus/training/subproofs.cpf.canonical.final.summary.json"))
    parser.add_argument("--include-identity", action=argparse.BooleanOptionalAction, default=True)
    parser.add_argument("--progress-interval", type=int, default=25000)
    args = parser.parse_args()

    seen = 0
    written = 0
    status_counts: dict[str, int] = {}
    input_counts: dict[str, int] = {}
    output_counts: dict[str, int] = {}
    with open_input(args.input) as source, open_output(args.output) as sink:
        for line in source:
            row = json.loads(line)
            seen += 1
            status = (row.get("canonicalization") or {}).get("status", "")
            status_counts[status] = status_counts.get(status, 0) + 1
            if keep_row(row, args.include_identity):
                sink.write(json.dumps(row, sort_keys=True, separators=(",", ":")) + "\n")
                written += 1
                input_status = (row.get("cpf_normalization") or {}).get("input_status", "")
                output_status = (row.get("cpf_normalization") or {}).get("output_status", "")
                input_counts[input_status] = input_counts.get(input_status, 0) + 1
                output_counts[output_status] = output_counts.get(output_status, 0) + 1
            if args.progress_interval > 0 and seen % args.progress_interval == 0:
                print(json.dumps({"event": "progress", "seen": seen, "written": written}, sort_keys=True), flush=True)

    summary = {
        "input": str(args.input),
        "output": str(args.output),
        "rows_seen": seen,
        "rows_written": written,
        "include_identity": args.include_identity,
        "canonicalization_counts_seen": dict(sorted(status_counts.items())),
        "input_counts_written": dict(sorted(input_counts.items())),
        "output_counts_written": dict(sorted(output_counts.items())),
    }
    args.summary.write_text(json.dumps(summary, indent=2, sort_keys=True))
    print(json.dumps(summary, sort_keys=True), flush=True)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
