#!/usr/bin/env python3
"""Learn conservative local processor budgets from certified replay events."""

from __future__ import annotations

import argparse
import json
import math
import re
from collections import defaultdict
from pathlib import Path

BUCKETS = ((0, 32), (33, 64), (65, 128), (129, 256), (257, None))


def processor_family(candidate: str) -> str:
    match = re.match(r"(?:exact-)?([a-z0-9-]+)", candidate)
    return match.group(1) if match else candidate


def bucket_for(size: int) -> tuple[int, int | None]:
    return next(
        (lower, upper)
        for lower, upper in BUCKETS
        if size >= lower and (upper is None or size <= upper)
    )


def learn(run_dir: Path, headroom: float) -> list[dict[str, object]]:
    samples: dict[tuple[str, int, int | None], list[int]] = defaultdict(list)
    for events_path in run_dir.rglob("processor-events.jsonl"):
        result_path = events_path.with_name("result.json")
        if not result_path.exists():
            continue
        result = json.loads(result_path.read_text(encoding="utf-8"))
        if not result.get("certified"):
            continue
        for line in events_path.read_text(encoding="utf-8").splitlines():
            event = json.loads(line)
            if event.get("outcome") not in {"solved", "transformed"}:
                continue
            metrics = event.get("metrics") or {}
            size = int(metrics.get("pairs") or 0) + int(metrics.get("rules") or 0)
            lower, upper = bucket_for(size)
            family = processor_family(str(event.get("processor") or "unknown"))
            samples[(family, lower, upper)].append(int(event.get("elapsed_ms") or 0))

    learned = []
    for (family, lower, upper), elapsed in sorted(samples.items()):
        observed_max = max(elapsed)
        learned.append(
            {
                "processor_family": family,
                "state_size_min": lower,
                "state_size_max": upper,
                "samples": len(elapsed),
                "observed_max_ms": observed_max,
                "recommended_timeout_ms": max(1, math.ceil(observed_max * headroom)),
                "headroom": headroom,
            }
        )
    return learned


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("run_dir", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("--headroom", type=float, default=1.2)
    args = parser.parse_args()
    if args.headroom < 1.2:
        parser.error("--headroom must be at least 1.2")
    learned = learn(args.run_dir, args.headroom)
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(learned, indent=2) + "\n", encoding="utf-8")
    print(f"wrote {len(learned)} learned budgets to {args.output}")


if __name__ == "__main__":
    main()
