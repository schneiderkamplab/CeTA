import hashlib
import unittest

from build_checked_runtime_tree_overlay import closed_tree


class ClosedTreeTests(unittest.TestCase):
    def test_closed_tree_and_rejected_alternatives(self):
        cpf = '<dpInput><trs/><dps/></dpInput>'
        key = hashlib.sha256(cpf.encode()).hexdigest()
        root = dict(input=dict(problem_key='root'), outcome='transformed',
                    witness=dict(kind='problem_states', residuals=[dict(cpf=cpf, problem_key=key)]))
        terminal = dict(input=dict(problem_key=key), outcome='solved',
                        witness=dict(kind='problem_states', residuals=[]))
        self.assertEqual(closed_tree([root, terminal], 'root'), 2)
        with self.assertRaisesRegex(ValueError, 'open'):
            closed_tree([root], 'root')
        with self.assertRaisesRegex(ValueError, 'ambiguous'):
            closed_tree([root, terminal, terminal], 'root')
        other = dict(input=dict(problem_key='other'), outcome='solved', witness=terminal['witness'])
        with self.assertRaisesRegex(ValueError, 'unused'):
            closed_tree([root, terminal, other], 'root')
        root['witness']['residuals'][0]['cpf'] = '<different/>'
        with self.assertRaisesRegex(ValueError, 'digest'):
            closed_tree([root, terminal], 'root')


if __name__ == '__main__':
    unittest.main()
