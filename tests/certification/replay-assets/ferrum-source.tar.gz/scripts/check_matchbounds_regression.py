#!/usr/bin/env python3
"""Run CeTA over the frozen Matchbounds/RFC certificate corpus."""

from __future__ import annotations

import argparse
from concurrent.futures import ThreadPoolExecutor, as_completed
import json
from pathlib import Path
import subprocess


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("corpus", type=Path)
    parser.add_argument("manifest", type=Path)
    parser.add_argument("checker", type=Path)
    parser.add_argument("--jobs", type=int, default=8)
    parser.add_argument("--timeout", type=float, default=60.0)
    return parser.parse_args()


def main() -> int:
    args = parse_args()
    rows = [json.loads(line) for line in args.manifest.read_text().splitlines()]

    def check(row: dict[str, object]) -> tuple[str, str | None]:
        proof = args.corpus / str(row["artifact"]) / "proof.normalized.cpf3.xml"
        expected_hash = str(row["proof_sha256"])
        import hashlib

        if hashlib.sha256(proof.read_bytes()).hexdigest() != expected_hash:
            return str(row["problem"]), "proof hash mismatch"
        try:
            result = subprocess.run(
                [str(args.checker), str(proof)],
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                text=True,
                timeout=args.timeout,
                check=False,
            )
        except subprocess.TimeoutExpired:
            return str(row["problem"]), "checker timeout"
        if result.returncode != 0 or "CERTIFIED" not in result.stdout.upper():
            diagnostic = (result.stderr or result.stdout).strip()[-800:]
            return str(row["problem"]), diagnostic or f"exit {result.returncode}"
        return str(row["problem"]), None

    failures: list[tuple[str, str]] = []
    with ThreadPoolExecutor(max_workers=args.jobs) as executor:
        futures = [executor.submit(check, row) for row in rows]
        for future in as_completed(futures):
            problem, error = future.result()
            if error is not None:
                failures.append((problem, error))

    if failures:
        for problem, error in sorted(failures):
            print(f"FAILED {problem}: {error}")
        print(f"{len(failures)} of {len(rows)} certificates failed")
        return 1
    print(f"all {len(rows)} certificates accepted")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
