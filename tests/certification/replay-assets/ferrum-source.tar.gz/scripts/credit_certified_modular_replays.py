#!/usr/bin/env python3
"""Recheck successful isolated roots and extract their executed modular chains."""
import argparse
import hashlib
from concurrent.futures import ThreadPoolExecutor, as_completed
import json
from pathlib import Path
import subprocess
import sys


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--replays', type=Path, required=True)
    p.add_argument('--output', type=Path, required=True)
    p.add_argument('--ferrum', required=True)
    p.add_argument('--ceta', required=True)
    p.add_argument('--jobs', type=int, default=4)
    args = p.parse_args()
    args.output.mkdir(parents=True, exist_ok=False)
    rows = [json.loads(line) for line in (args.replays/'results.jsonl').read_text().splitlines()]
    rows = [row for row in rows if row.get('certified') and row.get('returncode') == 0]

    def run(row):
        output = args.output/Path(row['path']).with_suffix('')
        output.mkdir(parents=True)
        details = json.loads((Path(row['output'])/'details.json').read_text())
        assert len(details) == 1 and details[0]['certified']
        root = details[0]['artifact_dir']
        with (output/'extract.log').open('x') as log:
            try:
                proc = subprocess.run([sys.executable, 'scripts/extract_local_cpf_oracle_events.py',
                    '--root', root, '--runtime-root', root, '--ferrum-canonicalizer', args.ferrum,
                    '--ceta', args.ceta, '--output', str(output/'events.jsonl'),
                    '--certified-manifest-output', str(output/'manifest.jsonl'), '--proof-chain-only',
                    '--exclude-complete-proof-atoms', '--runtime-explicit-states-only'],
                    stdout=log, stderr=subprocess.STDOUT, timeout=900)
            except subprocess.TimeoutExpired:
                return dict(path=row['path'], output=str(output), returncode=124)
        guidance = Path(row['output'])/'oracle.jsonl'
        events = Path(root)/'processor-events.jsonl'
        return dict(path=row['path'], output=str(output), returncode=proc.returncode,
                    tested_guidance=str(guidance.resolve()),
                    tested_guidance_sha256=hashlib.sha256(guidance.read_bytes()).hexdigest(),
                    tested_events=str(events.resolve()),
                    tested_events_sha256=hashlib.sha256(events.read_bytes()).hexdigest())

    with ThreadPoolExecutor(max_workers=args.jobs) as pool, (args.output/'results.jsonl').open('x') as log:
        for future in as_completed([pool.submit(run, row) for row in rows]):
            result = future.result()
            print(json.dumps(result), file=log, flush=True)
            print(json.dumps(result), flush=True)


if __name__ == '__main__':
    main()
