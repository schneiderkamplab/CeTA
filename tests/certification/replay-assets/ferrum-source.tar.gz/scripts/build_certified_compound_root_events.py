#!/usr/bin/env python3
"""Create replayable compound-root events from independently certified runs."""

from __future__ import annotations

import argparse
import json
from pathlib import Path


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--events", type=Path, action="append", required=True)
    parser.add_argument("--candidate", required=True)
    parser.add_argument(
        "--select-outcome",
        action="append",
        default=[],
        help="source event outcome to select; defaults to solved/transformed",
    )
    parser.add_argument("--select-processor")
    parser.add_argument(
        "--select-level",
        default="top-level",
        help="source event level to select; defaults to top-level",
    )
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    selected_outcomes = set(args.select_outcome or ["solved", "transformed"])

    rows: list[dict] = []
    for event_path in args.events:
        source_events = [
            json.loads(line)
            for line in event_path.read_text(encoding="utf-8").splitlines()
            if line.strip()
        ]
        root = next(
            (
                event
                for event in source_events
                if event.get("outcome") in selected_outcomes
                and event.get("level") == args.select_level
                and (
                    args.select_processor is None
                    or event.get("processor") == args.select_processor
                )
                and isinstance((event.get("input") or {}).get("cpf"), str)
                and (event.get("input") or {}).get("cpf", "").strip()
            ),
            None,
        )
        if root is None:
            raise SystemExit(f"no hydratable positive root event in {event_path}")
        rows.append(
            {
                "schema": "ferrum.processor-event.v1",
                "run_id": "certified-compound-root-recovery",
                "problem_id": root.get("problem_id"),
                "category": root.get("category"),
                "level": root.get("level"),
                "problem_kind": root.get("problem_kind"),
                "processor": args.candidate,
                "strategy_atom": args.candidate,
                "outcome": "solved",
                "progress": "closed",
                "elapsed_ms": None,
                "input": root["input"],
                "certification": {
                    "status": "certified-full-source",
                    "checker": "CeTA-CSR",
                },
                "credit": {"status": "proof-path-certified"},
                "metrics": {"source_event_path": str(event_path)},
            }
        )

    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(
        "".join(json.dumps(row, separators=(",", ":"), sort_keys=True) + "\n" for row in rows),
        encoding="utf-8",
    )
    print(json.dumps({"events": len(rows), "output": str(args.output)}, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
