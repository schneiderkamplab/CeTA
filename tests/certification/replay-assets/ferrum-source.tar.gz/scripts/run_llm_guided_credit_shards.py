#!/usr/bin/env python3
"""Run CPU LLM-guided Ferrum event collection in small TPDB shards.

The TPDB runner is intentionally process-isolated here: each shard starts a new
Ferrum process and therefore releases large proof-search allocations when the
shard exits.  Event logs keep inline CPF so they can be postprocessed into
credited/counterfactual HRM status-map datasets.
"""

from __future__ import annotations

import argparse
import json
import os
import shutil
import signal
import subprocess
import sys
import time
from pathlib import Path


DEFAULT_CATEGORIES = [
    "TRS_Standard",
    "TRS_Innermost",
    "SRS_Standard",
    "TRS_Contextsensitive",
    "TRS_Outermost",
]


def memory_used_bytes() -> int:
    values: dict[str, int] = {}
    with Path("/proc/meminfo").open("r", encoding="utf-8") as handle:
        for line in handle:
            key, value = line.split(":", 1)
            values[key] = int(value.strip().split()[0]) * 1024
    return values["MemTotal"] - values.get("MemAvailable", values.get("MemFree", 0))


def discover_ari_files(root: Path) -> list[Path]:
    return sorted(path for path in root.rglob("*.ari") if path.is_file())


def materialize_shards(tpdb_root: Path, category: str, shard_category_root: Path, shard_size: int) -> list[Path]:
    source_root = tpdb_root / category
    files = discover_ari_files(source_root)
    shards: list[Path] = []
    for shard_index, start in enumerate(range(0, len(files), shard_size)):
        category_root = shard_category_root / f"shard-{shard_index:04d}" / category
        category_root.mkdir(parents=True, exist_ok=True)
        for source in files[start : start + shard_size]:
            relative = source.relative_to(source_root)
            target = category_root / relative
            target.parent.mkdir(parents=True, exist_ok=True)
            if target.exists():
                continue
            try:
                os.link(source, target)
            except OSError:
                shutil.copy2(source, target)
        shards.append(category_root)
    return shards


def run_shard(args: argparse.Namespace, category: str, shard_root: Path, shard_dir: Path) -> dict[str, object]:
    events = shard_dir / f"{category}.processor-events.jsonl"
    stdout_path = shard_dir / "stdout.txt"
    stderr_path = shard_dir / "stderr.txt"
    status_path = shard_dir / "status.json"
    env = os.environ.copy()
    env.update(
        {
            "CUDA_VISIBLE_DEVICES": "",
            "OMP_NUM_THREADS": str(args.cpu_threads),
            "OPENBLAS_NUM_THREADS": str(args.cpu_threads),
            "MKL_NUM_THREADS": str(args.cpu_threads),
            "NUMEXPR_NUM_THREADS": str(args.cpu_threads),
            "RAYON_NUM_THREADS": str(args.cpu_threads),
            "CARGO_BUILD_JOBS": str(args.cpu_threads),
        }
    )
    if args.conda_prefix:
        env["OPENSSL_DIR"] = args.conda_prefix
        pkg = str(Path(args.conda_prefix) / "lib" / "pkgconfig")
        env["PKG_CONFIG_PATH"] = f"{pkg}:{env.get('PKG_CONFIG_PATH', '')}"
    command = [
        "cargo",
        "+1.95.0",
        "run",
        "--",
        "tpdb",
        "prove",
        str(shard_root),
        "--jobs",
        str(args.jobs),
        "--progress-every",
        str(args.progress_every),
        "--timeout-multiplier",
        str(args.timeout_multiplier),
        "--llm-model-dir",
        str(args.llm_model_dir),
        "--llm-backend",
        args.llm_backend,
        "--processor-events",
        str(events),
    ]
    started = time.time()
    shard_dir.mkdir(parents=True, exist_ok=True)
    with stdout_path.open("w", encoding="utf-8") as stdout, stderr_path.open("w", encoding="utf-8") as stderr:
        process = subprocess.Popen(
            command,
            cwd=args.repo,
            env=env,
            stdout=stdout,
            stderr=stderr,
            start_new_session=True,
        )
        killed_for_memory = False
        while process.poll() is None:
            if args.shard_timeout_seconds is not None and time.time() - started > args.shard_timeout_seconds:
                killed_for_memory = False
                os.killpg(process.pid, signal.SIGTERM)
                time.sleep(5)
                if process.poll() is None:
                    os.killpg(process.pid, signal.SIGKILL)
                break
            used = memory_used_bytes()
            if used > args.memory_guard_bytes:
                killed_for_memory = True
                os.killpg(process.pid, signal.SIGTERM)
                time.sleep(5)
                if process.poll() is None:
                    os.killpg(process.pid, signal.SIGKILL)
                break
            time.sleep(args.monitor_interval)
        returncode = process.wait()
    elapsed = time.time() - started
    status = {
        "category": category,
        "shard_root": str(shard_root),
        "events": str(events),
        "returncode": returncode,
        "killed_for_memory": killed_for_memory,
        "killed_for_timeout": (
            args.shard_timeout_seconds is not None
            and elapsed > args.shard_timeout_seconds
            and returncode != 0
        ),
        "elapsed_seconds": elapsed,
        "event_rows": sum(1 for _ in events.open("r", encoding="utf-8")) if events.exists() else 0,
        "event_bytes": events.stat().st_size if events.exists() else 0,
    }
    status_path.write_text(json.dumps(status, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    return status


def concatenate_logs(run_root: Path, statuses: list[dict[str, object]]) -> Path:
    combined = run_root / "all.llm-guided.processor-events.jsonl"
    with combined.open("wb") as output:
        for status in statuses:
            path = Path(str(status["events"]))
            if path.exists():
                with path.open("rb") as source:
                    shutil.copyfileobj(source, output)
    return combined


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--repo", type=Path, default=Path.cwd())
    parser.add_argument("--tpdb-root", type=Path, default=Path("../TPDB-ARI"))
    parser.add_argument("--run-root", type=Path, required=True)
    parser.add_argument("--categories", nargs="+", default=DEFAULT_CATEGORIES)
    parser.add_argument("--shard-size", type=int, default=32)
    parser.add_argument("--jobs", type=int, default=8)
    parser.add_argument("--cpu-threads", type=int, default=128)
    parser.add_argument("--progress-every", type=int, default=16)
    parser.add_argument("--timeout-multiplier", default="0.2")
    parser.add_argument("--llm-model-dir", type=Path, required=True)
    parser.add_argument("--llm-backend", default="transformers-cpu")
    parser.add_argument("--memory-guard-bytes", type=int, default=2 * 1024**4)
    parser.add_argument("--monitor-interval", type=float, default=5.0)
    parser.add_argument("--shard-timeout-seconds", type=float)
    parser.add_argument("--conda-prefix", default=os.environ.get("CONDA_PREFIX"))
    parser.add_argument("--resume", action="store_true")
    parser.add_argument("--max-shards-per-category", type=int)
    args = parser.parse_args()

    args.repo = args.repo.resolve()
    args.tpdb_root = (args.repo / args.tpdb_root).resolve() if not args.tpdb_root.is_absolute() else args.tpdb_root
    args.run_root.mkdir(parents=True, exist_ok=True)
    shard_root = args.run_root / "shards"
    statuses: list[dict[str, object]] = []
    for category in args.categories:
        category_shards = materialize_shards(args.tpdb_root, category, shard_root / category, args.shard_size)
        if args.max_shards_per_category is not None:
            category_shards = category_shards[: args.max_shards_per_category]
        for index, category_root in enumerate(category_shards):
            shard_dir = args.run_root / "runs" / category / f"shard-{index:04d}"
            status_path = shard_dir / "status.json"
            if args.resume and status_path.exists():
                status = json.loads(status_path.read_text(encoding="utf-8"))
            else:
                print(
                    f"shard-start category={category} shard={index + 1}/{len(category_shards)} root={category_root}",
                    file=sys.stderr,
                    flush=True,
                )
                status = run_shard(args, category, category_root, shard_dir)
                print(
                    f"shard-finish category={category} shard={index + 1}/{len(category_shards)} "
                    f"returncode={status['returncode']} rows={status['event_rows']} "
                    f"killed_for_memory={status['killed_for_memory']} "
                    f"killed_for_timeout={status.get('killed_for_timeout', False)} "
                    f"elapsed={status['elapsed_seconds']:.1f}s",
                    file=sys.stderr,
                    flush=True,
                )
            statuses.append(status)
            if status.get("killed_for_memory"):
                print(
                    f"memory guard tripped for {category} shard {index}; continuing with later shards",
                    file=sys.stderr,
                    flush=True,
                )
            if status.get("killed_for_timeout"):
                print(
                    f"timeout guard tripped for {category} shard {index}; continuing with later shards",
                    file=sys.stderr,
                    flush=True,
                )
    combined = concatenate_logs(args.run_root, statuses)
    summary = {
        "run_root": str(args.run_root),
        "combined": str(combined),
        "categories": args.categories,
        "shard_size": args.shard_size,
        "statuses": statuses,
        "failed_shards": [
            status
            for status in statuses
            if status.get("returncode") not in (0, None) or status.get("killed_for_memory")
            or status.get("killed_for_timeout")
        ],
    }
    (args.run_root / "collection-summary.json").write_text(
        json.dumps(summary, indent=2, sort_keys=True) + "\n",
        encoding="utf-8",
    )
    print(json.dumps(summary, indent=2, sort_keys=True), flush=True)
    return 0 if not summary["failed_shards"] else 2


if __name__ == "__main__":
    raise SystemExit(main())
