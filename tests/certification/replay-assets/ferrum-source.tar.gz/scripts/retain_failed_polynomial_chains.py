#!/usr/bin/env python3
"""Retain complete exact-polynomial chains only for failed target probes."""

from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path

from build_credited_status_map_dataset import canonicalize_cpf_input, compact_xml_for_key


WITNESS_SCHEMA = "ferrum.utility-guidance.witness.v1"


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("original", type=Path)
    parser.add_argument("probe", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("--baseline-run-dir", type=Path, required=True)
    parser.add_argument("--probe-details", type=Path, action="append", required=True)
    parser.add_argument("--failed-roots-output", type=Path)
    args = parser.parse_args()

    original_rows = [json.loads(line) for line in args.original.open(encoding="utf-8")]
    probe_rows = [json.loads(line) for line in args.probe.open(encoding="utf-8")]
    definitions = {
        row["candidate"]: row["witness_id"]
        for row in original_rows
        if row.get("schema") == WITNESS_SCHEMA
        and row.get("candidate", "").startswith("exact-poly(")
    }
    definition_ids = set(definitions.values())
    failed_roots = set()
    for details_path in args.probe_details:
        for result in json.loads(details_path.read_text(encoding="utf-8")):
            if result.get("status") != "yes" or not result.get("certified"):
                failed_roots.add(result["path"])

    baseline_artifacts = {}
    for result_path in args.baseline_run_dir.rglob("result.json"):
        result = json.loads(result_path.read_text(encoding="utf-8"))
        baseline_artifacts[result.get("path")] = result_path.parent

    retained_ids = set()
    restore_keys = set()
    selected_events = 0
    for root in failed_roots:
        artifact_dir = baseline_artifacts.get(root)
        if artifact_dir is None:
            raise ValueError(f"failed root has no baseline artifact: {root}")
        events_path = artifact_dir / "processor-events.jsonl"
        for line in events_path.open(encoding="utf-8"):
            event = json.loads(line)
            event_input = event.get("input") or {}
            raw_key = event_input.get("problem_key")
            cpf = event_input.get("cpf")
            if raw_key:
                restore_keys.add(raw_key)
            if isinstance(cpf, str):
                restore_keys.add(
                    hashlib.sha256(compact_xml_for_key(cpf).encode("utf-8")).hexdigest()
                )
                canonical, error = canonicalize_cpf_input(cpf)
                if error is None:
                    restore_keys.add(hashlib.sha256(canonical.encode("utf-8")).hexdigest())
            identifier = definitions.get(event.get("processor", ""))
            if identifier is not None:
                retained_ids.add(identifier)
                selected_events += 1

    probe_by_key = {
        row["problem_key"]: row
        for row in probe_rows
        if row.get("schema") != WITNESS_SCHEMA
    }
    original_by_key = {
        row["problem_key"]: row
        for row in original_rows
        if row.get("schema") != WITNESS_SCHEMA
    }
    pending = list(restore_keys)
    while pending:
        key = pending.pop()
        row = original_by_key.get(key)
        canonical_key = row.get("canonical_problem_key") if row is not None else None
        if isinstance(canonical_key, str) and canonical_key not in restore_keys:
            restore_keys.add(canonical_key)
            pending.append(canonical_key)
    restored_rows = restore_keys & original_by_key.keys()
    for key in restored_rows:
        row = original_by_key[key]
        for group in ("avoid", "possible", "prefer", "timeout"):
            for evidence in row.get(group) or []:
                reference = evidence.get("candidate_ref")
                if reference in definition_ids:
                    retained_ids.add(reference)
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with args.output.open("w", encoding="utf-8") as output:
        for row in original_rows:
            if row.get("schema") == WITNESS_SCHEMA:
                candidate = row.get("candidate", "")
                if candidate.startswith("exact-poly(") and row.get("witness_id") not in retained_ids:
                    continue
                selected = row
            else:
                key = row["problem_key"]
                selected = row if key in restored_rows else probe_by_key.get(key, row)
            print(json.dumps(selected, separators=(",", ":"), sort_keys=True), file=output)

    if args.failed_roots_output is not None:
        args.failed_roots_output.parent.mkdir(parents=True, exist_ok=True)
        args.failed_roots_output.write_text(
            "\n".join(sorted(failed_roots)) + ("\n" if failed_roots else ""),
            encoding="utf-8",
        )
    print(
        json.dumps(
            {
                "failed_roots": len(failed_roots),
                "retained_definitions": len(retained_ids),
                "retained_selected_events": selected_events,
                "restored_state_rows": len(restored_rows),
            },
            sort_keys=True,
        )
    )


if __name__ == "__main__":
    main()
