#!/usr/bin/env python3
"""Replace exact linear-polynomial models with certified deletion targets."""

from __future__ import annotations

import argparse
import hashlib
import json
from collections import Counter
from pathlib import Path
import xml.etree.ElementTree as ET

from build_credited_status_map_dataset import canonicalize_cpf_input, compact_xml_for_key


WITNESS_SCHEMA = "ferrum.utility-guidance.witness.v1"
GROUPS = ("avoid", "possible", "prefer", "timeout")


def cpf_rules(cpf: str, section: str) -> list[bytes]:
    root = ET.fromstring(cpf)
    rules = root.findall(f"./{section}/rules/rule")
    canonical = []
    for rule in rules:
        rule.tail = None
        canonical.append(ET.tostring(rule, encoding="utf-8"))
    return canonical


def deleted_indices(input_cpf: str, residual_cpf: str, section: str) -> list[int]:
    source = cpf_rules(input_cpf, section)
    residual = Counter(cpf_rules(residual_cpf, section))
    deleted = []
    for index, rule in enumerate(source):
        if residual[rule] > 0:
            residual[rule] -= 1
        else:
            deleted.append(index)
    if any(residual.values()) or not deleted:
        raise ValueError(f"residual {section} rules are not a strict input submultiset")
    return deleted


def decode_bounds(candidate: str) -> tuple[int, int, int, int]:
    prefix = "exact-poly(hex="
    if not candidate.startswith(prefix) or not candidate.endswith(")"):
        raise ValueError("not an exact polynomial candidate")
    witness = json.loads(bytes.fromhex(candidate[len(prefix) : -1]))
    if not witness:
        raise ValueError("empty exact polynomial witness")
    constants = [constant for _, constant, _ in witness]
    coefficients = [value for _, _, values in witness for value in values]
    return (
        max(constants, default=0),
        max(coefficients, default=1),
        len(witness),
        max((len(values) for _, _, values in witness), default=0),
    )


def bounded_atom(bounds: tuple[int, int, int, int]) -> str:
    constant, coefficient, symbols, arity = bounds
    return (
        f"poly(max-constant={constant},max-coefficient={coefficient},"
        f"max-symbols={symbols},max-arity={arity})"
    )


def target_atom(bounds: tuple[int, int, int, int], indices: list[int]) -> str:
    atom = bounded_atom(bounds)
    return atom.replace(
        "poly(",
        "poly-target(",
        1,
    )[:-1] + ",strict=" + "+".join(map(str, indices)) + ")"


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("input", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("--run-dir", type=Path, required=True)
    parser.add_argument("--affected-roots-output", type=Path)
    args = parser.parse_args()

    rows = [json.loads(line) for line in args.input.open(encoding="utf-8")]
    definitions = {
        row["witness_id"]: row["candidate"]
        for row in rows
        if row.get("schema") == WITNESS_SCHEMA
        and row.get("candidate", "").startswith("exact-poly(")
    }
    bounds = {identifier: decode_bounds(candidate) for identifier, candidate in definitions.items()}
    candidate_ids = {candidate: identifier for identifier, candidate in definitions.items()}

    targets: dict[tuple[str, str], str] = {}
    affected_roots = set()
    selected_events = 0
    for result_path in args.run_dir.rglob("result.json"):
        result = json.loads(result_path.read_text(encoding="utf-8"))
        if not result.get("certified"):
            continue
        events_path = result_path.parent / "processor-events.jsonl"
        if not events_path.exists():
            continue
        for line in events_path.open(encoding="utf-8"):
            event = json.loads(line)
            identifier = candidate_ids.get(event.get("processor", ""))
            if identifier is None:
                continue
            residuals = (event.get("witness") or {}).get("residuals") or []
            if len(residuals) != 1:
                raise ValueError("polynomial event does not have exactly one residual")
            event_input = event.get("input") or {}
            problem_key = event_input.get("problem_key")
            if not problem_key:
                raise ValueError("polynomial event has no input problem key")
            canonical_cpf, error = canonicalize_cpf_input(event_input["cpf"])
            if error is not None:
                raise ValueError(f"cannot canonicalize selected state: {error}")
            canonical_key = hashlib.sha256(canonical_cpf.encode("utf-8")).hexdigest()
            structural_key = hashlib.sha256(
                compact_xml_for_key(event_input["cpf"]).encode("utf-8")
            ).hexdigest()
            level = event.get("level")
            if level == "dependency-pair":
                section = "dps"
            elif level == "top-level":
                section = "trs"
            else:
                raise ValueError(f"unsupported polynomial event level: {level}")
            atom = target_atom(
                bounds[identifier],
                deleted_indices(event_input["cpf"], residuals[0]["cpf"], section),
            )
            for state_key in (problem_key, structural_key, canonical_key):
                key = (state_key, identifier)
                if key in targets and targets[key] != atom:
                    raise ValueError("one canonical state/witness pair has conflicting residuals")
                targets[key] = atom
            affected_roots.add(result["path"])
            selected_events += 1

    replaced_targeted = 0
    replaced_generic = 0
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with args.output.open("w", encoding="utf-8") as output:
        for row in rows:
            if row.get("schema") == WITNESS_SCHEMA and row.get("witness_id") in definitions:
                continue
            if row.get("schema") != WITNESS_SCHEMA:
                problem_key = row.get("problem_key", "")
                for group in GROUPS:
                    retained = []
                    seen = set()
                    for evidence in row.get(group) or []:
                        reference = evidence.get("candidate_ref")
                        if reference in definitions:
                            candidate = targets.get(
                                (problem_key, reference), bounded_atom(bounds[reference])
                            )
                            evidence = {
                                **{
                                    key: value
                                    for key, value in evidence.items()
                                    if key != "candidate_ref"
                                },
                                "candidate": candidate,
                            }
                            if candidate.startswith("poly-target("):
                                replaced_targeted += 1
                            else:
                                replaced_generic += 1
                        identity = (
                            evidence.get("candidate"),
                            evidence.get("candidate_ref"),
                            evidence.get("status"),
                        )
                        if identity not in seen:
                            seen.add(identity)
                            retained.append(evidence)
                    if group in row or retained:
                        row[group] = retained
            print(json.dumps(row, separators=(",", ":"), sort_keys=True), file=output)

    if args.affected_roots_output is not None:
        args.affected_roots_output.parent.mkdir(parents=True, exist_ok=True)
        args.affected_roots_output.write_text(
            "\n".join(sorted(affected_roots)) + ("\n" if affected_roots else ""),
            encoding="utf-8",
        )
    print(
        json.dumps(
            {
                "definitions_removed": len(definitions),
                "selected_events": selected_events,
                "targeted_state_replacements": replaced_targeted,
                "generic_replacements": replaced_generic,
                "target_atoms": len(set(targets.values())),
                "affected_roots": len(affected_roots),
            },
            sort_keys=True,
        )
    )


if __name__ == "__main__":
    main()
