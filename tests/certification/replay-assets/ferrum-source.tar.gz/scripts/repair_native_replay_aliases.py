"""Preserve canonical native search alternatives behind direct replay hints.

Only digest-checked typed event inputs are canonicalized. No witness,
certification credit, or new processor candidate is invented.
"""
import argparse
import copy
from concurrent.futures import ThreadPoolExecutor
import hashlib
import json
from pathlib import Path
import subprocess

from add_runtime_canonical_aliases import canonicalize, inline_inputs
from merge_monotone_oracle_records import load


def linked_row(records, key, canonical):
    if canonical == key or canonical not in records:
        return None
    for row in (records[key], records[canonical]):
        for bucket in ('prefer', 'possible', 'avoid', 'timeout'):
            for candidate in row.get(bucket, []):
                if candidate.get('candidate_ref') or any(
                    marker in candidate.get('candidate', '') for marker in ('exact-', 'hex=', 'pipeline(')
                ):
                    raise ValueError('alias repair accepts native parameter guidance only')
    seen = {key}
    target = canonical
    while target in records:
        if target in seen:
            raise ValueError('canonical alias cycle')
        seen.add(target)
        target = records[target].get('canonical_problem_key')
        if target is None:
            break
    result = copy.deepcopy(records[key])
    result['canonical_problem_key'] = canonical
    return result


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--oracle', type=Path, required=True)
    p.add_argument('--details', type=Path, action='append', required=True)
    p.add_argument('--ferrum', type=Path, required=True)
    p.add_argument('--jobs', type=int, default=16)
    p.add_argument('--output', type=Path, required=True)
    args = p.parse_args()
    _, records = load(args.oracle)
    cpfs = {}
    for details in args.details:
        for root in json.loads(details.read_text()):
            events = Path(root['artifact_dir']) / 'processor-events.jsonl'
            if not events.exists():
                continue
            with events.open() as source:
                cpfs.update(inline_inputs(map(json.loads, source)))
    selected = [key for key in cpfs if key in records and records[key].get('replay_order')
                and not records[key].get('canonical_problem_key')]
    def repair(key):
        try:
            canonical = canonicalize(args.ferrum.resolve(), cpfs[key], 30)
            return linked_row(records, key, hashlib.sha256(canonical.encode()).hexdigest()), None
        except (RuntimeError, subprocess.TimeoutExpired) as error:
            return None, dict(problem_key=key, error=str(error)[:200])
    failures, count = [], 0
    with args.output.open('x') as output, ThreadPoolExecutor(max_workers=args.jobs) as pool:
        for row, error in pool.map(repair, selected):
            if error:
                failures.append(error)
            if row:
                print(json.dumps(row), file=output)
                count += 1
    report = dict(inputs=len(cpfs), checked=len(selected), linked=count, failures=failures)
    with args.output.with_suffix('.report.json').open('x') as output:
        json.dump(report, output, indent=2)
    print(json.dumps(report))


if __name__ == '__main__':
    main()
