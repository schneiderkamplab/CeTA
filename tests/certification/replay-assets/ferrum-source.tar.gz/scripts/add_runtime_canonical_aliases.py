#!/usr/bin/env python3
"""Add exact Ferrum-runtime canonical aliases for supported typed states.

The aliases are semantic state aliases, not benchmark-path aliases: the same
Ferrum canonicalizer is run on the independently serialized CPF state that is
used by the runtime lookup.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import subprocess
import tempfile
from pathlib import Path


def canonicalize(ferrum: Path, cpf: str, timeout: float) -> str:
    with tempfile.NamedTemporaryFile(
        mode="w", suffix=".xml", encoding="utf-8"
    ) as source:
        source.write(cpf)
        source.flush()
        completed = subprocess.run(
            [str(ferrum), "canonicalize-cpf", source.name],
            text=True,
            capture_output=True,
            timeout=timeout,
            check=False,
        )
    if completed.returncode:
        raise RuntimeError(
            f"Ferrum canonicalization failed: {completed.stderr.strip()}"
        )
    return completed.stdout.strip()


def is_runtime_canonicalizable_event(row: dict) -> bool:
    input_data = row.get("input")
    if not isinstance(input_data, dict):
        return False
    cpf = input_data.get("cpf")
    return isinstance(cpf, str) and (
        "<trsInput" in cpf or "<dpInput" in cpf
    )


def inline_inputs(rows):
    """Recover interned CPF inputs without changing their typed context."""
    inputs = {}
    for row in rows:
        states = [row.get('input') or {}] + ((row.get('witness') or {}).get('residuals') or [])
        for state in states:
            cpf, key = state.get('cpf'), state.get('problem_key')
            if not cpf or not key:
                continue
            if hashlib.sha256(cpf.strip().encode()).hexdigest() != key:
                raise ValueError('state digest mismatch')
            inputs[key] = cpf
    return inputs


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--input", type=Path, action="append", required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--ferrum", type=Path, required=True)
    parser.add_argument("--timeout-seconds", type=float, default=10.0)
    parser.add_argument(
        "--replace-with-runtime-canonical",
        action="store_true",
        help=(
            "emit the Ferrum-canonical state instead of retaining both the "
            "extracted serialization and its runtime alias"
        ),
    )
    args = parser.parse_args()

    cache: dict[str, str | None] = {}
    original = aliases = canonicalization_timeouts = canonicalization_failures = 0
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with args.output.open("w", encoding="utf-8") as sink:
        for input_path in args.input:
            with input_path.open(encoding="utf-8") as source:
                inputs = inline_inputs(json.loads(line) for line in source if line.strip())
            with input_path.open(encoding="utf-8") as source:
                for line_number, line in enumerate(source, start=1):
                    if not line.strip():
                        continue
                    row = json.loads(line)
                    original_row = row
                    state = row.get('input') or {}
                    if not state.get('cpf') and state.get('problem_key') in inputs:
                        row = dict(row, input=dict(state, cpf=inputs[state['problem_key']]))
                    original += 1
                    if not is_runtime_canonicalizable_event(row):
                        sink.write(json.dumps(row, separators=(",", ":")) + "\n")
                        continue
                    cpf = row["input"]["cpf"]
                    raw_key = hashlib.sha256(cpf.strip().encode()).hexdigest()
                    if raw_key not in cache:
                        try:
                            canonical = canonicalize(
                                args.ferrum.resolve(),
                                cpf,
                                args.timeout_seconds,
                            )
                        except subprocess.TimeoutExpired:
                            canonical = None
                            canonicalization_timeouts += 1
                        except RuntimeError:
                            canonical = None
                            canonicalization_failures += 1
                        cache[raw_key] = canonical
                    else:
                        canonical = cache[raw_key]
                    if canonical is None:
                        sink.write(json.dumps(row, separators=(",", ":")) + "\n")
                        continue
                    if canonical == cpf.strip():
                        sink.write(json.dumps(row, separators=(",", ":")) + "\n")
                        continue
                    if not args.replace_with_runtime_canonical:
                        sink.write(json.dumps(original_row, separators=(",", ":")) + "\n")
                    alias = json.loads(json.dumps(row))
                    alias["input"]["cpf"] = canonical
                    alias["input"]["problem_key"] = hashlib.sha256(
                        canonical.encode()
                    ).hexdigest()
                    metrics = alias.setdefault("metrics", {})
                    metrics["runtime_canonical_alias"] = True
                    metrics["runtime_canonical_source"] = (
                        f"{input_path}:{line_number}"
                    )
                    sink.write(json.dumps(alias, separators=(",", ":")) + "\n")
                    aliases += 1
    print(
        json.dumps(
            {
                "original_events": original,
                "canonical_aliases": aliases,
                "canonicalization_failures": canonicalization_failures,
                "canonicalization_timeouts": canonicalization_timeouts,
                "distinct_dp_inputs": len(cache),
                "output": str(args.output),
            },
            sort_keys=True,
        )
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
