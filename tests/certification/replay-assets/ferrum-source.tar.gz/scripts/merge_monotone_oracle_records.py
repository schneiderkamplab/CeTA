#!/usr/bin/env python3
"""Merge utility-guidance records without replacing stronger evidence."""

from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path
from atomic_artifact import atomic_text_output


STATUS_RANK = {
    "timeout": 0,
    "failed": 1,
    "transformed_weak": 2,
    "transformed_strong": 3,
    "solved": 4,
}
POSITIVE_STATUSES = {"solved", "transformed_strong", "transformed_weak"}


def replay_priority(item: dict) -> tuple:
    candidate = str(item.get("candidate", ""))
    compound = ";" in candidate or "parallel(" in candidate or "choice(" in candidate
    return (
        compound,
        -STATUS_RANK.get(str(item.get("status")), -1),
        -float(item.get("utility_score", -1e30)),
        candidate,
    )


def has_positive_guidance(row: dict) -> bool:
    return any(
        item.get("status") in POSITIVE_STATUSES
        for bucket in ("prefer", "possible")
        for item in row.get(bucket, [])
    )


def candidate_identity(item: dict) -> tuple[str, str]:
    """Return the executable identity without collapsing interned witnesses.

    Large exact atoms may be stored once as metadata and referenced from a
    state row through ``candidate_ref``.  Treating the missing ``candidate``
    field as an empty string made every such exact witness collide during a
    monotone merge, silently deleting certified replay chains.
    """
    candidate_ref = item.get("candidate_ref")
    if candidate_ref is not None:
        return "ref", str(candidate_ref)
    return "inline", str(item.get("candidate", ""))


def metadata_key(row: dict) -> tuple[str, str]:
    schema = str(row.get("schema", ""))
    identity = row.get("witness_id")
    if identity is None:
        identity = json.dumps(row, sort_keys=True, separators=(",", ":"))
    return schema, str(identity)


def load(path: Path) -> tuple[dict[tuple[str, str], dict], dict[str, dict]]:
    metadata: dict[tuple[str, str], dict] = {}
    records: dict[str, dict] = {}
    with path.open(encoding="utf-8") as stream:
        for line in stream:
            row = json.loads(line)
            key = row.get("problem_key")
            if key is None:
                identity = metadata_key(row)
                previous = metadata.get(identity)
                if previous is not None and previous != row:
                    raise RuntimeError(
                        f"conflicting metadata record in {path}: {identity}"
                    )
                metadata[identity] = row
                continue
            if key in records:
                raise RuntimeError(f"duplicate problem_key in {path}: {key}")
            records[key] = row
    return metadata, records


def merge_bucket(current: list[dict], incoming: list[dict]) -> list[dict]:
    # Candidate order is executable replay evidence.  Preserve the base
    # oracle's order, update matching observations in place, and append only
    # genuinely new candidates.  Sorting by a newly merged utility score can
    # move a locally valid transformation ahead of a certified closing atom
    # and expose a different, uncovered residual state.
    result = [dict(item) for item in current]
    positions = {candidate_identity(item): index for index, item in enumerate(result)}
    for raw in incoming:
        item = dict(raw)
        candidate = candidate_identity(item)
        position = positions.get(candidate)
        if position is None:
            positions[candidate] = len(result)
            result.append(item)
            continue
        previous = result[position]
        if STATUS_RANK.get(str(item.get("status")), -1) > STATUS_RANK.get(
            str(previous.get("status")), -1
        ):
            previous["status"] = item.get("status")
        for field in (
            "attempts",
            "certified_count",
            "failed_count",
            "solved_count",
            "timeout_count",
            "transformed_count",
        ):
            previous[field] = max(
                int(previous.get(field, 0)), int(item.get(field, 0))
            )
        elapsed = [
            int(value)
            for value in (
                previous.get("best_elapsed_ms"),
                item.get("best_elapsed_ms"),
            )
            if value is not None
        ]
        previous["best_elapsed_ms"] = min(elapsed) if elapsed else None
        replay_elapsed = [int(value) for value in
                          (previous.get("replay_elapsed_ms"), item.get("replay_elapsed_ms"))
                          if value is not None]
        if replay_elapsed:
            previous["replay_elapsed_ms"] = max(replay_elapsed)
        previous["utility_score"] = max(
            float(previous.get("utility_score", -1e30)),
            float(item.get("utility_score", -1e30)),
        )
    return result


def normalize_record_buckets(record: dict) -> None:
    """Keep one absorbing best observation for each executable candidate.

    Older exports could place the same candidate in both ``prefer`` and
    ``avoid``.  Merging buckets independently then allowed a later failure to
    obscure an already certified success, contrary to the monotone-oracle
    contract.  Reconcile candidates across all buckets and classify them from
    their strongest status.
    """
    items: dict[tuple[str, str], dict] = {}
    order: list[tuple[str, str]] = []
    for bucket in ("prefer", "possible", "avoid", "timeout"):
        for raw in record.get(bucket, []):
            candidate = candidate_identity(raw)
            previous = items.get(candidate)
            if previous is None:
                items[candidate] = dict(raw)
                order.append(candidate)
            else:
                items[candidate] = merge_bucket([previous], [raw])[0]
    buckets = {name: [] for name in ("prefer", "possible", "avoid", "timeout")}
    for candidate in order:
        item = items[candidate]
        status = str(item.get("status"))
        bucket = (
            "prefer"
            if status in {"solved", "transformed_strong"}
            else "possible"
            if status == "transformed_weak"
            else "timeout"
            if status == "timeout"
            else "avoid"
        )
        buckets[bucket].append(item)
    for bucket, values in buckets.items():
        record[bucket] = values


def promote_incoming_candidates(current: dict, incoming: dict) -> None:
    """Put newly verified exact-state actions before older alternatives."""
    incoming_replay_order = incoming.get('replay_order') or ([
        hashlib.sha256(item['candidate'].encode()).hexdigest()
        for bucket in ('prefer', 'possible') for item in incoming.get(bucket, [])
        if item.get('candidate') and item.get('status') in POSITIVE_STATUSES
    ] if current.get('replay_order') else [])
    if incoming_replay_order:
        current['replay_order'] = list(dict.fromkeys([
            *incoming_replay_order, *current.get('replay_order', [])]))
    incoming_order = {
        candidate_identity(item): index
        for bucket in ("prefer", "possible", "avoid", "timeout")
        for index, item in enumerate(incoming.get(bucket, []))
    }
    for bucket in ("prefer", "possible", "avoid", "timeout"):
        current[bucket].sort(
            key=lambda item: (
                0 if candidate_identity(item) in incoming_order else 1,
                incoming_order.get(candidate_identity(item), 0),
            )
        )


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--base", type=Path, required=True)
    parser.add_argument("--incoming", type=Path, action="append", required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--report", type=Path, required=True)
    parser.add_argument(
        "--new-keys-only",
        action="store_true",
        help=(
            "import only keys absent from the base; use this when the incoming "
            "file is an older full-oracle snapshot whose overlapping rows must "
            "not reorder or replace newer replay evidence"
        ),
    )
    parser.add_argument(
        "--promote-incoming",
        action="store_true",
        help=(
            "place incoming candidates before older candidates for touched exact "
            "states; use after an independently certified replay establishes a "
            "better executable next action"
        ),
    )
    parser.add_argument(
        "--promote-key-file",
        type=Path,
        help=(
            "promote incoming candidates only for problem keys listed in this "
            "file (the first whitespace-separated field on each nonblank line); "
            "use this for exact states exercised by a certified replay"
        ),
    )
    parser.add_argument(
        "--incoming-key-file",
        type=Path,
        help=(
            "import incoming state rows only for keys listed in this file and "
            "their transitive canonical alias targets; witness metadata is "
            "retained so interned exact candidates remain executable"
        ),
    )
    parser.add_argument(
        "--incoming-exact-keys-only",
        action="store_true",
        help=(
            "when --incoming-key-file is present, import only those literal "
            "state rows and do not follow canonical_problem_key aliases; use "
            "this for proof-local runtime hashes whose canonical targets may "
            "also be shared by semantically richer states"
        ),
    )
    args = parser.parse_args()
    promote_keys: set[str] | None = None
    if args.promote_key_file is not None:
        promote_keys = {
            line.split(maxsplit=1)[0]
            for line in args.promote_key_file.read_text(encoding="utf-8").splitlines()
            if line.strip() and not line.lstrip().startswith("#")
        }
    incoming_keys: set[str] | None = None
    if args.incoming_key_file is not None:
        incoming_keys = {
            line.split(maxsplit=1)[0]
            for line in args.incoming_key_file.read_text(encoding="utf-8").splitlines()
            if line.strip() and not line.lstrip().startswith("#")
        }
    metadata, records = load(args.base)
    base_count = len(records)
    base_metadata_count = len(metadata)
    touched: set[str] = set()
    restored_aliases = 0
    for path in args.incoming:
        incoming_metadata, incoming_records = load(path)
        if incoming_keys is not None:
            selected = set(incoming_keys)
            if not args.incoming_exact_keys_only:
                pending = list(selected)
                while pending:
                    selected_key = pending.pop()
                    selected_row = incoming_records.get(selected_key)
                    if selected_row is None:
                        continue
                    canonical_key = selected_row.get("canonical_problem_key")
                    if canonical_key is not None and canonical_key not in selected:
                        selected.add(canonical_key)
                        pending.append(canonical_key)
            incoming_records = {
                key: row for key, row in incoming_records.items() if key in selected
            }
        for identity, row in incoming_metadata.items():
            previous = metadata.get(identity)
            if previous is not None and previous != row:
                raise RuntimeError(
                    f"conflicting metadata record across inputs: {identity}"
                )
            metadata[identity] = row
        for key, row in incoming_records.items():
            touched.add(key)
            current = records.get(key)
            if current is None:
                records[key] = row
                continue
            if args.new_keys_only:
                # ``new-keys-only`` protects the base candidate order, but a
                # canonical alias is part of the executable lookup relation,
                # not a competing candidate.  Older certified snapshots may
                # be the only place retaining that relation. Restore only a
                # missing fallback alias on a base row that has no positive
                # direct guidance; exact base evidence therefore remains
                # authoritative.
                if (
                    "canonical_problem_key" in row
                    and "canonical_problem_key" not in current
                    and not has_positive_guidance(current)
                ):
                    current["canonical_problem_key"] = row["canonical_problem_key"]
                    restored_aliases += 1
                continue
            # Direct exact-state evidence always supersedes a bare alias.
            if any(row.get(bucket) for bucket in ("prefer", "possible", "avoid", "timeout")):
                # Preserve the base alias's *effective* guidance before
                # replacing the alias relation.  At load time an alias
                # inherits its canonical target after its exact candidates;
                # dropping canonical_problem_key here used to discard that
                # established replay path whenever another category supplied
                # direct evidence for the same serialized key.
                canonical_key = current.get("canonical_problem_key")
                canonical = records.get(canonical_key) if canonical_key else None
                if canonical is not None:
                    for bucket in ("prefer", "possible", "avoid", "timeout"):
                        current[bucket] = merge_bucket(
                            list(current.get(bucket, [])),
                            list(canonical.get(bucket, [])),
                        )
                current.pop("canonical_problem_key", None)
                # New native exports can carry direct hints AND a checked
                # canonical link. Preserve that link so adding a raw-state
                # hint cannot shadow the canonical search alternatives.
                if "canonical_problem_key" in row:
                    current["canonical_problem_key"] = row["canonical_problem_key"]
            elif "canonical_problem_key" in row and not has_positive_guidance(current):
                current["canonical_problem_key"] = row["canonical_problem_key"]
            for bucket in ("prefer", "possible", "avoid", "timeout"):
                current[bucket] = merge_bucket(
                    list(current.get(bucket, [])), list(row.get(bucket, []))
                )
            normalize_record_buckets(current)
            if args.promote_incoming or (
                promote_keys is not None and key in promote_keys
            ):
                promote_incoming_candidates(current, row)
    for record in records.values():
        normalize_record_buckets(record)
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with atomic_text_output(args.output) as stream:
        for identity in sorted(metadata):
            stream.write(
                json.dumps(metadata[identity], sort_keys=True, separators=(",", ":"))
                + "\n"
            )
        for key in sorted(records):
            stream.write(json.dumps(records[key], sort_keys=True, separators=(",", ":")) + "\n")
    report = {
        "schema": "ferrum.monotone-oracle-merge.v1",
        "base_records": base_count,
        "base_metadata_records": base_metadata_count,
        "incoming": [str(path.resolve()) for path in args.incoming],
        "touched_keys": len(touched),
        "output_records": len(records),
        "output_metadata_records": len(metadata),
        "output": str(args.output.resolve()),
        "new_keys_only": args.new_keys_only,
        "promote_incoming": args.promote_incoming,
        "promote_key_file": (
            str(args.promote_key_file.resolve())
            if args.promote_key_file is not None
            else None
        ),
        "promoted_keys": len(promote_keys or ()),
        "restored_canonical_aliases": restored_aliases,
        "incoming_key_file": (
            str(args.incoming_key_file.resolve())
            if args.incoming_key_file is not None
            else None
        ),
        "selected_incoming_keys": (
            len(incoming_keys) if incoming_keys is not None else None
        ),
        "incoming_exact_keys_only": args.incoming_exact_keys_only,
    }
    with atomic_text_output(args.report) as stream:
        stream.write(json.dumps(report, indent=2, sort_keys=True) + "\n")
    print(json.dumps(report, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
