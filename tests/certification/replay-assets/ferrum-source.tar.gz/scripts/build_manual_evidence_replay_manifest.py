#!/usr/bin/env python3
"""Resolve the manual-evidence registry to an exact root replay manifest."""

from __future__ import annotations

import argparse
import json
import re
from pathlib import Path


ROW = re.compile(r"^\| `([^`]+)` \|")
EVIDENCE_ROW = re.compile(r"^\| `([^`]+)` \| (.*?) \|")
CODE_SPAN = re.compile(r"`([^`]+)`")


def registered_problems(text: str) -> list[str]:
    problems: list[str] = []
    seen: set[str] = set()
    for line in text.splitlines():
        match = ROW.match(line)
        if match is None or match.group(1) in seen:
            continue
        problem = match.group(1)
        seen.add(problem)
        problems.append(problem)
    return problems


def registered_evidence(text: str) -> dict[str, list[str]]:
    evidence: dict[str, list[str]] = {}
    for line in text.splitlines():
        match = EVIDENCE_ROW.match(line)
        if match is None:
            continue
        problem, cell = match.groups()
        locations = [
            value
            for value in CODE_SPAN.findall(cell)
            if value.startswith(("target/", "ferrum/target/", "/tmp/"))
        ]
        retained = evidence.setdefault(problem, [])
        retained.extend(value for value in locations if value not in retained)
    return evidence


def resolve_problem(tpdb: Path, problem: str) -> Path:
    direct = tpdb / problem
    if direct.is_file():
        return direct.resolve()
    parts = Path(problem).parts
    if len(parts) < 2:
        raise ValueError(f"registry problem lacks a category: {problem}")
    category = tpdb / parts[0]
    suffix = Path(*parts[1:])
    matches = sorted(
        path.resolve()
        for path in category.rglob(suffix.name)
        if path.is_file()
        and (
            len(suffix.parts) == 1
            or path.as_posix().endswith(suffix.as_posix())
        )
    )
    if len(matches) != 1:
        raise ValueError(
            f"expected one TPDB match for {problem}, found {len(matches)}: {matches}"
        )
    return matches[0]


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--registry", type=Path, required=True)
    parser.add_argument("--tpdb", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()

    registry = args.registry.read_text(encoding="utf-8")
    problems = registered_problems(registry)
    evidence = registered_evidence(registry)
    rows = [
        {
            "category": problem.split("/", 1)[0],
            "problem_id": problem,
            "path": str(resolve_problem(args.tpdb, problem)),
            "evidence_locations": evidence.get(problem, []),
            "status": "unknown",
        }
        for problem in problems
    ]
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(
        json.dumps(rows, indent=2, sort_keys=True) + "\n", encoding="utf-8"
    )
    print(json.dumps({"registered_roots": len(rows), "output": str(args.output)}))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
