import hashlib
import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

from export_unchecked_native_probe_hints import main


class UncheckedNativeHintsTests(unittest.TestCase):
    def test_priority_does_not_promote_unchecked_evidence(self):
        with tempfile.TemporaryDirectory() as directory:
            events = Path(directory) / 'events.jsonl'
            output = Path(directory) / 'hints.jsonl'
            events.write_text(json.dumps(dict(outcome='transformed',
                input=dict(problem_key='1' * 64), strategy_atom='exact-rat-natural-poly(hex=00)',
                elapsed_ms=100)) + '\n')
            atom = 'rat-quadratic-poly(max-constant=4,max-coefficient=4,denominator=2,delta-denominator=2,coefficients=0+1+2+4,quadratic-terms=1)'
            with patch('sys.argv', ['export', '--events', str(events), '--output', str(output),
                                   '--replace-family', 'exact-rat-natural-poly',
                                   '--native-action', atom, '--prioritize']):
                main()
            row = json.loads(output.read_text())
            self.assertEqual(row['replay_order'], [hashlib.sha256(atom.encode()).hexdigest()])
            item = row['possible'][0]
            self.assertEqual(item['candidate'], atom)
            self.assertEqual(item['status'], 'transformed_weak')
            self.assertEqual(item['certified_count'], 0)
            self.assertEqual(item['solved_count'], 0)

    def test_exact_override_is_rejected_before_reading_or_writing_files(self):
        with patch('sys.argv', ['export', '--events', '/does-not-exist', '--output', '/unused',
                               '--replace-family', 'foo', '--native-action', 'exact-graph(hex=00)']):
            with self.assertRaises(SystemExit):
                main()


if __name__ == '__main__':
    unittest.main()
