import json
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest
from unittest.mock import patch

import certify_modular_terminals as subject


class TerminalCertificationTests(unittest.TestCase):
    def test_rejected_candidate_does_not_hide_certified_alternative(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory) / 'source'
            output = Path(directory) / 'output'
            (root / '0').mkdir(parents=True)
            (root / 'results.jsonl').write_text(json.dumps(dict(index=0, outcome='Solved')) + '\n')
            (root / '0/input.cpf').write_text('<input/>')
            (root / '0/atom.fs').write_text('graph')
            checks = []

            def run(command, **kwargs):
                if command[0] == 'ferrum':
                    Path(command[command.index('--cpf') + 1]).write_text('<proof/>')
                    json.dump(dict(typed_outcome='Solved'), kwargs['stdout'])
                    return subprocess.CompletedProcess(command, 0)
                checks.append(Path(command[1]).name)
                accepted = checks[-1] == 'proof-1.cpf.xml'
                return subprocess.CompletedProcess(command, 0 if accepted else 1,
                                                   'CERTIFIED\n' if accepted else 'REJECTED\n', '')

            argv = ['certify', '--root', str(root), '--output', str(output),
                    '--ferrum', 'ferrum', '--ceta', 'ceta', '--raw-only',
                    '--candidate', 'size-change']
            with patch.object(sys, 'argv', argv), patch.object(subject.subprocess, 'run', side_effect=run):
                subject.main()
            result = json.loads((output / 'results.jsonl').read_text())
            self.assertTrue(result['certified'])
            self.assertEqual(checks, ['proof-0.cpf.xml', 'proof-1.cpf.xml', 'proof-1.cpf.xml'])
            oracle = json.loads((output / 'oracle.jsonl').read_text())
            self.assertEqual(oracle['prefer'][0]['candidate'], 'size-change')
            self.assertEqual(oracle['prefer'][0]['certified_count'], 2)


if __name__ == '__main__':
    unittest.main()
