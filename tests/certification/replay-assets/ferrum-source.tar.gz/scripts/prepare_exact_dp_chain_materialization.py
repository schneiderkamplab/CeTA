#!/usr/bin/env python3
"""Prepare a DP residual and an explicit exact-processor materialization chain.

The generated strategy is not oracle evidence.  It is a campaign aid that
executes independently checked exact atoms in their certified CPF order so
Ferrum can record every current live residual.  A later extraction exports
each recorded residual as a separate state-local oracle entry.
"""

from __future__ import annotations

import argparse
import json
from pathlib import Path


def rows(path: Path):
    for line in path.read_text(encoding="utf-8", errors="replace").splitlines():
        if not line.strip():
            continue
        try:
            row = json.loads(line)
        except json.JSONDecodeError:
            continue
        if isinstance(row, dict):
            yield row


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--runtime-events", type=Path, required=True)
    parser.add_argument("--live-key", required=True)
    parser.add_argument("--proof-events", type=Path, required=True)
    parser.add_argument("--after-source-key", required=True)
    parser.add_argument("--output-input", type=Path, required=True)
    parser.add_argument("--output-strategy", type=Path, required=True)
    args = parser.parse_args()

    live_cpf = None
    for row in rows(args.runtime_events):
        event_input = row.get("input") or {}
        if event_input.get("problem_key") == args.live_key:
            live_cpf = event_input.get("cpf")
            break
        for residual in (row.get("witness") or {}).get("residuals") or []:
            if isinstance(residual, dict) and residual.get("problem_key") == args.live_key:
                live_cpf = residual.get("cpf")
                break
        if live_cpf is not None:
            break
    if not isinstance(live_cpf, str) or "<dpInput" not in live_cpf:
        parser.error(f"live DP state {args.live_key} is absent from runtime events")

    ordered = list(rows(args.proof_events))
    start = next(
        (
            index
            for index, row in enumerate(ordered)
            if (row.get("input") or {}).get("problem_key") == args.after_source_key
            and str(row.get("processor") or "").startswith("exact-red-pair(")
        ),
        None,
    )
    if start is None:
        parser.error(f"source state {args.after_source_key} is absent from proof events")
    atoms: list[str] = []
    for row in ordered[start + 1 :]:
        atom = str(row.get("strategy_atom") or row.get("processor") or "")
        if not atom.startswith("exact-red-pair("):
            break
        atoms.append(atom)
    if not atoms:
        parser.error("no following exact reduction-pair atoms found")

    args.output_input.parent.mkdir(parents=True, exist_ok=True)
    args.output_strategy.parent.mkdir(parents=True, exist_ok=True)
    args.output_input.write_text(live_cpf, encoding="utf-8")
    args.output_strategy.write_text(
        "pipeline(" + ";\n".join(atoms) + ")\n", encoding="utf-8"
    )
    print(json.dumps({"atoms": len(atoms), "input": str(args.output_input), "strategy": str(args.output_strategy)}))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
