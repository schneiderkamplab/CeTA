#!/usr/bin/env python3

import sys
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))

from collect_termcomp_proofs import parse_category_table, proof_href


class CurrentTermcompPageTests(unittest.TestCase):
    def test_show_proof_button_is_collected_as_a_proof_link(self) -> None:
        headers, rows = parse_category_table(
            """
            <table>
              <tr class="head"><th>benchmark<th>AProVE25</tr>
              <tr><td><a href="/problem?path=A.ari">A.ari</a>
                  <td class="YES"><button onclick="show_proof('https://example/proofs/a.txt')">YES</button>
              </tr>
            </table>
            """
        )
        self.assertEqual(headers, ["benchmark", "AProVE25"])
        self.assertEqual(proof_href(rows[0][1]), "https://example/proofs/a.txt")


if __name__ == "__main__":
    unittest.main()
