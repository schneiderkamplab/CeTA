#!/usr/bin/env python3

import tempfile
import unittest
import xml.etree.ElementTree as ET
from pathlib import Path
import sys
import json
import sqlite3

sys.path.insert(0, str(Path(__file__).resolve().parent))

from rank_external_proof_exploration import (
    add_root_hint_votes,
    aprove_text_evidence,
    compact_atom,
    mu_term_evidence,
    runtime_root_input,
    selected_detail_rows,
)
from normalize_proof_outputs import parse_aprove_text


class AProVETextEvidenceTests(unittest.TestCase):
    def test_maps_processors_but_not_structural_or_terminal_nodes(self) -> None:
        root = ET.fromstring(
            """
            <ferrumTextProofNormalization sourceToolFamily="AProVE">
              <processorSequence>
                <step><processor>QTRS</processor></step>
                <step><processor>DependencyPairsProof</processor></step>
                <step><processor>QDP</processor></step>
                <step><processor>DependencyGraphProof</processor></step>
                <step><processor>UsableRulesProof</processor></step>
                <step><processor>QDPSizeChangeProof</processor></step>
                <step><processor>PisEmptyProof</processor></step>
                <step><processor>YES</processor></step>
              </processorSequence>
            </ferrumTextProofNormalization>
            """
        )
        atoms, unsupported, steps = aprove_text_evidence(root)
        self.assertEqual(atoms, ["dp", "graph", "usable-rules", "size-change"])
        self.assertEqual(unsupported, [])
        self.assertEqual(steps, [])

    def test_status_selection_can_cover_all_baseline_roots(self) -> None:
        details = [
            {"path": "/tmp/TRS_Standard/A.ari", "status": "yes"},
            {"path": "/tmp/TRS_Standard/B.ari", "status": "unknown"},
        ]
        self.assertEqual(
            set(selected_detail_rows(details, ["unknown"])),
            {"TRS_Standard/B.ari"},
        )
        self.assertEqual(
            set(selected_detail_rows(details, ["all"])),
            {"TRS_Standard/A.ari", "TRS_Standard/B.ari"},
        )

    def test_aprove_text_evidence_is_attached_to_live_root(self) -> None:
        votes = {}
        add_root_hint_votes(
            votes,
            "live-root",
            [
                {
                    "tool": "AProVE 2025",
                    "certification": "uncertified",
                    "root_atoms": ["switch-innermost"],
                },
                {
                    "tool": "AProVE 2025",
                    "certification": "certified",
                    "root_atoms": ["dp"],
                },
            ],
        )
        self.assertEqual(votes["live-root"]["switch-innermost"], 1)
        self.assertEqual(votes["live-root"]["dp"], 2)

    def test_root_input_falls_back_to_first_top_level_processor_event(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            events = [
                {
                    "level": "top-level",
                    "strategy_atom": "empty",
                    "input": {"problem_key": "a" * 64, "cpf": "<trsInput />"},
                },
                {
                    "level": "dependency-pair",
                    "strategy_atom": "graph",
                    "input": {"problem_key": "b" * 64, "cpf": "<dpInput />"},
                },
            ]
            (root / "processor-events.jsonl").write_text(
                "".join(json.dumps(event) + "\n" for event in events),
                encoding="utf-8",
            )
            cache = sqlite3.connect(":memory:")
            cache.execute(
                "create table canonical_cpf_cache "
                "(raw_key text primary key, canonical_cpf text, note text)"
            )
            self.assertEqual(
                runtime_root_input(str(root), cache),
                ("a" * 64, "<trsInput />"),
            )

    def test_root_input_without_legacy_event_file_is_an_empty_pair(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            cache = sqlite3.connect(":memory:")
            self.assertEqual(
                runtime_root_input(directory, cache),
                (None, None),
            )

    def test_reports_unknown_transform_without_inventing_a_strategy(self) -> None:
        root = ET.fromstring(
            """
            <ferrumTextProofNormalization sourceToolFamily="AProVE">
              <processorSequence>
                <step><processor>DependencyPairsProof</processor></step>
                <step><processor>AAECC</processor></step>
                <step><processor>QDPOrderProof</processor></step>
              </processorSequence>
            </ferrumTextProofNormalization>
            """
        )
        atoms, unsupported, steps = aprove_text_evidence(root)
        self.assertEqual(atoms, ["dp", "orders"])
        self.assertEqual(unsupported, ["aprove-text:AAECC"])
        self.assertEqual(steps, [])

    def test_missing_sequence_is_explicit(self) -> None:
        root = ET.fromstring(
            '<ferrumTextProofNormalization sourceToolFamily="AProVE" />'
        )
        self.assertEqual(
            aprove_text_evidence(root),
            ([], ["aprove-text:missing-processor-sequence"], []),
        )

    def test_maps_certified_csr_and_q_processor_families(self) -> None:
        root = ET.fromstring(
            """
            <ferrumTextProofNormalization sourceToolFamily="AProVE">
              <processorSequence>
                <step><processor>QReductionProof</processor><detail /></step>
                <step><processor>CSDependencyPairsProof</processor><detail /></step>
                <step><processor>CSRRRRProof</processor><detail>polynomial</detail></step>
                <step><processor>QCSDPForwardInstantiationProcessor</processor><detail /></step>
              </processorSequence>
            </ferrumTextProofNormalization>
            """
        )
        atoms, unsupported, steps = aprove_text_evidence(root)
        self.assertEqual(
            atoms,
            [
                "innermost-lhss",
                "csr-improved-dp",
                "poly(max-constant=4,max-coefficient=4)",
                "forward-instantiate(max-per-pair=2)",
            ],
        )
        self.assertEqual(unsupported, [])
        self.assertEqual(steps, [])

    def test_maps_detailed_generic_transformation(self) -> None:
        root = ET.fromstring(
            """
            <ferrumTextProofNormalization sourceToolFamily="AProVE">
              <processorSequence>
                <step>
                  <processor>TransformationProof</processor>
                  <detail>narrowing</detail>
                </step>
              </processorSequence>
            </ferrumTextProofNormalization>
            """
        )
        self.assertEqual(
            aprove_text_evidence(root),
            (["narrow(max-per-pair=2)"], [], []),
        )


class AProVENormalizationTests(unittest.TestCase):
    def test_extracts_details_and_polynomial_after_blank_line(self) -> None:
        summary = parse_aprove_text(
            """YES
(0) QTRS
(1) QTRSRRRProof [EQUIVALENT, 10 ms]
(2) QTRS

(1) QTRSRRRProof (EQUIVALENT)
Used ordering:
Polynomial interpretation [POLO]:

  POL(f(x_1)) = 2 + 3*x_1
With this ordering the following rules can be removed:

(2)
Obligation:
"""
        )
        qtrs_steps = [
            step for step in summary["steps"] if step["processor"] == "QTRSRRRProof"
        ]
        self.assertTrue(qtrs_steps)
        self.assertTrue(all(step["detail"] == "polynomial" for step in qtrs_steps))
        self.assertEqual(
            summary["polynomial_interpretations"][0]["interpretations"],
            [{"symbol": "f(x_1)", "polynomial": "2 + 3*x_1"}],
        )

    def test_classifies_narrowing_transformation_only_within_its_section(self) -> None:
        summary = parse_aprove_text(
            """YES
(9) TransformationProof [EQUIVALENT, 0 ms]
(10) QDP

(9) TransformationProof (EQUIVALENT)
By narrowing the rule at position [1] we obtained new rules.
(10)
Obligation:
The word rewriting appears only in this following obligation.
"""
        )
        transforms = [
            step for step in summary["steps"] if step["processor"] == "TransformationProof"
        ]
        self.assertTrue(transforms)
        self.assertTrue(all(step["detail"] == "narrowing" for step in transforms))

    def test_classifies_quasi_precedence_rule_removal_as_path_order(self) -> None:
        summary = parse_aprove_text(
            """YES
(1) QTRSRRRProof [EQUIVALENT, 0 ms]
(2) QTRS

(1) QTRSRRRProof (EQUIVALENT)
Used ordering:
Quasi precedence:
f_1 > g_1
f_1: multiset status
With this ordering the following rules can be removed.
(2)
Obligation:
"""
        )
        steps = [
            step for step in summary["steps"] if step["processor"] == "QTRSRRRProof"
        ]
        self.assertTrue(steps)
        self.assertTrue(all(step["detail"] == "path-order" for step in steps))


class MutermEvidenceTests(unittest.TestCase):
    def test_parses_headings_and_reduction_pair_parameters(self) -> None:
        text = """
        Dependency Pairs Processor:
        SCC Processor:
        Reduction Pair Processor:
        ->Interpretation type:
          linear
        ->Bound:
          3
        ->Dimension:
          2
        Problem residual
        """
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "proof.txt"
            path.write_text(text, encoding="utf-8")
            atoms, unsupported = mu_term_evidence(path)
        self.assertEqual(
            atoms,
            ["dp", "graph", "matrix(dim=2,max-constant=3,max-coefficient=3)"],
        )
        self.assertEqual(unsupported, [])


class RenderingTests(unittest.TestCase):
    def test_compacts_retained_witness(self) -> None:
        self.assertEqual(
            compact_atom("exact-graph(hex=" + "ab" * 200 + ")"),
            "exact-graph(<retained-witness>)",
        )


if __name__ == "__main__":
    unittest.main()
