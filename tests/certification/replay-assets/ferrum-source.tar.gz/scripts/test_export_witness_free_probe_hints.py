import hashlib
import unittest
from export_witness_free_probe_hints import collect, search_atoms, attach_canonical_alias, closed_chain_first


class NativeHintsTests(unittest.TestCase):
    def test_weighted_labeling_exports_search_bounds_not_synthesized_model(self):
        for atom in ['srs-weighted-labeling(carrier-size=3,max-weight=4)',
                     'srs-weighted-labeling(carrier-size=4,max-weight=2,strict-percent=50)']:
            event = self.event(search_atom=atom, elapsed_ms=100)
            event['strategy_atom'] = 'exact-relative-semantic-labeling(carrier-size=3,hex=invalid)'
            hint = collect([event])[0]['possible'][0]
            self.assertEqual(hint['candidate'], atom)
            self.assertEqual(hint['certified_count'], 0)

    def test_refined_graph_is_native_state_local_guidance(self):
        self.assertEqual(search_atoms('graph-refined'), ['graph-refined'])
        hint = collect([self.event(search_atom='graph-refined')])[0]['possible'][0]
        self.assertEqual(hint['candidate'], 'graph-refined')
        self.assertEqual(hint['certified_count'], 0)

    def test_inferred_signature_cutoffs_cover_the_typed_state(self):
        cpf = '<dpInput><trs><rules><rule><funapp><name>f</name><funapp><name>a</name></funapp><funapp><name>b</name></funapp></funapp><var>x</var></rule></rules></trs></dpInput>'
        atom = 'poly(max-constant=2,max-coefficient=1,max-symbols=1,max-arity=1)'
        event = dict(input=dict(problem_key=hashlib.sha256(cpf.encode()).hexdigest(), cpf=cpf),
                     strategy_atom=atom, outcome='transformed')
        hint = collect([event])[0]['possible'][0]
        self.assertIn('max-symbols=3', hint['candidate'])
        self.assertIn('max-arity=2', hint['candidate'])
        self.assertEqual(hint['certified_count'], 0)
        event['search_atom'] = atom
        self.assertEqual(collect([event])[0]['possible'][0]['candidate'], atom)

    def test_closed_chain_ranking_requires_all_children_and_rejects_circular_support(self):
        def event(key, atom, children=None):
            return dict(input=dict(problem_key=key), strategy_atom=atom,
                        outcome='solved' if children is None else 'transformed',
                        witness=dict(residuals=[dict(problem_key=c) for c in children or []]))
        incomplete = event('root', 'incomplete', ['leaf', 'missing'])
        circular = event('root', 'circular', ['root'])
        long = event('root', 'long', ['middle'])
        short = event('root', 'short', ['leaf'])
        events = [incomplete, circular, long, event('middle', 'step', ['leaf']), short,
                  event('leaf', 'terminal'), event('cycle', 'unseeded-cycle', ['cycle'])]
        ranked = closed_chain_first(events)
        names = [e['strategy_atom'] for e in ranked]
        self.assertLess(names.index('short'), names.index('long'))
        self.assertLess(names.index('short'), names.index('circular'))
        self.assertGreater(names.index('incomplete'), names.index('long'))
        self.assertEqual(len(ranked), len(events))

    def test_symbolic_loop_is_native_modular_search_without_witness_credit(self):
        for atom in ('nontermination(dp-symbolic-loop)', 'nontermination(dp-backward-loop)', 'nontermination(dp-fork-loop)', 'nontermination(dp-fair-loop)', 'nontermination-cycle(candidate=2,min-length=2,max-length=4)', 'nontermination-narrow(candidate=3,all=1,below=1)', 'nontermination-instance(candidate=3,constants=1,all=1)', 'nontermination-rule-filter(max-lhs=3,max-rhs=4,collapsing=0)'):
            with self.subTest(atom=atom):
                self.assertEqual(search_atoms('timeout(60s, ' + atom + ')'), [atom])
                row = collect([self.event(search_atom=atom, elapsed_ms=50)])[0]
                self.assertEqual(row['possible'][0]['candidate'], atom)
                self.assertEqual(row['possible'][0]['certified_count'], 0)

    def test_probe_alias_keeps_native_action_and_measured_allowance(self):
        raw = collect([self.event(elapsed_ms=70)])[0]
        raw['possible'][0]['replay_elapsed_ms'] = 70
        key = raw['problem_key']
        target = dict(collect([self.event(elapsed_ms=1)])[0], problem_key='a' * 64)
        rows = {key: raw, target['problem_key']: target}
        attach_canonical_alias(rows, key, target['problem_key'])
        self.assertEqual(raw['canonical_problem_key'], target['problem_key'])
        self.assertEqual(target['possible'][0]['replay_elapsed_ms'], 70)
        self.assertEqual(target['possible'][0]['certified_count'], 0)
        self.assertNotIn('canonical_problem_key', target)

    def test_actual_native_search_bounds_survive_witness_export(self):
        event = self.event(search_atom='poly(max-constant=4,candidate=2)', elapsed_ms=12)
        event['strategy_atom'] = 'exact-poly(hex=invalid)'
        hint = collect([event])[0]['possible'][0]
        self.assertEqual(hint['candidate'], 'poly(max-constant=4,candidate=2)')
        self.assertEqual(hint['best_elapsed_ms'], 12)
        self.assertEqual(hint['certified_count'], 0)

    def test_supplied_search_witness_is_not_mistaken_for_native_parameters(self):
        event = self.event(search_atom='exact-trs-proof(hex=00)')
        with self.assertRaisesRegex(ValueError, 'unsupported'):
            collect([event])

    def test_dp_discovery_continuation_is_not_exported_as_root_guidance(self):
        event = self.event(search_atom='dp(pipeline(nontermination-narrow(candidate=1); nontermination(dp-loop)))')
        hints = collect([event])[0]['possible']
        self.assertEqual([hint['candidate'] for hint in hints], ['dp'])
        self.assertEqual(hints[0]['certified_count'], 0)
        trimmed = collect([self.event(search_atom='dp-trimmed(graph; size-change)')])[0]['possible']
        self.assertEqual([hint['candidate'] for hint in trimmed], ['dp-trimmed'])
        with self.assertRaisesRegex(ValueError, 'compound'):
            collect([self.event(search_atom='pipeline(graph; size-change)')])

    def test_uniform_status_is_a_search_parameter_not_a_witness(self):
        atom = 'path-order(status=rpo,optimize=0)'
        self.assertEqual(search_atoms('timeout(60s, ' + atom + ')'), [atom])

    def test_csr_discovery_continuation_remains_at_child_states(self):
        for atom in ('csr-native-dp', 'csr-improved-dp', 'csr-safe-dp',
                     'csr-native-ordinary-dp', 'csr-conservative-dp'):
            event = self.event(search_atom=atom + '(pipeline(graph; size-change))')
            hints = collect([event])[0]['possible']
            self.assertEqual([hint['candidate'] for hint in hints], [atom])
            self.assertEqual(hints[0]['certified_count'], 0)

    def test_original_bounds_are_untried_not_measured_or_certified(self):
        originals = search_atoms('graph | timeout(60s, poly(max-constant=4)) | poly(max-constant=4)')
        self.assertEqual(originals, ['graph', 'poly(max-constant=4)'])
        hints = collect([self.event(elapsed_ms=123)], originals)[0]['possible']
        self.assertEqual([h['candidate'] for h in hints],
                         ['poly(max-constant=4)', 'poly(max-constant=2)'])
        self.assertEqual(hints[0]['attempts'], 0)
        self.assertEqual(hints[0]['transformed_count'], 0)
        self.assertNotIn('best_elapsed_ms', hints[0])
        self.assertEqual(hints[1]['best_elapsed_ms'], 123)
        self.assertTrue(all(h['certified_count'] == 0 for h in hints))

    def test_recipe_rejects_witnesses_compounds_and_unknown_syntax(self):
        for recipe in ('exact-poly(hex=00)', 'graph;poly', 'dp(poly)',
                       'timeout(0s, poly)', 'poly(foo=nan)', 'unknown'):
            with self.assertRaisesRegex(ValueError, 'native search recipe'):
                search_atoms(recipe)

    def event(self, **kwargs):
        cpf = '<dpInput/>'
        return dict(outcome='transformed', processor='poly(max-constant=2)',
                    input=dict(cpf=cpf, problem_key=hashlib.sha256(cpf.encode()).hexdigest()),
                    **kwargs)

    def test_zero_credit_and_deduplication(self):
        event = self.event()
        rows = collect([event, event])
        self.assertEqual(len(rows), 1)
        self.assertEqual(len(rows[0]['possible']), 1)
        self.assertEqual(rows[0]['possible'][0]['certified_count'], 0)
        self.assertEqual(rows[0]['prefer'], [])

    def test_digest_and_unsupported_actions_fail_closed(self):
        event = self.event()
        event['input']['cpf'] = '<other/>'
        with self.assertRaisesRegex(ValueError, 'digest'):
            collect([event])
        event = self.event()
        event['processor'] = 'exact-trs-proof(hex=00)'
        with self.assertRaisesRegex(ValueError, 'unsupported'):
            collect([event])

    def test_failed_attempt_is_not_imported(self):
        event = self.event()
        event['outcome'] = 'failed'
        self.assertEqual(collect([event]), [])


if __name__ == '__main__':
    unittest.main()
