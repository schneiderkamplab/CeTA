#!/usr/bin/env python3
"""Build LLM-oriented proof-step training data from Ferrum proof rows.

The output keeps the checker-facing XML label, but also exposes structured
targets for three uses:

* next-processor prediction;
* processor-parameter prediction;
* proof-witness suggestion.

The script does not trust the source proof blindly.  It joins optional fragment
audit result files and records whether a row was independently certified as a
standalone fragment, certified after nontrivial standardization, or only known
from the complete/source proof corpus.
"""

from __future__ import annotations

import argparse
import gzip
import hashlib
import json
import re
import xml.etree.ElementTree as ET
from pathlib import Path
from typing import Any


NUMBER_RE = re.compile(r"[-+]?\d+(?:/\d+)?")

PROCESSOR_ALIASES = {
    "removed": "ruleRemoval",
    "ruleRemovalProc": "ruleRemoval",
    "polynomialOrder": "interpretation",
    "matrixOrder": "interpretation",
    "pathOrder": "pathOrder",
    "recursivePathOrder": "pathOrder",
    "kbo": "pathOrder",
    "lpo": "pathOrder",
    "rpo": "pathOrder",
    "pIsEmpty": "emptyDPProblem",
    "rIsEmpty": "emptyTRS",
}


def open_input(path: Path):
    return gzip.open(path, "rt", encoding="utf-8") if path.suffix == ".gz" else path.open("r", encoding="utf-8")


def open_output(path: Path):
    path.parent.mkdir(parents=True, exist_ok=True)
    return gzip.open(path, "wt", encoding="utf-8") if path.suffix == ".gz" else path.open("w", encoding="utf-8")


def local_name(tag: str) -> str:
    return tag.rsplit("}", 1)[-1]


def parse_xml(text: str | None) -> ET.Element | None:
    if not text:
        return None
    try:
        return ET.fromstring(text.encode())
    except ET.ParseError:
        return None


def child_text(elem: ET.Element | None, name: str) -> str | None:
    if elem is None:
        return None
    for child in elem:
        if local_name(child.tag) == name:
            return "".join(child.itertext()).strip()
    return None


def iter_fun_symbols(root: ET.Element | None) -> list[str]:
    if root is None:
        return []
    symbols: list[str] = []
    for elem in root.iter():
        if local_name(elem.tag) != "funapp":
            continue
        name = child_text(elem, "name")
        if name is not None:
            symbols.append(name)
    return symbols


def count_rules(root: ET.Element | None) -> int:
    if root is None:
        return 0
    return sum(1 for elem in root.iter() if local_name(elem.tag) == "rule")


def count_dependency_pairs(root: ET.Element | None) -> int:
    if root is None:
        return 0
    return sum(1 for elem in root.iter() if local_name(elem.tag) in {"dependencyPair", "dp"})


def xml_tag_counts(root: ET.Element | None) -> dict[str, int]:
    counts: dict[str, int] = {}
    if root is None:
        return counts
    for elem in root.iter():
        name = local_name(elem.tag)
        counts[name] = counts.get(name, 0) + 1
    return dict(sorted(counts.items()))


def numbers_in_xml(root: ET.Element | None, limit: int = 200) -> list[str]:
    if root is None:
        return []
    text = ET.tostring(root, encoding="unicode")
    return NUMBER_RE.findall(text)[:limit]


def canonical_processor(name: str | None) -> str:
    if not name:
        return "unknown"
    return PROCESSOR_ALIASES.get(name, name)


def top_processor(row: dict[str, Any], output_root: ET.Element | None) -> str:
    if output_root is not None:
        return canonical_processor(local_name(output_root.tag))
    metadata = row.get("metadata") or {}
    return canonical_processor(str(metadata.get("processor_tag") or "unknown"))


def trust_from_status(status: str | None) -> str:
    if status == "certified":
        return "certified_fragment"
    if status in {"ceta_failed", "timeout", "standardization_failed"}:
        return f"fragment_{status}"
    if status == "unsupported":
        return "complete_or_text_only"
    return "unknown"


def load_status_map(path: Path | None) -> dict[str, str]:
    if path is None:
        return {}
    statuses: dict[str, str] = {}
    with open_input(path) as handle:
        for line in handle:
            row = json.loads(line)
            row_id = row.get("row_id")
            if row_id:
                statuses[str(row_id)] = str(row.get("status") or "")
    return statuses


def summarize_interpretations(root: ET.Element | None) -> dict[str, Any]:
    if root is None:
        return {}
    kinds = []
    for tag in ("polynomialOrder", "matrixOrder", "linearPolynomialOrder", "interpretation"):
        if any(local_name(elem.tag) == tag for elem in root.iter()):
            kinds.append(tag)
    symbols = []
    for elem in root.iter():
        if local_name(elem.tag) == "interpret":
            name = child_text(elem, "name")
            if name:
                symbols.append(name)
    return {
        "families": sorted(set(kinds)),
        "interpreted_symbols": sorted(set(symbols)),
        "interpreted_symbol_count": len(set(symbols)),
        "numeric_constants": numbers_in_xml(root, limit=200),
    }


def summarize_path_order(root: ET.Element | None) -> dict[str, Any]:
    if root is None:
        return {}
    order_tags = {"pathOrder", "kbo", "lpo", "rpo", "recursivePathOrder"}
    families = sorted({local_name(elem.tag) for elem in root.iter() if local_name(elem.tag) in order_tags})
    names = []
    for elem in root.iter():
        if local_name(elem.tag) in {"precedence", "status", "argumentFilter", "usableArgumentFilter"}:
            names.extend(iter_fun_symbols(elem))
    return {
        "families": families,
        "mentioned_symbols": sorted(set(names)),
        "numeric_constants": numbers_in_xml(root, limit=100),
    }


def summarize_removed_rules(root: ET.Element | None) -> dict[str, Any]:
    return {"removed_rule_count": count_rules(root), "symbols": sorted(set(iter_fun_symbols(root)))}


def summarize_components(root: ET.Element | None) -> dict[str, Any]:
    if root is None:
        return {}
    component_sizes = []
    for elem in root.iter():
        if local_name(elem.tag) in {"component", "realScc", "scc"}:
            component_sizes.append(count_dependency_pairs(elem) or count_rules(elem))
    return {"component_count": len(component_sizes), "component_sizes": component_sizes[:200]}


def witness_summary(processor: str, output_root: ET.Element | None) -> dict[str, Any]:
    summary: dict[str, Any] = {
        "xml_tag_counts": xml_tag_counts(output_root),
        "numeric_constants": numbers_in_xml(output_root, limit=200),
    }
    if processor in {"interpretation", "redPairProc", "monoRedPairProc"}:
        summary["interpretation"] = summarize_interpretations(output_root)
    if processor in {"pathOrder", "redPairProc", "monoRedPairProc"}:
        summary["path_order"] = summarize_path_order(output_root)
    if processor in {"ruleRemoval", "equalityRemoval", "innermostLhssRemovalProc"}:
        summary["removed"] = summarize_removed_rules(output_root)
    if processor == "depGraphProc":
        summary["dependency_graph"] = summarize_components(output_root)
    if processor in {"dpTrans", "usableRulesProc", "sizeChangeProc", "narrowingProc", "instantiationProc", "forwardInstantiationProc", "csrForwardInstantiationProc"}:
        summary["rule_count"] = count_rules(output_root)
        summary["dependency_pair_count"] = count_dependency_pairs(output_root)
        summary["symbols"] = sorted(set(iter_fun_symbols(output_root)))
    return summary


def row_id(row: dict[str, Any]) -> str:
    return str(row.get("id") or "")


def source_row_id(row: dict[str, Any]) -> str:
    return str(row.get("source_row_id") or row.get("id") or "")


def build_example(
    row: dict[str, Any],
    canonical_statuses: dict[str, str],
    original_standardized_statuses: dict[str, str],
    include_xml: bool,
) -> dict[str, Any]:
    problem_root = parse_xml((row.get("input") or {}).get("problem_xml"))
    context_xml = (row.get("input") or {}).get("local_context_xml")
    output_xml = row.get("output_xml")
    output_root = parse_xml(output_xml)
    processor = top_processor(row, output_root)
    rid = row_id(row)
    srid = source_row_id(row)
    canonical_status = canonical_statuses.get(rid)
    original_standardized_status = original_standardized_statuses.get(srid)
    trust = {
        "canonical_fragment_status": canonical_status,
        "canonical_fragment_trust": trust_from_status(canonical_status),
        "original_standardized_fragment_status": original_standardized_status,
        "original_standardized_fragment_trust": trust_from_status(original_standardized_status),
        "source_certification": (row.get("metadata") or {}).get("certification"),
    }
    problem_symbols = sorted(set(iter_fun_symbols(problem_root)))
    target = {
        "processor": processor,
        "parameters": witness_summary(processor, output_root),
        "proof_suggestion_xml": output_xml if include_xml else None,
    }
    example: dict[str, Any] = {
        "id": hashlib.sha256(json.dumps({"row": rid, "source": srid, "processor": processor}, sort_keys=True).encode()).hexdigest(),
        "row_id": rid,
        "source_row_id": srid,
        "task": "proof_step_suggestion",
        "input": {
            "problem_xml": (row.get("input") or {}).get("problem_xml") if include_xml else None,
            "local_context_xml": context_xml if include_xml else None,
            "problem_features": {
                "rule_count": count_rules(problem_root),
                "dependency_pair_count": count_dependency_pairs(problem_root),
                "function_symbols": problem_symbols,
                "function_symbol_count": len(problem_symbols),
                "xml_tag_counts": xml_tag_counts(problem_root),
            },
            "available_processors": [
                "dpTrans",
                "depGraphProc",
                "usableRulesProc",
                "ruleRemoval",
                "redPairProc",
                "monoRedPairProc",
                "sizeChangeProc",
                "pathOrder",
                "interpretation",
                "stringReversal",
                "loop",
                "bounds",
            ],
        },
        "target": target,
        "trust": trust,
        "metadata": row.get("metadata") or {},
        "cpf_normalization": row.get("cpf_normalization") or {},
        "canonicalization": row.get("canonicalization") or {},
    }
    if not include_xml:
        example["xml_sizes"] = {
            "problem_xml_bytes": len(((row.get("input") or {}).get("problem_xml") or "").encode()),
            "local_context_xml_bytes": len((context_xml or "").encode()),
            "output_xml_bytes": len((output_xml or "").encode()),
        }
    return example


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--input", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--summary", type=Path, required=True)
    parser.add_argument("--canonical-fragment-results", type=Path)
    parser.add_argument("--original-standardized-results", type=Path)
    parser.add_argument("--include-xml", action=argparse.BooleanOptionalAction, default=True)
    parser.add_argument("--limit", type=int)
    parser.add_argument("--progress-interval", type=int, default=50000)
    args = parser.parse_args()

    canonical_statuses = load_status_map(args.canonical_fragment_results)
    original_standardized_statuses = load_status_map(args.original_standardized_results)
    rows = 0
    processors: dict[str, int] = {}
    canonical_trust: dict[str, int] = {}
    original_trust: dict[str, int] = {}

    with open_input(args.input) as source, open_output(args.output) as sink:
        for line in source:
            row = json.loads(line)
            example = build_example(row, canonical_statuses, original_standardized_statuses, args.include_xml)
            sink.write(json.dumps(example, sort_keys=True, separators=(",", ":")) + "\n")
            rows += 1
            processor = example["target"]["processor"]
            processors[processor] = processors.get(processor, 0) + 1
            ctrust = example["trust"]["canonical_fragment_trust"]
            otrust = example["trust"]["original_standardized_fragment_trust"]
            canonical_trust[ctrust] = canonical_trust.get(ctrust, 0) + 1
            original_trust[otrust] = original_trust.get(otrust, 0) + 1
            if args.progress_interval > 0 and rows % args.progress_interval == 0:
                print(
                    json.dumps(
                        {
                            "event": "progress",
                            "rows": rows,
                            "processors": processors,
                            "canonical_trust": canonical_trust,
                            "original_standardized_trust": original_trust,
                        },
                        sort_keys=True,
                    ),
                    flush=True,
                )
            if args.limit is not None and rows >= args.limit:
                break

    summary = {
        "input": str(args.input),
        "output": str(args.output),
        "rows": rows,
        "include_xml": args.include_xml,
        "processor_counts": dict(sorted(processors.items())),
        "canonical_trust_counts": dict(sorted(canonical_trust.items())),
        "original_standardized_trust_counts": dict(sorted(original_trust.items())),
        "canonical_fragment_results": str(args.canonical_fragment_results) if args.canonical_fragment_results else None,
        "original_standardized_results": str(args.original_standardized_results) if args.original_standardized_results else None,
    }
    args.summary.write_text(json.dumps(summary, indent=2, sort_keys=True), encoding="utf-8")
    print(json.dumps(summary, sort_keys=True), flush=True)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
