import unittest
import xml.etree.ElementTree as ET

from normalize_recursive_csr_cpf import typed_dp


class RecursiveCsrTranslationTests(unittest.TestCase):
    def test_recursive_u3_instantiation_keeps_the_payload_and_typed_children(self):
        source = ET.fromstring('<dpProof><redPairUrProc><model/><dps/><usableRules/>'
            '<dpProof><instantiationProc><rule/><instantiations/>'
            '<dpProof><pIsEmpty/></dpProof></instantiationProc></dpProof>'
            '</redPairUrProc></dpProof>')
        before = ET.tostring(source)
        result = typed_dp(source)
        self.assertEqual(result.tag, 'csrDpProof')
        self.assertIsNotNone(result.find('csrRedPairUrProc/model'))
        self.assertIsNotNone(result.find('csrRedPairUrProc/csrDpProof/'
            'instantiationProc/csrDpProof/pIsEmpty'))
        self.assertEqual(before, ET.tostring(source))

    def test_unsupported_continuation_is_not_silently_reinterpreted(self):
        source = ET.fromstring('<dpProof><redPairUrProc><dpProof>'
            '<switchInnermostProc/></dpProof></redPairUrProc></dpProof>')
        self.assertIsNone(typed_dp(source))


if __name__ == '__main__':
    unittest.main()
