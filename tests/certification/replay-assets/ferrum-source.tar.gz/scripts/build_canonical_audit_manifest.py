#!/usr/bin/env python3
"""Build a reusable manifest for canonical CPF certificate audits.

The final canonical JSONL contains proof-fragment rows.  Only rows backed by a
complete certified CPF source can be checked directly by CeTA after applying the
canonical renaming to the complete certificate.  This manifest records both the
full TRS/SRS row population and the subset that is independently checkable.
"""

from __future__ import annotations

import argparse
import gzip
import hashlib
import json
from pathlib import Path
from typing import Any

from audit_canonical_collision_certificates import identity_mapping, sha256_text
from audit_standardized_subproof_rows import quick_candidate_source


def open_input(path: Path):
    return gzip.open(path, "rt", encoding="utf-8") if path.suffix == ".gz" else path.open("r", encoding="utf-8")


def open_output(path: Path):
    path.parent.mkdir(parents=True, exist_ok=True)
    return gzip.open(path, "wt", encoding="utf-8") if path.suffix == ".gz" else path.open("w", encoding="utf-8")


def is_trs_srs_category(category: str) -> bool:
    return "TRS" in category or "SRS" in category or "Rewriting" in category


def stable_hash(value: Any) -> str:
    return hashlib.sha256(json.dumps(value, sort_keys=True, separators=(",", ":")).encode()).hexdigest()


def manifest_row(row_index: int, row: dict[str, Any], source_cache: dict[str, bool]) -> dict[str, Any] | None:
    metadata = row.get("metadata") or {}
    category = str(metadata.get("category") or "")
    if not is_trs_srs_category(category):
        return None

    source = row.get("source") or {}
    canonicalization = row.get("canonicalization") or {}
    cpf_normalization = row.get("cpf_normalization") or {}
    mapping = dict(canonicalization.get("function_bijection") or {})
    source_path = source.get("xml_path")
    source_xml_format = source.get("xml_format")
    certification = metadata.get("certification")
    quick_source = False
    if source_path:
        quick_source = quick_candidate_source(source_path, source_cache)
    checkable = (
        certification == "certified"
        and source_xml_format in {"cpf-or-xml", "cpf-or-xml-normalized"}
        and bool(source_path)
        and quick_source
    )
    audit_key = stable_hash(
        {
            "source_path": source_path,
            "max_exact_symbols": canonicalization.get("max_exact_symbols"),
        }
    ) if checkable else None

    return {
        "row_index": row_index,
        "row_id": row.get("id"),
        "source_row_id": row.get("source_row_id"),
        "category": category,
        "benchmark": metadata.get("benchmark"),
        "tool": metadata.get("tool"),
        "processor_tag": metadata.get("processor_tag"),
        "certification": certification,
        "source_path": source_path,
        "source_xml_format": source_xml_format,
        "source_kind": source.get("kind"),
        "source_normalizer": source.get("normalizer"),
        "canonicalization_status": canonicalization.get("status"),
        "max_exact_symbols": canonicalization.get("max_exact_symbols", 0),
        "rule_count": canonicalization.get("rule_count"),
        "mapping_hash": stable_hash(mapping),
        "nonidentity_mapping": bool(mapping) and not identity_mapping(mapping),
        "canonical_problem_hash": sha256_text((row.get("input") or {}).get("problem_xml")),
        "input_status": cpf_normalization.get("input_status"),
        "output_status": cpf_normalization.get("output_status"),
        "checkable_complete_cpf": checkable,
        "audit_key": audit_key,
    }


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--input", type=Path, default=Path("target/termcomp-proof-corpus/training/subproofs.cpf.canonical.final.jsonl.gz"))
    parser.add_argument("--output", type=Path, default=Path("target/termcomp-proof-corpus/audit-manifests/canonical-trs-srs-manifest.jsonl.gz"))
    parser.add_argument("--summary", type=Path, default=Path("target/termcomp-proof-corpus/audit-manifests/canonical-trs-srs-manifest.summary.json"))
    parser.add_argument("--progress-interval", type=int, default=50000)
    args = parser.parse_args()

    rows_seen = 0
    rows_written = 0
    source_cache: dict[str, bool] = {}
    counts: dict[str, int] = {}
    category_counts: dict[str, int] = {}
    checkable_categories: dict[str, int] = {}
    audit_keys: set[str] = set()
    with open_input(args.input) as source, open_output(args.output) as sink:
        for line in source:
            rows_seen += 1
            row = json.loads(line)
            item = manifest_row(rows_seen, row, source_cache)
            if item is None:
                continue
            sink.write(json.dumps(item, sort_keys=True, separators=(",", ":")) + "\n")
            rows_written += 1
            category_counts[item["category"]] = category_counts.get(item["category"], 0) + 1
            key = "checkable" if item["checkable_complete_cpf"] else "not_checkable"
            counts[key] = counts.get(key, 0) + 1
            if item["nonidentity_mapping"]:
                counts["nonidentity_mapping"] = counts.get("nonidentity_mapping", 0) + 1
            if item["checkable_complete_cpf"]:
                checkable_categories[item["category"]] = checkable_categories.get(item["category"], 0) + 1
                audit_keys.add(str(item["audit_key"]))
            if args.progress_interval > 0 and rows_seen % args.progress_interval == 0:
                print(json.dumps({"event": "progress", "rows_seen": rows_seen, "rows_written": rows_written, "counts": counts}, sort_keys=True), flush=True)

    summary = {
        "input": str(args.input),
        "output": str(args.output),
        "rows_seen": rows_seen,
        "rows_written": rows_written,
        "counts": dict(sorted(counts.items())),
        "unique_audit_keys": len(audit_keys),
        "category_counts": dict(sorted(category_counts.items())),
        "checkable_category_counts": dict(sorted(checkable_categories.items())),
    }
    args.summary.parent.mkdir(parents=True, exist_ok=True)
    args.summary.write_text(json.dumps(summary, indent=2, sort_keys=True))
    print(json.dumps(summary, sort_keys=True), flush=True)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
