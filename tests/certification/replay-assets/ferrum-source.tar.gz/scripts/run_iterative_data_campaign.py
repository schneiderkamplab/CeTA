#!/usr/bin/env python3
"""Run resumable TPDB discovery/canonical-probe data-campaign rounds."""

from __future__ import annotations

import argparse
from collections import Counter
import json
import os
from pathlib import Path
import shutil
import signal
import subprocess
import sys
import time
from typing import Any


DEFAULT_SOURCE_DB = Path(
    "target/termcomp-proof-corpus/training/"
    "hrm-status-map-current-balanced-v3-20260723/"
    "ferrum.status-map.current-balanced-v3.sqlite"
)
DEFAULT_SOURCE_ORACLE = Path(
    "target/termcomp-proof-corpus/training/"
    "utility-guidance-v2/ranked-evidence.jsonl"
)
DEFAULT_CACHE = Path(
    "target/termcomp-proof-corpus/training/canonical-cpf-cache.sqlite"
)
DEFAULT_ROOTS = (
    Path("../TPDB-ARI/TRS_Standard"),
    Path("../TPDB-ARI/TRS_Innermost"),
    Path("../TPDB-ARI/SRS_Standard"),
    Path("../TPDB-ARI/TRS_Contextsensitive"),
    Path("../TPDB-ARI/TRS_Outermost"),
)


def write_json_atomic(path: Path, value: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(path.suffix + ".tmp")
    temporary.write_text(json.dumps(value, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    temporary.replace(path)


def memory_used_kb() -> int:
    values: dict[str, int] = {}
    with Path("/proc/meminfo").open(encoding="utf-8") as source:
        for line in source:
            name, rest = line.split(":", 1)
            if name in {"MemTotal", "MemAvailable"}:
                values[name] = int(rest.split()[0])
    return values["MemTotal"] - values["MemAvailable"]


def terminate_group(process: subprocess.Popen[bytes]) -> None:
    try:
        os.killpg(process.pid, signal.SIGTERM)
    except ProcessLookupError:
        return
    deadline = time.monotonic() + 5.0
    while process.poll() is None and time.monotonic() < deadline:
        time.sleep(0.1)
    if process.poll() is None:
        try:
            os.killpg(process.pid, signal.SIGKILL)
        except ProcessLookupError:
            pass


def run_supervised(
    command: list[str],
    log_path: Path,
    memory_threshold_kb: int,
    cwd: Path,
) -> None:
    log_path.parent.mkdir(parents=True, exist_ok=True)
    with log_path.open("ab") as log:
        log.write(("$ " + " ".join(command) + "\n").encode())
        log.flush()
        process = subprocess.Popen(
            command,
            cwd=cwd,
            stdout=log,
            stderr=subprocess.STDOUT,
            start_new_session=True,
        )
        try:
            while process.poll() is None:
                used = memory_used_kb()
                if used > memory_threshold_kb:
                    log.write(
                        f"campaign-abort memory_used_kb={used} "
                        f"threshold_kb={memory_threshold_kb}\n".encode()
                    )
                    log.flush()
                    terminate_group(process)
                    raise RuntimeError("whole-system memory threshold exceeded")
                time.sleep(2.0)
        except BaseException:
            if process.poll() is None:
                terminate_group(process)
            raise
        if process.returncode != 0:
            raise subprocess.CalledProcessError(process.returncode, command)


def phase(
    campaign_state_path: Path,
    state: dict[str, Any],
    name: str,
    command: list[str],
    log_path: Path,
    memory_threshold_kb: int,
    cwd: Path,
) -> None:
    if state["phases"].get(name) == "completed":
        print(f"campaign-resume skip={name}", flush=True)
        return
    state["phases"][name] = "running"
    state["active_phase"] = name
    write_json_atomic(campaign_state_path, state)
    print(f"campaign-phase-start name={name}", flush=True)
    started = time.monotonic()
    run_supervised(command, log_path, memory_threshold_kb, cwd)
    state["phases"][name] = "completed"
    state["phase_elapsed_seconds"][name] = round(time.monotonic() - started, 3)
    state["active_phase"] = None
    write_json_atomic(campaign_state_path, state)
    print(
        f"campaign-phase-finish name={name} "
        f"elapsed={state['phase_elapsed_seconds'][name]}s",
        flush=True,
    )


def clone_database(source: Path, destination: Path) -> None:
    if destination.exists():
        return
    destination.parent.mkdir(parents=True, exist_ok=True)
    temporary = destination.with_suffix(".sqlite.tmp")
    subprocess.run(
        ["cp", "--reflink=auto", "--sparse=always", str(source), str(temporary)],
        check=True,
    )
    temporary.replace(destination)


def aggregate_command(
    event_path: Path,
    database: Path,
    round_dir: Path,
    cache: Path,
    label: str,
) -> list[str]:
    output_dir = round_dir / "corpus"
    return [
        sys.executable,
        "scripts/build_credited_status_map_dataset.py",
        "--input",
        str(event_path),
        "--out-prefix",
        str(output_dir / f"status-map-{label}"),
        "--sqlite",
        str(database),
        "--summary",
        str(output_dir / f"status-map-{label}.summary.json"),
        "--canonical-cache",
        str(cache),
        "--canonicalization-jobs",
        "8",
        "--canonicalization-timeout-seconds",
        "60",
        "--append-sqlite",
        "--keep-sqlite",
        "--skip-row-export",
        "--no-scan-run-quality",
    ]


def export_oracle_command(
    database: Path,
    cache: Path,
    output: Path,
    base_oracle: Path,
) -> list[str]:
    return [
        sys.executable,
        "scripts/export_utility_guidance_lookup.py",
        "--sqlite",
        str(database),
        "--canonical-cache",
        str(cache),
        "--base-oracle",
        str(base_oracle),
        "--output",
        str(output),
    ]


def validate_oracle(path: Path) -> None:
    seen: set[str] = set()
    with path.open(encoding="utf-8") as source:
        for line_number, line in enumerate(source, 1):
            row = json.loads(line)
            key = row.get("problem_key")
            if not isinstance(key, str):
                raise RuntimeError(
                    f"oracle row {line_number} has no string problem_key: {path}"
                )
            if key in seen:
                raise RuntimeError(
                    f"duplicate oracle problem_key {key!r} on line {line_number}: {path}"
                )
            seen.add(key)


def summarize_root(round_dir: Path) -> dict[str, Any]:
    summary_path = round_dir / "root" / "summary.jsonl"
    counts: Counter[str] = Counter()
    elapsed_ms = event_bytes = cpf_bytes = 0
    categories: dict[str, Counter[str]] = {}
    if not summary_path.exists():
        return {}
    with summary_path.open(encoding="utf-8") as source:
        for line in source:
            row = json.loads(line)
            category = str(row.get("category", "unknown"))
            bucket = categories.setdefault(category, Counter())
            status = str(row.get("status", "unknown"))
            outcome = str(row.get("outcome", "unknown"))
            counts[f"status:{status}"] += 1
            counts[f"outcome:{outcome}"] += 1
            bucket[f"status:{status}"] += 1
            bucket[f"outcome:{outcome}"] += 1
            if row.get("certified"):
                counts["certified"] += 1
                bucket["certified"] += 1
            elapsed_ms += int(row.get("elapsed_ms") or 0)
            event_bytes += int(row.get("event_bytes") or 0)
            cpf_bytes += int(row.get("cpf_bytes") or 0)
    return {
        "counts": dict(counts),
        "categories": {name: dict(value) for name, value in sorted(categories.items())},
        "aggregate_elapsed_ms": elapsed_ms,
        "event_bytes": event_bytes,
        "cpf_bytes": cpf_bytes,
    }


def summarize_canonical(round_dir: Path) -> dict[str, Any]:
    database = round_dir / "canonical" / "campaign.sqlite"
    if not database.exists():
        return {}
    import sqlite3

    connection = sqlite3.connect(database)
    outcomes = dict(
        connection.execute(
            "SELECT outcome, COUNT(*) FROM trials GROUP BY outcome"
        ).fetchall()
    )
    selections = dict(
        connection.execute(
            "SELECT selection, COUNT(*) FROM trials GROUP BY selection"
        ).fetchall()
    )
    completed = connection.execute(
        "SELECT COUNT(*) FROM trials WHERE state='completed'"
    ).fetchone()[0]
    connection.close()
    return {
        "completed": completed,
        "outcomes": outcomes,
        "selections": selections,
    }


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--campaign-dir",
        type=Path,
        default=Path("target/data-campaign/oracle-two-round-20260724"),
    )
    parser.add_argument("--source-db", type=Path, default=DEFAULT_SOURCE_DB)
    parser.add_argument("--source-oracle", type=Path, default=DEFAULT_SOURCE_ORACLE)
    parser.add_argument("--canonical-cache", type=Path, default=DEFAULT_CACHE)
    parser.add_argument("--category-root", type=Path, action="append")
    parser.add_argument("--ferrum", type=Path, default=Path("target/release/ferrum"))
    parser.add_argument("--ceta", type=Path, default=Path(".tools/ceta-relative-bounds"))
    parser.add_argument(
        "--fragment-ceta",
        type=Path,
        default=Path(".tools/ceta-relative-bounds.bin"),
    )
    parser.add_argument("--jobs", type=int, default=8)
    parser.add_argument("--rayon-threads", type=int, default=8)
    parser.add_argument("--memory-threshold-kb", type=int, default=2 * 1024 * 1024 * 1024)
    parser.add_argument("--root-limit", type=int)
    parser.add_argument("--canonical-limit", type=int)
    parser.add_argument(
        "--canonical-run-problem-like",
        help="restrict canonical probes to states observed in matching run-problem keys",
    )
    parser.add_argument(
        "--canonical-problem-level",
        choices=("top-level", "context-sensitive", "dependency-pair"),
        help="restrict canonical probes by CPF subproblem level",
    )
    parser.add_argument(
        "--canonical-current-round-only",
        action="store_true",
        help="probe only states observed by the current round's root run",
    )
    parser.add_argument(
        "--frequent-explore",
        type=int,
        default=1,
        help="total distinct-family probes on frequent uncovered canonical states",
    )
    parser.add_argument(
        "--frequency-threshold",
        type=int,
        default=100,
        help="minimum observation count for frequent-state exploration",
    )
    parser.add_argument(
        "--extra-exploration-budget",
        type=int,
        default=0,
        help="per-round cap on canonical probes beyond baseline exploration",
    )
    parser.add_argument(
        "--prior-ledger",
        type=Path,
        help="canonical trial ledger preceding the first configured round",
    )
    parser.add_argument(
        "--round",
        action="append",
        metavar="LABEL,MULTIPLIER,OUTER_SECONDS,PROBE_MS,SEED",
        help="campaign round; may be repeated (defaults to the original R00/R01 pair)",
    )
    args = parser.parse_args()
    if args.jobs < 1 or args.jobs > 64:
        parser.error("--jobs must be between 1 and 64")
    if args.rayon_threads < 1 or args.jobs * args.rayon_threads > 128:
        parser.error("jobs * rayon-threads must be at most 128")
    if (
        args.frequent_explore < 1
        or args.frequency_threshold < 0
        or args.extra_exploration_budget < 0
    ):
        parser.error("adaptive canonical exploration settings must be non-negative")

    cwd = Path.cwd().resolve()
    campaign_dir = args.campaign_dir.resolve()
    source_db = args.source_db.resolve()
    source_oracle = args.source_oracle.resolve()
    cache = args.canonical_cache.resolve()
    ferrum = args.ferrum.resolve()
    ceta = args.ceta.resolve()
    fragment_ceta = args.fragment_ceta.resolve()
    initial_prior_ledger = (
        args.prior_ledger.resolve() if args.prior_ledger is not None else None
    )
    roots = tuple(path.resolve() for path in (args.category_root or DEFAULT_ROOTS))
    required_paths = [source_db, source_oracle, cache, ferrum, ceta, fragment_ceta, *roots]
    if initial_prior_ledger is not None:
        required_paths.append(initial_prior_ledger)
    for required in required_paths:
        if not required.exists():
            parser.error(f"required campaign input does not exist: {required}")

    campaign_dir.mkdir(parents=True, exist_ok=True)
    state_path = campaign_dir / "campaign.json"
    if state_path.exists():
        state = json.loads(state_path.read_text(encoding="utf-8"))
    else:
        state = {
            "schema": "ferrum.iterative-data-campaign.v1",
            "created_at": time.strftime("%Y-%m-%dT%H:%M:%S%z"),
            "source_database": str(source_db),
            "source_oracle": str(source_oracle),
            "canonical_cache": str(cache),
            "category_roots": [str(root) for root in roots],
            "jobs": args.jobs,
            "rayon_threads": args.rayon_threads,
            "memory_threshold_kb": args.memory_threshold_kb,
            "phases": {},
            "phase_elapsed_seconds": {},
            "active_phase": None,
        }
        write_json_atomic(state_path, state)

    round_settings: tuple[tuple[str, float, float, int, int], ...]
    if args.round:
        parsed_rounds: list[tuple[str, float, float, int, int]] = []
        for raw_round in args.round:
            fields = raw_round.split(",")
            if len(fields) != 5:
                parser.error(
                    "--round requires LABEL,MULTIPLIER,OUTER_SECONDS,PROBE_MS,SEED"
                )
            label, raw_multiplier, raw_outer, raw_probe, raw_seed = fields
            try:
                setting = (
                    label,
                    float(raw_multiplier),
                    float(raw_outer),
                    int(raw_probe),
                    int(raw_seed),
                )
            except ValueError:
                parser.error(f"invalid numeric field in --round {raw_round!r}")
            if not label or setting[1] <= 0 or setting[2] <= 0 or setting[3] <= 0:
                parser.error(f"invalid --round {raw_round!r}")
            parsed_rounds.append(setting)
        if len({setting[0] for setting in parsed_rounds}) != len(parsed_rounds):
            parser.error("--round labels must be unique")
        round_settings = tuple(parsed_rounds)
    else:
        round_settings = (
            ("r00", 0.25, 75.0, 250, 2400),
            ("r01", 0.50, 150.0, 500, 2401),
        )

    previous_db = source_db
    previous_oracle = source_oracle
    previous_ledger: Path | None = initial_prior_ledger
    for label, multiplier, outer_timeout, probe_timeout_ms, seed in round_settings:
        round_dir = campaign_dir / "rounds" / label
        root_dir = round_dir / "root"
        corpus_dir = round_dir / "corpus"
        canonical_dir = round_dir / "canonical"
        root_database = corpus_dir / f"aggregate-{label}-root.sqlite"
        database = corpus_dir / f"aggregate-{label}-final.sqlite"
        root_oracle = corpus_dir / f"oracle-{label}-root.jsonl"
        final_oracle = corpus_dir / f"oracle-{label}-final.jsonl"
        validate_oracle(previous_oracle)

        root_command = [
            sys.executable,
            "scripts/collect_processor_events.py",
            "--ferrum",
            str(ferrum),
            "--run-dir",
            str(root_dir),
            "--jobs",
            str(args.jobs),
            "--rayon-threads",
            str(args.rayon_threads),
            "--timeout",
            str(outer_timeout),
            "--timeout-multiplier",
            str(multiplier),
            "--utility-guidance-manifest",
            str(previous_oracle),
            "--ceta",
            str(ceta),
            "--memory-threshold-kb",
            str(args.memory_threshold_kb),
            "--seed",
            str(seed),
            "--progress-every",
            "1",
        ]
        for root in roots:
            root_command.extend(["--category-root", str(root)])
        if args.root_limit is not None:
            root_command.extend(["--limit", str(args.root_limit)])
        phase(
            state_path,
            state,
            f"{label}.root",
            root_command,
            round_dir / "root.log",
            args.memory_threshold_kb,
            cwd,
        )
        aggregate_root_phase = f"{label}.aggregate-root"
        if state["phases"].get(aggregate_root_phase) != "completed":
            if root_database.exists():
                root_database.unlink()
            clone_database(previous_db, root_database)
        phase(
            state_path,
            state,
            aggregate_root_phase,
            aggregate_command(
                root_dir / "all.processor-events.jsonl",
                root_database,
                round_dir,
                cache,
                f"{label}-root",
            ),
            round_dir / "aggregate-root.log",
            args.memory_threshold_kb,
            cwd,
        )
        phase(
            state_path,
            state,
            f"{label}.oracle-root",
            export_oracle_command(
                root_database,
                cache,
                root_oracle,
                previous_oracle,
            ),
            round_dir / "oracle-root.log",
            args.memory_threshold_kb,
            cwd,
        )

        canonical_command = [
            sys.executable,
            "scripts/run_canonical_processor_campaign.py",
            "--source-db",
            str(root_database),
            "--run-dir",
            str(canonical_dir),
            "--ferrum",
            str(ferrum),
            "--ceta",
            str(ceta),
            "--fragment-ceta",
            str(fragment_ceta),
            "--jobs",
            str(args.jobs),
            "--rayon-threads",
            str(args.rayon_threads),
            "--exploit",
            "0",
            "--tighten",
            "2",
            "--explore",
            "1",
            "--frequent-explore",
            str(args.frequent_explore),
            "--frequency-threshold",
            str(args.frequency_threshold),
            "--extra-exploration-budget",
            str(args.extra_exploration_budget),
            "--timeout-ms",
            str(probe_timeout_ms),
            "--outer-grace",
            "2",
            "--seed",
            str(seed),
            "--progress-every",
            "10",
        ]
        if previous_ledger is not None:
            canonical_command.extend(["--prior-ledger", str(previous_ledger)])
        if args.canonical_run_problem_like is not None:
            canonical_command.extend(
                ["--run-problem-like", args.canonical_run_problem_like]
            )
        if args.canonical_problem_level is not None:
            canonical_command.extend(
                ["--problem-level", args.canonical_problem_level]
            )
        if args.canonical_current_round_only:
            canonical_command.extend(
                ["--run-problem-prefix", str(root_dir.resolve())]
            )
        if args.canonical_limit is not None:
            canonical_command.extend(["--limit", str(args.canonical_limit)])
        phase(
            state_path,
            state,
            f"{label}.canonical",
            canonical_command,
            round_dir / "canonical.log",
            args.memory_threshold_kb,
            cwd,
        )
        aggregate_canonical_phase = f"{label}.aggregate-canonical"
        if state["phases"].get(aggregate_canonical_phase) != "completed":
            if database.exists():
                database.unlink()
            clone_database(root_database, database)
        phase(
            state_path,
            state,
            aggregate_canonical_phase,
            aggregate_command(
                canonical_dir / "processor-events.jsonl",
                database,
                round_dir,
                cache,
                f"{label}-final",
            ),
            round_dir / "aggregate-canonical.log",
            args.memory_threshold_kb,
            cwd,
        )
        phase(
            state_path,
            state,
            f"{label}.oracle-final",
            export_oracle_command(
                database,
                cache,
                final_oracle,
                root_oracle,
            ),
            round_dir / "oracle-final.log",
            args.memory_threshold_kb,
            cwd,
        )
        summary = {
            "round": label,
            "timeout_multiplier": multiplier,
            "outer_timeout_seconds": outer_timeout,
            "canonical_timeout_ms": probe_timeout_ms,
            "starting_oracle": str(previous_oracle),
            "database": str(database),
            "final_oracle": str(final_oracle),
            "root": summarize_root(round_dir),
            "canonical": summarize_canonical(round_dir),
        }
        write_json_atomic(round_dir / "round-summary.json", summary)
        previous_db = database
        previous_oracle = final_oracle
        previous_ledger = canonical_dir / "campaign.sqlite"

    state["completed_at"] = time.strftime("%Y-%m-%dT%H:%M:%S%z")
    state["final_database"] = str(previous_db)
    state["final_oracle"] = str(previous_oracle)
    write_json_atomic(state_path, state)
    print(json.dumps({"campaign": str(campaign_dir), "status": "completed"}), flush=True)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
