import tempfile
from pathlib import Path
import unittest

from atomic_artifact import atomic_text_output


class AtomicArtifactTests(unittest.TestCase):
    def test_new_output_is_invisible_until_complete(self):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / 'oracle.jsonl'
            with atomic_text_output(path, exclusive=True) as stream:
                stream.write('first\n')
                stream.flush()
                self.assertFalse(path.exists())
                stream.write('second\n')
            self.assertEqual(path.read_text(), 'first\nsecond\n')
            self.assertEqual(list(Path(directory).iterdir()), [path])

    def test_failed_write_preserves_previous_output(self):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / 'oracle.jsonl'
            path.write_text('previous\n')
            with self.assertRaisesRegex(RuntimeError, 'interrupted'):
                with atomic_text_output(path) as stream:
                    stream.write('incomplete')
                    self.assertEqual(path.read_text(), 'previous\n')
                    raise RuntimeError('interrupted')
            self.assertEqual(path.read_text(), 'previous\n')
            self.assertEqual(list(Path(directory).iterdir()), [path])

    def test_exclusive_publication_does_not_overwrite(self):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / 'oracle.jsonl'
            path.write_text('previous\n')
            with self.assertRaises(FileExistsError):
                with atomic_text_output(path, exclusive=True) as stream:
                    stream.write('replacement\n')
            self.assertEqual(path.read_text(), 'previous\n')
            self.assertEqual(list(Path(directory).iterdir()), [path])

    def test_success_replaces_only_at_publication(self):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / 'oracle.jsonl'
            path.write_text('previous\n')
            with atomic_text_output(path) as stream:
                stream.write('replacement\n')
                self.assertEqual(path.read_text(), 'previous\n')
            self.assertEqual(path.read_text(), 'replacement\n')


if __name__ == '__main__':
    unittest.main()
