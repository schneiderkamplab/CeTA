import json
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path


SCRIPT = Path(__file__).with_name("extract_certified_runtime_path_events.py")


def event(key, outcome, *, level="dependency-pair", children=()):
    return {
        "level": level,
        "outcome": outcome,
        "processor": "graph" if outcome == "transformed" else "size-change",
        "input": {"problem_key": key, "cpf": f"<dpInput>{key}</dpInput>"},
        "witness": {
            "residuals": [
                {"problem_key": child, "cpf": f"<dpInput>{child}</dpInput>"}
                for child in children
            ]
        },
    }


class CertifiedRuntimePathTest(unittest.TestCase):
    def run_case(self, tmp: Path, rows):
        events = tmp / "events.jsonl"
        proof = tmp / "proof.xml"
        ceta = tmp / "ceta"
        output = tmp / "selected.jsonl"
        manifest = tmp / "manifest.jsonl"
        events.write_text("".join(json.dumps(row) + "\n" for row in rows))
        proof.write_text("<certificationProblem />")
        ceta.write_text("#!/bin/sh\necho CERTIFIED\n")
        ceta.chmod(0o755)
        checked = subprocess.run(
            [
                sys.executable,
                str(SCRIPT),
                "--events",
                str(events),
                "--proof",
                str(proof),
                "--ceta",
                str(ceta),
                "--output",
                str(output),
                "--certified-manifest-output",
                str(manifest),
            ],
            text=True,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
        )
        return checked, output, manifest

    def test_extracts_complete_unambiguous_causal_tree(self):
        with tempfile.TemporaryDirectory() as raw_tmp:
            root = event(
                "root", "transformed", level="top-level", children=("a", "b")
            )
            a = event("a", "solved")
            a["input"]["cpf"] = None
            no_op = event("a", "transformed", children=("a",))
            checked, output, manifest = self.run_case(
                Path(raw_tmp),
                [
                    root,
                    no_op,
                    a,
                    event("b", "solved"),
                ],
            )
            self.assertEqual(checked.returncode, 0, checked.stdout)
            rows = [json.loads(line) for line in output.read_text().splitlines()]
            self.assertEqual(
                {row["input"]["problem_key"] for row in rows}, {"root", "a", "b"}
            )
            self.assertTrue(
                all(row["credit"]["status"] == "proof-path-certified" for row in rows)
            )
            self.assertEqual(len(manifest.read_text().splitlines()), 3)

    def test_rejects_open_residual(self):
        with tempfile.TemporaryDirectory() as raw_tmp:
            checked, _, _ = self.run_case(
                Path(raw_tmp),
                [event("root", "transformed", level="top-level", children=("missing",))],
            )
            self.assertNotEqual(checked.returncode, 0)
            self.assertIn("open residual", checked.stdout)

    def test_excludes_successful_abandoned_branch(self):
        with tempfile.TemporaryDirectory() as raw_tmp:
            checked, output, _ = self.run_case(
                Path(raw_tmp),
                [
                    event("root", "solved", level="top-level"),
                    event("abandoned", "solved"),
                ],
            )
            self.assertEqual(checked.returncode, 0, checked.stdout)
            rows = [json.loads(line) for line in output.read_text().splitlines()]
            self.assertEqual([row["input"]["problem_key"] for row in rows], ["root"])

    def test_rejects_two_completed_continuations_for_one_state(self):
        with tempfile.TemporaryDirectory() as raw_tmp:
            first = event("root", "solved", level="top-level")
            second = event("root", "solved", level="top-level")
            second["processor"] = "subterm"
            checked, _, _ = self.run_case(Path(raw_tmp), [first, second])
            self.assertNotEqual(checked.returncode, 0)
            self.assertIn("ambiguous completed", checked.stdout)


if __name__ == "__main__":
    unittest.main()
