#!/usr/bin/env python3
"""Export a CPF-shaped version of the subproof training JSONL dataset.

This script consumes ``subproofs.jsonl.gz`` and writes a new dataset whose
``input.problem_xml`` and ``output_xml`` are CPF-style XML fragments.

For original/normalized CPF rows the CPF fragments are preserved. For normalized
AProVE text rows, the benchmark is resolved to a local TPDB-ARI file when
possible, the ARI problem is converted to CPF ``<input><trsInput>...``, and the
AProVE text step/removal summary is converted to a CPF-shaped processor
fragment.
"""

from __future__ import annotations

import argparse
import gzip
import hashlib
import json
import re
import sys
import xml.etree.ElementTree as ET
from copy import deepcopy
from pathlib import Path
from typing import Any


TRS_CATEGORY_MAP = {
    "TRS Standard": "TRS_Standard",
    "TRS Standard Certifying": "TRS_Standard",
    "TRS_Standard": "TRS_Standard",
    "TRS Innermost": "TRS_Innermost",
    "TRS Innermost Certifying": "TRS_Innermost",
    "TRS_Innermost": "TRS_Innermost",
    "TRS Outermost": "TRS_Outermost",
    "TRS_Outermost": "TRS_Outermost",
    "TRS Relative": "TRS_Relative",
    "TRS Relative Certifying": "TRS_Relative",
    "TRS_Relative": "TRS_Relative",
    "SRS Standard": "SRS_Standard",
    "SRS Standard Certifying": "SRS_Standard",
    "SRS_Standard": "SRS_Standard",
    "SRS Relative": "SRS_Relative",
    "SRS_Relative": "SRS_Relative",
}

PROCESSOR_TO_CPF = {
    "DependencyPairsProof": "dpTrans",
    "DependencyGraphProof": "depGraphProc",
    "UsableRulesProof": "usableRulesProc",
    "RuleRemovalProof": "ruleRemoval",
    "ReductionPairProof": "redPairProc",
    "QReductionProof": "redPairProc",
    "QDPOrderProof": "redPairProc",
    "QDPSizeChangeProof": "sizeChangeProc",
    "SizeChangeProof": "sizeChangeProc",
    "SubtermCriterionProof": "sizeChangeProc",
    "InstantiationProof": "instantiationProc",
    "ForwardInstantiationProof": "forwardInstantiationProc",
    "NarrowingProof": "narrowingProc",
    "LoopProof": "loop",
}


def local_name(tag: str) -> str:
    return tag.rsplit("}", 1)[-1]


def open_input(path: Path):
    return gzip.open(path, "rt", encoding="utf-8") if path.suffix == ".gz" else path.open("r", encoding="utf-8")


def open_output(path: Path):
    path.parent.mkdir(parents=True, exist_ok=True)
    return gzip.open(path, "wt", encoding="utf-8") if path.suffix == ".gz" else path.open("w", encoding="utf-8")


def xml_string(elem: ET.Element) -> str:
    return ET.tostring(elem, encoding="unicode", short_empty_elements=True)


def add_text(parent: ET.Element, tag: str, text: str | None) -> ET.Element:
    elem = ET.SubElement(parent, tag)
    if text is not None:
        elem.text = text
    return elem


def tokenize_sexpr(text: str) -> list[str]:
    tokens: list[str] = []
    current = []
    in_string = False
    escaped = False
    for raw_line in text.splitlines():
        line = raw_line
        if not in_string and line.lstrip().startswith(";"):
            continue
        i = 0
        while i < len(line):
            ch = line[i]
            if in_string:
                current.append(ch)
                if escaped:
                    escaped = False
                elif ch == "\\":
                    escaped = True
                elif ch == '"':
                    tokens.append("".join(current))
                    current = []
                    in_string = False
                i += 1
                continue
            if ch == ";":
                break
            if ch.isspace():
                if current:
                    tokens.append("".join(current))
                    current = []
            elif ch in "()":
                if current:
                    tokens.append("".join(current))
                    current = []
                tokens.append(ch)
            elif ch == '"':
                if current:
                    tokens.append("".join(current))
                    current = []
                current = ['"']
                in_string = True
            else:
                current.append(ch)
            i += 1
        if current and not in_string:
            tokens.append("".join(current))
            current = []
    return tokens


def parse_forms(tokens: list[str]) -> list[Any]:
    index = 0

    def parse_one() -> Any:
        nonlocal index
        if index >= len(tokens):
            raise ValueError("unexpected end of tokens")
        token = tokens[index]
        index += 1
        if token == "(":
            items = []
            while index < len(tokens) and tokens[index] != ")":
                items.append(parse_one())
            if index >= len(tokens):
                raise ValueError("missing ')'")
            index += 1
            return items
        if token == ")":
            raise ValueError("unexpected ')'")
        if len(token) >= 2 and token[0] == '"' and token[-1] == '"':
            return token[1:-1]
        return token

    forms = []
    while index < len(tokens):
        forms.append(parse_one())
    return forms


def parse_ari(path: Path) -> dict[str, Any]:
    forms = parse_forms(tokenize_sexpr(path.read_text(errors="replace")))
    funs: dict[str, int] = {}
    strict_rules = []
    relative_rules = []
    fmt = None
    for form in forms:
        if not isinstance(form, list) or not form:
            continue
        head = form[0]
        if head == "format" and len(form) > 1:
            fmt = form[1]
        elif head == "fun" and len(form) >= 3:
            funs[str(form[1])] = int(form[2])
        elif head == "rule" and len(form) >= 3:
            cost_zero = ":cost" in form and "0" in form[form.index(":cost") + 1 : form.index(":cost") + 2]
            target = relative_rules if cost_zero else strict_rules
            target.append((form[1], form[2]))
    return {"format": fmt, "funs": funs, "rules": strict_rules, "relative_rules": relative_rules}


def atom_to_term(atom: str, funs: dict[str, int]) -> ET.Element:
    if atom in funs and funs[atom] == 0:
        app = ET.Element("funapp")
        add_text(app, "name", atom)
        return app
    var = ET.Element("var")
    var.text = atom
    return var


def ari_term_to_cpf(term: Any, funs: dict[str, int]) -> ET.Element:
    if isinstance(term, str):
        return atom_to_term(term, funs)
    if not isinstance(term, list) or not term:
        raise ValueError(f"bad term: {term!r}")
    symbol = str(term[0])
    app = ET.Element("funapp")
    add_text(app, "name", symbol)
    for arg in term[1:]:
        arg_elem = ET.SubElement(app, "arg")
        arg_elem.append(ari_term_to_cpf(arg, funs))
    return app


def append_rule(parent: ET.Element, lhs: Any, rhs: Any, funs: dict[str, int]) -> None:
    rule = ET.SubElement(parent, "rule")
    lhs_elem = ET.SubElement(rule, "lhs")
    lhs_elem.append(ari_term_to_cpf(lhs, funs))
    rhs_elem = ET.SubElement(rule, "rhs")
    rhs_elem.append(ari_term_to_cpf(rhs, funs))


def ari_to_cpf_input(path: Path, category: str) -> str:
    parsed = parse_ari(path)
    root = ET.Element("input")
    trs_input = ET.SubElement(root, "trsInput")
    trs = ET.SubElement(trs_input, "trs")
    rules = ET.SubElement(trs, "rules")
    for lhs, rhs in parsed["rules"]:
        append_rule(rules, lhs, rhs, parsed["funs"])
    if "Innermost" in category or "innermost" in category:
        strategy = ET.SubElement(trs_input, "strategy")
        ET.SubElement(strategy, "innermost")
    elif "Outermost" in category or "outermost" in category:
        strategy = ET.SubElement(trs_input, "strategy")
        ET.SubElement(strategy, "outermost")
    if parsed["relative_rules"]:
        rel = ET.SubElement(trs_input, "relativeRules")
        rel_rules = ET.SubElement(rel, "rules")
        for lhs, rhs in parsed["relative_rules"]:
            append_rule(rel_rules, lhs, rhs, parsed["funs"])
    return xml_string(root)


def category_dir(category: str) -> str | None:
    if category in TRS_CATEGORY_MAP:
        return TRS_CATEGORY_MAP[category]
    return TRS_CATEGORY_MAP.get(category.replace("_", " "))


def resolve_ari(tpdb_ari: Path, category: str, benchmark: str) -> Path | None:
    cat = category_dir(category)
    candidates: list[Path] = []
    if benchmark.endswith(".ari"):
        rel = Path(benchmark)
        candidates.append(tpdb_ari / rel)
        if cat and rel.parts and rel.parts[0] != cat:
            candidates.append(tpdb_ari / cat / Path(*rel.parts[1:]))
    if "tpdb-8.0/TRS/" in benchmark and benchmark.endswith(".xml"):
        rest = benchmark.split("tpdb-8.0/TRS/", 1)[1]
        ari_rest = str(Path(rest).with_suffix(".ari"))
        if cat:
            candidates.append(tpdb_ari / cat / ari_rest)
        for prefix in ("TRS_Standard", "TRS_Innermost", "TRS_Outermost", "TRS_Relative", "SRS_Standard", "SRS_Relative"):
            candidates.append(tpdb_ari / prefix / ari_rest)
    for candidate in candidates:
        if candidate.exists():
            return candidate
    return None


def parse_xml(text: str | None) -> ET.Element | None:
    if not text:
        return None
    try:
        return ET.fromstring(text.encode())
    except ET.ParseError:
        return None


def processor_name_to_cpf(name: str) -> str:
    if name in PROCESSOR_TO_CPF:
        return PROCESSOR_TO_CPF[name]
    lower = name.lower()
    if "dependencygraph" in lower:
        return "depGraphProc"
    if "usable" in lower:
        return "usableRulesProc"
    if "sizechange" in lower or "subterm" in lower:
        return "sizeChangeProc"
    if "narrow" in lower:
        return "narrowingProc"
    if "instantiation" in lower:
        return "instantiationProc"
    if "rule" in lower and "remov" in lower:
        return "ruleRemoval"
    if "pair" in lower or "order" in lower or "polynomial" in lower or "matrix" in lower:
        return "redPairProc"
    return "proofStep"


def aprove_step_to_cpf(elem: ET.Element) -> ET.Element:
    processor = ""
    for child in elem:
        if local_name(child.tag) == "processor":
            processor = "".join(child.itertext()).strip()
            break
    out = ET.Element(processor_name_to_cpf(processor), {"source": "aprove-text"})
    meta = ET.SubElement(out, "processorText")
    for key, value in elem.attrib.items():
        add_text(meta, key, value)
    for child in elem:
        copied = deepcopy(child)
        meta.append(copied)
    return out


RULE_LINE_RE = re.compile(r"^\s*(.+?)\s*->\s*(.+?)\s*$")


def parse_simple_term_text(text: str) -> ET.Element:
    text = text.strip()
    if not text:
        var = ET.Element("var")
        var.text = "_"
        return var
    if "(" not in text:
        app = ET.Element("funapp")
        add_text(app, "name", text)
        return app
    name, rest = text.split("(", 1)
    app = ET.Element("funapp")
    add_text(app, "name", name.strip())
    inner = rest.rsplit(")", 1)[0]
    depth = 0
    start = 0
    args = []
    for i, ch in enumerate(inner):
        if ch == "(":
            depth += 1
        elif ch == ")":
            depth -= 1
        elif ch == "," and depth == 0:
            args.append(inner[start:i])
            start = i + 1
    if inner.strip():
        args.append(inner[start:])
    for arg in args:
        arg_elem = ET.SubElement(app, "arg")
        arg_elem.append(parse_simple_term_text(arg))
    return app


def removed_to_cpf(elem: ET.Element) -> ET.Element:
    kind = elem.attrib.get("kind", "rules")
    out = ET.Element("ruleRemoval" if kind == "rules" else "redPairProc", {"source": "aprove-text"})
    rules = ET.SubElement(out, "rules")
    for child in elem:
        if local_name(child.tag) != "item":
            continue
        text = "".join(child.itertext()).strip()
        match = RULE_LINE_RE.match(text)
        if not match:
            raw = ET.SubElement(out, "processorText")
            raw.text = text
            continue
        rule = ET.SubElement(rules, "rule")
        lhs = ET.SubElement(rule, "lhs")
        lhs.append(parse_simple_term_text(match.group(1)))
        rhs = ET.SubElement(rule, "rhs")
        rhs.append(parse_simple_term_text(match.group(2)))
    return out


def normalize_output_xml(row: dict[str, Any]) -> tuple[str, str]:
    root = parse_xml(row.get("output_xml"))
    if root is None:
        fallback = ET.Element("proofStep", {"source": "unparseable"})
        fallback.text = row.get("output_xml") or ""
        return xml_string(fallback), "wrapped-unparseable-output"
    if row["source"].get("normalizer") == "aprove-text":
        tag = local_name(root.tag)
        if tag == "step":
            processor = ""
            for child in root:
                if local_name(child.tag) == "processor":
                    processor = "".join(child.itertext()).strip()
                    break
            status = "aprove-obligation-step" if processor.startswith("Obligation:") else "aprove-step-to-cpf"
            return xml_string(aprove_step_to_cpf(root)), status
        if tag == "removed":
            return xml_string(removed_to_cpf(root)), "aprove-removed-to-cpf"
        return xml_string(root), "aprove-output-preserved"
    return xml_string(root), "cpf-output-preserved"


def normalize_context_xml(text: str | None) -> str | None:
    root = parse_xml(text)
    if root is None:
        return text
    return xml_string(root)


def normalize_problem_xml(row: dict[str, Any], tpdb_ari: Path) -> tuple[str | None, str, str | None]:
    problem_xml = row.get("input", {}).get("problem_xml")
    root = parse_xml(problem_xml)
    if root is not None and local_name(root.tag) == "input":
        return xml_string(root), "cpf-input-preserved", None
    ari = resolve_ari(tpdb_ari, row["metadata"]["category"], row["metadata"]["benchmark"])
    if ari is not None:
        return ari_to_cpf_input(ari, row["metadata"]["category"]), "ari-to-cpf-input", str(ari)
    return problem_xml, "input-unresolved", None


def row_id(row: dict[str, Any]) -> str:
    material = {
        "source": row.get("source"),
        "metadata": row.get("metadata"),
        "input": row.get("input"),
        "output_xml": row.get("output_xml"),
        "cpf_normalization": row.get("cpf_normalization"),
    }
    return hashlib.sha256(json.dumps(material, sort_keys=True, separators=(",", ":")).encode()).hexdigest()


def normalize_row(row: dict[str, Any], tpdb_ari: Path) -> tuple[dict[str, Any], str, str]:
    out = deepcopy(row)
    out["source_row_id"] = row["id"]
    problem, input_status, ari_path = normalize_problem_xml(row, tpdb_ari)
    output, output_status = normalize_output_xml(row)
    out["input"]["problem_xml"] = problem
    out["input"]["local_context_xml"] = normalize_context_xml(row.get("input", {}).get("local_context_xml"))
    out["output_xml"] = output
    out["cpf_normalization"] = {
        "input_status": input_status,
        "output_status": output_status,
    }
    if ari_path is not None:
        out["cpf_normalization"]["ari_path"] = ari_path
    out["id"] = row_id(out)
    return out, input_status, output_status


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--input", type=Path, default=Path("target/termcomp-proof-corpus/training/subproofs.jsonl.gz"))
    parser.add_argument("--output", type=Path, default=Path("target/termcomp-proof-corpus/training/subproofs.cpf.jsonl.gz"))
    parser.add_argument("--summary", type=Path, default=Path("target/termcomp-proof-corpus/training/subproofs.cpf.summary.json"))
    parser.add_argument("--tpdb-ari", type=Path, default=Path("/work/dfm/festschrift/TPDB-ARI"))
    parser.add_argument("--progress-interval", type=int, default=25000)
    parser.add_argument("--limit", type=int)
    args = parser.parse_args()

    rows = 0
    input_counts: dict[str, int] = {}
    output_counts: dict[str, int] = {}
    with open_input(args.input) as source, open_output(args.output) as sink:
        for line in source:
            row = json.loads(line)
            normalized, input_status, output_status = normalize_row(row, args.tpdb_ari)
            sink.write(json.dumps(normalized, sort_keys=True, separators=(",", ":")) + "\n")
            rows += 1
            input_counts[input_status] = input_counts.get(input_status, 0) + 1
            output_counts[output_status] = output_counts.get(output_status, 0) + 1
            if args.progress_interval > 0 and rows % args.progress_interval == 0:
                print(json.dumps({"event": "progress", "rows": rows, "input_counts": input_counts, "output_counts": output_counts}, sort_keys=True), flush=True)
            if args.limit is not None and rows >= args.limit:
                break
    summary = {
        "input": str(args.input),
        "output": str(args.output),
        "rows_written": rows,
        "input_counts": dict(sorted(input_counts.items())),
        "output_counts": dict(sorted(output_counts.items())),
    }
    args.summary.write_text(json.dumps(summary, indent=2, sort_keys=True))
    print(json.dumps(summary, sort_keys=True))
    return 0


if __name__ == "__main__":
    sys.setrecursionlimit(max(sys.getrecursionlimit(), 200_000))
    raise SystemExit(main())
