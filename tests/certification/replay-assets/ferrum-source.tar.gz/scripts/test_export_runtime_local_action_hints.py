import unittest
from export_runtime_local_action_hints import build


class LocalHintTests(unittest.TestCase):
    def test_runtime_success_is_not_independent_certification(self):
        rows = build([dict(input=dict(problem_key='k'), strategy_atom='graph', outcome='solved')])
        self.assertEqual(len(rows), 1)
        action = rows[0]['possible'][0]
        self.assertEqual(action['candidate'], 'graph')
        self.assertEqual(action['certified_count'], 0)
        self.assertEqual(action['solved_count'], 0)
        self.assertEqual(action['status'], 'transformed_weak')

    def test_composites_fail_closed(self):
        with self.assertRaises(ValueError):
            build([dict(input=dict(problem_key='k'), strategy_atom='pipeline(graph; subterm)', outcome='solved')])


if __name__ == '__main__':
    unittest.main()
