#!/usr/bin/env python3
"""Normalize proof-corpus artefacts into XML-oriented training-data views.

This script does not overwrite the original TermCOMP artefacts. It writes
normalized XML files under `target/termcomp-proof-corpus/normalized/` and
records them in a `normalized_proofs` SQLite table.
"""

from __future__ import annotations

import argparse
import hashlib
import html
import json
import re
import sqlite3
import time
import xml.etree.ElementTree as ET
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from collect_termcomp_proofs import extract_features, safe_name


TIMING_PREFIX = re.compile(r"^\s*(?:\d+(?:\.\d+)?|\?)\s*/\s*(?:\d+(?:\.\d+)?|\?)\s*\t?")
STEP_RE = re.compile(r"^\((\d+)\)\s+([A-Za-z0-9_+./:-]+)(?:\s+\[([^,\]]+)(?:,\s*([^\]]+))?\])?")
PROOF_OF_RE = re.compile(r"^proof of\s+(.+)$", re.IGNORECASE)
POL_RE = re.compile(r"^\s*POL\((.+?)\)\s*=\s*(.+?)\s*$")
DETAIL_STEP_RE = re.compile(r"^\((\d+)\)\s+([A-Za-z0-9_+./:-]+)\s+\([^)]+\)\s*$")
SECTION_RE = re.compile(r"^\(\d+\)(?:\s|$)")


def aprove_processor_detail(processor: str, block: str) -> str | None:
    """Classify only proof details with a direct Ferrum strategy meaning."""
    lowered = block.lower()
    if processor == "TransformationProof":
        if "forward instantiat" in lowered:
            return "forward-instantiation"
        if "instantiat" in lowered:
            return "instantiation"
        if "narrow" in lowered:
            return "narrowing"
        if "rewrit" in lowered:
            return "rewriting"
    if processor in {"CSRRRRProof", "QTRSRRRProof"}:
        if "polynomial interpretation" in lowered:
            return "polynomial"
        if "matrix interpretation" in lowered:
            return "matrix"
        if "knuth-bendix" in lowered or "[kbo]" in lowered:
            return "kbo"
        if "quasi precedence:" in lowered:
            return "path-order"
        if "recursive path order" in lowered or "[rpo]" in lowered:
            return "path-order"
        if "lexicographic path order" in lowered or "[lpo]" in lowered:
            return "path-order"
    return None


@dataclass(frozen=True)
class ProofRow:
    year: int
    category: str
    benchmark: str
    tool: str
    result: str
    certification: str
    proof_url: str
    local_path: str
    detected_format: str


def ensure_table(conn: sqlite3.Connection) -> None:
    conn.execute(
        """
        create table if not exists normalized_proofs (
            proof_url text not null,
            normalizer text not null,
            normalized_format text not null,
            normalized_path text not null,
            sha256 text not null,
            bytes integer not null,
            extracted_json text not null,
            normalized_at real not null,
            primary key (proof_url, normalizer)
        )
        """
    )


def load_rows(conn: sqlite3.Connection, where: str, limit: int | None) -> list[ProofRow]:
    query = f"""
        select year, category, benchmark, tool, result, certification,
               proof_url, local_path, detected_format
        from proofs
        where download_error is null
          and local_path != ''
          and ({where})
        order by year, category, tool, benchmark
    """
    if limit is not None:
        query += " limit ?"
        raw = conn.execute(query, (limit,)).fetchall()
    else:
        raw = conn.execute(query).fetchall()
    return [ProofRow(*row) for row in raw]


def already_done(conn: sqlite3.Connection, normalizer: str) -> set[str]:
    return {
        row[0]
        for row in conn.execute(
            "select proof_url from normalized_proofs where normalizer = ?",
            (normalizer,),
        )
    }


def strip_timing_prefixes(text: str) -> str:
    return "\n".join(TIMING_PREFIX.sub("", line) for line in text.splitlines())


def xml_payload_from_text(text: str) -> str | None:
    stripped = strip_timing_prefixes(text)
    problem_start = stripped.find("<certificationProblem")
    normalized_start = stripped.find("<ferrumTextProofNormalization")
    root_candidates = [
        index for index in (problem_start, normalized_start) if index >= 0
    ]
    if not root_candidates:
        return None
    root_start = min(root_candidates)

    # Some StarExec wrappers print an XML declaration of their own before the
    # actual CPF declaration.  Starting at the first declaration used to leave
    # two declarations in the payload; the attempted repair then truncated the
    # proof to the first 54 bytes.  Bind the declaration to the selected root:
    # the last real declaration before it belongs to the embedded document.
    # ``<?xml-stylesheet ...?>`` deliberately does not match this expression.
    declarations = list(re.finditer(r"<\?xml(?:\s|$)", stripped[:root_start]))
    start = declarations[-1].start() if declarations else root_start
    xml_text = stripped[start:].strip()

    root_name = (
        "certificationProblem"
        if root_start == problem_start
        else "ferrumTextProofNormalization"
    )
    closing = f"</{root_name}>"
    end = xml_text.find(closing)
    if end >= 0:
        xml_text = xml_text[: end + len(closing)]
    return xml_text


def parse_xml_summary(xml_text: str) -> dict[str, Any]:
    _, features = extract_features(xml_text.encode())
    try:
        root = ET.fromstring(xml_text.encode())
        tags: dict[str, int] = {}
        for elem in root.iter():
            tag = elem.tag.rsplit("}", 1)[-1]
            tags[tag] = tags.get(tag, 0) + 1
        features["all_tag_counts"] = tags
    except ET.ParseError as error:
        features["xml_parse_error"] = str(error)
    return features


def dest_path(root: Path, row: ProofRow, normalizer: str) -> Path:
    digest = hashlib.sha256(row.proof_url.encode()).hexdigest()[:12]
    return (
        root
        / "normalized"
        / normalizer
        / f"Y{row.year}"
        / safe_name(row.category)
        / row.certification
        / safe_name(row.tool)
        / safe_name(row.benchmark)
        / f"{digest}.xml"
    )


def write_normalized(
    conn: sqlite3.Connection,
    root: Path,
    row: ProofRow,
    normalizer: str,
    normalized_format: str,
    data: bytes,
    extracted: dict[str, Any],
) -> None:
    path = dest_path(root, row, normalizer)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes(data)
    # Preserve the benchmark identity next to the normalized certificate.
    # Downstream recursive CPF extraction must match archived states to live
    # runtime states of the same root; a digest-only filename is not a safe
    # substitute for that identity.
    path.with_name("result.json").write_text(
        json.dumps(
            {
                "problem_id": row.benchmark,
                "category": row.category,
                "status": row.result,
                "certification": row.certification,
                "source_tool": row.tool,
            },
            indent=2,
            sort_keys=True,
        )
        + "\n",
        encoding="utf-8",
    )
    conn.execute(
        """
        insert or replace into normalized_proofs (
            proof_url, normalizer, normalized_format, normalized_path,
            sha256, bytes, extracted_json, normalized_at
        ) values (?, ?, ?, ?, ?, ?, ?, ?)
        """,
        (
            row.proof_url,
            normalizer,
            normalized_format,
            str(path),
            hashlib.sha256(data).hexdigest(),
            len(data),
            json.dumps(extracted, sort_keys=True),
            time.time(),
        ),
    )


def read_text_limited(path: str, max_bytes: int | None) -> str | None:
    file_path = Path(path)
    try:
        if max_bytes is not None and file_path.stat().st_size > max_bytes:
            return None
        return file_path.read_text(errors="replace")
    except OSError:
        return None


def report_progress(label: str, scanned: int, normalized: int, skipped_large: int, low_yield: int, total: int) -> None:
    print(
        json.dumps(
            {
                "phase": label,
                "scanned": scanned,
                "total": total,
                "normalized": normalized,
                "skipped_large": skipped_large,
                "low_yield": low_yield,
                "remaining": max(0, total - scanned),
            },
            sort_keys=True,
        ),
        flush=True,
    )


def normalize_xml_in_text(
    conn: sqlite3.Connection,
    root: Path,
    rows: list[ProofRow],
    resume: bool,
    max_text_bytes: int | None,
    progress_interval: int,
) -> int:
    done = already_done(conn, "xml-in-text") if resume else set()
    completed = 0
    scanned = 0
    skipped_large = 0
    low_yield = 0
    for row in rows:
        scanned += 1
        if row.proof_url in done:
            continue
        text = read_text_limited(row.local_path, max_text_bytes)
        if text is None:
            skipped_large += 1
            if scanned % progress_interval == 0:
                report_progress("xml-in-text", scanned, completed, skipped_large, low_yield, len(rows))
            continue
        xml_text = xml_payload_from_text(text)
        if xml_text is None:
            low_yield += 1
            if scanned % progress_interval == 0:
                report_progress("xml-in-text", scanned, completed, skipped_large, low_yield, len(rows))
            continue
        extracted = parse_xml_summary(xml_text)
        extracted["source_detected_format"] = row.detected_format
        extracted["source_first_line"] = text.splitlines()[0].strip() if text.splitlines() else ""
        write_normalized(
            conn,
            root,
            row,
            "xml-in-text",
            "cpf-or-xml-normalized",
            xml_text.encode(),
            extracted,
        )
        completed += 1
        if scanned % progress_interval == 0:
            conn.commit()
            report_progress("xml-in-text", scanned, completed, skipped_large, low_yield, len(rows))
    conn.commit()
    report_progress("xml-in-text", scanned, completed, skipped_large, low_yield, len(rows))
    return completed


def add_text(parent: ET.Element, tag: str, text: str | None) -> ET.Element:
    elem = ET.SubElement(parent, tag)
    if text is not None:
        elem.text = text
    return elem


def parse_aprove_text(text: str) -> dict[str, Any]:
    text = clean_aprove_text(text)
    lines = text.splitlines()
    result = lines[0].strip() if lines else ""
    steps: list[dict[str, str]] = []
    polynomials: list[dict[str, Any]] = []
    removed_rule_blocks: list[dict[str, Any]] = []
    current_step: str | None = None
    proof_of: str | None = None

    details: dict[str, str] = {}
    detail_headers = [
        (index, match)
        for index, line in enumerate(lines)
        if (match := DETAIL_STEP_RE.match(line.strip())) is not None
    ]
    for start, match in detail_headers:
        end = next(
            (
                index
                for index in range(start + 1, len(lines))
                if SECTION_RE.match(lines[index].strip())
            ),
            len(lines),
        )
        detail = aprove_processor_detail(
            match.group(2), "\n".join(lines[start + 1 : end])
        )
        if detail is not None:
            details[match.group(1)] = detail

    index = 0
    while index < len(lines):
        line = lines[index]
        proof_match = PROOF_OF_RE.match(line.strip())
        if proof_match:
            proof_of = proof_match.group(1).strip()
        step_match = STEP_RE.match(line.strip())
        if step_match:
            current_step = step_match.group(1)
            steps.append(
                {
                    "index": step_match.group(1),
                    "processor": step_match.group(2),
                    "classification": (step_match.group(3) or "").strip(),
                    "time": (step_match.group(4) or "").strip(),
                    "detail": details.get(step_match.group(1), ""),
                }
            )
        if "Polynomial interpretation" in line:
            order_kind = line.strip().removesuffix(":")
            interpretations = []
            index += 1
            while index < len(lines) and not lines[index].strip():
                index += 1
            while index < len(lines):
                poly_line = lines[index]
                if not poly_line.strip():
                    break
                match = POL_RE.match(poly_line)
                if match:
                    interpretations.append({"symbol": match.group(1).strip(), "polynomial": match.group(2).strip()})
                index += 1
            if interpretations:
                polynomials.append({"step": current_step, "kind": order_kind, "interpretations": interpretations})
        if "following rules can be removed" in line or "following dependency pairs can be removed" in line:
            block_kind = "dependency-pairs" if "dependency pairs" in line else "rules"
            removed = []
            index += 1
            while index < len(lines):
                candidate = lines[index].strip()
                if not candidate or candidate.startswith("---"):
                    break
                if "->" in candidate:
                    removed.append(candidate)
                index += 1
            removed_rule_blocks.append({"step": current_step, "kind": block_kind, "items": removed})
        index += 1
    return {
        "result": result,
        "proof_of": proof_of,
        "steps": steps,
        "polynomial_interpretations": polynomials,
        "removed_blocks": removed_rule_blocks,
    }


def clean_aprove_text(text: str) -> str:
    text = strip_timing_prefixes(text)
    text = re.sub(r"(?i)<br\s*/?>", "\n", text)
    text = re.sub(r"(?i)</p\s*>", "\n", text)
    text = re.sub(r"(?i)</blockquote\s*>", "\n", text)
    text = re.sub(r"(?i)<li\s*>", "\n", text)
    text = re.sub(r"<[^>]+>", "", text)
    text = html.unescape(text)
    text = text.replace("→", "->")
    return text


def aprove_summary_to_xml(row: ProofRow, summary: dict[str, Any]) -> bytes:
    root = ET.Element("ferrumTextProofNormalization", {"sourceToolFamily": "AProVE"})
    meta = ET.SubElement(root, "metadata")
    for tag, value in [
        ("year", str(row.year)),
        ("category", row.category),
        ("benchmark", row.benchmark),
        ("tool", row.tool),
        ("result", row.result),
        ("certification", row.certification),
        ("proofUrl", row.proof_url),
        ("proofOf", summary.get("proof_of") or ""),
    ]:
        add_text(meta, tag, value)
    steps = ET.SubElement(root, "processorSequence")
    for step in summary["steps"]:
        elem = ET.SubElement(steps, "step", {"index": step["index"]})
        add_text(elem, "processor", step["processor"])
        add_text(elem, "classification", step["classification"])
        add_text(elem, "time", step["time"])
        add_text(elem, "detail", step.get("detail", ""))
    orders = ET.SubElement(root, "orders")
    for order in summary["polynomial_interpretations"]:
        order_elem = ET.SubElement(orders, "polynomialInterpretation")
        if order.get("step"):
            order_elem.set("step", order["step"])
        add_text(order_elem, "kind", order["kind"])
        for interpretation in order["interpretations"]:
            interp = ET.SubElement(order_elem, "interpretation")
            add_text(interp, "symbol", interpretation["symbol"])
            add_text(interp, "polynomial", interpretation["polynomial"])
    removals = ET.SubElement(root, "removals")
    for block in summary["removed_blocks"]:
        block_elem = ET.SubElement(removals, "removed", {"kind": block["kind"]})
        if block.get("step"):
            block_elem.set("step", block["step"])
        for item in block["items"]:
            add_text(block_elem, "item", item)
    ET.indent(root, space="  ")
    return ET.tostring(root, encoding="utf-8", xml_declaration=True)


def normalize_aprove_text(
    conn: sqlite3.Connection,
    root: Path,
    rows: list[ProofRow],
    resume: bool,
    max_text_bytes: int | None,
    progress_interval: int,
) -> int:
    done = already_done(conn, "aprove-text") if resume else set()
    completed = 0
    scanned = 0
    skipped_large = 0
    low_yield = 0
    for row in rows:
        scanned += 1
        if row.proof_url in done:
            continue
        text = read_text_limited(row.local_path, max_text_bytes)
        if text is None:
            skipped_large += 1
            if scanned % progress_interval == 0:
                report_progress("aprove-text", scanned, completed, skipped_large, low_yield, len(rows))
            continue
        if not text.lstrip().startswith(("YES", "NO")):
            low_yield += 1
            if scanned % progress_interval == 0:
                report_progress("aprove-text", scanned, completed, skipped_large, low_yield, len(rows))
            continue
        summary = parse_aprove_text(text)
        if not summary["steps"] and not summary["polynomial_interpretations"] and not summary["removed_blocks"]:
            low_yield += 1
            if scanned % progress_interval == 0:
                report_progress("aprove-text", scanned, completed, skipped_large, low_yield, len(rows))
            continue
        xml_data = aprove_summary_to_xml(row, summary)
        extracted = {
            "processor_counts": {},
            "steps": len(summary["steps"]),
            "polynomial_interpretations": len(summary["polynomial_interpretations"]),
            "removed_blocks": len(summary["removed_blocks"]),
            "proof_of": summary.get("proof_of"),
        }
        for step in summary["steps"]:
            processor = step["processor"]
            extracted["processor_counts"][processor] = extracted["processor_counts"].get(processor, 0) + 1
        write_normalized(
            conn,
            root,
            row,
            "aprove-text",
            "ferrum-aprove-text-xml",
            xml_data,
            extracted,
        )
        completed += 1
        if scanned % progress_interval == 0:
            conn.commit()
            report_progress("aprove-text", scanned, completed, skipped_large, low_yield, len(rows))
    conn.commit()
    report_progress("aprove-text", scanned, completed, skipped_large, low_yield, len(rows))
    return completed


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--out", type=Path, default=Path("target/termcomp-proof-corpus"))
    parser.add_argument("--mode", choices=["xml-in-text", "aprove-text", "all"], default="all")
    parser.add_argument("--limit", type=int)
    parser.add_argument(
        "--benchmark",
        action="append",
        default=[],
        help=(
            "normalize only this exact benchmark identity; repeat for a "
            "focused proof-recovery batch"
        ),
    )
    parser.add_argument("--no-resume", action="store_true")
    parser.add_argument(
        "--max-text-bytes",
        type=int,
        default=8_000_000,
        help="skip text artefacts larger than this many bytes; use 0 for no limit",
    )
    parser.add_argument("--progress-interval", type=int, default=1000)
    args = parser.parse_args()

    db_path = args.out / "proofs.sqlite"
    conn = sqlite3.connect(db_path, timeout=60)
    ensure_table(conn)
    resume = not args.no_resume
    max_text_bytes = None if args.max_text_bytes == 0 else args.max_text_bytes
    wanted_benchmarks = set(args.benchmark)

    def selected_rows(where: str) -> list[ProofRow]:
        rows = load_rows(
            conn,
            where,
            None if wanted_benchmarks else args.limit,
        )
        if wanted_benchmarks:
            rows = [row for row in rows if row.benchmark in wanted_benchmarks]
            if args.limit is not None:
                rows = rows[: args.limit]
        return rows

    result: dict[str, int] = {}
    if args.mode in {"xml-in-text", "all"}:
        rows = selected_rows(
            "detected_format in ('text', 'cpf-or-xml') and certification = 'certified'"
        )
        result["xml_in_text"] = normalize_xml_in_text(
            conn,
            args.out,
            rows,
            resume,
            max_text_bytes,
            max(1, args.progress_interval),
        )
    if args.mode in {"aprove-text", "all"}:
        rows = selected_rows(
            "detected_format = 'text' and tool like 'AProVE%'"
        )
        result["aprove_text"] = normalize_aprove_text(
            conn,
            args.out,
            rows,
            resume,
            max_text_bytes,
            max(1, args.progress_interval),
        )
    print(json.dumps(result, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
