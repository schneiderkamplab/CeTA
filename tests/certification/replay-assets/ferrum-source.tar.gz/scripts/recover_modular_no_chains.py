#!/usr/bin/env python3
"""Recover source-proof chains by repeatedly binding newly exposed live states.

No processor fallback and no composite proof actions are allowed. Each wave
uses a root-local gated oracle; completed source and regenerated proofs are
checked with CeTA. This repairs representation aliases, not proof validity.
"""
import argparse
from concurrent.futures import ThreadPoolExecutor, as_completed
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
from build_modular_proof_overlay import build, retain_tested_guidance
from termcomp_trs_compare import run_one, result_to_dict
from retain_certified_replay_hints import direct_forward_atom


def add_direct_forward_hints(rows):
    """Change search policy only; new proposals remain weak until replayed."""
    witnesses = {r['witness_id']: r['candidate'] for r in rows if 'witness_id' in r}
    added = {}
    for row in rows:
        if 'problem_key' not in row:
            continue
        priority = []
        existing = {i.get('candidate_ref') for b in ('prefer', 'possible') for i in row.get(b, [])}
        for item in [*row.get('prefer', []), *row.get('possible', [])]:
            atom = item.get('candidate') or witnesses.get(item.get('candidate_ref'), '')
            direct = direct_forward_atom(atom)
            if direct == atom:
                continue
            digest = hashlib.sha256(direct.encode()).hexdigest()
            priority.append(digest)
            if digest in existing:
                continue
            existing.add(digest)
            if digest not in witnesses:
                added[digest] = direct
            row.setdefault('possible', []).append(dict(candidate_ref=digest,
                status='transformed_weak', utility_score=100, attempts=1,
                certified_count=0, solved_count=0, transformed_count=1,
                failed_count=0, timeout_count=0, best_elapsed_ms=0))
        row['replay_order'] = list(dict.fromkeys([*priority, *row.get('replay_order', [])]))
    rows.extend(dict(schema='ferrum.utility-guidance.witness.v1', witness_id=k, candidate=v)
                for k, v in added.items())
    return rows


def main():
    p = argparse.ArgumentParser(description=__doc__)
    for name in ('baseline', 'replay-details', 'output', 'ferrum', 'ceta'):
        p.add_argument('--' + name, type=Path, required=True)
    p.add_argument('--jobs', type=int, default=8)
    p.add_argument('--waves', type=int, default=32)
    p.add_argument('--direct-forward', action='store_true',
                   help='Propose existing deterministic forward reconstruction as weak local hints')
    p.add_argument('--retry-results', type=Path)
    p.add_argument('--runtime-root', type=Path, action='append', default=[],
                   help='Additional recorded runtime states to bind, without importing their outcomes')
    p.add_argument('--root', action='append', default=[],
                   help='Restrict recovery to these normalized root names or path suffixes')
    args = p.parse_args()
    args.output.mkdir(parents=True, exist_ok=False)
    os.environ['FERRUM_DP_LLM_NO_FALLBACK'] = '1'
    os.environ['RAYON_NUM_THREADS'] = '2'
    baseline = {}
    for category in ('standard', 'innermost', 'csr'):
        baseline.update({r['path']: r for r in json.loads((args.baseline/category/'details.json').read_text())})
    replay_text = args.replay_details.read_text()
    replay_rows = (list(map(json.loads, replay_text.splitlines()))
                   if args.replay_details.suffix == '.jsonl' else json.loads(replay_text))
    tasks = [r for r in replay_rows if not r['certified']]
    if args.root:
        tasks = [r for r in tasks if any(r['path'].endswith(name) for name in args.root)]
    if args.retry_results:
        failed = {r['path']: r for r in map(json.loads, args.retry_results.read_text().splitlines()) if r['returncode']}
        tasks = [r for r in tasks if r['path'].split('TPDB-ARI/', 1)[-1] in failed]
        for row in tasks:
            prior = Path(failed[row['path'].split('TPDB-ARI/', 1)[-1]]['output'])
            root = prior.parent if prior.name.startswith('wave-') else prior
            row['recovery_runtime_root'] = str(root)
            details = sorted(root.glob('wave-*/details.json'))
            if details:
                row['artifact_dir'] = json.loads(details[-1].read_text())[0]['artifact_dir']

    def run(row):
        name = row['path'].split('TPDB-ARI/', 1)[-1]
        output = args.output/Path(name).with_suffix('')
        output.mkdir(parents=True)
        source = baseline[row['path']]['artifact_dir']
        previous = []
        previous_keys = None
        runtime = Path(row['artifact_dir'])
        for wave in range(args.waves):
            local = output/f'wave-{wave:02}'
            local.mkdir()
            command = [sys.executable, 'scripts/extract_local_cpf_oracle_events.py',
                       '--root', source, '--runtime-root', str(runtime),
                       '--runtime-root', str(output), '--ferrum-canonicalizer', str(args.ferrum),
                       '--ceta', str(args.ceta), '--exclude-complete-proof-atoms',
                       '--proof-chain-only', '--runtime-explicit-states-only',
                       '--output', str(local/'events.jsonl'),
                       '--certified-manifest-output', str(local/'manifest.jsonl')]
            if row.get('recovery_runtime_root'):
                command.extend(['--runtime-root', row['recovery_runtime_root']])
            for runtime_root in args.runtime_root:
                command.extend(['--runtime-root', str(runtime_root)])
            with (local/'extract.log').open('x') as log:
                try:
                    done = subprocess.run(command, stdout=log, stderr=subprocess.STDOUT, timeout=180)
                except subprocess.TimeoutExpired:
                    return dict(path=name, returncode=124, output=str(local), reason='extraction timeout')
            if done.returncode:
                return dict(path=name, returncode=done.returncode, output=str(local), reason='extraction failed')
            with (local/'events.jsonl').open() as events, (local/'manifest.jsonl').open() as gates:
                rows = build(map(json.loads, events), map(json.loads, gates))
            rows = retain_tested_guidance(rows, previous)
            # Prefer this source chain's newly bound state-local actions.
            for r in rows:
                if 'problem_key' in r:
                    r['replay_order'] = [x.get('candidate_ref') or hashlib.sha256(x['candidate'].encode()).hexdigest()
                                         for x in r.get('prefer', [])]
            if args.direct_forward:
                rows = add_direct_forward_hints(rows)
            keys = {(r['problem_key'], tuple(r.get('replay_order', []))) for r in rows if 'problem_key' in r}
            oracle = local/'oracle.jsonl'
            with oracle.open('x') as stream:
                for r in rows:
                    print(json.dumps(r, separators=(',', ':')), file=stream)
            if keys == previous_keys:
                return dict(path=name, returncode=1, output=str(local), reason='no new state-local guidance')
            previous, previous_keys = rows, keys
            path = Path(row['path'])
            category = row['category']
            root = Path(*path.parts[:path.parts.index(category)+1])
            allowance = 1200 if category == 'TRS_Innermost' else 300
            result = run_one(args.ferrum, args.ceta, root, path, allowance + 5,
                             ['--strategy', f'timeout({allowance}s, fail)', '--utility-guidance-manifest',
                              str(oracle), '--no-top-level-llm'], True, local/'run')
            result = result_to_dict(category, result)
            (local/'details.json').write_text(json.dumps([result], indent=2))
            runtime = Path(result['artifact_dir'])
            print(json.dumps(dict(path=name, wave=wave, certified=result['certified'], status=result['status'])), flush=True)
            if result['certified'] and result['status'] == baseline[row['path']]['status']:
                cpf = runtime/'proof.cpf.xml'
                digest = hashlib.sha256(cpf.read_bytes()).hexdigest()
                for repeat in range(2):
                    checked = subprocess.run([str(args.ceta), str(cpf)], capture_output=True, text=True, timeout=60)
                    (local/f'recheck-{repeat}.log').write_text(checked.stdout + checked.stderr)
                    if checked.returncode or 'CERTIFIED' not in checked.stdout:
                        return dict(path=name, returncode=2, output=str(local), reason='independent recheck failed')
                if hashlib.sha256(cpf.read_bytes()).hexdigest() != digest:
                    return dict(path=name, returncode=2, output=str(local), reason='CPF changed')
                return dict(path=name, returncode=0, output=str(local), certified=True,
                            tested_guidance=str(oracle), tested_guidance_sha256=hashlib.sha256(oracle.read_bytes()).hexdigest(),
                            tested_events=str(runtime/'processor-events.jsonl'),
                            tested_events_sha256=hashlib.sha256((runtime/'processor-events.jsonl').read_bytes()).hexdigest(),
                            proof_sha256=digest, deterministic_rechecks=2)
        return dict(path=name, returncode=1, output=str(output), reason='wave ceiling')

    with ThreadPoolExecutor(max_workers=args.jobs) as pool, (args.output/'results.jsonl').open('x') as log:
        for future in as_completed([pool.submit(run, row) for row in tasks]):
            result = future.result()
            print(json.dumps(result), file=log, flush=True)
            print(json.dumps(result), flush=True)


if __name__ == '__main__':
    main()
