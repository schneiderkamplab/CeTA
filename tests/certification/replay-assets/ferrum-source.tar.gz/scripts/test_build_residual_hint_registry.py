import hashlib
import json
from pathlib import Path
import subprocess
import tempfile
import unittest


class ResidualHintRegistryTests(unittest.TestCase):
    def test_preserves_identity_and_context_without_positive_credit(self):
        with tempfile.TemporaryDirectory() as directory:
            base = Path(directory)
            state = base / 'state.cpf'
            cpf = '<dpInput><minimal>false</minimal><usableRules><rules/></usableRules></dpInput>'
            state.write_text(cpf)
            source = base / 'events.jsonl'
            source.write_text(json.dumps(dict(problem_id='Group/example.ari', category='TRS_Standard')))
            inventory = base / 'inventory.json'
            inventory.write_text(json.dumps(dict(records=[dict(input=str(state),
                sha256=hashlib.sha256(cpf.encode()).hexdigest(),
                origins=[dict(source_events=str(source))])])))
            replay = base / 'replay.jsonl'
            replay.write_text(json.dumps(dict(input=str(state))))
            output = base / 'registry.jsonl'
            command = ['python3', str(Path(__file__).with_name('build_residual_hint_registry.py')),
                       '--inventory', str(inventory), '--replay', str(replay), '--output', str(output)]
            subprocess.run(command, check=True, capture_output=True)
            row = json.loads(output.read_text())
            self.assertEqual(row['input']['cpf'], cpf)
            self.assertEqual(row['problem_id'], 'Group/example.ari')
            self.assertEqual(row['outcome'], 'failed')
            self.assertEqual(row['provenance']['credit'], 'none')
            state.write_text(cpf.replace('false', 'true'))
            command[-1] = str(base / 'changed.jsonl')
            self.assertNotEqual(subprocess.run(command, capture_output=True).returncode, 0)


if __name__ == '__main__':
    unittest.main()
