#!/usr/bin/env python3
"""Freeze certified Matchbounds/RFC evidence as a reproducible file list."""

from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path
import xml.etree.ElementTree as ET


PROCESSOR_TAGS = (
    "bounds",
    "relativeBounds",
    "rfcBounds",
    "rfcAutomatonClosedBounds",
    "rfcRelativeBounds",
    "rfcAutomatonClosedRelativeBounds",
    "rfcMatchboxRelativeBounds",
    "rfcNativeMatchboxRelativeBounds",
)


def local_name(tag: str) -> str:
    return tag.rsplit("}", 1)[-1]


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("corpus", type=Path)
    parser.add_argument("--tpdb-root", type=Path, required=True)
    parser.add_argument("--manifest", type=Path, required=True)
    parser.add_argument("--file-list", type=Path, required=True)
    return parser.parse_args()


def main() -> int:
    args = parse_args()
    tpdb_root = args.tpdb_root.resolve()
    repository_root = Path(__file__).resolve().parent.parent
    rows: list[dict[str, object]] = []

    for result_path in sorted(args.corpus.glob("*/result.json")):
        result = json.loads(result_path.read_text())
        if not result.get("certified"):
            continue
        proof_path = result_path.with_name("proof.normalized.cpf3.xml")
        if not proof_path.is_file():
            raise SystemExit(f"missing normalized proof: {proof_path}")
        problem = Path(result["problem"]).resolve()
        try:
            problem_rel = problem.relative_to(tpdb_root)
        except ValueError as error:
            raise SystemExit(f"problem outside TPDB root: {problem}") from error

        proof_bytes = proof_path.read_bytes()
        root = ET.fromstring(proof_bytes)
        tags = {local_name(node.tag) for node in root.iter()}
        processors = [tag for tag in PROCESSOR_TAGS if tag in tags]
        if not any(tag != "bounds" for tag in processors):
            raise SystemExit(f"proof has no relative/RFC processor: {proof_path}")
        source_cpf = result.get("source_cpf")
        if source_cpf:
            source_path = Path(str(source_cpf))
            if source_path.is_absolute():
                try:
                    source_cpf = source_path.relative_to(repository_root).as_posix()
                except ValueError:
                    source_cpf = source_path.as_posix()

        rows.append(
            {
                "artifact": result_path.parent.name,
                "problem": problem_rel.as_posix(),
                "processors": processors,
                "proof_sha256": hashlib.sha256(proof_bytes).hexdigest(),
                "source_cpf": source_cpf,
            }
        )

    rows.sort(key=lambda row: str(row["problem"]))
    problems = sorted({str(row["problem"]) for row in rows})

    args.manifest.parent.mkdir(parents=True, exist_ok=True)
    args.file_list.parent.mkdir(parents=True, exist_ok=True)
    args.manifest.write_text(
        "".join(json.dumps(row, sort_keys=True) + "\n" for row in rows)
    )
    args.file_list.write_text("".join(problem + "\n" for problem in problems))
    print(f"wrote {len(rows)} certificates for {len(problems)} examples")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
