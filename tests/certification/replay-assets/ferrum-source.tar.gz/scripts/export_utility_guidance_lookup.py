#!/usr/bin/env python3
"""Export ranked positive and negative strategy evidence per canonical CPF state.

The output is a compact JSONL runtime manifest.  Canonical problem hashes are
included directly; raw CPF hashes from the persistent canonicalization cache
are emitted as aliases so live DP states can hit the same canonical record
without rerunning the expensive offline SMT canonicalizer.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import re
import sqlite3
from pathlib import Path

EXCLUDED = {
    "llm",
    "llm-guidance",
    "nontermination-search",
    "termination",
    "utility-guidance",
}
SCHEMA = "ferrum.utility-guidance.v2"
WITNESS_SCHEMA = "ferrum.utility-guidance.witness.v1"
EVIDENCE_GROUPS = ("prefer", "possible", "avoid", "timeout")
PORTABLE_EXACT_PREFIXES = (
    "exact-dp(",
    "exact-dp-loop(",
    "exact-dp-nontermination-proof(",
    "exact-red-pair(",
    "exact-graph(",
    "exact-usable-rules(",
    "exact-trs-proof(",
    "exact-trs-nontermination-proof(",
)


def exact_witness_id(candidate: str) -> str:
    return hashlib.sha256(candidate.encode("utf-8")).hexdigest()


def resolve_candidate_refs(row: dict, witnesses: dict[str, str]) -> None:
    for group in EVIDENCE_GROUPS:
        for item in row.get(group) or []:
            reference = item.pop("candidate_ref", None)
            if reference is None:
                continue
            try:
                item["candidate"] = witnesses[reference]
            except KeyError as error:
                raise ValueError(f"unknown exact-witness reference {reference!r}") from error


def candidate_is_executable_atomic(candidate: str) -> bool:
    """Reject schedulers, recipes, and retired spellings from runtime data.

    `dp` is intentionally retained: in the universal worklist it is the
    top-level dependency-pair transformation and returns an explicit DP
    residual.  It is no longer a recursive scheduler alias.

    Historical spelling conversion belongs in the one-shot oracle migration,
    not in the production exporter.  Every retained candidate therefore names
    exactly one currently executable processor.
    """
    return (
        candidate not in EXCLUDED
        and ";" not in candidate
        and not candidate.startswith(("choice(", "parallel(", "sequence("))
        and "-{-" not in candidate
    )


def candidate_evidence(database: Path) -> dict[str, dict]:
    connection = sqlite3.connect(database)
    connection.row_factory = sqlite3.Row
    evidence: dict[str, dict] = {}
    rows = connection.execute(
        """
        SELECT problem_key, candidate, best_status, utility_score, best_elapsed_ms,
               best_rank, attempts, solved_count, transformed_count, failed_count,
               timeout_count, certified_count, hard_negative_count
        FROM candidates
        ORDER BY problem_key, (certified_count > 0) DESC, utility_score DESC, best_rank DESC,
                 best_elapsed_ms IS NULL, best_elapsed_ms, candidate
        """
    )
    for row in rows:
        candidate_name = row["candidate"]
        if not candidate_is_executable_atomic(candidate_name):
            continue
        state = evidence.setdefault(
            row["problem_key"],
            {
                "prefer": [],
                "possible": [],
                "avoid": [],
                "timeout": [],
                "_seen": set(),
            },
        )
        if candidate_name in state["_seen"]:
            continue
        state["_seen"].add(candidate_name)
        candidate = {
            "candidate": candidate_name,
            "status": row["best_status"],
            "utility_score": row["utility_score"],
            "best_elapsed_ms": row["best_elapsed_ms"],
            "attempts": row["attempts"],
            "solved_count": row["solved_count"],
            "transformed_count": row["transformed_count"],
            "failed_count": row["failed_count"],
            "timeout_count": row["timeout_count"],
            "certified_count": row["certified_count"],
        }
        positive_is_certified = row["certified_count"] > 0
        if (
            row["best_status"] in {"solved", "transformed_strong"}
            and positive_is_certified
        ):
            state["prefer"].append(candidate)
        elif row["best_status"] == "transformed_weak":
            # Weak transformations are scheduling hints, never a claim that
            # the state is solved.  Exact assembly-required transitions may
            # therefore remain findable before their recursive children close;
            # they cannot enter `prefer` or contribute a certified result.
            state["possible"].append(candidate)
        elif row["best_status"] == "timeout":
            state["timeout"].append(candidate)
        elif row["best_status"] == "failed":
            state["avoid"].append(candidate)
    connection.close()
    for state in evidence.values():
        del state["_seen"]
    return {
        problem_key: state
        for problem_key, state in evidence.items()
        if any(state[group] for group in ("prefer", "possible", "avoid", "timeout"))
    }


def add_contextless_portable_exact_states(
    database: Path, evidence: dict[str, dict]
) -> int:
    """Index self-validating exact witnesses without Ferrum-only DP context.

    CPF proof nodes do not carry ``ferrumDpStateContext``.  In particular,
    pair-source provenance is reconstructed only by the live worklist and can
    distinguish several runtime children whose mathematical DP cores are
    isomorphic.  A generic processor must never cross that boundary, but the
    exact processors listed above carry their source obligation and revalidate
    it before applying.  Merge only those candidates under the canonical
    contextless core so each nested certified CPF state remains independently
    findable without broadcasting unrelated search atoms.
    """
    with sqlite3.connect(database) as connection:
        rows = list(connection.execute("SELECT problem_key, cpf FROM problems"))
    additions: dict[str, dict] = {}
    for problem_key, cpf in rows:
        state = evidence.get(problem_key)
        if state is None or "ferrumDpStateContext" not in cpf:
            continue
        portable = {
            group: [
                item
                for item in state[group]
                if item["candidate"].startswith(PORTABLE_EXACT_PREFIXES)
            ]
            for group in EVIDENCE_GROUPS
        }
        if not any(portable[group] for group in EVIDENCE_GROUPS):
            continue
        contextless = re.sub(
            r"[ \t]*<ferrumDpStateContext>.*?</ferrumDpStateContext>[ \t]*\n?",
            "",
            cpf,
            count=1,
            flags=re.DOTALL,
        )
        if contextless == cpf:
            continue
        key = hashlib.sha256(contextless.strip().encode("utf-8")).hexdigest()
        previous = additions.get(key) or evidence.get(key)
        additions[key] = (
            portable
            if previous is None
            else merged_state_evidence(previous, portable, preserve_left_order=True)
        )
    for key, state in additions.items():
        evidence[key] = state
    return len(additions)


def merged_state_evidence(
    left: dict, right: dict, *, preserve_left_order: bool = False
) -> dict:
    def identity(candidate: dict) -> str:
        value = candidate.get("candidate")
        if isinstance(value, str):
            return f"candidate:{value}"
        reference = candidate.get("candidate_ref")
        if isinstance(reference, str):
            return f"candidate-ref:{reference}"
        raise ValueError("oracle candidate has neither candidate nor candidate_ref")

    merged = {}
    for group in ("prefer", "possible", "avoid", "timeout"):
        by_candidate = {}
        for candidate in left[group] + right[group]:
            candidate_identity = identity(candidate)
            previous = by_candidate.get(candidate_identity)
            priority = (
                candidate.get("certified_count", 0) > 0,
                candidate["utility_score"],
                candidate["status"] in {"solved", "transformed_strong"},
                -(candidate["best_elapsed_ms"] or 2**63),
            )
            if previous is None:
                by_candidate[candidate_identity] = candidate
                continue
            previous_priority = (
                previous.get("certified_count", 0) > 0,
                previous["utility_score"],
                previous["status"] in {"solved", "transformed_strong"},
                -(previous["best_elapsed_ms"] or 2**63),
            )
            if priority > previous_priority:
                by_candidate[candidate_identity] = candidate
        if preserve_left_order:
            # A monotone oracle must not make a previously successful replay
            # unreachable merely because a later export observed another,
            # faster candidate for the same state.  Dictionary replacement
            # above retains the original insertion position while still
            # upgrading duplicate evidence.
            merged[group] = list(by_candidate.values())
        else:
            merged[group] = sorted(
                by_candidate.values(),
                key=lambda candidate: (
                    candidate.get("certified_count", 0) > 0,
                    candidate["utility_score"],
                    candidate["status"] in {"solved", "transformed_strong"},
                    -(candidate["best_elapsed_ms"] or 2**63),
                    identity(candidate),
                ),
                reverse=True,
            )
    return merged


def aliases(
    cache: Path, evidence: dict[str, dict]
) -> tuple[dict[str, tuple[str, str]], int]:
    connection = sqlite3.connect(cache)
    result: dict[str, tuple[str, str]] = {}
    merged_direct_keys = 0
    for raw_key, canonical_cpf, note in connection.execute(
        "SELECT raw_key, canonical_cpf, note FROM canonical_cpf_cache"
    ):
        if note is not None:
            continue
        canonical_key = hashlib.sha256(canonical_cpf.encode("utf-8")).hexdigest()
        if canonical_key not in evidence or raw_key == canonical_key:
            continue
        if raw_key in evidence:
            evidence[raw_key] = merged_state_evidence(
                evidence[raw_key],
                evidence[canonical_key],
                preserve_left_order=True,
            )
            merged_direct_keys += 1
        else:
            result[raw_key] = (canonical_key, "semantic")
    connection.close()
    return result, merged_direct_keys


def apply_explicit_aliases(
    path: Path | None,
    evidence: dict[str, dict],
    result: dict[str, tuple[str, str]],
    *,
    prefer_alias_evidence: bool = False,
) -> int:
    if path is None:
        return 0
    merged = 0
    with path.open(encoding="utf-8") as source:
        for line in source:
            row = json.loads(line)
            raw_key = row["raw_key"]
            canonical_key = row["canonical_problem_key"]
            seen = {raw_key}
            while canonical_key not in evidence and canonical_key in result:
                if canonical_key in seen:
                    canonical_key = ""
                    break
                seen.add(canonical_key)
                canonical_key = result[canonical_key][0]
            if canonical_key not in evidence or raw_key == canonical_key:
                continue
            if raw_key in evidence:
                evidence[raw_key] = (
                    merged_state_evidence(
                        evidence[canonical_key],
                        evidence[raw_key],
                        preserve_left_order=True,
                    )
                    if prefer_alias_evidence
                    else merged_state_evidence(
                        evidence[raw_key],
                        evidence[canonical_key],
                        preserve_left_order=True,
                    )
                )
                result.pop(raw_key, None)
                merged += 1
            else:
                alias_kind = row.get("alias_kind", "semantic")
                if alias_kind not in {"semantic", "structural"}:
                    raise ValueError(f"invalid alias_kind {alias_kind!r}")
                result[raw_key] = (canonical_key, alias_kind)
    return merged


def apply_dataset_aliases(
    path: Path,
    evidence: dict[str, dict],
    result: dict[str, tuple[str, str]],
    *,
    prefer_alias_evidence: bool = False,
) -> int:
    """Record lossless runtime/raw aliases as structural aliases.

    ``problem_aliases`` contains hashes of the event CPF itself, its
    whitespace-insensitive serialization, and live runtime serializations
    structurally matched to that event.  These are representation-preserving
    aliases, unlike aliases from the semantic canonicalization cache.  The
    typed runtime loader may therefore inherit representation-bound
    ``exact-*`` witnesses without physically copying the full evidence row.
    """
    with sqlite3.connect(path) as connection:
        tables = {
            row[0]
            for row in connection.execute(
                "SELECT name FROM sqlite_master WHERE type='table'"
            )
        }
        if "problem_aliases" not in tables:
            return 0
        rows = list(
            connection.execute(
                "SELECT raw_problem_key, problem_key FROM problem_aliases"
            )
        )
    merged = 0
    for raw_key, canonical_key in rows:
        if canonical_key not in evidence or raw_key == canonical_key:
            continue
        if raw_key in evidence:
            evidence[raw_key] = (
                merged_state_evidence(
                    evidence[canonical_key],
                    evidence[raw_key],
                    preserve_left_order=True,
                )
                if prefer_alias_evidence
                else merged_state_evidence(
                    evidence[raw_key],
                    evidence[canonical_key],
                    preserve_left_order=True,
                )
            )
            result.pop(raw_key, None)
        else:
            result[raw_key] = (canonical_key, "structural")
        merged += 1
    return merged


def merge_base_oracle(
    path: Path | None,
    evidence: dict[str, dict],
    *,
    prefer_incoming: bool = False,
) -> tuple[dict[str, tuple[str, str]], int]:
    if path is None:
        return {}, 0
    base_aliases: dict[str, tuple[str, str]] = {}
    witnesses: dict[str, str] = {}
    merged = 0
    with path.open(encoding="utf-8") as source:
        for line in source:
            row = json.loads(line)
            if row.get("schema") == WITNESS_SCHEMA:
                candidate = row["candidate"]
                identifier = row["witness_id"]
                if (
                    not candidate.startswith("exact-")
                    or identifier != exact_witness_id(candidate)
                ):
                    raise ValueError(f"invalid exact-witness definition {identifier!r}")
                previous = witnesses.setdefault(identifier, candidate)
                if previous != candidate:
                    raise ValueError(f"conflicting exact-witness definition {identifier!r}")
                continue
            resolve_candidate_refs(row, witnesses)
            problem_key = row["problem_key"]
            canonical_key = row.get("canonical_problem_key")
            if isinstance(canonical_key, str):
                base_aliases[problem_key] = (
                    canonical_key,
                    row.get("alias_kind", "semantic"),
                )
                continue
            state = {
                group: [
                    item
                    for item in (row.get(group) or [])
                    if candidate_is_executable_atomic(str(item.get("candidate", "")))
                ]
                for group in ("prefer", "possible", "avoid", "timeout")
            }
            if problem_key in evidence:
                incoming = evidence[problem_key]
                evidence[problem_key] = (
                    merged_state_evidence(
                        incoming,
                        state,
                        preserve_left_order=True,
                    )
                    if prefer_incoming
                    else merged_state_evidence(
                        state,
                        incoming,
                        preserve_left_order=True,
                    )
                )
                merged += 1
            else:
                evidence[problem_key] = state
    return base_aliases, merged


def retain_base_alias_evidence(
    base_aliases: dict[str, tuple[str, str]],
    evidence: dict[str, dict],
    raw_aliases: dict[str, tuple[str, str]],
) -> int:
    """Retain inherited positives when canonicalization changes for a raw CPF."""
    merged = 0
    for raw_key, (old_canonical_key, old_alias_kind) in base_aliases.items():
        current_alias = raw_aliases.get(raw_key)
        if current_alias is not None:
            current_canonical_key = current_alias[0]
            if (
                old_canonical_key in evidence
                and current_canonical_key in evidence
                and old_canonical_key != current_canonical_key
            ):
                evidence[current_canonical_key] = merged_state_evidence(
                    evidence[current_canonical_key],
                    evidence[old_canonical_key],
                    preserve_left_order=True,
                )
                merged += 1
            continue
        if old_canonical_key not in evidence or raw_key == old_canonical_key:
            continue
        if raw_key in evidence:
            evidence[raw_key] = merged_state_evidence(
                evidence[raw_key],
                evidence[old_canonical_key],
                preserve_left_order=True,
            )
            merged += 1
        else:
            raw_aliases[raw_key] = (old_canonical_key, old_alias_kind)
    return merged


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--sqlite", type=Path, required=True)
    parser.add_argument("--canonical-cache", type=Path, required=True)
    parser.add_argument(
        "--alias-map",
        type=Path,
        help="additional raw-to-canonical JSONL aliases, for example retained root replays",
    )
    parser.add_argument(
        "--base-oracle",
        type=Path,
        help="previous utility manifest whose evidence and raw aliases must be retained",
    )
    parser.add_argument(
        "--prefer-incoming-evidence",
        action="store_true",
        help=(
            "put newly frozen exact-state evidence before inherited candidates; "
            "use for a targeted recovery overlay after the inherited choice has "
            "failed strict replay"
        ),
    )
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument(
        "--intern-exact-witnesses",
        action="store_true",
        help="store each exact-* atom once and refer to it by its SHA-256 digest",
    )
    args = parser.parse_args()

    evidence = candidate_evidence(args.sqlite)
    contextless_portable_states = add_contextless_portable_exact_states(
        args.sqlite, evidence
    )
    base_aliases, base_merged_direct_keys = merge_base_oracle(
        args.base_oracle,
        evidence,
        prefer_incoming=args.prefer_incoming_evidence,
    )
    raw_aliases, cache_merged_direct_keys = aliases(args.canonical_cache, evidence)
    merged_direct_keys = base_merged_direct_keys + cache_merged_direct_keys
    merged_direct_keys += retain_base_alias_evidence(
        base_aliases,
        evidence,
        raw_aliases,
    )
    merged_direct_keys += apply_dataset_aliases(
        args.sqlite,
        evidence,
        raw_aliases,
        prefer_alias_evidence=args.prefer_incoming_evidence,
    )
    merged_direct_keys += apply_explicit_aliases(
        args.alias_map,
        evidence,
        raw_aliases,
        prefer_alias_evidence=args.prefer_incoming_evidence,
    )
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with args.output.open("w", encoding="utf-8") as output:
        if args.intern_exact_witnesses:
            witnesses = {
                exact_witness_id(item["candidate"]): item["candidate"]
                for state in evidence.values()
                for group in EVIDENCE_GROUPS
                for item in state[group]
                if item["candidate"].startswith("exact-")
            }
            for witness_id, candidate in sorted(witnesses.items()):
                print(
                    json.dumps(
                        {
                            "schema": WITNESS_SCHEMA,
                            "witness_id": witness_id,
                            "candidate": candidate,
                        },
                        separators=(",", ":"),
                        sort_keys=True,
                    ),
                    file=output,
                )
        for problem_key, state_evidence in sorted(evidence.items()):
            if args.intern_exact_witnesses:
                state_evidence = {
                    group: [
                        (
                            {
                                **{
                                    key: value
                                    for key, value in item.items()
                                    if key != "candidate"
                                },
                                "candidate_ref": exact_witness_id(item["candidate"]),
                            }
                            if item["candidate"].startswith("exact-")
                            else item
                        )
                        for item in state_evidence[group]
                    ]
                    for group in EVIDENCE_GROUPS
                }
            print(
                json.dumps(
                    {
                        "schema": SCHEMA,
                        "problem_key": problem_key,
                        **state_evidence,
                    },
                    separators=(",", ":"),
                    sort_keys=True,
                ),
                file=output,
            )
        for raw_key, (canonical_key, alias_kind) in sorted(raw_aliases.items()):
            print(
                json.dumps(
                    {
                        "schema": SCHEMA,
                        "problem_key": raw_key,
                        "canonical_problem_key": canonical_key,
                        "alias_kind": alias_kind,
                    },
                    separators=(",", ":"),
                    sort_keys=True,
                ),
                file=output,
            )
    print(
        json.dumps(
            {
                "canonical_states": len(evidence),
                "raw_aliases": len(raw_aliases),
                "merged_direct_keys": merged_direct_keys,
                "contextless_portable_states": contextless_portable_states,
                "manifest_rows": len(evidence)
                + len(raw_aliases)
                + (len(witnesses) if args.intern_exact_witnesses else 0),
                "output": str(args.output),
            },
            sort_keys=True,
        )
    )


if __name__ == "__main__":
    main()
