"""Independent full-XML residual isomorphism, with explicit symbol bindings.

Rule/map/Q collections may reorder. Rule-local variables and genuinely fresh
symbols may rename. Pair-to-source-rule associations are edges, not discarded
indices. Every other XML field, role and value is retained in the graph.
"""
import argparse
import json
import signal
from pathlib import Path
import time
import xml.etree.ElementTree as ET
import networkx as nx
from audit_modular_child_equivalence import inverse_input_mapping


def obligation_graph(xml, bindings):
    root = ET.fromstring(xml)
    graph = nx.DiGraph()
    elements = list(root.iter())
    ids = {id(element): i for i, element in enumerate(elements)}
    extra = {}

    def reference(kind, key, label):
        key = (kind, key)
        if key not in extra:
            extra[key] = len(elements) + len(extra)
            graph.add_node(extra[key], label=label, symbol=key[1] if kind == 'name' else None)
        return extra[key]

    source_arrays = {}
    trs_rules = root.findall('./trs/rules/rule')
    for tag, path in [('pairSourceRules', './dps/rules/rule'),
                      ('weakPairSourceRules', './ferrumWeakDps/rules/rule')]:
        array = root.find('./ferrumDpStateContext/' + tag)
        if array is not None:
            pairs = root.findall(path)
            if len(pairs) != len(array) or any(n.tag != 'sourceRule' for n in array):
                raise ValueError('malformed pair/source-rule correspondence')
            for item, pair in zip(array, pairs):
                index = int(item.text)
                source_arrays[id(item)] = pair, trs_rules[index] if 0 <= index < len(trs_rules) else None

    def visit(node, scope=None):
        node_id = ids[id(node)]
        if node.tag == 'rule':
            scope = node_id
        text = (node.text or '').strip() if not (node.text or '').strip() else node.text
        label = ('xml', node.tag, tuple(sorted(node.attrib.items())), text)
        if node.tag == 'name':
            label = ('xml', 'name', tuple(sorted(node.attrib.items())))
            bound = bindings.get(('name', node.text))
            symbol = reference('name', node.text, ('symbol', 'bound', bound) if bound is not None else ('symbol', 'fresh'))
            graph.add_edge(node_id, symbol, role='symbol-binding')
        elif node.tag == 'var':
            label = ('xml', 'var', tuple(sorted(node.attrib.items())))
            key = (scope, node.text)
            if scope is None:
                bound = bindings.get(('var', node.text), node.text)
                variable_label = ('global-variable', bound)
            else:
                variable_label = ('rule-local-variable',)
            variable = reference('var', key, variable_label)
            graph.add_edge(node_id, variable, role='variable-binding')
        elif id(node) in source_arrays:
            pair, source = source_arrays[id(node)]
            graph.add_edge(node_id, ids[id(pair)], role='associated-pair')
            if source is not None:
                label = ('xml', 'sourceRule', tuple(sorted(node.attrib.items())), 'reference')
                graph.add_edge(node_id, ids[id(source)], role='source-rule')
        graph.add_node(node_id, label=label)
        unordered = node.tag in ('rules', 'contextSensitive', 'pairSourceRules', 'weakPairSourceRules')
        for index, child in enumerate(node):
            q_term = node.tag == 'innermostLhss' and child.tag in ('funapp', 'var')
            role = 'member' if unordered or q_term else f'position:{index}'
            graph.add_edge(node_id, ids[id(child)], role=role)
            visit(child, ids[id(child)] if q_term else scope)
            if child.tail and child.tail.strip():
                raise ValueError('mixed XML text content is not a residual state')

    visit(root)
    return graph


def isomorphic(left, right, inverse):
    if inverse is None:
        raise ValueError('no bijective input renaming')
    a = obligation_graph(left, {(kind, original): original for (kind, _), original in inverse.items()})
    b = obligation_graph(right, inverse)
    if len(a) != len(b) or a.number_of_edges() != b.number_of_edges():
        return None
    # Shared color refinement only prunes the exact graph-isomorphism search;
    # equality is never inferred from a hash/color match alone.
    labels = {}
    for graph in (a, b):
        for _, data in graph.nodes(data=True):
            data['color'] = labels.setdefault(data['label'], len(labels))
    for _ in range(6):
        labels, updates = {}, []
        for graph in (a, b):
            colors = {}
            for node in graph:
                signature = (graph.nodes[node]['color'],
                    tuple(sorted((data['role'], graph.nodes[v]['color']) for _, v, data in graph.out_edges(node, data=True))),
                    tuple(sorted((data['role'], graph.nodes[u]['color']) for u, _, data in graph.in_edges(node, data=True))))
                colors[node] = labels.setdefault(signature, len(labels))
            updates.append(colors)
        for graph, colors in zip((a, b), updates):
            nx.set_node_attributes(graph, colors, 'color')
    matcher = nx.algorithms.isomorphism.DiGraphMatcher(a, b,
        node_match=lambda x, y: x['color'] == y['color'] and x['label'] == y['label'],
        edge_match=lambda x, y: x['role'] == y['role'])
    if not matcher.is_isomorphic():
        return None
    return {data['symbol']: b.nodes[matcher.mapping[node]]['symbol']
            for node, data in a.nodes(data=True) if data.get('symbol') is not None}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--report', type=Path, required=True)
    parser.add_argument('--states', type=Path, required=True)
    parser.add_argument('--audit-root', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--timeout', type=int, default=60)
    args = parser.parse_args()
    with args.output.open('x') as output:
        for row in map(json.loads, args.report.open()):
            if row['status'] != 'needs-inspection':
                continue
            start = time.monotonic()
            result = dict(index=row['index'], family=row['family'])
            try:
                def expired(_signal, _frame):
                    raise TimeoutError('independent isomorphism allowance exceeded')
                signal.signal(signal.SIGALRM, expired)
                signal.alarm(args.timeout)
                observations = row['observations']
                if len(observations) != 2:
                    raise ValueError('expected one child per variant for focused isomorphism')
                directory = args.audit_root / str(row['index'])
                inverse = inverse_input_mapping((directory/'original.input.cpf').read_text(), (directory/'renamed.input.cpf').read_text())
                left, right = [(args.states / (obs['sha256'] + '.cpf')).read_text() for obs in observations]
                if any(observations[0][key] != observations[1][key] for key in ('problem_kind', 'assumption_kind')):
                    raise ValueError('changed child role')
                mapping = isomorphic(left, right, inverse)
                result.update(status='equal' if mapping is not None else 'different', symbol_bijection=mapping)
            except Exception as error:
                result.update(status='comparison-failed', reason=str(error))
            finally:
                signal.alarm(0)
            result['elapsed_s'] = round(time.monotonic() - start, 3)
            print(json.dumps(result), file=output, flush=True)
            print(result['index'], result['status'], result['elapsed_s'], flush=True)


if __name__ == '__main__':
    main()
