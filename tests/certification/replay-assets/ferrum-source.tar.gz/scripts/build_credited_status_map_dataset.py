#!/usr/bin/env python3
"""Build proof-path credited HRM status-map rows from Ferrum event logs.

This is a derived-data pass over immutable processor-event JSONL logs.  It
extends ``build_hrm_status_map_dataset.py`` in two ways:

* transformed attempts are credited as positive only when their run/problem
  later has a solved processor event; otherwise they are downgraded to failed
  by default;
* failed ``LlmGuidance`` rows contribute hard-negative observations for the
  positive atoms predicted by the model.  If fallback later solves the same
  canonical CPF with another atom, that solved atom wins for the same
  candidate, while the bad guidance atoms remain negatives.

The input and output row format is still HRM-Text ``direct``:

    {"condition":"direct","instruction":"<input>...</input>","response":"solved:\\n..."}
"""

from __future__ import annotations

import argparse
import gzip
import hashlib
import json
import multiprocessing as mp
import signal
import sqlite3
import subprocess
import sys
import tempfile
import time
import xml.etree.ElementTree as ET
from collections import Counter, defaultdict
from copy import deepcopy
from pathlib import Path
from typing import Any

from build_hrm_status_map_dataset import (
    POSITIVE_STATUSES,
    STATUS_ORDER,
    STATUS_RANK,
    bucket_for_event,
    normalize_atom,
    open_output,
    open_text,
    split_for_id,
    wrap_input,
)

STATUS_REWARD = {
    "solved": 1000.0,
    "transformed_strong": 300.0,
    "transformed_weak": 80.0,
    "failed": -60.0,
    "timeout": -400.0,
}


class CanonicalizationTimeout(RuntimeError):
    pass


def canonicalization_timeout_handler(signum: int, frame: Any) -> None:
    raise CanonicalizationTimeout("CPF input canonicalization timed out")


def local_name(tag: str) -> str:
    return tag.rsplit("}", 1)[-1]


def first_child(elem: ET.Element, name: str) -> ET.Element | None:
    for child in elem:
        if local_name(child.tag) == name:
            return child
    return None


def corrected_event_outcome(event: dict[str, Any], stats: Counter[str]) -> Any:
    outcome = event.get("outcome")
    if outcome != "transformed":
        return outcome
    witness = event.get("witness")
    metrics = event.get("metrics")
    if (
        isinstance(witness, dict)
        and witness.get("kind") == "proof_steps_debug"
        and isinstance(witness.get("value"), str)
        and witness["value"].lstrip().startswith("[Unsupported {")
        and isinstance(metrics, dict)
        and metrics.get("proof_steps") == 1
    ):
        stats["unsupported_only_transforms_reclassified_failed"] += 1
        return "failed"
    return outcome


def normalized_event_candidate(event: dict[str, Any]) -> str | None:
    raw_candidate = event.get("strategy_atom") or event.get("processor")
    candidate = normalize_atom(raw_candidate)
    if candidate != "termination":
        return candidate
    witness = event.get("witness")
    if (
        event.get("level") == "top-level"
        and isinstance(witness, dict)
        and witness.get("kind") == "proof_steps_debug"
        and isinstance(witness.get("value"), str)
        and "DependencyPairProof" in witness["value"]
    ):
        # `termination` is a generic search entry, not a replayable processor.
        # Preserve the executable proof-theoretic entry actually used.
        return "dp"
    return candidate


def child_text(elem: ET.Element | None, name: str) -> str | None:
    if elem is None:
        return None
    child = first_child(elem, name)
    if child is None:
        return None
    return "".join(child.itertext()).strip()


def funapp_args(elem: ET.Element) -> list[ET.Element]:
    args = []
    for child in elem:
        name = local_name(child.tag)
        if name in {"name", "sharp"}:
            continue
        if name == "arg":
            if len(child):
                args.append(child[0])
        elif name in {"funapp", "var"}:
            args.append(child)
    return args


def rule_sides(rule: ET.Element) -> tuple[ET.Element | None, ET.Element | None]:
    lhs = first_child(rule, "lhs")
    rhs = first_child(rule, "rhs")
    if lhs is not None and rhs is not None and len(lhs) and len(rhs):
        return lhs[0], rhs[0]
    terms = [child for child in rule if local_name(child.tag) in {"funapp", "var"}]
    if len(terms) >= 2:
        return terms[0], terms[1]
    return None, None


def canonical_symbol_name(index: int) -> str:
    letters = []
    while True:
        letters.append(chr(ord("a") + index % 26))
        index //= 26
        if index == 0:
            break
        index -= 1
    return "".join(reversed(letters))


def canonical_variable_name(index: int) -> str:
    if index == 0:
        return "x"
    if index == 1:
        return "y"
    if index == 2:
        return "z"
    return f"x{index - 2}"


def cpf_symbol_key(symbol: ET.Element | None) -> str | None:
    if symbol is None:
        return None
    tag = local_name(symbol.tag)
    if tag == "name":
        return "".join(symbol.itertext()).strip()
    if tag == "sharp":
        base = first_child(symbol, "name")
        text = "".join(base.itertext()).strip() if base is not None else ""
        return f"{text}#" if text else None
    if tag == "labeledSymbol":
        base_node = next(
            (
                child
                for child in symbol
                if local_name(child.tag) in {"name", "sharp", "labeledSymbol"}
            ),
            None,
        )
        base = cpf_symbol_key(base_node)
        if base is None:
            return None
        labels = [
            "".join(element.itertext()).strip()
            for element in symbol.iter()
            if local_name(element.tag) == "number"
        ]
        encoded = base.encode("utf-8").hex()
        return f"__ferrum_sl__{encoded}__{'_'.join(labels)}"
    return None


def funapp_symbol_key(term: ET.Element) -> str | None:
    if local_name(term.tag) != "funapp":
        return None
    symbol = next(
        (
            child
            for child in term
            if local_name(child.tag) in {"name", "sharp", "labeledSymbol"}
        ),
        None,
    )
    return cpf_symbol_key(symbol)


def collect_fun_symbols_from_term(term: ET.Element, out: set[str]) -> None:
    if local_name(term.tag) == "funapp":
        symbol = funapp_symbol_key(term)
        if symbol:
            out.add(symbol)
    for arg in funapp_args(term):
        collect_fun_symbols_from_term(arg, out)


def input_rule_blocks(root: ET.Element) -> list[ET.Element]:
    blocks = []
    root_name = local_name(root.tag)
    if root_name == "input":
        candidates = list(root)
    else:
        input_elem = first_child(root, "input")
        candidates = list(input_elem) if input_elem is not None else [root]
    for candidate in candidates:
        candidate_name = local_name(candidate.tag)
        if candidate_name not in {"trsInput", "dpInput"}:
            continue
        for container in candidate.iter():
            container_name = local_name(container.tag)
            if container_name in {"trs", "dps", "usableRules", "rules"}:
                rules = first_child(container, "rules") if container_name != "rules" else container
                if rules is None:
                    continue
                if any(local_name(child.tag) == "rule" for child in rules):
                    blocks.append(rules)
    if root_name in {"trsInput", "dpInput"}:
        for container in root.iter():
            container_name = local_name(container.tag)
            if container_name in {"trs", "dps", "usableRules", "rules"}:
                rules = first_child(container, "rules") if container_name != "rules" else container
                if rules is not None and any(local_name(child.tag) == "rule" for child in rules):
                    blocks.append(rules)
    # Deduplicate when a <rules> element was reached both directly and via its parent.
    seen: set[int] = set()
    unique = []
    for block in blocks:
        if id(block) not in seen:
            seen.add(id(block))
            unique.append(block)
    return unique


def term_key(term: ET.Element, assignment: dict[str, str], variables: dict[str, str]) -> str:
    name = local_name(term.tag)
    if name == "var":
        old = "".join(term.itertext()).strip()
        if old not in variables:
            variables[old] = canonical_variable_name(len(variables))
        return f"V{variables[old]}"
    if name == "funapp":
        symbol = funapp_symbol_key(term)
        canonical = assignment.get(symbol or "", symbol or "")
        args = [term_key(arg, assignment, variables) for arg in funapp_args(term)]
        return f"F{canonical}#{len(args)}({','.join(args)})"
    return local_name(term.tag)


def rule_key(rule: ET.Element, assignment: dict[str, str]) -> str:
    lhs, rhs = rule_sides(rule)
    if lhs is None or rhs is None:
        return ET.tostring(rule, encoding="unicode", short_empty_elements=True)
    variables: dict[str, str] = {}
    return f"{term_key(lhs, assignment, variables)}->{term_key(rhs, assignment, variables)}"


def collect_input_symbols(rule_blocks: list[ET.Element]) -> list[str]:
    symbols: set[str] = set()
    for block in rule_blocks:
        for rule in block:
            if local_name(rule.tag) != "rule":
                continue
            lhs, rhs = rule_sides(rule)
            if lhs is not None:
                collect_fun_symbols_from_term(lhs, symbols)
            if rhs is not None:
                collect_fun_symbols_from_term(rhs, symbols)
    return sorted(symbols)


def first_occurrence_renumbering(rule_blocks: list[ET.Element], assignment: dict[str, str]) -> dict[str, str]:
    seen: dict[str, str] = {}
    for block in rule_blocks:
        rules = [rule for rule in block if local_name(rule.tag) == "rule"]
        for rule in sorted(rules, key=lambda rule: rule_key(rule, assignment)):
            lhs, rhs = rule_sides(rule)
            for term in (lhs, rhs):
                if term is None:
                    continue
                for token in term_key(term, assignment, {}).split("F")[1:]:
                    symbol = token.split("#", 1)[0]
                    if symbol and symbol not in seen:
                        seen[symbol] = canonical_symbol_name(len(seen))
    return seen


def canonical_function_bijection(rule_blocks: list[ET.Element]) -> dict[str, str]:
    symbols = collect_input_symbols(rule_blocks)
    if not symbols:
        return {}
    symbol_set = set(symbols)

    def term_tokens(term: ET.Element, variables: dict[str, int]) -> list[str | int]:
        name = local_name(term.tag)
        if name == "var":
            old = "".join(term.itertext()).strip()
            if old not in variables:
                variables[old] = len(variables)
            return [1, variables[old]]
        if name == "funapp":
            symbol = funapp_symbol_key(term)
            if symbol not in symbol_set:
                return [4]
            args = funapp_args(term)
            tokens: list[str | int] = [2, symbol or "", len(args)]
            for arg in args:
                tokens.extend(term_tokens(arg, variables))
            tokens.append(3)
            return tokens
        return [4]

    rule_tokens: list[list[str | int]] = []
    for block_index, block in enumerate(rule_blocks):
        rules = [rule for rule in block if local_name(rule.tag) == "rule"]
        rules.sort(key=lambda rule: rule_key(rule, {symbol: "_" for symbol in symbols}))
        for rule in rules:
            lhs, rhs = rule_sides(rule)
            if lhs is None or rhs is None:
                continue
            variables: dict[str, int] = {}
            tokens: list[str | int] = [10 + block_index]
            tokens.extend(term_tokens(lhs, variables))
            tokens.append(100)
            tokens.extend(term_tokens(rhs, variables))
            tokens.append(101)
            rule_tokens.append(tokens)

    # The former SMT encoding constrained ranks only to be a permutation and
    # then minimized each encountered symbol independently.  Consequently the
    # unique result is simply first structural occurrence order.  Constructing
    # that permutation directly is equivalent, avoids quadratic solver calls
    # on large generated signatures, and leaves no timeout-dependent raw-hash
    # fallback in the oracle integration path.
    direct: dict[str, str] = {}
    for token in (token for tokens in rule_tokens for token in tokens):
        if isinstance(token, str) and token in symbol_set and token not in direct:
            direct[token] = canonical_symbol_name(len(direct))
    for symbol in symbols:
        if symbol not in direct:
            direct[symbol] = canonical_symbol_name(len(direct))
    renumbering = first_occurrence_renumbering(rule_blocks, direct)
    return {old: renumbering.get(mid, mid) for old, mid in direct.items()}


def rewrite_names(root: ET.Element, mapping: dict[str, str]) -> None:
    for parent in root.iter():
        if local_name(parent.tag) in {"funapp", "sharp", "labeledSymbol"}:
            continue
        for elem in parent:
            if local_name(elem.tag) != "name" or elem.text is None:
                continue
            old = elem.text.strip()
            if old in mapping:
                elem.text = mapping[old]


def normalize_funapp_symbols(root: ET.Element, mapping: dict[str, str]) -> None:
    """Write every parsed CPF symbol as one canonical atomic ``<name>``."""
    for term in root.iter():
        if local_name(term.tag) != "funapp":
            continue
        symbol_node = next(
            (
                child
                for child in term
                if local_name(child.tag) in {"name", "sharp", "labeledSymbol"}
            ),
            None,
        )
        symbol = cpf_symbol_key(symbol_node)
        if symbol_node is None or symbol is None:
            continue
        replacement = ET.Element("name")
        replacement.text = mapping.get(symbol, symbol)
        index = list(term).index(symbol_node)
        term.remove(symbol_node)
        term.insert(index, replacement)


def rewrite_rule_variables(rule: ET.Element) -> None:
    variables: dict[str, str] = {}
    for elem in rule.iter():
        if local_name(elem.tag) != "var" or elem.text is None:
            continue
        old = elem.text.strip()
        if old not in variables:
            variables[old] = canonical_variable_name(len(variables))
        elem.text = variables[old]


def sort_rule_blocks(rule_blocks: list[ET.Element]) -> None:
    identity: dict[str, str] = {}
    for block in rule_blocks:
        rules = [child for child in list(block) if local_name(child.tag) == "rule"]
        non_rules = [child for child in list(block) if local_name(child.tag) != "rule"]
        rules.sort(key=lambda rule: rule_key(rule, identity))
        block[:] = non_rules + rules


def canonicalize_dp_source_provenance(root: ET.Element) -> None:
    """Keep pair source indices aligned while canonical rule sets are sorted."""
    identity: dict[str, str] = {}
    for dp_input in (elem for elem in root.iter() if local_name(elem.tag) == "dpInput"):
        trs = first_child(dp_input, "trs")
        trs_rules = first_child(trs, "rules") if trs is not None else None
        original_to_canonical: dict[int, int] = {}
        if trs_rules is not None:
            rules = [child for child in list(trs_rules) if local_name(child.tag) == "rule"]
            order = sorted(range(len(rules)), key=lambda index: rule_key(rules[index], identity))
            original_to_canonical = {
                original: canonical for canonical, original in enumerate(order)
            }

        context = first_child(dp_input, "ferrumDpStateContext")
        if context is None:
            continue
        for pair_tag, source_tag in (
            ("dps", "pairSourceRules"),
            ("ferrumWeakDps", "weakPairSourceRules"),
        ):
            pair_container = first_child(dp_input, pair_tag)
            pair_rules = (
                first_child(pair_container, "rules")
                if pair_container is not None
                else None
            )
            source_container = first_child(context, source_tag)
            if pair_rules is None or source_container is None:
                continue
            rules = [child for child in list(pair_rules) if local_name(child.tag) == "rule"]
            sources = [
                child
                for child in list(source_container)
                if local_name(child.tag) == "sourceRule"
            ]
            if len(rules) != len(sources):
                continue
            for source in sources:
                if source.text is None:
                    continue
                try:
                    original = int(source.text.strip())
                except ValueError:
                    continue
                source.text = str(original_to_canonical.get(original, original))
            zipped = sorted(
                zip(rules, sources, strict=True),
                # Alpha-equivalent/duplicate dependency pairs can originate
                # from different source rules.  Their term keys are equal,
                # so using only the rule key leaves the stable sort dependent
                # on the live graph's incidental pair order.  Source
                # provenance is processor-relevant metadata and provides the
                # deterministic final tie-breaker.
                key=lambda entry: (
                    rule_key(entry[0], identity),
                    int(entry[1].text.strip()) if entry[1].text else -1,
                ),
            )
            non_rules = [
                child for child in list(pair_rules) if local_name(child.tag) != "rule"
            ]
            non_sources = [
                child
                for child in list(source_container)
                if local_name(child.tag) != "sourceRule"
            ]
            pair_rules[:] = non_rules + [rule for rule, _ in zipped]
            source_container[:] = non_sources + [source for _, source in zipped]


def strip_insignificant_xml_whitespace(root: ET.Element) -> None:
    for elem in root.iter():
        if elem.text is not None and not elem.text.strip():
            elem.text = None
        if elem.tail is not None and not elem.tail.strip():
            elem.tail = None


def strip_reconstruction_only_state_markers(root: ET.Element) -> None:
    """Remove metadata that does not change the rewriting obligation.

    ``ferrumCsrBoundary`` records which CPF wrapper may reconstruct a solved
    CSR child.  It is intentionally present in the exact runtime key, but it
    is not part of the CSR relation and therefore must not split semantic
    canonical keys used to connect archived proof states to live residuals.
    """
    for parent in root.iter():
        parent[:] = [
            child
            for child in list(parent)
            if local_name(child.tag) != "ferrumCsrBoundary"
        ]


def compact_xml_for_key(xml: str) -> str:
    """Match Ferrum's formatting-insensitive runtime lookup key exactly.

    CPF extraction and live serialization may indent the same XML tree
    differently.  Retaining this structural alias alongside the raw and
    semantic-canonical keys makes those equivalent states meet without
    weakening symbol/rule canonicalization.
    """
    data = xml.strip().encode("utf-8")
    result = bytearray()
    index = 0
    while index < len(data):
        if data[index] == ord(">"):
            result.append(data[index])
            index += 1
            whitespace_start = index
            while index < len(data) and data[index] in b" \t\n\v\f\r":
                index += 1
            if index >= len(data) or data[index] != ord("<"):
                result.extend(data[whitespace_start:index])
            continue
        if data[index : index + 2] == b"/>":
            while result and result[-1] in b" \t\n\v\f\r":
                result.pop()
        result.append(data[index])
        index += 1
    return (
        result.decode("utf-8")
        .replace("&apos;", "'")
        .replace("&#39;", "'")
        .replace("&#x27;", "'")
        .replace("&#X27;", "'")
    )


def canonicalize_cpf_input(cpf: str) -> tuple[str, str | None]:
    root = ET.fromstring(cpf.encode("utf-8"))
    root = deepcopy(root)
    strip_reconstruction_only_state_markers(root)
    strip_insignificant_xml_whitespace(root)
    rule_blocks = input_rule_blocks(root)
    if not rule_blocks:
        return cpf.strip(), "no-rule-blocks"
    mapping = canonical_function_bijection(rule_blocks)
    normalize_funapp_symbols(root, mapping)
    # Replacement-map and other non-term symbol references use ordinary
    # names, so retain the legacy rewrite for those nodes after term symbols
    # have been atomized.
    rewrite_names(root, mapping)
    for block in rule_blocks:
        for rule in block:
            if local_name(rule.tag) == "rule":
                rewrite_rule_variables(rule)
    canonicalize_dp_source_provenance(root)
    sort_rule_blocks(rule_blocks)
    return ET.tostring(root, encoding="unicode", short_empty_elements=True).strip(), None


def canonicalize_cpf_with_timeout(cpf: str, timeout_seconds: float) -> tuple[str, str | None]:
    try:
        signal.signal(signal.SIGALRM, canonicalization_timeout_handler)
        signal.setitimer(signal.ITIMER_REAL, timeout_seconds)
        return canonicalize_cpf_input(cpf)
    except CanonicalizationTimeout as exc:
        return cpf, f"failed-CanonicalizationTimeout:{exc}"
    except Exception as exc:  # noqa: BLE001 - keep the row and record the reason.
        return cpf, f"failed-{type(exc).__name__}"
    finally:
        signal.setitimer(signal.ITIMER_REAL, 0.0)


def canonicalize_with_ferrum(cpf: str, executable: str, timeout_seconds: float) -> str:
    """Use Ferrum's production canonicalizer, keeping runtime/oracle keys identical."""
    with tempfile.NamedTemporaryFile(mode="w", suffix=".cpf.xml", encoding="utf-8") as source:
        source.write(cpf)
        source.flush()
        result = subprocess.run(
            [executable, "canonicalize-cpf", source.name],
            check=True,
            capture_output=True,
            timeout=timeout_seconds,
        )
    return result.stdout.decode("utf-8").strip()


def canonicalize_worker(
    item: tuple[str, str, float, str | None],
) -> tuple[str, str, str | None, float]:
    raw_key, cpf, timeout_seconds, ferrum_canonicalizer = item
    started = time.monotonic()
    if ferrum_canonicalizer is None:
        canonical, note = canonicalize_cpf_with_timeout(cpf, timeout_seconds)
    else:
        try:
            canonical = canonicalize_with_ferrum(cpf, ferrum_canonicalizer, timeout_seconds)
            note = None
        except subprocess.TimeoutExpired:
            canonical, note = cpf, "failed-FerrumCanonicalizationTimeout"
        except Exception as exc:  # noqa: BLE001 - retain raw state with a diagnostic.
            canonical, note = cpf, f"failed-FerrumCanonicalization-{type(exc).__name__}"
    return raw_key, canonical, note, time.monotonic() - started


def canonicalize_process_target(
    raw_key: str,
    cpf: str,
    output_path: str,
    queue: mp.Queue,
    timeout_seconds: float = 60.0,
    ferrum_canonicalizer: str | None = None,
) -> None:
    started = time.monotonic()
    try:
        if ferrum_canonicalizer is None:
            canonical, note = canonicalize_cpf_input(cpf)
        else:
            canonical = canonicalize_with_ferrum(
                cpf, ferrum_canonicalizer, timeout_seconds
            )
            note = None
        Path(output_path).write_text(canonical, encoding="utf-8")
    except Exception as exc:  # noqa: BLE001 - propagate a structured failure to the parent.
        note = f"failed-{type(exc).__name__}"
    # Canonical CPF states can be hundreds of MiB.  Returning them through a
    # multiprocessing.Queue makes ``get_nowait`` block while receiving one
    # giant pipe frame, which also prevents the parent from enforcing worker
    # deadlines.  Transfer the payload through a temporary file and keep the
    # synchronization message bounded.
    queue.put((raw_key, note, time.monotonic() - started))


def run_problem_key(event: dict[str, Any], problem_key: str) -> str:
    run_id = event.get("run_id")
    problem_id = event.get("problem_id")
    if isinstance(run_id, str) and isinstance(problem_id, str):
        return f"{run_id}\0{problem_id}"
    if isinstance(problem_id, str):
        return f"<no-run>\0{problem_id}"
    return f"<cpf>\0{problem_key}"


def source_run_problem_key(input_path: Path, event: dict[str, Any]) -> str:
    run_id = event.get("run_id")
    problem_id = event.get("problem_id")
    run = run_id if isinstance(run_id, str) and run_id else str(input_path.parent)
    problem = problem_id if isinstance(problem_id, str) and problem_id else "<no-problem-id>"
    return f"{input_path}\0{run}\0{problem}"


def event_state_signature(event: dict[str, Any]) -> tuple[Any, ...]:
    metrics = event.get("metrics") if isinstance(event.get("metrics"), dict) else {}
    return (
        event.get("level"),
        event.get("problem_kind"),
        event.get("category"),
        metrics.get("rules"),
        metrics.get("pairs"),
        metrics.get("dp_pairs"),
        metrics.get("component_pairs"),
        metrics.get("usable_rules"),
        metrics.get("remaining_rules"),
        metrics.get("remaining_pairs"),
    )


def scan_event_log_quality(args: argparse.Namespace) -> tuple[set[str], dict[str, Any]]:
    by_key: dict[str, dict[str, Any]] = defaultdict(
        lambda: {
            "rows": 0,
            "missing_cpf": 0,
            "distinct_cpf": set(),
            "states": set(),
            "levels": Counter(),
            "processors": Counter(),
        }
    )
    stats: Counter[str] = Counter()
    started = time.monotonic()
    for input_path in args.input:
        stats["quality_input_files"] += 1
        with open_text(input_path) as source:
            for line in source:
                stats["quality_rows"] += 1
                try:
                    event = json.loads(line)
                except json.JSONDecodeError:
                    stats["quality_bad_json"] += 1
                    continue
                key = source_run_problem_key(input_path, event)
                entry = by_key[key]
                entry["rows"] += 1
                cpf = (event.get("input") or {}).get("cpf")
                if isinstance(cpf, str) and cpf.strip():
                    entry["distinct_cpf"].add(hashlib.sha256(cpf.strip().encode("utf-8")).hexdigest())
                else:
                    entry["missing_cpf"] += 1
                entry["states"].add(event_state_signature(event))
                if isinstance(event.get("level"), str):
                    entry["levels"][event["level"]] += 1
                if isinstance(event.get("processor"), str):
                    entry["processors"][event["processor"]] += 1
                if args.limit is not None and stats["quality_rows"] >= args.limit:
                    break
        if args.limit is not None and stats["quality_rows"] >= args.limit:
            break
    rejected: set[str] = set()
    suspicious_examples: list[dict[str, Any]] = []
    for key, entry in by_key.items():
        rows = int(entry["rows"])
        cpf_count = len(entry["distinct_cpf"])
        state_count = len(entry["states"])
        missing = int(entry["missing_cpf"])
        suspicious = False
        reasons: list[str] = []
        if missing:
            reasons.append("missing-cpf")
        if (
            rows >= args.quality_min_rows
            and state_count >= args.quality_min_states
            and cpf_count <= args.quality_max_cpf_for_state_mismatch
        ):
            suspicious = True
            reasons.append("many-states-one-cpf")
        if cpf_count > 0 and state_count > max(args.quality_state_cpf_ratio * cpf_count, args.quality_min_states):
            suspicious = True
            reasons.append("state-cpf-ratio")
        if suspicious and args.reject_suspicious_runs:
            rejected.add(key)
        if suspicious and len(suspicious_examples) < args.quality_examples:
            source, run, problem = key.split("\0", 2)
            suspicious_examples.append(
                {
                    "source": source,
                    "run": run,
                    "problem": problem,
                    "rows": rows,
                    "distinct_cpf": cpf_count,
                    "distinct_states": state_count,
                    "missing_cpf": missing,
                    "reasons": reasons,
                    "levels": dict(entry["levels"].most_common()),
                    "processors": dict(entry["processors"].most_common(8)),
                }
            )
    summary = {
        "elapsed_seconds": round(time.monotonic() - started, 3),
        "run_problem_count": len(by_key),
        "rejected_run_problem_count": len(rejected),
        "reject_suspicious_runs": args.reject_suspicious_runs,
        "stats": dict(stats),
        "suspicious_examples": suspicious_examples,
    }
    return rejected, summary


def positive_guidance_atoms(event: dict[str, Any]) -> list[str]:
    witness = event.get("witness")
    if not isinstance(witness, dict) or witness.get("kind") != "status_map":
        return []
    atoms: list[str] = []
    for section in ("solved", "transformed_strong", "transformed_weak"):
        values = witness.get(section)
        if isinstance(values, list):
            atoms.extend(value for value in values if isinstance(value, str))
    return atoms


def event_is_certified(event: dict[str, Any]) -> bool:
    certification = event.get("certification")
    if isinstance(certification, dict):
        status = certification.get("status")
        if isinstance(status, str) and status.startswith("certified"):
            return True
    credit = event.get("credit")
    return isinstance(credit, dict) and credit.get("status") == "proof-path-certified"


def create_schema(conn: sqlite3.Connection) -> None:
    conn.executescript(
        """
        PRAGMA journal_mode=WAL;
        PRAGMA synchronous=NORMAL;
        CREATE TABLE IF NOT EXISTS problems (
            problem_key TEXT PRIMARY KEY,
            cpf TEXT NOT NULL,
            first_problem_id TEXT,
            rows INTEGER NOT NULL DEFAULT 0,
            occurrences INTEGER NOT NULL DEFAULT 0,
            validity_mask INTEGER NOT NULL DEFAULT 0
        );
        CREATE TABLE IF NOT EXISTS problem_aliases (
            raw_problem_key TEXT NOT NULL,
            problem_key TEXT NOT NULL,
            source TEXT NOT NULL DEFAULT 'event-content-address',
            PRIMARY KEY(raw_problem_key, problem_key),
            FOREIGN KEY(problem_key) REFERENCES problems(problem_key)
        );
        CREATE INDEX IF NOT EXISTS problem_aliases_problem_idx
            ON problem_aliases(problem_key);
        CREATE TABLE IF NOT EXISTS run_problems (
            run_problem_key TEXT PRIMARY KEY,
            solved INTEGER NOT NULL DEFAULT 0,
            rows INTEGER NOT NULL DEFAULT 0
        );
        CREATE TABLE IF NOT EXISTS observations (
            problem_key TEXT NOT NULL,
            run_problem_key TEXT NOT NULL,
            candidate_key TEXT NOT NULL,
            candidate TEXT NOT NULL,
            raw_status TEXT NOT NULL,
            progress TEXT,
            elapsed_ms INTEGER,
            source TEXT NOT NULL,
            certified INTEGER NOT NULL DEFAULT 0
        );
        CREATE INDEX IF NOT EXISTS observations_problem_idx ON observations(problem_key);
        CREATE INDEX IF NOT EXISTS observations_run_problem_idx ON observations(run_problem_key);
        CREATE TABLE IF NOT EXISTS candidates (
            problem_key TEXT NOT NULL,
            candidate_key TEXT NOT NULL,
            candidate TEXT NOT NULL,
            best_status TEXT NOT NULL,
            best_rank INTEGER NOT NULL,
            best_elapsed_ms INTEGER,
            attempts INTEGER NOT NULL DEFAULT 0,
            solved_count INTEGER NOT NULL DEFAULT 0,
            transformed_count INTEGER NOT NULL DEFAULT 0,
            failed_count INTEGER NOT NULL DEFAULT 0,
            timeout_count INTEGER NOT NULL DEFAULT 0,
            certified_count INTEGER NOT NULL DEFAULT 0,
            hard_negative_count INTEGER NOT NULL DEFAULT 0,
            credited_transform_count INTEGER NOT NULL DEFAULT 0,
            downgraded_transform_count INTEGER NOT NULL DEFAULT 0,
            utility_score REAL NOT NULL DEFAULT 0.0,
            PRIMARY KEY (problem_key, candidate_key)
        );
        CREATE INDEX IF NOT EXISTS candidates_problem_key_idx ON candidates(problem_key);
        """
    )
    problem_columns = {
        row[1] for row in conn.execute("PRAGMA table_info(problems)").fetchall()
    }
    if "validity_mask" not in problem_columns:
        conn.execute(
            "ALTER TABLE problems ADD COLUMN validity_mask INTEGER NOT NULL DEFAULT 0"
        )
    if "occurrences" not in problem_columns:
        conn.execute(
            "ALTER TABLE problems ADD COLUMN occurrences INTEGER NOT NULL DEFAULT 0"
        )
    observation_columns = {
        row[1] for row in conn.execute("PRAGMA table_info(observations)").fetchall()
    }
    if "certified" not in observation_columns:
        conn.execute(
            "ALTER TABLE observations ADD COLUMN certified INTEGER NOT NULL DEFAULT 0"
        )
    candidate_columns = {
        row[1] for row in conn.execute("PRAGMA table_info(candidates)").fetchall()
    }
    if "certified_count" not in candidate_columns:
        conn.execute(
            "ALTER TABLE candidates ADD COLUMN certified_count INTEGER NOT NULL DEFAULT 0"
        )


def event_validity_mask(event: dict[str, Any]) -> int:
    campaign = event.get("campaign")
    if isinstance(campaign, dict):
        validity_mask = campaign.get("validity_mask")
        if isinstance(validity_mask, int) and 0 < validity_mask <= 15:
            return validity_mask
    metrics = event.get("metrics")
    if not isinstance(metrics, dict):
        return 0
    sound = metrics.get("input_sound_so_far")
    complete = metrics.get("input_complete_so_far")
    if not isinstance(sound, bool) or not isinstance(complete, bool):
        return 0
    if sound and complete:
        return 1
    if sound:
        return 2
    if complete:
        return 4
    return 8


def insert_observation(
    conn: sqlite3.Connection,
    problem_key: str,
    rpk: str,
    candidate: str,
    raw_status: str,
    progress: Any,
    elapsed: Any,
    source: str,
    certified: bool = False,
) -> None:
    if not isinstance(elapsed, int):
        elapsed = None
    conn.execute(
        """
        INSERT INTO observations(
            problem_key, run_problem_key, candidate_key, candidate,
            raw_status, progress, elapsed_ms, source, certified
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
        """,
        (
            problem_key,
            rpk,
            candidate,
            candidate,
            raw_status,
            progress if isinstance(progress, str) else None,
            elapsed,
            source,
            int(certified),
        ),
    )
    conn.execute(
        "INSERT OR IGNORE INTO temp.touched_problem_keys(problem_key) VALUES (?)",
        (problem_key,),
    )


def embedded_state_cpfs(event: dict[str, Any]) -> list[str]:
    """Return every state body carried by an event, including typed children.

    Processor-event streams content-address repeated inputs.  A transformed
    event is normally the only place where its child CPF is materialized; the
    next event then contains just that child's digest.  Ignoring witness
    residuals therefore orphaned precisely the recursive states needed for
    oracle replay.
    """
    cpfs: list[str] = []
    input_cpf = (event.get("input") or {}).get("cpf")
    if isinstance(input_cpf, str) and input_cpf.strip():
        cpfs.append(input_cpf.strip())
    residuals = (event.get("witness") or {}).get("residuals") or []
    for residual in residuals:
        if not isinstance(residual, dict):
            continue
        cpf = residual.get("cpf")
        if isinstance(cpf, str) and cpf.strip():
            cpfs.append(cpf.strip())
    return cpfs


def collect_distinct_cpf_inputs(args: argparse.Namespace) -> tuple[dict[str, str], Counter[str]]:
    distinct: dict[str, str] = {}
    stats: Counter[str] = Counter()
    started = time.monotonic()
    for input_path in args.input:
        stats["input_files"] += 1
        with open_text(input_path) as source:
            for line in source:
                stats["scan_event_rows"] += 1
                try:
                    event = json.loads(line)
                except json.JSONDecodeError:
                    stats["scan_bad_json"] += 1
                    continue
                embedded = embedded_state_cpfs(event)
                if not embedded:
                    stats["scan_missing_cpf"] += 1
                    continue
                for cpf in embedded:
                    raw_key = hashlib.sha256(cpf.encode("utf-8")).hexdigest()
                    if raw_key in distinct:
                        stats["scan_cache_hits"] += 1
                    else:
                        distinct[raw_key] = cpf
                        stats["scan_distinct_cpf"] += 1
                if (
                    args.progress_every > 0
                    and stats["scan_event_rows"] % args.progress_every == 0
                ):
                    print(
                        "canonicalization-scan-progress "
                        f"rows={stats['scan_event_rows']} "
                        f"distinct_cpf={len(distinct)} "
                        f"elapsed={time.monotonic() - started:.1f}s",
                        file=sys.stderr,
                        flush=True,
                    )
                if args.limit is not None and stats["scan_event_rows"] >= args.limit:
                    return distinct, stats
    return distinct, stats


def open_persistent_canonical_cache(path: Path) -> sqlite3.Connection:
    path.parent.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(path)
    conn.execute("PRAGMA journal_mode=WAL")
    conn.execute("PRAGMA synchronous=NORMAL")
    conn.execute(
        """
        CREATE TABLE IF NOT EXISTS canonical_cpf_cache (
            raw_key TEXT PRIMARY KEY,
            backend_id TEXT NOT NULL DEFAULT 'legacy-unknown',
            canonical_cpf TEXT NOT NULL,
            note TEXT,
            elapsed_ms INTEGER NOT NULL,
            raw_bytes INTEGER NOT NULL,
            canonical_bytes INTEGER NOT NULL,
            created_at TEXT NOT NULL,
            updated_at TEXT NOT NULL
        )
        """
    )
    columns = {
        row[1]
        for row in conn.execute("PRAGMA table_info(canonical_cpf_cache)").fetchall()
    }
    if "backend_id" not in columns:
        conn.execute(
            "ALTER TABLE canonical_cpf_cache "
            "ADD COLUMN backend_id TEXT NOT NULL DEFAULT 'legacy-unknown'"
        )
    conn.execute("CREATE INDEX IF NOT EXISTS canonical_cpf_cache_note_idx ON canonical_cpf_cache(note)")
    conn.commit()
    return conn


def canonicalizer_backend_id(executable: Path | None) -> str:
    """Content-address the implementation that defines canonical CPF keys.

    Raw CPF alone is not a sufficient persistent-cache key: changing Ferrum's
    canonicalizer can legitimately change the canonical state.  Keeping the
    implementation digest beside each entry prevents an old cache from
    silently restoring obsolete oracle keys.
    """
    source = executable if executable is not None else Path(__file__)
    digest = hashlib.sha256(source.read_bytes()).hexdigest()
    kind = "ferrum" if executable is not None else "python"
    return f"{kind}-sha256:{digest}"


def iter_canonicalization_results(
    items: list[tuple[str, str, float, str | None]],
    jobs: int,
) -> Any:
    if jobs <= 1:
        for item in items:
            yield canonicalize_worker(item)
        return

    queue: mp.Queue = mp.Queue()
    pending = list(items)
    active: dict[int, tuple[mp.Process, float, str, str, float, Path]] = {}
    with tempfile.TemporaryDirectory(prefix="ferrum-canonical-cpf-") as temporary:
        temporary_dir = Path(temporary)
        try:
            while pending or active:
                while pending and len(active) < jobs:
                    raw_key, cpf, timeout_seconds, ferrum_canonicalizer = pending.pop(0)
                    output_path = temporary_dir / f"{raw_key}.xml"
                    process = mp.Process(
                        target=canonicalize_process_target,
                        args=(
                            raw_key,
                            cpf,
                            str(output_path),
                            queue,
                            timeout_seconds,
                            ferrum_canonicalizer,
                        ),
                    )
                    process.start()
                    active[process.pid or -1] = (
                        process,
                        time.monotonic(),
                        raw_key,
                        cpf,
                        timeout_seconds,
                        output_path,
                    )

                while True:
                    try:
                        raw_key, note, elapsed = queue.get_nowait()
                    except Exception:
                        break
                    for pid, (
                        process,
                        _,
                        active_key,
                        cpf,
                        _,
                        output_path,
                    ) in list(active.items()):
                        if active_key == raw_key:
                            process.join(timeout=0.1)
                            active.pop(pid, None)
                            canonical = (
                                output_path.read_text(encoding="utf-8")
                                if output_path.exists()
                                else cpf
                            )
                            output_path.unlink(missing_ok=True)
                            yield raw_key, canonical, note, elapsed
                            break

                now = time.monotonic()
                for pid, (
                    process,
                    started,
                    raw_key,
                    cpf,
                    timeout_seconds,
                    output_path,
                ) in list(active.items()):
                    if not process.is_alive():
                        process.join(timeout=0.1)
                        active.pop(pid, None)
                        output_path.unlink(missing_ok=True)
                        yield (
                            raw_key,
                            cpf,
                            f"failed-ProcessExit:{process.exitcode}",
                            now - started,
                        )
                        continue
                    if now - started > timeout_seconds:
                        process.terminate()
                        process.join(timeout=5.0)
                        if process.is_alive():
                            process.kill()
                            process.join(timeout=1.0)
                        active.pop(pid, None)
                        output_path.unlink(missing_ok=True)
                        yield (
                            raw_key,
                            cpf,
                            "failed-CanonicalizationTimeout:CPF input canonicalization timed out",
                            now - started,
                        )
                if active and not pending:
                    time.sleep(0.05)
                elif active:
                    time.sleep(0.01)
        finally:
            for process, _, _, _, _, output_path in active.values():
                if process.is_alive():
                    process.terminate()
                    process.join(timeout=1.0)
                    if process.is_alive():
                        process.kill()
                output_path.unlink(missing_ok=True)


def build_canonical_cache(args: argparse.Namespace) -> tuple[dict[str, tuple[str, str | None]], Counter[str]]:
    distinct, stats = collect_distinct_cpf_inputs(args)
    started = time.monotonic()
    cache: dict[str, tuple[str, str | None]] = {}
    slowest: list[tuple[float, str, int, str | None]] = []
    persistent_conn = open_persistent_canonical_cache(args.canonical_cache)
    backend_id = canonicalizer_backend_id(args.ferrum_canonicalizer)
    missing: dict[str, str] = {}
    for raw_key, cpf in distinct.items():
        cached = persistent_conn.execute(
            "SELECT canonical_cpf, note FROM canonical_cpf_cache "
            "WHERE raw_key = ? AND backend_id = ?",
            (raw_key, backend_id),
        ).fetchone()
        if cached is None:
            missing[raw_key] = cpf
        elif args.retry_failed_canonical_cache and cached[1] is not None and str(cached[1]).startswith("failed-"):
            missing[raw_key] = cpf
            stats["persistent_cache_failed_retries"] += 1
        else:
            cache[raw_key] = (cached[0], cached[1])
            stats["persistent_cache_hits"] += 1
    stats["persistent_cache_misses"] = len(missing)
    print(
        "canonicalization-cache "
        f"path={args.canonical_cache} "
        f"distinct_cpf={len(distinct)} "
        f"hits={stats['persistent_cache_hits']} "
        f"misses={stats['persistent_cache_misses']}",
        file=sys.stderr,
        flush=True,
    )
    jobs = max(1, args.canonicalization_jobs)
    items = [
        (
            raw_key,
            cpf,
            args.canonicalization_timeout_seconds,
            str(args.ferrum_canonicalizer) if args.ferrum_canonicalizer else None,
        )
        for raw_key, cpf in missing.items()
    ]
    iterator = iter_canonicalization_results(items, jobs)
    try:
        for index, (raw_key, canonical, note, elapsed) in enumerate(iterator, 1):
            cache[raw_key] = (canonical, note)
            persistent_conn.execute(
                """
                INSERT INTO canonical_cpf_cache(
                    raw_key, backend_id, canonical_cpf, note, elapsed_ms, raw_bytes,
                    canonical_bytes, created_at, updated_at
                ) VALUES (?, ?, ?, ?, ?, ?, ?, strftime('%Y-%m-%dT%H:%M:%fZ','now'), strftime('%Y-%m-%dT%H:%M:%fZ','now'))
                ON CONFLICT(raw_key) DO UPDATE SET
                    backend_id = excluded.backend_id,
                    canonical_cpf = excluded.canonical_cpf,
                    note = excluded.note,
                    elapsed_ms = excluded.elapsed_ms,
                    raw_bytes = excluded.raw_bytes,
                    canonical_bytes = excluded.canonical_bytes,
                    updated_at = excluded.updated_at
                """,
                (
                    raw_key,
                    backend_id,
                    canonical,
                    note,
                    int(elapsed * 1000),
                    len(missing[raw_key]),
                    len(canonical),
                ),
            )
            if note is None:
                stats["precanonicalized_ok"] += 1
            else:
                stats[f"precanonicalized_{note}"] += 1
                if str(note).startswith("failed-"):
                    stats["precanonicalized_failed"] += 1
            slowest.append((elapsed, raw_key, len(distinct[raw_key]), note))
            slowest.sort(reverse=True, key=lambda row: row[0])
            slowest = slowest[:10]
            if (
                args.canonicalization_progress_every > 0
                and index % args.canonicalization_progress_every == 0
            ):
                persistent_conn.commit()
                print(
                    "canonicalization-progress "
                    f"done={index}/{len(items)} "
                    f"jobs={jobs} "
                    f"ok={stats['precanonicalized_ok']} "
                    f"failed={stats['precanonicalized_failed']} "
                    f"elapsed={time.monotonic() - started:.1f}s "
                    f"max_item={slowest[0][0]:.3f}s",
                    file=sys.stderr,
                    flush=True,
                )
    finally:
        persistent_conn.commit()
        persistent_conn.close()
    stats["precanonicalized_distinct_cpf"] = len(cache)
    stats["precanonicalization_elapsed_seconds"] = round(time.monotonic() - started, 3)
    for index, (elapsed, raw_key, size, note) in enumerate(slowest):
        stats[f"precanonicalization_slowest_{index}_ms"] = int(elapsed * 1000)
        stats[f"precanonicalization_slowest_{index}_bytes"] = size
        if note is not None:
            stats[f"precanonicalization_slowest_{index}_note"] = note
        stats[f"precanonicalization_slowest_{index}_key"] = raw_key
    return cache, stats


def ingest_events(args: argparse.Namespace, conn: sqlite3.Connection) -> Counter[str]:
    stats: Counter[str] = Counter()
    started = time.monotonic()
    rejected_run_problem_keys: set[str] = set()
    quality_summary: dict[str, Any] | None = None
    if args.scan_run_quality:
        rejected_run_problem_keys, quality_summary = scan_event_log_quality(args)
        args._quality_summary = quality_summary
        print(
            "quality-scan "
            f"run_problems={quality_summary['run_problem_count']} "
            f"rejected={quality_summary['rejected_run_problem_count']} "
            f"elapsed={quality_summary['elapsed_seconds']}s",
            file=sys.stderr,
            flush=True,
        )
    canonical_cache: dict[str, tuple[str, str | None]] = {}
    raw_state_cpf: dict[str, str] = {}
    if args.canonicalize_inputs and args.canonicalization_jobs > 1:
        canonical_cache, pre_stats = build_canonical_cache(args)
        for key, value in pre_stats.items():
            if isinstance(value, (int, float)):
                stats[key] += value
            else:
                stats[key] = value

    def print_ingest_progress(reason: str) -> None:
        elapsed_s = time.monotonic() - started
        print(
            "ingest-progress "
            f"reason={reason} "
            f"rows={stats['event_rows']} "
            f"distinct_cpf={len(canonical_cache)} "
            f"attempt_obs={stats['attempt_observations']} "
            f"guidance_hard_neg={stats['guidance_hard_negative_observations']} "
            f"canonicalized={stats['canonicalized_inputs']} "
            f"canon_failures={stats['canonicalization_failed']} "
            f"elapsed={elapsed_s:.1f}s",
            file=sys.stderr,
            flush=True,
        )

    for input_path in args.input:
        stats["ingest_input_files"] += 1
        with open_text(input_path) as source:
            for line in source:
                stats["event_rows"] += 1
                try:
                    event = json.loads(line)
                except json.JSONDecodeError:
                    stats["bad_json"] += 1
                    continue
                if source_run_problem_key(input_path, event) in rejected_run_problem_keys:
                    stats["rejected_quality_rows"] += 1
                    continue
                event_input = event.get("input") or {}
                for embedded_cpf in embedded_state_cpfs(event):
                    embedded_key = hashlib.sha256(
                        embedded_cpf.encode("utf-8")
                    ).hexdigest()
                    raw_state_cpf[embedded_key] = embedded_cpf
                cpf = event_input.get("cpf")
                event_problem_key = event_input.get("problem_key")
                if isinstance(cpf, str) and cpf.strip():
                    cpf = cpf.strip()
                    raw_key = hashlib.sha256(cpf.encode("utf-8")).hexdigest()
                    raw_state_cpf[raw_key] = cpf
                    if isinstance(event_problem_key, str) and event_problem_key != raw_key:
                        stats["mismatched_content_address"] += 1
                        continue
                elif isinstance(event_problem_key, str):
                    raw_key = event_problem_key
                    cpf = raw_state_cpf.get(raw_key)
                    if cpf is None and raw_key in canonical_cache:
                        cpf = canonical_cache[raw_key][0]
                        stats["content_addressed_canonical_cache_hits"] += 1
                    elif cpf is not None:
                        stats["content_addressed_state_hits"] += 1
                    else:
                        stats["unresolved_content_address"] += 1
                        continue
                else:
                    stats["missing_cpf"] += 1
                    continue
                raw_cpf = cpf
                if args.canonicalize_inputs:
                    cached = canonical_cache.get(raw_key)
                    if cached is None:
                        cached = canonicalize_cpf_with_timeout(
                            cpf,
                            args.canonicalization_timeout_seconds,
                        )
                        if cached[1] is not None and str(cached[1]).startswith("failed-"):
                            stats["canonicalization_failed"] += 1
                        canonical_cache[raw_key] = cached
                        if (
                            args.canonicalization_progress_every > 0
                            and len(canonical_cache) % args.canonicalization_progress_every == 0
                        ):
                            conn.commit()
                            print_ingest_progress("canonicalization")
                    canonical_cpf, canonicalization_note = cached
                else:
                    canonical_cpf, canonicalization_note = cpf, None
                if args.canonicalize_inputs:
                    if canonicalization_note is None:
                        stats["canonicalized_inputs"] += 1
                    else:
                        stats[f"canonicalization_{canonicalization_note}"] += 1
                        if str(canonicalization_note).startswith("failed-"):
                            stats["canonicalization_fallback_inputs"] += 1
                cpf = canonical_cpf
                problem_key = hashlib.sha256(cpf.encode("utf-8")).hexdigest()
                rpk = run_problem_key(event, problem_key)
                occurrence = int(
                    event.get("processor") == "UtilityGuidance"
                    or event.get("strategy_atom") == "utility-guidance"
                )
                conn.execute(
                    """
                    INSERT INTO problems(
                        problem_key, cpf, first_problem_id, rows, occurrences,
                        validity_mask
                    )
                    VALUES (?, ?, ?, 1, ?, ?)
                    ON CONFLICT(problem_key) DO UPDATE SET
                        rows = rows + 1,
                        occurrences = occurrences + excluded.occurrences,
                        validity_mask = problems.validity_mask | excluded.validity_mask
                    """,
                    (
                        problem_key,
                        cpf,
                        event.get("problem_id"),
                        occurrence,
                        event_validity_mask(event),
                    ),
                )
                conn.execute(
                    """
                    INSERT INTO problem_aliases(raw_problem_key, problem_key)
                    VALUES (?, ?)
                    ON CONFLICT(raw_problem_key, problem_key) DO NOTHING
                    """,
                    (raw_key, problem_key),
                )
                structural_key = hashlib.sha256(
                    compact_xml_for_key(raw_cpf).encode("utf-8")
                ).hexdigest()
                conn.execute(
                    """
                    INSERT INTO problem_aliases(raw_problem_key, problem_key)
                    VALUES (?, ?)
                    ON CONFLICT(raw_problem_key, problem_key) DO NOTHING
                    """,
                    (structural_key, problem_key),
                )
                if structural_key != raw_key:
                    stats["structural_problem_aliases"] += 1
                runtime_raw_problem_key = event_input.get(
                    "runtime_raw_problem_key"
                )
                if isinstance(runtime_raw_problem_key, str) and len(
                    runtime_raw_problem_key
                ) == 64:
                    conn.execute(
                        """
                        INSERT INTO problem_aliases(raw_problem_key, problem_key)
                        VALUES (?, ?)
                        ON CONFLICT(raw_problem_key, problem_key) DO NOTHING
                        """,
                        (runtime_raw_problem_key, problem_key),
                    )
                    stats["runtime_raw_problem_aliases"] += 1
                bucket = bucket_for_event(corrected_event_outcome(event, stats), event.get("progress"))
                solved = 1 if bucket == "solved" else 0
                conn.execute(
                    """
                    INSERT INTO run_problems(run_problem_key, solved, rows)
                    VALUES (?, ?, 1)
                    ON CONFLICT(run_problem_key) DO UPDATE SET
                        solved = max(solved, excluded.solved),
                        rows = rows + 1
                    """,
                    (rpk, solved),
                )

                candidate = normalized_event_candidate(event)
                if candidate is not None and bucket is not None:
                    insert_observation(
                        conn,
                        problem_key,
                        rpk,
                        candidate,
                        bucket,
                        event.get("progress"),
                        event.get("elapsed_ms"),
                        "attempt",
                        event_is_certified(event),
                    )
                    stats["attempt_observations"] += 1
                elif candidate is None:
                    stats["missing_candidate"] += 1
                else:
                    stats["unknown_status"] += 1

                if (
                    args.include_guidance_hard_negatives
                    and event.get("processor") == "LlmGuidance"
                    and event.get("outcome") == "failed"
                ):
                    for atom in positive_guidance_atoms(event):
                        normalized = normalize_atom(atom)
                        if normalized is None:
                            stats["unparseable_guidance_atom"] += 1
                            continue
                        insert_observation(
                            conn,
                            problem_key,
                            rpk,
                            normalized,
                            "failed",
                            "none",
                            event.get("elapsed_ms"),
                            "guidance-hard-negative",
                        )
                        stats["guidance_hard_negative_observations"] += 1

                if (
                    args.progress_every > 0
                    and stats["event_rows"] % args.progress_every == 0
                ):
                    conn.commit()
                    print_ingest_progress("rows")
                if args.limit is not None and stats["event_rows"] >= args.limit:
                    conn.commit()
                    return stats
    conn.commit()
    return stats


def credited_status(
    raw_status: str,
    progress: str | None,
    run_solved: bool,
    certified: bool,
    args: argparse.Namespace,
) -> str:
    if not raw_status.startswith("transformed"):
        return raw_status
    if certified or args.credit_transforms_without_final_solved or run_solved:
        return raw_status
    return "failed"


def elapsed_penalty(elapsed_ms: int | None, args: argparse.Namespace) -> float:
    if elapsed_ms is None:
        return 0.0
    ms_per_point = max(args.utility_ms_per_point, 1.0)
    return min(float(elapsed_ms) / ms_per_point, args.utility_max_time_penalty)


def candidate_utility(aggregate: dict[str, Any], args: argparse.Namespace) -> float:
    weak_transforms = max(0, aggregate["transformed_count"] - aggregate["credited_transform_count"])
    score = 0.0
    score += aggregate["solved_count"] * STATUS_REWARD["solved"]
    score += aggregate["credited_transform_count"] * STATUS_REWARD["transformed_strong"]
    score += weak_transforms * STATUS_REWARD["transformed_weak"]
    score += aggregate["failed_count"] * STATUS_REWARD["failed"]
    score += aggregate["downgraded_transform_count"] * STATUS_REWARD["failed"]
    score += aggregate["hard_negative_count"] * args.utility_hard_negative_penalty
    score += aggregate["timeout_count"] * STATUS_REWARD["timeout"]
    score -= elapsed_penalty(aggregate["best_elapsed_ms"], args)
    return score


def credited_candidate_sort_key(row: sqlite3.Row) -> tuple[int, float, int, int, str]:
    rank = STATUS_RANK.get(row["best_status"], 0)
    utility = row["utility_score"] if row["utility_score"] is not None else 0.0
    elapsed = row["best_elapsed_ms"] if row["best_elapsed_ms"] is not None else 10**12
    attempts = row["attempts"] if row["attempts"] is not None else 0
    return (-rank, -utility, elapsed, attempts, row["candidate"])


DEFAULT_EXCLUDED_PROPOSAL_ATOMS = (
    "llm",
    "llm-guidance",
    "utility-guidance",
    "termination",
)


def credited_response_for_candidates(
    rows: list[sqlite3.Row],
    max_per_status: int,
    max_negative_per_status: int | None = None,
) -> tuple[str, Counter[str]]:
    by_status: dict[str, list[sqlite3.Row]] = {status: [] for status in STATUS_ORDER}
    for row in rows:
        status = row["best_status"]
        if status in by_status:
            by_status[status].append(row)
    counts = Counter({status: len(values) for status, values in by_status.items()})
    sections: list[str] = []
    for status in STATUS_ORDER:
        values = sorted(by_status[status], key=credited_candidate_sort_key)
        cap = max_per_status
        if status in {"failed", "timeout"} and max_negative_per_status is not None:
            cap = max_negative_per_status
        if cap > 0:
            values = values[:cap]
        if values:
            sections.append(status + ":\n" + "\n".join(row["candidate"] for row in values))
    return "\n\n".join(sections), counts


def proposal_atom_is_excluded(candidate: str, args: argparse.Namespace) -> bool:
    return candidate in args.exclude_proposal_atom


def positive_atom_counts(conn: sqlite3.Connection, args: argparse.Namespace) -> Counter[str]:
    counts: Counter[str] = Counter()
    for row in conn.execute(
        """
        SELECT candidate, COUNT(*) AS n
        FROM candidates
        WHERE best_status IN ('solved', 'transformed_strong', 'transformed_weak')
        GROUP BY candidate
        """
    ):
        if proposal_atom_is_excluded(row["candidate"], args):
            continue
        counts[row["candidate"]] = int(row["n"])
    return counts


def train_replication_factor(
    rows: list[sqlite3.Row],
    counts: Counter[str],
    args: argparse.Namespace,
) -> int:
    status_factor = 1
    statuses = {row["best_status"] for row in rows}
    if "solved" in statuses:
        status_factor = max(status_factor, args.solved_row_weight)
    if "transformed_weak" in statuses:
        status_factor = max(status_factor, args.transformed_weak_row_weight)
    if "transformed_strong" in statuses:
        status_factor = max(status_factor, args.transformed_strong_row_weight)
    if not args.balance_positive_atoms or not counts:
        return max(1, status_factor)
    positives = [
        row["candidate"]
        for row in rows
        if row["best_status"] in POSITIVE_STATUSES and row["candidate"] in counts
    ]
    if not positives:
        return max(1, status_factor)
    target = args.balance_target_per_atom if args.balance_target_per_atom > 0 else max(counts.values())
    atom_factor = max(
        (target + counts[candidate] - 1) // counts[candidate] for candidate in positives
    )
    atom_factor = min(args.balance_max_repeats, int(atom_factor))
    return max(1, status_factor, atom_factor)


def aggregate_candidates(
    args: argparse.Namespace,
    conn: sqlite3.Connection,
    touched_only: bool = False,
) -> Counter[str]:
    if touched_only:
        return aggregate_touched_candidates(args, conn)
    stats: Counter[str] = Counter()
    rows = conn.execute(
        """
        SELECT o.*, rp.solved AS run_solved
        FROM observations o
        JOIN run_problems rp ON rp.run_problem_key = o.run_problem_key
        ORDER BY o.problem_key, o.candidate_key
        """
    )
    current_key: tuple[str, str] | None = None
    aggregate: dict[str, Any] = {}

    def flush() -> None:
        nonlocal aggregate
        if not aggregate:
            return
        if (
            aggregate["solved_count"] == 0
            and aggregate["credited_transform_count"] == 0
            and aggregate["timeout_count"] > 0
        ):
            aggregate["best_status"] = "timeout"
            aggregate["best_rank"] = STATUS_RANK["timeout"]
        conn.execute(
            """
            INSERT INTO candidates(
                problem_key, candidate_key, candidate, best_status, best_rank,
                best_elapsed_ms, attempts, solved_count, transformed_count,
                failed_count, timeout_count, hard_negative_count,
                certified_count,
                credited_transform_count, downgraded_transform_count,
                utility_score
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """,
            (
                aggregate["problem_key"],
                aggregate["candidate_key"],
                aggregate["candidate"],
                aggregate["best_status"],
                aggregate["best_rank"],
                aggregate["best_elapsed_ms"],
                aggregate["attempts"],
                aggregate["solved_count"],
                aggregate["transformed_count"],
                aggregate["failed_count"],
                aggregate["timeout_count"],
                aggregate["hard_negative_count"],
                aggregate["certified_count"],
                aggregate["credited_transform_count"],
                aggregate["downgraded_transform_count"],
                candidate_utility(aggregate, args),
            ),
        )
        aggregate = {}

    for row in rows:
        key = (row["problem_key"], row["candidate_key"])
        if key != current_key:
            flush()
            current_key = key
            aggregate = {
                "problem_key": row["problem_key"],
                "candidate_key": row["candidate_key"],
                "candidate": row["candidate"],
                "best_status": "failed",
                "best_rank": STATUS_RANK["failed"],
                "best_elapsed_ms": None,
                "attempts": 0,
                "solved_count": 0,
                "transformed_count": 0,
                "failed_count": 0,
                "timeout_count": 0,
                "certified_count": 0,
                "hard_negative_count": 0,
                "credited_transform_count": 0,
                "downgraded_transform_count": 0,
            }
        raw_status = row["raw_status"]
        run_solved = bool(row["run_solved"])
        status = credited_status(
            raw_status,
            row["progress"],
            run_solved,
            bool(row["certified"]),
            args,
        )
        rank = STATUS_RANK[status]
        elapsed = row["elapsed_ms"]
        aggregate["attempts"] += 1
        if row["certified"]:
            aggregate["certified_count"] += 1
        if status == "solved":
            aggregate["solved_count"] += 1
        elif status.startswith("transformed"):
            aggregate["transformed_count"] += 1
        elif status == "failed":
            aggregate["failed_count"] += 1
        elif status == "timeout":
            aggregate["timeout_count"] += 1
        if row["source"] == "guidance-hard-negative":
            aggregate["hard_negative_count"] += 1
        if raw_status.startswith("transformed") and status.startswith("transformed"):
            aggregate["credited_transform_count"] += 1
            stats["credited_transform_observations"] += 1
        if raw_status.startswith("transformed") and status == "failed":
            aggregate["downgraded_transform_count"] += 1
            stats["downgraded_transform_observations"] += 1
        better = rank > aggregate["best_rank"]
        if rank == aggregate["best_rank"] and elapsed is not None:
            best_elapsed = aggregate["best_elapsed_ms"]
            better = best_elapsed is None or elapsed < best_elapsed
        if better:
            aggregate["best_status"] = status
            aggregate["best_rank"] = rank
            aggregate["best_elapsed_ms"] = elapsed
        stats["observations_aggregated"] += 1
        if (
            args.progress_every > 0
            and stats["observations_aggregated"] % args.progress_every == 0
        ):
            conn.commit()
            print(
                f"aggregate-progress observations={stats['observations_aggregated']}",
                file=sys.stderr,
                flush=True,
            )
    flush()
    conn.commit()
    return stats


def aggregate_touched_candidates(
    args: argparse.Namespace,
    conn: sqlite3.Connection,
) -> Counter[str]:
    """Rebuild only touched candidate groups with SQLite-side aggregation."""
    stats: Counter[str] = Counter()
    credit_all = int(args.credit_transforms_without_final_solved)
    effective_rank = f"""
        CASE
          WHEN o.raw_status = 'solved' THEN {STATUS_RANK['solved']}
          WHEN o.raw_status = 'transformed_strong'
               AND ({credit_all} != 0 OR rp.solved != 0)
            THEN {STATUS_RANK['transformed_strong']}
          WHEN o.raw_status = 'transformed_weak'
               AND ({credit_all} != 0 OR rp.solved != 0)
            THEN {STATUS_RANK['transformed_weak']}
          WHEN o.raw_status = 'timeout' THEN {STATUS_RANK['timeout']}
          ELSE {STATUS_RANK['failed']}
        END
    """
    rows = conn.execute(
        f"""
        SELECT
          o.problem_key,
          o.candidate_key,
          MAX(o.candidate) AS candidate,
          COUNT(*) AS attempts,
          SUM(o.certified != 0) AS certified_count,
          SUM(o.raw_status = 'solved') AS solved_count,
          SUM(o.raw_status LIKE 'transformed%'
              AND ({credit_all} != 0 OR rp.solved != 0)) AS transformed_count,
          SUM(
            o.raw_status = 'failed'
            OR (o.raw_status LIKE 'transformed%'
                AND {credit_all} = 0 AND rp.solved = 0)
          ) AS failed_count,
          SUM(o.raw_status = 'timeout') AS timeout_count,
          SUM(o.source = 'guidance-hard-negative') AS hard_negative_count,
          SUM(o.raw_status LIKE 'transformed%'
              AND ({credit_all} != 0 OR rp.solved != 0))
            AS credited_transform_count,
          SUM(o.raw_status LIKE 'transformed%'
              AND {credit_all} = 0 AND rp.solved = 0)
            AS downgraded_transform_count,
          MAX({effective_rank}) AS observed_best_rank,
          MIN(CASE WHEN ({effective_rank}) = {STATUS_RANK['solved']}
                   THEN o.elapsed_ms END) AS solved_elapsed,
          MIN(CASE WHEN ({effective_rank}) = {STATUS_RANK['transformed_strong']}
                   THEN o.elapsed_ms END) AS strong_elapsed,
          MIN(CASE WHEN ({effective_rank}) = {STATUS_RANK['transformed_weak']}
                   THEN o.elapsed_ms END) AS weak_elapsed,
          MIN(CASE WHEN ({effective_rank}) = {STATUS_RANK['failed']}
                   THEN o.elapsed_ms END) AS failed_elapsed,
          MIN(CASE WHEN ({effective_rank}) = {STATUS_RANK['timeout']}
                   THEN o.elapsed_ms END) AS timeout_elapsed
        FROM observations o
        JOIN temp.touched_problem_keys touched
          ON touched.problem_key = o.problem_key
        JOIN run_problems rp ON rp.run_problem_key = o.run_problem_key
        GROUP BY o.problem_key, o.candidate_key
        ORDER BY o.problem_key, o.candidate_key
        """
    )
    status_for_rank = {rank: status for status, rank in STATUS_RANK.items()}
    elapsed_column = {
        "solved": "solved_elapsed",
        "transformed_strong": "strong_elapsed",
        "transformed_weak": "weak_elapsed",
        "failed": "failed_elapsed",
        "timeout": "timeout_elapsed",
    }
    for row in rows:
        aggregate = dict(row)
        best_rank = max(int(row["observed_best_rank"]), STATUS_RANK["failed"])
        best_status = status_for_rank[best_rank]
        best_elapsed_ms = row[elapsed_column[best_status]]
        if (
            row["solved_count"] == 0
            and row["credited_transform_count"] == 0
            and row["timeout_count"] > 0
        ):
            best_status = "timeout"
            best_rank = STATUS_RANK["timeout"]
        aggregate["best_status"] = best_status
        aggregate["best_rank"] = best_rank
        aggregate["best_elapsed_ms"] = best_elapsed_ms
        conn.execute(
            """
            INSERT INTO candidates(
                problem_key, candidate_key, candidate, best_status, best_rank,
                best_elapsed_ms, attempts, solved_count, transformed_count,
                failed_count, timeout_count, hard_negative_count,
                certified_count, credited_transform_count,
                downgraded_transform_count, utility_score
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """,
            (
                row["problem_key"],
                row["candidate_key"],
                row["candidate"],
                best_status,
                best_rank,
                aggregate["best_elapsed_ms"],
                row["attempts"],
                row["solved_count"],
                row["transformed_count"],
                row["failed_count"],
                row["timeout_count"],
                row["hard_negative_count"],
                row["certified_count"],
                row["credited_transform_count"],
                row["downgraded_transform_count"],
                candidate_utility(aggregate, args),
            ),
        )
        stats["candidate_groups_aggregated"] += 1
        stats["observations_aggregated"] += int(row["attempts"])
        stats["credited_transform_observations"] += int(
            row["credited_transform_count"]
        )
        stats["downgraded_transform_observations"] += int(
            row["downgraded_transform_count"]
        )
    conn.commit()
    return stats


def normalize_observation_candidates(
    conn: sqlite3.Connection,
    touched_only: bool = False,
) -> int:
    touched_join = (
        "JOIN temp.touched_problem_keys touched USING(problem_key)"
        if touched_only
        else ""
    )
    replacements = []
    for (candidate,) in conn.execute(
        f"""
        SELECT DISTINCT candidate
        FROM observations
        {touched_join}
        ORDER BY candidate
        """
    ):
        normalized = normalize_atom(candidate)
        if normalized is not None and normalized != candidate:
            replacements.append((normalized, normalized, candidate))
    if touched_only:
        conn.executemany(
            """
            UPDATE observations
            SET candidate = ?, candidate_key = ?
            WHERE candidate = ?
              AND problem_key IN (SELECT problem_key FROM temp.touched_problem_keys)
            """,
            replacements,
        )
    else:
        conn.executemany(
            """
            UPDATE observations
            SET candidate = ?, candidate_key = ?
            WHERE candidate = ?
            """,
            replacements,
        )
    conn.commit()
    return len(replacements)


def export_rows(args: argparse.Namespace, conn: sqlite3.Connection) -> Counter[str]:
    def split_path(split: str) -> Path:
        return args.out_prefix.parent / f"{args.out_prefix.name}.{split}.jsonl.gz"

    outputs = {
        "train": open_output(split_path("train")),
        "validation": open_output(split_path("validation")),
        "test": open_output(split_path("test")),
    }
    stats: Counter[str] = Counter()
    bucket_counts: Counter[str] = Counter()
    hard_negative_candidates = 0
    utility_by_status: Counter[str] = Counter()
    positive_counts = positive_atom_counts(conn, args)
    rarest_positive_atoms = sorted(positive_counts.items(), key=lambda item: (item[1], item[0]))[:50]
    try:
        problem_rows = conn.execute("SELECT problem_key, cpf FROM problems ORDER BY problem_key")
        for problem in problem_rows:
            rows = conn.execute(
                """
                SELECT * FROM candidates WHERE problem_key = ?
                ORDER BY best_rank DESC, utility_score DESC,
                         best_elapsed_ms ASC, attempts ASC, candidate ASC
                """,
                (problem["problem_key"],),
            ).fetchall()
            excluded = [row for row in rows if proposal_atom_is_excluded(row["candidate"], args)]
            if excluded:
                stats["excluded_candidate_instances"] += len(excluded)
                for row in excluded:
                    stats[f"excluded_atom/{row['candidate']}"] += 1
            rows = [row for row in rows if not proposal_atom_is_excluded(row["candidate"], args)]
            if not rows:
                continue
            counts = Counter(row["best_status"] for row in rows)
            has_positive = any(counts[status] for status in POSITIVE_STATUSES)
            if args.require_positive and not has_positive:
                stats["skipped_no_positive"] += 1
                continue
            split = split_for_id(problem["problem_key"], args.validation_pct, args.test_pct)
            train_negative_cap = (
                args.train_max_negative_per_status
                if split == "train" and has_positive
                else None
            )
            response, full_counts = credited_response_for_candidates(
                rows,
                args.max_per_status,
                train_negative_cap,
            )
            if not response:
                stats["skipped_empty_response"] += 1
                continue
            row_json = json.dumps(
                {
                    "condition": args.condition,
                    "instruction": wrap_input(problem["cpf"]),
                    "response": response,
                },
                sort_keys=True,
            ) + "\n"
            repeats = train_replication_factor(rows, positive_counts, args) if split == "train" else 1
            for _ in range(repeats):
                outputs[split].write(row_json)
            stats[f"{split}_rows"] += repeats
            stats["output_rows"] += repeats
            stats[f"{split}_source_rows"] += 1
            if has_positive:
                stats[f"{split}_positive_source_rows"] += 1
                stats[f"{split}_positive_effective_rows"] += repeats
            else:
                stats[f"{split}_negative_only_source_rows"] += 1
                stats[f"{split}_negative_only_effective_rows"] += repeats
            for status in POSITIVE_STATUSES:
                if counts[status]:
                    stats[f"{split}_{status}_source_rows"] += 1
                    stats[f"{split}_{status}_effective_rows"] += repeats
            if repeats > 1:
                stats["train_oversampled_extra_rows"] += repeats - 1
                stats["train_oversampled_source_rows"] += 1
            for status, count in full_counts.items():
                bucket_counts[f"{status}_candidates"] += count
            for row in rows:
                utility_by_status[f"{row['best_status']}_utility_sum"] += row["utility_score"]
            hard_negative_candidates += sum(1 for row in rows if row["hard_negative_count"] > 0)
            if (
                args.progress_every > 0
                and stats["output_rows"] % args.progress_every == 0
            ):
                print(f"export-progress rows={stats['output_rows']}", file=sys.stderr, flush=True)
    finally:
        for output in outputs.values():
            output.close()
    stats.update(bucket_counts)
    stats.update(utility_by_status)
    stats["hard_negative_candidates"] = hard_negative_candidates
    stats["positive_atom_count"] = len(positive_counts)
    stats["positive_atom_max_rows"] = max(positive_counts.values(), default=0)
    stats["rarest_positive_atoms"] = rarest_positive_atoms
    return stats


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--input",
        type=Path,
        nargs="+",
        required=True,
        help="one or more processor-event JSONL/JSONL.gz files",
    )
    parser.add_argument("--out-prefix", type=Path, required=True, help="output prefix without split suffix")
    parser.add_argument("--sqlite", type=Path, required=True, help="temporary/materialized SQLite database")
    parser.add_argument("--summary", type=Path, required=True)
    parser.add_argument("--condition", default="direct")
    parser.add_argument("--validation-pct", type=int, default=5)
    parser.add_argument("--test-pct", type=int, default=5)
    parser.add_argument("--max-per-status", type=int, default=16)
    parser.add_argument("--progress-every", type=int, default=100000)
    parser.add_argument("--limit", type=int)
    parser.add_argument("--keep-sqlite", action="store_true")
    parser.add_argument("--require-positive", action="store_true")
    parser.add_argument(
        "--scan-run-quality",
        action=argparse.BooleanOptionalAction,
        default=True,
        help="pre-scan event logs and report suspicious low-diversity run/problem groups",
    )
    parser.add_argument(
        "--reject-suspicious-runs",
        action=argparse.BooleanOptionalAction,
        default=True,
        help="skip run/problem groups whose state signatures indicate stale original-CPF logging",
    )
    parser.add_argument("--quality-min-rows", type=int, default=12)
    parser.add_argument("--quality-min-states", type=int, default=3)
    parser.add_argument("--quality-max-cpf-for-state-mismatch", type=int, default=1)
    parser.add_argument("--quality-state-cpf-ratio", type=int, default=4)
    parser.add_argument("--quality-examples", type=int, default=40)
    parser.add_argument(
        "--balance-positive-atoms",
        action=argparse.BooleanOptionalAction,
        default=True,
        help="oversample train rows containing rare positive processor atoms",
    )
    parser.add_argument(
        "--balance-target-per-atom",
        type=int,
        default=0,
        help="target positive rows per atom; 0 means use the most frequent positive atom count",
    )
    parser.add_argument(
        "--balance-max-repeats",
        type=int,
        default=16,
        help="maximum train-row replication factor for rare positive atoms",
    )
    parser.add_argument(
        "--solved-row-weight",
        type=int,
        default=1,
        help="minimum replication factor for train rows containing solved candidates",
    )
    parser.add_argument(
        "--transformed-strong-row-weight",
        type=int,
        default=1,
        help="minimum replication factor for train rows containing strong transformations",
    )
    parser.add_argument(
        "--transformed-weak-row-weight",
        type=int,
        default=1,
        help="minimum replication factor for train rows containing weak transformations",
    )
    parser.add_argument(
        "--train-max-negative-per-status",
        type=int,
        default=0,
        help=(
            "cap failed and timeout atoms on positive train rows; "
            "0 preserves --max-per-status"
        ),
    )
    parser.add_argument(
        "--exclude-proposal-atom",
        action="append",
        default=list(DEFAULT_EXCLUDED_PROPOSAL_ATOMS),
        help="candidate atom to omit from all exported status maps; repeatable",
    )
    parser.add_argument(
        "--reuse-sqlite",
        action="store_true",
        help="reuse an existing fully aggregated SQLite database and only export rows",
    )
    parser.add_argument(
        "--append-sqlite",
        action="store_true",
        help=(
            "append only --input events to an existing database, then rebuild "
            "candidate aggregates and exports"
        ),
    )
    parser.add_argument(
        "--skip-row-export",
        action="store_true",
        help="update the SQLite corpus without rewriting SFT JSONL row exports",
    )
    parser.add_argument(
        "--canonicalize-inputs",
        action=argparse.BooleanOptionalAction,
        default=True,
        help="canonicalize CPF inputs, including combined TRS+DP inputs, before grouping/export",
    )
    parser.add_argument(
        "--canonicalization-timeout-seconds",
        type=float,
        default=60.0,
        help="per-distinct-CPF timeout for exact/SMT canonicalization",
    )
    parser.add_argument(
        "--canonicalization-jobs",
        type=int,
        default=8,
        help="parallel worker processes for the distinct-CPF canonicalization prepass",
    )
    parser.add_argument(
        "--ferrum-canonicalizer",
        type=Path,
        help=(
            "Ferrum executable whose canonicalize-cpf command defines production "
            "oracle keys; use a dedicated --canonical-cache for this backend"
        ),
    )
    parser.add_argument(
        "--canonical-cache",
        type=Path,
        default=Path("target/termcomp-proof-corpus/training/canonical-cpf-cache.sqlite"),
        help="persistent SQLite cache keyed by raw CPF SHA-256",
    )
    parser.add_argument(
        "--retry-failed-canonical-cache",
        action="store_true",
        help="recompute persistent canonical-cache entries whose previous note starts with failed-",
    )
    parser.add_argument(
        "--canonicalization-progress-every",
        type=int,
        default=100,
        help="print ingest progress after this many distinct CPF canonicalizations",
    )
    parser.add_argument(
        "--utility-ms-per-point",
        type=float,
        default=1000.0,
        help="milliseconds corresponding to one utility point of time penalty",
    )
    parser.add_argument(
        "--utility-max-time-penalty",
        type=float,
        default=300.0,
        help="cap for the elapsed-time utility penalty per candidate",
    )
    parser.add_argument(
        "--utility-hard-negative-penalty",
        type=float,
        default=-200.0,
        help="penalty per failed positive atom predicted by LLM guidance",
    )
    parser.add_argument(
        "--credit-transforms-without-final-solved",
        action="store_true",
        help="keep transformed attempts positive even when their run/problem has no solved event",
    )
    parser.add_argument(
        "--include-guidance-hard-negatives",
        action=argparse.BooleanOptionalAction,
        default=True,
        help="add failed LlmGuidance positive predictions as hard-negative observations",
    )
    args = parser.parse_args()

    args.sqlite.parent.mkdir(parents=True, exist_ok=True)
    args.out_prefix.parent.mkdir(parents=True, exist_ok=True)
    if args.train_max_negative_per_status <= 0:
        args.train_max_negative_per_status = args.max_per_status
    if args.reuse_sqlite and args.append_sqlite:
        parser.error("--reuse-sqlite and --append-sqlite are mutually exclusive")
    if (args.reuse_sqlite or args.append_sqlite) and not args.sqlite.exists():
        parser.error(f"--reuse-sqlite database does not exist: {args.sqlite}")
    if not args.reuse_sqlite and not args.append_sqlite and args.sqlite.exists():
        args.sqlite.unlink()
    conn = sqlite3.connect(args.sqlite)
    conn.row_factory = sqlite3.Row
    conn.execute(
        "CREATE TEMP TABLE touched_problem_keys(problem_key TEXT PRIMARY KEY)"
    )
    if args.reuse_sqlite:
        ingest_stats = Counter({"reused_sqlite": 1})
        aggregate_stats = Counter({"reused_sqlite": 1})
    else:
        create_schema(conn)
        ingest_stats = ingest_events(args, conn)
        ingest_stats["normalized_historical_candidate_spellings"] = (
            normalize_observation_candidates(conn, touched_only=args.append_sqlite)
        )
        if args.append_sqlite:
            conn.execute(
                """
                DELETE FROM candidates
                WHERE problem_key IN (
                    SELECT problem_key FROM temp.touched_problem_keys
                )
                """
            )
            conn.commit()
        aggregate_stats = aggregate_candidates(
            args,
            conn,
            touched_only=args.append_sqlite,
        )
    problem_count = conn.execute("SELECT COUNT(*) FROM problems").fetchone()[0]
    run_problem_count = conn.execute("SELECT COUNT(*) FROM run_problems").fetchone()[0]
    solved_run_problem_count = conn.execute(
        "SELECT COUNT(*) FROM run_problems WHERE solved != 0"
    ).fetchone()[0]
    candidate_count = conn.execute("SELECT COUNT(*) FROM candidates").fetchone()[0]
    export_stats = (
        Counter({"skipped": 1}) if args.skip_row_export else export_rows(args, conn)
    )
    summary = {
        "input": [str(path) for path in args.input],
        "out_prefix": str(args.out_prefix),
        "sqlite": str(args.sqlite),
        "condition": args.condition,
        "validation_pct": args.validation_pct,
        "test_pct": args.test_pct,
        "max_per_status": args.max_per_status,
        "canonicalize_inputs": args.canonicalize_inputs,
        "canonicalization_timeout_seconds": args.canonicalization_timeout_seconds,
        "canonicalization_jobs": args.canonicalization_jobs,
        "canonical_cache": str(args.canonical_cache),
        "canonicalization_progress_every": args.canonicalization_progress_every,
        "utility_ms_per_point": args.utility_ms_per_point,
        "utility_max_time_penalty": args.utility_max_time_penalty,
        "utility_hard_negative_penalty": args.utility_hard_negative_penalty,
        "require_positive": args.require_positive,
        "scan_run_quality": args.scan_run_quality,
        "reject_suspicious_runs": args.reject_suspicious_runs,
        "quality": getattr(args, "_quality_summary", None),
        "balance_positive_atoms": args.balance_positive_atoms,
        "balance_target_per_atom": args.balance_target_per_atom,
        "balance_max_repeats": args.balance_max_repeats,
        "solved_row_weight": args.solved_row_weight,
        "transformed_strong_row_weight": args.transformed_strong_row_weight,
        "transformed_weak_row_weight": args.transformed_weak_row_weight,
        "train_max_negative_per_status": args.train_max_negative_per_status,
        "exclude_proposal_atom": args.exclude_proposal_atom,
        "reuse_sqlite": args.reuse_sqlite,
        "append_sqlite": args.append_sqlite,
        "include_guidance_hard_negatives": args.include_guidance_hard_negatives,
        "credit_transforms_without_final_solved": args.credit_transforms_without_final_solved,
        "problem_count": problem_count,
        "run_problem_count": run_problem_count,
        "solved_run_problem_count": solved_run_problem_count,
        "candidate_count": candidate_count,
        "ingest": dict(ingest_stats),
        "aggregate": dict(aggregate_stats),
        "export": dict(export_stats),
    }
    args.summary.parent.mkdir(parents=True, exist_ok=True)
    args.summary.write_text(json.dumps(summary, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    print(json.dumps(summary, indent=2, sort_keys=True), flush=True)
    conn.close()
    if (
        not args.reuse_sqlite
        and not args.append_sqlite
        and not args.keep_sqlite
        and args.sqlite.exists()
    ):
        args.sqlite.unlink()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
