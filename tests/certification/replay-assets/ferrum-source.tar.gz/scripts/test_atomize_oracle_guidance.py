import unittest

from atomize_oracle_guidance import atomize, migrate_record


class AtomizeOracleGuidanceTests(unittest.TestCase):
    def test_single_nontermination_timeout_becomes_one_processor_atom(self) -> None:
        self.assertEqual(
            atomize("nontermination(timeout(6000ms,rule-subset-narrowing))"),
            ("nontermination(rule-subset-narrowing)", True),
        )

    def test_removes_scheduler_aliases_that_are_not_processors(self) -> None:
        for candidate in ("fast-dp", "termination", "nontermination"):
            self.assertEqual(atomize(candidate), (None, False))

    def test_keeps_root_processor_and_drops_continuation(self):
        self.assertEqual(atomize("dp(graph;size-change)"), ("dp", True))
        self.assertEqual(
            atomize("csr-improved-dp(graph;size-change)"),
            ("csr-improved-dp", True),
        )

    def test_exact_witness_is_not_classified_as_composition(self):
        candidate = "exact-matrix(hex=aa;bb)"
        self.assertEqual(atomize(candidate), (candidate, False))

    def test_migrated_wrapper_is_a_transformation(self):
        row, changed, removed = migrate_record({
            "prefer": [{
                "candidate": "dp(graph;size-change)",
                "status": "solved",
                "solved_count": 1,
                "transformed_count": 0,
                "certified_count": 1,
            }]
        })
        self.assertEqual((changed, removed), (1, 0))
        self.assertEqual(row["prefer"][0]["candidate"], "dp")
        self.assertEqual(row["prefer"][0]["status"], "transformed_strong")
        self.assertEqual(row["prefer"][0]["solved_count"], 0)


if __name__ == "__main__":
    unittest.main()
