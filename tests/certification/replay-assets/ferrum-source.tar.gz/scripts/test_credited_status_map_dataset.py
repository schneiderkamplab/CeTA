#!/usr/bin/env python3

import json
import os
import unittest
import xml.etree.ElementTree as ET
import sqlite3
import tempfile
import queue
from pathlib import Path

from build_credited_status_map_dataset import (
    DEFAULT_EXCLUDED_PROPOSAL_ATOMS,
    canonicalize_dp_source_provenance,
    canonicalize_cpf_input,
    canonicalize_process_target,
    canonicalizer_backend_id,
    compact_xml_for_key,
    embedded_state_cpfs,
    input_rule_blocks,
    normalized_event_candidate,
    open_persistent_canonical_cache,
    sort_rule_blocks,
)
from build_hrm_status_map_dataset import normalize_atom
from build_hrm_strategy_direct_dataset import strategy_from_xml
from build_retained_root_aliases import normalized_problem_id
from extract_exact_fragment_training_data import iter_exact_rows
from export_utility_guidance_lookup import candidate_evidence
from rank_external_proof_exploration import expand_rule_indices


class ProcessorAtomNormalizationTest(unittest.TestCase):
    def test_embedded_state_cpfs_include_materialized_residuals(self) -> None:
        event = {
            "input": {"cpf": " <trsInput /> "},
            "witness": {
                "residuals": [
                    {"cpf": " <dpInput /> "},
                    {"problem_key": "content-address-only"},
                ]
            },
        }

        self.assertEqual(
            embedded_state_cpfs(event),
            ["<trsInput />", "<dpInput />"],
        )

    def test_persistent_canonical_cache_records_backend_identity(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            cache = Path(directory) / "canonical.sqlite"
            with sqlite3.connect(cache) as connection:
                connection.execute(
                    "CREATE TABLE canonical_cpf_cache("
                    "raw_key TEXT PRIMARY KEY, canonical_cpf TEXT NOT NULL, "
                    "note TEXT, elapsed_ms INTEGER NOT NULL, raw_bytes INTEGER NOT NULL, "
                    "canonical_bytes INTEGER NOT NULL, created_at TEXT NOT NULL, "
                    "updated_at TEXT NOT NULL)"
                )
            connection = open_persistent_canonical_cache(cache)
            columns = {
                row[1]
                for row in connection.execute(
                    "PRAGMA table_info(canonical_cpf_cache)"
                )
            }
            connection.close()

            self.assertIn("backend_id", columns)

    def test_canonicalizer_backend_identity_changes_with_executable(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            executable = Path(directory) / "canonicalizer"
            executable.write_bytes(b"one")
            first = canonicalizer_backend_id(executable)
            executable.write_bytes(b"two")
            second = canonicalizer_backend_id(executable)

            self.assertNotEqual(first, second)

    def test_structural_key_compaction_matches_indented_xml(self) -> None:
        compact = "<trsInput><trs><rules /></trs></trsInput>"
        indented = "<trsInput>\n  <trs>\n    <rules />\n  </trs>\n</trsInput>"
        self.assertEqual(compact_xml_for_key(compact), compact_xml_for_key(indented))

    def test_structural_key_compaction_matches_apostrophe_entities(self) -> None:
        self.assertEqual(
            compact_xml_for_key("<name>|f&apos;|</name>"),
            compact_xml_for_key("<name>|f'|</name>"),
        )

    def test_runtime_guidance_wrapper_is_not_an_executable_proposal(self) -> None:
        self.assertIn("utility-guidance", DEFAULT_EXCLUDED_PROPOSAL_ATOMS)

    def test_parallel_canonicalizer_transfers_payload_by_file(self) -> None:
        cpf = (
            "<trsInput><trs><rules><rule><funapp><name>f</name></funapp>"
            "<funapp><name>g</name></funapp></rule></rules></trs></trsInput>"
        )
        messages: queue.Queue = queue.Queue()
        with tempfile.TemporaryDirectory() as directory:
            output = Path(directory) / "canonical.xml"
            canonicalize_process_target("raw", cpf, str(output), messages)
            raw_key, note, elapsed = messages.get_nowait()

            self.assertEqual(raw_key, "raw")
            self.assertIsNone(note)
            self.assertGreaterEqual(elapsed, 0)
            self.assertEqual(
                output.read_text(encoding="utf-8"),
                canonicalize_cpf_input(cpf)[0],
            )

    def test_parallel_canonicalizer_can_use_production_ferrum_backend(self) -> None:
        messages: queue.Queue = queue.Queue()
        with tempfile.TemporaryDirectory() as directory:
            executable = Path(directory) / "ferrum-canonicalizer"
            executable.write_text(
                "#!/bin/sh\nprintf '<trsInput><trs><rules /></trs></trsInput>\\n'\n",
                encoding="utf-8",
            )
            os.chmod(executable, 0o700)
            output = Path(directory) / "canonical.xml"
            canonicalize_process_target(
                "raw",
                "<trsInput />",
                str(output),
                messages,
                1.0,
                str(executable),
            )
            raw_key, note, _ = messages.get_nowait()

            self.assertEqual(raw_key, "raw")
            self.assertIsNone(note)
            self.assertEqual(
                output.read_text(encoding="utf-8"),
                "<trsInput><trs><rules /></trs></trsInput>",
            )

    def test_cpf_canonicalization_ignores_indentation_whitespace(self) -> None:
        compact = (
            "<trsInput><trs><rules><rule><funapp><name>f</name></funapp>"
            "<funapp><name>g</name></funapp></rule></rules></trs></trsInput>"
        )
        indented = """
            <trsInput>
              <trs>
                <rules>
                  <rule>
                    <funapp><name>f</name></funapp>
                    <funapp><name>g</name></funapp>
                  </rule>
                </rules>
              </trs>
            </trsInput>
        """
        self.assertEqual(
            canonicalize_cpf_input(compact)[0],
            canonicalize_cpf_input(indented)[0],
        )

    def test_csr_boundary_marker_does_not_split_semantic_state(self) -> None:
        root = (
            "<trsInput><trs><rules><rule><funapp><name>f</name></funapp>"
            "<funapp><name>g</name></funapp></rule></rules></trs></trsInput>"
        )
        nested = root.replace(
            "</trsInput>",
            "<ferrumCsrBoundary>nested</ferrumCsrBoundary></trsInput>",
        )
        self.assertEqual(
            canonicalize_cpf_input(root)[0], canonicalize_cpf_input(nested)[0]
        )

    def test_cpf_canonicalization_matches_labeled_sharp_runtime_symbol(self) -> None:
        structured = """
            <dpInput><trs><rules/></trs><dps><rules><rule>
              <funapp><labeledSymbol><sharp><name>f</name></sharp>
                <numberLabel><number>0</number></numberLabel>
              </labeledSymbol><var>x</var></funapp>
              <funapp><labeledSymbol><sharp><name>f</name></sharp>
                <numberLabel><number>1</number></numberLabel>
              </labeledSymbol><var>x</var></funapp>
            </rule></rules></dps><minimal>true</minimal></dpInput>
        """
        runtime = """
            <dpInput><trs><rules/></trs><dps><rules><rule>
              <funapp><name>__ferrum_sl__6623__0</name><var>x</var></funapp>
              <funapp><name>__ferrum_sl__6623__1</name><var>x</var></funapp>
            </rule></rules></dps><minimal>true</minimal></dpInput>
        """
        self.assertEqual(
            canonicalize_cpf_input(structured)[0],
            canonicalize_cpf_input(runtime)[0],
        )

    def test_dp_canonicalization_sorts_pairs_with_their_remapped_sources(self) -> None:
        right = """
          <dpInput><trs><rules>
            <rule><funapp><name>f</name></funapp><funapp><name>g</name></funapp></rule>
            <rule><funapp><name>g</name></funapp><funapp><name>h</name></funapp></rule>
          </rules></trs><dps><rules>
            <rule><funapp><name>g#</name></funapp><funapp><name>h#</name></funapp></rule>
            <rule><funapp><name>f#</name></funapp><funapp><name>g#</name></funapp></rule>
          </rules></dps><minimal>true</minimal><ferrumDpStateContext>
            <pairSourceRules><sourceRule>1</sourceRule><sourceRule>0</sourceRule></pairSourceRules>
          </ferrumDpStateContext></dpInput>
        """
        root = ET.fromstring(right)
        canonicalize_dp_source_provenance(root)
        sort_rule_blocks(input_rule_blocks(root))
        sources = [
            int(elem.text)
            for elem in root.iter()
            if elem.tag == "sourceRule" and elem.text is not None
        ]
        self.assertEqual(sources, [0, 1])

    def test_dp_canonicalization_tie_breaks_duplicate_pairs_by_source(self) -> None:
        def problem(sources: tuple[int, int]) -> str:
            return f"""
              <dpInput><trs><rules>
                <rule><funapp><name>a</name></funapp><funapp><name>b</name></funapp></rule>
                <rule><funapp><name>c</name></funapp><funapp><name>d</name></funapp></rule>
              </rules></trs><dps><rules>
                <rule><funapp><name>u#</name><var>x</var></funapp><funapp><name>v#</name><var>x</var></funapp></rule>
                <rule><funapp><name>u#</name><var>y</var></funapp><funapp><name>v#</name><var>y</var></funapp></rule>
              </rules></dps><minimal>true</minimal><ferrumDpStateContext>
                <pairSourceRules><sourceRule>{sources[0]}</sourceRule><sourceRule>{sources[1]}</sourceRule></pairSourceRules>
              </ferrumDpStateContext></dpInput>
            """

        self.assertEqual(
            canonicalize_cpf_input(problem((0, 1)))[0],
            canonicalize_cpf_input(problem((1, 0)))[0],
        )

    def test_runtime_oracle_promotes_only_certified_positive_evidence(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            database = Path(directory) / "events.sqlite"
            connection = sqlite3.connect(database)
            connection.execute(
                """
                CREATE TABLE candidates(
                    problem_key TEXT,
                    candidate TEXT,
                    best_status TEXT,
                    utility_score REAL,
                    best_elapsed_ms INTEGER,
                    best_rank INTEGER,
                    attempts INTEGER,
                    solved_count INTEGER,
                    transformed_count INTEGER,
                    failed_count INTEGER,
                    timeout_count INTEGER,
                    certified_count INTEGER,
                    hard_negative_count INTEGER
                )
                """
            )
            connection.executemany(
                "INSERT INTO candidates VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
                [
                    ("uncertified", "poly()", "solved", 10.0, 1, 4, 1, 1, 0, 0, 0, 0, 0),
                    ("certified", "kbo()", "solved", 9.0, 2, 4, 1, 1, 0, 0, 0, 1, 0),
                    ("negative", "matrix()", "failed", -1.0, 3, 1, 1, 0, 0, 1, 0, 0, 0),
                ],
            )
            connection.commit()
            connection.close()

            evidence = candidate_evidence(database)

        self.assertNotIn("uncertified", evidence)
        self.assertEqual(evidence["certified"]["prefer"][0]["candidate"], "kbo()")
        self.assertEqual(evidence["negative"]["avoid"][0]["candidate"], "matrix()")

    def test_external_proof_rule_indices_are_expanded(self) -> None:
        problem = (
            "<trsInput><trs><rules><ruleIndex>2</ruleIndex></rules></trs></trsInput>"
        )
        lookup = """
            <lookupTables><ruleTable><indexToRule>
              <index>2</index>
              <rule><var>x</var><var>x</var></rule>
            </indexToRule></ruleTable></lookupTables>
        """
        expanded = expand_rule_indices(problem, lookup)
        self.assertNotIn("ruleIndex", expanded)
        self.assertIn("<rule><var>x</var><var>x</var></rule>", expanded)

    def test_retained_root_alias_normalizes_sharp_artifact_directory(self) -> None:
        self.assertEqual(
            normalized_problem_id(
                "TRS_Standard/Strategy_removed_AG01/sharp_4.25/proof.cpf3.xml"
            ),
            "Strategy_removed_AG01/#4.25",
        )

    def test_dependency_pair_entries_are_executable_atoms(self) -> None:
        self.assertEqual(normalize_atom("FastDependencyPairs"), "fast-dp")
        self.assertEqual(
            normalize_atom("DependencyPairs(Some(Sequence([DependencyGraph])))"),
            "dp",
        )
        self.assertEqual(
            normalize_atom("DependencyPairs(Some(Processor(SizeChange)))"),
            "dp(size-change)",
        )
        self.assertEqual(
            normalize_atom(
                "DependencyPairs(Some(Sequence([Processor(DependencyGraph), "
                "Processor(SizeChange)])))"
            ),
            "dp(graph;size-change)",
        )
        self.assertEqual(
            normalize_atom(
                "ArcticMatrixInterpretation { dimension: 1, max_constant: 2, "
                "max_coefficient: 2, max_nonzero: None, max_symbols: None, "
                "max_arity: None }"
            ),
            "arctic-matrix(dimension=1,max-constant=2,max-coefficient=2)",
        )
        self.assertEqual(
            normalize_atom(
                "MonotonicPolynomial { max_constant: 2, max_coefficient: 2, "
                "max_symbols: None, max_arity: None }"
            ),
            "mono-poly(max-constant=2,max-coefficient=2)",
        )

    def test_exact_debug_polynomial_models_are_not_degraded_to_search(self) -> None:
        model = [("f#", [(0, [1, 0]), (1, [0, 1])])]
        encoded = json.dumps(model, separators=(",", ":")).encode().hex()
        self.assertEqual(
            normalize_atom(f"ExactMaxPolynomial {{ interpretation: {model!r} }}"),
            f"exact-max-poly(hex={encoded})",
        )
        rational = [("f#", 0, [4, 0])]
        encoded = json.dumps([4, rational], separators=(",", ":")).encode().hex()
        self.assertEqual(
            normalize_atom(
                "ExactRationalPolynomial { denominator: 4, "
                f"interpretation: {rational!r} }}"
            ),
            f"exact-rat-poly(hex={encoded})",
        )
        self.assertEqual(
            normalize_atom(
                "MatrixInterpretation { dimension: 4, max_constant: 2, "
                "max_coefficient: 2, min_nonzero: Some(11), "
                "max_nonzero: Some(11), max_nonzero_constants: Some(1), "
                "max_nonzero_per_row: Some(3), max_symbols: None, "
                "max_arity: None }"
            ),
            "matrix(dim=4,max-constant=2,max-coefficient=2,min-nonzero=11,"
            "max-nonzero=11,max-nonzero-constants=1,max-nonzero-per-row=3)",
        )

    def test_executable_dp_atom_preserves_complete_continuation(self) -> None:
        atom = (
            "dp(graph; subterm; timeout(2000ms, size-change); "
            "parallel(matrix(dimension=1,max-constant=2,max-coefficient=1) | "
            "forward-instantiate(per-pair=2)))"
        )
        self.assertEqual(
            normalize_atom(atom),
            "dp(graph;subterm;timeout(2000ms,size-change);"
            "parallel(matrix(dimension=1,max-constant=2,max-coefficient=1)|"
            "forward-instantiate(per-pair=2)))",
        )

    def test_executable_top_level_sequence_preserves_complete_continuation(self) -> None:
        atom = (
            "matrix(dimension=2,max-constant=1,max-coefficient=1); "
            "csr-safe-dp"
        )
        self.assertEqual(
            normalize_atom(atom),
            "matrix(dimension=2,max-constant=1,max-coefficient=1);csr-safe-dp",
        )

    def test_dp_backed_generic_termination_is_recovered_as_dp(self) -> None:
        event = {
            "level": "top-level",
            "strategy_atom": "Termination",
            "witness": {
                "kind": "proof_steps_debug",
                "value": "[DependencyPairProof { proof: ... }]",
            },
        }
        self.assertEqual(normalized_event_candidate(event), "dp")

    def test_csr_loop_debug_label_is_an_executable_atom(self) -> None:
        self.assertEqual(
            normalized_event_candidate({"strategy_atom": "CsrLoop"}),
            "csr-loop",
        )

    def test_top_level_dp_result_preserves_its_certified_continuation(self) -> None:
        event = {
            "level": "top-level",
            "strategy_atom": (
                "DependencyPairs(Some(Sequence([Processor(DependencyGraph), "
                "Processor(MonotonicPolynomial { max_constant: 2, "
                "max_coefficient: 2, max_symbols: None, max_arity: None })])))"
            ),
        }
        self.assertEqual(
            normalized_event_candidate(event),
            "dp(graph;mono-poly(max-constant=2,max-coefficient=2))",
        )

    def test_top_level_dp_result_preserves_parallel_continuation(self) -> None:
        event = {
            "level": "top-level",
            "strategy_atom": (
                "DependencyPairs(Some(Sequence([Processor(DependencyGraph), "
                "Parallel([Processor(SizeChange), Processor(Subterm)])])))"
            ),
        }
        self.assertEqual(
            normalized_event_candidate(event),
            "dp(graph;parallel(size-change|subterm))",
        )

    def test_non_dp_generic_termination_stays_excluded_meta_atom(self) -> None:
        event = {
            "level": "top-level",
            "strategy_atom": "Termination",
            "witness": {
                "kind": "proof_steps_debug",
                "value": "[SynthesizedKbo { ... }]",
            },
        }
        self.assertEqual(normalized_event_candidate(event), "termination")

    def test_order_witness_does_not_leak_from_continuation(self) -> None:
        proof = """
        <ruleRemoval>
          <interpretation>
            <type><polynomial><degree>1</degree></polynomial></type>
            <interpret><name>f</name><arity>1</arity><variable>1</variable></interpret>
          </interpretation>
          <trsTerminationProof>
            <dpTrans><dpProof><redPairProc>
              <interpretation>
                <type><matrixInterpretation><dimension>2</dimension></matrixInterpretation></type>
              </interpretation>
            </redPairProc></dpProof></dpTrans>
          </trsTerminationProof>
        </ruleRemoval>
        """
        strategy = strategy_from_xml("ruleRemoval", proof, "<trsInput/>")
        self.assertIsNotNone(strategy)
        self.assertTrue(strategy[0].startswith("poly("), strategy)

    def test_exact_extractor_preserves_switch_innermost_before_dp(self) -> None:
        root = ET.fromstring(
            """
            <certificationProblem>
              <input>
                <trsInput>
                  <trs><rules /></trs>
                </trsInput>
              </input>
              <proof>
                <trsTerminationProof>
                  <switchInnermost>
                    <trsTerminationProof>
                      <dpTrans>
                        <dps><rules /></dps>
                        <dpProof><pIsEmpty /></dpProof>
                      </dpTrans>
                    </trsTerminationProof>
                  </switchInnermost>
                </trsTerminationProof>
              </proof>
            </certificationProblem>
            """
        )
        source = {
            "proof_url": "local://switch.cpf3.xml",
            "normalizer": None,
            "source_kind": "test",
            "xml_path": "switch.cpf3.xml",
            "xml_format": "cpf3",
            "year": 2025,
            "category": "TRS_Standard",
            "benchmark": "switch.ari",
            "tool": "Ferrum",
            "result": "YES",
            "certification": "certified",
        }

        rows, reasons = iter_exact_rows(source, root)

        self.assertFalse(reasons)
        self.assertEqual(
            [row["metadata"]["processor_tag"] for row in rows],
            ["switchInnermost", "dpTrans", "pIsEmpty"],
        )
        self.assertNotIn("<innermost", rows[0]["input"]["problem_xml"])
        self.assertIn("<innermost", rows[1]["input"]["problem_xml"])
        self.assertIn("<nfs>true</nfs>", rows[1]["input"]["problem_xml"])

    def test_csr_rule_removal_filters_residual_replacement_map_signature(self) -> None:
        root = ET.fromstring(
            """
            <certificationProblem>
              <input><trsInput><trs><rules>
                <rule><funapp><name>f</name></funapp><funapp><name>a</name></funapp></rule>
                <rule><funapp><name>g</name></funapp><funapp><name>b</name></funapp></rule>
              </rules></trs><strategy><contextSensitive>
                <replacementMapEntry><name>f</name><arity>0</arity></replacementMapEntry>
                <replacementMapEntry><name>a</name><arity>0</arity></replacementMapEntry>
                <replacementMapEntry><name>g</name><arity>0</arity></replacementMapEntry>
                <replacementMapEntry><name>b</name><arity>0</arity></replacementMapEntry>
              </contextSensitive></strategy></trsInput></input>
              <proof><csrTerminationProof><csrRuleRemoval><trs><rules>
                <rule><funapp><name>f</name></funapp><funapp><name>a</name></funapp></rule>
              </rules></trs><csrTerminationProof><rIsEmpty/></csrTerminationProof>
              </csrRuleRemoval></csrTerminationProof></proof>
            </certificationProblem>
            """
        )
        source = {
            "proof_url": "local://csr-rule-removal.cpf.xml",
            "normalizer": None,
            "source_kind": "test",
            "xml_path": "csr-rule-removal.cpf.xml",
            "xml_format": "cpf4",
            "year": 2025,
            "category": "TRS_Contextsensitive",
            "benchmark": "csr-rule-removal.ari",
            "tool": "Ferrum",
            "result": "YES",
            "certification": "certified",
        }

        rows, reasons = iter_exact_rows(source, root)

        self.assertFalse(reasons)
        residual = rows[-1]["input"]["problem_xml"]
        self.assertNotIn("<name>f</name>", residual)
        self.assertNotIn("<name>a</name>", residual)
        self.assertIn("<name>g</name>", residual)
        self.assertIn("<name>b</name>", residual)

    def test_guarded_csr_extension_materializes_recursive_states(self) -> None:
        root = ET.fromstring(
            """
            <certificationProblem>
              <input><trsInput><trs><rules>
                <rule><funapp><name>f</name></funapp><funapp><name>a</name></funapp></rule>
                <rule><funapp><name>g</name></funapp><funapp><name>b</name></funapp></rule>
              </rules></trs><strategy><contextSensitive /></strategy></trsInput></input>
              <proof><csrGuardedTerminationProof>
                <csrGuardedRuleRemoval>
                  <interpretation />
                  <trs><rules><rule>
                    <funapp><name>f</name></funapp><funapp><name>a</name></funapp>
                  </rule></rules></trs>
                  <csrGuardedImprovedDependencyPairs>
                    <unhidingSymbol><name>U</name></unhidingSymbol>
                    <dps><rules><rule>
                      <funapp><name>g#</name></funapp><funapp><name>g#</name></funapp>
                    </rule></rules></dps>
                    <csrGuardedDepGraphProc><component>
                      <dps><rules><rule>
                        <funapp><name>g#</name></funapp><funapp><name>g#</name></funapp>
                      </rule></rules></dps>
                      <csrGuardedExistingDpProof><csrDpProof><pIsEmpty /></csrDpProof></csrGuardedExistingDpProof>
                    </component></csrGuardedDepGraphProc>
                  </csrGuardedImprovedDependencyPairs>
                </csrGuardedRuleRemoval>
              </csrGuardedTerminationProof></proof>
            </certificationProblem>
            """
        )
        source = {
            "proof_url": "local://guarded-csr.cpf.xml",
            "normalizer": None,
            "source_kind": "test",
            "xml_path": "guarded-csr.cpf.xml",
            "xml_format": "cpf3",
            "year": 2026,
            "category": "TRS_Contextsensitive",
            "benchmark": "guarded-csr.ari",
            "tool": "Ferrum",
            "result": "YES",
            "certification": "certified",
        }

        rows, reasons = iter_exact_rows(source, root)

        self.assertFalse(reasons)
        self.assertEqual(
            [row["metadata"]["processor_tag"] for row in rows],
            [
                "csrGuardedRuleRemoval",
                "csrGuardedImprovedDependencyPairs",
                "csrGuardedDepGraphProc",
                "pIsEmpty",
            ],
        )
        self.assertNotIn("<name>f</name>", rows[1]["input"]["problem_xml"])
        self.assertIn("<construction>improved</construction>", rows[2]["input"]["problem_xml"])
        self.assertEqual(rows[3]["input"]["problem_xml"].count("<rule>"), 2)

    def test_exact_extractor_preserves_dp_rewriting_transition(self) -> None:
        root = ET.fromstring(
            """
            <certificationProblem>
              <input>
                <dpInput>
                  <dps><rules><rule>
                    <funapp><name>f</name></funapp>
                    <funapp><name>g</name></funapp>
                  </rule></rules></dps>
                  <trs><rules /></trs>
                </dpInput>
              </input>
              <proof>
                <dpProof>
                  <rewritingProc>
                    <rule>
                      <funapp><name>f</name></funapp>
                      <funapp><name>g</name></funapp>
                    </rule>
                    <rewriteStep><positionInTerm /></rewriteStep>
                    <rule>
                      <funapp><name>f</name></funapp>
                      <funapp><name>h</name></funapp>
                    </rule>
                    <dpProof><pIsEmpty /></dpProof>
                  </rewritingProc>
                </dpProof>
              </proof>
            </certificationProblem>
            """
        )
        source = {
            "proof_url": "local://rewriting.cpf3.xml",
            "normalizer": None,
            "source_kind": "test",
            "xml_path": "rewriting.cpf3.xml",
            "xml_format": "cpf3",
            "year": 2026,
            "category": "TRS_Innermost",
            "benchmark": "rewriting.ari",
            "tool": "Ferrum",
            "result": "YES",
            "certification": "certified",
        }

        rows, reasons = iter_exact_rows(source, root)

        self.assertFalse(reasons)
        self.assertEqual(
            [row["metadata"]["processor_tag"] for row in rows],
            ["rewritingProc", "pIsEmpty"],
        )
        self.assertIn("<name>h</name>", rows[1]["input"]["problem_xml"])

    def test_exact_extractor_materializes_both_relative_split_states(self) -> None:
        root = ET.fromstring(
            """
            <certificationProblem>
              <input><dpInput><trs><rules /></trs><dps><rules>
                <rule><funapp><name>f</name></funapp><funapp><name>f</name></funapp></rule>
                <rule><funapp><name>g</name></funapp><funapp><name>g</name></funapp></rule>
                <rule><funapp><name>h</name></funapp><funapp><name>h</name></funapp></rule>
              </rules></dps><minimal>true</minimal></dpInput></input>
              <proof><dpProof><splitProc>
                <dps><rules><rule>
                  <funapp><name>f</name></funapp><funapp><name>f</name></funapp>
                </rule></rules></dps><trs><rules /></trs>
                <dpProof><pIsEmpty /></dpProof>
                <dpProof><pIsEmpty /></dpProof>
              </splitProc></dpProof></proof>
            </certificationProblem>
            """
        )
        source = {
            "proof_url": "local://split.cpf.xml",
            "normalizer": None,
            "source_kind": "test",
            "xml_path": "split.cpf.xml",
            "xml_format": "cpf3",
            "year": 2025,
            "category": "TRS_Standard",
            "benchmark": "split.ari",
            "tool": "Ferrum",
            "result": "YES",
            "certification": "certified",
        }

        rows, reasons = iter_exact_rows(source, root)

        self.assertFalse(reasons)
        self.assertEqual(
            [row["metadata"]["processor_tag"] for row in rows],
            ["splitProc", "pIsEmpty", "pIsEmpty"],
        )
        selected_branch = rows[1]["input"]["problem_xml"]
        residual_branch = rows[2]["input"]["problem_xml"]
        self.assertIn("<ferrumWeakDps>", selected_branch)
        self.assertEqual(selected_branch.count("<rule>"), 5)
        self.assertNotIn("<ferrumWeakDps>", residual_branch)
        self.assertEqual(residual_branch.count("<rule>"), 2)

    def test_semantic_labeling_child_records_labeled_active_rules(self) -> None:
        root = ET.fromstring(
            """
            <certificationProblem>
              <input>
                <dpInput>
                  <trs><rules><rule>
                    <funapp><name>f</name></funapp>
                    <funapp><name>g</name></funapp>
                  </rule></rules></trs>
                  <dps><rules><rule>
                    <funapp><name>f#</name></funapp>
                    <funapp><name>g#</name></funapp>
                  </rule></rules></dps>
                  <minimal>true</minimal>
                </dpInput>
              </input>
              <proof>
                <dpProof>
                  <semlabProc>
                    <trs><rules><rule>
                      <funapp><name>lf</name></funapp>
                      <funapp><name>lg</name></funapp>
                    </rule></rules></trs>
                    <dps><rules><rule>
                      <funapp><name>lf#</name></funapp>
                      <funapp><name>lg#</name></funapp>
                    </rule></rules></dps>
                    <dpProof><pIsEmpty /></dpProof>
                  </semlabProc>
                </dpProof>
              </proof>
            </certificationProblem>
            """
        )
        source = {
            "proof_url": "local://semantic-labeling.cpf3.xml",
            "normalizer": None,
            "source_kind": "test",
            "xml_path": "semantic-labeling.cpf3.xml",
            "xml_format": "cpf3",
            "year": 2026,
            "category": "TRS_Standard",
            "benchmark": "semantic-labeling.ari",
            "tool": "Ferrum",
            "result": "YES",
            "certification": "certified",
        }

        rows, reasons = iter_exact_rows(source, root)

        self.assertFalse(reasons)
        self.assertEqual(
            [row["metadata"]["processor_tag"] for row in rows],
            ["semlabProc", "pIsEmpty"],
        )
        child_input = rows[1]["input"]["problem_xml"]
        self.assertIn("<trs>", child_input)
        self.assertIn("<usableRules>", child_input)
        # The labeled rule is present in the full R, the active usable-rule
        # set, and the explicit graph context.  Assert those roles instead of
        # treating their deliberate copies as accidental duplicates.
        child_root = ET.fromstring(child_input)
        child_dp = child_root.find("dpInput")
        self.assertIsNotNone(child_dp)
        self.assertEqual(len(child_dp.find("trs").findall("./rules/rule")), 1)
        self.assertEqual(
            len(child_dp.find("usableRules").findall("./rules/rule")), 1
        )
        self.assertEqual(
            len(
                child_dp.find("./ferrumDpStateContext/graphRules").findall(
                    "./rules/rule"
                )
            ),
            1,
        )
        self.assertIn("<minimal>false</minimal>", child_input)

    def test_red_pair_child_makes_implicit_full_rules_active(self) -> None:
        root = ET.fromstring(
            """
            <certificationProblem>
              <input>
                <dpInput>
                  <trs><rules><rule>
                    <funapp><name>f</name></funapp>
                    <funapp><name>g</name></funapp>
                  </rule></rules></trs>
                  <dps><rules><rule>
                    <funapp><name>f#</name></funapp>
                    <funapp><name>g#</name></funapp>
                  </rule></rules></dps>
                  <minimal>true</minimal>
                </dpInput>
              </input>
              <proof>
                <dpProof>
                  <redPairProc>
                    <dps><rules /></dps>
                    <orderingConstraintProof />
                    <dpProof><pIsEmpty /></dpProof>
                  </redPairProc>
                </dpProof>
              </proof>
            </certificationProblem>
            """
        )
        source = {
            "proof_url": "local://red-pair.cpf3.xml",
            "normalizer": None,
            "source_kind": "test",
            "xml_path": "red-pair.cpf3.xml",
            "xml_format": "cpf3",
            "year": 2026,
            "category": "TRS_Standard",
            "benchmark": "red-pair.ari",
            "tool": "Ferrum",
            "result": "YES",
            "certification": "certified",
        }

        rows, reasons = iter_exact_rows(source, root)

        self.assertFalse(reasons)
        child_input = rows[1]["input"]["problem_xml"]
        self.assertIn("<usableRules>", child_input)
        self.assertEqual(child_input.count("<name>f</name>"), 2)

    def test_exact_extractor_preserves_switch_full_loop_path(self) -> None:
        root = ET.fromstring(
            """
            <certificationProblem>
              <input>
                <trsInput>
                  <trs><rules /></trs>
                  <strategy><innermost /></strategy>
                </trsInput>
              </input>
              <proof>
                <trsNonterminationProof>
                  <switchFullStrategy>
                    <wcrProof><joinAutoBfs>1</joinAutoBfs></wcrProof>
                    <trsNonterminationProof><loop /></trsNonterminationProof>
                  </switchFullStrategy>
                </trsNonterminationProof>
              </proof>
            </certificationProblem>
            """
        )
        source = {
            "proof_url": "local://switch-full.cpf3.xml",
            "normalizer": None,
            "source_kind": "test",
            "xml_path": "switch-full.cpf3.xml",
            "xml_format": "cpf3",
            "year": 2026,
            "category": "TRS_Innermost",
            "benchmark": "switch-full.ari",
            "tool": "Ferrum",
            "result": "NO",
            "certification": "certified",
        }

        rows, reasons = iter_exact_rows(source, root)

        self.assertFalse(reasons)
        self.assertEqual(
            [row["metadata"]["processor_tag"] for row in rows],
            ["switchFullStrategy", "loop"],
        )
        self.assertIn("<innermost", rows[0]["input"]["problem_xml"])
        self.assertNotIn("<strategy", rows[1]["input"]["problem_xml"])

    def test_dp_nontermination_chain_preserves_each_residual_state(self) -> None:
        root = ET.fromstring(
            """
            <certificationProblem>
              <input><trsInput><trs><rules><rule>
                <funapp><name>r</name></funapp><funapp><name>r</name></funapp>
              </rule></rules></trs><strategy><full /></strategy></trsInput></input>
              <proof><trsNonterminationProof><dpTrans><dps><rules>
                <rule><funapp><name>a</name></funapp><funapp><name>a</name></funapp></rule>
                <rule><funapp><name>b</name></funapp><funapp><name>b</name></funapp></rule>
              </rules></dps><dpNonterminationProof><instantiationProc><dps><rules>
                <rule><funapp><name>c</name></funapp><funapp><name>c</name></funapp></rule>
              </rules></dps><dpNonterminationProof><dpRuleRemoval><dps><rules>
                <rule><funapp><name>a</name></funapp><funapp><name>a</name></funapp></rule>
              </rules></dps><trs><rules><rule>
                <funapp><name>r</name></funapp><funapp><name>r</name></funapp>
              </rule></rules></trs><dpNonterminationProof><loop /></dpNonterminationProof>
              </dpRuleRemoval></dpNonterminationProof></instantiationProc></dpNonterminationProof>
              </dpTrans></trsNonterminationProof></proof>
            </certificationProblem>
            """
        )
        source = {
            "proof_url": "local://dp-nontermination-chain.cpf.xml",
            "normalizer": None,
            "source_kind": "test",
            "xml_path": "dp-nontermination-chain.cpf.xml",
            "xml_format": "cpf3",
            "year": 2025,
            "category": "TRS_Standard",
            "benchmark": "dp-nontermination-chain.ari",
            "tool": "Ferrum",
            "result": "NO",
            "certification": "certified",
        }

        rows, reasons = iter_exact_rows(source, root)

        self.assertFalse(reasons)
        self.assertEqual(
            [row["metadata"]["processor_tag"] for row in rows],
            ["dpTrans", "instantiationProc", "dpRuleRemoval", "loop"],
        )
        self.assertEqual(rows[1]["input"]["problem_xml"].count("<rule>"), 3)
        self.assertEqual(rows[2]["input"]["problem_xml"].count("<rule>"), 4)
        self.assertEqual(rows[3]["input"]["problem_xml"].count("<rule>"), 2)

    def test_csr_dp_extraction_materializes_nested_q_context(self) -> None:
        root = ET.fromstring(
            """
            <certificationProblem>
              <input>
                <trsInput>
                  <trs><rules /></trs>
                  <strategy><contextSensitive /></strategy>
                </trsInput>
              </input>
              <proof>
                <csrTerminationProof>
                  <csrDependencyPairs>
                    <dps><rules /></dps>
                    <csrDpProof>
                      <depGraphProc>
                        <component>
                          <dps><rules /></dps>
                          <csrDpProof><sizeChangeProc /></csrDpProof>
                        </component>
                      </depGraphProc>
                    </csrDpProof>
                  </csrDependencyPairs>
                </csrTerminationProof>
              </proof>
            </certificationProblem>
            """
        )
        source = {
            "proof_url": "local://csr.cpf.xml",
            "normalizer": None,
            "source_kind": "test",
            "xml_path": "csr.cpf.xml",
            "xml_format": "cpf4",
            "year": 2025,
            "category": "TRS_Contextsensitive",
            "benchmark": "csr.ari",
            "tool": "Ferrum",
            "result": "YES",
            "certification": "certified",
        }

        rows, reasons = iter_exact_rows(source, root)

        self.assertEqual(
            [row["metadata"]["processor_tag"] for row in rows],
            ["csrDependencyPairs", "depGraphProc", "sizeChangeProc"],
        )
        self.assertIn("<contextSensitive", rows[0]["input"]["problem_xml"])
        self.assertIn("<contextSensitive", rows[1]["input"]["problem_xml"])
        self.assertIn("<contextSensitive", rows[2]["input"]["problem_xml"])
        self.assertIn("<dpInput", rows[1]["input"]["problem_xml"])
        self.assertFalse(
            any(key.startswith("unsupported_transition") for key in reasons),
            reasons,
        )


if __name__ == "__main__":
    unittest.main()
