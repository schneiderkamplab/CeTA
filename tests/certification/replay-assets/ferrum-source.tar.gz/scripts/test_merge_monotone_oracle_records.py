#!/usr/bin/env python3

import unittest
import hashlib
import json
import subprocess
import sys
import tempfile
from pathlib import Path

from merge_monotone_oracle_records import (
    has_positive_guidance,
    merge_bucket,
    normalize_record_buckets,
    promote_incoming_candidates,
    replay_priority,
)


class MonotoneOracleAliasTest(unittest.TestCase):
    def test_promoting_legacy_order_supersedes_newer_explicit_order(self):
        digest = lambda s: hashlib.sha256(s.encode()).hexdigest()
        current = dict(replay_order=[digest('poly')], prefer=[], avoid=[], timeout=[], possible=[
            dict(candidate='poly', status='transformed_weak'),
            dict(candidate='path-order', status='transformed_weak')])
        incoming = dict(possible=[dict(candidate='path-order', status='transformed_weak')])
        promote_incoming_candidates(current, incoming)
        self.assertEqual(current['replay_order'], [digest('path-order'), digest('poly')])
        del current['replay_order']
        promote_incoming_candidates(current, incoming)
        self.assertNotIn('replay_order', current)

    def test_direct_native_hint_preserves_its_explicit_canonical_fallback(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            old = dict(problem_key='raw', possible=[dict(candidate='poly', status='transformed_weak')])
            new = dict(old, canonical_problem_key='canonical')
            (root / 'base').write_text(json.dumps(old) + '\n')
            (root / 'incoming').write_text(json.dumps(new) + '\n')
            subprocess.run([sys.executable, str(Path(__file__).with_name('merge_monotone_oracle_records.py')),
                            '--base', str(root / 'base'), '--incoming', str(root / 'incoming'),
                            '--output', str(root / 'out'), '--report', str(root / 'report')],
                           check=True, capture_output=True)
            result = json.loads((root / 'out').read_text())
            self.assertEqual(result['canonical_problem_key'], 'canonical')
            self.assertEqual(result['possible'][0]['candidate'], 'poly')

    def test_replay_allowance_does_not_overwrite_historical_best(self) -> None:
        old = dict(candidate='path-order', status='transformed_weak',
                   best_elapsed_ms=39000, utility_score=1)
        new = dict(old, best_elapsed_ms=63130, replay_elapsed_ms=63130)
        merged = merge_bucket([old], [new])[0]
        self.assertEqual(merged['best_elapsed_ms'], 39000)
        self.assertEqual(merged['replay_elapsed_ms'], 63130)
        self.assertEqual(merge_bucket([merged], [old])[0]['replay_elapsed_ms'], 63130)

    def test_new_keys_only_restores_missing_certified_fallback_alias(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            base = root / "base.jsonl"
            incoming = root / "incoming.jsonl"
            output = root / "output.jsonl"
            report = root / "report.json"
            raw = "a" * 64
            canonical = "c" * 64
            empty = {"prefer": [], "possible": [], "avoid": [], "timeout": []}
            base.write_text(
                json.dumps({"problem_key": raw, **empty})
                + "\n"
                + json.dumps(
                    {
                        "problem_key": canonical,
                        "prefer": [{"candidate": "direct-loop", "status": "solved"}],
                        "possible": [],
                        "avoid": [],
                        "timeout": [],
                    }
                )
                + "\n"
            )
            incoming.write_text(
                json.dumps(
                    {
                        "problem_key": raw,
                        "canonical_problem_key": canonical,
                        **empty,
                    }
                )
                + "\n"
                + json.dumps(
                    {
                        "problem_key": canonical,
                        "prefer": [{"candidate": "direct-loop", "status": "solved"}],
                        "possible": [],
                        "avoid": [],
                        "timeout": [],
                    }
                )
                + "\n"
            )
            subprocess.run(
                [
                    sys.executable,
                    str(Path(__file__).with_name("merge_monotone_oracle_records.py")),
                    "--base",
                    str(base),
                    "--incoming",
                    str(incoming),
                    "--new-keys-only",
                    "--output",
                    str(output),
                    "--report",
                    str(report),
                ],
                check=True,
                capture_output=True,
                text=True,
            )
            merged = {
                row["problem_key"]: row
                for row in map(json.loads, output.read_text().splitlines())
            }
            self.assertEqual(merged[raw]["canonical_problem_key"], canonical)
            self.assertEqual(
                json.loads(report.read_text())["restored_canonical_aliases"], 1
            )

    def test_cli_can_keep_proof_local_runtime_keys_off_shared_canonical_target(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            base = root / "base.jsonl"
            incoming = root / "incoming.jsonl"
            keys = root / "keys.txt"
            output = root / "output.jsonl"
            report = root / "report.json"
            raw = "a" * 64
            canonical = "c" * 64
            base.write_text(
                json.dumps(
                    {
                        "problem_key": canonical,
                        "prefer": [{"candidate": "shared-safe", "status": "solved"}],
                        "possible": [],
                        "avoid": [],
                        "timeout": [],
                    }
                )
                + "\n"
            )
            incoming.write_text(
                json.dumps(
                    {
                        "problem_key": raw,
                        "canonical_problem_key": canonical,
                        "prefer": [{"candidate": "proof-local", "status": "solved"}],
                        "possible": [],
                        "avoid": [],
                        "timeout": [],
                    }
                )
                + "\n"
                + json.dumps(
                    {
                        "problem_key": canonical,
                        "prefer": [{"candidate": "unsafe-to-share", "status": "solved"}],
                        "possible": [],
                        "avoid": [],
                        "timeout": [],
                    }
                )
                + "\n"
            )
            keys.write_text(raw + "\n")
            subprocess.run(
                [
                    sys.executable,
                    str(Path(__file__).with_name("merge_monotone_oracle_records.py")),
                    "--base",
                    str(base),
                    "--incoming",
                    str(incoming),
                    "--output",
                    str(output),
                    "--report",
                    str(report),
                    "--promote-key-file",
                    str(keys),
                    "--incoming-key-file",
                    str(keys),
                    "--incoming-exact-keys-only",
                ],
                check=True,
                capture_output=True,
                text=True,
            )
            merged = {
                row["problem_key"]: row
                for row in map(json.loads, output.read_text().splitlines())
            }
            self.assertEqual(merged[raw]["prefer"][0]["candidate"], "proof-local")
            self.assertEqual(
                [item["candidate"] for item in merged[canonical]["prefer"]],
                ["shared-safe"],
            )

    def test_cli_promotes_only_certified_replay_keys(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            base = root / "base.jsonl"
            incoming = root / "incoming.jsonl"
            keys = root / "keys.txt"
            output = root / "output.jsonl"
            report = root / "report.json"
            rows = lambda first: {
                "prefer": [
                    {"candidate": first, "status": "transformed_strong"},
                    {"candidate": "recovered", "status": "solved"},
                ],
                "possible": [],
                "avoid": [],
                "timeout": [],
            }
            base.write_text(
                "\n".join(
                    json.dumps({"problem_key": key, **rows("current")})
                    for key in ("a" * 64, "b" * 64)
                )
                + "\n"
            )
            incoming.write_text(
                "\n".join(
                    json.dumps(
                        {
                            "problem_key": key,
                            "prefer": [
                                {"candidate": "recovered", "status": "solved"},
                                {"candidate": "stale", "status": "transformed_strong"},
                            ],
                            "possible": [],
                            "avoid": [],
                            "timeout": [],
                        }
                    )
                    for key in ("a" * 64, "b" * 64)
                )
                + "\n"
            )
            keys.write_text("a" * 64 + "\tcertified replay\n")
            subprocess.run(
                [
                    sys.executable,
                    str(Path(__file__).with_name("merge_monotone_oracle_records.py")),
                    "--base",
                    str(base),
                    "--incoming",
                    str(incoming),
                    "--output",
                    str(output),
                    "--report",
                    str(report),
                    "--promote-key-file",
                    str(keys),
                    "--incoming-key-file",
                    str(keys),
                ],
                check=True,
                capture_output=True,
                text=True,
            )
            merged = {
                row["problem_key"]: row
                for row in map(json.loads, output.read_text().splitlines())
            }
            self.assertEqual(merged["a" * 64]["prefer"][0]["candidate"], "recovered")
            self.assertEqual(merged["b" * 64]["prefer"][0]["candidate"], "current")
            self.assertNotIn(
                "stale",
                [item["candidate"] for item in merged["b" * 64]["prefer"]],
            )

    def test_cli_preserves_witness_metadata_while_merging_states(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            base = root / "base.jsonl"
            incoming = root / "incoming.jsonl"
            output = root / "output.jsonl"
            report = root / "report.json"
            witness = {
                "schema": "ferrum.utility-guidance.witness.v1",
                "witness_id": "w1",
                "candidate": "exact-poly-ref(id=w1)",
            }
            base.write_text(
                json.dumps(witness) + "\n"
                + json.dumps(
                    {
                        "problem_key": "a" * 64,
                        "prefer": [],
                        "possible": [],
                        "avoid": [],
                        "timeout": [],
                    }
                )
                + "\n"
            )
            incoming.write_text(
                json.dumps(
                    {
                        "problem_key": "b" * 64,
                        "prefer": [],
                        "possible": [],
                        "avoid": [],
                        "timeout": [],
                    }
                )
                + "\n"
            )
            subprocess.run(
                [
                    sys.executable,
                    str(Path(__file__).with_name("merge_monotone_oracle_records.py")),
                    "--base",
                    str(base),
                    "--incoming",
                    str(incoming),
                    "--output",
                    str(output),
                    "--report",
                    str(report),
                ],
                check=True,
                capture_output=True,
                text=True,
            )
            rows = [json.loads(line) for line in output.read_text().splitlines()]
            self.assertEqual(rows[0], witness)
            self.assertEqual(
                [row["problem_key"] for row in rows[1:]], ["a" * 64, "b" * 64]
            )

    def test_explicit_promotion_moves_reverified_action_first(self) -> None:
        current = {
            "prefer": [
                {"candidate": "dp", "status": "transformed_strong"},
                {"candidate": "exact-poly", "status": "transformed_strong"},
            ],
            "possible": [],
            "avoid": [],
            "timeout": [],
        }
        incoming = {
            "prefer": [
                {"candidate": "exact-poly", "status": "transformed_strong"}
            ]
        }
        promote_incoming_candidates(current, incoming)
        self.assertEqual(
            [item["candidate"] for item in current["prefer"]],
            ["exact-poly", "dp"],
        )

    def test_merge_preserves_certified_base_replay_order(self) -> None:
        base = [
            {"candidate": "max-poly", "status": "solved", "utility_score": 1.0},
            {"candidate": "instantiate", "status": "solved", "utility_score": 2.0},
        ]
        incoming = [
            {"candidate": "instantiate", "status": "solved", "utility_score": 99.0},
            {"candidate": "matrix", "status": "solved", "utility_score": 100.0},
        ]
        merged = merge_bucket(base, incoming)
        self.assertEqual(
            [item["candidate"] for item in merged],
            ["max-poly", "instantiate", "matrix"],
        )
        self.assertEqual(merged[1]["utility_score"], 99.0)

    def test_distinct_interned_exact_witnesses_do_not_collapse(self) -> None:
        record = {
            "prefer": [
                {
                    "candidate_ref": "sha256:first",
                    "status": "transformed_strong",
                    "utility_score": 100.0,
                },
                {
                    "candidate_ref": "sha256:second",
                    "status": "solved",
                    "utility_score": 200.0,
                },
            ],
            "possible": [],
            "avoid": [],
            "timeout": [],
        }
        normalize_record_buckets(record)
        self.assertEqual(
            [item["candidate_ref"] for item in record["prefer"]],
            ["sha256:first", "sha256:second"],
        )

    def test_atomic_state_transition_precedes_certified_whole_search(self) -> None:
        items = [
            {
                "candidate": "dp(graph;timeout(60s,parallel(poly|matrix)))",
                "status": "solved",
                "utility_score": 2000.0,
            },
            {
                "candidate": "dp",
                "status": "transformed_strong",
                "utility_score": 1200.0,
            },
        ]
        items.sort(key=replay_priority)
        self.assertEqual(items[0]["candidate"], "dp")

    def test_negative_history_does_not_block_certified_alias(self) -> None:
        self.assertFalse(
            has_positive_guidance(
                {
                    "avoid": [{"candidate": "graph", "status": "failed"}],
                    "timeout": [{"candidate": "matrix", "status": "timeout"}],
                }
            )
        )

    def test_existing_positive_direct_evidence_remains_authoritative(self) -> None:
        self.assertTrue(
            has_positive_guidance(
                {
                    "prefer": [
                        {"candidate": "subterm", "status": "transformed_strong"}
                    ]
                }
            )
        )

    def test_certified_success_absorbs_later_failure_across_buckets(self) -> None:
        record = {
            "prefer": [
                {
                    "candidate": "dp",
                    "status": "solved",
                    "certified_count": 1,
                    "solved_count": 1,
                    "failed_count": 0,
                    "attempts": 1,
                    "utility_score": 2000.0,
                    "best_elapsed_ms": 10,
                }
            ],
            "possible": [],
            "avoid": [
                {
                    "candidate": "dp",
                    "status": "failed",
                    "certified_count": 0,
                    "solved_count": 0,
                    "failed_count": 3,
                    "attempts": 3,
                    "utility_score": -60.0,
                    "best_elapsed_ms": 5,
                }
            ],
            "timeout": [],
        }
        normalize_record_buckets(record)
        self.assertEqual([item["candidate"] for item in record["prefer"]], ["dp"])
        self.assertEqual(record["prefer"][0]["status"], "solved")
        self.assertEqual(record["prefer"][0]["certified_count"], 1)
        self.assertEqual(record["prefer"][0]["failed_count"], 3)
        self.assertEqual(record["avoid"], [])


if __name__ == "__main__":
    unittest.main()
