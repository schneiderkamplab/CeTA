#!/usr/bin/env python3
"""Extract proof-fragment rows with exact local CPF obligations.

The older subproof extractor records the global problem for every row.  That is
useful for broad training data, but it is not sufficient for independently
checking a proof fragment: a fragment under ``dpTrans`` or ``depGraphProc`` must
be checked against the local DP obligation computed by the parent processors.

This extractor walks complete CPF certificates and propagates the local
``trsInput``/``dpInput`` obligation through the proof tree for processors whose
residual obligation can be reconstructed soundly from the CPF payload.  Rows are
emitted only for visited local obligations; unsupported recursive transitions
are counted and not guessed.
"""

from __future__ import annotations

import argparse
import gzip
import hashlib
import json
import sqlite3
import sys
import xml.etree.ElementTree as ET
from copy import copy, deepcopy
from pathlib import Path
from typing import Any, Iterable

from audit_canonical_fragments import (
    DP_PROOF_STEP_TAGS,
    TRS_PROOF_STEP_TAGS,
    local_name,
    normalize_cpf2_terms,
    parse_normalized_fragment,
    result_answer,
)
from extract_subproof_training_data import child_text, load_xml, path_to, source_rows
from materialize_fragment_audit_dataset import (
    dp_input_like,
    first_child,
    reversed_string_trs_input,
    rule_key,
    subtract_dps,
    subtract_trs,
    trs_input_like,
)

EXACT_TRS_PROOF_STEP_TAGS = TRS_PROOF_STEP_TAGS | {
    # Uncurrying has its own native top-level processor. Emit it at every
    # recursive boundary, not just through the root-only compatibility helper.
    "uncurry",
    "loop",
    "nonLoop",
    "notWNTreeAutomaton",
    "variableConditionViolated",
    "nonterminatingSRS",
    "switchFullStrategy",
    "innermostLhssIncrease",
    "switchInnermost",
    "aaeccInnermost",
    "csrRuleRemoval",
    "csrDependencyPairs",
    "csrImprovedDependencyPairs",
    "csrSafeDependencyPairs",
    "csrConservativeDependencyPairs",
    "csrInnermost",
    "csrRuleRemovalThenImproved",
    "csrGuardedRuleRemoval",
    "csrGuardedImprovedDependencyPairs",
    "csrGmTransformation",
    "ignoreRelativePart",
    "flatContextClosure",
    "semlab",
    "csrMutermTypedDependencyPairs",
    "gm04CompleteFullTransformation",
}

EXACT_DP_PROOF_STEP_TAGS = DP_PROOF_STEP_TAGS | {
    "complexConstantRemovalProc",
    "innermostLhssIncreaseProc",
    # Nontermination is polarity preserving under deletion: an infinite chain
    # of the residual is an infinite chain of the parent.  The residual is a
    # first-class DP state and must receive its own oracle lookup.
    "dpRuleRemoval",
    "switchFullStrategyProc",
    "generalRedPairProc",
    # This processor changes the problem kind: strict P/R obligations become
    # the strict part of a relative TRS and weak P/R obligations its relative
    # rules.  Its recursive TRS proof is independently replayable and must
    # not be flattened into the enclosing DP fragment.
    "switchToTRS",
    # The generated unary TRS is deterministically reconstructed from the
    # current two-stack QDP pairs.  Keeping this boundary explicit lets the
    # generated SRS use its own recursively keyed oracle proof.
    "qdpToSrs",
    # Ferrum/CeTA's Q-monotonic innermost processor is recursive just like
    # monoRedPairProc: it deletes the explicit strict DP/rule payload and
    # hands the resulting DP problem to its nested dpProof.
    "innermostMonoRedPairProc",
    # This is a real state transition: it replaces the innermost Q/LHS
    # obligation used by every processor below it.  Treating it as transparent
    # leaves otherwise exact continuations attached to the unreduced Q state.
    "innermostLhssRemovalProc",
    # The verified MU-TERM wrapper fixes the active ordinary-rule component
    # for its complete child proof.  It is therefore an executable state
    # transition, not transparent proof syntax.
    "localUsableRulesProc",
    "csrGuardedDepGraphProc",
    "csrRedPairUrProc",
    # Applicative-top uncurrying is a recursive DP transformation. Its
    # transformed R/P obligation is already reconstructed by child_input_for;
    # emitting the node here keeps the step attached to the actual split or
    # graph residual instead of the root-only compatibility fallback.
    "uncurryProc",
}


def xml_text(elem: ET.Element) -> str:
    return ET.tostring(elem, encoding="utf-8", short_empty_elements=True).decode("utf-8", "replace")


def input_wrapper(inner: ET.Element) -> ET.Element:
    wrapper = ET.Element("input")
    wrapper.append(deepcopy(inner))
    return wrapper


def set_strict_rule_context(dp_input: ET.Element, strict_trs: ET.Element | None) -> None:
    """Record generalized-DP strict ordinary rules in private state metadata."""
    for context in list(dp_input):
        if local_name(context.tag) == "ferrumDpStateContext":
            break
    else:
        context = ET.SubElement(dp_input, "ferrumDpStateContext")
    for existing in list(context):
        if local_name(existing.tag) == "strictRules":
            context.remove(existing)
    rules = first_child(strict_trs, "rules") if strict_trs is not None else None
    if rules is not None and list(rules):
        strict = ET.SubElement(context, "strictRules")
        strict.append(deepcopy(rules))
    if not list(context):
        dp_input.remove(context)


def parent_map(root: ET.Element) -> dict[int, ET.Element]:
    return {id(child): parent for parent in root.iter() for child in list(parent)}


def local_context(parent: ET.Element | None, elem: ET.Element) -> str | None:
    if parent is None:
        return None
    parent_copy = ET.Element(local_name(parent.tag), dict(parent.attrib))
    for child in list(parent):
        if child is elem:
            parent_copy.append(ET.Element("proofHole", {"tag": local_name(elem.tag)}))
        else:
            parent_copy.append(copy(child))
    return xml_text(parent_copy)


def proof_child(elem: ET.Element, proof_tag: str) -> ET.Element | None:
    for child in list(elem):
        if local_name(child.tag) == proof_tag:
            return child
    return None


def unwrap_proof_step(proof_elem: ET.Element) -> ET.Element | None:
    if local_name(proof_elem.tag) not in {
        "trsTerminationProof",
        "trsNonterminationProof",
        "dpProof",
        "dpNonterminationProof",
        "relativeNonterminationProof",
        "csrTerminationProof",
        "csrDpProof",
        "mutermTypedDpProof",
    }:
        return None
    for child in list(proof_elem):
        if local_name(child.tag) not in {"terminationAssumption", "finitenessAssumption", "unknownProof"}:
            return child
    return None


def inner_input(input_elem: ET.Element) -> ET.Element | None:
    if local_name(input_elem.tag) == "input":
        trs_input = first_child(input_elem, "trsInput")
        if trs_input is not None:
            return trs_input
        return first_child(input_elem, "dpInput")
    if local_name(input_elem.tag) in {"trsInput", "dpInput"}:
        return input_elem
    return None


def innermost_input(current_input: ET.Element) -> ET.Element:
    updated = deepcopy(current_input)
    current_inner = inner_input(updated)
    if current_inner is None:
        return updated
    for child in list(current_inner):
        if local_name(child.tag) == "strategy":
            current_inner.remove(child)
    strategy = ET.SubElement(current_inner, "strategy")
    innermost = ET.SubElement(strategy, "innermost")
    # CPF's top-level switch establishes the Q-normal-form side condition
    # used by the native innermost DP problem.  Omitting it made reconstructed
    # child states look like a different, weaker innermost problem, so their
    # independently certified continuations were unfindable at runtime.
    ET.SubElement(innermost, "nfs").text = "true"
    return updated


def full_input(current_input: ET.Element) -> ET.Element:
    updated = deepcopy(current_input)
    current_inner = inner_input(updated)
    if current_inner is None:
        return updated
    for child in list(current_inner):
        if local_name(child.tag) == "strategy":
            current_inner.remove(child)
    return updated


def strict_part_input(current_input: ET.Element) -> ET.Element:
    """Project a relative TRS obligation to its strict ordinary TRS.

    CPF's ``ignoreRelativePart`` nontermination processor proves a loop using
    only strict rules.  Its recursive ``trsNonterminationProof`` therefore has
    an ordinary TRS input, not the parent relative input.
    """
    updated = deepcopy(current_input)
    current_inner = inner_input(updated)
    if current_inner is None:
        return updated
    for child in list(current_inner):
        if local_name(child.tag) == "relativeRules":
            current_inner.remove(child)
    return updated


def ordinary_transformed_input(
    current_input: ET.Element, transformed_trs: ET.Element
) -> ET.Element | None:
    """Build the ordinary child obligation of a relative transformation.

    ``flatContextClosure`` certifies termination of the printed union TRS.
    Its recursive proof is therefore not a relative state and must not retain
    the parent's ``relativeRules`` component.
    """
    ordinary_parent = strict_part_input(current_input)
    inner = trs_input_like(ordinary_parent, transformed_trs)
    return input_wrapper(inner) if inner is not None else None


def gm04_source_csr_input(step: ET.Element) -> ET.Element | None:
    """Reconstruct the original CSR obligation carried by GM04 inverse CPF.

    ``gm04CompleteTransformation`` proves two independent obligations: the
    transformed ordinary TRS from the enclosing input and the original CSR
    printed in ``sourceTrs``/``sourceReplacementMap``.  The latter is not a
    child of the enclosing input syntactically, so generic residual propagation
    cannot discover it.
    """
    source_trs = first_child(step, "sourceTrs")
    source_map = first_child(step, "sourceReplacementMap")
    context_sensitive = (
        first_child(source_map, "contextSensitive")
        if source_map is not None
        else None
    )
    rules = first_child(source_trs, "rules") if source_trs is not None else None
    if rules is None or context_sensitive is None:
        return None

    wrapper = ET.Element("input")
    trs_input = ET.SubElement(wrapper, "trsInput")
    trs = ET.SubElement(trs_input, "trs")
    trs.append(deepcopy(rules))
    strategy = ET.SubElement(trs_input, "strategy")
    strategy.append(deepcopy(context_sensitive))
    return wrapper


def _unlabeled_rule_signature(rule: ET.Element) -> tuple[Any, Any]:
    variables: dict[str, int] = {}

    def term_signature(term: ET.Element) -> Any:
        tag = local_name(term.tag)
        if tag == "var":
            name = (term.text or "").strip()
            return ("var", variables.setdefault(name, len(variables)))
        if tag != "funapp" or not list(term):
            return (tag, (term.text or "").strip())
        symbol = list(term)[0]
        symbol_tag = local_name(symbol.tag)
        if symbol_tag == "labeledSymbol":
            name = first_child(symbol, "name")
            sharp = first_child(symbol, "sharp")
            base = (name.text or "").strip() if name is not None else ""
            if not base and sharp is not None:
                sharp_name = first_child(sharp, "name")
                base = ((sharp_name.text or "").strip() + "#") if sharp_name is not None else ""
        elif symbol_tag == "sharp":
            name = first_child(symbol, "name")
            base = ((name.text or "").strip() + "#") if name is not None else ""
        else:
            base = (symbol.text or "").strip()
        return ("app", base, tuple(term_signature(child) for child in list(term)[1:]))

    children = list(rule)
    return (term_signature(children[0]), term_signature(children[1]))


def semantic_labeled_relative_input(
    current_input: ET.Element, transformed_trs: ET.Element
) -> ET.Element | None:
    """Recover the labeled strict/weak split hidden by CPF's semlab payload."""
    current_inner = inner_input(current_input)
    current_strict = first_child(current_inner, "trs") if current_inner is not None else None
    current_weak = first_child(current_inner, "relativeRules") if current_inner is not None else None
    transformed_rules = first_child(transformed_trs, "rules")
    if current_strict is None or current_weak is None or transformed_rules is None:
        return ordinary_transformed_input(current_input, transformed_trs)

    def signatures(container: ET.Element) -> set[tuple[Any, Any]]:
        rules = first_child(container, "rules")
        return {
            _unlabeled_rule_signature(rule)
            for rule in (list(rules) if rules is not None else [])
            if local_name(rule.tag) == "rule"
        }

    strict_signatures = signatures(current_strict)
    weak_signatures = signatures(current_weak)
    strict_rules: list[ET.Element] = []
    weak_rules: list[ET.Element] = []
    for rule in transformed_rules:
        if local_name(rule.tag) != "rule":
            continue
        signature = _unlabeled_rule_signature(rule)
        if signature in strict_signatures:
            strict_rules.append(deepcopy(rule))
        if signature in weak_signatures:
            weak_rules.append(deepcopy(rule))
    if not strict_rules or len(strict_rules) + len(weak_rules) < len(list(transformed_rules)):
        return None

    child = ET.Element("trsInput")
    strict = ET.SubElement(child, "trs")
    strict_container = ET.SubElement(strict, "rules")
    strict_container.extend(strict_rules)
    weak = ET.SubElement(child, "relativeRules")
    weak_container = ET.SubElement(weak, "rules")
    weak_container.extend(weak_rules)
    strategy = first_child(current_inner, "strategy")
    if strategy is not None:
        child.append(deepcopy(strategy))
    return input_wrapper(child)


def flat_context_relative_input(
    current_input: ET.Element, transformed_trs: ET.Element
) -> ET.Element | None:
    """Recover the strict/weak partition produced by CPF flat contexts."""
    current_inner = inner_input(current_input)
    current_strict = first_child(current_inner, "trs") if current_inner is not None else None
    current_weak = first_child(current_inner, "relativeRules") if current_inner is not None else None
    transformed_rules = first_child(transformed_trs, "rules")
    if current_strict is None or current_weak is None or transformed_rules is None:
        return ordinary_transformed_input(current_input, transformed_trs)

    def signatures(container: ET.Element) -> set[tuple[Any, Any]]:
        rules = first_child(container, "rules")
        return {
            _unlabeled_rule_signature(rule)
            for rule in (list(rules) if rules is not None else [])
            if local_name(rule.tag) == "rule"
        }

    strict_signatures = signatures(current_strict)
    weak_signatures = signatures(current_weak)

    def possible_origins(rule: ET.Element) -> set[tuple[Any, Any]]:
        origins = {_unlabeled_rule_signature(rule)}
        sides = list(rule)
        if len(sides) != 2 or any(local_name(side.tag) != "funapp" for side in sides):
            return origins
        left, right = sides
        left_children, right_children = list(left), list(right)
        if len(left_children) != len(right_children) or not left_children:
            return origins
        if xml_text(left_children[0]) != xml_text(right_children[0]):
            return origins
        for position in range(1, len(left_children)):
            if any(
                xml_text(left_children[index]) != xml_text(right_children[index])
                for index in range(1, len(left_children))
                if index != position
            ):
                continue
            candidate = ET.Element("rule")
            candidate.append(deepcopy(left_children[position]))
            candidate.append(deepcopy(right_children[position]))
            origins.add(_unlabeled_rule_signature(candidate))
        return origins

    strict_rules: list[ET.Element] = []
    weak_rules: list[ET.Element] = []
    for rule in transformed_rules:
        if local_name(rule.tag) != "rule":
            continue
        origins = possible_origins(rule)
        if origins & strict_signatures:
            strict_rules.append(deepcopy(rule))
        if origins & weak_signatures:
            weak_rules.append(deepcopy(rule))
    if not strict_rules or len(strict_rules) + len(weak_rules) < len(list(transformed_rules)):
        return None
    child = ET.Element("trsInput")
    strict = ET.SubElement(child, "trs")
    ET.SubElement(strict, "rules").extend(strict_rules)
    weak = ET.SubElement(child, "relativeRules")
    ET.SubElement(weak, "rules").extend(weak_rules)
    strategy = first_child(current_inner, "strategy")
    if strategy is not None:
        child.append(deepcopy(strategy))
    return input_wrapper(child)


def relative_input_after_rule_removal(
    current_input: ET.Element, removed: ET.Element
) -> ET.Element | None:
    """Subtract a relative rule-removal payload from both R and S."""
    current_inner = inner_input(current_input)
    if current_inner is None:
        return None
    current_trs = first_child(current_inner, "trs")
    if current_trs is None:
        return None
    residual = trs_input_like(current_input, subtract_trs(current_trs, removed))
    if residual is None:
        return None
    current_weak = first_child(current_inner, "relativeRules")
    if current_weak is None:
        return input_wrapper(residual)
    residual_weak = subtract_trs(current_weak, removed)
    residual_weak.tag = "relativeRules"
    copied_weak = first_child(residual, "relativeRules")
    if copied_weak is not None:
        residual.remove(copied_weak)
    residual.append(residual_weak)
    return input_wrapper(residual)


def relative_input_after_bounds(
    current_input: ET.Element, removed: ET.Element
) -> ET.Element | None:
    """Move a relative-bounds payload from strict rules to weak rules."""
    current_inner = inner_input(current_input)
    if current_inner is None:
        return None
    current_trs = first_child(current_inner, "trs")
    if current_trs is None:
        return None

    residual = trs_input_like(current_input, subtract_trs(current_trs, removed))
    if residual is None:
        return None
    existing_weak = first_child(residual, "relativeRules")
    if existing_weak is None:
        existing_weak = ET.Element("relativeRules")
        ET.SubElement(existing_weak, "rules")
        strategy = first_child(residual, "strategy")
        insertion_index = list(residual).index(strategy) if strategy is not None else len(residual)
        residual.insert(insertion_index, existing_weak)
    weak_rules = first_child(existing_weak, "rules")
    removed_rules = first_child(removed, "rules")
    if weak_rules is None:
        weak_rules = ET.SubElement(existing_weak, "rules")
    existing_keys = {
        rule_key(rule)
        for rule in weak_rules
        if local_name(rule.tag) == "rule"
    }
    if removed_rules is not None:
        for rule in removed_rules:
            if local_name(rule.tag) != "rule" or rule_key(rule) in existing_keys:
                continue
            weak_rules.append(deepcopy(rule))
            existing_keys.add(rule_key(rule))
    return input_wrapper(residual)


def relative_input_after_dp_switch(current_input: ET.Element) -> ET.Element | None:
    """Reconstruct CPF ``switchToTRS``'s strict/weak relative child.

    The checked processor embeds ``(P/Pw, Q, R/Rw)`` as
    ``(P union R)/(Pw union Rw)``.  Ferrum records weak pairs separately and
    may carry a strict ordinary-rule subset plus an active-rule residual in
    its typed DP context.  Preserve those distinctions exactly.
    """
    current = inner_input(current_input)
    if current is None or local_name(current.tag) != "dpInput":
        return None
    dps = first_child(current, "dps")
    base_rules = first_child(current, "usableRules")
    if base_rules is None:
        base_rules = first_child(current, "trs")
    if dps is None or base_rules is None:
        return None

    weak_dps = first_child(current, "ferrumWeakDps")
    strict_dps = (
        subtract_alpha_equivalent_rules(dps, weak_dps)
        if weak_dps is not None
        else deepcopy(dps)
    )
    context = first_child(current, "ferrumDpStateContext")
    strict_rules = first_child(context, "strictRules") if context is not None else None
    weak_rules = (
        subtract_alpha_equivalent_rules(base_rules, strict_rules)
        if strict_rules is not None
        else deepcopy(base_rules)
    )

    child = ET.Element("trsInput")
    strict = ET.SubElement(child, "trs")
    strict_container = ET.SubElement(strict, "rules")
    for source in (strict_dps, strict_rules):
        rules = first_child(source, "rules") if source is not None else None
        if rules is not None:
            strict_container.extend(deepcopy(list(rules)))
    weak = ET.SubElement(child, "relativeRules")
    weak_container = ET.SubElement(weak, "rules")
    for source in (weak_dps, weak_rules):
        rules = first_child(source, "rules") if source is not None else None
        if rules is not None:
            weak_container.extend(deepcopy(list(rules)))
    return input_wrapper(child)


def normalized_rule_signature(rule: ET.Element) -> Any:
    """Identify one CPF rule modulo presentation-only differences.

    Variables are local to a rule, and CPF permits numeric symbols both as
    ``0`` and ``|0|``.  Exact processors must not lose a certified rule merely
    because an intermediate serializer chose different variable names or the
    alternate numeric spelling.
    """
    variables: dict[str, int] = {}

    def normalized_symbol(name: str) -> str:
        if len(name) >= 3 and name.startswith("|") and name.endswith("|"):
            inner = name[1:-1]
            if inner and inner[0].isdigit():
                return inner
        return name

    def term_signature(term: ET.Element) -> Any:
        tag = local_name(term.tag)
        if tag == "var":
            name = (term.text or "").strip()
            return ("var", variables.setdefault(name, len(variables)))
        if tag != "funapp" or not list(term):
            return (tag, " ".join((term.text or "").split()))
        symbol = list(term)[0]
        symbol_tag = local_name(symbol.tag)
        if symbol_tag != "name" and not (
            symbol_tag == "sharp" and first_child(symbol, "name") is not None
        ):
            # Labels are part of symbol identity, not XML decoration. Reading
            # only symbol.text identifies every labeled symbol with the empty
            # string and can delete the wrong pair in a reconstructed child.
            def structured_symbol(node: ET.Element) -> Any:
                return (local_name(node.tag), " ".join((node.text or "").split()),
                        tuple(structured_symbol(child) for child in node))
            base = structured_symbol(symbol)
        elif symbol_tag == "sharp":
            name = first_child(symbol, "name")
            base = ((name.text or "").strip() + "#") if name is not None else ""
        else:
            base = (symbol.text or "").strip()
        return (
            "app",
            normalized_symbol(base) if isinstance(base, str) else base,
            tuple(term_signature(child) for child in list(term)[1:]),
        )

    children = list(rule)
    # Synthetic audit fixtures may use an opaque ``<rule/>``.  Preserve the
    # previous exact matching behavior for such non-CPF placeholders.
    if len(children) != 2:
        return ("raw", rule_key(rule))
    return (term_signature(children[0]), term_signature(children[1]))


def replaced_dp_input(
    current_input: ET.Element,
    selected_rule: ET.Element,
    replacement_rules: ET.Element,
) -> ET.Element | None:
    current_inner = inner_input(current_input)
    if current_inner is None:
        return None
    current_dps = first_child(current_inner, "dps")
    current_trs = first_child(current_inner, "trs")
    if current_dps is None or current_trs is None:
        return None
    # Proof artifacts and live CPF inputs can differ in rule-local variable
    # names and in CPF's two spellings of numeric symbols (``0``/``|0|``).
    # Bytewise subtraction consequently used to retain the selected pair and
    # append its instances, turning a certified replacement P - {p} + I into
    # the different obligation P + I.  Match one multiset occurrence modulo
    # those presentation choices.  Removing exactly one occurrence matters
    # when a DP problem contains duplicate pairs.

    current_rules = first_child(current_dps, "rules")
    if current_rules is None:
        return None
    selected_signature = normalized_rule_signature(selected_rule)
    residual = ET.Element("dps")
    residual_rules = ET.SubElement(residual, "rules")
    removed = False
    for rule in current_rules:
        if (
            not removed
            and local_name(rule.tag) == "rule"
            and normalized_rule_signature(rule) == selected_signature
        ):
            removed = True
            continue
        residual_rules.append(deepcopy(rule))
    if not removed:
        return None
    generated_rules = first_child(replacement_rules, "rules")
    if generated_rules is None:
        return None
    residual_rules.extend(deepcopy(rule) for rule in list(generated_rules))
    return input_wrapper(dp_input_like(current_input, dps_elem=residual, trs_elem=current_trs))

def dp_input_with_active_rules(
    current_input: ET.Element,
    dps_elem: ET.Element,
    active_rules_elem: ET.Element,
) -> ET.Element | None:
    """Preserve the full DP rewrite system and record the active R separately.

    Replacing ``<trs>`` with ``<usableRules>`` loses the parent state and, for
    CSR problems, can also invalidate the replacement map.  Ferrum's runtime
    state keeps the original R and carries the currently active rules as a
    separate obligation, so extracted proof states must use the same shape.
    """
    current_inner = inner_input(current_input)
    if current_inner is None or local_name(current_inner.tag) != "dpInput":
        return None
    current_trs = first_child(current_inner, "trs")
    if current_trs is None:
        return None
    result = ET.Element("dpInput")
    result.append(deepcopy(current_trs))
    result.append(deepcopy(dps_elem))
    # Generalized DP problems keep a weak-pair submultiset of P.  Reduction
    # pairs and usable-rule restrictions preserve that classification for
    # every surviving pair.  The old reconstruction silently discarded it,
    # causing nested exact witnesses to be indexed under an ordinary DP state
    # and then offered to the wrong live sibling.
    current_weak = first_child(current_inner, "ferrumWeakDps")
    if current_weak is not None:
        surviving_rules = first_child(dps_elem, "rules")
        remaining = {}
        for rule in list(surviving_rules) if surviving_rules is not None else []:
            key = rule_key(rule)
            remaining[key] = remaining.get(key, 0) + 1
        weak = ET.Element("ferrumWeakDps")
        weak_rules = ET.SubElement(weak, "rules")
        source_weak_rules = first_child(current_weak, "rules")
        for rule in list(source_weak_rules) if source_weak_rules is not None else []:
            key = rule_key(rule)
            if remaining.get(key, 0) <= 0:
                continue
            weak_rules.append(deepcopy(rule))
            remaining[key] -= 1
        if list(weak_rules):
            result.append(weak)
    usable = deepcopy(active_rules_elem)
    usable.tag = "usableRules"
    result.append(usable)
    strategy = first_child(current_inner, "strategy")
    if strategy is not None:
        result.append(deepcopy(strategy))
    minimal = first_child(current_inner, "minimal")
    if minimal is not None:
        result.append(deepcopy(minimal))
    else:
        minimal = ET.SubElement(result, "minimal")
        minimal.text = "true"
    context = first_child(current_inner, "ferrumCsrDpContext")
    if context is not None:
        result.append(deepcopy(context))
    runtime_context = first_child(current_inner, "ferrumDpStateContext")
    if runtime_context is not None:
        result.append(deepcopy(runtime_context))
    return input_wrapper(result)


def dp_input_after_monotone_rule_removal(
    current_input: ET.Element,
    dps_elem: ET.Element,
    residual_rules_elem: ET.Element,
) -> ET.Element | None:
    """Materialize Ferrum's recursive monotone reduction-pair state.

    A monotone processor deletes every non-usable rule plus its explicitly
    strict usable rules from the residual base TRS.  Ferrum therefore carries
    ``R'`` as the child ``trs`` itself, with no redundant active-rule override,
    and records the same set as transformation context.  Reconstructing the
    older ``R + usableRules=R'`` spelling changes exact transformation source
    checks and orphaned the next nested oracle state.
    """
    child = dp_input_like(
        current_input,
        dps_elem=dps_elem,
        trs_elem=residual_rules_elem,
    )
    if child is None:
        return None
    for existing in list(child):
        if local_name(existing.tag) == "usableRules":
            child.remove(existing)
    context = first_child(child, "ferrumDpStateContext")
    if context is None:
        context = ET.SubElement(child, "ferrumDpStateContext")
    for existing in list(context):
        if local_name(existing.tag) in {"graphRules", "transformationRules"}:
            context.remove(existing)
    transformation = deepcopy(residual_rules_elem)
    transformation.tag = "transformationRules"
    context.append(transformation)
    return input_wrapper(child)


def dp_input_with_innermost_lhss(
    current_input: ET.Element,
    innermost_lhss_elem: ET.Element,
) -> ET.Element | None:
    """Materialize the child of CPF ``innermostLhssRemovalProc`` exactly."""
    updated = deepcopy(current_input)
    current_inner = inner_input(updated)
    if current_inner is None or local_name(current_inner.tag) != "dpInput":
        return None
    strategy = first_child(current_inner, 'strategy')
    if strategy is not None:
        for old in list(strategy):
            if local_name(old.tag) == 'innermostLhss':
                strategy.remove(old)
        if not list(strategy):
            current_inner.remove(strategy)
    context = first_child(current_inner, "ferrumDpStateContext")
    if context is None:
        context = ET.SubElement(current_inner, "ferrumDpStateContext")
    for child in list(context):
        if local_name(child.tag) in {"innermostLhss", "noInnermostLhss"}:
            context.remove(child)
    context.append(deepcopy(innermost_lhss_elem))
    return updated


def qdp_to_srs_child(current_input: ET.Element) -> ET.Element | None:
    """Recompute Ferrum/CPF's certified two-stack QDP-to-SRS child.

    The CPF ``qdpToSrs`` node carries no duplicate generated TRS.  Its rules
    are a deterministic projection of the current dependency pairs, so an
    independently keyed oracle continuation must reconstruct that projection
    rather than treating the whole nested proof as one opaque fragment.
    """
    current = inner_input(current_input)
    dps = first_child(current, "dps") if current is not None else None
    pair_rules = first_child(dps, "rules") if dps is not None else None
    if pair_rules is None or not list(pair_rules):
        return None

    def symbol_key(symbol: ET.Element) -> str:
        if local_name(symbol.tag) == "sharp":
            name = first_child(symbol, "name")
            return "#" + ((name.text or "").strip() if name is not None else "")
        return local_name(symbol.tag) + ":" + (symbol.text or "").strip()

    def unary_var(term: ET.Element) -> tuple[list[ET.Element], str] | None:
        if local_name(term.tag) == "var":
            return [], (term.text or "").strip()
        if local_name(term.tag) != "funapp" or len(list(term)) != 2:
            return None
        symbol, argument = list(term)
        tail = unary_var(argument)
        if tail is None:
            return None
        prefix, variable = tail
        return [deepcopy(symbol), *prefix], variable

    def unary_term(prefix: list[ET.Element], variable: str) -> ET.Element:
        tail = ET.Element("var")
        tail.text = variable
        for symbol in reversed(prefix):
            application = ET.Element("funapp")
            application.append(deepcopy(symbol))
            application.append(tail)
            tail = application
        return tail

    generated_rules = ET.Element("rules")
    for pair in pair_rules:
        if local_name(pair.tag) != "rule" or len(list(pair)) != 2:
            return None
        lhs, rhs = list(pair)
        if (
            local_name(lhs.tag) != "funapp"
            or local_name(rhs.tag) != "funapp"
            or len(list(lhs)) != 3
            or len(list(rhs)) != 3
            or symbol_key(list(lhs)[0]) != symbol_key(list(rhs)[0])
        ):
            return None
        lhs_first, lhs_second = list(lhs)[1:]
        rhs_first, rhs_second = list(rhs)[1:]
        if local_name(lhs_first.tag) == "var" and local_name(rhs_second.tag) == "var":
            x = (lhs_first.text or "").strip()
            y = (rhs_second.text or "").strip()
            left = unary_var(lhs_second)
            right = unary_var(rhs_first)
            if (
                not x
                or not y
                or x == y
                or left is None
                or right is None
                or left[1] != y
                or right[1] != x
                or not left[0]
                or not right[0]
            ):
                return None
            rule = ET.SubElement(generated_rules, "rule")
            rule.append(unary_term(left[0], x))
            rule.append(unary_term(list(reversed(right[0])), x))
            continue

        left = unary_var(lhs_first)
        right = unary_var(rhs_second)
        if (
            left is None
            or right is None
            or len(left[0]) != 1
            or len(right[0]) != 1
            or symbol_key(left[0][0]) != symbol_key(right[0][0])
            or local_name(lhs_second.tag) != "var"
            or local_name(rhs_first.tag) != "var"
            or left[1] != (rhs_first.text or "").strip()
            or right[1] != (lhs_second.text or "").strip()
            or left[1] == right[1]
        ):
            return None
        # Transfer pairs only move one stack symbol and generate no SRS rule.

    trs_input = ET.Element("trsInput")
    trs = ET.SubElement(trs_input, "trs")
    trs.append(generated_rules)
    return input_wrapper(trs_input)


def ordinary_dp_child_below_usable_rules(
    current_input: ET.Element,
    dps_elem: ET.Element,
    usable_rules_elem: ET.Element,
) -> ET.Element | None:
    """Materialize CPF ``usableRulesProc``'s exact child obligation.

    The processor restricts the active rules while preserving an ordinary
    innermost minimal-DP obligation.  The currently represented typed CSR
    usable-rule processors do drop minimality; a following
    ``ordinaryDpProof`` is their explicit context-changing boundary.
    """
    wrapped = dp_input_with_active_rules(current_input, dps_elem, usable_rules_elem)
    inner = inner_input(wrapped) if wrapped is not None else None
    if inner is None:
        return None
    if first_child(inner, "ferrumCsrDpContext") is not None:
        minimal = first_child(inner, "minimal")
        if minimal is None:
            minimal = ET.SubElement(inner, "minimal")
        minimal.text = "false"
    return wrapped


def ordinary_dp_child_below_red_pair(
    current_input: ET.Element,
    dps_elem: ET.Element,
    active_rules_elem: ET.Element,
) -> ET.Element | None:
    """Materialize the child below an ordinary reduction-pair processor.

    A plain ``redPairProc`` does not change an ordinary DP problem's rewrite
    strategy.  In particular, an innermost DP residual remains innermost.
    Only a typed CSR-DP state uses the plain ``dpProof`` child as its explicit
    boundary to ordinary rewriting; in that case its CSR construction and
    context-sensitive strategy cease to apply.
    """
    wrapped = dp_input_with_active_rules(current_input, dps_elem, active_rules_elem)
    inner = inner_input(wrapped) if wrapped is not None else None
    if inner is None:
        return None
    if first_child(inner, "ferrumCsrDpContext") is not None:
        for child in list(inner):
            if local_name(child.tag) in {"ferrumCsrDpContext", "strategy"}:
                inner.remove(child)
    return wrapped


def subtract_alpha_equivalent_rules(
    current: ET.Element, removed: ET.Element
) -> ET.Element:
    """Subtract a CPF rule multiset modulo per-rule variable renaming."""
    result = deepcopy(current)
    result_rules = first_child(result, "rules")
    removed_rules = first_child(removed, "rules")
    if result_rules is None or removed_rules is None:
        return result
    available = list(result_rules)
    for removed_rule in removed_rules:
        if local_name(removed_rule.tag) != "rule":
            continue
        signature = normalized_rule_signature(removed_rule)
        match = next(
            (
                rule
                for rule in available
                if local_name(rule.tag) == "rule"
                and normalized_rule_signature(rule) == signature
            ),
            None,
        )
        if match is not None:
            result_rules.remove(match)
            available.remove(match)
    return result


def ordinary_dp_child_at_explicit_boundary(
    current_input: ET.Element,
) -> ET.Element | None:
    """Materialize the child of CPF ``ordinaryDpProof`` exactly.

    The wrapper is the checked boundary from a typed CSR-DP obligation to an
    ordinary DP obligation.  The rules, pairs, minimality bit, and Ferrum's
    ordinary DP provenance remain unchanged; only the CSR strategy and CSR
    construction context cease to apply.
    """
    wrapped = deepcopy(current_input)
    inner = inner_input(wrapped)
    if inner is None or local_name(inner.tag) != "dpInput":
        return None
    for child in list(inner):
        if local_name(child.tag) in {"ferrumCsrDpContext", "strategy"}:
            inner.remove(child)
    return wrapped

def add_csr_dp_context(dp_input: ET.Element, construction: str) -> ET.Element:
    result = deepcopy(dp_input)
    inner = inner_input(result)
    if inner is None:
        return result
    context = ET.SubElement(inner, "ferrumCsrDpContext")
    value = ET.SubElement(context, "construction")
    value.text = construction
    graph = ET.SubElement(context, "graphEstimator")
    graph.text = (
        "context-sensitive"
        if construction in {"native", "improved", "safe"}
        else "ordinary"
    )
    qcs = ET.SubElement(context, "qcsUsableRules")
    qcs.text = "false"
    return result


def append_dps(current_dps: ET.Element, additional_dps: ET.Element) -> ET.Element:
    """Return the exact DP union used by complete nontermination processors."""
    result = deepcopy(current_dps)
    result_rules = first_child(result, "rules")
    additional_rules = first_child(additional_dps, "rules")
    if result_rules is None:
        result_rules = ET.SubElement(result, "rules")
    if additional_rules is not None:
        for rule in list(additional_rules):
            result_rules.append(deepcopy(rule))
    return result


def child_input_for(parent_step: ET.Element, child_proof: ET.Element, current_input: ET.Element) -> tuple[ET.Element | None, str | None]:
    parent_name = local_name(parent_step.tag)
    child_name = local_name(child_proof.tag)
    current_inner = inner_input(current_input)
    if current_inner is None:
        return None, "current_input_not_trs_or_dp"

    if (
        child_name == "mutermTypedDpProof"
        and parent_name == "csrMutermTypedDependencyPairs"
    ):
        dps = first_child(parent_step, "dps")
        if dps is None:
            return None, "csrMutermTypedDependencyPairs_missing_dps"
        child_input = dp_input_like(current_input, dps_elem=dps)
        if child_input is None:
            return None, "csrMutermTypedDependencyPairs_invalid_dp_input"
        # The verified processor establishes a minimal typed MU-TERM problem.
        # Ferrum's live serializer carries the construction and its ordinary
        # graph estimator explicitly, so retain them in the independently
        # addressable child obligation as well.
        return add_csr_dp_context(
            input_wrapper(child_input), "muterm-unhiding"
        ), None

    if child_name == "dpProof" and parent_name == "localUsableRulesProc":
        usable = first_child(parent_step, "usableRules")
        current_dps = first_child(current_inner, "dps")
        if usable is None or current_dps is None:
            return None, "localUsableRulesProc_missing_payload"
        child_input = dp_input_with_active_rules(current_input, current_dps, usable)
        child_inner = inner_input(child_input) if child_input is not None else None
        if child_inner is None:
            return None, "localUsableRulesProc_invalid_dp_input"
        # The local MU-TERM processor preserves its typed CSR construction,
        # but its ordinary `dpProof` child is no longer a minimal-chain
        # obligation.  This bit is semantically independent of the context
        # marker and is part of Ferrum's live state key.
        minimal = first_child(child_inner, "minimal")
        if minimal is None:
            minimal = ET.SubElement(child_inner, "minimal")
        minimal.text = "false"
        return child_input, None

    # This bridge only selects the theorem used for the unchanged child
    # obligation.  Unlike localUsableRulesProc, it does not change active R.
    if (
        child_name in {"dpProof", "csrDpProof"}
        and parent_name == "noncollapsingCsrProof"
    ):
        return deepcopy(current_input), None

    if child_name in {"dpProof", "dpNonterminationProof"} and parent_name == "dpTrans":
        dps = first_child(parent_step, "dps")
        if dps is None:
            return None, "dpTrans_missing_dps"
        return input_wrapper(dp_input_like(current_input, dps_elem=dps)), None

    if child_name == "dpNonterminationProof" and parent_name == "instantiationProc":
        current_dps = first_child(current_inner, "dps")
        instantiated = first_child(parent_step, "dps")
        if current_dps is None or instantiated is None:
            return None, "instantiationProc_missing_dps"
        # CeTA instantiation_complete_proc replaces P by the displayed
        # instances and clears minimality; it does not append them to P.
        child = dp_input_like(current_input, dps_elem=instantiated)
        minimal = first_child(child, "minimal")
        if minimal is None:
            minimal = ET.SubElement(child, "minimal")
        minimal.text = "false"
        return input_wrapper(child), None

    if child_name == "dpNonterminationProof" and parent_name == "dpRuleRemoval":
        current_dps = first_child(current_inner, "dps")
        current_trs = first_child(current_inner, "trs")
        removed_dps = first_child(parent_step, "dps")
        removed_trs = first_child(parent_step, "trs")
        if (
            current_dps is None
            or current_trs is None
            or removed_dps is None
            or removed_trs is None
        ):
            return None, "dpRuleRemoval_missing_payload"
        if parent_step.get("ferrumLegacyRetainedSubproblem") == "true":
            # CPF 2.1's nontermination rule-removal node stores the retained
            # subproblem.  CPF 3 stores the removed complement.  Confusing the
            # two turns (for example) a 187 -> 165 restriction into 187 -> 22
            # and destroys every following state identity.
            return input_wrapper(
                dp_input_like(
                    current_input,
                    dps_elem=removed_dps,
                    trs_elem=removed_trs,
                )
            ), None
        return input_wrapper(
            dp_input_like(
                current_input,
                dps_elem=subtract_dps(current_dps, removed_dps),
                trs_elem=subtract_trs(current_trs, removed_trs),
            )
        ), None

    if child_name == "dpNonterminationProof" and parent_name == "switchFullStrategyProc":
        child_input = deepcopy(current_input)
        child_inner = inner_input(child_input)
        if child_inner is None or local_name(child_inner.tag) != "dpInput":
            return None, "switchFullStrategyProc_invalid_dp_input"
        strategy = first_child(child_inner, "strategy")
        if strategy is not None:
            child_inner.remove(strategy)
        context = first_child(child_inner, "ferrumDpStateContext")
        if context is not None:
            for item in list(context):
                if local_name(item.tag) in {"innermostLhss", "noInnermostLhss"}:
                    context.remove(item)
            if not list(context):
                child_inner.remove(context)
        return child_input, None

    if child_name == "csrDpProof" and parent_name in {
        "csrDependencyPairs",
        "csrImprovedDependencyPairs",
        "csrSafeDependencyPairs",
        "csrConservativeDependencyPairs",
    }:
        dps = first_child(parent_step, "dps")
        if dps is None:
            return None, f"{parent_name}_missing_dps"
        construction = {
            "csrDependencyPairs": "native",
            "csrImprovedDependencyPairs": "improved",
            "csrSafeDependencyPairs": "safe",
            "csrConservativeDependencyPairs": "conservative",
        }[parent_name]
        return add_csr_dp_context(
            input_wrapper(dp_input_like(current_input, dps_elem=dps)),
            construction,
        ), None

    if child_name == "csrDpProof" and parent_name == "csrRuleRemovalThenImproved":
        removed = first_child(parent_step, "trs")
        dps = first_child(parent_step, "dps")
        current_trs = first_child(current_inner, "trs")
        if removed is None or dps is None or current_trs is None:
            return None, "csrRuleRemovalThenImproved_missing_payload"
        residual_input = input_wrapper(
            trs_input_like(current_input, subtract_trs(current_trs, removed))
        )
        dp_input = dp_input_like(residual_input, dps_elem=dps)
        if dp_input is None:
            return None, "csrRuleRemovalThenImproved_invalid_residual"
        return add_csr_dp_context(input_wrapper(dp_input), "improved"), None

    if child_name == "dpProof" and parent_name == "ordinaryDpProof":
        child = ordinary_dp_child_at_explicit_boundary(current_input)
        if child is None:
            return None, "ordinaryDpProof_invalid_dp_input"
        return child, None

    # Once the CSR-DP transformation has established its local DP input, the
    # ordinary DP processors have exactly the same residual-state semantics.
    if child_name in {"csrDpProof", "mutermTypedDpProof"}:
        child_name = "dpProof"

    if child_name == "dpProof" and parent_name == "component":
        dps = first_child(parent_step, "dps")
        if dps is None:
            return None, "component_missing_dps"
        return input_wrapper(dp_input_like(current_input, dps_elem=dps)), None

    if child_name == "dpProof" and parent_name == "depGraphProc":
        return deepcopy(current_input), None

    if child_name == "dpProof" and parent_name == "splitProc":
        current_dps = first_child(current_inner, "dps")
        selected_dps = first_child(parent_step, "dps")
        selected_trs = first_child(parent_step, "trs")
        if current_dps is None or selected_dps is None:
            return None, "splitProc_missing_dps"
        proof_children = [
            child for child in list(parent_step) if local_name(child.tag) == "dpProof"
        ]
        try:
            branch = next(index for index, child in enumerate(proof_children) if child is child_proof)
        except StopIteration:
            return None, "splitProc_unknown_child"
        current_weak = first_child(current_inner, "ferrumWeakDps")
        if branch == 0:
            child_dps = deepcopy(current_dps)
            child_weak = subtract_dps(current_dps, selected_dps)
            child_weak.tag = "ferrumWeakDps"
        elif branch == 1:
            child_dps = subtract_dps(current_dps, selected_dps)
            child_weak = (
                deepcopy(current_weak)
                if current_weak is not None
                else ET.Element("ferrumWeakDps")
            )
            if first_child(child_weak, "rules") is None:
                ET.SubElement(child_weak, "rules")
        else:
            return None, "splitProc_extra_child"
        child_input = dp_input_like(current_input, dps_elem=child_dps)
        if child_input is None:
            return None, "splitProc_invalid_dp_input"
        if branch == 1 and selected_trs is not None:
            active_rules = first_child(current_inner, "usableRules")
            if active_rules is None:
                active_rules = first_child(current_inner, "trs")
            if active_rules is None:
                return None, "splitProc_missing_active_rules"
            residual_active = subtract_alpha_equivalent_rules(active_rules, selected_trs)
            rebound = dp_input_with_active_rules(
                input_wrapper(child_input), child_dps, residual_active
            )
            child_input = inner_input(rebound) if rebound is not None else None
            if child_input is None:
                return None, "splitProc_invalid_rule_residual"
        set_strict_rule_context(child_input, selected_trs if branch == 0 else None)
        for existing in list(child_input):
            if local_name(existing.tag) == "ferrumWeakDps":
                child_input.remove(existing)
        weak_rules = first_child(child_weak, "rules")
        if weak_rules is not None and list(weak_rules):
            minimal = first_child(child_input, "minimal")
            insertion_index = (
                list(child_input).index(minimal)
                if minimal is not None
                else len(child_input)
            )
            child_input.insert(insertion_index, child_weak)
        return input_wrapper(child_input), None

    if child_name == "dpProof" and parent_name == "complexConstantRemovalProc":
        mapping = first_child(parent_step, "ruleMap")
        current_dps = first_child(current_inner, "dps")
        if mapping is None or current_dps is None:
            return None, "complexConstantRemovalProc_missing_mapping"
        replacements = []
        for entry in mapping:
            rules = [r for r in entry if local_name(r.tag) == "rule"]
            if len(rules) != 2:
                return None, "complexConstantRemovalProc_invalid_mapping"
            replacements.append((normalized_rule_signature(rules[0]), rules[1]))
        def converted(container):
            keys = {normalized_rule_signature(r) for rules in container for r in rules}
            if not keys.issubset({key for key, _ in replacements}):
                return None
            result = ET.Element(local_name(container.tag))
            rules = ET.SubElement(result, "rules")
            for key, replacement in replacements:
                if key in keys:
                    rules.append(deepcopy(replacement))
            return result
        pairs = converted(current_dps)
        if pairs is None:
            return None, "complexConstantRemovalProc_incomplete_mapping"
        child = dp_input_like(current_input, dps_elem=pairs)
        if child is None:
            return None, "complexConstantRemovalProc_invalid_input"
        weak = first_child(current_inner, "ferrumWeakDps")
        if weak is not None:
            converted_weak = converted(weak)
            if converted_weak is None:
                return None, "complexConstantRemovalProc_incomplete_weak_mapping"
            for previous in list(child):
                if local_name(previous.tag) == "ferrumWeakDps":
                    child.remove(previous)
            child.append(converted_weak)
        return input_wrapper(child), None

    if child_name == "dpProof" and parent_name == "generalRedPairProc":
        current_dps = first_child(current_inner, "dps")
        strict = first_child(parent_step, "strict")
        bound = first_child(parent_step, "bound")
        if current_dps is None or strict is None or bound is None:
            return None, "generalRedPairProc_missing_payload"
        proof_children = [
            child for child in list(parent_step) if local_name(child.tag) == "dpProof"
        ]
        try:
            branch = next(
                index for index, child in enumerate(proof_children) if child is child_proof
            )
        except StopIteration:
            return None, "generalRedPairProc_unknown_child"
        if len(proof_children) == 1:
            bound_keys = {
                rule_key(rule)
                for rules in bound
                if local_name(rules.tag) == "rules"
                for rule in rules
                if local_name(rule.tag) == "rule"
            }
            removed = ET.Element("dps")
            removed_rules = ET.SubElement(removed, "rules")
            for rules in strict:
                if local_name(rules.tag) != "rules":
                    continue
                for rule in rules:
                    if local_name(rule.tag) == "rule" and rule_key(rule) in bound_keys:
                        removed_rules.append(deepcopy(rule))
        elif len(proof_children) == 2 and branch in {0, 1}:
            removed = deepcopy(strict if branch == 0 else bound)
            removed.tag = "dps"
        else:
            return None, "generalRedPairProc_invalid_branch_count"
        residual_dps = subtract_dps(current_dps, removed)
        child_input = dp_input_like(current_input, dps_elem=residual_dps)
        if child_input is None:
            return None, "generalRedPairProc_invalid_dp_input"
        current_weak = first_child(current_inner, "ferrumWeakDps")
        if current_weak is not None:
            for existing in list(child_input):
                if local_name(existing.tag) == "ferrumWeakDps":
                    child_input.remove(existing)
            residual_weak = subtract_dps(current_weak, removed)
            residual_weak.tag = "ferrumWeakDps"
            weak_rules = first_child(residual_weak, "rules")
            if weak_rules is not None and list(weak_rules):
                minimal = first_child(child_input, "minimal")
                insertion_index = (
                    list(child_input).index(minimal)
                    if minimal is not None
                    else len(child_input)
                )
                child_input.insert(insertion_index, residual_weak)
        return input_wrapper(child_input), None

    if child_name == "dpProof" and parent_name == "usableRulesProc":
        usable = first_child(parent_step, "usableRules")
        current_dps = first_child(current_inner, "dps")
        if usable is None or current_dps is None:
            return None, "usableRulesProc_missing_payload"
        return ordinary_dp_child_below_usable_rules(
            current_input, current_dps, usable
        ), None

    if child_name == "dpProof" and parent_name == "semlabProc":
        labeled_dps = first_child(parent_step, "dps")
        labeled_trs = first_child(parent_step, "trs")
        if labeled_dps is None or labeled_trs is None:
            return None, "semlabProc_missing_payload"
        labeled_input = input_wrapper(
            dp_input_like(current_input, dps_elem=labeled_dps, trs_elem=labeled_trs)
        )
        # The emitted labeled TRS is the new mathematical R. An inherited
        # usableRules marker still contains *unlabeled* rules from the parent
        # and is not an active subset of that R. Root/CSR labeling below adds
        # an explicit marker containing the correctly labeled rules instead.
        labeled_inner = inner_input(labeled_input)
        if labeled_inner is not None:
            for inherited in list(labeled_inner):
                if local_name(inherited.tag) == "usableRules":
                    labeled_inner.remove(inherited)
        is_root_labeling = any(
            local_name(node.tag) == "rootLabeling" for node in parent_step.iter()
        )
        is_csr_labeling = first_child(current_inner, "ferrumCsrDpContext") is not None
        # Ferrum's semantic-labeling continuation makes the labeled R
        # component explicit as the active rule set even when the parent used
        # its implicit full R.  Omitting this marker changes later usable-rule
        # and graph states during independent oracle replay.
        child = (
            dp_input_with_active_rules(labeled_input, labeled_dps, labeled_trs)
            if is_root_labeling or is_csr_labeling
            else labeled_input
        )
        child_inner = inner_input(child) if child is not None else None
        if child_inner is None:
            return None, "semlabProc_invalid_labeled_input"

        # Finite semantic labeling yields a nonminimal residual in Ferrum's
        # extended CSR path.  Native CPF root labeling, however, is the
        # standard minimal-DP processor and preserves minimality.  Both label
        # weak pairs introduced by splitProc as well as the strong pairs
        # printed in CPF's <dps> payload.  Recover the weak subset by stripping
        # labels and matching it to the incoming weak-pair signatures.
        current_weak = first_child(current_inner, "ferrumWeakDps")
        if current_weak is not None:
            weak_rules = first_child(current_weak, "rules")
            weak_signatures = {
                _unlabeled_rule_signature(rule)
                for rule in (list(weak_rules) if weak_rules is not None else [])
                if local_name(rule.tag) == "rule"
            }
            labeled_rules = first_child(labeled_dps, "rules")
            labeled_weak = ET.Element("ferrumWeakDps")
            labeled_weak_rules = ET.SubElement(labeled_weak, "rules")
            for rule in (list(labeled_rules) if labeled_rules is not None else []):
                if (
                    local_name(rule.tag) == "rule"
                    and _unlabeled_rule_signature(rule) in weak_signatures
                ):
                    labeled_weak_rules.append(deepcopy(rule))
            for existing in list(child_inner):
                if local_name(existing.tag) == "ferrumWeakDps":
                    child_inner.remove(existing)
            if list(labeled_weak_rules):
                strategy = first_child(child_inner, "strategy")
                child_inner.insert(
                    list(child_inner).index(strategy)
                    if strategy is not None
                    else len(list(child_inner)),
                    labeled_weak,
                )

        current_context = first_child(current_inner, "ferrumDpStateContext")
        current_strict = (
            first_child(current_context, "strictRules")
            if current_context is not None
            else None
        )
        current_strict_rules = first_child(current_strict, "rules") if current_strict is not None else None
        if current_strict_rules is not None and list(current_strict_rules):
            strict_signatures = {
                _unlabeled_rule_signature(rule)
                for rule in current_strict_rules
                if local_name(rule.tag) == "rule"
            }
            labeled_strict = ET.Element("trs")
            labeled_strict_rules = ET.SubElement(labeled_strict, "rules")
            labeled_rule_container = first_child(labeled_trs, "rules")
            for rule in (list(labeled_rule_container) if labeled_rule_container is not None else []):
                if local_name(rule.tag) == "rule" and _unlabeled_rule_signature(rule) in strict_signatures:
                    labeled_strict_rules.append(deepcopy(rule))
            set_strict_rule_context(child_inner, labeled_strict)

        if is_csr_labeling and not is_root_labeling:
            minimal = first_child(child_inner, "minimal")
            if minimal is None:
                minimal = ET.SubElement(child_inner, "minimal")
            minimal.text = "false"
        context = first_child(child_inner, "ferrumDpStateContext")
        if context is not None:
            for existing in list(context):
                if local_name(existing.tag) in {
                    "innermostLhss",
                    "noInnermostLhss",
                    "graphRules",
                    "transformationRules",
                }:
                    context.remove(existing)
        if is_root_labeling or is_csr_labeling:
            if context is None:
                context = ET.SubElement(child_inner, "ferrumDpStateContext")
            labeled_lhss = first_child(parent_step, "innermostLhss")
            if labeled_lhss is not None and list(labeled_lhss):
                context.append(deepcopy(labeled_lhss))
            else:
                ET.SubElement(context, "noInnermostLhss")
            graph_rules = deepcopy(labeled_trs)
            graph_rules.tag = "graphRules"
            context.append(graph_rules)
        return child, None

    if child_name == "dpProof" and parent_name == "uncurryProc":
        transformed_dps = first_child(parent_step, "dps")
        transformed_trs = first_child(parent_step, "trs")
        if transformed_dps is None or transformed_trs is None:
            return None, "uncurryProc_missing_payload"
        return input_wrapper(
            dp_input_like(
                current_input,
                dps_elem=transformed_dps,
                trs_elem=transformed_trs,
            )
        ), None

    if child_name == "dpProof" and parent_name in {"redPairProc", "subtermProc"}:
        removed = first_child(parent_step, "dps")
        current_dps = first_child(current_inner, "dps")
        if removed is None or current_dps is None:
            return None, f"{parent_name}_missing_dps"
        residual_dps = subtract_dps(current_dps, removed)
        if parent_name == "redPairProc":
            # Ferrum carries the reduction pair's active R into the residual
            # state explicitly.  A plain redPairProc checks the current active
            # rules, or the full TRS when that context was implicit.
            active_rules = first_child(current_inner, "usableRules")
            if active_rules is None:
                active_rules = first_child(current_inner, "trs")
            if active_rules is None:
                return None, "redPairProc_missing_active_rules"
            return ordinary_dp_child_below_red_pair(
                current_input,
                residual_dps,
                active_rules,
            ), None
        return input_wrapper(
            dp_input_like(current_input, dps_elem=residual_dps)
        ), None

    if child_name == "dpProof" and parent_name in {
        "redPairUrProc",
        "csrRedPairUrProc",
    }:
        removed = first_child(parent_step, "dps")
        usable = first_child(parent_step, "usableRules")
        current_dps = first_child(current_inner, "dps")
        if removed is None or usable is None or current_dps is None:
            return None, f"{parent_name}_missing_payload"
        # A non-monotonic usable-rule reduction pair deletes pairs only.
        # Its U(P,R) witness is an orientation obligation, not the recursive
        # rule component: CeTA's generic_ur_af_redtriple_proc concludes with
        # delete_pairs dpp Premove.  Preserve the incoming R verbatim.
        return input_wrapper(
            dp_input_like(current_input, dps_elem=subtract_dps(current_dps, removed))
        ), None

    if child_name == "dpProof" and parent_name in {
        "monoRedPairProc",
        "monoRedPairUrProc",
        "innermostMonoRedPairProc",
    }:
        removed = first_child(parent_step, "dps")
        strict_trs = first_child(parent_step, "trs")
        current_dps = first_child(current_inner, "dps")
        if removed is None or strict_trs is None or current_dps is None:
            return None, f"{parent_name}_missing_payload"
        # CPF's <trs> child is the set of strictly deleted rules.  Even for
        # monoRedPairUrProc, U(P,R) is used to check orientation; CeTA deletes
        # every non-usable rule plus the explicitly strict usable rules from
        # the recursive problem.  This is exactly U \\ strict, whereas the
        # non-monotonic Ur processor above retains R.
        current_rules = first_child(current_inner, "usableRules")
        if current_rules is None:
            current_rules = first_child(current_inner, "trs")
        if current_rules is None:
            return None, f"{parent_name}_missing_active_rules"
        if parent_name == "monoRedPairUrProc":
            usable = first_child(parent_step, "usableRules")
            if usable is None:
                return None, f"{parent_name}_missing_usable_rules"
            residual_rules = subtract_alpha_equivalent_rules(usable, strict_trs)
        else:
            residual_rules = subtract_alpha_equivalent_rules(current_rules, strict_trs)
        child = dp_input_after_monotone_rule_removal(
            current_input,
            subtract_dps(current_dps, removed),
            residual_rules,
        )
        child_inner = inner_input(child) if child is not None else None
        if child_inner is None:
            return None, f"{parent_name}_invalid_residual"
        # The <trs> payload discharges strict ordinary rules as well as
        # deleting them from active R.  Preserve the generalized state, but
        # remove precisely those strict obligations from its private context.
        current_context = first_child(current_inner, "ferrumDpStateContext")
        current_strict = (
            first_child(current_context, "strictRules")
            if current_context is not None
            else None
        )
        if current_strict is not None:
            residual_strict = subtract_alpha_equivalent_rules(current_strict, strict_trs)
            set_strict_rule_context(child_inner, residual_strict)
        return child, None

    if child_name == "trsTerminationProof" and parent_name == "ruleRemoval":
        removed = first_child(parent_step, "trs")
        current_trs = first_child(current_inner, "trs")
        if removed is None or current_trs is None:
            return None, "ruleRemoval_missing_payload"
        # CPF ruleRemoval records the strictly oriented rules that are
        # deleted.  The recursive proof checks R \\ removed.  Treating the
        # payload itself as the child (the historical behavior) inverted the
        # transition and made every later oracle state context-losing.
        if first_child(current_inner, "relativeRules") is not None:
            residual = relative_input_after_rule_removal(current_input, removed)
            return (
                (residual, None)
                if residual is not None
                else (None, "ruleRemoval_invalid_relative_residual")
            )
        residual = subtract_alpha_equivalent_rules(current_trs, removed)
        return input_wrapper(trs_input_like(current_input, residual)), None

    if child_name == "csrTerminationProof" and parent_name == "csrRuleRemoval":
        removed = first_child(parent_step, "trs")
        current_trs = first_child(current_inner, "trs")
        if removed is None or current_trs is None:
            return None, "csrRuleRemoval_missing_trs"
        residual = subtract_trs(current_trs, removed)
        return input_wrapper(trs_input_like(current_input, residual)), None

    if child_name == "csrTerminationProof" and parent_name == "csrInnermost":
        return deepcopy(current_input), None

    if child_name == "trsTerminationProof" and parent_name == "removeNonApplicableRules":
        removed = first_child(parent_step, "trs")
        current_trs = first_child(current_inner, "trs")
        if removed is None or current_trs is None:
            return None, "removeNonApplicableRules_missing_trs"
        return input_wrapper(trs_input_like(current_input, subtract_trs(current_trs, removed))), None

    if child_name == "trsTerminationProof" and parent_name == "stringReversal":
        reversed_input = reversed_string_trs_input(current_input)
        if reversed_input is None:
            return None, "stringReversal_invalid_input"
        return full_input(input_wrapper(reversed_input)), None

    if child_name in {"trsTerminationProof", "trsNonterminationProof"} and parent_name in {
        "constantToUnary",
        "uncurry",
    }:
        residual = first_child(parent_step, "trs")
        if residual is None:
            return None, f"{parent_name}_missing_trs"
        return input_wrapper(trs_input_like(current_input, residual)), None

    if child_name == "trsTerminationProof" and parent_name == "relativeBounds":
        removed = first_child(parent_step, "trs")
        current_trs = first_child(current_inner, "trs")
        if removed is None or current_trs is None:
            return None, "relativeBounds_missing_trs"
        residual = relative_input_after_bounds(current_input, removed)
        return (
            (residual, None)
            if residual is not None
            else (None, "relativeBounds_invalid_relative_residual")
        )

    if child_name == "trsTerminationProof" and parent_name == "switchToTRS":
        child = relative_input_after_dp_switch(current_input)
        return (
            (child, None)
            if child is not None
            else (None, "switchToTRS_invalid_dp_input")
        )

    if child_name == "trsTerminationProof" and parent_name in {
        "switchInnermost",
        "aaeccInnermost",
    }:
        return innermost_input(current_input), None

    if child_name == "trsNonterminationProof" and parent_name == "switchFullStrategy":
        return full_input(current_input), None

    if child_name == "trsNonterminationProof" and parent_name == "innermostLhssIncrease":
        lhss = first_child(parent_step, "innermostLhss")
        if lhss is None:
            return None, "innermostLhssIncrease_missing_lhss"
        updated = deepcopy(current_input)
        current = inner_input(updated)
        if current is None:
            return None, "innermostLhssIncrease_invalid_input"
        strategy = first_child(current, "strategy")
        if strategy is None:
            strategy = ET.SubElement(current, "strategy")
        for child in list(strategy):
            if local_name(child.tag) == "innermostLhss":
                strategy.remove(child)
        strategy.append(deepcopy(lhss))
        return updated, None

    if child_name == "trsNonterminationProof" and parent_name == "ruleRemoval":
        removed = first_child(parent_step, "trs")
        current_trs = first_child(current_inner, "trs")
        if removed is None or current_trs is None:
            return None, "ruleRemoval_nontermination_missing_payload"
        residual = subtract_trs(current_trs, removed)
        return input_wrapper(trs_input_like(current_input, residual)), None

    if child_name == "trsNonterminationProof" and parent_name == "ignoreRelativePart":
        return strict_part_input(current_input), None

    if child_name == "trsTerminationProof" and parent_name == "flatContextClosure":
        transformed = first_child(parent_step, "trs")
        if transformed is None:
            return None, "flatContextClosure_missing_trs"
        child = flat_context_relative_input(current_input, transformed)
        return (
            (child, None)
            if child is not None
            else (None, "flatContextClosure_invalid_transformed_trs")
        )

    if child_name == "trsTerminationProof" and parent_name == "semlab":
        transformed = first_child(parent_step, "trs")
        if transformed is None:
            return None, "semlab_missing_trs"
        child = semantic_labeled_relative_input(current_input, transformed)
        return (
            (child, None)
            if child is not None
            else (None, "semlab_invalid_transformed_trs")
        )

    if child_name == "trsTerminationProof" and parent_name in {"equalityRemoval", "split"}:
        return deepcopy(current_input), None

    if child_name == "dpNonterminationProof" and parent_name == "innermostLhssIncreaseProc":
        added = first_child(parent_step, "innermostLhss")
        if added is None:
            return None, "innermostLhssIncreaseProc_missing_lhss"
        context = first_child(current_inner, "ferrumDpStateContext")
        strategy = first_child(current_inner, "strategy")
        current_q = first_child(context, "innermostLhss") if context is not None else None
        if current_q is None and strategy is not None:
            current_q = first_child(strategy, "innermostLhss")
        union = deepcopy(current_q) if current_q is not None else ET.Element("innermostLhss")
        for term in added:
            if not any(xml_text(term).strip() == xml_text(old).strip() for old in union):
                union.append(deepcopy(term))
        child = dp_input_with_innermost_lhss(current_input, union)
        inner = inner_input(child) if child is not None else None
        if inner is None:
            return None, "innermostLhssIncreaseProc_invalid_input"
        minimal = first_child(inner, "minimal")
        if minimal is None:
            minimal = ET.SubElement(inner, "minimal")
        minimal.text = "false"
        weak = first_child(inner, "ferrumWeakDps")
        pairs = inner.find("dps/rules")
        if weak is not None:
            if pairs is None:
                return None, "innermostLhssIncreaseProc_missing_pairs"
            for rule in weak.findall("rules/rule"):
                pairs.append(deepcopy(rule))
            inner.remove(weak)
        child_context = first_child(inner, "ferrumDpStateContext")
        strict = first_child(child_context, "strictRules") if child_context is not None else None
        if strict is not None:
            rules = inner.find("trs/rules")
            if rules is None:
                return None, "innermostLhssIncreaseProc_missing_rules"
            for rule in strict.findall("rules/rule"):
                rules.append(deepcopy(rule))
            child_context.remove(strict)
        return child, None

    if child_name in {"dpProof", "dpNonterminationProof"} and parent_name == "innermostLhssRemovalProc":
        lhss = first_child(parent_step, "innermostLhss")
        if lhss is None:
            return None, "innermostLhssRemovalProc_missing_lhss"
        child = dp_input_with_innermost_lhss(current_input, lhss)
        if child is not None and child_name == 'dpNonterminationProof':
            inner = inner_input(child)
            minimal = first_child(inner, 'minimal')
            if minimal is None:
                minimal = ET.SubElement(inner, 'minimal')
            minimal.text = 'false'
        return (
            (child, None)
            if child is not None
            else (None, "innermostLhssRemovalProc_invalid_input")
        )

    if child_name == "dpProof" and parent_name == "switchInnermostProc":
        active = first_child(current_inner, "usableRules")
        if active is None:
            active = first_child(current_inner, "trs")
        pairs = first_child(current_inner, "dps")
        if active is None or pairs is None:
            return None, "switchInnermostProc_missing_state"
        active = deepcopy(active)
        active.tag = "trs"
        switched = dp_input_like(current_input, dps_elem=pairs, trs_elem=active)
        if switched is None:
            return None, "switchInnermostProc_invalid_state"
        for existing in list(switched):
            if local_name(existing.tag) in {"strategy", "usableRules"}:
                switched.remove(existing)
        strategy = ET.SubElement(switched, "strategy")
        ET.SubElement(ET.SubElement(strategy, "innermost"), "nfs").text = "true"
        context = first_child(switched, "ferrumDpStateContext")
        if context is None:
            context = ET.SubElement(switched, "ferrumDpStateContext")
        for existing in list(context):
            if local_name(existing.tag) in {"rewriteStrategy", "innermostLhss",
                    "noInnermostLhss", "graphRules", "transformationRules"}:
                context.remove(existing)
        ET.SubElement(context, "rewriteStrategy").text = "innermost"
        transformation = deepcopy(active)
        transformation.tag = "transformationRules"
        context.append(transformation)
        # Implicit Q is exactly the LHS set of this active R, as in the
        # native switch processor. This is not an identity transformation.
        return input_wrapper(switched), None

    if child_name == "trsTerminationProof" and parent_name == "qdpToSrs":
        child = qdp_to_srs_child(current_input)
        return (
            (child, None)
            if child is not None
            else (None, "qdpToSrs_invalid_input")
        )

    replacement_tag = {
        "forwardInstantiationProc": "instantiations",
        "instantiationProc": "instantiations",
        "narrowingProc": "narrowings",
    }.get(parent_name)
    if child_name in {"dpProof", "dpNonterminationProof"} and replacement_tag is not None:
        selected = first_child(parent_step, "rule")
        replacements = first_child(parent_step, replacement_tag)
        if selected is None or replacements is None:
            return None, f"{parent_name}_missing_payload"
        replaced = replaced_dp_input(current_input, selected, replacements)
        if replaced is None:
            return None, f"{parent_name}_invalid_payload"
        # The optional ``usableRules`` inside instantiation/narrowing is the
        # local witness that validates the transformation.  It is not the R
        # component of the residual DP problem.  Replacing active R by this
        # witness loses the parent's independently certified rule context.
        return replaced, None

    if child_name in {"dpProof", "dpNonterminationProof"} and parent_name == "rewritingProc":
        rules = [child for child in list(parent_step) if local_name(child.tag) == "rule"]
        if len(rules) != 2:
            return None, "rewritingProc_missing_rules"
        replacements = ET.Element("rewritings")
        replacement_rules = ET.SubElement(replacements, "rules")
        replacement_rules.append(deepcopy(rules[1]))
        replaced = replaced_dp_input(current_input, rules[0], replacements)
        if replaced is None:
            return None, "rewritingProc_invalid_payload"
        # As above, rewritingProc/usableRules certifies the rewrite step; it
        # does not replace the residual rule obligation.  DP rewriting changes
        # P and preserves the active R/Q context.
        return replaced, None

    return None, f"unsupported_transition:{parent_name}->{child_name}"


def iter_child_proofs(step: ET.Element) -> Iterable[ET.Element]:
    for child in list(step):
        name = local_name(child.tag)
        if name in {
            "trsTerminationProof",
            "trsNonterminationProof",
            "dpProof",
            "dpNonterminationProof",
            "relativeNonterminationProof",
            "csrTerminationProof",
            "csrDpProof",
            "mutermTypedDpProof",
        }:
            yield child
        elif name == "component":
            proof = proof_child(child, "dpProof")
            if proof is None:
                proof = proof_child(child, "csrDpProof")
            if proof is None:
                proof = proof_child(child, "mutermTypedDpProof")
            if proof is not None:
                yield proof
        elif name == "ordinaryDpProof":
            proof = proof_child(child, "dpProof")
            if proof is not None:
                yield proof


def normalize_root(root: ET.Element) -> ET.Element:
    root = deepcopy(root)
    version = first_child(root, "cpfVersion")
    version_text = "".join(version.itertext()).strip() if version is not None else ""
    legacy_retained_dp_no_subproblem = version_text.startswith("2.")
    normalize_cpf2_terms(root)
    if legacy_retained_dp_no_subproblem:
        for element in root.iter():
            if local_name(element.tag) == "dpRuleRemoval":
                element.set("ferrumLegacyRetainedSubproblem", "true")
    lookup_tables = first_child(root, "lookupTables")
    rule_table = first_child(lookup_tables, "ruleTable") if lookup_tables is not None else None
    indexed_rules: dict[str, ET.Element] = {}
    if rule_table is not None:
        for entry in list(rule_table):
            if local_name(entry.tag) != "indexToRule":
                continue
            index = first_child(entry, "index")
            rule = first_child(entry, "rule")
            key = " ".join((index.text or "").split()) if index is not None else ""
            if key and rule is not None:
                indexed_rules[key] = deepcopy(rule)

    def expand(parent: ET.Element) -> None:
        for position, child in enumerate(list(parent)):
            if local_name(child.tag) == "ruleIndex":
                key = " ".join((child.text or "").split())
                rule = indexed_rules.get(key)
                if rule is not None:
                    parent.remove(child)
                    parent.insert(position, deepcopy(rule))
                continue
            # Keep the lookup table itself compact; every executable input and
            # proof payload outside it is expanded to a self-contained rule.
            if local_name(child.tag) != "lookupTables":
                expand(child)

    expand(root)
    return root


def iter_exact_rows(source_row: dict[str, Any], root: ET.Element) -> tuple[list[dict[str, Any]], dict[str, int]]:
    root = normalize_root(root)
    parents = parent_map(root)
    global_input = first_child(root, "input")
    lookup_tables = first_child(root, "lookupTables")
    proof = first_child(root, "proof")
    metadata = first_child(root, "metadata")
    answer = result_answer(str(source_row.get("result") or ""))
    if global_input is None or proof is None or answer not in {"yes", "no"}:
        return [], {"unsupported_root": 1}

    rows: list[dict[str, Any]] = []
    counts: dict[str, int] = {}
    # Element instances are hashable by identity.  Keep them as the keys (and
    # therefore alive) for the duration of this proof: caching only ``id``
    # values would permit CPython to reuse an id after a temporary child input
    # is collected and could return another state's XML.
    serialized_xml: dict[ET.Element, str] = {}

    def cached_xml_text(element: ET.Element) -> str:
        cached = serialized_xml.get(element)
        if cached is None:
            cached = xml_text(element)
            serialized_xml[element] = cached
        return cached

    def add_count(key: str) -> None:
        counts[key] = counts.get(key, 0) + 1

    def emit(
        step: ET.Element,
        current_input: ET.Element,
        causal_parent_step: ET.Element | None = None,
        causal_parent_input: ET.Element | None = None,
        causal_parent_branch_index: int | None = None,
    ) -> None:
        tag = local_name(step.tag)
        if tag not in EXACT_TRS_PROOF_STEP_TAGS and tag not in EXACT_DP_PROOF_STEP_TAGS:
            return
        parent = parents.get(id(step))
        context = local_context(parent, step)
        if context is None:
            add_count("missing_context")
            return
        output = cached_xml_text(step)
        current_input_xml = cached_xml_text(current_input)
        row_id_material = f"{source_row['proof_url']}\0{source_row.get('normalizer') or ''}\0exact\0{current_input_xml}\0{output}".encode()
        causal_parent_row_id = None
        if causal_parent_step is not None and causal_parent_input is not None:
            causal_material = (
                f"{source_row['proof_url']}\0{source_row.get('normalizer') or ''}"
                f"\0exact\0{cached_xml_text(causal_parent_input)}"
                f"\0{cached_xml_text(causal_parent_step)}"
            ).encode()
            causal_parent_row_id = hashlib.sha256(causal_material).hexdigest()
        rows.append(
            {
                "id": hashlib.sha256(row_id_material).hexdigest(),
                "source": {
                    "kind": source_row["source_kind"],
                    "proof_url": source_row["proof_url"],
                    "xml_path": source_row["xml_path"],
                    "xml_format": source_row["xml_format"],
                    "normalizer": source_row.get("normalizer"),
                    "exact_obligation_extractor": "v1",
                },
                "metadata": {
                    "year": source_row["year"],
                    "category": source_row["category"],
                    "benchmark": source_row["benchmark"],
                    "tool": source_row["tool"],
                    "result": source_row["result"],
                    "certification": source_row["certification"],
                    "processor_tag": tag,
                    "path": path_to(root, step, parents),
                    "normalized_tool": child_text(metadata, "tool") if metadata is not None else None,
                    "local_obligation": True,
                    "causal_parent_processor_tag": (
                        local_name(causal_parent_step.tag)
                        if causal_parent_step is not None
                        else None
                    ),
                    "causal_parent_row_id": causal_parent_row_id,
                    "causal_parent_branch_index": causal_parent_branch_index,
                    "causal_parent_output_xml": (
                        cached_xml_text(causal_parent_step)
                        if causal_parent_step is not None
                        else None
                    ),
                    "causal_parent_input_xml": (
                        cached_xml_text(causal_parent_input)
                        if causal_parent_input is not None
                        else None
                    ),
                    "causal_parent_local_context_xml": (
                        local_context(
                            parents.get(id(causal_parent_step)),
                            causal_parent_step,
                        )
                        if causal_parent_step is not None
                        else None
                    ),
                    "causal_parent_lookup_tables_xml": (
                        cached_xml_text(lookup_tables)
                        if causal_parent_step is not None
                        and lookup_tables is not None
                        else None
                    ),
                },
                "input": {
                    "problem_xml": current_input_xml,
                    "local_context_xml": context,
                    "lookup_tables_xml": cached_xml_text(lookup_tables) if lookup_tables is not None else None,
                },
                "output_xml": output,
                "cpf_normalization": {
                    "input_status": "cpf-input-preserved",
                    "output_status": "cpf-output-preserved",
                },
            }
        )

    def walk_step(
        step: ET.Element,
        current_input: ET.Element,
        causal_parent_step: ET.Element | None = None,
        causal_parent_input: ET.Element | None = None,
        causal_parent_branch_index: int | None = None,
    ) -> None:
        emit(
            step,
            current_input,
            causal_parent_step,
            causal_parent_input,
            causal_parent_branch_index,
        )
        if local_name(step.tag) == "csrGmTransformation":
            runtime_input_xml = source_row.get("csr_gm_runtime_trs_input")
            materialize = source_row.get("materialize_child_input")
            if callable(materialize):
                runtime_input_xml = materialize("csr-gm-transform", cached_xml_text(current_input))
            child = proof_child(step, "trsTerminationProof")
            if not isinstance(runtime_input_xml, str) or child is None:
                add_count("csrGmTransformation_missing_runtime_input")
            else:
                try:
                    runtime_input = ET.fromstring(runtime_input_xml)
                except ET.ParseError:
                    add_count("csrGmTransformation_invalid_runtime_input")
                else:
                    walk_proof(child, runtime_input, step, current_input, 0)
            return
        if local_name(step.tag) == "gm04CompleteFullTransformation":
            # The full inverse has two independent obligations, ordered like
            # the native processor: source CSR, then all non-top TRS rules.
            source = proof_child(step, "sourceProof")
            source_step = next(iter(source), None) if source is not None else None
            source_input = gm04_source_csr_input(step)
            if source_step is None or source_input is None:
                add_count("gm04CompleteFullTransformation_missing_source_proof")
            else:
                walk_step(source_step, source_input, step, current_input, 0)
            administrative = proof_child(step, "administrativeProof")
            administrative_step = next(iter(administrative), None) if administrative is not None else None
            top = step.find("topSymbol/name")
            trs = current_input.find("trsInput/trs")
            if administrative_step is None or top is None or not top.text or trs is None:
                add_count("gm04CompleteFullTransformation_missing_administrative_proof")
            else:
                residual = deepcopy(trs)
                rules = first_child(residual, "rules")
                if rules is None:
                    add_count("gm04CompleteFullTransformation_missing_rules")
                else:
                    for rule in list(rules):
                        lhs = next(iter(rule), None)
                        name = first_child(lhs, "name") if lhs is not None else None
                        if name is not None and name.text == top.text:
                            rules.remove(rule)
                    inner = trs_input_like(current_input, residual)
                    if inner is not None:
                        walk_step(administrative_step, input_wrapper(inner), step, current_input, 1)
            return
        if local_name(step.tag) == "gm04CompleteNonterminationTransformation":
            source = proof_child(step, "sourceProof")
            source_step = next(iter(source), None) if source is not None else None
            source_input = gm04_source_csr_input(step)
            if source_step is None or source_input is None:
                add_count("gm04CompleteNonterminationTransformation_missing_source_proof")
            else:
                walk_step(source_step, source_input, step, current_input)
            return
        if local_name(step.tag) == "gm04CompleteTransformation":
            transformed = proof_child(step, "transformedProof")
            source = proof_child(step, "sourceProof")
            transformed_step = next(iter(transformed), None) if transformed is not None else None
            source_step = next(iter(source), None) if source is not None else None
            if transformed_step is None:
                add_count("gm04CompleteTransformation_missing_transformed_proof")
            elif local_name(transformed_step.tag) == "dpTrans":
                # This dpTrans is presentation syntax for GM04's already
                # materialized DP residual.  It is not an independently sound
                # processor at the enclosing TRS root: its final two-pair
                # closure may use the private GM04 residual assumption.  Skip
                # the wrapper and index the nested DP chain at the typed DP
                # child instead.  Runtime alias attachment binds that child to
                # the exact state (including its private GM04 context).
                dps = first_child(transformed_step, "dps")
                dp_proof = proof_child(transformed_step, "dpProof")
                dp_inner = (
                    dp_input_like(current_input, dps_elem=dps)
                    if dps is not None
                    else None
                )
                if dp_proof is None or dp_inner is None:
                    add_count("gm04CompleteTransformation_invalid_transformed_dp")
                else:
                    walk_proof(
                        dp_proof,
                        input_wrapper(dp_inner),
                        step,
                        current_input,
                    )
            else:
                # The enclosing input is precisely the generated GM04 TRS.
                walk_step(transformed_step, deepcopy(current_input), step, current_input)
            source_input = gm04_source_csr_input(step)
            if source_step is None or source_input is None:
                add_count("gm04CompleteTransformation_missing_source_proof")
            else:
                walk_step(source_step, source_input, step, current_input)
            return
        for branch_index, child_proof in enumerate(iter_child_proofs(step)):
            structural_parent = parents.get(id(child_proof))
            transition_parent = (
                structural_parent
                if structural_parent is not None
                and local_name(structural_parent.tag)
                in {"component", "ordinaryDpProof"}
                else step
            )
            child_input, reason = child_input_for(
                transition_parent, child_proof, current_input
            )
            if child_input is None:
                add_count(reason or "cannot_build_child_input")
                continue
            walk_proof(
                child_proof,
                child_input,
                # `transition_parent` is needed only to materialize the
                # component-specific child input.  The executable causal
                # processor is still `step` (for example depGraphProc), and
                # `branch_index` identifies its residual.  Recording the
                # non-processor <component> here erases that distinction and
                # lets sibling SCC continuations alias one another.
                step,
                current_input,
                branch_index,
            )

    def walk_proof(
        proof_elem: ET.Element,
        current_input: ET.Element,
        causal_parent_step: ET.Element | None = None,
        causal_parent_input: ET.Element | None = None,
        causal_parent_branch_index: int | None = None,
    ) -> None:
        step = unwrap_proof_step(proof_elem)
        if step is None:
            add_count(f"terminal_or_unknown:{local_name(proof_elem.tag)}")
            return
        walk_step(
            step,
            current_input,
            causal_parent_step,
            causal_parent_input,
            causal_parent_branch_index,
        )

    def walk_guarded_step(step: ET.Element, current_input: ET.Element) -> None:
        """Walk the recursive guarded CSR extension without erasing states.

        The production checker deliberately uses a compact proof grammar: its
        recursive children are processor nodes rather than the ordinary CPF
        ``*Proof`` wrappers.  Treating the top-level wrapper as unsupported
        used to discard every exact row and leave only weak root-local hints.
        Reconstruct the same CSR and DP obligations as the checked processor
        so each continuation remains independently addressable.
        """
        tag = local_name(step.tag)
        emit(step, current_input)
        current_inner = inner_input(current_input)
        if current_inner is None:
            add_count("csr_guarded_invalid_input")
            return
        if tag == "csrGuardedRuleRemoval":
            removed = first_child(step, "trs")
            current_trs = first_child(current_inner, "trs")
            child = next(
                (
                    node
                    for node in list(step)
                    if local_name(node.tag)
                    in {
                        "csrGuardedImprovedDependencyPairs",
                        "csrGuardedDependencyPairs",
                    }
                ),
                None,
            )
            if removed is None or current_trs is None or child is None:
                add_count("csrGuardedRuleRemoval_missing_payload")
                return
            residual = input_wrapper(
                trs_input_like(current_input, subtract_trs(current_trs, removed))
            )
            walk_guarded_step(child, residual)
            return
        if tag in {
            "csrGuardedImprovedDependencyPairs",
            "csrGuardedDependencyPairs",
        }:
            dps = first_child(step, "dps")
            child = next(
                (
                    node
                    for node in list(step)
                    if local_name(node.tag) == "csrGuardedDepGraphProc"
                ),
                None,
            )
            if dps is None or child is None:
                add_count(f"{tag}_missing_payload")
                return
            construction = (
                "improved"
                if tag == "csrGuardedImprovedDependencyPairs"
                else "native"
            )
            child_dp = dp_input_like(current_input, dps_elem=dps)
            if child_dp is None:
                add_count(f"{tag}_invalid_dp_input")
                return
            walk_guarded_step(
                child, add_csr_dp_context(input_wrapper(child_dp), construction)
            )
            return
        if tag == "csrGuardedDepGraphProc":
            for component in (
                node for node in list(step) if local_name(node.tag) == "component"
            ):
                dps = first_child(component, "dps")
                if dps is None:
                    add_count("csrGuardedDepGraphProc_component_missing_dps")
                    continue
                component_input = input_wrapper(
                    dp_input_like(current_input, dps_elem=dps)
                )
                existing = first_child(component, "csrGuardedExistingDpProof")
                child_proof = (
                    proof_child(existing, "csrDpProof")
                    if existing is not None
                    else None
                )
                if child_proof is not None:
                    walk_proof(child_proof, component_input)
                # A component without a recursive proof is either acyclic or
                # discharged by a checked guarded terminal.  Both are wholly
                # represented by the parent graph processor and create no
                # open residual state.
            return
        add_count(f"unsupported_guarded_step:{tag}")

    for top in list(proof):
        if local_name(top.tag) == "relativeDpProof":
            standalone = first_child(global_input, "relativeDpInput")
            continuation = proof_child(top, "dpProof")
            if standalone is None or continuation is None:
                add_count("relativeDpProof_missing_typed_input_or_proof")
                continue
            materialized = deepcopy(standalone)
            materialized.tag = "dpInput"
            # CPF partitions P/Pw and R/Rw. The runtime representation
            # keeps their unions plus explicit weak-pair/strict-rule roles.
            for weak_tag, all_tag in (("weakDps", "dps"), ("strictRules", "trs")):
                subset = first_child(materialized, weak_tag)
                universe = first_child(materialized, all_tag)
                if subset is not None and universe is not None:
                    rules = first_child(universe, "rules")
                    if rules is None:
                        rules = ET.SubElement(universe, "rules")
                    subset_rules = first_child(subset, "rules")
                    if subset_rules is not None:
                        rules.extend(deepcopy(list(subset_rules)))
                    if weak_tag == "weakDps":
                        subset.tag = "ferrumWeakDps"
                    else:
                        set_strict_rule_context(materialized, subset)
                        materialized.remove(subset)
            walk_proof(continuation, input_wrapper(materialized))
        elif local_name(top.tag) == "csrImprovedDpProof":
            # Standalone arbitrary improved-CSR DP finiteness, not a fresh
            # dependency-pair transformation. Preserve the complete input
            # (P, R, active R, map, minimality and unhiding symbol) while
            # expressing it in the extractor's materialized DP vocabulary.
            standalone = first_child(global_input, "csrImprovedDpInput")
            continuation = proof_child(top, "csrDpProof")
            if standalone is None or continuation is None:
                add_count("csrImprovedDpProof_missing_typed_input_or_proof")
                continue
            materialized = deepcopy(standalone)
            materialized.tag = "dpInput"
            context = add_csr_dp_context(input_wrapper(materialized), "improved")
            # This is the checked improved-CSR reduction-pair context, not
            # ordinary DP usable rules. No source replacement map is erased.
            first_child(inner_input(context), "ferrumCsrDpContext").find("qcsUsableRules").text = "true"
            walk_proof(continuation, context)
        elif local_name(top.tag) in {
            "trsTerminationProof",
            "trsNonterminationProof",
            "dpProof",
            "dpNonterminationProof",
            "relativeNonterminationProof",
            "csrTerminationProof",
            "csrDpProof",
        }:
            walk_proof(top, global_input)
        elif local_name(top.tag) in {
            "csrDependencyPairs",
            "csrImprovedDependencyPairs",
            "csrSafeDependencyPairs",
            "csrConservativeDependencyPairs",
            "csrMutermTypedDependencyPairs",
        }:
            # The conservative CSR extension permits its root transformation
            # directly below <proof>, without a <csrTerminationProof> wrapper.
            # It is still an exact certified transition from the global input.
            walk_step(top, global_input)
        elif local_name(top.tag) == "csrRuleRemovalThenImproved":
            # This verified extension combines a root CSR rule removal with
            # the improved CSDP transformation.  It is not itself a public
            # one-shot atom, but its exact child QCS-DP state must still enter
            # the recursive oracle registry.
            walk_step(top, global_input)
        elif local_name(top.tag) == "csrGmTransformation":
            # The verified GM checker recomputes the transformed TRS and does
            # not duplicate it in CPF.  A local Ferrum extraction may supply
            # the exact runtime TRS input recovered from the adjacent event
            # trace, allowing the ordinary nested proof to be materialized.
            emit(top, global_input)
            runtime_input_xml = source_row.get("csr_gm_runtime_trs_input")
            child = proof_child(top, "trsTerminationProof")
            if not isinstance(runtime_input_xml, str) or child is None:
                add_count("csrGmTransformation_missing_runtime_input")
            else:
                try:
                    runtime_input = ET.fromstring(runtime_input_xml)
                except ET.ParseError:
                    add_count("csrGmTransformation_invalid_runtime_input")
                else:
                    walk_proof(child, runtime_input)
        elif local_name(top.tag) == "csrGuardedTerminationProof":
            child = next(iter(top), None)
            if child is None:
                add_count("csrGuardedTerminationProof_empty")
            else:
                walk_guarded_step(child, global_input)
        else:
            add_count(f"unsupported_top:{local_name(top.tag)}")

    return rows, counts


def open_output(path: Path):
    path.parent.mkdir(parents=True, exist_ok=True)
    return gzip.open(path, "wt", encoding="utf-8") if path.suffix == ".gz" else path.open("w", encoding="utf-8")


def main() -> int:
    sys.setrecursionlimit(max(sys.getrecursionlimit(), 200_000))
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--out", type=Path, default=Path("target/termcomp-proof-corpus"))
    parser.add_argument("--output", type=Path, default=Path("target/termcomp-proof-corpus/training/subproofs.exact-obligations.jsonl.gz"))
    parser.add_argument("--summary", type=Path, default=Path("target/termcomp-proof-corpus/training/subproofs.exact-obligations.summary.json"))
    parser.add_argument("--source", choices=["original", "normalized", "all"], default="all")
    parser.add_argument("--limit-docs", type=int)
    parser.add_argument("--max-file-bytes", type=int, default=25_000_000)
    parser.add_argument("--min-file-bytes", type=int, default=100)
    parser.add_argument("--progress-interval", type=int, default=1000)
    args = parser.parse_args()

    conn = sqlite3.connect(args.out / "proofs.sqlite")
    docs = source_rows(conn, args.source, args.limit_docs, args.min_file_bytes, progress=True)
    max_file_bytes = None if args.max_file_bytes == 0 else args.max_file_bytes
    totals: dict[str, int] = {
        "docs_total": len(docs),
        "docs_parsed": 0,
        "docs_with_rows": 0,
        "rows_written": 0,
        "skipped_parse": 0,
        "skipped_file_size": 0,
    }
    by_tag: dict[str, int] = {}
    reasons: dict[str, int] = {}
    with open_output(args.output) as sink:
        for idx, source_row in enumerate(docs, start=1):
            path = Path(source_row["xml_path"])
            file_size = path.stat().st_size if path.exists() else None
            if file_size is not None and file_size < args.min_file_bytes:
                totals["skipped_file_size"] += 1
                continue
            if max_file_bytes is not None and file_size is not None and file_size > max_file_bytes:
                totals["skipped_file_size"] += 1
                continue
            root = load_xml(source_row["xml_path"], max_file_bytes)
            if root is None:
                totals["skipped_parse"] += 1
                continue
            totals["docs_parsed"] += 1
            try:
                rows, local_reasons = iter_exact_rows(source_row, root)
            except (ET.ParseError, RecursionError, ValueError) as exc:
                totals["skipped_parse"] += 1
                reasons[f"extract_error:{type(exc).__name__}"] = reasons.get(f"extract_error:{type(exc).__name__}", 0) + 1
                continue
            for key, value in local_reasons.items():
                reasons[key] = reasons.get(key, 0) + value
            if rows:
                totals["docs_with_rows"] += 1
            for row in rows:
                sink.write(json.dumps(row, sort_keys=True, separators=(",", ":")) + "\n")
                totals["rows_written"] += 1
                tag = row["metadata"]["processor_tag"]
                by_tag[tag] = by_tag.get(tag, 0) + 1
            if args.progress_interval > 0 and idx % args.progress_interval == 0:
                print(json.dumps({"event": "progress", "doc": idx, **totals}, sort_keys=True), flush=True)

    summary = {
        **totals,
        "output": str(args.output),
        "by_tag": dict(sorted(by_tag.items(), key=lambda item: (-item[1], item[0]))),
        "reasons": dict(sorted(reasons.items(), key=lambda item: (-item[1], item[0]))),
    }
    args.summary.parent.mkdir(parents=True, exist_ok=True)
    args.summary.write_text(json.dumps(summary, indent=2, sort_keys=True), encoding="utf-8")
    print(json.dumps(summary, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
