#!/usr/bin/env python3
"""Check witness references and absence of complete termination-proof atoms."""
import argparse
import hashlib
import json
from pathlib import Path

p = argparse.ArgumentParser(description=__doc__)
p.add_argument('--oracle', type=Path, required=True)
p.add_argument('--output', type=Path, required=True)
p.add_argument('--exclude-complete-nontermination', action='store_true')
args = p.parse_args()
digest = hashlib.sha256()
witnesses, references, states = set(), set(), set()
complete, complete_no, malformed = [], [], []
with args.oracle.open('rb') as stream:
    for number, line in enumerate(stream, 1):
        digest.update(line)
        row = json.loads(line)
        if row.get('schema') == 'ferrum.utility-guidance.witness.v1':
            witness = row['witness_id']
            if witness in witnesses or hashlib.sha256(row['candidate'].encode()).hexdigest() != witness:
                malformed.append(number)
            witnesses.add(witness)
        if 'problem_key' in row:
            if row['problem_key'] in states:
                malformed.append(number)
            states.add(row['problem_key'])
        for item in [row] + [x for b in ('prefer','possible','avoid','timeout') for x in row.get(b, [])]:
            atom = item.get('candidate', '')
            if 'exact-dp-proof(' in atom or 'exact-trs-proof(' in atom:
                complete.append(number)
            if 'exact-dp-nontermination-proof(' in atom or 'exact-trs-nontermination-proof(' in atom:
                complete_no.append(number)
            if item.get('candidate_ref'):
                references.add(item['candidate_ref'])
report = dict(sha256=digest.hexdigest(), states=len(states), witnesses=len(witnesses),
              unresolved_witness_references=sorted(references-witnesses),
              complete_termination_atom_lines=complete,
              complete_nontermination_atom_lines=complete_no, malformed_lines=malformed)
with args.output.open('x') as stream:
    json.dump(report, stream, indent=2)
print(json.dumps(report))
if complete or malformed or references-witnesses or (args.exclude_complete_nontermination and complete_no):
    raise SystemExit(1)
