"""Export weak native-action hints from a twice-checked local probe.

The complete probe is certified, but explored events are not independently
credited. Root replay must certify before any root recovery is claimed.
"""
import argparse
import copy
from concurrent.futures import ThreadPoolExecutor
import hashlib
import json
from pathlib import Path
import re
import subprocess

from probe_witness_free_oracle import replace
from probe_native_event_frontier import FAMILIES, fit_signature
from add_runtime_canonical_aliases import canonicalize, inline_inputs
from atomic_artifact import atomic_text_output


def attach_canonical_alias(rows, key, canonical_key):
    if canonical_key == key:
        return
    alias = copy.deepcopy(rows[key])
    alias['problem_key'] = canonical_key
    alias.pop('canonical_problem_key', None)
    rows[key]['canonical_problem_key'] = canonical_key
    target = rows.setdefault(canonical_key, alias)
    if target is not alias:
        known = {c['candidate']: c for c in target['possible']}
        for candidate in alias['possible']:
            current = known.get(candidate['candidate'])
            if current is None:
                target['possible'].append(candidate)
            elif 'replay_elapsed_ms' in candidate:
                current['replay_elapsed_ms'] = max(current.get('replay_elapsed_ms', 0), candidate['replay_elapsed_ms'])
        target['replay_order'] = list(dict.fromkeys(target.get('replay_order', []) + alias.get('replay_order', [])))


def search_atoms(text):
    """Read the flat recipe emitted by probe_native_event_frontier, not a pipeline."""
    atoms = []
    for part in text.strip().split(' | '):
        atom = part.strip()
        timed = re.fullmatch(r'timeout\([1-9][0-9]*s, (.*)\)', atom)
        if timed:
            atom = timed[1]
        valid = re.fullmatch(r'[a-z][a-z-]*(?:\([a-z-]+=-?[0-9]+(?:,[a-z-]+=-?[0-9]+)*\))?', atom)
        valid = valid or re.fullmatch(r'path-order\(status=(?:rpo|lpo),optimize=[01]\)', atom)
        valid = valid or re.fullmatch(r'nontermination\(dp-(?:loop|symbolic-loop|backward-loop|fork-loop|fair-loop|nonloop)\)', atom)
        if (not valid
                or atom.split('(', 1)[0] not in FAMILIES | {'graph', 'size-change', 'subterm'}):
            raise ValueError('unsupported native search recipe')
        if atom not in atoms:
            atoms.append(atom)
    return atoms


def collect(events, original_atoms=()):
    events = list(events)
    cpfs = inline_inputs(events)
    rows = {}
    for event in events:
        if event.get('outcome') not in ('solved', 'transformed'):
            continue
        state = event.get('input') or {}
        key = state.get('problem_key', '')
        if not re.fullmatch('[0-9a-f]{64}', key):
            raise ValueError('invalid state key')
        if state.get('cpf') and hashlib.sha256(state['cpf'].strip().encode()).hexdigest() != key:
            raise ValueError('state digest mismatch')
        # New events retain the actual search recipe separately from the
        # resulting proof witness. Older events still need bounds inference.
        candidate = replace(event.get('search_atom') or event.get('strategy_atom')
                            or event.get('processor', ''))
        if not candidate or 'hex=' in candidate or 'exact-' in candidate:
            raise ValueError('unsupported native action conversion')
        # A root DP event may retain the explicit discovery continuation.
        # Export only the DP transformation here: nested events provide the
        # continuation at their own states, never as a root-level pipeline.
        for transformation in ('dp', 'dp-trimmed', 'csr-native-dp', 'csr-improved-dp',
                               'csr-safe-dp', 'csr-native-ordinary-dp',
                               'csr-conservative-dp'):
            if candidate.startswith(transformation + '(') and candidate.endswith(')'):
                candidate = transformation
        if ';' in candidate or '|' in candidate or 'pipeline(' in candidate:
            raise ValueError('unsupported compound native action conversion')
        # A retained interpretation can mention fewer symbols than its live
        # typed state (e.g. inactive original rules still carried in CPF).
        # Model-derived size cutoffs must not make the inferred search atom
        # immediately inapplicable. Keep genuine recorded search bounds
        # unchanged; this only repairs inferred legacy guidance.
        if not event.get('search_atom') and key in cpfs and (
                'max-symbols=' in candidate or 'max-arity=' in candidate):
            candidate = fit_signature(candidate, cpfs[key])
        row = rows.setdefault(key, dict(schema='ferrum.utility-guidance.v2',
            problem_key=key, prefer=[], possible=[], avoid=[], timeout=[]))
        # Tightening bounds to the returned model can change the next model
        # and hence the residual. Preserve the discovery recipe as additional
        # untried state-local hints, never as observed/certified actions. The
        # event does not identify which same-family search produced its model,
        # so do not attribute its timing or success statistics to these hints.
        for original in original_atoms:
            if original.split('(', 1)[0] != candidate.split('(', 1)[0] or original == candidate:
                continue
            if any(item['candidate'] == original for item in row['possible']):
                continue
            row['possible'].append(dict(candidate=original, status='transformed_weak',
                utility_score=1000.0, attempts=0, solved_count=0, transformed_count=0,
                failed_count=0, timeout_count=0, certified_count=0))
        if any(item['candidate'] == candidate for item in row['possible']):
            continue
        row['possible'].append(dict(candidate=candidate, status='transformed_weak',
            utility_score=1000.0, best_elapsed_ms=event.get('elapsed_ms', 0),
            attempts=1, solved_count=0, transformed_count=1, failed_count=0,
            timeout_count=0, certified_count=0))
    return list(rows.values())


def closed_chain_first(events):
    """Prioritize finite recorded closures, without granting proof credit.

    All alternatives survive. A cycle without a recorded terminal cannot
    seed itself, and every child of an AND-branch must have a closure.
    The resulting guidance is still atomic and keyed at each input state.
    """
    costs = {}
    def cost(event):
        if event.get('outcome') == 'solved':
            return 1
        if event.get('outcome') != 'transformed':
            return float('inf')
        children = (event.get('witness') or {}).get('residuals')
        if children is None:
            return float('inf')
        return 1 + sum(costs.get(child.get('problem_key'), float('inf')) for child in children)
    for _ in range(len(events)):
        changed = False
        for event in events:
            key = (event.get('input') or {}).get('problem_key')
            value = cost(event)
            if key and value < costs.get(key, float('inf')):
                costs[key] = value
                changed = True
        if not changed:
            break
    return sorted(events, key=cost)


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--events', type=Path, required=True)
    p.add_argument('--proof', type=Path, required=True)
    p.add_argument('--ceta', type=Path, required=True)
    p.add_argument('--output', type=Path, required=True)
    p.add_argument('--prioritize', action='store_true', help='Order these native actions first without assigning certification credit')
    p.add_argument('--closed-chain-first', action='store_true',
                   help='Prefer actions with short finite recorded continuations; retain all alternatives')
    p.add_argument('--search-strategy', type=Path,
                   help='Retain original flat probe search parameters as additional untried hints')
    p.add_argument('--record-replay-timings', action='store_true',
                   help='Retain native replay measurements separately from historical best times')
    p.add_argument('--canonical-ferrum', type=Path,
                   help='Export context-preserving runtime aliases as well as raw probe-state keys')
    p.add_argument('--canonical-jobs', type=int, default=8)
    p.add_argument('--checker-timeout', type=float, default=120,
                   help='Independent CeTA time allowance in seconds, separate from search')
    args = p.parse_args()
    if not 0 < args.checker_timeout < float('inf'):
        p.error('--checker-timeout must be finite and positive')
    originals = search_atoms(args.search_strategy.read_text()) if args.search_strategy else ()
    events = list(map(json.loads, args.events.read_text().splitlines()))
    if args.closed_chain_first:
        events = closed_chain_first(events)
    rows = collect(events, originals)
    if args.record_replay_timings:
        for row in rows:
            for item in row['possible']:
                if 'best_elapsed_ms' in item:
                    item['replay_elapsed_ms'] = item['best_elapsed_ms']
    if args.prioritize:
        for row in rows:
            row['replay_order'] = [hashlib.sha256(item['candidate'].encode()).hexdigest()
                                   for item in row['possible']]
    canonical_failures = []
    if args.canonical_ferrum:
        cpfs = inline_inputs(events)
        by_key = {row['problem_key']: row for row in rows}
        def convert(key):
            try:
                cpf = canonicalize(args.canonical_ferrum.resolve(), cpfs[key], 15)
                return key, hashlib.sha256(cpf.encode()).hexdigest(), None
            except (RuntimeError, subprocess.TimeoutExpired) as error:
                return key, None, str(error)[:250]
        with ThreadPoolExecutor(max_workers=args.canonical_jobs) as pool:
            for key, canonical_key, error in pool.map(convert, [key for key in by_key if key in cpfs]):
                if error:
                    canonical_failures.append(dict(problem_key=key, error=error))
                else:
                    attach_canonical_alias(by_key, key, canonical_key)
        rows = list(by_key.values())
    checks = []
    for _ in range(2):
        result = subprocess.run([str(args.ceta.resolve()), str(args.proof.resolve())],
                                capture_output=True, text=True, timeout=args.checker_timeout)
        checks.append(dict(returncode=result.returncode, stdout=result.stdout, stderr=result.stderr))
        if result.returncode or 'CERTIFIED' not in result.stdout.splitlines():
            raise ValueError('probe certificate rejected')
    with args.output.with_suffix('.checks.json').open('x') as out:
        json.dump(dict(proof=str(args.proof), checks=checks, canonical_failures=canonical_failures), out)
    with atomic_text_output(args.output, exclusive=True) as out:
        for row in rows:
            print(json.dumps(row), file=out)
    print(json.dumps(dict(states=len(rows), independent_event_certification_credit=0)))


if __name__ == '__main__':
    main()
