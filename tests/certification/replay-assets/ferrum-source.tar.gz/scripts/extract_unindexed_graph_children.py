#!/usr/bin/env python3
"""Retain actual runtime graph children missing from a supplied local oracle."""
import argparse
import hashlib
import json
from pathlib import Path


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--events', type=Path, required=True)
    p.add_argument('--oracle', type=Path, required=True)
    p.add_argument('--output', type=Path, required=True)
    args = p.parse_args()
    args.output.mkdir(parents=True, exist_ok=False)
    known = set()
    for line in args.oracle.open():
        row = json.loads(line)
        if 'problem_key' in row:
            known.add(row['problem_key'])
    retained = {}
    for line in args.events.open():
        row = json.loads(line)
        if row.get('outcome') != 'transformed' or not row.get('strategy_atom', '').startswith('exact-graph'):
            continue
        for child in (row.get('witness') or {}).get('residuals', []):
            key = child['problem_key']
            if key in known or key in retained:
                continue
            cpf = child.get('cpf')
            if not cpf or hashlib.sha256(cpf.strip().encode()).hexdigest() != key:
                raise RuntimeError('Missing or mismatched native child CPF')
            index = len(retained)
            (args.output/f'{index}.cpf').write_text(cpf)
            retained[key] = index
    (args.output/'keys.json').write_text(json.dumps(retained, indent=2))
    print(json.dumps(dict(unindexed_children=len(retained))))


if __name__ == '__main__':
    main()
