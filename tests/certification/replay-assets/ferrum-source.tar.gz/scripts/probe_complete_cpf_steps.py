#!/usr/bin/env python3
"""Materialize every local CPF action directly, without whole-root replay.

This is diagnostic state materialization, not a certification gate. Feed the
events back through the source-proof-checked extractor before oracle export.
Never substitute a recursive complete-proof atom for a missing local action.
"""
import argparse
import hashlib
from concurrent.futures import ThreadPoolExecutor
import json
import os
from pathlib import Path
import subprocess
import sys
import time
import xml.etree.ElementTree as ET

from extract_exact_fragment_training_data import iter_exact_rows
from extract_local_cpf_oracle_events import strategy_atom, materialize_single_cpf_child


def source_identity_signature(cpf):
    """Formatting-only identity check; never run signature-isomorphism search."""
    root = ET.fromstring(cpf)
    if root.tag == 'input' and len(root) == 1:
        root = root[0]
    for node in root.iter():
        if node.text is not None and not node.text.strip():
            node.text = None
        node.tail = None
    return hashlib.sha256(ET.tostring(root)).hexdigest()


def local_action(row):
    atom = strategy_atom(row)
    if atom and atom.startswith(('exact-trs-proof(', 'exact-dp-proof(')):
        return None
    return atom


def recover_rewrite_chain(input_xml, source_atom, target_xml, directory, args, env):
    """Explore a bounded native continuation; every step stays independently keyed."""
    from probe_alpha_dp_merges import pair_signature
    target = pair_signature(target_xml)
    deadline = time.monotonic() + args.timeout
    current = input_xml
    for index in range(4):
        remaining = deadline - time.monotonic()
        if remaining <= 0:
            break
        step = directory/'native-rewrite-chain'/str(index)
        step.mkdir(parents=True)
        (step/'input.cpf').write_text(current)
        with (step/'probe.json').open('x') as out, (step/'probe.log').open('x') as err:
            try:
                proc = subprocess.run([str(args.ferrum), 'probe-cpf', str(step/'input.cpf'),
                    '--strategy', 'rewrite', '--timeout-ms', str(int(remaining * 1000))],
                    env=env, stdout=out, stderr=err, timeout=remaining + 5)
            except subprocess.TimeoutExpired:
                break
        if proc.returncode:
            break
        native = json.loads((step/'probe.json').read_text())
        children = native.get('children', [])
        if native.get('typed_outcome') != 'Transformed' or len(children) != 1:
            break
        event = dict(strategy_atom='rewrite', source_strategy_atom=source_atom,
            outcome='transformed', credit={'status': 'diagnostic-only'},
            input={'cpf': current, 'problem_key': hashlib.sha256(current.strip().encode()).hexdigest()},
            witness={'residuals': children})
        (step/'processor-events.jsonl').write_text(json.dumps(event) + '\n')
        current = children[0]['cpf']
        count, pairs = pair_signature(current)
        if count > len(pairs):
            (step/'before-merge.cpf').write_text(current)
            remaining = deadline - time.monotonic()
            if remaining <= 0:
                break
            try:
                merged = subprocess.run([sys.executable, 'scripts/probe_alpha_dp_merges.py',
                    '--input', str(step/'before-merge.cpf'), '--output', str(step/'alpha-merges'),
                    '--ferrum', str(args.ferrum)], env=env, capture_output=True, timeout=remaining)
            except subprocess.TimeoutExpired:
                break
            if merged.returncode:
                break
            current = (step/'alpha-merges/residual.cpf').read_text()
        if pair_signature(current) == target:
            return [{'cpf': current}]
    return None


def may_probe_unchanged_continuation(outcome, branches):
    return outcome == 'Inapplicable' and branches == {0}


def native_recovery_candidates(processor):
    if processor == 'rewritingProc':
        return ['rewrite']
    family = {'instantiationProc': 'instantiate',
              'forwardInstantiationProc': 'forward-instantiate',
              'narrowingProc': 'narrow'}.get(processor)
    return [f'{family}(candidate={index},max-per-pair=128)' for index in range(16)] if family else []


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--proof', type=Path, required=True)
    p.add_argument('--problem-id', required=True,
                   help='Explicit TPDB identity; never infer identity from probe paths.')
    p.add_argument('--output', type=Path, required=True)
    p.add_argument('--ferrum', type=Path, required=True)
    p.add_argument('--jobs', type=int, default=4)
    p.add_argument('--root-input', type=Path,
                   help='Explore the source actions from an explicit live root CPF; still diagnostic only.')
    p.add_argument('--follow-children', action='store_true',
                   help='Probe a continuation on its native parent child, preserving live contexts.')
    p.add_argument('--normalize-alpha', action='store_true',
                   help='Explore explicit alpha-merge steps before retained local actions.')
    p.add_argument('--timeout', type=float, default=10)
    args = p.parse_args()
    args.output.mkdir(parents=True, exist_ok=False)
    root = ET.parse(args.proof).getroot()
    source = dict(proof_url=str(args.proof), xml_path=str(args.proof),
                  source_kind='direct-cpf-diagnostic', xml_format='4.0',
                  year=2026, category='retained', benchmark=str(args.proof),
                  tool='Ferrum', result='YES', certification='not-rechecked')
    source['materialize_child_input'] = lambda atom, xml: materialize_single_cpf_child(args.ferrum, atom, xml)
    rows, reasons = iter_exact_rows(source, root)
    (args.output / 'extraction-gaps.json').write_text(json.dumps(reasons, indent=2))
    env = dict(os.environ, RAYON_NUM_THREADS='2', FERRUM_DP_LLM_NO_FALLBACK='1')
    native_children = {}
    identity_children = {}
    source_branches = {}
    by_id = {row['id']: row for row in rows}
    for child in rows:
        parent_id = child['metadata'].get('causal_parent_row_id')
        parent = by_id.get(parent_id)
        branch = child['metadata'].get('causal_parent_branch_index')
        if parent and isinstance(branch, int):
            source_branches.setdefault(parent_id, set()).add(branch)
        if parent and isinstance(branch, int):
            signature = source_identity_signature(parent['input']['problem_xml'])
            if signature == source_identity_signature(child['input']['problem_xml']):
                identity_children.setdefault(parent_id, set()).add(branch)

    def probe(item):
        index, row = item
        directory = args.output / str(index)
        directory.mkdir()
        summary = dict(index=index, row_id=row['id'],
                       parent=row['metadata'].get('causal_parent_row_id'),
                       branch=row['metadata'].get('causal_parent_branch_index'),
                       processor=row['metadata']['processor_tag'])
        atom = local_action(row)
        if atom is None:
            return dict(summary, outcome='missing-local-action')
        input_xml = row['input']['problem_xml']
        parent_children = native_children.get(summary['parent'], []) if args.follow_children else []
        branch = summary['branch']
        linked = isinstance(branch, int) and 0 <= branch < len(parent_children)
        if linked:
            input_xml = parent_children[branch]['cpf']
        summary['native_parent_linked'] = linked
        if args.root_input and row['metadata'].get('causal_parent_row_id') is None:
            input_xml = args.root_input.read_text()
            summary['explicit_live_root_input'] = True
        from probe_alpha_dp_merges import pair_signature
        source_count, source_pairs = pair_signature(row['input']['problem_xml'])
        live_count, live_pairs = pair_signature(input_xml)
        exact_duplicate_boundary = (live_count > source_count
            and source_count == len(source_pairs) and live_pairs == source_pairs)
        if summary['processor'] == 'rewritingProc' and atom.startswith('exact-dp-transform('):
            payload = json.loads(bytes.fromhex(atom.split('hex=', 1)[1][:-1]))
            target_count, target_pairs = pair_signature(payload[2])
            # CPF rewrites a member of a set, whereas the runtime may retain
            # alpha-duplicate occurrences. Explicitly merge those first only
            # when the archived target is itself duplicate-free at that size.
            exact_duplicate_boundary |= (live_count > len(live_pairs)
                and target_count == len(live_pairs) == len(target_pairs))
        if args.normalize_alpha or exact_duplicate_boundary:
            from probe_alpha_dp_merges import pair_signature
            pair_count, signature = pair_signature(input_xml)
            if pair_count > len(signature):
                before = directory/'input-before-alpha.cpf'
                before.write_text(input_xml)
                merged = subprocess.run([sys.executable, 'scripts/probe_alpha_dp_merges.py',
                    '--input', str(before), '--output', str(directory/'alpha-merges'),
                    '--ferrum', str(args.ferrum)], capture_output=True, text=True,
                    env=env, timeout=180)
                (directory/'alpha-merges.log').write_text(merged.stdout + merged.stderr)
                if merged.returncode == 0:
                    input_xml = (directory/'alpha-merges/residual.cpf').read_text()
                    summary['explicit_alpha_merge_search'] = input_xml != before.read_text()
        (directory / 'input.cpf').write_text(input_xml)
        (directory / 'atom.fs').write_text(atom)
        with (directory / 'stdout.json').open('x') as out, (directory / 'stderr').open('x') as err:
            try:
                process = subprocess.run([str(args.ferrum), 'probe-cpf',
                    str(directory / 'input.cpf'), '--strategy-file', str(directory / 'atom.fs'),
                    '--timeout-ms', str(int(args.timeout * 1000)), '--processor-events',
                    str(directory / 'processor-events.jsonl')], env=env, stdout=out, stderr=err,
                    timeout=args.timeout + 5)
            except subprocess.TimeoutExpired:
                return dict(summary, outcome='harness-timeout')
        try:
            result = json.loads((directory / 'stdout.json').read_text())
        except ValueError:
            return dict(summary, outcome='invalid-output', returncode=process.returncode)
        source_atom = atom
        recovered_chain_children = None
        native_atoms = native_recovery_candidates(summary['processor'])
        if atom.startswith('exact-usable-rules('):
            native_atoms = ['usable-rules']
        if result.get('typed_outcome') == 'Inapplicable' and native_atoms \
                and atom.startswith(('exact-dp-transform(', 'exact-usable-rules(')):
            # Re-find the native action on the actual residual R/Q rather
            # than weakening an exact witness's source-context checks.
            from probe_alpha_dp_merges import pair_signature
            if atom.startswith('exact-usable-rules('):
                target_pairs = pair_signature(input_xml)
            else:
                payload = json.loads(bytes.fromhex(atom.split('hex=', 1)[1][:-1]))
                target_pairs = pair_signature(payload[2])
            deadline = time.monotonic() + args.timeout
            for attempt, native_atom in enumerate(native_atoms):
                remaining = deadline - time.monotonic()
                if remaining <= 0:
                    break
                probe_path = directory/f'native-recovery-{attempt}.json'
                with probe_path.open('x') as out, (directory/f'native-recovery-{attempt}.log').open('x') as err:
                    try:
                        native_process = subprocess.run([str(args.ferrum), 'probe-cpf',
                            str(directory/'input.cpf'), '--strategy', native_atom,
                            '--timeout-ms', str(max(1, int(remaining * 1000)))],
                            env=env, stdout=out, stderr=err, timeout=remaining + 5)
                    except subprocess.TimeoutExpired:
                        break
                if native_process.returncode:
                    break
                native = json.loads(probe_path.read_text())
                if native.get('typed_outcome') in {'Inapplicable', 'TimedOut'}:
                    break
                children = native.get('children', [])
                if native.get('typed_outcome') == 'Transformed' and len(children) == 1 \
                        and target_pairs == pair_signature(children[0]['cpf']):
                    # Pair equality chooses the search continuation; it does
                    # not claim equality of source and live R/Q contexts.
                    result, process, atom = native, native_process, native_atom
                    summary['native_family_recovery'] = atom
                    (directory/'atom.fs').write_text(atom)
                    break
        if (result.get('typed_outcome') == 'Inapplicable'
                and summary['processor'] == 'rewritingProc'
                and source_atom.startswith('exact-dp-transform(')):
            payload = json.loads(bytes.fromhex(source_atom.split('hex=', 1)[1][:-1]))
            recovered_chain_children = recover_rewrite_chain(
                input_xml, source_atom, payload[2], directory, args, env)
            if recovered_chain_children:
                summary['native_rewrite_chain_recovery'] = True
        native_children[row['id']] = recovered_chain_children or result.get('children', [])
        if result.get('typed_outcome') == 'Inapplicable' and not native_children[row['id']]:
            # A proof can explicitly print a state-identical graph wrapper
            # which native search omits as no progress. Index its continuation
            # on the unchanged input; do NOT claim the wrapper transformed.
            identity_branches = identity_children.get(row['id'], set())
            if identity_branches == {0}:
                native_children[row['id']] = [{'cpf': input_xml}]
                summary['source_identity_passthrough'] = True
            elif may_probe_unchanged_continuation(result.get('typed_outcome'), source_branches.get(row['id'])):
                # A wrapper may be unnecessary in the live representation
                # (for example one SCC or an already reduced usable set).
                # Try its sole continuation on the unchanged *full* state.
                # This is search, not a claimed transformation: it remains
                # Inapplicable and every next action must validate afresh.
                native_children[row['id']] = [{'cpf': input_xml}]
                summary['skipped_inapplicable_action_for_search'] = True
        # Record native inputs/children as diagnostics, not certified positive
        # evidence. The importing extractor must still check the source CPF.
        def state_record(cpf, name):
            path = directory / name
            path.write_text(cpf)
            # Worklist event addresses hash the native serialized CPF. Do
            # not substitute the separately canonicalized lookup alias.
            key = hashlib.sha256(cpf.strip().encode()).hexdigest()
            return dict(cpf=cpf, problem_key=key)
        try:
            event = dict(schema='ferrum.processor-event.v1', problem_id=args.problem_id,
                category=args.problem_id.split('/')[0], processor=atom, strategy_atom=atom,
                source_strategy_atom=source_atom,
                outcome=result['outcome'], input=state_record(input_xml, 'source.cpf'),
                witness=dict(kind='problem_states', residuals=[
                    state_record(child['cpf'], f'child-{i}.cpf')
                    for i, child in enumerate(result.get('children', []))]),
                certification=dict(status='not-checked'),
                credit=dict(status='diagnostic-only'))
            (directory / 'processor-events.jsonl').write_text(json.dumps(event) + '\n')
        except (ValueError, subprocess.TimeoutExpired) as error:
            return dict(summary, outcome='state-key-failure', reason=str(error))
        return dict(summary, outcome=result.get('typed_outcome'),
                    children=len(result.get('children', [])), returncode=process.returncode)

    with ThreadPoolExecutor(max_workers=args.jobs) as pool:
        with (args.output / 'results.jsonl').open('x') as out:
            results = map(probe, enumerate(rows)) if args.follow_children else pool.map(probe, enumerate(rows))
            for result in results:
                print(json.dumps(result), file=out, flush=True)
                print(json.dumps(result), flush=True)


if __name__ == '__main__':
    main()
