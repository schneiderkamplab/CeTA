import tempfile
import json
import unittest
from pathlib import Path

from termcomp_trs_compare import (
    DEFAULT_REPLAY_STATUSES,
    classify_ceta_failure,
    has_arg,
    run_managed_process,
    safe_problem_dir,
    uses_utility_guidance,
    problems_from_previous_details,
)


class TermcompHarnessTests(unittest.TestCase):
    def test_longest_first_preserves_selected_roots_and_stable_ties(self):
        with tempfile.TemporaryDirectory() as raw:
            root = Path(raw)
            rows = []
            for name, elapsed, status in [('a', 1, 'yes'), ('b', 600, 'timeout'),
                                           ('c', 600, 'unknown'), ('d', 1000, 'no')]:
                path = root / (name + '.ari')
                path.touch()
                rows.append(dict(path=str(path), category='TRS_Standard', status=status,
                                 elapsed_seconds=elapsed))
            details = root / 'details.json'
            details.write_text(json.dumps(rows))
            statuses = {'yes', 'timeout', 'unknown'}
            ordinary = problems_from_previous_details(details, 'TRS_Standard', statuses)
            prioritized = problems_from_previous_details(details, 'TRS_Standard', statuses, True)
            self.assertEqual([p.stem for p in ordinary], ['a', 'b', 'c'])
            self.assertEqual([p.stem for p in prioritized], ['b', 'c', 'a'])
            self.assertEqual(set(ordinary), set(prioritized))

    def test_full_replay_default_keeps_previous_timeouts(self) -> None:
        self.assertEqual(DEFAULT_REPLAY_STATUSES,
                         {"yes", "no", "unknown", "timeout", "error"})

    def test_relative_problem_keeps_category_subdirectories(self) -> None:
        with tempfile.TemporaryDirectory() as raw:
            workspace = Path(raw)
            repository = workspace / "ferrum"
            repository.mkdir()
            root = workspace / "TPDB-ARI" / "TRS_Standard"
            root.mkdir(parents=True)
            problem = root / "Secret_06_TRS" / "6.ari"
            problem.parent.mkdir()
            problem.touch()

            relative_problem = (
                Path("..")
                / "TPDB-ARI"
                / "TRS_Standard"
                / "Secret_06_TRS"
                / "6.ari"
            )
            expected = Path("/artifacts/Secret_06_TRS/6")

            old_cwd = Path.cwd()
            try:
                # Match --from-details paths that are relative to the repository.
                import os

                os.chdir(repository)
                self.assertEqual(
                    safe_problem_dir(root, relative_problem, Path("/artifacts")),
                    expected,
                )
            finally:
                os.chdir(old_cwd)

    def test_explicit_utility_manifest_is_guidance(self) -> None:
        self.assertTrue(
            uses_utility_guidance(["--utility-guidance-manifest", "oracle.jsonl"])
        )
        self.assertTrue(
            uses_utility_guidance(["--utility-guidance-manifest=oracle.jsonl"])
        )
        self.assertFalse(uses_utility_guidance(["--strategy", "default"]))

    def test_ceta_failure_classification(self) -> None:
        self.assertEqual(classify_ceta_failure("XML parse error at line 1", ""), "parse")
        self.assertEqual(
            classify_ceta_failure(
                "UNSUPPORTED\nFatal: parse error on <csrTerminationProof> at [proof]",
                "",
            ),
            "unsupported",
        )
        self.assertEqual(
            classify_ceta_failure("Error: does not appear in the dp problem", ""),
            "processor",
        )
        self.assertEqual(
            classify_ceta_failure("", "unsupported proof step"),
            "unsupported",
        )
        self.assertEqual(
            classify_ceta_failure("some deep checker mismatch", ""),
            "checker",
        )

    def test_has_arg(self) -> None:
        self.assertTrue(has_arg(["--no-top-level-llm"], "--no-top-level-llm"))
        self.assertFalse(has_arg(["--strategy", "default"], "--no-top-level-llm"))
        self.assertFalse(has_arg([], "--no-top-level-llm"))
        self.assertTrue(has_arg(["--strategy=timeout(60s,default)"], "--strategy"))

    def test_unlaunchable_process_is_a_local_failure(self) -> None:
        result = run_managed_process(
            ["/definitely/missing/ferrum-campaign-command"], timeout=1
        )
        self.assertEqual(result.returncode, 127)
        self.assertFalse(result.timed_out)
        self.assertIn("failed to launch", result.stderr)


if __name__ == "__main__":
    unittest.main()
