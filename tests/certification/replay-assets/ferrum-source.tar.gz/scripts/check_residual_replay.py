"""Independently check each completed residual proof twice, without modifying results."""
import argparse
from concurrent.futures import ThreadPoolExecutor
import hashlib
import json
from pathlib import Path
import subprocess


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("results", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("--checker", type=Path, default=Path("/work/dfm/festschrift/CeTA-CSR/ceta"))
    args = parser.parse_args()
    checker_hash = digest(args.checker)
    rows = [json.loads(line) for line in args.results.read_text().splitlines()]
    rows = [row for row in rows if "proof" in row]

    def check(row):
        path = Path(row["proof"])
        before = digest(path)
        checks = []
        for _ in range(2):
            try:
                result = subprocess.run([str(args.checker), str(path)], capture_output=True,
                                        text=True, timeout=120)
                checks.append({"exit_code": result.returncode, "stdout": result.stdout,
                               "stderr": result.stderr,
                               "accepted": result.returncode == 0 and
                               "CERTIFIED" in result.stdout.splitlines()})
            except subprocess.TimeoutExpired:
                checks.append({"accepted": False, "timeout": True})
        stable = before == digest(path) and checker_hash == digest(args.checker)
        return {"input": row["input"], "proof": str(path), "sha256": before,
                "checker_sha256": checker_hash, "checks": checks,
                "certified": stable and all(check["accepted"] for check in checks)}

    with args.output.open("x") as output, ThreadPoolExecutor(max_workers=4) as pool:
        for result in pool.map(check, rows):
            output.write(json.dumps(result) + "\n")
            output.flush()


if __name__ == "__main__":
    main()
