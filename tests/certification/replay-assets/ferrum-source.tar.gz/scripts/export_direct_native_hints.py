#!/usr/bin/env python3
"""Index successful direct local probes as weak guidance, never certified results.

Atoms are gated by the same root's twice-checked source proof (directly, or
through its manifest). A mismatched usable-rule witness can supply only a
native family hint. Observed states are not re-associated by heuristic row
matching. A complete reconstructed root must still pass CeTA before promotion.
"""
import argparse
from collections import defaultdict
from concurrent.futures import ThreadPoolExecutor, as_completed
import hashlib
import json
import re
import subprocess
import xml.etree.ElementTree as ET
from pathlib import Path
from build_credited_status_map_dataset import canonicalize_with_ferrum
from export_canonical_modular_aliases import PORTABLE


def source_action_identity(atom):
    """Ignore XML indentation only; retain names, contexts, and witness data."""
    def normalize(value):
        if isinstance(value, list):
            return [normalize(item) for item in value]
        if isinstance(value, dict):
            return {key: normalize(item) for key, item in value.items()}
        if isinstance(value, str) and value.startswith('<'):
            try:
                root = ET.fromstring(value)
            except ET.ParseError:
                return value
            for node in root.iter():
                if node.text is not None and not node.text.strip():
                    node.text = None
                if node.tail is not None and not node.tail.strip():
                    node.tail = None
            return ET.tostring(root, encoding='unicode')
        return value

    def replace(match):
        try:
            payload = json.loads(bytes.fromhex(match.group(1)))
        except (ValueError, UnicodeDecodeError):
            return match.group(0)
        return 'hex=' + json.dumps(normalize(payload), sort_keys=True).encode().hex()
    return re.sub(r'hex=([0-9a-f]+)', replace, atom)


def canonical_candidate(atom):
    # These parameter-free native processors recompute their live transition;
    # unlike positional witnesses, no source index is being transported.
    if atom in {'uncurry', 'switch-innermost', 'dp', 'graph', 'empty', 'rewrite'}:
        return atom
    if atom.startswith(PORTABLE):
        return atom
    # Index-based terminal witnesses are not portable. Offer the independent
    # native checker/search for that processor family as a weak hint instead.
    if atom.startswith('exact-subterm('):
        return 'subterm'
    return None


def same_unbound_redpair_hint(atom, source_atom):
    """A local order proposal, not a transfer of source certification."""
    if not all(a.startswith('exact-red-pair(hex=') for a in (atom, source_atom)):
        return False
    try:
        proposed, source = [json.loads(bytes.fromhex(a.split('hex=')[1][:-1]))
                            for a in (atom, source_atom)]
        return (len(proposed) == 3 and len(source) > 3
                and proposed == source[:3])
    except (ValueError, IndexError, TypeError):
        return False


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--shards', type=Path, required=True)
    p.add_argument('--output', type=Path, required=True)
    p.add_argument('--ferrum', required=True)
    p.add_argument('--jobs', type=int, default=8)
    p.add_argument('--state-jobs', type=int, default=1,
                   help='Bounded parallel canonicalization within a large root.')
    p.add_argument('--baseline', type=Path,
                   help='Derive the action gate directly from twice-rechecked retained CPFs.')
    p.add_argument('--ceta', type=Path)
    p.add_argument('--file-list', type=Path)
    args = p.parse_args()
    if args.baseline and not args.ceta:
        p.error('--baseline requires --ceta')
    tasks = [json.loads(s) for s in (args.shards / 'results.jsonl').read_text().splitlines()
             if json.loads(s)['returncode'] == 0 or args.baseline]
    if args.file_list:
        selected = set(args.file_list.read_text().splitlines())
        tasks = [task for task in tasks if task['path'] in selected]
    sources = {}
    source_audit = {}
    if args.baseline:
        for category in ('standard', 'innermost', 'csr'):
            for row in json.loads((args.baseline/category/'details.json').read_text()):
                sources[row['path'].split('TPDB-ARI/')[-1]] = Path(row['artifact_dir'])/'proof.cpf.xml'

    def collect(task):
        root = Path(task['output'])
        if args.baseline:
            from probe_complete_cpf_steps import local_action
            from extract_exact_fragment_training_data import iter_exact_rows
            from extract_local_cpf_oracle_events import materialize_single_cpf_child
            proof = sources[task['path']]
            digest = hashlib.sha256(proof.read_bytes()).hexdigest()
            check_outputs = []
            for repeat in (1, 2):
                checked = subprocess.run([str(args.ceta), str(proof)], capture_output=True,
                                         text=True, timeout=120)
                if checked.returncode or 'CERTIFIED' not in checked.stdout.splitlines():
                    raise RuntimeError(f'Source recheck {repeat} failed: {proof}')
                check_outputs.append(dict(stdout=checked.stdout, stderr=checked.stderr,
                                          returncode=checked.returncode))
            source = dict(proof_url=str(proof), xml_path=str(proof),
                          source_kind='direct-cpf-diagnostic', xml_format='4.0',
                          year=2026, category='retained', benchmark=str(proof),
                          tool='Ferrum', result='YES', certification='certified')
            source['materialize_child_input'] = lambda atom, xml: materialize_single_cpf_child(args.ferrum, atom, xml)
            rows, _ = iter_exact_rows(source, ET.parse(proof).getroot())
            allowed = {atom for row in rows if (atom := local_action(row)) is not None}
            if hashlib.sha256(proof.read_bytes()).hexdigest() != digest:
                raise RuntimeError(f'Source changed during extraction: {proof}')
            source_audit[task['path']] = dict(proof=str(proof), sha256=digest,
                checks=check_outputs, local_actions=len(allowed))
        else:
            allowed = {r['candidate'] for r in map(json.loads, (root/'manifest.jsonl').read_text().splitlines())
                       if r.get('recheck_status') == 'certified' and r.get('deterministic_rechecks', 0) >= 2}
        allowed_identities = {source_action_identity(atom) for atom in allowed}
        observations = []
        aliases = []
        # Explicit alpha merges are newly explored native steps, not actions
        # copied from the source CPF. Retain them only as weak guidance and
        # require the recorded native child to decrease the pair count while
        # preserving the complete set of variable-alpha pair signatures.
        from probe_alpha_dp_merges import pair_signature
        for probe_path in (root/'steps').rglob('alpha-merges/[0-9]*.json'):
            probe = json.loads(probe_path.read_text())
            source_path = probe_path.with_suffix('.cpf')
            children = probe.get('children', [])
            if probe.get('typed_outcome') != 'Transformed' or len(children) != 1:
                continue
            cpf = source_path.read_text()
            before_count, before_pairs = pair_signature(cpf)
            after_count, after_pairs = pair_signature(children[0]['cpf'])
            if after_count >= before_count or after_pairs != before_pairs:
                raise RuntimeError(f'Invalid recorded alpha merge: {probe_path}')
            observations.append((hashlib.sha256(cpf.strip().encode()).hexdigest(), 'alpha-merge'))
            aliases.append((cpf, 'alpha-merge'))
        for path in (root/'steps').rglob('processor-events.jsonl'):
            for event in map(json.loads, path.read_text().splitlines()):
                atom = event.get('strategy_atom', '')
                if atom.startswith(('exact-dp-proof(', 'exact-trs-proof(')):
                    continue
                if atom not in allowed and source_action_identity(atom) not in allowed_identities:
                    source_atom = event.get('source_strategy_atom', '')
                    native_recovery = False
                    if (same_unbound_redpair_hint(atom, source_atom)
                            and source_action_identity(source_atom) in allowed_identities):
                        native_recovery = True
                    if atom == 'usable-rules' and source_atom.startswith('exact-usable-rules(') \
                            and source_action_identity(source_atom) in allowed_identities:
                        native_recovery = True
                    native_tag = {
                        'rewrite': 'rewritingProc',
                        'instantiate': 'instantiationProc',
                        'forward-instantiate': 'forwardInstantiationProc',
                        'narrow': 'narrowingProc',
                    }.get(atom.split('(', 1)[0])
                    if atom != 'rewrite' and re.fullmatch(r'(?:instantiate|forward-instantiate|narrow)\(candidate=\d+,max-per-pair=128\)', atom) is None:
                        native_tag = None
                    if native_tag is not None and source_atom.startswith('exact-dp-transform(') \
                            and source_action_identity(source_atom) in allowed_identities:
                        try:
                            payload = json.loads(bytes.fromhex(source_atom.split('hex=', 1)[1][:-1]))
                            native_recovery = payload[0] == native_tag
                        except (ValueError, IndexError, TypeError):
                            pass
                    # A source-bound witness may have been rebound to a
                    # different variable representation by the exporter.
                    # Do not grant the unmatched witness source credit: offer
                    # only the native family, which recomputes its obligation.
                    if native_recovery:
                        pass
                    elif atom.startswith('exact-usable-rules(') and any(
                            candidate.startswith('exact-usable-rules(') for candidate in allowed):
                        atom = 'usable-rules'
                    else:
                        continue
                if event.get('credit', {}).get('status') != 'diagnostic-only' or event.get('outcome') not in ('solved', 'transformed'):
                    continue
                cpf = event['input']['cpf']
                observations.append((hashlib.sha256(cpf.strip().encode()).hexdigest(), atom))
                canonical_atom = atom if atom == 'usable-rules' else canonical_candidate(atom)
                if canonical_atom is not None:
                    aliases.append((cpf, canonical_atom))
        def canonical_alias(item):
            cpf, atom = item
            try:
                canonical = canonicalize_with_ferrum(cpf, args.ferrum, 60)
            except Exception:
                return None
            return hashlib.sha256(canonical.strip().encode()).hexdigest(), atom
        with ThreadPoolExecutor(max_workers=args.state_jobs) as pool:
            observations.extend(alias for alias in pool.map(canonical_alias, aliases) if alias is not None)
        return observations

    states, witnesses = defaultdict(dict), {}
    with ThreadPoolExecutor(max_workers=args.jobs) as pool:
        for future in as_completed([pool.submit(collect, task) for task in tasks]):
            for key, atom in future.result():
                reference = hashlib.sha256(atom.encode()).hexdigest()
                if atom.startswith('exact-'):
                    witnesses[reference] = atom
                    candidate = dict(candidate_ref=reference)
                else:
                    candidate = dict(candidate=atom)
                states[key][reference] = dict(candidate, status='transformed_weak',
                    utility_score=1500, attempts=1, certified_count=0, solved_count=0,
                    transformed_count=1, failed_count=0, timeout_count=0, best_elapsed_ms=0)
    with args.output.open('x') as out:
        for reference, atom in sorted(witnesses.items()):
            print(json.dumps(dict(schema='ferrum.utility-guidance.witness.v1', witness_id=reference, candidate=atom)), file=out)
        for key, entries in sorted(states.items()):
            print(json.dumps(dict(schema='ferrum.utility-guidance.v2', problem_key=key,
                replay_order=sorted(entries),
                prefer=[entries[reference] for reference in sorted(entries)],
                possible=[], avoid=[], timeout=[])), file=out)
    if args.baseline:
        with args.output.with_suffix('.sources.json').open('x') as audit:
            json.dump(source_audit, audit, indent=2, sort_keys=True)
    print(json.dumps({'states': len(states), 'witnesses': len(witnesses), 'certified_promotions': 0}))


if __name__ == '__main__':
    main()
