#!/usr/bin/env python3
"""Recover exact current-state oracle evidence from certified local CPF proofs."""

from __future__ import annotations

import argparse
import copy
import concurrent.futures
import functools
import hashlib
import json
import math
import re
import subprocess
import sys
import tempfile
import xml.etree.ElementTree as ET
from collections import Counter, defaultdict
from fractions import Fraction
from pathlib import Path

from build_hrm_status_map_dataset import normalize_atom
from build_hrm_strategy_direct_dataset import strategy_from_xml
from build_credited_status_map_dataset import (
    canonicalize_cpf_input,
    canonicalize_with_ferrum,
)
from atomize_oracle_guidance import atomize
from audit_canonical_fragments import normalize_cpf2_terms
from extract_exact_fragment_training_data import (
    child_input_for,
    dp_input_like,
    first_child,
    input_wrapper,
    iter_exact_rows,
    local_name,
    normalized_rule_signature,
    proof_child,
)
from extract_subproof_training_data import load_xml


def cpf_processor_tag_for_runtime(tag: str) -> str:
    """Replay scheduling policy does not change the checked CPF proof rule."""
    if tag == 'innermostLhssRemovalProcNontermination':
        return 'innermostLhssRemovalProc'
    return "forwardInstantiationProc" if tag == "forwardInstantiationProcDirect" else tag


DIRECT_ATOMS = {
    "depGraphProc": "graph",
    # A CPF node identifies one concrete transformation, not a portfolio
    # search. Pin candidate zero so replay uses the retained-witness path:
    # unlike the generic atoms this does not advance the search-local depth
    # counter and therefore reproduces the certified child state exactly.
    "forwardInstantiationProc": "forward-instantiate(max-per-pair=2,candidate=0)",
    "csrForwardInstantiationProc": "forward-instantiate(max-per-pair=2,candidate=0)",
    "instantiationProc": "instantiate(max-per-pair=2,candidate=0)",
    # CPF records the chosen narrowing result, but not Ferrum's candidate
    # budget.  Inferring max-per-pair=2 can select another child than the live
    # certified run.  Keep the portable default atom here; an observed runtime
    # atom may still retain an explicit parameter when it produced the proof.
    "narrowingProc": "narrow",
    "rewriteProc": "rewrite(max-per-pair=2)",
    "rewritingProc": "rewrite(max-per-pair=2)",
    "semanticLabelingProc": "semantic-labeling",
    "semlabProc": "semantic-labeling",
    "sizeChangeProc": "size-change",
    "splitProc": "split",
    "subtermProc": "subterm",
    "subtermCriterionProc": "subterm",
    "stringReversal": "string-reversal",
    "constantToUnary": "exact-constant-to-unary",
    "switchFullStrategy": "nontermination(loop)",
    "switchInnermost": "switch-innermost",
    "switchInnermostProc": "switch-innermost",
    "aaeccInnermost": "aaecc-innermost",
    "qdpToSrs": "qdp-to-srs",
    "ignoreRelativePart": "nontermination(loop)",
    "flatContextClosure": "relative-flat-context-closure",
    "uncurry": "uncurry",
    "uncurryProc": "uncurry",
    "usableRulesProc": "usable-rules",
    "localUsableRulesProc": "usable-rules",
    "csrDependencyPairs": "csr-native-dp",
    "csrImprovedDependencyPairs": "csr-improved-dp",
    # Safe CS-DPs are a distinct root action.  Collapsing them into `dp`
    # makes replay re-run the adaptive QCS/improved/conservative scheduler and
    # can starve the exact certified construction before its child states are
    # reached.
    "csrSafeDependencyPairs": "csr-safe-dp",
    "csrRta08DependencyPairs": "csr-rta08-dp",
    "csrConservativeDependencyPairs": "csr-conservative-dp",
    "csrMutermTypedDependencyPairs": "csr-muterm-unhiding",
    "csrGuardedImprovedDependencyPairs": "csr-improved-dp",
    "csrGuardedDependencyPairs": "csr-native-dp",
    "csrGuardedDepGraphProc": "graph",
    # Verified inverse of the complete GM04 transformed-CSR encoding.  The
    # processor has two independently replayed children (the source CSR and
    # the transformed residual DP problem), so retain it as a transformation
    # rather than collapsing the complete certificate into a root fragment.
    "gm04CompleteTransformation": "gm04-inverse-csr",
    "gm04CompleteFullTransformation": "gm04-inverse-csr-full",
    "csrGmTransformation": "csr-gm-transform",
    "gm04CompleteNonterminationTransformation": "gm04-inverse-csr",
}


# Optional production canonicalizer used for cross-generation proof imports.
# The pure-Python fallback remains useful when Ferrum is unavailable, but its
# historical first-occurrence labelling can distinguish a large symmetric TRS
# solely because its rules were serialized in another order.  Exact imported
# witnesses must meet the same canonical state that production lookup uses.
FERRUM_CANONICALIZER: str | None = None


def materialize_rule_table_references(root: ET.Element) -> ET.Element:
    """Return a CPF whose standalone rule sets contain concrete rules.

    CPF permits a global ``ruleTable`` and compact ``ruleIndex`` references.
    Exact subproof extraction, however, serializes each reconstructed input as
    an independent CPF problem.  Leaving an index in such an input silently
    drops the rule once the surrounding lookup table is gone.  Besides making
    the residual non-self-contained, that changes its canonical state key and
    prevents live worklist states from finding their certified continuation.

    Scalar references selecting rules for a transformation are expanded too,
    because the residual-state reconstructor consumes the concrete selected
    rule after the global table has been detached.
    """
    expanded = copy.deepcopy(root)
    table: dict[str, ET.Element] = {}
    for entry in expanded.iter():
        if local_name(entry.tag) != "indexToRule":
            continue
        index = next(
            (child for child in entry if local_name(child.tag) == "index"),
            None,
        )
        rule = next(
            (child for child in entry if local_name(child.tag) == "rule"),
            None,
        )
        key = (index.text or "").strip() if index is not None else ""
        if key and rule is not None:
            table[key] = copy.deepcopy(rule)
    if not table:
        return expanded
    for rules in expanded.iter():
        if local_name(rules.tag) != "rules":
            continue
        children = list(rules)
        for position, child in enumerate(children):
            if local_name(child.tag) != "ruleIndex":
                continue
            key = (child.text or "").strip()
            rule = table.get(key)
            if rule is None:
                continue
            rules.remove(child)
            rules.insert(position, copy.deepcopy(rule))
    rule_selecting_processors = {
        "forwardInstantiationProc",
        "csrForwardInstantiationProc",
        "instantiationProc",
        "narrowingProc",
        "rewriteProc",
        "rewritingProc",
    }
    for processor in expanded.iter():
        if local_name(processor.tag) not in rule_selecting_processors:
            continue
        children = list(processor)
        for position, child in enumerate(children):
            if local_name(child.tag) != "ruleIndex":
                continue
            rule = table.get((child.text or "").strip())
            if rule is None:
                continue
            processor.remove(child)
            processor.insert(position, copy.deepcopy(rule))

    # A general reduction-pair witness may mention rules in conditional proof
    # objects such as ``dpSequence`` without wrapping the references in a
    # ``rules`` element.  The exact processor retains this payload but rebuilds
    # its recursive dpProof children, so materialize every reference in the
    # retained (non-dpProof) portion.  This makes the witness independent of the
    # source CPF's global lookup table.
    def expand_general_payload(parent: ET.Element) -> None:
        children = list(parent)
        for position, child in enumerate(children):
            if local_name(child.tag) == "dpProof":
                continue
            if local_name(child.tag) == "ruleIndex":
                rule = table.get((child.text or "").strip())
                if rule is not None:
                    parent.remove(child)
                    replacement = copy.deepcopy(rule)
                    parent.insert(position, replacement)
                continue
            expand_general_payload(child)

    for processor in expanded.iter():
        if local_name(processor.tag) == "generalRedPairProc":
            expand_general_payload(processor)

    # Complete source-bound proof continuations retain payloads from every
    # CPF processor family, including rule references nested below rewrite
    # steps rather than directly below ``rewritingProc``.  At every CPF site
    # a ruleIndex is the compact alternative to the concrete rule itself, so
    # recursively eliminate all remaining references before detaching the
    # proof from its global lookup table.
    def expand_all_rule_indices(parent: ET.Element) -> None:
        for position, child in enumerate(list(parent)):
            if local_name(child.tag) == "ruleIndex":
                rule = table.get((child.text or "").strip())
                if rule is not None:
                    parent.remove(child)
                    parent.insert(position, copy.deepcopy(rule))
                continue
            expand_all_rule_indices(child)

    expand_all_rule_indices(expanded)
    return expanded


def explicit_csr_dp_atom_from_proof(proof_node: ET.Element) -> str | None:
    """Recover the exact CSR-DP construction hidden by a legacy bare dp event."""
    processor = next(iter(proof_node), None)
    if processor is None:
        return None
    return {
        "csrDependencyPairs": "csr-native-dp",
        "csrSafeDependencyPairs": "csr-safe-dp",
        "csrImprovedDependencyPairs": "csr-improved-dp",
        "csrRta08DependencyPairs": "csr-rta08-dp",
        "conservativeCsrTerminationProof": "csr-conservative-dp",
        # The first action is rule removal; any adjacent bare DP event belongs
        # to the certified continuation and is specifically improved CS-DP.
        "csrRuleRemovalThenImproved": "csr-improved-dp",
    }.get(local_name(processor.tag))


@functools.lru_cache(maxsize=64)
def _retained_input_text(path: str, size: int, modified: int) -> str:
    return Path(path).read_text(encoding="utf-8")


def hydrate_content_addressed_probe_input(event: dict) -> None:
    """Recover an omitted probe input only from its byte-verified local CPF.

    Benchmark names, levels and adjacent states are not sufficient aliases.
    A child event cannot inherit the root unless its full digest is identical.
    """
    data = event.get("input") or {}
    if data.get("cpf") is not None or not data.get("content_addressed"):
        return
    filename = event.get("problem_id")
    if not isinstance(filename, str) or not filename.endswith((".cpf", ".cpf.xml")):
        return
    path = Path(filename)
    try:
        stat = path.stat()
        if not path.is_file() or stat.st_size > 64 * 1024 * 1024:
            return
        cpf = _retained_input_text(str(path.resolve()), stat.st_size, stat.st_mtime_ns)
    except (OSError, UnicodeError):
        return
    if hashlib.sha256(cpf.strip().encode()).hexdigest() == data.get("problem_key"):
        data["cpf"] = cpf


def unwrap_input(problem_xml: str) -> str | None:
    try:
        root = ET.fromstring(problem_xml)
    except ET.ParseError:
        return None
    if local_name(root.tag) in {"trsInput", "dpInput", "srsInput"}:
        return ET.tostring(root, encoding="unicode", short_empty_elements=True)
    if local_name(root.tag) != "input":
        return None
    for child in root:
        if local_name(child.tag) in {"trsInput", "dpInput", "srsInput"}:
            return ET.tostring(child, encoding="unicode", short_empty_elements=True)
    return None


def runtime_state_signature(problem_xml: str) -> str | None:
    """Return the semantic state shared by CPF fragments and live events.

    CPF subproof inputs reconstruct the full TRS/DP obligation.  The live
    Ferrum serializer also records DP-state context which is processor
    semantic: the rewrite strategy, dependency-pair source provenance, and
    whether ordinary reduction has started affect processor applicability.
    Preserve that context.  In particular, treating an archived state which
    lacks the context as equal to every current state can transport graph,
    instantiation, or reduction-pair evidence to the wrong obligation.
    Active usable rules are likewise part of the
    executable DP obligation: erasing them can attach a reduction pair below
    localUsableRulesProc to its parent state and thereby change the checker
    obligation.  The context-sensitive replacement map, active R, and CS-DP
    construction therefore all remain in the signature.
    """
    try:
        root = ET.fromstring(problem_xml)
    except ET.ParseError:
        return None
    if local_name(root.tag) == "input":
        root = next(
            (
                child
                for child in root
                if local_name(child.tag) in {"trsInput", "dpInput", "srsInput"}
            ),
            None,
        )
        if root is None:
            return None
    if local_name(root.tag) not in {"trsInput", "dpInput", "srsInput"}:
        return None

    # This flag records which reduction-pair implementation Ferrum may try;
    # it is not part of the DP obligation.  Older certified improved-CS-DP
    # proofs serialize it as false, while current Ferrum derives true for the
    # same R/P/Q/minimality state.  Guided processors still validate their
    # applicability and the assembled CPF is independently checked by CeTA.
    for context in root.iter():
        if local_name(context.tag) != "ferrumCsrDpContext":
            continue
        for child in list(context):
            if local_name(child.tag) == "qcsUsableRules":
                context.remove(child)
    # An absent active-rule override means R itself.  Some CPF residual
    # reconstructors spell that identical state as
    # ``<usableRules><rules>R</rules></usableRules>``.  Retaining the redundant
    # full set creates a false state split and prevents the next certified
    # child from being found.  Only erase the override when its rule multiset
    # is exactly the complete TRS; every proper subset remains a semantic DP
    # obligation and must stay in the key.
    trs = next((child for child in root if local_name(child.tag) == "trs"), None)
    active = next(
        (child for child in root if local_name(child.tag) == "usableRules"), None
    )

    def direct_rule_shapes(container: ET.Element | None) -> list[tuple]:
        if container is None:
            return []
        rules = next(
            (child for child in container if local_name(child.tag) == "rules"),
            None,
        )
        if rules is None:
            return []

        def shape(element: ET.Element) -> tuple:
            text = " ".join((element.text or "").split())
            if local_name(element.tag) == "name":
                numeric = re.fullmatch(r"\|([0-9][A-Za-z0-9_]*)\|", text)
                if numeric is not None:
                    text = numeric.group(1)
            return (
                local_name(element.tag),
                text,
                tuple(shape(child) for child in element),
            )

        return sorted(
            shape(rule) for rule in rules if local_name(rule.tag) == "rule"
        )

    if (
        active is not None
        and direct_rule_shapes(active) == direct_rule_shapes(trs)
    ):
        root.remove(active)
    # The typed MU-TERM checker closes the replacement map over its generated
    # marked and fresh-unhiding signature.  Ferrum's live DP state stores only
    # the original CSR map because the generated symbols have processor-fixed
    # activity.  These serializations denote the same obligation, but only for
    # this explicitly tagged construction; retaining or dropping arbitrary
    # user-symbol map entries would be an unsafe alias.
    construction = next(
        (
            (child.text or "").strip()
            for context in root.iter()
            if local_name(context.tag) == "ferrumCsrDpContext"
            for child in context
            if local_name(child.tag) == "construction"
        ),
        "",
    )
    if construction in {"muterm-unhiding", "improved"}:
        for strategy in root.iter():
            if local_name(strategy.tag) != "contextSensitive":
                continue
            for entry in list(strategy):
                if local_name(entry.tag) != "replacementMapEntry":
                    continue
                has_marked_symbol = any(
                    local_name(child.tag) == "sharp" for child in entry
                )
                names = [
                    (element.text or "").strip()
                    for element in entry.iter()
                    if local_name(element.tag) == "name"
                ]
                if has_marked_symbol or any(
                    name.startswith("__CSR_U") for name in names
                ):
                    strategy.remove(entry)
    # A replacement-map declaration for a constant has no active positions
    # and therefore cannot change the context-sensitive rewrite relation.
    # CPF reconstruction may omit a constructor which occurs only in the
    # transformed administrative signature, while Ferrum's live serializer
    # lists it explicitly with arity zero.  Normalize this representation-only
    # difference for every context-sensitive state; non-nullary entries remain
    # part of the exact proof obligation.
    for strategy in root.iter():
        if local_name(strategy.tag) != "contextSensitive":
            continue
        for entry in list(strategy):
            if local_name(entry.tag) != "replacementMapEntry":
                continue
            arity = next(
                (
                    (child.text or "").strip()
                    for child in entry
                    if local_name(child.tag) == "arity"
                ),
                "",
            )
            if arity == "0":
                strategy.remove(entry)
    # CPF treats an absent strategy as full rewriting.  Archived proof
    # reconstruction sometimes writes `<strategy><full/></strategy>` while
    # Ferrum's live CPF3 serializer omits that default.  They are the same
    # proof state and must receive the same runtime signature.
    for parent in root.iter():
        for child in list(parent):
            if (
                local_name(child.tag) == "strategy"
                and len(list(child)) == 1
                and local_name(list(child)[0].tag) == "full"
            ):
                parent.remove(child)
    # CPF parsers select DP-input fields by tag, so sibling order is not part
    # of the mathematical state.  Official AProVE certificates sometimes put
    # `strategy` before `usableRules`, whereas Ferrum's serializer writes the
    # reverse order.  Normalize the known direct fields without moving any
    # unknown extension past another unknown extension.
    dp_input = next(
        (element for element in root.iter() if local_name(element.tag) == "dpInput"),
        None,
    )
    if dp_input is not None:
        order = {
            "trs": 0,
            "dps": 1,
            "ferrumWeakDps": 2,
            "usableRules": 3,
            "strategy": 4,
            "minimal": 5,
            "ferrumCsrDpContext": 6,
            "ferrumDpStateContext": 7,
        }
        children = list(dp_input)
        indexed = list(enumerate(children))
        indexed.sort(key=lambda item: (order.get(local_name(item[1].tag), 100), item[0]))
        dp_input[:] = [child for _, child in indexed]
    is_dp_input = any(local_name(element.tag) == "dpInput" for element in root.iter())
    for element in root.iter():
        if local_name(element.tag) == "name":
            text = (element.text or "").strip()
            numeric = re.fullmatch(r"\|([0-9][A-Za-z0-9_]*)\|", text)
            if numeric is not None:
                element.text = numeric.group(1)
        if local_name(element.tag) == "innermost" and not list(element):
            nfs = ET.SubElement(element, "nfs")
            # CPF's optional `nfs` flag defaults to false.  Treating an empty
            # `<innermost/>` in an archived DP input as true silently changed
            # the obligation and orphaned every subsequent certified child.
            # Non-DP inputs do not use this flag, but retain the historical
            # spelling there to avoid changing unrelated root aliases.
            nfs.text = "false" if is_dp_input else "true"
        element.text = (element.text or "").strip() or None
        element.tail = None
    normalized = ET.tostring(root, encoding="unicode", short_empty_elements=True)
    try:
        canonical = (
            canonicalize_with_ferrum(normalized, FERRUM_CANONICALIZER, 60.0)
            if FERRUM_CANONICALIZER is not None
            else canonicalize_cpf_input(normalized)[0]
        )
        return canonical
    except (
        ET.ParseError,
        ValueError,
        subprocess.CalledProcessError,
        subprocess.TimeoutExpired,
    ):
        # Keep extraction total for partial/extension inputs.  The fallback is
        # formatting-normalized but deliberately does not invent an alias.
        # In particular, an exact graph atom can contain an SCC projection
        # which the current CPF input parser rejects even though the complete
        # source proof is certified.  Such a synthetic child must not abort
        # recovery of the other, independently canonicalizable states.
        return normalized


LEGACY_UNIQUE_CONTEXT_PREFIX = "\0legacy-unique-context\0"
EXACT_CHILD_CONTEXT_PREFIX = "\0exact-child-context\0"
CAUSAL_CHILD_CONTEXT_PREFIX = "\0causal-child-context\0"
CAUSAL_PARENT_ATOM_PREFIX = "\0causal-parent-atom\0"
CAUSAL_PARENT_CONTEXT_PREFIX = "\0causal-parent-context\0"
CAUSAL_PARENT_RAW_PREFIX = "\0causal-parent-raw\0"
CAUSAL_UNIQUE_PARENT_TAG_PREFIX = "\0causal-unique-parent-tag\0"


def exact_semantic_model_discriminator(atom: str) -> str | None:
    match = re.fullmatch(
        r"exact-semantic-labeling\(hex=([0-9a-fA-F]+)\)", atom
    )
    if match is None:
        return None
    try:
        decoded = json.loads(bytes.fromhex(match.group(1)).decode("utf-8"))
    except (ValueError, UnicodeDecodeError, json.JSONDecodeError):
        return None
    model = decoded[0] if isinstance(decoded, list) and len(decoded) in {2, 3} else decoded
    if not isinstance(model, dict):
        return None
    canonical = json.dumps(
        model, ensure_ascii=False, sort_keys=True, separators=(",", ":")
    )
    return "semlabProc@" + hashlib.sha256(canonical.encode("utf-8")).hexdigest()
PORTABLE_EXACT_CONTEXT_PREFIX = "\0portable-exact-context\0"


def contextless_runtime_state_signature(
    problem_xml: str, canonical_signature: str | None = None
) -> str | None:
    """Canonical DP-state core used only for a uniqueness-checked bridge.

    Archived CPF inputs predate ``ferrumDpStateContext``.  They may be joined
    to a current live state only when every observed live state with the same
    rewriting obligation has one identical semantic context.  This helper is
    never itself an oracle key; ``read_runtime_state_aliases`` uses it to
    construct that uniqueness proof.
    """
    # Canonical symbol order can depend on provenance. Remove provenance
    # before canonicalization, while transporting Q to its semantic field.
    recanonicalize = has_dp_state_context(problem_xml)
    canonical = (unwrap_input(problem_xml) or problem_xml) if recanonicalize else (
        canonical_signature or runtime_state_signature(problem_xml)
    )
    if canonical is None:
        return None
    # Reuse the full signature only when no provenance needed removal.
    #
    # CPF's archived DP input puts Q in ``strategy/innermostLhss``.  Ferrum's
    # first-class live state puts the identical obligation in
    # ``ferrumDpStateContext/innermostLhss`` alongside pair provenance.  Keep
    # Q in this contextless signature, but normalize both spellings to the
    # legacy strategy position; otherwise an exact Q-increase child can never
    # find its independently retained continuation.
    q_match = re.search(
        r"<(?:[A-Za-z_][\w.-]*:)?innermostLhss\b[^>]*?"
        r"(?:/\s*>|>.*?</(?:[A-Za-z_][\w.-]*:)?innermostLhss>)",
        canonical,
        flags=re.DOTALL,
    )
    stripped = re.sub(
        r"<(?:[A-Za-z_][\w.-]*:)?ferrumDpStateContext(?:\s[^>]*)?>.*?"
        r"</(?:[A-Za-z_][\w.-]*:)?ferrumDpStateContext>",
        "",
        canonical,
        flags=re.DOTALL,
    )
    if q_match is not None:
        stripped = re.sub(
        r"<(?:[A-Za-z_][\w.-]*:)?strategy(?:\s[^>]*)?>\s*"
        r"<(?:[A-Za-z_][\w.-]*:)?innermostLhss\b[^>]*?"
        r"(?:/\s*>|>.*?</(?:[A-Za-z_][\w.-]*:)?innermostLhss>)\s*"
        r"</(?:[A-Za-z_][\w.-]*:)?strategy>",
        "",
        stripped,
        flags=re.DOTALL,
    )
        normalized_q = f"<strategy>{q_match.group(0)}</strategy>"
        stripped = re.sub(r"</dpInput>\s*$", normalized_q + "</dpInput>", stripped)
    result = runtime_state_signature(stripped) if recanonicalize else stripped
    if result is None:
        return None
    # The serializer can reintroduce provenance while canonicalizing. Its
    # symbols now come from the provenance-free input, so remove that field
    # again and normalize whitespace left by the deletion.
    try:
        root = ET.fromstring(result)
    except ET.ParseError:
        return None
    # The native canonicalizer serializes Q back inside its state context.
    # Preserve that *canonicalized* Q before dropping provenance a second
    # time; deleting the whole context here used to erase Q on live states
    # while leaving it present on archived inputs, orphaning NO chains.
    for context in list(root):
        if local_name(context.tag) != 'ferrumDpStateContext':
            continue
        q = first_child(context, 'innermostLhss')
        if q is not None:
            strategy = first_child(root, 'strategy')
            if strategy is None:
                strategy = ET.SubElement(root, 'strategy')
            for old in list(strategy):
                if local_name(old.tag) == 'innermostLhss':
                    strategy.remove(old)
            strategy.append(copy.deepcopy(q))
        root.remove(context)
    for element in root.iter():
        element.text = (element.text or "").strip() or None
        element.tail = None
    return ET.tostring(root, encoding="unicode", short_empty_elements=True)


def reduction_pair_obligation_signature(problem_xml: str) -> str | None:
    """Canonical P/R obligation across a certified CSR-to-ordinary bridge.

    A CPF ``ordinaryDpProof`` deliberately changes the proof framework while
    retaining the same dependency pairs and active rules.  This signature is
    used only together with an identical exact model and a uniqueness check
    to recover the producing live key.  The replay atom still carries P and R
    and revalidates them before it can apply.
    """
    canonical = runtime_state_signature(problem_xml)
    if canonical is None:
        return None
    try:
        root = ET.fromstring(canonical)
    except ET.ParseError:
        return None
    for child in list(root):
        if local_name(child.tag) in {
            "strategy",
            "ferrumCsrDpContext",
            "ferrumDpStateContext",
        }:
            root.remove(child)
    return ET.tostring(root, encoding="unicode", short_empty_elements=True)


def has_dp_state_context(problem_xml: str) -> bool:
    return "ferrumDpStateContext" in problem_xml


@functools.lru_cache(maxsize=4096)
def live_numeric_symbol_aliases(live_problem_xml: str) -> tuple[tuple[str, str], ...]:
    """Return numeric CPF aliases once per live obligation."""
    try:
        live = ET.fromstring(live_problem_xml)
    except ET.ParseError:
        return ()
    live_names = {
        (element.text or "").strip()
        for element in live.iter()
        if local_name(element.tag) == "name"
    }
    return tuple(
        sorted(
            (match.group(1), name)
            for name in live_names
            if (match := re.fullmatch(r"\|([0-9][A-Za-z0-9_]*)\|", name))
            is not None
        )
    )


def align_fragment_numeric_symbols(fragment_xml: str, live_problem_xml: str) -> str:
    """Use the live parser spelling for numeric function symbols.

    TPDB inputs spell numeric-leading function symbols such as ``|0|`` and
    ``|2nd|`` with bars, while archived CPF proofs commonly spell the same
    symbols as ``0`` and ``2nd``.  State canonicalization deliberately
    identifies those spellings, but exact witness payloads must still use the
    live symbol names consumed by Ferrum.  Only rewrite a bare numeric-leading
    identifier when the corresponding quoted name actually occurs in the live
    obligation.
    """
    numeric_aliases = dict(live_numeric_symbol_aliases(live_problem_xml))
    if not numeric_aliases:
        return fragment_xml
    try:
        fragment = ET.fromstring(fragment_xml)
    except ET.ParseError:
        return fragment_xml
    changed = False
    for element in fragment.iter():
        if local_name(element.tag) != "name":
            continue
        name = (element.text or "").strip()
        replacement = numeric_aliases.get(name)
        if replacement is not None:
            element.text = replacement
            changed = True
    return (
        ET.tostring(fragment, encoding="unicode", short_empty_elements=True)
        if changed
        else fragment_xml
    )


def runtime_dp_subset_signature(
    problem_xml: str, canonical_signature: str | None = None
) -> tuple[str, frozenset[str]] | None:
    """Split a DP state into its non-pair context and normalized pair set."""
    # Callers indexing a runtime trace have already paid for the full
    # canonical signature.  Recomputing it here used to parse, normalize, and
    # alpha-canonicalize every (occasionally multi-megabyte) DP state twice.
    canonical = canonical_signature or runtime_state_signature(problem_xml)
    if canonical is None:
        return None
    try:
        root = ET.fromstring(canonical)
    except ET.ParseError:
        return None
    if local_name(root.tag) == "input":
        root = next(
            (child for child in root if local_name(child.tag) == "dpInput"),
            None,
        )
        if root is None:
            return None
    if local_name(root.tag) != "dpInput":
        return None
    for child in list(root):
        if local_name(child.tag) in {
            "dps",
            "usableRules",
        }:
            root.remove(child)
    pairs_root = ET.fromstring(canonical)
    if local_name(pairs_root.tag) == "input":
        pairs_root = next(
            (child for child in pairs_root if local_name(child.tag) == "dpInput"),
            None,
        )
        if pairs_root is None:
            return None
    dps = next(
        (child for child in pairs_root if local_name(child.tag) == "dps"),
        None,
    )
    pairs: set[str] = set()
    if dps is not None:
        for rule in dps.iter():
            if local_name(rule.tag) != "rule":
                continue
            rule_copy = copy.deepcopy(rule)
            for element in rule_copy.iter():
                element.text = (element.text or "").strip() or None
                element.tail = None
            pairs.add(ET.tostring(rule_copy, encoding="unicode"))
    for element in root.iter():
        element.text = (element.text or "").strip() or None
        element.tail = None
    context = ET.tostring(root, encoding="unicode", short_empty_elements=True)
    return context, frozenset(pairs)


def problem_identity(problem_id: object) -> str:
    """Normalize absolute/run-relative benchmark names to a category suffix."""
    text = str(problem_id or "").replace("\\", "/")
    # Generated children retain the originating benchmark name and append a
    # processor-local suffix, for example ``z12.ari#qdp-to-srs``.  The suffix
    # identifies the typed state, not a second benchmark.  Runtime state keys
    # already distinguish that child exactly; allowing the suffix into the
    # benchmark identity instead strands the preceding certified continuation
    # under ``z12.ari`` and the child continuation under another namespace.
    # Literal ``#`` characters inside TPDB filenames (such as ``#3.15.ari``)
    # remain untouched because only text after the terminal ``.ari`` is
    # discarded.
    ari_end = text.find(".ari#")
    if ari_end >= 0:
        text = text[: ari_end + len(".ari")]
    parts = [part for part in text.split("/") if part not in {"", ".", ".."}]
    start = next(
        (index for index, part in enumerate(parts) if part.startswith(("TRS_", "SRS_"))),
        None,
    )
    return "/".join(parts[start:]) if start is not None else text


def problem_selection_variants(problem_id: object) -> set[str]:
    """Return exact category-qualified and suite-relative selection names.

    Adjacent result files from the flat category runner store names such as
    ``AG01_innermost/#4.26.ari``, whereas campaign file lists normally contain
    ``TRS_Innermost/AG01_innermost/#4.26.ari`` (and may be absolute TPDB
    paths). Compare those exact representations instead of using a suffix
    test: suffix matching also confuses ``AG01_innermost/#4.26`` with
    ``Applicative_AG01_innermost/#4.26``.
    """
    normalized = problem_identity(problem_id).lstrip("./")
    variants = {normalized} if normalized else set()
    parts = normalized.split("/")
    if parts and parts[0].startswith(("TRS_", "SRS_")) and len(parts) > 1:
        variants.add("/".join(parts[1:]))
    return variants


def problem_selection_matches(candidate: object, wanted: set[str]) -> str | None:
    """Return the uniquely matched requested identity, if there is one."""
    candidate_variants = problem_selection_variants(candidate)
    matches = [
        entry
        for entry in wanted
        if candidate_variants & problem_selection_variants(entry)
    ]
    return matches[0] if len(matches) == 1 else None


def flattened_artifact_problem_identity(
    proof_path: Path, wanted: set[str]
) -> str | None:
    """Recover a TPDB identity from TermCOMP's flattened artifact directory.

    Official proof downloads are stored below directories such as
    ``TRS_Standard_AProVE_04_JFP_Ex31.ari`` and do not carry Ferrum's adjacent
    ``result.json``. A supplied TPDB file list makes the inverse mapping
    unambiguous even when benchmark names themselves contain underscores.
    """
    by_flattened: dict[str, set[str]] = defaultdict(set)
    for entry in wanted:
        for variant in problem_selection_variants(entry):
            flattened = variant.replace("/", "_")
            doubled = variant.replace("/", "__")
            basename = variant.rsplit("/", 1)[-1]
            spellings = {flattened, doubled, basename}
            if flattened.endswith(".ari"):
                # The verified CPF2-to-CPF3 recovery tree names a detached
                # certificate after its benchmark, replacing the input suffix
                # rather than placing it below an adjacent result.json.
                spellings.add(flattened[: -len(".ari")] + ".cpf.xml")
                spellings.add(doubled[: -len(".ari")] + ".cpf.xml")
                spellings.add(basename[: -len(".ari")])
            for spelling in spellings:
                by_flattened[spelling].add(entry)
                # StarExec sanitizes the literal `#` in classic
                # AG/applicative names as `sharp_`.
                by_flattened[spelling.replace("#", "sharp_")].add(entry)
    matches = {
        entry
        for part in proof_path.parts
        for entry in by_flattened.get(part, set())
    }
    return next(iter(matches)) if len(matches) == 1 else None


def equivalent_runtime_identities(identity: str) -> set[str]:
    """Return narrowly certified benchmark identities for GM CSR children.

    TermCOMP stores the Giesl--Middeldorp image of ``CSR_04/X.ari`` as the
    ordinary benchmark ``Transformed_CSR_04/X_GM.ari``.  A live
    ``csr-gm-transform`` child retains the native root's problem id, although
    its typed TRS/DP obligation is the transformed benchmark.  Permit that one
    name-checked bridge; state signatures and exact processor source guards
    still have to match before any action can execute.
    """
    identities = {identity}
    standard_prefix = "TRS_Standard/Transformed_CSR_04/"
    csr_prefix = "TRS_Contextsensitive/CSR_04/"
    if identity.startswith(standard_prefix) and identity.endswith("_GM.ari"):
        stem = identity[len(standard_prefix) : -len("_GM.ari")]
        if stem and "/" not in stem:
            identities.add(f"{csr_prefix}{stem}.ari")
    elif identity.startswith(csr_prefix) and identity.endswith(".ari"):
        stem = identity[len(csr_prefix) : -len(".ari")]
        if stem and "/" not in stem:
            identities.add(f"{standard_prefix}{stem}_GM.ari")
    return identities


def proof_problem_identity(
    proof_path: Path, problem_id: object, category_hint: object = None
) -> str:
    """Qualify run-relative problem ids with the proof tree's category."""
    identity = problem_identity(problem_id)
    if identity.startswith(("TRS_", "SRS_")):
        return identity
    category = None
    for part in proof_path.parts:
        if not part.startswith(("TRS_", "SRS_")):
            continue
        # The parallel collector flattens a benchmark into filenames such as
        # ``TRS_Contextsensitive__CSR_04__Ex1.cpf.xml``.  Treating that whole
        # filename as the category prevented every certified flat-run state
        # from matching its live ``TRS_Contextsensitive/...`` identity.
        category = part.split("__", 1)[0]
        break
    category = category or str(category_hint or "").strip() or None
    # Isolated residual proofs are intentionally stored outside a TermCOMP
    # category tree. Their adjacent processor events consequently carry no
    # category either. The collector represents that absence as the display
    # value ``unknown``; treating it as a real path component changes
    # ``/tmp/state.xml`` into ``unknown/tmp/state.xml`` and breaks every
    # otherwise exact causal child alias from the certified run.
    if category == "unknown":
        category = None
    return f"{category}/{identity.lstrip('/')}" if category else identity


def read_runtime_state_aliases(
    event_paths: list[Path],
    *,
    reconstruct_encoded_children: bool = True,
) -> tuple[
    dict[tuple[str, str], set[str]],
    list[tuple[str, str, frozenset[str], str]],
    dict[str, str],
]:
    runtime_keys: dict[tuple[str, str], set[str]] = {}
    runtime_dp_states: list[tuple[str, str, frozenset[str], str]] = []
    runtime_inputs: dict[str, str] = {}
    context_candidates: dict[
        tuple[str, str], dict[str, set[str]]
    ] = {}
    # An archived CPF child predating ferrumDpStateContext can have the same
    # visible R/P/Q obligation as several live children with different pair
    # provenance.  A strict exact-dp-transform attempt records the particular
    # live child it materialized immediately before reporting that the child
    # had no oracle continuation.  Keep that causal observation separately:
    # it can disambiguate the legacy child without equating the other live
    # contexts.
    exact_child_contexts: dict[
        tuple[str, str], dict[str, set[str]]
    ] = {}
    causal_child_contexts: dict[
        tuple[str, str, str], dict[str, set[str]]
    ] = {}
    causal_parent_tag_children: dict[tuple[str, str], set[str]] = {}
    signature_cache: dict[
        str, tuple[str | None, tuple[str, frozenset[str]] | None]
    ] = {}
    # Runtime traces repeat the same exact atom at the parent event, its
    # recursive-return event, and often across retries.  Some payloads embed a
    # multi-megabyte DP input.  Decoding and reparsing that payload for every
    # occurrence dominated root-local pool construction, despite the atom
    # itself being content-addressed and immutable.
    exact_transform_child_cache: dict[str, str | None] = {}
    parent_processor_tag_cache: dict[tuple[str, str], str | None] = {}
    exact_graph_children_cache: dict[str, tuple[str, ...] | None] = {}
    exact_split_children_cache: dict[str, tuple[str, ...] | None] = {}
    fallback_event_identity = ""

    def cached_signatures(
        cpf: str, raw_key: str | None = None
    ) -> tuple[str | None, tuple[str, frozenset[str]] | None]:
        # Processor traces can repeat a very large content-addressed CPF
        # thousands of times (the Length innermost replay is ~1.8 GiB).
        # Using the CPF text itself as a dictionary key makes Python hash the
        # entire XML again for every freshly decoded JSON string.  The runtime
        # key is already its content address, so cache by that compact key;
        # fall back to one explicit digest only for legacy rows without it.
        cache_key = raw_key or hashlib.sha256(cpf.encode("utf-8")).hexdigest()
        cached = signature_cache.get(cache_key)
        if cached is None:
            signature = runtime_state_signature(cpf)
            cached = (
                signature,
                runtime_dp_subset_signature(cpf, signature),
            )
            signature_cache[cache_key] = cached
        return cached

    def record(identity: str, cpf: object, key: object) -> None:
        if not isinstance(cpf, str) or not isinstance(key, str):
            return
        runtime_inputs.setdefault(key, cpf)
        signature, subset_signature = cached_signatures(cpf, key)
        if signature is not None:
            runtime_keys.setdefault((identity, signature), set()).add(key)
            core_signature = contextless_runtime_state_signature(cpf, signature)
            if core_signature is not None:
                context_candidates.setdefault((identity, core_signature), {}).setdefault(
                    signature, set()
                ).add(key)
        if subset_signature is not None:
            runtime_dp_states.append((identity, *subset_signature, key))

    def identity_of(event: dict) -> str:
        identity = problem_identity(event.get("problem_id"))
        category = str(event.get("category") or "")
        if category.startswith(("TRS_", "SRS_")) and not identity.startswith(
            ("TRS_", "SRS_")
        ):
            identity = f"{category}/{identity.lstrip('/')}"
        return identity or fallback_event_identity

    def exact_transform_child_core(event: dict) -> str | None:
        atom = str(event.get("strategy_atom") or event.get("processor") or "")
        if atom in exact_transform_child_cache:
            return exact_transform_child_cache[atom]
        match = re.fullmatch(
            r"(?:exact-dp|exact-dp-transform|exact-dp-no-rule-removal|exact-semantic-labeling)\(hex=([0-9a-fA-F]+)\)",
            atom,
        )
        if match is None:
            exact_transform_child_cache[atom] = None
            return None
        try:
            decoded = json.loads(bytes.fromhex(match.group(1)).decode("utf-8"))
        except (ValueError, UnicodeDecodeError, json.JSONDecodeError):
            return None
        if isinstance(decoded, str) and atom.startswith("exact-dp(hex="):
            child = decoded
            result = contextless_runtime_state_signature(unwrap_input(child) or child)
            exact_transform_child_cache[atom] = result
            return result
        if not isinstance(decoded, list) or (len(decoded) not in {2, 3}
                and not (atom.startswith('exact-dp-transform(') and len(decoded) == 4)):
            return None
        # Both context-bound encodings carry their independently reconstructed
        # archived child as item 2.  For semantic labeling the executable
        # processor may relocate the complete signature to a canonically
        # renamed live state; retaining the archived core here gives the next
        # CPF processor a causal bridge to that exact live residual.
        child = decoded[2] if atom.startswith('exact-dp-transform(') and len(decoded) == 4 else decoded[-1]
        if not isinstance(child, str):
            exact_transform_child_cache[atom] = None
            return None
        result = contextless_runtime_state_signature(unwrap_input(child) or child)
        exact_transform_child_cache[atom] = result
        return result

    def parent_processor_tag(event: dict) -> str | None:
        atom = str(event.get("strategy_atom") or event.get("processor") or "")
        cache_key = (atom, str(event.get("level") or ""))
        if cache_key in parent_processor_tag_cache:
            return parent_processor_tag_cache[cache_key]
        exact_transform = re.fullmatch(
            r"exact-dp-transform\(hex=([0-9a-fA-F]+)\)", atom
        )
        if exact_transform is not None:
            try:
                decoded = json.loads(
                    bytes.fromhex(exact_transform.group(1)).decode("utf-8")
                )
            except (ValueError, UnicodeDecodeError, json.JSONDecodeError):
                return None
            if isinstance(decoded, list) and decoded and isinstance(decoded[0], str):
                result = cpf_processor_tag_for_runtime(decoded[0])
                parent_processor_tag_cache[cache_key] = result
                return result
            parent_processor_tag_cache[cache_key] = None
            return None
        exact_red_pair = re.fullmatch(
            r"exact-red-pair\(hex=([0-9a-fA-F]+)\)", atom
        )
        if exact_red_pair is not None:
            try:
                decoded = json.loads(
                    bytes.fromhex(exact_red_pair.group(1)).decode("utf-8")
                )
            except (ValueError, UnicodeDecodeError, json.JSONDecodeError):
                return None
            if isinstance(decoded, list) and decoded and isinstance(decoded[0], str):
                result = decoded[0]
                parent_processor_tag_cache[cache_key] = result
                return result
            parent_processor_tag_cache[cache_key] = None
            return None
        base = atom.split("(", 1)[0]
        if base == "exact-dp":
            return "dpTrans"
        if base == "exact-dp-no-rule-removal":
            return "dpRuleRemoval"
        if base == "switch-innermost":
            return (
                "switchInnermostProc"
                if event.get("level") == "dependency-pair"
                else "switchInnermost"
            )
        if base == "aaecc-innermost":
            return "aaeccInnermost"
        if base == "switch-full-nontermination":
            return "switchFullStrategyProc"
        if base == "uncurry":
            return (
                "uncurryProc"
                if event.get("level") == "dependency-pair"
                else "uncurry"
            )
        tag = {
            # Ferrum materializes applicative-top DP uncurrying in two typed
            # worklist steps.  Both are represented by ordinary uncurryProc
            # nodes in the recursive CPF proof.
            "uncurry-below": "uncurryProc",
            "graph": "depGraphProc",
            "exact-graph": "depGraphProc",
            "exact-split": "splitProc",
            "usable-rules": "usableRulesProc",
            "exact-usable-rules": "usableRulesProc",
            "exact-general-red-pair": "generalRedPairProc",
            "exact-semantic-labeling": "semlabProc",
            "innermost-lhss": "innermostLhssRemovalProc",
            "exact-innermost-lhss": "innermostLhssRemovalProc",
            "forward-instantiate": "forwardInstantiationProc",
            "forward-instantiation": "forwardInstantiationProc",
            "instantiate": "instantiationProc",
            "instantiation": "instantiationProc",
            "narrow": "narrowingProc",
            "narrowing": "narrowingProc",
            "rewrite": "rewritingProc",
            "rewriting": "rewritingProc",
        }.get(base)
        if tag == "semlabProc" and base == "exact-semantic-labeling":
            return exact_semantic_model_discriminator(atom)
        parent_processor_tag_cache[cache_key] = tag
        return tag

    def exact_graph_child_cores(event: dict) -> list[str] | None:
        atom = str(event.get("strategy_atom") or event.get("processor") or "")
        if atom in exact_graph_children_cache:
            cached = exact_graph_children_cache[atom]
            return list(cached) if cached is not None else None
        match = re.fullmatch(r"exact-graph\(hex=([0-9a-fA-F]+)\)", atom)
        if match is None:
            exact_graph_children_cache[atom] = None
            return None
        try:
            decoded = json.loads(bytes.fromhex(match.group(1)).decode("utf-8"))
            source_xml, components = decoded
            source = ET.fromstring(source_xml)
        except (ValueError, TypeError, UnicodeDecodeError, json.JSONDecodeError, ET.ParseError):
            return None
        if not isinstance(components, list):
            return None
        dps = next(
            (element for element in source.iter() if local_name(element.tag) == "dps"),
            None,
        )
        rules = first_child(dps, "rules") if dps is not None else None
        source_pairs = (
            [child for child in rules if local_name(child.tag) == "rule"]
            if rules is not None
            else []
        )
        result: list[str] = []
        # ElementTree serialization is read-only and elements do not carry a
        # parent pointer.  Project the already parsed source onto each SCC and
        # restore it afterwards instead of deep-copying the complete (often
        # multi-megabyte) DP state once per component.  Exact graph atoms are
        # common in timeout traces, so the old implementation made alias
        # discovery superlinear before the selected proofs were even read.
        original_pairs = list(rules) if rules is not None else []
        if rules is None:
            return None
        try:
            for component in components:
                if (
                    not isinstance(component, list)
                    or len(component) != 2
                    or component[1] is not True
                    or not isinstance(component[0], list)
                    or any(not isinstance(index, int) for index in component[0])
                    or any(index < 0 or index >= len(source_pairs) for index in component[0])
                ):
                    continue
                rules[:] = [source_pairs[index] for index in component[0]]
                core = contextless_runtime_state_signature(
                    ET.tostring(source, encoding="unicode")
                )
                if core is None:
                    return None
                result.append(core)
        finally:
            rules[:] = original_pairs
        exact_graph_children_cache[atom] = tuple(result)
        return result

    def exact_split_child_cores(event: dict) -> list[str] | None:
        atom = str(event.get("strategy_atom") or event.get("processor") or "")
        if atom in exact_split_children_cache:
            cached = exact_split_children_cache[atom]
            return list(cached) if cached is not None else None
        match = re.fullmatch(r"exact-split\(hex=([0-9a-fA-F]+)\)", atom)
        if match is None:
            exact_split_children_cache[atom] = None
            return None
        try:
            decoded = json.loads(bytes.fromhex(match.group(1)).decode("utf-8"))
            if len(decoded) == 2:
                selected_pair, source_xml = decoded
                selected_rule = None
            else:
                selected_pair, selected_rule, source_xml = decoded
            source = ET.fromstring(source_xml)
        except (ValueError, TypeError, UnicodeDecodeError, json.JSONDecodeError, ET.ParseError):
            return None
        dps = next(
            (element for element in source.iter() if local_name(element.tag) == "dps"),
            None,
        )
        rules = first_child(dps, "rules") if dps is not None else None
        pairs = (
            [child for child in rules if local_name(child.tag) == "rule"]
            if rules is not None
            else []
        )
        trs = first_child(source, "trs")
        trs_rules = first_child(trs, "rules") if trs is not None else None
        ordinary_rules = list(trs_rules) if trs_rules is not None else []
        pair_selected = isinstance(selected_pair, int) and selected_rule is None
        rule_selected = isinstance(selected_rule, int) and selected_pair is None
        if not (pair_selected ^ rule_selected):
            return None
        if pair_selected and not (0 <= selected_pair < len(pairs)):
            return None
        if rule_selected and not (0 <= selected_rule < len(ordinary_rules)):
            return None

        selected_child = copy.deepcopy(source)
        weak = ET.Element("ferrumWeakDps")
        weak_rules = ET.SubElement(weak, "rules")
        for index, pair in enumerate(pairs):
            if not pair_selected or index != selected_pair:
                weak_rules.append(copy.deepcopy(pair))
        minimal_index = next(
            (
                index
                for index, child in enumerate(list(selected_child))
                if local_name(child.tag) == "minimal"
            ),
            len(list(selected_child)),
        )
        selected_child.insert(minimal_index, weak)
        if rule_selected:
            context = next(
                (child for child in selected_child if local_name(child.tag) == "ferrumDpStateContext"),
                None,
            )
            if context is None:
                context = ET.SubElement(selected_child, "ferrumDpStateContext")
            strict = ET.SubElement(context, "strictRules")
            strict_rules = ET.SubElement(strict, "rules")
            strict_rules.append(copy.deepcopy(ordinary_rules[selected_rule]))

        residual_child = copy.deepcopy(source)
        residual_dps = next(
            (element for element in residual_child.iter() if local_name(element.tag) == "dps"),
            None,
        )
        residual_rules = (
            first_child(residual_dps, "rules") if residual_dps is not None else None
        )
        if residual_rules is None:
            return None
        if pair_selected:
            residual_rules[:] = [
                copy.deepcopy(pair) for index, pair in enumerate(pairs) if index != selected_pair
            ]
        cores = [
            contextless_runtime_state_signature(ET.tostring(child, encoding="unicode"))
            for child in (selected_child, residual_child)
        ]
        result = [core for core in cores if core is not None] if all(cores) else None
        exact_split_children_cache[atom] = (
            tuple(result) if result is not None else None
        )
        return result

    for event_path in event_paths:
        # Isolated ``ferrum prove`` traces deliberately omit a benchmark id.
        # When the adjacent result explicitly records one, use that identity
        # for every state in this one event stream.  This keeps the binding
        # benchmark-local while making the certified nested states from a
        # generated QDP-to-SRS (or analogous) subproblem independently
        # addressable.  Never infer an identity from a directory name.
        fallback_event_identity = ""
        result_path = event_path.with_name("result.json")
        if result_path.exists():
            try:
                result = json.loads(result_path.read_text(encoding="utf-8"))
            except (OSError, json.JSONDecodeError):
                result = {}
            result_problem_id = result.get("problem_id")
            if isinstance(result_problem_id, str) and result_problem_id.strip():
                fallback_event_identity = problem_identity(result_problem_id)
                result_category = str(result.get("category") or "")
                if result_category.startswith(("TRS_", "SRS_")) and not (
                    fallback_event_identity.startswith(("TRS_", "SRS_"))
                ):
                    fallback_event_identity = (
                        f"{result_category}/{fallback_event_identity.lstrip('/')}"
                    )
        events: list[dict] = []
        for line in event_path.read_text(encoding="utf-8", errors="replace").splitlines():
            if not line.strip():
                continue
            try:
                event = json.loads(line)
            except json.JSONDecodeError:
                continue
            if isinstance(event, dict):
                events.append(event)
        for index, event in enumerate(events):
            hydrate_content_addressed_probe_input(event)
            event_input = event.get("input") or {}
            identity = identity_of(event)
            cpf = event_input.get("cpf")
            key = event_input.get("problem_key")
            record(identity, cpf, key)
            # A transformed event materializes its children even when another
            # component consumes the deadline before those children are
            # attempted.  They are nevertheless exact live states and must
            # enter the registry; otherwise a certified continuation can be
            # present in CPF yet remain permanently unfindable by raw key.
            witness = event.get("witness") or {}
            residuals = witness.get("residuals") or []
            if isinstance(residuals, list):
                for residual in residuals:
                    if not isinstance(residual, dict):
                        continue
                    record(
                        identity,
                        residual.get("cpf"),
                        residual.get("problem_key"),
                    )
            # A successful exact transformation's explicit residual is an
            # authoritative causal child too.  Retain it even when that child
            # had some (ultimately inapplicable) guidance: otherwise a later
            # certified continuation can never be attached to the live state.
            # Generic transformations still require the old strict unguided
            # boundary below.
            atom = normalize_atom(
                event.get("strategy_atom") or event.get("processor")
            ) or ""
            atom_base = atom.split("(", 1)[0]
            reduction_pair_atom_bases = {
                "poly",
                "rat-poly",
                "quadratic-poly",
                "matrix",
                "arctic-matrix",
                "integer-arctic-matrix",
                "path-order",
                "kbo",
                "rpo",
                "exact-rat-natural-poly",
                "exact-rat-poly",
                "exact-poly",
                "exact-mono-poly",
                "exact-weak-poly",
                "exact-matrix",
                "exact-arctic",
                "exact-integer-matrix",
                "exact-path-order",
            }
            is_reduction_pair_atom = atom_base in reduction_pair_atom_bases
            encoded_child_core = (
                exact_transform_child_core(event)
                if reconstruct_encoded_children
                else None
            )
            encoded_graph_child_cores = (
                exact_graph_child_cores(event)
                if reconstruct_encoded_children
                else None
            )
            encoded_split_child_cores = (
                exact_split_child_cores(event)
                if reconstruct_encoded_children
                else None
            )
            is_exact_transform = atom.startswith(
                ("exact-dp(", "exact-dp-transform(", "exact-semantic-labeling(")
            ) and (encoded_child_core is not None or not reconstruct_encoded_children)
            parent_tag = parent_processor_tag(event)
            is_successful_exact_transform = (
                atom.startswith("exact-")
                and (parent_tag is not None or is_reduction_pair_atom)
                # The event outcome covers the processor *and its recursive
                # continuation*.  A valid exact transformation is therefore
                # reported as failed when its materialized residual has no
                # guidance yet.  An applicability failure has no residuals,
                # so requiring the explicit residual keeps this causal edge
                # source-validated without confusing the two cases.
                and event.get("outcome") in {"transformed", "failed"}
                and bool(residuals)
            )
            # These processors are deterministic state transformations.  A
            # successful event's explicit residual witness is therefore an
            # authoritative parent/child edge even though the human-readable
            # atom does not embed the child.  This is needed for CPF-local
            # contexts: the checked child records (for example)
            # ``innermostLhss``, while the live state additionally carries
            # pair provenance and cannot be matched by a contextless pool.
            is_successful_deterministic_transform = (
                atom
                in {
                    "usable-rules",
                    "innermost-lhss",
                    "uncurry",
                    "uncurry-below",
                    "switch-innermost",
                    "aaecc-innermost",
                    "switch-full-nontermination",
                }
                and parent_tag is not None
                and event.get("outcome") == "transformed"
                and bool(residuals)
            )
            is_unguided_transform = event.get("failure_reason") == (
                "strict oracle transformation produced an unguided residual"
            )
            if (
                not is_successful_exact_transform
                and not is_successful_deterministic_transform
                and not is_unguided_transform
            ):
                continue
            parent_tags = [parent_tag] if parent_tag is not None else []
            # Ferrum executes the checked U3 witness through the generic
            # `redPairUrProc` atom even when the enclosing certified CPF node
            # is the CSR-specific `csrRedPairUrProc`.  The wrappers have the
            # same concrete child after the exact atom has validated the live
            # QCS-DP obligation; only their checker entry-point names differ.
            # Index that one causal edge under both names so the next nested
            # certified processor remains independently findable.
            if parent_tag == "redPairUrProc":
                parent_tags.append("csrRedPairUrProc")
            if is_reduction_pair_atom:
                # The executable atom name identifies an order, while CPF
                # distinguishes the ordinary/monotone/usable-rule wrapper.
                # Register the exact observed child for each wrapper; only a
                # statically certified continuation with the same child core
                # can consume it, and the final CPF is checked independently.
                parent_tags = [
                    "redPairProc",
                    "monoRedPairProc",
                    "redPairUrProc",
                    "monoRedPairUrProc",
                    "innermostMonoRedPairProc",
                ]
            if not parent_tags:
                continue
            explicit_children = []
            parent_atom_fingerprint = exact_causal_atom_fingerprint(atom)
            adjacent_recursive_child: tuple[str, str] | None = None
            if (
                event.get("outcome") == "failed"
                and index > 0
                and len(residuals) == 1
            ):
                previous = events[index - 1]
                previous_atom = normalize_atom(
                    previous.get("strategy_atom") or previous.get("processor")
                )
                previous_input = previous.get("input") or {}
                previous_key = previous_input.get("problem_key")
                previous_cpf = previous_input.get("cpf")
                # Processor events are emitted on recursive return.  A strict
                # oracle miss immediately before its exact parent is thus the
                # concrete child that parent just invoked.  This is a stronger
                # bridge than guessing alpha-equivalence between Q contexts:
                # it is the recorded call edge itself.  Restrict it to the
                # unambiguous one-residual case and the explicit strict lookup
                # boundary.
                if (
                    identity_of(previous) == identity
                    and previous.get("outcome") == "failed"
                    and previous_atom == "utility-guidance"
                    and isinstance(previous_key, str)
                    and isinstance(previous_cpf, str)
                ):
                    adjacent_recursive_child = (previous_key, previous_cpf)
            elif (
                event.get("outcome") == "transformed"
                and index + 1 < len(events)
                and len(residuals) == 1
            ):
                following = events[index + 1]
                following_input = following.get("input") or {}
                following_key = following_input.get("problem_key")
                following_cpf = following_input.get("cpf")
                parent_key = event_input.get("problem_key")
                # Successful transformations are logged before entering the
                # continuation; failed recursive attempts are summarized on
                # return and use the previous-event case above.  The first
                # subsequent event on a different DP key is therefore the
                # concrete recursive child.
                if (
                    identity_of(following) == identity
                    and following.get("level") == event.get("level")
                    and isinstance(following_key, str)
                    and following_key != parent_key
                    and isinstance(following_cpf, str)
                ):
                    adjacent_recursive_child = (following_key, following_cpf)
            if isinstance(residuals, list):
                for residual_index, residual in enumerate(residuals):
                    if not isinstance(residual, dict):
                        continue
                    child_cpf = residual.get("cpf")
                    child_key = residual.get("problem_key")
                    if not isinstance(child_cpf, str) or not isinstance(child_key, str):
                        continue
                    child_signature, _ = cached_signatures(child_cpf, child_key)
                    child_core = contextless_runtime_state_signature(
                        child_cpf, child_signature
                    )
                    if child_signature is None or child_core is None:
                        continue
                    # The exact processor validates a source-to-live symbol
                    # isomorphism before it materializes this residual.  Its
                    # encoded archived child can therefore have a different
                    # raw core from the translated live child.  Index the
                    # causal edge by the archived core that the next static
                    # CPF row carries, while retaining the live full context
                    # and raw key as its only target.
                    # Graph and split atoms encode several distinct children.
                    # Their component-specific cores must take precedence over
                    # the generic single-child exact-transform core.  Treating
                    # every `exact-graph` as a generic exact transformation
                    # indexed its child under the whole archived graph input,
                    # so the recursive component could never find its own
                    # continuation (Ex16_Luc06_C and Ex1_GM99_C).
                    lookup_core = (
                        encoded_graph_child_cores[residual_index]
                        if encoded_graph_child_cores is not None
                        and residual_index < len(encoded_graph_child_cores)
                        else (
                            encoded_split_child_cores[residual_index]
                            if encoded_split_child_cores is not None
                            and residual_index < len(encoded_split_child_cores)
                            else (
                                encoded_child_core
                                if encoded_child_core is not None
                                else child_core
                            )
                        )
                    )
                    # The processor's explicit residual and the state passed
                    # to its recursive continuation can have different raw
                    # hashes after harmless parser standardization.  Once
                    # their *complete* semantic signatures agree (including
                    # R, P, Q, strategy, minimality, and Ferrum's typed
                    # context), both hashes are exact aliases of this causal
                    # child.  Do not use contextless or subset matching here.
                    equivalent_child_keys = runtime_keys.get(
                        (identity, child_signature), {child_key}
                    )
                    if adjacent_recursive_child is not None:
                        adjacent_key, adjacent_cpf = adjacent_recursive_child
                        # The execution edge establishes identity even when
                        # the recursive serializer standardized presentation
                        # variables and consequently changed the raw hash.
                        # Retain the complete recursive input under its own
                        # key; no context fields are erased or synthesized.
                        runtime_inputs.setdefault(adjacent_key, adjacent_cpf)
                        # Prefer the state actually passed to the recursive
                        # continuation.  The explicit witness residual is a
                        # pre-recursion serialization and can differ in
                        # semantically relevant Q bookkeeping; advertising
                        # both let guidance select the pre-recursion form and
                        # yielded a CPF that CeTA correctly rejected.  The
                        # witness key is still recorded as a registry state,
                        # but it is not the target of this causal edge.
                        equivalent_child_keys = {adjacent_key}
                    for tag in parent_tags:
                        causal_parent_tag_children.setdefault(
                            (identity, tag), set()
                        ).update(equivalent_child_keys)
                        causal_child_contexts.setdefault(
                            (identity, tag, lookup_core), {}
                        ).setdefault(child_signature, set()).update(
                            equivalent_child_keys
                        )
                        parent_raw_key = event_input.get("problem_key")
                        if (
                            (
                                is_successful_exact_transform
                                or is_successful_deterministic_transform
                                or is_reduction_pair_atom
                                or adjacent_recursive_child is not None
                            )
                            and isinstance(parent_raw_key, str)
                        ):
                            runtime_keys.setdefault(
                                (
                                    CAUSAL_PARENT_RAW_PREFIX
                                    + tag
                                    + "\0"
                                    + identity,
                                    parent_raw_key,
                                ),
                                set(),
                            ).update(equivalent_child_keys)
                        # Deterministic transformations can choose fresh
                        # presentation names or preserve newer typed context
                        # that is absent from an archived CPF child.  The
                        # exact parent obligation plus processor tag is still
                        # a complete causal key for the one live child.
                        parent_cpf = event_input.get("cpf")
                        if isinstance(parent_cpf, str):
                            parent_signature, _ = cached_signatures(
                                parent_cpf,
                                event_input.get("problem_key")
                                if isinstance(event_input.get("problem_key"), str)
                                else None,
                            )
                            parent_core = contextless_runtime_state_signature(
                                parent_cpf, parent_signature
                            )
                            if parent_core is not None:
                                runtime_keys.setdefault(
                                    (
                                        CAUSAL_PARENT_CONTEXT_PREFIX
                                        + tag
                                        + "\0"
                                        + identity,
                                        parent_core,
                                    ),
                                    set(),
                                ).update(equivalent_child_keys)
                    if parent_atom_fingerprint is not None:
                        # A retained reduction pair can relocate an entire
                        # semantically labeled signature.  Its live child then
                        # has a different contextless core from the archived
                        # continuation, even though this exact, source-bound
                        # processor atom is the same causal edge.  Index the
                        # one explicit residual by the certified parent atom
                        # as well; the child row reconstructs that atom from
                        # its causal-parent metadata below.
                        runtime_keys.setdefault(
                            (
                                CAUSAL_PARENT_ATOM_PREFIX + identity,
                                parent_atom_fingerprint
                                + f":branch:{residual_index}",
                            ),
                            set(),
                        ).update(equivalent_child_keys)
                    explicit_children.extend(sorted(equivalent_child_keys))
            # New event logs carry the processor's own residuals.  They are
            # authoritative and avoid confusing a sibling's adjacent lookup
            # with this transformation's child in multi-component proofs.
            if explicit_children:
                continue
            if index == 0:
                continue
            child_event = events[index - 1]
            child_atom = normalize_atom(
                child_event.get("strategy_atom") or child_event.get("processor")
            )
            empty_lookup = (
                child_event.get("outcome") == "failed"
                and child_atom == "utility-guidance"
                and int((child_event.get("metrics") or {}).get("parsed_candidates") or 0)
                == 0
            )
            if (
                "utility lookup miss" not in str(child_event.get("error") or "")
                and not empty_lookup
            ) or identity_of(child_event) != identity:
                continue
            child_input = child_event.get("input") or {}
            child_cpf = child_input.get("cpf")
            child_key = child_input.get("problem_key")
            if not isinstance(child_cpf, str) or not isinstance(child_key, str):
                continue
            child_signature, _ = cached_signatures(child_cpf, child_key)
            child_core = contextless_runtime_state_signature(child_cpf, child_signature)
            if child_signature is None or child_core is None:
                continue
            encoded_child_core = exact_transform_child_core(event)
            if encoded_child_core is not None and encoded_child_core != child_core:
                continue
            if encoded_child_core is not None:
                exact_child_contexts.setdefault(
                    (identity, child_core), {}
                ).setdefault(child_signature, set()).add(child_key)
            for tag in parent_tags:
                causal_child_contexts.setdefault(
                    (identity, tag, child_core), {}
                ).setdefault(child_signature, set()).add(child_key)
    # A contextless archived CPF state may name a current state only if its
    # semantic core has exactly one observed full context.  Multiple raw keys
    # for that one context are harmless formatting/canonical aliases; two
    # distinct full signatures are an ambiguity and deliberately create no
    # bridge.
    for (identity, core_signature), by_full_signature in context_candidates.items():
        # Some executable exact atoms carry their complete witness and
        # revalidate it against the live R/P/Q obligation.  For those atoms,
        # pair-source provenance is reconstruction metadata rather than an
        # applicability condition.  Retain every full context here; the
        # consumer below opts into this bridge only for those guarded atom
        # families.  Non-exact and heuristic guidance never sees it.
        runtime_keys[
            (PORTABLE_EXACT_CONTEXT_PREFIX + identity, core_signature)
        ] = {
            key
            for keys in by_full_signature.values()
            for key in keys
        }
        causal = exact_child_contexts.get((identity, core_signature), {})
        if causal:
            runtime_keys[
                (EXACT_CHILD_CONTEXT_PREFIX + identity, core_signature)
            ] = {
                key
                for keys in causal.values()
                for key in keys
            }
        if len(by_full_signature) == 1:
            keys = next(iter(by_full_signature.values()))
        else:
            if len(causal) != 1:
                continue
            causal_signature, keys = next(iter(causal.items()))
            if causal_signature not in by_full_signature:
                continue
        runtime_keys[
            (LEGACY_UNIQUE_CONTEXT_PREFIX + identity, core_signature)
        ] = set(keys)
    for (identity, parent_tag, core_signature), by_full_signature in (
        causal_child_contexts.items()
    ):
        runtime_keys[
            (
                CAUSAL_CHILD_CONTEXT_PREFIX + parent_tag + "\0" + identity,
                core_signature,
            )
        ] = {
            key
            for keys in by_full_signature.values()
            for key in keys
        }
    for (identity, parent_tag), keys in causal_parent_tag_children.items():
        if len(keys) == 1:
            runtime_keys[
                (
                    CAUSAL_UNIQUE_PARENT_TAG_PREFIX + parent_tag + "\0" + identity,
                    "",
                )
            ] = set(keys)
    return runtime_keys, runtime_dp_states, runtime_inputs


def runtime_event_paths(roots: list[Path]) -> list[Path]:
    paths: set[Path] = set()
    for root in roots:
        if root.is_file():
            paths.add(root)
            continue
        for pattern in (
            "processor-events.jsonl",
            "events.jsonl",
            "*.processor-events.jsonl",
            "*.events.jsonl",
        ):
            paths.update(root.rglob(pattern))
    return sorted(paths)


def runtime_event_path_matches_problems(
    event_path: Path, problem_ids: set[str]
) -> bool:
    """Cheaply discard runtime traces for proofs absent from this shard.

    Reading a processor-event file is not cheap: a single timeout trace can be
    hundreds of MiB and contain very large serialized residuals.  Proof
    selection (including the large-proof bound) is already complete before
    runtime aliases are loaded, so path-local TermCOMP runs can be filtered
    without parsing their event streams.  Unknown/flattened layouts are kept
    conservatively rather than risking loss of a valid alias.
    """

    normalized = event_path.as_posix().replace("\\", "/")
    known_layout = any(
        marker in normalized
        for marker in ("/TRS_Standard/", "/TRS_Innermost/", "/SRS_Standard/")
    )
    for problem_id in problem_ids:
        # Details manifests use ../TPDB-ARI/... whereas artifact directories
        # begin at the category. Normalize both through the same benchmark
        # identity convention before applying this read-avoidance filter.
        stem = problem_identity(problem_id)
        if stem.endswith(".ari"):
            stem = stem[:-4]
        runtime_stems = {stem, stem.replace("#", "sharp_")}
        if any(f"/{candidate}/" in normalized for candidate in runtime_stems):
            return True
    return not known_layout


def adjacent_event_file(proof_path: Path) -> Path | None:
    """Locate nested or flattened processor events beside a proof artifact."""
    candidates = [
        proof_path.with_name("processor-events.jsonl"),
        proof_path.with_name("events.jsonl"),
    ]
    for suffix in (".cpf3.xml", ".cpf.xml", ".cpf", ".xml"):
        if proof_path.name.endswith(suffix):
            stem = proof_path.name.removesuffix(suffix)
            candidates.extend(
                (
                    proof_path.with_name(stem + ".processor-events.jsonl"),
                    proof_path.with_name(stem + ".events.jsonl"),
                )
            )
            break
    return next((candidate for candidate in candidates if candidate.exists()), None)


def read_runtime_root_keys(event_paths: list[Path]) -> dict[str, set[str]]:
    """Index live top-level roots by benchmark identity.

    A root has no hidden processor context, so identity is the exact safe
    fallback when CPF3/CPF4 wrapper spelling prevents structural matching.
    Nested states never use this alias.
    """
    roots: dict[str, set[str]] = {}
    for event_path in event_paths:
        recorded_identities: set[str] = set()
        for line in event_path.read_text(encoding="utf-8", errors="replace").splitlines():
            try:
                event = json.loads(line)
            except json.JSONDecodeError:
                continue
            if event.get("level") != "top-level":
                continue
            key = (event.get("input") or {}).get("problem_key")
            if isinstance(key, str):
                identity = problem_identity(event.get("problem_id"))
                category = str(event.get("category") or "")
                if category.startswith(("TRS_", "SRS_")) and not identity.startswith(
                    ("TRS_", "SRS_")
                ):
                    identity = f"{category}/{identity.lstrip('/')}"
                # Processor logs are ordered.  Later top-level events in the
                # same file are residual states, not aliases of the original
                # benchmark root.  Treating all of them as roots broadcasts a
                # root processor onto unrelated children that happen to occur
                # in another certified proof.
                if identity in recorded_identities:
                    continue
                recorded_identities.add(identity)
                roots.setdefault(identity, set()).add(key)
    return roots


def attach_runtime_state_keys(
    rows: list[dict],
    proof_path: Path,
    problem_id: str,
    external_runtime_keys: dict[tuple[str, str], set[str]] | None = None,
    external_runtime_dp_states: list[
        tuple[str, str, frozenset[str], str]
    ] | None = None,
    external_runtime_root_keys: dict[str, set[str]] | None = None,
    allow_portable_ambiguous_aliases: bool = True,
    category_hint: str | None = None,
    include_adjacent_event: bool = True,
) -> None:
    """Alias certified CPF states to their exact producing runtime hashes."""
    event_path = adjacent_event_file(proof_path)
    # The global runtime index can contain hundreds of thousands of entries.
    # It is immutable during attachment, so do not duplicate the entire map
    # for every certified proof.
    external_keys = external_runtime_keys or {}
    runtime_keys = external_keys
    if event_path is not None and include_adjacent_event:
        runtime_keys = {
            signature: set(keys) for signature, keys in external_keys.items()
        }
        local_keys, _, _ = read_runtime_state_aliases([event_path])
        for signature, keys in local_keys.items():
            runtime_keys.setdefault(signature, set()).update(keys)
    additional_rows: list[dict] = []
    def alias_row_identity(row: dict) -> str:
        row_id = row.get("id")
        if isinstance(row_id, str):
            return row_id
        metadata = row.get("metadata", {})
        return json.dumps(
            [metadata.get("path") or [], metadata.get("processor_tag")],
            ensure_ascii=False,
            separators=(",", ":"),
        )

    attached_row_aliases = {
        (alias_row_identity(row), alias)
        for row in rows
        for alias in [row.get("metadata", {}).get("runtime_raw_problem_key")]
        if isinstance(alias, str)
    }
    identity = proof_problem_identity(proof_path, problem_id, category_hint)
    equivalent_identities = equivalent_runtime_identities(identity)
    signature_cache: dict[str, str | None] = {}
    core_signature_cache: dict[str, str | None] = {}

    def cached_runtime_signature(cpf: str) -> str | None:
        if cpf not in signature_cache:
            signature_cache[cpf] = runtime_state_signature(cpf)
        return signature_cache[cpf]

    def cached_core_signature(
        cpf: str, signature: str | None = None
    ) -> str | None:
        if cpf not in core_signature_cache:
            core_signature_cache[cpf] = contextless_runtime_state_signature(
                cpf, signature
            )
        return core_signature_cache[cpf]

    causal_child_aliases_by_core: dict[str, set[str]] | None = None

    def causal_child_aliases(core_signature: str) -> set[str]:
        nonlocal causal_child_aliases_by_core
        if causal_child_aliases_by_core is None:
            causal_child_aliases_by_core = {}
            suffixes = tuple("\0" + value for value in equivalent_identities)
            for (runtime_identity, runtime_core), keys in external_keys.items():
                if (
                    runtime_identity.startswith(CAUSAL_CHILD_CONTEXT_PREFIX)
                    and runtime_identity.endswith(suffixes)
                ):
                    causal_child_aliases_by_core.setdefault(
                        runtime_core, set()
                    ).update(keys)
        return set(causal_child_aliases_by_core.get(core_signature, set()))
    parent_tag_counts: Counter[str] = Counter()
    for candidate_row in rows:
        candidate_path = candidate_row["metadata"].get("path") or []
        if (
            len(candidate_path) >= 3
            and candidate_path[-2]
            in {
                "dpProof",
                "csrDpProof",
                "mutermTypedDpProof",
                "trsTerminationProof",
                "trsNonterminationProof",
                "dpNonterminationProof",
            }
        ):
            tag = candidate_path[-3]
            if tag == "component" and len(candidate_path) >= 4:
                tag = candidate_path[-4]
            parent_tag_counts[str(tag)] += 1
    for row in list(rows):
        path = row["metadata"].get("path") or []
        cpf = unwrap_input(str(row["input"]["problem_xml"]))
        signature = cached_runtime_signature(cpf) if cpf is not None else None
        immediate_parent_tag = (
            path[-3]
            if (
            len(path) >= 3
                and path[-2]
                in {
                    "dpProof",
                    "csrDpProof",
                    "mutermTypedDpProof",
                    "trsTerminationProof",
                    "trsNonterminationProof",
                    "dpNonterminationProof",
                }
            )
            else None
        )
        # Graph and split processors wrap each recursive proof in a
        # non-processor ``component`` element.  The continuation's causal
        # parent is the processor outside that wrapper, not ``component``.
        # Misclassifying it leaves every independently materialized SCC
        # without its first certified processor.
        if immediate_parent_tag == "component" and len(path) >= 4:
            immediate_parent_tag = path[-4]
        causal_parent_tag = row["metadata"].get("causal_parent_processor_tag")
        if causal_parent_tag == "component" and immediate_parent_tag is not None:
            # `component` is only the CPF container chosen by depGraphProc;
            # the runtime edge is recorded under the graph processor itself.
            # Keep the branch index, but use the executable parent tag for
            # exact parent-key lookup.
            causal_parent_tag = immediate_parent_tag
        if causal_parent_tag == "semlabProc":
            parent_input = row["metadata"].get("causal_parent_input_xml")
            parent_output = row["metadata"].get("causal_parent_output_xml")
            if isinstance(parent_input, str) and isinstance(parent_output, str):
                parent_atom = strategy_atom(
                    {
                        "metadata": {"processor_tag": causal_parent_tag},
                        "input": {
                            "problem_xml": parent_input,
                            "local_context_xml": row["metadata"].get(
                                "causal_parent_local_context_xml"
                            ),
                            "lookup_tables_xml": row["metadata"].get(
                                "causal_parent_lookup_tables_xml"
                            ),
                        },
                        "output_xml": parent_output,
                    }
                )
                if isinstance(parent_atom, str) and parent_atom.startswith(
                    "exact-semantic-labeling("
                ):
                    immediate_parent_tag = exact_semantic_model_discriminator(parent_atom)
                    # Runtime records semantic-labeling edges under this
                    # model discriminator, not the coarse CPF wrapper name.
                    # Use the same tag for the stronger parent-raw lookup
                    # below. Otherwise a semantically labeled child whose
                    # active usable-rule context is smaller than CPF's
                    # displayed transformed TRS cannot inherit its exact live
                    # key, even though the one-residual execution edge and
                    # model are both recorded.
                    causal_parent_tag = immediate_parent_tag
        candidate = strategy_atom(row)
        aliases: set[str] = set()
        causal_parent_raw_keys = row["metadata"].get(
            "causal_parent_runtime_raw_problem_keys"
        )
        if not isinstance(causal_parent_raw_keys, list):
            singular_parent_raw_key = row["metadata"].get(
                "causal_parent_runtime_raw_problem_key"
            )
            causal_parent_raw_keys = (
                [singular_parent_raw_key]
                if isinstance(singular_parent_raw_key, str)
                else []
            )
        causal_parent_branch_index = row["metadata"].get(
            "causal_parent_branch_index"
        )
        if (
            causal_parent_tag is not None
            and causal_parent_raw_keys
            and not isinstance(causal_parent_branch_index, int)
        ):
            # A multi-residual processor's parent key and coarse tag identify
            # all siblings, not this continuation.  Prefer the exact
            # parent-atom fingerprint plus branch index below.  Using the
            # broad key first cross-attached every depGraphProc SCC and made
            # strict replay explore their Cartesian product.
            aliases = {
                key
                for causal_parent_raw_key in causal_parent_raw_keys
                if isinstance(causal_parent_raw_key, str)
                for equivalent in equivalent_identities
                for key in external_keys.get(
                    (
                        CAUSAL_PARENT_RAW_PREFIX
                        + str(causal_parent_tag)
                        + "\0"
                        + equivalent,
                        causal_parent_raw_key,
                    ),
                    set(),
                )
            }
        if not aliases and causal_parent_tag is not None:
            parent_input = row["metadata"].get("causal_parent_input_xml")
            parent_output = row["metadata"].get("causal_parent_output_xml")
            parent_atom = row["metadata"].get("causal_parent_strategy_atom")
            if not isinstance(parent_atom, str) and isinstance(
                parent_input, str
            ) and isinstance(parent_output, str):
                parent_atom = strategy_atom(
                    {
                        "metadata": {"processor_tag": causal_parent_tag},
                        "input": {
                            "problem_xml": parent_input,
                            "local_context_xml": row["metadata"].get(
                                "causal_parent_local_context_xml"
                            ),
                            "lookup_tables_xml": row["metadata"].get(
                                "causal_parent_lookup_tables_xml"
                            ),
                        },
                        "output_xml": parent_output,
                    }
                )
            if isinstance(parent_atom, str):
                fingerprint = exact_causal_atom_fingerprint(parent_atom)
                if fingerprint is not None:
                    branch_index = causal_parent_branch_index
                    if isinstance(branch_index, int):
                        fingerprint += f":branch:{branch_index}"
                    aliases = {
                        key
                        for equivalent in equivalent_identities
                        for key in external_keys.get(
                            (
                                CAUSAL_PARENT_ATOM_PREFIX + equivalent,
                                fingerprint,
                            ),
                            set(),
                        )
                    }
        if not aliases and immediate_parent_tag is not None and cpf is not None:
            core_signature = cached_core_signature(cpf, signature)
            aliases = {
                key
                for equivalent in equivalent_identities
                for key in external_keys.get(
                    (
                        CAUSAL_CHILD_CONTEXT_PREFIX
                        + str(immediate_parent_tag)
                        + "\0"
                        + equivalent,
                        core_signature or "",
                    ),
                    set(),
                )
            }
        if not aliases and immediate_parent_tag is not None:
            causal_parent_input = row["metadata"].get("causal_parent_input_xml")
            if isinstance(causal_parent_input, str):
                parent_core = cached_core_signature(
                    unwrap_input(causal_parent_input) or causal_parent_input
                )
                aliases = {
                    key
                    for equivalent in equivalent_identities
                    for key in external_keys.get(
                        (
                            CAUSAL_PARENT_CONTEXT_PREFIX
                            + str(immediate_parent_tag)
                            + "\0"
                            + equivalent,
                            parent_core or "",
                        ),
                        set(),
                    )
                }
        if (
            not aliases
            and immediate_parent_tag is not None
            and parent_tag_counts[str(immediate_parent_tag)] == 1
        ):
            aliases = {
                key
                for equivalent in equivalent_identities
                for key in external_keys.get(
                    (
                        CAUSAL_UNIQUE_PARENT_TAG_PREFIX
                        + str(immediate_parent_tag)
                        + "\0"
                        + equivalent,
                        "",
                    ),
                    set(),
                )
            }
        if not aliases:
            aliases = {
                key
                for equivalent in equivalent_identities
                for key in external_keys.get((equivalent, signature or ""), set())
            }
        if not aliases and cpf is not None:
            core_signature = cached_core_signature(cpf, signature)
            aliases = {
                key
                for equivalent in equivalent_identities
                for key in external_keys.get(
                    (
                        EXACT_CHILD_CONTEXT_PREFIX + equivalent,
                        core_signature or "",
                    ),
                    set(),
                )
            }
        if (
            not aliases
            and allow_portable_ambiguous_aliases
            and cpf is not None
            and isinstance(candidate, str)
            and (
                candidate == "switch-full-nontermination"
                or candidate.startswith(
                    (
                        "exact-graph(",
                        "exact-dp-transform(",
                        "exact-dp-no-rule-removal(",
                        "exact-dp-proof(",
                        "exact-trs-proof(",
                        "exact-trs-nontermination-proof(",
                        "exact-usable-rules(",
                        "exact-innermost-lhss(",
                        "exact-red-pair(",
                        "exact-general-red-pair(",
                    )
                )
            )
        ):
            core_signature = cached_core_signature(cpf, signature)
            aliases = {
                key
                for equivalent in equivalent_identities
                for key in external_keys.get(
                    (
                        PORTABLE_EXACT_CONTEXT_PREFIX + equivalent,
                        core_signature or "",
                    ),
                    set(),
                )
            }
        # Some accepted CPF processors (notably generalRedPairProc variants)
        # are retained from the adjacent run as exact certified runtime atoms
        # because the static CPF walker cannot yet reconstruct their complete
        # witness.  These rows used to be appended after this aliasing pass,
        # which made their otherwise exact continuations unreachable whenever
        # the live child carried newer Ferrum-only context.  A runtime atom has
        # already been checked as part of this very proof, so it may inherit a
        # live key only when that key was causally observed as a transformation
        # child with the same contextless semantic core.
        if (
            not aliases
            and cpf is not None
            and path == ["certifiedRuntimeAtom"]
        ):
            core_signature = cached_core_signature(cpf, signature)
            if core_signature is not None:
                aliases = causal_child_aliases(core_signature)
        guarded_exact_partial_context = (
            isinstance(candidate, str)
            and candidate.startswith(("exact-graph(", "exact-red-pair("))
        )
        if (
            not aliases
            and cpf is not None
            and (
                not has_dp_state_context(cpf)
                or guarded_exact_partial_context
            )
        ):
            core_signature = cached_core_signature(cpf, signature)
            # A current campaign's causality-proved live child is stronger
            # than the archived proof's adjacent, contextless instrumentation
            # key.  Consult the external registry first so merging the local
            # legacy key cannot turn one precise bridge into two aliases.
            aliases = {
                key
                for equivalent in equivalent_identities
                for key in external_keys.get(
                    (
                        LEGACY_UNIQUE_CONTEXT_PREFIX + equivalent,
                        core_signature or "",
                    ),
                    set(),
                )
            }
            if not aliases:
                aliases = {
                    key
                    for equivalent in equivalent_identities
                    for key in runtime_keys.get(
                        (
                            LEGACY_UNIQUE_CONTEXT_PREFIX + equivalent,
                            core_signature or "",
                        ),
                        set(),
                    )
                }
        # Prefer a uniqueness- or causality-proved semantic-context bridge to
        # an observed contextless instrumentation key.  The latter commonly
        # comes from a failed oracle candidate and is not the typed child that
        # the exact transformation actually materialized.
        if not aliases:
            aliases = {
                key
                for equivalent in equivalent_identities
                for key in runtime_keys.get((equivalent, signature or ""), set())
            }
        if not aliases and len(path) <= 3:
            aliases = set((external_runtime_root_keys or {}).get(identity, set()))
        # Nested states are deliberately never matched by pair-set inclusion
        # or equality.  R, Q, minimality, replacement maps, and construction
        # provenance are proof obligations and therefore part of the state.
        # If the complete canonical signature does not match, the producer or
        # serializer must be fixed instead of borrowing advice from a merely
        # similar DP problem.
        existing_alias = row["metadata"].get("runtime_raw_problem_key")
        row_identity = alias_row_identity(row)
        if isinstance(existing_alias, str) and existing_alias in aliases:
            ordered_aliases = sorted(aliases - {existing_alias})
            for alias in ordered_aliases:
                if (row_identity, alias) in attached_row_aliases:
                    continue
                duplicate = copy.deepcopy(row)
                duplicate["metadata"]["runtime_raw_problem_key"] = alias
                additional_rows.append(duplicate)
                attached_row_aliases.add((row_identity, alias))
        elif len(aliases) == 1:
            row["metadata"]["runtime_raw_problem_key"] = next(iter(aliases))
            attached_row_aliases.add(
                (row_identity, row["metadata"]["runtime_raw_problem_key"])
            )
        elif aliases:
            ordered_aliases = sorted(aliases)
            row["metadata"]["runtime_raw_problem_key"] = ordered_aliases[0]
            attached_row_aliases.add((row_identity, ordered_aliases[0]))
            for alias in ordered_aliases[1:]:
                if (row_identity, alias) in attached_row_aliases:
                    continue
                duplicate = copy.deepcopy(row)
                duplicate["metadata"]["runtime_raw_problem_key"] = alias
                additional_rows.append(duplicate)
                attached_row_aliases.add((row_identity, alias))
    rows.extend(additional_rows)


def rebind_rows_to_runtime_inputs(
    rows: list[dict], runtime_inputs: dict[str, str]
) -> None:
    """Materialize structurally matched proof rows on their exact live state.

    A runtime alias is more than an alternate hash.  Archived CPF commonly
    spells numeric-leading symbols without TPDB's bars, while an exact atom
    validates its source rules using Ferrum's live spelling.  Keeping the
    archived input and merely attaching ``runtime_raw_problem_key`` therefore
    makes a sound witness unexecutable.  Rebind only rows whose structural
    signature selected one concrete live key, and rewrite only numeric aliases
    that are present in that live obligation.
    """
    for row in rows:
        key = row.get("metadata", {}).get("runtime_raw_problem_key")
        live = runtime_inputs.get(key) if isinstance(key, str) else None
        if not isinstance(live, str):
            continue
        row["output_xml"] = align_fragment_numeric_symbols(
            str(row["output_xml"]), live
        )
        # `dpTrans` is frozen before rebinding so its certified child flags
        # (in particular innermost `nfs`) cannot be inherited from the live
        # top-level wrapper.  Numeric TPDB aliases are representation-only,
        # however, and the exact processor compares its source TRS against
        # the live spelling.  Align just those aliases inside the frozen
        # witness while preserving the certified child state verbatim.
        atom = row.get("metadata", {}).get("strategy_atom")
        if isinstance(atom, str) and atom.startswith("exact-dp(hex="):
            try:
                encoded = atom.removeprefix("exact-dp(hex=").removesuffix(")")
                child = json.loads(bytes.fromhex(encoded))
                aligned_child = align_fragment_numeric_symbols(child, live)
                aligned = json.dumps(
                    aligned_child, ensure_ascii=False, separators=(",", ":")
                ).encode("utf-8").hex()
                row["metadata"]["strategy_atom"] = f"exact-dp(hex={aligned})"
            except (ValueError, json.JSONDecodeError, UnicodeDecodeError):
                pass
        if isinstance(atom, str) and atom.startswith("exact-graph(hex="):
            try:
                encoded = atom.removeprefix("exact-graph(hex=").removesuffix(")")
                source_xml, components = json.loads(bytes.fromhex(encoded))
                aligned_source = align_fragment_numeric_symbols(source_xml, live)
                source_root = ET.fromstring(aligned_source)
                live_root = ET.fromstring(unwrap_input(live) or live)
                source_strategy = next(
                    (
                        child
                        for child in source_root
                        if local_name(child.tag) == "strategy"
                    ),
                    None,
                )
                live_strategy = next(
                    (
                        child
                        for child in live_root
                        if local_name(child.tag) == "strategy"
                    ),
                    None,
                )
                if source_strategy is None and live_strategy is not None:
                    insert_at = next(
                        (
                            index + 1
                            for index, child in enumerate(list(source_root))
                            if local_name(child.tag) == "dps"
                        ),
                        len(list(source_root)),
                    )
                    source_root.insert(insert_at, copy.deepcopy(live_strategy))
                    aligned_source = ET.tostring(
                        source_root,
                        encoding="unicode",
                        short_empty_elements=True,
                    )
                aligned = json.dumps(
                    [aligned_source, components],
                    ensure_ascii=False,
                    separators=(",", ":"),
                ).encode("utf-8").hex()
                row["metadata"]["strategy_atom"] = f"exact-graph(hex={aligned})"
            except (
                ValueError,
                TypeError,
                json.JSONDecodeError,
                UnicodeDecodeError,
            ):
                pass
        # Keep an exact graph's archived source and component indices
        # together.  A portable alias can legitimately select a live state
        # whose pair order differs from the archived CPF.  Replacing only the
        # source XML while retaining the old indices silently selects another
        # SCC.  Ferrum's exact graph processor already validates the complete
        # archived R/P obligation and maps the indices through the recovered
        # signature/pair isomorphism; use that sound boundary directly.
        row["input"]["problem_xml"] = live
        row["metadata"]["runtime_input_rebound"] = True


def bind_rebound_causal_parent_atoms(rows: list[dict]) -> None:
    """Attach each child to its now-live exact parent atom by proof path."""
    atoms_by_id: dict[str, str] = {}
    atoms_by_path: dict[tuple[str, ...], set[str]] = {}
    raw_keys_by_id: dict[str, set[str]] = {}
    raw_keys_by_path: dict[tuple[str, ...], set[str]] = {}
    for row in rows:
        path = tuple(str(part) for part in (row.get("metadata", {}).get("path") or []))
        atom = strategy_atom(row)
        if path and isinstance(atom, str):
            # Runtime aliases duplicate a certified row while retaining the
            # same proof path and exact executable atom.  That is not an
            # ambiguous causal parent.  Count distinct atoms, not duplicate
            # alias rows; genuinely different witnesses on one path still
            # refuse the fallback below.
            atoms_by_path.setdefault(path, set()).add(atom)
            row_id = row.get("id")
            if isinstance(row_id, str):
                atoms_by_id[row_id] = atom
        raw_key = row.get("metadata", {}).get("runtime_raw_problem_key")
        if path and isinstance(raw_key, str):
            raw_keys_by_path.setdefault(path, set()).add(raw_key)
            row_id = row.get("id")
            if isinstance(row_id, str):
                raw_keys_by_id.setdefault(row_id, set()).add(raw_key)
    for row in rows:
        metadata = row.get("metadata", {})
        path = tuple(str(part) for part in (metadata.get("path") or []))
        if len(path) < 3 or path[-2] not in {
            "dpProof",
            "csrDpProof",
            "mutermTypedDpProof",
            "trsTerminationProof",
        }:
            continue
        atom = atoms_by_id.get(str(metadata.get("causal_parent_row_id") or ""))
        raw_keys = set(
            raw_keys_by_id.get(
                str(metadata.get("causal_parent_row_id") or ""), set()
            )
        )
        if atom is None:
            # Graph/split continuations insert a non-processor ``component``
            # wrapper between the parent processor and the recursive
            # ``dpProof``.  Strip that wrapper as well when recovering the
            # exact parent path.  The old ``path[:-2]`` stopped at
            # ``component`` and therefore could never bind a graph child when
            # the archived row id differed after context materialization.
            parent_path = path[:-3] if path[-3] == "component" else path[:-2]
            path_atoms = atoms_by_path.get(parent_path, [])
            atom = next(iter(path_atoms)) if len(path_atoms) == 1 else None
            raw_keys.update(raw_keys_by_path.get(parent_path, set()))
        if isinstance(atom, str) and exact_causal_atom_fingerprint(atom) is not None:
            metadata["causal_parent_strategy_atom"] = atom
        if raw_keys:
            metadata["causal_parent_runtime_raw_problem_keys"] = sorted(raw_keys)
            if len(raw_keys) == 1:
                metadata["causal_parent_runtime_raw_problem_key"] = next(
                    iter(raw_keys)
                )


def exact_graph_is_identity_wrapper(atom: str | None) -> bool:
    """Whether an exact graph has one open component equal to its full input.

    Such a CPF node is a structural wrapper around its recursive proof, not a
    state transformation.  Advertising it as an oracle action creates the
    cycle ``S -> S`` and hides the first real processor below the component.
    """
    if not isinstance(atom, str):
        return False
    match = re.fullmatch(r"exact-graph\(hex=([0-9a-fA-F]+)\)", atom)
    if match is None:
        return False
    try:
        source_xml, components = json.loads(bytes.fromhex(match.group(1)))
        source = ET.fromstring(source_xml)
    except (ValueError, TypeError, json.JSONDecodeError, UnicodeDecodeError, ET.ParseError):
        return False
    if (
        not isinstance(components, list)
        or len(components) != 1
        or not isinstance(components[0], list)
        or len(components[0]) != 2
        or components[0][1] is not True
        or not isinstance(components[0][0], list)
    ):
        return False
    dps = first_child(source, "dps")
    rules = first_child(dps, "rules") if dps is not None else None
    if rules is None:
        return False
    pair_count = sum(
        local_name(child.tag) in {"rule", "ruleIndex"} for child in rules
    )
    indices = components[0][0]
    return (
        pair_count > 0
        and all(isinstance(index, int) for index in indices)
        and set(indices) == set(range(pair_count))
        and len(indices) == pair_count
    )


def flatten_identity_graph_wrappers(rows: list[dict]) -> int:
    """Bind a no-op graph's recursive processor directly to the same state.

    Dependency-graph CPF permits a single full cyclic component with a nested
    proof.  Mathematically that child is the identical DP problem.  Preserve
    the graph in the final reconstructed proof through the child's causal CPF
    path, but do not offer it as a recursive oracle action.  Instead copy each
    exact live alias of the wrapper to its immediate continuation.
    """
    graph_aliases: dict[str, set[str]] = {}
    graph_path_aliases: dict[tuple[str, ...], set[str]] = {}
    for row in rows:
        metadata = row.get("metadata", {})
        if metadata.get("processor_tag") != "depGraphProc":
            continue
        atom = strategy_atom(row)
        if not exact_graph_is_identity_wrapper(atom):
            continue
        metadata["identity_graph_wrapper"] = True
        row_id = row.get("id")
        key = metadata.get("runtime_raw_problem_key")
        if isinstance(row_id, str) and isinstance(key, str):
            graph_aliases.setdefault(row_id, set()).add(key)
        path = tuple(str(part) for part in (metadata.get("path") or []))
        if path and isinstance(key, str):
            graph_path_aliases.setdefault(path, set()).add(key)
    if not graph_aliases and not graph_path_aliases:
        return 0
    existing = {
        (
            str(row.get("id") or ""),
            row.get("metadata", {}).get("runtime_raw_problem_key"),
        )
        for row in rows
    }
    additions: list[dict] = []
    for row in list(rows):
        metadata = row.get("metadata", {})
        parent_id = metadata.get("causal_parent_row_id")
        path = tuple(str(part) for part in (metadata.get("path") or []))
        aliases = graph_aliases.get(str(parent_id))
        if not aliases and len(path) >= 3 and path[-3:-1] == ("component", "dpProof"):
            aliases = graph_path_aliases.get(path[:-3])
        if not aliases:
            continue
        row_id = str(row.get("id") or "")
        for alias in sorted(aliases):
            if (row_id, alias) in existing:
                continue
            duplicate = copy.deepcopy(row)
            duplicate["metadata"]["runtime_raw_problem_key"] = alias
            duplicate["metadata"]["identity_graph_parent_flattened"] = True
            additions.append(duplicate)
            existing.add((row_id, alias))
    rows.extend(additions)
    return len(additions)


def freeze_portable_atoms_before_runtime_rebind(rows: list[dict]) -> None:
    """Encode portable witnesses while CPF source/component spellings agree.

    An exact graph atom carries its complete source DP state and Ferrum maps
    that state to the live signature when the atom executes.  If extraction
    first replaces the row input with a renamed live residual, however, the
    archived CPF component rules no longer match syntactically and the atom
    encoder discards the otherwise portable witness.  Freeze only processor
    families whose runtime implementation explicitly performs this guarded
    source-state isomorphism.
    """
    portable_processors = {
        "dpTrans",
        "dpRuleRemoval",
        "depGraphProc",
        "splitProc",
        "narrowingProc",
        "instantiationProc",
        "forwardInstantiationProc",
        "csrForwardInstantiationProc",
        "rewritingProc",
        "rewriteProc",
        "redPairProc",
        "redPairUrProc",
        "monoRedPairProc",
        "monoRedPairUrProc",
        "innermostMonoRedPairProc",
        "innermostLhssRemovalProc",
    }
    children_by_parent: dict[str, list[dict]] = {}
    for child in rows:
        parent_id = child.get("metadata", {}).get("causal_parent_row_id")
        if isinstance(parent_id, str):
            children_by_parent.setdefault(parent_id, []).append(child)
    for row in rows:
        metadata = row.get("metadata", {})
        processor_tag = metadata.get("processor_tag")
        if processor_tag == "ruleRemoval":
            atom = strategy_atom(row)
            if atom and atom.startswith(("exact-path-order-removal(", "exact-trs-no-rule-removal(")):
                metadata["strategy_atom"] = atom
            continue
        if processor_tag not in portable_processors:
            continue
        existing = metadata.get("strategy_atom")
        if processor_tag == "dpRuleRemoval":
            # For CPF nontermination proofs the recursive child is the
            # authoritative retained subproblem.  Reconstructing it again
            # from a detached legacy node can interpret its `<dps>` payload
            # using the opposite CPF2/CPF3 convention, producing an apparent
            # no-op.  Pin the exact atom to the unique child already recovered
            # by the twice-certified proof traversal.  Runtime still checks
            # that this child is a literal P/R subproblem before recursing.
            children = children_by_parent.get(str(row.get("id") or ""), [])
            atom = strategy_atom(row)
            if atom is not None and atom.startswith("exact-dp-no-rule-removal("):
                if len(children) == 1:
                    source_xml = str(row["input"]["problem_xml"])
                    residual_xml = str(children[0]["input"]["problem_xml"])
                    encoded = json.dumps(
                        [source_xml, residual_xml],
                        ensure_ascii=False,
                        separators=(",", ":"),
                    ).encode("utf-8").hex()
                    metadata["strategy_atom"] = (
                        f"exact-dp-no-rule-removal(hex={encoded})"
                    )
                elif existing is not None:
                    metadata["strategy_atom"] = existing
            continue
        if processor_tag in {
            "narrowingProc",
            "instantiationProc",
            "forwardInstantiationProc",
            "csrForwardInstantiationProc",
            "rewritingProc",
            "rewriteProc",
        }:
            # Exact DP transformations embed the certified step payload and
            # its complete child obligation.  Their runtime implementation
            # reconstructs the step against the live state under a checked
            # signature/rule isomorphism.  Encode that witness while the CPF
            # source and payload still share their archived spelling; after a
            # causal rebind, trying to synthesize it again can fail and used
            # to downgrade the checked continuation to an unrelated generic
            # narrowing/instantiation search (the Length innermost loop).
            metadata.pop("strategy_atom", None)
            atom = strategy_atom(row)
            if atom is not None and atom.startswith(
                ("exact-dp-transform(", "exact-dp-no-rule-removal(")
            ):
                metadata["strategy_atom"] = atom
            elif existing is not None:
                metadata["strategy_atom"] = existing
            continue
        if processor_tag == "splitProc":
            # Like exact graph, exact split embeds the complete archived
            # R/P obligation and the selected occurrence.  Ferrum validates
            # a full rule/pair isomorphism before translating that occurrence
            # to the live state.  Encode it before replacing the archived
            # input with the causally observed residual: the residual may use
            # different presentation names, and recomputing the selected
            # index from that spelling can then fail even though the retained
            # exact witness is portable.
            metadata.pop("strategy_atom", None)
            atom = strategy_atom(row)
            if atom is not None and atom.startswith("exact-split("):
                metadata["strategy_atom"] = atom
            elif existing is not None:
                metadata["strategy_atom"] = existing
            continue
        if processor_tag == "innermostLhssRemovalProc":
            metadata.pop("strategy_atom", None)
            atom = strategy_atom(row)
            if atom is not None and atom.startswith(("exact-innermost-lhss(", "exact-dp-transform(")):
                metadata["strategy_atom"] = atom
            elif existing is not None:
                metadata["strategy_atom"] = existing
            continue
        model_discriminator = existing
        if processor_tag not in {"dpTrans", "depGraphProc"} and not (
            isinstance(model_discriminator, str)
            and model_discriminator.startswith("exact-")
        ):
            # Before replacing a model-only red-pair spelling with the
            # self-contained portable atom, recover the exact model from the
            # certified CPF node itself.  Most structural rows do not yet
            # have a cached strategy_atom at this point.
            model_discriminator = strategy_atom(row)
        if (
            processor_tag
            in {
                "redPairProc",
                "redPairUrProc",
                "monoRedPairProc",
                "monoRedPairUrProc",
                "innermostMonoRedPairProc",
            }
            and (
                not isinstance(model_discriminator, str)
                or model_discriminator.startswith("exact-red-pair(")
            )
        ):
            # ``strategy_atom`` upgrades these CPF nodes directly to their
            # portable, source-bound representation.  Recover the affine
            # model separately so the adjacent producing event can identify
            # the live pre-bridge state without weakening the replay atom.
            witness = linear_polynomial_witness(str(row.get("output_xml", "")))
            if witness is not None:
                encoded = json.dumps(
                    witness, ensure_ascii=False, separators=(",", ":")
                ).encode("utf-8").hex()
                weak_affine = any(int(entry[1]) < 0 for entry in witness)
                model_discriminator = (
                    f"exact-weak-poly(hex={encoded})"
                    if weak_affine
                    else f"exact-poly(hex={encoded})"
                )
        # A generic runtime spelling such as ``graph`` is only a search
        # request: it recomputes Ferrum's current graph and may legitimately
        # disagree with the decomposition retained in the certified CPF.
        # Preserve an atom here only when it already carries the complete
        # exact witness.  Otherwise upgrade the certified depGraphProc while
        # its archived source/component spellings still agree.
        if (
            processor_tag == "dpTrans"
            and isinstance(existing, str)
            and existing.startswith("exact-dp(")
        ):
            continue
        if (
            processor_tag == "depGraphProc"
            and isinstance(existing, str)
            and existing.startswith("exact-graph(")
        ):
            continue
        if processor_tag in {"dpTrans", "depGraphProc"}:
            # Let ``strategy_atom`` inspect the certified component payload;
            # otherwise its normal explicit-atom fast path would simply hand
            # the generic ``dp``/``graph`` hint back to us.  Exact DP is
            # essential for historical certified proofs whose valid DP set
            # differs from Ferrum's current conservative construction; the
            # runtime processor validates the complete live source TRS and
            # CeTA validates the selected transformation in the final CPF.
            metadata.pop("strategy_atom", None)
        # ``iter_exact_rows`` may already have assigned a model-only
        # ``exact-poly`` spelling to a CPF red-pair node.  Recompute from the
        # still-archived input before runtime rebinding so the atom retains
        # its wrapper plus complete source P/R obligation.
        if processor_tag not in {"dpTrans", "depGraphProc"}:
            metadata.pop("strategy_atom", None)
            if isinstance(model_discriminator, str) and model_discriminator.startswith(
                (
                    "exact-rat-natural-poly(",
                    "exact-rat-poly(",
                    "exact-poly(",
                    "exact-mono-poly(",
                    "exact-weak-poly(",
                    "exact-matrix(",
                    "exact-arctic(",
                    "exact-integer-matrix(",
                    "exact-path-order(",
                )
            ):
                # Keep the model spelling as a causal discriminator.  The
                # portable exact-red-pair atom produced below is the replay
                # action, but this model identifies the precise live state
                # on which the certified implementation produced it.
                metadata["portable_model_atom"] = model_discriminator
        atom = strategy_atom(row)
        if processor_tag == "dpTrans":
            if atom is not None and atom.startswith("exact-dp("):
                metadata["strategy_atom"] = atom
            continue
        if (
            processor_tag != "depGraphProc"
            and (atom is None or not atom.startswith("exact-red-pair("))
        ):
            if existing is not None:
                metadata["strategy_atom"] = existing
            continue
        if atom is not None:
            metadata["strategy_atom"] = atom
        elif existing is not None:
            metadata["strategy_atom"] = existing


def bind_runtime_exact_reduction_atoms(
    rows: list[dict], proof_path: Path, problem_id: str
) -> None:
    """Bind a certified reduction-pair node to its producing exact atom.

    CPF records the interpretation and the residual pairs, but a typed CSR
    proof may place that same ``redPairProc`` below a verified usable-rule
    wrapper.  Re-encoding it as the generic ``exact-red-pair`` atom loses that
    wrapper choice.  The adjacent successful event records the exact atomic
    interpretation actually used at the already structurally matched live
    state.  Bind only unique, witness-carrying exact atoms; ambiguous events
    remain unmodified weak guidance.
    """
    event_path = adjacent_event_file(proof_path)
    if event_path is None:
        return
    identity = proof_problem_identity(proof_path, problem_id)
    event_identities = {identity}
    if not identity.startswith(("TRS_", "SRS_")):
        event_identities.update(
            f"{category}/{identity.lstrip('/')}"
            for category in (
                "TRS_Standard",
                "TRS_Innermost",
                "TRS_Contextsensitive",
                "SRS_Standard",
            )
        )
    exact_by_key: dict[str, set[str]] = {}
    key_inputs: dict[str, str] = {}
    wanted_model_atoms = {
        atom
        for row in rows
        for atom in [row.get("metadata", {}).get("portable_model_atom")]
        if isinstance(atom, str)
    }
    allowed_prefixes = (
        "exact-rat-natural-poly(",
        "exact-rat-poly(",
        "exact-poly(",
        "exact-mono-poly(",
        "exact-weak-poly(",
        "exact-matrix(",
        "exact-arctic(",
        "exact-integer-matrix(",
        "exact-path-order(",
    )
    events: list[dict] = []
    for line in event_path.read_text(encoding="utf-8", errors="replace").splitlines():
        try:
            event = json.loads(line)
        except json.JSONDecodeError:
            continue
        events.append(event)
    wanted_model_keys = {
        str((event.get("input") or {}).get("problem_key"))
        for event in events
        if normalize_atom(event.get("strategy_atom") or event.get("processor"))
        in wanted_model_atoms
        and isinstance((event.get("input") or {}).get("problem_key"), str)
    }
    for event in events:
        event_input = event.get("input") or {}
        key = event_input.get("problem_key")
        hydrate_content_addressed_probe_input(event)
        cpf = event_input.get("cpf")
        if key in wanted_model_keys and isinstance(cpf, str):
            key_inputs.setdefault(key, cpf)
        for residual in ((event.get("witness") or {}).get("residuals") or []):
            if not isinstance(residual, dict):
                continue
            residual_key = residual.get("problem_key")
            residual_cpf = residual.get("cpf")
            if residual_key in wanted_model_keys and isinstance(residual_cpf, str):
                key_inputs.setdefault(residual_key, residual_cpf)
    exact_by_model_core: dict[tuple[str, str], set[str]] = {}
    for event in events:
        event_identity = problem_identity(event.get("problem_id"))
        category = str(event.get("category") or "")
        if category.startswith(("TRS_", "SRS_")) and not event_identity.startswith(
            ("TRS_", "SRS_")
        ):
            event_identity = f"{category}/{event_identity.lstrip('/')}"
        key = (event.get("input") or {}).get("problem_key")
        atom = normalize_atom(event.get("strategy_atom") or event.get("processor"))
        if (
            event_identity in event_identities
            and event.get("outcome") in {"solved", "transformed"}
            and isinstance(key, str)
            and isinstance(atom, str)
            and atom.startswith(allowed_prefixes)
            and not any(marker in atom for marker in (";", "parallel(", "choice("))
        ):
            exact_by_key.setdefault(key, set()).add(atom)
            if atom in wanted_model_atoms:
                live_cpf = key_inputs.get(key)
                core = (
                    reduction_pair_obligation_signature(live_cpf)
                    if isinstance(live_cpf, str)
                    else None
                )
                if core is not None:
                    exact_by_model_core.setdefault((atom, core), set()).add(key)
    for row in rows:
        if row.get("metadata", {}).get("processor_tag") not in {
            "redPairProc",
            "redPairUrProc",
            "monoRedPairProc",
            "monoRedPairUrProc",
            "innermostMonoRedPairProc",
        }:
            continue
        if not isinstance(row["metadata"].get("runtime_raw_problem_key"), str):
            model_atom = row["metadata"].get("portable_model_atom")
            archived = unwrap_input(str(row.get("input", {}).get("problem_xml", "")))
            core = (
                reduction_pair_obligation_signature(archived)
                if isinstance(archived, str)
                else None
            )
            model_keys = (
                exact_by_model_core.get((model_atom, core), set())
                if isinstance(model_atom, str) and core is not None
                else set()
            )
            if len(model_keys) == 1:
                row["metadata"]["runtime_raw_problem_key"] = next(iter(model_keys))
                row["metadata"]["runtime_model_state_bound"] = True
        generated_atom = strategy_atom(row)
        if generated_atom is not None and generated_atom.startswith(
            "exact-red-pair("
        ):
            try:
                encoded = generated_atom.split("hex=", 1)[1][:-1]
                decoded = json.loads(bytes.fromhex(encoded))
            except (ValueError, json.JSONDecodeError, UnicodeDecodeError):
                decoded = None
            if isinstance(decoded, list) and len(decoded) == 5:
                # The self-contained CPF atom records the full source Q/R
                # state and is therefore safer than a historical
                # implementation-specific model atom.
                continue
        key = row["metadata"].get("runtime_raw_problem_key")
        atoms = exact_by_key.get(key, set()) if isinstance(key, str) else set()
        if len(atoms) == 1:
            row["metadata"]["strategy_atom"] = next(iter(atoms))
            row["metadata"]["runtime_exact_atom_bound"] = True


def bind_runtime_exact_graph_atoms(
    rows: list[dict], proof_path: Path, problem_id: str
) -> None:
    """Bind a certified graph node to the exact successful live decomposition.

    CPF graph components are sets of dependency pairs.  When equal pairs occur
    more than once, the proof walker and the live prover may assign different
    numeric indices to the same component.  Replaying the walker's indices on
    the live ordering is then inapplicable even though the checked graph step
    is identical.  Replace it only when the adjacent, successful runtime atom
    is unique at the already matched raw state and has the same cyclic-child
    cardinalities.  The exact state key supplies the stronger source guard.
    """
    event_path = adjacent_event_file(proof_path)
    if event_path is None:
        return
    identity = proof_problem_identity(proof_path, problem_id)
    event_identities = {identity}
    if not identity.startswith(("TRS_", "SRS_")):
        event_identities.update(
            f"{category}/{identity.lstrip('/')}"
            for category in (
                "TRS_Standard",
                "TRS_Innermost",
                "TRS_Contextsensitive",
                "SRS_Standard",
            )
        )
    exact_by_key: dict[str, set[str]] = {}
    for line in event_path.read_text(encoding="utf-8", errors="replace").splitlines():
        try:
            event = json.loads(line)
        except json.JSONDecodeError:
            continue
        event_identity = problem_identity(event.get("problem_id"))
        category = str(event.get("category") or "")
        if category.startswith(("TRS_", "SRS_")) and not event_identity.startswith(
            ("TRS_", "SRS_")
        ):
            event_identity = f"{category}/{event_identity.lstrip('/')}"
        key = (event.get("input") or {}).get("problem_key")
        atom = normalize_atom(event.get("strategy_atom") or event.get("processor"))
        if (
            event_identity in event_identities
            and event.get("outcome") in {"solved", "transformed"}
            and isinstance(key, str)
            and isinstance(atom, str)
            and atom.startswith("exact-graph(")
        ):
            exact_by_key.setdefault(key, set()).add(atom)
    for row in rows:
        if row.get("metadata", {}).get("processor_tag") != "depGraphProc":
            continue
        key = row.get("metadata", {}).get("runtime_raw_problem_key")
        generated = strategy_atom(row)
        if not isinstance(key, str) or not isinstance(generated, str):
            continue
        live_atoms = exact_by_key.get(key, set())
        compatible = {
            atom
            for atom in live_atoms
            if exact_graph_cyclic_shape(atom) == exact_graph_cyclic_shape(generated)
        }
        if len(compatible) == 1:
            row["metadata"]["strategy_atom"] = next(iter(compatible))
            row["metadata"]["runtime_exact_graph_atom_bound"] = True


def certified_runtime_atom_rows(proof_path: Path, problem_id: str) -> list[dict]:
    """Recover live atomic state/action pairs adjacent to a certified CPF.

    Some extension checkers (notably ``csrGmTransformation``) recompute their
    transformed TRS and therefore do not serialize that child system in CPF.
    The successful Ferrum processor events beside the twice-certified proof
    are the only exact representation of those nested runtime states.  We
    retain only independently executable atoms and never copy their witness.
    Every atom is re-run and revalidated by Ferrum during replay.
    """
    event_path = adjacent_event_file(proof_path)
    if event_path is None:
        return []
    proof_root = load_xml(str(proof_path), None)
    proof_node = next(
        (element for element in proof_root if local_name(element.tag) == "proof"),
        None,
    )

    def contains_dp_loop(element: ET.Element | None, below_dp: bool = False) -> bool:
        """Whether the checked CPF ends in a loop for a DP obligation."""
        if element is None:
            return False
        tag = local_name(element.tag)
        below_dp = below_dp or tag in {"dpTrans", "dpNonterminationProof"}
        if tag == "loop" and below_dp:
            return True
        return any(contains_dp_loop(child, below_dp) for child in element)

    certified_terminal_dp_loop = contains_dp_loop(proof_node)
    explicit_csr_dp = (
        explicit_csr_dp_atom_from_proof(proof_node)
        if proof_node is not None
        else None
    )
    # Run-local problem ids commonly omit the TermCOMP category (for example
    # ``Transformed_CSR_04/Foo.ari``), while live events qualify them as
    # ``TRS_Standard/Transformed_CSR_04/Foo.ari``.  Use the same proof-path
    # qualification as structural alias attachment; otherwise every nested
    # successful runtime atom is silently discarded even when its event sits
    # beside the twice-certified proof.
    identity = proof_problem_identity(proof_path, problem_id)
    # A proof collected into a flat, category-less artifact directory may
    # retain only ``Suite/Example.ari`` in result metadata, while its adjacent
    # live events use ``TRS_Innermost/Suite/Example.ari``.  The event file is
    # already local to this twice-certified proof, so admitting precisely one
    # leading TermCOMP category is an identity qualification, not a
    # cross-benchmark alias.  Do not use an unrestricted suffix comparison:
    # that would also conflate nested benchmark paths.
    event_identities = {identity}
    if not identity.startswith(("TRS_", "SRS_")):
        event_identities.update(
            f"{category}/{identity.lstrip('/')}"
            for category in (
                "TRS_Standard",
                "TRS_Innermost",
                "TRS_Contextsensitive",
                "SRS_Standard",
            )
        )
    recovered: list[dict] = []
    seen: set[tuple[str, str]] = set()
    events: list[dict] = []
    for line in event_path.read_text(encoding="utf-8", errors="replace").splitlines():
        try:
            events.append(json.loads(line))
        except json.JSONDecodeError:
            continue
    # Nested successful events omit the bulky CPF after the first event for a
    # state.  Recover it by that exact problem key.  Falling back merely by
    # processor level would attach a successful atom to an unrelated sibling
    # residual and is therefore pool-only weak guidance.
    key_inputs: dict[str, str] = {}
    level_inputs: dict[str, str] = {}
    for event in events:
        hydrate_content_addressed_probe_input(event)
        cpf = (event.get("input") or {}).get("cpf")
        key = (event.get("input") or {}).get("problem_key")
        level = event.get("level")
        if isinstance(cpf, str) and isinstance(key, str):
            key_inputs.setdefault(key, cpf)
        if isinstance(cpf, str) and isinstance(level, str):
            level_inputs.setdefault(level, cpf)
        # Content-addressed event streams serialize a transformed child once
        # in the producing event's residual witness.  All subsequent trials
        # carry only that child's problem key.  The registry reader above
        # already materializes these residuals; do the same here so a
        # certified continuation is bound to its exact live state instead of
        # being downgraded to a level-wide pool hint.
        residuals = ((event.get("witness") or {}).get("residuals") or [])
        if isinstance(residuals, list):
            for residual in residuals:
                if not isinstance(residual, dict):
                    continue
                residual_cpf = residual.get("cpf")
                residual_key = residual.get("problem_key")
                if isinstance(residual_cpf, str) and isinstance(residual_key, str):
                    key_inputs.setdefault(residual_key, residual_cpf)

    # A successful DP-to-relative switch is search infrastructure, not a CPF
    # processor: CPF serializes the resulting loop directly below the DP
    # proof.  Consequently the relative child is intentionally not a
    # self-contained certified state.  When the adjacent run immediately
    # closes that switch by a relative loop and the complete checked CPF does
    # contain a terminal DP loop, bind the independently executable DP-loop
    # search to the *source DP state*.  Replay reruns and validates the loop;
    # no relative witness or whole proof is copied into the oracle.
    terminal_dp_loop_sources: set[str] = set()
    if certified_terminal_dp_loop:
        successful_indices = [
            index
            for index, event in enumerate(events)
            if event.get("outcome") in {"solved", "transformed"}
        ]
        for position, index in enumerate(successful_indices[:-1]):
            event = events[index]
            atom = normalize_atom(
                event.get("strategy_atom") or event.get("processor")
            )
            if atom != "switch-to-trs" or event.get("outcome") != "transformed":
                continue
            following = events[successful_indices[position + 1]]
            following_atom = normalize_atom(
                following.get("strategy_atom") or following.get("processor")
            )
            source_key = (event.get("input") or {}).get("problem_key")
            if (
                following.get("outcome") == "solved"
                and following_atom == "nontermination(bounded-rewriting)"
                and isinstance(source_key, str)
                and source_key in key_inputs
            ):
                terminal_dp_loop_sources.add(source_key)
    for event in events:
        event_identity = problem_identity(event.get("problem_id"))
        category = str(event.get("category") or "")
        if category.startswith(("TRS_", "SRS_")) and not event_identity.startswith(
            ("TRS_", "SRS_")
        ):
            event_identity = f"{category}/{event_identity.lstrip('/')}"
        if event_identity not in event_identities:
            continue
        if event.get("outcome") not in {"solved", "transformed"}:
            continue
        atom = normalize_atom(event.get("strategy_atom") or event.get("processor"))
        if atom == "dp" and explicit_csr_dp is not None:
            atom = explicit_csr_dp
        if isinstance(atom, str) and atom.startswith("csr-improved-dp("):
            atom = "csr-improved-dp"
        if isinstance(atom, str) and atom.startswith("csr-gm-transform("):
            atom = "csr-gm-transform"
        event_input = event.get("input") or {}
        cpf = event_input.get("cpf")
        key = event_input.get("problem_key")
        exact_cpf = isinstance(cpf, str)
        if not exact_cpf and isinstance(key, str):
            cpf = key_inputs.get(key)
            exact_cpf = isinstance(cpf, str)
        pool_only = not exact_cpf
        if pool_only:
            cpf = level_inputs.get(str(event.get("level") or ""))
        if (
            not isinstance(atom, str)
            or atom == "utility-guidance"
            or not isinstance(cpf, str)
            or not isinstance(key, str)
            or any(
                marker in atom
                for marker in (";", "parallel(", "choice(", "pipeline(", "csr(exhaust(")
            )
            or (key, atom) in seen
        ):
            continue
        try:
            inner = ET.fromstring(cpf)
        except ET.ParseError:
            continue
        certified_state_bridge = exact_cpf and (
            atom.startswith("exact-")
            or atom
            in {
                "empty",
                "graph",
                "size-change",
                "subterm",
                "usable-rules",
                "innermost-lhss",
                "uncurry-below",
            }
        )
        wrapper = ET.Element("input")
        wrapper.append(inner)
        seen.add((key, atom))
        recovered.append(
            {
                "metadata": {
                    "processor_tag": "certifiedRuntimeAtom",
                    "strategy_atom": atom,
                    "outcome": event["outcome"],
                    "runtime_raw_problem_key": key,
                    "runtime_residual_problem_keys": [
                        residual.get("problem_key")
                        for residual in ((event.get("witness") or {}).get("residuals") or [])
                        if isinstance(residual, dict)
                        and isinstance(residual.get("problem_key"), str)
                    ],
                    "runtime_atom_pool_only": pool_only,
                    # The atom came directly from this live event and its
                    # component indices belong to the source ordering encoded
                    # inside it.  Rebinding that source from a separately
                    # serialized CPF input can silently reindex duplicates.
                    "runtime_exact_graph_atom_bound": (
                        exact_cpf and atom.startswith("exact-graph(")
                    ),
                    # An exact live state plus a deterministic atomic
                    # processor is a faithful bridge to the corresponding
                    # node of this twice-checked complete proof.  Search/model
                    # atoms without an exact witness remain weak hints because
                    # a later implementation may choose a different model.
                    "runtime_atom_external_hint": not certified_state_bridge,
                    "runtime_atom_certified_source": certified_state_bridge,
                    "path": ["certifiedRuntimeAtom"],
                },
                "input": {"problem_xml": ET.tostring(wrapper, encoding="unicode")},
                "output_xml": "<certifiedRuntimeAtom />",
            }
        )
    for key in sorted(terminal_dp_loop_sources):
        atom = "nontermination(dp-loop)"
        if (key, atom) in seen:
            continue
        cpf = key_inputs[key]
        try:
            inner = ET.fromstring(cpf)
        except ET.ParseError:
            continue
        wrapper = ET.Element("input")
        wrapper.append(inner)
        recovered.append(
            {
                "metadata": {
                    "processor_tag": "certifiedRuntimeAtom",
                    "strategy_atom": atom,
                    "outcome": "solved",
                    "runtime_raw_problem_key": key,
                    "runtime_atom_pool_only": False,
                    "runtime_atom_external_hint": False,
                    "runtime_atom_certified_source": True,
                    "runtime_terminal_dp_loop_rebound": True,
                    "path": ["certifiedRuntimeAtom"],
                },
                "input": {"problem_xml": ET.tostring(wrapper, encoding="unicode")},
                "output_xml": "<certifiedRuntimeAtom />",
            }
        )
        seen.add((key, atom))
    return recovered


def discard_runtime_atoms_shadowed_by_local_context(
    proof_rows: list[dict], runtime_rows: list[dict]
) -> list[dict]:
    """Do not flatten a certified local-R boundary into its first atom.

    Historical event logs recorded the first reduction inside a
    localUsableRulesProc against the pre-wrapper state.  Offering a generic
    search hint there bypasses the wrapper and changes the checked weak-rule
    obligation.  A state-bound ``exact-*`` atom is different: Ferrum reruns
    that atom on the recorded input and exports both the local-usable-rules
    wrapper and its reduction pair.  Keep such an atom when it came from an
    exact live state beside the certified proof.  Model-only ``exact-*``
    atoms still do not encode which usable-rule wrapper the current runtime
    will emit.  Replaying such an atom after that policy changes can orient
    the same pairs but reconstruct a different, checker-rejected CPF.  When
    the certified CPF already exposes the local-usable-rules transition, keep
    that transition and its context-bound child reduction pair instead of
    the adjacent implementation-specific shortcut.
    """
    protected = {
        runtime_state_signature(unwrap_input(str(row["input"]["problem_xml"])))
        for row in proof_rows
        if row.get("metadata", {}).get("processor_tag") == "localUsableRulesProc"
    }
    protected.discard(None)
    structural_atoms = {
        atom
        for row in proof_rows
        if row.get("metadata", {}).get("processor_tag")
        != "certifiedRuntimeAtom"
        for atom in [strategy_atom(row)]
        if isinstance(atom, str)
    }
    structural_processor_tags = {
        str(row.get("metadata", {}).get("processor_tag") or "")
        for row in proof_rows
    }

    structural_red_pair_atoms = {
        atom for atom in structural_atoms if atom.startswith("exact-red-pair(")
    }
    structural_red_rows = {
        row.get("id"): row
        for row in proof_rows
        if row.get("metadata", {}).get("processor_tag")
        in {
            "redPairProc",
            "redPairUrProc",
            "monoRedPairProc",
            "monoRedPairUrProc",
            "innermostMonoRedPairProc",
        }
        and isinstance(row.get("id"), str)
    }
    structural_red_edges: dict[str, set[str]] = {}
    for child in proof_rows:
        parent_id = child.get("metadata", {}).get("causal_parent_row_id")
        child_key = child.get("metadata", {}).get("runtime_raw_problem_key")
        if parent_id in structural_red_rows and isinstance(child_key, str):
            structural_red_edges.setdefault(parent_id, set()).add(child_key)

    exact_model_prefixes = (
        "exact-rat-natural-poly(",
        "exact-rat-poly(",
        "exact-poly(",
        "exact-mono-poly(",
        "exact-weak-poly(",
        "exact-matrix(",
        "exact-arctic(",
        "exact-integer-matrix(",
        "exact-path-order(",
    )
    matched_structural_red_ids: set[str] = set()
    for runtime_row in runtime_rows:
        metadata = runtime_row.get("metadata", {})
        atom = normalize_atom(metadata.get("strategy_atom"))
        parent_key = metadata.get("runtime_raw_problem_key")
        residual_keys = set(metadata.get("runtime_residual_problem_keys") or [])
        if (
            not isinstance(atom, str)
            or not atom.startswith(exact_model_prefixes)
            or not isinstance(parent_key, str)
            or not residual_keys
        ):
            continue
        for row_id, structural_row in structural_red_rows.items():
            if (
                structural_row.get("metadata", {}).get("runtime_raw_problem_key")
                == parent_key
                and residual_keys.intersection(structural_red_edges.get(row_id, set()))
            ):
                # This is not merely a successful model from a backtracked
                # branch: its exact source and exact residual are the edge
                # reconstructed from the checked CPF.  Prefer the live atom,
                # because it preserves the implementation's typed active-R
                # transition without reverse-engineering that private state
                # from presentation-oriented CPF payloads.
                metadata["runtime_matches_structural_red_pair"] = True
                matched_structural_red_ids.add(row_id)
                break
    structural_bounds_rows = {
        row.get("id"): row
        for row in proof_rows
        if row.get("metadata", {}).get("processor_tag") == "relativeBounds"
        and isinstance(row.get("id"), str)
    }
    structural_bounds_edges: dict[str, set[str]] = {}
    for child in proof_rows:
        parent_id = child.get("metadata", {}).get("causal_parent_row_id")
        child_key = child.get("metadata", {}).get("runtime_raw_problem_key")
        if parent_id in structural_bounds_rows and isinstance(child_key, str):
            structural_bounds_edges.setdefault(parent_id, set()).add(child_key)
    matched_structural_bounds_ids: set[str] = set()
    for runtime_row in runtime_rows:
        metadata = runtime_row.get("metadata", {})
        atom = normalize_atom(metadata.get("strategy_atom"))
        parent_key = metadata.get("runtime_raw_problem_key")
        residual_keys = set(metadata.get("runtime_residual_problem_keys") or [])
        if (
            not isinstance(atom, str)
            or not atom.startswith("relative-match-bounds(")
            or not isinstance(parent_key, str)
            or not residual_keys
        ):
            continue
        for row_id, structural_row in structural_bounds_rows.items():
            if (
                structural_row.get("metadata", {}).get("runtime_raw_problem_key")
                == parent_key
                and residual_keys.intersection(
                    structural_bounds_edges.get(row_id, set())
                )
            ):
                # The exact live search edge is the relativeBounds node in
                # this checked proof.  Retain the executable bounded search
                # recipe when reverse-parsing its automaton into an exact
                # atom would otherwise lose implementation-side state.
                metadata["runtime_matches_structural_bounds"] = True
                metadata["runtime_atom_certified_source"] = True
                metadata["runtime_atom_external_hint"] = False
                matched_structural_bounds_ids.add(row_id)
                break

    # Prefer the exact atom emitted by the live prover when it names the same
    # source -> residual edge as a transformation in the checked CPF.  The
    # presentation-oriented CPF parser may serialize an equivalent boundary
    # with different whitespace or may include the recursive continuation in
    # its exact payload.  Literal atom comparison then loses the independently
    # replayable live boundary.  Matching both endpoint keys prevents a
    # successful atom from a backtracked branch from acquiring certification.
    structural_transition_tags = {
        "dpRuleRemoval": ("exact-dp-no-rule-removal(",),
        "narrowingProc": ("exact-dp-transform(",),
        "instantiationProc": ("exact-dp-transform(", "alpha-merge"),
        "forwardInstantiationProc": ("exact-dp-transform(",),
        "rewriteProc": ("exact-dp-transform(",),
    }
    # Runtime alias attachment deliberately gives one CPF row several live
    # serializations. Do not collapse those variants by their shared row id.
    structural_transition_rows = [
        (row.get("id"), row)
        for row in proof_rows
        if row.get("metadata", {}).get("processor_tag")
        in structural_transition_tags
        and isinstance(row.get("id"), str)
    ]
    structural_transition_ids = {row_id for row_id, _ in structural_transition_rows}
    structural_transition_edges: dict[str, set[str]] = {}
    for child in proof_rows:
        parent_id = child.get("metadata", {}).get("causal_parent_row_id")
        child_key = child.get("metadata", {}).get("runtime_raw_problem_key")
        if parent_id in structural_transition_ids and isinstance(child_key, str):
            structural_transition_edges.setdefault(parent_id, set()).add(child_key)
    matched_structural_transition_ids: set[str] = set()
    for runtime_row in runtime_rows:
        metadata = runtime_row.get("metadata", {})
        atom = normalize_atom(metadata.get("strategy_atom"))
        parent_key = metadata.get("runtime_raw_problem_key")
        residual_keys = set(metadata.get("runtime_residual_problem_keys") or [])
        if not isinstance(atom, str) or not isinstance(parent_key, str):
            continue
        for row_id, structural_row in structural_transition_rows:
            tag = structural_row.get("metadata", {}).get("processor_tag")
            prefixes = structural_transition_tags[str(tag)]
            if (
                (atom == "alpha-merge" if atom.startswith("alpha-merge") else atom.startswith(prefixes))
                and (atom != "alpha-merge" or tag == "instantiationProc")
                and structural_row.get("metadata", {}).get(
                    "runtime_raw_problem_key"
                )
                == parent_key
                and residual_keys.intersection(
                    structural_transition_edges.get(row_id, set())
                )
            ):
                metadata["runtime_matches_structural_transition"] = True
                metadata["runtime_atom_certified_source"] = True
                metadata["runtime_atom_external_hint"] = False
                matched_structural_transition_ids.add(row_id)
                break

    # Terminal DP loops have no child endpoint.  Their exact live source key,
    # exact witness atom, and the loop node at that same checked CPF state are
    # sufficient to identify the proof-path node.
    structural_loop_rows = {
        row.get("id"): row
        for row in proof_rows
        if row.get("metadata", {}).get("processor_tag") == "loop"
        and isinstance(row.get("id"), str)
    }
    structural_loop_keys = {
        row.get("metadata", {}).get("runtime_raw_problem_key")
        for row in structural_loop_rows.values()
    }
    matched_structural_loop_ids: set[str] = set()
    for runtime_row in runtime_rows:
        metadata = runtime_row.get("metadata", {})
        atom = normalize_atom(metadata.get("strategy_atom"))
        if (
            isinstance(atom, str)
            and atom.startswith("exact-dp-loop(")
            and metadata.get("runtime_raw_problem_key") in structural_loop_keys
        ):
            metadata["runtime_matches_structural_transition"] = True
            metadata["runtime_atom_certified_source"] = True
            metadata["runtime_atom_external_hint"] = False
            matched_structural_loop_ids.update(
                row_id
                for row_id, row in structural_loop_rows.items()
                if row.get("metadata", {}).get("runtime_raw_problem_key")
                == metadata.get("runtime_raw_problem_key")
            )

    def occurs_in_certified_proof(atom: str) -> bool:
        """Whether a live atom has a structural counterpart in the CPF.

        Runtime logs contain successful attempts from branches which the
        prover later backtracked over.  Certification of the final CPF does
        not certify that those attempts belong to its proof path.  Exact
        structural atoms sometimes refine a generic runtime spelling, so
        compare those processor families explicitly while retaining literal
        matching for model-bearing atoms.
        """
        if atom in structural_atoms:
            return True
        # Empty DP/TRS obligations are explicit terminal proof nodes, not
        # processor atoms, so ``strategy_atom`` intentionally returns no
        # advice for them.  The adjacent successful runtime event is still
        # the independently executable action required to close the child
        # materialized by the preceding exact transformation.  Without this
        # bridge proof-chain-only extraction drops every such terminal child.
        if atom == "empty" and structural_processor_tags.intersection(
            {"pIsEmpty", "rIsEmpty", "sIsEmpty"}
        ):
            return True
        if atom == "uncurry-below" and "uncurryProc" in structural_processor_tags:
            return True
        if atom.startswith("exact-graph(") and any(
            structural.startswith("exact-graph(")
            and exact_graph_same_step(atom, structural)
            for structural in structural_atoms
        ):
            return True
        if atom.startswith("exact-red-pair(") and any(
            exact_red_pair_same_step(atom, structural)
            for structural in structural_red_pair_atoms
        ):
            return True
        refinements = {
            "graph": "exact-graph(",
            "size-change": "exact-size-change(",
            "subterm": "exact-subterm(",
            "usable-rules": "exact-usable-rules(",
            "innermost-lhss": "exact-innermost-lhss(",
        }
        prefix = refinements.get(atom)
        return prefix is not None and any(
            structural.startswith(prefix) for structural in structural_atoms
        )
    has_structural_reduction_pair = any(
        row.get("metadata", {}).get("processor_tag")
        in {
            "redPairProc",
            "redPairUrProc",
            "monoRedPairProc",
            "monoRedPairUrProc",
            "innermostMonoRedPairProc",
        }
        for row in proof_rows
    )
    model_prefixes = (
        *exact_model_prefixes,
        "exact-red-pair(",
    )
    retained: list[dict] = []
    for row in runtime_rows:
        atom = normalize_atom(row.get("metadata", {}).get("strategy_atom"))
        if (
            has_structural_reduction_pair
            and isinstance(atom, str)
            and atom.startswith(model_prefixes)
            and not row.get("metadata", {}).get(
                "runtime_matches_structural_red_pair"
            )
            and not row.get("metadata", {}).get(
                "runtime_matches_structural_bounds"
            )
            and not (
                atom.startswith("exact-red-pair(")
                and any(
                    exact_red_pair_same_step(atom, structural)
                    for structural in structural_red_pair_atoms
                )
            )
        ):
            # A model atom re-runs the current implementation's wrapper
            # selection.  The certified CPF's explicit red-pair node is the
            # direct replay boundary and carries the source P/R context.
            continue
        if (
            row.get("metadata", {}).get("processor_tag")
            == "certifiedRuntimeAtom"
            and row.get("metadata", {}).get("runtime_atom_certified_source")
            and isinstance(atom, str)
            and not occurs_in_certified_proof(atom)
            and not row.get("metadata", {}).get(
                "runtime_matches_structural_red_pair"
            )
            and not row.get("metadata", {}).get(
                "runtime_matches_structural_bounds"
            )
            and not row.get("metadata", {}).get(
                "runtime_matches_structural_transition"
            )
        ):
            # A successful atomic attempt beside a certified proof may have
            # been abandoned.  Preserve it as exploration guidance, but do
            # not let certification of a different final CPF promote it into
            # the monotone preferred path.
            row = copy.deepcopy(row)
            row["metadata"]["runtime_atom_certified_source"] = False
            row["metadata"]["runtime_atom_external_hint"] = True
        signature = runtime_state_signature(
            unwrap_input(str(row.get("input", {}).get("problem_xml", "")))
        )
        if signature not in protected:
            retained.append(row)
    matched_structural_ids = (
        matched_structural_red_ids
        | matched_structural_bounds_ids
        | matched_structural_transition_ids
        | matched_structural_loop_ids
    )
    if matched_structural_ids:
        proof_rows[:] = [
            row for row in proof_rows if row.get("id") not in matched_structural_ids
        ]
    return retained


def certified_runtime_root_recipe_row(
    proof_path: Path,
    problem_id: str,
    runtime_root_key: str | None,
) -> dict | None:
    """Recover the complete producing root recipe beside a certified proof.

    Recursive CPF extraction still indexes every child processor under its
    own state.  The complete root recipe is retained as well: it is the only
    self-contained fallback when processor evolution changes an intermediate
    serialization or exposes a residual for which no live alias was recorded.
    The row is emitted only from a successful runtime event adjacent to a
    complete CPF which passed the caller's certification gate.
    """
    if runtime_root_key is None:
        return None
    event_path = adjacent_event_file(proof_path)
    if event_path is None:
        return None
    selected: tuple[str, str] | None = None
    for line in event_path.read_text(encoding="utf-8", errors="replace").splitlines():
        try:
            event = json.loads(line)
        except json.JSONDecodeError:
            continue
        event_input = event.get("input") or {}
        candidate = event.get("strategy_atom") or event.get("processor")
        normalized_candidate = (
            normalize_atom(candidate) if isinstance(candidate, str) else None
        )
        cpf = event_input.get("cpf")
        if (
            event_input.get("problem_key") != runtime_root_key
            or event.get("outcome") != "solved"
            or not isinstance(normalized_candidate, str)
            or not isinstance(cpf, str)
            or not any(
                marker in normalized_candidate
                for marker in (";", "parallel(", "choice(", "pipeline(", "exhaust(")
            )
        ):
            continue
        selected = (normalized_candidate, cpf)
    if selected is None:
        return None
    candidate, cpf = selected
    wrapper_atom = candidate.split("(", 1)[0].strip()
    if wrapper_atom not in {
        "dp",
        "csr-safe-dp",
        "csr-improved-dp",
        "csr-muterm-unhiding",
        "csr-innermost-dp",
        "csr-rta08-dp",
        "csr-native-dp",
        "csr-native-ordinary-dp",
        "csr-conservative-dp",
        "csr-gm-transform",
        "csr-innermost-equivalence",
        "csr-innermost-rta08-equivalence",
    }:
        return None
    try:
        wrapper = ET.Element("input")
        wrapper.append(ET.fromstring(cpf))
    except ET.ParseError:
        return None
    return {
        "metadata": {
            "processor_tag": "certifiedRuntimeRootRecipe",
            "strategy_atom": candidate,
            "outcome": "solved",
            "runtime_raw_problem_key": runtime_root_key,
            "preserve_composed_recipe": True,
            "path": [
                "certificationProblem",
                "proof",
                "certifiedRuntimeRootRecipe",
            ],
        },
        "input": {"problem_xml": ET.tostring(wrapper, encoding="unicode")},
        "output_xml": "<certifiedRuntimeRootRecipe />",
    }


def certified_linear_root_recipe_row(
    rows: list[dict],
    root_problem_xml: str | None,
    runtime_root_key: str | None,
) -> dict | None:
    """Combine a certified linear CSR rule-removal proof into one root recipe.

    Top-level sequential strategies are logged as one event per residual, so
    unlike recursive DP recipes there may be no composed runtime event to
    retain.  A CPF consisting exclusively of a single, strictly nested chain
    of ``csrRuleRemoval`` nodes nevertheless determines that sequence exactly.
    Refuse branching, gaps, duplicate paths, and mixed processor chains: those
    require state-local guidance instead of a synthesized whole-root recipe.
    """
    if root_problem_xml is None or runtime_root_key is None:
        return None
    proof_rows = [
        row
        for row in rows
        if (row.get("metadata") or {}).get("processor_tag")
        not in {"rIsEmpty", "pIsEmpty"}
    ]
    if len(proof_rows) < 2:
        return None
    base_path = ["certificationProblem", "proof", "csrTerminationProof"]
    suffix = ["csrRuleRemoval"]
    atoms: list[str] = []
    for index, row in enumerate(proof_rows):
        metadata = row.get("metadata") or {}
        expected_path = base_path + suffix
        if (
            metadata.get("processor_tag") != "csrRuleRemoval"
            or metadata.get("path") != expected_path
            or metadata.get("outcome") not in {None, "transformed"}
        ):
            return None
        atom = strategy_atom(row)
        if not isinstance(atom, str) or not atom.startswith(
            ("exact-poly(", "exact-matrix(")
        ):
            return None
        atoms.append(atom)
        suffix += ["csrTerminationProof", "csrRuleRemoval"]
    candidate = ";".join(atoms)
    return {
        "metadata": {
            "processor_tag": "certifiedLinearRootRecipe",
            "strategy_atom": candidate,
            "outcome": "solved",
            "runtime_raw_problem_key": runtime_root_key,
            "preserve_composed_recipe": True,
            "path": [
                "certificationProblem",
                "proof",
                "certifiedLinearRootRecipe",
            ],
        },
        "input": {"problem_xml": root_problem_xml},
        "output_xml": "<certifiedLinearRootRecipe />",
    }


def exact_complete_dp_proof_rows(rows: list[dict]) -> list[dict]:
    """Materialize complete source-bound DP continuations.

    Every ordinary processor row already carries its complete recursive CPF
    subtree in ``output_xml``.  Retaining that subtree as a terminal DP atom
    avoids search-order drift between dozens of independently useful exact
    transitions while remaining state-local: Ferrum rechecks the complete
    source DP obligation before inserting it, and the reconstructed root CPF
    still has to pass CeTA.
    """
    exact_rows: list[dict] = []
    for row in rows:
        metadata = row.get("metadata") or {}
        path = metadata.get("path") or []
        source_xml = str((row.get("input") or {}).get("problem_xml") or "")
        fragment_xml = str(row.get("output_xml") or "").strip()
        if (
            "dpProof" not in path
            or "dpNonterminationProof" in path
            or "<dpInput" not in source_xml
            or not fragment_xml.startswith("<")
            or metadata.get("processor_tag") in {"pIsEmpty"}
        ):
            continue
        try:
            ET.fromstring(fragment_xml)
        except ET.ParseError:
            continue
        dp_proof_xml = f"<dpProof>{fragment_xml}</dpProof>"
        encoded = json.dumps(
            [source_xml, dp_proof_xml],
            ensure_ascii=False,
            separators=(",", ":"),
        ).encode("utf-8").hex()
        exact_rows.append(
            {
                "metadata": {
                    "processor_tag": "exactCompleteDpProof",
                    "strategy_atom": f"exact-dp-proof(hex={encoded})",
                    "outcome": "solved",
                    "path": list(path) + ["exactCompleteDpProof"],
                },
                "input": {"problem_xml": source_xml},
                "output_xml": "<exactCompleteDpProof />",
            }
        )
    return exact_rows


def exact_complete_dp_nontermination_proof_rows(rows: list[dict]) -> list[dict]:
    """Materialize complete source-bound DP nontermination continuations.

    A terminal loop found after instantiation may have been generalized back
    through those transformations when Ferrum constructed the certified CPF.
    Retaining only the final loop then loses that lifting information.  The
    complete recursive DP-nontermination subtree at each independently keyed
    source state preserves it without replaying the whole top-level proof.
    """
    exact_rows: list[dict] = []
    for row in rows:
        metadata = row.get("metadata") or {}
        path = metadata.get("path") or []
        source_xml = str((row.get("input") or {}).get("problem_xml") or "")
        fragment_xml = str(row.get("output_xml") or "").strip()
        if (
            "dpNonterminationProof" not in path
            or "<dpInput" not in source_xml
            or not fragment_xml.startswith("<")
            or metadata.get("processor_tag") in {"loop", "nonLoop"}
        ):
            continue
        try:
            ET.fromstring(fragment_xml)
        except ET.ParseError:
            continue
        dp_proof_xml = (
            f"<dpNonterminationProof>{fragment_xml}</dpNonterminationProof>"
        )
        encoded = json.dumps(
            [source_xml, dp_proof_xml],
            ensure_ascii=False,
            separators=(",", ":"),
        ).encode("utf-8").hex()
        exact_rows.append(
            {
                "metadata": {
                    "processor_tag": "exactCompleteDpNonterminationProof",
                    "strategy_atom": (
                        "exact-dp-nontermination-proof(" f"hex={encoded})"
                    ),
                    "outcome": "solved",
                    "path": list(path)
                    + ["exactCompleteDpNonterminationProof"],
                },
                "input": {"problem_xml": source_xml},
                "output_xml": "<exactCompleteDpNonterminationProof />",
            }
        )
    return exact_rows


def exact_complete_trs_proof_row(
    root: ET.Element,
    root_problem_xml: str | None,
    runtime_root_key: str | None,
) -> dict | None:
    """Retain a complete certified termination proof at its exact TRS root.

    This is deliberately source-bound rather than a generic whole-proof
    shortcut.  Ferrum first checks that the live TRS (including its strategy)
    is the archived source up to a signature isomorphism, and the resulting
    reconstructed CPF is independently checked again by CeTA.  Nested rows
    are still retained, so the same certificate also contributes state-local
    processor guidance.
    """
    if root_problem_xml is None:
        return None
    # Some CSR processors extend the certificate's replacement map with a
    # fresh, frozen proof-local unhiding symbol.  That symbol is not part of
    # the root TRS and Ferrum's live source parser correctly rejects it as an
    # unknown input symbol.  Bind the retained proof to the semantic root by
    # dropping only replacement-map entries absent from the root rule
    # signature; the complete proof fragment still declares and checks its
    # fresh symbol.
    try:
        source_root = ET.fromstring(root_problem_xml)
        trs_node = next(
            element
            for element in source_root.iter()
            if local_name(element.tag) == "trs"
        )
        source_symbols = {
            (name.text or "").strip()
            for name in trs_node.iter()
            if local_name(name.tag) == "name" and (name.text or "").strip()
        }
        for parent in source_root.iter():
            for child in list(parent):
                if local_name(child.tag) != "replacementMapEntry":
                    continue
                name = next(
                    (
                        (element.text or "").strip()
                        for element in child
                        if local_name(element.tag) == "name"
                    ),
                    "",
                )
                if name and name not in source_symbols:
                    parent.remove(child)
        root_problem_xml = ET.tostring(source_root, encoding="unicode")
    except (ET.ParseError, StopIteration):
        pass
    proof = next(
        (element for element in root.iter() if local_name(element.tag) == "proof"),
        None,
    )
    termination = next(iter(proof), None) if proof is not None else None
    if termination is None:
        return None
    termination_xml = ET.tostring(termination, encoding="unicode").strip()
    encoded = json.dumps(
        [root_problem_xml, termination_xml],
        ensure_ascii=False,
        separators=(",", ":"),
    ).encode("utf-8").hex()
    metadata = {
            "processor_tag": "exactCompleteTrsProof",
            "strategy_atom": f"exact-trs-proof(hex={encoded})",
            "outcome": "solved",
            "path": [
                "certificationProblem",
                "proof",
                "exactCompleteTrsProof",
            ],
        }
    if runtime_root_key is not None:
        metadata["runtime_raw_problem_key"] = runtime_root_key
    return {
        "metadata": metadata,
        "input": {"problem_xml": root_problem_xml},
        "output_xml": "<exactCompleteTrsProof />",
    }


def exact_complete_trs_nontermination_proof_row(
    root: ET.Element,
    root_problem_xml: str | None,
    runtime_root_key: str | None,
) -> dict | None:
    """Retain a complete certified nontermination proof at its exact root."""
    if root_problem_xml is None:
        return None
    proof = next(
        (element for element in root.iter() if local_name(element.tag) == "proof"),
        None,
    )
    nontermination = (
        next(
            (
                child
                for child in proof
                if local_name(child.tag) == "trsNonterminationProof"
            ),
            None,
        )
        if proof is not None
        else None
    )
    if nontermination is None:
        return None
    proof_xml = ET.tostring(nontermination, encoding="unicode").strip()
    encoded = json.dumps(
        [root_problem_xml, proof_xml],
        ensure_ascii=False,
        separators=(",", ":"),
    ).encode("utf-8").hex()
    metadata = {
        "processor_tag": "exactCompleteTrsNonterminationProof",
        "strategy_atom": f"exact-trs-nontermination-proof(hex={encoded})",
        "outcome": "solved",
        "path": [
            "certificationProblem",
            "proof",
            "exactCompleteTrsNonterminationProof",
        ],
    }
    if runtime_root_key is not None:
        metadata["runtime_raw_problem_key"] = runtime_root_key
    return {
        "metadata": metadata,
        "input": {"problem_xml": root_problem_xml},
        "output_xml": "<exactCompleteTrsNonterminationProof />",
    }


def csr_gm_runtime_trs_input(proof_path: Path, root: ET.Element) -> str | None:
    """Recover the GM-transformed TRS omitted by the compact CPF4 node."""
    gm = next(
        (element for element in root.iter() if local_name(element.tag) == "csrGmTransformation"),
        None,
    )
    if gm is None:
        return None
    dp_trans = next(
        (element for element in gm.iter() if local_name(element.tag) == "dpTrans"),
        None,
    )
    certified_dps = (
        next((child for child in dp_trans if local_name(child.tag) == "dps"), None)
        if dp_trans is not None
        else None
    )
    if certified_dps is None:
        return None
    certified_pairs = frozenset(
        normalized_rule_signature(rule)
        for rules in certified_dps
        if local_name(rules.tag) == "rules"
        for rule in rules
        if local_name(rule.tag) == "rule"
    )
    event_path = adjacent_event_file(proof_path)
    if event_path is None:
        return None
    best: tuple[int, ET.Element] | None = None
    for line in event_path.read_text(encoding="utf-8", errors="replace").splitlines():
        try:
            event = json.loads(line)
        except json.JSONDecodeError:
            continue
        cpf = (event.get("input") or {}).get("cpf")
        if not isinstance(cpf, str):
            continue
        try:
            dp_input = ET.fromstring(cpf)
        except ET.ParseError:
            continue
        if local_name(dp_input.tag) != "dpInput":
            continue
        dps = next((child for child in dp_input if local_name(child.tag) == "dps"), None)
        trs = next((child for child in dp_input if local_name(child.tag) == "trs"), None)
        if dps is None or trs is None:
            continue
        runtime_pairs = frozenset(
            normalized_rule_signature(rule)
            for rules in dps
            if local_name(rules.tag) == "rules"
            for rule in rules
            if local_name(rule.tag) == "rule"
        )
        # A nested GM proof may share its event file with a larger, unrelated
        # outer TRS. Never choose a state merely because it has more pairs.
        if not runtime_pairs or not runtime_pairs.issubset(certified_pairs):
            continue
        if best is None or len(runtime_pairs) > best[0]:
            best = (len(runtime_pairs), copy.deepcopy(trs))
    if best is None:
        return None
    # Ferrum removes proper-subterm/acyclic pairs before its first recorded
    # graph state, whereas CPF's dpTrans lists the complete DP set.  The
    # largest recorded DP state is therefore the initial GM-transformed TRS
    # even when its pair count is smaller than the serialized dpTrans set.
    wrapper = ET.Element("input")
    trs_input = ET.SubElement(wrapper, "trsInput")
    trs_input.append(best[1])
    strategy = ET.SubElement(trs_input, "strategy")
    ET.SubElement(strategy, "full")
    return ET.tostring(wrapper, encoding="unicode")


def materialize_single_cpf_child(ferrum: Path | None, atom: str, input_xml: str) -> str | None:
    """Execute a deterministic local transformation to recover its implicit CPF child.

    No root search or whole-proof replay is involved. The source proof gate
    remains mandatory before any resulting action enters the oracle.
    """
    if ferrum is None:
        return None
    with tempfile.TemporaryDirectory(prefix="ferrum-cpf-child-") as directory:
        path = Path(directory) / "input.cpf"
        path.write_text(input_xml)
        try:
            result = subprocess.run([str(ferrum), "probe-cpf", str(path),
                "--strategy", atom, "--timeout-ms", "60000"],
                capture_output=True, text=True, timeout=65)
            if result.returncode:
                return None
            data = json.loads(result.stdout)
        except (OSError, ValueError, subprocess.TimeoutExpired):
            return None
        children = data.get("children", [])
        if data.get("typed_outcome") != "Transformed" or len(children) != 1:
            return None
        return children[0].get("cpf")


def strategy_atom(row: dict) -> str | None:
    if row["metadata"].get("reduction_pair_model_hint"):
        return row["metadata"].get("strategy_atom")
    processor = str(row["metadata"]["processor_tag"])
    if processor == 'innermostLhssRemovalProc':
        explicit = row['metadata'].get('strategy_atom', '')
        if explicit.startswith('exact-dp-transform('):
            return explicit
        step = ET.fromstring(row.get('output_xml', '<innermostLhssRemovalProc/>'))
        child_proof = first_child(step, 'dpNonterminationProof')
        if child_proof is not None:
            source = ET.fromstring(row['input']['problem_xml'])
            child, error = child_input_for(step, child_proof, source)
            q = first_child(step, 'innermostLhss')
            if child is None or error or q is None:
                return None
            payload = json.dumps(['innermostLhssRemovalProcNontermination',
                                  ET.tostring(q, encoding='unicode'), ET.tostring(child, encoding='unicode')],
                                 separators=(',', ':')).encode().hex()
            return f'exact-dp-transform(hex={payload})'
    # A primitive terminal witness is one modular action, unlike a complete
    # nontermination proof containing preprocessing and hidden residuals.
    source_xml = str(row.get("input", {}).get("problem_xml", ""))
    if processor == 'ruleRemoval':
        explicit = row['metadata'].get('strategy_atom', '')
        if explicit.startswith('exact-trs-no-rule-removal('):
            return explicit
        step = ET.fromstring(row.get('output_xml', '<ruleRemoval/>'))
        child_proof = first_child(step, 'trsNonterminationProof')
        if child_proof is not None:
            child, error = child_input_for(step, child_proof, ET.fromstring(source_xml))
            if error or child is None:
                return None
            encoded = json.dumps([source_xml, ET.tostring(child, encoding='unicode')],
                                 ensure_ascii=False, separators=(',', ':')).encode().hex()
            return f'exact-trs-no-rule-removal(hex={encoded})'
    if processor in {"loop", "nonLoop", "notWNTreeAutomaton", "variableConditionViolated", "nonterminatingSRS"} and (
        "<trsInput" in source_xml and "<contextSensitive" not in source_xml
        and "<relativeRules" not in source_xml
    ):
        terminal_xml = str(row.get("output_xml", ""))
        try:
            terminal = ET.fromstring(terminal_xml)
        except ET.ParseError:
            return None
        if local_name(terminal.tag) == processor:
            encoded = json.dumps([source_xml, terminal_xml], ensure_ascii=False,
                                 separators=(",", ":")).encode().hex()
            return f"exact-trs-nontermination-terminal(hex={encoded})"
    if processor == "pIsEmpty":
        # The DP graph processor includes the native empty-P check. The
        # top-level `empty` atom is not part of the DP strategy grammar.
        return "graph"
    if processor == "rIsEmpty":
        return "empty"
    explicit = row["metadata"].get("strategy_atom")
    # For state-changing CPF processors, the generic search atom is only a
    # hint about how the witness was found.  Retaining it instead of the
    # certified source/payload/child boundary loses the exact continuation as
    # soon as candidate ordering changes.  Materialize the independently
    # checked transformation below; keep explicit spellings for processors
    # whose result is not represented by such a boundary.
    exact_boundary_processors = {
        "narrowingProc",
        "instantiationProc",
        "forwardInstantiationProc",
        "csrForwardInstantiationProc",
        "rewritingProc",
    }
    if (
        isinstance(explicit, str)
        and explicit.strip()
        and (
            processor not in exact_boundary_processors
            or explicit.strip().startswith("exact-")
        )
    ):
        return explicit.strip()
    output_xml = str(row.get("output_xml", ""))
    if processor == "semlab":
        try:
            step = ET.fromstring(output_xml)
        except ET.ParseError:
            return None
        if step.find("model/rootLabeling") is not None:
            return "trs-root-labeling"
    if processor == "innermostLhssIncrease":
        try:
            fragment = ET.fromstring(output_xml)
            current_input = ET.fromstring(str(row["input"]["problem_xml"]))
        except ET.ParseError:
            return None
        lhss = first_child(fragment, "innermostLhss")
        dp_trans = next(
            (element for element in fragment.iter() if local_name(element.tag) == "dpTrans"),
            None,
        )
        dps = first_child(dp_trans, "dps") if dp_trans is not None else None
        if lhss is None or dps is None:
            return None
        dp_input = dp_input_like(current_input, dps_elem=dps)
        strategy = first_child(dp_input, "strategy")
        if strategy is None:
            strategy = ET.SubElement(dp_input, "strategy")
        for child in list(strategy):
            if local_name(child.tag) == "innermostLhss":
                strategy.remove(child)
        strategy.append(copy.deepcopy(lhss))
        encoded = json.dumps(
            ET.tostring(dp_input, encoding="unicode", short_empty_elements=True),
            ensure_ascii=False,
            separators=(",", ":"),
        ).encode("utf-8").hex()
        return f"exact-innermost-lhss-dp(hex={encoded})"
    if processor == "switchFullStrategyProc":
        return "switch-full-nontermination"
    if processor == "switchToTRS":
        return "switch-to-trs"
    if processor in {"bounds", "relativeBounds"}:
        proof = bounds_proof_witness(output_xml)
        if proof is not None:
            if processor == "bounds":
                encoded = json.dumps(
                    proof, ensure_ascii=False, separators=(",", ":")
                ).encode("utf-8").hex()
                return f"exact-match-bounds(hex={encoded})"
            try:
                fragment = ET.fromstring(output_xml)
                problem = ET.fromstring(
                    unwrap_input(str(row["input"]["problem_xml"])) or ""
                )
            except ET.ParseError:
                fragment = None
                problem = None
            if fragment is not None and problem is not None:
                removed = first_child(fragment, "trs")
                input_trs = first_child(problem, "trs")
                input_rules_node = first_child(input_trs, "rules") if input_trs is not None else None
                removed_rules_node = first_child(removed, "rules") if removed is not None else None
                input_rules = list(input_rules_node) if input_rules_node is not None else []
                removed_rules = list(removed_rules_node) if removed_rules_node is not None else []

                def shape(element: ET.Element) -> tuple:
                    return (
                        local_name(element.tag),
                        " ".join((element.text or "").split()),
                        tuple(shape(child) for child in element),
                    )

                available: dict[tuple, list[int]] = {}
                for index, rule in enumerate(input_rules):
                    available.setdefault(shape(rule), []).append(index)
                removed_indices: list[int] = []
                for rule in removed_rules:
                    choices = available.get(shape(rule), [])
                    if not choices:
                        removed_indices = []
                        break
                    removed_indices.append(choices.pop(0))
                if removed_indices:
                    encoded = json.dumps(
                        [proof, removed_indices],
                        ensure_ascii=False,
                        separators=(",", ":"),
                    ).encode("utf-8").hex()
                    return f"exact-relative-match-bounds(hex={encoded})"
    if processor in {
        "narrowingProc",
        "instantiationProc",
        "forwardInstantiationProc",
        "csrForwardInstantiationProc",
        "rewritingProc",
        "complexConstantRemovalProc",
        "innermostLhssIncreaseProc",
    }:
        try:
            fragment = ET.fromstring(output_xml)
            current_input = ET.fromstring(str(row["input"]["problem_xml"]))
        except ET.ParseError:
            return None
        recursive = proof_child(fragment, "dpProof")
        if recursive is None:
            recursive = proof_child(fragment, "dpNonterminationProof")
        if recursive is not None:
            child, error = child_input_for(fragment, recursive, current_input)
            if child is not None and error is None:
                child_xml = ET.tostring(
                    child, encoding="unicode", short_empty_elements=True
                )
                prefix = copy.deepcopy(fragment)
                for nested in list(prefix):
                    if local_name(nested.tag) in {"dpProof", "dpNonterminationProof"}:
                        prefix.remove(nested)
                payload_xml = "".join(
                    ET.tostring(nested, encoding="unicode", short_empty_elements=True)
                    for nested in prefix
                )
                witness = [processor, payload_xml, child_xml]
                source_xml = str(row["input"]["problem_xml"])
                if typed_problem_kind(source_xml)[0] == 'dependency-pair':
                    witness.append(source_xml)
                encoded = json.dumps(
                    witness,
                    ensure_ascii=False,
                    separators=(",", ":"),
                ).encode("utf-8").hex()
                return f"exact-dp-transform(hex={encoded})"
    if processor == "dpRuleRemoval":
        try:
            fragment = ET.fromstring(output_xml)
            current_input = ET.fromstring(str(row["input"]["problem_xml"]))
        except ET.ParseError:
            return None
        recursive = proof_child(fragment, "dpNonterminationProof")
        if recursive is None:
            return None
        child, error = child_input_for(fragment, recursive, current_input)
        if child is None or error is not None:
            return None
        source_xml = ET.tostring(
            current_input, encoding="unicode", short_empty_elements=True
        )
        residual_xml = ET.tostring(
            child, encoding="unicode", short_empty_elements=True
        )
        encoded = json.dumps(
            [source_xml, residual_xml],
            ensure_ascii=False,
            separators=(",", ":"),
        ).encode("utf-8").hex()
        return f"exact-dp-no-rule-removal(hex={encoded})"
    if processor == "splitProc":
        try:
            fragment = ET.fromstring(output_xml)
            problem_xml = unwrap_input(str(row["input"]["problem_xml"])) or ""
            problem = ET.fromstring(problem_xml)
        except ET.ParseError:
            return None

        def direct_rules(container: ET.Element | None) -> list[ET.Element]:
            rules = first_child(container, "rules") if container is not None else None
            return [
                child
                for child in (list(rules) if rules is not None else [])
                if local_name(child.tag) == "rule"
            ]

        input_pairs = direct_rules(first_child(problem, "dps"))
        selected_pairs = direct_rules(first_child(fragment, "dps"))
        input_rules = direct_rules(first_child(problem, "trs"))
        selected_rules = direct_rules(first_child(fragment, "trs"))
        if (len(selected_pairs), len(selected_rules)) not in {(1, 0), (0, 1)}:
            return None
        selected_is_pair = bool(selected_pairs)
        selected_shape = normalized_rule_signature((selected_pairs or selected_rules)[0])
        candidates = input_pairs if selected_is_pair else input_rules
        matches = [
            index
            for index, item in enumerate(candidates)
            if normalized_rule_signature(item) == selected_shape
        ]
        if len(matches) != 1:
            return None
        encoded = json.dumps(
            [matches[0] if selected_is_pair else None,
             None if selected_is_pair else matches[0],
             problem_xml],
            ensure_ascii=False,
            separators=(",", ":"),
        ).encode("utf-8").hex()
        return f"exact-split(hex={encoded})"
    if processor in {
        "usableRulesProc",
        "localUsableRulesProc",
        "innermostLhssRemovalProc",
    }:
        try:
            fragment = ET.fromstring(output_xml)
        except ET.ParseError:
            return None
        prefix = copy.deepcopy(fragment)
        for child in list(prefix):
            if local_name(child.tag) == "dpProof":
                prefix.remove(child)
        payload_xml = "".join(
            ET.tostring(child, encoding="unicode", short_empty_elements=True)
            for child in prefix
        )
        name = (
            "exact-usable-rules"
            if processor in {"usableRulesProc", "localUsableRulesProc"}
            else "exact-innermost-lhss"
        )
        witness: object = payload_xml
        if name == "exact-innermost-lhss":
            source_input = unwrap_input(str(row["input"]["problem_xml"]))
            if source_input is None:
                return None
            witness = [payload_xml, source_input]
        if name == "exact-usable-rules":
            try:
                problem = ET.fromstring(unwrap_input(str(row["input"]["problem_xml"])) or "")
            except ET.ParseError:
                return None
            input_dps = first_child(problem, "dps")
            active_rules = first_child(problem, "usableRules")
            if active_rules is None:
                active_rules = first_child(problem, "trs")
            if input_dps is None or active_rules is None:
                return None
            source_rules = copy.deepcopy(active_rules)
            source_rules.tag = "usableRules"
            witness = [
                payload_xml,
                ET.tostring(input_dps, encoding="unicode", short_empty_elements=True),
                ET.tostring(source_rules, encoding="unicode", short_empty_elements=True),
            ]
        encoded = json.dumps(
            witness, ensure_ascii=False, separators=(",", ":")
        ).encode("utf-8").hex()
        return f"{name}(hex={encoded})"
    if processor == "dpTrans":
        try:
            fragment = ET.fromstring(output_xml)
            current_input = ET.fromstring(str(row["input"]["problem_xml"]))
        except ET.ParseError:
            return None
        dps = first_child(fragment, "dps")
        child = dp_input_like(current_input, dps_elem=dps) if dps is not None else None
        if child is not None:
            child_xml = ET.tostring(
                input_wrapper(child), encoding="unicode", short_empty_elements=True
            )
            encoded = json.dumps(
                child_xml, ensure_ascii=False, separators=(",", ":")
            ).encode("utf-8").hex()
            return f"exact-dp(hex={encoded})"
    if processor in {
        "csrRedPairUrProc",
        "redPairProc",
        "redPairUrProc",
        "monoRedPairProc",
        "monoRedPairUrProc",
        "innermostMonoRedPairProc",
    }:
        try:
            fragment = ET.fromstring(output_xml)
            problem = ET.fromstring(unwrap_input(str(row["input"]["problem_xml"])) or "")
        except ET.ParseError:
            return None

        def direct_rules(container: ET.Element | None) -> list[ET.Element]:
            if container is None:
                return []
            rules = next(
                (child for child in container if local_name(child.tag) == "rules"),
                None,
            )
            return (
                [child for child in rules if local_name(child.tag) == "rule"]
                if rules is not None
                else []
            )

        def shape(element: ET.Element) -> tuple:
            return (
                local_name(element.tag),
                " ".join((element.text or "").split()),
                tuple(shape(child) for child in element),
            )

        input_dps = next(
            (child for child in problem if local_name(child.tag) == "dps"), None
        )
        removed_dps = next(
            (child for child in fragment if local_name(child.tag) == "dps"), None
        )
        input_pairs = direct_rules(input_dps)
        removed_pairs = direct_rules(removed_dps)
        available = set(range(len(input_pairs)))
        removed_indices: list[int] = []
        removed_match_failed = False
        for removed_pair in removed_pairs:
            match = next(
                (
                    index
                    for index in sorted(available)
                    if shape(input_pairs[index]) == shape(removed_pair)
                ),
                None,
            )
            if match is None:
                removed_match_failed = True
                break
            available.remove(match)
            removed_indices.append(match)
        strict_trs = next(
            (child for child in fragment if local_name(child.tag) == "trs"), None
        )
        strict_rules = direct_rules(strict_trs)
        has_usable_restriction = processor == "monoRedPairUrProc" and any(
            local_name(child.tag) == "usableRules" for child in fragment
        )
        if not removed_match_failed and (
            removed_indices or strict_rules or has_usable_restriction
        ):
            prefix = copy.deepcopy(fragment)
            for child in list(prefix):
                if local_name(child.tag) in {
                    "dpProof",
                    "csrDpProof",
                    "ordinaryDpProof",
                }:
                    prefix.remove(child)
            payload_xml = "".join(
                ET.tostring(child, encoding="unicode", short_empty_elements=True)
                for child in prefix
            )
            active_rules = next(
                (
                    child
                    for child in problem
                    if local_name(child.tag) == "usableRules"
                ),
                None,
            )
            if active_rules is None:
                active_rules = next(
                    (child for child in problem if local_name(child.tag) == "trs"),
                    None,
                )
            if input_dps is None or active_rules is None:
                return None
            source_rules = copy.deepcopy(active_rules)
            source_rules.tag = "usableRules"
            source_pairs_xml = ET.tostring(
                input_dps, encoding="unicode", short_empty_elements=True
            )
            source_rules_xml = ET.tostring(
                source_rules, encoding="unicode", short_empty_elements=True
            )
            # Runtime generalized-DP states store weak pairs in the private
            # ``ferrumWeakDps`` container.  Always export an ordinary CPF
            # rule container here: the Rust parser intentionally accepts
            # explicit ``<rules/>`` (including the empty set), not a bare
            # ``<dps/>`` whose meaning would be ambiguous.
            weak_context = next(
                (
                    child
                    for child in problem.iter()
                    if local_name(child.tag) in {"ferrumWeakDps", "weakPairs"}
                ),
                None,
            )
            strict_context = next(
                (child for child in problem.iter() if local_name(child.tag) == "strictRules"),
                None,
            )
            weak_pairs = ET.Element("dps")
            weak_pair_rules = ET.SubElement(weak_pairs, "rules")
            source_weak_rules = (
                next(
                    (
                        child
                        for child in weak_context
                        if local_name(child.tag) == "rules"
                    ),
                    None,
                )
                if weak_context is not None
                else None
            )
            if source_weak_rules is not None:
                weak_pair_rules.extend(copy.deepcopy(list(source_weak_rules)))

            strict_rules_context = ET.Element("usableRules")
            strict_rule_rules = ET.SubElement(strict_rules_context, "rules")
            source_strict_rules = (
                next(
                    (
                        child
                        for child in strict_context
                        if local_name(child.tag) == "rules"
                    ),
                    None,
                )
                if strict_context is not None
                else None
            )
            if source_strict_rules is not None:
                strict_rule_rules.extend(copy.deepcopy(list(source_strict_rules)))
            encoded = json.dumps(
                [
                    processor,
                    payload_xml,
                    sorted(removed_indices),
                    source_pairs_xml,
                    source_rules_xml,
                    ET.tostring(
                        weak_pairs, encoding="unicode", short_empty_elements=True
                    ),
                    ET.tostring(
                        strict_rules_context,
                        encoding="unicode",
                        short_empty_elements=True,
                    ),
                ],
                ensure_ascii=False,
                separators=(",", ":"),
            ).encode("utf-8").hex()
            return f"exact-red-pair(hex={encoded})"
    if processor == "generalRedPairProc":
        try:
            fragment = ET.fromstring(output_xml)
            problem = ET.fromstring(unwrap_input(str(row["input"]["problem_xml"])) or "")
        except ET.ParseError:
            return None
        dps = next((child for child in problem if local_name(child.tag) == "dps"), None)
        input_rules_element = (
            next((child for child in dps if local_name(child.tag) == "rules"), None)
            if dps is not None
            else None
        )
        input_pairs = (
            [child for child in input_rules_element if local_name(child.tag) == "rule"]
            if input_rules_element is not None
            else []
        )

        def shape(element: ET.Element, variables: dict[str, str] | None = None) -> tuple:
            # Pair membership is alpha-invariant. Rebinding an earlier
            # transformation may freshen variables in the live input while
            # retaining equivalent strict/bound rule payloads.
            variables = {} if variables is None else variables
            tag = local_name(element.tag)
            text = " ".join((element.text or "").split())
            if tag == "var":
                text = variables.setdefault(text, f"V{len(variables)}")
            return tag, text, tuple(shape(child, variables) for child in element)

        def indices_for(container_name: str) -> list[int] | None:
            container = next(
                (child for child in fragment if local_name(child.tag) == container_name),
                None,
            )
            rules = (
                next((child for child in container if local_name(child.tag) == "rules"), None)
                if container is not None
                else None
            )
            selected = [child for child in rules if local_name(child.tag) == "rule"] if rules is not None else []
            available: dict[tuple, list[int]] = {}
            for index, rule in enumerate(input_pairs):
                available.setdefault(shape(rule), []).append(index)
            result: list[int] = []
            for rule in selected:
                choices = available.get(shape(rule), [])
                if not choices:
                    return None
                result.append(choices.pop(0))
            return result or None

        strict_indices = indices_for("strict")
        bound_indices = indices_for("bound")
        proof_count = sum(local_name(child.tag) == "dpProof" for child in fragment)
        if strict_indices is not None and bound_indices is not None and proof_count in {1, 2}:
            payload_xml = "".join(
                ET.tostring(child, encoding="unicode", short_empty_elements=True)
                for child in fragment
                if local_name(child.tag) != "dpProof"
            )
            witness = [payload_xml, strict_indices, bound_indices, proof_count == 1,
                       str(row["input"]["problem_xml"])]
            encoded = json.dumps(witness, ensure_ascii=False, separators=(",", ":")).encode("utf-8").hex()
            return f"exact-general-red-pair(hex={encoded})"
    if processor == "depGraphProc":
        try:
            fragment = ET.fromstring(output_xml)
            problem = ET.fromstring(unwrap_input(str(row["input"]["problem_xml"])) or "")
        except ET.ParseError:
            return None
        dps = next((child for child in problem if local_name(child.tag) == "dps"), None)
        rules = next((child for child in dps if local_name(child.tag) == "rules"), None) if dps is not None else None
        input_pairs = [child for child in rules if local_name(child.tag) == "rule"] if rules is not None else []
        def shape(
            element: ET.Element, variables: dict[str, str] | None = None
        ) -> tuple:
            # Exact transformations may freshen variables while preserving
            # the dependency pair modulo alpha-equivalence.  Graph component
            # membership is about those pairs, not their printed variable
            # names.  Canonicalize variables by first occurrence within each
            # rule before deriving the live component indices.
            variables = {} if variables is None else variables
            tag = local_name(element.tag)
            text = " ".join((element.text or "").split())
            if tag == "var":
                text = variables.setdefault(text, f"V{len(variables)}")
            return (
                tag,
                text,
                tuple(shape(child, variables) for child in element),
            )
        available: dict[tuple, list[int]] = {}
        for index, rule in enumerate(input_pairs):
            available.setdefault(shape(rule), []).append(index)
        components: list[list[object]] = []
        for component in (child for child in fragment if local_name(child.tag) == "component"):
            component_dps = next((child for child in component if local_name(child.tag) == "dps"), None)
            component_rules = next((child for child in component_dps if local_name(child.tag) == "rules"), None) if component_dps is not None else None
            indices: list[int] = []
            for rule in ([child for child in component_rules if local_name(child.tag) == "rule"] if component_rules is not None else []):
                choices = available.get(shape(rule), [])
                if not choices:
                    return None
                indices.append(choices.pop(0))
            # CPF uses ``dpProof`` for ordinary DP components, ``csrDpProof``
            # below ordinary CSR-DP processors, and ``mutermTypedDpProof``
            # below the typed MU-TERM construction.  Missing any of these
            # silently encodes a cyclic component as acyclic and yields an
            # executable exact-graph atom that cannot reproduce its source.
            has_proof = any(
                local_name(child.tag)
                in {"dpProof", "csrDpProof", "mutermTypedDpProof"}
                for child in component
            )
            components.append([indices, has_proof])
        covered = sorted(index for indices, _ in components for index in indices)
        if components and len(covered) == len(set(covered)) and all(
            0 <= index < len(input_pairs) for index in covered
        ):
            # CPF depGraphProc lists only retained SCCs.  Pairs absent from
            # every component are the acyclic part deleted by the processor;
            # preserve that omission in the exact runtime witness rather than
            # inventing singleton components (which is not an equivalent CPF
            # graph certificate in the presence of cross-component edges).
            # Pair indices alone are not portable once the oracle key is
            # canonicalized: a live alpha-isomorphic state can have a
            # different pair order.  Retain the complete source DP state so
            # Ferrum can validate the isomorphism and remap every component.
            source_problem = unwrap_input(str(row["input"]["problem_xml"])) or ""
            encoded = json.dumps([source_problem, components], separators=(",", ":")).encode("utf-8").hex()
            return f"exact-graph(hex={encoded})"
    if processor in {"subtermProc", "subtermCriterionProc"}:
        try:
            root = ET.fromstring(output_xml)
        except ET.ParseError:
            return None
        entries: list[list[object]] = []
        for entry in root.iter():
            if local_name(entry.tag) != "argumentFilterEntry":
                continue
            symbol = interpretation_symbol_name(entry)
            arity_text = next(
                ((child.text or "").strip() for child in entry if local_name(child.tag) == "arity"),
                "",
            )
            position_text = next(
                ((child.text or "").strip() for child in entry if local_name(child.tag) == "collapsing"),
                "",
            )
            try:
                arity = int(arity_text)
                position = int(position_text) - 1
            except ValueError:
                return None
            if symbol is None or arity == 0 or not 0 <= position < arity:
                return None
            entries.append([symbol, arity, position])
        if entries:
            encoded = json.dumps(entries, ensure_ascii=False, separators=(",", ":")).encode("utf-8").hex()
            return f"exact-subterm(hex={encoded})"
    if processor == "constantToUnary":
        try:
            fragment = ET.fromstring(output_xml)
        except ET.ParseError:
            return None
        variable = next(
            ((child.text or "").strip() for child in fragment if local_name(child.tag) == "var"),
            "",
        )
        renaming: dict[str, str] = {}
        for entry in fragment.iter():
            if local_name(entry.tag) != "renamingEntry":
                continue
            names = [
                (child.text or "").strip()
                for child in entry
                if local_name(child.tag) == "name" and (child.text or "").strip()
            ]
            if len(names) != 2:
                return None
            renaming[names[0]] = names[1]
        if not variable or not renaming:
            return None
        encoded = json.dumps([variable, renaming], ensure_ascii=False, separators=(",", ":")).encode("utf-8").hex()
        return f"exact-constant-to-unary(hex={encoded})"
    if processor == "sizeChangeProc":
        try:
            fragment = ET.fromstring(output_xml)
            problem = ET.fromstring(
                unwrap_input(str(row["input"]["problem_xml"])) or ""
            )
        except ET.ParseError:
            fragment = None
            problem = None
        if (
            fragment is not None
            and problem is not None
            and any(local_name(element.tag) == "subtermCriterion" for element in fragment.iter())
        ):
            dps = next(
                (child for child in problem if local_name(child.tag) == "dps"),
                None,
            )
            rules = (
                next(
                    (child for child in dps if local_name(child.tag) == "rules"),
                    None,
                )
                if dps is not None
                else None
            )

            def xml_shape(element: ET.Element) -> tuple:
                return (
                    local_name(element.tag),
                    " ".join((element.text or "").split()),
                    tuple(xml_shape(child) for child in element),
                )

            input_pairs = (
                [child for child in rules if local_name(child.tag) == "rule"]
                if rules is not None
                else []
            )
            available: dict[tuple, list[int]] = {}
            for index, rule in enumerate(input_pairs):
                available.setdefault(xml_shape(rule), []).append(index)
            witness: list[list[object]] = []
            graph_elements = [
                element
                for element in fragment.iter()
                if local_name(element.tag) == "sizeChangeGraph"
            ]
            compact_indices: list[int] = []
            for graph in graph_elements:
                text = next(
                    (
                        (child.text or "").strip()
                        for child in graph
                        if local_name(child.tag) == "ruleIndex"
                    ),
                    "",
                )
                try:
                    compact_indices.append(int(text) - 1)
                except ValueError:
                    compact_indices.append(-1)
            indices_are_local = sorted(compact_indices) == list(range(len(input_pairs)))
            for graph_position, graph in enumerate(graph_elements):
                rule = next(
                    (child for child in graph if local_name(child.tag) == "rule"),
                    None,
                )
                rule_index = next(
                    (
                        (child.text or "").strip()
                        for child in graph
                        if local_name(child.tag) == "ruleIndex"
                    ),
                    "",
                )
                if rule is not None:
                    indices = available.get(xml_shape(rule), [])
                    if not indices:
                        witness = []
                        break
                    pair_index = indices.pop(0)
                else:
                    try:
                        # CPF rule indices are one-based.  AProVE uses this
                        # compact form in its certified size-change proofs.
                        # Inside a dependency-graph component these indices
                        # still refer to the original DP transformation.  The
                        # local dpInput contains the component pairs in that
                        # same order, so fall back to the graph position when
                        # the global index is outside the local component.
                        pair_index = int(rule_index) - 1
                    except ValueError:
                        witness = []
                        break
                    if not indices_are_local:
                        if len(graph_elements) != len(input_pairs):
                            witness = []
                            break
                        pair_index = graph_position
                edges: list[list[object]] = []
                for edge in graph:
                    if local_name(edge.tag) != "edge":
                        continue
                    positions = [
                        (child.text or "").strip()
                        for child in edge
                        if local_name(child.tag) == "position"
                    ]
                    strict = next(
                        (
                            (child.text or "").strip().lower()
                            for child in edge
                            if local_name(child.tag) == "strict"
                        ),
                        "",
                    )
                    try:
                        left, right = map(int, positions)
                    except (ValueError, TypeError):
                        edges = []
                        break
                    if strict not in {"true", "false"}:
                        edges = []
                        break
                    edges.append([left, strict == "true", right])
                if not edges:
                    witness = []
                    break
                witness.append([pair_index, edges])
            if len(witness) == len(input_pairs) and witness:
                encoded = json.dumps(
                    witness, ensure_ascii=False, separators=(",", ":")
                ).encode("utf-8").hex()
                return f"exact-size-change(hex={encoded})"
    if processor in {"csrRuleRemovalThenImproved", "csrGuardedRuleRemoval"}:
        fragment = str(row["output_xml"])
        witness = linear_polynomial_witness(fragment)
        if witness is not None:
            encoded = json.dumps(
                witness, ensure_ascii=False, separators=(",", ":")
            ).encode("utf-8").hex()
            polynomial = f"exact-poly(hex={encoded})"
        else:
            mapped = strategy_from_xml(
                processor,
                fragment,
                str(row["input"]["problem_xml"]),
            )
            if mapped is None:
                return None
            polynomial = mapped[0].replace(", ", ",")
        # This checker node contains two independently executable actions.
        # Emit rule removal here; the root-local atom materializer below also
        # places a bare ``csr-improved-dp`` atom on the resulting CSR child.
        return polynomial
    if processor == "dpTrans":
        return "dp"
    if processor == "semlab":
        model = relative_semantic_labeling_model(str(row["output_xml"]))
        if model is None:
            return None
        carrier_size, interpretations = model
        encoded = json.dumps(
            interpretations, ensure_ascii=False, separators=(",", ":")
        ).encode("utf-8").hex()
        return (
            "exact-relative-semantic-labeling("
            f"carrier-size={carrier_size},hex={encoded})"
        )
    if processor in {"semanticLabelingProc", "semlabProc"}:
        try:
            fragment = ET.fromstring(str(row["output_xml"]))
        except ET.ParseError:
            return None
        if any(local_name(node.tag) == "rootLabeling" for node in fragment.iter()):
            # Root labeling is deterministic from the live DP signature and
            # has its own native Ferrum atom.  Treating it as an exact finite
            # model either drops the step (there is no <finiteModel>) or,
            # worse, attaches the following finite model to the root-labeled
            # processor's parent state.
            return "root-labeling"
        model = relative_semantic_labeling_model(str(row["output_xml"]))
        if model is None:
            return None
        carrier_size, entries = model
        exact_model = {
            "carrier_size": carrier_size,
            "arities": {name: arity for name, arity, _ in entries},
            "interpretations": {name: function for name, _, function in entries},
        }
        try:
            current_input = ET.fromstring(str(row["input"]["problem_xml"]))
        except ET.ParseError:
            return None
        recursive = proof_child(fragment, "dpProof")
        if recursive is None:
            return None
        child, error = child_input_for(fragment, recursive, current_input)
        if child is None or error is not None:
            return None
        child_xml = ET.tostring(
            child, encoding="unicode", short_empty_elements=True
        )
        encoded = json.dumps(
            [exact_model, str(row["input"]["problem_xml"]), child_xml],
            ensure_ascii=False,
            separators=(",", ":"),
        ).encode("utf-8").hex()
        return f"exact-semantic-labeling(hex={encoded})"
    if processor == "nonLoop":
        source_xml = str(row["input"]["problem_xml"])
        fragment_xml = str(row.get("output_xml", ""))
        if "<nonLoop" not in fragment_xml:
            return None
        encoded = json.dumps(
            [source_xml, fragment_xml],
            ensure_ascii=False,
            separators=(",", ":"),
        ).encode("utf-8").hex()
        return f"exact-dp-nonloop(hex={encoded})"
    if processor == "loop":
        path = row["metadata"].get("path") or []
        if "dpNonterminationProof" in path:
            source_xml = str(row["input"]["problem_xml"])
            fragment_xml = str(row.get("output_xml", ""))
            if "<loop" not in fragment_xml:
                return None
            encoded = json.dumps(
                [source_xml, fragment_xml],
                ensure_ascii=False,
                separators=(",", ":"),
            ).encode("utf-8").hex()
            return f"exact-dp-loop(hex={encoded})"
        return "nontermination(loop)"
    if processor in DIRECT_ATOMS:
        return DIRECT_ATOMS[processor]
    mapped = strategy_from_xml(
        processor,
        output_xml,
        str(row["input"]["problem_xml"]),
    )
    if mapped is None:
        return None
    candidate = mapped[0].replace(", ", ",")
    if processor == "ruleRemoval" and candidate.startswith("kbo("):
        witness = top_level_kbo_witness(align_fragment_numeric_symbols(
            str(row['output_xml']), str(row['input']['problem_xml'])))
        if witness is not None:
            # Complete omitted constants with an admissible candidate. This
            # is independently checked by native exact-kbo on every rule;
            # it is not permission to accept an incomplete weight map.
            live = ET.fromstring(str(row['input']['problem_xml']))
            precedence, ranks, weights = witness
            for term in live.iter('funapp'):
                if len(term) == 1 and term[0].tag == 'name':
                    name = term[0].text or ''
                    if name not in weights:
                        weights[name] = 1
                        ranks[name] = max(ranks.values(), default=-1) + 1
                        precedence.append(name)
            encoded = json.dumps(witness, separators=(',', ':')).encode().hex()
            return f'exact-kbo(hex={encoded})'
    if candidate.startswith("csr-gm-transform("):
        return "csr-gm-transform"
    if candidate.startswith("csr-improved-dp("):
        return "csr-improved-dp"
    # Preserve the selected affine model for every polynomial processor
    # family.  In particular, ``monoRedPairProc`` used to be reduced back to
    # a bounded ``mono-poly`` search atom.  That is not representation exact:
    # another valid model can delete a different subset and expose a child
    # for which the certified continuation has no entry.  Exact atoms still
    # recheck all live weak/strict obligations before deleting anything.
    if candidate.startswith(("poly(", "mono-poly(", "weak-poly(")):
        witness = linear_polynomial_witness(str(row["output_xml"]))
        if witness is not None:
            encoded = json.dumps(
                witness, ensure_ascii=False, separators=(",", ":")
            ).encode("utf-8").hex()
            weak_affine = candidate.startswith("weak-poly(") or any(
                int(entry[1]) < 0 for entry in witness
            )
            candidate = (
                f"exact-weak-poly(hex={encoded})"
                if weak_affine
                else f"exact-poly(hex={encoded})"
            )
    if candidate.startswith("max-poly("):
        witness = max_polynomial_witness(str(row["output_xml"]))
        if witness is not None:
            encoded = json.dumps(
                witness, ensure_ascii=False, separators=(",", ":")
            ).encode("utf-8").hex()
            candidate = f"exact-max-poly(hex={encoded})"
    if candidate == "path-order":
        witness = path_order_witness(str(row["output_xml"]))
        if witness is not None:
            removal_indices: list[int] | None = None
            if processor == "ruleRemoval":
                try:
                    fragment = ET.fromstring(str(row["output_xml"]))
                    problem = ET.fromstring(
                        unwrap_input(str(row["input"]["problem_xml"])) or ""
                    )
                except ET.ParseError:
                    fragment = None
                    problem = None
                if fragment is not None and problem is not None and local_name(problem.tag) == "trsInput":
                    input_trs = first_child(problem, "trs")
                    removed_trs = first_child(fragment, "trs")
                    input_rules_node = first_child(input_trs, "rules") if input_trs is not None else None
                    removed_rules_node = first_child(removed_trs, "rules") if removed_trs is not None else None
                    input_rules = list(input_rules_node) if input_rules_node is not None else []
                    removed_rules = list(removed_rules_node) if removed_rules_node is not None else []

                    def rule_shape(element: ET.Element, variables: dict[str, str] | None = None) -> tuple:
                        variables = {} if variables is None else variables
                        tag = local_name(element.tag)
                        text = " ".join((element.text or "").split())
                        if tag == "var":
                            text = variables.setdefault(text, f"V{len(variables)}")
                        return (tag, text, tuple(rule_shape(child, variables) for child in element))

                    available: dict[tuple, list[int]] = {}
                    for index, rule in enumerate(input_rules):
                        available.setdefault(rule_shape(rule), []).append(index)
                    located: list[int] = []
                    for rule in removed_rules:
                        choices = available.get(rule_shape(rule), [])
                        if not choices:
                            located = []
                            break
                        located.append(choices.pop(0))
                    if located:
                        removal_indices = sorted(located)
            if removal_indices is not None and len(witness) == 5:
                _, statuses, precedence, precedence_ranks, argument_filter = witness
                encoded_value = [
                    statuses,
                    precedence,
                    precedence_ranks,
                    argument_filter,
                    removal_indices,
                ]
                name = "exact-path-order-removal"
            else:
                encoded_value = witness
                name = "exact-path-order"
            encoded = json.dumps(
                encoded_value, ensure_ascii=False, separators=(",", ":")
            ).encode("utf-8").hex()
            candidate = f"{name}(hex={encoded})"
            if name == "exact-path-order-removal":
                source_hex = str(row["input"]["problem_xml"]).encode("utf-8").hex()
                candidate = f"{name}(hex={encoded},source-hex={source_hex})"
    # ``strategy_from_xml`` historically only distinguished linear natural
    # polynomial interpretations.  Preserve the processor family when a
    # certified CPF carries degree-2 monomials; replaying it as ``poly`` would
    # silently discard squares and mixed terms such as x1*x2.
    if candidate.startswith("poly("):
        try:
            fragment = ET.fromstring(str(row["output_xml"]))
        except ET.ParseError:
            fragment = None
        degrees = (
            [
                int((element.text or "").strip())
                for element in fragment.iter()
                if local_name(element.tag) == "degree"
                and (element.text or "").strip().isdigit()
            ]
            if fragment is not None
            else []
        )
        tags = (
            {local_name(element.tag) for element in fragment.iter()}
            if fragment is not None
            else set()
        )
        if "rationals" in tags:
            witness = rational_linear_polynomial_witness(str(row["output_xml"]))
            if witness is not None:
                encoded = json.dumps(
                    witness, ensure_ascii=False, separators=(",", ":")
                ).encode("utf-8").hex()
                candidate = f"exact-rat-poly(hex={encoded})"
            else:
                delta_denominator = 1
                coefficient_denominator = 1
                for rational in (
                    element
                    for element in fragment.iter()
                    if local_name(element.tag) == "rational"
                ):
                    denominator = next(
                        (
                            int((child.text or "").strip())
                            for child in rational
                            if local_name(child.tag) == "denominator"
                            and (child.text or "").strip().isdigit()
                        ),
                        1,
                    )
                    if any(
                        local_name(ancestor.tag) == "delta"
                        and rational in list(ancestor)
                        for ancestor in fragment.iter()
                    ):
                        delta_denominator = max(delta_denominator, denominator)
                    else:
                        coefficient_denominator = max(
                            coefficient_denominator, denominator
                        )
                candidate = (
                    "rational-poly(max-constant=16,max-coefficient=16,"
                    f"denominator={coefficient_denominator},"
                    f"delta-denominator={delta_denominator})"
                )
        elif (
            processor
            in {
                "monoRedPairProc",
                "monoRedPairUrProc",
                "innermostMonoRedPairProc",
            }
            and not any(degree >= 2 for degree in degrees)
        ):
            candidate = "mono-" + candidate
        elif any(degree >= 2 for degree in degrees):
            candidate = "quadratic-" + candidate
    if candidate.startswith("matrix("):
        try:
            fragment = ET.fromstring(str(row["output_xml"]))
        except ET.ParseError:
            fragment = None
        if fragment is not None:
            arctic_witness = arctic_matrix_witness(str(row["output_xml"]))
            integer_witness = integer_matrix_witness(str(row["output_xml"]))
            natural_witness = natural_matrix_witness(str(row["output_xml"]))
            if arctic_witness is not None:
                encoded = json.dumps(
                    arctic_witness, ensure_ascii=False, separators=(",", ":")
                ).encode("utf-8").hex()
                candidate = f"exact-arctic(hex={encoded})"
            elif integer_witness is not None:
                encoded = json.dumps(
                    integer_witness, ensure_ascii=False, separators=(",", ":")
                ).encode("utf-8").hex()
                candidate = f"exact-integer-matrix(hex={encoded})"
            elif natural_witness is not None:
                encoded = json.dumps(
                    natural_witness, ensure_ascii=False, separators=(",", ":")
                ).encode("utf-8").hex()
                candidate = f"exact-matrix(hex={encoded})"
        if candidate.startswith("matrix(") and fragment is not None and any(
            local_name(element.tag) == "arctic" for element in fragment.iter()
        ):
            parameters = dict(
                re.findall(
                    r"(dimension|dim|max-constant|max-coefficient)=(\d+)",
                    candidate,
                )
            )
            dimension = parameters.get("dimension", parameters.get("dim", "2"))
            max_constant = parameters.get("max-constant", "1")
            max_coefficient = parameters.get("max-coefficient", "1")
            candidate = (
                f"arctic-matrix(dimension={dimension},"
                f"max-constant={max_constant},max-coefficient={max_coefficient})"
            )
    return candidate


def bounds_proof_witness(fragment_xml: str) -> dict[str, object] | None:
    """Decode Ferrum/CeTA CPF match-bounds data into BoundsProof JSON."""
    try:
        fragment = ET.fromstring(fragment_xml)
    except ET.ParseError:
        return None
    bounds = next(
        (element for element in fragment.iter() if local_name(element.tag) == "bounds"),
        None,
    )
    if bounds is None:
        return None
    type_node = first_child(bounds, "type")
    type_tag = local_name(next(iter(type_node), ET.Element("missing")).tag) if type_node is not None else ""
    bounds_type = {"match": "Match", "roof": "Roof"}.get(type_tag)
    bound_text = (first_child(bounds, "bound").text or "").strip() if first_child(bounds, "bound") is not None else ""
    try:
        bound = int(bound_text)
    except ValueError:
        return None
    if bounds_type is None or bound < 0:
        return None

    def states(container: ET.Element | None) -> list[str]:
        if container is None:
            return []
        return [
            (element.text or "").strip()
            for element in container
            if local_name(element.tag) == "state" and (element.text or "").strip()
        ]

    final_states = states(first_child(bounds, "finalStates"))
    automaton_node = first_child(bounds, "treeAutomaton")
    if automaton_node is None:
        return None
    automaton_finals = states(first_child(automaton_node, "finalStates"))
    transitions_node = first_child(automaton_node, "transitions")
    transitions: list[dict[str, object]] = []
    for transition in list(transitions_node) if transitions_node is not None else []:
        if local_name(transition.tag) != "transition":
            continue
        lhs = first_child(transition, "lhs")
        rhs = first_child(transition, "rhs")
        rhs_states = states(rhs)
        if lhs is None or len(rhs_states) != 1:
            return None
        lhs_states = states(lhs)
        name = first_child(lhs, "name")
        if name is None:
            if len(lhs_states) != 1:
                return None
            lhs_json: object = {"State": lhs_states[0]}
        else:
            symbol = (name.text or "").strip()
            height_node = first_child(lhs, "height")
            try:
                height = int((height_node.text or "").strip()) if height_node is not None else None
            except ValueError:
                return None
            if not symbol or (height is not None and height < 0):
                return None
            lhs_json = {
                "Symbol": {
                    "symbol": symbol,
                    "height": height,
                    "args": lhs_states,
                }
            }
        transitions.append({"lhs": lhs_json, "rhs": rhs_states[0]})
    if not final_states or not automaton_finals or not transitions:
        return None

    compatibility: list[list[str]] = []
    criterion = first_child(bounds, "criterion")
    state_compatibility = (
        first_child(criterion, "stateCompatibility") if criterion is not None else None
    )
    relation = first_child(state_compatibility, "relation") if state_compatibility is not None else None
    if relation is not None:
        for entry in relation:
            pair = states(entry)
            if len(pair) != 2:
                return None
            compatibility.append(pair)
    return {
        "bounds_type": bounds_type,
        "bound": bound,
        "final_states": final_states,
        "automaton": {
            "final_states": automaton_finals,
            "transitions": transitions,
        },
        "state_compatibility": compatibility,
    }


def natural_matrix_witness(fragment_xml: str) -> list[list[object]] | None:
    """Extract one direct natural matrix interpretation from a CPF step."""
    parsed = matrix_witness(fragment_xml, require_arctic=False)
    return parsed[1] if parsed is not None and not parsed[0] else None


def integer_matrix_witness(fragment_xml: str) -> list[list[object]] | None:
    """Extract one direct ordinary integer matrix interpretation."""
    parsed = matrix_witness(fragment_xml, require_arctic=False)
    return parsed[1] if parsed is not None and parsed[0] else None


def arctic_matrix_witness(
    fragment_xml: str,
) -> tuple[bool, list[list[object]]] | None:
    """Extract one direct Arctic matrix model, preserving its domain and -inf."""
    return matrix_witness(fragment_xml, require_arctic=True)


def interpretation_symbol_name(interpretation: ET.Element) -> str | None:
    """Decode a CPF symbol into Ferrum's exact runtime spelling."""
    def decode(node: ET.Element) -> str | None:
        tag = local_name(node.tag)
        if tag == "name":
            return (node.text or "").strip() or None
        if tag == "sharp":
            base_node = next((child for child in node if local_name(child.tag) in {"name", "sharp", "labeledSymbol"}), None)
            base = decode(base_node) if base_node is not None else None
            return f"{base}#" if base is not None else None
        if tag != "labeledSymbol":
            return None
        base_node = next((child for child in node if local_name(child.tag) in {"name", "sharp", "labeledSymbol"}), None)
        base = decode(base_node) if base_node is not None else None
        if base is None:
            return None
        symbol_label = next((child for child in node if local_name(child.tag) == "symbolLabel"), None)
        if symbol_label is not None:
            labels = [decode(child) for child in symbol_label if child is not None]
            if any(label is None for label in labels):
                return None
            encoded_labels = "_".join(str(label).encode("utf-8").hex() for label in labels)
            return f"__ferrum_rl__{base.encode('utf-8').hex()}__{encoded_labels}"
        number_label = next((child for child in node if local_name(child.tag) == "numberLabel"), None)
        labels = [
            (number.text or "").strip()
            for number in (list(number_label) if number_label is not None else [])
            if local_name(number.tag) == "number" and (number.text or "").strip()
        ]
        return f"__ferrum_sl__{base.encode('utf-8').hex()}__{'_'.join(labels)}"

    symbol = next(
        (child for child in interpretation if local_name(child.tag) in {"name", "sharp", "labeledSymbol"}),
        None,
    )
    return decode(symbol) if symbol is not None else None


def _semantic_arithmetic_function(element: ET.Element) -> object | None:
    node = element
    if local_name(node.tag) == "arithFunction":
        children = list(node)
        if len(children) != 1:
            return None
        node = children[0]
    tag = local_name(node.tag)
    if tag == "ifEqual":
        items = [_semantic_arithmetic_function(child) for child in node]
        return {"IfEqual": items} if len(items) == 4 and all(item is not None for item in items) else None
    if tag == "natural":
        try:
            return {"Constant": int((node.text or "").strip())}
        except ValueError:
            return None
    if tag == "variable":
        try:
            position = int((node.text or "").strip())
        except ValueError:
            return None
        return {"Argument": position - 1} if position >= 1 else None
    if tag in {"sum", "product"}:
        items = []
        for child in node:
            parsed = _semantic_arithmetic_function(child)
            if parsed is None:
                return None
            items.append(parsed)
        if not items:
            return None
        return {"Sum" if tag == "sum" else "Product": items}
    return None


def relative_semantic_labeling_model(
    fragment_xml: str,
) -> tuple[int, list[list[object]]] | None:
    """Extract the exact finite model from a CPF relative semlab node."""
    try:
        root = ET.fromstring(fragment_xml)
    except ET.ParseError:
        return None
    finite = next(
        (node for node in root.iter() if local_name(node.tag) == "finiteModel"),
        None,
    )
    if finite is None:
        return None
    carrier = next(
        (node for node in finite if local_name(node.tag) == "carrierSize"),
        None,
    )
    try:
        carrier_size = int((carrier.text or "").strip()) if carrier is not None else 0
    except ValueError:
        return None
    if carrier_size <= 0:
        return None
    interpretations: list[list[object]] = []
    for interpretation in finite:
        if local_name(interpretation.tag) != "interpret":
            continue
        name = interpretation_symbol_name(interpretation)
        arity_node = next(
            (node for node in interpretation if local_name(node.tag) == "arity"),
            None,
        )
        function_node = next(
            (node for node in interpretation if local_name(node.tag) == "arithFunction"),
            None,
        )
        try:
            arity = int((arity_node.text or "").strip()) if arity_node is not None else -1
        except ValueError:
            return None
        function = (
            _semantic_arithmetic_function(function_node)
            if function_node is not None
            else None
        )
        if name is None or arity < 0 or function is None:
            return None
        interpretations.append([name, arity, function])
    return (carrier_size, interpretations) if interpretations else None


def matrix_witness(
    fragment_xml: str, *, require_arctic: bool
) -> tuple[bool, list[list[object]]] | None:
    try:
        fragment = ET.fromstring(fragment_xml)
    except ET.ParseError:
        return None
    container = next(
        (
            element
            for element in fragment.iter()
            if local_name(element.tag) == "interpretation"
            and any(
                local_name(child.tag) == "matrixInterpretation"
                for child in element.iter()
            )
        ),
        None,
    )
    if container is None:
        return None
    has_arctic = any(local_name(element.tag) == "arctic" for element in container.iter())
    if has_arctic != require_arctic:
        return None
    integer_domain = any(
        local_name(element.tag) == "integers" for element in container.iter()
    )
    dimension_text = next(
        (
            (element.text or "").strip()
            for element in container.iter()
            if local_name(element.tag) == "dimension"
        ),
        "",
    )
    strict_dimension_text = next(
        (
            (element.text or "").strip()
            for element in container.iter()
            if local_name(element.tag) == "strictDimension"
        ),
        "1",
    )
    try:
        dimension = int(dimension_text)
        strict_dimension = int(strict_dimension_text)
    except ValueError:
        return None
    if dimension <= 0 or strict_dimension != 1:
        return None

    def vector(element: ET.Element) -> list[int] | None:
        if local_name(element.tag) != "vector":
            return None
        try:
            values = [
                (
                    -(1 << 63)
                    if local_name(child.tag) == "minusInfinity"
                    else int((child.text or "").strip())
                )
                for child in element
                if local_name(child.tag) in {"integer", "minusInfinity"}
            ]
        except ValueError:
            return None
        if require_arctic and not integer_domain and any(
            value < 0 and value != -(1 << 63) for value in values
        ):
            return None
        if not require_arctic and not integer_domain and any(value < 0 for value in values):
            return None
        return values if len(values) == dimension else None

    def matrix(element: ET.Element) -> list[list[int]] | None:
        if local_name(element.tag) != "matrix":
            return None
        rows = [vector(child) for child in element if local_name(child.tag) == "vector"]
        return rows if len(rows) == dimension and all(row is not None for row in rows) else None

    witness: list[list[object]] = []
    for interpretation in (
        element for element in list(container) if local_name(element.tag) == "interpret"
    ):
        name = interpretation_symbol_name(interpretation)
        arity_text = next(
            (
                (child.text or "").strip()
                for child in interpretation
                if local_name(child.tag) == "arity"
            ),
            "",
        )
        expression = next(
            (
                child
                for child in interpretation
                if local_name(child.tag) not in {"name", "sharp", "labeledSymbol", "arity"}
            ),
            None,
        )
        try:
            arity = int(arity_text)
        except ValueError:
            return None
        if name is None or arity < 0 or expression is None:
            return None
        terms = list(expression) if local_name(expression.tag) == "sum" else [expression]
        constant = [0] * dimension
        coefficients = [
            [[0 for _ in range(dimension)] for _ in range(dimension)]
            for _ in range(arity)
        ]
        for term in terms:
            if local_name(term.tag) == "vector":
                value = vector(term)
                if value is None:
                    return None
                constant = [left + right for left, right in zip(constant, value)]
                continue
            if local_name(term.tag) != "product":
                return None
            coefficient = next(
                (child for child in term if local_name(child.tag) == "matrix"),
                None,
            )
            variable = next(
                (child for child in term if local_name(child.tag) == "variable"),
                None,
            )
            if coefficient is None or variable is None:
                return None
            value = matrix(coefficient)
            try:
                index = int((variable.text or "").strip()) - 1
            except ValueError:
                return None
            if value is None or not 0 <= index < arity:
                return None
            coefficients[index] = [
                [old + new for old, new in zip(old_row, new_row)]
                for old_row, new_row in zip(coefficients[index], value)
            ]
        witness.append([name, constant, coefficients])
    return (integer_domain, witness) if witness else None


def linear_polynomial_witness(fragment_xml: str) -> list[list[object]] | None:
    """Extract an exact affine natural-polynomial model from a CPF processor.

    Return ``None`` for rational, higher-degree, matrix, max-polynomial, or
    nonlinear expressions.  Exact replay is deliberately narrower than the
    existing family/bounds mapping: a malformed or unsupported witness falls
    back to bounded synthesis rather than being guessed.
    """
    try:
        fragment = ET.fromstring(fragment_xml)
    except ET.ParseError:
        return None
    container = next(
        (
            element
            for element in fragment.iter()
            if local_name(element.tag) == "interpretation"
            and any(local_name(child.tag) == "polynomial" for child in element.iter())
        ),
        None,
    )
    polynomial = (
        next(
            (
                element
                for element in container.iter()
                if local_name(element.tag) == "polynomial"
            ),
            None,
        )
        if container is not None
        else None
    )
    if polynomial is None or any(
        local_name(element.tag) == "rationals" for element in polynomial.iter()
    ):
        return None
    degree = next(
        (
            (element.text or "").strip()
            for element in polynomial.iter()
            if local_name(element.tag) == "degree"
        ),
        "",
    )
    # CPF3 permits the degree annotation to be omitted.  The recursive
    # ``affine`` decoder below is the authoritative check: it rejects every
    # nonlinear monomial, so an absent annotation is still safe to retain.
    if degree not in {"", "1"}:
        return None

    def affine(element: ET.Element, arity: int) -> tuple[int, list[int]] | None:
        tag = local_name(element.tag)
        children = list(element)
        if tag == "integer" and not children:
            try:
                return int((element.text or "").strip()), [0] * arity
            except ValueError:
                return None
        if tag == "variable" and not children:
            try:
                index = int((element.text or "").strip()) - 1
            except ValueError:
                return None
            if not 0 <= index < arity:
                return None
            coefficients = [0] * arity
            coefficients[index] = 1
            return 0, coefficients
        if tag == "sum":
            total = (0, [0] * arity)
            for child in children:
                value = affine(child, arity)
                if value is None:
                    return None
                total = (
                    total[0] + value[0],
                    [left + right for left, right in zip(total[1], value[1])],
                )
            return total
        if tag == "product" and len(children) == 2:
            left = affine(children[0], arity)
            right = affine(children[1], arity)
            if left is None or right is None:
                return None
            if any(left[1]) and any(right[1]):
                return None
            if any(left[1]):
                if any(right[1]) or right[0] < 0:
                    return None
                return left[0] * right[0], [value * right[0] for value in left[1]]
            if any(right[1]):
                if any(left[1]) or left[0] < 0:
                    return None
                return left[0] * right[0], [value * left[0] for value in right[1]]
            return left[0] * right[0], [0] * arity
        return None

    witness: list[list[object]] = []
    for interpretation in (
        element for element in list(container) if local_name(element.tag) == "interpret"
    ):
        name = interpretation_symbol_name(interpretation)
        arity_text = next(
            (
                (child.text or "").strip()
                for child in interpretation
                if local_name(child.tag) == "arity"
            ),
            "",
        )
        expression = next(
            (
                child
                for child in interpretation
                if local_name(child.tag) not in {"name", "sharp", "labeledSymbol", "arity"}
            ),
            None,
        )
        try:
            arity = int(arity_text)
        except ValueError:
            return None
        if name is None or arity < 0 or expression is None:
            return None
        value = affine(expression, arity)
        # CPF's weak affine processor permits negative constants.  Preserve
        # those in ``exact-weak-poly``; coefficients must remain
        # nonnegative so the live exact validator can establish weak
        # monotonicity with CeTA's Pleft/Pright semantics.
        if value is None or any(coefficient < 0 for coefficient in value[1]):
            return None
        witness.append([name, value[0], value[1]])
    return witness or None


def max_polynomial_witness(fragment_xml: str) -> list[list[object]] | None:
    """Extract an exact natural max-polynomial model from a CPF processor.

    Ferrum represents each function by a list of affine alternatives.  CPF
    nests ``max`` and ``sum`` expressions, so sums are distributed over max
    alternatives.  Unsupported or negative expressions are rejected instead
    of being approximated by a new synthesis request.
    """
    try:
        fragment = ET.fromstring(fragment_xml)
    except ET.ParseError:
        return None
    container = next(
        (element for element in fragment.iter() if local_name(element.tag) == "maxPoly"),
        None,
    )
    if container is None:
        return None

    Affine = tuple[int, list[int]]

    def alternatives(element: ET.Element, arity: int) -> list[Affine] | None:
        tag = local_name(element.tag)
        children = list(element)
        if tag in {"constant", "integer"} and not children:
            try:
                value = int((element.text or "").strip())
            except ValueError:
                return None
            return [(value, [0] * arity)] if value >= 0 else None
        if tag == "variable" and not children:
            try:
                index = int((element.text or "").strip()) - 1
            except ValueError:
                return None
            if not 0 <= index < arity:
                return None
            coefficients = [0] * arity
            coefficients[index] = 1
            return [(0, coefficients)]
        if tag == "max":
            result: list[Affine] = []
            for child in children:
                values = alternatives(child, arity)
                if values is None:
                    return None
                result.extend(values)
            return result or None
        if tag == "sum":
            result: list[Affine] = [(0, [0] * arity)]
            for child in children:
                values = alternatives(child, arity)
                if values is None:
                    return None
                result = [
                    (
                        left[0] + right[0],
                        [a + b for a, b in zip(left[1], right[1])],
                    )
                    for left in result
                    for right in values
                ]
            return result
        return None

    witness: list[list[object]] = []
    for interpretation in (
        element for element in list(container) if local_name(element.tag) == "interpret"
    ):
        name = interpretation_symbol_name(interpretation)
        arity_text = next(
            (
                (child.text or "").strip()
                for child in interpretation
                if local_name(child.tag) == "arity"
            ),
            "",
        )
        expression = next(
            (
                child
                for child in interpretation
                if local_name(child.tag) not in {"name", "sharp", "labeledSymbol", "arity"}
            ),
            None,
        )
        try:
            arity = int(arity_text)
        except ValueError:
            return None
        if name is None or arity < 0 or expression is None:
            return None
        values = alternatives(expression, arity)
        if values is None:
            return None
        # Preserve order while removing syntactically duplicate alternatives.
        unique: list[list[object]] = []
        seen: set[tuple[int, tuple[int, ...]]] = set()
        for constant, coefficients in values:
            key = constant, tuple(coefficients)
            if key not in seen:
                seen.add(key)
                unique.append([constant, coefficients])
        witness.append([name, unique])
    return witness or None


def top_level_kbo_witness(fragment_xml: str) -> list[object] | None:
    """The native KBO atom supports variable weight one and no filtering."""
    try:
        root = ET.fromstring(fragment_xml)
        order = next(node for node in root.iter() if local_name(node.tag) == 'knuthBendixOrder')
        if order.findtext('w0') != '1' or order.find('argumentFilter') is not None:
            return None
        weights, ranks = {}, {}
        for entry in order.findall('./precedenceWeight/precedenceWeightEntry'):
            name = interpretation_symbol_name(entry)
            weight, rank = int(entry.findtext('weight')), int(entry.findtext('precedence'))
            if name is None or name in weights or weight < 0 or rank < 0:
                return None
            weights[name], ranks[name] = weight, rank
        if not weights:
            return None
        classes = {rank: i for i, rank in enumerate(sorted(set(ranks.values()), reverse=True))}
        ranks = {name: classes[rank] for name, rank in ranks.items()}
        return [sorted(ranks, key=lambda name: (ranks[name], name)), ranks, weights]
    except (ET.ParseError, StopIteration, ValueError, TypeError):
        return None


def path_order_witness(fragment_xml: str) -> list[object] | None:
    """Extract an exact CPF recursive-path-order witness.

    Positions are converted from CPF's one-based convention to Ferrum's
    zero-based argument filters.  The resulting JSON is the stable wire form
    consumed by ``exact-path-order``; live replay rechecks all comparisons.
    """
    try:
        fragment = ET.fromstring(fragment_xml)
    except ET.ParseError:
        return None
    container = next(
        (
            element
            for element in fragment.iter()
            if local_name(element.tag) == "recursivePathOrder"
        ),
        None,
    )
    if container is None:
        return None
    status_container = next(
        (child for child in container if local_name(child.tag) == "statusPrecedence"),
        None,
    )
    if status_container is None:
        return None
    statuses: dict[str, str] = {}
    ranks: dict[str, int] = {}
    for entry in status_container:
        if local_name(entry.tag) != "statusPrecedenceEntry":
            continue
        name = interpretation_symbol_name(entry)
        rank_text = next(
            (
                (child.text or "").strip()
                for child in entry
                if local_name(child.tag) == "precedence"
            ),
            "",
        )
        try:
            rank = int(rank_text)
        except ValueError:
            return None
        status = (
            "Lpo"
            if any(local_name(child.tag) == "lex" for child in entry)
            else "Rpo"
            if any(local_name(child.tag) == "mul" for child in entry)
            else None
        )
        if name is None or status is None or rank < 0:
            return None
        statuses[name] = status
        ranks[name] = rank
    if not ranks:
        return None
    # CPF assigns larger precedence numbers to stronger symbols, whereas
    # Ferrum's path-order checker uses rank 0 for the strongest equivalence
    # class.  Retain the complete ordering (including quasi-precedence ties),
    # but normalize away irrelevant gaps in CPF's numeric representation.
    cpf_rank_classes = {
        rank: index
        for index, rank in enumerate(sorted(set(ranks.values()), reverse=True))
    }
    ranks = {name: cpf_rank_classes[rank] for name, rank in ranks.items()}
    precedence = sorted(ranks, key=lambda name: (ranks[name], name))
    default_order = (
        "Lpo"
        if sum(status == "Lpo" for status in statuses.values()) * 2 > len(statuses)
        else "Rpo"
    )
    argument_filter: dict[str, dict[str, object]] = {}
    filter_container = next(
        (child for child in container if local_name(child.tag) == "argumentFilter"),
        None,
    )
    if filter_container is not None:
        for entry in filter_container:
            if local_name(entry.tag) != "argumentFilterEntry":
                continue
            name = interpretation_symbol_name(entry)
            collapsing = next(
                (child for child in entry if local_name(child.tag) == "collapsing"),
                None,
            )
            noncollapsing = next(
                (child for child in entry if local_name(child.tag) == "nonCollapsing"),
                None,
            )
            if name is None or (collapsing is None) == (noncollapsing is None):
                return None
            if collapsing is not None:
                try:
                    position = int((collapsing.text or "").strip()) - 1
                except ValueError:
                    return None
                if position < 0:
                    return None
                argument_filter[name] = {"Collapsing": position}
            else:
                positions: list[int] = []
                assert noncollapsing is not None
                for child in noncollapsing:
                    if local_name(child.tag) != "position":
                        continue
                    try:
                        position = int((child.text or "").strip()) - 1
                    except ValueError:
                        return None
                    if position < 0:
                        return None
                    positions.append(position)
                argument_filter[name] = {"NonCollapsing": positions}
    return [default_order, statuses, precedence, ranks, argument_filter]


def rational_linear_polynomial_witness(
    fragment_xml: str,
) -> tuple[int, list[list[object]]] | None:
    """Extract an affine rational model as shared-denominator numerators."""
    try:
        fragment = ET.fromstring(fragment_xml)
    except ET.ParseError:
        return None
    container = next(
        (
            element
            for element in fragment.iter()
            if local_name(element.tag) == "interpretation"
            and any(local_name(child.tag) == "rationals" for child in element.iter())
        ),
        None,
    )
    if container is None:
        return None

    def affine(
        element: ET.Element, arity: int
    ) -> tuple[Fraction, list[Fraction]] | None:
        tag = local_name(element.tag)
        children = list(element)
        if tag == "integer" and not children:
            try:
                return Fraction(int((element.text or "").strip())), [Fraction(0)] * arity
            except ValueError:
                return None
        if tag == "rational":
            try:
                numerator = int(next(child for child in children if local_name(child.tag) == "numerator").text or "")
                denominator = int(next(child for child in children if local_name(child.tag) == "denominator").text or "")
                return Fraction(numerator, denominator), [Fraction(0)] * arity
            except (StopIteration, ValueError, ZeroDivisionError):
                return None
        if tag == "variable" and not children:
            try:
                index = int((element.text or "").strip()) - 1
            except ValueError:
                return None
            if not 0 <= index < arity:
                return None
            coefficients = [Fraction(0)] * arity
            coefficients[index] = Fraction(1)
            return Fraction(0), coefficients
        if tag == "sum":
            total = (Fraction(0), [Fraction(0)] * arity)
            for child in children:
                value = affine(child, arity)
                if value is None:
                    return None
                total = (
                    total[0] + value[0],
                    [left + right for left, right in zip(total[1], value[1])],
                )
            return total
        if tag == "product" and len(children) == 2:
            left = affine(children[0], arity)
            right = affine(children[1], arity)
            if left is None or right is None:
                return None
            if any(left[1]) and any(right[1]):
                return None
            if any(left[1]):
                if any(right[1]):
                    return None
                return left[0] * right[0], [value * right[0] for value in left[1]]
            if any(right[1]):
                return left[0] * right[0], [value * left[0] for value in right[1]]
            return left[0] * right[0], [Fraction(0)] * arity
        return None

    values: list[tuple[str, Fraction, list[Fraction]]] = []
    denominator = 1
    for interpretation in (
        element for element in list(container) if local_name(element.tag) == "interpret"
    ):
        name = interpretation_symbol_name(interpretation)
        arity_text = next(
            ((child.text or "").strip() for child in interpretation if local_name(child.tag) == "arity"),
            "",
        )
        expression = next(
            (
                child
                for child in interpretation
                if local_name(child.tag) not in {"name", "sharp", "labeledSymbol", "arity"}
            ),
            None,
        )
        try:
            arity = int(arity_text)
        except ValueError:
            return None
        if name is None or expression is None:
            return None
        value = affine(expression, arity)
        if value is None or value[0] < 0 or any(coefficient < 0 for coefficient in value[1]):
            return None
        values.append((name, value[0], value[1]))
        for coefficient in (value[0], *value[1]):
            denominator = math.lcm(denominator, coefficient.denominator)
    if not values:
        return None
    witness = [
        [
            name,
            int(constant * denominator),
            [int(coefficient * denominator) for coefficient in coefficients],
        ]
        for name, constant, coefficients in values
    ]
    return denominator, witness


def event_outcome(processor: str, proof_fragment: str) -> tuple[str, str]:
    if processor in {"loop", "nonLoop"}:
        return "solved", "closed"
    if processor in {
        "constantToUnary",
        "stringReversal",
        "constantToUnary",
        "switchFullStrategy",
        "switchInnermost",
        "switchInnermostProc",
        "aaeccInnermost",
        "uncurry",
        "uncurryProc",
        "gm04CompleteTransformation",
        "gm04CompleteFullTransformation",
        "gm04CompleteNonterminationTransformation",
    }:
        return "transformed", "strong"
    try:
        root = ET.fromstring(proof_fragment)
    except ET.ParseError:
        root = None
    recursive_proofs = (
        [
            elem
            for elem in root.iter()
            if elem is not root
            and local_name(elem.tag)
            in {
                "trsTerminationProof",
                "trsNonterminationProof",
                "dpProof",
                "dpNonterminationProof",
                "csrTerminationProof",
                "csrDpProof",
            }
        ]
        if root is not None
        else []
    )
    if not recursive_proofs:
        return "solved", "closed"
    terminal_steps = {
        "pIsEmpty",
        "rIsEmpty",
        "sIsEmpty",
        "loop",
        "nonLoop",
    }
    if all(
        (step := next(iter(proof), None)) is not None
        and local_name(step.tag) in terminal_steps
        for proof in recursive_proofs
    ):
        return "solved", "closed"
    return "transformed", "strong"


def cpf_version(path: Path) -> str:
    with path.open(encoding="utf-8", errors="ignore") as source:
        prefix = source.read(500)
    return "cpf4" if "4.0" in prefix else "cpf3"


def result_path_for_proof(proof_path: Path) -> Path:
    """Locate either a nested-run result or a flat event-collector result."""
    if proof_path.name in {"proof.cpf.xml", "proof.cpf3.xml"}:
        return proof_path.with_name("result.json")
    for suffix in (".cpf3.xml", ".cpf.xml"):
        if proof_path.name.endswith(suffix):
            return proof_path.with_name(
                proof_path.name.removesuffix(suffix) + ".result.json"
            )
    return proof_path.with_name("result.json")


def adjacent_event_identity(proof_path: Path) -> tuple[str | None, str | None]:
    """Recover benchmark identity when a flat certified run has no result JSON.

    Flat/manual proof captures commonly retain ``events.jsonl`` and the CPF but
    no ``result.json``.  Calling such a benchmark ``proof.cpf.xml`` prevents
    every exact nested runtime state from matching its event, even though the
    events are the producer's authoritative identity record.  Prefer a solved
    event and otherwise use the first well-formed event; category qualification
    is handled by the existing identity normalizer downstream.
    """
    event_path = adjacent_event_file(proof_path)
    if event_path is None:
        return None, None
    fallback: tuple[str, str | None] | None = None
    for line in event_path.read_text(encoding="utf-8", errors="replace").splitlines():
        try:
            event = json.loads(line)
        except json.JSONDecodeError:
            continue
        problem_id = event.get("problem_id")
        category = event.get("category")
        if not isinstance(problem_id, str) or not problem_id.strip():
            continue
        normalized_category = (
            category if isinstance(category, str) and category.strip() else None
        )
        normalized_problem_id = problem_identity(problem_id)
        problem_id = normalized_problem_id
        if (
            normalized_category is not None
            and normalized_category.startswith(("TRS_", "SRS_"))
            and not normalized_problem_id.startswith(("TRS_", "SRS_"))
        ):
            problem_id = f"{normalized_category}/{normalized_problem_id}"
        item = (
            problem_id,
            normalized_category,
        )
        if fallback is None:
            fallback = item
        if event.get("outcome") == "solved":
            return item
    return fallback if fallback is not None else (None, None)


def certified_result_polarity(result: dict) -> str | None:
    if result.get("certified") is not True:
        return None
    status = str(result.get("status", "")).strip().lower()
    if status in {"yes", "terminating"}:
        return "YES"
    if status in {"no", "nonterminating"}:
        return "NO"
    return None


def proof_polarity(root: ET.Element) -> str | None:
    """Read the claimed result from a CPF without trusting adjacent metadata."""
    answer = next(
        (element for element in root.iter() if local_name(element.tag) == "answer"),
        None,
    )
    if answer is not None:
        child = next(iter(answer), None)
        if child is not None:
            tag = local_name(child.tag).lower()
            if tag == "yes":
                return "YES"
            if tag == "no":
                return "NO"
    # CPF 2 certificates predate the explicit <answer> element.  Their proof
    # root still states the claimed property unambiguously, and CeTA checks
    # that very proof below.  Infer only from the complete top-level proof
    # constructor; never from an adjacent solver-status preamble.
    proof = next(
        (element for element in root if local_name(element.tag) == "proof"),
        None,
    )
    proof_child = next(iter(proof), None) if proof is not None else None
    if proof_child is not None:
        tag = local_name(proof_child.tag)
        if tag in {"trsTerminationProof", "srsTerminationProof"}:
            return "YES"
        if tag in {"trsNonterminationProof", "srsNonterminationProof"}:
            return "NO"
    return None


def cpf_root_in_schema_order(root: ET.Element) -> ET.Element:
    """Repair legacy CPF writers that placed cpfVersion after the input.

    Some archived certificates were accepted by the contemporaneous checker
    despite emitting the root children as input, cpfVersion, proof, origin.
    The current parser requires the schema order.  This is a purely syntactic
    permutation of complete top-level elements; the proof and problem are not
    changed.
    """
    children = list(root)
    version_position = next(
        (
            position
            for position, child in enumerate(children)
            if local_name(child.tag) == "cpfVersion"
        ),
        None,
    )
    has_lookup_tables = any(
        local_name(child.tag) == "lookupTables" for child in children
    )
    if version_position is None or (version_position == 0 and has_lookup_tables):
        return root
    ordered = copy.deepcopy(root)
    if not has_lookup_tables:
        ordered.insert(0, ET.Element("lookupTables"))
    rank = {
        "cpfVersion": 0,
        "lookupTables": 1,
        "input": 2,
        "answer": 3,
        "proof": 4,
        "origin": 5,
    }
    ordered[:] = sorted(
        list(ordered),
        key=lambda child: rank.get(local_name(child.tag), len(rank)),
    )
    return ordered


def ceta_certified_polarity(
    proof_path: Path, ceta: Path, timeout: float
) -> tuple[str | None, str]:
    """Require two independent successful checks of the same complete CPF."""
    root = load_xml(str(proof_path), None)
    if root is None:
        return None, "parse-failed"
    polarity = proof_polarity(root)
    if polarity is None:
        return None, "missing-answer"
    checker_path = proof_path
    temporary: tempfile.TemporaryDirectory[str] | None = None
    try:
        raw = proof_path.read_text(encoding="utf-8", errors="replace")
        xml_start = raw.find("<?xml")
        if xml_start < 0:
            xml_start = raw.find("<certificationProblem")
        ordered_root = cpf_root_in_schema_order(root)
        if ordered_root is not root:
            # The same legacy CPF 2 writers that emitted cpfVersion after the
            # input also used the old lhs/rhs/arg term wrappers.  The current
            # checker accepts the proof vocabulary, but its CPF3-compatible
            # parser expects the normalized direct-term representation.  This
            # is a syntax-only conversion; all rules, processors, and proof
            # witnesses remain unchanged and are checked twice below.
            normalize_cpf2_terms(ordered_root)
            temporary = tempfile.TemporaryDirectory(prefix="ferrum-ceta-cpf-")
            checker_path = Path(temporary.name) / "proof.xml"
            checker_path.write_text(
                ET.tostring(ordered_root, encoding="unicode"), encoding="utf-8"
            )
        elif xml_start > 0 and raw[:xml_start].strip():
            temporary = tempfile.TemporaryDirectory(prefix="ferrum-ceta-cpf-")
            checker_path = Path(temporary.name) / "proof.xml"
            checker_path.write_text(raw[xml_start:], encoding="utf-8")
        for attempt in range(2):
            try:
                checked = subprocess.run(
                    [str(ceta), str(checker_path)],
                    text=True,
                    stdout=subprocess.PIPE,
                    stderr=subprocess.STDOUT,
                    timeout=timeout,
                )
            except subprocess.TimeoutExpired:
                return None, f"checker-timeout-{attempt + 1}"
            if checked.returncode != 0 or "CERTIFIED" not in checked.stdout.upper():
                return None, f"checker-rejected-{attempt + 1}"
    finally:
        if temporary is not None:
            temporary.cleanup()
    return polarity, "certified-twice"


def proof_files(root: Path) -> set[Path]:
    """Find complete CPF artifacts while also accepting a direct file path."""
    if root.is_file():
        return {root}
    if not root.is_dir():
        return set()
    proofs: set[Path] = set()
    for pattern in ("*.cpf", "*.cpf.xml", "*.cpf3.xml", "proof.xml"):
        proofs.update(root.rglob(pattern))
    for path in root.rglob("*.txt"):
        if not path.is_file():
            continue
        try:
            prefix = path.read_text(encoding="utf-8", errors="replace")[:65536]
        except OSError:
            continue
        if "<certificationProblem" in prefix or "<?xml" in prefix:
            proofs.add(path)
    return {
        path
        for path in proofs
        if path.is_file() and not path.name.endswith(".input.xml")
    }


def manifest_evidence_roots(path: Path) -> list[Path]:
    rows = json.loads(path.read_text(encoding="utf-8"))
    roots: list[Path] = []
    for row in rows:
        for raw in row.get("evidence_locations", []):
            candidate = Path(raw)
            if not candidate.exists() and candidate.parts[:1] == ("ferrum",):
                candidate = Path(*candidate.parts[1:])
            roots.append(candidate)
    return roots


def unresolved_problem_paths_from_details(
    path: Path,
    statuses: set[str],
    include_uncertified_yes: bool,
) -> set[str]:
    """Select TPDB-relative roots from a prior TermCOMP details file."""
    payload = json.loads(path.read_text(encoding="utf-8"))
    rows = payload if isinstance(payload, list) else payload.get("details", [])
    selected: set[str] = set()
    for row in rows:
        if not isinstance(row, dict):
            continue
        status = str(row.get("status") or "").strip().lower()
        if status not in statuses and not (
            include_uncertified_yes
            and status in {"yes", "terminating", "no", "nonterminating"}
            and not bool(row.get("certified"))
        ):
            continue
        raw = str(row.get("path") or row.get("problem") or "").replace("\\", "/")
        marker = "TPDB-ARI/"
        if marker in raw:
            raw = raw.split(marker, 1)[1]
        raw = raw.lstrip("./")
        if raw:
            selected.add(raw)
    return selected


def typed_problem_kind(cpf: str) -> tuple[str, str]:
    """Classify the full typed obligation without dropping its strategy."""
    lowered = cpf.lower()
    is_dp = "<dpinput" in lowered
    is_csr = "<contextsensitive" in lowered
    is_minimal = "<minimal>true" in lowered
    if is_dp and is_csr:
        return (
            "context-sensitive-dependency-pair",
            "qcs-dp" if is_minimal else "csdp",
        )
    if is_dp:
        return ("dependency-pair", "qdp" if is_minimal else "dp")
    if is_csr:
        return ("context-sensitive", "csr")
    if "<srsinput" in lowered or "<string" in lowered or "<word" in lowered:
        return ("top-level", "srs")
    if "<innermost" in lowered:
        return ("top-level", "innermost-trs")
    return ("top-level", "trs")


def typed_pool_context(cpf: str) -> tuple[str, ...]:
    """Return the sound compatibility class for root-local atom pooling.

    Root-local pooling deliberately tries a certified proof's atoms on other
    live states of the same root.  A level such as ``dependency-pair`` is not
    a sufficient type: improved, safe, and conservative CSR-DP constructions
    have different proof obligations even when their visible pairs overlap.
    Keep those constructions separate while still allowing atoms to move
    between residuals produced by the same construction.  The QCS-usable flag
    is deliberately not part of this pool type: it is search metadata that has
    drifted across versions, while exact usable-rule atoms are revalidated
    against the live closure by Ferrum.
    """
    level, problem_kind = typed_problem_kind(cpf)
    if level != "context-sensitive-dependency-pair":
        return (level, problem_kind)
    try:
        root = ET.fromstring(cpf)
    except ET.ParseError:
        return (level, problem_kind, "unparsed")

    context = next(
        (
            node
            for node in root.iter()
            if local_name(node.tag) == "ferrumCsrDpContext"
        ),
        None,
    )
    if context is None:
        return (level, problem_kind, "unspecified")

    fields: dict[str, str] = {}
    for child in context:
        fields[local_name(child.tag)] = (child.text or "").strip().lower()
    return (
        level,
        problem_kind,
        fields.get("construction", "unspecified"),
        fields.get("graphEstimator", "unspecified"),
    )


def root_local_atom_is_portable(atom: str) -> bool:
    """Whether an atom may be offered to sibling states of one root proof."""
    if atom == "utility-guidance":
        return False
    if atom.startswith(
        (
            # Terminal witnesses already carry their complete source DP
            # obligation.  They belong on that independently keyed state;
            # broadcasting them to siblings only creates inapplicable exact
            # candidates that can shadow a valid transformation chain.
            "exact-dp-loop(",
            "exact-dp-nonloop(",
            "exact-dp-nontermination-proof(",
            "exact-innermost-lhss(",
            "exact-subterm(",
        )
    ):
        return False
    return not any(
        marker in atom
        for marker in (";", "parallel(", "choice(", "pipeline(", "csr(exhaust(")
    )


def reduction_pair_model_atoms(atom: str) -> list[str]:
    """Recover reusable models, not source-bound CPF processor claims.

    These atoms must remain weak hints on sibling states. Their native
    processors independently check live R/P/Q obligations and construct a
    fresh proof; the original deletion indices and filters are not assumed.
    """
    prefix = "exact-red-pair(hex="
    if not atom.startswith(prefix) or not atom.endswith(")"):
        return []
    try:
        payload = json.loads(bytes.fromhex(atom[len(prefix):-1]))
        if not isinstance(payload, list) or len(payload) < 2 or not isinstance(payload[1], str):
            return []
        fragment = "<modelHint>" + payload[1] + "</modelHint>"
        ET.fromstring(fragment)
    except (ValueError, TypeError, UnicodeDecodeError, ET.ParseError):
        return []
    atoms = []
    for family, extract in (
        ("exact-matrix", natural_matrix_witness),
        ("exact-integer-matrix", integer_matrix_witness),
        ("exact-arctic", arctic_matrix_witness),
        ("exact-poly", linear_polynomial_witness),
        ("exact-rat-poly", rational_linear_polynomial_witness),
    ):
        witness = extract(fragment)
        if witness is not None:
            encoded = json.dumps(witness, ensure_ascii=False, separators=(",", ":")).encode().hex()
            atoms.append(f"{family}(hex={encoded})")
            if family == "exact-poly" and payload[0] in {"monoRedPairProc", "monoRedPairUrProc", "innermostMonoRedPairProc"}:
                atoms.append(f"exact-mono-poly(hex={encoded})")
    return atoms


def exact_red_pair_processor_tag(atom: str) -> str | None:
    """Decode the CPF processor tag carried by an exact red-pair atom."""
    prefix = "exact-red-pair(hex="
    if not atom.startswith(prefix) or not atom.endswith(")"):
        return None
    try:
        payload = json.loads(bytes.fromhex(atom[len(prefix) : -1]))
    except (ValueError, json.JSONDecodeError, UnicodeDecodeError):
        return None
    if not isinstance(payload, list) or not payload or not isinstance(payload[0], str):
        return None
    return payload[0]


def exact_graph_same_step(left: str, right: str) -> bool:
    """Recognize one graph decomposition across archived/live state context.

    An exact graph atom contains ``[source_dp_input, components]``.  The CPF
    walker reconstructs the semantic source obligation, whereas a current
    runtime event also serializes Ferrum-only bookkeeping in that source.
    Requiring byte-identical atoms therefore misclassifies the very same
    certified graph node as a backtracked attempt.  Compare the complete
    component specification and the contextless typed source state instead;
    replay still validates the exact atom against the live input key.
    """

    prefix = "exact-graph(hex="

    def decode(atom: str) -> tuple[str, object] | None:
        if not atom.startswith(prefix) or not atom.endswith(")"):
            return None
        try:
            value = json.loads(bytes.fromhex(atom[len(prefix) : -1]))
        except (ValueError, json.JSONDecodeError, UnicodeDecodeError):
            return None
        if (
            not isinstance(value, list)
            or len(value) != 2
            or not isinstance(value[0], str)
            or not isinstance(value[1], list)
        ):
            return None
        return value[0], value[1]

    lhs = decode(left)
    rhs = decode(right)
    if lhs is None or rhs is None or lhs[1] != rhs[1]:
        return False
    lhs_signature = contextless_runtime_state_signature(lhs[0])
    rhs_signature = contextless_runtime_state_signature(rhs[0])
    return lhs_signature is not None and lhs_signature == rhs_signature


def exact_graph_cyclic_shape(atom: str) -> tuple[int, ...] | None:
    """Return cyclic component sizes without decoding the bulky source state.

    This deliberately partial discriminator is used only by
    ``bind_runtime_exact_graph_atoms`` after an exact raw input key and a
    unique successful adjacent runtime atom have already been established.
    CPF reconstruction can choose a different equal-pair representative when
    mapping recursive graph children back to source indices; the number and
    cardinality of the cyclic obligations remain invariant.
    """
    prefix = "exact-graph(hex="
    if not atom.startswith(prefix) or not atom.endswith(")"):
        return None
    try:
        value = json.loads(bytes.fromhex(atom[len(prefix) : -1]))
    except (ValueError, json.JSONDecodeError, UnicodeDecodeError):
        return None
    if (
        not isinstance(value, list)
        or len(value) != 2
        or not isinstance(value[0], str)
        or not isinstance(value[1], list)
    ):
        return None
    sizes = []
    for component in value[1]:
        if (
            not isinstance(component, list)
            or len(component) != 2
            or not isinstance(component[0], list)
            or not isinstance(component[1], bool)
        ):
            return None
        if component[1]:
            sizes.append(len(component[0]))
    return tuple(sorted(sizes))


def exact_red_pair_is_context_bound(atom: str) -> bool:
    """Whether an exact red-pair atom carries its complete source DP state.

    The five-field encoding contains the processor payload, removed indices,
    source pairs, and source active rules.  Ferrum compares both source
    containers with the live state before applying the processor, so these
    atoms may safely be offered to sibling residual hashes of the same root.
    This is deliberately narrower than general root-local atom pooling.
    """
    prefix = "exact-red-pair(hex="
    if not atom.startswith(prefix) or not atom.endswith(")"):
        return False
    try:
        payload = json.loads(bytes.fromhex(atom[len(prefix) : -1]))
    except (ValueError, json.JSONDecodeError, UnicodeDecodeError):
        return False
    return (
        isinstance(payload, list)
        and len(payload) == 5
        and all(isinstance(value, str) for value in (payload[0], payload[1], payload[3], payload[4]))
        and isinstance(payload[2], list)
    )


def exact_red_pair_same_step(left: str, right: str) -> bool:
    """Compare legacy and self-contained encodings of one CPF red-pair step.

    Older runtime events encode ``[tag, payload, removed]`` while current
    extraction appends the source pair/rule containers.  Whitespace in the
    CPF payload is immaterial.  This deliberately compares only the common
    certified processor data; the live runtime key supplies the missing
    source-state boundary for a legacy atom.
    """

    prefix = "exact-red-pair(hex="

    def decode(atom: str) -> list[object] | None:
        if not atom.startswith(prefix) or not atom.endswith(")"):
            return None
        try:
            value = json.loads(bytes.fromhex(atom[len(prefix) : -1]))
        except (ValueError, json.JSONDecodeError, UnicodeDecodeError):
            return None
        return value if isinstance(value, list) and len(value) in {3, 5} else None

    def xml_shape(fragment: object) -> tuple | None:
        if not isinstance(fragment, str):
            return None
        try:
            root = ET.fromstring(f"<root>{fragment}</root>")
        except ET.ParseError:
            return None

        def shape(element: ET.Element) -> tuple:
            return (
                local_name(element.tag),
                " ".join((element.text or "").split()),
                tuple(shape(child) for child in element),
            )

        return tuple(shape(child) for child in root)

    lhs = decode(left)
    rhs = decode(right)
    return bool(
        lhs is not None
        and rhs is not None
        and isinstance(lhs[0], str)
        and lhs[0] == rhs[0]
        and isinstance(lhs[2], list)
        and lhs[2] == rhs[2]
        and xml_shape(lhs[1]) is not None
        and xml_shape(lhs[1]) == xml_shape(rhs[1])
    )


@functools.lru_cache(maxsize=128)
def exact_red_pair_step_fingerprint(atom: str) -> str | None:
    """Identify one retained reduction-pair edge independently of context.

    The complete source P/R containers remain in the executable atom and are
    revalidated by Ferrum.  For causal child lookup we need only identify the
    certified processor prefix itself, because a semantic-labeling relocation
    may rename every symbol between the archived and live child cores.
    """
    prefix = "exact-red-pair(hex="
    if not atom.startswith(prefix) or not atom.endswith(")"):
        return None
    try:
        decoded = json.loads(bytes.fromhex(atom[len(prefix) : -1]))
    except (ValueError, json.JSONDecodeError, UnicodeDecodeError):
        return None
    if (
        not isinstance(decoded, list)
        or len(decoded) not in {3, 5, 7}
        or not isinstance(decoded[0], str)
        or not isinstance(decoded[1], str)
        or not isinstance(decoded[2], list)
    ):
        return None
    try:
        root = ET.fromstring(f"<root>{decoded[1]}</root>")
    except ET.ParseError:
        return None

    def shape(element: ET.Element) -> tuple:
        return (
            local_name(element.tag),
            " ".join((element.text or "").split()),
            tuple(shape(child) for child in element),
        )

    material = json.dumps(
        [decoded[0], decoded[2], [shape(child) for child in root]],
        ensure_ascii=False,
        separators=(",", ":"),
    ).encode("utf-8")
    return hashlib.sha256(material).hexdigest()


@functools.lru_cache(maxsize=128)
def exact_general_red_pair_step_fingerprint(atom: str) -> str | None:
    """Identify one retained general reduction-pair edge semantically.

    Runtime rebinding may change CPF's numeric symbol spelling from ``0`` to
    ``|0|`` and may reformat the payload XML.  Hashing the atom bytes then
    disconnects both ordered successors from their certified parent.  The
    processor still validates the requested strict/bound rules against the
    live state, so a normalized XML shape plus the two index sets and merge
    flag is the appropriate causal identity.
    """

    prefix = "exact-general-red-pair(hex="
    if not atom.startswith(prefix) or not atom.endswith(")"):
        return None
    try:
        decoded = json.loads(bytes.fromhex(atom[len(prefix) : -1]))
    except (ValueError, json.JSONDecodeError, UnicodeDecodeError):
        return None
    if (
        not isinstance(decoded, list)
        or len(decoded) not in {4, 5}
        or not isinstance(decoded[0], str)
        or not isinstance(decoded[1], list)
        or not isinstance(decoded[2], list)
        or not isinstance(decoded[3], bool)
    ):
        return None
    try:
        root = ET.fromstring(f"<root>{decoded[0]}</root>")
    except ET.ParseError:
        return None

    def shape(element: ET.Element) -> tuple:
        text = " ".join((element.text or "").split())
        if local_name(element.tag) == "name":
            unquoted = text[1:-1] if text.startswith("|") and text.endswith("|") else text
            if unquoted and unquoted[0].isdigit():
                text = unquoted
        return (
            local_name(element.tag),
            text,
            tuple(shape(child) for child in element),
        )

    # Numeric indices are an ordering-dependent projection of the strict and
    # bound rule containers already present in the payload.  Exact replay
    # relocates and validates those rules on the live pair ordering, so the
    # indices must not split one causal edge into two identities.
    material = json.dumps(
        [decoded[3], [shape(child) for child in root]],
        ensure_ascii=False,
        separators=(",", ":"),
    ).encode("utf-8")
    return hashlib.sha256(material).hexdigest()


@functools.lru_cache(maxsize=128)
def exact_causal_atom_fingerprint(atom: str) -> str | None:
    """Identify a self-contained exact processor edge.

    Exact atoms embed the retained source obligation and witness.  Hashing the
    whole atom therefore gives a safe bridge from that certified parent row to
    the one live residual it materialized, even when the child uses fresh
    names or newer typed context.  Reduction pairs retain their established
    structural fingerprint because semantic labeling can relocate their full
    source signature.
    """
    red_pair = exact_red_pair_step_fingerprint(atom)
    if red_pair is not None:
        return "red-pair:" + red_pair
    general_red_pair = exact_general_red_pair_step_fingerprint(atom)
    if general_red_pair is not None:
        return "general-red-pair:" + general_red_pair
    if not re.fullmatch(r"exact-[a-z0-9-]+\(hex=[0-9a-fA-F]+\)", atom):
        return None
    return "exact:" + hashlib.sha256(atom.encode("utf-8")).hexdigest()


def rebind_context_bound_red_pair_atom(atom: str, live_cpf: str) -> str:
    """Spell a self-contained red-pair witness in the live signature.

    A pooled bound atom must retain its certified source P/R obligation so
    Ferrum can decide whether it applies to the sibling state.  Only numeric
    TPDB aliases are adjusted to the spelling used by that live obligation.
    """
    prefix = "exact-red-pair(hex="
    if not exact_red_pair_is_context_bound(atom):
        return atom
    try:
        payload = json.loads(bytes.fromhex(atom[len(prefix) : -1]))
    except (ValueError, json.JSONDecodeError, UnicodeDecodeError):
        return atom
    for index in (1, 3, 4):
        payload[index] = align_fragment_numeric_symbols(payload[index], live_cpf)
    encoded = json.dumps(
        payload, ensure_ascii=False, separators=(",", ":")
    ).encode("utf-8").hex()
    return f"{prefix}{encoded})"


def effective_rule_count(cpf: str) -> int | None:
    """Count the live R component used by a DP reduction-pair processor."""
    try:
        root = ET.fromstring(cpf)
    except ET.ParseError:
        return None
    if local_name(root.tag) == "input":
        root = next(
            (child for child in root if local_name(child.tag) == "dpInput"),
            root,
        )
    usable = next(
        (child for child in root if local_name(child.tag) == "usableRules"),
        None,
    )
    container = (
        usable
        if usable is not None
        else next(
            (child for child in root if local_name(child.tag) == "trs"),
            None,
        )
    )
    if container is None:
        return None
    rules = next(
        (child for child in container if local_name(child.tag) == "rules"),
        None,
    )
    return (
        sum(1 for child in rules if local_name(child.tag) == "rule")
        if rules is not None
        else 0
    )


def effective_pair_count(cpf: str) -> int | None:
    """Count the dependency-pair multiset of a typed live obligation."""
    try:
        root = ET.fromstring(cpf)
    except ET.ParseError:
        return None
    if local_name(root.tag) == "input":
        root = next(
            (child for child in root if local_name(child.tag) == "dpInput"),
            root,
        )
    dps = next((child for child in root if local_name(child.tag) == "dps"), None)
    rules = (
        next((child for child in dps if local_name(child.tag) == "rules"), None)
        if dps is not None
        else None
    )
    return (
        sum(1 for child in rules if local_name(child.tag) == "rule")
        if rules is not None
        else 0
    )


def root_local_atom_shape_compatible(atom: str, source_cpf: str, live_cpf: str) -> bool:
    """Cheap necessary conditions before offering a guarded exact atom.

    The executable processors still perform the authoritative term-level
    applicability check.  These count gates prevent a large certified proof
    from broadcasting hundreds of obviously inapplicable XML witnesses to
    every residual of the root and consuming the strict replay deadline.
    """
    source_pairs = effective_pair_count(source_cpf)
    live_pairs = effective_pair_count(live_cpf)
    source_rules = effective_rule_count(source_cpf)
    live_rules = effective_rule_count(live_cpf)
    if atom.startswith("exact-graph("):
        return (
            source_pairs is not None
            and live_pairs is not None
            and source_rules == live_rules
            and source_pairs <= live_pairs <= source_pairs + 8
        )
    if atom.startswith(
        (
            "exact-dp-transform(",
            "exact-dp-no-rule-removal(",
            "exact-dp-proof(",
            "exact-red-pair(",
            "exact-usable-rules(",
            "exact-semantic-labeling(",
        )
    ):
        return source_pairs == live_pairs and source_rules == live_rules
    if atom.startswith(("exact-size-change(", "exact-subterm(")):
        return source_pairs == live_pairs
    return True


def typed_strategy_atom(candidate: str, problem_kind: str, category: str = "") -> str:
    """Preserve the problem-family-specific executable processor choice."""
    if (
        problem_kind == "csr" or category == "TRS_Contextsensitive"
    ) and candidate == "nontermination(loop)":
        return "csr-loop"
    if (
        problem_kind == "srs" or category.startswith("SRS_")
    ) and candidate == "nontermination(loop)":
        return "nontermination(srs-loop)"
    return candidate


def root_uncurry_row(root: ET.Element) -> dict | None:
    """Recover the root uncurrying transformation omitted by exact-row extraction."""
    input_node = next(
        (element for element in root if local_name(element.tag) == "input"),
        None,
    )
    if input_node is None or unwrap_input(ET.tostring(input_node, encoding="unicode")) is None:
        return None
    uncurry = next(
        (element for element in root.iter() if local_name(element.tag) == "uncurry"),
        None,
    )
    if uncurry is None:
        return None
    return {
        "metadata": {
            "processor_tag": "uncurry",
            "path": ["certificationProblem", "proof", "trsTerminationProof", "uncurry"],
        },
        "input": {
            "problem_xml": ET.tostring(
                input_node,
                encoding="unicode",
                short_empty_elements=True,
            )
        },
        "output_xml": ET.tostring(
            uncurry,
            encoding="unicode",
            short_empty_elements=True,
        ),
    }


def root_dp_uncurry_row(root: ET.Element) -> dict | None:
    """Recover a DP applicative-top uncurrying step omitted by exact extraction."""
    input_node = next(
        (element for element in root if local_name(element.tag) == "input"),
        None,
    )
    if input_node is None:
        return None
    problem_xml = unwrap_input(ET.tostring(input_node, encoding="unicode"))
    if problem_xml is None or "<dpInput" not in problem_xml:
        return None
    uncurry = next(
        (element for element in root.iter() if local_name(element.tag) == "uncurryProc"),
        None,
    )
    if uncurry is None:
        return None
    return {
        "metadata": {
            "processor_tag": "uncurryProc",
            "path": ["certificationProblem", "proof", "dpProof", "uncurryProc"],
        },
        "input": {
            "problem_xml": ET.tostring(
                input_node,
                encoding="unicode",
                short_empty_elements=True,
            )
        },
        "output_xml": ET.tostring(
            uncurry,
            encoding="unicode",
            short_empty_elements=True,
        ),
    }


def root_direct_processor_row(root: ET.Element) -> dict | None:
    """Recover a root processor hidden below a CPF proof-kind wrapper.

    Exact fragment extraction intentionally focuses on recursive subproofs and
    can omit the first ``dpTrans``/CSR-DP processor below
    ``trsTerminationProof``.  Losing that row leaves only a generic
    ``termination`` recommendation, so an oracle cannot independently select
    the transformation that exposes all retained child states.
    """
    input_node = next(
        (element for element in root if local_name(element.tag) == "input"),
        None,
    )
    proof_node = next(
        (element for element in root if local_name(element.tag) == "proof"),
        None,
    )
    if input_node is None or proof_node is None:
        return None
    problem_xml = unwrap_input(ET.tostring(input_node, encoding="unicode"))
    if problem_xml is None:
        return None
    processor = next(iter(proof_node), None)
    proof_kind = local_name(processor.tag) if processor is not None else None
    wrappers = {
        "trsTerminationProof",
        "trsNonterminationProof",
        "dpProof",
        "dpNonterminationProof",
        "relativeNonterminationProof",
        "csrTerminationProof",
        "srsTerminationProof",
    }
    while processor is not None and local_name(processor.tag) in wrappers:
        processor = next(iter(processor), None)
    if processor is None:
        return None
    processor_tag = local_name(processor.tag)
    if processor_tag != "dpTrans" and processor_tag not in DIRECT_ATOMS:
        return None
    metadata = {
            "processor_tag": processor_tag,
            "path": ["certificationProblem", "proof", processor_tag],
        }
    if processor_tag == "dpTrans":
        metadata["strategy_atom"] = "dp"
    # A top-level dpTrans has the same state transition on the YES and NO
    # sides.  Keep it as ``dp`` so the resulting DP state is independently
    # guided.  Mapping the NO form to a monolithic root DP-loop search loses
    # every certified intermediate state and can spend the whole root budget
    # rediscovering a loop that is already keyed at the final residual.
    return {
        "metadata": metadata,
        "input": {
            "problem_xml": ET.tostring(
                input_node,
                encoding="unicode",
                short_empty_elements=True,
            )
        },
        "output_xml": ET.tostring(
            processor,
            encoding="unicode",
            short_empty_elements=True,
        ),
    }


def certified_probe_root_row(root: ET.Element, result: dict) -> dict | None:
    """Retain the processor actually replayed by a certified standalone probe.

    Ferrum may wrap a probe fragment in infrastructure processors needed for a
    valid CPF (most notably ``depGraphProc``).  Treating that wrapper as the
    root recommendation can make the oracle select an inapplicable graph
    processor and lose the certifiably successful processor that was probed.
    """
    candidate = result.get("strategy_atom")
    outcome = result.get("probe_outcome")
    if (
        not isinstance(candidate, str)
        or not candidate.strip()
        or candidate.strip() == "termination"
        or outcome not in {"solved", "transformed"}
    ):
        return None
    input_node = next(
        (element for element in root if local_name(element.tag) == "input"),
        None,
    )
    proof_node = next(
        (element for element in root if local_name(element.tag) == "proof"),
        None,
    )
    if input_node is None or proof_node is None:
        return None
    if unwrap_input(ET.tostring(input_node, encoding="unicode")) is None:
        return None
    return {
        "metadata": {
            "processor_tag": "certifiedProbeStrategy",
            "strategy_atom": candidate.strip(),
            "outcome": outcome,
            "path": ["certificationProblem", "proof", "certifiedProbeStrategy"],
        },
        "input": {
            "problem_xml": ET.tostring(
                input_node,
                encoding="unicode",
                short_empty_elements=True,
            )
        },
        "output_xml": ET.tostring(
            proof_node,
            encoding="unicode",
            short_empty_elements=True,
        ),
    }


def live_root_problem_key(root: ET.Element, proof_path: Path) -> str | None:
    """Return the runtime raw key of the producing trace's original state."""
    event_path = adjacent_event_file(proof_path)
    input_node = next(
        (element for element in root if local_name(element.tag) == "input"), None
    )
    if event_path is None or input_node is None:
        return None
    problem_xml = unwrap_input(ET.tostring(input_node, encoding="unicode"))
    if problem_xml is None:
        return None
    root_level, _ = typed_problem_kind(problem_xml)
    root_signature = runtime_state_signature(problem_xml)
    fallback: str | None = None
    matched: str | None = None
    for line in event_path.read_text(encoding="utf-8", errors="replace").splitlines():
        try:
            event = json.loads(line)
        except json.JSONDecodeError:
            continue
        # Ferrum records the initial invocation as ``top-level`` even when
        # its typed input is CSR or innermost; subsequent processor events use
        # the more specific level.  Both describe the same root state here.
        if event.get("level") not in {root_level, "top-level"}:
            continue
        event_input = event.get("input") or {}
        key = event_input.get("problem_key")
        if not isinstance(key, str):
            continue
        if fallback is None:
            fallback = key
        event_cpf = event_input.get("cpf")
        if (
            isinstance(event_cpf, str)
            and runtime_state_signature(event_cpf) == root_signature
        ):
            matched = key
    return matched or fallback


def main() -> int:
    sys.setrecursionlimit(max(sys.getrecursionlimit(), 200_000))
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--root",
        type=Path,
        action="append",
        default=[],
        help="proof tree to scan; repeat to build one union from several trees",
    )
    parser.add_argument(
        "--manifest",
        type=Path,
        help="manual replay manifest whose evidence_locations should be scanned",
    )
    parser.add_argument(
        "--runtime-root",
        type=Path,
        action="append",
        default=[],
        help=(
            "current replay tree/event log whose live state keys should be "
            "structurally aliased to certified CPF fragment states"
        ),
    )
    parser.add_argument(
        "--ferrum-canonicalizer",
        type=Path,
        help=(
            "production Ferrum executable used to canonicalize archived and "
            "live states before runtime rebinding"
        ),
    )
    parser.add_argument(
        "--ceta",
        type=Path,
        help="recheck every discovered complete proof twice instead of trusting result.json",
    )
    parser.add_argument("--ceta-timeout", type=float, default=60.0)
    parser.add_argument(
        "--ceta-jobs",
        type=int,
        default=1,
        help="parallel complete-proof CeTA rechecks (each proof is still checked twice)",
    )
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument(
        "--certified-manifest-output",
        type=Path,
        help=(
            "write exact state/action gates for rows recovered from complete "
            "proofs that passed both requested CeTA rechecks"
        ),
    )
    parser.add_argument("--run-id", default="certified-cpf-replay")
    parser.add_argument("--progress-every", type=int, default=50)
    parser.add_argument("--limit", type=int)
    parser.add_argument(
        "--max-proof-bytes",
        type=int,
        help=(
            "defer larger proofs to a separately bounded extraction shard; "
            "the complete proof is still CeTA-checked when that shard runs"
        ),
    )
    parser.add_argument(
        "--problem-file-list",
        type=Path,
        help="restrict extraction to benchmark paths listed one per line",
    )
    parser.add_argument(
        "--problem-details",
        type=Path,
        help="select roots from a prior TermCOMP details JSON file",
    )
    parser.add_argument(
        "--problem-status",
        action="append",
        default=[],
        help="status selected from --problem-details; repeat as needed",
    )
    parser.add_argument(
        "--include-uncertified-yes",
        action="store_true",
        help="also select terminal results whose prior CeTA check failed",
    )
    parser.add_argument(
        "--root-local-atom-pool",
        action="store_true",
        help=(
            "offer independently validated DP atoms from a certified proof "
            "to every live DP residual of the same benchmark"
        ),
    )
    parser.add_argument(
        "--bound-red-pair-pool",
        action="store_true",
        help=(
            "offer only exact reduction-pair atoms that carry and validate "
            "their complete source pair/rule context to live DP residuals "
            "of the same benchmark"
        ),
    )
    parser.add_argument(
        "--proof-chain-only",
        action="store_true",
        help=(
            "use runtime logs only to bind the complete certified CPF chain; "
            "do not append successful runtime trials that are absent from that proof"
        ),
    )
    parser.add_argument(
        "--root-proofs-only",
        action="store_true",
        help=(
            "freeze only complete certified top-level proofs; retain the "
            "lightweight live-root alias but skip recursive runtime-state "
            "canonicalization (useful after a broad certified replay)"
        ),
    )
    parser.add_argument(
        "--runtime-explicit-states-only", action="store_true",
        help="index recorded live inputs/residuals without reconstructing speculative encoded children",
    )
    parser.add_argument(
        "--exclude-complete-proof-atoms",
        action="store_true",
        help=(
            "exclude exact-trs-proof and exact-dp-proof shortcuts while "
            "retaining the independently executable processor chain"
        ),
    )
    args = parser.parse_args()

    global FERRUM_CANONICALIZER
    if args.ferrum_canonicalizer is not None:
        canonicalizer = args.ferrum_canonicalizer.resolve()
        if not canonicalizer.is_file():
            parser.error(f"Ferrum canonicalizer does not exist: {canonicalizer}")
        FERRUM_CANONICALIZER = str(canonicalizer)

    if args.root_proofs_only and args.exclude_complete_proof_atoms:
        parser.error(
            "--root-proofs-only and --exclude-complete-proof-atoms are mutually exclusive"
        )

    scan_roots = list(args.root)
    if args.manifest is not None:
        scan_roots.extend(manifest_evidence_roots(args.manifest))
    if not scan_roots:
        parser.error("at least one --root or --manifest is required")

    discovered: dict[str, tuple[Path, Path]] = {}
    for proof_root in scan_roots:
        for proof in proof_files(proof_root):
            resolved = proof.resolve()
            content_hash = hashlib.sha256(resolved.read_bytes()).hexdigest()
            discovered.setdefault(content_hash, (proof_root, resolved))
    proofs = sorted(
        discovered.values(),
        key=lambda item: (item[0].as_posix(), item[1].as_posix()),
    )
    selected_problem_ids: dict[Path, str] = {}
    wanted: set[str] = set()
    if args.problem_file_list is not None:
        wanted.update({
            line.strip().lstrip("./")
            for line in args.problem_file_list.read_text(encoding="utf-8").splitlines()
            if line.strip() and not line.lstrip().startswith("#")
        })
    if args.problem_details is not None:
        statuses = {
            str(status).strip().lower() for status in args.problem_status
        } or {"unknown", "timeout", "error"}
        wanted.update(
            unresolved_problem_paths_from_details(
                args.problem_details, statuses, args.include_uncertified_yes
            )
        )
    if wanted:

        def selected_proof(item: tuple[Path, Path]) -> bool:
            result_path = result_path_for_proof(item[1])
            matched: str | None = None
            if result_path.exists():
                try:
                    result = json.loads(result_path.read_text(encoding="utf-8"))
                except json.JSONDecodeError:
                    result = {}
                problem = str(result.get("problem_id") or result.get("path") or "")
                matched = problem_selection_matches(problem, wanted)
            else:
                matched = flattened_artifact_problem_identity(item[1], wanted)
            if matched is not None:
                selected_problem_ids[item[1]] = matched
                return True
            return False

        proofs = [item for item in proofs if selected_proof(item)]
    if args.limit is not None:
        proofs = proofs[: args.limit]
    if args.max_proof_bytes is not None:
        if args.max_proof_bytes < 1:
            parser.error("--max-proof-bytes must be positive")
        proofs = [
            item for item in proofs if item[1].stat().st_size <= args.max_proof_bytes
        ]
        # Selection happens before size sharding so that a proof's flattened
        # artifact identity can be resolved once.  Do not, however, retain
        # identities belonging only to a deferred shard: doing so makes the
        # runtime scan ingest their (potentially enormous) event logs even
        # though no source proof in this invocation can use them.
        retained_proof_paths = {proof_path for _, proof_path in proofs}
        selected_problem_ids = {
            proof_path: problem_id
            for proof_path, problem_id in selected_problem_ids.items()
            if proof_path in retained_proof_paths
        }
    if args.ceta_jobs < 1:
        parser.error("--ceta-jobs must be at least 1")
    external_runtime_event_paths = runtime_event_paths(args.runtime_root)
    selected_runtime_problem_ids = set(selected_problem_ids.values())
    if selected_runtime_problem_ids:
        explicit_runtime_files = {path.resolve() for path in args.runtime_root if path.is_file()}
        external_runtime_event_paths = [
            event_path
            for event_path in external_runtime_event_paths
            if event_path.resolve() in explicit_runtime_files or runtime_event_path_matches_problems(
                event_path, selected_runtime_problem_ids
            )
        ]
    if args.root_proofs_only:
        external_runtime_keys = {}
        external_runtime_dp_states = []
        external_runtime_inputs = {}
    else:
        (
            external_runtime_keys,
            external_runtime_dp_states,
            external_runtime_inputs,
        ) = read_runtime_state_aliases(
            external_runtime_event_paths,
            # In root-local pool mode every independently validating atom is
            # offered to the explicit live residual CPFs already stored in the
            # event witness.  Reconstructing every SCC again from the atom's
            # embedded source can take minutes for large graphs and provides no
            # additional state.  Keep the stricter reconstruction for ordinary
            # state-local extraction, where it disambiguates archived children.
            reconstruct_encoded_children=not (args.root_local_atom_pool or args.runtime_explicit_states_only),
        )
    external_runtime_root_keys = read_runtime_root_keys(external_runtime_event_paths)
    certified: dict[Path, tuple[str | None, str]] = {}
    if args.ceta is not None:
        if args.ceta_jobs == 1:
            certified = {
                proof_path: ceta_certified_polarity(
                    proof_path, args.ceta, args.ceta_timeout
                )
                for _, proof_path in proofs
            }
        else:
            with concurrent.futures.ThreadPoolExecutor(
                max_workers=args.ceta_jobs
            ) as executor:
                pending = {
                    executor.submit(
                        ceta_certified_polarity,
                        proof_path,
                        args.ceta,
                        args.ceta_timeout,
                    ): proof_path
                    for _, proof_path in proofs
                }
                for completed, future in enumerate(
                    concurrent.futures.as_completed(pending), start=1
                ):
                    proof_path = pending[future]
                    certified[proof_path] = future.result()
                    if (
                        args.progress_every > 0
                        and completed % args.progress_every == 0
                    ):
                        print(
                            f"CeTA-rechecked {completed}/{len(proofs)} proofs",
                            file=sys.stderr,
                            flush=True,
                        )
    args.output.parent.mkdir(parents=True, exist_ok=True)
    counts: Counter[str] = Counter()
    rejected_proofs: list[dict[str, str]] = []
    certified_manifest_rows: dict[tuple[str, str], dict] = {}
    with args.output.open("w", encoding="utf-8") as sink:
        for index, (proof_root, proof_path) in enumerate(proofs, start=1):
            result_path = result_path_for_proof(proof_path)
            result = (
                json.loads(result_path.read_text(encoding="utf-8"))
                if result_path.exists()
                else {}
            )
            if args.ceta is not None:
                polarity, check_status = certified[proof_path]
                counts[f"ceta:{check_status}"] += 1
                if polarity is None:
                    rejected_proofs.append(
                        {"proof_path": str(proof_path), "reason": check_status}
                    )
                    continue
                result = {
                    **result,
                    "certified": True,
                    "status": (
                        "Terminating" if polarity == "YES" else "Nonterminating"
                    ),
                }
            else:
                if not result_path.exists():
                    counts["missing_result"] += 1
                    continue
                polarity = certified_result_polarity(result)
                if polarity is None:
                    counts["not_certified_result"] += 1
                    continue
            root = load_xml(str(proof_path), None)
            if root is None:
                counts["parse_failed"] += 1
                continue
            # Converted CPF2 certificates normally use a global rule table.
            # Exact residual states and processor witnesses must be
            # self-contained once detached from that certificate.  Expand
            # every ruleIndex before reconstructing those states; otherwise
            # exact reduction-pair extraction cannot match the removed rules
            # and may silently downgrade a certified witness to a coarse
            # synthesis hint.
            root = materialize_rule_table_references(root)
            # The exact-row walker normalizes its own private copy, but the
            # source-bound complete-root rows below are constructed directly
            # from this tree.  Normalize the shared tree as well so legacy
            # CPF2 ``lhs``/``rhs``/``arg`` wrappers cannot leak into an exact
            # atom that Ferrum's current CPF3 input parser must replay.
            normalize_cpf2_terms(root)
            relative = (
                proof_path.name
                if proof_root.is_file()
                else proof_path.relative_to(proof_root.resolve()).as_posix()
            )
            event_problem_id, event_category = adjacent_event_identity(proof_path)
            category = next(
                (
                    part
                    for part in proof_path.parts
                    if part.startswith(("TRS_", "SRS_"))
                ),
                str(result.get("category") or event_category or "unknown"),
            )
            problem_id = str(
                result.get("problem_id")
                or result.get("path")
                or event_problem_id
                or selected_problem_ids.get(proof_path)
                or relative
            )
            source_row = {
                "proof_url": f"local://{proof_root.name}/{relative}",
                "normalizer": None,
                "source_kind": "local-certified-cpf",
                "xml_path": str(proof_path),
                "xml_format": cpf_version(proof_path),
                "year": 2025,
                "category": category,
                "benchmark": problem_id,
                "tool": "Ferrum",
                "result": polarity,
                "certification": "certified",
                "csr_gm_runtime_trs_input": csr_gm_runtime_trs_input(
                    proof_path, root
                ),
                "materialize_child_input": lambda atom, input_xml: materialize_single_cpf_child(
                    args.ferrum_canonicalizer, atom, input_xml),
            }
            rows, reasons = (
                ([], Counter())
                if args.root_proofs_only
                else iter_exact_rows(source_row, root)
            )
            if any(
                str(row["metadata"].get("processor_tag"))
                == "innermostLhssIncrease"
                for row in rows
            ):
                # The nested dpTrans is already part of the exact Q-increase
                # boundary.  Exporting it separately canonicalizes back to
                # the root on some inputs, erases Q, and can outrank the sound
                # combined transformation.
                rows = [
                    row
                    for row in rows
                    if str(row["metadata"].get("processor_tag")) != "dpTrans"
                ]
            uncurry_row = root_uncurry_row(root)
            if uncurry_row is not None and not any(
                str(row["metadata"]["processor_tag"]) == "uncurry"
                for row in rows
            ):
                rows.append(uncurry_row)
            dp_uncurry_row = root_dp_uncurry_row(root)
            if dp_uncurry_row is not None and not any(
                str(row["metadata"]["processor_tag"]) == "uncurryProc"
                for row in rows
            ):
                rows.append(dp_uncurry_row)
            direct_root_row = root_direct_processor_row(root)
            if direct_root_row is not None:
                direct_input = unwrap_input(
                    str(direct_root_row["input"]["problem_xml"])
                )
                if direct_root_row["metadata"].get("strategy_atom"):
                    rows = [
                        row
                        for row in rows
                        if not (
                            str(row["metadata"]["processor_tag"])
                            == str(direct_root_row["metadata"]["processor_tag"])
                            and unwrap_input(str(row["input"]["problem_xml"]))
                            == direct_input
                        )
                    ]
                    rows.append(direct_root_row)
                elif not any(
                    str(row["metadata"]["processor_tag"])
                    == str(direct_root_row["metadata"]["processor_tag"])
                    and unwrap_input(str(row["input"]["problem_xml"]))
                    == direct_input
                    for row in rows
                ):
                    rows.append(direct_root_row)
            probe_root_row = certified_probe_root_row(root, result)
            if probe_root_row is not None:
                probe_input = unwrap_input(
                    str(probe_root_row["input"]["problem_xml"])
                )
                rows = [
                    row
                    for row in rows
                    if unwrap_input(str(row["input"]["problem_xml"]))
                    != probe_input
                ]
                rows.append(probe_root_row)
            # The CPF root exposes the atomic processor and every recursive
            # child proof exposes its own next processor.  Preserve those
            # state-local rows and additionally retain the complete producing
            # recipe at the exact live root as a certified replay fallback.
            runtime_root_key = live_root_problem_key(root, proof_path)
            if runtime_root_key is None:
                root_identity = proof_problem_identity(
                    proof_path, problem_id, category
                )
                root_aliases = external_runtime_root_keys.get(root_identity, set())
                if len(root_aliases) == 1:
                    runtime_root_key = next(iter(root_aliases))
            root_input_node = next(
                (element for element in root if local_name(element.tag) == "input"),
                None,
            )
            root_problem_xml = (
                unwrap_input(ET.tostring(root_input_node, encoding="unicode"))
                if root_input_node is not None
                else None
            )
            if runtime_root_key is not None and root_problem_xml is not None:
                for row in rows:
                    if (
                        unwrap_input(str(row["input"]["problem_xml"]))
                        == root_problem_xml
                    ):
                        row["metadata"]["runtime_raw_problem_key"] = (
                            runtime_root_key
                        )
            root_recipe_row = certified_runtime_root_recipe_row(
                proof_path, problem_id, runtime_root_key
            )
            if root_recipe_row is not None:
                rows.append(root_recipe_row)
            elif (
                linear_root_recipe_row := certified_linear_root_recipe_row(
                    rows, root_problem_xml, runtime_root_key
                )
            ) is not None:
                rows.append(linear_root_recipe_row)
            # A terminal CPF witness is not oracle advice.  For certified
            # nontermination roots, retain only the independently executable
            # search family that reconstructed that witness (direct loop,
            # DP loop, or DP non-loop), keyed at the live root.  This is an
            # atomic algorithm choice and carries no term/substitution data.
            if (
                polarity == "NO"
                and runtime_root_key is not None
                and root_problem_xml is not None
                and not (
                    direct_root_row is not None
                    and direct_root_row["metadata"].get("processor_tag") == "dpTrans"
                )
            ):
                terminal_atoms = [
                    strategy_atom(row)
                    for row in rows
                    if str(row["metadata"].get("processor_tag"))
                    in {"loop", "nonLoop"}
                ]
                terminal_atoms = [
                    atom
                    for atom in terminal_atoms
                    if isinstance(atom, str) and atom.startswith("nontermination(")
                ]
                if terminal_atoms:
                    rank = {
                        "nontermination(dp-nonloop)": 3,
                        "nontermination(dp-loop)": 2,
                        "nontermination(loop)": 1,
                    }
                    selected_atom = max(
                        terminal_atoms, key=lambda atom: rank.get(atom, 0)
                    )
                    rows.append(
                        {
                            "metadata": {
                                "processor_tag": "certifiedAtomicRootSearch",
                                "strategy_atom": selected_atom,
                                "outcome": "solved",
                                "runtime_raw_problem_key": runtime_root_key,
                                "path": [
                                    "certificationProblem",
                                    "proof",
                                    "certifiedAtomicRootSearch",
                                ],
                            },
                            "input": {"problem_xml": root_problem_xml},
                            "output_xml": "<certifiedAtomicRootSearch />",
                        }
                    )
            if not args.exclude_complete_proof_atoms:
                exact_root_row = exact_complete_trs_proof_row(
                    root, root_problem_xml, runtime_root_key
                )
                if exact_root_row is not None:
                    rows.append(exact_root_row)
                exact_nontermination_root_row = (
                    exact_complete_trs_nontermination_proof_row(
                        root, root_problem_xml, runtime_root_key
                    )
                )
                if exact_nontermination_root_row is not None:
                    rows.append(exact_nontermination_root_row)
            if args.root_proofs_only:
                rows = [
                    row
                    for row in rows
                    if row.get("metadata", {}).get("processor_tag")
                    in {"exactCompleteTrsProof", "exactCompleteTrsNonterminationProof"}
                ]
            elif not args.exclude_complete_proof_atoms:
                rows.extend(exact_complete_dp_proof_rows(rows))
                rows.extend(exact_complete_dp_nontermination_proof_rows(rows))
            # Exact CPF reconstruction intentionally omits live-only usable
            # rule and construction metadata.  Restore the corresponding raw
            # runtime aliases for every nested state, not only the root, so a
            # certified child continuation is independently findable.
            # Encode self-contained exact witnesses before alias attachment.
            # The attachment pass deliberately permits contextless archived
            # states to bridge newer Ferrum bookkeeping only for guarded
            # exact atoms.  Red-pair rows otherwise still look like their
            # model-only `exact-poly` spelling here and miss that safe bridge;
            # freezing them after attachment is one step too late.
            freeze_portable_atoms_before_runtime_rebind(rows)
            attach_runtime_state_keys(
                rows,
                proof_path,
                problem_id,
                external_runtime_keys,
                external_runtime_dp_states,
                external_runtime_root_keys,
                # ``proof_chain_only`` excludes unrelated successful runtime
                # trials; it must not make a certified structural proof chain
                # unreachable.  These portable aliases are limited to exact
                # processors which revalidate their complete live source
                # obligation before producing a child.  It is therefore safe
                # to bind every provenance variant with the same typed core,
                # even when several such variants were observed.
                allow_portable_ambiguous_aliases=True,
                category_hint=category,
                include_adjacent_event=not args.root_proofs_only,
            )
            bind_runtime_exact_reduction_atoms(rows, proof_path, problem_id)
            bind_runtime_exact_graph_atoms(rows, proof_path, problem_id)
            # Each pass can expose the next independently keyed continuation
            # in a long transformation chain.  Certified AProVE proofs such
            # as ``aprove4`` contain more than eight such states, so the old
            # fixed cap silently stopped while progress was still monotone.
            # The loop already terminates on a stable attachment count; keep
            # only a generous corruption guard here.
            for _ in range(64):
                attached_before = sum(
                    isinstance(
                        row.get("metadata", {}).get("runtime_raw_problem_key"),
                        str,
                    )
                    for row in rows
                )
                rebind_rows_to_runtime_inputs(rows, external_runtime_inputs)
                bind_rebound_causal_parent_atoms(rows)
                attach_runtime_state_keys(
                    rows,
                    proof_path,
                    problem_id,
                    external_runtime_keys,
                    external_runtime_dp_states,
                    external_runtime_root_keys,
                    allow_portable_ambiguous_aliases=True,
                    category_hint=category,
                    include_adjacent_event=not args.root_proofs_only,
                )
                flatten_identity_graph_wrappers(rows)
                attached_after = sum(
                    isinstance(
                        row.get("metadata", {}).get("runtime_raw_problem_key"),
                        str,
                    )
                    for row in rows
                )
                if attached_after == attached_before:
                    break
            rebind_rows_to_runtime_inputs(rows, external_runtime_inputs)
            runtime_rows = (
                []
                if args.root_proofs_only
                else certified_runtime_atom_rows(proof_path, problem_id)
            )
            freeze_portable_atoms_before_runtime_rebind(runtime_rows)
            attach_runtime_state_keys(
                runtime_rows,
                proof_path,
                problem_id,
                external_runtime_keys,
                external_runtime_dp_states,
                external_runtime_root_keys,
                category_hint=category,
                include_adjacent_event=not args.root_proofs_only,
            )
            rebind_rows_to_runtime_inputs(runtime_rows, external_runtime_inputs)
            retained_runtime_rows = discard_runtime_atoms_shadowed_by_local_context(
                rows, runtime_rows
            )
            if args.proof_chain_only:
                # A deterministic atom at its exact live state is part of the
                # checked chain when (and only when) the same processor family
                # occurs structurally in the twice-certified CPF.  These rows
                # carry no stored proof fragment or model: replay reruns the
                # processor and the final CPF is checked again.  Keeping them
                # is essential for private typed contexts (such as GM04's
                # residual assumption) which CPF intentionally does not expose
                # as standalone input syntax.
                rows.extend(
                    row
                    for row in retained_runtime_rows
                    if row.get("metadata", {}).get(
                        "runtime_atom_certified_source"
                    )
                    and not row.get("metadata", {}).get(
                        "runtime_atom_external_hint"
                    )
                )
            else:
                rows.extend(retained_runtime_rows)
            if args.root_local_atom_pool or args.bound_red_pair_pool:
                identity = proof_problem_identity(
                    proof_path, problem_id, category
                )
                equivalent_identities = equivalent_runtime_identities(identity)
                live_keys_by_context: dict[tuple[str, ...], set[str]] = {}
                for (runtime_identity, signature), keys in external_runtime_keys.items():
                    if runtime_identity not in equivalent_identities:
                        continue
                    # The structural signature intentionally omits Ferrum-only
                    # state metadata.  Pool typing must inspect each raw live
                    # input, otherwise QCS mode is erased before this safety
                    # check and no correctly typed fragment can match it.
                    for key in keys:
                        live_cpf = external_runtime_inputs.get(key, signature)
                        context = typed_pool_context(live_cpf)
                        live_keys_by_context.setdefault(context, set()).add(key)
                atom_rows: dict[tuple[tuple[str, ...], str], dict] = {}
                has_q_increase_dp = any(
                    (strategy_atom(candidate) or "").startswith(
                        "exact-innermost-lhss-dp("
                    )
                    for candidate in rows
                )
                for row in rows:
                    atom = strategy_atom(row)
                    if atom is None or not root_local_atom_is_portable(atom):
                        continue
                    # The dpTrans below innermostLhssIncrease is not a
                    # top-level ordinary DP transformation.  Pooling it back
                    # to the root erases Q and can outrank the combined exact
                    # boundary that reconstructs the checked CPF correctly.
                    if has_q_increase_dp and atom.startswith("exact-dp("):
                        continue
                    if (
                        args.bound_red_pair_pool
                        and not args.root_local_atom_pool
                        and not exact_red_pair_is_context_bound(atom)
                    ):
                        continue
                    problem_xml = unwrap_input(str(row["input"]["problem_xml"]))
                    if problem_xml is None:
                        continue
                    level, _ = typed_problem_kind(problem_xml)
                    # Exact CPF fragments do not carry Ferrum's internal CSR
                    # construction marker.  When structural alignment already
                    # bound the fragment to a live runtime state, recover the
                    # type from that state instead of treating it as an
                    # unspecified CSR-DP and losing its valid residual pool.
                    source_key = row["metadata"].get("runtime_raw_problem_key")
                    source_runtime_cpf = (
                        external_runtime_inputs.get(source_key)
                        if isinstance(source_key, str)
                        else None
                    )
                    red_pair_tag = exact_red_pair_processor_tag(atom)
                    context = typed_pool_context(source_runtime_cpf or problem_xml)
                    if args.root_local_atom_pool:
                        # A CPF deletion step is source-bound, but its model
                        # can still be useful after a different deletion. Do
                        # not relax source-bound shape/context checks: offer
                        # separately checked native model actions instead.
                        for model_atom in reduction_pair_model_atoms(atom):
                            model_row = copy.deepcopy(row)
                            model_row["metadata"]["strategy_atom"] = model_atom
                            model_row["metadata"]["reduction_pair_model_hint"] = True
                            atom_rows.setdefault((context, model_atom), model_row)
                    if red_pair_tag in {"redPairProc", "monoRedPairProc"} and (
                        effective_rule_count(source_runtime_cpf or problem_xml) != 0
                    ) and not exact_red_pair_is_context_bound(atom):
                        # Unlike the Ur variants, a plain reduction-pair CPF
                        # node does not carry its weak-rule obligation.  It may
                        # only move between independently materialized states
                        # when both have R = empty.  Otherwise the same pair
                        # witness can be invalid under a different active R.
                        continue
                    context = typed_pool_context(source_runtime_cpf or problem_xml)
                    # DP-only processors cannot be applied to top-level TRS
                    # states.  Conversely, root transformations such as dp
                    # and uncurry are useful on newly exposed top-level TRSs.
                    if level == "dependency-pair" and (
                        atom == "dp" or atom.startswith("nontermination(")
                    ):
                        continue
                    atom_rows.setdefault((context, atom), row)
                    if (
                        row["metadata"].get("processor_tag")
                        == "csrRuleRemovalThenImproved"
                    ):
                        improved = copy.deepcopy(row)
                        improved["metadata"]["strategy_atom"] = "csr-improved-dp"
                        atom_rows.setdefault((context, "csr-improved-dp"), improved)
                pooled_rows: list[dict] = []
                for (context, atom), row in atom_rows.items():
                    red_pair_tag = exact_red_pair_processor_tag(atom)
                    source_cpf = unwrap_input(str(row["input"]["problem_xml"]))
                    if source_cpf is None:
                        continue
                    for key in sorted(live_keys_by_context.get(context, set())):
                        if row["metadata"].get("runtime_raw_problem_key") == key and not row["metadata"].get("reduction_pair_model_hint"):
                            continue
                        live_cpf = external_runtime_inputs.get(key)
                        if live_cpf is None:
                            continue
                        if not root_local_atom_shape_compatible(
                            atom, source_cpf, live_cpf
                        ):
                            continue
                        if red_pair_tag in {"redPairProc", "monoRedPairProc"} and (
                            effective_rule_count(live_cpf) != 0
                        ) and not exact_red_pair_is_context_bound(atom):
                            continue
                        try:
                            live_input = ET.Element("input")
                            live_input.append(ET.fromstring(live_cpf))
                        except ET.ParseError:
                            continue
                        duplicate = copy.deepcopy(row)
                        duplicate["metadata"]["runtime_raw_problem_key"] = key
                        duplicate["metadata"]["root_local_atom_pool"] = True
                        duplicate["metadata"]["bound_red_pair_pool"] = (
                            args.bound_red_pair_pool
                            and exact_red_pair_is_context_bound(atom)
                        )
                        # A processor extracted from another state in the same
                        # certified proof is an external hint for this live
                        # state, not certified positive evidence on the source
                        # state's canonical key.  Key it by the live state and
                        # keep it weak until an actual replay applies it and a
                        # complete reconstructed proof certifies.
                        duplicate["metadata"]["outcome"] = "transformed"
                        duplicate["input"]["problem_xml"] = ET.tostring(
                            live_input, encoding="unicode"
                        )
                        # Do not recompute this proof fragment against the
                        # sibling input.  Its encoded source state is the
                        # executable applicability guard.
                        duplicate["metadata"]["strategy_atom"] = (
                            rebind_context_bound_red_pair_atom(atom, live_cpf)
                            if exact_red_pair_is_context_bound(atom)
                            else atom
                        )
                        pooled_rows.append(duplicate)
                rows.extend(pooled_rows)
            counts.update({f"extract:{key}": value for key, value in reasons.items()})
            emitted = 0
            for row in rows:
                if row["metadata"].get("identity_graph_wrapper"):
                    counts["identity_graph_wrappers_flattened"] += 1
                    continue
                if (
                    row["metadata"].get("runtime_atom_pool_only")
                    and not row["metadata"].get("root_local_atom_pool")
                ):
                    continue
                candidate = strategy_atom(row)
                if candidate is None:
                    counts[
                        f"unsupported:{row['metadata']['processor_tag']}"
                    ] += 1
                    continue
                if not row["metadata"].get("preserve_composed_recipe"):
                    candidate, _ = atomize(candidate)
                    if candidate is None:
                        counts["composed_strategy_discarded"] += 1
                        continue
                cpf = unwrap_input(str(row["input"]["problem_xml"]))
                if cpf is None:
                    counts["input_unwrap_failed"] += 1
                    continue
                outcome = row["metadata"].get("outcome")
                if outcome in {"solved", "transformed"}:
                    progress = "closed" if outcome == "solved" else "strong"
                else:
                    outcome, progress = event_outcome(
                        str(row["metadata"]["processor_tag"]),
                        str(row["output_xml"]),
                    )
                problem_key = hashlib.sha256(cpf.strip().encode("utf-8")).hexdigest()
                level, problem_kind = typed_problem_kind(cpf)
                # CPF uses the same <loop> proof node for ordinary TRSs and
                # unary encodings of SRSs.  The executable search processors
                # are deliberately distinct, however: ``loop`` runs the
                # bounded term-rewriting search, whereas ``srs-loop`` uses
                # the complete word-oriented search that originally found
                # these certified SRS witnesses.  Preserve that typed choice
                # instead of silently weakening SRS evidence to the ordinary
                # direct-loop fast path.
                candidate = typed_strategy_atom(candidate, problem_kind, category)
                event = {
                    "schema": "ferrum.processor-event.v1",
                    "run_id": args.run_id,
                    "problem_id": problem_id,
                    "category": category,
                    "level": level,
                    "problem_kind": problem_kind,
                    "processor": candidate,
                    "strategy_atom": candidate,
                    "outcome": outcome,
                    "progress": progress,
                    "elapsed_ms": None,
                    "input": {
                        "format": "cpf4-xml" if source_row["xml_format"] == "cpf4" else "cpf3-xml",
                        "cpf": cpf,
                        "problem_key": problem_key,
                    },
                    "metrics": {
                        "proof_path": row["metadata"]["path"],
                        "processor_tag": row["metadata"]["processor_tag"],
                    },
                    "witness": {
                        "kind": "cpf-proof-fragment",
                        "xml": row["output_xml"],
                    },
                    "certification": {
                        "status": (
                            "external-hint-certified-source"
                            if row["metadata"].get("root_local_atom_pool")
                            or row["metadata"].get("runtime_atom_external_hint")
                            else "certified-full-source"
                        ),
                        "checker": "CeTA",
                    },
                    "credit": {
                        "status": (
                            "external-hint"
                            if row["metadata"].get("root_local_atom_pool")
                            or row["metadata"].get("runtime_atom_external_hint")
                            else "proof-path-certified"
                        )
                    },
                }
                if row["metadata"].get("root_local_atom_pool") or row[
                    "metadata"
                ].get("runtime_atom_external_hint"):
                    event["progress"] = "weak"
                runtime_raw_problem_key = row["metadata"].get(
                    "runtime_raw_problem_key"
                )
                if isinstance(runtime_raw_problem_key, str):
                    event["input"]["runtime_raw_problem_key"] = (
                        runtime_raw_problem_key
                    )
                events_to_write = [event]
                # Pair-source provenance and active-rule bookkeeping are
                # Ferrum reconstruction metadata, not part of the CPF DP
                # obligation.  Emit the canonical contextless spelling as a
                # second, certified lookup key for portable exact processors.
                # The selected atom still carries its complete source state
                # and validates it against the live obligation, so this alias
                # cannot promote a merely similar processor result.  This is
                # what makes every child of a large external proof
                # independently findable without first observing that exact
                # runtime provenance spelling.
                portable_native_alias = {
                    "exact-size-change(": "size-change",
                    "exact-subterm(": "subterm",
                }
                alias_candidate = next(
                    (
                        native
                        for prefix, native in portable_native_alias.items()
                        if candidate.startswith(prefix)
                    ),
                    None,
                )
                if candidate in {"size-change", "subterm"}:
                    alias_candidate = candidate
                if alias_candidate is not None and has_dp_state_context(cpf):
                    contextless = contextless_runtime_state_signature(cpf)
                    if isinstance(contextless, str) and contextless.strip() != cpf.strip():
                        alias_event = copy.deepcopy(event)
                        alias_key = hashlib.sha256(
                            contextless.strip().encode("utf-8")
                        ).hexdigest()
                        alias_event["input"]["cpf"] = contextless
                        alias_event["input"]["problem_key"] = alias_key
                        alias_event["input"].pop("runtime_raw_problem_key", None)
                        alias_event["processor"] = alias_candidate
                        alias_event["strategy_atom"] = alias_candidate
                        events_to_write.append(alias_event)
                        counts["portable_contextless_aliases"] += 1
                for emitted_event in events_to_write:
                    emitted_key = emitted_event["input"]["problem_key"]
                    emitted_candidate = emitted_event["strategy_atom"]
                    sink.write(json.dumps(emitted_event, separators=(",", ":")) + "\n")
                    if (
                        args.certified_manifest_output is not None
                        and not row["metadata"].get("root_local_atom_pool")
                        and not row["metadata"].get("runtime_atom_external_hint")
                    ):
                        certified_manifest_rows[(emitted_key, emitted_candidate)] = {
                            "scope": "canonical",
                            "problem_key": emitted_key,
                            "candidate": emitted_candidate,
                            "recorded_implementation_hash": None,
                            "recheck_status": "certified",
                            "deterministic_rechecks": 2 if args.ceta is not None else 0,
                            "source_proof": str(proof_path),
                            "checker": str(args.ceta) if args.ceta is not None else "recorded",
                        }
                    emitted += 1
                    counts["events"] += 1
                    counts[f"candidate:{emitted_candidate}"] += 1
            if emitted:
                counts["proofs_with_events"] += 1
            if (
                args.progress_every > 0
                and (index % args.progress_every == 0 or index == len(proofs))
            ):
                print(
                    f"cpf-oracle-extract {index}/{len(proofs)} "
                    f"proofs={counts['proofs_with_events']} events={counts['events']}",
                    flush=True,
                )
    if args.certified_manifest_output is not None:
        if args.ceta is None:
            parser.error("--certified-manifest-output requires --ceta")
        args.certified_manifest_output.parent.mkdir(parents=True, exist_ok=True)
        args.certified_manifest_output.write_text(
            "".join(
                json.dumps(row, separators=(",", ":")) + "\n"
                for row in certified_manifest_rows.values()
            ),
            encoding="utf-8",
        )
    summary_path = args.output.with_suffix(args.output.suffix + ".summary.json")
    summary_path.write_text(
        json.dumps(
            {
                "proofs_seen": len(proofs),
                "counts": dict(sorted(counts.items())),
                "rejected_proofs": rejected_proofs,
                "output": str(args.output),
            },
            indent=2,
            sort_keys=True,
        )
        + "\n",
        encoding="utf-8",
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
