#!/usr/bin/env python3
"""Normalize redundant CPF bounds proof forms without changing proof search."""

from __future__ import annotations

import argparse
import copy
import xml.etree.ElementTree as ET
from pathlib import Path


ABSOLUTE_TO_RELATIVE = {
    "bounds": "relativeBounds",
    "rfcBounds": "rfcRelativeBounds",
    "rfcAutomatonClosedBounds": "rfcAutomatonClosedRelativeBounds",
}


def empty_termination_proof() -> ET.Element:
    proof = ET.Element("trsTerminationProof")
    ET.SubElement(proof, "rIsEmpty")
    return proof


def replace_child(parent: ET.Element, old: ET.Element, new: ET.Element) -> None:
    index = list(parent).index(old)
    parent.remove(old)
    parent.insert(index, new)


def trs_after_rule_removal(
    current_trs: ET.Element, removed_trs: ET.Element
) -> ET.Element:
    def element_key(element: ET.Element) -> tuple:
        return (
            element.tag,
            (element.text or "").strip(),
            tuple(element_key(child) for child in element),
        )

    remaining = copy.deepcopy(current_trs)
    remaining_rules = remaining.find("rules")
    removed_rules = removed_trs.find("rules")
    if remaining_rules is None or removed_rules is None:
        raise ValueError("expected <trs><rules> in rule-removal proof")
    for removed in list(removed_rules):
        key = element_key(removed)
        match = next(
            (
                candidate
                for candidate in list(remaining_rules)
                if element_key(candidate) == key
            ),
            None,
        )
        if match is None:
            raise ValueError("removed rule is absent from the current TRS")
        remaining_rules.remove(match)
    return remaining


def normalize_termination_proof(
    termination_proof: ET.Element, current_trs: ET.Element
) -> None:
    children = list(termination_proof)
    if len(children) != 1:
        return
    step = children[0]

    relative_tag = ABSOLUTE_TO_RELATIVE.get(step.tag)
    if relative_tag is not None:
        relative = ET.Element(relative_tag)
        if step.tag == "bounds":
            relative.append(copy.deepcopy(step))
        else:
            for child in list(step):
                relative.append(copy.deepcopy(child))
        relative.append(copy.deepcopy(current_trs))
        relative.append(empty_termination_proof())
        replace_child(termination_proof, step, relative)
        return

    if step.tag == "rfcNativeMatchboxRelativeBounds":
        step.tag = "rfcMatchboxRelativeBounds"

    if step.tag == "stringReversal":
        reversed_trs = step.find("trs")
        nested = step.find("trsTerminationProof")
        if reversed_trs is not None and nested is not None:
            normalize_termination_proof(nested, reversed_trs)
        return

    nested = step.find("trsTerminationProof")
    if nested is not None:
        removed_trs = step.find("trs")
        if step.tag in {
            "ruleRemoval",
            "removeNonApplicableRules",
            "relativeBounds",
            "rfcRelativeBounds",
            "rfcAutomatonClosedRelativeBounds",
            "rfcMatchboxRelativeBounds",
        } and removed_trs is not None:
            current_trs = trs_after_rule_removal(current_trs, removed_trs)
        normalize_termination_proof(nested, current_trs)


def normalize_file(source: Path, destination: Path) -> None:
    tree = ET.parse(source)
    root = tree.getroot()
    input_trs = root.find("./input/trsInput/trs")
    termination_proof = root.find("./proof/trsTerminationProof")
    if input_trs is None or termination_proof is None:
        raise ValueError(f"{source}: expected a CPF TRS termination problem")
    normalize_termination_proof(termination_proof, input_trs)
    ET.indent(tree, space="  ")
    destination.parent.mkdir(parents=True, exist_ok=True)
    tree.write(destination, encoding="UTF-8", xml_declaration=True)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("source", type=Path)
    parser.add_argument("destination", type=Path)
    args = parser.parse_args()
    normalize_file(args.source, args.destination)


if __name__ == "__main__":
    main()
