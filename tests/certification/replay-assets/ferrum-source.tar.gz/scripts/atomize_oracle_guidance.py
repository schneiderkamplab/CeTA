#!/usr/bin/env python3
"""Remove persisted strategy composition while preserving the next processor.

An oracle record describes one problem state.  A historical candidate such as
``dp(graph; size-change)`` therefore contains two different kinds of data: the
applicable root processor (``dp``), and an obsolete continuation for a child
state.  This migration retains only the former.  Other composed candidates are
discarded; their individual processors belong on their own residual-state
records.
"""

from __future__ import annotations

import argparse
import json
import re
from pathlib import Path


BUCKETS = ("prefer", "possible", "avoid", "timeout")
CONTINUATION_WRAPPER = re.compile(
    r"^(dp|csr-(?:improved|safe|innermost|rta08|conservative)-dp|"
    r"csr-gm-transform|switch-innermost)\(.+\)$"
)
COMPOSITION_MARKERS = (";", "parallel(", "choice(", "pipeline(", "exhaust(")
SCHEDULER_ALIASES = {"fast-dp", "termination", "nontermination"}
SINGLE_NONTERMINATION_TIMEOUT = re.compile(
    r"^nontermination\(timeout\([^,]+,([a-z][a-z0-9-]*)\)\)$"
)


def atomize(candidate: str) -> tuple[str | None, bool]:
    if candidate in SCHEDULER_ALIASES:
        return None, False
    match = CONTINUATION_WRAPPER.match(candidate)
    if match:
        return match.group(1), True
    match = SINGLE_NONTERMINATION_TIMEOUT.match(candidate)
    if match:
        return f"nontermination({match.group(1)})", True
    if "hex=" not in candidate and "witness=" not in candidate:
        if any(marker in candidate for marker in COMPOSITION_MARKERS):
            return None, False
    return candidate, False


def migrate_record(record: dict) -> tuple[dict, int, int]:
    record = dict(record)
    atomized = removed = 0
    for bucket in BUCKETS:
        retained = []
        positions: dict[str, int] = {}
        for raw in record.get(bucket, []):
            item = dict(raw)
            candidate, changed = atomize(str(item.get("candidate", "")))
            if candidate is None:
                removed += 1
                continue
            if changed:
                atomized += 1
                item["candidate"] = candidate
                if bucket in ("prefer", "possible"):
                    item["status"] = "transformed_strong"
                    item["solved_count"] = 0
                    item["transformed_count"] = max(
                        1,
                        int(item.get("transformed_count", 0)),
                        int(item.get("certified_count", 0)),
                    )
            previous = positions.get(candidate)
            if previous is None:
                positions[candidate] = len(retained)
                retained.append(item)
            else:
                # Preserve first-choice ordering while retaining the strongest
                # accumulated counters for the now-identical processor atom.
                old = retained[previous]
                for field in (
                    "attempts", "certified_count", "failed_count", "solved_count",
                    "timeout_count", "transformed_count",
                ):
                    old[field] = max(int(old.get(field, 0)), int(item.get(field, 0)))
                old["utility_score"] = max(
                    float(old.get("utility_score", -1e30)),
                    float(item.get("utility_score", -1e30)),
                )
        record[bucket] = retained
    return record, atomized, removed


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--input", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--report", type=Path, required=True)
    args = parser.parse_args()
    records = atomized = removed = 0
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with args.input.open(encoding="utf-8") as source, args.output.open("w", encoding="utf-8") as output:
        for line in source:
            if not line.strip():
                continue
            row, row_atomized, row_removed = migrate_record(json.loads(line))
            output.write(json.dumps(row, sort_keys=True, separators=(",", ":")) + "\n")
            records += 1
            atomized += row_atomized
            removed += row_removed
    report = {
        "schema": "ferrum.atomic-oracle-migration.v1",
        "input": str(args.input.resolve()),
        "output": str(args.output.resolve()),
        "records": records,
        "atomized_candidates": atomized,
        "removed_composed_candidates": removed,
    }
    args.report.write_text(json.dumps(report, indent=2, sort_keys=True) + "\n")
    print(json.dumps(report, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
