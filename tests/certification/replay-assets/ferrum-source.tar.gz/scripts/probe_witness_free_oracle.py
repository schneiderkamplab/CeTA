#!/usr/bin/env python3
"""Experimental search-only oracle: replace exact models by parameter bounds.

Never promote this file as certified guidance: inherited statistics refer to
the original actions. Only fresh replay certificates can certify the results.
"""
import argparse
import collections
import copy
import hashlib
import math
from fractions import Fraction
import json
import re
import xml.etree.ElementTree as ET
from pathlib import Path
import probe_generic_witness_replacements as generic

EXACT = re.compile(r'(?<![\w-])exact-([\w-]+)\(([^()]*)\)')
LIMITS = dict(max_constant_limit=256, max_coefficient_limit=256,
              max_symbols_limit=256, max_arity_limit=16)

def cpf_polynomial_bounds(root):
    """Recover search bounds, not assignments, from a native CPF interpretation."""
    if root.tag == 'interpretation':
        wrapper = ET.Element('proof')
        wrapper.append(root)
        root = wrapper
    typ = root.find('.//interpretation/type/polynomial')
    if typ is None:
        return None

    def polynomial(node):
        if node.tag == 'integer':
            return {(): Fraction(int(node.text))}
        if node.tag == 'rational':
            return {(): Fraction(int(node.findtext('numerator')),
                                 int(node.findtext('denominator')))}
        if node.tag == 'variable':
            return {(int(node.text),): Fraction(1)}
        if node.tag not in ('sum', 'product'):
            raise ValueError('unsupported CPF polynomial expression')
        result = {} if node.tag == 'sum' else {(): Fraction(1)}
        for child in node:
            part = polynomial(child)
            if node.tag == 'sum':
                for monomial, coefficient in part.items():
                    result[monomial] = result.get(monomial, 0) + coefficient
            else:
                product = {}
                for a, x in result.items():
                    for b, y in part.items():
                        key = tuple(sorted(a + b))
                        product[key] = product.get(key, 0) + x * y
                result = product
        return {m: c for m, c in result.items() if c}

    entries = root.findall('.//interpretation/interpret')
    if not entries:
        return None
    models = [polynomial(entry[-1]) for entry in entries]
    values = [c for model in models for c in model.values()]
    degree = max((len(m) for model in models for m in model), default=0)
    if any(c < 0 for c in values):
        # CPF's natural weak-polynomial processor permits negative constants,
        # but not arbitrary negative coefficients or rational quadratic models.
        if degree > 1 or typ.find('domain/naturals') is None or any(
                c < 0 for model in models for monomial, c in model.items() if monomial):
            return None
        if any(c.denominator != 1 for c in values):
            return None
        low = min([0] + [int(model.get((), 0)) for model in models])
        high = max([0] + [int(model.get((), 0)) for model in models])
        coefficient = max([0] + [int(c) for model in models for m, c in model.items() if m])
        arity = max(int(entry.findtext('arity')) for entry in entries)
        if max(-low, high, coefficient, len(entries)) > 256 or arity > 16:
            return None
        return (f'weak-poly(min-constant={low},max-constant={high},'
                f'max-coefficient={coefficient},max-symbols={len(entries)},max-arity={arity})')
    denominator = math.lcm(*(c.denominator for c in values))
    gap = None
    if typ.find('domain/rationals') is not None:
        delta = polynomial(typ.find('domain/rationals/delta')[0]).get((), 0)
        if delta <= 0:
            return None
        gap = math.ceil(1 / delta)
        if degree == 2:
            # The native quadratic checker stores its strict gap as an integer
            # numerator over the interpretation denominator. Preserve a small
            # source gap by refining that common denominator, not rounding it up.
            denominator = math.lcm(denominator, gap)
    constant = max([0] + [int(model.get((), 0) * denominator) for model in models])
    coefficient = max([0] + [int(c * denominator) for model in models
                             for m, c in model.items() if m])
    arity = max(int(entry.findtext('arity')) for entry in entries)
    if max(constant, coefficient, denominator, len(entries)) > 256 or arity > 16:
        return None
    bounds = (f'max-constant={constant},max-coefficient={coefficient},'
              f'max-symbols={len(entries)},max-arity={arity}')
    if typ.find('domain/rationals') is not None:
        if degree > 2:
            return None  # Native rat-poly also has a degree-two synthesis continuation.
        kind = 'rat-quadratic-poly' if degree == 2 else 'rat-poly'
        return f'{kind}({bounds},denominator={denominator},delta-denominator={gap})'
    if typ.find('domain/naturals') is not None and degree <= 2:
        kind = 'quadratic-poly' if degree == 2 else 'poly'
        return f'{kind}({bounds})'
    return None

def cpf_scalar_matrix_bounds(interpretation):
    """Convert a dimension-one rational matrix to polynomial search bounds.

    No symbol assignments escape this function; unsupported dimensions/shapes
    are rejected rather than silently interpreted over the natural numbers.
    """
    node = copy.deepcopy(interpretation)
    typ = node.find('type/matrixInterpretation')
    if typ is None or typ.findtext('dimension') != '1' or typ.find('domain/rationals') is None:
        return None
    typ.tag = 'polynomial'
    for child in list(typ):
        if child.tag != 'domain':
            typ.remove(child)
    ET.SubElement(typ, 'degree').text = '1'

    def scalar(expr):
        if expr.tag in ('vector', 'matrix'):
            if len(expr) != 1:
                raise ValueError('non-scalar matrix expression')
            return scalar(expr[0])
        for index, child in enumerate(list(expr)):
            expr[index] = scalar(child)
        return expr

    try:
        for entry in node.findall('interpret'):
            entry[-1] = scalar(entry[-1])
        return cpf_polynomial_bounds(node)
    except (ValueError, TypeError, IndexError, AttributeError):
        return None

def cpf_max_polynomial_bounds(root):
    """Discard max-affine assignments, retaining native search bounds only."""
    model = root.find('.//maxPoly')
    if model is None:
        return None

    def alternatives(node, arity):
        if node.tag in ('constant', 'integer'):
            value = int(node.text)
            if value < 0:
                raise ValueError('negative max coefficient')
            return [(value, [0] * arity)]
        if node.tag == 'variable':
            index = int(node.text) - 1
            if not 0 <= index < arity:
                raise ValueError('invalid max variable')
            coefficients = [0] * arity
            coefficients[index] = 1
            return [(0, coefficients)]
        if node.tag == 'max':
            result = [a for child in node for a in alternatives(child, arity)]
        elif node.tag == 'sum':
            result = [(0, [0] * arity)]
            for child in node:
                part = alternatives(child, arity)
                if len(result) * len(part) > 64:
                    raise ValueError('max expansion too large')
                result = [(a + b, [x + y for x, y in zip(xs, ys)])
                          for a, xs in result for b, ys in part]
        else:
            raise ValueError('unsupported max expression')
        if not result or len(result) > 64:
            raise ValueError('invalid max alternatives')
        return result

    entries = model.findall('interpret')
    if not entries or len(entries) > 256:
        return None
    arities = [int(entry.findtext('arity')) for entry in entries]
    if min(arities) < 0 or max(arities) > 16:
        return None
    models = [alternatives(entry[-1], arity) for entry, arity in zip(entries, arities)]
    constant = max(c for model in models for c, _ in model)
    coefficient = max([0] + [v for model in models for _, cs in model for v in cs])
    if constant > 1_048_576 or coefficient > 256:
        return None
    return (f'max-poly(max-constant={constant},max-coefficient={coefficient},'
            f'alternatives={max(map(len, models))},max-symbols={len(entries)},'
            f'max-arity={max(arities)})')

def atom_replacement(atom):
    family = atom.split('(', 1)[0][6:]
    ordinary = {'graph': 'graph', 'size-change': 'size-change', 'subterm': 'subterm',
                'usable-rules': 'usable-rules', 'dp': 'dp', 'path-order': 'path-order',
                'split': 'split', 'constant-to-unary': 'constant-to-unary'}
    # Discovery hints only: discard the complete terminal witness or selected
    # subproblem. Native search must find and certify a new witness on live P/R/Q.
    ordinary.update({'dp-loop': 'nontermination(dp-loop)',
                     'dp-nonloop': 'nontermination(dp-nonloop)',
                     'dp-no-rule-removal': 'nontermination-usable-rules',
                     'trs-no-rule-removal': 'nontermination',
                     'trs-nontermination-terminal': 'nontermination'})
    if family in ordinary:
        return ordinary[family]
    for name in ['polynomial', 'matrix', 'arctic', 'integer_arctic', 'integer_matrix', 'rational_polynomial',
                 'weak_polynomial', 'monotonic_polynomial', 'max_polynomial', 'kbo',
                 'semantic_labeling', 'relative_semantic_labeling', 'match_bounds']:
        try:
            result = getattr(generic, name + '_replacement')(atom, **LIMITS)
        except (ValueError, TypeError, IndexError):
            result = None
        if result:
            return result
    match = re.search(r'hex=([a-fA-F0-9]+)', atom)
    if not match:
        return None
    value = json.loads(bytes.fromhex(match[1]))
    if family == 'general-red-pair':
        root = ET.fromstring('<w>' + value[0] + '</w>')
        interpretation = root.find('interpretation')
        if interpretation is None or interpretation.find('type/polynomial/domain/naturals') is None:
            return None
        degree = interpretation.findtext('type/polynomial/degree')
        if degree not in ('1', '2'):
            return None
        # Keep only search bounds and context depth; discard selected pairs, source
        # state, interpretation and complete constraint/induction derivation.
        bound = max([1] + [abs(int(x.text)) for x in interpretation.iter('integer')])
        if bound > 16:
            return None
        before = int(root.findtext('condRedPairProof/before', '1'))
        after = int(root.findtext('condRedPairProof/after', '0'))
        if not 0 <= before <= 3 or not 0 <= after <= 3 or before + after > 3:
            return None
        return (f'conditional-poly(max-coefficient={bound}' + (',degree=2' if degree == '2' else '')
                + (f',before={before}' if before != 1 else '')
                + (f',after={after}' if after != 0 else '') + ')')
    if family == 'trs-order':
        if not isinstance(value, list) or len(value) != 2:
            return None
        # Discard the binding and model, retaining only native search bounds.
        return replace(value[1])
    if family == 'semantic-labeling' and isinstance(value, list) and len(value) in (2, 3):
        unbound = 'exact-semantic-labeling(hex=' + json.dumps(value[0]).encode().hex() + ')'
        return generic.semantic_labeling_replacement(unbound, **LIMITS)
    if family == 'innermost-lhss-dp':
        return 'innermost-lhss-dp'
    if family == 'innermost-lhss':
        return 'innermost-lhss'
    if family == 'dp-transform':
        # Keep only the processor family. The selected position, substitution,
        # and complete target state must be rediscovered by native search.
        return {'rewritingProc': 'rewrite', 'narrowingProc': 'narrow',
                'complexConstantRemovalProc': 'complex-constant-removal',
                'instantiationProc': 'instantiate',
                'forwardInstantiationProc': 'forward-instantiate'}.get(value[0])
    if family == 'path-order-removal':
        return 'path-order'
    if family == 'poly-removal':
        equivalent = 'exact-poly(hex=' + json.dumps(value[0]).encode().hex() + ')'
        return generic.polynomial_replacement(equivalent, **LIMITS)
    if family == 'rat-natural-poly':
        denominator, delta, interpretation = value
        if denominator <= 0 or delta <= 0:
            return None
        quadratic = [x for item in interpretation for row in item[3] for x in row]
        if any(x < 0 for x in quadratic):
            return None
        constant = max(item[1] for item in interpretation)
        coefficient = max([0] + [x for item in interpretation for x in item[2]] + quadratic)
        # The native search accepts a reciprocal gap. Round downward to a
        # weaker gap when the source gap is not itself a reciprocal.
        delta_denominator = max(1, (denominator + delta - 1) // delta)
        kind = 'rat-quadratic-poly' if any(quadratic) else 'rat-poly'
        return (f'{kind}(denominator={denominator},delta-denominator={delta_denominator},'
                f'max-constant={constant},max-coefficient={coefficient},max-symbols={len(interpretation)},'
                f'max-arity={max(len(item[2]) for item in interpretation)})')
    if family == 'red-pair':
        root = ET.fromstring('<w>' + value[1] + '</w>')
        if root.find('.//weightedPathOrder') is not None:
            # Keep the WPO processor family, but discard its model, filter,
            # precedence and statuses. Native synthesis chooses all of them.
            bounds = cpf_max_polynomial_bounds(root)
            if not bounds:
                return None
            native = bounds.replace('max-poly(', 'wpo-max(', 1)
            positions = [[int(p.text) for p in status.findall('position')]
                         for status in root.findall('.//precedenceStatusEntry/status')]
            # Retain only the required search class, never a particular
            # argument order or a symbol-to-position mapping.
            if any(order != sorted(order) for order in positions):
                native = native[:-1] + ',permutations=1)'
            return native
        if root.find('.//maxPoly') is not None:
            if root.find('.//argumentFilter') is not None:
                return None  # Native max-poly does not search argument filters.
            return cpf_max_polynomial_bounds(root)
        if root.find('.//recursivePathOrder') is not None:
            return 'path-order'
        if root.find('.//knuthBendixOrder') is not None:
            weights = [int(e.text) for e in root.find('.//knuthBendixOrder').iter()
                       if e.tag in ('weight', 'w0', 'integer') and e.text and e.text.strip()]
            bound = max([1] + weights)
            return f'kbo(max-weight={bound},max-symbols=256)' if bound <= 256 else None
        if root.find('.//interpretation/type/polynomial') is not None:
            bounds = cpf_polynomial_bounds(root)
            if value[0] == 'innermostMonoRedPairProc' and bounds and bounds.startswith('poly('):
                # Natural affine polynomials are dimension-one matrices.
                # Unlike ordinary poly, native matrix also synthesizes a
                # Q-monotonic R-removal step when no DP can be deleted.
                # Retain only bounds, never assignments or strict-rule IDs.
                return bounds.replace('poly(', 'matrix(dimension=1,', 1)
            return bounds
        dim = root.find('.//matrixInterpretation/dimension')
        numbers = [int(e.text) for e in root.iter('integer') if e.text]
        bound = max([0] + [abs(x) for x in numbers])
        if bound > 256:
            return None
        if dim is not None:
            matrix = root.find('.//matrixInterpretation')
            domain = matrix.find('domain')
            if any(x < 0 for x in numbers) and domain is not None and (domain.find('integers') is not None or
                    domain.find('arctic/domain/integers') is not None):
                kind = 'integer-arctic-matrix' if domain.find('arctic') is not None else 'integer-matrix'
                low, high = min([0] + numbers), max([0] + numbers)
                return f'{kind}(dimension={int(dim.text)},min-value={low},max-value={high},max-symbols=256,max-arity=16)'
            # A nonnegative integer-domain model also provides useful natural
            # search bounds. This is guidance only, not a domain-conversion
            # proof: native synthesis and certification recheck the result.
            kind = 'arctic-matrix' if root.find('.//arctic') is not None else 'matrix'
            return f'{kind}(dimension={int(dim.text)},max-constant={bound},max-coefficient={bound},max-symbols=256,max-arity=16)'
        if root.find('.//polynomialInterpretation') is not None:
            return f'poly(max-constant={bound},max-coefficient={bound},max-symbols=256,max-arity=16)'
    return None

def replace(candidate):
    unsupported = False
    def one(match):
        nonlocal unsupported
        try:
            replacement = atom_replacement(match[0])
        except (ValueError, TypeError, IndexError, KeyError, ZeroDivisionError, ET.ParseError):
            replacement = None
        if replacement is None:
            unsupported = True
        return replacement or 'fail'
    result = EXACT.sub(one, candidate)
    return None if unsupported or re.search(r'(?<![\w-])exact-[\w-]+\s*\(', result) else result

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--input', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    definitions = {}
    unsupported = collections.Counter()
    with args.input.open() as stream:
        for line in stream:
            row = json.loads(line)
            if row.get('schema') == generic.WITNESS_SCHEMA:
                definitions[row['witness_id']] = replace(row['candidate'])
                if definitions[row['witness_id']] is None:
                    unsupported[row['candidate'].split('(', 1)[0]] += 1
    counts = collections.Counter()
    with args.output.open('x') as out, args.input.open() as stream:
        for line in stream:
            row = json.loads(line)
            if row.get('schema') == generic.WITNESS_SCHEMA:
                continue
            changed_ids = {}
            for bucket in generic.GROUPS:
                kept = []
                for item in row.get(bucket, []):
                    old = item.get('candidate_ref') or hashlib.sha256(item.get('candidate','').encode()).hexdigest()
                    candidate = definitions.get(item['candidate_ref']) if item.get('candidate_ref') else replace(item.get('candidate',''))
                    if not candidate:
                        counts['removed'] += 1
                        continue
                    if candidate != item.get('candidate'):
                        counts['converted_or_resolved'] += 1
                    changed_ids[old] = hashlib.sha256(candidate.encode()).hexdigest()
                    kept.append({**{k:v for k,v in item.items() if k != 'candidate_ref'}, 'candidate':candidate})
                    counts['kept'] += 1
                if bucket in row:
                    row[bucket] = kept
            if 'replay_order' in row:
                row['replay_order'] = [changed_ids[x] for x in row['replay_order'] if x in changed_ids]
            out.write(json.dumps(row,separators=(',',':'))+'\n')
    print(json.dumps(counts))
    print(json.dumps({'unsupported_witness_definitions': dict(unsupported)}))

if __name__ == '__main__':
    main()
