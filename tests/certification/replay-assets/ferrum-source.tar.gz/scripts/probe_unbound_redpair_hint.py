#!/usr/bin/env python3
"""Try an archived order as an unbound local search hint, never as certified evidence.

The order/removal witness is unchanged. Ferrum must apply it to the live state,
and the complete reconstructed proof must pass CeTA before a root is credited.
"""
import argparse
import hashlib
import json
import subprocess
from pathlib import Path

p = argparse.ArgumentParser(description=__doc__)
p.add_argument('--step', type=Path, required=True)
p.add_argument('--output', type=Path, required=True)
p.add_argument('--ferrum', required=True)
args = p.parse_args()
source_atom = (args.step/'atom.fs').read_text()
assert source_atom.startswith('exact-red-pair(hex=')
payload = json.loads(bytes.fromhex(source_atom.split('hex=')[1][:-1]))
atom = 'exact-red-pair(hex=' + json.dumps(payload[:3], separators=(',', ':')).encode().hex() + ')'
args.output.mkdir(parents=True, exist_ok=False)
(args.output/'atom.fs').write_text(atom)
cpf = (args.step/'input.cpf').read_text()
(args.output/'input.cpf').write_text(cpf)
result = subprocess.run([args.ferrum, 'probe-cpf', str(args.output/'input.cpf'),
    '--strategy-file', str(args.output/'atom.fs'), '--timeout-ms', '60000'],
    capture_output=True, text=True, timeout=65)
(args.output/'stdout.json').write_text(result.stdout)
(args.output/'stderr').write_text(result.stderr)
if result.returncode:
    raise SystemExit(result.returncode)
probe = json.loads(result.stdout)
print(probe.get('typed_outcome'))
if probe.get('typed_outcome') in ('Solved', 'Transformed'):
    event = dict(strategy_atom=atom, source_strategy_atom=source_atom,
        outcome=probe['typed_outcome'].lower(), credit={'status':'diagnostic-only'},
        input=dict(cpf=cpf, problem_key=hashlib.sha256(cpf.strip().encode()).hexdigest()),
        witness=dict(residuals=probe.get('children', [])))
    (args.output/'processor-events.jsonl').write_text(json.dumps(event)+'\n')
