#!/usr/bin/env python3
"""Bounded CeTA audit for materialized fragment certificates."""

from __future__ import annotations

import argparse
import concurrent.futures
import gzip
import json
import subprocess
import time
from pathlib import Path
from typing import Any

from audit_canonical_fragments import sha256_text


def open_input(path: Path):
    return gzip.open(path, "rt", encoding="utf-8") if path.suffix == ".gz" else path.open("r", encoding="utf-8")


def base_result(row_index: int, row: dict[str, Any]) -> dict[str, Any]:
    metadata = row.get("metadata") or {}
    return {
        "row_index": row_index,
        "row_id": row.get("id"),
        "source_row_id": row.get("source_row_id"),
        "category": metadata.get("category"),
        "benchmark": metadata.get("benchmark"),
        "tool": metadata.get("tool"),
        "year": metadata.get("year"),
        "processor_tag": metadata.get("processor_tag"),
        "result": metadata.get("result"),
        "source_path": (row.get("source") or {}).get("xml_path"),
    }


def ceta_job(ceta: str, work_dir: str, timeout: int, keep: str, result: dict[str, Any], certificate: str) -> dict[str, Any]:
    digest = sha256_text(certificate)[:16]
    row_id = str(result.get("row_id") or "row")
    path = Path(work_dir) / f"{row_id[:16]}-{digest}.cpf3.xml"
    path.write_text(certificate, encoding="utf-8")
    start = time.monotonic()
    try:
        proc = subprocess.run(
            [ceta, "--allow-assumptions", str(path)],
            text=True,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            timeout=timeout,
        )
        elapsed = time.monotonic() - start
        if proc.returncode == 0 and "CERTIFIED" in proc.stdout:
            status = "certified"
        else:
            status = "ceta_failed"
        tail = proc.stdout[-4000:]
    except subprocess.TimeoutExpired as exc:
        elapsed = time.monotonic() - start
        status = "timeout"
        tail = (exc.stdout or "")[-4000:] if isinstance(exc.stdout, str) else "timeout"
    keep_file = keep == "all" or (keep == "failures" and status != "certified")
    if keep_file:
        cert_path = str(path)
    else:
        try:
            path.unlink()
        except OSError:
            pass
        cert_path = None
    result.update(
        {
            "status": status,
            "elapsed_sec": round(elapsed, 6),
            "certificate_path": cert_path,
            "ceta_tail": "" if status == "certified" else tail,
        }
    )
    return result


def write_result(sink, result: dict[str, Any], counts: dict[str, int], reasons: dict[str, int], processors: dict[str, int]) -> None:
    status = str(result.get("status"))
    counts[status] = counts.get(status, 0) + 1
    reason = result.get("reason")
    if reason:
        reasons[str(reason)] = reasons.get(str(reason), 0) + 1
    proc = result.get("processor_tag")
    if proc:
        processors[str(proc)] = processors.get(str(proc), 0) + 1
    sink.write(json.dumps(result, sort_keys=True, separators=(",", ":")) + "\n")


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--jsonl", type=Path, default=Path("target/termcomp-proof-corpus/training/subproofs.cpf.canonical.fragment-audit.jsonl.gz"))
    parser.add_argument("--out-dir", type=Path, default=Path("target/termcomp-proof-corpus/fragment-audit/canonical-fragment-audit-full"))
    parser.add_argument("--ceta", type=Path, default=Path(".tools/ceta-relative-bounds"))
    parser.add_argument("--workers", type=int, default=64)
    parser.add_argument("--timeout", type=int, default=30)
    parser.add_argument("--limit", type=int)
    parser.add_argument("--progress-interval", type=int, default=50000)
    parser.add_argument("--keep-certificates", choices=["none", "failures", "all"], default="failures")
    args = parser.parse_args()

    args.out_dir.mkdir(parents=True, exist_ok=True)
    cert_dir = args.out_dir / "certificates"
    cert_dir.mkdir(exist_ok=True)
    results_path = args.out_dir / "results.jsonl.gz"
    summary_path = args.out_dir / "summary.json"

    counts: dict[str, int] = {}
    reasons: dict[str, int] = {}
    processors: dict[str, int] = {}
    processed = 0
    elapsed_total = 0.0
    started = time.monotonic()
    max_pending = max(1, args.workers * 2)
    pending: set[concurrent.futures.Future] = set()

    with gzip.open(results_path, "wt", encoding="utf-8") as sink, concurrent.futures.ThreadPoolExecutor(max_workers=args.workers) as pool:
        def drain_one(wait: bool = False) -> None:
            nonlocal elapsed_total
            if not pending:
                return
            done, _ = concurrent.futures.wait(
                pending,
                timeout=None if wait else 0,
                return_when=concurrent.futures.FIRST_COMPLETED,
            )
            for fut in done:
                pending.remove(fut)
                result = fut.result()
                elapsed_total += float(result.get("elapsed_sec") or 0.0)
                write_result(sink, result, counts, reasons, processors)

        with open_input(args.jsonl) as handle:
            for row_index, line in enumerate(handle, start=1):
                if args.limit is not None and row_index > args.limit:
                    break
                row = json.loads(line)
                processed += 1
                result = base_result(row_index, row)
                audit = row.get("fragment_audit") or {}
                cert = audit.get("cpf3_certificate")
                if cert:
                    while len(pending) >= max_pending:
                        drain_one(wait=True)
                    pending.add(
                        pool.submit(
                            ceta_job,
                            str(args.ceta),
                            str(cert_dir),
                            args.timeout,
                            args.keep_certificates,
                            result,
                            str(cert),
                        )
                    )
                else:
                    result.update({"status": "unsupported", "reason": audit.get("reason") or "no_materialized_certificate"})
                    write_result(sink, result, counts, reasons, processors)
                drain_one(wait=False)
                if args.progress_interval > 0 and processed % args.progress_interval == 0:
                    print(
                        json.dumps(
                            {
                                "event": "progress",
                                "processed": processed,
                                "pending": len(pending),
                                "counts": counts,
                                "elapsed_wall_sec": round(time.monotonic() - started, 3),
                            },
                            sort_keys=True,
                        ),
                        flush=True,
                    )
        while pending:
            drain_one(wait=True)

    summary = {
        "jsonl": str(args.jsonl),
        "results": str(results_path),
        "processed": processed,
        "counts": dict(sorted(counts.items())),
        "reason_counts": dict(sorted(reasons.items())),
        "processor_counts": dict(sorted(processors.items())),
        "ceta_elapsed_total_sec": round(elapsed_total, 6),
        "wall_elapsed_sec": round(time.monotonic() - started, 6),
        "workers": args.workers,
        "timeout": args.timeout,
    }
    summary_path.write_text(json.dumps(summary, indent=2, sort_keys=True), encoding="utf-8")
    print(json.dumps(summary, sort_keys=True), flush=True)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
