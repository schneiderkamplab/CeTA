import copy
import unittest
from compare_standalone_audits import compare


def action(outcome='transformed', certified=False):
    return dict(index=0, problem_key='state', family='poly', source_events='events',
                rename_supported=True, results=[dict(variant=v, outcome=outcome,
                children=1, certified=certified) for v in ('original', 'renamed')])


class ComparisonTests(unittest.TestCase):
    def test_open_is_not_a_certified_gain(self):
        self.assertEqual(compare([], [action()])['gains'], [])

    def test_repaired_terminals(self):
        report = compare([action('solved')], [action('solved', True)])
        self.assertEqual(len(report['gains']), 2)
        self.assertEqual(report['uncertified_terminals'], [])

    def test_loss_and_renaming_difference(self):
        row = action('solved', True)
        changed = copy.deepcopy(row)
        changed['results'][1]['certified'] = False
        report = compare([row], [changed])
        self.assertEqual(report['losses'], [[0, 'renamed']])
        self.assertEqual(report['uncertified_terminals'], [[0, 'renamed']])
        self.assertEqual(report['renaming_differences'], [0])

    def test_reordered_identity_not_compared(self):
        changed = action('solved', True)
        changed['problem_key'] = 'different'
        report = compare([action()], [changed])
        self.assertEqual(report['identity_mismatches'], [0])
        self.assertEqual(report['gains'], [])

    def test_missing_and_duplicate(self):
        self.assertEqual(compare([action()], [])['missing_indices'], [0])
        with self.assertRaises(ValueError):
            compare([], [action(), action()])

    def test_missing_variant(self):
        changed = action()
        changed['results'].pop()
        self.assertEqual(compare([action()], [changed])['missing_variants'], [[0, 'renamed']])


if __name__ == '__main__':
    unittest.main()
