import unittest
from audit_residual_isomorphism import isomorphic


def rule(f, x='x', rhs=None):
    return f'<rule><funapp><name>{f}</name><var>{x}</var></funapp>{rhs or f"<var>{x}</var>"}</rule>'


class IsomorphismTests(unittest.TestCase):
    def test_fresh_functions_need_no_name_convention(self):
        a = '<trsInput><trs><rules>' + rule('new_symbol') + '</rules></trs></trsInput>'
        b = a.replace('new_symbol', 'entirely_different').replace('>x<', '>fresh_var<')
        self.assertEqual(isomorphic(a, b, {}), {'new_symbol': 'entirely_different'})

    def test_bound_symbols_and_variable_sharing_are_preserved(self):
        a = '<rules>' + rule('f') + '</rules>'
        b = a.replace('>f<', '>g<')
        self.assertIsNone(isomorphic(a, b, {('name', 'f'): 'f', ('name', 'g'): 'g'}))
        changed = a.replace('</funapp><var>x', '</funapp><var>y')
        self.assertIsNone(isomorphic(a, changed, {}))

    def test_no_context_fields_can_disappear(self):
        for tag in ('minimal', 'nfs', 'activeRulesAreResidual'):
            a = f'<dpInput><{tag}>true</{tag}></dpInput>'
            self.assertIsNone(isomorphic(a, a.replace('true', 'false'), {}))
        a = '<dpInput><dps><rules>' + rule('f') + '</rules></dps><weakDps/></dpInput>'
        self.assertIsNone(isomorphic(a, a.replace('weakDps', 'strictRules'), {}))

    def test_source_rule_association_moves_with_pairs(self):
        trs = '<trs><rules>' + rule('r0') + rule('r1') + '</rules></trs>'
        p = '<dps><rules>' + rule('p0') + rule('p1') + '</rules></dps>'
        sources = '<ferrumDpStateContext><pairSourceRules><sourceRule>0</sourceRule><sourceRule>1</sourceRule></pairSourceRules></ferrumDpStateContext>'
        a = '<dpInput>' + trs + p + sources + '</dpInput>'
        inverse = {('name', name): name for name in ('r0', 'r1', 'p0', 'p1')}
        p_reversed = '<dps><rules>' + rule('p1') + rule('p0') + '</rules></dps>'
        bad = a.replace(p, p_reversed)
        self.assertIsNone(isomorphic(a, bad, inverse))
        good = bad.replace('<sourceRule>0</sourceRule><sourceRule>1</sourceRule>', '<sourceRule>1</sourceRule><sourceRule>0</sourceRule>')
        self.assertIsNotNone(isomorphic(a, good, inverse))


if __name__ == '__main__':
    unittest.main()
