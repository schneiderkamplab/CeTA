#!/usr/bin/env python3

import json
import subprocess
import tempfile
import unittest
from pathlib import Path


SCRIPT = Path(__file__).with_name("build_certified_runtime_atom_overlay.py")


def event(key: str, processor: str, outcome: str) -> dict:
    return {
        "processor": processor,
        "input": {"problem_key": key},
        "outcome": outcome,
    }


class CertifiedRuntimeAtomOverlayTests(unittest.TestCase):
    def run_script(self, rows, *args, expect_success=True):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            events = root / "events.jsonl"
            output = root / "overlay.jsonl"
            events.write_text("".join(json.dumps(row) + "\n" for row in rows))
            result = subprocess.run(
                [
                    "python3",
                    str(SCRIPT),
                    "--events",
                    str(events),
                    "--atom-prefix",
                    "exact-",
                    "--output",
                    str(output),
                    *args,
                ],
                text=True,
                capture_output=True,
            )
            if expect_success:
                self.assertEqual(result.returncode, 0, result.stderr)
                return [json.loads(line) for line in output.read_text().splitlines()]
            self.assertNotEqual(result.returncode, 0)
            return result

    def test_keeps_only_successful_matching_exact_runtime_events(self):
        rows = self.run_script(
            [
                event("a", "exact-rpo(one)", "transformed"),
                event("b", "exact-rpo(two)", "solved"),
                event("c", "exact-rpo(failed)", "failed"),
                event("d", "matrix(2)", "solved"),
            ]
        )
        witnesses = [row for row in rows if "witness_id" in row]
        guidance = [row for row in rows if "problem_key" in row]
        self.assertEqual(len(witnesses), 2)
        self.assertEqual({row["problem_key"] for row in guidance}, {"a", "b"})
        statuses = {row["problem_key"]: row["prefer"][0]["status"] for row in guidance}
        self.assertEqual(statuses, {"a": "transformed_strong", "b": "solved"})
        self.assertTrue(all("candidate_ref" in row["prefer"][0] for row in guidance))
        self.assertTrue(all(row["prefer"][0]["certified_count"] == 1 for row in guidance))

    def test_weak_mode_never_claims_certification(self):
        rows = self.run_script(
            [event("a", "exact-rpo(one)", "solved")],
            "--status",
            "transformed_weak",
        )
        guidance = next(row for row in rows if "problem_key" in row)
        self.assertEqual(guidance["prefer"], [])
        candidate = guidance["possible"][0]
        self.assertEqual(candidate["status"], "transformed_weak")
        self.assertEqual(candidate["certified_count"], 0)
        self.assertEqual(candidate["solved_count"], 0)

    def test_modular_only_omits_compound_wrappers(self):
        rows = self.run_script([
            event("atom", "exact-rpo(hex=1234)", "transformed"),
            event("compound", "dp(pipeline(graph; size-change))", "transformed"),
            event("plain", "qdp-to-srs", "transformed"),
        ], "--atom-prefix", "", "--modular-only", "--status", "transformed_weak")
        self.assertEqual({r["problem_key"] for r in rows if "problem_key" in r}, {"atom", "plain"})

    def test_generic_atoms_remain_inline(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            events = root / "events.jsonl"
            output = root / "overlay.jsonl"
            events.write_text(json.dumps(event("a", "empty", "solved")) + "\n")
            result = subprocess.run(
                [
                    "python3",
                    str(SCRIPT),
                    "--events",
                    str(events),
                    "--atom-prefix",
                    "",
                    "--output",
                    str(output),
                ],
                text=True,
                capture_output=True,
            )
            self.assertEqual(result.returncode, 0, result.stderr)
            rows = [json.loads(line) for line in output.read_text().splitlines()]
            self.assertEqual(len(rows), 1)
        self.assertEqual(rows[0]["prefer"][0]["candidate"], "empty")

    def test_explicit_certified_key_alias_preserves_source_and_adds_target(self):
        rows = self.run_script(
            [event("old", "exact-graph(witness)", "solved")],
            "--certified-key-alias",
            "old=new",
        )
        guidance = [row for row in rows if "problem_key" in row]
        self.assertEqual({row["problem_key"] for row in guidance}, {"old", "new"})
        self.assertEqual(
            {row["prefer"][0]["candidate_ref"] for row in guidance},
            {next(row["witness_id"] for row in rows if "witness_id" in row)},
        )

    def test_certified_key_alias_requires_a_matching_source_event(self):
        result = self.run_script(
            [event("old", "matrix(2)", "solved")],
            "--certified-key-alias",
            "old=new",
            expect_success=False,
        )
        self.assertIn("alias source has no successful matching atom", result.stderr)

    def test_conflict_policy_is_deterministic_and_drops_unused_witnesses(self):
        events = [
            event("a", "exact-rpo(first)", "transformed"),
            event("a", "exact-rpo(last)", "transformed"),
        ]
        failed = self.run_script(events, expect_success=False)
        self.assertIn("conflicting successful atoms", failed.stderr)
        first = self.run_script(events, "--on-conflict", "first")
        last = self.run_script(events, "--on-conflict", "last")
        self.assertEqual(len([row for row in first if "witness_id" in row]), 1)
        self.assertEqual(len([row for row in last if "witness_id" in row]), 1)
        self.assertEqual(
            next(row["candidate"] for row in first if "witness_id" in row),
            "exact-rpo(first)",
        )
        self.assertEqual(
            next(row["candidate"] for row in last if "witness_id" in row),
            "exact-rpo(last)",
        )


if __name__ == "__main__":
    unittest.main()
