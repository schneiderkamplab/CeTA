#!/usr/bin/env python3
"""Probe canonical CPF subproblems with exploitation, tightening, and exploration.

The source corpus supplies canonical states and accumulated processor evidence.
This runner persists every scheduled (state, atom, timeout) trial in SQLite and
emits ordinary Ferrum processor-event JSONL for reuse by the existing dataset
builder. Interrupted campaigns can be resumed without repeating completed work.
"""

from __future__ import annotations

import argparse
import concurrent.futures
import hashlib
import json
import os
from pathlib import Path
import re
import signal
import shutil
import sqlite3
import subprocess
import tempfile
import threading
import time
from typing import Any
import xml.etree.ElementTree as ET


POSITIVE = {"solved", "transformed_strong", "transformed_weak"}
EXCLUDED = {"llm", "llm-guidance", "utility-guidance", "termination"}
SRS_ONLY = {
    "rfc-relative-match-bounds",
    "srs-length",
    "srs-weighted-length",
    "srs-weighted-rule-removal",
}
TIGHTENABLE_PARAMETERS = {
    "max-constant": 0,
    "max_constant": 0,
    "max-coefficient": 1,
    "max_coefficient": 1,
    "max-coeff": 1,
    "dimension": 1,
    "dim": 1,
    "max-weight": 1,
    "max_weight": 1,
    "weight": 1,
    "alternatives": 1,
    "alts": 1,
    "max-terms": 1,
    "max_terms": 1,
    "denominator": 1,
}
LOWER_RANGE_PARAMETERS = {"min-constant", "min_constant", "min"}

DEFAULT_FRONTIER_ATOMS = {
    "top-level": (
        "uncurry",
        "poly(max-constant=2,max-coefficient=2)",
        "matrix(dim=2,max-constant=2,max-coefficient=1)",
        "kbo(max-weight=2)",
        "path-order",
        "fast-dp",
        "nontermination",
    ),
    "context-sensitive": (
        "csr-innermost",
        "poly(max-constant=2,max-coefficient=2)",
        "matrix(dim=2,max-constant=2,max-coefficient=1)",
        "fast-dp",
        "dp",
        "nontermination",
    ),
    "dependency-pair": (
        "graph",
        "usable-rules",
        "subterm",
        "sct",
        "quadratic-poly(max-constant=1,max-coefficient=1)",
        "poly(max-constant=2,max-coefficient=2)",
        "matrix(dim=2,max-constant=2,max-coefficient=1)",
        "arctic-matrix(dimension=3,max-constant=1,max-coefficient=1)",
        "kbo(max-weight=2)",
        "path-order",
        "rewriting",
        "instantiation",
        "forward-instantiation",
        "narrowing",
        # Generic transformation atoms deterministically select candidate 0.
        # Recursive campaigns must also explore the bounded alternatives: a
        # complete proof can require a lower-ranked candidate even though the
        # first candidate is a sound, productive transformation.
        *(f"narrow(candidate={index},per-pair=2)" for index in range(1, 9)),
        *(f"instantiate(candidate={index},per-pair=2)" for index in range(1, 9)),
        *(
            f"forward-instantiate(candidate={index},per-pair=2)"
            for index in range(1, 9)
        ),
        "nontermination",
    ),
}

PROBE_OUTCOMES = {
    "Solved",
    "Transformed",
    "Inapplicable",
    "Failed",
    "TimedOut",
}
# Complete problem states and proof artifacts are retained separately.  Keeping
# megabytes of repeated inline CPF from processor-event stdout in every trial
# makes the registry needlessly large without adding diagnostic value.
MAX_DIAGNOSTIC_TEXT_BYTES = 128_000

ALLOCATION_FRACTIONS = {
    "unseen": 0.35,
    "hints": 0.25,
    "escalation": 0.20,
    "tightening": 0.15,
    "opposite": 0.05,
}

# Keep every adaptive/local probe within the user-selected competition-scale
# ceiling. Recursive timeout and parameter escalation may use the remaining
# allowance but must not silently create 80/160/300-second atoms.
PROBE_TIMEOUT_CAP_MS = 60_000


def allocation_lane(selection: str) -> str:
    if selection.startswith("diagnostic-"):
        return "opposite"
    if selection in {"tighten", "tighten-certified"}:
        return "tightening"
    if selection in {"timeout-promote", "timeout-escalate", "parameter-escalate"}:
        return "escalation"
    if selection in {"external-proof-hint", "exploit"}:
        return "hints"
    return "unseen"


def allocation_quotas(budget: int) -> dict[str, int]:
    quotas = {
        lane: int(budget * fraction)
        for lane, fraction in ALLOCATION_FRACTIONS.items()
    }
    quotas["unseen"] += budget - sum(quotas.values())
    return quotas


def enforce_initial_allocation(
    connection: sqlite3.Connection, budget: int
) -> dict[str, int]:
    """Retain deterministic pending work within each requested scheduler lane."""
    if budget <= 0:
        return {}
    quotas = allocation_quotas(budget)
    rows = connection.execute(
        """
        SELECT task_key, selection, state FROM trials
        ORDER BY CASE state WHEN 'completed' THEN 0 WHEN 'running' THEN 1 ELSE 2 END,
                 task_key
        """
    ).fetchall()
    retained: dict[str, int] = {lane: 0 for lane in quotas}
    rejected: list[tuple[str]] = []
    for task_key, selection, state in rows:
        lane = allocation_lane(selection)
        if retained[lane] < quotas[lane]:
            retained[lane] += 1
        elif state == "pending":
            rejected.append((task_key,))
    connection.executemany("DELETE FROM trials WHERE task_key=?", rejected)
    connection.commit()
    return retained


def local_name(tag: str) -> str:
    return tag.rsplit("}", 1)[-1]


def raw_problem_hash(cpf: str) -> str:
    return hashlib.sha256(cpf.strip().encode()).hexdigest()


def bounded_diagnostic_text(value: str, limit: int = MAX_DIAGNOSTIC_TEXT_BYTES) -> str:
    encoded = value.encode("utf-8", errors="replace")
    if len(encoded) <= limit:
        return value
    half = limit // 2
    omitted = len(encoded) - 2 * half
    marker = f"\n... <{omitted} diagnostic bytes omitted> ...\n".encode()
    kept = encoded[:half] + marker + encoded[-half:]
    return kept.decode("utf-8", errors="replace")


def canonical_problem(cpf: str) -> tuple[str, str]:
    """Return a deterministic XML serialization and its content hash.

    Corpus states may already have a stronger symbol-canonical key.  This
    structural canonicalization is used for newly generated residuals until a
    later semantic canonicalization pass aliases them.
    """
    try:
        canonical = ET.canonicalize(cpf.strip(), strip_text=True)
    except (ET.ParseError, ValueError):
        canonical = cpf.strip()
    return canonical, hashlib.sha256(canonical.encode()).hexdigest()


def first_element(root: ET.Element, name: str) -> ET.Element | None:
    return next((node for node in root.iter() if local_name(node.tag) == name), None)


def element_text(root: ET.Element, name: str) -> str | None:
    node = first_element(root, name)
    if node is None or node.text is None:
        return None
    return node.text.strip()


def typed_problem_context(cpf: str) -> dict[str, Any]:
    """Extract the complete state discriminator retained by CPF inputs.

    Unknown extension elements are retained as canonical XML in
    ``transformation_context`` so adding a producer-side context cannot
    silently alias it to a weaker state.
    """
    try:
        root = ET.fromstring(cpf)
    except ET.ParseError as error:
        return {
            "kind": "invalid",
            "parse_error": str(error),
            "strategy": "unknown",
            "minimal": None,
            "usable_rules": None,
            "q": None,
            "replacement_map": [],
            "transformation_context": [],
        }
    problem = root if local_name(root.tag) in {"trsInput", "dpInput"} else None
    if problem is None:
        problem = next(
            (
                node
                for node in root.iter()
                if local_name(node.tag) in {"trsInput", "dpInput"}
            ),
            root,
        )
    names = {local_name(node.tag) for node in problem.iter()}
    strategy = (
        "context-sensitive"
        if "contextSensitive" in names
        else "innermost"
        if "innermost" in names
        else "full"
    )
    replacement_map: list[dict[str, Any]] = []
    context_sensitive = first_element(problem, "contextSensitive")
    if context_sensitive is not None:
        for entry in context_sensitive:
            if local_name(entry.tag) != "replacementMapEntry":
                continue
            symbol = next(
                (
                    node
                    for node in entry
                    if local_name(node.tag) in {"name", "sharp", "labeledSymbol"}
                ),
                None,
            )
            replacement_map.append(
                {
                    "symbol_xml": (
                        ET.canonicalize(
                            ET.tostring(symbol, encoding="unicode"), strip_text=True
                        )
                        if symbol is not None
                        else None
                    ),
                    "positions": sorted(
                        int(node.text.strip())
                        for node in entry
                        if local_name(node.tag) == "position"
                        and node.text
                        and node.text.strip().isdigit()
                    ),
                }
            )
    minimal_text = element_text(problem, "minimal")
    minimal = (
        minimal_text.lower() == "true" if minimal_text is not None else None
    )
    q_node = first_element(problem, "q")
    if q_node is None:
        q_node = first_element(problem, "Q")
    usable_node = first_element(problem, "usableRules")
    known = {
        "trs",
        "dps",
        "strategy",
        "minimal",
        "usableRules",
        "q",
        "Q",
    }
    transformation_context = [
        ET.canonicalize(ET.tostring(node, encoding="unicode"), strip_text=True)
        for node in problem
        if local_name(node.tag) not in known
    ]
    is_dp = local_name(problem.tag) == "dpInput"
    is_string = bool({"string", "word"} & names)
    if is_dp and strategy == "context-sensitive":
        kind = "qcs-dp" if minimal is True else "csdp"
    elif is_dp:
        kind = "qdp" if minimal is True else "dp"
    elif strategy == "context-sensitive":
        kind = "cs-trs"
    elif is_string:
        kind = "srs"
    elif strategy == "innermost":
        kind = "innermost-trs"
    else:
        kind = "trs"
    return {
        "kind": kind,
        "strategy": strategy,
        "minimal": minimal,
        "usable_rules": (
            ET.canonicalize(
                ET.tostring(usable_node, encoding="unicode"), strip_text=True
            )
            if usable_node is not None
            else None
        ),
        "q": (
            ET.canonicalize(ET.tostring(q_node, encoding="unicode"), strip_text=True)
            if q_node is not None
            else None
        ),
        "replacement_map": replacement_map,
        "transformation_context": transformation_context,
    }


def problem_kind(cpf: str) -> str:
    return str(typed_problem_context(cpf)["kind"])


def extract_child_problems(certificate: str) -> list[str]:
    """Extract complete residual inputs guarded by checker assumptions."""
    try:
        root = ET.fromstring(certificate)
    except ET.ParseError:
        return []
    children: list[str] = []
    seen: set[str] = set()
    for assumption in root.iter():
        if local_name(assumption.tag) not in {
            "terminationAssumption",
            "finitenessAssumption",
            "csrTerminationAssumption",
        }:
            continue
        for node in assumption.iter():
            if local_name(node.tag) not in {"trsInput", "dpInput"}:
                continue
            cpf = ET.tostring(node, encoding="unicode")
            key = raw_problem_hash(cpf)
            if key not in seen:
                seen.add(key)
                children.append(cpf)
            break
    return children


def validate_materialized_child(cpf: str) -> tuple[bool, str]:
    context = typed_problem_context(cpf)
    if context["kind"] == "invalid":
        return False, str(context.get("parse_error") or "invalid XML")
    try:
        root = ET.fromstring(cpf)
    except ET.ParseError as error:
        return False, str(error)
    if local_name(root.tag) not in {"trsInput", "dpInput"}:
        return False, "child is not a standalone trsInput or dpInput"
    required = {"trs"}
    if local_name(root.tag) == "dpInput":
        required.add("dps")
    direct = {local_name(node.tag) for node in root}
    missing = sorted(required - direct)
    if missing:
        return False, f"child is missing {', '.join(missing)}"
    if context["strategy"] == "context-sensitive" and not context["replacement_map"]:
        # An empty replacement map is represented by zero entries, but the
        # contextSensitive node itself must still be explicit.
        if first_element(root, "contextSensitive") is None:
            return False, "context-sensitive child lost its replacement map"
    return True, ""
def normalize_candidate(candidate: str) -> str:
    """Turn historical debug spellings into executable strategy atoms."""
    if candidate == "CsrLoop":
        return "csr-loop"
    if not candidate.startswith("SrsRfcRelativeMatchBounds-{-"):
        return candidate
    fields = dict(
        re.findall(
            r"(max_bound|max_words|max_word_len|max_states|max_transitions|"
            r"at_bound|closure):-?([A-Za-z0-9]+)",
            candidate,
        )
    )
    ordered = (
        ("max-bound", "max_bound"),
        ("max-words", "max_words"),
        ("max-word-len", "max_word_len"),
        ("max-states", "max_states"),
        ("max-transitions", "max_transitions"),
        ("at-bound", "at_bound"),
        ("closure", "closure"),
    )
    arguments = [
        f"{output_name}={fields[source_name].lower()}"
        for output_name, source_name in ordered
        if source_name in fields
    ]
    if not arguments:
        return candidate
    return f"rfc-relative-match-bounds({','.join(arguments)})"


def problem_level(cpf: str) -> str:
    if "<dpInput" in cpf:
        return "dependency-pair"
    if "<contextSensitive" in cpf:
        return "context-sensitive"
    return "top-level"


def stable_jitter(seed: int, problem_key: str, candidate: str) -> int:
    digest = hashlib.sha256(f"{seed}\0{problem_key}\0{candidate}".encode()).digest()
    return int.from_bytes(digest[:8], "big")


def processor_family(candidate: str) -> str:
    head = candidate.split("(", 1)[0]
    if head in {
        "poly",
        "sat-poly",
        "weak-poly",
        "max-poly",
        "rational-poly",
        "symbol-weights",
    }:
        return "algebraic-interpretation"
    if head == "quadratic-poly":
        # Keep degree-2 synthesis as its own exploration family.  Otherwise a
        # previously attempted linear polynomial order suppresses it in the
        # distinct-family frontier allocation.
        return "quadratic-polynomial"
    if head in {"path-order", "lpo", "rpo", "q-lpo", "q-rpo"}:
        return "path-order"
    if head.startswith("nontermination"):
        return "nontermination"
    return head


def candidate_applicable(candidate: str, run_problem_like: str | None) -> bool:
    if run_problem_like is None:
        return True
    head = candidate.split("(", 1)[0]
    if "TRS_" in run_problem_like and head in SRS_ONLY:
        return False
    return True


def split_strategy_arguments(arguments: str) -> list[str]:
    parts: list[str] = []
    depth = 0
    start = 0
    for index, character in enumerate(arguments):
        if character == "(":
            depth += 1
        elif character == ")":
            depth -= 1
            if depth < 0:
                return []
        elif character == "," and depth == 0:
            parts.append(arguments[start:index].strip())
            start = index + 1
    if depth != 0:
        return []
    parts.append(arguments[start:].strip())
    return parts


def smaller_values(value: int, minimum: int) -> list[int]:
    if value <= minimum:
        return []
    candidates = {minimum, value - 1}
    if minimum < 1 < value:
        candidates.add(1)
    midpoint = minimum + (value - minimum) // 2
    if minimum < midpoint < value:
        candidates.add(midpoint)
    return sorted(candidates)


def tightening_variants(candidate: str) -> list[str]:
    open_parenthesis = candidate.find("(")
    if open_parenthesis <= 0 or not candidate.endswith(")"):
        return []
    arguments = split_strategy_arguments(candidate[open_parenthesis + 1 : -1])
    if not arguments:
        return []

    parsed: list[tuple[str, str, int] | None] = []
    for argument in arguments:
        if "=" not in argument:
            parsed.append(None)
            continue
        name, raw_value = (part.strip() for part in argument.split("=", 1))
        try:
            value = int(raw_value)
        except ValueError:
            parsed.append(None)
            continue
        parsed.append((name, raw_value, value))

    replacements: list[tuple[int, str, list[int]]] = []
    for index, parameter in enumerate(parsed):
        if parameter is None:
            continue
        name, _raw_value, value = parameter
        if name in TIGHTENABLE_PARAMETERS:
            values = smaller_values(value, TIGHTENABLE_PARAMETERS[name])
        elif name in LOWER_RANGE_PARAMETERS and value < 0:
            values = sorted({0, value + 1}, reverse=True)
        else:
            values = []
        if values:
            replacements.append((index, name, values))
    if not replacements:
        return []

    def render(changes: dict[int, int]) -> str:
        rendered = list(arguments)
        for index, value in changes.items():
            parameter = parsed[index]
            assert parameter is not None
            rendered[index] = f"{parameter[0]}={value}"
        return f"{candidate[:open_parenthesis]}({','.join(rendered)})"

    variants: list[str] = []
    # First test the smallest combined proof class, then isolate each parameter.
    variants.append(render({index: values[0] for index, _name, values in replacements}))
    parameter_priority = {
        "dimension": 0,
        "dim": 0,
        "max-coefficient": 1,
        "max_coefficient": 1,
        "max-coeff": 1,
        "alternatives": 2,
        "alts": 2,
        "max-terms": 2,
        "max_terms": 2,
        "denominator": 3,
        "max-constant": 4,
        "max_constant": 4,
        "max-weight": 5,
        "max_weight": 5,
        "weight": 5,
        "min-constant": 6,
        "min_constant": 6,
        "min": 6,
    }
    for index, name, values in sorted(
        replacements, key=lambda replacement: (parameter_priority[replacement[1]], replacement[0])
    ):
        variants.extend(render({index: value}) for value in values)
    return list(dict.fromkeys(variant for variant in variants if variant != candidate))


PARAMETER_EXPANSION_CAPS = {
    "dimension": 4,
    "dim": 4,
    "max-coefficient": 8,
    "max_coefficient": 8,
    "max-coeff": 8,
    "max-constant": 8,
    "max_constant": 8,
    "max-weight": 16,
    "max_weight": 16,
    "weight": 16,
    "alternatives": 4,
    "alts": 4,
    "max-terms": 4,
    "max_terms": 4,
    "denominator": 8,
    "max-per-pair": 8,
    "per-pair": 8,
}


def parameter_expansion_variants(candidate: str) -> list[str]:
    """Return bounded one-parameter expansions for a timed-out supported atom."""
    open_parenthesis = candidate.find("(")
    if open_parenthesis <= 0 or not candidate.endswith(")"):
        return []
    arguments = split_strategy_arguments(candidate[open_parenthesis + 1 : -1])
    variants: list[str] = []
    for index, argument in enumerate(arguments):
        if "=" not in argument:
            continue
        name, raw_value = (part.strip() for part in argument.split("=", 1))
        cap = PARAMETER_EXPANSION_CAPS.get(name)
        if cap is None:
            continue
        try:
            value = int(raw_value)
        except ValueError:
            continue
        if value < 1 or value >= cap:
            continue
        expanded = min(cap, value * 2)
        rendered = list(arguments)
        rendered[index] = f"{name}={expanded}"
        variants.append(f"{candidate[:open_parenthesis]}({','.join(rendered)})")
    return list(dict.fromkeys(variants))


def terminate_group(process: subprocess.Popen[str]) -> None:
    try:
        os.killpg(process.pid, signal.SIGTERM)
    except ProcessLookupError:
        return
    deadline = time.monotonic() + 2.0
    while process.poll() is None and time.monotonic() < deadline:
        time.sleep(0.05)
    if process.poll() is None:
        try:
            os.killpg(process.pid, signal.SIGKILL)
        except ProcessLookupError:
            pass


def initialize_results(connection: sqlite3.Connection) -> None:
    connection.executescript(
        """
        CREATE TABLE IF NOT EXISTS trials (
            task_key TEXT PRIMARY KEY,
            problem_key TEXT NOT NULL,
            candidate TEXT NOT NULL,
            selection TEXT NOT NULL,
            source_candidate TEXT,
            validity_mask INTEGER NOT NULL DEFAULT 0,
            timeout_ms INTEGER NOT NULL,
            state TEXT NOT NULL DEFAULT 'pending',
            outcome TEXT,
            decision TEXT,
            level TEXT,
            elapsed_ms INTEGER,
            return_code INTEGER,
            stdout TEXT,
            stderr TEXT,
            event_rows INTEGER NOT NULL DEFAULT 0,
            cpf_path TEXT,
            cpf_bytes INTEGER NOT NULL DEFAULT 0,
            certification_status TEXT,
            ceta_return_code INTEGER,
            ceta_elapsed_ms INTEGER,
            ceta_stdout TEXT,
            ceta_stderr TEXT,
            implementation_hash TEXT,
            started_at TEXT,
            finished_at TEXT
        );
        CREATE INDEX IF NOT EXISTS trials_state_idx ON trials(state);
        CREATE INDEX IF NOT EXISTS trials_problem_idx ON trials(problem_key);
        CREATE TABLE IF NOT EXISTS states (
            raw_hash TEXT PRIMARY KEY,
            canonical_hash TEXT NOT NULL,
            source_problem_key TEXT,
            cpf TEXT NOT NULL,
            problem_kind TEXT NOT NULL,
            level TEXT NOT NULL,
            typed_context TEXT NOT NULL DEFAULT '{}',
            validity_mask INTEGER NOT NULL DEFAULT 0,
            canonicalization_status TEXT NOT NULL,
            first_seen_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
        );
        CREATE INDEX IF NOT EXISTS states_canonical_idx
            ON states(canonical_hash);
        CREATE TABLE IF NOT EXISTS state_origins (
            raw_hash TEXT NOT NULL,
            root_problem TEXT NOT NULL,
            proof_position TEXT NOT NULL DEFAULT '',
            PRIMARY KEY(raw_hash, root_problem, proof_position)
        );
        CREATE TABLE IF NOT EXISTS state_aliases (
            alias_raw_hash TEXT PRIMARY KEY,
            state_raw_hash TEXT NOT NULL,
            alias_kind TEXT NOT NULL,
            created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
        );
        CREATE INDEX IF NOT EXISTS state_aliases_state_idx
            ON state_aliases(state_raw_hash);
        CREATE TABLE IF NOT EXISTS transitions (
            transition_key TEXT PRIMARY KEY,
            parent_raw_hash TEXT NOT NULL,
            child_raw_hash TEXT NOT NULL,
            task_key TEXT NOT NULL,
            processor_atom TEXT NOT NULL,
            sound INTEGER NOT NULL,
            complete INTEGER NOT NULL,
            certification_status TEXT NOT NULL,
            proof_fragment_path TEXT,
            child_index INTEGER NOT NULL DEFAULT 0,
            implementation_hash TEXT NOT NULL,
            created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
        );
        CREATE INDEX IF NOT EXISTS transitions_parent_idx
            ON transitions(parent_raw_hash);
        CREATE INDEX IF NOT EXISTS transitions_child_idx
            ON transitions(child_raw_hash);
        CREATE TABLE IF NOT EXISTS terminal_proofs (
            raw_hash TEXT NOT NULL,
            task_key TEXT NOT NULL,
            processor_atom TEXT NOT NULL,
            decision TEXT,
            certification_status TEXT NOT NULL,
            proof_path TEXT NOT NULL,
            implementation_hash TEXT NOT NULL,
            elapsed_ms INTEGER,
            PRIMARY KEY(raw_hash, task_key)
        );
        CREATE TABLE IF NOT EXISTS assembled_proofs (
            raw_hash TEXT NOT NULL,
            transition_task_key TEXT NOT NULL,
            proof_path TEXT NOT NULL,
            checker_path TEXT NOT NULL,
            checker_result TEXT NOT NULL,
            checker_digest TEXT NOT NULL,
            deterministic_recheck INTEGER NOT NULL DEFAULT 0,
            implementation_hash TEXT NOT NULL,
            elapsed_ms INTEGER,
            created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY(raw_hash, transition_task_key)
        );
        CREATE TABLE IF NOT EXISTS reconstruction_contexts (
            transition_key TEXT PRIMARY KEY,
            parent_raw_hash TEXT NOT NULL,
            child_raw_hash TEXT NOT NULL,
            child_index INTEGER NOT NULL,
            assumption_kind TEXT NOT NULL,
            assumption_hash TEXT NOT NULL,
            fragment_path TEXT NOT NULL
        );
        CREATE VIEW IF NOT EXISTS oracle_evidence AS
        SELECT
            s.raw_hash,
            s.canonical_hash,
            t.candidate AS processor_atom,
            t.outcome,
            t.certification_status,
            t.elapsed_ms,
            t.timeout_ms,
            t.selection,
            t.implementation_hash,
            CASE
                WHEN t.certification_status = 'certified-full' THEN 4
                WHEN t.outcome = 'failed' THEN 1
                WHEN t.outcome = 'timeout' THEN 0
                ELSE 2
            END AS evidence_rank
        FROM states s
        JOIN trials t
          ON t.problem_key = s.raw_hash
          OR t.problem_key = s.source_problem_key;
        UPDATE trials SET state = 'pending' WHERE state = 'running';
        """
    )
    columns = {
        row[1] for row in connection.execute("PRAGMA table_info(trials)").fetchall()
    }
    if "source_candidate" not in columns:
        connection.execute("ALTER TABLE trials ADD COLUMN source_candidate TEXT")
    if "decision" not in columns:
        connection.execute("ALTER TABLE trials ADD COLUMN decision TEXT")
    if "validity_mask" not in columns:
        connection.execute(
            "ALTER TABLE trials ADD COLUMN validity_mask INTEGER NOT NULL DEFAULT 0"
        )
    additions = {
        "cpf_path": "TEXT",
        "cpf_bytes": "INTEGER NOT NULL DEFAULT 0",
        "certification_status": "TEXT",
        "ceta_return_code": "INTEGER",
        "ceta_elapsed_ms": "INTEGER",
        "ceta_stdout": "TEXT",
        "ceta_stderr": "TEXT",
        "implementation_hash": "TEXT",
    }
    for name, declaration in additions.items():
        if name not in columns:
            connection.execute(f"ALTER TABLE trials ADD COLUMN {name} {declaration}")
    transition_columns = {
        row[1] for row in connection.execute("PRAGMA table_info(transitions)")
    }
    if "child_index" not in transition_columns:
        connection.execute(
            "ALTER TABLE transitions ADD COLUMN child_index INTEGER NOT NULL DEFAULT 0"
        )
    connection.commit()


def register_state(
    connection: sqlite3.Connection,
    cpf: str,
    *,
    source_problem_key: str | None = None,
    canonical_hash: str | None = None,
    validity_mask: int = 0,
    origin: str | None = None,
    proof_position: str = "",
    canonical_cache: sqlite3.Connection | None = None,
) -> tuple[str, bool]:
    raw_hash = raw_problem_hash(cpf)
    cached = (
        canonical_cache.execute(
            """
            SELECT canonical_cpf, note FROM canonical_cpf_cache
            WHERE raw_key = ?
            """,
            (raw_hash,),
        ).fetchone()
        if canonical_cache is not None
        else None
    )
    semantic_hash = (
        hashlib.sha256(cached[0].encode()).hexdigest()
        if cached is not None and cached[1] is None
        else None
    )
    structural_hash = (
        canonical_problem(cpf)[1]
        if semantic_hash is None and canonical_hash is None
        else raw_hash
    )
    chosen_canonical = semantic_hash or canonical_hash or structural_hash
    status = (
        "semantic-cache"
        if semantic_hash is not None
        else "source-canonical"
        if canonical_hash
        else "structural-pending"
    )
    typed_context = typed_problem_context(cpf)
    cursor = connection.execute(
        """
        INSERT OR IGNORE INTO states(
            raw_hash, canonical_hash, source_problem_key, cpf, problem_kind,
            level, typed_context, validity_mask, canonicalization_status
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
        """,
        (
            raw_hash,
            chosen_canonical,
            source_problem_key,
            cpf,
            problem_kind(cpf),
            problem_level(cpf),
            json.dumps(typed_context, sort_keys=True),
            validity_mask,
            status,
        ),
    )
    connection.execute(
        """
        UPDATE states SET
            validity_mask = validity_mask | ?,
            source_problem_key = COALESCE(source_problem_key, ?)
        WHERE raw_hash = ?
        """,
        (validity_mask, source_problem_key, raw_hash),
    )
    if origin is not None:
        connection.execute(
            """
            INSERT OR IGNORE INTO state_origins(
                raw_hash, root_problem, proof_position
            ) VALUES (?, ?, ?)
            """,
            (raw_hash, origin, proof_position),
        )
    return raw_hash, bool(cursor.rowcount)


def runtime_canonical_hash(
    ferrum: Path,
    cpf: str,
    *,
    timeout_seconds: float = 60.0,
) -> str:
    """Return the exact key queried by Ferrum's canonical runtime lookup."""
    with tempfile.NamedTemporaryFile(
        mode="w", suffix=".xml", encoding="utf-8"
    ) as source:
        source.write(cpf)
        source.flush()
        completed = subprocess.run(
            [str(ferrum), "canonicalize-cpf", source.name],
            text=True,
            capture_output=True,
            timeout=timeout_seconds,
            check=False,
        )
    if completed.returncode:
        raise RuntimeError(
            "Ferrum runtime canonicalization failed: "
            + completed.stderr.strip()
        )
    canonical = completed.stdout.strip()
    if not canonical:
        raise RuntimeError("Ferrum runtime canonicalization returned an empty state")
    return hashlib.sha256(canonical.encode()).hexdigest()


def import_source_registry(
    source: sqlite3.Connection,
    results: sqlite3.Connection,
    cpfs: dict[str, str],
    canonical_cache: sqlite3.Connection | None = None,
    ferrum: Path | None = None,
) -> dict[str, str]:
    problem_columns = {
        row[1] for row in source.execute("PRAGMA table_info(problems)")
    }
    validity_expression = "validity_mask" if "validity_mask" in problem_columns else "0"
    tables = {
        item[0]
        for item in source.execute(
            "SELECT name FROM sqlite_master WHERE type='table'"
        )
    }
    selected_keys = set(cpfs)
    validity_by_key = dict(
        source.execute(
            f"""
            SELECT problem_key, {validity_expression}
            FROM problems
            """
        )
    )
    origins_by_key: dict[str, list[str]] = {}
    if "observations" in tables:
        for problem_key, root_problem in source.execute(
            """
            SELECT problem_key, run_problem_key
            FROM observations
            GROUP BY problem_key, run_problem_key
            """
        ):
            if problem_key in selected_keys:
                origins_by_key.setdefault(problem_key, []).append(root_problem)
    aliases_by_key: dict[str, list[tuple[str, str]]] = {}
    if "problem_aliases" in tables:
        for problem_key, alias_raw_hash, alias_kind in source.execute(
            """
            SELECT problem_key, raw_problem_key, source
            FROM problem_aliases
            """
        ):
            if problem_key in selected_keys:
                aliases_by_key.setdefault(problem_key, []).append(
                    (alias_raw_hash, alias_kind)
                )
    raw_by_source: dict[str, str] = {}
    for problem_key, cpf in cpfs.items():
        validity_mask = int(validity_by_key.get(problem_key, 0))
        raw_hash, _ = register_state(
            results,
            cpf,
            source_problem_key=problem_key,
            canonical_hash=problem_key,
            validity_mask=validity_mask,
            canonical_cache=canonical_cache,
        )
        raw_by_source[problem_key] = raw_hash
        if ferrum is not None:
            runtime_hash = runtime_canonical_hash(ferrum, cpf)
            # Ferrum queries this exact semantic key. Distinct extracted XML
            # serializations may intentionally share it, and their evidence
            # must therefore merge on this key instead of remaining split
            # across Python-only canonical hashes.
            results.execute(
                """
                UPDATE states SET canonical_hash=?, canonicalization_status=?
                WHERE raw_hash=?
                """,
                (runtime_hash, "ferrum-runtime", raw_hash),
            )
        for root_problem in origins_by_key.get(problem_key, ()):
            results.execute(
                """
                INSERT OR IGNORE INTO state_origins(
                    raw_hash, root_problem, proof_position
                ) VALUES (?, ?, '')
                """,
                (raw_hash, root_problem),
            )
        for alias_raw_hash, alias_kind in aliases_by_key.get(problem_key, ()):
            results.execute(
                """
                INSERT OR REPLACE INTO state_aliases(
                    alias_raw_hash, state_raw_hash, alias_kind
                ) VALUES (?, ?, ?)
                """,
                (alias_raw_hash, raw_hash, alias_kind),
            )
    results.commit()
    return raw_by_source


def candidate_pools(
    source: sqlite3.Connection,
    run_problem_like: str | None,
    problem_level_filter: str | None = None,
    selected_only: bool = False,
) -> dict[str, list[str]]:
    if problem_level_filter == "context-sensitive":
        return {
            "top-level": [],
            "context-sensitive": [
                "poly(max-constant=2,max-coefficient=2)",
                "csr-innermost",
                "fast-dp",
                "dp",
            ],
            "dependency-pair": [],
        }
    pools: dict[str, dict[str, tuple[int, float]]] = {
        "top-level": {},
        "context-sensitive": {},
        "dependency-pair": {},
    }
    selected_join = (
        "JOIN temp.campaign_selected_keys selected ON selected.problem_key = p.problem_key"
        if selected_only
        else ""
    )
    rows = source.execute(
        f"""
        SELECT p.cpf, c.candidate, COUNT(*) AS states,
               AVG(c.utility_score) AS utility
        FROM candidates c JOIN problems p USING(problem_key)
        {selected_join}
        GROUP BY CASE
                   WHEN instr(p.cpf, '<dpInput') > 0 THEN 2
                   WHEN instr(p.cpf, '<contextSensitive') > 0 THEN 1
                   ELSE 0
                 END,
                 c.candidate
        """
    )
    for cpf, candidate, states, utility in rows:
        candidate = normalize_candidate(candidate)
        if candidate in EXCLUDED or not candidate_applicable(
            candidate, run_problem_like
        ):
            continue
        old_states, old_utility = pools[problem_level(cpf)].get(candidate, (0, 0.0))
        combined_states = old_states + int(states)
        combined_utility = (
            old_utility * old_states + float(utility) * int(states)
        ) / combined_states
        pools[problem_level(cpf)][candidate] = (
            combined_states,
            combined_utility,
        )
    observed = {
        level: [
            candidate
            for candidate, _ in sorted(
                values.items(),
                key=lambda item: (-item[1][1], item[1][0], item[0]),
            )
        ]
        for level, values in pools.items()
    }
    return {
        level: list(
            dict.fromkeys(DEFAULT_FRONTIER_ATOMS[level] + tuple(observed[level]))
        )
        for level in observed
    }


def schedule_tasks(
    source: sqlite3.Connection,
    results: sqlite3.Connection,
    prior_ledgers: list[Path],
    exploit: int,
    tighten: int,
    explore: int,
    frequent_explore: int,
    frequency_threshold: int,
    extra_exploration_budget: int,
    dual_probe: bool,
    timeout_ms: int,
    seed: int,
    limit: int | None,
    implementation_hash: str,
    run_problem_like: str | None,
    candidate_hints: dict[str, list[str]],
    candidate_hint_cpfs: dict[str, str],
    hint_limit: int,
    hinted_only: bool,
    problem_level_filter: str | None = None,
    run_problem_prefix: str | None = None,
) -> tuple[int, dict[str, str]]:
    promoted_timeouts: dict[str, list[str]] = {}
    certified_trials: set[tuple[str, str]] = set()
    for ledger_path in prior_ledgers:
        if not ledger_path.exists():
            continue
        prior = sqlite3.connect(f"file:{ledger_path}?mode=ro", uri=True)
        try:
            columns = {
                row[1] for row in prior.execute("PRAGMA table_info(trials)").fetchall()
            }
            for problem_key, candidate in prior.execute(
                """
                SELECT problem_key, candidate
                FROM trials
                WHERE state = 'completed' AND outcome = 'timeout' AND timeout_ms < ?
                ORDER BY timeout_ms DESC, candidate
                """,
                (timeout_ms,),
            ):
                candidates = promoted_timeouts.setdefault(problem_key, [])
                if candidate not in candidates:
                    candidates.append(candidate)
            if "implementation_hash" in columns and "certification_status" in columns:
                certified_trials.update(
                    prior.execute(
                        """
                        SELECT problem_key, candidate
                        FROM trials
                        WHERE state = 'completed'
                          AND certification_status = 'certified-full'
                          AND implementation_hash = ?
                        """,
                        (implementation_hash,),
                    )
                )
        finally:
            prior.close()
    cpfs: dict[str, str] = {}
    problem_columns = {
        row[1] for row in source.execute("PRAGMA table_info(problems)").fetchall()
    }
    validity_expression = "validity_mask" if "validity_mask" in problem_columns else "0"
    frequency_expression = "occurrences" if "occurrences" in problem_columns else "rows"
    problem_joins: list[str] = []
    selected_only = False
    if run_problem_prefix is not None:
        source.execute(
            "CREATE TEMP TABLE IF NOT EXISTS campaign_selected_keys("
            "problem_key TEXT PRIMARY KEY)"
        )
        source.execute("DELETE FROM campaign_selected_keys")
        source.execute(
            """
            INSERT OR IGNORE INTO campaign_selected_keys
            SELECT problem_key
            FROM observations
            WHERE run_problem_key >= ? AND run_problem_key < ?
            GROUP BY problem_key
            """,
            (run_problem_prefix, run_problem_prefix + "\uffff"),
        )
        problem_joins.append("JOIN campaign_selected_keys USING(problem_key)")
        selected_only = True
    if run_problem_like is not None:
        source.execute(
            "CREATE TEMP TABLE IF NOT EXISTS campaign_subset_keys("
            "problem_key TEXT PRIMARY KEY)"
        )
        source.execute("DELETE FROM campaign_subset_keys")
        source.execute(
            """
            INSERT OR IGNORE INTO campaign_subset_keys
            SELECT problem_key
            FROM observations
            WHERE run_problem_key LIKE ?
            GROUP BY problem_key
            """,
            (run_problem_like,),
        )
        problem_joins.append("JOIN campaign_subset_keys USING(problem_key)")
    if hinted_only:
        source.execute(
            "CREATE TEMP TABLE IF NOT EXISTS campaign_hint_keys("
            "problem_key TEXT PRIMARY KEY)"
        )
        source.execute("DELETE FROM campaign_hint_keys")
        source.executemany(
            "INSERT OR IGNORE INTO campaign_hint_keys VALUES (?)",
            ((problem_key,) for problem_key in candidate_hints),
        )
        problem_joins.append("JOIN campaign_hint_keys USING(problem_key)")
    joins = "\n".join(problem_joins)
    level_predicates = {
        "top-level": (
            "instr(cpf, '<dpInput') = 0 AND "
            "instr(cpf, '<contextSensitive') = 0"
        ),
        "context-sensitive": "instr(cpf, '<contextSensitive') > 0",
        "dependency-pair": "instr(cpf, '<dpInput') > 0",
    }
    where_clause = (
        f"WHERE {level_predicates[problem_level_filter]}"
        if problem_level_filter is not None
        else ""
    )
    limit_clause = "" if limit is None else "LIMIT ?"
    query_parameters: tuple[object, ...] = ()
    if limit is not None:
        query_parameters += (limit,)
    problems = source.execute(
        f"""
        SELECT problems.problem_key, cpf, {validity_expression},
               {frequency_expression}
        FROM problems
        {joins}
        {where_clause}
        ORDER BY problems.problem_key
        {limit_clause}
        """,
        query_parameters,
    ).fetchall()
    existing_problem_keys = {row[0] for row in problems}
    for problem_key, cpf in sorted(candidate_hint_cpfs.items()):
        if problem_key in existing_problem_keys:
            continue
        if problem_level_filter == "dependency-pair" and "<dpInput" not in cpf:
            continue
        if problem_level_filter == "context-sensitive" and "<contextSensitive" not in cpf:
            continue
        if problem_level_filter == "top-level" and (
            "<dpInput" in cpf or "<contextSensitive" in cpf
        ):
            continue
        problems.append((problem_key, cpf, 0, 1))
        existing_problem_keys.add(problem_key)
    pools = (
        candidate_pools(
            source,
            run_problem_like,
            problem_level_filter,
            selected_only=selected_only,
        )
        if explore > 0 or frequent_explore > 0
        else {"top-level": [], "context-sensitive": [], "dependency-pair": []}
    )
    extra_per_state = max(0, frequent_explore - explore)
    adaptive_state_limit = (
        extra_exploration_budget // extra_per_state if extra_per_state > 0 else 0
    )
    selected_problem_keys = {row[0] for row in problems}
    adaptive_rows = sorted(
        (
            (problem_key, frequency)
            for problem_key, _cpf, _validity_mask, frequency in problems
            if problem_key in selected_problem_keys
        ),
        key=lambda row: (-int(row[1]), row[0]),
    )
    adaptive_keys = {
        problem_key
        for problem_key, frequency in adaptive_rows[:adaptive_state_limit]
        if int(frequency) >= frequency_threshold
    }
    remaining_extra_budget = extra_exploration_budget
    scheduled = 0
    for problem_key, cpf, validity_mask, _frequency in problems:
        cpfs[problem_key] = cpf
        raw_local = source.execute(
            """
            SELECT candidate, best_status, utility_score, attempts
            FROM candidates WHERE problem_key = ?
            ORDER BY utility_score DESC, best_rank DESC, best_elapsed_ms, candidate
            """,
            (problem_key,),
        ).fetchall()
        local_by_candidate: dict[str, tuple[str, float, int]] = {}
        for candidate, status, utility, attempt_count in raw_local:
            candidate = normalize_candidate(candidate)
            previous = local_by_candidate.get(candidate)
            if previous is None:
                local_by_candidate[candidate] = (
                    status,
                    float(utility),
                    int(attempt_count),
                )
                continue
            total_attempts = previous[2] + int(attempt_count)
            is_better = (
                status in POSITIVE
                and previous[0] not in POSITIVE
            ) or (
                (status in POSITIVE) == (previous[0] in POSITIVE)
                and float(utility) > previous[1]
            )
            if is_better:
                local_by_candidate[candidate] = (
                    status,
                    float(utility),
                    total_attempts,
                )
            else:
                local_by_candidate[candidate] = (
                    previous[0],
                    previous[1],
                    total_attempts,
                )
        local = [
            (candidate, status, utility, attempt_count)
            for candidate, (status, utility, attempt_count) in local_by_candidate.items()
        ]
        local.sort(key=lambda row: (-row[2], row[0]))
        chosen: list[tuple[str, str, str | None]] = []
        chosen_names: set[str] = set()
        for candidate in promoted_timeouts.get(problem_key, ())[:1]:
            if candidate not in EXCLUDED:
                chosen.append((candidate, "timeout-promote", candidate))
                chosen_names.add(candidate)
        for candidate in candidate_hints.get(problem_key, ())[:hint_limit]:
            candidate = normalize_candidate(candidate)
            if (
                candidate not in EXCLUDED
                and candidate not in chosen_names
                and candidate_applicable(candidate, run_problem_like)
            ):
                chosen.append((candidate, "external-proof-hint", candidate))
                chosen_names.add(candidate)
        positive_candidates: list[str] = []
        for candidate, status, _utility, _attempts in local:
            if candidate not in EXCLUDED and status in POSITIVE:
                positive_candidates.append(candidate)
                if len(chosen) < exploit:
                    chosen.append((candidate, "exploit", None))
                    chosen_names.add(candidate)

        attempts = {row[0]: int(row[3]) for row in local}
        tightened: list[tuple[str, str]] = []
        if tighten > 0:
            for source_candidate in positive_candidates:
                for variant in tightening_variants(source_candidate):
                    if variant not in chosen_names and attempts.get(variant, 0) == 0:
                        tightened.append((variant, source_candidate))
                        chosen_names.add(variant)
                        if len(tightened) >= tighten:
                            break
                if len(tightened) >= tighten:
                    break
        chosen.extend(
            (candidate, "tighten", source_candidate)
            for candidate, source_candidate in tightened
        )

        level = problem_level(cpf)
        if dual_probe and level == "top-level":
            if validity_mask & 2 and attempts.get("nontermination", 0) == 0:
                chosen.append(
                    ("nontermination", "diagnostic-no", "validity:sound-incomplete")
                )
                chosen_names.add("nontermination")
            if validity_mask & 4 and attempts.get("termination", 0) == 0:
                chosen.append(
                    ("termination", "diagnostic-yes", "validity:unsound-complete")
                )
                chosen_names.add("termination")
        elif dual_probe and level == "dependency-pair":
            if validity_mask & 2 and attempts.get("nontermination", 0) == 0:
                chosen.append(
                    ("nontermination", "diagnostic-no", "validity:sound-incomplete")
                )
                chosen_names.add("nontermination")
            if validity_mask & 4 and attempts.get("termination", 0) == 0:
                chosen.append(
                    ("termination", "diagnostic-yes", "validity:unsound-complete")
                )
                chosen_names.add("termination")

        exploration = [
            candidate
            for candidate in pools[level]
            if candidate not in chosen_names and attempts.get(candidate, 0) == 0
        ]
        exploration.sort(key=lambda candidate: stable_jitter(seed, problem_key, candidate))
        baseline_exploration = exploration[:explore]
        chosen.extend((candidate, "explore", None) for candidate in baseline_exploration)
        if (
            problem_key in adaptive_keys
            and not positive_candidates
            and remaining_extra_budget > 0
        ):
            used_families = {
                processor_family(candidate) for candidate in baseline_exploration
            }
            family_attempts: dict[str, int] = {}
            for candidate, count in attempts.items():
                family = processor_family(candidate)
                family_attempts[family] = family_attempts.get(family, 0) + count
            extra_pool = [
                candidate
                for candidate in exploration[explore:]
                if processor_family(candidate) not in used_families
            ]
            extra_pool.sort(
                key=lambda candidate: (
                    family_attempts.get(processor_family(candidate), 0),
                    stable_jitter(seed, problem_key, candidate),
                )
            )
            extras: list[str] = []
            extra_limit = min(extra_per_state, remaining_extra_budget)
            for candidate in extra_pool:
                family = processor_family(candidate)
                if family in used_families:
                    continue
                extras.append(candidate)
                used_families.add(family)
                if len(extras) >= extra_limit:
                    break
            chosen.extend(
                (candidate, "explore-frequent", None) for candidate in extras
            )
            remaining_extra_budget -= len(extras)

        for candidate, selection, source_candidate in chosen:
            if (problem_key, candidate) in certified_trials:
                continue
            task_key = hashlib.sha256(
                f"{problem_key}\0{candidate}\0{timeout_ms}\0{implementation_hash}".encode()
            ).hexdigest()
            cursor = results.execute(
                """
                INSERT OR IGNORE INTO trials(
                    task_key, problem_key, candidate, selection, source_candidate,
                    validity_mask, timeout_ms, implementation_hash
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    task_key,
                    problem_key,
                    candidate,
                    selection,
                    source_candidate,
                    validity_mask,
                    timeout_ms,
                    implementation_hash,
                ),
            )
            scheduled += cursor.rowcount
    results.commit()
    return scheduled, cpfs


def run_trial(
    ferrum: Path,
    ceta: Path,
    fragment_ceta: Path,
    ceta_timeout_s: float,
    artifact_dir: Path,
    run_id: str,
    implementation_hash: str,
    rayon_threads: int,
    task: tuple[str, str, str, str, int, str | None, int],
    cpf: str,
    outer_grace_s: float,
) -> dict[str, Any]:
    (
        task_key,
        problem_key,
        candidate,
        selection,
        timeout_ms,
        source_candidate,
        validity_mask,
    ) = task
    started = time.monotonic()
    with tempfile.TemporaryDirectory(prefix="ferrum-canonical-probe-") as raw_dir:
        directory = Path(raw_dir)
        input_path = directory / "input.xml"
        strategy_path = directory / "strategy.fs"
        event_path = directory / "events.jsonl"
        proof_path = directory / "proof.cpf3.xml"
        input_path.write_text(cpf, encoding="utf-8")
        # Exact witnesses can contain several megabytes of hex-encoded CPF
        # evidence.  Passing those through --strategy exceeds Linux's
        # per-process argument limit, whereas probe-cpf deliberately supports
        # strategy files for this case.
        strategy_path.write_text(candidate, encoding="utf-8")
        env = os.environ.copy()
        env["FERRUM_PROCESSOR_EVENT_RUN_ID"] = run_id
        env["FERRUM_PROCESSOR_EVENT_PROBLEM_ID"] = problem_key
        env["FERRUM_PROCESSOR_EVENT_CATEGORY"] = "canonical-campaign"
        env["RAYON_NUM_THREADS"] = str(rayon_threads)
        process = subprocess.Popen(
            [
                str(ferrum),
                "probe-cpf",
                str(input_path),
                "--strategy-file",
                str(strategy_path),
                "--timeout-ms",
                str(timeout_ms),
                "--processor-events",
                str(event_path),
                "--cpf",
                str(proof_path),
            ],
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
            env=env,
            start_new_session=True,
        )
        outer_timeout = timeout_ms / 1000.0 + outer_grace_s
        try:
            stdout, stderr = process.communicate(timeout=outer_timeout)
            outer_timed_out = False
        except subprocess.TimeoutExpired:
            terminate_group(process)
            stdout, stderr = process.communicate()
            outer_timed_out = True

        events = event_path.read_text(encoding="utf-8") if event_path.exists() else ""
        result_row = None
        for line in reversed(stdout.splitlines()):
            try:
                parsed = json.loads(line)
            except json.JSONDecodeError:
                continue
            if parsed.get("schema") == "ferrum.canonical-probe.v1":
                result_row = parsed
                break
        outcome = "timeout" if outer_timed_out else "failed"
        level = problem_level(cpf)
        if result_row is not None:
            outcome = str(result_row.get("outcome", outcome))
            level = str(result_row.get("level", level))
            typed_outcome = str(
                result_row.get("typed_outcome")
                or {
                    "solved": "Solved",
                    "transformed": "Transformed",
                    "inapplicable": "Inapplicable",
                    "failed": "Failed",
                    "timeout": "TimedOut",
                }.get(outcome, "Failed")
            )
        else:
            typed_outcome = "TimedOut" if outer_timed_out else "Failed"
        if typed_outcome not in PROBE_OUTCOMES:
            outcome = "failed"
            typed_outcome = "Failed"
        decision = None
        if result_row is not None:
            details = result_row.get("details")
            if isinstance(details, dict) and isinstance(details.get("status"), str):
                decision = details["status"]

        certification: dict[str, Any] = {
            "status": "not-positive",
            "checker": None,
            "return_code": None,
            "elapsed_ms": None,
            "stdout": "",
            "stderr": "",
            "cpf_path": None,
            "cpf_bytes": 0,
        }
        if outcome in {"solved", "transformed"}:
            export_status = None
            manifest_children: list[str] = []
            manifest_errors: list[str] = []
            if result_row is not None and isinstance(result_row.get("details"), dict):
                cpf_export = result_row["details"].get("cpf_export")
                if isinstance(cpf_export, dict):
                    export_status = cpf_export.get("status")
                    if export_status == "residual-manifest":
                        for index, child in enumerate(cpf_export.get("children", [])):
                            child_cpf = child.get("cpf") if isinstance(child, dict) else None
                            if not isinstance(child_cpf, str):
                                manifest_errors.append(
                                    f"residual manifest child {index} has no CPF"
                                )
                                continue
                            valid, reason = validate_materialized_child(child_cpf)
                            if valid:
                                manifest_children.append(child_cpf)
                            else:
                                manifest_errors.append(reason)
                    if export_status != "written":
                        certification["stderr"] = str(
                            cpf_export.get("reason") or cpf_export.get("error") or ""
                        )
            if proof_path.exists():
                checker = ceta
                if outcome == "transformed":
                    # Open processor output is a typed transition, not a
                    # positive proof.  Its runtime children and CPF holes are
                    # checked for an exact bijection by `probe-cpf`; production
                    # CeTA is run only after all children have been substituted.
                    checker_stdout = ""
                    checker_stderr = ""
                    checker_elapsed_ms = 0
                    checker_return_code = None
                    certification_status = "assembly-required"
                else:
                    checker_started = time.monotonic()
                    checker_process = subprocess.Popen(
                        [str(checker), str(proof_path)],
                        stdout=subprocess.PIPE,
                        stderr=subprocess.PIPE,
                        text=True,
                        start_new_session=True,
                    )
                    try:
                        checker_stdout, checker_stderr = checker_process.communicate(
                            timeout=ceta_timeout_s
                        )
                        checker_timed_out = False
                    except subprocess.TimeoutExpired:
                        terminate_group(checker_process)
                        checker_stdout, checker_stderr = checker_process.communicate()
                        checker_timed_out = True
                    checker_elapsed_ms = int((time.monotonic() - checker_started) * 1000)
                    checker_return_code = checker_process.returncode
                    certified = (
                        not checker_timed_out
                        and checker_return_code == 0
                        and "CERTIFIED" in checker_stdout
                    )
                    if checker_timed_out:
                        certification_status = "timeout"
                    elif certified:
                        certification_status = "certified-full"
                    else:
                        certification_status = "failed"
                retained = artifact_dir / task_key[:2] / task_key
                retained.mkdir(parents=True, exist_ok=True)
                shutil.copy2(input_path, retained / "input.cpf3.xml")
                shutil.copy2(proof_path, retained / "proof.cpf3.xml")
                (retained / "ceta.stdout").write_text(checker_stdout, encoding="utf-8")
                (retained / "ceta.stderr").write_text(checker_stderr, encoding="utf-8")
                certification = {
                    "status": certification_status,
                    "checker": str(checker),
                    "return_code": checker_return_code,
                    "elapsed_ms": checker_elapsed_ms,
                    "stdout": checker_stdout,
                    "stderr": checker_stderr,
                    "cpf_path": str(retained / "proof.cpf3.xml"),
                    "cpf_bytes": proof_path.stat().st_size,
                }
                child_problems = (
                    extract_child_problems(
                        proof_path.read_text(encoding="utf-8")
                    )
                    if certification_status in {"certified-fragment", "assembly-required"}
                    else []
                )
                invalid_children = [
                    reason
                    for child in child_problems
                    for valid, reason in [validate_materialized_child(child)]
                    if not valid
                ]
                if certification_status in {"certified-fragment", "assembly-required"} and (
                    not child_problems or invalid_children
                ):
                    certification_status = "context-invalid"
                    certification["status"] = certification_status
                    certification["stderr"] = "; ".join(
                        invalid_children or ["fragment has no materialized child"]
                    )
                    child_problems = []
            else:
                if export_status == "residual-manifest" and not manifest_errors:
                    # This is useful typed frontier discovery, but deliberately
                    # not a certified transformation: no serialized fragment
                    # exists from which a parent proof could be reconstructed.
                    certification["status"] = "residual-manifest"
                    child_problems = manifest_children
                elif manifest_errors:
                    certification["status"] = "context-invalid"
                    certification["stderr"] = "; ".join(manifest_errors)
                    child_problems = []
                else:
                    certification["status"] = (
                        "unsupported" if export_status == "unsupported" else "cpf-error"
                    )
                    child_problems = []
        else:
            child_problems = []
        if not events:
            synthetic = {
                "schema": "ferrum.processor-event.v1",
                "run_id": run_id,
                "problem_id": problem_key,
                "category": "canonical-campaign",
                "level": level,
                "problem_kind": (
                    "qdp"
                    if level == "dependency-pair"
                    else "csr"
                    if level == "context-sensitive"
                    else "trs"
                ),
                "processor": candidate,
                "strategy_atom": candidate,
                "outcome": outcome,
                "progress": "none",
                "elapsed_ms": int((time.monotonic() - started) * 1000),
                "input": {
                    "format": "cpf3-xml",
                    "cpf": cpf,
                    "problem_key": problem_key,
                    "content_addressed": True,
                },
                "metrics": {"outer_timeout": outer_timed_out},
                "witness": None,
            }
            events = json.dumps(synthetic, separators=(",", ":")) + "\n"
        decorated_events = []
        for line in events.splitlines():
            try:
                event = json.loads(line)
            except json.JSONDecodeError:
                continue
            event["campaign"] = {
                "selection": selection,
                "source_candidate": source_candidate,
                "diagnostic_only": selection.startswith("diagnostic-"),
                "validity_mask": validity_mask,
                "timeout_ms": timeout_ms,
                "implementation_hash": implementation_hash,
            }
            event["certification"] = {
                key: certification[key]
                for key in (
                    "status",
                    "checker",
                    "return_code",
                    "elapsed_ms",
                    "cpf_path",
                    "cpf_bytes",
                )
            }
            decorated_events.append(json.dumps(event, separators=(",", ":")))
        events = "\n".join(decorated_events) + ("\n" if decorated_events else "")
        return {
            "task_key": task_key,
            "problem_key": problem_key,
            "candidate": candidate,
            "selection": selection,
            "outcome": outcome,
            "typed_outcome": typed_outcome,
            "decision": decision,
            "level": level,
            "elapsed_ms": int((time.monotonic() - started) * 1000),
            "return_code": process.returncode,
            "stdout": stdout,
            "stderr": stderr,
            "events": events,
            "event_rows": len(events.splitlines()),
            "cpf_path": certification["cpf_path"],
            "cpf_bytes": certification["cpf_bytes"],
            "certification_status": certification["status"],
            "ceta_return_code": certification["return_code"],
            "ceta_elapsed_ms": certification["elapsed_ms"],
            "ceta_stdout": certification["stdout"],
            "ceta_stderr": certification["stderr"],
            "child_problems": child_problems,
        }


def enqueue_trial(
    results: sqlite3.Connection,
    problem_key: str,
    candidate: str,
    selection: str,
    timeout_ms: int,
    implementation_hash: str,
    validity_mask: int,
    source_candidate: str | None = None,
) -> bool:
    timeout_ms = min(timeout_ms, PROBE_TIMEOUT_CAP_MS)
    task_key = hashlib.sha256(
        f"{problem_key}\0{candidate}\0{timeout_ms}\0{implementation_hash}".encode()
    ).hexdigest()
    cursor = results.execute(
        """
        INSERT OR IGNORE INTO trials(
            task_key, problem_key, candidate, selection, source_candidate,
            validity_mask, timeout_ms, implementation_hash
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        """,
        (
            task_key,
            problem_key,
            candidate,
            selection,
            source_candidate,
            validity_mask,
            timeout_ms,
            implementation_hash,
        ),
    )
    return bool(cursor.rowcount)


def oracle_candidates(
    results: sqlite3.Connection,
    raw_hash: str,
    implementation_hash: str,
) -> list[str]:
    """Rank current-implementation evidence, preferring exact raw hits."""
    state = results.execute(
        "SELECT canonical_hash FROM states WHERE raw_hash=?", (raw_hash,)
    ).fetchone()
    if state is None:
        return []
    canonical_hash = state[0]
    rows = results.execute(
        """
        SELECT processor_atom, MAX(evidence_rank) AS rank,
               MIN(COALESCE(elapsed_ms, 9223372036854775807)) AS runtime,
               CASE WHEN raw_hash = ? THEN 0 ELSE 1 END AS alias_rank
        FROM oracle_evidence
        WHERE implementation_hash = ?
          AND (raw_hash = ? OR canonical_hash = ?)
          AND outcome NOT IN ('failed', 'timeout')
        GROUP BY processor_atom, alias_rank
        ORDER BY alias_rank, rank DESC, runtime, processor_atom
        """,
        (raw_hash, implementation_hash, raw_hash, canonical_hash),
    )
    return list(dict.fromkeys(row[0] for row in rows))


def record_certified_result(
    results: sqlite3.Connection,
    row: dict[str, Any],
    parent_cpf: str,
    implementation_hash: str,
    frontier_atoms: dict[str, list[str]],
    frontier_atom_limit: int,
    base_timeout_ms: int,
    schedule_followups: bool = True,
) -> tuple[dict[str, str], int]:
    parent_raw, _ = register_state(
        results,
        parent_cpf,
        source_problem_key=row["problem_key"],
        validity_mask=int(
            results.execute(
                "SELECT validity_mask FROM trials WHERE task_key=?",
                (row["task_key"],),
            ).fetchone()[0]
        ),
    )
    discovered: dict[str, str] = {}
    scheduled = 0
    if row["certification_status"] == "certified-full":
        results.execute(
            """
            INSERT OR IGNORE INTO terminal_proofs(
                raw_hash, task_key, processor_atom, decision,
                certification_status, proof_path, implementation_hash,
                elapsed_ms
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?)
            """,
            (
                parent_raw,
                row["task_key"],
                row["candidate"],
                row["decision"],
                row["certification_status"],
                row["cpf_path"],
                implementation_hash,
                row["elapsed_ms"],
            ),
        )
    if row["certification_status"] == "residual-manifest":
        parent_mask = results.execute(
            "SELECT validity_mask FROM states WHERE raw_hash=?", (parent_raw,)
        ).fetchone()[0]
        for index, child_cpf in enumerate(row["child_problems"]):
            child_raw, is_new = register_state(
                results,
                child_cpf,
                validity_mask=parent_mask,
                origin=f"residual-manifest:{row['task_key']}",
                proof_position=str(index),
            )
            discovered[child_raw] = child_cpf
            # A child may already be present because an earlier evidence import
            # registered it without scheduling trials.  Enqueueing is itself
            # idempotent, so schedule every discovered child and let the trial
            # key suppress duplicates.  Conditioning this on `is_new` strands
            # exactly the pre-seeded residuals that recursive replay is meant
            # to close.
            if schedule_followups:
                level = problem_level(child_cpf)
                for atom in frontier_atoms[level][:frontier_atom_limit]:
                    scheduled += enqueue_trial(
                        results,
                        child_raw,
                        atom,
                        "frontier-unseen",
                        base_timeout_ms,
                        implementation_hash,
                        parent_mask,
                    )
    if row["certification_status"] in {"certified-fragment", "assembly-required"}:
        parent_mask = results.execute(
            "SELECT validity_mask FROM states WHERE raw_hash=?", (parent_raw,)
        ).fetchone()[0]
        sound = bool(parent_mask & 1 or parent_mask & 2 or parent_mask == 0)
        complete = bool(parent_mask & 1 or parent_mask & 4 or parent_mask == 0)
        for index, child_cpf in enumerate(row["child_problems"]):
            child_raw, is_new = register_state(
                results,
                child_cpf,
                validity_mask=parent_mask,
                origin=f"transition:{row['task_key']}",
                proof_position=str(index),
            )
            discovered[child_raw] = child_cpf
            transition_key = hashlib.sha256(
                f"{row['task_key']}\0{child_raw}\0{index}".encode()
            ).hexdigest()
            results.execute(
                """
                INSERT OR IGNORE INTO transitions(
                    transition_key, parent_raw_hash, child_raw_hash, task_key,
                    processor_atom, sound, complete, certification_status,
                    proof_fragment_path, child_index, implementation_hash
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    transition_key,
                    parent_raw,
                    child_raw,
                    row["task_key"],
                    row["candidate"],
                    int(sound),
                    int(complete),
                    row["certification_status"],
                    row["cpf_path"],
                    index,
                    implementation_hash,
                ),
            )
            child_kind = problem_kind(child_cpf)
            assumption_kind = (
                "finitenessAssumption"
                if problem_level(child_cpf) == "dependency-pair"
                else "csrTerminationAssumption"
                if child_kind == "cs-trs"
                else "terminationAssumption"
            )
            results.execute(
                """
                INSERT OR IGNORE INTO reconstruction_contexts(
                    transition_key, parent_raw_hash, child_raw_hash,
                    child_index, assumption_kind, assumption_hash, fragment_path
                ) VALUES (?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    transition_key,
                    parent_raw,
                    child_raw,
                    index,
                    assumption_kind,
                    raw_problem_hash(child_cpf),
                    row["cpf_path"],
                ),
            )
            if schedule_followups:
                level = problem_level(child_cpf)
                atoms = list(
                    dict.fromkeys(
                        oracle_candidates(results, child_raw, implementation_hash)
                        + frontier_atoms[level]
                    )
                )
                for atom in atoms[:frontier_atom_limit]:
                    scheduled += enqueue_trial(
                        results,
                        child_raw,
                        atom,
                        "frontier-unseen",
                        base_timeout_ms,
                        implementation_hash,
                        parent_mask,
                    )
    if schedule_followups and row["outcome"] == "timeout":
        current_timeout = results.execute(
            "SELECT timeout_ms FROM trials WHERE task_key=?", (row["task_key"],)
        ).fetchone()[0]
        if current_timeout < min(base_timeout_ms * 4, PROBE_TIMEOUT_CAP_MS):
            scheduled += enqueue_trial(
                results,
                row["problem_key"],
                row["candidate"],
                "timeout-escalate",
                min(
                    current_timeout * 2,
                    base_timeout_ms * 4,
                    PROBE_TIMEOUT_CAP_MS,
                ),
                implementation_hash,
                results.execute(
                    "SELECT validity_mask FROM trials WHERE task_key=?",
                    (row["task_key"],),
                ).fetchone()[0],
                row["candidate"],
            )
        for variant in parameter_expansion_variants(row["candidate"])[:2]:
            scheduled += enqueue_trial(
                results,
                row["problem_key"],
                variant,
                "parameter-escalate",
                min(
                    max(current_timeout, base_timeout_ms * 2),
                    PROBE_TIMEOUT_CAP_MS,
                ),
                implementation_hash,
                results.execute(
                    "SELECT validity_mask FROM trials WHERE task_key=?",
                    (row["task_key"],),
                ).fetchone()[0],
                row["candidate"],
            )
    if schedule_followups and row["certification_status"] == "certified-full":
        for variant in tightening_variants(row["candidate"])[:2]:
            scheduled += enqueue_trial(
                results,
                row["problem_key"],
                variant,
                "tighten-certified",
                base_timeout_ms,
                implementation_hash,
                results.execute(
                    "SELECT validity_mask FROM trials WHERE task_key=?",
                    (row["task_key"],),
                ).fetchone()[0],
                row["candidate"],
            )
    return discovered, scheduled


def certified_proof_path(
    connection: sqlite3.Connection, raw_hash: str
) -> str | None:
    row = connection.execute(
        """
        SELECT proof_path FROM (
            SELECT proof_path, 0 priority FROM terminal_proofs
            WHERE raw_hash=? AND certification_status='certified-full'
            UNION ALL
            SELECT proof_path, 1 priority FROM assembled_proofs
            WHERE raw_hash=? AND checker_result='CERTIFIED'
              AND deterministic_recheck=1
        ) ORDER BY priority, proof_path LIMIT 1
        """,
        (raw_hash, raw_hash),
    ).fetchone()
    return str(row[0]) if row is not None else None


def proof_replacement(document: ET.Element, assumption_kind: str) -> ET.Element | None:
    if assumption_kind == "csrTerminationAssumption":
        wrapper = first_element(document, "proof")
        if wrapper is None:
            return None
        children = [child for child in wrapper if isinstance(child.tag, str)]
        return (
            ET.fromstring(ET.tostring(children[0], encoding="unicode"))
            if children
            else None
        )
    wanted = (
        "dpProof"
        if assumption_kind == "finitenessAssumption"
        else "trsTerminationProof"
    )
    wrapper = first_element(document, wanted)
    if wrapper is None:
        return None
    children = [child for child in wrapper if isinstance(child.tag, str)]
    return ET.fromstring(ET.tostring(children[0], encoding="unicode")) if children else None


def compose_certified_fragment(
    fragment: str, children: list[tuple[str, str]]
) -> tuple[str | None, str]:
    """Replace every assumption with the corresponding certified proof step."""
    try:
        root = ET.fromstring(fragment)
    except ET.ParseError as error:
        return None, f"invalid fragment: {error}"
    assumptions: list[tuple[ET.Element, ET.Element, str]] = []
    for parent in root.iter():
        for child in list(parent):
            kind = local_name(child.tag)
            if kind in {
                "terminationAssumption",
                "finitenessAssumption",
                "csrTerminationAssumption",
            }:
                assumptions.append((parent, child, kind))
    if len(assumptions) != len(children):
        return None, (
            f"assumption/child mismatch: {len(assumptions)} assumptions, "
            f"{len(children)} children"
        )
    for (parent, assumption, actual_kind), (expected_kind, child_path) in zip(
        assumptions, children, strict=True
    ):
        if actual_kind != expected_kind:
            return None, f"expected {expected_kind}, found {actual_kind}"
        try:
            child_document = ET.parse(child_path).getroot()
        except (ET.ParseError, OSError) as error:
            return None, f"invalid child proof {child_path}: {error}"
        replacement = proof_replacement(child_document, actual_kind)
        if replacement is None:
            return None, f"child proof {child_path} has no matching proof"
        index = list(parent).index(assumption)
        parent.remove(assumption)
        parent.insert(index, replacement)
    if any(
        local_name(node.tag)
        in {
            "terminationAssumption",
            "finitenessAssumption",
            "csrTerminationAssumption",
        }
        for node in root.iter()
    ):
        return None, "assembled proof still contains assumptions"
    return ET.tostring(root, encoding="unicode"), ""


def run_checker(
    checker: Path, proof_path: Path, timeout_s: float
) -> tuple[bool, int, str, str, int]:
    started = time.monotonic()
    process = subprocess.Popen(
        [str(checker), str(proof_path)],
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        text=True,
        start_new_session=True,
    )
    try:
        stdout, stderr = process.communicate(timeout=timeout_s)
        timed_out = False
    except subprocess.TimeoutExpired:
        terminate_group(process)
        stdout, stderr = process.communicate()
        timed_out = True
    elapsed_ms = int((time.monotonic() - started) * 1000)
    certified = (
        not timed_out and process.returncode == 0 and "CERTIFIED" in stdout
    )
    return certified, process.returncode or 0, stdout, stderr, elapsed_ms


def assemble_ready_proofs(
    connection: sqlite3.Connection,
    checker: Path,
    timeout_s: float,
    artifact_dir: Path,
    implementation_hash: str,
) -> int:
    """Assemble and independently check all transformations whose children close."""
    assembled = 0
    made_progress = True
    while made_progress:
        made_progress = False
        tasks = connection.execute(
            """
            SELECT DISTINCT parent_raw_hash, task_key, proof_fragment_path
            FROM transitions
            WHERE certification_status IN ('certified-fragment','assembly-required')
              AND NOT EXISTS (
                SELECT 1 FROM assembled_proofs a
                WHERE a.raw_hash=transitions.parent_raw_hash
                  AND a.transition_task_key=transitions.task_key
              )
            ORDER BY parent_raw_hash, task_key
            """
        ).fetchall()
        for parent_raw, task_key, fragment_path in tasks:
            edges = connection.execute(
                """
                SELECT t.child_raw_hash, t.child_index, r.assumption_kind
                FROM transitions t
                JOIN reconstruction_contexts r USING(transition_key)
                WHERE t.parent_raw_hash=? AND t.task_key=?
                ORDER BY t.child_index
                """,
                (parent_raw, task_key),
            ).fetchall()
            child_paths = [
                (kind, certified_proof_path(connection, child_raw))
                for child_raw, _index, kind in edges
            ]
            if not edges or any(path is None for _kind, path in child_paths):
                continue
            try:
                fragment = Path(fragment_path).read_text(encoding="utf-8")
            except OSError:
                continue
            composed, error = compose_certified_fragment(
                fragment,
                [(kind, str(path)) for kind, path in child_paths if path is not None],
            )
            if composed is None:
                continue
            retained = artifact_dir / "assembled" / parent_raw[:2] / task_key
            retained.mkdir(parents=True, exist_ok=True)
            proof_path = retained / "proof.cpf.xml"
            proof_path.write_text(composed, encoding="utf-8")
            first = run_checker(checker, proof_path, timeout_s)
            second = run_checker(checker, proof_path, timeout_s) if first[0] else first
            deterministic = bool(first[0] and second[0])
            checker_result = "CERTIFIED" if first[0] else "REJECTED"
            digest = hashlib.sha256(
                (
                    f"{first[1]}\0{first[2]}\0{first[3]}\0"
                    f"{second[1]}\0{second[2]}\0{second[3]}"
                ).encode()
            ).hexdigest()
            (retained / "checker.stdout").write_text(first[2], encoding="utf-8")
            (retained / "checker.stderr").write_text(first[3], encoding="utf-8")
            connection.execute(
                """
                INSERT OR REPLACE INTO assembled_proofs(
                    raw_hash, transition_task_key, proof_path, checker_path,
                    checker_result, checker_digest, deterministic_recheck,
                    implementation_hash, elapsed_ms
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    parent_raw,
                    task_key,
                    str(proof_path),
                    str(checker),
                    checker_result,
                    digest,
                    int(deterministic),
                    implementation_hash,
                    first[4] + second[4],
                ),
            )
            connection.commit()
            if deterministic:
                assembled += 1
                made_progress = True
    return assembled


def campaign_summary(connection: sqlite3.Connection) -> dict[str, Any]:
    covered = {
        row[0]
        for row in connection.execute(
            """
            SELECT DISTINCT raw_hash FROM terminal_proofs
            WHERE certification_status='certified-full'
            UNION
            SELECT DISTINCT raw_hash FROM assembled_proofs
            WHERE checker_result='CERTIFIED' AND deterministic_recheck=1
            """
        )
    }
    by_kind: dict[str, dict[str, int]] = {}
    for raw_hash, kind in connection.execute(
        "SELECT raw_hash, problem_kind FROM states"
    ):
        counts = by_kind.setdefault(kind, {"covered": 0, "uncovered": 0})
        counts["covered" if raw_hash in covered else "uncovered"] += 1
    outcomes = dict(
        connection.execute(
            """
            SELECT COALESCE(outcome, state), COUNT(*) FROM trials
            GROUP BY COALESCE(outcome, state)
            """
        )
    )
    processors = {
        processor: dict(json.loads(values))
        for processor, values in connection.execute(
            """
            SELECT candidate, json_group_object(outcome, count)
            FROM (
                SELECT candidate, COALESCE(outcome, state) outcome,
                       COUNT(*) count
                FROM trials GROUP BY candidate, COALESCE(outcome, state)
            ) GROUP BY candidate
            """
        )
    }
    raw_states, canonical_states = connection.execute(
        "SELECT COUNT(*), COUNT(DISTINCT canonical_hash) FROM states"
    ).fetchone()
    return {
        "schema": "ferrum.state-first-campaign-summary.v1",
        "unique_raw_states": raw_states,
        "unique_canonical_states": canonical_states,
        "covered_states": len(covered),
        "uncovered_states": raw_states - len(covered),
        "states_by_problem_kind": by_kind,
        "direct_probes_by_outcome": outcomes,
        "direct_probes_by_processor": processors,
        "allocation_lanes": {
            lane: connection.execute(
                "SELECT COUNT(*) FROM trials WHERE selection IN ({})".format(
                    ",".join("?" for _ in selections)
                ),
                tuple(selections),
            ).fetchone()[0]
            for lane, selections in {
                "unseen": (
                    "explore",
                    "explore-frequent",
                    "frontier-unseen",
                ),
                "hints": ("external-proof-hint", "exploit"),
                "escalation": (
                    "timeout-promote",
                    "timeout-escalate",
                    "parameter-escalate",
                ),
                "tightening": ("tighten", "tighten-certified"),
                "opposite": ("diagnostic-no", "diagnostic-yes"),
            }.items()
        },
        "certified_transformations": connection.execute(
            "SELECT COUNT(*) FROM transitions"
        ).fetchone()[0],
        "certified_terminal_proofs": connection.execute(
            "SELECT COUNT(*) FROM terminal_proofs"
        ).fetchone()[0],
        "assembled_proofs_certified": connection.execute(
            """
            SELECT COUNT(*) FROM assembled_proofs
            WHERE checker_result='CERTIFIED' AND deterministic_recheck=1
            """
        ).fetchone()[0],
        "assembled_proofs_rejected": connection.execute(
            "SELECT COUNT(*) FROM assembled_proofs WHERE checker_result!='CERTIFIED'"
        ).fetchone()[0],
        "new_child_states": connection.execute(
            "SELECT COUNT(DISTINCT child_raw_hash) FROM transitions"
        ).fetchone()[0],
        "timeout_escalations": connection.execute(
            "SELECT COUNT(*) FROM trials WHERE selection='timeout-escalate'"
        ).fetchone()[0],
        "tightening_trials": connection.execute(
            "SELECT COUNT(*) FROM trials WHERE selection IN ('tighten','tighten-certified')"
        ).fetchone()[0],
        "certified_tightening_gains": connection.execute(
            """
            SELECT COUNT(*) FROM trials
            WHERE selection IN ('tighten','tighten-certified')
              AND certification_status = 'certified-full'
            """
        ).fetchone()[0],
        "uncertified_solved_attempts": connection.execute(
            """
            SELECT COUNT(*) FROM trials
            WHERE outcome='solved'
              AND certification_status != 'certified-full'
            """
        ).fetchone()[0],
        "uncertified_promoted_yes": connection.execute(
            """
            SELECT COUNT(*) FROM terminal_proofs
            WHERE certification_status!='certified-full'
            """
        ).fetchone()[0],
    }


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--source-db", type=Path, required=True)
    parser.add_argument("--run-dir", type=Path, required=True)
    parser.add_argument(
        "--canonical-cache",
        type=Path,
        help="persistent semantic CPF canonicalization cache",
    )
    parser.add_argument(
        "--runtime-canonicalize-registry",
        action=argparse.BooleanOptionalAction,
        default=True,
        help=(
            "canonicalize every imported source state with the Ferrum binary; "
            "disable for self-contained hint campaigns and recover runtime "
            "aliases from fresh probe events instead"
        ),
    )
    parser.add_argument("--ferrum", type=Path, default=Path("target/release/ferrum"))
    parser.add_argument(
        "--ceta", type=Path, default=Path(".tools/ceta-relative-bounds")
    )
    parser.add_argument(
        "--fragment-ceta",
        type=Path,
        default=Path(".tools/ceta-relative-bounds.bin"),
        help="verified CeTA build with termination/finiteness assumption support",
    )
    parser.add_argument("--ceta-timeout", type=float, default=60.0)
    parser.add_argument("--jobs", type=int, default=8)
    parser.add_argument("--rayon-threads", type=int, default=2)
    parser.add_argument("--exploit", type=int, default=1)
    parser.add_argument("--tighten", type=int, default=2)
    parser.add_argument("--explore", type=int, default=1)
    parser.add_argument(
        "--frequent-explore",
        type=int,
        default=1,
        help="total distinct-family candidates for frequent uncovered states",
    )
    parser.add_argument(
        "--frequency-threshold",
        type=int,
        default=1,
        help="minimum state occurrence count for adaptive exploration",
    )
    parser.add_argument(
        "--extra-exploration-budget",
        type=int,
        default=0,
        help="global cap on exploration trials beyond the baseline count",
    )
    parser.add_argument(
        "--run-problem-like",
        help="restrict states to observations whose run_problem_key matches SQL LIKE",
    )
    parser.add_argument(
        "--run-problem-prefix",
        help="restrict states to an indexed run-problem key prefix",
    )
    parser.add_argument(
        "--problem-level",
        choices=("top-level", "context-sensitive", "dependency-pair"),
        help="restrict probes by the CPF subproblem level",
    )
    parser.add_argument(
        "--dual-probe",
        action=argparse.BooleanOptionalAction,
        default=True,
        help="probe the opposite decision for states with directional validity metadata",
    )
    parser.add_argument("--timeout-ms", type=int, default=2_000)
    parser.add_argument(
        "--recursive-frontier",
        action=argparse.BooleanOptionalAction,
        default=True,
        help="enqueue children extracted from certified transformed probes",
    )
    parser.add_argument(
        "--frontier-atom-limit",
        type=int,
        default=8,
        help="maximum directly applicable atoms initially scheduled per new child",
    )
    parser.add_argument(
        "--max-probes",
        type=int,
        default=0,
        help="campaign-wide completed-probe cap; zero means unlimited",
    )
    parser.add_argument(
        "--resume-pending-only",
        action="store_true",
        help=(
            "run only trial rows already marked pending; do not schedule, "
            "rebalance, or import source-registry work"
        ),
    )
    parser.add_argument(
        "--allow-uncertified-yes",
        action="store_true",
        help="return success even if a solved probe fails independent certification",
    )
    parser.add_argument("--outer-grace", type=float, default=10.0)
    parser.add_argument("--seed", type=int, default=0)
    parser.add_argument(
        "--candidate-hints",
        type=Path,
        action="append",
        default=[],
        help=(
            "JSONL rows keyed by problem_key with ranked suggested_atoms; "
            "repeat to merge independent hint sources"
        ),
    )
    parser.add_argument(
        "--hint-limit",
        type=int,
        default=3,
        help="maximum external-proof candidates scheduled per matching state",
    )
    parser.add_argument(
        "--hinted-only",
        action="store_true",
        help="schedule only states present in --candidate-hints",
    )
    parser.add_argument(
        "--prior-ledger",
        type=Path,
        action="append",
        default=[],
        help="prior campaign SQLite ledger whose timed-out trials may be promoted",
    )
    parser.add_argument("--limit", type=int)
    parser.add_argument("--progress-every", type=int, default=10)
    args = parser.parse_args()
    if (
        args.jobs < 1
        or args.jobs > 64
        or args.rayon_threads != 2
        or args.jobs * args.rayon_threads > 128
        or args.exploit < 0
        or args.tighten < 0
        or args.explore < 0
        or args.frequent_explore < args.explore
        or args.frequency_threshold < 0
        or args.extra_exploration_budget < 0
        or args.hint_limit < 0
        or args.frontier_atom_limit < 0
        or args.max_probes < 0
        or args.timeout_ms > PROBE_TIMEOUT_CAP_MS
    ):
        parser.error(
            "jobs must be 1..64, each probe must use two Rayon threads, "
            "probe counts must be non-negative, and timeout at most 60s"
        )

    args.run_dir.mkdir(parents=True, exist_ok=True)
    results_path = args.run_dir / "campaign.sqlite"
    events_path = args.run_dir / "processor-events.jsonl"
    source = sqlite3.connect(f"file:{args.source_db}?mode=ro", uri=True)
    results = sqlite3.connect(results_path)
    initialize_results(results)
    # A killed worker cannot atomically return its trial to the queue.  The
    # campaign process owns this ledger exclusively, so any `running` row at
    # startup is an interrupted attempt and must be retried.
    interrupted = results.execute(
        "UPDATE trials SET state='pending', started_at=NULL WHERE state='running'"
    ).rowcount
    results.commit()
    if interrupted:
        print(f"canonical-campaign requeued-interrupted={interrupted}", flush=True)
    candidate_hints: dict[str, list[str]] = {}
    candidate_hint_cpfs: dict[str, str] = {}
    for candidate_hint_path in args.candidate_hints:
        with candidate_hint_path.open(encoding="utf-8") as source_hints:
            for line in source_hints:
                row = json.loads(line)
                problem_key = row.get("problem_key")
                suggestions = row.get("suggested_atoms") or []
                if not isinstance(problem_key, str):
                    continue
                atoms = [
                    item.get("atom") if isinstance(item, dict) else item
                    for item in suggestions
                ]
                candidate_hints.setdefault(problem_key, []).extend(
                    atom for atom in atoms if isinstance(atom, str)
                )
                candidate_hints[problem_key] = list(
                    dict.fromkeys(candidate_hints[problem_key])
                )
                cpf = row.get("cpf")
                if isinstance(cpf, str) and cpf.strip():
                    previous = candidate_hint_cpfs.setdefault(problem_key, cpf)
                    if previous != cpf:
                        raise ValueError(
                            f"conflicting candidate-hint CPF for {problem_key}"
                        )
    implementation_hash = hashlib.sha256(args.ferrum.read_bytes()).hexdigest()
    if args.resume_pending_only:
        scheduled, cpfs = 0, {}
        retained_allocation = {}
    else:
        scheduled, cpfs = schedule_tasks(
            source,
            results,
            args.prior_ledger,
            args.exploit,
            args.tighten,
            args.explore,
            args.frequent_explore,
            args.frequency_threshold,
            args.extra_exploration_budget,
            args.dual_probe,
            args.timeout_ms,
            args.seed,
            args.limit,
            implementation_hash,
            args.run_problem_like,
            candidate_hints,
            candidate_hint_cpfs,
            args.hint_limit,
            args.hinted_only,
            args.problem_level,
            args.run_problem_prefix,
        )
        retained_allocation = enforce_initial_allocation(results, args.max_probes)
    canonical_cache = (
        sqlite3.connect(f"file:{args.canonical_cache}?mode=ro", uri=True)
        if args.canonical_cache is not None
        else None
    )
    if not args.resume_pending_only:
        import_source_registry(
            source,
            results,
            cpfs,
            canonical_cache,
            args.ferrum.resolve() if args.runtime_canonicalize_registry else None,
        )
    for raw_hash, source_problem_key, cpf in results.execute(
        "SELECT raw_hash, source_problem_key, cpf FROM states"
    ):
        cpfs[raw_hash] = cpf
        if source_problem_key is not None:
            cpfs.setdefault(source_problem_key, cpf)
    pool_candidates = candidate_pools(
        source,
        args.run_problem_like,
        args.problem_level,
    )
    frontier_atoms: dict[str, list[str]] = {}
    for level in DEFAULT_FRONTIER_ATOMS:
        frontier_atoms[level] = list(
            dict.fromkeys(DEFAULT_FRONTIER_ATOMS[level] + tuple(pool_candidates[level]))
        )
    run_id = args.run_dir.name
    print(
        f"canonical-campaign states={len(cpfs)} new={scheduled} "
        f"pending={results.execute('SELECT COUNT(*) FROM trials WHERE state=\"pending\"').fetchone()[0]} "
        f"jobs={args.jobs} timeout_ms={args.timeout_ms}",
        flush=True,
    )

    lock = threading.Lock()
    completed = 0
    previously_completed = results.execute(
        "SELECT COUNT(*) FROM trials WHERE state='completed'"
    ).fetchone()[0]
    outcomes: dict[str, int] = {}
    certifications: dict[str, int] = {}
    with events_path.open("a", encoding="utf-8") as event_output:
        with concurrent.futures.ThreadPoolExecutor(max_workers=args.jobs) as executor:
            futures: dict[concurrent.futures.Future[dict[str, object]], tuple] = {}
            while True:
                remaining_submit_budget = (
                    None
                    if args.max_probes == 0
                    else (
                        args.max_probes
                        - previously_completed
                        - completed
                        - len(futures)
                    )
                )
                available = args.jobs - len(futures)
                if remaining_submit_budget is not None:
                    available = min(available, max(0, remaining_submit_budget))
                if available > 0:
                    tasks = results.execute(
                        """
                        SELECT task_key, problem_key, candidate, selection, timeout_ms,
                               source_candidate, validity_mask
                        FROM trials WHERE state = 'pending' ORDER BY task_key LIMIT ?
                        """,
                        (available,),
                    ).fetchall()
                    if tasks:
                        results.executemany(
                            """
                            UPDATE trials SET state='running', started_at=datetime('now')
                            WHERE task_key=?
                            """,
                            [(task[0],) for task in tasks],
                        )
                        results.commit()
                        for task in tasks:
                            problem_key = task[1]
                            cpf = cpfs.get(problem_key)
                            if cpf is None:
                                state_row = results.execute(
                                    """
                                    SELECT cpf FROM states WHERE raw_hash=?
                                    UNION ALL
                                    SELECT s.cpf FROM state_aliases a
                                    JOIN states s ON s.raw_hash=a.state_raw_hash
                                    WHERE a.alias_raw_hash=?
                                    LIMIT 1
                                    """,
                                    (problem_key, problem_key),
                                ).fetchone()
                                if state_row is None:
                                    raise RuntimeError(
                                        "pending trial has no materialized state: "
                                        f"{problem_key}"
                                    )
                                cpf = str(state_row[0])
                                cpfs[problem_key] = cpf
                            future = executor.submit(
                                run_trial,
                                args.ferrum,
                                args.ceta,
                                args.fragment_ceta,
                                args.ceta_timeout,
                                args.run_dir / "artifacts",
                                run_id,
                                implementation_hash,
                                args.rayon_threads,
                                task,
                                cpf,
                                args.outer_grace,
                            )
                            futures[future] = task
                if not futures:
                    break
                done, _pending_futures = concurrent.futures.wait(
                    futures,
                    return_when=concurrent.futures.FIRST_COMPLETED,
                )
                for future in done:
                    futures.pop(future)
                    row = future.result()
                    with lock:
                        event_output.write(row.pop("events"))
                        event_output.flush()
                        results.execute(
                            """
                            UPDATE trials SET state='completed', outcome=?, decision=?,
                                level=?, elapsed_ms=?, return_code=?, stdout=?,
                                stderr=?, event_rows=?, cpf_path=?, cpf_bytes=?,
                                certification_status=?, ceta_return_code=?,
                                ceta_elapsed_ms=?, ceta_stdout=?, ceta_stderr=?,
                                implementation_hash=?,
                                finished_at=datetime('now')
                            WHERE task_key=?
                            """,
                            (
                                row["outcome"],
                                row["decision"],
                                row["level"],
                                row["elapsed_ms"],
                                row["return_code"],
                                bounded_diagnostic_text(row["stdout"]),
                                bounded_diagnostic_text(row["stderr"]),
                                row["event_rows"],
                                row["cpf_path"],
                                row["cpf_bytes"],
                                row["certification_status"],
                                row["ceta_return_code"],
                                row["ceta_elapsed_ms"],
                                bounded_diagnostic_text(row["ceta_stdout"]),
                                bounded_diagnostic_text(row["ceta_stderr"]),
                                implementation_hash,
                                row["task_key"],
                            ),
                        )
                        children, _new_trials = record_certified_result(
                            results,
                            row,
                            cpfs[row["problem_key"]],
                            implementation_hash,
                            frontier_atoms,
                            args.frontier_atom_limit,
                            args.timeout_ms,
                            schedule_followups=args.recursive_frontier,
                        )
                        cpfs.update(children)
                        results.commit()
                        if not args.resume_pending_only:
                            enforce_initial_allocation(results, args.max_probes)
                        assemble_ready_proofs(
                            results,
                            args.ceta,
                            args.ceta_timeout,
                            args.run_dir / "artifacts",
                            implementation_hash,
                        )
                        completed += 1
                        outcomes[row["outcome"]] = outcomes.get(row["outcome"], 0) + 1
                        certifications[row["certification_status"]] = (
                            certifications.get(row["certification_status"], 0) + 1
                        )
                        if completed % args.progress_every == 0:
                            pending = results.execute(
                                "SELECT COUNT(*) FROM trials WHERE state='pending'"
                            ).fetchone()[0]
                            print(
                                f"progress completed={completed} pending={pending} outcomes="
                                f"{json.dumps(outcomes, sort_keys=True)} certifications="
                                f"{json.dumps(certifications, sort_keys=True)}",
                                flush=True,
                            )
    assemble_ready_proofs(
        results,
        args.ceta,
        args.ceta_timeout,
        args.run_dir / "artifacts",
        implementation_hash,
    )
    summary = campaign_summary(results)
    summary.update(
        {
            "implementation_hash": implementation_hash,
            "probe_timeout_cap_ms": PROBE_TIMEOUT_CAP_MS,
            "root_concurrency_cap": 64,
            "direct_probe_concurrency_cap": 64,
            "allocation_budget": args.max_probes,
            "allocation_quotas": allocation_quotas(args.max_probes)
            if args.max_probes
            else {},
            "initial_allocation_retained": retained_allocation,
        }
    )
    (args.run_dir / "summary.json").write_text(
        json.dumps(summary, indent=2, sort_keys=True) + "\n",
        encoding="utf-8",
    )
    print(json.dumps(summary, sort_keys=True), flush=True)
    source.close()
    if canonical_cache is not None:
        canonical_cache.close()
    results.close()
    if summary["uncertified_promoted_yes"] and not args.allow_uncertified_yes:
        return 2
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
