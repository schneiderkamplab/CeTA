#!/usr/bin/env python3
"""Recanonicalize an oracle with the current Ferrum canonicalizer."""

from __future__ import annotations

import argparse
import concurrent.futures
import hashlib
import json
import sqlite3
import subprocess
import tempfile
import time
from pathlib import Path

from export_utility_guidance_lookup import merged_state_evidence


GROUPS = ("prefer", "possible", "avoid", "timeout")


def cpf_key(cpf: str) -> str:
    return hashlib.sha256(cpf.strip().encode("utf-8")).hexdigest()


def read_oracle(
    path: Path,
) -> tuple[list[dict], list[tuple[str, dict]], dict[str, str]]:
    passthrough = []
    evidence = []
    aliases = {}
    with path.open(encoding="utf-8") as source:
        for line_number, line in enumerate(source, start=1):
            if not line.strip():
                continue
            row = json.loads(line)
            key = row.get("problem_key")
            # Witness dictionaries are deliberately colocated with state rows so
            # exact candidates remain self-contained.  They have no state key to
            # canonicalize, but an upgrade must retain them byte-for-byte at the
            # JSON-object level.
            if not isinstance(key, str):
                passthrough.append(row)
                continue
            canonical = row.get("canonical_problem_key")
            if isinstance(canonical, str):
                aliases[key] = canonical
            else:
                evidence.append((key, {group: list(row.get(group) or []) for group in GROUPS}))
    return passthrough, evidence, aliases


def cache_sources(path: Path, wanted: set[str], sources: dict[str, str]) -> None:
    with sqlite3.connect(f"file:{path.resolve()}?mode=ro", uri=True) as connection:
        for raw_key, cpf in connection.execute(
            "SELECT raw_key, canonical_cpf FROM canonical_cpf_cache"
        ):
            canonical_key = cpf_key(cpf)
            if raw_key in wanted and raw_key not in sources:
                sources[raw_key] = cpf
            if canonical_key in wanted and canonical_key not in sources:
                sources[canonical_key] = cpf


def problem_db_sources(
    path: Path,
    wanted: set[str],
    sources: dict[str, str],
    *,
    overwrite: bool = False,
) -> None:
    with sqlite3.connect(f"file:{path.resolve()}?mode=ro", uri=True) as connection:
        tables = {
            row[0]
            for row in connection.execute(
                "SELECT name FROM sqlite_master WHERE type='table'"
            )
        }
        if "problems" in tables:
            for key, cpf in connection.execute("SELECT problem_key, cpf FROM problems"):
                if key in wanted and (overwrite or key not in sources):
                    sources[key] = cpf
        if "replay_cpf_cache" in tables:
            for key, cpf in connection.execute(
                "SELECT problem_key, cpf FROM replay_cpf_cache"
            ):
                if key in wanted and (overwrite or key not in sources):
                    sources[key] = cpf


def discover_sqlite(roots: list[Path]) -> list[Path]:
    paths = set()
    for root in roots:
        if root.is_file():
            paths.add(root)
        elif root.is_dir():
            paths.update(root.rglob("*.sqlite"))
    return sorted(paths)


def open_result_cache(path: Path) -> sqlite3.Connection:
    connection = sqlite3.connect(path)
    connection.execute("PRAGMA journal_mode=WAL")
    connection.execute(
        """
        CREATE TABLE IF NOT EXISTS current_canonicalization (
            source_key TEXT PRIMARY KEY,
            source_sha256 TEXT,
            canonical_cpf TEXT,
            error TEXT,
            elapsed_ms INTEGER NOT NULL
        )
        """
    )
    columns = {
        row[1]
        for row in connection.execute("PRAGMA table_info(current_canonicalization)")
    }
    if "source_sha256" not in columns:
        connection.execute(
            "ALTER TABLE current_canonicalization ADD COLUMN source_sha256 TEXT"
        )
    connection.commit()
    return connection


def canonicalize_one(
    ferrum: Path, source_key: str, cpf: str, timeout: float
) -> tuple[str, str | None, str | None, int]:
    started = time.monotonic()
    try:
        with tempfile.NamedTemporaryFile(
            mode="w", suffix=".xml", encoding="utf-8"
        ) as source:
            source.write(cpf.strip())
            source.flush()
            completed = subprocess.run(
                [str(ferrum), "canonicalize-cpf", source.name],
                text=True,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                timeout=timeout,
                check=False,
            )
        if completed.returncode:
            error = completed.stderr.strip() or f"exit status {completed.returncode}"
            canonical = None
        else:
            canonical = completed.stdout.strip()
            error = None if canonical else "empty canonical CPF"
            if error is not None:
                canonical = None
    except subprocess.TimeoutExpired:
        canonical = None
        error = "timeout"
    elapsed_ms = round((time.monotonic() - started) * 1000)
    return source_key, canonical, error, elapsed_ms


def canonicalize_sources(
    ferrum: Path,
    sources: dict[str, str],
    result_cache: Path,
    jobs: int,
    timeout: float,
    progress_every: int,
) -> tuple[dict[str, str], dict[str, str]]:
    connection = open_result_cache(result_cache)
    cached = {
        row[0]: (row[2], row[3], row[1])
        for row in connection.execute(
            "SELECT source_key, source_sha256, canonical_cpf, error "
            "FROM current_canonicalization"
        )
    }
    source_hashes = {key: cpf_key(cpf) for key, cpf in sources.items()}
    pending = [
        (key, cpf)
        for key, cpf in sources.items()
        if key not in cached or cached[key][2] != source_hashes[key]
    ]
    print(
        f"canonicalization sources={len(sources)} cached={len(cached)} "
        f"pending={len(pending)} jobs={jobs}",
        flush=True,
    )
    completed_count = 0
    with concurrent.futures.ThreadPoolExecutor(max_workers=jobs) as pool:
        futures = [
            pool.submit(canonicalize_one, ferrum, key, cpf, timeout)
            for key, cpf in pending
        ]
        for future in concurrent.futures.as_completed(futures):
            key, canonical, error, elapsed_ms = future.result()
            cached[key] = (canonical, error, source_hashes[key])
            connection.execute(
                """
                INSERT OR REPLACE INTO current_canonicalization
                    (source_key, source_sha256, canonical_cpf, error, elapsed_ms)
                VALUES (?, ?, ?, ?, ?)
                """,
                (key, source_hashes[key], canonical, error, elapsed_ms),
            )
            completed_count += 1
            if completed_count % 100 == 0:
                connection.commit()
            if completed_count % progress_every == 0 or completed_count == len(pending):
                print(
                    f"canonicalized={completed_count}/{len(pending)} "
                    f"success={sum(value[0] is not None for value in cached.values())}",
                    flush=True,
                )
    connection.commit()
    connection.close()
    successful = {
        key: canonical
        for key, (canonical, _, source_hash) in cached.items()
        if canonical and source_hash == source_hashes.get(key)
    }
    failed = {
        key: error or "unknown"
        for key, (canonical, error, source_hash) in cached.items()
        if not canonical and source_hash == source_hashes.get(key)
    }
    return successful, failed


def resolve_alias(key: str, aliases: dict[str, str]) -> str:
    seen = set()
    while key in aliases and key not in seen:
        seen.add(key)
        key = aliases[key]
    return key


def upgrade(
    evidence_rows: list[tuple[str, dict]],
    inherited_aliases: dict[str, str],
    canonical_cpfs: dict[str, str],
) -> tuple[dict[str, dict], dict[str, str], int]:
    canonical_keys = {key: cpf_key(cpf) for key, cpf in canonical_cpfs.items()}
    evidence: dict[str, dict] = {}
    aliases: dict[str, str] = {}
    promoted = 0
    for raw_key, state in evidence_rows:
        target = canonical_keys.get(raw_key, raw_key)
        if target != raw_key:
            aliases[raw_key] = target
            promoted += 1
        if target in evidence:
            evidence[target] = merged_state_evidence(
                evidence[target], state, preserve_left_order=True
            )
        else:
            evidence[target] = state
    for raw_key, old_target in inherited_aliases.items():
        resolved = resolve_alias(old_target, inherited_aliases)
        target = canonical_keys.get(resolved, resolved)
        if raw_key != target:
            aliases[raw_key] = target
    aliases = {
        raw: target
        for raw, target in aliases.items()
        if raw not in evidence and target in evidence and raw != target
    }
    return evidence, aliases, promoted


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--oracle", type=Path, required=True)
    parser.add_argument("--ferrum", type=Path, required=True)
    parser.add_argument("--source-cache", type=Path, action="append", default=[])
    parser.add_argument("--source-sqlite-root", type=Path, action="append", default=[])
    parser.add_argument(
        "--preferred-source-sqlite",
        type=Path,
        action="append",
        default=[],
        help=(
            "SQLite source whose live replay CPFs override reconstructed or "
            "historical sources for matching keys"
        ),
    )
    parser.add_argument("--result-cache", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--report", type=Path, required=True)
    parser.add_argument("--jobs", type=int, default=8)
    parser.add_argument("--timeout-seconds", type=float, default=60.0)
    parser.add_argument("--progress-every", type=int, default=1000)
    args = parser.parse_args()

    passthrough_rows, evidence_rows, inherited_aliases = read_oracle(args.oracle)
    evidence_keys = {key for key, _ in evidence_rows}
    wanted = evidence_keys | set(inherited_aliases)
    sources: dict[str, str] = {}
    for cache in args.source_cache:
        cache_sources(cache, wanted, sources)
    sqlite_paths = discover_sqlite(args.source_sqlite_root)
    for index, path in enumerate(sqlite_paths, start=1):
        try:
            problem_db_sources(path, wanted, sources)
        except sqlite3.DatabaseError:
            continue
        if index % 25 == 0:
            print(f"source databases={index}/{len(sqlite_paths)} recovered={len(sources)}")

    preferred_replacements = 0
    for path in args.preferred_source_sqlite:
        before = dict(sources)
        problem_db_sources(path, wanted, sources, overwrite=True)
        preferred_replacements += sum(
            before.get(key) != cpf for key, cpf in sources.items()
        )

    alias_sources = 0
    for raw_key, target in inherited_aliases.items():
        resolved = resolve_alias(target, inherited_aliases)
        if resolved in evidence_keys and resolved not in sources and raw_key in sources:
            sources[resolved] = sources[raw_key]
            alias_sources += 1
    evidence_sources = {key: cpf for key, cpf in sources.items() if key in evidence_keys}
    print(
        f"evidence CPF sources={len(evidence_sources)} "
        f"recovered through aliases={alias_sources}",
        flush=True,
    )

    canonical_cpfs, failures = canonicalize_sources(
        args.ferrum.resolve(),
        evidence_sources,
        args.result_cache,
        args.jobs,
        args.timeout_seconds,
        args.progress_every,
    )
    evidence, aliases, promoted = upgrade(
        evidence_rows, inherited_aliases, canonical_cpfs
    )
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with args.output.open("w", encoding="utf-8") as sink:
        for row in passthrough_rows:
            sink.write(json.dumps(row, separators=(",", ":"), sort_keys=True) + "\n")
        for key, state in sorted(evidence.items()):
            sink.write(
                json.dumps(
                    {"schema": "ferrum.utility-guidance.v2", "problem_key": key, **state},
                    separators=(",", ":"),
                    sort_keys=True,
                )
                + "\n"
            )
        for raw, canonical in sorted(aliases.items()):
            sink.write(
                json.dumps(
                    {
                        "schema": "ferrum.utility-guidance.v2",
                        "problem_key": raw,
                        "canonical_problem_key": canonical,
                    },
                    separators=(",", ":"),
                    sort_keys=True,
                )
                + "\n"
            )
    report = {
        "schema": "ferrum.oracle-canonical-upgrade.v1",
        "source_oracle": str(args.oracle),
        "source_evidence": len(evidence_rows),
        "source_aliases": len(inherited_aliases),
        "passthrough_rows": len(passthrough_rows),
        "source_sqlite_files": len(sqlite_paths),
        "preferred_source_sqlite_files": len(args.preferred_source_sqlite),
        "preferred_source_replacements": preferred_replacements,
        "recovered_cpf_states": len(evidence_sources),
        "recovered_through_aliases": alias_sources,
        "canonicalization_successes": len(canonical_cpfs),
        "canonicalization_failures": len(failures),
        "unrecoverable_states": len(evidence_rows) - len(evidence_sources),
        "promoted_evidence_records": promoted,
        "output_evidence": len(evidence),
        "output_aliases": len(aliases),
        "jobs": args.jobs,
        "timeout_seconds": args.timeout_seconds,
        "result_cache": str(args.result_cache),
        "output": str(args.output),
    }
    args.report.write_text(json.dumps(report, indent=2, sort_keys=True) + "\n")
    print(json.dumps(report, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
