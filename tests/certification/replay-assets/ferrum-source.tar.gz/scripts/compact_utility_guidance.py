#!/usr/bin/env python3
"""Intern repeated exact witnesses in a utility-guidance JSONL manifest.

The transformation is lossless: entry order, candidate order, evidence, and
aliases are preserved.  Only ``exact-*`` candidate strings are replaced by a
SHA-256 reference to one definition emitted at the beginning of the file.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import sqlite3
from pathlib import Path

WITNESS_SCHEMA = "ferrum.utility-guidance.witness.v1"
GROUPS = ("prefer", "possible", "avoid", "timeout")


def exact_candidates(row: dict) -> list[str]:
    result = []
    for group in GROUPS:
        for evidence in row.get(group) or []:
            candidate = evidence.get("candidate")
            if isinstance(candidate, str) and candidate.startswith("exact-"):
                result.append(candidate)
    return result


def witness_id(candidate: str) -> str:
    return hashlib.sha256(candidate.encode("utf-8")).hexdigest()


def evidence_digest(row: dict) -> bytes:
    state = {group: row.get(group) or [] for group in GROUPS}
    state["current_checker_invalidation"] = row.get(
        "current_checker_invalidation", False
    )
    return hashlib.sha256(
        json.dumps(state, separators=(",", ":"), sort_keys=True).encode("utf-8")
    ).digest()


def structural_aliases(paths: list[Path]) -> dict[str, set[str]]:
    result: dict[str, set[str]] = {}
    for path in paths:
        with sqlite3.connect(path) as connection:
            table = connection.execute(
                "SELECT 1 FROM sqlite_master "
                "WHERE type = 'table' AND name = 'problem_aliases'"
            ).fetchone()
            if table is None:
                continue
            for raw_key, canonical_key in connection.execute(
                "SELECT raw_problem_key, problem_key FROM problem_aliases"
            ):
                result.setdefault(raw_key, set()).add(canonical_key)
    return result


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("input", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument(
        "--structural-alias-sqlite",
        type=Path,
        action="append",
        default=[],
        help=(
            "collapse an exactly duplicate direct row to a typed structural alias "
            "using problem_aliases from this SQLite database (repeatable)"
        ),
    )
    args = parser.parse_args()

    witnesses: dict[str, str] = {}
    direct_digests: dict[str, bytes] = {}
    existing_alias_targets: set[str] = set()
    rows = 0
    occurrences = 0
    with args.input.open(encoding="utf-8") as source:
        for line_number, line in enumerate(source, 1):
            if not line.strip():
                continue
            row = json.loads(line)
            if row.get("schema") == WITNESS_SCHEMA:
                candidate = row["candidate"]
                identifier = row["witness_id"]
                if identifier != witness_id(candidate):
                    raise ValueError(
                        f"invalid witness digest on input line {line_number}"
                    )
                previous = witnesses.setdefault(identifier, candidate)
                if previous != candidate:
                    raise ValueError(f"SHA-256 collision on input line {line_number}")
                continue
            rows += 1
            if "canonical_problem_key" in row:
                existing_alias_targets.add(row["canonical_problem_key"])
            else:
                direct_digests[row["problem_key"]] = evidence_digest(row)
            for candidate in exact_candidates(row):
                identifier = witness_id(candidate)
                previous = witnesses.setdefault(identifier, candidate)
                if previous != candidate:
                    raise ValueError(f"SHA-256 collision on input line {line_number}")
                occurrences += 1

    aliases = structural_aliases(args.structural_alias_sqlite)
    collapsed_aliases = {}
    for raw_key, canonical_keys in aliases.items():
        if raw_key not in direct_digests:
            continue
        matching = sorted(
            canonical_key
            for canonical_key in canonical_keys
            if canonical_key != raw_key
            and canonical_key in direct_digests
            and direct_digests[raw_key] == direct_digests[canonical_key]
        )
        if matching:
            collapsed_aliases[raw_key] = matching[0]
    # The runtime intentionally resolves aliases in one hop.  Keep every
    # selected target as a direct row rather than emitting alias chains or
    # cycles whose meaning would depend on load order.
    selected_targets = set(collapsed_aliases.values()) | existing_alias_targets
    collapsed_aliases = {
        raw_key: canonical_key
        for raw_key, canonical_key in collapsed_aliases.items()
        if raw_key not in selected_targets
    }

    args.output.parent.mkdir(parents=True, exist_ok=True)
    with args.output.open("w", encoding="utf-8") as output:
        for identifier, candidate in sorted(witnesses.items()):
            print(
                json.dumps(
                    {
                        "schema": WITNESS_SCHEMA,
                        "witness_id": identifier,
                        "candidate": candidate,
                    },
                    separators=(",", ":"),
                    sort_keys=True,
                ),
                file=output,
            )
        with args.input.open(encoding="utf-8") as source:
            for line in source:
                if not line.strip():
                    continue
                row = json.loads(line)
                if row.get("schema") == WITNESS_SCHEMA:
                    continue
                if row.get("problem_key") in collapsed_aliases:
                    continue
                for group in GROUPS:
                    for evidence in row.get(group) or []:
                        candidate = evidence.get("candidate")
                        if not (
                            isinstance(candidate, str)
                            and candidate.startswith("exact-")
                        ):
                            continue
                        evidence["candidate_ref"] = witness_id(candidate)
                        del evidence["candidate"]
                print(
                    json.dumps(row, separators=(",", ":"), sort_keys=True),
                    file=output,
                )
        for raw_key, canonical_key in sorted(collapsed_aliases.items()):
            print(
                json.dumps(
                    {
                        "schema": "ferrum.utility-guidance.v2",
                        "problem_key": raw_key,
                        "canonical_problem_key": canonical_key,
                        "alias_kind": "structural",
                    },
                    separators=(",", ":"),
                    sort_keys=True,
                ),
                file=output,
            )

    input_bytes = args.input.stat().st_size
    output_bytes = args.output.stat().st_size
    print(
        json.dumps(
            {
                "input": str(args.input),
                "output": str(args.output),
                "rows": rows,
                "exact_occurrences": occurrences,
                "distinct_exact_witnesses": len(witnesses),
                "collapsed_structural_aliases": len(collapsed_aliases),
                "input_bytes": input_bytes,
                "output_bytes": output_bytes,
                "saved_bytes": input_bytes - output_bytes,
                "saved_percent": round(
                    100.0 * (input_bytes - output_bytes) / input_bytes, 2
                ),
            },
            sort_keys=True,
        )
    )


if __name__ == "__main__":
    main()
