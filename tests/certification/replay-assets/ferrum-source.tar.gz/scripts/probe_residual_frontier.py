"""Try bounded native continuations on unresolved audit states; never promote evidence."""
import argparse
from concurrent.futures import ThreadPoolExecutor
import json
from pathlib import Path
import subprocess
import time


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--inventory", type=Path, required=True)
    parser.add_argument("--replay", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--ferrum", type=Path, required=True)
    parser.add_argument("--strategy", action="append", required=True)
    parser.add_argument("--jobs", type=int, default=4)
    parser.add_argument("--timeout-ms", type=int, default=6000)
    parser.add_argument("--skip-checked", type=Path, action="append", default=[],
                        help="omit states already recovered and independently certified")
    args = parser.parse_args()
    unresolved = {r["input"] for r in map(json.loads, args.replay.read_text().splitlines()) if "proof" not in r}
    for path in args.skip_checked:
        unresolved.difference_update(r["input"] for r in map(json.loads, path.read_text().splitlines())
                                     if r.get("certified"))
    rows = [r for r in json.loads(args.inventory.read_text())["records"] if r["input"] in unresolved]
    # Repeated occurrences provide a measured reuse signal, not a claim of root gains.
    rows.sort(key=lambda r: (-len(r["origins"]), r["sha256"]))
    args.output.mkdir()

    def probe(row):
        directory = args.output / row["sha256"]
        directory.mkdir()
        trials = []
        for index, strategy in enumerate(args.strategy):
            proof = directory / f"{index}.cpf"
            events = directory / f"{index}.events.jsonl"
            started = time.monotonic()
            command = [str(args.ferrum.resolve()), "probe-cpf", row["input"], "--recursive",
                       "--summary", "--strategy", strategy, "--timeout-ms", str(args.timeout_ms),
                       "--cpf", str(proof), "--processor-events", str(events)]
            with (directory / f"{index}.stdout").open("x") as stdout, (directory / f"{index}.stderr").open("x") as stderr:
                try:
                    result = subprocess.run(command, stdout=stdout, stderr=stderr,
                                            timeout=args.timeout_ms / 1000 + 5)
                    status = result.returncode
                except subprocess.TimeoutExpired:
                    status = "harness-timeout"
            trials.append(dict(strategy=strategy, exit_code=status,
                               elapsed_seconds=time.monotonic() - started))
            if proof.exists() and proof.stat().st_size:
                return dict(input=row["input"], origins=row["origins"], trials=trials,
                            proof=str(proof), certified=False)
        return dict(input=row["input"], origins=row["origins"], trials=trials, certified=False)

    with (args.output / "results.jsonl").open("x") as output, ThreadPoolExecutor(max_workers=args.jobs) as pool:
        for result in pool.map(probe, rows):
            output.write(json.dumps(result) + "\n")
            output.flush()
            print(json.dumps(dict(input=result["input"], proof="proof" in result)), flush=True)


if __name__ == "__main__":
    main()
