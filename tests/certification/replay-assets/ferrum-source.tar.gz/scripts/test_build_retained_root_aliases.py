import json
import subprocess
import tempfile
import unittest
from pathlib import Path


SCRIPT = Path(__file__).with_name("build_retained_root_aliases.py")


class RetainedRootAliasTests(unittest.TestCase):
    def test_shallow_root_wins_over_earlier_nested_top_level_event(self):
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            proof_events = root / "proof-events.jsonl"
            runtime = root / "runtime"
            runtime.mkdir()
            output = root / "aliases.jsonl"
            problem_id = "TRS_Standard/Zantema_05/z01.ari"
            proof_events.write_text(
                "\n".join(
                    json.dumps(event)
                    for event in (
                        {
                            "level": "top-level",
                            "problem_id": problem_id,
                            "input": {"cpf": "<trsInput><trs><rules/></trs></trsInput>"},
                            "metrics": {
                                "proof_path": [
                                    "certificationProblem",
                                    "proof",
                                    "trsTerminationProof",
                                    "uncurry",
                                    "trsTerminationProof",
                                    "ruleRemoval",
                                ]
                            },
                        },
                        {
                            "level": "top-level",
                            "problem_id": problem_id,
                            "input": {"cpf": "<trsInput><trs/></trsInput>"},
                            "metrics": {
                                "proof_path": [
                                    "certificationProblem",
                                    "proof",
                                    "trsTerminationProof",
                                    "uncurry",
                                ]
                            },
                        },
                    )
                )
                + "\n",
                encoding="utf-8",
            )
            (runtime / "processor-events.jsonl").write_text(
                json.dumps(
                    {
                        "level": "top-level",
                        "problem_id": problem_id,
                        "strategy_atom": "utility-guidance",
                        "input": {"problem_key": "live-root"},
                    }
                )
                + "\n",
                encoding="utf-8",
            )

            subprocess.run(
                [
                    "python3",
                    str(SCRIPT),
                    "--proof-events",
                    str(proof_events),
                    "--runtime-run",
                    str(runtime),
                    "--output",
                    str(output),
                ],
                check=True,
                capture_output=True,
                text=True,
            )
            alias = json.loads(output.read_text(encoding="utf-8"))
            import hashlib

            expected = hashlib.sha256(
                "<trsInput><trs/></trsInput>".encode()
            ).hexdigest()
            self.assertEqual(alias["canonical_problem_key"], expected)
            self.assertEqual(alias["problem_key"], "live-root")


if __name__ == "__main__":
    unittest.main()
