#!/usr/bin/env python3
"""Plot Ferrum solved counts by timeout from a termcomp details.json file."""

from __future__ import annotations

import argparse
import csv
import json
from pathlib import Path


DEFAULT_TIMEOUTS = [1, 2, 5, 10, 30, 60, 120, 180, 240, 305]


def solved_counts(rows: list[dict], timeout: int) -> tuple[int, int]:
    yes = sum(
        1
        for row in rows
        if row.get("status") == "yes" and row.get("elapsed_seconds", 10**9) <= timeout
    )
    no = sum(
        1
        for row in rows
        if row.get("status") == "no" and row.get("elapsed_seconds", 10**9) <= timeout
    )
    return yes, no


def write_csv(path: Path, counts: list[tuple[int, int, int]]) -> None:
    with path.open("w", newline="") as handle:
        writer = csv.writer(handle)
        writer.writerow(["timeout_seconds", "yes", "no", "total"])
        for timeout, yes, no in counts:
            writer.writerow([timeout, yes, no, yes + no])


def write_svg(path: Path, counts: list[tuple[int, int, int]], title: str) -> None:
    width = 1080
    height = 620
    margin_left = 86
    margin_right = 30
    margin_top = 72
    margin_bottom = 86
    plot_width = width - margin_left - margin_right
    plot_height = height - margin_top - margin_bottom
    max_total = max(1, max(yes + no for _, yes, no in counts))
    y_top = ((max_total + 99) // 100) * 100
    bar_gap = 16
    bar_width = (plot_width - bar_gap * (len(counts) - 1)) / len(counts)

    def y(value: int) -> float:
        return margin_top + plot_height - (value / y_top) * plot_height

    parts = [
        f'<svg xmlns="http://www.w3.org/2000/svg" width="{width}" height="{height}" viewBox="0 0 {width} {height}">',
        "<style>",
        "text{font-family:Arial,Helvetica,sans-serif;fill:#202124}",
        ".axis{stroke:#333;stroke-width:1.2}",
        ".grid{stroke:#d8dee8;stroke-width:1}",
        ".yes{fill:#3b82f6}",
        ".no{fill:#ef4444}",
        ".label{font-size:13px}",
        ".small{font-size:12px;fill:#4b5563}",
        ".title{font-size:22px;font-weight:700}",
        "</style>",
        f'<rect width="{width}" height="{height}" fill="#fff"/>',
        f'<text x="{margin_left}" y="36" class="title">{title}</text>',
        f'<text x="{margin_left}" y="58" class="small">Stacked solved counts from details.json; YES and NO are counted only when elapsed_seconds <= timeout.</text>',
    ]

    for tick in range(0, y_top + 1, 100):
        yy = y(tick)
        parts.append(
            f'<line x1="{margin_left}" y1="{yy:.1f}" x2="{width - margin_right}" y2="{yy:.1f}" class="grid"/>'
        )
        parts.append(
            f'<text x="{margin_left - 12}" y="{yy + 4:.1f}" text-anchor="end" class="small">{tick}</text>'
        )

    parts.append(
        f'<line x1="{margin_left}" y1="{margin_top}" x2="{margin_left}" y2="{margin_top + plot_height}" class="axis"/>'
    )
    parts.append(
        f'<line x1="{margin_left}" y1="{margin_top + plot_height}" x2="{width - margin_right}" y2="{margin_top + plot_height}" class="axis"/>'
    )

    for index, (timeout, yes, no) in enumerate(counts):
        x = margin_left + index * (bar_width + bar_gap)
        total = yes + no
        yes_h = (yes / y_top) * plot_height
        no_h = (no / y_top) * plot_height
        yes_y = margin_top + plot_height - yes_h
        no_y = yes_y - no_h
        parts.append(f'<rect x="{x:.1f}" y="{yes_y:.1f}" width="{bar_width:.1f}" height="{yes_h:.1f}" class="yes"/>')
        parts.append(f'<rect x="{x:.1f}" y="{no_y:.1f}" width="{bar_width:.1f}" height="{no_h:.1f}" class="no"/>')
        parts.append(
            f'<text x="{x + bar_width / 2:.1f}" y="{no_y - 6:.1f}" text-anchor="middle" class="small">{total}</text>'
        )
        parts.append(
            f'<text x="{x + bar_width / 2:.1f}" y="{margin_top + plot_height + 22}" text-anchor="middle" class="label">{timeout}s</text>'
        )

    legend_x = width - margin_right - 180
    parts.extend(
        [
            f'<rect x="{legend_x}" y="28" width="16" height="16" class="no"/>',
            f'<text x="{legend_x + 24}" y="41" class="label">NO</text>',
            f'<rect x="{legend_x + 72}" y="28" width="16" height="16" class="yes"/>',
            f'<text x="{legend_x + 96}" y="41" class="label">YES</text>',
            f'<text x="{width / 2}" y="{height - 24}" text-anchor="middle" class="label">Timeout</text>',
            f'<text transform="translate(24 {height / 2}) rotate(-90)" text-anchor="middle" class="label">Solved examples</text>',
            "</svg>",
        ]
    )
    path.write_text("\n".join(parts) + "\n")


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("details", type=Path)
    parser.add_argument("--svg", type=Path, required=True)
    parser.add_argument("--csv", type=Path, required=True)
    parser.add_argument(
        "--timeouts",
        type=int,
        nargs="+",
        default=DEFAULT_TIMEOUTS,
        help="timeout cutoffs in seconds",
    )
    parser.add_argument(
        "--title",
        default="Ferrum TermCOMP 2025 TRS Solved Counts by Timeout",
    )
    args = parser.parse_args()

    rows = json.loads(args.details.read_text())
    counts = [(timeout, *solved_counts(rows, timeout)) for timeout in args.timeouts]
    write_csv(args.csv, counts)
    write_svg(args.svg, counts, args.title)


if __name__ == "__main__":
    main()
