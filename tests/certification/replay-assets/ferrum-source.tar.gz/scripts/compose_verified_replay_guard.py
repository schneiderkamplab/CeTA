"""Compare a complete guard plus explicitly identified corrective reruns to baseline.

This is mixed-run validation, never a claim of a fresh single-binary full replay.
"""
import argparse
import json
from pathlib import Path


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--baseline", type=Path, required=True)
    parser.add_argument("--guard", type=Path, required=True)
    parser.add_argument("--correction", type=Path, action="append", default=[])
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    baseline = {row["path"]: row for row in json.loads(args.baseline.read_text())}
    guard_rows = json.loads(args.guard.read_text())
    current = {row["path"]: row for row in guard_rows}
    assert len(current) == len(guard_rows) and current.keys() == baseline.keys()
    origins = {path: str(args.guard) for path in current}
    for correction in args.correction:
        for row in json.loads(correction.read_text()):
            assert row["path"] in current
            current[row["path"]] = row
            origins[row["path"]] = str(correction)
    losses = [path for path, row in current.items()
              if not row.get("certified") or row["status"] != baseline[path]["status"]]
    report = dict(scope="mixed-run guard with explicit corrective reruns",
        baseline=str(args.baseline), guard=str(args.guard),
        corrections=list(map(str, args.correction)), count=len(current),
        losses=losses, origins=origins)
    args.output.mkdir(exist_ok=False)
    (args.output / "comparison.json").write_text(json.dumps(report, indent=2))
    (args.output / "details.json").write_text(json.dumps(list(current.values()), indent=2))
    print(json.dumps({"count": len(current), "losses": losses}))


if __name__ == "__main__":
    main()
