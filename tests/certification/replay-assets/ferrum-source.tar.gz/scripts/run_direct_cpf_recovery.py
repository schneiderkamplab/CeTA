#!/usr/bin/env python3
"""Directly expose all local CPF steps, then source-check and export their keys."""
import argparse
from concurrent.futures import ThreadPoolExecutor, as_completed
import json
import os
from pathlib import Path
import subprocess
import sys
import xml.etree.ElementTree as ET


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--baseline', type=Path, required=True)
    selection = p.add_mutually_exclusive_group(required=True)
    selection.add_argument('--file-list', type=Path)
    selection.add_argument('--from-details', type=Path,
                           help='Directly recover only uncertified rows from this completed replay.')
    p.add_argument('--output', type=Path, required=True)
    p.add_argument('--ferrum', type=Path, required=True)
    p.add_argument('--ceta', type=Path, required=True)
    p.add_argument('--jobs', type=int, default=8)
    p.add_argument('--normalize-alpha', action='store_true')
    p.add_argument('--probe-timeout', type=float, default=60,
                   help='Local processor allowance in seconds; root replay remains independently bounded.')
    p.add_argument('--live-root-details', type=Path,
                   help='Start each source chain from its recorded live top-level input.')
    p.add_argument('--existing-steps-root', type=Path,
                   help='Re-address and re-import retained direct probes without repeating them.')
    args = p.parse_args()
    memory = {s.split(':')[0]: int(s.split()[1]) for s in Path('/proc/meminfo').read_text().splitlines()}
    if memory['MemTotal'] - memory['MemAvailable'] > 2 * 1024**3:
        raise RuntimeError('Non-reclaimable memory pressure exceeds 2 TiB')
    args.output.mkdir(parents=True, exist_ok=False)
    selected = (set(args.file_list.read_text().splitlines()) if args.file_list else
                {row['path'].split('TPDB-ARI/')[-1]
                 for row in json.loads(args.from_details.read_text())
                 if not row.get('certified')})
    tasks = []
    for category in ('standard', 'innermost', 'csr'):
        for row in json.loads((args.baseline / category / 'details.json').read_text()):
            identity = row['path'].split('TPDB-ARI/')[-1]
            if identity in selected:
                tasks.append((identity, Path(row['artifact_dir'])))
    if len(tasks) != len(selected):
        raise RuntimeError('Not every selected root has a retained baseline artifact')
    env = dict(os.environ, RAYON_NUM_THREADS='2', FERRUM_DP_LLM_NO_FALLBACK='1')
    live_roots = {}
    if args.live_root_details:
        for row in json.loads(args.live_root_details.read_text()):
            live_roots[row['path'].split('TPDB-ARI/')[-1]] = Path(row['artifact_dir'])/'processor-events.jsonl'

    def run(task):
        identity, source = task
        output = args.output / Path(identity).with_suffix('')
        output.mkdir(parents=True)
        steps = output / 'steps'
        commands = [
            [sys.executable, 'scripts/probe_complete_cpf_steps.py', '--proof', str(source / 'proof.cpf.xml'),
             '--problem-id', identity, '--output', str(steps), '--ferrum', str(args.ferrum), '--jobs', '2',
             '--follow-children', '--timeout', str(args.probe_timeout)],
            [sys.executable, 'scripts/extract_local_cpf_oracle_events.py', '--root', str(source),
             '--runtime-root', str(steps), '--ferrum-canonicalizer', str(args.ferrum), '--ceta', str(args.ceta),
             '--output', str(output / 'events.jsonl'), '--certified-manifest-output', str(output / 'manifest.jsonl'),
             '--proof-chain-only', '--exclude-complete-proof-atoms', '--runtime-explicit-states-only'],
        ]
        if args.existing_steps_root:
            commands[0] = [sys.executable, 'scripts/rekey_direct_cpf_events.py',
                '--root', str(args.existing_steps_root / Path(identity).with_suffix('') / 'steps'),
                '--output', str(steps)]
        elif args.normalize_alpha:
            commands[0].append('--normalize-alpha')
        if args.live_root_details and not args.existing_steps_root:
            live_input = None
            for line in live_roots[identity].open():
                event = json.loads(line)
                cpf = event.get('input', {}).get('cpf')
                if not cpf:
                    continue
                parsed = ET.fromstring(cpf)
                if parsed.tag == 'input' and len(parsed) == 1:
                    parsed = parsed[0]
                if parsed.tag in {'trsInput', 'srsInput', 'relativeTrsInput'}:
                    live_input = cpf
                    break
            if live_input is None:
                return dict(path=identity, output=str(output), phase='live-root-input', returncode=1)
            input_path = output/'live-root.cpf'
            input_path.write_text(live_input)
            commands[0].extend(['--root-input', str(input_path)])
        for index, command in enumerate(commands):
            with (output / f'phase-{index}.log').open('x') as stream:
                try:
                    result = subprocess.run(command, env=env, stdout=stream, stderr=subprocess.STDOUT, timeout=900)
                except subprocess.TimeoutExpired:
                    return dict(path=identity, output=str(output), phase=index, returncode=124)
            if result.returncode:
                return dict(path=identity, output=str(output), phase=index, returncode=result.returncode)
        return dict(path=identity, output=str(output), returncode=0)

    with ThreadPoolExecutor(max_workers=args.jobs) as pool:
        with (args.output / 'results.jsonl').open('x') as stream:
            for future in as_completed([pool.submit(run, task) for task in tasks]):
                row = future.result()
                print(json.dumps(row), file=stream, flush=True)
                print(json.dumps(row), flush=True)


if __name__ == '__main__':
    main()
