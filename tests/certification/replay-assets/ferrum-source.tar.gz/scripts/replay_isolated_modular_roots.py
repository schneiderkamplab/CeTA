#!/usr/bin/env python3
"""Test root-local modular guidance without competing global oracle actions."""
import argparse
from concurrent.futures import ThreadPoolExecutor, as_completed
import json
import os
from pathlib import Path
import subprocess
import sys


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    for name in ('shards', 'baseline', 'file-list', 'output', 'ferrum', 'ceta'):
        parser.add_argument('--' + name, type=Path, required=True)
    parser.add_argument('--jobs', type=int, default=4)
    parser.add_argument('--materialized-only', action='store_true',
                        help='Use completed steps directories while independent extraction is pending.')
    args = parser.parse_args()
    args.output.mkdir(parents=True, exist_ok=False)
    selected = set(args.file_list.read_text().splitlines())
    tasks = ([dict(path=path, output=str(args.shards/Path(path).with_suffix('')))
              for path in sorted(selected)] if args.materialized_only else
             [json.loads(line) for line in (args.shards/'results.jsonl').read_text().splitlines()])
    tasks = [row for row in tasks if row['path'] in selected
             and (Path(row['output'])/'steps/results.jsonl').exists()]
    env = dict(os.environ, FERRUM_DP_LLM_NO_FALLBACK='1', RAYON_NUM_THREADS='2')

    def run(row):
        output = args.output/Path(row['path']).with_suffix('')
        output.mkdir(parents=True)
        selection = output/'root.txt'
        selection.write_text(row['path'] + '\n')
        empty = output/'empty.jsonl'
        empty.touch()
        source_shards = args.shards
        if args.materialized_only:
            source_shards = output/'materialized-shards'
            source_shards.mkdir()
            (source_shards/'results.jsonl').write_text(json.dumps(dict(row, returncode=0,
                scope='native steps only; source certification is performed by exporter')) + '\n')
        commands = [
            [sys.executable, 'scripts/export_direct_native_hints.py', '--shards', str(source_shards),
             '--file-list', str(selection), '--baseline', str(args.baseline), '--ceta', str(args.ceta),
             '--ferrum', str(args.ferrum), '--jobs', '1', '--output', str(output/'hints.jsonl')],
            [sys.executable, 'scripts/certify_modular_terminals.py', '--root', str(Path(row['output'])/'steps'),
             '--output', str(output/'terminals'), '--ferrum', str(args.ferrum), '--ceta', str(args.ceta),
             '--jobs', '2', '--include-open-terminals', '--candidate', 'size-change',
             '--candidate', 'subterm', '--candidate', 'graph'],
            [sys.executable, 'scripts/merge_monotone_oracle_records.py', '--base', str(empty),
             '--incoming', str(output/'hints.jsonl'), '--incoming', str(output/'terminals/oracle.jsonl'),
             '--output', str(output/'oracle.jsonl'), '--report', str(output/'merge.json')],
            [sys.executable, 'scripts/termcomp_trs_compare.py', '--ferrum', str(args.ferrum),
             '--ceta', str(args.ceta), '--category', row['path'].split('/')[0], '--file-list', str(selection),
             '--jobs', '1', '--timeout', '305', '--output', str(output/'summary.md'),
             '--details-output', str(output/'details.json'), '--run-dir', str(output/'run'),
             '--extra-arg=--strategy', '--extra-arg=timeout(300s, fail)',
             '--extra-arg=--utility-guidance-manifest', '--extra-arg=' + str(output/'oracle.jsonl'),
             '--extra-arg=--no-top-level-llm'],
        ]
        for phase, command in enumerate(commands):
            with (output/f'phase-{phase}.log').open('x') as log:
                try:
                    result = subprocess.run(command, env=env, stdout=log, stderr=subprocess.STDOUT, timeout=900)
                except subprocess.TimeoutExpired:
                    return dict(path=row['path'], output=str(output), phase=phase, returncode=124)
            if result.returncode:
                return dict(path=row['path'], output=str(output), phase=phase, returncode=result.returncode)
        details = json.loads((output/'details.json').read_text())
        return dict(path=row['path'], output=str(output), returncode=0,
                    certified=len(details) == 1 and bool(details[0].get('certified')))

    with ThreadPoolExecutor(max_workers=args.jobs) as pool, (args.output/'results.jsonl').open('x') as log:
        for future in as_completed([pool.submit(run, row) for row in tasks]):
            result = future.result()
            print(json.dumps(result), file=log, flush=True)
            print(json.dumps(result), flush=True)


if __name__ == '__main__':
    main()
