#!/usr/bin/env python3
"""Recheck and freeze the union of certified campaign proofs.

Root proofs and independently certified canonical fragments are deduplicated by
their proof obligation. Native context-sensitive obligations are deliberately
excluded so CSR checker development can proceed independently.
"""

from __future__ import annotations

import argparse
import concurrent.futures
import hashlib
import json
import os
from pathlib import Path
import shutil
import sqlite3
import subprocess
import tempfile
import time
from typing import Any


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as source:
        for chunk in iter(lambda: source.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def is_csr(path: Path | None) -> bool:
    if path is None or not path.exists():
        return False
    text = path.read_text(encoding="utf-8", errors="ignore")
    return "<contextSensitive" in text or "<replacementMapEntry" in text


def collect_root(round_dir: Path) -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    for result_path in sorted((round_dir / "root" / "per-problem").glob("*.result.json")):
        try:
            result = json.loads(result_path.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError):
            continue
        if not result.get("certified") or result.get("category") == "TRS_Contextsensitive":
            continue
        proof = Path(str(result.get("cpf_path", "")))
        if not proof.exists() or is_csr(proof):
            continue
        rows.append(
            {
                "obligation_key": "root\0"
                + str(result.get("category"))
                + "\0"
                + str(result.get("path")),
                "scope": "root",
                "category": result.get("category"),
                "problem_id": result.get("problem_id"),
                "problem_key": None,
                "candidate": None,
                "input_path": result.get("path"),
                "proof_path": str(proof),
                "checker_kind": "full",
                "source_round": round_dir.name,
                "recorded_implementation_hash": None,
            }
        )
    return rows


def collect_canonical_ledger(ledger: Path, campaign_dir: Path) -> list[dict[str, Any]]:
    connection = sqlite3.connect(f"file:{ledger}?mode=ro", uri=True)
    columns = {row[1] for row in connection.execute("PRAGMA table_info(trials)")}
    if "certification_status" not in columns:
        connection.close()
        return []
    implementation = (
        "implementation_hash" if "implementation_hash" in columns else "NULL"
    )
    records = connection.execute(
        f"""
        SELECT problem_key, candidate, cpf_path, certification_status,
               {implementation}
        FROM trials
        WHERE state = 'completed'
          AND certification_status IN (
              'certified-full', 'certified-fragment'
          )
          AND cpf_path IS NOT NULL
        ORDER BY finished_at
        """
    ).fetchall()
    rows: list[dict[str, Any]] = []
    for problem_key, candidate, raw_proof, status, implementation_hash in records:
        proof = Path(raw_proof)
        input_path = proof.parent / "input.cpf3.xml"
        if not proof.exists():
            continue
        rows.append(
            {
                "obligation_key": f"canonical\0{problem_key}\0{candidate}",
                "scope": "canonical",
                "category": None,
                "problem_id": None,
                "problem_key": problem_key,
                "candidate": candidate,
                "input_path": str(input_path),
                "proof_path": str(proof),
                "checker_kind": (
                    "fragment" if status == "certified-fragment" else "full"
                ),
                "source_round": str(ledger.parent.relative_to(campaign_dir)),
                "recorded_implementation_hash": implementation_hash,
            }
        )
    tables = {
        row[0]
        for row in connection.execute(
            "SELECT name FROM sqlite_master WHERE type='table'"
        )
    }
    if "assembled_proofs" in tables:
        for raw_hash, task_key, raw_proof, implementation_hash in connection.execute(
            """
            SELECT raw_hash, transition_task_key, proof_path, implementation_hash
            FROM assembled_proofs WHERE checker_result='CERTIFIED'
            """
        ):
            proof = Path(raw_proof)
            if not proof.exists():
                continue
            rows.append(
                {
                    "obligation_key": f"assembled\0{raw_hash}\0{task_key}",
                    "scope": "assembled",
                    "category": None,
                    "problem_id": None,
                    "problem_key": raw_hash,
                    "candidate": None,
                    "input_path": "",
                    "proof_path": str(proof),
                    "checker_kind": "full",
                    "source_round": str(ledger.parent.relative_to(campaign_dir)),
                    "recorded_implementation_hash": implementation_hash,
                }
            )
    connection.close()
    return rows


def check_one(
    row: dict[str, Any],
    ceta: Path,
    fragment_ceta: Path,
    timeout: float,
) -> dict[str, Any]:
    checker = fragment_ceta if row["checker_kind"] == "fragment" else ceta
    command = [str(checker)]
    if row["checker_kind"] == "fragment":
        command.append("--allow-assumptions")
    command.append(row["proof_path"])
    started = time.monotonic()
    try:
        completed = subprocess.run(
            command,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
            timeout=timeout,
        )
        timed_out = False
    except subprocess.TimeoutExpired as error:
        completed = None
        timed_out = True
        stdout = error.stdout or ""
        stderr = error.stderr or ""
    else:
        stdout = completed.stdout
        stderr = completed.stderr
    certified = (
        completed is not None
        and completed.returncode == 0
        and "CERTIFIED" in stdout.upper()
    )
    return {
        **row,
        "recheck_status": "timeout" if timed_out else ("certified" if certified else "failed"),
        "recheck_return_code": None if completed is None else completed.returncode,
        "recheck_elapsed_ms": int((time.monotonic() - started) * 1000),
        "recheck_stdout": stdout,
        "recheck_stderr": stderr,
    }


def link_or_copy(source: Path, destination: Path) -> None:
    destination.parent.mkdir(parents=True, exist_ok=True)
    try:
        os.link(source, destination)
    except OSError:
        shutil.copy2(source, destination)


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--campaign-dir", type=Path, required=True)
    parser.add_argument("--output-dir", type=Path, required=True)
    parser.add_argument("--ceta", type=Path, required=True)
    parser.add_argument("--fragment-ceta", type=Path, required=True)
    parser.add_argument("--jobs", type=int, default=8)
    parser.add_argument("--timeout", type=float, default=60.0)
    parser.add_argument("--progress-every", type=int, default=50)
    args = parser.parse_args()

    rounds = sorted((args.campaign_dir / "rounds").glob("r[0-9][0-9]"))
    latest: dict[str, dict[str, Any]] = {}
    for round_dir in rounds:
        for row in collect_root(round_dir):
            latest[row["obligation_key"]] = row
    ledgers = sorted(args.campaign_dir.rglob("campaign.sqlite"))
    for ledger in ledgers:
        for row in collect_canonical_ledger(ledger, args.campaign_dir):
            latest[row["obligation_key"]] = row
    rows = list(latest.values())
    args.output_dir.mkdir(parents=True, exist_ok=True)
    print(
        f"certified-union collected={len(rows)} rounds={len(rounds)} "
        f"ledgers={len(ledgers)}",
        flush=True,
    )

    checked: list[dict[str, Any]] = []
    with concurrent.futures.ThreadPoolExecutor(max_workers=args.jobs) as executor:
        futures = [
            executor.submit(check_one, row, args.ceta, args.fragment_ceta, args.timeout)
            for row in rows
        ]
        for index, future in enumerate(concurrent.futures.as_completed(futures), 1):
            checked.append(future.result())
            if index % args.progress_every == 0 or index == len(futures):
                certified = sum(row["recheck_status"] == "certified" for row in checked)
                print(
                    f"certified-union progress={index}/{len(futures)} certified={certified}",
                    flush=True,
                )

    manifest = args.output_dir / "manifest.jsonl"
    certified_rows = 0
    with tempfile.NamedTemporaryFile(
        "w", encoding="utf-8", dir=args.output_dir, delete=False
    ) as output:
        temporary = Path(output.name)
        for row in sorted(checked, key=lambda item: item["obligation_key"]):
            proof = Path(row["proof_path"])
            row["proof_sha256"] = sha256(proof)
            if row["recheck_status"] == "certified":
                certified_rows += 1
                retained = (
                    args.output_dir
                    / "artifacts"
                    / row["proof_sha256"][:2]
                    / row["proof_sha256"]
                )
                retained_proof = retained / "proof.cpf3.xml"
                if not retained_proof.exists():
                    link_or_copy(proof, retained_proof)
                input_path = Path(row["input_path"])
                if input_path.exists():
                    retained_input = retained / (
                        "input.cpf3.xml" if input_path.suffix == ".xml" else input_path.name
                    )
                    if not retained_input.exists():
                        link_or_copy(input_path, retained_input)
                    row["retained_input_path"] = str(retained_input)
                row["retained_proof_path"] = str(retained_proof)
            print(json.dumps(row, sort_keys=True), file=output)
    temporary.replace(manifest)
    summary = {
        "schema": "ferrum.certified-campaign-union.v1",
        "campaign_dir": str(args.campaign_dir.resolve()),
        "csr_excluded": False,
        "rounds": [round_dir.name for round_dir in rounds],
        "ledgers": [str(ledger) for ledger in ledgers],
        "collected": len(rows),
        "certified": certified_rows,
        "failed": sum(row["recheck_status"] == "failed" for row in checked),
        "timeout": sum(row["recheck_status"] == "timeout" for row in checked),
        "manifest": str(manifest.resolve()),
    }
    (args.output_dir / "summary.json").write_text(
        json.dumps(summary, indent=2, sort_keys=True) + "\n", encoding="utf-8"
    )
    print(json.dumps(summary, sort_keys=True), flush=True)
    return 0 if certified_rows == len(rows) else 1


if __name__ == "__main__":
    raise SystemExit(main())
