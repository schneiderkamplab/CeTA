import hashlib
import unittest
from export_native_replay_hints import atomic_candidate, collect_supported, attach_canonical_alias


class NativeHintTests(unittest.TestCase):
    def test_shared_top_order_is_an_untried_state_local_alternative(self):
        event = dict(self.event('path-order'), level='top-level')
        rows, _ = collect_supported([event], shared_top_path_order=True)
        candidates = next(iter(rows.values()))['possible']
        atoms = [c['candidate'] for c in candidates]
        index = atoms.index('path-order(max-symbols=256,shared=1)')
        self.assertLess(index, atoms.index('path-order'))
        self.assertEqual(candidates[index]['attempts'], 0)
        self.assertEqual(candidates[index]['certified_count'], 0)
        event['level'] = 'dependency-pair'
        rows, _ = collect_supported([event], shared_top_path_order=True)
        self.assertFalse(any('shared=' in c['candidate'] for c in next(iter(rows.values()))['possible']))

    def test_family_selection_does_not_change_unrelated_priorities(self):
        rows, _ = collect_supported([self.event('poly'), self.event('matrix(dimension=2)')],
                                    candidate_families=['matrix'])
        row = next(iter(rows.values()))
        self.assertEqual([c['candidate'] for c in row['possible']], ['matrix(dimension=2)'])
        self.assertEqual(row['possible'][0]['certified_count'], 0)
        rows, _ = collect_supported([self.event('poly')], candidate_families=['matrix'])
        self.assertEqual(rows, {})

    def test_terminal_priority_does_not_promote_certification_credit(self):
        transform, terminal = self.event('poly'), self.event('size-change')
        transform['outcome'] = 'transformed'
        rows, _ = collect_supported([transform, terminal], prefer_terminal=True)
        row = next(iter(rows.values()))
        self.assertEqual([c['candidate'] for c in row['possible']], ['size-change', 'poly'])
        self.assertTrue(all(c['certified_count'] == 0 for c in row['possible']))
        self.assertEqual(row['prefer'], [])

    def test_later_trial_priority_preserves_alternatives_without_credit(self):
        rows, _ = collect_supported([self.event('matrix'), self.event('poly')],
                                     prefer_latest=True)
        row = next(iter(rows.values()))
        self.assertEqual([c['candidate'] for c in row['possible']], ['poly', 'matrix'])
        self.assertTrue(all(c['certified_count'] == 0 for c in row['possible']))
        self.assertEqual(row['replay_order'][0], hashlib.sha256(b'poly').hexdigest())

    def test_raw_search_hint_keeps_canonical_fallback_without_self_alias(self):
        rows, _ = collect_supported([self.event('poly')])
        raw = next(iter(rows))
        attach_canonical_alias(rows, raw, 'canonical')
        self.assertEqual(rows[raw]['canonical_problem_key'], 'canonical')
        self.assertNotIn('canonical_problem_key', rows['canonical'])
        self.assertEqual(rows[raw]['possible'], rows['canonical']['possible'])
        attach_canonical_alias(rows, 'canonical', 'canonical')
        self.assertNotIn('canonical_problem_key', rows['canonical'])

    def test_continuations_are_not_exported(self):
        self.assertEqual(atomic_candidate('csr-improved-dp(pipeline(graph; size-change))'),
                         'csr-improved-dp')
        self.assertEqual(atomic_candidate('dp(graph; size-change)'), 'dp')
        self.assertEqual(atomic_candidate('dp-trimmed(graph; size-change)'), 'dp-trimmed')
        self.assertIsNone(atomic_candidate('pipeline(graph; size-change)'))
        self.assertIsNone(atomic_candidate('timeout(8s, graph)'))
        self.assertEqual(atomic_candidate('matrix(dim=2,bound=1)'), 'matrix(dim=2,bound=1)')

    def test_native_role_order_is_an_alternative(self):
        rows, _ = collect_supported([self.event('path-order')])
        self.assertEqual([c['candidate'] for c in next(iter(rows.values()))['possible']],
                         ['gm04-rpo', 'path-order'])
        self.assertEqual(next(iter(rows.values()))['possible'][0]['attempts'], 0)

    def event(self, atom):
        cpf = '<dpInput/>'
        return dict(processor=atom, outcome='solved', input=dict(
            cpf=cpf, problem_key=hashlib.sha256(cpf.encode()).hexdigest()))

    def test_no_credit_and_deduplication(self):
        rows, omitted = collect_supported([self.event('graph'), self.event('graph')])
        row = next(iter(rows.values()))
        self.assertEqual(len(row['possible']), 1)
        self.assertEqual(row['possible'][0]['certified_count'], 0)
        self.assertEqual(row['possible'][0]['solved_count'], 0)
        self.assertEqual(row['prefer'], [])
        self.assertFalse(omitted)

    def test_unsupported_does_not_drop_supported(self):
        rows, omitted = collect_supported([self.event('exact-unknown(hex=5b5d)'), self.event('graph')])
        self.assertEqual(len(rows), 1)
        self.assertEqual(omitted['exact-unknown'], 1)

    def test_discovery_bounds_remain_untried_hints(self):
        rows, omitted = collect_supported([self.event('matrix(dim=2,bound=1)')],
                                          ['matrix(dim=2,bound=3)', 'poly'])
        candidates = next(iter(rows.values()))['possible']
        self.assertEqual([c['candidate'] for c in candidates],
                         ['matrix(dim=2,bound=3)', 'matrix(dim=2,bound=1)'])
        self.assertEqual(candidates[0]['attempts'], 0)
        self.assertEqual(candidates[0]['certified_count'], 0)
        self.assertFalse(omitted)

    def test_digest_errors_are_not_swallowed(self):
        event = self.event('graph')
        event['input']['cpf'] = '<changed/>'
        with self.assertRaisesRegex(ValueError, 'digest mismatch'):
            collect_supported([event])


if __name__ == '__main__':
    unittest.main()
