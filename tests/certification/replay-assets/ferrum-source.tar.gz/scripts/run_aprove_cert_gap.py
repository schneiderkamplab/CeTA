#!/usr/bin/env python3
from __future__ import annotations

import argparse
import concurrent.futures
import hashlib
import json
import os
import re
import shutil
import signal
import sqlite3
import subprocess
import sys
import time
from dataclasses import dataclass
from pathlib import Path


@dataclass(frozen=True)
class Candidate:
    benchmark_key: str
    local_path: Path
    historical_runtime: float | None


@dataclass(frozen=True)
class Result:
    benchmark_key: str
    local_path: str
    status: str
    decision: str | None
    elapsed_seconds: float
    stdout_path: str
    stderr_path: str
    cpf2_path: str | None
    cpf3_path: str | None
    ceta_stdout_path: str | None
    ceta_stderr_path: str | None
    sha256: str | None
    bytes: int | None
    error: str | None


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Run AProVE CPF generation on TRS_Standard gaps without certified AProVE proofs."
    )
    parser.add_argument("--db", type=Path, default=Path("target/termcomp-proof-corpus/proofs.sqlite"))
    parser.add_argument("--tpdb", type=Path, default=Path("/work/dfm/festschrift/TPDB-ARI"))
    parser.add_argument(
        "--aprove-rootfs",
        type=Path,
        default=Path("/work/dfm/festschrift/.containers/rootfs/jckassing_aprove_solver_aprove_termcomp25_v7"),
    )
    parser.add_argument("--ceta", type=Path, default=Path(".tools/ceta-relative-bounds"))
    parser.add_argument("--out", type=Path, default=Path("target/aprove-cert-runs"))
    parser.add_argument("--workers", type=int, default=128)
    parser.add_argument("--timeout", type=float, default=65.0)
    parser.add_argument("--limit", type=int, default=0, help="Limit candidate count; 0 means all.")
    parser.add_argument("--no-db-insert", action="store_true")
    return parser.parse_args()


def connect(db: Path) -> sqlite3.Connection:
    conn = sqlite3.connect(db, timeout=120.0)
    conn.execute("pragma busy_timeout=120000")
    return conn


def benchmark_to_local(tpdb: Path, benchmark: str) -> Path | None:
    key = benchmark
    if key.startswith("TRS_Standard/"):
        key = key[len("TRS_Standard/") :]
    key = re.sub(r"\.xml$", ".ari", key)
    path = tpdb / "TRS_Standard" / key
    if path.exists():
        return path
    return None


def load_candidates(db: Path, tpdb: Path, limit: int) -> list[Candidate]:
    query = """
with aprove_yes as (
  select benchmark, min(coalesce(runtime_seconds, 999999.0)) rt
  from proofs
  where category = 'TRS_Standard'
    and lower(tool) like '%aprove%'
    and certification = 'uncertified'
    and result = 'YES'
  group by benchmark
),
aprove_cert as (
  select distinct benchmark
  from proofs
  where category = 'TRS_Standard'
    and lower(tool) like '%aprove%'
    and certification = 'certified'
    and result like '%YES%'
)
select benchmark, rt
from aprove_yes
where benchmark not in (select benchmark from aprove_cert)
order by rt asc, benchmark asc
"""
    conn = connect(db)
    rows = conn.execute(query).fetchall()
    conn.close()

    seen_paths: set[Path] = set()
    candidates: list[Candidate] = []
    for benchmark, runtime in rows:
        local = benchmark_to_local(tpdb, benchmark)
        if local is None:
            continue
        local = local.resolve()
        if local in seen_paths:
            continue
        seen_paths.add(local)
        key = f"TRS_Standard/{local.relative_to(tpdb / 'TRS_Standard')}"
        candidates.append(
            Candidate(
                benchmark_key=key,
                local_path=local,
                historical_runtime=None if runtime is None or runtime >= 999999.0 else float(runtime),
            )
        )
        if limit and len(candidates) >= limit:
            break
    return candidates


def safe_name(key: str) -> str:
    return re.sub(r"[^A-Za-z0-9._-]+", "_", key).strip("_")


def write_text(path: Path, data: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(data, encoding="utf-8", errors="replace")


def run_process(
    args: list[str],
    timeout: float,
    env: dict[str, str],
    cwd: Path,
) -> tuple[int | None, bytes, bytes, bool]:
    proc = subprocess.Popen(
        args,
        cwd=cwd,
        env=env,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        start_new_session=True,
    )
    try:
        stdout, stderr = proc.communicate(timeout=timeout)
        return proc.returncode, stdout, stderr, False
    except subprocess.TimeoutExpired:
        try:
            os.killpg(proc.pid, signal.SIGTERM)
            stdout, stderr = proc.communicate(timeout=3)
        except Exception:
            try:
                os.killpg(proc.pid, signal.SIGKILL)
            except ProcessLookupError:
                pass
            stdout, stderr = proc.communicate()
        return None, stdout, stderr, True


def run_candidate(
    candidate: Candidate,
    run_dir: Path,
    aprove_rootfs: Path,
    ceta: Path,
    timeout_seconds: float,
    cwd: Path,
) -> Result:
    start = time.monotonic()
    name = safe_name(candidate.benchmark_key)
    artifact_dir = run_dir / "artefacts" / name
    artifact_dir.mkdir(parents=True, exist_ok=True)

    stdout_path = artifact_dir / "aprove.stdout"
    stderr_path = artifact_dir / "aprove.stderr"
    cpf2_path = artifact_dir / "proof.cpf2.xml"
    cpf3_path = artifact_dir / "proof.cpf3.xml"
    ceta_stdout_path = artifact_dir / "ceta.stdout"
    ceta_stderr_path = artifact_dir / "ceta.stderr"

    env = os.environ.copy()
    bundle = aprove_rootfs / "opt" / "bundle"
    env["PATH"] = f"{bundle / 'bin'}:{env.get('PATH', '')}"
    lib_path = f"{bundle / 'lib'}:{bundle / 'c_lib'}"
    env["LD_LIBRARY_PATH"] = f"{lib_path}:{env.get('LD_LIBRARY_PATH', '')}"

    jar = bundle / "aprove.jar"
    cmd = [
        "java",
        "-ea",
        "-jar",
        str(jar),
        "-m",
        "wst",
        "-p",
        "cpf",
        str(candidate.local_path),
    ]
    returncode, stdout, stderr, timed_out = run_process(cmd, timeout_seconds, env, cwd)
    stdout_path.write_bytes(stdout)
    stderr_path.write_bytes(stderr)

    elapsed = time.monotonic() - start
    if timed_out:
        return Result(
            candidate.benchmark_key,
            str(candidate.local_path),
            "timeout",
            None,
            elapsed,
            str(stdout_path),
            str(stderr_path),
            None,
            None,
            None,
            None,
            None,
            None,
            None,
        )
    if returncode != 0:
        return Result(
            candidate.benchmark_key,
            str(candidate.local_path),
            "aprove-error",
            None,
            elapsed,
            str(stdout_path),
            str(stderr_path),
            None,
            None,
            None,
            None,
            None,
            None,
            f"aprove exit {returncode}",
        )

    text = stdout.decode("utf-8", errors="replace")
    first = text.splitlines()[0].strip() if text.splitlines() else ""
    if first not in {"YES", "NO"}:
        return Result(
            candidate.benchmark_key,
            str(candidate.local_path),
            "maybe",
            first or None,
            elapsed,
            str(stdout_path),
            str(stderr_path),
            None,
            None,
            None,
            None,
            None,
            None,
            None,
        )

    cpf2 = "\n".join(text.splitlines()[1:])
    if not cpf2.strip().startswith("<?xml"):
        return Result(
            candidate.benchmark_key,
            str(candidate.local_path),
            "no-cpf",
            first,
            elapsed,
            str(stdout_path),
            str(stderr_path),
            None,
            None,
            None,
            None,
            None,
            None,
            "decision without CPF XML",
        )
    write_text(cpf2_path, cpf2)

    converter = aprove_rootfs / "opt" / "cpfconverter" / "cpf2_to_3.sh"
    conv_code, conv_stdout, conv_stderr, conv_timeout = run_process(
        [str(converter), str(cpf2_path)],
        30.0,
        env,
        cwd,
    )
    if conv_stdout:
        cpf3_path.write_bytes(conv_stdout)
    (artifact_dir / "converter.stderr").write_bytes(conv_stderr)
    if conv_timeout or conv_code != 0:
        return Result(
            candidate.benchmark_key,
            str(candidate.local_path),
            "conversion-error",
            first,
            time.monotonic() - start,
            str(stdout_path),
            str(stderr_path),
            str(cpf2_path),
            str(cpf3_path) if cpf3_path.exists() else None,
            None,
            None,
            None,
            None,
            "cpf2_to_3 failed",
        )

    ceta_code, ceta_stdout, ceta_stderr, ceta_timeout = run_process(
        [str(ceta), str(cpf3_path)],
        30.0,
        env,
        cwd,
    )
    ceta_stdout_path.write_bytes(ceta_stdout)
    ceta_stderr_path.write_bytes(ceta_stderr)
    ceta_text = ceta_stdout.decode("utf-8", errors="replace") + ceta_stderr.decode("utf-8", errors="replace")
    if ceta_timeout or ceta_code != 0 or "CERTIFIED" not in ceta_text:
        return Result(
            candidate.benchmark_key,
            str(candidate.local_path),
            "ceta-failed",
            first,
            time.monotonic() - start,
            str(stdout_path),
            str(stderr_path),
            str(cpf2_path),
            str(cpf3_path),
            str(ceta_stdout_path),
            str(ceta_stderr_path),
            None,
            None,
            ceta_text.strip()[:500] or f"ceta exit {ceta_code}",
        )

    data = cpf3_path.read_bytes()
    return Result(
        candidate.benchmark_key,
        str(candidate.local_path),
        "certified",
        first,
        time.monotonic() - start,
        str(stdout_path),
        str(stderr_path),
        str(cpf2_path),
        str(cpf3_path),
        str(ceta_stdout_path),
        str(ceta_stderr_path),
        hashlib.sha256(data).hexdigest(),
        len(data),
        None,
    )


def insert_results(db: Path, results: list[Result]) -> int:
    rows = [
        r
        for r in results
        if r.status == "certified" and r.decision in {"YES", "NO"} and r.cpf3_path
    ]
    if not rows:
        return 0
    conn = connect(db)
    now = time.time()
    with conn:
        for r in rows:
            proof_url = f"local://generated/aprove25-cert/{r.benchmark_key}/cpf3"
            data = Path(r.cpf3_path).read_bytes()
            first_line = data.splitlines()[0].decode("utf-8", "replace") if data else ""
            conn.execute(
                """
insert or replace into proofs (
  year, category, benchmark, tool, tool_column, result, certification,
  proof_url, error_url, benchmark_url, runtime_seconds, cert_runtime_seconds,
  local_path, sha256, bytes, first_line, detected_format, extracted_json,
  download_error, downloaded_at, archive_url, archive_member
) values (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
""",
                (
                    2026,
                    "TRS_Standard",
                    r.benchmark_key,
                    "AProVE25 local generated certified",
                    0,
                    f"CERTIFIED {r.decision}",
                    "certified",
                    proof_url,
                    None,
                    f"file://{r.local_path}",
                    r.elapsed_seconds,
                    None,
                    r.cpf3_path,
                    r.sha256,
                    r.bytes,
                    first_line,
                    "xml-cpf3",
                    None,
                    None,
                    now,
                    None,
                    None,
                ),
            )
    conn.close()
    return len(rows)


def main() -> int:
    args = parse_args()
    cwd = Path.cwd().resolve()
    if not args.aprove_rootfs.exists():
        print(f"missing AProVE rootfs: {args.aprove_rootfs}", file=sys.stderr)
        return 2
    if not args.ceta.exists():
        print(f"missing CeTA: {args.ceta}", file=sys.stderr)
        return 2

    stamp = time.strftime("%Y%m%d-%H%M%S")
    run_dir = args.out / stamp
    run_dir.mkdir(parents=True, exist_ok=True)

    candidates = load_candidates(args.db, args.tpdb, args.limit)
    (run_dir / "candidates.tsv").write_text(
        "".join(f"{c.benchmark_key}\t{c.local_path}\t{c.historical_runtime or ''}\n" for c in candidates),
        encoding="utf-8",
    )
    meta = {
        "started_at": time.time(),
        "workers": args.workers,
        "timeout": args.timeout,
        "candidate_count": len(candidates),
        "db": str(args.db),
        "tpdb": str(args.tpdb),
        "aprove_rootfs": str(args.aprove_rootfs),
        "ceta": str(args.ceta),
    }
    (run_dir / "run.json").write_text(json.dumps(meta, indent=2, sort_keys=True), encoding="utf-8")
    print(f"run_dir={run_dir}", flush=True)
    print(f"candidates={len(candidates)} workers={args.workers} timeout={args.timeout}", flush=True)

    results: list[Result] = []
    results_path = run_dir / "results.jsonl"
    counts: dict[str, int] = {}
    started = time.monotonic()

    with concurrent.futures.ThreadPoolExecutor(max_workers=args.workers) as pool:
        futures = [
            pool.submit(
                run_candidate,
                candidate,
                run_dir,
                args.aprove_rootfs,
                args.ceta,
                args.timeout,
                cwd,
            )
            for candidate in candidates
        ]
        with results_path.open("a", encoding="utf-8") as results_file:
            for index, future in enumerate(concurrent.futures.as_completed(futures), start=1):
                try:
                    result = future.result()
                except Exception as exc:
                    result = Result(
                        "<internal>",
                        "",
                        "runner-error",
                        None,
                        0.0,
                        "",
                        "",
                        None,
                        None,
                        None,
                        None,
                        None,
                        None,
                        repr(exc),
                    )
                results.append(result)
                counts[result.status] = counts.get(result.status, 0) + 1
                results_file.write(json.dumps(result.__dict__, sort_keys=True) + "\n")
                results_file.flush()
                elapsed = time.monotonic() - started
                rate = index / elapsed if elapsed > 0 else 0.0
                remaining = (len(candidates) - index) / rate if rate > 0 else 0.0
                print(
                    f"[{index}/{len(candidates)}] {result.status}"
                    f"{' ' + result.decision if result.decision else ''}"
                    f" {result.benchmark_key} elapsed={result.elapsed_seconds:.1f}s"
                    f" totals={counts} eta={remaining:.0f}s",
                    flush=True,
                )

    inserted = 0 if args.no_db_insert else insert_results(args.db, results)
    summary = {
        "finished_at": time.time(),
        "elapsed_seconds": time.monotonic() - started,
        "counts": counts,
        "inserted": inserted,
        "candidate_count": len(candidates),
    }
    (run_dir / "summary.json").write_text(json.dumps(summary, indent=2, sort_keys=True), encoding="utf-8")
    print(json.dumps(summary, indent=2, sort_keys=True), flush=True)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
