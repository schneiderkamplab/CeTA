#!/usr/bin/env python3
"""Compare independent-action audits without treating open actions as solves."""
import argparse
from collections import Counter
import json
from pathlib import Path


def compare(previous, current):
    old = {row['index']: row for row in previous}
    totals = Counter()
    report = dict(actions=len(current), totals={}, gains=[], losses=[],
                  uncertified_terminals=[], renaming_differences=[],
                  uncovered=[], identity_mismatches=[], missing_indices=[],
                  missing_variants=[])
    seen = set()
    for row in current:
        index = row['index']
        if index in seen:
            raise ValueError(f'duplicate action index {index}')
        seen.add(index)
        before = old.get(index)
        if before and any(row.get(key) != before.get(key)
                          for key in ('problem_key', 'family', 'source_events')):
            report['identity_mismatches'].append(index)
            continue
        prior = {r['variant']: r for r in before['results']} if before else {}
        results = row['results']
        present = {r['variant'] for r in results}
        if len(present) != len(results):
            raise ValueError(f'duplicate variant for action {index}')
        report['missing_variants'].extend([index, v] for v in sorted(set(prior) - present))
        if not row['rename_supported']:
            report['uncovered'].append(index)
        for result in results:
            variant = result['variant']
            certified = result.get('certified', False)
            totals[f"{result.get('outcome', result.get('error', 'error'))}:{certified}"] += 1
            identity = [index, variant]
            if certified and not prior.get(variant, {}).get('certified'):
                report['gains'].append(identity)
            if not certified and prior.get(variant, {}).get('certified'):
                report['losses'].append(identity)
            if result.get('outcome') == 'solved' and not certified:
                report['uncertified_terminals'].append(identity)
        fields = ('outcome', 'typed_outcome', 'children', 'certified', 'error')
        if len(results) == 2 and any(results[0].get(k) != results[1].get(k) for k in fields):
            report['renaming_differences'].append(index)
    report['totals'] = dict(totals)
    report['missing_indices'] = sorted(set(old) - seen)
    return report


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--baseline', type=Path, required=True)
    parser.add_argument('--current', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    def read(path):
        with path.open() as stream:
            return [json.loads(line) for line in stream if line.strip()]
    report = compare(read(args.baseline), read(args.current))
    with args.output.open('x') as stream:
        json.dump(report, stream, indent=2)
        stream.write('\n')
    print(json.dumps(report, indent=2))


if __name__ == '__main__':
    main()
