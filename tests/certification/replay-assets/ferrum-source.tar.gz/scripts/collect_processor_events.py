#!/usr/bin/env python3
"""Collect Ferrum processor-event logs with per-example process isolation.

This runner avoids the memory-retention failure mode of in-process `tpdb prove`:
each benchmark is proved by a separate `ferrum prove` process with its own event
file. Event files are merged only after all workers finish, so large JSONL rows
cannot interleave across processes.
"""

from __future__ import annotations

import argparse
import concurrent.futures
import json
import os
from pathlib import Path
import random
import signal
import subprocess
import sys
import threading
import time


def mem_used_kb() -> int:
    total = available = None
    with open("/proc/meminfo", encoding="utf-8") as handle:
        for line in handle:
            if line.startswith("MemTotal:"):
                total = int(line.split()[1])
            elif line.startswith("MemAvailable:"):
                available = int(line.split()[1])
    if total is None or available is None:
        return 0
    return total - available


def discover_inputs(root: Path) -> list[Path]:
    inputs: list[Path] = []
    for path in sorted(root.rglob("*")):
        if path.suffix != ".ari":
            continue
        try:
            text = path.read_text(encoding="utf-8", errors="ignore")
        except OSError:
            continue
        if any(
            marker in text
            for marker in ("(format TRS)", "(format CSTRS)", "(format SRS)")
        ):
            inputs.append(path)
    return inputs


def normalized_detail_status(row: dict[str, object]) -> str:
    """Map both collector and TermCOMP detail rows to selection statuses."""
    status = str(row.get("status", "unknown")).strip().lower()
    outcome = str(row.get("outcome", "")).strip().lower()
    if status in {"terminating", "yes"}:
        return "yes"
    if status in {"nonterminating", "no"}:
        return "no"
    if outcome == "timeout" or status == "timeout":
        return "timeout"
    if outcome in {"nonzero", "memory-threshold", "cancelled", "error"}:
        return "error"
    return "unknown"


def selected_detail_paths(
    details_paths: list[Path], statuses: set[str]
) -> set[Path]:
    selected: set[Path] = set()
    for details_path in details_paths:
        text = details_path.read_text(encoding="utf-8")
        try:
            value = json.loads(text)
        except json.JSONDecodeError:
            value = [
                json.loads(line)
                for line in text.splitlines()
                if line.strip()
            ]
        if not isinstance(value, list):
            raise ValueError(f"details JSON must contain a list: {details_path}")
        for row in value:
            if not isinstance(row, dict) or normalized_detail_status(row) not in statuses:
                continue
            raw_path = row.get("path")
            if isinstance(raw_path, str):
                path = Path(raw_path)
                if not path.is_absolute():
                    # TermCOMP details paths are normally relative to the
                    # working directory in which the campaign is resumed.
                    path = Path.cwd() / path
                selected.add(path.resolve())
    return selected


def safe_problem_id(root: Path, path: Path) -> str:
    rel = path.relative_to(root)
    return "__".join((root.name, *rel.with_suffix("").parts))


def write_json_atomic(path: Path, value: object) -> None:
    temporary = path.with_suffix(path.suffix + ".tmp")
    temporary.write_text(json.dumps(value, sort_keys=True) + "\n", encoding="utf-8")
    temporary.replace(path)


def terminate_group(process: subprocess.Popen[bytes]) -> None:
    try:
        os.killpg(process.pid, signal.SIGTERM)
    except ProcessLookupError:
        return
    except OSError:
        pass
    deadline = time.monotonic() + 5
    while time.monotonic() < deadline:
        if process.poll() is not None:
            return
        time.sleep(0.1)
    try:
        os.killpg(process.pid, signal.SIGKILL)
    except OSError:
        pass


def terminate_active_processes(
    active_processes: dict[int, subprocess.Popen[bytes]], active_lock: threading.Lock
) -> None:
    with active_lock:
        processes = list(active_processes.values())
    for process in processes:
        if process.poll() is None:
            try:
                os.killpg(process.pid, signal.SIGTERM)
            except (ProcessLookupError, OSError):
                pass
    deadline = time.monotonic() + 5
    while time.monotonic() < deadline:
        if all(process.poll() is not None for process in processes):
            return
        time.sleep(0.1)
    for process in processes:
        if process.poll() is None:
            try:
                os.killpg(process.pid, signal.SIGKILL)
            except (ProcessLookupError, OSError):
                pass


def run_one(
    ferrum: Path,
    category_root: Path,
    path: Path,
    run_id: str,
    per_problem_dir: Path,
    timeout_s: float,
    prover_timeout_s: float,
    memory_threshold_kb: int,
    rayon_threads: int,
    utility_guidance_manifest: Path | None,
    strategy: str | None,
    dp_guidance_no_fallback: bool,
    timeout_multiplier: float,
    ceta: Path | None,
    ceta_timeout_s: float,
    stop_event: threading.Event,
    active_processes: dict[int, subprocess.Popen[bytes]],
    active_lock: threading.Lock,
) -> dict[str, object]:
    problem_id = safe_problem_id(category_root, path)
    event_path = per_problem_dir / f"{problem_id}.processor-events.jsonl"
    stdout_path = per_problem_dir / f"{problem_id}.stdout.log"
    stderr_path = per_problem_dir / f"{problem_id}.stderr.log"
    result_path = per_problem_dir / f"{problem_id}.result.json"
    cpf_path = per_problem_dir / f"{problem_id}.cpf.xml"
    ceta_stdout_path = per_problem_dir / f"{problem_id}.ceta.stdout.log"
    ceta_stderr_path = per_problem_dir / f"{problem_id}.ceta.stderr.log"
    # A missing result row means an earlier isolated attempt did not commit.
    # Discard all of its partial artifacts before retrying so proof-path credit
    # never joins a cancelled prefix with the subsequent complete attempt.
    for partial_path in (
        event_path,
        stdout_path,
        stderr_path,
        result_path,
        cpf_path,
        ceta_stdout_path,
        ceta_stderr_path,
    ):
        partial_path.unlink(missing_ok=True)
    env = os.environ.copy()
    env["FERRUM_PROCESSOR_EVENT_RUN_ID"] = run_id
    env["RAYON_NUM_THREADS"] = str(max(1, rayon_threads))
    if dp_guidance_no_fallback:
        env["FERRUM_DP_LLM_NO_FALLBACK"] = "1"
    started = time.monotonic()
    if stop_event.is_set():
        return {
            "problem_id": str(path.relative_to(category_root)),
            "path": str(path),
            "outcome": "cancelled",
            "return_code": None,
            "status": "unknown",
            "elapsed_ms": 0,
            "event_path": str(event_path),
            "event_bytes": 0,
        }
    with stdout_path.open("wb") as stdout, stderr_path.open("wb") as stderr:
        effective_strategy = strategy or f"timeout({prover_timeout_s:g}s, default)"
        command = [
            str(ferrum),
            "prove",
            str(path),
            "--processor-events",
            str(event_path),
            "--timeout-multiplier",
            str(timeout_multiplier),
            "--cpf",
            str(cpf_path),
        "--cpf-mode",
        "auto",
        "--strategy",
        effective_strategy,
        ]
        if utility_guidance_manifest is not None:
            command.extend(
                ["--utility-guidance-manifest", str(utility_guidance_manifest)]
            )
        process = subprocess.Popen(
            command,
            stdout=stdout,
            stderr=stderr,
            env=env,
            start_new_session=True,
        )
        with active_lock:
            active_processes[process.pid] = process
        outcome = "finished"
        try:
            while process.poll() is None:
                if stop_event.is_set():
                    outcome = "cancelled"
                    terminate_group(process)
                    break
                if time.monotonic() - started > timeout_s:
                    outcome = "timeout"
                    terminate_group(process)
                    break
                if mem_used_kb() > memory_threshold_kb:
                    outcome = "memory-threshold"
                    stop_event.set()
                    terminate_group(process)
                    break
                time.sleep(0.5)
        finally:
            with active_lock:
                active_processes.pop(process.pid, None)
    return_code = process.poll()
    elapsed_ms = int((time.monotonic() - started) * 1000)
    event_bytes = event_path.stat().st_size if event_path.exists() else 0
    status = "unknown"
    try:
        with stdout_path.open("r", encoding="utf-8", errors="ignore") as stdout:
            for line in stdout:
                if line.startswith("status: "):
                    status = line.split("status: ", 1)[1].strip()
                    break
    except OSError:
        pass
    if outcome == "finished" and return_code == 0:
        outcome = "ok"
    elif outcome == "finished":
        outcome = "nonzero"
    certified = False
    ceta_return_code: int | None = None
    ceta_timed_out = False
    if (
        ceta is not None
        and status in {"Terminating", "Nonterminating"}
        and cpf_path.exists()
    ):
        checker = subprocess.Popen(
            [str(ceta), str(cpf_path)],
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            start_new_session=True,
        )
        try:
            ceta_stdout, ceta_stderr = checker.communicate(timeout=ceta_timeout_s)
        except subprocess.TimeoutExpired:
            ceta_timed_out = True
            terminate_group(checker)
            ceta_stdout, ceta_stderr = checker.communicate()
        ceta_return_code = checker.returncode
        ceta_stdout_path.write_bytes(ceta_stdout)
        ceta_stderr_path.write_bytes(ceta_stderr)
        certified = (
            not ceta_timed_out
            and ceta_return_code == 0
            and b"CERTIFIED" in ceta_stdout.upper()
        )
    row = {
        "category": category_root.name,
        "problem_id": str(path.relative_to(category_root)),
        "path": str(path),
        "outcome": outcome,
        "return_code": return_code,
        "status": status,
        "elapsed_ms": elapsed_ms,
        "event_path": str(event_path),
        "event_bytes": event_bytes,
        "cpf_path": str(cpf_path),
        "cpf_bytes": cpf_path.stat().st_size if cpf_path.exists() else 0,
        "certified": certified,
        "ceta_return_code": ceta_return_code,
        "ceta_timed_out": ceta_timed_out,
    }
    if outcome == "cancelled":
        result_path.unlink(missing_ok=True)
    else:
        write_json_atomic(result_path, row)
    return row


def merge_events(per_problem_dir: Path, merged_path: Path) -> int:
    rows = 0
    with merged_path.open("wb") as output:
        for path in sorted(per_problem_dir.glob("*.processor-events.jsonl")):
            with path.open("rb") as handle:
                for line in handle:
                    output.write(line)
                    rows += 1
    return rows


def load_completed(per_problem_dir: Path) -> dict[str, dict[str, object]]:
    completed: dict[str, dict[str, object]] = {}
    for path in sorted(per_problem_dir.glob("*.result.json")):
        try:
            row = json.loads(path.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError):
            continue
        problem_path = row.get("path")
        if isinstance(problem_path, str) and row.get("outcome") != "cancelled":
            completed[problem_path] = row
    return completed


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--ferrum", type=Path, default=Path("target/release/ferrum"))
    parser.add_argument("--category-root", type=Path, action="append", required=True)
    parser.add_argument("--run-dir", type=Path, required=True)
    parser.add_argument("--jobs", type=int, default=8)
    parser.add_argument("--rayon-threads", type=int, default=8)
    parser.add_argument("--limit", type=int)
    parser.add_argument(
        "--from-details",
        type=Path,
        action="append",
        default=[],
        help="select roots from a prior details JSON file; may be repeated",
    )
    parser.add_argument(
        "--include-status",
        action="append",
        choices=("yes", "no", "unknown", "timeout", "error"),
        help=(
            "status selected from --from-details; repeat as needed "
            "(default: unknown, timeout, error)"
        ),
    )
    parser.add_argument("--timeout", type=float, default=300.0)
    parser.add_argument(
        "--prover-timeout",
        type=float,
        default=300.0,
        help="Ferrum strategy ceiling inside the outer harness timeout",
    )
    parser.add_argument("--timeout-multiplier", type=float, default=1.0)
    parser.add_argument("--utility-guidance-manifest", type=Path)
    parser.add_argument(
        "--strategy",
        help=(
            "exact Ferrum strategy; defaults to timeout(PROVER_TIMEOUT, default). "
            "Use timeout(..., fail) with --dp-guidance-no-fallback for a strict "
            "oracle-only replay"
        ),
    )
    parser.add_argument(
        "--dp-guidance-no-fallback",
        action="store_true",
        help="set FERRUM_DP_LLM_NO_FALLBACK=1 in every isolated prover",
    )
    parser.add_argument("--ceta", type=Path)
    parser.add_argument("--ceta-timeout", type=float, default=60.0)
    parser.add_argument("--seed", type=int, default=0)
    parser.add_argument("--memory-threshold-kb", type=int, default=2 * 1024 * 1024 * 1024)
    parser.add_argument("--progress-every", type=int, default=5)
    args = parser.parse_args()
    if (
        args.jobs < 1
        or args.jobs > 64
        or args.rayon_threads < 1
        or args.jobs * args.rayon_threads > 128
    ):
        parser.error("jobs must be 1..64 and jobs * rayon-threads must be at most 128")
    if args.timeout_multiplier <= 0:
        parser.error("--timeout-multiplier must be positive")
    if args.prover_timeout <= 0 or args.prover_timeout > args.timeout:
        parser.error("--prover-timeout must be positive and no greater than --timeout")

    args.run_dir.mkdir(parents=True, exist_ok=True)
    per_problem_dir = args.run_dir / "per-problem"
    per_problem_dir.mkdir(exist_ok=True)
    summary_path = args.run_dir / "summary.jsonl"
    merged_path = args.run_dir / "all.processor-events.jsonl"
    run_id = str(args.run_dir.resolve())
    tasks = [
        (root, path)
        for root in args.category_root
        for path in discover_inputs(root)
    ]
    if args.from_details:
        statuses = set(args.include_status or ("unknown", "timeout", "error"))
        try:
            selected_paths = selected_detail_paths(args.from_details, statuses)
        except (OSError, json.JSONDecodeError, ValueError) as error:
            parser.error(str(error))
        tasks = [
            (root, path) for root, path in tasks if path.resolve() in selected_paths
        ]
    random.Random(args.seed).shuffle(tasks)
    if args.limit is not None:
        tasks = tasks[: args.limit]
    previous = load_completed(per_problem_dir)
    pending = [
        task for task in tasks if str(task[1]) not in previous
    ]
    started = time.monotonic()
    existing_rows = [previous[str(path)] for _root, path in tasks if str(path) in previous]
    completed = len(existing_rows)
    proved = sum(row.get("status") == "Terminating" for row in existing_rows)
    disproved = sum(row.get("status") == "Nonterminating" for row in existing_rows)
    timed_out = sum(row.get("outcome") == "timeout" for row in existing_rows)
    memory_stopped = sum(row.get("outcome") == "memory-threshold" for row in existing_rows)
    failed = sum(
        row.get("outcome") not in {"ok", "nonzero", "cancelled", "timeout"}
        for row in existing_rows
    )
    stop_event = threading.Event()
    active_lock = threading.Lock()
    active_processes: dict[int, subprocess.Popen[bytes]] = {}
    previous_signal_handlers: dict[int, object] = {}

    def request_stop(_signum: int, _frame: object) -> None:
        stop_event.set()
        terminate_active_processes(active_processes, active_lock)

    for signum in (signal.SIGINT, signal.SIGTERM):
        previous_signal_handlers[signum] = signal.getsignal(signum)
        signal.signal(signum, request_stop)
    print(
        f"isolated-events-start categories={','.join(root.name for root in args.category_root)} "
        f"selected={len(tasks)} resumed={completed} pending={len(pending)} "
        f"jobs={args.jobs} timeout={args.timeout}s multiplier={args.timeout_multiplier} "
        f"oracle={args.utility_guidance_manifest or 'none'} run_id={run_id}",
        file=sys.stderr,
        flush=True,
    )
    try:
        with summary_path.open("a", encoding="utf-8") as summary:
            with concurrent.futures.ThreadPoolExecutor(max_workers=max(1, args.jobs)) as executor:
                futures = set()
                input_iter = iter(pending)
                while len(futures) < max(1, args.jobs):
                    try:
                        category_root, path = next(input_iter)
                    except StopIteration:
                        break
                    futures.add(
                        executor.submit(
                            run_one,
                            args.ferrum,
                            category_root,
                            path,
                            run_id,
                            per_problem_dir,
                            args.timeout,
                            args.prover_timeout,
                            args.memory_threshold_kb,
                            args.rayon_threads,
                            args.utility_guidance_manifest,
                            args.strategy,
                            args.dp_guidance_no_fallback,
                            args.timeout_multiplier,
                            args.ceta,
                            args.ceta_timeout,
                            stop_event,
                            active_processes,
                            active_lock,
                        )
                    )
                while futures:
                    done, futures = concurrent.futures.wait(
                        futures, return_when=concurrent.futures.FIRST_COMPLETED
                    )
                    for future in done:
                        row = future.result()
                        completed += 1
                        if row["status"] == "Terminating":
                            proved += 1
                        elif row["status"] == "Nonterminating":
                            disproved += 1
                        if row["outcome"] == "timeout":
                            timed_out += 1
                        elif row["outcome"] == "memory-threshold":
                            memory_stopped += 1
                        elif row["outcome"] not in {"ok", "nonzero", "cancelled"}:
                            failed += 1
                        summary.write(json.dumps(row, sort_keys=True) + "\n")
                        summary.flush()
                        if (
                            completed == len(tasks)
                            or (args.progress_every > 0 and completed % args.progress_every == 0)
                            or row["outcome"] == "memory-threshold"
                        ):
                            elapsed = time.monotonic() - started
                            newly_completed = completed - len(existing_rows)
                            eta = (
                                0
                                if newly_completed == 0
                                else elapsed
                                * (len(tasks) - completed)
                                / newly_completed
                            )
                            print(
                                "isolated-events-progress "
                                f"completed={completed}/{len(tasks)} yes={proved} no={disproved} "
                                f"timeouts={timed_out} memory_stopped={memory_stopped} "
                                f"used_kb={mem_used_kb()} elapsed={elapsed:.1f}s eta={eta:.1f}s",
                                file=sys.stderr,
                                flush=True,
                            )
                        if row["outcome"] == "memory-threshold":
                            print("isolated-events-abort reason=memory-threshold", file=sys.stderr, flush=True)
                            terminate_active_processes(active_processes, active_lock)
                            executor.shutdown(wait=True, cancel_futures=True)
                            return 99
                    while not stop_event.is_set() and len(futures) < max(1, args.jobs):
                        try:
                            category_root, path = next(input_iter)
                        except StopIteration:
                            break
                        futures.add(
                            executor.submit(
                                run_one,
                                args.ferrum,
                                category_root,
                                path,
                                run_id,
                                per_problem_dir,
                                args.timeout,
                                args.prover_timeout,
                                args.memory_threshold_kb,
                            args.rayon_threads,
                            args.utility_guidance_manifest,
                            args.strategy,
                            args.dp_guidance_no_fallback,
                            args.timeout_multiplier,
                                args.ceta,
                                args.ceta_timeout,
                                stop_event,
                                active_processes,
                                active_lock,
                            )
                        )
    finally:
        stop_event.set()
        terminate_active_processes(active_processes, active_lock)
        for signum, handler in previous_signal_handlers.items():
            signal.signal(signum, handler)
    rows = merge_events(per_problem_dir, merged_path)
    result_rows = load_completed(per_problem_dir)
    with summary_path.open("w", encoding="utf-8") as summary:
        for row in sorted(result_rows.values(), key=lambda item: str(item["path"])):
            summary.write(json.dumps(row, sort_keys=True) + "\n")
    elapsed = time.monotonic() - started
    print(
        f"isolated-events-finish completed={completed} yes={proved} no={disproved} "
        f"timeouts={timed_out} failed={failed} rows={rows} elapsed={elapsed:.1f}s",
        file=sys.stderr,
        flush=True,
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
