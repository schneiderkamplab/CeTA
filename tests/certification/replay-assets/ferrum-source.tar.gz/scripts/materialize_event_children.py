"""Materialize exact typed event children for independent exploration, without credit."""
import argparse
import hashlib
import json
from pathlib import Path
import xml.etree.ElementTree as ET


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--events', type=Path, required=True)
    p.add_argument('--problem', required=True)
    p.add_argument('--output', type=Path, required=True)
    p.add_argument('--include-unguided', action='store_true',
                   help='include uncredited children rejected only for missing oracle guidance')
    args = p.parse_args()
    args.output.mkdir()
    rows = {}
    for event in map(json.loads, args.events.read_text().splitlines()):
        eligible = event.get('outcome') == 'transformed' or (
            args.include_unguided and event.get('outcome') == 'failed' and
            event.get('failure_reason') == 'strict oracle transformation produced an unguided residual')
        if event.get('problem_id') != args.problem or not eligible:
            continue
        for child in (event.get('witness') or {}).get('residuals', []):
            cpf, key = child['cpf'], child['problem_key']
            if hashlib.sha256(cpf.strip().encode()).hexdigest() != key:
                raise ValueError('child digest mismatch')
            ET.fromstring(cpf)
            origin = dict(source_events=str(args.events), processor=event['processor'],
                          parent=event['input']['problem_key'])
            if key in rows:
                if origin not in rows[key]['origins']:
                    rows[key]['origins'].append(origin)
                continue
            path = args.output / f'{key}.cpf'
            path.write_text(cpf)
            rows[key] = dict(input=str(path.resolve()), sha256=key, certified=False,
                             origins=[origin])
    (args.output / 'inventory.json').write_text(json.dumps(dict(records=list(rows.values()))))
    with (args.output / 'untried.jsonl').open('x') as out, (args.output / 'inputs.txt').open('x') as inputs:
        for row in rows.values():
            print(json.dumps(row), file=out)
            print(row['input'], file=inputs)
    print(json.dumps(dict(children=len(rows), credit='none')))


if __name__ == '__main__':
    main()
