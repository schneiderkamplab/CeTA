#!/usr/bin/env python3
"""Export local extracted actions gated by twice-checked source-proof manifests."""
import argparse
import collections
import hashlib
import json
from pathlib import Path
from merge_monotone_oracle_records import merge_bucket, metadata_key, normalize_record_buckets

RETIRED_COMPOSITES = ('exact-trs-proof(', 'exact-dp-proof(',
                      'exact-trs-nontermination-proof(', 'exact-dp-nontermination-proof(')


def retain_tested_guidance(extracted, guidance):
    """Preserve live state keys without upgrading weak exploration evidence.

    CPF extraction can omit execution-only context aliases. Its checked rows
    supplement, rather than replace, the modular oracle used by the replay.
    """
    metadata, states = {}, {}
    for row in [*guidance, *extracted]:
        for atom in [row.get('candidate', '')] + [
            item.get('candidate', '') for bucket in ('prefer', 'possible', 'avoid', 'timeout')
            for item in row.get(bucket, [])
        ]:
            if atom.startswith(RETIRED_COMPOSITES):
                raise ValueError('complete proof in tested guidance')
        key = row.get('problem_key')
        if key is None:
            identity = metadata_key(row)
            if identity in metadata and metadata[identity] != row:
                raise ValueError('conflicting tested witness metadata')
            metadata[identity] = row
        elif key not in states:
            states[key] = dict(row)
        else:
            for bucket in ('prefer', 'possible', 'avoid', 'timeout'):
                states[key][bucket] = merge_bucket(states[key].get(bucket, []), row.get(bucket, []))
    for row in states.values():
        normalize_record_buckets(row)
    return [*metadata.values(), *states.values()]


def attach_replay_order(rows, events):
    """Order existing positives; never import or certify an action this way."""
    orders = collections.defaultdict(list)
    for event in events:
        if event.get('outcome') not in ('transformed', 'solved'):
            continue
        atom, key = event.get('strategy_atom'), event.get('input', {}).get('problem_key')
        if isinstance(atom, str) and isinstance(key, str):
            digest = hashlib.sha256(atom.encode()).hexdigest()
            if digest not in orders[key]:
                orders[key].append(digest)
    for row in rows:
        if row.get('problem_key') in orders:
            row['replay_order'] = orders[row['problem_key']]


def build(events, manifest):
    gates = {(r['problem_key'], r['candidate']) for r in manifest
             if r.get('recheck_status') == 'certified' and r.get('deterministic_rechecks', 0) >= 2}
    states = collections.defaultdict(dict)
    witnesses = {}
    for event in events:
        key = event.get('input', {}).get('problem_key')
        atom = event.get('strategy_atom', '')
        if (key, atom) not in gates:
            continue
        if atom.startswith(RETIRED_COMPOSITES):
            raise ValueError('complete proof in modular extraction')
        outcome = event.get('outcome')
        if outcome not in ('solved', 'transformed'):
            continue
        status = 'solved' if outcome == 'solved' else 'transformed_strong'
        if atom.startswith('exact-'):
            reference = hashlib.sha256(atom.encode()).hexdigest()
            witnesses[reference] = atom
            candidate = {'candidate_ref': reference}
        else:
            candidate = {'candidate': atom}
        states[key][atom] = dict(candidate, status=status, utility_score=2000,
                                attempts=1, certified_count=1, best_elapsed_ms=0,
                                failed_count=0, timeout_count=0,
                                solved_count=int(outcome == 'solved'),
                                transformed_count=int(outcome == 'transformed'))
    rows = [{'schema': 'ferrum.utility-guidance.witness.v1',
             'witness_id': key, 'candidate': atom} for key, atom in sorted(witnesses.items())]
    rows += [{'schema': 'ferrum.utility-guidance.v2', 'problem_key': key,
              'prefer': list(atoms.values()), 'possible': [], 'avoid': [], 'timeout': [],
              'replay_order': [hashlib.sha256(atom.encode()).hexdigest() for atom in atoms]}
             for key, atoms in sorted(states.items())]
    return rows


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--events', type=Path)
    p.add_argument('--manifest', type=Path)
    p.add_argument('--shards', type=Path, action='append')
    p.add_argument('--output', type=Path, required=True)
    args = p.parse_args()
    if args.shards:
        completed = [json.loads(line) for shard in args.shards
                     for line in (shard / 'results.jsonl').read_text().splitlines()]
        directories = [Path(r['output']) for r in completed if r['returncode'] == 0]
        def records(filename):
            for directory in directories:
                with (directory / filename).open() as stream:
                    yield from map(json.loads, stream)
        rows = build(records('events.jsonl'), records('manifest.jsonl'))
        guidance = []
        for result in completed:
            if result['returncode'] != 0 or not result.get('tested_guidance'):
                continue
            path = Path(result['tested_guidance'])
            data = path.read_bytes()
            if hashlib.sha256(data).hexdigest() != result['tested_guidance_sha256']:
                raise ValueError(f'tested guidance changed: {path}')
            guidance.extend(map(json.loads, data.splitlines()))
        rows = retain_tested_guidance(rows, guidance)
        for result in completed:
            if result['returncode'] != 0 or not result.get('tested_events'):
                continue
            path = Path(result['tested_events'])
            data = path.read_bytes()
            if hashlib.sha256(data).hexdigest() != result['tested_events_sha256']:
                raise ValueError(f'tested events changed: {path}')
            attach_replay_order(rows, map(json.loads, data.splitlines()))
    else:
        if not args.events or not args.manifest:
            p.error('supply --shards or both --events and --manifest')
        with args.events.open() as events, args.manifest.open() as manifest:
            rows = build(map(json.loads, events), map(json.loads, manifest))
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with args.output.open('x') as output:
        for row in rows:
            print(json.dumps(row, separators=(',', ':')), file=output)
    print(json.dumps({'records': len(rows), 'output': str(args.output)}))


if __name__ == '__main__':
    main()
