#!/usr/bin/env python3
"""Inventory processor positions in retained CPF trees, with exact origins.

This is a vocabulary inventory, not an assertion that each tag has a sound
standalone implementation. Side-condition proof syntax is intentionally not
classified as a processor.
"""
import argparse
from collections import Counter, defaultdict
import json
from pathlib import Path
import xml.etree.ElementTree as ET

PROOF_CONTAINERS = {
    'trsTerminationProof', 'trsNonterminationProof', 'dpProof',
    'dpNonterminationProof', 'csrTerminationProof', 'csrDpProof',
    'mutermTypedDpProof', 'sourceProof', 'administrativeProof',
    'transformedProof', 'ordinaryDpProof', 'relativeTerminationProof',
    'relativeNonterminationProof', 'csrGuardedTerminationProof',
}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--root', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    counts, origins, failures = Counter(), defaultdict(set), []
    scanned = 0
    for path in args.root.rglob('proof.cpf.xml'):
        try:
            tree = ET.parse(path)
        except ET.ParseError as error:
            failures.append({'path': str(path), 'error': str(error)})
            continue
        scanned += 1
        for parent in tree.iter():
            if parent.tag.rsplit('}', 1)[-1] not in PROOF_CONTAINERS:
                continue
            for child in parent:
                tag = child.tag.rsplit('}', 1)[-1]
                if tag in PROOF_CONTAINERS:
                    continue
                counts[tag] += 1
                origins[tag].add(str(path))
    with args.output.open('x') as stream:
        json.dump({'proofs_scanned': scanned, 'parse_failures': failures,
                   'processors': {tag: {'occurrences': count, 'roots': sorted(origins[tag])}
                                  for tag, count in counts.most_common()}}, stream, indent=2)
    print(json.dumps({'proofs_scanned': scanned, 'parse_failures': len(failures),
                      'processor_tags': len(counts), 'counts': counts}))


if __name__ == '__main__':
    main()
