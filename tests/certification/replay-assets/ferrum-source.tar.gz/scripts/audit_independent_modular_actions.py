#!/usr/bin/env python3
"""Replay saved runtime actions without root history or an oracle.

Open transformations are reported as open, never promoted to certified solves.
Actions additionally receive an injective XML symbol renaming where their typed
witness transport is implemented. Others are explicitly reported as uncovered.
"""
import argparse
from concurrent.futures import ThreadPoolExecutor, as_completed
import hashlib
import json
import os
import re
from pathlib import Path
import subprocess
import time
import xml.etree.ElementTree as ET


def xml_tree(cpf):
    try:
        return ET.fromstring(cpf), False
    except ET.ParseError:
        return ET.fromstring('<auditFragment>' + cpf + '</auditFragment>'), True


def rename_input(cpf, mapping=None, varmap=None):
    root, fragment = xml_tree(cpf)
    names = sorted({n.text for n in root.iter() if n.tag == 'name' and n.text})
    variables = sorted({n.text for n in root.iter() if n.tag == 'var' and n.text})
    mapping = mapping if mapping is not None else {s: f'audit_symbol_{i}' for i, s in enumerate(names)}
    varmap = varmap if varmap is not None else {s: f'audit_variable_{i}' for i, s in enumerate(variables)}
    for node in root.iter():
        if node.tag == 'name' and node.text in mapping:
            node.text = mapping[node.text]
        elif node.tag == 'var' and node.text in varmap:
            node.text = varmap[node.text]
    return (''.join(ET.tostring(child, encoding='unicode') for child in root)
            if fragment else ET.tostring(root, encoding='unicode'))


def imported_symbol_aliases(cpf):
    """Mirror the CPF importer's structural fresh-wrapper normalization.

    XML names still receive the full bijection. Only runtime witness names
    use this map: the importer normalizes the unique fresh frozen unary
    wrapper in improved CSR problems to its internal fresh symbol.
    """
    root, _ = xml_tree(cpf)
    if root.findtext('./ferrumCsrDpContext/construction') != 'improved':
        return {}
    source = root.find('./trs')
    if source is None:
        return {}
    names = {n.text for n in source.iter('name')}
    entries = root.findall('./strategy/contextSensitive/replacementMapEntry')
    unknown = [entry for entry in entries
               if entry.findtext('name') not in names]
    if len(unknown) != 1:
        return {}
    entry = unknown[0]
    alias = entry.findtext('name')
    if alias is None or entry.findtext('arity') != '1' or entry.findall('position'):
        return {}
    occurrences = [term for term in root.findall('./dps/rules/rule//funapp')
                   if term.findtext('name') == alias]
    if not occurrences or any(len(term) != 2 for term in occurrences):
        return {}
    index = 0
    while f'__CSR_U{index}' in names:
        index += 1
    return {alias: f'__CSR_U{index}'}


def cpf_runtime_symbol(node):
    """Decode typed CPF symbol roles exactly as the native CPF importer does."""
    if node.tag == 'name':
        return node.text or ''
    if node.tag not in ('sharp', 'labeledSymbol'):
        raise ValueError('not a CPF symbol')
    base = next(child for child in node if child.tag in ('name', 'sharp', 'labeledSymbol'))
    base = cpf_runtime_symbol(base)
    if node.tag == 'sharp':
        return base + '#'
    labels = node.find('symbolLabel')
    if labels is not None:
        suffix = '_'.join(cpf_runtime_symbol(child).encode().hex() for child in labels)
        return '__ferrum_rl__' + base.encode().hex() + '__' + suffix
    suffix = '_'.join(child.text or '' for child in node.iter('number'))
    return '__ferrum_sl__' + base.encode().hex() + '__' + suffix


def renamed_action(cpf, atom):
    """Transport only explicitly understood witness schemas, never arbitrary JSON."""
    families = ('graph', 'matrix', 'poly', 'poly-removal', 'dp', 'dp-transform',
                'usable-rules', 'red-pair', 'size-change', 'innermost-lhss',
                'innermost-lhss-dp', 'dp-no-rule-removal', 'trs-no-rule-removal',
                'dp-loop', 'dp-nonloop', 'general-red-pair', 'split', 'subterm',
                'mono-poly', 'weak-poly', 'max-poly', 'arctic', 'rat-natural-poly',
                'path-order', 'path-order-removal', 'kbo', 'semantic-labeling')
    match = re.fullmatch(r'(exact-(?:' + '|'.join(families) + r'))\(hex=([0-9a-f]+)(?:,\s*source-hex=([0-9a-f]+))?\)', atom)
    if not match:
        return (rename_input(cpf), atom) if 'exact-' not in atom and 'hex=' not in atom else None
    family, encoded, source_encoded = match.groups()
    if source_encoded is not None and family != 'exact-path-order-removal':
        return None
    source_xml = bytes.fromhex(source_encoded).decode() if source_encoded is not None else None
    payload = json.loads(bytes.fromhex(encoded))
    model_only = family in {
        'exact-matrix', 'exact-poly', 'exact-poly-removal', 'exact-subterm',
        'exact-mono-poly', 'exact-weak-poly', 'exact-max-poly', 'exact-arctic',
        'exact-rat-natural-poly', 'exact-path-order', 'exact-path-order-removal', 'exact-kbo',
    }
    xmls = [cpf]
    if source_xml is not None:
        xmls.append(source_xml)
    def xml_leaves(value):
        if isinstance(value, str) and value.lstrip().startswith('<'):
            yield value
        elif isinstance(value, list):
            for item in value:
                yield from xml_leaves(item)
    if not model_only:
        xmls.extend(xml_leaves(payload))
    trees = [xml_tree(xml)[0] for xml in xmls]
    names = sorted({n.text for root in trees for n in root.iter() if n.tag == 'name' and n.text})
    variables = sorted({n.text for root in trees for n in root.iter() if n.tag == 'var' and n.text})
    input_names = {n.text for n in trees[0].iter() if n.tag == 'name' and n.text}
    def representative(name):
        # Ferrum accepts the unambiguous CPF numeric-symbol alias 0 <-> |0|.
        # A witness may use the other spelling from its live input. Do not
        # turn that alias into two different functions during the audit.
        if name.isdecimal() and name not in input_names and f'|{name}|' in input_names:
            return f'|{name}|'
        if name.startswith('|') and name.endswith('|') and name[1:-1].isdecimal():
            if name not in input_names and name[1:-1] in input_names:
                return name[1:-1]
        return name
    representatives = {name: f'audit_symbol_{i}' for i, name in
                       enumerate(sorted({representative(name) for name in names}))}
    mapping = {name: representatives[representative(name)] for name in names}
    varmap = {s: f'audit_variable_{i}' for i, s in enumerate(variables)}
    def transport_xml(value):
        if isinstance(value, str) and value.lstrip().startswith('<'):
            return rename_input(value, mapping, varmap)
        if isinstance(value, list):
            return [transport_xml(item) for item in value]
        return value
    if not model_only:
        payload = transport_xml(payload)
    runtime_aliases = imported_symbol_aliases(rename_input(cpf, mapping, varmap))
    typed_mapping = {}
    for xml, original in zip(xmls, trees):
        renamed, _ = xml_tree(rename_input(xml, mapping, varmap))
        for left, right in zip(original.iter(), renamed.iter()):
            if left.tag in ('name', 'sharp', 'labeledSymbol'):
                old, new = cpf_runtime_symbol(left), cpf_runtime_symbol(right)
                if old in typed_mapping and typed_mapping[old] != new:
                    raise ValueError('ambiguous typed CPF symbol transport')
                typed_mapping[old] = new
    extra_symbols = {}
    occupied = set(mapping.values()) | set(typed_mapping.values()) | set(runtime_aliases.values())
    def symbol(name):
        base = name.rstrip('#')
        if name in typed_mapping:
            renamed = typed_mapping[name]
            return runtime_aliases.get(renamed, renamed)
        if name in mapping:
            renamed = mapping[name]
            return runtime_aliases.get(renamed, renamed)
        if base in mapping:
            return mapping[base] + name[len(base):]
        if name != base:
            return symbol(base) + name[len(base):]
        for prefix in ('__ferrum_sl__', '__ferrum_rl__'):
            if name.startswith(prefix):
                encoded_base, labels = name[len(prefix):].split('__', 1)
                renamed_base = symbol(bytes.fromhex(encoded_base).decode())
                if prefix == '__ferrum_rl__':
                    labels = '_'.join(symbol(bytes.fromhex(label).decode()).encode().hex()
                                      for label in labels.split('_')) if labels else ''
                elif labels and not all(label.isdecimal() for label in labels.split('_')):
                    raise ValueError('invalid numeric symbol label')
                return prefix + renamed_base.encode().hex() + '__' + labels
        numeric_alias = f'|{name}|' if name.isdecimal() else (
            name[1:-1] if name.startswith('|') and name.endswith('|') and name[1:-1].isdecimal() else None)
        if numeric_alias in mapping:
            return mapping[numeric_alias]
        # Retained interpretations can contain entries for symbols no longer
        # occurring in this residual. Extend the bijection with fresh symbols;
        # never guess that such an entry denotes a live function.
        if name not in extra_symbols:
            index = len(extra_symbols)
            fresh = f'audit_witness_symbol_{index}'
            while fresh in occupied:
                index += 1
                fresh = f'audit_witness_symbol_{index}'
            occupied.add(fresh)
            extra_symbols[name] = fresh
        return extra_symbols[name]
    def symbol_keys(table):
        return {symbol(name): value for name, value in table.items()}
    try:
        if family in ('exact-matrix', 'exact-poly', 'exact-poly-removal', 'exact-subterm',
                      'exact-mono-poly', 'exact-weak-poly', 'exact-max-poly',
                      'exact-arctic', 'exact-rat-natural-poly'):
            entries = (payload[0] if family == 'exact-poly-removal' else
                       payload[1] if family == 'exact-arctic' else
                       payload[2] if family == 'exact-rat-natural-poly' else payload)
            for entry in entries:
                entry[0] = symbol(entry[0])
        elif family in ('exact-path-order', 'exact-path-order-removal'):
            offset = int(isinstance(payload[0], str))
            for index in (offset, offset + 2, offset + 3):
                payload[index] = symbol_keys(payload[index])
            payload[offset + 1] = [symbol(name) for name in payload[offset + 1]]
        elif family == 'exact-kbo':
            payload[0] = [symbol(name) for name in payload[0]]
            payload[1], payload[2] = symbol_keys(payload[1]), symbol_keys(payload[2])
        elif family == 'exact-semantic-labeling':
            for field in ('arities', 'interpretations'):
                payload[0][field] = symbol_keys(payload[0][field])
    except (ValueError, UnicodeDecodeError):
        return None  # Malformed role encodings are not transportable.
    encoded = json.dumps(payload, separators=(',', ':')).encode().hex()
    source_argument = (',source-hex=' + rename_input(source_xml, mapping, varmap).encode().hex()
                       if source_xml is not None else '')
    return rename_input(cpf, mapping, varmap), f'{family}(hex={encoded}{source_argument})'


def collect(path):
    registry, events, child_keys = {}, [], set()
    for line in path.read_text().splitlines():
        row = json.loads(line)
        inp = row.get('input') or {}
        witness = row.get('witness') or {}
        for value in [inp, *(witness.get('residuals') or [])]:
            if isinstance(value, dict) and value.get('cpf') and value.get('problem_key'):
                registry[value['problem_key']] = value['cpf']
        child_keys.update(value['problem_key'] for value in (witness.get('residuals') or [])
                          if isinstance(value, dict) and value.get('problem_key'))
        if row.get('outcome') in ('solved', 'transformed') and row.get('strategy_atom'):
            events.append(row)
    for row in events:
        inp = row['input']
        cpf = inp.get('cpf') or registry.get(inp.get('problem_key'))
        if cpf and inp.get('problem_key') in child_keys:
            yield cpf, row['strategy_atom'], row['outcome'], inp.get('problem_key')


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--root', type=Path, required=True)
    p.add_argument('--output', type=Path, required=True)
    p.add_argument('--ferrum', type=Path, required=True)
    p.add_argument('--ceta', type=Path, required=True)
    p.add_argument('--limit', type=int, default=200)
    p.add_argument('--jobs', type=int, default=8)
    p.add_argument('--timeout-ms', type=int, default=60000)
    p.add_argument('--summary', action='store_true',
                   help='Use compact probe diagnostics; requires a Ferrum supporting --summary')
    p.add_argument('--indices', type=str,
                   help='Comma-separated original action indices for a focused regression')
    p.add_argument('--only-untransported', type=Path,
                   help='Audit only state/action pairs lacking transport in this prior audit')
    args = p.parse_args()
    wanted_indices = {int(index) for index in args.indices.split(',')} if args.indices else None
    if wanted_indices and (min(wanted_indices) < 0 or args.only_untransported):
        p.error('--indices requires nonnegative original indices and cannot accompany --only-untransported')
    selection_limit = max(args.limit, max(wanted_indices) + 1) if wanted_indices else args.limit
    args.output.mkdir(parents=True, exist_ok=False)
    selected, seen = [], set()
    # Round robin over roots prevents a single large proof consuming the audit.
    streams = [(path, iter(collect(path))) for path in sorted(args.root.rglob('processor-events.jsonl'))]
    while streams and len(selected) < selection_limit:
        remaining = []
        for source_path, stream in streams:
            item = next(stream, None)
            if item is None:
                continue
            remaining.append((source_path, stream))
            cpf, atom, expected, key = item
            identity = hashlib.sha256((cpf + '\0' + atom).encode()).hexdigest()
            if identity not in seen and len(selected) < selection_limit:
                seen.add(identity)
                selected.append((cpf, atom, expected, key, str(source_path)))
        streams = remaining
    if args.only_untransported:
        prior = [json.loads(line) for line in (args.only_untransported / 'results.jsonl').open()]
        wanted = {(row['problem_key'], (args.only_untransported / str(row['index']) / 'atom.fs').read_text())
                  for row in prior if not row['rename_supported']}
        selected = [item for item in selected if (item[3], item[1]) in wanted]

    def run(index_item):
        index, (cpf, atom, expected, key, source_path) = index_item
        directory = args.output / str(index)
        directory.mkdir()
        (directory / 'atom.fs').write_text(atom)
        variants = [('original', cpf, atom)]
        rename_error = None
        try:
            renamed = renamed_action(cpf, atom)
        except (ValueError, TypeError, IndexError, ET.ParseError) as error:
            renamed = None
            rename_error = str(error)[:200]
        rename_supported = renamed is not None
        if renamed:
            variants.append(('renamed', *renamed))
        results = []
        env = dict(os.environ, RAYON_NUM_THREADS='2')
        for flag in ('FERRUM_DP_LLM_NO_FALLBACK', 'FERRUM_STATE_LOCAL_PRIORITY',
                     'FERRUM_ORACLE_STATE_LOCAL_ONLY'):
            env.pop(flag, None)
        for variant, xml, local_atom in variants:
            source = directory / f'{variant}.input.cpf'
            proof = directory / f'{variant}.proof.cpf'
            source.write_text(xml)
            atom_path = directory / f'{variant}.atom.fs'
            atom_path.write_text(local_atom)
            probe_started = time.monotonic()
            try:
                proc = subprocess.run([str(args.ferrum), 'probe-cpf', str(source),
                    '--strategy-file', str(atom_path),
                    '--timeout-ms', str(args.timeout_ms), '--cpf', str(proof)]
                    + (['--summary'] if args.summary else []),
                    env=env, capture_output=True, text=True, timeout=args.timeout_ms / 1000 + 5)
                probe_wall_ms = round((time.monotonic() - probe_started) * 1000)
                (directory / f'{variant}.stdout').write_text(proc.stdout)
                (directory / f'{variant}.stderr').write_text(proc.stderr)
                data = json.loads(proc.stdout) if proc.returncode == 0 else {}
                checks = []
                if data.get('outcome') == 'solved' and proof.exists():
                    for repeat in range(2):
                        check = subprocess.run([str(args.ceta), str(proof)], capture_output=True,
                                               text=True, timeout=60)
                        (directory / f'{variant}.ceta-{repeat}.log').write_text(check.stdout + check.stderr)
                        checks.append(check.returncode == 0 and 'CERTIFIED' in check.stdout.splitlines())
                results.append(dict(variant=variant, returncode=proc.returncode,
                    outcome=data.get('outcome'), typed_outcome=data.get('typed_outcome'),
                    children=data.get('child_count', len(data.get('children', []))), checks=checks,
                    probe_wall_ms=probe_wall_ms, elapsed_ms=data.get('elapsed_ms'),
                    stdout_bytes=len(proc.stdout.encode()),
                    certified=checks == [True, True]))
            except (subprocess.TimeoutExpired, json.JSONDecodeError) as error:
                results.append(dict(variant=variant, error=type(error).__name__))
        return dict(index=index, source_events=source_path, problem_key=key, family=atom.split('(')[0],
                    expected=expected, rename_supported=rename_supported,
                    rename_error=rename_error, results=results)

    indexed = list(enumerate(selected))
    if wanted_indices:
        missing = wanted_indices - set(range(len(selected)))
        if missing:
            p.error(f'requested action indices missing from this source: {sorted(missing)}')
        indexed = [item for item in indexed if item[0] in wanted_indices]
    with ThreadPoolExecutor(max_workers=args.jobs) as pool, (args.output / 'results.jsonl').open('x') as log:
        for future in as_completed([pool.submit(run, item) for item in indexed]):
            print(json.dumps(future.result()), file=log, flush=True)
    print(json.dumps({'actions': len(indexed), 'output': str(args.output)}))


if __name__ == '__main__':
    main()
