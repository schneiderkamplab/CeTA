#!/usr/bin/env bash
set -euo pipefail

repo_root="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
isabelle="${repo_root}/.tools/Isabelle2025-2/bin/isabelle"
ceta_pristine="${repo_root}/.tools/CeTA-source-3.9/CeTA-3.9"
ceta_src="${repo_root}/.tools/CeTA-ferrum-rfc"
patch_file="${repo_root}/docs/ceta-relative-bounds.patch"
export_dir="${repo_root}/target/ceta-relative-bounds-export"
generated_dir="${ceta_src}/generated/Haskell"
main_src="${generated_dir}/Main.hs"
binary="${repo_root}/.tools/ceta-relative-bounds"
ghcup_bin="${HOME}/.ghcup/bin"
isabelle_identifier="${CETA_ISABELLE_IDENTIFIER:-ferrum_rfc_check}"

export ISABELLE_IDENTIFIER="${ISABELLE_IDENTIFIER:-$isabelle_identifier}"

if [[ ! -x "${isabelle}" ]]; then
  echo "missing Isabelle at ${isabelle}" >&2
  exit 1
fi

if [[ ! -d "${ceta_src}" ]]; then
  if [[ ! -d "${ceta_pristine}" ]]; then
    echo "missing pristine CeTA 3.9 source at ${ceta_pristine}" >&2
    exit 1
  fi
  if [[ ! -f "${patch_file}" ]]; then
    echo "missing patch at ${patch_file}" >&2
    exit 1
  fi
  cp -a "${ceta_pristine}" "${ceta_src}"
  patch -d "${ceta_src}" -p1 < "${patch_file}"
fi

if [[ ! -f "${main_src}" ]]; then
  echo "missing ${main_src}" >&2
  exit 1
fi

if [[ -x "${ghcup_bin}/ghc" ]]; then
  export PATH="${ghcup_bin}:${PATH}"
fi

"${isabelle}" build -j "${CETA_ISABELLE_JOBS:-32}" -d "${ceta_src}/thys" Proof_Checker
"${isabelle}" build -j "${CETA_ISABELLE_JOBS:-32}" -d "${ceta_src}/thys" Code

rm -rf "${export_dir}"
mkdir -p "${export_dir}"
"${isabelle}" export -n -d "${ceta_src}/thys" -O "${export_dir}" \
  -x 'Code.Code_Haskell:code/export1/*.hs' Code >/dev/null

find "${generated_dir}" -maxdepth 1 -type f \( -name '*.hi' -o -name '*.o' \) -delete
find "${export_dir}/Code.Code_Haskell/code/export1" -maxdepth 1 -type f -name '*.hs' \
  -exec cp '{}' "${generated_dir}/" ';'

make --no-print-directory -C "${ceta_src}" GHC_ARGS="${CETA_GHC_ARGS:--O2 -j${CETA_GHC_JOBS:-8}}" haskell
mkdir -p "$(dirname "${binary}")"
cp "${ceta_src}/ceta" "${binary}"
chmod +x "${binary}"
echo "${binary}"
