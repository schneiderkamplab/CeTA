fn main() -> anyhow::Result<()> {
    ferrum::cli::run()
}
