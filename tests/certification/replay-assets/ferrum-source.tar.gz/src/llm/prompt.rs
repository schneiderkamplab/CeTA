use crate::core::{RewriteRule, Trs};
use crate::proving::DependencyPair;

use super::proof_state_json;

pub fn top_level_prompt(trs: &Trs, feedback: &[String]) -> Result<String, serde_json::Error> {
    Ok(format!(
        r#"You are guiding Ferrum, an LLM-first but proof-checked TRS termination prover.

Ferrum will not trust prose proofs. Return only JSON proposals. Ferrum checks every candidate before accepting it.

Supported proposal kinds:

{{
  "candidates": [
    {{
      "kind": "symbol_weights",
      "weights": {{"f": 1, "g": 0}}
    }},
    {{
      "kind": "linear_polynomial",
      "interpretations": {{
        "f": {{"constant": 1, "coefficients": [1]}},
        "g": {{"constant": 0, "coefficients": [1]}}
      }}
    }}
  ]
}}

For certified linear_polynomial proposals, use non-negative constants and positive argument coefficients. Ferrum accepts only if every rule strictly decreases.

Previous feedback:
{}

Proof state:

{}
"#,
        feedback_text(feedback),
        proof_state_json(trs)?
    ))
}

pub fn dp_component_prompt(
    pairs: &[DependencyPair],
    usable_rules: &[RewriteRule],
    feedback: &[String],
) -> String {
    let pairs = pairs
        .iter()
        .map(|pair| format!("{} -> {}", pair.lhs(), pair.rhs()))
        .collect::<Vec<_>>()
        .join("\n");
    let usable = usable_rules
        .iter()
        .map(ToString::to_string)
        .collect::<Vec<_>>()
        .join("\n");
    format!(
        r#"You are guiding Ferrum on one dependency-pair component.

Return only JSON proposals. Ferrum checks every candidate before accepting it.

Goal: find a reduction pair that weakly orients all usable rules and all dependency pairs, and strictly orients at least one dependency pair. Prefer positive argument coefficients for certified polynomial interpretations.

Argument filtering is only allowed here, inside this dependency-pair component. Do not use argument filtering for whole-TRS rule removal.

Supported proposal kinds:

{{
  "candidates": [
    {{
      "kind": "symbol_weights",
      "weights": {{"f#": 1, "f": 0, "s": 1}}
    }},
    {{
      "kind": "linear_polynomial",
      "interpretations": {{
        "f#": {{"constant": 0, "coefficients": [1]}},
        "s": {{"constant": 1, "coefficients": [1]}}
      }}
    }},
    {{
      "kind": "path_order",
      "order": "rpo",
      "precedence": ["f#", "f", "s", "0"],
      "argument_filter": {{"f#": [0], "f": [0], "s": [0]}}
    }}
  ]
}}

Previous feedback:
{}

Dependency pairs:
{}

Usable rules:
{}
"#,
        feedback_text(feedback),
        pairs,
        usable
    )
}

fn feedback_text(feedback: &[String]) -> String {
    if feedback.is_empty() {
        "none".to_string()
    } else {
        feedback.join("\n")
    }
}
