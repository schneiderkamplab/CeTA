use serde::Serialize;

use crate::core::{Term, Trs};
use crate::proving::dependency_pairs;

#[derive(Clone, Debug, Serialize, Eq, PartialEq)]
pub struct ProofStateView {
    name: Option<String>,
    strategy: String,
    variables: Vec<String>,
    rules: Vec<RuleView>,
    arities: Vec<ArityView>,
    defined_symbols: Vec<String>,
    validation_issues: Vec<String>,
    dependency_pairs: Vec<RuleView>,
}

#[derive(Clone, Debug, Serialize, Eq, PartialEq)]
struct RuleView {
    lhs: String,
    rhs: String,
}

#[derive(Clone, Debug, Serialize, Eq, PartialEq)]
struct ArityView {
    symbol: String,
    arity: usize,
}

impl ProofStateView {
    pub fn from_trs(trs: &Trs) -> Self {
        Self {
            name: trs.name().map(ToString::to_string),
            strategy: format!("{:?}", trs.strategy()),
            variables: trs
                .variables()
                .iter()
                .map(|variable| variable.as_str().to_string())
                .collect(),
            rules: trs
                .rules()
                .iter()
                .map(|rule| RuleView {
                    lhs: format!("{}", rule.lhs()),
                    rhs: format!("{}", rule.rhs()),
                })
                .collect(),
            arities: trs
                .arities()
                .iter()
                .map(|(symbol, arity)| ArityView {
                    symbol: symbol.as_str().to_string(),
                    arity: *arity,
                })
                .collect(),
            defined_symbols: trs
                .defined_symbols()
                .iter()
                .map(|symbol| symbol.as_str().to_string())
                .collect(),
            validation_issues: trs.validate().iter().map(ToString::to_string).collect(),
            dependency_pairs: dependency_pairs(trs)
                .iter()
                .map(|pair| RuleView {
                    lhs: term_to_string(pair.lhs()),
                    rhs: term_to_string(pair.rhs()),
                })
                .collect(),
        }
    }
}

pub fn proof_state_json(trs: &Trs) -> Result<String, serde_json::Error> {
    serde_json::to_string_pretty(&ProofStateView::from_trs(trs))
}

fn term_to_string(term: &Term) -> String {
    format!("{term}")
}
