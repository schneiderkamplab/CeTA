use std::collections::BTreeMap;

use serde::Deserialize;
use thiserror::Error;

#[derive(Clone, Debug, Deserialize, Eq, PartialEq)]
pub struct LlmProposalBatch {
    pub candidates: Vec<LlmProposal>,
}

#[derive(Clone, Debug, Default, Eq, PartialEq)]
pub struct StatusMapPrediction {
    /// Exact oracle ranking across positive evidence classes.  LLM status-map
    /// responses leave this empty and retain their class-based scheduling.
    pub ordered_positive: Vec<String>,
    /// Measured successful local action times; scheduling hints, not proof credit.
    pub measured_elapsed_ms: BTreeMap<String, u64>,
    pub solved: Vec<String>,
    pub transformed_strong: Vec<String>,
    pub transformed_weak: Vec<String>,
    pub failed: Vec<String>,
    pub timeout: Vec<String>,
}

#[derive(Clone, Debug, Deserialize, Eq, PartialEq)]
#[serde(tag = "kind", rename_all = "snake_case")]
pub enum LlmProposal {
    SymbolWeights {
        weights: SymbolWeights,
    },
    LinearPolynomial {
        interpretations: LinearPolynomialInterpretations,
    },
    PathOrder {
        order: PathOrderKind,
        precedence: Vec<String>,
        #[serde(default)]
        argument_filter: BTreeMap<String, Vec<usize>>,
    },
    ProcessorChoice {
        processor: String,
    },
}

pub type SymbolWeights = BTreeMap<String, i64>;

pub type LinearPolynomialInterpretations = BTreeMap<String, LinearPolynomial>;

#[derive(Clone, Debug, Deserialize, Eq, PartialEq)]
pub struct LinearPolynomial {
    #[serde(default)]
    pub constant: i64,
    #[serde(default)]
    pub coefficients: Vec<i64>,
}

#[derive(Clone, Copy, Debug, Deserialize, Eq, PartialEq)]
#[serde(rename_all = "snake_case")]
pub enum PathOrderKind {
    Lpo,
    Rpo,
}

#[derive(Debug, Error)]
pub enum ProposalError {
    #[error("invalid LLM proposal JSON: {0}")]
    Json(#[from] serde_json::Error),
}

pub fn parse_proposal_batch(input: &str) -> Result<LlmProposalBatch, ProposalError> {
    serde_json::from_str(input).map_err(ProposalError::from)
}

pub fn parse_status_map_prediction(input: &str) -> StatusMapPrediction {
    let mut prediction = StatusMapPrediction::default();
    let spans = status_section_spans(input);
    for (section, body) in spans {
        let atoms = parse_status_atoms(body);
        match section {
            "solved" => prediction.solved = atoms,
            "transformed_strong" => prediction.transformed_strong = atoms,
            "transformed_weak" => prediction.transformed_weak = atoms,
            "failed" => prediction.failed = atoms,
            "timeout" => prediction.timeout = atoms,
            _ => {}
        }
    }
    prediction
}

fn status_section_spans(input: &str) -> Vec<(&str, &str)> {
    const SECTIONS: [&str; 5] = [
        "solved",
        "transformed_strong",
        "transformed_weak",
        "failed",
        "timeout",
    ];
    let mut headers = Vec::new();
    let lower = input.to_ascii_lowercase();
    for section in SECTIONS {
        let mut offset = 0usize;
        while let Some(relative) = lower[offset..].find(section) {
            let start = offset + relative;
            let after = start + section.len();
            let suffix = &lower[after..];
            let colon_offset = suffix
                .char_indices()
                .find_map(|(index, ch)| match ch {
                    ':' => Some(index),
                    ch if ch.is_whitespace() => None,
                    _ => Some(usize::MAX),
                })
                .filter(|index| *index != usize::MAX);
            if let Some(colon_offset) = colon_offset {
                headers.push((start, after + colon_offset + 1, section));
                break;
            }
            offset = after;
        }
    }
    headers.sort_by_key(|(start, _, _)| *start);
    headers
        .iter()
        .enumerate()
        .map(|(index, (_, body_start, section))| {
            let body_end = headers
                .get(index + 1)
                .map(|(next_start, _, _)| *next_start)
                .unwrap_or(input.len());
            (*section, &input[*body_start..body_end])
        })
        .collect()
}

fn parse_status_atoms(body: &str) -> Vec<String> {
    let mut atoms = Vec::new();
    let mut seen = std::collections::BTreeSet::new();
    let lines = body
        .lines()
        .map(str::trim)
        .filter(|line| !line.is_empty())
        .collect::<Vec<_>>();
    if lines.len() > 1 {
        for line in lines {
            let line = normalize_status_atom(line);
            if !line.is_empty() && seen.insert(line.clone()) {
                atoms.push(line);
            }
        }
        return atoms;
    }
    let tokens = body.split_whitespace().collect::<Vec<_>>();
    let mut index = 0usize;
    while index < tokens.len() {
        let token = tokens[index];
        if matches!(token, ":" | "(" | ")" | "," | "=") {
            index += 1;
            continue;
        }
        if [
            "solved",
            "transformed_strong",
            "transformed_weak",
            "failed",
            "timeout",
        ]
        .contains(&token)
        {
            index += 1;
            continue;
        }
        if tokens.get(index + 1).is_some_and(|next| *next == "(")
            || (token.contains('(') && !token.contains(')'))
        {
            let mut atom = token.to_string();
            index += 1;
            while index < tokens.len() {
                atom.push(' ');
                atom.push_str(tokens[index]);
                if tokens[index].contains(')') {
                    index += 1;
                    break;
                }
                index += 1;
            }
            let atom = normalize_status_atom(&atom);
            if !atom.is_empty() && seen.insert(atom.clone()) {
                atoms.push(atom);
            }
            continue;
        }
        let atom = normalize_status_atom(token);
        if !atom.is_empty() && seen.insert(atom.clone()) {
            atoms.push(atom);
        }
        index += 1;
    }
    atoms
}

fn normalize_status_atom(input: &str) -> String {
    let mut out = String::new();
    let mut previous_space = false;
    for ch in input.trim().chars() {
        if ch.is_whitespace() {
            previous_space = true;
            continue;
        }
        if matches!(ch, '(' | ')' | ',' | '=') {
            while out.ends_with(' ') {
                out.pop();
            }
            out.push(ch);
            previous_space = false;
        } else {
            if previous_space && !out.is_empty() && !out.ends_with(['(', '=', ',', '-']) {
                out.push(' ');
            }
            out.push(ch);
            previous_space = false;
        }
    }
    out.replace("=- ", "=-")
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn parses_newline_status_map() {
        let prediction = parse_status_map_prediction(
            "solved:\nsize-change\nmatrix(dim=2,max-constant=2,max-coefficient=1)\n\nfailed:\ngraph\n",
        );
        assert_eq!(
            prediction.solved,
            vec![
                "size-change",
                "matrix(dim=2,max-constant=2,max-coefficient=1)",
            ]
        );
        assert_eq!(prediction.failed, vec!["graph"]);
    }

    #[test]
    fn parses_tokenizer_decoded_inline_status_map() {
        let prediction = parse_status_map_prediction(
            "solved : size-change matrix ( dim = 2 , max-constant = 2 , max-coefficient = 1 ) failed : graph sat-poly ( max-constant = 2 , max-coefficient = 1 )",
        );
        assert_eq!(
            prediction.solved,
            vec![
                "size-change",
                "matrix(dim=2,max-constant=2,max-coefficient=1)",
            ]
        );
        assert_eq!(
            prediction.failed,
            vec!["graph", "sat-poly(max-constant=2,max-coefficient=1)",]
        );
    }
}
