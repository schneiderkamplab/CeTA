use std::collections::{HashMap, HashSet};
use std::fs::File;
use std::io::{BufRead, BufReader};
use std::path::Path;
use std::sync::Arc;

use serde::Deserialize;
use sha2::{Digest, Sha256};
use thiserror::Error;

use super::StatusMapPrediction;

const SCHEMA: &str = "ferrum.utility-guidance.v2";
const WITNESS_SCHEMA: &str = "ferrum.utility-guidance.witness.v1";

#[derive(Clone, Debug)]
pub struct UtilityGuidanceLookup {
    entries: Arc<HashMap<String, UtilityGuidanceEntry>>,
}

#[derive(Clone, Debug, Deserialize, PartialEq)]
pub struct UtilityGuidanceEntry {
    pub problem_key: String,
    #[serde(default)]
    pub current_checker_invalidation: bool,
    /// SHA-256 identities of observed state-local native actions. This is
    /// scheduling evidence only, never a certification status.
    #[serde(default)]
    pub replay_order: Vec<String>,
    #[serde(default)]
    pub prefer: Vec<UtilityGuidanceCandidate>,
    #[serde(default)]
    pub possible: Vec<UtilityGuidanceCandidate>,
    #[serde(default)]
    pub avoid: Vec<UtilityGuidanceCandidate>,
    #[serde(default)]
    pub timeout: Vec<UtilityGuidanceCandidate>,
    #[serde(default)]
    pub canonical_problem_key: Option<String>,
    #[serde(default)]
    pub alias_kind: UtilityGuidanceAliasKind,
}

#[derive(Clone, Copy, Debug, Default, Deserialize, PartialEq)]
#[serde(rename_all = "snake_case")]
pub enum UtilityGuidanceAliasKind {
    /// Semantic equivalence does not preserve representation-bound witnesses.
    #[default]
    Semantic,
    /// A lossless serializer/runtime alias may reuse exact witnesses.
    Structural,
}

#[derive(Clone, Debug, Deserialize, PartialEq)]
pub struct UtilityGuidanceCandidate {
    #[serde(default)]
    pub candidate: Arc<str>,
    #[serde(default)]
    candidate_ref: Option<String>,
    pub status: String,
    pub utility_score: f64,
    pub best_elapsed_ms: Option<u64>,
    /// Conservative measured allowance after a search/backend change.
    /// Kept separate from the historical minimum used for ranking.
    #[serde(default)]
    pub replay_elapsed_ms: Option<u64>,
    pub attempts: u64,
    pub solved_count: u64,
    pub transformed_count: u64,
    pub failed_count: u64,
    pub timeout_count: u64,
    #[serde(default)]
    pub certified_count: u64,
}

#[derive(Debug, Deserialize)]
struct UtilityGuidanceRow {
    #[serde(rename = "schema")]
    _schema: String,
    #[serde(flatten)]
    entry: UtilityGuidanceEntry,
}

#[derive(Debug, Deserialize)]
struct UtilityGuidanceSchemaRow {
    schema: String,
}

#[derive(Debug, Deserialize)]
struct UtilityGuidanceWitnessRow {
    witness_id: String,
    candidate: Arc<str>,
}

#[derive(Debug, Error)]
pub enum UtilityGuidanceError {
    #[error("failed to read utility-guidance manifest: {0}")]
    Io(#[from] std::io::Error),
    #[error("invalid utility-guidance JSON on line {line}: {source}")]
    Json {
        line: usize,
        source: serde_json::Error,
    },
    #[error("unsupported utility-guidance schema {schema:?} on line {line}")]
    Schema { line: usize, schema: String },
    #[error("duplicate utility-guidance key {key:?} on line {line}")]
    Duplicate { line: usize, key: String },
    #[error("duplicate utility-guidance witness {witness_id:?} on line {line}")]
    DuplicateWitness { line: usize, witness_id: String },
    #[error("utility-guidance candidate on line {line} has neither candidate nor candidate_ref")]
    MissingCandidate { line: usize },
    #[error("utility-guidance candidate on line {line} refers to missing witness {witness_id:?}")]
    MissingWitness { line: usize, witness_id: String },
    #[error(
        "utility-guidance alias {key:?} on line {line} refers to missing canonical key {canonical_key:?}"
    )]
    AliasTarget {
        line: usize,
        key: String,
        canonical_key: String,
    },
    #[error("cyclic utility-guidance alias involving {key:?} on line {line}")]
    AliasCycle { line: usize, key: String },
    #[error("invalid {group} evidence status {status:?} on line {line}")]
    Status {
        line: usize,
        group: &'static str,
        status: String,
    },
    #[error("invalid exact-witness definition {witness_id:?} on line {line}")]
    InvalidWitness { line: usize, witness_id: String },
}

impl UtilityGuidanceLookup {
    /// Return whether the byte-exact live serialization has strong positive
    /// guidance. Unlike [`Self::predict`], this deliberately does not consult
    /// the whitespace-compacted structural key.
    pub(crate) fn has_exact_strong_guidance(&self, cpf_input: &str) -> bool {
        let raw_key = format!("{:x}", Sha256::digest(cpf_input.trim().as_bytes()));
        self.entries.get(&raw_key).is_some_and(|entry| {
            entry
                .prefer
                .iter()
                .chain(entry.possible.iter())
                .any(|candidate| {
                    matches!(candidate.status.as_str(), "solved" | "transformed_strong")
                })
        })
    }

    pub fn from_path(path: &Path) -> Result<Self, UtilityGuidanceError> {
        Self::from_reader(BufReader::new(File::open(path)?))
    }

    fn from_reader(reader: impl BufRead) -> Result<Self, UtilityGuidanceError> {
        let mut unresolved_entries = HashMap::new();
        let mut aliases = Vec::new();
        let mut witnesses = HashMap::new();
        for (index, line) in reader.lines().enumerate() {
            let line_number = index + 1;
            let line = line?;
            if line.trim().is_empty() {
                continue;
            }
            let schema: UtilityGuidanceSchemaRow =
                serde_json::from_str(&line).map_err(|source| UtilityGuidanceError::Json {
                    line: line_number,
                    source,
                })?;
            if schema.schema == WITNESS_SCHEMA {
                let witness: UtilityGuidanceWitnessRow =
                    serde_json::from_str(&line).map_err(|source| UtilityGuidanceError::Json {
                        line: line_number,
                        source,
                    })?;
                let expected = format!("{:x}", Sha256::digest(witness.candidate.as_bytes()));
                if !witness.candidate.starts_with("exact-") || witness.witness_id != expected {
                    return Err(UtilityGuidanceError::InvalidWitness {
                        line: line_number,
                        witness_id: witness.witness_id,
                    });
                }
                if witnesses
                    .insert(witness.witness_id.clone(), witness.candidate)
                    .is_some()
                {
                    return Err(UtilityGuidanceError::DuplicateWitness {
                        line: line_number,
                        witness_id: witness.witness_id,
                    });
                }
                continue;
            }
            if schema.schema != SCHEMA {
                return Err(UtilityGuidanceError::Schema {
                    line: line_number,
                    schema: schema.schema,
                });
            }
            let row: UtilityGuidanceRow =
                serde_json::from_str(&line).map_err(|source| UtilityGuidanceError::Json {
                    line: line_number,
                    source,
                })?;
            validate_evidence_statuses(line_number, "prefer", &row.entry.prefer, |status| {
                matches!(status, "solved" | "transformed_strong")
            })?;
            validate_evidence_statuses(line_number, "possible", &row.entry.possible, |status| {
                status == "transformed_weak"
            })?;
            validate_evidence_statuses(line_number, "avoid", &row.entry.avoid, |status| {
                status == "failed"
            })?;
            validate_evidence_statuses(line_number, "timeout", &row.entry.timeout, |status| {
                status == "timeout"
            })?;
            if let Some(canonical_problem_key) = row.entry.canonical_problem_key.as_deref() {
                aliases.push((
                    line_number,
                    row.entry.clone(),
                    canonical_problem_key.to_string(),
                ));
                continue;
            }
            let key = row.entry.problem_key.clone();
            if unresolved_entries
                .insert(key.clone(), (line_number, row.entry))
                .is_some()
            {
                return Err(UtilityGuidanceError::Duplicate {
                    line: line_number,
                    key,
                });
            }
        }
        for (line, entry) in unresolved_entries.values_mut() {
            resolve_candidate_references(*line, entry, &witnesses)?;
        }
        for (line, entry, _) in &mut aliases {
            resolve_candidate_references(*line, entry, &witnesses)?;
        }
        let mut entries = unresolved_entries
            .into_iter()
            .map(|(key, (_, entry))| (key, entry))
            .collect::<HashMap<_, _>>();
        // Resolve dependency order, not JSONL order. Merging independently
        // canonicalized evidence can legitimately create alias chains.
        // Each edge must still apply its own witness-transport restrictions.
        let mut pending = HashMap::new();
        for (line, alias, target) in aliases {
            let key = alias.problem_key.clone();
            if entries.contains_key(&key)
                || pending.insert(key.clone(), (line, alias, target)).is_some()
            {
                return Err(UtilityGuidanceError::Duplicate { line, key });
            }
        }
        let mut dependents: HashMap<String, Vec<String>> = HashMap::new();
        let mut ready = Vec::new();
        for (key, (line, _, target)) in &pending {
            if entries.contains_key(target) {
                ready.push(key.clone());
            } else if pending.contains_key(target) {
                dependents.entry(target.clone()).or_default().push(key.clone());
            } else {
                return Err(UtilityGuidanceError::AliasTarget {
                    line: *line,
                    key: key.clone(),
                    canonical_key: target.clone(),
                });
            }
        }
        while let Some(ready_key) = ready.pop() {
            let (line, mut alias, canonical_key) = pending.remove(&ready_key).unwrap();
            let Some(canonical) = entries.get(&canonical_key).cloned() else {
                return Err(UtilityGuidanceError::AliasTarget {
                    line,
                    key: alias.problem_key,
                    canonical_key,
                });
            };
            let key = alias.problem_key.clone();
            if alias.current_checker_invalidation {
                // The exact serialization was invalidated against the active
                // checker.  Its negative evidence must shadow semantically
                // broader canonical positives.
            } else if canonical.current_checker_invalidation {
                alias = canonical;
                alias.problem_key = key.clone();
            } else {
                // A structural alias may transport an exact witness when it
                // has no action of its own.  Once the live serialization has
                // a strong exact action, however, appending every exact
                // witness from the canonical equivalence class turns a
                // deterministic recursive proof into a combinatorial search
                // over sibling residuals.  Keep generic canonical guidance,
                // but let the state-local exact continuation shadow broader
                // representation-bound alternatives.
                let has_local_strong_exact = alias.prefer.iter().any(|candidate| {
                    matches!(candidate.status.as_str(), "solved" | "transformed_strong")
                        && candidate.candidate.starts_with("exact-")
                });
                let inherit_exact = alias.alias_kind == UtilityGuidanceAliasKind::Structural
                    && !has_local_strong_exact;
                append_unseen_candidates(
                    &mut alias.prefer,
                    canonical
                        .prefer
                        .into_iter()
                        .filter(|candidate| {
                            if has_local_strong_exact {
                                !candidate.candidate.starts_with("exact-")
                            } else {
                                inherit_exact
                                    || !is_representation_bound(&candidate.candidate, false)
                            }
                        })
                        .collect(),
                );
                append_unseen_candidates(
                    &mut alias.possible,
                    canonical
                        .possible
                        .into_iter()
                        .filter(|candidate| {
                            if has_local_strong_exact {
                                !candidate.candidate.starts_with("exact-")
                            } else {
                                inherit_exact
                                    || !is_representation_bound(&candidate.candidate, false)
                            }
                        })
                        .collect(),
                );
                append_unseen_candidates(&mut alias.avoid, canonical.avoid);
                append_unseen_candidates(&mut alias.timeout, canonical.timeout);
            }
            alias.canonical_problem_key = Some(canonical_key);
            if entries.insert(key.clone(), alias).is_some() {
                return Err(UtilityGuidanceError::Duplicate { line, key });
            }
            ready.extend(dependents.remove(&key).unwrap_or_default());
        }
        if let Some((key, (line, _, _))) = pending.into_iter().next() {
            return Err(UtilityGuidanceError::AliasCycle { line, key });
        }
        Ok(Self {
            entries: Arc::new(entries),
        })
    }

    pub fn len(&self) -> usize {
        self.entries.len()
    }

    pub fn is_empty(&self) -> bool {
        self.entries.is_empty()
    }

    pub(crate) fn has_replay_order(&self, cpf_input: &str) -> bool {
        let key = format!("{:x}", Sha256::digest(cpf_input.trim().as_bytes()));
        self.entries.get(&key).is_some_and(|entry|
            !entry.current_checker_invalidation && !entry.replay_order.is_empty())
    }

    pub fn predict(&self, cpf_input: &str) -> Option<StatusMapPrediction> {
        let raw_key = format!("{:x}", Sha256::digest(cpf_input.trim().as_bytes()));
        let compact = compact_xml_for_key(cpf_input);
        let structural_key = format!("{:x}", Sha256::digest(compact.as_bytes()));
        // Diagnostic-only lookup trace for lossless category slicing. Processor
        // events do not record every raw/structural/canonical query we try.
        // Never infer that an unrecorded event key is unused by the lookup.
        if let Some(directory) = std::env::var_os("FERRUM_ORACLE_LOOKUP_TRACE_DIR") {
            use std::io::Write;
            let path = std::path::PathBuf::from(directory)
                .join(format!("{}.jsonl", std::process::id()));
            if let Ok(mut output) = std::fs::OpenOptions::new()
                .create(true).append(true).open(path)
            {
                let _ = writeln!(output, "[\"{raw_key}\",\"{structural_key}\"]");
            }
        }
        let mut matching_entries = Vec::new();
        let raw_entry = self.entries.get(&raw_key);
        if let Some(entry) = raw_entry {
            matching_entries.push(entry);
        }
        if structural_key != raw_key {
            if let Some(entry) = self.entries.get(&structural_key) {
                matching_entries.push(entry);
            }
        }
        if matching_entries.is_empty() {
            return None;
        }
        if matching_entries
            .iter()
            .any(|entry| entry.current_checker_invalidation)
        {
            matching_entries.retain(|entry| entry.current_checker_invalidation);
        } else if raw_entry.is_some_and(|entry| {
            entry.prefer.iter().any(|candidate| {
                matches!(candidate.status.as_str(), "solved" | "transformed_strong")
            })
        }) {
            // A byte-exact, strong action is the most specific evidence we
            // can have for this live state.  The compact key is only a
            // serializer-compatibility fallback.  Merging its older weak
            // fragments here can bypass a newly reconstructed context (for
            // example localUsableRulesProc) after that exact action exposes
            // an as-yet uncovered child.
            matching_entries.retain(|entry| std::ptr::eq(*entry, raw_entry.unwrap()));
        }
        let mut prediction = StatusMapPrediction::default();
        if let Some(entry) = raw_entry.filter(|entry| !entry.current_checker_invalidation) {
            for candidate in entry.prefer.iter().chain(entry.possible.iter()) {
                if matches!(candidate.status.as_str(), "solved" | "transformed_strong" | "transformed_weak") {
                    if let Some(ms) = candidate.best_elapsed_ms.max(candidate.replay_elapsed_ms)
                        .filter(|ms| *ms > 0) {
                        prediction.measured_elapsed_ms.entry(candidate.candidate.to_string())
                            .and_modify(|old| *old = (*old).max(ms)).or_insert(ms);
                    }
                }
            }
        }
        let mut seen_positive = HashSet::new();
        prediction.ordered_positive.extend(
            matching_entries
                .iter()
                .flat_map(|entry| entry.prefer.iter().chain(entry.possible.iter()))
                .filter(|candidate| {
                    matches!(
                        candidate.status.as_str(),
                        "solved" | "transformed_strong" | "transformed_weak"
                    )
                })
                .map(|candidate| candidate.candidate.as_ref().to_owned())
                .filter(|candidate| seen_positive.insert(candidate.clone())),
        );
        if let Some(entry) = raw_entry.filter(|entry| !entry.current_checker_invalidation) {
            if !entry.replay_order.is_empty() {
                let priorities: HashMap<_, _> = entry.replay_order.iter()
                    .enumerate().map(|(index, digest)| (digest.as_str(), index)).collect();
                prediction.ordered_positive.sort_by_cached_key(|atom| {
                    let digest = format!("{:x}", Sha256::digest(atom.as_bytes()));
                    priorities.get(digest.as_str()).copied().unwrap_or(usize::MAX)
                });
            }
        }
        seen_positive.clear();
        for status in ["solved", "transformed_strong", "transformed_weak"] {
            for candidate in matching_entries
                .iter()
                .flat_map(|entry| entry.prefer.iter().chain(entry.possible.iter()))
                .filter(|candidate| candidate.status == status)
            {
                let mut candidates = vec![candidate.candidate.as_ref().to_owned()];
                candidates.retain(|candidate| seen_positive.insert(candidate.clone()));
                match status {
                    "solved" => prediction.solved.extend(candidates),
                    "transformed_strong" => prediction.transformed_strong.extend(candidates),
                    "transformed_weak" => prediction.transformed_weak.extend(candidates),
                    _ => unreachable!("positive status selected above"),
                }
            }
        }
        let mut seen_failed = HashSet::new();
        prediction.failed.extend(
            matching_entries
                .iter()
                .flat_map(|entry| entry.avoid.iter())
                .map(|candidate| candidate.candidate.as_ref().to_owned())
                .filter(|candidate| {
                    !seen_positive.contains(candidate) && seen_failed.insert(candidate.clone())
                }),
        );
        let mut seen_timeout = HashSet::new();
        prediction.timeout.extend(
            matching_entries
                .iter()
                .flat_map(|entry| entry.timeout.iter())
                .map(|candidate| candidate.candidate.as_ref().to_owned())
                .filter(|candidate| {
                    !seen_positive.contains(candidate)
                        && !seen_failed.contains(candidate)
                        && seen_timeout.insert(candidate.clone())
                }),
        );
        Some(prediction)
    }

    /// Look up only exact processors whose payload validates and relocates
    /// its complete source obligation.  This is the safe interface for a
    /// legacy/contextless DP-state alias: parameterized or index-only advice
    /// must never cross that representation boundary.
    pub fn predict_portable_exact(
        &self,
        cpf_input: &str,
        allow_complete_transformations: bool,
    ) -> Option<StatusMapPrediction> {
        self.predict(cpf_input)
            .map(|prediction| {
                only_portable_canonical_exact_candidates(prediction, allow_complete_transformations)
            })
            .filter(|prediction| !prediction.ordered_positive.is_empty())
    }

    /// Look up guidance on a canonical mathematical problem view while
    /// discarding witnesses and transformations whose source obligation is
    /// tied to one concrete runtime state.  Only terminal processors that
    /// recompute their complete witness from the live state are safe here.
    pub fn predict_semantic_canonical(
        &self,
        cpf_input: &str,
        allow_complete_transformations: bool,
    ) -> Option<StatusMapPrediction> {
        self.predict(cpf_input)
            .map(|prediction| {
                only_semantic_core_candidates(prediction, allow_complete_transformations)
            })
            .filter(|prediction| !prediction.ordered_positive.is_empty())
    }

    /// Combine exact evidence for the live serialization with evidence for its
    /// semantically canonical serialization.  Exact evidence is considered
    /// first: canonical equivalence preserves the proof problem, but a
    /// parameterized search atom can still synthesize a different model when
    /// symbol or constraint order changes.  Thus a known replayable action for
    /// the exact state must not be displaced by a newer canonical candidate.
    pub fn predict_prefer_canonical(
        &self,
        raw_cpf_input: &str,
        canonical_cpf_input: &str,
        allow_complete_transformations: bool,
    ) -> Option<StatusMapPrediction> {
        let exact = self.predict(raw_cpf_input);
        if self.is_current_checker_invalidated(raw_cpf_input) {
            return exact;
        }
        let canonical = self.predict(canonical_cpf_input).map(|prediction| {
            without_representation_bound_candidates(prediction, allow_complete_transformations)
        });
        if exact.as_ref().is_some_and(|prediction| {
            !prediction.solved.is_empty() || !prediction.transformed_strong.is_empty()
        }) {
            // A certified exact-state action is already known to be
            // executable for this serialization. Racing it against broader
            // canonical candidates makes the result scheduler-dependent: a
            // different but locally valid transformation may win and expose
            // an uncovered child. Canonical evidence remains the fallback
            // when exact evidence is absent or only weak.
            // A complete exact DP transformation is different from an
            // index-based residual fragment: it checks the witness TRS as an
            // alpha-invariant multiset and CeTA validates the selected DP set.
            // It is therefore safe across canonical serializer aliases and
            // must outrank an older generic `dp` atom whose downstream chain
            // may have drifted.
            let portable_exact = canonical.as_ref().cloned().map(|prediction| {
                only_portable_canonical_exact_candidates(prediction, allow_complete_transformations)
            });
            let raw_key = format!("{:x}", Sha256::digest(raw_cpf_input.trim().as_bytes()));
            if self.entries.get(&raw_key).is_some_and(|entry| !entry.replay_order.is_empty()) {
                return merge_predictions(exact, portable_exact);
            }
            return merge_predictions(portable_exact, exact);
        }
        merge_predictions(exact, canonical)
    }

    /// Prefer exact evidence for the current executable state, then exact
    /// aliases emitted by older lossless serializers, and finally semantic
    /// canonical evidence. Serializer migrations must not make certified
    /// guidance disappear, but a current exact-state action remains first.
    pub fn predict_prefer_exact_aliases(
        &self,
        exact_inputs: &[&str],
        canonical_cpf_input: &str,
        allow_complete_transformations: bool,
    ) -> Option<StatusMapPrediction> {
        let mut merged = None;
        for input in exact_inputs {
            let prediction = self.predict(input);
            if self.is_current_checker_invalidated(input) {
                return merge_predictions(merged, prediction);
            }
            merged = merge_predictions(merged, prediction);
            if merged.as_ref().is_some_and(|prediction| {
                !prediction.solved.is_empty() || !prediction.transformed_strong.is_empty()
            }) {
                // Keep the exact alias first, but do not let stale strong
                // evidence hide source-bound canonical actions forever.
                // These alternatives run only if the earlier chain fails.
                let portable = self.predict(canonical_cpf_input).map(|prediction|
                    only_portable_canonical_exact_candidates(prediction, allow_complete_transformations));
                return merge_predictions(merged, portable);
            }
        }
        merge_predictions(
            merged,
            self.predict(canonical_cpf_input).map(|prediction| {
                without_representation_bound_candidates(prediction, allow_complete_transformations)
            }),
        )
    }

    fn is_current_checker_invalidated(&self, cpf_input: &str) -> bool {
        let raw_key = format!("{:x}", Sha256::digest(cpf_input.trim().as_bytes()));
        let compact = compact_xml_for_key(cpf_input);
        let structural_key = format!("{:x}", Sha256::digest(compact.as_bytes()));
        self.entries
            .get(&raw_key)
            .is_some_and(|entry| entry.current_checker_invalidation)
            || self
                .entries
                .get(&structural_key)
                .is_some_and(|entry| entry.current_checker_invalidation)
    }
}

fn resolve_candidate_references(
    line: usize,
    entry: &mut UtilityGuidanceEntry,
    witnesses: &HashMap<String, Arc<str>>,
) -> Result<(), UtilityGuidanceError> {
    for candidate in entry
        .prefer
        .iter_mut()
        .chain(entry.possible.iter_mut())
        .chain(entry.avoid.iter_mut())
        .chain(entry.timeout.iter_mut())
    {
        if candidate.candidate.is_empty() {
            let Some(witness_id) = candidate.candidate_ref.as_deref() else {
                return Err(UtilityGuidanceError::MissingCandidate { line });
            };
            candidate.candidate = witnesses.get(witness_id).cloned().ok_or_else(|| {
                UtilityGuidanceError::MissingWitness {
                    line,
                    witness_id: witness_id.to_string(),
                }
            })?;
        }
        candidate.candidate_ref = None;
    }
    Ok(())
}

fn is_representation_bound(candidate: &str, allow_complete_transformations: bool) -> bool {
    candidate.starts_with("exact-")
        && !is_portable_exact_candidate(candidate, allow_complete_transformations)
}

fn is_complete_transformation_candidate(candidate: &str) -> bool {
    [
        "exact-dp-transform(",
        "exact-dp-no-rule-removal(",
        "exact-semantic-labeling(",
    ]
    .iter()
    .any(|prefix| candidate.starts_with(prefix))
}

/// Exact processors whose payload carries enough source state to validate and
/// relocate itself across the checked signature isomorphism used by canonical
/// DP lookup. Checked live-reassigned SCT graphs are also portable. Unchecked
/// index-only fragments and source-less contexts remain representation-bound.
fn is_portable_exact_candidate(candidate: &str, allow_complete_transformations: bool) -> bool {
    // This native family recomputes the closure from the complete live state;
    // it transports no indexed witness or omitted context across the alias.
    if matches!(candidate, "usable-rules" | "innermost-lhss" | "instantiate" | "alpha-merge" | "graph-refined") {
        return true;
    }
    // Unselected transformations enumerate choices from the live state.
    // Their bounded native searches are portable; a candidate ordinal is
    // not, since rule/pair ordering can change under canonicalization.
    if ["narrow", "rewrite", "instantiate", "forward-instantiate"]
        .iter().any(|prefix| candidate.starts_with(prefix))
    {
        use crate::proving::{DpStrategy, DpStrategyProcessor};
        if matches!(DpStrategy::parse(candidate), Ok(DpStrategy::Processor(
            DpStrategyProcessor::Narrowing { .. }
            | DpStrategyProcessor::Rewriting { .. }
            | DpStrategyProcessor::Instantiation { .. }
            | DpStrategyProcessor::ForwardInstantiation { .. }
        ))) { return true; }
    }
    [
        "exact-dp(",
        "exact-innermost-lhss-dp(",
        "exact-red-pair(",
        "exact-general-red-pair(",
        "exact-graph(",
        "exact-usable-rules(",
        // The SCT processor reassigns every witness graph bijectively to
        // live pairs, rechecks every subterm edge, and checks live closure.
        // Source pair indices are not trusted as live pair indices.
        "exact-size-change(",
        // This is a checked subset choice, not an index-based proof. The
        // native processor rebinds every retained Q term to the live Q and
        // rejects nonminimal/non-innermost/nonordinary inputs. Offering the
        // choice canonically cannot bypass those applicability checks.
        "exact-innermost-lhss(",
        "exact-dp-nonloop(",
        "exact-dp-loop(",
        "exact-dp-nontermination-proof(",
        "exact-dp-proof(",
        "exact-trs-proof(",
        "exact-trs-nontermination-proof(",
        "exact-trs-nontermination-terminal(",
        "exact-trs-no-rule-removal(",
        "exact-trs-order(",
    ]
    .iter()
    .any(|prefix| candidate.starts_with(prefix))
        || (allow_complete_transformations && is_complete_transformation_candidate(candidate))
}

fn only_portable_canonical_exact_candidates(
    mut prediction: StatusMapPrediction,
    allow_complete_transformations: bool,
) -> StatusMapPrediction {
    let portable =
        |candidate: &String| is_portable_exact_candidate(candidate, allow_complete_transformations);
    prediction.ordered_positive.retain(portable);
    prediction.measured_elapsed_ms.retain(|candidate, _| portable(candidate));
    prediction.solved.retain(portable);
    prediction.transformed_strong.retain(portable);
    prediction.transformed_weak.retain(portable);
    prediction.failed.clear();
    prediction.timeout.clear();
    prediction
}

/// Candidates that may cross from a fully instrumented runtime state to its
/// context-free mathematical DP core.  Native SCT and subterm are recomputed
/// from the live state.  Even self-validating exact transformations must use
/// the narrower proof-projection lookup: otherwise a valid transformation
/// from another runtime context can replace the recorded residual
/// continuation with a different transformation loop.
fn only_semantic_core_candidates(
    mut prediction: StatusMapPrediction,
    _allow_complete_transformations: bool,
) -> StatusMapPrediction {
    let portable = |candidate: &String| matches!(candidate.as_str(), "size-change" | "subterm");
    prediction.measured_elapsed_ms.retain(|candidate, _| portable(candidate));
    prediction.ordered_positive.retain(portable);
    prediction.solved.retain(portable);
    prediction.transformed_strong.retain(portable);
    prediction.transformed_weak.retain(portable);
    prediction.failed.clear();
    prediction.timeout.clear();
    prediction
}

fn without_representation_bound_candidates(
    mut prediction: StatusMapPrediction,
    allow_complete_transformations: bool,
) -> StatusMapPrediction {
    prediction.measured_elapsed_ms.retain(|candidate, _|
        !is_representation_bound(candidate, allow_complete_transformations));
    prediction
        .ordered_positive
        .retain(|candidate| !is_representation_bound(candidate, allow_complete_transformations));
    prediction
        .solved
        .retain(|candidate| !is_representation_bound(candidate, allow_complete_transformations));
    prediction
        .transformed_strong
        .retain(|candidate| !is_representation_bound(candidate, allow_complete_transformations));
    prediction
        .transformed_weak
        .retain(|candidate| !is_representation_bound(candidate, allow_complete_transformations));
    prediction
        .failed
        .retain(|candidate| !is_representation_bound(candidate, allow_complete_transformations));
    prediction
        .timeout
        .retain(|candidate| !is_representation_bound(candidate, allow_complete_transformations));
    prediction
}

fn append_unseen_candidates(
    target: &mut Vec<UtilityGuidanceCandidate>,
    candidates: Vec<UtilityGuidanceCandidate>,
) {
    let mut seen = target
        .iter()
        .map(|candidate| (candidate.candidate.clone(), candidate.status.clone()))
        .collect::<HashSet<_>>();
    target.extend(
        candidates.into_iter().filter(|candidate| {
            seen.insert((candidate.candidate.clone(), candidate.status.clone()))
        }),
    );
}

fn merge_predictions(
    exact: Option<StatusMapPrediction>,
    canonical: Option<StatusMapPrediction>,
) -> Option<StatusMapPrediction> {
    let predictions = [exact.as_ref(), canonical.as_ref()];
    if predictions.iter().all(Option::is_none) {
        return None;
    }

    let mut merged = StatusMapPrediction::default();
    let mut seen_ordered = HashSet::new();
    for prediction in predictions.iter().flatten() {
        for (atom, ms) in &prediction.measured_elapsed_ms {
            merged.measured_elapsed_ms.entry(atom.clone())
                .and_modify(|old| *old = (*old).max(*ms)).or_insert(*ms);
        }
        merged.ordered_positive.extend(
            prediction
                .ordered_positive
                .iter()
                .filter(|candidate| seen_ordered.insert((*candidate).clone()))
                .cloned(),
        );
    }
    let mut seen_positive = HashSet::new();
    for status in ["solved", "transformed_strong", "transformed_weak"] {
        for prediction in predictions.iter().flatten() {
            let candidates = match status {
                "solved" => &prediction.solved,
                "transformed_strong" => &prediction.transformed_strong,
                "transformed_weak" => &prediction.transformed_weak,
                _ => unreachable!("positive status selected above"),
            };
            for candidate in candidates {
                if !seen_positive.insert(candidate.clone()) {
                    continue;
                }
                match status {
                    "solved" => merged.solved.push(candidate.clone()),
                    "transformed_strong" => merged.transformed_strong.push(candidate.clone()),
                    "transformed_weak" => merged.transformed_weak.push(candidate.clone()),
                    _ => unreachable!("positive status selected above"),
                }
            }
        }
    }

    let mut seen_failed = HashSet::new();
    for prediction in predictions.iter().flatten() {
        merged.failed.extend(
            prediction
                .failed
                .iter()
                .filter(|candidate| {
                    !seen_positive.contains(*candidate) && seen_failed.insert((*candidate).clone())
                })
                .cloned(),
        );
    }
    let mut seen_timeout = HashSet::new();
    for prediction in predictions.iter().flatten() {
        merged.timeout.extend(
            prediction
                .timeout
                .iter()
                .filter(|candidate| {
                    !seen_positive.contains(*candidate)
                        && !seen_failed.contains(*candidate)
                        && seen_timeout.insert((*candidate).clone())
                })
                .cloned(),
        );
    }
    Some(merged)
}

pub(crate) fn compact_xml_for_key(xml: &str) -> String {
    let bytes = xml.trim().as_bytes();
    let mut result = Vec::with_capacity(bytes.len());
    let mut index = 0;
    while index < bytes.len() {
        if bytes[index] == b'>' {
            result.push(b'>');
            index += 1;
            let whitespace_start = index;
            while index < bytes.len() && bytes[index].is_ascii_whitespace() {
                index += 1;
            }
            if index >= bytes.len() || bytes[index] != b'<' {
                result.extend_from_slice(&bytes[whitespace_start..index]);
            }
            continue;
        }
        if bytes[index] == b'/' && index + 1 < bytes.len() && bytes[index + 1] == b'>' {
            while result.last().is_some_and(u8::is_ascii_whitespace) {
                result.pop();
            }
        }
        result.push(bytes[index]);
        index += 1;
    }
    String::from_utf8(result)
        .expect("compacting UTF-8 XML only removes ASCII whitespace")
        // CPF serializers legitimately choose either spelling for an
        // apostrophe in element text.  It is not markup outside a
        // single-quoted attribute (none occur in typed problem inputs), so
        // normalize the equivalent entity spellings before hashing.
        .replace("&apos;", "'")
        .replace("&#39;", "'")
        .replace("&#x27;", "'")
        .replace("&#X27;", "'")
}

fn validate_evidence_statuses(
    line: usize,
    group: &'static str,
    candidates: &[UtilityGuidanceCandidate],
    valid: impl Fn(&str) -> bool,
) -> Result<(), UtilityGuidanceError> {
    if let Some(candidate) = candidates
        .iter()
        .find(|candidate| !valid(candidate.status.as_str()))
    {
        return Err(UtilityGuidanceError::Status {
            line,
            group,
            status: candidate.status.clone(),
        });
    }
    Ok(())
}

#[cfg(test)]
mod tests {
    use std::io::Cursor;

    use sha2::{Digest, Sha256};

    use super::{SCHEMA, UtilityGuidanceError, UtilityGuidanceLookup, WITNESS_SCHEMA, compact_xml_for_key, is_portable_exact_candidate};

    #[test]
    fn replay_order_does_not_promote_weak_or_failed_evidence() {
        let cpf = "<dpInput><dps><rules/></dps></dpInput>";
        let key = format!("{:x}", Sha256::digest(cpf.as_bytes()));
        let candidate = |atom: &str, status: &str| serde_json::json!({
            "candidate": atom, "status": status, "utility_score": 1.0,
            "attempts": 1, "solved_count": 0, "transformed_count": 1,
            "failed_count": 0, "timeout_count": 0
        });
        let row = serde_json::json!({"schema": SCHEMA, "problem_key": key,
            "prefer": [candidate("graph", "transformed_strong")],
            "possible": [candidate("alpha-merge", "transformed_weak")],
            "avoid": [candidate("subterm", "failed")],
            "replay_order": [format!("{:x}", Sha256::digest(b"subterm")),
                format!("{:x}", Sha256::digest(b"alpha-merge"))]});
        let lookup = UtilityGuidanceLookup::from_reader(Cursor::new(row.to_string())).unwrap();
        let result = lookup.predict(cpf).unwrap();
        assert_eq!(result.ordered_positive, ["alpha-merge", "graph"]);
        assert_eq!(result.transformed_weak, ["alpha-merge"]);
        assert_eq!(result.transformed_strong, ["graph"]);
        assert!(result.solved.is_empty());
        assert_eq!(result.failed, ["subterm"]);
    }

    #[test]
    fn canonical_native_q_reduction_is_not_hidden_by_an_old_raw_transformation() {
        let raw = "<dpInput><live/></dpInput>";
        let canonical = "<dpInput><canonical/></dpInput>";
        let row = |cpf: &str, atom: &str, status: &str| serde_json::json!({
            "schema": SCHEMA,
            "problem_key": format!("{:x}", Sha256::digest(cpf.as_bytes())),
            (if status == "transformed_strong" { "prefer" } else { "possible" }):
                [{"candidate": atom, "status": status, "utility_score": 1.0,
                "attempts": 1, "solved_count": 0, "transformed_count": 1,
                "failed_count": 0, "timeout_count": 0, "certified_count": 0}]
        });
        let manifest = format!("{}\n{}\n", row(raw, "narrow", "transformed_strong"),
            row(canonical, "innermost-lhss", "transformed_weak"));
        let lookup = UtilityGuidanceLookup::from_reader(Cursor::new(manifest)).unwrap();
        let result = lookup.predict_prefer_canonical(raw, canonical, false).unwrap();
        assert_eq!(result.ordered_positive, ["innermost-lhss", "narrow"]);
        assert_eq!(result.transformed_weak, ["innermost-lhss"]);
        assert!(result.solved.is_empty());
    }

    #[test]
    fn canonical_native_transform_searches_are_portable_but_ordinals_are_not() {
        for family in ["narrow", "rewrite", "instantiate", "forward-instantiate"] {
            assert!(is_portable_exact_candidate(family, false));
            assert!(is_portable_exact_candidate(&format!("{family}(per-pair=128)"), false));
            assert!(!is_portable_exact_candidate(&format!("{family}(candidate=1,per-pair=128)"), false));
        }
    }

    #[test]
    fn measured_replay_allowance_preserves_best_time_and_evidence_credit() {
        let cpf = "<trsInput><trs><rules/></trs></trsInput>";
        let key = format!("{:x}", Sha256::digest(cpf.as_bytes()));
        let row = serde_json::json!({"schema": SCHEMA, "problem_key": key,
            "possible": [{"candidate": "path-order", "status": "transformed_weak",
                "utility_score": 1.0, "best_elapsed_ms": 39000,
                "replay_elapsed_ms": 63130, "attempts": 1, "solved_count": 0,
                "transformed_count": 1, "failed_count": 0, "timeout_count": 0,
                "certified_count": 0}]});
        let lookup = UtilityGuidanceLookup::from_reader(Cursor::new(row.to_string())).unwrap();
        let prediction = lookup.predict(cpf).unwrap();
        assert_eq!(prediction.measured_elapsed_ms.get("path-order"), Some(&63130));
        assert!(prediction.solved.is_empty());
        assert!(prediction.transformed_strong.is_empty());
        assert_eq!(prediction.transformed_weak, ["path-order"]);
    }

    #[test]
    fn predicts_the_single_manifest_candidate() {
        let cpf = "<trsInput><trs><rules/></trs></trsInput>";
        let key = format!("{:x}", Sha256::digest(cpf.trim().as_bytes()));
        let manifest = format!(
            "{{\"schema\":\"ferrum.utility-guidance.v2\",\"problem_key\":\"{key}\",\
             \"prefer\":[{{\"candidate\":\"subterm\",\"status\":\"solved\",\
             \"utility_score\":42.0,\"best_elapsed_ms\":3,\"attempts\":2,\
             \"solved_count\":2,\"transformed_count\":0,\"failed_count\":0,\
             \"timeout_count\":0}}],\"possible\":[],\"avoid\":[],\"timeout\":[]}}\n"
        );
        let lookup = UtilityGuidanceLookup::from_reader(Cursor::new(manifest)).unwrap();
        let prediction = lookup.predict(&format!("\n{cpf}\n")).unwrap();
        assert_eq!(prediction.solved, ["subterm"]);
        assert_eq!(prediction.measured_elapsed_ms.get("subterm"), Some(&3));
        assert!(prediction.transformed_strong.is_empty());
    }

    #[test]
    fn byte_exact_strong_action_shadows_older_compact_fragment() {
        let cpf = "<dpInput>\n  <dps>\n    <rules/>\n  </dps>\n</dpInput>";
        let raw_key = format!("{:x}", Sha256::digest(cpf.as_bytes()));
        let compact_key = format!("{:x}", Sha256::digest(compact_xml_for_key(cpf).as_bytes()));
        assert_ne!(raw_key, compact_key);
        let manifest = format!(
            "{{\"schema\":\"{SCHEMA}\",\"problem_key\":\"{raw_key}\",\
             \"prefer\":[{{\"candidate\":\"exact-usable-rules(hex=00)\",\
             \"status\":\"transformed_strong\",\"utility_score\":1200.0,\
             \"best_elapsed_ms\":0,\"attempts\":1,\"solved_count\":0,\
             \"transformed_count\":1,\"failed_count\":0,\"timeout_count\":0}}]}}\n\
             {{\"schema\":\"{SCHEMA}\",\"problem_key\":\"{compact_key}\",\
             \"possible\":[{{\"candidate\":\"exact-poly(hex=00)\",\
             \"status\":\"transformed_weak\",\"utility_score\":600.0,\
             \"best_elapsed_ms\":0,\"attempts\":1,\"solved_count\":0,\
             \"transformed_count\":1,\"failed_count\":0,\"timeout_count\":0}}]}}\n"
        );
        let lookup = UtilityGuidanceLookup::from_reader(manifest.as_bytes()).unwrap();
        let prediction = lookup.predict(cpf).unwrap();
        assert_eq!(
            prediction.transformed_strong,
            ["exact-usable-rules(hex=00)"]
        );
        assert!(prediction.transformed_weak.is_empty());
        assert_eq!(prediction.ordered_positive, ["exact-usable-rules(hex=00)"]);
    }

    #[test]
    fn resolves_compact_witness_references_independently_of_row_order() {
        let cpf = "<trsInput><trs><rules/></trs></trsInput>";
        let key = format!("{:x}", Sha256::digest(cpf.as_bytes()));
        let candidate = "exact-dp(hex=5b5d)";
        let witness_id = format!("{:x}", Sha256::digest(candidate.as_bytes()));
        let manifest = format!(
            "{{\"schema\":\"{SCHEMA}\",\"problem_key\":\"{key}\",\
             \"prefer\":[{{\"candidate_ref\":\"{witness_id}\",\"status\":\"solved\",\
             \"utility_score\":42.0,\"best_elapsed_ms\":3,\"attempts\":1,\
             \"solved_count\":1,\"transformed_count\":0,\"failed_count\":0,\
             \"timeout_count\":0,\"certified_count\":1}}]}}\n\
             {{\"schema\":\"{WITNESS_SCHEMA}\",\"witness_id\":\"{witness_id}\",\
             \"candidate\":\"{candidate}\"}}\n"
        );
        let lookup = UtilityGuidanceLookup::from_reader(manifest.as_bytes()).unwrap();
        assert_eq!(lookup.predict(cpf).unwrap().solved, [candidate]);
    }

    #[test]
    fn rejects_missing_compact_witness_reference() {
        let manifest = format!(
            "{{\"schema\":\"{SCHEMA}\",\"problem_key\":\"key\",\
             \"prefer\":[{{\"candidate_ref\":\"missing\",\"status\":\"solved\",\
             \"utility_score\":1.0,\"best_elapsed_ms\":1,\"attempts\":1,\
             \"solved_count\":1,\"transformed_count\":0,\"failed_count\":0,\
             \"timeout_count\":0}}]}}\n"
        );
        assert!(matches!(
            UtilityGuidanceLookup::from_reader(manifest.as_bytes()),
            Err(super::UtilityGuidanceError::MissingWitness { .. })
        ));
    }

    #[test]
    fn rejects_candidate_without_inline_or_referenced_witness() {
        let manifest = format!(
            "{{\"schema\":\"{SCHEMA}\",\"problem_key\":\"key\",\
             \"prefer\":[{{\"status\":\"solved\",\"utility_score\":1.0,\
             \"best_elapsed_ms\":1,\"attempts\":1,\"solved_count\":1,\
             \"transformed_count\":0,\"failed_count\":0,\"timeout_count\":0}}]}}\n"
        );
        assert!(matches!(
            UtilityGuidanceLookup::from_reader(manifest.as_bytes()),
            Err(super::UtilityGuidanceError::MissingCandidate { .. })
        ));
    }

    #[test]
    fn lookup_ignores_inter_tag_and_empty_element_formatting() {
        let compact =
            "<dpInput><trs><rules/></trs><dps><rules/></dps><minimal>true</minimal></dpInput>";
        let key = format!("{:x}", Sha256::digest(compact.as_bytes()));
        let manifest = format!(
            "{{\"schema\":\"{SCHEMA}\",\"problem_key\":\"{key}\",\"prefer\":[{{\"candidate\":\"graph\",\"status\":\"solved\",\"utility_score\":1.0,\"best_elapsed_ms\":1,\"attempts\":1,\"solved_count\":1,\"transformed_count\":0,\"failed_count\":0,\"timeout_count\":0,\"certified_count\":1}}]}}\n"
        );
        let lookup = UtilityGuidanceLookup::from_reader(manifest.as_bytes()).unwrap();
        let formatted = "<dpInput>\n  <trs><rules /></trs>\n  <dps><rules /></dps>\n  <minimal>true</minimal>\n</dpInput>\n";
        assert_eq!(
            lookup.predict(formatted).unwrap().solved,
            vec!["graph".to_string()]
        );
    }

    #[test]
    fn structural_key_ignores_apostrophe_entity_spelling() {
        assert_eq!(
            compact_xml_for_key("<name>|f&apos;|</name>"),
            compact_xml_for_key("<name>|f'|</name>"),
        );
    }

    #[test]
    fn structural_positive_supersedes_stale_raw_negative() {
        let compact =
            "<dpInput><trs><rules/></trs><dps><rules/></dps><minimal>true</minimal></dpInput>";
        let formatted = "<dpInput>\n  <trs><rules /></trs>\n  <dps><rules /></dps>\n  <minimal>true</minimal>\n</dpInput>";
        let structural_key = format!("{:x}", Sha256::digest(compact.as_bytes()));
        let raw_key = format!("{:x}", Sha256::digest(formatted.as_bytes()));
        let manifest = format!(
            "{{\"schema\":\"{SCHEMA}\",\"problem_key\":\"{raw_key}\",\"avoid\":[\
             {{\"candidate\":\"graph\",\"status\":\"failed\",\"utility_score\":-10.0,\
             \"best_elapsed_ms\":1,\"attempts\":2,\"solved_count\":0,\
             \"transformed_count\":0,\"failed_count\":2,\"timeout_count\":0}},\
             {{\"candidate\":\"kbo(max-weight=2)\",\"status\":\"failed\",\
             \"utility_score\":-10.0,\"best_elapsed_ms\":1,\"attempts\":2,\
             \"solved_count\":0,\"transformed_count\":0,\"failed_count\":2,\
             \"timeout_count\":0}}]}}\n\
             {{\"schema\":\"{SCHEMA}\",\"problem_key\":\"{structural_key}\",\
             \"prefer\":[{{\"candidate\":\"graph\",\"status\":\"solved\",\
             \"utility_score\":100.0,\"best_elapsed_ms\":1,\"attempts\":1,\
             \"solved_count\":1,\"transformed_count\":0,\"failed_count\":0,\
             \"timeout_count\":0,\"certified_count\":1}}]}}\n"
        );
        let lookup = UtilityGuidanceLookup::from_reader(manifest.as_bytes()).unwrap();
        let prediction = lookup.predict(formatted).unwrap();
        assert_eq!(prediction.solved, ["graph"]);
        assert_eq!(prediction.failed, ["kbo(max-weight=2)"]);
    }

    #[test]
    fn alias_chains_are_order_independent_and_preserve_local_priority() {
        let row = |key: &str, target: Option<&str>, atom: &str| {
            let mut value = serde_json::json!({
                "schema": SCHEMA, "problem_key": key,
                "possible": [{"candidate": atom, "status": "transformed_weak",
                    "utility_score": 1.0, "best_elapsed_ms": 1, "attempts": 1,
                    "solved_count": 0, "transformed_count": 1,
                    "failed_count": 0, "timeout_count": 0}]
            });
            if let Some(target) = target {
                value["canonical_problem_key"] = target.into();
            }
            value.to_string()
        };
        let rows = [row("a", Some("b"), "graph"),
            row("b", Some("c"), "size-change"), row("c", None, "poly")];
        for order in [[0, 1, 2], [2, 1, 0], [1, 0, 2]] {
            let manifest = order.map(|i| rows[i].clone()).join("\n");
            let lookup = UtilityGuidanceLookup::from_reader(manifest.as_bytes()).unwrap();
            let actions: Vec<_> = lookup.entries["a"].possible.iter()
                .map(|candidate| candidate.candidate.as_ref()).collect();
            assert_eq!(actions, ["graph", "size-change", "poly"]);
        }
    }

    #[test]
    fn cyclic_and_duplicate_aliases_are_rejected() {
        let row = |key: &str, target: &str| serde_json::json!({
            "schema": SCHEMA, "problem_key": key, "canonical_problem_key": target
        }).to_string();
        let cycle = [row("a", "b"), row("b", "a")].join("\n");
        assert!(matches!(UtilityGuidanceLookup::from_reader(cycle.as_bytes()),
            Err(UtilityGuidanceError::AliasCycle { .. })));
        let duplicate = [row("a", "b"), row("a", "c")].join("\n");
        assert!(matches!(UtilityGuidanceLookup::from_reader(duplicate.as_bytes()),
            Err(UtilityGuidanceError::Duplicate { .. })));
    }

    #[test]
    fn canonical_state_positive_supersedes_a_distinct_stale_raw_alias() {
        let raw = "<dpInput><dps><rules><rule/></rules></dps></dpInput>";
        let canonical = "<dpInput><trs><rules/></trs><dps><rules><rule/></rules></dps><minimal>true</minimal></dpInput>";
        let raw_key = format!("{:x}", Sha256::digest(raw.as_bytes()));
        let canonical_key = format!("{:x}", Sha256::digest(canonical.as_bytes()));
        let manifest = format!(
            "{{\"schema\":\"{SCHEMA}\",\"problem_key\":\"{raw_key}\",\"possible\":[\
             {{\"candidate\":\"direct-loop\",\"status\":\"transformed_weak\",\
             \"utility_score\":1.0,\"best_elapsed_ms\":1,\"attempts\":1,\
             \"solved_count\":0,\"transformed_count\":1,\"failed_count\":0,\
             \"timeout_count\":0}}],\"avoid\":[{{\"candidate\":\"poly\",\
             \"status\":\"failed\",\"utility_score\":-10.0,\"best_elapsed_ms\":1,\
             \"attempts\":1,\"solved_count\":0,\"transformed_count\":0,\
             \"failed_count\":1,\"timeout_count\":0}}]}}\n\
             {{\"schema\":\"{SCHEMA}\",\"problem_key\":\"{canonical_key}\",\
             \"prefer\":[{{\"candidate\":\"poly\",\"status\":\"solved\",\
             \"utility_score\":100.0,\"best_elapsed_ms\":1,\"attempts\":1,\
             \"solved_count\":1,\"transformed_count\":0,\"failed_count\":0,\
             \"timeout_count\":0,\"certified_count\":1}}]}}\n"
        );
        let lookup = UtilityGuidanceLookup::from_reader(manifest.as_bytes()).unwrap();
        let prediction = lookup
            .predict_prefer_canonical(raw, canonical, true)
            .unwrap();
        assert_eq!(prediction.solved, ["poly"]);
        assert_eq!(prediction.transformed_weak, ["direct-loop"]);
        assert!(prediction.failed.is_empty());
    }

    #[test]
    fn current_checker_invalidation_shadows_structural_and_canonical_positives() {
        let raw = "<dpInput>\n  <dps><rules /></dps>\n</dpInput>";
        let structural = compact_xml_for_key(raw);
        let canonical =
            "<dpInput><trs><rules/></trs><dps><rules/></dps><minimal>true</minimal></dpInput>";
        let raw_key = format!("{:x}", Sha256::digest(raw.as_bytes()));
        let structural_key = format!("{:x}", Sha256::digest(structural.as_bytes()));
        let canonical_key = format!("{:x}", Sha256::digest(canonical.as_bytes()));
        let failed = "{\"candidate\":\"dp\",\"status\":\"failed\",\"utility_score\":-60.0,\"best_elapsed_ms\":1,\"attempts\":1,\"solved_count\":0,\"transformed_count\":0,\"failed_count\":1,\"timeout_count\":0}";
        let solved = "{\"candidate\":\"dp\",\"status\":\"solved\",\"utility_score\":100.0,\"best_elapsed_ms\":1,\"attempts\":1,\"solved_count\":1,\"transformed_count\":0,\"failed_count\":0,\"timeout_count\":0,\"certified_count\":1}";
        let manifest = format!(
            "{{\"schema\":\"{SCHEMA}\",\"problem_key\":\"{raw_key}\",\"current_checker_invalidation\":true,\"avoid\":[{failed}]}}\n\
             {{\"schema\":\"{SCHEMA}\",\"problem_key\":\"{structural_key}\",\"prefer\":[{solved}]}}\n\
             {{\"schema\":\"{SCHEMA}\",\"problem_key\":\"{canonical_key}\",\"prefer\":[{solved}]}}\n"
        );
        let lookup = UtilityGuidanceLookup::from_reader(manifest.as_bytes()).unwrap();
        let prediction = lookup
            .predict_prefer_canonical(raw, canonical, true)
            .unwrap();
        assert!(prediction.solved.is_empty());
        assert_eq!(prediction.failed, ["dp"]);
    }

    #[test]
    fn exact_replayable_action_precedes_new_canonical_candidates() {
        let raw = "<dpInput><dps><rules><rule/></rules></dps></dpInput>";
        let canonical = "<dpInput><trs><rules/></trs><dps><rules><rule/></rules></dps><minimal>true</minimal></dpInput>";
        let raw_key = format!("{:x}", Sha256::digest(raw.as_bytes()));
        let canonical_key = format!("{:x}", Sha256::digest(canonical.as_bytes()));
        let manifest = format!(
            "{{\"schema\":\"{SCHEMA}\",\"problem_key\":\"{raw_key}\",\"prefer\":[\
             {{\"candidate\":\"dp\",\"status\":\"solved\",\"utility_score\":1.0,\
             \"best_elapsed_ms\":10,\"attempts\":1,\"solved_count\":1,\
             \"transformed_count\":0,\"failed_count\":0,\"timeout_count\":0,\
             \"certified_count\":1}}]}}\n\
             {{\"schema\":\"{SCHEMA}\",\"problem_key\":\"{canonical_key}\",\"prefer\":[\
             {{\"candidate\":\"dp(graph;size-change)\",\"status\":\"solved\",\
             \"utility_score\":100.0,\"best_elapsed_ms\":1,\"attempts\":1,\
             \"solved_count\":1,\"transformed_count\":0,\"failed_count\":0,\
             \"timeout_count\":0,\"certified_count\":1}}]}}\n"
        );
        let lookup = UtilityGuidanceLookup::from_reader(manifest.as_bytes()).unwrap();
        let prediction = lookup
            .predict_prefer_canonical(raw, canonical, true)
            .unwrap();
        assert_eq!(prediction.solved, ["dp"]);
    }

    #[test]
    fn portable_canonical_exact_dp_precedes_stale_raw_dp() {
        let raw =
            "<trsInput><trs><rules><rule/></rules><strategy><full/></strategy></trs></trsInput>";
        let canonical = "<trsInput><trs><rules><rule/><rule/></rules><strategy><full/></strategy></trs></trsInput>";
        let raw_key = format!("{:x}", Sha256::digest(raw.as_bytes()));
        let canonical_key = format!("{:x}", Sha256::digest(canonical.as_bytes()));
        let manifest = format!(
            "{{\"schema\":\"{SCHEMA}\",\"problem_key\":\"{raw_key}\",\"prefer\":[\
             {{\"candidate\":\"dp\",\"status\":\"transformed_strong\",\
             \"utility_score\":10.0,\"best_elapsed_ms\":1,\"attempts\":1,\
             \"solved_count\":0,\"transformed_count\":1,\"failed_count\":0,\
             \"timeout_count\":0,\"certified_count\":1}}]}}\n\
             {{\"schema\":\"{SCHEMA}\",\"problem_key\":\"{canonical_key}\",\"prefer\":[\
             {{\"candidate\":\"exact-dp(hex=00)\",\"status\":\"transformed_strong\",\
             \"utility_score\":100.0,\"best_elapsed_ms\":1,\"attempts\":1,\
             \"solved_count\":0,\"transformed_count\":1,\"failed_count\":0,\
             \"timeout_count\":0,\"certified_count\":1}}]}}\n"
        );
        let lookup = UtilityGuidanceLookup::from_reader(manifest.as_bytes()).unwrap();
        let prediction = lookup
            .predict_prefer_canonical(raw, canonical, true)
            .unwrap();
        assert_eq!(prediction.ordered_positive, ["exact-dp(hex=00)", "dp"]);
    }

    #[test]
    fn semantic_canonical_fallback_does_not_transport_exact_witnesses() {
        let raw = "<dpInput><dps><rules><rule/></rules></dps></dpInput>";
        let canonical = "<dpInput><trs><rules/></trs><dps><rules><rule/></rules></dps><minimal>true</minimal></dpInput>";
        let canonical_key = format!("{:x}", Sha256::digest(canonical.as_bytes()));
        let manifest = format!(
            "{{\"schema\":\"{SCHEMA}\",\"problem_key\":\"{canonical_key}\",\"prefer\":[\
             {{\"candidate\":\"exact-poly(hex=00)\",\"status\":\"solved\",\
             \"utility_score\":100.0,\"best_elapsed_ms\":1,\"attempts\":1,\
             \"solved_count\":1,\"transformed_count\":0,\"failed_count\":0,\
             \"timeout_count\":0,\"certified_count\":1}},\
             {{\"candidate\":\"graph\",\"status\":\"transformed_strong\",\
             \"utility_score\":10.0,\"best_elapsed_ms\":1,\"attempts\":1,\
             \"solved_count\":0,\"transformed_count\":1,\"failed_count\":0,\
             \"timeout_count\":0,\"certified_count\":1}}]}}\n"
        );
        let lookup = UtilityGuidanceLookup::from_reader(manifest.as_bytes()).unwrap();
        let prediction = lookup
            .predict_prefer_canonical(raw, canonical, true)
            .unwrap();
        assert_eq!(prediction.ordered_positive, ["graph"]);
        assert!(prediction.solved.is_empty());
        assert_eq!(prediction.transformed_strong, ["graph"]);
    }

    #[test]
    fn semantic_canonical_fallback_transports_self_relocating_exact_processors() {
        let raw = "<dpInput><dps><rules><rule/></rules></dps></dpInput>";
        let canonical = "<dpInput><trs><rules/></trs><dps><rules><rule/></rules></dps><minimal>true</minimal></dpInput>";
        let canonical_key = format!("{:x}", Sha256::digest(canonical.as_bytes()));
        let candidate = |name: &str| {
            format!(
                "{{\"candidate\":\"{name}\",\"status\":\"transformed_strong\",\
                 \"utility_score\":100.0,\"best_elapsed_ms\":1,\"attempts\":1,\
                 \"solved_count\":0,\"transformed_count\":1,\"failed_count\":0,\
                 \"timeout_count\":0,\"certified_count\":1}}"
            )
        };
        let manifest = format!(
            "{{\"schema\":\"{SCHEMA}\",\"problem_key\":\"{canonical_key}\",\"prefer\":[{},{},{},{},{},{},{}]}}\n",
            candidate("exact-red-pair(hex=00)"),
            candidate("exact-graph(hex=00)"),
            candidate("exact-usable-rules(hex=00)"),
            candidate("exact-dp-transform(hex=00)"),
            candidate("exact-semantic-labeling(hex=00)"),
            candidate("exact-size-change(hex=00)"),
            candidate("exact-innermost-lhss(hex=00)"),
        );
        let lookup = UtilityGuidanceLookup::from_reader(manifest.as_bytes()).unwrap();
        let prediction = lookup
            .predict_prefer_canonical(raw, canonical, true)
            .unwrap();
        assert_eq!(
            prediction.ordered_positive,
            [
                "exact-red-pair(hex=00)",
                "exact-graph(hex=00)",
                "exact-usable-rules(hex=00)",
                "exact-dp-transform(hex=00)",
                "exact-semantic-labeling(hex=00)",
                "exact-size-change(hex=00)",
                "exact-innermost-lhss(hex=00)",
            ]
        );
    }

    #[test]
    fn semantic_core_rejects_generic_transformations_but_keeps_recomputed_terminals() {
        let canonical = "<dpInput><trs><rules/></trs><dps><rules><rule/></rules></dps><minimal>true</minimal></dpInput>";
        let canonical_key = format!("{:x}", Sha256::digest(canonical.as_bytes()));
        let manifest = format!(
            "{{\"schema\":\"{SCHEMA}\",\"problem_key\":\"{canonical_key}\",\"prefer\":[\
             {{\"candidate\":\"usable-rules\",\"status\":\"transformed_strong\",\"utility_score\":30.0,\"best_elapsed_ms\":1,\"attempts\":1,\"solved_count\":0,\"transformed_count\":1,\"failed_count\":0,\"timeout_count\":0,\"certified_count\":1}},\
             {{\"candidate\":\"size-change\",\"status\":\"solved\",\"utility_score\":20.0,\"best_elapsed_ms\":1,\"attempts\":1,\"solved_count\":1,\"transformed_count\":0,\"failed_count\":0,\"timeout_count\":0,\"certified_count\":1}},\
             {{\"candidate\":\"subterm\",\"status\":\"solved\",\"utility_score\":10.0,\"best_elapsed_ms\":1,\"attempts\":1,\"solved_count\":1,\"transformed_count\":0,\"failed_count\":0,\"timeout_count\":0,\"certified_count\":1}}]}}\n"
        );
        let lookup = UtilityGuidanceLookup::from_reader(manifest.as_bytes()).unwrap();
        let prediction = lookup.predict_semantic_canonical(canonical, true).unwrap();
        assert_eq!(prediction.ordered_positive, ["size-change", "subterm"]);
        assert!(prediction.transformed_strong.is_empty());
        assert_eq!(prediction.solved, ["size-change", "subterm"]);
    }

    #[test]
    fn manifest_alias_inherits_generic_but_not_exact_candidates() {
        let canonical = "<dpInput><dps><rules/></dps></dpInput>";
        let alias =
            "<dpInput><dps><rules/><ferrumAliasSymbol>g</ferrumAliasSymbol></dps></dpInput>";
        let canonical_key = format!("{:x}", Sha256::digest(canonical.as_bytes()));
        let alias_key = format!("{:x}", Sha256::digest(alias.as_bytes()));
        let manifest = format!(
            "{{\"schema\":\"{SCHEMA}\",\"problem_key\":\"{canonical_key}\",\"prefer\":[\
             {{\"candidate\":\"exact-path-order(hex=00)\",\"status\":\"solved\",\
             \"utility_score\":100.0,\"best_elapsed_ms\":1,\"attempts\":1,\
             \"solved_count\":1,\"transformed_count\":0,\"failed_count\":0,\
             \"timeout_count\":0,\"certified_count\":1}},\
             {{\"candidate\":\"size-change\",\"status\":\"solved\",\
             \"utility_score\":10.0,\"best_elapsed_ms\":1,\"attempts\":1,\
             \"solved_count\":1,\"transformed_count\":0,\"failed_count\":0,\
             \"timeout_count\":0,\"certified_count\":1}}]}}\n\
             {{\"schema\":\"{SCHEMA}\",\"problem_key\":\"{alias_key}\",\
             \"canonical_problem_key\":\"{canonical_key}\"}}\n"
        );
        let lookup = UtilityGuidanceLookup::from_reader(manifest.as_bytes()).unwrap();
        assert_eq!(lookup.predict(alias).unwrap().solved, ["size-change"]);
    }

    #[test]
    fn canonical_lookup_keeps_self_relocating_exact_dp_transformation() {
        let raw = "<dpInput><dps><rules/><ferrumLiveState/></dps></dpInput>";
        let canonical = "<dpInput><dps><rules/></dps></dpInput>";
        let canonical_key = format!("{:x}", Sha256::digest(canonical.as_bytes()));
        let candidate = "exact-dp-transform(hex=5b5d)";
        let manifest = format!(
            "{{\"schema\":\"{SCHEMA}\",\"problem_key\":\"{canonical_key}\",\
             \"prefer\":[{{\"candidate\":\"{candidate}\",\
             \"status\":\"transformed_strong\",\"utility_score\":1200.0,\
             \"best_elapsed_ms\":1,\"attempts\":1,\"solved_count\":0,\
             \"transformed_count\":1,\"failed_count\":0,\
             \"timeout_count\":0,\"certified_count\":1}}]}}\n"
        );
        let lookup = UtilityGuidanceLookup::from_reader(manifest.as_bytes()).unwrap();

        let prediction = lookup
            .predict_prefer_canonical(raw, canonical, true)
            .unwrap();

        assert_eq!(prediction.transformed_strong, [candidate]);
        assert_eq!(prediction.ordered_positive, [candidate]);
    }

    #[test]
    fn canonical_lookup_allows_checked_q_subset_choices_not_index_witnesses() {
        assert!(super::is_portable_exact_candidate("exact-innermost-lhss(hex=00)", false));
        assert!(super::is_portable_exact_candidate("usable-rules", false));
        assert!(super::is_portable_exact_candidate("instantiate", false));
        assert!(super::is_portable_exact_candidate("exact-size-change(hex=00)", false));
        assert!(!super::is_portable_exact_candidate("exact-subterm(hex=00)", false));
    }

    #[test]
    fn structural_alias_inherits_exact_candidates() {
        let canonical = "<dpInput><dps><rules/></dps></dpInput>";
        let alias = "<dpInput><dps><rules/><ferrumStructuralAlias>g</ferrumStructuralAlias></dps></dpInput>";
        let canonical_key = format!("{:x}", Sha256::digest(canonical.as_bytes()));
        let alias_key = format!("{:x}", Sha256::digest(alias.as_bytes()));
        let manifest = format!(
            "{{\"schema\":\"{SCHEMA}\",\"problem_key\":\"{canonical_key}\",\"prefer\":[\
             {{\"candidate\":\"exact-path-order(hex=00)\",\"status\":\"solved\",\
             \"utility_score\":100.0,\"best_elapsed_ms\":1,\"attempts\":1,\
             \"solved_count\":1,\"transformed_count\":0,\"failed_count\":0,\
             \"timeout_count\":0,\"certified_count\":1}}]}}\n\
             {{\"schema\":\"{SCHEMA}\",\"problem_key\":\"{alias_key}\",\
             \"canonical_problem_key\":\"{canonical_key}\",\"alias_kind\":\"structural\"}}\n"
        );
        let lookup = UtilityGuidanceLookup::from_reader(manifest.as_bytes()).unwrap();
        assert_eq!(
            lookup.predict(alias).unwrap().solved,
            ["exact-path-order(hex=00)"]
        );
    }

    #[test]
    fn structural_alias_local_exact_action_shadows_canonical_exact_alternatives() {
        let canonical = "<dpInput><dps><rules/></dps></dpInput>";
        let alias = "<dpInput><dps><rules/><ferrumStructuralAlias>g</ferrumStructuralAlias></dps></dpInput>";
        let canonical_key = format!("{:x}", Sha256::digest(canonical.as_bytes()));
        let alias_key = format!("{:x}", Sha256::digest(alias.as_bytes()));
        let manifest = format!(
            "{{\"schema\":\"{SCHEMA}\",\"problem_key\":\"{canonical_key}\",\"prefer\":[\
             {{\"candidate\":\"exact-red-pair(hex=01)\",\"status\":\"solved\",\
             \"utility_score\":100.0,\"best_elapsed_ms\":1,\"attempts\":1,\
             \"solved_count\":1,\"transformed_count\":0,\"failed_count\":0,\
             \"timeout_count\":0,\"certified_count\":1}},\
             {{\"candidate\":\"graph\",\"status\":\"transformed_strong\",\
             \"utility_score\":10.0,\"best_elapsed_ms\":1,\"attempts\":1,\
             \"solved_count\":0,\"transformed_count\":1,\"failed_count\":0,\
             \"timeout_count\":0,\"certified_count\":1}}]}}\n\
             {{\"schema\":\"{SCHEMA}\",\"problem_key\":\"{alias_key}\",\
             \"canonical_problem_key\":\"{canonical_key}\",\"alias_kind\":\"structural\",\
             \"prefer\":[{{\"candidate\":\"exact-red-pair(hex=02)\",\
             \"status\":\"solved\",\"utility_score\":200.0,\"best_elapsed_ms\":1,\
             \"attempts\":1,\"solved_count\":1,\"transformed_count\":0,\
             \"failed_count\":0,\"timeout_count\":0,\"certified_count\":1}}]}}\n"
        );
        let lookup = UtilityGuidanceLookup::from_reader(manifest.as_bytes()).unwrap();
        let prediction = lookup.predict(alias).unwrap();
        assert_eq!(prediction.solved, ["exact-red-pair(hex=02)"]);
        assert_eq!(prediction.transformed_strong, ["graph"]);
        assert_eq!(
            prediction.ordered_positive,
            ["exact-red-pair(hex=02)", "graph"]
        );
    }

    #[test]
    fn resolves_content_addressed_exact_witnesses() {
        let cpf = "<dpInput><dps><rules/></dps></dpInput>";
        let key = format!("{:x}", Sha256::digest(cpf.as_bytes()));
        let exact = "exact-poly(hex=00)";
        let witness_id = format!("{:x}", Sha256::digest(exact.as_bytes()));
        let manifest = format!(
            "{{\"schema\":\"{WITNESS_SCHEMA}\",\"witness_id\":\"{witness_id}\",\
             \"candidate\":\"{exact}\"}}\n\
             {{\"schema\":\"{SCHEMA}\",\"problem_key\":\"{key}\",\"prefer\":[\
             {{\"candidate_ref\":\"{witness_id}\",\"status\":\"solved\",\
             \"utility_score\":100.0,\"best_elapsed_ms\":1,\"attempts\":1,\
             \"solved_count\":1,\"transformed_count\":0,\"failed_count\":0,\
             \"timeout_count\":0,\"certified_count\":1}}]}}\n"
        );
        let lookup = UtilityGuidanceLookup::from_reader(manifest.as_bytes()).unwrap();
        assert_eq!(lookup.predict(cpf).unwrap().solved, [exact]);
    }

    #[test]
    fn does_not_invent_unrecorded_tighter_parameters() {
        let cpf = "<dpInput><dps><rules/></dps></dpInput>";
        let key = format!("{:x}", Sha256::digest(cpf.as_bytes()));
        let manifest = format!(
            "{{\"schema\":\"ferrum.utility-guidance.v2\",\"problem_key\":\"{key}\",\
             \"prefer\":[{{\"candidate\":\"poly(max-constant=2,max-coefficient=2)\",\
             \"status\":\"solved\",\"utility_score\":42.0,\"best_elapsed_ms\":3,\
             \"attempts\":2,\"solved_count\":2,\"transformed_count\":0,\
             \"failed_count\":0,\"timeout_count\":0,\"certified_count\":1}}],\"possible\":[],\
             \"avoid\":[],\"timeout\":[]}}\n"
        );
        let lookup = UtilityGuidanceLookup::from_reader(Cursor::new(manifest)).unwrap();
        let prediction = lookup.predict(cpf).unwrap();
        assert_eq!(
            prediction.solved,
            ["poly(max-constant=2,max-coefficient=2)"]
        );
    }

    #[test]
    fn exposes_every_positive_candidate_in_ranked_order() {
        let cpf = "<dpInput><dps><rules/></dps></dpInput>";
        let key = format!("{:x}", Sha256::digest(cpf.as_bytes()));
        let manifest = format!(
            "{{\"schema\":\"ferrum.utility-guidance.v2\",\"problem_key\":\"{key}\",\
             \"prefer\":[\
             {{\"candidate\":\"subterm\",\"status\":\"solved\",\
             \"utility_score\":42.0,\"best_elapsed_ms\":3,\"attempts\":1,\
             \"solved_count\":1,\"transformed_count\":0,\"failed_count\":0,\
             \"timeout_count\":0}},\
             {{\"candidate\":\"sct\",\"status\":\"solved\",\
             \"utility_score\":41.0,\"best_elapsed_ms\":4,\"attempts\":1,\
             \"solved_count\":1,\"transformed_count\":0,\"failed_count\":0,\
             \"timeout_count\":0}},\
             {{\"candidate\":\"usable-rules\",\
             \"status\":\"transformed_strong\",\"utility_score\":40.0,\
             \"best_elapsed_ms\":5,\"attempts\":1,\"solved_count\":0,\
             \"transformed_count\":1,\"failed_count\":0,\"timeout_count\":0}}],\
             \"possible\":[{{\"candidate\":\"graph\",\
             \"status\":\"transformed_weak\",\"utility_score\":39.0,\
             \"best_elapsed_ms\":6,\"attempts\":1,\"solved_count\":0,\
             \"transformed_count\":1,\"failed_count\":0,\"timeout_count\":0}}],\
             \"avoid\":[],\"timeout\":[]}}\n"
        );
        let lookup = UtilityGuidanceLookup::from_reader(Cursor::new(manifest)).unwrap();
        let prediction = lookup.predict(cpf).unwrap();
        assert_eq!(prediction.solved, ["subterm", "sct"]);
        assert_eq!(prediction.transformed_strong, ["usable-rules"]);
        assert_eq!(prediction.transformed_weak, ["graph"]);
        assert_eq!(
            prediction.ordered_positive,
            ["subterm", "sct", "usable-rules", "graph"]
        );
    }

    #[test]
    fn oracle_order_is_not_regrouped_by_evidence_status() {
        let cpf = "<dpInput><dps><rules/></dps></dpInput>";
        let key = format!("{:x}", Sha256::digest(cpf.as_bytes()));
        let candidate = |name: &str, status: &str| {
            format!(
                "{{\"candidate\":\"{name}\",\"status\":\"{status}\",\
             \"utility_score\":1.0,\"best_elapsed_ms\":1,\"attempts\":1,\
             \"solved_count\":1,\"transformed_count\":1,\"failed_count\":0,\
             \"timeout_count\":0,\"certified_count\":1}}"
            )
        };
        let manifest = format!(
            "{{\"schema\":\"{SCHEMA}\",\"problem_key\":\"{key}\",\"prefer\":[{},{}]}}\n",
            candidate("graph", "transformed_strong"),
            candidate("size-change", "solved"),
        );
        let lookup = UtilityGuidanceLookup::from_reader(manifest.as_bytes()).unwrap();
        assert_eq!(
            lookup.predict(cpf).unwrap().ordered_positive,
            ["graph", "size-change"]
        );
    }

    #[test]
    fn negative_only_state_is_a_hit_with_avoidance_evidence() {
        let cpf = "<dpInput><dps><rules/></dps></dpInput>";
        let key = format!("{:x}", Sha256::digest(cpf.as_bytes()));
        let manifest = format!(
            "{{\"schema\":\"ferrum.utility-guidance.v2\",\"problem_key\":\"{key}\",\
             \"prefer\":[],\"possible\":[],\"avoid\":[{{\"candidate\":\"kbo(max-weight=2)\",\
             \"status\":\"failed\",\"utility_score\":-120.0,\"best_elapsed_ms\":9,\
             \"attempts\":2,\"solved_count\":0,\"transformed_count\":0,\
             \"failed_count\":2,\"timeout_count\":0}}],\"timeout\":[{{\"candidate\":\
             \"matrix(dim=2,max-constant=2,max-coefficient=1)\",\"status\":\"timeout\",\
             \"utility_score\":-400.0,\"best_elapsed_ms\":null,\"attempts\":1,\
             \"solved_count\":0,\"transformed_count\":0,\"failed_count\":0,\
             \"timeout_count\":1}}]}}\n"
        );
        let lookup = UtilityGuidanceLookup::from_reader(Cursor::new(manifest)).unwrap();
        let prediction = lookup.predict(cpf).unwrap();
        assert!(prediction.solved.is_empty());
        assert_eq!(prediction.failed, ["kbo(max-weight=2)"]);
        assert_eq!(
            prediction.timeout,
            ["matrix(dim=2,max-constant=2,max-coefficient=1)"]
        );
    }

    #[test]
    fn raw_alias_uses_canonical_evidence_without_canonicalizing() {
        let canonical = "<trsInput><trs><rules/></trs></trsInput>";
        let raw = "<trsInput><trs><rules><rule/></rules></trs></trsInput>";
        let canonical_key = format!("{:x}", Sha256::digest(canonical.as_bytes()));
        let raw_key = format!("{:x}", Sha256::digest(raw.as_bytes()));
        let manifest = format!(
            "{{\"schema\":\"ferrum.utility-guidance.v2\",\"problem_key\":\"{canonical_key}\",\
             \"prefer\":[{{\"candidate\":\"poly(max-constant=1,max-coefficient=1)\",\
             \"status\":\"solved\",\"utility_score\":10.0,\"best_elapsed_ms\":4,\
             \"attempts\":1,\"solved_count\":1,\"transformed_count\":0,\
             \"failed_count\":0,\"timeout_count\":0}}],\"possible\":[],\"avoid\":[],\
             \"timeout\":[]}}\n\
             {{\"schema\":\"ferrum.utility-guidance.v2\",\"problem_key\":\"{raw_key}\",\
             \"canonical_problem_key\":\"{canonical_key}\"}}\n"
        );
        let lookup = UtilityGuidanceLookup::from_reader(Cursor::new(manifest)).unwrap();
        let prediction = lookup.predict(raw).unwrap();
        assert_eq!(
            prediction.solved,
            ["poly(max-constant=1,max-coefficient=1)"]
        );
    }

    #[test]
    fn raw_alias_retains_exact_evidence_before_canonical_evidence() {
        let canonical = "<trsInput><trs><rules/></trs></trsInput>";
        let raw = "<trsInput><trs><rules><rule/></rules></trs></trsInput>";
        let canonical_key = format!("{:x}", Sha256::digest(canonical.as_bytes()));
        let raw_key = format!("{:x}", Sha256::digest(raw.as_bytes()));
        let candidate = |name: &str, status: &str| {
            format!(
                "{{\"candidate\":\"{name}\",\"status\":\"{status}\",\
                 \"utility_score\":10.0,\"best_elapsed_ms\":1,\"attempts\":1,\
                 \"solved_count\":1,\"transformed_count\":0,\"failed_count\":0,\
                 \"timeout_count\":0,\"certified_count\":1}}"
            )
        };
        let manifest = format!(
            "{{\"schema\":\"{SCHEMA}\",\"problem_key\":\"{canonical_key}\",\
             \"prefer\":[{}]}}\n\
             {{\"schema\":\"{SCHEMA}\",\"problem_key\":\"{raw_key}\",\
             \"canonical_problem_key\":\"{canonical_key}\",\"prefer\":[{}]}}\n",
            candidate("canonical-poly", "solved"),
            candidate("exact-poly", "solved"),
        );
        let lookup = UtilityGuidanceLookup::from_reader(Cursor::new(manifest)).unwrap();
        assert_eq!(
            lookup.predict(raw).unwrap().solved,
            ["exact-poly", "canonical-poly"]
        );
    }

    #[test]
    fn misses_unknown_cpf() {
        let lookup = UtilityGuidanceLookup::from_reader(Cursor::new("")).unwrap();
        assert!(lookup.predict("<trsInput/>").is_none());
    }
}
