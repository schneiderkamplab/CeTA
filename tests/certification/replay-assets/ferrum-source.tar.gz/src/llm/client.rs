use std::path::{Path, PathBuf};
use std::process::{Child, Command, Stdio};
use std::sync::{Arc, Mutex};
use std::thread::sleep;
use std::time::Duration;
use std::{fmt, net::TcpListener};

use reqwest::blocking::Client;
use serde::{Deserialize, Serialize};
use thiserror::Error;

use crate::proving::{configure_managed_child, terminate_child_process_group};

use super::{LlmProposal, StatusMapPrediction, parse_proposal_batch, parse_status_map_prediction};

#[derive(Clone, Debug, Deserialize, Serialize, PartialEq)]
pub struct LlmApiConfig {
    pub endpoint: String,
    pub model: String,
    #[serde(default = "default_temperature")]
    pub temperature: f64,
    #[serde(default = "default_max_tokens")]
    pub max_tokens: usize,
}

#[derive(Clone, Debug)]
pub struct LlmClient {
    config: LlmApiConfig,
    http: Client,
    _server: Option<Arc<ManagedServerProcess>>,
}

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub enum LlmBackend {
    Vllm,
    Mlx,
    TransformersCpu,
}

impl LlmBackend {
    fn server_label(self) -> &'static str {
        match self {
            Self::Vllm => "vLLM",
            Self::Mlx => "MLX",
            Self::TransformersCpu => "Transformers CPU",
        }
    }
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct LocalLlmConfig {
    pub model_dir: PathBuf,
    pub backend: LlmBackend,
}

struct ManagedServerProcess {
    label: &'static str,
    child: Mutex<Child>,
}

impl fmt::Debug for ManagedServerProcess {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("ManagedServerProcess")
            .field("label", &self.label)
            .finish_non_exhaustive()
    }
}

impl Drop for ManagedServerProcess {
    fn drop(&mut self) {
        if let Ok(child) = self.child.get_mut() {
            terminate_child_process_group(child);
            let _ = child.wait();
        }
    }
}

#[derive(Debug, Error)]
pub enum LlmClientError {
    #[error("LLM model directory does not exist: {0}")]
    ModelDirectoryMissing(String),

    #[error("LLM HTTP request failed: {0}")]
    Http(#[from] reqwest::Error),

    #[error("failed to choose a local LLM server port: {0}")]
    Port(std::io::Error),

    #[error("failed to start local {backend} server: {source}")]
    StartServer {
        backend: &'static str,
        source: std::io::Error,
    },

    #[error("local {0} server exited before becoming ready")]
    ServerExited(&'static str),

    #[error("local {0} server did not become ready within the startup timeout")]
    ServerTimeout(&'static str),

    #[error("LLM response did not contain proposal JSON")]
    MissingProposalJson,

    #[error("invalid LLM proposal JSON: {0}")]
    Proposal(String),
}

impl LlmClient {
    pub fn from_model_dir(path: &Path) -> Result<Self, LlmClientError> {
        Self::from_local_config(LocalLlmConfig {
            model_dir: path.to_path_buf(),
            backend: LlmBackend::Vllm,
        })
    }

    pub fn from_local_config(local: LocalLlmConfig) -> Result<Self, LlmClientError> {
        if !local.model_dir.is_dir() {
            return Err(LlmClientError::ModelDirectoryMissing(
                local.model_dir.display().to_string(),
            ));
        }
        let port = choose_local_port().map_err(LlmClientError::Port)?;
        let model = local.model_dir.display().to_string();
        let backend_label = local.backend.server_label();
        let child = server_command(&local, port)
            .stdout(Stdio::null())
            .stderr(Stdio::null())
            .spawn()
            .map_err(|source| LlmClientError::StartServer {
                backend: backend_label,
                source,
            })?;
        let config = LlmApiConfig {
            endpoint: format!("http://127.0.0.1:{port}/v1/chat/completions"),
            model,
            temperature: default_temperature(),
            max_tokens: default_max_tokens(),
        };
        let http = Client::builder()
            .timeout(Duration::from_secs(120))
            .build()?;
        let server = Arc::new(ManagedServerProcess {
            label: backend_label,
            child: Mutex::new(child),
        });
        wait_for_server(&http, port, &server)?;
        Ok(Self {
            config,
            http,
            _server: Some(server),
        })
    }

    pub fn from_config(config: LlmApiConfig) -> Result<Self, LlmClientError> {
        let http = Client::builder()
            .timeout(Duration::from_secs(120))
            .build()?;
        Ok(Self {
            config,
            http,
            _server: None,
        })
    }

    pub fn request_proposals(&self, prompt: &str) -> Result<Vec<LlmProposal>, LlmClientError> {
        let request = self
            .http
            .post(&self.config.endpoint)
            .json(&ChatCompletionRequest {
                model: &self.config.model,
                temperature: self.config.temperature,
                max_tokens: self.config.max_tokens,
                messages: vec![ChatMessage {
                    role: "user",
                    content: prompt,
                }],
            });
        let response = request
            .send()?
            .error_for_status()?
            .json::<ChatCompletionResponse>()?;
        let content = response
            .choices
            .first()
            .map(|choice| choice.message.content.as_str())
            .ok_or(LlmClientError::MissingProposalJson)?;
        let json = extract_json_object(content).ok_or(LlmClientError::MissingProposalJson)?;
        parse_proposal_batch(json)
            .map(|batch| batch.candidates)
            .map_err(|error| LlmClientError::Proposal(error.to_string()))
    }

    pub fn request_status_map(
        &self,
        cpf_input: &str,
    ) -> Result<StatusMapPrediction, LlmClientError> {
        let prompt = format!("[BOS]<input>\n{}\n</input>[SEP]", cpf_input.trim());
        let request = self
            .http
            .post(completions_endpoint(&self.config.endpoint))
            .json(&CompletionRequest {
                model: &self.config.model,
                prompt: &prompt,
                temperature: self.config.temperature,
                max_tokens: self.config.max_tokens.min(96),
                stop: vec!["[EOS]"],
            });
        let response = request
            .send()?
            .error_for_status()?
            .json::<CompletionResponse>()?;
        let content = response
            .choices
            .first()
            .map(|choice| choice.text.as_str())
            .ok_or(LlmClientError::MissingProposalJson)?;
        Ok(parse_status_map_prediction(content))
    }
}

fn completions_endpoint(chat_endpoint: &str) -> String {
    chat_endpoint
        .strip_suffix("/chat/completions")
        .map(|prefix| format!("{prefix}/completions"))
        .unwrap_or_else(|| chat_endpoint.to_string())
}

fn choose_local_port() -> Result<u16, std::io::Error> {
    let listener = TcpListener::bind(("127.0.0.1", 0))?;
    Ok(listener.local_addr()?.port())
}

fn server_command(local: &LocalLlmConfig, port: u16) -> Command {
    let mut command = match local.backend {
        LlmBackend::Vllm => {
            let mut command = Command::new("vllm");
            command
                .arg("serve")
                .arg(&local.model_dir)
                .arg("--host")
                .arg("127.0.0.1")
                .arg("--port")
                .arg(port.to_string())
                .arg("--gpu-memory-utilization")
                .arg("0.20");
            command
        }
        LlmBackend::Mlx => {
            let mut command = Command::new("python");
            command
                .arg(mlx_server_script())
                .arg("--model-dir")
                .arg(&local.model_dir)
                .arg("--host")
                .arg("127.0.0.1")
                .arg("--port")
                .arg(port.to_string());
            command
        }
        LlmBackend::TransformersCpu => {
            let mut command = Command::new("python");
            command
                .env("CUDA_VISIBLE_DEVICES", "")
                .arg(transformers_cpu_server_script())
                .arg("--model-dir")
                .arg(&local.model_dir)
                .arg("--host")
                .arg("127.0.0.1")
                .arg("--port")
                .arg(port.to_string());
            command
        }
    };
    configure_managed_child(&mut command);
    command
}

fn mlx_server_script() -> PathBuf {
    PathBuf::from(env!("CARGO_MANIFEST_DIR")).join("scripts/mlx_openai_server.py")
}

fn transformers_cpu_server_script() -> PathBuf {
    PathBuf::from(env!("CARGO_MANIFEST_DIR")).join("scripts/transformers_cpu_openai_server.py")
}

fn wait_for_server(
    http: &Client,
    port: u16,
    server: &Arc<ManagedServerProcess>,
) -> Result<(), LlmClientError> {
    let models_url = format!("http://127.0.0.1:{port}/v1/models");
    for _ in 0..600 {
        if let Ok(mut child) = server.child.lock()
            && child
                .try_wait()
                .map_err(|source| LlmClientError::StartServer {
                    backend: server.label,
                    source,
                })?
                .is_some()
        {
            return Err(LlmClientError::ServerExited(server.label));
        }
        if http
            .get(&models_url)
            .send()
            .and_then(|response| response.error_for_status())
            .is_ok()
        {
            return Ok(());
        }
        sleep(Duration::from_millis(500));
    }
    Err(LlmClientError::ServerTimeout(server.label))
}

fn default_temperature() -> f64 {
    0.0
}

fn default_max_tokens() -> usize {
    2048
}

#[derive(Serialize)]
struct ChatCompletionRequest<'a> {
    model: &'a str,
    temperature: f64,
    max_tokens: usize,
    messages: Vec<ChatMessage<'a>>,
}

#[derive(Serialize)]
struct CompletionRequest<'a> {
    model: &'a str,
    prompt: &'a str,
    temperature: f64,
    max_tokens: usize,
    stop: Vec<&'a str>,
}

#[derive(Serialize)]
struct ChatMessage<'a> {
    role: &'a str,
    content: &'a str,
}

#[derive(Deserialize)]
struct ChatCompletionResponse {
    choices: Vec<ChatChoice>,
}

#[derive(Deserialize)]
struct ChatChoice {
    message: ChatChoiceMessage,
}

#[derive(Deserialize)]
struct ChatChoiceMessage {
    content: String,
}

#[derive(Deserialize)]
struct CompletionResponse {
    choices: Vec<CompletionChoice>,
}

#[derive(Deserialize)]
struct CompletionChoice {
    text: String,
}

fn extract_json_object(input: &str) -> Option<&str> {
    let start = input.find('{')?;
    let mut depth = 0usize;
    let mut in_string = false;
    let mut escaped = false;
    for (offset, ch) in input[start..].char_indices() {
        if escaped {
            escaped = false;
            continue;
        }
        match ch {
            '\\' if in_string => escaped = true,
            '"' => in_string = !in_string,
            '{' if !in_string => depth += 1,
            '}' if !in_string => {
                depth -= 1;
                if depth == 0 {
                    return Some(&input[start..=start + offset]);
                }
            }
            _ => {}
        }
    }
    None
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn extracts_json_from_markdown_fence() {
        let input = "```json\n{\"candidates\":[]}\n```";
        assert_eq!(extract_json_object(input), Some("{\"candidates\":[]}"));
    }
}
