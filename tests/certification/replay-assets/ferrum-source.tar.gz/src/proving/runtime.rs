use std::collections::HashSet;
use std::fs::OpenOptions;
use std::io::{self, Read, Write};
#[cfg(unix)]
use std::os::unix::process::CommandExt;
use std::path::{Component, Path, PathBuf};
use std::process::{Child, Command, Output, Stdio};
use std::sync::{
    Arc, Mutex, OnceLock,
    atomic::{AtomicBool, Ordering},
};
use std::thread;
use std::time::{Duration, Instant};

use serde_json::{Value, json};
use sha2::{Digest, Sha256};

static PROGRESS_LOG_LOCK: OnceLock<Mutex<()>> = OnceLock::new();
static PROCESSOR_EVENT_LOG_LOCK: OnceLock<Mutex<()>> = OnceLock::new();
static PROCESSOR_EVENT_LOG_PATH: OnceLock<PathBuf> = OnceLock::new();
static PROCESSOR_EVENT_STATE_KEYS: OnceLock<Mutex<HashSet<String>>> = OnceLock::new();

pub(crate) type CancellationFlag = Arc<AtomicBool>;

/// Allocate state-local oracle search time without changing evidence credit.
/// The optional replay multiplier compensates for loaded machines; the parent
/// deadline still wins. Normal runs retain the 300-second local ceiling;
/// explicitly long replay campaigns may raise it, at most to one hour.
pub(crate) fn measured_oracle_atom_timeout(base: Duration, measured_ms: Option<u64>) -> Duration {
    let percent = std::env::var("FERRUM_ORACLE_TIME_SCALE_PERCENT").ok()
        .and_then(|value| value.parse::<u64>().ok()).filter(|value| *value >= 100)
        .unwrap_or(100);
    let max_ms = std::env::var("FERRUM_ORACLE_ATOM_MAX_SECONDS").ok()
        .and_then(|value| value.parse::<u64>().ok())
        .filter(|value| (1..=3600).contains(value)).unwrap_or(300) * 1000;
    oracle_atom_timeout_with_cap(base, measured_ms, percent, max_ms)
}

#[cfg(test)]
fn oracle_atom_timeout_with_scale(base: Duration, measured_ms: Option<u64>, percent: u64) -> Duration {
    oracle_atom_timeout_with_cap(base, measured_ms, percent, 300_000)
}

fn oracle_atom_timeout_with_cap(base: Duration, measured_ms: Option<u64>, percent: u64, max_ms: u64) -> Duration {
    let learned = measured_ms.map(|ms| ms.saturating_add(ms / 5 + u64::from(ms % 5 != 0)))
        .unwrap_or(0);
    let baseline = base.as_millis().min(max_ms as u128) as u64;
    let scaled = baseline.max(learned).saturating_mul(percent.max(100));
    Duration::from_millis((scaled / 100 + u64::from(scaled % 100 != 0)).min(max_ms))
}

#[cfg(test)]
mod oracle_timeout_tests {
    use super::*;

    #[test]
    fn learned_budgets_have_headroom_and_remain_capped_when_scaled() {
        let base = Duration::from_secs(8);
        assert_eq!(oracle_atom_timeout_with_scale(base, Some(13_777), 100), Duration::from_millis(16_533));
        assert_eq!(oracle_atom_timeout_with_scale(base, None, 200), Duration::from_secs(16));
        assert_eq!(oracle_atom_timeout_with_scale(base, Some(1), 0), base);
        assert_eq!(oracle_atom_timeout_with_scale(base, Some(u64::MAX), u64::MAX), Duration::from_secs(300));
    }

    #[test]
    fn explicit_long_replay_retains_learned_headroom_without_unbounded_time() {
        let base = Duration::from_secs(8);
        assert_eq!(oracle_atom_timeout_with_cap(base, Some(303_292), 100, 1_800_000),
            Duration::from_millis(363_951));
        assert_eq!(oracle_atom_timeout_with_cap(base, Some(u64::MAX), u64::MAX, 1_800_000),
            Duration::from_secs(1800));
    }
}

thread_local! {
    static CANCELLATION_FLAGS: std::cell::RefCell<Vec<CancellationFlag>> =
        const { std::cell::RefCell::new(Vec::new()) };
    static PROCESSOR_EVENT_CONTEXT: std::cell::RefCell<Option<ProcessorEventContext>> =
        const { std::cell::RefCell::new(None) };
}

#[derive(Clone, Debug)]
pub struct ProcessorEventContext {
    pub run_id: String,
    pub problem_id: String,
    pub category: Option<String>,
}

pub(crate) fn new_cancellation_flag() -> CancellationFlag {
    Arc::new(AtomicBool::new(false))
}

pub(crate) fn cancel(flag: &CancellationFlag) {
    flag.store(true, Ordering::Relaxed);
}

pub(crate) fn cancellation_requested(flags: &[CancellationFlag]) -> bool {
    flags.iter().any(|flag| flag.load(Ordering::Relaxed))
}

pub(crate) fn current_cancellation_flags() -> Vec<CancellationFlag> {
    CANCELLATION_FLAGS.with(|flags| flags.borrow().clone())
}

pub(crate) fn current_thread_cancelled() -> bool {
    thread_cancellation_requested()
}

pub(crate) fn with_cancellation_flags<R>(flags: Vec<CancellationFlag>, f: impl FnOnce() -> R) -> R {
    let previous = CANCELLATION_FLAGS.replace(flags);
    let result = f();
    CANCELLATION_FLAGS.replace(previous);
    result
}

pub fn with_processor_event_context<R>(context: ProcessorEventContext, f: impl FnOnce() -> R) -> R {
    let previous = PROCESSOR_EVENT_CONTEXT.replace(Some(context));
    let result = f();
    PROCESSOR_EVENT_CONTEXT.replace(previous);
    result
}

pub(crate) fn current_processor_event_context() -> Option<ProcessorEventContext> {
    PROCESSOR_EVENT_CONTEXT.with(|context| context.borrow().clone())
}

pub(crate) fn processor_event_context_or_problem_name(
    problem_name: Option<&str>,
) -> Option<ProcessorEventContext> {
    current_processor_event_context().or_else(|| {
        problem_name.and_then(|name| {
            let path = Path::new(name);
            let (category, problem_id) = tpdb_category_and_problem_id(path)?;
            Some(ProcessorEventContext {
                run_id: std::env::var("FERRUM_PROCESSOR_EVENT_RUN_ID")
                    .unwrap_or_else(|_| std::process::id().to_string()),
                problem_id,
                category: Some(category),
            })
        })
    })
}

fn tpdb_category_and_problem_id(path: &Path) -> Option<(String, String)> {
    let parts = path
        .components()
        .filter_map(|component| match component {
            Component::Normal(part) => part.to_str().map(str::to_string),
            _ => None,
        })
        .collect::<Vec<_>>();
    let tpdb_index = parts.iter().position(|part| part == "TPDB-ARI")?;
    let category = parts.get(tpdb_index + 1)?.clone();
    let problem_id = parts
        .get(tpdb_index + 2..)?
        .iter()
        .map(String::as_str)
        .collect::<Vec<_>>()
        .join("/");
    if problem_id.is_empty() {
        return None;
    }
    Some((category, problem_id))
}

fn thread_cancellation_requested() -> bool {
    CANCELLATION_FLAGS.with(|flags| cancellation_requested(&flags.borrow()))
}

#[derive(Clone, Default)]
pub(crate) struct CancellationScope {
    tokens: Vec<CancellationFlag>,
    deadline: Option<Instant>,
}

impl CancellationScope {
    pub(crate) fn current(deadline: Option<Instant>) -> Self {
        Self {
            tokens: current_cancellation_flags(),
            deadline,
        }
    }

    pub(crate) fn is_cancelled(&self) -> bool {
        cancellation_requested(&self.tokens)
            || self
                .deadline
                .is_some_and(|deadline| Instant::now() >= deadline)
    }

    pub(crate) fn remaining(&self) -> Option<Duration> {
        self.deadline
            .map(|deadline| deadline.saturating_duration_since(Instant::now()))
    }

    pub(crate) fn deadline(&self) -> Option<Instant> {
        self.deadline
    }

    pub(crate) fn tokens(&self) -> Vec<CancellationFlag> {
        self.tokens.clone()
    }

    pub(crate) fn child_scope(&self, deadline_cap: Option<Instant>) -> (Self, CancellationFlag) {
        let token = new_cancellation_flag();
        (self.with_child_token(token.clone(), deadline_cap), token)
    }

    pub(crate) fn with_child_token(
        &self,
        token: CancellationFlag,
        deadline_cap: Option<Instant>,
    ) -> Self {
        let mut tokens = self.tokens.clone();
        tokens.push(token);
        let deadline = match (self.deadline, deadline_cap) {
            (Some(parent), Some(cap)) => Some(parent.min(cap)),
            (Some(parent), None) => Some(parent),
            (None, Some(cap)) => Some(cap),
            (None, None) => None,
        };
        Self { tokens, deadline }
    }
}

pub(crate) fn parallel_poll_interval(remaining: Option<Duration>) -> Duration {
    remaining
        .map(|remaining| remaining.min(Duration::from_millis(10)))
        .unwrap_or_else(|| Duration::from_millis(10))
}

pub(crate) fn cooperative_parallel_wait_tick(remaining: Option<Duration>) {
    if rayon::yield_now().is_none() {
        thread::sleep(parallel_poll_interval(remaining));
    }
}

pub(crate) fn run_command_with_input_deadline(
    command: &mut Command,
    input: &str,
    deadline: Option<Instant>,
) -> io::Result<Option<Output>> {
    command.stdin(Stdio::piped()).stdout(Stdio::piped());
    configure_managed_child(command);
    let mut child = command.spawn()?;
    // Solver inputs can be tens of megabytes.  Writing synchronously before
    // entering `wait_with_deadline` lets a slow solver fill the pipe and trap
    // this thread forever, so neither the deadline nor cooperative
    // cancellation can kill it.  Deliver stdin concurrently and retain the
    // writer so every exit path still joins it after the child is reaped.
    let input = input.as_bytes().to_vec();
    let stdin_writer = child.stdin.take().map(|mut stdin| {
        thread::spawn(move || {
            stdin.write_all(&input)?;
            stdin.flush()
        })
    });
    wait_with_deadline(child, deadline, stdin_writer)
}

pub(crate) fn configure_managed_child(command: &mut Command) {
    #[cfg(unix)]
    {
        command.process_group(0);
        unsafe {
            command.pre_exec(|| {
                if libc::prctl(libc::PR_SET_PDEATHSIG, libc::SIGTERM) != 0 {
                    return Err(io::Error::last_os_error());
                }
                if libc::getppid() == 1 {
                    return Err(io::Error::new(
                        io::ErrorKind::Interrupted,
                        "parent exited before managed child exec",
                    ));
                }
                Ok(())
            });
        }
    }
}

fn wait_with_deadline(
    mut child: Child,
    deadline: Option<Instant>,
    stdin_writer: Option<thread::JoinHandle<io::Result<()>>>,
) -> io::Result<Option<Output>> {
    let stdout_reader = child.stdout.take().map(|mut stdout| {
        thread::spawn(move || {
            let mut bytes = Vec::new();
            stdout.read_to_end(&mut bytes)?;
            Ok::<_, io::Error>(bytes)
        })
    });
    let stderr_reader = child.stderr.take().map(|mut stderr| {
        thread::spawn(move || {
            let mut bytes = Vec::new();
            stderr.read_to_end(&mut bytes)?;
            Ok::<_, io::Error>(bytes)
        })
    });
    loop {
        if let Some(status) = child.try_wait()? {
            join_input_writer(stdin_writer)?;
            let stdout = join_output_reader(stdout_reader)?;
            let stderr = join_output_reader(stderr_reader)?;
            return Ok(Some(Output {
                status,
                stdout,
                stderr,
            }));
        }
        if deadline.is_some_and(|deadline| Instant::now() >= deadline)
            || thread_cancellation_requested()
        {
            kill_child_tree(&mut child);
            let _ = child.wait();
            let _ = join_input_writer(stdin_writer);
            let _ = join_output_reader(stdout_reader);
            let _ = join_output_reader(stderr_reader);
            return Ok(None);
        }
        let sleep_for = deadline
            .and_then(|deadline| deadline.checked_duration_since(Instant::now()))
            .map(|remaining| remaining.min(Duration::from_millis(10)))
            .unwrap_or_else(|| Duration::from_millis(10));
        thread::sleep(sleep_for);
    }
}

fn join_input_writer(writer: Option<thread::JoinHandle<io::Result<()>>>) -> io::Result<()> {
    writer.map_or_else(
        || Ok(()),
        |writer| {
            writer
                .join()
                .map_err(|_| io::Error::other("managed subprocess input writer thread panicked"))?
        },
    )
}

fn join_output_reader(
    reader: Option<thread::JoinHandle<io::Result<Vec<u8>>>>,
) -> io::Result<Vec<u8>> {
    reader.map_or_else(
        || Ok(Vec::new()),
        |reader| {
            reader
                .join()
                .map_err(|_| io::Error::other("managed subprocess output reader thread panicked"))?
        },
    )
}

fn kill_child_tree(child: &mut Child) {
    terminate_child_process_group(child);
}

pub(crate) fn terminate_child_process_group(child: &mut Child) {
    #[cfg(unix)]
    {
        kill_unix_process_group(child.id());
    }
    let _ = child.kill();
}

#[cfg(unix)]
fn kill_unix_process_group(pid: u32) {
    const SIGTERM: i32 = 15;
    const SIGKILL: i32 = 9;
    unsafe extern "C" {
        fn kill(pid: i32, signal: i32) -> i32;
    }
    let Ok(pid) = i32::try_from(pid) else {
        return;
    };
    let process_group = -pid;
    unsafe {
        kill(process_group, SIGTERM);
    }
    thread::sleep(Duration::from_millis(20));
    unsafe {
        kill(process_group, SIGKILL);
    }
}

pub(crate) fn write_progress_event(
    kind: &str,
    event: &str,
    name: &str,
    elapsed_ms: u128,
    details: &str,
) {
    let Some(path) = std::env::var_os("FERRUM_PROGRESS_LOG") else {
        return;
    };
    let lock = PROGRESS_LOG_LOCK.get_or_init(|| Mutex::new(()));
    let Ok(_guard) = lock.lock() else {
        return;
    };
    let Ok(mut file) = OpenOptions::new().create(true).append(true).open(path) else {
        return;
    };
    let _ = writeln!(
        file,
        "{{\"kind\":\"{}\",\"event\":\"{}\",\"name\":\"{}\",\"elapsed_ms\":{},\"details\":\"{}\"}}",
        json_escape(kind),
        json_escape(event),
        json_escape(name),
        elapsed_ms,
        json_escape(details)
    );
}

pub fn set_processor_event_log_path(path: PathBuf) -> Result<(), PathBuf> {
    let result = PROCESSOR_EVENT_LOG_PATH.set(path);
    if result.is_ok()
        && let Some(keys) = PROCESSOR_EVENT_STATE_KEYS.get()
        && let Ok(mut keys) = keys.lock()
    {
        keys.clear();
    }
    result
}

pub(crate) fn processor_event_log_enabled() -> bool {
    PROCESSOR_EVENT_LOG_PATH.get().is_some()
        || std::env::var_os("FERRUM_PROCESSOR_EVENT_LOG").is_some()
}

#[cfg(test)]
pub(crate) fn processor_event_cpf3_input(
    cpf: String,
    standardization_error: Option<String>,
    force_inline: bool,
) -> Value {
    processor_event_cpf3_input_with_status(
        cpf,
        standardization_error.is_none(),
        standardization_error,
        force_inline,
    )
}

pub(crate) fn processor_event_raw_input(
    serialized: String,
    format: &'static str,
    force_inline: bool,
) -> Value {
    let problem_key = format!("{:x}", Sha256::digest(serialized.trim().as_bytes()));
    let keys = PROCESSOR_EVENT_STATE_KEYS.get_or_init(|| Mutex::new(HashSet::new()));
    let first_occurrence = keys
        .lock()
        .map(|mut keys| keys.insert(problem_key.clone()))
        .unwrap_or(true);
    if force_inline || first_occurrence {
        json!({
            "format": format,
            "problem_key": problem_key,
            "standardized": false,
            "standardization_error": null,
            "cpf": serialized,
        })
    } else {
        json!({
            "format": format,
            "problem_key": problem_key,
            "cpf": null,
            "content_addressed": true,
        })
    }
}

#[cfg(test)]
fn processor_event_cpf3_input_with_status(
    cpf: String,
    standardized: bool,
    standardization_error: Option<String>,
    force_inline: bool,
) -> Value {
    let problem_key = format!("{:x}", Sha256::digest(cpf.trim().as_bytes()));
    let keys = PROCESSOR_EVENT_STATE_KEYS.get_or_init(|| Mutex::new(HashSet::new()));
    let first_occurrence = keys
        .lock()
        .map(|mut keys| keys.insert(problem_key.clone()))
        .unwrap_or(true);
    if force_inline || first_occurrence {
        json!({
            "format": "cpf3",
            "problem_key": problem_key,
            "standardized": standardized,
            "standardization_error": standardization_error,
            "cpf": cpf,
        })
    } else {
        json!({
            "format": "cpf3",
            "problem_key": problem_key,
            "cpf": null,
            "content_addressed": true,
        })
    }
}

pub(crate) fn write_processor_event(event: &Value) {
    let Ok(mut line) = serde_json::to_vec(event) else {
        return;
    };
    line.push(b'\n');
    let path = PROCESSOR_EVENT_LOG_PATH
        .get()
        .cloned()
        .or_else(|| std::env::var_os("FERRUM_PROCESSOR_EVENT_LOG").map(PathBuf::from));
    let Some(path) = path else {
        return;
    };
    let lock = PROCESSOR_EVENT_LOG_LOCK.get_or_init(|| Mutex::new(()));
    let Ok(_guard) = lock.lock() else {
        return;
    };
    let Ok(mut file) = OpenOptions::new().create(true).append(true).open(path) else {
        return;
    };
    let _ = file.write_all(&line);
}

fn json_escape(value: &str) -> String {
    let mut escaped = String::with_capacity(value.len());
    for ch in value.chars() {
        match ch {
            '"' => escaped.push_str("\\\""),
            '\\' => escaped.push_str("\\\\"),
            '\n' => escaped.push_str("\\n"),
            '\r' => escaped.push_str("\\r"),
            '\t' => escaped.push_str("\\t"),
            ch if ch.is_control() => escaped.push_str(&format!("\\u{:04x}", ch as u32)),
            ch => escaped.push(ch),
        }
    }
    escaped
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn cancellation_scope_inherits_parent_tokens_and_caps_deadline() {
        let parent_flag = new_cancellation_flag();
        let parent_deadline = Instant::now() + Duration::from_secs(10);
        let child_deadline = Instant::now() + Duration::from_millis(100);

        with_cancellation_flags(vec![parent_flag.clone()], || {
            let parent = CancellationScope::current(Some(parent_deadline));
            let (child, child_flag) = parent.child_scope(Some(child_deadline));

            assert!(
                child
                    .deadline()
                    .is_some_and(|deadline| deadline <= child_deadline)
            );
            assert!(!child.is_cancelled());
            cancel(&child_flag);
            assert!(child.is_cancelled());
        });

        let parent = CancellationScope {
            tokens: vec![parent_flag.clone()],
            deadline: None,
        };
        assert!(!parent.is_cancelled());
        cancel(&parent_flag);
        assert!(parent.is_cancelled());
    }

    #[test]
    fn cancellation_kills_running_child_process() {
        let flag = new_cancellation_flag();
        let child_flag = flag.clone();
        thread::spawn(move || {
            thread::sleep(Duration::from_millis(50));
            cancel(&child_flag);
        });

        let started = Instant::now();
        let mut command = Command::new("sh");
        command.arg("-c").arg("cat >/dev/null; sleep 5; echo late");
        let output = with_cancellation_flags(vec![flag], || {
            run_command_with_input_deadline(
                &mut command,
                "",
                Some(Instant::now() + Duration::from_secs(10)),
            )
            .expect("child process should start")
        });

        assert!(output.is_none());
        assert!(started.elapsed() < Duration::from_secs(2));
    }

    #[test]
    fn managed_child_drains_large_stdout_and_stderr_without_deadlocking() {
        let mut command = Command::new("sh");
        command
            .arg("-c")
            .arg("(yes o | head -c 1048576); (yes e | head -c 1048576 >&2)");
        command.stderr(Stdio::piped());
        let output = run_command_with_input_deadline(
            &mut command,
            "",
            Some(Instant::now() + Duration::from_secs(5)),
        )
        .expect("child process should start")
        .expect("child process should finish before the deadline");

        assert!(output.status.success());
        assert_eq!(output.stdout.len(), 1_048_576);
        assert_eq!(output.stderr.len(), 1_048_576);
    }

    #[test]
    fn managed_child_deadline_interrupts_blocked_large_stdin_write() {
        let mut command = Command::new("sh");
        // Keep stdin open without reading it, so an input larger than the pipe
        // capacity blocks the writer until the managed child is terminated.
        command.arg("-c").arg("sleep 30");
        let input = "x".repeat(16 * 1024 * 1024);
        let started = Instant::now();
        let output = run_command_with_input_deadline(
            &mut command,
            &input,
            Some(Instant::now() + Duration::from_millis(100)),
        )
        .expect("child process should start");

        assert!(output.is_none());
        assert!(started.elapsed() < Duration::from_secs(2));
    }

    #[test]
    fn compact_processor_events_store_cpf_once_and_reference_its_hash() {
        let cpf = "<dpInput><dps><rules/></dps></dpInput>".to_string();
        let first = processor_event_cpf3_input(cpf.clone(), None, false);
        let second = processor_event_cpf3_input(cpf.clone(), None, false);
        let forced = processor_event_cpf3_input(cpf, None, true);

        assert!(first["cpf"].is_string());
        assert!(second["cpf"].is_null());
        assert_eq!(first["problem_key"], second["problem_key"]);
        assert_eq!(second["content_addressed"], true);
        assert!(forced["cpf"].is_string());
    }
}
