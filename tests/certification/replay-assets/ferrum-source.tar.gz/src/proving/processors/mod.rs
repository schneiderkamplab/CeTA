mod canonical;

/// Strict oracle replay selects a fresh action at every residual. Explicit
/// strategies without oracle guidance and ordinary fallback search retain
/// their normal continuation semantics. The flag also enables the policy
/// during non-strict diagnostic runs.
pub(crate) fn state_local_only() -> bool {
    std::env::var_os("FERRUM_ORACLE_STATE_LOCAL_ONLY").is_some()
        || std::env::var_os("FERRUM_DP_LLM_NO_FALLBACK").is_some()
}

pub(crate) fn clear_oracle_child_strategy(state: &mut ProblemState, enabled: bool) {
    if enabled {
        if let ProblemState::DependencyPairs(problem) = state {
            if problem.options.utility_guidance.is_some() {
                problem.options.strategy = None;
            }
        }
    }
}

/// Deliberately fail in release builds too: complete termination certificates
/// must be decomposed into independently checked modular processor actions.
pub(crate) fn reject_retired_complete_termination_proof() {
    assert!(
        false,
        "complete TRS/DP termination-proof actions are retired; use modular processor guidance"
    );
}

pub(crate) fn reject_retired_complete_nontermination_proof() {
    assert!(
        false,
        "complete TRS/DP nontermination-proof actions are retired; use modular transformations and terminal witnesses"
    );
}

#[cfg(test)]
mod retired_proof_tests {
    #[test]
    #[cfg(unix)]
    fn state_local_ablation_clears_only_oracle_scheduling_context() {
        use super::*;
        use crate::core::Trs;
        use crate::proving::dependency_pairs::DpOptions;
        let mut options = DpOptions::default();
        options.strategy = Some(crate::proving::DpStrategy::parse("graph").unwrap());
        let mut state = ProblemState::DependencyPairs(dp::DpProblemState::ordinary(
            Trs::new(None, Default::default(), vec![]),
            vec![],
            options,
        ));
        clear_oracle_child_strategy(&mut state, true);
        let ProblemState::DependencyPairs(problem) = &mut state else {
            unreachable!()
        };
        assert!(
            problem.options.strategy.is_some(),
            "standalone strategies are unaffected"
        );
        problem.options.utility_guidance = Some(
            crate::llm::UtilityGuidanceLookup::from_path(std::path::Path::new("/dev/null"))
                .unwrap(),
        );
        let before = crate::proving::dependency_pairs::dp_state_input_cpf(problem);
        clear_oracle_child_strategy(&mut state, false);
        let ProblemState::DependencyPairs(problem) = &state else {
            unreachable!()
        };
        assert!(problem.options.strategy.is_some());
        clear_oracle_child_strategy(&mut state, true);
        let ProblemState::DependencyPairs(problem) = &state else {
            unreachable!()
        };
        assert!(problem.options.strategy.is_none());
        assert!(problem.options.utility_guidance.is_some());
        assert_eq!(
            before,
            crate::proving::dependency_pairs::dp_state_input_cpf(problem)
        );
    }

    #[test]
    #[should_panic(expected = "complete TRS/DP nontermination-proof actions are retired")]
    fn retired_trs_no_atom_asserts_before_decoding() {
        let _ = crate::proving::ProveStrategy::parse("exact-trs-nontermination-proof(hex=00)");
    }

    #[test]
    #[should_panic(expected = "complete TRS/DP nontermination-proof actions are retired")]
    fn retired_dp_no_atom_asserts_before_decoding() {
        let _ = crate::proving::DpStrategy::parse("exact-dp-nontermination-proof(hex=00)");
    }
    #[test]
    #[should_panic(expected = "complete TRS/DP termination-proof actions are retired")]
    fn retired_trs_atom_asserts_before_decoding() {
        let _ = crate::proving::ProveStrategy::parse("exact-trs-proof(hex=00)");
    }

    #[test]
    #[should_panic(expected = "complete TRS/DP termination-proof actions are retired")]
    fn retired_dp_atom_asserts_before_decoding() {
        let _ = crate::proving::DpStrategy::parse("exact-dp-proof(hex=00)");
    }
}
pub mod csr;
pub mod dp;
pub mod relative;
pub mod relative_adp;
pub(crate) mod rewrite_analysis;
#[cfg(test)]
pub(crate) mod test_support;
pub mod top_level;
pub mod traits;
pub mod worklist;

pub(crate) use canonical::{
    standardized_csr_input_cpf4, standardized_relative_trs_input_cpf3, standardized_trs_input_cpf3,
};
pub use traits::{
    CsrProblemState, CsrProofBoundary, ProblemCertificate, ProblemState, ProcessorApplication,
    ProcessorResult, WorklistProcessor,
};
pub use worklist::{
    LazyProcessorAttempt, WorklistFailure, WorklistFailureKind, solve_worklist_lazy,
    solve_worklist_lazy_until,
};
