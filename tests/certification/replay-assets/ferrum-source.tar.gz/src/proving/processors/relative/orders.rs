use std::time::Instant;

use crate::proving::dependency_pairs::{DpArgumentFilter, DpPathOrderKind};
use crate::proving::engine::ProveStrategyProcessor;
use crate::proving::processors::top_level::kbo::{
    checked_top_level_kbo_removal, synthesize_top_level_kbo_removal,
};
use crate::proving::processors::top_level::path_order::{
    checked_top_level_path_order_removal_with_ranks,
    synthesize_top_level_path_order_removal_with_deadline,
};
use crate::proving::{Proof, ProofStep, Status};
use std::collections::BTreeMap;

use super::super::{
    ProblemCertificate, ProblemState, ProcessorApplication, ProcessorResult, WorklistProcessor,
};
use super::residual::after_rule_removal;

pub struct RelativeKboRuleRemovalProcessor {
    pub max_weight: i64,
    pub max_symbols: usize,
    pub exact_witness: Option<(Vec<String>, BTreeMap<String, usize>, BTreeMap<String, i64>)>,
    pub deadline: Option<Instant>,
}

impl WorklistProcessor for RelativeKboRuleRemovalProcessor {
    fn name(&self) -> &'static str {
        "relative-kbo-rule-removal"
    }
    fn apply(&self, state: &ProblemState) -> ProcessorResult {
        let relative = match state {
            ProblemState::RelativeTrs(relative) | ProblemState::RelativeSrs(relative) => relative,
            _ => return ProcessorResult::Inapplicable,
        };
        let union = relative.union();
        let removal = if let Some((precedence, ranks, weights)) = &self.exact_witness {
            checked_top_level_kbo_removal(&union, precedence, ranks, weights)
        } else {
            synthesize_top_level_kbo_removal(
                &union,
                self.max_weight,
                self.max_symbols,
                self.deadline,
            )
        };
        let Some(removal) = removal else {
            return ProcessorResult::Inapplicable;
        };
        let remaining = after_rule_removal(relative, &removal.removed);
        let residual = ProblemState::from_relative(remaining);
        let precedence = removal.precedence;
        let precedence_ranks = removal.precedence_ranks;
        let exact_weights = removal.weights.clone();
        let weights = removal.weights.into_iter().collect::<Vec<_>>();
        let removed = removal.removed;
        let selected_atom = ProveStrategyProcessor::ExactKbo {
            precedence: precedence.clone(),
            precedence_ranks: precedence_ranks.clone(),
            weights: exact_weights,
        }
        .to_strategy_atom();
        ProcessorResult::Applied(
            ProcessorApplication::new(vec![residual], move |children| {
                let [ProblemCertificate::Trs(proof)] =
                    <[ProblemCertificate; 1]>::try_from(children).ok()?
                else {
                    return None;
                };
                if proof.status() != &Status::Terminating {
                    return None;
                }
                Some(ProblemCertificate::Trs(Proof::terminating(vec![
                    ProofStep::KboRuleRemoval {
                        precedence: precedence.clone(),
                        precedence_ranks: precedence_ranks.clone(),
                        weights: weights.clone(),
                        removed: removed.clone(),
                        proof: Box::new(proof),
                    },
                ])))
            })
            .with_selected_atom(selected_atom),
        )
    }
}

pub struct RelativePathOrderRuleRemovalProcessor {
    pub max_symbols: usize,
    pub exact_witness: Option<(
        BTreeMap<String, DpPathOrderKind>,
        Vec<String>,
        BTreeMap<String, usize>,
        DpArgumentFilter,
    )>,
    pub deadline: Option<Instant>,
}

impl WorklistProcessor for RelativePathOrderRuleRemovalProcessor {
    fn name(&self) -> &'static str {
        "relative-path-order-rule-removal"
    }
    fn apply(&self, state: &ProblemState) -> ProcessorResult {
        let relative = match state {
            ProblemState::RelativeTrs(relative) | ProblemState::RelativeSrs(relative) => relative,
            _ => return ProcessorResult::Inapplicable,
        };
        let union = relative.union();
        let removal = if let Some((statuses, precedence, ranks, filter)) = &self.exact_witness {
            checked_top_level_path_order_removal_with_ranks(
                &union, statuses, precedence, ranks, filter,
            )
        } else {
            synthesize_top_level_path_order_removal_with_deadline(
                &union,
                self.max_symbols,
                self.deadline,
            )
        };
        let Some(removal) = removal else {
            return ProcessorResult::Inapplicable;
        };
        let remaining = after_rule_removal(relative, &removal.removed);
        let residual = ProblemState::from_relative(remaining);
        let statuses = removal.statuses;
        let precedence = removal.precedence;
        let precedence_ranks = removal.precedence_ranks;
        let argument_filter = removal.argument_filter;
        let removed = removal.removed;
        let selected_atom = ProveStrategyProcessor::ExactPathOrder {
            statuses: statuses.clone(),
            precedence: precedence.clone(),
            precedence_ranks: precedence_ranks.clone(),
            argument_filter: argument_filter.clone(),
        }
        .to_strategy_atom();
        ProcessorResult::Applied(
            ProcessorApplication::new(vec![residual], move |children| {
                let [ProblemCertificate::Trs(proof)] =
                    <[ProblemCertificate; 1]>::try_from(children).ok()?
                else {
                    return None;
                };
                if proof.status() != &Status::Terminating {
                    return None;
                }
                Some(ProblemCertificate::Trs(Proof::terminating(vec![
                    ProofStep::PathOrderRuleRemoval {
                        statuses: statuses.clone(),
                        precedence: precedence.clone(),
                        precedence_ranks: precedence_ranks.clone(),
                        argument_filter: argument_filter.clone(),
                        removed: removed.clone(),
                        proof: Box::new(proof),
                    },
                ])))
            })
            .with_selected_atom(selected_atom),
        )
    }
}
