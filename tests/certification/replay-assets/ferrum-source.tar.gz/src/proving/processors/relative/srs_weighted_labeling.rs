//! Joint finite unary-model and labeled-weight synthesis. No symbol assignments
//! are supplied: the query chooses both tables, then native code rechecks them.
use std::collections::BTreeMap;
use std::time::Instant;

use super::super::{ProblemState, ProcessorResult, WorklistProcessor};
use super::semantic_labeling::RelativeSemanticLabelingProcessor;
use crate::core::{RelativeTrs, RewriteStrategy, Symbol};
use crate::proving::dependency_pairs::{
    DpOptions, SemanticLabelingModel, SlArithmeticFunction, parse_smt_values, run_smt_script,
};
use crate::proving::runtime::{current_thread_cancelled, write_progress_event};

pub struct SrsWeightedLabelingProcessor {
    pub carrier_size: usize,
    pub max_weight: usize,
    pub strict_percent: usize,
    pub deadline: Option<Instant>,
}

impl WorklistProcessor for SrsWeightedLabelingProcessor {
    fn name(&self) -> &'static str {
        "srs-weighted-labeling"
    }
    fn apply(&self, state: &ProblemState) -> ProcessorResult {
        let relative = match state {
            ProblemState::Trs(t) | ProblemState::Srs(t) => RelativeTrs::new(t.clone(), vec![]),
            ProblemState::RelativeTrs(r) | ProblemState::RelativeSrs(r) => r.clone(),
            _ => return ProcessorResult::Inapplicable,
        };
        let Some(model) = synthesize(
            &relative,
            self.carrier_size,
            self.max_weight,
            self.strict_percent,
            self.deadline,
        ) else {
            return ProcessorResult::Inapplicable;
        };
        RelativeSemanticLabelingProcessor {
            carrier_size: self.carrier_size,
            interpretations: model
                .interpretations
                .into_iter()
                .map(|(f, value)| (f.as_str().to_owned(), 1, value))
                .collect(),
            deadline: self.deadline,
        }
        .apply(state)
    }
}

fn lookup(prefix: &str, symbol: usize, argument: &str, carrier: usize) -> String {
    let mut result = format!("{prefix}_{symbol}_{}", carrier - 1);
    for value in (0..carrier - 1).rev() {
        result = format!("(ite (= {argument} {value}) {prefix}_{symbol}_{value} {result})");
    }
    result
}

struct Encoder {
    script: String,
    indices: BTreeMap<Symbol, usize>,
    cache: BTreeMap<(Vec<Symbol>, usize), (String, String)>,
    carrier: usize,
}

impl Encoder {
    fn word(&mut self, word: &[Symbol], tail: usize) -> (String, String) {
        let key = (word.to_vec(), tail);
        if let Some(result) = self.cache.get(&key) {
            return result.clone();
        }
        let Some((head, rest)) = word.split_first() else {
            return (tail.to_string(), "0".into());
        };
        let (argument, weight) = self.word(rest, tail);
        let i = self.cache.len();
        let state = format!("sw_state_{i}");
        let total = format!("sw_total_{i}");
        let symbol = self.indices[head];
        self.script.push_str(&format!(
            "(define-fun {state} () Int {})\n",
            lookup("sw_f", symbol, &argument, self.carrier)
        ));
        self.script.push_str(&format!(
            "(define-fun {total} () Int (+ {weight} {}))\n",
            lookup("sw_w", symbol, &argument, self.carrier)
        ));
        self.cache.insert(key, (state.clone(), total.clone()));
        (state, total)
    }
}

fn evaluate(
    word: &[Symbol],
    tail: usize,
    tables: &BTreeMap<Symbol, (Vec<usize>, Vec<usize>)>,
) -> Option<(usize, usize)> {
    let mut state = tail;
    let mut weight = 0usize;
    for symbol in word.iter().rev() {
        let (function, weights) = tables.get(symbol)?;
        weight = weight.checked_add(*weights.get(state)?)?;
        state = *function.get(state)?;
    }
    Some((state, weight))
}

fn synthesize(
    relative: &RelativeTrs,
    carrier: usize,
    max_weight: usize,
    strict_percent: usize,
    deadline: Option<Instant>,
) -> Option<SemanticLabelingModel> {
    if !(2..=8).contains(&carrier)
        || !(1..=128).contains(&max_weight)
        || strict_percent > 100
        || relative.strict().strategy() != RewriteStrategy::Full
    {
        return None;
    }
    let union = relative.union();
    let rules = union.srs_rules()?;
    let strict = relative.strict().srs_rules()?;
    if rules.len() > 256
        || rules.is_empty()
        || strict.is_empty()
        || rules
            .iter()
            .any(|r| r.lhs().is_empty() || r.lhs().len() + r.rhs().len() > 1024)
    {
        return None;
    }
    let mut indices = BTreeMap::new();
    for rule in &rules {
        for symbol in rule.lhs().iter().chain(rule.rhs()) {
            let next = indices.len();
            indices.entry(symbol.clone()).or_insert(next);
        }
    }
    if indices.len() > 128 {
        return None;
    }
    let mut encoder = Encoder {
        script: "(set-logic QF_LIA)\n".into(),
        indices,
        cache: BTreeMap::new(),
        carrier,
    };
    for i in 0..encoder.indices.len() {
        for value in 0..carrier {
            for (prefix, bound) in [("sw_f", carrier - 1), ("sw_w", max_weight)] {
                let name = format!("{prefix}_{i}_{value}");
                encoder.script.push_str(&format!(
                    "(declare-const {name} Int)\n(assert (and (<= 0 {name}) (<= {name} {bound})))\n"
                ));
            }
        }
    }
    let mut progress = Vec::new();
    for rule in &rules {
        for tail in 0..carrier {
            if current_thread_cancelled() || deadline.is_some_and(|end| Instant::now() >= end) {
                return None;
            }
            let (ls, lw) = encoder.word(rule.lhs(), tail);
            let (rs, rw) = encoder.word(rule.rhs(), tail);
            encoder.script.push_str(&format!(
                "(assert (= {ls} {rs}))\n(assert (>= {lw} {rw}))\n"
            ));
            if strict.contains(rule) {
                progress.push(format!("(> {lw} {rw})"));
            }
        }
    }
    let minimum_strict = (progress.len() * strict_percent).div_ceil(100).max(1);
    if strict_percent == 0 {
        encoder
            .script
            .push_str(&format!("(assert (or {}))\n", progress.join(" ")));
    } else {
        let count = progress
            .iter()
            .map(|p| format!("(ite {p} 1 0)"))
            .collect::<Vec<_>>()
            .join(" ");
        encoder
            .script
            .push_str(&format!("(assert (>= (+ {count}) {minimum_strict}))\n"));
    }
    encoder.script.push_str("(check-sat)\n(get-model)\n");
    write_progress_event(
        "srs-weighted-labeling",
        "encoded",
        "finite-model-and-weights",
        0,
        &format!(
            "carrier={carrier} symbols={} rules={} bytes={}",
            encoder.indices.len(),
            rules.len(),
            encoder.script.len()
        ),
    );
    let output = run_smt_script(&encoder.script, &DpOptions::default(), deadline)?;
    if output.split_whitespace().next() != Some("sat") {
        return None;
    }
    let values = parse_smt_values(&output)?;
    let mut tables = BTreeMap::new();
    for (symbol, index) in &encoder.indices {
        let mut function = Vec::new();
        let mut weights = Vec::new();
        for tail in 0..carrier {
            let f = usize::try_from(*values.get(&format!("sw_f_{index}_{tail}"))?).ok()?;
            let w = usize::try_from(*values.get(&format!("sw_w_{index}_{tail}"))?).ok()?;
            if f >= carrier || w > max_weight {
                return None;
            }
            function.push(f);
            weights.push(w);
        }
        tables.insert(symbol.clone(), (function, weights));
    }
    let mut strict_progress = 0;
    for rule in &rules {
        for tail in 0..carrier {
            let (ls, lw) = evaluate(rule.lhs(), tail, &tables)?;
            let (rs, rw) = evaluate(rule.rhs(), tail, &tables)?;
            if ls != rs || lw < rw {
                return None;
            }
            strict_progress += usize::from(strict.contains(rule) && lw > rw);
        }
    }
    if strict_progress < minimum_strict {
        return None;
    }
    let interpretations = tables
        .into_iter()
        .map(|(symbol, (function, _))| {
            let mut result = SlArithmeticFunction::Constant(function[carrier - 1]);
            for value in (0..carrier - 1).rev() {
                result = SlArithmeticFunction::IfEqual(Box::new([
                    SlArithmeticFunction::Argument(0),
                    SlArithmeticFunction::Constant(value),
                    SlArithmeticFunction::Constant(function[value]),
                    result,
                ]));
            }
            (symbol, result)
        })
        .collect();
    Some(SemanticLabelingModel {
        carrier_size: carrier,
        arities: union.arities(),
        interpretations,
    })
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::time::Duration;
    #[test]
    fn finite_weighted_labeling_synthesizes_and_rechecks_without_names() {
        for name in ["f", "renamed"] {
            let trs = crate::parsing::parse_ari_trs(
                None,
                &format!("(format TRS)(fun {name} 1)(rule ({name} x) x)"),
            )
            .unwrap();
            let state = ProblemState::Srs(trs.clone());
            let processor = SrsWeightedLabelingProcessor {
                carrier_size: 3,
                max_weight: 2,
                strict_percent: 0,
                deadline: Some(Instant::now() + Duration::from_secs(15)),
            };
            assert!(matches!(
                processor.apply(&state),
                ProcessorResult::Applied(_)
            ));
            let rule = crate::core::RewriteRule::new(
                trs.rules()[0].lhs().clone(),
                trs.rules()[0].lhs().clone(),
            );
            let loop_trs = crate::core::Trs::new(None, trs.variables().clone(), vec![rule]);
            assert!(
                synthesize(
                    &RelativeTrs::new(loop_trs, vec![]),
                    3,
                    2,
                    0,
                    processor.deadline
                )
                .is_none()
            );
        }
        let atom = "srs-weighted-labeling(carrier-size=4,max-weight=3)";
        let crate::proving::ProveStrategy::Processor(p) =
            crate::proving::ProveStrategy::parse(atom).unwrap()
        else {
            panic!()
        };
        assert_eq!(p.to_strategy_atom(), atom);
    }

    #[test]
    fn weighted_labeling_rejects_invalid_bounds_deadlines_and_non_srs() {
        let trs =
            crate::parsing::parse_ari_trs(None, "(format TRS)(fun f 1)(rule (f x) x)").unwrap();
        let relative = RelativeTrs::new(trs, vec![]);
        for (carrier, weight) in [(0, 1), (1, 1), (9, 1), (2, 0), (2, 129)] {
            assert!(synthesize(&relative, carrier, weight, 0, None).is_none());
        }
        assert!(
            synthesize(
                &relative,
                2,
                1,
                0,
                Some(Instant::now() - Duration::from_secs(1))
            )
            .is_none()
        );
        assert!(synthesize(&relative, 2, 1, 101, None).is_none());
        assert!(
            synthesize(
                &relative,
                2,
                1,
                100,
                Some(Instant::now() + Duration::from_secs(15))
            )
            .is_some()
        );
        let non_srs =
            crate::parsing::parse_ari_trs(None, "(format TRS)(fun f 2)(rule (f x y) x)").unwrap();
        assert!(synthesize(&RelativeTrs::new(non_srs, vec![]), 2, 1, 0, None).is_none());
    }
}
