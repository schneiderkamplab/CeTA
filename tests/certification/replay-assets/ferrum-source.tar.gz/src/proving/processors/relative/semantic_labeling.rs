use std::time::Instant;

use crate::core::{RelativeTrs, RewriteStrategy, Symbol};
use crate::proving::dependency_pairs::{
    SemanticLabelingModel, SlArithmeticFunction, label_relative_trs_with_model,
    synthesize_finite_label_relative_trs,
};
use crate::proving::engine::ProveStrategyProcessor;
use crate::proving::{Proof, ProofStep, Status};

use super::super::{
    ProblemCertificate, ProblemState, ProcessorApplication, ProcessorResult, WorklistProcessor,
};

pub struct RelativeSemanticLabelingProcessor {
    pub carrier_size: usize,
    pub interpretations: Vec<(String, usize, SlArithmeticFunction)>,
    pub deadline: Option<Instant>,
}

pub struct SynthesizingRelativeSemanticLabelingProcessor {
    pub carrier_size: usize,
    pub deadline: Option<Instant>,
}

/// Full tiling as semantic labeling in a finite shift algebra. Memory and
/// alphabet size determine the model, without enumerating interpretations or
/// importing an external model. The ordinary model checker checks every rule.
pub struct SrsShiftLabelingProcessor {
    pub memory: usize,
    pub deadline: Option<Instant>,
}

#[cfg(test)]
mod shift_tests {
    use super::*;
    use crate::proving::processors::relative::SrsContextClosureProcessor;

    #[test]
    fn shift_labeling_requires_the_complete_model_and_tracks_context_layers() {
        for (a, b) in [("a", "b"), ("renamed", "other")] {
            for memory in [2, 4, 5] {
                let text = format!("(format TRS) (fun {a} 1) (fun {b} 1)
                (rule ({a} ({b} x)) ({b} ({a} x)))");
                let trs = crate::parsing::parse_ari_trs(None, &text).unwrap();
                let mut state = ProblemState::Srs(trs);
                let shift = SrsShiftLabelingProcessor { memory, deadline: None };
                for layer in 0..memory {
                    assert!(matches!(shift.apply(&state), ProcessorResult::Inapplicable), "incomplete context at layer {layer}");
                    let ProcessorResult::Applied(application) =
                        (SrsContextClosureProcessor { depth: memory }).apply(&state) else { panic!("closure"); };
                    state = application.residuals.into_iter().next().unwrap();
                }
                assert!(matches!((SrsContextClosureProcessor { depth: memory }).apply(&state), ProcessorResult::Inapplicable));
                assert!(matches!(shift.apply(&state), ProcessorResult::Applied(_)));
            }
        }
        for atom in ["srs-context-closure(depth=2)", "srs-shift-labeling(memory=3)", "srs-context-closure(depth=8)", "srs-shift-labeling(memory=8)"] {
            let crate::proving::ProveStrategy::Processor(p) = crate::proving::ProveStrategy::parse(atom).unwrap() else { panic!() };
            assert_eq!(p.to_strategy_atom(), atom);
        }
        assert!(crate::proving::ProveStrategy::parse("srs-shift-labeling(memory=0)").is_err());
        assert!(crate::proving::ProveStrategy::parse("srs-shift-labeling(memory=9)").is_err());
        assert!(crate::proving::ProveStrategy::parse("srs-context-closure(depth=9)").is_err());
    }

    #[test]
    fn shift_memory_four_keeps_the_carrier_size_guard() {
        let trs = crate::parsing::parse_ari_trs(None,
            "(format TRS) (fun a 1) (fun b 1) (fun c 1) (fun d 1) (fun e 1)
             (rule (a (b (c (d (e x))))) x)").unwrap();
        let state = ProblemState::Srs(trs);
        assert!(matches!(
            (SrsShiftLabelingProcessor { memory: 4, deadline: None }).apply(&state),
            ProcessorResult::Inapplicable
        ));
    }
}

impl WorklistProcessor for SrsShiftLabelingProcessor {
    fn name(&self) -> &'static str { "srs-shift-labeling" }

    fn apply(&self, state: &ProblemState) -> ProcessorResult {
        let trs = match state {
            ProblemState::Trs(t) | ProblemState::Srs(t) => t.clone(),
            ProblemState::RelativeTrs(r) | ProblemState::RelativeSrs(r) => r.union(),
            _ => return ProcessorResult::Inapplicable,
        };
        if trs.strategy() != RewriteStrategy::Full || trs.srs_rules().is_none()
            || !(1..=8).contains(&self.memory) {
            return ProcessorResult::Inapplicable;
        }
        let arities = trs.arities();
        let base = arities.len();
        let Some(carrier) = base.checked_pow(self.memory as u32).filter(|n| *n > 0 && *n <= 256) else {
            return ProcessorResult::Inapplicable;
        };
        if trs.rules().len().saturating_mul(carrier) > 100_000 {
            return ProcessorResult::Inapplicable;
        }
        let interpretations = arities.iter().enumerate().map(|(symbol_index, (symbol, arity))| {
            // Encode a lookup table in the existing CPF arithmetic language.
            // No modulo operation or new checker extension is required.
            let mut function = SlArithmeticFunction::Constant(((carrier - 1) * base + symbol_index) % carrier);
            for value in (0..if self.memory == 1 { 0 } else { carrier - 1 }).rev() {
                function = SlArithmeticFunction::IfEqual(Box::new([
                    SlArithmeticFunction::Argument(0),
                    SlArithmeticFunction::Constant(value),
                    SlArithmeticFunction::Constant((value * base + symbol_index) % carrier),
                    function,
                ]));
            }
            (symbol.as_str().to_owned(), *arity, function)
        }).collect();
        RelativeSemanticLabelingProcessor {
            carrier_size: carrier, interpretations, deadline: self.deadline,
        }.apply(state)
    }
}

impl WorklistProcessor for SynthesizingRelativeSemanticLabelingProcessor {
    fn name(&self) -> &'static str {
        "relative-semantic-labeling-synthesis"
    }

    fn apply(&self, state: &ProblemState) -> ProcessorResult {
        let ordinary;
        let relative = match state {
            ProblemState::RelativeTrs(relative) | ProblemState::RelativeSrs(relative) => relative,
            ProblemState::Trs(trs) | ProblemState::Srs(trs)
                if trs.strategy() == RewriteStrategy::Full =>
            {
                ordinary = RelativeTrs::new(trs.clone(), Vec::new());
                &ordinary
            }
            _ => return ProcessorResult::Inapplicable,
        };
        let Some(labeling) =
            synthesize_finite_label_relative_trs(relative, self.carrier_size, self.deadline)
        else {
            return ProcessorResult::Inapplicable;
        };
        let interpretations = labeling
            .model
            .arities
            .iter()
            .filter_map(|(symbol, arity)| {
                labeling
                    .model
                    .interpretations
                    .get(symbol)
                    .cloned()
                    .map(|interpretation| (symbol.as_str().to_owned(), *arity, interpretation))
            })
            .collect::<Vec<_>>();
        let selected_atom = ProveStrategyProcessor::ExactRelativeSemanticLabeling {
            carrier_size: labeling.model.carrier_size,
            interpretations,
        }
        .to_strategy_atom();
        let residual = if matches!(state, ProblemState::Trs(_) | ProblemState::Srs(_)) {
            ProblemState::Trs(labeling.relative.strict().clone())
        } else {
            ProblemState::from_relative(labeling.relative)
        };
        let model = labeling.model;
        let labeled_rules = labeling.labeled_rules;
        ProcessorResult::Applied(
            ProcessorApplication::new(vec![residual], move |children| {
                let [ProblemCertificate::Trs(proof)] =
                    <[ProblemCertificate; 1]>::try_from(children).ok()?
                else {
                    return None;
                };
                (proof.status() == &Status::Terminating).then(|| {
                    ProblemCertificate::Trs(Proof::terminating(vec![ProofStep::SemanticLabeling {
                        root_labeling: false,
                        model: model.clone(),
                        labeled_rules: labeled_rules.clone(),
                        proof: Box::new(proof),
                    }]))
                })
            })
            .with_selected_atom(selected_atom),
        )
    }
}

impl WorklistProcessor for RelativeSemanticLabelingProcessor {
    fn name(&self) -> &'static str {
        "relative-semantic-labeling"
    }
    fn apply(&self, state: &ProblemState) -> ProcessorResult {
        let ordinary;
        let relative = match state {
            ProblemState::RelativeTrs(relative) | ProblemState::RelativeSrs(relative) => relative,
            ProblemState::Trs(trs) | ProblemState::Srs(trs)
                if trs.strategy() == RewriteStrategy::Full =>
            {
                ordinary = RelativeTrs::new(trs.clone(), Vec::new());
                &ordinary
            }
            _ => return ProcessorResult::Inapplicable,
        };
        let model = SemanticLabelingModel {
            carrier_size: self.carrier_size,
            arities: self
                .interpretations
                .iter()
                .map(|(symbol, arity, _)| (Symbol::new(symbol), *arity))
                .collect(),
            interpretations: self
                .interpretations
                .iter()
                .map(|(symbol, _, interpretation)| (Symbol::new(symbol), interpretation.clone()))
                .collect(),
        };
        let Some(labeling) = label_relative_trs_with_model(relative, model, self.deadline) else {
            return ProcessorResult::Inapplicable;
        };
        let residual = if matches!(state, ProblemState::Trs(_) | ProblemState::Srs(_)) {
            ProblemState::Trs(labeling.relative.strict().clone())
        } else {
            ProblemState::from_relative(labeling.relative)
        };
        let model = labeling.model;
        let labeled_rules = labeling.labeled_rules;
        ProcessorResult::Applied(ProcessorApplication::new(vec![residual], move |children| {
            let [ProblemCertificate::Trs(proof)] =
                <[ProblemCertificate; 1]>::try_from(children).ok()?
            else {
                return None;
            };
            if proof.status() != &Status::Terminating {
                return None;
            }
            Some(ProblemCertificate::Trs(Proof::terminating(vec![
                ProofStep::SemanticLabeling {
                    root_labeling: false,
                    model: model.clone(),
                    labeled_rules: labeled_rules.clone(),
                    proof: Box::new(proof),
                },
            ])))
        }))
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::time::Duration;

    #[test]
    fn ordinary_semantic_labeling_preserves_the_full_trs_state_kind() {
        let trs =
            crate::parsing::parse_ari_trs(None, "(format TRS) (fun f 1) (rule (f (f x)) (f x))")
                .unwrap();
        let exact = RelativeSemanticLabelingProcessor {
            carrier_size: 2,
            interpretations: vec![("f".into(), 1, SlArithmeticFunction::Argument(0))],
            deadline: None,
        };
        let synthesis = SynthesizingRelativeSemanticLabelingProcessor {
            carrier_size: 2,
            deadline: Some(Instant::now() + Duration::from_secs(5)),
        };
        for state in [
            ProblemState::Trs(trs.clone()),
            ProblemState::Srs(trs.clone()),
        ] {
            for processor in [&exact as &dyn WorklistProcessor, &synthesis] {
                let ProcessorResult::Applied(application) = processor.apply(&state) else {
                    panic!("ordinary semantic labeling must apply");
                };
                assert!(matches!(
                    application.residuals.as_slice(),
                    [ProblemState::Trs(_)]
                ));
                assert!(
                    application
                        .reconstruct(vec![ProblemCertificate::Trs(Proof::unknown(
                            "open child",
                            vec![]
                        ))])
                        .is_none()
                );
            }
        }
        let inner = crate::core::Trs::new_with_strategy(
            None,
            trs.variables().clone(),
            trs.rules().to_vec(),
            RewriteStrategy::Innermost,
        );
        for processor in [&exact as &dyn WorklistProcessor, &synthesis] {
            assert!(matches!(
                processor.apply(&ProblemState::Trs(inner.clone())),
                ProcessorResult::Inapplicable
            ));
        }
    }
}
