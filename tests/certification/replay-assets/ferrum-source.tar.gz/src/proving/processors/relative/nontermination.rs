use std::time::Instant;

use crate::core::RelativeTrs;
use crate::proving::nontermination::{
    NonterminationStrategyProcessor, bounded_relative_rewriting_loop, search_nontermination_witness,
};
use crate::proving::{NonterminationProof, Proof};

use super::super::{
    ProblemCertificate, ProblemState, ProcessorApplication, ProcessorResult, WorklistProcessor,
};

pub struct RelativeNonterminationProcessor {
    pub processor: NonterminationStrategyProcessor,
    pub deadline: Option<Instant>,
}

#[cfg(test)]
pub(crate) fn find_relative_loop(
    relative: &RelativeTrs,
    deadline: Option<Instant>,
) -> Option<NonterminationProof> {
    if let Some(proof) = bounded_relative_rewriting_loop(relative, deadline) {
        return Some(proof);
    }
    let union = relative.union();
    let processors = [
        NonterminationStrategyProcessor::DirectLoop,
        NonterminationStrategyProcessor::SrsLoop,
        NonterminationStrategyProcessor::RuleSubsetNarrowing,
        NonterminationStrategyProcessor::BoundedNarrowing,
        NonterminationStrategyProcessor::BoundedRewriting,
    ];
    let proof = processors
        .into_iter()
        .find_map(|processor| search_nontermination_witness(&union, &processor, deadline))?;
    validate_relative_loop(relative, proof)
}

fn validate_relative_loop(
    relative: &RelativeTrs,
    proof: NonterminationProof,
) -> Option<NonterminationProof> {
    let NonterminationProof::Loop(loop_proof) = &proof else {
        return None;
    };
    let all_steps_are_union_rules = loop_proof.steps.iter().all(|step| {
        relative.strict().rules().contains(&step.rule) || relative.weak_rules().contains(&step.rule)
    });
    let has_strict_step = loop_proof
        .steps
        .iter()
        .any(|step| relative.strict().rules().contains(&step.rule));
    (all_steps_are_union_rules && has_strict_step).then_some(proof)
}

impl WorklistProcessor for RelativeNonterminationProcessor {
    fn name(&self) -> &'static str {
        "relative-nontermination"
    }
    fn apply(&self, state: &ProblemState) -> ProcessorResult {
        let relative = match state {
            ProblemState::RelativeTrs(relative) | ProblemState::RelativeSrs(relative) => relative,
            _ => return ProcessorResult::Inapplicable,
        };
        let proof = if self.processor == NonterminationStrategyProcessor::DirectLoop {
            bounded_relative_rewriting_loop(relative, self.deadline)
        } else {
            None
        }
        .or_else(|| {
            search_nontermination_witness(&relative.union(), &self.processor, self.deadline)
        })
        .and_then(|proof| validate_relative_loop(relative, proof));
        let Some(proof) = proof else {
            return if self.deadline.is_some_and(|limit| Instant::now() >= limit) {
                ProcessorResult::TimedOut
            } else {
                ProcessorResult::Inapplicable
            };
        };
        ProcessorResult::Applied(ProcessorApplication::solved(ProblemCertificate::Trs(
            Proof::nonterminating(proof),
        )))
    }
}
