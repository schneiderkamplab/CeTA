use crate::core::{RelativeTrs, RewriteRule, Term, Trs, Variable};
use crate::proving::FlatContext;
use crate::proving::{Proof, ProofStep, Status};

use super::super::{
    ProblemCertificate, ProblemState, ProcessorApplication, ProcessorResult, WorklistProcessor,
};

pub struct RelativeFlatContextClosureProcessor;

pub(crate) fn close_relative(
    relative: &RelativeTrs,
) -> Option<(Vec<FlatContext>, Vec<RewriteRule>, RelativeTrs)> {
    close_relative_depth(relative, 1)
}

fn close_relative_depth(
    relative: &RelativeTrs,
    depth: usize,
) -> Option<(Vec<FlatContext>, Vec<RewriteRule>, RelativeTrs)> {
    let union = relative.union();
    let mut used_variables = union.variables().clone();
    let mut contexts = Vec::new();
    for (symbol, arity) in union.arities() {
        for hole in 0..arity {
            let mut arguments = Vec::with_capacity(arity.saturating_sub(1));
            for position in 0..arity {
                if position == hole {
                    continue;
                }
                let mut suffix = 0usize;
                let variable = loop {
                    let candidate = Variable::new(format!(
                        "__ferrum_fcc_{}_{}_{}_{}",
                        symbol.as_str().len(),
                        hole,
                        position,
                        suffix,
                    ));
                    if used_variables.insert(candidate.clone()) {
                        break candidate;
                    }
                    suffix += 1;
                };
                arguments.push(Term::Var(variable));
            }
            contexts.push(FlatContext {
                symbol: symbol.clone(),
                before: arguments[..hole].to_vec(),
                after: arguments[hole..].to_vec(),
            });
        }
    }
    if contexts.is_empty() {
        return None;
    }
    let close_rules = |rules: &[RewriteRule]| {
        let mut closed = Vec::new();
        let mut seen = std::collections::HashSet::new();
        for rule in rules {
            let mut left = rule.lhs();
            let mut right = rule.rhs();
            let mut common = 0;
            while common < depth && left.root_symbol().is_some()
                && left.root_symbol() == right.root_symbol() {
                common += 1;
                match (left, right) {
                    (Term::App {args: a, ..}, Term::App {args: b, ..}) if a.len() == 1 && b.len() == 1 => {
                        left = &a[0]; right = &b[0];
                    }
                    _ => break,
                }
            }
            if common >= depth {
                if seen.insert(rule.clone()) {
                    closed.push(rule.clone());
                }
                continue;
            }
            for context in &contexts {
                let apply = |term: &Term| {
                    let mut args = context.before.clone();
                    args.push(term.clone());
                    args.extend(context.after.iter().cloned());
                    Term::App {
                        symbol: context.symbol.clone(),
                        args,
                    }
                };
                let closed_rule = RewriteRule::new(apply(rule.lhs()), apply(rule.rhs()));
                if seen.insert(closed_rule.clone()) {
                    closed.push(closed_rule);
                }
            }
        }
        closed
    };
    let strict_rules = close_rules(relative.strict().rules());
    let weak_rules = close_rules(relative.weak_rules());
    let mut transformed_rules = strict_rules.clone();
    for rule in &weak_rules {
        if !transformed_rules.contains(rule) {
            transformed_rules.push(rule.clone());
        }
    }
    let transformed = RelativeTrs::new(
        Trs::new_with_strategy(
            relative.strict().name().map(str::to_string),
            used_variables,
            strict_rules,
            relative.strict().strategy(),
        ),
        weak_rules,
    );
    // Closing an already closed relative system is idempotent.  Reporting an
    // unchanged child as a transformation lets recursive portfolios apply
    // this processor forever and spend the whole root budget revisiting the
    // same content-addressed state.
    // The explicit variable universe may grow by fresh variables that do not
    // occur in any retained rule.  It is not part of the mathematical
    // relative-rewriting problem (and is omitted by canonical CPF output), so
    // compare the two rule partitions directly for the no-progress test.
    if transformed.strict().rules() == relative.strict().rules()
        && transformed.weak_rules() == relative.weak_rules()
    {
        return None;
    }
    Some((contexts, transformed_rules, transformed))
}

impl WorklistProcessor for RelativeFlatContextClosureProcessor {
    fn name(&self) -> &'static str {
        "relative-flat-context-closure"
    }
    fn apply(&self, state: &ProblemState) -> ProcessorResult {
        apply_closure(state, 1, false)
    }
}

/// One layer of full flat-context closure for the finite shift algebra.
/// Repeating this atom exposes each layer as an independently guided state.
pub struct SrsContextClosureProcessor { pub depth: usize }

impl WorklistProcessor for SrsContextClosureProcessor {
    fn name(&self) -> &'static str { "srs-context-closure" }
    fn apply(&self, state: &ProblemState) -> ProcessorResult {
        if !(1..=8).contains(&self.depth) { return ProcessorResult::Inapplicable; }
        apply_closure(state, self.depth, true)
    }
}

fn apply_closure(state: &ProblemState, depth: usize, srs_only: bool) -> ProcessorResult {
        // Ordinary termination is the empty-weak-part case. Keep its child
        // ordinary so the next standalone TRS processor can consume it.
        let ordinary;
        let relative = match state {
            ProblemState::RelativeTrs(relative) | ProblemState::RelativeSrs(relative) => relative,
            ProblemState::Trs(trs) | ProblemState::Srs(trs)
                if trs.strategy() == crate::core::RewriteStrategy::Full => {
                    ordinary = RelativeTrs::new(trs.clone(), Vec::new());
                    &ordinary
                }
            _ => return ProcessorResult::Inapplicable,
        };
        if srs_only && (relative.union().srs_rules().is_none()
            || relative.strict().strategy() != crate::core::RewriteStrategy::Full) {
            return ProcessorResult::Inapplicable;
        }
        if srs_only && relative.union().rules().len().saturating_mul(relative.union().arities().len()) > 100_000 {
            return ProcessorResult::Inapplicable;
        }
        let Some((contexts, transformed_rules, transformed)) = close_relative_depth(relative, depth) else {
            return ProcessorResult::Inapplicable;
        };
        let residual = if matches!(state, ProblemState::Trs(_) | ProblemState::Srs(_)) {
            ProblemState::Trs(transformed.strict().clone())
        } else {
            ProblemState::from_relative(transformed)
        };
        ProcessorResult::Applied(ProcessorApplication::new(vec![residual], move |children| {
            let [ProblemCertificate::Trs(proof)] =
                <[ProblemCertificate; 1]>::try_from(children).ok()?
            else {
                return None;
            };
            if proof.status() != &Status::Terminating {
                return None;
            }
            Some(ProblemCertificate::Trs(Proof::terminating(vec![
                ProofStep::FlatContextClosure {
                    contexts: contexts.clone(),
                    transformed_rules: transformed_rules.clone(),
                    proof: Box::new(proof),
                },
            ])))
        }))
}

#[cfg(test)]
mod tests {
    use std::collections::BTreeSet;

    use crate::core::{RelativeTrs, RewriteRule, Term, Trs, Variable};

    use super::*;

    #[test]
    fn flat_context_closure_accepts_full_trs_and_srs_but_not_innermost() {
        let trs = Trs::new(None, Default::default(), vec![RewriteRule::new(
            Term::app("f", vec![Term::var("x")]),
            Term::app("g", vec![Term::var("x")]),
        )]);
        for state in [ProblemState::Trs(trs.clone()), ProblemState::Srs(trs.clone())] {
            let ProcessorResult::Applied(application) = RelativeFlatContextClosureProcessor.apply(&state)
                else { panic!("ordinary closure must apply") };
            assert!(matches!(application.residuals.as_slice(), [ProblemState::Trs(_)]));
        }
        let inner = Trs::new_with_strategy(None, trs.variables().clone(), trs.rules().to_vec(),
            crate::core::RewriteStrategy::Innermost);
        assert!(matches!(RelativeFlatContextClosureProcessor.apply(&ProblemState::Trs(inner)),
            ProcessorResult::Inapplicable));
    }

    #[test]
    fn flat_context_closure_preserves_the_relative_partition() {
        let variable = Variable::new("x");
        let strict = RewriteRule::new(
            Term::app("a", vec![Term::Var(variable.clone())]),
            Term::app("b", vec![Term::Var(variable.clone())]),
        );
        let weak = RewriteRule::new(
            Term::app("b", vec![Term::Var(variable.clone())]),
            Term::app("c", vec![Term::Var(variable.clone())]),
        );
        let relative = RelativeTrs::new(
            Trs::new(None, BTreeSet::from([variable]), vec![strict]),
            vec![weak],
        );

        let ProcessorResult::Applied(application) =
            RelativeFlatContextClosureProcessor.apply(&ProblemState::RelativeSrs(relative))
        else {
            panic!("flat-context closure should apply");
        };
        let (residuals, _) = application.into_parts();
        let [ProblemState::RelativeSrs(closed)] = residuals.as_slice() else {
            panic!("flat-context closure must preserve the relative SRS obligation");
        };
        assert_eq!(closed.strict().rules().len(), 3);
        assert_eq!(closed.weak_rules().len(), 3);
        assert!(closed.strict().rules().iter().any(|rule| {
            rule.lhs() == &Term::app("a", vec![Term::app("a", vec![Term::var("x")])])
                && rule.rhs() == &Term::app("a", vec![Term::app("b", vec![Term::var("x")])])
        }));
        assert!(closed.weak_rules().iter().any(|rule| {
            rule.lhs() == &Term::app("a", vec![Term::app("b", vec![Term::var("x")])])
                && rule.rhs() == &Term::app("a", vec![Term::app("c", vec![Term::var("x")])])
        }));

        assert!(close_relative(&closed).is_none());
    }

    #[test]
    fn flat_context_closure_declines_rule_identical_state_with_fresh_unused_variables() {
        let variable = Variable::new("x");
        let rule = RewriteRule::new(
            Term::app("a", vec![Term::Var(variable.clone())]),
            Term::app("a", vec![Term::Var(variable.clone())]),
        );
        let relative = RelativeTrs::new(
            Trs::new(None, BTreeSet::from([variable]), vec![rule]),
            Vec::new(),
        );

        assert!(close_relative(&relative).is_none());
    }
}
