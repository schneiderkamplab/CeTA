use std::time::Instant;

use super::residual::after_rule_removal;
use crate::proving::engine::{ProveOptions, ProveStrategyProcessor};
use crate::proving::processors::top_level::polynomial::{
    exact_linear_polynomial_interpretations,
    synthesize_top_level_polynomial_removal_with_smt_candidate,
    synthesize_top_level_polynomial_removal_with_smt_target,
    top_level_polynomial_removal_from_interpretations,
};
use crate::proving::{Proof, ProofStep, Status};

use super::super::{
    ProblemCertificate, ProblemState, ProcessorApplication, ProcessorResult, WorklistProcessor,
};

pub struct RelativePolynomialRuleRemovalProcessor {
    pub options: ProveOptions,
    pub exact_interpretation: Option<Vec<(String, i64, Vec<i64>)>>,
    pub target_strict_rule_indices: Option<Vec<usize>>,
    pub candidate_index: usize,
    pub deadline: Option<Instant>,
}

impl WorklistProcessor for RelativePolynomialRuleRemovalProcessor {
    fn name(&self) -> &'static str {
        "relative-polynomial-rule-removal"
    }

    fn apply(&self, state: &ProblemState) -> ProcessorResult {
        let relative = match state {
            ProblemState::RelativeTrs(relative) | ProblemState::RelativeSrs(relative) => relative,
            _ => return ProcessorResult::Inapplicable,
        };
        let union = relative.union();
        let removal = if let Some(witness) = self.exact_interpretation.as_deref() {
            let Some(interpretations) = exact_linear_polynomial_interpretations(witness) else {
                return ProcessorResult::Failed {
                    reason: "exact polynomial witness contains duplicate symbols".to_string(),
                };
            };
            top_level_polynomial_removal_from_interpretations(&union, interpretations)
        } else if let Some(target) = self.target_strict_rule_indices.as_deref() {
            synthesize_top_level_polynomial_removal_with_smt_target(
                &union,
                &self.options,
                target,
                self.deadline,
            )
        } else {
            synthesize_top_level_polynomial_removal_with_smt_candidate(
                &union,
                &self.options,
                self.candidate_index,
                self.deadline,
            )
        };
        let Some(removal) = removal else {
            return ProcessorResult::Inapplicable;
        };
        let remaining = after_rule_removal(relative, &removal.removed);
        let residual = ProblemState::from_relative(remaining);
        let interpretations = removal.interpretations;
        let selected_atom = if self.exact_interpretation.is_some() {
            ProveStrategyProcessor::ExactLinearPolynomial {
                interpretation: interpretations.clone(),
            }
        } else if let Some(strict_rule_indices) = self.target_strict_rule_indices.as_ref() {
            ProveStrategyProcessor::TargetLinearPolynomial {
                max_constant: self.options.max_polynomial_constant,
                max_coefficient: self.options.max_polynomial_coefficient,
                max_symbols: Some(self.options.max_polynomial_symbols),
                max_arity: Some(self.options.max_polynomial_arity),
                strict_rule_indices: strict_rule_indices.clone(),
            }
        } else {
            ProveStrategyProcessor::SelectedLinearPolynomial {
                max_constant: self.options.max_polynomial_constant,
                max_coefficient: self.options.max_polynomial_coefficient,
                max_symbols: Some(self.options.max_polynomial_symbols),
                max_arity: Some(self.options.max_polynomial_arity),
                candidate_index: self.candidate_index,
            }
        }
        .to_strategy_atom();
        let removed = removal.removed;
        ProcessorResult::Applied(
            ProcessorApplication::new(vec![residual], move |children| {
                let [ProblemCertificate::Trs(proof)] =
                    <[ProblemCertificate; 1]>::try_from(children).ok()?
                else {
                    return None;
                };
                if proof.status() != &Status::Terminating {
                    return None;
                }
                Some(ProblemCertificate::Trs(Proof::terminating(vec![
                    ProofStep::PolynomialRuleRemoval {
                        interpretations: interpretations.clone(),
                        removed: removed.clone(),
                        proof: Box::new(proof),
                    },
                ])))
            })
            .with_selected_atom(selected_atom),
        )
    }
}
