use crate::core::{RelativeTrs, RewriteRule, Trs};

pub(crate) fn after_rule_removal(relative: &RelativeTrs, removed: &[RewriteRule]) -> RelativeTrs {
    let strict_rules = relative
        .strict()
        .rules()
        .iter()
        .filter(|rule| !removed.contains(rule))
        .cloned()
        .collect();
    let weak_rules = relative
        .weak_rules()
        .iter()
        .filter(|rule| !removed.contains(rule))
        .cloned()
        .collect();
    RelativeTrs::new(
        Trs::new_with_strategy(
            relative.strict().name().map(str::to_string),
            relative.strict().variables().clone(),
            strict_rules,
            relative.strict().strategy(),
        ),
        weak_rules,
    )
}
