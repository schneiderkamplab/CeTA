use crate::proving::dependency_pairs::{DpOptions, reconstruct_dependency_pair_proof};
use crate::proving::processors::dp::DpProblemState;

use super::super::{
    ProblemCertificate, ProblemState, ProcessorApplication, ProcessorResult, WorklistProcessor,
};
use super::{RelativeAdpProof, RelativeAdpProofTree};

pub struct RelativeAdpDerelatificationProcessor {
    pub options: DpOptions,
}

impl WorklistProcessor for RelativeAdpDerelatificationProcessor {
    fn name(&self) -> &'static str {
        "relative-adp-derelatification"
    }
    fn apply(&self, state: &ProblemState) -> ProcessorResult {
        let ProblemState::RelativeAnnotatedDependencyPairs(state) = state else {
            return ProcessorResult::Inapplicable;
        };
        if state.graph_pending {
            return ProcessorResult::Inapplicable;
        }
        let transformed = state.problem.move_annotated_base_to_main();
        let Some(ordinary) = transformed.to_ordinary_dp_problem(&state.template) else {
            return ProcessorResult::Inapplicable;
        };
        let dp_state = DpProblemState::nonminimal(
            ordinary.rules.clone(),
            ordinary.pairs.clone(),
            self.options.clone(),
        );
        let reconstruction = dp_state.clone();
        let canonical = state.problem.clone();
        let ordinary_pairs = ordinary.pairs;
        let ordinary_rules = ordinary.rules.rules().to_vec();
        ProcessorResult::Applied(ProcessorApplication::new(
            vec![ProblemState::DependencyPairs(dp_state)],
            move |children| {
                let [ProblemCertificate::DependencyPairTree(tree)] =
                    <[ProblemCertificate; 1]>::try_from(children).ok()?
                else {
                    return None;
                };
                let proof = reconstruct_dependency_pair_proof(&reconstruction, tree);
                Some(ProblemCertificate::RelativeAnnotatedDependencyPairs(
                    RelativeAdpProof {
                        canonical: canonical.clone(),
                        proof: RelativeAdpProofTree::Derelatify {
                            transformed: transformed.clone(),
                            ordinary_pairs: ordinary_pairs.clone(),
                            ordinary_rules: ordinary_rules.clone(),
                            proof: Box::new(proof),
                        },
                    },
                ))
            },
        ))
    }
}
