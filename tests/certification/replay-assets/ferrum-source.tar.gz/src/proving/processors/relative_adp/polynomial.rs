use std::time::Instant;

use crate::proving::dependency_pairs::DpOptions;

use super::super::{
    ProblemCertificate, ProblemState, ProcessorApplication, ProcessorResult, WorklistProcessor,
};
use super::{RelativeAdpProblemState, RelativeAdpProof, RelativeAdpProofTree};

pub struct RelativeAdpPolynomialProcessor {
    pub options: DpOptions,
    pub deadline: Option<Instant>,
}

impl WorklistProcessor for RelativeAdpPolynomialProcessor {
    fn name(&self) -> &'static str {
        "relative-adp-polynomial"
    }
    fn apply(&self, state: &ProblemState) -> ProcessorResult {
        let ProblemState::RelativeAnnotatedDependencyPairs(state) = state else {
            return ProcessorResult::Inapplicable;
        };
        if state.graph_pending {
            return ProcessorResult::Inapplicable;
        }
        let Some((residual, step)) = state
            .problem
            .remove_by_polynomial(&self.options, self.deadline)
        else {
            return ProcessorResult::Inapplicable;
        };
        let residual_state = RelativeAdpProblemState {
            problem: residual.clone(),
            template: state.template.clone(),
            graph_pending: true,
        };
        let canonical = state.problem.clone();
        ProcessorResult::Applied(ProcessorApplication::new(
            vec![ProblemState::RelativeAnnotatedDependencyPairs(
                residual_state,
            )],
            move |children| {
                let [ProblemCertificate::RelativeAnnotatedDependencyPairs(proof)] =
                    <[ProblemCertificate; 1]>::try_from(children).ok()?
                else {
                    return None;
                };
                Some(ProblemCertificate::RelativeAnnotatedDependencyPairs(
                    RelativeAdpProof {
                        canonical: canonical.clone(),
                        proof: RelativeAdpProofTree::Polynomial {
                            step: step.clone(),
                            residual: residual.clone(),
                            proof: Box::new(proof.proof),
                        },
                    },
                ))
            },
        ))
    }
}
