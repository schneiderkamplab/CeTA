use super::super::{
    ProblemCertificate, ProblemState, ProcessorApplication, ProcessorResult, WorklistProcessor,
};
use super::{RelativeAdpProblemState, RelativeAdpProof, RelativeAdpProofTree};

pub struct RelativeAdpDependencyGraphProcessor;

impl WorklistProcessor for RelativeAdpDependencyGraphProcessor {
    fn name(&self) -> &'static str {
        "relative-adp-dependency-graph"
    }
    fn apply(&self, state: &ProblemState) -> ProcessorResult {
        let ProblemState::RelativeAnnotatedDependencyPairs(state) = state else {
            return ProcessorResult::Inapplicable;
        };
        if !state.graph_pending {
            return ProcessorResult::Inapplicable;
        }
        let children = state.problem.dependency_graph_children(&state.template);
        if children.is_empty() {
            return ProcessorResult::Applied(ProcessorApplication::solved(
                ProblemCertificate::RelativeAnnotatedDependencyPairs(RelativeAdpProof {
                    canonical: state.problem.clone(),
                    proof: RelativeAdpProofTree::Empty,
                }),
            ));
        }
        let problems = children.clone();
        let template = state.template.clone();
        let residuals = children
            .into_iter()
            .map(|child| {
                ProblemState::RelativeAnnotatedDependencyPairs(RelativeAdpProblemState {
                    problem: child.problem,
                    template: template.clone(),
                    graph_pending: false,
                })
            })
            .collect();
        let canonical = state.problem.clone();
        ProcessorResult::Applied(ProcessorApplication::new(residuals, move |children| {
            let mut proofs = Vec::with_capacity(problems.len());
            for (graph_child, child) in problems.iter().cloned().zip(children) {
                let ProblemCertificate::RelativeAnnotatedDependencyPairs(proof) = child else {
                    return None;
                };
                proofs.push((graph_child, Box::new(proof.proof)));
            }
            Some(ProblemCertificate::RelativeAnnotatedDependencyPairs(
                RelativeAdpProof {
                    canonical: canonical.clone(),
                    proof: RelativeAdpProofTree::DependencyGraph { children: proofs },
                },
            ))
        }))
    }
}
