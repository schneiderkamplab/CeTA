use crate::core::RewriteStrategy;
use crate::proving::{Proof, ProofStep, Status};

use super::super::{
    ProblemCertificate, ProblemState, ProcessorApplication, ProcessorResult, WorklistProcessor,
};
use super::{RelativeAdpProblem, RelativeAdpProblemState};

pub struct RelativeAdpTransformationProcessor;

impl WorklistProcessor for RelativeAdpTransformationProcessor {
    fn name(&self) -> &'static str {
        "relative-annotated-dependency-pairs"
    }
    fn apply(&self, state: &ProblemState) -> ProcessorResult {
        let relative = match state {
            ProblemState::RelativeTrs(relative) => relative,
            _ => return ProcessorResult::Inapplicable,
        };
        if relative.strict().strategy() != RewriteStrategy::Full {
            return ProcessorResult::Inapplicable;
        }
        let Some(canonical) = RelativeAdpProblem::canonical(relative) else {
            return ProcessorResult::Inapplicable;
        };
        let residual = RelativeAdpProblemState {
            problem: canonical,
            template: relative.clone(),
            graph_pending: true,
        };
        ProcessorResult::Applied(ProcessorApplication::new(
            vec![ProblemState::RelativeAnnotatedDependencyPairs(residual)],
            move |children| {
                let [ProblemCertificate::RelativeAnnotatedDependencyPairs(proof)] =
                    <[ProblemCertificate; 1]>::try_from(children).ok()?
                else {
                    return None;
                };
                Some(ProblemCertificate::Trs(Proof::with_status(
                    Status::Terminating,
                    vec![ProofStep::RelativeAnnotatedDependencyPairProof {
                        proof: Box::new(proof),
                    }],
                )))
            },
        ))
    }
}
