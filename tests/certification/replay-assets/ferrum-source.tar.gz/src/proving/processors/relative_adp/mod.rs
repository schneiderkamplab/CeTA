//! Annotated dependency pairs for relative termination (IJCAR 2024).
//!
//! This module keeps annotations as positions in the unmarked right-hand side.
//! That mirrors Definitions 15 and 17 directly and avoids encoding proof state
//! into user-visible function-symbol names.

use std::collections::{BTreeMap, BTreeSet};

use crate::core::{RelativeTrs, RewriteRule, Symbol, Term, Trs, Variable};
use crate::proving::dependency_pairs::{
    ceta_tcap_dependency_edge_for_rules, synthesize_relative_adp_polynomial_reduction_pair,
};
use crate::proving::{DependencyPair, DependencyPairProof, DpOptions};
use serde_json::json;

mod dependency_graph;
mod derelatification;
mod erasure_reduction_pair;
mod polynomial;
mod transformation;

pub use dependency_graph::RelativeAdpDependencyGraphProcessor;
pub use derelatification::RelativeAdpDerelatificationProcessor;
pub use erasure_reduction_pair::RelativeAdpErasureReductionPairProcessor;
pub use polynomial::RelativeAdpPolynomialProcessor;
pub use transformation::RelativeAdpTransformationProcessor;

pub type Position = Vec<usize>;

#[derive(Clone, Copy, Debug, Eq, Hash, Ord, PartialEq, PartialOrd)]
pub enum RelativeAdpOrigin {
    Main,
    Base,
}

#[derive(Clone, Debug, Eq, Hash, Ord, PartialEq, PartialOrd)]
pub struct AnnotatedDependencyPair {
    pub lhs: Term,
    pub rhs: Term,
    pub annotations: BTreeSet<Position>,
    pub origin: RelativeAdpOrigin,
    pub source_rule: usize,
}

impl AnnotatedDependencyPair {
    pub fn erase(&self) -> RewriteRule {
        RewriteRule::new(self.lhs.clone(), self.rhs.clone())
    }

    pub fn annotation_count(&self) -> usize {
        self.annotations.len()
    }

    pub fn is_unannotated(&self) -> bool {
        self.annotations.is_empty()
    }
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct RelativeAdpProblem {
    pub main: Vec<AnnotatedDependencyPair>,
    pub base: Vec<AnnotatedDependencyPair>,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct RelativeAdpProblemState {
    pub problem: RelativeAdpProblem,
    pub template: RelativeTrs,
    pub graph_pending: bool,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct DerelatifiedDpProblem {
    pub pairs: Vec<DependencyPair>,
    pub rules: Trs,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct RelativeAdpPolynomialStep {
    pub interpretations: Vec<(String, i64, Vec<i64>)>,
    pub strict_main: Vec<usize>,
    pub strict_base: Vec<usize>,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct RelativeAdpErasureReductionPairStep {
    pub interpretations: Vec<(String, i64, Vec<i64>)>,
    pub strict_main: Vec<usize>,
    pub strict_base: Vec<usize>,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct RelativeAdpProof {
    pub canonical: RelativeAdpProblem,
    pub proof: RelativeAdpProofTree,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct RelativeAdpGraphChild {
    /// Original-problem indices represented in the candidate, for diagnostics.
    pub selected: Vec<usize>,
    /// The complete candidate Q, including flattened main ADPs used by lassos.
    pub candidate: Vec<AnnotatedDependencyPair>,
    pub problem: RelativeAdpProblem,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub enum RelativeAdpProofTree {
    Empty,
    DependencyGraph {
        children: Vec<(RelativeAdpGraphChild, Box<RelativeAdpProofTree>)>,
    },
    Polynomial {
        step: RelativeAdpPolynomialStep,
        residual: RelativeAdpProblem,
        proof: Box<RelativeAdpProofTree>,
    },
    ErasureReductionPair {
        step: RelativeAdpErasureReductionPairStep,
        residual: RelativeAdpProblem,
        proof: Box<RelativeAdpProofTree>,
    },
    Derelatify {
        transformed: RelativeAdpProblem,
        ordinary_pairs: Vec<DependencyPair>,
        ordinary_rules: Vec<RewriteRule>,
        proof: Box<DependencyPairProof>,
    },
}

/// Complete content-addressable representation of a relative annotated-DP
/// residual. CPF has no standalone input production for this processor
/// problem, so the worklist uses this explicit Ferrum state document.
pub(crate) fn serialize_relative_adp_state(state: &RelativeAdpProblemState) -> String {
    let encode = |pairs: &[AnnotatedDependencyPair]| {
        pairs
            .iter()
            .map(|pair| {
                json!({
                    "lhs": pair.lhs.to_string(),
                    "rhs": pair.rhs.to_string(),
                    "annotations": pair.annotations,
                    "origin": match pair.origin {
                        RelativeAdpOrigin::Main => "main",
                        RelativeAdpOrigin::Base => "base",
                    },
                    "source_rule": pair.source_rule,
                })
            })
            .collect::<Vec<_>>()
    };
    serde_json::to_string(&json!({
        "schema": "ferrum.relative-adp-state.v1",
        "template_cpf": crate::cert::write_relative_trs_input_cpf3(&state.template),
        "graph_pending": state.graph_pending,
        "main": encode(&state.problem.main),
        "base": encode(&state.problem.base),
    }))
    .expect("relative ADP state serialization is infallible")
}

impl RelativeAdpProblem {
    /// The canonical `(A1(R), A2(S))` problem from Definition 17.
    ///
    /// The chain criterion requires the base TRS to be non-duplicating.  A
    /// caller may first move duplicating base rules to the main TRS, but must
    /// never construct a canonical problem while this precondition fails.
    pub fn canonical(relative: &RelativeTrs) -> Option<Self> {
        if !rules_are_nonduplicating(relative.weak_rules()) {
            return None;
        }
        let defined = relative.union().defined_symbols();
        let main = canonical_adps(
            relative.strict().rules(),
            &defined,
            1,
            RelativeAdpOrigin::Main,
            0,
        );
        let base = canonical_adps(
            relative.weak_rules(),
            &defined,
            2,
            RelativeAdpOrigin::Base,
            relative.strict().rules().len(),
        );
        Some(Self { main, base })
    }

    pub fn base_is_unannotated(&self) -> bool {
        self.base
            .iter()
            .all(AnnotatedDependencyPair::is_unannotated)
    }

    /// Move annotated base ADPs unchanged into the main component.
    ///
    /// The weak relation is unchanged and the strict relation only grows. A
    /// following DRP1 step still creates one ordinary dependency pair for each
    /// annotated RHS position.
    pub fn move_annotated_base_to_main(&self) -> Self {
        let mut main = self.main.clone();
        let mut base = Vec::with_capacity(self.base.len());
        for adp in &self.base {
            if adp.is_unannotated() {
                base.push(adp.clone());
                continue;
            }
            let mut moved = adp.clone();
            moved.origin = RelativeAdpOrigin::Main;
            main.push(moved);
        }
        deduplicate_adps(&mut main);
        deduplicate_adps(&mut base);
        Self { main, base }
    }

    /// The first derelatifying processor (Theorem 26).
    pub fn to_ordinary_dp_problem(&self, template: &RelativeTrs) -> Option<DerelatifiedDpProblem> {
        if !self.base_is_unannotated() {
            return None;
        }
        let mut pairs = Vec::new();
        for adp in &self.main {
            let lhs = mark_root(&adp.lhs)?;
            for position in &adp.annotations {
                let rhs = mark_root(subterm_at(&adp.rhs, position)?)?;
                let pair =
                    DependencyPair::new_for_nontermination(lhs.clone(), rhs, adp.source_rule);
                if !pairs.contains(&pair) {
                    pairs.push(pair);
                }
            }
        }
        let mut rules = self
            .main
            .iter()
            .chain(&self.base)
            .map(AnnotatedDependencyPair::erase)
            .collect::<Vec<_>>();
        deduplicate_rules(&mut rules);
        Some(DerelatifiedDpProblem {
            pairs,
            rules: Trs::new_with_strategy(
                template.strict().name().map(str::to_string),
                template.strict().variables().clone(),
                rules,
                template.strict().strategy(),
            ),
        })
    }

    /// The polynomial instance of Theorem 36.  The fresh binary compound
    /// symbol is accepted only with coefficients `[1, 1]`, which establishes
    /// c-monotonicity and c-invariance for natural linear polynomials.
    pub fn remove_by_polynomial(
        &self,
        options: &DpOptions,
        deadline: Option<std::time::Instant>,
    ) -> Option<(Self, RelativeAdpPolynomialStep)> {
        let all = self.main.iter().chain(&self.base).collect::<Vec<_>>();
        let constraints = all
            .iter()
            .map(|adp| {
                Some(DependencyPair::new_for_nontermination(
                    mark_root(&adp.lhs)?,
                    annotation_summary(adp)?,
                    adp.source_rule,
                ))
            })
            .collect::<Option<Vec<_>>>()?;
        let mut erased_rules = all.iter().map(|adp| adp.erase()).collect::<Vec<_>>();
        deduplicate_rules(&mut erased_rules);
        let strict_candidates = self
            .main
            .iter()
            .map(|_| true)
            .chain(self.base.iter().map(|adp| !adp.is_unannotated()))
            .enumerate()
            .filter_map(|(index, candidate)| candidate.then_some(index))
            .collect::<Vec<_>>();
        let (interpretations, strict) = synthesize_relative_adp_polynomial_reduction_pair(
            &constraints,
            &erased_rules,
            &strict_candidates,
            options,
            deadline,
        )?;
        let strict = strict.into_iter().collect::<BTreeSet<_>>();
        let strict_main = (0..self.main.len())
            .filter(|index| strict.contains(index))
            .collect::<Vec<_>>();
        let strict_base = (0..self.base.len())
            .filter(|index| strict.contains(&(self.main.len() + index)))
            .collect::<Vec<_>>();
        debug_assert!(!strict_main.is_empty() || !strict_base.is_empty());
        debug_assert!(
            strict_base
                .iter()
                .all(|index| !self.base[*index].is_unannotated())
        );
        let mut main = Vec::new();
        let mut base = Vec::new();
        for (index, adp) in self.main.iter().enumerate() {
            if strict_main.contains(&index) {
                let mut erased = adp.clone();
                erased.annotations.clear();
                erased.origin = RelativeAdpOrigin::Base;
                base.push(erased);
            } else {
                main.push(adp.clone());
            }
        }
        for (index, adp) in self.base.iter().enumerate() {
            if strict_base.contains(&index) {
                let mut erased = adp.clone();
                erased.annotations.clear();
                base.push(erased);
            } else {
                base.push(adp.clone());
            }
        }
        deduplicate_adps(&mut main);
        deduplicate_adps(&mut base);
        let interpretations = interpretations
            .into_iter()
            .map(|(symbol, interpretation)| {
                (symbol, interpretation.constant, interpretation.coefficients)
            })
            .collect();
        Some((
            Self { main, base },
            RelativeAdpPolynomialStep {
                interpretations,
                strict_main,
                strict_base,
            },
        ))
    }

    /// A monotone reduction-pair processor over erased ADP rules.
    ///
    /// Every ADP is weakly oriented after erasing annotations. Strict main
    /// ADPs are moved to the base component without annotations; strict
    /// annotated base ADPs are replaced by their unannotated copies. Since
    /// erasure maps every semantic ADP step to an ordinary rewrite step, a
    /// selected ADP can occur only finitely often in an infinite chain.
    pub fn remove_by_erasure_polynomial(
        &self,
        options: &DpOptions,
        deadline: Option<std::time::Instant>,
    ) -> Option<(Self, RelativeAdpErasureReductionPairStep)> {
        let all = self.main.iter().chain(&self.base).collect::<Vec<_>>();
        let constraints = all
            .iter()
            .map(|adp| {
                DependencyPair::new_for_nontermination(
                    adp.lhs.clone(),
                    adp.rhs.clone(),
                    adp.source_rule,
                )
            })
            .collect::<Vec<_>>();
        let strict_candidates = self
            .main
            .iter()
            .map(|_| true)
            .chain(self.base.iter().map(|adp| !adp.is_unannotated()))
            .enumerate()
            .filter_map(|(index, candidate)| candidate.then_some(index))
            .collect::<Vec<_>>();
        let (interpretations, strict) = synthesize_relative_adp_polynomial_reduction_pair(
            &constraints,
            &[],
            &strict_candidates,
            options,
            deadline,
        )?;
        let strict = strict.into_iter().collect::<BTreeSet<_>>();
        let strict_main = (0..self.main.len())
            .filter(|index| strict.contains(index))
            .collect::<Vec<_>>();
        let strict_base = (0..self.base.len())
            .filter(|index| strict.contains(&(self.main.len() + index)))
            .collect::<Vec<_>>();
        if strict_main.is_empty() && strict_base.is_empty() {
            return None;
        }
        let mut main = Vec::new();
        let mut base = Vec::new();
        for (index, adp) in self.main.iter().enumerate() {
            if strict_main.contains(&index) {
                let mut erased = adp.clone();
                erased.annotations.clear();
                erased.origin = RelativeAdpOrigin::Base;
                base.push(erased);
            } else {
                main.push(adp.clone());
            }
        }
        for (index, adp) in self.base.iter().enumerate() {
            if strict_base.contains(&index) {
                let mut erased = adp.clone();
                erased.annotations.clear();
                base.push(erased);
            } else {
                base.push(adp.clone());
            }
        }
        deduplicate_adps(&mut main);
        deduplicate_adps(&mut base);
        Some((
            Self { main, base },
            RelativeAdpErasureReductionPairStep {
                interpretations: interpretations
                    .into_iter()
                    .map(|(symbol, interpretation)| {
                        (symbol, interpretation.constant, interpretation.coefficients)
                    })
                    .collect(),
                strict_main,
                strict_base,
            },
        ))
    }

    /// The verified CeTA candidate family: main SCCs, plus every branching-base
    /// SCC/predecessor-cone/source-to-main corridor lasso candidate.
    pub fn dependency_graph_children(&self, template: &RelativeTrs) -> Vec<RelativeAdpGraphChild> {
        let problem = semantic_remdups(self.main.iter().chain(&self.base).cloned());
        if problem.is_empty() {
            return Vec::new();
        }
        let graph = relative_dependency_graph_for_problem(&problem, template);
        let mut candidates = estimated_sccs(&graph)
            .into_iter()
            .filter(|component| {
                component
                    .iter()
                    .any(|index| semantic_contains(&self.main, &problem[*index]))
            })
            .map(|component| {
                component
                    .into_iter()
                    .map(|index| problem[index].clone())
                    .collect::<Vec<_>>()
            })
            .collect::<Vec<_>>();

        let lasso_problem = semantic_remdups(
            self.main
                .iter()
                .map(flatten_adp)
                .chain(self.base.iter().cloned()),
        );
        let lasso_graph = relative_dependency_graph_for_problem(&lasso_problem, template);
        let reachable = (0..problem.len())
            .map(|source| reachable_indices(&graph, source))
            .collect::<Vec<_>>();
        let coreachable = (0..problem.len())
            .map(|target| coreachable_indices(&graph, target))
            .collect::<Vec<_>>();

        for component in estimated_sccs(&lasso_graph) {
            for source in 0..problem.len() {
                let source_pair = &problem[source];
                if !semantic_contains(&self.base, source_pair)
                    || !component
                        .iter()
                        .any(|index| semantic_eq(&lasso_problem[*index], source_pair))
                    || source_pair.annotation_count() <= 1
                {
                    continue;
                }
                for target in 0..problem.len() {
                    if !semantic_contains(&self.main, &problem[target])
                        || !reachable[source].contains(&target)
                    {
                        continue;
                    }
                    let corridor = reachable[source]
                        .iter()
                        .copied()
                        .filter(|middle| coreachable[target].contains(middle));
                    let candidate = semantic_remdups(
                        component
                            .iter()
                            .map(|index| lasso_problem[*index].clone())
                            .chain(
                                coreachable[source]
                                    .iter()
                                    .map(|index| problem[*index].clone()),
                            )
                            .chain(corridor.map(|index| problem[index].clone())),
                    );
                    candidates.push(candidate);
                }
            }
        }

        let mut unique_candidates: Vec<Vec<AnnotatedDependencyPair>> = Vec::new();
        for candidate in candidates {
            if !unique_candidates
                .iter()
                .any(|existing| semantic_candidate_eq(existing, &candidate))
            {
                unique_candidates.push(candidate);
            }
        }

        unique_candidates
            .into_iter()
            .map(|candidate| self.graph_child_from_candidate(&problem, candidate))
            .collect()
    }

    pub fn graph_child_from_selected(&self, selected: &[usize]) -> Option<Self> {
        let nodes = semantic_remdups(self.main.iter().chain(&self.base).cloned());
        if selected.is_empty()
            || selected.windows(2).any(|indices| indices[0] >= indices[1])
            || selected.iter().any(|index| *index >= nodes.len())
        {
            return None;
        }
        let candidate = selected
            .iter()
            .map(|index| nodes[*index].clone())
            .collect::<Vec<_>>();
        Some(self.graph_child_from_candidate(&nodes, candidate).problem)
    }

    fn graph_child_from_candidate(
        &self,
        problem: &[AnnotatedDependencyPair],
        candidate: Vec<AnnotatedDependencyPair>,
    ) -> RelativeAdpGraphChild {
        let main = self
            .main
            .iter()
            .filter(|pair| semantic_contains(&candidate, pair))
            .cloned()
            .collect::<Vec<_>>();
        let base = semantic_remdups(
            candidate
                .iter()
                .cloned()
                .chain(
                    problem
                        .iter()
                        .filter(|pair| !semantic_contains(&candidate, pair))
                        .map(flatten_adp),
                )
                .filter(|pair| !semantic_contains(&main, pair)),
        );
        let selected = problem
            .iter()
            .enumerate()
            .filter_map(|(index, pair)| semantic_contains(&candidate, pair).then_some(index))
            .collect();
        RelativeAdpGraphChild {
            selected,
            candidate,
            problem: Self { main, base },
        }
    }
}

fn relative_dependency_graph(nodes: &[&AnnotatedDependencyPair], erased: &Trs) -> Vec<Vec<usize>> {
    nodes
        .iter()
        .map(|source| {
            nodes
                .iter()
                .enumerate()
                .filter_map(|(target_index, target)| {
                    source
                        .annotations
                        .iter()
                        .filter_map(|position| subterm_at(&source.rhs, position))
                        .any(|rhs| ceta_tcap_dependency_edge_for_rules(erased, rhs, &target.lhs))
                        .then_some(target_index)
                })
                .collect()
        })
        .collect()
}

fn semantic_eq(left: &AnnotatedDependencyPair, right: &AnnotatedDependencyPair) -> bool {
    left.lhs == right.lhs && left.rhs == right.rhs && left.annotations == right.annotations
}

fn semantic_contains(pairs: &[AnnotatedDependencyPair], pair: &AnnotatedDependencyPair) -> bool {
    pairs.iter().any(|candidate| semantic_eq(candidate, pair))
}

fn semantic_candidate_eq(
    left: &[AnnotatedDependencyPair],
    right: &[AnnotatedDependencyPair],
) -> bool {
    left.len() == right.len()
        && left
            .iter()
            .zip(right)
            .all(|(left_pair, right_pair)| semantic_eq(left_pair, right_pair))
}

fn semantic_remdups(
    pairs: impl IntoIterator<Item = AnnotatedDependencyPair>,
) -> Vec<AnnotatedDependencyPair> {
    let mut result = Vec::new();
    for pair in pairs {
        if !semantic_contains(&result, &pair) {
            result.push(pair);
        }
    }
    result
}

fn flatten_adp(pair: &AnnotatedDependencyPair) -> AnnotatedDependencyPair {
    let mut result = pair.clone();
    result.annotations.clear();
    result.origin = RelativeAdpOrigin::Base;
    result
}

fn relative_dependency_graph_for_problem(
    problem: &[AnnotatedDependencyPair],
    template: &RelativeTrs,
) -> Vec<Vec<usize>> {
    let mut erased_rules = problem.iter().map(AnnotatedDependencyPair::erase).collect();
    deduplicate_rules(&mut erased_rules);
    let erased = Trs::new_with_strategy(
        template.strict().name().map(str::to_string),
        template.strict().variables().clone(),
        erased_rules,
        template.strict().strategy(),
    );
    let nodes = problem.iter().collect::<Vec<_>>();
    relative_dependency_graph(&nodes, &erased)
}

fn reachable_indices(graph: &[Vec<usize>], source: usize) -> Vec<usize> {
    let mut result = vec![source];
    let mut seen = vec![false; graph.len()];
    seen[source] = true;
    let mut cursor = 0;
    while cursor < result.len() {
        let node = result[cursor];
        cursor += 1;
        for successor in graph[node].iter().copied() {
            if !seen[successor] {
                seen[successor] = true;
                result.push(successor);
            }
        }
    }
    result
}

fn coreachable_indices(graph: &[Vec<usize>], target: usize) -> Vec<usize> {
    let reverse = (0..graph.len())
        .map(|node| {
            graph
                .iter()
                .enumerate()
                .filter_map(|(source, successors)| successors.contains(&node).then_some(source))
                .collect::<Vec<_>>()
        })
        .collect::<Vec<_>>();
    reachable_indices(&reverse, target)
}

fn estimated_sccs(graph: &[Vec<usize>]) -> Vec<Vec<usize>> {
    struct Tarjan<'a> {
        graph: &'a [Vec<usize>],
        next_index: usize,
        indices: Vec<Option<usize>>,
        lowlink: Vec<usize>,
        stack: Vec<usize>,
        on_stack: Vec<bool>,
        components: Vec<Vec<usize>>,
    }
    impl Tarjan<'_> {
        fn visit(&mut self, node: usize) {
            let index = self.next_index;
            self.next_index += 1;
            self.indices[node] = Some(index);
            self.lowlink[node] = index;
            self.stack.push(node);
            self.on_stack[node] = true;
            for successor in self.graph[node].iter().copied() {
                if self.indices[successor].is_none() {
                    self.visit(successor);
                    self.lowlink[node] = self.lowlink[node].min(self.lowlink[successor]);
                } else if self.on_stack[successor] {
                    self.lowlink[node] = self.lowlink[node].min(self.indices[successor].unwrap());
                }
            }
            if self.lowlink[node] == self.indices[node].unwrap() {
                let mut component = Vec::new();
                loop {
                    let member = self.stack.pop().unwrap();
                    self.on_stack[member] = false;
                    component.push(member);
                    if member == node {
                        break;
                    }
                }
                component.sort_unstable();
                self.components.push(component);
            }
        }
    }
    let mut tarjan = Tarjan {
        graph,
        next_index: 0,
        indices: vec![None; graph.len()],
        lowlink: vec![0; graph.len()],
        stack: Vec::new(),
        on_stack: vec![false; graph.len()],
        components: Vec::new(),
    };
    for node in 0..graph.len() {
        if tarjan.indices[node].is_none() {
            tarjan.visit(node);
        }
    }
    tarjan.components.reverse();
    tarjan.components
}

fn deduplicate_adps(adps: &mut Vec<AnnotatedDependencyPair>) {
    let mut seen = BTreeSet::new();
    adps.retain(|adp| seen.insert(adp.clone()));
}

fn deduplicate_rules(rules: &mut Vec<RewriteRule>) {
    let mut unique = Vec::new();
    for rule in rules.drain(..) {
        if !unique.contains(&rule) {
            unique.push(rule);
        }
    }
    *rules = unique;
}

fn subterm_at<'a>(term: &'a Term, position: &[usize]) -> Option<&'a Term> {
    let mut current = term;
    for index in position {
        let Term::App { args, .. } = current else {
            return None;
        };
        current = args.get(*index)?;
    }
    Some(current)
}

fn mark_root(term: &Term) -> Option<Term> {
    let Term::App { symbol, args } = term else {
        return None;
    };
    Some(Term::app(format!("{}#", symbol.as_str()), args.clone()))
}

fn annotation_summary(adp: &AnnotatedDependencyPair) -> Option<Term> {
    let mut annotations = adp.annotations.iter();
    let Some(first) = annotations.next() else {
        return Some(Term::app("__ferrum_adp_c0", vec![]));
    };
    let first = mark_root(subterm_at(&adp.rhs, first)?)?;
    let Some(second_position) = annotations.next() else {
        return Some(first);
    };
    if annotations.next().is_some() {
        return None;
    }
    let second = mark_root(subterm_at(&adp.rhs, second_position)?)?;
    Some(Term::app("__ferrum_adp_c2", vec![first, second]))
}

fn canonical_adps(
    rules: &[RewriteRule],
    defined: &BTreeSet<Symbol>,
    max_annotations: usize,
    origin: RelativeAdpOrigin,
    source_offset: usize,
) -> Vec<AnnotatedDependencyPair> {
    let mut result = Vec::new();
    for (rule_index, rule) in rules.iter().enumerate() {
        let mut positions = Vec::new();
        collect_defined_positions(rule.rhs(), defined, &mut Vec::new(), &mut positions);
        let annotation_sets = maximal_bounded_subsets(&positions, max_annotations);
        for annotations in annotation_sets {
            result.push(AnnotatedDependencyPair {
                lhs: rule.lhs().clone(),
                rhs: rule.rhs().clone(),
                annotations,
                origin,
                source_rule: source_offset + rule_index,
            });
        }
    }
    result
}

fn collect_defined_positions(
    term: &Term,
    defined: &BTreeSet<Symbol>,
    position: &mut Position,
    result: &mut Vec<Position>,
) {
    let Term::App { symbol, args } = term else {
        return;
    };
    if defined.contains(symbol) {
        result.push(position.clone());
    }
    for (index, argument) in args.iter().enumerate() {
        position.push(index);
        collect_defined_positions(argument, defined, position, result);
        position.pop();
    }
}

fn maximal_bounded_subsets(positions: &[Position], bound: usize) -> Vec<BTreeSet<Position>> {
    let size = positions.len().min(bound);
    if size == 0 {
        return vec![BTreeSet::new()];
    }
    let mut result = Vec::new();
    choose_positions(positions, size, 0, &mut BTreeSet::new(), &mut result);
    result
}

fn choose_positions(
    positions: &[Position],
    remaining: usize,
    start: usize,
    current: &mut BTreeSet<Position>,
    result: &mut Vec<BTreeSet<Position>>,
) {
    if remaining == 0 {
        result.push(current.clone());
        return;
    }
    for index in start..=positions.len() - remaining {
        current.insert(positions[index].clone());
        choose_positions(positions, remaining - 1, index + 1, current, result);
        current.remove(&positions[index]);
    }
}

pub fn rules_are_nonduplicating(rules: &[RewriteRule]) -> bool {
    rules.iter().all(|rule| {
        let lhs = variable_multiplicities(rule.lhs());
        variable_multiplicities(rule.rhs())
            .into_iter()
            .all(|(variable, rhs_count)| rhs_count <= lhs.get(&variable).copied().unwrap_or(0))
    })
}

fn variable_multiplicities(term: &Term) -> BTreeMap<Variable, usize> {
    fn collect(term: &Term, counts: &mut BTreeMap<Variable, usize>) {
        match term {
            Term::Var(variable) => *counts.entry(variable.clone()).or_default() += 1,
            Term::App { args, .. } => {
                for argument in args {
                    collect(argument, counts);
                }
            }
        }
    }
    let mut counts = BTreeMap::new();
    collect(term, &mut counts);
    counts
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::core::{RewriteStrategy, Trs};

    fn relative(strict: Vec<RewriteRule>, weak: Vec<RewriteRule>) -> RelativeTrs {
        RelativeTrs::new(
            Trs::new_with_strategy(None, BTreeSet::new(), strict, RewriteStrategy::Full),
            weak,
        )
    }

    #[test]
    fn canonical_redex_creating_example_has_two_base_annotations() {
        let problem = relative(
            vec![RewriteRule::new(
                Term::app("a", vec![]),
                Term::app("b", vec![]),
            )],
            vec![RewriteRule::new(
                Term::app("f", vec![]),
                Term::app("d", vec![Term::app("f", vec![]), Term::app("a", vec![])]),
            )],
        );
        let adps = RelativeAdpProblem::canonical(&problem).expect("non-duplicating base TRS");
        assert_eq!(adps.main.len(), 1);
        assert!(adps.main[0].annotations.is_empty());
        assert_eq!(adps.base.len(), 1);
        assert_eq!(adps.base[0].annotations, BTreeSet::from([vec![0], vec![1]]));
    }

    #[test]
    fn a2_keeps_only_inclusion_maximal_pairs() {
        let problem = relative(
            vec![RewriteRule::new(
                Term::app("a", vec![]),
                Term::app("b", vec![]),
            )],
            vec![RewriteRule::new(
                Term::app("f", vec![]),
                Term::app(
                    "d",
                    vec![
                        Term::app("f", vec![]),
                        Term::app("a", vec![]),
                        Term::app("a", vec![]),
                    ],
                ),
            )],
        );
        let adps = RelativeAdpProblem::canonical(&problem).expect("canonical ADPs");
        assert_eq!(adps.base.len(), 3);
        assert!(adps.base.iter().all(|adp| adp.annotation_count() == 2));
    }

    #[test]
    fn canonical_problem_rejects_duplicating_base_trs() {
        let x = Term::var("x");
        let problem = relative(
            vec![RewriteRule::new(
                Term::app("a", vec![]),
                Term::app("b", vec![]),
            )],
            vec![RewriteRule::new(
                Term::app("f", vec![x.clone()]),
                Term::app("g", vec![x.clone(), x]),
            )],
        );
        assert!(RelativeAdpProblem::canonical(&problem).is_none());
    }

    #[test]
    fn derelatification_two_then_one_produces_ordinary_dps() {
        let problem = relative(
            vec![RewriteRule::new(
                Term::app("a", vec![]),
                Term::app("b", vec![]),
            )],
            vec![RewriteRule::new(
                Term::app("f", vec![Term::app("s", vec![Term::var("y")])]),
                Term::app(
                    "d",
                    vec![Term::app("f", vec![Term::var("y")]), Term::app("a", vec![])],
                ),
            )],
        );
        let canonical = RelativeAdpProblem::canonical(&problem).expect("canonical ADPs");
        assert!(!canonical.base_is_unannotated());
        let transformed = canonical.move_annotated_base_to_main();
        assert!(transformed.base_is_unannotated());
        let ordinary = transformed
            .to_ordinary_dp_problem(&problem)
            .expect("first derelatifying processor applies");
        assert_eq!(ordinary.pairs.len(), 2);
        assert!(
            ordinary
                .pairs
                .iter()
                .any(|pair| pair.lhs().to_string() == "f#(s(y))"
                    && pair.rhs().to_string() == "f#(y)")
        );
        assert!(
            ordinary
                .pairs
                .iter()
                .any(|pair| pair.lhs().to_string() == "f#(s(y))" && pair.rhs().to_string() == "a#")
        );
    }

    #[test]
    fn relative_graph_includes_the_redex_creating_minimal_lasso() {
        let problem = relative(
            vec![RewriteRule::new(
                Term::app("a", vec![]),
                Term::app("b", vec![]),
            )],
            vec![RewriteRule::new(
                Term::app("f", vec![]),
                Term::app("d", vec![Term::app("f", vec![]), Term::app("a", vec![])]),
            )],
        );
        let canonical = RelativeAdpProblem::canonical(&problem).expect("canonical ADPs");
        let children = canonical.dependency_graph_children(&problem);
        assert_eq!(children.len(), 2);
        let lasso = children
            .iter()
            .find(|child| child.problem == canonical)
            .expect("the branching-base lasso retains the complete problem");
        assert_eq!(lasso.selected.len(), 2);
        assert_eq!(
            canonical.graph_child_from_selected(&lasso.selected),
            Some(lasso.problem.clone())
        );
        assert!(canonical.graph_child_from_selected(&[]).is_none());
        assert!(canonical.graph_child_from_selected(&[0, 0]).is_none());
        assert!(canonical.graph_child_from_selected(&[2]).is_none());
    }

    #[test]
    fn relative_graph_closes_an_acyclic_annotated_problem() {
        let problem = relative(
            vec![RewriteRule::new(
                Term::app("f", vec![Term::var("x")]),
                Term::app("g", vec![Term::var("x")]),
            )],
            Vec::new(),
        );
        let canonical = RelativeAdpProblem::canonical(&problem).expect("canonical ADPs");
        let children = canonical.dependency_graph_children(&problem);
        assert_eq!(children.len(), 1);
        assert_eq!(children[0].problem, canonical);
    }

    #[test]
    fn polynomial_processor_rejects_strict_but_already_flat_base_adp() {
        let problem = RelativeAdpProblem {
            main: Vec::new(),
            base: vec![AnnotatedDependencyPair {
                lhs: Term::app("f", vec![Term::var("x")]),
                rhs: Term::var("x"),
                annotations: BTreeSet::new(),
                origin: RelativeAdpOrigin::Base,
                source_rule: 0,
            }],
        };

        assert!(
            problem
                .remove_by_polynomial(&DpOptions::default(), None)
                .is_none()
        );
    }

    #[test]
    fn polynomial_processor_uses_the_additive_compound_algebra() {
        let x = Term::var("x");
        let y = Term::var("y");
        let problem = RelativeAdpProblem {
            main: vec![AnnotatedDependencyPair {
                lhs: Term::app(
                    "f",
                    vec![
                        Term::app("s", vec![x.clone()]),
                        Term::app("s", vec![y.clone()]),
                    ],
                ),
                rhs: Term::app("c", vec![Term::app("g", vec![x]), Term::app("h", vec![y])]),
                annotations: BTreeSet::from([vec![0], vec![1]]),
                origin: RelativeAdpOrigin::Main,
                source_rule: 0,
            }],
            base: Vec::new(),
        };

        let (_, witness) = problem
            .remove_by_polynomial(&DpOptions::default(), None)
            .expect("the branching ADP is additively orientable");
        let compound = witness
            .interpretations
            .iter()
            .find(|(name, _, _)| name == "__ferrum_adp_c2")
            .expect("binary compound interpretation");
        assert_eq!((compound.1, compound.2.as_slice()), (0, [1, 1].as_slice()));
    }

    #[test]
    fn erasure_reduction_pair_moves_strict_main_adp_to_flat_base() {
        let x = Term::var("x");
        let problem = RelativeAdpProblem {
            main: vec![AnnotatedDependencyPair {
                lhs: Term::app("f", vec![Term::app("s", vec![x.clone()])]),
                rhs: Term::app("f", vec![x]),
                annotations: BTreeSet::from([Vec::new()]),
                origin: RelativeAdpOrigin::Main,
                source_rule: 0,
            }],
            base: Vec::new(),
        };

        let (residual, witness) = problem
            .remove_by_erasure_polynomial(&DpOptions::default(), None)
            .expect("the erased ADP is strictly polynomially orientable");

        assert_eq!(witness.strict_main, vec![0]);
        assert!(witness.strict_base.is_empty());
        assert!(!witness.interpretations.is_empty());
        assert!(residual.main.is_empty());
        assert_eq!(residual.base.len(), 1);
        assert!(residual.base[0].is_unannotated());
        assert_eq!(residual.base[0].origin, RelativeAdpOrigin::Base);
        assert_eq!(residual.base[0].lhs, problem.main[0].lhs);
        assert_eq!(residual.base[0].rhs, problem.main[0].rhs);
    }
}
