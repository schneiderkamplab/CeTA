use std::collections::{HashMap, HashSet, VecDeque};
use std::fmt;
use std::sync::Arc;
use std::sync::atomic::{AtomicUsize, Ordering};

use super::traits::ProofReconstruction;
use super::{ProblemCertificate, ProblemState, ProcessorResult};

#[derive(Clone, Debug, Eq, PartialEq)]
pub enum WorklistFailureKind {
    Inapplicable,
    Failed(String),
    TimedOut,
    InvalidReconstruction,
}

#[derive(Clone, Debug)]
pub struct WorklistFailure {
    pub state: Option<ProblemState>,
    pub kind: WorklistFailureKind,
}

impl fmt::Display for WorklistFailure {
    fn fmt(&self, formatter: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(formatter, "processor worklist failed: {:?}", self.kind)
    }
}

impl std::error::Error for WorklistFailure {}

#[derive(Clone, Copy, Debug)]
enum CompletionTarget {
    Root(usize),
    Child { node: usize, index: usize },
}

#[derive(Clone)]
struct PendingNode {
    target: CompletionTarget,
    cache_key: Option<String>,
    reconstruction: Option<Arc<dyn ProofReconstruction>>,
    child_short_circuit:
        Option<Arc<dyn Fn(&ProblemCertificate) -> Option<ProblemCertificate> + Send + Sync>>,
    children: Vec<Option<Arc<ProblemCertificate>>>,
    unresolved: usize,
}

#[derive(Clone)]
struct LazyTask {
    // Alternatives differ in their cursor and reconstruction bookkeeping,
    // not in the immutable processor input. Sharing that input avoids copying
    // every remaining SCC (and its entire TRS) at each sibling choice.
    state: Arc<ProblemState>,
    cache_key: Option<String>,
    target: CompletionTarget,
    cursor: usize,
    // A top-level cycle identity can include a large exact transformation
    // witness. Keep exact equality without copying its bytes into each SCC
    // and each retained alternative.
    ancestry: HashSet<Arc<str>>,
    is_root: bool,
}

#[derive(Clone)]
struct LazySearchBranch {
    roots: Vec<Option<Arc<ProblemCertificate>>>,
    queue: VecDeque<LazyTask>,
    pending: Vec<PendingNode>,
    solved: HashMap<String, Arc<ProblemCertificate>>,
    speculative_depth: usize,
    // Shared by every descendant alternative of a bounded search choice.
    // The sibling that selects the next choice does not inherit this budget.
    attempt_budgets: Vec<Arc<AtomicUsize>>,
}

fn reusable_certificate_key(state: &ProblemState) -> Option<String> {
    let ProblemState::DependencyPairs(problem) = state else {
        return None;
    };
    use sha2::{Digest, Sha256};
    let input = crate::proving::dependency_pairs::dp_state_input_cpf(problem);
    Some(format!("{:x}", Sha256::digest(input.trim().as_bytes())))
}

// A certified, state-local oracle path commonly contains a long sequence of
// simplifying transformations.  Keep that path depth-first long enough to
// reach its terminal residual before revisiting sibling processor choices.
// Cycle keys still prevent a non-progressing transformation from starving
// the retained alternatives.
const MAX_SPECULATIVE_BRANCH_DEPTH: usize = 1024;

fn speculation_limit(setting: Option<&str>) -> usize {
    setting
        .and_then(|value| value.parse::<usize>().ok())
        .filter(|limit| *limit > 0)
        .unwrap_or(MAX_SPECULATIVE_BRANCH_DEPTH)
}

/// One lazily materialized atomic attempt.
///
/// Search alternatives retain their untried suffix. Mandatory normalization
/// steps do not: skipping one would create a different, ill-formed scheduler
/// state rather than a legitimate processor alternative.
pub struct LazyProcessorAttempt {
    pub result: ProcessorResult,
    pub next_cursor: usize,
    pub retain_fallback: bool,
    pub cycle_key: Option<String>,
    pub continuation_attempt_limit: Option<usize>,
}

impl LazyProcessorAttempt {
    pub fn alternative(result: ProcessorResult, next_cursor: usize) -> Self {
        Self {
            result,
            next_cursor,
            retain_fallback: true,
            cycle_key: None,
            continuation_attempt_limit: None,
        }
    }

    pub fn required(result: ProcessorResult, next_cursor: usize) -> Self {
        Self {
            result,
            next_cursor,
            retain_fallback: false,
            cycle_key: None,
            continuation_attempt_limit: None,
        }
    }

    pub fn with_cycle_key(mut self, cycle_key: String) -> Self {
        self.cycle_key = Some(cycle_key);
        self
    }

    pub fn with_continuation_attempt_limit(mut self, limit: Option<usize>) -> Self {
        self.continuation_attempt_limit = limit.filter(|limit| *limit > 0);
        self
    }
}

/// Lazy alternative worklist used by portfolios with expensive processors.
/// The scheduler returns one atomic attempt and the cursor of its successor;
/// later alternatives are not synthesized unless the current branch fails.
pub fn solve_worklist_lazy(
    initial: Vec<ProblemState>,
    next: impl FnMut(&ProblemState, usize, bool) -> Option<LazyProcessorAttempt>,
) -> Result<Vec<ProblemCertificate>, WorklistFailure> {
    solve_worklist_lazy_until(initial, || false, next)
}

pub fn solve_worklist_lazy_until(
    initial: Vec<ProblemState>,
    mut should_stop: impl FnMut() -> bool,
    mut next: impl FnMut(&ProblemState, usize, bool) -> Option<LazyProcessorAttempt>,
) -> Result<Vec<ProblemCertificate>, WorklistFailure> {
    // Oracle growth can turn a formerly immediate dead end into a long open
    // continuation. Allow bounded scheduling experiments without changing
    // processors, certificates, or the established default search order.
    let speculation_limit = speculation_limit(
        std::env::var("FERRUM_WORKLIST_SPECULATION_DEPTH").ok().as_deref(),
    );
    let root_count = initial.len();
    let queue = initial
        .into_iter()
        .enumerate()
        .map(|(index, state)| LazyTask {
            cache_key: reusable_certificate_key(&state),
            state: Arc::new(state),
            target: CompletionTarget::Root(index),
            cursor: 0,
            ancestry: HashSet::new(),
            is_root: true,
        })
        .collect();
    let mut agenda = vec![LazySearchBranch {
        roots: vec![None; root_count],
        queue,
        pending: Vec::new(),
        solved: HashMap::new(),
        speculative_depth: 0,
        attempt_budgets: Vec::new(),
    }];
    let mut last_failure = None;
    let mut last_processor_failure_state = None;

    while !agenda.is_empty() {
        // Do not drain a potentially exponential backlog of retained
        // alternatives after the enclosing processor deadline. Individual
        // atoms observe the same deadline, but returning TimedOut from each
        // one is not enough when thousands of sibling branches are already
        // materialized.
        if should_stop() {
            return Err(WorklistFailure {
                state: None,
                kind: WorklistFailureKind::TimedOut,
            });
        }
        let mut branch = agenda.pop().expect("nonempty agenda");
        let Some(mut task) = branch.queue.pop_front() else {
            if let Some(certificates) = branch.roots.into_iter().collect::<Option<Vec<_>>>() {
                return Ok(certificates.into_iter().map(Arc::unwrap_or_clone).collect());
            }
            last_failure = Some(invalid_reconstruction_state());
            continue;
        };
        if let Some(certificate) = task
            .cache_key
            .as_ref()
            .and_then(|key| branch.solved.get(key))
            .cloned()
        {
            if std::env::var_os("FERRUM_WORKLIST_TRACE").is_some() {
                eprintln!(
                    "worklist reused certificate key={:?}",
                    task.cache_key.as_deref()
                );
            }
            if let Err(failure) = complete_target(
                task.target,
                certificate,
                &mut branch.roots,
                &mut branch.pending,
                &mut branch.solved,
                &mut branch.queue,
            ) {
                last_failure = Some(failure);
                continue;
            }
            agenda.push(branch);
            continue;
        }
        if std::env::var_os("FERRUM_WORKLIST_TRACE").is_some() {
            eprintln!(
                "worklist task kind={} cursor={} root={} queue={} ancestry={}",
                match task.state.as_ref() {
                    ProblemState::DependencyPairs(problem) => {
                        if problem.pairs.is_empty() {
                            "dp-empty"
                        } else {
                            "dp"
                        }
                    }
                    ProblemState::Trs(_) => "trs",
                    ProblemState::Srs(_) => "srs",
                    ProblemState::Csr(_) => "csr",
                    ProblemState::RelativeTrs(_) => "relative-trs",
                    ProblemState::RelativeSrs(_) => "relative-srs",
                    ProblemState::RelativeAnnotatedDependencyPairs(_) => "relative-adp",
                },
                task.cursor,
                task.is_root,
                branch.queue.len(),
                task.ancestry.len(),
            );
        }
        if std::env::var_os("FERRUM_WORKLIST_TRACE_INPUTS").is_some()
            && let ProblemState::DependencyPairs(problem) = task.state.as_ref()
        {
            eprintln!("worklist-input {}", serde_json::to_string(
                &crate::proving::dependency_pairs::dp_state_input_cpf(problem)).unwrap());
        }
        let application = loop {
            if branch.attempt_budgets.iter().any(|budget| {
                budget
                    .fetch_update(Ordering::Relaxed, Ordering::Relaxed, |remaining| {
                        remaining.checked_sub(1)
                    })
                    .is_err()
            }) {
                last_processor_failure_state = Some(task.state.clone());
                last_failure = Some(WorklistFailure {
                    state: None,
                    kind: WorklistFailureKind::Failed(
                        "continuation search budget exhausted".into(),
                    ),
                });
                break None;
            }
            let next_started = std::time::Instant::now();
            let Some(attempt) = next(&task.state, task.cursor, task.is_root) else {
                if std::env::var_os("FERRUM_WORKLIST_TRACE").is_some() {
                    eprintln!("worklist task exhausted at cursor={}", task.cursor);
                }
                if task.cursor == 0 {
                    last_processor_failure_state = Some(task.state.clone());
                    last_failure = Some(WorklistFailure {
                        state: None, kind: WorklistFailureKind::Inapplicable,
                    });
                }
                break None;
            };
            if std::env::var_os("FERRUM_TIMING_TRACE").is_some() {
                eprintln!(
                    "worklist next elapsed_ms={} cursor={}",
                    next_started.elapsed().as_millis(),
                    task.cursor
                );
            }
            task.cursor = attempt.next_cursor;
            if attempt
                .cycle_key
                .as_ref()
                .is_some_and(|key| task.ancestry.contains(key.as_str()))
            {
                if std::env::var_os("FERRUM_WORKLIST_TRACE").is_some() {
                    eprintln!(
                        "worklist skipped ancestral cycle cursor={} key={:?}",
                        task.cursor, attempt.cycle_key,
                    );
                }
                continue;
            }
            if let Some(cycle_key) = attempt.cycle_key {
                task.ancestry.insert(cycle_key.into());
            }
            match attempt.result {
                ProcessorResult::Applied(application) => {
                    break Some((
                        application,
                        attempt.retain_fallback,
                        attempt.continuation_attempt_limit,
                    ));
                }
                ProcessorResult::Inapplicable => {
                    last_processor_failure_state = Some(task.state.clone());
                    last_failure = Some(WorklistFailure {
                        state: None,
                        kind: WorklistFailureKind::Inapplicable,
                    });
                }
                ProcessorResult::Failed { reason } => {
                    last_processor_failure_state = Some(task.state.clone());
                    last_failure = Some(WorklistFailure {
                        state: None,
                        kind: WorklistFailureKind::Failed(reason),
                    });
                }
                ProcessorResult::TimedOut => {
                    last_processor_failure_state = Some(task.state.clone());
                    last_failure = Some(WorklistFailure {
                        state: None,
                        kind: WorklistFailureKind::TimedOut,
                    });
                }
            }
        };
        let Some((application, retain_fallback, continuation_attempt_limit)) = application else {
            continue;
        };

        let expansion_started = std::time::Instant::now();

        let fallback = if retain_fallback {
            // Preserve the untried suffix as an explicit sibling search branch.
            let mut fallback = branch.clone();
            fallback.queue.push_front(task.clone());
            fallback.speculative_depth = 0;
            Some(fallback)
        } else {
            None
        };

        if let Some(limit) = continuation_attempt_limit {
            branch.attempt_budgets.push(Arc::new(AtomicUsize::new(limit)));
        }

        let (residuals, reconstruction, child_short_circuit) = application.into_worklist_parts();
        if std::env::var_os("FERRUM_TIMING_TRACE").is_some() {
            eprintln!(
                "worklist application unpack elapsed_ms={} residuals={}",
                expansion_started.elapsed().as_millis(),
                residuals.len()
            );
        }
        if residuals.is_empty() {
            let Some(certificate) = reconstruction.reconstruct(Vec::new()) else {
                if std::env::var_os("FERRUM_WORKLIST_TRACE").is_some() {
                    eprintln!(
                        "worklist reconstruction rejected terminal certificate for {:?}",
                        task.state
                    );
                }
                last_failure = Some(WorklistFailure {
                    state: Some(Arc::unwrap_or_clone(task.state)),
                    kind: WorklistFailureKind::InvalidReconstruction,
                });
                continue;
            };
            let certificate = Arc::new(certificate);
            if let Some(key) = &task.cache_key {
                branch.solved.insert(key.clone(), certificate.clone());
            }
            if let Err(failure) = complete_target(
                task.target,
                certificate,
                &mut branch.roots,
                &mut branch.pending,
                &mut branch.solved,
                &mut branch.queue,
            ) {
                if std::env::var_os("FERRUM_WORKLIST_TRACE").is_some() {
                    eprintln!("worklist completion failed: {failure:?}");
                }
                last_failure = Some(failure);
                continue;
            }
        } else {
            let node = branch.pending.len();
            branch.pending.push(PendingNode {
                target: task.target,
                cache_key: task.cache_key.clone(),
                children: vec![None; residuals.len()],
                unresolved: residuals.len(),
                reconstruction: Some(reconstruction),
                child_short_circuit,
            });
            let children = residuals
                .into_iter()
                .enumerate()
                .map(|(index, state)| LazyTask {
                    cache_key: reusable_certificate_key(&state),
                    state: Arc::new(state),
                    target: CompletionTarget::Child { node, index },
                    cursor: 0,
                    ancestry: task.ancestry.clone(),
                    is_root: false,
                })
                .collect::<Vec<_>>();
            // Finish the freshly exposed residual chain before exploring its
            // siblings.  Appending children behind the existing queue makes
            // alternatives from independent SCCs multiply: a doomed first
            // child is discovered only after every later sibling portfolio
            // has been enumerated.  Reverse insertion preserves residual
            // order while keeping the search depth-first within each child.
            for child in children.into_iter().rev() {
                branch.queue.push_front(child);
            }
        }
        if std::env::var_os("FERRUM_TIMING_TRACE").is_some() {
            eprintln!(
                "worklist expansion finish elapsed_ms={}",
                expansion_started.elapsed().as_millis()
            );
        }
        // A fairness boundary must never defer an already reconstructed
        // complete proof behind untried alternatives.
        if branch.roots.iter().all(Option::is_some) {
            return Ok(branch.roots.into_iter()
                .map(|certificate| Arc::unwrap_or_clone(certificate.expect("checked complete")))
                .collect());
        }
        branch.speculative_depth += 1;
        if let Some(fallback) = fallback {
            if branch.speculative_depth >= speculation_limit {
                // Bound depth-first speculation so a repeatable
                // transformation cannot starve the retained processor suffix.
                agenda.push(branch);
                agenda.push(fallback);
            } else {
                agenda.push(fallback);
                agenda.push(branch);
            }
        } else {
            agenda.push(branch);
        }
    }

    let mut failure = last_failure.unwrap_or(WorklistFailure {
        state: None,
        kind: WorklistFailureKind::Inapplicable,
    });
    if failure.state.is_none() && failure.kind != WorklistFailureKind::InvalidReconstruction {
        failure.state = last_processor_failure_state.map(Arc::unwrap_or_clone);
    }
    if std::env::var_os("FERRUM_WORKLIST_TRACE").is_some() {
        let key = failure.state.as_ref().and_then(|state| match state {
            ProblemState::DependencyPairs(problem) => {
                use sha2::{Digest, Sha256};
                let input = crate::proving::dependency_pairs::dp_state_input_cpf(problem);
                Some(format!("{:x}", Sha256::digest(input.trim().as_bytes())))
            }
            _ => None,
        });
        eprintln!("worklist exhausted: kind={:?} key={key:?}", failure.kind);
    }
    Err(failure)
}

fn complete_target(
    mut target: CompletionTarget,
    mut certificate: Arc<ProblemCertificate>,
    roots: &mut [Option<Arc<ProblemCertificate>>],
    pending: &mut [PendingNode],
    solved: &mut HashMap<String, Arc<ProblemCertificate>>,
    queue: &mut VecDeque<LazyTask>,
) -> Result<(), WorklistFailure> {
    loop {
        match target {
            CompletionTarget::Root(index) => {
                roots[index] = Some(certificate);
                return Ok(());
            }
            CompletionTarget::Child { node, index } => {
                let shortcut = {
                    let parent = &mut pending[node];
                    parent
                        .child_short_circuit
                        .as_ref()
                        .and_then(|short_circuit| short_circuit(&certificate))
                        .map(|parent_certificate| {
                            parent.reconstruction = None;
                            (parent.target, parent.cache_key.clone(), parent_certificate)
                        })
                };
                if let Some((parent_target, cache_key, parent_certificate)) = shortcut {
                    let parent_certificate = Arc::new(parent_certificate);
                    // Residuals are processed depth-first, so every still
                    // queued descendant of this node is an unvisited sibling.
                    // It is irrelevant once this disjunctive certificate has
                    // completed the parent.
                    queue.retain(|task| {
                        !matches!(task.target, CompletionTarget::Child { node: owner, .. } if owner == node)
                    });
                    if let Some(key) = cache_key {
                        solved.insert(key.clone(), parent_certificate.clone());
                    }
                    certificate = parent_certificate;
                    target = parent_target;
                    continue;
                }
                let parent = &mut pending[node];
                if parent.children[index].replace(certificate).is_some() {
                    return Err(invalid_reconstruction_state());
                }
                parent.unresolved -= 1;
                if parent.unresolved != 0 {
                    return Ok(());
                }
                let children = parent
                    .children
                    .iter_mut()
                    .map(Option::take)
                    .collect::<Option<Vec<_>>>()
                    .ok_or_else(invalid_reconstruction_state)?;
                let reconstruction = parent
                    .reconstruction
                    .take()
                    .ok_or_else(invalid_reconstruction_state)?;
                certificate = match reconstruction.reconstruct(
                    children.into_iter().map(Arc::unwrap_or_clone).collect(),
                ) {
                    Some(certificate) => Arc::new(certificate),
                    None => {
                        if std::env::var_os("FERRUM_WORKLIST_TRACE").is_some() {
                            eprintln!(
                                "worklist reconstruction rejected node={node} target={:?}",
                                parent.target
                            );
                        }
                        return Err(invalid_reconstruction_state());
                    }
                };
                if let Some(key) = &parent.cache_key {
                    solved.insert(key.clone(), certificate.clone());
                }
                target = parent.target;
            }
        }
    }
}

fn invalid_reconstruction_state() -> WorklistFailure {
    WorklistFailure {
        state: None,
        kind: WorklistFailureKind::InvalidReconstruction,
    }
}

#[cfg(test)]
mod tests {
    #[test]
    fn continuation_budget_is_shared_by_descendants_but_not_outer_alternative() {
        let named = |name: &str| ProblemState::Trs(crate::core::Trs::new(
            Some(name.into()), Default::default(), Vec::new()));
        let mut child_attempts = 0;
        let certificates = solve_worklist_lazy(vec![named("root")], |state, cursor, _| {
            let ProblemState::Trs(trs) = state else { return None };
            if trs.name() == Some("root") && cursor == 1 {
                return Some(LazyProcessorAttempt::alternative(
                    EmptySystemProcessor.apply(state), 2));
            }
            let is_root = trs.name() == Some("root");
            if !is_root {
                child_attempts += 1;
                assert!(child_attempts <= 8, "descendant alternatives must share the budget");
            }
            let result = ProcessorResult::Applied(ProcessorApplication::new(
                vec![named("open")], |mut children: Vec<ProblemCertificate>| children.pop()));
            Some(LazyProcessorAttempt::alternative(result, cursor + 1)
                .with_continuation_attempt_limit(is_root.then_some(8)))
        }).expect("exhausting one choice must retain the next outer alternative");
        assert_eq!(certificates.len(), 1);
        assert_eq!(child_attempts, 8);
    }

    #[test]
    fn complete_root_is_returned_before_any_unused_alternative() {
        let state = ProblemState::Trs(crate::core::Trs::new(None, Default::default(), Vec::new()));
        let certificates = solve_worklist_lazy(vec![state], |state, cursor, _| {
            assert_eq!(cursor, 0, "completed proof must not be deferred");
            Some(LazyProcessorAttempt::alternative(EmptySystemProcessor.apply(state), 1))
        })
        .unwrap();
        assert_eq!(certificates.len(), 1);
    }

    #[test]
    fn speculation_budget_is_positive_and_defaults_are_unchanged() {
        assert_eq!(super::speculation_limit(None), 1024);
        assert_eq!(super::speculation_limit(Some("0")), 1024);
        assert_eq!(super::speculation_limit(Some("invalid")), 1024);
        assert_eq!(super::speculation_limit(Some("32")), 32);
    }

    use super::*;
    use crate::proving::processors::ProcessorApplication;
    use crate::proving::processors::{WorklistProcessor, top_level::EmptySystemProcessor};
    use crate::proving::{Proof, ProofStep, Status};
    use std::sync::atomic::{AtomicUsize, Ordering};

    #[test]
    fn alternatives_share_immutable_inputs_but_keep_independent_cursors() {
        let task = LazyTask {
            state: Arc::new(ProblemState::Trs(crate::core::Trs::new(
                None, Default::default(), Vec::new(),
            ))),
            cache_key: None,
            target: CompletionTarget::Root(0),
            cursor: 0,
            ancestry: HashSet::new(),
            is_root: true,
        };
        let mut alternative = task.clone();
        alternative.cursor = 7;
        alternative.ancestry.insert("alternative".into());
        assert!(Arc::ptr_eq(&task.state, &alternative.state));
        assert_eq!(task.cursor, 0);
        assert!(task.ancestry.is_empty());
    }

    #[test]
    fn exhausted_guidance_retains_the_blocked_state() {
        let state = ProblemState::Trs(crate::core::Trs::new(
            Some("blocked".to_owned()), Default::default(), Vec::new()));
        let failure = solve_worklist_lazy(vec![state], |_, _, _| None).unwrap_err();
        let Some(ProblemState::Trs(trs)) = failure.state else { panic!("missing blocked state") };
        assert_eq!(trs.name(), Some("blocked"));
    }

    #[test]
    fn empty_processor_solves_a_root_with_no_residuals() {
        let state = ProblemState::Trs(crate::core::Trs::new(None, Default::default(), Vec::new()));
        let certificates = solve_worklist_lazy(vec![state], |state, cursor, _is_root| {
            (cursor == 0)
                .then(|| LazyProcessorAttempt::alternative(EmptySystemProcessor.apply(state), 1))
        })
        .expect("empty worklist state should close");
        let [ProblemCertificate::Trs(proof)] = certificates.as_slice() else {
            panic!("expected one TRS proof")
        };
        assert_eq!(proof.status(), &Status::Terminating);
        assert_eq!(proof.steps(), &[ProofStep::EmptySystem]);
    }

    #[test]
    fn reconstruction_waits_for_every_residual() {
        let nonempty = ProblemState::Trs(crate::core::Trs::new(
            Some("root".to_string()),
            Default::default(),
            vec![crate::core::RewriteRule::new(
                crate::core::Term::app("a", vec![]),
                crate::core::Term::app("b", vec![]),
            )],
        ));
        let empty =
            || ProblemState::Trs(crate::core::Trs::new(None, Default::default(), Vec::new()));
        let certificates = solve_worklist_lazy(vec![nonempty], |state, cursor, _is_root| {
            if cursor != 0 {
                return None;
            }
            let result = match state {
                ProblemState::Trs(trs) if !trs.is_empty() => {
                    ProcessorResult::Applied(ProcessorApplication::new(
                        vec![empty(), empty()],
                        |children: Vec<ProblemCertificate>| {
                            (children.len() == 2).then_some(ProblemCertificate::Trs(
                                Proof::terminating(vec![ProofStep::EmptySystem]),
                            ))
                        },
                    ))
                }
                _ => EmptySystemProcessor.apply(state),
            };
            Some(LazyProcessorAttempt::alternative(result, 1))
        })
        .expect("both child states should close");
        assert_eq!(certificates.len(), 1);
    }

    #[test]
    fn disjunctive_child_certificate_skips_unneeded_siblings() {
        static SECOND_CHILD_ATTEMPTS: AtomicUsize = AtomicUsize::new(0);
        SECOND_CHILD_ATTEMPTS.store(0, Ordering::Relaxed);
        let named = |name: &str| {
            ProblemState::Trs(crate::core::Trs::new(
                Some(name.to_string()),
                Default::default(),
                vec![crate::core::RewriteRule::new(
                    crate::core::Term::app("a", vec![]),
                    crate::core::Term::app("b", vec![]),
                )],
            ))
        };
        let certificates = solve_worklist_lazy(vec![named("root")], |state, cursor, _| {
            if cursor != 0 {
                return None;
            }
            let ProblemState::Trs(trs) = state else {
                return None;
            };
            let result = match trs.name() {
                Some("root") => ProcessorResult::Applied(
                    ProcessorApplication::new(
                        vec![named("witness"), named("unneeded")],
                        |_children: Vec<ProblemCertificate>| None,
                    )
                    .with_child_short_circuit(
                        |certificate| match certificate {
                            ProblemCertificate::Trs(proof)
                                if proof.status() == &Status::Nonterminating =>
                            {
                                Some(ProblemCertificate::Trs(proof.clone()))
                            }
                            _ => None,
                        },
                    ),
                ),
                Some("witness") => ProcessorResult::Applied(ProcessorApplication::solved(
                    ProblemCertificate::Trs(Proof::nonterminating(
                        crate::proving::NonterminationProof::VariableConditionViolated,
                    )),
                )),
                Some("unneeded") => {
                    SECOND_CHILD_ATTEMPTS.fetch_add(1, Ordering::Relaxed);
                    ProcessorResult::Inapplicable
                }
                _ => ProcessorResult::Inapplicable,
            };
            Some(LazyProcessorAttempt::required(result, 1))
        })
        .expect("one disjunctive child should complete the root");

        let [ProblemCertificate::Trs(proof)] = certificates.as_slice() else {
            panic!("expected one TRS certificate")
        };
        assert_eq!(proof.status(), &Status::Nonterminating);
        assert_eq!(SECOND_CHILD_ATTEMPTS.load(Ordering::Relaxed), 0);
    }

    #[test]
    fn identical_dp_siblings_reuse_the_reconstructed_certificate() {
        static CHILD_SOLVES: AtomicUsize = AtomicUsize::new(0);
        CHILD_SOLVES.store(0, Ordering::Relaxed);
        let dp = ProblemState::DependencyPairs(
            crate::proving::processors::dp::DpProblemState::ordinary(
                crate::core::Trs::new(None, Default::default(), Vec::new()),
                Vec::new(),
                crate::proving::DpOptions::default(),
            ),
        );
        let certificates = solve_worklist_lazy(vec![dp.clone()], |state, cursor, is_root| {
            if cursor != 0 {
                return None;
            }
            let result = if is_root {
                ProcessorResult::Applied(ProcessorApplication::new(
                    vec![dp.clone(), dp.clone()],
                    |children: Vec<ProblemCertificate>| {
                        (children.len() == 2).then_some(ProblemCertificate::DependencyPairTree(
                            crate::proving::DpProofTree::Empty,
                        ))
                    },
                ))
            } else {
                let ProblemState::DependencyPairs(_) = state else {
                    return None;
                };
                CHILD_SOLVES.fetch_add(1, Ordering::Relaxed);
                ProcessorResult::Applied(ProcessorApplication::solved(
                    ProblemCertificate::DependencyPairTree(crate::proving::DpProofTree::Empty),
                ))
            };
            Some(LazyProcessorAttempt::alternative(result, 1))
        })
        .expect("identical DP siblings should both close");

        assert_eq!(certificates.len(), 1);
        assert_eq!(CHILD_SOLVES.load(Ordering::Relaxed), 1);
    }

    #[test]
    fn failed_child_resumes_the_next_atomic_processor_alternative() {
        let named = |name: &str| {
            ProblemState::Trs(crate::core::Trs::new(
                Some(name.to_string()),
                Default::default(),
                vec![crate::core::RewriteRule::new(
                    crate::core::Term::app("a", vec![]),
                    crate::core::Term::app("b", vec![]),
                )],
            ))
        };
        let certificates = solve_worklist_lazy(vec![named("root")], |state, cursor, _is_root| {
            let ProblemState::Trs(trs) = state else {
                return None;
            };
            let result = match (trs.name(), cursor) {
                (Some("root"), 0) => ProcessorResult::Applied(ProcessorApplication::new(
                    vec![named("dead-end")],
                    |mut children: Vec<ProblemCertificate>| children.pop(),
                )),
                (Some("root"), 1) => ProcessorResult::Applied(ProcessorApplication::solved(
                    ProblemCertificate::Trs(Proof::terminating(vec![ProofStep::EmptySystem])),
                )),
                (_, 0) => ProcessorResult::Inapplicable,
                _ => return None,
            };
            Some(LazyProcessorAttempt::alternative(result, cursor + 1))
        })
        .expect("the second root processor must survive the first child's failure");
        assert_eq!(certificates.len(), 1);
    }

    #[test]
    fn repeatable_transformations_have_a_bounded_depth_before_retained_alternatives() {
        static TRANSFORMS: AtomicUsize = AtomicUsize::new(0);
        TRANSFORMS.store(0, Ordering::Relaxed);
        let named = |name: String| {
            ProblemState::Trs(crate::core::Trs::new(
                Some(name),
                Default::default(),
                vec![crate::core::RewriteRule::new(
                    crate::core::Term::app("a", vec![]),
                    crate::core::Term::app("b", vec![]),
                )],
            ))
        };
        let certificates = solve_worklist_lazy(vec![named("0".to_string())], |state, cursor, _| {
            let ProblemState::Trs(trs) = state else {
                return None;
            };
            let depth = trs.name()?.parse::<usize>().ok()?;
            let result = match cursor {
                0 => {
                    TRANSFORMS.fetch_add(1, Ordering::Relaxed);
                    ProcessorResult::Applied(ProcessorApplication::new(
                        vec![named((depth + 1).to_string())],
                        |mut children: Vec<ProblemCertificate>| children.pop(),
                    ))
                }
                1 => ProcessorResult::Applied(ProcessorApplication::solved(
                    ProblemCertificate::Trs(Proof::terminating(vec![ProofStep::EmptySystem])),
                )),
                _ => return None,
            };
            Some(LazyProcessorAttempt::alternative(result, cursor + 1))
        })
        .expect("the retained terminal alternative must be scheduled fairly");
        assert_eq!(certificates.len(), 1);
        assert_eq!(TRANSFORMS.load(Ordering::Relaxed), speculation_limit(
            std::env::var("FERRUM_WORKLIST_SPECULATION_DEPTH").ok().as_deref()));
    }

    #[test]
    fn global_stop_discards_retained_alternative_backlog() {
        let checks = AtomicUsize::new(0);
        let state = ProblemState::Trs(crate::core::Trs::new(None, Default::default(), Vec::new()));
        let result = solve_worklist_lazy_until(
            vec![state],
            || checks.fetch_add(1, Ordering::Relaxed) >= 2,
            |state, cursor, _| {
                let residual = state.clone();
                Some(LazyProcessorAttempt::alternative(
                    ProcessorResult::Applied(ProcessorApplication::new(
                        vec![residual],
                        |mut children: Vec<ProblemCertificate>| children.pop(),
                    )),
                    cursor + 1,
                ))
            },
        );

        assert!(matches!(
            result,
            Err(WorklistFailure {
                kind: WorklistFailureKind::TimedOut,
                ..
            })
        ));
        assert!(checks.load(Ordering::Relaxed) <= 4);
    }

    #[test]
    fn failed_residual_chain_is_exhausted_before_later_siblings() {
        static LATER_SIBLING_ATTEMPTS: AtomicUsize = AtomicUsize::new(0);
        LATER_SIBLING_ATTEMPTS.store(0, Ordering::Relaxed);
        let named = |name: &str| {
            ProblemState::Trs(crate::core::Trs::new(
                Some(name.to_string()),
                Default::default(),
                vec![crate::core::RewriteRule::new(
                    crate::core::Term::app("a", vec![]),
                    crate::core::Term::app("b", vec![]),
                )],
            ))
        };
        let result = solve_worklist_lazy(vec![named("root")], |state, cursor, _| {
            let ProblemState::Trs(trs) = state else {
                return None;
            };
            let result = match (trs.name(), cursor) {
                (Some("root"), 0) => ProcessorResult::Applied(ProcessorApplication::new(
                    vec![named("first"), named("later")],
                    |mut children: Vec<ProblemCertificate>| children.pop(),
                )),
                (Some("first"), 0) => ProcessorResult::Applied(ProcessorApplication::new(
                    vec![named("dead-end")],
                    |mut children: Vec<ProblemCertificate>| children.pop(),
                )),
                (Some("dead-end"), 0) => ProcessorResult::Inapplicable,
                (Some("later"), _) => {
                    LATER_SIBLING_ATTEMPTS.fetch_add(1, Ordering::Relaxed);
                    ProcessorResult::Inapplicable
                }
                _ => return None,
            };
            Some(LazyProcessorAttempt::required(result, cursor + 1))
        });
        assert!(result.is_err());
        assert_eq!(LATER_SIBLING_ATTEMPTS.load(Ordering::Relaxed), 0);
    }
}
