use std::fmt;
use std::sync::Arc;

use crate::core::{CsrTrs, RelativeTrs, Trs};

use super::super::dependency_pairs::DpProofTree;
use super::super::processors::relative_adp::{RelativeAdpProblemState, RelativeAdpProof};
use super::super::{DpNonterminationProof, Proof};
use super::dp::DpProblemState;

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub enum CsrProofBoundary {
    /// Dedicated CPF4 extensions such as GM and orthogonality may occur.
    Root,
    /// The state is the direct continuation of one root CSR rule-removal.
    /// CPF4 has dedicated combined constructors for some processors here
    /// (notably improved CS-DPs), but those constructors are not recursively
    /// nestable below an arbitrary CSR proof.
    RootRuleRemovalContinuation,
    /// Only recursively representable native CSR proof constructors may occur.
    Nested,
}

#[derive(Clone, Debug)]
pub struct CsrProblemState {
    pub csr: CsrTrs,
    pub boundary: CsrProofBoundary,
}

impl CsrProblemState {
    pub fn root(csr: CsrTrs) -> Self {
        Self {
            csr,
            boundary: CsrProofBoundary::Root,
        }
    }
    pub fn nested(csr: CsrTrs) -> Self {
        Self {
            csr,
            boundary: CsrProofBoundary::Nested,
        }
    }

    pub fn rule_removal_child(parent: &Self, csr: CsrTrs) -> Self {
        Self {
            csr,
            boundary: if parent.boundary == CsrProofBoundary::Root {
                CsrProofBoundary::RootRuleRemovalContinuation
            } else {
                CsrProofBoundary::Nested
            },
        }
    }
}

/// Every proof obligation handled by Ferrum's processor scheduler.
///
/// SRS states are deliberately distinct from unary TRSs: their processor
/// applicability and CPF reconstruction rules are not interchangeable.
#[derive(Clone, Debug)]
pub enum ProblemState {
    Trs(Trs),
    Srs(Trs),
    Csr(CsrProblemState),
    RelativeTrs(RelativeTrs),
    RelativeSrs(RelativeTrs),
    DependencyPairs(DpProblemState),
    RelativeAnnotatedDependencyPairs(RelativeAdpProblemState),
}

impl ProblemState {
    /// Classify a freshly materialized ordinary residual by its current rule
    /// representation. Rule removal can expose an SRS even when the parent
    /// was not one, so inheriting the parent's enum variant is incorrect.
    pub fn from_trs(trs: Trs) -> Self {
        if trs.srs_rules().is_some() {
            Self::Srs(trs)
        } else {
            Self::Trs(trs)
        }
    }

    pub fn from_relative(relative: RelativeTrs) -> Self {
        if relative.strict().srs_rules().is_some() {
            Self::RelativeSrs(relative)
        } else {
            Self::RelativeTrs(relative)
        }
    }
}

/// A completed certificate for one state kind. Reconstruction functions may
/// only consume certificates matching their residual states.
#[derive(Clone, Debug, Eq, PartialEq)]
pub enum ProblemCertificate {
    Trs(Proof),
    DependencyPairTree(DpProofTree),
    DependencyPairNontermination(DpNonterminationProof),
    RelativeAnnotatedDependencyPairs(RelativeAdpProof),
}

pub trait ProofReconstruction: Send + Sync {
    fn reconstruct(&self, children: Vec<ProblemCertificate>) -> Option<ProblemCertificate>;
}

impl<F> ProofReconstruction for F
where
    F: Fn(Vec<ProblemCertificate>) -> Option<ProblemCertificate> + Send + Sync,
{
    fn reconstruct(&self, children: Vec<ProblemCertificate>) -> Option<ProblemCertificate> {
        self(children)
    }
}

/// The sole successful processor result. An empty residual vector means that
/// the processor solved the state; otherwise every residual must be solved
/// before reconstruction can produce the parent certificate.
pub struct ProcessorApplication {
    pub residuals: Vec<ProblemState>,
    selected_atom: Option<String>,
    reconstruction: Arc<dyn ProofReconstruction>,
    child_short_circuit:
        Option<Arc<dyn Fn(&ProblemCertificate) -> Option<ProblemCertificate> + Send + Sync>>,
}

impl ProcessorApplication {
    pub fn new(
        residuals: Vec<ProblemState>,
        reconstruction: impl ProofReconstruction + 'static,
    ) -> Self {
        Self {
            residuals,
            selected_atom: None,
            reconstruction: Arc::new(reconstruction),
            child_short_circuit: None,
        }
    }

    /// Complete the parent as soon as one child supplies a certificate that
    /// is already sufficient for it.  This is used for disjunctive residuals
    /// such as dependency-graph nontermination: termination needs every SCC,
    /// while one infinite SCC proves the parent infinite.
    pub fn with_child_short_circuit(
        mut self,
        short_circuit: impl Fn(&ProblemCertificate) -> Option<ProblemCertificate>
        + Send
        + Sync
        + 'static,
    ) -> Self {
        self.child_short_circuit = Some(Arc::new(short_circuit));
        self
    }

    /// Record the exact executable atom actually selected by a synthesizing
    /// processor.  This is provenance, not a compatibility continuation: it
    /// must still denote exactly one processor at the current state.
    pub fn with_selected_atom(mut self, atom: impl Into<String>) -> Self {
        self.selected_atom = Some(atom.into());
        self
    }

    pub fn selected_atom(&self) -> Option<&str> {
        self.selected_atom.as_deref()
    }

    pub fn solved(certificate: ProblemCertificate) -> Self {
        Self::new(Vec::new(), move |children: Vec<ProblemCertificate>| {
            children.is_empty().then_some(certificate.clone())
        })
    }

    pub fn reconstruct(&self, children: Vec<ProblemCertificate>) -> Option<ProblemCertificate> {
        self.reconstruction.reconstruct(children)
    }

    pub fn into_parts(self) -> (Vec<ProblemState>, Arc<dyn ProofReconstruction>) {
        (self.residuals, self.reconstruction)
    }

    pub(crate) fn into_worklist_parts(
        self,
    ) -> (
        Vec<ProblemState>,
        Arc<dyn ProofReconstruction>,
        Option<Arc<dyn Fn(&ProblemCertificate) -> Option<ProblemCertificate> + Send + Sync>>,
    ) {
        (
            self.residuals,
            self.reconstruction,
            self.child_short_circuit,
        )
    }

    pub fn into_parts_with_selected_atom(
        self,
    ) -> (
        Vec<ProblemState>,
        Option<String>,
        Arc<dyn ProofReconstruction>,
    ) {
        (self.residuals, self.selected_atom, self.reconstruction)
    }
}

impl fmt::Debug for ProcessorApplication {
    fn fmt(&self, formatter: &mut fmt::Formatter<'_>) -> fmt::Result {
        formatter
            .debug_struct("ProcessorApplication")
            .field("residuals", &self.residuals)
            .field("selected_atom", &self.selected_atom)
            .finish_non_exhaustive()
    }
}

#[derive(Debug)]
pub enum ProcessorResult {
    Applied(ProcessorApplication),
    Inapplicable,
    Failed { reason: String },
    TimedOut,
}

pub trait WorklistProcessor {
    fn name(&self) -> &'static str;
    fn apply(&self, state: &ProblemState) -> ProcessorResult;
}
