//! Test harnesses for exercising the production residual-state worklist.
//!
//! These helpers do not implement processor control flow.  They construct an
//! explicit problem state, invoke the same atomic processor used in production,
//! and let the universal worklist solve every residual.

use std::time::Instant;

use crate::core::{CsrTrs, RewriteRule, RewriteStrategy, Trs};
use crate::proving::dependency_pairs::{
    DependencyPair, DependencyPairProof, DpOptions, DpProofStats, DpStrategy,
    complete_dependency_pair_probe, reconstruct_dependency_pair_proof,
};
use crate::proving::engine::ProveOptions;
use crate::proving::proof::ProofStep;

use super::csr::{CsrDependencyPairKind, CsrDependencyPairTransformationProcessor};
use super::dp::{DpProblemState, initial_innermost_lhss};
use super::top_level::solve_top_level_worklist;
use super::{
    ProblemCertificate, ProblemState, ProcessorResult, WorklistProcessor, solve_worklist_lazy,
};

fn solve_explicit_dp_tree(
    state: DpProblemState,
    strategy: &DpStrategy,
    deadline: Option<Instant>,
) -> Option<crate::proving::DpProofTree> {
    let certificates = solve_worklist_lazy(
        vec![ProblemState::DependencyPairs(state.clone())],
        |state, cursor, is_root| {
            super::dp::next_scheduled_result_with_strategy(
                state,
                cursor,
                deadline,
                is_root.then_some(strategy),
            )
        },
    )
    .ok()?;
    let [ProblemCertificate::DependencyPairTree(tree)] = certificates.as_slice() else {
        return None;
    };
    Some(tree.clone())
}

/// Exercise an explicit atom policy independently at every materialized DP
/// state. This models state-local oracle guidance in focused certification
/// tests; it does not carry a sequence cursor or hidden continuation between
/// parent and child states.
fn solve_explicit_dp_tree_with_atomic_policy(
    state: DpProblemState,
    strategy: &DpStrategy,
    deadline: Option<Instant>,
) -> Option<crate::proving::DpProofTree> {
    let certificates = solve_worklist_lazy(
        vec![ProblemState::DependencyPairs(state.clone())],
        |state, cursor, _| {
            super::dp::next_scheduled_result_with_strategy(state, cursor, deadline, Some(strategy))
        },
    )
    .ok()?;
    let [ProblemCertificate::DependencyPairTree(tree)] = certificates.as_slice() else {
        return None;
    };
    Some(tree.clone())
}

fn solve_explicit_dp_schedule(
    state: DpProblemState,
    strategy: &DpStrategy,
    deadline: Option<Instant>,
) -> Option<DependencyPairProof> {
    let tree = solve_explicit_dp_tree(state.clone(), strategy, deadline)?;
    Some(reconstruct_dependency_pair_proof(&state, tree))
}

pub(crate) fn solve_dependency_pairs(
    trs: &Trs,
    options: &DpOptions,
) -> Option<DependencyPairProof> {
    solve_dependency_pairs_until(trs, options, None)
}

pub(crate) fn solve_dependency_pairs_until(
    trs: &Trs,
    options: &DpOptions,
    deadline: Option<Instant>,
) -> Option<DependencyPairProof> {
    if trs.strategy() == RewriteStrategy::Full
        && !trs.rules().iter().all(RewriteRule::is_well_formed)
    {
        return None;
    }
    solve_dp_state(
        trs,
        crate::proving::dependency_pairs::dependency_pairs(trs),
        options,
        deadline,
    )
}

pub(crate) fn solve_dependency_pairs_with_strategy(
    trs: &Trs,
    options: &DpOptions,
    strategy: &DpStrategy,
    deadline: Option<Instant>,
) -> Option<DependencyPairProof> {
    if trs.strategy() == RewriteStrategy::Full
        && !trs.rules().iter().all(RewriteRule::is_well_formed)
    {
        return None;
    }
    solve_dp_state_with_strategy(
        trs,
        crate::proving::dependency_pairs::dependency_pairs(trs),
        options,
        strategy,
        deadline,
    )
}

pub(crate) fn solve_dp_state(
    trs: &Trs,
    pairs: Vec<DependencyPair>,
    options: &DpOptions,
    deadline: Option<Instant>,
) -> Option<DependencyPairProof> {
    let options = options.clone();
    let mut stats = DpProofStats::default();
    stats.minimal = true;
    stats.normal_form_substitutions = trs.strategy() == RewriteStrategy::Innermost;
    let state = DpProblemState {
        trs: trs.clone(),
        pairs,
        options,
        stats,
        innermost_lhss: initial_innermost_lhss(trs),
        subtree_deadline: deadline,
    };
    let certificate = solve_top_level_worklist(
        ProblemState::DependencyPairs(state.clone()),
        &ProveOptions::default(),
        deadline,
    )
    .ok()?;
    let ProblemCertificate::DependencyPairTree(tree) = certificate else {
        return None;
    };
    Some(reconstruct_dependency_pair_proof(&state, tree))
}

pub(crate) fn solve_dp_state_with_strategy(
    trs: &Trs,
    pairs: Vec<DependencyPair>,
    options: &DpOptions,
    strategy: &DpStrategy,
    deadline: Option<Instant>,
) -> Option<DependencyPairProof> {
    let mut stats = DpProofStats::default();
    stats.minimal = true;
    stats.normal_form_substitutions = trs.strategy() == RewriteStrategy::Innermost;
    solve_explicit_dp_schedule(
        DpProblemState {
            trs: trs.clone(),
            pairs,
            options: options.clone(),
            stats,
            innermost_lhss: initial_innermost_lhss(trs),
            subtree_deadline: deadline,
        },
        strategy,
        deadline,
    )
}

pub(crate) fn probe_dp_atom(
    trs: &Trs,
    pairs: Vec<DependencyPair>,
    options: &DpOptions,
    strategy: &DpStrategy,
    deadline: Option<Instant>,
) -> Option<(Option<DependencyPairProof>, Vec<ProblemState>)> {
    probe_dp_atom_state(trs, pairs, None, true, options, strategy, deadline)
}

pub(crate) fn probe_dp_atom_state(
    trs: &Trs,
    pairs: Vec<DependencyPair>,
    active_rules: Option<Vec<RewriteRule>>,
    minimal: bool,
    options: &DpOptions,
    strategy: &DpStrategy,
    deadline: Option<Instant>,
) -> Option<(Option<DependencyPairProof>, Vec<ProblemState>)> {
    let state = DpProblemState::materialized_from_parts(
        trs.clone(),
        pairs,
        Vec::new(),
        active_rules,
        minimal,
        options.clone(),
    );
    apply_explicit_dp_processor(&state, strategy, deadline)
}

#[allow(clippy::too_many_arguments)]
pub(crate) fn probe_csr_dp_atom(
    csr: &CsrTrs,
    pairs: Vec<DependencyPair>,
    active_rules: Option<Vec<RewriteRule>>,
    minimal: bool,
    construction: &str,
    graph_estimator: &str,
    use_qcs_usable_rules: bool,
    options: &DpOptions,
    strategy: &DpStrategy,
    deadline: Option<Instant>,
) -> Option<(Option<DependencyPairProof>, Vec<ProblemState>)> {
    let state = DpProblemState::csr_materialized_from_parts(
        csr,
        pairs,
        Vec::new(),
        active_rules,
        minimal,
        construction,
        graph_estimator,
        use_qcs_usable_rules,
        options.clone(),
    )?;
    apply_explicit_dp_processor(&state, strategy, deadline)
}

fn apply_explicit_dp_processor(
    state: &DpProblemState,
    strategy: &DpStrategy,
    deadline: Option<Instant>,
) -> Option<(Option<DependencyPairProof>, Vec<ProblemState>)> {
    let root = ProblemState::DependencyPairs(state.clone());
    let mut cursor = 1;
    loop {
        let attempt = super::dp::next_scheduled_result_with_strategy(
            &root,
            cursor,
            deadline,
            Some(strategy),
        )?;
        cursor = attempt.next_cursor;
        let ProcessorResult::Applied(application) = attempt.result else {
            continue;
        };
        let (residuals, reconstruction) = application.into_parts();
        if !residuals.is_empty() {
            return Some((None, residuals));
        }
        let ProblemCertificate::DependencyPairTree(tree) = reconstruction.reconstruct(Vec::new())?
        else {
            return None;
        };
        return Some((
            Some(complete_dependency_pair_probe(state, tree)),
            Vec::new(),
        ));
    }
}

pub(crate) fn solve_csr_dependency_pairs_with_kind(
    csr: &CsrTrs,
    kind: CsrDependencyPairKind,
    options: &DpOptions,
    deadline: Option<Instant>,
) -> Option<DependencyPairProof> {
    let application = match (CsrDependencyPairTransformationProcessor {
        kind,
        options: options.clone(),
    })
    .apply(&ProblemState::Csr(super::CsrProblemState::root(
        csr.clone(),
    ))) {
        ProcessorResult::Applied(application) => application,
        _ => return None,
    };
    let (residuals, reconstruction) = application.into_parts();
    let children = residuals
        .into_iter()
        .map(|residual| solve_top_level_worklist(residual, &ProveOptions::default(), deadline).ok())
        .collect::<Option<Vec<_>>>()?;
    let ProblemCertificate::Trs(proof) = reconstruction.reconstruct(children)? else {
        return None;
    };
    proof.into_steps().into_iter().find_map(|step| match step {
        ProofStep::DependencyPairProof { proof }
        | ProofStep::ContextSensitiveDependencyPairProof { proof, .. }
        | ProofStep::ContextSensitiveInnermostDependencyPairProof { proof, .. } => Some(*proof),
        _ => None,
    })
}

pub(crate) fn solve_csr_dependency_pairs_with_kind_and_strategy(
    csr: &CsrTrs,
    kind: CsrDependencyPairKind,
    options: &DpOptions,
    strategy: &DpStrategy,
    deadline: Option<Instant>,
) -> Option<DependencyPairProof> {
    let application = match (CsrDependencyPairTransformationProcessor {
        kind,
        options: options.clone(),
    })
    .apply(&ProblemState::Csr(super::CsrProblemState::root(
        csr.clone(),
    ))) {
        ProcessorResult::Applied(application) => application,
        _ => return None,
    };
    let (residuals, reconstruction) = application.into_parts();
    let children = residuals
        .into_iter()
        .map(|residual| match residual {
            ProblemState::DependencyPairs(state) => {
                solve_explicit_dp_tree(state, strategy, deadline)
                    .map(ProblemCertificate::DependencyPairTree)
            }
            state => solve_top_level_worklist(state, &ProveOptions::default(), deadline).ok(),
        })
        .collect::<Option<Vec<_>>>()?;
    let ProblemCertificate::Trs(proof) = reconstruction.reconstruct(children)? else {
        return None;
    };
    proof.into_steps().into_iter().find_map(|step| match step {
        ProofStep::DependencyPairProof { proof }
        | ProofStep::ContextSensitiveDependencyPairProof { proof, .. }
        | ProofStep::ContextSensitiveInnermostDependencyPairProof { proof, .. } => Some(*proof),
        _ => None,
    })
}

pub(crate) fn solve_csr_root(
    csr: &CsrTrs,
    options: &DpOptions,
    deadline: Option<Instant>,
) -> Option<DependencyPairProof> {
    let prove_options = ProveOptions {
        dp_options: options.clone(),
        ..ProveOptions::default()
    };
    let ProblemCertificate::Trs(proof) = solve_top_level_worklist(
        ProblemState::Csr(super::CsrProblemState::root(csr.clone())),
        &prove_options,
        deadline,
    )
    .ok()?
    else {
        return None;
    };
    proof.into_steps().into_iter().find_map(|step| match step {
        ProofStep::DependencyPairProof { proof }
        | ProofStep::ContextSensitiveDependencyPairProof { proof, .. }
        | ProofStep::ContextSensitiveInnermostDependencyPairProof { proof, .. } => {
            let proof = *proof;
            proof
                .component_proofs
                .iter()
                .all(|component| component.proved)
                .then_some(proof)
        }
        _ => None,
    })
}

pub(crate) fn solve_csr_root_with_strategy(
    csr: &CsrTrs,
    options: &DpOptions,
    strategy: &DpStrategy,
    deadline: Option<Instant>,
) -> Option<DependencyPairProof> {
    [
        CsrDependencyPairKind::Improved,
        CsrDependencyPairKind::Safe,
        CsrDependencyPairKind::Rta08,
        CsrDependencyPairKind::NativeContextSensitive,
        CsrDependencyPairKind::NativeOrdinary,
        CsrDependencyPairKind::Conservative,
    ]
    .into_iter()
    .find_map(|kind| {
        solve_csr_dependency_pairs_with_kind_and_strategy(csr, kind, options, strategy, deadline)
    })
}

pub(crate) fn solve_csr_dependency_pairs_with_kind_and_atomic_policy(
    csr: &CsrTrs,
    kind: CsrDependencyPairKind,
    options: &DpOptions,
    strategy: &DpStrategy,
    deadline: Option<Instant>,
) -> Option<DependencyPairProof> {
    let application = match (CsrDependencyPairTransformationProcessor {
        kind,
        options: options.clone(),
    })
    .apply(&ProblemState::Csr(super::CsrProblemState::root(
        csr.clone(),
    ))) {
        ProcessorResult::Applied(application) => application,
        _ => return None,
    };
    let (residuals, reconstruction) = application.into_parts();
    let children = residuals
        .into_iter()
        .map(|residual| match residual {
            ProblemState::DependencyPairs(state) => {
                solve_explicit_dp_tree_with_atomic_policy(state, strategy, deadline)
                    .map(ProblemCertificate::DependencyPairTree)
            }
            state => solve_top_level_worklist(state, &ProveOptions::default(), deadline).ok(),
        })
        .collect::<Option<Vec<_>>>()?;
    let ProblemCertificate::Trs(proof) = reconstruction.reconstruct(children)? else {
        return None;
    };
    proof.into_steps().into_iter().find_map(|step| match step {
        ProofStep::DependencyPairProof { proof }
        | ProofStep::ContextSensitiveDependencyPairProof { proof, .. }
        | ProofStep::ContextSensitiveInnermostDependencyPairProof { proof, .. } => Some(*proof),
        _ => None,
    })
}

pub(crate) fn solve_improved_csr_dependency_pairs(
    csr: &CsrTrs,
    options: &DpOptions,
    deadline: Option<Instant>,
) -> Option<DependencyPairProof> {
    solve_csr_dependency_pairs_with_kind(csr, CsrDependencyPairKind::Improved, options, deadline)
}

pub(crate) fn solve_improved_csr_dependency_pairs_with_strategy(
    csr: &CsrTrs,
    options: &DpOptions,
    strategy: &DpStrategy,
    deadline: Option<Instant>,
) -> Option<DependencyPairProof> {
    solve_csr_dependency_pairs_with_kind_and_strategy(
        csr,
        CsrDependencyPairKind::Improved,
        options,
        strategy,
        deadline,
    )
}
