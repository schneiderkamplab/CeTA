use crate::proving::dependency_pairs::{
    CsrDpProblemContext, DpOptions, certificate_improved_csr_dependency_pairs,
    conservative_csr_dependency_problem, csr_dependency_pairs,
    csr_dp_minimal_processors_are_mu_valid, csr_dp_native_certification_issues,
    csr_dp_problem_state, csr_dp_proof_is_conservatively_certifiable,
    csr_rhs_active_variables_are_active_in_lhs,
    csr_rta08_proof_has_component_first_reduction_pairs, innermost_csr_dependency_problem,
    innermost_csr_usable_rules, muterm_expanded_dependency_pairs, muterm_innermost_unhiding_rules,
    muterm_unhiding_is_safe, reconstruct_dependency_pair_proof, rta_csr_dependency_pairs,
    safe_csr_dependency_pair_proof_closes_all_cyclic_components, safe_csr_dependency_pairs,
};
use crate::proving::processors::rewrite_analysis::csr_is_orthogonal;
use crate::proving::{ContextSensitiveDependencyPairConstruction, Proof, ProofStep};

use super::super::{
    ProblemCertificate, ProblemState, ProcessorApplication, ProcessorResult, WorklistProcessor,
};

#[derive(Clone, Copy, Debug, Eq, Hash, PartialEq)]
pub enum CsrDependencyPairKind {
    NativeContextSensitive,
    NativeOrdinary,
    Safe,
    Improved,
    Innermost,
    MutermUnhiding,
    MutermExpanded,
    Rta08,
    Conservative,
}

pub struct CsrDependencyPairTransformationProcessor {
    pub kind: CsrDependencyPairKind,
    pub options: DpOptions,
}

pub(crate) fn materialize_innermost_csr_dependency_pairs(
    root_csr: &crate::core::CsrTrs,
    options: DpOptions,
) -> Option<(
    crate::proving::processors::dp::DpProblemState,
    Vec<crate::core::RewriteRule>,
)> {
    let (problem, pairs) = innermost_csr_dependency_problem(root_csr);
    let auxiliary_rules = problem.rules()[root_csr.rules().len()..].to_vec();
    let context = CsrDpProblemContext::innermost(&problem, root_csr);
    let state = csr_dp_problem_state(&problem, pairs, context, options, None, Vec::new())?;
    Some((state, auxiliary_rules))
}

pub(crate) fn materialize_muterm_unhiding_dependency_pairs(
    root_csr: &crate::core::CsrTrs,
    options: DpOptions,
) -> Option<crate::proving::processors::dp::DpProblemState> {
    // Every currently certified MU-TERM unhiding boundary transfers CSR
    // termination to an innermost problem.  CeTA checks the corresponding
    // orthogonality premise at the root, independently of whether the native
    // pair set contains collapsing pairs.  Keep the runtime applicability
    // test in exact agreement so a successful search cannot become a
    // checker-rejected positive.
    if !csr_is_orthogonal(root_csr) || !muterm_unhiding_is_safe(root_csr) {
        return None;
    }
    let native_pairs = rta_csr_dependency_pairs(root_csr);
    let has_collapsing_pair = native_pairs
        .iter()
        .any(|pair| matches!(pair.rhs(), crate::core::Term::Var(_)));
    // Collapsing problems must retain the native typed root; expansion is a
    // checked component-local operation.  Purely noncollapsing problems keep
    // the established expanded-innermost search route, whose graph and
    // usable-rule processors have a different soundness boundary.
    let (pairs, active_rules) = if has_collapsing_pair {
        (native_pairs, None)
    } else {
        let pairs = muterm_expanded_dependency_pairs(root_csr);
        let active_rules = innermost_csr_usable_rules(root_csr, root_csr.rules(), &pairs);
        (pairs, Some(active_rules))
    };
    csr_dp_problem_state(
        root_csr,
        pairs,
        CsrDpProblemContext::muterm_unhiding(root_csr),
        options,
        active_rules,
        Vec::new(),
    )
}

impl WorklistProcessor for CsrDependencyPairTransformationProcessor {
    fn name(&self) -> &'static str {
        "context-sensitive-dependency-pairs"
    }

    fn apply(&self, state: &ProblemState) -> ProcessorResult {
        let ProblemState::Csr(state) = state else {
            return ProcessorResult::Inapplicable;
        };
        if state.boundary != super::super::CsrProofBoundary::Root {
            let supported = if state.csr.trs().strategy() == crate::core::RewriteStrategy::Innermost
            {
                self.kind == CsrDependencyPairKind::Innermost
            } else {
                matches!(
                    self.kind,
                    CsrDependencyPairKind::NativeContextSensitive
                        | CsrDependencyPairKind::Safe
                        | CsrDependencyPairKind::Improved
                )
            };
            if !supported {
                return ProcessorResult::Inapplicable;
            }
        }
        let root_csr = &state.csr;
        if matches!(
            self.kind,
            CsrDependencyPairKind::NativeContextSensitive | CsrDependencyPairKind::NativeOrdinary
        ) && !csr_rhs_active_variables_are_active_in_lhs(root_csr)
        {
            return ProcessorResult::Inapplicable;
        }
        let (problem_csr, pairs, context, auxiliary_rules) = match self.kind {
            CsrDependencyPairKind::NativeContextSensitive
            | CsrDependencyPairKind::NativeOrdinary => (
                root_csr.clone(),
                csr_dependency_pairs(root_csr),
                CsrDpProblemContext::native(
                    root_csr,
                    if self.kind == CsrDependencyPairKind::NativeContextSensitive {
                        crate::proving::dependency_pairs::CsrGraphEstimator::ContextSensitive
                    } else {
                        crate::proving::dependency_pairs::CsrGraphEstimator::Ordinary
                    },
                    true,
                ),
                None,
            ),
            CsrDependencyPairKind::Safe => (
                root_csr.clone(),
                safe_csr_dependency_pairs(root_csr),
                CsrDpProblemContext::safe(root_csr),
                None,
            ),
            CsrDependencyPairKind::Improved => (
                root_csr.clone(),
                certificate_improved_csr_dependency_pairs(root_csr),
                CsrDpProblemContext::improved(root_csr),
                None,
            ),
            CsrDependencyPairKind::MutermUnhiding | CsrDependencyPairKind::MutermExpanded => {
                let force_expanded = self.kind == CsrDependencyPairKind::MutermExpanded;
                let problem = if force_expanded {
                    if !csr_is_orthogonal(root_csr) {
                        return ProcessorResult::Inapplicable;
                    }
                    let pairs = muterm_expanded_dependency_pairs(root_csr);
                    let Some(problem) = csr_dp_problem_state(
                        root_csr,
                        pairs,
                        CsrDpProblemContext::muterm_expanded(root_csr),
                        self.options.clone(),
                        None,
                        Vec::new(),
                    ) else {
                        return ProcessorResult::Inapplicable;
                    };
                    problem
                } else {
                    let Some(problem) = materialize_muterm_unhiding_dependency_pairs(
                        root_csr,
                        self.options.clone(),
                    ) else {
                        return ProcessorResult::Inapplicable;
                    };
                    problem
                };
                let reconstruction_problem = problem.clone();
                let auxiliary_rules = muterm_innermost_unhiding_rules(root_csr);
                let construction = if force_expanded
                    || !rta_csr_dependency_pairs(root_csr)
                        .iter()
                        .any(|pair| matches!(pair.rhs(), crate::core::Term::Var(_)))
                {
                    ContextSensitiveDependencyPairConstruction::MutermExpandedInnermost
                } else {
                    ContextSensitiveDependencyPairConstruction::MutermUnhiding
                };
                return ProcessorResult::Applied(ProcessorApplication::new(
                    vec![ProblemState::DependencyPairs(problem)],
                    move |children| {
                        let [ProblemCertificate::DependencyPairTree(tree)] =
                            <[ProblemCertificate; 1]>::try_from(children).ok()?
                        else {
                            return None;
                        };
                        let proof =
                            reconstruct_dependency_pair_proof(&reconstruction_problem, tree);
                        let step = ProofStep::ContextSensitiveDependencyPairProof {
                            construction,
                            auxiliary_rules: auxiliary_rules.clone(),
                            proof: Box::new(proof),
                        };
                        Some(ProblemCertificate::Trs(Proof::terminating(vec![step])))
                    },
                ));
            }
            CsrDependencyPairKind::Innermost => {
                let Some((problem, auxiliary)) =
                    materialize_innermost_csr_dependency_pairs(root_csr, self.options.clone())
                else {
                    return ProcessorResult::Inapplicable;
                };
                let reconstruction_problem = problem.clone();
                let validation_csr = root_csr.clone();
                return ProcessorResult::Applied(ProcessorApplication::new(
                    vec![ProblemState::DependencyPairs(problem)],
                    move |children| {
                        let [ProblemCertificate::DependencyPairTree(tree)] =
                            <[ProblemCertificate; 1]>::try_from(children).ok()?
                        else {
                            return None;
                        };
                        let proof =
                            reconstruct_dependency_pair_proof(&reconstruction_problem, tree);
                        if !csr_dp_native_certification_issues(&validation_csr, &proof, false)
                            .is_empty()
                        {
                            return None;
                        }
                        Some(ProblemCertificate::Trs(Proof::terminating(vec![
                            ProofStep::ContextSensitiveInnermostDependencyPairProof {
                                auxiliary_rules: auxiliary.clone(),
                                proof: Box::new(proof),
                            },
                        ])))
                    },
                ));
            }
            CsrDependencyPairKind::Rta08 => (
                root_csr.clone(),
                rta_csr_dependency_pairs(root_csr),
                CsrDpProblemContext::rta08(root_csr),
                None,
            ),
            CsrDependencyPairKind::Conservative => {
                let (problem, pairs) = conservative_csr_dependency_problem(root_csr);
                let context = CsrDpProblemContext::conservative(&problem);
                let auxiliary_rules = problem.rules().to_vec();
                (problem, pairs, context, Some(auxiliary_rules))
            }
        };
        let Some(problem) = csr_dp_problem_state(
            &problem_csr,
            pairs,
            context,
            self.options.clone(),
            None,
            Vec::new(),
        ) else {
            return ProcessorResult::Inapplicable;
        };
        let reconstruction_problem = problem.clone();
        let validation_csr = root_csr.clone();
        let kind = self.kind;
        ProcessorResult::Applied(ProcessorApplication::new(
            vec![ProblemState::DependencyPairs(problem)],
            move |children| {
                let [ProblemCertificate::DependencyPairTree(tree)] =
                    <[ProblemCertificate; 1]>::try_from(children).ok()?
                else {
                    return None;
                };
                let proof = reconstruct_dependency_pair_proof(&reconstruction_problem, tree);
                let certification_issues =
                    csr_dp_native_certification_issues(&validation_csr, &proof, true);
                let valid = match kind {
                    CsrDependencyPairKind::NativeContextSensitive
                    | CsrDependencyPairKind::NativeOrdinary => {
                        csr_dp_minimal_processors_are_mu_valid(&validation_csr, &proof, false)
                            && csr_dp_native_certification_issues(&validation_csr, &proof, true)
                                .is_empty()
                    }
                    CsrDependencyPairKind::Safe => {
                        safe_csr_dependency_pair_proof_closes_all_cyclic_components(
                            &validation_csr,
                            &proof,
                        ) && csr_dp_native_certification_issues(&validation_csr, &proof, false)
                            .is_empty()
                    }
                    CsrDependencyPairKind::Improved => certification_issues.is_empty(),
                    CsrDependencyPairKind::MutermUnhiding
                    | CsrDependencyPairKind::MutermExpanded => false,
                    CsrDependencyPairKind::Rta08 => {
                        csr_rta08_proof_has_component_first_reduction_pairs(&validation_csr, &proof)
                    }
                    CsrDependencyPairKind::Conservative => {
                        csr_dp_proof_is_conservatively_certifiable(&proof)
                    }
                    CsrDependencyPairKind::Innermost => {
                        csr_dp_native_certification_issues(&validation_csr, &proof, false)
                            .is_empty()
                    }
                };
                if !valid {
                    if std::env::var_os("FERRUM_WORKLIST_TRACE").is_some() {
                        eprintln!(
                            "CSR DP reconstruction rejected kind={kind:?} issues={certification_issues:?}"
                        );
                    }
                    return None;
                }
                let step = if kind == CsrDependencyPairKind::Innermost {
                    ProofStep::ContextSensitiveInnermostDependencyPairProof {
                        auxiliary_rules: auxiliary_rules.clone().unwrap_or_default(),
                        proof: Box::new(proof),
                    }
                } else {
                    let construction = match kind {
                        CsrDependencyPairKind::NativeContextSensitive
                        | CsrDependencyPairKind::NativeOrdinary => {
                            ContextSensitiveDependencyPairConstruction::Native
                        }
                        CsrDependencyPairKind::Safe => {
                            ContextSensitiveDependencyPairConstruction::Safe
                        }
                        CsrDependencyPairKind::Improved => {
                            ContextSensitiveDependencyPairConstruction::Improved
                        }
                        CsrDependencyPairKind::MutermUnhiding
                        | CsrDependencyPairKind::MutermExpanded => unreachable!(),
                        CsrDependencyPairKind::Rta08 => {
                            ContextSensitiveDependencyPairConstruction::Rta08
                        }
                        CsrDependencyPairKind::Conservative => {
                            ContextSensitiveDependencyPairConstruction::Conservative
                        }
                        CsrDependencyPairKind::Innermost => unreachable!(),
                    };
                    ProofStep::ContextSensitiveDependencyPairProof {
                        construction,
                        auxiliary_rules: auxiliary_rules.clone().unwrap_or_default(),
                        proof: Box::new(proof),
                    }
                };
                Some(ProblemCertificate::Trs(Proof::terminating(vec![step])))
            },
        ))
    }
}

#[cfg(test)]
mod tests {
    use crate::proving::dependency_pairs::{CsrDpConstruction, DpProblemContext};

    use super::materialize_muterm_unhiding_dependency_pairs;

    #[test]
    fn ex1_gm03_materializes_a_typed_muterm_state() {
        let csr = crate::parsing::parse_ari_cstrs(
            Some("CSR_04/Ex1_GM03.ari".to_string()),
            include_str!("../../../../tests/fixtures/csr_ex1_gm03.ari"),
        )
        .expect("parse Ex1_GM03 fixture");
        let state = materialize_muterm_unhiding_dependency_pairs(
            &csr,
            crate::proving::dependency_pairs::DpOptions::default(),
        )
        .expect("materialize MU-TERM state");

        assert!(matches!(
            state.stats.problem,
            DpProblemContext::ContextSensitive(ref context)
                if context.construction == CsrDpConstruction::MutermUnhiding
        ));
    }

    #[test]
    fn muterm_unhiding_rejects_overlapping_csr_even_with_collapsing_pairs() {
        let csr = crate::parsing::parse_ari_cstrs(
            Some("overlapping-collapsing-csr".to_string()),
            r#"
(format CSTRS)
(fun sel 2 :replacement-map (1 2))
(fun s 1 :replacement-map (1))
(fun cons 2 :replacement-map (1))
(fun quote 1 :replacement-map ())
(fun sel1 2 :replacement-map (1 2))
(rule (sel (s X) (cons Y Z)) (sel X Z))
(rule (quote (sel X Z)) (sel1 X Z))
"#,
        )
        .expect("parse overlapping CSR");

        assert!(
            crate::proving::dependency_pairs::rta_csr_dependency_pairs(&csr)
                .iter()
                .any(|pair| matches!(pair.rhs(), crate::core::Term::Var(_)))
        );
        assert!(
            materialize_muterm_unhiding_dependency_pairs(
                &csr,
                crate::proving::dependency_pairs::DpOptions::default(),
            )
            .is_none()
        );
    }

    #[test]
    fn muterm_unhiding_rejects_nested_unsafe_frozen_rhs() {
        let csr = crate::parsing::parse_ari_cstrs(
            Some("unsafe-nested-frozen-csr".to_string()),
            r#"
(format CSTRS)
(fun f 1 :replacement-map ())
(fun g 1 :replacement-map ())
(fun h 1 :replacement-map (1))
(rule (f X) (g (h X)))
"#,
        )
        .expect("parse unsafe CSR");

        assert!(crate::proving::processors::rewrite_analysis::csr_is_orthogonal(&csr));
        assert!(
            materialize_muterm_unhiding_dependency_pairs(
                &csr,
                crate::proving::dependency_pairs::DpOptions::default(),
            )
            .is_none()
        );
    }
}
