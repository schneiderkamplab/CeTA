use std::collections::{BTreeMap, BTreeSet};
use std::time::Instant;

use crate::core::{CsrTrs, ReplacementMap, RewriteRule, Symbol, Trs};
use crate::llm::LinearPolynomialInterpretations;
use crate::proving::engine::{ProveOptions, ProveStrategyProcessor};
use crate::proving::processors::top_level::polynomial::{
    csr_smt_polynomial_script, exact_linear_polynomial_interpretations, top_level_parse_smt_model,
};
use crate::proving::processors::top_level::smt::{command_exists, run_script};
use crate::proving::runtime::{CancellationScope, write_progress_event};
use crate::proving::{
    Proof, ProofStep, linear_polynomial_strictly_orients_rule,
    linear_polynomial_weakly_orients_rule,
};
use crate::standardize::standardize_trs_with_bijection;

use super::super::{
    ProblemCertificate, ProblemState, ProcessorApplication, ProcessorResult, WorklistProcessor,
};

pub(crate) fn linear_polynomial_interpretations_for_proof(
    interpretations: &LinearPolynomialInterpretations,
) -> Vec<(String, i64, Vec<i64>)> {
    interpretations
        .iter()
        .map(|(symbol, interpretation)| {
            (
                symbol.clone(),
                interpretation.constant,
                interpretation.coefficients.clone(),
            )
        })
        .collect()
}

pub(crate) fn csr_linear_polynomial_is_mu_monotone(
    csr: &CsrTrs,
    interpretations: &LinearPolynomialInterpretations,
) -> bool {
    interpretations.values().all(|interpretation| {
        interpretation.constant >= 0 && interpretation.coefficients.iter().all(|value| *value >= 0)
    }) && csr.trs().arities().into_iter().all(|(symbol, arity)| {
        let Some(interpretation) = interpretations.get(symbol.as_str()) else {
            return true;
        };
        (0..arity).all(|index| {
            let coefficient = interpretation.coefficients.get(index).copied().unwrap_or(1);
            if csr.replacement_map().is_allowed(&symbol, index) {
                coefficient >= 1
            } else {
                coefficient >= 0
            }
        })
    })
}

pub(crate) fn synthesize_csr_linear_polynomial_removal(
    csr: &CsrTrs,
    max_constant: i64,
    max_coefficient: i64,
    max_symbols: usize,
    max_arity: usize,
    candidate_index: usize,
    deadline: Option<Instant>,
    cancellation: &CancellationScope,
) -> Option<CsrPolynomialRemoval> {
    synthesize_csr_linear_polynomial_removal_with_target(
        csr,
        max_constant,
        max_coefficient,
        max_symbols,
        max_arity,
        candidate_index,
        None,
        None,
        deadline,
        cancellation,
    )
}

pub(crate) fn synthesize_csr_linear_polynomial_target_removal(
    csr: &CsrTrs,
    max_constant: i64,
    max_coefficient: i64,
    max_symbols: usize,
    max_arity: usize,
    target_strict_rule_indices: &[usize],
    deadline: Option<Instant>,
    cancellation: &CancellationScope,
) -> Option<CsrPolynomialRemoval> {
    synthesize_csr_linear_polynomial_removal_with_target(
        csr,
        max_constant,
        max_coefficient,
        max_symbols,
        max_arity,
        0,
        Some(target_strict_rule_indices),
        None,
        deadline,
        cancellation,
    )
}

pub(crate) fn synthesize_csr_linear_polynomial_minimum_removal(
    csr: &CsrTrs,
    max_constant: i64,
    max_coefficient: i64,
    max_symbols: usize,
    max_arity: usize,
    min_delete: usize,
    deadline: Option<Instant>,
    cancellation: &CancellationScope,
) -> Option<CsrPolynomialRemoval> {
    synthesize_csr_linear_polynomial_removal_with_target(
        csr,
        max_constant,
        max_coefficient,
        max_symbols,
        max_arity,
        0,
        None,
        Some(min_delete),
        deadline,
        cancellation,
    )
}

fn synthesize_csr_linear_polynomial_removal_with_target(
    csr: &CsrTrs,
    max_constant: i64,
    max_coefficient: i64,
    max_symbols: usize,
    max_arity: usize,
    candidate_index: usize,
    target_strict_rule_indices: Option<&[usize]>,
    minimum_delete: Option<usize>,
    deadline: Option<Instant>,
    cancellation: &CancellationScope,
) -> Option<CsrPolynomialRemoval> {
    let standardized = standardize_trs_with_bijection(csr.trs()).ok()?;
    let replacement_map = ReplacementMap::new(
        csr.replacement_map()
            .entries()
            .iter()
            .filter_map(|(symbol, positions)| {
                standardized
                    .function_bijection
                    .get(symbol)
                    .cloned()
                    .map(|canonical| (canonical, positions.clone()))
            })
            .collect(),
    );
    let standardized_csr = CsrTrs::new(standardized.trs.clone(), replacement_map).ok()?;
    let canonical_target_indices = target_strict_rule_indices.map(|target| {
        let target = target.iter().copied().collect::<BTreeSet<_>>();
        standardized
            .rule_metadata
            .iter()
            .filter(|metadata| target.contains(&metadata.original_pair_index))
            .map(|metadata| metadata.canonical_pair_index)
            .collect::<BTreeSet<_>>()
            .into_iter()
            .collect::<Vec<_>>()
    });
    if target_strict_rule_indices.is_some_and(|target| {
        canonical_target_indices
            .as_ref()
            .is_none_or(|canonical| canonical.len() != target.len())
    }) {
        return None;
    }
    let canonical_removal = synthesize_csr_linear_polynomial_removal_raw(
        &standardized_csr,
        max_constant,
        max_coefficient,
        max_symbols,
        max_arity,
        candidate_index,
        canonical_target_indices.as_deref(),
        minimum_delete,
        deadline,
        cancellation,
    )?;
    let removed_canonical_indices = standardized
        .trs
        .rules()
        .iter()
        .enumerate()
        .filter_map(|(index, rule)| canonical_removal.removed.contains(rule).then_some(index))
        .collect::<BTreeSet<_>>();
    let removed_original_indices = standardized
        .rule_metadata
        .iter()
        .filter(|metadata| removed_canonical_indices.contains(&metadata.canonical_pair_index))
        .map(|metadata| metadata.original_pair_index)
        .collect::<BTreeSet<_>>();
    let removed = csr
        .rules()
        .iter()
        .enumerate()
        .filter(|(index, _)| removed_original_indices.contains(index))
        .map(|(_, rule)| rule.clone())
        .collect::<Vec<_>>();
    if removed.is_empty() {
        return None;
    }
    let remaining = csr_without_rules(csr, &removed)?;
    let interpretations = canonical_removal
        .interpretations
        .into_iter()
        .map(|(symbol, interpretation)| {
            let canonical = Symbol::new(symbol);
            let original = standardized
                .inverse_function_bijection
                .get(&canonical)
                .unwrap_or(&canonical);
            (original.as_str().to_string(), interpretation)
        })
        .collect();
    Some(CsrPolynomialRemoval {
        interpretations,
        removed,
        remaining,
    })
}

fn synthesize_csr_linear_polynomial_removal_raw(
    csr: &CsrTrs,
    max_constant: i64,
    max_coefficient: i64,
    max_symbols: usize,
    max_arity: usize,
    candidate_index: usize,
    target_strict_rule_indices: Option<&[usize]>,
    minimum_delete: Option<usize>,
    deadline: Option<Instant>,
    cancellation: &CancellationScope,
) -> Option<CsrPolynomialRemoval> {
    if deadline.is_some_and(|limit| Instant::now() >= limit) || cancellation.is_cancelled() {
        return None;
    }
    if max_constant < 0 || max_coefficient < 0 {
        return None;
    }
    let arities = csr
        .trs()
        .arities()
        .into_iter()
        .map(|(symbol, arity)| (symbol.as_str().to_string(), arity))
        .collect::<BTreeMap<_, _>>();
    if arities.is_empty()
        || arities.len() > max_symbols
        || arities.values().any(|arity| *arity > max_arity)
    {
        return None;
    }
    let solver = command_exists("z3").then_some("z3")?;
    let script = csr_smt_polynomial_script(
        csr,
        &arities,
        max_constant,
        max_coefficient,
        candidate_index.checked_sub(1),
        target_strict_rule_indices,
        minimum_delete,
        deadline,
    )?;
    let stdout = run_script(&script, solver, deadline)?;
    if cancellation.is_cancelled() || !stdout.contains("sat") || stdout.contains("unsat") {
        return None;
    }
    let interpretations = top_level_parse_smt_model(&stdout, &arities)?;
    let removal = csr_linear_polynomial_removal(csr, &interpretations);
    write_progress_event(
        "csr-rule-removal",
        if removal.is_some() {
            "selected"
        } else {
            "rejected"
        },
        "smt-polynomial",
        0,
        &format!(
            "smt_calls=1 rules={} reason={}",
            csr.rules().len(),
            if removal.is_some() {
                "checked-max-removal"
            } else {
                "model-failed-check"
            }
        ),
    );
    removal
}

pub(crate) fn csr_linear_polynomial_removal(
    csr: &CsrTrs,
    interpretations: &LinearPolynomialInterpretations,
) -> Option<CsrPolynomialRemoval> {
    if !csr_linear_polynomial_is_mu_monotone(csr, interpretations) {
        return None;
    }
    let mut removed = Vec::new();
    for rule in csr.rules() {
        if !linear_polynomial_weakly_orients_rule(rule, interpretations) {
            return None;
        }
        if linear_polynomial_strictly_orients_rule(rule, interpretations) {
            removed.push(rule.clone());
        }
    }
    if removed.is_empty() {
        return None;
    }
    let remaining = csr_without_rules(csr, &removed)?;
    Some(CsrPolynomialRemoval {
        interpretations: interpretations.clone(),
        removed,
        remaining,
    })
}

fn csr_without_rules(csr: &CsrTrs, removed: &[RewriteRule]) -> Option<CsrTrs> {
    let mut remaining: Vec<_> = Vec::new();
    let mut removed = removed.to_vec();
    'rule_loop: for rule in csr.rules() {
        for i in 0..removed.len() {
            if rule == &removed[i] || crate::proving::rewrite_rules_are_variants(rule, &removed[i])
            {
                removed.remove(i);
                continue 'rule_loop;
            }
        }
        remaining.push(rule.clone());
    }
    let trs = Trs::new_with_strategy(
        csr.trs().name().map(str::to_string),
        csr.trs().variables().clone(),
        remaining,
        csr.trs().strategy(),
    );
    let arities = trs.arities();
    let replacement_map = ReplacementMap::new(
        csr.replacement_map()
            .entries()
            .iter()
            .filter_map(|(symbol, positions)| {
                arities
                    .contains_key(symbol)
                    .then(|| (symbol.clone(), positions.clone()))
            })
            .collect(),
    );
    CsrTrs::new(trs, replacement_map).ok()
}

pub(crate) struct CsrPolynomialRemoval {
    pub(crate) interpretations: LinearPolynomialInterpretations,
    pub(crate) removed: Vec<RewriteRule>,
    pub(crate) remaining: CsrTrs,
}

pub struct CsrPolynomialRuleRemovalProcessor {
    pub options: ProveOptions,
    pub exact_interpretation: Option<Vec<(String, i64, Vec<i64>)>>,
    pub target_strict_rule_indices: Option<Vec<usize>>,
    pub minimum_delete: Option<(usize, usize)>,
    pub candidate_index: usize,
    pub deadline: Option<Instant>,
}

impl WorklistProcessor for CsrPolynomialRuleRemovalProcessor {
    fn name(&self) -> &'static str {
        "csr-polynomial-rule-removal"
    }

    fn apply(&self, state: &ProblemState) -> ProcessorResult {
        let ProblemState::Csr(state) = state else {
            return ProcessorResult::Inapplicable;
        };
        let csr = &state.csr;
        let cancellation = CancellationScope::current(self.deadline);
        let removal = if let Some(witness) = self.exact_interpretation.as_deref() {
            let Some(interpretations) = exact_linear_polynomial_interpretations(witness) else {
                return ProcessorResult::Failed {
                    reason: "exact CSR polynomial witness contains duplicate symbols".to_string(),
                };
            };
            csr_linear_polynomial_removal(csr, &interpretations)
        } else if let Some(target) = self.target_strict_rule_indices.as_deref() {
            synthesize_csr_linear_polynomial_target_removal(
                csr,
                self.options.max_polynomial_constant,
                self.options.max_polynomial_coefficient,
                self.options.max_polynomial_symbols,
                self.options.max_polynomial_arity,
                target,
                self.deadline,
                &cancellation,
            )
        } else if let Some((min_delete, residual_budget)) = self.minimum_delete {
            if residual_budget != 1 {
                return ProcessorResult::Failed {
                    reason: "CSR polynomial residual budget must be one".to_string(),
                };
            }
            synthesize_csr_linear_polynomial_minimum_removal(
                csr,
                self.options.max_polynomial_constant,
                self.options.max_polynomial_coefficient,
                self.options.max_polynomial_symbols,
                self.options.max_polynomial_arity,
                min_delete,
                self.deadline,
                &cancellation,
            )
        } else {
            synthesize_csr_linear_polynomial_removal(
                csr,
                self.options.max_polynomial_constant,
                self.options.max_polynomial_coefficient,
                self.options.max_polynomial_symbols,
                self.options.max_polynomial_arity,
                self.candidate_index,
                self.deadline,
                &cancellation,
            )
        };
        let Some(removal) = removal else {
            return ProcessorResult::Inapplicable;
        };
        let interpretations = linear_polynomial_interpretations_for_proof(&removal.interpretations);
        let selected_atom = if self.exact_interpretation.is_some() {
            ProveStrategyProcessor::ExactLinearPolynomial {
                interpretation: interpretations.clone(),
            }
        } else if let Some(strict_rule_indices) = self.target_strict_rule_indices.as_ref() {
            ProveStrategyProcessor::TargetLinearPolynomial {
                max_constant: self.options.max_polynomial_constant,
                max_coefficient: self.options.max_polynomial_coefficient,
                max_symbols: Some(self.options.max_polynomial_symbols),
                max_arity: Some(self.options.max_polynomial_arity),
                strict_rule_indices: strict_rule_indices.clone(),
            }
        } else if let Some((min_delete, residual_budget)) = self.minimum_delete {
            ProveStrategyProcessor::MinimumDeletionLinearPolynomial {
                max_constant: self.options.max_polynomial_constant,
                max_coefficient: self.options.max_polynomial_coefficient,
                max_symbols: Some(self.options.max_polynomial_symbols),
                max_arity: Some(self.options.max_polynomial_arity),
                min_delete,
                residual_budget,
            }
        } else {
            ProveStrategyProcessor::SelectedLinearPolynomial {
                max_constant: self.options.max_polynomial_constant,
                max_coefficient: self.options.max_polynomial_coefficient,
                max_symbols: Some(self.options.max_polynomial_symbols),
                max_arity: Some(self.options.max_polynomial_arity),
                candidate_index: self.candidate_index,
            }
        }
        .to_strategy_atom();
        let removed = removal.removed;
        ProcessorResult::Applied(
            ProcessorApplication::new(
                vec![ProblemState::Csr(
                    super::super::CsrProblemState::rule_removal_child(state, removal.remaining),
                )],
                move |children| {
                    let [ProblemCertificate::Trs(proof)] =
                        <[ProblemCertificate; 1]>::try_from(children).ok()?
                    else {
                        return None;
                    };
                    if proof.status() != &crate::proving::Status::Terminating {
                        return None;
                    }
                    Some(ProblemCertificate::Trs(Proof::terminating(vec![
                        ProofStep::ContextSensitivePolynomialRuleRemoval {
                            interpretations: interpretations.clone(),
                            removed: removed.clone(),
                            proof: Box::new(proof),
                        },
                    ])))
                },
            )
            .with_selected_atom(selected_atom),
        )
    }
}
