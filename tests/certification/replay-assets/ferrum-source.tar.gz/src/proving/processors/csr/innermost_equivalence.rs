use crate::core::{CsrTrs, RewriteStrategy, Trs};
use crate::proving::dependency_pairs::{
    CsrDpProblemContext, DpOptions, csr_dp_problem_state, csr_innermost_dp_certification_issues,
    csr_rta08_proof_is_certifiable, reconstruct_dependency_pair_proof, rta_csr_dependency_pairs,
};
use crate::proving::processors::rewrite_analysis::csr_is_orthogonal;
use crate::proving::{Proof, ProofStep};

use super::super::{
    ProblemCertificate, ProblemState, ProcessorApplication, ProcessorResult, WorklistProcessor,
};
use super::dependency_pairs::materialize_innermost_csr_dependency_pairs;

/// For an orthogonal underlying TRS, replace CSR termination by its innermost
/// CSR obligation and expose that obligation to the shared worklist.
pub struct CsrInnermostEquivalenceProcessor {
    pub options: DpOptions,
    /// Use the source-restricted RTA08 problem instead of the native
    /// innermost-CSR problem with explicit unhiding rules.
    pub rta08: bool,
}

impl WorklistProcessor for CsrInnermostEquivalenceProcessor {
    fn name(&self) -> &'static str {
        "csr-innermost-equivalence"
    }

    fn apply(&self, state: &ProblemState) -> ProcessorResult {
        let ProblemState::Csr(state) = state else {
            return ProcessorResult::Inapplicable;
        };
        if state.boundary != super::super::CsrProofBoundary::Root {
            return ProcessorResult::Inapplicable;
        }
        let csr = &state.csr;
        if csr.trs().strategy() == RewriteStrategy::Innermost {
            return ProcessorResult::Inapplicable;
        }
        if !csr_is_orthogonal(csr) {
            if std::env::var_os("FERRUM_WORKLIST_TRACE").is_some() {
                eprintln!("CSR innermost equivalence rejected: source TRS is not orthogonal");
            }
            return ProcessorResult::Inapplicable;
        }
        let trs = Trs::new_with_strategy(
            csr.trs().name().map(str::to_string),
            csr.trs().variables().clone(),
            csr.rules().to_vec(),
            RewriteStrategy::Innermost,
        );
        let Ok(residual) = CsrTrs::new(trs, csr.replacement_map().clone()) else {
            return ProcessorResult::Failed {
                reason: "failed to preserve the CSR replacement map".to_string(),
            };
        };
        let (dp_state, _auxiliary_rules) = if self.rta08 {
            let Some(dp_state) = csr_dp_problem_state(
                &residual,
                rta_csr_dependency_pairs(&residual),
                CsrDpProblemContext::innermost_rta08(&residual),
                self.options.clone(),
                None,
                Vec::new(),
            ) else {
                return ProcessorResult::Inapplicable;
            };
            (dp_state, Vec::new())
        } else {
            let Some((dp_state, auxiliary_rules)) =
                materialize_innermost_csr_dependency_pairs(&residual, self.options.clone())
            else {
                return ProcessorResult::Inapplicable;
            };
            (dp_state, auxiliary_rules)
        };
        let reconstruction_state = dp_state.clone();
        let validation_csr = residual;
        let use_rta08 = self.rta08;
        ProcessorResult::Applied(ProcessorApplication::new(
            vec![ProblemState::DependencyPairs(dp_state)],
            move |children| {
                let [ProblemCertificate::DependencyPairTree(tree)] =
                    <[ProblemCertificate; 1]>::try_from(children).ok()?
                else {
                    return None;
                };
                let dp_proof = reconstruct_dependency_pair_proof(&reconstruction_state, tree);
                let certification_issues = (!use_rta08)
                    .then(|| csr_innermost_dp_certification_issues(&validation_csr, &dp_proof));
                let certifiable = if use_rta08 {
                    csr_rta08_proof_is_certifiable(&validation_csr, &dp_proof)
                } else {
                    certification_issues
                        .as_ref()
                        .is_some_and(|issues| issues.is_empty())
                };
                if !certifiable {
                    if std::env::var_os("FERRUM_WORKLIST_TRACE").is_some() {
                        if let Some(issues) = certification_issues.as_ref() {
                            eprintln!(
                                "innermost CSR-DP reconstruction rejected: {}",
                                issues.join("; ")
                            );
                        } else {
                            eprintln!(
                                "innermost RTA08 reconstruction rejected: invalid recursive reduction-pair proof"
                            );
                        }
                    }
                    return None;
                }
                let direct = Proof::terminating(vec![
                    ProofStep::ContextSensitiveInnermostDependencyPairProof {
                        // The certified native/RTA08 continuations are checked
                        // against the original CSR rules.  Keeping the search-
                        // only projection rules here selects CeTA's older
                        // auxiliary-rule checker and loses the certified
                        // active-SCT/RTA08 semantics.
                        auxiliary_rules: Vec::new(),
                        proof: Box::new(dp_proof),
                    },
                ]);
                Some(ProblemCertificate::Trs(Proof::terminating(vec![
                    ProofStep::ContextSensitiveInnermostEquivalence {
                        proof: Box::new(direct),
                    },
                ])))
            },
        ))
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::parsing::parse_ari_cstrs;
    use crate::proving::dependency_pairs::{
        CsrDpConstruction, DpProblemContext, DpProofTree, DpReductionPairProof,
        DpStrategyProcessor, arities_for_constraints, weakly_decreases_by_polynomial,
    };
    use crate::proving::processors::dp::{
        DependencyGraphProcessor, ReductionPairProcessor, SizeChangeProcessor,
    };
    use crate::proving::processors::{CsrProblemState, ProblemCertificate, ProblemState};

    #[test]
    fn ex3_enters_source_restricted_innermost_rta08_without_variable_condition() {
        let csr = parse_ari_cstrs(
            Some("CSR_04/Ex3_2_Luc97.ari".to_string()),
            include_str!("../../../../tests/fixtures/csr_ex3_2_luc97.ari"),
        )
        .unwrap();
        let result = (CsrInnermostEquivalenceProcessor {
            options: DpOptions::default(),
            rta08: true,
        })
        .apply(&ProblemState::Csr(CsrProblemState::root(csr.clone())));
        let ProcessorResult::Applied(application) = result else {
            panic!("expected source-restricted RTA08 residual");
        };
        let [ProblemState::DependencyPairs(dp)] = application.residuals.as_slice() else {
            panic!("expected one dependency-pair residual");
        };
        assert!(!dp.stats.minimal);
        assert!(matches!(
            &dp.stats.problem,
            DpProblemContext::ContextSensitive(context)
                if context.construction == CsrDpConstruction::InnermostRta08
        ));
        assert_eq!(dp.pairs, rta_csr_dependency_pairs(&csr));
    }

    #[test]
    fn ex3_enters_independently_certifiable_innermost_unhiding_problem() {
        let csr = parse_ari_cstrs(
            Some("CSR_04/Ex3_2_Luc97.ari".to_string()),
            include_str!("../../../../tests/fixtures/csr_ex3_2_luc97.ari"),
        )
        .unwrap();
        let result = (CsrInnermostEquivalenceProcessor {
            options: DpOptions::default(),
            rta08: false,
        })
        .apply(&ProblemState::Csr(CsrProblemState::root(csr.clone())));
        let ProcessorResult::Applied(application) = result else {
            panic!("expected innermost-CSR unhiding residual");
        };
        let [ProblemState::DependencyPairs(dp)] = application.residuals.as_slice() else {
            panic!("expected one dependency-pair residual");
        };
        assert!(!dp.stats.minimal);
        assert!(matches!(
            &dp.stats.problem,
            DpProblemContext::ContextSensitive(context)
                if context.construction == CsrDpConstruction::Innermost
        ));
        assert_eq!(dp.pairs.len(), 10);
        assert!(dp.trs.rules().len() > csr.rules().len());
    }

    #[test]
    fn native_active_sct_reconstructs_without_search_only_auxiliary_rules() {
        let csr = parse_ari_cstrs(
            None,
            "(format CSTRS)\n\
             (fun f 1 :replacement-map (1))\n\
             (fun s 1 :replacement-map (1))\n\
             (rule (f (s X)) (f X))\n",
        )
        .unwrap();
        let ProcessorResult::Applied(root_application) = (CsrInnermostEquivalenceProcessor {
            options: DpOptions::default(),
            rta08: false,
        })
        .apply(&ProblemState::Csr(CsrProblemState::root(csr.clone()))) else {
            panic!("expected native innermost-CSR residual");
        };
        let ProcessorResult::Applied(sct_application) =
            (SizeChangeProcessor { deadline: None }).apply(&root_application.residuals[0])
        else {
            panic!("expected active SCT closure");
        };
        let sct_certificate = sct_application
            .reconstruct(Vec::new())
            .expect("reconstruct active SCT closure");
        let ProblemCertificate::Trs(root_proof) = root_application
            .reconstruct(vec![sct_certificate])
            .expect("reconstruct native innermost-CSR proof")
        else {
            panic!("expected terminating CSR proof");
        };
        let [
            ProofStep::ContextSensitiveInnermostEquivalence {
                proof: direct_proof,
            },
        ] = root_proof.steps()
        else {
            panic!("expected orthogonal innermost-CSR switch");
        };
        let [
            ProofStep::ContextSensitiveInnermostDependencyPairProof {
                auxiliary_rules, ..
            },
        ] = direct_proof.steps()
        else {
            panic!("expected native innermost-CSR dependency pairs");
        };
        assert!(
            auxiliary_rules.is_empty(),
            "search-only projection rules must not cross the CPF boundary"
        );
        let cpf = crate::cert::write_cpf_csr(&csr, &root_proof, crate::cert::CpfMode::Cpf40)
            .expect("write native active-SCT CPF");
        if let Some(path) = std::env::var_os("FERRUM_TEST_CPF_OUT") {
            std::fs::write(path, cpf).expect("write requested active-SCT CPF artifact");
        }
    }

    #[test]
    fn terminal_innermost_rta08_reconstructs_exact_cpf_shape() {
        let csr = parse_ari_cstrs(
            None,
            include_str!("../../../../tests/fixtures/csr_rta08_collapsing.ari"),
        )
        .unwrap();
        let ProcessorResult::Applied(root_application) = (CsrInnermostEquivalenceProcessor {
            options: DpOptions::default(),
            rta08: true,
        })
        .apply(&ProblemState::Csr(CsrProblemState::root(csr.clone()))) else {
            panic!("expected source-restricted RTA08 residual");
        };
        let dp_state = root_application.residuals[0].clone();
        let ProcessorResult::Applied(redpair_application) = (ReductionPairProcessor {
            processor: DpStrategyProcessor::SatPolynomial {
                max_constant: 2,
                max_coefficient: 2,
                max_symbols: None,
                max_arity: None,
            },
            deadline: None,
        })
        .apply(&dp_state) else {
            panic!("expected terminal RTA08 reduction pair");
        };
        let [ProblemState::DependencyPairs(empty)] = redpair_application.residuals.as_slice()
        else {
            panic!("expected one empty dependency-pair residual");
        };
        assert!(empty.pairs.is_empty());
        let child = redpair_application
            .reconstruct(vec![ProblemCertificate::DependencyPairTree(
                DpProofTree::Empty,
            )])
            .expect("reconstruct terminal reduction pair");
        let ProblemCertificate::Trs(proof) = root_application
            .reconstruct(vec![child])
            .expect("reconstruct innermost CSR proof")
        else {
            panic!("expected terminating CSR proof");
        };
        let cpf = crate::cert::write_cpf_csr(&csr, &proof, crate::cert::CpfMode::Cpf40)
            .expect("write terminal innermost RTA08 CPF");
        if let Some(path) = std::env::var_os("FERRUM_TEST_CPF_OUT") {
            std::fs::write(path, &cpf).expect("write requested CPF test artifact");
        }
        assert!(cpf.contains("<csrInnermostDependencyPairs>"));
        assert!(cpf.contains("<redPairUrProc>"));
        assert!(!cpf.contains("<monoRedPairUrProc>"));
    }

    #[test]
    fn innermost_rta08_graph_separates_one_way_collapsing_component() {
        let csr = parse_ari_cstrs(
            None,
            "(format CSTRS)\n\
             (fun f 1 :replacement-map (1))\n\
             (fun box 1 :replacement-map ())\n\
             (fun g 1 :replacement-map (1))\n\
             (fun s 1 :replacement-map (1))\n\
             (rule (f (box X)) X)\n\
             (rule (g (s X)) (g X))\n",
        )
        .unwrap();
        let ProcessorResult::Applied(root_application) = (CsrInnermostEquivalenceProcessor {
            options: DpOptions::default(),
            rta08: true,
        })
        .apply(&ProblemState::Csr(CsrProblemState::root(csr))) else {
            panic!("expected source-restricted RTA08 residual");
        };
        let ProcessorResult::Applied(graph_application) =
            (DependencyGraphProcessor { deadline: None }).apply(&root_application.residuals[0])
        else {
            panic!("expected an RTA08 dependency-graph decomposition");
        };
        assert_eq!(graph_application.residuals.len(), 2);
        assert!(graph_application.residuals.iter().all(|residual| matches!(
            residual,
            ProblemState::DependencyPairs(problem) if problem.pairs.len() == 1
        )));
        let mut component_certificates = Vec::new();
        for residual in &graph_application.residuals {
            let ProcessorResult::Applied(redpair_application) = (ReductionPairProcessor {
                processor: DpStrategyProcessor::SatPolynomial {
                    max_constant: 2,
                    max_coefficient: 2,
                    max_symbols: None,
                    max_arity: None,
                },
                deadline: None,
            })
            .apply(residual) else {
                panic!("expected a terminal RTA08 reduction pair for each component");
            };
            assert!(matches!(
                redpair_application.residuals.as_slice(),
                [ProblemState::DependencyPairs(problem)] if problem.pairs.is_empty()
            ));
            let certificate = redpair_application
                .reconstruct(vec![ProblemCertificate::DependencyPairTree(
                    DpProofTree::Empty,
                )])
                .expect("reconstruct component reduction pair");
            let ProblemCertificate::DependencyPairTree(DpProofTree::RedPair { reduction, .. }) =
                &certificate
            else {
                panic!("expected reconstructed reduction pair");
            };
            let DpReductionPairProof::Polynomial { interpretation, .. } = &reduction.reduction_pair
            else {
                panic!("expected polynomial reduction pair");
            };
            let interpretation = interpretation
                .iter()
                .map(|(name, constant, coefficients)| {
                    (
                        name.clone(),
                        crate::llm::LinearPolynomial {
                            constant: *constant,
                            coefficients: coefficients.clone(),
                        },
                    )
                })
                .collect::<crate::llm::LinearPolynomialInterpretations>();
            assert_eq!(
                interpretation.len(),
                match &reduction.reduction_pair {
                    DpReductionPairProof::Polynomial { interpretation, .. } => {
                        interpretation.len()
                    }
                    _ => unreachable!(),
                },
                "polynomial symbol identifiers must remain injective"
            );
            let proof_arities = arities_for_constraints(&reduction.pairs, &reduction.usable_rules);
            assert!(
                proof_arities
                    .keys()
                    .all(|symbol| interpretation.contains_key(symbol)),
                "retained polynomial proofs must explicitly interpret every occurring symbol; missing {:?} from {:?}",
                proof_arities
                    .keys()
                    .filter(|symbol| !interpretation.contains_key(*symbol))
                    .collect::<Vec<_>>(),
                interpretation.keys().collect::<Vec<_>>()
            );
            assert!(reduction.usable_rules.iter().all(|rule| {
                weakly_decreases_by_polynomial(rule.lhs(), rule.rhs(), &interpretation)
            }));
            component_certificates.push(certificate);
        }
        let graph_certificate = graph_application
            .reconstruct(component_certificates)
            .expect("reconstruct RTA08 graph");
        let ProblemCertificate::Trs(proof) = root_application
            .reconstruct(vec![graph_certificate])
            .expect("reconstruct recursive innermost RTA08 proof")
        else {
            panic!("expected terminating CSR proof");
        };
        let cpf = crate::cert::write_cpf_csr(
            &parse_ari_cstrs(
                None,
                "(format CSTRS)\n\
                 (fun f 1 :replacement-map (1))\n\
                 (fun box 1 :replacement-map ())\n\
                 (fun g 1 :replacement-map (1))\n\
                 (fun s 1 :replacement-map (1))\n\
                 (rule (f (box X)) X)\n\
                 (rule (g (s X)) (g X))\n",
            )
            .unwrap(),
            &proof,
            crate::cert::CpfMode::Cpf40,
        )
        .expect("write recursive innermost RTA08 CPF");
        assert!(cpf.contains("<depGraphProc>"));
        if let Some(path) = std::env::var_os("FERRUM_TEST_RECURSIVE_RTA08_CPF_OUT") {
            std::fs::write(path, cpf).expect("write requested recursive CPF test artifact");
        }
    }

    #[test]
    fn innermost_rta08_reduction_pairs_recurse_over_the_exact_residual() {
        let csr = parse_ari_cstrs(
            None,
            include_str!("../../../../tests/fixtures/csr_rta08_recursive.ari"),
        )
        .unwrap();
        let first = "5b5b225f5f4353525f504930222c302c5b312c315d5d2c5b2266222c312c5b315d5d2c5b226623222c302c5b315d5d2c5b2267222c312c5b315d5d2c5b226723222c302c5b315d5d2c5b2268222c302c5b315d5d2c5b2273222c312c5b315d5d5d";
        let second = "5b5b225f5f4353525f504930222c302c5b312c315d5d2c5b2266222c312c5b315d5d2c5b226623222c302c5b315d5d2c5b2267222c312c5b315d5d2c5b226723222c302c5b315d5d2c5b2268222c312c5b315d5d2c5b2273222c302c5b315d5d5d";
        let mut options = crate::proving::ProveOptions::default();
        options.strategy = crate::proving::ProveStrategy::parse(&format!(
            "csr-innermost-rta08(exact-poly(hex={first}); exact-poly(hex={second}))"
        ))
        .unwrap();
        let proof = crate::proving::prove_context_sensitive(&csr, &options);
        assert!(
            matches!(proof.status(), crate::proving::Status::Terminating),
            "unexpected proof: {proof:?}"
        );
        let cpf = crate::cert::write_cpf_csr(&csr, &proof, crate::cert::CpfMode::Cpf40)
            .expect("write recursive RTA08 reduction-pair CPF");
        // The residual remains an innermost-CSR DPP.  Both recursive
        // context-sensitive reduction-pair steps therefore retain the
        // certified U3 CSR processor; the nested ordinary red-pair wrapper
        // is the final exact order witness inside that CSR continuation.
        assert_eq!(cpf.matches("<csrRedPairUrProc>").count(), 2);
        assert_eq!(cpf.matches("<redPairUrProc>").count(), 1);
        if let Some(path) = std::env::var_os("FERRUM_TEST_RECURSIVE_RTA08_CPF_OUT") {
            std::fs::write(path, cpf).expect("write requested recursive CPF test artifact");
        }
    }
}
