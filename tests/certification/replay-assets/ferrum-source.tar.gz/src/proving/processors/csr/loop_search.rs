use std::time::Instant;

use crate::proving::Proof;
use crate::proving::nontermination::bounded_csr_rewriting_loop;

use super::super::{
    ProblemCertificate, ProblemState, ProcessorApplication, ProcessorResult, WorklistProcessor,
};

/// Native context-sensitive loop search. A successful loop has no residual
/// obligations.
pub struct CsrLoopProcessor {
    pub deadline: Option<Instant>,
}

impl WorklistProcessor for CsrLoopProcessor {
    fn name(&self) -> &'static str {
        "csr-loop"
    }

    fn apply(&self, state: &ProblemState) -> ProcessorResult {
        let ProblemState::Csr(state) = state else {
            return ProcessorResult::Inapplicable;
        };
        if state.boundary != super::super::CsrProofBoundary::Root {
            return ProcessorResult::Inapplicable;
        }
        let csr = &state.csr;
        let Some(nontermination) = bounded_csr_rewriting_loop(csr, self.deadline) else {
            return if self.deadline.is_some_and(|limit| Instant::now() >= limit) {
                ProcessorResult::TimedOut
            } else {
                ProcessorResult::Inapplicable
            };
        };
        ProcessorResult::Applied(ProcessorApplication::solved(ProblemCertificate::Trs(
            Proof::nonterminating(nontermination),
        )))
    }
}
