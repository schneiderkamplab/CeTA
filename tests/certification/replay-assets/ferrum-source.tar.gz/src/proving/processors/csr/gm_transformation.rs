use crate::proving::csr_gm_transformation;
use crate::proving::dependency_pairs::{
    DpOptions, DpStrategy, dependency_pairs, reconstruct_dependency_pair_proof,
};
use crate::proving::processors::dp::DpProblemState;
use crate::proving::{Proof, ProofStep};

use super::super::{
    ProblemCertificate, ProblemState, ProcessorApplication, ProcessorResult, WorklistProcessor,
};

/// Giesl--Middeldorp CSR-to-TRS transformation. Its ordinary TRS obligation
/// is returned to the shared worklist instead of being solved recursively.
pub struct CsrGmTransformationProcessor {
    pub options: DpOptions,
    pub strategy: Option<DpStrategy>,
}

impl WorklistProcessor for CsrGmTransformationProcessor {
    fn name(&self) -> &'static str {
        "csr-gm-transformation"
    }

    fn apply(&self, state: &ProblemState) -> ProcessorResult {
        let ProblemState::Csr(state) = state else {
            return ProcessorResult::Inapplicable;
        };
        if state.boundary != super::super::CsrProofBoundary::Root {
            return ProcessorResult::Inapplicable;
        }
        let csr = &state.csr;
        // The certified CPF transformation requires a ground source symbol
        // for the activation construction. Reject the processor here rather
        // than discovering the missing witness only during serialization.
        if !csr.trs().arities().values().any(|arity| *arity == 0) {
            return ProcessorResult::Inapplicable;
        }
        let transformation = csr_gm_transformation(csr);
        let mark_symbol = transformation.mark_symbol;
        let active_symbols = transformation.active_symbols;
        let transformed_rules = transformation.transformed.rules().to_vec();
        let child = if let Some(strategy) = &self.strategy {
            let mut options = self.options.clone();
            options.strategy = Some(strategy.clone());
            let pairs = dependency_pairs(&transformation.transformed);
            ProblemState::DependencyPairs(DpProblemState::ordinary(
                transformation.transformed.clone(),
                pairs,
                options,
            ))
        } else {
            ProblemState::Trs(transformation.transformed.clone())
        };
        let reconstruction_dp = match &child {
            ProblemState::DependencyPairs(problem) => Some(problem.clone()),
            _ => None,
        };
        ProcessorResult::Applied(ProcessorApplication::new(vec![child], move |children| {
            let [child] = <[ProblemCertificate; 1]>::try_from(children).ok()?;
            let proof = match child {
                ProblemCertificate::Trs(proof) => proof,
                ProblemCertificate::DependencyPairTree(tree) => {
                    let problem = reconstruction_dp.as_ref()?;
                    let proof = reconstruct_dependency_pair_proof(problem, tree);
                    Proof::terminating(vec![ProofStep::DependencyPairProof {
                        proof: Box::new(proof),
                    }])
                }
                _ => return None,
            };
            if proof.status() != &crate::proving::Status::Terminating {
                return None;
            }
            Some(ProblemCertificate::Trs(Proof::terminating(vec![
                ProofStep::ContextSensitiveGmTransformation {
                    mark_symbol: mark_symbol.clone(),
                    active_symbols: active_symbols.clone(),
                    transformed_rules: transformed_rules.clone(),
                    proof: Box::new(proof),
                },
            ])))
        }))
    }
}

#[cfg(test)]
mod tests {
    use crate::proving::dependency_pairs::DpOptions;
    use crate::proving::processors::{
        CsrProblemState, ProblemState, ProcessorResult, WorklistProcessor,
    };

    use super::CsrGmTransformationProcessor;

    #[test]
    fn gm_transformation_requires_a_source_constant() {
        let csr = crate::parsing::parse_ari_cstrs(
            Some("constant-free-gm".to_string()),
            r#"
(format CSTRS)
(fun f 1 :replacement-map (1))
(rule (f X) (f X))
"#,
        )
        .expect("parse constant-free CSR");
        let result = CsrGmTransformationProcessor {
            options: DpOptions::default(),
            strategy: None,
        }
        .apply(&ProblemState::Csr(CsrProblemState::root(csr)));

        assert!(matches!(result, ProcessorResult::Inapplicable));
    }
}
