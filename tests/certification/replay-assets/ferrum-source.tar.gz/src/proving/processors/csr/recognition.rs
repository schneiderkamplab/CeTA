use std::collections::{BTreeMap, BTreeSet};

use crate::core::{CsrTrs, ReplacementMap, RewriteRule, Symbol, Term, Trs};

#[derive(Clone, Debug)]
pub(crate) struct Gm04InverseCsr {
    pub csr: CsrTrs,
    /// Complete source signature recovered from the transformed system.
    /// Constructors that occur only in GM04 administrative rules are absent
    /// from `csr.trs().arities()` but remain part of the transformation
    /// schema and therefore must be carried explicitly in the certificate.
    pub source_signature: BTreeMap<Symbol, usize>,
    pub source_replacement_map: ReplacementMap,
    /// Exact non-top residual used by the mechanized GM04 theorem.  It includes
    /// constructor-only nullaries recovered from their `proper(c) -> ok(c)`
    /// administrative rules.  The checker admits that signature extension only
    /// when the source child establishes global CSR termination.
    pub residual_rules: Vec<RewriteRule>,
    pub active_symbol: Symbol,
    pub mark_symbol: Symbol,
    pub proper_symbol: Symbol,
    pub ok_symbol: Symbol,
    pub top_symbol: Symbol,
}

/// Recognize the standard Giesl--Middeldorp `active/mark/proper/ok/top`
/// transformation used by the transformed-CSR benchmarks.
///
/// This is intentionally a complete-schema check, not a naming heuristic:
/// source rules and replacement-map positions are reconstructed first, and
/// every rule of the live innermost TRS must then be one of the rules generated
/// by that source CSR.  The published transformation is sound for subsets of
/// the complete generated system, so missing administrative rules are allowed;
/// foreign rules are not. Role discovery currently requires both outer
/// wrapper transitions, even though the theorem admits smaller subsets.
pub(crate) fn recognize_gm04_inverse_csr(trs: &Trs) -> Option<Gm04InverseCsr> {
    // Infer t(m(x))->t(p(x)) and t(o(x))->t(a(x)); the full
    // generated-schema check below decides whether these roles are valid.
    let edges = trs
        .rules()
        .iter()
        .filter_map(|rule| {
            let (top, left) = unary_term(rule.lhs())?;
            let (right_top, right) = unary_term(rule.rhs())?;
            let (from, x) = unary_term(left)?;
            let (to, y) = unary_term(right)?;
            (top == right_top && x == y && matches!(x, Term::Var(_))).then_some((
                top.clone(),
                from.clone(),
                to.clone(),
            ))
        })
        .collect::<BTreeSet<_>>();
    for (top, mark, proper) in &edges {
        for (other_top, ok, active) in &edges {
            if top != other_top || BTreeSet::from([top, mark, proper, ok, active]).len() != 5 {
                continue;
            }
            if let Some(inverse) = recognize_gm04_with_roles(
                trs,
                active.clone(),
                mark.clone(),
                proper.clone(),
                ok.clone(),
                top.clone(),
            ) {
                return Some(inverse);
            }
        }
    }
    None
}

fn unary_term(term: &Term) -> Option<(&Symbol, &Term)> {
    match term {
        Term::App { symbol, args } if args.len() == 1 => Some((symbol, &args[0])),
        _ => None,
    }
}

fn recognize_gm04_with_roles(
    trs: &Trs,
    active_symbol: Symbol,
    mark_symbol: Symbol,
    proper_symbol: Symbol,
    ok_symbol: Symbol,
    top_symbol: Symbol,
) -> Option<Gm04InverseCsr> {
    let arities = trs.arities();

    let unwrap = |term: &Term, wrapper: &Symbol| match term {
        Term::App { symbol, args } if symbol == wrapper && args.len() == 1 => Some(args[0].clone()),
        _ => None,
    };
    let mut source_rules = Vec::new();
    for rule in trs.rules() {
        if let (Some(lhs), Some(rhs)) = (
            unwrap(rule.lhs(), &active_symbol),
            unwrap(rule.rhs(), &mark_symbol),
        ) {
            source_rules.push(RewriteRule::new(lhs, rhs));
        }
    }
    if source_rules.is_empty() {
        return None;
    }

    let administrative = BTreeSet::from([
        active_symbol.clone(),
        mark_symbol.clone(),
        proper_symbol.clone(),
        ok_symbol.clone(),
        top_symbol.clone(),
    ]);
    let mut rule_source_arities = BTreeMap::<Symbol, usize>::new();
    for rule in &source_rules {
        collect_source_arities(rule.lhs(), &administrative, &mut rule_source_arities)?;
        collect_source_arities(rule.rhs(), &administrative, &mut rule_source_arities)?;
    }
    if rule_source_arities.is_empty() {
        return None;
    }

    // The ARI `Trs` representation intentionally retains only rules, not the
    // declared signature.  The complete transformed system nevertheless
    // contains one proper/ok administrative rule for every source constructor,
    // so its live rule-derived signature recovers constructors that never occur
    // in a source rule (for example `nil` in Ex1_2_AEL03_C).  Keep that complete
    // signature separate from the operational source CSR: adding dummy rules or
    // pretending that such constructors are defined would change the relation
    // whose termination the source child proves.
    let source_signature = arities
        .iter()
        .filter(|(symbol, _)| !administrative.contains(*symbol))
        .map(|(symbol, arity)| (symbol.clone(), *arity))
        .collect::<BTreeMap<_, _>>();
    if !rule_source_arities
        .iter()
        .all(|(symbol, arity)| source_signature.get(symbol) == Some(arity))
    {
        return None;
    }

    let mut allowed = source_signature
        .keys()
        .cloned()
        .map(|symbol| (symbol, BTreeSet::new()))
        .collect::<BTreeMap<_, _>>();
    for rule in trs.rules() {
        if let Some((symbol, index)) = activation_position(rule, &active_symbol, &source_signature)
        {
            allowed.get_mut(&symbol)?.insert(index);
        }
    }

    let source_trs = Trs::new_with_strategy(
        trs.name().map(str::to_string),
        trs.variables().clone(),
        source_rules.clone(),
        crate::core::RewriteStrategy::Full,
    );
    let operational_arities = source_trs.arities();
    let operational_allowed = allowed
        .iter()
        .filter(|(symbol, _)| operational_arities.contains_key(*symbol))
        .map(|(symbol, positions)| (symbol.clone(), positions.clone()))
        .collect();
    let csr = CsrTrs::new(source_trs, ReplacementMap::new(operational_allowed)).ok()?;
    if !trs.rules().iter().all(|rule| {
        gm04_rule_is_generated(
            rule,
            &source_rules,
            &source_signature,
            &allowed,
            &active_symbol,
            &mark_symbol,
            &proper_symbol,
            &ok_symbol,
            &top_symbol,
        )
    }) {
        return None;
    }
    let residual_rules = gm04_non_top_rules(
        &source_rules,
        &source_signature,
        &allowed,
        &active_symbol,
        &mark_symbol,
        &proper_symbol,
        &ok_symbol,
    );
    Some(Gm04InverseCsr {
        csr,
        source_signature,
        source_replacement_map: ReplacementMap::new(allowed),
        residual_rules,
        active_symbol,
        mark_symbol,
        proper_symbol,
        ok_symbol,
        top_symbol,
    })
}

#[allow(clippy::too_many_arguments)]
fn gm04_non_top_rules(
    source_rules: &[RewriteRule],
    source_arities: &BTreeMap<Symbol, usize>,
    allowed: &BTreeMap<Symbol, BTreeSet<usize>>,
    active: &Symbol,
    mark: &Symbol,
    proper: &Symbol,
    ok: &Symbol,
) -> Vec<RewriteRule> {
    let mut rules = source_rules
        .iter()
        .map(|rule| {
            RewriteRule::new(
                Term::app(active.as_str(), vec![rule.lhs().clone()]),
                Term::app(mark.as_str(), vec![rule.rhs().clone()]),
            )
        })
        .collect::<Vec<_>>();

    for (symbol, arity) in source_arities {
        let variables = canonical_variables(*arity);
        let plain = Term::app(symbol.as_str(), variables.clone());
        for index in allowed.get(symbol).into_iter().flatten() {
            let mut arguments = variables.clone();
            arguments[*index] = Term::app(active.as_str(), vec![arguments[*index].clone()]);
            rules.push(RewriteRule::new(
                Term::app(active.as_str(), vec![plain.clone()]),
                Term::app(symbol.as_str(), arguments),
            ));
        }
    }
    for (symbol, arity) in source_arities {
        let variables = canonical_variables(*arity);
        let plain = Term::app(symbol.as_str(), variables.clone());
        for index in allowed.get(symbol).into_iter().flatten() {
            let mut arguments = variables.clone();
            arguments[*index] = Term::app(mark.as_str(), vec![arguments[*index].clone()]);
            rules.push(RewriteRule::new(
                Term::app(symbol.as_str(), arguments),
                Term::app(mark.as_str(), vec![plain.clone()]),
            ));
        }
    }
    for (symbol, arity) in source_arities {
        let variables = canonical_variables(*arity);
        let plain = Term::app(symbol.as_str(), variables.clone());
        if *arity == 0 {
            rules.push(RewriteRule::new(
                Term::app(proper.as_str(), vec![plain.clone()]),
                Term::app(ok.as_str(), vec![plain]),
            ));
        } else {
            rules.push(RewriteRule::new(
                Term::app(proper.as_str(), vec![plain.clone()]),
                Term::app(
                    symbol.as_str(),
                    variables
                        .iter()
                        .cloned()
                        .map(|argument| Term::app(proper.as_str(), vec![argument]))
                        .collect(),
                ),
            ));
        }
    }
    for (symbol, arity) in source_arities {
        if *arity == 0 {
            continue;
        }
        let variables = canonical_variables(*arity);
        let plain = Term::app(symbol.as_str(), variables.clone());
        rules.push(RewriteRule::new(
            Term::app(
                symbol.as_str(),
                variables
                    .iter()
                    .cloned()
                    .map(|argument| Term::app(ok.as_str(), vec![argument]))
                    .collect(),
            ),
            Term::app(ok.as_str(), vec![plain]),
        ));
    }
    rules
}

fn collect_source_arities(
    term: &Term,
    administrative: &BTreeSet<Symbol>,
    arities: &mut BTreeMap<Symbol, usize>,
) -> Option<()> {
    let Term::App { symbol, args } = term else {
        return Some(());
    };
    if administrative.contains(symbol) {
        return None;
    }
    match arities.insert(symbol.clone(), args.len()) {
        Some(old) if old != args.len() => return None,
        _ => {}
    }
    for argument in args {
        collect_source_arities(argument, administrative, arities)?;
    }
    Some(())
}

fn canonical_variables(arity: usize) -> Vec<Term> {
    (0..arity)
        // The executable GM04 checker constructs its administrative schema
        // with IsaFoR's x_1_to_x_n variables.  CPF rule removal subtracts the
        // listed strict rules syntactically, so merely alpha-equivalent fresh
        // names would leave those rules in the checker's residual.  Use the
        // checker-normal form at this serialization boundary.
        .map(|index| Term::var(format!("x{}", index + 1)))
        .collect()
}

fn rule_alpha_equivalent(rule: &RewriteRule, lhs: &Term, rhs: &Term) -> bool {
    fn terms(
        left: &Term,
        right: &Term,
        forward: &mut BTreeMap<crate::core::Variable, crate::core::Variable>,
        reverse: &mut BTreeMap<crate::core::Variable, crate::core::Variable>,
    ) -> bool {
        match (left, right) {
            (Term::Var(left), Term::Var(right)) => {
                if forward.get(left).is_some_and(|mapped| mapped != right)
                    || reverse.get(right).is_some_and(|mapped| mapped != left)
                {
                    return false;
                }
                forward.insert(left.clone(), right.clone());
                reverse.insert(right.clone(), left.clone());
                true
            }
            (
                Term::App {
                    symbol: left_symbol,
                    args: left_args,
                },
                Term::App {
                    symbol: right_symbol,
                    args: right_args,
                },
            ) => {
                left_symbol == right_symbol
                    && left_args.len() == right_args.len()
                    && left_args
                        .iter()
                        .zip(right_args)
                        .all(|(left, right)| terms(left, right, forward, reverse))
            }
            _ => false,
        }
    }
    let mut forward = BTreeMap::new();
    let mut reverse = BTreeMap::new();
    terms(rule.lhs(), lhs, &mut forward, &mut reverse)
        && terms(rule.rhs(), rhs, &mut forward, &mut reverse)
}

fn activation_position(
    rule: &RewriteRule,
    active: &Symbol,
    source_arities: &BTreeMap<Symbol, usize>,
) -> Option<(Symbol, usize)> {
    let Term::App {
        symbol: lhs_active,
        args: outer,
    } = rule.lhs()
    else {
        return None;
    };
    let [Term::App { symbol, args }] = outer.as_slice() else {
        return None;
    };
    if lhs_active != active || source_arities.get(symbol) != Some(&args.len()) {
        return None;
    }
    let Term::App {
        symbol: rhs_symbol,
        args: rhs_args,
    } = rule.rhs()
    else {
        return None;
    };
    if rhs_symbol != symbol || rhs_args.len() != args.len() {
        return None;
    }
    let mut activated = None;
    for (index, (lhs, rhs)) in args.iter().zip(rhs_args).enumerate() {
        if lhs == rhs {
            continue;
        }
        let Term::App {
            symbol: wrapper,
            args: wrapped,
        } = rhs
        else {
            return None;
        };
        if wrapper != active || wrapped.as_slice() != [lhs.clone()] || activated.is_some() {
            return None;
        }
        activated = Some(index);
    }
    activated.map(|index| (symbol.clone(), index))
}

#[allow(clippy::too_many_arguments)]
fn gm04_rule_is_generated(
    rule: &RewriteRule,
    source_rules: &[RewriteRule],
    source_arities: &BTreeMap<Symbol, usize>,
    allowed: &BTreeMap<Symbol, BTreeSet<usize>>,
    active: &Symbol,
    mark: &Symbol,
    proper: &Symbol,
    ok: &Symbol,
    top: &Symbol,
) -> bool {
    if source_rules.iter().any(|source| {
        rule.lhs() == &Term::app(active.as_str(), vec![source.lhs().clone()])
            && rule.rhs() == &Term::app(mark.as_str(), vec![source.rhs().clone()])
    }) {
        return true;
    }
    if activation_position(rule, active, source_arities)
        .is_some_and(|(symbol, index)| allowed.get(&symbol).is_some_and(|set| set.contains(&index)))
    {
        return true;
    }
    for (symbol, arity) in source_arities {
        let variables = canonical_variables(*arity);
        let plain = Term::app(symbol.as_str(), variables.clone());
        for index in allowed.get(symbol).into_iter().flatten() {
            let mut marked = variables.clone();
            marked[*index] = Term::app(mark.as_str(), vec![marked[*index].clone()]);
            if rule_alpha_equivalent(
                rule,
                &Term::app(symbol.as_str(), marked),
                &Term::app(mark.as_str(), vec![plain.clone()]),
            ) {
                return true;
            }
        }
        let proper_lhs = Term::app(proper.as_str(), vec![plain.clone()]);
        let proper_rhs = Term::app(
            symbol.as_str(),
            variables
                .iter()
                .cloned()
                .map(|argument| Term::app(proper.as_str(), vec![argument]))
                .collect(),
        );
        if rule_alpha_equivalent(rule, &proper_lhs, &proper_rhs) {
            return true;
        }
        let ok_args = variables
            .iter()
            .cloned()
            .map(|argument| Term::app(ok.as_str(), vec![argument]))
            .collect::<Vec<_>>();
        if rule_alpha_equivalent(
            rule,
            &Term::app(symbol.as_str(), ok_args),
            &Term::app(ok.as_str(), vec![plain.clone()]),
        ) {
            return true;
        }
        if *arity == 0
            && rule.lhs() == &Term::app(proper.as_str(), vec![plain.clone()])
            && rule.rhs() == &Term::app(ok.as_str(), vec![plain])
        {
            return true;
        }
    }
    let x = Term::var("__gm04_top_x");
    rule_alpha_equivalent(
        rule,
        &Term::app(
            top.as_str(),
            vec![Term::app(mark.as_str(), vec![x.clone()])],
        ),
        &Term::app(
            top.as_str(),
            vec![Term::app(proper.as_str(), vec![x.clone()])],
        ),
    ) || rule_alpha_equivalent(
        rule,
        &Term::app(top.as_str(), vec![Term::app(ok.as_str(), vec![x.clone()])]),
        &Term::app(top.as_str(), vec![Term::app(active.as_str(), vec![x])]),
    )
}

/// Infer wrapper transport roles from live rules, never from spellings.
/// This only proposes a replacement map; the switch processor still has to
/// discharge its independent proof obligations.
fn structural_wrapper_roles(trs: &Trs) -> (BTreeSet<Symbol>, BTreeSet<Symbol>) {
    let mut wrappers = BTreeSet::new();
    let mut activated = BTreeSet::new();
    let transitions = trs
        .rules()
        .iter()
        .filter_map(|rule| {
            let (from, _) = unary_term(rule.lhs())?;
            let (to, _) = unary_term(rule.rhs())?;
            (from != to).then_some((from.clone(), to.clone()))
        })
        .collect::<BTreeSet<_>>();
    for (from, to) in &transitions {
        if transitions.contains(&(to.clone(), from.clone())) {
            wrappers.extend([from.clone(), to.clone()]);
        }
    }
    for rule in trs.rules() {
        // w(f(xs)) -> g(..., w(x_i), ...).
        if let Some((
            wrapper,
            Term::App {
                symbol: source,
                args: xs,
            },
        )) = unary_term(rule.lhs())
            && let Term::App {
                symbol: target,
                args: ys,
            } = rule.rhs()
            && xs.len() == ys.len()
            && !xs.is_empty()
            && xs.iter().zip(ys).all(|(x, y)| {
                x == y || unary_term(y).is_some_and(|(w, child)| w == wrapper && child == x)
            })
            && xs.iter().zip(ys).any(|(x, y)| x != y)
        {
            wrappers.insert(wrapper.clone());
            if source != target {
                activated.insert(target.clone());
            }
        }
        // t(w(x)) -> t(v(x)).
        if let (Some((top, lhs)), Some((rhs_top, rhs))) =
            (unary_term(rule.lhs()), unary_term(rule.rhs()))
            && top == rhs_top
            && let (Some((from, x)), Some((to, y))) = (unary_term(lhs), unary_term(rhs))
            && from != to
            && x == y
            && matches!(x, Term::Var(_))
        {
            wrappers.extend([top.clone(), from.clone(), to.clone()]);
        }
    }
    // Connect source/target wrappers to the already observed transport roles.
    loop {
        let before = wrappers.len();
        for rule in trs.rules() {
            if let (Some((from, _)), Some((to, _))) =
                (unary_term(rule.lhs()), unary_term(rule.rhs()))
                && from != to
                && (wrappers.contains(from) || wrappers.contains(to))
            {
                wrappers.extend([from.clone(), to.clone()]);
            }
        }
        if before == wrappers.len() {
            break;
        }
    }
    (wrappers, activated)
}

pub(crate) fn recognize_transformed_csr(trs: &Trs) -> Option<CsrTrs> {
    let arities = trs.arities();
    let (wrappers, activated) = structural_wrapper_roles(trs);
    if wrappers.is_empty() {
        return None;
    }
    let mut allowed = arities
        .keys()
        .cloned()
        .map(|symbol| (symbol, BTreeSet::new()))
        .collect::<BTreeMap<_, _>>();
    for rule in trs.rules() {
        let Some((
            wrapper,
            Term::App {
                symbol: source,
                args: xs,
            },
        )) = unary_term(rule.lhs())
        else {
            continue;
        };
        if !wrappers.contains(wrapper) {
            continue;
        }
        let Term::App {
            symbol: target,
            args: ys,
        } = rule.rhs()
        else {
            continue;
        };
        if source != target || xs.len() != ys.len() {
            continue;
        }
        for (index, (x, y)) in xs.iter().zip(ys).enumerate() {
            if unary_term(y).is_some_and(|(w, child)| wrappers.contains(w) && child == x) {
                allowed.entry(source.clone()).or_default().insert(index);
            }
        }
    }
    for wrapper in wrappers {
        if arities.get(&wrapper) == Some(&1) {
            allowed.insert(wrapper, BTreeSet::from([0]));
        }
    }
    for symbol in activated {
        if let Some(arity) = arities.get(&symbol) {
            allowed.insert(symbol, (0..*arity).collect());
        }
    }
    CsrTrs::new(trs.clone(), ReplacementMap::new(allowed)).ok()
}

pub(crate) fn looks_like_standard_transformed_csr(trs: &Trs) -> bool {
    !structural_wrapper_roles(trs).0.is_empty()
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn activated_symbols_are_inferred_without_prefixes() {
        let trs = crate::parsing::parse_ari_trs(
            None,
            r#"
(format TRS)
(fun envelope 1)
(fun plain 1)
(fun running 1)
(rule (envelope (plain X)) (running (envelope X)))
(rule (running X) (plain X))
"#,
        )
        .unwrap();
        let csr = recognize_transformed_csr(&trs).unwrap();
        assert_eq!(
            csr.replacement_map()
                .allowed_positions(&Symbol::new("running")),
            Some(&BTreeSet::from([0]))
        );
        let names_only = crate::parsing::parse_ari_trs(
            None,
            r#"
(format TRS)
(fun active 1)
(fun mark 1)
(rule (active X) (mark X))
"#,
        )
        .unwrap();
        assert!(!looks_like_standard_transformed_csr(&names_only));
        assert!(recognize_gm04_inverse_csr(&names_only).is_none());
    }

    #[test]
    fn gm04_inverse_recovers_source_rules_and_replacement_map() {
        let trs = crate::parsing::parse_ari_trs(
            None,
            r#"
(format TRS)
(strategy INNERMOST)
(fun active 1)
(fun mark 1)
(fun proper 1)
(fun ok 1)
(fun top 1)
(fun f 3)
(fun a 0)
(fun b 0)
(fun c 0)
(fun unused 0)
(rule (active (f a b X)) (mark (f X X X)))
(rule (active c) (mark a))
(rule (active c) (mark b))
(rule (active (f X1 X2 X3)) (f (active X1) X2 X3))
(rule (active (f X1 X2 X3)) (f X1 X2 (active X3)))
(rule (f (mark X1) X2 X3) (mark (f X1 X2 X3)))
(rule (f X1 X2 (mark X3)) (mark (f X1 X2 X3)))
(rule (proper (f X1 X2 X3)) (f (proper X1) (proper X2) (proper X3)))
(rule (proper a) (ok a))
(rule (proper b) (ok b))
(rule (proper c) (ok c))
(rule (proper unused) (ok unused))
(rule (f (ok X1) (ok X2) (ok X3)) (ok (f X1 X2 X3)))
(rule (top (mark X)) (top (proper X)))
(rule (top (ok X)) (top (active X)))
"#,
        )
        .unwrap();
        let inverse = recognize_gm04_inverse_csr(&trs).expect("complete GM04 schema");
        fn renamed(term: &Term) -> Term {
            match term {
                Term::Var(_) => term.clone(),
                Term::App { symbol, args } => Term::app(
                    &format!("renamed_{}", symbol.as_str()),
                    args.iter().map(renamed).collect(),
                ),
            }
        }
        let renamed_trs = Trs::new_with_strategy(
            None,
            trs.variables().clone(),
            trs.rules()
                .iter()
                .map(|r| RewriteRule::new(renamed(r.lhs()), renamed(r.rhs())))
                .collect(),
            trs.strategy(),
        );
        let renamed_inverse =
            recognize_gm04_inverse_csr(&renamed_trs).expect("renamed GM04 schema");
        assert_eq!(renamed_inverse.active_symbol.as_str(), "renamed_active");
        assert_eq!(
            renamed_inverse
                .source_replacement_map
                .allowed_positions(&Symbol::new("renamed_f")),
            inverse
                .source_replacement_map
                .allowed_positions(&Symbol::new("f"))
        );
        assert!(looks_like_standard_transformed_csr(&renamed_trs));
        assert!(recognize_transformed_csr(&renamed_trs).is_some());
        let mut foreign_rules = renamed_trs.rules().to_vec();
        foreign_rules.push(RewriteRule::new(
            Term::app("renamed_top", vec![Term::var("X")]),
            Term::var("X"),
        ));
        let foreign = Trs::new_with_strategy(
            None,
            renamed_trs.variables().clone(),
            foreign_rules,
            renamed_trs.strategy(),
        );
        assert!(recognize_gm04_inverse_csr(&foreign).is_none());
        assert_eq!(inverse.csr.rules().len(), 3);
        assert_eq!(inverse.residual_rules.len(), 13);
        assert!(
            inverse.residual_rules.iter().any(|rule| {
                rule.to_string() == "active(f(x1, x2, x3)) -> f(active(x1), x2, x3)"
            })
        );
        assert!(
            inverse
                .residual_rules
                .iter()
                .all(|rule| !rule.to_string().contains("__gm04_x"))
        );
        assert_eq!(
            inverse
                .residual_rules
                .iter()
                .filter(|rule| rule.to_string().contains("unused"))
                .map(ToString::to_string)
                .collect::<Vec<_>>(),
            vec!["proper(unused) -> ok(unused)"]
        );
        assert_eq!(
            inverse.source_signature.get(&Symbol::new("unused")),
            Some(&0)
        );
        assert_eq!(
            inverse
                .source_replacement_map
                .allowed_positions(&Symbol::new("unused")),
            Some(&BTreeSet::new())
        );
        assert_eq!(
            inverse
                .csr
                .replacement_map()
                .allowed_positions(&Symbol::new("unused")),
            None
        );
        assert_eq!(
            inverse
                .csr
                .replacement_map()
                .allowed_positions(&Symbol::new("f")),
            Some(&BTreeSet::from([0, 2]))
        );
    }

    #[test]
    fn gm04_inverse_rejects_foreign_administrative_rule() {
        let trs = Trs::new(
            None,
            BTreeSet::new(),
            vec![
                RewriteRule::new(
                    Term::app("active", vec![Term::app("a", vec![])]),
                    Term::app("mark", vec![Term::app("a", vec![])]),
                ),
                RewriteRule::new(
                    Term::app("proper", vec![Term::app("a", vec![])]),
                    Term::app("active", vec![Term::app("a", vec![])]),
                ),
                RewriteRule::new(
                    Term::app("top", vec![Term::app("mark", vec![Term::var("x")])]),
                    Term::app("top", vec![Term::app("proper", vec![Term::var("x")])]),
                ),
                RewriteRule::new(
                    Term::app("top", vec![Term::app("ok", vec![Term::var("x")])]),
                    Term::app("top", vec![Term::app("active", vec![Term::var("x")])]),
                ),
            ],
        );
        assert!(recognize_gm04_inverse_csr(&trs).is_none());
    }

    #[test]
    fn workspace_transformed_csr_c_family_matches_gm04_schema() {
        let directory = std::path::Path::new(env!("CARGO_MANIFEST_DIR"))
            .parent()
            .unwrap()
            .join("TPDB-ARI/TRS_Innermost/Transformed_CSR_innermost_04");
        if !directory.is_dir() {
            return;
        }
        let mut recognized = Vec::new();
        for entry in std::fs::read_dir(directory).unwrap() {
            let path = entry.unwrap().path();
            if !path
                .file_name()
                .and_then(|name| name.to_str())
                .is_some_and(|name| name.ends_with("_C.ari"))
            {
                continue;
            }
            let input = std::fs::read_to_string(&path).unwrap();
            let trs = crate::parsing::parse_ari_trs(
                path.file_name()
                    .map(|name| name.to_string_lossy().into_owned()),
                &input,
            )
            .unwrap();
            if recognize_gm04_inverse_csr(&trs).is_some() {
                recognized.push(path);
            }
        }
        eprintln!("recognized {} checked GM04 C systems", recognized.len());
        assert!(
            recognized.len() >= 25,
            "only {} transformed-CSR C systems matched the checked GM04 schema: {recognized:#?}",
            recognized.len()
        );
    }
}
