use std::time::Instant;

use crate::proving::dependency_pairs::{
    MatrixInterpretation, checked_csr_matrix_rule_removal, synthesize_csr_matrix_rule_removal,
};
use crate::proving::engine::{ProveOptions, ProveStrategyProcessor};
use crate::proving::{Proof, ProofStep};

use super::super::{
    ProblemCertificate, ProblemState, ProcessorApplication, ProcessorResult, WorklistProcessor,
};

pub struct CsrMatrixRuleRemovalProcessor {
    pub options: ProveOptions,
    pub dimension: usize,
    pub max_constant: i64,
    pub max_coefficient: i64,
    pub max_symbols: Option<usize>,
    pub max_arity: Option<usize>,
    pub exact_interpretation: Option<Vec<(String, Vec<i64>, Vec<Vec<Vec<i64>>>)>>,
    pub deadline: Option<Instant>,
}

impl WorklistProcessor for CsrMatrixRuleRemovalProcessor {
    fn name(&self) -> &'static str {
        "csr-matrix-rule-removal"
    }

    fn apply(&self, state: &ProblemState) -> ProcessorResult {
        let ProblemState::Csr(state) = state else {
            return ProcessorResult::Inapplicable;
        };
        let csr = &state.csr;
        let removal = if let Some(witness) = self.exact_interpretation.as_ref() {
            let interpretations = witness
                .iter()
                .map(|(symbol, constant, coefficients)| {
                    (
                        symbol.clone(),
                        MatrixInterpretation {
                            constant: constant.clone(),
                            coefficients: coefficients.clone(),
                        },
                    )
                })
                .collect();
            checked_csr_matrix_rule_removal(csr, interpretations)
        } else {
            let mut dp_options = self.options.dp_options.clone();
            dp_options.max_polynomial_constant = self.max_constant;
            dp_options.max_polynomial_coefficient = self.max_coefficient;
            if let Some(value) = self.max_symbols {
                dp_options.max_polynomial_symbols = value;
            }
            if let Some(value) = self.max_arity {
                dp_options.max_polynomial_arity = value;
            }
            synthesize_csr_matrix_rule_removal(csr, &dp_options, self.dimension, self.deadline)
        };
        let Some(removal) = removal else {
            return ProcessorResult::Inapplicable;
        };
        let interpretations = removal.interpretations;
        let exact = interpretations
            .iter()
            .map(|(symbol, interpretation)| {
                (
                    symbol.clone(),
                    interpretation.constant.clone(),
                    interpretation.coefficients.clone(),
                )
            })
            .collect();
        let selected_atom = ProveStrategyProcessor::ExactMatrixInterpretation {
            interpretation: exact,
        }
        .to_strategy_atom();
        let dimension = removal.dimension;
        let strict_dimension = removal.strict_dimension;
        let removed = removal.removed;
        ProcessorResult::Applied(
            ProcessorApplication::new(
                vec![ProblemState::Csr(
                    super::super::CsrProblemState::rule_removal_child(state, removal.remaining),
                )],
                move |children| {
                    let [ProblemCertificate::Trs(proof)] =
                        <[ProblemCertificate; 1]>::try_from(children).ok()?
                    else {
                        return None;
                    };
                    if proof.status() != &crate::proving::Status::Terminating {
                        return None;
                    }
                    Some(ProblemCertificate::Trs(Proof::terminating(vec![
                        ProofStep::ContextSensitiveMatrixRuleRemoval {
                            interpretations: interpretations.clone(),
                            dimension,
                            strict_dimension,
                            removed: removed.clone(),
                            proof: Box::new(proof),
                        },
                    ])))
                },
            )
            .with_selected_atom(selected_atom),
        )
    }
}
