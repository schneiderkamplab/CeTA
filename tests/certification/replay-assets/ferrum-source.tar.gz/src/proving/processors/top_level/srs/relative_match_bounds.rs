use std::collections::{BTreeMap, BTreeSet};
use std::time::Instant;

use super::automaton::{
    add_srs_word_symbols_to_arities, complete_srs_relative_match_bounds_completion,
    srs_relative_match_bounds_candidate_batches, srs_rules_from_rewrite_rules,
};
use crate::core::{RelativeTrs, Trs};
use crate::proving::{BoundsProof, BoundsType, Proof, ProofStep, Status};

use super::super::super::{
    ProblemCertificate, ProblemState, ProcessorApplication, ProcessorResult, WorklistProcessor,
};

/// One relative match-bounds deletion.
///
/// The former implementation recursively repeated this processor and hid all
/// intermediate relative SRS obligations in one proof-returning call.  This
/// processor performs exactly one certified deletion and returns its residual
/// to the universal worklist.
pub struct SrsRelativeMatchBoundsProcessor {
    pub max_bound: usize,
    pub max_states: usize,
    pub max_transitions: usize,
    pub deadline: Option<Instant>,
}

impl WorklistProcessor for SrsRelativeMatchBoundsProcessor {
    fn name(&self) -> &'static str {
        "srs-relative-match-bounds"
    }

    fn apply(&self, state: &ProblemState) -> ProcessorResult {
        let relative = match state {
            ProblemState::RelativeSrs(relative) => relative.clone(),
            ProblemState::Srs(trs) => RelativeTrs::new(trs.clone(), Vec::new()),
            _ => return ProcessorResult::Inapplicable,
        };
        let Some(strict_rules) = relative.strict().srs_rules() else {
            return ProcessorResult::Inapplicable;
        };
        if strict_rules.is_empty() {
            return ProcessorResult::Inapplicable;
        }
        let Some(weak_rules) = srs_rules_from_rewrite_rules(relative.weak_rules()) else {
            return ProcessorResult::Inapplicable;
        };
        let mut arities = BTreeMap::new();
        for (symbol, arity) in relative.strict().arities() {
            if arity > 1 {
                return ProcessorResult::Inapplicable;
            }
            arities.insert(symbol.as_str().to_string(), arity);
        }
        add_srs_word_symbols_to_arities(&strict_rules, &mut arities);
        add_srs_word_symbols_to_arities(&weak_rules, &mut arities);

        // Prefer deleting a larger certified batch even when it needs a
        // slightly higher bound.  Returning the first low-bound singleton
        // creates a needlessly hard residual and used to hide that chain in
        // recursive control flow.
        for removed_indices in srs_relative_match_bounds_candidate_batches(&strict_rules) {
            for bound in 0..=self.max_bound {
                if self.deadline.is_some_and(|limit| Instant::now() >= limit) {
                    return ProcessorResult::TimedOut;
                }
                let removed_set = removed_indices.iter().copied().collect::<BTreeSet<_>>();
                let selected = removed_indices
                    .iter()
                    .map(|&index| strict_rules[index].clone())
                    .collect::<Vec<_>>();
                let residual_srs = strict_rules
                    .iter()
                    .enumerate()
                    .filter_map(|(index, rule)| {
                        (!removed_set.contains(&index)).then_some(rule.clone())
                    })
                    .collect::<Vec<_>>();
                let current_weak = weak_rules
                    .iter()
                    .cloned()
                    .chain(residual_srs.iter().cloned())
                    .collect::<Vec<_>>();
                let Some(completion) = complete_srs_relative_match_bounds_completion(
                    &selected,
                    &current_weak,
                    &arities,
                    bound,
                    self.max_states,
                    self.max_transitions,
                    self.deadline,
                ) else {
                    continue;
                };

                let removed = removed_indices
                    .iter()
                    .map(|&index| relative.strict().rules()[index].clone())
                    .collect::<Vec<_>>();
                let residual_rules = relative
                    .strict()
                    .rules()
                    .iter()
                    .enumerate()
                    .filter_map(|(index, rule)| {
                        (!removed_set.contains(&index)).then_some(rule.clone())
                    })
                    .collect();
                let residual_strict = Trs::new_with_strategy(
                    relative.strict().name().map(str::to_string),
                    relative.strict().variables().clone(),
                    residual_rules,
                    relative.strict().strategy(),
                );
                let residual_weak = relative
                    .weak_rules()
                    .iter()
                    .cloned()
                    .chain(removed.iter().cloned())
                    .collect();
                // CPF relativeBounds moves Rdelete from the strict component
                // into the weak component, even when its input was ordinary.
                let residual =
                    ProblemState::RelativeSrs(RelativeTrs::new(residual_strict, residual_weak));
                let bounds = BoundsProof {
                    bounds_type: BoundsType::Match,
                    bound,
                    final_states: completion.tail_states,
                    automaton: completion.automaton,
                    state_compatibility: completion.state_compatibility,
                };
                return ProcessorResult::Applied(ProcessorApplication::new(
                    vec![residual],
                    move |children| {
                        let [ProblemCertificate::Trs(proof)] =
                            <[ProblemCertificate; 1]>::try_from(children).ok()?
                        else {
                            return None;
                        };
                        if proof.status() != &Status::Terminating {
                            return None;
                        }
                        Some(ProblemCertificate::Trs(Proof::terminating(vec![
                            ProofStep::RelativeBounds {
                                proof: bounds.clone(),
                                removed: removed.clone(),
                                proof_after_removal: Box::new(proof),
                            },
                        ])))
                    },
                ));
            }
        }
        ProcessorResult::Inapplicable
    }
}
