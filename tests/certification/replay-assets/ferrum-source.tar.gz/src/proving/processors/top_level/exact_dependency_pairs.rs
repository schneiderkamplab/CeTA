use crate::parsing::{CpfInputProblem, parse_cpf_input};
use crate::proving::dependency_pairs::{
    DpOptions, dependency_pair_rules_alpha_equivalent, dependency_pairs,
    reconstruct_dependency_pair_proof,
};
use crate::proving::engine::ProveStrategyProcessor;
use crate::proving::processors::dp::{DpProblemState, same_rule_multiset};
use crate::proving::{Proof, ProofStep};
use crate::standardize::translate_rule_symbols;

use super::super::{
    ProblemCertificate, ProblemState, ProcessorApplication, ProcessorResult, WorklistProcessor,
};

/// Replays the exact DP set selected by a CeTA-certified `dpTrans` step.
///
/// Some innermost DP constructions omit pairs that the generic, deliberately
/// complete Ferrum constructor retains.  Keeping the certified set makes the
/// resulting child state identical to the source proof and therefore
/// independently addressable by oracle guidance.  The final CPF checker
/// validates that the selected set is a sound DP transformation of the live
/// TRS.
pub struct ExactDependencyPairTransformationProcessor {
    pub options: DpOptions,
    pub dp_input_xml: String,
    pub nontermination_q_increase: bool,
}

impl WorklistProcessor for ExactDependencyPairTransformationProcessor {
    fn name(&self) -> &'static str {
        "exact-dependency-pair-transformation"
    }

    fn apply(&self, state: &ProblemState) -> ProcessorResult {
        let trs = match state {
            ProblemState::Trs(trs) | ProblemState::Srs(trs) => trs,
            _ => return ProcessorResult::Inapplicable,
        };
        let Ok(CpfInputProblem::Dp {
            trs: witness_trs,
            pairs: mut witness_pairs,
            mut weak_pairs,
            mut active_rules,
            minimal,
            normal_form_substitutions,
            mut innermost_lhss,
            clear_innermost_lhss,
            mut graph_rules,
            mut transformation_rules,
            ordinary_reduction_started,
            ordinary_bridge_loses_minimality,
            ..
        }) = parse_cpf_input(None, &self.dp_input_xml)
        else {
            return ProcessorResult::Failed {
                reason: "exact DP witness is not a CPF dpInput".to_owned(),
            };
        };
        // Oracle state keys deliberately quotient over rule order and variable
        // names.  Exact witnesses must use the same equivalence here, or a
        // certified DP transformation becomes spuriously inapplicable after
        // harmless reconstruction/canonicalization drift.  Multiplicity and
        // the live rewrite strategy remain part of the obligation.
        let same_rules = same_rule_multiset(witness_trs.rules(), trs.rules());
        let same_strategy = witness_trs.strategy() == trs.strategy();
        let portable = (!same_rules && same_strategy)
            .then(|| crate::proving::processors::dp::portable_trs_isomorphism(&witness_trs, trs))
            .flatten();
        if (!same_rules && portable.is_none()) || !same_strategy {
            if std::env::var_os("FERRUM_TRACE_EXACT_DP").is_some() {
                eprintln!(
                    "exact DP mismatch: witness_rules={} live_rules={} same_rules={} witness_strategy={:?} live_strategy={:?}",
                    witness_trs.rules().len(),
                    trs.rules().len(),
                    same_rules,
                    witness_trs.strategy(),
                    trs.strategy(),
                );
            }
            return ProcessorResult::Failed {
                reason: "exact DP witness does not match the live TRS".to_owned(),
            };
        }
        if let Some((mut symbols, _)) = portable {
            // A root DP transformation marks the defined source symbols.
            // The TRS isomorphism fixes their live images, and therefore also
            // fixes the corresponding marked symbols in the certified DP set.
            for (source, target) in symbols.clone() {
                symbols.insert(
                    crate::core::Symbol::new(format!("{}#", source.as_str())),
                    crate::core::Symbol::new(format!("{}#", target.as_str())),
                );
            }
            let translate_rules = |rules: Vec<crate::core::RewriteRule>| {
                rules
                    .into_iter()
                    .map(|rule| translate_rule_symbols(&rule, &symbols))
                    .collect::<Vec<_>>()
            };
            witness_pairs = translate_rules(witness_pairs);
            weak_pairs = translate_rules(weak_pairs);
            active_rules = active_rules.map(&translate_rules);
            graph_rules = graph_rules.map(&translate_rules);
            transformation_rules = transformation_rules.map(&translate_rules);
            innermost_lhss = innermost_lhss.map(|terms| {
                terms
                    .into_iter()
                    .map(|term| crate::standardize::translate_term_symbols(&term, &symbols))
                    .collect()
            });
        }

        let available = dependency_pairs(trs);
        let mut used = vec![false; available.len()];
        let mut pairs = Vec::with_capacity(witness_pairs.len());
        for mut witness_rule in witness_pairs {
            let witness = crate::proving::DependencyPair::from_rule(witness_rule.clone(), 0);
            let matched = available.iter().enumerate().find(|(index, pair)| {
                !used[*index] && dependency_pair_rules_alpha_equivalent(pair, &witness)
            });
            let matched_source_rule = matched.map(|(index, pair)| {
                used[index] = true;
                // CeTA's nontermination DP transformation compares the
                // unmarked pair literally with its source rule. Oracle
                // alpha-equivalence must therefore be rebound to the live
                // rule's variables before reconstructing the certificate.
                witness_rule = pair.as_rule();
                pair.source_rule()
            });
            // Certified innermost transformations may use a strictly smaller
            // construction than Ferrum's conservative complete generator.
            // Preserve that concrete pair and attach its source-rule
            // provenance by the unmarked LHS root.  CeTA checks the complete
            // selected set when it validates the reconstructed dpTrans.
            let marked_root = witness_rule
                .lhs()
                .root_symbol()
                .map(|symbol| symbol.as_str().trim_end_matches('#'));
            let source_rule = matched_source_rule
                .or_else(|| {
                    marked_root.and_then(|root| {
                        trs.rules().iter().position(|rule| {
                            rule.lhs()
                                .root_symbol()
                                .is_some_and(|symbol| symbol.as_str() == root)
                        })
                    })
                })
                .unwrap_or(0);
            pairs.push(crate::proving::DependencyPair::from_rule(
                witness_rule,
                source_rule,
            ));
        }
        let weak_pairs = weak_pairs
            .into_iter()
            .filter_map(|witness| {
                pairs
                    .iter()
                    .find(|pair| {
                        dependency_pair_rules_alpha_equivalent(
                            pair,
                            &crate::proving::DependencyPair::from_rule(witness.clone(), 0),
                        )
                    })
                    .cloned()
            })
            .collect();
        let problem = DpProblemState::from_parts(
            trs.clone(),
            pairs,
            weak_pairs,
            active_rules,
            minimal,
            self.options.clone(),
        )
        .restore_runtime_context(
            innermost_lhss,
            clear_innermost_lhss,
            graph_rules,
            transformation_rules,
            ordinary_reduction_started,
            ordinary_bridge_loses_minimality,
        )
        .with_normal_form_substitutions(normal_form_substitutions);
        let reconstruction_problem = problem.clone();
        let nontermination_q_increase = self.nontermination_q_increase;
        let retained_pairs = problem.pairs().to_vec();
        let retained_lhss = problem.innermost_lhss().map(<[_]>::to_vec);
        if nontermination_q_increase && retained_lhss.is_none() {
            return ProcessorResult::Failed {
                reason: "exact Q-increase DP witness has no innermost LHS set".to_owned(),
            };
        }
        let selected_atom = if nontermination_q_increase {
            ProveStrategyProcessor::ExactInnermostLhssDependencyPairs {
                dp_input_xml: self.dp_input_xml.clone(),
            }
        } else {
            ProveStrategyProcessor::ExactDependencyPairs {
                dp_input_xml: self.dp_input_xml.clone(),
            }
        }
        .to_strategy_atom();
        ProcessorResult::Applied(
            ProcessorApplication::new(
                vec![ProblemState::DependencyPairs(problem)],
                move |mut children: Vec<ProblemCertificate>| {
                    if nontermination_q_increase {
                        let [ProblemCertificate::DependencyPairNontermination(proof)] =
                            children.as_mut_slice()
                        else {
                            return None;
                        };
                        return Some(ProblemCertificate::Trs(Proof::nonterminating(
                            crate::proving::NonterminationProof::InnermostLhssDependencyPairs {
                                innermost_lhss: retained_lhss.clone()?,
                                pairs: retained_pairs.clone(),
                                proof: Box::new(proof.clone()),
                            },
                        )));
                    }
                    match children.as_mut_slice() {
                        [ProblemCertificate::DependencyPairTree(tree)] => {
                            let proof = reconstruct_dependency_pair_proof(
                                &reconstruction_problem,
                                std::mem::replace(tree, crate::proving::DpProofTree::Empty),
                            );
                            Some(ProblemCertificate::Trs(Proof::terminating(vec![
                                ProofStep::DependencyPairProof {
                                    proof: Box::new(proof),
                                },
                            ])))
                        }
                        [ProblemCertificate::DependencyPairNontermination(proof)] => {
                            Some(ProblemCertificate::Trs(Proof::nonterminating(
                                crate::proving::NonterminationProof::DependencyPairs {
                                    pairs: retained_pairs.clone(),
                                    proof: Box::new(proof.clone()),
                                },
                            )))
                        }
                        _ => None,
                    }
                },
            )
            .with_selected_atom(selected_atom),
        )
    }
}

#[cfg(test)]
mod tests {
    use std::collections::BTreeSet;

    use super::*;
    use crate::core::{RewriteRule, Term, Trs, Variable};
    use crate::proving::{DpNonterminationProof, Status};

    #[test]
    fn exact_dp_transformation_reconstructs_nontermination_children() {
        let trs = Trs::new(
            None,
            BTreeSet::from([Variable::new("x")]),
            vec![RewriteRule::new(
                Term::app("f", vec![Term::app("s", vec![Term::var("x")])]),
                Term::app(
                    "f",
                    vec![Term::app("s", vec![Term::app("s", vec![Term::var("x")])])],
                ),
            )],
        );
        let pairs = dependency_pairs(&trs);
        let dp_input_xml = crate::cert::write_dp_state_input_cpf3(&trs, &pairs, None, true, true)
            .replace("<var>x</var>", "<var>archived</var>");
        let processor = ExactDependencyPairTransformationProcessor {
            options: DpOptions::default(),
            dp_input_xml,
            nontermination_q_increase: false,
        };
        let ProcessorResult::Applied(application) = processor.apply(&ProblemState::Trs(trs)) else {
            panic!("exact DP transformation should apply");
        };
        assert_eq!(application.residuals.len(), 1);
        let ProblemState::DependencyPairs(child) = &application.residuals[0] else {
            panic!("expected DP child");
        };
        assert_eq!(child.pairs()[0].as_rule(), pairs[0].as_rule());
        let certificate = application
            .reconstruct(vec![ProblemCertificate::DependencyPairNontermination(
                DpNonterminationProof::ExactProofXml("<loop/>".to_owned()),
            )])
            .expect("ordinary DP nontermination must reconstruct at the TRS root");
        let ProblemCertificate::Trs(proof) = certificate else {
            panic!("expected a TRS certificate");
        };
        assert_eq!(proof.status(), &Status::Nonterminating);
    }
}
