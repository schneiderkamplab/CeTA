use crate::proving::dependency_pairs::{
    DpOptions, Gm04ResidualContext, dependency_pairs, reconstruct_dependency_pair_proof,
};
use crate::proving::processors::csr::recognition::{
    recognize_gm04_inverse_csr, recognize_transformed_csr,
};
use crate::proving::processors::dp::DpProblemState;
use crate::proving::{Proof, ProofStep, Status};

use super::super::{
    CsrProblemState, ProblemCertificate, ProblemState, ProcessorApplication, ProcessorResult,
    WorklistProcessor,
};

/// Recognize a transformed CSR encoding and expose the CSR obligation.
///
/// The continuation is deliberately not a field of this processor: the
/// universal worklist queries guidance again for the returned CSR state.
pub struct SwitchContextSensitiveProcessor;
pub struct Gm04InverseContextSensitiveProcessor {
    pub options: DpOptions,
    pub full_termination: bool,
}

impl WorklistProcessor for SwitchContextSensitiveProcessor {
    fn name(&self) -> &'static str {
        "switch-context-sensitive"
    }

    fn apply(&self, state: &ProblemState) -> ProcessorResult {
        let ProblemState::Trs(trs) = state else {
            return ProcessorResult::Inapplicable;
        };
        let Some(csr) = recognize_transformed_csr(trs) else {
            return ProcessorResult::Inapplicable;
        };
        let replacement_map = csr.replacement_map().clone();
        let csr_rules = csr.rules().to_vec();
        ProcessorResult::Applied(ProcessorApplication::new(
            vec![ProblemState::Csr(CsrProblemState::root(csr))],
            move |children| {
                let [ProblemCertificate::Trs(proof)] =
                    <[ProblemCertificate; 1]>::try_from(children).ok()?
                else {
                    return None;
                };
                if proof.status() != &Status::Terminating {
                    return None;
                }
                Some(ProblemCertificate::Trs(Proof::terminating(vec![
                    ProofStep::SwitchContextSensitive {
                        replacement_map: replacement_map.clone(),
                        csr_rules: csr_rules.clone(),
                        proof: Box::new(proof),
                    },
                ])))
            },
        ))
    }
}

impl WorklistProcessor for Gm04InverseContextSensitiveProcessor {
    fn name(&self) -> &'static str {
        "gm04-inverse-context-sensitive"
    }

    fn apply(&self, state: &ProblemState) -> ProcessorResult {
        let ProblemState::Trs(trs) = state else {
            return ProcessorResult::Inapplicable;
        };
        let Some(inverse) = recognize_gm04_inverse_csr(trs) else {
            return ProcessorResult::Inapplicable;
        };
        if trs.strategy() == crate::core::RewriteStrategy::Full {
            if self.full_termination {
                // The verified full inverse theorem needs two independent,
                // recursively solvable obligations: the source CSR and the
                // complete transformation without its two top rules.  The
                // checker derives termination of the ordinary two-pair top
                // problem from the source proof, so it is neither necessary
                // nor desirable to smuggle that residual in as an assumption
                // of a transformed DP proof.
                let administrative_trs = crate::core::Trs::new_with_strategy(
                    trs.name().map(str::to_string),
                    trs.variables().clone(),
                    inverse.residual_rules.clone(),
                    crate::core::RewriteStrategy::Full,
                );
                let residuals = vec![
                    ProblemState::Csr(CsrProblemState::root(inverse.csr.clone())),
                    ProblemState::Trs(administrative_trs),
                ];
                return ProcessorResult::Applied(ProcessorApplication::new(
                    residuals,
                    move |children| {
                        let [
                            ProblemCertificate::Trs(source_proof),
                            ProblemCertificate::Trs(administrative_proof),
                        ] = <[ProblemCertificate; 2]>::try_from(children).ok()?
                        else {
                            return None;
                        };
                        if source_proof.status() != &Status::Terminating
                            || administrative_proof.status() != &Status::Terminating
                        {
                            return None;
                        }
                        Some(ProblemCertificate::Trs(Proof::terminating(vec![
                            ProofStep::Gm04InverseContextSensitiveFull {
                                source_csr: inverse.csr.clone(),
                                source_signature: inverse.source_signature.clone(),
                                source_replacement_map: inverse.source_replacement_map.clone(),
                                active_symbol: inverse.active_symbol.clone(),
                                mark_symbol: inverse.mark_symbol.clone(),
                                proper_symbol: inverse.proper_symbol.clone(),
                                ok_symbol: inverse.ok_symbol.clone(),
                                top_symbol: inverse.top_symbol.clone(),
                                top_sharp_symbol: crate::core::Symbol::new(format!(
                                    "{}#",
                                    inverse.top_symbol.as_str()
                                )),
                                administrative_rules: inverse.residual_rules.clone(),
                                // Kept in the CPF syntax for backward compatibility;
                                // the direct theorem no longer assumes confluence.
                                wcr_depth: 0,
                                administrative_proof: Box::new(administrative_proof),
                                source_proof: Box::new(source_proof),
                            },
                        ])))
                    },
                ));
            } else {
                let child = ProblemState::Csr(CsrProblemState::root(inverse.csr.clone()));
                return ProcessorResult::Applied(ProcessorApplication::new(
                    vec![child],
                    move |children| {
                        let [ProblemCertificate::Trs(source_proof)] =
                            <[ProblemCertificate; 1]>::try_from(children).ok()?
                        else {
                            return None;
                        };
                        if source_proof.status() != &Status::Nonterminating {
                            return None;
                        }
                        Some(ProblemCertificate::Trs(Proof::with_status(
                            Status::Nonterminating,
                            vec![ProofStep::Gm04InverseContextSensitiveNontermination {
                                source_csr: inverse.csr.clone(),
                                source_signature: inverse.source_signature.clone(),
                                source_replacement_map: inverse.source_replacement_map.clone(),
                                active_symbol: inverse.active_symbol.clone(),
                                mark_symbol: inverse.mark_symbol.clone(),
                                proper_symbol: inverse.proper_symbol.clone(),
                                ok_symbol: inverse.ok_symbol.clone(),
                                top_symbol: inverse.top_symbol.clone(),
                                source_proof: Box::new(source_proof),
                            }],
                        )))
                    },
                ));
            }
        }
        if self.full_termination && trs.strategy() != crate::core::RewriteStrategy::Full {
            return ProcessorResult::Inapplicable;
        }
        if !matches!(
            trs.strategy(),
            crate::core::RewriteStrategy::Full | crate::core::RewriteStrategy::Innermost
        ) {
            return ProcessorResult::Inapplicable;
        }
        let top_sharp = crate::core::Symbol::new(format!("{}#", inverse.top_symbol.as_str()));
        let variable = crate::core::Term::var("__gm04_x");
        let wrap = |outer: &crate::core::Symbol, inner: &crate::core::Symbol| {
            crate::core::Term::app(
                outer.as_str(),
                vec![crate::core::Term::app(
                    inner.as_str(),
                    vec![variable.clone()],
                )],
            )
        };
        let residual_pairs = vec![
            crate::core::RewriteRule::new(
                wrap(&top_sharp, &inverse.ok_symbol),
                wrap(&top_sharp, &inverse.active_symbol),
            ),
            crate::core::RewriteRule::new(
                wrap(&top_sharp, &inverse.mark_symbol),
                wrap(&top_sharp, &inverse.proper_symbol),
            ),
        ];
        let residual_rules = inverse.residual_rules.clone();
        let residual_q = if trs.strategy() == crate::core::RewriteStrategy::Innermost {
            residual_rules
                .iter()
                .map(|rule| rule.lhs().clone())
                .collect::<Vec<_>>()
        } else {
            Vec::new()
        };
        let transformed_pairs = dependency_pairs(trs);
        let mut symbols = std::collections::BTreeSet::new();
        fn collect_symbols(
            term: &crate::core::Term,
            symbols: &mut std::collections::BTreeSet<String>,
        ) {
            if let crate::core::Term::App { symbol, args } = term {
                symbols.insert(symbol.as_str().to_owned());
                for argument in args {
                    collect_symbols(argument, symbols);
                }
            }
        }
        for pair in &transformed_pairs {
            collect_symbols(pair.lhs(), &mut symbols);
            collect_symbols(pair.rhs(), &mut symbols);
        }
        for rule in trs.rules() {
            collect_symbols(rule.lhs(), &mut symbols);
            collect_symbols(rule.rhs(), &mut symbols);
        }
        let mut options = self.options.clone();
        options.gm04_residual = Some(Gm04ResidualContext {
            pairs: residual_pairs,
            rules: residual_rules.clone(),
            q: residual_q.clone(),
            top_sharp: top_sharp.clone(),
            active: inverse.active_symbol.clone(),
            proper: inverse.proper_symbol.clone(),
            ok: inverse.ok_symbol.clone(),
            mark: inverse.mark_symbol.clone(),
            top: inverse.top_symbol.clone(),
            symbols: symbols.into_iter().collect(),
            graph_decomposed: false,
        });
        let dp_state = DpProblemState::ordinary(trs.clone(), transformed_pairs, options);
        let reconstruction_state = dp_state.clone();
        let residuals = vec![
            ProblemState::Csr(CsrProblemState::root(inverse.csr.clone())),
            ProblemState::DependencyPairs(dp_state),
        ];
        ProcessorResult::Applied(ProcessorApplication::new(
            residuals,
            move |mut children: Vec<ProblemCertificate>| {
                let [
                    ProblemCertificate::Trs(source_proof),
                    ProblemCertificate::DependencyPairTree(tree),
                ] = children.as_mut_slice()
                else {
                    return None;
                };
                if source_proof.status() != &Status::Terminating {
                    return None;
                }
                let transformed_dp = reconstruct_dependency_pair_proof(
                    &reconstruction_state,
                    std::mem::replace(tree, crate::proving::DpProofTree::Empty),
                );
                let transformed_proof = Proof::terminating(vec![ProofStep::DependencyPairProof {
                    proof: Box::new(transformed_dp),
                }]);
                Some(ProblemCertificate::Trs(Proof::terminating(vec![
                    ProofStep::Gm04InverseContextSensitive {
                        source_csr: inverse.csr.clone(),
                        source_signature: inverse.source_signature.clone(),
                        source_replacement_map: inverse.source_replacement_map.clone(),
                        active_symbol: inverse.active_symbol.clone(),
                        mark_symbol: inverse.mark_symbol.clone(),
                        proper_symbol: inverse.proper_symbol.clone(),
                        ok_symbol: inverse.ok_symbol.clone(),
                        top_symbol: inverse.top_symbol.clone(),
                        top_sharp_symbol: top_sharp.clone(),
                        transformed_proof: Box::new(transformed_proof),
                        source_proof: Box::new(source_proof.clone()),
                    },
                ])))
            },
        ))
    }
}
