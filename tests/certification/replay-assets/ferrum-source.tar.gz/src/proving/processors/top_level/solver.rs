use serde_json::json;
use sha2::{Digest, Sha256};
use std::collections::HashSet;
use std::thread;
use std::time::{Duration, Instant};

use crate::proving::engine::{
    ProveOptions, ProveStrategy, ProveStrategyProcessor, evaluate_csr_prove_strategy_condition,
    evaluate_prove_strategy_condition, worklist_guidance_strategy_for_csr,
    worklist_guidance_strategy_for_relative, worklist_guidance_strategy_for_trs,
};
use crate::proving::nontermination::NonterminationStrategy;
use crate::proving::processors::relative_adp::{
    RelativeAdpDependencyGraphProcessor, RelativeAdpDerelatificationProcessor,
    RelativeAdpErasureReductionPairProcessor, RelativeAdpPolynomialProcessor,
    serialize_relative_adp_state,
};
use crate::proving::processors::{
    LazyProcessorAttempt, ProblemCertificate, ProblemState, ProcessorResult, WorklistFailure,
    WorklistProcessor, solve_worklist_lazy_until,
};
use crate::proving::runtime::{
    processor_event_context_or_problem_name, processor_event_log_enabled,
    processor_event_raw_input, write_processor_event,
};

use super::{ConfiguredTopLevelProcessor, EmptySystemProcessor};

pub(crate) fn solve_top_level_worklist(
    initial: ProblemState,
    options: &ProveOptions,
    deadline: Option<Instant>,
) -> Result<ProblemCertificate, WorklistFailure> {
    let [certificate] = <[ProblemCertificate; 1]>::try_from(solve_worklist_lazy_until(
        vec![initial],
        || deadline.is_some_and(|deadline| Instant::now() >= deadline),
        // A task's cursor already advances past failed alternatives, and
        // canonical cycle keys guard successful transformations.  A second
        // global cache of negative attempts therefore only saves occasional
        // sibling retries.  Its old implementation serialized and hashed the
        // complete mathematical state before *every* attempt; on the large
        // Kaliszyk systems that repeated 100 MiB CPF serialization dominated
        // the entire competition allowance before a 4 ms loop processor ran.
        |state, cursor, is_root| next_scheduled_result(state, cursor, options, deadline, is_root),
    )?)
    .expect("one top-level root must produce one certificate");
    Ok(certificate)
}

fn next_scheduled_result(
    state: &ProblemState,
    cursor: usize,
    options: &ProveOptions,
    deadline: Option<Instant>,
    is_root: bool,
) -> Option<LazyProcessorAttempt> {
    if matches!(state, ProblemState::DependencyPairs(_)) {
        return crate::proving::processors::dp::next_scheduled_result(state, cursor, deadline);
    }
    if cursor == 0 {
        let started = Instant::now();
        let result = EmptySystemProcessor.apply(state);
        record_top_level_attempt(state, "empty", started.elapsed(), &result);
        return Some(LazyProcessorAttempt::required(result, 1));
    }
    if matches!(state, ProblemState::RelativeAnnotatedDependencyPairs(_)) {
        let strict = std::env::var_os("FERRUM_DP_LLM_NO_FALLBACK").is_some()
            && options.utility_guidance.is_some();
        let ProblemState::RelativeAnnotatedDependencyPairs(adp) = state else {
            unreachable!()
        };
        let serialized = serialize_relative_adp_state(adp);
        let guided = options
            .utility_guidance
            .as_ref()
            .and_then(|lookup| lookup.predict(&serialized));
        let atoms = guided
            .map(|prediction| {
                prediction
                    .solved
                    .into_iter()
                    .chain(prediction.transformed_strong)
                    .chain(prediction.transformed_weak)
                    .filter(|atom| {
                        matches!(
                            atom.as_str(),
                            "relative-adp-graph"
                                | "relative-adp-erasure-reduction-pair"
                                | "relative-adp-polynomial"
                                | "relative-adp-derelatification"
                        )
                    })
                    .collect::<Vec<_>>()
            })
            .filter(|atoms| !atoms.is_empty())
            .or_else(|| {
                (!strict).then(|| {
                    vec![
                        "relative-adp-graph".to_owned(),
                        "relative-adp-erasure-reduction-pair".to_owned(),
                        "relative-adp-polynomial".to_owned(),
                        "relative-adp-derelatification".to_owned(),
                    ]
                })
            })?;
        let atom = atoms.get(cursor - 1)?;
        let started = Instant::now();
        let result = match atom.as_str() {
            "relative-adp-graph" => RelativeAdpDependencyGraphProcessor.apply(state),
            "relative-adp-erasure-reduction-pair" => RelativeAdpErasureReductionPairProcessor {
                options: options.dp_options.clone(),
                deadline,
            }
            .apply(state),
            "relative-adp-polynomial" => RelativeAdpPolynomialProcessor {
                options: options.dp_options.clone(),
                deadline,
            }
            .apply(state),
            "relative-adp-derelatification" => RelativeAdpDerelatificationProcessor {
                options: options.dp_options.clone(),
            }
            .apply(state),
            _ => unreachable!(),
        };
        record_top_level_attempt(state, atom, started.elapsed(), &result);
        return Some(
            LazyProcessorAttempt::alternative(result, cursor + 1)
                .with_cycle_key(format!("relative-adp:{state:?}:{atom}")),
        );
    }
    let strict_guidance = std::env::var_os("FERRUM_DP_LLM_NO_FALLBACK").is_some()
        && options.utility_guidance.is_some();
    let guided = match state {
        ProblemState::Trs(trs) | ProblemState::Srs(trs) => {
            worklist_guidance_strategy_for_trs(trs, options)
        }
        ProblemState::Csr(state) => worklist_guidance_strategy_for_csr(state, options),
        ProblemState::RelativeTrs(relative) | ProblemState::RelativeSrs(relative) => {
            worklist_guidance_strategy_for_relative(relative, options)
        }
        _ => None,
    };
    if cursor == 1 && std::env::var_os("FERRUM_WORKLIST_TRACE").is_some() {
        let (kind, input) = match state {
            ProblemState::Trs(trs) => ("trs", crate::cert::write_trs_input_cpf3(trs)),
            ProblemState::Srs(trs) => ("srs", crate::cert::write_trs_input_cpf3(trs)),
            ProblemState::Csr(state) => (
                "csr",
                crate::cert::write_csr_state_input_cpf4(&state.csr, state.boundary),
            ),
            ProblemState::RelativeTrs(relative) => (
                "relative-trs",
                crate::cert::write_relative_trs_input_cpf3(relative),
            ),
            ProblemState::RelativeSrs(relative) => (
                "relative-srs",
                crate::cert::write_relative_trs_input_cpf3(relative),
            ),
            _ => ("other", String::new()),
        };
        let key = format!("{:x}", Sha256::digest(input.trim().as_bytes()));
        let guidance_summary = guided.as_ref().map(|strategy| {
            let rendered = format!("{strategy:?}");
            let prefix = rendered.chars().take(240).collect::<String>();
            if prefix.len() < rendered.len() {
                format!("{prefix}... ({} bytes)", rendered.len())
            } else {
                rendered
            }
        });
        eprintln!("worklist kind={kind} key={key} guidance={guidance_summary:?}");
    }
    let has_guidance = guided.is_some();
    let scheduling_started = Instant::now();
    let strategies = ordered_top_level_strategies(guided, options, is_root, strict_guidance);
    if strategies.is_empty() {
        return None;
    }
    let mut scheduled = Vec::new();
    for strategy in &strategies {
        flatten_strategy(strategy, state, None, Duration::ZERO, None, &mut scheduled);
    }
    if std::env::var_os("FERRUM_TIMING_TRACE").is_some() {
        eprintln!(
            "top-level scheduling elapsed_ms={} strategies={} atoms={}",
            scheduling_started.elapsed().as_millis(),
            strategies.len(),
            scheduled.len()
        );
    }
    if is_root && options.llm_first {
        let mut proposed = options
            .llm_proposals
            .iter()
            .filter_map(|proposal| match proposal {
                crate::llm::LlmProposal::LinearPolynomial { interpretations } => {
                    Some(ScheduledProcessor {
                        processor: ProveStrategyProcessor::ExactLinearPolynomial {
                            interpretation: interpretations
                                .iter()
                                .map(|(symbol, interpretation)| {
                                    (
                                        symbol.clone(),
                                        interpretation.constant,
                                        interpretation.coefficients.clone(),
                                    )
                                })
                                .collect(),
                        },
                        timeout: None,
                        delay: Duration::ZERO,
                        continuation: None,
                    })
                }
                _ => None,
            })
            .collect::<Vec<_>>();
        proposed.append(&mut scheduled);
        scheduled = proposed;
    }
    let mut seen = HashSet::new();
    let scheduled = scheduled
        .into_iter()
        // `switch-csr` has no sound transformation certificate.  In particular,
        // serializing its CSR child as the root input certifies a different
        // rewrite relation.  Keep the atom parseable for old strategies and
        // oracles, but never schedule it until a compositional checker theorem
        // relates the original TRS to the recognized CSR obligation.
        .filter(|candidate| processor_is_certifiably_schedulable(&candidate.processor, is_root))
        .filter(|candidate| seen.insert(format!("{candidate:?}")))
        .collect::<Vec<_>>();
    let mut scheduled = scheduled;
    let polynomial_rule_count = match state {
        ProblemState::Trs(trs) | ProblemState::Srs(trs) => trs.rules().len(),
        ProblemState::RelativeTrs(relative) | ProblemState::RelativeSrs(relative) => {
            relative.union().rules().len()
        }
        ProblemState::Csr(state) => state.csr.rules().len(),
        _ => 0,
    };
    if polynomial_rule_count > 0 {
        let mut alternatives = Vec::new();
        for candidate in &scheduled {
            let ProveStrategyProcessor::LinearPolynomial {
                max_constant,
                max_coefficient,
                max_symbols,
                max_arity,
            } = &candidate.processor
            else {
                continue;
            };
            alternatives.extend((1..=polynomial_rule_count).map(|candidate_index| {
                ScheduledProcessor {
                    processor: ProveStrategyProcessor::SelectedLinearPolynomial {
                        max_constant: *max_constant,
                        max_coefficient: *max_coefficient,
                        max_symbols: *max_symbols,
                        max_arity: *max_arity,
                        candidate_index,
                    },
                    timeout: candidate.timeout,
                    delay: candidate.delay,
                    continuation: candidate.continuation.clone(),
                }
            }));
        }
        scheduled.extend(alternatives);
    }
    if !has_guidance {
        scheduled.sort_by_key(|candidate| {
            (
                candidate.delay,
                candidate.timeout.unwrap_or(Duration::from_secs(u64::MAX)),
            )
        });
    }
    if cursor > scheduled.len() && options.utility_guidance.is_some()
        && let ProblemState::Trs(trs) | ProblemState::Srs(trs) = state
        && let Some(canonical) = crate::proving::engine::worklist_canonical_guidance_for_trs(trs, options)
    {
        let mut alternatives = Vec::new();
        flatten_strategy(&canonical, state, None, Duration::ZERO, None, &mut alternatives);
        let mut known = scheduled.iter().map(|candidate| candidate.processor.to_strategy_atom()).collect::<HashSet<_>>();
        scheduled.extend(alternatives.into_iter().filter(|candidate|
            processor_is_certifiably_schedulable(&candidate.processor, is_root)
                && known.insert(candidate.processor.to_strategy_atom())));
    }
    let candidate = scheduled.get(cursor - 1)?;
    if std::env::var_os("FERRUM_WORKLIST_TRACE").is_some() {
        eprintln!("worklist cursor={cursor} candidate={candidate:?}");
    }
    if !wait_for_delay(candidate.delay, deadline) {
        return Some(LazyProcessorAttempt::alternative(
            ProcessorResult::TimedOut,
            cursor + 1,
        ));
    }
    let processor_deadline = candidate
        .timeout
        .map(|duration| {
            let local = Instant::now() + duration;
            deadline.map_or(local, |outer| outer.min(local))
        })
        .or(deadline);
    let atom = candidate.processor.to_strategy_atom();
    if std::env::var_os("FERRUM_TIMING_TRACE").is_some() {
        eprintln!("top-level applying atom={}", atom);
    }
    let started = Instant::now();
    let mut atomic_result = ConfiguredTopLevelProcessor {
        processor: &candidate.processor,
        options,
        deadline: processor_deadline,
    }
    .apply(state);
    let state_local_only = super::super::state_local_only() && options.utility_guidance.is_some();
    if let ProcessorResult::Applied(application) = &mut atomic_result {
        for residual in &mut application.residuals {
            super::super::clear_oracle_child_strategy(residual, state_local_only);
        }
    }
    if std::env::var_os("FERRUM_TIMING_TRACE").is_some() {
        eprintln!(
            "top-level applied atom={} elapsed_ms={}",
            atom,
            started.elapsed().as_millis()
        );
    }
    // A timeout attached to one atomic transformation bounds construction of
    // that transformation, not the independently scheduled proof of its
    // residuals.  In particular, oracle guidance represents `exact-dp` as an
    // atom: carrying its local budget into the DP child used to make a long
    // certified chain expire just as its final SCCs were materialized.  A
    // syntactic continuation is different: it belongs to the same scoped
    // strategy expression and `apply_scoped_continuation` receives the local
    // deadline below.
    record_top_level_attempt(state, &atom, started.elapsed(), &atomic_result);
    let result = match (&candidate.continuation, atomic_result) {
        (Some(continuation), ProcessorResult::Applied(application)) if !state_local_only => {
            apply_scoped_continuation(application, continuation, options, processor_deadline)
        }
        (_, result) => result,
    };
    let mut attempt = LazyProcessorAttempt::alternative(result, cursor + 1);
    if matches!(
        &attempt.result,
        ProcessorResult::Applied(application) if !application.residuals.is_empty()
    ) {
        // Cycle identity must follow the same canonical mathematical state
        // used by oracle lookup and event addressing. `Debug` includes
        // irrelevant implementation data such as unused fresh variables; a
        // processor could therefore return the same CPF state forever while
        // appearing different to the worklist (relative flat-context closure
        // exposed this on complete transformed-CSR systems). The stable atom
        // deliberately ignores delay and timeout wrappers as well.
        //
        // Failed attempts and terminal proofs cannot create a cycle. Hashing
        // them used to serialize multi-megabyte TPDB systems after a proof was
        // already complete, turning millisecond loop witnesses into root
        // timeouts without adding any scheduler protection.
        let canonical_state = serialized_problem_state(state)
            .map(|(_, _, input)| format!("{:x}", Sha256::digest(input.trim().as_bytes())))
            .unwrap_or_else(|| format!("{state:?}"));
        attempt = attempt.with_cycle_key(format!("top-level:{canonical_state}:{atom}"));
    }
    Some(attempt)
}

fn processor_is_certifiably_schedulable(
    processor: &ProveStrategyProcessor,
    _is_root: bool,
) -> bool {
    !matches!(processor, ProveStrategyProcessor::SwitchContextSensitive)
}

fn ordered_top_level_strategies(
    guided: Option<ProveStrategy>,
    options: &ProveOptions,
    is_root: bool,
    strict_guidance: bool,
) -> Vec<ProveStrategy> {
    let default_strategy = ProveStrategy::default_from_file();
    // Competition and campaign harnesses normally express their wall-clock
    // ceiling as `timeout(..., default)`.  The timeout is an execution bound,
    // not a user-authored proof recipe: treating the wrapper as an explicit
    // strategy made the complete default portfolio run before oracle advice.
    // Besides defeating oracle-only replay, this made results depend heavily
    // on parallel load.  Strip only transparent timeout wrappers here; a
    // timeout around any genuinely different strategy remains explicit.
    let strategy_is_default = |strategy: &ProveStrategy| {
        let mut strategy = strategy;
        while let ProveStrategy::Timeout {
            strategy: inner, ..
        } = strategy
        {
            strategy = inner;
        }
        strategy == &default_strategy
    };
    // Campaigns use `timeout(..., fail)` as an explicit assertion that no
    // top-level fallback may run.  `fail` is therefore a scheduling sentinel,
    // not a user-authored proof recipe: putting it before oracle guidance
    // makes every strict replay fail before consulting the oracle.
    let strategy_is_fail = |strategy: &ProveStrategy| {
        let mut strategy = strategy;
        while let ProveStrategy::Timeout {
            strategy: inner, ..
        } = strategy
        {
            strategy = inner;
        }
        matches!(
            strategy,
            ProveStrategy::Processor(ProveStrategyProcessor::Fail)
        )
    };
    let explicit_root_strategy =
        is_root && !strategy_is_default(&options.strategy) && !strategy_is_fail(&options.strategy);
    let mut strategies = Vec::new();
    // A caller-supplied root sequence is an executable proof recipe, not a
    // fallback portfolio. Run it before state-local advice so an identical
    // guided first atom cannot discard the recipe's continuation. The
    // checked-in default remains guidance-first, including in strict
    // oracle-only runs.
    if explicit_root_strategy {
        strategies.push(options.strategy.clone());
    }
    strategies.extend(guided);
    if !strict_guidance && !explicit_root_strategy {
        strategies.push(if is_root {
            options.strategy.clone()
        } else {
            default_strategy
        });
    }
    strategies
}

pub(crate) fn serialized_problem_state(state: &ProblemState) -> Option<(&'static str, &'static str, String)> {
    match state {
        ProblemState::Trs(trs) => {
            Some(("top-level", "trs", crate::cert::write_trs_input_cpf3(trs)))
        }
        ProblemState::Srs(trs) => {
            Some(("top-level", "srs", crate::cert::write_trs_input_cpf3(trs)))
        }
        ProblemState::Csr(state) => Some((
            "top-level",
            "csr",
            crate::cert::write_csr_state_input_cpf4(&state.csr, state.boundary),
        )),
        ProblemState::RelativeTrs(relative) => Some((
            "top-level",
            "relative-trs",
            crate::cert::write_relative_trs_input_cpf3(relative),
        )),
        ProblemState::RelativeSrs(relative) => Some((
            "top-level",
            "relative-srs",
            crate::cert::write_relative_trs_input_cpf3(relative),
        )),
        ProblemState::DependencyPairs(problem) => Some((
            "dependency-pair",
            "dp",
            crate::proving::dependency_pairs::dp_state_input_cpf(problem),
        )),
        ProblemState::RelativeAnnotatedDependencyPairs(state) => Some((
            "relative-adp",
            "relative-adp",
            serialize_relative_adp_state(state),
        )),
    }
}

fn problem_state_name(state: &ProblemState) -> Option<&str> {
    match state {
        ProblemState::Trs(trs) | ProblemState::Srs(trs) => trs.name(),
        ProblemState::Csr(state) => state.csr.trs().name(),
        ProblemState::RelativeTrs(relative) | ProblemState::RelativeSrs(relative) => {
            relative.strict().name()
        }
        ProblemState::DependencyPairs(problem) => problem.trs.name(),
        ProblemState::RelativeAnnotatedDependencyPairs(state) => state.template.strict().name(),
    }
}

fn record_top_level_attempt(
    state: &ProblemState,
    atom: &str,
    elapsed: Duration,
    result: &ProcessorResult,
) {
    if !processor_event_log_enabled() {
        return;
    }
    let Some((level, kind, serialized)) = serialized_problem_state(state) else {
        return;
    };
    let format = if kind == "csr" {
        "cpf4"
    } else if kind == "relative-adp" {
        "ferrum-state-json"
    } else {
        "cpf3"
    };
    let input = processor_event_raw_input(serialized, format, true);
    let selected = match result {
        ProcessorResult::Applied(application) => application.selected_atom().unwrap_or(atom),
        _ => atom,
    };
    let (outcome, progress, residuals) = match result {
        ProcessorResult::Applied(application) if application.residuals.is_empty() => {
            ("solved", "proof", Vec::new())
        }
        ProcessorResult::Applied(application) => {
            let residuals = application
                .residuals
                .iter()
                .filter_map(|residual| {
                    let (_, kind, serialized) = serialized_problem_state(residual)?;
                    let key = format!("{:x}", Sha256::digest(serialized.trim().as_bytes()));
                    Some(json!({"problem_key": key, "problem_kind": kind, "cpf": serialized}))
                })
                .collect();
            ("transformed", "strong", residuals)
        }
        ProcessorResult::Inapplicable | ProcessorResult::Failed { .. } => {
            ("failed", "none", Vec::new())
        }
        ProcessorResult::TimedOut => ("timeout", "none", Vec::new()),
    };
    let context = processor_event_context_or_problem_name(problem_state_name(state));
    let failure_reason = match result {
        ProcessorResult::Failed { reason } => Some(reason.as_str()),
        ProcessorResult::Inapplicable => Some("inapplicable"),
        ProcessorResult::TimedOut => Some("timeout"),
        ProcessorResult::Applied(_) => None,
    };
    write_processor_event(&json!({
        "schema": "ferrum.processor-event.v1",
        "run_id": context.as_ref().map(|context| context.run_id.as_str()),
        "problem_id": context.as_ref().map(|context| context.problem_id.as_str()),
        "category": context.as_ref().and_then(|context| context.category.as_deref()),
        "level": level,
        "problem_kind": kind,
        "processor": selected,
        "strategy_atom": selected,
        "search_atom": atom,
        "outcome": outcome,
        "progress": progress,
        "failure_reason": failure_reason,
        "elapsed_ms": elapsed.as_millis(),
        "input": input,
        "metrics": { "residuals": residuals.len() },
        "witness": { "kind": "problem_states", "residuals": residuals },
        "credit": { "status": "pending" },
    }));
}

#[derive(Clone, Debug, Eq, PartialEq)]
struct ScheduledProcessor {
    processor: ProveStrategyProcessor,
    timeout: Option<Duration>,
    delay: Duration,
    continuation: Option<Box<ProveStrategy>>,
}

fn apply_scoped_continuation(
    application: super::super::ProcessorApplication,
    continuation: &ProveStrategy,
    options: &ProveOptions,
    deadline: Option<Instant>,
) -> ProcessorResult {
    let (residuals, selected_atom, reconstruction) = application.into_parts_with_selected_atom();
    if residuals.is_empty() {
        return ProcessorResult::Applied(super::super::ProcessorApplication::new(
            Vec::new(),
            move |children| reconstruction.reconstruct(children),
        ));
    }

    let mut child_options = options.clone();
    child_options.strategy = continuation.clone();
    // A sequence is an explicit continuation. State-local oracle guidance is
    // still used whenever no tail is present, but it must not replace the
    // strategy-file tail on this residual.
    child_options.utility_guidance = None;
    child_options.llm_first = false;
    let mut children = Vec::with_capacity(residuals.len());
    for residual in residuals {
        let certificate = match solve_top_level_worklist(residual, &child_options, deadline) {
            Ok(certificate) => certificate,
            Err(failure) => {
                return ProcessorResult::Failed {
                    reason: format!("explicit strategy continuation failed: {failure}"),
                };
            }
        };
        children.push(certificate);
    }
    let Some(certificate) = reconstruction.reconstruct(children) else {
        return ProcessorResult::Failed {
            reason: "explicit strategy continuation produced incompatible certificates".to_string(),
        };
    };
    let mut solved = super::super::ProcessorApplication::solved(certificate);
    if let Some(atom) = selected_atom {
        solved = solved.with_selected_atom(atom);
    }
    ProcessorResult::Applied(solved)
}

fn flatten_strategy(
    strategy: &ProveStrategy,
    state: &ProblemState,
    timeout: Option<Duration>,
    delay: Duration,
    continuation: Option<Box<ProveStrategy>>,
    output: &mut Vec<ScheduledProcessor>,
) {
    match strategy {
        ProveStrategy::Processor(ProveStrategyProcessor::NonterminationSearch) => {
            let strategy = NonterminationStrategy::default_for(problem_state_strategy(state));
            flatten_nontermination_strategy(&strategy, timeout, delay, continuation, output);
        }
        ProveStrategy::Processor(processor) => output.push(ScheduledProcessor {
            processor: processor.clone(),
            timeout,
            delay,
            continuation,
        }),
        ProveStrategy::Sequence(strategies) => {
            let Some((first, tail)) = strategies.split_first() else {
                return;
            };
            let continuation = compose_continuation(tail, continuation);
            flatten_strategy(first, state, timeout, delay, continuation, output);
        }
        ProveStrategy::Choice(strategies) | ProveStrategy::Parallel(strategies) => {
            for strategy in strategies {
                flatten_strategy(
                    strategy,
                    state,
                    timeout,
                    delay,
                    continuation.clone(),
                    output,
                );
            }
        }
        ProveStrategy::Timeout { duration, strategy } => {
            flatten_strategy(
                strategy,
                state,
                Some(timeout.map_or(*duration, |outer| outer.min(*duration))),
                delay,
                continuation,
                output,
            );
        }
        ProveStrategy::Delay { duration, strategy } => {
            flatten_strategy(
                strategy,
                state,
                timeout,
                delay.saturating_add(*duration),
                continuation,
                output,
            );
        }
        ProveStrategy::Conditional {
            condition,
            then_strategy,
            else_strategy,
        } => {
            let selected = if evaluate_condition(condition, state) {
                then_strategy
            } else {
                else_strategy
            };
            flatten_strategy(selected, state, timeout, delay, continuation, output);
        }
    }
}

fn compose_continuation(
    tail: &[ProveStrategy],
    continuation: Option<Box<ProveStrategy>>,
) -> Option<Box<ProveStrategy>> {
    let mut steps = tail.to_vec();
    if let Some(continuation) = continuation {
        match *continuation {
            ProveStrategy::Sequence(mut following) => steps.append(&mut following),
            following => steps.push(following),
        }
    }
    match steps.len() {
        0 => None,
        1 => steps.pop().map(Box::new),
        _ => Some(Box::new(ProveStrategy::Sequence(steps))),
    }
}

fn flatten_nontermination_strategy(
    strategy: &NonterminationStrategy,
    timeout: Option<Duration>,
    delay: Duration,
    continuation: Option<Box<ProveStrategy>>,
    output: &mut Vec<ScheduledProcessor>,
) {
    match strategy {
        NonterminationStrategy::Processor(processor) => output.push(ScheduledProcessor {
            processor: ProveStrategyProcessor::Nontermination(processor.clone()),
            timeout,
            delay,
            continuation,
        }),
        NonterminationStrategy::Sequence(strategies)
        | NonterminationStrategy::Choice(strategies) => {
            for strategy in strategies {
                flatten_nontermination_strategy(
                    strategy,
                    timeout,
                    delay,
                    continuation.clone(),
                    output,
                );
            }
        }
        NonterminationStrategy::Repeat {
            max_iterations,
            strategy,
        } => {
            for _ in 0..*max_iterations {
                flatten_nontermination_strategy(
                    strategy,
                    timeout,
                    delay,
                    continuation.clone(),
                    output,
                );
            }
        }
        NonterminationStrategy::Timeout { duration, strategy } => {
            flatten_nontermination_strategy(
                strategy,
                Some(timeout.map_or(*duration, |outer| outer.min(*duration))),
                delay,
                continuation,
                output,
            );
        }
    }
}

fn problem_state_strategy(state: &ProblemState) -> crate::core::RewriteStrategy {
    match state {
        ProblemState::Trs(trs) | ProblemState::Srs(trs) => trs.strategy(),
        ProblemState::Csr(state) => state.csr.trs().strategy(),
        ProblemState::RelativeTrs(relative) | ProblemState::RelativeSrs(relative) => {
            relative.strict().strategy()
        }
        ProblemState::DependencyPairs(problem) => problem.trs.strategy(),
        ProblemState::RelativeAnnotatedDependencyPairs(_) => crate::core::RewriteStrategy::Full,
    }
}

fn evaluate_condition(
    condition: &crate::proving::engine::ProveStrategyCondition,
    state: &ProblemState,
) -> bool {
    use crate::proving::engine::ProveStrategyCondition;

    match condition {
        ProveStrategyCondition::Not(inner) => return !evaluate_condition(inner, state),
        ProveStrategyCondition::All(conditions) => {
            return conditions
                .iter()
                .all(|condition| evaluate_condition(condition, state));
        }
        ProveStrategyCondition::Any(conditions) => {
            return conditions
                .iter()
                .any(|condition| evaluate_condition(condition, state));
        }
        _ => {}
    }
    match state {
        ProblemState::RelativeTrs(_) | ProblemState::RelativeSrs(_)
            if matches!(condition, ProveStrategyCondition::Relative) =>
        {
            true
        }
        ProblemState::Csr(state) => evaluate_csr_prove_strategy_condition(condition, &state.csr),
        ProblemState::Trs(trs) | ProblemState::Srs(trs) => {
            evaluate_prove_strategy_condition(condition, trs)
        }
        ProblemState::RelativeTrs(relative) | ProblemState::RelativeSrs(relative) => {
            evaluate_prove_strategy_condition(condition, relative.strict())
        }
        _ => false,
    }
}

fn wait_for_delay(delay: Duration, deadline: Option<Instant>) -> bool {
    if delay.is_zero() {
        return deadline.is_none_or(|limit| Instant::now() < limit);
    }
    let wake = Instant::now() + delay;
    loop {
        let now = Instant::now();
        if deadline.is_some_and(|limit| now >= limit) {
            return false;
        }
        if now >= wake {
            return true;
        }
        thread::sleep(
            wake.saturating_duration_since(now)
                .min(Duration::from_millis(10)),
        );
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn exhausted_raw_order_reaches_canonical_source_bound_order() {
        let trs = Trs::new(None, Default::default(), vec![RewriteRule::new(
            Term::app("live_f", vec![Term::var("x")]), Term::app("live_g", vec![Term::var("x")]))]);
        let source = Trs::new(None, Default::default(), vec![RewriteRule::new(
            Term::app("old_f", vec![Term::var("x")]), Term::app("old_g", vec![Term::var("x")]))]);
        let stale = ProveStrategyProcessor::ExactLinearPolynomial {
            interpretation: vec![("old_f".into(), 1, vec![1]), ("old_g".into(), 0, vec![1])],
        }.to_strategy_atom();
        let bound = ProveStrategyProcessor::ExactSourceBoundOrder {
            source_trs_input_xml: crate::cert::write_trs_input_cpf3(&source),
            order_atom: ProveStrategyProcessor::ExactLinearPolynomialRemoval {
                interpretation: vec![("old_f".into(), 1, vec![1]), ("old_g".into(), 0, vec![1])],
                removed_rule_indices: vec![0],
            }.to_strategy_atom(),
        }.to_strategy_atom();
        let raw = crate::cert::write_trs_input_cpf3(&trs);
        let (canonical, error) = crate::proving::engine::standardized_trs_input_cpf3(&trs);
        assert!(error.is_none());
        let row = |input: &str, atom: &str| serde_json::json!({
            "schema":"ferrum.utility-guidance.v2", "problem_key":format!("{:x}", Sha256::digest(input.trim().as_bytes())),
            "prefer":[{"candidate":atom,"status":"transformed_strong","utility_score":1.0,"best_elapsed_ms":1,
            "attempts":1,"solved_count":0,"transformed_count":1,"failed_count":0,"timeout_count":0,"certified_count":1}]
        }).to_string();
        let path = std::env::temp_dir().join(format!("ferrum-canonical-backtrack-{}.jsonl", std::process::id()));
        std::fs::write(&path, format!("{}\n{}\n", row(&raw, &stale), row(&canonical, &bound))).unwrap();
        let options = ProveOptions { utility_guidance: Some(crate::llm::UtilityGuidanceLookup::from_path(&path).unwrap()),
            strategy: ProveStrategy::parse("fail").unwrap(), ..ProveOptions::default() };
        std::fs::remove_file(path).unwrap();
        let result = solve_top_level_worklist(ProblemState::Trs(trs), &options, Some(Instant::now() + Duration::from_secs(5)));
        assert!(result.is_ok(), "{result:?}");
    }
    use crate::core::{RewriteRule, Term, Trs};
    use crate::proving::Status;

    #[test]
    fn switch_csr_is_unschedulable_until_cpf_is_compositional() {
        assert!(!processor_is_certifiably_schedulable(
            &ProveStrategyProcessor::SwitchContextSensitive,
            true,
        ));
        assert!(!processor_is_certifiably_schedulable(
            &ProveStrategyProcessor::SwitchContextSensitive,
            false,
        ));
        assert!(processor_is_certifiably_schedulable(
            &ProveStrategyProcessor::DependencyPairs,
            false,
        ));
    }

    #[test]
    fn relative_condition_matches_only_relative_states() {
        let trs = Trs::new(None, Default::default(), Vec::new());
        let relative = crate::core::RelativeTrs::new(trs.clone(), Vec::new());
        let condition = crate::proving::engine::ProveStrategyCondition::Relative;
        assert!(evaluate_condition(
            &condition,
            &ProblemState::RelativeTrs(relative)
        ));
        assert!(!evaluate_condition(&condition, &ProblemState::Trs(trs)));
        assert!(!evaluate_condition(
            &crate::proving::engine::ProveStrategyCondition::Not(Box::new(condition)),
            &ProblemState::RelativeTrs(crate::core::RelativeTrs::new(
                Trs::new(None, Default::default(), Vec::new()),
                Vec::new(),
            )),
        ));
    }

    #[test]
    fn polynomial_residual_is_closed_by_the_same_worklist() {
        let trs = Trs::new(
            None,
            Default::default(),
            vec![RewriteRule::new(
                Term::app("f", vec![Term::var("x")]),
                Term::var("x"),
            )],
        );
        let mut options = ProveOptions::default();
        options.strategy =
            ProveStrategy::Processor(ProveStrategyProcessor::ExactLinearPolynomial {
                interpretation: vec![("f".to_string(), 1, vec![1])],
            });
        let certificate = solve_top_level_worklist(ProblemState::Trs(trs), &options, None)
            .expect("exact rule removal and its empty residual must close");
        let ProblemCertificate::Trs(proof) = certificate else {
            panic!("expected a top-level proof")
        };
        assert_eq!(proof.status(), &Status::Terminating);
        assert!(matches!(
            proof.steps(),
            [crate::proving::ProofStep::PolynomialRuleRemoval { .. }]
        ));
    }

    #[test]
    fn explicit_sequence_runs_its_tail_on_the_transformed_residual() {
        let trs = Trs::new(
            None,
            Default::default(),
            vec![
                RewriteRule::new(
                    Term::app("f", vec![Term::var("x")]),
                    Term::app("g", vec![Term::var("x")]),
                ),
                RewriteRule::new(Term::app("g", vec![Term::var("x")]), Term::var("x")),
            ],
        );
        let exact = |interpretation| {
            ProveStrategy::Processor(ProveStrategyProcessor::ExactLinearPolynomial {
                interpretation,
            })
        };
        let mut options = ProveOptions::default();
        options.strategy = ProveStrategy::Sequence(vec![
            exact(vec![
                ("f".to_string(), 1, vec![1]),
                ("g".to_string(), 0, vec![1]),
            ]),
            exact(vec![("g".to_string(), 1, vec![1])]),
        ]);

        let certificate = solve_top_level_worklist(ProblemState::Trs(trs), &options, None)
            .expect("the second exact processor must run on the first residual");
        let ProblemCertificate::Trs(proof) = certificate else {
            panic!("expected a top-level proof")
        };
        let [crate::proving::ProofStep::PolynomialRuleRemoval { proof, .. }] = proof.steps() else {
            panic!("expected the first polynomial removal")
        };
        assert!(matches!(
            proof.steps(),
            [crate::proving::ProofStep::PolynomialRuleRemoval { .. }]
        ));
    }

    #[test]
    fn explicit_root_recipe_precedes_guidance_even_in_strict_mode() {
        let guided = ProveStrategy::Processor(ProveStrategyProcessor::Fail);
        let explicit =
            ProveStrategy::parse("poly(max-constant=1,max-coefficient=1);switch-innermost")
                .unwrap();
        let options = ProveOptions {
            strategy: explicit.clone(),
            ..ProveOptions::default()
        };

        assert_eq!(
            ordered_top_level_strategies(Some(guided.clone()), &options, true, true),
            vec![explicit, guided]
        );
    }

    #[test]
    fn timeout_wrapped_default_remains_guidance_first() {
        let guided = ProveStrategy::Processor(ProveStrategyProcessor::Fail);
        let options = ProveOptions {
            strategy: ProveStrategy::Timeout {
                duration: Duration::from_secs(60),
                strategy: Box::new(ProveStrategy::default_from_file()),
            },
            ..ProveOptions::default()
        };

        assert_eq!(
            ordered_top_level_strategies(Some(guided.clone()), &options, true, true),
            vec![guided]
        );
    }

    #[test]
    fn timeout_wrapped_fail_is_a_strict_replay_sentinel() {
        let guided = ProveStrategy::Processor(ProveStrategyProcessor::ExactLinearPolynomial {
            interpretation: vec![("f".to_owned(), 1, vec![1])],
        });
        let options = ProveOptions {
            strategy: ProveStrategy::Timeout {
                duration: Duration::from_secs(60),
                strategy: Box::new(ProveStrategy::Processor(ProveStrategyProcessor::Fail)),
            },
            ..ProveOptions::default()
        };

        assert_eq!(
            ordered_top_level_strategies(Some(guided.clone()), &options, true, true),
            vec![guided]
        );
    }
}
