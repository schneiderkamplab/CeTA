use std::time::Instant;

use super::automaton::prove_srs_by_match_bounds_completion_with_limits;
use crate::proving::{Proof, ProofStep};

use super::super::super::{
    ProblemCertificate, ProblemState, ProcessorApplication, ProcessorResult, WorklistProcessor,
};
pub struct SrsMatchBoundsProcessor {
    pub max_bound: usize,
    pub max_states: usize,
    pub max_transitions: usize,
    pub deadline: Option<Instant>,
}

impl WorklistProcessor for SrsMatchBoundsProcessor {
    fn name(&self) -> &'static str {
        "srs-match-bounds"
    }

    fn apply(&self, state: &ProblemState) -> ProcessorResult {
        // The completion routine also recognizes cons-encoded string rules
        // and lifts its automaton back to the original ranked TRS signature.
        // Keep that checked structural route reachable through the native atom.
        let trs = match state {
            ProblemState::Srs(trs) | ProblemState::Trs(trs) => trs,
            _ => return ProcessorResult::Inapplicable,
        };
        let proof = prove_srs_by_match_bounds_completion_with_limits(
            trs,
            self.max_bound,
            self.max_states,
            self.max_transitions,
            self.deadline,
        );
        let Some(bounds) = proof else {
            return if self.deadline.is_some_and(|limit| Instant::now() >= limit) {
                ProcessorResult::TimedOut
            } else {
                ProcessorResult::Inapplicable
            };
        };
        let proof = Proof::terminating(vec![ProofStep::Bounds { proof: bounds }]);
        ProcessorResult::Applied(ProcessorApplication::solved(ProblemCertificate::Trs(proof)))
    }
}
