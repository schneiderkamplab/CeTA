use std::time::Instant;

use crate::core::RelativeTrs;
use crate::proving::dependency_pairs::{
    MatrixDomain, MatrixInterpretation, checked_relative_matrix_rule_removal,
    synthesize_relative_integer_matrix_rule_removal, synthesize_relative_matrix_rule_removal,
};
use crate::proving::engine::{ProveOptions, ProveStrategyProcessor};
use crate::proving::{Proof, ProofStep, Status};

use super::super::{
    ProblemCertificate, ProblemState, ProcessorApplication, ProcessorResult, WorklistProcessor,
};

/// Ordinary natural/integer matrix rule removal.
///
/// Ordinary termination is the relative problem R / empty.  Reusing the
/// relative orientation checker keeps the model validation in one place,
/// while the returned residual remains an ordinary TRS/SRS worklist state.
pub struct MatrixRuleRemovalProcessor {
    pub options: ProveOptions,
    pub dimension: usize,
    pub max_constant: i64,
    pub max_coefficient: i64,
    pub min_value: i64,
    pub max_value: i64,
    pub max_symbols: Option<usize>,
    pub max_arity: Option<usize>,
    pub exact_interpretation: Option<Vec<(String, Vec<i64>, Vec<Vec<Vec<i64>>>)>>,
    pub domain: MatrixDomain,
    pub deadline: Option<Instant>,
}

impl WorklistProcessor for MatrixRuleRemovalProcessor {
    fn name(&self) -> &'static str {
        "matrix-rule-removal"
    }

    fn apply(&self, state: &ProblemState) -> ProcessorResult {
        let trs = match state {
            ProblemState::Trs(trs) | ProblemState::Srs(trs) => trs,
            _ => return ProcessorResult::Inapplicable,
        };
        let relative = RelativeTrs::new(trs.clone(), Vec::new());
        let removal = if let Some(witness) = self.exact_interpretation.as_ref() {
            let interpretations = witness
                .iter()
                .map(|(symbol, constant, coefficients)| {
                    (
                        symbol.clone(),
                        MatrixInterpretation {
                            constant: constant.clone(),
                            coefficients: coefficients.clone(),
                        },
                    )
                })
                .collect();
            checked_relative_matrix_rule_removal(&relative, interpretations, self.domain)
        } else {
            let mut options = self.options.dp_options.clone();
            options.max_polynomial_constant = self.max_constant;
            options.max_polynomial_coefficient = self.max_coefficient;
            if let Some(value) = self.max_symbols {
                options.max_polynomial_symbols = value;
            }
            if let Some(value) = self.max_arity {
                options.max_polynomial_arity = value;
            }
            match self.domain {
                MatrixDomain::Naturals => synthesize_relative_matrix_rule_removal(
                    &relative,
                    &options,
                    self.dimension,
                    self.deadline,
                ),
                MatrixDomain::Integers => synthesize_relative_integer_matrix_rule_removal(
                    &relative,
                    &options,
                    self.dimension,
                    self.min_value,
                    self.max_value,
                    self.deadline,
                ),
            }
        };
        let Some(removal) = removal else {
            return ProcessorResult::Inapplicable;
        };
        let remaining = removal.remaining.strict().clone();
        let residual = ProblemState::from_trs(remaining);
        let interpretations = removal.interpretations;
        let exact = interpretations
            .iter()
            .map(|(symbol, interpretation)| {
                (
                    symbol.clone(),
                    interpretation.constant.clone(),
                    interpretation.coefficients.clone(),
                )
            })
            .collect();
        let selected_atom = match removal.domain {
            MatrixDomain::Naturals => ProveStrategyProcessor::ExactMatrixInterpretation {
                interpretation: exact,
            },
            MatrixDomain::Integers => ProveStrategyProcessor::ExactIntegerMatrixInterpretation {
                interpretation: exact,
            },
        }
        .to_strategy_atom();
        let dimension = removal.dimension;
        let strict_dimension = removal.strict_dimension;
        let domain = removal.domain;
        let removed = removal.removed;
        ProcessorResult::Applied(
            ProcessorApplication::new(vec![residual], move |children| {
                let [ProblemCertificate::Trs(proof)] =
                    <[ProblemCertificate; 1]>::try_from(children).ok()?
                else {
                    return None;
                };
                if proof.status() != &Status::Terminating {
                    return None;
                }
                Some(ProblemCertificate::Trs(Proof::terminating(vec![
                    ProofStep::MatrixRuleRemoval {
                        interpretations: interpretations.clone(),
                        dimension,
                        strict_dimension,
                        domain,
                        removed: removed.clone(),
                        proof: Box::new(proof),
                    },
                ])))
            })
            .with_selected_atom(selected_atom),
        )
    }
}
