use crate::core::{RewriteRule, RewriteStrategy, Term, Trs, match_pattern};
use crate::proving::{Proof, ProofStep, Status};

use super::super::{
    ProblemCertificate, ProblemState, ProcessorApplication, ProcessorResult, WorklistProcessor,
};

pub struct RemoveNonApplicableRulesProcessor;

impl WorklistProcessor for RemoveNonApplicableRulesProcessor {
    fn name(&self) -> &'static str {
        "remove-non-applicable-rules"
    }

    fn apply(&self, state: &ProblemState) -> ProcessorResult {
        let trs = match state {
            ProblemState::Trs(trs) | ProblemState::Srs(trs) => trs,
            _ => return ProcessorResult::Inapplicable,
        };
        if trs.strategy() != RewriteStrategy::Innermost {
            return ProcessorResult::Inapplicable;
        }
        let Some((removed, remaining)) = remove_non_applicable_rules(trs) else {
            return ProcessorResult::Inapplicable;
        };
        let residual = ProblemState::from_trs(remaining);
        ProcessorResult::Applied(ProcessorApplication::new(vec![residual], move |children| {
            let [ProblemCertificate::Trs(proof)] =
                <[ProblemCertificate; 1]>::try_from(children).ok()?
            else {
                return None;
            };
            if proof.status() != &Status::Terminating {
                return None;
            }
            Some(ProblemCertificate::Trs(Proof::terminating(vec![
                ProofStep::RemoveNonApplicableRules {
                    removed: removed.clone(),
                    proof: Box::new(proof),
                },
            ])))
        }))
    }
}

pub fn remove_non_applicable_rules(trs: &Trs) -> Option<(Vec<RewriteRule>, Trs)> {
    let (removed, remaining): (Vec<_>, Vec<_>) = trs
        .rules()
        .iter()
        .cloned()
        .partition(|rule| is_non_applicable_innermost(rule, trs.rules()));
    if removed.is_empty() {
        return None;
    }
    Some((
        removed,
        Trs::new_with_strategy(
            trs.name().map(str::to_string),
            trs.variables().clone(),
            remaining,
            trs.strategy(),
        ),
    ))
}

fn is_non_applicable_innermost(rule: &RewriteRule, rules: &[RewriteRule]) -> bool {
    proper_non_variable_subterms(rule.lhs()).any(|subterm| {
        rules.iter().any(|candidate| {
            matches!(candidate.lhs(), Term::App { .. })
                && match_pattern(candidate.lhs(), subterm).is_some()
        })
    })
}

fn proper_non_variable_subterms(term: &Term) -> impl Iterator<Item = &Term> {
    let mut subterms = Vec::new();
    collect_proper_non_variable_subterms(term, &mut subterms);
    subterms.into_iter()
}

fn collect_proper_non_variable_subterms<'a>(term: &'a Term, subterms: &mut Vec<&'a Term>) {
    let Term::App { args, .. } = term else {
        return;
    };
    for arg in args {
        if matches!(arg, Term::App { .. }) {
            subterms.push(arg);
        }
        collect_proper_non_variable_subterms(arg, subterms);
    }
}
