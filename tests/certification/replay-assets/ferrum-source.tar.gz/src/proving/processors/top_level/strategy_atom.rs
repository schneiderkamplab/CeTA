use crate::proving::engine::ProveStrategyProcessor;
use crate::proving::processors::top_level::{SrsMatchAtBound, SrsRfcBarrenClosure};

fn hex_json(value: &impl serde::Serialize) -> String {
    serde_json::to_vec(value)
        .expect("strategy witnesses are JSON serializable")
        .into_iter()
        .map(|byte| format!("{byte:02x}"))
        .collect()
}

fn bounded(
    name: &str,
    constant: i64,
    coefficient: i64,
    symbols: Option<usize>,
    arity: Option<usize>,
) -> String {
    let mut args = vec![
        format!("max-constant={constant}"),
        format!("max-coefficient={coefficient}"),
    ];
    if let Some(value) = symbols {
        args.push(format!("max-symbols={value}"));
    }
    if let Some(value) = arity {
        args.push(format!("max-arity={value}"));
    }
    format!("{name}({})", args.join(","))
}

impl ProveStrategyProcessor {
    /// Canonical executable spelling of exactly this one processor.
    pub(crate) fn to_strategy_atom(&self) -> String {
        match self {
            Self::Fail => "fail".into(),
            Self::ExactNonterminationRuleRemoval { source_trs_input_xml, residual_trs_input_xml } => format!(
                "exact-trs-no-rule-removal(hex={})", hex_json(&(source_trs_input_xml, residual_trs_input_xml))
            ),
            Self::ExactNonterminationTerminal { source_trs_input_xml, terminal_xml } => format!(
                "exact-trs-nontermination-terminal(hex={})",
                hex_json(&(source_trs_input_xml, terminal_xml))
            ),
            Self::ExactTerminationProof {
                source_trs_input_xml,
                termination_proof_xml,
            } => format!(
                "exact-trs-proof(hex={})",
                hex_json(&(source_trs_input_xml, termination_proof_xml))
            ),
            Self::CertifiedLinearSequence(processors) => processors
                .iter()
                .map(Self::to_strategy_atom)
                .collect::<Vec<_>>()
                .join(";"),
            Self::NonterminationSearch => "nontermination".into(),
            Self::Nontermination(processor) => format!(
                "nontermination({})",
                crate::proving::NonterminationStrategy::Processor(processor.clone())
                    .to_strategy_atom()
            ),
            Self::RemoveNonApplicableRules => "remove-non-applicable-rules".into(),
            Self::StringReversal => "string-reversal".into(),
            Self::SrsStripContexts { max_prefix, max_suffix } => {
                let mut args = Vec::new();
                if let Some(limit) = max_prefix { args.push(format!("max-prefix={limit}")); }
                if let Some(limit) = max_suffix { args.push(format!("max-suffix={limit}")); }
                if args.is_empty() { "srs-strip-contexts".into() }
                else { format!("srs-strip-contexts({})", args.join(",")) }
            }
            Self::NativeConstantToUnary => "constant-to-unary".into(),
            Self::ConstantToUnary { variable, renaming } => format!(
                "exact-constant-to-unary(hex={})",
                hex_json(&(variable, renaming))
            ),
            Self::SrsLength => "srs-length".into(),
            Self::SrsWeightedLength { max_weight } => format!("srs-weighted-length({max_weight})"),
            Self::SrsCanonicalWeightRemoval { max_weight } => format!("srs-canonical-weight-removal(max-weight={max_weight})"),
            Self::SrsCompactWeightRemoval { max_weight } => format!("srs-compact-weight-removal(max-weight={max_weight})"),
            Self::SrsCanonicalCompactWeightRemoval { max_weight } => format!("srs-canonical-compact-weight-removal(max-weight={max_weight})"),
            Self::SrsSummedWeightRemoval { max_weight } => format!("srs-summed-weight-removal(max-weight={max_weight})"),
            Self::SrsLinearWeightRemoval { max_weight } => format!("srs-linear-weight-removal(max-weight={max_weight})"),
            Self::SrsLpWeightRemoval { max_weight, all_strict, maximal } => if *all_strict {
                format!("srs-lp-weight-removal(max-weight={max_weight},all-strict=true)")
            } else if *maximal {
                format!("srs-lp-weight-removal(max-weight={max_weight},maximal=true)")
            } else { format!("srs-lp-weight-removal(max-weight={max_weight})") },
            Self::SrsWeightedRuleRemoval { max_weight } => {
                format!("srs-weighted-rule-removal({max_weight})")
            }
            Self::SrsMatchBounds {
                max_bound,
                max_states,
                max_transitions,
            } => format!(
                "match-bounds(max-bound={max_bound},max-states={max_states},max-transitions={max_transitions})"
            ),
            Self::ExactSrsMatchBounds { proof } => {
                format!("exact-match-bounds(hex={})", hex_json(proof))
            }
            Self::ExactSrsRelativeMatchBounds {
                proof,
                removed_indices,
            } => format!(
                "exact-relative-match-bounds(hex={})",
                hex_json(&(proof, removed_indices))
            ),
            Self::SrsRelativeMatchBounds {
                max_bound,
                max_states,
                max_transitions,
            } => format!(
                "relative-match-bounds(max-bound={max_bound},max-states={max_states},max-transitions={max_transitions})"
            ),
            Self::SrsRelativeMatchBoundsRemoval {
                max_bound,
                max_states,
                max_transitions,
            } => format!(
                "relative-match-bounds-removal(max-bound={max_bound},max-states={max_states},max-transitions={max_transitions})"
            ),
            Self::SrsRfcMatchBounds {
                max_bound,
                max_words,
                max_word_len,
                max_states,
                max_transitions,
                at_bound,
                closure,
            } => rfc_atom(
                "rfc-match-bounds",
                *max_bound,
                *max_words,
                *max_word_len,
                *max_states,
                *max_transitions,
                *at_bound,
                *closure,
            ),
            Self::SrsRfcRelativeMatchBounds {
                allow_partial,
                absolute_residual,
                layered_seconds,
                fresh_seconds,
                min_bound,
                max_bound,
                max_words,
                max_word_len,
                max_states,
                max_transitions,
                at_bound,
                closure,
            } => {
                let mut atom = rfc_atom(
                "rfc-relative-match-bounds",
                *max_bound,
                *max_words,
                *max_word_len,
                *max_states,
                *max_transitions,
                *at_bound,
                *closure,
                );
                if *allow_partial { atom = atom.replacen('(', "(allow-partial=true,", 1); }
                if *absolute_residual { atom = atom.replacen('(', "(absolute-residual=true,", 1); }
                if *layered_seconds != 2 { atom = atom.replacen('(', &format!("(layered-seconds={layered_seconds},"), 1); }
                if *fresh_seconds != (*layered_seconds).min(3) { atom = atom.replacen('(', &format!("(fresh-seconds={fresh_seconds},"), 1); }
                if *min_bound == 0 { atom } else {
                    atom.replacen('(', &format!("(min-bound={min_bound},"), 1)
                }
            },
            Self::LinearPolynomial {
                max_constant,
                max_coefficient,
                max_symbols,
                max_arity,
            } => bounded(
                "poly",
                *max_constant,
                *max_coefficient,
                *max_symbols,
                *max_arity,
            ),
            Self::SelectedLinearPolynomial {
                max_constant,
                max_coefficient,
                max_symbols,
                max_arity,
                candidate_index,
            } => {
                let mut atom = bounded(
                    "poly",
                    *max_constant,
                    *max_coefficient,
                    *max_symbols,
                    *max_arity,
                );
                atom.insert_str(atom.len() - 1, &format!(",candidate={candidate_index}"));
                atom
            }
            Self::TargetLinearPolynomial {
                max_constant,
                max_coefficient,
                max_symbols,
                max_arity,
                strict_rule_indices,
            } => {
                let mut atom = bounded(
                    "poly-target",
                    *max_constant,
                    *max_coefficient,
                    *max_symbols,
                    *max_arity,
                );
                atom.insert_str(
                    atom.len() - 1,
                    &format!(
                        ",strict={}",
                        strict_rule_indices
                            .iter()
                            .map(usize::to_string)
                            .collect::<Vec<_>>()
                            .join("+")
                    ),
                );
                atom
            }
            Self::MinimumDeletionLinearPolynomial {
                max_constant,
                max_coefficient,
                max_symbols,
                max_arity,
                min_delete,
                residual_budget,
            } => {
                let mut atom = bounded(
                    "poly-min-delete",
                    *max_constant,
                    *max_coefficient,
                    *max_symbols,
                    *max_arity,
                );
                atom.insert_str(
                    atom.len() - 1,
                    &format!(",min-delete={min_delete},residual-budget={residual_budget}"),
                );
                atom
            }
            Self::ExactLinearPolynomial { interpretation } => {
                format!("exact-poly(hex={})", hex_json(interpretation))
            }
            Self::ExactSourceBoundOrder { source_trs_input_xml, order_atom } => format!(
                "exact-trs-order(hex={})", hex_json(&(source_trs_input_xml, order_atom))),
            Self::ExactLinearPolynomialRemoval {
                interpretation,
                removed_rule_indices,
            } => format!(
                "exact-poly-removal(hex={})",
                hex_json(&(interpretation, removed_rule_indices))
            ),
            Self::SmtLinearPolynomial {
                max_constant,
                max_coefficient,
                max_symbols,
                max_arity,
            } => bounded(
                "smt-poly",
                *max_constant,
                *max_coefficient,
                *max_symbols,
                *max_arity,
            ),
            Self::MatrixInterpretation {
                dimension,
                max_constant,
                max_coefficient,
                max_symbols,
                max_arity,
            } => {
                let mut atom = bounded(
                    "matrix",
                    *max_constant,
                    *max_coefficient,
                    *max_symbols,
                    *max_arity,
                );
                atom.insert_str(atom.len() - 1, &format!(",dimension={dimension}"));
                atom
            }
            Self::IntegerMatrixInterpretation {
                dimension,
                min_value,
                max_value,
                max_symbols,
                max_arity,
            } => {
                let mut args = vec![
                    format!("dimension={dimension}"),
                    format!("min-value={min_value}"),
                    format!("max-value={max_value}"),
                ];
                for (name, value) in [("max-symbols", max_symbols), ("max-arity", max_arity)] {
                    if let Some(value) = value {
                        args.push(format!("{name}={value}"));
                    }
                }
                format!("integer-matrix({})", args.join(","))
            }
            Self::ExactMatrixInterpretation { interpretation } => {
                format!("exact-matrix(hex={})", hex_json(interpretation))
            }
            Self::ExactIntegerMatrixInterpretation { interpretation } => {
                format!("exact-integer-matrix(hex={})", hex_json(interpretation))
            }
            Self::Kbo {
                max_weight,
                max_symbols,
            } => format!("kbo(max-weight={max_weight},max-symbols={max_symbols})"),
            Self::ExactKbo {
                precedence,
                precedence_ranks,
                weights,
            } => format!(
                "exact-kbo(hex={})",
                hex_json(&(precedence, precedence_ranks, weights))
            ),
            Self::PathOrder { max_symbols } => format!("path-order(max-symbols={max_symbols})"),
            Self::SharedPathOrder { max_symbols } => format!("path-order(max-symbols={max_symbols},shared=1)"),
            Self::ExactPathOrder {
                statuses,
                precedence,
                precedence_ranks,
                argument_filter,
            } => format!(
                "exact-path-order(hex={})",
                hex_json(&(statuses, precedence, precedence_ranks, argument_filter))
            ),
            Self::ExactPathOrderRemoval {
                source_trs_input_xml,
                statuses,
                precedence,
                precedence_ranks,
                argument_filter,
                removed_rule_indices,
            } => format!(
                "exact-path-order-removal(hex={}{})",
                hex_json(&(
                    statuses,
                    precedence,
                    precedence_ranks,
                    argument_filter,
                    removed_rule_indices,
                )),
                source_trs_input_xml.as_ref().map(|source| format!(",source-hex={}", source.as_bytes().iter().map(|byte| format!("{byte:02x}")).collect::<String>())).unwrap_or_default()
            ),
            Self::RelativeFlatContextClosure => "relative-flat-context-closure".into(),
            Self::SrsContextClosure { depth } => format!("srs-context-closure(depth={depth})"),
            Self::SrsShiftLabeling { memory } => format!("srs-shift-labeling(memory={memory})"),
            Self::SrsWeightedLabeling { carrier_size, max_weight, strict_percent } => {
                let percent = if *strict_percent == 0 { String::new() } else { format!(",strict-percent={strict_percent}") };
                format!("srs-weighted-labeling(carrier-size={carrier_size},max-weight={max_weight}{percent})")
            },
            Self::TrsRootLabeling => "trs-root-labeling".into(),
            Self::RelativeAnnotatedDependencyPairs => "relative-adp".into(),
            Self::RelativeSemanticLabeling { carrier_size: 2 } => {
                "relative-semantic-labeling".into()
            }
            Self::RelativeSemanticLabeling { carrier_size } => {
                format!("relative-semantic-labeling(carrier-size={carrier_size})")
            }
            Self::ExactRelativeSemanticLabeling {
                carrier_size,
                interpretations,
            } => format!(
                "exact-relative-semantic-labeling(carrier-size={carrier_size},hex={})",
                hex_json(interpretations)
            ),
            Self::OutermostRaffelsieperZantema => "outermost-rz".into(),
            Self::SwitchContextSensitive => "switch-csr".into(),
            Self::Gm04InverseContextSensitive => "gm04-inverse-csr".into(),
            Self::Gm04InverseContextSensitiveFull => "gm04-inverse-csr-full".into(),
            Self::CsrLoop => "csr-loop".into(),
            Self::CsrInnermostEquivalence => "csr-innermost-equivalence".into(),
            Self::CsrInnermostEquivalenceWithStrategy(strategy) => {
                format!("csr-innermost-equivalence({})", strategy.to_strategy_atom())
            }
            Self::CsrInnermostRta08Equivalence => "csr-innermost-rta08-equivalence".into(),
            Self::CsrInnermostRta08EquivalenceWithStrategy(strategy) => {
                format!(
                    "csr-innermost-rta08-equivalence({})",
                    strategy.to_strategy_atom()
                )
            }
            Self::ExactNonterminationProof {
                source_trs_input_xml,
                nontermination_proof_xml,
            } => format!(
                "exact-trs-nontermination-proof(hex={})",
                hex_json(&(source_trs_input_xml, nontermination_proof_xml))
            ),
            Self::SwitchInnermost => "switch-innermost".into(),
            Self::AaeccInnermost => "aaecc-innermost".into(),
            Self::Uncurry => "uncurry".into(),
            Self::UncurryRole { role } => format!("uncurry(role={role})"),
            Self::SafeCsrDependencyPairs => "csr-safe-dp".into(),
            Self::ImprovedCsrDependencyPairs => "csr-improved-dp".into(),
            Self::MutermUnhidingCsrDependencyPairs => "csr-muterm-unhiding".into(),
            Self::MutermExpandedCsrDependencyPairs => "csr-muterm-expanded".into(),
            Self::InnermostCsrDependencyPairs => "csr-innermost-dp".into(),
            Self::Rta08CsrDependencyPairs => "csr-rta08-dp".into(),
            Self::NativeContextSensitiveCsrDependencyPairs => "csr-native-dp".into(),
            Self::NativeOrdinaryCsrDependencyPairs => "csr-native-ordinary-dp".into(),
            Self::ConservativeCsrDependencyPairs => "csr-conservative-dp".into(),
            Self::CsrGmTransformation => "csr-gm-transform".into(),
            Self::DependencyPairs => "dp".into(),
            Self::TrimmedDependencyPairs => "dp-trimmed".into(),
            Self::TrimmedDependencyPairsWithStrategy(strategy) => {
                format!("dp-trimmed({})", strategy.to_strategy_atom())
            }
            Self::InnermostLhssDependencyPairs => "innermost-lhss-dp".into(),
            Self::ExactDependencyPairs { dp_input_xml } => {
                format!("exact-dp(hex={})", hex_json(dp_input_xml))
            }
            Self::ExactInnermostLhssDependencyPairs { dp_input_xml } => {
                format!("exact-innermost-lhss-dp(hex={})", hex_json(dp_input_xml))
            }
            Self::DependencyPairsWithStrategy(strategy) => {
                format!("dp({})", strategy.to_strategy_atom())
            }
            Self::CsrGmTransformationWithStrategy(strategy) => {
                format!("csr-gm-transform({})", strategy.to_strategy_atom())
            }
            Self::SafeCsrDependencyPairsWithStrategy(strategy) => {
                format!("csr-safe-dp({})", strategy.to_strategy_atom())
            }
            Self::ImprovedCsrDependencyPairsWithStrategy(strategy) => {
                format!("csr-improved-dp({})", strategy.to_strategy_atom())
            }
            Self::MutermUnhidingCsrDependencyPairsWithStrategy(strategy) => {
                format!("csr-muterm-unhiding({})", strategy.to_strategy_atom())
            }
            Self::MutermExpandedCsrDependencyPairsWithStrategy(strategy) => {
                format!("csr-muterm-expanded({})", strategy.to_strategy_atom())
            }
            Self::InnermostCsrDependencyPairsWithStrategy(strategy) => {
                format!("csr-innermost-dp({})", strategy.to_strategy_atom())
            }
            Self::Rta08CsrDependencyPairsWithStrategy(strategy) => {
                format!("csr-rta08-dp({})", strategy.to_strategy_atom())
            }
            Self::NativeContextSensitiveCsrDependencyPairsWithStrategy(strategy) => {
                format!("csr-native-dp({})", strategy.to_strategy_atom())
            }
            Self::NativeOrdinaryCsrDependencyPairsWithStrategy(strategy) => {
                format!("csr-native-ordinary-dp({})", strategy.to_strategy_atom())
            }
            Self::ConservativeCsrDependencyPairsWithStrategy(strategy) => {
                format!("csr-conservative-dp({})", strategy.to_strategy_atom())
            }
        }
    }
}

fn rfc_atom(
    name: &str,
    bound: usize,
    words: usize,
    word_len: usize,
    states: usize,
    transitions: usize,
    at_bound: SrsMatchAtBound,
    closure: SrsRfcBarrenClosure,
) -> String {
    let at_bound = match at_bound {
        SrsMatchAtBound::Exact => "exact",
        SrsMatchAtBound::Merge => "merge",
    };
    let closure = match closure {
        SrsRfcBarrenClosure::Right => "right",
        SrsRfcBarrenClosure::Full => "full",
    };
    format!(
        "{name}(max-bound={bound},max-words={words},max-word-len={word_len},max-states={states},max-transitions={transitions},at-bound={at_bound},closure={closure})"
    )
}

#[cfg(test)]
mod tests {
    use crate::proving::dependency_pairs::{DpArgumentFilterEntry, DpPathOrderKind};
    use crate::proving::engine::{ProveStrategy, ProveStrategyProcessor};
    use std::collections::BTreeMap;

    #[test]
    fn rfc_minimum_bound_is_explicit_and_roundtrips() {
        let atom = "rfc-relative-match-bounds(min-bound=2,max-bound=2,at-bound=merge)";
        let ProveStrategy::Processor(processor) = ProveStrategy::parse(atom).unwrap() else { panic!() };
        assert!(processor.to_strategy_atom().contains("min-bound=2"));
        roundtrip(processor);
        assert!(ProveStrategy::parse("rfc-relative-match-bounds(min-bound=3,max-bound=2)").is_err());
        let absolute = "rfc-relative-match-bounds(absolute-residual=true,layered-seconds=60,min-bound=2,max-bound=4,at-bound=merge)";
        let ProveStrategy::Processor(p) = ProveStrategy::parse(absolute).unwrap() else { panic!() };
        assert_eq!(ProveStrategy::parse(&p.to_strategy_atom()).unwrap(), ProveStrategy::Processor(p));
        assert!(ProveStrategy::parse("rfc-relative-match-bounds(layered-seconds=0)").is_err());
        assert!(ProveStrategy::parse("rfc-relative-match-bounds(absolute-residual=maybe)").is_err());
        let ProveStrategy::Processor(processor) = ProveStrategy::parse("rfc-relative-match-bounds(max-bound=2)").unwrap() else { panic!() };
        assert!(!processor.to_strategy_atom().contains("min-bound"));
        roundtrip(processor);
    }

    fn roundtrip(processor: ProveStrategyProcessor) {
        let atom = processor.to_strategy_atom();
        assert_eq!(
            ProveStrategy::parse(&atom).unwrap(),
            ProveStrategy::Processor(processor)
        );
    }

    #[test]
    fn exact_order_atoms_roundtrip() {
        roundtrip(ProveStrategyProcessor::ExactKbo {
            precedence: vec!["f".into(), "g".into()],
            precedence_ranks: BTreeMap::from([("f".into(), 0), ("g".into(), 1)]),
            weights: BTreeMap::from([("f".into(), 1), ("g".into(), 2)]),
        });
        roundtrip(ProveStrategyProcessor::ExactPathOrder {
            statuses: BTreeMap::from([("f".into(), DpPathOrderKind::Lpo)]),
            precedence: vec!["f".into()],
            precedence_ranks: BTreeMap::from([("f".into(), 0)]),
            argument_filter: BTreeMap::from([(
                "f".into(),
                DpArgumentFilterEntry::NonCollapsing(vec![0]),
            )]),
        });
    }
}
