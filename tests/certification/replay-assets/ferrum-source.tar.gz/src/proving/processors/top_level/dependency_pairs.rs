use crate::proving::dependency_pairs::{
    DpOptions, dependency_pairs, reconstruct_dependency_pair_proof,
};
use crate::proving::processors::dp::DpProblemState;
use crate::proving::{Proof, ProofStep};

use super::super::{
    ProblemCertificate, ProblemState, ProcessorApplication, ProcessorResult, WorklistProcessor,
};

pub struct DependencyPairTransformationProcessor {
    pub options: DpOptions,
}

pub(super) fn apply_trimmed_dependency_pairs(
    state: &ProblemState,
    options: DpOptions,
) -> ProcessorResult {
    let trs = match state {
        ProblemState::Trs(trs) | ProblemState::Srs(trs)
            if trs.strategy() == crate::core::RewriteStrategy::Full => trs,
        _ => return ProcessorResult::Inapplicable,
    };
    if !trs.rules().iter().all(crate::core::RewriteRule::is_well_formed) {
        return ProcessorResult::Inapplicable;
    }
    let pairs = crate::proving::dependency_pairs::trimmed_dependency_pairs(trs);
    let problem = DpProblemState::ordinary(trs.clone(), pairs, options);
    let reconstruction_problem = problem.clone();
    ProcessorResult::Applied(ProcessorApplication::new(
        vec![ProblemState::DependencyPairs(problem)],
        move |children| {
            let [ProblemCertificate::DependencyPairTree(tree)] =
                <[ProblemCertificate; 1]>::try_from(children).ok()? else { return None };
            let proof = reconstruct_dependency_pair_proof(&reconstruction_problem, tree);
            Some(ProblemCertificate::Trs(Proof::terminating(vec![
                ProofStep::DependencyPairProof { proof: Box::new(proof) },
            ])))
        },
    ))
}

/// Restrict a full-rewriting nontermination search to Q = lhs(R), then
/// construct the native DP problem. CeTA's q_increase_nonterm_trs preserves
/// NFS: adding Q must not silently turn on normal-form substitutions.
pub struct InnermostLhssDependencyPairTransformationProcessor {
    pub options: DpOptions,
}

impl WorklistProcessor for InnermostLhssDependencyPairTransformationProcessor {
    fn name(&self) -> &'static str { "innermost-lhss-dependency-pair-transformation" }

    fn apply(&self, state: &ProblemState) -> ProcessorResult {
        let trs = match state {
            ProblemState::Trs(trs) | ProblemState::Srs(trs) => trs,
            _ => return ProcessorResult::Inapplicable,
        };
        if trs.strategy() != crate::core::RewriteStrategy::Full
            || !trs.rules().iter().all(crate::core::RewriteRule::is_well_formed)
        {
            return ProcessorResult::Inapplicable;
        }
        let pairs = dependency_pairs(trs);
        let q = trs.rules().iter().map(|r| r.lhs().clone()).collect::<Vec<_>>();
        // Nontermination dpTrans creates a non-minimal, NFS=false obligation.
        let mut child = DpProblemState::nonminimal(trs.clone(), pairs.clone(), self.options.clone())
            .with_normal_form_substitutions(false);
        child.innermost_lhss = Some(q.clone());
        ProcessorResult::Applied(ProcessorApplication::new(
            vec![ProblemState::DependencyPairs(child)], move |children| {
                let [ProblemCertificate::DependencyPairNontermination(proof)] =
                    <[ProblemCertificate; 1]>::try_from(children).ok()? else { return None };
                Some(ProblemCertificate::Trs(Proof::nonterminating(
                    crate::proving::NonterminationProof::InnermostLhssDependencyPairs {
                        innermost_lhss: q.clone(), pairs: pairs.clone(), proof: Box::new(proof),
                    },
                )))
            },
        ))
    }
}

#[cfg(test)]
mod q_initialization_tests {
    use super::*;
    use crate::core::{RewriteRule, Term, Trs};
    use crate::proving::DpProofTree;

    #[test]
    fn trimmed_root_dp_preserves_equal_calls_and_exposes_native_child() {
        for (f, g) in [("f", "g"), ("renamed_outer", "renamed_inner")] {
            let x = Term::var("x");
            let gx = Term::app(g, vec![x.clone()]);
            let fgx = Term::app(f, vec![gx.clone()]);
            let trs = Trs::new(None, x.variables(), vec![
                RewriteRule::new(fgx.clone(), gx.clone()),
                RewriteRule::new(gx, fgx),
            ]);
            let original = dependency_pairs(&trs);
            let ProcessorResult::Applied(app) = apply_trimmed_dependency_pairs(
                &ProblemState::Trs(trs.clone()), DpOptions::default(),
            ) else { panic!("full well-formed TRS must apply") };
            let [ProblemState::DependencyPairs(child)] = app.residuals.as_slice()
                else { panic!("must expose one DP state") };
            assert_eq!(original.len(), 3);
            assert_eq!(child.pairs().len(), 2);
            assert!(child.pairs().iter().all(|p| p.source_rule() == 1));
            assert!(child.pairs().iter().any(|p| p.lhs() == p.rhs()),
                "the nonterminating self-call must not be omitted");
        }
    }

    #[test]
    fn trimmed_dp_strategy_roundtrips_with_and_without_continuation() {
        for text in ["dp-trimmed", "dp-trimmed(graph; size-change)"] {
            let parsed = crate::proving::engine::ProveStrategy::parse(text).unwrap();
            let crate::proving::engine::ProveStrategy::Processor(p) = parsed else { panic!() };
            let roundtrip = crate::proving::engine::ProveStrategy::parse(&p.to_strategy_atom()).unwrap();
            assert_eq!(roundtrip, crate::proving::engine::ProveStrategy::Processor(p));
        }
    }

    #[test]
    fn native_q_dp_preserves_rules_and_nfs_and_rejects_termination_children() {
        for name in ["call", "renamed"] {
            let x = Term::var("x");
            let rule = RewriteRule::new(Term::app(name, vec![x.clone()]),
                Term::app(name, vec![Term::app("step", vec![x.clone()])]));
            let trs = Trs::new(None, x.variables(), vec![rule.clone()]);
            let processor = InnermostLhssDependencyPairTransformationProcessor { options: DpOptions::default() };
            let ProcessorResult::Applied(app) = processor.apply(&ProblemState::Trs(trs.clone())) else { panic!() };
            let [ProblemState::DependencyPairs(child)] = app.residuals.as_slice() else { panic!() };
            assert_eq!(child.trs.rules(), trs.rules());
            assert_eq!(child.innermost_lhss, Some(vec![rule.lhs().clone()]));
            assert!(!child.stats.normal_form_substitutions);
            assert!(!child.stats.minimal);
            assert_eq!(child.pairs.len(), dependency_pairs(&trs).len());
            assert!(app.reconstruct(vec![ProblemCertificate::DependencyPairTree(DpProofTree::Empty)]).is_none());
        }
        let parsed = crate::proving::engine::ProveStrategy::parse("innermost-lhss-dp").unwrap();
        let crate::proving::engine::ProveStrategy::Processor(p) = parsed else { panic!() };
        assert_eq!(p.to_strategy_atom(), "innermost-lhss-dp");
    }
}

impl WorklistProcessor for DependencyPairTransformationProcessor {
    fn name(&self) -> &'static str {
        "dependency-pair-transformation"
    }

    fn apply(&self, state: &ProblemState) -> ProcessorResult {
        let trs = match state {
            ProblemState::Trs(trs) | ProblemState::Srs(trs) => trs,
            _ => return ProcessorResult::Inapplicable,
        };
        if !trs
            .rules()
            .iter()
            .all(crate::core::RewriteRule::is_well_formed)
        {
            return ProcessorResult::Inapplicable;
        }
        let pairs = dependency_pairs(trs);
        let problem = DpProblemState::ordinary(trs.clone(), pairs, self.options.clone());
        let reconstruction_problem = problem.clone();
        ProcessorResult::Applied(ProcessorApplication::new(
            vec![ProblemState::DependencyPairs(problem)],
            move |mut children: Vec<ProblemCertificate>| {
                let [child] = children.as_mut_slice() else {
                    return None;
                };
                match child {
                    ProblemCertificate::DependencyPairNontermination(proof) => {
                        Some(ProblemCertificate::Trs(Proof::nonterminating(
                            crate::proving::NonterminationProof::DependencyPairs {
                                pairs: reconstruction_problem.pairs().to_vec(),
                                proof: Box::new(proof.clone()),
                            },
                        )))
                    }
                    ProblemCertificate::DependencyPairTree(tree) => {
                        let proof = reconstruct_dependency_pair_proof(
                            &reconstruction_problem,
                            std::mem::replace(tree, crate::proving::DpProofTree::Empty),
                        );
                        Some(ProblemCertificate::Trs(Proof::terminating(vec![
                            ProofStep::DependencyPairProof {
                                proof: Box::new(proof),
                            },
                        ])))
                    }
                    _ => None,
                }
            },
        ))
    }
}
