mod automaton;
mod exact_match_bounds;
mod length;
mod match_bounds;
mod relative_match_bounds;
mod rfc_match_bounds;
mod rfc_relative_match_bounds;
mod words;

pub(crate) use automaton::cons_encoded_srs_rules;
pub use automaton::{SrsMatchAtBound, SrsRfcBarrenClosure};
#[cfg(test)]
pub(crate) use automaton::{
    SrsMatchAutomatonBuilder, SrsMatchPath, SrsMatchWordIndex, SrsRfcBarrenBuilder,
    complete_srs_match_bounds_automaton_for_initial_words, complete_srs_match_bounds_completion,
    complete_srs_rfc_match_bounds_completion_for_initial_words, match_bounds_weak_rhs_height,
    prove_srs_by_match_bounds_completion, prove_srs_by_reversal_match_bounds_completion,
    prove_srs_by_rfc_match_bounds_with_limits, srs_relative_match_bounds_candidate_batches,
    srs_rfc_initial_words,
};
pub use exact_match_bounds::{ExactSrsMatchBoundsProcessor, ExactSrsRelativeMatchBoundsProcessor};
pub use length::{SrsLengthProcessor, SrsWeightedLengthProcessor, SrsWeightedRuleRemovalProcessor};
pub use length::SrsCanonicalWeightRemovalProcessor;
pub use length::SrsCompactWeightRemovalProcessor;
pub use match_bounds::SrsMatchBoundsProcessor;
pub use relative_match_bounds::SrsRelativeMatchBoundsProcessor;
pub use rfc_match_bounds::SrsRfcMatchBoundsProcessor;
pub use rfc_relative_match_bounds::SrsRfcRelativeMatchBoundsProcessor;
pub(crate) use words::reverse_srs_rules;
pub(crate) use words::{srs_word_to_term, strict_srs_word_with_tail};
