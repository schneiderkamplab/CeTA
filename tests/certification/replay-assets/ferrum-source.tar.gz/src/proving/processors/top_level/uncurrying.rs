use std::collections::{BTreeMap, BTreeSet};

use crate::core::{RewriteRule, RewriteStrategy, Symbol, Term, Trs};
use crate::proving::UncurriedSymbolEntry;

#[derive(Clone, Debug)]
pub(crate) struct UncurryingTransform {
    pub(crate) app_symbol: Symbol,
    pub(crate) symbols: Vec<UncurriedSymbolEntry>,
    pub(crate) uncurry_rules: Vec<RewriteRule>,
    pub(crate) eta_rules: Vec<RewriteRule>,
    pub(crate) transformed: Trs,
    occupied: BTreeSet<Symbol>,
}

impl UncurryingTransform {
    pub(crate) fn transform_term(&self, term: &Term) -> Term {
        uncurry_term(term, &self.app_symbol, &self.occupied)
    }
}

pub(crate) fn synthesize_uncurrying_transform(trs: &Trs) -> Option<UncurryingTransform> {
    let app_symbol = infer_uncurrying_application_symbol(trs)?;
    synthesize_uncurrying_for_application(trs, app_symbol)
}

/// Application roles are ranked by structural use, with first occurrence
/// breaking ties. The index is a state-local search parameter, invariant
/// under consistent symbol/variable renaming.
pub(crate) fn synthesize_uncurrying_with_role(trs: &Trs, role: usize) -> Option<UncurryingTransform> {
    fn collect(term: &Term, symbols: &mut Vec<Symbol>) {
        if let Term::App { symbol, args } = term {
            if args.len() == 2 && !symbols.contains(symbol) { symbols.push(symbol.clone()); }
            for argument in args { collect(argument, symbols); }
        }
    }
    fn count(term: &Term, application: &Symbol) -> usize {
        match term {
            Term::Var(_) => 0,
            Term::App { symbol, args } => usize::from(symbol == application
                && flatten_applicative_term(term, application).is_some())
                + args.iter().map(|term| count(term, application)).sum::<usize>(),
        }
    }
    let mut symbols = Vec::new();
    for rule in trs.rules() { collect(rule.lhs(), &mut symbols); collect(rule.rhs(), &mut symbols); }
    let mut candidates = symbols.into_iter().filter_map(|symbol| {
        if trs.rules().iter().any(|rule| contains_variable_head_application(rule.lhs(), &symbol)) {
            return None;
        }
        let score: usize = trs.rules().iter().map(|rule| count(rule.lhs(), &symbol) + count(rule.rhs(), &symbol)).sum();
        (score > 0).then_some((score, symbol))
    }).collect::<Vec<_>>();
    candidates.sort_by_key(|(score, _)| std::cmp::Reverse(*score));
    synthesize_uncurrying_for_application(trs, candidates.get(role)?.1.clone())
}

fn synthesize_uncurrying_for_application(trs: &Trs, app_symbol: Symbol) -> Option<UncurryingTransform> {

    let mut max_applications = BTreeMap::<Symbol, usize>::new();
    for rule in trs.rules() {
        if contains_variable_head_application(rule.lhs(), &app_symbol) {
            return None;
        }
        collect_uncurrying_heads(rule.lhs(), &app_symbol, &mut max_applications);
        collect_uncurrying_heads(rule.rhs(), &app_symbol, &mut max_applications);
    }
    if max_applications
        .values()
        .all(|applications| *applications == 0)
    {
        return None;
    }
    let occupied = trs.arities().keys().cloned().collect::<BTreeSet<_>>();
    let symbols = max_applications
        .iter()
        .map(|(symbol, max_application)| UncurriedSymbolEntry {
            original: symbol.clone(),
            arity: 0,
            symbols: (0..=*max_application)
                .map(|application| uncurried_symbol(symbol, application, &occupied))
                .collect(),
        })
        .collect::<Vec<_>>();

    let eta_rules = build_eta_rules(trs, &app_symbol, &max_applications);
    let uncurry_rules = build_uncurry_rules(&app_symbol, &symbols);
    let mut variables = trs.variables().clone();
    for rule in uncurry_rules.iter().chain(&eta_rules) {
        variables.extend(rule.lhs().variables());
        variables.extend(rule.rhs().variables());
    }

    let mut transformed_rules = trs
        .rules()
        .iter()
        .map(|rule| {
            RewriteRule::new(
                uncurry_term(rule.lhs(), &app_symbol, &occupied),
                uncurry_term(rule.rhs(), &app_symbol, &occupied),
            )
        })
        .collect::<Vec<_>>();
    transformed_rules.extend(eta_rules.iter().map(|rule| {
        RewriteRule::new(
            uncurry_term(rule.lhs(), &app_symbol, &occupied),
            uncurry_term(rule.rhs(), &app_symbol, &occupied),
        )
    }));
    transformed_rules.extend(uncurry_rules.iter().cloned());

    let transformed = Trs::new_with_strategy(
        trs.name().map(str::to_string),
        variables,
        transformed_rules,
        RewriteStrategy::Full,
    );

    Some(UncurryingTransform {
        app_symbol,
        symbols,
        uncurry_rules,
        eta_rules,
        transformed,
        occupied,
    })
}

#[cfg(test)]
mod role_tests {
    use super::*;

    #[test]
    fn application_roles_survive_renaming_and_allow_ambiguous_signatures() {
        for [first, second] in [["p", "q"], ["z_renamed", "a_renamed"]] {
            let rules = [first, second].into_iter().map(|application| RewriteRule::new(
                Term::app(application, vec![Term::app("constant", vec![]), Term::var("x")]),
                Term::app("result", vec![Term::var("x")]),
            )).collect();
            let trs = Trs::new(None, BTreeSet::from([crate::core::Variable::new("x")]), rules);
            assert_eq!(synthesize_uncurrying_with_role(&trs, 0).unwrap().app_symbol.as_str(), first);
            assert_eq!(synthesize_uncurrying_with_role(&trs, 1).unwrap().app_symbol.as_str(), second);
            assert!(synthesize_uncurrying_with_role(&trs, 2).is_none());
        }
    }
}

pub(crate) fn infer_uncurrying_application_symbol(trs: &Trs) -> Option<Symbol> {
    let arities = trs.arities();
    let conventional = Symbol::new("app");
    if arities.get(&conventional).copied() == Some(2) {
        return Some(conventional);
    }

    let mut candidates = arities.iter().filter_map(|(candidate, arity)| {
        (*arity == 2
            && arities
                .iter()
                .all(|(symbol, arity)| symbol == candidate || *arity == 0))
        .then(|| candidate.clone())
    });
    let candidate = candidates.next()?;
    candidates.next().is_none().then_some(candidate)
}

fn collect_uncurrying_heads(
    term: &Term,
    app_symbol: &Symbol,
    max_applications: &mut BTreeMap<Symbol, usize>,
) {
    match term {
        Term::Var(_) => {}
        Term::App { symbol, args } if symbol == app_symbol && args.len() == 2 => {
            if let Some((head, arguments)) = flatten_applicative_term(term, app_symbol) {
                max_applications
                    .entry(head)
                    .and_modify(|current| *current = (*current).max(arguments.len()))
                    .or_insert(arguments.len());
                for argument in arguments {
                    collect_uncurrying_heads(argument, app_symbol, max_applications);
                }
            } else {
                for arg in args {
                    collect_uncurrying_heads(arg, app_symbol, max_applications);
                }
            }
        }
        Term::App { symbol, args } => {
            max_applications.entry(symbol.clone()).or_insert(0);
            for arg in args {
                collect_uncurrying_heads(arg, app_symbol, max_applications);
            }
        }
    }
}

pub(crate) fn contains_variable_head_application(term: &Term, app_symbol: &Symbol) -> bool {
    match term {
        Term::Var(_) => false,
        Term::App { symbol, args } if symbol == app_symbol && args.len() == 2 => {
            if applicative_head(term, app_symbol).is_some_and(|head| matches!(head, Term::Var(_))) {
                return true;
            }
            args.iter()
                .any(|arg| contains_variable_head_application(arg, app_symbol))
        }
        Term::App { args, .. } => args
            .iter()
            .any(|arg| contains_variable_head_application(arg, app_symbol)),
    }
}

fn build_eta_rules(
    trs: &Trs,
    app_symbol: &Symbol,
    max_applications: &BTreeMap<Symbol, usize>,
) -> Vec<RewriteRule> {
    let mut rules = Vec::new();
    for rule in trs.rules() {
        let mut lhs = rule.lhs().clone();
        let mut rhs = rule.rhs().clone();
        let mut index = 0usize;
        // Eta-saturation is governed by the applicative arity still available
        // at the left-hand side.  The right-hand side may be a variable (for
        // example `app(0, x) -> x`); it must still receive the same fresh
        // argument.  Requiring a known applicative head on both sides omitted
        // exactly those mandatory eta rules and produced CPF transformations
        // that CeTA correctly rejected.
        while remaining_applications(&lhs, app_symbol, max_applications).unwrap_or(0) > 0 {
            let variable = Term::var(format!("eta{index}"));
            lhs = Term::App {
                symbol: app_symbol.clone(),
                args: vec![lhs, variable.clone()],
            };
            rhs = Term::App {
                symbol: app_symbol.clone(),
                args: vec![rhs, variable],
            };
            rules.push(RewriteRule::new(lhs.clone(), rhs.clone()));
            index += 1;
        }
    }
    rules
}

fn remaining_applications(
    term: &Term,
    app_symbol: &Symbol,
    max_applications: &BTreeMap<Symbol, usize>,
) -> Option<usize> {
    match term {
        Term::Var(_) => None,
        Term::App { symbol, args } if symbol == app_symbol && args.len() == 2 => {
            let (head, arguments) = flatten_applicative_term(term, app_symbol)?;
            max_applications
                .get(&head)
                .and_then(|max| max.checked_sub(arguments.len()))
        }
        Term::App { symbol, args } if args.is_empty() => max_applications.get(symbol).copied(),
        Term::App { .. } => Some(0),
    }
}

fn applicative_head<'a>(term: &'a Term, app_symbol: &Symbol) -> Option<&'a Term> {
    let mut head = term;
    loop {
        match head {
            Term::App { symbol, args } if symbol == app_symbol && args.len() == 2 => {
                head = &args[0];
            }
            Term::App { .. } | Term::Var(_) => return Some(head),
        }
    }
}

fn flatten_applicative_term<'a>(
    term: &'a Term,
    app_symbol: &Symbol,
) -> Option<(Symbol, Vec<&'a Term>)> {
    let mut arguments = Vec::new();
    let mut head = term;
    loop {
        match head {
            Term::App { symbol, args } if symbol == app_symbol && args.len() == 2 => {
                arguments.push(&args[1]);
                head = &args[0];
            }
            Term::App { symbol, args } if args.is_empty() => {
                arguments.reverse();
                return Some((symbol.clone(), arguments));
            }
            _ => return None,
        }
    }
}

fn uncurry_term(term: &Term, app_symbol: &Symbol, occupied: &BTreeSet<Symbol>) -> Term {
    if let Some((head, arguments)) = flatten_applicative_term(term, app_symbol) {
        let symbol = uncurried_symbol(&head, arguments.len(), occupied);
        return Term::App {
            symbol,
            args: arguments
                .into_iter()
                .map(|argument| uncurry_term(argument, app_symbol, occupied))
                .collect(),
        };
    }
    match term {
        Term::Var(variable) => Term::Var(variable.clone()),
        Term::App { symbol, args } => Term::App {
            symbol: symbol.clone(),
            args: args
                .iter()
                .map(|arg| uncurry_term(arg, app_symbol, occupied))
                .collect(),
        },
    }
}

fn build_uncurry_rules(app_symbol: &Symbol, entries: &[UncurriedSymbolEntry]) -> Vec<RewriteRule> {
    let mut rules = Vec::new();
    for entry in entries {
        for application in 0..entry.symbols.len().saturating_sub(1) {
            let prefix_variables = (0..application)
                .map(|index| Term::var(format!("x{index}")))
                .collect::<Vec<_>>();
            let next_argument = Term::var("y");
            let lhs_head = Term::App {
                symbol: entry.symbols[application].clone(),
                args: prefix_variables.clone(),
            };
            let mut rhs_args = prefix_variables;
            rhs_args.push(next_argument.clone());
            rules.push(RewriteRule::new(
                Term::App {
                    symbol: app_symbol.clone(),
                    args: vec![lhs_head, next_argument],
                },
                Term::App {
                    symbol: entry.symbols[application + 1].clone(),
                    args: rhs_args,
                },
            ));
        }
    }
    rules
}

fn uncurried_symbol(symbol: &Symbol, application: usize, occupied: &BTreeSet<Symbol>) -> Symbol {
    if application == 0 {
        return symbol.clone();
    }
    let base = format!("{}{application}", symbol.as_str());
    let candidate = Symbol::new(base.clone());
    if !occupied.contains(&candidate) {
        return candidate;
    }
    let mut suffix = 0usize;
    loop {
        let candidate = Symbol::new(format!("{base}_{suffix}"));
        if !occupied.contains(&candidate) {
            return candidate;
        }
        suffix += 1;
    }
}
