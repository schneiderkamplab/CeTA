use super::super::super::processors::relative_adp::{RelativeAdpProof, RelativeAdpProofTree};
use super::super::super::{DpProofTree, Proof, ProofStep};
use super::super::{
    ProblemCertificate, ProblemState, ProcessorApplication, ProcessorResult, WorklistProcessor,
};

pub struct EmptySystemProcessor;

impl WorklistProcessor for EmptySystemProcessor {
    fn name(&self) -> &'static str {
        "empty-system"
    }

    fn apply(&self, state: &ProblemState) -> ProcessorResult {
        let certificate = match state {
            ProblemState::Trs(trs) | ProblemState::Srs(trs) if trs.is_empty() => {
                ProblemCertificate::Trs(Proof::terminating(vec![ProofStep::EmptySystem]))
            }
            ProblemState::Csr(state) if state.csr.rules().is_empty() => {
                ProblemCertificate::Trs(Proof::terminating(vec![ProofStep::EmptySystem]))
            }
            ProblemState::RelativeTrs(relative) | ProblemState::RelativeSrs(relative)
                if relative.strict().is_empty() =>
            {
                ProblemCertificate::Trs(Proof::terminating(vec![ProofStep::EmptySystem]))
            }
            ProblemState::DependencyPairs(problem)
                if problem.stats.strict_rules.is_empty()
                    && (problem.pairs.is_empty()
                        || problem
                            .pairs
                            .iter()
                            .all(|pair| problem.stats.weak_pairs.contains(pair))) =>
            {
                ProblemCertificate::DependencyPairTree(DpProofTree::Empty)
            }
            ProblemState::RelativeAnnotatedDependencyPairs(state)
                if state.problem.main.is_empty() && !state.graph_pending =>
            {
                ProblemCertificate::RelativeAnnotatedDependencyPairs(RelativeAdpProof {
                    canonical: state.problem.clone(),
                    proof: RelativeAdpProofTree::Empty,
                })
            }
            _ => return ProcessorResult::Inapplicable,
        };
        ProcessorResult::Applied(ProcessorApplication::solved(certificate))
    }
}

#[cfg(test)]
mod tests {
    use std::collections::BTreeSet;

    use crate::core::{RewriteStrategy, Term, Trs};
    use crate::proving::dependency_pairs::{DependencyPair, DpOptions};
    use crate::proving::processors::dp::DpProblemState;

    use super::*;

    #[test]
    fn closes_dependency_pair_obligation_when_every_pair_is_weak() {
        let pair = DependencyPair::new_for_test(
            Term::app("f#", vec![Term::var("x")]),
            Term::app("g#", vec![Term::var("x")]),
        );
        let trs = Trs::new_with_strategy(None, BTreeSet::new(), Vec::new(), RewriteStrategy::Full);
        let mut problem = DpProblemState::ordinary(trs, vec![pair.clone()], DpOptions::default());
        problem.stats.weak_pairs.push(pair);

        assert!(matches!(
            EmptySystemProcessor.apply(&ProblemState::DependencyPairs(problem)),
            ProcessorResult::Applied(_)
        ));
    }

    #[test]
    fn does_not_close_generalized_dp_obligation_with_a_strict_rule() {
        let pair = DependencyPair::new_for_test(
            Term::app("f#", vec![Term::var("x")]),
            Term::app("g#", vec![Term::var("x")]),
        );
        let strict_rule = crate::core::RewriteRule::new(
            Term::app("f", vec![Term::var("x")]),
            Term::app("g", vec![Term::var("x")]),
        );
        let trs = Trs::new_with_strategy(
            None,
            BTreeSet::new(),
            vec![strict_rule.clone()],
            RewriteStrategy::Full,
        );
        let mut problem = DpProblemState::ordinary(trs, vec![pair.clone()], DpOptions::default())
            .with_strict_rules(vec![strict_rule]);
        problem.stats.weak_pairs.push(pair);

        assert!(matches!(
            EmptySystemProcessor.apply(&ProblemState::DependencyPairs(problem)),
            ProcessorResult::Inapplicable
        ));
    }
}
