use super::super::{
    ProblemCertificate, ProblemState, ProcessorApplication, ProcessorResult, WorklistProcessor,
};
use super::srs::{srs_word_to_term, strict_srs_word_with_tail};
use crate::core::{RewriteRule, RewriteStrategy, Term, Trs};
use crate::proving::{Proof, ProofStep, Status};

#[derive(Default)]
pub struct SrsStripContextsProcessor {
    pub max_prefix: Option<usize>,
    pub max_suffix: Option<usize>,
}

/// Strengthening only: termination of stripped rules implies termination
/// of the originals. Nontermination of the strengthened system proves nothing.
fn stripped_rules(
    rules: &[RewriteRule],
    max_prefix: Option<usize>,
    max_suffix: Option<usize>,
) -> Option<Vec<RewriteRule>> {
    let mut changed = false;
    let result = rules
        .iter()
        .map(|rule| {
            let (lhs, left_tail) = strict_srs_word_with_tail(rule.lhs())?;
            let (rhs, right_tail) = strict_srs_word_with_tail(rule.rhs())?;
            if left_tail != right_tail || lhs.is_empty() {
                return None;
            }
            let prefix = lhs
                .iter()
                .zip(&rhs)
                .take_while(|(a, b)| a == b)
                .count()
                .min(lhs.len() - 1)
                .min(max_prefix.unwrap_or(usize::MAX));
            let lhs = &lhs[prefix..];
            let rhs = &rhs[prefix..];
            let suffix = lhs
                .iter()
                .rev()
                .zip(rhs.iter().rev())
                .take_while(|(a, b)| a == b)
                .count()
                .min(lhs.len() - 1)
                .min(max_suffix.unwrap_or(usize::MAX));
            changed |= prefix + suffix > 0;
            Some(RewriteRule::new(
                srs_word_to_term(&lhs[..lhs.len() - suffix], Term::Var(left_tail)),
                srs_word_to_term(&rhs[..rhs.len() - suffix], Term::Var(right_tail)),
            ))
        })
        .collect::<Option<Vec<_>>>()?;
    changed.then_some(result)
}

impl WorklistProcessor for SrsStripContextsProcessor {
    fn name(&self) -> &'static str {
        "srs-strip-contexts"
    }
    fn apply(&self, state: &ProblemState) -> ProcessorResult {
        let (ProblemState::Trs(trs) | ProblemState::Srs(trs)) = state else {
            return ProcessorResult::Inapplicable;
        };
        if trs.strategy() != RewriteStrategy::Full {
            return ProcessorResult::Inapplicable;
        }
        let Some(rules) = stripped_rules(trs.rules(), self.max_prefix, self.max_suffix) else {
            return ProcessorResult::Inapplicable;
        };
        let child = Trs::new_with_strategy(
            trs.name().map(str::to_owned),
            trs.variables().clone(),
            rules.clone(),
            RewriteStrategy::Full,
        );
        let child = match state {
            ProblemState::Srs(_) => ProblemState::Srs(child),
            _ => ProblemState::Trs(child),
        };
        ProcessorResult::Applied(ProcessorApplication::new(vec![child], move |children| {
            let [ProblemCertificate::Trs(proof)] =
                <[ProblemCertificate; 1]>::try_from(children).ok()?
            else {
                return None;
            };
            if proof.status() != &Status::Terminating {
                return None;
            }
            Some(ProblemCertificate::Trs(Proof::terminating(vec![
                ProofStep::RuleStrengthening {
                    strengthened_rules: rules.clone(),
                    proof: Box::new(proof),
                },
            ])))
        }))
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::core::Symbol;
    fn word(s: &str) -> Term {
        srs_word_to_term(
            &s.chars()
                .map(|c| Symbol::new(c.to_string()))
                .collect::<Vec<_>>(),
            Term::var("x"),
        )
    }
    #[test]
    fn strips_shared_context_and_substitution_without_names() {
        for (l, r, sl, sr) in [("cabd", "cbed", "ab", "be"), ("wxyz", "wyvz", "xy", "yv")] {
            assert_eq!(
                stripped_rules(&[RewriteRule::new(word(l), word(r))], None, None),
                Some(vec![RewriteRule::new(word(sl), word(sr))])
            );
        }
    }
    #[test]
    fn retains_nonempty_left_side_and_refuses_mismatched_variables() {
        assert_eq!(
            stripped_rules(&[RewriteRule::new(word("aaa"), word("aaa"))], None, None),
            Some(vec![RewriteRule::new(word("a"), word("a"))])
        );
        assert!(stripped_rules(
            &[RewriteRule::new(
                word("aba"),
                Term::app("a", vec![Term::var("y")])
            )],
            None,
            None
        )
        .is_none());
        assert!(stripped_rules(&[RewriteRule::new(word("a"), word("b"))], None, None).is_none());
    }
    #[test]
    fn refuses_nontermination_and_unknown_children() {
        let trs = Trs::new(
            None,
            std::collections::BTreeSet::new(),
            vec![RewriteRule::new(word("cabd"), word("cbed"))],
        );
        let ProcessorResult::Applied(application) =
            SrsStripContextsProcessor::default().apply(&ProblemState::Srs(trs))
        else {
            panic!("shared prefix and suffix must yield a child");
        };
        for status in [Status::Unknown, Status::Nonterminating] {
            assert!(application
                .reconstruct(vec![ProblemCertificate::Trs(Proof::with_status(
                    status,
                    vec![]
                ),)])
                .is_none());
        }
    }
    #[test]
    fn does_not_change_innermost_problems() {
        let trs = Trs::new_with_strategy(
            None,
            std::collections::BTreeSet::new(),
            vec![RewriteRule::new(word("cabd"), word("cbed"))],
            RewriteStrategy::Innermost,
        );
        assert!(matches!(
            SrsStripContextsProcessor::default().apply(&ProblemState::Trs(trs)),
            ProcessorResult::Inapplicable
        ));
    }

    #[test]
    fn context_limits_preserve_unselected_prefixes_and_suffixes() {
        let rules = vec![RewriteRule::new(word("aabcdd"), word("aaceedd"))];
        assert_eq!(
            stripped_rules(&rules, Some(0), Some(1)),
            Some(vec![RewriteRule::new(word("aabcd"), word("aaceed"))])
        );
        assert_eq!(
            stripped_rules(&rules, Some(1), Some(0)),
            Some(vec![RewriteRule::new(word("abcdd"), word("aceedd"))])
        );
        assert!(stripped_rules(&rules, Some(0), Some(0)).is_none());
    }

    #[test]
    fn bounded_context_atom_round_trips() {
        use crate::proving::ProveStrategy;
        let atom = "srs-strip-contexts(max-prefix=0,max-suffix=1)";
        let ProveStrategy::Processor(processor) = ProveStrategy::parse(atom).unwrap() else {
            panic!("expected atomic processor");
        };
        assert_eq!(processor.to_strategy_atom(), atom);
        assert!(ProveStrategy::parse("srs-strip-contexts(max-prefix=-1)").is_err());
        assert!(ProveStrategy::parse("srs-strip-contexts(witness=x)").is_err());
    }
}
