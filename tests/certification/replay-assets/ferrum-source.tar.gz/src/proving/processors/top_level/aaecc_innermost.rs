use crate::core::{RewriteStrategy, Trs};
use crate::proving::processors::rewrite_analysis::aaecc_innermost_witness;
use crate::proving::{Proof, ProofStep, Status};

use super::super::{
    ProblemCertificate, ProblemState, ProcessorApplication, ProcessorResult, WorklistProcessor,
};

/// Giesl--Arts' AAECC switch from full to innermost termination.
pub struct AaeccInnermostProcessor;

impl WorklistProcessor for AaeccInnermostProcessor {
    fn name(&self) -> &'static str {
        "aaecc-innermost"
    }

    fn apply(&self, state: &ProblemState) -> ProcessorResult {
        let trs = match state {
            ProblemState::Trs(trs) | ProblemState::Srs(trs)
                if trs.strategy() == RewriteStrategy::Full =>
            {
                trs
            }
            _ => return ProcessorResult::Inapplicable,
        };
        let Some((r1, r2, sigma, wcr_depth)) = aaecc_innermost_witness(trs) else {
            return ProcessorResult::Inapplicable;
        };
        let residual = ProblemState::from_trs(Trs::new_with_strategy(
            trs.name().map(str::to_string),
            trs.variables().clone(),
            trs.rules().to_vec(),
            RewriteStrategy::Innermost,
        ));
        ProcessorResult::Applied(ProcessorApplication::new(vec![residual], move |children| {
            let [ProblemCertificate::Trs(proof)] =
                <[ProblemCertificate; 1]>::try_from(children).ok()?
            else {
                return None;
            };
            if proof.status() != &Status::Terminating {
                return None;
            }
            Some(ProblemCertificate::Trs(Proof::terminating(vec![
                ProofStep::AaeccInnermost {
                    r1: r1.clone(),
                    r2: r2.clone(),
                    sigma: sigma.clone(),
                    wcr_depth,
                    proof: Box::new(proof),
                },
            ])))
        }))
    }
}
