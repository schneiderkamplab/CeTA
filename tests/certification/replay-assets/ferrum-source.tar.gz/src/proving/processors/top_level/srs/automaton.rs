use std::collections::{BTreeMap, BTreeSet, VecDeque};

#[cfg(test)]
mod strict_path_tests {
    use super::*;

    #[test]
    fn fresh_rfc_paths_validate_renamings_and_reject_loops_and_limits() {
        for (a, b) in [("a", "b"), ("renamed_left", "renamed_right")] {
            let rules = [crate::core::SrsRule::new_for_test(vec![a], vec![b, b])];
            let deadline = Some(Instant::now() + std::time::Duration::from_secs(2));
            let completion = complete_fresh_rfc_paths(&rules, 2, 256, 4096, deadline).unwrap();
            let tails = completion.tail_states.iter().cloned().collect();
            let validator = SrsMatchAutomatonBuilder::from_completion_for_validation(completion, 256, 4096).unwrap();
            assert!(validator.has_no_rfc_top_redex_at_bound(&rules, 2));
            assert!(validator.is_rfc_matchbox_closed(&rules));
            assert!(validator.is_rfc_matchbox_ext_right_from_tail_states(&rules, &tails));
            assert_eq!(validator.is_rfc_matchbox_below_top_strict_compatible(&rules, 2, deadline), Some(true));
            assert!(complete_fresh_rfc_paths(&rules, 2, 1, 1, deadline).is_none());
            assert!(complete_fresh_rfc_paths(&rules, 2, 256, 4096, Some(Instant::now())).is_none());
            let looping = [crate::core::SrsRule::new_for_test(vec![a], vec![a])];
            assert!(complete_fresh_rfc_paths(&looping, 2, 256, 4096, deadline).is_none());
        }
    }

    #[test]
    fn full_rfc_deletion_tries_reached_layers_and_checks_obligations() {
        let rules = [crate::core::SrsRule::new_for_test(vec!["a"], vec!["b", "b"])];
        let deadline = Some(Instant::now() + std::time::Duration::from_secs(10));
        let barren = SrsRfcBarrenBuilder::new_with_limits(&rules, 3, 256, 4096)
            .unwrap().complete_all_rule_removal(SrsRfcBarrenClosure::Right, deadline).unwrap();
        assert_eq!(barren.removed_rule_indices(), [0]);
        let completion = barren.into_direct_layered_completion(&[0], &[], 256, 4096, deadline).unwrap();
        let validator = SrsMatchAutomatonBuilder::from_completion_for_validation(completion, 256, 4096).unwrap();
        assert!(validator.has_no_rfc_top_redex_at_bound(&rules, 3));
        assert!(validator.is_rfc_matchbox_closed(&rules));
        assert_eq!(validator.is_rfc_matchbox_below_top_strict_compatible(&rules, 3, deadline), Some(true));
        assert!(validator.transitions.iter().all(|transition| transition.height == 0));
    }

    #[test]
    fn rfc_partial_deletion_checks_kept_rule_right_extensions() {
        let removed = crate::core::SrsRule::new_for_test(vec!["d"], vec!["e"]);
        let kept = crate::core::SrsRule::new_for_test(vec!["a", "b"], vec!["c"]);
        let mut a = SrsMatchAutomatonBuilder::empty(16, 64);
        a.insert_transition("a", 0, "q0", "q1");
        a.ensure_identity_state_compatibility();
        let tails = BTreeSet::from(["q0".to_owned()]);
        assert!(a.is_rfc_matchbox_ext_right_from_tail_states(std::slice::from_ref(&removed), &tails));
        assert!(!a.is_rfc_matchbox_ext_right_from_tail_states(&[removed.clone(), kept.clone()], &tails));
        a.insert_transition("c", 0, "q0", "q1");
        assert!(a.is_rfc_matchbox_ext_right_from_tail_states(&[removed, kept], &tails));
    }

    #[test]
    fn rfc_partial_weak_mixed_height_is_not_maximum_height() {
        let rule = crate::core::SrsRule::new_for_test(vec!["a", "b"], vec!["c"]);
        let mut a = SrsMatchAutomatonBuilder::empty(16, 64);
        a.insert_transition("b", 0, "q0", "q1");
        a.insert_transition("a", 2, "q1", "q2");
        a.insert_transition("c", 2, "q0", "q2");
        assert_eq!(a.is_match_bounds_weak_compatible(std::slice::from_ref(&rule), None), Some(true));
        assert_eq!(a.is_ceta_relative_match_bounds_weak_compatible(std::slice::from_ref(&rule), 2, true, None), Some(false));
        a.insert_transition("c", 1, "q0", "q2");
        assert_eq!(a.is_ceta_relative_match_bounds_weak_compatible(&[rule], 2, true, None), Some(true));
    }

    #[test]
    fn compact_rhs_shares_suffixes_without_losing_requested_paths() {
        let mut a = SrsMatchAutomatonBuilder::empty(128, 1024);
        a.compact_rhs_states = Some(BTreeMap::new());
        let word = vec![Symbol::new("a"), Symbol::new("b"), Symbol::new("c")];
        let tail1 = a.fresh_state().unwrap();
        let tail2 = a.fresh_state().unwrap();
        assert_eq!(a.add_rhs_path(&word, 2, &tail1, "q0"), Some(true));
        let states = a.states.len();
        assert_eq!(a.add_rhs_path(&word, 2, &tail2, "q0"), Some(true));
        assert_eq!(a.states.len(), states);
        for tail in [&tail1, &tail2] {
            assert!(a.word_reaches_at_height(&word, 2, tail, "q0"));
            assert!(!a.word_reaches_at_height(&word, 1, tail, "q0"));
        }
    }

    #[test]
    fn indexed_weak_completion_matches_live_completion_with_epsilon_edges() {
        let mut initial = SrsMatchAutomatonBuilder::empty(256, 4096);
        let q1 = initial.fresh_state().unwrap();
        let q2 = initial.fresh_state().unwrap();
        for tail in ["q0", q1.as_str(), q2.as_str()] {
            for head in ["q0", q1.as_str(), q2.as_str()] {
                for height in 0..=2 {
                    initial.insert_transition("a", height, tail, head);
                }
            }
        }
        initial.insert_epsilon(&q1, &q2).unwrap();
        initial.insert_transition("b", 1, "q0", &q1);
        let rules = [crate::core::SrsRule::from_words(
            vec![Symbol::new("a")], vec![Symbol::new("b"), Symbol::new("b")],
        )];
        let mut plain = initial.clone();
        let mut indexed = initial;
        let deadline = Some(Instant::now() + std::time::Duration::from_secs(10));
        let expected = plain.ensure_match_bounds_weak_compatibility_indexed(&rules, 2, true, deadline, false);
        let actual = indexed.ensure_match_bounds_weak_compatibility_indexed(&rules, 2, true, deadline, true);
        assert_eq!(expected, Some(true));
        assert_eq!(actual, expected);
        assert_eq!(indexed.transitions, plain.transitions);
        assert_eq!(indexed.state_transitions, plain.state_transitions);
        assert_eq!(indexed.states, plain.states);
        assert_eq!(indexed.is_ceta_relative_match_bounds_weak_compatible(&rules, 2, true, deadline), Some(true));
        assert_eq!(indexed.ensure_match_bounds_weak_compatibility_indexed(&rules, 2, true, deadline, true), Some(false));
    }

    #[test]
    fn indexed_weak_completion_caches_new_paths_without_changing_completion() {
        let mut initial = SrsMatchAutomatonBuilder::empty(2048, 32768);
        let mut states = vec!["q0".to_owned()];
        for _ in 0..7 { states.push(initial.fresh_state().unwrap()); }
        for (i, tail) in states.iter().enumerate() {
            initial.insert_epsilon(tail, &states[(i + 1) % states.len()]).unwrap();
            for head in &states {
                for height in 0..=2 { initial.insert_transition("a", height, tail, head); }
            }
        }
        let rules = [crate::core::SrsRule::new_for_test(vec!["a"], vec!["b", "b"])];
        let mut plain = initial.clone();
        let mut indexed = initial;
        let deadline = Some(Instant::now() + std::time::Duration::from_secs(30));
        assert_eq!(plain.ensure_match_bounds_weak_compatibility_indexed(&rules, 2, true, deadline, false), Some(true));
        assert_eq!(indexed.ensure_match_bounds_weak_compatibility_indexed(&rules, 2, true, deadline, true), Some(true));
        assert_eq!(indexed.transitions, plain.transitions);
        assert_eq!(indexed.state_transitions, plain.state_transitions);
        assert_eq!(indexed.states, plain.states);
        assert_eq!(indexed.is_ceta_relative_match_bounds_weak_compatible(&rules, 2, true, deadline), Some(true));
    }

    #[test]
    fn indexed_rfc_validation_matches_unindexed_with_relations_and_mutations() {
        let mut a = SrsMatchAutomatonBuilder::empty(32, 512);
        let q1 = a.fresh_state().unwrap();
        let q2 = a.fresh_state().unwrap();
        a.insert_epsilon("q0", &q1).unwrap();
        let rules = [
            crate::core::SrsRule::new_for_test(vec!["a", "b"], vec!["b", "a"]),
            crate::core::SrsRule::new_for_test(vec!["b", "b"], vec!["a"]),
            crate::core::SrsRule::new_for_test(vec!["a"], Vec::<&str>::new()),
        ];
        for round in 0..3 {
            let states = ["q0", q1.as_str(), q2.as_str()];
            for (i, tail) in states.iter().enumerate() {
                for (j, head) in states.iter().enumerate() {
                    a.insert_transition(if (i + j + round) % 2 == 0 {"a"} else {"b"}, 0, tail, head);
                }
            }
            if round == 1 { a.ensure_identity_state_compatibility(); }
            if round == 2 { a.state_compatibility.insert((q1.clone(), q2.clone())); }
            for rule in &rules {
                let rules = std::slice::from_ref(rule);
                assert_eq!(a.is_rfc_matchbox_closed(rules), a.is_rfc_matchbox_closed_unindexed(rules));
                for tails in [a.states.clone(), BTreeSet::from([q1.clone(), "absent".into()])] {
                    assert_eq!(a.is_rfc_matchbox_ext_right_from_tail_states(rules, &tails),
                        a.is_rfc_matchbox_ext_right_from_tail_states_unindexed(rules, &tails));
                }
                for bound in 0..=2 {
                    let strict = a.strict_paths_for_word(rule.lhs(), None).unwrap().iter().all(|path| {
                        let minimum = path.heights.iter().min().copied().unwrap_or(bound);
                        minimum >= bound || a.states.iter().any(|head|
                            a.word_reaches_at_height(rule.rhs(), minimum + 1, &path.tail, head)
                            && a.state_compatibility_contains(&path.head, head))
                    });
                    assert_eq!(a.is_rfc_matchbox_below_top_strict_compatible(rules, bound, None), Some(strict));
                    let no_top = a.states.iter().all(|tail| a.exact_heads_for_word(rule.lhs(), bound, tail).is_empty());
                    assert_eq!(a.has_no_rfc_top_redex_at_bound(rules, bound), no_top);
                    for cap in [false, true] {
                        let expected = a.weak_paths_for_word(rule.lhs(), None).unwrap().iter().all(|path| {
                            match_bounds_weak_rhs_height(rule, path, bound, cap).is_some_and(|height|
                                height <= bound && a.word_reaches_at_height(rule.rhs(), height, &path.tail, &path.head))
                        });
                        assert_eq!(a.is_ceta_relative_match_bounds_weak_compatible(rules, bound, cap, None), Some(expected));
                    }
                }
            }
        }
    }

    #[test]
    fn indexed_fixed_height_reachability_matches_live_epsilon_reachability() {
        let mut a = SrsMatchAutomatonBuilder::empty(32, 128);
        let q1 = a.fresh_state().unwrap();
        let q2 = a.fresh_state().unwrap();
        a.insert_epsilon("q0", &q1).unwrap();
        a.insert_epsilon(&q2, "q0").unwrap();
        for height in 0..=2 {
            a.insert_transition("a", height, &q1, &q2);
            a.insert_transition("b", height, &q2, &q1);
        }
        let index = SrsMatchWordIndex::new(&a);
        for word in ["", "a", "b", "aa", "ab", "ba", "bb", "aba"] {
            let word = word.chars().map(|c| Symbol::new(c.to_string())).collect::<Vec<_>>();
            for height in 0..=3 {
                for (tail, tail_name) in index.states.iter().enumerate() {
                    let heads = index.exact_head_bits(&word, height, tail);
                    for (head, head_name) in index.states.iter().enumerate() {
                        assert_eq!(heads[head / 64] & (1u64 << (head % 64)) != 0,
                            a.word_reaches_at_height(&word, height, tail_name, head_name));
                    }
                }
            }
        }
    }

    #[test]
    fn bidirectional_completion_closes_growing_binary_word_system() {
        let word = |s: &str| s.chars().map(|c| Symbol::new(c.to_string())).collect();
        let rules = vec![(
            crate::core::SrsRule::from_words(word("aabaaba"), word("abaabaaab")),
            true,
        )];
        let symbols = BTreeMap::from([("a".to_string(), 1), ("b".to_string(), 1)]);
        let deadline = Some(Instant::now() + std::time::Duration::from_secs(10));
        for bound in 3..=8 {
            let mut builder = SrsMatchAutomatonBuilder::accepting_all_ground_strings(
                &symbols, 100_000, 1_000_000,
            );
            builder.bidirectional_rhs = true;
            let result = complete_srs_match_bounds_completion_from_builder(
                builder,
                rules.clone(),
                bound,
                100_000,
                1_000_000,
                SrsMatchAtBound::Exact,
                deadline,
            );
            if result.is_some() {
                return;
            }
        }
        panic!("completion did not close");
    }

    #[test]
    fn bidirectional_rhs_reuses_both_ends_at_the_requested_height() {
        let mut builder = SrsMatchAutomatonBuilder::empty(32, 64);
        builder.bidirectional_rhs = true;
        builder.insert_transition("right", 2, "q0", "p");
        builder.insert_transition("left", 2, "s", "q0");
        builder.insert_transition("middle", 1, "p", "s");
        let word = ["left", "middle", "right"].map(Symbol::new);
        let states = builder.states.len();
        assert!(builder.add_rhs_path(&word, 2, "q0", "q0").unwrap());
        assert_eq!(builder.states.len(), states);
        assert!(builder.word_reaches_at_height(&word, 2, "q0", "q0"));
        assert!(!builder.word_reaches_at_height(&word, 1, "q0", "q0"));
        assert!(!builder.add_rhs_path(&word, 2, "q0", "q0").unwrap());
    }

    #[test]
    fn minimum_height_paths_equal_exhaustive_runs_with_epsilon_and_branching() {
        let mut automaton = SrsMatchAutomatonBuilder::empty(128, 1024);
        let q1 = automaton.fresh_state().unwrap();
        let q2 = automaton.fresh_state().unwrap();
        for tail in ["q0", q1.as_str(), q2.as_str()] {
            for head in ["q0", q1.as_str(), q2.as_str()] {
                for height in 0..3 {
                    automaton.insert_transition("letter", height, tail, head);
                }
            }
        }
        automaton.insert_epsilon(&q1, &q2).unwrap();
        for length in 0..=4 {
            let word = vec![Symbol::new("letter"); length];
            let exhaustive = automaton.paths_for_word(&word, usize::MAX, None).unwrap();
            let compact = automaton.strict_paths_for_word(&word, None).unwrap();
            let maximum = automaton.maximum_height_paths_for_word(&word, None).unwrap();
            let weak = automaton.weak_paths_for_word(&word, None).unwrap();
            let weak_projection = |paths: &[SrsMatchPath]| paths.iter().map(|p| (
                p.tail.clone(), p.head.clone(), p.heights.iter().min().copied(),
                p.heights.iter().max().copied(),
            )).collect::<BTreeSet<_>>();
            assert_eq!(weak_projection(&exhaustive), weak_projection(&weak));
            assert_eq!(weak.len(), weak_projection(&weak).len());
            let max_projection = |paths: &[SrsMatchPath]| paths.iter().map(|p| (
                p.tail.clone(), p.head.clone(), p.heights.iter().max().copied(),
            )).collect::<BTreeSet<_>>();
            assert_eq!(max_projection(&exhaustive), max_projection(&maximum));
            assert_eq!(maximum.len(), max_projection(&maximum).len());
            let projection = |paths: &[SrsMatchPath]| {
                paths
                    .iter()
                    .map(|p| {
                        (
                            p.tail.clone(),
                            p.head.clone(),
                            p.heights.iter().min().copied(),
                        )
                    })
                    .collect::<BTreeSet<_>>()
            };
            assert_eq!(projection(&exhaustive), projection(&compact));
            assert_eq!(compact.len(), projection(&compact).len());
            let rule = crate::core::SrsRule::from_words(word.clone(), word.clone());
            for bound in 0..=3 {
                let expected = exhaustive.iter().all(|p| {
                    p.heights.iter().min().copied().is_none_or(|height| {
                        height >= bound || automaton.states.iter().any(|head| {
                            automaton.word_reaches_at_height(rule.rhs(), height + 1, &p.tail, head)
                                && automaton.state_compatibility_contains(&p.head, head)
                        })
                    })
                });
                assert_eq!(automaton.is_rfc_matchbox_below_top_strict_compatible(
                    std::slice::from_ref(&rule), bound, None), Some(expected));
            }
            if length >= 2 {
                assert!(compact.len() < exhaustive.len());
            }
        }
        assert!(
            automaton
                .strict_paths_for_word(&[Symbol::new("missing")], None)
                .unwrap()
                .is_empty()
        );
    }

    #[test]
    fn minimum_height_paths_respect_expired_deadline() {
        let automaton = SrsMatchAutomatonBuilder::empty(8, 8);
        assert!(
            automaton
                .strict_paths_for_word(&[], Some(Instant::now()))
                .is_none()
        );
        assert!(automaton.maximum_height_paths_for_word(&[], Some(Instant::now())).is_none());
    }
}
use std::time::Instant;

use rayon::prelude::*;

use crate::core::{RewriteRule, Symbol, Term, Trs, Variable};
use crate::proving::processors::rewrite_analysis::{
    apply_substitution, positions_with_subterms, rename_rule_variables, rename_variables,
    replace_subterm_at_position, unify_terms,
};
use crate::proving::runtime::{current_thread_cancelled, write_progress_event};
use crate::proving::{
    BoundsProof, BoundsType, TreeAutomaton, TreeAutomatonTransition, TreeAutomatonTransitionLhs,
};
#[cfg(test)]
use crate::proving::{Proof, ProofStep};

#[cfg(test)]
use super::words::reverse_srs_rules;
use super::words::{srs_word_to_term, strict_srs_word_with_tail};

#[cfg(test)]
const DEFAULT_SRS_MATCH_BOUNDS_MAX_STATES: usize = usize::MAX;
#[cfg(test)]
const DEFAULT_SRS_MATCH_BOUNDS_MAX_TRANSITIONS: usize = usize::MAX;
const DEFAULT_SRS_MATCH_BOUNDS_MAX_PATHS: usize = usize::MAX;
const DEFAULT_SRS_MATCH_BOUNDS_MAX_ITERATIONS: usize = usize::MAX;
const DEFAULT_SRS_RELATIVE_MATCH_BOUNDS_MAX_BATCHES: usize = usize::MAX;

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub enum SrsMatchAtBound {
    Exact,
    Merge,
}

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub enum SrsRfcBarrenClosure {
    Right,
    Full,
}

#[cfg(test)]
mod empty_lhs_tests {
    use super::*;
    use crate::core::Variable;

    #[test]
    fn srs_match_bounds_rejects_empty_left_hand_sides() {
        let make = |lhs, rhs| {
            Trs::new(
                None,
                BTreeSet::from([Variable::new("x")]),
                vec![RewriteRule::new(lhs, rhs)],
            )
        };
        for rhs in [Term::var("x"), Term::app("a", vec![Term::var("x")])] {
            let trs = make(Term::var("x"), rhs);
            assert!(prove_srs_by_match_bounds_completion(&trs, 3).is_none());
        }
        // A valid automaton must not validate an empty lhs in the live rules.
        let deleting = make(Term::app("a", vec![Term::var("x")]), Term::var("x"));
        let bounds =
            prove_srs_by_match_bounds_completion_with_limits(&deleting, 0, 100, 1000, None)
                .unwrap();
        let invalid = make(Term::var("x"), Term::app("a", vec![Term::var("x")]));
        assert!(!checked_srs_match_bounds_proof(&invalid, &bounds, None));
        let invalid_rules = invalid.srs_rules().unwrap();
        let valid_rules = deleting.srs_rules().unwrap();
        assert!(!checked_srs_relative_match_bounds_proof(
            &invalid_rules,
            &[],
            &bounds,
            None
        ));
        assert!(!checked_srs_relative_match_bounds_proof(
            &valid_rules,
            &invalid_rules,
            &bounds,
            None
        ));
    }
}

#[cfg(test)]
pub(crate) fn prove_srs_by_match_bounds_completion(trs: &Trs, max_bound: usize) -> Option<Proof> {
    let bounds = prove_srs_by_match_bounds_completion_with_limits(
        trs,
        max_bound,
        DEFAULT_SRS_MATCH_BOUNDS_MAX_STATES,
        DEFAULT_SRS_MATCH_BOUNDS_MAX_TRANSITIONS,
        None,
    )?;
    Some(Proof::terminating(vec![ProofStep::Bounds {
        proof: bounds,
    }]))
}

pub(crate) fn prove_srs_by_match_bounds_completion_with_limits(
    trs: &Trs,
    max_bound: usize,
    max_states: usize,
    max_transitions: usize,
    deadline: Option<Instant>,
) -> Option<BoundsProof> {
    for bound in 0..=max_bound {
        if current_thread_cancelled() || deadline.is_some_and(|limit| Instant::now() >= limit) {
            return None;
        }
        if let Some(proof) =
            prove_srs_by_match_bounds_with_limits(trs, bound, max_states, max_transitions, deadline)
        {
            return Some(proof);
        }
    }
    None
}

pub(crate) fn checked_srs_match_bounds_proof(
    trs: &Trs,
    proof: &BoundsProof,
    deadline: Option<Instant>,
) -> bool {
    if proof.bounds_type != BoundsType::Match
        || proof.final_states.is_empty()
        || proof.automaton.final_states.is_empty()
        || proof.automaton.transitions.iter().any(|transition| {
            matches!(
                &transition.lhs,
                TreeAutomatonTransitionLhs::Symbol {
                    height: Some(height),
                    ..
                } if *height > proof.bound
            )
        })
    {
        return false;
    }
    let Some(rules) = trs
        .srs_rules()
        .filter(|rules| !rules.is_empty() && rules.iter().all(|rule| !rule.lhs().is_empty()))
    else {
        return false;
    };
    let completion = SrsMatchCompletion {
        automaton: proof.automaton.clone(),
        tail_states: proof.final_states.clone(),
        state_compatibility: proof.state_compatibility.clone(),
    };
    let Some(automaton) = SrsMatchAutomatonBuilder::from_completion_for_validation(
        completion,
        usize::MAX,
        usize::MAX,
    ) else {
        return false;
    };
    if proof
        .final_states
        .iter()
        .any(|state| !automaton.states.contains(state))
    {
        return false;
    }
    let symbols = rules
        .iter()
        .flat_map(|rule| rule.lhs().iter().chain(rule.rhs()))
        .collect::<BTreeSet<_>>();
    if proof.final_states.iter().any(|tail| {
        symbols.iter().any(|symbol| {
            !automaton.word_reaches_at_height(std::slice::from_ref(*symbol), 0, tail, tail)
        })
    }) {
        return false;
    }
    automaton
        .is_match_bounds_strict_compatible(&rules, proof.bound, deadline)
        .unwrap_or(false)
}

/// Recover a unary candidate from a ranked cons-encoded bounds witness,
/// independently validate it, then use the existing ranked lifting route.
/// The supplied ranked automaton is only candidate data, not trusted evidence.
pub(crate) fn reconstruct_cons_match_bounds_proof(
    trs: &Trs,
    witness: &BoundsProof,
    deadline: Option<Instant>,
) -> Option<BoundsProof> {
    let (constructor, letters, rules) = cons_encoded_srs_rules(trs)?;
    let rename = |state: &str| format!("unlift_{state}");
    let mut transitions = Vec::new();
    for transition in &witness.automaton.transitions {
        if current_thread_cancelled() || deadline.is_some_and(|limit| Instant::now() >= limit) {
            return None;
        }
        match &transition.lhs {
            TreeAutomatonTransitionLhs::State(source) => {
                transitions.push(TreeAutomatonTransition {
                    lhs: TreeAutomatonTransitionLhs::State(rename(source)),
                    rhs: rename(&transition.rhs),
                })
            }
            TreeAutomatonTransitionLhs::Symbol {
                symbol,
                height: Some(height),
                args,
            } if symbol == constructor.as_str() && args.len() == 2 => {
                for letter_transition in &witness.automaton.transitions {
                    let TreeAutomatonTransitionLhs::Symbol {
                        symbol,
                        height: Some(letter_height),
                        args: letter_args,
                    } = &letter_transition.lhs
                    else {
                        continue;
                    };
                    if letter_args.is_empty()
                        && letter_height == height
                        && letter_transition.rhs == args[0]
                        && letters.contains(&Symbol::new(symbol))
                    {
                        transitions.push(TreeAutomatonTransition {
                            lhs: TreeAutomatonTransitionLhs::Symbol {
                                symbol: symbol.clone(),
                                height: Some(*height),
                                args: vec![rename(&args[1])],
                            },
                            rhs: rename(&transition.rhs),
                        });
                    }
                }
            }
            _ => {}
        }
    }
    let unary_trs = Trs::new(
        None,
        BTreeSet::from([Variable::new("tail")]),
        rules
            .iter()
            .map(|rule| {
                RewriteRule::new(
                    srs_word_to_term(rule.lhs(), Term::var("tail")),
                    srs_word_to_term(rule.rhs(), Term::var("tail")),
                )
            })
            .collect(),
    );
    // Ranked witnesses repeat a constant transition for every associated
    // constructor transition. Their cross-product must not multiply identical
    // unary transitions (or the reconstructed certificate) quadratically.
    let mut seen = BTreeSet::new();
    transitions.retain(|transition| seen.insert(serde_json::to_string(transition).unwrap()));
    let candidate = BoundsProof {
        bounds_type: witness.bounds_type.clone(),
        bound: witness.bound,
        final_states: witness
            .final_states
            .iter()
            .map(|state| rename(state))
            .collect(),
        automaton: TreeAutomaton {
            final_states: witness
                .automaton
                .final_states
                .iter()
                .map(|state| rename(state))
                .collect(),
            transitions,
        },
        state_compatibility: witness
            .state_compatibility
            .iter()
            .map(|(a, b)| (rename(a), rename(b)))
            .collect(),
    };
    if !checked_srs_match_bounds_proof(&unary_trs, &candidate, deadline) {
        return None;
    }
    let completion = lift_cons_encoded_match_bounds_completion(
        SrsMatchCompletion {
            automaton: candidate.automaton,
            tail_states: candidate.final_states,
            state_compatibility: candidate.state_compatibility,
        },
        &constructor,
        &letters,
        usize::MAX,
    )?;
    Some(BoundsProof {
        bounds_type: candidate.bounds_type,
        bound: candidate.bound,
        final_states: completion.tail_states,
        automaton: completion.automaton,
        state_compatibility: completion.state_compatibility,
    })
}

pub(crate) fn checked_srs_relative_match_bounds_proof(
    strict_rules: &[crate::core::SrsRule],
    weak_rules: &[crate::core::SrsRule],
    proof: &BoundsProof,
    deadline: Option<Instant>,
) -> bool {
    let trace_rejection = |reason: &str| {
        if std::env::var_os("FERRUM_WORKLIST_TRACE").is_some() {
            eprintln!("exact relative match-bounds rejected: {reason}");
        }
        false
    };
    if strict_rules.is_empty()
        || strict_rules
            .iter()
            .chain(weak_rules)
            .any(|rule| rule.lhs().is_empty())
        || proof.bounds_type != BoundsType::Match
        || proof.final_states.is_empty()
        || proof.automaton.final_states.is_empty()
        || proof.automaton.transitions.iter().any(|transition| {
            matches!(
                &transition.lhs,
                TreeAutomatonTransitionLhs::Symbol {
                    height: Some(height),
                    ..
                } if *height > proof.bound
            )
        })
    {
        return trace_rejection("malformed proof or empty strict rules");
    }
    let completion = SrsMatchCompletion {
        automaton: proof.automaton.clone(),
        tail_states: proof.final_states.clone(),
        state_compatibility: proof.state_compatibility.clone(),
    };
    let Some(automaton) = SrsMatchAutomatonBuilder::from_completion_for_validation(
        completion,
        usize::MAX,
        usize::MAX,
    ) else {
        return trace_rejection("automaton reconstruction failed");
    };
    if proof
        .final_states
        .iter()
        .any(|state| !automaton.states.contains(state))
    {
        return trace_rejection("final state is absent from automaton");
    }
    let symbols = strict_rules
        .iter()
        .chain(weak_rules)
        .flat_map(|rule| rule.lhs().iter().chain(rule.rhs()))
        .collect::<BTreeSet<_>>();
    if proof.final_states.iter().any(|tail| {
        symbols.iter().any(|symbol| {
            !automaton.word_reaches_at_height(std::slice::from_ref(*symbol), 0, tail, tail)
        })
    }) {
        return trace_rejection("automaton does not accept every letter from a tail state");
    }
    let strict = automaton
        .is_match_bounds_strict_compatible(strict_rules, proof.bound, deadline)
        .unwrap_or(false);
    if !strict {
        return trace_rejection("strict compatibility failed");
    }
    let cap_weak_heights = strict_rules.iter().all(|rule| !rule.rhs().is_empty());
    if !automaton
        .is_ceta_relative_match_bounds_weak_compatible(
            weak_rules,
            proof.bound,
            cap_weak_heights,
            deadline,
        )
        .unwrap_or(false)
    {
        return trace_rejection("weak compatibility failed");
    }
    true
}

#[cfg(test)]
pub(crate) fn prove_srs_by_reversal_match_bounds_completion(
    trs: &Trs,
    max_bound: usize,
) -> Option<Proof> {
    let reversed_rules = reverse_srs_rules(trs.rules())?;
    let reversed = Trs::new_with_strategy(
        trs.name().map(str::to_string),
        trs.variables().clone(),
        reversed_rules.clone(),
        trs.strategy(),
    );
    let proof = prove_srs_by_match_bounds_completion(&reversed, max_bound)?;
    Some(Proof::terminating(vec![ProofStep::StringReversal {
        reversed_rules,
        reversed_weak_rules: Vec::new(),
        proof: Box::new(proof),
    }]))
}

pub(crate) fn prove_srs_by_match_bounds_with_limits(
    trs: &Trs,
    bound: usize,
    max_states: usize,
    max_transitions: usize,
    deadline: Option<Instant>,
) -> Option<BoundsProof> {
    let completion = if let Some(srs_rules) = trs.srs_rules() {
        if srs_rules.is_empty() {
            return None;
        }
        let mut symbol_arities = BTreeMap::new();
        for (symbol, arity) in trs.arities() {
            if arity > 1 {
                return None;
            }
            symbol_arities.insert(symbol.as_str().to_string(), arity);
        }
        add_srs_word_symbols_to_arities(&srs_rules, &mut symbol_arities);
        complete_srs_match_bounds_completion(
            &srs_rules,
            &symbol_arities,
            bound,
            max_states,
            max_transitions,
            deadline,
        )?
    } else {
        let (constructor, letters, srs_rules) = cons_encoded_srs_rules(trs)?;
        write_progress_event(
            "match-bounds",
            "selected",
            "cons-encoded-srs",
            0,
            &format!(
                "rules={} constructor={} letters={} bound={bound}",
                srs_rules.len(),
                constructor,
                letters.len()
            ),
        );
        let symbol_arities = letters
            .iter()
            .map(|letter| (letter.as_str().to_string(), 1))
            .collect();
        let completion = complete_srs_match_bounds_completion(
            &srs_rules,
            &symbol_arities,
            bound,
            max_states,
            max_transitions,
            deadline,
        )?;
        lift_cons_encoded_match_bounds_completion(
            completion,
            &constructor,
            &letters,
            max_transitions,
        )?
    };
    write_progress_event(
        "match-bounds",
        "completed",
        "exact",
        0,
        &format!(
            "bound={bound} final_states={} transitions={}",
            completion.automaton.final_states.len(),
            completion.automaton.transitions.len()
        ),
    );
    Some(BoundsProof {
        bounds_type: BoundsType::Match,
        bound,
        final_states: completion.tail_states,
        automaton: completion.automaton,
        state_compatibility: completion.state_compatibility,
    })
}

pub(crate) fn cons_encoded_srs_rules(
    trs: &Trs,
) -> Option<(Symbol, BTreeSet<Symbol>, Vec<crate::core::SrsRule>)> {
    let mut constructor = None;
    let mut letters = BTreeSet::new();
    let mut srs_rules = Vec::new();
    for rule in trs.rules() {
        let (lhs, lhs_tail, lhs_constructor) = cons_encoded_word(rule.lhs())?;
        let (rhs, rhs_tail, rhs_constructor) = cons_encoded_word(rule.rhs())?;
        if lhs.is_empty()
            || rhs.is_empty()
            || lhs_tail != rhs_tail
            || lhs_constructor != rhs_constructor
            || constructor
                .as_ref()
                .is_some_and(|constructor| constructor != &lhs_constructor)
        {
            return None;
        }
        constructor = Some(lhs_constructor);
        letters.extend(lhs.iter().cloned());
        letters.extend(rhs.iter().cloned());
        srs_rules.push(crate::core::SrsRule::from_words(lhs, rhs));
    }
    Some((constructor?, letters, srs_rules))
}

pub(crate) fn cons_encoded_word(term: &Term) -> Option<(Vec<Symbol>, Variable, Symbol)> {
    let mut word = Vec::new();
    let mut cursor = term;
    let mut constructor = None;
    loop {
        match cursor {
            Term::Var(variable) => {
                return Some((word, variable.clone(), constructor?));
            }
            Term::App { symbol, args } if args.len() == 2 => {
                if constructor
                    .as_ref()
                    .is_some_and(|constructor| constructor != symbol)
                {
                    return None;
                }
                let Term::App {
                    symbol: letter,
                    args: letter_args,
                } = &args[0]
                else {
                    return None;
                };
                if !letter_args.is_empty() || letter == symbol {
                    return None;
                }
                constructor = Some(symbol.clone());
                word.push(letter.clone());
                cursor = &args[1];
            }
            Term::App { .. } => return None,
        }
    }
}

pub(crate) fn lift_cons_encoded_match_bounds_completion(
    completion: SrsMatchCompletion,
    constructor: &Symbol,
    letters: &BTreeSet<Symbol>,
    max_transitions: usize,
) -> Option<SrsMatchCompletion> {
    let final_state = completion.automaton.final_states.first()?.clone();
    let letter_indices = letters
        .iter()
        .enumerate()
        .map(|(index, letter)| (letter.as_str().to_string(), index))
        .collect::<BTreeMap<_, _>>();
    let mut transitions = Vec::new();
    for transition in completion.automaton.transitions {
        match transition.lhs {
            TreeAutomatonTransitionLhs::State(source) => {
                transitions.push(TreeAutomatonTransition {
                    lhs: TreeAutomatonTransitionLhs::State(source),
                    rhs: transition.rhs,
                });
            }
            TreeAutomatonTransitionLhs::Symbol {
                symbol,
                height: Some(height),
                args,
            } => {
                let [tail] = args.as_slice() else {
                    return None;
                };
                let index = *letter_indices.get(&symbol)?;
                let letter_state = format!("lc{index}_{height}");
                transitions.push(TreeAutomatonTransition {
                    lhs: TreeAutomatonTransitionLhs::Symbol {
                        symbol: symbol.clone(),
                        height: Some(height),
                        args: Vec::new(),
                    },
                    rhs: letter_state.clone(),
                });
                transitions.push(TreeAutomatonTransition {
                    lhs: TreeAutomatonTransitionLhs::Symbol {
                        symbol: constructor.as_str().to_string(),
                        height: Some(height),
                        args: vec![letter_state, tail.clone()],
                    },
                    rhs: transition.rhs,
                });
            }
            TreeAutomatonTransitionLhs::Symbol { .. } => return None,
        }
    }
    for letter in letters {
        transitions.push(TreeAutomatonTransition {
            lhs: TreeAutomatonTransitionLhs::Symbol {
                symbol: letter.as_str().to_string(),
                height: Some(0),
                args: Vec::new(),
            },
            rhs: final_state.clone(),
        });
    }
    transitions.push(TreeAutomatonTransition {
        lhs: TreeAutomatonTransitionLhs::Symbol {
            symbol: constructor.as_str().to_string(),
            height: Some(0),
            args: vec![final_state.clone(), final_state.clone()],
        },
        rhs: final_state.clone(),
    });
    if transitions.len() > max_transitions {
        return None;
    }
    Some(SrsMatchCompletion {
        automaton: TreeAutomaton {
            final_states: completion.automaton.final_states,
            transitions,
        },
        tail_states: completion.tail_states,
        state_compatibility: completion.state_compatibility,
    })
}

pub(crate) fn prove_srs_by_rfc_match_bounds_with_limits(
    trs: &Trs,
    max_bound: usize,
    max_words: usize,
    max_word_len: usize,
    max_states: usize,
    max_transitions: usize,
    at_bound: SrsMatchAtBound,
    _closure: SrsRfcBarrenClosure,
    deadline: Option<Instant>,
) -> Option<SrsRfcMatchBoundsWitness> {
    let srs_rules = trs.srs_rules()?;
    if srs_rules.is_empty() {
        return None;
    }
    if srs_rules
        .iter()
        .any(|rule| rule.lhs().is_empty())
    {
        return None;
    }
    if !strict_srs_rules_are_right_linear(trs) {
        return None;
    }
    let (_, tail) = strict_srs_word_with_tail(trs.rules().first()?.lhs())?;
    let finite_initial_words = if at_bound == SrsMatchAtBound::Exact {
        srs_rfc_initial_words(trs.rules(), &tail, &srs_rules, max_words, max_word_len)
    } else {
        None
    };
    let rhs_initial_words = srs_rules
        .iter()
        .map(|rule| rule.rhs().to_vec())
        .collect::<Vec<_>>();
    let mut symbol_arities = BTreeMap::new();
    add_srs_word_symbols_to_arities(&srs_rules, &mut symbol_arities);
    if finite_initial_words
        .as_ref()
        .is_none_or(|initial_words| initial_words.is_empty())
        && rhs_initial_words.is_empty()
    {
        return None;
    }
    for bound in 0..=max_bound {
        if current_thread_cancelled() || deadline.is_some_and(|limit| Instant::now() >= limit) {
            return None;
        }
        let finite_completion = (at_bound == SrsMatchAtBound::Exact)
            .then(|| {
                finite_initial_words.as_ref().and_then(|initial_words| {
                    complete_srs_match_bounds_completion_for_initial_words(
                        &srs_rules,
                        initial_words,
                        bound,
                        max_states,
                        max_transitions,
                        SrsMatchAtBound::Exact,
                        deadline,
                    )
                    .map(|completion| (completion, initial_words.clone()))
                })
            })
            .flatten();
        let (completion, initial_words, automaton_closed) =
            if let Some((completion, initial_words)) = finite_completion {
                (completion, initial_words, false)
            } else {
                let completion = complete_srs_rfc_match_bounds_universal_completion(
                    &srs_rules,
                    &rhs_initial_words,
                    &symbol_arities,
                    bound,
                    max_states,
                    max_transitions,
                    deadline,
                )
                .or_else(|| {
                    complete_srs_rfc_match_bounds_completion_for_initial_words(
                        &srs_rules,
                        &rhs_initial_words,
                        bound,
                        max_states,
                        max_transitions,
                        SrsMatchAtBound::Exact,
                        deadline,
                    )
                });
                let Some(completion) = completion else {
                    continue;
                };
                (completion, rhs_initial_words.clone(), true)
            };
        let proof = BoundsProof {
            bounds_type: BoundsType::Match,
            bound,
            final_states: completion.tail_states,
            automaton: completion.automaton,
            state_compatibility: completion.state_compatibility,
        };
        return Some(SrsRfcMatchBoundsWitness {
            proof,
            initial_words,
            automaton_closed,
        });
    }
    None
}

/// A checked RFC match-bounds witness.  The search layer returns data, not a
/// recursively nested proof: the worklist processor is the sole owner of the
/// terminal certificate boundary.
pub(crate) struct SrsRfcMatchBoundsWitness {
    pub(crate) proof: BoundsProof,
    pub(crate) initial_words: Vec<Vec<Symbol>>,
    pub(crate) automaton_closed: bool,
}

pub(crate) fn complete_srs_rfc_match_bounds_universal_completion(
    rules: &[crate::core::SrsRule],
    initial_words: &[Vec<crate::core::Symbol>],
    symbol_arities: &BTreeMap<String, usize>,
    bound: usize,
    max_states: usize,
    max_transitions: usize,
    deadline: Option<Instant>,
) -> Option<SrsMatchCompletion> {
    let automaton = SrsMatchAutomatonBuilder::accepting_all_ground_strings(
        symbol_arities,
        max_states,
        max_transitions,
    );
    let completion = complete_srs_match_bounds_completion_from_builder(
        automaton,
        rules.iter().cloned().map(|rule| (rule, true)).collect(),
        bound,
        max_states,
        max_transitions,
        SrsMatchAtBound::Exact,
        deadline,
    )?;
    let validator = SrsMatchAutomatonBuilder::from_completion_for_validation(
        completion,
        max_states,
        max_transitions,
    )?;
    if !validator.accepts_initial_words_from_all_states(initial_words)
        || !validator.is_rfc_automaton_closed(rules)
        || !validator.has_rfc_lhs_suffix_totality(rules)
    {
        return None;
    }
    validator.into_completion()
}

pub(crate) fn complete_srs_rfc_matchbox_one_state_completion(
    rules: &[crate::core::SrsRule],
    initial_words: &[Vec<crate::core::Symbol>],
    bound: usize,
    max_states: usize,
    max_transitions: usize,
    deadline: Option<Instant>,
) -> Option<SrsMatchCompletion> {
    if bound == 0 {
        return None;
    }
    let mut automaton = SrsMatchAutomatonBuilder::empty(max_states, max_transitions);
    let final_state = automaton.final_state.clone();
    let mut symbols = BTreeSet::new();
    for word in initial_words {
        symbols.extend(word.iter().map(|symbol| symbol.as_str().to_string()));
    }
    for rule in rules {
        symbols.extend(rule.lhs().iter().map(|symbol| symbol.as_str().to_string()));
        symbols.extend(rule.rhs().iter().map(|symbol| symbol.as_str().to_string()));
    }
    for symbol in &symbols {
        automaton.insert_transition(symbol, 0, &final_state, &final_state);
    }
    for rule in rules {
        if current_thread_cancelled() || deadline.is_some_and(|limit| Instant::now() >= limit) {
            return None;
        }
        automaton.add_merged_rhs_path_to_final(rule.rhs(), bound, &final_state)?;
    }
    automaton.ensure_identity_state_compatibility();
    if automaton.transitions.len() + automaton.state_transitions.len() > max_transitions {
        return None;
    }
    if !automaton.accepts_initial_words_from_all_states(initial_words)
        || !automaton.is_rfc_matchbox_closed(rules)
        || !automaton.has_rfc_lhs_suffix_totality(rules)
        || !automaton.has_no_rfc_top_redex_at_bound(rules, bound)
    {
        return None;
    }
    automaton.into_completion()
}

impl<'a> SrsRfcBarrenBuilder<'a> {
    #[cfg(test)]
    pub(crate) fn new(rules: &'a [crate::core::SrsRule], bound: usize) -> Self {
        Self::new_with_limits(rules, bound, usize::MAX, usize::MAX)
            .expect("unbounded RFC barren builder should always initialize")
    }

    pub(crate) fn new_with_limits(
        rules: &'a [crate::core::SrsRule],
        bound: usize,
        max_places: usize,
        max_epsilons: usize,
    ) -> Option<Self> {
        let places = rules
            .iter()
            .try_fold(0usize, |acc, rule| acc.checked_add(rule.rhs().len() + 1))?;
        if places > max_places {
            return None;
        }
        Some(Self {
            rules,
            bound,
            top: vec![None; rules.len()],
            epsilons: BTreeSet::new(),
            epsilon_forward: BTreeMap::new(),
            epsilon_backward: BTreeMap::new(),
            max_places,
            max_epsilons,
        })
    }

    pub(crate) fn start_place(&self, level: usize, rule_index: usize) -> SrsRfcBarrenPlace {
        SrsRfcBarrenPlace {
            level,
            rule_index,
            position: 0,
        }
    }

    pub(crate) fn end_place(&self, level: usize, rule_index: usize) -> SrsRfcBarrenPlace {
        SrsRfcBarrenPlace {
            level,
            rule_index,
            position: self.rules[rule_index].rhs().len(),
        }
    }

    pub(crate) fn place_state(place: &SrsRfcBarrenPlace) -> String {
        format!(
            "rfc_{}_{}_{}",
            place.level, place.rule_index, place.position
        )
    }

    pub(crate) fn places(&self) -> Vec<SrsRfcBarrenPlace> {
        let mut places = Vec::new();
        for (rule_index, rule) in self.rules.iter().enumerate() {
            let max_level = self.top[rule_index].unwrap_or(0);
            for level in 0..=max_level {
                for position in 0..=rule.rhs().len() {
                    places.push(SrsRfcBarrenPlace {
                        level,
                        rule_index,
                        position,
                    });
                }
            }
        }
        places
    }

    pub(crate) fn bounded_insert_epsilon(
        &mut self,
        source: SrsRfcBarrenPlace,
        target: SrsRfcBarrenPlace,
    ) -> Option<bool> {
        if self.epsilons.contains(&(source.clone(), target.clone())) {
            return Some(false);
        }
        let mut pre = self.epsilon_preimage(&source);
        pre.insert(source);
        let mut post = self.epsilon_image(&target);
        post.insert(target);
        let possible_additions = pre.len().saturating_mul(post.len());
        if self.epsilons.len().saturating_add(possible_additions) > self.max_epsilons {
            return None;
        }
        let mut changed = false;
        for source in &pre {
            for target in &post {
                if self.epsilons.insert((source.clone(), target.clone())) {
                    self.epsilon_forward
                        .entry(source.clone())
                        .or_default()
                        .insert(target.clone());
                    self.epsilon_backward
                        .entry(target.clone())
                        .or_default()
                        .insert(source.clone());
                    changed = true;
                }
            }
        }
        Some(changed)
    }

    pub(crate) fn epsilon_image(&self, place: &SrsRfcBarrenPlace) -> BTreeSet<SrsRfcBarrenPlace> {
        self.epsilon_forward.get(place).cloned().unwrap_or_default()
    }

    pub(crate) fn epsilon_preimage(
        &self,
        place: &SrsRfcBarrenPlace,
    ) -> BTreeSet<SrsRfcBarrenPlace> {
        self.epsilon_backward
            .get(place)
            .cloned()
            .unwrap_or_default()
    }

    pub(crate) fn epsilon_hull(&self, place: &SrsRfcBarrenPlace) -> BTreeSet<SrsRfcBarrenPlace> {
        let mut hull = self.epsilon_image(place);
        hull.insert(place.clone());
        hull
    }

    pub(crate) fn inverse_epsilon_hull(
        &self,
        place: &SrsRfcBarrenPlace,
    ) -> BTreeSet<SrsRfcBarrenPlace> {
        let mut hull = self.epsilon_preimage(place);
        hull.insert(place.clone());
        hull
    }

    pub(crate) fn next(
        &self,
        place: &SrsRfcBarrenPlace,
        symbol: &crate::core::Symbol,
    ) -> BTreeSet<SrsRfcBarrenPlace> {
        let rhs = self.rules[place.rule_index].rhs();
        if place.position < rhs.len() && &rhs[place.position] == symbol {
            BTreeSet::from([SrsRfcBarrenPlace {
                level: place.level,
                rule_index: place.rule_index,
                position: place.position + 1,
            }])
        } else {
            BTreeSet::new()
        }
    }

    pub(crate) fn next_eps(
        &self,
        place: &SrsRfcBarrenPlace,
        symbol: &crate::core::Symbol,
    ) -> BTreeSet<SrsRfcBarrenPlace> {
        self.next(place, symbol)
            .into_iter()
            .flat_map(|next| self.epsilon_hull(&next))
            .collect()
    }

    pub(crate) fn prev(
        &self,
        place: &SrsRfcBarrenPlace,
        symbol: &crate::core::Symbol,
    ) -> BTreeSet<SrsRfcBarrenPlace> {
        let rhs = self.rules[place.rule_index].rhs();
        if place.position > 0 && &rhs[place.position - 1] == symbol {
            BTreeSet::from([SrsRfcBarrenPlace {
                level: place.level,
                rule_index: place.rule_index,
                position: place.position - 1,
            }])
        } else {
            BTreeSet::new()
        }
    }

    pub(crate) fn prev_eps(
        &self,
        place: &SrsRfcBarrenPlace,
        symbol: &crate::core::Symbol,
    ) -> BTreeSet<SrsRfcBarrenPlace> {
        self.prev(place, symbol)
            .into_iter()
            .flat_map(|previous| self.inverse_epsilon_hull(&previous))
            .collect()
    }

    pub(crate) fn fuzzy_min(
        left: SrsRfcFuzzyHeight,
        right: SrsRfcFuzzyHeight,
    ) -> SrsRfcFuzzyHeight {
        match (left, right) {
            (SrsRfcFuzzyHeight::Finite(left), SrsRfcFuzzyHeight::Finite(right)) => {
                SrsRfcFuzzyHeight::Finite(left.min(right))
            }
            (SrsRfcFuzzyHeight::Finite(height), SrsRfcFuzzyHeight::Infinite)
            | (SrsRfcFuzzyHeight::Infinite, SrsRfcFuzzyHeight::Finite(height)) => {
                SrsRfcFuzzyHeight::Finite(height)
            }
            (SrsRfcFuzzyHeight::Infinite, SrsRfcFuzzyHeight::Infinite) => {
                SrsRfcFuzzyHeight::Infinite
            }
        }
    }

    pub(crate) fn reaches(
        &self,
        place: &SrsRfcBarrenPlace,
        word: &[crate::core::Symbol],
    ) -> BTreeMap<SrsRfcBarrenPlace, SrsRfcFuzzyHeight> {
        let mut current = BTreeMap::from([(place.clone(), SrsRfcFuzzyHeight::Infinite)]);
        for (index, symbol) in word.iter().enumerate() {
            if current.is_empty() {
                return BTreeMap::new();
            }
            let last = index + 1 == word.len();
            let mut next: BTreeMap<SrsRfcBarrenPlace, SrsRfcFuzzyHeight> = BTreeMap::new();
            for (source, height) in current {
                let targets = if last {
                    self.next(&source, symbol)
                } else {
                    self.next_eps(&source, symbol)
                };
                for target in targets {
                    let path_height =
                        Self::fuzzy_min(height, SrsRfcFuzzyHeight::Finite(source.level));
                    next.entry(target)
                        .and_modify(|old| *old = (*old).max(path_height))
                        .or_insert(path_height);
                }
            }
            current = next;
        }
        current
    }

    pub(crate) fn is_final(&self, place: &SrsRfcBarrenPlace) -> bool {
        place.level == 0 && place.position == self.rules[place.rule_index].rhs().len()
    }

    pub(crate) fn is_initial(&self, place: &SrsRfcBarrenPlace) -> bool {
        place.level == 0 && place.position == 0
    }

    pub(crate) fn prefix_reaches_final(
        &self,
        place: &SrsRfcBarrenPlace,
        word: &[crate::core::Symbol],
    ) -> Option<usize> {
        let (first, rest) = word.split_first()?;
        let mut current = self.next_eps(place, first);
        let mut length = 1usize;
        for symbol in rest {
            if current.is_empty() {
                return None;
            }
            if current.iter().any(|place| self.is_final(place)) {
                return Some(length);
            }
            current = current
                .iter()
                .flat_map(|place| self.next_eps(place, symbol))
                .collect();
            length += 1;
        }
        None
    }

    pub(crate) fn suffix_leaves_initial(
        &self,
        place: &SrsRfcBarrenPlace,
        word: &[crate::core::Symbol],
    ) -> Option<usize> {
        let (first, rest) = word.split_last()?;
        let mut current = self.prev_eps(place, first);
        let mut length = 1usize;
        for symbol in rest.iter().rev() {
            if current.is_empty() {
                return None;
            }
            if current.iter().any(|place| self.is_initial(place)) {
                return Some(length);
            }
            current = current
                .iter()
                .flat_map(|place| self.prev_eps(place, symbol))
                .collect();
            length += 1;
        }
        None
    }

    pub(crate) fn wanted_for_ext_right(&self) -> Vec<SrsRfcWantedEpsilons> {
        let mut wanted = Vec::new();
        for (rule_index, rule) in self.rules.iter().enumerate() {
            for redex_start in self.places() {
                let transition = (redex_start.clone(), self.start_place(0, rule_index));
                if self.epsilons.contains(&transition) {
                    continue;
                }
                if self
                    .prefix_reaches_final(&redex_start, rule.lhs())
                    .is_some()
                {
                    wanted.push(SrsRfcWantedEpsilons {
                        rule_index,
                        top_height: None,
                        transitions: vec![transition],
                    });
                }
            }
        }
        wanted
    }

    pub(crate) fn wanted_for_ext_left(&self) -> Vec<SrsRfcWantedEpsilons> {
        let mut wanted = Vec::new();
        for (rule_index, rule) in self.rules.iter().enumerate() {
            for redex_end in self.places() {
                let transition = (redex_end.clone(), self.end_place(0, rule_index));
                if self.epsilons.contains(&transition) {
                    continue;
                }
                if self.suffix_leaves_initial(&redex_end, rule.lhs()).is_some() {
                    wanted.push(SrsRfcWantedEpsilons {
                        rule_index,
                        top_height: None,
                        transitions: vec![transition],
                    });
                }
            }
        }
        wanted
    }

    pub(crate) fn wanted_for_overlap(&self) -> Vec<SrsRfcWantedEpsilons> {
        let mut wanted = Vec::new();
        for (rule_index, rule) in self.rules.iter().enumerate() {
            for redex_start in self.places() {
                let Some(prefix_len) = self.prefix_reaches_final(&redex_start, rule.lhs()) else {
                    continue;
                };
                for redex_end in self.places() {
                    let Some(suffix_len) = self.suffix_leaves_initial(&redex_end, rule.lhs())
                    else {
                        continue;
                    };
                    if prefix_len + suffix_len > rule.lhs().len() {
                        continue;
                    }
                    let transitions = [
                        (redex_start.clone(), self.start_place(0, rule_index)),
                        (self.end_place(0, rule_index), redex_end),
                    ]
                    .into_iter()
                    .filter(|transition| !self.epsilons.contains(transition))
                    .collect::<Vec<_>>();
                    if !transitions.is_empty() {
                        wanted.push(SrsRfcWantedEpsilons {
                            rule_index,
                            top_height: None,
                            transitions,
                        });
                    }
                }
            }
        }
        wanted
    }

    pub(crate) fn wanted_for_inner(&self) -> Vec<SrsRfcWantedEpsilons> {
        let mut wanted = Vec::new();
        for (rule_index, rule) in self.rules.iter().enumerate() {
            for redex_start in self.places() {
                for (redex_end, height) in self.reaches(&redex_start, rule.lhs()) {
                    let SrsRfcFuzzyHeight::Finite(redex_height) = height else {
                        continue;
                    };
                    let top_height = redex_height + 1;
                    let reduct_height = top_height.min(self.bound);
                    let transitions = if rule.rhs().is_empty() {
                        vec![(redex_start.clone(), redex_end)]
                    } else {
                        vec![
                            (
                                redex_start.clone(),
                                self.start_place(reduct_height, rule_index),
                            ),
                            (self.end_place(reduct_height, rule_index), redex_end),
                        ]
                    }
                    .into_iter()
                    .filter(|transition| !self.epsilons.contains(transition))
                    .collect::<Vec<_>>();
                    if !transitions.is_empty() {
                        wanted.push(SrsRfcWantedEpsilons {
                            rule_index,
                            top_height: Some(reduct_height),
                            transitions,
                        });
                    }
                }
            }
        }
        wanted
    }

    pub(crate) fn insert_epsilon_closure(
        &mut self,
        source: SrsRfcBarrenPlace,
        target: SrsRfcBarrenPlace,
    ) -> Option<bool> {
        self.bounded_insert_epsilon(source, target)
    }

    pub(crate) fn complete_all_rule_removal(
        mut self,
        closure: SrsRfcBarrenClosure,
        deadline: Option<Instant>,
    ) -> Option<SrsRfcBarrenBuilder<'a>> {
        let mut iterations = 0usize;
        loop {
            if current_thread_cancelled() || deadline.is_some_and(|limit| Instant::now() >= limit) {
                return None;
            }
            iterations += 1;
            if iterations > DEFAULT_SRS_MATCH_BOUNDS_MAX_ITERATIONS {
                return None;
            }
            let iteration_started = Instant::now();
            let ext_right_started = Instant::now();
            let mut wanted = self.wanted_for_ext_right();
            let ext_right_count = wanted.len();
            let ext_right_ms = ext_right_started.elapsed().as_millis();
            let mut ext_full_count = 0usize;
            if closure == SrsRfcBarrenClosure::Full {
                wanted.extend(self.wanted_for_ext_left());
                wanted.extend(self.wanted_for_overlap());
                ext_full_count = wanted.len().saturating_sub(ext_right_count);
            }
            write_progress_event(
                "rfc-matchbox",
                "subphase",
                "right-barren-completion",
                iteration_started.elapsed().as_millis(),
                &format!(
                    "iteration={} phase=extensions places={} epsilons={} ext_right={} ext_full={} elapsed_ms={}",
                    iterations,
                    self.places().len(),
                    self.epsilons.len(),
                    ext_right_count,
                    ext_full_count,
                    ext_right_started.elapsed().as_millis()
                ),
            );
            let inner_started = Instant::now();
            let inner = self.wanted_for_inner();
            let inner_count = inner.len();
            let inner_ms = inner_started.elapsed().as_millis();
            wanted.extend(inner);
            write_progress_event(
                "rfc-matchbox",
                "obligations",
                "right-barren-completion",
                iteration_started.elapsed().as_millis(),
                &format!(
                    "iteration={} places={} epsilons={} ext_right={} ext_full={} inner={} ext_right_ms={} inner_ms={}",
                    iterations,
                    self.places().len(),
                    self.epsilons.len(),
                    ext_right_count,
                    ext_full_count,
                    inner_count,
                    ext_right_ms,
                    inner_ms
                ),
            );
            let mut changed = false;
            for item in wanted {
                if let Some(height) = item.top_height {
                    let old = self.top[item.rule_index];
                    self.top[item.rule_index] = Some(old.map_or(height, |old| old.max(height)));
                }
                for (source, target) in item.transitions {
                    changed |= self.insert_epsilon_closure(source, target)?;
                }
            }
            if self
                .top
                .iter()
                .any(|height| height.is_some_and(|height| height > self.bound))
                || self.places().len() > self.max_places
            {
                return None;
            }
            write_progress_event(
                "rfc-matchbox",
                if changed { "iteration" } else { "fixed-point" },
                "right-barren-completion",
                iteration_started.elapsed().as_millis(),
                &format!(
                    "iteration={} places={} epsilons={} ext_right={} ext_full={} inner={} ext_right_ms={} inner_ms={}",
                    iterations,
                    self.places().len(),
                    self.epsilons.len(),
                    ext_right_count,
                    ext_full_count,
                    inner_count,
                    ext_right_ms,
                    inner_ms
                ),
            );
            if !changed {
                return Some(self);
            }
        }
    }

    pub(crate) fn removed_rule_indices(&self) -> Vec<usize> {
        self.top
            .iter()
            .enumerate()
            .filter_map(|(index, height)| {
                (height.is_none() || height.is_some_and(|height| height < self.bound))
                    .then_some(index)
            })
            .collect()
    }

    #[allow(dead_code)]
    pub(crate) fn kept_rule_indices(&self) -> Vec<usize> {
        self.top
            .iter()
            .enumerate()
            .filter_map(|(index, height)| {
                height
                    .is_some_and(|height| height >= self.bound)
                    .then_some(index)
            })
            .collect()
    }

    pub(crate) fn into_match_automaton_completion(
        &self,
        removed_indices: &[usize],
        kept_indices: &[usize],
        max_states: usize,
        max_transitions: usize,
        deadline: Option<Instant>,
    ) -> Option<SrsMatchCompletion> {
        let import_started = Instant::now();
        write_progress_event("rfc-matchbox", "start", "partial-barren-import", 0,
            &format!("rules={} removed={} epsilons={}", self.rules.len(), removed_indices.len(), self.epsilons.len()));
        let mut automaton = SrsMatchAutomatonBuilder::empty(max_states, max_transitions);
        for (rule_index, rule) in self.rules.iter().enumerate() {
            let max_level = self.top[rule_index].unwrap_or(0).min(self.bound);
            for level in 0..=max_level {
                for position in 0..rule.rhs().len() {
                    let head = Self::place_state(&SrsRfcBarrenPlace {
                        level,
                        rule_index,
                        position,
                    });
                    let tail = Self::place_state(&SrsRfcBarrenPlace {
                        level,
                        rule_index,
                        position: position + 1,
                    });
                    automaton.insert_transition(rule.rhs()[position].as_str(), level, &tail, &head);
                }
                let start = Self::place_state(&self.start_place(level, rule_index));
                let final_state = automaton.final_state.clone();
                automaton.insert_epsilon(&start, &final_state)?;
            }
        }
        for &rule_index in removed_indices {
            let final_state = automaton.final_state.clone();
            automaton.add_merged_rhs_path_to_final(
                self.rules[rule_index].rhs(),
                0,
                &final_state,
            )?;
        }
        for (source, target) in &self.epsilons {
            if source.level > self.bound || target.level > self.bound {
                continue;
            }
            let source = Self::place_state(source);
            let target = Self::place_state(target);
            automaton.insert_epsilon(&target, &source)?;
        }
        let removed_rules = removed_indices
            .iter()
            .map(|&index| self.rules[index].clone())
            .collect::<Vec<_>>();
        write_progress_event("rfc-matchbox", "finish", "partial-barren-import",
            import_started.elapsed().as_millis(), &format!("states={} transitions={} epsilons={}",
                automaton.states.len(), automaton.transitions.len(), automaton.state_transitions.len()));
        let kept_rules = kept_indices
            .iter()
            .map(|&index| self.rules[index].clone())
            .collect::<Vec<_>>();
        let mut iterations = 0usize;
        loop {
            if current_thread_cancelled() || deadline.is_some_and(|limit| Instant::now() >= limit) {
                return None;
            }
            iterations += 1;
            if iterations > DEFAULT_SRS_MATCH_BOUNDS_MAX_ITERATIONS {
                return None;
            }
            let mut changed = false;
            changed |= automaton.ensure_identity_state_compatibility();
            let phase_started = Instant::now();
            changed |= automaton.ensure_rfc_matchbox_below_top_strict_compatibility(
                &removed_rules,
                self.bound,
                deadline,
            )?;
            write_progress_event("rfc-matchbox", "subphase", "partial-barren-strict",
                phase_started.elapsed().as_millis(), &format!("iteration={iterations} states={}", automaton.states.len()));
            let phase_started = Instant::now();
            changed |= automaton.ensure_match_bounds_weak_compatibility(
                &kept_rules,
                self.bound,
                removed_rules.iter().all(|r| !r.rhs().is_empty()),
                deadline,
            )?;
            write_progress_event("rfc-matchbox", "subphase", "partial-barren-weak",
                phase_started.elapsed().as_millis(), &format!("iteration={iterations} states={}", automaton.states.len()));
            let phase_started = Instant::now();
            changed |= automaton.ensure_rfc_matchbox_closure(self.rules, deadline)?;
            write_progress_event("rfc-matchbox", "subphase", "partial-barren-closure",
                phase_started.elapsed().as_millis(), &format!("iteration={iterations} states={}", automaton.states.len()));
            let phase_started = Instant::now();
            changed |= automaton.ensure_rfc_matchbox_ext_right(self.rules, deadline)?;
            write_progress_event("rfc-matchbox", "subphase", "partial-barren-ext-right",
                phase_started.elapsed().as_millis(), &format!("iteration={iterations} states={}", automaton.states.len()));
            if automaton.states.len() > max_states
                || automaton.transitions.len() + automaton.state_transitions.len() > max_transitions
            {
                return None;
            }
            if !changed {
                break;
            }
        }
        if automaton.states.len() > max_states
            || automaton.transitions.len() + automaton.state_transitions.len() > max_transitions
            || !automaton.is_rfc_matchbox_below_top_strict_compatible(
                &removed_rules,
                self.bound,
                deadline,
            )?
            || !automaton.is_ceta_relative_match_bounds_weak_compatible(
                &kept_rules, self.bound, removed_rules.iter().all(|r| !r.rhs().is_empty()), deadline)?
            || !automaton.is_rfc_matchbox_closed(self.rules)
            || !automaton.is_rfc_matchbox_ext_right(self.rules)
            || !automaton.has_no_rfc_top_redex_at_bound(&removed_rules, self.bound)
        {
            return None;
        }
        automaton.into_completion()
    }

    pub(crate) fn into_direct_layered_completion(
        &self,
        removed_indices: &[usize],
        kept_indices: &[usize],
        max_states: usize,
        max_transitions: usize,
        deadline: Option<Instant>,
    ) -> Option<SrsMatchCompletion> {
        if self.bound > 0 {
            // Higher match bounds require substantially more finite-layer
            // closure work. Reserve half the caller's local allowance for
            // the smaller reached-layer construction, while leaving time
            // for the full-layer alternative if validation fails.
            // This applies to full deletion too: adding unused top layers
            // can create artificial redexes even when every rule is strict.
            let allowance = deadline.map(|end| end.saturating_duration_since(Instant::now()) / 2)
                .unwrap_or(std::time::Duration::from_secs(2));
            let probe_end = Instant::now() + allowance.min(std::time::Duration::from_secs(30));
            if let Some(proof) = self.into_direct_layered_completion_with_layers(
                removed_indices, kept_indices, max_states, max_transitions,
                Some(deadline.map_or(probe_end, |end| end.min(probe_end))), true,
            ) {
                return Some(proof);
            }
        }
        self.into_direct_layered_completion_with_layers(
            removed_indices, kept_indices, max_states, max_transitions, deadline, false,
        )
    }

    fn into_direct_layered_completion_with_layers(
        &self, removed_indices: &[usize], kept_indices: &[usize],
        max_states: usize, max_transitions: usize, deadline: Option<Instant>,
        reached_layers_only: bool,
    ) -> Option<SrsMatchCompletion> {
        let mut automaton = SrsMatchAutomatonBuilder::empty(max_states, max_transitions);
        automaton.states.clear();
        let mut roots = Vec::with_capacity(self.rules.len());
        let mut tails = Vec::with_capacity(self.rules.len());
        for (rule_index, rule) in self.rules.iter().enumerate() {
            roots.push(Self::place_state(&self.start_place(0, rule_index)));
            tails.push(Self::place_state(&self.end_place(0, rule_index)));
            // Extra, unreachable layers can introduce artificial top redexes.
            // First try the layers reached by barren completion for deleted
            // rules; retain all layers for weak rules. The full independent
            // compatibility/closure/no-top checks below remain mandatory.
            let max_level = if reached_layers_only && removed_indices.contains(&rule_index) {
                self.top[rule_index].unwrap_or(0).min(self.bound)
            } else { self.bound };
            for level in 0..=max_level {
                for position in 0..rule.rhs().len() {
                    let head = Self::place_state(&SrsRfcBarrenPlace {
                        level,
                        rule_index,
                        position,
                    });
                    let tail = Self::place_state(&SrsRfcBarrenPlace {
                        level,
                        rule_index,
                        position: position + 1,
                    });
                    automaton.insert_transition(rule.rhs()[position].as_str(), level, &tail, &head);
                }
            }
        }
        for (source, target) in &self.epsilons {
            automaton.insert_epsilon_from_closed_relation(
                &Self::place_state(target),
                &Self::place_state(source),
            );
        }
        automaton.ensure_identity_state_compatibility();

        let removed_rules = removed_indices
            .iter()
            .map(|&index| self.rules[index].clone())
            .collect::<Vec<_>>();
        let kept_rules = kept_indices
            .iter()
            .map(|&index| self.rules[index].clone())
            .collect::<Vec<_>>();
        let mut completion_iterations = 0usize;
        loop {
            if current_thread_cancelled() || deadline.is_some_and(|limit| Instant::now() >= limit) {
                return None;
            }
            // This construction only adds edges and compatibility pairs.
            // Once a forbidden top-level redex is reachable it cannot be
            // repaired by further completion. Avoid spending the remainder
            // of the local budget on an already invalid candidate.
            if !automaton.has_no_rfc_top_redex_at_bound(&removed_rules, self.bound) {
                write_progress_event("rfc-matchbox", "layered-rejected", "monotone-top-redex", 0,
                    &format!("iteration={completion_iterations} states={} removed={}",
                        automaton.states.len(), removed_rules.len()));
                return None;
            }
            completion_iterations += 1;
            if completion_iterations > DEFAULT_SRS_MATCH_BOUNDS_MAX_ITERATIONS {
                return None;
            }
            let iteration_started = Instant::now();
            let strict_changed = if kept_indices.is_empty() {
                automaton.ensure_rfc_matchbox_below_top_strict_epsilon_bridges(
                    self.rules, self.bound, deadline,
                )?
            } else {
                automaton.ensure_layered_selected_epsilon_compatibility(
                    self.rules, removed_indices, self.bound, true, deadline,
                )?
            };
            let weak_changed = if kept_indices.is_empty() {false} else {
                automaton.ensure_layered_selected_epsilon_compatibility(
                    self.rules, kept_indices, self.bound, false, deadline,
                )?
            };
            let closure_changed =
                automaton.ensure_rfc_matchbox_closure_epsilons(self.rules, &tails, deadline)?;
            let ext_changed = if kept_indices.is_empty() {false} else {
                automaton.ensure_rfc_matchbox_ext_right_relations(self.rules, &tails,
                    &tails.iter().cloned().collect(), deadline)?
            };
            write_progress_event("rfc-matchbox", "iteration", "direct-layered-barren",
                iteration_started.elapsed().as_millis(),
                &format!("iteration={completion_iterations} strict={strict_changed} weak={weak_changed} closure={closure_changed} ext={ext_changed} states={} epsilons={}",
                    automaton.states.len(), automaton.state_transitions.len()));
            if automaton.states.len() > max_states
                || automaton.transitions.len() + automaton.state_transitions.len() > max_transitions
            {
                return None;
            }
            if !strict_changed && !weak_changed && !closure_changed && !ext_changed {
                break;
            }
        }
        let initial =
            self.rules
                .iter()
                .zip(roots.iter().zip(&tails))
                .all(|(rule, (root, tail))| {
                    automaton.word_reaches_at_height(rule.rhs(), 0, tail, root)
                });
        let tail_set = tails.iter().cloned().collect::<BTreeSet<_>>();
        let validation_started = Instant::now();
        let closed = automaton.is_rfc_matchbox_closed(self.rules);
        let ext_right =
            automaton.is_rfc_matchbox_ext_right_from_tail_states(self.rules, &tail_set);
        let below_top = automaton.is_rfc_matchbox_below_top_strict_compatible(
            &removed_rules,
            self.bound,
            deadline,
        )?;
        let weak = automaton.is_ceta_relative_match_bounds_weak_compatible(
            &kept_rules, self.bound, removed_rules.iter().all(|r| !r.rhs().is_empty()), deadline)?;
        let no_top = automaton.has_no_rfc_top_redex_at_bound(&removed_rules, self.bound);
        write_progress_event("rfc-matchbox", "validation", "direct-layered-barren",
            validation_started.elapsed().as_millis(),
            &format!("states={} rules={}", automaton.states.len(), self.rules.len()));
        let within_limits = automaton.states.len() <= max_states
            && automaton.transitions.len() + automaton.state_transitions.len() <= max_transitions;
        write_progress_event(
            "rfc-matchbox",
            if initial && closed && ext_right && below_top && weak && no_top && within_limits {
                "layered-selected"
            } else {
                "layered-rejected"
            },
            "direct-layered-barren",
            0,
            &format!(
                "bound={} states={} transitions={} initial={} closed={} ext_right={} below_top={} weak={} no_top={} within_limits={}",
                self.bound,
                automaton.states.len(),
                automaton.transitions.len() + automaton.state_transitions.len(),
                initial,
                closed,
                ext_right,
                below_top,
                weak,
                no_top,
                within_limits
            ),
        );
        if !initial || !closed || !ext_right || !below_top || !weak || !no_top || !within_limits {
            return None;
        }

        let mut used_symbols = self
            .rules
            .iter()
            .flat_map(|rule| rule.lhs().iter().chain(rule.rhs()))
            .map(|symbol| symbol.as_str().to_string())
            .collect::<BTreeSet<_>>();
        for (index, tail) in tails.iter().enumerate() {
            if automaton
                .transitions
                .iter()
                .any(|transition| &transition.head == tail)
            {
                continue;
            }
            let mut suffix = index;
            let witness_symbol = loop {
                let candidate = format!("ferrum_rfc_tail_{suffix}");
                if used_symbols.insert(candidate.clone()) {
                    break candidate;
                }
                suffix += self.rules.len().max(1);
            };
            automaton.insert_transition(&witness_symbol, 0, "", tail);
        }
        if automaton.transitions.len() + automaton.state_transitions.len() > max_transitions {
            return None;
        }

        let mut completion = automaton.into_completion()?;
        roots.extend(tails.iter().cloned());
        roots.sort();
        roots.dedup();
        completion.automaton.final_states = roots;
        completion.tail_states = tails;
        Some(completion)
    }

    pub(crate) fn into_exact_right_barren_completion(
        &self,
        removed_indices: &[usize],
        kept_indices: &[usize],
        max_states: usize,
        max_transitions: usize,
        deadline: Option<Instant>,
    ) -> Option<SrsMatchCompletion> {
        if !kept_indices.is_empty() || removed_indices.len() != self.rules.len() {
            return None;
        }

        let exact_started = Instant::now();
        let mut automaton = SrsMatchAutomatonBuilder::empty(max_states, max_transitions);
        automaton.states.clear();
        let mut roots = Vec::new();
        let mut tails = Vec::new();
        for (rule_index, rule) in self.rules.iter().enumerate() {
            let root = Self::place_state(&self.start_place(0, rule_index));
            let tail = Self::place_state(&self.end_place(0, rule_index));
            roots.push(root);
            tails.push(tail);
            for position in 0..rule.rhs().len() {
                let head = Self::place_state(&SrsRfcBarrenPlace {
                    level: 0,
                    rule_index,
                    position,
                });
                let tail = Self::place_state(&SrsRfcBarrenPlace {
                    level: 0,
                    rule_index,
                    position: position + 1,
                });
                automaton.insert_transition(rule.rhs()[position].as_str(), 0, &tail, &head);
            }
        }
        for (source, target) in &self.epsilons {
            automaton.insert_epsilon_from_closed_relation(
                &Self::place_state(target),
                &Self::place_state(source),
            );
        }
        write_progress_event(
            "rfc-matchbox",
            "phase",
            "exact-right-barren-build",
            exact_started.elapsed().as_millis(),
            &format!(
                "phase=imported states={} transitions={} epsilons={}",
                automaton.states.len(),
                automaton.transitions.len(),
                automaton.state_transitions.len()
            ),
        );

        let common_tail = tails.first()?.clone();
        if self.rules.len() == 1 {
            for (rule, root) in self.rules.iter().zip(&roots) {
                automaton.add_rhs_path(rule.rhs(), 0, &common_tail, root)?;
            }
        }
        automaton.ensure_identity_state_compatibility();
        let tail_set = BTreeSet::from([common_tail.clone()]);
        let result_states = automaton
            .transitions
            .iter()
            .map(|transition| transition.head.clone())
            .collect::<BTreeSet<_>>();
        let anchor_candidates = roots
            .iter()
            .filter(|root| result_states.contains(*root))
            .cloned()
            .chain(
                result_states
                    .iter()
                    .filter(|state| !roots.contains(state))
                    .cloned(),
            );
        let anchor_started = Instant::now();
        let mut selected = None;
        for (candidate_index, result_state) in anchor_candidates
            .enumerate()
            .take(if self.rules.len() == 1 { usize::MAX } else { 0 })
        {
            if current_thread_cancelled() || deadline.is_some_and(|limit| Instant::now() >= limit) {
                return None;
            }
            let candidate_started = Instant::now();
            let mut candidate = automaton.clone();
            candidate.insert_epsilon(&result_state, &common_tail)?;
            let within_limits = candidate.states.len() <= max_states
                && candidate.transitions.len() + candidate.state_transitions.len()
                    <= max_transitions;
            let ext_right = within_limits
                && candidate.is_rfc_matchbox_ext_right_from_tail_states(self.rules, &tail_set);
            let no_top =
                ext_right && candidate.has_no_rfc_top_redex_at_bound(self.rules, self.bound);
            let closed = no_top && candidate.is_rfc_matchbox_closed(self.rules);
            write_progress_event(
                "rfc-matchbox",
                if closed {
                    "anchor-selected"
                } else {
                    "anchor-rejected"
                },
                "exact-right-barren-tail-anchor",
                candidate_started.elapsed().as_millis(),
                &format!(
                    "candidate={} index={} states={} transitions={} within_limits={} ext_right={} no_top={} closed={}",
                    result_state,
                    candidate_index,
                    candidate.states.len(),
                    candidate.transitions.len() + candidate.state_transitions.len(),
                    within_limits,
                    ext_right,
                    no_top,
                    closed
                ),
            );
            if closed {
                selected = Some(candidate);
                break;
            }
        }
        let paired = if selected.is_none() {
            let candidate_started = Instant::now();
            let mut candidate = automaton.clone();
            let direct_tail_set = tails.iter().cloned().collect::<BTreeSet<_>>();
            let direct_initial =
                self.rules
                    .iter()
                    .zip(roots.iter().zip(&tails))
                    .all(|(rule, (root, tail))| {
                        candidate.word_reaches_at_height(rule.rhs(), 0, tail, root)
                    });
            let direct_ext = direct_initial
                && candidate
                    .is_rfc_matchbox_ext_right_from_tail_states(self.rules, &direct_tail_set);
            let direct_no_top =
                direct_ext && candidate.has_no_rfc_top_redex_at_bound(self.rules, self.bound);
            let direct_closed = direct_no_top && candidate.is_rfc_matchbox_closed(self.rules);
            write_progress_event(
                "rfc-matchbox",
                if direct_closed {
                    "paired-selected"
                } else {
                    "paired-rejected"
                },
                "exact-right-barren-direct-paired-tail",
                candidate_started.elapsed().as_millis(),
                &format!(
                    "tails={} states={} transitions={} paired_initial={} ext_right={} no_top={} closed={}",
                    tails.len(),
                    candidate.states.len(),
                    candidate.transitions.len() + candidate.state_transitions.len(),
                    direct_initial,
                    direct_ext,
                    direct_no_top,
                    direct_closed
                ),
            );
            if direct_closed {
                Some(candidate)
            } else {
                for (root, tail) in roots.iter().zip(&tails) {
                    candidate.insert_epsilon(root, tail)?;
                }
                let states_before_quotient = candidate.states.len();
                let transitions_before_quotient =
                    candidate.transitions.len() + candidate.state_transitions.len();
                let quotient = candidate.quotient_epsilon_sccs()?;
                roots = roots
                    .iter()
                    .map(|state| {
                        quotient
                            .get(state)
                            .cloned()
                            .unwrap_or_else(|| state.clone())
                    })
                    .collect::<Vec<_>>();
                tails = tails
                    .iter()
                    .map(|state| {
                        quotient
                            .get(state)
                            .cloned()
                            .unwrap_or_else(|| state.clone())
                    })
                    .collect::<Vec<_>>();
                write_progress_event(
                    "rfc-matchbox",
                    "phase",
                    "exact-right-barren-paired-tail",
                    candidate_started.elapsed().as_millis(),
                    &format!(
                        "phase=epsilon-scc-quotient states_before={} states={} transitions_before={} transitions={} epsilons={}",
                        states_before_quotient,
                        candidate.states.len(),
                        transitions_before_quotient,
                        candidate.transitions.len(),
                        candidate.state_transitions.len()
                    ),
                );
                let mut ext_relations = false;
                let mut closure_iterations = 0usize;
                loop {
                    if current_thread_cancelled()
                        || deadline.is_some_and(|limit| Instant::now() >= limit)
                    {
                        return None;
                    }
                    closure_iterations += 1;
                    if closure_iterations > DEFAULT_SRS_MATCH_BOUNDS_MAX_ITERATIONS {
                        return None;
                    }
                    let strict_started = Instant::now();
                    let strict_changed = candidate
                        .ensure_rfc_matchbox_below_top_strict_compatibility(
                            self.rules, self.bound, deadline,
                        )?;
                    let strict_ms = strict_started.elapsed().as_millis();
                    let closure_started = Instant::now();
                    let closure_changed = candidate
                        .ensure_rfc_matchbox_closure_epsilons(self.rules, &tails, deadline)?;
                    let closure_ms = closure_started.elapsed().as_millis();
                    write_progress_event(
                        "rfc-matchbox",
                        "subphase",
                        "exact-right-barren-paired-tail",
                        candidate_started.elapsed().as_millis(),
                        &format!(
                            "phase=closure iteration={} changed={} elapsed_ms={}",
                            closure_iterations, closure_changed, closure_ms
                        ),
                    );
                    let tail_set = tails.iter().cloned().collect::<BTreeSet<_>>();
                    let ext_started = Instant::now();
                    let ext_changed = candidate.ensure_rfc_matchbox_ext_right_relations(
                        self.rules, &tails, &tail_set, deadline,
                    )?;
                    let ext_ms = ext_started.elapsed().as_millis();
                    ext_relations |= ext_changed;
                    let states_before_iteration_quotient = candidate.states.len();
                    if closure_changed || ext_changed {
                        let quotient = candidate.quotient_epsilon_sccs()?;
                        roots = roots
                            .iter()
                            .map(|state| {
                                quotient
                                    .get(state)
                                    .cloned()
                                    .unwrap_or_else(|| state.clone())
                            })
                            .collect();
                        tails = tails
                            .iter()
                            .map(|state| {
                                quotient
                                    .get(state)
                                    .cloned()
                                    .unwrap_or_else(|| state.clone())
                            })
                            .collect();
                    }
                    write_progress_event(
                        "rfc-matchbox",
                        if strict_changed || closure_changed || ext_changed {
                            "iteration"
                        } else {
                            "fixed-point"
                        },
                        "exact-right-barren-paired-tail",
                        candidate_started.elapsed().as_millis(),
                        &format!(
                            "phase=strict-closure-ext iteration={} strict_changed={} closure_changed={} ext_changed={} strict_ms={} closure_ms={} ext_ms={} states_before_quotient={} states={} transitions={} epsilons={}",
                            closure_iterations,
                            strict_changed,
                            closure_changed,
                            ext_changed,
                            strict_ms,
                            closure_ms,
                            ext_ms,
                            states_before_iteration_quotient,
                            candidate.states.len(),
                            candidate.transitions.len(),
                            candidate.state_transitions.len()
                        ),
                    );
                    if !strict_changed && !closure_changed && !ext_changed {
                        break;
                    }
                }
                let tail_set = tails.iter().cloned().collect::<BTreeSet<_>>();
                let paired_initial =
                    self.rules
                        .iter()
                        .zip(roots.iter().zip(&tails))
                        .all(|(rule, (root, tail))| {
                            candidate.word_reaches_at_height(rule.rhs(), 0, tail, root)
                        });
                let all_tail_rhs_states = tails.iter().all(|tail| {
                    candidate
                        .transitions
                        .iter()
                        .any(|transition| &transition.head == tail)
                        || candidate
                            .state_transitions
                            .iter()
                            .any(|(_, target)| target == tail)
                });
                let within_limits = candidate.states.len() <= max_states
                    && candidate.transitions.len() + candidate.state_transitions.len()
                        <= max_transitions;
                let ext_right = paired_initial && all_tail_rhs_states && within_limits;
                if cfg!(debug_assertions) && candidate.states.len() <= 256 {
                    debug_assert!(
                        candidate.is_rfc_matchbox_ext_right_from_tail_states(self.rules, &tail_set)
                    );
                    debug_assert!(candidate.is_rfc_matchbox_closed(self.rules));
                }
                let strict_compatible = ext_right
                    && candidate.is_rfc_matchbox_below_top_strict_compatible(
                        self.rules, self.bound, deadline,
                    )?;
                let closure_compatible =
                    strict_compatible && candidate.is_rfc_matchbox_closed(self.rules);
                let no_top = closure_compatible
                    && candidate.has_no_rfc_top_redex_at_bound(self.rules, self.bound);
                let closed = no_top;
                write_progress_event(
                    "rfc-matchbox",
                    if closed {
                        "paired-selected"
                    } else {
                        "paired-rejected"
                    },
                    "exact-right-barren-paired-tail",
                    candidate_started.elapsed().as_millis(),
                    &format!(
                        "tails={} states={} transitions={} ext_relations_changed={} paired_initial={} tail_rhs={} within_limits={} ext_right={} strict_compatible={} closure_compatible={} no_top={} closed={}",
                        tails.len(),
                        candidate.states.len(),
                        candidate.transitions.len() + candidate.state_transitions.len(),
                        ext_relations,
                        paired_initial,
                        all_tail_rhs_states,
                        within_limits,
                        ext_right,
                        strict_compatible,
                        closure_compatible,
                        no_top,
                        closed
                    ),
                );
                closed.then_some(candidate)
            }
        } else {
            None
        };
        let paired_selected = selected.is_none() && paired.is_some();
        automaton = selected.or(paired)?;
        write_progress_event(
            "rfc-matchbox",
            "finish",
            "exact-right-barren-tail-anchor-search",
            anchor_started.elapsed().as_millis(),
            &format!(
                "rules={} states={} transitions={}",
                self.rules.len(),
                automaton.states.len(),
                automaton.transitions.len() + automaton.state_transitions.len()
            ),
        );

        let mut completion = automaton.into_completion()?;
        roots.extend(tails.iter().cloned());
        roots.sort();
        roots.dedup();
        completion.automaton.final_states = roots;
        completion.tail_states = if paired_selected {
            tails
        } else {
            vec![common_tail; self.rules.len()]
        };
        Some(completion)
    }
}

pub(crate) fn complete_srs_rfc_matchbox_barren_completion(
    rules: &[crate::core::SrsRule],
    bound: usize,
    max_states: usize,
    max_transitions: usize,
    closure: SrsRfcBarrenClosure,
    layered_only: bool,
    allow_partial: bool,
    layered_seconds: u64,
    fresh_seconds: u64,
    deadline: Option<Instant>,
) -> Option<(SrsMatchCompletion, Vec<usize>)> {
    // Try unfurled RHS paths before merging variable tails. This uses the
    // recorded fresh-path budget. Legacy strategies retain their short cap;
    // explicit exploration can allocate more without changing other routes.
    if fresh_seconds > 0 {
        let cap = Instant::now() + std::time::Duration::from_secs(fresh_seconds.min(300));
        let local = Some(deadline.map_or(cap, |end| end.min(cap)));
        if let Some(completion) = complete_fresh_rfc_paths(rules, bound, max_states, max_transitions, local) {
            return Some((completion, (0..rules.len()).collect()));
        }
    }
    let barren_started = Instant::now();
    let barren = SrsRfcBarrenBuilder::new_with_limits(rules, bound, max_states, max_transitions)?
        .complete_all_rule_removal(closure, deadline)?;
    write_progress_event(
        "rfc-matchbox",
        "finish",
        "right-barren-epsilon-completion",
        barren_started.elapsed().as_millis(),
        &format!(
            "rules={} bound={} places={} epsilons={} top={:?}",
            rules.len(),
            bound,
            barren.places().len(),
            barren.epsilons.len(),
            barren.top
        ),
    );
    let removed_indices = barren.removed_rule_indices();
    if removed_indices.is_empty() {
        return None;
    }
    // A newly exposed partial residual must not displace an established
    // full-deletion route before its relative continuation has guidance.
    if removed_indices.len() != rules.len()
        && !allow_partial
        && std::env::var_os("FERRUM_EXPERIMENTAL_RFC_LAYERED_SECONDS").is_none()
    {
        return None;
    }
    // A partial deletion can fail its no-top check for just one candidate
    // rule. Try structural subsets with the cheap finite-layer construction
    // as well, rather than reserving them for expansive path completion.
    let candidate_batches = if bound == 0 || removed_indices.len() == rules.len() {
        vec![removed_indices.clone()]
    } else {
        srs_rfc_matchbox_removed_candidate_batches(rules, &removed_indices)
    };
    for candidate_removed in candidate_batches {
        if current_thread_cancelled() || deadline.is_some_and(|limit| Instant::now() >= limit) {
            return None;
        }
        let removed_set = candidate_removed.iter().copied().collect::<BTreeSet<_>>();
        let kept_indices = (0..rules.len())
            .filter(|index| !removed_set.contains(index))
            .collect::<Vec<_>>();
        let completion = if layered_only {
            // Partial deletion has the same explicit weak/strict validation
            // below. Previously it was excluded before even trying this
            // finite layered automaton, forcing expansive path completion.
            // Preserve the full-deletion budget and bound the new probe.
            let local_deadline = if !kept_indices.is_empty() {
                let seconds = std::env::var("FERRUM_EXPERIMENTAL_RFC_LAYERED_SECONDS")
                    .ok().and_then(|value| value.parse::<u64>().ok()).unwrap_or(layered_seconds).min(300);
                let cap = Instant::now() + std::time::Duration::from_secs(seconds);
                Some(deadline.map_or(cap, |end| end.min(cap)))
            } else { deadline };
            barren.into_direct_layered_completion(
                &candidate_removed,
                &kept_indices,
                max_states,
                max_transitions,
                local_deadline,
            )
        } else {
            barren
                .into_exact_right_barren_completion(
                    &candidate_removed,
                    &kept_indices,
                    max_states,
                    max_transitions,
                    deadline,
                )
                .or_else(|| {
                    (bound > 0)
                        .then(|| {
                            barren.into_match_automaton_completion(
                                &candidate_removed,
                                &kept_indices,
                                max_states,
                                max_transitions,
                                deadline,
                            )
                        })
                        .flatten()
                })
        };
        if let Some(completion) = completion {
            return Some((completion, candidate_removed));
        }
    }
    None
}

/// Synthesize from RHS paths without folding unrelated variable tails.
/// All existing independent validation remains mandatory.
fn complete_fresh_rfc_paths(
    rules: &[crate::core::SrsRule], bound: usize, max_states: usize,
    max_transitions: usize, deadline: Option<Instant>,
) -> Option<SrsMatchCompletion> {
    let mut automaton = SrsMatchAutomatonBuilder::empty(max_states, max_transitions);
    let mut roots = Vec::new();
    let mut tails = Vec::new();
    for rule in rules {
        if rule.lhs().is_empty() { return None; }
        let tail = automaton.fresh_state()?;
        let root = automaton.fresh_state()?;
        automaton.add_rhs_path(rule.rhs(), 0, &tail, &root)?;
        roots.push(root);
        tails.push(tail);
    }
    let tail_set = tails.iter().cloned().collect::<BTreeSet<_>>();
    for iteration in 0..DEFAULT_SRS_MATCH_BOUNDS_MAX_ITERATIONS {
        if current_thread_cancelled() || deadline.is_some_and(|end| Instant::now() >= end) {
            return None;
        }
        if !automaton.has_no_rfc_top_redex_at_bound(rules, bound) { return None; }
        let started = Instant::now();
        let mut changed = automaton.ensure_identity_state_compatibility();
        changed |= automaton.ensure_rfc_matchbox_below_top_strict_compatibility(rules, bound, deadline)?;
        let states = automaton.states.iter().cloned().collect::<Vec<_>>();
        for rule in rules {
            for tail in &states {
                if current_thread_cancelled() || deadline.is_some_and(|end| Instant::now() >= end) {
                    return None;
                }
                let mut heads = automaton.exact_heads_for_word(rule.lhs(), 0, tail);
                if tail_set.contains(tail) {
                    for split in 1..rule.lhs().len() {
                        heads.extend(automaton.exact_heads_for_word(&rule.lhs()[..split], 0, tail));
                    }
                }
                for head in heads {
                    if !automaton.word_reaches_at_height(rule.rhs(), 0, tail, &head) {
                        changed |= automaton.add_rhs_path(rule.rhs(), 0, tail, &head)?;
                    }
                }
            }
        }
        write_progress_event("rfc-matchbox", "iteration", "fresh-rfc-paths", started.elapsed().as_millis(),
            &format!("iteration={iteration} states={} changed={changed}", automaton.states.len()));
        if changed { continue; }
        if !automaton.has_no_rfc_top_redex_at_bound(rules, bound)
            || !automaton.is_rfc_matchbox_closed(rules)
            || !automaton.is_rfc_matchbox_ext_right_from_tail_states(rules, &tail_set)
            || !automaton.is_rfc_matchbox_below_top_strict_compatible(rules, bound, deadline)? {
            return None;
        }
        let mut symbols = rules.iter().flat_map(|r| r.lhs().iter().chain(r.rhs()))
            .map(|s| s.as_str().to_string()).collect::<BTreeSet<_>>();
        for (i, tail) in tails.iter().enumerate() {
            if automaton.transitions.iter().any(|t| &t.head == tail) { continue; }
            let mut j = i;
            let name = loop {
                let name = format!("ferrum_rfc_fresh_tail_{j}");
                if symbols.insert(name.clone()) { break name; }
                j += tails.len().max(1);
            };
            automaton.insert_transition(&name, 0, "", tail);
        }
        automaton.ensure_identity_state_compatibility();
        let mut completion = automaton.into_completion()?;
        roots.extend(tails.iter().cloned());
        completion.automaton.final_states = roots;
        completion.tail_states = tails;
        return Some(completion);
    }
    None
}

pub(crate) fn srs_rfc_matchbox_removed_candidate_batches(
    rules: &[crate::core::SrsRule],
    removable_indices: &[usize],
) -> Vec<Vec<usize>> {
    let removable = removable_indices.iter().copied().collect::<BTreeSet<_>>();
    let mut order = removable_indices.to_vec();
    order.sort_by_key(|&index| {
        let rule = &rules[index];
        (
            rule.lhs().len().saturating_sub(rule.rhs().len()),
            rule.lhs().len(),
            std::cmp::Reverse(rule.rhs().len()),
        )
    });
    order.reverse();

    let mut seen = BTreeSet::new();
    let mut batches = Vec::new();
    let mut push_batch = |batch: Vec<usize>| {
        if batch.is_empty() || batch.iter().any(|index| !removable.contains(index)) {
            return;
        }
        let mut normalized = batch;
        normalized.sort_unstable();
        if seen.insert(normalized.clone()) {
            batches.push(normalized);
        }
    };

    push_batch(order.clone());

    push_batch(
        order
            .iter()
            .copied()
            .filter(|&index| rules[index].lhs().len() > rules[index].rhs().len())
            .collect(),
    );
    push_batch(
        order
            .iter()
            .copied()
            .filter(|&index| rules[index].lhs().len() >= rules[index].rhs().len())
            .collect(),
    );

    for lhs_len in {
        let mut lengths = order
            .iter()
            .map(|&index| rules[index].lhs().len())
            .collect::<BTreeSet<_>>()
            .into_iter()
            .collect::<Vec<_>>();
        lengths.reverse();
        lengths
    } {
        push_batch(
            order
                .iter()
                .copied()
                .filter(|&index| rules[index].lhs().len() >= lhs_len)
                .collect(),
        );
    }

    for size in (2..order.len()).rev() {
        push_batch(order.iter().copied().take(size).collect());
    }

    for index in order {
        push_batch(vec![index]);
    }

    batches
}

pub(crate) struct SrsRfcRelativeMatchBoundsRemoval {
    pub(crate) proof: BoundsProof,
    pub(crate) initial_words: Vec<Vec<Symbol>>,
    pub(crate) automaton_closed: bool,
    pub(crate) removed: Vec<RewriteRule>,
    pub(crate) remaining: Trs,
}

pub(crate) fn synthesize_srs_rfc_relative_match_bounds_removal(
    trs: &Trs,
    allow_partial: bool,
    layered_seconds: u64,
    fresh_seconds: u64,
    min_bound: usize,
    max_bound: usize,
    max_words: usize,
    max_word_len: usize,
    max_states: usize,
    max_transitions: usize,
    at_bound: SrsMatchAtBound,
    closure: SrsRfcBarrenClosure,
    deadline: Option<Instant>,
) -> Option<SrsRfcRelativeMatchBoundsRemoval> {
    let srs_rules = trs.srs_rules()?;
    if srs_rules.is_empty() {
        return None;
    }
    if srs_rules
        .iter()
        .any(|rule| rule.lhs().is_empty())
    {
        return None;
    }
    if !strict_srs_rules_are_right_linear(trs) {
        return None;
    }
    let (_, tail) = strict_srs_word_with_tail(trs.rules().first()?.lhs())?;
    let finite_initial_words = if at_bound == SrsMatchAtBound::Exact {
        srs_rfc_initial_words(trs.rules(), &tail, &srs_rules, max_words, max_word_len)
    } else {
        None
    };
    let rhs_initial_words = srs_rules
        .iter()
        .map(|rule| rule.rhs().to_vec())
        .collect::<Vec<_>>();
    if finite_initial_words
        .as_ref()
        .is_none_or(|initial_words| initial_words.is_empty())
        && rhs_initial_words.is_empty()
    {
        return None;
    }
    let search_passes: &[u8] = if at_bound == SrsMatchAtBound::Merge {
        &[0, 1, 2]
    } else {
        &[0]
    };
    for &search_pass in search_passes {
        for bound in min_bound..=max_bound {
            if current_thread_cancelled() || deadline.is_some_and(|limit| Instant::now() >= limit) {
                return None;
            }
            let (completion, initial_words, automaton_closed, removed_indices) = match at_bound {
                SrsMatchAtBound::Exact => {
                    let Some(result) = finite_initial_words.as_ref().and_then(|initial_words| {
                        complete_srs_match_bounds_completion_for_initial_words(
                            &srs_rules,
                            initial_words,
                            bound,
                            max_states,
                            max_transitions,
                            SrsMatchAtBound::Exact,
                            deadline,
                        )
                        .map(|completion| (completion, initial_words.clone()))
                    }) else {
                        continue;
                    };
                    (
                        result.0,
                        result.1,
                        false,
                        (0..srs_rules.len()).collect::<Vec<_>>(),
                    )
                }
                SrsMatchAtBound::Merge => {
                    let fallback_max_states = max_states.min(300);
                    let fallback_max_transitions = max_transitions.min(5_000);
                    let result = if search_pass < 2 {
                        complete_srs_rfc_matchbox_barren_completion(
                            &srs_rules,
                            bound,
                            max_states,
                            max_transitions,
                            closure,
                            search_pass == 0,
                            allow_partial,
                            layered_seconds,
                            fresh_seconds,
                            deadline,
                        )
                    } else {
                        complete_srs_rfc_matchbox_one_state_completion(
                            &srs_rules,
                            &rhs_initial_words,
                            bound,
                            max_states,
                            max_transitions,
                            deadline,
                        )
                        .map(|completion| (completion, (0..srs_rules.len()).collect::<Vec<_>>()))
                        .or_else(|| {
                            complete_srs_rfc_match_bounds_completion_for_initial_words(
                                &srs_rules,
                                &rhs_initial_words,
                                bound,
                                fallback_max_states,
                                fallback_max_transitions,
                                SrsMatchAtBound::Merge,
                                deadline,
                            )
                            .map(|completion| {
                                (completion, (0..srs_rules.len()).collect::<Vec<_>>())
                            })
                        })
                    };
                    let Some((completion, removed_indices)) = result else {
                        continue;
                    };
                    let tail_states = completion.tail_states.clone();
                    let automaton_final_states = completion.automaton.final_states.clone();
                    let Some(validator) = SrsMatchAutomatonBuilder::from_completion_for_validation(
                        completion,
                        max_states,
                        max_transitions,
                    ) else {
                        continue;
                    };
                    let removed_srs_rules = removed_indices
                        .iter()
                        .map(|&index| srs_rules[index].clone())
                        .collect::<Vec<_>>();
                    let kept_srs_rules = srs_rules
                        .iter()
                        .enumerate()
                        .filter_map(|(index, rule)| {
                            (!removed_indices.contains(&index)).then_some(rule.clone())
                        })
                        .collect::<Vec<_>>();
                    let validation_started = Instant::now();
                    let weak_compatible = validator.is_ceta_relative_match_bounds_weak_compatible(
                        &kept_srs_rules, bound,
                        removed_srs_rules.iter().all(|r| !r.rhs().is_empty()), deadline)?;
                    let no_top = validator.has_no_rfc_top_redex_at_bound(&removed_srs_rules, bound);
                    let below_top_strict = no_top
                        && validator.is_rfc_matchbox_below_top_strict_compatible(
                            &removed_srs_rules,
                            bound,
                            deadline,
                        )?;
                    let ext_right = validator.is_rfc_matchbox_ext_right_from_tail_states(
                        &srs_rules,
                        &tail_states.iter().cloned().collect(),
                    );
                    let canonical_matchbox =
                        no_top && below_top_strict && weak_compatible && ext_right;
                    write_progress_event(
                        "rfc-matchbox",
                        "canonical-validation",
                        "direct-layered-barren",
                        validation_started.elapsed().as_millis(),
                        &format!(
                            "bound={bound} no_top={no_top} \
                                 below_top_strict={below_top_strict} \
                                 weak_compatible={weak_compatible} ext_right={ext_right}"
                        ),
                    );
                    if !canonical_matchbox {
                        continue;
                    }
                    let Some(mut completion) = validator.into_completion() else {
                        continue;
                    };
                    completion.automaton.final_states = automaton_final_states;
                    completion.tail_states = tail_states;
                    for tail in &completion.tail_states {
                        let self_loop = TreeAutomatonTransition {
                            lhs: TreeAutomatonTransitionLhs::State(tail.clone()),
                            rhs: tail.clone(),
                        };
                        if !completion.automaton.transitions.contains(&self_loop) {
                            completion.automaton.transitions.push(self_loop);
                        }
                    }
                    if completion.automaton.transitions.len() > max_transitions {
                        continue;
                    }
                    (completion, rhs_initial_words.clone(), true, removed_indices)
                }
            };
            let proof = BoundsProof {
                bounds_type: BoundsType::Match,
                bound,
                final_states: completion.tail_states,
                automaton: completion.automaton,
                state_compatibility: completion.state_compatibility,
            };
            let removed_index_set = removed_indices.iter().copied().collect::<BTreeSet<_>>();
            let removed = removed_indices
                .iter()
                .map(|&index| trs.rules()[index].clone())
                .collect::<Vec<_>>();
            let remaining_rules = trs
                .rules()
                .iter()
                .enumerate()
                .filter_map(|(index, rule)| {
                    (!removed_index_set.contains(&index)).then_some(rule.clone())
                })
                .collect::<Vec<_>>();
            let remaining = Trs::new_with_strategy(
                trs.name().map(str::to_string),
                trs.variables().clone(),
                remaining_rules,
                trs.strategy(),
            );
            return Some(SrsRfcRelativeMatchBoundsRemoval {
                proof,
                initial_words,
                automaton_closed,
                removed,
                remaining,
            });
        }
    }
    None
}

pub(crate) fn strict_srs_rules_are_right_linear(trs: &Trs) -> bool {
    trs.rules().iter().all(|rule| {
        let Some((_, lhs_tail)) = strict_srs_word_with_tail(rule.lhs()) else {
            return false;
        };
        let Some((_, rhs_tail)) = strict_srs_word_with_tail(rule.rhs()) else {
            return false;
        };
        lhs_tail == rhs_tail
    })
}

pub(crate) fn srs_relative_match_bounds_candidate_batches(
    rules: &[crate::core::SrsRule],
) -> Vec<Vec<usize>> {
    let mut order = (0..rules.len()).collect::<Vec<_>>();
    order.sort_by_key(|&index| {
        let rule = &rules[index];
        (
            rule.lhs().len().saturating_sub(rule.rhs().len()),
            rule.lhs().len(),
            std::cmp::Reverse(rule.rhs().len()),
        )
    });
    order.reverse();

    let mut seen = BTreeSet::new();
    let mut batches = Vec::new();
    let mut push_batch = |batch: Vec<usize>| {
        if batch.is_empty() || batch.len() > rules.len() {
            return;
        }
        let mut normalized = batch;
        normalized.sort_unstable();
        if seen.insert(normalized.clone()) {
            batches.push(normalized);
        }
    };

    let all = order.clone();
    push_batch(all);

    let decreasing = order
        .iter()
        .copied()
        .filter(|&index| rules[index].lhs().len() > rules[index].rhs().len())
        .collect::<Vec<_>>();
    push_batch(decreasing);

    let non_growing = order
        .iter()
        .copied()
        .filter(|&index| rules[index].lhs().len() >= rules[index].rhs().len())
        .collect::<Vec<_>>();
    push_batch(non_growing);

    for lhs_len in {
        let mut lengths = rules
            .iter()
            .map(|rule| rule.lhs().len())
            .collect::<BTreeSet<_>>()
            .into_iter()
            .collect::<Vec<_>>();
        lengths.reverse();
        lengths
    } {
        push_batch(
            order
                .iter()
                .copied()
                .filter(|&index| rules[index].lhs().len() >= lhs_len)
                .collect(),
        );
    }

    for size in (2..rules.len()).rev() {
        push_batch(order.iter().copied().take(size).collect());
    }

    for index in order {
        push_batch(vec![index]);
    }

    batches.truncate(DEFAULT_SRS_RELATIVE_MATCH_BOUNDS_MAX_BATCHES);
    batches
}

pub(crate) fn srs_rules_from_rewrite_rules(
    rules: &[RewriteRule],
) -> Option<Vec<crate::core::SrsRule>> {
    rules
        .iter()
        .map(|rule| {
            let (lhs, lhs_tail) = strict_srs_word_with_tail(rule.lhs())?;
            let (rhs, rhs_tail) = strict_srs_word_with_tail(rule.rhs())?;
            (lhs_tail == rhs_tail).then(|| crate::core::SrsRule::from_words(lhs, rhs))
        })
        .collect()
}

pub(crate) fn add_srs_word_symbols_to_arities(
    rules: &[crate::core::SrsRule],
    symbol_arities: &mut BTreeMap<String, usize>,
) {
    for rule in rules {
        for symbol in rule.lhs().iter().chain(rule.rhs()) {
            symbol_arities.insert(symbol.as_str().to_string(), 1);
        }
    }
}

#[derive(Clone, Debug, Eq, Ord, PartialEq, PartialOrd)]
pub(crate) struct SrsMatchTransition {
    symbol: String,
    height: usize,
    tail: String,
    head: String,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub(crate) struct SrsMatchPath {
    pub(crate) tail: String,
    pub(crate) head: String,
    pub(crate) heights: Vec<usize>,
}

#[derive(Clone, Debug, Eq, PartialEq, Ord, PartialOrd)]
pub(crate) struct SrsMatchReach {
    head: String,
    min_height: Option<usize>,
}

pub(crate) struct SrsMatchCompletion {
    pub(crate) automaton: TreeAutomaton,
    pub(crate) tail_states: Vec<String>,
    pub(crate) state_compatibility: Vec<(String, String)>,
}

#[derive(Clone, Debug, Eq, PartialEq, Ord, PartialOrd)]
pub(crate) struct SrsRfcBarrenPlace {
    pub(crate) level: usize,
    pub(crate) rule_index: usize,
    pub(crate) position: usize,
}

#[derive(Clone, Copy, Debug, Eq, PartialEq, Ord, PartialOrd)]
pub(crate) enum SrsRfcFuzzyHeight {
    Finite(usize),
    Infinite,
}

#[derive(Clone, Debug)]
pub(crate) struct SrsRfcWantedEpsilons {
    rule_index: usize,
    top_height: Option<usize>,
    transitions: Vec<(SrsRfcBarrenPlace, SrsRfcBarrenPlace)>,
}

pub(crate) struct SrsRfcBarrenBuilder<'a> {
    pub(crate) rules: &'a [crate::core::SrsRule],
    pub(crate) bound: usize,
    pub(crate) top: Vec<Option<usize>>,
    pub(crate) epsilons: BTreeSet<(SrsRfcBarrenPlace, SrsRfcBarrenPlace)>,
    pub(crate) epsilon_forward: BTreeMap<SrsRfcBarrenPlace, BTreeSet<SrsRfcBarrenPlace>>,
    pub(crate) epsilon_backward: BTreeMap<SrsRfcBarrenPlace, BTreeSet<SrsRfcBarrenPlace>>,
    pub(crate) max_places: usize,
    pub(crate) max_epsilons: usize,
}

pub(crate) fn min_optional_height(left: Option<usize>, right: Option<usize>) -> Option<usize> {
    match (left, right) {
        (Some(left), Some(right)) => Some(left.min(right)),
        (Some(height), None) | (None, Some(height)) => Some(height),
        (None, None) => None,
    }
}

#[derive(Clone)]
pub(crate) struct SrsMatchAutomatonBuilder {
    pub(crate) final_state: String,
    pub(crate) transitions: BTreeSet<SrsMatchTransition>,
    pub(crate) transition_heads:
        BTreeMap<String, BTreeMap<usize, BTreeMap<String, BTreeSet<String>>>>,
    pub(crate) state_transitions: BTreeSet<(String, String)>,
    pub(crate) epsilon_forward: BTreeMap<String, BTreeSet<String>>,
    pub(crate) epsilon_backward: BTreeMap<String, BTreeSet<String>>,
    pub(crate) state_compatibility: BTreeSet<(String, String)>,
    pub(crate) states: BTreeSet<String>,
    pub(crate) next_state: usize,
    pub(crate) compact_rhs_states: Option<BTreeMap<(Vec<String>, usize, usize, String), String>>,
    bidirectional_rhs: bool,
    pub(crate) max_states: usize,
    pub(crate) max_transitions: usize,
}

pub(crate) struct SrsMatchWordIndex {
    pub(crate) states: Vec<String>,
    pub(crate) state_ids: BTreeMap<String, usize>,
    pub(crate) epsilon_closure: Vec<Vec<u64>>,
    pub(crate) compatibility: Vec<Vec<u64>>,
    pub(crate) transition_heads: BTreeMap<String, BTreeMap<usize, Vec<Vec<usize>>>>,
}

impl SrsMatchWordIndex {
    pub(crate) fn new(automaton: &SrsMatchAutomatonBuilder) -> Self {
        let states = automaton.states.iter().cloned().collect::<Vec<_>>();
        let state_ids = states
            .iter()
            .enumerate()
            .map(|(index, state)| (state.clone(), index))
            .collect::<BTreeMap<_, _>>();
        let words = states.len().div_ceil(64);
        let mut epsilon_closure = vec![vec![0; words]; states.len()];
        for (index, state) in states.iter().enumerate() {
            epsilon_closure[index][index / 64] |= 1 << (index % 64);
            if let Some(reachable) = automaton.epsilon_forward.get(state) {
                for target in reachable {
                    if let Some(&target_index) = state_ids.get(target) {
                        epsilon_closure[index][target_index / 64] |= 1 << (target_index % 64);
                    }
                }
            }
        }
        let mut compatibility = vec![vec![0; words]; states.len()];
        if automaton.state_compatibility.is_empty() {
            for index in 0..states.len() {
                compatibility[index][index / 64] |= 1 << (index % 64);
            }
        } else {
            for (source, target) in &automaton.state_compatibility {
                let (Some(&source), Some(&target)) = (state_ids.get(source), state_ids.get(target))
                else {
                    continue;
                };
                compatibility[source][target / 64] |= 1 << (target % 64);
            }
        }

        let mut transition_heads = BTreeMap::new();
        for transition in &automaton.transitions {
            if transition.tail.is_empty() {
                continue;
            }
            let Some(&tail) = state_ids.get(&transition.tail) else {
                continue;
            };
            let Some(&head) = state_ids.get(&transition.head) else {
                continue;
            };
            let by_tail = transition_heads
                .entry(transition.symbol.clone())
                .or_insert_with(BTreeMap::new)
                .entry(transition.height)
                .or_insert_with(|| vec![Vec::new(); states.len()]);
            by_tail[tail].push(head);
        }
        Self {
            states,
            state_ids,
            epsilon_closure,
            compatibility,
            transition_heads,
        }
    }

    #[cfg(test)]
    pub(crate) fn exact_heads(
        &self,
        word: &[crate::core::Symbol],
        height: usize,
        tail: &str,
    ) -> Vec<String> {
        let Some(&tail) = self.state_ids.get(tail) else {
            return Vec::new();
        };
        let reached = self.exact_head_bits(word, height, tail);
        let mut heads = Vec::new();
        Self::for_each_bit(&reached, |state| heads.push(self.states[state].clone()));
        heads
    }

    pub(crate) fn exact_head_bits(
        &self,
        word: &[crate::core::Symbol],
        height: usize,
        tail: usize,
    ) -> Vec<u64> {
        let mut current = vec![0; self.epsilon_closure[tail].len()];
        current[tail / 64] |= 1 << (tail % 64);
        for symbol in word.iter().rev() {
            let mut expanded = vec![0; current.len()];
            Self::for_each_bit(&current, |state| {
                Self::union_bits(&mut expanded, &self.epsilon_closure[state]);
            });
            let Some(by_tail) = self
                .transition_heads
                .get(symbol.as_str())
                .and_then(|by_height| by_height.get(&height))
            else {
                return vec![0; current.len()];
            };
            let mut next = vec![0; current.len()];
            Self::for_each_bit(&expanded, |state| {
                for &head in &by_tail[state] {
                    next[head / 64] |= 1 << (head % 64);
                }
            });
            if next.iter().all(|word| *word == 0) {
                return next;
            }
            current = next;
        }
        let mut reached = vec![0; current.len()];
        Self::for_each_bit(&current, |state| {
            Self::union_bits(&mut reached, &self.epsilon_closure[state]);
        });
        reached
    }

    pub(crate) fn state_id(&self, state: &str) -> Option<usize> {
        self.state_ids.get(state).copied()
    }

    pub(crate) fn state(&self, state: usize) -> &str {
        &self.states[state]
    }

    pub(crate) fn first_bit(bits: &[u64]) -> Option<usize> {
        bits.iter().enumerate().find_map(|(word_index, &word)| {
            (word != 0).then(|| word_index * 64 + word.trailing_zeros() as usize)
        })
    }

    pub(crate) fn has_compatible(&self, source: usize, targets: &[u64]) -> bool {
        self.compatibility[source]
            .iter()
            .zip(targets)
            .any(|(compatible, targets)| compatible & targets != 0)
    }

    pub(crate) fn union_bits(target: &mut [u64], source: &[u64]) {
        for (target, source) in target.iter_mut().zip(source) {
            *target |= source;
        }
    }

    pub(crate) fn for_each_bit(bits: &[u64], mut f: impl FnMut(usize)) {
        for (word_index, &word) in bits.iter().enumerate() {
            let mut remaining = word;
            while remaining != 0 {
                let bit = remaining.trailing_zeros() as usize;
                f(word_index * 64 + bit);
                remaining &= remaining - 1;
            }
        }
    }
}

impl SrsMatchAutomatonBuilder {
    pub(crate) fn empty(max_states: usize, max_transitions: usize) -> Self {
        Self {
            final_state: "q0".to_string(),
            transitions: BTreeSet::new(),
            transition_heads: BTreeMap::new(),
            state_transitions: BTreeSet::new(),
            epsilon_forward: BTreeMap::new(),
            epsilon_backward: BTreeMap::new(),
            state_compatibility: BTreeSet::new(),
            states: BTreeSet::from(["q0".to_string()]),
            next_state: 1,
            compact_rhs_states: None,
            bidirectional_rhs: false,
            max_states,
            max_transitions,
        }
    }

    pub(crate) fn accepting_all_ground_strings(
        symbol_arities: &BTreeMap<String, usize>,
        max_states: usize,
        max_transitions: usize,
    ) -> Self {
        let mut builder = Self::empty(max_states, max_transitions);
        for (symbol, arity) in symbol_arities {
            let state = builder.final_state.clone();
            if *arity == 0 {
                builder.insert_transition(symbol, 0, "", &state);
            } else {
                builder.insert_transition(symbol, 0, &state, &state);
            }
        }
        builder
    }

    pub(crate) fn accepting_all_ground_strings_compact(
        symbol_arities: &BTreeMap<String, usize>,
        max_states: usize,
        max_transitions: usize,
    ) -> Self {
        let mut builder =
            Self::accepting_all_ground_strings(symbol_arities, max_states, max_transitions);
        builder.compact_rhs_states = Some(BTreeMap::new());
        builder
    }

    pub(crate) fn accepting_initial_words(
        initial_words: &[Vec<crate::core::Symbol>],
        max_states: usize,
        max_transitions: usize,
    ) -> Option<Self> {
        let mut builder = Self::empty(max_states, max_transitions);
        for word in initial_words {
            let final_state = builder.final_state.clone();
            builder.add_rhs_path(word, 0, &final_state, &final_state)?;
        }
        Some(builder)
    }

    pub(crate) fn from_completion_for_validation(
        completion: SrsMatchCompletion,
        max_states: usize,
        max_transitions: usize,
    ) -> Option<Self> {
        let mut builder = Self::empty(max_states, max_transitions);
        builder.final_state = completion
            .automaton
            .final_states
            .first()
            .cloned()
            .unwrap_or_else(|| "q0".to_string());
        builder.states.clear();
        builder.states.insert(builder.final_state.clone());
        builder.state_compatibility = completion.state_compatibility.into_iter().collect();
        let mut epsilon_transitions = BTreeSet::new();
        for transition in completion.automaton.transitions {
            match transition.lhs {
                TreeAutomatonTransitionLhs::State(source) => {
                    epsilon_transitions.insert((source, transition.rhs));
                }
                TreeAutomatonTransitionLhs::Symbol {
                    symbol,
                    height,
                    args,
                } => {
                    let tail = match args.as_slice() {
                        [] => "",
                        [tail] => tail.as_str(),
                        _ => return None,
                    };
                    builder.insert_transition(&symbol, height.unwrap_or(0), tail, &transition.rhs);
                }
            }
        }
        builder.insert_epsilon_batch(&epsilon_transitions)?;
        if builder.states.len() > max_states
            || builder.transitions.len() + builder.state_transitions.len() > max_transitions
        {
            return None;
        }
        Some(builder)
    }

    pub(crate) fn insert_transition(
        &mut self,
        symbol: &str,
        height: usize,
        tail: &str,
        head: &str,
    ) -> bool {
        self.states.insert(head.to_string());
        if !tail.is_empty() {
            self.states.insert(tail.to_string());
        }
        let transition = SrsMatchTransition {
            symbol: symbol.to_string(),
            height,
            tail: tail.to_string(),
            head: head.to_string(),
        };
        if !self.transitions.insert(transition) {
            return false;
        }
        self.transition_heads
            .entry(symbol.to_string())
            .or_default()
            .entry(height)
            .or_default()
            .entry(tail.to_string())
            .or_default()
            .insert(head.to_string());
        true
    }

    pub(crate) fn add_rhs_path(
        &mut self,
        rhs: &[crate::core::Symbol],
        height: usize,
        tail: &str,
        head: &str,
    ) -> Option<bool> {
        if rhs.is_empty() {
            return Some(self.insert_epsilon(tail, head)?);
        }
        if self.has_rhs_path(rhs, height, tail, head) {
            return Some(false);
        }
        if self.bidirectional_rhs && !tail.is_empty() && !head.is_empty() {
            return self.add_bidirectional_rhs_path(rhs, height, tail, head);
        }
        let mut changed = false;
        let mut current_tail = tail.to_string();
        let compact_word = self.compact_rhs_states.as_ref().map(|_| {
            rhs.iter()
                .map(|symbol| symbol.as_str().to_string())
                .collect::<Vec<_>>()
        });
        for (index, symbol) in rhs.iter().rev().enumerate() {
            let is_head = index + 1 == rhs.len();
            let current_head = if is_head {
                head.to_string()
            } else if let Some(word) = compact_word.as_ref() {
                let key = (word.clone(), height, index, head.to_string());
                if let Some(state) = self
                    .compact_rhs_states
                    .as_ref()
                    .and_then(|states| states.get(&key))
                {
                    state.clone()
                } else {
                    let state = self.fresh_state()?;
                    self.compact_rhs_states
                        .as_mut()
                        .expect("compact state map is enabled")
                        .insert(key, state.clone());
                    state
                }
            } else if let Some(reusable) =
                self.reusable_transition_head(symbol.as_str(), height, &current_tail)
            {
                reusable
            } else {
                self.fresh_state()?
            };
            changed |=
                self.insert_transition(symbol.as_str(), height, &current_tail, &current_head);
            current_tail = current_head;
        }
        Some(changed)
    }

    /// Reuse existing fixed-height runs at both ends of a missing RHS path.
    /// Only the gap is allocated. This is a construction heuristic, not a
    /// compatibility shortcut: completion still checks every resulting run.
    fn add_bidirectional_rhs_path(
        &mut self,
        rhs: &[Symbol],
        height: usize,
        tail: &str,
        head: &str,
    ) -> Option<bool> {
        let mut prefixes = vec![BTreeSet::from([tail.to_string()])];
        for symbol in rhs.iter().rev().take(rhs.len() - 1) {
            let Some(by_tail) = self
                .transition_heads
                .get(symbol.as_str())
                .and_then(|m| m.get(&height))
            else {
                break;
            };
            let next = prefixes
                .last()?
                .iter()
                .flat_map(|state| by_tail.get(state).into_iter().flatten().cloned())
                .collect::<BTreeSet<_>>();
            if next.is_empty() {
                break;
            }
            prefixes.push(next);
        }
        let mut suffixes = vec![BTreeSet::from([head.to_string()])];
        for symbol in rhs.iter().take(rhs.len() - 1) {
            let Some(by_tail) = self
                .transition_heads
                .get(symbol.as_str())
                .and_then(|m| m.get(&height))
            else {
                break;
            };
            let targets = suffixes.last()?;
            let previous = by_tail
                .iter()
                .filter(|(state, targets_from_state)| {
                    !state.is_empty() && !targets.is_disjoint(targets_from_state)
                })
                .map(|(state, _)| state.clone())
                .collect::<BTreeSet<_>>();
            if previous.is_empty() {
                break;
            }
            suffixes.push(previous);
        }
        let prefix = prefixes.len() - 1;
        let suffix = (suffixes.len() - 1).min(rhs.len() - prefix - 1);
        let mut from = prefixes[prefix].first()?.clone();
        let to = suffixes[suffix].first()?.clone();
        let gap = &rhs[suffix..rhs.len() - prefix];
        let mut changed = false;
        for (index, symbol) in gap.iter().rev().enumerate() {
            let next = if index + 1 == gap.len() {
                to.clone()
            } else {
                self.fresh_state()?
            };
            changed |= self.insert_transition(symbol.as_str(), height, &from, &next);
            from = next;
        }
        Some(changed)
    }

    pub(crate) fn add_merged_rhs_path_to_final(
        &mut self,
        rhs: &[crate::core::Symbol],
        height: usize,
        tail: &str,
    ) -> Option<bool> {
        if rhs.is_empty() {
            let final_state = self.final_state.clone();
            return self.insert_epsilon(tail, &final_state);
        }
        let mut changed = false;
        let mut current_tail = tail.to_string();
        let final_state = self.final_state.clone();
        for symbol in rhs.iter().rev() {
            changed |= self.insert_transition(symbol.as_str(), height, &current_tail, &final_state);
            current_tail = final_state.clone();
        }
        Some(changed)
    }

    pub(crate) fn add_merged_rhs_path_to_head(
        &mut self,
        rhs: &[crate::core::Symbol],
        height: usize,
        tail: &str,
        head: &str,
    ) -> Option<bool> {
        if rhs.is_empty() {
            return self.insert_epsilon(tail, head);
        }
        let mut changed = false;
        let mut current_tail = tail.to_string();
        for symbol in rhs.iter().rev() {
            changed |= self.insert_transition(symbol.as_str(), height, &current_tail, head);
            current_tail = head.to_string();
        }
        Some(changed)
    }

    pub(crate) fn reusable_transition_head(
        &self,
        symbol: &str,
        height: usize,
        tail: &str,
    ) -> Option<String> {
        self.transitions
            .iter()
            .filter(|transition| {
                transition.symbol == symbol
                    && transition.height == height
                    && transition.tail == tail
            })
            .map(|transition| transition.head.clone())
            .next()
    }

    pub(crate) fn has_rhs_path(
        &self,
        rhs: &[crate::core::Symbol],
        height: usize,
        tail: &str,
        head: &str,
    ) -> bool {
        let mut current = BTreeSet::from([tail.to_string()]);
        for symbol in rhs.iter().rev() {
            let mut next = BTreeSet::new();
            for state in &current {
                for reachable in self.epsilon_reachable(state) {
                    if let Some(heads) = self.transition_heads(symbol.as_str(), height, &reachable)
                    {
                        next.extend(heads.iter().cloned());
                    }
                }
            }
            if next.is_empty() {
                return false;
            }
            current = next;
        }
        current.iter().any(|state| {
            self.epsilon_reachable(state)
                .iter()
                .any(|target| target == head)
        })
    }

    pub(crate) fn exact_heads_for_word(
        &self,
        word: &[crate::core::Symbol],
        height: usize,
        tail: &str,
    ) -> Vec<String> {
        let mut current = BTreeSet::from([tail.to_string()]);
        for symbol in word.iter().rev() {
            let mut next = BTreeSet::new();
            for state in &current {
                for reachable in self.epsilon_reachable(state) {
                    if let Some(heads) = self.transition_heads(symbol.as_str(), height, &reachable)
                    {
                        next.extend(heads.iter().cloned());
                    }
                }
            }
            if next.is_empty() {
                return Vec::new();
            }
            current = next;
        }
        let mut reached = BTreeSet::new();
        for state in current {
            for head in self.epsilon_reachable(&state) {
                reached.insert(head);
            }
        }
        reached.into_iter().collect()
    }

    #[cfg(test)]
    pub(crate) fn native_heads_for_labeled_word(
        &self,
        word: &[crate::core::Symbol],
        heights: &[usize],
        tail: &str,
    ) -> BTreeSet<String> {
        if word.len() != heights.len() {
            return BTreeSet::new();
        }
        let mut current = BTreeSet::from([tail.to_string()]);
        for (offset, (symbol, height)) in word.iter().zip(heights).rev().enumerate() {
            let inputs = if offset == 0 {
                current
            } else {
                current
                    .iter()
                    .flat_map(|state| self.epsilon_reachable(state))
                    .collect()
            };
            let mut next = BTreeSet::new();
            for state in inputs {
                if let Some(heads) = self.transition_heads(symbol.as_str(), *height, &state) {
                    next.extend(heads.iter().cloned());
                }
            }
            if next.is_empty() {
                return next;
            }
            current = next;
        }
        current
    }

    #[cfg(test)]
    pub(crate) fn native_heads_for_word(
        &self,
        word: &[crate::core::Symbol],
        height: usize,
        tail: &str,
    ) -> BTreeSet<String> {
        self.native_heads_for_labeled_word(word, &vec![height; word.len()], tail)
    }

    pub(crate) fn insert_epsilon(&mut self, source: &str, target: &str) -> Option<bool> {
        if source == target
            || self
                .epsilon_forward
                .get(source)
                .is_some_and(|reachable| reachable.contains(target))
        {
            return Some(false);
        }
        self.states.insert(source.to_string());
        self.states.insert(target.to_string());
        if !self
            .state_transitions
            .insert((source.to_string(), target.to_string()))
        {
            return Some(false);
        }
        let mut predecessors = self
            .epsilon_backward
            .get(source)
            .cloned()
            .unwrap_or_default();
        predecessors.insert(source.to_string());
        let mut successors = self
            .epsilon_forward
            .get(target)
            .cloned()
            .unwrap_or_default();
        successors.insert(target.to_string());
        for predecessor in predecessors {
            for successor in &successors {
                if predecessor == *successor {
                    continue;
                }
                self.epsilon_forward
                    .entry(predecessor.clone())
                    .or_default()
                    .insert(successor.clone());
                self.epsilon_backward
                    .entry(successor.clone())
                    .or_default()
                    .insert(predecessor.clone());
            }
        }
        Some(true)
    }

    pub(crate) fn insert_epsilon_from_closed_relation(
        &mut self,
        source: &str,
        target: &str,
    ) -> bool {
        if source == target {
            return false;
        }
        self.states.insert(source.to_string());
        self.states.insert(target.to_string());
        if !self
            .state_transitions
            .insert((source.to_string(), target.to_string()))
        {
            return false;
        }
        self.epsilon_forward
            .entry(source.to_string())
            .or_default()
            .insert(target.to_string());
        self.epsilon_backward
            .entry(target.to_string())
            .or_default()
            .insert(source.to_string());
        true
    }

    pub(crate) fn insert_epsilon_batch(
        &mut self,
        required: &BTreeSet<(String, String)>,
    ) -> Option<bool> {
        let started = Instant::now();
        let required = required
            .iter()
            .filter(|(source, target)| {
                source != target
                    && !self
                        .epsilon_forward
                        .get(source)
                        .is_some_and(|reachable| reachable.contains(target))
            })
            .cloned()
            .collect::<Vec<_>>();
        if required.is_empty() {
            return Some(false);
        }
        write_progress_event(
            "rfc-matchbox",
            "epsilon-batch",
            "prepare",
            started.elapsed().as_millis(),
            &format!(
                "required={} states={} explicit_epsilons={}",
                required.len(),
                self.states.len(),
                self.state_transitions.len()
            ),
        );
        if self.transitions.len() + self.state_transitions.len() + required.len()
            > self.max_transitions
        {
            return None;
        }
        for (source, target) in &required {
            self.states.insert(source.clone());
            self.states.insert(target.clone());
            self.state_transitions
                .insert((source.clone(), target.clone()));
        }

        let states = self.states.iter().cloned().collect::<Vec<_>>();
        let state_ids = states
            .iter()
            .enumerate()
            .map(|(index, state)| (state.clone(), index))
            .collect::<BTreeMap<_, _>>();
        let bit_words = states.len().div_ceil(64);
        let mut closure = vec![vec![0u64; bit_words]; states.len()];
        for (index, state) in states.iter().enumerate() {
            closure[index][index / 64] |= 1 << (index % 64);
            if let Some(reachable) = self.epsilon_forward.get(state) {
                for target in reachable {
                    let target = state_ids[target];
                    closure[index][target / 64] |= 1 << (target % 64);
                }
            }
        }
        for (source, target) in &required {
            let source = state_ids[source];
            let target = state_ids[target];
            closure[source][target / 64] |= 1 << (target % 64);
        }
        for intermediate in 0..states.len() {
            let intermediate_row = closure[intermediate].clone();
            for row in &mut closure {
                if row[intermediate / 64] & (1 << (intermediate % 64)) != 0 {
                    SrsMatchWordIndex::union_bits(row, &intermediate_row);
                }
            }
        }
        write_progress_event(
            "rfc-matchbox",
            "epsilon-batch",
            "closure",
            started.elapsed().as_millis(),
            &format!("required={} states={}", required.len(), states.len()),
        );

        self.epsilon_forward.clear();
        self.epsilon_backward.clear();
        for (source, row) in closure.iter().enumerate() {
            SrsMatchWordIndex::for_each_bit(row, |target| {
                if source != target {
                    self.epsilon_forward
                        .entry(states[source].clone())
                        .or_default()
                        .insert(states[target].clone());
                    self.epsilon_backward
                        .entry(states[target].clone())
                        .or_default()
                        .insert(states[source].clone());
                }
            });
        }
        write_progress_event(
            "rfc-matchbox",
            "epsilon-batch",
            "finish",
            started.elapsed().as_millis(),
            &format!(
                "required={} states={} reachable_pairs={}",
                required.len(),
                states.len(),
                self.epsilon_forward
                    .values()
                    .map(BTreeSet::len)
                    .sum::<usize>()
            ),
        );
        Some(true)
    }

    pub(crate) fn quotient_epsilon_sccs(&mut self) -> Option<BTreeMap<String, String>> {
        let states = self.states.iter().cloned().collect::<Vec<_>>();
        let mut quotient = BTreeMap::new();
        let mut representatives = Vec::new();
        for state in &states {
            let representative = representatives
                .iter()
                .find(|representative| {
                    self.epsilon_forward
                        .get(state)
                        .is_some_and(|reachable| reachable.contains(*representative))
                        && self
                            .epsilon_forward
                            .get(*representative)
                            .is_some_and(|reachable| reachable.contains(state))
                })
                .cloned()
                .unwrap_or_else(|| {
                    representatives.push(state.clone());
                    state.clone()
                });
            quotient.insert(state.clone(), representative);
        }
        if representatives.len() == states.len() {
            return Some(quotient);
        }

        let remap = |state: &str| {
            quotient
                .get(state)
                .cloned()
                .unwrap_or_else(|| state.to_string())
        };
        let transitions = self
            .transitions
            .iter()
            .map(|transition| SrsMatchTransition {
                symbol: transition.symbol.clone(),
                height: transition.height,
                tail: if transition.tail.is_empty() {
                    String::new()
                } else {
                    remap(&transition.tail)
                },
                head: remap(&transition.head),
            })
            .collect::<BTreeSet<_>>();
        let state_transitions = self
            .state_transitions
            .iter()
            .map(|(source, target)| (remap(source), remap(target)))
            .filter(|(source, target)| source != target)
            .collect::<BTreeSet<_>>();
        let state_compatibility = self
            .state_compatibility
            .iter()
            .map(|(source, target)| (remap(source), remap(target)))
            .collect::<BTreeSet<_>>();

        self.final_state = remap(&self.final_state);
        self.transitions.clear();
        self.transition_heads.clear();
        self.state_transitions.clear();
        self.epsilon_forward.clear();
        self.epsilon_backward.clear();
        self.state_compatibility = state_compatibility;
        self.states = representatives.into_iter().collect();
        for transition in transitions {
            self.insert_transition(
                &transition.symbol,
                transition.height,
                &transition.tail,
                &transition.head,
            );
        }
        for (source, target) in state_transitions {
            self.insert_epsilon(&source, &target)?;
        }
        Some(quotient)
    }

    pub(crate) fn transition_heads(
        &self,
        symbol: &str,
        height: usize,
        tail: &str,
    ) -> Option<&BTreeSet<String>> {
        self.transition_heads.get(symbol)?.get(&height)?.get(tail)
    }

    pub(crate) fn insert_state_compatibility(&mut self, source: &str, target: &str) -> bool {
        self.states.insert(source.to_string());
        self.states.insert(target.to_string());
        self.state_compatibility
            .insert((source.to_string(), target.to_string()))
    }

    pub(crate) fn ensure_identity_state_compatibility(&mut self) -> bool {
        let states = self.states.iter().cloned().collect::<Vec<_>>();
        states
            .iter()
            .map(|state| self.insert_state_compatibility(state, state))
            .fold(false, |changed, inserted| changed | inserted)
    }

    pub(crate) fn state_compatibility_contains(&self, source: &str, target: &str) -> bool {
        if self.state_compatibility.is_empty() {
            source == target
        } else {
            self.state_compatibility
                .contains(&(source.to_string(), target.to_string()))
        }
    }

    pub(crate) fn fresh_state(&mut self) -> Option<String> {
        if self.states.len() >= self.max_states {
            return None;
        }
        let state = format!("q{}", self.next_state);
        self.next_state += 1;
        self.states.insert(state.clone());
        Some(state)
    }

    #[allow(dead_code)]
    pub(crate) fn word_reaches(
        &self,
        word: &[crate::core::Symbol],
        tail: &str,
        head: &str,
    ) -> bool {
        self.has_rhs_path(word, 0, tail, head)
    }

    pub(crate) fn word_reaches_at_height(
        &self,
        word: &[crate::core::Symbol],
        height: usize,
        tail: &str,
        head: &str,
    ) -> bool {
        self.has_rhs_path(word, height, tail, head)
    }

    #[allow(dead_code)]
    pub(crate) fn word_reaches_some(&self, word: &[crate::core::Symbol], tail: &str) -> bool {
        self.states
            .iter()
            .any(|head| self.word_reaches(word, tail, head))
    }

    #[allow(dead_code)]
    pub(crate) fn accepts_initial_words_from_all_states(
        &self,
        initial_words: &[Vec<crate::core::Symbol>],
    ) -> bool {
        initial_words.iter().all(|word| {
            self.states
                .iter()
                .all(|state| self.word_reaches(word, state, &self.final_state))
        })
    }

    #[allow(dead_code)]
    pub(crate) fn is_rfc_automaton_closed(&self, rules: &[crate::core::SrsRule]) -> bool {
        rules.iter().all(|rule| {
            let lhs = rule.lhs();
            !lhs.is_empty()
                && (1..=lhs.len()).all(|split| {
                    let prefix = &lhs[..split];
                    let suffix = &lhs[split..];
                    self.states.iter().all(|tail| {
                        self.states.iter().all(|middle| {
                            self.states.iter().all(|head| {
                                !(self.word_reaches(suffix, tail, middle)
                                    && self.word_reaches(prefix, middle, head))
                                    || self.word_reaches(rule.rhs(), tail, head)
                            })
                        })
                    })
                })
        })
    }

    pub(crate) fn is_rfc_matchbox_closed(&self, rules: &[crate::core::SrsRule]) -> bool {
        let index = SrsMatchWordIndex::new(self);
        rules.iter().all(|rule| {
            !rule.lhs().is_empty() && (0..index.states.len()).all(|tail| {
                let rhs = index.exact_head_bits(rule.rhs(), 0, tail);
                let lhs = index.exact_head_bits(rule.lhs(), 0, tail);
                let mut compatible = true;
                SrsMatchWordIndex::for_each_bit(&lhs, |head| {
                    compatible &= index.has_compatible(head, &rhs);
                });
                compatible
            })
        })
    }

    #[cfg(test)]
    fn is_rfc_matchbox_closed_unindexed(&self, rules: &[crate::core::SrsRule]) -> bool {
        rules.iter().all(|rule| {
            let lhs = rule.lhs();
            !lhs.is_empty()
                && self.states.iter().all(|tail| {
                    let rhs_heads = self.exact_heads_for_word(rule.rhs(), 0, tail);
                    self.exact_heads_for_word(lhs, 0, tail).iter().all(|head| {
                        rhs_heads
                            .iter()
                            .any(|rhs_head| self.state_compatibility_contains(head, rhs_head))
                    })
                })
        })
    }

    #[cfg(test)]
    pub(crate) fn is_rfc_native_matchbox_closed(&self, rules: &[crate::core::SrsRule]) -> bool {
        rules.iter().all(|rule| {
            !rule.lhs().is_empty()
                && self.states.iter().all(|tail| {
                    self.native_heads_for_word(rule.lhs(), 0, tail)
                        .is_subset(&self.native_heads_for_word(rule.rhs(), 0, tail))
                })
        })
    }

    #[cfg(test)]
    pub(crate) fn is_rfc_native_matchbox_closed_with_relation(
        &self,
        rules: &[crate::core::SrsRule],
    ) -> bool {
        rules.iter().all(|rule| {
            !rule.lhs().is_empty()
                && self.states.iter().all(|tail| {
                    let rhs_heads = self.native_heads_for_word(rule.rhs(), 0, tail);
                    self.native_heads_for_word(rule.lhs(), 0, tail)
                        .iter()
                        .all(|lhs_head| {
                            rhs_heads.iter().any(|rhs_head| {
                                self.state_compatibility_contains(lhs_head, rhs_head)
                            })
                        })
                })
        })
    }

    #[cfg(test)]
    pub(crate) fn are_rfc_tail_states_epsilon_closed(&self, tail_states: &[String]) -> bool {
        let tails = tail_states.iter().collect::<BTreeSet<_>>();
        tail_states.iter().all(|tail| {
            self.epsilon_reachable(tail)
                .iter()
                .all(|state| tails.contains(state))
        })
    }

    pub(crate) fn is_rfc_matchbox_ext_right(&self, rules: &[crate::core::SrsRule]) -> bool {
        self.is_rfc_matchbox_ext_right_from_tail_states(rules, &self.states)
    }

    pub(crate) fn is_rfc_matchbox_ext_right_from_tail_states(
        &self,
        rules: &[crate::core::SrsRule],
        tail_states: &BTreeSet<String>,
    ) -> bool {
        let index = SrsMatchWordIndex::new(self);
        rules.iter().all(|rule| {
            !rule.lhs().is_empty() && tail_states.iter().all(|tail| {
                // No nonempty prefix is reachable from an absent state.
                let Some(tail) = index.state_id(tail) else { return true; };
                let rhs = index.exact_head_bits(rule.rhs(), 0, tail);
                (1..rule.lhs().len()).all(|split| {
                    let heads = index.exact_head_bits(&rule.lhs()[..split], 0, tail);
                    let mut compatible = true;
                    SrsMatchWordIndex::for_each_bit(&heads, |head| {
                        compatible &= index.has_compatible(head, &rhs);
                    });
                    compatible
                })
            })
        })
    }

    #[cfg(test)]
    fn is_rfc_matchbox_ext_right_from_tail_states_unindexed(
        &self,
        rules: &[crate::core::SrsRule],
        tail_states: &BTreeSet<String>,
    ) -> bool {
        rules.iter().all(|rule| {
            let lhs = rule.lhs();
            !lhs.is_empty()
                && (1..lhs.len()).all(|split| {
                    let prefix = &lhs[..split];
                    tail_states.iter().all(|tail| {
                        let rhs_heads = self.exact_heads_for_word(rule.rhs(), 0, tail);
                        self.exact_heads_for_word(prefix, 0, tail)
                            .iter()
                            .all(|prefix_head| {
                                rhs_heads.iter().any(|rhs_head| {
                                    self.state_compatibility_contains(prefix_head, rhs_head)
                                })
                            })
                    })
                })
        })
    }

    pub(crate) fn ensure_rfc_matchbox_ext_right(
        &mut self,
        rules: &[crate::core::SrsRule],
        deadline: Option<Instant>,
    ) -> Option<bool> {
        self.ensure_rfc_matchbox_ext_right_from_tail_states(rules, &self.states.clone(), deadline)
    }

    pub(crate) fn ensure_rfc_matchbox_ext_right_relations(
        &mut self,
        rules: &[crate::core::SrsRule],
        rule_tails: &[String],
        tail_states: &BTreeSet<String>,
        deadline: Option<Instant>,
    ) -> Option<bool> {
        if rules.len() != rule_tails.len() {
            return None;
        }
        let mut changed = self.ensure_identity_state_compatibility();
        let mut iterations = 0usize;
        loop {
            if current_thread_cancelled() || deadline.is_some_and(|limit| Instant::now() >= limit) {
                return None;
            }
            iterations += 1;
            if iterations > DEFAULT_SRS_MATCH_BOUNDS_MAX_ITERATIONS {
                return None;
            }
            let index = SrsMatchWordIndex::new(self);
            let tail_ids = tail_states
                .iter()
                .filter_map(|tail| index.state_id(tail).map(|state| (tail, state)))
                .collect::<Vec<_>>();
            let mut required_epsilons = BTreeSet::new();
            for (rule_index, rule) in rules.iter().enumerate() {
                let lhs = rule.lhs();
                if lhs.is_empty() {
                    return None;
                }
                for split in 1..lhs.len() {
                    let prefix = &lhs[..split];
                    for (tail, tail_id) in &tail_ids {
                        let prefix_heads = index.exact_head_bits(prefix, 0, *tail_id);
                        if SrsMatchWordIndex::first_bit(&prefix_heads).is_none() {
                            continue;
                        }
                        let rhs_heads = index.exact_head_bits(rule.rhs(), 0, *tail_id);
                        let Some(rhs_head) = SrsMatchWordIndex::first_bit(&rhs_heads) else {
                            required_epsilons
                                .insert(((*tail).clone(), rule_tails[rule_index].clone()));
                            continue;
                        };
                        SrsMatchWordIndex::for_each_bit(&prefix_heads, |prefix_head| {
                            if !index.has_compatible(prefix_head, &rhs_heads) {
                                required_epsilons.insert((
                                    index.state(rhs_head).to_string(),
                                    index.state(prefix_head).to_string(),
                                ));
                            }
                        });
                    }
                }
            }
            let epsilon_changed = self.insert_epsilon_batch(&required_epsilons)?;
            changed |= epsilon_changed;
            if !epsilon_changed {
                return Some(changed);
            }
        }
    }

    pub(crate) fn ensure_rfc_matchbox_ext_right_from_tail_states(
        &mut self,
        rules: &[crate::core::SrsRule],
        tail_states: &BTreeSet<String>,
        deadline: Option<Instant>,
    ) -> Option<bool> {
        let mut changed = self.ensure_identity_state_compatibility();
        for rule in rules {
            if current_thread_cancelled() || deadline.is_some_and(|limit| Instant::now() >= limit) {
                return None;
            }
            let lhs = rule.lhs();
            if lhs.is_empty() {
                return None;
            }
            for split in 1..lhs.len() {
                let prefix = &lhs[..split];
                for tail in tail_states {
                    let prefix_heads = self.exact_heads_for_word(prefix, 0, tail);
                    if prefix_heads.is_empty() {
                        continue;
                    }
                    let mut rhs_heads = self.exact_heads_for_word(rule.rhs(), 0, tail);
                    for prefix_head in prefix_heads {
                        if !rhs_heads.iter().any(|candidate| {
                            self.state_compatibility_contains(&prefix_head, candidate)
                        }) {
                            changed |= self.add_merged_rhs_path_to_head(
                                rule.rhs(),
                                0,
                                tail,
                                &prefix_head,
                            )?;
                            rhs_heads = self.exact_heads_for_word(rule.rhs(), 0, tail);
                        }
                    }
                }
            }
        }
        Some(changed)
    }

    pub(crate) fn is_rfc_matchbox_below_top_strict_compatible(
        &self,
        rules: &[crate::core::SrsRule],
        bound: usize,
        deadline: Option<Instant>,
    ) -> Option<bool> {
        let index = SrsMatchWordIndex::new(self);
        for rule in rules {
            if current_thread_cancelled() || deadline.is_some_and(|limit| Instant::now() >= limit) {
                return None;
            }
            // This obligation observes only the endpoints and minimum label.
            // Enumerating every run duplicates the same obligation exponentially.
            let lhs_paths = self.strict_paths_for_word(rule.lhs(), deadline)?;
            let mut rhs_cache = BTreeMap::new();
            for lhs_path in lhs_paths {
                if current_thread_cancelled() || deadline.is_some_and(|limit| Instant::now() >= limit) {
                    return None;
                }
                let Some(redex_height) = lhs_path.heights.iter().min().copied() else {
                    continue;
                };
                if redex_height >= bound {
                    continue;
                }
                let rhs_height = redex_height + 1;
                let tail = index.state_id(&lhs_path.tail)?;
                let head = index.state_id(&lhs_path.head)?;
                let rhs = rhs_cache.entry((tail, rhs_height)).or_insert_with(||
                    index.exact_head_bits(rule.rhs(), rhs_height, tail));
                if !index.has_compatible(head, rhs) {
                    return Some(false);
                }
            }
        }
        Some(true)
    }

    pub(crate) fn ensure_rfc_matchbox_below_top_strict_epsilon_bridges(
        &mut self,
        rules: &[crate::core::SrsRule],
        bound: usize,
        deadline: Option<Instant>,
    ) -> Option<bool> {
        let tails = self.states.iter().cloned().collect::<Vec<_>>();
        let mut required = BTreeSet::new();
        for (rule_index, rule) in rules.iter().enumerate() {
            if current_thread_cancelled() || deadline.is_some_and(|limit| Instant::now() >= limit) {
                return None;
            }
            for tail in &tails {
                let lhs_reaches =
                    self.reaches_for_word_from_tail(rule.lhs(), tail, bound, deadline)?;
                for lhs_reach in lhs_reaches {
                    let Some(redex_height) = lhs_reach.min_height else {
                        continue;
                    };
                    if redex_height >= bound {
                        continue;
                    }
                    let rhs_heads = self.exact_heads_for_word(rule.rhs(), redex_height + 1, tail);
                    if rhs_heads.iter().any(|rhs_head| {
                        self.state_compatibility_contains(&lhs_reach.head, rhs_head)
                    }) {
                        continue;
                    }
                    if let Some(rhs_head) = rhs_heads.first() {
                        required.insert((rhs_head.clone(), lhs_reach.head));
                    } else {
                        let canonical_tail = SrsRfcBarrenBuilder::place_state(&SrsRfcBarrenPlace {
                            level: redex_height + 1,
                            rule_index,
                            position: rule.rhs().len(),
                        });
                        let canonical_head = SrsRfcBarrenBuilder::place_state(&SrsRfcBarrenPlace {
                            level: redex_height + 1,
                            rule_index,
                            position: 0,
                        });
                        if !self.states.contains(&canonical_tail)
                            || !self.states.contains(&canonical_head)
                        {
                            return None;
                        }
                        required.insert((tail.clone(), canonical_tail));
                        required.insert((canonical_head, lhs_reach.head));
                    }
                }
            }
        }
        self.insert_epsilon_batch(&required)
    }

    /// Complete selected layered obligations without inventing fresh states.
    /// Epsilon merging may overapproximate, so callers must independently
    /// validate all compatibility and no-top-redex conditions afterwards.
    fn ensure_layered_selected_epsilon_compatibility(
        &mut self, rules: &[crate::core::SrsRule], selected: &[usize], bound: usize,
        strict: bool, deadline: Option<Instant>,
    ) -> Option<bool> {
        let mut required = BTreeSet::new();
        let cap = rules.iter().enumerate().filter(|(i,_)| !selected.contains(i))
            .all(|(_,r)| !r.rhs().is_empty());
        for &index in selected {
            let rule = rules.get(index)?;
            // This pass only collects epsilon obligations; the automaton
            // remains immutable until the final batch insertion. Runs with
            // the same tail and required height therefore share exactly the
            // same RHS reachability query, independently of their LHS head.
            let mut rhs_heads = BTreeMap::new();
            let paths = if strict {self.strict_paths_for_word(rule.lhs(),deadline)?}
                else {self.weak_paths_for_word(rule.lhs(), deadline)?};
            for path in paths {
                if current_thread_cancelled() || deadline.is_some_and(|d| Instant::now() >= d) {return None;}
                let height = *path.heights.first()?;
                if strict && height >= bound {continue;}
                let height = if strict {height + 1} else {
                    // CeTA's Weak_TRS enrichment is not maximum height:
                    // mixed-height redexes use min+1; uniform non-growing
                    // redexes retain their height. Strict erasing rules
                    // disable the optional cap.
                    match_bounds_weak_rhs_height(rule, &path, bound, cap)?
                };
                if height > bound {return None;}
                let heads = rhs_heads.entry((height,path.tail.clone())).or_insert_with(||
                    self.exact_heads_for_word(rule.rhs(),height,&path.tail));
                if heads.contains(&path.head) {continue;}
                if let Some(head) = heads.first() {
                    required.insert((head.clone(),path.head));
                } else {
                    let tail = SrsRfcBarrenBuilder::place_state(&SrsRfcBarrenPlace {level:height,rule_index:index,position:rule.rhs().len()});
                    let head = SrsRfcBarrenBuilder::place_state(&SrsRfcBarrenPlace {level:height,rule_index:index,position:0});
                    if !self.states.contains(&tail) || !self.states.contains(&head) {return None;}
                    required.insert((path.tail,tail));
                    required.insert((head,path.head));
                }
            }
        }
        self.insert_epsilon_batch(&required)
    }

    pub(crate) fn ensure_rfc_matchbox_below_top_strict_compatibility(
        &mut self,
        rules: &[crate::core::SrsRule],
        bound: usize,
        deadline: Option<Instant>,
    ) -> Option<bool> {
        let mut changed = false;
        let mut iterations = 0usize;
        loop {
            if current_thread_cancelled() || deadline.is_some_and(|limit| Instant::now() >= limit) {
                return None;
            }
            iterations += 1;
            if iterations > DEFAULT_SRS_MATCH_BOUNDS_MAX_ITERATIONS {
                return None;
            }
            let mut round_changed = false;
            for rule in rules {
                let lhs_paths = self.strict_paths_for_word(rule.lhs(), deadline)?;
                for lhs_path in lhs_paths {
                    if current_thread_cancelled() || deadline.is_some_and(|limit| Instant::now() >= limit) {
                        return None;
                    }
                    let Some(redex_height) = lhs_path.heights.iter().min().copied() else {
                        continue;
                    };
                    if redex_height >= bound {
                        continue;
                    }
                    let rhs_height = redex_height + 1;
                    if self.word_reaches_at_height(
                        rule.rhs(),
                        rhs_height,
                        &lhs_path.tail,
                        &lhs_path.head,
                    ) {
                        continue;
                    }
                    round_changed |=
                        self.add_rhs_path(rule.rhs(), rhs_height, &lhs_path.tail, &lhs_path.head)?;
                    if self.states.len() > self.max_states
                        || self.transitions.len() + self.state_transitions.len()
                            > self.max_transitions
                    {
                        return None;
                    }
                }
            }
            if !round_changed {
                return Some(changed);
            }
            changed = true;
        }
    }

    pub(crate) fn is_match_bounds_weak_compatible(
        &self,
        rules: &[crate::core::SrsRule],
        deadline: Option<Instant>,
    ) -> Option<bool> {
        for rule in rules {
            if current_thread_cancelled() || deadline.is_some_and(|limit| Instant::now() >= limit) {
                return None;
            }
            let lhs_paths = self.maximum_height_paths_for_word(rule.lhs(), deadline)?;
            for lhs_path in lhs_paths {
                if current_thread_cancelled() || deadline.is_some_and(|limit| Instant::now() >= limit) {
                    return None;
                }
                let Some(redex_height) = lhs_path.heights.iter().max().copied() else {
                    continue;
                };
                if !self.word_reaches_at_height(
                    rule.rhs(),
                    redex_height,
                    &lhs_path.tail,
                    &lhs_path.head,
                ) {
                    return Some(false);
                }
            }
        }
        Some(true)
    }

    pub(crate) fn is_match_bounds_strict_compatible(
        &self,
        rules: &[crate::core::SrsRule],
        bound: usize,
        deadline: Option<Instant>,
    ) -> Option<bool> {
        for rule in rules {
            if current_thread_cancelled() || deadline.is_some_and(|limit| Instant::now() >= limit) {
                return None;
            }
            let lhs_paths = self.strict_paths_for_word(rule.lhs(), deadline)?;
            for lhs_path in lhs_paths {
                let Some(redex_height) = lhs_path.heights.iter().min().copied() else {
                    continue;
                };
                let rhs_height = redex_height + 1;
                if !rule.rhs().is_empty() && rhs_height > bound
                    || !self.word_reaches_at_height(
                        rule.rhs(),
                        rhs_height,
                        &lhs_path.tail,
                        &lhs_path.head,
                    )
                {
                    return Some(false);
                }
            }
        }
        Some(true)
    }

    pub(crate) fn is_ceta_relative_match_bounds_weak_compatible(
        &self,
        rules: &[crate::core::SrsRule],
        bound: usize,
        cap_at_bound: bool,
        deadline: Option<Instant>,
    ) -> Option<bool> {
        let index = SrsMatchWordIndex::new(self);
        for rule in rules {
            if current_thread_cancelled() || deadline.is_some_and(|limit| Instant::now() >= limit) {
                return None;
            }
            let lhs_paths =
                self.weak_paths_for_word(rule.lhs(), deadline)?;
            let mut rhs_cache = BTreeMap::new();
            for lhs_path in lhs_paths {
                let Some(rhs_height) =
                    match_bounds_weak_rhs_height(rule, &lhs_path, bound, cap_at_bound)
                else {
                    return Some(false);
                };
                if rhs_height > bound {
                    return Some(false);
                }
                let tail = index.state_id(&lhs_path.tail)?;
                let head = index.state_id(&lhs_path.head)?;
                let heads = rhs_cache.entry((tail, rhs_height)).or_insert_with(||
                    index.exact_head_bits(rule.rhs(), rhs_height, tail));
                if heads[head / 64] & (1u64 << (head % 64)) == 0 {
                    return Some(false);
                }
            }
        }
        Some(true)
    }

    pub(crate) fn ensure_match_bounds_weak_compatibility(
        &mut self,
        rules: &[crate::core::SrsRule],
        bound: usize,
        cap_at_bound: bool,
        deadline: Option<Instant>,
    ) -> Option<bool> {
        self.ensure_match_bounds_weak_compatibility_indexed(
            rules, bound, cap_at_bound, deadline,
            true,
        )
    }

    fn ensure_match_bounds_weak_compatibility_indexed(
        &mut self,
        rules: &[crate::core::SrsRule],
        bound: usize,
        cap_at_bound: bool,
        deadline: Option<Instant>,
        indexed: bool,
    ) -> Option<bool> {
        let mut changed = false;
        let mut iterations = 0usize;
        loop {
            if current_thread_cancelled() || deadline.is_some_and(|limit| Instant::now() >= limit) {
                return None;
            }
            iterations += 1;
            if iterations > DEFAULT_SRS_MATCH_BOUNDS_MAX_ITERATIONS {
                return None;
            }
            let mut round_changed = false;
            for rule in rules {
                let lhs_paths = self.weak_paths_for_word(rule.lhs(), deadline)?;
                // Completion only adds edges. Positive reachability in this
                // snapshot remains true; negative answers must use the live
                // automaton, since earlier obligations may have added a path.
                let index = indexed.then(|| SrsMatchWordIndex::new(self));
                let mut rhs_cache: BTreeMap<(usize, usize), Vec<u64>> = BTreeMap::new();
                // Newly created paths are absent from the snapshot above.
                // Cache their positive reachability too: completion only adds
                // transitions, so positive answers never need invalidation.
                // A cache miss must still query the current automaton.
                let mut live_rhs_cache: BTreeMap<(String, usize), BTreeSet<String>> =
                    BTreeMap::new();
                let rule_started = Instant::now();
                let mut cached_hits = 0usize;
                let mut live_checks = 0usize;
                for lhs_path in lhs_paths {
                    if current_thread_cancelled() || deadline.is_some_and(|limit| Instant::now() >= limit) {
                        return None;
                    }
                    let Some(redex_height) = match_bounds_weak_rhs_height(rule, &lhs_path, bound, cap_at_bound) else {
                        continue;
                    };
                    if redex_height > bound {
                        return None;
                    }
                    if let Some(index) = index.as_ref() {
                        if let (Some(tail), Some(head)) = (
                            index.state_id(&lhs_path.tail), index.state_id(&lhs_path.head),
                        ) {
                            let heads = rhs_cache.entry((tail, redex_height)).or_insert_with(||
                                index.exact_head_bits(rule.rhs(), redex_height, tail));
                            if heads[head / 64] & (1u64 << (head % 64)) != 0 {
                                cached_hits += 1;
                                continue;
                            }
                        }
                    }
                    let reached = if indexed {
                        let key = (lhs_path.tail.clone(), redex_height);
                        if live_rhs_cache.get(&key).is_some_and(|heads| heads.contains(&lhs_path.head)) {
                            cached_hits += 1;
                            true
                        } else {
                            live_checks += 1;
                            let heads = self.exact_heads_for_word(rule.rhs(), redex_height, &lhs_path.tail)
                                .into_iter().collect::<BTreeSet<_>>();
                            let reached = heads.contains(&lhs_path.head);
                            live_rhs_cache.insert(key, heads);
                            reached
                        }
                    } else {
                        live_checks += 1;
                        self.word_reaches_at_height(rule.rhs(), redex_height, &lhs_path.tail, &lhs_path.head)
                    };
                    if reached {
                        continue;
                    }
                    round_changed |= self.add_rhs_path(
                        rule.rhs(),
                        redex_height,
                        &lhs_path.tail,
                        &lhs_path.head,
                    )?;
                    if self.states.len() > self.max_states
                        || self.transitions.len() + self.state_transitions.len()
                            > self.max_transitions
                    {
                        return None;
                    }
                }
                if indexed && rule_started.elapsed().as_millis() >= 10 {
                    write_progress_event("rfc-matchbox", "weak-rule", "indexed-weak-completion",
                        rule_started.elapsed().as_millis(),
                        &format!("states={} cached_hits={cached_hits} live_checks={live_checks} groups={}",
                            self.states.len(), rhs_cache.len()));
                }
            }
            if !round_changed {
                return Some(changed);
            }
            changed = true;
        }
    }

    #[allow(dead_code)]
    pub(crate) fn has_rfc_lhs_suffix_totality(&self, rules: &[crate::core::SrsRule]) -> bool {
        rules.iter().all(|rule| {
            let lhs = rule.lhs();
            !lhs.is_empty()
                && (1..lhs.len()).all(|split| {
                    let suffix = &lhs[split..];
                    self.states
                        .iter()
                        .all(|tail| self.word_reaches_some(suffix, tail))
                })
        })
    }

    pub(crate) fn has_no_rfc_top_redex_at_bound(
        &self,
        rules: &[crate::core::SrsRule],
        bound: usize,
    ) -> bool {
        let index = SrsMatchWordIndex::new(self);
        rules.iter().all(|rule| {
            let lhs = rule.lhs();
            !lhs.is_empty()
                && (0..index.states.len()).all(|tail|
                    index.exact_head_bits(lhs, bound, tail).iter().all(|word| *word == 0))
        })
    }

    #[allow(dead_code)]
    pub(crate) fn ensure_rfc_side_conditions(
        &mut self,
        initial_words: &[Vec<crate::core::Symbol>],
        rules: &[crate::core::SrsRule],
        deadline: Option<Instant>,
    ) -> Option<bool> {
        let mut changed = false;
        loop {
            if current_thread_cancelled() || deadline.is_some_and(|limit| Instant::now() >= limit) {
                return None;
            }
            let mut round_changed = false;
            let states = self.states.iter().cloned().collect::<Vec<_>>();
            let mut symbols = BTreeSet::new();
            for word in initial_words {
                symbols.extend(word.iter().map(|symbol| symbol.as_str().to_string()));
            }
            for rule in rules {
                symbols.extend(rule.lhs().iter().map(|symbol| symbol.as_str().to_string()));
                symbols.extend(rule.rhs().iter().map(|symbol| symbol.as_str().to_string()));
            }
            for state in &states {
                let final_state = self.final_state.clone();
                round_changed |= self.insert_epsilon(state, &final_state)?;
                for symbol in &symbols {
                    round_changed |= self.insert_transition(symbol, 0, state, state);
                }
                for rule in rules {
                    let lhs = rule.lhs();
                    if lhs.is_empty() {
                        return None;
                    }
                }
                if self.states.len() > self.max_states
                    || self.transitions.len() + self.state_transitions.len() > self.max_transitions
                {
                    return None;
                }
            }
            changed |= round_changed;
            if !round_changed {
                break;
            }
        }
        Some(changed)
    }

    pub(crate) fn ensure_rfc_matchbox_closure(
        &mut self,
        rules: &[crate::core::SrsRule],
        deadline: Option<Instant>,
    ) -> Option<bool> {
        let mut changed = self.ensure_identity_state_compatibility();
        for rule in rules {
            if current_thread_cancelled() || deadline.is_some_and(|limit| Instant::now() >= limit) {
                return None;
            }
            let lhs = rule.lhs();
            if lhs.is_empty() {
                return None;
            }
            for split in 1..=lhs.len() {
                let prefix = &lhs[..split];
                let suffix = &lhs[split..];
                let states = self.states.iter().cloned().collect::<Vec<_>>();
                for tail in &states {
                    let suffix_paths =
                        self.reaches_for_word_from_tail(suffix, tail, 0, deadline)?;
                    let rhs_paths =
                        self.reaches_for_word_from_tail(rule.rhs(), tail, 0, deadline)?;
                    if rhs_paths.is_empty() {
                        continue;
                    }
                    for suffix_path in suffix_paths {
                        let prefix_paths = self.reaches_for_word_from_tail(
                            prefix,
                            &suffix_path.head,
                            0,
                            deadline,
                        )?;
                        for prefix_path in prefix_paths {
                            if rhs_paths.iter().any(|rhs_path| {
                                self.state_compatibility_contains(&prefix_path.head, &rhs_path.head)
                            }) {
                                continue;
                            }
                            let rhs_head = rhs_paths.first()?.head.clone();
                            changed |=
                                self.insert_state_compatibility(&prefix_path.head, &rhs_head);
                        }
                    }
                }
            }
        }
        Some(changed)
    }

    pub(crate) fn ensure_rfc_matchbox_closure_epsilons(
        &mut self,
        rules: &[crate::core::SrsRule],
        rule_tails: &[String],
        deadline: Option<Instant>,
    ) -> Option<bool> {
        if rules.len() != rule_tails.len() {
            return None;
        }
        let mut changed = self.ensure_identity_state_compatibility();
        let mut iterations = 0usize;
        loop {
            if current_thread_cancelled() || deadline.is_some_and(|limit| Instant::now() >= limit) {
                return None;
            }
            iterations += 1;
            if iterations > DEFAULT_SRS_MATCH_BOUNDS_MAX_ITERATIONS {
                return None;
            }
            let index = SrsMatchWordIndex::new(self);
            let compute_chunk = |(rule_index, tail_start, tail_end): (usize, usize, usize)| {
                let rule_started = Instant::now();
                let rule = &rules[rule_index];
                let lhs = rule.lhs();
                if lhs.is_empty() {
                    return None;
                }
                let mut required = BTreeSet::new();
                for tail in tail_start..tail_end {
                    if current_thread_cancelled()
                        || deadline.is_some_and(|limit| Instant::now() >= limit)
                    {
                        return None;
                    }
                    let lhs_heads = index.exact_head_bits(lhs, 0, tail);
                    if SrsMatchWordIndex::first_bit(&lhs_heads).is_none() {
                        continue;
                    }
                    let rhs_heads = index.exact_head_bits(rule.rhs(), 0, tail);
                    let Some(rhs_head) = SrsMatchWordIndex::first_bit(&rhs_heads) else {
                        required.insert((
                            index.state(tail).to_string(),
                            rule_tails[rule_index].clone(),
                        ));
                        continue;
                    };
                    SrsMatchWordIndex::for_each_bit(&lhs_heads, |lhs_head| {
                        if !index.has_compatible(lhs_head, &rhs_heads) {
                            required.insert((
                                index.state(rhs_head).to_string(),
                                index.state(lhs_head).to_string(),
                            ));
                        }
                    });
                }
                let elapsed_ms = rule_started.elapsed().as_millis();
                if elapsed_ms >= 10 || !required.is_empty() {
                    write_progress_event(
                        "rfc-matchbox",
                        "closure-chunk",
                        "exact-right-barren-paired-tail",
                        elapsed_ms,
                        &format!(
                            "rule={} tails={}..{} states={} required={}",
                            rule_index,
                            tail_start,
                            tail_end,
                            index.states.len(),
                            required.len()
                        ),
                    );
                }
                Some(required)
            };
            let parallel_work = rules.len().saturating_mul(index.states.len()) >= 4096;
            let per_rule = if parallel_work {
                let states_len = index.states.len();
                let tasks = (0..rules.len())
                    .flat_map(|rule_index| {
                        let chunk_size = 32;
                        (0..states_len).step_by(chunk_size).map(move |tail_start| {
                            (
                                rule_index,
                                tail_start,
                                (tail_start + chunk_size).min(states_len),
                            )
                        })
                    })
                    .collect::<Vec<_>>();
                let pool = rayon::ThreadPoolBuilder::new()
                    .num_threads(4)
                    .thread_name(|index| format!("ferrum-rfc-closure-{index}"))
                    .build()
                    .ok()?;
                pool.install(|| tasks.into_par_iter().map(compute_chunk).collect::<Vec<_>>())
            } else {
                (0..rules.len())
                    .map(|rule_index| (rule_index, 0, index.states.len()))
                    .map(compute_chunk)
                    .collect::<Vec<_>>()
            };
            let mut required_epsilons = BTreeSet::new();
            for required in per_rule {
                required_epsilons.extend(required?);
            }
            let round_changed = self.insert_epsilon_batch(&required_epsilons)?;
            changed |= round_changed;
            if !round_changed {
                return Some(changed);
            }
        }
    }

    pub(crate) fn reaches_for_word_from_tail(
        &self,
        word: &[crate::core::Symbol],
        tail: &str,
        height_cap: usize,
        deadline: Option<Instant>,
    ) -> Option<Vec<SrsMatchReach>> {
        let mut current: BTreeSet<(String, Option<usize>)> =
            BTreeSet::from([(tail.to_string(), None)]);
        for symbol in word.iter().rev() {
            if current_thread_cancelled() || deadline.is_some_and(|limit| Instant::now() >= limit) {
                return None;
            }
            let mut next = BTreeSet::new();
            for (state, min_height) in &current {
                for reachable_tail in self.epsilon_reachable(state) {
                    let Some(by_height) = self.transition_heads.get(symbol.as_str()) else {
                        continue;
                    };
                    for (height, by_tail) in by_height {
                        let Some(heads) = by_tail.get(&reachable_tail) else {
                            continue;
                        };
                        let transition_height = (*height).min(height_cap);
                        let next_min = Some(match min_height {
                            Some(height) => (*height).min(transition_height),
                            None => transition_height,
                        });
                        next.extend(heads.iter().cloned().map(|head| (head, next_min)));
                    }
                }
            }
            if next.is_empty() {
                return Some(Vec::new());
            }
            current = next;
        }
        let mut reached = BTreeSet::new();
        for (state, min_height) in current {
            for head in self.epsilon_reachable(&state) {
                reached.insert(SrsMatchReach { head, min_height });
            }
        }
        Some(reached.into_iter().collect())
    }

    /// Exact quotient for the weak obligations that inspect only the maximum
    /// label. This must NOT replace paths for uniform-height weak obligations.
    fn maximum_height_paths_for_word(
        &self,
        word: &[crate::core::Symbol],
        deadline: Option<Instant>,
    ) -> Option<Vec<SrsMatchPath>> {
        let mut paths = Vec::new();
        for tail in &self.states {
            let mut current = BTreeSet::from([(tail.clone(), None::<usize>)]);
            for symbol in word.iter().rev() {
                let mut next = BTreeSet::new();
                for (state, maximum) in &current {
                    if current_thread_cancelled() || deadline.is_some_and(|d| Instant::now() >= d) {
                        return None;
                    }
                    for reachable in self.epsilon_reachable(state) {
                        let Some(by_height) = self.transition_heads.get(symbol.as_str()) else {
                            continue;
                        };
                        for (height, by_tail) in by_height {
                            if let Some(heads) = by_tail.get(&reachable) {
                                let maximum = Some(maximum.map_or(*height, |h| h.max(*height)));
                                next.extend(heads.iter().cloned().map(|head| (head, maximum)));
                            }
                        }
                    }
                }
                current = next;
                if current.is_empty() { break; }
            }
            if current_thread_cancelled() || deadline.is_some_and(|d| Instant::now() >= d) {
                return None;
            }
            let mut reached = BTreeSet::new();
            for (state, maximum) in current {
                for head in self.epsilon_reachable(&state) {
                    reached.insert((head, maximum));
                }
            }
            paths.extend(reached.into_iter().map(|(head, maximum)| SrsMatchPath {
                tail: tail.clone(), head, heights: maximum.into_iter().collect(),
            }));
        }
        Some(paths)
    }

    /// Exact weak-obligation quotient: endpoints plus minimum/maximum heights
    /// preserve both min+1 and the uniform-height exception. Dynamic merging
    /// avoids enumerating exponentially many runs with the same obligations.
    fn weak_paths_for_word(
        &self, word: &[crate::core::Symbol], deadline: Option<Instant>,
    ) -> Option<Vec<SrsMatchPath>> {
        let mut paths = Vec::new();
        for tail in &self.states {
            let mut current = BTreeSet::from([(tail.clone(), None::<(usize, usize)>)]);
            for symbol in word.iter().rev() {
                let mut next = BTreeSet::new();
                for (state, extrema) in &current {
                    if current_thread_cancelled() || deadline.is_some_and(|d| Instant::now() >= d) {return None;}
                    for reachable in self.epsilon_reachable(state) {
                        let Some(by_height) = self.transition_heads.get(symbol.as_str()) else {continue;};
                        for (height, by_tail) in by_height {
                            if let Some(heads) = by_tail.get(&reachable) {
                                let extrema = Some(extrema.map_or((*height,*height), |(lo,hi)| (lo.min(*height),hi.max(*height))));
                                next.extend(heads.iter().cloned().map(|head| (head,extrema)));
                            }
                        }
                    }
                }
                current = next;
                if current.is_empty() {break;}
            }
            if current_thread_cancelled() || deadline.is_some_and(|d| Instant::now() >= d) {return None;}
            let mut reached = BTreeSet::new();
            for (state, extrema) in current {
                for head in self.epsilon_reachable(&state) {reached.insert((head,extrema));}
            }
            paths.extend(reached.into_iter().map(|(head,extrema)| SrsMatchPath {
                tail:tail.clone(),head,heights:match extrema {
                    None => vec![], Some((lo,hi)) if lo==hi => vec![lo], Some((lo,hi)) => vec![lo,hi],
                },
            }));
        }
        Some(paths)
    }

    /// Strict match compatibility depends only on endpoints and the minimum
    /// label, not the full height vector or the individual automaton run.
    /// Do not use this quotient for weak compatibility: its uniform-height
    /// side condition needs the original vectors.
    fn strict_paths_for_word(
        &self,
        word: &[crate::core::Symbol],
        deadline: Option<Instant>,
    ) -> Option<Vec<SrsMatchPath>> {
        let mut paths = Vec::new();
        for tail in &self.states {
            if current_thread_cancelled() || deadline.is_some_and(|d| Instant::now() >= d) {
                return None;
            }
            for reached in self.reaches_for_word_from_tail(word, tail, usize::MAX, deadline)? {
                paths.push(SrsMatchPath {
                    tail: tail.clone(),
                    head: reached.head,
                    heights: reached.min_height.into_iter().collect(),
                });
            }
        }
        Some(paths)
    }

    pub(crate) fn paths_for_word(
        &self,
        word: &[crate::core::Symbol],
        max_paths: usize,
        deadline: Option<Instant>,
    ) -> Option<Vec<SrsMatchPath>> {
        let mut paths = Vec::new();
        let word = word
            .iter()
            .map(|symbol| symbol.as_str())
            .collect::<Vec<_>>();
        for tail in &self.states {
            if current_thread_cancelled() || deadline.is_some_and(|limit| Instant::now() >= limit) {
                return None;
            }
            if paths.len() > max_paths {
                return None;
            }
            if !self.collect_paths_for_reversed_word(
                &word,
                word.len(),
                tail,
                tail,
                Vec::new(),
                &mut paths,
                max_paths,
                deadline,
            ) {
                return None;
            }
        }
        Some(paths)
    }

    #[allow(dead_code)]
    pub(crate) fn paths_for_word_from_tail(
        &self,
        word: &[crate::core::Symbol],
        tail: &str,
        max_paths: usize,
        deadline: Option<Instant>,
    ) -> Option<Vec<SrsMatchPath>> {
        let mut paths = Vec::new();
        let word = word
            .iter()
            .map(|symbol| symbol.as_str())
            .collect::<Vec<_>>();
        if !self.collect_paths_for_reversed_word(
            &word,
            word.len(),
            tail,
            tail,
            Vec::new(),
            &mut paths,
            max_paths,
            deadline,
        ) {
            return None;
        }
        Some(paths)
    }

    pub(crate) fn collect_paths_for_reversed_word(
        &self,
        word: &[&str],
        remaining: usize,
        original_tail: &str,
        current_tail: &str,
        heights_rev: Vec<usize>,
        paths: &mut Vec<SrsMatchPath>,
        max_paths: usize,
        deadline: Option<Instant>,
    ) -> bool {
        if current_thread_cancelled()
            || deadline.is_some_and(|limit| Instant::now() >= limit)
            || paths.len() > max_paths
        {
            return false;
        }
        if remaining == 0 {
            for head in self.epsilon_reachable(current_tail) {
                if current_thread_cancelled()
                    || deadline.is_some_and(|limit| Instant::now() >= limit)
                    || paths.len() > max_paths
                {
                    return false;
                }
                let mut heights = heights_rev.clone();
                heights.reverse();
                paths.push(SrsMatchPath {
                    tail: original_tail.to_string(),
                    head,
                    heights,
                });
            }
            return true;
        }
        let symbol = word[remaining - 1];
        for reachable_tail in self.epsilon_reachable(current_tail) {
            let Some(by_height) = self.transition_heads.get(symbol) else {
                continue;
            };
            for (height, by_tail) in by_height {
                let Some(heads) = by_tail.get(&reachable_tail) else {
                    continue;
                };
                for head in heads {
                    let mut heights = heights_rev.clone();
                    heights.push(*height);
                    self.collect_paths_for_reversed_word(
                        word,
                        remaining - 1,
                        original_tail,
                        head,
                        heights,
                        paths,
                        max_paths,
                        deadline,
                    );
                    if current_thread_cancelled()
                        || deadline.is_some_and(|limit| Instant::now() >= limit)
                        || paths.len() > max_paths
                    {
                        return false;
                    }
                }
            }
        }
        true
    }

    pub(crate) fn epsilon_reachable(&self, state: &str) -> Vec<String> {
        let mut reachable = self.epsilon_forward.get(state).cloned().unwrap_or_default();
        reachable.insert(state.to_string());
        reachable.into_iter().collect()
    }

    pub(crate) fn into_completion(self) -> Option<SrsMatchCompletion> {
        if self.transitions.len() + self.state_transitions.len() > self.max_transitions {
            return None;
        }
        let mut transitions = self
            .transitions
            .into_iter()
            .map(|transition| TreeAutomatonTransition {
                lhs: TreeAutomatonTransitionLhs::Symbol {
                    symbol: transition.symbol,
                    height: Some(transition.height),
                    args: if transition.tail.is_empty() {
                        Vec::new()
                    } else {
                        vec![transition.tail]
                    },
                },
                rhs: transition.head,
            })
            .collect::<Vec<_>>();
        transitions.extend(self.state_transitions.into_iter().map(|(source, target)| {
            TreeAutomatonTransition {
                lhs: TreeAutomatonTransitionLhs::State(source),
                rhs: target,
            }
        }));
        Some(SrsMatchCompletion {
            automaton: TreeAutomaton {
                final_states: vec![self.final_state.clone()],
                transitions,
            },
            tail_states: vec![self.final_state],
            state_compatibility: self.state_compatibility.into_iter().collect(),
        })
    }
}

pub(crate) fn complete_srs_match_bounds_completion(
    rules: &[crate::core::SrsRule],
    symbol_arities: &BTreeMap<String, usize>,
    bound: usize,
    max_states: usize,
    max_transitions: usize,
    deadline: Option<Instant>,
) -> Option<SrsMatchCompletion> {
    // The inverse-context/decomposed constructor is retained as an
    // experimental search primitive, but it is not used for certificates.
    // Its compact state merging can expose additional lhs runs after local
    // completion, and Ferrum does not yet implement CeTA's exact exhaustive
    // compatibility check for that representation.  Use the ordinary
    // accepting-all-strings construction until that validation is available.
    let automaton = SrsMatchAutomatonBuilder::accepting_all_ground_strings_compact(
        symbol_arities,
        max_states,
        max_transitions,
    );
    if let Some(completion) = complete_srs_match_bounds_completion_from_builder(
        automaton,
        rules.iter().cloned().map(|rule| (rule, true)).collect(),
        bound,
        max_states,
        max_transitions,
        SrsMatchAtBound::Exact,
        deadline,
    ) {
        return Some(completion);
    }
    // A missing path may already have reusable runs on both ends. The
    // one-sided construction can grow without reaching a finite fixed point;
    // try this independent construction under the same limits and deadline.
    // Every candidate still goes through the exhaustive compatibility check.
    let mut alternative = SrsMatchAutomatonBuilder::accepting_all_ground_strings(
        symbol_arities,
        max_states,
        max_transitions,
    );
    alternative.bidirectional_rhs = true;
    complete_srs_match_bounds_completion_from_builder(
        alternative,
        rules.iter().cloned().map(|rule| (rule, true)).collect(),
        bound,
        max_states,
        max_transitions,
        SrsMatchAtBound::Exact,
        deadline,
    )
}

pub(crate) fn complete_srs_relative_match_bounds_completion(
    strict_rules: &[crate::core::SrsRule],
    weak_rules: &[crate::core::SrsRule],
    symbol_arities: &BTreeMap<String, usize>,
    bound: usize,
    max_states: usize,
    max_transitions: usize,
    deadline: Option<Instant>,
) -> Option<SrsMatchCompletion> {
    if strict_rules.is_empty() {
        return None;
    }
    let automaton = SrsMatchAutomatonBuilder::accepting_all_ground_strings(
        symbol_arities,
        max_states,
        max_transitions,
    );
    let rules = strict_rules
        .iter()
        .cloned()
        .map(|rule| (rule, true))
        .chain(weak_rules.iter().cloned().map(|rule| (rule, false)))
        .collect::<Vec<_>>();
    if let Some(completion) = complete_srs_match_bounds_completion_from_builder(
        automaton,
        rules.clone(),
        bound,
        max_states,
        max_transitions,
        SrsMatchAtBound::Exact,
        deadline,
    ) {
        return Some(completion);
    }
    let mut alternative = SrsMatchAutomatonBuilder::accepting_all_ground_strings(
        symbol_arities,
        max_states,
        max_transitions,
    );
    alternative.bidirectional_rhs = true;
    complete_srs_match_bounds_completion_from_builder(
        alternative,
        rules,
        bound,
        max_states,
        max_transitions,
        SrsMatchAtBound::Exact,
        deadline,
    )
}

#[allow(dead_code)]
pub(crate) fn complete_srs_match_bounds_automaton_for_initial_words(
    rules: &[crate::core::SrsRule],
    initial_words: &[Vec<crate::core::Symbol>],
    bound: usize,
    max_states: usize,
    max_transitions: usize,
    deadline: Option<Instant>,
) -> Option<TreeAutomaton> {
    Some(
        complete_srs_match_bounds_completion_for_initial_words(
            rules,
            initial_words,
            bound,
            max_states,
            max_transitions,
            SrsMatchAtBound::Exact,
            deadline,
        )?
        .automaton,
    )
}

pub(crate) fn complete_srs_match_bounds_completion_for_initial_words(
    rules: &[crate::core::SrsRule],
    initial_words: &[Vec<crate::core::Symbol>],
    bound: usize,
    max_states: usize,
    max_transitions: usize,
    at_bound: SrsMatchAtBound,
    deadline: Option<Instant>,
) -> Option<SrsMatchCompletion> {
    let automaton = SrsMatchAutomatonBuilder::accepting_initial_words(
        initial_words,
        max_states,
        max_transitions,
    )?;
    complete_srs_match_bounds_completion_from_builder(
        automaton,
        rules.iter().cloned().map(|rule| (rule, true)).collect(),
        bound,
        max_states,
        max_transitions,
        at_bound,
        deadline,
    )
}

#[allow(dead_code)]
pub(crate) fn complete_srs_rfc_match_bounds_completion_for_initial_words(
    rules: &[crate::core::SrsRule],
    initial_words: &[Vec<crate::core::Symbol>],
    bound: usize,
    max_states: usize,
    max_transitions: usize,
    at_bound: SrsMatchAtBound,
    deadline: Option<Instant>,
) -> Option<SrsMatchCompletion> {
    let mut automaton = SrsMatchAutomatonBuilder::accepting_initial_words(
        initial_words,
        max_states,
        max_transitions,
    )?;
    let mut iterations = 0usize;
    loop {
        if current_thread_cancelled() || deadline.is_some_and(|limit| Instant::now() >= limit) {
            return None;
        }
        iterations += 1;
        if iterations > DEFAULT_SRS_MATCH_BOUNDS_MAX_ITERATIONS {
            return None;
        }
        let mut changed = automaton.ensure_rfc_side_conditions(initial_words, rules, deadline)?;
        let mut queue = VecDeque::from_iter(rules.iter().cloned());
        while let Some(rule) = queue.pop_front() {
            if current_thread_cancelled() || deadline.is_some_and(|limit| Instant::now() >= limit) {
                return None;
            }
            iterations += 1;
            if iterations > DEFAULT_SRS_MATCH_BOUNDS_MAX_ITERATIONS {
                return None;
            }
            let mut rule_changed = false;
            let lhs = rule.lhs();
            if lhs.is_empty() {
                return None;
            }
            for split in 1..=lhs.len() {
                let prefix = &lhs[..split];
                let suffix = &lhs[split..];
                let states = automaton.states.iter().cloned().collect::<Vec<_>>();
                for tail in &states {
                    if current_thread_cancelled()
                        || deadline.is_some_and(|limit| Instant::now() >= limit)
                    {
                        return None;
                    }
                    match at_bound {
                        SrsMatchAtBound::Exact => {
                            let suffix_paths = automaton.paths_for_word_from_tail(
                                suffix,
                                tail,
                                DEFAULT_SRS_MATCH_BOUNDS_MAX_PATHS,
                                deadline,
                            )?;
                            for suffix_path in suffix_paths {
                                let prefix_paths = automaton.paths_for_word_from_tail(
                                    prefix,
                                    &suffix_path.head,
                                    DEFAULT_SRS_MATCH_BOUNDS_MAX_PATHS,
                                    deadline,
                                )?;
                                for prefix_path in prefix_paths {
                                    let redex_height = suffix_path
                                        .heights
                                        .iter()
                                        .chain(prefix_path.heights.iter())
                                        .min()
                                        .copied()
                                        .unwrap_or(0);
                                    let rhs_height = redex_height + 1;
                                    if !rule.rhs().is_empty() && rhs_height > bound {
                                        return None;
                                    }
                                    rule_changed |= automaton.add_rhs_path(
                                        rule.rhs(),
                                        rhs_height,
                                        tail,
                                        &prefix_path.head,
                                    )?;
                                    if automaton.states.len() > max_states
                                        || automaton.transitions.len()
                                            + automaton.state_transitions.len()
                                            > max_transitions
                                    {
                                        return None;
                                    }
                                }
                            }
                        }
                        SrsMatchAtBound::Merge => {
                            let suffix_paths = automaton
                                .reaches_for_word_from_tail(suffix, tail, bound, deadline)?;
                            for suffix_path in suffix_paths {
                                let prefix_paths = automaton.reaches_for_word_from_tail(
                                    prefix,
                                    &suffix_path.head,
                                    bound,
                                    deadline,
                                )?;
                                for prefix_path in prefix_paths {
                                    let redex_height = min_optional_height(
                                        suffix_path.min_height,
                                        prefix_path.min_height,
                                    )
                                    .unwrap_or(0);
                                    let rhs_height = if rule.rhs().is_empty() {
                                        redex_height + 1
                                    } else {
                                        (redex_height + 1).min(bound)
                                    };
                                    let rhs_head = if !rule.rhs().is_empty() && rhs_height == bound
                                    {
                                        automaton.final_state.clone()
                                    } else {
                                        prefix_path.head.clone()
                                    };
                                    if !rule.rhs().is_empty() && rhs_height == bound {
                                        rule_changed |= automaton.add_merged_rhs_path_to_final(
                                            rule.rhs(),
                                            rhs_height,
                                            tail,
                                        )?;
                                    } else {
                                        rule_changed |= automaton.add_rhs_path(
                                            rule.rhs(),
                                            rhs_height,
                                            tail,
                                            &rhs_head,
                                        )?;
                                    }
                                    if rhs_head != prefix_path.head {
                                        rule_changed |= automaton.insert_state_compatibility(
                                            &prefix_path.head,
                                            &rhs_head,
                                        );
                                    }
                                    if automaton.states.len() > max_states
                                        || automaton.transitions.len()
                                            + automaton.state_transitions.len()
                                            > max_transitions
                                    {
                                        return None;
                                    }
                                }
                            }
                        }
                    }
                }
            }
            if rule_changed {
                changed = true;
                queue.extend(rules.iter().cloned());
            }
        }
        if !changed {
            break;
        }
    }
    let closed = match at_bound {
        SrsMatchAtBound::Exact => automaton.is_rfc_automaton_closed(rules),
        SrsMatchAtBound::Merge => {
            automaton.ensure_rfc_matchbox_closure(rules, deadline)?;
            automaton.is_rfc_matchbox_closed(rules)
        }
    };
    if !automaton.accepts_initial_words_from_all_states(initial_words)
        || !closed
        || !automaton.has_rfc_lhs_suffix_totality(rules)
    {
        return None;
    }
    automaton.into_completion()
}

pub(crate) fn complete_srs_match_bounds_completion_from_builder(
    mut automaton: SrsMatchAutomatonBuilder,
    rules: Vec<(crate::core::SrsRule, bool)>,
    bound: usize,
    max_states: usize,
    max_transitions: usize,
    at_bound: SrsMatchAtBound,
    deadline: Option<Instant>,
) -> Option<SrsMatchCompletion> {
    let started = Instant::now();
    // An empty word on the left is a variable lhs in the unary TRS.
    // It has no redex height; skipping that obligation would vacuously
    // accept even epsilon -> epsilon. CeTA's bounds theorem excludes it.
    if rules.iter().any(|(rule, _)| rule.lhs().is_empty()) {
        return None;
    }
    let strict_rules = rules
        .iter()
        .filter_map(|(rule, strict)| strict.then_some(rule.clone()))
        .collect::<Vec<_>>();
    let weak_rules = rules
        .iter()
        .filter_map(|(rule, strict)| (!strict).then_some(rule.clone()))
        .collect::<Vec<_>>();
    let cap_weak_heights = strict_rules.iter().all(|rule| !rule.rhs().is_empty());
    let mut queue = VecDeque::from_iter(rules.iter().cloned());
    let mut iterations = 0usize;
    while let Some((rule, strict)) = queue.pop_front() {
        if current_thread_cancelled() || deadline.is_some_and(|limit| Instant::now() >= limit) {
            return None;
        }
        iterations += 1;
        if iterations > DEFAULT_SRS_MATCH_BOUNDS_MAX_ITERATIONS {
            return None;
        }
        let mut changed = false;
        let paths = if strict {
            automaton.strict_paths_for_word(rule.lhs(), deadline)?
        } else {
            automaton.weak_paths_for_word(rule.lhs(), deadline)?
        };
        write_progress_event(
            "match-bounds",
            "completion-batch",
            "paths",
            started.elapsed().as_millis(),
            &format!(
                "iteration={iterations} bound={bound} paths={} states={} transitions={}",
                paths.len(),
                automaton.states.len(),
                automaton.transitions.len() + automaton.state_transitions.len()
            ),
        );
        for path in paths {
            // One rule can expose a very large batch. Checking only between
            // rules lets completion overrun its deadline while consuming it.
            if current_thread_cancelled() || deadline.is_some_and(|limit| Instant::now() >= limit) {
                return None;
            }
            let Some(redex_height) = path.heights.iter().min().copied() else {
                continue;
            };
            let rhs_height = if strict {
                redex_height + 1
            } else {
                match_bounds_weak_rhs_height(&rule, &path, bound, cap_weak_heights)?
            };
            let rhs_is_already_compatible = !rule.rhs().is_empty()
                && automaton.word_reaches_at_height(rule.rhs(), rhs_height, &path.tail, &path.head);
            if rhs_is_already_compatible {
                continue;
            }
            if !rule.rhs().is_empty() && rhs_height > bound {
                match at_bound {
                    SrsMatchAtBound::Exact => {
                        write_progress_event(
                            "match-bounds",
                            "rejected",
                            "height-bound",
                            0,
                            &format!(
                                "bound={bound} redex_height={redex_height} rhs_height={rhs_height} lhs_len={} rhs_len={} states={} transitions={}",
                                rule.lhs().len(),
                                rule.rhs().len(),
                                automaton.states.len(),
                                automaton.transitions.len() + automaton.state_transitions.len()
                            ),
                        );
                        return None;
                    }
                    SrsMatchAtBound::Merge => return None,
                }
            }
            changed |= automaton.add_rhs_path(rule.rhs(), rhs_height, &path.tail, &path.head)?;
            if automaton.states.len() > max_states
                || automaton.transitions.len() + automaton.state_transitions.len() > max_transitions
            {
                return None;
            }
        }
        if changed {
            queue.extend(rules.iter().cloned());
        }
    }
    // Completion constructs candidate transitions incrementally.  Recheck the
    // complete automaton using the same all-path obligations that CPF/CeTA
    // imposes: in particular, every state reached by a strict left-hand side
    // must have a compatible right-hand-side run.  This final pass prevents a
    // locally completed path from masking a different run exposed later in the
    // fixed point.
    if !automaton.is_match_bounds_strict_compatible(&strict_rules, bound, deadline)?
        || !automaton.is_ceta_relative_match_bounds_weak_compatible(
            &weak_rules,
            bound,
            cap_weak_heights,
            deadline,
        )?
    {
        return None;
    }
    automaton.into_completion()
}

pub(crate) fn match_bounds_weak_rhs_height(
    rule: &crate::core::SrsRule,
    path: &SrsMatchPath,
    bound: usize,
    cap_at_bound: bool,
) -> Option<usize> {
    let minimum = path.heights.iter().min().copied()?;
    let uniformly_lifted = path.heights.iter().all(|height| *height == minimum);
    let non_growing = rule.lhs().len() >= rule.rhs().len();
    let height = if uniformly_lifted && non_growing {
        minimum
    } else {
        minimum + 1
    };
    Some(if cap_at_bound {
        height.min(bound)
    } else {
        height
    })
}

#[allow(dead_code)]
pub(crate) fn srs_rfc_initial_words(
    rewrite_rules: &[RewriteRule],
    tail: &Variable,
    rules: &[crate::core::SrsRule],
    max_words: usize,
    max_word_len: usize,
) -> Option<Vec<Vec<crate::core::Symbol>>> {
    let mut words = BTreeSet::new();
    let mut queue = VecDeque::new();
    for rule in rules {
        if rule.rhs().len() > max_word_len {
            return None;
        }
        if words.insert(rule.rhs().to_vec()) {
            queue.push_back(rule.rhs().to_vec());
        }
    }
    while let Some(word) = queue.pop_front() {
        if current_thread_cancelled() {
            return None;
        }
        let term = srs_word_to_term(&word, Term::Var(tail.clone()));
        for next_term in rfc_narrow_successors_for_template(&term, rewrite_rules) {
            let (next, next_tail) = strict_srs_word_with_tail(&next_term)?;
            if &next_tail != tail {
                return None;
            }
            if next.len() > max_word_len {
                return None;
            }
            if words.insert(next.clone()) {
                if words.len() > max_words {
                    return None;
                }
                queue.push_back(next);
            }
        }
    }
    Some(words.into_iter().collect())
}

#[allow(dead_code)]
pub(crate) fn rfc_narrow_successors_for_template(term: &Term, rules: &[RewriteRule]) -> Vec<Term> {
    let mut successors = BTreeSet::new();
    let source = rename_variables(term, "__rfc_t_");
    for (position, subterm) in positions_with_subterms(&source) {
        if matches!(subterm, Term::Var(_)) {
            continue;
        }
        for rule in rules {
            let rule = rename_rule_variables(rule, "__rfc_r_");
            let mut substitution = BTreeMap::new();
            if !unify_terms(subterm, rule.lhs(), &mut substitution) {
                continue;
            }
            let narrowed_source = apply_substitution(&source, &substitution);
            let replacement = apply_substitution(rule.rhs(), &substitution);
            if let Some(next) =
                replace_subterm_at_position(&narrowed_source, &position, &replacement)
            {
                successors.insert(unrename_variables(&next, "__rfc_t_"));
            }
        }
    }
    successors.into_iter().collect()
}

#[allow(dead_code)]
pub(crate) fn unrename_variables(term: &Term, prefix: &str) -> Term {
    match term {
        Term::Var(variable) => {
            let name = variable.as_str();
            Term::var(name.strip_prefix(prefix).unwrap_or(name))
        }
        Term::App { symbol, args } => Term::app(
            symbol.as_str(),
            args.iter()
                .map(|arg| unrename_variables(arg, prefix))
                .collect(),
        ),
    }
}
