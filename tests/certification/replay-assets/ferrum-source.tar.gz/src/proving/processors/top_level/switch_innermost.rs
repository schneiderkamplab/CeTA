use crate::core::{RewriteStrategy, Trs};
use crate::proving::processors::rewrite_analysis::switch_innermost_wcr_depth;
use crate::proving::{Proof, ProofStep, Status};

use super::super::{
    ProblemCertificate, ProblemState, ProcessorApplication, ProcessorResult, WorklistProcessor,
};

pub struct SwitchInnermostProcessor;

impl WorklistProcessor for SwitchInnermostProcessor {
    fn name(&self) -> &'static str {
        "switch-innermost"
    }

    fn apply(&self, state: &ProblemState) -> ProcessorResult {
        let trs = match state {
            ProblemState::Trs(trs) | ProblemState::Srs(trs)
                if trs.strategy() == RewriteStrategy::Full =>
            {
                trs
            }
            _ => return ProcessorResult::Inapplicable,
        };
        let Some(wcr_depth) = switch_innermost_wcr_depth(trs) else {
            return ProcessorResult::Inapplicable;
        };
        let residual = Trs::new_with_strategy(
            trs.name().map(str::to_string),
            trs.variables().clone(),
            trs.rules().to_vec(),
            RewriteStrategy::Innermost,
        );
        let residual = ProblemState::from_trs(residual);
        ProcessorResult::Applied(ProcessorApplication::new(vec![residual], move |children| {
            let [ProblemCertificate::Trs(proof)] =
                <[ProblemCertificate; 1]>::try_from(children).ok()?
            else {
                return None;
            };
            if proof.status() == &Status::Nonterminating {
                // Every innermost rewrite step is also a full rewrite step.
                // Hence a concrete nontermination witness from the child is
                // already a proof for the parent and needs no switch wrapper.
                return Some(ProblemCertificate::Trs(proof));
            }
            if proof.status() != &Status::Terminating {
                return None;
            }
            Some(ProblemCertificate::Trs(Proof::terminating(vec![
                ProofStep::SwitchInnermost {
                    wcr_depth,
                    proof: Box::new(proof),
                },
            ])))
        }))
    }
}
