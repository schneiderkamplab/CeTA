use std::collections::BTreeMap;
use std::time::Instant;
use crate::core::{RewriteStrategy, Term, Trs};
use crate::proving::{Proof, ProofStep, Status};
use crate::proving::dependency_pairs::SemanticLabelingModel;
use super::super::{ProblemCertificate, ProblemState, ProcessorApplication, ProcessorResult, WorklistProcessor};

/// Root symbols form a finite algebra for any root-preserving TRS. Repeated
/// variables share their assigned root; no benchmark names or witnesses enter
/// this construction. Root-changing rules do not satisfy this model.
pub struct TrsRootLabelingProcessor { pub deadline: Option<Instant> }

impl WorklistProcessor for TrsRootLabelingProcessor {
    fn name(&self) -> &'static str { "trs-root-labeling" }
    fn apply(&self, state: &ProblemState) -> ProcessorResult {
        let trs = match state {
            ProblemState::Trs(trs) | ProblemState::Srs(trs) => trs,
            _ => return ProcessorResult::Inapplicable,
        };
        if trs.strategy() != RewriteStrategy::Full || trs.rules().is_empty()
            || trs.arities().keys().any(|s| s.as_str().starts_with("__ferrum_rl__") || s.as_str().starts_with("__ferrum_sl__"))
            || trs.rules().iter().any(|r| !matches!((r.lhs(), r.rhs()),
                (Term::App {symbol: f, ..}, Term::App {symbol: g, ..}) if f == g))
        { return ProcessorResult::Inapplicable; }
        let arities = trs.arities();
        let roots = arities.keys().cloned().collect::<Vec<_>>();
        let Some(labeled_rules) = crate::proving::processors::dp::root_label_rules(trs.rules(), &roots, self.deadline) else {
            return ProcessorResult::TimedOut;
        };
        let model = SemanticLabelingModel { carrier_size: roots.len(), arities, interpretations: BTreeMap::new() };
        let child = Trs::new_with_strategy(trs.name().map(str::to_owned), trs.variables().clone(), labeled_rules.clone(), trs.strategy());
        ProcessorResult::Applied(ProcessorApplication::new(vec![ProblemState::Trs(child)], move |children| {
            let [ProblemCertificate::Trs(proof)] = <[ProblemCertificate; 1]>::try_from(children).ok()? else { return None };
            if proof.status() != &Status::Terminating { return None; }
            Some(ProblemCertificate::Trs(Proof::terminating(vec![ProofStep::SemanticLabeling {
                root_labeling: true, model: model.clone(), labeled_rules: labeled_rules.clone(), proof: Box::new(proof),
            }])))
        }))
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::core::RewriteRule;
    #[test]
    fn trs_root_labeling_checks_root_model_and_parses_atom() {
        for symbol in ["f", "renamed"] {
            let trs = Trs::new(None, Default::default(), vec![RewriteRule::new(
                Term::app(symbol, vec![Term::app("s", vec![Term::var("x")])]),
                Term::app(symbol, vec![Term::var("x")]))]);
            let ProcessorResult::Applied(application) = TrsRootLabelingProcessor { deadline: None }
                .apply(&ProblemState::Trs(trs)) else { panic!() };
            assert_eq!(application.residuals.len(), 1);
        }
        let invalid = Trs::new(None, Default::default(), vec![RewriteRule::new(
            Term::app("f", vec![Term::var("x")]), Term::app("g", vec![Term::var("x")]))]);
        assert!(matches!(TrsRootLabelingProcessor { deadline: None }.apply(&ProblemState::Trs(invalid)), ProcessorResult::Inapplicable));
        assert!(matches!(crate::proving::ProveStrategy::parse("trs-root-labeling").unwrap(),
            crate::proving::ProveStrategy::Processor(crate::proving::ProveStrategyProcessor::TrsRootLabeling)));
    }
}
