use crate::proving::{Proof, ProofStep, UncurryProof};

use super::uncurrying::synthesize_uncurrying_with_role;

use super::super::{
    ProblemCertificate, ProblemState, ProcessorApplication, ProcessorResult, WorklistProcessor,
};

pub struct UncurryProcessor;

pub struct UncurryRoleProcessor {
    pub role: usize,
}

impl WorklistProcessor for UncurryProcessor {
    fn name(&self) -> &'static str {
        "uncurry"
    }

    fn apply(&self, state: &ProblemState) -> ProcessorResult {
        UncurryRoleProcessor { role: 0 }.apply(state)
    }
}

impl WorklistProcessor for UncurryRoleProcessor {
    fn name(&self) -> &'static str { "uncurry" }

    fn apply(&self, state: &ProblemState) -> ProcessorResult {
        let trs = match state {
            ProblemState::Trs(trs) | ProblemState::Srs(trs) => trs,
            _ => return ProcessorResult::Inapplicable,
        };
        let Some(transform) = synthesize_uncurrying_with_role(trs, self.role) else {
            return ProcessorResult::Inapplicable;
        };
        let residual = ProblemState::from_trs(transform.transformed.clone());
        ProcessorResult::Applied(ProcessorApplication::new(vec![residual], move |children| {
            let [ProblemCertificate::Trs(proof)] =
                <[ProblemCertificate; 1]>::try_from(children).ok()?
            else {
                return None;
            };
            let status = proof.status().clone();
            Some(ProblemCertificate::Trs(Proof::with_status(
                status,
                vec![ProofStep::Uncurry {
                    proof: UncurryProof {
                        app_symbol: transform.app_symbol.clone(),
                        symbols: transform.symbols.clone(),
                        uncurry_rules: transform.uncurry_rules.clone(),
                        eta_rules: transform.eta_rules.clone(),
                        transformed_rules: transform.transformed.rules().to_vec(),
                        proof: Box::new(proof),
                    },
                }],
            )))
        }))
    }
}
