use std::collections::BTreeMap;
use std::process::Command;
use std::time::Instant;

use crate::proving::runtime::{
    current_thread_cancelled, run_command_with_input_deadline, write_progress_event,
};
use crate::proving::smt_session::run_persistent_smt_script;

const MAX_SCRIPT_BYTES: usize = 128 * 1024 * 1024;

pub(crate) fn solver_args(solver: &str) -> &'static [&'static str] {
    let name = std::path::Path::new(solver)
        .file_name()
        .and_then(|name| name.to_str())
        .unwrap_or(solver);
    if name.contains("cvc5") {
        &["-q", "--lang", "smt2", "--produce-models", "--incremental"]
    } else {
        &["-in"]
    }
}

pub(crate) fn parse_integer_values(output: &str) -> Option<BTreeMap<String, i64>> {
    let normalized = output
        .replace('(', " ( ")
        .replace(')', " ) ")
        .replace('\n', " ");
    let tokens = normalized.split_whitespace().collect::<Vec<_>>();
    let mut values = BTreeMap::new();
    let mut index = 0usize;
    while index + 4 < tokens.len() {
        if tokens[index] == "(" && tokens[index + 1] == "define-fun" {
            let name = tokens[index + 2].to_string();
            if tokens.get(index + 5).copied() != Some("Int") {
                index += 1;
                continue;
            }
            let value_start = index + 6;
            let (value, consumed) = parse_integer(&tokens[value_start..])?;
            values.insert(name, value);
            index = value_start + consumed;
        } else {
            index += 1;
        }
    }
    Some(values)
}

fn parse_integer(tokens: &[&str]) -> Option<(i64, usize)> {
    match tokens {
        [value, ..] => value.parse().ok().map(|value| (value, 1)),
        _ => None,
    }
    .or_else(|| match tokens {
        ["(", "-", value, ")", ..] => value.parse::<i64>().ok().map(|value| (-value, 4)),
        _ => None,
    })
}

pub(crate) fn command_exists(command: &str) -> bool {
    Command::new("sh")
        .arg("-c")
        .arg(format!("command -v {command} >/dev/null 2>&1"))
        .status()
        .map(|status| status.success())
        .unwrap_or(false)
}

pub(crate) fn sanitize_identifier(input: &str) -> String {
    input
        .chars()
        .map(|ch| {
            if ch.is_ascii_alphanumeric() || ch == '_' {
                ch
            } else {
                '_'
            }
        })
        .collect()
}

pub(crate) fn sum(parts: Vec<String>) -> String {
    let non_zero = parts
        .into_iter()
        .filter(|part| part != "0")
        .collect::<Vec<_>>();
    match non_zero.as_slice() {
        [] => "0".to_string(),
        [part] => part.clone(),
        _ => format!("(+ {})", non_zero.join(" ")),
    }
}

pub(crate) fn and(terms: Vec<String>) -> String {
    match terms.as_slice() {
        [] => "true".to_string(),
        [term] => term.clone(),
        _ => format!("(and {})", terms.join(" ")),
    }
}

pub(crate) fn or(terms: Vec<String>) -> String {
    match terms.as_slice() {
        [] => "false".to_string(),
        [term] => term.clone(),
        _ => format!("(or {})", terms.join(" ")),
    }
}

pub(crate) fn boolean(value: bool) -> String {
    if value { "true" } else { "false" }.to_string()
}

pub(crate) fn run_script(script: &str, solver: &str, deadline: Option<Instant>) -> Option<String> {
    check_script_size(script)?;
    let solver_name = std::path::Path::new(solver)
        .file_name()
        .and_then(|name| name.to_str())
        .unwrap_or(solver);
    let persistent_logic =
        script.starts_with("(set-logic QF_BV)") || script.starts_with("(set-logic QF_LIA)");
    if std::env::var_os("FERRUM_EXPERIMENTAL_PERSISTENT_TOP_SMT").is_some()
        && std::env::var_os("FERRUM_DISABLE_PERSISTENT_SMT").is_none()
        && solver_name == "z3"
        && persistent_logic
    {
        match run_persistent_smt_script(solver, solver_args(solver), script, deadline) {
            Ok(Some(output)) => {
                write_progress_event(
                    "top-level-smt",
                    "solver-exit",
                    "persistent",
                    0,
                    &format!(
                        "solver={solver} reused={} stdout={}",
                        output.reused_session,
                        output
                            .stdout
                            .chars()
                            .take(160)
                            .collect::<String>()
                            .replace('\n', " ")
                    ),
                );
                return Some(output.stdout);
            }
            Ok(None) => return None,
            Err(error) => write_progress_event(
                "top-level-smt",
                "persistent-fallback",
                "solver",
                0,
                &format!("solver={solver} error={error}"),
            ),
        }
    }
    let mut command = Command::new(solver);
    command.args(solver_args(solver));
    let output = run_command_with_input_deadline(&mut command, script, deadline).ok()??;
    output
        .status
        .success()
        .then(|| String::from_utf8_lossy(&output.stdout).into_owned())
}

pub(crate) fn check_build(script: &str, deadline: Option<Instant>) -> Option<()> {
    if current_thread_cancelled() || deadline.is_some_and(|limit| Instant::now() >= limit) {
        return None;
    }
    check_script_size(script)
}

fn check_script_size(script: &str) -> Option<()> {
    if script.len() <= MAX_SCRIPT_BYTES {
        return Some(());
    }
    write_progress_event(
        "top-level-smt",
        "decline",
        "script-size",
        0,
        &format!(
            "script_bytes={} max_script_bytes={MAX_SCRIPT_BYTES}",
            script.len()
        ),
    );
    None
}
