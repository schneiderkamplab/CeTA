use std::time::Instant;

use crate::proving::Proof;
use crate::proving::nontermination::{
    NonterminationStrategyProcessor, search_nontermination_witness,
};

use super::super::{
    ProblemCertificate, ProblemState, ProcessorApplication, ProcessorResult, WorklistProcessor,
};

/// A terminal nontermination search. It either produces one checked witness
/// or is inapplicable; it never owns a continuation or residual scheduler.
pub struct NonterminationProcessor {
    pub processor: NonterminationStrategyProcessor,
    pub deadline: Option<Instant>,
}

impl WorklistProcessor for NonterminationProcessor {
    fn name(&self) -> &'static str {
        "nontermination"
    }

    fn apply(&self, state: &ProblemState) -> ProcessorResult {
        let trs = match state {
            ProblemState::Trs(trs) | ProblemState::Srs(trs) => trs,
            _ => return ProcessorResult::Inapplicable,
        };
        match search_nontermination_witness(trs, &self.processor, self.deadline) {
            Some(proof) => ProcessorResult::Applied(ProcessorApplication::solved(
                ProblemCertificate::Trs(Proof::nonterminating(proof)),
            )),
            None => {
                if self.deadline.is_some_and(|limit| Instant::now() >= limit) {
                    ProcessorResult::TimedOut
                } else {
                    ProcessorResult::Inapplicable
                }
            }
        }
    }
}
