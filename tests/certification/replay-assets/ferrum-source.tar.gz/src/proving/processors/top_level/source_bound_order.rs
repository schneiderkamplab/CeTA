//! Relocate one order and its deletion mask through a checked TRS isomorphism.
//! The ordinary order processor still rechecks all live orientation obligations.
use crate::core::Symbol;
use crate::parsing::{CpfInputProblem, parse_cpf_input};
use crate::proving::engine::{ProveOptions, ProveStrategy, ProveStrategyProcessor};
use crate::proving::processors::{ProblemState, ProcessorResult, WorklistProcessor};
use std::time::Instant;

fn relocate(state: &ProblemState, source_xml: &str, atom: &str) -> Option<ProveStrategyProcessor> {
    let parsed = parse_cpf_input(None, source_xml).ok()?;
    let (source, live) = match (&parsed, state) {
        (CpfInputProblem::Trs(source), ProblemState::Trs(live) | ProblemState::Srs(live)) => {
            (source, live)
        }
        (CpfInputProblem::Csr { csr: source, .. }, ProblemState::Csr(live)) => {
            (source.trs(), live.csr.trs())
        }
        _ => return None,
    };
    let (symbols, indices) =
        crate::proving::processors::dp::portable_trs_isomorphism(source, live)?;
    if let (CpfInputProblem::Csr { csr: source, .. }, ProblemState::Csr(live)) = (&parsed, state) {
        // Rule isomorphism alone is not enough: frozen arguments are part of
        // the mathematical input, even for an independently rechecked order.
        for (symbol, arity) in source.trs().arities() {
            let mapped = symbols.get(&symbol)?;
            for position in 0..arity {
                if source.replacement_map().is_allowed(&symbol, position)
                    != live.csr.replacement_map().is_allowed(mapped, position)
                {
                    return None;
                }
            }
        }
    }
    // Never transport an unused sibling interpretation into a live symbol.
    let rename = |name: &String| {
        symbols
            .get(&Symbol::new(name.clone()))
            .map(|s| s.as_str().to_owned())
    };
    // Whitelist before parsing, including for manually constructed enum values.
    if ![
        "exact-poly-removal(",
        "exact-kbo(",
        "exact-poly(",
        "exact-matrix(",
    ]
    .iter()
    .any(|prefix| atom.starts_with(prefix))
    {
        return None;
    }
    match ProveStrategy::parse(atom).ok()? {
        ProveStrategy::Processor(ProveStrategyProcessor::ExactLinearPolynomial {
            interpretation,
        }) => Some(ProveStrategyProcessor::ExactLinearPolynomial {
            interpretation: interpretation
                .into_iter()
                .filter_map(|(name, c, coefficients)| {
                    rename(&name).map(|name| (name, c, coefficients))
                })
                .collect(),
        }),
        ProveStrategy::Processor(ProveStrategyProcessor::ExactMatrixInterpretation {
            interpretation,
        }) => Some(ProveStrategyProcessor::ExactMatrixInterpretation {
            interpretation: interpretation
                .into_iter()
                .filter_map(|(name, c, coefficients)| {
                    rename(&name).map(|name| (name, c, coefficients))
                })
                .collect(),
        }),
        ProveStrategy::Processor(ProveStrategyProcessor::ExactLinearPolynomialRemoval {
            interpretation,
            removed_rule_indices,
        }) => {
            let mut mapped = removed_rule_indices
                .iter()
                .map(|i| indices.get(i).copied())
                .collect::<Option<Vec<_>>>()?;
            mapped.sort_unstable();
            Some(ProveStrategyProcessor::ExactLinearPolynomialRemoval {
                interpretation: interpretation
                    .into_iter()
                    .filter_map(|(name, c, coefficients)| {
                        rename(&name).map(|name| (name, c, coefficients))
                    })
                    .collect(),
                removed_rule_indices: mapped,
            })
        }
        ProveStrategy::Processor(ProveStrategyProcessor::ExactKbo {
            precedence,
            precedence_ranks,
            weights,
        }) => Some(ProveStrategyProcessor::ExactKbo {
            precedence: precedence.iter().filter_map(rename).collect(),
            precedence_ranks: precedence_ranks
                .iter()
                .filter_map(|(s, v)| rename(s).map(|s| (s, *v)))
                .collect(),
            weights: weights
                .iter()
                .filter_map(|(s, v)| rename(s).map(|s| (s, *v)))
                .collect(),
        }),
        _ => None,
    }
}

pub(super) fn apply(
    state: &ProblemState,
    source: &str,
    atom: &str,
    options: &ProveOptions,
    deadline: Option<Instant>,
) -> ProcessorResult {
    let Some(processor) = relocate(state, source, atom) else {
        return ProcessorResult::Inapplicable;
    };
    super::dispatch::ConfiguredTopLevelProcessor {
        processor: &processor,
        options,
        deadline,
    }
    .apply(state)
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::core::{RewriteRule, Term, Trs};
    use std::collections::BTreeSet;

    #[test]
    fn source_bound_csr_order_checks_the_replacement_map() {
        use crate::core::{CsrTrs, ReplacementMap};
        use crate::proving::processors::CsrProblemState;
        let make = |name: &str, active: bool| {
            let trs = Trs::new(
                None,
                BTreeSet::new(),
                vec![RewriteRule::new(
                    Term::app(name, vec![Term::var("x")]),
                    Term::var("x"),
                )],
            );
            let mu = if active {
                ReplacementMap::full_for_arities(&trs.arities())
            } else {
                ReplacementMap::empty_for_arities(&trs.arities())
            };
            CsrTrs::new(trs, mu).unwrap()
        };
        let source = make("f", true);
        let live = ProblemState::Csr(CsrProblemState::root(make("g", true)));
        let changed = ProblemState::Csr(CsrProblemState::root(make("g", false)));
        let atom = ProveStrategyProcessor::ExactLinearPolynomial {
            interpretation: vec![("f".into(), 1, vec![1])],
        }
        .to_strategy_atom();
        let xml = crate::cert::write_csr_input_cpf4(&source);
        assert!(matches!(
            relocate(&live, &xml, &atom),
            Some(ProveStrategyProcessor::ExactLinearPolynomial { .. })
        ));
        assert!(relocate(&changed, &xml, &atom).is_none());
        let bound = ProveStrategyProcessor::ExactSourceBoundOrder {
            source_trs_input_xml: xml,
            order_atom: atom,
        };
        assert!(ProveStrategy::parse(&bound.to_strategy_atom()).is_ok());
    }

    #[test]
    fn bound_order_relocates_symbols_and_rule_indices_but_rejects_state_changes() {
        let rule = |f: &str, g: &str| {
            RewriteRule::new(
                Term::app(f, vec![Term::var("x")]),
                Term::app(g, vec![Term::var("x")]),
            )
        };
        let source = Trs::new(None, BTreeSet::new(), vec![rule("f", "g"), rule("g", "h")]);
        let live = Trs::new(None, BTreeSet::new(), vec![rule("b", "c"), rule("a", "b")]);
        let source_xml = crate::cert::write_trs_input_cpf3(&source);
        let inner = ProveStrategyProcessor::ExactLinearPolynomialRemoval {
            interpretation: vec![
                ("f".into(), 2, vec![1]),
                ("g".into(), 1, vec![1]),
                ("h".into(), 0, vec![1]),
            ],
            removed_rule_indices: vec![0],
        }
        .to_strategy_atom();
        let state = ProblemState::Trs(live);
        let Some(ProveStrategyProcessor::ExactLinearPolynomialRemoval {
            interpretation,
            removed_rule_indices,
        }) = relocate(&state, &source_xml, &inner)
        else {
            panic!("missing relocation")
        };
        assert_eq!(removed_rule_indices, vec![1]);
        assert!(interpretation.contains(&("a".into(), 2, vec![1])));
        let wrong = ProblemState::Trs(Trs::new(None, BTreeSet::new(), vec![rule("a", "b")]));
        assert!(relocate(&wrong, &source_xml, &inner).is_none());
        assert!(relocate(&state, &source_xml, "exact-dp-proof(hex=00)").is_none());
        let bound = ProveStrategyProcessor::ExactSourceBoundOrder {
            source_trs_input_xml: source_xml,
            order_atom: inner,
        };
        assert!(matches!(
            ProveStrategy::parse(&bound.to_strategy_atom()).unwrap(),
            ProveStrategy::Processor(ProveStrategyProcessor::ExactSourceBoundOrder { .. })
        ));
    }
}
