use std::collections::BTreeMap;
use std::time::Instant;

use crate::core::{RewriteRule, Trs};
use crate::core::{Term, Variable};
use crate::proving::engine::ProveStrategyProcessor;
use crate::proving::processors::top_level::smt::{
    and as top_smt_and, boolean as top_smt_bool, check_build, command_exists, or as top_smt_or,
    parse_integer_values, run_script, sanitize_identifier, sum,
};
use crate::proving::runtime::{current_thread_cancelled, write_progress_event};
use crate::proving::{Proof, ProofStep, Status};

use super::super::{
    ProblemCertificate, ProblemState, ProcessorApplication, ProcessorResult, WorklistProcessor,
};

#[cfg(test)]
pub(crate) fn synthesize_top_level_kbo(
    trs: &Trs,
    max_weight: i64,
    max_symbols: usize,
    deadline: Option<Instant>,
) -> Option<(Vec<String>, BTreeMap<String, usize>, BTreeMap<String, i64>)> {
    synthesize_top_level_kbo_weak_reduction_pair(trs, max_weight, max_symbols, true, deadline)
}

pub(crate) fn synthesize_top_level_kbo_removal(
    trs: &Trs,
    max_weight: i64,
    max_symbols: usize,
    deadline: Option<Instant>,
) -> Option<TopLevelKboRemoval> {
    let (precedence, precedence_ranks, weights) = synthesize_top_level_kbo_weak_reduction_pair(
        trs,
        max_weight,
        max_symbols,
        false,
        deadline,
    )?;
    let precedence_rank_refs = top_precedence_rank_refs(&precedence_ranks);
    let mut removed = Vec::new();
    let mut remaining = Vec::new();
    for rule in trs.rules() {
        if top_level_kbo_gt(rule.lhs(), rule.rhs(), &weights, &precedence_rank_refs) {
            removed.push(rule.clone());
        } else {
            remaining.push(rule.clone());
        }
    }
    if removed.is_empty() || remaining.len() == trs.rules().len() {
        return None;
    }
    Some(TopLevelKboRemoval {
        precedence,
        precedence_ranks,
        weights,
        removed,
        remaining: Trs::new_with_strategy(
            trs.name().map(str::to_string),
            trs.variables().clone(),
            remaining,
            trs.strategy(),
        ),
    })
}

fn synthesize_top_level_kbo_weak_reduction_pair(
    trs: &Trs,
    max_weight: i64,
    max_symbols: usize,
    require_all_strict: bool,
    deadline: Option<Instant>,
) -> Option<(Vec<String>, BTreeMap<String, usize>, BTreeMap<String, i64>)> {
    if current_thread_cancelled() || deadline.is_some_and(|limit| Instant::now() >= limit) {
        return None;
    }
    if max_weight < 1 {
        return None;
    }
    let arities = trs
        .arities()
        .into_iter()
        .map(|(symbol, arity)| (symbol.as_str().to_string(), arity))
        .collect::<BTreeMap<_, _>>();
    let symbols = arities.keys().cloned().collect::<Vec<_>>();
    if symbols.is_empty() || symbols.len() > max_symbols {
        return None;
    }
    let solver = command_exists("z3")
        .then_some("z3")
        .or_else(|| command_exists("cvc5").then_some("cvc5"))?;
    let script = top_level_kbo_smt_script(
        trs,
        &symbols,
        &arities,
        max_weight,
        require_all_strict,
        deadline,
    )?;
    let stdout = run_script(&script, solver, deadline)?;
    if !stdout.contains("sat") || stdout.contains("unsat") {
        write_progress_event(
            "top-level-rule-removal",
            "rejected",
            if require_all_strict {
                "kbo"
            } else {
                "kbo-removal"
            },
            0,
            "smt_calls=1 reason=unsat-or-timeout",
        );
        return None;
    }
    let (precedence, precedence_ranks, weights) = top_level_parse_kbo_smt_model(&stdout, &symbols)?;
    let precedence_rank_refs = top_precedence_rank_refs(&precedence_ranks);
    if !top_level_kbo_weights_are_admissible(&arities, &weights, &precedence_ranks) {
        return None;
    }
    let mut has_strict = false;
    let all_weak = trs.rules().iter().all(|rule| {
        if top_level_kbo_gt(rule.lhs(), rule.rhs(), &weights, &precedence_rank_refs) {
            has_strict = true;
            true
        } else {
            rule.lhs() == rule.rhs()
        }
    });
    let all_strict = has_strict
        && trs
            .rules()
            .iter()
            .all(|rule| top_level_kbo_gt(rule.lhs(), rule.rhs(), &weights, &precedence_rank_refs));
    let accepted = all_weak && has_strict && (!require_all_strict || all_strict);
    write_progress_event(
        "top-level-rule-removal",
        if accepted { "selected" } else { "rejected" },
        if require_all_strict {
            "kbo"
        } else {
            "kbo-removal"
        },
        0,
        &format!(
            "smt_calls=1 reason={}",
            if accepted {
                "checked-removal"
            } else {
                "model-failed-check"
            }
        ),
    );
    accepted.then_some((precedence, precedence_ranks, weights))
}

fn top_level_kbo_smt_script(
    trs: &Trs,
    symbols: &[String],
    arities: &BTreeMap<String, usize>,
    max_weight: i64,
    require_all_strict: bool,
    deadline: Option<Instant>,
) -> Option<String> {
    let mut script = String::new();
    script.push_str("(set-logic QF_LIA)\n");
    let max_rank = i64::try_from(symbols.len().checked_sub(1)?).ok()?;
    for symbol in symbols {
        check_build(&script, deadline)?;
        let rank = top_kbo_rank(symbol);
        let weight = top_kbo_weight_var(symbol);
        script.push_str(&format!("(declare-const {rank} Int)\n"));
        script.push_str(&format!(
            "(assert (and (>= {rank} 0) (<= {rank} {max_rank})))\n"
        ));
        script.push_str(&format!("(declare-const {weight} Int)\n"));
        script.push_str(&format!(
            "(assert (and (>= {weight} 0) (<= {weight} {max_weight})))\n"
        ));
    }
    for (symbol, arity) in arities {
        check_build(&script, deadline)?;
        let rank = top_kbo_rank(symbol);
        let weight = top_kbo_weight_var(symbol);
        if *arity == 1 {
            script.push_str(&format!(
                "(assert (or (> {weight} 0) (and (= {weight} 0) (= {rank} 0))))\n"
            ));
        } else if *arity == 0 {
            script.push_str(&format!("(assert (> {weight} 0))\n"));
        }
    }
    let mut strict_terms = Vec::new();
    for rule in trs.rules() {
        check_build(&script, deadline)?;
        let strict = top_level_kbo_gt_smt(rule.lhs(), rule.rhs());
        strict_terms.push(strict.clone());
        let weak = top_smt_or(vec![top_smt_bool(rule.lhs() == rule.rhs()), strict]);
        script.push_str("(assert ");
        script.push_str(if require_all_strict {
            strict_terms.last()?
        } else {
            &weak
        });
        script.push_str(")\n");
    }
    if strict_terms.is_empty() {
        script.push_str("(assert false)\n");
    } else if !require_all_strict {
        script.push_str("(assert ");
        script.push_str(&top_smt_or(strict_terms));
        script.push_str(")\n");
    }
    script.push_str("(check-sat)\n(get-model)\n");
    check_build(&script, deadline)?;
    Some(script)
}

fn top_level_parse_kbo_smt_model(
    output: &str,
    symbols: &[String],
) -> Option<(Vec<String>, BTreeMap<String, usize>, BTreeMap<String, i64>)> {
    let values = parse_integer_values(output)?;
    let mut ranked = Vec::new();
    let mut precedence_ranks = BTreeMap::new();
    let mut weights = BTreeMap::new();
    for symbol in symbols {
        let rank = usize::try_from(values.get(&top_kbo_rank(symbol)).copied()?).ok()?;
        ranked.push((rank, symbol.clone()));
        precedence_ranks.insert(symbol.clone(), rank);
        weights.insert(
            symbol.clone(),
            values.get(&top_kbo_weight_var(symbol)).copied()?,
        );
    }
    ranked.sort_by(|left, right| left.0.cmp(&right.0).then_with(|| left.1.cmp(&right.1)));
    Some((
        ranked.into_iter().map(|(_, symbol)| symbol).collect(),
        precedence_ranks,
        weights,
    ))
}

fn top_level_kbo_weights_are_admissible(
    arities: &BTreeMap<String, usize>,
    weights: &BTreeMap<String, i64>,
    precedence_ranks: &BTreeMap<String, usize>,
) -> bool {
    arities.iter().all(|(symbol, arity)| {
        let weight = weights.get(symbol).copied().unwrap_or(1);
        (*arity > 1 && weight >= 0)
            || (*arity == 0 && weight > 0)
            || (*arity == 1 && (weight > 0 || precedence_ranks.get(symbol).copied() == Some(0)))
    })
}

pub(crate) fn top_precedence_rank_refs(
    precedence_ranks: &BTreeMap<String, usize>,
) -> BTreeMap<&str, usize> {
    precedence_ranks
        .iter()
        .map(|(symbol, rank)| (symbol.as_str(), *rank))
        .collect()
}

fn top_level_kbo_gt_smt(lhs: &Term, rhs: &Term) -> String {
    if !top_level_kbo_variable_condition_holds(lhs, rhs) {
        return "false".to_string();
    }
    let lhs_weight = top_level_kbo_weight_smt(lhs);
    let rhs_weight = top_level_kbo_weight_smt(rhs);
    top_smt_or(vec![
        format!("(> {lhs_weight} {rhs_weight})"),
        format!(
            "(and (= {lhs_weight} {rhs_weight}) {})",
            top_level_kbo_precedence_gt_smt(lhs, rhs)
        ),
    ])
}

fn top_level_kbo_precedence_gt_smt(lhs: &Term, rhs: &Term) -> String {
    match (lhs, rhs) {
        (Term::Var(_), _) => "false".to_string(),
        (_, Term::Var(_)) => top_smt_bool(contains_term(lhs, rhs)),
        (
            Term::App {
                symbol: lhs_symbol,
                args: lhs_args,
            },
            Term::App {
                symbol: rhs_symbol,
                args: rhs_args,
            },
        ) => {
            let subterm = lhs_args
                .iter()
                .map(|arg| {
                    top_smt_or(vec![
                        top_smt_bool(arg == rhs),
                        top_level_kbo_gt_smt(arg, rhs),
                    ])
                })
                .collect::<Vec<_>>();
            let lex = if lhs_args.len() == rhs_args.len() {
                let mut disjuncts = Vec::new();
                for index in 0..lhs_args.len().min(rhs_args.len()) {
                    let prefix_equal = top_smt_and(
                        (0..index)
                            .map(|prefix| top_smt_bool(lhs_args[prefix] == rhs_args[prefix]))
                            .collect(),
                    );
                    disjuncts.push(top_smt_and(vec![
                        prefix_equal,
                        top_smt_bool(lhs_args[index] != rhs_args[index]),
                        top_level_kbo_gt_smt(&lhs_args[index], &rhs_args[index]),
                    ]));
                }
                top_smt_and(vec![
                    format!(
                        "(= {} {})",
                        top_kbo_rank(lhs_symbol.as_str()),
                        top_kbo_rank(rhs_symbol.as_str())
                    ),
                    top_smt_or(disjuncts),
                ])
            } else {
                "false".to_string()
            };
            let precedence = if lhs_symbol != rhs_symbol {
                top_smt_and(vec![
                    format!(
                        "(< {} {})",
                        top_kbo_rank(lhs_symbol.as_str()),
                        top_kbo_rank(rhs_symbol.as_str())
                    ),
                    top_smt_and(
                        rhs_args
                            .iter()
                            .map(|arg| {
                                top_smt_or(vec![
                                    top_level_kbo_gt_smt(lhs, arg),
                                    top_smt_bool(lhs == arg),
                                ])
                            })
                            .collect(),
                    ),
                ])
            } else {
                "false".to_string()
            };
            top_smt_or(subterm.into_iter().chain([lex, precedence]).collect())
        }
    }
}

fn top_level_kbo_weight_smt(term: &Term) -> String {
    match term {
        Term::Var(_) => "1".to_string(),
        Term::App { symbol, args } => {
            let mut parts = vec![top_kbo_weight_var(symbol.as_str())];
            parts.extend(args.iter().map(top_level_kbo_weight_smt));
            sum(parts)
        }
    }
}

fn top_kbo_rank(symbol: &str) -> String {
    format!("kr_{}", sanitize_identifier(symbol))
}

fn top_kbo_weight_var(symbol: &str) -> String {
    format!("kw_{}", sanitize_identifier(symbol))
}

pub(crate) fn top_level_kbo_gt(
    lhs: &Term,
    rhs: &Term,
    weights: &BTreeMap<String, i64>,
    precedence: &BTreeMap<&str, usize>,
) -> bool {
    if !top_level_kbo_variable_condition_holds(lhs, rhs) {
        return false;
    }
    let lhs_weight = top_level_kbo_weight(lhs, weights);
    let rhs_weight = top_level_kbo_weight(rhs, weights);
    if lhs_weight > rhs_weight {
        return true;
    }
    lhs_weight == rhs_weight && top_level_kbo_precedence_gt(lhs, rhs, weights, precedence)
}

fn top_level_kbo_variable_condition_holds(lhs: &Term, rhs: &Term) -> bool {
    let mut lhs_variables = BTreeMap::new();
    collect_variable_counts(lhs, &mut lhs_variables);
    let mut rhs_variables = BTreeMap::new();
    collect_variable_counts(rhs, &mut rhs_variables);
    rhs_variables
        .into_iter()
        .all(|(variable, count)| lhs_variables.get(&variable).copied().unwrap_or(0) >= count)
}

fn collect_variable_counts(term: &Term, counts: &mut BTreeMap<Variable, usize>) {
    match term {
        Term::Var(variable) => {
            *counts.entry(variable.clone()).or_default() += 1;
        }
        Term::App { args, .. } => {
            for arg in args {
                collect_variable_counts(arg, counts);
            }
        }
    }
}

fn top_level_kbo_weight(term: &Term, weights: &BTreeMap<String, i64>) -> i64 {
    match term {
        Term::Var(_) => 1,
        Term::App { symbol, args } => {
            weights.get(symbol.as_str()).copied().unwrap_or(1)
                + args
                    .iter()
                    .map(|arg| top_level_kbo_weight(arg, weights))
                    .sum::<i64>()
        }
    }
}

fn top_level_kbo_precedence_gt(
    lhs: &Term,
    rhs: &Term,
    weights: &BTreeMap<String, i64>,
    precedence: &BTreeMap<&str, usize>,
) -> bool {
    match (lhs, rhs) {
        (Term::Var(_), _) => false,
        (_, Term::Var(_)) => contains_term(lhs, rhs),
        (
            Term::App {
                symbol: lhs_symbol,
                args: lhs_args,
            },
            Term::App {
                symbol: rhs_symbol,
                args: rhs_args,
            },
        ) => {
            if lhs_args
                .iter()
                .any(|arg| arg == rhs || top_level_kbo_gt(arg, rhs, weights, precedence))
            {
                return true;
            }
            let lhs_rank = precedence
                .get(lhs_symbol.as_str())
                .copied()
                .unwrap_or(usize::MAX);
            let rhs_rank = precedence
                .get(rhs_symbol.as_str())
                .copied()
                .unwrap_or(usize::MAX);
            if lhs_rank == rhs_rank && lhs_args.len() == rhs_args.len() {
                return lhs_args.iter().zip(rhs_args).any(|(left, right)| {
                    left != right
                        && top_level_kbo_gt(left, right, weights, precedence)
                        && lhs_args
                            .iter()
                            .zip(rhs_args)
                            .take_while(|(prefix_left, prefix_right)| {
                                *prefix_left != left || *prefix_right != right
                            })
                            .all(|(prefix_left, prefix_right)| prefix_left == prefix_right)
                });
            }
            lhs_rank < rhs_rank
                && rhs_args
                    .iter()
                    .all(|arg| top_level_kbo_gt(lhs, arg, weights, precedence) || lhs == arg)
        }
    }
}

fn contains_term(term: &Term, needle: &Term) -> bool {
    match term {
        Term::Var(_) => term == needle,
        Term::App { args, .. } => {
            term == needle || args.iter().any(|arg| contains_term(arg, needle))
        }
    }
}

pub(crate) struct TopLevelKboRemoval {
    pub(crate) precedence: Vec<String>,
    pub(crate) precedence_ranks: BTreeMap<String, usize>,
    pub(crate) weights: BTreeMap<String, i64>,
    pub(crate) removed: Vec<RewriteRule>,
    pub(crate) remaining: Trs,
}

pub struct KboRuleRemovalProcessor {
    pub max_weight: i64,
    pub max_symbols: usize,
    pub exact_witness: Option<(Vec<String>, BTreeMap<String, usize>, BTreeMap<String, i64>)>,
    pub deadline: Option<Instant>,
}

impl WorklistProcessor for KboRuleRemovalProcessor {
    fn name(&self) -> &'static str {
        "kbo-rule-removal"
    }

    fn apply(&self, state: &ProblemState) -> ProcessorResult {
        let trs = match state {
            ProblemState::Trs(trs) | ProblemState::Srs(trs) => trs,
            _ => return ProcessorResult::Inapplicable,
        };
        let removal = if let Some((precedence, ranks, weights)) = &self.exact_witness {
            checked_top_level_kbo_removal(trs, precedence, ranks, weights)
        } else {
            synthesize_top_level_kbo_removal(trs, self.max_weight, self.max_symbols, self.deadline)
        };
        let Some(removal) = removal else {
            return ProcessorResult::Inapplicable;
        };
        let residual = ProblemState::from_trs(removal.remaining);
        let precedence = removal.precedence;
        let precedence_ranks = removal.precedence_ranks;
        let exact_weights = removal.weights.clone();
        let weights = removal.weights.into_iter().collect::<Vec<_>>();
        let removed = removal.removed;
        let selected_atom = ProveStrategyProcessor::ExactKbo {
            precedence: precedence.clone(),
            precedence_ranks: precedence_ranks.clone(),
            weights: exact_weights,
        }
        .to_strategy_atom();
        ProcessorResult::Applied(
            ProcessorApplication::new(vec![residual], move |children| {
                let [ProblemCertificate::Trs(proof)] =
                    <[ProblemCertificate; 1]>::try_from(children).ok()?
                else {
                    return None;
                };
                if proof.status() != &Status::Terminating {
                    return None;
                }
                Some(ProblemCertificate::Trs(Proof::terminating(vec![
                    ProofStep::KboRuleRemoval {
                        precedence: precedence.clone(),
                        precedence_ranks: precedence_ranks.clone(),
                        weights: weights.clone(),
                        removed: removed.clone(),
                        proof: Box::new(proof),
                    },
                ])))
            })
            .with_selected_atom(selected_atom),
        )
    }
}

pub(crate) fn checked_top_level_kbo_removal(
    trs: &Trs,
    precedence: &[String],
    precedence_ranks: &BTreeMap<String, usize>,
    weights: &BTreeMap<String, i64>,
) -> Option<TopLevelKboRemoval> {
    let arities = trs
        .arities()
        .into_iter()
        .map(|(symbol, arity)| (symbol.as_str().to_owned(), arity))
        .collect::<BTreeMap<_, _>>();
    if arities
        .keys()
        .any(|symbol| !precedence_ranks.contains_key(symbol) || !weights.contains_key(symbol))
        || !top_level_kbo_weights_are_admissible(&arities, weights, precedence_ranks)
    {
        return None;
    }
    let ranks = top_precedence_rank_refs(precedence_ranks);
    let mut removed = Vec::new();
    let mut remaining = Vec::new();
    for rule in trs.rules() {
        if top_level_kbo_gt(rule.lhs(), rule.rhs(), weights, &ranks) {
            removed.push(rule.clone());
        } else if rule.lhs() == rule.rhs() {
            remaining.push(rule.clone());
        } else {
            return None;
        }
    }
    if removed.is_empty() {
        return None;
    }
    Some(TopLevelKboRemoval {
        precedence: precedence.to_vec(),
        precedence_ranks: precedence_ranks.clone(),
        weights: weights.clone(),
        removed,
        remaining: Trs::new_with_strategy(
            trs.name().map(str::to_owned),
            trs.variables().clone(),
            remaining,
            trs.strategy(),
        ),
    })
}
