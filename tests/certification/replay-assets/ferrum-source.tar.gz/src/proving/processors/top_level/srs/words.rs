use crate::core::{RewriteRule, Term, Variable};

pub(crate) fn reverse_srs_rules(rules: &[RewriteRule]) -> Option<Vec<RewriteRule>> {
    rules
        .iter()
        .map(|rule| {
            let (mut lhs, lhs_tail) = strict_srs_word_with_tail(rule.lhs())?;
            let (mut rhs, rhs_tail) = strict_srs_word_with_tail(rule.rhs())?;
            if lhs_tail != rhs_tail {
                return None;
            }
            lhs.reverse();
            rhs.reverse();
            let tail = Term::Var(lhs_tail);
            Some(RewriteRule::new(
                srs_word_to_term(&lhs, tail.clone()),
                srs_word_to_term(&rhs, tail),
            ))
        })
        .collect()
}

pub(crate) fn strict_srs_word_with_tail(
    term: &Term,
) -> Option<(Vec<crate::core::Symbol>, Variable)> {
    let mut word = Vec::new();
    let mut cursor = term;
    loop {
        match cursor {
            Term::Var(variable) => return Some((word, variable.clone())),
            Term::App { symbol, args } if args.len() == 1 => {
                word.push(symbol.clone());
                cursor = &args[0];
            }
            _ => return None,
        }
    }
}

pub(crate) fn srs_word_to_term(word: &[crate::core::Symbol], tail: Term) -> Term {
    word.iter()
        .rev()
        .fold(tail, |term, symbol| Term::app(symbol.as_str(), vec![term]))
}
