use std::time::Instant;

use super::automaton::{
    SrsMatchAtBound, SrsRfcBarrenClosure, prove_srs_by_rfc_match_bounds_with_limits,
};
use crate::proving::{Proof, ProofStep};

use super::super::super::{
    ProblemCertificate, ProblemState, ProcessorApplication, ProcessorResult, WorklistProcessor,
};

pub struct SrsRfcMatchBoundsProcessor {
    pub max_bound: usize,
    pub max_words: usize,
    pub max_word_len: usize,
    pub max_states: usize,
    pub max_transitions: usize,
    pub at_bound: SrsMatchAtBound,
    pub closure: SrsRfcBarrenClosure,
    pub deadline: Option<Instant>,
}

impl WorklistProcessor for SrsRfcMatchBoundsProcessor {
    fn name(&self) -> &'static str {
        "srs-rfc-match-bounds"
    }

    fn apply(&self, state: &ProblemState) -> ProcessorResult {
        let ProblemState::Srs(trs) = state else {
            return ProcessorResult::Inapplicable;
        };
        let proof = prove_srs_by_rfc_match_bounds_with_limits(
            trs,
            self.max_bound,
            self.max_words,
            self.max_word_len,
            self.max_states,
            self.max_transitions,
            self.at_bound,
            self.closure,
            self.deadline,
        );
        let Some(witness) = proof else {
            return if self.deadline.is_some_and(|limit| Instant::now() >= limit) {
                ProcessorResult::TimedOut
            } else {
                ProcessorResult::Inapplicable
            };
        };
        let step = if witness.automaton_closed {
            ProofStep::RfcAutomatonClosedBounds {
                proof: witness.proof,
                initial_words: witness.initial_words,
            }
        } else {
            ProofStep::RfcBounds {
                proof: witness.proof,
                initial_words: witness.initial_words,
            }
        };
        let proof = Proof::terminating(vec![step]);
        ProcessorResult::Applied(ProcessorApplication::solved(ProblemCertificate::Trs(proof)))
    }
}
