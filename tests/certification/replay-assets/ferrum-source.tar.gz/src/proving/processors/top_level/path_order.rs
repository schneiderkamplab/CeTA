use std::collections::BTreeMap;
use std::time::Instant;

use crate::core::Term;
use crate::core::{RewriteRule, Trs};
use crate::proving::dependency_pairs::{DpArgumentFilter, DpPathOrderKind};
use crate::proving::dependency_pairs::{DpArgumentFilterEntry, filter_term};
use crate::proving::dependency_pairs::{compatible_filter_choices, joined_filter_choices};
use crate::proving::engine::ProveStrategyProcessor;
use crate::proving::processors::top_level::smt::{
    and as smt_and, boolean as smt_boolean, check_build, command_exists, or as smt_or,
    parse_integer_values, run_script, sanitize_identifier,
};
use crate::proving::runtime::current_thread_cancelled;
use crate::proving::{Proof, ProofStep, Status};

use super::super::{
    ProblemCertificate, ProblemState, ProcessorApplication, ProcessorResult, WorklistProcessor,
};

const MAX_FILTERED_TERM_ALTERNATIVES: usize = 20_000;

#[cfg(test)]
mod bound_witness_tests {
    use super::*;
    use crate::core::Variable;
    use std::collections::BTreeSet;

    #[test]
    fn shared_top_path_order_keeps_positional_equivalence_boundary() {
        if !command_exists("z3") && !command_exists("cvc5") { return; }
        let x = Term::var("x");
        let y = Term::var("y");
        let trs = Trs::new(None, BTreeSet::from([Variable::new("x"), Variable::new("y")]), vec![
            RewriteRule::new(Term::app("f", vec![x.clone(), y.clone()]),
                             Term::app("f", vec![y, x.clone()])),
            RewriteRule::new(Term::app("erase", vec![x.clone()]), x),
        ]);
        let arities = BTreeMap::from([("f".to_string(), 2), ("erase".to_string(), 1)]);
        let filters = top_level_path_order_permutation_filter_entries_by_symbol(&arities);
        // Multiset equality would weakly orient the swap, but the existing
        // whole-TRS checker deliberately uses positional quasi-equivalence.
        assert!(synthesize_top_level_path_order_shared(
            &trs, &arities.keys().cloned().collect::<Vec<_>>(), &filters,
            Some(Instant::now() + std::time::Duration::from_secs(5)),
        ).is_none());
    }

    #[test]
    fn native_top_path_order_removes_rules_modulo_quasi_precedence() {
        if !command_exists("z3") && !command_exists("cvc5") { return; }
        for (f, g) in [("left", "right"), ("renamed_a", "renamed_b")] {
            let x = Term::var("x");
            let trs = Trs::new(None, BTreeSet::from([Variable::new("x")]), vec![
                RewriteRule::new(Term::app(f, vec![x.clone()]), Term::app(g, vec![x.clone()])),
                RewriteRule::new(Term::app(g, vec![x.clone()]), Term::app(f, vec![x.clone()])),
                RewriteRule::new(Term::app("erase", vec![x.clone()]), x),
            ]);
            let removal = synthesize_top_level_path_order_removal_with_deadline(
                &trs, 3, Some(Instant::now() + std::time::Duration::from_secs(5)))
                .expect("weak equivalence leaves the mutual cycle and deletes erase");
            assert_eq!(removal.removed, vec![trs.rules()[2].clone()]);
            assert_eq!(removal.remaining.rules(), &trs.rules()[..2]);
            let arities = BTreeMap::from([
                (f.to_string(), 1), (g.to_string(), 1), ("erase".to_string(), 1),
            ]);
            let filters = top_level_path_order_permutation_filter_entries_by_symbol(&arities);
            let shared = synthesize_top_level_path_order_shared(
                &trs, &arities.keys().cloned().collect::<Vec<_>>(), &filters,
                Some(Instant::now() + std::time::Duration::from_secs(5)),
            ).expect("shared encoding preserves whole-TRS quasi precedence");
            assert_eq!(shared.removed, removal.removed);
            assert_eq!(shared.remaining.rules(), removal.remaining.rules());
        }
    }

    #[test]
    fn top_path_order_filters_keep_every_argument() {
        let entries = top_level_path_order_permutation_filter_entries_by_symbol(
            &BTreeMap::from([("unary".into(), 1), ("binary".into(), 2)]));
        assert!(entries["unary"].contains(&DpArgumentFilterEntry::Collapsing(0)));
        assert!(entries["binary"].iter().all(|entry| matches!(entry,
            DpArgumentFilterEntry::NonCollapsing(positions) if positions.len() == 2)));
    }

    #[test]
    fn top_path_order_repeated_filter_choices_are_consistent_and_cached() {
        let entries = top_level_path_order_permutation_filter_entries_by_symbol(
            &BTreeMap::from([("renamed".into(), 1)]));
        let mut term = Term::var("x");
        for _ in 0..24 { term = Term::app("renamed", vec![term]); }
        let alternatives = top_filtered_term_alternatives(&term, &entries,
            Some(Instant::now() + std::time::Duration::from_secs(5))).unwrap();
        assert_eq!(alternatives.len(), 2);
        assert!(alternatives.iter().any(|a| a.term == term));
        assert!(alternatives.iter().any(|a| a.term == Term::var("x")));
    }

    fn problem(symbol: &str) -> Trs {
        Trs::new(None, BTreeSet::from([Variable::new("x")]), vec![
            RewriteRule::new(Term::app(symbol, vec![Term::var("x")]), Term::var("x")),
        ])
    }

    #[test]
    fn bound_path_order_removal_transports_symbols_and_roundtrips() {
        let source = problem("f");
        let live = problem("renamed");
        let processor = PathOrderRuleRemovalProcessor {
            shared_encoding: false,
            source_trs_input_xml: Some(crate::cert::write_trs_input_cpf3(&source)),
            max_symbols: 0,
            exact_witness: Some((BTreeMap::from([("f".into(), DpPathOrderKind::Lpo)]),
                vec!["f".into()], BTreeMap::from([("f".into(), 1)]),
                BTreeMap::from([("f".into(), DpArgumentFilterEntry::NonCollapsing(vec![0]))]))),
            exact_removed_rule_indices: Some(vec![0]), deadline: None,
        };
        let ProcessorResult::Applied(application) = processor.apply(&ProblemState::Trs(live)) else {
            panic!("renamed source must match");
        };
        let atom = application.selected_atom().unwrap();
        assert!(atom.contains("source-hex="));
        assert!(crate::proving::engine::ProveStrategy::parse(atom).is_ok());
        let unrelated = Trs::new(None, BTreeSet::new(), vec![]);
        assert!(matches!(processor.apply(&ProblemState::Trs(unrelated)), ProcessorResult::Failed { .. }));
    }

    #[test]
    fn exact_removal_accepts_omitted_nullary_filter_but_not_nonnullary_filter() {
        let trs = Trs::new(None, BTreeSet::new(), vec![
            RewriteRule::new(Term::app("f", vec![Term::app("c", vec![])]), Term::app("c", vec![])),
        ]);
        let mut processor = PathOrderRuleRemovalProcessor {
            shared_encoding: false,
            source_trs_input_xml: None, max_symbols: 0,
            exact_witness: Some((BTreeMap::from([("f".into(), DpPathOrderKind::Lpo), ("c".into(), DpPathOrderKind::Lpo)]),
                vec!["f".into(), "c".into()], BTreeMap::from([("f".into(), 0), ("c".into(), 1)]),
                BTreeMap::from([("f".into(), DpArgumentFilterEntry::NonCollapsing(vec![0]))]))),
            exact_removed_rule_indices: Some(vec![0]), deadline: None,
        };
        assert!(matches!(processor.apply(&ProblemState::Trs(trs.clone())), ProcessorResult::Applied(_)));
        processor.exact_witness.as_mut().unwrap().3.clear();
        assert!(matches!(processor.apply(&ProblemState::Trs(trs)), ProcessorResult::Failed { .. }));
    }
}

pub(crate) fn synthesize_top_level_path_order_removal_with_deadline(
    trs: &Trs,
    max_symbols: usize,
    deadline: Option<Instant>,
) -> Option<TopLevelPathOrderRemoval> {
    let arities = trs
        .arities()
        .into_iter()
        .map(|(symbol, arity)| (symbol.as_str().to_string(), arity))
        .collect::<BTreeMap<_, _>>();
    if arities.is_empty() || arities.len() > max_symbols {
        return None;
    }
    synthesize_top_level_path_order_removal_with_smt(trs, &arities, deadline)
}

fn synthesize_top_level_path_order_removal_with_smt(
    trs: &Trs,
    arities: &BTreeMap<String, usize>,
    deadline: Option<Instant>,
) -> Option<TopLevelPathOrderRemoval> {
    let symbols = arities.keys().cloned().collect::<Vec<_>>();
    let filter_entries = top_level_path_order_permutation_filter_entries_by_symbol(arities);
    synthesize_top_level_path_order_removal_with_filter_entries(
        trs,
        &symbols,
        &filter_entries,
        deadline,
    )
}

fn synthesize_top_level_path_order_removal_with_filter_entries(
    trs: &Trs,
    symbols: &[String],
    filter_entries: &BTreeMap<String, Vec<DpArgumentFilterEntry>>,
    deadline: Option<Instant>,
) -> Option<TopLevelPathOrderRemoval> {
    let script = top_level_path_order_smt_script(trs, symbols, filter_entries, deadline)?;
    let solver = command_exists("z3")
        .then_some("z3")
        .or_else(|| command_exists("cvc5").then_some("cvc5"))?;
    let stdout = run_script(&script, solver, deadline)?;
    if stdout
        .lines()
        .map(str::trim)
        .find(|line| !line.is_empty())?
        != "sat"
    {
        return None;
    }
    let (precedence, precedence_ranks, statuses, argument_filter) =
        top_level_parse_path_order_smt_model(&stdout, symbols, filter_entries)?;
    checked_top_level_path_order_removal_with_ranks(
        trs,
        &statuses,
        &precedence,
        &precedence_ranks,
        &argument_filter,
    )
}

// Reuse the shared comparison encoding, not the DP processor's applicability
// conditions: callers still supply only whole-TRS-safe filter choices, and
// the resulting model passes the original whole-TRS validator below.
fn synthesize_top_level_path_order_shared(
    trs: &Trs,
    symbols: &[String],
    filter_entries: &BTreeMap<String, Vec<DpArgumentFilterEntry>>,
    deadline: Option<Instant>,
) -> Option<TopLevelPathOrderRemoval> {
    use crate::proving::dependency_pairs::{
        DependencyPair, configured_mixed_path_order_smt_script, parse_order_model,
        parse_path_order_status_model, run_path_order_smt_script, DpOptions,
    };
    let encoding_started = Instant::now();
    let constraints = trs.rules().iter().enumerate().map(|(index, rule)| {
        DependencyPair::new(rule.lhs().clone(), rule.rhs().clone(), index)
    }).collect::<Vec<_>>();
    let script = configured_mixed_path_order_smt_script(
        &constraints, &[], &[], symbols, filter_entries,
        None, None, None, deadline, true, false, None, true,
    )?;
    crate::proving::runtime::write_progress_event(
        "smt", "encoded", "top-level-shared-path-order",
        encoding_started.elapsed().as_millis(),
        &format!("bytes={} rules={} symbols={}", script.len(), trs.rules().len(), symbols.len()),
    );
    let solve_started = Instant::now();
    let result = run_path_order_smt_script(&script, &DpOptions::default(), deadline);
    crate::proving::runtime::write_progress_event(
        "smt", "solved", "top-level-shared-path-order",
        solve_started.elapsed().as_millis(),
        if result.is_some() { "output-returned" } else { "no-output" },
    );
    let stdout = result?;
    let (precedence, ranks, filter, _) = parse_order_model(&stdout, symbols, filter_entries)?;
    let statuses = parse_path_order_status_model(&stdout, symbols)?;
    checked_top_level_path_order_removal_with_ranks(trs, &statuses, &precedence, &ranks, &filter)
}

pub(crate) fn checked_top_level_path_order_removal_with_ranks(
    trs: &Trs,
    statuses: &BTreeMap<String, DpPathOrderKind>,
    precedence: &[String],
    precedence_ranks: &BTreeMap<String, usize>,
    argument_filter: &DpArgumentFilter,
) -> Option<TopLevelPathOrderRemoval> {
    let borrowed_ranks = precedence_ranks
        .iter()
        .map(|(symbol, rank)| (symbol.as_str(), *rank))
        .collect::<BTreeMap<_, _>>();
    let mut removed = Vec::new();
    let mut remaining = Vec::new();
    for rule in trs.rules() {
        if !top_level_path_order_ge(
            rule.lhs(),
            rule.rhs(),
            statuses,
            &borrowed_ranks,
            argument_filter,
        ) {
            return None;
        }
        if top_level_path_order_gt_filtered(
            rule.lhs(),
            rule.rhs(),
            statuses,
            &borrowed_ranks,
            argument_filter,
        ) {
            removed.push(rule.clone());
        } else {
            remaining.push(rule.clone());
        }
    }
    if removed.is_empty() || remaining.len() == trs.rules().len() {
        return None;
    }
    Some(TopLevelPathOrderRemoval {
        statuses: statuses.clone(),
        precedence: precedence.to_vec(),
        precedence_ranks: precedence_ranks.clone(),
        argument_filter: argument_filter.clone(),
        removed,
        remaining: Trs::new_with_strategy(
            trs.name().map(str::to_string),
            trs.variables().clone(),
            remaining,
            trs.strategy(),
        ),
    })
}

pub(crate) fn top_level_path_order_permutation_filter_entries_by_symbol(
    arities: &BTreeMap<String, usize>,
) -> BTreeMap<String, Vec<DpArgumentFilterEntry>> {
    arities
        .iter()
        .map(|(symbol, arity)| {
            let positions = (0..*arity).collect::<Vec<_>>();
            let mut entries = Vec::new();
            if *arity > 1 {
                for permutation in top_level_argument_permutations(&positions) {
                    top_level_push_unique_filter_entry(
                        &mut entries,
                        DpArgumentFilterEntry::NonCollapsing(permutation),
                    );
                }
            } else {
                entries.push(DpArgumentFilterEntry::NonCollapsing(positions));
                // Unary projection keeps the only argument, hence preserves
                // strict monotonicity. Never project away arguments of a
                // higher-arity symbol in a whole-TRS reduction pair.
                if *arity == 1 {
                    entries.push(DpArgumentFilterEntry::Collapsing(0));
                }
            }
            (symbol.clone(), entries)
        })
        .collect()
}

fn top_level_push_unique_filter_entry(
    entries: &mut Vec<DpArgumentFilterEntry>,
    entry: DpArgumentFilterEntry,
) {
    if !entries.contains(&entry) {
        entries.push(entry);
    }
}

pub(crate) fn top_level_path_order_smt_script(
    trs: &Trs,
    symbols: &[String],
    filter_entries: &BTreeMap<String, Vec<DpArgumentFilterEntry>>,
    deadline: Option<Instant>,
) -> Option<String> {
    let mut script = String::new();
    script.push_str("(set-logic QF_LIA)\n");
    let max_rank = i64::try_from(symbols.len().checked_sub(1)?).ok()?;
    for symbol in symbols {
        check_build(&script, deadline)?;
        let rank = top_path_order_rank(symbol);
        let status = top_path_order_status(symbol);
        script.push_str(&format!("(declare-const {rank} Int)\n"));
        script.push_str(&format!(
            "(assert (and (>= {rank} 0) (<= {rank} {max_rank})))\n"
        ));
        script.push_str(&format!("(declare-const {status} Int)\n"));
        script.push_str(&format!("(assert (or (= {status} 0) (= {status} 1)))\n"));
        if let Some(entries) = filter_entries.get(symbol) {
            let max_filter = i64::try_from(entries.len().checked_sub(1)?).ok()?;
            let filter = top_path_order_filter(symbol);
            script.push_str(&format!("(declare-const {filter} Int)\n"));
            script.push_str(&format!(
                "(assert (and (>= {filter} 0) (<= {filter} {max_filter})))\n"
            ));
        }
    }
    for (index, left) in symbols.iter().enumerate() {
        for right in &symbols[index + 1..] {
            script.push_str(&format!("(assert (=> (= {} {}) (= {} {})))\n",
                top_path_order_rank(left), top_path_order_rank(right),
                top_path_order_status(left), top_path_order_status(right)));
        }
    }
    let mut encoder = TopPathOrderSmtEncoder::new(deadline);
    let mut rule_assertions = Vec::new();
    let mut strict_terms = Vec::new();
    for rule in trs.rules() {
        check_build(&script, deadline)?;
        rule_assertions.push(top_filtered_path_order_ge_formula(
            rule.lhs(),
            rule.rhs(),
            filter_entries,
            &mut encoder,
        )?);
        strict_terms.push(top_filtered_path_order_gt_formula(
            rule.lhs(),
            rule.rhs(),
            filter_entries,
            &mut encoder,
        )?);
    }
    script.push_str(&encoder.definitions);
    check_build(&script, deadline)?;
    for assertion in rule_assertions {
        check_build(&script, deadline)?;
        script.push_str("(assert ");
        script.push_str(&assertion);
        script.push_str(")\n");
    }
    if strict_terms.is_empty() {
        script.push_str("(assert false)\n");
    } else {
        script.push_str("(assert ");
        script.push_str(&smt_or(strict_terms));
        script.push_str(")\n");
    }
    script.push_str("(check-sat)\n(get-model)\n");
    check_build(&script, deadline)?;
    Some(script)
}

fn top_filtered_path_order_ge_formula(
    lhs: &Term,
    rhs: &Term,
    filter_entries: &BTreeMap<String, Vec<DpArgumentFilterEntry>>,
    encoder: &mut TopPathOrderSmtEncoder,
) -> Option<String> {
    top_filtered_path_order_relation_formula(
        lhs,
        rhs,
        filter_entries,
        encoder,
        |encoder, left, right| {
            Some(smt_or(vec![
                encoder.equiv(left, right)?,
                encoder.gt(left, right)?,
            ]))
        },
    )
}

fn top_filtered_path_order_gt_formula(
    lhs: &Term,
    rhs: &Term,
    filter_entries: &BTreeMap<String, Vec<DpArgumentFilterEntry>>,
    encoder: &mut TopPathOrderSmtEncoder,
) -> Option<String> {
    top_filtered_path_order_relation_formula(
        lhs,
        rhs,
        filter_entries,
        encoder,
        |encoder, left, right| encoder.gt(left, right),
    )
}

fn top_filtered_path_order_relation_formula(
    lhs: &Term,
    rhs: &Term,
    filter_entries: &BTreeMap<String, Vec<DpArgumentFilterEntry>>,
    encoder: &mut TopPathOrderSmtEncoder,
    relation: impl Fn(&mut TopPathOrderSmtEncoder, &Term, &Term) -> Option<String>,
) -> Option<String> {
    let lhs_alternatives = top_filtered_term_alternatives(lhs, filter_entries, encoder.deadline)?;
    let rhs_alternatives = top_filtered_term_alternatives(rhs, filter_entries, encoder.deadline)?;
    if lhs_alternatives.is_empty() || rhs_alternatives.is_empty() {
        return None;
    }
    let mut disjuncts = Vec::new();
    for left in &lhs_alternatives {
        for right in &rhs_alternatives {
            if encoder.timed_out() {
                return None;
            }
            if !compatible_filter_choices(&left.filters, &right.filters) {
                continue;
            }
            disjuncts.push(smt_and(vec![
                left.condition.clone(),
                right.condition.clone(),
                relation(encoder, &left.term, &right.term)?,
            ]));
        }
    }
    Some(smt_or(disjuncts))
}

struct TopPathOrderSmtEncoder {
    definitions: String,
    variables: BTreeMap<(Term, Term), String>,
    next_variable: usize,
    deadline: Option<Instant>,
}

impl TopPathOrderSmtEncoder {
    fn new(deadline: Option<Instant>) -> Self {
        Self {
            definitions: String::new(),
            variables: BTreeMap::new(),
            next_variable: 0,
            deadline,
        }
    }

    fn timed_out(&self) -> bool {
        current_thread_cancelled() || self.deadline.is_some_and(|limit| Instant::now() >= limit)
    }

    fn equiv(&self, lhs: &Term, rhs: &Term) -> Option<String> {
        if self.timed_out() { return None; }
        match (lhs, rhs) {
            (Term::Var(a), Term::Var(b)) => Some(smt_boolean(a == b)),
            (Term::App { symbol: f, args: xs }, Term::App { symbol: g, args: ys })
                if xs.len() == ys.len() => {
                let mut parts = vec![format!("(= {} {})",
                    top_path_order_rank(f.as_str()), top_path_order_rank(g.as_str()))];
                for (x, y) in xs.iter().zip(ys) { parts.push(self.equiv(x, y)?); }
                Some(smt_and(parts))
            }
            _ => Some("false".into()),
        }
    }

    fn gt(&mut self, lhs: &Term, rhs: &Term) -> Option<String> {
        if self.timed_out() {
            return None;
        }
        if lhs == rhs {
            return Some("false".to_string());
        }
        if let Some(variable) = self.variables.get(&(lhs.clone(), rhs.clone())) {
            return Some(variable.clone());
        }
        let variable = format!("pogt_{}", self.next_variable);
        self.next_variable += 1;
        self.variables
            .insert((lhs.clone(), rhs.clone()), variable.clone());
        self.definitions
            .push_str(&format!("(declare-const {variable} Bool)\n"));
        let formula = self.gt_definition(lhs, rhs)?;
        self.definitions
            .push_str(&format!("(assert (= {variable} {formula}))\n"));
        Some(variable)
    }

    fn gt_definition(&mut self, lhs: &Term, rhs: &Term) -> Option<String> {
        if self.timed_out() {
            return None;
        }
        match (lhs, rhs) {
            (_, Term::Var(variable)) => Some(smt_boolean(
                lhs != rhs && lhs.variables().contains(variable),
            )),
            (Term::Var(_), Term::App { .. }) => Some("false".to_string()),
            (
                Term::App {
                    symbol: lhs_symbol,
                    args: lhs_args,
                },
                Term::App {
                    symbol: rhs_symbol,
                    args: rhs_args,
                },
            ) => {
                let mut subterm = Vec::new();
                for arg in lhs_args {
                    subterm.push(smt_or(vec![self.equiv(arg, rhs)?, self.gt(arg, rhs)?]));
                }
                let dominates_rhs_args = smt_and(
                    rhs_args
                        .iter()
                        .map(|arg| self.gt(lhs, arg))
                        .collect::<Option<_>>()?,
                );
                let precedence_case = smt_and(vec![
                    dominates_rhs_args.clone(),
                    format!(
                        "(< {} {})",
                        top_path_order_rank(lhs_symbol.as_str()),
                        top_path_order_rank(rhs_symbol.as_str())
                    ),
                ]);
                let equivalent_root_case = {
                    let lex = self.lex_gt(lhs_args, rhs_args)?;
                    let multiset = self.multiset_gt(lhs_args, rhs_args)?;
                    smt_and(vec![
                        dominates_rhs_args,
                        format!(
                            "(= {} {})",
                            top_path_order_rank(lhs_symbol.as_str()),
                            top_path_order_rank(rhs_symbol.as_str())
                        ),
                        smt_or(vec![
                            smt_and(vec![
                                format!("(= {} 1)", top_path_order_status(lhs_symbol.as_str())),
                                lex,
                            ]),
                            smt_and(vec![
                                format!("(= {} 0)", top_path_order_status(lhs_symbol.as_str())),
                                multiset,
                            ]),
                        ]),
                    ])
                };
                Some(smt_or(
                    subterm
                        .into_iter()
                        .chain([precedence_case, equivalent_root_case])
                        .collect(),
                ))
            }
        }
    }

    fn lex_gt(&mut self, lhs: &[Term], rhs: &[Term]) -> Option<String> {
        let mut disjuncts = Vec::new();
        for index in 0..lhs.len().min(rhs.len()) {
            if self.timed_out() {
                return None;
            }
            let prefix_equal = smt_and(
                (0..index)
                    .map(|prefix| self.equiv(&lhs[prefix], &rhs[prefix]))
                    .collect::<Option<_>>()?,
            );
            disjuncts.push(smt_and(vec![
                prefix_equal,
                smt_boolean(lhs[index] != rhs[index]),
                self.gt(&lhs[index], &rhs[index])?,
            ]));
        }
        if lhs.len() > rhs.len() {
            disjuncts.push(smt_and(lhs.iter().zip(rhs).map(|(l,r)| self.equiv(l,r)).collect::<Option<_>>()?));
        }
        Some(smt_or(disjuncts))
    }

    fn multiset_gt(&mut self, lhs: &[Term], rhs: &[Term]) -> Option<String> {
        self.multiset_match(lhs, rhs, 0, &mut vec![false; rhs.len()], &mut Vec::new())
    }

    fn multiset_match<'a>(
        &mut self,
        lhs: &'a [Term],
        rhs: &[Term],
        lhs_index: usize,
        matched: &mut [bool],
        removed: &mut Vec<&'a Term>,
    ) -> Option<String> {
        if self.timed_out() {
            return None;
        }
        if lhs_index == lhs.len() {
            if removed.is_empty() { return Some("false".into()); }
            let mut obligations = Vec::new();
            for (index, right) in rhs.iter().enumerate() {
                if !matched[index] {
                    let mut choices = Vec::new();
                    for left in removed.iter() { choices.push(self.gt(left, right)?); }
                    obligations.push(smt_or(choices));
                }
            }
            return Some(smt_and(obligations));
        }
        let mut disjuncts = Vec::new();
        for (index, right) in rhs.iter().enumerate() {
            if matched[index] { continue; }
            let equal = self.equiv(&lhs[lhs_index], right)?;
            matched[index] = true;
            let rest = self.multiset_match(lhs, rhs, lhs_index + 1, matched, removed)?;
            matched[index] = false;
            disjuncts.push(smt_and(vec![equal, rest]));
        }
        removed.push(&lhs[lhs_index]);
        disjuncts.push(self.multiset_match(lhs, rhs, lhs_index + 1, matched, removed)?);
        removed.pop();
        Some(smt_or(disjuncts))
    }
}

#[derive(Clone, Debug)]
struct TopFilteredTermAlternative {
    condition: String,
    term: Term,
    filters: BTreeMap<String, usize>,
}

fn top_filtered_term_alternatives(
    term: &Term,
    filter_entries: &BTreeMap<String, Vec<DpArgumentFilterEntry>>,
    deadline: Option<Instant>,
) -> Option<Vec<TopFilteredTermAlternative>> {
    top_filtered_term_alternatives_cached(term, filter_entries, deadline, &mut BTreeMap::new())
}

fn top_filtered_term_alternatives_cached(
    term: &Term,
    filter_entries: &BTreeMap<String, Vec<DpArgumentFilterEntry>>,
    deadline: Option<Instant>,
    cache: &mut BTreeMap<Term, Vec<TopFilteredTermAlternative>>,
) -> Option<Vec<TopFilteredTermAlternative>> {
    if current_thread_cancelled() || deadline.is_some_and(|limit| Instant::now() >= limit) {
        return None;
    }
    if let Some(alternatives) = cache.get(term) { return Some(alternatives.clone()); }
    let result = match term {
        Term::Var(_) => Some(vec![TopFilteredTermAlternative {
            condition: "true".to_string(),
            term: term.clone(),
            filters: BTreeMap::new(),
        }]),
        Term::App { symbol, args } => {
            let entries = filter_entries
                .get(symbol.as_str())
                .cloned()
                .unwrap_or_else(|| {
                    vec![DpArgumentFilterEntry::NonCollapsing(
                        (0..args.len()).collect(),
                    )]
                });
            let mut alternatives = Vec::new();
            for (entry_index, entry) in entries.into_iter().enumerate() {
                if alternatives.len() >= MAX_FILTERED_TERM_ALTERNATIVES {
                    return Some(Vec::new());
                }
                let entry_condition = format!(
                    "(= {} {entry_index})",
                    top_path_order_filter(symbol.as_str())
                );
                let entry_filters = BTreeMap::from([(symbol.as_str().to_string(), entry_index)]);
                match entry {
                    DpArgumentFilterEntry::Collapsing(position) => {
                        if let Some(arg) = args.get(position) {
                            for alternative in
                                top_filtered_term_alternatives_cached(arg, filter_entries, deadline, cache)?
                            {
                                let Some(filters) = joined_filter_choices(&entry_filters, &alternative.filters) else { continue; };
                                if alternatives.len() >= MAX_FILTERED_TERM_ALTERNATIVES {
                                    return Some(Vec::new());
                                }
                                alternatives.push(TopFilteredTermAlternative {
                                    condition: smt_and(vec![
                                        entry_condition.clone(),
                                        alternative.condition,
                                    ]),
                                    term: alternative.term,
                                    filters,
                                });
                            }
                        }
                    }
                    DpArgumentFilterEntry::NonCollapsing(positions) => {
                        let selected = positions
                            .into_iter()
                            .filter_map(|position| args.get(position))
                            .collect::<Vec<_>>();
                        for (conditions, terms, child_filters) in
                            top_combine_filtered_arguments(&selected, filter_entries, deadline, cache)?
                        {
                            let Some(filters) = joined_filter_choices(&entry_filters, &child_filters) else { continue; };
                            if alternatives.len() >= MAX_FILTERED_TERM_ALTERNATIVES {
                                return Some(Vec::new());
                            }
                            alternatives.push(TopFilteredTermAlternative {
                                condition: smt_and(
                                    std::iter::once(entry_condition.clone())
                                        .chain(conditions)
                                        .collect(),
                                ),
                                term: Term::app(symbol.as_str(), terms),
                                filters,
                            });
                        }
                    }
                }
            }
            Some(alternatives)
        }
    };
    if let Some(alternatives) = &result { cache.insert(term.clone(), alternatives.clone()); }
    result
}

fn top_combine_filtered_arguments(
    args: &[&Term],
    filter_entries: &BTreeMap<String, Vec<DpArgumentFilterEntry>>,
    deadline: Option<Instant>,
    cache: &mut BTreeMap<Term, Vec<TopFilteredTermAlternative>>,
) -> Option<Vec<(Vec<String>, Vec<Term>, BTreeMap<String, usize>)>> {
    if current_thread_cancelled() || deadline.is_some_and(|limit| Instant::now() >= limit) {
        return None;
    }
    if let Some((first, rest)) = args.split_first() {
        let first_alternatives = top_filtered_term_alternatives_cached(first, filter_entries, deadline, cache)?;
        let rest_alternatives = top_combine_filtered_arguments(rest, filter_entries, deadline, cache)?;
        let mut combined = Vec::new();
        for first_alternative in first_alternatives {
            for (rest_conditions, rest_terms, rest_filters) in &rest_alternatives {
                let Some(filters) = joined_filter_choices(&first_alternative.filters, rest_filters) else { continue; };
                if combined.len() >= MAX_FILTERED_TERM_ALTERNATIVES {
                    return Some(Vec::new());
                }
                let mut conditions = vec![first_alternative.condition.clone()];
                conditions.extend(rest_conditions.clone());
                let mut terms = vec![first_alternative.term.clone()];
                terms.extend(rest_terms.clone());
                combined.push((conditions, terms, filters));
            }
        }
        Some(combined)
    } else {
        Some(vec![(Vec::new(), Vec::new(), BTreeMap::new())])
    }
}

fn top_level_parse_path_order_smt_model(
    output: &str,
    symbols: &[String],
    filter_entries: &BTreeMap<String, Vec<DpArgumentFilterEntry>>,
) -> Option<(
    Vec<String>,
    BTreeMap<String, usize>,
    BTreeMap<String, DpPathOrderKind>,
    DpArgumentFilter,
)> {
    let values = parse_integer_values(output)?;
    let mut ranked = Vec::new();
    let mut precedence_ranks = BTreeMap::new();
    let mut statuses = BTreeMap::new();
    for symbol in symbols {
        let rank = usize::try_from(values.get(&top_path_order_rank(symbol)).copied()?).ok()?;
        ranked.push((rank, symbol.clone()));
        precedence_ranks.insert(symbol.clone(), rank);
        let status = match values
            .get(&top_path_order_status(symbol))
            .copied()
            .unwrap_or(0)
        {
            0 => DpPathOrderKind::Rpo,
            1 => DpPathOrderKind::Lpo,
            _ => return None,
        };
        statuses.insert(symbol.clone(), status);
    }
    ranked.sort_by(|left, right| left.0.cmp(&right.0).then_with(|| left.1.cmp(&right.1)));
    let mut argument_filter = BTreeMap::new();
    for (symbol, entries) in filter_entries {
        let index = usize::try_from(
            values
                .get(&top_path_order_filter(symbol))
                .copied()
                .unwrap_or(0),
        )
        .ok()?;
        argument_filter.insert(symbol.clone(), entries.get(index)?.clone());
    }
    Some((
        ranked.into_iter().map(|(_, symbol)| symbol).collect(),
        precedence_ranks,
        statuses,
        argument_filter,
    ))
}

fn top_path_order_rank(symbol: &str) -> String {
    format!("por_{}", sanitize_identifier(symbol))
}

fn top_path_order_filter(symbol: &str) -> String {
    format!("pof_{}", sanitize_identifier(symbol))
}

fn top_path_order_status(symbol: &str) -> String {
    format!("pos_{}", sanitize_identifier(symbol))
}

#[allow(dead_code)]
fn top_level_path_order_ge(
    lhs: &Term,
    rhs: &Term,
    statuses: &BTreeMap<String, DpPathOrderKind>,
    precedence: &BTreeMap<&str, usize>,
    argument_filter: &DpArgumentFilter,
) -> bool {
    let lhs = filter_term(lhs, argument_filter);
    let rhs = filter_term(rhs, argument_filter);
    top_level_path_order_equiv(&lhs, &rhs, precedence)
        || top_level_path_order_gt(&lhs, &rhs, statuses, precedence)
}

fn top_level_path_order_gt_filtered(
    lhs: &Term,
    rhs: &Term,
    statuses: &BTreeMap<String, DpPathOrderKind>,
    precedence: &BTreeMap<&str, usize>,
    argument_filter: &DpArgumentFilter,
) -> bool {
    let lhs = filter_term(lhs, argument_filter);
    let rhs = filter_term(rhs, argument_filter);
    top_level_path_order_gt(&lhs, &rhs, statuses, precedence)
}

fn top_level_path_order_gt(
    lhs: &Term,
    rhs: &Term,
    statuses: &BTreeMap<String, DpPathOrderKind>,
    precedence: &BTreeMap<&str, usize>,
) -> bool {
    match (lhs, rhs) {
        (_, Term::Var(variable)) => lhs != rhs && lhs.variables().contains(variable),
        (Term::Var(_), Term::App { .. }) => false,
        (
            Term::App {
                symbol: lhs_symbol,
                args: lhs_args,
            },
            Term::App {
                symbol: rhs_symbol,
                args: rhs_args,
            },
        ) => {
            if lhs_args
                .iter()
                .any(|arg| top_level_path_order_equiv(arg, rhs, precedence)
                    || top_level_path_order_gt(arg, rhs, statuses, precedence))
            {
                return true;
            }
            let lhs_dominates_rhs_args = rhs_args
                .iter()
                .all(|arg| top_level_path_order_gt(lhs, arg, statuses, precedence));
            if !lhs_dominates_rhs_args {
                return false;
            }
            let lhs_rank = precedence
                .get(lhs_symbol.as_str())
                .copied()
                .unwrap_or(usize::MAX);
            let rhs_rank = precedence
                .get(rhs_symbol.as_str())
                .copied()
                .unwrap_or(usize::MAX);
            if lhs_rank < rhs_rank {
                return true;
            }
            if lhs_rank == rhs_rank {
                return match statuses
                    .get(lhs_symbol.as_str())
                    .copied()
                    .unwrap_or(DpPathOrderKind::Rpo)
                {
                    DpPathOrderKind::Lpo => {
                        top_level_lex_path_order_gt(lhs_args, rhs_args, statuses, precedence)
                    }
                    DpPathOrderKind::Rpo => {
                        top_level_multiset_path_order_gt(lhs_args, rhs_args, statuses, precedence)
                    }
                };
            }
            false
        }
    }
}

fn top_level_path_order_equiv(lhs: &Term, rhs: &Term, precedence: &BTreeMap<&str, usize>) -> bool {
    match (lhs, rhs) {
        (Term::Var(left), Term::Var(right)) => left == right,
        (
            Term::App {
                symbol: lhs_symbol,
                args: lhs_args,
            },
            Term::App {
                symbol: rhs_symbol,
                args: rhs_args,
            },
        ) => {
            lhs_args.len() == rhs_args.len()
                && precedence
                    .get(lhs_symbol.as_str())
                    .copied()
                    .unwrap_or(usize::MAX)
                    == precedence
                        .get(rhs_symbol.as_str())
                        .copied()
                        .unwrap_or(usize::MAX)
                && lhs_args
                    .iter()
                    .zip(rhs_args)
                    .all(|(left, right)| top_level_path_order_equiv(left, right, precedence))
        }
        _ => false,
    }
}

fn top_level_lex_path_order_gt(
    lhs: &[Term],
    rhs: &[Term],
    statuses: &BTreeMap<String, DpPathOrderKind>,
    precedence: &BTreeMap<&str, usize>,
) -> bool {
    for (left, right) in lhs.iter().zip(rhs) {
        if top_level_path_order_equiv(left, right, precedence) {
            continue;
        }
        return top_level_path_order_gt(left, right, statuses, precedence);
    }
    lhs.len() > rhs.len()
}

fn top_level_multiset_path_order_gt(
    lhs: &[Term],
    rhs: &[Term],
    statuses: &BTreeMap<String, DpPathOrderKind>,
    precedence: &BTreeMap<&str, usize>,
) -> bool {
    // The common and important X = lhs, Z = empty case avoids exponential
    // common-submultiset enumeration for duplicated right arguments.
    if !lhs.is_empty()
        && rhs.iter().all(|right| {
            lhs.iter()
                .any(|left| top_level_path_order_gt(left, right, statuses, precedence))
        })
    {
        return true;
    }
    let mut matched_rhs = vec![false; rhs.len()];
    let mut removed_lhs = Vec::new();
    top_level_multiset_path_order_extension(
        lhs,
        rhs,
        statuses,
        precedence,
        0,
        &mut matched_rhs,
        &mut removed_lhs,
    )
}

/// Strict multiset extension of the path order.
///
/// One removed left element may dominate any number of added right elements;
/// requiring an injective left/right matching is only a sufficient condition
/// and rejects standard RPO witnesses such as `{s(x)} >mul {x,x}`. Enumerate
/// the common (quasi-equivalent) submultiset and then check that every
/// unmatched right element is below some removed left element.
fn top_level_multiset_path_order_extension<'a>(
    lhs: &'a [Term],
    rhs: &[Term],
    statuses: &BTreeMap<String, DpPathOrderKind>,
    precedence: &BTreeMap<&str, usize>,
    lhs_index: usize,
    matched_rhs: &mut [bool],
    removed_lhs: &mut Vec<&'a Term>,
) -> bool {
    if lhs_index == lhs.len() {
        return !removed_lhs.is_empty()
            && rhs.iter().enumerate().all(|(index, right)| {
                matched_rhs[index]
                    || removed_lhs
                        .iter()
                        .any(|left| top_level_path_order_gt(left, right, statuses, precedence))
            });
    }

    let left = &lhs[lhs_index];
    for (rhs_index, right) in rhs.iter().enumerate() {
        if !matched_rhs[rhs_index] && top_level_path_order_equiv(left, right, precedence) {
            matched_rhs[rhs_index] = true;
            if top_level_multiset_path_order_extension(
                lhs,
                rhs,
                statuses,
                precedence,
                lhs_index + 1,
                matched_rhs,
                removed_lhs,
            ) {
                return true;
            }
            matched_rhs[rhs_index] = false;
        }
    }

    removed_lhs.push(left);
    let result = top_level_multiset_path_order_extension(
        lhs,
        rhs,
        statuses,
        precedence,
        lhs_index + 1,
        matched_rhs,
        removed_lhs,
    );
    removed_lhs.pop();
    result
}

fn top_level_argument_permutations(positions: &[usize]) -> Vec<Vec<usize>> {
    fn go(index: usize, current: &mut Vec<usize>, result: &mut Vec<Vec<usize>>) {
        if index == current.len() {
            result.push(current.clone());
            return;
        }
        for swap_index in index..current.len() {
            current.swap(index, swap_index);
            go(index + 1, current, result);
            current.swap(index, swap_index);
        }
    }

    let mut current = positions.to_vec();
    let mut result = Vec::new();
    go(0, &mut current, &mut result);
    result
}

pub(crate) struct TopLevelPathOrderRemoval {
    pub(crate) statuses: BTreeMap<String, DpPathOrderKind>,
    pub(crate) precedence: Vec<String>,
    pub(crate) precedence_ranks: BTreeMap<String, usize>,
    pub(crate) argument_filter: DpArgumentFilter,
    pub(crate) removed: Vec<RewriteRule>,
    pub(crate) remaining: Trs,
}

pub struct PathOrderRuleRemovalProcessor {
    pub shared_encoding: bool,
    pub source_trs_input_xml: Option<String>,
    pub max_symbols: usize,
    pub exact_witness: Option<(
        BTreeMap<String, DpPathOrderKind>,
        Vec<String>,
        BTreeMap<String, usize>,
        DpArgumentFilter,
    )>,
    pub exact_removed_rule_indices: Option<Vec<usize>>,
    pub deadline: Option<Instant>,
}

impl WorklistProcessor for PathOrderRuleRemovalProcessor {
    fn name(&self) -> &'static str {
        "path-order-rule-removal"
    }

    fn apply(&self, state: &ProblemState) -> ProcessorResult {
        let trs = match state {
            ProblemState::Trs(trs) | ProblemState::Srs(trs) => trs,
            _ => return ProcessorResult::Inapplicable,
        };
        if let Some(source_xml) = &self.source_trs_input_xml {
            let Ok(crate::parsing::CpfInputProblem::Trs(source)) = crate::parsing::parse_cpf_input(None, source_xml) else {
                return ProcessorResult::Failed { reason: "invalid exact path-order source".into() };
            };
            let Some((symbols, rule_indices)) = crate::proving::processors::dp::portable_trs_isomorphism(&source, trs) else {
                return ProcessorResult::Failed { reason: "exact path-order source is not isomorphic to the live TRS".into() };
            };
            let (Some((statuses, precedence, ranks, filter)), Some(indices)) = (&self.exact_witness, &self.exact_removed_rule_indices) else {
                return ProcessorResult::Inapplicable;
            };
            let rename = |name: &String| symbols.get(&crate::core::Symbol::new(name.clone())).map(|symbol| symbol.as_str().to_owned()).unwrap_or_else(|| name.clone());
            let mapped = indices.iter().map(|index| rule_indices.get(index).copied()).collect::<Option<Vec<_>>>();
            let Some(mut mapped) = mapped else {
                return ProcessorResult::Failed { reason: "exact path-order deletion mask is outside the source".into() };
            };
            mapped.sort_unstable();
            return Self {
                shared_encoding: self.shared_encoding,
                source_trs_input_xml: None,
                max_symbols: self.max_symbols,
                exact_witness: Some((statuses.iter().map(|(k,v)| (rename(k),v.clone())).collect(),
                    precedence.iter().map(rename).collect(),
                    ranks.iter().map(|(k,v)| (rename(k),*v)).collect(),
                    filter.iter().map(|(k,v)| (rename(k),v.clone())).collect())),
                exact_removed_rule_indices: Some(mapped), deadline: self.deadline,
            }.apply(state);
        }
        let removal = if let (Some((statuses, precedence, ranks, filter)), Some(indices)) =
            (&self.exact_witness, &self.exact_removed_rule_indices)
        {
            // A nullary symbol has exactly one possible noncollapsing filter.
            // CPF witnesses may omit that vacuous entry; do not invent a
            // filter for any positive-arity symbol.
            let mut filter = filter.clone();
            for (symbol, arity) in trs.arities() {
                if arity == 0 {
                    filter.entry(symbol.as_str().to_owned())
                        .or_insert_with(|| DpArgumentFilterEntry::NonCollapsing(Vec::new()));
                }
            }
            if trs.arities().keys().any(|symbol| !filter.contains_key(symbol.as_str())) {
                return ProcessorResult::Failed { reason: "exact path-order deletion witness does not cover the live signature".into() };
            }
            if indices.is_empty()
                || indices.windows(2).any(|pair| pair[0] >= pair[1])
                || indices.iter().any(|index| *index >= trs.rules().len())
            {
                return ProcessorResult::Failed {
                    reason: "exact path-order deletion mask is invalid".to_string(),
                };
            }
            // This is a retained CPF reduction-pair certificate.  Ferrum's
            // RPO validator is intentionally search-oriented and is not yet
            // complete for every CPF argument-filter/status combination.
            // Preserve the exact deletion and model here; the reconstructed
            // proof is accepted only after CeTA checks all weak and strict
            // orientation obligations against the live TRS.
            let removed = indices
                .iter()
                .map(|index| trs.rules()[*index].clone())
                .collect();
            let remaining = Trs::new_with_strategy(
                trs.name().map(str::to_owned),
                trs.variables().clone(),
                trs.rules()
                    .iter()
                    .enumerate()
                    .filter(|(index, _)| indices.binary_search(index).is_err())
                    .map(|(_, rule)| rule.clone())
                    .collect(),
                trs.strategy(),
            );
            Some(TopLevelPathOrderRemoval {
                statuses: statuses.clone(),
                precedence: precedence.clone(),
                precedence_ranks: ranks.clone(),
                argument_filter: filter.clone(),
                removed,
                remaining,
            })
        } else if let Some((statuses, precedence, ranks, filter)) = &self.exact_witness {
            checked_top_level_path_order_removal_with_ranks(
                trs, statuses, precedence, ranks, filter,
            )
        } else if self.shared_encoding {
            let arities = trs.arities().into_iter()
                .map(|(symbol, arity)| (symbol.as_str().to_string(), arity))
                .collect::<BTreeMap<_, _>>();
            if arities.is_empty() || arities.len() > self.max_symbols {
                return ProcessorResult::Inapplicable;
            }
            let filters = top_level_path_order_permutation_filter_entries_by_symbol(&arities);
            synthesize_top_level_path_order_shared(
                trs, &arities.keys().cloned().collect::<Vec<_>>(), &filters, self.deadline)
        } else {
            synthesize_top_level_path_order_removal_with_deadline(
                trs,
                self.max_symbols,
                self.deadline,
            )
        };
        let Some(mut removal) = removal else {
            return ProcessorResult::Inapplicable;
        };
        if let Some(indices) = self.exact_removed_rule_indices.as_deref() {
            if indices.is_empty()
                || indices.windows(2).any(|pair| pair[0] >= pair[1])
                || indices.iter().any(|index| *index >= trs.rules().len())
            {
                return ProcessorResult::Failed {
                    reason: "exact path-order deletion mask is invalid".to_string(),
                };
            }
            removal.removed = indices
                .iter()
                .map(|index| trs.rules()[*index].clone())
                .collect();
            removal.remaining = Trs::new_with_strategy(
                trs.name().map(str::to_owned),
                trs.variables().clone(),
                trs.rules()
                    .iter()
                    .enumerate()
                    .filter(|(index, _)| indices.binary_search(index).is_err())
                    .map(|(_, rule)| rule.clone())
                    .collect(),
                trs.strategy(),
            );
        }
        let residual = ProblemState::from_trs(removal.remaining);
        let statuses = removal.statuses;
        let precedence = removal.precedence;
        let precedence_ranks = removal.precedence_ranks;
        let argument_filter = removal.argument_filter;
        let removed = removal.removed;
        let selected_atom =
            if let Some(removed_rule_indices) = self.exact_removed_rule_indices.clone() {
                ProveStrategyProcessor::ExactPathOrderRemoval {
                    source_trs_input_xml: Some(crate::cert::write_trs_input_cpf3(trs)),
                    statuses: statuses.clone(),
                    precedence: precedence.clone(),
                    precedence_ranks: precedence_ranks.clone(),
                    argument_filter: argument_filter.clone(),
                    removed_rule_indices,
                }
                .to_strategy_atom()
            } else if self.shared_encoding {
                ProveStrategyProcessor::SharedPathOrder { max_symbols: self.max_symbols }.to_strategy_atom()
            } else {
                ProveStrategyProcessor::ExactPathOrder {
                    statuses: statuses.clone(),
                    precedence: precedence.clone(),
                    precedence_ranks: precedence_ranks.clone(),
                    argument_filter: argument_filter.clone(),
                }
                .to_strategy_atom()
            };
        ProcessorResult::Applied(
            ProcessorApplication::new(vec![residual], move |children| {
                let [ProblemCertificate::Trs(proof)] =
                    <[ProblemCertificate; 1]>::try_from(children).ok()?
                else {
                    return None;
                };
                if proof.status() != &Status::Terminating {
                    return None;
                }
                Some(ProblemCertificate::Trs(Proof::terminating(vec![
                    ProofStep::PathOrderRuleRemoval {
                        statuses: statuses.clone(),
                        precedence: precedence.clone(),
                        precedence_ranks: precedence_ranks.clone(),
                        argument_filter: argument_filter.clone(),
                        removed: removed.clone(),
                        proof: Box::new(proof),
                    },
                ])))
            })
            .with_selected_atom(selected_atom),
        )
    }
}
