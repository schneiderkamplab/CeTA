use crate::core::{RewriteStrategy, Trs};
use crate::proving::processors::top_level::srs::reverse_srs_rules;
use crate::proving::{Proof, ProofStep, Status};

use super::super::{
    ProblemCertificate, ProblemState, ProcessorApplication, ProcessorResult, WorklistProcessor,
};

pub struct StringReversalProcessor;

impl WorklistProcessor for StringReversalProcessor {
    fn name(&self) -> &'static str {
        "string-reversal"
    }

    fn apply(&self, state: &ProblemState) -> ProcessorResult {
        let (trs, weak_rules, relative) = match state {
            ProblemState::Trs(trs) | ProblemState::Srs(trs) => (trs, &[][..], false),
            ProblemState::RelativeSrs(relative) => (relative.strict(), relative.weak_rules(), true),
            _ => return ProcessorResult::Inapplicable,
        };
        let Some(reversed_rules) = reverse_srs_rules(trs.rules()) else {
            return ProcessorResult::Inapplicable;
        };
        let Some(reversed_weak_rules) = reverse_srs_rules(weak_rules) else {
            return ProcessorResult::Inapplicable;
        };
        let reversed_strategy = if trs.strategy() == RewriteStrategy::Innermost {
            RewriteStrategy::Full
        } else {
            trs.strategy()
        };
        let original_strategy = trs.strategy();
        let reversed = Trs::new_with_strategy(
            trs.name().map(str::to_string),
            trs.variables().clone(),
            reversed_rules.clone(),
            reversed_strategy,
        );
        // Preserve the input problem kind.  A unary TRS is not thereby an
        // SRS transformation target: changing the variant here loses the
        // TRS continuation (notably switchInnermost and DP) and changes its
        // canonical oracle key.
        let residual = if relative {
            ProblemState::from_relative(crate::core::RelativeTrs::new(
                reversed,
                reversed_weak_rules.clone(),
            ))
        } else {
            match state {
                ProblemState::Srs(_) => ProblemState::Srs(reversed),
                ProblemState::Trs(_) => ProblemState::Trs(reversed),
                _ => unreachable!(),
            }
        };
        ProcessorResult::Applied(ProcessorApplication::new(vec![residual], move |children| {
            let [ProblemCertificate::Trs(proof)] =
                <[ProblemCertificate; 1]>::try_from(children).ok()?
            else {
                return None;
            };
            let status = proof.status().clone();
            if status == Status::Unknown
                || status == Status::Nonterminating
                    && reversed_strategy == RewriteStrategy::Full
                    && original_strategy == RewriteStrategy::Innermost
            {
                return None;
            }
            Some(ProblemCertificate::Trs(Proof::with_status(
                status,
                vec![ProofStep::StringReversal {
                    reversed_rules: reversed_rules.clone(),
                    reversed_weak_rules: reversed_weak_rules.clone(),
                    proof: Box::new(proof),
                }],
            )))
        }))
    }
}

#[cfg(test)]
mod tests {
    use std::collections::BTreeSet;

    use crate::core::{RelativeTrs, RewriteRule, Term, Trs, Variable};

    use super::*;

    #[test]
    fn relative_reversal_preserves_strict_and_weak_components() {
        let variable = Variable::new("x");
        let strict = RewriteRule::new(
            Term::app("a", vec![Term::app("b", vec![Term::Var(variable.clone())])]),
            Term::app("c", vec![Term::Var(variable.clone())]),
        );
        let weak = RewriteRule::new(
            Term::app("d", vec![Term::app("e", vec![Term::Var(variable.clone())])]),
            Term::app("f", vec![Term::Var(variable.clone())]),
        );
        let relative = RelativeTrs::new(
            Trs::new(None, BTreeSet::from([variable]), vec![strict]),
            vec![weak],
        );

        let ProcessorResult::Applied(application) =
            StringReversalProcessor.apply(&ProblemState::RelativeSrs(relative))
        else {
            panic!("relative SRS reversal should apply");
        };
        let (residuals, _) = application.into_parts();
        let [ProblemState::RelativeSrs(reversed)] = residuals.as_slice() else {
            panic!("reversal must leave a relative SRS obligation");
        };

        assert_eq!(
            reversed.strict().rules()[0].lhs(),
            &Term::app("b", vec![Term::app("a", vec![Term::var("x")])],)
        );
        assert_eq!(
            reversed.weak_rules()[0].lhs(),
            &Term::app("e", vec![Term::app("d", vec![Term::var("x")])],)
        );
    }
}
