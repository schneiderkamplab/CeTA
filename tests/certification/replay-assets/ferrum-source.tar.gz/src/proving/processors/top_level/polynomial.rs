use std::time::Instant;

use std::collections::{BTreeMap, BTreeSet};

use crate::core::{CsrTrs, RewriteRule, Symbol, Term, Trs, Variable};
use crate::llm::{LinearPolynomial, LinearPolynomialInterpretations};
use crate::proving::engine::{ProveOptions, ProveStrategyProcessor};
use crate::proving::processors::top_level::smt::{
    check_build, command_exists, parse_integer_values, run_script, sanitize_identifier,
};
use crate::proving::runtime::write_progress_event;
use crate::proving::{Proof, ProofStep, Status};
use crate::proving::{
    linear_polynomial_is_monotone_for_trs, linear_polynomial_strictly_orients_rule,
    linear_polynomial_weakly_orients_rule,
};

use super::super::{
    ProblemCertificate, ProblemState, ProcessorApplication, ProcessorResult, WorklistProcessor,
};

pub(crate) fn exact_linear_polynomial_interpretations(
    witness: &[(String, i64, Vec<i64>)],
) -> Option<LinearPolynomialInterpretations> {
    let interpretations = witness
        .iter()
        .map(|(name, constant, coefficients)| {
            (
                name.clone(),
                LinearPolynomial {
                    constant: *constant,
                    coefficients: coefficients.clone(),
                },
            )
        })
        .collect::<LinearPolynomialInterpretations>();
    (interpretations.len() == witness.len()).then_some(interpretations)
}

#[cfg(test)]
pub(crate) fn synthesize_top_level_polynomial_removal_with_smt(
    trs: &Trs,
    options: &ProveOptions,
    deadline: Option<Instant>,
) -> Option<TopLevelPolynomialRemoval> {
    synthesize_top_level_polynomial_removal_with_smt_candidate(trs, options, 0, deadline)
}

pub(crate) fn synthesize_top_level_polynomial_removal_with_smt_candidate(
    trs: &Trs,
    options: &ProveOptions,
    candidate_index: usize,
    deadline: Option<Instant>,
) -> Option<TopLevelPolynomialRemoval> {
    let arities = trs
        .arities()
        .into_iter()
        .map(|(symbol, arity)| (symbol.as_str().to_string(), arity))
        .collect::<BTreeMap<_, _>>();
    if arities.is_empty()
        || arities.len() > options.max_polynomial_symbols
        || options.max_polynomial_constant < 0
        || options.max_polynomial_coefficient < 1
    {
        return None;
    }
    let solver = command_exists("z3")
        .then_some("z3")
        .or_else(|| command_exists("cvc5").then_some("cvc5"))?;
    let script = top_level_smt_polynomial_script(
        trs,
        candidate_index,
        &arities,
        options.max_polynomial_constant,
        options.max_polynomial_coefficient,
        deadline,
    )?;
    let stdout = run_script(&script, solver, deadline)?;
    if !stdout.contains("sat") || stdout.contains("unsat") {
        write_progress_event(
            "top-level-rule-removal",
            "rejected",
            "smt-polynomial",
            0,
            "smt_calls=1 reason=unsat-or-timeout",
        );
        return None;
    }
    let interpretations = top_level_parse_smt_model(&stdout, &arities)?;
    let removal = top_level_polynomial_removal_from_interpretations(trs, interpretations);
    write_progress_event(
        "top-level-rule-removal",
        if removal.is_some() {
            "selected"
        } else {
            "rejected"
        },
        "smt-polynomial",
        0,
        &format!(
            "smt_calls=1 reason={}",
            if removal.is_some() {
                "checked-removal"
            } else {
                "model-failed-check"
            }
        ),
    );
    removal
}

pub(crate) fn synthesize_top_level_polynomial_removal_with_smt_target(
    trs: &Trs,
    options: &ProveOptions,
    target_strict_rule_indices: &[usize],
    deadline: Option<Instant>,
) -> Option<TopLevelPolynomialRemoval> {
    let arities = trs
        .arities()
        .into_iter()
        .map(|(symbol, arity)| (symbol.as_str().to_string(), arity))
        .collect::<BTreeMap<_, _>>();
    if arities.is_empty()
        || arities.len() > options.max_polynomial_symbols
        || options.max_polynomial_constant < 0
        || options.max_polynomial_coefficient < 1
    {
        return None;
    }
    let solver = command_exists("z3")
        .then_some("z3")
        .or_else(|| command_exists("cvc5").then_some("cvc5"))?;
    let script = top_level_smt_polynomial_script_with_strict_prefix(
        trs,
        trs.rules().len(),
        None,
        Some(target_strict_rule_indices),
        None,
        &arities,
        options.max_polynomial_constant,
        options.max_polynomial_coefficient,
        deadline,
    )?;
    let stdout = run_script(&script, solver, deadline)?;
    if !stdout.contains("sat") || stdout.contains("unsat") {
        return None;
    }
    let interpretations = top_level_parse_smt_model(&stdout, &arities)?;
    top_level_polynomial_removal_from_interpretations(trs, interpretations)
}

pub(crate) fn synthesize_top_level_polynomial_removal_with_minimum_deletion(
    trs: &Trs,
    options: &ProveOptions,
    min_delete: usize,
    deadline: Option<Instant>,
) -> Option<TopLevelPolynomialRemoval> {
    let arities = trs
        .arities()
        .into_iter()
        .map(|(symbol, arity)| (symbol.as_str().to_string(), arity))
        .collect::<BTreeMap<_, _>>();
    if min_delete == 0
        || min_delete > trs.rules().len()
        || arities.is_empty()
        || arities.len() > options.max_polynomial_symbols
        || options.max_polynomial_constant < 0
        || options.max_polynomial_coefficient < 1
    {
        return None;
    }
    let solver = command_exists("z3")
        .then_some("z3")
        .or_else(|| command_exists("cvc5").then_some("cvc5"))?;
    let script = top_level_smt_polynomial_script_with_strict_prefix(
        trs,
        trs.rules().len(),
        None,
        None,
        Some(min_delete),
        &arities,
        options.max_polynomial_constant,
        options.max_polynomial_coefficient,
        deadline,
    )?;
    let stdout = run_script(&script, solver, deadline)?;
    if !stdout.contains("sat") || stdout.contains("unsat") {
        return None;
    }
    let interpretations = top_level_parse_smt_model(&stdout, &arities)?;
    let removal = top_level_polynomial_removal_from_interpretations(trs, interpretations)?;
    (removal.removed.len() >= min_delete).then_some(removal)
}

pub(crate) fn top_level_polynomial_removal_from_interpretations(
    trs: &Trs,
    interpretations: crate::llm::LinearPolynomialInterpretations,
) -> Option<TopLevelPolynomialRemoval> {
    // A top-level rule-removal proof uses a monotone reduction pair: unlike a
    // usable-rules DP step, every argument position is a context in which a
    // strict rule may be rewritten.  Exact/oracle witnesses used to bypass
    // the monotonicity constraints imposed by the SMT generator, allowing a
    // zero coefficient to reach CPF where CeTA necessarily rejected it.
    if !linear_polynomial_is_monotone_for_trs(trs, &interpretations) {
        return None;
    }
    let mut removed = Vec::new();
    let mut remaining = Vec::new();
    for rule in trs.rules() {
        if !linear_polynomial_weakly_orients_rule(rule, &interpretations) {
            return None;
        }
        if linear_polynomial_strictly_orients_rule(rule, &interpretations) {
            removed.push(rule.clone());
        } else {
            remaining.push(rule.clone());
        }
    }
    if removed.is_empty() || remaining.len() == trs.rules().len() {
        return None;
    }
    Some(TopLevelPolynomialRemoval {
        interpretations: interpretations
            .into_iter()
            .map(|(name, interpretation)| {
                (name, interpretation.constant, interpretation.coefficients)
            })
            .collect(),
        removed,
        remaining: Trs::new_with_strategy(
            trs.name().map(str::to_string),
            trs.variables().clone(),
            remaining,
            trs.strategy(),
        ),
    })
}

fn top_level_smt_polynomial_script(
    trs: &Trs,
    candidate_index: usize,
    arities: &BTreeMap<String, usize>,
    max_constant: i64,
    max_coefficient: i64,
    deadline: Option<Instant>,
) -> Option<String> {
    top_level_smt_polynomial_script_with_strict_prefix(
        trs,
        trs.rules().len(),
        candidate_index.checked_sub(1),
        None,
        None,
        arities,
        max_constant,
        max_coefficient,
        deadline,
    )
}

fn top_level_smt_polynomial_script_with_strict_prefix(
    trs: &Trs,
    strict_rule_count: usize,
    required_strict_rule: Option<usize>,
    target_strict_rule_indices: Option<&[usize]>,
    minimum_strict_rules: Option<usize>,
    arities: &BTreeMap<String, usize>,
    max_constant: i64,
    max_coefficient: i64,
    deadline: Option<Instant>,
) -> Option<String> {
    let mut script = String::new();
    script.push_str("(set-logic QF_NIA)\n");
    for (symbol, arity) in arities {
        check_build(&script, deadline)?;
        script.push_str(&format!("(declare-const {} Int)\n", top_smt_c(symbol)));
        script.push_str(&format!(
            "(assert (and (>= {} 0) (<= {} {})))\n",
            top_smt_c(symbol),
            top_smt_c(symbol),
            max_constant
        ));
        for index in 0..*arity {
            script.push_str(&format!(
                "(declare-const {} Int)\n",
                top_smt_a(symbol, index)
            ));
            script.push_str(&format!(
                "(assert (and (>= {} 1) (<= {} {})))\n",
                top_smt_a(symbol, index),
                top_smt_a(symbol, index),
                max_coefficient
            ));
        }
    }
    let mut strict_terms = Vec::new();
    for (index, rule) in trs.rules().iter().enumerate() {
        check_build(&script, deadline)?;
        let lhs = top_smt_interpret(rule.lhs());
        let rhs = top_smt_interpret(rule.rhs());
        top_smt_push_weak(&mut script, &lhs, &rhs);
        if index < strict_rule_count {
            strict_terms.push(top_smt_strict(&lhs, &rhs));
        }
    }
    if required_strict_rule.is_some_and(|index| index >= strict_terms.len()) {
        return None;
    }
    if target_strict_rule_indices.is_some() && minimum_strict_rules.is_some() {
        return None;
    }
    if let Some(target_indices) = target_strict_rule_indices {
        let target_indices = target_indices.iter().copied().collect::<BTreeSet<_>>();
        if target_indices.is_empty()
            || target_indices
                .iter()
                .any(|index| *index >= strict_terms.len())
        {
            return None;
        }
        for (index, strict) in strict_terms.iter().enumerate() {
            if target_indices.contains(&index) {
                script.push_str(&format!("(assert {strict})\n"));
            } else {
                script.push_str(&format!("(assert (not {strict}))\n"));
            }
        }
    } else if let Some(minimum) = minimum_strict_rules {
        if minimum == 0 || minimum > strict_terms.len() {
            return None;
        }
        let score = strict_terms
            .iter()
            .map(|strict| format!("(ite {strict} 1 0)"))
            .collect::<Vec<_>>()
            .join(" ");
        script.push_str(&format!("(assert (>= (+ {score}) {minimum}))\n"));
    } else if strict_terms.is_empty() {
        script.push_str("(assert false)\n");
    } else if let Some(index) = required_strict_rule {
        script.push_str(&format!("(assert {})\n", strict_terms[index]));
    } else if strict_terms.len() == 1 {
        script.push_str(&format!("(assert {})\n", strict_terms[0]));
    } else {
        script.push_str(&format!("(assert (or {}))\n", strict_terms.join(" ")));
    }
    script.push_str("(check-sat)\n(get-model)\n");
    check_build(&script, deadline)?;
    Some(script)
}

pub(crate) fn csr_smt_polynomial_script(
    csr: &CsrTrs,
    arities: &BTreeMap<String, usize>,
    max_constant: i64,
    max_coefficient: i64,
    required_strict_rule: Option<usize>,
    target_strict_rule_indices: Option<&[usize]>,
    minimum_strict_rules: Option<usize>,
    deadline: Option<Instant>,
) -> Option<String> {
    let mut script = String::new();
    script.push_str("(set-logic QF_NIA)\n");
    script.push_str("(set-option :opt.priority lex)\n");
    for (symbol, arity) in arities {
        check_build(&script, deadline)?;
        script.push_str(&format!("(declare-const {} Int)\n", top_smt_c(symbol)));
        script.push_str(&format!(
            "(assert (and (>= {} 0) (<= {} {})))\n",
            top_smt_c(symbol),
            top_smt_c(symbol),
            max_constant
        ));
        let core_symbol = Symbol::new(symbol);
        for index in 0..*arity {
            let coefficient = top_smt_a(symbol, index);
            let lower_bound = i64::from(csr.replacement_map().is_allowed(&core_symbol, index));
            script.push_str(&format!("(declare-const {coefficient} Int)\n"));
            script.push_str(&format!(
                "(assert (and (>= {coefficient} {lower_bound}) (<= {coefficient} {max_coefficient})))\n"
            ));
        }
    }
    let mut strict_terms = Vec::new();
    for rule in csr.rules() {
        check_build(&script, deadline)?;
        let lhs = top_smt_interpret(rule.lhs());
        let rhs = top_smt_interpret(rule.rhs());
        top_smt_push_weak(&mut script, &lhs, &rhs);
        strict_terms.push(top_smt_strict(&lhs, &rhs));
    }
    if required_strict_rule.is_some_and(|index| index >= strict_terms.len()) {
        return None;
    }
    if target_strict_rule_indices.is_some() && minimum_strict_rules.is_some() {
        return None;
    }
    if let Some(target_indices) = target_strict_rule_indices {
        let target_indices = target_indices.iter().copied().collect::<BTreeSet<_>>();
        if target_indices.is_empty()
            || target_indices
                .iter()
                .any(|index| *index >= strict_terms.len())
        {
            return None;
        }
        for (index, strict) in strict_terms.iter().enumerate() {
            if target_indices.contains(&index) {
                script.push_str(&format!("(assert {strict})\n"));
            } else {
                script.push_str(&format!("(assert (not {strict}))\n"));
            }
        }
    } else if let Some(minimum) = minimum_strict_rules {
        if minimum == 0 || minimum > strict_terms.len() {
            return None;
        }
        let score = strict_terms
            .iter()
            .map(|strict| format!("(ite {strict} 1 0)"))
            .collect::<Vec<_>>()
            .join(" ");
        script.push_str(&format!("(assert (>= (+ {score}) {minimum}))\n"));
    } else if strict_terms.is_empty() {
        script.push_str("(assert false)\n");
    } else if let Some(index) = required_strict_rule {
        script.push_str(&format!("(assert {})\n", strict_terms[index]));
    } else {
        script.push_str(&format!("(assert (or {}))\n", strict_terms.join(" ")));
        let score = strict_terms
            .iter()
            .map(|strict| format!("(ite {strict} 1 0)"))
            .collect::<Vec<_>>()
            .join(" ");
        script.push_str(&format!("(maximize (+ {score}))\n"));
    }
    script.push_str("(check-sat)\n(get-model)\n");
    check_build(&script, deadline)?;
    Some(script)
}

#[derive(Clone, Debug)]
struct TopSmtForm {
    constant: String,
    coefficients: BTreeMap<Variable, String>,
}

fn top_smt_interpret(term: &Term) -> TopSmtForm {
    match term {
        Term::Var(variable) => TopSmtForm {
            constant: "0".to_string(),
            coefficients: BTreeMap::from([(variable.clone(), "1".to_string())]),
        },
        Term::App { symbol, args } => {
            let symbol = symbol.as_str();
            let mut form = TopSmtForm {
                constant: top_smt_c(symbol),
                coefficients: BTreeMap::new(),
            };
            for (index, arg) in args.iter().enumerate() {
                let arg_form = top_smt_interpret(arg);
                let coefficient = top_smt_a(symbol, index);
                form.constant = top_smt_add(
                    &form.constant,
                    &top_smt_mul(&coefficient, &arg_form.constant),
                );
                for (variable, value) in arg_form.coefficients {
                    let scaled = top_smt_mul(&coefficient, &value);
                    form.coefficients
                        .entry(variable)
                        .and_modify(|old| *old = top_smt_add(old, &scaled))
                        .or_insert(scaled);
                }
            }
            form
        }
    }
}

fn top_smt_push_weak(script: &mut String, lhs: &TopSmtForm, rhs: &TopSmtForm) {
    script.push_str(&format!(
        "(assert (>= {} {}))\n",
        lhs.constant, rhs.constant
    ));
    let variables = lhs
        .coefficients
        .keys()
        .chain(rhs.coefficients.keys())
        .cloned()
        .collect::<BTreeSet<_>>();
    for variable in variables {
        let left = lhs
            .coefficients
            .get(&variable)
            .cloned()
            .unwrap_or_else(|| "0".to_string());
        let right = rhs
            .coefficients
            .get(&variable)
            .cloned()
            .unwrap_or_else(|| "0".to_string());
        script.push_str(&format!("(assert (>= {left} {right}))\n"));
    }
}

fn top_smt_strict(lhs: &TopSmtForm, rhs: &TopSmtForm) -> String {
    format!("(> {} {})", lhs.constant, rhs.constant)
}

pub(crate) fn top_level_parse_smt_model(
    output: &str,
    arities: &BTreeMap<String, usize>,
) -> Option<crate::llm::LinearPolynomialInterpretations> {
    let values = parse_integer_values(output)?;
    let mut interpretations = BTreeMap::new();
    for (symbol, arity) in arities {
        let constant = values.get(&top_smt_c(symbol)).copied().unwrap_or(0);
        let coefficients = (0..*arity)
            .map(|index| values.get(&top_smt_a(symbol, index)).copied().unwrap_or(1))
            .collect::<Vec<_>>();
        interpretations.insert(
            symbol.clone(),
            crate::llm::LinearPolynomial {
                constant,
                coefficients,
            },
        );
    }
    Some(interpretations)
}

fn top_smt_c(symbol: &str) -> String {
    format!("tc_{}", sanitize_identifier(symbol))
}

fn top_smt_a(symbol: &str, index: usize) -> String {
    format!("ta_{}_{}", sanitize_identifier(symbol), index)
}

fn top_smt_add(lhs: &str, rhs: &str) -> String {
    if lhs == "0" {
        rhs.to_string()
    } else if rhs == "0" {
        lhs.to_string()
    } else {
        format!("(+ {lhs} {rhs})")
    }
}

fn top_smt_mul(lhs: &str, rhs: &str) -> String {
    if lhs == "1" {
        rhs.to_string()
    } else if rhs == "1" {
        lhs.to_string()
    } else if lhs == "0" || rhs == "0" {
        "0".to_string()
    } else {
        format!("(* {lhs} {rhs})")
    }
}

pub(crate) struct TopLevelPolynomialRemoval {
    pub(crate) interpretations: Vec<(String, i64, Vec<i64>)>,
    pub(crate) removed: Vec<RewriteRule>,
    pub(crate) remaining: Trs,
}

pub struct PolynomialRuleRemovalProcessor {
    pub options: ProveOptions,
    pub exact_interpretation: Option<Vec<(String, i64, Vec<i64>)>>,
    pub target_strict_rule_indices: Option<Vec<usize>>,
    pub exact_removed_rule_indices: Option<Vec<usize>>,
    pub candidate_index: usize,
    pub deadline: Option<Instant>,
}

pub struct MinimumDeletionPolynomialRuleRemovalProcessor {
    pub options: ProveOptions,
    pub min_delete: usize,
    pub residual_budget: usize,
    pub deadline: Option<Instant>,
}

impl WorklistProcessor for MinimumDeletionPolynomialRuleRemovalProcessor {
    fn name(&self) -> &'static str {
        "minimum-deletion-polynomial-rule-removal"
    }

    fn apply(&self, state: &ProblemState) -> ProcessorResult {
        let trs = match state {
            ProblemState::Trs(trs) | ProblemState::Srs(trs) => trs,
            _ => return ProcessorResult::Inapplicable,
        };
        if self.residual_budget != 1 {
            return ProcessorResult::Failed {
                reason: "top-level polynomial residual budget must be one".to_string(),
            };
        }
        let Some(removal) = synthesize_top_level_polynomial_removal_with_minimum_deletion(
            trs,
            &self.options,
            self.min_delete,
            self.deadline,
        ) else {
            return ProcessorResult::Inapplicable;
        };
        let residual = ProblemState::from_trs(removal.remaining);
        let interpretations = removal.interpretations;
        let removed = removal.removed;
        let selected_atom = ProveStrategyProcessor::MinimumDeletionLinearPolynomial {
            max_constant: self.options.max_polynomial_constant,
            max_coefficient: self.options.max_polynomial_coefficient,
            max_symbols: Some(self.options.max_polynomial_symbols),
            max_arity: Some(self.options.max_polynomial_arity),
            min_delete: self.min_delete,
            residual_budget: self.residual_budget,
        }
        .to_strategy_atom();
        ProcessorResult::Applied(
            ProcessorApplication::new(vec![residual], move |children| {
                let [ProblemCertificate::Trs(proof)] =
                    <[ProblemCertificate; 1]>::try_from(children).ok()?
                else {
                    return None;
                };
                if proof.status() != &Status::Terminating {
                    return None;
                }
                Some(ProblemCertificate::Trs(Proof::terminating(vec![
                    ProofStep::PolynomialRuleRemoval {
                        interpretations: interpretations.clone(),
                        removed: removed.clone(),
                        proof: Box::new(proof),
                    },
                ])))
            })
            .with_selected_atom(selected_atom),
        )
    }
}

impl WorklistProcessor for PolynomialRuleRemovalProcessor {
    fn name(&self) -> &'static str {
        "polynomial-rule-removal"
    }

    fn apply(&self, state: &ProblemState) -> ProcessorResult {
        let trs = match state {
            ProblemState::Trs(trs) | ProblemState::Srs(trs) => trs,
            _ => return ProcessorResult::Inapplicable,
        };
        let removal = if let Some(witness) = self.exact_interpretation.as_deref() {
            let arities = trs.arities();
            let witness = witness.iter().map(|(name, constant, coefficients)| {
                let quoted = format!("|{name}|");
                let renamed = if name.as_bytes().first().is_some_and(u8::is_ascii_digit)
                    && !arities.keys().any(|symbol| symbol.as_str() == name)
                    && arities.iter().any(|(symbol, arity)| symbol.as_str() == quoted && *arity == coefficients.len()) {
                    quoted
                } else { name.clone() };
                (renamed, *constant, coefficients.clone())
            }).collect::<Vec<_>>();
            let Some(interpretations) = exact_linear_polynomial_interpretations(&witness) else {
                return ProcessorResult::Failed {
                    reason: "exact polynomial witness contains duplicate symbols".to_string(),
                };
            };
            top_level_polynomial_removal_from_interpretations(trs, interpretations)
        } else if let Some(target) = self.target_strict_rule_indices.as_deref() {
            synthesize_top_level_polynomial_removal_with_smt_target(
                trs,
                &self.options,
                target,
                self.deadline,
            )
        } else {
            synthesize_top_level_polynomial_removal_with_smt_candidate(
                trs,
                &self.options,
                self.candidate_index,
                self.deadline,
            )
        };
        let Some(mut removal) = removal else {
            return ProcessorResult::Inapplicable;
        };
        if let Some(indices) = self.exact_removed_rule_indices.as_deref() {
            if indices.is_empty()
                || indices.windows(2).any(|pair| pair[0] >= pair[1])
                || indices.iter().any(|index| *index >= trs.rules().len())
            {
                return ProcessorResult::Failed {
                    reason: "exact polynomial deletion mask is invalid".to_string(),
                };
            }
            let selected = indices
                .iter()
                .map(|index| trs.rules()[*index].clone())
                .collect::<Vec<_>>();
            if !selected.iter().all(|rule| removal.removed.contains(rule)) {
                return ProcessorResult::Failed {
                    reason: "exact polynomial deletion mask contains a non-strict rule".to_string(),
                };
            }
            removal.removed = selected;
            removal.remaining = Trs::new_with_strategy(
                trs.name().map(str::to_owned),
                trs.variables().clone(),
                trs.rules()
                    .iter()
                    .enumerate()
                    .filter(|(index, _)| indices.binary_search(index).is_err())
                    .map(|(_, rule)| rule.clone())
                    .collect(),
                trs.strategy(),
            );
        }
        let residual = ProblemState::from_trs(removal.remaining);
        let interpretations = removal.interpretations;
        // A successful search recipe is not a replay witness.  In particular,
        // an SMT solver may return a different valid model for the same
        // `candidate_index`; that model can delete a different rule set and
        // strand every state-local continuation recorded for the old child.
        // Expose the exact, already validated interpretation and deletion mask
        // for every applied transformation so runtime guidance has a direct
        // state/action/child bijection.
        let removed_rule_indices = trs
            .rules()
            .iter()
            .enumerate()
            .filter_map(|(index, rule)| removal.removed.contains(rule).then_some(index))
            .collect();
        let selected_atom = ProveStrategyProcessor::ExactLinearPolynomialRemoval {
            interpretation: interpretations.clone(),
            removed_rule_indices,
        }
        .to_strategy_atom();
        let removed = removal.removed;
        ProcessorResult::Applied(
            ProcessorApplication::new(vec![residual], move |children| {
                let [ProblemCertificate::Trs(proof)] =
                    <[ProblemCertificate; 1]>::try_from(children).ok()?
                else {
                    return None;
                };
                if proof.status() != &Status::Terminating {
                    return None;
                }
                Some(ProblemCertificate::Trs(Proof::terminating(vec![
                    ProofStep::PolynomialRuleRemoval {
                        interpretations: interpretations.clone(),
                        removed: removed.clone(),
                        proof: Box::new(proof),
                    },
                ])))
            })
            .with_selected_atom(selected_atom),
        )
    }
}

#[cfg(test)]
mod tests {
    use std::collections::BTreeSet;

    use super::*;
    use crate::core::{Term, Variable};
    use crate::proving::NonterminationProof;

    #[test]
    fn exact_polynomial_preserves_unambiguous_numeric_constant_values() {
        let trs = Trs::new(None, BTreeSet::new(), vec![RewriteRule::new(
            Term::app("f", vec![Term::app("|0|", vec![])]),
            Term::app("g", vec![Term::app("|0|", vec![])]))]);
        let result = PolynomialRuleRemovalProcessor {
            options: ProveOptions::default(),
            exact_interpretation: Some(vec![("f".into(), 0, vec![2]),
                ("g".into(), 0, vec![1]), ("0".into(), 1, vec![])]),
            target_strict_rule_indices: None, exact_removed_rule_indices: None,
            candidate_index: 0, deadline: None,
        }.apply(&ProblemState::Trs(trs));
        let ProcessorResult::Applied(application) = result else { panic!("strict rule must be removed") };
        let (ProblemState::Trs(child) | ProblemState::Srs(child)) = &application.residuals[0] else { panic!() };
        assert!(child.rules().is_empty());
    }

    #[test]
    fn termination_removal_rejects_a_nonterminating_residual_certificate() {
        let variables = BTreeSet::from([Variable::new("x")]);
        let trs = Trs::new(
            None,
            variables,
            vec![
                RewriteRule::new(
                    Term::app("f", vec![Term::var("x")]),
                    Term::app("g", vec![Term::var("x")]),
                ),
                RewriteRule::new(
                    Term::app("h", vec![Term::var("x")]),
                    Term::app("h", vec![Term::var("x")]),
                ),
            ],
        );
        let result = PolynomialRuleRemovalProcessor {
            options: ProveOptions::default(),
            exact_interpretation: Some(vec![
                ("f".to_string(), 1, vec![1]),
                ("g".to_string(), 0, vec![1]),
                ("h".to_string(), 0, vec![1]),
            ]),
            target_strict_rule_indices: None,
            exact_removed_rule_indices: None,
            candidate_index: 0,
            deadline: None,
        }
        .apply(&ProblemState::Trs(trs));
        let ProcessorResult::Applied(application) = result else {
            panic!("the exact interpretation must remove f(x) -> g(x)")
        };
        assert!(
            application
                .selected_atom()
                .is_some_and(|atom| atom.starts_with("exact-poly-removal(")),
            "successful rule removal must publish its deterministic witness"
        );
        let child = ProblemCertificate::Trs(Proof::nonterminating(
            NonterminationProof::VariableConditionViolated,
        ));
        assert!(application.reconstruct(vec![child]).is_none());
    }

    #[test]
    fn rule_removal_reclassifies_a_string_shaped_residual() {
        let variables = BTreeSet::from([Variable::new("x"), Variable::new("y")]);
        let trs = Trs::new(
            None,
            variables,
            vec![
                RewriteRule::new(
                    Term::app("p", vec![Term::var("x"), Term::var("y")]),
                    Term::var("x"),
                ),
                RewriteRule::new(Term::app("a", vec![Term::var("x")]), Term::var("x")),
            ],
        );
        assert!(trs.srs_rules().is_none());
        let result = PolynomialRuleRemovalProcessor {
            options: ProveOptions::default(),
            exact_interpretation: Some(vec![
                ("p".to_string(), 1, vec![1, 1]),
                ("a".to_string(), 0, vec![1]),
            ]),
            target_strict_rule_indices: None,
            exact_removed_rule_indices: None,
            candidate_index: 0,
            deadline: None,
        }
        .apply(&ProblemState::Trs(trs));
        let ProcessorResult::Applied(application) = result else {
            panic!("the exact interpretation must remove the binary rule")
        };
        assert!(matches!(
            application.residuals.as_slice(),
            [ProblemState::Srs(_)]
        ));
    }

    #[test]
    fn exact_top_level_polynomial_rejects_zero_context_coefficients() {
        let variables = BTreeSet::from([Variable::new("x"), Variable::new("y")]);
        let trs = Trs::new(
            None,
            variables,
            vec![RewriteRule::new(
                Term::app("f", vec![Term::var("x"), Term::var("y")]),
                Term::var("x"),
            )],
        );
        let interpretations = LinearPolynomialInterpretations::from([(
            "f".to_string(),
            LinearPolynomial {
                constant: 1,
                coefficients: vec![1, 0],
            },
        )]);

        assert!(linear_polynomial_strictly_orients_rule(
            &trs.rules()[0],
            &interpretations
        ));
        assert!(top_level_polynomial_removal_from_interpretations(&trs, interpretations).is_none());
    }
}
