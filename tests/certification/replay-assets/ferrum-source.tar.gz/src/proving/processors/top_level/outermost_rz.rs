use crate::core::RewriteStrategy;
use crate::proving::raffelsieper_zantema_transformation;
use crate::proving::{Proof, ProofStep, Status};

use super::super::{
    ProblemCertificate, ProblemState, ProcessorApplication, ProcessorResult, WorklistProcessor,
};

pub struct OutermostRaffelsieperZantemaProcessor;

impl WorklistProcessor for OutermostRaffelsieperZantemaProcessor {
    fn name(&self) -> &'static str {
        "outermost-raffelsieper-zantema"
    }

    fn apply(&self, state: &ProblemState) -> ProcessorResult {
        let ProblemState::Trs(trs) = state else {
            return ProcessorResult::Inapplicable;
        };
        if trs.strategy() != RewriteStrategy::Outermost {
            return ProcessorResult::Inapplicable;
        }
        let Some(transformation) = raffelsieper_zantema_transformation(trs) else {
            return ProcessorResult::Inapplicable;
        };
        let transformed_rules = transformation.transformed.rules().to_vec();
        ProcessorResult::Applied(ProcessorApplication::new(
            vec![ProblemState::from_trs(transformation.transformed)],
            move |children| {
                let [ProblemCertificate::Trs(proof)] =
                    <[ProblemCertificate; 1]>::try_from(children).ok()?
                else {
                    return None;
                };
                if proof.status() != &Status::Terminating {
                    return None;
                }
                Some(ProblemCertificate::Trs(Proof::terminating(vec![
                    ProofStep::OutermostRaffelsieperZantemaTransformation {
                        top_symbol: transformation.top_symbol.clone(),
                        up_symbol: transformation.up_symbol.clone(),
                        down_symbol: transformation.down_symbol.clone(),
                        block_symbol: transformation.block_symbol.clone(),
                        ground_constant: transformation.ground_constant.clone(),
                        flat_symbols: transformation.flat_symbols.clone(),
                        non_redex_patterns: transformation.non_redex_patterns.clone(),
                        transformed_rules: transformed_rules.clone(),
                        proof: Box::new(proof),
                    },
                ])))
            },
        ))
    }
}
