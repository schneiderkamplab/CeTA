use crate::parsing::{CpfInputProblem, parse_cpf_input};
use crate::proving::processors::dp::{portable_trs_isomorphism, same_rule_multiset};
use crate::proving::{NonterminationProof, Proof, ProofStep};

use super::super::{
    ProblemCertificate, ProblemState, ProcessorApplication, ProcessorResult, WorklistProcessor,
};

/// Insert a complete twice-certified CPF termination continuation at the
/// exact TRS obligation from which it was extracted.
pub struct ExactTerminationProofProcessor {
    pub source_trs_input_xml: String,
    pub termination_proof_xml: String,
}

/// Insert a complete twice-certified CPF nontermination continuation at the
/// exact TRS obligation from which it was extracted.
pub struct ExactNonterminationProofProcessor {
    pub source_trs_input_xml: String,
    pub nontermination_proof_xml: String,
}

/// Full rewriting is monotone in its rule relation: a checked infinite
/// reduction of a literal rule subset is also one of the parent. This does
/// not silently extend to innermost rewriting, where deleting rules can
/// change normal-form side conditions.
pub(super) fn apply_nontermination_rule_removal(
    state: &ProblemState, source: &str, residual: &str,
) -> ProcessorResult {
    use crate::core::{RewriteStrategy, Trs};
    let live = match state {
        ProblemState::Trs(trs) | ProblemState::Srs(trs) => trs,
        _ => return ProcessorResult::Inapplicable,
    };
    let (Ok(CpfInputProblem::Trs(source)), Ok(CpfInputProblem::Trs(residual))) =
        (parse_cpf_input(None, source), parse_cpf_input(None, residual)) else {
            return ProcessorResult::Inapplicable;
        };
    if live.strategy() != RewriteStrategy::Full || source.strategy() != RewriteStrategy::Full
        || residual.strategy() != RewriteStrategy::Full {
        return ProcessorResult::Inapplicable;
    }
    let Some((symbols, _)) = portable_trs_isomorphism(&source, live) else {
        return ProcessorResult::Inapplicable;
    };
    let mut available = live.rules().to_vec();
    let mut retained = Vec::new();
    for rule in residual.rules() {
        let translated = crate::standardize::translate_rule_symbols(rule, &symbols);
        let Some(index) = available.iter().position(|candidate| same_rule_multiset(
            std::slice::from_ref(candidate), std::slice::from_ref(&translated),
        )) else { return ProcessorResult::Inapplicable; };
        retained.push(available.remove(index));
    }
    if available.is_empty() { return ProcessorResult::Inapplicable; }
    let child = Trs::new_with_strategy(live.name().map(str::to_owned), live.variables().clone(),
                                      retained, RewriteStrategy::Full);
    let child = if matches!(state, ProblemState::Srs(_)) { ProblemState::Srs(child) }
                else { ProblemState::Trs(child) };
    ProcessorResult::Applied(ProcessorApplication::new(vec![child], move |children| {
        let [ProblemCertificate::Trs(proof)] = <[ProblemCertificate; 1]>::try_from(children).ok()? else {
            return None;
        };
        if proof.status() != &crate::proving::Status::Nonterminating { return None; }
        Some(ProblemCertificate::Trs(Proof::nonterminating(NonterminationProof::RuleRemoval {
            removed_rules: available.clone(), proof: Box::new(proof),
        })))
    }))
}

impl WorklistProcessor for ExactNonterminationProofProcessor {
    fn name(&self) -> &'static str {
        "exact-trs-nontermination-proof"
    }

    fn apply(&self, state: &ProblemState) -> ProcessorResult {
        crate::proving::processors::reject_retired_complete_nontermination_proof();
        apply_bound_nontermination_xml(state, &self.source_trs_input_xml, &self.nontermination_proof_xml)
    }
}

/// One terminal witness only. Preprocessing belongs in independently keyed
/// transformation events, never inside this processor's payload.
pub(super) fn apply_nontermination_terminal(
    state: &ProblemState, source: &str, terminal: &str,
) -> ProcessorResult {
    let Ok(document) = roxmltree::Document::parse(terminal) else {
        return ProcessorResult::Failed { reason: "malformed nontermination terminal".into() };
    };
    let root = document.root_element();
    if !matches!(root.tag_name().name(), "loop" | "nonLoop" | "notWNTreeAutomaton" | "variableConditionViolated" | "nonterminatingSRS")
        || root.descendants().skip(1).filter(|n| n.is_element()).any(|n| {
            matches!(n.tag_name().name(), "trsNonterminationProof" | "dpNonterminationProof"
                | "trsTerminationProof" | "dpProof" | "ruleRemoval" | "dpTrans" | "uncurry")
        })
    {
        return ProcessorResult::Failed { reason: "nontermination terminal contains a composite proof".into() };
    }
    apply_bound_nontermination_xml(state, source, &format!("<trsNonterminationProof>{terminal}</trsNonterminationProof>"))
}

fn apply_bound_nontermination_xml(
    state: &ProblemState, source_trs_input_xml: &str, nontermination_proof_xml: &str,
) -> ProcessorResult {
        let live = match state {
            ProblemState::Trs(trs) | ProblemState::Srs(trs) => trs,
            _ => return ProcessorResult::Inapplicable,
        };
        let Ok(CpfInputProblem::Trs(source)) = parse_cpf_input(None, source_trs_input_xml)
        else {
            return ProcessorResult::Failed {
                reason: "invalid exact TRS nontermination source".to_owned(),
            };
        };
        let same_rules = same_rule_multiset(source.rules(), live.rules());
        let portable = (!same_rules)
            .then(|| portable_trs_isomorphism(&source, live))
            .flatten();
        if source.strategy() != live.strategy() || (!same_rules && portable.is_none()) {
            return ProcessorResult::Inapplicable;
        }
        let fragment = nontermination_proof_xml.trim();
        let Some(inner) = fragment
            .strip_prefix("<trsNonterminationProof>")
            .and_then(|value| value.strip_suffix("</trsNonterminationProof>"))
        else {
            return ProcessorResult::Failed {
                reason: "malformed exact TRS nontermination proof".to_owned(),
            };
        };
        let mut inner = inner.trim().to_owned();
        if let Some((symbols, _)) = portable {
            // Simultaneous XML-aware transport also handles permutations:
            // replacing a->b and then b->a would collapse distinct symbols.
            inner = crate::proving::processors::dp::translate_payload_symbols(&inner, &symbols);
        }
        ProcessorResult::Applied(ProcessorApplication::solved(ProblemCertificate::Trs(
            Proof::nonterminating(NonterminationProof::ExactXml(inner)),
        )))
}

impl WorklistProcessor for ExactTerminationProofProcessor {
    fn name(&self) -> &'static str {
        "exact-trs-proof"
    }

    fn apply(&self, state: &ProblemState) -> ProcessorResult {
        crate::proving::processors::reject_retired_complete_termination_proof();
        let parsed = match parse_cpf_input(None, &self.source_trs_input_xml) {
            Ok(parsed) => parsed,
            Err(_) => {
                return ProcessorResult::Failed {
                    reason: "invalid exact termination proof source".to_owned(),
                };
            }
        };
        let portable = match (parsed, state) {
            (CpfInputProblem::Trs(source), ProblemState::Trs(live) | ProblemState::Srs(live)) => {
                let same_rules = same_rule_multiset(source.rules(), live.rules());
                let portable = (!same_rules)
                    .then(|| portable_trs_isomorphism(&source, live))
                    .flatten();
                if source.strategy() != live.strategy() || (!same_rules && portable.is_none()) {
                    return ProcessorResult::Inapplicable;
                }
                portable
            }
            (CpfInputProblem::Csr { csr: source, .. }, ProblemState::Csr(live)) => {
                // Complete CSR proofs are retained only at their exact live
                // root.  Unlike ordinary TRSs, a signature isomorphism must
                // also transport the replacement map; until that transport
                // is represented explicitly, require literal maps and rules.
                if !same_rule_multiset(source.rules(), live.csr.rules())
                    || source.replacement_map() != live.csr.replacement_map()
                {
                    return ProcessorResult::Inapplicable;
                }
                None
            }
            _ => return ProcessorResult::Inapplicable,
        };
        let fragment = self.termination_proof_xml.trim();
        let inner = fragment
            .strip_prefix("<trsTerminationProof>")
            .and_then(|value| value.strip_suffix("</trsTerminationProof>"))
            .unwrap_or(fragment);
        if !inner.trim_start().starts_with('<') {
            return ProcessorResult::Failed {
                reason: "malformed exact termination proof".to_owned(),
            };
        }
        let mut inner = inner.trim().to_owned();
        if let Some((symbols, _)) = portable {
            // The applicability check permits a presentation-only signature
            // isomorphism, so the retained CPF payload must use the same live
            // spelling as the emitted root input.  CPF function symbols are
            // represented uniformly by name elements, including sharp and
            // interpretation entries.
            let escape = |value: &str| {
                value
                    .replace('&', "&amp;")
                    .replace('<', "&lt;")
                    .replace('>', "&gt;")
            };
            for (source_symbol, live_symbol) in symbols {
                if source_symbol == live_symbol {
                    continue;
                }
                let source_name = format!("<name>{}</name>", escape(source_symbol.as_str()));
                let live_name = format!("<name>{}</name>", escape(live_symbol.as_str()));
                inner = inner.replace(&source_name, &live_name);
            }
        }
        ProcessorResult::Applied(ProcessorApplication::solved(ProblemCertificate::Trs(
            Proof::terminating(vec![ProofStep::ExactTerminationXml(inner)]),
        )))
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn nontermination_rule_removal_checks_subset_strategy_and_child_polarity() {
        let retained = "<rule><funapp><name>f</name></funapp><var>x</var></rule>";
        let removed = "<rule><funapp><name>g</name></funapp><funapp><name>h</name></funapp></rule>";
        let source = format!("<trsInput><trs><rules>{retained}{removed}</rules></trs></trsInput>");
        let residual = format!("<trsInput><trs><rules>{retained}</rules></trs></trsInput>");
        let CpfInputProblem::Trs(trs) = parse_cpf_input(None, &source).unwrap() else { panic!() };
        let state = ProblemState::Trs(trs.clone());
        let ProcessorResult::Applied(app) = apply_nontermination_rule_removal(&state, &source, &residual) else { panic!() };
        assert_eq!(app.residuals.len(), 1);
        assert!(app.reconstruct(vec![ProblemCertificate::Trs(Proof::terminating(vec![]))]).is_none());
        let ProcessorResult::Applied(app) = apply_nontermination_rule_removal(&state, &source, &residual) else { panic!() };
        let Some(ProblemCertificate::Trs(proof)) = app.reconstruct(vec![ProblemCertificate::Trs(
            Proof::nonterminating(NonterminationProof::VariableConditionViolated))]) else { panic!() };
        let xml = crate::cert::write_cpf(&trs, &proof, crate::cert::CpfMode::Auto).unwrap();
        assert!(xml.contains("<ruleRemoval>"));
        assert!(xml.contains("<variableConditionViolated/>"));
        assert!(matches!(apply_nontermination_rule_removal(&state, &source, &source), ProcessorResult::Inapplicable));
        assert!(matches!(apply_nontermination_rule_removal(&state, &source,
            &residual.replace("<name>f</name>", "<name>missing</name>")), ProcessorResult::Inapplicable));
        let inner = source.replace("</trsInput>", "<strategy><innermost/></strategy></trsInput>");
        let CpfInputProblem::Trs(inner_trs) = parse_cpf_input(None, &inner).unwrap() else { panic!() };
        assert!(matches!(apply_nontermination_rule_removal(&ProblemState::Trs(inner_trs), &inner, &residual), ProcessorResult::Inapplicable));
    }

    #[test]
    fn nontermination_terminal_rejects_wrappers_and_nested_proofs() {
        let state = csr_state(SOURCE);
        for payload in ["<trsNonterminationProof><loop/></trsNonterminationProof>",
            "<dpTrans><dpNonterminationProof><loop/></dpNonterminationProof></dpTrans>",
            "<loop><trsNonterminationProof><loop/></trsNonterminationProof></loop>",
            "<loop>"] {
            assert!(matches!(apply_nontermination_terminal(&state, SOURCE, payload),
                ProcessorResult::Failed { .. }));
        }
    }

    #[test]
    fn nontermination_terminal_is_source_bound() {
        let source = "<trsInput><trs><rules/></trs></trsInput>";
        let CpfInputProblem::Trs(trs) = parse_cpf_input(None, source).unwrap() else { panic!() };
        assert!(matches!(apply_nontermination_terminal(&ProblemState::Trs(trs), source, "<loop/>"),
            ProcessorResult::Applied(_)));
        // The application above only binds the witness. A malformed loop
        // still cannot pass the final CeTA certification gate.
        assert!(matches!(apply_nontermination_terminal(&csr_state(SOURCE), source, "<loop/>"),
            ProcessorResult::Inapplicable));
    }
    use crate::proving::processors::CsrProblemState;

    const SOURCE: &str = r#"
      <trsInput><trs><rules><rule>
        <funapp><name>f</name><var>x</var></funapp><var>x</var>
      </rule></rules></trs><strategy><contextSensitive>
        <replacementMapEntry><name>f</name><arity>1</arity><position>1</position>
        </replacementMapEntry>
      </contextSensitive></strategy></trsInput>"#;

    fn csr_state(input: &str) -> ProblemState {
        let CpfInputProblem::Csr { csr, .. } = parse_cpf_input(None, input).unwrap() else {
            panic!("expected CSR input")
        };
        ProblemState::Csr(CsrProblemState::root(csr))
    }

    #[test]
    #[should_panic(expected = "complete TRS/DP termination-proof actions are retired")]
    fn retired_complete_csr_proof_cannot_bypass_parser_guard() {
        let processor = ExactTerminationProofProcessor {
            source_trs_input_xml: SOURCE.to_owned(),
            termination_proof_xml: "<csrImprovedDependencyPairs/>".to_owned(),
        };
        assert!(matches!(
            processor.apply(&csr_state(SOURCE)),
            ProcessorResult::Applied(_)
        ));

    }

    #[test]
    #[should_panic(expected = "complete TRS/DP termination-proof actions are retired")]
    fn retired_complete_dp_proof_cannot_bypass_parser_guard() {
        let processor = crate::proving::processors::dp::ExactDpTerminationProofProcessor {
            source_dp_input_xml: String::new(),
            dp_proof_xml: String::new(),
        };
        processor.apply(&csr_state(SOURCE));
    }

    #[test]
    #[should_panic(expected = "complete TRS/DP nontermination-proof actions are retired")]
    fn retired_complete_trs_no_cannot_bypass_parser_guard() {
        ExactNonterminationProofProcessor {
            source_trs_input_xml: String::new(), nontermination_proof_xml: String::new(),
        }.apply(&csr_state(SOURCE));
    }

    #[test]
    #[should_panic(expected = "complete TRS/DP nontermination-proof actions are retired")]
    fn retired_complete_dp_no_cannot_bypass_parser_guard() {
        crate::proving::processors::dp::ExactDpNonterminationProofProcessor {
            source_dp_input_xml: String::new(), dp_proof_xml: String::new(),
        }.apply(&csr_state(SOURCE));
    }
}
