use std::collections::{BTreeMap, BTreeSet};

use crate::core::{RewriteRule, Symbol, Term, Trs, Variable};
use crate::proving::engine::ProveStrategyProcessor;
use crate::proving::{Proof, ProofStep, Status};

use super::super::{
    ProblemCertificate, ProblemState, ProcessorApplication, ProcessorResult, WorklistProcessor,
};

/// CPF's constant-to-unary termination transformation.
///
/// The selected constants are replaced uniformly by fresh unary symbols
/// applied to one fresh variable.  The selection is part of the atom: this
/// keeps the residual deterministic and lets the oracle address the child
/// state independently.
pub struct ConstantToUnaryProcessor {
    pub variable: String,
    pub renaming: BTreeMap<String, String>,
}

/// Lift every constant, choosing fresh names rather than supplied witnesses.
/// Selection depends only on arity; renaming the input does not change which
/// symbols are lifted. The exact processor rechecks all freshness obligations.
pub(super) fn apply_native(state: &ProblemState) -> ProcessorResult {
    let ProblemState::Trs(trs) = state else {
        return ProcessorResult::Inapplicable;
    };
    let arities = trs.arities();
    let mut occupied = arities.keys().map(|s| s.as_str().to_string()).collect::<BTreeSet<_>>();
    let mut renaming = BTreeMap::new();
    for (symbol, arity) in &arities {
        if *arity != 0 { continue; }
        let mut fresh = format!("{}'", symbol.as_str());
        while occupied.contains(&fresh) { fresh.push('\''); }
        occupied.insert(fresh.clone());
        renaming.insert(symbol.as_str().to_string(), fresh);
    }
    let mut variable = "x".to_string();
    while trs.variables().contains(&Variable::new(variable.clone())) {
        variable.push('\'');
    }
    ConstantToUnaryProcessor { variable, renaming }.apply(state)
}

impl WorklistProcessor for ConstantToUnaryProcessor {
    fn name(&self) -> &'static str {
        "constant-to-unary"
    }

    fn apply(&self, state: &ProblemState) -> ProcessorResult {
        let ProblemState::Trs(trs) = state else {
            return ProcessorResult::Inapplicable;
        };
        let variable = Variable::new(self.variable.clone());
        if self.renaming.is_empty() || trs.variables().contains(&variable) {
            return ProcessorResult::Inapplicable;
        }
        let arities = trs.arities();
        let occupied = arities.keys().map(Symbol::as_str).collect::<BTreeSet<_>>();
        let mut renaming = BTreeMap::new();
        for (source, target) in &self.renaming {
            let source_symbol = Symbol::new(source.clone());
            if arities.get(&source_symbol) != Some(&0)
                || source == target
                || occupied.contains(target.as_str())
                || renaming
                    .values()
                    .any(|existing: &Symbol| existing.as_str() == target)
            {
                return ProcessorResult::Inapplicable;
            }
            renaming.insert(source_symbol, Symbol::new(target.clone()));
        }
        let transformed_rules = trs
            .rules()
            .iter()
            .map(|rule| {
                RewriteRule::new(
                    replace_constants(rule.lhs(), &variable, &renaming),
                    replace_constants(rule.rhs(), &variable, &renaming),
                )
            })
            .collect::<Vec<_>>();
        let mut variables = trs.variables().clone();
        variables.insert(variable.clone());
        let transformed = Trs::new_with_strategy(
            trs.name().map(str::to_string),
            variables,
            transformed_rules.clone(),
            trs.strategy(),
        );
        let residual = ProblemState::Trs(transformed);
        let selected_atom = ProveStrategyProcessor::ConstantToUnary {
            variable: self.variable.clone(),
            renaming: self.renaming.clone(),
        }
        .to_strategy_atom();
        ProcessorResult::Applied(
            ProcessorApplication::new(vec![residual], move |children| {
                let [ProblemCertificate::Trs(proof)] =
                    <[ProblemCertificate; 1]>::try_from(children).ok()?
                else {
                    return None;
                };
                if proof.status() != &Status::Terminating {
                    return None;
                }
                Some(ProblemCertificate::Trs(Proof::terminating(vec![
                    ProofStep::ConstantToUnary {
                        variable: variable.clone(),
                        renaming: renaming.clone(),
                        transformed_rules: transformed_rules.clone(),
                        proof: Box::new(proof),
                    },
                ])))
            })
            .with_selected_atom(selected_atom),
        )
    }
}

fn replace_constants(
    term: &Term,
    variable: &Variable,
    renaming: &BTreeMap<Symbol, Symbol>,
) -> Term {
    match term {
        Term::Var(variable) => Term::Var(variable.clone()),
        Term::App { symbol, args } if args.is_empty() && renaming.contains_key(symbol) => {
            Term::App {
                symbol: renaming[symbol].clone(),
                args: vec![Term::Var(variable.clone())],
            }
        }
        Term::App { symbol, args } => Term::App {
            symbol: symbol.clone(),
            args: args
                .iter()
                .map(|arg| replace_constants(arg, variable, renaming))
                .collect(),
        },
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::core::RewriteStrategy;

    #[test]
    fn native_constant_to_unary_freshness_and_strategy() {
        for (f, a) in [("f", "a"), ("renamed", "constant")] {
            let collision = format!("{a}'");
            let trs = Trs::new_with_strategy(None,
                BTreeSet::from([Variable::new("x")]),
                vec![RewriteRule::new(Term::app(f, vec![Term::app(a, vec![])]),
                    Term::app(&collision, vec![Term::var("x")]))],
                RewriteStrategy::Innermost);
            let ProcessorResult::Applied(application) = apply_native(&ProblemState::Trs(trs)) else {
                panic!("native constant lifting should apply");
            };
            let ProblemState::Trs(child) = &application.residuals[0] else { panic!() };
            assert_eq!(child.strategy(), RewriteStrategy::Innermost);
            assert!(child.variables().contains(&Variable::new("x'")));
            assert_eq!(child.arities().get(&Symbol::new(format!("{a}''"))), Some(&1));
            assert!(!child.arities().contains_key(&Symbol::new(a)));
            assert_eq!(child.arities().get(&Symbol::new(&collision)), Some(&1));
        }
    }

    #[test]
    fn native_constant_to_unary_declines_without_constants() {
        let trs = Trs::new(None, BTreeSet::from([Variable::new("x")]),
            vec![RewriteRule::new(Term::app("f", vec![Term::var("x")]), Term::var("x"))]);
        assert!(matches!(apply_native(&ProblemState::Trs(trs)), ProcessorResult::Inapplicable));
    }

    #[test]
    fn native_constant_to_unary_strategy_roundtrip() {
        let strategy = crate::proving::ProveStrategy::parse("constant-to-unary").unwrap();
        let crate::proving::ProveStrategy::Processor(processor) = strategy else { panic!() };
        assert_eq!(processor.to_strategy_atom(), "constant-to-unary");
    }
}
