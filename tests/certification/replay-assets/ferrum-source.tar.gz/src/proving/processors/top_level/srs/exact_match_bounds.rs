use std::time::Instant;

use std::collections::BTreeSet;

use super::automaton::{
    checked_srs_match_bounds_proof, checked_srs_relative_match_bounds_proof,
    srs_rules_from_rewrite_rules,
};
use crate::core::{RelativeTrs, Trs};
use crate::proving::{BoundsProof, Proof, ProofStep, Status};

use super::super::super::{
    ProblemCertificate, ProblemState, ProcessorApplication, ProcessorResult, WorklistProcessor,
};

pub struct ExactSrsMatchBoundsProcessor {
    pub proof: BoundsProof,
    pub deadline: Option<Instant>,
}

#[cfg(test)]
mod cons_witness_tests {
    use super::*;
    use crate::core::{RewriteRule, Term, Variable};

    #[test]
    fn reconstructs_ranked_cons_witness_and_rejects_missing_transitions() {
        let cons = |letter: &str, tail| Term::app("cell", vec![Term::app(letter, vec![]), tail]);
        let trs = Trs::new(None, BTreeSet::from([Variable::new("x")]), vec![RewriteRule::new(
            cons("a", cons("b", Term::var("x"))), cons("a", Term::var("x")),
        )]);
        let witness = super::super::automaton::prove_srs_by_match_bounds_completion_with_limits(
            &trs, 1, 1000, 10000, None,
        ).unwrap();
        let processor = ExactSrsMatchBoundsProcessor { proof: witness.clone(), deadline: None };
        let ProcessorResult::Applied(application) = processor.apply(&ProblemState::Trs(trs.clone())) else {
            panic!("ranked cons witness must be independently reconstructable");
        };
        assert!(application.reconstruct(vec![]).is_some());
        let mut invalid = witness;
        invalid.automaton.transitions.clear();
        assert!(matches!(ExactSrsMatchBoundsProcessor { proof: invalid, deadline: None }
            .apply(&ProblemState::Trs(trs)), ProcessorResult::Inapplicable));
    }
}

pub struct ExactSrsRelativeMatchBoundsProcessor {
    pub proof: BoundsProof,
    pub removed_indices: Vec<usize>,
    pub deadline: Option<Instant>,
}

impl WorklistProcessor for ExactSrsRelativeMatchBoundsProcessor {
    fn name(&self) -> &'static str {
        "exact-srs-relative-match-bounds"
    }

    fn apply(&self, state: &ProblemState) -> ProcessorResult {
        let relative = match state {
            ProblemState::RelativeSrs(relative) => relative.clone(),
            ProblemState::Srs(trs) => RelativeTrs::new(trs.clone(), Vec::new()),
            _ => return ProcessorResult::Inapplicable,
        };
        let Some(strict_rules) = relative.strict().srs_rules() else {
            return ProcessorResult::Inapplicable;
        };
        let Some(weak_rules) = srs_rules_from_rewrite_rules(relative.weak_rules()) else {
            return ProcessorResult::Inapplicable;
        };
        let removed_set = self
            .removed_indices
            .iter()
            .copied()
            .collect::<BTreeSet<_>>();
        if removed_set.is_empty()
            || removed_set.len() != self.removed_indices.len()
            || removed_set.iter().any(|index| *index >= strict_rules.len())
        {
            return ProcessorResult::Inapplicable;
        }
        let selected = self
            .removed_indices
            .iter()
            .map(|&index| strict_rules[index].clone())
            .collect::<Vec<_>>();
        let residual_srs = strict_rules
            .iter()
            .enumerate()
            .filter_map(|(index, rule)| (!removed_set.contains(&index)).then_some(rule.clone()))
            .collect::<Vec<_>>();
        let current_weak = weak_rules
            .iter()
            .cloned()
            .chain(residual_srs.iter().cloned())
            .collect::<Vec<_>>();
        if !checked_srs_relative_match_bounds_proof(
            &selected,
            &current_weak,
            &self.proof,
            self.deadline,
        ) {
            return if self
                .deadline
                .is_some_and(|deadline| Instant::now() >= deadline)
            {
                ProcessorResult::TimedOut
            } else {
                ProcessorResult::Inapplicable
            };
        }

        let removed = self
            .removed_indices
            .iter()
            .map(|&index| relative.strict().rules()[index].clone())
            .collect::<Vec<_>>();
        let residual_rules = relative
            .strict()
            .rules()
            .iter()
            .enumerate()
            .filter_map(|(index, rule)| (!removed_set.contains(&index)).then_some(rule.clone()))
            .collect();
        let residual_strict = Trs::new_with_strategy(
            relative.strict().name().map(str::to_string),
            relative.strict().variables().clone(),
            residual_rules,
            relative.strict().strategy(),
        );
        let residual_weak = relative
            .weak_rules()
            .iter()
            .cloned()
            .chain(removed.iter().cloned())
            .collect();
        let residual = ProblemState::RelativeSrs(RelativeTrs::new(residual_strict, residual_weak));
        let proof = self.proof.clone();
        ProcessorResult::Applied(ProcessorApplication::new(vec![residual], move |children| {
            let [ProblemCertificate::Trs(child)] =
                <[ProblemCertificate; 1]>::try_from(children).ok()?
            else {
                return None;
            };
            if child.status() != &Status::Terminating {
                return None;
            }
            Some(ProblemCertificate::Trs(Proof::terminating(vec![
                ProofStep::RelativeBounds {
                    proof: proof.clone(),
                    removed: removed.clone(),
                    proof_after_removal: Box::new(child),
                },
            ])))
        }))
    }
}

impl WorklistProcessor for ExactSrsMatchBoundsProcessor {
    fn name(&self) -> &'static str {
        "exact-srs-match-bounds"
    }

    fn apply(&self, state: &ProblemState) -> ProcessorResult {
        let proof = match state {
            ProblemState::Trs(trs) => {
                let Some(proof) = super::automaton::reconstruct_cons_match_bounds_proof(trs, &self.proof, self.deadline) else {
                    return ProcessorResult::Inapplicable;
                };
                proof
            }
            ProblemState::Srs(trs) => {
                if !checked_srs_match_bounds_proof(trs, &self.proof, self.deadline) {
                    return if self.deadline.is_some_and(|deadline| Instant::now() >= deadline) {
                        ProcessorResult::TimedOut
                    } else { ProcessorResult::Inapplicable };
                }
                self.proof.clone()
            }
            _ => return ProcessorResult::Inapplicable,
        };
        ProcessorResult::Applied(ProcessorApplication::solved(ProblemCertificate::Trs(
            Proof::terminating(vec![ProofStep::Bounds {
                proof,
            }]),
        )))
    }
}
