use std::collections::{BTreeMap, BTreeSet};
use std::process::{Command, Stdio};
use std::time::Instant;

use crate::core::{SrsRule, Trs};
use crate::llm::{LinearPolynomial, LinearPolynomialInterpretations};
use crate::proving::processors::top_level::polynomial::{
    TopLevelPolynomialRemoval, top_level_polynomial_removal_from_interpretations,
};
use crate::proving::processors::top_level::smt::{
    command_exists, parse_integer_values, sanitize_identifier, solver_args, sum,
};
use crate::proving::runtime::{run_command_with_input_deadline, write_progress_event};
use crate::proving::{
    Proof, ProofStep, Status, linear_polynomial_prove_termination,
    linear_polynomial_strictly_orients_rule, linear_polynomial_weakly_orients_rule,
};

use super::super::super::{
    ProblemCertificate, ProblemState, ProcessorApplication, ProcessorResult, WorklistProcessor,
};

pub struct SrsLengthProcessor;

impl WorklistProcessor for SrsLengthProcessor {
    fn name(&self) -> &'static str {
        "srs-length"
    }

    fn apply(&self, state: &ProblemState) -> ProcessorResult {
        let (ProblemState::Srs(trs) | ProblemState::Trs(trs)) = state else {
            return ProcessorResult::Inapplicable;
        };
        let Some((model, interpretations)) = strict_length_interpretation(trs) else {
            return ProcessorResult::Inapplicable;
        };
        if !trs.rules().iter().all(|rule| {
            linear_polynomial_strictly_orients_rule(rule, &model)
                && linear_polynomial_weakly_orients_rule(rule, &model)
        }) {
            return ProcessorResult::Inapplicable;
        }
        ProcessorResult::Applied(ProcessorApplication::solved(ProblemCertificate::Trs(
            Proof::terminating(vec![ProofStep::SynthesizedLinearPolynomial {
                interpretations,
            }]),
        )))
    }
}

pub struct SrsWeightedLengthProcessor {
    pub max_weight: i64,
    pub deadline: Option<Instant>,
}

impl WorklistProcessor for SrsWeightedLengthProcessor {
    fn name(&self) -> &'static str {
        "srs-weighted-length"
    }

    fn apply(&self, state: &ProblemState) -> ProcessorResult {
        let (ProblemState::Srs(trs) | ProblemState::Trs(trs)) = state else {
            return ProcessorResult::Inapplicable;
        };
        let Some((model, interpretations)) =
            weighted_length_interpretation(trs, self.max_weight, true, self.deadline)
        else {
            return ProcessorResult::Inapplicable;
        };
        if !linear_polynomial_prove_termination(trs, &model) {
            return ProcessorResult::Inapplicable;
        }
        ProcessorResult::Applied(ProcessorApplication::solved(ProblemCertificate::Trs(
            Proof::terminating(vec![ProofStep::SynthesizedLinearPolynomial {
                interpretations,
            }]),
        )))
    }
}

pub struct SrsWeightedRuleRemovalProcessor {
    pub max_weight: i64,
    pub deadline: Option<Instant>,
}

/// Solve a canonical copy, then transport only its weights back to live
/// symbols. The live rule-removal checker remains the acceptance boundary.
pub struct SrsCanonicalWeightRemovalProcessor {
    pub max_weight: i64,
    pub deadline: Option<Instant>,
}

/// An opt-in equivalent LIA encoding that cancels shared symbol counts and
/// shares duplicate inequalities. Existing oracle atoms retain their encoding.
pub struct SrsCompactWeightRemovalProcessor {
    pub max_weight: i64,
    pub deadline: Option<Instant>,
    pub canonical: bool,
    pub summed: bool,
    pub rational: bool,
    pub lp: bool,
}

impl WorklistProcessor for SrsCompactWeightRemovalProcessor {
    fn name(&self) -> &'static str {
        if self.lp {
            "srs-lp-weight-removal"
        } else if self.rational {
            "srs-linear-weight-removal"
        } else if self.summed {
            "srs-summed-weight-removal"
        } else if self.canonical {
            "srs-canonical-compact-weight-removal"
        } else {
            "srs-compact-weight-removal"
        }
    }
    fn apply(&self, state: &ProblemState) -> ProcessorResult {
        self.apply_with_strictness(state, false)
    }
}

impl SrsCompactWeightRemovalProcessor {
    pub(crate) fn apply_with_strictness(&self, state: &ProblemState, all_strict: bool) -> ProcessorResult {
        self.apply_with_objective(state, all_strict, false)
    }

    pub(crate) fn apply_with_objective(&self, state: &ProblemState, all_strict: bool, maximal: bool) -> ProcessorResult {
        if self.deadline.is_some_and(|end| Instant::now() >= end) {
            return ProcessorResult::TimedOut;
        }
        let (ProblemState::Srs(trs) | ProblemState::Trs(trs)) = state else {
            return ProcessorResult::Inapplicable;
        };
        if trs.unary_srs_rules().is_none() {
            return ProcessorResult::Inapplicable;
        }
        let canonical_start = Instant::now();
        // A simultaneous strict interpretation closes the entire state, so
        // there is no synthesized residual whose identity needs stabilizing.
        let canonical = if self.canonical && !all_strict {
            match crate::standardize::standardize_trs_with_bijection(trs) {
                Ok(canonical) => Some(canonical),
                Err(_) => {
                    write_progress_event("srs-weights", "canonicalization-failed", self.name(),
                        canonical_start.elapsed().as_millis(), "no canonical representative");
                    return ProcessorResult::Inapplicable;
                }
            }
        } else { None };
        write_progress_event("srs-weights", "canonicalized", self.name(),
            canonical_start.elapsed().as_millis(), &format!("canonical={} rules={}", canonical.is_some(), trs.rules().len()));
        let search_trs = canonical.as_ref().map_or(trs, |c| &c.trs);
        let Some((mut model, _)) = weighted_length_interpretation_encoding(
            search_trs, self.max_weight, all_strict, self.deadline, true, self.summed, self.rational, self.lp, maximal,
        ) else { return ProcessorResult::Inapplicable; };
        if let Some(canonical) = canonical {
            let Some(transported) = model.into_iter().map(|(symbol, interpretation)| {
                canonical.inverse_function_bijection.get(&crate::core::Symbol::new(symbol))
                    .map(|original| (original.as_str().to_owned(), interpretation))
            }).collect::<Option<BTreeMap<_,_>>>() else { return ProcessorResult::Inapplicable; };
            model = transported;
        }
        if all_strict && !trs.rules().iter().all(|rule| linear_polynomial_strictly_orients_rule(rule, &model)) {
            return ProcessorResult::Inapplicable;
        }
        let Some(removal) = top_level_polynomial_removal_from_interpretations(trs, model) else {
            return ProcessorResult::Inapplicable;
        };
        weighted_removal_application(removal)
    }
}

impl WorklistProcessor for SrsCanonicalWeightRemovalProcessor {
    fn name(&self) -> &'static str { "srs-canonical-weight-removal" }
    fn apply(&self, state: &ProblemState) -> ProcessorResult {
        if self.deadline.is_some_and(|end| Instant::now() >= end) {
            return ProcessorResult::TimedOut;
        }
        let (ProblemState::Srs(trs) | ProblemState::Trs(trs)) = state else {
            return ProcessorResult::Inapplicable;
        };
        if trs.unary_srs_rules().is_none() { return ProcessorResult::Inapplicable; }
        let Ok(canonical) = crate::standardize::standardize_trs_with_bijection(trs) else {
            return ProcessorResult::Inapplicable;
        };
        let Some((model, _)) = weighted_length_interpretation(&canonical.trs,
            self.max_weight, false, self.deadline) else { return ProcessorResult::Inapplicable; };
        let Some(model) = model.into_iter().map(|(symbol, interpretation)| {
            canonical.inverse_function_bijection.get(&crate::core::Symbol::new(symbol))
                .map(|original| (original.as_str().to_owned(), interpretation))
        }).collect::<Option<BTreeMap<_,_>>>() else { return ProcessorResult::Inapplicable; };
        let Some(removal) = top_level_polynomial_removal_from_interpretations(trs, model) else {
            return ProcessorResult::Inapplicable;
        };
        weighted_removal_application(removal)
    }
}

impl WorklistProcessor for SrsWeightedRuleRemovalProcessor {
    fn name(&self) -> &'static str {
        "srs-weighted-rule-removal"
    }

    fn apply(&self, state: &ProblemState) -> ProcessorResult {
        let (ProblemState::Srs(trs) | ProblemState::Trs(trs)) = state else {
            return ProcessorResult::Inapplicable;
        };
        let Some((interpretations, _)) =
            weighted_length_interpretation(trs, self.max_weight, false, self.deadline)
        else {
            return ProcessorResult::Inapplicable;
        };
        let Some(removal) = top_level_polynomial_removal_from_interpretations(trs, interpretations)
        else {
            return ProcessorResult::Inapplicable;
        };
        weighted_removal_application(removal)
    }
}

fn weighted_removal_application(removal: TopLevelPolynomialRemoval) -> ProcessorResult {
    let interpretations = removal.interpretations;
    let removed = removal.removed;
    ProcessorResult::Applied(ProcessorApplication::new(
        vec![ProblemState::Srs(removal.remaining)],
        move |children| {
            let [ProblemCertificate::Trs(proof)] =
                <[ProblemCertificate; 1]>::try_from(children).ok()?
            else {
                return None;
            };
            if proof.status() != &Status::Terminating {
                return None;
            }
            Some(ProblemCertificate::Trs(Proof::terminating(vec![
                ProofStep::PolynomialRuleRemoval {
                    interpretations: interpretations.clone(),
                    removed: removed.clone(),
                    proof: Box::new(proof),
                },
            ])))
        },
    ))
}

fn strict_length_interpretation(
    trs: &Trs,
) -> Option<(
    LinearPolynomialInterpretations,
    Vec<(String, i64, Vec<i64>)>,
)> {
    let rules = trs.unary_srs_rules()?;
    if rules.is_empty() || !rules.iter().all(|rule| rule.lhs().len() > rule.rhs().len()) {
        return None;
    }
    let mut model = BTreeMap::new();
    let mut certificate = Vec::new();
    for (symbol, arity) in trs.arities() {
        if arity > 1 {
            return None;
        }
        let coefficients = if arity == 0 { Vec::new() } else { vec![1] };
        model.insert(
            symbol.as_str().to_string(),
            LinearPolynomial {
                constant: 1,
                coefficients: coefficients.clone(),
            },
        );
        certificate.push((symbol.as_str().to_string(), 1, coefficients));
    }
    Some((model, certificate))
}

fn weighted_length_interpretation(
    trs: &Trs,
    max_weight: i64,
    all_strict: bool,
    deadline: Option<Instant>,
) -> Option<(
    LinearPolynomialInterpretations,
    Vec<(String, i64, Vec<i64>)>,
)> {
    weighted_length_interpretation_encoding(trs, max_weight, all_strict, deadline, false, false, false, false, false)
}

fn weighted_length_interpretation_encoding(
    trs: &Trs, max_weight: i64, all_strict: bool, deadline: Option<Instant>, compact: bool, summed: bool, rational: bool, lp: bool, maximal: bool,
) -> Option<(LinearPolynomialInterpretations, Vec<(String, i64, Vec<i64>)>)> {
    let rules = trs.unary_srs_rules()?;
    if rules.is_empty() || max_weight < 1 {
        return None;
    }
    let symbols = srs_symbols(&rules);
    if symbols.is_empty() {
        return None;
    }
    let weights = if lp && all_strict {
        // Compact solver identifiers without graph canonicalization. The
        // bijection is local, and every transported order is checked below.
        let aliases = symbols.iter().enumerate().map(|(i, s)|
            (s.clone(), crate::core::Symbol::new(format!("w{i:08}"))))
            .collect::<BTreeMap<_, _>>();
        let compact_rules = rules.iter().map(|rule| SrsRule::from_words(
            rule.lhs().iter().map(|s| aliases[s.as_str()].clone()).collect(),
            rule.rhs().iter().map(|s| aliases[s.as_str()].clone()).collect(),
        )).collect::<Vec<_>>();
        let compact_symbols = srs_symbols(&compact_rules);
        let model = synthesize_weights(&compact_rules, &compact_symbols, max_weight,
            all_strict, deadline, compact, summed, rational, lp, maximal)?;
        aliases.into_iter().map(|(original, alias)|
            Some((original, *model.get(alias.as_str())?))).collect::<Option<BTreeMap<_, _>>>()?
    } else { synthesize_weights(&rules, &symbols, max_weight, all_strict, deadline, compact, summed, rational, lp, maximal)? };
    let arities = trs.arities();
    let mut model = BTreeMap::new();
    let mut certificate = Vec::new();
    for symbol in symbols {
        let arity = *arities.get(&crate::core::Symbol::new(symbol.clone()))?;
        if arity > 1 {
            return None;
        }
        let constant = *weights.get(&symbol)?;
        let coefficients = if arity == 0 { Vec::new() } else { vec![1] };
        model.insert(
            symbol.clone(),
            LinearPolynomial {
                constant,
                coefficients: coefficients.clone(),
            },
        );
        certificate.push((symbol, constant, coefficients));
    }
    Some((model, certificate))
}

fn srs_symbols(rules: &[SrsRule]) -> BTreeSet<String> {
    rules
        .iter()
        .flat_map(|rule| rule.lhs().iter().chain(rule.rhs()))
        .map(|symbol| symbol.as_str().to_string())
        .collect()
}

fn synthesize_weights(
    rules: &[SrsRule],
    symbols: &BTreeSet<String>,
    max_weight: i64,
    all_strict: bool,
    deadline: Option<Instant>,
    compact: bool,
    summed: bool,
    rational: bool,
    lp: bool,
    maximal: bool,
) -> Option<BTreeMap<String, i64>> {
    let started = Instant::now();
    let solver = if lp { "highs-lp" } else { command_exists("z3")
        .then_some("z3")
        .or_else(|| command_exists("cvc5").then_some("cvc5"))? };
    let script = if rational {
        linear_weight_script(rules, symbols, max_weight, all_strict)
    } else if compact {
        compact_weighted_length_script_mode(rules, symbols, max_weight, all_strict, summed)
    } else {
        weighted_length_script(rules, symbols, max_weight, all_strict)
    };
    let script = if rational {
        // The constraints are homogeneous differences of symbol weights.
        // Positive rational scaling preserves weak and strict orientation.
        script.replace("QF_LIA", "QF_LRA").replace(" Int)", " Real)")
    } else { script };
    let mut command = if lp {
        let mut command = Command::new("python3");
        command.args(["-c", include_str!(concat!(env!("CARGO_MANIFEST_DIR"), "/scripts/solve_srs_linear_weights.py"))]);
        if all_strict { command.arg("--all-strict"); }
        if maximal { command.arg("--maximize-removal"); }
        command
    } else {
        let mut command = Command::new(solver);
        command.args(solver_args(solver));
        command
    };
    command.stderr(Stdio::null());
    write_progress_event("srs-weights", "encoded", "weight-synthesis", started.elapsed().as_millis(),
        &format!("rational={rational} compact={compact} summed={summed} rules={} symbols={} bytes={}", rules.len(), symbols.len(), script.len()));
    let output = run_command_with_input_deadline(&mut command, &script, deadline).ok()??;
    if !output.status.success() {
        return None;
    }
    let stdout = String::from_utf8_lossy(&output.stdout);
    write_progress_event("srs-weights", "solver-exit", solver, started.elapsed().as_millis(),
        stdout.split_whitespace().next().unwrap_or("empty"));
    if !stdout.contains("sat") || stdout.contains("unsat") {
        return None;
    }
    let values = if rational {
        scaled_real_weights(&stdout, symbols, max_weight)?
    } else { parse_integer_values(&stdout)? };
    symbols
        .iter()
        .map(|symbol| Some((symbol.clone(), *values.get(&weight_name(symbol))?)))
        .collect()
}

fn weight_gcd(mut a: u128, mut b: u128) -> u128 {
    while b != 0 { (a, b) = (b, a % b); }
    a
}

/// Parse only exact nonnegative rational numerals. Reject approximations,
/// algebraic expressions, excessive nesting, zero denominators and overflow.
fn exact_weight_fraction(tokens: &[&str], depth: usize) -> Option<(u128, u128, usize)> {
    if depth > 16 { return None; }
    if tokens.first().copied()? == "(" {
        if tokens.get(1).copied()? != "/" { return None; }
        let (an, ad, ac) = exact_weight_fraction(tokens.get(2..)?, depth + 1)?;
        let (bn, bd, bc) = exact_weight_fraction(tokens.get(2 + ac..)?, depth + 1)?;
        if bn == 0 || tokens.get(2 + ac + bc).copied()? != ")" { return None; }
        let n = an.checked_mul(bd)?;
        let d = ad.checked_mul(bn)?;
        let gcd = weight_gcd(n, d);
        return Some((n / gcd, d / gcd, 3 + ac + bc));
    }
    let atom = tokens[0];
    let (n, d) = if let Some((whole, fractional)) = atom.split_once('.') {
        if whole.is_empty() || fractional.is_empty() ||
            !whole.bytes().chain(fractional.bytes()).all(|b| b.is_ascii_digit()) { return None; }
        let d = 10u128.checked_pow(u32::try_from(fractional.len()).ok()?)?;
        (whole.parse::<u128>().ok()?.checked_mul(d)?.checked_add(fractional.parse().ok()?)?, d)
    } else {
        if atom.is_empty() || !atom.bytes().all(|b| b.is_ascii_digit()) { return None; }
        (atom.parse().ok()?, 1)
    };
    let gcd = weight_gcd(n, d);
    Some((n / gcd, d / gcd, 1))
}

fn scaled_real_weights(output: &str, symbols: &BTreeSet<String>, max_weight: i64) -> Option<BTreeMap<String, i64>> {
    let normalized = output.replace('(', " ( ").replace(')', " ) ");
    let tokens: Vec<_> = normalized.split_whitespace().collect();
    let names: BTreeSet<_> = symbols.iter().map(|s| weight_name(s)).collect();
    if names.len() != symbols.len() { return None; }
    let mut fractions = BTreeMap::new();
    for index in 0..tokens.len().saturating_sub(6) {
        if tokens[index] != "(" || tokens[index + 1] != "define-fun" || !names.contains(tokens[index + 2]) { continue; }
        if tokens[index + 3..index + 6] != ["(", ")", "Real"] { return None; }
        let (n, d, consumed) = exact_weight_fraction(&tokens[index + 6..], 0)?;
        if tokens.get(index + 6 + consumed).copied() != Some(")") { return None; }
        if fractions.insert(tokens[index + 2].to_string(), (n, d)).is_some() { return None; }
    }
    if fractions.len() != names.len() { return None; }
    let mut denominator = 1u128;
    for &(_, d) in fractions.values() {
        denominator = (denominator / weight_gcd(denominator, d)).checked_mul(d)?;
    }
    let integers = fractions.into_iter().map(|(name, (n, d))|
        Some((name, n.checked_mul(denominator / d)?))).collect::<Option<BTreeMap<_, _>>>()?;
    let gcd = integers.values().copied().fold(0, weight_gcd).max(1);
    integers.into_iter().map(|(name, value)| {
        let value = i64::try_from(value / gcd).ok()?;
        (value <= max_weight).then_some((name, value))
    }).collect()
}

fn weighted_length_script(
    rules: &[SrsRule],
    symbols: &BTreeSet<String>,
    max_weight: i64,
    all_strict: bool,
) -> String {
    let mut script = String::from("(set-logic QF_LIA)\n");
    for symbol in symbols {
        let weight = weight_name(symbol);
        script.push_str(&format!("(declare-const {weight} Int)\n"));
        script.push_str(&format!(
            "(assert (and (>= {weight} 0) (<= {weight} {max_weight})))\n"
        ));
    }
    let comparisons = rules
        .iter()
        .map(|rule| {
            let lhs = word_weight(rule.lhs());
            let rhs = word_weight(rule.rhs());
            if all_strict {
                format!("(assert (> {lhs} {rhs}))\n")
            } else {
                script.push_str(&format!("(assert (>= {lhs} {rhs}))\n"));
                format!("(> {lhs} {rhs})")
            }
        })
        .collect::<Vec<_>>();
    if all_strict {
        for comparison in comparisons {
            script.push_str(&comparison);
        }
    } else {
        script.push_str(&format!("(assert (or {}))\n", comparisons.join(" ")));
    }
    script.push_str("(check-sat)\n(get-model)\n");
    script
}

fn word_weight(word: &[crate::core::Symbol]) -> String {
    sum(word
        .iter()
        .map(|symbol| weight_name(symbol.as_str()))
        .collect())
}

fn compact_weighted_length_script(
    rules: &[SrsRule], symbols: &BTreeSet<String>, max_weight: i64, all_strict: bool,
) -> String {
    compact_weighted_length_script_mode(rules, symbols, max_weight, all_strict, false)
}

// Homogeneous inequalities may be divided by a positive common factor.
// Combine the strict-progress sum algebraically before handing it to SMT:
// shared positive/negative occurrences otherwise create a very large term.
fn linear_weight_script(
    rules: &[SrsRule], symbols: &BTreeSet<String>, max_weight: i64, all_strict: bool,
) -> String {
    let mut script = String::from("(set-logic QF_LRA)\n");
    for symbol in symbols {
        let weight = weight_name(symbol);
        script.push_str(&format!("(declare-const {weight} Real)\n(assert (and (>= {weight} 0) (<= {weight} {max_weight})))\n"));
    }
    let rows: BTreeSet<Vec<(String, i64)>> = rules.iter().map(|rule| {
        let mut counts = BTreeMap::<String, i64>::new();
        for symbol in rule.lhs() { *counts.entry(symbol.as_str().to_owned()).or_default() += 1; }
        for symbol in rule.rhs() { *counts.entry(symbol.as_str().to_owned()).or_default() -= 1; }
        let divisor = counts.values().fold(0, |g, c| weight_gcd(g, c.unsigned_abs() as u128)).max(1) as i64;
        counts.into_iter().filter(|(_, c)| *c != 0).map(|(s, c)| (s, c / divisor)).collect()
    }).collect();
    let expression = |counts: &BTreeMap<String, i64>| sum(counts.iter().filter(|(_, c)| **c != 0)
        .map(|(s, c)| format!("(* {c} {})", weight_name(s))).collect());
    let mut total = BTreeMap::<String, i64>::new();
    for row in rows {
        let row: BTreeMap<_, _> = row.into_iter().collect();
        script.push_str(&format!("(assert ({} {} 0))\n", if all_strict { ">" } else { ">=" }, expression(&row)));
        for (symbol, count) in row { *total.entry(symbol).or_default() += count; }
    }
    if !all_strict { script.push_str(&format!("(assert (> {} 0))\n", expression(&total))); }
    script.push_str("(check-sat)\n(get-model)\n");
    script
}

fn compact_weighted_length_script_mode(
    rules: &[SrsRule], symbols: &BTreeSet<String>, max_weight: i64, all_strict: bool, summed: bool,
) -> String {
    let mut script = String::from("(set-logic QF_LIA)\n");
    for symbol in symbols {
        let weight = weight_name(symbol);
        script.push_str(&format!("(declare-const {weight} Int)\n(assert (and (>= {weight} 0) (<= {weight} {max_weight})))\n"));
    }
    let differences: BTreeSet<Vec<(String, i64)>> = rules.iter().map(|rule| {
        let mut counts = BTreeMap::<String, i64>::new();
        for symbol in rule.lhs() { *counts.entry(symbol.as_str().to_owned()).or_default() += 1; }
        for symbol in rule.rhs() { *counts.entry(symbol.as_str().to_owned()).or_default() -= 1; }
        counts.into_iter().filter(|(_, count)| *count != 0).collect()
    }).collect();
    let mut strict = Vec::new();
    let mut gaps = Vec::new();
    for difference in differences {
        let side = |positive: bool| sum(difference.iter().filter_map(|(symbol, count)| {
            if (*count > 0) != positive { return None; }
            let weight = weight_name(symbol);
            Some(if count.abs() == 1 { weight } else { format!("(* {} {weight})", count.abs()) })
        }).collect());
        let lhs = side(true);
        let rhs = side(false);
        if all_strict { script.push_str(&format!("(assert (> {lhs} {rhs}))\n")); }
        else {
            script.push_str(&format!("(assert (>= {lhs} {rhs}))\n"));
            strict.push(format!("(> {lhs} {rhs})"));
            gaps.push(format!("(- {lhs} {rhs})"));
        }
    }
    if !all_strict {
        if summed {
            // Every gap is constrained nonnegative above. Therefore some
            // gap is positive iff their sum is positive. Avoid a Boolean
            // disjunction without changing the admissible integer models.
            script.push_str(&format!("(assert (> {} 0))\n", sum(gaps)));
        } else {
            script.push_str(&format!("(assert (or {}))\n", strict.join(" ")));
        }
    }
    script.push_str("(check-sat)\n(get-model)\n");
    script
}

fn weight_name(symbol: &str) -> String {
    format!("sw_{}", sanitize_identifier(symbol))
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::core::{RewriteRule, Term, Variable};
    use std::collections::BTreeSet;

    fn unary_trs(lhs: &str, rhs: &str) -> Trs {
        let x = Term::var("x");
        let word = |letters: &str| {
            letters.chars().rev().fold(x.clone(), |tail, letter| {
                Term::app(letter.to_string(), vec![tail])
            })
        };
        Trs::new(
            None,
            BTreeSet::from([Variable::new("x")]),
            vec![RewriteRule::new(word(lhs), word(rhs))],
        )
    }

    #[test]
    fn compact_srs_weights_share_inequalities_and_keep_strict_progress() {
        let trs = unary_trs("aab", "ab");
        let rule = trs.unary_srs_rules().unwrap()[0].clone();
        let rules = vec![rule; 100];
        let symbols = srs_symbols(&rules);
        let compact = compact_weighted_length_script(&rules, &symbols, 16, false);
        let legacy = weighted_length_script(&rules, &symbols, 16, false);
        assert!(compact.len() * 10 < legacy.len());
        assert_eq!(compact.matches("(assert (>=").count(), 1);
        assert!(compact.contains(&format!("(assert (or (> {} 0)))", weight_name("a"))));
        let balanced = unary_trs("ab", "ba").unary_srs_rules().unwrap();
        assert!(compact_weighted_length_script(&balanced, &symbols, 16, false).contains("(assert (or (> 0 0)))"));
        let atom = "srs-compact-weight-removal(max-weight=65536)";
        let crate::proving::ProveStrategy::Processor(p) = crate::proving::ProveStrategy::parse(atom).unwrap() else { panic!() };
        assert_eq!(p.to_strategy_atom(), atom);
    }

    #[test]
    fn compact_srs_weights_recheck_models_and_reject_balanced_rules() {
        let processor = SrsCompactWeightRemovalProcessor { max_weight: 16, canonical: false, summed: false, rational: false, lp: false,
            deadline: Some(Instant::now() + std::time::Duration::from_secs(5)) };
        assert!(matches!(processor.apply(&ProblemState::Srs(unary_trs("aab", "ab"))), ProcessorResult::Applied(_)));
        assert!(matches!(processor.apply(&ProblemState::Srs(unary_trs("ab", "ba"))), ProcessorResult::Inapplicable));
    }

    #[test]
    fn canonical_compact_weights_transport_to_live_names() {
        for (lhs, rhs) in [("aab", "ab"), ("zzy", "zy")] {
            let trs = unary_trs(lhs, rhs);
            let processor = SrsCompactWeightRemovalProcessor { max_weight: 16, canonical: true, summed: false, rational: false, lp: false,
                deadline: Some(Instant::now() + std::time::Duration::from_secs(5)) };
            assert!(matches!(processor.apply(&ProblemState::Srs(trs)), ProcessorResult::Applied(_)));
        }
        let atom = "srs-canonical-compact-weight-removal(max-weight=128)";
        let crate::proving::ProveStrategy::Processor(p) = crate::proving::ProveStrategy::parse(atom).unwrap() else { panic!() };
        assert_eq!(p.to_strategy_atom(), atom);
    }

    #[test]
    fn summed_weights_preserve_weak_obligations_and_strict_progress() {
        let atom = "srs-summed-weight-removal(max-weight=128)";
        let crate::proving::ProveStrategy::Processor(p) = crate::proving::ProveStrategy::parse(atom).unwrap() else { panic!() };
        assert_eq!(p.to_strategy_atom(), atom);
        let processor = SrsCompactWeightRemovalProcessor { max_weight: 16, canonical: true, summed: true, rational: false, lp: false,
            deadline: Some(Instant::now() + std::time::Duration::from_secs(5)) };
        for (lhs, rhs, positive) in [("aab", "ab", true), ("zzy", "zy", true), ("ab", "ba", false), ("a", "aa", false)] {
            assert_eq!(matches!(processor.apply(&ProblemState::Srs(unary_trs(lhs, rhs))), ProcessorResult::Applied(_)), positive);
        }
        let mut rules = unary_trs("aa", "a").unary_srs_rules().unwrap();
        rules.extend(unary_trs("a", "aa").unary_srs_rules().unwrap());
        let symbols = srs_symbols(&rules);
        assert!(synthesize_weights(&rules, &symbols, 16, false, processor.deadline, true, true, false, false, false).is_none());
        let script = compact_weighted_length_script_mode(&rules, &symbols, 16, false, true);
        assert!(!script.contains("(or "));
        assert_eq!(script.matches("(assert (>=").count(), 2);
    }

    #[test]
    fn linear_weights_scale_exact_fractions_and_reject_invalid_models() {
        let symbols = BTreeSet::from(["a".to_string(), "b".to_string()]);
        let model = "sat (model (define-fun sw_a () Real (/ 1.0 3.0)) (define-fun sw_b () Real 0.5))";
        assert_eq!(scaled_real_weights(model, &symbols, 3), Some(BTreeMap::from([("sw_a".to_string(),2),("sw_b".to_string(),3)])));
        assert!(scaled_real_weights(model, &symbols, 2).is_none());
        for invalid in ["(/ 1.0 0.0)", "(- 1.0)", "0.3?", "(/ 1.0)", "1e2"] {
            let model = format!("(model (define-fun sw_a () Real {invalid}) (define-fun sw_b () Real 0.5))");
            assert!(scaled_real_weights(&model, &symbols, 128).is_none(), "{invalid}");
        }
        assert!(scaled_real_weights("(model (define-fun sw_a () Real 1.0))", &symbols, 128).is_none());
    }

    #[test]
    fn linear_weights_synthesize_and_recheck_without_integer_search() {
        let processor = SrsCompactWeightRemovalProcessor { max_weight: 128, canonical: true, summed: true, rational: true, lp: false,
            deadline: Some(Instant::now() + std::time::Duration::from_secs(5)) };
        for (lhs, rhs, positive) in [("aab", "ab", true), ("zzy", "zy", true), ("ab", "ba", false), ("a", "aa", false)] {
            assert_eq!(matches!(processor.apply(&ProblemState::Srs(unary_trs(lhs, rhs))), ProcessorResult::Applied(_)), positive);
        }
        let atom = "srs-linear-weight-removal(max-weight=65536)";
        let crate::proving::ProveStrategy::Processor(p) = crate::proving::ProveStrategy::parse(atom).unwrap() else { panic!() };
        assert_eq!(p.to_strategy_atom(), atom);
    }

    #[test]
    fn linear_weights_normalize_rows_and_cancel_progress_sum() {
        let mut rules = unary_trs("aa", "a").unary_srs_rules().unwrap();
        rules.extend(unary_trs("aaaa", "aa").unary_srs_rules().unwrap());
        rules.extend(unary_trs("a", "aa").unary_srs_rules().unwrap());
        let script = linear_weight_script(&rules, &srs_symbols(&rules), 128, false);
        assert_eq!(script.matches("(assert (>=").count(), 2);
        assert!(script.contains("(assert (> 0 0))"));
        assert!(synthesize_weights(&rules, &srs_symbols(&rules), 128, false,
            Some(Instant::now() + std::time::Duration::from_secs(5)), true, true, true, false, false).is_none());
    }

    #[test]
    fn lp_weights_are_separate_and_exactly_rechecked() {
        let atom = "srs-lp-weight-removal(max-weight=128)";
        let crate::proving::ProveStrategy::Processor(p) = crate::proving::ProveStrategy::parse(atom).unwrap() else { panic!() };
        assert_eq!(p.to_strategy_atom(), atom);
        let strict_atom = "srs-lp-weight-removal(max-weight=128,all-strict=true)";
        let crate::proving::ProveStrategy::Processor(p) = crate::proving::ProveStrategy::parse(strict_atom).unwrap() else { panic!() };
        assert_eq!(p.to_strategy_atom(), strict_atom);
        assert!(crate::proving::ProveStrategy::parse("srs-lp-weight-removal(all-strict=maybe)").is_err());
        let maximal_atom = "srs-lp-weight-removal(max-weight=128,maximal=true)";
        let crate::proving::ProveStrategy::Processor(p) = crate::proving::ProveStrategy::parse(maximal_atom).unwrap() else { panic!() };
        assert_eq!(p.to_strategy_atom(), maximal_atom);
        assert!(crate::proving::ProveStrategy::parse("srs-lp-weight-removal(all-strict=true,maximal=true)").is_err());
        // The optional backend is exercised only when its dependency is present.
        let mut availability = Command::new("python3");
        availability.args(["-c", "import os,sys; p=os.getenv('FERRUM_LP_PYTHONPATH'); sys.path.insert(0,p) if p else None; import highspy"]);
        availability.stdout(Stdio::null()).stderr(Stdio::null());
        if !availability.status().is_ok_and(|status| status.success()) { return; }
        for (lhs, rhs, positive) in [("aab", "ab", true), ("zzy", "zy", true), ("ab", "ba", false), ("a", "aa", false)] {
            let processor = SrsCompactWeightRemovalProcessor { max_weight: 128, canonical: true, summed: true, rational: true, lp: true,
                deadline: Some(Instant::now() + std::time::Duration::from_secs(5)) };
            assert_eq!(matches!(processor.apply(&ProblemState::Srs(unary_trs(lhs, rhs))), ProcessorResult::Applied(_)), positive);
            assert_eq!(matches!(processor.apply_with_strictness(&ProblemState::Srs(unary_trs(lhs, rhs)), true), ProcessorResult::Applied(_)), positive);
        }
        let mut rules = unary_trs("aab", "ab").rules().to_vec();
        rules.extend(unary_trs("b", "bb").rules().iter().cloned());
        let state = ProblemState::Srs(Trs::new(None, BTreeSet::from([Variable::new("x")]), rules));
        let processor = SrsCompactWeightRemovalProcessor { max_weight: 128, canonical: true, summed: true, rational: true, lp: true,
            deadline: Some(Instant::now() + std::time::Duration::from_secs(5)) };
        assert!(matches!(processor.apply(&state), ProcessorResult::Applied(_)));
        assert!(matches!(processor.apply_with_strictness(&state, true), ProcessorResult::Inapplicable));
        for (a,b,c) in [("a","b","c"),("third","first","second")] {
            let text = format!("(format TRS) (fun {a} 1) (fun {b} 1) (fun {c} 1)
                (rule ({a} x) ({b} x)) (rule ({b} x) x) (rule ({c} x) ({c} x))");
            let trs = crate::parsing::parse_ari_trs(None, &text).unwrap();
            let ProcessorResult::Applied(app) = processor.apply_with_objective(&ProblemState::Srs(trs), false, true)
                else { panic!("maximal progress"); };
            let ProblemState::Srs(residual) = &app.residuals[0] else { panic!("SRS residual"); };
            assert_eq!(residual.rules().len(), 1);
            assert_eq!(residual.rules()[0].lhs(), residual.rules()[0].rhs());
        }
    }

    #[test]
    fn canonical_weights_preserve_residuals_under_renaming_and_rule_reordering() {
        let mut residuals = Vec::new();
        for (a, b, reverse) in [("a", "b", false), ("z", "y", true)] {
            let text = format!("(format TRS) (fun {a} 1) (fun {b} 1)
                (rule ({a} ({a} x)) ({b} x)) (rule ({b} ({b} x)) ({a} x))");
            let parsed = crate::parsing::parse_ari_trs(None, &text).unwrap();
            let mut rules = parsed.rules().to_vec();
            if reverse { rules.reverse(); }
            let trs = Trs::new(None, parsed.variables().clone(), rules);
            let ProcessorResult::Applied(app) = (SrsCanonicalWeightRemovalProcessor {
                max_weight: 128, deadline: Some(Instant::now() + std::time::Duration::from_secs(5)),
            }).apply(&ProblemState::Srs(trs.clone())) else { panic!("weights"); };
            let ProblemState::Srs(child) = &app.residuals[0] else { panic!("SRS child"); };
            residuals.push(crate::standardize::standardize_trs(child).unwrap());
            assert!(matches!((SrsCanonicalWeightRemovalProcessor { max_weight: 128,
                deadline: Some(Instant::now()) }).apply(&ProblemState::Srs(trs)), ProcessorResult::TimedOut));
        }
        assert_eq!(residuals[0], residuals[1]);
        let atom = "srs-canonical-weight-removal(max-weight=128)";
        let crate::proving::ProveStrategy::Processor(p) = crate::proving::ProveStrategy::parse(atom).unwrap() else { panic!() };
        assert_eq!(p.to_strategy_atom(), atom);
    }

    #[test]
    fn strict_length_closes_without_a_residual() {
        let result = SrsLengthProcessor.apply(&ProblemState::Srs(unary_trs("ab", "a")));
        let ProcessorResult::Applied(application) = result else {
            panic!("strict length should apply")
        };
        assert!(application.residuals.is_empty());
    }

    #[test]
    fn strict_length_rejects_non_decreasing_rules() {
        assert!(matches!(
            SrsLengthProcessor.apply(&ProblemState::Srs(unary_trs("a", "ab"))),
            ProcessorResult::Inapplicable
        ));
    }
}
