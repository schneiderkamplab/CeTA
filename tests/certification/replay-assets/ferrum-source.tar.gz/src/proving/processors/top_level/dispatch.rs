use std::time::Instant;

use crate::proving::engine::{ProveOptions, ProveStrategyProcessor};
use crate::proving::processors::csr::{
    CsrDependencyPairKind, CsrDependencyPairTransformationProcessor, CsrGmTransformationProcessor,
    CsrInnermostEquivalenceProcessor, CsrLoopProcessor, CsrMatrixRuleRemovalProcessor,
    CsrPolynomialRuleRemovalProcessor,
};
use crate::proving::processors::dp::DpNonterminationProcessor;
use crate::proving::processors::relative::{
    RelativeFlatContextClosureProcessor, RelativeKboRuleRemovalProcessor,
    RelativeMatrixRuleRemovalProcessor, RelativeNonterminationProcessor,
    RelativePathOrderRuleRemovalProcessor, RelativePolynomialRuleRemovalProcessor,
    RelativeSemanticLabelingProcessor,
};
use crate::proving::processors::relative_adp::RelativeAdpTransformationProcessor;

use super::super::{ProblemState, ProcessorResult, WorklistProcessor};
use super::EmptySystemProcessor;
use super::{
    AaeccInnermostProcessor, ConstantToUnaryProcessor, DependencyPairTransformationProcessor,
    ExactDependencyPairTransformationProcessor, ExactNonterminationProofProcessor,
    ExactSrsMatchBoundsProcessor, ExactSrsRelativeMatchBoundsProcessor,
    ExactTerminationProofProcessor, Gm04InverseContextSensitiveProcessor, KboRuleRemovalProcessor,
    MatrixRuleRemovalProcessor, MinimumDeletionPolynomialRuleRemovalProcessor,
    NonterminationProcessor, OutermostRaffelsieperZantemaProcessor, PathOrderRuleRemovalProcessor,
    PolynomialRuleRemovalProcessor, RemoveNonApplicableRulesProcessor, SrsLengthProcessor,
    SrsMatchBoundsProcessor, SrsRelativeMatchBoundsProcessor, SrsRfcMatchBoundsProcessor,
    SrsRfcRelativeMatchBoundsProcessor, SrsWeightedLengthProcessor,
    SrsWeightedRuleRemovalProcessor, StringReversalProcessor, SwitchContextSensitiveProcessor,
    SwitchInnermostProcessor, UncurryProcessor,
};

/// A configured top-level atom. Strategy syntax supplies configuration only;
/// every successful transformation exposes its children to the universal
/// worklist through the ordinary processor interface.
pub(crate) struct ConfiguredTopLevelProcessor<'a> {
    pub processor: &'a ProveStrategyProcessor,
    pub options: &'a ProveOptions,
    pub deadline: Option<Instant>,
}

impl WorklistProcessor for ConfiguredTopLevelProcessor<'_> {
    fn name(&self) -> &'static str {
        "configured-top-level"
    }

    fn apply(&self, state: &ProblemState) -> ProcessorResult {
        let processor = self.processor;
        let options = self.options;
        let deadline = self.deadline;
        match processor {
        ProveStrategyProcessor::Fail => ProcessorResult::Inapplicable,
        ProveStrategyProcessor::ExactTerminationProof {
            source_trs_input_xml,
            termination_proof_xml,
        } => ExactTerminationProofProcessor {
            source_trs_input_xml: source_trs_input_xml.clone(),
            termination_proof_xml: termination_proof_xml.clone(),
        }
        .apply(state),
        ProveStrategyProcessor::ExactNonterminationTerminal { source_trs_input_xml, terminal_xml } => {
            super::exact_proof::apply_nontermination_terminal(state, source_trs_input_xml, terminal_xml)
        }
        ProveStrategyProcessor::ExactNonterminationRuleRemoval { source_trs_input_xml, residual_trs_input_xml } => {
            super::exact_proof::apply_nontermination_rule_removal(state, source_trs_input_xml, residual_trs_input_xml)
        }
        ProveStrategyProcessor::ExactNonterminationProof {
            source_trs_input_xml,
            nontermination_proof_xml,
        } => ExactNonterminationProofProcessor {
            source_trs_input_xml: source_trs_input_xml.clone(),
            nontermination_proof_xml: nontermination_proof_xml.clone(),
        }
        .apply(state),
        ProveStrategyProcessor::CertifiedLinearSequence(processors) => {
            apply_certified_linear_sequence(processors, state, options, deadline)
        }
        ProveStrategyProcessor::RemoveNonApplicableRules => {
            RemoveNonApplicableRulesProcessor.apply(state)
        }
        ProveStrategyProcessor::SrsStripContexts { max_prefix, max_suffix } => {
            super::SrsStripContextsProcessor {
                max_prefix: *max_prefix,
                max_suffix: *max_suffix,
            }.apply(state)
        }
        ProveStrategyProcessor::StringReversal => StringReversalProcessor.apply(state),
        ProveStrategyProcessor::NativeConstantToUnary => {
            super::constant_to_unary::apply_native(state)
        }
        ProveStrategyProcessor::ConstantToUnary { variable, renaming } => {
            ConstantToUnaryProcessor {
                variable: variable.clone(),
                renaming: renaming.clone(),
            }
            .apply(state)
        }
        ProveStrategyProcessor::Nontermination(processor)
            if matches!(
                state,
                ProblemState::RelativeTrs(_) | ProblemState::RelativeSrs(_)
            ) =>
        {
            RelativeNonterminationProcessor {
                processor: processor.clone(),
                deadline,
            }
            .apply(state)
        }
        ProveStrategyProcessor::Nontermination(processor)
            if matches!(state, ProblemState::DependencyPairs(_)) =>
        {
            let native = DpNonterminationProcessor { deadline };
            if matches!(processor, crate::proving::nontermination::NonterminationStrategyProcessor::DependencyPairNonLoop) {
                native.apply_nonloop(state)
            } else if matches!(processor, crate::proving::nontermination::NonterminationStrategyProcessor::DependencyPairSymbolicLoop) {
                native.apply_symbolic_loop(state)
            } else if matches!(processor, crate::proving::nontermination::NonterminationStrategyProcessor::DependencyPairBackwardLoop) {
                native.apply_backward_loop(state)
            } else {
                native.apply(state)
            }
        }
        ProveStrategyProcessor::Nontermination(processor) => NonterminationProcessor {
            processor: processor.clone(),
            deadline,
        }
        .apply(state),
        ProveStrategyProcessor::NonterminationSearch => ProcessorResult::Failed {
            reason: "nontermination search is a scheduler alias, not an atomic processor"
                .to_string(),
        },
        ProveStrategyProcessor::SrsLength => SrsLengthProcessor.apply(state),
        ProveStrategyProcessor::SrsWeightedLength { max_weight } => SrsWeightedLengthProcessor {
            max_weight: *max_weight,
            deadline,
        }
        .apply(state),
        ProveStrategyProcessor::SrsCanonicalWeightRemoval { max_weight } => {
            super::srs::SrsCanonicalWeightRemovalProcessor { max_weight: *max_weight, deadline }.apply(state)
        }
        ProveStrategyProcessor::SrsCompactWeightRemoval { max_weight } => {
            super::srs::SrsCompactWeightRemovalProcessor { max_weight: *max_weight, deadline, canonical: false, summed: false, rational: false, lp: false }.apply(state)
        }
        ProveStrategyProcessor::SrsCanonicalCompactWeightRemoval { max_weight } => {
            super::srs::SrsCompactWeightRemovalProcessor { max_weight: *max_weight, deadline, canonical: true, summed: false, rational: false, lp: false }.apply(state)
        }
        ProveStrategyProcessor::SrsSummedWeightRemoval { max_weight } => {
            super::srs::SrsCompactWeightRemovalProcessor { max_weight: *max_weight, deadline, canonical: true, summed: true, rational: false, lp: false }.apply(state)
        }
        ProveStrategyProcessor::SrsLinearWeightRemoval { max_weight } => {
            super::srs::SrsCompactWeightRemovalProcessor { max_weight: *max_weight, deadline, canonical: true, summed: true, rational: true, lp: false }.apply(state)
        }
        ProveStrategyProcessor::SrsLpWeightRemoval { max_weight, all_strict, maximal } => {
            let processor = super::srs::SrsCompactWeightRemovalProcessor { max_weight: *max_weight, deadline, canonical: true, summed: true, rational: true, lp: true };
            processor.apply_with_objective(state, *all_strict, *maximal)
        }
        ProveStrategyProcessor::SrsWeightedRuleRemoval { max_weight } => {
            SrsWeightedRuleRemovalProcessor {
                max_weight: *max_weight,
                deadline,
            }
            .apply(state)
        }
        ProveStrategyProcessor::SrsMatchBounds {
            max_bound,
            max_states,
            max_transitions,
        } if matches!(state, ProblemState::RelativeSrs(_)) => SrsRelativeMatchBoundsProcessor {
            max_bound: *max_bound,
            max_states: *max_states,
            max_transitions: *max_transitions,
            deadline,
        }
        .apply(state),
        ProveStrategyProcessor::ExactSrsMatchBounds { proof } => ExactSrsMatchBoundsProcessor {
            proof: proof.clone(),
            deadline,
        }
        .apply(state),
        ProveStrategyProcessor::ExactSrsRelativeMatchBounds {
            proof,
            removed_indices,
        } => ExactSrsRelativeMatchBoundsProcessor {
            proof: proof.clone(),
            removed_indices: removed_indices.clone(),
            deadline,
        }
        .apply(state),
        ProveStrategyProcessor::SrsMatchBounds {
            max_bound,
            max_states,
            max_transitions,
        } => SrsMatchBoundsProcessor {
            max_bound: *max_bound,
            max_states: *max_states,
            max_transitions: *max_transitions,
            deadline,
        }
        .apply(state),
        ProveStrategyProcessor::SrsRelativeMatchBoundsRemoval {
            max_bound,
            max_states,
            max_transitions,
        } => SrsRelativeMatchBoundsProcessor {
            max_bound: *max_bound,
            max_states: *max_states,
            max_transitions: *max_transitions,
            deadline,
        }
        .apply(state),
        ProveStrategyProcessor::SrsRelativeMatchBounds {
            max_bound,
            max_states,
            max_transitions,
        } => SrsRelativeMatchBoundsProcessor {
            max_bound: *max_bound,
            max_states: *max_states,
            max_transitions: *max_transitions,
            deadline,
        }
        .apply(state),
        ProveStrategyProcessor::SrsRfcMatchBounds {
            max_bound,
            max_words,
            max_word_len,
            max_states,
            max_transitions,
            at_bound,
            closure,
        } => SrsRfcMatchBoundsProcessor {
            max_bound: *max_bound,
            max_words: *max_words,
            max_word_len: *max_word_len,
            max_states: *max_states,
            max_transitions: *max_transitions,
            at_bound: *at_bound,
            closure: *closure,
            deadline,
        }
        .apply(state),
        ProveStrategyProcessor::SrsRfcRelativeMatchBounds {
            allow_partial,
            absolute_residual,
            layered_seconds,
            fresh_seconds,
            min_bound,
            max_bound,
            max_words,
            max_word_len,
            max_states,
            max_transitions,
            at_bound,
            closure,
        } => SrsRfcRelativeMatchBoundsProcessor {
            allow_partial: *allow_partial,
            absolute_residual: *absolute_residual,
            layered_seconds: *layered_seconds,
            fresh_seconds: *fresh_seconds,
            min_bound: *min_bound,
            max_bound: *max_bound,
            max_words: *max_words,
            max_word_len: *max_word_len,
            max_states: *max_states,
            max_transitions: *max_transitions,
            at_bound: *at_bound,
            closure: *closure,
            deadline,
        }
        .apply(state),
        ProveStrategyProcessor::LinearPolynomial {
            max_constant,
            max_coefficient,
            max_symbols,
            max_arity,
        }
        | ProveStrategyProcessor::SmtLinearPolynomial {
            max_constant,
            max_coefficient,
            max_symbols,
            max_arity,
        } => {
            let mut scoped = options.clone();
            scoped.max_polynomial_constant = *max_constant;
            scoped.max_polynomial_coefficient = *max_coefficient;
            if let Some(value) = max_symbols {
                scoped.max_polynomial_symbols = *value;
            }
            if let Some(value) = max_arity {
                scoped.max_polynomial_arity = *value;
            }
            if matches!(state, ProblemState::Csr(_)) {
                CsrPolynomialRuleRemovalProcessor {
                    options: scoped,
                    exact_interpretation: None,
                    target_strict_rule_indices: None,
                    minimum_delete: None,
                    candidate_index: 0,
                    deadline,
                }
                .apply(state)
            } else if matches!(
                state,
                ProblemState::RelativeTrs(_) | ProblemState::RelativeSrs(_)
            ) {
                RelativePolynomialRuleRemovalProcessor {
                    options: scoped,
                    exact_interpretation: None,
                    target_strict_rule_indices: None,
                    candidate_index: 0,
                    deadline,
                }
                .apply(state)
            } else {
                PolynomialRuleRemovalProcessor {
                    options: scoped,
                    exact_interpretation: None,
                    target_strict_rule_indices: None,
                    exact_removed_rule_indices: None,
                    candidate_index: 0,
                    deadline,
                }
                .apply(state)
            }
        }
        ProveStrategyProcessor::SelectedLinearPolynomial {
            max_constant,
            max_coefficient,
            max_symbols,
            max_arity,
            candidate_index,
        } => {
            let mut scoped = options.clone();
            scoped.max_polynomial_constant = *max_constant;
            scoped.max_polynomial_coefficient = *max_coefficient;
            if let Some(value) = max_symbols {
                scoped.max_polynomial_symbols = *value;
            }
            if let Some(value) = max_arity {
                scoped.max_polynomial_arity = *value;
            }
            if matches!(state, ProblemState::Csr(_)) {
                CsrPolynomialRuleRemovalProcessor {
                    options: scoped,
                    exact_interpretation: None,
                    target_strict_rule_indices: None,
                    minimum_delete: None,
                    candidate_index: *candidate_index,
                    deadline,
                }
                .apply(state)
            } else if matches!(
                state,
                ProblemState::RelativeTrs(_) | ProblemState::RelativeSrs(_)
            ) {
                RelativePolynomialRuleRemovalProcessor {
                    options: scoped,
                    exact_interpretation: None,
                    target_strict_rule_indices: None,
                    candidate_index: *candidate_index,
                    deadline,
                }
                .apply(state)
            } else {
                PolynomialRuleRemovalProcessor {
                    options: scoped,
                    exact_interpretation: None,
                    target_strict_rule_indices: None,
                    exact_removed_rule_indices: None,
                    candidate_index: *candidate_index,
                    deadline,
                }
                .apply(state)
            }
        }
        ProveStrategyProcessor::TargetLinearPolynomial {
            max_constant,
            max_coefficient,
            max_symbols,
            max_arity,
            strict_rule_indices,
        } => {
            let mut scoped = options.clone();
            scoped.max_polynomial_constant = *max_constant;
            scoped.max_polynomial_coefficient = *max_coefficient;
            if let Some(value) = max_symbols {
                scoped.max_polynomial_symbols = *value;
            }
            if let Some(value) = max_arity {
                scoped.max_polynomial_arity = *value;
            }
            if matches!(state, ProblemState::Csr(_)) {
                CsrPolynomialRuleRemovalProcessor {
                    options: scoped,
                    exact_interpretation: None,
                    target_strict_rule_indices: Some(strict_rule_indices.clone()),
                    minimum_delete: None,
                    candidate_index: 0,
                    deadline,
                }
                .apply(state)
            } else if matches!(
                state,
                ProblemState::RelativeTrs(_) | ProblemState::RelativeSrs(_)
            ) {
                RelativePolynomialRuleRemovalProcessor {
                    options: scoped,
                    exact_interpretation: None,
                    target_strict_rule_indices: Some(strict_rule_indices.clone()),
                    candidate_index: 0,
                    deadline,
                }
                .apply(state)
            } else {
                PolynomialRuleRemovalProcessor {
                    options: scoped,
                    exact_interpretation: None,
                    target_strict_rule_indices: Some(strict_rule_indices.clone()),
                    exact_removed_rule_indices: None,
                    candidate_index: 0,
                    deadline,
                }
                .apply(state)
            }
        }
        ProveStrategyProcessor::MinimumDeletionLinearPolynomial {
            max_constant,
            max_coefficient,
            max_symbols,
            max_arity,
            min_delete,
            residual_budget,
        } => {
            let mut scoped = options.clone();
            scoped.max_polynomial_constant = *max_constant;
            scoped.max_polynomial_coefficient = *max_coefficient;
            if let Some(value) = max_symbols {
                scoped.max_polynomial_symbols = *value;
            }
            if let Some(value) = max_arity {
                scoped.max_polynomial_arity = *value;
            }
            if matches!(state, ProblemState::Csr(_)) {
                CsrPolynomialRuleRemovalProcessor {
                    options: scoped,
                    exact_interpretation: None,
                    target_strict_rule_indices: None,
                    minimum_delete: Some((*min_delete, *residual_budget)),
                    candidate_index: 0,
                    deadline,
                }
                .apply(state)
            } else {
                MinimumDeletionPolynomialRuleRemovalProcessor {
                    options: scoped,
                    min_delete: *min_delete,
                    residual_budget: *residual_budget,
                    deadline,
                }
                .apply(state)
            }
        }
        ProveStrategyProcessor::ExactLinearPolynomial { interpretation } => {
            if matches!(state, ProblemState::Csr(_)) {
                CsrPolynomialRuleRemovalProcessor {
                    options: options.clone(),
                    exact_interpretation: Some(interpretation.clone()),
                    target_strict_rule_indices: None,
                    minimum_delete: None,
                    candidate_index: 0,
                    deadline,
                }
                .apply(state)
            } else if matches!(
                state,
                ProblemState::RelativeTrs(_) | ProblemState::RelativeSrs(_)
            ) {
                RelativePolynomialRuleRemovalProcessor {
                    options: options.clone(),
                    exact_interpretation: Some(interpretation.clone()),
                    target_strict_rule_indices: None,
                    candidate_index: 0,
                    deadline,
                }
                .apply(state)
            } else {
                PolynomialRuleRemovalProcessor {
                    options: options.clone(),
                    exact_interpretation: Some(interpretation.clone()),
                    target_strict_rule_indices: None,
                    exact_removed_rule_indices: None,
                    candidate_index: 0,
                    deadline,
                }
                .apply(state)
            }
        }
        ProveStrategyProcessor::ExactSourceBoundOrder { source_trs_input_xml, order_atom } => {
            super::source_bound_order::apply(state, source_trs_input_xml, order_atom, options, deadline)
        }
        ProveStrategyProcessor::ExactLinearPolynomialRemoval {
            interpretation,
            removed_rule_indices,
        } if matches!(state, ProblemState::Trs(_) | ProblemState::Srs(_)) => {
            PolynomialRuleRemovalProcessor {
                options: options.clone(),
                exact_interpretation: Some(interpretation.clone()),
                target_strict_rule_indices: None,
                exact_removed_rule_indices: Some(removed_rule_indices.clone()),
                candidate_index: 0,
                deadline,
            }
            .apply(state)
        }
        ProveStrategyProcessor::ExactLinearPolynomialRemoval { .. } => {
            ProcessorResult::Inapplicable
        }
        ProveStrategyProcessor::MatrixInterpretation {
            dimension,
            max_constant,
            max_coefficient,
            max_symbols,
            max_arity,
        } if matches!(state, ProblemState::Csr(_)) => CsrMatrixRuleRemovalProcessor {
            options: options.clone(),
            dimension: *dimension,
            max_constant: *max_constant,
            max_coefficient: *max_coefficient,
            max_symbols: *max_symbols,
            max_arity: *max_arity,
            exact_interpretation: None,
            deadline,
        }
        .apply(state),
        ProveStrategyProcessor::ExactMatrixInterpretation { interpretation }
            if matches!(state, ProblemState::Csr(_)) =>
        {
            CsrMatrixRuleRemovalProcessor {
                options: options.clone(),
                dimension: interpretation
                    .first()
                    .map_or(1, |(_, constant, _)| constant.len()),
                max_constant: 0,
                max_coefficient: 0,
                max_symbols: None,
                max_arity: None,
                exact_interpretation: Some(interpretation.clone()),
                deadline,
            }
            .apply(state)
        }
        ProveStrategyProcessor::IntegerMatrixInterpretation {
            dimension,
            min_value,
            max_value,
            max_symbols,
            max_arity,
        } if matches!(
            state,
            ProblemState::RelativeTrs(_) | ProblemState::RelativeSrs(_)
        ) => RelativeMatrixRuleRemovalProcessor {
            options: options.clone(),
            dimension: *dimension,
            max_constant: *max_value,
            max_coefficient: *max_value,
            min_value: *min_value,
            max_value: *max_value,
            max_symbols: *max_symbols,
            max_arity: *max_arity,
            exact_interpretation: None,
            domain: crate::proving::dependency_pairs::MatrixDomain::Integers,
            deadline,
        }
        .apply(state),
        ProveStrategyProcessor::MatrixInterpretation {
            dimension,
            max_constant,
            max_coefficient,
            max_symbols,
            max_arity,
        } if matches!(
            state,
            ProblemState::RelativeTrs(_) | ProblemState::RelativeSrs(_)
        ) =>
        {
            RelativeMatrixRuleRemovalProcessor {
                options: options.clone(),
                dimension: *dimension,
                max_constant: *max_constant,
                max_coefficient: *max_coefficient,
                min_value: 0,
                max_value: (*max_constant).max(*max_coefficient),
                max_symbols: *max_symbols,
                max_arity: *max_arity,
                exact_interpretation: None,
                domain: crate::proving::dependency_pairs::MatrixDomain::Naturals,
                deadline,
            }
            .apply(state)
        }
        ProveStrategyProcessor::IntegerMatrixInterpretation {
            dimension,
            min_value,
            max_value,
            max_symbols,
            max_arity,
        } if matches!(
            state,
            ProblemState::RelativeTrs(_) | ProblemState::RelativeSrs(_)
        ) => RelativeMatrixRuleRemovalProcessor {
            options: options.clone(),
            dimension: *dimension,
            max_constant: *max_value,
            max_coefficient: *max_value,
            min_value: *min_value,
            max_value: *max_value,
            max_symbols: *max_symbols,
            max_arity: *max_arity,
            exact_interpretation: None,
            domain: crate::proving::dependency_pairs::MatrixDomain::Integers,
            deadline,
        }
        .apply(state),
        ProveStrategyProcessor::ExactMatrixInterpretation { interpretation }
        | ProveStrategyProcessor::ExactIntegerMatrixInterpretation { interpretation }
            if matches!(
                state,
                ProblemState::RelativeTrs(_) | ProblemState::RelativeSrs(_)
            ) =>
        {
            let domain = if matches!(
                processor,
                ProveStrategyProcessor::ExactIntegerMatrixInterpretation { .. }
            ) {
                crate::proving::dependency_pairs::MatrixDomain::Integers
            } else {
                crate::proving::dependency_pairs::MatrixDomain::Naturals
            };
            RelativeMatrixRuleRemovalProcessor {
                options: options.clone(),
                dimension: interpretation
                    .first()
                    .map_or(1, |(_, constant, _)| constant.len()),
                max_constant: 0,
                max_coefficient: 0,
                min_value: 0,
                max_value: 0,
                max_symbols: None,
                max_arity: None,
                exact_interpretation: Some(interpretation.clone()),
                domain,
                deadline,
            }
            .apply(state)
        }
        ProveStrategyProcessor::Kbo {
            max_weight,
            max_symbols,
        } if matches!(
            state,
            ProblemState::RelativeTrs(_) | ProblemState::RelativeSrs(_)
        ) =>
        {
            RelativeKboRuleRemovalProcessor {
                max_weight: *max_weight,
                max_symbols: *max_symbols,
                exact_witness: None,
                deadline,
            }
            .apply(state)
        }
        ProveStrategyProcessor::Kbo {
            max_weight,
            max_symbols,
        } => KboRuleRemovalProcessor {
            max_weight: *max_weight,
            max_symbols: *max_symbols,
            exact_witness: None,
            deadline,
        }
        .apply(state),
        ProveStrategyProcessor::ExactKbo {
            precedence,
            precedence_ranks,
            weights,
        } if matches!(
            state,
            ProblemState::RelativeTrs(_) | ProblemState::RelativeSrs(_)
        ) =>
        {
            RelativeKboRuleRemovalProcessor {
                max_weight: 0,
                max_symbols: 0,
                exact_witness: Some((
                    precedence.clone(),
                    precedence_ranks.clone(),
                    weights.clone(),
                )),
                deadline,
            }
            .apply(state)
        }
        ProveStrategyProcessor::ExactKbo {
            precedence,
            precedence_ranks,
            weights,
        } => KboRuleRemovalProcessor {
            max_weight: 0,
            max_symbols: 0,
            exact_witness: Some((
                precedence.clone(),
                precedence_ranks.clone(),
                weights.clone(),
            )),
            deadline,
        }
        .apply(state),
        ProveStrategyProcessor::MatrixInterpretation {
            dimension,
            max_constant,
            max_coefficient,
            max_symbols,
            max_arity,
        } => MatrixRuleRemovalProcessor {
            options: options.clone(),
            dimension: *dimension,
            max_constant: *max_constant,
            max_coefficient: *max_coefficient,
            min_value: 0,
            max_value: (*max_constant).max(*max_coefficient),
            max_symbols: *max_symbols,
            max_arity: *max_arity,
            exact_interpretation: None,
            domain: crate::proving::dependency_pairs::MatrixDomain::Naturals,
            deadline,
        }
        .apply(state),
        ProveStrategyProcessor::IntegerMatrixInterpretation {
            dimension,
            min_value,
            max_value,
            max_symbols,
            max_arity,
        } => MatrixRuleRemovalProcessor {
            options: options.clone(),
            dimension: *dimension,
            max_constant: *max_value,
            max_coefficient: *max_value,
            min_value: *min_value,
            max_value: *max_value,
            max_symbols: *max_symbols,
            max_arity: *max_arity,
            exact_interpretation: None,
            domain: crate::proving::dependency_pairs::MatrixDomain::Integers,
            deadline,
        }
        .apply(state),
        ProveStrategyProcessor::ExactMatrixInterpretation { interpretation }
        | ProveStrategyProcessor::ExactIntegerMatrixInterpretation { interpretation } => {
            let domain = if matches!(
                processor,
                ProveStrategyProcessor::ExactIntegerMatrixInterpretation { .. }
            ) {
                crate::proving::dependency_pairs::MatrixDomain::Integers
            } else {
                crate::proving::dependency_pairs::MatrixDomain::Naturals
            };
            MatrixRuleRemovalProcessor {
                options: options.clone(),
                dimension: interpretation
                    .first()
                    .map_or(1, |(_, constant, _)| constant.len()),
                max_constant: 0,
                max_coefficient: 0,
                min_value: 0,
                max_value: 0,
                max_symbols: None,
                max_arity: None,
                exact_interpretation: Some(interpretation.clone()),
                domain,
                deadline,
            }
            .apply(state)
        }
        ProveStrategyProcessor::PathOrder { max_symbols }
            if matches!(
                state,
                ProblemState::RelativeTrs(_) | ProblemState::RelativeSrs(_)
            ) =>
        {
            RelativePathOrderRuleRemovalProcessor {
                max_symbols: *max_symbols,
                exact_witness: None,
                deadline,
            }
            .apply(state)
        }
        ProveStrategyProcessor::PathOrder { max_symbols } => PathOrderRuleRemovalProcessor {
            source_trs_input_xml: None,
            shared_encoding: false,
            max_symbols: *max_symbols,
            exact_witness: None,
            exact_removed_rule_indices: None,
            deadline,
        }
        .apply(state),
        ProveStrategyProcessor::SharedPathOrder { max_symbols } => PathOrderRuleRemovalProcessor {
            source_trs_input_xml: None,
            shared_encoding: true,
            max_symbols: *max_symbols,
            exact_witness: None,
            exact_removed_rule_indices: None,
            deadline,
        }.apply(state),
        ProveStrategyProcessor::ExactPathOrder {
            statuses,
            precedence,
            precedence_ranks,
            argument_filter,
        } if matches!(
            state,
            ProblemState::RelativeTrs(_) | ProblemState::RelativeSrs(_)
        ) =>
        {
            RelativePathOrderRuleRemovalProcessor {
                max_symbols: 0,
                exact_witness: Some((
                    statuses.clone(),
                    precedence.clone(),
                    precedence_ranks.clone(),
                    argument_filter.clone(),
                )),
                deadline,
            }
            .apply(state)
        }
        ProveStrategyProcessor::ExactPathOrder {
            statuses,
            precedence,
            precedence_ranks,
            argument_filter,
        } => PathOrderRuleRemovalProcessor {
            source_trs_input_xml: None,
            shared_encoding: false,
            max_symbols: 0,
            exact_witness: Some((
                statuses.clone(),
                precedence.clone(),
                precedence_ranks.clone(),
                argument_filter.clone(),
            )),
            exact_removed_rule_indices: None,
            deadline,
        }
        .apply(state),
        ProveStrategyProcessor::ExactPathOrderRemoval {
            source_trs_input_xml,
            statuses,
            precedence,
            precedence_ranks,
            argument_filter,
            removed_rule_indices,
        } if matches!(state, ProblemState::Trs(_) | ProblemState::Srs(_)) => {
            PathOrderRuleRemovalProcessor {
                shared_encoding: false,
                source_trs_input_xml: source_trs_input_xml.clone(),
                max_symbols: 0,
                exact_witness: Some((
                    statuses.clone(),
                    precedence.clone(),
                    precedence_ranks.clone(),
                    argument_filter.clone(),
                )),
                exact_removed_rule_indices: Some(removed_rule_indices.clone()),
                deadline,
            }
            .apply(state)
        }
        ProveStrategyProcessor::ExactPathOrderRemoval { .. } => ProcessorResult::Inapplicable,
        ProveStrategyProcessor::RelativeFlatContextClosure => {
            RelativeFlatContextClosureProcessor.apply(state)
        }
        ProveStrategyProcessor::SrsContextClosure { depth } => {
            crate::proving::processors::relative::SrsContextClosureProcessor { depth: *depth }.apply(state)
        }
        ProveStrategyProcessor::SrsShiftLabeling { memory } => {
            crate::proving::processors::relative::SrsShiftLabelingProcessor { memory: *memory, deadline }.apply(state)
        }
        ProveStrategyProcessor::SrsWeightedLabeling { carrier_size, max_weight, strict_percent } => {
            crate::proving::processors::relative::SrsWeightedLabelingProcessor {
                carrier_size: *carrier_size, max_weight: *max_weight, strict_percent: *strict_percent, deadline,
            }.apply(state)
        }
        ProveStrategyProcessor::TrsRootLabeling => super::root_labeling::TrsRootLabelingProcessor { deadline }.apply(state),
        ProveStrategyProcessor::RelativeAnnotatedDependencyPairs => {
            RelativeAdpTransformationProcessor.apply(state)
        }
        ProveStrategyProcessor::RelativeSemanticLabeling { carrier_size } => {
            crate::proving::processors::relative::SynthesizingRelativeSemanticLabelingProcessor {
                carrier_size: *carrier_size,
                deadline,
            }
            .apply(state)
        }
        ProveStrategyProcessor::ExactRelativeSemanticLabeling {
            carrier_size,
            interpretations,
        } => RelativeSemanticLabelingProcessor {
            carrier_size: *carrier_size,
            interpretations: interpretations.clone(),
            deadline,
        }
        .apply(state),
        ProveStrategyProcessor::SwitchInnermost => SwitchInnermostProcessor.apply(state),
        ProveStrategyProcessor::AaeccInnermost => AaeccInnermostProcessor.apply(state),
        ProveStrategyProcessor::OutermostRaffelsieperZantema => {
            OutermostRaffelsieperZantemaProcessor.apply(state)
        }
        ProveStrategyProcessor::SwitchContextSensitive => {
            SwitchContextSensitiveProcessor.apply(state)
        }
        ProveStrategyProcessor::Gm04InverseContextSensitive => {
            Gm04InverseContextSensitiveProcessor {
                options: options.dp_options.clone(),
                full_termination: false,
            }
            .apply(state)
        }
        ProveStrategyProcessor::Gm04InverseContextSensitiveFull => {
            Gm04InverseContextSensitiveProcessor {
                options: options.dp_options.clone(),
                full_termination: true,
            }
            .apply(state)
        }
        ProveStrategyProcessor::CsrLoop => CsrLoopProcessor { deadline }.apply(state),
        ProveStrategyProcessor::CsrInnermostEquivalence => CsrInnermostEquivalenceProcessor {
            options: options.dp_options.clone(),
            rta08: false,
        }
        .apply(state),
        ProveStrategyProcessor::CsrInnermostEquivalenceWithStrategy(strategy) => {
            let mut dp_options = options.dp_options.clone();
            dp_options.strategy = Some(strategy.clone());
            CsrInnermostEquivalenceProcessor {
                options: dp_options,
                rta08: false,
            }
            .apply(state)
        }
        ProveStrategyProcessor::CsrInnermostRta08Equivalence => CsrInnermostEquivalenceProcessor {
            options: options.dp_options.clone(),
            rta08: true,
        }
        .apply(state),
        ProveStrategyProcessor::CsrInnermostRta08EquivalenceWithStrategy(strategy) => {
            let mut dp_options = options.dp_options.clone();
            dp_options.strategy = Some(strategy.clone());
            CsrInnermostEquivalenceProcessor {
                options: dp_options,
                rta08: true,
            }
            .apply(state)
        }
        ProveStrategyProcessor::CsrGmTransformation => CsrGmTransformationProcessor {
            options: options.dp_options.clone(),
            strategy: None,
        }
        .apply(state),
        ProveStrategyProcessor::CsrGmTransformationWithStrategy(strategy) => {
            CsrGmTransformationProcessor {
                options: options.dp_options.clone(),
                strategy: Some(strategy.clone()),
            }
            .apply(state)
        }
        ProveStrategyProcessor::Uncurry => UncurryProcessor.apply(state),
        ProveStrategyProcessor::UncurryRole { role } => super::UncurryRoleProcessor { role: *role }.apply(state),
        ProveStrategyProcessor::DependencyPairs
        | ProveStrategyProcessor::DependencyPairsWithStrategy(_) => {
            let mut dp_options = options.dp_options.clone();
            if let ProveStrategyProcessor::DependencyPairsWithStrategy(strategy) = processor {
                dp_options.strategy = Some(strategy.clone());
            }
            if matches!(state, ProblemState::Csr(_)) {
                ProcessorResult::Failed {
                    reason: "`dp` is an ordinary dependency-pair atom; CSR requires an explicit csr-*-dp atom".to_string(),
                }
            } else {
                DependencyPairTransformationProcessor {
                    options: dp_options,
                }
                .apply(state)
            }
        }
        ProveStrategyProcessor::InnermostLhssDependencyPairs => {
            super::InnermostLhssDependencyPairTransformationProcessor {
                options: options.dp_options.clone(),
            }.apply(state)
        }
        ProveStrategyProcessor::TrimmedDependencyPairs
        | ProveStrategyProcessor::TrimmedDependencyPairsWithStrategy(_) => {
            let mut dp_options = options.dp_options.clone();
            if let ProveStrategyProcessor::TrimmedDependencyPairsWithStrategy(strategy) = processor {
                dp_options.strategy = Some(strategy.clone());
            }
            super::dependency_pairs::apply_trimmed_dependency_pairs(state, dp_options)
        }
        ProveStrategyProcessor::ExactDependencyPairs { dp_input_xml } => {
            ExactDependencyPairTransformationProcessor {
                options: options.dp_options.clone(),
                dp_input_xml: dp_input_xml.clone(),
                nontermination_q_increase: false,
            }
            .apply(state)
        }
        ProveStrategyProcessor::ExactInnermostLhssDependencyPairs { dp_input_xml } => {
            ExactDependencyPairTransformationProcessor {
                options: options.dp_options.clone(),
                dp_input_xml: dp_input_xml.clone(),
                nontermination_q_increase: true,
            }
            .apply(state)
        }
        ProveStrategyProcessor::SafeCsrDependencyPairs
        | ProveStrategyProcessor::SafeCsrDependencyPairsWithStrategy(_)
        | ProveStrategyProcessor::ImprovedCsrDependencyPairs
        | ProveStrategyProcessor::ImprovedCsrDependencyPairsWithStrategy(_)
        | ProveStrategyProcessor::MutermUnhidingCsrDependencyPairs
        | ProveStrategyProcessor::MutermUnhidingCsrDependencyPairsWithStrategy(_)
        | ProveStrategyProcessor::MutermExpandedCsrDependencyPairs
        | ProveStrategyProcessor::MutermExpandedCsrDependencyPairsWithStrategy(_)
        | ProveStrategyProcessor::InnermostCsrDependencyPairs
        | ProveStrategyProcessor::InnermostCsrDependencyPairsWithStrategy(_)
        | ProveStrategyProcessor::Rta08CsrDependencyPairs
        | ProveStrategyProcessor::Rta08CsrDependencyPairsWithStrategy(_)
        | ProveStrategyProcessor::NativeContextSensitiveCsrDependencyPairs
        | ProveStrategyProcessor::NativeContextSensitiveCsrDependencyPairsWithStrategy(_)
        | ProveStrategyProcessor::NativeOrdinaryCsrDependencyPairs
        | ProveStrategyProcessor::NativeOrdinaryCsrDependencyPairsWithStrategy(_)
        | ProveStrategyProcessor::ConservativeCsrDependencyPairs
        | ProveStrategyProcessor::ConservativeCsrDependencyPairsWithStrategy(_) => {
            let mut dp_options = options.dp_options.clone();
            dp_options.strategy = match processor {
                ProveStrategyProcessor::SafeCsrDependencyPairsWithStrategy(strategy)
                | ProveStrategyProcessor::ImprovedCsrDependencyPairsWithStrategy(strategy)
                | ProveStrategyProcessor::MutermUnhidingCsrDependencyPairsWithStrategy(strategy)
                | ProveStrategyProcessor::MutermExpandedCsrDependencyPairsWithStrategy(strategy)
                | ProveStrategyProcessor::InnermostCsrDependencyPairsWithStrategy(strategy)
                | ProveStrategyProcessor::Rta08CsrDependencyPairsWithStrategy(strategy)
                | ProveStrategyProcessor::NativeContextSensitiveCsrDependencyPairsWithStrategy(strategy)
                | ProveStrategyProcessor::NativeOrdinaryCsrDependencyPairsWithStrategy(strategy)
                | ProveStrategyProcessor::ConservativeCsrDependencyPairsWithStrategy(strategy) => {
                    Some(strategy.clone())
                }
                _ => None,
            };
            let kind = match processor {
                ProveStrategyProcessor::SafeCsrDependencyPairs
                | ProveStrategyProcessor::SafeCsrDependencyPairsWithStrategy(_) => {
                    CsrDependencyPairKind::Safe
                }
                ProveStrategyProcessor::ImprovedCsrDependencyPairs
                | ProveStrategyProcessor::ImprovedCsrDependencyPairsWithStrategy(_) => {
                    CsrDependencyPairKind::Improved
                }
                ProveStrategyProcessor::MutermUnhidingCsrDependencyPairs
                | ProveStrategyProcessor::MutermUnhidingCsrDependencyPairsWithStrategy(_) => {
                    CsrDependencyPairKind::MutermUnhiding
                }
                ProveStrategyProcessor::MutermExpandedCsrDependencyPairs
                | ProveStrategyProcessor::MutermExpandedCsrDependencyPairsWithStrategy(_) => {
                    CsrDependencyPairKind::MutermExpanded
                }
                ProveStrategyProcessor::InnermostCsrDependencyPairs
                | ProveStrategyProcessor::InnermostCsrDependencyPairsWithStrategy(_) => {
                    CsrDependencyPairKind::Innermost
                }
                ProveStrategyProcessor::Rta08CsrDependencyPairs
                | ProveStrategyProcessor::Rta08CsrDependencyPairsWithStrategy(_) => {
                    CsrDependencyPairKind::Rta08
                }
                ProveStrategyProcessor::NativeContextSensitiveCsrDependencyPairs
                | ProveStrategyProcessor::NativeContextSensitiveCsrDependencyPairsWithStrategy(_) => {
                    CsrDependencyPairKind::NativeContextSensitive
                }
                ProveStrategyProcessor::NativeOrdinaryCsrDependencyPairs
                | ProveStrategyProcessor::NativeOrdinaryCsrDependencyPairsWithStrategy(_) => {
                    CsrDependencyPairKind::NativeOrdinary
                }
                ProveStrategyProcessor::ConservativeCsrDependencyPairs
                | ProveStrategyProcessor::ConservativeCsrDependencyPairsWithStrategy(_) => {
                    CsrDependencyPairKind::Conservative
                }
                _ => unreachable!(),
            };
            CsrDependencyPairTransformationProcessor {
                kind,
                options: dp_options,
            }
            .apply(state)
        }
    }
    }
}

fn apply_certified_linear_sequence(
    processors: &[ProveStrategyProcessor],
    initial: &ProblemState,
    options: &ProveOptions,
    deadline: Option<Instant>,
) -> ProcessorResult {
    let mut state = initial.clone();
    let mut reconstructions = Vec::with_capacity(processors.len());
    for processor in processors {
        if deadline.is_some_and(|limit| Instant::now() >= limit)
            || !matches!(
                processor,
                ProveStrategyProcessor::ExactLinearPolynomial { .. }
                    | ProveStrategyProcessor::ExactMatrixInterpretation { .. }
            )
        {
            return ProcessorResult::Inapplicable;
        }
        let ProcessorResult::Applied(application) = (ConfiguredTopLevelProcessor {
            processor,
            options,
            deadline,
        })
        .apply(&state) else {
            return ProcessorResult::Inapplicable;
        };
        let (residuals, reconstruction) = application.into_parts();
        let Ok([residual]) = <[ProblemState; 1]>::try_from(residuals) else {
            return ProcessorResult::Inapplicable;
        };
        state = residual;
        reconstructions.push(reconstruction);
    }
    let ProcessorResult::Applied(empty) = EmptySystemProcessor.apply(&state) else {
        return ProcessorResult::Inapplicable;
    };
    let Some(mut certificate) = empty.reconstruct(Vec::new()) else {
        return ProcessorResult::Inapplicable;
    };
    for reconstruction in reconstructions.into_iter().rev() {
        let Some(parent) = reconstruction.reconstruct(vec![certificate]) else {
            return ProcessorResult::Inapplicable;
        };
        certificate = parent;
    }
    ProcessorResult::Applied(
        super::super::ProcessorApplication::solved(certificate).with_selected_atom(
            ProveStrategyProcessor::CertifiedLinearSequence(processors.to_vec()).to_strategy_atom(),
        ),
    )
}

#[cfg(test)]
mod tests {
    use std::collections::{BTreeMap, BTreeSet};

    use crate::core::{CsrTrs, ReplacementMap, RewriteRule, Symbol, Term, Trs, Variable};
    use crate::proving::dependency_pairs::DpStrategy;
    use crate::proving::engine::{ProveOptions, ProveStrategy, ProveStrategyProcessor};
    use crate::proving::processors::{
        CsrProblemState, ProblemState, ProcessorResult, WorklistProcessor,
    };

    use super::ConfiguredTopLevelProcessor;

    fn simple_trs() -> Trs {
        Trs::new(
            None,
            BTreeSet::from([Variable::new("x")]),
            vec![RewriteRule::new(
                Term::app("f", vec![Term::var("x")]),
                Term::app("f", vec![Term::app("g", vec![Term::var("x")])]),
            )],
        )
    }

    fn configured<'a>(
        processor: &'a ProveStrategyProcessor,
        options: &'a ProveOptions,
    ) -> ConfiguredTopLevelProcessor<'a> {
        ConfiguredTopLevelProcessor {
            processor,
            options,
            deadline: None,
        }
    }

    #[test]
    fn nested_dp_recipe_is_carried_by_materialized_state() {
        let expected = DpStrategy::parse("graph; size-change").unwrap();
        let processor = ProveStrategyProcessor::DependencyPairsWithStrategy(expected.clone());
        let ProcessorResult::Applied(application) =
            configured(&processor, &ProveOptions::default())
                .apply(&ProblemState::Trs(simple_trs()))
        else {
            panic!("configured DP transformation was not applied");
        };
        let [ProblemState::DependencyPairs(child)] = application.residuals.as_slice() else {
            panic!("configured DP transformation did not materialize a DP child");
        };
        assert_eq!(child.options.strategy.as_ref(), Some(&expected));
    }

    #[test]
    fn nested_csr_and_gm_recipes_are_carried_by_materialized_states() {
        let trs = Trs::new(
            None,
            BTreeSet::from([Variable::new("x")]),
            vec![
                RewriteRule::new(
                    Term::app("f", vec![Term::var("x")]),
                    Term::app("f", vec![Term::app("g", vec![Term::var("x")])]),
                ),
                RewriteRule::new(Term::app("g", vec![Term::var("x")]), Term::app("a", vec![])),
            ],
        );
        let csr = CsrTrs::new(
            trs,
            ReplacementMap::new(BTreeMap::from([
                (Symbol::new("f"), BTreeSet::from([0])),
                (Symbol::new("g"), BTreeSet::from([0])),
                (Symbol::new("a"), BTreeSet::new()),
            ])),
        )
        .unwrap();
        let root = ProblemState::Csr(CsrProblemState::root(csr));
        let options = ProveOptions::default();
        let expected = DpStrategy::parse("graph; size-change").unwrap();

        for recipe in [
            "csr-improved-dp(graph; size-change)",
            "csr-gm-transform(graph; size-change)",
        ] {
            let ProveStrategy::Processor(processor) = ProveStrategy::parse(recipe).unwrap() else {
                panic!("recipe did not parse as one configured processor: {recipe}");
            };
            let ProcessorResult::Applied(application) =
                configured(&processor, &options).apply(&root)
            else {
                panic!("configured CSR transformation was not applied: {recipe}");
            };
            let [ProblemState::DependencyPairs(child)] = application.residuals.as_slice() else {
                panic!("configured CSR transformation did not materialize a DP child: {recipe}");
            };
            assert_eq!(
                child.options.strategy.as_ref(),
                Some(&expected),
                "lost nested recipe for {recipe}"
            );
        }
    }
}
