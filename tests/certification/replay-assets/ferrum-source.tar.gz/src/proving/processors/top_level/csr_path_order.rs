//! Context-sensitive recursive path-order witness discovery.
//!
//! This module deliberately starts with the multiset-status fragment of
//! Borralleras--Lucas--Rubio CSRPO.  It is useful on its own and, more
//! importantly, gives us an exact executable specification against which the
//! certificate checker can be developed.  Results from this module are not
//! promoted until the corresponding CeTA-CSR processor accepts the witness.

use std::collections::{BTreeMap, BTreeSet};
use std::time::{Duration, Instant};

use crate::core::{CsrTrs, Term};

use super::smt::{command_exists, parse_integer_values, run_script};

#[derive(Clone, Debug, Eq, PartialEq)]
pub(crate) struct CsrPathOrderWitness {
    pub(crate) unmarked_ranks: BTreeMap<String, usize>,
    pub(crate) marked_ranks: BTreeMap<String, usize>,
    /// `(is_marked, symbol)` entries with lexicographic status. CSRPO assigns
    /// status on the extended signature, so a symbol and its marked copy may
    /// differ when their precedence is strict.
    pub(crate) lexicographic: BTreeSet<(bool, String)>,
    /// `(parent_is_marked, parent, zero_based_position) -> marked roots`.
    pub(crate) marking: BTreeMap<(bool, String, usize), BTreeSet<String>>,
}

#[derive(Clone, Debug, Eq, Ord, PartialEq, PartialOrd)]
enum Aterm {
    Var {
        name: String,
        label: Vec<String>,
    },
    App {
        symbol: usize,
        marked: String,
        args: Vec<Aterm>,
    },
}

pub(crate) fn synthesize_csr_path_order(
    csr: &CsrTrs,
    allowance: Duration,
) -> Option<CsrPathOrderWitness> {
    let deadline = Instant::now() + allowance;
    let arities = csr.trs().arities();
    let symbols = arities
        .keys()
        .map(|s| s.as_str().to_string())
        .collect::<Vec<_>>();
    if symbols.is_empty() || symbols.len() > 40 {
        return None;
    }
    let indices = symbols
        .iter()
        .enumerate()
        .map(|(index, symbol)| (symbol.clone(), index))
        .collect::<BTreeMap<_, _>>();
    let arity = symbols
        .iter()
        .map(|symbol| {
            let key = arities.keys().find(|key| key.as_str() == symbol)?;
            Some(*arities.get(key)?)
        })
        .collect::<Option<Vec<_>>>()?;

    let mut script = String::from("(set-logic QF_LIA)\n");
    let max_rank = symbols.len().checked_mul(2)?.checked_sub(1)?;
    for index in 0..symbols.len() {
        for marked in [false, true] {
            let status = status_name(index, marked);
            script.push_str(&format!(
                "(declare-const {status} Int)\n(assert (or (= {status} 0) (= {status} 1)))\n"
            ));
            let rank = rank_name(index, marked);
            script.push_str(&format!(
                "(declare-const {rank} Int)\n(assert (and (>= {rank} 0) (<= {rank} {max_rank})))\n"
            ));
        }
        script.push_str(&format!(
            "(assert (=> (= {} {}) (= {} {})))\n",
            rank_name(index, false),
            rank_name(index, true),
            status_name(index, false),
            status_name(index, true)
        ));
    }
    for left in 0..symbols.len() {
        for right in (left + 1)..symbols.len() {
            for left_marked in [false, true] {
                for right_marked in [false, true] {
                    script.push_str(&format!(
                        "(assert (=> (= {} {}) (= {} {})))\n",
                        rank_name(left, left_marked),
                        rank_name(right, right_marked),
                        status_name(left, left_marked),
                        status_name(right, right_marked)
                    ));
                }
            }
        }
    }

    for (parent, parent_arity) in arity.iter().copied().enumerate() {
        for parent_marked in [false, true] {
            for position in 0..parent_arity {
                for target in 0..symbols.len() {
                    let mark = mark_name(parent, parent_marked, position, target);
                    script.push_str(&format!(
                        "(declare-const {mark} Int)\n(assert (or (= {mark} 0) (= {mark} 1)))\n"
                    ));
                    if csr.replacement_map().is_allowed(
                        arities.keys().find(|key| key.as_str() == symbols[parent])?,
                        position,
                    ) {
                        script.push_str(&format!("(assert (= {mark} 0))\n"));
                    }
                }
            }
        }
        for position in 0..parent_arity {
            for target in 0..symbols.len() {
                script.push_str(&format!(
                    "(assert (<= {} {}))\n",
                    mark_name(parent, false, position, target),
                    mark_name(parent, true, position, target)
                ));
            }
        }
        // Every unmarked symbol is at least as large as its marked copy.
        script.push_str(&format!(
            "(assert (<= {} {}))\n",
            rank_name(parent, false),
            rank_name(parent, true)
        ));
    }

    let mut encoder = Encoder {
        symbols: &symbols,
        arities: &arity,
        indices: &indices,
        deadline,
        definitions: String::new(),
        comparisons: BTreeMap::new(),
        next_comparison: 0,
    };
    let mut rules = Vec::new();
    for rule in csr.rules() {
        let lhs = encoder.annotate(rule.lhs())?;
        let rhs = encoder.annotate(rule.rhs())?;
        rules.push(encoder.gt(&lhs, &rhs)?);
    }
    script.push_str(&encoder.definitions);
    for (index, rule) in rules.into_iter().enumerate() {
        script.push_str(&format!("(assert (! {rule} :named csrpo_rule_{index}))\n"));
    }
    script.push_str("(check-sat)\n(get-model)\n");

    let solver = command_exists("z3")
        .then_some("z3")
        .or_else(|| command_exists("cvc5").then_some("cvc5"))?;
    let output = run_script(&script, solver, Some(deadline))?;
    if output
        .lines()
        .map(str::trim)
        .find(|line| !line.is_empty())?
        != "sat"
    {
        return None;
    }
    let values = parse_integer_values(&output)?;
    let mut witness = CsrPathOrderWitness {
        unmarked_ranks: BTreeMap::new(),
        marked_ranks: BTreeMap::new(),
        lexicographic: BTreeSet::new(),
        marking: BTreeMap::new(),
    };
    for (index, symbol) in symbols.iter().enumerate() {
        witness.unmarked_ranks.insert(
            symbol.clone(),
            usize::try_from(*values.get(&rank_name(index, false))?).ok()?,
        );
        witness.marked_ranks.insert(
            symbol.clone(),
            usize::try_from(*values.get(&rank_name(index, true))?).ok()?,
        );
        for marked in [false, true] {
            if values
                .get(&status_name(index, marked))
                .copied()
                .unwrap_or(0)
                == 1
            {
                witness.lexicographic.insert((marked, symbol.clone()));
            }
        }
        for parent_marked in [false, true] {
            for position in 0..arity[index] {
                let marked = symbols
                    .iter()
                    .enumerate()
                    .filter(|(target, _)| {
                        values
                            .get(&mark_name(index, parent_marked, position, *target))
                            .copied()
                            .unwrap_or(0)
                            == 1
                    })
                    .map(|(_, target)| target.clone())
                    .collect();
                witness
                    .marking
                    .insert((parent_marked, symbol.clone(), position), marked);
            }
        }
    }
    validate_csr_path_order(csr, &witness).then_some(witness)
}

#[derive(Clone, Debug, Eq, PartialEq)]
enum Cterm {
    Var {
        name: String,
        label: BTreeSet<usize>,
    },
    App {
        symbol: usize,
        marked: bool,
        args: Vec<Cterm>,
    },
}

pub(crate) fn validate_csr_path_order(csr: &CsrTrs, witness: &CsrPathOrderWitness) -> bool {
    let arities = csr.trs().arities();
    let symbols = arities
        .keys()
        .map(|s| s.as_str().to_string())
        .collect::<Vec<_>>();
    let indices = symbols
        .iter()
        .enumerate()
        .map(|(index, symbol)| (symbol.clone(), index))
        .collect::<BTreeMap<_, _>>();
    let arity = symbols
        .iter()
        .map(|symbol| {
            arities
                .iter()
                .find(|(key, _)| key.as_str() == symbol)
                .map(|(_, arity)| *arity)
        })
        .collect::<Option<Vec<_>>>();
    let Some(arity) = arity else { return false };
    let checker = ConcreteOrder {
        csr,
        witness,
        symbols: &symbols,
        indices: &indices,
        arities: &arity,
    };
    if !checker.valid_marking_pair() {
        return false;
    }
    csr.rules().iter().all(|rule| {
        let Some(lhs) = checker.annotate(rule.lhs()) else {
            return false;
        };
        let Some(rhs) = checker.annotate(rule.rhs()) else {
            return false;
        };
        checker.gt(&lhs, &rhs)
    })
}

struct ConcreteOrder<'a> {
    csr: &'a CsrTrs,
    witness: &'a CsrPathOrderWitness,
    symbols: &'a [String],
    indices: &'a BTreeMap<String, usize>,
    arities: &'a [usize],
}

impl ConcreteOrder<'_> {
    fn annotate(&self, term: &Term) -> Option<Cterm> {
        match term {
            Term::Var(variable) => Some(Cterm::Var {
                name: variable.as_str().to_string(),
                label: BTreeSet::new(),
            }),
            Term::App { symbol, args } => Some(Cterm::App {
                symbol: *self.indices.get(symbol.as_str())?,
                marked: false,
                args: args
                    .iter()
                    .map(|arg| self.annotate(arg))
                    .collect::<Option<_>>()?,
            }),
        }
    }

    fn valid_marking_pair(&self) -> bool {
        for (symbol, arity) in self.arities.iter().copied().enumerate() {
            let Some(unmarked_rank) = self.witness.unmarked_ranks.get(&self.symbols[symbol]) else {
                return false;
            };
            let Some(marked_rank) = self.witness.marked_ranks.get(&self.symbols[symbol]) else {
                return false;
            };
            if unmarked_rank > marked_rank {
                return false;
            }
            for position in 0..arity {
                let unmarked = self.mark_set(symbol, false, position);
                let marked = self.mark_set(symbol, true, position);
                if !unmarked.is_subset(&marked) {
                    return false;
                }
                let core_arities = self.csr.trs().arities();
                let core_symbol = core_arities
                    .keys()
                    .find(|candidate| candidate.as_str() == self.symbols[symbol]);
                if core_symbol.is_some_and(|core| {
                    self.csr.replacement_map().is_allowed(core, position)
                        && (!unmarked.is_empty() || !marked.is_empty())
                }) {
                    return false;
                }
            }
        }
        for left in 0..self.symbols.len() {
            for right in 0..self.symbols.len() {
                for left_marked in [false, true] {
                    for right_marked in [false, true] {
                        if self.rank(left, left_marked) == self.rank(right, right_marked)
                            && self.is_lex(left, left_marked) != self.is_lex(right, right_marked)
                        {
                            return false;
                        }
                    }
                }
            }
        }
        true
    }

    fn rank(&self, symbol: usize, marked: bool) -> usize {
        let ranks = if marked {
            &self.witness.marked_ranks
        } else {
            &self.witness.unmarked_ranks
        };
        ranks
            .get(&self.symbols[symbol])
            .copied()
            .unwrap_or(usize::MAX)
    }

    fn is_lex(&self, symbol: usize, marked: bool) -> bool {
        self.witness
            .lexicographic
            .contains(&(marked, self.symbols[symbol].clone()))
    }

    fn mark_set(&self, parent: usize, marked: bool, position: usize) -> BTreeSet<usize> {
        self.witness
            .marking
            .get(&(marked, self.symbols[parent].clone(), position))
            .into_iter()
            .flatten()
            .filter_map(|symbol| self.indices.get(symbol).copied())
            .collect()
    }

    fn mt(&self, term: &Cterm, marking: BTreeSet<usize>) -> Cterm {
        match term {
            Cterm::Var { name, .. } => Cterm::Var {
                name: name.clone(),
                label: marking,
            },
            Cterm::App {
                symbol,
                marked,
                args,
            } => Cterm::App {
                symbol: *symbol,
                marked: *marked || marking.contains(symbol),
                args: args.clone(),
            },
        }
    }

    fn marked_args(&self, symbol: usize, marked: bool, args: &[Cterm]) -> Vec<Cterm> {
        args.iter()
            .enumerate()
            .map(|(position, arg)| self.mt(arg, self.mark_set(symbol, marked, position)))
            .collect()
    }

    fn equiv(&self, lhs: &Cterm, rhs: &Cterm) -> bool {
        match (lhs, rhs) {
            (
                Cterm::Var {
                    name: left,
                    label: left_label,
                },
                Cterm::Var {
                    name: right,
                    label: right_label,
                },
            ) => left == right && left_label.is_subset(right_label),
            (
                Cterm::App {
                    symbol: ls,
                    marked: lm,
                    args: la,
                },
                Cterm::App {
                    symbol: rs,
                    marked: rm,
                    args: ra,
                },
            ) if la.len() == ra.len() && self.rank(*ls, *lm) == self.rank(*rs, *rm) => self
                .marked_args(*ls, *lm, la)
                .iter()
                .zip(self.marked_args(*rs, *rm, ra))
                .all(|(left, right)| self.equiv(left, &right)),
            _ => false,
        }
    }

    fn ge(&self, lhs: &Cterm, rhs: &Cterm) -> bool {
        self.equiv(lhs, rhs) || self.gt(lhs, rhs)
    }

    fn gt(&self, lhs: &Cterm, rhs: &Cterm) -> bool {
        match (lhs, rhs) {
            (_, Cterm::Var { name, label }) => self.stable(lhs, name, label),
            (Cterm::Var { .. }, Cterm::App { .. }) => false,
            (
                Cterm::App {
                    symbol: ls,
                    marked: lm,
                    args: la,
                },
                Cterm::App {
                    symbol: rs,
                    marked: rm,
                    args: ra,
                },
            ) => {
                if self
                    .marked_args(*ls, *lm, la)
                    .iter()
                    .any(|arg| self.ge(arg, rhs))
                {
                    return true;
                }
                let rhs_args = self.marked_args(*rs, *rm, ra);
                if !rhs_args.iter().all(|arg| self.gt(lhs, arg)) {
                    return false;
                }
                if self.rank(*ls, *lm) < self.rank(*rs, *rm) {
                    return true;
                }
                if self.rank(*ls, *lm) != self.rank(*rs, *rm) {
                    return false;
                }
                let lhs_args = self.marked_args(*ls, *lm, la);
                if self.is_lex(*ls, *lm) {
                    self.lex_gt(&lhs_args, &rhs_args)
                } else {
                    self.multiset_gt(&lhs_args, &rhs_args)
                }
            }
        }
    }

    fn stable(&self, term: &Cterm, variable: &str, label: &BTreeSet<usize>) -> bool {
        contains_cvariable(term, variable)
            && (0..self.symbols.len())
                .all(|symbol| label.contains(&symbol) || self.safe(term, variable, symbol))
    }

    fn safe(&self, term: &Cterm, variable: &str, target: usize) -> bool {
        match term {
            Cterm::Var { name, label } => name == variable && !label.contains(&target),
            Cterm::App {
                symbol,
                marked,
                args,
            } => {
                args.iter().enumerate().any(|(position, arg)| {
                    contains_cvariable(arg, variable)
                        && self.safe(
                            &self.mt(arg, self.mark_set(*symbol, *marked, position)),
                            variable,
                            target,
                        )
                }) || (((self.rank(*symbol, *marked) < self.rank(target, false))
                    || (self.rank(*symbol, *marked) == self.rank(target, false)
                        && !self.is_lex(*symbol, *marked)
                        && !self.is_lex(target, false)))
                    && (0..self.arities[target]).all(|position| {
                        self.mark_set(target, false, position)
                            == self.mark_set(target, true, position)
                    }))
            }
        }
    }

    fn lex_gt(&self, lhs: &[Cterm], rhs: &[Cterm]) -> bool {
        (0..lhs.len().min(rhs.len())).any(|index| {
            (0..index).all(|prefix| self.equiv(&lhs[prefix], &rhs[prefix]))
                && self.gt(&lhs[index], &rhs[index])
        })
    }

    fn multiset_gt(&self, lhs: &[Cterm], rhs: &[Cterm]) -> bool {
        (1usize..(1usize << lhs.len()))
            .any(|removed| self.multiset_match(lhs, rhs, removed, 0, &mut vec![false; rhs.len()]))
    }

    fn multiset_match(
        &self,
        lhs: &[Cterm],
        rhs: &[Cterm],
        removed: usize,
        lhs_index: usize,
        used_rhs: &mut [bool],
    ) -> bool {
        if lhs_index == lhs.len() {
            return rhs.iter().enumerate().all(|(right_index, right)| {
                used_rhs[right_index]
                    || lhs.iter().enumerate().any(|(left_index, left)| {
                        removed & (1usize << left_index) != 0 && self.gt(left, right)
                    })
            });
        }
        if removed & (1usize << lhs_index) != 0 {
            return self.multiset_match(lhs, rhs, removed, lhs_index + 1, used_rhs);
        }
        for right_index in 0..rhs.len() {
            if used_rhs[right_index] || !self.equiv(&lhs[lhs_index], &rhs[right_index]) {
                continue;
            }
            used_rhs[right_index] = true;
            if self.multiset_match(lhs, rhs, removed, lhs_index + 1, used_rhs) {
                used_rhs[right_index] = false;
                return true;
            }
            used_rhs[right_index] = false;
        }
        false
    }
}

fn contains_cvariable(term: &Cterm, variable: &str) -> bool {
    match term {
        Cterm::Var { name, .. } => name == variable,
        Cterm::App { args, .. } => args.iter().any(|arg| contains_cvariable(arg, variable)),
    }
}

struct Encoder<'a> {
    symbols: &'a [String],
    arities: &'a [usize],
    indices: &'a BTreeMap<String, usize>,
    deadline: Instant,
    definitions: String,
    comparisons: BTreeMap<(Aterm, Aterm), String>,
    next_comparison: usize,
}

impl Encoder<'_> {
    fn annotate(&self, term: &Term) -> Option<Aterm> {
        match term {
            Term::Var(variable) => Some(Aterm::Var {
                name: variable.as_str().to_string(),
                label: vec!["false".to_string(); self.symbols.len()],
            }),
            Term::App { symbol, args } => Some(Aterm::App {
                symbol: *self.indices.get(symbol.as_str())?,
                marked: "false".to_string(),
                args: args
                    .iter()
                    .map(|arg| self.annotate(arg))
                    .collect::<Option<_>>()?,
            }),
        }
    }

    fn timed_out(&self) -> bool {
        Instant::now() >= self.deadline
    }

    fn gt(&mut self, lhs: &Aterm, rhs: &Aterm) -> Option<String> {
        if self.timed_out() {
            return None;
        }
        if let Some(name) = self.comparisons.get(&(lhs.clone(), rhs.clone())) {
            return Some(name.clone());
        }
        let name = format!("csgt_{}", self.next_comparison);
        self.next_comparison += 1;
        self.comparisons
            .insert((lhs.clone(), rhs.clone()), name.clone());
        self.definitions
            .push_str(&format!("(declare-const {name} Bool)\n"));
        let definition = self.gt_definition(lhs, rhs)?;
        self.definitions
            .push_str(&format!("(assert (= {name} {definition}))\n"));
        Some(name)
    }

    fn ge(&mut self, lhs: &Aterm, rhs: &Aterm) -> Option<String> {
        Some(or(vec![self.equiv(lhs, rhs)?, self.gt(lhs, rhs)?]))
    }

    fn gt_definition(&mut self, lhs: &Aterm, rhs: &Aterm) -> Option<String> {
        match (lhs, rhs) {
            (_, Aterm::Var { name, label }) => self.stable(lhs, name, label),
            (Aterm::Var { .. }, Aterm::App { .. }) => Some("false".to_string()),
            (
                Aterm::App {
                    symbol: ls,
                    marked: lm,
                    args: la,
                },
                Aterm::App {
                    symbol: rs,
                    marked: rm,
                    args: ra,
                },
            ) => {
                let mut cases = Vec::new();
                for (position, arg) in la.iter().enumerate() {
                    let marked_arg = self.mt(arg, self.mark_set(*ls, lm, position));
                    cases.push(self.ge(&marked_arg, rhs)?);
                }
                let rhs_args = ra
                    .iter()
                    .enumerate()
                    .map(|(position, arg)| self.mt(arg, self.mark_set(*rs, rm, position)))
                    .collect::<Vec<_>>();
                let dominates = and(rhs_args
                    .iter()
                    .map(|arg| self.gt(lhs, arg))
                    .collect::<Option<_>>()?);
                cases.push(and(vec![
                    dominates.clone(),
                    format!("(< {} {})", self.rank(*ls, lm), self.rank(*rs, rm)),
                ]));
                let lhs_args = la
                    .iter()
                    .enumerate()
                    .map(|(position, arg)| self.mt(arg, self.mark_set(*ls, lm, position)))
                    .collect::<Vec<_>>();
                cases.push(and(vec![
                    dominates,
                    format!("(= {} {})", self.rank(*ls, lm), self.rank(*rs, rm)),
                    or(vec![
                        and(vec![
                            format!("(= {} 0)", self.status(*ls, lm)),
                            self.multiset_gt(&lhs_args, &rhs_args)?,
                        ]),
                        and(vec![
                            format!("(= {} 1)", self.status(*ls, lm)),
                            self.lex_gt(&lhs_args, &rhs_args)?,
                        ]),
                    ]),
                ]));
                Some(or(cases))
            }
        }
    }

    fn equiv(&mut self, lhs: &Aterm, rhs: &Aterm) -> Option<String> {
        match (lhs, rhs) {
            (
                Aterm::Var {
                    name: ln,
                    label: ll,
                },
                Aterm::Var {
                    name: rn,
                    label: rl,
                },
            ) if ln == rn => Some(and(ll
                .iter()
                .zip(rl)
                .map(|(left, right)| format!("(=> {left} {right})"))
                .collect())),
            (Aterm::Var { .. }, _) | (_, Aterm::Var { .. }) => Some("false".to_string()),
            (
                Aterm::App {
                    symbol: ls,
                    marked: lm,
                    args: la,
                },
                Aterm::App {
                    symbol: rs,
                    marked: rm,
                    args: ra,
                },
            ) if la.len() == ra.len() => {
                let mut clauses =
                    vec![format!("(= {} {})", self.rank(*ls, lm), self.rank(*rs, rm))];
                for position in 0..la.len() {
                    let left = self.mt(&la[position], self.mark_set(*ls, lm, position));
                    let right = self.mt(&ra[position], self.mark_set(*rs, rm, position));
                    clauses.push(self.equiv(&left, &right)?);
                }
                Some(and(clauses))
            }
            _ => Some("false".to_string()),
        }
    }

    fn stable(&mut self, term: &Aterm, variable: &str, label: &[String]) -> Option<String> {
        if !contains_variable(term, variable) {
            return Some("false".to_string());
        }
        Some(and(label
            .iter()
            .enumerate()
            .map(|(symbol, marked)| {
                Some(or(vec![marked.clone(), self.safe(term, variable, symbol)?]))
            })
            .collect::<Option<_>>()?))
    }

    fn safe(&mut self, term: &Aterm, variable: &str, target: usize) -> Option<String> {
        match term {
            Aterm::Var { name, label } if name == variable => {
                Some(format!("(not {})", label[target]))
            }
            Aterm::Var { .. } => Some("false".to_string()),
            Aterm::App {
                symbol,
                marked,
                args,
            } => {
                let mut cases = Vec::new();
                for (position, arg) in args.iter().enumerate() {
                    if contains_variable(arg, variable) {
                        let marked_arg = self.mt(arg, self.mark_set(*symbol, marked, position));
                        cases.push(self.safe(&marked_arg, variable, target)?);
                    }
                }
                let same_marking = and((0..self.arities[target])
                    .flat_map(|position| {
                        (0..self.symbols.len()).map(move |root| {
                            format!(
                                "(= {} {})",
                                mark_name(target, false, position, root),
                                mark_name(target, true, position, root)
                            )
                        })
                    })
                    .collect());
                cases.push(and(vec![
                    same_marking,
                    or(vec![
                        format!(
                            "(< {} {})",
                            self.rank(*symbol, marked),
                            rank_name(target, false)
                        ),
                        and(vec![
                            format!(
                                "(= {} {})",
                                self.rank(*symbol, marked),
                                rank_name(target, false)
                            ),
                            format!("(= {} 0)", self.status(*symbol, marked)),
                            format!("(= {} 0)", status_name(target, false)),
                        ]),
                    ]),
                ]));
                Some(or(cases))
            }
        }
    }

    fn mt(&self, term: &Aterm, marking: Vec<String>) -> Aterm {
        match term {
            Aterm::Var { name, .. } => Aterm::Var {
                name: name.clone(),
                label: marking,
            },
            Aterm::App {
                symbol,
                marked,
                args,
            } => Aterm::App {
                symbol: *symbol,
                marked: or(vec![marked.clone(), marking[*symbol].clone()]),
                args: args.clone(),
            },
        }
    }

    fn mark_set(&self, parent: usize, marked: &str, position: usize) -> Vec<String> {
        (0..self.symbols.len())
            .map(|target| {
                format!(
                    "(ite {marked} (= {} 1) (= {} 1))",
                    mark_name(parent, true, position, target),
                    mark_name(parent, false, position, target)
                )
            })
            .collect()
    }

    fn rank(&self, symbol: usize, marked: &str) -> String {
        format!(
            "(ite {marked} {} {})",
            rank_name(symbol, true),
            rank_name(symbol, false)
        )
    }

    fn status(&self, symbol: usize, marked: &str) -> String {
        format!(
            "(ite {marked} {} {})",
            status_name(symbol, true),
            status_name(symbol, false)
        )
    }

    fn multiset_gt(&mut self, lhs: &[Aterm], rhs: &[Aterm]) -> Option<String> {
        let mut cases = Vec::new();
        for removed in 1usize..(1usize << lhs.len()) {
            cases.extend(self.multiset_match(lhs, rhs, removed, 0, &mut vec![false; rhs.len()])?);
        }
        Some(or(cases))
    }

    fn lex_gt(&mut self, lhs: &[Aterm], rhs: &[Aterm]) -> Option<String> {
        let mut cases = Vec::new();
        for index in 0..lhs.len().min(rhs.len()) {
            let mut clauses = Vec::new();
            for prefix in 0..index {
                clauses.push(self.equiv(&lhs[prefix], &rhs[prefix])?);
            }
            clauses.push(self.gt(&lhs[index], &rhs[index])?);
            cases.push(and(clauses));
        }
        Some(or(cases))
    }

    fn multiset_match(
        &mut self,
        lhs: &[Aterm],
        rhs: &[Aterm],
        removed: usize,
        lhs_index: usize,
        used_rhs: &mut [bool],
    ) -> Option<Vec<String>> {
        if lhs_index == lhs.len() {
            let removed_terms = lhs
                .iter()
                .enumerate()
                .filter(|(index, _)| removed & (1usize << index) != 0)
                .map(|(_, term)| term)
                .collect::<Vec<_>>();
            let mut clauses = Vec::new();
            for (index, right) in rhs.iter().enumerate() {
                if !used_rhs[index] {
                    clauses.push(or(removed_terms
                        .iter()
                        .map(|left| self.gt(left, right))
                        .collect::<Option<_>>()?));
                }
            }
            return Some(vec![and(clauses)]);
        }
        if removed & (1usize << lhs_index) != 0 {
            return self.multiset_match(lhs, rhs, removed, lhs_index + 1, used_rhs);
        }
        let mut cases = Vec::new();
        for rhs_index in 0..rhs.len() {
            if used_rhs[rhs_index] {
                continue;
            }
            used_rhs[rhs_index] = true;
            for rest in self.multiset_match(lhs, rhs, removed, lhs_index + 1, used_rhs)? {
                cases.push(and(vec![
                    self.equiv(&lhs[lhs_index], &rhs[rhs_index])?,
                    rest,
                ]));
            }
            used_rhs[rhs_index] = false;
        }
        Ok::<_, ()>(cases).ok()
    }
}

fn contains_variable(term: &Aterm, variable: &str) -> bool {
    match term {
        Aterm::Var { name, .. } => name == variable,
        Aterm::App { args, .. } => args.iter().any(|arg| contains_variable(arg, variable)),
    }
}

fn rank_name(symbol: usize, marked: bool) -> String {
    format!("csrpo_r_{}_{}", if marked { "m" } else { "u" }, symbol)
}

fn status_name(symbol: usize, marked: bool) -> String {
    format!("csrpo_s_{}_{}", if marked { "m" } else { "u" }, symbol)
}

fn mark_name(parent: usize, marked: bool, position: usize, target: usize) -> String {
    format!(
        "csrpo_m_{}_{}_{}_{}",
        if marked { "m" } else { "u" },
        parent,
        position,
        target
    )
}

fn and(parts: Vec<String>) -> String {
    match parts.as_slice() {
        [] => "true".to_string(),
        [part] => part.clone(),
        _ => format!("(and {})", parts.join(" ")),
    }
}

fn or(parts: Vec<String>) -> String {
    match parts.as_slice() {
        [] => "false".to_string(),
        [part] => part.clone(),
        _ => format!("(or {})", parts.join(" ")),
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::parsing::parse_ari_cstrs;

    #[test]
    fn finds_published_from_sel_witness() {
        let input = r#"
            (format CSTRS)
            (fun |0| 0 :replacement-map ())
            (fun s 1 :replacement-map ())
            (fun cons 2 :replacement-map ())
            (fun from 1 :replacement-map ())
            (fun sel 2 :replacement-map (1 2))
            (rule (from X) (cons X (from (s X))))
            (rule (sel |0| (cons X Y)) X)
            (rule (sel (s X) (cons Y Z)) (sel X Z))
        "#;
        let csr = parse_ari_cstrs(Some("from-sel".to_string()), input).unwrap();
        let witness = synthesize_csr_path_order(&csr, Duration::from_secs(10))
            .expect("published from/sel CSRPO witness");
        assert!(
            witness
                .marking
                .get(&(false, "cons".to_string(), 1))
                .is_some_and(|roots| roots.contains("from"))
        );
    }

    #[test]
    fn finds_published_from_witness() {
        let input = r#"
            (format CSTRS)
            (fun s 1 :replacement-map ())
            (fun cons 2 :replacement-map ())
            (fun from 1 :replacement-map ())
            (rule (from X) (cons X (from (s X))))
        "#;
        let csr = parse_ari_cstrs(Some("from".to_string()), input).unwrap();
        assert!(synthesize_csr_path_order(&csr, Duration::from_secs(10)).is_some());
    }

    #[test]
    fn ex5_7_luc97_has_no_witness_in_the_checked_csrpo_fragment() {
        let input =
            include_str!("../../../../../TPDB-ARI/TRS_Contextsensitive/CSR_04/Ex5_7_Luc97.ari");
        let csr = parse_ari_cstrs(Some("Ex5_7_Luc97".to_string()), input).unwrap();
        assert!(synthesize_csr_path_order(&csr, Duration::from_secs(60)).is_none());
    }
}
