mod aaecc_innermost;
mod constant_to_unary;
pub(crate) mod csr_path_order;
mod dependency_pairs;
mod dispatch;
mod empty;
mod exact_dependency_pairs;
mod exact_proof;
mod source_bound_order;
pub(crate) mod kbo;
mod matrix;
mod nontermination;
mod root_labeling;
mod outermost_rz;
pub(crate) mod path_order;
pub(crate) mod polynomial;
mod remove_non_applicable;
pub(crate) mod smt;
mod solver;
pub(crate) use solver::serialized_problem_state;
pub(crate) mod srs;
mod strategy_atom;
mod string_reversal;
mod srs_strip_contexts;
mod switch_context_sensitive;
mod switch_innermost;
mod uncurry;
pub(crate) mod uncurrying;

pub use aaecc_innermost::AaeccInnermostProcessor;
pub use constant_to_unary::ConstantToUnaryProcessor;
pub use dependency_pairs::{DependencyPairTransformationProcessor, InnermostLhssDependencyPairTransformationProcessor};
pub(crate) use dispatch::ConfiguredTopLevelProcessor;
pub use empty::EmptySystemProcessor;
pub use exact_dependency_pairs::ExactDependencyPairTransformationProcessor;
pub use exact_proof::{ExactNonterminationProofProcessor, ExactTerminationProofProcessor};
pub use kbo::KboRuleRemovalProcessor;
pub use matrix::MatrixRuleRemovalProcessor;
pub use nontermination::NonterminationProcessor;
pub use outermost_rz::OutermostRaffelsieperZantemaProcessor;
pub use path_order::PathOrderRuleRemovalProcessor;
pub use polynomial::{
    MinimumDeletionPolynomialRuleRemovalProcessor, PolynomialRuleRemovalProcessor,
};
pub use remove_non_applicable::RemoveNonApplicableRulesProcessor;
#[cfg(test)]
pub(crate) use remove_non_applicable::remove_non_applicable_rules;
pub(crate) use solver::solve_top_level_worklist;
pub use srs::{
    ExactSrsMatchBoundsProcessor, ExactSrsRelativeMatchBoundsProcessor, SrsLengthProcessor,
    SrsMatchAtBound, SrsMatchBoundsProcessor, SrsRelativeMatchBoundsProcessor, SrsRfcBarrenClosure,
    SrsRfcMatchBoundsProcessor, SrsRfcRelativeMatchBoundsProcessor, SrsWeightedLengthProcessor,
    SrsWeightedRuleRemovalProcessor,
};
pub use string_reversal::StringReversalProcessor;
pub use srs_strip_contexts::SrsStripContextsProcessor;
pub use switch_context_sensitive::{
    Gm04InverseContextSensitiveProcessor, SwitchContextSensitiveProcessor,
};
pub use switch_innermost::SwitchInnermostProcessor;
pub use uncurry::{UncurryProcessor, UncurryRoleProcessor};
