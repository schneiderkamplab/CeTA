use std::time::Instant;

use super::automaton::{
    SrsMatchAtBound, SrsRfcBarrenClosure, synthesize_srs_rfc_relative_match_bounds_removal,
};
use crate::proving::{Proof, ProofStep, Status};
use crate::core::RelativeTrs;

use super::super::super::{
    ProblemCertificate, ProblemState, ProcessorApplication, ProcessorResult, WorklistProcessor,
};

/// One RFC-relative match-bounds deletion.
///
/// The certificate bounds deleted-rule steps on the forward-closure language.
/// The legacy checker requires the reverse relative residual: remaining rules
/// are strict, deleted rules weak. The explicitly selected absolute mode uses
/// the additional verified forward-closure/absolute-residual theorem instead.
pub struct SrsRfcRelativeMatchBoundsProcessor {
    pub allow_partial: bool,
    pub absolute_residual: bool,
    pub layered_seconds: u64,
    pub fresh_seconds: u64,
    pub min_bound: usize,
    pub max_bound: usize,
    pub max_words: usize,
    pub max_word_len: usize,
    pub max_states: usize,
    pub max_transitions: usize,
    pub at_bound: SrsMatchAtBound,
    pub closure: SrsRfcBarrenClosure,
    pub deadline: Option<Instant>,
}

impl WorklistProcessor for SrsRfcRelativeMatchBoundsProcessor {
    fn name(&self) -> &'static str {
        "srs-rfc-relative-match-bounds"
    }

    fn apply(&self, state: &ProblemState) -> ProcessorResult {
        let ProblemState::Srs(trs) = state else {
            return ProcessorResult::Inapplicable;
        };
        let Some(removal) = synthesize_srs_rfc_relative_match_bounds_removal(
            trs,
            self.allow_partial,
            self.layered_seconds,
            self.fresh_seconds,
            self.min_bound,
            self.max_bound,
            self.max_words,
            self.max_word_len,
            self.max_states,
            self.max_transitions,
            self.at_bound,
            self.closure,
            self.deadline,
        ) else {
            return if self.deadline.is_some_and(|limit| Instant::now() >= limit) {
                ProcessorResult::TimedOut
            } else {
                ProcessorResult::Inapplicable
            };
        };
        // The absolute continuation requires the separately verified RFC
        // forward-closure/absolute-residual theorem, not reverse-relative SN.
        if self.absolute_residual && !removal.automaton_closed {
            return ProcessorResult::Inapplicable;
        }
        let absolute_residual = self.absolute_residual;
        let residual = if absolute_residual {
            ProblemState::Srs(removal.remaining)
        } else { ProblemState::RelativeSrs(RelativeTrs::new(
            removal.remaining, removal.removed.clone(),
        )) };
        ProcessorResult::Applied(ProcessorApplication::new(vec![residual], move |children| {
            let [ProblemCertificate::Trs(proof)] =
                <[ProblemCertificate; 1]>::try_from(children).ok()?
            else {
                return None;
            };
            if proof.status() != &Status::Terminating {
                return None;
            }
            let step = if removal.automaton_closed {
                ProofStep::RfcMatchboxRelativeBounds {
                    absolute_residual,
                    proof: removal.proof.clone(),
                    initial_words: removal.initial_words.clone(),
                    removed: removal.removed.clone(),
                    proof_after_removal: Box::new(proof),
                }
            } else {
                ProofStep::RfcRelativeBounds {
                    proof: removal.proof.clone(),
                    initial_words: removal.initial_words.clone(),
                    removed: removal.removed.clone(),
                    proof_after_removal: Box::new(proof),
                }
            };
            Some(ProblemCertificate::Trs(Proof::terminating(vec![step])))
        }))
    }
}
