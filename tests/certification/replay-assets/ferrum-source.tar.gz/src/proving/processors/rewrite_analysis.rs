use std::collections::{BTreeMap, BTreeSet};
use std::time::{Duration, Instant};

use crate::core::{
    CsrTrs, RewriteRule, RewriteStrategy, Substitution, Term, Trs, Variable, match_pattern,
};
use crate::proving::runtime::current_thread_cancelled;

const MAX_REACHABLE_TERMS: usize = usize::MAX;
const WEAK_CONFLUENCE_BUDGET: Duration = Duration::from_secs(1);

pub(crate) fn switch_innermost_wcr_depth(trs: &Trs) -> Option<usize> {
    if !is_overlay_trs(trs) {
        return None;
    }
    weak_confluence_witness_depth(trs)
}

/// Compute the Giesl--Arts (AAECC) decomposition used to reduce full
/// termination to innermost termination (Theorem 16).  The returned witness
/// is deliberately explicit: certification must recheck the partition and
/// signature separation instead of trusting this construction.
pub(crate) fn aaecc_innermost_witness(
    trs: &Trs,
) -> Option<(
    Vec<RewriteRule>,
    Vec<RewriteRule>,
    BTreeSet<crate::core::Symbol>,
    usize,
)> {
    let mut non_sigma = BTreeSet::new();
    let mut r1 = Vec::new();
    let mut r2 = Vec::new();
    for rule in trs.rules() {
        let Some(right_root) = rule.rhs().root_symbol() else {
            r1.push(rule.clone());
            collect_symbols(rule.lhs(), &mut non_sigma);
            collect_symbols(rule.rhs(), &mut non_sigma);
            continue;
        };
        let left_root = rule.lhs().root_symbol()?;
        if non_sigma.contains(left_root) || non_sigma.contains(right_root) {
            r1.push(rule.clone());
            collect_symbols(rule.lhs(), &mut non_sigma);
            collect_symbols(rule.rhs(), &mut non_sigma);
        } else {
            r2.push(rule.clone());
            collect_symbols_below_root(rule.lhs(), &mut non_sigma);
            collect_symbols_below_root(rule.rhs(), &mut non_sigma);
        }
    }

    loop {
        let mut changed = false;
        let mut retained = Vec::with_capacity(r2.len());
        for rule in r2 {
            let left_root = rule.lhs().root_symbol()?;
            let right_root = rule.rhs().root_symbol()?;
            if non_sigma.contains(left_root) || non_sigma.contains(right_root) {
                changed |= non_sigma.insert(left_root.clone());
                changed |= non_sigma.insert(right_root.clone());
                r1.push(rule);
            } else {
                retained.push(rule);
            }
        }
        r2 = retained;
        if !changed {
            break;
        }
    }
    if r2.is_empty() {
        return None;
    }

    let mut all_symbols = BTreeSet::new();
    for rule in trs.rules() {
        collect_symbols(rule.lhs(), &mut all_symbols);
        collect_symbols(rule.rhs(), &mut all_symbols);
    }
    let sigma = all_symbols
        .difference(&non_sigma)
        .cloned()
        .collect::<BTreeSet<_>>();
    if !valid_aaecc_partition(trs, &r1, &r2, &sigma) {
        return None;
    }

    let r1_trs = Trs::new_with_strategy(
        trs.name().map(str::to_string),
        trs.variables().clone(),
        r1.clone(),
        RewriteStrategy::Full,
    );
    let wcr_depth = weak_confluence_witness_depth(&r1_trs)?;
    if rules_have_cross_overlap(&r2, &r1) {
        return None;
    }
    Some((r1, r2, sigma, wcr_depth))
}

/// Whether a rule from `inner` overlaps a non-variable position of the
/// left-hand side of a rule from `outer`.  This is the exact directed
/// critical-pair side condition used by the published AAECC theorem:
/// `critical_pairs outer inner = {}`.  Variables are renamed apart before
/// unification, and root overlaps are intentionally included.
pub(crate) fn rules_have_cross_overlap(outer: &[RewriteRule], inner: &[RewriteRule]) -> bool {
    outer.iter().enumerate().any(|(outer_index, outer_rule)| {
        let outer_rule = rename_rule_variables(outer_rule, &format!("o{outer_index}_"));
        inner.iter().enumerate().any(|(inner_index, inner_rule)| {
            let inner_rule = rename_rule_variables(inner_rule, &format!("i{inner_index}_"));
            positions_with_subterms(outer_rule.lhs())
                .into_iter()
                .filter(|(_, subterm)| !matches!(subterm, Term::Var(_)))
                .any(|(_, subterm)| {
                    let mut substitution = Substitution::new();
                    unify_terms(inner_rule.lhs(), subterm, &mut substitution)
                })
        })
    })
}

fn valid_aaecc_partition(
    trs: &Trs,
    r1: &[RewriteRule],
    r2: &[RewriteRule],
    sigma: &BTreeSet<crate::core::Symbol>,
) -> bool {
    let mut union = r1.to_vec();
    union.extend_from_slice(r2);
    if !same_rule_multiset(&union, trs.rules()) {
        return false;
    }
    if r1.iter().any(|rule| {
        term_contains_any_symbol(rule.lhs(), sigma) || term_contains_any_symbol(rule.rhs(), sigma)
    }) {
        return false;
    }
    r2.iter().all(|rule| {
        let (Some(left_root), Some(right_root)) =
            (rule.lhs().root_symbol(), rule.rhs().root_symbol())
        else {
            return false;
        };
        sigma.contains(left_root)
            && sigma.contains(right_root)
            && !term_below_root_contains_any_symbol(rule.lhs(), sigma)
            && !term_below_root_contains_any_symbol(rule.rhs(), sigma)
    })
}

fn same_rule_multiset(left: &[RewriteRule], right: &[RewriteRule]) -> bool {
    if left.len() != right.len() {
        return false;
    }
    let mut used = vec![false; right.len()];
    left.iter().all(|rule| {
        let Some(index) = right
            .iter()
            .enumerate()
            .position(|(index, candidate)| !used[index] && candidate == rule)
        else {
            return false;
        };
        used[index] = true;
        true
    })
}

fn collect_symbols(term: &Term, symbols: &mut BTreeSet<crate::core::Symbol>) {
    if let Term::App { symbol, args } = term {
        symbols.insert(symbol.clone());
        for arg in args {
            collect_symbols(arg, symbols);
        }
    }
}

fn collect_symbols_below_root(term: &Term, symbols: &mut BTreeSet<crate::core::Symbol>) {
    if let Term::App { args, .. } = term {
        for arg in args {
            collect_symbols(arg, symbols);
        }
    }
}

fn term_contains_any_symbol(term: &Term, symbols: &BTreeSet<crate::core::Symbol>) -> bool {
    match term {
        Term::Var(_) => false,
        Term::App { symbol, args } => {
            symbols.contains(symbol)
                || args
                    .iter()
                    .any(|arg| term_contains_any_symbol(arg, symbols))
        }
    }
}

fn term_below_root_contains_any_symbol(
    term: &Term,
    symbols: &BTreeSet<crate::core::Symbol>,
) -> bool {
    match term {
        Term::Var(_) => false,
        Term::App { args, .. } => args
            .iter()
            .any(|arg| term_contains_any_symbol(arg, symbols)),
    }
}

pub(crate) fn weak_confluence_witness_depth(trs: &Trs) -> Option<usize> {
    let deadline = Instant::now() + WEAK_CONFLUENCE_BUDGET;
    let pairs = critical_pairs(trs);
    if pairs.is_empty() {
        return Some(1);
    }
    let mut depth = 1usize;
    loop {
        if current_thread_cancelled() || Instant::now() >= deadline {
            return None;
        }
        if weakly_confluent_by_join_bfs(&pairs, trs.rules(), depth, deadline) {
            return Some(depth);
        }
        depth = depth.checked_mul(2)?;
    }
}

pub(crate) fn csr_is_orthogonal(csr: &CsrTrs) -> bool {
    csr.trs().rules().iter().all(|rule| is_linear(rule.lhs()))
        && critical_pairs(csr.trs()).is_empty()
}

fn is_linear(term: &Term) -> bool {
    fn visit(term: &Term, variables: &mut BTreeSet<Variable>) -> bool {
        match term {
            Term::Var(variable) => variables.insert(variable.clone()),
            Term::App { args, .. } => args.iter().all(|arg| visit(arg, variables)),
        }
    }
    visit(term, &mut BTreeSet::new())
}

pub(crate) fn is_overlay_trs(trs: &Trs) -> bool {
    trs.rules().iter().enumerate().all(|(left_index, left)| {
        let left = rename_rule_variables(left, &format!("l{left_index}_"));
        trs.rules().iter().enumerate().all(|(right_index, right)| {
            let right = rename_rule_variables(right, &format!("r{right_index}_"));
            positions_with_subterms(right.lhs())
                .into_iter()
                .filter(|(position, subterm)| {
                    !position.is_empty() && !matches!(subterm, Term::Var(_))
                })
                .all(|(_, subterm)| {
                    let mut substitution = Substitution::new();
                    !unify_terms(left.lhs(), subterm, &mut substitution)
                })
        })
    })
}

pub(crate) fn critical_pairs(trs: &Trs) -> Vec<(Term, Term)> {
    let mut pairs = Vec::new();
    for (left_index, left) in trs.rules().iter().enumerate() {
        let left = rename_rule_variables(left, &format!("l{left_index}_"));
        for (right_index, right) in trs.rules().iter().enumerate() {
            let right = rename_rule_variables(right, &format!("r{right_index}_"));
            for (position, subterm) in positions_with_subterms(right.lhs()) {
                if matches!(subterm, Term::Var(_))
                    || left_index == right_index && position.is_empty()
                {
                    continue;
                }
                let mut substitution = Substitution::new();
                if !unify_terms(left.lhs(), subterm, &mut substitution) {
                    continue;
                }
                let contracted = apply_substitution(left.rhs(), &substitution);
                let Some(overlap) =
                    replace_subterm_at_position(right.lhs(), &position, &contracted)
                else {
                    continue;
                };
                let overlap = apply_substitution(&overlap, &substitution);
                let root = apply_substitution(right.rhs(), &substitution);
                if overlap != root {
                    pairs.push((overlap, root));
                }
            }
        }
    }
    pairs
}

fn terms_join(
    left: &Term,
    right: &Term,
    rules: &[RewriteRule],
    depth: usize,
    deadline: Instant,
) -> bool {
    let Some(left_reachable) = reachable_terms(left, rules, depth, deadline) else {
        return false;
    };
    let Some(right_reachable) = reachable_terms(right, rules, depth, deadline) else {
        return false;
    };
    left_reachable
        .iter()
        .any(|term| right_reachable.contains(term))
}

pub(crate) fn weakly_confluent_by_join_bfs(
    pairs: &[(Term, Term)],
    rules: &[RewriteRule],
    depth: usize,
    deadline: Instant,
) -> bool {
    pairs
        .iter()
        .all(|(left, right)| terms_join(left, right, rules, depth, deadline))
}

fn reachable_terms(
    start: &Term,
    rules: &[RewriteRule],
    depth: usize,
    deadline: Instant,
) -> Option<BTreeSet<Term>> {
    let mut seen = BTreeSet::from([start.clone()]);
    let mut frontier = BTreeSet::from([start.clone()]);
    for _ in 0..depth {
        if current_thread_cancelled() || Instant::now() >= deadline {
            return None;
        }
        let mut next = BTreeSet::new();
        for term in frontier {
            if current_thread_cancelled() || Instant::now() >= deadline {
                return None;
            }
            for reduct in one_step_reducts(&term, rules) {
                if seen.insert(reduct.clone()) {
                    if seen.len() > MAX_REACHABLE_TERMS {
                        return None;
                    }
                    next.insert(reduct);
                }
            }
        }
        if next.is_empty() {
            break;
        }
        frontier = next;
    }
    Some(seen)
}

fn one_step_reducts(term: &Term, rules: &[RewriteRule]) -> Vec<Term> {
    let mut reducts = Vec::new();
    for (position, subterm) in positions_with_subterms(term) {
        for rule in rules {
            let Some(substitution) = match_pattern(rule.lhs(), subterm) else {
                continue;
            };
            let rhs = apply_substitution(rule.rhs(), &substitution);
            if let Some(reduct) = replace_subterm_at_position(term, &position, &rhs)
                && !reducts.contains(&reduct)
            {
                reducts.push(reduct);
            }
        }
    }
    reducts
}

pub(crate) fn positions_with_subterms(term: &Term) -> Vec<(Vec<usize>, &Term)> {
    fn visit<'a>(
        term: &'a Term,
        current: &mut Vec<usize>,
        positions: &mut Vec<(Vec<usize>, &'a Term)>,
    ) {
        positions.push((current.clone(), term));
        if let Term::App { args, .. } = term {
            for (index, arg) in args.iter().enumerate() {
                current.push(index + 1);
                visit(arg, current, positions);
                current.pop();
            }
        }
    }
    let mut positions = Vec::new();
    visit(term, &mut Vec::new(), &mut positions);
    positions
}

pub(crate) fn replace_subterm_at_position(
    term: &Term,
    position: &[usize],
    replacement: &Term,
) -> Option<Term> {
    if position.is_empty() {
        return Some(replacement.clone());
    }
    let Term::App { symbol, args } = term else {
        return None;
    };
    let index = position[0].checked_sub(1)?;
    let mut new_args = args.clone();
    new_args[index] = replace_subterm_at_position(args.get(index)?, &position[1..], replacement)?;
    Some(Term::App {
        symbol: symbol.clone(),
        args: new_args,
    })
}

pub(crate) fn rename_rule_variables(rule: &RewriteRule, prefix: &str) -> RewriteRule {
    RewriteRule::new(
        rename_variables(rule.lhs(), prefix),
        rename_variables(rule.rhs(), prefix),
    )
}

pub(crate) fn rename_variables(term: &Term, prefix: &str) -> Term {
    match term {
        Term::Var(variable) => Term::var(format!("{prefix}{}", variable.as_str())),
        Term::App { symbol, args } => Term::app(
            symbol.as_str(),
            args.iter()
                .map(|arg| rename_variables(arg, prefix))
                .collect(),
        ),
    }
}

pub(crate) fn unify_terms(lhs: &Term, rhs: &Term, substitution: &mut Substitution) -> bool {
    let lhs = apply_substitution(lhs, substitution);
    let rhs = apply_substitution(rhs, substitution);
    match (&lhs, &rhs) {
        (Term::Var(variable), term) | (term, Term::Var(variable)) => {
            bind_variable(variable, term, substitution)
        }
        (
            Term::App {
                symbol: left_symbol,
                args: left_args,
            },
            Term::App {
                symbol: right_symbol,
                args: right_args,
            },
        ) => {
            left_symbol == right_symbol
                && left_args.len() == right_args.len()
                && left_args
                    .iter()
                    .zip(right_args)
                    .all(|(left, right)| unify_terms(left, right, substitution))
        }
    }
}

fn bind_variable(variable: &Variable, term: &Term, substitution: &mut Substitution) -> bool {
    if matches!(term, Term::Var(other) if other == variable) {
        return true;
    }
    if term.variables().contains(variable) {
        return false;
    }
    substitution.insert(variable.clone(), term.clone());
    true
}

pub(crate) fn apply_substitution(term: &Term, substitution: &BTreeMap<Variable, Term>) -> Term {
    match term {
        Term::Var(variable) => substitution
            .get(variable)
            .map(|term| apply_substitution(term, substitution))
            .unwrap_or_else(|| term.clone()),
        Term::App { symbol, args } => Term::app(
            symbol.as_str(),
            args.iter()
                .map(|arg| apply_substitution(arg, substitution))
                .collect(),
        ),
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    fn app(symbol: &str, args: Vec<Term>) -> Term {
        Term::app(symbol, args)
    }

    fn rule(lhs: Term, rhs: Term) -> RewriteRule {
        RewriteRule::new(lhs, rhs)
    }

    fn full_trs(rules: Vec<RewriteRule>) -> Trs {
        Trs::new_with_strategy(None, BTreeSet::new(), rules, RewriteStrategy::Full)
    }

    fn ga01_example_rules() -> Vec<RewriteRule> {
        let x = Term::var("x");
        vec![
            rule(app("g", vec![x.clone()]), app("s", vec![x.clone()])),
            rule(
                app("f", vec![x.clone(), x.clone()]),
                app("f", vec![app("g", vec![x.clone()]), x]),
            ),
        ]
    }

    #[test]
    fn aaecc_finds_nontrivial_partition() {
        let witness = aaecc_innermost_witness(&full_trs(ga01_example_rules()))
            .expect("AAECC should separate the f-layer from g and s");
        let (r1, r2, sigma, wcr_depth) = witness;
        assert_eq!(r1.len(), 1);
        assert_eq!(r2.len(), 1);
        assert_eq!(sigma, BTreeSet::from([crate::core::Symbol::new("f")]));
        assert_eq!(wcr_depth, 1);
    }

    #[test]
    fn aaecc_partition_is_rule_order_independent() {
        let rules = ga01_example_rules();
        let forward = aaecc_innermost_witness(&full_trs(rules.clone())).unwrap();
        let reverse =
            aaecc_innermost_witness(&full_trs(rules.into_iter().rev().collect())).unwrap();
        assert_eq!(forward.2, reverse.2);
        assert_eq!(forward.3, reverse.3);
        assert!(same_rule_multiset(&forward.0, &reverse.0));
        assert!(same_rule_multiset(&forward.1, &reverse.1));
    }

    #[test]
    fn aaecc_keeps_collapsing_rules_out_of_r2() {
        let x = Term::var("x");
        let trs = full_trs(vec![
            rule(app("g", vec![x.clone()]), x.clone()),
            rule(app("f", vec![x.clone()]), app("f", vec![app("g", vec![x])])),
        ]);
        let (r1, r2, sigma, _) = aaecc_innermost_witness(&trs).unwrap();
        assert_eq!(r1.len(), 1);
        assert!(matches!(r1[0].rhs(), Term::Var(_)));
        assert_eq!(r2.len(), 1);
        assert_eq!(sigma, BTreeSet::from([crate::core::Symbol::new("f")]));
    }

    #[test]
    fn aaecc_rejects_r1_overlap_into_r2_lhs() {
        let x = Term::var("x");
        let trs = full_trs(vec![
            rule(app("g", vec![x.clone()]), app("a", vec![])),
            rule(app("f", vec![app("g", vec![x.clone()])]), app("f", vec![x])),
        ]);
        assert!(aaecc_innermost_witness(&trs).is_none());
    }

    #[test]
    fn aaecc_cross_overlap_check_is_directed_and_includes_root() {
        let x = Term::var("x");
        let outer = vec![rule(
            app("f", vec![app("g", vec![x.clone()])]),
            app("f", vec![x.clone()]),
        )];
        let inner = vec![rule(app("g", vec![x.clone()]), x)];
        assert!(rules_have_cross_overlap(&outer, &inner));
        assert!(!rules_have_cross_overlap(&inner, &outer));
    }

    #[test]
    fn aaecc_accepts_joinable_r1_critical_pairs() {
        let x = Term::var("x");
        let trs = full_trs(vec![
            rule(app("g", vec![app("c", vec![])]), app("c", vec![])),
            rule(app("g", vec![x.clone()]), app("a", vec![])),
            rule(app("g", vec![x.clone()]), app("b", vec![])),
            rule(app("a", vec![]), app("c", vec![])),
            rule(app("b", vec![]), app("c", vec![])),
            rule(app("f", vec![x.clone()]), app("f", vec![app("s", vec![x])])),
        ]);
        let (r1, r2, sigma, wcr_depth) =
            aaecc_innermost_witness(&trs).expect("joinable R1 peaks are admissible");
        assert_eq!(r1.len(), 5);
        assert_eq!(r2.len(), 1);
        assert_eq!(sigma, BTreeSet::from([crate::core::Symbol::new("f")]));
        assert!(wcr_depth >= 1);
    }
}
