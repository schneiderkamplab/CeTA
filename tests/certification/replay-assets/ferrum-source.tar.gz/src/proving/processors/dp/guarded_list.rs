//! Role discovery for CeTA's guarded-list semantic-rank terminal theorem.
//!
//! These are local algebraic role constraints, not a complete input TRS:
//! unrelated rules and symbols are allowed. Discovery only proposes a witness;
//! CeTA still checks *every* residual rule against the semantic-rank obligations.
//! Missing/ambiguous roles and exhausted discovery budgets decline this route.

use std::collections::BTreeMap;

use crate::core::{CsrTrs, Symbol, Term, Variable};
use crate::proving::dependency_pairs::DependencyPair;

#[derive(Clone, Copy)]
enum Role {
    Truth,
    And,
    Nat,
    List,
    IList,
    Continue,
    EmptyContinue,
    TakeContinue,
    Zero,
    Successor,
    Length,
    Nil,
    Cons,
    Take,
    Zeros,
}
use Role::*;

#[derive(Clone)]
enum Pattern {
    Var(usize),
    Fun(Role, bool, Vec<Pattern>),
}
fn v(index: usize) -> Pattern {
    Pattern::Var(index)
}
fn f(role: Role, args: Vec<Pattern>) -> Pattern {
    Pattern::Fun(role, false, args)
}
fn marked(role: Role, args: Vec<Pattern>) -> Pattern {
    Pattern::Fun(role, true, args)
}

type Roles = [Option<Symbol>; 15];

fn matches(
    pattern: &Pattern,
    term: &Term,
    roles: &mut Roles,
    variables: &mut BTreeMap<usize, Variable>,
) -> Option<()> {
    match (pattern, term) {
        (Pattern::Var(index), Term::Var(variable)) => {
            if let Some(old) = variables.get(index) {
                (old == variable).then_some(())
            } else {
                // Each local schema uses distinct variables for independent arguments.
                if variables.values().any(|old| old == variable) {
                    return None;
                }
                variables.insert(*index, variable.clone());
                Some(())
            }
        }
        (Pattern::Fun(role, sharp, patterns), Term::App { symbol, args }) => {
            if patterns.len() != args.len() {
                return None;
            }
            let symbol = if *sharp {
                Symbol::new(symbol.as_str().strip_suffix('#')?)
            } else {
                symbol.clone()
            };
            let index = *role as usize;
            if let Some(old) = &roles[index] {
                if old != &symbol {
                    return None;
                }
            } else {
                if roles.iter().flatten().any(|old| old == &symbol) {
                    return None;
                }
                roles[index] = Some(symbol);
            }
            for (pattern, term) in patterns.iter().zip(args) {
                matches(pattern, term, roles, variables)?;
            }
            Some(())
        }
        _ => None,
    }
}

fn escape(text: &str) -> String {
    text.replace('&', "&amp;")
        .replace('<', "&lt;")
        .replace('>', "&gt;")
}

pub(super) fn terminal_payload(csr: &CsrTrs, pairs: &[DependencyPair]) -> Option<String> {
    if pairs.len() != 2 {
        return None;
    }
    // Exact pair language of csr_guard_{strict,weak}_pair. Variables 0 and 1
    // are the element and tail respectively; their *live* names enter CPF.
    let strict = (
        marked(Length, vec![f(Cons, vec![v(0), v(1)])]),
        marked(
            Continue,
            vec![f(And, vec![f(List, vec![v(1)]), f(Nat, vec![v(0)])]), v(1)],
        ),
    );
    let weak = (
        marked(Continue, vec![f(Truth, vec![]), v(1)]),
        marked(Length, vec![v(1)]),
    );
    let mut seeds = Vec::new();
    for order in [[0, 1], [1, 0]] {
        let mut roles: Roles = Default::default();
        let mut variables = BTreeMap::new();
        if matches(&strict.0, pairs[order[0]].lhs(), &mut roles, &mut variables).is_some()
            && matches(&strict.1, pairs[order[0]].rhs(), &mut roles, &mut variables).is_some()
            && matches(&weak.0, pairs[order[1]].lhs(), &mut roles, &mut variables).is_some()
            && matches(&weak.1, pairs[order[1]].rhs(), &mut roles, &mut variables).is_some()
        {
            seeds.push((roles, variables));
        }
    }
    if seeds.len() != 1 {
        return None;
    }
    let (roles, variables) = seeds.pop()?;

    // Discover constructor/predicate roles through independent local laws.
    // This deliberately does not require exact rule counts, declaration order,
    // a complete residual signature, or an isomorphism to a benchmark fixture.
    let constraints = [
        (f(Nat, vec![f(Zero, vec![])]), f(Truth, vec![])),
        (f(List, vec![f(Nil, vec![])]), f(Truth, vec![])),
        (f(Nat, vec![f(Successor, vec![v(0)])]), f(Nat, vec![v(0)])),
        (f(IList, vec![v(0)]), f(List, vec![v(0)])),
        (
            f(List, vec![f(Take, vec![v(0), v(1)])]),
            f(And, vec![f(Nat, vec![v(0)]), f(IList, vec![v(1)])]),
        ),
        (
            f(Zeros, vec![]),
            f(Cons, vec![f(Zero, vec![]), f(Zeros, vec![])]),
        ),
        (
            f(TakeContinue, vec![f(Truth, vec![]), v(0), v(1), v(2)]),
            f(Cons, vec![v(2), f(Take, vec![v(1), v(0)])]),
        ),
    ];
    let mut candidates = vec![roles];
    let mut budget = 50_000usize;
    for (lhs, rhs) in constraints {
        let mut next = Vec::new();
        for roles in candidates {
            for rule in csr.trs().rules() {
                budget = budget.checked_sub(1)?;
                let mut roles = roles.clone();
                let mut local_variables = BTreeMap::new();
                if matches(&lhs, rule.lhs(), &mut roles, &mut local_variables).is_some()
                    && matches(&rhs, rule.rhs(), &mut roles, &mut local_variables).is_some()
                    && !next.contains(&roles)
                {
                    next.push(roles);
                    if next.len() > 256 {
                        return None;
                    }
                }
            }
        }
        if next.is_empty() {
            return None;
        }
        candidates = next;
    }
    if candidates.len() != 1 {
        return None;
    }
    let mut roles = candidates.pop()?;
    // Rule removal may eliminate the empty-list continuation altogether.
    // In that case an unused symbol supplies this optional semantic role;
    // no input symbol is guessed from its spelling or declaration order.
    let mut empty_candidates = Vec::new();
    for rule in csr.trs().rules() {
        let mut candidate = roles.clone();
        let mut vars = BTreeMap::new();
        if matches(
            &f(EmptyContinue, vec![f(Truth, vec![])]),
            rule.lhs(),
            &mut candidate,
            &mut vars,
        )
        .is_some()
            && matches(&f(Nil, vec![]), rule.rhs(), &mut candidate, &mut vars).is_some()
            && !empty_candidates.contains(&candidate)
        {
            empty_candidates.push(candidate);
        }
    }
    match empty_candidates.len() {
        0 => {
            let arities = csr.trs().arities();
            let fresh = (0..)
                .map(|index| Symbol::new(format!("__guard_unused_{index}")))
                .find(|symbol| {
                    !arities.contains_key(symbol)
                        && !roles.iter().flatten().any(|old| old == symbol)
                })?;
            roles[EmptyContinue as usize] = Some(fresh);
        }
        1 => roles = empty_candidates.pop()?,
        _ => return None,
    }
    let symbols = roles.into_iter().collect::<Option<Vec<_>>>()?;
    let mu = csr.replacement_map();
    if mu.is_allowed(&symbols[Continue as usize], 1)
        || mu.is_allowed(&symbols[And as usize], 1)
        || [Nat, List, IList]
            .iter()
            .any(|role| mu.is_allowed(&symbols[*role as usize], 0))
    {
        return None;
    }
    let tags = [
        "truthSymbol",
        "andSymbol",
        "natPredicateSymbol",
        "listPredicateSymbol",
        "ilistPredicateSymbol",
        "u11Symbol",
        "u21Symbol",
        "u31Symbol",
        "zeroSymbol",
        "successorSymbol",
        "lengthSymbol",
        "nilSymbol",
        "consSymbol",
        "takeSymbol",
        "zerosSymbol",
    ];
    let mut payload = tags
        .iter()
        .zip(&symbols)
        .map(|(tag, symbol)| format!("<{tag}><name>{}</name></{tag}>", escape(symbol.as_str())))
        .collect::<Vec<_>>();
    // Only N and L occur in the generic checker's pair equality. The other
    // six fields are legacy syntax and semantically unused by that checker.
    for (tag, index) in [
        ("xVariable", 0),
        ("listVariable", 1),
        ("ilistVariable", 1),
        ("mVariable", 0),
        ("nVariable", 0),
        ("valueVariable", 0),
        ("leftValueVariable", 0),
        ("rightValueVariable", 1),
    ] {
        payload.push(format!(
            "<{tag}>{}</{tag}>",
            escape(variables.get(&index)?.as_str())
        ));
    }
    Some(payload.join("\n"))
}

#[cfg(test)]
mod tests {
    use super::*;

    fn pairs() -> Vec<DependencyPair> {
        vec![
            DependencyPair::new_for_test(
                Term::app(
                    "length#",
                    vec![Term::app("cons", vec![Term::var("N"), Term::var("L")])],
                ),
                Term::app(
                    "U11#",
                    vec![
                        Term::app(
                            "and",
                            vec![
                                Term::app("isNatList", vec![Term::var("L")]),
                                Term::app("isNat", vec![Term::var("N")]),
                            ],
                        ),
                        Term::var("L"),
                    ],
                ),
            ),
            DependencyPair::new_for_test(
                Term::app("U11#", vec![Term::app("tt", vec![]), Term::var("L")]),
                Term::app("length#", vec![Term::var("L")]),
            ),
        ]
    }

    #[test]
    fn guarded_list_roles_reject_missing_ambiguous_and_invalid_shapes() {
        let input = include_str!("../../../../tests/fixtures/csr_ovconsos_nokinds.ari");
        let parse = |input: &str| crate::parsing::parse_ari_cstrs(None, input).unwrap();
        let csr = parse(input);
        let mut pairs = pairs();
        let payload = terminal_payload(&csr, &pairs).expect("unique local roles");
        pairs.reverse();
        assert_eq!(terminal_payload(&csr, &pairs).as_ref(), Some(&payload));
        let residual = input
            .lines()
            .filter(|line| {
                ![
                    "(rule (U21 tt) nil)",
                    "(rule (length nil) |0|)",
                    "(rule (take |0| IL) (U21 (isNatIList IL)))",
                ]
                .contains(line)
            })
            .collect::<Vec<_>>()
            .join("\n");
        let residual_payload = terminal_payload(&parse(&residual), &pairs)
            .expect("deleted continuation gets a fresh unused role");
        assert!(residual_payload.contains("<u21Symbol><name>__guard_unused_0</name>"));
        assert!(terminal_payload(&csr, &pairs[..1]).is_none());
        let missing = input.replace("(rule (isNatIList V) (isNatList V))", "");
        assert!(terminal_payload(&parse(&missing), &pairs).is_none());
        let ambiguous = format!(
            "{input}\n(fun otherEmpty 1 :replacement-map (1))\n(rule (otherEmpty tt) nil)\n"
        );
        assert!(terminal_payload(&parse(&ambiguous), &pairs).is_none());
        let active = input.replace(
            "(fun isNat 1 :replacement-map ())",
            "(fun isNat 1 :replacement-map (1))",
        );
        assert!(terminal_payload(&parse(&active), &pairs).is_none());
        let wrong_pair = DependencyPair::new_for_test(pairs[0].lhs().clone(), Term::var("L"));
        assert!(terminal_payload(&csr, &[wrong_pair, pairs[1].clone()]).is_none());
        assert_eq!(escape("a<&b>"), "a&lt;&amp;b&gt;");
    }
}
