use std::time::Instant;

use crate::core::RewriteStrategy;
use crate::proving::dependency_pairs::{
    CsrDpConstruction, DpProblemContext, DpProofTree, DpSizeChangeEdge, DpSizeChangeGraph,
    cached_ceta_q_dependency_pair_graph_with_rules_deadline,
    cached_dp_problem_dependency_graph_with_context_deadline,
    cached_size_change_graphs_are_terminating_on_dependency_graph,
    csr_innermost_sct_targets_are_source_covered, csr_size_change_graph_is_improved_unhiding,
    csr_size_change_graph_is_mu_valid, dp_graph_details, dp_rhs_roots_are_constructors,
    linear_sct_only_experiment_enabled, size_change_graphs_are_terminating_on_dependency_graph,
    strategy_timed_out, synthesize_general_size_change_criterion,
    synthesize_polynomial_size_change, term_app_parts,
};
use crate::proving::runtime::{CancellationScope, write_progress_event};

use super::super::{
    ProblemCertificate, ProblemState, ProcessorApplication, ProcessorResult, WorklistProcessor,
};

/// Dependency-pair size-change termination, including the certified
/// polynomial/SCT combined leaf used for ordinary DP problems.
pub struct SizeChangeProcessor {
    pub deadline: Option<Instant>,
}
/// Replay a certified syntactic size-change witness on the exact live state.
pub struct ExactSizeChangeProcessor {
    pub graphs: Vec<(usize, Vec<(usize, bool, usize)>)>,
    pub deadline: Option<Instant>,
}

#[cfg(test)]
mod native_q_tests {
    use super::*;
    use crate::core::{Term, Trs};
    use crate::proving::dependency_pairs::{DependencyPair, DpOptions};

    #[test]
    fn native_sct_uses_iedg_phase_cycle_and_rejects_nondecreasing_mutation() {
        let x = Term::var("x");
        let sx = Term::app("step", vec![x.clone()]);
        let call = |value: Term, phase: &str| Term::app("call#", vec![value, Term::app(phase, vec![])]);
        for decreasing in [true, false] {
            let pairs = vec![
                DependencyPair::new_for_test(call(sx.clone(), "left"),
                    call(if decreasing { x.clone() } else { sx.clone() }, "right")),
                DependencyPair::new_for_test(call(x.clone(), "right"), call(x.clone(), "left")),
            ];
            let trs = Trs::new_with_strategy(None, Default::default(), Vec::new(), RewriteStrategy::Innermost);
            let problem = super::super::DpProblemState::ordinary(trs, pairs, DpOptions::default());
            let result = SizeChangeProcessor {
                deadline: Some(Instant::now() + std::time::Duration::from_secs(1)),
            }.apply(&ProblemState::DependencyPairs(problem));
            assert_eq!(matches!(result, ProcessorResult::Applied(_)), decreasing);
        }
    }
}

fn exact_size_change_edge_witness(
    pair: &crate::proving::DependencyPair,
    wire_edges: &[(usize, bool, usize)],
) -> Option<Vec<DpSizeChangeEdge>> {
    let (Some((_, lhs_args)), Some((_, rhs_args))) =
        (term_app_parts(pair.lhs()), term_app_parts(pair.rhs()))
    else {
        return None;
    };
    let mut edges = Vec::with_capacity(wire_edges.len());
    for (left_position, strict, right_position) in wire_edges {
        let left = left_position
            .checked_sub(1)
            .and_then(|index| lhs_args.get(index))?;
        let right = right_position
            .checked_sub(1)
            .and_then(|index| rhs_args.get(index))?;
        if if *strict {
            !right.is_proper_subterm_of(left)
        } else {
            right != left && !right.is_proper_subterm_of(left)
        } {
            return None;
        }
        edges.push(DpSizeChangeEdge {
            left_position: *left_position,
            strict: *strict,
            right_position: *right_position,
        });
    }
    Some(edges)
}

/// Pair positions in retained CPF fragments are presentation details: graph
/// decomposition and reconstruction may enumerate the same live pair set in a
/// different order.  Match every checked SCT graph to one distinct live pair
/// and let `accept` recheck the resulting closure.  Trying all structurally
/// valid bijections is important when several pairs have the same arity.
fn exact_size_change_assignment(
    candidates: &[Vec<(usize, DpSizeChangeGraph)>],
    pair_count: usize,
    accept: &mut impl FnMut(Vec<DpSizeChangeGraph>) -> Option<Vec<DpSizeChangeGraph>>,
) -> Option<Vec<DpSizeChangeGraph>> {
    fn search(
        depth: usize,
        order: &[usize],
        candidates: &[Vec<(usize, DpSizeChangeGraph)>],
        used: &mut [bool],
        assigned: &mut [Option<DpSizeChangeGraph>],
        accept: &mut impl FnMut(Vec<DpSizeChangeGraph>) -> Option<Vec<DpSizeChangeGraph>>,
    ) -> Option<Vec<DpSizeChangeGraph>> {
        if depth == order.len() {
            let graphs = assigned.iter().cloned().collect::<Option<Vec<_>>>()?;
            return accept(graphs);
        }
        let witness_index = order[depth];
        for (pair_index, graph) in &candidates[witness_index] {
            if used[*pair_index] {
                continue;
            }
            used[*pair_index] = true;
            assigned[*pair_index] = Some(graph.clone());
            if let Some(graphs) = search(depth + 1, order, candidates, used, assigned, accept) {
                return Some(graphs);
            }
            assigned[*pair_index] = None;
            used[*pair_index] = false;
        }
        None
    }

    let mut order = (0..candidates.len()).collect::<Vec<_>>();
    order.sort_by_key(|index| candidates[*index].len());
    search(
        0,
        &order,
        candidates,
        &mut vec![false; pair_count],
        &mut vec![None; pair_count],
        accept,
    )
}

impl WorklistProcessor for ExactSizeChangeProcessor {
    fn name(&self) -> &'static str {
        "dependency-pair-exact-size-change"
    }

    fn apply(&self, state: &ProblemState) -> ProcessorResult {
        let ProblemState::DependencyPairs(problem) = state else {
            return ProcessorResult::Inapplicable;
        };
        let stats = problem.stats.clone();
        let innermost_csr_active_sct = matches!(
            &stats.problem,
            DpProblemContext::ContextSensitive(context)
                if context.construction == CsrDpConstruction::Innermost
                    && csr_innermost_sct_targets_are_source_covered(
                        &context.csr,
                        &problem.pairs,
                    )
        );
        if ((!stats.minimal || stats.ordinary_bridge_loses_minimality) && !innermost_csr_active_sct)
            || self.graphs.len() != problem.pairs.len()
            || !dp_rhs_roots_are_constructors(
                &problem.pairs,
                stats.active_rules.as_deref().unwrap_or(problem.trs.rules()),
            )
        {
            if std::env::var_os("FERRUM_WORKLIST_TRACE").is_some() {
                eprintln!(
                    "exact size-change precondition failed minimal={} innermost_csr_active_sct={} witness_graphs={} pairs={} constructor_roots={} active_rules={}",
                    stats.minimal,
                    innermost_csr_active_sct,
                    self.graphs.len(),
                    problem.pairs.len(),
                    dp_rhs_roots_are_constructors(
                        &problem.pairs,
                        stats.active_rules.as_deref().unwrap_or(problem.trs.rules()),
                    ),
                    stats
                        .active_rules
                        .as_ref()
                        .map_or(problem.trs.rules().len(), Vec::len),
                );
            }
            return ProcessorResult::Inapplicable;
        }
        let cancellation = CancellationScope::current(self.deadline);
        if cancellation.is_cancelled() || strategy_timed_out(self.deadline) {
            return ProcessorResult::TimedOut;
        }
        let mut seen_source_indices = vec![false; problem.pairs.len()];
        let mut candidates = Vec::with_capacity(self.graphs.len());
        for (source_pair_index, wire_edges) in &self.graphs {
            if *source_pair_index >= problem.pairs.len() || seen_source_indices[*source_pair_index]
            {
                return ProcessorResult::Inapplicable;
            }
            seen_source_indices[*source_pair_index] = true;
            let live_candidates = problem
                .pairs
                .iter()
                .enumerate()
                .filter_map(|(live_pair_index, pair)| {
                    exact_size_change_edge_witness(pair, wire_edges).map(|edges| {
                        (
                            live_pair_index,
                            DpSizeChangeGraph {
                                pair: pair.clone(),
                                edges,
                            },
                        )
                    })
                })
                .collect::<Vec<_>>();
            if live_candidates.is_empty() {
                if std::env::var_os("FERRUM_WORKLIST_TRACE").is_some() {
                    eprintln!(
                        "exact size-change witness graph {} matches no live pair",
                        source_pair_index
                    );
                }
                return ProcessorResult::Inapplicable;
            }
            candidates.push(live_candidates);
        }
        if seen_source_indices.iter().any(|present| !present) {
            return ProcessorResult::Inapplicable;
        }
        let Some(base_graph) = cached_dp_problem_dependency_graph_with_context_deadline(
            &stats,
            &problem.trs,
            &problem.pairs,
            problem.innermost_lhss.as_deref(),
            stats
                .graph_rules
                .as_deref()
                .or(stats.active_rules.as_deref()),
            self.deadline,
            &cancellation,
        ) else {
            return ProcessorResult::Inapplicable;
        };
        let dependency_graph = if problem.trs.strategy() == RewriteStrategy::Innermost {
            let Some(graph) = cached_ceta_q_dependency_pair_graph_with_rules_deadline(
                &stats,
                stats.active_rules.as_deref().unwrap_or(problem.trs.rules()),
                &problem.pairs,
                problem.innermost_lhss.as_deref().unwrap_or(&[]),
                self.deadline,
                &cancellation,
            ) else {
                return ProcessorResult::Inapplicable;
            };
            graph
        } else {
            base_graph
        };
        let Some(graphs) =
            exact_size_change_assignment(&candidates, problem.pairs.len(), &mut |mut graphs| {
                if let DpProblemContext::ContextSensitive(context) = &stats.problem {
                    for graph in &mut graphs {
                        let snapshot = graph.clone();
                        graph.edges.retain(|edge| {
                            let singleton = DpSizeChangeGraph {
                                pair: snapshot.pair.clone(),
                                edges: vec![edge.clone()],
                            };
                            csr_size_change_graph_is_mu_valid(&context.csr, &singleton)
                                || (context.construction == CsrDpConstruction::Improved
                                    && csr_size_change_graph_is_improved_unhiding(
                                        &context.csr,
                                        &singleton,
                                    ))
                        });
                    }
                }
                // CeTA's precise SCT processor composes graphs only when its
                // estimated dependency graph connects their source pairs.
                // The generic certificate cache deliberately checks the
                // stronger all-compositions criterion, so exact certified
                // replay must use the indexed criterion explicitly.
                size_change_graphs_are_terminating_on_dependency_graph(&graphs, &dependency_graph)
                    .map(|_| graphs)
            })
        else {
            if std::env::var_os("FERRUM_WORKLIST_TRACE").is_some() {
                eprintln!("exact size-change witness does not close the live dependency graph");
            }
            return ProcessorResult::Inapplicable;
        };
        ProcessorResult::Applied(ProcessorApplication::solved(
            ProblemCertificate::DependencyPairTree(DpProofTree::SizeChange { graphs }),
        ))
    }
}

impl WorklistProcessor for SizeChangeProcessor {
    fn name(&self) -> &'static str {
        "dependency-pair-size-change"
    }

    fn apply(&self, state: &ProblemState) -> ProcessorResult {
        let ProblemState::DependencyPairs(problem) = state else {
            return ProcessorResult::Inapplicable;
        };
        let cancellation = CancellationScope::current(self.deadline);
        if cancellation.is_cancelled() || strategy_timed_out(self.deadline) {
            return ProcessorResult::TimedOut;
        }
        let stats = problem.stats.clone();
        let innermost_csr_active_sct = matches!(
            &stats.problem,
            DpProblemContext::ContextSensitive(context)
                if context.construction == CsrDpConstruction::Innermost
                    && csr_innermost_sct_targets_are_source_covered(
                        &context.csr,
                        &problem.pairs,
                    )
        );
        let constructor_roots = dp_rhs_roots_are_constructors(
            &problem.pairs,
            stats.active_rules.as_deref().unwrap_or(problem.trs.rules()),
        );
        if ((!stats.minimal || stats.ordinary_bridge_loses_minimality) && !innermost_csr_active_sct)
            || !constructor_roots
        {
            write_progress_event(
                "dp-size-change",
                "rejected",
                "size-change",
                0,
                &format!(
                    "minimal={} innermost_csr_active_sct={} constructor_roots={} pairs={}",
                    stats.minimal,
                    innermost_csr_active_sct,
                    constructor_roots,
                    problem.pairs.len()
                ),
            );
            return ProcessorResult::Inapplicable;
        }

        let dependency_graph = cached_dp_problem_dependency_graph_with_context_deadline(
            &stats,
            &problem.trs,
            &problem.pairs,
            problem.innermost_lhss.as_deref(),
            stats.active_rules.as_deref(),
            self.deadline,
            &cancellation,
        );
        let mut size_change_graph = dependency_graph.as_ref().and_then(|graph| {
            if problem.trs.strategy() == RewriteStrategy::Innermost {
                cached_ceta_q_dependency_pair_graph_with_rules_deadline(
                    &stats,
                    stats.active_rules.as_deref().unwrap_or(problem.trs.rules()),
                    &problem.pairs,
                    problem.innermost_lhss.as_deref().unwrap_or(&[]),
                    self.deadline,
                    &cancellation,
                )
            } else {
                Some(graph.clone())
            }
        });
        if let Some(graph) = size_change_graph.as_deref() {
            write_progress_event(
                "dp-size-change",
                "indexed-graph",
                "size-change",
                0,
                &dp_graph_details(
                    &problem.trs,
                    &problem.pairs,
                    problem.innermost_lhss.as_deref(),
                    graph,
                ),
            );
        }

        let mut graphs = if linear_sct_only_experiment_enabled() {
            None
        } else {
            size_change_graph.as_deref().and_then(|graph| {
                synthesize_general_size_change_criterion(&stats, &problem.pairs, graph)
            })
        };
        // Preserve the established successful SCT route. Only after it fails,
        // retry CeTA's pair-local usable-rule IEDG estimate. In particular, do
        // not use the forward/reverse TCAP filters of graph decomposition:
        // the independent SCT checker does not apply those filters.
        if graphs.is_none() && !linear_sct_only_experiment_enabled()
            && matches!(stats.problem, DpProblemContext::Ordinary)
            && problem.trs.strategy() == RewriteStrategy::Innermost
        {
            if let Some(graph) = size_change_graph.as_mut() {
                let candidates = problem.pairs.iter()
                    .map(crate::proving::dependency_pairs::size_change_graph_for_pair)
                    .collect::<Option<Vec<_>>>();
                // The generic cached certificate check deliberately ignores
                // graph-decomposition edges. Here, however, graph is IEDG,
                // precisely the relation sct_subterm_precise_proc checks.
                // Do not conflate these two different premises.
                if let Some(candidates) = candidates.as_ref() {
                    if size_change_graphs_are_terminating_on_dependency_graph(candidates, graph).is_some() {
                        graphs = Some(candidates.clone());
                    }
                }
                if graphs.is_none() {
                    let previous = graph.clone();
                    if crate::proving::dependency_pairs::refine_ceta_q_iedg_with_pair_local_rules(
                        stats.active_rules.as_deref().unwrap_or(problem.trs.rules()),
                        &problem.pairs, problem.innermost_lhss.as_deref().unwrap_or(&[]),
                        graph, self.deadline, &cancellation,
                    ).is_none() { return ProcessorResult::TimedOut; }
                    if *graph != previous {
                        if let Some(candidates) = candidates {
                            if size_change_graphs_are_terminating_on_dependency_graph(&candidates, graph).is_some() {
                                graphs = Some(candidates);
                            }
                        }
                    }
                }
            }
        }
        if let (
            Some(dependency_graph),
            Some(sc_graphs),
            DpProblemContext::ContextSensitive(context),
        ) = (
            size_change_graph.as_deref(),
            graphs.as_mut(),
            &stats.problem,
        ) {
            for graph in sc_graphs.iter_mut() {
                let snapshot = graph.clone();
                graph.edges.retain(|edge| {
                    let singleton = DpSizeChangeGraph {
                        pair: snapshot.pair.clone(),
                        edges: vec![edge.clone()],
                    };
                    csr_size_change_graph_is_mu_valid(&context.csr, &singleton)
                        || (context.construction == CsrDpConstruction::Improved
                            && csr_size_change_graph_is_improved_unhiding(&context.csr, &singleton))
                });
            }
            if cached_size_change_graphs_are_terminating_on_dependency_graph(
                Some(&stats),
                sc_graphs,
                dependency_graph,
            )
            .is_none()
            {
                graphs = None;
            }
        }

        let tree = if let Some(graphs) = graphs {
            DpProofTree::SizeChange { graphs }
        } else if matches!(stats.problem, DpProblemContext::Ordinary) {
            let Some((graphs, reduction_pair, usable_rules)) = synthesize_polynomial_size_change(
                Some(&stats),
                &problem.pairs,
                &problem.trs,
                &problem.options,
                problem.innermost_lhss.as_deref(),
                size_change_graph.as_deref(),
                self.deadline,
            ) else {
                return ProcessorResult::Inapplicable;
            };
            DpProofTree::SizeChangeRedPair {
                graphs,
                reduction_pair,
                usable_rules,
            }
        } else {
            return ProcessorResult::Inapplicable;
        };

        ProcessorResult::Applied(ProcessorApplication::solved(
            ProblemCertificate::DependencyPairTree(tree),
        ))
    }
}
