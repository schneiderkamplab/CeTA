//! NO-only instantiation, with substitutions synthesized from live pair overlaps.
//! CeTA Instantiation_Impl.instantiation_complete_proc checks every resulting
//! pair is an instance. No termination-side coverage theorem is claimed.

use super::super::{
    ProblemCertificate, ProblemState, ProcessorApplication, ProcessorResult, WorklistProcessor,
};
use super::nontermination_cycle::canonical_pair_rule_order;
use crate::core::{RewriteStrategy, Term};
use crate::proving::dependency_pairs::{
    DependencyPair, DpProblemContext, freshen_rule_avoiding, strategy_timed_out,
};
use crate::proving::nontermination::{apply_substitution, unify_terms};
use crate::proving::{DpNonterminationProof, rewrite_rules_are_variants};
use std::collections::BTreeMap;
use std::time::Instant;

pub struct NonterminationInstanceProcessor {
    pub candidate: usize,
    pub constants: bool,
    pub all: bool,
    pub deadline: Option<Instant>,
}

impl WorklistProcessor for NonterminationInstanceProcessor {
    fn name(&self) -> &'static str {
        "nontermination-instance"
    }
    fn apply(&self, state: &ProblemState) -> ProcessorResult {
        let ProblemState::DependencyPairs(problem) = state else {
            return ProcessorResult::Inapplicable;
        };
        if !matches!(problem.stats.problem, DpProblemContext::Ordinary)
            || !problem.stats.weak_pairs.is_empty()
            || !problem.stats.strict_rules.is_empty()
            || problem
                .innermost_lhss
                .as_ref()
                .is_some_and(|q| !q.is_empty())
            || (problem.innermost_lhss.is_none() && problem.trs.strategy() != RewriteStrategy::Full)
        {
            return ProcessorResult::Inapplicable;
        }
        let Some((order, rule_order)) = canonical_pair_rule_order(problem) else {
            return ProcessorResult::Inapplicable;
        };
        let mut constants = Vec::new();
        let rules = problem
            .stats
            .active_rules
            .as_deref()
            .unwrap_or(problem.trs.rules());
        for term in order
            .iter()
            .flat_map(|i| [problem.pairs[*i].lhs(), problem.pairs[*i].rhs()])
            .chain(
                rule_order
                    .iter()
                    .flat_map(|i| [rules[*i].lhs(), rules[*i].rhs()]),
            )
        {
            for (_, subterm) in crate::proving::dependency_pairs::positions_with_subterms(term) {
                if matches!(subterm, Term::App { args, .. } if args.is_empty())
                    && !constants.contains(&subterm)
                {
                    constants.push(subterm);
                }
            }
        }
        let mut candidate = 0;
        for &index in &order {
            let pair = &problem.pairs[index];
            let mut used = pair.lhs().variables();
            used.extend(pair.rhs().variables());
            let mut instances = Vec::new();
            if self.constants {
                let mut variables = Vec::new();
                for term in [pair.lhs(), pair.rhs()] {
                    for (_, subterm) in
                        crate::proving::dependency_pairs::positions_with_subterms(term)
                    {
                        if let Term::Var(variable) = subterm
                            && !variables.contains(&variable)
                        {
                            variables.push(variable);
                        }
                    }
                }
                for variable in variables {
                    for constant in &constants {
                        let subst = BTreeMap::from([(variable.clone(), (*constant).clone())]);
                        instances.push(DependencyPair::new(
                            apply_substitution(pair.lhs(), &subst),
                            apply_substitution(pair.rhs(), &subst),
                            pair.source_rule(),
                        ));
                    }
                }
            } else {
                for (rank, &other) in order.iter().enumerate() {
                    let fresh = freshen_rule_avoiding(&problem.pairs[other].as_rule(), rank, &used);
                    for left in [pair.rhs(), pair.lhs()] {
                        for right in [fresh.lhs(), fresh.rhs()] {
                            if strategy_timed_out(self.deadline) {
                                return ProcessorResult::TimedOut;
                            }
                            let mut subst = BTreeMap::new();
                            if !unify_terms(left, right, &mut subst) {
                                continue;
                            }
                            let instantiated = DependencyPair::new(
                                apply_substitution(pair.lhs(), &subst),
                                apply_substitution(pair.rhs(), &subst),
                                pair.source_rule(),
                            );
                            if rewrite_rules_are_variants(&pair.as_rule(), &instantiated.as_rule())
                            {
                                continue;
                            }
                            instances.push(instantiated);
                        }
                    }
                }
            }
            let groups = if self.all {
                vec![instances]
            } else {
                instances.into_iter().map(|p| vec![p]).collect()
            };
            for group in groups {
                if strategy_timed_out(self.deadline) {
                    return ProcessorResult::TimedOut;
                }
                if group.is_empty() {
                    continue;
                }
                if candidate != self.candidate {
                    candidate += 1;
                    continue;
                }
                let mut child = problem.clone();
                child.pairs.splice(index..=index, group);
                child.stats.minimal = false;
                let pairs = child.pairs.clone();
                return ProcessorResult::Applied(ProcessorApplication::new(
                    vec![ProblemState::DependencyPairs(child)],
                    move |children| {
                        let [ProblemCertificate::DependencyPairNontermination(proof)] =
                            <[ProblemCertificate; 1]>::try_from(children).ok()?
                        else {
                            return None;
                        };
                        Some(ProblemCertificate::DependencyPairNontermination(
                            DpNonterminationProof::Instantiation {
                                instantiated_pairs: pairs.clone(),
                                proof: Box::new(proof),
                            },
                        ))
                    },
                ));
            }
        }
        ProcessorResult::Inapplicable
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::core::{Term, Trs, Variable};
    use crate::proving::dependency_pairs::{DpOptions, DpProofTree, DpStrategy};
    use crate::proving::processors::dp::{DpNonterminationProcessor, DpProblemState};

    #[test]
    fn local_ceta_native_no_instantiation_certifies_under_renaming() {
        for [p, q, a] in [["p#", "q#", "a"], ["call#", "back#", "seed"]] {
            for (constants, all) in [(false, false), (false, true), (true, false), (true, true)] {
                let x = Term::var("x");
                let a = Term::app(a, vec![]);
                let state = DpProblemState::ordinary(
                    Trs::new(None, [Variable::new("x")].into_iter().collect(), vec![]),
                    vec![
                        DependencyPair::new_for_test(
                            Term::app(p, vec![x.clone()]),
                            Term::app(q, vec![x]),
                        ),
                        DependencyPair::new_for_test(
                            Term::app(q, vec![a.clone()]),
                            Term::app(p, vec![a]),
                        ),
                    ],
                    DpOptions::default(),
                );
                let processor = NonterminationInstanceProcessor {
                    candidate: 0,
                    constants,
                    all,
                    deadline: None,
                };
                let ProcessorResult::Applied(app) =
                    processor.apply(&ProblemState::DependencyPairs(state.clone()))
                else {
                    panic!()
                };
                let ProblemState::DependencyPairs(child) = &app.residuals[0] else {
                    panic!()
                };
                assert_ne!(child.pairs, state.pairs);
                assert_eq!(child.trs, state.trs);
                assert_eq!(child.innermost_lhss, state.innermost_lhss);
                assert!(!child.stats.minimal);
                assert!(
                    app.reconstruct(vec![ProblemCertificate::DependencyPairTree(
                        DpProofTree::Empty
                    )])
                    .is_none()
                );
                let mut restricted = state.clone();
                restricted.innermost_lhss = Some(vec![Term::var("q")]);
                assert!(matches!(
                    processor.apply(&ProblemState::DependencyPairs(restricted)),
                    ProcessorResult::Inapplicable
                ));
                let ProcessorResult::Applied(app) =
                    processor.apply(&ProblemState::DependencyPairs(state.clone()))
                else {
                    panic!()
                };
                let ProcessorResult::Applied(terminal) =
                    (DpNonterminationProcessor { deadline: None })
                        .apply_symbolic_loop(&app.residuals[0])
                else {
                    panic!()
                };
                let proof = app
                    .reconstruct(vec![terminal.reconstruct(vec![]).unwrap()])
                    .unwrap();
                let ProblemCertificate::DependencyPairNontermination(proof) = proof else {
                    panic!()
                };
                let xml = crate::cert::write_cpf3_dp_nontermination_state(&state, &proof).unwrap();
                let path = std::env::temp_dir()
                    .join(format!("ferrum-no-instance-{}.xml", std::process::id()));
                std::fs::write(&path, xml).unwrap();
                let checker =
                    std::env::var("CETA_CSR_BIN").unwrap_or_else(|_| "../CeTA-CSR/ceta".into());
                let output = std::process::Command::new(checker)
                    .arg(&path)
                    .output()
                    .unwrap();
                let _ = std::fs::remove_file(path);
                assert!(
                    output.status.success()
                        && String::from_utf8_lossy(&output.stdout).trim() == "CERTIFIED",
                    "{}{}",
                    String::from_utf8_lossy(&output.stdout),
                    String::from_utf8_lossy(&output.stderr)
                );
            }
        }
        assert!(DpStrategy::parse("nontermination-instance(candidate=3)").is_ok());
    }
}
