use std::collections::BTreeSet;
use std::time::Instant;

use crate::core::{RewriteStrategy, Term, Trs};
use crate::proving::dependency_pairs::{
    ArcticMatrixDomain, CsrDpConstruction, CsrDpProblemContext, DpProblemContext, DpProofTree,
    DpReductionPairProof, DpRemovalProof, DpStrategyProcessor, ReductionPairContext,
    csr_construction_uses_u3, csr_pairs_have_marked_or_fresh_unhiding_roots, csr_u3_usable_rules,
    innermost_csr_usable_rules, is_rta_marking_obligation, muterm_extended_basic_usable_rules,
    reduction_pair_is_mono_for_residual, reduction_pair_residual_base_rules,
    rta_context_sensitive_usable_rules, rta_reduction_pair_weak_rules, same_rule_set,
    strategy_timed_out, synthesize_component_removal_by_processor,
    synthesize_path_order_for_component_requiring_strict_rules,
    synthesize_kbo_for_component_requiring_strict_rules,
    synthesize_monotonic_usable_polynomial, usable_rule_reduction_pair_is_certifiable,
    ceta_innermost_usable_rules_closed_with_filter, term_is_q_normal,
};
use crate::proving::runtime::CancellationScope;

use super::super::{
    ProblemCertificate, ProblemState, ProcessorApplication, ProcessorResult, WorklistProcessor,
};

pub struct ReductionPairProcessor {
    pub processor: DpStrategyProcessor,
    pub deadline: Option<Instant>,
}

impl WorklistProcessor for ReductionPairProcessor {
    fn name(&self) -> &'static str {
        "dependency-pair-reduction-pair"
    }

    fn apply(&self, state: &ProblemState) -> ProcessorResult {
        let ProblemState::DependencyPairs(problem) = state else {
            return ProcessorResult::Inapplicable;
        };
        let cancellation = CancellationScope::current(self.deadline);
        if cancellation.is_cancelled() || strategy_timed_out(self.deadline) {
            return ProcessorResult::TimedOut;
        }
        let stats = problem.stats.clone();
        let mut context = ReductionPairContext::new(
            &problem.trs,
            &problem.pairs,
            stats.active_rules.as_deref(),
            stats.active_rules_are_residual,
            stats.minimal,
            &problem.options,
            problem.innermost_lhss.as_deref(),
            self.deadline,
            &cancellation,
        );
        if !stats.minimal && stats.active_rules_are_residual
            && matches!(stats.problem, DpProblemContext::ContextSensitive(_))
        {
            // A preceding CSR usable-rules processor has established this R.
            // Non-minimal continuations cannot silently filter it again:
            // ask synthesis to orient precisely the certified local rules.
            context.usable_rules = context.input_rules.clone();
            context.fixed_usable_rules = true;
        }
        if !stats.strict_rules.is_empty() {
            // A generalized split can make an ordinary rule strict even when
            // that rule is outside the pair-local usable-rule approximation.
            // Such a rule is discharged by `monoRedPairUrProc`'s non-usable
            // rule case, rather than being an applicability failure.  Keep
            // the complete residual rule universe until the selected order
            // computes and certifies its own interpretation-dependent U(R).
            context.usable_rules = context.input_rules.clone();
            let mut required = Vec::new();
            for strict_rule in &stats.strict_rules {
                let Some(index) = context.usable_rules.iter().position(|rule| {
                    super::general_red_pair::alpha_equivalent_rules(rule, strict_rule)
                }) else {
                    return ProcessorResult::Inapplicable;
                };
                required.push(index);
            }
            context.required_strict_rule_indices = required;
        }
        let strong_pairs = problem
            .pairs
            .iter()
            .filter(|pair| !stats.pair_is_weak(pair))
            .cloned()
            .collect::<Vec<_>>();
        let strong_pair_indices = problem
            .pairs
            .iter()
            .enumerate()
            .filter_map(|(index, pair)| (!stats.pair_is_weak(pair)).then_some(index))
            .collect::<Vec<_>>();
        let selected_strict_pairs = match self.processor {
            DpStrategyProcessor::SelectedLinearPolynomial {
                candidate_index: 0, ..
            } => None,
            DpStrategyProcessor::SelectedLinearPolynomial {
                candidate_index, ..
            } => {
                let Some(pair) = strong_pairs.get(candidate_index - 1) else {
                    return ProcessorResult::Inapplicable;
                };
                Some(vec![pair.clone()])
            }
            _ => None,
        };
        if let Some(selected) = selected_strict_pairs.as_deref() {
            context.strict_pairs = Some(selected);
        } else if strong_pairs.len() != problem.pairs.len()
            && matches!(
                self.processor,
                DpStrategyProcessor::LinearPolynomial { .. }
                    | DpStrategyProcessor::SelectedLinearPolynomial { .. }
            )
        {
            context.strict_pairs = Some(&strong_pairs);
        }
        if let DpStrategyProcessor::SelectedMatrixInterpretation {
            candidate_index, ..
        } = self.processor
        {
            if candidate_index > 0 {
                if let Some(index) = strong_pair_indices.get(candidate_index - 1) {
                    context.required_strict_pair_index = Some(*index);
                } else if problem.innermost_lhss.is_some()
                    && matches!(stats.problem, DpProblemContext::Ordinary)
                    && stats.minimal && stats.normal_form_substitutions && stats.weak_pairs.is_empty()
                {
                    // Candidates after P address Q-monotonic ordinary-rule
                    // removal directly, without first exhausting a DP query.
                    let index = candidate_index - strong_pair_indices.len() - 1;
                    if index >= context.usable_rules.len() { return ProcessorResult::Inapplicable; }
                    context.q_monotonic_rule_index = Some(index);
                } else {
                    return ProcessorResult::Inapplicable;
                }
            }
        }
        if let DpStrategyProcessor::SelectedArcticMatrixInterpretation {
            candidate_index, ..
        } = self.processor
        {
            if candidate_index > 0 {
                let Some(index) = strong_pair_indices.get(candidate_index - 1) else {
                    return ProcessorResult::Inapplicable;
                };
                context.required_strict_pair_index = Some(*index);
            }
        }
        if let DpStrategyProcessor::SelectedIntegerArcticMatrixInterpretation {
            candidate_index,
            ..
        } = self.processor
        {
            if candidate_index > 0 {
                let Some(index) = strong_pair_indices.get(candidate_index - 1) else {
                    return ProcessorResult::Inapplicable;
                };
                context.required_strict_pair_index = Some(*index);
            }
        }
        if let DpStrategyProcessor::SelectedPathOrder { candidate_index } = self.processor {
            if candidate_index > 0 {
                let Some(index) = strong_pair_indices.get(candidate_index - 1) else {
                    return ProcessorResult::Inapplicable;
                };
                context.required_strict_pair_index = Some(*index);
            }
        }

        let innermost_rta08 = matches!(
            &stats.problem,
            DpProblemContext::ContextSensitive(context)
                if context.construction == CsrDpConstruction::InnermostRta08
        );
        let rta08 = innermost_rta08
            || (stats.minimal
                && problem
                    .pairs
                    .iter()
                    .any(|pair| matches!(pair.rhs(), Term::Var(_)))
                && matches!(
                    &stats.problem,
                    DpProblemContext::ContextSensitive(context)
                        if context.construction == CsrDpConstruction::Rta08
                ));
        let muterm_unhiding = matches!(
            &stats.problem,
            DpProblemContext::ContextSensitive(context)
                if context.construction == CsrDpConstruction::MutermUnhiding
        );
        let muterm_expanded = matches!(
            &stats.problem,
            DpProblemContext::ContextSensitive(context)
                if context.construction == CsrDpConstruction::MutermExpanded
        );
        if muterm_unhiding && stats.active_rules_are_residual {
            // A local-usable node has already established this precise R.
            // Do not append bridges again or silently compute another U:
            // both change the obligation of a non-minimal continuation.
            context.usable_rules = context.input_rules.clone();
            context.fixed_usable_rules = true;
            context.required_strict_rule_indices.clear();
        } else if muterm_unhiding {
            // Compute the pair-local innermost closure over the source rules
            // and exact unhiding bridges. Marked bridge targets are selected
            // only when they occur in this component; appending every bridge
            // here used to reintroduce unrelated `fact`/`if` source rules and
            // made MU-TERM's valid ExIntrod reduction triple undiscoverable.
            let DpProblemContext::ContextSensitive(csr_context) = &stats.problem else {
                unreachable!()
            };
            let bridges =
                crate::proving::dependency_pairs::muterm_innermost_unhiding_rules(&csr_context.csr);
            let mut rules_and_bridges = context.input_rules.clone();
            for rule in bridges {
                if !rules_and_bridges.contains(&rule) {
                    rules_and_bridges.push(rule);
                }
            }
            context.usable_rules =
                innermost_csr_usable_rules(&csr_context.csr, &rules_and_bridges, &problem.pairs);
            context.fixed_usable_rules = true;
            context.required_strict_rule_indices.clear();
        } else if muterm_expanded {
            // The expanded processor is searched on ordinary pairs, but its
            // certifiable usable-rule boundary is defined from the typed
            // component before macro expansion.  Recover that component by
            // source-rule provenance; the exact expansion itself is checked
            // independently by CeTA.
            let DpProblemContext::ContextSensitive(csr_context) = &stats.problem else {
                unreachable!()
            };
            let source_rules = problem
                .pairs
                .iter()
                .map(|pair| pair.source_rule())
                .collect::<std::collections::BTreeSet<_>>();
            let typed_pairs =
                crate::proving::dependency_pairs::rta_csr_dependency_pairs(&csr_context.csr)
                    .into_iter()
                    .filter(|pair| source_rules.contains(&pair.source_rule()))
                    .collect::<Vec<_>>();
            let bridges =
                crate::proving::dependency_pairs::muterm_innermost_unhiding_rules(&csr_context.csr);
            context.usable_rules = muterm_extended_basic_usable_rules(
                &csr_context.csr,
                &context.input_rules,
                &typed_pairs,
                &bridges,
            );
            context.fixed_usable_rules = true;
            context.required_strict_rule_indices.clear();
        } else if rta08 {
            let DpProblemContext::ContextSensitive(csr_context) = &stats.problem else {
                unreachable!()
            };
            let usable = rta_context_sensitive_usable_rules(
                &csr_context.csr,
                &context.input_rules,
                &problem.pairs,
            );
            context.usable_rules =
                rta_reduction_pair_weak_rules(&csr_context.csr, &usable, &problem.pairs);
            context.fixed_usable_rules = true;
            context.required_strict_rule_indices = context
                .usable_rules
                .iter()
                .enumerate()
                .filter_map(|(index, rule)| is_rta_marking_obligation(rule).then_some(index))
                .collect();
        } else if stats.minimal
            && let DpProblemContext::ContextSensitive(csr_context) = &stats.problem
            && csr_construction_uses_u3(csr_context.construction)
        {
            // A reduction-pair step preserves the minimal improved/native
            // CS-DP framework.  Recompute U3 from the residual pairs and the
            // live R component after every such step.  `active_rules` is only
            // the previous processor's usable subset for a non-monotone
            // redPairUrProc; that processor does not replace R.  Seeding U3
            // from it can omit rules that CeTA correctly reintroduces when it
            // checks the residual (the former Ex4_7_37 mismatch).  Monotone
            // rule deletion is already reflected in `problem.trs`.
            context.usable_rules = if csr_pairs_have_marked_or_fresh_unhiding_roots(
                &csr_context.csr,
                &problem.pairs,
            ) {
                csr_u3_usable_rules(&csr_context.csr, &context.input_rules, &problem.pairs)
            } else {
                problem.trs.rules().to_vec()
            };
            context.fixed_usable_rules = true;
        }

        if context.fixed_usable_rules && selected_strict_pairs.is_some() {
            return ProcessorResult::Inapplicable;
        }
        let q_aware_removal = (|| {
                // Alternative proof obligation: CeTA's innermost usable-rule
                // branch does not require Q to collapse under the filter.
                // Search without that sufficient condition, then independently
                // check the actual Q-aware closure before accepting the model.
                // None is a synthesis option only; the live Q is untouched.
                let q = problem.innermost_lhss.as_deref()?;
                if !matches!(stats.problem, DpProblemContext::Ordinary)
                    || !stats.normal_form_substitutions
                    || q.is_empty()
                    || !context.required_strict_rule_indices.is_empty()
                    || context.input_rules.iter().any(|r| term_is_q_normal(r.lhs(), q))
                    || context.is_cancelled_or_timed_out()
                {
                    return None;
                }
                let mut options = context.scoped_options();
                let mut candidate = match self.processor {
                    DpStrategyProcessor::Kbo { max_weight, max_symbols } => {
                        options.max_symbol_weight = max_weight;
                        options.max_symbols = max_symbols;
                        synthesize_kbo_for_component_requiring_strict_rules(
                            &problem.pairs, &context.input_rules, &[], &options,
                            None, self.deadline, false,
                        )?
                    }
                    DpStrategyProcessor::PathOrder | DpStrategyProcessor::SelectedPathOrder { .. }
                    | DpStrategyProcessor::ConfiguredPathOrder { .. } => {
                        if let DpStrategyProcessor::ConfiguredPathOrder { order, optimize } = self.processor {
                            options.path_order_status = Some(order);
                            options.path_order_optimize = optimize;
                        }
                        synthesize_path_order_for_component_requiring_strict_rules(
                            &problem.pairs, &context.input_rules, &[], &options,
                            None, context.required_strict_pair_index, None, self.deadline, false,
                        )?
                    }
                    _ => return None,
                };
                let filter = match &candidate.reduction_pair {
                    DpReductionPairProof::Kbo { argument_filter, .. }
                    | DpReductionPairProof::PathOrder { argument_filter, .. } => argument_filter,
                    _ => return None,
                };
                if !ceta_innermost_usable_rules_closed_with_filter(
                    &context.input_rules, q, &problem.pairs,
                    candidate.usable_rules.as_deref()?, filter,
                ) {
                    return None;
                }
                candidate.strict_rule_indices.clear();
                Some(candidate)
        })();
        let removal = q_aware_removal.or_else(||
            synthesize_component_removal_by_processor(&self.processor, &context)).or_else(|| {
                (problem.trs.strategy() == RewriteStrategy::Full
                    && matches!(
                        self.processor,
                        DpStrategyProcessor::LinearPolynomial { .. }
                            | DpStrategyProcessor::SelectedLinearPolynomial { .. }
                            | DpStrategyProcessor::SmtPolynomial { .. }
                    ))
                .then(|| {
                    let mut options = context.scoped_options();
                    match self.processor {
                        DpStrategyProcessor::LinearPolynomial {
                            max_constant,
                            max_coefficient,
                            ..
                        }
                        | DpStrategyProcessor::SelectedLinearPolynomial {
                            max_constant,
                            max_coefficient,
                            ..
                        }
                        | DpStrategyProcessor::SmtPolynomial {
                            max_constant,
                            max_coefficient,
                            ..
                        } => {
                            options.max_polynomial_constant = max_constant;
                            options.max_polynomial_coefficient = max_coefficient;
                        }
                        _ => {}
                    }
                    synthesize_monotonic_usable_polynomial(
                        &problem.pairs,
                        &context.usable_rules,
                        &options,
                        !same_rule_set(&context.usable_rules, &context.input_rules),
                        self.deadline,
                    )
                })
                .flatten()
            }).or_else(|| {
                // A full-R redPairProc does not use innermost usable-rule
                // side conditions. CeTA's generic_ur_af_redtriple_proc with
                // U_opt=None checks all active rules, independently of Q.
                // This is an alternative search obligation, NOT Q removal:
                // the live state's Q, strategy, and minimality stay intact.
                if !matches!(stats.problem, DpProblemContext::Ordinary)
                    || !matches!(self.processor, DpStrategyProcessor::Kbo { .. } | DpStrategyProcessor::PathOrder
                        | DpStrategyProcessor::SelectedPathOrder { .. } | DpStrategyProcessor::ConfiguredPathOrder { .. })
                    || !problem.innermost_lhss.as_ref().is_some_and(|q| !q.is_empty())
                    || !context.required_strict_rule_indices.is_empty()
                    || !same_rule_set(&context.usable_rules, &context.input_rules)
                    || context.is_cancelled_or_timed_out()
                {
                    return None;
                }
                let mut options = context.scoped_options();
                if let DpStrategyProcessor::Kbo { max_weight, max_symbols } = self.processor {
                    options.max_symbol_weight = max_weight;
                    options.max_symbols = max_symbols;
                    synthesize_kbo_for_component_requiring_strict_rules(
                        &problem.pairs, &context.input_rules, &[], &options,
                        None, self.deadline, true,
                    )
                } else {
                    if let DpStrategyProcessor::ConfiguredPathOrder { order, optimize } = self.processor {
                        options.path_order_status = Some(order);
                        options.path_order_optimize = optimize;
                    }
                    synthesize_path_order_for_component_requiring_strict_rules(
                        &problem.pairs, &context.input_rules, &[], &options,
                        None, context.required_strict_pair_index, None, self.deadline, true,
                    )
                }
            });
        let Some(mut removal) = removal else {
            return ProcessorResult::Inapplicable;
        };
        let recursive_muterm = muterm_unhiding && stats.active_rules_are_residual;
        if recursive_muterm {
            // The verified local MU-TERM continuation deletes pairs, not
            // rules. A strict rule orientation still implies the required
            // weak orientation, but must not change R or select monoRedPair.
            removal.strict_rule_indices.clear();
        }
        if rta08
            && matches!(
                removal.reduction_pair,
                DpReductionPairProof::MaxPolynomial { .. }
            )
        {
            return ProcessorResult::Inapplicable;
        }
        if rta08 {
            let strict_rules = removal
                .strict_rule_indices
                .iter()
                .copied()
                .collect::<BTreeSet<_>>();
            if !context
                .usable_rules
                .iter()
                .enumerate()
                .filter(|(_, rule)| is_rta_marking_obligation(rule))
                .all(|(index, _)| strict_rules.contains(&index))
            {
                return ProcessorResult::Inapplicable;
            }
        }
        if muterm_unhiding {
            // The outer localUsableRulesProc fixes one ordinary rule
            // component for the complete child proof.  Strict orientation
            // of a weak rule is harmless, but must not silently turn into a
            // rule-deletion step that changes that component mid-chain.
            removal.strict_rule_indices.clear();
        }
        removal
            .strict_pair_indices
            .retain(|index| !stats.pair_is_weak(&problem.pairs[*index]));
        // A redPairUrProc is also a genuine transformation when the order
        // weakly orients every obligation but its interpretation-dependent
        // usable-rule closure strictly shrinks R.  This is the modular rule
        // removal step used by the Zantema z12--z18 family: no DP is strict,
        // yet deleting all non-usable base rules exposes a certifiable
        // switchInnermost/QDP-to-SRS continuation.  The synthesizer has
        // already validated the order and closure; do not discard that
        // progress merely because both strict-index lists are empty.
        let usable_restriction_progress = removal.usable_rules.as_ref().is_some_and(|usable| {
            !same_rule_set(usable, &context.input_rules)
                && usable.iter().all(|rule| context.input_rules.contains(rule))
        });
        if removal.strict_pair_indices.is_empty()
            && removal.strict_rule_indices.is_empty()
            && !usable_restriction_progress
            && !(innermost_rta08
                && problem
                    .pairs
                    .iter()
                    .all(|pair| matches!(pair.rhs(), Term::Var(_))))
        {
            return ProcessorResult::Inapplicable;
        }
        if context.is_cancelled_or_timed_out() {
            return ProcessorResult::TimedOut;
        }
        let proof_usable_rules = removal
            .usable_rules
            .clone()
            .unwrap_or_else(|| context.usable_rules.clone());
        let strict_rule_indices = removal
            .strict_rule_indices
            .iter()
            .copied()
            .collect::<BTreeSet<_>>();
        let strict_rules = proof_usable_rules
            .iter()
            .cloned()
            .enumerate()
            .filter_map(|(index, rule)| strict_rule_indices.contains(&index).then_some(rule))
            .collect::<Vec<_>>();
        let residual_usable_rules = proof_usable_rules
            .iter()
            .cloned()
            .enumerate()
            .filter_map(|(index, rule)| (!strict_rule_indices.contains(&index)).then_some(rule))
            .collect::<Vec<_>>();
        let transformation_rules = if rta08 {
            Some(context.input_rules.clone())
        } else {
            Some(residual_usable_rules.clone())
        };
        let usable_reference_rules = match &stats.problem {
            DpProblemContext::ContextSensitive(csr_context)
                if !stats.active_rules_are_residual
                    && matches!(
                        csr_context.construction,
                        CsrDpConstruction::Innermost | CsrDpConstruction::MutermUnhiding
                    ) =>
            {
                // Without an explicit residual boundary, record the usable
                // restriction against the source CSR. After a separately
                // certified usable-rules step, however, R is already the
                // active local rule set. Comparing it to the original CSR
                // would invent another restriction and reject a legitimate
                // non-minimal redPairProc continuation.
                csr_context.csr.rules()
            }
            _ => &context.input_rules,
        };
        let uses_usable_rules = !same_rule_set(&proof_usable_rules, usable_reference_rules);
        let improved = matches!(
            stats.problem,
            DpProblemContext::ContextSensitive(CsrDpProblemContext {
                construction: CsrDpConstruction::Improved,
                ..
            })
        );
        // Improved CS-DPs must retain their minimal CSR obligation after
        // every reduction-pair deletion.  The complete active rule set is a
        // valid (if non-minimal) closed U3 set, so a full-rule order can use
        // the same recursive checker as a proper U3 usable-rule subset.
        // RTA08 keeps its established usable-rule-only certificate shape.
        let force_non_mono_usable_rules =
            improved || (uses_usable_rules && rta08) || recursive_muterm;
        if !usable_rule_reduction_pair_is_certifiable(stats.minimal, uses_usable_rules)
            && !innermost_rta08
        {
            return ProcessorResult::Inapplicable;
        }

        let strict = removal
            .strict_pair_indices
            .iter()
            .copied()
            .collect::<BTreeSet<_>>();
        let selected_atom = exact_selected_atom(&self.processor, &removal.reduction_pair);
        let reduction = DpRemovalProof {
            pairs: problem.pairs.clone(),
            usable_rules: proof_usable_rules,
            uses_usable_rules,
            force_non_mono_usable_rules,
            strict_pair_indices: removal.strict_pair_indices,
            strict_rules,
            reduction_pair: removal.reduction_pair,
        };
        let residual_pairs = problem
            .pairs
            .iter()
            .cloned()
            .enumerate()
            .filter_map(|(index, pair)| (!strict.contains(&index)).then_some(pair))
            .collect::<Vec<_>>();
        let q_monotonic = problem.trs.strategy() == RewriteStrategy::Innermost
            && !reduction.strict_rules.is_empty()
            && !reduction.force_non_mono_usable_rules;
        let mono = (reduction_pair_is_mono_for_residual(&reduction.reduction_pair) || q_monotonic)
            && !reduction.force_non_mono_usable_rules;
        // monoRedPairUrProc carries its reduced usable TRS into the residual.
        // A non-monotonic redPairUrProc uses usable rules only for its current
        // orientation obligation, so its residual retains the parent R.
        let continues_with_usable_rules = uses_usable_rules && mono;
        let active_rules = if rta08 {
            context.input_rules.clone()
        } else if continues_with_usable_rules || mono {
            residual_usable_rules
        } else {
            stats
                .active_rules
                .clone()
                .unwrap_or_else(|| problem.trs.rules().to_vec())
        };
        let residual_base_rules = reduction_pair_residual_base_rules(
            problem.trs.rules(),
            &active_rules,
            rta08 || continues_with_usable_rules || mono,
        );
        let mut residual = problem.clone();
        residual.trs = Trs::new_with_strategy(
            problem.trs.name().map(str::to_string),
            problem.trs.variables().clone(),
            residual_base_rules,
            problem.trs.strategy(),
        );
        // In the source-restricted innermost RTA08 framework, a weak
        // collapsing pair still contributes a strict marking step.  The
        // verified checker can therefore close an all-collapsing residual
        // directly; do not misreport those pairs as strictly oriented by the
        // synthesized reduction pair.
        let closes_collapsing_residual = innermost_rta08
            && residual_pairs
                .iter()
                .all(|pair| matches!(pair.rhs(), Term::Var(_)));
        residual.pairs = if closes_collapsing_residual {
            Vec::new()
        } else {
            residual_pairs
        };
        residual.stats = stats;
        residual.stats.strict_rules.retain(|parent_strict| {
            !reduction.strict_rules.iter().any(|removed| {
                super::general_red_pair::alpha_equivalent_rules(parent_strict, removed)
            }) && (!continues_with_usable_rules
                || active_rules.iter().any(|active| {
                    super::general_red_pair::alpha_equivalent_rules(parent_strict, active)
                }))
        });
        residual.stats.active_rules =
            (active_rules.as_slice() != residual.trs.rules()).then(|| active_rules.clone());
        residual.stats.graph_rules =
            (active_rules.as_slice() != residual.trs.rules()).then_some(active_rules);
        residual.stats.transformation_rules = transformation_rules;

        let application = ProcessorApplication::new(
            vec![ProblemState::DependencyPairs(residual)],
            move |children| {
                let [ProblemCertificate::DependencyPairTree(proof)] =
                    <[ProblemCertificate; 1]>::try_from(children).ok()?
                else {
                    return None;
                };
                Some(ProblemCertificate::DependencyPairTree(
                    DpProofTree::RedPair {
                        reduction: reduction.clone(),
                        proof: Box::new(proof),
                    },
                ))
            },
        );
        ProcessorResult::Applied(match selected_atom {
            Some(atom) => application.with_selected_atom(atom),
            None => application,
        })
    }
}

fn exact_selected_atom(
    source_processor: &DpStrategyProcessor,
    proof: &DpReductionPairProof,
) -> Option<String> {
    if matches!(
        source_processor,
        DpStrategyProcessor::TargetPathOrder { .. }
            | DpStrategyProcessor::ConfiguredPathOrder { .. }
            | DpStrategyProcessor::TargetLinearPolynomial { .. }
            | DpStrategyProcessor::MinimumDeletionLinearPolynomial { .. }
            | DpStrategyProcessor::TargetArcticMatrixInterpretation { .. }
            | DpStrategyProcessor::TargetWeakPolynomial { .. }
            | DpStrategyProcessor::TargetRationalPolynomial { .. }
    ) {
        return Some(source_processor.to_strategy_atom());
    }
    if matches!(
        source_processor,
        DpStrategyProcessor::PathOrder | DpStrategyProcessor::SelectedPathOrder { .. }
    ) {
        let selected = match source_processor {
            DpStrategyProcessor::PathOrder => {
                DpStrategyProcessor::SelectedPathOrder { candidate_index: 0 }
            }
            selected => selected.clone(),
        };
        return Some(selected.to_strategy_atom());
    }
    if matches!(
        source_processor,
        DpStrategyProcessor::LinearPolynomial { .. }
            | DpStrategyProcessor::SelectedLinearPolynomial { .. }
    ) {
        let selected = match source_processor {
            DpStrategyProcessor::LinearPolynomial {
                max_constant,
                max_coefficient,
                max_symbols,
                max_arity,
            } => DpStrategyProcessor::SelectedLinearPolynomial {
                max_constant: *max_constant,
                max_coefficient: *max_coefficient,
                max_symbols: *max_symbols,
                max_arity: *max_arity,
                candidate_index: 0,
            },
            selected => selected.clone(),
        };
        return Some(selected.to_strategy_atom());
    }
    if matches!(
        source_processor,
        DpStrategyProcessor::IntegerArcticMatrixInterpretation { .. }
            | DpStrategyProcessor::SelectedIntegerArcticMatrixInterpretation { .. }
    ) {
        let selected = match source_processor {
            DpStrategyProcessor::IntegerArcticMatrixInterpretation {
                threshold,
                all_strict,
                max_finite_per_row,
                bitvectors,
                root_projection,
                optimize,
                symmetry,
                solver,
                dimension,
                min_value,
                max_value,
                max_symbols,
                max_arity,
            } => DpStrategyProcessor::SelectedIntegerArcticMatrixInterpretation {
                threshold: *threshold,
                all_strict: *all_strict,
                max_finite_per_row: *max_finite_per_row,
                bitvectors: *bitvectors,
                root_projection: *root_projection,
                optimize: *optimize,
                symmetry: *symmetry,
                solver: solver.clone(),
                dimension: *dimension,
                min_value: *min_value,
                max_value: *max_value,
                max_symbols: *max_symbols,
                max_arity: *max_arity,
                candidate_index: 0,
            },
            selected => selected.clone(),
        };
        return Some(selected.to_strategy_atom());
    }
    // A selected Arctic search index fixes only the search lane, not the SMT
    // model returned inside that lane.  Persist the validated interpretation
    // below so oracle replay is a direct, deterministic proof witness.
    if matches!(
        source_processor,
        DpStrategyProcessor::MatrixInterpretation { .. }
            | DpStrategyProcessor::SelectedMatrixInterpretation { .. }
    ) {
        let selected = match source_processor {
            DpStrategyProcessor::MatrixInterpretation {
                dimension,
                max_constant,
                max_coefficient,
                min_nonzero,
                max_nonzero,
                max_nonzero_constants,
                max_nonzero_per_row,
                max_symbols,
                max_arity,
            } => DpStrategyProcessor::SelectedMatrixInterpretation {
                dimension: *dimension,
                max_constant: *max_constant,
                max_coefficient: *max_coefficient,
                min_nonzero: *min_nonzero,
                max_nonzero: *max_nonzero,
                max_nonzero_constants: *max_nonzero_constants,
                max_nonzero_per_row: *max_nonzero_per_row,
                max_symbols: *max_symbols,
                max_arity: *max_arity,
                candidate_index: 0,
            },
            selected => selected.clone(),
        };
        return Some(selected.to_strategy_atom());
    }
    let processor = match proof {
        DpReductionPairProof::Polynomial { interpretation, .. } => {
            if interpretation.iter().any(|(_, constant, _)| *constant < 0) {
                DpStrategyProcessor::ExactWeakPolynomial {
                    interpretation: interpretation.clone(),
                }
            } else if matches!(
                source_processor,
                DpStrategyProcessor::MonotonicPolynomial { .. }
                    | DpStrategyProcessor::ExactMonotonicPolynomial { .. }
            ) {
                DpStrategyProcessor::ExactMonotonicPolynomial {
                    interpretation: interpretation.clone(),
                }
            } else {
                DpStrategyProcessor::ExactLinearPolynomial {
                    interpretation: interpretation.clone(),
                }
            }
        }
        DpReductionPairProof::MaxPolynomial { interpretation, .. } => {
            DpStrategyProcessor::ExactMaxPolynomial {
                interpretation: interpretation.clone(),
            }
        }
        DpReductionPairProof::WeightedPathOrderMax { .. } => return None,
        DpReductionPairProof::RationalPolynomial {
            denominator,
            interpretation,
            ..
        } => DpStrategyProcessor::ExactRationalPolynomial {
            denominator: *denominator,
            interpretation: interpretation.clone(),
        },
        DpReductionPairProof::RationalNaturalPolynomial {
            denominator,
            delta,
            interpretation,
            ..
        } => DpStrategyProcessor::ExactRationalNaturalPolynomial {
            denominator: *denominator,
            delta: *delta,
            interpretation: interpretation
                .iter()
                .map(|(symbol, polynomial)| {
                    (
                        symbol.clone(),
                        polynomial.constant,
                        polynomial.linear.clone(),
                        polynomial.quadratic.clone(),
                    )
                })
                .collect(),
        },
        DpReductionPairProof::Matrix { interpretation, .. } => {
            DpStrategyProcessor::ExactMatrixInterpretation {
                interpretation: interpretation
                    .iter()
                    .map(|(symbol, value)| {
                        (
                            symbol.clone(),
                            value.constant.clone(),
                            value.coefficients.clone(),
                        )
                    })
                    .collect(),
            }
        }
        DpReductionPairProof::ArcticMatrix {
            interpretation,
            domain,
            ..
        } => DpStrategyProcessor::ExactArcticMatrixInterpretation {
            integer_domain: *domain == ArcticMatrixDomain::Integers,
            interpretation: interpretation
                .iter()
                .map(|(symbol, value)| {
                    (
                        symbol.clone(),
                        value.constant.clone(),
                        value.coefficients.clone(),
                    )
                })
                .collect(),
        },
        DpReductionPairProof::PathOrder {
            order,
            statuses,
            precedence,
            precedence_ranks,
            argument_filter,
            ..
        } => DpStrategyProcessor::ExactPathOrder {
            default_order: *order,
            statuses: statuses.clone(),
            precedence: precedence.clone(),
            precedence_ranks: precedence_ranks.clone(),
            argument_filter: argument_filter.clone(),
        },
        // There is not yet a one-shot strategy representation for these
        // proof families.  Keep the configured atomic search processor until
        // such a representation exists; never invent a lossy witness.
        DpReductionPairProof::NaturalPolynomial { .. }
        | DpReductionPairProof::IntegerMatrix { .. }
        | DpReductionPairProof::Kbo { .. } => return None,
    };
    Some(processor.to_strategy_atom())
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::proving::dependency_pairs::{DpOptions, dependency_pairs};
    use crate::proving::processors::dp::DpProblemState;

    #[test]
    fn native_full_rule_path_order_preserves_innermost_q() {
        check_native_full_rule_order_preserves_innermost_q(DpStrategyProcessor::PathOrder);
    }

    #[test]
    fn configured_path_order_roundtrips_and_preserves_q() {
        use crate::proving::dependency_pairs::{DpStrategy, DpPathOrderKind};
        for order in [DpPathOrderKind::Rpo, DpPathOrderKind::Lpo] {
            let processor = DpStrategyProcessor::ConfiguredPathOrder { order, optimize: false };
            assert_eq!(DpStrategy::parse(&processor.to_strategy_atom()).unwrap(),
                       DpStrategy::Processor(processor.clone()));
            check_native_full_rule_order_preserves_innermost_q(processor);
        }
        assert!(DpStrategy::parse("path-order(status=bogus)").is_err());
        assert!(DpStrategy::parse("path-order(status=rpo,optimize=2)").is_err());
    }

    #[test]
    fn native_full_rule_kbo_preserves_innermost_q() {
        check_native_full_rule_order_preserves_innermost_q(DpStrategyProcessor::Kbo {
            max_weight: 4, max_symbols: 16,
        });
    }

    fn check_native_full_rule_order_preserves_innermost_q(atom: DpStrategyProcessor) {
        use crate::core::{RewriteRule, Variable};
        use crate::proving::dependency_pairs::DependencyPair;
        let x = Term::var("x");
        let s = |t| Term::app("succ", vec![t]);
        let f = |t| Term::app("worker", vec![t]);
        let p = |t| Term::app("call#", vec![t]);
        let trs = Trs::new_with_strategy(
            None, BTreeSet::from([Variable::new("x")]),
            vec![RewriteRule::new(f(s(x.clone())), f(x.clone()))],
            RewriteStrategy::Innermost,
        );
        let pair = DependencyPair::new_for_test(p(s(s(x.clone()))), p(f(x)));
        let problem = DpProblemState::ordinary(trs, vec![pair], DpOptions::default());
        let q = problem.innermost_lhss.clone();
        assert!(q.as_ref().is_some_and(|q| !q.is_empty()));
        let processor = ReductionPairProcessor {
            processor: atom,
            deadline: Some(Instant::now() + std::time::Duration::from_secs(10)),
        };
        let ProcessorResult::Applied(application) =
            processor.apply(&ProblemState::DependencyPairs(problem)) else {
            panic!("full-R order should orient this QDP without Q-based filtering");
        };
        let [ProblemState::DependencyPairs(child)] = application.residuals.as_slice() else {
            panic!("expected an empty-pair residual with its context intact");
        };
        assert!(child.pairs.is_empty());
        assert_eq!(child.innermost_lhss, q);
        assert_eq!(child.trs.strategy(), RewriteStrategy::Innermost);
        assert_eq!(child.trs.rules().len(), 1);
    }

    #[test]
    fn native_full_rule_path_order_rejects_a_cyclic_pair() {
        use crate::core::{RewriteRule, Variable};
        use crate::proving::dependency_pairs::DependencyPair;
        let x = Term::var("x");
        let f = |t| Term::app("worker", vec![t]);
        let term = Term::app("call#", vec![f(x.clone())]);
        let trs = Trs::new_with_strategy(
            None, BTreeSet::from([Variable::new("x")]),
            vec![RewriteRule::new(f(Term::app("succ", vec![x.clone()])), f(x))],
            RewriteStrategy::Innermost,
        );
        let problem = DpProblemState::ordinary(trs,
            vec![DependencyPair::new_for_test(term.clone(), term)], DpOptions::default());
        for atom in [DpStrategyProcessor::PathOrder,
            DpStrategyProcessor::Kbo { max_weight: 4, max_symbols: 16 }] {
            let processor = ReductionPairProcessor {
                processor: atom,
                deadline: Some(Instant::now() + std::time::Duration::from_secs(10)),
            };
            assert!(matches!(processor.apply(&ProblemState::DependencyPairs(problem.clone())),
                ProcessorResult::Inapplicable));
        }
    }

    #[test]
    fn monotone_order_can_progress_only_by_restricting_usable_rules() {
        let trs = crate::parsing::parse_ari_trs(
            Some("z18-usable-restriction".to_owned()),
            r#"
(format TRS)
(fun f 2)
(fun a 1)
(fun b 1)
(rule (f x (a (b y))) (a (f (a (b x)) y)))
(rule (f (a x) y) (f x (a y)))
(rule (f (b x) y) (f x (b y)))
"#,
        )
        .unwrap();
        let pairs = dependency_pairs(&trs);
        assert_eq!(pairs.len(), 3);
        let state = ProblemState::DependencyPairs(DpProblemState::ordinary(
            trs,
            pairs,
            DpOptions::default(),
        ));
        let processor = ReductionPairProcessor {
            processor: DpStrategyProcessor::ExactMonotonicPolynomial {
                interpretation: vec![
                    ("a".to_owned(), 0, vec![1]),
                    ("b".to_owned(), 2, vec![1]),
                    ("f#".to_owned(), 0, vec![1, 1]),
                ],
            },
            deadline: None,
        };

        let ProcessorResult::Applied(application) = processor.apply(&state) else {
            panic!("a strict usable-rule restriction must count as DP progress");
        };
        let [ProblemState::DependencyPairs(child)] = application.residuals.as_slice() else {
            panic!("expected one dependency-pair residual");
        };
        assert_eq!(child.pairs.len(), 3, "the order deletes no dependency pair");
        assert!(child.trs.rules().is_empty());
        assert!(
            child
                .stats
                .active_rules
                .as_deref()
                .unwrap_or(child.trs.rules())
                .is_empty()
        );
    }

    #[test]
    fn exact_monotone_order_can_delete_only_ordinary_rules() {
        let trs = crate::parsing::parse_ari_trs(
            Some("ordinary-dp-rule-only-removal".to_owned()),
            r#"
(format TRS)
(fun f 1)
(fun g 1)
(fun k 1)
(rule (f x) (g x))
(rule (g x) (f x))
(rule (k x) x)
"#,
        )
        .unwrap();
        let x = crate::core::Term::var("x");
        let pairs = vec![
            crate::proving::dependency_pairs::DependencyPair::new_for_test(
                crate::core::Term::app("p#", vec![crate::core::Term::app("k", vec![x.clone()])]),
                crate::core::Term::app(
                    "p#",
                    vec![crate::core::Term::app(
                        "f",
                        vec![crate::core::Term::app(
                            "g",
                            vec![crate::core::Term::app("k", vec![x])],
                        )],
                    )],
                ),
            ),
        ];
        let state = ProblemState::DependencyPairs(DpProblemState::ordinary(
            trs,
            pairs,
            DpOptions::default(),
        ));
        let processor = ReductionPairProcessor {
            processor: DpStrategyProcessor::ExactMonotonicPolynomial {
                interpretation: vec![
                    ("f".to_owned(), 0, vec![1]),
                    ("g".to_owned(), 0, vec![1]),
                    ("k".to_owned(), 1, vec![1]),
                    ("p#".to_owned(), 0, vec![1]),
                ],
            },
            deadline: None,
        };

        let ProcessorResult::Applied(application) = processor.apply(&state) else {
            panic!("strict ordinary-rule progress must be retained");
        };
        let [ProblemState::DependencyPairs(child)] = application.residuals.as_slice() else {
            panic!("expected one dependency-pair residual");
        };
        assert_eq!(child.pairs.len(), 1);
        let active_rules = child
            .stats
            .active_rules
            .as_deref()
            .unwrap_or(child.trs.rules());
        assert_eq!(active_rules.len(), 2);
        assert!(active_rules.iter().all(|rule| {
            rule.lhs()
                .root_symbol()
                .is_some_and(|root| root.as_str() != "k")
        }));
    }
}
