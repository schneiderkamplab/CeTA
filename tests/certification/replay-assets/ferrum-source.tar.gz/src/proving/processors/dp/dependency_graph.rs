use std::time::Instant;

use crate::core::RewriteStrategy;
use crate::parsing::{CpfInputProblem, parse_cpf_input};
use crate::proving::dependency_pairs::{
    DependencyPair, DpComponentProof, DpProblemContext, DpProofTree, DpStrategyProcessor,
    cached_ceta_q_dependency_pair_graph_with_rules_deadline,
    cached_dp_problem_dependency_graph_with_context_deadline, component_is_cyclic,
    component_proof_from_tree, dependency_pair_rules_alpha_equivalent,
    exact_graph_extra_pairs_are_acyclic, strategy_timed_out, strongly_connected_components,
    topologically_order_components,
};
use crate::standardize::translate_rule_symbols;

fn checker_graph_stats(problem: &super::DpProblemState) -> crate::proving::dependency_pairs::DpProofStats {
    let mut stats = problem.stats.clone();
    if let DpProblemContext::ContextSensitive(context) = &mut stats.problem {
        if context.construction == crate::proving::dependency_pairs::CsrDpConstruction::Improved {
            // The native processor and retained-witness validator must use
            // the same map as both CPF writers. Only the fresh auxiliary
            // wrapper is frozen; the source CSR rules/map remain unchanged.
            let fresh = crate::proving::dependency_pairs::fresh_unhiding_symbol(context.csr.trs());
            context.csr = context.csr.clone().with_frozen_auxiliary_symbol(fresh);
        }
    }
    stats
}

fn pairs_with_sources(
    rules: Vec<crate::core::RewriteRule>,
    source_rules: Option<Vec<usize>>,
) -> Vec<DependencyPair> {
    rules
        .into_iter()
        .enumerate()
        .map(|(index, rule)| {
            let source = source_rules
                .as_ref()
                .and_then(|sources| sources.get(index))
                .copied()
                .unwrap_or(index);
            DependencyPair::from_rule(rule, source)
        })
        .collect()
}

fn acyclic_component_proof(pairs: Vec<DependencyPair>) -> DpComponentProof {
    DpComponentProof {
        pairs,
        usable_rules: Vec::new(),
        interpretation: None,
        backend: None,
        usable_rules_processor: None,
        innermost_lhss_processor: None,
        reductions: Vec::new(),
        final_acyclic_components: Vec::new(),
        proof_tree: None,
        proved: false,
    }
}

fn weak_only_component_proof(pairs: Vec<DependencyPair>) -> DpComponentProof {
    DpComponentProof {
        pairs,
        usable_rules: Vec::new(),
        interpretation: None,
        backend: None,
        usable_rules_processor: None,
        innermost_lhss_processor: None,
        reductions: Vec::new(),
        final_acyclic_components: Vec::new(),
        proof_tree: Some(Box::new(DpProofTree::Empty)),
        proved: true,
    }
}

fn guarded_list_terminal_payload(problem: &super::DpProblemState) -> Option<String> {
    let DpProblemContext::ContextSensitive(context) = &problem.stats.problem else {
        return None;
    };
    if !problem.stats.minimal || !problem.stats.weak_pairs.is_empty() {
        return None;
    }
    super::guarded_list::terminal_payload(&context.csr, &problem.pairs)
}
use crate::proving::runtime::CancellationScope;

use super::super::{
    ProblemCertificate, ProblemState, ProcessorApplication, ProcessorResult, WorklistProcessor,
};

pub struct DependencyGraphProcessor {
    pub deadline: Option<Instant>,
}

pub struct ExactDependencyGraphProcessor {
    pub components: Vec<(Vec<usize>, bool)>,
    pub source_dp_input_xml: Option<String>,
    pub source_is_live: bool,
}

impl WorklistProcessor for ExactDependencyGraphProcessor {
    fn name(&self) -> &'static str {
        "exact-dependency-graph"
    }

    fn apply(&self, state: &ProblemState) -> ProcessorResult {
        let replay_started = Instant::now();
        let replay_timing = std::env::var_os("FERRUM_EXACT_REPLAY_TIMING").is_some();
        let ProblemState::DependencyPairs(problem) = state else {
            return ProcessorResult::Inapplicable;
        };
        let components = if self.source_is_live {
            if replay_timing {
                eprintln!("exact-graph state-local {:?}", replay_started.elapsed());
            }
            self.components.clone()
        } else if let Some(source_xml) = &self.source_dp_input_xml {
            let live_xml = crate::proving::dependency_pairs::dp_state_input_cpf(problem);
            if source_xml.trim() == live_xml.trim()
                || crate::llm::compact_xml_for_key(source_xml)
                    == crate::llm::compact_xml_for_key(&live_xml)
            {
                // State-local oracle lookup already established that this is
                // the exact serialized obligation carried by the witness.
                // Do not parse and solve a large signature-isomorphism
                // problem merely to rediscover the identity map (the GM04
                // LISTUTILITIES residual contains 1,158 pairs).
                if replay_timing {
                    eprintln!("exact-graph identity-source {:?}", replay_started.elapsed());
                }
                self.components.clone()
            } else {
                let Ok(source) = parse_cpf_input(None, source_xml) else {
                    return ProcessorResult::Failed {
                        reason: "invalid exact graph source state".into(),
                    };
                };
                if replay_timing {
                    eprintln!("exact-graph parsed-source {:?}", replay_started.elapsed());
                }
                let (
                    source_trs,
                    source_pairs,
                    mut source_provenance_present,
                    source_active_rules,
                    source_graph_rules,
                    source_csr_context,
                ) = match source {
                    CpfInputProblem::Dp {
                        trs,
                        pairs,
                        pair_source_rules,
                        active_rules,
                        graph_rules,
                        ..
                    } => {
                        let present = pair_source_rules.is_some();
                        (
                            trs,
                            pairs_with_sources(pairs, pair_source_rules),
                            present,
                            active_rules,
                            graph_rules,
                            None,
                        )
                    }
                    CpfInputProblem::CsrDp {
                        csr,
                        pairs,
                        pair_source_rules,
                        active_rules,
                        graph_rules,
                        construction,
                        graph_estimator,
                        use_qcs_usable_rules,
                        ..
                    } => {
                        let present = pair_source_rules.is_some();
                        let replacement_map = csr.replacement_map().clone();
                        (
                            csr.trs().clone(),
                            pairs_with_sources(pairs, pair_source_rules),
                            present,
                            active_rules,
                            graph_rules,
                            Some((
                                replacement_map,
                                construction,
                                graph_estimator,
                                use_qcs_usable_rules,
                            )),
                        )
                    }
                    _ => {
                        return ProcessorResult::Failed {
                            reason: "exact graph source is not a DP state".into(),
                        };
                    }
                };
                // Ordinary monotone DP processors have two equivalent live
                // serializations for their recursive rule component:
                //
                //   * the residual R as `<trs>`, used by CPF reconstruction;
                //   * the original TRS plus the residual as `usableRules` /
                //     `graphRules`, retained by older oracle states so that
                //     the original innermost Q context remains available.
                //
                // Dependency-graph construction observes the effective graph
                // rules, not the inactive historical base rules.  Compare
                // that executable relation here.  CSR states deliberately do
                // not use this bridge: their complete source TRS and
                // replacement map remain checker obligations below.
                let compare_effective_ordinary_rules = source_csr_context.is_none()
                    && matches!(problem.stats.problem, DpProblemContext::Ordinary);
                let source_rule_view = if compare_effective_ordinary_rules {
                    source_graph_rules
                        .as_deref()
                        .or(source_active_rules.as_deref())
                        .unwrap_or_else(|| source_trs.rules())
                } else {
                    source_trs.rules()
                };
                let live_rule_view = if compare_effective_ordinary_rules {
                    problem
                        .stats
                        .graph_rules
                        .as_deref()
                        .or(problem.stats.active_rules.as_deref())
                        .unwrap_or_else(|| problem.trs.rules())
                } else {
                    problem.trs.rules()
                };
                let variables = |rules: &[crate::core::RewriteRule]| {
                    rules
                        .iter()
                        .flat_map(|rule| {
                            rule.lhs()
                                .variables()
                                .into_iter()
                                .chain(rule.rhs().variables())
                        })
                        .collect()
                };
                let source_rule_trs = crate::core::Trs::new_with_strategy(
                    None,
                    variables(source_rule_view),
                    source_rule_view.to_vec(),
                    source_trs.strategy(),
                );
                let live_rule_trs = crate::core::Trs::new_with_strategy(
                    None,
                    variables(live_rule_view),
                    live_rule_view.to_vec(),
                    problem.trs.strategy(),
                );
                let Some((symbols, source_rule_aliases)) =
                    super::exact_transformation::portable_trs_isomorphism(
                        &source_rule_trs,
                        &live_rule_trs,
                    )
                else {
                    return ProcessorResult::Failed {
                        reason: "exact graph source changes the live TRS".into(),
                    };
                };
                if replay_timing {
                    eprintln!("exact-graph trs-isomorphism {:?}", replay_started.elapsed());
                }
                match (source_csr_context, &problem.stats.problem) {
                    (
                        Some((source_map, construction, graph_estimator, _source_use_qcs)),
                        DpProblemContext::ContextSensitive(live),
                    ) => {
                        let mut source_entries = source_map.entries().clone();
                        let mut live_entries = live.csr.replacement_map().entries().clone();
                        let source_aux = crate::proving::dependency_pairs::fresh_unhiding_symbol(&source_trs);
                        let live_aux = crate::proving::dependency_pairs::fresh_unhiding_symbol(live.csr.trs());
                        let improved = construction == "improved"
                            && live.construction == crate::proving::dependency_pairs::CsrDpConstruction::Improved;
                        if improved {
                            // Compare the maps actually emitted in CSR CPF.
                            // The live root may still carry the TRS-only map,
                            // while a parsed DP input retains the explicit U.
                            source_entries.entry(source_aux.clone()).or_default();
                            live_entries.entry(live_aux.clone()).or_default();
                        }
                        let maps_match = source_entries.iter().all(|(source, positions)| {
                            let target = if improved && source == &source_aux {
                                &live_aux
                            } else {
                                symbols.get(source).unwrap_or(source)
                            };
                            live_entries.get(target) == Some(positions)
                        }) && live_entries.len() == source_entries.len();
                        if !maps_match
                            || construction != live.construction.as_str()
                            || graph_estimator != live.graph_estimator.as_str()
                        {
                            return ProcessorResult::Inapplicable;
                        }
                    }
                    (None, DpProblemContext::Ordinary) => {}
                    _ => return ProcessorResult::Inapplicable,
                }
                // The TRS alone does not determine images of marked DP symbols.
                // In canonical residual inputs those symbols may be represented
                // by unrelated plain names (for example active# -> aa), while
                // the corresponding ordinary symbol has a different image.  A
                // TRS-derived f# -> image(f)# alias then maps a perfectly
                // isomorphic graph source to the wrong live pairs.  Recover the
                // complete signature bijection from R and P together, as exact
                // reduction-pair replay already does.
                let source_pair_rules = source_pairs
                    .iter()
                    .map(DependencyPair::as_rule)
                    .collect::<Vec<_>>();
                let live_pair_rules = problem
                    .pairs
                    .iter()
                    .map(DependencyPair::as_rule)
                    .collect::<Vec<_>>();
                let pair_symbols = super::general_red_pair::portable_rule_pair_isomorphism(
                    source_rule_view,
                    &source_pair_rules,
                    live_rule_view,
                    &live_pair_rules,
                );
                if compare_effective_ordinary_rules
                    && (source_trs.rules() != source_rule_view
                        || problem.trs.rules() != live_rule_view)
                {
                    // Source indices refer to the respective historical base
                    // TRSs.  Once those containers differ, equal numeric
                    // indices carry no cross-serialization meaning; pair
                    // identity is established by the exact alpha-equivalent
                    // rule multiset below instead.
                    source_provenance_present = false;
                }
                if replay_timing {
                    eprintln!(
                        "exact-graph pair-isomorphism {:?}",
                        replay_started.elapsed()
                    );
                }
                let pair_mapping = |pairs: &[DependencyPair]| {
                    // Certified events normally retain the producer's pair order.
                    // Recognize that overwhelmingly common case in O(n).  The
                    // previous unconditional bipartite scan was O(n^2) and made
                    // a 1,158-pair exact witness spend over a minute merely
                    // rediscovering the identity permutation.
                    if pairs.len() <= problem.pairs.len()
                        && pairs
                            .iter()
                            .zip(&problem.pairs)
                            .all(|(source_pair, live_pair)| {
                                (!source_provenance_present
                                    || source_pair.source_rule() == live_pair.source_rule())
                                    && dependency_pair_rules_alpha_equivalent(
                                        source_pair,
                                        live_pair,
                                    )
                            })
                    {
                        return Some((0..pairs.len()).collect());
                    }
                    let trust_provenance =
                        source_provenance_present && pairs.len() <= problem.pairs.len();
                    let mut used = vec![false; problem.pairs.len()];
                    let mut mapping = Vec::with_capacity(pairs.len());
                    for (source_index, source_pair) in pairs.iter().enumerate() {
                        if let Some((index, _)) =
                            problem.pairs.iter().enumerate().find(|(index, live_pair)| {
                                !used[*index]
                                    && (!trust_provenance
                                        || source_pair.source_rule() == live_pair.source_rule())
                                    && dependency_pair_rules_alpha_equivalent(
                                        source_pair,
                                        live_pair,
                                    )
                            })
                        {
                            used[index] = true;
                            mapping.push(index);
                            continue;
                        }
                        // CPF P is a set. A historical state can repeat one
                        // rule only because hidden source provenance differed;
                        // that duplicate denotes the same live graph vertex.
                        let previous = pairs[..source_index].iter().position(|other| {
                            dependency_pair_rules_alpha_equivalent(other, source_pair)
                        })?;
                        mapping.push(mapping[previous]);
                    }
                    Some(mapping)
                };
                // Most retained events preserve the source spelling exactly.
                // Prefer that unambiguous identity before applying the TRS
                // signature isomorphism; symmetric signatures may admit several
                // canonical bijections even though the raw state already agrees.
                let mapping = pair_mapping(&source_pairs).or_else(|| {
                    let symbols = pair_symbols.as_ref().unwrap_or(&symbols);
                    let translated = source_pairs
                        .iter()
                        .map(|pair| {
                            let source = source_rule_aliases
                                .get(&pair.source_rule())
                                .copied()
                                .unwrap_or_else(|| pair.source_rule());
                            DependencyPair::from_rule(
                                translate_rule_symbols(&pair.as_rule(), &symbols),
                                source,
                            )
                        })
                        .collect::<Vec<_>>();
                    pair_mapping(&translated)
                });
                let Some(mapping) = mapping else {
                    if std::env::var_os("FERRUM_WORKLIST_TRACE").is_some() {
                        let unmatched = source_pairs.iter().find(|source_pair| {
                            !problem.pairs.iter().any(|live_pair| {
                                dependency_pair_rules_alpha_equivalent(source_pair, live_pair)
                            })
                        });
                        eprintln!(
                            "exact graph source mismatch source_pairs={} live_pairs={} first_unmatched={unmatched:?}",
                            source_pairs.len(),
                            problem.pairs.len()
                        );
                    }
                    return ProcessorResult::Failed {
                        reason: "exact graph source pairs do not match the live state".into(),
                    };
                };
                if replay_timing {
                    eprintln!("exact-graph pair-mapping {:?}", replay_started.elapsed());
                }
                let mut translated_components = self
                    .components
                    .iter()
                    .map(|(indices, proved)| {
                        let live_indices = indices
                            .iter()
                            .map(|index| mapping.get(*index).copied())
                            .collect::<Option<Vec<_>>>()?;
                        // Preserve the certified component's order.  Although a
                        // graph component is mathematically a set, its retained
                        // child state is the source of the recursively certified
                        // continuation.  Reordering it to the live root order
                        // needlessly changes the exact nested oracle key (and can
                        // also perturb signature canonicalization in symmetric
                        // systems) without changing the graph certificate.
                        Some((live_indices, *proved))
                    })
                    .collect::<Option<Vec<_>>>()
                    .unwrap_or_default();
                if translated_components.is_empty() && !self.components.is_empty() {
                    return ProcessorResult::Failed {
                        reason: "exact graph source component indices are invalid".into(),
                    };
                }
                let mut old_pair = vec![false; problem.pairs.len()];
                for index in &mapping {
                    old_pair[*index] = true;
                }
                if old_pair.iter().any(|old| !old) {
                    let active_rules = problem
                        .stats
                        .graph_rules
                        .as_deref()
                        .or(problem.stats.active_rules.as_deref())
                        .unwrap_or_else(|| problem.trs.rules());
                    if !exact_graph_extra_pairs_are_acyclic(
                        &problem.trs,
                        active_rules,
                        &problem.pairs,
                        &old_pair,
                        problem.innermost_lhss.as_deref(),
                    ) {
                        // Exact graph witnesses are pooled across the certified
                        // residuals of one root.  A witness for a proper subset
                        // whose additional live pairs are cyclic is not invalid;
                        // it is simply not the witness for this state.  Keep
                        // searching for the complete state-bound graph instead
                        // of aborting the processor worklist.
                        return ProcessorResult::Inapplicable;
                    }
                    // The CPF dependency-graph processor still requires a
                    // decomposition of the complete live pair set.  The check
                    // above proves that every additional pair is outside every
                    // retained cycle and that the subgraph induced by additional
                    // pairs is acyclic, so each can be represented by an open
                    // singleton component.  Omitting them made Ferrum construct a
                    // locally closed proof which CeTA rejected as an incomplete
                    // decomposition (ExAppendixB_AEL03_iGM).
                    translated_components.extend(
                        old_pair
                            .iter()
                            .enumerate()
                            .filter_map(|(index, old)| (!old).then_some((vec![index], false))),
                    );
                }
                translated_components
            }
        } else {
            self.components.clone()
        };
        let mut owner = vec![None; problem.pairs.len()];
        for (component_index, (indices, _)) in components.iter().enumerate() {
            if indices.is_empty() {
                return ProcessorResult::Failed {
                    reason: "exact graph contains an empty component".into(),
                };
            }
            for index in indices {
                if *index >= owner.len() || owner[*index].replace(component_index).is_some() {
                    return ProcessorResult::Failed {
                        reason: "exact graph indices are invalid or duplicated".into(),
                    };
                }
            }
        }
        if owner.iter().any(Option::is_none) {
            // A source-bound fragment can omit acyclic components during
            // extraction, but CPF still requires the complete literal pair
            // set. Recompute this local graph boundary instead of emitting
            // an incomplete decomposition or trusting the omission. This
            // also obtains the correct topological order for restored nodes.
            return DependencyGraphProcessor { deadline: None }.apply(state);
        }
        // A retained CSR graph is only an executable witness if it is still
        // a decomposition of the live checker graph.  In particular, older
        // improved-CS-DP states treated the fresh unhiding symbol as frozen
        // during oracle extraction, whereas CPF/CeTA gives an unmentioned
        // fresh symbol the default fully active map.  That could split a real
        // cyclic component and defer the rejection until final certification.
        // Recompute only this CSR boundary; ordinary exact graph witnesses
        // retain their intentionally cheap state-local replay path.
        if matches!(problem.stats.problem, DpProblemContext::ContextSensitive(_)) {
            let mut checker_stats = checker_graph_stats(problem);
            // Validate the witness against the exact current boundary. A
            // larger ancestor's induced over-approximation can retain edges
            // that a fresh check of this transformed state disproves.
            checker_stats.detach_graph_caches();
            let active_rules = problem
                .stats
                .graph_rules
                .as_deref()
                .or(problem.stats.active_rules.as_deref())
                .unwrap_or_else(|| problem.trs.rules());
            let cancellation = CancellationScope::current(None);
            let Some(live_graph) = cached_dp_problem_dependency_graph_with_context_deadline(
                &checker_stats,
                &problem.trs,
                &problem.pairs,
                problem.innermost_lhss.as_deref(),
                Some(active_rules),
                None,
                &cancellation,
            ) else {
                return ProcessorResult::Failed {
                    reason: "could not validate exact CSR dependency graph".into(),
                };
            };
            for live_component in strongly_connected_components(&live_graph) {
                if !component_is_cyclic(&live_component, &live_graph) {
                    continue;
                }
                let Some(component_owner) = live_component
                    .first()
                    .and_then(|index| owner.get(*index))
                    .and_then(|entry| *entry)
                else {
                    if std::env::var_os("FERRUM_WORKLIST_TRACE").is_some() {
                        eprintln!(
                            "exact CSR graph invalid: cyclic component contains omitted pair"
                        );
                    }
                    return ProcessorResult::Inapplicable;
                };
                if !components[component_owner].1
                    || live_component
                        .iter()
                        .any(|index| owner.get(*index).copied().flatten() != Some(component_owner))
                {
                    if std::env::var_os("FERRUM_WORKLIST_TRACE").is_some() {
                        eprintln!(
                            "exact CSR graph invalid: live SCC crosses retained components (size={})",
                            live_component.len()
                        );
                    }
                    return ProcessorResult::Inapplicable;
                }
            }
            // `check_graph_decomp` also interprets the listed components in
            // topological order.  A newly restored edge need not merge two
            // SCCs to invalidate an archived order; a backward cross-edge is
            // enough (this is the LISTUTILITIES unhiding-edge regression).
            for (from, successors) in live_graph.iter().enumerate() {
                let Some(from_owner) = owner.get(from).copied().flatten() else {
                    continue;
                };
                if successors.iter().any(|to| {
                    owner
                        .get(*to)
                        .copied()
                        .flatten()
                        .is_some_and(|to_owner| to_owner < from_owner)
                }) {
                    if std::env::var_os("FERRUM_WORKLIST_TRACE").is_some() {
                        eprintln!("exact CSR graph invalid: restored backward component edge");
                    }
                    return ProcessorResult::Inapplicable;
                }
            }
        }
        // A graph certificate with one open component containing every live
        // pair merely reproduces its input obligation.  Treating it as an
        // applied processor creates a recursive oracle cycle (and cannot add
        // anything to the reconstructed CPF proof).  This is independent of
        // pair order: owner validation above has already established that the
        // component contains each live pair exactly once.
        if components.len() == 1
            && components[0].1
            && components[0].0.len() == problem.pairs.len()
            && owner.iter().all(Option::is_some)
        {
            return ProcessorResult::Inapplicable;
        }
        // Listed acyclic components have no nested proof; omitted source
        // pairs are represented by the graph certificate itself.
        // This atom is an exact CPF graph certificate, not a request to rerun
        // Ferrum's (deliberately conservative) estimator.  Re-estimating here
        // can add false edges and defeat a decomposition that CeTA accepts.
        // Coverage, disjointness, pair identity and every recursive component
        // are reconstructed explicitly; CeTA validates the graph certificate
        // itself before the answer is promoted.
        enum Slot {
            Closed(DpComponentProof),
            Residual(Vec<DependencyPair>),
        }
        let mut residuals = Vec::new();
        let mut slots = Vec::new();
        for (indices, has_proof) in &components {
            let pairs = indices
                .iter()
                .map(|index| problem.pairs[*index].clone())
                .collect::<Vec<_>>();
            if *has_proof {
                let mut child = problem.clone();
                if let Some(context) = child.options.gm04_residual.as_mut() {
                    context.graph_decomposed = true;
                }
                child.pairs = pairs.clone();
                child.stats.weak_pairs = pairs
                    .iter()
                    .filter(|pair| problem.stats.weak_pairs.contains(pair))
                    .cloned()
                    .collect();
                residuals.push(ProblemState::DependencyPairs(child));
                slots.push(Slot::Residual(pairs));
            } else {
                slots.push(Slot::Closed(acyclic_component_proof(pairs)));
            }
        }
        let application =
            ProcessorApplication::new(residuals, move |children: Vec<ProblemCertificate>| {
                let mut children = children.into_iter();
                let mut proofs = Vec::with_capacity(slots.len());
                for slot in &slots {
                    match slot {
                        Slot::Closed(proof) => proofs.push(proof.clone()),
                        Slot::Residual(pairs) => {
                            let ProblemCertificate::DependencyPairTree(tree) = children.next()?
                            else {
                                return None;
                            };
                            proofs.push(component_proof_from_tree(pairs.clone(), tree));
                        }
                    }
                }
                if children.next().is_some() {
                    return None;
                }
                Some(ProblemCertificate::DependencyPairTree(
                    DpProofTree::DepGraph { components: proofs },
                ))
            })
            .with_child_short_circuit(|certificate| match certificate {
                ProblemCertificate::DependencyPairNontermination(proof) => {
                    if std::env::var_os("FERRUM_WORKLIST_TRACE").is_some() {
                        eprintln!("exact graph short-circuited on DP nontermination");
                    }
                    Some(ProblemCertificate::DependencyPairNontermination(
                        proof.clone(),
                    ))
                }
                _ => None,
            });
        if replay_timing {
            eprintln!("exact-graph complete {:?}", replay_started.elapsed());
        }
        ProcessorResult::Applied(application)
    }
}

impl WorklistProcessor for DependencyGraphProcessor {
    fn name(&self) -> &'static str {
        "dependency-graph"
    }

    fn apply(&self, state: &ProblemState) -> ProcessorResult {
        self.apply_with_refinement(state, false)
    }
}

impl DependencyGraphProcessor {
    pub(crate) fn apply_refined(&self, state: &ProblemState) -> ProcessorResult {
        self.apply_with_refinement(state, true)
    }

    fn apply_with_refinement(&self, state: &ProblemState, refined: bool) -> ProcessorResult {
        let ProblemState::DependencyPairs(problem) = state else {
            return ProcessorResult::Inapplicable;
        };
        if refined && (!matches!(problem.stats.problem, DpProblemContext::Ordinary)
            || problem.trs.strategy() != RewriteStrategy::Innermost) {
            return ProcessorResult::Inapplicable;
        }
        if let Some(payload_xml) = guarded_list_terminal_payload(problem) {
            return ProcessorResult::Applied(ProcessorApplication::solved(
                ProblemCertificate::DependencyPairTree(DpProofTree::TransformationExact {
                    processor_tag: "csrGuardedListTerminal".to_string(),
                    payload_xml,
                    proof: Box::new(DpProofTree::Empty),
                }),
            ));
        }
        let cancellation = CancellationScope::current(self.deadline);
        if cancellation.is_cancelled() || strategy_timed_out(self.deadline) {
            return ProcessorResult::TimedOut;
        }
        let graph_stats = checker_graph_stats(problem);
        let active_rules = graph_stats
            .graph_rules
            .as_deref()
            .or(graph_stats.active_rules.as_deref())
            .unwrap_or_else(|| problem.trs.rules());
        let graph = if problem.trs.strategy() == RewriteStrategy::Innermost {
            cached_ceta_q_dependency_pair_graph_with_rules_deadline(
                &graph_stats,
                active_rules,
                &problem.pairs,
                problem.innermost_lhss.as_deref().unwrap_or(&[]),
                self.deadline,
                &cancellation,
            )
        } else {
            cached_dp_problem_dependency_graph_with_context_deadline(
                &graph_stats,
                &problem.trs,
                &problem.pairs,
                problem.innermost_lhss.as_deref(),
                Some(active_rules),
                self.deadline,
                &cancellation,
            )
        };
        let Some(mut graph) = graph else {
            return if cancellation.is_cancelled() || strategy_timed_out(self.deadline) {
                ProcessorResult::TimedOut
            } else {
                ProcessorResult::Failed {
                    reason: "dependency graph construction failed".to_string(),
                }
            };
        };
        if refined && crate::proving::dependency_pairs::refine_ceta_q_dependency_graph(
            active_rules, &problem.pairs, problem.innermost_lhss.as_deref().unwrap_or(&[]),
            &mut graph, self.deadline, &cancellation,
        ).is_none() {
            return ProcessorResult::TimedOut;
        }
        // `cached_ceta_q_dependency_pair_graph_with_rules_deadline` already
        // implements the executable Q-aware CeTA edge criterion.  Do not add
        // a blanket same-root envelope here: after forward instantiation it
        // merges distinct, provably one-way calls into one artificial SCC and
        // prevents the certified residual chain from being exposed (#4.24).
        let components =
            topologically_order_components(strongly_connected_components(&graph), &graph);
        if components.len() == 1 && component_is_cyclic(&components[0], &graph) {
            return ProcessorResult::Inapplicable;
        }
        // A computed graph is a complete, deterministic witness.  Preserve
        // it at the processor boundary so the oracle can replay the exact
        // SCC partition instead of paying for graph construction again.
        // Including the source DP input lets exact replay validate and
        // translate the witness across canonical symbol renamings.
        let selected_atom = DpStrategyProcessor::ExactDependencyGraph {
            components: components
                .iter()
                .map(|component| (component.clone(), component_is_cyclic(component, &graph)))
                .collect(),
            source_dp_input_xml: Some(crate::proving::dependency_pairs::dp_state_input_cpf(
                problem,
            )),
            source_is_live: false,
        }
        .to_strategy_atom();

        enum Slot {
            Closed(DpComponentProof),
            Residual(Vec<DependencyPair>),
        }

        let mut residuals = Vec::new();
        let mut slots = Vec::new();
        for component in components {
            let component_pairs = component
                .iter()
                .map(|index| problem.pairs[*index].clone())
                .collect::<Vec<_>>();
            let cyclic = component_is_cyclic(&component, &graph);
            let has_strong = !problem.stats.strict_rules.is_empty() || component_pairs
                .iter()
                .any(|pair| !problem.stats.weak_pairs.contains(pair));
            if cyclic && has_strong {
                let mut child = problem.clone();
                if let Some(context) = child.options.gm04_residual.as_mut() {
                    context.graph_decomposed = true;
                }
                child.pairs = component_pairs.clone();
                child.stats.weak_pairs = component_pairs
                    .iter()
                    .filter(|pair| problem.stats.weak_pairs.contains(pair))
                    .cloned()
                    .collect();
                residuals.push(ProblemState::DependencyPairs(child));
                slots.push(Slot::Residual(component_pairs));
            } else if cyclic {
                slots.push(Slot::Closed(weak_only_component_proof(component_pairs)));
            } else {
                slots.push(Slot::Closed(acyclic_component_proof(component_pairs)));
            }
        }

        ProcessorResult::Applied(
            ProcessorApplication::new(residuals, move |children: Vec<ProblemCertificate>| {
                let mut children = children.into_iter();
                let mut component_proofs = Vec::with_capacity(slots.len());
                for slot in &slots {
                    match slot {
                        Slot::Closed(proof) => component_proofs.push(proof.clone()),
                        Slot::Residual(pairs) => {
                            let Some(ProblemCertificate::DependencyPairTree(tree)) =
                                children.next()
                            else {
                                return None;
                            };
                            component_proofs.push(component_proof_from_tree(pairs.clone(), tree));
                        }
                    }
                }
                if children.next().is_some() {
                    return None;
                }
                Some(ProblemCertificate::DependencyPairTree(
                    DpProofTree::DepGraph {
                        components: component_proofs,
                    },
                ))
            })
            .with_child_short_circuit(|certificate| match certificate {
                ProblemCertificate::DependencyPairNontermination(proof) => {
                    if std::env::var_os("FERRUM_WORKLIST_TRACE").is_some() {
                        eprintln!("graph short-circuited on DP nontermination");
                    }
                    Some(ProblemCertificate::DependencyPairNontermination(
                        proof.clone(),
                    ))
                }
                _ => None,
            })
            .with_selected_atom(selected_atom),
        )
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::collections::{BTreeMap, BTreeSet};

    use crate::core::{CsrTrs, ReplacementMap, RewriteRule, Symbol, Term, Trs, Variable};
    use crate::proving::DpOptions;

    #[test]
    fn native_improved_graph_matches_emitted_frozen_auxiliary_map() {
        let a = Term::app("left", vec![]);
        let b = Term::app("right", vec![]);
        let trs = Trs::new(None, BTreeSet::new(), vec![RewriteRule::new(b.clone(), a.clone())]);
        let csr = CsrTrs::full(trs);
        let fresh = crate::proving::dependency_pairs::fresh_unhiding_symbol(csr.trs());
        let wrap = |term| Term::app(fresh.as_str(), vec![term]);
        let pairs = vec![
            DependencyPair::from_rule(RewriteRule::new(wrap(a.clone()), wrap(b)), 0),
            DependencyPair::from_rule(RewriteRule::new(wrap(a.clone()), wrap(a)), 0),
        ];
        let make = |csr: &CsrTrs| super::super::DpProblemState::csr_materialized_from_parts(
            csr, pairs.clone(), vec![], None, true, "improved", "context-sensitive", false,
            DpOptions::default()).unwrap();
        let source = make(&csr);
        let materialized = make(&csr.clone().with_frozen_auxiliary_symbol(fresh.clone()));
        assert_eq!(crate::proving::dependency_pairs::dp_state_input_cpf(&source),
                   crate::proving::dependency_pairs::dp_state_input_cpf(&materialized));
        for state in [source, materialized] {
            let ProcessorResult::Applied(application) = (DependencyGraphProcessor { deadline: None })
                .apply(&ProblemState::DependencyPairs(state)) else { panic!("expected graph split") };
            assert_eq!(application.residuals.len(), 1);
            let ProblemState::DependencyPairs(child) = &application.residuals[0] else { panic!() };
            assert_eq!(child.pairs, vec![pairs[1].clone()]);
        }
        assert!(csr.replacement_map().allowed_positions(&fresh).is_none(),
                "graph estimation must not mutate the source relation");
    }

    #[test]
    fn weak_pair_components_retain_strict_rule_obligations() {
        let pair = |name: &str| DependencyPair::from_rule(
            RewriteRule::new(Term::app(name, vec![]), Term::app(name, vec![])), 0);
        let pairs = vec![pair("f#"), pair("g#")];
        let rule = RewriteRule::new(Term::app("a", vec![]), Term::app("a", vec![]));
        let mut state = super::super::DpProblemState::ordinary(
            Trs::new(None, BTreeSet::new(), vec![rule.clone()]), pairs.clone(), DpOptions::default());
        state.stats.weak_pairs = pairs;
        state.stats.strict_rules = vec![rule];
        let ProcessorResult::Applied(application) = (DependencyGraphProcessor { deadline: None }).apply(
            &ProblemState::DependencyPairs(state.clone())) else { panic!("expected two SCCs") };
        assert_eq!(application.residuals.len(), 2);
        for child in application.residuals {
            let ProblemState::DependencyPairs(child) = child else { panic!() };
            assert_eq!(child.stats.strict_rules, state.stats.strict_rules);
        }
    }

    #[test]
    fn exact_source_graph_may_omit_implicitly_acyclic_pairs() {
        let var = || Term::var("X");
        let pair = |left: &str, right: &str, source| {
            DependencyPair::from_rule(
                RewriteRule::new(Term::app(left, vec![var()]), Term::app(right, vec![var()])),
                source,
            )
        };
        let problem = super::super::DpProblemState::ordinary(
            Trs::new(None, Default::default(), Vec::new()),
            vec![pair("f#", "f#", 0), pair("g#", "h#", 1)],
            DpOptions::default(),
        );
        let source = crate::proving::dependency_pairs::dp_state_input_cpf(&problem);
        let state = ProblemState::DependencyPairs(problem);
        let processor = ExactDependencyGraphProcessor {
            components: vec![(vec![0], true)],
            source_dp_input_xml: Some(source),
            source_is_live: false,
        };

        let ProcessorResult::Applied(application) = processor.apply(&state) else {
            panic!("a source graph may omit pairs certified as acyclic")
        };
        let (residuals, reconstruction) = application.into_parts();
        assert_eq!(residuals.len(), 1);
        let ProblemState::DependencyPairs(residual) = &residuals[0] else {
            panic!("expected the listed cyclic DP component")
        };
        assert_eq!(residual.pairs.len(), 1);
        assert_eq!(
            residual.pairs[0].lhs().root_symbol().unwrap().as_str(),
            "f#"
        );
        // This is a reconstruction-shape test, not a termination claim for
        // the open f# loop. The omitted acyclic pair must still be printed.
        let Some(ProblemCertificate::DependencyPairTree(DpProofTree::DepGraph { components })) =
            reconstruction.reconstruct(vec![ProblemCertificate::DependencyPairTree(DpProofTree::Empty)])
            else { panic!("expected reconstructed graph") };
        assert_eq!(components.len(), 2);
    }

    #[test]
    fn exact_source_graph_matches_materialized_and_active_rule_residuals() {
        let x = Term::var("x");
        let active_rule = RewriteRule::new(
            Term::app("f", vec![x.clone()]),
            Term::app("f", vec![x.clone()]),
        );
        let inactive_rule = RewriteRule::new(
            Term::app("g", vec![x.clone()]),
            Term::app("g", vec![x.clone()]),
        );
        let pair = DependencyPair::from_rule(
            RewriteRule::new(Term::app("f#", vec![x.clone()]), Term::app("f#", vec![x])),
            0,
        );
        let source = super::super::DpProblemState::ordinary(
            Trs::new_with_strategy(
                None,
                BTreeSet::from([Variable::new("x")]),
                vec![active_rule.clone()],
                RewriteStrategy::Innermost,
            ),
            vec![pair.clone()],
            DpOptions::default(),
        );
        let source_xml = crate::proving::dependency_pairs::dp_state_input_cpf(&source);

        let mut live = super::super::DpProblemState::ordinary(
            Trs::new_with_strategy(
                None,
                BTreeSet::from([Variable::new("x")]),
                vec![active_rule.clone(), inactive_rule],
                RewriteStrategy::Innermost,
            ),
            vec![pair],
            DpOptions::default(),
        );
        live.stats.active_rules = Some(vec![active_rule.clone()]);
        live.stats.graph_rules = Some(vec![active_rule]);
        let processor = ExactDependencyGraphProcessor {
            components: vec![(vec![0], false)],
            source_dp_input_xml: Some(source_xml),
            source_is_live: false,
        };

        assert!(matches!(
            processor.apply(&ProblemState::DependencyPairs(live)),
            ProcessorResult::Applied(_)
        ));
    }

    #[test]
    fn exact_graph_rejects_a_single_open_full_state_component() {
        let x = Term::var("x");
        let pair = DependencyPair::from_rule(
            RewriteRule::new(Term::app("f#", vec![x.clone()]), Term::app("f#", vec![x])),
            0,
        );
        let problem = super::super::DpProblemState::ordinary(
            Trs::new(None, Default::default(), Vec::new()),
            vec![pair],
            DpOptions::default(),
        );
        let source = crate::proving::dependency_pairs::dp_state_input_cpf(&problem);
        let processor = ExactDependencyGraphProcessor {
            components: vec![(vec![0], true)],
            source_dp_input_xml: Some(source),
            source_is_live: false,
        };

        assert!(matches!(
            processor.apply(&ProblemState::DependencyPairs(problem)),
            ProcessorResult::Inapplicable
        ));
    }

    #[test]
    fn exact_source_graph_rejects_a_different_csr_replacement_map() {
        let x = Term::var("x");
        let trs = Trs::new(
            None,
            BTreeSet::from([Variable::new("x")]),
            vec![RewriteRule::new(
                Term::app("f", vec![x.clone()]),
                Term::app("g", vec![x.clone()]),
            )],
        );
        let csr = |active: BTreeSet<usize>| {
            CsrTrs::new(
                trs.clone(),
                ReplacementMap::new(BTreeMap::from([
                    (Symbol::new("f"), active),
                    (Symbol::new("g"), BTreeSet::new()),
                ])),
            )
            .expect("valid CSR")
        };
        let pair = DependencyPair::from_rule(
            RewriteRule::new(Term::app("F", vec![x.clone()]), Term::app("G", vec![x])),
            0,
        );
        let make_state = |csr: &CsrTrs| {
            super::super::DpProblemState::csr_materialized_from_parts(
                csr,
                vec![pair.clone()],
                Vec::new(),
                None,
                true,
                "improved",
                "context-sensitive",
                true,
                DpOptions::default(),
            )
            .expect("materialized CSR-DP state")
        };
        let source = make_state(&csr(BTreeSet::from([0])));
        let source_xml = crate::proving::dependency_pairs::dp_state_input_cpf(&source);
        let live = ProblemState::DependencyPairs(make_state(&csr(BTreeSet::new())));
        let processor = ExactDependencyGraphProcessor {
            components: vec![(vec![0], false)],
            source_dp_input_xml: Some(source_xml),
            source_is_live: false,
        };

        assert!(matches!(
            processor.apply(&live),
            ProcessorResult::Inapplicable
        ));
    }

    #[test]
    fn exact_source_graph_ignores_qcs_usable_rule_search_capability() {
        let x = Term::var("x");
        let trs = Trs::new(
            None,
            BTreeSet::from([Variable::new("x")]),
            vec![RewriteRule::new(
                Term::app("f", vec![x.clone()]),
                Term::app("f", vec![x.clone()]),
            )],
        );
        let csr = CsrTrs::new(
            trs,
            ReplacementMap::new(BTreeMap::from([(Symbol::new("f"), BTreeSet::from([0]))])),
        )
        .expect("valid CSR");
        let pair = DependencyPair::from_rule(
            RewriteRule::new(Term::app("F", vec![x.clone()]), Term::app("G", vec![x])),
            0,
        );
        let make_state = |use_qcs_usable_rules| {
            super::super::DpProblemState::csr_materialized_from_parts(
                &csr,
                vec![pair.clone()],
                Vec::new(),
                None,
                true,
                "improved",
                "context-sensitive",
                use_qcs_usable_rules,
                DpOptions::default(),
            )
            .expect("materialized CSR-DP state")
        };
        let source_xml = crate::proving::dependency_pairs::dp_state_input_cpf(&make_state(false));
        let live = ProblemState::DependencyPairs(make_state(true));
        let processor = ExactDependencyGraphProcessor {
            components: vec![(vec![0], false)],
            source_dp_input_xml: Some(source_xml),
            source_is_live: false,
        };

        assert!(matches!(
            processor.apply(&live),
            ProcessorResult::Applied(_)
        ));
    }
}
