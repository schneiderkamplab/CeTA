use std::collections::BTreeMap;
use std::time::Instant;

use crate::core::{RewriteRule, RewriteStrategy, Symbol, Term, Trs, Variable};
use crate::proving::dependency_pairs::{
    DependencyPair, DpProblemContext, DpProofTree, DpSemanticLabelingStep, SemanticLabelingModel,
};

use super::super::{
    ProblemCertificate, ProblemState, ProcessorApplication, ProcessorResult, WorklistProcessor,
};

/// CPF root labeling for an ordinary full-rewriting DP problem.
///
/// A variable is assigned a possible root symbol and every function symbol
/// is labeled by the roots of its direct arguments.  Unlike encoding root
/// labeling as an arithmetic finite model, this preserves the correlations
/// between repeated variables and produces the precise CPF transformation.
pub struct RootLabelingProcessor {
    pub deadline: Option<Instant>,
}

impl WorklistProcessor for RootLabelingProcessor {
    fn name(&self) -> &'static str {
        "dependency-pair-root-labeling"
    }

    fn apply(&self, state: &ProblemState) -> ProcessorResult {
        let ProblemState::DependencyPairs(problem) = state else {
            return ProcessorResult::Inapplicable;
        };
        if !matches!(problem.stats.problem, DpProblemContext::Ordinary)
            || problem.trs.strategy() != RewriteStrategy::Full
            || problem
                .innermost_lhss
                .as_ref()
                .is_some_and(|q| !q.is_empty())
            || problem.trs.arities().keys().any(|symbol| {
                symbol.as_str().starts_with("__ferrum_sl__")
                    || symbol.as_str().starts_with("__ferrum_rl__")
            })
        {
            return ProcessorResult::Inapplicable;
        }
        let roots = problem.trs.arities().keys().cloned().collect::<Vec<_>>();
        if roots.is_empty() {
            return ProcessorResult::Inapplicable;
        }
        let active_rules = problem
            .stats
            .active_rules
            .as_deref()
            .unwrap_or_else(|| problem.trs.rules());
        // The CPF root-label interpretation maps f(args) to f. Labeling is
        // sound only when this is a model of R, not merely when the finite
        // labeled image can be constructed. Pairs need not preserve roots.
        if active_rules.iter().chain(&problem.stats.strict_rules)
            .any(|rule| !root_model_holds(rule, &roots)) {
            return ProcessorResult::Inapplicable;
        }
        let mut labeled_pairs = Vec::new();
        let mut labeled_weak_pairs = Vec::new();
        for pair in &problem.pairs {
            let Some(rules) = root_label_rule_instances(&pair.as_rule(), &roots, self.deadline)
            else {
                return ProcessorResult::TimedOut;
            };
            for rule in rules {
                let labeled = DependencyPair::from_rule(rule, pair.source_rule());
                if problem.stats.pair_is_weak(pair) {
                    push_unique(&mut labeled_weak_pairs, labeled.clone());
                }
                push_unique(&mut labeled_pairs, labeled);
            }
        }
        let Some(labeled_rules) = root_label_rules(active_rules, &roots, self.deadline) else {
            return ProcessorResult::TimedOut;
        };
        if labeled_pairs.is_empty() || labeled_pairs == problem.pairs {
            return ProcessorResult::Inapplicable;
        }
        let Some(labeled_strict_rules) =
            root_label_rules(&problem.stats.strict_rules, &roots, self.deadline)
        else {
            return ProcessorResult::TimedOut;
        };
        let labeled_trs = Trs::new_with_strategy(
            problem.trs.name().map(str::to_owned),
            problem.trs.variables().clone(),
            labeled_rules,
            problem.trs.strategy(),
        );
        let step = DpSemanticLabelingStep {
            model: SemanticLabelingModel {
                carrier_size: roots.len(),
                arities: problem.trs.arities(),
                interpretations: BTreeMap::new(),
            },
            root_labeling: true,
            labeled_pairs: labeled_pairs.clone(),
            labeled_rules: labeled_trs.rules().to_vec(),
            labeled_innermost_lhss: Vec::new(),
        };
        let mut residual = problem.clone();
        residual.trs = labeled_trs;
        residual.pairs = labeled_pairs;
        residual.stats.active_rules = Some(residual.trs.rules().to_vec());
        residual.stats.graph_rules = Some(residual.trs.rules().to_vec());
        residual.stats.transformation_rules = None;
        residual.stats.weak_pairs = labeled_weak_pairs;
        residual.stats.strict_rules = labeled_strict_rules;

        ProcessorResult::Applied(ProcessorApplication::new(
            vec![ProblemState::DependencyPairs(residual)],
            move |children| {
                let [ProblemCertificate::DependencyPairTree(proof)] =
                    <[ProblemCertificate; 1]>::try_from(children).ok()?
                else {
                    return None;
                };
                Some(ProblemCertificate::DependencyPairTree(
                    DpProofTree::SemanticLabeling {
                        step: Box::new(step.clone()),
                        proof: Box::new(proof),
                    },
                ))
            },
        ))
    }
}

fn root_model_holds(rule: &RewriteRule, roots: &[Symbol]) -> bool {
    match (rule.lhs(), rule.rhs()) {
        (Term::App { symbol: left, .. }, Term::App { symbol: right, .. }) => left == right,
        (Term::Var(left), Term::Var(right)) if left == right => true,
        // Every valuation has the same value in a singleton carrier.
        _ => roots.len() == 1,
    }
}

pub(crate) fn root_label_rules(
    rules: &[RewriteRule],
    roots: &[Symbol],
    deadline: Option<Instant>,
) -> Option<Vec<RewriteRule>> {
    let mut result = Vec::new();
    for rule in rules {
        for labeled in root_label_rule_instances(rule, roots, deadline)? {
            push_unique(&mut result, labeled);
        }
    }
    Some(result)
}

fn root_label_rule_instances(
    rule: &RewriteRule,
    roots: &[Symbol],
    deadline: Option<Instant>,
) -> Option<Vec<RewriteRule>> {
    let mut variables = rule.lhs().variables();
    variables.extend(rule.rhs().variables());
    let variables = variables.into_iter().collect::<Vec<_>>();
    let mut assignments = vec![BTreeMap::<Variable, Symbol>::new()];
    for variable in variables {
        if deadline.is_some_and(|deadline| Instant::now() >= deadline) {
            return None;
        }
        if assignments.len().saturating_mul(roots.len()) > 16_384 {
            return None;
        }
        let next_variable = variable.clone();
        assignments = assignments
            .into_iter()
            .flat_map(|assignment| {
                let variable = next_variable.clone();
                roots.iter().cloned().map(move |root| {
                    let mut next = assignment.clone();
                    next.insert(variable.clone(), root);
                    next
                })
            })
            .collect();
    }
    let mut result = Vec::new();
    for assignment in assignments {
        let lhs = root_label_term(rule.lhs(), &assignment)?;
        let rhs = root_label_term(rule.rhs(), &assignment)?;
        push_unique(&mut result, RewriteRule::new(lhs, rhs));
    }
    Some(result)
}

fn root_label_term(term: &Term, assignment: &BTreeMap<Variable, Symbol>) -> Option<Term> {
    match term {
        Term::Var(variable) => Some(Term::Var(variable.clone())),
        Term::App { symbol, args } => {
            let labels = args
                .iter()
                .map(|argument| match argument {
                    Term::Var(variable) => assignment.get(variable).cloned(),
                    Term::App { symbol, .. } => Some(symbol.clone()),
                })
                .collect::<Option<Vec<_>>>()?;
            let labeled_args = args
                .iter()
                .map(|argument| root_label_term(argument, assignment))
                .collect::<Option<Vec<_>>>()?;
            Some(Term::app(root_label_symbol(symbol, &labels), labeled_args))
        }
    }
}

fn root_label_symbol(symbol: &Symbol, labels: &[Symbol]) -> String {
    format!(
        "__ferrum_rl__{}__{}",
        hex_encode(symbol.as_str()),
        labels
            .iter()
            .map(|label| hex_encode(label.as_str()))
            .collect::<Vec<_>>()
            .join("_")
    )
}

fn hex_encode(input: &str) -> String {
    input.bytes().map(|byte| format!("{byte:02x}")).collect()
}

fn push_unique<T: Eq>(items: &mut Vec<T>, item: T) {
    if !items.contains(&item) {
        items.push(item);
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn root_labeling_requires_model_of_active_rules() {
        use crate::proving::dependency_pairs::DpOptions;
        use crate::proving::processors::dp::DpProblemState;
        let invalid = RewriteRule::new(Term::app("p", vec![Term::app("zero", vec![])]),
                                      Term::app("true", vec![]));
        let pair = DependencyPair::new(Term::app("F", vec![Term::var("x")]),
                                       Term::app("F", vec![Term::app("p", vec![Term::var("x")])]), 0);
        let trs = Trs::new_with_strategy(None, Default::default(), vec![invalid], RewriteStrategy::Full);
        let mut state = DpProblemState::ordinary(trs, vec![pair], DpOptions::default());
        let processor = RootLabelingProcessor { deadline: None };
        assert!(matches!(processor.apply(&ProblemState::DependencyPairs(state.clone())),
                         ProcessorResult::Inapplicable));
        state.stats.active_rules = Some(vec![]);
        assert!(matches!(processor.apply(&ProblemState::DependencyPairs(state)),
                         ProcessorResult::Applied(_)));
    }

    #[test]
    fn tpa03_root_labeling_has_the_precise_four_rule_image() {
        let rule = RewriteRule::new(
            Term::app(
                "f",
                vec![
                    Term::var("x"),
                    Term::app("f", vec![Term::var("y"), Term::var("x")]),
                ],
            ),
            Term::app(
                "f",
                vec![
                    Term::app("f", vec![Term::var("x"), Term::var("x")]),
                    Term::app("f", vec![Term::app("a", vec![]), Term::var("y")]),
                ],
            ),
        );
        let roots = vec![Symbol::new("a"), Symbol::new("f")];
        let labeled = root_label_rule_instances(&rule, &roots, None).unwrap();

        assert_eq!(labeled.len(), 4);
        assert!(labeled.iter().all(|rule| {
            rule.lhs()
                .root_symbol()
                .is_some_and(|symbol| symbol.as_str().starts_with("__ferrum_rl__"))
        }));
    }
}
