use crate::core::{RelativeTrs, RewriteRule, RewriteStrategy, Trs};
use crate::proving::dependency_pairs::{DpProblemContext, DpProofTree};
use crate::proving::{NonterminationProof, ProofStep, Status};

use super::super::{
    ProblemCertificate, ProblemState, ProcessorApplication, ProcessorResult, WorklistProcessor,
};

/// Apply CPF's certified `switchToTRS` DP processor.
///
/// A DP problem `(P/Pw, Q, R/Rw)` is embedded into the relative rewrite
/// problem `(P union R)/(Pw union Rw)`. Keeping that relative problem as a
/// worklist child lets match bounds and its other processors receive their
/// own oracle guidance.
pub struct SwitchToTrsProcessor;

impl WorklistProcessor for SwitchToTrsProcessor {
    fn name(&self) -> &'static str {
        "switch-to-trs"
    }

    fn apply(&self, state: &ProblemState) -> ProcessorResult {
        let ProblemState::DependencyPairs(problem) = state else {
            return ProcessorResult::Inapplicable;
        };
        // RelativeTrs currently represents unrestricted rewriting with
        // Q = empty. Do not silently erase a restricted or CSR Q context.
        if !matches!(problem.stats.problem, DpProblemContext::Ordinary)
            || problem.trs.strategy() != RewriteStrategy::Full
            || problem
                .innermost_lhss
                .as_ref()
                .is_some_and(|q| !q.is_empty())
        {
            return ProcessorResult::Inapplicable;
        }

        let pair_rule = |pair: &crate::proving::DependencyPair| {
            RewriteRule::new(pair.lhs().clone(), pair.rhs().clone())
        };
        let strict_pairs = problem
            .pairs
            .iter()
            .filter(|pair| !problem.stats.weak_pairs.contains(pair))
            .map(pair_rule);
        let weak_pairs = problem.stats.weak_pairs.iter().map(pair_rule);
        let active_rules = problem
            .stats
            .active_rules
            .as_deref()
            .unwrap_or(problem.trs.rules());
        let strict_rules = problem.stats.strict_rules.clone();
        let weak_rules = active_rules
            .iter()
            .filter(|rule| !problem.stats.strict_rules.contains(rule))
            .cloned();

        let source_trs = problem.trs.clone();
        let source_pairs = problem.pairs.clone();
        let strict = strict_pairs.chain(strict_rules).collect::<Vec<_>>();
        if strict.is_empty() {
            return ProcessorResult::Inapplicable;
        }
        let weak = weak_pairs.chain(weak_rules).collect::<Vec<_>>();
        let mut variables = problem.trs.variables().clone();
        for rule in strict.iter().chain(&weak) {
            variables.extend(rule.lhs().variables());
            variables.extend(rule.rhs().variables());
        }
        let strict_trs = Trs::new_with_strategy(
            problem
                .trs
                .name()
                .map(|name| format!("{name}#switch-to-trs")),
            variables,
            strict,
            RewriteStrategy::Full,
        );
        let generated = RelativeTrs::new(strict_trs, weak);
        let removed_count = problem.pairs.len() + active_rules.len();
        let child = ProblemState::from_relative(generated.clone());

        ProcessorResult::Applied(ProcessorApplication::new(
            vec![child],
            move |children: Vec<ProblemCertificate>| {
                if std::env::var_os("FERRUM_WORKLIST_TRACE").is_some() {
                    eprintln!(
                        "switch-to-trs reconstruct children={} kind={}",
                        children.len(),
                        match children.first() {
                            Some(ProblemCertificate::Trs(_)) => "trs",
                            Some(ProblemCertificate::DependencyPairTree(_)) => "dp-tree",
                            Some(ProblemCertificate::DependencyPairNontermination(_)) => "dp-no",
                            Some(ProblemCertificate::RelativeAnnotatedDependencyPairs(_)) => "adp",
                            None => "none",
                        }
                    );
                }
                let [ProblemCertificate::Trs(proof)] =
                    <[ProblemCertificate; 1]>::try_from(children).ok()?
                else {
                    return None;
                };
                if std::env::var_os("FERRUM_WORKLIST_TRACE").is_some() {
                    eprintln!(
                        "switch-to-trs child status={:?} steps={}",
                        proof.status(),
                        proof.steps().len()
                    );
                }
                if proof.status() == &Status::Nonterminating {
                    let [
                        ProofStep::Nontermination {
                            proof: NonterminationProof::Loop(loop_proof),
                        },
                    ] = proof.steps()
                    else {
                        if std::env::var_os("FERRUM_WORKLIST_TRACE").is_some() {
                            eprintln!(
                                "switch-to-trs rejected non-loop nontermination proof: {:?}",
                                proof.steps()
                            );
                        }
                        return None;
                    };
                    // A relative loop witnesses DP nontermination exactly when
                    // it is also a valid mixed P/R loop of the source problem.
                    // Validate that stronger condition before changing proof
                    // vocabulary; this excludes loops sustained only by a
                    // strict R rule.
                    if !crate::proving::nontermination::check_mixed_dp_loop_proof(
                        &source_trs,
                        &source_pairs,
                        loop_proof,
                    ) {
                        if std::env::var_os("FERRUM_WORKLIST_TRACE").is_some() {
                            eprintln!(
                                "switch-to-trs rejected a relative loop that is not a source DP loop"
                            );
                        }
                        return None;
                    }
                    if std::env::var_os("FERRUM_WORKLIST_TRACE").is_some() {
                        eprintln!("switch-to-trs validated and lifted relative DP loop");
                    }
                    return Some(ProblemCertificate::DependencyPairNontermination(
                        crate::proving::DpNonterminationProof::Loop(loop_proof.clone()),
                    ));
                }
                if proof.status() != &Status::Terminating {
                    return None;
                }
                Some(ProblemCertificate::DependencyPairTree(
                    DpProofTree::SwitchToTrs {
                        generated: generated.clone(),
                        removed_count,
                        proof: Box::new(proof),
                    },
                ))
            },
        ))
    }
}

#[cfg(test)]
mod tests {
    use std::collections::BTreeSet;

    use crate::core::{Term, Variable};
    use crate::proving::dependency_pairs::{DependencyPair, DpOptions};
    use crate::proving::processors::dp::DpProblemState;

    use super::*;

    #[test]
    fn preserves_strict_and_weak_dp_and_rule_parts() {
        let x = Term::var("x");
        let strict_rule = RewriteRule::new(
            Term::app("f", vec![x.clone()]),
            Term::app("g", vec![x.clone()]),
        );
        let weak_rule = RewriteRule::new(
            Term::app("g", vec![x.clone()]),
            Term::app("h", vec![x.clone()]),
        );
        let strict_pair = DependencyPair::new_for_test(
            Term::app("f#", vec![x.clone()]),
            Term::app("g#", vec![x.clone()]),
        );
        let weak_pair = DependencyPair::new_for_test(
            Term::app("g#", vec![x.clone()]),
            Term::app("h#", vec![x]),
        );
        let trs = Trs::new(
            None,
            BTreeSet::from([Variable::new("x")]),
            vec![strict_rule.clone(), weak_rule.clone()],
        );
        let state = DpProblemState::from_parts(
            trs,
            vec![strict_pair.clone(), weak_pair.clone()],
            vec![weak_pair.clone()],
            None,
            true,
            DpOptions::default(),
        )
        .with_strict_rules(vec![strict_rule.clone()]);

        let ProcessorResult::Applied(application) =
            SwitchToTrsProcessor.apply(&ProblemState::DependencyPairs(state))
        else {
            panic!("switch-to-trs must apply to an ordinary full DP state");
        };
        let [ProblemState::RelativeSrs(relative)] = application.residuals.as_slice() else {
            panic!("switch-to-trs must expose exactly one relative TRS child");
        };

        assert_eq!(
            relative.strict().rules(),
            &[strict_pair.as_rule(), strict_rule]
        );
        assert_eq!(relative.weak_rules(), &[weak_pair.as_rule(), weak_rule]);
    }

    #[test]
    fn rejects_nonempty_q_context() {
        let x = Term::var("x");
        let trs = Trs::new(None, BTreeSet::from([Variable::new("x")]), Vec::new());
        let pair = DependencyPair::new_for_test(
            Term::app("f#", vec![x.clone()]),
            Term::app("f#", vec![x]),
        );
        let mut state = DpProblemState::ordinary(trs, vec![pair], DpOptions::default());
        state.innermost_lhss = Some(vec![Term::app("q", Vec::new())]);

        assert!(matches!(
            SwitchToTrsProcessor.apply(&ProblemState::DependencyPairs(state)),
            ProcessorResult::Inapplicable
        ));
    }

    #[test]
    fn relative_loop_without_strict_rules_becomes_a_dp_loop() {
        let x = Term::var("x");
        let pair = DependencyPair::new_for_test(
            Term::app("f#", vec![x.clone()]),
            Term::app("f#", vec![x.clone()]),
        );
        let trs = Trs::new(None, BTreeSet::from([Variable::new("x")]), Vec::new());
        let state = DpProblemState::ordinary(trs, vec![pair.clone()], DpOptions::default());
        let ProcessorResult::Applied(application) =
            SwitchToTrsProcessor.apply(&ProblemState::DependencyPairs(state))
        else {
            panic!("switch-to-trs must apply")
        };
        let start = Term::app("f#", vec![Term::app("a", Vec::new())]);
        let loop_proof = crate::proving::LoopProof {
            start: start.clone(),
            steps: vec![crate::proving::LoopRewriteStep {
                position: Vec::new(),
                rule: pair.as_rule(),
                result: start,
            }],
            substitution: Default::default(),
            context_position: Vec::new(),
        };
        let certificate = application
            .reconstruct(vec![ProblemCertificate::Trs(
                crate::proving::Proof::nonterminating(NonterminationProof::Loop(
                    loop_proof.clone(),
                )),
            )])
            .expect("a relative loop over DP strict rules must reconstruct");
        assert_eq!(
            certificate,
            ProblemCertificate::DependencyPairNontermination(
                crate::proving::DpNonterminationProof::Loop(loop_proof)
            )
        );
    }
}
