use std::fmt;

use crate::core::{CsrTrs, RewriteRule, RewriteStrategy, Term, Trs};
use crate::proving::dependency_pairs::{
    CsrDpConstruction, CsrDpProblemContext, CsrGraphEstimator, DependencyPair, DpOptions,
    DpProblemContext, DpProofStats,
};

use super::initial_innermost_lhss;

/// Complete executable state of one dependency-pair obligation.
///
/// Every DP processor consumes this value and returns zero or more successor
/// values. Search bookkeeping therefore lives in the state, never in a
/// recursive proof-producing call.
#[derive(Clone)]
pub struct DpProblemState {
    pub(crate) trs: Trs,
    pub(crate) pairs: Vec<DependencyPair>,
    pub(crate) options: DpOptions,
    pub(crate) stats: DpProofStats,
    pub(crate) innermost_lhss: Option<Vec<Term>>,
    /// Deadline inherited from the top-level transformation that exposed
    /// this residual subtree. Runtime-only: never serialized or hashed.
    pub(crate) subtree_deadline: Option<std::time::Instant>,
}

impl DpProblemState {
    pub fn ordinary(trs: Trs, pairs: Vec<DependencyPair>, options: DpOptions) -> Self {
        let stats = DpProofStats::initial_ordinary(&trs);
        Self {
            innermost_lhss: initial_innermost_lhss(&trs),
            subtree_deadline: None,
            trs,
            pairs,
            options,
            stats,
        }
    }

    pub fn nonminimal(trs: Trs, pairs: Vec<DependencyPair>, options: DpOptions) -> Self {
        let mut state = Self::ordinary(trs, pairs, options);
        state.stats.minimal = false;
        state
    }

    pub(crate) fn from_parts(
        trs: Trs,
        pairs: Vec<DependencyPair>,
        weak_pairs: Vec<DependencyPair>,
        active_rules: Option<Vec<RewriteRule>>,
        minimal: bool,
        options: DpOptions,
    ) -> Self {
        let active_rules = active_rules.filter(|rules| rules.as_slice() != trs.rules());
        let mut state = Self::ordinary(trs, pairs, options);
        state.stats.weak_pairs = weak_pairs;
        state.stats.active_rules = active_rules;
        state.stats.minimal = minimal;
        state.innermost_lhss = initial_innermost_lhss(&state.trs);
        state
    }

    /// Construct an already materialized ordinary DP state. Unlike a fresh
    /// root, this state must not inject
    /// an implicit graph step before the selected atom.
    pub(crate) fn materialized_from_parts(
        trs: Trs,
        pairs: Vec<DependencyPair>,
        weak_pairs: Vec<DependencyPair>,
        active_rules: Option<Vec<RewriteRule>>,
        minimal: bool,
        options: DpOptions,
    ) -> Self {
        let mut state = Self::from_parts(trs, pairs, weak_pairs, active_rules, minimal, options);
        state.stats.normal_form_substitutions = true;
        state
    }

    /// Construct the exact already materialized CSR-DP state described by a
    /// CPF campaign input represented as a first-class problem state;
    /// the selected processor returns its residual `ProblemState`s directly.
    #[allow(clippy::too_many_arguments)]
    pub(crate) fn csr_materialized_from_parts(
        csr: &CsrTrs,
        pairs: Vec<DependencyPair>,
        weak_pairs: Vec<DependencyPair>,
        active_rules: Option<Vec<RewriteRule>>,
        minimal: bool,
        construction: &str,
        graph_estimator: &str,
        use_qcs_usable_rules: bool,
        options: DpOptions,
    ) -> Option<Self> {
        let construction = match construction {
            "innermost" => CsrDpConstruction::Innermost,
            "innermost-rta08" => CsrDpConstruction::InnermostRta08,
            "muterm-unhiding" => CsrDpConstruction::MutermUnhiding,
            "muterm-expanded" => CsrDpConstruction::MutermExpanded,
            "rta08" => CsrDpConstruction::Rta08,
            "safe" => CsrDpConstruction::Safe,
            "improved" => CsrDpConstruction::Improved,
            "conservative" => CsrDpConstruction::Conservative,
            _ => CsrDpConstruction::Native,
        };
        let context = CsrDpProblemContext {
            csr: csr.clone(),
            // Construction and minimality are independent serialized facts.
            // In particular, the verified direct innermost-CSR/unhiding
            // transformation produces a nonminimal DPP.  Reclassifying it as
            // conservative here loses its theorem context after every oracle
            // child round-trip and changes which processors are applicable.
            construction,
            graph_estimator: if graph_estimator == "ordinary" {
                CsrGraphEstimator::Ordinary
            } else {
                CsrGraphEstimator::ContextSensitive
            },
            use_qcs_usable_rules,
            innermost_q_lhss: None,
        };
        // This constructor materializes the serialized state verbatim. It
        // must not run QCS usable-rule reduction merely because that
        // processor is available for the state.
        let mut stats = DpProofStats::default();
        stats.minimal = minimal;
        stats.weak_pairs = weak_pairs;
        stats.problem = DpProblemContext::ContextSensitive(context);
        stats.graph_rules = active_rules.clone();
        stats.active_rules = active_rules.filter(|rules| rules.as_slice() != csr.trs().rules());
        // A full CSR input does not assert normal-form substitutions. An
        // unconditional true here invented an empty-Q/nfs obligation when
        // a materialized state crossed into an ordinary DP continuation.
        // Match the live constructor instead of strengthening the input.
        stats.normal_form_substitutions =
            csr.trs().strategy() == crate::core::RewriteStrategy::Innermost;
        Some(Self {
            trs: csr.trs().clone(),
            pairs,
            options,
            stats,
            // A CPF CSR-DP input without an explicit `innermostLhss` field
            // denotes Q = empty.  Do not infer Q from the CSR rules here:
            // that changes a materialized residual and makes applying an
            // atom to the serialized child differ from applying it to the
            // in-memory child.  Innermost/QCS transformations that need a
            // nonempty Q serialize it explicitly and `restore_runtime_context`
            // installs it below.
            innermost_lhss: None,
            subtree_deadline: None,
        })
    }

    pub fn trs(&self) -> &Trs {
        &self.trs
    }

    pub fn pairs(&self) -> &[DependencyPair] {
        &self.pairs
    }

    pub(crate) fn innermost_lhss(&self) -> Option<&[Term]> {
        self.innermost_lhss.as_deref()
    }

    pub fn active_rule_count(&self) -> usize {
        self.stats.active_rules.as_ref().map_or(0, Vec::len)
    }

    pub(crate) fn restore_runtime_context(
        mut self,
        innermost_lhss: Option<Vec<Term>>,
        clear_innermost_lhss: bool,
        graph_rules: Option<Vec<RewriteRule>>,
        transformation_rules: Option<Vec<RewriteRule>>,
        ordinary_reduction_started: bool,
        ordinary_bridge_loses_minimality: bool,
    ) -> Self {
        if clear_innermost_lhss {
            self.innermost_lhss = None;
        } else if innermost_lhss.is_some() {
            self.innermost_lhss = innermost_lhss;
        }
        if graph_rules.is_some() {
            self.stats.graph_rules = graph_rules;
        }
        if transformation_rules.is_some() {
            self.stats.transformation_rules = transformation_rules;
        }
        self.stats.ordinary_reduction_started = ordinary_reduction_started;
        self.stats.ordinary_bridge_loses_minimality = ordinary_bridge_loses_minimality;
        self
    }

    pub(crate) fn with_normal_form_substitutions(mut self, enabled: bool) -> Self {
        self.stats.normal_form_substitutions = enabled;
        self
    }

    /// Restore whether the serialized active-rule component is the certified
    /// residual of an earlier rule processor rather than a search hint.
    pub(crate) fn with_active_rules_are_residual(mut self, enabled: bool) -> Self {
        self.stats.active_rules_are_residual = enabled;
        self
    }

    pub(crate) fn with_strict_rules(mut self, strict_rules: Vec<RewriteRule>) -> Self {
        self.stats.strict_rules = strict_rules;
        self
    }

    /// Restore the ordinary-DP continuation produced by CSR semantic
    /// labeling while retaining the labeled CSR context needed by the
    /// certified finite-semantic continuation checker.
    pub(crate) fn restore_semantic_csr_continuation(mut self, enabled: bool) -> Self {
        if enabled
            && let DpProblemContext::ContextSensitive(mut context) = self.stats.problem.clone()
        {
            context.innermost_q_lhss = self.innermost_lhss.clone();
            self.stats.semantic_csr_context = Some(context);
            self.stats.problem = DpProblemContext::Ordinary;
            // `check_csr_dp_ordinary_min` constructs the semantic-labeling
            // input with both DP flags false and delegates its child to the
            // ordinary nonminimal checker.  Restore that exact obligation,
            // even for legacy child fragments that serialized the parent's
            // `minimal=true` bit.
            self.stats.minimal = false;
        }
        self
    }
}

impl fmt::Debug for DpProblemState {
    fn fmt(&self, formatter: &mut fmt::Formatter<'_>) -> fmt::Result {
        formatter
            .debug_struct("DpProblemState")
            .field("trs", &self.trs)
            .field("pairs", &self.pairs)
            .field("weak_pairs", &self.stats.weak_pairs)
            .field("active_rules", &self.stats.active_rules)
            .field("minimal", &self.stats.minimal)
            .field(
                "innermost",
                &(self.trs.strategy() == RewriteStrategy::Innermost),
            )
            .field("innermost_lhss", &self.innermost_lhss)
            .finish_non_exhaustive()
    }
}

#[cfg(test)]
mod tests {
    use std::collections::{BTreeMap, BTreeSet};

    use crate::core::{CsrTrs, ReplacementMap, RewriteRule, Symbol, Term, Trs, Variable};
    use crate::proving::dependency_pairs::{
        CsrDpProblemContext, CsrGraphEstimator, DependencyPair, DpProblemContext,
    };

    use super::*;

    #[test]
    fn full_csr_materialization_does_not_invent_normal_form_substitutions() {
        let trs = Trs::new(None, BTreeSet::from([Variable::new("x")]), vec![
            RewriteRule::new(Term::app("f", vec![Term::var("x")]), Term::var("x")),
        ]);
        let csr = CsrTrs::new(trs, ReplacementMap::new(BTreeMap::from([
            (Symbol::new("f"), BTreeSet::from([0])),
        ]))).unwrap();
        let mut state = DpProblemState::csr_materialized_from_parts(
            &csr, vec![DependencyPair::new_for_test(Term::app("f#", vec![Term::var("x")]), Term::var("x"))],
            vec![], None, true, "improved", "context-sensitive", true, DpOptions::default(),
        ).unwrap();
        assert!(!state.stats.normal_form_substitutions);
        assert!(state.innermost_lhss.is_none());
        state.stats.problem = DpProblemContext::Ordinary;
        let (xml, error) = crate::proving::standardized_dp_problem_state_input_cpf(&state);
        assert!(error.is_none());
        assert!(!xml.contains("innermostLhss"));
        let q = vec![Term::app("f", vec![Term::var("x")])];
        state = state.restore_runtime_context(Some(q.clone()), false, None, None, false, false);
        assert_eq!(state.innermost_lhss, Some(q));
    }

    #[test]
    fn semantic_csr_continuation_restores_ordinary_nonminimal_obligation() {
        let trs = Trs::new(
            None,
            BTreeSet::from([Variable::new("x")]),
            vec![RewriteRule::new(
                Term::app("f", vec![Term::var("x")]),
                Term::var("x"),
            )],
        );
        let csr = CsrTrs::new(
            trs.clone(),
            ReplacementMap::new(BTreeMap::from([(Symbol::new("f"), BTreeSet::from([0]))])),
        )
        .unwrap();
        let pair = DependencyPair::new_for_test(
            Term::app("f#", vec![Term::var("x")]),
            Term::app("f#", vec![Term::var("x")]),
        );
        let mut state = DpProblemState::ordinary(trs, vec![pair], DpOptions::default());
        state.stats.minimal = true;
        state.stats.problem = DpProblemContext::ContextSensitive(CsrDpProblemContext {
            csr,
            construction: CsrDpConstruction::Improved,
            graph_estimator: CsrGraphEstimator::ContextSensitive,
            use_qcs_usable_rules: true,
            innermost_q_lhss: None,
        });

        let restored = state.restore_semantic_csr_continuation(true);
        assert!(matches!(restored.stats.problem, DpProblemContext::Ordinary));
        assert!(restored.stats.semantic_csr_context.is_some());
        assert!(!restored.stats.minimal);
    }
}
