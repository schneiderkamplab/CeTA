use std::time::Instant;

use crate::proving::dependency_pairs::{
    DependencyPair, DpNarrowingStep, DpProofTree, narrowing_processor_side_conditions_hold, strategy_timed_out,
    synthesize_narrowing_steps_filtered,
};
use crate::proving::runtime::CancellationScope;

use super::super::{
    ProblemCertificate, ProblemState, ProcessorApplication, ProcessorResult, WorklistProcessor,
};

pub struct NarrowingProcessor {
    pub max_per_pair: Option<usize>,
    pub candidate_index: usize,
    /// Generic exploration is depth-bounded. Explicit candidates and strict
    /// state-local guidance are bounded by the worklist deadline instead:
    /// materializing a residual must not reset its processor applicability.
    pub require_depth_bound: bool,
    pub deadline: Option<Instant>,
}

fn candidates(
    problem: &super::DpProblemState,
    max_per_pair: Option<usize>,
    deadline: Option<Instant>,
) -> Option<Vec<(DpNarrowingStep, Vec<DependencyPair>)>> {
    if max_per_pair == Some(0) || !problem.stats.weak_pairs.is_empty()
        || !narrowing_processor_side_conditions_hold(&problem.trs, &problem.pairs)
    { return Some(Vec::new()); }
    let mut options = problem.options.clone();
    if let Some(limit) = max_per_pair { options.max_narrowings_per_step = limit; }
    let active_trs = crate::core::Trs::new_with_strategy(
        problem.trs.name().map(str::to_owned), problem.trs.variables().clone(),
        problem.stats.active_rules.clone().unwrap_or_else(|| problem.trs.rules().to_vec()),
        problem.trs.strategy(),
    );
    // Q remains the original implicit context, independently of active R.
    let default_q = (problem.trs.strategy() == crate::core::RewriteStrategy::Innermost
        && problem.innermost_lhss.is_none()).then(||
            problem.trs.rules().iter().map(|rule| rule.lhs().clone()).collect::<Vec<_>>());
    synthesize_narrowing_steps_filtered(None, &active_trs, &problem.pairs, &options,
        problem.innermost_lhss.as_deref().or(default_q.as_deref()), deadline,
        &CancellationScope::current(deadline), |_| true)
        .map(|steps| steps.into_iter().map(|(_, step, residual)| (step, residual)).collect())
}

pub(crate) fn narrowing_candidate_count(
    state: &ProblemState, max_per_pair: Option<usize>, deadline: Option<Instant>,
) -> Option<usize> {
    let ProblemState::DependencyPairs(problem) = state else { return Some(0) };
    candidates(problem, max_per_pair, deadline).map(|steps| steps.len())
}

impl WorklistProcessor for NarrowingProcessor {
    fn name(&self) -> &'static str {
        "dependency-pair-narrowing"
    }

    fn apply(&self, state: &ProblemState) -> ProcessorResult {
        let ProblemState::DependencyPairs(problem) = state else {
            return ProcessorResult::Inapplicable;
        };
        if !problem.stats.weak_pairs.is_empty()
            || !narrowing_processor_side_conditions_hold(&problem.trs, &problem.pairs)
            || (self.require_depth_bound
                && problem.stats.generic_narrowing_transforms
                    >= problem.options.max_narrowing_transforms)
        {
            return ProcessorResult::Inapplicable;
        }
        let cancellation = CancellationScope::current(self.deadline);
        if cancellation.is_cancelled() || strategy_timed_out(self.deadline) {
            return ProcessorResult::TimedOut;
        }
        if self.max_per_pair == Some(0) {
            return ProcessorResult::Inapplicable;
        }
        let Some(candidates) = candidates(problem, self.max_per_pair, self.deadline) else {
            return ProcessorResult::TimedOut;
        };
        let Some((step, residual_pairs)) = candidates.into_iter().nth(self.candidate_index)
        else {
            return ProcessorResult::Inapplicable;
        };
        if std::env::var_os("FERRUM_WORKLIST_TRACE").is_some() {
            eprintln!(
                "narrowing candidate={} max_narrowings_per_step={} source_rule={} pair={:?} position={:?} residual_pairs={}",
                self.candidate_index,
                problem.options.max_narrowings_per_step,
                step.pair.source_rule(),
                step.pair,
                step.position,
                residual_pairs.len(),
            );
        }
        let mut residual = problem.clone();
        residual.pairs = residual_pairs;
        if self.require_depth_bound {
            residual.stats.generic_narrowing_transforms += 1;
        }

        ProcessorResult::Applied(
            ProcessorApplication::new(vec![ProblemState::DependencyPairs(residual)], {
                let step = step.clone();
                move |children| {
                    let [ProblemCertificate::DependencyPairTree(proof)] =
                        <[ProblemCertificate; 1]>::try_from(children).ok()?
                    else {
                        return None;
                    };
                    Some(ProblemCertificate::DependencyPairTree(
                        DpProofTree::Narrowing {
                            step: step.clone(),
                            proof: Box::new(proof),
                        },
                    ))
                }
            })
            .with_child_short_circuit(move |certificate| match certificate {
                ProblemCertificate::DependencyPairNontermination(proof) => {
                    Some(ProblemCertificate::DependencyPairNontermination(
                        crate::proving::DpNonterminationProof::Narrowing {
                            step: step.clone(),
                            proof: Box::new(proof.clone()),
                        },
                    ))
                }
                _ => None,
            }),
        )
    }
}

#[cfg(test)]
mod tests {
    use std::collections::BTreeSet;

    use crate::core::{RewriteRule, Term, Trs, Variable};
    use crate::proving::dependency_pairs::{DependencyPair, DpOptions};
    use crate::proving::processors::dp::DpProblemState;

    use super::*;

    #[test]
    fn generic_narrowing_stops_at_the_configured_transform_depth() {
        let trs = Trs::new(
            None,
            BTreeSet::from([Variable::new("x")]),
            vec![RewriteRule::new(
                Term::app("g", vec![Term::app("s", vec![Term::var("x")])]),
                Term::var("x"),
            )],
        );
        let pair = DependencyPair::new_for_test(
            Term::app("f#", vec![Term::app("g", vec![Term::var("x")])]),
            Term::app("f#", vec![Term::var("x")]),
        );
        let mut state = DpProblemState::ordinary(trs, vec![pair], DpOptions::default());
        state.stats.generic_narrowing_transforms = state.options.max_narrowing_transforms;

        assert!(matches!(
            NarrowingProcessor {
                max_per_pair: Some(1),
                candidate_index: 0,
                require_depth_bound: true,
                deadline: None,
            }
            .apply(&ProblemState::DependencyPairs(state)),
            ProcessorResult::Inapplicable
        ));
    }

    #[test]
    fn explicitly_selected_narrowing_ignores_the_search_depth_budget() {
        let rules = (0..3)
            .map(|index| {
                RewriteRule::new(
                    Term::app("g", vec![Term::app(format!("c{index}"), Vec::new())]),
                    Term::app(format!("c{index}"), Vec::new()),
                )
            })
            .collect();
        let trs = Trs::new(None, BTreeSet::from([Variable::new("x")]), rules);
        let pair = DependencyPair::new_for_test(
            Term::app("f#", vec![Term::app("s", vec![Term::var("x")])]),
            Term::app("f#", vec![Term::app("g", vec![Term::var("x")])]),
        );
        let mut state = DpProblemState::ordinary(trs, vec![pair], DpOptions::default());
        state.stats.generic_narrowing_transforms = state.options.max_narrowing_transforms;

        assert!(matches!(
            NarrowingProcessor {
                max_per_pair: Some(32),
                candidate_index: 0,
                require_depth_bound: false,
                deadline: None,
            }
            .apply(&ProblemState::DependencyPairs(state)),
            ProcessorResult::Applied(_)
        ));
    }

    #[test]
    fn strategy_limit_controls_generated_narrowing_alternatives() {
        let rules = (0..9)
            .map(|index| {
                RewriteRule::new(
                    Term::app("g", vec![Term::app(format!("c{index}"), Vec::new())]),
                    Term::app(format!("c{index}"), Vec::new()),
                )
            })
            .collect();
        let trs = Trs::new(None, BTreeSet::from([Variable::new("x")]), rules);
        let pair = DependencyPair::new_for_test(
            Term::app("f#", vec![Term::app("s", vec![Term::var("x")])]),
            Term::app("f#", vec![Term::app("g", vec![Term::var("x")])]),
        );
        let state = ProblemState::DependencyPairs(DpProblemState::ordinary(
            trs,
            vec![pair],
            DpOptions::default(),
        ));

        assert!(matches!(
            NarrowingProcessor {
                max_per_pair: Some(32),
                candidate_index: 0,
                require_depth_bound: true,
                deadline: None,
            }
            .apply(&state),
            ProcessorResult::Applied(_)
        ));
    }
}
