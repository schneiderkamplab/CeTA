use std::collections::BTreeMap;

use crate::core::{CsrTrs, RewriteRule, RewriteStrategy, Symbol, Term, Trs, Variable};
use crate::proving::dependency_pairs::{
    CsrDpConstruction, DpProblemContext, DpProofTree, ceta_innermost_usable_rules_for_pairs,
    improved_qcs_certificate_usable_rules, innermost_csr_usable_rules,
    muterm_innermost_unhiding_rules, qcs_certificate_usable_rules,
    usable_rules as ordinary_usable_rules,
};

use super::super::{
    ProblemCertificate, ProblemState, ProcessorApplication, ProcessorResult, WorklistProcessor,
};
use super::initial_innermost_lhss;

pub struct ExactUsableRulesProcessor {
    pub payload_xml: String,
    pub source_pairs_xml: Option<String>,
    pub source_rules_xml: Option<String>,
}

fn numeric_symbol_alias(left: &Symbol, right: &Symbol) -> bool {
    fn numeric(name: &str) -> &str {
        name.strip_prefix('|')
            .and_then(|name| name.strip_suffix('|'))
            .filter(|name| !name.is_empty() && name.bytes().all(|byte| byte.is_ascii_digit()))
            .unwrap_or(name)
    }
    numeric(left.as_str()) == numeric(right.as_str())
}

fn alpha_numeric_terms_with_maps(
    left: &Term,
    right: &Term,
    forward: &mut BTreeMap<Variable, Variable>,
    reverse: &mut BTreeMap<Variable, Variable>,
) -> bool {
    match (left, right) {
        (Term::Var(left), Term::Var(right)) => {
            if forward.get(left).is_some_and(|mapped| mapped != right)
                || reverse.get(right).is_some_and(|mapped| mapped != left)
            {
                return false;
            }
            forward.insert(left.clone(), right.clone());
            reverse.insert(right.clone(), left.clone());
            true
        }
        (
            Term::App {
                symbol: left_symbol,
                args: left_args,
            },
            Term::App {
                symbol: right_symbol,
                args: right_args,
            },
        ) => {
            numeric_symbol_alias(left_symbol, right_symbol)
                && left_args.len() == right_args.len()
                && left_args.iter().zip(right_args).all(|(left, right)| {
                    alpha_numeric_terms_with_maps(left, right, forward, reverse)
                })
        }
        _ => false,
    }
}

fn alpha_numeric_term_equivalent(left: &Term, right: &Term) -> bool {
    alpha_numeric_terms_with_maps(left, right, &mut BTreeMap::new(), &mut BTreeMap::new())
}

fn alpha_numeric_rule_equivalent(left: &RewriteRule, right: &RewriteRule) -> bool {
    let mut forward = BTreeMap::new();
    let mut reverse = BTreeMap::new();
    alpha_numeric_terms_with_maps(left.lhs(), right.lhs(), &mut forward, &mut reverse)
        && alpha_numeric_terms_with_maps(left.rhs(), right.rhs(), &mut forward, &mut reverse)
}

fn rebind_usable_rules(
    usable: &[RewriteRule],
    current: &[RewriteRule],
) -> Option<Vec<RewriteRule>> {
    let mut used = vec![false; current.len()];
    usable
        .iter()
        .map(|source| {
            current.iter().enumerate().find_map(|(index, live)| {
                (!used[index] && alpha_numeric_rule_equivalent(source, live)).then(|| {
                    used[index] = true;
                    live.clone()
                })
            })
        })
        .collect()
}

/// An archived state's spelling need not be the payload's spelling. Match
/// the witness's own rules injectively to a subset of the live rules. This
/// proposes a subset only: `apply` still checks the actual usable closure.
fn relocate_usable_rule_subset(usable: &[RewriteRule], current: &[RewriteRule]) -> Option<Vec<RewriteRule>> {
    fn bind<K: Ord + Clone>(map: &mut BTreeMap<K, K>, a: &K, b: &K) -> bool {
        if let Some(old) = map.get(a) { return old == b; }
        if map.values().any(|old| old == b) { return false; }
        map.insert(a.clone(), b.clone());
        true
    }
    fn terms(a: &Term, b: &Term, symbols: &mut BTreeMap<Symbol, Symbol>,
        variables: &mut BTreeMap<Variable, Variable>) -> bool {
        match (a, b) {
            (Term::Var(a), Term::Var(b)) => bind(variables, a, b),
            (Term::App { symbol: a, args: aa }, Term::App { symbol: b, args: bb }) =>
                aa.len() == bb.len() && bind(symbols, a, b)
                    && aa.iter().zip(bb).all(|(a,b)| terms(a,b,symbols,variables)),
            _ => false,
        }
    }
    fn search(index: usize, source: &[RewriteRule], live: &[RewriteRule],
        symbols: BTreeMap<Symbol, Symbol>, selected: &mut Vec<usize>, fuel: &mut usize) -> bool {
        if index == source.len() { return true; }
        for (candidate, rule) in live.iter().enumerate() {
            if selected.contains(&candidate) { continue; }
            if *fuel == 0 { return false; }
            *fuel -= 1;
            let mut s = symbols.clone();
            let mut v = BTreeMap::new();
            if terms(source[index].lhs(), rule.lhs(), &mut s, &mut v)
                && terms(source[index].rhs(), rule.rhs(), &mut s, &mut v) {
                selected.push(candidate);
                if search(index + 1, source, live, s, selected, fuel) { return true; }
                selected.pop();
            }
        }
        false
    }
    let mut selected = Vec::new();
    search(0, usable, current, BTreeMap::new(), &mut selected, &mut 100_000)
        .then(|| selected.into_iter().map(|index| current[index].clone()).collect())
}

pub(super) fn rebind_innermost_lhss(lhss: &[Term], current: &[Term]) -> Option<Vec<Term>> {
    let mut used = vec![false; current.len()];
    lhss.iter()
        .map(|source| {
            current.iter().enumerate().find_map(|(index, live)| {
                (!used[index] && alpha_numeric_term_equivalent(source, live)).then(|| {
                    used[index] = true;
                    live.clone()
                })
            })
        })
        .collect()
}

impl WorklistProcessor for ExactUsableRulesProcessor {
    fn name(&self) -> &'static str {
        "exact-dependency-pair-usable-rules"
    }

    fn apply(&self, state: &ProblemState) -> ProcessorResult {
        let replay_started = std::time::Instant::now();
        let replay_timing = std::env::var_os("FERRUM_EXACT_REPLAY_TIMING").is_some();
        let ProblemState::DependencyPairs(problem) = state else {
            return ProcessorResult::Inapplicable;
        };
        let mut payload_xml = self.payload_xml.clone();
        let current = problem
            .stats
            .active_rules
            .as_deref()
            .unwrap_or(problem.trs.rules());
        if let (Some(source_pairs_xml), Some(source_rules_xml)) =
            (&self.source_pairs_xml, &self.source_rules_xml)
        {
            let Ok(Some(source_pairs)) =
                crate::parsing::parse_cpf_rule_container_fragment(source_pairs_xml, "dps")
            else {
                return ProcessorResult::Failed {
                    reason: "invalid exact usable-rules source pairs".to_owned(),
                };
            };
            let Ok(Some(source_rules)) =
                crate::parsing::parse_cpf_rule_container_fragment(source_rules_xml, "usableRules")
            else {
                return ProcessorResult::Failed {
                    reason: "invalid exact usable-rules source rules".to_owned(),
                };
            };
            if replay_timing {
                eprintln!("exact-usable parsed-source {:?}", replay_started.elapsed());
            }
            let live_pairs = problem
                .pairs
                .iter()
                .map(|pair| pair.as_rule())
                .collect::<Vec<_>>();
            let Some(symbols) = super::general_red_pair::portable_rule_pair_isomorphism(
                &source_rules,
                &source_pairs,
                current,
                &live_pairs,
            ) else {
                return ProcessorResult::Failed {
                    reason: "exact usable-rules source state is not isomorphic to the live state"
                        .to_owned(),
                };
            };
            if replay_timing {
                eprintln!("exact-usable isomorphism {:?}", replay_started.elapsed());
            }
            let translated_rules = source_rules
                .iter()
                .map(|rule| crate::standardize::translate_rule_symbols(rule, &symbols))
                .collect::<Vec<_>>();
            let translated_pairs = source_pairs
                .iter()
                .map(|rule| crate::standardize::translate_rule_symbols(rule, &symbols))
                .collect::<Vec<_>>();
            if !super::general_red_pair::same_rule_multiset(&translated_rules, current) {
                return ProcessorResult::Failed {
                    reason: "exact usable-rules source rules do not match the live active rules"
                        .to_owned(),
                };
            }
            if !super::general_red_pair::same_rule_multiset(&translated_pairs, &live_pairs) {
                return ProcessorResult::Failed {
                    reason: "exact usable-rules source pairs do not match the live pairs"
                        .to_owned(),
                };
            }
            if symbols.iter().any(|(source, live)| source != live) {
                payload_xml =
                    super::exact_transformation::translate_payload_symbols(&payload_xml, &symbols);
            }
            if replay_timing {
                eprintln!("exact-usable translated {:?}", replay_started.elapsed());
            }
        } else if self.source_pairs_xml.is_some() || self.source_rules_xml.is_some() {
            return ProcessorResult::Failed {
                reason: "incomplete exact usable-rules source context".to_owned(),
            };
        }
        let Ok(Some(parsed_usable)) =
            crate::parsing::parse_cpf_rule_container_fragment(&payload_xml, "usableRules")
        else {
            return ProcessorResult::Failed {
                reason: "invalid exact usable-rules witness".to_owned(),
            };
        };
        if replay_timing {
            eprintln!("exact-usable parsed-payload {:?}", replay_started.elapsed());
        }
        // A typed MU-TERM local-usable-rules node is checked over the live
        // ordinary rules plus the generated unhiding bridges.  Those bridges
        // are rewrite obligations of this processor, but deliberately are
        // not members of the parent TRS.  Rebinding against `current` alone
        // therefore made every faithfully extracted localUsableRulesProc
        // containing a bridge impossible to replay.
        let mut muterm_rebind_rules = Vec::new();
        let rebind_rules = match &problem.stats.problem {
            DpProblemContext::ContextSensitive(context)
                if context.construction == CsrDpConstruction::MutermUnhiding =>
            {
                muterm_rebind_rules.extend_from_slice(current);
                for rule in muterm_innermost_unhiding_rules(&context.csr) {
                    if !muterm_rebind_rules.contains(&rule) {
                        muterm_rebind_rules.push(rule);
                    }
                }
                muterm_rebind_rules.as_slice()
            }
            _ => current,
        };
        let Some(usable) = rebind_usable_rules(&parsed_usable, rebind_rules)
            .or_else(|| relocate_usable_rule_subset(&parsed_usable, rebind_rules)) else {
            return ProcessorResult::Failed {
                reason: "exact usable-rules witness contains a rule outside the live active TRS"
                    .to_owned(),
            };
        };
        if replay_timing {
            eprintln!("exact-usable rebound {:?}", replay_started.elapsed());
        }
        if !problem.stats.minimal {
            return ProcessorResult::Failed {
                reason: "exact usable-rules processor requires a minimal DP problem".to_owned(),
            };
        }
        if usable.as_slice() == current {
            return ProcessorResult::Failed {
                reason: "exact usable-rules witness does not restrict the live active TRS"
                    .to_owned(),
            };
        }
        match &problem.stats.problem {
            DpProblemContext::Ordinary => {
                let active_trs = Trs::new_with_strategy(
                    problem.trs.name().map(str::to_string),
                    problem.trs.variables().clone(),
                    current.to_vec(),
                    problem.trs.strategy(),
                );
                let expected = if active_trs.strategy() == RewriteStrategy::Innermost {
                    let initial_lhss;
                    let innermost_lhss = if let Some(lhss) = problem.innermost_lhss.as_deref() {
                        Some(lhss)
                    } else {
                        // Q belongs to the DP problem, not to the currently
                        // restricted usable-rule obligation R.  In
                        // particular, a second usable-rules step must retain
                        // the original innermost normal-form context.
                        initial_lhss = initial_innermost_lhss(&problem.trs);
                        initial_lhss.as_deref()
                    };
                    let Some(innermost_lhss) = innermost_lhss else {
                        return ProcessorResult::Failed {
                            reason: "innermost usable-rules witness has no Q normal-form context"
                                .to_owned(),
                        };
                    };
                    // Validate the executable CPF condition itself.  The
                    // synthesized-search helper additionally root-completes
                    // this set as a conservative heuristic; requiring that
                    // larger heuristic set here rejects legal CPF witnesses
                    // (for example Mixed_innermost/wiehe13).
                    let required = ceta_innermost_usable_rules_for_pairs(
                        active_trs.rules(),
                        innermost_lhss,
                        &problem.pairs,
                    );
                    active_trs
                        .rules()
                        .iter()
                        .filter(|rule| required.contains(*rule))
                        .cloned()
                        .collect()
                } else {
                    ordinary_usable_rules(&active_trs, &problem.pairs)
                };
                if expected.iter().any(|rule| !usable.contains(rule)) {
                    return ProcessorResult::Failed {
                        reason: format!(
                            "exact usable-rules witness omits {} required ordinary usable rules",
                            expected
                                .iter()
                                .filter(|rule| !usable.contains(rule))
                                .count()
                        ),
                    };
                }
            }
            DpProblemContext::ContextSensitive(context)
                if context.construction == CsrDpConstruction::MutermUnhiding =>
            {
                // The typed MU-TERM checker validates these local obligations
                // against R plus the generated unhiding rules.  Preserve that
                // deliberately narrow exception here.
                let mut allowed = current.to_vec();
                for rule in muterm_innermost_unhiding_rules(&context.csr) {
                    if !allowed.contains(&rule) {
                        allowed.push(rule);
                    }
                }
                if usable.iter().any(|rule| !allowed.contains(rule)) {
                    return ProcessorResult::Inapplicable;
                }
            }
            DpProblemContext::ContextSensitive(context) if context.use_qcs_usable_rules => {
                // A QCS usable-rules CPF node denotes the executable closure,
                // not an arbitrary subset of the current rules.  Accepting a
                // pooled exact fragment by subset alone can therefore produce
                // a proof which Ferrum calls complete but CeTA rejects.
                let active_trs = Trs::new_with_strategy(
                    problem.trs.name().map(str::to_string),
                    problem.trs.variables().clone(),
                    current.to_vec(),
                    problem.trs.strategy(),
                );
                let Ok(active_csr) = CsrTrs::new(active_trs, context.csr.replacement_map().clone())
                else {
                    return ProcessorResult::Inapplicable;
                };
                let expected = if context.construction == CsrDpConstruction::Improved {
                    improved_qcs_certificate_usable_rules(&active_csr, &problem.pairs)
                } else {
                    qcs_certificate_usable_rules(&active_csr, &problem.pairs)
                };
                // CPF permits any sound superset of the computed usable
                // rules.  Requiring equality rejects certified witnesses
                // which deliberately retain additional rules; requiring only
                // U ⊆ R would permit an unsound omission.  Enforce the
                // actual boundary U_expected ⊆ U_witness ⊆ R.
                if expected.iter().any(|rule| !usable.contains(rule)) {
                    return ProcessorResult::Inapplicable;
                }
            }
            DpProblemContext::ContextSensitive(context)
                if context.construction == CsrDpConstruction::Innermost =>
            {
                let expected = innermost_csr_usable_rules(&context.csr, current, &problem.pairs);
                if expected.iter().any(|rule| !usable.contains(rule)) {
                    return ProcessorResult::Inapplicable;
                }
            }
            // Ferrum has no general certified usable-rules processor for the
            // remaining CSR-DP frameworks.  An external exact fragment must
            // not silently cross that theorem boundary.
            DpProblemContext::ContextSensitive(_) => return ProcessorResult::Inapplicable,
        }
        let mut child = problem.clone();
        child.stats.active_rules = Some(usable.clone());
        child.stats.active_rules_are_residual = true;
        // Match the computed processor's theorem boundary.  Ordinary
        // innermost usable rules preserve a minimal DP problem; this is what
        // licenses certified SCT/subterm continuations.  The currently
        // represented CSR usable-rule processors restrict their typed rule
        // obligation but do not preserve minimality.
        if matches!(problem.stats.problem, DpProblemContext::ContextSensitive(_)) {
            child.stats.minimal = false;
        }
        // An exact usable-rules witness has the same state semantics as the
        // computed processor: subsequent graph checks are restricted to its
        // certified rule set, including an explicitly empty set.
        child.stats.graph_rules = Some(usable.clone());
        ProcessorResult::Applied(ProcessorApplication::new(
            vec![ProblemState::DependencyPairs(child)],
            move |children| {
                let [ProblemCertificate::DependencyPairTree(proof)] =
                    <[ProblemCertificate; 1]>::try_from(children).ok()?
                else {
                    return None;
                };
                Some(ProblemCertificate::DependencyPairTree(
                    DpProofTree::ComponentContext {
                        usable_rules_processor: Some(usable.clone()),
                        innermost_lhss_processor: None,
                        proof: Box::new(proof),
                    },
                ))
            },
        ))
    }
}

#[cfg(test)]
mod tests {
    #[test]
    fn usable_witness_relocation_is_injective_and_rule_local() {
        use crate::core::{RewriteRule, Term};
        let rule = |f: &str, g: &str, x: &str| RewriteRule::new(
            Term::app(f, vec![Term::var(x)]), Term::app(g, vec![Term::var(x)]));
        let source = vec![rule("first", "second", "x"), rule("second", "third", "x")];
        let live = vec![rule("b", "c", "u"), rule("a", "b", "v")];
        assert_eq!(super::relocate_usable_rule_subset(&source, &live),
            Some(vec![live[1].clone(), live[0].clone()]));
        // Distinct source symbols cannot collapse to one live symbol.
        assert!(super::relocate_usable_rule_subset(&source[..1], &[rule("a", "a", "x")]).is_none());
        // Nor may repeated rule variables be separated across lhs/rhs.
        let invalid = RewriteRule::new(Term::app("a", vec![Term::var("x")]),
            Term::app("b", vec![Term::var("y")]));
        assert!(super::relocate_usable_rule_subset(&source[..1], &[invalid]).is_none());
        assert!(super::relocate_usable_rule_subset(&source, &live[..1]).is_none());
    }

    use std::collections::BTreeSet;

    use crate::core::{RewriteRule, RewriteStrategy, Term, Trs, Variable};
    use crate::proving::dependency_pairs::{
        CsrDpProblemContext, DependencyPair, DpOptions, csr_dp_problem_state, dp_state_input_cpf,
        muterm_innermost_unhiding_rules, rta_csr_dependency_pairs,
    };
    use crate::proving::processors::dp::DpProblemState;

    use super::*;

    #[test]
    fn source_dp_binding_uses_pairs_to_disambiguate_symmetric_rules() {
        let rule = |f: &str| RewriteRule::new(Term::app(f, vec![Term::var("x")]), Term::var("x"));
        let pair = |f: &str, g: &str| DependencyPair::from_rule(RewriteRule::new(
            Term::app(format!("{f}#"), vec![Term::app(f, vec![Term::var("x")])]),
            Term::app(format!("{g}#"), vec![Term::var("x")])), 0);
        let source = DpProblemState::ordinary(Trs::new(None, BTreeSet::new(), vec![rule("f"), rule("g")]),
            vec![pair("f", "g")], DpOptions::default());
        let mut live = DpProblemState::ordinary(Trs::new(None, BTreeSet::new(), vec![rule("z"), rule("a")]),
            vec![pair("a", "z")], DpOptions::default());
        let xml = dp_state_input_cpf(&source);
        let mapping = source_dp_symbol_isomorphism(&xml, &live).unwrap();
        assert_eq!(mapping[&Symbol::new("f")], Symbol::new("a"));
        assert_eq!(mapping[&Symbol::new("f#")], Symbol::new("a#"));
        live.stats.minimal = !live.stats.minimal;
        assert!(source_dp_symbol_isomorphism(&xml, &live).is_none());
    }

    #[test]
    fn source_bound_q_choice_relocates_q_only_symbols_and_checks_roles() {
        let make = |f: &str, g: &str, marked: &str, q: &str, var: &str| {
            let x = Term::var(var);
            let trs = Trs::new_with_strategy(None, BTreeSet::new(), vec![RewriteRule::new(
                Term::app(f, vec![x.clone()]), Term::app(g, vec![x.clone()]))], RewriteStrategy::Innermost);
            let mut state = DpProblemState::ordinary(trs, vec![DependencyPair::new_for_test(
                Term::app(marked, vec![x.clone()]), Term::app(marked, vec![x.clone()]))], DpOptions::default());
            state.innermost_lhss = Some(vec![Term::app(f, vec![x.clone()]), Term::app(q, vec![x])]);
            state
        };
        let source = make("f", "g", "F#", "q_only", "x");
        let mut live = make("a", "b", "H#", "unused", "u");
        live.innermost_lhss.as_mut().unwrap().reverse();
        let payload = "<innermostLhss><funapp><name>q_only</name><var>x</var></funapp></innermostLhss>";
        let mut processor = ExactInnermostLhssProcessor { payload_xml: payload.into(), source_dp_input_xml: None };
        assert!(matches!(processor.apply(&ProblemState::DependencyPairs(live.clone())), ProcessorResult::Inapplicable));
        processor.source_dp_input_xml = Some(dp_state_input_cpf(&source));
        let ProcessorResult::Applied(application) = processor.apply(&ProblemState::DependencyPairs(live.clone()))
            else { panic!("source-bound Q target must survive signature renaming") };
        let ProblemState::DependencyPairs(child) = &application.residuals[0] else { panic!() };
        assert_eq!(child.innermost_lhss, Some(vec![Term::app("unused", vec![Term::var("u")])]));
        assert_eq!(child.trs.rules(), live.trs.rules());
        assert_eq!(child.stats.minimal, live.stats.minimal);
        let atom = crate::proving::DpStrategyProcessor::ExactInnermostLhss {
            payload_xml: payload.into(), source_dp_input_xml: processor.source_dp_input_xml.clone() };
        assert_eq!(crate::proving::DpStrategy::parse(&atom.to_strategy_atom()).unwrap(),
            crate::proving::DpStrategy::Processor(atom));
        live.stats.strict_rules = live.trs.rules().to_vec();
        assert!(matches!(processor.apply(&ProblemState::DependencyPairs(live)), ProcessorResult::Inapplicable));
    }

    #[test]
    fn exact_q_subset_choice_checks_live_membership_and_minimality() {
        let trs = Trs::new_with_strategy(None, BTreeSet::from([Variable::new("x")]),
            vec![RewriteRule::new(Term::app("f", vec![Term::var("x")]), Term::app("c", vec![]))],
            RewriteStrategy::Innermost);
        let mut problem = DpProblemState::ordinary(trs, vec![], DpOptions::default());
        let empty = ExactInnermostLhssProcessor { payload_xml: "<innermostLhss/>".into(), source_dp_input_xml: None };
        let ProcessorResult::Applied(application) = empty.apply(&ProblemState::DependencyPairs(problem.clone()))
            else { panic!("Q may be reduced to the empty subset") };
        let ProblemState::DependencyPairs(child) = &application.residuals[0] else { panic!() };
        assert_eq!(child.innermost_lhss, Some(vec![]));
        assert_eq!(child.stats.minimal, problem.stats.minimal);
        assert_eq!(child.stats.normal_form_substitutions, problem.stats.normal_form_substitutions);
        let foreign = ExactInnermostLhssProcessor { source_dp_input_xml: None, payload_xml:
            "<innermostLhss><funapp><name>foreign</name><var>x</var></funapp></innermostLhss>".into() };
        assert!(matches!(foreign.apply(&ProblemState::DependencyPairs(problem.clone())), ProcessorResult::Inapplicable));
        problem.stats.minimal = false;
        assert!(matches!(empty.apply(&ProblemState::DependencyPairs(problem)), ProcessorResult::Inapplicable));
    }

    #[test]
    fn relocated_usable_subset_still_requires_the_live_closure() {
        let rule = |f: &str| RewriteRule::new(Term::app(f, vec![Term::var("x")]), Term::var("x"));
        let processor = ExactUsableRulesProcessor {
            payload_xml: "<usableRules><rules><rule><funapp><name>old</name><var>x</var></funapp><var>x</var></rule></rules></usableRules>".into(),
            source_pairs_xml: None, source_rules_xml: None,
        };
        let state = |rules| ProblemState::DependencyPairs(DpProblemState::ordinary(
            Trs::new(None, Default::default(), rules),
            vec![DependencyPair::new_for_test(Term::app("F#", vec![Term::var("x")]),
                Term::app("F#", vec![Term::app("f", vec![Term::var("x")])]))],
            DpOptions::default()));
        assert!(matches!(processor.apply(&state(vec![rule("f"), rule("g")])), ProcessorResult::Applied(_)));
        assert!(matches!(processor.apply(&state(vec![rule("g"), rule("f")])),
            ProcessorResult::Failed { reason } if reason.contains("required ordinary usable rules")));
    }

    #[test]
    fn exact_ordinary_innermost_usable_rules_preserve_minimality() {
        let trs = Trs::new_with_strategy(
            None,
            BTreeSet::from([Variable::new("x")]),
            vec![RewriteRule::new(
                Term::app("f", vec![Term::var("x")]),
                Term::app("c", Vec::new()),
            )],
            RewriteStrategy::Innermost,
        );
        let state = ProblemState::DependencyPairs(DpProblemState::ordinary(
            trs,
            vec![DependencyPair::new_for_test(
                Term::app("f#", vec![Term::var("x")]),
                Term::app("g#", vec![Term::var("x")]),
            )],
            DpOptions::default(),
        ));

        let ProcessorResult::Applied(application) = ExactUsableRulesProcessor {
            payload_xml: "<usableRules><rules/></usableRules>".to_owned(),
            source_pairs_xml: None,
            source_rules_xml: None,
        }
        .apply(&state) else {
            panic!("exact usable-rules witness should apply");
        };
        let [ProblemState::DependencyPairs(residual)] =
            <[ProblemState; 1]>::try_from(application.residuals).unwrap()
        else {
            panic!("expected one DP residual");
        };
        assert!(residual.stats.minimal);
    }

    #[test]
    fn exact_muterm_local_usable_rules_rebind_generated_unhiding_bridges() {
        let csr = crate::parsing::parse_ari_cstrs(
            Some("CSR_04/Ex1_GM03.ari".to_owned()),
            include_str!("../../../../tests/fixtures/csr_ex1_gm03.ari"),
        )
        .expect("parse Ex1_GM03 fixture");
        let pairs = rta_csr_dependency_pairs(&csr);
        let context = CsrDpProblemContext::muterm_unhiding(&csr);
        let mut state =
            csr_dp_problem_state(&csr, pairs, context, DpOptions::default(), None, Vec::new())
                .expect("materialize typed MU-TERM state");
        let bridge = muterm_innermost_unhiding_rules(&csr)
            .into_iter()
            .next()
            .expect("fixture has an unhiding bridge");

        let mut payload_state = state.clone();
        payload_state.stats.active_rules = Some(vec![bridge.clone()]);
        let serialized = dp_state_input_cpf(&payload_state);
        let start = serialized
            .find("<usableRules>")
            .expect("usable-rules start");
        let end =
            serialized.find("</usableRules>").expect("usable-rules end") + "</usableRules>".len();
        let payload_xml = serialized[start..end].to_owned();

        // The live parent contains only its ordinary TRS rules.  The exact
        // local boundary is nevertheless allowed to add a generated bridge.
        state.stats.active_rules = None;
        let result = ExactUsableRulesProcessor {
            payload_xml,
            source_pairs_xml: None,
            source_rules_xml: None,
        }
        .apply(&ProblemState::DependencyPairs(state));
        let ProcessorResult::Applied(application) = result else {
            panic!("generated MU-TERM bridge should be replayable");
        };
        let [ProblemState::DependencyPairs(residual)] =
            <[ProblemState; 1]>::try_from(application.residuals).unwrap()
        else {
            panic!("expected one typed MU-TERM residual");
        };
        assert_eq!(residual.stats.active_rules, Some(vec![bridge]));
    }
}

pub struct ExactInnermostLhssProcessor {
    pub payload_xml: String,
    pub source_dp_input_xml: Option<String>,
}

pub(super) fn source_dp_symbol_isomorphism(
    source_xml: &str,
    problem: &super::DpProblemState,
) -> Option<BTreeMap<Symbol, Symbol>> {
    use crate::standardize::{StandardizationGroup, StandardizationProblem, TermPair,
        standardize_problem_with_bijection};
    let crate::parsing::CpfInputProblem::Dp { trs, pairs, weak_pairs, strict_rules,
        active_rules, minimal, normal_form_substitutions, innermost_lhss, clear_innermost_lhss, .. } =
        crate::parsing::parse_cpf_input(None, source_xml).ok()? else { return None };
    if !matches!(problem.stats.problem, DpProblemContext::Ordinary)
        || minimal != problem.stats.minimal
        || normal_form_substitutions != problem.stats.normal_form_substitutions
        || trs.strategy() != problem.trs.strategy() {
        return None;
    }
    let source_q = innermost_lhss.or_else(|| (!clear_innermost_lhss)
        .then(|| initial_innermost_lhss(&trs)).flatten()).unwrap_or_default();
    let current_q = problem.innermost_lhss.clone().or_else(|| initial_innermost_lhss(&problem.trs)).unwrap_or_default();
    let make_problem = |rules: &[RewriteRule], pairs: &[RewriteRule],
                        weak: &[RewriteRule], strict: &[RewriteRule], q: &[Term]| {
        StandardizationProblem::new(vec![
            StandardizationGroup::new("R", rules.iter().map(TermPair::from_rule).collect()),
            StandardizationGroup::new("P", pairs.iter().map(TermPair::from_rule).collect()),
            StandardizationGroup::new("Pw", weak.iter().map(TermPair::from_rule).collect()),
            StandardizationGroup::new("strictR", strict.iter().map(TermPair::from_rule).collect()),
            StandardizationGroup::new("Q", q.iter().map(|t| TermPair::new(t.clone(), t.clone())).collect()),
        ])
    };
    let source = standardize_problem_with_bijection(&make_problem(
        active_rules.as_deref().unwrap_or(trs.rules()), &pairs, &weak_pairs,
        &strict_rules, &source_q)).ok()?;
    let live_pairs = problem.pairs.iter().map(|p| p.as_rule()).collect::<Vec<_>>();
    let live_weak = problem.stats.weak_pairs.iter().map(|p| p.as_rule()).collect::<Vec<_>>();
    let live = standardize_problem_with_bijection(&make_problem(
        problem.stats.active_rules.as_deref().unwrap_or(problem.trs.rules()),
        &live_pairs, &live_weak, &problem.stats.strict_rules, &current_q)).ok()?;
    if source.problem != live.problem { return None; }
    source.function_bijection.iter().map(|(symbol, canonical)|
        Some((symbol.clone(), live.inverse_function_bijection.get(canonical)?.clone())))
        .collect::<Option<BTreeMap<_, _>>>()
}

fn rebind_source_q_target(source_xml: &str, target: &[Term], problem: &super::DpProblemState,
                          current_q: &[Term]) -> Option<Vec<Term>> {
    let symbols = source_dp_symbol_isomorphism(source_xml, problem)?;
    use crate::standardize::translate_term_symbols;
    let translated = target.iter().map(|term| translate_term_symbols(term, &symbols)).collect::<Vec<_>>();
    rebind_innermost_lhss(&translated, current_q)
}

impl WorklistProcessor for ExactInnermostLhssProcessor {
    fn name(&self) -> &'static str {
        "exact-dependency-pair-innermost-lhss"
    }

    fn apply(&self, state: &ProblemState) -> ProcessorResult {
        let ProblemState::DependencyPairs(problem) = state else {
            return ProcessorResult::Inapplicable;
        };
        if !problem.stats.minimal
            || problem.trs.strategy() != RewriteStrategy::Innermost
            || !matches!(problem.stats.problem, DpProblemContext::Ordinary)
        {
            return ProcessorResult::Inapplicable;
        }
        let Ok(Some(parsed_lhss)) =
            crate::parsing::parse_cpf_term_container_fragment(&self.payload_xml, "innermostLhss")
        else {
            return ProcessorResult::Failed {
                reason: "invalid exact innermost-LHS witness".to_owned(),
            };
        };
        let current = problem
            .innermost_lhss
            .clone()
            .or_else(|| initial_innermost_lhss(&problem.trs))
            .unwrap_or_default();
        let Some(lhss) = rebind_innermost_lhss(&parsed_lhss, &current).or_else(|| {
            rebind_source_q_target(self.source_dp_input_xml.as_deref()?,
                                  &parsed_lhss, problem, &current)
        }) else {
            return ProcessorResult::Inapplicable;
        };
        if lhss == current {
            return ProcessorResult::Inapplicable;
        }
        let mut child = problem.clone();
        child.innermost_lhss = Some(lhss.clone());
        ProcessorResult::Applied(ProcessorApplication::new(
            vec![ProblemState::DependencyPairs(child)],
            move |children| {
                let [ProblemCertificate::DependencyPairTree(proof)] =
                    <[ProblemCertificate; 1]>::try_from(children).ok()?
                else {
                    return None;
                };
                Some(ProblemCertificate::DependencyPairTree(
                    DpProofTree::ComponentContext {
                        usable_rules_processor: None,
                        innermost_lhss_processor: Some(lhss.clone()),
                        proof: Box::new(proof),
                    },
                ))
            },
        ))
    }
}
