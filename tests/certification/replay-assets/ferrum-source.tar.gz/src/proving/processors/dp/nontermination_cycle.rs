//! Native NO-only restriction to a simple marked-root cycle.
//!
//! This is search restriction, not a termination graph theorem. CeTA's
//! `rule_removal_nonterm_dp` permits deleting arbitrary P/R members when
//! reconstructing a nontermination child. Here P is selected structurally;
//! R, Q, NFS, and the remaining context are unchanged.

use std::collections::BTreeSet;
use std::time::Instant;

use super::super::{
    ProblemCertificate, ProblemState, ProcessorApplication, ProcessorResult, WorklistProcessor,
};
use crate::proving::DpNonterminationProof;
use crate::proving::dependency_pairs::{DpProblemContext, strategy_timed_out};
use crate::standardize::{
    StandardizationGroup, StandardizationProblem, TermPair, standardize_problem_with_bijection,
};

pub struct NonterminationCycleProcessor {
    pub candidate: usize,
    pub min_length: usize,
    pub max_length: usize,
    pub repeated: bool,
    pub deadline: Option<Instant>,
}

pub(super) fn canonical_pair_rule_order(
    problem: &super::DpProblemState,
) -> Option<(Vec<usize>, Vec<usize>)> {
    let rules = problem
        .stats
        .active_rules
        .as_deref()
        .unwrap_or(problem.trs.rules());
    let q = problem.innermost_lhss.as_deref().unwrap_or(&[]);
    let signature = StandardizationProblem::new(vec![
        StandardizationGroup::new(
            "dps",
            problem
                .pairs
                .iter()
                .map(|p| TermPair::from_rule(&p.as_rule()))
                .collect(),
        ),
        StandardizationGroup::new("rules", rules.iter().map(TermPair::from_rule).collect()),
        StandardizationGroup::new(
            "q",
            q.iter()
                .map(|t| TermPair::new(t.clone(), t.clone()))
                .collect(),
        ),
    ]);
    let canonical = standardize_problem_with_bijection(&signature).ok()?;
    let order = |group| {
        let mut indices = canonical
            .pair_metadata
            .iter()
            .filter(|m| m.original_group_index == group)
            .map(|m| (m.canonical_pair_index, m.original_pair_index))
            .collect::<Vec<_>>();
        indices.sort_unstable();
        indices.into_iter().map(|(_, original)| original).collect()
    };
    Some((order(0), order(1)))
}

impl WorklistProcessor for NonterminationCycleProcessor {
    fn name(&self) -> &'static str {
        "nontermination-cycle"
    }

    fn apply(&self, state: &ProblemState) -> ProcessorResult {
        let ProblemState::DependencyPairs(problem) = state else {
            return ProcessorResult::Inapplicable;
        };
        if !matches!(problem.stats.problem, DpProblemContext::Ordinary)
            || !problem.stats.weak_pairs.is_empty()
            || !problem.stats.strict_rules.is_empty()
            || !(1..=8).contains(&self.max_length)
            || self.min_length == 0
            || self.min_length > self.max_length
            || problem.pairs.len() < 2
        {
            return ProcessorResult::Inapplicable;
        }
        if strategy_timed_out(self.deadline) {
            return ProcessorResult::TimedOut;
        }
        let Some((order, _)) = canonical_pair_rule_order(problem) else {
            return ProcessorResult::Inapplicable;
        };
        let mut cycles = BTreeSet::new();
        let mut explored = 0usize;
        for first in 0..order.len() {
            let Some(goal) = problem.pairs[order[first]].lhs().root_symbol() else {
                continue;
            };
            let mut pending = vec![vec![first]];
            while let Some(path) = pending.pop() {
                if strategy_timed_out(self.deadline) {
                    return ProcessorResult::TimedOut;
                }
                explored += 1;
                if explored > 65_536 {
                    break;
                }
                let pair = &problem.pairs[order[*path.last().unwrap()]];
                let Some(next_root) = pair.rhs().root_symbol() else {
                    continue;
                };
                if next_root == goal {
                    let mut members = path.clone();
                    members.sort_unstable();
                    cycles.insert((members.len(), members));
                    if !self.repeated {
                        continue;
                    }
                }
                if path.len() >= self.max_length
                    || (!self.repeated
                        && path.iter().any(|i| {
                            problem.pairs[order[*i]].lhs().root_symbol() == Some(next_root)
                        }))
                {
                    continue;
                }
                for next in (first + 1..order.len()).rev() {
                    if problem.pairs[order[next]].lhs().root_symbol() == Some(next_root)
                        && !path.contains(&next)
                    {
                        let mut extension = path.clone();
                        extension.push(next);
                        pending.push(extension);
                    }
                }
            }
            if explored > 65_536 {
                break;
            }
        }
        let Some((_, selected)) = cycles
            .into_iter()
            .filter(|(_, members)| {
                members.len() >= self.min_length && members.len() < problem.pairs.len()
            })
            .nth(self.candidate)
        else {
            return ProcessorResult::Inapplicable;
        };
        let selected = selected
            .into_iter()
            .map(|rank| order[rank])
            .collect::<BTreeSet<_>>();
        let removed = problem
            .pairs
            .iter()
            .enumerate()
            .filter(|(i, _)| !selected.contains(i))
            .map(|(_, pair)| pair.clone())
            .collect::<Vec<_>>();
        let mut child = problem.clone();
        child.pairs = problem
            .pairs
            .iter()
            .enumerate()
            .filter(|(i, _)| selected.contains(i))
            .map(|(_, pair)| pair.clone())
            .collect();
        ProcessorResult::Applied(ProcessorApplication::new(
            vec![ProblemState::DependencyPairs(child)],
            move |children| {
                let [ProblemCertificate::DependencyPairNontermination(proof)] =
                    <[ProblemCertificate; 1]>::try_from(children).ok()?
                else {
                    return None;
                };
                Some(ProblemCertificate::DependencyPairNontermination(
                    DpNonterminationProof::DpRuleRemoval {
                        removed_pairs: removed.clone(),
                        removed_rules: vec![],
                        proof: Box::new(proof),
                    },
                ))
            },
        ))
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::core::{RewriteRule, Term, Trs};
    use crate::proving::dependency_pairs::{DependencyPair, DpOptions, DpProofTree, DpStrategy};
    use crate::proving::processors::dp::{DpNonterminationProcessor, DpProblemState};

    #[test]
    fn repeated_marked_roots_do_not_collapse_to_singleton_cycles() {
        let term = |name| Term::app("p#", vec![Term::app(name, vec![])]);
        let state = DpProblemState::ordinary(
            Trs::new(None, BTreeSet::new(), vec![]),
            vec![
                DependencyPair::new_for_test(term("a"), term("b")),
                DependencyPair::new_for_test(term("b"), term("a")),
                DependencyPair::new_for_test(term("c"), term("d")),
            ],
            DpOptions::default(),
        );
        let mut found = false;
        for candidate in 0..3 {
            let processor = NonterminationCycleProcessor {
                candidate,
                min_length: 2,
                max_length: 2,
                repeated: true,
                deadline: None,
            };
            let ProcessorResult::Applied(app) =
                processor.apply(&ProblemState::DependencyPairs(state.clone()))
            else {
                continue;
            };
            let ProblemState::DependencyPairs(child) = &app.residuals[0] else {
                panic!()
            };
            assert_eq!(child.pairs.len(), 2);
            if let ProcessorResult::Applied(terminal) =
                (DpNonterminationProcessor { deadline: None })
                    .apply_symbolic_loop(&app.residuals[0])
            {
                assert!(
                    app.reconstruct(vec![terminal.reconstruct(vec![]).unwrap()])
                        .is_some()
                );
                found = true;
            }
        }
        assert!(found);
        assert!(
            DpStrategy::parse("nontermination-cycle(min-length=2,max-length=2,repeated=1)").is_ok()
        );
        assert!(DpStrategy::parse("nontermination-cycle(repeated=2)").is_err());
    }

    fn problem(names: [&str; 4], reverse: bool) -> DpProblemState {
        let [a, b, c, d] = names;
        let term = |name| Term::app(name, vec![]);
        let mut pairs = vec![
            DependencyPair::new_for_test(term(a), term(b)),
            DependencyPair::new_for_test(term(b), term(a)),
            DependencyPair::new_for_test(term(c), term(d)),
        ];
        if reverse {
            pairs.reverse();
        }
        DpProblemState::ordinary(
            Trs::new(None, Default::default(), vec![]),
            pairs,
            DpOptions::default(),
        )
    }

    #[test]
    fn cycle_restriction_is_renaming_and_order_independent_and_preserves_context() {
        for (names, reverse) in [
            (["a#", "b#", "c#", "d#"], false),
            (["z#", "y#", "x#", "w#"], true),
        ] {
            let mut state = problem(names, reverse);
            state.innermost_lhss = Some(vec![Term::app("guard", vec![])]);
            state.stats.active_rules = Some(vec![RewriteRule::new(
                Term::app("u", vec![]),
                Term::app("v", vec![]),
            )]);
            state.stats.normal_form_substitutions = true;
            let ProcessorResult::Applied(app) = (NonterminationCycleProcessor {
                candidate: 0,
                min_length: 1,
                max_length: 2,
                repeated: false,
                deadline: None,
            })
            .apply(&ProblemState::DependencyPairs(state.clone())) else {
                panic!("two-pair cycle")
            };
            let ProblemState::DependencyPairs(child) = &app.residuals[0] else {
                panic!()
            };
            assert_eq!(child.pairs.len(), 2);
            assert!(child.pairs.iter().all(|p| {
                p.lhs()
                    .root_symbol()
                    .is_some_and(|s| s.as_str() == names[0] || s.as_str() == names[1])
            }));
            assert_eq!(child.trs, state.trs);
            assert_eq!(child.innermost_lhss, state.innermost_lhss);
            assert_eq!(child.stats.active_rules, state.stats.active_rules);
            assert_eq!(
                child.stats.normal_form_substitutions,
                state.stats.normal_form_substitutions
            );
            assert_eq!(child.stats.minimal, state.stats.minimal);
            assert!(
                app.reconstruct(vec![ProblemCertificate::DependencyPairTree(
                    DpProofTree::Empty
                )])
                .is_none()
            );
        }
    }

    #[test]
    fn cycle_bounds_parser_and_relative_guard() {
        assert!(DpStrategy::parse("nontermination-cycle(candidate=0,max-length=2)").is_ok());
        assert!(DpStrategy::parse("nontermination-cycle(max-length=0)").is_err());
        let mut state = problem(["a#", "b#", "c#", "d#"], false);
        let processor = NonterminationCycleProcessor {
            candidate: 0,
            min_length: 1,
            max_length: 1,
            repeated: false,
            deadline: None,
        };
        assert!(matches!(
            processor.apply(&ProblemState::DependencyPairs(state.clone())),
            ProcessorResult::Inapplicable
        ));
        state.stats.weak_pairs = vec![state.pairs[0].clone()];
        assert!(matches!(
            (NonterminationCycleProcessor {
                candidate: 0,
                min_length: 1,
                max_length: 2,
                repeated: false,
                deadline: None
            })
            .apply(&ProblemState::DependencyPairs(state)),
            ProcessorResult::Inapplicable
        ));
    }

    #[test]
    fn local_ceta_native_cycle_restriction_certifies() {
        let state = problem(["a#", "b#", "c#", "d#"], false);
        let ProcessorResult::Applied(select) = (NonterminationCycleProcessor {
            candidate: 0,
            min_length: 2,
            max_length: 2,
            repeated: false,
            deadline: None,
        })
        .apply(&ProblemState::DependencyPairs(state.clone())) else {
            panic!()
        };
        let ProcessorResult::Applied(terminal) = (DpNonterminationProcessor { deadline: None })
            .apply_symbolic_loop(&select.residuals[0])
        else {
            panic!()
        };
        let proof = terminal.reconstruct(vec![]).unwrap();
        let ProblemCertificate::DependencyPairNontermination(proof) =
            select.reconstruct(vec![proof]).unwrap()
        else {
            panic!()
        };
        let xml = crate::cert::write_cpf3_dp_nontermination_state(&state, &proof).unwrap();
        assert!(xml.contains("<dpRuleRemoval>"));
        let path = std::env::temp_dir().join(format!(
            "ferrum-cycle-restriction-{}.xml",
            std::process::id()
        ));
        std::fs::write(&path, xml).unwrap();
        let checker = std::env::var("CETA_CSR_BIN").unwrap_or_else(|_| "../CeTA-CSR/ceta".into());
        let output = std::process::Command::new(checker)
            .arg(&path)
            .output()
            .unwrap();
        let _ = std::fs::remove_file(path);
        assert!(
            output.status.success()
                && String::from_utf8_lossy(&output.stdout).trim() == "CERTIFIED",
            "{}{}",
            String::from_utf8_lossy(&output.stdout),
            String::from_utf8_lossy(&output.stderr)
        );
    }
}
