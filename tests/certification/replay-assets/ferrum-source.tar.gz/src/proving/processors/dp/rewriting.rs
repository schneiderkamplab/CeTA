use std::time::Instant;

use crate::core::{RewriteStrategy, Trs};
use crate::proving::dependency_pairs::{
    CsrDpConstruction, DpProblemContext, DpProofTree, strategy_timed_out,
    synthesize_innermost_rewriting_step_candidate_filtered,
};
use crate::proving::runtime::CancellationScope;

use super::super::{
    ProblemCertificate, ProblemState, ProcessorApplication, ProcessorResult, WorklistProcessor,
};

pub struct RewritingProcessor {
    pub max_per_pair: Option<usize>,
    pub candidate_index: usize,
    pub deadline: Option<Instant>,
}

pub(crate) fn rewriting_candidate_count(state: &ProblemState, max_per_pair: Option<usize>) -> usize {
    let ProblemState::DependencyPairs(problem) = state else { return 0 };
    if max_per_pair == Some(0) || problem.trs.strategy() != RewriteStrategy::Innermost
        || !problem.stats.weak_pairs.is_empty()
        || matches!(&problem.stats.problem, DpProblemContext::ContextSensitive(context)
            if context.construction == CsrDpConstruction::MutermUnhiding)
    { return 0; }
    let active_trs = Trs::new_with_strategy(problem.trs.name().map(str::to_string),
        problem.trs.variables().clone(),
        problem.stats.active_rules.clone().unwrap_or_else(|| problem.trs.rules().to_vec()),
        problem.trs.strategy());
    crate::proving::dependency_pairs::innermost_rewriting_candidate_count(
        &active_trs, &problem.pairs, problem.innermost_lhss.as_deref())
}

impl WorklistProcessor for RewritingProcessor {
    fn name(&self) -> &'static str {
        "dependency-pair-rewriting"
    }

    fn apply(&self, state: &ProblemState) -> ProcessorResult {
        let ProblemState::DependencyPairs(problem) = state else {
            return ProcessorResult::Inapplicable;
        };
        if problem.trs.strategy() != RewriteStrategy::Innermost
            || !problem.stats.weak_pairs.is_empty()
        {
            return ProcessorResult::Inapplicable;
        }
        // A typed MU-TERM pair already represents one exact macro step: a
        // noncollapsing pair, or a collapsing pair immediately followed by
        // its checked unhiding rule.  Rewriting its expanded right-hand side
        // again is neither part of the retained MU-TERM continuation nor
        // useful for the dedicated reduction-triple processor.  In
        // particular, recursive examples such as Ex1_GM03 otherwise grow a
        // nested `if`/`p` term on every worklist visit and spend the whole
        // deadline serializing progressively larger residual states.
        if matches!(
            &problem.stats.problem,
            DpProblemContext::ContextSensitive(context)
                if context.construction == CsrDpConstruction::MutermUnhiding
        ) {
            return ProcessorResult::Inapplicable;
        }
        let cancellation = CancellationScope::current(self.deadline);
        if cancellation.is_cancelled() || strategy_timed_out(self.deadline) {
            return ProcessorResult::TimedOut;
        }
        if self.max_per_pair == Some(0) {
            return ProcessorResult::Inapplicable;
        }
        let active_rules = problem
            .stats
            .active_rules
            .clone()
            .unwrap_or_else(|| problem.trs.rules().to_vec());
        let active_trs = Trs::new_with_strategy(
            problem.trs.name().map(str::to_string),
            problem.trs.variables().clone(),
            active_rules,
            problem.trs.strategy(),
        );
        let Some((step, residual_pairs)) = synthesize_innermost_rewriting_step_candidate_filtered(
            &active_trs,
            &problem.pairs,
            problem.innermost_lhss.as_deref(),
            self.candidate_index,
            |_| true,
        ) else {
            return ProcessorResult::Inapplicable;
        };
        let mut residual = problem.clone();
        residual.pairs = residual_pairs;

        ProcessorResult::Applied(ProcessorApplication::new(
            vec![ProblemState::DependencyPairs(residual)],
            move |children| {
                let [ProblemCertificate::DependencyPairTree(proof)] =
                    <[ProblemCertificate; 1]>::try_from(children).ok()?
                else {
                    return None;
                };
                Some(ProblemCertificate::DependencyPairTree(
                    DpProofTree::Rewriting {
                        step: Box::new(step.clone()),
                        proof: Box::new(proof),
                    },
                ))
            },
        ))
    }
}
