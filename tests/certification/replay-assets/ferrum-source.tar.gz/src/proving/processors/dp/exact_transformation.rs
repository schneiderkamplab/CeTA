use std::collections::{BTreeMap, BTreeSet};

use crate::core::{ReplacementMap, RewriteStrategy, Symbol, Trs};
use crate::parsing::{CpfInputProblem, parse_cpf_input};
use crate::proving::dependency_pairs::{
    DependencyPair, DpForwardInstantiationStep, DpInstantiationStep, DpNarrowingStep,
    DpProblemContext, DpProofTree, DpRewritingStep, alpha_unique_pairs, apply_substitution,
    dependency_pair_rules_alpha_equivalent, dependency_pairs_alpha_equivalent, match_term,
    narrow_pair_at_position, narrowing_position_is_admissible,
    narrowing_position_is_ceta_q_admissible, replace_subterm_at_position, subterm_at_position,
    term_is_linear, validate_forward_instantiation_step, q_instantiation_ceta_coverage_holds,
    csr_instantiation_coverage_holds,
};
use crate::standardize::{standardize_trs_with_bijection, translate_rule_symbols};

use super::super::{
    ProblemCertificate, ProblemState, ProcessorApplication, ProcessorResult, WorklistProcessor,
};
use super::{
    ForwardInstantiationProcessor, InstantiationProcessor, NarrowingProcessor, RewritingProcessor,
};

pub struct ExactDpTransformationProcessor {
    pub processor_tag: String,
    pub payload_xml: String,
    pub dp_input_xml: String,
    pub source_dp_input_xml: Option<String>,
}

pub struct ExactDpTerminationProofProcessor {
    pub source_dp_input_xml: String,
    pub dp_proof_xml: String,
}

impl WorklistProcessor for ExactDpTerminationProofProcessor {
    fn name(&self) -> &'static str {
        "exact-dp-proof"
    }

    fn apply(&self, state: &ProblemState) -> ProcessorResult {
        crate::proving::processors::reject_retired_complete_termination_proof();
        let ProblemState::DependencyPairs(problem) = state else {
            return ProcessorResult::Inapplicable;
        };
        let Ok(CpfInputProblem::Dp {
            mut trs,
            pairs,
            weak_pairs,
            strict_rules,
            active_rules,
            minimal,
            innermost_lhss,
            ..
        }) = parse_cpf_input(None, &self.source_dp_input_xml)
        else {
            return ProcessorResult::Failed {
                reason: "invalid exact DP proof source".to_owned(),
            };
        };
        trs = restore_retained_dp_strategy(trs, problem.trs.strategy(), innermost_lhss.is_some());
        let Some((symbols, _)) = portable_trs_isomorphism(&trs, &problem.trs) else {
            return ProcessorResult::Inapplicable;
        };
        let translated_pairs = pairs
            .into_iter()
            .map(|rule| DependencyPair::from_rule(translate_rule_symbols(&rule, &symbols), 0))
            .collect::<Vec<_>>();
        let same_pairs = |left: &[DependencyPair], right: &[DependencyPair]| {
            left.len() == right.len() && {
                let mut used = vec![false; right.len()];
                left.iter().all(|pair| {
                    right
                        .iter()
                        .enumerate()
                        .find_map(|(index, other)| {
                            (!used[index] && dependency_pairs_alpha_equivalent(pair, other)).then(
                                || {
                                    used[index] = true;
                                },
                            )
                        })
                        .is_some()
                })
            }
        };
        if !same_pairs(&translated_pairs, &problem.pairs) {
            return ProcessorResult::Inapplicable;
        }
        let translated_weak = weak_pairs
            .into_iter()
            .map(|rule| DependencyPair::from_rule(translate_rule_symbols(&rule, &symbols), 0))
            .collect::<Vec<_>>();
        if !same_pairs(&translated_weak, &problem.stats.weak_pairs)
            || minimal != problem.stats.minimal
        {
            return ProcessorResult::Inapplicable;
        }
        let same_rules = |source: &[crate::core::RewriteRule],
                          live: &[crate::core::RewriteRule]| {
            let translated = source
                .iter()
                .map(|rule| translate_rule_symbols(rule, &symbols))
                .collect::<Vec<_>>();
            super::same_rule_multiset(&translated, live)
        };
        let live_active = problem
            .stats
            .active_rules
            .as_deref()
            .unwrap_or_else(|| problem.trs.rules());
        let source_active = active_rules.as_deref().unwrap_or_else(|| trs.rules());
        if !same_rules(source_active, live_active)
            || !same_rules(&strict_rules, &problem.stats.strict_rules)
        {
            return ProcessorResult::Inapplicable;
        }
        let fragment = self.dp_proof_xml.trim();
        if !fragment.starts_with("<dpProof") || !fragment.ends_with("</dpProof>") {
            return ProcessorResult::Failed {
                reason: "malformed exact DP proof fragment".to_owned(),
            };
        }
        let Some(inner) = fragment
            .strip_prefix("<dpProof>")
            .and_then(|value| value.strip_suffix("</dpProof>"))
        else {
            return ProcessorResult::Failed {
                reason: "exact DP proof wrapper has attributes".to_owned(),
            };
        };
        ProcessorResult::Applied(ProcessorApplication::solved(
            ProblemCertificate::DependencyPairTree(DpProofTree::ExactXml(inner.trim().to_owned())),
        ))
    }
}

fn restore_retained_dp_strategy(
    mut witness_trs: Trs,
    live_strategy: RewriteStrategy,
    has_innermost_context: bool,
) -> Trs {
    if witness_trs.strategy() == RewriteStrategy::Full
        && live_strategy == RewriteStrategy::Innermost
        && has_innermost_context
    {
        witness_trs = Trs::new_with_strategy(
            witness_trs.name().map(str::to_owned),
            witness_trs.variables().clone(),
            witness_trs.rules().to_vec(),
            RewriteStrategy::Innermost,
        );
    }
    witness_trs
}

/// Recover the unique source-to-live signature isomorphism from the complete
/// TRSs, together with the corresponding source-rule permutation.
///
/// Exact transformation witnesses are stored under canonical oracle keys, so
/// their symbol names and rule order need not be the spelling used by the live
/// residual.  Treating those presentation choices as semantic made otherwise
/// valid certified witnesses inapplicable after a root was reconstructed.
pub(crate) fn portable_trs_isomorphism(
    source: &Trs,
    target: &Trs,
) -> Option<(BTreeMap<Symbol, Symbol>, BTreeMap<usize, usize>)> {
    if source.strategy() != target.strategy() {
        return None;
    }
    // Retained witnesses normally originate from the very runtime state on
    // which they are replayed.  Avoid canonicalizing a large, highly
    // symmetric TRS merely to rediscover the identity bijection: on the
    // transformed list benchmarks that search can dominate an otherwise
    // exact oracle replay for several minutes.
    if source.rules() == target.rules() {
        let mut symbols = BTreeMap::new();
        for symbol in source.arities().keys() {
            symbols.insert(symbol.clone(), symbol.clone());
            symbols.insert(
                Symbol::new(format!("{}#", symbol.as_str())),
                Symbol::new(format!("{}#", symbol.as_str())),
            );
        }
        symbols.insert(Symbol::new("__CSR_U0"), Symbol::new("__CSR_U0"));
        let rule_indices = (0..source.rules().len())
            .map(|index| (index, index))
            .collect();
        return Some((symbols, rule_indices));
    }
    if let Some(mut symbols) = super::general_red_pair::ordered_rule_pair_isomorphism(
        source.rules(),
        &[],
        target.rules(),
        &[],
    ) {
        for (source_symbol, target_symbol) in symbols.clone() {
            if source_symbol.as_str().ends_with('#') {
                continue;
            }
            symbols
                .entry(Symbol::new(format!("{}#", source_symbol.as_str())))
                .or_insert_with(|| Symbol::new(format!("{}#", target_symbol.as_str())));
        }
        symbols.insert(Symbol::new("__CSR_U0"), Symbol::new("__CSR_U0"));
        let rule_indices = (0..source.rules().len())
            .map(|index| (index, index))
            .collect();
        return Some((symbols, rule_indices));
    }
    // CPF and TPDB inputs can differ only in rule-local variable names and in
    // the standard numeric-symbol spelling (`0` versus `|0|`).  Recover that
    // obvious bijection in linear/quadratic time before invoking full
    // signature canonicalization, whose symmetry search is intentionally
    // general but unnecessarily expensive for large retained states.
    let normalized_name = |symbol: &Symbol| {
        let name = symbol.as_str();
        name.strip_prefix('|')
            .and_then(|inner| inner.strip_suffix('|'))
            .filter(|inner| inner.as_bytes().first().is_some_and(u8::is_ascii_digit))
            .unwrap_or(name)
            .to_owned()
    };
    let source_arities = source.arities();
    let target_arities = target.arities();
    let mut symbols = BTreeMap::new();
    let mut used_targets = BTreeSet::new();
    let direct_symbols = source_arities.iter().all(|(source_symbol, source_arity)| {
        let normalized = normalized_name(source_symbol);
        let mut matching = target_arities
            .iter()
            .filter(|(target_symbol, target_arity)| {
                *target_arity == source_arity && normalized_name(target_symbol) == normalized
            });
        let Some((target_symbol, _)) = matching.next() else {
            return false;
        };
        if matching.next().is_some() || !used_targets.insert(target_symbol.clone()) {
            return false;
        }
        symbols.insert(source_symbol.clone(), target_symbol.clone());
        symbols.insert(
            Symbol::new(format!("{}#", source_symbol.as_str())),
            Symbol::new(format!("{}#", target_symbol.as_str())),
        );
        true
    }) && used_targets.len() == target_arities.len();
    if direct_symbols {
        let translated = source
            .rules()
            .iter()
            .map(|rule| translate_rule_symbols(rule, &symbols))
            .collect::<Vec<_>>();
        let mut used_rules = BTreeSet::new();
        let rule_indices =
            translated
                .iter()
                .enumerate()
                .map(|(source_index, source_rule)| {
                    let target_index = target.rules().iter().enumerate().find_map(
                        |(target_index, target_rule)| {
                            (!used_rules.contains(&target_index)
                                && super::general_red_pair::alpha_equivalent_rules(
                                    source_rule,
                                    target_rule,
                                ))
                            .then_some(target_index)
                        },
                    )?;
                    used_rules.insert(target_index);
                    Some((source_index, target_index))
                })
                .collect::<Option<BTreeMap<_, _>>>();
        if let Some(rule_indices) = rule_indices {
            symbols.insert(Symbol::new("__CSR_U0"), Symbol::new("__CSR_U0"));
            return Some((symbols, rule_indices));
        }
    }
    let source_standardized = standardize_trs_with_bijection(source).ok()?;
    let target_standardized = standardize_trs_with_bijection(target).ok()?;
    if source_standardized.trs.rules() != target_standardized.trs.rules() {
        return None;
    }

    let mut symbols = BTreeMap::new();
    for (source_symbol, canonical_symbol) in &source_standardized.function_bijection {
        let target_symbol = target_standardized
            .inverse_function_bijection
            .get(canonical_symbol)?
            .clone();
        symbols.insert(source_symbol.clone(), target_symbol.clone());
        // CPF represents marked symbols as <sharp><name>f</name></sharp>, but
        // the internal term uses f#.  Keep both views synchronized.
        symbols.insert(
            Symbol::new(format!("{}#", source_symbol.as_str())),
            Symbol::new(format!("{}#", target_symbol.as_str())),
        );
    }
    // The improved-CSR unhiding symbol is pinned by the state serializer and
    // is intentionally independent of the source signature.
    symbols.insert(Symbol::new("__CSR_U0"), Symbol::new("__CSR_U0"));

    let source_to_canonical = source_standardized
        .rule_metadata
        .iter()
        .map(|metadata| (metadata.original_pair_index, metadata.canonical_pair_index))
        .collect::<BTreeMap<_, _>>();
    let canonical_to_target = target_standardized
        .rule_metadata
        .iter()
        .map(|metadata| (metadata.canonical_pair_index, metadata.original_pair_index))
        .collect::<BTreeMap<_, _>>();
    let rule_indices = source_to_canonical
        .into_iter()
        .map(|(source_index, canonical_index)| {
            Some((source_index, *canonical_to_target.get(&canonical_index)?))
        })
        .collect::<Option<BTreeMap<_, _>>>()?;
    Some((symbols, rule_indices))
}

fn translate_replacement_map(
    replacement_map: &ReplacementMap,
    symbols: &BTreeMap<Symbol, Symbol>,
) -> ReplacementMap {
    ReplacementMap::new(
        replacement_map
            .entries()
            .iter()
            .map(|(symbol, positions)| {
                (
                    symbols.get(symbol).unwrap_or(symbol).clone(),
                    positions.clone(),
                )
            })
            .collect(),
    )
}

fn escape_xml_text(text: &str) -> String {
    text.replace('&', "&amp;")
        .replace('<', "&lt;")
        .replace('>', "&gt;")
        .replace('"', "&quot;")
        .replace('\'', "&apos;")
}

/// Rename only CPF symbol-name elements.  Two passes through collision-free
/// placeholders prevent a permutation such as a -> b, b -> c from cascading.
pub(crate) fn translate_payload_symbols(
    payload: &str,
    symbols: &BTreeMap<Symbol, Symbol>,
) -> String {
    let changed_symbols = symbols
        .iter()
        .filter(|(source, target)| source != target)
        .collect::<Vec<_>>();
    if changed_symbols.is_empty() {
        return payload.to_owned();
    }
    fn parse_cpf_symbol(node: roxmltree::Node<'_, '_>) -> Option<String> {
        match node.tag_name().name() {
            "name" => node.text().map(str::trim).map(str::to_owned),
            "sharp" => {
                let child = node.children().find(roxmltree::Node::is_element)?;
                Some(format!("{}#", parse_cpf_symbol(child)?))
            }
            "labeledSymbol" => {
                let base = node.children().find(|child| {
                    child.is_element()
                        && matches!(child.tag_name().name(), "name" | "sharp" | "labeledSymbol")
                })?;
                if let Some(label) = node.children().find(|child| {
                    child.is_element() && child.tag_name().name() == "symbolLabel"
                }) {
                    let encode = |s: String| s.bytes().map(|b| format!("{b:02x}")).collect::<String>();
                    let labels = label.children().filter(roxmltree::Node::is_element)
                        .map(|child| parse_cpf_symbol(child).map(&encode))
                        .collect::<Option<Vec<_>>>()?.join("_");
                    return Some(format!("__ferrum_rl__{}__{labels}", encode(parse_cpf_symbol(base)?)));
                }
                let labels = node
                    .descendants()
                    .filter(|child| child.is_element() && child.tag_name().name() == "number")
                    .map(|child| child.text().unwrap_or_default().trim().to_owned())
                    .collect::<Vec<_>>()
                    .join("_");
                let encoded = parse_cpf_symbol(base)?
                    .bytes()
                    .map(|byte| format!("{byte:02x}"))
                    .collect::<String>();
                Some(format!("__ferrum_sl__{encoded}__{labels}"))
            }
            _ => None,
        }
    }

    fn serialize_cpf_symbol(symbol: &str) -> Option<String> {
        if symbol == "#" {
            return Some("<name>#</name>".to_owned());
        }
        if let Some(base) = symbol.strip_suffix('#') {
            return Some(format!("<sharp>{}</sharp>", serialize_cpf_symbol(base)?));
        }
        if let Some(rest) = symbol.strip_prefix("__ferrum_rl__") {
            let decode = |hex: &str| {
                if !hex.len().is_multiple_of(2) { return None; }
                String::from_utf8((0..hex.len()).step_by(2)
                    .map(|i| u8::from_str_radix(&hex[i..i + 2], 16).ok())
                    .collect::<Option<Vec<_>>>()?).ok()
            };
            let (base, labels) = rest.split_once("__")?;
            let labels = labels.split('_').filter(|label| !label.is_empty())
                .map(|label| serialize_cpf_symbol(&decode(label)?))
                .collect::<Option<Vec<_>>>()?.join("");
            return Some(format!("<labeledSymbol>{}<symbolLabel>{labels}</symbolLabel></labeledSymbol>",
                serialize_cpf_symbol(&decode(base)?)?));
        }
        if let Some(rest) = symbol.strip_prefix("__ferrum_sl__") {
            let (hex, labels) = rest.split_once("__")?;
            if !hex.len().is_multiple_of(2) {
                return None;
            }
            let bytes = (0..hex.len())
                .step_by(2)
                .map(|index| u8::from_str_radix(&hex[index..index + 2], 16).ok())
                .collect::<Option<Vec<_>>>()?;
            let base = String::from_utf8(bytes).ok()?;
            let numbers = labels
                .split('_')
                .filter(|label| !label.is_empty())
                .map(|label| format!("<number>{}</number>", escape_xml_text(label)))
                .collect::<String>();
            return Some(format!(
                "<labeledSymbol>{}<numberLabel>{numbers}</numberLabel></labeledSymbol>",
                serialize_cpf_symbol(&base)?
            ));
        }
        Some(format!("<name>{}</name>", escape_xml_text(symbol)))
    }

    // Rewrite complete CPF symbol nodes in one parsed pass.  The previous
    // marker implementation rescanned the full payload once per signature
    // symbol, which made a large exact GM04 witness quadratic in the number
    // of symbols (roughly half a second per SCC in release mode).
    let wrapped = format!("<ferrumCpfFragment>{payload}</ferrumCpfFragment>");
    let Ok(document) = roxmltree::Document::parse(&wrapped) else {
        return payload.to_owned();
    };
    // A local witness can retain interpretations for unused sibling symbols.
    // Extending a partial state isomorphism with identity on those symbols is
    // not injective: F# -> G# would collide with an unused original G# entry.
    // Freshen such symbols uniformly throughout the payload instead of
    // allowing two contradictory interpretations for one live symbol.
    let mut effective_symbols = symbols.clone();
    let source_symbols = document.descendants().filter(|node| node.is_element())
        .filter_map(parse_cpf_symbol).map(Symbol::new).collect::<BTreeSet<_>>();
    let targets = symbols.iter().filter(|(source, target)| source != target)
        .map(|(_, target)| target.clone()).collect::<BTreeSet<_>>();
    let mut occupied = source_symbols.clone();
    occupied.extend(symbols.values().cloned());
    let mut fresh_index = 0usize;
    for source in source_symbols {
        if effective_symbols.contains_key(&source) || !targets.contains(&source) { continue; }
        let fresh = loop {
            let candidate = Symbol::new(format!("__ferrum_unused_witness_{fresh_index}"));
            fresh_index += 1;
            if occupied.insert(candidate.clone()) { break candidate; }
        };
        effective_symbols.insert(source, fresh);
    }
    let prefix_len = "<ferrumCpfFragment>".len();
    let mut edits = document
        .descendants()
        .filter(|node| node.is_element())
        .filter(|node| match node.tag_name().name() {
            "labeledSymbol" => true,
            "sharp" => !node.ancestors().skip(1).any(|ancestor| {
                ancestor.is_element() && ancestor.tag_name().name() == "labeledSymbol"
            }),
            "name" => !node.ancestors().skip(1).any(|ancestor| {
                ancestor.is_element()
                    && matches!(ancestor.tag_name().name(), "sharp" | "labeledSymbol")
            }),
            _ => false,
        })
        .filter_map(|node| {
            let source = Symbol::new(parse_cpf_symbol(node)?);
            let target = effective_symbols.get(&source).cloned().or_else(|| {
                // A source CPF may spell a marked symbol structurally even
                // when the state isomorphism only needed to record the
                // corresponding unmarked alias.  In that case transport
                // the base alias and retain the mark.  An explicit f#
                // entry still wins, so marked and unmarked images remain
                // independent when both are present.
                let base = source.as_str().strip_suffix('#')?;
                let mapped = effective_symbols.get(&Symbol::new(base))?;
                Some(if mapped.as_str().ends_with('#') {
                    mapped.clone()
                } else {
                    Symbol::new(format!("{}#", mapped.as_str()))
                })
            })?;
            if target == source {
                return None;
            }
            let replacement = if node.tag_name().name() == "sharp"
                && let Some(target_base) = target.as_str().strip_suffix('#')
            {
                // Preserve the source wrapper's whitespace.  Besides keeping
                // retained payloads stable, this replaces only one compact
                // child range rather than rebuilding a possibly pretty-
                // printed `<sharp>` element.
                let child = node.children().find(roxmltree::Node::is_element)?;
                let node_range = node.range();
                let child_range = child.range();
                let mut replacement = wrapped[node_range.clone()].to_owned();
                replacement.replace_range(
                    (child_range.start - node_range.start)..(child_range.end - node_range.start),
                    &serialize_cpf_symbol(target_base)?,
                );
                replacement
            } else {
                serialize_cpf_symbol(target.as_str())?
            };
            let range = node.range();
            Some((
                (range.start - prefix_len)..(range.end - prefix_len),
                replacement,
            ))
        })
        .collect::<Vec<_>>();
    edits.sort_by_key(|(range, _)| std::cmp::Reverse(range.start));
    let mut translated = payload.to_owned();
    for (range, replacement) in edits {
        translated.replace_range(range, &replacement);
    }
    translated
}

fn same_pairs(state: &ProblemState, expected: &[crate::core::RewriteRule]) -> bool {
    let ProblemState::DependencyPairs(problem) = state else {
        return false;
    };
    if problem.pairs.len() != expected.len() {
        return false;
    }
    let mut used = vec![false; problem.pairs.len()];
    expected.iter().all(|rule| {
        let wanted = DependencyPair::from_rule(rule.clone(), 0);
        problem.pairs.iter().enumerate().any(|(index, pair)| {
            // CPF residual rules do not encode Ferrum's internal
            // `source_rule` provenance.  Comparing against `wanted` with its
            // fabricated source index 0 can reject the native result of a
            // perfectly matching transformation and force the exact-state
            // fallback.  That fallback necessarily crosses a serialized CPF
            // boundary and may lose the fresh variable spelling required by
            // the enclosing transformation proof.  Match the actual pair
            // rules here; provenance remains attached to the live native
            // result and is checked when reconstructing the processor step.
            if !used[index] && dependency_pair_rules_alpha_equivalent(pair, &wanted) {
                used[index] = true;
                true
            } else {
                false
            }
        })
    })
}

fn same_pair_sources(
    state: &ProblemState,
    expected: &[crate::core::RewriteRule],
    expected_sources: Option<&[usize]>,
) -> bool {
    let Some(expected_sources) = expected_sources else {
        return true;
    };
    let ProblemState::DependencyPairs(problem) = state else {
        return false;
    };
    if expected.len() != expected_sources.len() || problem.pairs.len() != expected.len() {
        return false;
    }
    let mut used = vec![false; problem.pairs.len()];
    expected
        .iter()
        .zip(expected_sources)
        .all(|(rule, source_rule)| {
            let wanted = DependencyPair::from_rule(rule.clone(), *source_rule);
            problem.pairs.iter().enumerate().any(|(index, pair)| {
                if !used[index]
                    && pair.source_rule() == *source_rule
                    && dependency_pair_rules_alpha_equivalent(pair, &wanted)
                {
                    used[index] = true;
                    true
                } else {
                    false
                }
            })
        })
}

fn preserve_live_pair_spellings(mapped: &mut [DependencyPair], live: &[DependencyPair]) {
    let mut used_live = vec![false; live.len()];
    for pair in mapped {
        if let Some((index, original)) = live.iter().enumerate().find(|(index, original)| {
            !used_live[*index] && dependency_pair_rules_alpha_equivalent(pair, original)
        }) {
            used_live[index] = true;
            *pair = original.clone();
        }
    }
}

/// Replace alpha-equivalent retained rule spellings by the literal live
/// rules.  CPF's rewriting processor checks that its displayed rewrite rule
/// is a member of the enclosing TRS syntactically, so carrying an archived
/// rule-local variable name (`y1` instead of live `y`) across an exact state
/// boundary produces an invalid certificate even though discovery correctly
/// treats the rules as variants.
fn restore_live_rule_spellings(
    retained: &[crate::core::RewriteRule],
    live: &[crate::core::RewriteRule],
) -> Option<Vec<crate::core::RewriteRule>> {
    if retained.len() != live.len() {
        return None;
    }
    let mut used = vec![false; live.len()];
    retained
        .iter()
        .map(|rule| {
            live.iter().enumerate().find_map(|(index, candidate)| {
                (!used[index] && super::general_red_pair::alpha_equivalent_rules(rule, candidate))
                    .then(|| {
                        used[index] = true;
                        candidate.clone()
                    })
            })
        })
        .collect()
}

/// Recover the typed CPF instantiation boundary from an exact residual.
///
/// Canonical training artifacts can rename marked DP symbols independently
/// of the underlying TRS signature.  Re-emitting their selected-rule payload
/// verbatim is therefore not portable.  The live parent and the already
/// retargeted child determine the same step without relying on those names:
/// exactly one parent pair is replaced by the residual's unmatched pairs.
fn derive_instantiation_step(
    parent: &[DependencyPair],
    child: &[DependencyPair],
    context_sensitive: bool,
) -> Option<DpInstantiationStep> {
    for removed_index in 0..parent.len() {
        let mut matched_child = vec![false; child.len()];
        let mut all_retained = true;
        for (parent_index, retained) in parent.iter().enumerate() {
            if parent_index == removed_index {
                continue;
            }
            let Some((child_index, _)) = child.iter().enumerate().find(|(index, candidate)| {
                !matched_child[*index] && dependency_pairs_alpha_equivalent(retained, candidate)
            }) else {
                all_retained = false;
                break;
            };
            matched_child[child_index] = true;
        }
        if !all_retained {
            continue;
        }
        let instantiations = child
            .iter()
            .enumerate()
            .filter(|(index, _)| !matched_child[*index])
            .map(|(_, pair)| pair.clone())
            .collect::<Vec<_>>();
        if instantiations.is_empty() {
            continue;
        }
        let mut reconstructed = parent
            .iter()
            .enumerate()
            .filter(|(index, _)| *index != removed_index)
            .map(|(_, pair)| pair.clone())
            .collect::<Vec<_>>();
        reconstructed.extend(instantiations.clone());
        let reconstructed = alpha_unique_pairs(reconstructed);
        if reconstructed.len() == child.len()
            && reconstructed.iter().all(|pair| {
                child
                    .iter()
                    .any(|candidate| dependency_pairs_alpha_equivalent(pair, candidate))
            })
        {
            return Some(DpInstantiationStep {
                pair: parent[removed_index].clone(),
                instantiations,
                context_sensitive,
            });
        }
    }
    None
}

/// Recover an exact retained instantiation while rebuilding internal source
/// provenance from the live parent.
///
/// CPF serializes dependency-pair rules, but not Ferrum's `source_rule`
/// field.  Older oracle states therefore contain placeholder (and sometimes
/// reordered) source indices.  Those indices must not decide whether the CPF
/// transformation applies.  Retained pairs keep their live provenance and
/// every newly instantiated pair inherits the selected live pair's source,
/// which is the provenance used by the native transformation processors.
fn derive_exact_instantiation_step(
    parent: &[DependencyPair],
    archived_child: &[DependencyPair],
    context_sensitive: bool,
    expected_selected: Option<&crate::core::RewriteRule>,
    expected_instantiations: Option<&[crate::core::RewriteRule]>,
) -> Option<(DpInstantiationStep, Vec<DependencyPair>)> {
    for removed_index in 0..parent.len() {
        if expected_selected.is_some_and(|selected| {
            !super::general_red_pair::alpha_equivalent_rules(
                selected,
                &parent[removed_index].as_rule(),
            )
        }) {
            continue;
        }
        if let Some(expected) = expected_instantiations {
            let source_rule = parent[removed_index].source_rule();
            let instantiations = expected
                .iter()
                .cloned()
                .map(|rule| DependencyPair::from_rule(rule, source_rule))
                .collect::<Vec<_>>();
            let mut normalized_child = parent
                .iter()
                .enumerate()
                .filter(|(index, _)| *index != removed_index)
                .map(|(_, pair)| pair.clone())
                .collect::<Vec<_>>();
            normalized_child.extend(instantiations.clone());
            // CeTA's next processor consumes the literal rule set printed
            // by this transformation. Alpha-equivalent rules with different
            // variable names are distinct members of that serialized set.
            // Do not silently remove one at the runtime/CPF boundary.
            let mut literal_child = Vec::new();
            for pair in normalized_child {
                if !literal_child.iter().any(|other: &DependencyPair|
                    other.lhs() == pair.lhs() && other.rhs() == pair.rhs()) {
                    literal_child.push(pair);
                }
            }
            let normalized_child = literal_child;
            let same_rule_set = |left: &[DependencyPair], right: &[DependencyPair]| {
                left.iter().all(|pair| {
                    right
                        .iter()
                        .any(|other| dependency_pair_rules_alpha_equivalent(pair, other))
                }) && right.iter().all(|pair| {
                    left.iter()
                        .any(|other| dependency_pair_rules_alpha_equivalent(pair, other))
                })
            };
            if same_rule_set(&normalized_child, archived_child) {
                return Some((
                    DpInstantiationStep {
                        pair: parent[removed_index].clone(),
                        instantiations,
                        context_sensitive,
                    },
                    normalized_child,
                ));
            }
            continue;
        }
        let mut normalized_child = archived_child.to_vec();
        let mut matched_child = vec![false; archived_child.len()];
        let mut all_retained = true;
        for (parent_index, retained) in parent.iter().enumerate() {
            if parent_index == removed_index {
                continue;
            }
            let Some((child_index, _)) =
                archived_child
                    .iter()
                    .enumerate()
                    .find(|(index, candidate)| {
                        !matched_child[*index]
                            && dependency_pair_rules_alpha_equivalent(retained, candidate)
                    })
            else {
                all_retained = false;
                break;
            };
            matched_child[child_index] = true;
            normalized_child[child_index] = retained.clone();
        }
        if !all_retained {
            continue;
        }
        let source_rule = parent[removed_index].source_rule();
        let instantiations = archived_child
            .iter()
            .enumerate()
            .filter(|(index, _)| !matched_child[*index])
            .map(|(index, pair)| {
                let normalized = DependencyPair::from_rule(pair.as_rule(), source_rule);
                normalized_child[index] = normalized.clone();
                normalized
            })
            .collect::<Vec<_>>();
        if instantiations.is_empty() {
            continue;
        }
        if expected_instantiations.is_some_and(|expected| {
            let actual = instantiations
                .iter()
                .map(DependencyPair::as_rule)
                .collect::<Vec<_>>();
            !super::general_red_pair::same_rule_multiset(expected, &actual)
        }) {
            continue;
        }
        // Dependency-pair problems are sets.  Some archived states retained
        // rule-identical pairs only because their stale source placeholders
        // differed.  Once provenance is rebuilt, normalize those accidental
        // duplicates exactly as the native processors do.
        let normalized_child = alpha_unique_pairs(normalized_child);
        let mut reconstructed = parent
            .iter()
            .enumerate()
            .filter(|(index, _)| *index != removed_index)
            .map(|(_, pair)| pair.clone())
            .collect::<Vec<_>>();
        reconstructed.extend(instantiations.clone());
        let reconstructed = alpha_unique_pairs(reconstructed);
        if reconstructed.len() == normalized_child.len()
            && reconstructed.iter().all(|pair| {
                normalized_child
                    .iter()
                    .any(|candidate| dependency_pairs_alpha_equivalent(pair, candidate))
            })
        {
            return Some((
                DpInstantiationStep {
                    pair: parent[removed_index].clone(),
                    instantiations,
                    context_sensitive,
                },
                normalized_child,
            ));
        }
    }
    None
}

/// CeTA's complete nontermination instantiation replaces P by P'. Every
/// displayed pair must be a simultaneous LHS/RHS instance of an original pair.
fn derive_nontermination_instantiations(
    parent: &[DependencyPair],
    child: &[DependencyPair],
    payload: &str,
) -> Option<Vec<DependencyPair>> {
    if child.is_empty() || !child.iter().all(|instance| parent.iter().any(|original| {
        let mut substitution = BTreeMap::new();
        match_term(original.lhs(), instance.lhs(), &mut substitution)
            && match_term(original.rhs(), instance.rhs(), &mut substitution)
    })) {
        return None;
    }
    let archived = crate::parsing::parse_cpf_rule_container_fragment(payload, "dps").ok()??;
    let added_rules = child
        .iter()
        .map(DependencyPair::as_rule)
        .collect::<Vec<_>>();
    super::general_red_pair::same_rule_multiset(&archived, &added_rules).then(|| child.to_vec())
}

fn derive_exact_forward_instantiation_step(
    problem: &crate::proving::DpProblemState,
    child: &[DependencyPair],
    payload: &str,
) -> Option<(DpForwardInstantiationStep, Vec<DependencyPair>)> {
    let trace = |reason: &str| {
        if std::env::var_os("FERRUM_EXACT_REPLAY_TIMING").is_some() {
            eprintln!("exact-forward-instantiation reconstruction rejected: {reason}");
        }
    };
    let wrapped = format!("<ferrumCpfFragment>{payload}</ferrumCpfFragment>");
    let document = roxmltree::Document::parse(&wrapped).ok()?;
    let root = document.root_element();
    let selected_node = root
        .children()
        .find(|node| node.is_element() && node.tag_name().name() == "rule")?;
    let selected_xml = &wrapped[selected_node.range()];
    let selected_container = format!("<dps><rules>{selected_xml}</rules></dps>");
    let selected = crate::parsing::parse_cpf_rule_container_fragment(&selected_container, "dps")
        .ok()??
        .into_iter()
        .next()?;
    let archived_instantiations =
        crate::parsing::parse_cpf_rule_container_fragment(payload, "instantiations").ok()??;
    let Some((generic, normalized_child)) = derive_exact_instantiation_step(
        &problem.pairs,
        child,
        matches!(problem.stats.problem, DpProblemContext::ContextSensitive(_)),
        Some(&selected),
        Some(&archived_instantiations),
    ) else {
        trace("residual is not one retained-pairs-plus-instantiations replacement");
        return None;
    };
    if !super::general_red_pair::alpha_equivalent_rules(&selected, &generic.pair.as_rule()) {
        trace("payload selected pair differs from reconstructed live pair");
        return None;
    }
    let live_instantiations = generic
        .instantiations
        .iter()
        .map(DependencyPair::as_rule)
        .collect::<Vec<_>>();
    if !super::general_red_pair::same_rule_multiset(&archived_instantiations, &live_instantiations)
    {
        trace("payload instantiations differ from reconstructed residual pairs");
        return None;
    }

    let archived_usable =
        crate::parsing::parse_cpf_rule_container_fragment(payload, "usableRules").ok()?;
    let input_rules = if problem.stats.active_rules_are_residual {
        problem
            .stats
            .active_rules
            .as_deref()
            .unwrap_or(problem.trs.rules())
    } else {
        problem
            .stats
            .transformation_rules
            .as_deref()
            .or(problem.stats.active_rules.as_deref())
            .unwrap_or(problem.trs.rules())
    };
    let usable_rules = if let Some(archived) = archived_usable.as_ref() {
        let mut used = vec![false; input_rules.len()];
        archived
            .iter()
            .map(|rule| {
                input_rules.iter().enumerate().find_map(|(index, live)| {
                    (!used[index] && super::general_red_pair::alpha_equivalent_rules(rule, live))
                        .then(|| {
                            used[index] = true;
                            live.clone()
                        })
                })
            })
            .collect::<Option<Vec<_>>>()?
    } else {
        Vec::new()
    };
    let step = DpForwardInstantiationStep {
        pair: generic.pair,
        instantiations: generic.instantiations,
        usable_rules,
        uses_usable_rules: archived_usable.is_some(),
    };
    if !validate_forward_instantiation_step(
        &problem.trs,
        &problem.pairs,
        &step,
        problem.innermost_lhss.as_deref().unwrap_or(&[]),
        input_rules,
    ) {
        trace("executable forward-instantiation coverage check failed");
        return None;
    }
    Some((step, normalized_child))
}

fn derive_exact_instantiation_from_payload(
    problem: &crate::proving::DpProblemState,
    child: &[DependencyPair],
    payload: &str,
) -> Option<(DpInstantiationStep, Vec<DependencyPair>)> {
    let wrapped = format!("<ferrumCpfFragment>{payload}</ferrumCpfFragment>");
    let document = roxmltree::Document::parse(&wrapped).ok()?;
    let root = document.root_element();
    let selected_node = root
        .children()
        .find(|node| node.is_element() && node.tag_name().name() == "rule")?;
    let selected_xml = &wrapped[selected_node.range()];
    let selected_container = format!("<dps><rules>{selected_xml}</rules></dps>");
    let selected = crate::parsing::parse_cpf_rule_container_fragment(&selected_container, "dps")
        .ok()??
        .into_iter()
        .next()?;
    let archived_instantiations =
        crate::parsing::parse_cpf_rule_container_fragment(payload, "instantiations").ok()??;
    let result = derive_exact_instantiation_step(
        &problem.pairs,
        child,
        matches!(problem.stats.problem, DpProblemContext::ContextSensitive(_)),
        Some(&selected),
        Some(&archived_instantiations),
    )?;
    if matches!(problem.stats.problem, DpProblemContext::Ordinary) {
        // Matching the selected rule and child set is not sufficient: every
        // displayed rule must be an instance, and incoming chains must be
        // covered. Reuse the native CeTA-style criterion before constructing
        // a standalone exact step, rather than deferring this to root CeTA.
        let rules = if problem.stats.active_rules_are_residual {
            problem.stats.active_rules.as_deref().unwrap_or(problem.trs.rules())
        } else {
            problem.trs.rules()
        };
        let default_q = (problem.trs.strategy() == RewriteStrategy::Innermost
            && problem.innermost_lhss.is_none()).then(|| rules.iter().map(|rule| rule.lhs().clone()).collect::<Vec<_>>());
        let q = problem.innermost_lhss.as_deref().or(default_q.as_deref()).unwrap_or(&[]);
        if !q_instantiation_ceta_coverage_holds(&problem.pairs, &result.0.pair,
            &result.0.instantiations, q, rules) {
            return None;
        }
    } else if let DpProblemContext::ContextSensitive(context) = &problem.stats.problem {
        if !csr_instantiation_coverage_holds(
            &context.csr, &problem.pairs, &result.0.pair, &result.0.instantiations,
            problem.stats.active_rules.as_deref().unwrap_or(problem.trs.rules()),
        ) {
            return None;
        }
    }
    Some(result)
}

/// Reconstruct a retained CPF narrowing step beyond the generic search cap.
///
/// CPF records the selected pair, position, and the complete narrowing set.
/// Recompute that set from the live parent and require exact alpha-multiset
/// agreement with both the payload and retained child.  This is the same
/// independently checked processor boundary as native narrowing; it merely
/// avoids treating Ferrum's portfolio bound (normally eight alternatives) as
/// a semantic limit on a certified step (LengthOfFiniteLists needs thirteen).
fn derive_exact_narrowing_step(
    problem: &crate::proving::DpProblemState,
    child: &[DependencyPair],
    payload: &str,
) -> Option<(DpNarrowingStep, Vec<DependencyPair>)> {
    let trace = |reason: &str| {
        if std::env::var_os("FERRUM_EXACT_REPLAY_TIMING").is_some() {
            eprintln!("exact-narrowing reconstruction rejected: {reason}");
        }
    };
    let wrapped = format!("<ferrumCpfFragment>{payload}</ferrumCpfFragment>");
    let document = roxmltree::Document::parse(&wrapped).ok()?;
    let root = document.root_element();
    let selected_node = root
        .children()
        .find(|node| node.is_element() && node.tag_name().name() == "rule")?;
    let selected_xml = &wrapped[selected_node.range()];
    let selected_container = format!("<dps><rules>{selected_xml}</rules></dps>");
    let archived_selected =
        crate::parsing::parse_cpf_rule_container_fragment(&selected_container, "dps")
            .ok()??
            .into_iter()
            .next()?;
    let archived_narrowings =
        crate::parsing::parse_cpf_rule_container_fragment(payload, "narrowings").ok()??;
    let (generic, literal_child) = derive_exact_instantiation_step(
        &problem.pairs, child, false, Some(&archived_selected), Some(&archived_narrowings))?;
    if !super::general_red_pair::alpha_equivalent_rules(&archived_selected, &generic.pair.as_rule())
    {
        trace("payload selected pair differs from reconstructed live pair");
        return None;
    }
    let position_node = root
        .descendants()
        .find(|node| node.is_element() && node.tag_name().name() == "positionInTerm")?;
    let position = position_node
        .children()
        .filter(|node| node.is_element() && node.tag_name().name() == "position")
        .map(|node| node.text()?.trim().parse::<usize>().ok())
        .collect::<Option<Vec<_>>>()?;
    let child_narrowings = generic
        .instantiations
        .iter()
        .map(DependencyPair::as_rule)
        .collect::<Vec<_>>();
    if !super::general_red_pair::same_rule_multiset(&archived_narrowings, &child_narrowings) {
        trace("payload narrowing set differs from retained child");
        return None;
    }
    if match problem.trs.strategy() {
        RewriteStrategy::Innermost => false,
        RewriteStrategy::Full => !q_covers_active_rule_lhss(problem) && !term_is_linear(generic.pair.rhs()),
        RewriteStrategy::Outermost => true,
    } {
        trace("live selected pair violates narrowing strategy side conditions");
        return None;
    }
    let default_q = (problem.trs.strategy() == RewriteStrategy::Innermost
        && problem.innermost_lhss.is_none())
    .then(|| {
        problem
            .trs
            .rules()
            .iter()
            .map(|rule| rule.lhs().clone())
            .collect::<Vec<_>>()
    });
    let q_lhss = problem
        .innermost_lhss
        .as_deref()
        .or(default_q.as_deref())
        .unwrap_or_default();
    let active_trs = Trs::new_with_strategy(
        problem.trs.name().map(str::to_owned), problem.trs.variables().clone(),
        problem.stats.active_rules.clone().unwrap_or_else(|| problem.trs.rules().to_vec()),
        if q_covers_active_rule_lhss(problem) { RewriteStrategy::Innermost } else { problem.trs.strategy() },
    );
    if !narrowing_position_is_admissible(
        &active_trs,
        &generic.pair,
        &position,
        &problem.pairs,
        q_lhss,
    ) || !narrowing_position_is_ceta_q_admissible(&active_trs, &generic.pair, &position, q_lhss)
    {
        trace("payload position violates the live CeTA narrowing side conditions");
        return None;
    }
    let native = narrow_pair_at_position(
        &generic.pair,
        &position,
        active_trs.rules(),
        q_lhss,
        usize::MAX,
    )?;
    let native_rules = native
        .iter()
        .map(DependencyPair::as_rule)
        .collect::<Vec<_>>();
    if !super::general_red_pair::same_rule_multiset(&native_rules, &child_narrowings) {
        trace("live narrowing result differs from the retained child");
        return None;
    }
    Some((DpNarrowingStep {
        pair: generic.pair,
        position,
        // The native recomputation above establishes the narrowing set modulo
        // alpha-renaming.  CPF's following graph decomposition, however,
        // consumes these rules syntactically.  Emit the already validated
        // retained-child spellings so the processor result and recursive
        // child form one literal state boundary rather than two alpha-equal
        // but context-losing serializations.
        narrowings: generic.instantiations,
    }, literal_child))
}

/// A full-labelled QDP can nevertheless require innermost steps: including
/// every active R left-hand side in Q entails NF(Q) subset NF(R). Keep this
/// semantic test separate from the TRS strategy label and preserve Q itself.
fn q_covers_active_rule_lhss(problem: &crate::proving::DpProblemState) -> bool {
    if problem.trs.strategy() == RewriteStrategy::Outermost
        || !matches!(problem.stats.problem, DpProblemContext::Ordinary) { return false; }
    let Some(q) = problem.innermost_lhss.as_deref() else { return false };
    problem.stats.active_rules.as_deref().unwrap_or(problem.trs.rules()).iter().all(|rule| {
        !crate::proving::dependency_pairs::term_is_q_normal(rule.lhs(), q)
    })
}

impl WorklistProcessor for ExactDpTransformationProcessor {
    fn name(&self) -> &'static str {
        "exact-dependency-pair-transformation"
    }

    fn apply(&self, state: &ProblemState) -> ProcessorResult {
        if let Some(source) = &self.source_dp_input_xml {
            let ProblemState::DependencyPairs(problem) = state else { return ProcessorResult::Inapplicable };
            let Some(symbols) = super::exact_context::source_dp_symbol_isomorphism(source, problem) else {
                return ProcessorResult::Inapplicable;
            };
            return Self {
                source_dp_input_xml: None,
                processor_tag: self.processor_tag.clone(),
                payload_xml: translate_payload_symbols(&self.payload_xml, &symbols),
                dp_input_xml: translate_payload_symbols(&self.dp_input_xml, &symbols),
            }.apply(state);
        }
        if self.processor_tag == "innermostLhssRemovalProcNontermination" {
            return super::nontermination::reduce_innermost_lhss(state, &self.payload_xml);
        }
        if self.processor_tag == "forwardInstantiationProcDirect" {
            // Explicit replay policy, not a different proof rule. Keep the
            // exact reconstruction's residual representation independent of
            // whether bounded native discovery happens to finish first.
            let normalized = Self {
                source_dp_input_xml: None,
                processor_tag: "forwardInstantiationProc".to_owned(),
                payload_xml: self.payload_xml.clone(),
                dp_input_xml: self.dp_input_xml.clone(),
            };
            return normalized.apply_with_forward_policy(state, true);
        }
        self.apply_with_forward_policy(state, false)
    }
}

impl ExactDpTransformationProcessor {
    fn apply_with_forward_policy(&self, state: &ProblemState, direct_forward: bool) -> ProcessorResult {
        let Ok(witness) = parse_cpf_input(None, &self.dp_input_xml) else {
            return ProcessorResult::Failed {
                reason: "invalid exact DP transformation residual".to_owned(),
            };
        };
        let (
            mut witness_trs,
            mut pairs,
            pair_source_rules,
            mut active_rules,
            mut innermost_lhss,
            clear_innermost_lhss,
            witness_csr_context,
        ) = match witness {
            CpfInputProblem::Dp {
                trs,
                pairs,
                pair_source_rules,
                active_rules,
                innermost_lhss,
                clear_innermost_lhss,
                ..
            } => (
                trs,
                pairs,
                pair_source_rules,
                active_rules,
                innermost_lhss,
                clear_innermost_lhss,
                None,
            ),
            CpfInputProblem::CsrDp {
                csr,
                pairs,
                pair_source_rules,
                active_rules,
                construction,
                graph_estimator,
                use_qcs_usable_rules,
                innermost_lhss,
                clear_innermost_lhss,
                ..
            } => {
                let witness_trs = csr.trs().clone();
                (
                    witness_trs,
                    pairs,
                    pair_source_rules,
                    active_rules,
                    innermost_lhss,
                    clear_innermost_lhss,
                    Some((
                        csr.replacement_map().clone(),
                        construction,
                        graph_estimator,
                        use_qcs_usable_rules,
                    )),
                )
            }
            _ => {
                return ProcessorResult::Failed {
                    reason: "invalid exact DP transformation residual".to_owned(),
                };
            }
        };
        let ProblemState::DependencyPairs(problem) = state else {
            return ProcessorResult::Inapplicable;
        };
        // A standalone CPF `<dpInput>` has no strategy tag.  Proof-chain
        // extraction records the otherwise implicit innermost Q obligation
        // as `innermostLhss` in the typed state context.  Reconstruct that
        // strategy before comparing the retained state with a live child of
        // `switchInnermostProc`; the rules themselves remain unchanged.
        witness_trs = restore_retained_dp_strategy(
            witness_trs,
            problem.trs.strategy(),
            innermost_lhss.is_some(),
        );
        let direct_isomorphism = portable_trs_isomorphism(&witness_trs, &problem.trs);
        let residual_isomorphism = problem
            .stats
            .active_rules_are_residual
            .then(|| problem.stats.active_rules.as_deref())
            .flatten()
            .and_then(|active_rules| {
                let active_trs = Trs::new_with_strategy(
                    problem.trs.name().map(str::to_owned),
                    problem.trs.variables().clone(),
                    active_rules.to_vec(),
                    problem.trs.strategy(),
                );
                portable_trs_isomorphism(&witness_trs, &active_trs).map(
                    |(symbol_aliases, active_rule_aliases)| {
                        // The retained CPF child numbers source rules in its
                        // explicit residual R, whereas Ferrum deliberately
                        // keeps the original TRS as the innermost Q context
                        // and stores R in `active_rules`.  Translate the
                        // residual-local rule permutation back to original-R
                        // indices so narrowing/instantiation descendants keep
                        // their live source identities.
                        let source_rule_aliases = active_rule_aliases
                            .into_iter()
                            .filter_map(|(source_index, active_index)| {
                                let active_rule = active_rules.get(active_index)?;
                                problem
                                    .trs
                                    .rules()
                                    .iter()
                                    .position(|rule| {
                                        super::general_red_pair::alpha_equivalent_rules(
                                            active_rule,
                                            rule,
                                        )
                                    })
                                    .map(|original_index| (source_index, original_index))
                            })
                            .collect();
                        (symbol_aliases, source_rule_aliases)
                    },
                )
            });
        let Some((mut symbol_aliases, source_rule_aliases)) =
            direct_isomorphism.or(residual_isomorphism)
        else {
            if std::env::var_os("FERRUM_EXACT_REPLAY_TIMING").is_some() {
                eprintln!(
                    "exact-transformation TRS mismatch witness_rules={} witness_strategy={:?} live_rules={} live_strategy={:?} active_rules={} active_residual={}",
                    witness_trs.rules().len(),
                    witness_trs.strategy(),
                    problem.trs.rules().len(),
                    problem.trs.strategy(),
                    problem.stats.active_rules.as_deref().map_or(0, <[_]>::len),
                    problem.stats.active_rules_are_residual,
                );
            }
            return ProcessorResult::Failed {
                reason: "exact DP transformation residual changes the live TRS".to_owned(),
            };
        };
        // Rule deletion can leave R empty while numeric symbols survive in P.
        // Bind the CPF/ARI quoting aliases against the live pair signature,
        // not just R, and only when both spellings are unambiguous.
        let source_signature = Trs::new(None, BTreeSet::new(), pairs.clone()).arities();
        let target_signature = Trs::new(None, BTreeSet::new(),
            problem.pairs.iter().map(DependencyPair::as_rule).collect()).arities();
        let numeric = |symbol: &Symbol| {
            let name = symbol.as_str();
            let inner = name.strip_prefix('|').and_then(|s| s.strip_suffix('|')).unwrap_or(name);
            (!inner.is_empty() && inner.bytes().all(|b| b.is_ascii_digit())).then(|| inner.to_owned())
        };
        for (symbol, arity) in &source_signature {
            if symbol_aliases.contains_key(symbol) { continue; }
            let Some(name) = numeric(symbol) else { continue; };
            if source_signature.keys().filter(|s| numeric(s).as_ref() == Some(&name)).count() != 1 { continue; }
            let matches = target_signature.iter().filter(|(s, a)|
                *a == arity && numeric(s).as_ref() == Some(&name)).collect::<Vec<_>>();
            if let [(target, _)] = matches.as_slice() {
                symbol_aliases.insert(symbol.clone(), (*target).clone());
            }
        }
        let translated_payload = translate_payload_symbols(&self.payload_xml, &symbol_aliases);
        if self.processor_tag == "complexConstantRemovalProc" {
            return super::complex_constant_removal::apply(state, &translated_payload);
        }
        if self.processor_tag == "innermostLhssIncreaseProc" {
            return super::nontermination::increase_innermost_lhss(state, &translated_payload);
        }
        let context_matches = match (&witness_csr_context, &problem.stats.problem) {
            (None, DpProblemContext::Ordinary) => true,
            (
                Some((replacement_map, construction, graph_estimator, use_qcs_usable_rules)),
                DpProblemContext::ContextSensitive(context),
            ) => {
                translate_replacement_map(replacement_map, &symbol_aliases)
                    == *context.csr.replacement_map()
                    && context.construction.as_str() == construction
                    && context.graph_estimator.as_str() == graph_estimator
                    && context.use_qcs_usable_rules == *use_qcs_usable_rules
            }
            _ => false,
        };
        if !context_matches {
            return ProcessorResult::Failed {
                reason: "exact DP transformation residual changes the DP proof context".to_owned(),
            };
        }
        pairs = pairs
            .into_iter()
            .map(|rule| translate_rule_symbols(&rule, &symbol_aliases))
            .collect();
        active_rules = active_rules.map(|rules| {
            rules
                .into_iter()
                .map(|rule| translate_rule_symbols(&rule, &symbol_aliases))
                .collect()
        });
        if let Some(retained_active) = active_rules.take() {
            let live_active = problem
                .stats
                .active_rules
                .as_deref()
                .unwrap_or(problem.trs.rules());
            let Some(restored) = restore_live_rule_spellings(&retained_active, live_active) else {
                return ProcessorResult::Failed {
                    reason: "exact DP transformation changes the active rewrite rules".to_owned(),
                };
            };
            active_rules = Some(restored);
        }
        innermost_lhss = innermost_lhss.map(|terms| {
            terms
                .into_iter()
                .map(|term| crate::standardize::translate_term_symbols(&term, &symbol_aliases))
                .collect()
        });
        let pair_source_rules = pair_source_rules.map(|sources| {
            sources
                .into_iter()
                .map(|source| source_rule_aliases.get(&source).copied().unwrap_or(source))
                .collect::<Vec<_>>()
        });
        let max_candidates = match self.processor_tag.as_str() {
            "rewritingProc" => 128,
            // Complete NO instantiation supplies the entire replacement P'.
            // Termination candidate enumeration cannot recover this boundary;
            // use the independently checked simultaneous instances below.
            "instantiationProc" if translated_payload.trim_start().starts_with("<dps>") => 0,
            "narrowingProc" | "instantiationProc" => 128,
            // Retain native residual serialization/provenance where cheaply
            // available. Bound discovery across all candidates, then use the
            // checked exact reconstruction below for expensive chains.
            "forwardInstantiationProc" => if direct_forward { 0 } else { 128 },
            _ => return ProcessorResult::Inapplicable,
        };
        let forward_deadline = std::time::Instant::now() + std::time::Duration::from_millis(500);
        for candidate_index in 0..max_candidates {
            if self.processor_tag == "forwardInstantiationProc"
                && std::time::Instant::now() >= forward_deadline
            {
                break;
            }
            let result = match self.processor_tag.as_str() {
                "rewritingProc" => RewritingProcessor {
                    max_per_pair: Some(2),
                    candidate_index,
                    deadline: None,
                }
                .apply(state),
                "narrowingProc" => NarrowingProcessor {
                    // Certified tools may retain more alternatives for one
                    // selected pair than the generic portfolio. Native
                    // applicability plus the exact child comparison below
                    // still guards this transition.
                    max_per_pair: Some(8),
                    candidate_index,
                    require_depth_bound: false,
                    deadline: None,
                }
                .apply(state),
                "instantiationProc" => InstantiationProcessor {
                    max_per_pair: Some(2),
                    candidate_index,
                    require_depth_bound: false,
                    deadline: None,
                }
                .apply(state),
                "forwardInstantiationProc" => ForwardInstantiationProcessor {
                    max_per_pair: Some(2),
                    candidate_index,
                    require_depth_bound: false,
                    require_graph_progress: false,
                    deadline: Some(forward_deadline),
                }
                .apply(state),
                _ => unreachable!(),
            };
            match result {
                ProcessorResult::Applied(application)
                    if application.residuals.len() == 1
                        && same_pairs(&application.residuals[0], &pairs)
                        && same_pair_sources(
                            &application.residuals[0],
                            &pairs,
                            pair_source_rules.as_deref(),
                        )
                        // Innermost rewriting carries source-rule provenance
                        // that is not part of CPF's rule multiset.  A newly
                        // enumerated alpha-equivalent candidate can therefore
                        // select the right rules with the wrong provenance and
                        // strand the certified continuation.  Reconstruct the
                        // retained rewrite below, where its rule, position,
                        // parent, and child are all checked explicitly.
                        && !(self.processor_tag == "rewritingProc"
                            && (problem.trs.strategy()
                                == crate::core::RewriteStrategy::Innermost
                                || problem.innermost_lhss.is_some())) =>
                {
                    return ProcessorResult::Applied(application);
                }
                ProcessorResult::Inapplicable if candidate_index > 0 => break,
                ProcessorResult::TimedOut if self.processor_tag == "forwardInstantiationProc" => break,
                ProcessorResult::TimedOut => return ProcessorResult::TimedOut,
                _ => {}
            }
        }

        // Some externally certified transformations are more complete than
        // Ferrum's bounded candidate generators.  We may still materialize
        // their exact residual when the live parent and retained child let us
        // independently reconstruct the state boundary below.
        //
        // For rewriting, this is deliberately a single certified processor
        // step rather than opaque whole-proof replay.  CeTA's rewriting
        // processor accepts joinable/trivial innermost critical pairs;
        // Ferrum's generic discovery currently uses the stricter sufficient
        // condition that usable-rule left-hand sides do not overlap at all.
        // Requiring an innermost source, no weak pairs, and an exact one-pair
        // replacement keeps the retained step attached to the correct typed
        // state while the final CPF contains the original CeTA-checkable
        // payload verbatim (modulo the proven signature isomorphism).
        if !matches!(
            self.processor_tag.as_str(),
            "narrowingProc" | "instantiationProc" | "forwardInstantiationProc" | "rewritingProc"
        ) {
            return ProcessorResult::Inapplicable;
        }
        let mut used_sources = vec![false; problem.pairs.len()];
        let mut mapped = pairs
            .into_iter()
            .enumerate()
            .map(|(witness_index, rule)| {
                let wanted = DependencyPair::from_rule(rule.clone(), 0);
                let source_rule = pair_source_rules
                    .as_ref()
                    .and_then(|sources| sources.get(witness_index).copied())
                    .or_else(|| {
                        problem
                            .pairs
                            .iter()
                            .enumerate()
                            .find(|(index, pair)| {
                                !used_sources[*index]
                                    && dependency_pairs_alpha_equivalent(pair, &wanted)
                            })
                            .map(|(index, pair)| {
                                used_sources[index] = true;
                                pair.source_rule()
                            })
                    })
                    .unwrap_or(0);
                DependencyPair::from_rule(rule, source_rule)
            })
            .collect::<Vec<_>>();
        // A retained CPF state may spell variables differently from the live
        // state.  That is semantically harmless, but CeTA's transformation
        // result and the following dependency-graph decomposition use
        // syntactic list membership.  Keep every alpha-equivalent retained
        // pair byte-for-byte live and use the archived spelling only for
        // genuinely new transformed pairs.
        preserve_live_pair_spellings(&mut mapped, &problem.pairs);
        if mapped == problem.pairs {
            return ProcessorResult::Inapplicable;
        }
        if self.processor_tag == "rewritingProc" {
            if (problem.trs.strategy() != crate::core::RewriteStrategy::Innermost
                && !q_covers_active_rule_lhss(problem))
                || !problem.stats.weak_pairs.is_empty()
            {
                return ProcessorResult::Inapplicable;
            }
            let Some((native_rewriting, native_pairs)) =
                derive_exact_rewriting_step(problem, &mapped, &translated_payload)
            else {
                return ProcessorResult::Inapplicable;
            };
            let mut child = problem.clone();
            child.pairs = native_pairs;
            if active_rules.is_some() {
                child.stats.active_rules = active_rules;
            }
            if clear_innermost_lhss {
                child.innermost_lhss = None;
            } else if innermost_lhss.is_some() {
                child.innermost_lhss = innermost_lhss;
            }
            let no_rewriting = native_rewriting.clone();
            return ProcessorResult::Applied(ProcessorApplication::new(
                vec![ProblemState::DependencyPairs(child)],
                move |children| {
                    let [ProblemCertificate::DependencyPairTree(proof)] =
                        <[ProblemCertificate; 1]>::try_from(children).ok()?
                    else {
                        return None;
                    };
                    Some(ProblemCertificate::DependencyPairTree(
                        DpProofTree::Rewriting {
                            step: Box::new(native_rewriting.clone()),
                            proof: Box::new(proof),
                        },
                    ))
                },
            ).with_child_short_circuit(move |certificate| {
                let ProblemCertificate::DependencyPairNontermination(proof) = certificate else { return None };
                Some(ProblemCertificate::DependencyPairNontermination(
                    crate::proving::DpNonterminationProof::Rewriting {
                        step: Box::new(crate::proving::DpRewriteProof {
                            original_pair: no_rewriting.original_pair.clone(),
                            rewrite_step: no_rewriting.rewrite_step.clone(),
                            rewritten_pair: no_rewriting.rewritten_pair.clone(),
                            usable_rules: no_rewriting.usable_rules.clone(),
                            proof: Box::new(proof.clone()),
                        }),
                    }))
            }));
        }
        let native_forward = (self.processor_tag == "forwardInstantiationProc")
            .then(|| derive_exact_forward_instantiation_step(problem, &mapped, &translated_payload))
            .flatten();
        // The retained child alone is not an adequate instantiation witness:
        // for a singleton SCC, replacing its sole pair by any unrelated pair
        // has the same set shape.  Bind the transition to CPF's selected pair
        // and displayed instances.  Otherwise an oracle alias from a sibling
        // SCC can execute locally yet only be rejected when CeTA checks the
        // reconstructed whole proof.
        let native_instantiation = (self.processor_tag == "instantiationProc")
            .then(|| derive_exact_instantiation_from_payload(problem, &mapped, &translated_payload))
            .flatten();
        let nontermination_instantiation = (self.processor_tag == "instantiationProc")
            .then(|| {
                if problem.stats.normal_form_substitutions
                    && problem.innermost_lhss.as_ref().is_some_and(|q| !q.is_empty()) {
                    return None;
                }
                derive_nontermination_instantiations(&problem.pairs, &mapped, &translated_payload)
            })
            .flatten();
        let native_narrowing = (self.processor_tag == "narrowingProc")
            .then(|| derive_exact_narrowing_step(problem, &mapped, &translated_payload))
            .flatten();
        if native_forward.is_none()
            && native_instantiation.is_none()
            && nontermination_instantiation.is_none()
            && native_narrowing.is_none()
        {
            return ProcessorResult::Inapplicable;
        }
        let mut child = problem.clone();
        if nontermination_instantiation.is_some() && native_instantiation.is_none() {
            child.stats.minimal = false;
        }
        child.pairs = native_forward
            .as_ref()
            .map(|(_, normalized_child)| normalized_child.clone())
            .or_else(|| {
                native_instantiation
                    .as_ref()
                    .map(|(_, normalized_child)| normalized_child.clone())
            })
            .or_else(|| native_narrowing.as_ref().map(|(_, child)| child.clone()))
            .unwrap_or(mapped);
        if active_rules.is_some() {
            child.stats.active_rules = active_rules;
        }
        if clear_innermost_lhss {
            child.innermost_lhss = None;
        } else if innermost_lhss.is_some() {
            child.innermost_lhss = innermost_lhss;
        }
        let nontermination_instantiations = nontermination_instantiation.or_else(|| {
            native_instantiation
                .as_ref()
                .filter(|_| !problem.stats.normal_form_substitutions
                    || problem.innermost_lhss.as_ref().is_none_or(Vec::is_empty))
                .map(|_| child.pairs.clone())
        });
        let nontermination_narrowing = native_narrowing.as_ref().map(|(step, _)| step.clone());
        ProcessorResult::Applied(
            ProcessorApplication::new(
                vec![ProblemState::DependencyPairs(child)],
                move |children| {
                    let [ProblemCertificate::DependencyPairTree(proof)] =
                        <[ProblemCertificate; 1]>::try_from(children).ok()?
                    else {
                        return None;
                    };
                    Some(ProblemCertificate::DependencyPairTree(
                        if let Some((step, _)) = &native_forward {
                            DpProofTree::ForwardInstantiation {
                                step: step.clone(),
                                proof: Box::new(proof),
                            }
                        } else if let Some((step, _)) = &native_instantiation {
                            DpProofTree::Instantiation {
                                step: step.clone(),
                                proof: Box::new(proof),
                            }
                        } else {
                            DpProofTree::Narrowing {
                                step: native_narrowing.as_ref()?.0.clone(),
                                proof: Box::new(proof),
                            }
                        },
                    ))
                },
            )
            .with_child_short_circuit(move |certificate| {
                let ProblemCertificate::DependencyPairNontermination(proof) = certificate else {
                    return None;
                };
                if let Some(instantiated_pairs) = &nontermination_instantiations {
                    return Some(ProblemCertificate::DependencyPairNontermination(
                        crate::proving::DpNonterminationProof::Instantiation {
                            instantiated_pairs: instantiated_pairs.clone(),
                            proof: Box::new(proof.clone()),
                        },
                    ));
                }
                nontermination_narrowing.as_ref().map(|step| {
                    ProblemCertificate::DependencyPairNontermination(
                        crate::proving::DpNonterminationProof::Narrowing {
                            step: step.clone(),
                            proof: Box::new(proof.clone()),
                        },
                    )
                })
            }),
        )
    }
}

/// Check that a transformation preserves every pair except one and replaces
/// that pair by exactly one new pair.  Pair order and variable spelling are
/// presentation details, so the comparison is alpha-equivalence based.
fn exact_single_pair_replacement_indices(
    parent: &[DependencyPair],
    child: &[DependencyPair],
) -> Option<(usize, usize)> {
    let merged_result = parent.len() == child.len() + 1;
    if (parent.len() != child.len() && !merged_result) || parent.is_empty() {
        return None;
    }
    (0..parent.len()).find_map(|removed_parent| {
        (0..child.len()).find_map(|added_child| {
            let mut used_child = vec![false; child.len()];
            // CPF treats the rewritten result as a set member. It can
            // already occur among the retained pairs. The native residual
            // still preserves the duplicate; a separate alpha-merge action
            // is needed before a deduplicated continuation is followed.
            used_child[added_child] = !merged_result;
            let retained = parent.iter().enumerate().all(|(parent_index, pair)| {
                if parent_index == removed_parent {
                    return true;
                }
                let Some((child_index, _)) = child.iter().enumerate().find(|(index, candidate)| {
                    !used_child[*index] && dependency_pairs_alpha_equivalent(pair, candidate)
                }) else {
                    return false;
                };
                used_child[child_index] = true;
                true
            });
            (retained
                && !dependency_pairs_alpha_equivalent(&parent[removed_parent], &child[added_child]))
            .then_some((removed_parent, added_child))
        })
    })
}

fn derive_exact_rewriting_step(
    problem: &crate::proving::DpProblemState,
    child: &[DependencyPair],
    payload: &str,
) -> Option<(DpRewritingStep, Vec<DependencyPair>)> {
    let trace = |reason: &str| {
        if std::env::var_os("FERRUM_EXACT_REPLAY_TIMING").is_some() {
            eprintln!("exact-rewriting reconstruction rejected: {reason}");
        }
    };
    let Some((parent_index, child_index)) =
        exact_single_pair_replacement_indices(&problem.pairs, child)
    else {
        trace("residual is not one exact pair replacement");
        return None;
    };
    let original_pair = problem.pairs[parent_index].clone();
    let archived_child_pair = child[child_index].clone();

    let wrapped = format!("<ferrumCpfFragment>{payload}</ferrumCpfFragment>");
    let document = roxmltree::Document::parse(&wrapped).ok()?;
    let root = document.root_element();
    let direct = root
        .children()
        .filter(roxmltree::Node::is_element)
        .collect::<Vec<_>>();
    let original_node = direct
        .first()
        .copied()
        .filter(|node| node.tag_name().name() == "rule")?;
    let rewrite_node = direct
        .iter()
        .copied()
        .find(|node| node.tag_name().name() == "rewriteStep")?;
    let rewritten_node = direct
        .iter()
        .copied()
        .skip_while(|node| *node != rewrite_node)
        .skip(1)
        .find(|node| node.tag_name().name() == "rule")?;
    let parse_one_rule = |node: roxmltree::Node<'_, '_>| {
        let xml = &wrapped[node.range()];
        let container = format!("<dps><rules>{xml}</rules></dps>");
        crate::parsing::parse_cpf_rule_container_fragment(&container, "dps")
            .ok()??
            .into_iter()
            .next()
    };
    let archived_original = parse_one_rule(original_node)?;
    let archived_rewritten = parse_one_rule(rewritten_node)?;
    let original_rule = original_pair.as_rule();
    let rewritten_rule = archived_child_pair.as_rule();
    if !super::general_red_pair::alpha_equivalent_rules(&archived_original, &original_rule)
        || !super::general_red_pair::alpha_equivalent_rules(&archived_rewritten, &rewritten_rule)
    {
        trace("payload pair does not match live parent/child pair");
        return None;
    }

    let position = rewrite_node
        .descendants()
        .filter(|node| node.is_element() && node.tag_name().name() == "position")
        .map(|node| node.text()?.trim().parse::<usize>().ok())
        .collect::<Option<Vec<_>>>()?;
    if position.is_empty() {
        trace("rewrite position is empty");
        return None;
    }
    let archived_rewrite_rule_node = rewrite_node
        .children()
        .find(|node| node.is_element() && node.tag_name().name() == "rule")?;
    let archived_rewrite_rule = parse_one_rule(archived_rewrite_rule_node)?;
    let active_rules = problem
        .stats
        .active_rules
        .as_deref()
        .unwrap_or(problem.trs.rules());
    let Some(rewrite_rule) = active_rules
        .iter()
        .find(|rule| super::general_red_pair::alpha_equivalent_rules(rule, &archived_rewrite_rule))
        .cloned()
    else {
        trace("payload rewrite rule is absent from live active rules");
        return None;
    };
    let archived_usable =
        crate::parsing::parse_cpf_rule_container_fragment(payload, "usableRules").ok()??;
    let Some(usable_rules) = archived_usable
        .iter()
        .map(|archived| {
            active_rules
                .iter()
                .find(|rule| super::general_red_pair::alpha_equivalent_rules(rule, archived))
                .cloned()
        })
        .collect::<Option<Vec<_>>>()
    else {
        trace("payload usable rule is absent from live active rules");
        return None;
    };

    let redex = subterm_at_position(original_pair.rhs(), &position)?;
    // Rule variables and pair variables are separate binders. Freshen before
    // matching so recursive substitution cannot capture variables inside the
    // live redex (the synthesized rewriting route does the same).
    let mut used_variables = original_pair.lhs().variables();
    used_variables.extend(original_pair.rhs().variables());
    let fresh_rule = crate::proving::dependency_pairs::freshen_rule_avoiding(
        &rewrite_rule, 0, &used_variables,
    );
    let mut substitution = BTreeMap::new();
    if !match_term(fresh_rule.lhs(), redex, &mut substitution) {
        trace("payload rewrite rule does not match the selected live redex");
        return None;
    }
    let replacement = apply_substitution(fresh_rule.rhs(), &substitution);
    let result = replace_subterm_at_position(original_pair.rhs(), &position, &replacement)?;
    let live_rewritten_pair = DependencyPair::from_rule(
        crate::core::RewriteRule::new(original_pair.lhs().clone(), result.clone()),
        original_pair.source_rule(),
    );
    // The retained child records archived source-rule provenance.  That
    // provenance is not part of the rewriting result and can differ after a
    // canonical residual has been reconstructed.  Compare the DP rules here;
    // the live result deliberately retains the live parent's source rule.
    if !dependency_pair_rules_alpha_equivalent(&live_rewritten_pair, &archived_child_pair) {
        trace("computed live rewrite result differs from retained child");
        if std::env::var_os("FERRUM_EXACT_REPLAY_TIMING").is_some() {
            eprintln!("exact-rewriting computed={:?} archived={:?}", live_rewritten_pair.as_rule(), archived_child_pair.as_rule());
        }
        return None;
    }
    let mut residual = problem.pairs.clone();
    residual[parent_index] = live_rewritten_pair.clone();
    Some((
        DpRewritingStep {
            original_pair,
            rewrite_step: crate::proving::LoopRewriteStep {
                position,
                rule: rewrite_rule,
                result,
            },
            rewritten_pair: live_rewritten_pair,
            usable_rules,
        },
        residual,
    ))
}

#[cfg(test)]
mod tests {
    #[test]
    fn explicit_q_coverage_is_not_an_innermost_strategy_relabeling() {
        let rule = RewriteRule::new(Term::app("f", vec![Term::var("x")]), Term::var("x"));
        let mut problem = DpProblemState::ordinary(
            Trs::new(None, BTreeSet::new(), vec![rule.clone()]), vec![], DpOptions::default());
        assert!(!super::q_covers_active_rule_lhss(&problem));
        problem.innermost_lhss = Some(vec![rule.lhs().clone()]);
        assert!(super::q_covers_active_rule_lhss(&problem));
        assert_eq!(problem.trs.strategy(), RewriteStrategy::Full);
        problem.innermost_lhss = Some(vec![]);
        assert!(!super::q_covers_active_rule_lhss(&problem));
        problem.stats.active_rules = Some(vec![]);
        assert!(super::q_covers_active_rule_lhss(&problem));
    }

    #[test]
    fn explicit_forward_reconstruction_policy_round_trips() {
        use crate::proving::dependency_pairs::{DpStrategy, DpStrategyProcessor};
        let strategy = DpStrategy::Processor(DpStrategyProcessor::ExactDpTransformation {
            source_dp_input_xml: None,
            processor_tag: "forwardInstantiationProcDirect".to_owned(),
            payload_xml: "<rule/>".to_owned(),
            dp_input_xml: "<dpInput/>".to_owned(),
        });
        assert_eq!(DpStrategy::parse(&strategy.to_strategy_atom()).unwrap(), strategy);
    }

    #[test]
    fn exact_rewriting_can_target_an_already_retained_pair() {
        use crate::core::{RewriteRule, Term};
        use crate::proving::DependencyPair;
        let pair = |rhs: &str| DependencyPair::from_rule(RewriteRule::new(
            Term::app("F", vec![Term::var("x")]),
            Term::app(rhs, vec![Term::var("x")])), 0);
        let parent = vec![pair("G"), pair("H")];
        assert_eq!(super::exact_single_pair_replacement_indices(&parent, &[pair("H")]), Some((0, 0)));
        assert_eq!(super::exact_single_pair_replacement_indices(&parent, &[pair("K")]), None);
    }
    #[test]
    fn exact_narrowing_uses_certified_active_rules_not_original_rules() {
        let constant = |name: &str| Term::app(name, vec![]);
        let app = |name: &str, arg| Term::app(name, vec![arg]);
        let pair = DependencyPair::new_for_test(app("F", app("k", Term::var("x"))), app("F", app("h", Term::var("x"))));
        let retained = RewriteRule::new(app("h", constant("a")), constant("b"));
        let removed = RewriteRule::new(app("h", constant("c")), constant("d"));
        let mut problem = DpProblemState::ordinary(Trs::new(None, BTreeSet::new(), vec![retained.clone(), removed]), vec![pair], DpOptions::default());
        let child = DependencyPair::new_for_test(app("F", app("k", constant("a"))), app("F", constant("b")));
        let payload = "<rule><funapp><name>F</name><funapp><name>k</name><var>x</var></funapp></funapp><funapp><name>F</name><funapp><name>h</name><var>x</var></funapp></funapp></rule><positionInTerm><position>1</position></positionInTerm><narrowings><rules><rule><funapp><name>F</name><funapp><name>k</name><funapp><name>a</name></funapp></funapp></funapp><funapp><name>F</name><funapp><name>b</name></funapp></funapp></rule></rules></narrowings>";
        assert!(super::derive_exact_narrowing_step(&problem, &[child.clone()], payload).is_none());
        problem.stats.active_rules = Some(vec![retained]);
        assert!(super::derive_exact_narrowing_step(&problem, &[child], payload).is_some());
    }

    #[test]
    fn exact_rewriting_freshens_rule_variables_before_matching() {
        fn xml(term: &Term) -> String {
            match term {
                Term::Var(variable) => format!("<var>{variable}</var>"),
                Term::App { symbol, args } => format!("<funapp><name>{symbol}</name>{}</funapp>",
                    args.iter().map(xml).collect::<String>()),
            }
        }
        let app = |name: &str, args| Term::app(name, args);
        let x = Term::var("x");
        let y = Term::var("y");
        let g = app("g", vec![x.clone(), y.clone()]);
        let k = app("k", vec![x.clone(), y.clone()]);
        let lhs = app("F", vec![x.clone(), y.clone()]);
        let before = DependencyPair::new_for_test(lhs.clone(),
            app("F", vec![app("h", vec![g.clone(), k.clone()]), y.clone()]));
        let after = DependencyPair::new_for_test(lhs,
            app("F", vec![app("q", vec![g, k]), y.clone()]));
        let rule = RewriteRule::new(app("h", vec![x.clone(), y.clone()]), app("q", vec![x, y]));
        let rule_xml = |rule: RewriteRule| format!("<rule>{}{}</rule>", xml(rule.lhs()), xml(rule.rhs()));
        let payload = format!("{}<rewriteStep><positionInTerm><position>1</position></positionInTerm>{}</rewriteStep>{}<usableRules><rules>{}</rules></usableRules>",
            rule_xml(before.as_rule()), rule_xml(rule.clone()), rule_xml(after.as_rule()), rule_xml(rule.clone()));
        let trs = Trs::new_with_strategy(None, BTreeSet::new(), vec![rule], RewriteStrategy::Innermost);
        let problem = DpProblemState::ordinary(trs, vec![before], DpOptions::default());
        let (_, residual) = super::derive_exact_rewriting_step(&problem, &[after.clone()], &payload)
            .expect("rule-local variables must not capture live pair variables");
        assert_eq!(residual[0].as_rule(), after.as_rule());
    }

    #[test]
    fn payload_transport_freshens_unused_colliding_interpretations() {
        let payload = "<interpretation><interpret><sharp><name>F</name></sharp><arity>1</arity><variable>1</variable></interpret><interpret><sharp><name>G</name></sharp><arity>1</arity><integer>0</integer></interpret></interpretation>";
        let symbols = std::collections::BTreeMap::from([
            (crate::core::Symbol::new("F#"), crate::core::Symbol::new("G#")),
        ]);
        let transported = super::translate_payload_symbols(payload, &symbols);
        assert_eq!(transported.matches("<sharp><name>G</name></sharp>").count(), 1);
        assert!(transported.contains("__ferrum_unused_witness_0"));
    }

    use std::collections::{BTreeMap, BTreeSet};

    use crate::core::{
        CsrTrs, ReplacementMap, RewriteRule, RewriteStrategy, Symbol, Term, Trs, Variable,
    };
    use crate::proving::dependency_pairs::{DependencyPair, DpOptions};
    use crate::proving::{DpProblemState, ProblemState, ProcessorResult, WorklistProcessor};

    use super::{
        ExactDpTransformationProcessor, derive_exact_instantiation_step,
        derive_nontermination_instantiations, preserve_live_pair_spellings,
        restore_live_rule_spellings, restore_retained_dp_strategy, same_pairs,
        translate_payload_symbols,
    };

    #[test]
    fn exact_instantiation_rejects_noninstances_even_with_matching_child_shape() {
        let pair = |symbol: &str| DependencyPair::new_for_test(
            Term::app(format!("{symbol}#"), vec![Term::var("x")]),
            Term::app(format!("{symbol}#"), vec![Term::var("x")]));
        let problem = DpProblemState::ordinary(Trs::new(None, BTreeSet::new(), vec![]),
            vec![pair("f")], DpOptions::default());
        let rule_xml = |symbol: &str| format!("<rule><funapp><sharp><name>{symbol}</name></sharp><var>x</var></funapp><funapp><sharp><name>{symbol}</name></sharp><var>x</var></funapp></rule>");
        let payload = format!("{}<instantiations><rules>{}</rules></instantiations>", rule_xml("f"), rule_xml("g"));
        assert!(super::derive_exact_instantiation_from_payload(&problem, &[pair("g")], &payload).is_none());
    }

    #[test]
    fn exact_instantiation_keeps_literal_alpha_variant_rules_for_cpf() {
        let pair = |variable: &str| DependencyPair::from_rule(
            RewriteRule::new(Term::app("f#", vec![Term::var(variable)]),
                             Term::app("g#", vec![Term::var(variable)])), 0);
        let selected = DependencyPair::from_rule(
            RewriteRule::new(Term::app("h#", vec![Term::var("x")]),
                             Term::app("k#", vec![Term::var("x")])), 1);
        let retained = pair("live");
        let instance = pair("witness");
        let (_, child) = derive_exact_instantiation_step(
            &[selected.clone(), retained.clone()], &[instance.clone()], false,
            Some(&selected.as_rule()), Some(&[instance.as_rule()])).unwrap();
        assert_eq!(child.len(), 2);
        assert!(child.iter().any(|pair| pair.as_rule() == retained.as_rule()));
        assert!(child.iter().any(|pair| pair.as_rule() == instance.as_rule()));
    }

    #[test]
    fn exact_instantiation_rebuilds_stale_pair_sources_from_live_parent() {
        let pair = |lhs: &str, rhs: &str, source_rule| {
            DependencyPair::from_rule(
                RewriteRule::new(
                    Term::app(format!("{lhs}#"), vec![Term::var("x")]),
                    Term::app(format!("{rhs}#"), vec![Term::var("x")]),
                ),
                source_rule,
            )
        };
        let selected = pair("f", "g", 7);
        let retained = pair("h", "i", 11);
        let archived_child = vec![pair("h", "i", 0), pair("f", "j", 0), pair("f", "k", 0)];

        let (step, normalized) = derive_exact_instantiation_step(
            &[selected.clone(), retained.clone()],
            &archived_child,
            false,
            None,
            None,
        )
        .expect("rule-identical retained state should ignore archived source placeholders");

        assert_eq!(step.pair.source_rule(), 7);
        assert!(
            step.instantiations
                .iter()
                .all(|pair| pair.source_rule() == 7)
        );
        assert!(normalized.iter().any(|pair| pair == &retained));
        assert_eq!(
            normalized
                .iter()
                .filter(|pair| pair.source_rule() == 7)
                .count(),
            2
        );
    }

    #[test]
    fn nontermination_instantiation_replaces_pairs_and_checks_instances() {
        let pair = |name: &str| {
            DependencyPair::from_rule(
                RewriteRule::new(
                    Term::app(format!("{name}#"), Vec::new()),
                    Term::app(format!("{name}#"), Vec::new()),
                ),
                0,
            )
        };
        let retained = pair("f");
        let added = pair("g");
        let payload = concat!(
            "<instantiations><dps><rules><rule>",
            "<funapp><sharp><name>g</name></sharp></funapp>",
            "<funapp><sharp><name>g</name></sharp></funapp>",
            "</rule></rules></dps></instantiations>"
        );

        assert_eq!(
            derive_nontermination_instantiations(
                std::slice::from_ref(&retained),
                &[retained.clone(), added.clone()],
                payload,
            ),
            None
        );
        let general = DependencyPair::from_rule(RewriteRule::new(
            Term::app("g#", vec![Term::var("x")]),
            Term::app("g#", vec![Term::var("x")]),
        ), 0);
        let instance = DependencyPair::from_rule(RewriteRule::new(
            Term::app("g#", vec![Term::app("a", vec![])]),
            Term::app("g#", vec![Term::app("a", vec![])]),
        ), 0);
        let payload = concat!("<dps><rules><rule>",
            "<funapp><sharp><name>g</name></sharp><funapp><name>a</name></funapp></funapp>",
            "<funapp><sharp><name>g</name></sharp><funapp><name>a</name></funapp></funapp>",
            "</rule></rules></dps>");
        assert_eq!(derive_nontermination_instantiations(
            &[general], std::slice::from_ref(&instance), payload), Some(vec![instance]));
    }

    #[test]
    fn retained_innermost_context_restores_standalone_dp_input_strategy() {
        let trs = Trs::new(
            None,
            BTreeSet::from([Variable::new("x")]),
            vec![RewriteRule::new(
                Term::app("f", vec![Term::var("x")]),
                Term::var("x"),
            )],
        );

        let restored = restore_retained_dp_strategy(trs.clone(), RewriteStrategy::Innermost, true);
        assert_eq!(restored.strategy(), RewriteStrategy::Innermost);
        assert_eq!(restored.rules(), trs.rules());

        let untyped = restore_retained_dp_strategy(trs, RewriteStrategy::Innermost, false);
        assert_eq!(untyped.strategy(), RewriteStrategy::Full);
    }

    #[test]
    fn retained_active_rules_recover_live_rule_local_variable_spellings() {
        let retained = RewriteRule::new(
            Term::app(
                "app",
                vec![Term::app("add1", vec![Term::var("x0")]), Term::var("y1")],
            ),
            Term::app("add2", vec![Term::var("x0"), Term::var("y1")]),
        );
        let live = RewriteRule::new(
            Term::app(
                "app",
                vec![Term::app("add1", vec![Term::var("x0")]), Term::var("y")],
            ),
            Term::app("add2", vec![Term::var("x0"), Term::var("y")]),
        );

        assert_eq!(
            restore_live_rule_spellings(&[retained], std::slice::from_ref(&live)),
            Some(vec![live])
        );
    }

    #[test]
    fn cpf_pair_matching_does_not_invent_source_rule_zero() {
        let rule = RewriteRule::new(
            Term::app("f#", vec![Term::var("x")]),
            Term::app("g#", vec![Term::var("x")]),
        );
        let trs = Trs::new(None, BTreeSet::from([Variable::new("x")]), Vec::new());
        let state = DpProblemState::ordinary(
            trs,
            vec![DependencyPair::from_rule(rule.clone(), 7)],
            DpOptions::default(),
        );

        assert!(same_pairs(&ProblemState::DependencyPairs(state), &[rule]));
    }

    #[test]
    fn payload_translation_is_simultaneous_for_symbol_permutations() {
        let symbols = BTreeMap::from([
            (Symbol::new("a"), Symbol::new("b")),
            (Symbol::new("b"), Symbol::new("a")),
        ]);
        assert_eq!(translate_payload_symbols(
            "<loop><funapp><name>a</name><funapp><name>b</name></funapp></funapp></loop>",
            &symbols),
            "<loop><funapp><name>b</name><funapp><name>a</name></funapp></funapp></loop>");
    }

    #[test]
    fn payload_translation_serializes_canonical_names_as_marked_symbols() {
        let symbols = BTreeMap::from([
            (Symbol::new("a"), Symbol::new("active#")),
            (Symbol::new("f"), Symbol::new("live")),
        ]);
        let payload = concat!(
            "<dps><rules><rule>",
            "<funapp><name>a</name><var>x</var></funapp>",
            "<funapp><sharp><name>f</name></sharp><var>x</var></funapp>",
            "</rule></rules></dps>"
        );

        let translated = translate_payload_symbols(payload, &symbols);

        assert!(translated.contains("<sharp><name>active</name></sharp>"));
        assert!(translated.contains("<sharp><name>live</name></sharp>"));
        assert!(!translated.contains("<name>active#</name>"));
        assert!(!translated.contains("<sharp><sharp>"));
    }

    #[test]
    fn payload_translation_keeps_marked_and_unmarked_images_independent() {
        let symbols = BTreeMap::from([
            (Symbol::new("active"), Symbol::new("b")),
            (Symbol::new("active#"), Symbol::new("aa#")),
            (Symbol::new("mark"), Symbol::new("c")),
            (Symbol::new("mark#"), Symbol::new("ab#")),
        ]);
        let payload = concat!(
            "<interpretation>",
            "<interpret><name>active</name></interpret>",
            "<interpret><sharp>\n  <name>active</name>\n</sharp></interpret>",
            "</interpretation>",
            "<dps><rules><rule>",
            "<funapp><sharp>\n<name>active</name>\n</sharp><var>x</var></funapp>",
            "<funapp><sharp> <name>mark</name> </sharp><var>x</var></funapp>",
            "</rule></rules></dps>"
        );

        let translated = translate_payload_symbols(payload, &symbols);

        assert!(translated.contains("<interpret><name>b</name></interpret>"));
        assert!(translated.contains("<name>aa</name>\n</sharp></interpret>"));
        assert!(translated.contains("<name>aa</name>\n</sharp><var>x</var>"));
        assert!(translated.contains("<name>ab</name> </sharp><var>x</var>"));
        assert!(!translated.contains("<sharp><name>b</name></sharp>"));
    }

    #[test]
    fn payload_translation_relocates_structured_semantic_labels() {
        let symbols = BTreeMap::from([(
            Symbol::new("__ferrum_sl__70726f706572__1"),
            Symbol::new("__ferrum_sl__6f6b__0"),
        )]);
        let payload = concat!(
            "<usableRules><rules><rule><funapp>",
            "<labeledSymbol><name>proper</name><numberLabel><number>1</number>",
            "</numberLabel></labeledSymbol><var>x</var></funapp>",
            "<var>x</var></rule></rules></usableRules>"
        );

        let translated = translate_payload_symbols(payload, &symbols);

        assert!(translated.contains(
            "<labeledSymbol><name>ok</name><numberLabel><number>0</number></numberLabel></labeledSymbol>"
        ));
        assert!(!translated.contains("<name>proper</name>"));
    }

    #[test]
    fn payload_translation_relocates_root_labels_as_whole_symbols() {
        let symbols = BTreeMap::from([(
            Symbol::new("__ferrum_rl__6623__61_66"),
            Symbol::new("__ferrum_rl__6723__62_67"),
        )]);
        let payload = "<interpret><labeledSymbol><sharp><name>f</name></sharp><symbolLabel><name>a</name><name>f</name></symbolLabel></labeledSymbol></interpret>";
        let translated = translate_payload_symbols(payload, &symbols);
        assert_eq!(translated, "<interpret><labeledSymbol><sharp><name>g</name></sharp><symbolLabel><name>b</name><name>g</name></symbolLabel></labeledSymbol></interpret>");
        assert!(!translated.contains("numberLabel"));
    }

    #[test]
    fn exact_transformation_preserves_live_spelling_of_retained_pairs() {
        let live = DependencyPair::from_rule(
            RewriteRule::new(
                Term::app("f#", vec![Term::var("V1")]),
                Term::app("g#", vec![Term::var("V1")]),
            ),
            7,
        );
        let archived = DependencyPair::from_rule(
            RewriteRule::new(
                Term::app("f#", vec![Term::var("x")]),
                Term::app("g#", vec![Term::var("x")]),
            ),
            0,
        );
        let transformed = DependencyPair::from_rule(
            RewriteRule::new(
                Term::app("h#", vec![Term::app("s", vec![Term::var("y")])]),
                Term::app("k#", vec![Term::var("y")]),
            ),
            9,
        );
        let mut mapped = vec![archived, transformed.clone()];

        preserve_live_pair_spellings(&mut mapped, std::slice::from_ref(&live));

        assert_eq!(mapped[0], live);
        assert_eq!(mapped[0].source_rule(), 7);
        assert_eq!(mapped[1], transformed);
    }

    #[test]
    fn exact_transformation_rejects_csr_child_without_certified_instantiation_coverage() {
        let x = Term::var("x");
        let rules = vec![
            RewriteRule::new(Term::app("f", vec![x.clone()]), x.clone()),
            RewriteRule::new(Term::app("g", vec![x.clone()]), x.clone()),
        ];
        let trs = Trs::new(None, BTreeSet::from([Variable::new("x")]), rules);
        let csr = CsrTrs::new(
            trs,
            ReplacementMap::new(BTreeMap::from([
                (Symbol::new("f"), BTreeSet::from([0])),
                (Symbol::new("g"), BTreeSet::from([0])),
            ])),
        )
        .unwrap();
        let parent_pair = DependencyPair::from_rule(
            RewriteRule::new(
                Term::app("f#", vec![x.clone()]),
                Term::app("f#", vec![x.clone()]),
            ),
            0,
        );
        let child_pair = DependencyPair::from_rule(
            RewriteRule::new(
                Term::app("f#", vec![Term::app("g", vec![x.clone()])]),
                Term::app("f#", vec![Term::app("g", vec![x.clone()])]),
            ),
            0,
        );
        let parent = DpProblemState::csr_materialized_from_parts(
            &csr,
            vec![parent_pair],
            Vec::new(),
            None,
            true,
            "improved",
            "context-sensitive",
            true,
            DpOptions::default(),
        )
        .unwrap();
        let (parent_xml, error) = crate::proving::standardized_dp_problem_state_input_cpf(&parent);
        assert!(error.is_none(), "{error:?}");
        let crate::parsing::CpfInputProblem::CsrDp {
            csr: parsed_csr,
            pairs: parsed_pairs,
            pair_source_rules,
            active_rules,
            minimal,
            construction,
            graph_estimator,
            use_qcs_usable_rules,
            ..
        } = crate::parsing::parse_cpf_input(None, &parent_xml).unwrap()
        else {
            panic!("expected serialized CSR-DP parent");
        };
        let parsed_pairs = parsed_pairs
            .into_iter()
            .enumerate()
            .map(|(index, rule)| {
                DependencyPair::from_rule(
                    rule,
                    pair_source_rules
                        .as_ref()
                        .and_then(|sources| sources.get(index).copied())
                        .unwrap_or(0),
                )
            })
            .collect();
        let parent = DpProblemState::csr_materialized_from_parts(
            &parsed_csr,
            parsed_pairs,
            Vec::new(),
            active_rules,
            minimal,
            &construction,
            &graph_estimator,
            use_qcs_usable_rules,
            DpOptions::default(),
        )
        .unwrap();
        let child = DpProblemState::csr_materialized_from_parts(
            &parsed_csr,
            vec![child_pair],
            Vec::new(),
            None,
            true,
            "improved",
            "context-sensitive",
            true,
            DpOptions::default(),
        )
        .unwrap();
        let (dp_input_xml, error) = crate::proving::standardized_dp_problem_state_input_cpf(&child);
        assert!(error.is_none(), "{error:?}");
        let crate::parsing::CpfInputProblem::CsrDp {
            pair_source_rules: Some(expected_sources),
            ..
        } = crate::parsing::parse_cpf_input(None, &dp_input_xml).unwrap()
        else {
            panic!("expected serialized CSR-DP child provenance");
        };

        let result = ExactDpTransformationProcessor {
            source_dp_input_xml: None,
            processor_tag: "instantiationProc".to_owned(),
            payload_xml: concat!(
                "<rule><funapp><sharp><name>f</name></sharp><var>x</var></funapp>",
                "<funapp><sharp><name>f</name></sharp><var>x</var></funapp></rule>",
                "<instantiations><rules><rule>",
                "<funapp><sharp><name>f</name></sharp><funapp><name>g</name><var>x</var></funapp></funapp>",
                "<funapp><sharp><name>f</name></sharp><funapp><name>g</name><var>x</var></funapp></funapp>",
                "</rule></rules></instantiations>",
            )
            .to_owned(),
            dp_input_xml,
        }
        .apply(&ProblemState::DependencyPairs(parent));
        assert!(matches!(result, ProcessorResult::Inapplicable));
        assert_eq!(expected_sources, vec![0]);
    }

    #[test]
    fn retargeted_instantiation_must_still_cover_the_live_self_loop() {
        let x = Term::var("x");
        let source_rules = vec![
            RewriteRule::new(
                Term::app("f", vec![x.clone()]),
                Term::app("g", vec![x.clone()]),
            ),
            RewriteRule::new(Term::app("g", vec![x.clone()]), x.clone()),
        ];
        let target_rules = vec![
            RewriteRule::new(Term::app("q", vec![x.clone()]), x.clone()),
            RewriteRule::new(
                Term::app("p", vec![x.clone()]),
                Term::app("q", vec![x.clone()]),
            ),
        ];
        let source_trs = Trs::new(None, BTreeSet::from([Variable::new("x")]), source_rules);
        let target_trs = Trs::new(None, BTreeSet::from([Variable::new("x")]), target_rules);
        let source_csr = CsrTrs::new(
            source_trs,
            ReplacementMap::new(BTreeMap::from([
                (Symbol::new("f"), BTreeSet::from([0])),
                (Symbol::new("g"), BTreeSet::from([0])),
            ])),
        )
        .unwrap();
        let target_csr = CsrTrs::new(
            target_trs,
            ReplacementMap::new(BTreeMap::from([
                (Symbol::new("p"), BTreeSet::from([0])),
                (Symbol::new("q"), BTreeSet::from([0])),
            ])),
        )
        .unwrap();
        let source_child_pair = DependencyPair::from_rule(
            RewriteRule::new(
                Term::app("g#", vec![Term::app("g", vec![x.clone()])]),
                Term::app("g#", vec![Term::app("g", vec![x.clone()])]),
            ),
            1,
        );
        let source_child = DpProblemState::csr_materialized_from_parts(
            &source_csr,
            vec![source_child_pair],
            Vec::new(),
            None,
            true,
            "improved",
            "context-sensitive",
            true,
            DpOptions::default(),
        )
        .unwrap();
        let dp_input_xml = crate::cert::append_ferrum_dp_state_context(
            crate::cert::write_csr_dp_state_input_cpf4(
                &source_csr,
                &source_child.pairs,
                &[],
                None,
                true,
                "improved",
                "context-sensitive",
                true,
            ),
            &[1],
            &[],
            &[],
            None,
            false,
            None,
            None,
            false,
            false,
            false,
            false,
            false,
        );

        let target_parent_pair = DependencyPair::from_rule(
            RewriteRule::new(
                Term::app("q#", vec![x.clone()]),
                Term::app("q#", vec![x.clone()]),
            ),
            0,
        );
        let target_parent = DpProblemState::csr_materialized_from_parts(
            &target_csr,
            vec![target_parent_pair],
            Vec::new(),
            None,
            true,
            "improved",
            "context-sensitive",
            true,
            DpOptions::default(),
        )
        .unwrap();
        let result = ExactDpTransformationProcessor {
            source_dp_input_xml: None,
            processor_tag: "instantiationProc".to_owned(),
            payload_xml: concat!(
                "<rule><funapp><sharp><name>g</name></sharp><var>x</var></funapp>",
                "<funapp><sharp><name>g</name></sharp><var>x</var></funapp></rule>",
                "<instantiations><rules><rule>",
                "<funapp><sharp><name>g</name></sharp><funapp><name>g</name><var>x</var></funapp></funapp>",
                "<funapp><sharp><name>g</name></sharp><funapp><name>g</name><var>x</var></funapp></funapp>",
                "</rule></rules></instantiations>",
            )
            .to_owned(),
            dp_input_xml,
        }
        .apply(&ProblemState::DependencyPairs(target_parent));
        // Symbol transport alone does not justify replacing q#(x) -> q#(x)
        // by its q#(q(x)) instance: the arbitrary incoming self-loop remains
        // uncovered. This historical shape-only test must reject the step.
        assert!(matches!(result, ProcessorResult::Inapplicable));
    }
}
