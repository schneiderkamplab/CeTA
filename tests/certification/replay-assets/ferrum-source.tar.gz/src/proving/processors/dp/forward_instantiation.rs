use std::time::Instant;

use crate::proving::dependency_pairs::{
    CsrDpConstruction, DpProblemContext, DpProofTree, residual_dp_graph_score_cached,
    strategy_timed_out, synthesize_forward_instantiation_candidates_filtered,
    usable_rules_in_innermost_context,
};
use crate::proving::runtime::CancellationScope;

use super::super::{
    ProblemCertificate, ProblemState, ProcessorApplication, ProcessorResult, WorklistProcessor,
};

pub struct ForwardInstantiationProcessor {
    pub max_per_pair: Option<usize>,
    pub candidate_index: usize,
    /// Bound generic recursive exploration independently of the graph-score
    /// heuristic.  A continuation may make progress only after a subsequent
    /// graph or usable-rules step, so generic search may deliberately disable
    /// `require_graph_progress`; it must still not grow an unbounded chain of
    /// successively instantiated states.
    pub require_depth_bound: bool,
    /// Generic search suppresses non-improving recursive CSR instantiations.
    /// An explicitly selected candidate is already a bounded oracle decision
    /// and must remain independently replayable even when this heuristic
    /// measure is unchanged.
    pub require_graph_progress: bool,
    pub deadline: Option<Instant>,
}

fn requires_graph_progress(construction: CsrDpConstruction) -> bool {
    matches!(
        construction,
        CsrDpConstruction::Innermost | CsrDpConstruction::Improved
    )
}

fn concrete_loop_witness(
    proof: &crate::proving::DpNonterminationProof,
) -> Option<&crate::proving::LoopProof> {
    match proof {
        crate::proving::DpNonterminationProof::Loop(loop_proof) => Some(loop_proof),
        crate::proving::DpNonterminationProof::Narrowing { proof, .. }
        | crate::proving::DpNonterminationProof::InnermostLhssIncrease { proof, .. }
        | crate::proving::DpNonterminationProof::InnermostLhssRemoval { proof, .. }
        | crate::proving::DpNonterminationProof::SwitchFullStrategy { proof, .. }
        | crate::proving::DpNonterminationProof::DpRuleRemoval { proof, .. }
        | crate::proving::DpNonterminationProof::Instantiation { proof, .. } => {
            concrete_loop_witness(proof)
        }
        crate::proving::DpNonterminationProof::Rewriting { .. }
        | crate::proving::DpNonterminationProof::NonLoop(_)
        | crate::proving::DpNonterminationProof::ExactLoopXml(_)
        | crate::proving::DpNonterminationProof::ExactNonLoopXml(_)
        | crate::proving::DpNonterminationProof::ExactProofXml(_) => None,
    }
}

fn forward_instantiation_rules(
    problem: &crate::proving::DpProblemState,
) -> Vec<crate::core::RewriteRule> {
    if problem.stats.active_rules_are_residual {
        // Once a certified processor has materialized an explicit residual
        // rule problem, that state is authoritative.  In particular,
        // `Some([])` means R = empty and must not be replaced by stale
        // transformation-rule hints retained for candidate discovery.
        problem
            .stats
            .active_rules
            .clone()
            .unwrap_or_else(|| problem.trs.rules().to_vec())
    } else {
        problem
            .stats
            .transformation_rules
            .as_ref()
            .or(problem.stats.active_rules.as_ref())
            .cloned()
            .unwrap_or_else(|| {
                usable_rules_in_innermost_context(
                    &problem.trs,
                    &problem.pairs,
                    problem.innermost_lhss.as_deref(),
                )
            })
    }
}

pub(crate) fn forward_instantiation_candidate_count(
    state: &ProblemState,
    deadline: Option<Instant>,
) -> Option<usize> {
    let ProblemState::DependencyPairs(problem) = state else {
        return Some(0);
    };
    if !problem.stats.weak_pairs.is_empty() {
        return Some(0);
    }
    let cancellation = CancellationScope::current(deadline);
    let usable = forward_instantiation_rules(problem);
    synthesize_forward_instantiation_candidates_filtered(
        // Keep candidate ordering independent of non-serialized caches.
        None,
        &problem.trs,
        &problem.pairs,
        &usable,
        problem.stats.active_rules_are_residual,
        problem.innermost_lhss.as_deref(),
        problem.stats.minimal || problem.stats.normal_form_substitutions,
        deadline,
        &cancellation,
        |_| true,
    )
    .map(|candidates| candidates.len())
}

impl WorklistProcessor for ForwardInstantiationProcessor {
    fn name(&self) -> &'static str {
        "dependency-pair-forward-instantiation"
    }

    fn apply(&self, state: &ProblemState) -> ProcessorResult {
        let ProblemState::DependencyPairs(problem) = state else {
            return ProcessorResult::Inapplicable;
        };
        if !problem.stats.weak_pairs.is_empty() {
            return ProcessorResult::Inapplicable;
        }
        if self.require_depth_bound
            && problem.stats.generic_forward_instantiation_transforms
                >= problem.options.max_forward_instantiation_transforms
        {
            return ProcessorResult::Inapplicable;
        }
        let cancellation = CancellationScope::current(self.deadline);
        if cancellation.is_cancelled() || strategy_timed_out(self.deadline) {
            return ProcessorResult::TimedOut;
        }
        let usable = forward_instantiation_rules(problem);
        if self.max_per_pair == Some(0) {
            return ProcessorResult::Inapplicable;
        }
        let Some(candidates) = synthesize_forward_instantiation_candidates_filtered(
            // Keep candidate ordering independent of non-serialized caches.
            None,
            &problem.trs,
            &problem.pairs,
            &usable,
            problem.stats.active_rules_are_residual,
            problem.innermost_lhss.as_deref(),
            problem.stats.minimal || problem.stats.normal_form_substitutions,
            self.deadline,
            &cancellation,
            |_| true,
        ) else {
            return ProcessorResult::TimedOut;
        };
        // Direct innermost-CSR and improved-CS-DP problems can admit an unbounded family of
        // successively larger forward instantiations.  Following those
        // states depth-first prevents the worklist from ever trying a later
        // reduction pair on the original residual (Ex3_2_Luc97).  For this
        // construction, retain only instantiations that strictly improve the
        // same certified dependency-graph measure used to rank candidates.
        // Every retained child remains self-contained and independently
        // replayable; this is a search restriction, not a proof shortcut.
        let require_graph_progress = self.require_graph_progress
            && matches!(
                &problem.stats.problem,
                DpProblemContext::ContextSensitive(context)
                    if requires_graph_progress(context.construction)
            );
        let baseline_score = require_graph_progress.then_some(()).and_then(|()| {
            residual_dp_graph_score_cached(
                Some(&problem.stats),
                &problem.trs,
                &problem.pairs,
                &usable,
                problem.innermost_lhss.as_deref().unwrap_or(&[]),
                self.deadline,
                &cancellation,
            )
        });
        let Some((_score, step, residual_pairs)) = candidates
            .into_iter()
            .filter(|(score, _, _)| {
                !require_graph_progress
                    || baseline_score
                        .as_ref()
                        .is_some_and(|baseline| *score < *baseline)
            })
            .nth(self.candidate_index)
        else {
            return ProcessorResult::Inapplicable;
        };
        let mut residual = problem.clone();
        residual.stats.transformation_rules = None;
        residual.pairs = residual_pairs;
        if self.require_depth_bound {
            residual.stats.generic_forward_instantiation_transforms += 1;
        }

        let source_trs = problem.trs.clone();
        let source_pairs = problem.pairs.clone();

        ProcessorResult::Applied(
            ProcessorApplication::new(vec![ProblemState::DependencyPairs(residual)], {
                let step = step.clone();
                move |children| {
                    let [ProblemCertificate::DependencyPairTree(proof)] =
                        <[ProblemCertificate; 1]>::try_from(children).ok()?
                    else {
                        return None;
                    };
                    Some(ProblemCertificate::DependencyPairTree(
                        DpProofTree::ForwardInstantiation {
                            step: step.clone(),
                            proof: Box::new(proof),
                        },
                    ))
                }
            })
            .with_child_short_circuit(move |certificate| match certificate {
                ProblemCertificate::DependencyPairNontermination(proof) => {
                    // Forward instantiation often exposes a concrete loop whose
                    // marked steps are merely instances of the selected source
                    // pair. Replace those rule labels by the general source pair
                    // and replay the complete sequence against the parent. This
                    // yields a direct CPF loop and needs no unverified converse
                    // of the forward-instantiation theorem.
                    let mut lifted = concrete_loop_witness(proof)?.clone();
                    let mut replacements = 0usize;
                    for rewrite_step in &mut lifted.steps {
                        let candidate = crate::proving::DependencyPair::from_rule(
                            rewrite_step.rule.clone(),
                            step.pair.source_rule(),
                        );
                        if crate::proving::dependency_pairs::dependency_pair_is_instance_of(
                            &candidate, &step.pair,
                        ) {
                            rewrite_step.rule = step.pair.as_rule();
                            replacements += 1;
                        }
                    }
                    let valid = crate::proving::nontermination::check_mixed_dp_loop_proof(
                        &source_trs,
                        &source_pairs,
                        &lifted,
                    );
                    if std::env::var_os("FERRUM_WORKLIST_TRACE").is_some() {
                        eprintln!(
                            "forward-instantiation loop lift replacements={replacements} valid={valid} source-pairs={} loop-steps={}",
                            source_pairs.len(),
                            lifted.steps.len(),
                        );
                    }
                    valid.then_some(
                        ProblemCertificate::DependencyPairNontermination(
                            crate::proving::DpNonterminationProof::Loop(lifted),
                        ),
                    )
                }
                _ => None,
            }),
        )
    }
}

#[cfg(test)]
mod tests {
    use std::collections::BTreeSet;

    use super::{
        ForwardInstantiationProcessor, forward_instantiation_rules, requires_graph_progress,
    };
    use crate::core::{RewriteRule, Term, Trs, Variable};
    use crate::proving::dependency_pairs::{CsrDpConstruction, DependencyPair, DpOptions};
    use crate::proving::processors::dp::DpProblemState;
    use crate::proving::processors::{ProblemState, ProcessorResult, WorklistProcessor};

    #[test]
    fn graph_progress_guard_covers_recursive_csr_instantiation_frameworks() {
        assert!(requires_graph_progress(CsrDpConstruction::Innermost));
        assert!(requires_graph_progress(CsrDpConstruction::Improved));
        assert!(!requires_graph_progress(CsrDpConstruction::Native));
        assert!(!requires_graph_progress(CsrDpConstruction::MutermUnhiding));
    }

    #[test]
    fn explicit_empty_residual_rules_override_transformation_hints() {
        let hint = RewriteRule::new(
            Term::app("g", vec![Term::var("x")]),
            Term::app("h", vec![Term::var("x")]),
        );
        let trs = Trs::new(
            None,
            BTreeSet::from([Variable::new("x")]),
            vec![hint.clone()],
        );
        let pair = DependencyPair::new_for_test(
            Term::app("f#", vec![Term::var("x")]),
            Term::app("f#", vec![Term::var("x")]),
        );
        let mut state = DpProblemState::ordinary(trs, vec![pair], DpOptions::default());
        state.stats.transformation_rules = Some(vec![hint]);
        state.stats.active_rules = Some(Vec::new());
        state.stats.active_rules_are_residual = true;

        assert!(forward_instantiation_rules(&state).is_empty());
    }

    #[test]
    fn generic_forward_instantiation_stops_at_the_configured_transform_depth() {
        let trs = Trs::new(
            None,
            BTreeSet::from([Variable::new("x")]),
            vec![RewriteRule::new(
                Term::app("g", vec![Term::var("x")]),
                Term::app("h", vec![Term::var("x")]),
            )],
        );
        let pair = DependencyPair::new_for_test(
            Term::app("f#", vec![Term::app("g", vec![Term::var("x")])]),
            Term::app("f#", vec![Term::app("h", vec![Term::var("x")])]),
        );
        let mut state = DpProblemState::ordinary(trs, vec![pair], DpOptions::default());
        state.stats.generic_forward_instantiation_transforms =
            state.options.max_forward_instantiation_transforms;

        assert!(matches!(
            ForwardInstantiationProcessor {
                max_per_pair: Some(1),
                candidate_index: 0,
                require_depth_bound: true,
                require_graph_progress: true,
                deadline: None,
            }
            .apply(&ProblemState::DependencyPairs(state)),
            ProcessorResult::Inapplicable
        ));
    }

    #[test]
    fn generic_continuation_keeps_depth_bound_without_graph_progress_filter() {
        let trs = Trs::new(
            None,
            BTreeSet::from([Variable::new("x")]),
            vec![RewriteRule::new(
                Term::app("g", vec![Term::var("x")]),
                Term::app("h", vec![Term::var("x")]),
            )],
        );
        let pair = DependencyPair::new_for_test(
            Term::app("f#", vec![Term::app("g", vec![Term::var("x")])]),
            Term::app("f#", vec![Term::app("h", vec![Term::var("x")])]),
        );
        let mut state = DpProblemState::ordinary(trs, vec![pair], DpOptions::default());
        state.stats.generic_forward_instantiation_transforms =
            state.options.max_forward_instantiation_transforms;

        assert!(matches!(
            ForwardInstantiationProcessor {
                max_per_pair: Some(1),
                candidate_index: 0,
                require_depth_bound: true,
                require_graph_progress: false,
                deadline: None,
            }
            .apply(&ProblemState::DependencyPairs(state)),
            ProcessorResult::Inapplicable
        ));
    }
}
