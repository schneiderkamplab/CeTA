use std::time::Instant;

use crate::core::{RewriteRule, RewriteStrategy, Trs};
use crate::parsing::{CpfInputProblem, parse_cpf_input};
use crate::proving::dependency_pairs::{DependencyPair, dependency_pair_rules_alpha_equivalent};
use crate::proving::nontermination::find_dp_nontermination_witness;
use crate::proving::processors::rewrite_analysis::weak_confluence_witness_depth;
use crate::standardize::translate_rule_symbols;

use super::super::{
    ProblemCertificate, ProblemState, ProcessorApplication, ProcessorResult, WorklistProcessor,
};

/// Atomic search for a checked dependency-pair nontermination witness.
pub struct DpNonterminationProcessor {
    pub deadline: Option<Instant>,
}

/// Search restriction, not a termination usable-rule theorem: any literal
/// subset of R is sound for a NO child. Keep the syntactic RHS reachability
/// closure, preserve Q/NFS, and expose the resulting state separately.
pub struct DpNonterminationUsableRulesProcessor;

/// NO-only bounded-rule search restriction. Unlike a termination rule-removal
/// theorem, any literal R subset is sufficient for a nontermination child.
/// These structural bounds never inspect symbol names or supplied witnesses.
pub struct DpNonterminationRuleFilterProcessor {
    pub max_lhs: usize,
    pub max_rhs: usize,
    pub collapsing: bool,
}

impl WorklistProcessor for DpNonterminationRuleFilterProcessor {
    fn name(&self) -> &'static str {
        "nontermination-rule-filter"
    }
    fn apply(&self, state: &ProblemState) -> ProcessorResult {
        let ProblemState::DependencyPairs(problem) = state else {
            return ProcessorResult::Inapplicable;
        };
        if !matches!(
            problem.stats.problem,
            crate::proving::DpProblemContext::Ordinary
        ) || !problem.stats.weak_pairs.is_empty()
            || !problem.stats.strict_rules.is_empty()
        {
            return ProcessorResult::Inapplicable;
        }
        let rules = problem
            .stats
            .active_rules
            .as_deref()
            .unwrap_or(problem.trs.rules());
        let (retained, removed): (Vec<_>, Vec<_>) = rules.iter().cloned().partition(|r| {
            crate::proving::dependency_pairs::positions_with_subterms(r.lhs()).len() <= self.max_lhs
                && crate::proving::dependency_pairs::positions_with_subterms(r.rhs()).len()
                    <= self.max_rhs
                && (self.collapsing || r.rhs().root_symbol().is_some())
        });
        if removed.is_empty() {
            return ProcessorResult::Inapplicable;
        }
        let mut child = problem.clone();
        child.trs = Trs::new_with_strategy(
            problem.trs.name().map(str::to_owned),
            problem.trs.variables().clone(),
            retained,
            problem.trs.strategy(),
        );
        child.stats.active_rules = None;
        child.stats.graph_rules = None;
        child.stats.transformation_rules = None;
        child.stats.minimal = false;
        ProcessorResult::Applied(ProcessorApplication::new(
            vec![ProblemState::DependencyPairs(child)],
            move |children| {
                let [ProblemCertificate::DependencyPairNontermination(proof)] =
                    <[ProblemCertificate; 1]>::try_from(children).ok()?
                else {
                    return None;
                };
                Some(ProblemCertificate::DependencyPairNontermination(
                    crate::proving::DpNonterminationProof::DpRuleRemoval {
                        removed_pairs: vec![],
                        removed_rules: removed.clone(),
                        proof: Box::new(proof),
                    },
                ))
            },
        ))
    }
}

/// CeTA's nontermination Q reduction: discard patterns outside funas(P,R).
/// Unlike the termination Q processor, this preserves NFS and drops minimality.
pub struct DpNonterminationInnermostLhssProcessor;

#[cfg(test)]
mod rule_filter_tests {
    use super::*;
    use crate::core::{Term, Variable};
    use crate::proving::dependency_pairs::{DpOptions, DpProofTree, DpStrategy};
    use crate::proving::processors::dp::DpProblemState;

    #[test]
    fn local_ceta_rule_filter_preserves_context_and_requires_no() {
        let x = Term::var("x");
        let constant = |s| Term::app(s, vec![]);
        let trs = Trs::new(
            None,
            [Variable::new("x")].into_iter().collect(),
            vec![
                RewriteRule::new(constant("a"), constant("b")),
                RewriteRule::new(Term::app("erase", vec![x.clone()]), x.clone()),
            ],
        );
        let p = Term::app("call#", vec![x]);
        let mut state = DpProblemState::ordinary(
            trs,
            vec![DependencyPair::new_for_test(p.clone(), p)],
            DpOptions::default(),
        );
        state.innermost_lhss = Some(vec![]);
        state.stats.normal_form_substitutions = true;
        let filter = DpNonterminationRuleFilterProcessor {
            max_lhs: 2,
            max_rhs: 2,
            collapsing: false,
        };
        let ProcessorResult::Applied(app) =
            filter.apply(&ProblemState::DependencyPairs(state.clone()))
        else {
            panic!()
        };
        let ProblemState::DependencyPairs(child) = &app.residuals[0] else {
            panic!()
        };
        assert_eq!(child.trs.rules().len(), 1);
        assert_eq!(child.innermost_lhss, state.innermost_lhss);
        assert_eq!(
            child.stats.normal_form_substitutions,
            state.stats.normal_form_substitutions
        );
        assert!(matches!(
            (DpNonterminationProcessor { deadline: None }).apply_symbolic_loop(&app.residuals[0]),
            ProcessorResult::Inapplicable
        ));
        assert!(
            app.reconstruct(vec![ProblemCertificate::DependencyPairTree(
                DpProofTree::Empty
            )])
            .is_none()
        );
        state.stats.normal_form_substitutions = false;
        let ProcessorResult::Applied(app) =
            filter.apply(&ProblemState::DependencyPairs(state.clone()))
        else {
            panic!()
        };
        let ProcessorResult::Applied(terminal) =
            (DpNonterminationProcessor { deadline: None }).apply_symbolic_loop(&app.residuals[0])
        else {
            panic!()
        };
        let proof = app
            .reconstruct(vec![terminal.reconstruct(vec![]).unwrap()])
            .unwrap();
        let ProblemCertificate::DependencyPairNontermination(proof) = proof else {
            panic!()
        };
        let xml = crate::cert::write_cpf3_dp_nontermination_state(&state, &proof).unwrap();
        let path =
            std::env::temp_dir().join(format!("ferrum-rule-filter-{}.xml", std::process::id()));
        std::fs::write(&path, xml).unwrap();
        let checker = std::env::var("CETA_CSR_BIN").unwrap_or_else(|_| "../CeTA-CSR/ceta".into());
        let output = std::process::Command::new(checker)
            .arg(&path)
            .output()
            .unwrap();
        let _ = std::fs::remove_file(path);
        assert!(
            output.status.success()
                && String::from_utf8_lossy(&output.stdout).trim() == "CERTIFIED",
            "{}{}",
            String::from_utf8_lossy(&output.stdout),
            String::from_utf8_lossy(&output.stderr)
        );
        assert!(
            DpStrategy::parse("nontermination-rule-filter(max-lhs=3,max-rhs=4,collapsing=0)")
                .is_ok()
        );
        assert!(DpStrategy::parse("nontermination-rule-filter(collapsing=2)").is_err());
    }
}

impl WorklistProcessor for DpNonterminationInnermostLhssProcessor {
    fn name(&self) -> &'static str {
        "nontermination-innermost-lhss"
    }
    fn apply(&self, state: &ProblemState) -> ProcessorResult {
        use std::collections::BTreeSet;
        let ProblemState::DependencyPairs(problem) = state else {
            return ProcessorResult::Inapplicable;
        };
        if !matches!(
            problem.stats.problem,
            crate::proving::DpProblemContext::Ordinary
        ) || !problem.stats.weak_pairs.is_empty()
            || !problem.stats.strict_rules.is_empty()
        {
            return ProcessorResult::Inapplicable;
        }
        let Some(current) = &problem.innermost_lhss else {
            return ProcessorResult::Inapplicable;
        };
        let symbols = |term: &crate::core::Term| {
            crate::proving::dependency_pairs::positions_with_subterms(term)
                .into_iter()
                .filter_map(|(_, term)| match term {
                    crate::core::Term::App { symbol, args } => Some((symbol.clone(), args.len())),
                    _ => None,
                })
                .collect::<BTreeSet<_>>()
        };
        let mut signature = BTreeSet::new();
        for pair in &problem.pairs {
            signature.extend(symbols(pair.lhs()));
            signature.extend(symbols(pair.rhs()));
        }
        for rule in problem
            .stats
            .active_rules
            .as_deref()
            .unwrap_or(problem.trs.rules())
        {
            signature.extend(symbols(rule.lhs()));
            signature.extend(symbols(rule.rhs()));
        }
        let remaining = current
            .iter()
            .filter(|q| symbols(q).is_subset(&signature))
            .cloned()
            .collect::<Vec<_>>();
        if &remaining == current {
            return ProcessorResult::Inapplicable;
        }
        let mut child = problem.clone();
        child.innermost_lhss = Some(remaining.clone());
        child.stats.minimal = false;
        ProcessorResult::Applied(ProcessorApplication::new(
            vec![ProblemState::DependencyPairs(child)],
            move |children| {
                let [ProblemCertificate::DependencyPairNontermination(proof)] =
                    <[ProblemCertificate; 1]>::try_from(children).ok()?
                else {
                    return None;
                };
                Some(ProblemCertificate::DependencyPairNontermination(
                    crate::proving::DpNonterminationProof::InnermostLhssRemoval {
                        remaining_lhss: remaining.clone(),
                        proof: Box::new(proof),
                    },
                ))
            },
        ))
    }
}

impl WorklistProcessor for DpNonterminationUsableRulesProcessor {
    fn name(&self) -> &'static str {
        "nontermination-usable-rules"
    }
    fn apply(&self, state: &ProblemState) -> ProcessorResult {
        use std::collections::BTreeSet;
        let ProblemState::DependencyPairs(problem) = state else {
            return ProcessorResult::Inapplicable;
        };
        if !matches!(
            problem.stats.problem,
            crate::proving::DpProblemContext::Ordinary
        ) || !problem.stats.weak_pairs.is_empty()
            || !problem.stats.strict_rules.is_empty()
        {
            return ProcessorResult::Inapplicable;
        }
        let rules = problem
            .stats
            .active_rules
            .as_deref()
            .unwrap_or(problem.trs.rules());
        let mut symbols = BTreeSet::new();
        let add = |term: &crate::core::Term, out: &mut BTreeSet<crate::core::Symbol>| {
            for (_, t) in crate::proving::dependency_pairs::positions_with_subterms(term) {
                if let Some(s) = t.root_symbol() {
                    out.insert(s.clone());
                }
            }
        };
        for pair in &problem.pairs {
            add(pair.rhs(), &mut symbols);
        }
        loop {
            let before = symbols.len();
            for r in rules {
                if r.lhs().root_symbol().is_some_and(|s| symbols.contains(s)) {
                    add(r.rhs(), &mut symbols);
                }
            }
            if symbols.len() == before {
                break;
            }
        }
        let (retained, removed): (Vec<_>, Vec<_>) = rules
            .iter()
            .cloned()
            .partition(|r| r.lhs().root_symbol().is_some_and(|s| symbols.contains(s)));
        if removed.is_empty() {
            return ProcessorResult::Inapplicable;
        }
        let mut child = problem.clone();
        child.trs = Trs::new_with_strategy(
            problem.trs.name().map(str::to_owned),
            problem.trs.variables().clone(),
            retained,
            problem.trs.strategy(),
        );
        child.stats.active_rules = None;
        child.stats.graph_rules = None;
        child.stats.transformation_rules = None;
        child.stats.minimal = false;
        ProcessorResult::Applied(ProcessorApplication::new(
            vec![ProblemState::DependencyPairs(child)],
            move |children| {
                let [ProblemCertificate::DependencyPairNontermination(proof)] =
                    <[ProblemCertificate; 1]>::try_from(children).ok()?
                else {
                    return None;
                };
                Some(ProblemCertificate::DependencyPairNontermination(
                    crate::proving::DpNonterminationProof::DpRuleRemoval {
                        removed_pairs: vec![],
                        removed_rules: removed.clone(),
                        proof: Box::new(proof),
                    },
                ))
            },
        ))
    }
}

/// Replay one certified nontermination-preserving DP rule-removal boundary.
///
/// This is intentionally not an opaque proof replay: the retained source is
/// matched against the live DP state modulo a signature isomorphism, the
/// residual must be a literal subproblem, and its continuation is solved as
/// an independently keyed worklist state.
pub struct ExactDpNonterminationRuleRemovalProcessor {
    pub source_dp_input_xml: String,
    pub residual_dp_input_xml: String,
}

/// Replace a Q-restricted DP nontermination obligation by full rewriting
/// after independently establishing weak confluence of the active TRS.
pub struct DpSwitchFullNonterminationProcessor {
    pub deadline: Option<Instant>,
}

pub struct ExactDpNonLoopProcessor {
    pub source_dp_input_xml: String,
    pub non_loop_xml: String,
}

pub struct ExactDpLoopProcessor {
    pub source_dp_input_xml: String,
    pub loop_xml: String,
}

pub struct ExactDpNonterminationProofProcessor {
    pub source_dp_input_xml: String,
    pub dp_proof_xml: String,
}

/// CeTA Q_Reduction_Nonterm_Impl: remove Q patterns outside the live P/R
/// signature, then require NF(Q') subset NF(the retained Q). Minimality is
/// dropped, NFS is preserved, and only a NO child reconstructs this step.
pub(super) fn reduce_innermost_lhss(state: &ProblemState, payload: &str) -> ProcessorResult {
    use crate::core::Term;
    use std::collections::BTreeSet;
    let ProblemState::DependencyPairs(problem) = state else {
        return ProcessorResult::Inapplicable;
    };
    if !matches!(
        problem.stats.problem,
        crate::proving::dependency_pairs::DpProblemContext::Ordinary
    ) || !problem.stats.weak_pairs.is_empty()
        || !problem.stats.strict_rules.is_empty()
    {
        return ProcessorResult::Inapplicable;
    }
    let Ok(Some(parsed)) =
        crate::parsing::parse_cpf_term_container_fragment(payload, "innermostLhss")
    else {
        return ProcessorResult::Inapplicable;
    };
    let current = problem.innermost_lhss.clone().unwrap_or_else(|| {
        if problem.trs.strategy() == RewriteStrategy::Innermost {
            problem
                .trs
                .rules()
                .iter()
                .map(|r| r.lhs().clone())
                .collect()
        } else {
            vec![]
        }
    });
    let Some(remaining) = super::exact_context::rebind_innermost_lhss(&parsed, &current) else {
        return ProcessorResult::Inapplicable;
    };
    fn symbols(term: &Term, out: &mut BTreeSet<(crate::core::Symbol, usize)>) {
        if let Term::App { symbol, args } = term {
            out.insert((symbol.clone(), args.len()));
            for arg in args {
                symbols(arg, out);
            }
        }
    }
    let mut signature = BTreeSet::new();
    for pair in &problem.pairs {
        symbols(pair.lhs(), &mut signature);
        symbols(pair.rhs(), &mut signature);
    }
    for rule in problem
        .stats
        .active_rules
        .as_deref()
        .unwrap_or(problem.trs.rules())
    {
        symbols(rule.lhs(), &mut signature);
        symbols(rule.rhs(), &mut signature);
    }
    for q in &current {
        let mut needed = BTreeSet::new();
        symbols(q, &mut needed);
        if needed.is_subset(&signature)
            && crate::proving::dependency_pairs::term_is_q_normal(q, &remaining)
        {
            return ProcessorResult::Inapplicable;
        }
    }
    if current == remaining {
        return ProcessorResult::Inapplicable;
    }
    let mut child = problem.clone();
    child.innermost_lhss = Some(remaining.clone());
    child.stats.minimal = false;
    ProcessorResult::Applied(ProcessorApplication::new(
        vec![ProblemState::DependencyPairs(child)],
        move |children| {
            let [ProblemCertificate::DependencyPairNontermination(proof)] =
                <[ProblemCertificate; 1]>::try_from(children).ok()?
            else {
                return None;
            };
            Some(ProblemCertificate::DependencyPairNontermination(
                crate::proving::DpNonterminationProof::InnermostLhssRemoval {
                    remaining_lhss: remaining.clone(),
                    proof: Box::new(proof),
                },
            ))
        },
    ))
}

/// CeTA's Q-increase for nontermination: union Q, drop minimality, and merge
/// strict/weak pairs and rules. Only a nontermination child can reconstruct it.
pub(super) fn increase_innermost_lhss(state: &ProblemState, payload: &str) -> ProcessorResult {
    let ProblemState::DependencyPairs(problem) = state else {
        return ProcessorResult::Inapplicable;
    };
    if !matches!(
        problem.stats.problem,
        crate::proving::dependency_pairs::DpProblemContext::Ordinary
    ) {
        return ProcessorResult::Inapplicable;
    }
    let Ok(Some(added_lhss)) =
        crate::parsing::parse_cpf_term_container_fragment(payload, "innermostLhss")
    else {
        return ProcessorResult::Inapplicable;
    };
    let mut child = problem.clone();
    let mut q = child.innermost_lhss.clone().unwrap_or_default();
    for term in &added_lhss {
        if !q.contains(term) {
            q.push(term.clone());
        }
    }
    child.innermost_lhss = Some(q);
    child.stats.minimal = false;
    child
        .pairs
        .extend(std::mem::take(&mut child.stats.weak_pairs));
    let mut rules = child
        .stats
        .active_rules
        .clone()
        .unwrap_or_else(|| child.trs.rules().to_vec());
    rules.extend(std::mem::take(&mut child.stats.strict_rules));
    child.stats.active_rules = Some(rules.clone());
    child.stats.graph_rules = Some(rules.clone());
    child.stats.transformation_rules = Some(rules);
    let child_pairs = child.pairs.clone();
    ProcessorResult::Applied(ProcessorApplication::new(
        vec![ProblemState::DependencyPairs(child)],
        move |children| {
            let [ProblemCertificate::DependencyPairNontermination(proof)] =
                <[ProblemCertificate; 1]>::try_from(children).ok()?
            else {
                return None;
            };
            Some(ProblemCertificate::DependencyPairNontermination(
                crate::proving::DpNonterminationProof::InnermostLhssIncrease {
                    added_lhss: added_lhss.clone(),
                    child_pairs: child_pairs.clone(),
                    proof: Box::new(proof),
                },
            ))
        },
    ))
}

#[cfg(test)]
mod q_increase_tests {
    use super::*;
    use crate::core::Term;
    use crate::proving::dependency_pairs::{DpOptions, DpProofTree};
    use crate::proving::processors::dp::DpProblemState;

    #[test]
    fn local_ceta_native_q_entry_rule_restriction_and_full_switch() {
        use crate::proving::processors::top_level::InnermostLhssDependencyPairTransformationProcessor;
        let x = Term::var("x");
        let rule = RewriteRule::new(
            Term::app("call", vec![x.clone()]),
            Term::app(
                "call",
                vec![Term::app(
                    "step",
                    vec![Term::app("helper", vec![x.clone()])],
                )],
            ),
        );
        let helper = RewriteRule::new(Term::app("helper", vec![x.clone()]), x.clone());
        let trs = Trs::new(None, x.variables(), vec![rule, helper]);
        let ProcessorResult::Applied(entry) =
            (InnermostLhssDependencyPairTransformationProcessor {
                options: DpOptions::default(),
            })
            .apply(&ProblemState::Trs(trs.clone()))
        else {
            panic!("Q entry")
        };
        let ProcessorResult::Applied(restrict) =
            DpNonterminationUsableRulesProcessor.apply(&entry.residuals[0])
        else {
            panic!("rule restriction")
        };
        assert!(matches!(
            (DpSwitchFullNonterminationProcessor { deadline: None }).apply(&restrict.residuals[0]),
            ProcessorResult::Inapplicable
        ));
        let ProcessorResult::Applied(reduce_q) =
            DpNonterminationInnermostLhssProcessor.apply(&restrict.residuals[0])
        else {
            panic!("Q reduction")
        };
        let ProcessorResult::Applied(switch) =
            (DpSwitchFullNonterminationProcessor { deadline: None }).apply(&reduce_q.residuals[0])
        else {
            panic!("full switch")
        };
        let ProcessorResult::Applied(terminal) = (DpNonterminationProcessor {
            deadline: Some(Instant::now() + std::time::Duration::from_secs(5)),
        })
        .apply(&switch.residuals[0]) else {
            panic!("native loop")
        };
        let proof = terminal.reconstruct(vec![]).unwrap();
        let proof = switch.reconstruct(vec![proof]).unwrap();
        let proof = reduce_q.reconstruct(vec![proof]).unwrap();
        let proof = restrict.reconstruct(vec![proof]).unwrap();
        let ProblemCertificate::Trs(proof) = entry.reconstruct(vec![proof]).unwrap() else {
            panic!("root proof")
        };
        let xml = crate::cert::write_cpf(&trs, &proof, crate::cert::CpfMode::Cpf30).unwrap();
        assert!(xml.contains("<innermostLhssIncrease>"));
        let path =
            std::env::temp_dir().join(format!("ferrum-native-q-chain-{}.xml", std::process::id()));
        std::fs::write(&path, xml).unwrap();
        let checker = std::env::var("CETA_CSR_BIN").unwrap_or_else(|_| "../CeTA-CSR/ceta".into());
        let output = std::process::Command::new(checker)
            .arg(&path)
            .output()
            .unwrap();
        let _ = std::fs::remove_file(path);
        assert!(
            output.status.success(),
            "{}{}",
            String::from_utf8_lossy(&output.stdout),
            String::from_utf8_lossy(&output.stderr)
        );
    }

    #[test]
    fn native_nontermination_rule_restriction_preserves_q_and_rejects_yes() {
        let x = Term::var("x");
        let dead = RewriteRule::new(Term::app("outer", vec![x.clone()]), x.clone());
        let live = RewriteRule::new(Term::app("inner", vec![x.clone()]), x.clone());
        let trs = Trs::new(None, x.variables(), vec![dead.clone(), live.clone()]);
        let pair = DependencyPair::from_rule(
            RewriteRule::new(
                Term::app("call#", vec![x.clone()]),
                Term::app("call#", vec![Term::app("inner", vec![x])]),
            ),
            0,
        );
        let mut problem = DpProblemState::ordinary(trs, vec![pair], DpOptions::default());
        let q = vec![dead.lhs().clone(), live.lhs().clone()];
        problem.innermost_lhss = Some(q.clone());
        let ProcessorResult::Applied(app) =
            DpNonterminationUsableRulesProcessor.apply(&ProblemState::DependencyPairs(problem))
        else {
            panic!()
        };
        let ProblemState::DependencyPairs(child) = &app.residuals[0] else {
            panic!()
        };
        assert_eq!(child.trs.rules(), &[live]);
        assert_eq!(child.innermost_lhss, Some(q));
        assert!(!child.stats.normal_form_substitutions);
        assert!(!child.stats.minimal);
        assert!(
            app.reconstruct(vec![ProblemCertificate::DependencyPairTree(
                DpProofTree::Empty
            )])
            .is_none()
        );
    }

    #[test]
    fn q_nontermination_reduction_preserves_live_signature_obligations() {
        let x = Term::var("x");
        let lhs = Term::app("live", vec![x.clone()]);
        let rule = RewriteRule::new(lhs.clone(), x.clone());
        let trs =
            Trs::new_with_strategy(None, Default::default(), vec![rule], RewriteStrategy::Full);
        let mut problem = DpProblemState::ordinary(trs, vec![], DpOptions::default());
        problem.innermost_lhss = Some(vec![lhs.clone(), Term::app("absent", vec![x])]);
        let state = ProblemState::DependencyPairs(problem);
        assert!(matches!(
            reduce_innermost_lhss(&state, "<innermostLhss/>"),
            ProcessorResult::Inapplicable
        ));
        let payload =
            "<innermostLhss><funapp><name>live</name><var>x</var></funapp></innermostLhss>";
        let ProcessorResult::Applied(app) = reduce_innermost_lhss(&state, payload) else {
            panic!()
        };
        let ProblemState::DependencyPairs(child) = &app.residuals[0] else {
            panic!()
        };
        assert_eq!(child.innermost_lhss, Some(vec![lhs]));
        assert!(!child.stats.minimal);
        assert!(
            app.reconstruct(vec![ProblemCertificate::DependencyPairTree(
                DpProofTree::Empty
            )])
            .is_none()
        );
    }

    #[test]
    fn q_increase_preserves_nfs_drops_minimality_and_rejects_yes_child() {
        let trs = Trs::new_with_strategy(None, Default::default(), vec![], RewriteStrategy::Full);
        let mut problem = DpProblemState::ordinary(trs, vec![], DpOptions::default());
        problem.innermost_lhss = Some(vec![Term::app("old", vec![])]);
        let nfs = problem.stats.normal_form_substitutions;
        let ProcessorResult::Applied(application) = increase_innermost_lhss(
            &ProblemState::DependencyPairs(problem),
            "<innermostLhss><funapp><name>added</name></funapp></innermostLhss>",
        ) else {
            panic!()
        };
        let ProblemState::DependencyPairs(child) = &application.residuals[0] else {
            panic!()
        };
        assert!(!child.stats.minimal);
        assert_eq!(child.stats.normal_form_substitutions, nfs);
        assert_eq!(child.innermost_lhss.as_ref().unwrap().len(), 2);
        assert!(
            application
                .reconstruct(vec![ProblemCertificate::DependencyPairTree(
                    DpProofTree::Empty
                )])
                .is_none()
        );
    }
}

impl WorklistProcessor for ExactDpNonterminationProofProcessor {
    fn name(&self) -> &'static str {
        "exact-dp-nontermination-proof"
    }

    fn apply(&self, state: &ProblemState) -> ProcessorResult {
        crate::proving::processors::reject_retired_complete_nontermination_proof();
        let ProblemState::DependencyPairs(problem) = state else {
            return ProcessorResult::Inapplicable;
        };
        if !problem.stats.weak_pairs.is_empty() {
            return ProcessorResult::Inapplicable;
        }
        let Some((source_trs, source_pairs)) = parsed_ordinary_dp(&self.source_dp_input_xml) else {
            return ProcessorResult::Failed {
                reason: "invalid exact DP nontermination source".to_owned(),
            };
        };
        let Some((symbols, _)) = super::portable_trs_isomorphism(&source_trs, &problem.trs) else {
            return ProcessorResult::Inapplicable;
        };
        let translated_pairs = source_pairs
            .iter()
            .map(|rule| translate_rule_symbols(rule, &symbols))
            .collect::<Vec<_>>();
        // The loop names every pair it uses.  Additional live pairs cannot
        // invalidate that witness; they only enlarge the relation whose
        // nontermination is being proved.
        if select_live_pairs(&translated_pairs, &problem.pairs).is_none() {
            return ProcessorResult::Inapplicable;
        }
        let fragment = self.dp_proof_xml.trim();
        if !fragment.starts_with("<dpNonterminationProof")
            || !fragment.ends_with("</dpNonterminationProof>")
        {
            return ProcessorResult::Failed {
                reason: "malformed exact DP nontermination proof fragment".to_owned(),
            };
        }
        ProcessorResult::Applied(ProcessorApplication::solved(
            ProblemCertificate::DependencyPairNontermination(
                crate::proving::DpNonterminationProof::ExactProofXml(fragment.to_owned()),
            ),
        ))
    }
}

impl WorklistProcessor for ExactDpLoopProcessor {
    fn name(&self) -> &'static str {
        "exact-dp-loop"
    }

    fn apply(&self, state: &ProblemState) -> ProcessorResult {
        let trace = |message: &str| {
            if std::env::var_os("FERRUM_EXACT_REPLAY_TIMING").is_some() {
                eprintln!("exact-dp-loop: {message}");
            }
        };
        let ProblemState::DependencyPairs(problem) = state else {
            return ProcessorResult::Inapplicable;
        };
        if !problem.stats.weak_pairs.is_empty() {
            trace("weak pairs are present");
            return ProcessorResult::Inapplicable;
        }
        let Some((source_trs, source_pairs)) = parsed_ordinary_dp(&self.source_dp_input_xml) else {
            return ProcessorResult::Failed {
                reason: "invalid exact loop source".to_owned(),
            };
        };
        let Some((symbols, _)) = super::portable_trs_isomorphism(&source_trs, &problem.trs) else {
            trace("source TRS mismatch");
            return ProcessorResult::Failed {
                reason: "exact loop source TRS is not isomorphic to the live TRS".into(),
            };
        };
        let translated_pairs = source_pairs
            .iter()
            .map(|rule| translate_rule_symbols(rule, &symbols))
            .collect::<Vec<_>>();
        // An independently checked loop over a pair subset remains a witness
        // after sound DP generation adds further pairs.
        if select_live_pairs(&translated_pairs, &problem.pairs).is_none() {
            trace("source pair mismatch");
            return ProcessorResult::Failed {
                reason: "exact loop source pairs do not match the live pairs".into(),
            };
        }
        let fragment = self.loop_xml.trim();
        if !fragment.starts_with("<loop") || !fragment.ends_with("</loop>") {
            return ProcessorResult::Failed {
                reason: "malformed exact loop fragment".to_owned(),
            };
        }
        let Some(fragment) = super::nontermination_rebind::relocate(fragment, problem, false)
        else {
            return ProcessorResult::Failed {
                reason: "loop witness rules cannot be rebound to the live problem".into(),
            };
        };
        ProcessorResult::Applied(ProcessorApplication::solved(
            ProblemCertificate::DependencyPairNontermination(
                crate::proving::DpNonterminationProof::ExactLoopXml(fragment),
            ),
        ))
    }
}

impl WorklistProcessor for ExactDpNonLoopProcessor {
    fn name(&self) -> &'static str {
        "exact-dp-nonloop"
    }

    fn apply(&self, state: &ProblemState) -> ProcessorResult {
        let ProblemState::DependencyPairs(problem) = state else {
            return ProcessorResult::Inapplicable;
        };
        if !problem.stats.weak_pairs.is_empty()
            || problem
                .innermost_lhss
                .as_ref()
                .is_some_and(|q| !q.is_empty())
            || problem.trs.strategy() != RewriteStrategy::Full
        {
            return ProcessorResult::Inapplicable;
        }
        let Some((source_trs, source_pairs)) = parsed_ordinary_dp(&self.source_dp_input_xml) else {
            return ProcessorResult::Failed {
                reason: "invalid exact non-loop source".to_owned(),
            };
        };
        let Some((symbols, _)) = super::portable_trs_isomorphism(&source_trs, &problem.trs) else {
            return ProcessorResult::Inapplicable;
        };
        let translated_pairs = source_pairs
            .iter()
            .map(|rule| translate_rule_symbols(rule, &symbols))
            .collect::<Vec<_>>();
        if select_live_pairs(&translated_pairs, &problem.pairs).is_none_or(|(matched, removed)| {
            !removed.is_empty() || matched.len() != problem.pairs.len()
        }) {
            return ProcessorResult::Inapplicable;
        }
        let fragment = self.non_loop_xml.trim();
        if !fragment.starts_with("<nonLoop") || !fragment.ends_with("</nonLoop>") {
            return ProcessorResult::Failed {
                reason: "malformed exact non-loop fragment".to_owned(),
            };
        }
        let Some(fragment) = super::nontermination_rebind::relocate(fragment, problem, true) else {
            return ProcessorResult::Failed {
                reason: "nonloop witness cannot be consistently rebound to the live problem".into(),
            };
        };
        ProcessorResult::Applied(ProcessorApplication::solved(
            ProblemCertificate::DependencyPairNontermination(
                crate::proving::DpNonterminationProof::ExactNonLoopXml(fragment),
            ),
        ))
    }
}

impl WorklistProcessor for DpSwitchFullNonterminationProcessor {
    fn name(&self) -> &'static str {
        "dependency-pair-switch-full-nontermination"
    }

    fn apply(&self, state: &ProblemState) -> ProcessorResult {
        let ProblemState::DependencyPairs(problem) = state else {
            return ProcessorResult::Inapplicable;
        };
        if problem.innermost_lhss.as_ref().is_none_or(Vec::is_empty)
            || !problem.stats.weak_pairs.is_empty()
            || !problem.stats.strict_rules.is_empty()
            || !matches!(
                problem.stats.problem,
                crate::proving::DpProblemContext::Ordinary
            )
            || problem.trs.strategy() == RewriteStrategy::Outermost
        {
            return ProcessorResult::Inapplicable;
        }
        if self
            .deadline
            .is_some_and(|deadline| Instant::now() >= deadline)
        {
            return ProcessorResult::TimedOut;
        }
        let active_rules = problem
            .stats
            .active_rules
            .as_deref()
            .unwrap_or_else(|| problem.trs.rules());
        let active_trs = Trs::new_with_strategy(
            problem.trs.name().map(str::to_owned),
            problem.trs.variables().clone(),
            active_rules.to_vec(),
            RewriteStrategy::Full,
        );
        // Termination_Switch_Impl.switch_termination_proc: overlay/WCR,
        // well-formed R, no R overlap into P, and NF(R) subset NF(Q).
        let pairs = problem
            .pairs
            .iter()
            .map(|p| p.as_rule())
            .collect::<Vec<_>>();
        let lhs = active_rules
            .iter()
            .map(|r| r.lhs().clone())
            .collect::<Vec<_>>();
        if !active_rules.iter().all(RewriteRule::is_well_formed)
            || !crate::proving::processors::rewrite_analysis::is_overlay_trs(&active_trs)
            || crate::proving::processors::rewrite_analysis::rules_have_cross_overlap(
                &pairs,
                active_rules,
            )
            || problem.innermost_lhss.as_ref().is_some_and(|q| {
                q.iter()
                    .any(|term| crate::proving::dependency_pairs::term_is_q_normal(term, &lhs))
            })
        {
            return ProcessorResult::Inapplicable;
        }
        let Some(wcr_depth) = weak_confluence_witness_depth(&active_trs) else {
            return if self
                .deadline
                .is_some_and(|deadline| Instant::now() >= deadline)
            {
                ProcessorResult::TimedOut
            } else {
                ProcessorResult::Inapplicable
            };
        };
        let mut child = problem.clone();
        child.trs = Trs::new_with_strategy(
            problem.trs.name().map(str::to_owned),
            problem.trs.variables().clone(),
            problem.trs.rules().to_vec(),
            RewriteStrategy::Full,
        );
        child.innermost_lhss = None;
        child.stats.minimal = false;
        ProcessorResult::Applied(ProcessorApplication::new(
            vec![ProblemState::DependencyPairs(child)],
            move |children| {
                let [ProblemCertificate::DependencyPairNontermination(proof)] =
                    <[ProblemCertificate; 1]>::try_from(children).ok()?
                else {
                    return None;
                };
                Some(ProblemCertificate::DependencyPairNontermination(
                    crate::proving::DpNonterminationProof::SwitchFullStrategy {
                        wcr_depth,
                        proof: Box::new(proof),
                    },
                ))
            },
        ))
    }
}

fn parsed_ordinary_dp(xml: &str) -> Option<(Trs, Vec<RewriteRule>)> {
    match parse_cpf_input(None, xml).ok()? {
        CpfInputProblem::Dp { trs, pairs, .. } => Some((trs, pairs)),
        _ => None,
    }
}

fn select_live_pairs(
    wanted: &[RewriteRule],
    live: &[DependencyPair],
) -> Option<(Vec<DependencyPair>, Vec<DependencyPair>)> {
    let mut retained = Vec::with_capacity(wanted.len());
    let mut used = vec![false; live.len()];
    for rule in wanted {
        let wanted_pair = DependencyPair::from_rule(rule.clone(), 0);
        let index = live.iter().enumerate().find_map(|(index, pair)| {
            (!used[index] && dependency_pair_rules_alpha_equivalent(pair, &wanted_pair))
                .then_some(index)
        })?;
        used[index] = true;
        retained.push(live[index].clone());
    }
    let removed = live
        .iter()
        .enumerate()
        .filter(|(index, _)| !used[*index])
        .map(|(_, pair)| pair.clone())
        .collect();
    Some((retained, removed))
}

fn select_live_rules(
    wanted: &[RewriteRule],
    live: &[RewriteRule],
) -> Option<(Vec<RewriteRule>, Vec<RewriteRule>)> {
    let mut retained = Vec::with_capacity(wanted.len());
    let mut used = vec![false; live.len()];
    for rule in wanted {
        let index = live.iter().enumerate().find_map(|(index, candidate)| {
            (!used[index] && super::alpha_equivalent_rules(rule, candidate)).then_some(index)
        })?;
        used[index] = true;
        retained.push(live[index].clone());
    }
    let removed = live
        .iter()
        .enumerate()
        .filter(|(index, _)| !used[*index])
        .map(|(_, rule)| rule.clone())
        .collect();
    Some((retained, removed))
}

impl WorklistProcessor for ExactDpNonterminationRuleRemovalProcessor {
    fn name(&self) -> &'static str {
        "exact-dp-nontermination-rule-removal"
    }

    fn apply(&self, state: &ProblemState) -> ProcessorResult {
        let trace = |reason: &str| {
            if std::env::var_os("FERRUM_EXACT_REPLAY_TIMING").is_some() {
                eprintln!("exact DP nontermination rule removal rejected: {reason}");
            }
        };
        let ProblemState::DependencyPairs(problem) = state else {
            return ProcessorResult::Inapplicable;
        };
        if !problem.stats.weak_pairs.is_empty() {
            trace("live problem has weak dependency pairs");
            return ProcessorResult::Inapplicable;
        }
        let Some((source_trs, source_pairs)) = parsed_ordinary_dp(&self.source_dp_input_xml) else {
            return ProcessorResult::Failed {
                reason: "invalid exact DP rule-removal source".to_owned(),
            };
        };
        let Some((residual_trs, residual_pairs)) = parsed_ordinary_dp(&self.residual_dp_input_xml)
        else {
            return ProcessorResult::Failed {
                reason: "invalid exact DP rule-removal residual".to_owned(),
            };
        };
        let Some((symbols, _)) = super::portable_trs_isomorphism(&source_trs, &problem.trs) else {
            trace("source TRS differs from live TRS");
            return ProcessorResult::Inapplicable;
        };
        let translated_source_pairs = source_pairs
            .iter()
            .map(|rule| translate_rule_symbols(rule, &symbols))
            .collect::<Vec<_>>();
        // A nontermination subproblem remains a sound witness when the live
        // problem has acquired additional pairs.  This occurs, for example,
        // when a later complete DP generator restores proper-subterm pairs
        // that an archived proof omitted: the retained source and residual
        // are still literal subsets of the live problem.  Requiring source
        // equality here made otherwise self-contained certified chains
        // representation-version dependent.
        if select_live_pairs(&translated_source_pairs, &problem.pairs).is_none() {
            trace("source dependency pairs are not a subset of the live dependency pairs");
            return ProcessorResult::Inapplicable;
        }
        let translated_residual_pairs = residual_pairs
            .iter()
            .map(|rule| translate_rule_symbols(rule, &symbols))
            .collect::<Vec<_>>();
        let translated_residual_rules = residual_trs
            .rules()
            .iter()
            .map(|rule| translate_rule_symbols(rule, &symbols))
            .collect::<Vec<_>>();
        let Some((retained_pairs, removed_pairs)) =
            select_live_pairs(&translated_residual_pairs, &problem.pairs)
        else {
            trace("residual dependency pairs are not a subset of the live pairs");
            return ProcessorResult::Inapplicable;
        };
        let Some((retained_rules, removed_rules)) =
            select_live_rules(&translated_residual_rules, problem.trs.rules())
        else {
            trace("residual ordinary rules are not a subset of the live rules");
            return ProcessorResult::Inapplicable;
        };
        if removed_pairs.is_empty() && removed_rules.is_empty() {
            trace("retained step removes neither pairs nor rules");
            return ProcessorResult::Inapplicable;
        }
        let mut child = problem.clone();
        child.pairs = retained_pairs;
        child.trs = Trs::new_with_strategy(
            problem.trs.name().map(str::to_owned),
            problem.trs.variables().clone(),
            retained_rules,
            problem.trs.strategy(),
        );
        child.stats.active_rules = None;
        child.stats.graph_rules = None;
        ProcessorResult::Applied(ProcessorApplication::new(
            vec![ProblemState::DependencyPairs(child)],
            move |children| {
                let [ProblemCertificate::DependencyPairNontermination(proof)] =
                    <[ProblemCertificate; 1]>::try_from(children).ok()?
                else {
                    return None;
                };
                Some(ProblemCertificate::DependencyPairNontermination(
                    crate::proving::DpNonterminationProof::DpRuleRemoval {
                        removed_pairs: removed_pairs.clone(),
                        removed_rules: removed_rules.clone(),
                        proof: Box::new(proof),
                    },
                ))
            },
        ))
    }
}

impl WorklistProcessor for DpNonterminationProcessor {
    fn name(&self) -> &'static str {
        "dependency-pair-nontermination"
    }

    fn apply(&self, state: &ProblemState) -> ProcessorResult {
        self.apply_search(state, find_dp_nontermination_witness)
    }
}

impl DpNonterminationProcessor {
    pub fn apply_fair_loop(&self, state: &ProblemState) -> ProcessorResult {
        self.apply_search(state, crate::proving::nontermination::fair_dp_loop_proof)
    }
    pub fn apply_fork_loop(&self, state: &ProblemState) -> ProcessorResult {
        self.apply_search(state, crate::proving::nontermination::fork_dp_loop_proof)
    }
    pub fn apply_backward_loop(&self, state: &ProblemState) -> ProcessorResult {
        self.apply_search(
            state,
            crate::proving::nontermination::backward_dp_loop_proof,
        )
    }
    pub fn apply_symbolic_loop(&self, state: &ProblemState) -> ProcessorResult {
        self.apply_search(
            state,
            crate::proving::nontermination::dp_symbolic_loop_proof,
        )
    }
    pub fn apply_nonloop(&self, state: &ProblemState) -> ProcessorResult {
        self.apply_search(
            state,
            crate::proving::nontermination::dp_nonloop_proof_with_deadline,
        )
    }

    fn apply_search(
        &self,
        state: &ProblemState,
        search: fn(
            &Trs,
            &[DependencyPair],
            Option<Instant>,
        ) -> Option<crate::proving::DpNonterminationProof>,
    ) -> ProcessorResult {
        let ProblemState::DependencyPairs(state) = state else {
            return ProcessorResult::Inapplicable;
        };
        if !state.stats.weak_pairs.is_empty() {
            return ProcessorResult::Inapplicable;
        }
        // An innermost DP loop needs explicit normal-form-substitution
        // evidence in CPF.  A checked concrete mixed loop is not by itself a
        // proof of that separate obligation, so this processor must not emit
        // an uncertifiable terminal answer for such a state.
        if state.trs.strategy() == RewriteStrategy::Innermost
            || state.stats.normal_form_substitutions
            || state.innermost_lhss.as_ref().is_some_and(|q| !q.is_empty())
        {
            return ProcessorResult::Inapplicable;
        }
        let active_trs = Trs::new_with_strategy(
            state.trs.name().map(str::to_owned),
            state.trs.variables().clone(),
            state
                .stats
                .active_rules
                .clone()
                .unwrap_or_else(|| state.trs.rules().to_vec()),
            state.trs.strategy(),
        );
        let Some(proof) = search(&active_trs, &state.pairs, self.deadline) else {
            return if self
                .deadline
                .is_some_and(|deadline| Instant::now() >= deadline)
            {
                ProcessorResult::TimedOut
            } else {
                ProcessorResult::Inapplicable
            };
        };
        ProcessorResult::Applied(ProcessorApplication::solved(
            ProblemCertificate::DependencyPairNontermination(proof),
        ))
    }
}

#[cfg(test)]
mod tests {
    use std::collections::BTreeSet;

    use crate::core::{RewriteRule, RewriteStrategy};
    use crate::core::{Term, Trs};
    use crate::proving::dependency_pairs::{DependencyPair, DpOptions};
    use crate::proving::processors::dp::DpProblemState;
    use crate::proving::processors::{
        ProblemCertificate, ProblemState, ProcessorResult, WorklistProcessor,
    };

    use super::{
        DpNonterminationProcessor, DpSwitchFullNonterminationProcessor, ExactDpLoopProcessor,
        ExactDpNonterminationRuleRemovalProcessor,
    };

    fn constant_pair(name: &str) -> DependencyPair {
        DependencyPair::new_for_test(
            Term::app(format!("{name}#"), Vec::new()),
            Term::app(format!("{name}#"), Vec::new()),
        )
    }

    fn singleton_dp_input(name: &str) -> String {
        format!(
            concat!(
                "<dpInput><trs><rules /></trs><dps><rules><rule>",
                "<funapp><sharp><name>{0}</name></sharp></funapp>",
                "<funapp><sharp><name>{0}</name></sharp></funapp>",
                "</rule></rules></dps><minimal>true</minimal></dpInput>"
            ),
            name
        )
    }

    #[test]
    fn exact_nontermination_terminals_translate_witness_symbols() {
        let rule = RewriteRule::new(Term::app("live", vec![]), Term::app("live", vec![]));
        let state = ProblemState::DependencyPairs(DpProblemState::ordinary(
            Trs::new(None, BTreeSet::new(), vec![rule]),
            vec![constant_pair("live")],
            DpOptions::default(),
        ));
        let source = singleton_dp_input("archived").replace("<rules />",
            "<rules><rule><funapp><name>archived</name></funapp><funapp><name>archived</name></funapp></rule></rules>");
        for tag in ["loop", "nonLoop"] {
            let term = "<funapp><sharp><name>payload_spelling</name></sharp></funapp>";
            let rule = format!("<rule>{term}{term}</rule>");
            let payload = if tag == "loop" {
                format!(
                    "<loop><rewriteSequence><startTerm>{term}</startTerm><rewriteStep><positionInTerm/>{rule}{term}</rewriteStep></rewriteSequence><substitution/><box/></loop>"
                )
            } else {
                format!(
                    "<nonLoop><originalRule>{rule}<isPair>true</isPair></originalRule></nonLoop>"
                )
            };
            let result = if tag == "loop" {
                ExactDpLoopProcessor {
                    source_dp_input_xml: source.clone(),
                    loop_xml: payload,
                }
                .apply(&state)
            } else {
                super::ExactDpNonLoopProcessor {
                    source_dp_input_xml: source.clone(),
                    non_loop_xml: payload,
                }
                .apply(&state)
            };
            let ProcessorResult::Applied(application) = result else {
                panic!("matching renamed terminal")
            };
            let Some(ProblemCertificate::DependencyPairNontermination(proof)) =
                application.reconstruct(vec![])
            else {
                panic!()
            };
            let xml = match proof {
                crate::proving::DpNonterminationProof::ExactLoopXml(xml)
                | crate::proving::DpNonterminationProof::ExactNonLoopXml(xml) => xml,
                _ => panic!(),
            };
            assert!(xml.contains("<name>live</name>"));
            assert!(!xml.contains("archived"));
        }
    }

    #[test]
    fn exact_nontermination_subproblem_accepts_additional_live_pairs() {
        let retained = constant_pair("p");
        let extra = constant_pair("q");
        let problem = DpProblemState::ordinary(
            Trs::new(None, BTreeSet::new(), Vec::new()),
            vec![retained.clone(), extra],
            DpOptions::default(),
        );
        let source = singleton_dp_input("p");
        let processor = ExactDpNonterminationRuleRemovalProcessor {
            source_dp_input_xml: source.clone(),
            residual_dp_input_xml: source,
        };

        let ProcessorResult::Applied(application) =
            processor.apply(&ProblemState::DependencyPairs(problem))
        else {
            panic!("a certified nontermination subproblem should survive added live pairs");
        };
        let [ProblemState::DependencyPairs(child)] = application.residuals.as_slice() else {
            panic!("expected one retained nontermination obligation");
        };
        assert_eq!(child.pairs, vec![retained]);
    }

    #[test]
    fn exact_nontermination_subproblem_rejects_missing_source_pair() {
        let problem = DpProblemState::ordinary(
            Trs::new(None, BTreeSet::new(), Vec::new()),
            vec![constant_pair("q")],
            DpOptions::default(),
        );
        let source = singleton_dp_input("p");
        let processor = ExactDpNonterminationRuleRemovalProcessor {
            source_dp_input_xml: source.clone(),
            residual_dp_input_xml: source,
        };

        assert!(matches!(
            processor.apply(&ProblemState::DependencyPairs(problem)),
            ProcessorResult::Inapplicable
        ));
    }

    #[test]
    fn exact_loop_accepts_additional_live_pairs() {
        let problem = DpProblemState::ordinary(
            Trs::new(None, BTreeSet::new(), Vec::new()),
            vec![constant_pair("p"), constant_pair("q")],
            DpOptions::default(),
        );
        let processor = ExactDpLoopProcessor {
            source_dp_input_xml: singleton_dp_input("p"),
            loop_xml: "<loop><rewriteSequence><startTerm><funapp><sharp><name>p</name></sharp></funapp></startTerm><rewriteStep><positionInTerm/><rule><funapp><sharp><name>p</name></sharp></funapp><funapp><sharp><name>p</name></sharp></funapp></rule><funapp><sharp><name>p</name></sharp></funapp></rewriteStep></rewriteSequence><substitution/><box/></loop>".to_owned(),
        };

        assert!(matches!(
            processor.apply(&ProblemState::DependencyPairs(problem)),
            ProcessorResult::Applied(_)
        ));
    }

    #[test]
    fn emits_a_solved_dp_nontermination_certificate() {
        let trs = Trs::new(None, BTreeSet::new(), Vec::new());
        let pair =
            DependencyPair::new_for_test(Term::app("f#", Vec::new()), Term::app("f#", Vec::new()));
        let state = ProblemState::DependencyPairs(DpProblemState::ordinary(
            trs,
            vec![pair],
            DpOptions::default(),
        ));
        let ProcessorResult::Applied(application) =
            (DpNonterminationProcessor { deadline: None }).apply(&state)
        else {
            panic!("self-loop must produce a DP nontermination witness");
        };
        assert!(application.residuals.is_empty());
        assert!(matches!(
            application.reconstruct(Vec::new()),
            Some(ProblemCertificate::DependencyPairNontermination(_))
        ));
    }

    #[test]
    fn native_no_search_preserves_active_rules_and_rejects_unchecked_q() {
        let rule = RewriteRule::new(Term::app("a", vec![]), Term::app("b", vec![]));
        let mut problem = DpProblemState::ordinary(
            Trs::new(None, BTreeSet::new(), vec![rule]),
            vec![constant_pair("p")],
            DpOptions::default(),
        );
        problem.stats.active_rules = Some(vec![]);
        let processor = DpNonterminationProcessor { deadline: None };
        assert!(matches!(
            processor.apply_search(
                &ProblemState::DependencyPairs(problem.clone()),
                |trs, _, _| {
                    assert!(trs.rules().is_empty());
                    None
                }
            ),
            ProcessorResult::Inapplicable
        ));
        problem.innermost_lhss = Some(vec![Term::app("a", vec![])]);
        assert!(matches!(
            processor.apply_search(&ProblemState::DependencyPairs(problem), |_, _, _| panic!(
                "Q must not be silently discarded"
            )),
            ProcessorResult::Inapplicable
        ));
    }

    #[test]
    fn native_nonloop_search_returns_a_pattern_not_a_loop() {
        let rule = RewriteRule::new(Term::app("ground", vec![]), Term::app("ground", vec![]));
        let pair = DependencyPair::new_for_test(
            Term::app("F", vec![Term::var("x")]),
            Term::app("F", vec![Term::app("s", vec![Term::var("x")])]),
        );
        let state = ProblemState::DependencyPairs(DpProblemState::ordinary(
            Trs::new(None, BTreeSet::new(), vec![rule]),
            vec![pair],
            DpOptions::default(),
        ));
        let ProcessorResult::Applied(application) =
            (DpNonterminationProcessor { deadline: None }).apply_nonloop(&state)
        else {
            panic!()
        };
        assert!(matches!(
            application.reconstruct(vec![]),
            Some(ProblemCertificate::DependencyPairNontermination(
                crate::proving::DpNonterminationProof::NonLoop(_)
            ))
        ));
    }

    #[test]
    fn rejects_innermost_dp_loop_without_explicit_nfs_evidence() {
        let trs = Trs::new_with_strategy(
            None,
            BTreeSet::new(),
            vec![RewriteRule::new(
                Term::app("f", vec![Term::var("x")]),
                Term::app("f", vec![Term::var("x")]),
            )],
            RewriteStrategy::Innermost,
        );
        let pair =
            DependencyPair::new_for_test(Term::app("f#", Vec::new()), Term::app("f#", Vec::new()));
        let state = ProblemState::DependencyPairs(DpProblemState::ordinary(
            trs,
            vec![pair],
            DpOptions::default(),
        ));
        assert!(matches!(
            (DpNonterminationProcessor { deadline: None }).apply(&state),
            ProcessorResult::Inapplicable
        ));
    }

    #[test]
    fn switch_full_nontermination_accepts_an_innermost_q_problem() {
        let trs = Trs::new_with_strategy(
            None,
            BTreeSet::new(),
            vec![RewriteRule::new(
                Term::app("a", vec![]),
                Term::app("b", vec![]),
            )],
            RewriteStrategy::Innermost,
        );
        let pair = constant_pair("f");
        let mut problem = DpProblemState::ordinary(trs, vec![pair], DpOptions::default());
        problem.innermost_lhss = Some(vec![Term::app("a", Vec::new())]);
        problem.stats.normal_form_substitutions = true;
        let mut invalid = problem.clone();
        invalid.innermost_lhss = Some(vec![Term::app("f", Vec::new())]);
        assert!(matches!(
            (DpSwitchFullNonterminationProcessor { deadline: None })
                .apply(&ProblemState::DependencyPairs(invalid)),
            ProcessorResult::Inapplicable
        ));

        let ProcessorResult::Applied(application) =
            (DpSwitchFullNonterminationProcessor { deadline: None })
                .apply(&ProblemState::DependencyPairs(problem))
        else {
            panic!("an innermost Q problem over a weakly confluent TRS should switch to full");
        };
        let [ProblemState::DependencyPairs(child)] = application.residuals.as_slice() else {
            panic!("expected one full-rewriting residual");
        };
        assert_eq!(child.trs.strategy(), RewriteStrategy::Full);
        assert!(child.innermost_lhss.is_none());
        assert!(child.stats.normal_form_substitutions);
        assert!(!child.stats.minimal);
    }

    #[test]
    fn switch_full_nontermination_checks_overlay_and_pair_overlap() {
        let x = Term::var("x");
        for (rules, lhs) in [
            (
                vec![RewriteRule::new(
                    Term::app("a", vec![]),
                    Term::app("b", vec![]),
                )],
                Term::app("call#", vec![Term::app("a", vec![])]),
            ),
            (
                vec![
                    RewriteRule::new(Term::app("a", vec![]), Term::app("b", vec![])),
                    RewriteRule::new(
                        Term::app("g", vec![Term::app("a", vec![])]),
                        Term::app("g", vec![Term::app("b", vec![])]),
                    ),
                ],
                Term::app("call#", vec![x.clone()]),
            ),
        ] {
            let q = rules.iter().map(|r| r.lhs().clone()).collect();
            let trs = Trs::new(None, x.variables(), rules);
            let pair = DependencyPair::new_for_test(lhs.clone(), lhs);
            let mut problem = DpProblemState::ordinary(trs, vec![pair], DpOptions::default());
            problem.innermost_lhss = Some(q);
            assert!(matches!(
                (DpSwitchFullNonterminationProcessor { deadline: None })
                    .apply(&ProblemState::DependencyPairs(problem)),
                ProcessorResult::Inapplicable
            ));
        }
    }
}
