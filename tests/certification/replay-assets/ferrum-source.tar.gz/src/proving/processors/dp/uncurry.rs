use std::collections::{BTreeMap, BTreeSet};
use std::time::Instant;

use crate::core::{RewriteRule, RewriteStrategy, Symbol, Term, Trs, Variable};
use crate::proving::UncurriedSymbolEntry;
use crate::proving::dependency_pairs::{
    DependencyPair, DpProofTree, DpUncurryingStep, strategy_timed_out,
};
use crate::proving::processors::top_level::uncurrying::infer_uncurrying_application_symbol;
use crate::proving::processors::top_level::uncurrying::synthesize_uncurrying_transform;
use crate::proving::runtime::CancellationScope;

use super::super::{
    ProblemCertificate, ProblemState, ProcessorApplication, ProcessorResult, WorklistProcessor,
};

pub struct UncurryProcessor {
    pub deadline: Option<Instant>,
}

pub struct UncurryBelowProcessor {
    pub deadline: Option<Instant>,
}

#[cfg(test)]
mod applicability_tests {
    use super::*;
    use crate::proving::dependency_pairs::DpOptions;
    use crate::proving::processors::dp::DpProblemState;

    #[test]
    fn proper_uncurrying_rejects_variable_heads_in_weak_pairs() {
        let app = |l, r| Term::app("app", vec![l, r]);
        let trs = Trs::new(None, Default::default(), vec![RewriteRule::new(
            app(Term::app("f", vec![]), Term::var("x")), Term::var("x"))]);
        assert!(synthesize_uncurrying_transform(&trs).is_some());
        let strict = DependencyPair::new(Term::app("F", vec![Term::var("x")]),
                                        Term::app("F", vec![Term::var("x")]), 0);
        let weak = DependencyPair::new(Term::app("G", vec![app(Term::var("u"), Term::var("v"))]),
                                      Term::app("G", vec![Term::var("u")]), 0);
        let mut problem = DpProblemState::ordinary(trs, vec![strict], DpOptions::default());
        problem.stats.weak_pairs.push(weak);
        assert!(matches!((UncurryBelowProcessor { deadline: None }).apply(
            &ProblemState::DependencyPairs(problem)), ProcessorResult::Inapplicable));
    }
}

impl WorklistProcessor for UncurryBelowProcessor {
    fn name(&self) -> &'static str {
        "dependency-pair-uncurry-below"
    }

    fn apply(&self, state: &ProblemState) -> ProcessorResult {
        let ProblemState::DependencyPairs(problem) = state else {
            return ProcessorResult::Inapplicable;
        };
        if problem.pairs.is_empty() || !problem.innermost_lhss.as_ref().is_none_or(Vec::is_empty) {
            return ProcessorResult::Inapplicable;
        }
        let cancellation = CancellationScope::current(self.deadline);
        if cancellation.is_cancelled() || strategy_timed_out(self.deadline) {
            return ProcessorResult::TimedOut;
        }
        let active_rules = problem
            .stats
            .active_rules
            .as_deref()
            .unwrap_or(problem.trs.rules());
        let active_trs = Trs::new_with_strategy(
            problem.trs.name().map(str::to_string),
            problem.trs.variables().clone(),
            active_rules.to_vec(),
            RewriteStrategy::Full,
        );
        let Some(transform) = synthesize_uncurrying_transform(&active_trs) else {
            if std::env::var_os("FERRUM_WORKLIST_TRACE").is_some() {
                eprintln!("uncurry-below: no proper-applicative transform");
            }
            return ProcessorResult::Inapplicable;
        };
        // Proper-applicative uncurrying checks hvf_term on P and Pw as well
        // as R. In particular, eta-generated weak pairs can contain a
        // variable-headed application below their marked root.
        if problem.pairs.iter().chain(&problem.stats.weak_pairs).any(|pair|
            crate::proving::processors::top_level::uncurrying::contains_variable_head_application(
                pair.lhs(), &transform.app_symbol)) {
            return ProcessorResult::Inapplicable;
        }
        // Eta saturation is supported by the underlying checker, but it
        // moves eta rules from R into P. Materialize that split separately
        // before admitting it here; the important proper-applicative RFC
        // residuals are already eta closed.
        if !transform.eta_rules.is_empty() {
            if std::env::var_os("FERRUM_WORKLIST_TRACE").is_some() {
                eprintln!(
                    "uncurry-below: eta saturation requires {} rules",
                    transform.eta_rules.len()
                );
            }
            return ProcessorResult::Inapplicable;
        }
        let mut symbols = transform.symbols.clone();
        let mapped_inputs = symbols
            .iter()
            .map(|entry| (entry.original.clone(), entry.arity))
            .collect::<BTreeSet<_>>();
        let mut occupied_outputs = symbols
            .iter()
            .flat_map(|entry| entry.symbols.iter().cloned())
            .collect::<BTreeSet<_>>();
        occupied_outputs.extend(problem.trs.arities().keys().cloned());
        let mut pair_signatures = BTreeMap::new();
        for pair in &problem.pairs {
            collect_arities(pair.lhs(), &mut pair_signatures);
            collect_arities(pair.rhs(), &mut pair_signatures);
        }
        let mut extra_mapping = BTreeMap::new();
        for (symbol, arity) in pair_signatures {
            if symbol == transform.app_symbol || mapped_inputs.contains(&(symbol.clone(), arity)) {
                continue;
            }
            let mapped = if !symbols.iter().any(|entry| {
                entry
                    .symbols
                    .iter()
                    .enumerate()
                    .any(|(index, output)| output == &symbol && entry.arity + index == arity)
            }) {
                symbol.clone()
            } else {
                fresh_symbol(&mut occupied_outputs)
            };
            symbols.push(UncurriedSymbolEntry {
                original: symbol.clone(),
                arity,
                symbols: vec![mapped.clone()],
            });
            extra_mapping.insert((symbol, arity), mapped);
        }
        let transformed_pairs = problem
            .pairs
            .iter()
            .map(|pair| {
                DependencyPair::new(
                    rename_signatures(transform.transform_term(pair.lhs()), &extra_mapping),
                    rename_signatures(transform.transform_term(pair.rhs()), &extra_mapping),
                    pair.source_rule(),
                )
            })
            .collect::<Vec<_>>();
        let transformed_weak_pairs = problem
            .pairs
            .iter()
            .zip(&transformed_pairs)
            .filter_map(|(source, transformed)| {
                problem
                    .stats
                    .weak_pairs
                    .contains(source)
                    .then_some(transformed.clone())
            })
            .collect::<Vec<_>>();
        let transformed_rules = transform.transformed.rules().to_vec();
        let step = DpUncurryingStep {
            app_symbol: transform.app_symbol.clone(),
            applicative_top: None,
            symbols,
            // In CPF's ordinary uncurrying processor U belongs to Rw, not
            // Pw. It is therefore present in `transformed_rules` and remains
            // available to the subsequent certified usable-rules processor.
            uncurry_rules: transform.uncurry_rules.clone(),
            eta_rules: Vec::new(),
            transformed_pairs: transformed_pairs.clone(),
            transformed_rules: transformed_rules.clone(),
        };
        let mut residual = problem.clone();
        residual.trs = Trs::new_with_strategy(
            problem.trs.name().map(str::to_string),
            problem.trs.variables().clone(),
            transformed_rules,
            RewriteStrategy::Full,
        );
        residual.pairs = transformed_pairs;
        residual.stats.weak_pairs = transformed_weak_pairs;
        residual.stats.active_rules = Some(residual.trs.rules().to_vec());
        residual.stats.graph_rules = Some(residual.trs.rules().to_vec());
        residual.stats.transformation_rules = None;
        residual.innermost_lhss = None;

        ProcessorResult::Applied(ProcessorApplication::new(
            vec![ProblemState::DependencyPairs(residual)],
            move |children| {
                let [ProblemCertificate::DependencyPairTree(proof)] =
                    <[ProblemCertificate; 1]>::try_from(children).ok()?
                else {
                    return None;
                };
                Some(ProblemCertificate::DependencyPairTree(
                    DpProofTree::Uncurry {
                        step: Box::new(step.clone()),
                        proof: Box::new(proof),
                    },
                ))
            },
        ))
    }
}

impl WorklistProcessor for UncurryProcessor {
    fn name(&self) -> &'static str {
        "dependency-pair-uncurry"
    }

    fn apply(&self, state: &ProblemState) -> ProcessorResult {
        let ProblemState::DependencyPairs(problem) = state else {
            return ProcessorResult::Inapplicable;
        };
        if problem.pairs.is_empty() {
            return ProcessorResult::Inapplicable;
        }
        let cancellation = CancellationScope::current(self.deadline);
        if cancellation.is_cancelled() || strategy_timed_out(self.deadline) {
            return ProcessorResult::TimedOut;
        }
        let q_is_empty = problem.innermost_lhss.as_ref().is_some_and(Vec::is_empty)
            || (problem.trs.strategy() == RewriteStrategy::Full
                && problem.innermost_lhss.is_none());
        if !q_is_empty {
            return ProcessorResult::Inapplicable;
        }
        let active_rules = problem
            .stats
            .active_rules
            .as_deref()
            .unwrap_or(problem.trs.rules());
        let Some(step) =
            synthesize_applicative_top_uncurrying(&problem.trs, &problem.pairs, active_rules)
        else {
            return ProcessorResult::Inapplicable;
        };
        let mut residual = problem.clone();
        residual.trs = Trs::new_with_strategy(
            problem.trs.name().map(str::to_string),
            problem.trs.variables().clone(),
            step.transformed_rules.clone(),
            RewriteStrategy::Full,
        );
        residual.pairs = step.transformed_pairs.clone();
        let transformed_input_pair_count = problem.pairs.len();
        let transformed_eta_pair_count = step.eta_rules.len();
        residual.stats.weak_pairs = problem
            .pairs
            .iter()
            .zip(
                step.transformed_pairs
                    .iter()
                    .take(transformed_input_pair_count),
            )
            .filter_map(|(source, transformed)| {
                problem
                    .stats
                    .weak_pairs
                    .contains(source)
                    .then_some(transformed.clone())
            })
            .chain(
                step.transformed_pairs
                    .iter()
                    // Eta expansions of the strict rules become strict pairs
                    // in CPF's applicative-top processor.  Only the generated
                    // uncurrying rules belong to the weak-pair component.
                    .skip(transformed_input_pair_count + transformed_eta_pair_count)
                    .cloned(),
            )
            .collect();
        residual.stats.active_rules = Some(residual.trs.rules().to_vec());
        residual.stats.graph_rules = Some(residual.trs.rules().to_vec());
        residual.stats.transformation_rules = None;
        residual.innermost_lhss = None;

        ProcessorResult::Applied(ProcessorApplication::new(
            vec![ProblemState::DependencyPairs(residual)],
            move |children| {
                let [ProblemCertificate::DependencyPairTree(proof)] =
                    <[ProblemCertificate; 1]>::try_from(children).ok()?
                else {
                    return None;
                };
                Some(ProblemCertificate::DependencyPairTree(
                    DpProofTree::Uncurry {
                        step: Box::new(step.clone()),
                        proof: Box::new(proof),
                    },
                ))
            },
        ))
    }
}

pub(crate) fn synthesize_applicative_top_uncurrying(
    trs: &Trs,
    pairs: &[DependencyPair],
    active_rules: &[RewriteRule],
) -> Option<DpUncurryingStep> {
    let (app_symbol, applicative_top) = root_signature(pairs.first()?.lhs())?;
    // Unary marked wrappers in the transformed-CSR `_C` encoding require an
    // eta-saturated applicative-top transformation.  The eta-free processor
    // below is sound only for genuine spines with at least one argument after
    // the head.  Do not misclassify `top#(f(...))` and emit a proof that CeTA
    // will reject for its missing eta expansion.
    if applicative_top <= 1 || !app_symbol.as_str().ends_with('#') {
        return None;
    }
    if pairs
        .iter()
        .any(|pair| root_signature(pair.lhs()) != Some((app_symbol.clone(), applicative_top)))
    {
        return None;
    }
    // This is exactly CeTA's `hvf_top` side condition. Substituting a
    // variable-headed applicative spine does not commute with the top
    // uncurrying map, so such a DP problem is outside this processor.
    if pairs.iter().any(|pair| {
        matches!(
            pair.lhs(),
            Term::App { symbol, args }
                if symbol == &app_symbol
                    && args.len() == applicative_top
                    && args.first().is_some_and(|head| matches!(head, Term::Var(_)))
        )
    }) {
        return None;
    }
    let mut arities = trs.arities();
    for pair in pairs {
        collect_arities(pair.lhs(), &mut arities);
        collect_arities(pair.rhs(), &mut arities);
    }
    let mut expandable = BTreeSet::new();
    for pair in pairs {
        collect_head_signature(pair.lhs(), &app_symbol, applicative_top, &mut expandable);
        collect_head_signature(pair.rhs(), &app_symbol, applicative_top, &mut expandable);
    }
    expandable.remove(&(app_symbol.clone(), applicative_top));
    // A marked symbol of arity two or more is not by itself an application
    // symbol: ordinary DPs such as `log#(x,y)` and `f#(x,y,z)` have exactly
    // that shape.  In a genuine applicative-top DP, the first argument of the
    // marked application contains the corresponding unmarked application
    // spine (for example `app#(app(f,x),y)`).  Pin that structural witness;
    // otherwise the eta-free transformation below is not applicable.
    let base_symbol = Symbol::new(app_symbol.as_str().strip_suffix('#')?);
    if !expandable.contains(&(base_symbol.clone(), applicative_top))
        && infer_uncurrying_application_symbol(trs).as_ref() != Some(&base_symbol)
    {
        return None;
    }
    if expandable.is_empty() {
        return None;
    }
    let mut occupied = arities.keys().cloned().collect::<BTreeSet<_>>();
    let expanded_symbols = expandable
        .iter()
        .map(|(symbol, arity)| {
            let expanded_arity = arity + applicative_top - 1;
            (
                (symbol.clone(), *arity),
                (fresh_symbol(&mut occupied), expanded_arity),
            )
        })
        .collect::<BTreeMap<_, _>>();
    let mut signatures = arities.into_iter().collect::<Vec<_>>();
    signatures.retain(|signature| signature != &(app_symbol.clone(), applicative_top));
    signatures.sort();
    let symbols = signatures
        .into_iter()
        .map(|(symbol, arity)| {
            let mut mapped = vec![symbol.clone()];
            if let Some((expanded, _)) = expanded_symbols.get(&(symbol.clone(), arity)) {
                mapped.push(expanded.clone());
            }
            UncurriedSymbolEntry {
                original: symbol,
                arity,
                symbols: mapped,
            }
        })
        .collect::<Vec<_>>();
    let all_uncurry_rules = expanded_symbols
        .iter()
        .map(|((symbol, arity), (expanded, _))| {
            uncurry_rule(&app_symbol, applicative_top, symbol, *arity, expanded)
        })
        .collect::<Vec<_>>();
    let requires_uncurry_pairs = pairs.iter().any(|pair| {
        let Term::App { symbol, args } = pair.rhs() else {
            return false;
        };
        symbol == &app_symbol
            && args.len() == applicative_top
            && args.first().is_some_and(|head| match head {
                Term::Var(_) => true,
                Term::App { symbol, .. } => active_rules
                    .iter()
                    .any(|rule| rule.lhs().root_symbol() == Some(symbol)),
            })
    });
    let uncurry_rules = requires_uncurry_pairs
        .then_some(all_uncurry_rules)
        .unwrap_or_default();
    // `uncurry_top_proc` moves eta expansions of strict rules from R into P
    // before uncurrying.  CeTA requires this closure whenever an applicative
    // right-hand side can expose a reducible head.  The signature map created
    // above has positive applicative arity exactly for the entries in
    // `expanded_symbols`, so materialize one top eta pair (with n - 1 fresh
    // arguments) for every such active rule.
    let eta_rules = active_rules
        .iter()
        .filter(|rule| {
            root_signature(rule.lhs())
                .is_some_and(|signature| expanded_symbols.contains_key(&signature))
        })
        .map(|rule| eta_expand_top_rule(rule, &app_symbol, applicative_top))
        .collect::<Vec<_>>();
    let mut transformed_pairs = pairs
        .iter()
        .map(|pair| {
            DependencyPair::new(
                uncurry_top(pair.lhs(), &app_symbol, applicative_top, &expanded_symbols),
                uncurry_top(pair.rhs(), &app_symbol, applicative_top, &expanded_symbols),
                pair.source_rule(),
            )
        })
        .collect::<Vec<_>>();
    transformed_pairs.extend(eta_rules.iter().map(|rule| {
        DependencyPair::new(
            uncurry_top(rule.lhs(), &app_symbol, applicative_top, &expanded_symbols),
            uncurry_top(rule.rhs(), &app_symbol, applicative_top, &expanded_symbols),
            pairs[0].source_rule(),
        )
    }));
    transformed_pairs.extend(
        uncurry_rules
            .iter()
            .cloned()
            .map(|rule| DependencyPair::from_rule(rule, pairs[0].source_rule())),
    );
    transformed_pairs.dedup();
    Some(DpUncurryingStep {
        app_symbol,
        applicative_top: Some(applicative_top),
        symbols,
        uncurry_rules,
        eta_rules,
        transformed_pairs,
        transformed_rules: active_rules.to_vec(),
    })
}

fn eta_expand_top_rule(
    rule: &RewriteRule,
    app_symbol: &Symbol,
    applicative_top: usize,
) -> RewriteRule {
    let mut occupied = rule.lhs().variables();
    occupied.extend(rule.rhs().variables());
    let mut fresh = Vec::with_capacity(applicative_top.saturating_sub(1));
    for index in 0..applicative_top.saturating_sub(1) {
        let mut suffix = index;
        loop {
            let variable = Variable::new(format!("__ferrum_eta{suffix}"));
            if occupied.insert(variable.clone()) {
                fresh.push(Term::Var(variable));
                break;
            }
            suffix += applicative_top.max(1);
        }
    }
    let mut lhs_args = vec![rule.lhs().clone()];
    lhs_args.extend(fresh.iter().cloned());
    let mut rhs_args = vec![rule.rhs().clone()];
    rhs_args.extend(fresh);
    RewriteRule::new(
        Term::App {
            symbol: app_symbol.clone(),
            args: lhs_args,
        },
        Term::App {
            symbol: app_symbol.clone(),
            args: rhs_args,
        },
    )
}

fn root_signature(term: &Term) -> Option<(Symbol, usize)> {
    match term {
        Term::Var(_) => None,
        Term::App { symbol, args } => Some((symbol.clone(), args.len())),
    }
}

fn collect_arities(term: &Term, arities: &mut BTreeMap<Symbol, usize>) {
    if let Term::App { symbol, args } = term {
        arities.insert(symbol.clone(), args.len());
        for argument in args {
            collect_arities(argument, arities);
        }
    }
}

fn rename_signatures(term: Term, mapping: &BTreeMap<(Symbol, usize), Symbol>) -> Term {
    match term {
        Term::Var(variable) => Term::Var(variable),
        Term::App { symbol, args } => {
            let arity = args.len();
            Term::App {
                symbol: mapping
                    .get(&(symbol.clone(), arity))
                    .cloned()
                    .unwrap_or(symbol),
                args: args
                    .into_iter()
                    .map(|argument| rename_signatures(argument, mapping))
                    .collect(),
            }
        }
    }
}

fn collect_head_signature(
    term: &Term,
    app_symbol: &Symbol,
    applicative_top: usize,
    signatures: &mut BTreeSet<(Symbol, usize)>,
) {
    let Term::App { symbol, args } = term else {
        return;
    };
    if symbol == app_symbol
        && args.len() == applicative_top
        && let Some(Term::App { symbol: head, args }) = args.first()
    {
        signatures.insert((head.clone(), args.len()));
    }
}

fn fresh_symbol(occupied: &mut BTreeSet<Symbol>) -> Symbol {
    for index in 0usize.. {
        let candidate = Symbol::new(format!("__ferrum_dp_u{index}#"));
        if occupied.insert(candidate.clone()) {
            return candidate;
        }
    }
    unreachable!()
}

fn uncurry_rule(
    app_symbol: &Symbol,
    applicative_top: usize,
    head: &Symbol,
    head_arity: usize,
    expanded: &Symbol,
) -> RewriteRule {
    let head_args = (0..head_arity)
        .map(|index| Term::var(format!("u{index}")))
        .collect::<Vec<_>>();
    let tail_args = (0..applicative_top.saturating_sub(1))
        .map(|index| Term::var(format!("u{}", head_arity + index)))
        .collect::<Vec<_>>();
    let mut lhs_args = vec![Term::App {
        symbol: head.clone(),
        args: head_args.clone(),
    }];
    lhs_args.extend(tail_args.iter().cloned());
    let mut rhs_args = head_args;
    rhs_args.extend(tail_args);
    RewriteRule::new(
        Term::App {
            symbol: app_symbol.clone(),
            args: lhs_args,
        },
        Term::App {
            symbol: expanded.clone(),
            args: rhs_args,
        },
    )
}

fn uncurry_top(
    term: &Term,
    app_symbol: &Symbol,
    applicative_top: usize,
    expanded: &BTreeMap<(Symbol, usize), (Symbol, usize)>,
) -> Term {
    let Term::App { symbol, args } = term else {
        return term.clone();
    };
    if symbol == app_symbol
        && args.len() == applicative_top
        && let Some(Term::App {
            symbol: head,
            args: head_args,
        }) = args.first()
        && let Some((expanded_symbol, _)) = expanded.get(&(head.clone(), head_args.len()))
    {
        let mut expanded_args = head_args.iter().map(uncurry_below).collect::<Vec<_>>();
        expanded_args.extend(args[1..].iter().map(uncurry_below));
        return Term::App {
            symbol: expanded_symbol.clone(),
            args: expanded_args,
        };
    }
    Term::App {
        symbol: symbol.clone(),
        args: args.iter().map(uncurry_below).collect(),
    }
}

fn uncurry_below(term: &Term) -> Term {
    match term {
        Term::Var(variable) => Term::Var(variable.clone()),
        Term::App { symbol, args } => Term::App {
            symbol: symbol.clone(),
            args: args.iter().map(uncurry_below).collect(),
        },
    }
}
