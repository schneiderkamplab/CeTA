use std::time::Instant;

use crate::core::{RewriteStrategy, Trs};
use crate::proving::dependency_pairs::{
    CsrDpConstruction, DpProblemContext, DpProofTree, dp_pairs_overlap_rules, strategy_timed_out,
};
use crate::proving::processors::rewrite_analysis::weak_confluence_witness_depth;
use crate::proving::runtime::CancellationScope;

use super::super::{
    ProblemCertificate, ProblemState, ProcessorApplication, ProcessorResult, WorklistProcessor,
};

pub struct SwitchInnermostProcessor {
    pub deadline: Option<Instant>,
}

impl WorklistProcessor for SwitchInnermostProcessor {
    fn name(&self) -> &'static str {
        "dependency-pair-switch-innermost"
    }

    fn apply(&self, state: &ProblemState) -> ProcessorResult {
        let ProblemState::DependencyPairs(problem) = state else {
            return ProcessorResult::Inapplicable;
        };
        let ordinary_boundary = matches!(problem.stats.problem, DpProblemContext::Ordinary)
            || matches!(
                &problem.stats.problem,
                DpProblemContext::ContextSensitive(context)
                    if context.construction == CsrDpConstruction::MutermUnhiding
            );
        if problem.trs.strategy() != RewriteStrategy::Full
            || !problem.stats.minimal
            || !ordinary_boundary
            || problem
                .innermost_lhss
                .as_ref()
                .is_some_and(|lhss| !lhss.is_empty())
            || !problem.stats.weak_pairs.is_empty()
        {
            return ProcessorResult::Inapplicable;
        }
        let cancellation = CancellationScope::current(self.deadline);
        if cancellation.is_cancelled() || strategy_timed_out(self.deadline) {
            return ProcessorResult::TimedOut;
        }
        let active_rules = problem
            .stats
            .active_rules
            .clone()
            .unwrap_or_else(|| problem.trs.rules().to_vec());
        if dp_pairs_overlap_rules(&problem.pairs, &active_rules) {
            return ProcessorResult::Inapplicable;
        }
        let full_trs = Trs::new_with_strategy(
            problem.trs.name().map(str::to_string),
            problem.trs.variables().clone(),
            active_rules.clone(),
            RewriteStrategy::Full,
        );
        let Some(wcr_depth) = weak_confluence_witness_depth(&full_trs) else {
            return ProcessorResult::Inapplicable;
        };
        let q_lhss = active_rules
            .iter()
            .map(|rule| rule.lhs().clone())
            .collect::<Vec<_>>();
        let mut residual = problem.clone();
        residual.trs = Trs::new_with_strategy(
            problem.trs.name().map(str::to_string),
            problem.trs.variables().clone(),
            active_rules.clone(),
            RewriteStrategy::Innermost,
        );
        residual.stats.active_rules = Some(active_rules.clone());
        residual.stats.graph_rules = Some(active_rules.clone());
        residual.stats.transformation_rules = Some(active_rules);
        // switchInnermostProc changes the chain obligation itself: the
        // substitutions at dependency-pair steps are now required to be
        // normal forms.  Record that invariant on the residual so the
        // innermost narrowing, rewriting, and usable-rule processors can use
        // their certified variants.  Merely changing the TRS strategy while
        // leaving this flag false made a serialized residual weaker than the
        // proof problem established by the switch processor.
        residual.stats.normal_form_substitutions = true;
        residual.innermost_lhss = Some(q_lhss.clone());

        ProcessorResult::Applied(ProcessorApplication::new(
            vec![ProblemState::DependencyPairs(residual)],
            move |children| {
                let [ProblemCertificate::DependencyPairTree(proof)] =
                    <[ProblemCertificate; 1]>::try_from(children).ok()?
                else {
                    return None;
                };
                Some(ProblemCertificate::DependencyPairTree(
                    DpProofTree::SwitchInnermost {
                        wcr_depth,
                        innermost_lhss: q_lhss.clone(),
                        proof: Box::new(proof),
                    },
                ))
            },
        ))
    }
}
