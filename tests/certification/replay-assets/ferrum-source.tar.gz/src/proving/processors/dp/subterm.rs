use std::collections::BTreeSet;
use std::time::Instant;

use crate::proving::dependency_pairs::{
    CsrDpConstruction, CsrDpProblemContext, DpProblemContext, DpProofTree,
    DpSubtermProjectionEntry, dp_rhs_roots_are_constructors, strategy_timed_out,
    subterm_graphs_for_projection_entries_with_csr, subterm_strict_pairs_for_projection_with_csr,
    synthesize_projection_subterm_criterion,
};
use crate::proving::runtime::CancellationScope;

use super::super::{
    ProblemCertificate, ProblemState, ProcessorApplication, ProcessorResult, WorklistProcessor,
};

pub struct SubtermProcessor {
    pub deadline: Option<Instant>,
}

pub struct ExactSubtermProcessor {
    pub projection: Vec<(String, usize, usize)>,
    pub deadline: Option<Instant>,
}

fn subterm_is_applicable(problem: &crate::proving::processors::dp::DpProblemState) -> bool {
    if !problem.stats.weak_pairs.is_empty()
        || !problem.stats.minimal
        || problem.stats.ordinary_bridge_loses_minimality
    {
        return false;
    }
    matches!(
        problem.stats.problem,
        DpProblemContext::ContextSensitive(CsrDpProblemContext {
            construction: CsrDpConstruction::Improved,
            ..
        })
    ) || dp_rhs_roots_are_constructors(
        &problem.pairs,
        problem
            .stats
            .active_rules
            .as_deref()
            .unwrap_or(problem.trs.rules()),
    )
}

fn apply_projection(
    problem: &crate::proving::processors::dp::DpProblemState,
    projection: Vec<DpSubtermProjectionEntry>,
) -> ProcessorResult {
    let projection_map = projection
        .iter()
        .map(|entry| (entry.symbol.clone(), entry.position))
        .collect();
    let improved_csr = match &problem.stats.problem {
        DpProblemContext::ContextSensitive(CsrDpProblemContext {
            csr,
            construction: CsrDpConstruction::Improved,
            ..
        }) => Some(csr),
        _ => None,
    };
    let Some(strict_indices) =
        subterm_strict_pairs_for_projection_with_csr(&problem.pairs, &projection_map, improved_csr)
    else {
        return ProcessorResult::Inapplicable;
    };
    if strict_indices.is_empty() {
        return ProcessorResult::Inapplicable;
    }
    let Some(graphs) =
        subterm_graphs_for_projection_entries_with_csr(&problem.pairs, &projection, improved_csr)
    else {
        return ProcessorResult::Inapplicable;
    };
    let strict = strict_indices.iter().copied().collect::<BTreeSet<_>>();
    let graph_strict = graphs
        .iter()
        .enumerate()
        .filter_map(|(index, graph)| graph.edges.iter().any(|edge| edge.strict).then_some(index))
        .collect::<BTreeSet<_>>();
    if strict != graph_strict {
        return ProcessorResult::Inapplicable;
    }
    let strict_pairs = problem
        .pairs
        .iter()
        .enumerate()
        .filter_map(|(index, pair)| strict.contains(&index).then_some(pair.clone()))
        .collect::<Vec<_>>();
    let residual_pairs = problem
        .pairs
        .iter()
        .enumerate()
        .filter_map(|(index, pair)| (!strict.contains(&index)).then_some(pair.clone()))
        .collect::<Vec<_>>();
    let mut residual = problem.clone();
    residual.pairs = residual_pairs;
    ProcessorResult::Applied(ProcessorApplication::new(
        vec![ProblemState::DependencyPairs(residual)],
        move |children| {
            let [ProblemCertificate::DependencyPairTree(proof)] =
                <[ProblemCertificate; 1]>::try_from(children).ok()?
            else {
                return None;
            };
            Some(ProblemCertificate::DependencyPairTree(
                DpProofTree::Subterm {
                    projection: projection.clone(),
                    strict_pairs: strict_pairs.clone(),
                    graphs: graphs.clone(),
                    proof: Box::new(proof),
                },
            ))
        },
    ))
}

impl WorklistProcessor for ExactSubtermProcessor {
    fn name(&self) -> &'static str {
        "dependency-pair-exact-subterm"
    }

    fn apply(&self, state: &ProblemState) -> ProcessorResult {
        let ProblemState::DependencyPairs(problem) = state else {
            return ProcessorResult::Inapplicable;
        };
        let cancellation = CancellationScope::current(self.deadline);
        if cancellation.is_cancelled() || strategy_timed_out(self.deadline) {
            return ProcessorResult::TimedOut;
        }
        if !subterm_is_applicable(problem) {
            return ProcessorResult::Inapplicable;
        }
        let projection = self
            .projection
            .iter()
            .map(|(symbol, arity, position)| DpSubtermProjectionEntry {
                symbol: crate::core::Symbol::new(symbol),
                arity: *arity,
                position: *position,
            })
            .collect();
        apply_projection(problem, projection)
    }
}

impl WorklistProcessor for SubtermProcessor {
    fn name(&self) -> &'static str {
        "dependency-pair-subterm"
    }

    fn apply(&self, state: &ProblemState) -> ProcessorResult {
        let ProblemState::DependencyPairs(problem) = state else {
            return ProcessorResult::Inapplicable;
        };
        let cancellation = CancellationScope::current(self.deadline);
        if cancellation.is_cancelled() || strategy_timed_out(self.deadline) {
            return ProcessorResult::TimedOut;
        }
        if !subterm_is_applicable(problem) {
            return ProcessorResult::Inapplicable;
        }

        let Some((projection, _)) = synthesize_projection_subterm_criterion(
            &problem.pairs,
            &problem.options,
            self.deadline,
            match &problem.stats.problem {
                DpProblemContext::ContextSensitive(CsrDpProblemContext {
                    csr,
                    construction: CsrDpConstruction::Improved,
                    ..
                }) => Some(csr),
                _ => None,
            },
        ) else {
            return ProcessorResult::Inapplicable;
        };
        apply_projection(problem, projection)
    }
}
