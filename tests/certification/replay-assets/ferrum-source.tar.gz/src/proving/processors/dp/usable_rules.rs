use crate::core::{CsrTrs, RewriteStrategy, Trs};
use crate::proving::dependency_pairs::{
    CsrDpConstruction, CsrGraphEstimator, DpProblemContext, DpProofTree,
    improved_qcs_certificate_usable_rules, innermost_csr_usable_rules,
    qcs_certificate_usable_rules, usable_rules_in_innermost_context,
};

use super::super::{
    ProblemCertificate, ProblemState, ProcessorApplication, ProcessorResult, WorklistProcessor,
};
use super::initial_innermost_lhss;

fn term_contains_symbol(term: &crate::core::Term, needle: &crate::core::Symbol) -> bool {
    match term {
        crate::core::Term::Var(_) => false,
        crate::core::Term::App { symbol, args } => {
            symbol == needle
                || args
                    .iter()
                    .any(|argument| term_contains_symbol(argument, needle))
        }
    }
}

fn rule_multiset_is_alpha_subset(
    subset: &[crate::core::RewriteRule],
    superset: &[crate::core::RewriteRule],
) -> bool {
    let mut remaining = superset.to_vec();
    subset.iter().all(|rule| {
        let Some(index) = remaining
            .iter()
            .position(|other| super::general_red_pair::alpha_equivalent_rules(rule, other))
        else {
            return false;
        };
        remaining.swap_remove(index);
        true
    })
}

/// Validate the cheap usable-rule witness supplied by the complete GM04
/// transformation.
///
/// The transformed TRS consists of the non-top administrative system `S`
/// plus two rules rooted by `top`.  CeTA's innermost usable-rule closure can
/// only add a rule when its left-root occurs in a current right-hand side;
/// recursively, newly admitted rules contribute their own right-hand sides.
/// Consequently `S` is a sound (deliberately generous) usable-rule set when
/// `top` occurs in neither a DP right-hand side nor a right-hand side of `S`.
/// The remaining executable side conditions are checked here as well.  The
/// emitted CPF is still the ordinary `<usableRulesProc>`, so CeTA independently
/// repeats the full closure check.
fn gm04_usable_rules_candidate(
    problem: &crate::proving::processors::dp::DpProblemState,
    input_rules: &[crate::core::RewriteRule],
    innermost_lhss: Option<&[crate::core::Term]>,
) -> Option<Vec<crate::core::RewriteRule>> {
    let context = problem.options.gm04_residual.as_ref()?;
    if !matches!(problem.stats.problem, DpProblemContext::Ordinary)
        || problem.trs.strategy() != RewriteStrategy::Innermost
        || innermost_lhss.is_none_or(<[_]>::is_empty)
        || problem
            .pairs
            .iter()
            .any(|pair| !pair.rhs().variables().is_subset(&pair.lhs().variables()))
    {
        return None;
    }

    let retained = &context.rules;
    let active_trs = Trs::new_with_strategy(
        problem.trs.name().map(str::to_owned),
        problem.trs.variables().clone(),
        input_rules.to_vec(),
        problem.trs.strategy(),
    );
    let computed = usable_rules_in_innermost_context(&active_trs, &problem.pairs, innermost_lhss);
    // `retained` may deliberately omit administrative rules for constructors
    // that occur only in the transformed signature.  It remains a valid
    // usable-rule superset precisely when it contains the independently
    // computed closure and is itself drawn from the live rule multiset.
    if !rule_multiset_is_alpha_subset(retained, input_rules)
        || !rule_multiset_is_alpha_subset(&computed, retained)
        || problem
            .pairs
            .iter()
            .any(|pair| term_contains_symbol(pair.rhs(), &context.top))
        || retained
            .iter()
            .any(|rule| term_contains_symbol(rule.rhs(), &context.top))
    {
        return None;
    }
    Some(retained.clone())
}

/// Replace the active rule obligation by the certified usable-rule closure.
///
/// This processor changes only `R`. Innermost-LHS reduction is a separate
/// atom, so both residual states are independently serializable and guided.
pub struct UsableRulesProcessor;

impl WorklistProcessor for UsableRulesProcessor {
    fn name(&self) -> &'static str {
        "dependency-pair-usable-rules"
    }

    fn apply(&self, state: &ProblemState) -> ProcessorResult {
        let ProblemState::DependencyPairs(problem) = state else {
            return ProcessorResult::Inapplicable;
        };
        if !problem.stats.minimal
            && !(matches!(problem.stats.problem, DpProblemContext::Ordinary)
                && problem.trs.strategy() == RewriteStrategy::Innermost)
        {
            return ProcessorResult::Inapplicable;
        }
        let input_rules = problem
            .stats
            .active_rules
            .as_deref()
            .unwrap_or(problem.trs.rules());
        if matches!(
            &problem.stats.problem,
            DpProblemContext::ContextSensitive(context)
                if context.construction == CsrDpConstruction::Innermost
                    && context.graph_estimator == CsrGraphEstimator::ContextSensitive
        ) {
            // Native innermost-CSR proofs use the replacement-map-aware
            // checker. Its current usable-rules node is conservative, so an
            // empty direct-unhiding usable set must not be exported here.
            return ProcessorResult::Inapplicable;
        }
        let initial_lhss;
        let innermost_lhss = if let Some(lhss) = problem.innermost_lhss.as_deref() {
            Some(lhss)
        } else {
            initial_lhss = initial_innermost_lhss(&problem.trs);
            initial_lhss.as_deref()
        };
        let gm04_candidate = gm04_usable_rules_candidate(problem, input_rules, innermost_lhss)
            .filter(|usable| usable.as_slice() != input_rules);
        // Typed MU-TERM local obligations range over R and the generated
        // unhiding bridges, not R alone. Compute the same pair-local closure
        // used by native MU-TERM reduction-pair search; no retained rule set
        // or model is needed. Other frameworks must not acquire these rules.
        let mut allowed_rules = input_rules.to_vec();
        if let DpProblemContext::ContextSensitive(context) = &problem.stats.problem
            && context.construction == CsrDpConstruction::MutermUnhiding
        {
            for rule in
                crate::proving::dependency_pairs::muterm_innermost_unhiding_rules(&context.csr)
            {
                if !allowed_rules.contains(&rule) {
                    allowed_rules.push(rule);
                }
            }
        }
        let usable = match &problem.stats.problem {
            DpProblemContext::ContextSensitive(context)
                if context.construction == CsrDpConstruction::MutermUnhiding =>
            {
                innermost_csr_usable_rules(&context.csr, &allowed_rules, &problem.pairs)
            }
            DpProblemContext::Ordinary if problem.trs.strategy() == RewriteStrategy::Innermost => {
                // Recompute recursively inside the current certified rule
                // boundary.  Using the original TRS here can reintroduce a
                // rule removed by an outer usable-rules processor, after
                // which the subset guard merely makes this processor look
                // inapplicable.  This is especially visible after a
                // Q-reduction exposes a smaller nested closure.
                let active_trs = Trs::new_with_strategy(
                    problem.trs.name().map(str::to_owned),
                    problem.trs.variables().clone(),
                    input_rules.to_vec(),
                    problem.trs.strategy(),
                );
                let ordinary =
                    usable_rules_in_innermost_context(&active_trs, &problem.pairs, innermost_lhss);
                // Prefer the more precise standard closure whenever it makes
                // progress. The complete-GM04 retained set is a fallback for
                // a standard no-op, not a replacement for a smaller certified
                // obligation used by established recursive continuations.
                if ordinary.as_slice() == input_rules {
                    gm04_candidate.unwrap_or(ordinary)
                } else {
                    ordinary
                }
            }
            DpProblemContext::ContextSensitive(context) if context.use_qcs_usable_rules => {
                let active_trs = Trs::new_with_strategy(
                    problem.trs.name().map(str::to_string),
                    problem.trs.variables().clone(),
                    input_rules.to_vec(),
                    problem.trs.strategy(),
                );
                let Ok(active_csr) = CsrTrs::new(active_trs, context.csr.replacement_map().clone())
                else {
                    return ProcessorResult::Inapplicable;
                };
                if context.construction == CsrDpConstruction::Improved {
                    improved_qcs_certificate_usable_rules(&active_csr, &problem.pairs)
                } else {
                    qcs_certificate_usable_rules(&active_csr, &problem.pairs)
                }
            }
            DpProblemContext::ContextSensitive(context)
                if context.construction == CsrDpConstruction::Innermost =>
            {
                innermost_csr_usable_rules(&context.csr, input_rules, &problem.pairs)
            }
            _ => return ProcessorResult::Inapplicable,
        };
        // A usable-rules processor may only restrict the current active rule
        // obligation. Reintroducing a rule removed by an earlier processor
        // loses the certified residual context and can make the reconstructed
        // CPF omit the usable-rules step that justifies the later reduction.
        if usable.iter().any(|rule| !allowed_rules.contains(rule)) {
            if std::env::var_os("FERRUM_WORKLIST_TRACE").is_some() {
                eprintln!(
                    "usable-rules rejected reintroduction input={} computed={}",
                    input_rules.len(),
                    usable.len()
                );
            }
            return ProcessorResult::Inapplicable;
        }
        if usable.as_slice() == input_rules {
            if std::env::var_os("FERRUM_WORKLIST_TRACE").is_some() {
                eprintln!("usable-rules no progress rules={}", input_rules.len());
            }
            return ProcessorResult::Inapplicable;
        }
        let mut residual = problem.clone();
        residual.stats.active_rules = Some(usable.clone());
        residual.stats.active_rules_are_residual = true;
        // The CSR usable-rules theorem restricts R but preserves the typed
        // CSR-DP obligation while dropping minimality.  A later
        // `<ordinaryDpProof>` is a separate context-changing bridge;
        // conflating these transitions loses CSR instantiation/narrowing
        // continuations such as Ex9_Luc06, while retaining minimality would
        // unsoundly license subterm/SCT below this processor.  Ordinary
        // innermost usable rules have their own minimal-DP theorem and must
        // retain the bit; dropping it disables sound SCT/subterm closers and
        // can leave the fallback worklist transforming forever.
        if matches!(problem.stats.problem, DpProblemContext::ContextSensitive(_)) {
            residual.stats.minimal = false;
        }
        // Dependency-graph construction after this processor must use the
        // certified reduced rule obligation as well.  Leaving `graph_rules`
        // unchanged makes the in-memory child differ from the serialized
        // child (notably when the usable set is empty), and can both lose an
        // oracle lookup and reintroduce graph edges through rules that this
        // processor has removed.
        residual.stats.graph_rules = Some(usable.clone());
        ProcessorResult::Applied(ProcessorApplication::new(
            vec![ProblemState::DependencyPairs(residual)],
            move |children| {
                let [ProblemCertificate::DependencyPairTree(proof)] =
                    <[ProblemCertificate; 1]>::try_from(children).ok()?
                else {
                    return None;
                };
                Some(ProblemCertificate::DependencyPairTree(
                    DpProofTree::ComponentContext {
                        usable_rules_processor: Some(usable.clone()),
                        innermost_lhss_processor: None,
                        proof: Box::new(proof),
                    },
                ))
            },
        ))
    }
}

#[cfg(test)]
mod tests {
    use std::collections::BTreeSet;

    use crate::core::{RewriteRule, RewriteStrategy, Term, Trs, Variable};
    use crate::proving::dependency_pairs::{DependencyPair, DpOptions};
    use crate::proving::processors::dp::DpProblemState;

    use super::*;

    #[test]
    fn nonminimal_csr_order_keeps_an_established_rule_set() {
        use crate::core::{CsrTrs, ReplacementMap};
        use crate::proving::dependency_pairs::DpStrategy;
        let x = Term::var("x");
        let rule = RewriteRule::new(Term::app("s", vec![x.clone()]), x.clone());
        let csr = CsrTrs::new(Trs::new(None, Default::default(), vec![rule.clone()]),
            ReplacementMap::new(Default::default())).unwrap();
        let pair = DependencyPair::new_for_test(
            Term::app("f#", vec![Term::app("s", vec![x.clone()])]),
            Term::app("f#", vec![x]));
        let state = DpProblemState::csr_materialized_from_parts(&csr, vec![pair], vec![],
            Some(vec![rule.clone()]), false, "native", "context-sensitive", false,
            DpOptions::default()).unwrap().with_active_rules_are_residual(true);
        let DpStrategy::Processor(processor) = DpStrategy::parse(
            "poly(max-constant=2,max-coefficient=2,max-symbols=8,max-arity=2)").unwrap()
        else { panic!("expected processor"); };
        let ProcessorResult::Applied(order) = super::super::reduction_pair::ReductionPairProcessor {
            processor, deadline: Some(std::time::Instant::now() + std::time::Duration::from_secs(10)),
        }.apply(&ProblemState::DependencyPairs(state)) else { panic!("expected native order"); };
        let Some(ProblemCertificate::DependencyPairTree(DpProofTree::RedPair { reduction, .. })) =
            order.reconstruct(vec![ProblemCertificate::DependencyPairTree(DpProofTree::Empty)])
        else { panic!("expected reduction pair"); };
        assert!(!reduction.uses_usable_rules);
        assert_eq!(reduction.usable_rules, vec![rule]);
    }

    #[test]
    fn native_muterm_usable_rules_compute_live_bridges_and_preserve_context() {
        use crate::proving::dependency_pairs::{
            CsrDpProblemContext, csr_dp_problem_state, muterm_innermost_unhiding_rules,
            rta_csr_dependency_pairs,
        };
        let csr = crate::parsing::parse_ari_cstrs(
            None,
            include_str!("../../../../tests/fixtures/csr_ex1_gm03.ari"),
        )
        .unwrap();
        let pairs = rta_csr_dependency_pairs(&csr);
        let parent = csr_dp_problem_state(
            &csr,
            pairs,
            CsrDpProblemContext::muterm_unhiding(&csr),
            DpOptions::default(),
            None,
            Vec::new(),
        )
        .unwrap();
        let mut allowed = parent.trs.rules().to_vec();
        for rule in muterm_innermost_unhiding_rules(&csr) {
            if !allowed.contains(&rule) {
                allowed.push(rule);
            }
        }
        let expected = innermost_csr_usable_rules(&csr, &allowed, &parent.pairs);
        let ProcessorResult::Applied(application) =
            UsableRulesProcessor.apply(&ProblemState::DependencyPairs(parent.clone()))
        else {
            panic!("native typed MU-TERM closure must be available");
        };
        let ProblemState::DependencyPairs(child) = &application.residuals[0] else {
            panic!("expected typed DP child");
        };
        assert_eq!(child.stats.active_rules.as_ref(), Some(&expected));
        assert_eq!(child.stats.graph_rules.as_ref(), Some(&expected));
        assert_eq!(child.pairs, parent.pairs);
        assert_eq!(child.innermost_lhss, parent.innermost_lhss);
        assert!(!child.stats.minimal);
        assert!(
            matches!(&child.stats.problem, DpProblemContext::ContextSensitive(c)
            if c.construction == CsrDpConstruction::MutermUnhiding)
        );
        assert!(matches!(
            UsableRulesProcessor.apply(&application.residuals[0]),
            ProcessorResult::Inapplicable
        ));
    }

    #[test]
    fn nonminimal_muterm_order_uses_the_established_local_rules_once() {
        use crate::proving::dependency_pairs::{
            CsrDpProblemContext, DpStrategy, csr_dp_problem_state, rta_csr_dependency_pairs,
        };
        let csr = crate::parsing::parse_ari_cstrs(
            None,
            include_str!("../../../../tests/fixtures/csr_ex1_gm03.ari"),
        )
        .unwrap();
        let pairs = rta_csr_dependency_pairs(&csr)
            .into_iter()
            .filter(|p| {
                matches!(
                    p.lhs().root_symbol().map(|s| s.as_str()),
                    Some("diff#" | "if#")
                ) && matches!(
                    p.rhs().root_symbol().map(|s| s.as_str()),
                    None | Some("diff#" | "if#")
                )
            })
            .collect::<Vec<_>>();
        assert_eq!(pairs.len(), 3);
        let parent = csr_dp_problem_state(
            &csr,
            pairs,
            CsrDpProblemContext::muterm_unhiding(&csr),
            DpOptions::default(),
            None,
            Vec::new(),
        )
        .unwrap();
        let ProcessorResult::Applied(local) =
            UsableRulesProcessor.apply(&ProblemState::DependencyPairs(parent))
        else {
            panic!("expected native local closure");
        };
        let DpStrategy::Processor(processor) = DpStrategy::parse(
            "rat-poly(max-constant=4,max-coefficient=4,max-symbols=16,max-arity=4,denominator=2,delta-denominator=2)").unwrap()
        else { panic!("expected processor"); };
        let ProcessorResult::Applied(order) =
            super::super::reduction_pair::ReductionPairProcessor {
                processor,
                deadline: Some(std::time::Instant::now() + std::time::Duration::from_secs(10)),
            }
            .apply(&local.residuals[0])
        else {
            panic!("native rational search must make progress");
        };
        // Inspect the reconstructed node only; the placeholder is not exported
        // or claimed as a proof of the remaining DP problem.
        let Some(ProblemCertificate::DependencyPairTree(DpProofTree::RedPair {
            reduction, ..
        })) = order.reconstruct(vec![ProblemCertificate::DependencyPairTree(
            DpProofTree::Empty,
        )])
        else {
            panic!("expected one reduction pair");
        };
        let ProblemState::DependencyPairs(child) = &local.residuals[0] else {
            panic!("expected DP child");
        };
        assert!(!child.stats.minimal);
        assert!(!reduction.uses_usable_rules);
        assert!(reduction.force_non_mono_usable_rules);
        assert!(reduction.strict_rules.is_empty());
        assert_eq!(
            Some(&reduction.usable_rules),
            child.stats.active_rules.as_ref()
        );
    }

    #[test]
    fn ordinary_innermost_usable_rules_preserve_minimality() {
        let trs = Trs::new_with_strategy(
            None,
            BTreeSet::from([Variable::new("x")]),
            vec![RewriteRule::new(
                Term::app("f", vec![Term::app("s", vec![Term::var("x")])]),
                Term::app("f", vec![Term::var("x")]),
            )],
            RewriteStrategy::Innermost,
        );
        let pair = DependencyPair::new_for_test(
            Term::app("f#", vec![Term::app("s", vec![Term::var("x")])]),
            Term::app("f#", vec![Term::var("x")]),
        );
        let state = ProblemState::DependencyPairs(DpProblemState::ordinary(
            trs,
            vec![pair],
            DpOptions::default(),
        ));

        let ProcessorResult::Applied(application) = UsableRulesProcessor.apply(&state) else {
            panic!("usable rules should remove the ordinary innermost rule obligation");
        };
        let [ProblemState::DependencyPairs(child)] = application.residuals.as_slice() else {
            panic!("expected one DP residual");
        };
        assert!(child.stats.minimal);
        assert_eq!(child.stats.active_rules.as_deref(), Some(&[][..]));
    }

    #[test]
    fn ordinary_full_usable_rules_are_not_a_standalone_processor() {
        let trs = Trs::new(
            None,
            BTreeSet::from([Variable::new("x")]),
            vec![
                RewriteRule::new(
                    Term::app("round", vec![Term::app("s", vec![Term::var("x")])]),
                    Term::app("s", vec![Term::var("x")]),
                ),
                RewriteRule::new(Term::app("unused", vec![Term::var("x")]), Term::var("x")),
            ],
        );
        let pair = DependencyPair::new_for_test(
            Term::app("round#", vec![Term::app("s", vec![Term::var("x")])]),
            Term::app("round#", vec![Term::var("x")]),
        );
        let state = ProblemState::DependencyPairs(DpProblemState::ordinary(
            trs,
            vec![pair],
            DpOptions::default(),
        ));

        assert!(matches!(
            UsableRulesProcessor.apply(&state),
            ProcessorResult::Inapplicable
        ));
    }
}
