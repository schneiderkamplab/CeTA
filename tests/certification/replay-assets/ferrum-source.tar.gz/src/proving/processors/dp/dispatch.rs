use std::time::Instant;

use crate::proving::dependency_pairs::{CsrDpConstruction, DpProblemContext, DpStrategyProcessor};

use super::super::{ProblemState, ProcessorResult, WorklistProcessor};
use super::{
    DependencyGraphProcessor, DpNonterminationProcessor, DpSwitchFullNonterminationProcessor,
    ExactDependencyGraphProcessor, ExactDpLoopProcessor, ExactDpNonLoopProcessor,
    ExactDpNonterminationProofProcessor, ExactDpNonterminationRuleRemovalProcessor,
    ExactDpTerminationProofProcessor, ExactDpTransformationProcessor, ExactGeneralRedPairProcessor,
    ExactInnermostLhssProcessor, ExactReductionPairProcessor, ExactSemanticLabelingProcessor,
    ExactSizeChangeProcessor, ExactSplitProcessor, ExactSubtermProcessor,
    ExactUsableRulesProcessor, ForwardInstantiationProcessor, InnermostLhssProcessor,
    AlphaMergeProcessor, InstantiationProcessor, MutermExpandProcessor, NarrowingProcessor, QdpToSrsProcessor,
    ReductionPairProcessor, RewritingProcessor, RootLabelingProcessor, SizeChangeProcessor,
    RuleSplitProcessor, SplitProcessor, SubtermProcessor, SwitchInnermostProcessor, SwitchToTrsProcessor,
    UncurryBelowProcessor, UncurryProcessor, UsableRulesProcessor,
};

/// A configured atomic DP processor.  Strategy syntax is configuration; the
/// processor still obeys the same `ProblemState -> ProcessorResult` contract
/// as every concrete processor family.
pub struct ConfiguredDpProcessor<'a> {
    pub processor: &'a DpStrategyProcessor,
    pub deadline: Option<Instant>,
}

pub(crate) fn innermost_rta08_processor_is_certifiable(processor: &DpStrategyProcessor) -> bool {
    matches!(
        processor,
        DpStrategyProcessor::DependencyGraph
            | DpStrategyProcessor::SymbolWeights { .. }
            | DpStrategyProcessor::LinearPolynomial { .. }
            | DpStrategyProcessor::ExactLinearPolynomial { .. }
            | DpStrategyProcessor::ExactMonotonicPolynomial { .. }
            | DpStrategyProcessor::ExactWeakPolynomial { .. }
            | DpStrategyProcessor::ExactMaxPolynomial { .. }
            | DpStrategyProcessor::ExactWeightedPathOrderMax { .. }
            | DpStrategyProcessor::ExactRationalPolynomial { .. }
            | DpStrategyProcessor::ExactRationalNaturalPolynomial { .. }
            | DpStrategyProcessor::ExactMatrixInterpretation { .. }
            | DpStrategyProcessor::ExactArcticMatrixInterpretation { .. }
            | DpStrategyProcessor::MonotonicPolynomial { .. }
            | DpStrategyProcessor::SatPolynomial { .. }
            | DpStrategyProcessor::WeakPolynomial { .. }
            | DpStrategyProcessor::MaxPolynomial { .. }
            | DpStrategyProcessor::WeightedPathOrderMax { .. }
            | DpStrategyProcessor::RationalPolynomial { .. }
            | DpStrategyProcessor::RationalQuadraticPolynomial { .. }
            | DpStrategyProcessor::SmtPolynomial { .. }
            | DpStrategyProcessor::QuadraticPolynomial { .. }
            | DpStrategyProcessor::MatrixInterpretation { .. }
            | DpStrategyProcessor::IntegerMatrixInterpretation { .. }
            | DpStrategyProcessor::ArcticMatrixInterpretation { .. }
            | DpStrategyProcessor::IntegerArcticMatrixInterpretation { .. }
            | DpStrategyProcessor::QuasiPeriodic { .. }
            | DpStrategyProcessor::QuasiPeriodicBv { .. }
            | DpStrategyProcessor::ApplicativeReductionPair
            | DpStrategyProcessor::PathOrder
            | DpStrategyProcessor::ConfiguredPathOrder { .. }
            | DpStrategyProcessor::ExactPathOrder { .. }
            | DpStrategyProcessor::Kbo { .. }
    )
}

impl WorklistProcessor for ConfiguredDpProcessor<'_> {
    fn name(&self) -> &'static str {
        "configured-dp"
    }

    fn apply(&self, state: &ProblemState) -> ProcessorResult {
        if let ProblemState::DependencyPairs(problem) = state
            && matches!(
                &problem.stats.problem,
                DpProblemContext::ContextSensitive(context)
                    if context.construction == CsrDpConstruction::InnermostRta08
            )
            && !innermost_rta08_processor_is_certifiable(self.processor)
        {
            return ProcessorResult::Inapplicable;
        }
        match self.processor {
            DpStrategyProcessor::ComplexConstantRemoval => super::complex_constant_removal::discover(state, self.deadline),
            DpStrategyProcessor::LargestComplexConstantRemoval => super::complex_constant_removal::discover_largest(state, self.deadline),
            DpStrategyProcessor::Gm04AdministrativeRpo => {
                let ProblemState::DependencyPairs(problem) = state else {
                    return ProcessorResult::Inapplicable;
                };
                let Some(order) = super::solver::native_gm04_administrative_rpo(problem) else {
                    return ProcessorResult::Inapplicable;
                };
                ReductionPairProcessor { processor: order, deadline: self.deadline }.apply(state)
            }
            DpStrategyProcessor::Gm04SourceCsr => super::gm04_source_csr::Gm04SourceCsrProcessor.apply(state),
            DpStrategyProcessor::DependencyGraph => DependencyGraphProcessor {
                deadline: self.deadline,
            }
            .apply(state),
            DpStrategyProcessor::RefinedDependencyGraph => DependencyGraphProcessor {
                deadline: self.deadline,
            }.apply_refined(state),
            DpStrategyProcessor::ExactReductionPair {
                processor_tag,
                payload_xml,
                removed_indices,
                source_pairs_xml,
                source_rules_xml,
                source_weak_pairs_xml,
                source_strict_rules_xml,
            } => ExactReductionPairProcessor {
                processor_tag: processor_tag.clone(),
                payload_xml: payload_xml.clone(),
                removed_indices: removed_indices.clone(),
                source_pairs_xml: source_pairs_xml.clone(),
                source_rules_xml: source_rules_xml.clone(),
                source_weak_pairs_xml: source_weak_pairs_xml.clone(),
                source_strict_rules_xml: source_strict_rules_xml.clone(),
            }
            .apply(state),
            DpStrategyProcessor::ExactUsableRules {
                payload_xml,
                source_pairs_xml,
                source_rules_xml,
            } => ExactUsableRulesProcessor {
                payload_xml: payload_xml.clone(),
                source_pairs_xml: source_pairs_xml.clone(),
                source_rules_xml: source_rules_xml.clone(),
            }
            .apply(state),
            DpStrategyProcessor::ExactInnermostLhss { payload_xml, source_dp_input_xml } => {
                ExactInnermostLhssProcessor {
                    payload_xml: payload_xml.clone(),
                    source_dp_input_xml: source_dp_input_xml.clone(),
                }
                .apply(state)
            }
            DpStrategyProcessor::ExactDpTransformation {
                processor_tag,
                payload_xml,
                dp_input_xml,
                source_dp_input_xml,
            } => ExactDpTransformationProcessor {
                processor_tag: processor_tag.clone(),
                payload_xml: payload_xml.clone(),
                dp_input_xml: dp_input_xml.clone(),
                source_dp_input_xml: source_dp_input_xml.clone(),
            }
            .apply(state),
            DpStrategyProcessor::ExactNonterminationRuleRemoval {
                source_dp_input_xml,
                residual_dp_input_xml,
            } => ExactDpNonterminationRuleRemovalProcessor {
                source_dp_input_xml: source_dp_input_xml.clone(),
                residual_dp_input_xml: residual_dp_input_xml.clone(),
            }
            .apply(state),
            DpStrategyProcessor::ExactTerminationProof {
                source_dp_input_xml,
                dp_proof_xml,
            } => ExactDpTerminationProofProcessor {
                source_dp_input_xml: source_dp_input_xml.clone(),
                dp_proof_xml: dp_proof_xml.clone(),
            }
            .apply(state),
            DpStrategyProcessor::NonterminationUsableRules => super::nontermination::DpNonterminationUsableRulesProcessor.apply(state),
            DpStrategyProcessor::NonterminationCycle { candidate, min_length, max_length, repeated } => super::nontermination_cycle::NonterminationCycleProcessor {
                candidate: *candidate, min_length: *min_length, max_length: *max_length, repeated: *repeated, deadline: self.deadline,
            }.apply(state),
            DpStrategyProcessor::NonterminationNarrowing { candidate, lookahead, all, below } => super::nontermination_narrowing::NonterminationNarrowingProcessor {
                candidate: *candidate, lookahead: *lookahead, all: *all, below: *below, deadline: self.deadline,
            }.apply(state),
            DpStrategyProcessor::NonterminationInnermostLhss => super::nontermination::DpNonterminationInnermostLhssProcessor.apply(state),
            DpStrategyProcessor::SwitchFullNontermination => DpSwitchFullNonterminationProcessor {
                deadline: self.deadline,
            }
            .apply(state),
            DpStrategyProcessor::NonterminationLoop => DpNonterminationProcessor {
                deadline: self.deadline,
            }
            .apply(state),
            DpStrategyProcessor::NonterminationSymbolicLoop => DpNonterminationProcessor { deadline: self.deadline }.apply_symbolic_loop(state),
            DpStrategyProcessor::NonterminationBackwardLoop => DpNonterminationProcessor { deadline: self.deadline }.apply_backward_loop(state),
            DpStrategyProcessor::NonterminationForkLoop => DpNonterminationProcessor { deadline: self.deadline }.apply_fork_loop(state),
            DpStrategyProcessor::NonterminationFairLoop => DpNonterminationProcessor { deadline: self.deadline }.apply_fair_loop(state),
            DpStrategyProcessor::NonterminationInstance { candidate, constants, all } => super::nontermination_instance::NonterminationInstanceProcessor { candidate: *candidate, constants: *constants, all: *all, deadline: self.deadline }.apply(state),
            DpStrategyProcessor::NonterminationRuleFilter { max_lhs, max_rhs, collapsing } => super::nontermination::DpNonterminationRuleFilterProcessor { max_lhs: *max_lhs, max_rhs: *max_rhs, collapsing: *collapsing }.apply(state),
            DpStrategyProcessor::NonterminationNonLoop => DpNonterminationProcessor {
                deadline: self.deadline,
            }
            .apply_nonloop(state),
            DpStrategyProcessor::ExactNonterminationLoop {
                source_dp_input_xml,
                loop_xml,
            } => ExactDpLoopProcessor {
                source_dp_input_xml: source_dp_input_xml.clone(),
                loop_xml: loop_xml.clone(),
            }
            .apply(state),
            DpStrategyProcessor::ExactNonterminationProof {
                source_dp_input_xml,
                dp_proof_xml,
            } => ExactDpNonterminationProofProcessor {
                source_dp_input_xml: source_dp_input_xml.clone(),
                dp_proof_xml: dp_proof_xml.clone(),
            }
            .apply(state),
            DpStrategyProcessor::ExactNonterminationNonLoop {
                source_dp_input_xml,
                non_loop_xml,
            } => ExactDpNonLoopProcessor {
                source_dp_input_xml: source_dp_input_xml.clone(),
                non_loop_xml: non_loop_xml.clone(),
            }
            .apply(state),
            DpStrategyProcessor::ExactSplit {
                selected_pair_index,
                selected_rule_index,
                source_dp_input_xml,
            } => ExactSplitProcessor {
                selected_pair_index: *selected_pair_index,
                selected_rule_index: *selected_rule_index,
                source_dp_input_xml: source_dp_input_xml.clone(),
            }
            .apply(state),
            DpStrategyProcessor::ExactDependencyGraph {
                components,
                source_dp_input_xml,
                source_is_live,
            } => ExactDependencyGraphProcessor {
                components: components.clone(),
                source_dp_input_xml: source_dp_input_xml.clone(),
                source_is_live: *source_is_live,
            }
            .apply(state),
            DpStrategyProcessor::ConditionalPolynomial { max_coefficient, degree, before, after, squares, reinduct, induction } =>
                super::conditional_polynomial::ConditionalPolynomialProcessor {
                    max_coefficient: *max_coefficient, degree: *degree, before: *before, after: *after, squares: *squares, reinduct: *reinduct, induction: *induction, deadline: self.deadline,
                }.apply(state),
            DpStrategyProcessor::ExactGeneralRedPair {
                payload_xml,
                strict_indices,
                bound_indices,
                merge,
                source_dp_input_xml,
            } => ExactGeneralRedPairProcessor {
                payload_xml: payload_xml.clone(),
                strict_indices: strict_indices.clone(),
                bound_indices: bound_indices.clone(),
                merge: *merge,
                source_dp_input_xml: source_dp_input_xml.clone(),
            }
            .apply(state),
            DpStrategyProcessor::UsableRules => UsableRulesProcessor.apply(state),
            DpStrategyProcessor::MutermExpand => MutermExpandProcessor.apply(state),
            DpStrategyProcessor::InnermostLhss => InnermostLhssProcessor.apply(state),
            DpStrategyProcessor::Split => {
                let ProblemState::DependencyPairs(problem) = state else {
                    return ProcessorResult::Inapplicable;
                };
                let Some(selected_strong_index) = problem
                    .pairs
                    .iter()
                    .position(|pair| !problem.stats.weak_pairs.contains(pair))
                else {
                    return ProcessorResult::Inapplicable;
                };
                SplitProcessor {
                    selected_strong_index,
                }
                .apply(state)
            }
            DpStrategyProcessor::SelectedSplit { candidate_index } => {
                let ProblemState::DependencyPairs(problem) = state else {
                    return ProcessorResult::Inapplicable;
                };
                let strong_indices = problem
                    .pairs
                    .iter()
                    .enumerate()
                    .filter_map(|(index, pair)| {
                        (!problem.stats.weak_pairs.contains(pair)).then_some(index)
                    })
                    .collect::<Vec<_>>();
                if let Some(&selected_strong_index) = strong_indices.get(*candidate_index) {
                    SplitProcessor { selected_strong_index }.apply(state)
                } else {
                    RuleSplitProcessor { selected_rule_index: candidate_index - strong_indices.len() }.apply(state)
                }
            }
            DpStrategyProcessor::SwitchInnermost => SwitchInnermostProcessor {
                deadline: self.deadline,
            }
            .apply(state),
            DpStrategyProcessor::QdpToSrs => QdpToSrsProcessor.apply(state),
            DpStrategyProcessor::SwitchToTrs => SwitchToTrsProcessor.apply(state),
            DpStrategyProcessor::Subterm => SubtermProcessor {
                deadline: self.deadline,
            }
            .apply(state),
            DpStrategyProcessor::ExactSubterm { projection } => ExactSubtermProcessor {
                projection: projection.clone(),
                deadline: self.deadline,
            }
            .apply(state),
            DpStrategyProcessor::SizeChange => SizeChangeProcessor {
                deadline: self.deadline,
            }
            .apply(state),
            DpStrategyProcessor::ExactSizeChange { graphs } => ExactSizeChangeProcessor {
                graphs: graphs.clone(),
                deadline: self.deadline,
            }
            .apply(state),
            DpStrategyProcessor::Rewriting { max_per_pair } => RewritingProcessor {
                max_per_pair: *max_per_pair,
                candidate_index: 0,
                deadline: self.deadline,
            }
            .apply(state),
            DpStrategyProcessor::SelectedRewriting { max_per_pair, candidate_index } => RewritingProcessor {
                max_per_pair: *max_per_pair,
                candidate_index: *candidate_index,
                deadline: self.deadline,
            }.apply(state),
            DpStrategyProcessor::Narrowing { max_per_pair } => NarrowingProcessor {
                max_per_pair: *max_per_pair,
                candidate_index: 0,
                require_depth_bound: true,
                deadline: self.deadline,
            }
            .apply(state),
            DpStrategyProcessor::SelectedNarrowing {
                max_per_pair,
                candidate_index,
            } => NarrowingProcessor {
                max_per_pair: *max_per_pair,
                candidate_index: *candidate_index,
                // An explicit candidate is replay guidance, not an unbounded
                // search request.  Residual CPF materialization deliberately
                // does not preserve the internal transformation-depth budget,
                // so enforcing that budget here made an independently
                // applicable nested state fail in a continuous proof.  All
                // semantic narrowing side conditions are still rechecked.
                require_depth_bound: false,
                deadline: self.deadline,
            }
            .apply(state),
            DpStrategyProcessor::AlphaMerge => AlphaMergeProcessor { deadline: self.deadline }.apply(state),
            DpStrategyProcessor::Instantiation { max_per_pair } => InstantiationProcessor {
                max_per_pair: *max_per_pair,
                candidate_index: 0,
                require_depth_bound: true,
                deadline: self.deadline,
            }
            .apply(state),
            DpStrategyProcessor::SelectedInstantiation {
                max_per_pair,
                candidate_index,
            } => InstantiationProcessor {
                max_per_pair: *max_per_pair,
                candidate_index: *candidate_index,
                require_depth_bound: false,
                deadline: self.deadline,
            }
            .apply(state),
            DpStrategyProcessor::ForwardInstantiation { max_per_pair } => {
                ForwardInstantiationProcessor {
                    max_per_pair: *max_per_pair,
                    candidate_index: 0,
                    require_depth_bound: true,
                    require_graph_progress: true,
                    deadline: self.deadline,
                }
                .apply(state)
            }
            DpStrategyProcessor::SelectedForwardInstantiation {
                max_per_pair,
                candidate_index,
            } => ForwardInstantiationProcessor {
                max_per_pair: *max_per_pair,
                candidate_index: *candidate_index,
                require_depth_bound: false,
                require_graph_progress: false,
                deadline: self.deadline,
            }
            .apply(state),
            DpStrategyProcessor::ExactSemanticLabeling {
                model,
                source_dp_input_xml,
                expected_child_dp_input_xml,
            } => ExactSemanticLabelingProcessor {
                model: model.clone(),
                source_dp_input_xml: source_dp_input_xml.clone(),
                expected_child_dp_input_xml: expected_child_dp_input_xml.clone(),
                deadline: self.deadline,
            }
            .apply(state),
            DpStrategyProcessor::RootLabeling => RootLabelingProcessor {
                deadline: self.deadline,
            }
            .apply(state),
            DpStrategyProcessor::UncurryBelow => UncurryBelowProcessor {
                deadline: self.deadline,
            }
            .apply(state),
            DpStrategyProcessor::Uncurry => UncurryProcessor {
                deadline: self.deadline,
            }
            .apply(state),
            DpStrategyProcessor::Llm
            | DpStrategyProcessor::SymbolWeights { .. }
            | DpStrategyProcessor::LinearPolynomial { .. }
            | DpStrategyProcessor::SelectedLinearPolynomial { .. }
            | DpStrategyProcessor::TargetLinearPolynomial { .. }
            | DpStrategyProcessor::MinimumDeletionLinearPolynomial { .. }
            | DpStrategyProcessor::ExactLinearPolynomial { .. }
            | DpStrategyProcessor::ExactMonotonicPolynomial { .. }
            | DpStrategyProcessor::ExactWeakPolynomial { .. }
            | DpStrategyProcessor::ExactMaxPolynomial { .. }
            | DpStrategyProcessor::ExactWeightedPathOrderMax { .. }
            | DpStrategyProcessor::ExactRationalPolynomial { .. }
            | DpStrategyProcessor::ExactRationalNaturalPolynomial { .. }
            | DpStrategyProcessor::ExactMatrixInterpretation { .. }
            | DpStrategyProcessor::ExactArcticMatrixInterpretation { .. }
            | DpStrategyProcessor::MonotonicPolynomial { .. }
            | DpStrategyProcessor::SatPolynomial { .. }
            | DpStrategyProcessor::WeakPolynomial { .. }
            | DpStrategyProcessor::TargetWeakPolynomial { .. }
            | DpStrategyProcessor::MaxPolynomial { .. }
            | DpStrategyProcessor::WeightedPathOrderMax { .. }
            | DpStrategyProcessor::RationalPolynomial { .. }
            | DpStrategyProcessor::RationalQuadraticPolynomial { .. }
            | DpStrategyProcessor::TargetRationalPolynomial { .. }
            | DpStrategyProcessor::SmtPolynomial { .. }
            | DpStrategyProcessor::QuadraticPolynomial { .. }
            | DpStrategyProcessor::MatrixInterpretation { .. }
            | DpStrategyProcessor::SelectedMatrixInterpretation { .. }
            | DpStrategyProcessor::IntegerMatrixInterpretation { .. }
            | DpStrategyProcessor::ArcticMatrixInterpretation { .. }
            | DpStrategyProcessor::SelectedArcticMatrixInterpretation { .. }
            | DpStrategyProcessor::TargetArcticMatrixInterpretation { .. }
            | DpStrategyProcessor::IntegerArcticMatrixInterpretation { .. }
            | DpStrategyProcessor::QuasiPeriodic { .. }
            | DpStrategyProcessor::QuasiPeriodicBv { .. }
            | DpStrategyProcessor::SelectedIntegerArcticMatrixInterpretation { .. }
            | DpStrategyProcessor::ApplicativeReductionPair
            | DpStrategyProcessor::PathOrder
            | DpStrategyProcessor::SelectedPathOrder { .. }
            | DpStrategyProcessor::ConfiguredPathOrder { .. }
            | DpStrategyProcessor::TargetPathOrder { .. }
            | DpStrategyProcessor::ExactPathOrder { .. }
            | DpStrategyProcessor::Kbo { .. } => ReductionPairProcessor {
                processor: self.processor.clone(),
                deadline: self.deadline,
            }
            .apply(state),
            DpStrategyProcessor::SemanticLabeling => ProcessorResult::Failed {
                reason: "semantic labeling must be expanded as model alternatives".to_string(),
            },
        }
    }
}
