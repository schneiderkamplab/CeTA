//! Relocate primitive witnesses using their own rule occurrences, not assumed
//! agreement between an archived input's spelling and its payload's spelling.
use std::collections::BTreeMap;
use crate::core::{RewriteRule, Symbol, Term, Variable};
use super::DpProblemState;

fn bind<K: Ord + Clone>(map: &mut BTreeMap<K, K>, source: &K, target: &K) -> bool {
    if let Some(old) = map.get(source) { return old == target; }
    if map.values().any(|old| old == target) { return false; }
    map.insert(source.clone(), target.clone());
    true
}

fn terms(a: &Term, b: &Term, symbols: &mut BTreeMap<Symbol, Symbol>,
    variables: &mut BTreeMap<Variable, Variable>) -> bool {
    match (a, b) {
        (Term::Var(a), Term::Var(b)) => bind(variables, a, b),
        (Term::App { symbol: a, args: aa }, Term::App { symbol: b, args: bb }) =>
            aa.len() == bb.len() && bind(symbols, a, b)
                && aa.iter().zip(bb).all(|(a,b)| terms(a,b,symbols,variables)),
        _ => false,
    }
}

fn escape(value: &str) -> String {
    value.replace('&', "&amp;").replace('<', "&lt;").replace('>', "&gt;")
}

pub(super) fn relocate(payload: &str, state: &DpProblemState, nonloop: bool) -> Option<String> {
    let doc = roxmltree::Document::parse(payload).ok()?;
    let mut sources = Vec::new();
    for node in doc.descendants().filter(|n| n.has_tag_name("rule")) {
        let parent = node.parent()?;
        let is_pair = if nonloop && parent.has_tag_name("rewriteStep") {
            // Pattern rewriting uses ordinary rsteps (CPF parser's rsteps),
            // not the mixed marked/relative steps of a DP loop.
            if parent.children().any(|n| n.has_tag_name("relative")) { return None; }
            false
        } else if nonloop {
            if !parent.has_tag_name("originalRule") { return None; }
            match parent.children().find(|n| n.has_tag_name("isPair"))?.text()?.trim() {
                "true" => true, "false" => false, _ => return None,
            }
        } else {
            if !parent.has_tag_name("rewriteStep") { return None; }
            !parent.children().any(|n| n.has_tag_name("relative"))
        };
        let wrapped = format!("<rules>{}</rules>", &payload[node.range()]);
        let mut rules = crate::parsing::parse_cpf_rule_container_fragment(&wrapped, "rules").ok()??;
        if rules.len() != 1 { return None; }
        sources.push((rules.remove(0), is_pair, nonloop && parent.has_tag_name("originalRule")));
    }
    if sources.is_empty() { return None; }
    let pairs = state.pairs.iter().map(|p| p.as_rule()).collect::<Vec<_>>();
    let rules = state.stats.active_rules.as_deref().unwrap_or(state.trs.rules());
    fn search(index: usize, sources: &[(RewriteRule, bool, bool)], pairs: &[RewriteRule], rules: &[RewriteRule],
        symbols: BTreeMap<Symbol, Symbol>, variables: BTreeMap<Variable, Variable>,
        nonloop: bool, fuel: &mut usize) -> Option<(BTreeMap<Symbol, Symbol>, BTreeMap<Variable, Variable>)> {
        if index == sources.len() { return Some((symbols, variables)); }
        let (source, pair, global_variables) = &sources[index];
        let candidates = if *pair { pairs } else { rules };
        for target in candidates {
            if *fuel == 0 { return None; } *fuel -= 1;
            let mut s = symbols.clone();
            let mut v = if *global_variables { variables.clone() } else { BTreeMap::new() };
            if terms(source.lhs(), target.lhs(), &mut s, &mut v)
                && terms(source.rhs(), target.rhs(), &mut s, &mut v) {
                if let Some(result) = search(index+1, sources, pairs, rules, s,
                    if *global_variables { v } else { variables.clone() }, nonloop, fuel) { return Some(result); }
            }
        }
        None
    }
    let (symbols, variables) = search(0, &sources, &pairs, rules,
        BTreeMap::new(), BTreeMap::new(), nonloop, &mut 100_000)?;
    let translated = super::exact_transformation::translate_payload_symbols(payload, &symbols);
    if !nonloop { return Some(translated); }
    // A single injective variable renaming transports the entire pattern proof,
    // including every pumping/closing substitution, without changing binding.
    let doc = roxmltree::Document::parse(&translated).ok()?;
    let mut mapping = variables;
    let mut occupied = doc.descendants().filter(|n| n.has_tag_name("var"))
        .filter_map(|n| n.text()).map(Variable::new).collect::<std::collections::BTreeSet<_>>();
    occupied.extend(mapping.values().cloned());
    let mut counter = 0;
    for variable in occupied.clone() {
        if !mapping.contains_key(&variable) && mapping.values().any(|v| v == &variable) {
            let fresh = loop {
                let name = Variable::new(format!("__witness_var_{counter}")); counter += 1;
                if occupied.insert(name.clone()) { break name; }
            };
            mapping.insert(variable, fresh);
        }
    }
    let mut edits = doc.descendants().filter(|n| n.has_tag_name("var"))
        .filter_map(|n| Some((n.range(), format!("<var>{}</var>",
            escape(mapping.get(&Variable::new(n.text()?.trim()))?.as_str())))))
        .collect::<Vec<_>>();
    edits.sort_by_key(|(r,_)| std::cmp::Reverse(r.start));
    let mut result = translated;
    for (range, value) in edits { result.replace_range(range, &value); }
    Some(result)
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::core::Trs;
    use crate::proving::{DependencyPair, DpOptions};

    fn state() -> DpProblemState {
        let x = Term::var("target_x");
        let term = Term::app("live", vec![x]);
        DpProblemState::ordinary(Trs::new(None, Default::default(), vec![]),
            vec![DependencyPair::new_for_test(term.clone(), term)], DpOptions::default())
    }

    #[test]
    fn nonloop_renaming_preserves_substitutions_and_freshens_collisions() {
        let rule = "<rule><funapp><name>old</name><var>x</var></funapp><funapp><name>old</name><var>x</var></funapp></rule>";
        let payload = format!("<nonLoop><originalRule>{rule}<isPair>true</isPair></originalRule><substitution><substEntry><var>x</var><var>target_x</var></substEntry></substitution></nonLoop>");
        let output = relocate(&payload, &state(), true).unwrap();
        assert!(output.contains("<name>live</name><var>target_x</var>"));
        assert!(output.contains("<substEntry><var>target_x</var><var>__witness_var_0</var>"));
        assert!(relocate(&payload.replace("<isPair>true", "<isPair>false"), &state(), true).is_none());
    }

    #[test]
    fn rejects_changed_variable_sharing_and_noninjective_symbols() {
        let mut symbols = BTreeMap::new(); let mut variables = BTreeMap::new();
        let source = Term::app("a", vec![Term::app("b", vec![])]);
        let target = Term::app("z", vec![Term::app("z", vec![])]);
        assert!(!terms(&source, &target, &mut symbols, &mut variables));
        let source = Term::app("f", vec![Term::var("x"), Term::var("x")]);
        let target = Term::app("g", vec![Term::var("u"), Term::var("v")]);
        assert!(!terms(&source, &target, &mut BTreeMap::new(), &mut BTreeMap::new()));
    }

    #[test]
    fn nonloop_rewrite_steps_use_ordinary_rules_and_local_rule_variables() {
        let mut state = state();
        state.trs = Trs::new(None, Default::default(), vec![RewriteRule::new(
            Term::app("step", vec![Term::var("local")]), Term::var("local"))]);
        let payload = "<nonLoop><originalRule><rule><funapp><name>old</name><var>x</var></funapp><funapp><name>old</name><var>x</var></funapp></rule><isPair>true</isPair></originalRule><rewriteStep><rule><funapp><name>rewrite</name><var>x</var></funapp><var>x</var></rule></rewriteStep></nonLoop>";
        let rebound = relocate(payload, &state, true).unwrap();
        assert!(rebound.contains("<name>step</name>"));
        assert!(rebound.contains("<name>live</name>"));
        assert!(relocate(&payload.replace("<rewriteStep>", "<rewriteStep><relative/>"), &state, true).is_none());
    }
}
