use crate::core::RewriteStrategy;
use crate::proving::dependency_pairs::{DpProblemContext, DpProofTree};

use super::super::{
    ProblemCertificate, ProblemState, ProcessorApplication, ProcessorResult, WorklistProcessor,
};
use super::remaining_innermost_lhss;

/// Remove innermost-Q left-hand sides that cannot participate in the current
/// minimal DP problem. This changes only `Q`; usable-rule reduction is a
/// separate worklist atom.
pub struct InnermostLhssProcessor;

/// Materialize an explicitly checked Q-reduction target.  Setting
/// `preserve_minimality` to false mirrors CeTA's general Q-reduction
/// processor: the new obligation is deliberately non-minimal when the more
/// restrictive minimality-preserving criterion is unavailable.
pub(crate) fn apply_innermost_lhss_target(
    state: &ProblemState,
    remaining: Vec<crate::core::Term>,
    preserve_minimality: bool,
) -> ProcessorResult {
    let ProblemState::DependencyPairs(problem) = state else {
        return ProcessorResult::Inapplicable;
    };
    if problem.trs.strategy() != RewriteStrategy::Innermost
        || !matches!(problem.stats.problem, DpProblemContext::Ordinary)
    {
        return ProcessorResult::Inapplicable;
    }
    let current = problem.innermost_lhss.as_deref().unwrap_or(&[]);
    if remaining.as_slice() == current {
        return ProcessorResult::Inapplicable;
    }
    let mut residual = problem.clone();
    residual.innermost_lhss = Some(remaining.clone());
    if !preserve_minimality {
        residual.stats.minimal = false;
    }
    ProcessorResult::Applied(ProcessorApplication::new(
        vec![ProblemState::DependencyPairs(residual)],
        move |children| {
            let [ProblemCertificate::DependencyPairTree(proof)] =
                <[ProblemCertificate; 1]>::try_from(children).ok()?
            else {
                return None;
            };
            Some(ProblemCertificate::DependencyPairTree(
                DpProofTree::ComponentContext {
                    usable_rules_processor: None,
                    innermost_lhss_processor: Some(remaining.clone()),
                    proof: Box::new(proof),
                },
            ))
        },
    ))
}

impl WorklistProcessor for InnermostLhssProcessor {
    fn name(&self) -> &'static str {
        "dependency-pair-innermost-lhss"
    }

    fn apply(&self, state: &ProblemState) -> ProcessorResult {
        let ProblemState::DependencyPairs(problem) = state else {
            return ProcessorResult::Inapplicable;
        };
        if !problem.stats.minimal
            || problem.trs.strategy() != RewriteStrategy::Innermost
            || !matches!(problem.stats.problem, DpProblemContext::Ordinary)
        {
            return ProcessorResult::Inapplicable;
        }
        let current = problem.innermost_lhss.as_deref().unwrap_or(&[]);
        let active_rules = problem
            .stats
            .active_rules
            .as_deref()
            .unwrap_or(problem.trs.rules());
        let remaining = remaining_innermost_lhss(current, active_rules, &problem.pairs);
        if remaining.as_slice() == current {
            return ProcessorResult::Inapplicable;
        }
        apply_innermost_lhss_target(state, remaining, true)
    }
}
