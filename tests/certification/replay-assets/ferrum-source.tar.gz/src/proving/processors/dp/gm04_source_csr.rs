use crate::core::{RewriteStrategy, Symbol, Term};
use crate::proving::Status;
use crate::proving::dependency_pairs::{DpProblemContext, DpProofTree, Gm04ResidualContext};
use crate::proving::processors::csr::recognition::recognize_gm04_inverse_csr;
use crate::proving::processors::{
    CsrProblemState, ProblemCertificate, ProblemState, ProcessorApplication, ProcessorResult,
    WorklistProcessor,
};

/// The source CSR is a real child, not an inherited or trusted assumption.
/// Recognition checks the complete transformation schema independently of names.
pub(super) struct Gm04SourceCsrProcessor;

impl WorklistProcessor for Gm04SourceCsrProcessor {
    fn name(&self) -> &'static str {
        "gm04-source-csr"
    }

    fn apply(&self, state: &ProblemState) -> ProcessorResult {
        let ProblemState::DependencyPairs(problem) = state else {
            return ProcessorResult::Inapplicable;
        };
        if !matches!(problem.stats.problem, DpProblemContext::Ordinary)
            || problem.stats.semantic_csr_context.is_some()
            || problem.trs.strategy() != RewriteStrategy::Innermost
            || !problem.stats.normal_form_substitutions
            || !problem.stats.minimal
            || !problem.stats.strict_rules.is_empty()
            || problem.pairs.len() != 2
        {
            return ProcessorResult::Inapplicable;
        }
        let Some(inverse) = recognize_gm04_inverse_csr(&problem.trs) else {
            return ProcessorResult::Inapplicable;
        };
        let top_sharp = Symbol::new(format!("{}#", inverse.top_symbol.as_str()));
        let wrap = |inner: &Symbol| {
            Term::app(
                top_sharp.as_str(),
                vec![Term::app(inner.as_str(), vec![Term::var("__gm04_x")])],
            )
        };
        let pairs = vec![
            crate::core::RewriteRule::new(wrap(&inverse.ok_symbol), wrap(&inverse.active_symbol)),
            crate::core::RewriteRule::new(wrap(&inverse.mark_symbol), wrap(&inverse.proper_symbol)),
        ];
        let mut checked = problem.clone();
        let expected_q = inverse
            .residual_rules
            .iter()
            .map(|r| r.lhs().clone())
            .collect::<Vec<_>>();
        let Some(live_q) = problem.innermost_lhss.as_deref() else {
            return ProcessorResult::Inapplicable;
        };
        let as_rules = |terms: &[Term]| {
            terms
                .iter()
                .map(|t| crate::core::RewriteRule::new(t.clone(), t.clone()))
                .collect::<Vec<_>>()
        };
        // Equal lengths plus one-way membership can hide a missing Q term
        // behind a duplicate. Require a complete alpha-equivalent multiset.
        if !super::same_rule_multiset(&as_rules(live_q), &as_rules(&expected_q)) {
            return ProcessorResult::Inapplicable;
        }
        checked.options.gm04_residual = Some(Gm04ResidualContext {
            pairs,
            rules: inverse.residual_rules.clone(),
            q: expected_q,
            top_sharp: top_sharp.clone(),
            active: inverse.active_symbol.clone(),
            proper: inverse.proper_symbol.clone(),
            ok: inverse.ok_symbol.clone(),
            mark: inverse.mark_symbol.clone(),
            top: inverse.top_symbol.clone(),
            symbols: Vec::new(),
            graph_decomposed: true,
        });
        if super::solver::gm04_residual_assumption(&checked).is_none() {
            return ProcessorResult::Inapplicable;
        }
        ProcessorResult::Applied(ProcessorApplication::new(
            vec![ProblemState::Csr(CsrProblemState::root(
                inverse.csr.clone(),
            ))],
            move |children| {
                let [ProblemCertificate::Trs(source)] =
                    <[ProblemCertificate; 1]>::try_from(children).ok()?
                else {
                    return None;
                };
                if source.status() != &Status::Terminating {
                    return None;
                }
                let payload_xml = crate::cert::gm04_source_dp_context_xml(
                    &inverse, &top_sharp, &source, &checked,
                )
                .ok()?;
                Some(ProblemCertificate::DependencyPairTree(
                    DpProofTree::TransformationExact {
                        processor_tag: "__gm04SourceCsr".into(),
                        payload_xml,
                        proof: Box::new(DpProofTree::Empty),
                    },
                ))
            },
        ))
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::proving::{DependencyPair, DpOptions, DpProblemState};

    fn problem() -> DpProblemState {
        let trs = crate::parsing::parse_ari_trs(
            None,
            r#"
(format TRS) (strategy INNERMOST)
(fun A 1) (fun M 1) (fun P 1) (fun O 1) (fun T 1) (fun f 1) (fun a 0)
(rule (A (f X)) (M a))
(rule (P (f X)) (f (P X)))
(rule (P a) (O a))
(rule (f (O X)) (O (f X)))
(rule (T (M X)) (T (P X)))
(rule (T (O X)) (T (A X)))
"#,
        )
        .unwrap();
        let trs = crate::core::Trs::new_with_strategy(
            None,
            trs.variables().clone(),
            trs.rules().to_vec(),
            RewriteStrategy::Innermost,
        );
        let inverse = recognize_gm04_inverse_csr(&trs).unwrap();
        let pair = |a: &str, b: &str| {
            DependencyPair::from_rule(
                crate::core::RewriteRule::new(
                    Term::app("T#", vec![Term::app(a, vec![Term::var("X")])]),
                    Term::app("T#", vec![Term::app(b, vec![Term::var("X")])]),
                ),
                0,
            )
        };
        let mut state = DpProblemState::ordinary(
            trs,
            vec![pair("O", "A"), pair("M", "P")],
            DpOptions::default(),
        );
        state.stats.active_rules = Some(inverse.residual_rules.clone());
        state.innermost_lhss = Some(
            inverse
                .residual_rules
                .iter()
                .map(|r| r.lhs().clone())
                .collect(),
        );
        state
    }

    #[test]
    fn gm04_source_is_an_independent_csr_child_and_preserves_side_conditions() {
        let state = problem();
        assert_eq!(state.trs.strategy(), RewriteStrategy::Innermost);
        assert!(matches!(
            Gm04SourceCsrProcessor.apply(&ProblemState::DependencyPairs(state.clone())),
            ProcessorResult::Applied(_)
        ));
        let mut reduced = state.clone();
        reduced.stats.active_rules.as_mut().unwrap().pop();
        assert!(matches!(
            Gm04SourceCsrProcessor.apply(&ProblemState::DependencyPairs(reduced)),
            ProcessorResult::Applied(_)
        ));
        let mut wrong = state.clone();
        wrong.innermost_lhss = Some(Vec::new());
        assert!(matches!(
            Gm04SourceCsrProcessor.apply(&ProblemState::DependencyPairs(wrong)),
            ProcessorResult::Inapplicable
        ));
        let mut wrong = state.clone();
        let q = wrong.innermost_lhss.as_mut().unwrap();
        assert!(q.len() > 1);
        q[1] = q[0].clone();
        assert!(matches!(
            Gm04SourceCsrProcessor.apply(&ProblemState::DependencyPairs(wrong)),
            ProcessorResult::Inapplicable
        ));
        let mut wrong = state.clone();
        wrong.stats.normal_form_substitutions = false;
        assert!(matches!(
            Gm04SourceCsrProcessor.apply(&ProblemState::DependencyPairs(wrong)),
            ProcessorResult::Inapplicable
        ));
        let mut wrong = state.clone();
        wrong.stats.strict_rules = vec![state.trs.rules()[0].clone()];
        assert!(matches!(
            Gm04SourceCsrProcessor.apply(&ProblemState::DependencyPairs(wrong)),
            ProcessorResult::Inapplicable
        ));
        let mut wrong = state;
        wrong.pairs.pop();
        assert!(matches!(
            Gm04SourceCsrProcessor.apply(&ProblemState::DependencyPairs(wrong)),
            ProcessorResult::Inapplicable
        ));
    }
}
