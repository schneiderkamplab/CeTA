use serde_json::json;
use sha2::{Digest, Sha256};
use std::collections::hash_map::DefaultHasher;
use std::collections::{BTreeMap, HashSet};
use std::hash::{Hash, Hasher};
use std::thread;
use std::time::{Duration, Instant};

use crate::proving::dependency_pairs::{
    CsrDpConstruction, DpParallelCancel, DpProblemContext, DpStrategy, DpStrategyProcessor,
    worklist_guidance_strategy,
};
use crate::proving::processors::WorklistProcessor;
use crate::proving::processors::top_level::EmptySystemProcessor;
use crate::proving::processors::{LazyProcessorAttempt, ProblemState, ProcessorResult};
use crate::proving::runtime::{
    processor_event_context_or_problem_name, processor_event_log_enabled,
    processor_event_raw_input, write_processor_event,
};

use super::{
    ConfiguredDpProcessor, ExactSemanticLabelingProcessor, ForwardInstantiationProcessor,
    InstantiationProcessor, NarrowingProcessor, RewritingProcessor, RootLabelingProcessor, RuleSplitProcessor, SplitProcessor,
    forward_instantiation_candidate_count, innermost_rta08_processor_is_certifiable,
    instantiation_candidate_count, narrowing_candidate_count, rewriting_candidate_count, semantic_labeling_candidate_models,
};

fn trace_atom(atom: &str) -> String {
    let prefix = atom.chars().take(160).collect::<String>();
    if prefix.len() < atom.len() {
        format!("{prefix}... ({} bytes)", atom.len())
    } else {
        atom.to_owned()
    }
}

/// Construct the fixed RPO used in the completeness proof of the GM04
/// transformation.  Smaller numeric ranks denote higher precedence in the
/// checked path-order implementation:
///
/// `active > proper > source symbols > ok > mark`.
///
/// Marked source symbols normally inherit the role of their unmarked symbol.
/// The marked administrative callees `active#` and `proper#` are lower than
/// `top#`, because their direct top calls are precisely the generated pairs
/// removed before the two recursive top pairs reach the complete-GM04
/// terminal theorem.  This merely proposes a witness; `ExactPathOrder`
/// independently checks every live weak rule and strict pair before it can
/// remove anything.
pub(crate) fn gm04_administrative_rpo(
    problem: &super::DpProblemState,
) -> Option<DpStrategyProcessor> {
    let context = problem.options.gm04_residual.as_ref()?;
    let role_rank = |symbol: &str| {
        let marked = symbol.ends_with('#');
        let base = symbol.strip_suffix('#').unwrap_or(symbol);
        if marked && (base == context.active.as_str() || base == context.proper.as_str()) {
            // The transformed top rules produce both the two recursive
            // top#(...) pairs retained by the complete-GM04 theorem and the
            // direct top#(...) -> active#/proper# calls.  The latter must be
            // deleted by this administrative order.  Giving marked symbols
            // the role of their unmarked counterparts made active#/proper#
            // outrank top#, so those two calls survived and the exact
            // terminal residual could never match.
            6
        } else if base == context.active.as_str() {
            0
        } else if base == context.proper.as_str() {
            1
        } else if base == context.ok.as_str() {
            3
        } else if base == context.mark.as_str() {
            4
        } else if base == context.top.as_str() {
            // The two top pairs deliberately do not satisfy this order.  They
            // are retained for the exact GM04 residual theorem.
            5
        } else {
            2
        }
    };
    let precedence_ranks = context
        .symbols
        .iter()
        .map(|symbol| (symbol.clone(), role_rank(symbol)))
        .collect::<BTreeMap<_, _>>();
    let mut precedence = context.symbols.clone();
    precedence.sort_by_key(|symbol| (precedence_ranks[symbol], symbol.clone()));
    let statuses = precedence
        .iter()
        .map(|symbol| {
            (
                symbol.clone(),
                crate::proving::dependency_pairs::DpPathOrderKind::Rpo,
            )
        })
        .collect();
    Some(DpStrategyProcessor::ExactPathOrder {
        default_order: crate::proving::dependency_pairs::DpPathOrderKind::Rpo,
        statuses,
        precedence,
        precedence_ranks,
        argument_filter: Default::default(),
    })
}

/// Native order discovery for GM04 administrative symbols. Standalone states
/// need not carry the parent's search options: recover roles from the full
/// transformation schema. This context is only used to propose an RPO, never
/// installed as a source-CSR assumption. The reduction-pair checker still
/// verifies the live P/R/Q obligation and every selected strict deletion.
pub(super) fn native_gm04_administrative_rpo(
    problem: &super::DpProblemState,
) -> Option<DpStrategyProcessor> {
    if let Some(order) = gm04_administrative_rpo(problem) {
        return Some(order);
    }
    let inverse = crate::proving::processors::csr::recognition::recognize_gm04_inverse_csr(
        &problem.trs,
    )?;
    let mut proposal = problem.clone();
    let mut rules = problem.trs.rules().to_vec();
    rules.extend(problem.pairs.iter().map(|pair| pair.as_rule()));
    let signature = crate::core::Trs::new(None, Default::default(), rules).arities();
    proposal.options.gm04_residual = Some(crate::proving::dependency_pairs::Gm04ResidualContext {
        pairs: Vec::new(), rules: Vec::new(), q: Vec::new(),
        top_sharp: crate::core::Symbol::new(format!("{}#", inverse.top_symbol.as_str())),
        active: inverse.active_symbol, proper: inverse.proper_symbol,
        ok: inverse.ok_symbol, mark: inverse.mark_symbol, top: inverse.top_symbol,
        symbols: signature.keys().map(|symbol| symbol.as_str().to_string()).collect(),
        graph_decomposed: false,
    });
    gm04_administrative_rpo(&proposal)
}

pub(super) fn gm04_residual_assumption(
    problem: &super::DpProblemState,
) -> Option<crate::proving::DpProofTree> {
    // The verified complete-GM04 theorem discharges an *innermost* QDP
    // residual.  A Standard/full-rewriting inverse transformation may expose
    // the same generated P/Q/R syntax, but it must prove that ordinary
    // residual with ordinary DP processors instead of importing this
    // assumption.
    if problem.trs.strategy() != crate::core::RewriteStrategy::Innermost {
        return None;
    }
    let expected = problem.options.gm04_residual.as_ref()?;
    if !problem.stats.weak_pairs.is_empty() {
        if std::env::var_os("FERRUM_WORKLIST_TRACE").is_some() {
            eprintln!("GM04 terminal mismatch: weak pairs");
        }
        return None;
    }
    // Almost every component of a GM04 graph is administrative. Reject
    // those from the terminal theorem by their tiny pair signature before
    // comparing the large generated R and Q multisets.
    if problem.pairs.len() != expected.pairs.len()
        || problem.pairs.iter().any(|pair| {
            pair.lhs().root_symbol() != Some(&expected.top_sharp)
                || pair.rhs().root_symbol() != Some(&expected.top_sharp)
        })
    {
        return None;
    }
    let mut unmatched = problem.pairs.clone();
    for rule in &expected.pairs {
        let witness = crate::proving::DependencyPair::from_rule(rule.clone(), 0);
        let Some(index) = unmatched.iter().position(|pair| {
            crate::proving::dependency_pairs::dependency_pair_rules_alpha_equivalent(pair, &witness)
        }) else {
            if std::env::var_os("FERRUM_WORKLIST_TRACE").is_some() {
                eprintln!("GM04 terminal mismatch: expected pair {rule}");
            }
            return None;
        };
        unmatched.swap_remove(index);
    }
    let live_rules = problem
        .stats
        .active_rules
        .as_deref()
        .unwrap_or(problem.trs.rules());
    if !live_rules.iter().all(|rule| {
        expected
            .rules
            .iter()
            .any(|other| super::general_red_pair::alpha_equivalent_rules(rule, other))
    }) {
        if std::env::var_os("FERRUM_WORKLIST_TRACE").is_some() {
            let unexpected = live_rules
                .iter()
                .filter(|rule| {
                    !expected
                        .rules
                        .iter()
                        .any(|other| super::general_red_pair::alpha_equivalent_rules(rule, other))
                })
                .map(ToString::to_string)
                .collect::<Vec<_>>();
            let missing = expected
                .rules
                .iter()
                .filter(|rule| {
                    !live_rules
                        .iter()
                        .any(|other| super::general_red_pair::alpha_equivalent_rules(rule, other))
                })
                .map(ToString::to_string)
                .collect::<Vec<_>>();
            eprintln!(
                "GM04 terminal mismatch: rules live={} expected={} unexpected={unexpected:?} missing={missing:?}",
                live_rules.len(),
                expected.rules.len()
            );
        }
        return None;
    }
    let live_q = problem.innermost_lhss.as_deref()?;
    if live_q.len() != expected.q.len()
        || !live_q.iter().all(|lhs| {
            expected.q.iter().any(|other| {
                super::same_rule_multiset(
                    &[crate::core::RewriteRule::new(lhs.clone(), lhs.clone())],
                    &[crate::core::RewriteRule::new(other.clone(), other.clone())],
                )
            })
        })
    {
        if std::env::var_os("FERRUM_WORKLIST_TRACE").is_some() {
            eprintln!(
                "GM04 terminal mismatch: Q live={} expected={}",
                live_q.len(),
                expected.q.len()
            );
        }
        return None;
    }
    // A CPF finiteness assumption is an ordinary DP input.  Its active rule
    // set is represented by the input's `<trs>`, not by the private
    // `<usableRules>` state field that Ferrum uses while searching.  Keeping
    // the latter here produced a document that the verified CPF parser could
    // not read below `gm04CompleteTransformation`.
    //
    // The GM04 checker expects these residual rules as the weak rule set and
    // reconstructs Q from the innermost strategy, exactly matching the live
    // state checked above.
    let residual_trs = crate::core::Trs::new_with_strategy(
        problem.trs.name().map(str::to_owned),
        problem.trs.variables().clone(),
        live_rules.to_vec(),
        problem.trs.strategy(),
    );
    let cpf_input =
        crate::cert::write_dp_state_input_cpf3(&residual_trs, &problem.pairs, None, true, true);
    Some(crate::proving::DpProofTree::TransformationExact {
        processor_tag: "gm04ResidualAssumption".to_owned(),
        payload_xml: cpf_input,
        proof: Box::new(crate::proving::DpProofTree::Empty),
    })
}

// Semantic-labeling's exhaustive carrier-two product is intentionally a
// bounded fallback.  Asking for `cursor + 1` candidates made the scheduler's
// apparent end move forward with every failed attempt, so a single DP state
// could generate thousands of zero-progress trials until the outer timeout.
// Exact oracle models are separate processors and are not affected by this
// bound.
const MAX_SEMANTIC_LABELING_ALTERNATIVES: usize = 256;
const GENERIC_SEMANTIC_LABELING_CONTINUATION_BUDGET: Duration = Duration::from_secs(4);

fn dp_cycle_key(state: &ProblemState, cursor: usize) -> String {
    let started = Instant::now();
    let mut hasher = DefaultHasher::new();
    cursor.hash(&mut hasher);
    if let ProblemState::DependencyPairs(problem) = state {
        problem.pairs.hash(&mut hasher);
        if let Some(context) = problem.options.gm04_residual.as_ref() {
            // The GM04 administrative continuation keeps one immutable,
            // potentially very large generated TRS in every SCC child.
            // Exclude that immutable source context, but hash every mutable
            // residual component exactly.  Boolean/length-only summaries are
            // not sufficient: usable-rule and Q processors can change their
            // contents without changing `Some`-ness or cardinality.
            context.top.hash(&mut hasher);
            context.graph_decomposed.hash(&mut hasher);
            // Reduction-pair processors retain the pair vector and move
            // deleted pairs into `weak_pairs`.  Omitting that set made a
            // successful all-weak child share its cycle key with the strict
            // parent, so the worklist discarded the child before the GM04
            // terminal theorem could close it.
            problem.stats.weak_pairs.hash(&mut hasher);
            problem.stats.active_rules.hash(&mut hasher);
            problem.stats.strict_rules.hash(&mut hasher);
            problem.stats.minimal.hash(&mut hasher);
            problem
                .stats
                .ordinary_bridge_loses_minimality
                .hash(&mut hasher);
            problem.stats.graph_rules.hash(&mut hasher);
            problem.stats.transformation_rules.hash(&mut hasher);
            problem.stats.ordinary_reduction_started.hash(&mut hasher);
            problem.innermost_lhss.hash(&mut hasher);
            return format!("dp-gm04:{:016x}", hasher.finish());
        }
        if std::env::var_os("FERRUM_TIMING_TRACE").is_some() {
            eprintln!(
                "dp cycle key pairs elapsed_ms={}",
                started.elapsed().as_millis()
            );
        }
        problem.trs.rules().hash(&mut hasher);
        if std::env::var_os("FERRUM_TIMING_TRACE").is_some() {
            eprintln!(
                "dp cycle key rules elapsed_ms={}",
                started.elapsed().as_millis()
            );
        }
        problem.trs.strategy().hash(&mut hasher);
        problem.options.strategy.hash(&mut hasher);
        if std::env::var_os("FERRUM_TIMING_TRACE").is_some() {
            eprintln!(
                "dp cycle key strategy elapsed_ms={}",
                started.elapsed().as_millis()
            );
        }
        problem.stats.weak_pairs.hash(&mut hasher);
        problem.stats.active_rules.hash(&mut hasher);
        problem.stats.minimal.hash(&mut hasher);
        problem
            .stats
            .ordinary_bridge_loses_minimality
            .hash(&mut hasher);
        problem.innermost_lhss.hash(&mut hasher);
    }
    let key = format!("dp:{:016x}", hasher.finish());
    if std::env::var_os("FERRUM_TIMING_TRACE").is_some() {
        eprintln!(
            "dp cycle key elapsed_ms={} cursor={cursor}",
            started.elapsed().as_millis()
        );
    }
    key
}

pub(crate) fn next_scheduled_result(
    state: &ProblemState,
    cursor: usize,
    deadline: Option<Instant>,
) -> Option<LazyProcessorAttempt> {
    let explicit = match state {
        ProblemState::DependencyPairs(problem) => problem.options.strategy.as_ref(),
        _ => None,
    };
    next_scheduled_result_with_strategy(state, cursor, deadline, explicit)
}

pub(crate) fn next_scheduled_result_with_strategy(
    state: &ProblemState,
    cursor: usize,
    deadline: Option<Instant>,
    explicit_strategy: Option<&DpStrategy>,
) -> Option<LazyProcessorAttempt> {
    let mut attempt = next_scheduled_result_inner(state, cursor, deadline, explicit_strategy)?;
    // Opt-in discovery fairness: a productive transformation must not consume
    // every later processor's opportunity through an enormous descendant tree.
    // The worklist shares this allowance across descendants and restores the
    // untried sibling when it expires. Mandatory normalization is unaffected.
    // No limit is imposed on ordinary production/oracle replays by default.
    if attempt.retain_fallback
        && let Ok(value) = std::env::var("FERRUM_DP_EXPLORATION_CONTINUATION_ATTEMPTS")
        && let Ok(limit) = value.parse::<usize>()
        && limit > 0
    {
        attempt.continuation_attempt_limit = Some(
            attempt.continuation_attempt_limit.map_or(limit, |old| old.min(limit)));
    }
    Some(attempt)
}

fn next_scheduled_result_inner(
    state: &ProblemState,
    cursor: usize,
    deadline: Option<Instant>,
    explicit_strategy: Option<&DpStrategy>,
) -> Option<LazyProcessorAttempt> {
    let deadline = match state {
        ProblemState::DependencyPairs(problem) => match (deadline, problem.subtree_deadline) {
            (Some(outer), Some(subtree)) => Some(outer.min(subtree)),
            (outer, subtree) => outer.or(subtree),
        },
        _ => deadline,
    };
    if deadline.is_some_and(|deadline| Instant::now() >= deadline) {
        return None;
    }
    if cursor == 0 {
        let started = Instant::now();
        let result = EmptySystemProcessor.apply(state);
        record_dp_attempt(state, "empty", started.elapsed(), &result, None);
        return Some(LazyProcessorAttempt::required(result, 1));
    }
    let ProblemState::DependencyPairs(problem) = state else {
        return None;
    };
    if cursor == 1
        && let Some(tree) = gm04_residual_assumption(problem)
    {
        return Some(LazyProcessorAttempt::required(
            ProcessorResult::Applied(crate::proving::processors::ProcessorApplication::solved(
                crate::proving::processors::ProblemCertificate::DependencyPairTree(tree),
            )),
            2,
        ));
    }
    // A source signature may declare nullary constructors that do not occur
    // in its rules.  After the exact GM04 cleanup polynomial removes their
    // administrative rules, their old left-hand sides can remain in Q.  Use
    // CeTA's standard general Q-reduction here.  It soundly drops minimality,
    // and the complete-GM04 terminal theorem accepts the resulting stronger
    // non-minimal obligation.
    if cursor == 1
        && let Some(context) = problem.options.gm04_residual.as_ref()
    {
        let live_rules = problem
            .stats
            .active_rules
            .as_deref()
            .unwrap_or(problem.trs.rules());
        if super::same_rule_multiset(live_rules, &context.rules)
            && problem.pairs.len() == context.pairs.len()
            && problem.pairs.iter().all(|pair| {
                pair.lhs().root_symbol() == Some(&context.top_sharp)
                    && pair.rhs().root_symbol() == Some(&context.top_sharp)
            })
            && problem.innermost_lhss.as_deref() != Some(context.q.as_slice())
        {
            return Some(LazyProcessorAttempt::required(
                crate::proving::processors::dp::apply_innermost_lhss_target(
                    state,
                    context.q.clone(),
                    false,
                ),
                3,
            ));
        }
    }
    // An explicit continuation is already authoritative for this residual.
    // Computing an oracle key first is redundant and can dominate runtime
    // after semantic labeling, whose fully materialized child may contain
    // hundreds of labeled symbols and megabytes of terms.
    let gm04_internal_guidance = problem.options.gm04_residual.is_some();
    let has_exact_strong_guidance =
        problem
            .options
            .utility_guidance
            .as_ref()
            .is_some_and(|lookup| {
                let input = crate::proving::dependency_pairs::dp_state_input_cpf(problem);
                lookup.has_exact_strong_guidance(&input)
            });
    // Existing innermost proof sequences deliberately carry bounded
    // continuations across their residuals.  Their exact entries describe
    // the same chain and must not preempt those continuations: doing so can
    // spend the entire root allowance on an alternate exact transformation.
    // Full rewriting needs the override to relocate independently certified
    // children exposed by semantic labeling, narrowing, and rewriting.
    // Migration mode: a strong action for this live state takes priority in
    // every framework, not only full ordinary DPs. "Exact" here means the
    // state key, not a supplied model: parameter-only actions qualify too.
    // Keep opt-in until the complete cross-category replay guards pass.
    let state_local_priority = std::env::var_os("FERRUM_STATE_LOCAL_PRIORITY").is_some();
    let exact_guidance_overrides_continuation = has_exact_strong_guidance
        && (state_local_priority
            || (matches!(problem.stats.problem, DpProblemContext::Ordinary)
                && problem.trs.strategy() == crate::core::RewriteStrategy::Full));
    // GM04's administrative continuation is deliberately generic.  Each
    // transformation still materializes a new, independently addressable DP
    // problem, so state-local certified guidance must get the first chance
    // there.  Keep the inherited continuation as a fallback; do not let its
    // mere presence suppress an exact oracle witness for the new state.
    let guided = (explicit_strategy.is_none()
        || gm04_internal_guidance
        || exact_guidance_overrides_continuation)
        .then(|| worklist_guidance_strategy(problem))
        .flatten();
    let has_guided_strategy = guided.is_some();
    // Canonical/portable evidence is a useful fallback, but it is not evidence
    // for this exact GM04 child.  In particular, treating a canonical hit as
    // live-state guidance used to schedule large narrowing and polynomial
    // portfolios before the checked linear administrative RPO.  Only a
    // byte-exact strong entry may outrank that generic GM04 continuation.
    if cursor == 1 && std::env::var_os("FERRUM_WORKLIST_TRACE").is_some() {
        let input = crate::proving::dependency_pairs::dp_state_input_cpf(problem);
        let key = format!("{:x}", Sha256::digest(input.trim().as_bytes()));
        let guidance_summary = guided.as_ref().map(|strategy| {
            let rendered = format!("{strategy:?}");
            let prefix = rendered.chars().take(240).collect::<String>();
            if prefix.len() < rendered.len() {
                format!("{prefix}... ({} bytes)", rendered.len())
            } else {
                rendered
            }
        });
        eprintln!(
            "dp worklist key={key} pairs={} rules={} exact_strong={} override={} explicit={} strategy={:?} guidance={guidance_summary:?}",
            problem.pairs.len(),
            problem
                .stats
                .active_rules
                .as_ref()
                .map_or(problem.trs.rules().len(), Vec::len),
            has_exact_strong_guidance,
            exact_guidance_overrides_continuation,
            explicit_strategy.is_some(),
            problem.trs.strategy(),
        );
    }
    let strict_guidance = std::env::var_os("FERRUM_DP_LLM_NO_FALLBACK").is_some()
        && (problem.options.utility_guidance.is_some() || problem.options.llm_client.is_some());
    let has_explicit_strategy = explicit_strategy.is_some();
    let strategies = if gm04_internal_guidance {
        let mut strategies = guided.into_iter().collect::<Vec<_>>();
        if !strict_guidance {
            if let Some(strategy) = explicit_strategy.cloned() {
                strategies.push(strategy);
            } else {
                strategies.push(DpStrategy::default_for(problem.trs.strategy()));
            }
        }
        strategies
    } else if exact_guidance_overrides_continuation {
        // A child produced by an inherited pipeline is a new independent DP
        // problem.  Its byte-exact certified action must take precedence over
        // the parent's continuation; otherwise transformations such as
        // narrowing keep replaying on the child and drift away from the
        // certified chain.  The inherited continuation is not a generic
        // fallback: it is the remainder of the already selected parent
        // strategy, and therefore remains part of strict oracle-only replay.
        // Keep it after the independently addressable child's exact action so
        // either representation of the certified recursive chain can close.
        let mut strategies = guided.into_iter().collect::<Vec<_>>();
        if let Some(strategy) = explicit_strategy.cloned() {
            strategies.push(strategy);
        }
        strategies
    } else if let Some(strategy) = explicit_strategy.cloned() {
        vec![strategy]
    } else {
        let mut strategies = guided.into_iter().collect::<Vec<_>>();
        if !strict_guidance {
            strategies.push(DpStrategy::default_for(problem.trs.strategy()));
        }
        strategies
    };
    if strategies.is_empty() {
        return None;
    }
    // Only cost-sort a fallback which was actually appended by this
    // scheduler.  In the exact-guidance override branch the sole strategy is
    // the oracle's causally ranked Choice; treating its last (and only)
    // element as the default reordered exact transformations behind cheap
    // generic atoms and broke certified recursive replay.
    let default_strategy_index = appended_default_strategy_index(
        strategies.len(),
        has_explicit_strategy,
        strict_guidance,
        exact_guidance_overrides_continuation,
        gm04_internal_guidance,
    );
    // When exact guidance preempts an inherited pipeline, preserve the tail
    // of the pipeline stage which that exact processor replaces.  Merely
    // adding the inherited strategy as a sibling alternative is insufficient:
    // once the exact processor succeeds, only its own oracle continuation is
    // attached to the child and the caller's later stages are lost.  This was
    // visible on transformed-CSR Standard problems where an exact graph and
    // exact polynomial deletion reached the intended two-pair residual, but
    // silently dropped the caller's graph/subterm/SCT cleanup.
    let explicit_frontier = explicit_strategy.map(strategy_frontier).unwrap_or_default();
    let guided_strategy_count = if exact_guidance_overrides_continuation && has_guided_strategy {
        1
    } else {
        0
    };
    let mut processors = Vec::new();
    for (index, strategy) in strategies.iter().enumerate() {
        let mut local = if has_explicit_strategy || strict_guidance {
            strategy_frontier(strategy)
        } else {
            let mut local = Vec::new();
            flatten_strategy(strategy, None, Duration::ZERO, &mut local);
            local
        };
        if index < guided_strategy_count {
            for scheduled in &mut local {
                let inherited_tail =
                    matching_inherited_continuation(&scheduled.processor, &explicit_frontier);
                scheduled.continuation =
                    parallel_continuation(scheduled.continuation.clone(), inherited_tail);
            }
        }
        if Some(index) == default_strategy_index {
            // Composition-free fallback atoms are alternatives, not a hidden
            // continuation.  Prefer deterministic closers before
            // transformations that can generate arbitrarily deep children.
            local.sort_by_key(|scheduled| processor_cost(&scheduled.processor));
        }
        processors.extend(local);
    }
    // The complete GM04 transformation has a generic, linear-time
    // administrative proof: decompose its dependency graph, then instantiate
    // the paper's fixed RPO.  Put those checked processors before generic SMT
    // synthesis, which is needlessly expensive on the generated signatures.
    if !strict_guidance && let Some(rpo) = gm04_administrative_rpo(problem) {
        let scheduled = |processor| ScheduledProcessor {
            processor,
            timeout: None,
            delay: Duration::ZERO,
            continuation: None,
        };
        let mut administrative = Vec::new();
        // Usable rules are recursive DP processors.  An earlier application
        // only certifies the closure for the then-current P and Q; graph
        // decomposition or Q reduction can expose a strictly smaller closure.
        // Always offer the processor for each independently materialized GM04
        // child.  Its ordinary no-progress check keeps this bounded.
        let installs_initial_usable_rules = problem.stats.active_rules.is_none();
        administrative.push(scheduled(DpStrategyProcessor::UsableRules));
        if !problem
            .options
            .gm04_residual
            .as_ref()
            .is_some_and(|context| context.graph_decomposed)
        {
            administrative.push(scheduled(DpStrategyProcessor::InnermostLhss));
        }
        // Lemma 28 orients every non-top administrative pair at once. Trying
        // that deletion before graph construction both preserves modularity
        // and avoids the quadratic Q-graph on large generated systems. The
        // graph remains a checked fallback if a future valid encoding leaves
        // more than the two terminal top pairs.
        administrative.push(scheduled(rpo));
        if !problem
            .options
            .gm04_residual
            .as_ref()
            .is_some_and(|context| context.graph_decomposed)
        {
            administrative.push(scheduled(DpStrategyProcessor::DependencyGraph));
        }
        if has_guided_strategy && has_exact_strong_guidance {
            if installs_initial_usable_rules {
                // The complete generated TRS intentionally contains top
                // administration rules which are unreachable from pair RHSs.
                // Install the checked usable closure before considering any
                // graph witness: an older sound full-R graph can otherwise
                // collapse the system into one useless giant SCC and divert
                // from the certified modular chain.
                let usable = administrative.remove(0);
                let mut ordered = vec![usable];
                ordered.append(&mut processors);
                ordered.extend(administrative);
                processors = ordered;
            } else {
                // Exact state-local evidence precedes both the inherited
                // generic continuation and the expensive graph fallback.
                processors.extend(administrative);
            }
        } else {
            administrative.append(&mut processors);
            processors = administrative;
        }
    }
    let innermost_rta08 = matches!(
        &problem.stats.problem,
        DpProblemContext::ContextSensitive(context)
            if context.construction == CsrDpConstruction::InnermostRta08
    );
    let mut seen = HashSet::new();
    let mut processors = processors
        .into_iter()
        .filter(|scheduled| {
            !innermost_rta08 || innermost_rta08_processor_is_certifiable(&scheduled.processor)
        })
        .filter(|scheduled| {
            seen.insert((
                scheduled.processor.clone(),
                scheduled.timeout,
                scheduled.delay,
                scheduled
                    .continuation
                    .as_ref()
                    .map(DpStrategy::to_strategy_atom),
            ))
        })
        .collect::<Vec<_>>();
    if cursor == 1 && std::env::var_os("FERRUM_WORKLIST_TRACE").is_some() {
        let order = processors
            .iter()
            .take(8)
            .map(|scheduled| trace_atom(&scheduled.processor.to_strategy_atom()))
            .collect::<Vec<_>>();
        eprintln!("dp worklist processor order={order:?}");
    }
    let strong_pair_count = problem
        .pairs
        .iter()
        .filter(|pair| !problem.stats.weak_pairs.contains(pair))
        .count();
    // Candidate-index expansion is the witness-free fallback for a generic
    // reduction-pair atom.  Do not multiply that search when the oracle has
    // retained an exact, independently rechecked processor result for this
    // state: exact guidance already identifies the intended residual and the
    // expansion can create a Cartesian product across graph components.
    let has_exact_reduction_guidance = processors.iter().any(|scheduled| {
        matches!(
            scheduled.processor,
            DpStrategyProcessor::ExactLinearPolynomial { .. }
                | DpStrategyProcessor::ExactMonotonicPolynomial { .. }
                | DpStrategyProcessor::ExactWeakPolynomial { .. }
                | DpStrategyProcessor::ExactMaxPolynomial { .. }
                | DpStrategyProcessor::ExactWeightedPathOrderMax { .. }
                | DpStrategyProcessor::ExactRationalPolynomial { .. }
                | DpStrategyProcessor::ExactMatrixInterpretation { .. }
                | DpStrategyProcessor::ExactArcticMatrixInterpretation { .. }
                | DpStrategyProcessor::ExactReductionPair { .. }
                | DpStrategyProcessor::ExactGeneralRedPair { .. }
        )
    });
    if strong_pair_count > 0 && !has_exact_reduction_guidance {
        let mut alternatives = Vec::new();
        for scheduled in &processors {
            if !matches!(scheduled.processor, DpStrategyProcessor::PathOrder) {
                continue;
            }
            alternatives.extend((1..=strong_pair_count).map(|candidate_index| {
                ScheduledProcessor {
                    processor: DpStrategyProcessor::SelectedPathOrder { candidate_index },
                    timeout: scheduled.timeout,
                    delay: scheduled.delay,
                    continuation: scheduled.continuation.clone(),
                }
            }));
        }
        processors.extend(alternatives);
        let mut alternatives = Vec::new();
        for scheduled in &processors {
            let DpStrategyProcessor::LinearPolynomial {
                max_constant,
                max_coefficient,
                max_symbols,
                max_arity,
            } = &scheduled.processor
            else {
                continue;
            };
            alternatives.extend((1..=strong_pair_count).map(|candidate_index| {
                ScheduledProcessor {
                    processor: DpStrategyProcessor::SelectedLinearPolynomial {
                        max_constant: *max_constant,
                        max_coefficient: *max_coefficient,
                        max_symbols: *max_symbols,
                        max_arity: *max_arity,
                        candidate_index,
                    },
                    timeout: scheduled.timeout,
                    delay: scheduled.delay,
                    continuation: scheduled.continuation.clone(),
                }
            }));
        }
        processors.extend(alternatives);
        let mut alternatives = Vec::new();
        for scheduled in &processors {
            let DpStrategyProcessor::IntegerArcticMatrixInterpretation {
                threshold,
                all_strict,
                max_finite_per_row,
                bitvectors,
                root_projection,
                optimize,
                symmetry,
                solver,
                dimension,
                min_value,
                max_value,
                max_symbols,
                max_arity,
            } = &scheduled.processor
            else {
                continue;
            };
            alternatives.extend((1..=strong_pair_count).map(|candidate_index| {
                ScheduledProcessor {
                    processor: DpStrategyProcessor::SelectedIntegerArcticMatrixInterpretation {
                        threshold: *threshold,
                        all_strict: *all_strict,
                        max_finite_per_row: *max_finite_per_row,
                        bitvectors: *bitvectors,
                        root_projection: *root_projection,
                        optimize: *optimize,
                        symmetry: *symmetry,
                        solver: solver.clone(),
                        dimension: *dimension,
                        min_value: *min_value,
                        max_value: *max_value,
                        max_symbols: *max_symbols,
                        max_arity: *max_arity,
                        candidate_index,
                    },
                    timeout: scheduled.timeout,
                    delay: scheduled.delay,
                    continuation: scheduled.continuation.clone(),
                }
            }));
        }
        processors.extend(alternatives);
        let mut alternatives = Vec::new();
        for scheduled in &processors {
            let DpStrategyProcessor::ArcticMatrixInterpretation {
                threshold,
                shared,
                dimension,
                max_constant,
                max_coefficient,
                max_nonzero,
                max_symbols,
                max_arity,
            } = &scheduled.processor
            else {
                continue;
            };
            alternatives.extend((1..=strong_pair_count).map(|candidate_index| {
                ScheduledProcessor {
                    processor: DpStrategyProcessor::SelectedArcticMatrixInterpretation {
                        threshold: *threshold,
                        shared: *shared,
                        dimension: *dimension,
                        max_constant: *max_constant,
                        max_coefficient: *max_coefficient,
                        max_nonzero: *max_nonzero,
                        max_symbols: *max_symbols,
                        max_arity: *max_arity,
                        candidate_index,
                    },
                    timeout: scheduled.timeout,
                    delay: scheduled.delay,
                    continuation: scheduled.continuation.clone(),
                }
            }));
        }
        processors.extend(alternatives);
        let mut alternatives = Vec::new();
        for scheduled in &processors {
            let DpStrategyProcessor::MatrixInterpretation {
                dimension,
                max_constant,
                max_coefficient,
                min_nonzero,
                max_nonzero,
                max_nonzero_constants,
                max_nonzero_per_row,
                max_symbols,
                max_arity,
            } = &scheduled.processor
            else {
                continue;
            };
            alternatives.extend((1..=strong_pair_count).map(|candidate_index| {
                ScheduledProcessor {
                    processor: DpStrategyProcessor::SelectedMatrixInterpretation {
                        dimension: *dimension,
                        max_constant: *max_constant,
                        max_coefficient: *max_coefficient,
                        min_nonzero: *min_nonzero,
                        max_nonzero: *max_nonzero,
                        max_nonzero_constants: *max_nonzero_constants,
                        max_nonzero_per_row: *max_nonzero_per_row,
                        max_symbols: *max_symbols,
                        max_arity: *max_arity,
                        candidate_index,
                    },
                    timeout: scheduled.timeout,
                    delay: scheduled.delay,
                    continuation: scheduled.continuation.clone(),
                }
            }));
        }
        processors.extend(alternatives);
    }
    let mut offset = 1usize;
    for scheduled in processors {
        let continuation = scheduled.continuation.clone();
        let processor_deadline = scheduled
            .timeout
            .map(|timeout| {
                let cap = Instant::now() + timeout;
                deadline.map_or(cap, |parent| parent.min(cap))
            })
            .or(deadline);
        match scheduled.processor {
            DpStrategyProcessor::Split => {
                let indices = problem
                    .pairs
                    .iter()
                    .enumerate()
                    .filter_map(|(index, pair)| {
                        (!problem.stats.weak_pairs.contains(pair)).then_some(index)
                    })
                    .collect::<Vec<_>>();
                let rule_count = problem.stats.active_rules.as_deref().unwrap_or(problem.trs.rules()).len();
                if cursor < offset + indices.len() + rule_count {
                    let cycle_key = dp_cycle_key(state, cursor);
                    if !wait_for_delay(scheduled.delay, deadline) {
                        return Some(
                            LazyProcessorAttempt::alternative(
                                ProcessorResult::TimedOut,
                                cursor + 1,
                            )
                            .with_cycle_key(cycle_key),
                        );
                    }
                    let candidate_index = cursor - offset;
                    return Some(
                        LazyProcessorAttempt::alternative(
                            record_dp_result(
                                state,
                                "split",
                                strict_guidance,
                                continuation.clone(),
                                || {
                                    if let Some(&selected_strong_index) = indices.get(candidate_index) {
                                        SplitProcessor { selected_strong_index }.apply(state)
                                    } else {
                                        RuleSplitProcessor { selected_rule_index: candidate_index - indices.len() }.apply(state)
                                    }
                                },
                            ),
                            cursor + 1,
                        )
                        .with_cycle_key(cycle_key),
                    );
                }
                offset += indices.len() + rule_count;
            }
            DpStrategyProcessor::SelectedSplit { candidate_index } => {
                if cursor == offset {
                    let result = record_dp_result(
                                state,
                                "split",
                                strict_guidance,
                                continuation.clone(),
                                || {
                                    ConfiguredDpProcessor {
                                        processor: &DpStrategyProcessor::SelectedSplit { candidate_index },
                                        deadline: processor_deadline,
                                    }
                                    .apply(state)
                                },
                    );
                    return Some(LazyProcessorAttempt::alternative(result, cursor + 1));
                }
                offset += 1;
            }
            DpStrategyProcessor::RootLabeling => {
                if cursor == offset {
                    let cycle_key = dp_cycle_key(state, cursor);
                    if !wait_for_delay(scheduled.delay, deadline) {
                        return Some(
                            LazyProcessorAttempt::alternative(
                                ProcessorResult::TimedOut,
                                cursor + 1,
                            )
                            .with_cycle_key(cycle_key),
                        );
                    }
                    let result = record_dp_result(
                        state,
                        "root-labeling",
                        strict_guidance,
                        continuation.clone(),
                        || {
                            RootLabelingProcessor {
                                deadline: processor_deadline,
                            }
                            .apply(state)
                        },
                    );
                    return Some(
                        LazyProcessorAttempt::alternative(result, cursor + 1)
                            .with_cycle_key(cycle_key),
                    );
                }
                offset += 1;
            }
            DpStrategyProcessor::SemanticLabeling => {
                let Some(models) = semantic_labeling_candidate_models(
                    problem,
                    MAX_SEMANTIC_LABELING_ALTERNATIVES,
                    processor_deadline,
                ) else {
                    return Some(LazyProcessorAttempt::alternative(
                        ProcessorResult::TimedOut,
                        cursor + 1,
                    ));
                };
                if cursor < offset + models.len() {
                    let cycle_key = dp_cycle_key(state, cursor);
                    if !wait_for_delay(scheduled.delay, deadline) {
                        return Some(
                            LazyProcessorAttempt::alternative(
                                ProcessorResult::TimedOut,
                                cursor + 1,
                            )
                            .with_cycle_key(cycle_key),
                        );
                    }
                    let candidate = &models[cursor - offset];
                    let candidate_continuation = candidate
                        .exact_polynomial
                        .as_ref()
                        .map(|interpretation| {
                            DpStrategy::Sequence(vec![
                                DpStrategy::Processor(DpStrategyProcessor::ExactLinearPolynomial {
                                    interpretation: interpretation.clone(),
                                }),
                                DpStrategy::Processor(DpStrategyProcessor::DependencyGraph),
                                DpStrategy::Processor(DpStrategyProcessor::SemanticLabeling),
                            ])
                        })
                        .or_else(|| continuation.clone())
                        .map(|strategy| DpStrategy::Timeout {
                            duration: GENERIC_SEMANTIC_LABELING_CONTINUATION_BUDGET,
                            strategy: Box::new(strategy),
                        });
                    let result = record_dp_result(
                        state,
                        "semantic-labeling",
                        strict_guidance,
                        candidate_continuation,
                        || {
                            ExactSemanticLabelingProcessor {
                                model: candidate.model.clone(),
                                source_dp_input_xml: None,
                                expected_child_dp_input_xml: None,
                                deadline: processor_deadline,
                            }
                            .apply(state)
                        },
                    );
                    // A jointly synthesized polynomial makes this model a
                    // strong first choice, not a logically required branch.
                    // If its labeled residual does not close, retain the
                    // worklist fallback so the remaining semantic models are
                    // still explored.
                    // Optional bounded exploration of each synthesized model.
                    // Every descendant shares the allowance; merely bounding
                    // depth would still permit exponentially many siblings.
                    let continuation_limit =
                        std::env::var("FERRUM_SEMANTIC_LABELING_CONTINUATION_ATTEMPTS")
                            .ok()
                            .and_then(|value| value.parse::<usize>().ok());
                    let attempt = LazyProcessorAttempt::alternative(result, cursor + 1)
                        .with_continuation_attempt_limit(continuation_limit);
                    return Some(attempt.with_cycle_key(cycle_key));
                }
                offset += models.len();
            }
            DpStrategyProcessor::Rewriting { max_per_pair } => {
                let count = rewriting_candidate_count(state, max_per_pair);
                if cursor < offset + count {
                    let candidate_index = cursor - offset;
                    let atom = DpStrategyProcessor::SelectedRewriting { max_per_pair, candidate_index }.to_strategy_atom();
                    let cycle_key = dp_cycle_key(state, cursor);
                    if !wait_for_delay(scheduled.delay, deadline) {
                        return Some(LazyProcessorAttempt::alternative(ProcessorResult::TimedOut, cursor + 1)
                            .with_cycle_key(cycle_key));
                    }
                    return Some(LazyProcessorAttempt::alternative(
                        record_dp_result(state, &atom, strict_guidance, continuation.clone(), || {
                            RewritingProcessor { max_per_pair, candidate_index, deadline: processor_deadline }.apply(state)
                        }), cursor + 1).with_cycle_key(cycle_key));
                }
                offset += count;
            }
            DpStrategyProcessor::Narrowing { max_per_pair } => {
                // A family hint must backtrack over native candidates, not
                // silently mean candidate zero. In strict guidance every
                // child requires its own advice; search-history depth is
                // not part of the independently serialized DP obligation.
                let count = narrowing_candidate_count(state, max_per_pair, processor_deadline).unwrap_or(0);
                if cursor < offset + count {
                    let candidate_index = cursor - offset;
                    let atom = DpStrategyProcessor::SelectedNarrowing { max_per_pair, candidate_index }.to_strategy_atom();
                    let cycle_key = dp_cycle_key(state, cursor);
                    if !wait_for_delay(scheduled.delay, deadline) {
                        return Some(LazyProcessorAttempt::alternative(ProcessorResult::TimedOut, cursor + 1)
                            .with_cycle_key(cycle_key));
                    }
                    return Some(LazyProcessorAttempt::alternative(
                        record_dp_result(state, &atom, strict_guidance, continuation.clone(), || {
                            NarrowingProcessor { max_per_pair, candidate_index,
                                require_depth_bound: !strict_guidance, deadline: processor_deadline }.apply(state)
                        }), cursor + 1).with_cycle_key(cycle_key));
                }
                offset += count;
            }
            DpStrategyProcessor::ForwardInstantiation { max_per_pair } => {
                let count =
                    forward_instantiation_candidate_count(state, processor_deadline).unwrap_or(0);
                if cursor < offset + count {
                    let candidate_index = cursor - offset;
                    let event_atom = DpStrategyProcessor::SelectedForwardInstantiation {
                        max_per_pair,
                        candidate_index,
                    }
                    .to_strategy_atom();
                    let cycle_key = dp_cycle_key(state, cursor);
                    if !wait_for_delay(scheduled.delay, deadline) {
                        return Some(
                            LazyProcessorAttempt::alternative(
                                ProcessorResult::TimedOut,
                                cursor + 1,
                            )
                            .with_cycle_key(cycle_key),
                        );
                    }
                    return Some(
                        LazyProcessorAttempt::alternative(
                            record_dp_result(
                                state,
                                &event_atom,
                                strict_guidance,
                                continuation.clone(),
                                || {
                                    ForwardInstantiationProcessor {
                                        max_per_pair,
                                        candidate_index,
                                        require_depth_bound: !strict_guidance,
                                        // A retained continuation may expose
                                        // progress only after usable-rule or
                                        // graph normalization.
                                        require_graph_progress: !strict_guidance && continuation.is_none(),
                                        deadline: processor_deadline,
                                    }
                                    .apply(state)
                                },
                            ),
                            cursor + 1,
                        )
                        .with_cycle_key(cycle_key),
                    );
                }
                offset += count;
            }
            DpStrategyProcessor::Instantiation { max_per_pair } => {
                let count = instantiation_candidate_count(state, processor_deadline).unwrap_or(0);
                if cursor < offset + count {
                    let candidate_index = cursor - offset;
                    let event_atom = DpStrategyProcessor::SelectedInstantiation {
                        max_per_pair,
                        candidate_index,
                    }
                    .to_strategy_atom();
                    let cycle_key = dp_cycle_key(state, cursor);
                    if !wait_for_delay(scheduled.delay, deadline) {
                        return Some(
                            LazyProcessorAttempt::alternative(
                                ProcessorResult::TimedOut,
                                cursor + 1,
                            )
                            .with_cycle_key(cycle_key),
                        );
                    }
                    return Some(
                        LazyProcessorAttempt::alternative(
                            record_dp_result(
                                state,
                                &event_atom,
                                strict_guidance,
                                continuation.clone(),
                                || {
                                    InstantiationProcessor {
                                        max_per_pair,
                                        candidate_index,
                                        require_depth_bound: !strict_guidance,
                                        deadline: processor_deadline,
                                    }
                                    .apply(state)
                                },
                            ),
                            cursor + 1,
                        )
                        .with_cycle_key(cycle_key),
                    );
                }
                offset += count;
            }
            processor => {
                if cursor == offset {
                    let cycle_key = dp_cycle_key(state, cursor);
                    if !wait_for_delay(scheduled.delay, deadline) {
                        return Some(
                            LazyProcessorAttempt::alternative(
                                ProcessorResult::TimedOut,
                                cursor + 1,
                            )
                            .with_cycle_key(cycle_key),
                        );
                    }
                    return Some(
                        LazyProcessorAttempt::alternative(
                            record_dp_result(
                                state,
                                &processor.to_strategy_atom(),
                                strict_guidance,
                                continuation.clone(),
                                || {
                                    if std::env::var_os("FERRUM_WORKLIST_TRACE").is_some() {
                                        let atom = processor.to_strategy_atom();
                                        eprintln!(
                                            "dp worklist starting atom={} remaining_ms={:?}",
                                            trace_atom(&atom),
                                            processor_deadline.map(|deadline| deadline
                                                .saturating_duration_since(Instant::now())
                                                .as_millis()),
                                        );
                                    }
                                    ConfiguredDpProcessor {
                                        processor: &processor,
                                        deadline: processor_deadline,
                                    }
                                    .apply(state)
                                },
                            ),
                            cursor + 1,
                        )
                        .with_cycle_key(cycle_key),
                    );
                }
                offset += 1;
            }
        }
    }
    None
}

fn exact_processor_replaces(exact: &DpStrategyProcessor, requested: &DpStrategyProcessor) -> bool {
    matches!(
        (exact, requested),
        (
            DpStrategyProcessor::ExactDependencyGraph { .. },
            DpStrategyProcessor::DependencyGraph
        ) | (
            DpStrategyProcessor::ExactMonotonicPolynomial { .. },
            DpStrategyProcessor::MonotonicPolynomial { .. }
        ) | (
            DpStrategyProcessor::ExactLinearPolynomial { .. },
            DpStrategyProcessor::LinearPolynomial { .. }
        ) | (
            DpStrategyProcessor::ExactMaxPolynomial { .. },
            DpStrategyProcessor::MaxPolynomial { .. }
        ) | (
            DpStrategyProcessor::ExactMatrixInterpretation { .. },
            DpStrategyProcessor::MatrixInterpretation { .. }
        ) | (
            DpStrategyProcessor::ExactArcticMatrixInterpretation { .. },
            DpStrategyProcessor::ArcticMatrixInterpretation { .. }
        ) | (
            DpStrategyProcessor::ExactUsableRules { .. },
            DpStrategyProcessor::UsableRules
        ) | (
            DpStrategyProcessor::ExactInnermostLhss { .. },
            DpStrategyProcessor::InnermostLhss
        ) | (
            DpStrategyProcessor::ExactSubterm { .. },
            DpStrategyProcessor::Subterm
        ) | (
            DpStrategyProcessor::ExactSizeChange { .. },
            DpStrategyProcessor::SizeChange
        )
    )
}

fn parallel_continuation(
    preferred: Option<DpStrategy>,
    fallback: Option<DpStrategy>,
) -> Option<DpStrategy> {
    match (preferred, fallback) {
        (None, strategy) | (strategy, None) => strategy,
        (Some(preferred), Some(fallback)) if preferred == fallback => Some(preferred),
        // A sequential choice can make a preserved fallback unreachable when
        // the oracle continuation consumes the enclosing root deadline.  Put
        // both continuations on the same cost-scheduled child frontier; their
        // processors still construct and validate their own proofs.
        (Some(preferred), Some(fallback)) => Some(DpStrategy::Parallel {
            cancel_on: DpParallelCancel::Proof,
            strategies: vec![preferred, fallback],
        }),
    }
}

fn matching_inherited_continuation(
    exact: &DpStrategyProcessor,
    explicit_frontier: &[ScheduledProcessor],
) -> Option<DpStrategy> {
    let mut tails = explicit_frontier
        .iter()
        .filter(|candidate| exact_processor_replaces(exact, &candidate.processor))
        .filter_map(|candidate| candidate.continuation.clone())
        .collect::<Vec<_>>();
    tails.dedup();
    match tails.len() {
        0 => None,
        1 => tails.pop(),
        _ => Some(DpStrategy::Choice(tails)),
    }
}

fn appended_default_strategy_index(
    strategy_count: usize,
    has_explicit_strategy: bool,
    strict_guidance: bool,
    exact_guidance_overrides_continuation: bool,
    gm04_internal_guidance: bool,
) -> Option<usize> {
    (!has_explicit_strategy
        && !strict_guidance
        && (!exact_guidance_overrides_continuation || gm04_internal_guidance))
        .then_some(strategy_count.saturating_sub(1))
}

fn record_dp_result(
    state: &ProblemState,
    atom: &str,
    strict_guidance: bool,
    continuation: Option<DpStrategy>,
    apply: impl FnOnce() -> ProcessorResult,
) -> ProcessorResult {
    let started = Instant::now();
    let prepared = attach_dp_continuation(apply(), continuation);
    // Preserve the exact children even when strict mode rejects this atom
    // before the worklist materializes them.  Without this boundary the event
    // stream can only guess a child from an adjacent, possibly sibling,
    // lookup event and cannot build a deterministic recursive oracle.
    let rejected_residuals = strict_guidance
        .then(|| residual_event_values(&prepared))
        .filter(|residuals| !residuals.is_empty());
    let result = reject_unguided_strict_residuals(prepared, strict_guidance, atom);
    if std::env::var_os("FERRUM_WORKLIST_TRACE").is_some() {
        let disposition = match &result {
            ProcessorResult::Applied(application) => {
                format!("applied residuals={}", application.residuals.len())
            }
            ProcessorResult::Inapplicable => "inapplicable".to_owned(),
            ProcessorResult::Failed { reason } => format!("failed: {reason}"),
            ProcessorResult::TimedOut => "timed-out".to_owned(),
        };
        eprintln!(
            "dp worklist atom={} {disposition} elapsed_ms={}",
            trace_atom(atom),
            started.elapsed().as_millis()
        );
    }
    record_dp_attempt(
        state,
        atom,
        started.elapsed(),
        &result,
        rejected_residuals.as_deref(),
    );
    result
}

fn attach_dp_continuation(
    mut result: ProcessorResult,
    continuation: Option<DpStrategy>,
) -> ProcessorResult {
    if let ProcessorResult::Applied(application) = &mut result {
        for residual in &mut application.residuals {
            if super::super::state_local_only() {
                super::super::clear_oracle_child_strategy(residual, true);
                if matches!(residual, ProblemState::DependencyPairs(problem)
                    if problem.options.utility_guidance.is_some())
                {
                    continue;
                }
            }
            if let ProblemState::DependencyPairs(problem) = residual {
                // A transformer may deliberately materialize a child with a
                // certified state-local strategy (for example QDP-to-SRS
                // creates the generated SRS's DP obligation).  Absence of an
                // inherited tail must not erase that strategy.  A real tail
                // remains authoritative and still replaces it.
                if continuation.is_some() {
                    problem.options.strategy = continuation.clone();
                }
            }
        }
    }
    result
}

/// In strict oracle-only mode, a nonempty residual without state-local
/// guidance cannot contribute to a complete branch. Reject it at the atomic
/// boundary so the scheduler immediately tries the next independently
/// applicable atom instead of materializing an exponentially large dead
/// worklist subtree.
fn reject_unguided_strict_residuals(
    result: ProcessorResult,
    strict_guidance: bool,
    atom: &str,
) -> ProcessorResult {
    if !strict_guidance {
        return result;
    }
    // Graph decomposition is conjunctive for termination but disjunctive for
    // nontermination: one cyclic component carrying a checked infinite chain
    // closes the parent.  Rejecting the complete graph merely because a
    // sibling component has no oracle entry discards that sound branch before
    // the worklist can discover its polarity.  Let reconstruction decide:
    // it still requires every component for a termination certificate, while
    // a DP-nontermination certificate legitimately short-circuits on one.
    if atom == "graph" || atom.starts_with("exact-graph(") {
        return result;
    }
    let ProcessorResult::Applied(application) = &result else {
        return result;
    };
    let has_unguided_nonempty_child = application.residuals.iter().any(|state| match state {
        ProblemState::DependencyPairs(problem) => {
            let terminal = strict_oracle_terminal(problem);
            let unguided = !terminal
                && problem.options.gm04_residual.is_none()
                && problem.options.strategy.is_none()
                && worklist_guidance_strategy(problem).is_none();
            if unguided && std::env::var_os("FERRUM_WORKLIST_TRACE").is_some() {
                let input = crate::proving::dependency_pairs::dp_state_input_cpf(problem);
                if std::env::var_os("FERRUM_WORKLIST_TRACE_INPUTS").is_some() {
                    eprintln!("worklist-input {}", serde_json::to_string(&input).unwrap());
                }
                let key = format!("{:x}", Sha256::digest(input.trim().as_bytes()));
                eprintln!(
                    "strict oracle rejected unguided residual key={key} pairs={} rules={}",
                    problem.pairs.len(),
                    problem
                        .stats
                        .active_rules
                        .as_ref()
                        .map_or(problem.trs.rules().len(), Vec::len),
                );
            }
            unguided
        }
        _ => false,
    });
    if has_unguided_nonempty_child {
        ProcessorResult::Failed {
            reason: "strict oracle transformation produced an unguided residual".to_owned(),
        }
    } else {
        result
    }
}

/// Terminal checks are mandatory, deterministic worklist steps rather than
/// search fallbacks.  In particular, the sole GM04 residual assumption is
/// discharged by the enclosing, checker-verified source-CSR proof.  Rejecting
/// that exact innermost child merely because it has no further oracle recipe
/// makes the strict scheduler disagree with the proof checker about whether
/// the branch is closed. Full-rewriting GM04 residuals are deliberately not
/// terminal here.
fn strict_oracle_terminal(problem: &super::DpProblemState) -> bool {
    (problem.stats.strict_rules.is_empty()
        && (problem.pairs.is_empty()
            || problem
                .pairs
                .iter()
                .all(|pair| problem.stats.weak_pairs.contains(pair))))
        || gm04_residual_assumption(problem).is_some()
}
/// Record every atomic DP boundary centrally. Processor implementations do
/// not own scheduling or event plumbing; their sole contract remains
/// `ProblemState -> Vec<ProblemState>`. This makes every materialized child
/// independently extractable for future oracle lookup.
fn record_dp_attempt(
    state: &ProblemState,
    atom: &str,
    elapsed: Duration,
    result: &ProcessorResult,
    rejected_residuals: Option<&[serde_json::Value]>,
) {
    if !processor_event_log_enabled() {
        return;
    }
    let ProblemState::DependencyPairs(problem) = state else {
        return;
    };
    let input_cpf = crate::proving::dependency_pairs::dp_state_input_cpf(problem);
    let input = processor_event_raw_input(input_cpf, "cpf3", false);
    let selected_atom = match result {
        ProcessorResult::Applied(application) => application.selected_atom().unwrap_or(atom),
        _ => atom,
    };
    let (outcome, progress, mut residuals) = match result {
        ProcessorResult::Applied(application) if application.residuals.is_empty() => {
            ("solved", "proof", Vec::new())
        }
        ProcessorResult::Applied(_) => ("transformed", "strong", residual_event_values(result)),
        ProcessorResult::Inapplicable => ("failed", "none", Vec::new()),
        ProcessorResult::Failed { .. } => ("failed", "none", Vec::new()),
        ProcessorResult::TimedOut => ("timeout", "none", Vec::new()),
    };
    if residuals.is_empty() {
        if let Some(rejected) = rejected_residuals {
            residuals.extend_from_slice(rejected);
        }
    }
    let context = processor_event_context_or_problem_name(problem.trs.name());
    let failure_reason = match result {
        ProcessorResult::Failed { reason } => Some(reason.as_str()),
        ProcessorResult::Inapplicable => Some("inapplicable"),
        ProcessorResult::TimedOut => Some("timeout"),
        ProcessorResult::Applied(_) => None,
    };
    write_processor_event(&json!({
        "schema": "ferrum.processor-event.v1",
        "run_id": context.as_ref().map(|context| context.run_id.as_str()),
        "problem_id": context.as_ref().map(|context| context.problem_id.as_str()),
        "category": context.as_ref().and_then(|context| context.category.as_deref()),
        "level": "dependency-pair",
        "problem_kind": match problem.stats.problem {
            crate::proving::dependency_pairs::DpProblemContext::Ordinary => "dp",
            crate::proving::dependency_pairs::DpProblemContext::ContextSensitive(_) => "csr-dp",
        },
        "processor": selected_atom,
        "strategy_atom": selected_atom,
        // Keep the search configuration distinct from its resulting witness.
        // Inferring tighter bounds from the model can change the next model
        // and hence the independently guided residual problem.
        "search_atom": atom,
        "outcome": outcome,
        "progress": progress,
        "failure_reason": failure_reason,
        "elapsed_ms": elapsed.as_millis(),
        "input": input,
        "metrics": {
            "rules": problem.stats.active_rules.as_ref().map_or(problem.trs.rules().len(), Vec::len),
            "pairs": problem.pairs.len(),
            "residuals": residuals.len(),
        },
        "witness": {
            "kind": "problem_states",
            "residuals": residuals,
        },
        "credit": { "status": "pending" },
    }));
}

fn residual_event_values(result: &ProcessorResult) -> Vec<serde_json::Value> {
    let ProcessorResult::Applied(application) = result else {
        return Vec::new();
    };
    application
        .residuals
        .iter()
        .map(|residual| {
            let (_, kind, cpf) = crate::proving::processors::top_level::serialized_problem_state(residual)
                .expect("every materialized state has an event representation");
            json!({
                "problem_key": format!("{:x}", Sha256::digest(cpf.trim().as_bytes())),
                "cpf": cpf,
                "format": if kind == "csr" { "cpf4" } else { "cpf3" },
                "standardized": false,
            })
        })
        .collect()
}

#[derive(Clone, Debug, Eq, PartialEq)]
struct ScheduledProcessor {
    processor: DpStrategyProcessor,
    timeout: Option<Duration>,
    delay: Duration,
    continuation: Option<DpStrategy>,
}

fn strategy_frontier(strategy: &DpStrategy) -> Vec<ScheduledProcessor> {
    match strategy {
        DpStrategy::Processor(processor) => vec![ScheduledProcessor {
            processor: processor.clone(),
            timeout: None,
            delay: Duration::ZERO,
            continuation: None,
        }],
        DpStrategy::Sequence(strategies) => strategies
            .iter()
            .flat_map(strategy_frontier)
            .map(|mut scheduled| {
                // Plain semicolon sequences predate explicit pipelines and
                // denote a recursive processor portfolio: every transformed
                // child gets the same alternatives again.  Certified recipes
                // that require one-way advancement use `pipeline(...)`.
                scheduled.continuation =
                    append_continuation(scheduled.continuation, Some(strategy.clone()));
                scheduled
            })
            .collect(),
        DpStrategy::Pipeline(strategies) => {
            let Some((stage, rest)) = strategies.split_first() else {
                return Vec::new();
            };
            let tail = match rest {
                [] => None,
                [single] => Some(single.clone()),
                _ => Some(DpStrategy::Pipeline(rest.to_vec())),
            };
            strategy_frontier(stage)
                .into_iter()
                .map(|mut scheduled| {
                    // A pipeline is a strict state transition: later stages
                    // are applicable only to children produced by this one.
                    // Exposing them on the parent loses transformation
                    // contexts and makes exact oracle recipes non-replayable.
                    scheduled.continuation =
                        append_continuation(scheduled.continuation, tail.clone());
                    scheduled
                })
                .collect()
        }
        DpStrategy::Choice(strategies) => strategies.iter().flat_map(strategy_frontier).collect(),
        DpStrategy::Parallel {
            cancel_on: DpParallelCancel::Proof | DpParallelCancel::Progress,
            strategies,
        } => {
            let mut alternatives = strategies
                .iter()
                .flat_map(strategy_frontier)
                .collect::<Vec<_>>();
            alternatives.sort_by_key(|scheduled| processor_cost(&scheduled.processor));
            alternatives
        }
        DpStrategy::Repeat {
            max_iterations,
            strategy,
        } => {
            if *max_iterations == 0 {
                return Vec::new();
            }
            let tail = (*max_iterations > 1).then(|| DpStrategy::Repeat {
                max_iterations: max_iterations - 1,
                strategy: strategy.clone(),
            });
            strategy_frontier(strategy)
                .into_iter()
                .map(|mut scheduled| {
                    scheduled.continuation =
                        append_continuation(scheduled.continuation, tail.clone());
                    scheduled
                })
                .collect()
        }
        DpStrategy::Timeout { duration, strategy } => strategy_frontier(strategy)
            .into_iter()
            .map(|mut scheduled| {
                scheduled.timeout = Some(
                    scheduled
                        .timeout
                        .map_or(*duration, |inner| inner.min(*duration)),
                );
                if let Some(continuation) = scheduled.continuation.take() {
                    scheduled.continuation = Some(DpStrategy::Timeout {
                        duration: *duration,
                        strategy: Box::new(continuation),
                    });
                }
                scheduled
            })
            .collect(),
        DpStrategy::Delay { duration, strategy } => strategy_frontier(strategy)
            .into_iter()
            .map(|mut scheduled| {
                scheduled.delay = scheduled.delay.saturating_add(*duration);
                if let Some(continuation) = scheduled.continuation.take() {
                    scheduled.continuation = Some(DpStrategy::Delay {
                        duration: *duration,
                        strategy: Box::new(continuation),
                    });
                }
                scheduled
            })
            .collect(),
    }
}

fn append_continuation(
    first: Option<DpStrategy>,
    second: Option<DpStrategy>,
) -> Option<DpStrategy> {
    match (first, second) {
        (None, tail) | (tail, None) => tail,
        (Some(first), Some(second)) => Some(DpStrategy::Pipeline(vec![first, second])),
    }
}

fn flatten_strategy(
    strategy: &DpStrategy,
    timeout: Option<Duration>,
    delay: Duration,
    output: &mut Vec<ScheduledProcessor>,
) {
    match strategy {
        DpStrategy::Processor(processor) => output.push(ScheduledProcessor {
            processor: processor.clone(),
            timeout,
            delay,
            continuation: None,
        }),
        DpStrategy::Sequence(strategies)
        | DpStrategy::Pipeline(strategies)
        | DpStrategy::Choice(strategies) => {
            for strategy in strategies {
                flatten_strategy(strategy, timeout, delay, output);
            }
        }
        DpStrategy::Parallel {
            cancel_on: DpParallelCancel::Proof | DpParallelCancel::Progress,
            strategies,
        } => {
            let mut alternatives = Vec::new();
            for strategy in strategies {
                flatten_strategy(strategy, timeout, delay, &mut alternatives);
            }
            // A worklist never commits to the first successful alternative:
            // if its residuals fail, the branch resumes at the next atom.
            // Trying bounded structural processors first therefore preserves
            // completeness while avoiding an unnecessary wait for an SMT
            // sibling that would have been cancelled by progress.
            alternatives.sort_by_key(|scheduled| processor_cost(&scheduled.processor));
            output.extend(alternatives);
        }
        DpStrategy::Repeat {
            max_iterations,
            strategy,
        } => {
            for _ in 0..*max_iterations {
                flatten_strategy(strategy, timeout, delay, output);
            }
        }
        DpStrategy::Timeout { duration, strategy } => {
            let timeout = Some(timeout.map_or(*duration, |outer| outer.min(*duration)));
            flatten_strategy(strategy, timeout, delay, output);
        }
        DpStrategy::Delay { duration, strategy } => {
            flatten_strategy(strategy, timeout, delay.saturating_add(*duration), output);
        }
    }
}

fn processor_cost(processor: &DpStrategyProcessor) -> u8 {
    match processor {
        DpStrategyProcessor::DependencyGraph | DpStrategyProcessor::RefinedDependencyGraph
            | DpStrategyProcessor::SizeChange => 0,
        DpStrategyProcessor::UsableRules
        | DpStrategyProcessor::InnermostLhss
        | DpStrategyProcessor::SwitchInnermost
        | DpStrategyProcessor::Subterm
        | DpStrategyProcessor::Rewriting { .. }
        | DpStrategyProcessor::SelectedRewriting { .. }
        | DpStrategyProcessor::Narrowing { .. }
        | DpStrategyProcessor::SelectedNarrowing { .. }
        | DpStrategyProcessor::AlphaMerge
        | DpStrategyProcessor::Instantiation { .. }
        | DpStrategyProcessor::SelectedInstantiation { .. }
        | DpStrategyProcessor::ForwardInstantiation { .. }
        | DpStrategyProcessor::SelectedForwardInstantiation { .. }
        | DpStrategyProcessor::Split
        | DpStrategyProcessor::SelectedSplit { .. } => 1,
        DpStrategyProcessor::Llm
        | DpStrategyProcessor::SemanticLabeling
        | DpStrategyProcessor::RootLabeling => 3,
        _ => 2,
    }
}

fn wait_for_delay(delay: Duration, deadline: Option<Instant>) -> bool {
    if delay.is_zero() {
        return deadline.is_none_or(|deadline| Instant::now() < deadline);
    }
    let wake = Instant::now() + delay;
    loop {
        let now = Instant::now();
        if deadline.is_some_and(|deadline| now >= deadline) {
            return false;
        }
        if now >= wake {
            return true;
        }
        let remaining = wake.saturating_duration_since(now);
        let until_deadline = deadline
            .map(|deadline| deadline.saturating_duration_since(now))
            .unwrap_or(remaining);
        thread::sleep(remaining.min(until_deadline).min(Duration::from_millis(10)));
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::core::{RewriteRule, Term, Trs};
    use crate::proving::dependency_pairs::{DpOptions, DpProofTree, dependency_pairs};
    use crate::proving::processors::dp::DpProblemState;

    #[test]
    fn generic_rewriting_schedules_all_candidates_and_serializes_selection() {
        let a = Term::app("a", vec![]);
        let trs = Trs::new_with_strategy(None, std::collections::BTreeSet::new(),
            vec![RewriteRule::new(Term::app("h", vec![a.clone()]), a.clone())],
            crate::core::RewriteStrategy::Innermost);
        let pairs = ["f#", "k#"].into_iter().map(|head|
            crate::proving::dependency_pairs::DependencyPair::new_for_test(
                Term::app(head, vec![Term::app("s", vec![a.clone()])]),
                Term::app(head, vec![Term::app("h", vec![a.clone()])]),
            )).collect();
        let state = ProblemState::DependencyPairs(DpProblemState::ordinary(trs, pairs, DpOptions::default()));
        assert_eq!(rewriting_candidate_count(&state, None), 2);
        let strategy = DpStrategy::parse("rewrite").unwrap();
        let mut cursor = 1;
        let mut alternatives = 0;
        while let Some(attempt) = next_scheduled_result_with_strategy(&state, cursor, None, Some(&strategy)) {
            assert!(attempt.next_cursor > cursor);
            cursor = attempt.next_cursor;
            if attempt.retain_fallback && matches!(attempt.result, ProcessorResult::Applied(_)) {
                alternatives += 1;
            }
            assert!(cursor < 10);
        }
        assert_eq!(alternatives, 2);
        let selected = DpStrategyProcessor::SelectedRewriting { max_per_pair: Some(2), candidate_index: 1 };
        assert_eq!(DpStrategy::parse(&selected.to_strategy_atom()).unwrap(), DpStrategy::Processor(selected));
        let first = RewritingProcessor { max_per_pair: None, candidate_index: 0, deadline: None }.apply(&state);
        let second = RewritingProcessor { max_per_pair: None, candidate_index: 1, deadline: None }.apply(&state);
        assert!(matches!(first, ProcessorResult::Applied(_)));
        assert!(matches!(second, ProcessorResult::Applied(_)));
        assert!(matches!(RewritingProcessor { max_per_pair: None, candidate_index: 2, deadline: None }.apply(&state),
            ProcessorResult::Inapplicable));
    }

    #[test]
    fn generic_narrowing_schedules_more_than_the_first_candidate() {
        let x = Term::var("x");
        let rules = ["g", "h"].into_iter().enumerate().map(|(index, name)| RewriteRule::new(
            Term::app(name, vec![if index == 0 { Term::app("a", vec![]) }
                else { Term::app("s", vec![Term::app("a", vec![])]) }]), Term::app("a", vec![]),
        )).collect();
        let trs = Trs::new(None, std::collections::BTreeSet::new(), rules);
        let pairs = [("f#", "g"), ("k#", "h")].into_iter().map(|(head, inner)|
            crate::proving::dependency_pairs::DependencyPair::new_for_test(
                Term::app(head, vec![Term::app("s", vec![x.clone()])]),
                Term::app(head, vec![Term::app(inner, vec![x.clone()])]),
            )).collect();
        let state = ProblemState::DependencyPairs(DpProblemState::ordinary(trs, pairs, DpOptions::default()));
        let count = narrowing_candidate_count(&state, None, None).unwrap();
        assert!(count >= 2, "expected distinct narrowing residuals, got {count}");
        let strategy = DpStrategy::parse("narrow").unwrap();
        let mut cursor = 1;
        let mut alternatives = 0;
        while let Some(attempt) = next_scheduled_result_with_strategy(&state, cursor, None, Some(&strategy)) {
            assert!(attempt.next_cursor > cursor);
            cursor = attempt.next_cursor;
            if attempt.retain_fallback && matches!(attempt.result, ProcessorResult::Applied(_)) {
                alternatives += 1;
            }
            assert!(cursor < 20);
        }
        assert_eq!(alternatives, count);
    }

    #[test]
    fn exact_guidance_override_is_not_cost_sorted_as_default_fallback() {
        assert_eq!(
            appended_default_strategy_index(1, false, false, true, false),
            None
        );
        assert_eq!(
            appended_default_strategy_index(2, false, false, false, false),
            Some(1)
        );
        assert_eq!(
            appended_default_strategy_index(2, false, false, true, true),
            Some(1)
        );
    }

    #[test]
    fn exact_graph_reuses_the_matching_explicit_pipeline_tail() {
        let exact = DpStrategyProcessor::ExactDependencyGraph {
            components: vec![(vec![0], true)],
            source_dp_input_xml: None,
            source_is_live: true,
        };
        assert!(exact_processor_replaces(
            &exact,
            &DpStrategyProcessor::DependencyGraph
        ));
        assert!(!exact_processor_replaces(
            &exact,
            &DpStrategyProcessor::SizeChange
        ));

        let explicit = DpStrategy::Pipeline(vec![
            DpStrategy::Processor(DpStrategyProcessor::DependencyGraph),
            DpStrategy::Processor(DpStrategyProcessor::Subterm),
            DpStrategy::Processor(DpStrategyProcessor::SizeChange),
        ]);
        let frontier = strategy_frontier(&explicit);
        let inherited_tail = matching_inherited_continuation(&exact, &frontier);
        assert_eq!(
            inherited_tail,
            Some(DpStrategy::Pipeline(vec![
                DpStrategy::Processor(DpStrategyProcessor::Subterm),
                DpStrategy::Processor(DpStrategyProcessor::SizeChange),
            ]))
        );
        let preferred = DpStrategy::Processor(DpStrategyProcessor::DependencyGraph);
        assert_eq!(
            parallel_continuation(Some(preferred.clone()), inherited_tail.clone()),
            Some(DpStrategy::Parallel {
                cancel_on: DpParallelCancel::Proof,
                strategies: vec![preferred, inherited_tail.expect("pipeline tail")],
            })
        );
    }

    #[test]
    fn exact_processor_preserves_every_matching_explicit_tail() {
        let exact = DpStrategyProcessor::ExactDependencyGraph {
            components: vec![(vec![0], true)],
            source_dp_input_xml: None,
            source_is_live: true,
        };
        let explicit = DpStrategy::Choice(vec![
            DpStrategy::Pipeline(vec![
                DpStrategy::Processor(DpStrategyProcessor::DependencyGraph),
                DpStrategy::Processor(DpStrategyProcessor::Subterm),
            ]),
            DpStrategy::Pipeline(vec![
                DpStrategy::Processor(DpStrategyProcessor::DependencyGraph),
                DpStrategy::Processor(DpStrategyProcessor::SizeChange),
            ]),
        ]);
        assert_eq!(
            matching_inherited_continuation(&exact, &strategy_frontier(&explicit)),
            Some(DpStrategy::Choice(vec![
                DpStrategy::Processor(DpStrategyProcessor::Subterm),
                DpStrategy::Processor(DpStrategyProcessor::SizeChange),
            ]))
        );
    }

    #[test]
    fn dp_events_retain_non_dp_children_in_order() {
        let trs = Trs::new(None, Default::default(), vec![RewriteRule::new(
            Term::app("f", vec![Term::var("x")]), Term::var("x"))]);
        let result = ProcessorResult::Applied(crate::proving::ProcessorApplication::new(
            vec![ProblemState::Srs(trs.clone()), ProblemState::Trs(trs)], |_| None));
        let children = residual_event_values(&result);
        assert_eq!(children.len(), 2);
        for child in children {
            let cpf = child["cpf"].as_str().unwrap();
            assert!(cpf.contains("<trsInput>"));
            assert_eq!(child["problem_key"], format!("{:x}", Sha256::digest(cpf.trim().as_bytes())));
        }
    }

    #[test]
    fn worklist_closes_an_empty_dp_residual() {
        let trs = Trs::new(
            None,
            Default::default(),
            vec![RewriteRule::new(
                Term::app("f", vec![Term::var("x")]),
                Term::var("x"),
            )],
        );
        let pairs = dependency_pairs(&trs);
        assert!(pairs.is_empty());
        let certificate = crate::proving::processors::top_level::solve_top_level_worklist(
            ProblemState::DependencyPairs(DpProblemState::ordinary(
                trs,
                pairs,
                DpOptions::default(),
            )),
            &crate::proving::ProveOptions::default(),
            None,
        )
        .expect("empty DP residual should close in the common worklist");
        let crate::proving::processors::ProblemCertificate::DependencyPairTree(tree) = certificate
        else {
            panic!("expected a DP tree")
        };
        assert_eq!(tree, DpProofTree::Empty);
    }

    #[test]
    fn explicit_sequence_advances_instead_of_restarting_at_each_child() {
        let strategy =
            DpStrategy::parse("pipeline(graph; instantiate(per-pair=3); subterm)").unwrap();
        let first = strategy_frontier(&strategy);
        assert_eq!(first.len(), 1);
        assert_eq!(first[0].processor, DpStrategyProcessor::DependencyGraph);
        assert_eq!(
            first[0]
                .continuation
                .as_ref()
                .map(DpStrategy::to_strategy_atom),
            Some("pipeline(instantiate(per-pair=3); subterm)".to_string())
        );

        let second = strategy_frontier(first[0].continuation.as_ref().unwrap());
        assert_eq!(second.len(), 1);
        assert!(matches!(
            second[0].processor,
            DpStrategyProcessor::Instantiation {
                max_per_pair: Some(3)
            }
        ));
        assert_eq!(
            second[0]
                .continuation
                .as_ref()
                .map(DpStrategy::to_strategy_atom),
            Some("subterm".to_string())
        );
    }

    #[test]
    fn recursive_sequence_preserves_a_nested_pipeline_tail() {
        let strategy =
            DpStrategy::parse("graph; (subterm | pipeline(instantiate(per-pair=3); size-change))")
                .unwrap();
        let frontier = strategy_frontier(&strategy);
        let instantiation = frontier
            .iter()
            .find(|scheduled| {
                matches!(
                    scheduled.processor,
                    DpStrategyProcessor::Instantiation {
                        max_per_pair: Some(3)
                    }
                )
            })
            .expect("nested pipeline should expose its first transformation");

        let continuation = instantiation
            .continuation
            .as_ref()
            .expect("nested pipeline tail must survive the recursive sequence");
        assert!(matches!(
            continuation,
            DpStrategy::Pipeline(stages)
                if matches!(stages.first(), Some(DpStrategy::Processor(
                    DpStrategyProcessor::SizeChange
                )))
        ));
    }

    #[test]
    fn native_gm04_rpo_recovers_roles_without_parent_options() {
        assert!(matches!(DpStrategy::parse("gm04-rpo").unwrap(),
            DpStrategy::Processor(DpStrategyProcessor::Gm04AdministrativeRpo)));
        assert_eq!(DpStrategyProcessor::Gm04AdministrativeRpo.to_strategy_atom(), "gm04-rpo");
        for names in [["A", "M", "P", "O", "T"], ["run", "done", "scan", "ready", "wrap"]] {
            let [a, m, p, o, t] = names;
            let input = format!(r#"
(format TRS) (strategy INNERMOST)
(fun {a} 1) (fun {m} 1) (fun {p} 1) (fun {o} 1) (fun {t} 1) (fun f 1) (fun c 0)
(rule ({a} (f X)) ({m} c))
(rule ({p} (f X)) (f ({p} X)))
(rule ({p} c) ({o} c))
(rule (f ({o} X)) ({o} (f X)))
(rule ({t} ({m} X)) ({t} ({p} X)))
(rule ({t} ({o} X)) ({t} ({a} X)))
"#);
            let trs = crate::parsing::parse_ari_trs(None, &input).unwrap();
            let state = DpProblemState::ordinary(trs, Vec::new(), DpOptions::default());
            let DpStrategyProcessor::ExactPathOrder { precedence_ranks, .. } =
                native_gm04_administrative_rpo(&state).expect("structural GM04 roles")
            else { panic!("expected RPO") };
            assert!(precedence_ranks[a] < precedence_ranks["f"]);
            assert!(precedence_ranks[p] < precedence_ranks["f"]);
            assert!(precedence_ranks["f"] < precedence_ranks[o]);
            assert!(state.options.gm04_residual.is_none());
        }
        let trs = crate::parsing::parse_ari_trs(None,
            "(format TRS) (fun active 1) (fun mark 1) (rule (active X) (mark X))").unwrap();
        let state = DpProblemState::ordinary(trs, Vec::new(), DpOptions::default());
        assert!(native_gm04_administrative_rpo(&state).is_none());
    }

    #[test]
    fn gm04_administrative_rpo_places_marked_callees_below_top_sharp() {
        use crate::core::{RewriteStrategy, Symbol, Trs};
        use crate::proving::dependency_pairs::Gm04ResidualContext;

        let trs = Trs::new_with_strategy(
            None,
            Default::default(),
            Vec::new(),
            RewriteStrategy::Innermost,
        );
        let mut options = DpOptions::default();
        options.gm04_residual = Some(Gm04ResidualContext {
            pairs: Vec::new(),
            rules: Vec::new(),
            q: Vec::new(),
            top_sharp: Symbol::new("top#"),
            active: Symbol::new("active"),
            proper: Symbol::new("proper"),
            ok: Symbol::new("ok"),
            mark: Symbol::new("mark"),
            top: Symbol::new("top"),
            symbols: [
                "active", "active#", "proper", "proper#", "source", "ok", "mark", "top", "top#",
            ]
            .into_iter()
            .map(str::to_owned)
            .collect(),
            graph_decomposed: false,
        });
        let state = DpProblemState::ordinary(trs, Vec::new(), options);
        let DpStrategyProcessor::ExactPathOrder {
            precedence_ranks, ..
        } = gm04_administrative_rpo(&state).expect("GM04 administrative RPO")
        else {
            panic!("expected exact path order")
        };

        assert!(precedence_ranks["active"] < precedence_ranks["source"]);
        assert!(precedence_ranks["proper"] < precedence_ranks["source"]);
        assert!(precedence_ranks["top#"] < precedence_ranks["active#"]);
        assert!(precedence_ranks["top#"] < precedence_ranks["proper#"]);
    }

    #[test]
    fn gm04_assumption_is_exact_and_private() {
        use crate::core::{RewriteRule, RewriteStrategy, Symbol, Term, Trs};
        use crate::proving::dependency_pairs::Gm04ResidualContext;

        let x = Term::var("x");
        let rule = RewriteRule::new(
            Term::app("active", vec![x.clone()]),
            Term::app("mark", vec![x.clone()]),
        );
        let pair_rule = RewriteRule::new(
            Term::app("top#", vec![Term::app("ok", vec![x.clone()])]),
            Term::app("top#", vec![Term::app("active", vec![x])]),
        );
        let y = Term::var("canonical");
        let expected_rule = RewriteRule::new(
            Term::app("active", vec![y.clone()]),
            Term::app("mark", vec![y.clone()]),
        );
        let expected_pair_rule = RewriteRule::new(
            Term::app("top#", vec![Term::app("ok", vec![y.clone()])]),
            Term::app("top#", vec![Term::app("active", vec![y])]),
        );
        let pair = crate::proving::DependencyPair::from_rule(pair_rule.clone(), 0);
        let trs = Trs::new_with_strategy(
            None,
            Default::default(),
            vec![rule.clone()],
            RewriteStrategy::Innermost,
        );
        let mut options = DpOptions::default();
        options.gm04_residual = Some(Gm04ResidualContext {
            pairs: vec![expected_pair_rule],
            rules: vec![expected_rule.clone()],
            q: vec![expected_rule.lhs().clone()],
            top_sharp: Symbol::new("top#"),
            active: Symbol::new("active"),
            proper: Symbol::new("proper"),
            ok: Symbol::new("ok"),
            mark: Symbol::new("mark"),
            top: Symbol::new("top"),
            symbols: vec!["active".into(), "mark".into(), "ok".into(), "top#".into()],
            graph_decomposed: false,
        });
        let state = DpProblemState::ordinary(trs, vec![pair.clone()], options);
        let assumption = gm04_residual_assumption(&state).expect("exact GM04 residual");
        assert!(strict_oracle_terminal(&state));
        let DpProofTree::TransformationExact { payload_xml, .. } = assumption else {
            panic!("expected the private GM04 finiteness assumption")
        };
        assert!(payload_xml.contains("<trs>"));
        assert!(payload_xml.contains("<name>active</name>"));
        assert!(!payload_xml.contains("<usableRules>"));

        let mut nonminimal = state.clone();
        nonminimal.stats.minimal = false;
        assert!(gm04_residual_assumption(&nonminimal).is_some());
        assert!(strict_oracle_terminal(&nonminimal));

        let mut full = state.clone();
        full.trs = Trs::new_with_strategy(
            None,
            Default::default(),
            vec![expected_rule.clone()],
            RewriteStrategy::Full,
        );
        assert!(gm04_residual_assumption(&full).is_none());
        assert!(!strict_oracle_terminal(&full));

        let mut wrong_q = state.clone();
        wrong_q.innermost_lhss = Some(vec![Term::app("foreign", vec![])]);
        assert!(gm04_residual_assumption(&wrong_q).is_none());
        assert!(!strict_oracle_terminal(&wrong_q));

        let strict_cycle = dp_cycle_key(&ProblemState::DependencyPairs(state.clone()), 1);
        let mut active_rule_parent = state.clone();
        active_rule_parent.stats.active_rules = Some(vec![rule]);
        let mut active_rule_child = state.clone();
        active_rule_child.stats.active_rules = Some(Vec::new());
        assert_ne!(
            dp_cycle_key(&ProblemState::DependencyPairs(active_rule_parent), 1),
            dp_cycle_key(&ProblemState::DependencyPairs(active_rule_child), 1),
            "distinct GM04 usable-rule residuals must have distinct worklist states"
        );
        let mut weak = state;
        weak.stats.weak_pairs.push(pair);
        assert!(gm04_residual_assumption(&weak).is_none());
        assert_ne!(
            strict_cycle,
            dp_cycle_key(&ProblemState::DependencyPairs(weak), 1),
            "weakening a GM04 pair must produce a distinct worklist state"
        );
    }
}
