use crate::proving::dependency_pairs::{
    CsrDpConstruction, CsrDpProblemContext, DpProblemContext, DpProofTree,
    muterm_expand_dependency_pairs, muterm_innermost_unhiding_rules,
};

use super::super::{
    ProblemCertificate, ProblemState, ProcessorApplication, ProcessorResult, WorklistProcessor,
};

/// Expand one typed MU-TERM graph component into its ordinary macro pairs.
/// CeTA checks this boundary with `expandedStrongUsableRulesProc` (or the
/// stronger ordinary continuation); this processor only materializes the
/// independently guided child state.
pub struct MutermExpandProcessor;

impl WorklistProcessor for MutermExpandProcessor {
    fn name(&self) -> &'static str {
        "muterm-expand"
    }

    fn apply(&self, state: &ProblemState) -> ProcessorResult {
        let ProblemState::DependencyPairs(problem) = state else {
            return ProcessorResult::Inapplicable;
        };
        let DpProblemContext::ContextSensitive(context) = &problem.stats.problem else {
            return ProcessorResult::Inapplicable;
        };
        if context.construction != CsrDpConstruction::MutermUnhiding {
            return ProcessorResult::Inapplicable;
        }

        let bridges = muterm_innermost_unhiding_rules(&context.csr);
        let expanded = muterm_expand_dependency_pairs(&problem.pairs, &bridges);
        if expanded == problem.pairs {
            return ProcessorResult::Inapplicable;
        }

        let mut child = problem.clone();
        child.pairs = expanded;
        child.stats.problem =
            DpProblemContext::ContextSensitive(CsrDpProblemContext::muterm_expanded(&context.csr));
        child.stats.active_rules = None;
        child.stats.graph_rules = None;
        child.stats.weak_pairs.clear();
        child.stats.minimal = true;
        child.innermost_lhss = None;

        ProcessorResult::Applied(ProcessorApplication::new(
            vec![ProblemState::DependencyPairs(child)],
            move |children| {
                let [ProblemCertificate::DependencyPairTree(proof)] =
                    <[ProblemCertificate; 1]>::try_from(children).ok()?
                else {
                    return None;
                };
                Some(ProblemCertificate::DependencyPairTree(
                    DpProofTree::TransformationExact {
                        processor_tag: "__mutermExpanded".to_string(),
                        payload_xml: String::new(),
                        proof: Box::new(proof),
                    },
                ))
            },
        ))
    }
}
