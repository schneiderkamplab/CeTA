//! CeTA Narrowing_Impl.narrowing_complete_proc, restricted to Q = empty.
//! For a NO child, a single actual narrowing suffices; termination-side
//! linearity and coverage requirements must not be reused here.

use super::super::{
    ProblemCertificate, ProblemState, ProcessorApplication, ProcessorResult, WorklistProcessor,
};
use super::nontermination_cycle::canonical_pair_rule_order;
use crate::core::RewriteStrategy;
use crate::proving::dependency_pairs::{
    DpNarrowingStep, DpProblemContext, narrow_pair_at_exact_position, positions_with_subterms,
    strategy_timed_out,
};
use crate::proving::{DpNonterminationProof, rewrite_rules_are_variants};
use std::time::Instant;

pub struct NonterminationNarrowingProcessor {
    pub candidate: usize,
    pub lookahead: bool,
    pub all: bool,
    pub below: bool,
    pub deadline: Option<Instant>,
}

impl WorklistProcessor for NonterminationNarrowingProcessor {
    fn name(&self) -> &'static str {
        "nontermination-narrow"
    }
    fn apply(&self, state: &ProblemState) -> ProcessorResult {
        let ProblemState::DependencyPairs(problem) = state else {
            return ProcessorResult::Inapplicable;
        };
        if !matches!(problem.stats.problem, DpProblemContext::Ordinary)
            || !problem.stats.weak_pairs.is_empty()
            || !problem.stats.strict_rules.is_empty()
            || problem
                .innermost_lhss
                .as_ref()
                .is_some_and(|q| !q.is_empty())
            || (problem.innermost_lhss.is_none() && problem.trs.strategy() != RewriteStrategy::Full)
        {
            return ProcessorResult::Inapplicable;
        }
        if strategy_timed_out(self.deadline) {
            return ProcessorResult::TimedOut;
        }
        let Some((pairs, rule_order)) = canonical_pair_rule_order(problem) else {
            return ProcessorResult::Inapplicable;
        };
        let active = problem
            .stats
            .active_rules
            .as_deref()
            .unwrap_or(problem.trs.rules());
        let rules = rule_order
            .into_iter()
            .map(|i| active[i].clone())
            .collect::<Vec<_>>();
        let mut candidate = 0;
        let mut ranked = Vec::new();
        for index in pairs {
            let pair = &problem.pairs[index];
            // CPF replacement is set-based. Explicit alpha merging can
            // normalize duplicates before this native step.
            if problem
                .pairs
                .iter()
                .filter(|p| rewrite_rules_are_variants(&p.as_rule(), &pair.as_rule()))
                .count()
                != 1
            {
                continue;
            }
            let mut positions = positions_with_subterms(pair.rhs());
            // Prefer existing structured redexes before inventing instances
            // of variables. Deep positions expose the small residual calls
            // before their enclosing administrative symbols.
            positions.sort_by_key(|(position, term)| {
                (
                    matches!(term, crate::core::Term::Var(_)),
                    std::cmp::Reverse(position.len()),
                    position.clone(),
                )
            });
            for (position, _) in positions {
                if strategy_timed_out(self.deadline) {
                    return ProcessorResult::TimedOut;
                }
                // Term traversal is zero-based; DP narrowing witnesses and
                // their CPF positions use one-based argument indices.
                let position = position
                    .into_iter()
                    .map(|index| index + 1)
                    .collect::<Vec<_>>();
                let Some(narrowings) = (if self.below {
                    crate::proving::dependency_pairs::narrow_pair_at_position(
                        pair,
                        &position,
                        &rules,
                        &[],
                        4096,
                    )
                } else {
                    narrow_pair_at_exact_position(pair, &position, &rules, &[])
                }) else {
                    continue;
                };
                let groups = if self.all {
                    vec![narrowings]
                } else {
                    narrowings.into_iter().map(|p| vec![p]).collect()
                };
                for narrowed in groups {
                    if narrowed.is_empty()
                        || (narrowed.len() == 1
                            && rewrite_rules_are_variants(&pair.as_rule(), &narrowed[0].as_rule()))
                    {
                        continue;
                    }
                    if self.lookahead {
                        let cost = narrowed
                            .iter()
                            .flat_map(|p| {
                                problem
                                    .pairs
                                    .iter()
                                    .map(|next| continuation_cost(p.rhs(), next.lhs(), &rules))
                            })
                            .min()
                            .unwrap_or(usize::MAX);
                        let size = narrowed
                            .iter()
                            .map(|p| positions_with_subterms(p.rhs()).len())
                            .sum::<usize>();
                        ranked.push(((cost, size, candidate), index, position.clone(), narrowed));
                        candidate += 1;
                        continue;
                    }
                    if candidate != self.candidate {
                        candidate += 1;
                        continue;
                    }
                    let step = DpNarrowingStep {
                        pair: pair.clone(),
                        position,
                        narrowings: narrowed.clone(),
                    };
                    let mut child = problem.clone();
                    child.pairs.splice(index..=index, narrowed);
                    return ProcessorResult::Applied(ProcessorApplication::new(
                        vec![ProblemState::DependencyPairs(child)],
                        move |children| {
                            let [ProblemCertificate::DependencyPairNontermination(proof)] =
                                <[ProblemCertificate; 1]>::try_from(children).ok()?
                            else {
                                return None;
                            };
                            Some(ProblemCertificate::DependencyPairNontermination(
                                DpNonterminationProof::Narrowing {
                                    step: step.clone(),
                                    proof: Box::new(proof),
                                },
                            ))
                        },
                    ));
                }
            }
        }
        if self.lookahead {
            ranked.sort_by_key(|(key, _, _, _)| *key);
            if let Some((_, index, position, narrowed)) = ranked.into_iter().nth(self.candidate) {
                let step = DpNarrowingStep {
                    pair: problem.pairs[index].clone(),
                    position,
                    narrowings: narrowed.clone(),
                };
                let mut child = problem.clone();
                child.pairs.splice(index..=index, narrowed);
                return ProcessorResult::Applied(ProcessorApplication::new(
                    vec![ProblemState::DependencyPairs(child)],
                    move |children| {
                        let [ProblemCertificate::DependencyPairNontermination(proof)] =
                            <[ProblemCertificate; 1]>::try_from(children).ok()?
                        else {
                            return None;
                        };
                        Some(ProblemCertificate::DependencyPairNontermination(
                            DpNonterminationProof::Narrowing {
                                step: step.clone(),
                                proof: Box::new(proof),
                            },
                        ))
                    },
                ));
            }
        }
        ProcessorResult::Inapplicable
    }
}

// A search heuristic only: favor exposing the constructor pattern required
// by a following marked call. It changes ranking, never applicability or the
// independently checked narrowing proof.
fn continuation_cost(
    actual: &crate::core::Term,
    pattern: &crate::core::Term,
    rules: &[crate::core::RewriteRule],
) -> usize {
    use crate::core::Term;
    match (actual, pattern) {
        (_, Term::Var(_)) | (Term::Var(_), _) => 0,
        (
            Term::App {
                symbol: a,
                args: xs,
            },
            Term::App {
                symbol: b,
                args: ys,
            },
        ) if a == b && xs.len() == ys.len() => xs
            .iter()
            .zip(ys)
            .map(|(x, y)| continuation_cost(x, y, rules))
            .sum(),
        _ => {
            if rules
                .iter()
                .any(|r| r.lhs().root_symbol() == actual.root_symbol())
            {
                1
            } else {
                100
            }
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::core::{RewriteRule, Term, Trs, Variable};
    use crate::proving::dependency_pairs::{DependencyPair, DpOptions, DpProofTree, DpStrategy};
    use crate::proving::processors::dp::{
        DpNonterminationProcessor, DpProblemState, NarrowingProcessor,
    };

    fn problem() -> DpProblemState {
        let x = Term::var("x");
        let rule = RewriteRule::new(Term::app("contract", vec![x.clone(), x.clone()]), x.clone());
        let pair = DependencyPair::new_for_test(
            Term::app("call#", vec![x.clone()]),
            Term::app("call#", vec![Term::app("contract", vec![x.clone(), x])]),
        );
        DpProblemState::ordinary(
            Trs::new(None, [Variable::new("x")].into_iter().collect(), vec![rule]),
            vec![pair],
            DpOptions::default(),
        )
    }

    #[test]
    fn no_narrowing_does_not_weaken_termination_or_q_guards() {
        let state = problem();
        assert!(matches!(
            (NarrowingProcessor {
                max_per_pair: Some(128),
                candidate_index: 0,
                require_depth_bound: false,
                deadline: None
            })
            .apply(&ProblemState::DependencyPairs(state.clone())),
            ProcessorResult::Inapplicable
        ));
        let native = NonterminationNarrowingProcessor {
            candidate: 0,
            lookahead: false,
            all: false,
            below: false,
            deadline: None,
        };
        let ProcessorResult::Applied(app) =
            native.apply(&ProblemState::DependencyPairs(state.clone()))
        else {
            panic!()
        };
        let ProblemState::DependencyPairs(child) = &app.residuals[0] else {
            panic!()
        };
        assert_eq!(child.trs, state.trs);
        assert_eq!(child.innermost_lhss, state.innermost_lhss);
        assert_eq!(
            child.stats.normal_form_substitutions,
            state.stats.normal_form_substitutions
        );
        assert!(
            app.reconstruct(vec![ProblemCertificate::DependencyPairTree(
                DpProofTree::Empty
            )])
            .is_none()
        );
        let mut restricted = state;
        restricted.innermost_lhss = Some(vec![Term::var("q")]);
        assert!(matches!(
            native.apply(&ProblemState::DependencyPairs(restricted)),
            ProcessorResult::Inapplicable
        ));
        assert!(DpStrategy::parse("nontermination-narrow(candidate=0)").is_ok());
    }

    #[test]
    fn local_ceta_no_narrowing_certifies_nonlinear_right_hand_side() {
        let mut state = problem();
        let mut rules = state.trs.rules().to_vec();
        rules.push(RewriteRule::new(
            rules[0].lhs().clone(),
            Term::app("other", vec![]),
        ));
        state.trs = Trs::new(None, state.trs.variables().clone(), rules);
        let ProcessorResult::Applied(narrow) = (NonterminationNarrowingProcessor {
            candidate: 0,
            lookahead: true,
            all: true,
            below: true,
            deadline: None,
        })
        .apply(&ProblemState::DependencyPairs(state.clone())) else {
            panic!()
        };
        let ProblemState::DependencyPairs(child) = &narrow.residuals[0] else {
            panic!()
        };
        assert_eq!(child.pairs.len(), 2, "keep both actual narrowing branches");
        let ProcessorResult::Applied(terminal) = (DpNonterminationProcessor { deadline: None })
            .apply_symbolic_loop(&narrow.residuals[0])
        else {
            panic!()
        };
        let proof = terminal.reconstruct(vec![]).unwrap();
        let ProblemCertificate::DependencyPairNontermination(proof) =
            narrow.reconstruct(vec![proof]).unwrap()
        else {
            panic!()
        };
        let xml = crate::cert::write_cpf3_dp_nontermination_state(&state, &proof).unwrap();
        assert!(xml.contains("<narrowingProc>"));
        let path =
            std::env::temp_dir().join(format!("ferrum-no-narrowing-{}.xml", std::process::id()));
        std::fs::write(&path, xml).unwrap();
        let checker = std::env::var("CETA_CSR_BIN").unwrap_or_else(|_| "../CeTA-CSR/ceta".into());
        let output = std::process::Command::new(checker)
            .arg(&path)
            .output()
            .unwrap();
        let _ = std::fs::remove_file(path);
        assert!(
            output.status.success()
                && String::from_utf8_lossy(&output.stdout).trim() == "CERTIFIED",
            "{}{}",
            String::from_utf8_lossy(&output.stdout),
            String::from_utf8_lossy(&output.stderr)
        );
    }
}
