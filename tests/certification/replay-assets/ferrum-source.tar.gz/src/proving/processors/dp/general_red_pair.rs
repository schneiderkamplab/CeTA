use std::collections::{BTreeMap, BTreeSet};

use crate::core::{RewriteRule, Term, Trs, Variable};
use crate::proving::dependency_pairs::{CsrDpConstruction, DpProblemContext, DpProofTree};
use crate::standardize::{
    StandardizationGroup, StandardizationProblem, TermPair, standardize_problem_with_bijection,
    translate_rule_symbols,
};

use super::super::{
    ProblemCertificate, ProblemState, ProcessorApplication, ProcessorResult, WorklistProcessor,
};

/// Replays a CeTA-certified CPF `generalRedPairProc` witness while exposing
/// each generated DP obligation to the ordinary state worklist.
pub struct ExactGeneralRedPairProcessor {
    pub payload_xml: String,
    pub strict_indices: Vec<usize>,
    pub bound_indices: Vec<usize>,
    pub merge: bool,
    pub source_dp_input_xml: Option<String>,
}

/// Replays the non-recursive prefix of a certified `redPairProc` or
/// `redPairUrProc`, while returning its residual DP problem to the worklist.
pub struct ExactReductionPairProcessor {
    pub processor_tag: String,
    pub payload_xml: String,
    pub removed_indices: Vec<usize>,
    pub source_pairs_xml: Option<String>,
    pub source_rules_xml: Option<String>,
    pub source_weak_pairs_xml: Option<String>,
    pub source_strict_rules_xml: Option<String>,
}

/// Retained processor atoms describe the checked reduction-pair prefix.  Old
/// event logs sometimes retained the source processor's continuation as well;
/// replay supplies a freshly reconstructed child, so serializing both creates
/// an ill-typed `<csrDpProof>` inside an ordinary `<dpProof>`.  Remove only a
/// direct continuation of the fragment (or of its optional outer processor
/// element); nested proof data inside other witness fields is untouched.
fn reduction_pair_payload_without_continuation(payload: &str, processor_tag: &str) -> String {
    let prefix = "<ferrumReductionPairPayload>";
    let wrapped = format!("{prefix}{payload}</ferrumReductionPairPayload>");
    let Ok(document) = roxmltree::Document::parse(&wrapped) else {
        return payload.to_owned();
    };
    let mut ranges = document
        .descendants()
        .filter(|node| {
            node.is_element()
                && matches!(
                    node.tag_name().name(),
                    "dpProof" | "csrDpProof" | "ordinaryDpProof"
                )
                && node.parent().is_some_and(|parent| {
                    parent.is_element()
                        && (parent.tag_name().name() == "ferrumReductionPairPayload"
                            || parent.tag_name().name() == processor_tag)
                })
        })
        .map(|node| {
            let range = node.range();
            (range.start - prefix.len())..(range.end - prefix.len())
        })
        .collect::<Vec<_>>();
    ranges.sort_by_key(|range| std::cmp::Reverse(range.start));
    let mut result = payload.to_owned();
    for range in ranges {
        result.replace_range(range, "");
    }
    result
}

impl WorklistProcessor for ExactReductionPairProcessor {
    fn name(&self) -> &'static str {
        "exact-reduction-pair"
    }

    fn apply(&self, state: &ProblemState) -> ProcessorResult {
        let replay_started = std::time::Instant::now();
        let replay_timing = std::env::var_os("FERRUM_EXACT_REPLAY_TIMING").is_some();
        let ProblemState::DependencyPairs(problem) = state else {
            return ProcessorResult::Inapplicable;
        };
        let hinted_removed = self
            .removed_indices
            .iter()
            .copied()
            .collect::<BTreeSet<_>>();
        if !matches!(
            self.processor_tag.as_str(),
            "csrRedPairUrProc"
                | "redPairProc"
                | "redPairUrProc"
                | "monoRedPairProc"
                | "monoRedPairUrProc"
                | "innermostMonoRedPairProc"
        ) {
            return ProcessorResult::Failed {
                reason: "unsupported exact reduction-pair processor tag".to_owned(),
            };
        }
        if self.processor_tag == "csrRedPairUrProc"
            && !matches!(problem.stats.problem, DpProblemContext::ContextSensitive(_))
        {
            return ProcessorResult::Inapplicable;
        }
        let current_rules = problem
            .stats
            .active_rules
            .as_deref()
            .unwrap_or(problem.trs.rules());

        // A certified transformed benchmark and the live transformation may
        // use different fresh names (for example `a__sel` versus
        // `selActive`).  Recover a complete source-to-live TRS isomorphism
        // before matching pairs, then rename the entire CPF witness.  This is
        // the same guarded bridge used by exact graph replay: no partial or
        // merely pair-overlapping state is accepted.
        let mut payload_xml = self.payload_xml.clone();
        let mut source_context = match (&self.source_pairs_xml, &self.source_rules_xml) {
            (Some(source_pairs_xml), Some(source_rules_xml)) => {
                let Ok(Some(source_pairs)) =
                    crate::parsing::parse_cpf_rule_container_fragment(source_pairs_xml, "dps")
                else {
                    return ProcessorResult::Failed {
                        reason: "exact reduction pair has invalid source-pair context".to_owned(),
                    };
                };
                let Ok(Some(source_rules)) = crate::parsing::parse_cpf_rule_container_fragment(
                    source_rules_xml,
                    "usableRules",
                ) else {
                    return ProcessorResult::Failed {
                        reason: "exact reduction pair has invalid source-rule context".to_owned(),
                    };
                };
                Some((source_pairs, source_rules))
            }
            (None, None) => None,
            _ => {
                return ProcessorResult::Failed {
                    reason: "exact reduction pair has incomplete source context".to_owned(),
                };
            }
        };
        let mut source_generalized_context =
            match (&self.source_weak_pairs_xml, &self.source_strict_rules_xml) {
                (Some(weak_xml), Some(strict_xml)) => {
                    let weak =
                        match crate::parsing::parse_cpf_rule_container_fragment(weak_xml, "dps") {
                            Ok(Some(weak)) => weak,
                            Ok(None) => {
                                return ProcessorResult::Failed {
                                    reason: "exact reduction-pair weak-pair context is missing dps"
                                        .to_owned(),
                                };
                            }
                            Err(error) => {
                                return ProcessorResult::Failed {
                                    reason: format!(
                                        "invalid exact reduction-pair weak-pair context: {error}"
                                    ),
                                };
                            }
                        };
                    let strict = match crate::parsing::parse_cpf_rule_container_fragment(
                        strict_xml,
                        "usableRules",
                    ) {
                        Ok(Some(strict)) => strict,
                        Ok(None) => return ProcessorResult::Failed {
                            reason:
                                "exact reduction-pair strict-rule context is missing usableRules"
                                    .to_owned(),
                        },
                        Err(error) => {
                            return ProcessorResult::Failed {
                                reason: format!(
                                    "invalid exact reduction-pair strict-rule context: {error}"
                                ),
                            };
                        }
                    };
                    Some((weak, strict))
                }
                (None, None) => None,
                _ => {
                    return ProcessorResult::Failed {
                        reason: "incomplete exact reduction-pair generalized context".to_owned(),
                    };
                }
            };
        if replay_timing {
            eprintln!(
                "exact-red-pair tag={} parsed-source {:?} pairs={} rules={}",
                self.processor_tag,
                replay_started.elapsed(),
                problem.pairs.len(),
                current_rules.len()
            );
        }
        if let Some((source_pairs, source_rules)) = source_context.as_mut() {
            // CPF dependency-pair problems denote sets.  Historical oracle
            // states could nevertheless serialize rule-identical pairs more
            // than once when their (non-CPF) Ferrum source provenance
            // differed.  Normalize that accidental multiplicity only when
            // the current state has already been deduplicated.  Older GM04
            // residuals deliberately retain the same multiplicity on both
            // sides; collapsing only their archived side destroys an exact
            // source match and orphans an otherwise certified witness.
            if source_pairs.len() != problem.pairs.len() {
                *source_pairs = alpha_unique_rules(source_pairs.iter().cloned());
            }
            let variables = |rules: &[crate::core::RewriteRule]| {
                rules
                    .iter()
                    .flat_map(|rule| {
                        rule.lhs()
                            .variables()
                            .into_iter()
                            .chain(rule.rhs().variables())
                    })
                    .collect::<BTreeSet<_>>()
            };
            let source_trs = Trs::new_with_strategy(
                None,
                variables(source_rules),
                source_rules.clone(),
                problem.trs.strategy(),
            );
            let live_trs = Trs::new_with_strategy(
                None,
                variables(current_rules),
                current_rules.to_vec(),
                problem.trs.strategy(),
            );
            let live_pair_rules = problem
                .pairs
                .iter()
                .map(|pair| pair.as_rule())
                .collect::<Vec<_>>();
            let uses_usable_rules = matches!(
                self.processor_tag.as_str(),
                "csrRedPairUrProc" | "redPairUrProc" | "monoRedPairUrProc"
            );
            // Root/finite labeling nests CPF labels around symbols.  The
            // portable-isomorphism search deliberately reasons about plain
            // function symbols and may therefore fail even when the archived
            // and live obligations are already alpha-equivalent.  Recognize
            // that strongest, identity case first.  The exact multiset tests
            // below remain authoritative, so this cannot make a foreign
            // witness applicable.
            let identity_source = same_rule_multiset(source_pairs, &live_pair_rules)
                && same_rule_multiset(source_rules, current_rules);
            let pair_portable = identity_source
                .then(BTreeMap::new)
                .or_else(|| {
                    portable_rule_pair_isomorphism(
                        source_rules,
                        source_pairs,
                        current_rules,
                        &live_pair_rules,
                    )
                })
                .or_else(|| {
                    // A source may have been reconstructed with an explicit
                    // active-rule override whose signature is too small to fix
                    // every symmetric symbol. Recover a candidate bijection from
                    // the complete pair multiset, then require the translated
                    // source R to match the live R exactly below.
                    if uses_usable_rules {
                        portable_rule_pair_isomorphism(&[], source_pairs, &[], &live_pair_rules)
                    } else {
                        None
                    }
                });
            let portable = pair_portable
                .clone()
                .map(|symbols| (symbols, BTreeMap::new()))
                .or_else(|| {
                    super::exact_transformation::portable_trs_isomorphism(&source_trs, &live_trs)
                        .map(|(symbols, variables)| {
                            // DP transformations mark defined symbols by
                            // appending `#`.  A TRS isomorphism therefore
                            // determines the corresponding marked-symbol
                            // isomorphism as well.  Without this extension a
                            // retained witness whose source and live TRSs use
                            // different names matches R but spuriously fails
                            // on P.  The exact multiset checks below still
                            // reject every inconsistent or partial mapping.
                            (extend_dp_marked_symbol_isomorphism(symbols), variables)
                        })
                });
            if replay_timing {
                eprintln!(
                    "exact-red-pair tag={} isomorphism {:?} pair_fast={}",
                    self.processor_tag,
                    replay_started.elapsed(),
                    pair_portable.is_some()
                );
            }
            if std::env::var_os("FERRUM_WORKLIST_TRACE").is_some() {
                eprintln!(
                    "exact red-pair portable source_rules={} live_rules={} pair_isomorphic={} isomorphic={}",
                    source_rules.len(),
                    current_rules.len(),
                    pair_portable.is_some(),
                    portable.is_some()
                );
            }
            if let Some((symbols, _)) = portable {
                *source_pairs = source_pairs
                    .iter()
                    .map(|rule| translate_rule_symbols(rule, &symbols))
                    .collect();
                *source_rules = source_rules
                    .iter()
                    .map(|rule| translate_rule_symbols(rule, &symbols))
                    .collect();
                if let Some((source_weak, source_strict)) = source_generalized_context.as_mut() {
                    *source_weak = source_weak
                        .iter()
                        .map(|rule| translate_rule_symbols(rule, &symbols))
                        .collect();
                    *source_strict = source_strict
                        .iter()
                        .map(|rule| translate_rule_symbols(rule, &symbols))
                        .collect();
                }

                // A root-local certified-witness pool intentionally offers
                // exact processors from sibling residuals.  Reject a
                // non-matching source context before rebinding the payload:
                // otherwise a perfectly well-formed sibling witness can
                // fail while trying to match one of its explicit CPF rules
                // against this state's R, aborting the worklist before the
                // state-bound candidate is considered.
                if !same_rule_multiset(source_pairs, &live_pair_rules)
                    || !same_rule_multiset(source_rules, current_rules)
                {
                    return ProcessorResult::Inapplicable;
                }
                if let Some((source_weak, source_strict)) = source_generalized_context.as_ref() {
                    let live_weak = problem
                        .stats
                        .weak_pairs
                        .iter()
                        .map(|pair| pair.as_rule())
                        .collect::<Vec<_>>();
                    // Graph decomposition may project away weak pairs from
                    // sibling components.  An archived exact witness may
                    // consequently cover a strict superset of the live weak
                    // obligations; every live obligation must still occur in
                    // the source context.
                    let weak_match = rule_multiset_subset(&live_weak, source_weak);
                    let strict_match =
                        same_rule_multiset(source_strict, &problem.stats.strict_rules);
                    if std::env::var_os("FERRUM_WORKLIST_TRACE").is_some() {
                        eprintln!(
                            "exact red-pair generalized context weak_match={weak_match} strict_match={strict_match} source_weak={} live_weak={} source_strict={} live_strict={}",
                            source_weak.len(),
                            live_weak.len(),
                            source_strict.len(),
                            problem.stats.strict_rules.len()
                        );
                    }
                    if !weak_match || !strict_match {
                        return ProcessorResult::Inapplicable;
                    }
                }
                payload_xml =
                    super::exact_transformation::translate_payload_symbols(&payload_xml, &symbols);
                // Function-symbol isomorphism is not enough for a CPF rule
                // multiset.  Membership in Premove/U/Rremove is literal in
                // CeTA, whereas canonical residuals freely rename variables
                // (x,y,...) and live transformations often use X,XS,... .
                // Rebind every explicit rule independently.  The historical
                // GM-only gate let Ferrum delete alpha-equivalent pairs in its
                // runtime state while the emitted CPF deleted only ground
                // pairs, so the recursive proof checked a different child.
                let live_pairs = problem
                    .pairs
                    .iter()
                    .map(|pair| pair.as_rule())
                    .collect::<Vec<_>>();
                payload_xml =
                    match rebind_payload_rule_variables(&payload_xml, &live_pairs, current_rules) {
                        Ok(payload) => payload,
                        Err(reason) => {
                            if std::env::var_os("FERRUM_WORKLIST_TRACE").is_some() {
                                eprintln!("exact red-pair payload rebinding failed: {reason}");
                            }
                            return ProcessorResult::Failed { reason };
                        }
                    };
                if replay_timing {
                    eprintln!(
                        "exact-red-pair tag={} rebound-payload {:?}",
                        self.processor_tag,
                        replay_started.elapsed()
                    );
                }
            }
        }
        let Ok(Some(payload_dps)) =
            crate::parsing::parse_cpf_rule_container_fragment(&payload_xml, "dps")
        else {
            return ProcessorResult::Failed {
                reason: "exact reduction pair has no parseable dps witness".to_owned(),
            };
        };
        // Extracted indices are only a cache for the archived pair order. A
        // graph decomposition or another deterministic transformation may
        // enumerate the same live DP multiset in a different order. The
        // CPF's explicit <dps> rules are the semantic witness, so relocate
        // those rules in the live problem before rejecting a valid replay.
        let hinted_rules = (hinted_removed.len() == self.removed_indices.len()
            && hinted_removed
                .iter()
                .all(|index| *index < problem.pairs.len()))
        .then(|| {
            hinted_removed
                .iter()
                .map(|index| problem.pairs[*index].as_rule())
                .collect::<Vec<_>>()
        });
        let removed = if payload_dps.is_empty() && self.removed_indices.is_empty() {
            BTreeSet::new()
        } else if hinted_rules
            .as_deref()
            .is_some_and(|rules| same_rule_multiset(&payload_dps, rules))
        {
            hinted_removed
        } else if let Some(relocated) = locate_rule_multiset_indices(&payload_dps, &problem.pairs) {
            relocated
        } else if context_bound_source(&source_context) {
            // CeTA's split_pairs intersects the CPF removal request with the
            // live P/Pw multiset.  AProVE routinely leaves rules from sibling
            // graph components in that request.  A state-bound certified
            // witness may therefore project those extras away, but an
            // unbound pool hint must still match completely.
            let relocated = locate_rule_multiset_intersection_indices(&payload_dps, &problem.pairs);
            if std::env::var_os("FERRUM_WORKLIST_TRACE").is_some()
                && relocated.len() != payload_dps.len()
            {
                eprintln!(
                    "exact red-pair partial relocation payload_dps={} relocated={}",
                    payload_dps.len(),
                    relocated.len()
                );
                for (index, rule) in payload_dps.iter().enumerate() {
                    let matched = problem
                        .pairs
                        .iter()
                        .position(|pair| alpha_equivalent_rules(rule, &pair.as_rule()));
                    eprintln!("  requested[{index}]={rule:?} matched={matched:?}");
                }
            }
            relocated
        } else {
            if std::env::var_os("FERRUM_WORKLIST_TRACE").is_some() {
                eprintln!(
                    "exact red-pair removed mismatch payload_dps={} live_pairs={}",
                    payload_dps.len(),
                    problem.pairs.len()
                );
            }
            // A root-local exact-witness pool deliberately offers witnesses
            // from sibling residuals.  A well-formed witness that does not
            // match this live P is merely inapplicable; treating it as a
            // fatal processor error prevents later state-bound candidates
            // from being tried.
            return ProcessorResult::Inapplicable;
        };
        let context_bound = match source_context {
            Some((source_pairs, source_rules)) => {
                let live_pairs = problem
                    .pairs
                    .iter()
                    .map(|pair| pair.as_rule())
                    .collect::<Vec<_>>();
                let rules_match = same_rule_multiset(&source_rules, current_rules);
                if !same_rule_multiset(&source_pairs, &live_pairs) || !rules_match {
                    if std::env::var_os("FERRUM_WORKLIST_TRACE").is_some() {
                        eprintln!(
                            "exact red-pair source mismatch pairs={} rules={}",
                            same_rule_multiset(&source_pairs, &live_pairs),
                            rules_match
                        );
                    }
                    return ProcessorResult::Inapplicable;
                }
                if let Some((source_weak, source_strict)) = source_generalized_context {
                    let live_weak = problem
                        .stats
                        .weak_pairs
                        .iter()
                        .map(|pair| pair.as_rule())
                        .collect::<Vec<_>>();
                    let weak_match = rule_multiset_subset(&live_weak, &source_weak);
                    let strict_match =
                        same_rule_multiset(&source_strict, &problem.stats.strict_rules);
                    if std::env::var_os("FERRUM_WORKLIST_TRACE").is_some() {
                        eprintln!(
                            "exact red-pair bound generalized context weak_match={weak_match} strict_match={strict_match}"
                        );
                    }
                    if !weak_match || !strict_match {
                        return ProcessorResult::Inapplicable;
                    }
                }
                true
            }
            None => false,
        };
        if !context_bound {
            // Unbound order hints still select live rules modulo alpha
            // renaming. CPF deletion is literal, so emit the live variable
            // spellings just as for source-bound witnesses above.
            let live_pairs = problem.pairs.iter().map(|pair| pair.as_rule()).collect::<Vec<_>>();
            payload_xml = match rebind_payload_rule_variables(&payload_xml, &live_pairs, current_rules) {
                Ok(payload) => payload,
                Err(reason) => return ProcessorResult::Failed { reason },
            };
        }
        if matches!(problem.stats.problem, DpProblemContext::ContextSensitive(_))
            && matches!(self.processor_tag.as_str(), "redPairProc")
            && !current_rules.is_empty()
            && !context_bound
        {
            // A plain, unbound hint cannot establish the stronger ordinary
            // DP obligation.  A context-bound exact witness, however, checks
            // the complete live P/R state and is emitted below CPF's explicit
            // `<ordinaryDpProof>` bridge.
            return ProcessorResult::Inapplicable;
        }
        if !context_bound
            && matches!(
                self.processor_tag.as_str(),
                "monoRedPairProc" | "innermostMonoRedPairProc"
            )
            && payload_dps.len()
                != problem
                    .pairs
                    .iter()
                    .filter(|pair| !problem.stats.weak_pairs.contains(pair))
                    .count()
        {
            // In an ordinary DP problem every pair is strict, so this is the
            // historical all-pairs guard.  After splitProc, however, P may be
            // entirely weak while only an ordinary rule remains strict.  A
            // monotonic rule-removal witness then legitimately has empty
            // `<dps>` and a non-empty `<trs>`.
            return ProcessorResult::Inapplicable;
        }
        let mut child = problem.clone();
        child.pairs = problem
            .pairs
            .iter()
            .enumerate()
            .filter(|(index, _)| !removed.contains(index))
            .map(|(_, pair)| pair.clone())
            .collect();
        child.stats.weak_pairs = child
            .pairs
            .iter()
            .filter(|pair| problem.stats.weak_pairs.contains(pair))
            .cloned()
            .collect();
        if matches!(problem.stats.problem, DpProblemContext::ContextSensitive(_))
            && self.processor_tag != "csrRedPairUrProc"
        {
            // `ReductionPairExact` is serialized as one ordinary DP proof
            // containing this processor and its whole continuation.  Make
            // that boundary equally explicit in the recursive runtime state.
            child.stats.problem = DpProblemContext::Ordinary;
            // The verified minimal CSR-DP checker deliberately enters
            // `check_csr_dp_ordinary_min` at this boundary.  Consequently
            // the ordinary continuation retains the source minimal-chain
            // assumption; dropping it here made Ferrum reject complete CPFs
            // which the production checker accepts (notably csrdiv).
            // Non-minimal sources already carry `stats.minimal = false`, so
            // no extra loss marker is needed for them.  The recursive native
            // `csrRedPairUrProc` path remains context-sensitive above.
            child.stats.ordinary_bridge_loses_minimality = false;
        }
        // Match the residual-state transition of the synthesizing reduction-
        // pair processor.  Even a plain redPairProc records the weak rule
        // component that was oriented at this step as the transformation
        // context for its child.  Dropping it here made an exact CPF witness
        // produce a different, context-losing oracle state from the same
        // synthesized witness.
        if matches!(problem.stats.problem, DpProblemContext::Ordinary) {
            child.stats.transformation_rules = Some(current_rules.to_vec());
        }
        let usable_rules = if matches!(
            self.processor_tag.as_str(),
            "csrRedPairUrProc" | "redPairUrProc" | "monoRedPairUrProc"
        ) {
            let Ok(Some(usable_rules)) =
                crate::parsing::parse_cpf_rule_container_fragment(&payload_xml, "usableRules")
            else {
                return ProcessorResult::Failed {
                    reason: "exact usable-rule reduction pair has no parseable usableRules witness"
                        .to_owned(),
                };
            };
            let current = current_rules;
            match &problem.stats.problem {
                DpProblemContext::ContextSensitive(context)
                    if self.processor_tag == "csrRedPairUrProc"
                        && problem.stats.minimal
                        && crate::proving::dependency_pairs::csr_construction_uses_u3(context.construction)
                        && crate::proving::dependency_pairs::csr_pairs_have_marked_or_fresh_unhiding_roots(
                            &context.csr, &problem.pairs,
                        ) =>
                {
                    let required = crate::proving::dependency_pairs::csr_u3_usable_rules(
                        &context.csr, current, &problem.pairs,
                    );
                    if !rule_multiset_subset(&required, &usable_rules)
                        || !rule_multiset_subset(&usable_rules, current)
                    {
                        return ProcessorResult::Inapplicable;
                    }
                }
                DpProblemContext::Ordinary => {
                    if !rule_multiset_subset(&usable_rules, current) {
                        return ProcessorResult::Inapplicable;
                    }
                }
                DpProblemContext::ContextSensitive(context) if context.use_qcs_usable_rules => {
                    // The exact CPF node carries its usable-rule obligation,
                    // and the production checker recomputes the applicable
                    // QCS closure. Ferrum's search-side closure is deliberately
                    // broader for some improved CS-DP states, so it is not a
                    // valid rejection oracle for an otherwise exact witness.
                    if !rule_multiset_subset(&usable_rules, current) {
                        return ProcessorResult::Inapplicable;
                    }
                }
                DpProblemContext::ContextSensitive(context)
                    if context.construction == CsrDpConstruction::Innermost =>
                {
                    if !rule_multiset_subset(&usable_rules, current) {
                        return ProcessorResult::Inapplicable;
                    }
                }
                // Safe/native/conservative CSR-DP problems do not use the
                // QCS or innermost usable-rule theorem represented by pooled
                // exact fragments.  Pair overlap alone is not a proof that a
                // redPairUrProc may cross this construction boundary.
                DpProblemContext::ContextSensitive(_) => {
                    return ProcessorResult::Inapplicable;
                }
            }
            Some(usable_rules)
        } else {
            None
        };
        // Native recursive CSR usable-rule reduction pairs continue over the
        // certified usable-rule component.  Preserve it just as the
        // synthesizing processor does; otherwise exact replay materializes a
        // context-losing child with a different oracle identity.
        if self.processor_tag == "csrRedPairUrProc" {
            child.stats.transformation_rules = usable_rules.clone();
        }
        if matches!(
            self.processor_tag.as_str(),
            "monoRedPairProc" | "monoRedPairUrProc" | "innermostMonoRedPairProc"
        ) {
            let Ok(Some(strict_rules)) =
                crate::parsing::parse_cpf_rule_container_fragment(&payload_xml, "trs")
            else {
                return ProcessorResult::Failed {
                    reason: "exact monotonic reduction pair has no parseable trs witness"
                        .to_owned(),
                };
            };
            // monoRedPairUrProc deletes non-usable rules as well as the
            // explicitly strict usable rules (CeTA's Rremove = non_ur @ Rr).
            // The plain monotonic processor deletes Rr from the incoming R.
            let base_rules = usable_rules.as_deref().unwrap_or(current_rules);
            let residual_rules = if context_bound {
                // mono_redpair_proc uses split_rules, hence Rremove is
                // semantically intersected with the current R/Rw.  Preserve
                // that behavior for exact, state-bound CPF replay.
                subtract_rule_multiset_intersection(base_rules, &strict_rules)
            } else {
                let Some(residual_rules) = subtract_rule_multiset(base_rules, &strict_rules) else {
                    return ProcessorResult::Inapplicable;
                };
                residual_rules
            };
            if removed.is_empty() && same_rule_multiset(&residual_rules, current_rules) {
                return ProcessorResult::Inapplicable;
            }
            let mut residual_occurrences = residual_rules.clone();
            if child.trs.strategy() == crate::core::RewriteStrategy::Innermost
                && problem.stats.strict_rules.is_empty()
            {
                // Innermost DP oracles predating generalized rule splitting
                // represent the same recursive R component as an active-rule
                // restriction over the original TRS.  Keep that stable
                // representation for ordinary innermost reductions.  The
                // generalized Standard path below still materializes R in the
                // base TRS, as required by splitProc and CPF reconstruction.
                child.stats.active_rules = (residual_rules.as_slice() != child.trs.rules())
                    .then(|| residual_rules.clone());
                child.stats.graph_rules =
                    (residual_rules.as_slice() != child.trs.rules()).then_some(residual_rules);
            } else {
                child.trs = Trs::new_with_strategy(
                    child.trs.name().map(str::to_owned),
                    child.trs.variables().clone(),
                    residual_rules.clone(),
                    child.trs.strategy(),
                );
                child.stats.active_rules = None;
                child.stats.graph_rules = None;
                // Keep the incoming mathematical R as the reconstruction
                // context.  The executable child already carries R' in
                // `child.trs`; replacing this provenance by R' loses the
                // standard CPF view `R + usableRules=R'` and orphans every
                // nested oracle state after a monotonic usable-rule deletion.
                // Exact processors validate against the executable R' before
                // use, so retaining the parent obligation is both safe and
                // sufficient for contextless proof-state projection.
                if !problem.stats.active_rules_are_residual {
                    // Preserve the historical canonical spelling for an
                    // ordinary reduction that has no earlier mathematical-R
                    // projection.  When a usable-rule step already supplied
                    // that projection, retain it instead of replacing it by
                    // R'.
                    child.stats.transformation_rules = Some(residual_rules);
                }
            }
            // A generalized DP problem may carry strict ordinary rules in
            // addition to strict dependency pairs.  For monoRedPairUrProc,
            // CeTA deletes not only the explicit strict `<trs>` payload but
            // also every non-usable rule.  Therefore the authoritative child
            // strict set is the parent strict multiset intersected with the
            // residual active R, not merely `strict_rules` subtracted from it.
            // Keeping a non-usable strict rule here produced a phantom
            // obligation after an otherwise terminal certified processor.
            child.stats.strict_rules.retain(|parent_strict| {
                let Some(position) = residual_occurrences
                    .iter()
                    .position(|residual| alpha_equivalent_rules(parent_strict, residual))
                else {
                    return false;
                };
                residual_occurrences.remove(position);
                true
            });
        }
        let processor_tag = self.processor_tag.clone();
        let payload_xml = reduction_pair_payload_without_continuation(&payload_xml, &processor_tag);
        let removed_count = removed.len();
        if std::env::var_os("FERRUM_WORKLIST_TRACE").is_some() {
            eprintln!(
                "exact red-pair applied tag={processor_tag} removed={removed_count} parent_pairs={} child_pairs={}",
                problem.pairs.len(),
                child.pairs.len()
            );
        }
        if replay_timing {
            eprintln!(
                "exact-red-pair tag={} complete {:?} removed={} residual={}",
                processor_tag,
                replay_started.elapsed(),
                removed_count,
                child.pairs.len()
            );
        }
        ProcessorResult::Applied(ProcessorApplication::new(
            vec![ProblemState::DependencyPairs(child)],
            move |mut children: Vec<ProblemCertificate>| {
                let processor_tag = processor_tag.clone();
                let payload_xml = payload_xml.clone();
                let [ProblemCertificate::DependencyPairTree(tree)] = children.as_mut_slice() else {
                    return None;
                };
                Some(ProblemCertificate::DependencyPairTree(
                    DpProofTree::ReductionPairExact {
                        processor_tag,
                        payload_xml,
                        removed_count,
                        proof: Box::new(std::mem::replace(tree, DpProofTree::Empty)),
                    },
                ))
            },
        ))
    }
}

fn locate_rule_multiset_indices(
    rules: &[crate::core::RewriteRule],
    pairs: &[crate::proving::dependency_pairs::DependencyPair],
) -> Option<BTreeSet<usize>> {
    if rules.is_empty() {
        return None;
    }
    let mut matched = BTreeSet::new();
    for rule in rules {
        let index = pairs.iter().enumerate().find_map(|(index, pair)| {
            let pair_rule = pair.as_rule();
            (!matched.contains(&index) && alpha_equivalent_rules(rule, &pair_rule)).then_some(index)
        })?;
        matched.insert(index);
    }
    Some(matched)
}

fn locate_rule_multiset_intersection_indices(
    rules: &[crate::core::RewriteRule],
    pairs: &[crate::proving::dependency_pairs::DependencyPair],
) -> BTreeSet<usize> {
    let mut matched = BTreeSet::new();
    for rule in rules {
        if let Some(index) = pairs.iter().enumerate().find_map(|(index, pair)| {
            let pair_rule = pair.as_rule();
            (!matched.contains(&index) && alpha_equivalent_rules(rule, &pair_rule)).then_some(index)
        }) {
            matched.insert(index);
        }
    }
    matched
}

fn context_bound_source(
    source_context: &Option<(Vec<crate::core::RewriteRule>, Vec<crate::core::RewriteRule>)>,
) -> bool {
    source_context.is_some()
}

fn subtract_rule_multiset(
    rules: &[crate::core::RewriteRule],
    removed: &[crate::core::RewriteRule],
) -> Option<Vec<crate::core::RewriteRule>> {
    let mut deleted = vec![false; rules.len()];
    for removed_rule in removed {
        let index = rules.iter().enumerate().find_map(|(index, rule)| {
            (!deleted[index] && alpha_equivalent_rules(removed_rule, rule)).then_some(index)
        })?;
        deleted[index] = true;
    }
    Some(
        rules
            .iter()
            .enumerate()
            .filter_map(|(index, rule)| (!deleted[index]).then_some(rule.clone()))
            .collect(),
    )
}

fn subtract_rule_multiset_intersection(
    rules: &[crate::core::RewriteRule],
    removed: &[crate::core::RewriteRule],
) -> Vec<crate::core::RewriteRule> {
    let mut deleted = vec![false; rules.len()];
    for removed_rule in removed {
        if let Some(index) = rules.iter().enumerate().find_map(|(index, rule)| {
            (!deleted[index] && alpha_equivalent_rules(removed_rule, rule)).then_some(index)
        }) {
            deleted[index] = true;
        }
    }
    rules
        .iter()
        .enumerate()
        .filter_map(|(index, rule)| (!deleted[index]).then_some(rule.clone()))
        .collect()
}

pub(super) fn ordered_rule_pair_isomorphism(
    source_rules: &[RewriteRule],
    source_pairs: &[RewriteRule],
    live_rules: &[RewriteRule],
    live_pairs: &[RewriteRule],
) -> Option<BTreeMap<crate::core::Symbol, crate::core::Symbol>> {
    fn match_term(
        source: &Term,
        target: &Term,
        symbols: &mut BTreeMap<crate::core::Symbol, crate::core::Symbol>,
        reverse_symbols: &mut BTreeMap<crate::core::Symbol, crate::core::Symbol>,
        variables: &mut BTreeMap<Variable, Variable>,
        reverse_variables: &mut BTreeMap<Variable, Variable>,
    ) -> bool {
        match (source, target) {
            (Term::Var(source), Term::Var(target)) => {
                if variables.get(source).is_some_and(|mapped| mapped != target)
                    || reverse_variables
                        .get(target)
                        .is_some_and(|mapped| mapped != source)
                {
                    return false;
                }
                variables.insert(source.clone(), target.clone());
                reverse_variables.insert(target.clone(), source.clone());
                true
            }
            (
                Term::App {
                    symbol: source_symbol,
                    args: source_args,
                },
                Term::App {
                    symbol: target_symbol,
                    args: target_args,
                },
            ) => {
                if source_args.len() != target_args.len()
                    || symbols
                        .get(source_symbol)
                        .is_some_and(|mapped| mapped != target_symbol)
                    || reverse_symbols
                        .get(target_symbol)
                        .is_some_and(|mapped| mapped != source_symbol)
                {
                    return false;
                }
                symbols.insert(source_symbol.clone(), target_symbol.clone());
                reverse_symbols.insert(target_symbol.clone(), source_symbol.clone());
                source_args.iter().zip(target_args).all(|(source, target)| {
                    match_term(
                        source,
                        target,
                        symbols,
                        reverse_symbols,
                        variables,
                        reverse_variables,
                    )
                })
            }
            _ => false,
        }
    }

    if source_rules.len() != live_rules.len() || source_pairs.len() != live_pairs.len() {
        return None;
    }
    let mut symbols = BTreeMap::new();
    let mut reverse_symbols = BTreeMap::new();
    for (source, target) in source_rules
        .iter()
        .zip(live_rules)
        .chain(source_pairs.iter().zip(live_pairs))
    {
        let mut variables = BTreeMap::new();
        let mut reverse_variables = BTreeMap::new();
        if !match_term(
            source.lhs(),
            target.lhs(),
            &mut symbols,
            &mut reverse_symbols,
            &mut variables,
            &mut reverse_variables,
        ) || !match_term(
            source.rhs(),
            target.rhs(),
            &mut symbols,
            &mut reverse_symbols,
            &mut variables,
            &mut reverse_variables,
        ) {
            return None;
        }
    }
    Some(symbols)
}

fn extend_dp_marked_symbol_isomorphism(
    mut symbols: BTreeMap<crate::core::Symbol, crate::core::Symbol>,
) -> BTreeMap<crate::core::Symbol, crate::core::Symbol> {
    for (source, target) in symbols.clone() {
        symbols.insert(
            crate::core::Symbol::new(format!("{}#", source.as_str())),
            crate::core::Symbol::new(format!("{}#", target.as_str())),
        );
    }
    symbols
}

pub(super) fn portable_rule_pair_isomorphism(
    source_rules: &[crate::core::RewriteRule],
    source_pairs: &[crate::core::RewriteRule],
    live_rules: &[crate::core::RewriteRule],
    live_pairs: &[crate::core::RewriteRule],
) -> Option<BTreeMap<crate::core::Symbol, crate::core::Symbol>> {
    if let Some(symbols) =
        ordered_rule_pair_isomorphism(source_rules, source_pairs, live_rules, live_pairs)
    {
        return Some(symbols);
    }
    let problem = |rules: &[crate::core::RewriteRule], pairs: &[crate::core::RewriteRule]| {
        StandardizationProblem::new(vec![
            StandardizationGroup::new("rules", rules.iter().map(TermPair::from_rule).collect()),
            StandardizationGroup::new("dps", pairs.iter().map(TermPair::from_rule).collect()),
        ])
    };
    let source = standardize_problem_with_bijection(&problem(source_rules, source_pairs)).ok()?;
    let live = standardize_problem_with_bijection(&problem(live_rules, live_pairs)).ok()?;
    if source.problem != live.problem {
        return None;
    }
    source
        .function_bijection
        .iter()
        .map(|(source_symbol, canonical_symbol)| {
            Some((
                source_symbol.clone(),
                live.inverse_function_bijection
                    .get(canonical_symbol)?
                    .clone(),
            ))
        })
        .collect()
}

pub(crate) fn same_rule_multiset(
    left: &[crate::core::RewriteRule],
    right: &[crate::core::RewriteRule],
) -> bool {
    if left.len() != right.len() {
        return false;
    }
    let mut unmatched = right.to_vec();
    left.iter().all(|rule| {
        let Some(index) = unmatched
            .iter()
            .position(|other| alpha_equivalent_rules(other, rule))
        else {
            return false;
        };
        unmatched.swap_remove(index);
        true
    })
}

fn alpha_unique_rules(
    rules: impl IntoIterator<Item = crate::core::RewriteRule>,
) -> Vec<crate::core::RewriteRule> {
    let mut unique = Vec::new();
    for rule in rules {
        if !unique
            .iter()
            .any(|other| alpha_equivalent_rules(other, &rule))
        {
            unique.push(rule);
        }
    }
    unique
}

pub(crate) fn rule_multiset_subset(
    subset: &[crate::core::RewriteRule],
    superset: &[crate::core::RewriteRule],
) -> bool {
    let mut unmatched = superset.to_vec();
    subset.iter().all(|rule| {
        let Some(index) = unmatched
            .iter()
            .position(|other| alpha_equivalent_rules(other, rule))
        else {
            return false;
        };
        unmatched.swap_remove(index);
        true
    })
}

pub(crate) fn alpha_equivalent_rules(
    left: &crate::core::RewriteRule,
    right: &crate::core::RewriteRule,
) -> bool {
    fn key(rule: &crate::core::RewriteRule) -> String {
        let mut variables = BTreeMap::new();
        format!(
            "{}->{}",
            crate::proving::dependency_pairs::canonical_term_variable_key(
                rule.lhs(),
                &mut variables,
            ),
            crate::proving::dependency_pairs::canonical_term_variable_key(
                rule.rhs(),
                &mut variables,
            )
        )
    }

    key(left) == key(right)
}

fn alpha_rule_variable_bijection(
    source: &RewriteRule,
    target: &RewriteRule,
) -> Option<BTreeMap<Variable, Variable>> {
    fn match_terms(
        source: &Term,
        target: &Term,
        forward: &mut BTreeMap<Variable, Variable>,
        reverse: &mut BTreeMap<Variable, Variable>,
    ) -> bool {
        match (source, target) {
            (Term::Var(source), Term::Var(target)) => {
                if forward.get(source).is_some_and(|mapped| mapped != target)
                    || reverse.get(target).is_some_and(|mapped| mapped != source)
                {
                    return false;
                }
                forward.insert(source.clone(), target.clone());
                reverse.insert(target.clone(), source.clone());
                true
            }
            (
                Term::App {
                    symbol: source_symbol,
                    args: source_args,
                },
                Term::App {
                    symbol: target_symbol,
                    args: target_args,
                },
            ) => {
                source_symbol == target_symbol
                    && source_args.len() == target_args.len()
                    && source_args
                        .iter()
                        .zip(target_args)
                        .all(|(source, target)| match_terms(source, target, forward, reverse))
            }
            _ => false,
        }
    }

    let mut forward = BTreeMap::new();
    let mut reverse = BTreeMap::new();
    (match_terms(source.lhs(), target.lhs(), &mut forward, &mut reverse)
        && match_terms(source.rhs(), target.rhs(), &mut forward, &mut reverse))
    .then_some(forward)
}

/// Rebind variables in the explicit DP and usable-rule witnesses to their
/// corresponding live rules.  The mapping is deliberately rule-local: CPF
/// fragments conventionally reuse names such as `X` in unrelated rules,
/// whereas generated transformations may give those variables distinct
/// fresh names.
fn rebind_payload_rule_variables(
    payload: &str,
    live_pairs: &[RewriteRule],
    live_rules: &[RewriteRule],
) -> Result<String, String> {
    rebind_payload_rule_variables_impl(payload, live_pairs, live_rules, true)
}

pub(crate) fn rebind_standalone_rule_variables(
    payload: &str,
    live_pairs: &[RewriteRule],
    live_rules: &[RewriteRule],
) -> Result<String, String> {
    rebind_payload_rule_variables_impl(payload, live_pairs, live_rules, false)
}

fn rebind_payload_rule_variables_impl(
    payload: &str,
    live_pairs: &[RewriteRule],
    live_rules: &[RewriteRule],
    generated_gm_convention: bool,
) -> Result<String, String> {
    fn escape_xml_text(text: &str) -> String {
        text.replace('&', "&amp;")
            .replace('<', "&lt;")
            .replace('>', "&gt;")
            .replace('"', "&quot;")
            .replace('\'', "&apos;")
    }

    const PREFIX: &str = "<ferrumCpfFragment>";
    let wrapped = format!("{PREFIX}{payload}</ferrumCpfFragment>");
    let document = roxmltree::Document::parse(&wrapped)
        .map_err(|error| format!("invalid exact reduction-pair payload: {error}"))?;
    let mut edits = Vec::<(std::ops::Range<usize>, String)>::new();

    let is_general = document.root_element().children().any(|node|
        node.is_element() && node.tag_name().name() == "condRedPairProof");
    let containers = if is_general {
        vec![("strict", live_pairs), ("bound", live_pairs)]
    } else {
        vec![("dps", live_pairs), ("usableRules", live_rules), ("trs", live_rules)]
    };
    for (container_name, live) in containers {
        let Some(container) = document
            .descendants()
            .find(|node| node.is_element() && node.tag_name().name() == container_name)
        else {
            if container_name == "dps" {
                return Err("exact reduction pair has no dps witness".to_owned());
            }
            continue;
        };
        let rule_nodes = container
            .descendants()
            .filter(|node| node.is_element() && node.tag_name().name() == "rule")
            .collect::<Vec<_>>();
        let parsed = crate::parsing::parse_cpf_rule_container_fragment(payload, container_name)
            .map_err(|error| format!("invalid exact {container_name} witness: {error}"))?
            .unwrap_or_default();
        if rule_nodes.len() != parsed.len() {
            return Err(format!(
                "exact {container_name} witness has inconsistent rule structure"
            ));
        }

        let mut used = BTreeSet::new();
        for (source, rule_node) in parsed.iter().zip(rule_nodes) {
            let Some((index, variables)) = live.iter().enumerate().find_map(|(index, target)| {
                (!used.contains(&index))
                    .then(|| alpha_rule_variable_bijection(source, target))
                    .flatten()
                    .map(|variables| (index, variables))
            }) else {
                // CeTA's mono_redpair_proc and redpair processor first split
                // the requested DPs/TRS rules against the live problem. CPF
                // producers may consequently retain requests belonging to a
                // sibling graph component. They are not orientation
                // obligations and need no live-variable rebinding. Usable
                // rules, by contrast, are an explicit closure witness and
                // must all belong to the live rule context.
                if matches!(container_name, "dps" | "trs") {
                    continue;
                }
                return Err(format!(
                    "exact {container_name} rule does not match a live rule: {source:?}"
                ));
            };
            used.insert(index);
            for variable_node in rule_node
                .descendants()
                .filter(|node| node.is_element() && node.tag_name().name() == "var")
            {
                let Some(source_name) = variable_node.text().map(str::trim) else {
                    continue;
                };
                let Some(target) = variables.get(&Variable::new(source_name)) else {
                    continue;
                };
                // The executable GM checker reconstructs generated helper
                // rules with x1, x2, ... variables. Ferrum deliberately uses
                // a reserved internal prefix to avoid collisions while
                // searching. Usable-rule membership in this CPF processor is
                // literal, so serialize those reserved variables using the
                // checker's public convention. DP membership is
                // alpha-invariant and retains the live spelling.
                let target_name = if generated_gm_convention && container_name == "usableRules" {
                    target
                        .as_str()
                        .strip_prefix("__csr_gm_x")
                        .map(|suffix| format!("x{suffix}"))
                        .unwrap_or_else(|| target.as_str().to_owned())
                } else {
                    target.as_str().to_owned()
                };
                let range = variable_node.range();
                edits.push((
                    (range.start - PREFIX.len())..(range.end - PREFIX.len()),
                    format!("<var>{}</var>", escape_xml_text(&target_name)),
                ));
            }
        }
    }

    edits.sort_by_key(|(range, _)| std::cmp::Reverse(range.start));
    let mut rebound = payload.to_owned();
    for (range, replacement) in edits {
        rebound.replace_range(range, &replacement);
    }
    Ok(rebound)
}

impl WorklistProcessor for ExactGeneralRedPairProcessor {
    fn name(&self) -> &'static str {
        "exact-general-red-pair"
    }

    fn apply(&self, state: &ProblemState) -> ProcessorResult {
        let ProblemState::DependencyPairs(problem) = state else {
            return ProcessorResult::Inapplicable;
        };
        if let Some(source) = &self.source_dp_input_xml {
            let Ok(crate::parsing::CpfInputProblem::Dp { trs, pairs, active_rules, .. }) =
                crate::parsing::parse_cpf_input(None, source) else {
                return ProcessorResult::Inapplicable;
            };
            let live_pairs = problem.pairs.iter().map(|p| p.as_rule()).collect::<Vec<_>>();
            let live_rules = problem.stats.active_rules.as_deref().unwrap_or(problem.trs.rules());
            let Some(symbols) = portable_rule_pair_isomorphism(
                active_rules.as_deref().unwrap_or(trs.rules()), &pairs, live_rules, &live_pairs,
            ) else { return ProcessorResult::Inapplicable; };
            // Re-enter the existing checked rule/variable binding path after
            // transporting the entire local witness through one bijection.
            return ExactGeneralRedPairProcessor {
                payload_xml: super::exact_transformation::translate_payload_symbols(&self.payload_xml, &symbols),
                strict_indices: self.strict_indices.clone(),
                bound_indices: self.bound_indices.clone(),
                merge: self.merge,
                source_dp_input_xml: None,
            }.apply(state);
        }
        let pair_count = problem.pairs.len();
        let valid_indices = |indices: &[usize]| {
            !indices.is_empty()
                && indices.iter().all(|index| *index < pair_count)
                && indices.iter().copied().collect::<BTreeSet<_>>().len() == indices.len()
        };

        // The indices are an efficient projection of the retained CPF
        // witness onto its source state; they are not, by themselves, a
        // portable state identity.  In particular, a later residual can have
        // the same number of pairs and accidentally accept the same numeric
        // indices.  That used to let a generalRedPairProc replay recursively
        // inside one of its own branches (thiemann34), attaching a proof for
        // the wrong conditional DP sequence.  Bind both requested sets back
        // to the live rules before exposing any successors.
        let parse_requested = |name: &str| {
            crate::parsing::parse_cpf_rule_container_fragment(&self.payload_xml, name)
                .map_err(|error| format!("invalid general reduction-pair {name}: {error}"))?
                .ok_or_else(|| format!("general reduction-pair witness has no {name} rules"))
        };
        let requested_strict = match parse_requested("strict") {
            Ok(rules) => rules,
            Err(reason) => return ProcessorResult::Failed { reason },
        };
        let requested_bound = match parse_requested("bound") {
            Ok(rules) => rules,
            Err(reason) => return ProcessorResult::Failed { reason },
        };
        let selected_rules = |indices: &[usize]| {
            indices
                .iter()
                .map(|index| problem.pairs[*index].as_rule())
                .collect::<Vec<_>>()
        };
        let relocate = |requested: &[RewriteRule], hinted: &[usize]| {
            if valid_indices(hinted) && same_rule_multiset(requested, &selected_rules(hinted)) {
                Some(hinted.to_vec())
            } else {
                locate_rule_multiset_indices(requested, &problem.pairs)
                    .map(|indices| indices.into_iter().collect())
            }
        };
        let Some(strict_indices) = relocate(&requested_strict, &self.strict_indices) else {
            return ProcessorResult::Failed {
                reason: "general reduction-pair witness does not match the live strict/bound pairs"
                    .to_owned(),
            };
        };
        let Some(bound_indices) = relocate(&requested_bound, &self.bound_indices) else {
            return ProcessorResult::Failed {
                reason: "general reduction-pair witness does not match the live strict/bound pairs"
                    .to_owned(),
            };
        };

        let strict = strict_indices.into_iter().collect::<BTreeSet<_>>();
        let bound = bound_indices.into_iter().collect::<BTreeSet<_>>();
        let deletions = if self.merge {
            vec![
                strict
                    .intersection(&bound)
                    .copied()
                    .collect::<BTreeSet<_>>(),
            ]
        } else {
            vec![strict, bound]
        };
        if deletions.iter().any(BTreeSet::is_empty) {
            return ProcessorResult::Failed {
                reason: "general reduction-pair witness deletes no pair".to_owned(),
            };
        }

        let residuals = deletions
            .into_iter()
            .map(|deleted| {
                let mut child = problem.clone();
                child.pairs = problem
                    .pairs
                    .iter()
                    .enumerate()
                    .filter(|(index, _)| !deleted.contains(index))
                    .map(|(_, pair)| pair.clone())
                    .collect();
                child.stats.weak_pairs = child
                    .pairs
                    .iter()
                    .filter(|pair| problem.stats.weak_pairs.contains(pair))
                    .cloned()
                    .collect();
                ProblemState::DependencyPairs(child)
            })
            .collect();
        // CeTA splits strict/bound requests by syntactic membership before
        // checking their conditional constraints. Relocating the indices
        // alone is insufficient when a preceding step freshened variables.
        let live_pairs = problem.pairs.iter().map(|pair| pair.as_rule()).collect::<Vec<_>>();
        let payload_xml = match rebind_payload_rule_variables(&self.payload_xml, &live_pairs,
            problem.stats.active_rules.as_deref().unwrap_or(problem.trs.rules())) {
            Ok(payload) => payload,
            Err(reason) => return ProcessorResult::Failed { reason },
        };
        ProcessorResult::Applied(ProcessorApplication::new(
            residuals,
            move |children: Vec<ProblemCertificate>| {
                let payload_xml = payload_xml.clone();
                let mut proofs = Vec::with_capacity(children.len());
                for child in children {
                    let ProblemCertificate::DependencyPairTree(tree) = child else {
                        return None;
                    };
                    proofs.push(Box::new(tree));
                }
                Some(ProblemCertificate::DependencyPairTree(
                    DpProofTree::GeneralRedPairExact {
                        payload_xml,
                        proofs,
                    },
                ))
            },
        ))
    }
}

#[cfg(test)]
mod tests {
    use std::collections::BTreeMap;

    use super::{
        ExactGeneralRedPairProcessor, ExactReductionPairProcessor, alpha_rule_variable_bijection,
        extend_dp_marked_symbol_isomorphism, locate_rule_multiset_indices,
        portable_rule_pair_isomorphism, rebind_payload_rule_variables,
        reduction_pair_payload_without_continuation, same_rule_multiset,
    };
    use crate::core::{CsrTrs, ReplacementMap, RewriteRule, Term, Trs};
    use crate::proving::dependency_pairs::{DependencyPair, DpOptions, DpProblemContext};
    use crate::proving::processors::dp::DpProblemState;
    use crate::proving::{DpProofTree, ProblemCertificate};
    use crate::proving::processors::{ProblemState, ProcessorResult, WorklistProcessor};
    use crate::standardize::translate_rule_symbols;

    fn rule(lhs: &str, rhs: &str) -> RewriteRule {
        RewriteRule::new(Term::app(lhs, vec![]), Term::app(rhs, vec![]))
    }

    #[test]
    fn exact_general_red_pair_is_bound_to_its_live_requested_pairs() {
        let state = ProblemState::DependencyPairs(DpProblemState::ordinary(
            Trs::new(None, Default::default(), vec![]),
            vec![
                DependencyPair::new_for_test(Term::app("a", vec![]), Term::app("b", vec![])),
                DependencyPair::new_for_test(Term::app("c", vec![]), Term::app("d", vec![])),
                DependencyPair::new_for_test(Term::app("e", vec![]), Term::app("f", vec![])),
            ],
            DpOptions::default(),
        ));
        let processor = ExactGeneralRedPairProcessor {
            source_dp_input_xml: None,
            payload_xml: concat!(
                "<interpretation/>",
                "<strict><rules><rule><funapp><name>e</name></funapp>",
                "<funapp><name>f</name></funapp></rule></rules></strict>",
                "<bound><rules><rule><funapp><name>c</name></funapp>",
                "<funapp><name>d</name></funapp></rule></rules></bound>",
                "<condRedPairProof/>"
            )
            .to_owned(),
            strict_indices: vec![2],
            bound_indices: vec![1],
            merge: false,
        };
        assert!(matches!(
            processor.apply(&state),
            ProcessorResult::Applied(_)
        ));

        // Deterministic transformations may enumerate the same live pair set
        // in a different order.  The explicit CPF rule sets, rather than the
        // archived numeric indices, identify the two successor problems.
        let reordered = ProblemState::DependencyPairs(DpProblemState::ordinary(
            Trs::new(None, Default::default(), vec![]),
            vec![
                DependencyPair::new_for_test(Term::app("e", vec![]), Term::app("f", vec![])),
                DependencyPair::new_for_test(Term::app("a", vec![]), Term::app("b", vec![])),
                DependencyPair::new_for_test(Term::app("c", vec![]), Term::app("d", vec![])),
            ],
            DpOptions::default(),
        ));
        assert!(matches!(
            processor.apply(&reordered),
            ProcessorResult::Applied(_)
        ));

        // A sibling residual can have the same arity and pair count.  Numeric
        // indices alone must not make the retained witness applicable there.
        let drifted = ProblemState::DependencyPairs(DpProblemState::ordinary(
            Trs::new(None, Default::default(), vec![]),
            vec![
                DependencyPair::new_for_test(Term::app("u", vec![]), Term::app("v", vec![])),
                DependencyPair::new_for_test(Term::app("w", vec![]), Term::app("x", vec![])),
                DependencyPair::new_for_test(Term::app("y", vec![]), Term::app("z", vec![])),
            ],
            DpOptions::default(),
        ));
        assert!(matches!(
            processor.apply(&drifted),
            ProcessorResult::Failed { reason }
                if reason.contains("does not match the live strict/bound pairs")
        ));
        let ProblemState::DependencyPairs(source) = &state else { panic!() };
        let source_xml = crate::proving::dependency_pairs::dp_state_input_cpf(source);
        let portable = ExactGeneralRedPairProcessor {
            source_dp_input_xml: Some(source_xml.clone()),
            ..processor
        };
        assert!(matches!(portable.apply(&drifted), ProcessorResult::Applied(_)));
        let atom = crate::proving::DpStrategyProcessor::ExactGeneralRedPair {
            payload_xml: portable.payload_xml.clone(),
            strict_indices: portable.strict_indices.clone(),
            bound_indices: portable.bound_indices.clone(),
            merge: portable.merge,
            source_dp_input_xml: Some(source_xml),
        };
        let parsed = crate::proving::DpStrategy::parse(&atom.to_strategy_atom()).unwrap();
        assert_eq!(parsed, crate::proving::DpStrategy::Processor(atom));
    }

    #[test]
    fn exact_rule_matching_preserves_multiplicity() {
        let a = rule("a", "b");
        let b = rule("b", "c");
        assert!(same_rule_multiset(&[a.clone(), b.clone()], &[b, a.clone()]));
        assert!(!same_rule_multiset(
            &[a.clone(), a.clone()],
            &[a, rule("b", "c")]
        ));
    }

    #[test]
    fn exact_rule_matching_is_alpha_invariant() {
        let left = RewriteRule::new(
            Term::app("f", vec![Term::var("X"), Term::var("Y")]),
            Term::app("g", vec![Term::var("Y"), Term::var("X")]),
        );
        let renamed = RewriteRule::new(
            Term::app("f", vec![Term::var("A"), Term::var("B")]),
            Term::app("g", vec![Term::var("B"), Term::var("A")]),
        );
        let not_alpha_equivalent = RewriteRule::new(
            Term::app("f", vec![Term::var("A"), Term::var("B")]),
            Term::app("g", vec![Term::var("A"), Term::var("B")]),
        );

        assert!(same_rule_multiset(&[left.clone()], &[renamed]));
        assert!(!same_rule_multiset(&[left], &[not_alpha_equivalent]));
    }

    #[test]
    fn portable_pair_isomorphism_maps_marked_symbols_independently() {
        let source_rules = vec![RewriteRule::new(
            Term::app("active", vec![Term::var("X")]),
            Term::app("mark", vec![Term::var("X")]),
        )];
        let source_pairs = vec![RewriteRule::new(
            Term::app("active#", vec![Term::app("u", vec![Term::var("X")])]),
            Term::app("mark#", vec![Term::var("X")]),
        )];
        let live_rules = vec![RewriteRule::new(
            Term::app("b", vec![Term::var("x")]),
            Term::app("c", vec![Term::var("x")]),
        )];
        let live_pairs = vec![RewriteRule::new(
            Term::app("aa", vec![Term::app("y", vec![Term::var("x")])]),
            Term::app("ab", vec![Term::var("x")]),
        )];

        let symbols =
            portable_rule_pair_isomorphism(&source_rules, &source_pairs, &live_rules, &live_pairs)
                .unwrap();

        assert_eq!(symbols[&crate::core::Symbol::new("active")].as_str(), "b");
        assert_eq!(symbols[&crate::core::Symbol::new("mark")].as_str(), "c");
        assert_eq!(symbols[&crate::core::Symbol::new("active#")].as_str(), "aa");
        assert_eq!(symbols[&crate::core::Symbol::new("mark#")].as_str(), "ab");
        assert_eq!(symbols[&crate::core::Symbol::new("u")].as_str(), "y");
    }

    #[test]
    fn trs_isomorphism_determines_corresponding_marked_dp_symbols() {
        let mut symbols = BTreeMap::new();
        symbols.insert(
            crate::core::Symbol::new("source"),
            crate::core::Symbol::new("live"),
        );
        let symbols = extend_dp_marked_symbol_isomorphism(symbols);
        let source_pair = RewriteRule::new(
            Term::app("source#", vec![Term::var("X")]),
            Term::app("source#", vec![Term::var("X")]),
        );
        let live_pair = RewriteRule::new(
            Term::app("live#", vec![Term::var("x")]),
            Term::app("live#", vec![Term::var("x")]),
        );

        let translated = translate_rule_symbols(&source_pair, &symbols);
        assert!(same_rule_multiset(&[translated], &[live_pair]));
    }

    #[test]
    fn exact_rule_variable_bijection_respects_repeated_variables() {
        let source = RewriteRule::new(
            Term::app("f", vec![Term::var("X"), Term::var("Y")]),
            Term::app("g", vec![Term::var("Y"), Term::var("X")]),
        );
        let target = RewriteRule::new(
            Term::app("f", vec![Term::var("u"), Term::var("v")]),
            Term::app("g", vec![Term::var("v"), Term::var("u")]),
        );
        let variables = alpha_rule_variable_bijection(&source, &target).unwrap();
        assert_eq!(
            variables
                .get(&crate::core::Variable::new("X"))
                .unwrap()
                .as_str(),
            "u"
        );
        assert_eq!(
            variables
                .get(&crate::core::Variable::new("Y"))
                .unwrap()
                .as_str(),
            "v"
        );
    }

    #[test]
    fn exact_payload_rebinds_variables_independently_per_rule() {
        let payload = concat!(
            "<dps><rules>",
            "<rule><funapp><name>f</name><var>X</var></funapp><var>X</var></rule>",
            "<rule><funapp><name>g</name><var>X</var></funapp><var>X</var></rule>",
            "</rules></dps>",
            "<usableRules><rules>",
            "<rule><funapp><name>h</name><var>X</var></funapp><var>X</var></rule>",
            "</rules></usableRules>",
            "<trs><rules>",
            "<rule><funapp><name>h</name><var>X</var></funapp><var>X</var></rule>",
            "</rules></trs>"
        );
        let live_pairs = vec![
            RewriteRule::new(Term::app("f", vec![Term::var("left")]), Term::var("left")),
            RewriteRule::new(Term::app("g", vec![Term::var("right")]), Term::var("right")),
        ];
        let live_rules = vec![RewriteRule::new(
            Term::app("h", vec![Term::var("__csr_gm_x1")]),
            Term::var("__csr_gm_x1"),
        )];
        let rebound = rebind_payload_rule_variables(payload, &live_pairs, &live_rules).unwrap();
        assert_eq!(rebound.matches("<var>left</var>").count(), 2);
        assert_eq!(rebound.matches("<var>right</var>").count(), 2);
        assert_eq!(rebound.matches("<var>x1</var>").count(), 2);
        assert_eq!(rebound.matches("<var>__csr_gm_x1</var>").count(), 2);
        assert!(!rebound.contains("<var>X</var>"));
        // Standalone input contains the live variables literally. Unlike an
        // enclosing GM transformation it does not regenerate public x1 names.
        let standalone = super::rebind_standalone_rule_variables(
            payload, &live_pairs, &live_rules,
        ).unwrap();
        assert_eq!(standalone.matches("<var>__csr_gm_x1</var>").count(), 4);
        assert!(!standalone.contains("<var>x1</var>"));
        assert_eq!(standalone.matches("<var>left</var>").count(), 2);
        assert_eq!(standalone.matches("<var>right</var>").count(), 2);
    }

    #[test]
    fn general_payload_rebinds_strict_and_bound_without_changing_constraints() {
        let payload = concat!(
            "<condRedPairProof><var>X</var></condRedPairProof>",
            "<strict><rules><rule><funapp><name>f</name><var>X</var></funapp><var>X</var></rule></rules></strict>",
            "<bound><rules><rule><funapp><name>f</name><var>X</var></funapp><var>X</var></rule></rules></bound>"
        );
        let pairs = vec![RewriteRule::new(
            Term::app("f", vec![Term::var("fresh")]), Term::var("fresh"),
        )];
        let rebound = rebind_payload_rule_variables(payload, &pairs, &[]).unwrap();
        assert_eq!(rebound.matches("<var>fresh</var>").count(), 4);
        assert!(rebound.contains("<condRedPairProof><var>X</var></condRedPairProof>"));
        assert!(rebind_payload_rule_variables(payload, &[], &[]).is_err());
    }

    #[test]
    fn exact_reduction_pair_relocates_rules_after_pair_reordering() {
        let removed = rule("a", "b");
        let pairs = vec![
            DependencyPair::new_for_test(Term::app("c", vec![]), Term::app("d", vec![])),
            DependencyPair::new_for_test(removed.lhs().clone(), removed.rhs().clone()),
        ];
        assert_eq!(
            locate_rule_multiset_indices(&[removed], &pairs),
            Some([1].into_iter().collect())
        );
    }

    #[test]
    fn exact_reduction_pair_drops_archived_continuation_only() {
        let payload = concat!(
            "<interpretation><dpProof><kept/></dpProof></interpretation>",
            "<dps><rules/></dps>",
            "<csrDpProof><pIsEmpty/></csrDpProof>"
        );
        let stripped = reduction_pair_payload_without_continuation(payload, "redPairUrProc");
        assert!(stripped.contains("<interpretation><dpProof><kept/></dpProof></interpretation>"));
        assert!(stripped.contains("<dps><rules/></dps>"));
        assert!(!stripped.contains("<csrDpProof>"));

        let wrapped = concat!(
            "<redPairUrProc><dps><rules/></dps>",
            "<ordinaryDpProof><dpProof><pIsEmpty/></dpProof></ordinaryDpProof>",
            "</redPairUrProc>"
        );
        let stripped = reduction_pair_payload_without_continuation(wrapped, "redPairUrProc");
        assert!(stripped.contains("<redPairUrProc><dps><rules/></dps>"));
        assert!(!stripped.contains("ordinaryDpProof"));
    }

    #[test]
    fn exact_reduction_pair_preserves_the_oriented_rule_context() {
        let weak_rule = rule("f", "g");
        let removed = rule("a", "b");
        let retained = rule("c", "d");
        let trs = Trs::new(None, Default::default(), vec![weak_rule.clone()]);
        let state = ProblemState::DependencyPairs(DpProblemState::ordinary(
            trs,
            vec![
                DependencyPair::new_for_test(removed.lhs().clone(), removed.rhs().clone()),
                DependencyPair::new_for_test(retained.lhs().clone(), retained.rhs().clone()),
            ],
            DpOptions::default(),
        ));
        let payload_xml = format!(
            "<redPairProc><dps><rules><rule><funapp><name>a</name></funapp><funapp><name>b</name></funapp></rule></rules></dps></redPairProc>"
        );
        let processor = ExactReductionPairProcessor {
            processor_tag: "redPairProc".to_owned(),
            payload_xml,
            removed_indices: vec![0],
            source_pairs_xml: None,
            source_rules_xml: None,
            source_weak_pairs_xml: None,
            source_strict_rules_xml: None,
        };
        let result = processor.apply(&state);
        let ProcessorResult::Applied(application) = result else {
            panic!("exact reduction-pair witness should apply: {result:?}");
        };
        let [ProblemState::DependencyPairs(child)] = application.residuals.as_slice() else {
            panic!("expected one DP residual");
        };
        assert_eq!(
            child.stats.transformation_rules.as_deref(),
            Some(&[weak_rule][..])
        );
    }

    #[test]
    fn exact_ordinary_reduction_pair_preserves_minimal_csr_continuations() {
        use crate::core::CsrTrs;
        use crate::proving::dependency_pairs::{CsrDpProblemContext, csr_dp_problem_state};

        let weak_rule = rule("f", "g");
        let removed = rule("a", "b");
        let retained = rule("c", "d");
        let trs = Trs::new(None, Default::default(), vec![weak_rule.clone()]);
        let csr = CsrTrs::full(trs);
        let pairs = vec![
            DependencyPair::new_for_test(removed.lhs().clone(), removed.rhs().clone()),
            DependencyPair::new_for_test(retained.lhs().clone(), retained.rhs().clone()),
        ];
        let problem = csr_dp_problem_state(
            &csr,
            pairs,
            CsrDpProblemContext::improved(&csr),
            DpOptions::default(),
            None,
            Vec::new(),
        )
        .expect("improved CSR-DP state");
        assert!(problem.stats.minimal);
        let state = ProblemState::DependencyPairs(problem);
        let payload_xml = concat!(
            "<redPairProc><dps><rules>",
            "<rule><funapp><name>a</name></funapp>",
            "<funapp><name>b</name></funapp></rule>",
            "</rules></dps></redPairProc>"
        );
        let source_pairs_xml = concat!(
            "<dps><rules>",
            "<rule><funapp><name>a</name></funapp><funapp><name>b</name></funapp></rule>",
            "<rule><funapp><name>c</name></funapp><funapp><name>d</name></funapp></rule>",
            "</rules></dps>"
        );
        let source_rules_xml = concat!(
            "<usableRules><rules><rule><funapp><name>f</name></funapp>",
            "<funapp><name>g</name></funapp></rule></rules></usableRules>"
        );
        let processor = ExactReductionPairProcessor {
            processor_tag: "redPairProc".to_owned(),
            payload_xml: payload_xml.to_owned(),
            removed_indices: vec![0],
            source_pairs_xml: Some(source_pairs_xml.to_owned()),
            source_rules_xml: Some(source_rules_xml.to_owned()),
            source_weak_pairs_xml: None,
            source_strict_rules_xml: None,
        };

        let ProcessorResult::Applied(application) = processor.apply(&state) else {
            panic!("context-bound exact ordinary reduction pair should apply");
        };
        let [ProblemState::DependencyPairs(child)] = application.residuals.as_slice() else {
            panic!("expected one DP residual");
        };
        assert!(matches!(
            child.stats.problem,
            super::DpProblemContext::Ordinary
        ));
        assert!(child.stats.minimal);
        assert!(!child.stats.ordinary_bridge_loses_minimality);
    }

    #[test]
    fn exact_monotone_reduction_pair_projects_sibling_removal_requests() {
        let live_rule = rule("h", "i");
        let live_pair = rule("a", "b");
        let state = ProblemState::DependencyPairs(DpProblemState::ordinary(
            Trs::new(None, Default::default(), vec![live_rule.clone()]),
            vec![DependencyPair::new_for_test(
                live_pair.lhs().clone(),
                live_pair.rhs().clone(),
            )],
            DpOptions::default(),
        ));
        let payload_xml = concat!(
            "<monoRedPairProc><interpretation/>",
            "<dps><rules>",
            "<rule><funapp><name>a</name></funapp><funapp><name>b</name></funapp></rule>",
            "<rule><funapp><name>x</name></funapp><funapp><name>y</name></funapp></rule>",
            "</rules></dps>",
            "<trs><rules>",
            "<rule><funapp><name>p</name></funapp><funapp><name>q</name></funapp></rule>",
            "</rules></trs></monoRedPairProc>"
        );
        let source_pairs_xml = concat!(
            "<dps><rules><rule><funapp><name>a</name></funapp>",
            "<funapp><name>b</name></funapp></rule></rules></dps>"
        );
        let source_rules_xml = concat!(
            "<usableRules><rules><rule><funapp><name>h</name></funapp>",
            "<funapp><name>i</name></funapp></rule></rules></usableRules>"
        );
        let processor = ExactReductionPairProcessor {
            processor_tag: "monoRedPairProc".to_owned(),
            payload_xml: payload_xml.to_owned(),
            removed_indices: vec![0],
            source_pairs_xml: Some(source_pairs_xml.to_owned()),
            source_rules_xml: Some(source_rules_xml.to_owned()),
            source_weak_pairs_xml: None,
            source_strict_rules_xml: None,
        };

        let ProcessorResult::Applied(application) = processor.apply(&state) else {
            panic!("state-bound sibling requests should be projected");
        };
        let [ProblemState::DependencyPairs(child)] = application.residuals.as_slice() else {
            panic!("expected one DP residual");
        };
        assert!(child.pairs.is_empty());
        assert_eq!(
            child
                .stats
                .active_rules
                .as_deref()
                .unwrap_or(child.trs.rules()),
            &[live_rule]
        );
    }

    #[test]
    fn exact_monotone_usable_reduction_pair_can_remove_only_rules() {
        let removed_rule = rule("f", "g");
        let retained_rule = rule("h", "i");
        let pair = DependencyPair::new_for_test(Term::app("a", vec![]), Term::app("b", vec![]));
        let state = ProblemState::DependencyPairs(DpProblemState::ordinary(
            Trs::new(
                None,
                Default::default(),
                vec![removed_rule.clone(), retained_rule.clone()],
            ),
            vec![pair],
            DpOptions::default(),
        ));
        let payload_xml = concat!(
            "<monoRedPairUrProc><interpretation/>",
            "<dps><rules/></dps>",
            "<trs><rules><rule><funapp><name>f</name></funapp>",
            "<funapp><name>g</name></funapp></rule></rules></trs>",
            "<usableRules><rules>",
            "<rule><funapp><name>f</name></funapp><funapp><name>g</name></funapp></rule>",
            "<rule><funapp><name>h</name></funapp><funapp><name>i</name></funapp></rule>",
            "</rules></usableRules></monoRedPairUrProc>"
        );
        let processor = ExactReductionPairProcessor {
            processor_tag: "monoRedPairUrProc".to_owned(),
            payload_xml: payload_xml.to_owned(),
            removed_indices: vec![],
            source_pairs_xml: None,
            source_rules_xml: None,
            source_weak_pairs_xml: None,
            source_strict_rules_xml: None,
        };

        let ProcessorResult::Applied(application) = processor.apply(&state) else {
            panic!("rule-only exact reduction pair should apply");
        };
        let [ProblemState::DependencyPairs(child)] = application.residuals.as_slice() else {
            panic!("expected one DP residual");
        };
        assert_eq!(child.pairs.len(), 1);
        assert_eq!(child.trs.rules(), &[retained_rule]);
        assert!(child.stats.active_rules.is_none());
    }

    #[test]
    fn exact_monotone_reduction_pair_discharges_generalized_strict_rules() {
        let strict_rule = rule("f", "g");
        let weak_rule = rule("h", "i");
        let pair = DependencyPair::new_for_test(Term::app("a", vec![]), Term::app("b", vec![]));
        let strict_pair =
            DependencyPair::new_for_test(Term::app("c", vec![]), Term::app("d", vec![]));
        let problem = DpProblemState::from_parts(
            Trs::new(
                None,
                Default::default(),
                vec![strict_rule.clone(), weak_rule.clone()],
            ),
            vec![pair.clone(), strict_pair],
            vec![pair],
            None,
            true,
            DpOptions::default(),
        )
        .with_strict_rules(vec![strict_rule]);
        let state = ProblemState::DependencyPairs(problem);
        let payload_xml = concat!(
            "<monoRedPairProc><interpretation/>",
            "<dps><rules/></dps>",
            "<trs><rules><rule><funapp><name>f</name></funapp>",
            "<funapp><name>g</name></funapp></rule></rules></trs>",
            "</monoRedPairProc>"
        );
        let source_pairs_xml = concat!(
            "<dps><rules><rule><funapp><name>a</name></funapp>",
            "<funapp><name>b</name></funapp></rule>",
            "<rule><funapp><name>c</name></funapp>",
            "<funapp><name>d</name></funapp></rule></rules></dps>"
        );
        let source_rules_xml = concat!(
            "<usableRules><rules>",
            "<rule><funapp><name>f</name></funapp><funapp><name>g</name></funapp></rule>",
            "<rule><funapp><name>h</name></funapp><funapp><name>i</name></funapp></rule>",
            "</rules></usableRules>"
        );
        // This archived context predates a graph projection and therefore
        // contains one additional weak pair.  Its witness still covers all
        // live weak obligations.
        let source_weak_pairs_xml = source_pairs_xml;
        let source_strict_rules_xml = concat!(
            "<usableRules><rules><rule><funapp><name>f</name></funapp>",
            "<funapp><name>g</name></funapp></rule></rules></usableRules>"
        );
        let processor = ExactReductionPairProcessor {
            processor_tag: "monoRedPairProc".to_owned(),
            payload_xml: payload_xml.to_owned(),
            removed_indices: vec![],
            source_pairs_xml: Some(source_pairs_xml.to_owned()),
            source_rules_xml: Some(source_rules_xml.to_owned()),
            source_weak_pairs_xml: Some(source_weak_pairs_xml.to_owned()),
            source_strict_rules_xml: Some(source_strict_rules_xml.to_owned()),
        };

        let ProcessorResult::Applied(application) = processor.apply(&state) else {
            panic!("strict-rule exact reduction pair should apply");
        };
        let [ProblemState::DependencyPairs(child)] = application.residuals.as_slice() else {
            panic!("expected one DP residual");
        };
        assert!(child.stats.strict_rules.is_empty());
        assert_eq!(child.trs.rules(), &[weak_rule]);
        assert!(child.stats.active_rules.is_none());

        let ordinary_state = ProblemState::DependencyPairs(DpProblemState::ordinary(
            Trs::new(
                None,
                Default::default(),
                vec![rule("f", "g"), rule("h", "i")],
            ),
            vec![DependencyPair::new_for_test(
                Term::app("a", vec![]),
                Term::app("b", vec![]),
            )],
            DpOptions::default(),
        ));
        assert!(matches!(
            processor.apply(&ordinary_state),
            ProcessorResult::Inapplicable
        ));
    }

    #[test]
    fn exact_monotone_usable_pair_discharges_nonusable_generalized_strict_rule() {
        let strict_rule = rule("f", "g");
        let usable_rule = rule("h", "i");
        let pair = DependencyPair::new_for_test(Term::app("a", vec![]), Term::app("b", vec![]));
        let problem = DpProblemState::from_parts(
            Trs::new(
                None,
                Default::default(),
                vec![strict_rule.clone(), usable_rule.clone()],
            ),
            vec![pair.clone()],
            vec![pair],
            None,
            true,
            DpOptions::default(),
        )
        .with_strict_rules(vec![strict_rule]);
        let payload_xml = concat!(
            "<monoRedPairUrProc><interpretation/>",
            "<dps><rules/></dps><trs><rules/></trs>",
            "<usableRules><rules><rule><funapp><name>h</name></funapp>",
            "<funapp><name>i</name></funapp></rule></rules></usableRules>",
            "</monoRedPairUrProc>"
        );
        let processor = ExactReductionPairProcessor {
            processor_tag: "monoRedPairUrProc".to_owned(),
            payload_xml: payload_xml.to_owned(),
            removed_indices: vec![],
            source_pairs_xml: None,
            source_rules_xml: None,
            source_weak_pairs_xml: None,
            source_strict_rules_xml: None,
        };

        let ProcessorResult::Applied(application) =
            processor.apply(&ProblemState::DependencyPairs(problem))
        else {
            panic!("non-usable strict rule should be discharged");
        };
        let [ProblemState::DependencyPairs(child)] = application.residuals.as_slice() else {
            panic!("expected one DP residual");
        };
        assert!(child.stats.strict_rules.is_empty());
        assert_eq!(child.trs.rules(), &[usable_rule]);
        assert!(child.stats.active_rules.is_none());
    }

    #[test]
    fn exact_monotone_usable_reduction_pair_can_only_restrict_to_usable_rules() {
        let non_usable_rule = rule("f", "g");
        let usable_rule = rule("h", "i");
        let state = ProblemState::DependencyPairs(DpProblemState::ordinary(
            Trs::new(
                None,
                Default::default(),
                vec![non_usable_rule, usable_rule.clone()],
            ),
            vec![DependencyPair::new_for_test(
                Term::app("a", vec![]),
                Term::app("b", vec![]),
            )],
            DpOptions::default(),
        ));
        let payload_xml = concat!(
            "<monoRedPairUrProc><interpretation/>",
            "<dps><rules/></dps><trs><rules/></trs>",
            "<usableRules><rules>",
            "<rule><funapp><name>h</name></funapp><funapp><name>i</name></funapp></rule>",
            "</rules></usableRules></monoRedPairUrProc>"
        );
        let processor = ExactReductionPairProcessor {
            processor_tag: "monoRedPairUrProc".to_owned(),
            payload_xml: payload_xml.to_owned(),
            removed_indices: vec![],
            source_pairs_xml: None,
            source_rules_xml: None,
            source_weak_pairs_xml: None,
            source_strict_rules_xml: None,
        };

        let ProcessorResult::Applied(application) = processor.apply(&state) else {
            panic!("usable-rule restriction should be a residual transformation");
        };
        let [ProblemState::DependencyPairs(child)] = application.residuals.as_slice() else {
            panic!("expected one DP residual");
        };
        assert_eq!(child.pairs.len(), 1);
        assert_eq!(child.trs.rules(), &[usable_rule]);
        assert!(child.stats.active_rules.is_none());
    }

    #[test]
    fn exact_usable_reduction_pair_binds_exact_context_and_numeric_alias() {
        let zero = Term::app("|0|", vec![]);
        let live_rule = RewriteRule::new(
            Term::app("f", vec![zero.clone()]),
            Term::app("g", vec![zero.clone()]),
        );
        let removed = DependencyPair::new_for_test(
            Term::app("p#", vec![zero.clone()]),
            Term::app("q#", vec![zero.clone()]),
        );
        let retained = DependencyPair::new_for_test(
            Term::app("q#", vec![Term::var("x")]),
            Term::app("r#", vec![Term::var("x")]),
        );
        let state = ProblemState::DependencyPairs(DpProblemState::ordinary(
            Trs::new(None, Default::default(), vec![live_rule.clone()]),
            vec![removed.clone(), retained.clone()],
            DpOptions::default(),
        ));
        let source_pairs_xml = concat!(
            "<dps><rules>",
            "<rule><funapp><sharp><name>p</name></sharp><funapp><name>0</name></funapp></funapp>",
            "<funapp><sharp><name>q</name></sharp><funapp><name>0</name></funapp></funapp></rule>",
            "<rule><funapp><sharp><name>q</name></sharp><var>X</var></funapp>",
            "<funapp><sharp><name>r</name></sharp><var>X</var></funapp></rule>",
            "</rules></dps>"
        );
        let usable_rules_xml = concat!(
            "<usableRules><rules><rule>",
            "<funapp><name>f</name><funapp><name>0</name></funapp></funapp>",
            "<funapp><name>g</name><funapp><name>0</name></funapp></funapp>",
            "</rule></rules></usableRules>"
        );
        let payload_xml = format!(
            "<redPairUrProc>{usable_rules_xml}<dps><rules>{}</rules></dps></redPairUrProc>",
            concat!(
                "<rule><funapp><sharp><name>p</name></sharp><funapp><name>0</name></funapp></funapp>",
                "<funapp><sharp><name>q</name></sharp><funapp><name>0</name></funapp></funapp></rule>"
            )
        );
        let processor = ExactReductionPairProcessor {
            processor_tag: "redPairUrProc".to_owned(),
            payload_xml,
            removed_indices: vec![0],
            source_pairs_xml: Some(source_pairs_xml.to_owned()),
            source_rules_xml: Some(usable_rules_xml.to_owned()),
            source_weak_pairs_xml: None,
            source_strict_rules_xml: None,
        };

        let result = processor.apply(&state);
        let ProcessorResult::Applied(application) = result else {
            panic!("usable-rule exact witness should apply: {result:?}");
        };
        let [ProblemState::DependencyPairs(child)] = application.residuals.as_slice() else {
            panic!("expected one DP residual");
        };
        assert_eq!(child.pairs.len(), 1);
        assert!(child.stats.active_rules.is_none());
        assert!(child.stats.graph_rules.is_none());

        let extra_state = ProblemState::DependencyPairs(DpProblemState::ordinary(
            Trs::new(
                None,
                Default::default(),
                vec![
                    live_rule,
                    RewriteRule::new(Term::app("h", vec![Term::var("x")]), Term::var("x")),
                ],
            ),
            vec![removed, retained],
            DpOptions::default(),
        ));
        assert!(matches!(
            processor.apply(&extra_state),
            ProcessorResult::Inapplicable
        ));
    }

    #[test]
    fn exact_recursive_csr_usable_reduction_pair_preserves_typed_child() {
        let weak_rule = rule("f", "g");
        let removed =
            DependencyPair::new_for_test(Term::app("p#", vec![]), Term::app("q#", vec![]));
        let retained =
            DependencyPair::new_for_test(Term::app("q#", vec![]), Term::app("r#", vec![]));
        let trs = Trs::new(None, Default::default(), vec![weak_rule.clone()]);
        let csr = CsrTrs::new(trs, ReplacementMap::new(BTreeMap::new())).unwrap();
        let state = ProblemState::DependencyPairs(
            DpProblemState::csr_materialized_from_parts(
                &csr,
                vec![removed.clone(), retained.clone()],
                vec![],
                None,
                true,
                "improved",
                "context-sensitive",
                true,
                DpOptions::default(),
            )
            .unwrap(),
        );
        let source_pairs_xml = concat!(
            "<dps><rules>",
            "<rule><funapp><sharp><name>p</name></sharp></funapp><funapp><sharp><name>q</name></sharp></funapp></rule>",
            "<rule><funapp><sharp><name>q</name></sharp></funapp><funapp><sharp><name>r</name></sharp></funapp></rule>",
            "</rules></dps>"
        );
        let source_rules_xml = concat!(
            "<usableRules><rules><rule><funapp><name>f</name></funapp>",
            "<funapp><name>g</name></funapp></rule></rules></usableRules>"
        );
        let payload_xml = concat!(
            "<interpretation/>",
            "<usableRules><rules><rule><funapp><name>f</name></funapp>",
            "<funapp><name>g</name></funapp></rule></rules></usableRules>",
            "<dps><rules><rule><funapp><sharp><name>p</name></sharp></funapp>",
            "<funapp><sharp><name>q</name></sharp></funapp></rule></rules></dps>"
        );
        let processor = ExactReductionPairProcessor {
            processor_tag: "csrRedPairUrProc".to_owned(),
            payload_xml: payload_xml.to_owned(),
            removed_indices: vec![0],
            source_pairs_xml: Some(source_pairs_xml.to_owned()),
            source_rules_xml: Some(source_rules_xml.to_owned()),
            source_weak_pairs_xml: None,
            source_strict_rules_xml: None,
        };

        // Native minimal U3 does not depend on the optional QCS search flag.
        let mut native_state = state.clone();
        if let ProblemState::DependencyPairs(problem) = &mut native_state {
            if let DpProblemContext::ContextSensitive(context) = &mut problem.stats.problem {
                context.use_qcs_usable_rules = false;
            }
        }
        assert!(matches!(processor.apply(&native_state), ProcessorResult::Applied(_)));
        let foreign_usable = ExactReductionPairProcessor {
            processor_tag: processor.processor_tag.clone(),
            payload_xml: processor.payload_xml.replace("<name>f</name>", "<name>foreign</name>"),
            removed_indices: processor.removed_indices.clone(),
            source_pairs_xml: processor.source_pairs_xml.clone(),
            source_rules_xml: processor.source_rules_xml.clone(),
            source_weak_pairs_xml: None,
            source_strict_rules_xml: None,
        };
        assert!(!matches!(foreign_usable.apply(&native_state), ProcessorResult::Applied(_)));

        let ProcessorResult::Applied(application) = processor.apply(&state) else {
            panic!("recursive CSR usable reduction pair should apply");
        };
        let [ProblemState::DependencyPairs(child)] = application.residuals.as_slice() else {
            panic!("expected one typed CSR-DP child");
        };
        assert!(matches!(
            child.stats.problem,
            DpProblemContext::ContextSensitive(_)
        ));
        let child_cpf = crate::proving::dependency_pairs::dp_state_input_cpf(child);
        assert!(child_cpf.contains("<contextSensitive>"), "{child_cpf}");
        assert!(
            child_cpf.contains("<transformationRules>"),
            "recursive CSR child lost its usable-rule transformation context: {child_cpf}"
        );
        assert_eq!(
            child.stats.transformation_rules.as_deref(),
            Some(std::slice::from_ref(&weak_rule))
        );
        assert!(!child.stats.ordinary_bridge_loses_minimality);
    }

    #[test]
    fn exact_reduction_pair_preserves_matching_duplicate_source_multiplicity() {
        let duplicate =
            DependencyPair::new_for_test(Term::app("p#", vec![]), Term::app("q#", vec![]));
        let state = ProblemState::DependencyPairs(DpProblemState::ordinary(
            Trs::new(None, Default::default(), vec![]),
            vec![duplicate.clone(), duplicate],
            DpOptions::default(),
        ));
        let pair_xml = concat!(
            "<rule><funapp><sharp><name>p</name></sharp></funapp>",
            "<funapp><sharp><name>q</name></sharp></funapp></rule>"
        );
        let source_pairs_xml = format!("<dps><rules>{pair_xml}{pair_xml}</rules></dps>");
        let processor = ExactReductionPairProcessor {
            processor_tag: "redPairProc".to_owned(),
            payload_xml: format!("<interpretation/><dps><rules>{pair_xml}</rules></dps>"),
            removed_indices: vec![0],
            source_pairs_xml: Some(source_pairs_xml),
            source_rules_xml: Some("<usableRules><rules/></usableRules>".to_owned()),
            source_weak_pairs_xml: None,
            source_strict_rules_xml: None,
        };

        let result = processor.apply(&state);
        let ProcessorResult::Applied(application) = result else {
            panic!("matching duplicate source/live contexts must remain replayable: {result:?}");
        };
        let [ProblemState::DependencyPairs(child)] = application.residuals.as_slice() else {
            panic!("expected one DP residual");
        };
        assert_eq!(child.pairs.len(), 1);
    }

    #[test]
    fn unbound_reduction_pair_emits_live_variable_names() {
        let pair = DependencyPair::new_for_test(
            Term::app("f", vec![Term::var("fresh")]), Term::var("fresh"));
        let state = ProblemState::DependencyPairs(DpProblemState::ordinary(
            Trs::new(None, Default::default(), vec![]), vec![pair], DpOptions::default()));
        let processor = ExactReductionPairProcessor {
            processor_tag: "redPairProc".to_owned(),
            payload_xml: "<interpretation/><dps><rules><rule><funapp><name>f</name><var>old</var></funapp><var>old</var></rule></rules></dps>".to_owned(),
            removed_indices: vec![0], source_pairs_xml: None, source_rules_xml: None,
            source_weak_pairs_xml: None, source_strict_rules_xml: None,
        };
        let ProcessorResult::Applied(application) = processor.apply(&state) else { panic!("alpha-equivalent deletion") };
        let Some(ProblemCertificate::DependencyPairTree(DpProofTree::ReductionPairExact { payload_xml, .. })) =
            application.reconstruct(vec![ProblemCertificate::DependencyPairTree(DpProofTree::Empty)])
        else { panic!("local reduction-pair certificate") };
        assert!(payload_xml.contains("<var>fresh</var>"));
        assert!(!payload_xml.contains("<var>old</var>"));
    }
}
