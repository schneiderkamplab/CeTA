use std::collections::{BTreeMap, BTreeSet};
use std::time::Instant;

use super::initial_innermost_lhss;
use crate::core::{CsrTrs, ReplacementMap, RewriteStrategy, Trs};
use crate::proving::dependency_pairs::{
    CsrDpProblemContext, DpProblemContext, DpProofTree, DpSemanticLabelingStep,
    SemanticLabelingModel, alpha_unique_pairs_with_deadline, alpha_unique_rules_with_deadline,
    collect_symbol_arities, constructor_normalization_semantic_labeling_candidate,
    constructor_projection_affine_semantic_labeling_candidates,
    direct_sat_semantic_labeling_candidate, distinguished_constant_semantic_labeling_candidates,
    conjunctive_sat_semantic_labeling_candidate,
    goal_directed_sat_semantic_labeling_candidate, semantic_label_base_symbol,
    semantic_label_pair_instances, semantic_label_rule_instances, semantic_label_terms,
    semantic_labeling_arities, semantic_labeling_context_rules,
    semantic_labeling_function_candidates, semantic_labeling_model_condition_holds,
    semlab_timed_out_or_cancelled, sparse_affine_semantic_labeling_candidates,
};
use crate::proving::runtime::CancellationScope;

use super::super::{
    ProblemCertificate, ProblemState, ProcessorApplication, ProcessorResult, WorklistProcessor,
};
use super::DpProblemState;

/// Enumerate at most `limit` semantic-labeling models independently of
/// recursive proof search.  The worklist asks only for the next alternative;
/// materializing the complete carrier-two product can otherwise consume
/// unbounded memory before the first model is tried.
#[derive(Clone)]
pub struct SemanticLabelingCandidate {
    pub model: SemanticLabelingModel,
    pub exact_polynomial: Option<Vec<(String, i64, Vec<i64>)>>,
}

pub fn semantic_labeling_candidate_models(
    problem: &DpProblemState,
    limit: usize,
    deadline: Option<Instant>,
) -> Option<Vec<SemanticLabelingCandidate>> {
    let cancellation = CancellationScope::current(deadline);
    if limit == 0
        || cancellation.is_cancelled()
        || semlab_timed_out_or_cancelled(deadline, &cancellation)
    {
        return (limit == 0).then(Vec::new);
    }
    // Generic finite-model relabeling must not repeat indefinitely.  Native
    // root labels use a distinct internal representation, so the legitimate
    // root-labeling -> finite-labeling continuation remains available.
    if problem
        .trs
        .arities()
        .keys()
        .any(|symbol| semantic_label_base_symbol(symbol).is_some())
    {
        return Some(Vec::new());
    }
    let constrained_arities = semantic_labeling_arities(&problem.trs, &problem.pairs, None);
    if constrained_arities.is_empty() {
        return Some(Vec::new());
    }
    let arities = semantic_labeling_arities(
        &problem.trs,
        &problem.pairs,
        problem.innermost_lhss.as_deref(),
    );
    let interpretations = arities
        .keys()
        .filter(|symbol| !constrained_arities.contains_key(*symbol))
        .cloned()
        .map(|symbol| {
            (
                symbol,
                crate::proving::dependency_pairs::SlArithmeticFunction::Constant(0),
            )
        })
        .collect();
    let base = SemanticLabelingModel {
        carrier_size: 2,
        arities,
        interpretations,
    };
    let symbols = constrained_arities.into_iter().collect::<Vec<_>>();
    let mut lhs_arities = BTreeMap::new();
    for rule in problem.trs.rules() {
        collect_symbol_arities(rule.lhs(), &mut lhs_arities);
    }
    for pair in &problem.pairs {
        collect_symbol_arities(pair.lhs(), &mut lhs_arities);
    }
    let lhs_symbols = lhs_arities.into_keys().collect::<BTreeSet<_>>();
    let mut candidates = Vec::new();
    let defined_symbols = problem.trs.defined_symbols();
    if let Some((model, interpretation)) = goal_directed_sat_semantic_labeling_candidate(
        &problem.trs,
        &problem.pairs,
        &symbols,
        &base,
        deadline,
        &cancellation,
    ) {
        candidates.push(SemanticLabelingCandidate {
            model,
            exact_polynomial: Some(interpretation),
        });
    }
    if let Some(model) = direct_sat_semantic_labeling_candidate(
        &problem.trs,
        &symbols,
        &defined_symbols,
        &lhs_symbols,
        &base,
        deadline,
        &cancellation,
    ) {
        candidates.push(SemanticLabelingCandidate {
            model,
            exact_polynomial: None,
        });
    }
    if let Some(model) = conjunctive_sat_semantic_labeling_candidate(
        &problem.trs, &symbols, &base, deadline, &cancellation,
    ) {
        candidates.push(SemanticLabelingCandidate { model, exact_polynomial: None });
    }
    if problem.trs.strategy() == RewriteStrategy::Full {
        candidates.extend(
            constructor_projection_affine_semantic_labeling_candidates(
                &problem.trs,
                &base,
                &symbols,
            )
            .into_iter()
            .map(|model| SemanticLabelingCandidate {
                model,
                exact_polynomial: None,
            }),
        );
    }
    candidates.extend(
        distinguished_constant_semantic_labeling_candidates(&base, &symbols)
            .into_iter()
            .map(|model| SemanticLabelingCandidate {
                model,
                exact_polynomial: None,
            }),
    );
    candidates.extend(
        sparse_affine_semantic_labeling_candidates(&base, &symbols, limit)
            .into_iter()
            .map(|model| SemanticLabelingCandidate {
                model,
                exact_polynomial: None,
            }),
    );
    candidates.extend(
        constructor_normalization_semantic_labeling_candidate(&problem.trs, &base, &symbols)
            .into_iter()
            .map(|model| SemanticLabelingCandidate {
                model,
                exact_polynomial: None,
            }),
    );
    candidates.truncate(limit);
    if candidates.len() >= limit {
        return Some(candidates);
    }

    // Preserve the previous exhaustive carrier-two fallback, but materialize
    // models iteratively so proof search remains outside the processor.
    let mut stack = vec![(0usize, base)];
    while let Some((index, model)) = stack.pop() {
        if cancellation.is_cancelled() || semlab_timed_out_or_cancelled(deadline, &cancellation) {
            return None;
        }
        if index == symbols.len() {
            candidates.push(SemanticLabelingCandidate {
                model,
                exact_polynomial: None,
            });
            if candidates.len() >= limit {
                break;
            }
            continue;
        }
        let (symbol, arity) = &symbols[index];
        let prefer_nonzero = lhs_symbols.contains(symbol)
            && !defined_symbols.contains(symbol)
            && !symbol.as_str().ends_with('#');
        let functions =
            semantic_labeling_function_candidates(*arity, model.carrier_size, prefer_nonzero);
        for function in functions.into_iter().rev() {
            let mut child = model.clone();
            child.interpretations.insert(symbol.clone(), function);
            stack.push((index + 1, child));
        }
    }
    Some(candidates)
}

pub struct ExactSemanticLabelingProcessor {
    pub model: SemanticLabelingModel,
    pub source_dp_input_xml: Option<String>,
    pub expected_child_dp_input_xml: Option<String>,
    pub deadline: Option<Instant>,
}

impl WorklistProcessor for ExactSemanticLabelingProcessor {
    fn name(&self) -> &'static str {
        "dependency-pair-semantic-labeling"
    }

    fn apply(&self, state: &ProblemState) -> ProcessorResult {
        let ProblemState::DependencyPairs(problem) = state else {
            return ProcessorResult::Inapplicable;
        };
        let mut model = self.model.clone();
        let mut relocated_source = false;
        if let Some(source) = &self.source_dp_input_xml {
            let Ok(Some(mut source_pairs)) =
                crate::parsing::parse_cpf_rule_container_fragment(source, "dps")
            else {
                return ProcessorResult::Failed {
                    reason: "exact semantic labeling has invalid source pairs".to_owned(),
                };
            };
            let mut source_rules =
                match crate::parsing::parse_cpf_rule_container_fragment(source, "usableRules") {
                    Ok(Some(rules)) => rules,
                    Ok(None) => {
                        let Ok(Some(rules)) =
                            crate::parsing::parse_cpf_rule_container_fragment(source, "trs")
                        else {
                            return ProcessorResult::Failed {
                                reason: "exact semantic labeling has invalid source rules"
                                    .to_owned(),
                            };
                        };
                        rules
                    }
                    Err(_) => {
                        return ProcessorResult::Failed {
                            reason: "exact semantic labeling has invalid source rules".to_owned(),
                        };
                    }
                };
            let live_pairs = problem
                .pairs
                .iter()
                .map(|pair| pair.as_rule())
                .collect::<Vec<_>>();
            let mut source_weak_pairs =
                match crate::parsing::parse_cpf_rule_container_fragment(source, "ferrumWeakDps") {
                    Ok(Some(rules)) => rules,
                    Ok(None) => Vec::new(),
                    Err(_) => {
                        return ProcessorResult::Failed {
                            reason: "exact semantic labeling has invalid source weak pairs"
                                .to_owned(),
                        };
                    }
                };
            let live_weak_pairs = problem
                .pairs
                .iter()
                .filter(|pair| problem.stats.pair_is_weak(pair))
                .map(|pair| pair.as_rule())
                .collect::<Vec<_>>();
            let mut source_strict_rules =
                match crate::parsing::parse_cpf_rule_container_fragment(source, "strictRules") {
                    Ok(Some(rules)) => rules,
                    Ok(None) => Vec::new(),
                    Err(_) => {
                        return ProcessorResult::Failed {
                            reason: "exact semantic labeling has invalid source strict rules"
                                .to_owned(),
                        };
                    }
                };
            let live_rules = problem
                .stats
                .active_rules
                .as_deref()
                .unwrap_or_else(|| problem.trs.rules());
            let Some(symbols) = super::general_red_pair::portable_rule_pair_isomorphism(
                &source_rules,
                &source_pairs,
                live_rules,
                &live_pairs,
            ) else {
                return ProcessorResult::Inapplicable;
            };
            relocated_source = symbols.iter().any(|(source, live)| source != live);
            source_pairs = source_pairs
                .into_iter()
                .map(|rule| crate::standardize::translate_rule_symbols(&rule, &symbols))
                .collect();
            source_rules = source_rules
                .into_iter()
                .map(|rule| crate::standardize::translate_rule_symbols(&rule, &symbols))
                .collect();
            source_weak_pairs = source_weak_pairs
                .into_iter()
                .map(|rule| crate::standardize::translate_rule_symbols(&rule, &symbols))
                .collect();
            source_strict_rules = source_strict_rules
                .into_iter()
                .map(|rule| crate::standardize::translate_rule_symbols(&rule, &symbols))
                .collect();
            model.arities = model
                .arities
                .into_iter()
                .map(|(symbol, arity)| (symbols.get(&symbol).cloned().unwrap_or(symbol), arity))
                .collect();
            model.interpretations = model
                .interpretations
                .into_iter()
                .map(|(symbol, interpretation)| {
                    (
                        symbols.get(&symbol).cloned().unwrap_or(symbol),
                        interpretation,
                    )
                })
                .collect();
            if !super::general_red_pair::same_rule_multiset(&source_pairs, &live_pairs)
                || !super::general_red_pair::same_rule_multiset(
                    &source_weak_pairs,
                    &live_weak_pairs,
                )
                || !super::general_red_pair::same_rule_multiset(&source_rules, live_rules)
                || !super::general_red_pair::same_rule_multiset(
                    &source_strict_rules,
                    &problem.stats.strict_rules,
                )
            {
                return ProcessorResult::Inapplicable;
            }
        }
        let cancellation = CancellationScope::current(self.deadline);
        if std::env::var_os("FERRUM_WORKLIST_TRACE").is_some() {
            eprintln!(
                "exact semantic-labeling cancellation scope_cancelled={} thread_cancelled={} deadline_expired={}",
                cancellation.is_cancelled(),
                crate::proving::runtime::current_thread_cancelled(),
                self.deadline
                    .is_some_and(|deadline| Instant::now() >= deadline),
            );
        }
        if semlab_timed_out_or_cancelled(self.deadline, &cancellation) {
            return ProcessorResult::TimedOut;
        }
        // A preceding usable-rules processor changes the current R
        // obligation without replacing `problem.trs`, which remains the
        // source TRS for reconstruction and provenance.  Semantic labeling
        // is applied to that certified active R, not to rules already removed
        // by the enclosing usableRulesProc.
        let mut active_rules = problem
            .stats
            .active_rules
            .as_deref()
            .unwrap_or_else(|| problem.trs.rules())
            .to_vec();
        // Strict rules remain independent obligations even when the weak
        // active-rule subset omits them. CeTA labels their union, retaining
        // strictness in the child; omitting their images loses obligations.
        for rule in &problem.stats.strict_rules {
            if !active_rules.iter().any(|candidate|
                super::general_red_pair::alpha_equivalent_rules(candidate, rule)) {
                active_rules.push(rule.clone());
            }
        }
        if !semantic_labeling_model_condition_holds(
            &model,
            &active_rules,
            self.deadline,
            &cancellation,
        ) {
            if std::env::var_os("FERRUM_WORKLIST_TRACE").is_some()
                && !semlab_timed_out_or_cancelled(self.deadline, &cancellation)
            {
                for (index, rule) in active_rules.iter().enumerate() {
                    if !semantic_labeling_model_condition_holds(
                        &model,
                        std::slice::from_ref(rule),
                        self.deadline,
                        &cancellation,
                    ) {
                        eprintln!(
                            "exact semantic-labeling model rejects active rule {index}: {rule}"
                        );
                        break;
                    }
                }
            }
            return if semlab_timed_out_or_cancelled(self.deadline, &cancellation) {
                ProcessorResult::TimedOut
            } else {
                ProcessorResult::Inapplicable
            };
        }

        let mut labeled_pairs = Vec::new();
        let mut labeled_weak_pairs = Vec::new();
        for pair in &problem.pairs {
            let Some(instances) =
                semantic_label_pair_instances(&model, pair, self.deadline, &cancellation)
            else {
                if std::env::var_os("FERRUM_WORKLIST_TRACE").is_some() {
                    eprintln!("exact semantic-labeling could not label pair: {pair:?}");
                }
                return ProcessorResult::TimedOut;
            };
            // The finite model can give several valuations the same labels,
            // so duplicate instances of one source pair may be discarded.
            // Do not, however, alpha-deduplicate across *different* source
            // pairs.  Transformations such as forward instantiation can
            // deliberately retain alpha-equivalent pairs with distinct
            // variables/provenance, and CeTA's semantic-labeling processor
            // requires the labeled image of every such source obligation.
            // A global alpha-unique pass used to drop one of those images and
            // made the resulting complete CPF checker-rejected (z19).
            let Some(instances) =
                alpha_unique_pairs_with_deadline(instances, self.deadline, &cancellation)
            else {
                return ProcessorResult::TimedOut;
            };
            if problem.stats.pair_is_weak(pair) {
                labeled_weak_pairs.extend(instances.iter().cloned());
            }
            labeled_pairs.extend(instances);
        }
        let mut labeled_pairs = labeled_pairs;
        if labeled_pairs == problem.pairs || labeled_pairs.is_empty() {
            return ProcessorResult::Inapplicable;
        }

        let mut labeled_rules = Vec::new();
        let active_trs = Trs::new_with_strategy(
            problem.trs.name().map(str::to_string),
            problem.trs.variables().clone(),
            active_rules.to_vec(),
            problem.trs.strategy(),
        );
        for rule in semantic_labeling_context_rules(
            &active_trs,
            &problem.pairs,
            problem.innermost_lhss.as_deref(),
        ) {
            let Some(mut instances) =
                semantic_label_rule_instances(&model, &rule, self.deadline, &cancellation)
            else {
                if std::env::var_os("FERRUM_WORKLIST_TRACE").is_some() {
                    eprintln!("exact semantic-labeling could not label active rule: {rule}");
                }
                return ProcessorResult::TimedOut;
            };
            labeled_rules.append(&mut instances);
        }
        let semantic_lhss = problem
            .innermost_lhss
            .clone()
            .or_else(|| initial_innermost_lhss(&problem.trs));
        let labeled_innermost_lhss = match semantic_lhss.as_deref() {
            Some(lhss) => {
                let Some(labeled) =
                    semantic_label_terms(&model, lhss, self.deadline, &cancellation)
                else {
                    if std::env::var_os("FERRUM_WORKLIST_TRACE").is_some() {
                        eprintln!("exact semantic-labeling could not label innermost LHS context");
                    }
                    return ProcessorResult::TimedOut;
                };
                labeled
            }
            None => Vec::new(),
        };
        let Some(labeled_rules) =
            alpha_unique_rules_with_deadline(labeled_rules, self.deadline, &cancellation)
        else {
            return ProcessorResult::TimedOut;
        };
        let mut labeled_strict_rules = Vec::new();
        for rule in &problem.stats.strict_rules {
            let Some(mut instances) =
                semantic_label_rule_instances(&model, rule, self.deadline, &cancellation)
            else {
                return ProcessorResult::TimedOut;
            };
            labeled_strict_rules.append(&mut instances);
        }
        let Some(labeled_strict_rules) =
            alpha_unique_rules_with_deadline(labeled_strict_rules, self.deadline, &cancellation)
        else {
            return ProcessorResult::TimedOut;
        };
        if !relocated_source && let Some(expected_child) = &self.expected_child_dp_input_xml {
            let Ok(Some(expected_pairs)) =
                crate::parsing::parse_cpf_rule_container_fragment(expected_child, "dps")
            else {
                return ProcessorResult::Failed {
                    reason: "exact semantic labeling has invalid expected child pairs".to_owned(),
                };
            };
            let Ok(Some(expected_rules)) =
                crate::parsing::parse_cpf_rule_container_fragment(expected_child, "trs")
            else {
                return ProcessorResult::Failed {
                    reason: "exact semantic labeling has invalid expected child rules".to_owned(),
                };
            };
            let generated_pair_rules = labeled_pairs
                .iter()
                .map(|pair| pair.as_rule())
                .collect::<Vec<_>>();
            if !super::general_red_pair::same_rule_multiset(&expected_pairs, &generated_pair_rules)
                || !super::general_red_pair::same_rule_multiset(&expected_rules, &labeled_rules)
            {
                return ProcessorResult::Inapplicable;
            }
            let expected_strict_rules =
                crate::parsing::parse_cpf_rule_container_fragment(expected_child, "strictRules")
                    .ok()
                    .flatten()
                    .unwrap_or_default();
            if !super::general_red_pair::same_rule_multiset(
                &expected_strict_rules,
                &labeled_strict_rules,
            ) {
                return ProcessorResult::Inapplicable;
            }
            // Semantic labeling is a complete transformation: accepting an
            // archived proper subset here can omit a labeled rule that CeTA
            // recomputes from the source problem.  Equality also ensures the
            // runtime child and the detached certified CPF child coincide.

            // Preserve the certified pair order and live provenance by
            // relocating every archived pair in the independently generated
            // multiset rather than constructing context-free new pairs.
            let mut used = BTreeSet::new();
            let mut ordered_pairs = Vec::with_capacity(expected_pairs.len());
            for expected in &expected_pairs {
                let Some((index, pair)) = labeled_pairs.iter().enumerate().find(|(index, pair)| {
                    !used.contains(index)
                        && super::general_red_pair::alpha_equivalent_rules(
                            expected,
                            &pair.as_rule(),
                        )
                }) else {
                    return ProcessorResult::Inapplicable;
                };
                used.insert(index);
                ordered_pairs.push(pair.clone());
            }
            labeled_pairs = ordered_pairs;
        }
        let labeled_trs = Trs::new_with_strategy(
            problem.trs.name().map(str::to_string),
            problem.trs.variables().clone(),
            labeled_rules,
            problem.trs.strategy(),
        );
        let step = DpSemanticLabelingStep {
            model,
            root_labeling: false,
            labeled_pairs: labeled_pairs.clone(),
            labeled_rules: labeled_trs.rules().to_vec(),
            labeled_innermost_lhss: labeled_innermost_lhss.clone(),
        };
        let mut residual = problem.clone();
        residual.trs = labeled_trs;
        residual.pairs = labeled_pairs;
        residual.stats.active_rules = Some(residual.trs.rules().to_vec());
        residual.stats.graph_rules = Some(residual.trs.rules().to_vec());
        residual.stats.transformation_rules = None;
        residual.stats.weak_pairs = labeled_weak_pairs;
        residual.stats.strict_rules = labeled_strict_rules;
        // Ordinary CPF semantic labeling preserves the minimality flag; this
        // is part of the target DPP constructed by CeTA's `sem_lab_proc`.
        // Only the CSR extension below deliberately bridges to an ordinary,
        // nonminimal DP obligation.  Clearing the flag unconditionally used
        // to disable otherwise valid SCT/subterm continuations after ordinary
        // semantic labeling (notably the final `z19` residual).
        if matches!(problem.stats.problem, DpProblemContext::ContextSensitive(_)) {
            residual.stats.minimal = false;
        }
        residual.innermost_lhss =
            (!labeled_innermost_lhss.is_empty()).then_some(labeled_innermost_lhss);
        if let DpProblemContext::ContextSensitive(context) = &problem.stats.problem {
            let labeled_map = ReplacementMap::new(
                residual
                    .trs
                    .arities()
                    .keys()
                    .filter_map(|symbol| {
                        let base = semantic_label_base_symbol(symbol)?;
                        let positions = context.csr.replacement_map().allowed_positions(&base)?;
                        Some((symbol.clone(), positions.clone()))
                    })
                    .collect(),
            );
            let labeled_csr = match CsrTrs::new(residual.trs.clone(), labeled_map) {
                Ok(csr) => csr,
                Err(issues) => {
                    return ProcessorResult::Failed {
                        reason: format!("invalid labeled CSR replacement map: {issues:?}"),
                    };
                }
            };
            residual.stats.semantic_csr_context = Some(CsrDpProblemContext {
                csr: labeled_csr,
                construction: context.construction,
                graph_estimator: context.graph_estimator,
                use_qcs_usable_rules: context.use_qcs_usable_rules,
                innermost_q_lhss: residual.innermost_lhss.clone(),
            });
            residual.stats.problem = DpProblemContext::Ordinary;
        }

        ProcessorResult::Applied(ProcessorApplication::new(
            vec![ProblemState::DependencyPairs(residual)],
            move |children| {
                let [ProblemCertificate::DependencyPairTree(proof)] =
                    <[ProblemCertificate; 1]>::try_from(children).ok()?
                else {
                    return None;
                };
                Some(ProblemCertificate::DependencyPairTree(
                    DpProofTree::SemanticLabeling {
                        step: Box::new(step.clone()),
                        proof: Box::new(proof),
                    },
                ))
            },
        ))
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::core::{RewriteRule, Symbol, Term, Variable};
    use crate::proving::{DependencyPair, DpOptions, SlArithmeticFunction};

    #[test]
    fn ordinary_semantic_labeling_preserves_minimality() {
        let variables = BTreeSet::from([Variable::new("x")]);
        let rule = RewriteRule::new(
            Term::app("f", vec![Term::var("x")]),
            Term::app("f", vec![Term::app("a", vec![])]),
        );
        let trs = Trs::new(None, variables, vec![rule]);
        let pair = DependencyPair::from_rule(
            RewriteRule::new(
                Term::app("f#", vec![Term::var("x")]),
                Term::app("f#", vec![Term::app("a", vec![])]),
            ),
            0,
        );
        let mut state = DpProblemState::ordinary(trs, vec![pair], DpOptions::default());
        assert!(state.stats.minimal);
        let model = SemanticLabelingModel {
            carrier_size: 2,
            arities: BTreeMap::from([
                (Symbol::new("a"), 0),
                (Symbol::new("f"), 1),
                (Symbol::new("f#"), 1),
            ]),
            interpretations: BTreeMap::from([
                (Symbol::new("a"), SlArithmeticFunction::Constant(0)),
                (Symbol::new("f"), SlArithmeticFunction::Constant(0)),
                (Symbol::new("f#"), SlArithmeticFunction::Constant(0)),
            ]),
        };
        let processor = ExactSemanticLabelingProcessor {
            model,
            source_dp_input_xml: None,
            expected_child_dp_input_xml: None,
            deadline: None,
        };

        let ProcessorResult::Applied(application) =
            processor.apply(&ProblemState::DependencyPairs(state.clone()))
        else {
            panic!("semantic labeling should apply");
        };
        let [ProblemState::DependencyPairs(residual)] = application.residuals.as_slice() else {
            panic!("semantic labeling should produce one DP residual");
        };
        assert!(residual.stats.minimal);
        // A weak-rule restriction may not erase a separate strict-rule
        // obligation from the semantic model or its labeled TRS.
        state.stats.strict_rules = state.trs.rules().to_vec();
        state.stats.active_rules = Some(Vec::new());
        let ProcessorResult::Applied(application) = processor.apply(&ProblemState::DependencyPairs(state)) else {
            panic!("strict rules must still be labeled with empty active weak rules");
        };
        let [ProblemState::DependencyPairs(child)] = application.residuals.as_slice() else { panic!() };
        assert!(!child.stats.strict_rules.is_empty());
        assert!(child.stats.strict_rules.iter().all(|rule| child.trs.rules().contains(rule)));
    }

    #[test]
    fn semantic_labeling_preserves_distinct_alpha_equivalent_source_pairs() {
        let variables = BTreeSet::from([Variable::new("x"), Variable::new("y")]);
        let trs = Trs::new(None, variables, Vec::new());
        let pairs = ["x", "y"]
            .into_iter()
            .map(|variable| {
                DependencyPair::from_rule(
                    RewriteRule::new(
                        Term::app("f#", vec![Term::var(variable)]),
                        Term::app("f#", vec![Term::var(variable)]),
                    ),
                    0,
                )
            })
            .collect();
        let state = DpProblemState::ordinary(trs, pairs, DpOptions::default());
        let processor = ExactSemanticLabelingProcessor {
            model: SemanticLabelingModel {
                carrier_size: 2,
                arities: BTreeMap::from([(Symbol::new("f#"), 1)]),
                interpretations: BTreeMap::from([(
                    Symbol::new("f#"),
                    SlArithmeticFunction::Constant(0),
                )]),
            },
            source_dp_input_xml: None,
            expected_child_dp_input_xml: None,
            deadline: None,
        };

        let ProcessorResult::Applied(application) =
            processor.apply(&ProblemState::DependencyPairs(state))
        else {
            panic!("semantic labeling should apply");
        };
        let [ProblemState::DependencyPairs(residual)] = application.residuals.as_slice() else {
            panic!("semantic labeling should produce one DP residual");
        };
        assert_eq!(residual.pairs.len(), 4);
        assert_ne!(residual.pairs[0].lhs(), residual.pairs[1].lhs());
        assert_ne!(residual.pairs[0].lhs(), residual.pairs[2].lhs());
    }
}
