use crate::parsing::{CpfInputProblem, parse_cpf_input};
use crate::proving::dependency_pairs::{
    DependencyPair, DpProofTree, dependency_pair_rules_alpha_equivalent,
};
use crate::standardize::translate_rule_symbols;

use super::super::{
    ProblemCertificate, ProblemState, ProcessorApplication, ProcessorResult, WorklistProcessor,
};

/// One concrete CPF dependency-pair split.
///
/// The scheduler enumerates `selected_strong_index` when the strategy atom is
/// `split`; the processor itself is deterministic and exposes both resulting
/// obligations to the common worklist.
pub struct SplitProcessor {
    pub selected_strong_index: usize,
}

pub struct RuleSplitProcessor {
    pub selected_rule_index: usize,
}

pub struct ExactSplitProcessor {
    pub selected_pair_index: Option<usize>,
    pub selected_rule_index: Option<usize>,
    pub source_dp_input_xml: String,
}

impl WorklistProcessor for ExactSplitProcessor {
    fn name(&self) -> &'static str {
        "exact-dependency-pair-split"
    }

    fn apply(&self, state: &ProblemState) -> ProcessorResult {
        let ProblemState::DependencyPairs(problem) = state else {
            return ProcessorResult::Inapplicable;
        };
        let Ok(source) = parse_cpf_input(None, &self.source_dp_input_xml) else {
            return ProcessorResult::Failed {
                reason: "invalid exact split source".to_owned(),
            };
        };
        let (source_trs, source_pairs, source_active_rules) = match source {
            CpfInputProblem::Dp {
                trs,
                pairs,
                active_rules,
                ..
            } => (trs, pairs, active_rules),
            CpfInputProblem::CsrDp {
                csr,
                pairs,
                active_rules,
                ..
            } => (csr.trs().clone(), pairs, active_rules),
            _ => return ProcessorResult::Inapplicable,
        };
        let live_rules = problem
            .stats
            .active_rules
            .as_deref()
            .unwrap_or(problem.trs.rules());
        let source_rules = source_active_rules.as_deref().unwrap_or(source_trs.rules());
        if source_trs.strategy() != problem.trs.strategy() {
            return ProcessorResult::Failed {
                reason: "exact split source changes the live TRS".to_owned(),
            };
        }
        let live_pair_rules = problem
            .pairs
            .iter()
            .map(DependencyPair::as_rule)
            .collect::<Vec<_>>();
        // The active TRS can have nontrivial signature automorphisms.  A
        // TRS-only bijection may consequently exchange two rule roles even
        // though the dependency pairs distinguish them, causing a retained
        // split to select the wrong live rule.  Exact split portability is a
        // property of the complete DP state, so constrain the bijection by R
        // and P together (including marked symbols) just like exact graph and
        // exact reduction-pair replay.
        let Some(symbols) = super::general_red_pair::portable_rule_pair_isomorphism(
            source_rules,
            &source_pairs,
            live_rules,
            &live_pair_rules,
        ) else {
            return ProcessorResult::Failed {
                reason: "exact split source changes the live DP state".to_owned(),
            };
        };
        if self.selected_pair_index.is_some() == self.selected_rule_index.is_some() {
            return ProcessorResult::Failed {
                reason: "exact split must select exactly one pair or rule".to_owned(),
            };
        }
        if source_pairs.len() != problem.pairs.len() {
            return ProcessorResult::Inapplicable;
        }
        // Match the complete pair multiset, consuming equal occurrences in
        // order.  CPF can split one of several alpha-equivalent occurrences;
        // requiring the selected rule alone to be unique rejects that valid
        // case, while a complete bijection preserves its occurrence identity.
        let mut unused = (0..problem.pairs.len()).collect::<Vec<_>>();
        let mut source_to_live = Vec::with_capacity(source_pairs.len());
        for source in source_pairs {
            let source = translate_rule_symbols(&source, &symbols);
            let source = DependencyPair::new(source.lhs().clone(), source.rhs().clone(), 0);
            let Some(position) = unused.iter().position(|index| {
                dependency_pair_rules_alpha_equivalent(&problem.pairs[*index], &source)
            }) else {
                return ProcessorResult::Inapplicable;
            };
            source_to_live.push(unused.remove(position));
        }
        if let Some(source_index) = self.selected_pair_index {
            if source_index >= source_to_live.len() {
                return ProcessorResult::Failed {
                    reason: "exact split pair index is out of range".to_owned(),
                };
            }
            let selected_strong_index = source_to_live[source_index];
            if problem
                .stats
                .weak_pairs
                .contains(&problem.pairs[selected_strong_index])
            {
                return ProcessorResult::Inapplicable;
            }
            return SplitProcessor {
                selected_strong_index,
            }
            .apply(state);
        }

        let source_index = self
            .selected_rule_index
            .expect("exclusive split selector checked");
        if source_index >= source_trs.rules().len() {
            return ProcessorResult::Failed {
                reason: "exact split rule index is out of range".to_owned(),
            };
        }
        let source_rule = translate_rule_symbols(&source_trs.rules()[source_index], &symbols);
        let Some(selected_rule) = live_rules
            .iter()
            .find(|rule| super::general_red_pair::alpha_equivalent_rules(rule, &source_rule))
            .cloned()
        else {
            return ProcessorResult::Inapplicable;
        };

        let selected_rule_index = live_rules.iter().position(|rule| rule == &selected_rule)
            .expect("selected live rule was just found");
        RuleSplitProcessor { selected_rule_index }.apply(state)
    }
}

impl WorklistProcessor for RuleSplitProcessor {
    fn name(&self) -> &'static str {
        "dependency-rule-split"
    }

    fn apply(&self, state: &ProblemState) -> ProcessorResult {
        let ProblemState::DependencyPairs(problem) = state else {
            return ProcessorResult::Inapplicable;
        };
        let live_rules = problem.stats.active_rules.as_deref().unwrap_or(problem.trs.rules());
        let Some(selected_rule) = live_rules.get(self.selected_rule_index).cloned() else {
            return ProcessorResult::Inapplicable;
        };
        // Do not return the parent itself as the selected obligation.
        if problem.pairs.iter().all(|p| problem.stats.weak_pairs.contains(p))
            && problem.stats.strict_rules == [selected_rule.clone()] {
            return ProcessorResult::Inapplicable;
        }
        let mut selected = problem.clone();
        selected.stats.weak_pairs = selected.pairs.clone();
        selected.stats.strict_rules = vec![selected_rule.clone()];
        let mut residual = problem.clone();
        residual
            .stats
            .strict_rules
            .retain(|rule| !super::general_red_pair::alpha_equivalent_rules(rule, &selected_rule));
        // A rule split proves the selected rule in the first generalized
        // obligation and removes that occurrence from the complementary
        // problem.  Leaving active R unchanged made the second child
        // identical to its parent, so state-only oracle lookup selected the
        // same split forever and semantic labeling generated one extra rule
        // compared with CeTA's certified residual.
        let mut residual_rules = live_rules.to_vec();
        let Some(position) = residual_rules
            .iter()
            .position(|rule| super::general_red_pair::alpha_equivalent_rules(rule, &selected_rule))
        else {
            return ProcessorResult::Inapplicable;
        };
        residual_rules.remove(position);
        residual.trs = crate::core::Trs::new_with_strategy(
            residual.trs.name().map(str::to_owned),
            residual.trs.variables().clone(),
            residual_rules.clone(),
            residual.trs.strategy(),
        );
        // This is the complementary R component certified by splitProc, not
        // a search-local usable-rule hint.  Materialize it in the TRS so all
        // recursive processors (including uncurrying) consume exactly the
        // same obligation that CPF reconstruction presents to CeTA.
        residual.stats.active_rules = None;
        residual.stats.active_rules_are_residual = false;
        residual.stats.graph_rules = None;
        residual.stats.transformation_rules = Some(residual_rules);
        ProcessorResult::Applied(ProcessorApplication::new(
            vec![
                ProblemState::DependencyPairs(selected),
                ProblemState::DependencyPairs(residual),
            ],
            move |children| {
                let [
                    ProblemCertificate::DependencyPairTree(selected_proof),
                    ProblemCertificate::DependencyPairTree(residual_proof),
                ] = <[ProblemCertificate; 2]>::try_from(children).ok()?
                else {
                    return None;
                };
                Some(ProblemCertificate::DependencyPairTree(DpProofTree::Split {
                    selected_pairs: Vec::new(),
                    selected_rules: vec![selected_rule.clone()],
                    selected_proof: Box::new(selected_proof),
                    residual_proof: Box::new(residual_proof),
                }))
            },
        ))
    }
}

impl WorklistProcessor for SplitProcessor {
    fn name(&self) -> &'static str {
        "dependency-pair-split"
    }

    fn apply(&self, state: &ProblemState) -> ProcessorResult {
        let ProblemState::DependencyPairs(problem) = state else {
            return ProcessorResult::Inapplicable;
        };
        let strong_indices = problem
            .pairs
            .iter()
            .enumerate()
            .filter_map(|(index, pair)| (!problem.stats.weak_pairs.contains(pair)).then_some(index))
            .collect::<Vec<_>>();
        if strong_indices.len() < 2 || !strong_indices.contains(&self.selected_strong_index) {
            return ProcessorResult::Inapplicable;
        }

        let selected_pairs = vec![problem.pairs[self.selected_strong_index].clone()];
        let residual_pairs = problem
            .pairs
            .iter()
            .enumerate()
            .filter_map(|(index, pair)| {
                (index != self.selected_strong_index).then_some(pair.clone())
            })
            .collect::<Vec<_>>();

        let mut selected = problem.clone();
        selected
            .stats
            .weak_pairs
            .extend(
                problem
                    .pairs
                    .iter()
                    .enumerate()
                    .filter_map(|(index, pair)| {
                        (index != self.selected_strong_index
                            && !problem.stats.weak_pairs.contains(pair))
                        .then_some(pair.clone())
                    }),
            );
        // This branch selects only a dependency pair.  Any parent strict
        // ordinary rules belong to the complementary branch and are weak in
        // the selected obligation.
        selected.stats.strict_rules.clear();

        let mut residual = problem.clone();
        residual.pairs = residual_pairs;
        residual
            .stats
            .weak_pairs
            .retain(|pair| residual.pairs.contains(pair));

        ProcessorResult::Applied(ProcessorApplication::new(
            vec![
                ProblemState::DependencyPairs(selected),
                ProblemState::DependencyPairs(residual),
            ],
            move |children| {
                let [
                    ProblemCertificate::DependencyPairTree(selected_proof),
                    ProblemCertificate::DependencyPairTree(residual_proof),
                ] = <[ProblemCertificate; 2]>::try_from(children).ok()?
                else {
                    return None;
                };
                Some(ProblemCertificate::DependencyPairTree(DpProofTree::Split {
                    selected_pairs: selected_pairs.clone(),
                    selected_rules: Vec::new(),
                    selected_proof: Box::new(selected_proof),
                    residual_proof: Box::new(residual_proof),
                }))
            },
        ))
    }
}

#[cfg(test)]
mod tests {
    use crate::core::{RewriteRule, Term, Trs};
    use crate::proving::dependency_pairs::{DependencyPair, DpOptions};
    use crate::proving::processors::dp::DpProblemState;

    use super::*;

    #[test]
    fn native_rule_split_is_available_after_pair_candidates() {
        let selected_rule = RewriteRule::new(Term::app("f", vec![Term::var("x")]), Term::var("x"));
        let retained_rule = RewriteRule::new(Term::app("g", vec![Term::var("x")]), Term::var("x"));
        let pair = DependencyPair::new_for_test(Term::app("p", vec![Term::var("x")]), Term::var("x"));
        let problem = DpProblemState::ordinary(
            Trs::new(None, Default::default(), vec![selected_rule.clone(), retained_rule.clone()]),
            vec![pair], DpOptions::default());
        let state = ProblemState::DependencyPairs(problem);
        let atom = crate::proving::dependency_pairs::DpStrategyProcessor::SelectedSplit { candidate_index: 1 };
        let processor = super::super::ConfiguredDpProcessor { processor: &atom, deadline: None };
        let ProcessorResult::Applied(application) = processor.apply(&state) else {
            panic!("native rule alternative should apply");
        };
        let [ProblemState::DependencyPairs(selected), ProblemState::DependencyPairs(residual)] = application.residuals.as_slice() else {
            panic!("split must retain both obligations");
        };
        assert_eq!(selected.stats.strict_rules, vec![selected_rule]);
        assert_eq!(selected.stats.weak_pairs, selected.pairs);
        assert_eq!(residual.trs.rules(), &[retained_rule]);
        assert!(residual.stats.active_rules.is_none());
        assert!(matches!(RuleSplitProcessor { selected_rule_index: 2 }.apply(&state), ProcessorResult::Inapplicable));
        assert!(matches!(RuleSplitProcessor { selected_rule_index: 0 }.apply(&application.residuals[0]), ProcessorResult::Inapplicable));
    }

    #[test]
    fn exact_rule_split_removes_selected_rule_from_complementary_active_system() {
        let selected_rule = RewriteRule::new(
            Term::app("f", vec![Term::var("x")]),
            Term::app("g", vec![Term::var("x")]),
        );
        let retained_rule = RewriteRule::new(
            Term::app("h", vec![Term::var("x")]),
            Term::app("i", vec![Term::var("x")]),
        );
        let pair = DependencyPair::new_for_test(
            Term::app("p#", vec![Term::var("x")]),
            Term::app("q#", vec![Term::var("x")]),
        );
        let problem = DpProblemState::ordinary(
            Trs::new(
                None,
                Default::default(),
                vec![selected_rule.clone(), retained_rule.clone()],
            ),
            vec![pair],
            DpOptions::default(),
        );
        let source = concat!(
            "<dpInput><trs><rules>",
            "<rule><funapp><name>f</name><var>X</var></funapp><funapp><name>g</name><var>X</var></funapp></rule>",
            "<rule><funapp><name>h</name><var>X</var></funapp><funapp><name>i</name><var>X</var></funapp></rule>",
            "</rules></trs><dps><rules><rule>",
            "<funapp><sharp><name>p</name></sharp><var>X</var></funapp>",
            "<funapp><sharp><name>q</name></sharp><var>X</var></funapp>",
            "</rule></rules></dps><minimal>true</minimal></dpInput>"
        );
        let processor = ExactSplitProcessor {
            selected_pair_index: None,
            selected_rule_index: Some(0),
            source_dp_input_xml: source.to_owned(),
        };

        let ProcessorResult::Applied(application) =
            processor.apply(&ProblemState::DependencyPairs(problem))
        else {
            panic!("exact rule split should apply");
        };
        let [
            ProblemState::DependencyPairs(selected),
            ProblemState::DependencyPairs(residual),
        ] = application.residuals.as_slice()
        else {
            panic!("expected selected and complementary DP obligations");
        };
        assert_eq!(selected.stats.strict_rules, vec![selected_rule]);
        assert_eq!(residual.trs.rules(), &[retained_rule]);
        assert!(residual.stats.active_rules.is_none());
    }

    #[test]
    fn exact_rule_split_uses_pairs_to_disambiguate_symmetric_rule_roles() {
        let selected_rule = RewriteRule::new(
            Term::app("z", vec![Term::var("x")]),
            Term::app("y", vec![Term::var("x")]),
        );
        let retained_rule = RewriteRule::new(
            Term::app("a", vec![Term::var("x")]),
            Term::app("b", vec![Term::var("x")]),
        );
        let pair = DependencyPair::new_for_test(
            Term::app("z#", vec![Term::app("z", vec![Term::var("x")])]),
            Term::app("y#", vec![Term::app("y", vec![Term::var("x")])]),
        );
        let problem = DpProblemState::ordinary(
            Trs::new(
                None,
                Default::default(),
                vec![selected_rule.clone(), retained_rule],
            ),
            vec![pair],
            DpOptions::default(),
        );
        let source = concat!(
            "<dpInput><trs><rules>",
            "<rule><funapp><name>f</name><var>X</var></funapp><funapp><name>g</name><var>X</var></funapp></rule>",
            "<rule><funapp><name>h</name><var>X</var></funapp><funapp><name>i</name><var>X</var></funapp></rule>",
            "</rules></trs><dps><rules><rule>",
            "<funapp><sharp><name>f</name></sharp><funapp><name>f</name><var>X</var></funapp></funapp>",
            "<funapp><sharp><name>g</name></sharp><funapp><name>g</name><var>X</var></funapp></funapp>",
            "</rule></rules></dps><minimal>true</minimal></dpInput>"
        );
        let processor = ExactSplitProcessor {
            selected_pair_index: None,
            selected_rule_index: Some(0),
            source_dp_input_xml: source.to_owned(),
        };

        let ProcessorResult::Applied(application) =
            processor.apply(&ProblemState::DependencyPairs(problem))
        else {
            panic!("pair-constrained exact rule split should apply");
        };
        let [ProblemState::DependencyPairs(selected), _] = application.residuals.as_slice() else {
            panic!("expected selected and complementary DP obligations");
        };
        assert_eq!(selected.stats.strict_rules, vec![selected_rule]);
    }
}
