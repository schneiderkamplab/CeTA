use std::collections::BTreeMap;

use crate::core::{RewriteRule, RewriteStrategy, Term, Trs};
#[cfg(test)]
use crate::proving::dependency_pairs::usable_rules_in_innermost_context;
use crate::proving::dependency_pairs::{DependencyPair, collect_symbol_arities, term_is_q_normal};

/// Initial Q left-hand sides for an innermost dependency-pair problem.
pub(crate) fn initial_innermost_lhss(trs: &Trs) -> Option<Vec<Term>> {
    (trs.strategy() == RewriteStrategy::Innermost)
        .then(|| trs.rules().iter().map(|rule| rule.lhs().clone()).collect())
}

/// Restrict Q to the left-hand sides that can still occur in the active
/// residual signature while preserving Q-normal argument obligations.
pub(crate) fn remaining_innermost_lhss(
    q_lhss: &[Term],
    active_rules: &[RewriteRule],
    pairs: &[DependencyPair],
) -> Vec<Term> {
    let mut occurring_symbols = BTreeMap::new();
    for pair in pairs {
        collect_symbol_arities(pair.lhs(), &mut occurring_symbols);
        collect_symbol_arities(pair.rhs(), &mut occurring_symbols);
    }
    for rule in active_rules {
        collect_symbol_arities(rule.lhs(), &mut occurring_symbols);
        collect_symbol_arities(rule.rhs(), &mut occurring_symbols);
    }

    q_lhss
        .iter()
        .filter(|lhs| {
            let Term::App { symbol, args } = lhs else {
                return false;
            };
            args.iter()
                .all(|argument| term_is_q_normal(argument, q_lhss))
                && occurring_symbols.get(symbol).copied() == Some(args.len())
        })
        .cloned()
        .collect()
}

#[cfg(test)]
pub(crate) fn refined_innermost_lhss_for_pairs(
    trs: &Trs,
    pairs: &[DependencyPair],
    parent_innermost_lhss: Option<&[Term]>,
) -> Option<Vec<Term>> {
    if trs.strategy() != RewriteStrategy::Innermost {
        return parent_innermost_lhss.map(<[Term]>::to_vec);
    }
    let initial_lhss;
    let current_lhss = if let Some(lhss) = parent_innermost_lhss {
        lhss
    } else {
        initial_lhss = trs
            .rules()
            .iter()
            .map(|rule| rule.lhs().clone())
            .collect::<Vec<_>>();
        &initial_lhss
    };
    let usable = usable_rules_in_innermost_context(trs, pairs, Some(current_lhss));
    Some(remaining_innermost_lhss(current_lhss, &usable, pairs))
}
