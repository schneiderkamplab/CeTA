//! A single complex-constant removal step. The payload contains only a ground
//! term and an old/new pair map; the continuation is a separate worklist child.
use std::collections::{BTreeMap, BTreeSet};

use super::super::{ProblemCertificate, ProblemState, ProcessorApplication, ProcessorResult};
use crate::core::{Symbol, Term, Trs};
use crate::proving::dependency_pairs::{
    DependencyPair, DpProblemContext, DpProofTree, apply_substitution, match_term, term_is_linear,
    term_is_q_normal,
};
use crate::proving::processors::rewrite_analysis::critical_pairs;

pub(super) fn apply(state: &ProblemState, payload: &str) -> ProcessorResult {
    let result = derive(state, payload);
    result.unwrap_or(ProcessorResult::Inapplicable)
}

/// Discover a ground RHS subterm and lift it to a fresh shared parameter.
/// Selection uses occurrence count, not symbol names or retained pair maps.
/// The existing executable side conditions validate every proposed step.
pub(super) fn discover(state: &ProblemState, deadline: Option<std::time::Instant>) -> ProcessorResult {
    discover_ranked(state, deadline, false)
}

pub(super) fn discover_largest(state: &ProblemState, deadline: Option<std::time::Instant>) -> ProcessorResult {
    discover_ranked(state, deadline, true)
}

fn discover_ranked(state: &ProblemState, deadline: Option<std::time::Instant>, largest: bool) -> ProcessorResult {
    use crate::core::{RewriteRule, Variable};
    use crate::proving::dependency_pairs::positions_with_subterms;
    let ProblemState::DependencyPairs(problem) = state else { return ProcessorResult::Inapplicable; };
    let cancellation = crate::proving::runtime::CancellationScope::current(deadline);
    let cancelled = || cancellation.is_cancelled()
        || crate::proving::dependency_pairs::strategy_timed_out(deadline);
    if cancelled() { return ProcessorResult::TimedOut; }
    let pairs = problem.pairs.iter().chain(&problem.stats.weak_pairs).collect::<Vec<_>>();
    let mut constants = Vec::<(Term, usize)>::new();
    let mut used_symbols = BTreeSet::new();
    let mut used_variables = BTreeSet::new();
    for term in problem.trs.rules().iter().flat_map(|r| [r.lhs(), r.rhs()])
        .chain(problem.stats.active_rules.as_deref().unwrap_or(problem.trs.rules()).iter()
            .chain(&problem.stats.strict_rules).flat_map(|r| [r.lhs(), r.rhs()]))
        .chain(pairs.iter().flat_map(|p| [p.lhs(), p.rhs()]))
        .chain(problem.innermost_lhss.iter().flatten()) {
        if cancelled() { return ProcessorResult::TimedOut; }
        used_variables.extend(term.variables());
        for (_, child) in positions_with_subterms(term) {
            if let Term::App { symbol, .. } = child { used_symbols.insert(symbol.clone()); }
        }
    }
    for pair in &pairs {
        if cancelled() { return ProcessorResult::TimedOut; }
        for (position, term) in positions_with_subterms(pair.rhs()) {
            if position.is_empty() || !term.variables().is_empty() { continue; }
            if let Some((_, count)) = constants.iter_mut().find(|(t, _)| t == term) {
                *count += 1;
            } else { constants.push((term.clone(), 1)); }
        }
    }
    constants.sort_by_key(|(_, count)| std::cmp::Reverse(*count));
    if largest {
        // Abstract a closed computation as a whole rather than its frequent
        // small constructor subterms. Both rankings are name-independent.
        constants.sort_by_key(|(term, _)| std::cmp::Reverse(positions_with_subterms(term).len()));
    }
    let fresh = (0..).map(|i| Variable::new(format!("cc_parameter_{i}")))
        .find(|v| !used_variables.contains(v)).unwrap();
    let parameter = Term::Var(fresh);
    let mut roots = BTreeMap::new();
    let mut next = 0;
    for pair in &pairs {
        for term in [pair.lhs(), pair.rhs()] {
            let Term::App { symbol, args } = term else { return ProcessorResult::Inapplicable; };
            roots.entry((symbol.clone(), args.len())).or_insert_with(|| loop {
                let proposal = Symbol::new(format!("cc_lift_{next}#"));
                next += 1;
                if used_symbols.insert(proposal.clone()) { break proposal; }
            });
        }
    }
    fn abstract_term(t: &Term, constant: &Term, parameter: &Term) -> Term {
        if t == constant { return parameter.clone(); }
        match t {
            Term::Var(_) => t.clone(),
            Term::App { symbol, args } => Term::app(symbol.as_str(), args.iter()
                .map(|a| abstract_term(a, constant, parameter)).collect()),
        }
    }
    for (constant, _) in constants.into_iter().take(32) {
        if cancelled() { return ProcessorResult::TimedOut; }
        let mut payload = String::new();
        crate::cert::write_term_cpf3(&mut payload, &constant, 0);
        payload.push_str("<ruleMap>");
        for pair in &pairs {
            let lift = |t: &Term, rhs: bool| {
                let Term::App { symbol, args } = t else { unreachable!() };
                let mut lifted = args.iter().map(|a| if rhs {
                    abstract_term(a, &constant, &parameter)
                } else { a.clone() }).collect::<Vec<_>>();
                lifted.push(parameter.clone());
                Term::app(roots[&(symbol.clone(), args.len())].as_str(), lifted)
            };
            let new = RewriteRule::new(lift(pair.lhs(), false), lift(pair.rhs(), true));
            payload.push_str("<ruleMapEntry>");
            for rule in [pair.as_rule(), new] {
                payload.push_str("<rule>");
                crate::cert::write_term_cpf3(&mut payload, rule.lhs(), 0);
                crate::cert::write_term_cpf3(&mut payload, rule.rhs(), 0);
                payload.push_str("</rule>");
            }
            payload.push_str("</ruleMapEntry>");
        }
        payload.push_str("</ruleMap>");
        if let ProcessorResult::Applied(application) = apply(state, &payload) {
            return ProcessorResult::Applied(application.with_selected_atom(if largest {
                "complex-constant-removal-largest"
            } else { "complex-constant-removal" }));
        }
    }
    ProcessorResult::Inapplicable
}

fn derive(state: &ProblemState, payload: &str) -> Option<ProcessorResult> {
    let ProblemState::DependencyPairs(problem) = state else {
        return None;
    };
    if !matches!(problem.stats.problem, DpProblemContext::Ordinary)
        || !problem.stats.strict_rules.is_empty()
    {
        return None;
    }
    let wrapped = format!("<payload>{payload}</payload>");
    let doc = roxmltree::Document::parse(&wrapped).ok()?;
    let mut children = doc.root_element().children().filter(|n| n.is_element());
    let constant_node = children.next()?;
    let map_node = children.next()?;
    if map_node.tag_name().name() != "ruleMap" || children.next().is_some() {
        return None;
    }
    let constant_xml = format!("<constant>{}</constant>", &wrapped[constant_node.range()]);
    let constants =
        crate::parsing::parse_cpf_term_container_fragment(&constant_xml, "constant").ok()??;
    let [constant] = constants.as_slice() else {
        return None;
    };
    if !constant.variables().is_empty() {
        return None;
    }
    let mut mappings = Vec::new();
    for entry in map_node.children().filter(|n| n.is_element()) {
        if entry.tag_name().name() != "ruleMapEntry" {
            return None;
        }
        let rules_xml = format!(
            "<rules>{}</rules>",
            entry
                .children()
                .filter(|n| n.is_element())
                .map(|n| &wrapped[n.range()])
                .collect::<String>()
        );
        let rules =
            crate::parsing::parse_cpf_rule_container_fragment(&rules_xml, "rules").ok()??;
        let [old, new] = rules.as_slice() else {
            return None;
        };
        mappings.push((old.clone(), new.clone()));
    }
    // Variables are local to each pair: transport both sides of the map
    // together when an earlier runtime processor freshened their spelling.
    for (old, new) in &mut mappings {
        if let Some(live) = problem.pairs.iter().chain(&problem.stats.weak_pairs)
            .find(|pair| super::general_red_pair::alpha_equivalent_rules(old, &pair.as_rule())) {
            let mut substitution = BTreeMap::new();
            if !match_term(old.lhs(), live.lhs(), &mut substitution)
                || !match_term(old.rhs(), live.rhs(), &mut substitution) { return None; }
            *old = live.as_rule();
            *new = crate::core::RewriteRule::new(apply_substitution(new.lhs(), &substitution),
                apply_substitution(new.rhs(), &substitution));
        }
    }
    let Term::App { args, .. } = mappings.first()?.1.lhs() else {
        return None;
    };
    let Term::Var(fresh) = args.last()? else {
        return None;
    };
    let active = problem
        .stats
        .active_rules
        .as_deref()
        .unwrap_or(problem.trs.rules());
    let q = problem.innermost_lhss.as_ref()?;
    // This is a sufficient executable NF(Q) subset NF(R) check: every rule
    // lhs is an instance of a Q pattern, so an R redex is necessarily a Q redex.
    if active.iter().any(|r| {
        matches!(r.lhs(), Term::Var(_))
            || !q
                .iter()
                .any(|p| match_term(p, r.lhs(), &mut BTreeMap::new()))
    }) {
        return None;
    }
    let lhs = active.iter().map(|r| r.lhs().clone()).collect::<Vec<_>>();
    if !term_is_q_normal(constant, &lhs) {
        // Weak orthogonality is a sufficient confluence condition. Nontrivial
        // innermost critical-pair joining can be added without weakening it.
        let trs = Trs::new_with_strategy(
            None,
            BTreeSet::new(),
            active.to_vec(),
            problem.trs.strategy(),
        );
        if active.iter().any(|r| !term_is_linear(r.lhs())) || !critical_pairs(&trs).is_empty() {
            return None;
        }
    }
    let root = |t: &Term| -> Option<(Symbol, usize)> {
        match t {
            Term::App { symbol, args } => Some((symbol.clone(), args.len())),
            _ => None,
        }
    };
    let defined = active
        .iter()
        .filter_map(|r| root(r.lhs()))
        .collect::<BTreeSet<_>>();
    let q_roots = q.iter().filter_map(root).collect::<BTreeSet<_>>();
    let mut renaming = BTreeMap::new();
    for (old, new) in &mappings {
        for (a, b) in [(old.lhs(), new.lhs()), (old.rhs(), new.rhs())] {
            let a = root(a)?;
            let b = root(b)?;
            if b.1 != a.1 + 1 {
                return None;
            }
            if renaming
                .insert(a, b.0.clone())
                .is_some_and(|previous| previous != b.0)
            {
                return None;
            }
        }
    }
    let mut substitution = BTreeMap::new();
    substitution.insert(fresh.clone(), constant.clone());
    for (old, new) in &mappings {
        if old.lhs().variables().contains(fresh)
            || old.rhs().variables().contains(fresh)
            || defined.contains(&root(old.rhs())?)
        {
            return None;
        }
        let Term::App { args: old_lhs, .. } = old.lhs() else {
            return None;
        };
        let Term::App { args: old_rhs, .. } = old.rhs() else {
            return None;
        };
        let Term::App { args: new_lhs, .. } = new.lhs() else {
            return None;
        };
        let Term::App { args: new_rhs, .. } = new.rhs() else {
            return None;
        };
        if defined.contains(&root(new.lhs())?)
            || q_roots.contains(&root(new.lhs())?)
            || new_lhs.last() != Some(&Term::Var(fresh.clone()))
            || new_rhs.last() != Some(&Term::Var(fresh.clone()))
            || &new_lhs[..new_lhs.len() - 1] != old_lhs
            || new_rhs[..new_rhs.len() - 1]
                .iter()
                .map(|t| apply_substitution(t, &substitution))
                .collect::<Vec<_>>()
                != *old_rhs
        {
            return None;
        }
    }
    let convert = |pairs: &[DependencyPair]| -> Option<Vec<DependencyPair>> {
        let mut result = Vec::new();
        for pair in pairs {
            let mut covered = false;
            for (old, new) in &mappings {
                if old.lhs() == pair.lhs() && old.rhs() == pair.rhs() {
                    result.push(DependencyPair::from_rule(new.clone(), pair.source_rule()));
                    covered = true;
                }
            }
            if !covered {
                return None;
            }
        }
        Some(result)
    };
    let mut child = problem.clone();
    child.pairs = convert(&problem.pairs)?;
    child.stats.weak_pairs = convert(&problem.stats.weak_pairs)?;
    let mut payload_xml = wrapped[constant_node.range()].to_owned();
    payload_xml.push_str("<ruleMap>");
    for (old, new) in &mappings {
        let trs = Trs::new_with_strategy(None, BTreeSet::new(), vec![old.clone(), new.clone()], problem.trs.strategy());
        let xml = crate::cert::write_trs_input_cpf3(&trs);
        let doc = roxmltree::Document::parse(&xml).ok()?;
        payload_xml.push_str("<ruleMapEntry>");
        for rule in doc.descendants().filter(|n| n.is_element() && n.tag_name().name() == "rule") {
            payload_xml.push_str(&xml[rule.range()]);
        }
        payload_xml.push_str("</ruleMapEntry>");
    }
    payload_xml.push_str("</ruleMap>");
    Some(ProcessorResult::Applied(ProcessorApplication::new(
        vec![ProblemState::DependencyPairs(child)],
        move |children| {
            let [ProblemCertificate::DependencyPairTree(proof)] =
                <[ProblemCertificate; 1]>::try_from(children).ok()?
            else {
                return None;
            };
            Some(ProblemCertificate::DependencyPairTree(
                DpProofTree::TransformationExact {
                    processor_tag: "complexConstantRemovalProc".into(),
                    payload_xml: payload_xml.clone(),
                    proof: Box::new(proof),
                },
            ))
        },
    )))
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::core::{RewriteRule, RewriteStrategy};
    use crate::proving::dependency_pairs::DpOptions;
    use crate::proving::processors::dp::DpProblemState;

    fn example() -> (ProblemState, String) {
        let payload = concat!(
            "<funapp><name>zero</name></funapp><ruleMap><ruleMapEntry>",
            "<rule><funapp><name>F</name><var>x</var></funapp>",
            "<funapp><name>G</name><funapp><name>zero</name></funapp></funapp></rule>",
            "<rule><funapp><name>A</name><var>x</var><var>fresh</var></funapp>",
            "<funapp><name>B</name><var>fresh</var><var>fresh</var></funapp></rule>",
            "</ruleMapEntry></ruleMap>"
        )
        .to_owned();
        let pair = DependencyPair::from_rule(
            RewriteRule::new(
                Term::app("F", vec![Term::var("x")]),
                Term::app("G", vec![Term::app("zero", vec![])]),
            ),
            0,
        );
        let trs = Trs::new_with_strategy(None, BTreeSet::new(), vec![], RewriteStrategy::Innermost);
        let mut state = DpProblemState::ordinary(trs, vec![pair], DpOptions::default());
        state.innermost_lhss = Some(vec![]);
        (ProblemState::DependencyPairs(state), payload)
    }

    #[test]
    fn native_complex_constant_is_symbol_independent_and_makes_progress() {
        for (f, g, zero) in [("F", "G", "zero"), ("renamed_a", "renamed_b", "renamed_c")] {
            let trs = Trs::new_with_strategy(None, BTreeSet::new(), vec![], RewriteStrategy::Innermost);
            let pair = DependencyPair::new(Term::app(f, vec![Term::var("x")]),
                Term::app(g, vec![Term::app(zero, vec![])]), 0);
            let mut problem = DpProblemState::ordinary(trs, vec![pair], DpOptions::default());
            problem.innermost_lhss = Some(vec![]);
            let ProcessorResult::Applied(application) = discover(&ProblemState::DependencyPairs(problem), None) else { panic!() };
            assert_eq!(application.selected_atom(), Some("complex-constant-removal"));
            assert!(matches!(discover(&application.residuals[0], None), ProcessorResult::Inapplicable));
        }
        use crate::proving::dependency_pairs::{DpStrategy, DpStrategyProcessor};
        assert_eq!(DpStrategy::parse("complex-constant-removal").unwrap(),
            DpStrategy::Processor(DpStrategyProcessor::ComplexConstantRemoval));
    }

    #[test]
    fn largest_closed_computation_is_an_independent_search_choice() {
        let trs = Trs::new_with_strategy(None, BTreeSet::new(), vec![], RewriteStrategy::Innermost);
        let zero = Term::app("z", vec![]);
        let pair = DependencyPair::new(Term::app("F", vec![Term::var("x")]),
            Term::app("G", vec![Term::app("calculate", vec![zero.clone(), zero])]), 0);
        let mut problem = DpProblemState::ordinary(trs, vec![pair], DpOptions::default());
        problem.innermost_lhss = Some(vec![]);
        let state = ProblemState::DependencyPairs(problem);
        let ProcessorResult::Applied(application) = discover_largest(&state, None) else { panic!() };
        let ProblemState::DependencyPairs(child) = &application.residuals[0] else { panic!() };
        let Term::App { args, .. } = child.pairs[0].rhs() else { panic!() };
        assert!(matches!(args[0], Term::Var(_)));
        assert!(crate::proving::dependency_pairs::DpStrategy::parse("complex-constant-removal-largest").is_ok());
    }

    #[test]
    fn complex_constant_removal_checks_drop_and_retains_context() {
        let (state, payload) = example();
        let ProcessorResult::Applied(application) = apply(&state, &payload) else {
            panic!("valid step rejected")
        };
        assert_eq!(application.residuals.len(), 1);
        let ProblemState::DependencyPairs(child) = &application.residuals[0] else {
            panic!()
        };
        assert_eq!(child.pairs.len(), 1);
        assert_eq!(child.innermost_lhss, Some(vec![]));
        assert!(matches!(
            apply(
                &state,
                &payload.replace(
                    "<name>zero</name></funapp><ruleMap>",
                    "<name>different</name></funapp><ruleMap>"
                )
            ),
            ProcessorResult::Inapplicable
        ));
        assert!(matches!(
            apply(&state, &payload.replace("fresh", "x")),
            ProcessorResult::Inapplicable
        ));
        assert!(matches!(
            apply(&state, &payload.replace("<ruleMapEntry>", "<invalid>")),
            ProcessorResult::Inapplicable
        ));
    }

    #[test]
    fn complex_constant_removal_ceta_certifies_native_reconstruction_and_rejects_mutation() {
        let checker = std::path::Path::new("../CeTA-CSR/ceta");
        if !checker.exists() { return; }
        let (state, _) = example();
        let ProcessorResult::Applied(application) = discover(&state, None) else { panic!() };
        use crate::proving::processors::WorklistProcessor;
        let ProcessorResult::Applied(graph) = super::super::DependencyGraphProcessor { deadline: None }
            .apply(&application.residuals[0]) else { panic!() };
        let graph_proof = graph.reconstruct(vec![]).expect("acyclic child");
        let Some(ProblemCertificate::DependencyPairTree(tree)) = application.reconstruct(vec![graph_proof]) else { panic!() };
        let ProblemState::DependencyPairs(problem) = state else { panic!() };
        let proof = crate::proving::dependency_pairs::complete_dependency_pair_probe(&problem, tree);
        let cpf = crate::cert::write_cpf3_dp_problem(&problem.trs, &problem.pairs, &proof);
        let directory = std::env::temp_dir().join(format!("ferrum-complex-constant-test-{}-{}",
            std::process::id(), std::time::SystemTime::now().duration_since(std::time::UNIX_EPOCH).unwrap().as_nanos()));
        std::fs::create_dir(&directory).unwrap();
        let path = directory.join("proof.xml");
        for repeat in 0..2 {
            std::fs::write(&path, &cpf).unwrap();
            let output = std::process::Command::new(checker).arg(&path).output().unwrap();
            let stdout = String::from_utf8_lossy(&output.stdout);
            assert!(output.status.success() && stdout.contains("CERTIFIED"), "repeat {repeat}: {stdout} {}", String::from_utf8_lossy(&output.stderr));
        }
        // Change only the declared constant; the pair-map's old RHS stays zero.
        let offset = cpf.find("<complexConstantRemovalProc>").unwrap();
        let broken = format!("{}{}", &cpf[..offset], cpf[offset..].replacen("<name>zero</name>", "<name>different</name>", 1));
        std::fs::write(&path, broken).unwrap();
        let output = std::process::Command::new(checker).arg(&path).output().unwrap();
        assert!(!String::from_utf8_lossy(&output.stdout).contains("CERTIFIED"));
        std::fs::remove_file(path).unwrap();
        std::fs::remove_dir(directory).unwrap();
    }

    #[test]
    fn complex_constant_removal_rejects_missing_q_and_uncovered_pairs() {
        let (mut state, payload) = example();
        let ProblemState::DependencyPairs(problem) = &mut state else {
            panic!()
        };
        problem.innermost_lhss = None;
        assert!(matches!(
            apply(&state, &payload),
            ProcessorResult::Inapplicable
        ));
        let (state, payload) = example();
        assert!(matches!(
            apply(
                &state,
                &payload.replace("<name>F</name>", "<name>other</name>")
            ),
            ProcessorResult::Inapplicable
        ));
    }
}
