use std::time::Instant;

use crate::proving::dependency_pairs::{
    CsrDpConstruction, DpProblemContext, DpProofTree, strategy_timed_out,
    synthesize_instantiation_step_filtered,
};
use crate::proving::runtime::CancellationScope;

use super::super::{
    ProblemCertificate, ProblemState, ProcessorApplication, ProcessorResult, WorklistProcessor,
};

fn improved_csr_context(
    problem: &crate::proving::processors::dp::DpProblemState,
) -> Option<&crate::core::CsrTrs> {
    match &problem.stats.problem {
        DpProblemContext::ContextSensitive(context)
            if context.construction == CsrDpConstruction::Improved =>
        {
            Some(&context.csr)
        }
        _ => None,
    }
}

pub struct InstantiationProcessor {
    pub max_per_pair: Option<usize>,
    pub candidate_index: usize,
    /// Generic portfolio search is depth-bounded; an exact retained witness
    /// remains replayable regardless of that search-local bound.
    pub require_depth_bound: bool,
    pub deadline: Option<Instant>,
}

const MAX_GENERIC_INSTANTIATION_TRANSFORMS: usize = 8;

/// Explicit alpha-renaming instantiation, separate from indexed candidate
/// enumeration so adding this processor cannot shift retained candidate IDs.
pub struct AlphaMergeProcessor {
    pub deadline: Option<Instant>,
}

impl WorklistProcessor for AlphaMergeProcessor {
    fn name(&self) -> &'static str { "dependency-pair-alpha-merge" }

    fn apply(&self, state: &ProblemState) -> ProcessorResult {
        let ProblemState::DependencyPairs(problem) = state else { return ProcessorResult::Inapplicable };
        if !matches!(problem.stats.problem, DpProblemContext::Ordinary) || !problem.stats.weak_pairs.is_empty() {
            return ProcessorResult::Inapplicable;
        }
        let cancellation = CancellationScope::current(self.deadline);
        for (removed, pair) in problem.pairs.iter().enumerate() {
            if cancellation.is_cancelled() || strategy_timed_out(self.deadline) { return ProcessorResult::TimedOut; }
            let Some(representative) = problem.pairs[..removed].iter().find(|other|
                super::general_red_pair::alpha_equivalent_rules(&pair.as_rule(), &other.as_rule())) else { continue };
            // Mutual instancehood makes the representative cover every
            // incoming instance in CeTA's instantiation_proc criterion.
            let step = crate::proving::dependency_pairs::DpInstantiationStep {
                pair: pair.clone(), instantiations: vec![representative.clone()], context_sensitive: false,
            };
            let mut child = problem.clone();
            child.pairs.remove(removed);
            return ProcessorResult::Applied(ProcessorApplication::new(
                vec![ProblemState::DependencyPairs(child)], move |children| {
                    let [ProblemCertificate::DependencyPairTree(proof)] = <[ProblemCertificate; 1]>::try_from(children).ok()? else { return None };
                    Some(ProblemCertificate::DependencyPairTree(DpProofTree::Instantiation {
                        step: step.clone(), proof: Box::new(proof),
                    }))
                }));
        }
        ProcessorResult::Inapplicable
    }
}

fn instantiation_candidates(
    state: &ProblemState,
    deadline: Option<Instant>,
) -> Option<
    Vec<(
        crate::proving::dependency_pairs::DpInstantiationStep,
        Vec<crate::proving::dependency_pairs::DependencyPair>,
    )>,
> {
    let ProblemState::DependencyPairs(problem) = state else {
        return Some(Vec::new());
    };
    if !problem.stats.weak_pairs.is_empty() {
        return Some(Vec::new());
    }
    let cancellation = CancellationScope::current(deadline);
    let active_rules = problem
        .stats
        .active_rules
        .as_deref()
        .unwrap_or(problem.trs.rules());
    let q_lhss = problem.innermost_lhss.as_deref().unwrap_or(&[]);
    let csr = improved_csr_context(problem);
    let mut tried = Vec::new();
    let mut candidates = Vec::new();
    loop {
        let next = synthesize_instantiation_step_filtered(
            // Keep candidate ordering independent of non-serialized caches.
            None,
            &problem.trs,
            &problem.pairs,
            active_rules,
            q_lhss,
            csr,
            deadline,
            &cancellation,
            |pair| !tried.contains(pair),
        );
        let Some((step, residual)) = next else {
            break;
        };
        tried.push(step.pair.clone());
        candidates.push((step, residual));
    }
    if cancellation.is_cancelled() || strategy_timed_out(deadline) {
        None
    } else {
        Some(candidates)
    }
}

pub(crate) fn instantiation_candidate_count(
    state: &ProblemState,
    deadline: Option<Instant>,
) -> Option<usize> {
    instantiation_candidates(state, deadline).map(|candidates| candidates.len())
}

impl WorklistProcessor for InstantiationProcessor {
    fn name(&self) -> &'static str {
        "dependency-pair-instantiation"
    }

    fn apply(&self, state: &ProblemState) -> ProcessorResult {
        let ProblemState::DependencyPairs(problem) = state else {
            return ProcessorResult::Inapplicable;
        };
        if !problem.stats.weak_pairs.is_empty() {
            return ProcessorResult::Inapplicable;
        }
        if self.require_depth_bound
            && problem.stats.generic_instantiation_transforms
                >= MAX_GENERIC_INSTANTIATION_TRANSFORMS
        {
            return ProcessorResult::Inapplicable;
        }
        let cancellation = CancellationScope::current(self.deadline);
        if cancellation.is_cancelled() || strategy_timed_out(self.deadline) {
            return ProcessorResult::TimedOut;
        }
        if self.max_per_pair == Some(0) {
            return ProcessorResult::Inapplicable;
        }
        let Some(candidates) = instantiation_candidates(state, self.deadline) else {
            return if cancellation.is_cancelled() || strategy_timed_out(self.deadline) {
                ProcessorResult::TimedOut
            } else {
                ProcessorResult::Inapplicable
            };
        };
        let Some((step, residual_pairs)) = candidates.into_iter().nth(self.candidate_index) else {
            return ProcessorResult::Inapplicable;
        };
        let mut residual = problem.clone();
        residual.pairs = residual_pairs;
        if self.require_depth_bound {
            residual.stats.generic_instantiation_transforms += 1;
        }
        let nontermination_pairs = residual.pairs.clone();
        let nontermination_allowed = !problem.stats.normal_form_substitutions
            || problem.innermost_lhss.as_ref().is_none_or(Vec::is_empty);

        ProcessorResult::Applied(
            ProcessorApplication::new(vec![ProblemState::DependencyPairs(residual)], {
                let step = step.clone();
                move |children| {
                    let [ProblemCertificate::DependencyPairTree(proof)] =
                        <[ProblemCertificate; 1]>::try_from(children).ok()?
                    else {
                        return None;
                    };
                    Some(ProblemCertificate::DependencyPairTree(
                        DpProofTree::Instantiation {
                            step: step.clone(),
                            proof: Box::new(proof),
                        },
                    ))
                }
            })
            .with_child_short_circuit(move |certificate| match certificate {
                ProblemCertificate::DependencyPairNontermination(proof) => {
                    if !nontermination_allowed { return None; }
                    if std::env::var_os("FERRUM_WORKLIST_TRACE").is_some() {
                        eprintln!(
                            "instantiation propagated DP nontermination through {} instantiated pairs",
                            step.instantiations.len(),
                        );
                    }
                    Some(ProblemCertificate::DependencyPairNontermination(
                        crate::proving::DpNonterminationProof::Instantiation {
                            instantiated_pairs: nontermination_pairs.clone(),
                            proof: Box::new(proof.clone()),
                        },
                    ))
                }
                _ => {
                    if std::env::var_os("FERRUM_WORKLIST_TRACE").is_some() {
                        eprintln!("instantiation could not propagate a non-DP certificate");
                    }
                    None
                }
            }),
        )
    }
}

#[cfg(test)]
mod tests {
    use std::collections::{BTreeMap, BTreeSet};

    use super::*;
    use crate::core::{ReplacementMap, RewriteRule, Symbol, Term, Trs, Variable};
    use crate::proving::dependency_pairs::{
        CsrDpProblemContext, CsrGraphEstimator, DependencyPair, DpOptions,
    };
    use crate::proving::processors::dp::DpProblemState;

    #[test]
    fn alpha_duplicate_merge_is_an_explicit_identity_instantiation() {
        let strategy = crate::proving::dependency_pairs::DpStrategy::parse("alpha-merge").unwrap();
        assert!(matches!(strategy, crate::proving::dependency_pairs::DpStrategy::Processor(
            crate::proving::dependency_pairs::DpStrategyProcessor::AlphaMerge)));
        let pair = |variable: &str| DependencyPair::new_for_test(
            Term::app("f#", vec![Term::app("s", vec![Term::var(variable)])]),
            Term::app("f#", vec![Term::var(variable)]));
        let first = pair("x");
        let second = pair("renamed");
        let problem = DpProblemState::ordinary(
            Trs::new(None, BTreeSet::new(), vec![]),
            vec![first.clone(), second.clone()], DpOptions::default());
        let ProcessorResult::Applied(application) = AlphaMergeProcessor { deadline: None }.apply(&ProblemState::DependencyPairs(problem)) else { panic!("alpha merge") };
        let ProblemState::DependencyPairs(child) = &application.residuals[0] else { panic!() };
        assert_eq!(child.pairs, vec![first.clone()]);
        let Some(ProblemCertificate::DependencyPairTree(DpProofTree::Instantiation { step, .. })) = application.reconstruct(vec![ProblemCertificate::DependencyPairTree(DpProofTree::Empty)]) else { panic!("explicit instantiation certificate") };
        assert_eq!(step.pair, second);
        assert_eq!(step.instantiations, vec![first]);
        assert!(!step.context_sensitive);
    }

    #[test]
    fn generic_instantiation_stops_at_the_search_depth_bound() {
        let trs = Trs::new(
            None,
            BTreeSet::from([Variable::new("x")]),
            vec![RewriteRule::new(
                Term::app("g", vec![Term::var("x")]),
                Term::app("h", vec![Term::var("x")]),
            )],
        );
        let pair = DependencyPair::new_for_test(
            Term::app("f#", vec![Term::app("g", vec![Term::var("x")])]),
            Term::app("f#", vec![Term::app("h", vec![Term::var("x")])]),
        );
        let mut state = DpProblemState::ordinary(trs, vec![pair], DpOptions::default());
        state.stats.generic_instantiation_transforms = MAX_GENERIC_INSTANTIATION_TRANSFORMS;

        assert!(matches!(
            InstantiationProcessor {
                max_per_pair: Some(1),
                candidate_index: 0,
                require_depth_bound: true,
                deadline: None,
            }
            .apply(&ProblemState::DependencyPairs(state)),
            ProcessorResult::Inapplicable
        ));
    }

    #[test]
    fn semantic_csr_residual_uses_the_ordinary_instantiation_context() {
        let trs = Trs::new(
            None,
            BTreeSet::from([Variable::new("x")]),
            vec![RewriteRule::new(
                Term::app("g", vec![Term::var("x")]),
                Term::app("h", vec![Term::var("x")]),
            )],
        );
        let csr = crate::core::CsrTrs::new(
            trs.clone(),
            ReplacementMap::new(BTreeMap::from([
                (Symbol::new("g"), BTreeSet::from([0])),
                (Symbol::new("h"), BTreeSet::new()),
            ])),
        )
        .expect("valid replacement map");
        let pair = DependencyPair::new_for_test(
            Term::app("f#", vec![Term::app("g", vec![Term::var("x")])]),
            Term::app("f#", vec![Term::app("h", vec![Term::var("x")])]),
        );
        let mut state = DpProblemState::ordinary(trs, vec![pair], DpOptions::default());
        state.stats.semantic_csr_context = Some(CsrDpProblemContext {
            csr: csr.clone(),
            construction: CsrDpConstruction::Improved,
            graph_estimator: CsrGraphEstimator::ContextSensitive,
            use_qcs_usable_rules: true,
            innermost_q_lhss: None,
        });

        assert_eq!(improved_csr_context(&state), None);
    }
}
