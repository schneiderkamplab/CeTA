//! Native bounded-increase/conditional polynomial synthesis.
//!
//! The proof calculus follows Bounded_Increase_Impl.check_cc_prf. Structural
//! induction produces symbolic arithmetic leaves, then one QF_NIA query
//! jointly chooses all interpretations and the pairs to delete. No retained
//! proof, interpretation, symbol name, or benchmark identity is consulted.
use std::collections::{BTreeMap, BTreeSet};
use std::time::Instant;

use super::super::{ProblemState, ProcessorResult, WorklistProcessor};
use super::{DpProblemState, ExactGeneralRedPairProcessor};
use crate::core::{RewriteRule, Term, Variable};
use crate::proving::dependency_pairs::{
    DpProblemContext, apply_substitution, parse_smt_values, positions_with_subterms,
    run_smt_script, term_is_q_normal, unify_terms,
};

#[derive(Clone, Debug, Eq, PartialEq)]
enum Constraint {
    Rewrite(Term, Term),
    Order(bool, Term, Term),
    Implication(Vec<Constraint>, Box<Constraint>),
    All(Vec<Variable>, Box<Constraint>),
}

type Subst = BTreeMap<Variable, Term>;
type Leaf = (Option<(Term, Term)>, bool, Term, Term);

fn term_xml(t: &Term) -> String {
    let mut s = String::new();
    crate::cert::write_term_cpf3(&mut s, t, 0);
    s
}

fn rule_xml(r: &RewriteRule) -> String {
    format!("<rule>{}{}</rule>", term_xml(r.lhs()), term_xml(r.rhs()))
}

impl Constraint {
    fn subst(&self, sigma: &Subst) -> Self {
        let t = |x| apply_substitution(x, sigma);
        match self {
            Self::Rewrite(a, b) => Self::Rewrite(t(a), t(b)),
            Self::Order(s, a, b) => Self::Order(*s, t(a), t(b)),
            Self::Implication(cs, c) => Self::Implication(
                cs.iter().map(|c| c.subst(sigma)).collect(),
                Box::new(c.subst(sigma)),
            ),
            Self::All(xs, c) => {
                let mut sigma = sigma.clone();
                for x in xs {
                    sigma.remove(x);
                }
                // All binders are globally fresh; no substitution can capture
                // a binder introduced elsewhere by this constructor.
                Self::All(xs.clone(), Box::new(c.subst(&sigma)))
            }
        }
    }

    fn variables(&self) -> BTreeSet<Variable> {
        match self {
            Self::Rewrite(a, b) | Self::Order(_, a, b) => {
                a.variables().union(&b.variables()).cloned().collect()
            }
            Self::Implication(cs, c) => cs
                .iter()
                .chain(std::iter::once(c.as_ref()))
                .flat_map(Self::variables)
                .collect(),
            Self::All(xs, c) => c
                .variables()
                .difference(&xs.iter().cloned().collect())
                .cloned()
                .collect(),
        }
    }

    fn xml(&self) -> String {
        let body = match self {
            Self::Rewrite(a, b) => format!(
                "<constraint>{}<rewrite/>{}</constraint>",
                term_xml(a),
                term_xml(b)
            ),
            Self::Order(s, a, b) => format!(
                "<constraint>{}<{}{}/>{}</constraint>",
                term_xml(a),
                if *s { "strict" } else { "nonStrict" },
                "",
                term_xml(b)
            ),
            Self::Implication(cs, c) => format!(
                "<implication>{}{}</implication>",
                cs.iter().map(Self::xml).collect::<String>(),
                c.xml()
            ),
            Self::All(xs, c) => {
                let mut body = c.xml();
                for x in xs.iter().rev() {
                    body = format!(
                        "<conditionalConstraint><all>{}{}</all></conditionalConstraint>",
                        term_xml(&Term::Var(x.clone())),
                        body
                    );
                }
                return body;
            }
        };
        format!("<conditionalConstraint>{body}</conditionalConstraint>")
    }
}

fn goal(cs: &[Constraint], c: &Constraint) -> Constraint {
    if cs.is_empty() {
        c.clone()
    } else {
        Constraint::Implication(cs.to_vec(), Box::new(c.clone()))
    }
}
fn wrap(body: String) -> String {
    format!("<conditionalConstraintProof>{body}</conditionalConstraintProof>")
}

struct Calculus<'a> {
    rules: &'a [RewriteRule],
    defined: BTreeSet<String>,
    reserved: BTreeSet<Variable>,
    fresh: usize,
    nodes: usize,
    reinduct: usize,
    independent_induction: bool,
    dataflow_induction: bool,
    deadline: Option<Instant>,
}

impl Calculus<'_> {
    fn fresh(&mut self) -> Variable {
        loop {
            self.fresh += 1;
            let v = Variable::new(format!("__cond{}", self.fresh));
            if self.reserved.insert(v.clone()) {
                return v;
            }
        }
    }
    fn constructor_term(&self, t: &Term) -> bool {
        positions_with_subterms(t).iter().all(|(_, t)| {
            t.root_symbol()
                .is_none_or(|s| !self.defined.contains(s.as_str()))
        })
    }
    fn renamed(&mut self, r: &RewriteRule) -> RewriteRule {
        let vars = r
            .lhs()
            .variables()
            .union(&r.rhs().variables())
            .cloned()
            .collect::<Vec<_>>();
        let sigma = vars
            .into_iter()
            .map(|v| (v, Term::Var(self.fresh())))
            .collect();
        RewriteRule::new(
            apply_substitution(r.lhs(), &sigma),
            apply_substitution(r.rhs(), &sigma),
        )
    }

    fn prove(
        &mut self,
        cs: Vec<Constraint>,
        con: Constraint,
        depth: usize,
    ) -> Option<(String, Vec<Leaf>)> {
        if self.deadline.is_some_and(|d| Instant::now() >= d) { return None; }
        // Close an already impossible constructor premise before choosing
        // any recursive normalization/induction step. Otherwise an unrelated
        // earlier premise can consume the depth budget and turn a vacuous
        // branch into a stronger unconditional arithmetic obligation.
        for c in &cs {
            if let Constraint::Rewrite(
                Term::App { symbol: f, args: ss },
                Term::App { symbol: g, args: ts },
            ) = c {
                if !self.defined.contains(f.as_str()) && (f != g || ss.len() != ts.len()) {
                    return Some((wrap(format!(
                        "<differentConstructor>{}</differentConstructor>", c.xml()
                    )), vec![]));
                }
            }
        }
        self.nodes += 1;
        if depth > 80 || self.nodes > 8000 || self.deadline.is_some_and(|d| Instant::now() >= d) {
            if std::env::var_os("FERRUM_CONDITIONAL_TRACE").is_some() {
                eprintln!(
                    "conditional calculus limit depth={depth}: {:?}",
                    goal(&cs, &con)
                );
            }
            return None;
        }
        // A fresh rewrite output unused by the conclusion or any other
        // premise need not enter an induction hypothesis. Keeping it can
        // require an unrelated auxiliary computation to match at every
        // recursive call. Delete_Condition proves the stronger obligation;
        // it does not assert that the discarded rewrite is realizable.
        for (i, c) in cs.iter().enumerate() {
            let Constraint::Rewrite(lhs, Term::Var(x)) = c else { continue };
            if lhs.variables().contains(x) || con.variables().contains(x)
                || cs.iter().enumerate().any(|(j, other)| j != i && other.variables().contains(x))
            {
                continue;
            }
            let mut next = cs.clone();
            next.remove(i);
            let (proof, leaves) = self.prove(next.clone(), con.clone(), depth + 1)?;
            return Some((wrap(format!(
                "<deleteCondition>{}{proof}</deleteCondition>", goal(&next, &con).xml()
            )), leaves));
        }
        // Constructor decomposition and Q-normal variable equations are
        // deterministic proof normalization, not order/model enumeration.
        for (i, c) in cs.iter().enumerate() {
            let Constraint::Rewrite(a, b) = c else {
                continue;
            };
            if let (
                Term::App {
                    symbol: f,
                    args: ss,
                },
                Term::App {
                    symbol: g,
                    args: ts,
                },
            ) = (a, b)
            {
                if !self.defined.contains(f.as_str()) {
                    if f != g || ss.len() != ts.len() {
                        return Some((
                            wrap(format!(
                                "<differentConstructor>{}</differentConstructor>",
                                c.xml()
                            )),
                            vec![],
                        ));
                    }
                    let mut next = cs.clone();
                    next.remove(i);
                    next.extend(
                        ss.iter()
                            .zip(ts)
                            .map(|(s, t)| Constraint::Rewrite(s.clone(), t.clone())),
                    );
                    let (p, leaves) = self.prove(next.clone(), con.clone(), depth + 1)?;
                    return Some((
                        wrap(format!(
                            "<sameConstructor>{}{}{p}</sameConstructor>",
                            c.xml(),
                            goal(&next, &con).xml()
                        )),
                        leaves,
                    ));
                }
            }
            let substitution = match (a,b) {
                (Term::Var(x),t) if !t.variables().contains(x) => Some((x,t)),
                (t,Term::Var(x)) if !t.variables().contains(x) && self.constructor_term(t)
                    && !cs.iter().any(|c| matches!(c,Constraint::Rewrite(Term::App{symbol,args},_)
                        if self.defined.contains(symbol.as_str()) && args.contains(&Term::Var(x.clone())))) => Some((x,t)),
                _ => None,
            };
            if let Some((x, t)) = substitution {
                let sigma = BTreeMap::from([(x.clone(), t.clone())]);
                let next = cs
                    .iter()
                    .enumerate()
                    .filter(|(j, _)| *j != i)
                    .map(|(_, c)| c.subst(&sigma))
                    .collect::<Vec<_>>();
                let out = con.subst(&sigma);
                let (p, leaves) = self.prove(next.clone(), out.clone(), depth + 1)?;
                return Some((
                    wrap(format!(
                        "<variableEquation>{}{}{}{p}</variableEquation>",
                        term_xml(&Term::Var(x.clone())),
                        term_xml(t),
                        goal(&next, &out).xml()
                    )),
                    leaves,
                ));
            }
            if a == b && matches!(a, Term::Var(_)) {
                let mut next = cs.clone();
                next.remove(i);
                let (p, leaves) = self.prove(next.clone(), con.clone(), depth + 1)?;
                return Some((
                    wrap(format!(
                        "<deleteCondition>{}{p}</deleteCondition>",
                        goal(&next, &con).xml()
                    )),
                    leaves,
                ));
            }
        }
        // Instantiate an IH only by matching its premises against live ones.
        for c in &cs {
            let Constraint::All(xs, inner) = c else {
                continue;
            };
            let Constraint::Implication(prems, out) = inner.as_ref() else {
                continue;
            };
            let mut sigma = BTreeMap::new();
            let mut matched = true;
            for prem in prems {
                let found = cs.iter().find_map(|live| {
                    let mut s = sigma.clone();
                    match_constraint(prem, live, xs, &mut s).then_some(s)
                });
                if let Some(s) = found {
                    sigma = s;
                } else {
                    matched = false;
                    break;
                }
            }
            if !matched {
                continue;
            }
            // Unconstrained quantified variables can retain the corresponding
            // live variable; prefer variables already present in the goal.
            let mut aligned = sigma.clone();
            if match_constraint(out, &con, xs, &mut aligned) {
                sigma = aligned;
            }
            let free = con.variables();
            for x in xs {
                if !sigma.contains_key(x) {
                    let v = free.iter().find(|v| !xs.contains(v))?;
                    sigma.insert(x.clone(), Term::Var(v.clone()));
                }
            }
            if !sigma.values().all(|t| self.constructor_term(t)) {
                continue;
            }
            let out = out.subst(&sigma);
            // After proving every instantiated IH premise, its conclusion is
            // available. Discarding the other premises asks a stronger final
            // arithmetic question and avoids re-inducing on the same rewrite.
            let next = vec![out];
            let (p, leaves) = self.prove(next.clone(), con.clone(), depth + 1)?;
            let subst = sigma
                .iter()
                .map(|(x, t)| {
                    format!(
                        "<substEntry>{}{}</substEntry>",
                        term_xml(&Term::Var(x.clone())),
                        term_xml(t)
                    )
                })
                .collect::<String>();
            return Some((
                wrap(format!(
                    "<simplifyCondition>{}<substitution>{subst}</substitution>{}{p}</simplifyCondition>",
                    c.xml(),
                    goal(&next, &con).xml()
                )),
                leaves,
            ));
        }
        let rewrites = cs
            .iter()
            .filter(|c| matches!(c, Constraint::Rewrite(..)))
            .count();
        if rewrites == 0 {
            let Constraint::Order(strict, s, t) = &con else {
                return None;
            };
            let premise = cs.iter().find_map(|c| match c {
                Constraint::Order(b, u, v) if b == strict => Some((u.clone(), v.clone())),
                _ => None,
            });
            let retained = premise
                .as_ref()
                .map(|(u, v)| Constraint::Order(*strict, u.clone(), v.clone()))
                .into_iter()
                .collect::<Vec<_>>();
            let p = wrap("<final/>".to_owned());
            let p = if cs == retained {
                p
            } else {
                wrap(format!(
                    "<deleteCondition>{}{p}</deleteCondition>",
                    goal(&retained, &con).xml()
                ))
            };
            return Some((p, vec![(premise, *strict, s.clone(), t.clone())]));
        }
        // Make arguments of the induction subject distinct variables.
        for (i, c) in cs.iter().enumerate() {
            let Constraint::Rewrite(Term::App { symbol, args }, rhs) = c else {
                continue;
            };
            if !self.defined.contains(symbol.as_str()) {
                continue;
            }
            let mut seen = BTreeSet::new();
            for (j, t) in args.iter().enumerate() {
                if matches!(t,Term::Var(v) if seen.insert(v.clone())) {
                    continue;
                }
                let x = self.fresh();
                let mut replaced = args.clone();
                replaced[j] = Term::Var(x.clone());
                let mut next = cs.clone();
                next.remove(i);
                next.insert(
                    0,
                    Constraint::Rewrite(Term::app(symbol.as_str(), replaced), rhs.clone()),
                );
                next.insert(0, Constraint::Rewrite(t.clone(), Term::Var(x.clone())));
                let (p, leaves) = self.prove(next.clone(), con.clone(), depth + 1)?;
                return Some((
                    wrap(format!(
                        "<funargIntoVar>{}<position>{}</position>{}{}{p}</funargIntoVar>",
                        c.xml(),
                        j + 1,
                        term_xml(&Term::Var(x)),
                        goal(&next, &con).xml()
                    )),
                    leaves,
                ));
            }
        }
        let mut conclusion_variables = con.variables();
        loop {
            let old = conclusion_variables.len();
            for premise in &cs {
                if let Constraint::Rewrite(lhs, rhs) = premise {
                    if self.constructor_term(lhs) && self.constructor_term(rhs) {
                        let variables = premise.variables();
                        if !variables.is_disjoint(&conclusion_variables) {
                            conclusion_variables.extend(variables);
                        }
                    }
                }
            }
            if conclusion_variables.len() == old { break; }
        }
        let mut induction_candidates = cs.iter().enumerate().collect::<Vec<_>>();
        if self.independent_induction && self.dataflow_induction {
            // The combined fallback retains data-flow premises but explores
            // the opposite induction order. Constructor decomposition can
            // reorder sibling predicates, so either direction can expose the
            // useful bound first without relying on symbol names.
            induction_candidates.reverse();
        } else if self.independent_induction {
            induction_candidates.sort_by_key(|(_, c)| match c {
                Constraint::Rewrite(Term::App { args, .. }, _) => args.iter()
                    .flat_map(Term::variables).filter(|v| conclusion_variables.contains(v)).count(),
                _ => usize::MAX,
            });
        }
        for (i, c) in induction_candidates {
            let Constraint::Rewrite(a @ Term::App { symbol, args }, q) = c else {
                continue;
            };
            if !self.defined.contains(symbol.as_str()) || unify_terms(a, q, &mut BTreeMap::new()) {
                continue;
            }
            // If an IH for this predicate is already present but cannot yet
            // be instantiated, simplify its other rewrite premises first.
            // Re-inducing on the identical predicate only grows the context.
            let existing_induction_premises = cs.iter().filter_map(|c| match c {
                Constraint::All(_,inner) => match inner.as_ref() {
                    Constraint::Implication(pre,_) if matches!(pre.first(),Some(Constraint::Rewrite(t,_)) if t.root_symbol()==Some(symbol)) => Some(pre.len()),
                    _=>None,
                },
                _=>None,
            }).min();
            let xs = args
                .iter()
                .map(|t| {
                    if let Term::Var(x) = t {
                        Some(x.clone())
                    } else {
                        None
                    }
                })
                .collect::<Option<Vec<_>>>()?;
            if xs.iter().collect::<BTreeSet<_>>().len() != xs.len() {
                continue;
            }
            // If the predicate's arguments do not occur in the arithmetic
            // conclusion, first try proving that conclusion from this rewrite
            // alone. This exposes impossible result constructors without
            // burdening its IH with unrelated data-flow premises. Induction's
            // conjunct list is an explicitly checked subset of the context.
            let independent = self.independent_induction && !self.dataflow_induction
                && args.iter().all(|t| t.variables().is_disjoint(&conclusion_variables));
            let prune_dataflow = self.dataflow_induction && self.rules.iter()
                .filter(|r| r.lhs().root_symbol() == Some(symbol))
                .any(|r| positions_with_subterms(r.rhs()).iter()
                    .any(|(_, t)| t.root_symbol() == Some(symbol)));
            let phi = cs
                .iter()
                .enumerate()
                .filter(|(j, _)| *j != i && !independent)
                .filter(|(_, c)| !prune_dataflow || induction_dataflow_premise(args, q, c, &self.defined)
                    || (self.independent_induction && q.variables().is_empty()
                        && matches!(c, Constraint::Rewrite(Term::App { args: producer_args, .. }, rhs)
                            if !producer_args.is_empty() && !rhs.variables().is_disjoint(
                                &args.iter().flat_map(Term::variables).collect()))))
                .map(|(_, c)| c.clone())
                .collect::<Vec<_>>();
            // A smaller conjunction can yield a useful stronger induction
            // hypothesis even when the same predicate has already occurred.
            // Require strict descent in premise count; do not repeatedly
            // unfold an unchanged hypothesis. The emitted induction still
            // proves every rule case with its explicitly selected conjuncts.
            if let Some(previous) = existing_induction_premises {
                if !prune_dataflow || phi.len() + 1 >= previous {
                    continue;
                }
            }
            let rules = self
                .rules
                .iter()
                .filter(|r| r.lhs().root_symbol() == Some(symbol))
                .cloned()
                .collect::<Vec<_>>();
            let mut entries = String::new();
            let mut leaves = Vec::new();
            for rule in rules {
                let rule = self.renamed(&rule);
                let Term::App { args: ls, .. } = rule.lhs() else {
                    return None;
                };
                let sigma = xs
                    .iter()
                    .cloned()
                    .zip(ls.iter().cloned())
                    .collect::<Subst>();
                let mut next = vec![Constraint::Rewrite(
                    rule.rhs().clone(),
                    apply_substitution(q, &sigma),
                )];
                next.extend(phi.iter().map(|p| p.subst(&sigma)));
                let mut rys = String::new();
                for (_, r) in positions_with_subterms(rule.rhs()) {
                    let Term::App {
                        symbol: f,
                        args: rs,
                    } = r
                    else {
                        continue;
                    };
                    if f != symbol
                        || rs.len() != xs.len()
                        || !rs.iter().all(|t| self.constructor_term(t))
                    {
                        continue;
                    }
                    let mu = xs
                        .iter()
                        .cloned()
                        .zip(rs.iter().cloned())
                        .collect::<Subst>();
                    let mut pre = vec![Constraint::Rewrite(r.clone(), apply_substitution(q, &mu))];
                    pre.extend(phi.iter().map(|p| p.subst(&mu)));
                    let ih = Constraint::Implication(pre, Box::new(con.subst(&mu)));
                    let original = goal(&phi, &con).variables();
                    let extras = original
                        .difference(&xs.iter().cloned().collect())
                        .cloned()
                        .collect::<Vec<_>>();
                    let bind = extras
                        .iter()
                        .map(|x| (x.clone(), Term::Var(self.fresh())))
                        .collect::<Subst>();
                    let ys = bind
                        .values()
                        .filter_map(|t| {
                            if let Term::Var(x) = t {
                                Some(x.clone())
                            } else {
                                None
                            }
                        })
                        .collect::<Vec<_>>();
                    let quantified = Constraint::All(ys, Box::new(ih.subst(&bind)));
                    rys.push_str(&format!(
                        "<subtermVarEntry>{}{}</subtermVarEntry>",
                        term_xml(r),
                        extras
                            .iter()
                            .map(|x| term_xml(&Term::Var(x.clone())))
                            .collect::<String>()
                    ));
                    // The checker alpha-normalizes the quantified variables,
                    // so fresh binders may differ from the rys source names.
                    next.push(quantified);
                }
                let out = con.subst(&sigma);
                let (p, ls) = self.prove(next.clone(), out.clone(), depth + 1)?;
                leaves.extend(ls);
                entries.push_str(&format!("<ruleConstraintProof>{}<subtermVarEntries>{rys}</subtermVarEntries>{}{p}</ruleConstraintProof>",rule_xml(&rule),goal(&next,&out).xml()));
            }
            return Some((
                wrap(format!(
                    "<induction>{}<conjuncts>{}</conjuncts><ruleConstraintProofs>{entries}</ruleConstraintProofs></induction>",
                    c.xml(),
                    phi.iter().map(Constraint::xml).collect::<String>()
                )),
                leaves,
            ));
        }
        // An IH can become unusable after constructor equations change the
        // shape of the goal (for example, exposing a successor). Drop that
        // hypothesis and re-induct on the new goal, rather than treating the
        // predicate name as permanently visited. This is a stronger goal and
        // is explicitly certified by Delete_Condition. The shared node/depth
        // and deadline bounds still prevent unproductive re-induction loops.
        if self.reinduct > 0 && cs.iter().any(|c| matches!(c, Constraint::All(..))) {
            let next = cs.iter().filter(|c| !matches!(c, Constraint::All(..))).cloned().collect::<Vec<_>>();
            self.reinduct -= 1;
            let result = self.prove(next.clone(), con.clone(), depth + 1);
            self.reinduct += 1;
            let (proof, leaves) = result?;
            return Some((wrap(format!("<deleteCondition>{}{proof}</deleteCondition>", goal(&next, &con).xml())), leaves));
        }
        if std::env::var_os("FERRUM_CONDITIONAL_TRACE").is_some() {
            eprintln!(
                "conditional calculus open depth={depth}: {:?}",
                goal(&cs, &con)
            );
        }
        // An open branch need not invalidate the induction surrounding it.
        // Drop this branch's premises and let the shared arithmetic query
        // discharge its stronger, unconditional conclusion. Doing this only
        // at the outermost obligation loses all successfully decomposed
        // constructor cases and instantiated induction hypotheses.
        let Constraint::Order(strict, lhs, rhs) = &con else {
            return None;
        };
        Some((
            wrap(format!(
                "<deleteCondition>{}{}</deleteCondition>",
                con.xml(),
                wrap("<final/>".to_owned())
            )),
            vec![(None, *strict, lhs.clone(), rhs.clone())],
        ))
    }
}

fn match_constraint(
    pattern: &Constraint,
    live: &Constraint,
    bind: &[Variable],
    sigma: &mut Subst,
) -> bool {
    fn mt(p: &Term, t: &Term, bind: &[Variable], s: &mut Subst) -> bool {
        match (p, t) {
            (Term::Var(x), _) if bind.contains(x) => match s.get(x) {
                Some(v) => v == t,
                None => {
                    s.insert(x.clone(), t.clone());
                    true
                }
            },
            (Term::Var(x), Term::Var(y)) => x == y,
            (Term::App { symbol: f, args: a }, Term::App { symbol: g, args: b }) => {
                f == g && a.len() == b.len() && a.iter().zip(b).all(|(p, t)| mt(p, t, bind, s))
            }
            _ => false,
        }
    }
    match (pattern, live) {
        (Constraint::Rewrite(a, b), Constraint::Rewrite(c, d)) => {
            mt(a, c, bind, sigma) && mt(b, d, bind, sigma)
        }
        (Constraint::Order(s, a, b), Constraint::Order(t, c, d)) if s == t => {
            mt(a, c, bind, sigma) && mt(b, d, bind, sigma)
        }
        (Constraint::Implication(ps, p), Constraint::Implication(qs, q)) => {
            if ps.len() != qs.len() { return false; }
            let mut ordered = sigma.clone();
            if ps.iter().zip(qs).all(|(p, q)| match_constraint(p, q, bind, &mut ordered))
                && match_constraint(p, q, bind, &mut ordered)
            {
                *sigma = ordered;
                return true;
            }
            // Conjunct order has no logical significance (CeTA's
            // check_subsumes uses premise sets). Preserve the cheap ordered
            // path, then match a permutation with shared substitutions.
            // A small work bound prevents symmetric premises from producing
            // an unbounded factorial search; failure merely loses a hint.
            fn premises(ps: &[Constraint], qs: &[Constraint], bind: &[Variable],
                used: &mut [bool], sigma: &Subst, budget: &mut usize) -> Option<Subst>
            {
                let Some((p, tail)) = ps.split_first() else { return Some(sigma.clone()); };
                for (i, q) in qs.iter().enumerate() {
                    if used[i] { continue; }
                    if *budget == 0 { return None; }
                    *budget -= 1;
                    let mut next = sigma.clone();
                    if !match_constraint(p, q, bind, &mut next) { continue; }
                    used[i] = true;
                    let result = premises(tail, qs, bind, used, &next, budget);
                    used[i] = false;
                    if result.is_some() { return result; }
                }
                None
            }
            let mut candidate = sigma.clone();
            if !match_constraint(p, q, bind, &mut candidate) { return false; }
            if let Some(candidate) = premises(ps, qs, bind, &mut vec![false; qs.len()],
                &candidate, &mut 256)
            {
                *sigma = candidate;
                true
            } else { false }
        }
        (Constraint::All(xs, p), Constraint::All(ys, q)) if xs.len() == ys.len() => {
            // Nested induction hypotheses can themselves be premises. Match
            // them modulo bound-variable renaming, without allowing a local
            // binder to escape into the outer instantiation substitution.
            let rename = xs.iter().cloned().zip(ys.iter().cloned().map(Term::Var)).collect();
            let mut candidate = sigma.clone();
            if match_constraint(&p.subst(&rename), q, bind, &mut candidate)
                && candidate.values().all(|t| t.variables().iter().all(|v| !ys.contains(v)))
            {
                *sigma = candidate;
                true
            } else {
                false
            }
        }
        _ => false,
    }
}

pub struct ConditionalPolynomialProcessor {
    pub max_coefficient: i64,
    pub degree: usize,
    pub before: usize,
    pub after: usize,
    pub squares: bool,
    pub reinduct: usize,
    /// Zero retains the established portfolio. 1..7 selects a generic
    /// induction shape, allowing guidance to budget each SMT query separately.
    pub induction: usize,
    pub deadline: Option<Instant>,
}

impl WorklistProcessor for ConditionalPolynomialProcessor {
    fn name(&self) -> &'static str {
        "conditional-poly"
    }
    fn apply(&self, state: &ProblemState) -> ProcessorResult {
        let ProblemState::DependencyPairs(problem) = state else {
            return ProcessorResult::Inapplicable;
        };
        let proof = if self.induction == 0 {
            synthesize_degree(problem, self.max_coefficient, self.degree, self.before, self.after, self.squares, self.reinduct, self.deadline)
        } else if let Some(&(independent, dataflow, split)) = [
            (false, false, false), (true, false, false), (false, true, false),
            (false, false, true), (true, false, true), (false, true, true), (true, true, true),
        ].get(self.induction - 1) {
            synthesize_degree_context_encoding(problem, self.max_coefficient, self.degree, self.before, self.after,
                self.squares, self.reinduct, independent, dataflow, split, true, self.deadline)
        } else { None };
        match proof {
            Some(processor) => processor.apply(state),
            None if self.deadline.is_some_and(|d| Instant::now() >= d) => ProcessorResult::TimedOut,
            None => ProcessorResult::Inapplicable,
        }
    }
}

#[cfg(test)]
fn synthesize(
    problem: &DpProblemState,
    bound: i64,
    deadline: Option<Instant>,
) -> Option<ExactGeneralRedPairProcessor> {
    synthesize_degree(problem, bound, 1, 1, 0, false, 0, deadline)
}

fn synthesize_degree(
    problem: &DpProblemState,
    bound: i64,
    degree: usize,
    before: usize,
    after: usize,
    squares: bool,
    reinduct: usize,
    deadline: Option<Instant>,
) -> Option<ExactGeneralRedPairProcessor> {
    // Preserve the ordinary context-rich derivation first. A failed proof
    // shape can then try an independent-predicate induction, still within
    // the same deadline and with one joint arithmetic query per shape.
    synthesize_degree_context(problem, bound, degree, before, after, squares, reinduct, false, false, false, deadline)
        .or_else(|| {
            if deadline.is_some_and(|d| Instant::now() >= d) { return None; }
            synthesize_degree_context(problem, bound, degree, before, after, squares, reinduct, true, false, false, deadline)
        })
        .or_else(|| {
            if deadline.is_some_and(|d| Instant::now() >= d) { return None; }
            synthesize_degree_context(problem, bound, degree, before, after, squares, reinduct, false, true, false, deadline)
        })
        .or_else(|| {
            // CeTA permits distinct strict and bounded pair sets, yielding
            // two independently necessary residual obligations. Preserve the
            // merged search first, then synthesize this more general split.
            for (independent, dataflow) in [(false, false), (true, false), (false, true), (true, true)] {
                if deadline.is_some_and(|d| Instant::now() >= d) { return None; }
                if let Some(proof) = synthesize_degree_context(problem, bound, degree,
                    before, after, squares, reinduct, independent, dataflow, true, deadline) {
                    return Some(proof);
                }
            }
            None
        })
}

/// Choose a stronger induction obligation, never assume a missing premise.
/// For a predicate with a ground result, retain producers of its arguments,
/// not unrelated tests or nested IHs. For a computed result, retain its
/// consumers and IHs. Already derived arithmetic facts remain available.
/// CeTA checks the selected conjuncts as a subset and validates every rule
/// case of the stronger claim. Non-recursive dispatch keeps its full context.
fn induction_dataflow_premise(arguments: &[Term], result: &Term, premise: &Constraint, defined: &BTreeSet<String>) -> bool {
    let outputs = result.variables();
    if matches!(premise, Constraint::Order(..)) { return true; }
    if matches!(premise, Constraint::All(..)) { return !outputs.is_empty(); }
    let Constraint::Rewrite(lhs, rhs) = premise else { return false; };
    if outputs.is_empty() {
        let inputs = arguments.iter().flat_map(Term::variables).collect::<BTreeSet<_>>();
        !rhs.variables().is_disjoint(&inputs)
            && lhs.root_symbol().is_some_and(|s| defined.contains(s.as_str()))
    } else {
        !lhs.variables().is_disjoint(&outputs)
    }
}

fn synthesize_degree_context(
    problem: &DpProblemState, bound: i64, degree: usize, before: usize,
    after: usize, squares: bool, reinduct: usize, independent_induction: bool,
    dataflow_induction: bool,
    split_bounds: bool,
    deadline: Option<Instant>,
) -> Option<ExactGeneralRedPairProcessor> {
    // Preserve established automatic model selection. Explicit induction
    // guidance opts into the equivalent finite-coefficient encoding.
    synthesize_degree_context_encoding(problem, bound, degree, before, after, squares,
        reinduct, independent_induction, dataflow_induction, split_bounds, false, deadline)
}

fn synthesize_degree_context_encoding(
    problem: &DpProblemState, bound: i64, degree: usize, before: usize,
    after: usize, squares: bool, reinduct: usize, independent_induction: bool,
    dataflow_induction: bool, split_bounds: bool, linear_encoding: bool,
    deadline: Option<Instant>,
) -> Option<ExactGeneralRedPairProcessor> {
    if !matches!(problem.stats.problem, DpProblemContext::Ordinary)
        || !problem.stats.normal_form_substitutions
        || !problem.stats.minimal
        || !problem.stats.strict_rules.is_empty()
        || !problem.stats.weak_pairs.is_empty()
        || problem.pairs.is_empty()
        || problem.pairs.len() > 16
        || !(1..=16).contains(&bound)
        || !(1..=2).contains(&degree)
        || before > 3 || after > 3 || before + after > 3
        || problem.pairs.len().checked_pow((before + after) as u32 + 1)? > 4096
    {
        return None;
    }
    // Synthesize for the same live R that the general reduction-pair checker
    // uses. A certified usable-rule step may retain the parent TRS for proof
    // reconstruction while reducing active R (including to the empty set).
    let rules = problem.stats.active_rules.as_deref().unwrap_or(problem.trs.rules());
    let q = problem.innermost_lhss.as_deref()?;
    if rules.iter().any(|r| {
        r.lhs().root_symbol().is_none()
            || !r.rhs().variables().is_subset(&r.lhs().variables())
            || term_is_q_normal(r.lhs(), q)
    }) {
        return None;
    }
    let defined = rules
        .iter()
        .filter_map(|r| r.lhs().root_symbol().map(|s| s.as_str().to_owned()))
        .collect::<BTreeSet<_>>();
    let pairs = problem
        .pairs
        .iter()
        .map(|p| p.as_rule())
        .collect::<Vec<_>>();
    if pairs.iter().any(|p| {
        p.lhs().root_symbol().is_none()
            || p.rhs()
                .root_symbol()
                .is_none_or(|s| defined.contains(s.as_str()))
            || !p.rhs().variables().is_subset(&p.lhs().variables())
    }) {
        return None;
    }
    let reserved = rules
        .iter()
        .chain(&pairs)
        .flat_map(|r| {
            r.lhs()
                .variables()
                .union(&r.rhs().variables())
                .cloned()
                .collect::<Vec<_>>()
        })
        .collect();
    let mut calculus = Calculus {
        rules,
        defined: defined.clone(),
        reserved,
        fresh: 0,
        nodes: 0,
        reinduct,
        independent_induction,
        dataflow_induction,
        deadline,
    };
    let mut signature = BTreeMap::new();
    let mut positive = BTreeSet::new();
    let mut collect = |term: &Term, pos: bool| {
        for (_, t) in positions_with_subterms(term) {
            if let Term::App { symbol, args } = t {
                signature.insert(symbol.as_str().to_owned(), args.len());
                if pos {
                    positive.insert(symbol.as_str().to_owned());
                }
            }
        }
    };
    for r in rules {
        collect(r.lhs(), true);
        collect(r.rhs(), true);
    }
    for t in q {
        collect(t, true);
    }
    for p in &pairs {
        for t in [p.lhs(), p.rhs()] {
            collect(t, false);
            if let Term::App { args, .. } = t {
                for a in args {
                    collect(a, true);
                }
            }
        }
    }
    let constant = (0..)
        .map(|i| format!("__conditional_bound_{i}"))
        .find(|s| !signature.contains_key(s))?;
    signature.insert(constant.clone(), 0);
    let constant_term = Term::app(constant.clone(), vec![]);
    let terms = pairs
        .iter()
        .map(|r| r.rhs())
        .chain(rules.iter().map(|r| r.rhs()))
        .flat_map(positions_with_subterms)
        .map(|(_, t)| t.clone())
        .collect::<BTreeSet<_>>()
        .into_iter()
        .collect::<Vec<_>>();
    // Each record carries its live pair index and condition kind (weak,
    // strict, bound). All predecessor sequences are covered, a conservative
    // superset of the checker's estimated dependency graph.
    let mut records = Vec::new();
    for (index, pair) in pairs.iter().enumerate() {
        for sequence_index in 0..pairs.len().pow((before + after) as u32) {
            let mut number = sequence_index;
            let mut sequence = Vec::new();
            for _ in 0..before {
                sequence.push(calculus.renamed(&pairs[number % pairs.len()]));
                number /= pairs.len();
            }
            let pair = calculus.renamed(pair);
            sequence.push(pair.clone());
            for _ in 0..after {
                sequence.push(calculus.renamed(&pairs[number % pairs.len()]));
                number /= pairs.len();
            }
            for kind in 0..3 {
                if deadline.is_some_and(|d| Instant::now() >= d) { return None; }
                let con = Constraint::Order(
                    kind == 1,
                    pair.lhs().clone(),
                    if kind == 2 {
                        constant_term.clone()
                    } else {
                        pair.rhs().clone()
                    },
                );
                let premises = sequence.windows(2).map(|w| Constraint::Rewrite(w[0].rhs().clone(), w[1].lhs().clone())).collect::<Vec<_>>();
                let initial = goal(&premises, &con);
                calculus.nodes = 0;
                let (proof, leaves) =
                    calculus.prove(premises, con.clone(), 0).unwrap_or_else(|| {
                        // A stronger unconditional obligation is always a legitimate
                        // fallback proof shape; its arithmetic still has to be solved.
                        let Constraint::Order(s, a, b) = &con else {
                            unreachable!()
                        };
                        (
                            wrap(format!(
                                "<deleteCondition>{}{}</deleteCondition>",
                                con.xml(),
                                wrap("<final/>".to_owned())
                            )),
                            vec![(None, *s, a.clone(), b.clone())],
                        )
                    });
                records.push((index,kind,format!("<condition>{}<dpSequence><rules>{}</rules></dpSequence>{proof}</condition>",initial.xml(),sequence.iter().map(rule_xml).collect::<String>()),leaves));
            }
        }
    }
    let parameters = signature
        .iter()
        .enumerate()
        .map(|(i, (s, n))| {
            (
                s.clone(),
                (0..basis(*n, degree).len()).map(|j| format!("cp_{i}_{j}")).collect::<Vec<_>>(),
            )
        })
        .collect::<BTreeMap<_, _>>();
    let mut encoder = PolynomialEncoder::new(&parameters);
    if linear_encoding && degree == 1 && bound <= 2 {
        encoder.finite_parameters = parameters.values().flatten().map(|p| (p.clone(), bound)).collect();
    }
    let mut script = "(set-logic QF_NIA)\n(set-option :produce-models true)\n".to_owned();
    for (s, ps) in &parameters {
        for (index, p) in ps.iter().enumerate() {
            script.push_str(&format!(
                "(declare-fun {p} () Int)\n(assert (and (>= {p} {}) (<= {p} {bound})))\n",
                if positive.contains(s) { 0 } else { -bound }
            ));
            // The focused square lane uses affine interpretations on the
            // rewrite signature and squared affine-free forms on DP roots.
            // This structural template avoids high-degree constructor-term
            // expansions; degree=2 without squares retains the wider search.
            if squares && positive.contains(s) && index > signature[s] {
                script.push_str(&format!("(assert (= {p} 0))\n"));
                encoder.zero_parameters.insert(p.clone());
            }
        }
    }
    // CeTA Poly_Order.check_quadratic_ge_const recognizes an exact square
    // of a homogeneous linear form plus a constant, even with mixed signs.
    // Synthesize the form jointly, rather than enumerating sign patterns.
    if degree == 2 {
        for (s, ps) in &parameters {
            let n = signature[s];
            if n == 0 { continue; }
            let flag = format!("{}_square", ps[0]);
            script.push_str(&format!("(declare-fun {flag} () Bool)\n"));
            if squares && !positive.contains(s) { script.push_str(&format!("(assert {flag})\n")); }
            for i in 0..n {
                script.push_str(&format!("(declare-fun {}_root_{i} () Int)\n(assert (and (>= {}_root_{i} -{bound}) (<= {}_root_{i} {bound})))\n", ps[0], ps[0], ps[0]));
            }
            let mut checks = Vec::new();
            for (m, c) in basis(n, 2).iter().zip(ps).skip(1) {
                checks.push(if m.len() == 1 { format!("(= {c} 0)") } else {
                    format!("(= {c} (* {} {}_root_{} {}_root_{}))", if m[0] == m[1] {1} else {2}, ps[0], m[0], ps[0], m[1])
                });
            }
            checks.push(format!("(or {})", (0..n).map(|i| format!("(not (= {}_root_{i} 0))", ps[0])).collect::<Vec<_>>().join(" ")));
            script.push_str(&format!("(assert (=> {flag} (and {})))\n", checks.join(" ")));
        }
    }
    for i in 0..pairs.len() {
        script.push_str(&format!(
            "(declare-fun delete_{i} () Int)\n(assert (or (= delete_{i} 0) (= delete_{i} 1)))\n"
        ));
        if split_bounds {
            script.push_str(&format!(
                "(declare-fun bound_{i} () Int)\n(assert (or (= bound_{i} 0) (= bound_{i} 1)))\n"
            ));
        }
    }
    script.push_str(&format!(
        "(assert (or {}))\n",
        (0..pairs.len())
            .map(|i| format!("(= delete_{i} 1)"))
            .collect::<Vec<_>>()
            .join(" ")
    ));
    if split_bounds {
        script.push_str(&format!("(assert (or {}))\n", (0..pairs.len())
            .map(|i| format!("(= bound_{i} 1)")).collect::<Vec<_>>().join(" ")));
    }
    // Signed usable-rule reachability is solved jointly with coefficients.
    // Decreasing positions require REVERSED rule orientation, not forward
    // orientation. This is usable_rules_gen1/2, not ordinary usable rules.
    for i in 0..terms.len() {
        for b in 0..2 {
            script.push_str(&format!("(declare-fun ur_{i}_{b} () Bool)\n"));
        }
    }
    for p in &pairs {
        let i = terms.iter().position(|t| t == p.rhs())?;
        script.push_str(&format!("(assert ur_{i}_1)\n"));
    }
    for (i, t) in terms.iter().enumerate() {
        let Term::App { symbol, args } = t else {
            continue;
        };
        for b in 0..2 {
            for r in rules
                .iter()
                .filter(|r| r.lhs().root_symbol() == Some(symbol))
            {
                let j = terms.iter().position(|t| t == r.rhs())?;
                script.push_str(&format!("(assert (=> ur_{i}_{b} ur_{j}_{b}))\n"));
                let (l, r) = if b == 1 {
                    (r.lhs(), r.rhs())
                } else {
                    (r.rhs(), r.lhs())
                };
                let formula = leaf_formula(&(None, false, l.clone(), r.clone()), &mut encoder, false)?;
                script.push_str(&encoder.take_definitions());
                script.push_str(&format!(
                    "(assert (=> ur_{i}_{b} {}))\n",
                    formula
                ));
            }
            for (a, t) in args.iter().enumerate() {
                let j = terms.iter().position(|x| x == t)?;
                let coefficients = basis(args.len(), degree).iter().zip(&parameters[symbol.as_str()])
                    .filter(|(m, _)| m.contains(&a)).map(|(_, c)| c).collect::<Vec<_>>();
                let sign = |op: &str| format!("(or {})", coefficients.iter().map(|c| format!("({op} {c} 0)")).collect::<Vec<_>>().join(" "));
                let pos = sign(">");
                let neg = sign("<");
                // Mixed signs are Wild: require both rule directions, never
                // guess monotonicity from one selected coefficient.
                script.push_str(&format!("(assert (=> (and ur_{i}_{b} {pos}) ur_{j}_{b}))\n(assert (=> (and ur_{i}_{b} {neg}) ur_{j}_{}))\n",1-b));
            }
        }
    }
    for (i, kind, _, leaves) in &records {
        for leaf in leaves {
            let formula = leaf_formula(leaf, &mut encoder, true)?;
            script.push_str(&encoder.take_definitions());
            script.push_str(&format!(
                "(assert {})\n",
                if *kind == 0 {
                    formula
                } else {
                    format!("(=> (= {}_{i} 1) {formula})", if *kind == 2 && split_bounds { "bound" } else { "delete" })
                }
            ));
        }
    }
    script.push_str("(check-sat)\n(get-model)\n");
    if let Some(path) = std::env::var_os("FERRUM_CONDITIONAL_TRACE") {
        let path = std::path::PathBuf::from(path);
        let _ = std::fs::write(path.with_extension("smt2"), &script);
        let shape = if dataflow_induction { "dataflow" } else if independent_induction { "independent" } else { "context" };
        let _ = std::fs::write(path.with_extension(format!("{shape}.smt2")), &script);
        let records = records
            .iter()
            .map(|(i, k, xml, leaves)| {
                serde_json::json!({
                    "pair":i,"kind":k,"proof":xml,
                    "leaves":leaves.iter().map(|(prem,s,a,b)|serde_json::json!({
                        "strict":s,"lhs":term_xml(a),"rhs":term_xml(b),
                        "premise":prem.as_ref().map(|(u,v)|vec![term_xml(u),term_xml(v)])
                    })).collect::<Vec<_>>()
                })
            })
            .collect::<Vec<_>>();
        let encoded = serde_json::to_vec_pretty(&records).unwrap_or_default();
        let _ = std::fs::write(path.with_extension("json"), &encoded);
        let _ = std::fs::write(path.with_extension(format!("{shape}.json")), &encoded);
    }
    let output = run_smt_script(&script, &problem.options, deadline)?;
    if let Some(path) = std::env::var_os("FERRUM_CONDITIONAL_TRACE") {
        let _ = std::fs::write(std::path::PathBuf::from(path).with_extension("model"), &output);
    }
    let values = parse_smt_values(&output)?;
    let selected = (0..pairs.len())
        .filter(|i| values.get(&format!("delete_{i}")) == Some(&1))
        .collect::<Vec<_>>();
    if selected.is_empty() {
        return None;
    }
    let bounded = if split_bounds { (0..pairs.len())
        .filter(|i| values.get(&format!("bound_{i}")) == Some(&1))
        .collect::<Vec<_>>() } else { selected.clone() };
    if bounded.is_empty() { return None; }
    let model = parameters
        .iter()
        .map(|(s, ps)| {
            Some((
                s.clone(),
                ps.iter()
                    .map(|p| values.get(p).copied())
                    .collect::<Option<Vec<_>>>()?,
            ))
        })
        .collect::<Option<BTreeMap<_, _>>>()?;
    if model.iter().any(|(s, cs)| {
        cs.iter()
            .any(|c| *c < if positive.contains(s) { 0 } else { -bound } || *c > bound)
    }) {
        return None;
    }
    // Exact checked arithmetic, independent of the SMT encoding and model.
    let usable_ok = check_signed_usable(&pairs, rules, &model);
    let bad_record = records.iter().find(|(i, k, _, ls)| {
            (*k == 0 || if *k == 2 { bounded.contains(i) } else { selected.contains(i) })
                && ls.iter().any(|l| !check_leaf(l, &model))
        });
    if !usable_ok || bad_record.is_some() {
        if std::env::var_os("FERRUM_CONDITIONAL_TRACE").is_some() {
            eprintln!("conditional model rejected: usable={usable_ok}, record={:?}", bad_record.map(|(i,k,_,_)| (*i,*k)));
        }
        return None;
    }
    let mut interpretation=format!("<interpretation><type><polynomial><domain><naturals/></domain><degree>{degree}</degree></polynomial></type>");
    for (s, cs) in &model {
        interpretation.push_str("<interpret>");
        crate::cert::write_symbol_cpf3(&mut interpretation, s, 0);
        interpretation.push_str(&format!(
            "<arity>{}</arity><sum><integer>{}</integer>",
            signature[s],
            cs[0]
        ));
        for (m, c) in basis(signature[s], degree).iter().zip(cs).skip(1) {
            interpretation.push_str(&format!("<product><integer>{c}</integer>"));
            for i in m { interpretation.push_str(&format!("<variable>{}</variable>", i + 1)); }
            interpretation.push_str("</product>");
        }
        interpretation.push_str("</sum></interpret>");
    }
    interpretation.push_str("</interpretation>");
    let requested = selected
        .iter()
        .map(|i| rule_xml(&pairs[*i]))
        .collect::<String>();
    let requested_bound = bounded.iter().map(|i| rule_xml(&pairs[*i])).collect::<String>();
    let mut name = String::new();
    crate::cert::write_symbol_cpf3(&mut name, &constant, 0);
    let conditions = records
        .into_iter()
        .filter(|(i, k, _, _)| *k == 0 || if *k == 2 { bounded.contains(i) } else { selected.contains(i) })
        .map(|(_, _, xml, _)| xml)
        .collect::<String>();
    let payload_xml = format!(
        "{interpretation}<strict><rules>{requested}</rules></strict><bound><rules>{requested_bound}</rules></bound><condRedPairProof>{name}<before>{before}</before><after>{after}</after><conditions>{conditions}</conditions></condRedPairProof>"
    );
    Some(ExactGeneralRedPairProcessor {
        payload_xml,
        strict_indices: selected.clone(),
        merge: selected == bounded,
        bound_indices: bounded,
        source_dp_input_xml: None,
    })
}

fn check_signed_usable(
    pairs: &[RewriteRule],
    rules: &[RewriteRule],
    model: &BTreeMap<String, Vec<i64>>,
) -> bool {
    let mut work = pairs
        .iter()
        .map(|p| (p.rhs().clone(), true))
        .collect::<Vec<_>>();
    let mut seen = BTreeSet::new();
    while let Some((t, forward)) = work.pop() {
        if !seen.insert((t.clone(), forward)) {
            continue;
        }
        let Term::App { symbol, args } = t else {
            continue;
        };
        for r in rules
            .iter()
            .filter(|r| r.lhs().root_symbol() == Some(&symbol))
        {
            let (a, b) = if forward {
                (r.lhs(), r.rhs())
            } else {
                (r.rhs(), r.lhs())
            };
            if !check_leaf_with_squares(&(None, false, a.clone(), b.clone()), model, false) {
                return false;
            }
            work.push((r.rhs().clone(), forward));
        }
        let Some(cs) = model.get(symbol.as_str()) else {
            return false;
        };
        let Some(monomials) = inferred_basis(args.len(), cs.len()) else { return false };
        for (i, t) in args.into_iter().enumerate() {
            let coefficients = monomials.iter().zip(cs).filter(|(m, _)| m.contains(&i)).map(|(_, c)| *c).collect::<Vec<_>>();
            let positive = coefficients.iter().any(|c| *c > 0);
            let negative = coefficients.iter().any(|c| *c < 0);
            if positive { work.push((t.clone(), forward)); }
            if negative { work.push((t, !forward)); }
        }
    }
    true
}

fn basis(arity: usize, degree: usize) -> Vec<Vec<usize>> {
    let mut out = vec![vec![]];
    out.extend((0..arity).map(|i| vec![i]));
    if degree == 2 {
        for i in 0..arity { for j in i..arity { out.push(vec![i, j]); } }
    }
    out
}

fn inferred_basis(arity: usize, coefficients: usize) -> Option<Vec<Vec<usize>>> {
    let degree = if coefficients == arity + 1 { 1 } else { 2 };
    let out = basis(arity, degree);
    (out.len() == coefficients).then_some(out)
}

type Monomial = Vec<String>;
type Symbolic = BTreeMap<Monomial, String>;

/// Share term expansions and coefficient expressions across every obligation
/// in the single query. Named SMT definitions form a DAG, not duplicated trees.
struct PolynomialEncoder<'a> {
    parameters: &'a BTreeMap<String, Vec<String>>,
    terms: BTreeMap<Term, Symbolic>,
    expressions: BTreeMap<String, String>,
    definitions: String,
    zero_parameters: BTreeSet<String>,
    finite_parameters: BTreeMap<String, i64>,
}

impl<'a> PolynomialEncoder<'a> {
    fn new(parameters: &'a BTreeMap<String, Vec<String>>) -> Self {
        Self { parameters, terms: BTreeMap::new(), expressions: BTreeMap::new(), definitions: String::new(), zero_parameters: BTreeSet::new(), finite_parameters: BTreeMap::new() }
    }
    fn take_definitions(&mut self) -> String { std::mem::take(&mut self.definitions) }
    fn arithmetic(&mut self, op: &str, a: &str, b: &str) -> Option<String> {
        if op == "*" && (a == "0" || b == "0") { return Some("0".into()); }
        if (op == "+" && b == "0") || (op == "*" && b == "1") || (op == "-" && b == "0") { return Some(a.into()); }
        if (op == "+" && a == "0") || (op == "*" && a == "1") { return Some(b.into()); }
        if op == "-" && a == b { return Some("0".into()); }
        let (a, b) = if op != "-" && a > b { (b, a) } else { (a, b) };
        // Each linear term composition multiplies a bounded interpretation
        // parameter by a previously composed coefficient. Encode its finite
        // signed range as constant multiplication choices, avoiding NIA.
        let finite = if op == "*" {
            self.finite_parameters.get(a).map(|n| (a,b,*n))
                .or_else(|| self.finite_parameters.get(b).map(|n| (b,a,*n)))
        } else { None };
        let expression = if let Some((parameter, value, bound)) = finite {
            let mut result = format!("(* {bound} {value})");
            for n in (-bound..bound).rev() {
                result = format!("(ite (= {parameter} {n}) (* {n} {value}) {result})");
            }
            result
        } else { format!("({op} {a} {b})") };
        if let Some(name) = self.expressions.get(&expression) { return Some(name.clone()); }
        if self.expressions.len() >= 100_000 { return None; }
        let name = format!("cp_dag_{}", self.expressions.len());
        self.definitions.push_str(&format!("(define-fun {name} () Int {expression})\n"));
        self.expressions.insert(expression, name.clone());
        Some(name)
    }
    fn product(&mut self, a: &Symbolic, b: &Symbolic) -> Option<Symbolic> {
        let mut out = Symbolic::new();
        for (ma, ca) in a { for (mb, cb) in b {
            let mut m = ma.clone(); m.extend(mb.iter().cloned()); m.sort();
            if m.len() > 64 { return None; }
            let product = self.arithmetic("*", ca, cb)?;
            let old = out.get(&m).map_or("0", String::as_str);
            let sum = self.arithmetic("+", old, &product)?;
            out.insert(m, sum);
            if out.len() > 4096 { return None; }
        } }
        Some(out)
    }
    fn term(&mut self, t: &Term) -> Option<Symbolic> {
        if let Some(cached) = self.terms.get(t) { return Some(cached.clone()); }
        let result = match t {
            Term::Var(v) => BTreeMap::from([(vec![v.as_str().to_owned()], "1".to_owned())]),
            Term::App { symbol, args } => {
                let ps = self.parameters.get(symbol.as_str())?.clone();
                let monomials = inferred_basis(args.len(), ps.len())?;
                let children = args.iter().map(|a| self.term(a)).collect::<Option<Vec<_>>>()?;
                let mut out = Symbolic::new();
                for (m, c) in monomials.iter().zip(ps) {
                    if self.zero_parameters.contains(&c) { continue; }
                    let mut part = BTreeMap::from([(vec![], c)]);
                    for i in m { part = self.product(&part, &children[*i])?; }
                    for (v, x) in part {
                        let old = out.get(&v).map_or("0", String::as_str);
                        let sum = self.arithmetic("+", old, &x)?;
                        out.insert(v, sum);
                    }
                    if out.len() > 4096 { return None; }
                }
                out
            }
        };
        self.terms.insert(t.clone(), result.clone());
        Some(result)
    }
    fn difference(&mut self, a: &Term, b: &Term) -> Option<Symbolic> {
        let a = self.term(a)?; let b = self.term(b)?;
        a.keys().chain(b.keys()).cloned().collect::<BTreeSet<_>>().into_iter()
            .map(|v| Some((v.clone(), self.arithmetic("-", a.get(&v).map_or("0", String::as_str), b.get(&v).map_or("0", String::as_str))?))).collect()
    }
}

fn leaf_formula(l: &Leaf, p: &mut PolynomialEncoder<'_>, allow_square: bool) -> Option<String> {
    let (premise, strict, a, b) = l;
    let d = p.difference(a, b)?;
    let ge = |d: &Symbolic, gap: i32| {
        format!(
            "(and {})",
            d.keys()
                .cloned()
                .chain(std::iter::once(Vec::new()))
                .collect::<BTreeSet<_>>()
                .iter()
                .map(|v| format!(
                    "(>= {} {})",
                    d.get(v).map_or("0", String::as_str),
                    if v.is_empty() { gap } else { 0 }
                ))
                .collect::<Vec<_>>()
                .join(" ")
        )
    };
    let mut direct = ge(&d, if *strict { 1 } else { 0 });
    if !strict && allow_square {
        if let Term::App { symbol, args } = a {
            let ps = &p.parameters[symbol.as_str()];
            if !args.is_empty() && ps.len() == basis(args.len(), 2).len() {
                let rhs = p.term(b)?;
                let constant = rhs.get(&vec![]).map_or("0", String::as_str);
                let zeros = rhs.iter().filter(|(m, _)| !m.is_empty())
                    .map(|(_, c)| format!("(= {c} 0)")).collect::<Vec<_>>().join(" ");
                direct = format!("(or {direct} (and {}_square (>= {} {constant}) {zeros}))", ps[0], ps[0]);
            }
        }
    }
    if let Some((u, v)) = premise {
        let h = p.difference(u, v)?;
        let delta = d
            .keys()
            .chain(h.keys())
            .cloned()
            .collect::<BTreeSet<_>>()
            .into_iter()
            .map(|v| {
                let x = p.arithmetic("-",
                    d.get(&v).map_or("0", String::as_str),
                    h.get(&v).map_or("0", String::as_str)
                )?;
                Some((v, x))
            })
            .collect::<Option<Symbolic>>()?;
        Some(format!("(or {direct} {})", ge(&delta, 0)))
    } else {
        Some(direct)
    }
}
type Numeric = BTreeMap<Monomial, i128>;
fn numeric_product(a: &Numeric, b: &Numeric) -> Option<Numeric> {
    let mut out = Numeric::new();
    for (ma, ca) in a { for (mb, cb) in b {
        let mut m = ma.clone(); m.extend(mb.iter().cloned()); m.sort();
        if m.len() > 64 { return None; }
        let old = out.get(&m).copied().unwrap_or(0);
        out.insert(m, old.checked_add(ca.checked_mul(*cb)?)?);
        if out.len() > 4096 { return None; }
    } }
    Some(out)
}
fn numeric(t: &Term, model: &BTreeMap<String, Vec<i64>>) -> Option<Numeric> {
    match t {
        Term::Var(v) => Some(BTreeMap::from([(vec![v.as_str().to_owned()], 1)])),
        Term::App { symbol, args } => {
            let ps = model.get(symbol.as_str())?;
            let monomials = inferred_basis(args.len(), ps.len())?;
            let children = args.iter().map(|t| numeric(t, model)).collect::<Option<Vec<_>>>()?;
            let mut out = Numeric::new();
            for (m, c) in monomials.iter().zip(ps) {
                if *c == 0 { continue; }
                let mut part = BTreeMap::from([(vec![], i128::from(*c))]);
                for i in m { part = numeric_product(&part, &children[*i])?; }
                for (v, x) in part {
                    let value = out
                        .get(&v)
                        .copied()
                        .unwrap_or(0)
                        .checked_add(x)?;
                    out.insert(v, value);
                }
            }
            Some(out)
        }
    }
}
fn difference(a: &Numeric, b: &Numeric) -> Option<Numeric> {
    a.keys()
        .chain(b.keys())
        .cloned()
        .collect::<BTreeSet<_>>()
        .into_iter()
        .map(|v| {
            Some((
                v.clone(),
                a.get(&v)
                    .copied()
                    .unwrap_or(0)
                    .checked_sub(b.get(&v).copied().unwrap_or(0))?,
            ))
        })
        .collect()
}
fn check_leaf(l: &Leaf, model: &BTreeMap<String, Vec<i64>>) -> bool {
    check_leaf_with_squares(l, model, true)
}
fn check_leaf_with_squares(l: &Leaf, model: &BTreeMap<String, Vec<i64>>, allow_square: bool) -> bool {
    let check = || -> Option<bool> {
        let (premise, strict, a, b) = l;
        if !strict && allow_square {
            if let Term::App { symbol, args } = a {
                let rhs = numeric(b, model)?;
                if let Some(cs) = model.get(symbol.as_str()) {
                    if exact_homogeneous_square(args.len(), cs)
                        && rhs.iter().all(|(m, c)| m.is_empty() || *c == 0)
                        && i128::from(cs[0]) >= rhs.get(&vec![]).copied().unwrap_or(0)
                    { return Some(true); }
                }
            }
        }
        let d = difference(&numeric(a, model)?, &numeric(b, model)?)?;
        let ge = |d: &Numeric, gap: i128| {
            d.values().all(|v| *v >= 0) && d.get(&Vec::new()).copied().unwrap_or(0) >= gap
        };
        if ge(&d, if *strict { 1 } else { 0 }) {
            return Some(true);
        }
        let Some((u, v)) = premise else {
            return Some(false);
        };
        let h = difference(&numeric(u, model)?, &numeric(v, model)?)?;
        Some(ge(&difference(&d, &h)?, 0))
    };
    check().unwrap_or(false)
}

/// Exact integer reconstruction of one square, without sign enumeration.
fn exact_homogeneous_square(n: usize, cs: &[i64]) -> bool {
    if n == 0 || cs.len() != basis(n, 2).len() || cs[1..=n].iter().any(|c| *c != 0) { return false; }
    let monomials = basis(n, 2);
    let coeff = |i: usize, j: usize| i128::from(cs[monomials.iter().position(|m| m == &vec![i.min(j), i.max(j)]).unwrap()]);
    let Some(pivot) = (0..n).find(|i| coeff(*i, *i) > 0) else { return false };
    let d = coeff(pivot, pivot);
    let root = d.isqrt();
    if root * root != d { return false; }
    let mut roots = vec![0; n]; roots[pivot] = root;
    for i in 0..n { if i != pivot {
        let cross = coeff(i, pivot);
        if cross % (2 * root) != 0 { return false; }
        roots[i] = cross / (2 * root);
    } }
    (0..n).all(|i| (i..n).all(|j| coeff(i,j) == roots[i] * roots[j] * if i == j {1} else {2}))
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn finite_signed_parameter_multiplication_is_exact() {
        let parameters = BTreeMap::from([("f".into(), vec!["coefficient".into()])]);
        for bound in [1,2] {
            let mut encoder = PolynomialEncoder::new(&parameters);
            encoder.finite_parameters.insert("coefficient".into(), bound);
            let product = encoder.arithmetic("*", "coefficient", "value").unwrap();
            let script = format!("(set-logic ALL)\n(declare-const coefficient Int)\n(declare-const value Int)\n(assert (and (>= coefficient -{bound}) (<= coefficient {bound})))\n{}(assert (not (= {product} (* coefficient value))))\n(check-sat)\n", encoder.take_definitions());
            let output = run_smt_script(&script, &crate::proving::DpOptions::default(), Some(Instant::now()+std::time::Duration::from_secs(10))).unwrap();
            assert_eq!(output.lines().next(), Some("unsat"));
        }
    }

    #[test]
    fn dataflow_induction_retains_producers_and_consumers_not_boolean_noise() {
        let x = Term::var("x");
        let y = Term::var("y");
        let truth = Term::app("answer", vec![]);
        let producer = Constraint::Rewrite(Term::app("compute", vec![x.clone()]), y.clone());
        let consumer = Constraint::Rewrite(Term::app("test", vec![y.clone()]), truth.clone());
        let defined = BTreeSet::from(["compute".into(), "test".into()]);
        let arguments = vec![y.clone()];
        assert!(induction_dataflow_premise(&arguments, &truth, &producer, &defined));
        assert!(!induction_dataflow_premise(&arguments, &truth, &consumer, &defined));
        assert!(induction_dataflow_premise(&arguments, &y, &consumer, &defined));
        assert!(!induction_dataflow_premise(&arguments, &y, &producer, &defined));
        let constructor_producer = Constraint::Rewrite(
            Term::app("successor", vec![x.clone()]), y.clone());
        assert!(!induction_dataflow_premise(&arguments, &truth, &constructor_producer, &defined));
        assert!(induction_dataflow_premise(&arguments, &truth, &Constraint::Order(false, x, y), &defined));
    }

    #[test]
    fn dataflow_induction_closes_recursive_predicate_and_rejects_wrong_order() {
        let x = Term::var("x");
        let y = Term::var("y");
        let zero = Term::app("zero", vec![]);
        let yes = Term::app("yes", vec![]);
        let no = Term::app("no", vec![]);
        let s = |x| Term::app("next", vec![x]);
        let eq = |x, y| Term::app("agree", vec![x, y]);
        let rules = vec![
            RewriteRule::new(eq(zero.clone(), zero.clone()), yes.clone()),
            RewriteRule::new(eq(s(x.clone()), zero.clone()), no.clone()),
            RewriteRule::new(eq(zero.clone(), s(y.clone())), no.clone()),
            RewriteRule::new(eq(s(x.clone()), s(y.clone())), eq(x.clone(), y.clone())),
            RewriteRule::new(Term::app("guard", vec![x.clone(), y.clone()]), no.clone()),
        ];
        let premises = vec![Constraint::Rewrite(eq(x.clone(), y.clone()), yes),
            Constraint::Rewrite(Term::app("guard", vec![s(x.clone()), Term::var("tail")]), no)];
        let conclusion = Constraint::Order(false,
            Term::app("rank", vec![x, y]), Term::app("bound", vec![]));
        let mut calculus = Calculus {
            rules: &rules, defined: BTreeSet::from(["agree".into(), "guard".into()]),
            reserved: premises.iter().flat_map(Constraint::variables).chain(conclusion.variables()).collect(),
            fresh: 0, nodes: 0, reinduct: 0, independent_induction: false,
            dataflow_induction: true, deadline: None,
        };
        let (proof, leaves) = calculus.prove(premises, conclusion, 0).unwrap();
        assert!(proof.contains("<simplifyCondition>"));
        let mut model = BTreeMap::from([
            ("rank".into(), vec![0, -1, 1]), ("next".into(), vec![1, 1]),
            ("zero".into(), vec![0]), ("bound".into(), vec![0]),
        ]);
        assert!(leaves.iter().all(|leaf| check_leaf(leaf, &model)));
        model.insert("rank".into(), vec![0, -1, 0]);
        assert!(leaves.iter().any(|leaf| !check_leaf(leaf, &model)));
    }

    #[test]
    fn constructor_contradiction_precedes_structural_budget_but_respects_defined_symbols() {
        let premise = Constraint::Rewrite(Term::app("left", vec![]), Term::app("right", vec![]));
        let conclusion = Constraint::Order(true, Term::var("x"), Term::var("x"));
        let mut calculus = Calculus {
            rules: &[], defined: BTreeSet::new(), reserved: BTreeSet::new(),
            fresh: 0, nodes: 8001, reinduct: 0, independent_induction: false, dataflow_induction: false, deadline: None,
        };
        let (proof, leaves) = calculus.prove(vec![premise.clone()], conclusion.clone(), 81).unwrap();
        assert!(proof.contains("<differentConstructor>"));
        assert!(leaves.is_empty());
        calculus.defined.insert("left".to_owned());
        assert!(calculus.prove(vec![premise.clone()], conclusion.clone(), 81).is_none());
        calculus.defined.clear();
        calculus.deadline = Some(Instant::now());
        assert!(calculus.prove(vec![premise], conclusion, 81).is_none());
    }

    #[test]
    fn quadratic_square_bound_is_exact_and_not_a_strict_order() {
        // (x-y+z)^2 - 1, with no symbol-dependent interpretation choices.
        let cs = vec![-1, 0, 0, 0, 1, -2, 2, 1, -2, 1];
        assert!(exact_homogeneous_square(3, &cs));
        let mut bad = cs.clone(); bad[5] = -3;
        assert!(!exact_homogeneous_square(3, &bad));
        let model = BTreeMap::from([("rank".into(), cs), ("bound".into(), vec![-1])]);
        let lhs = Term::app("rank", vec![Term::var("x"), Term::var("y"), Term::var("z")]);
        let rhs = Term::app("bound", vec![]);
        assert!(check_leaf(&(None, false, lhs.clone(), rhs.clone()), &model));
        assert!(!check_leaf_with_squares(&(None, false, lhs.clone(), rhs.clone()), &model, false));
        assert!(!check_leaf(&(None, true, lhs, rhs), &model));
    }

    #[test]
    fn quadratic_expansion_rechecks_mixed_monomials_and_shares_encoding() {
        let x = Term::var("x"); let y = Term::var("y");
        let term = Term::app("product", vec![Term::app("succ", vec![x]), Term::app("succ", vec![y])]);
        let model = BTreeMap::from([
            ("product".to_owned(), vec![0, 0, 0, 0, 1, 0]),
            ("succ".to_owned(), vec![1, 1, 0]),
        ]);
        assert_eq!(numeric(&term, &model).unwrap(), BTreeMap::from([
            (vec![], 1), (vec!["x".into()], 1), (vec!["y".into()], 1),
            (vec!["x".into(), "y".into()], 1),
        ]));
        let params = model.iter().enumerate().map(|(i, (s, cs))|
            (s.clone(), (0..cs.len()).map(|j| format!("test_{i}_{j}")).collect())).collect();
        let mut encoder = PolynomialEncoder::new(&params);
        let first = encoder.term(&term).unwrap();
        let expressions = encoder.expressions.len();
        assert!(!encoder.take_definitions().is_empty());
        assert_eq!(encoder.term(&term).unwrap(), first);
        assert_eq!(encoder.expressions.len(), expressions);
        assert!(encoder.take_definitions().is_empty());
        assert!(!check_leaf(&(None, true, term.clone(), term), &model));
    }

    #[test]
    fn quadratic_signed_usable_checks_both_ambiguous_argument_directions() {
        let x = Term::var("x");
        let call = Term::app("call", vec![x]);
        let pair = RewriteRule::new(call.clone(), call);
        assert!(check_signed_usable(&[pair.clone()], &[],
            &BTreeMap::from([("call".into(), vec![0, -1, 1])])));
        assert!(check_signed_usable(&[pair], &[],
            &BTreeMap::from([("call".into(), vec![0, 0, -1])])));
        let x = Term::var("x");
        let term = Term::app("call", vec![Term::app("h", vec![x.clone()])]);
        let rule = RewriteRule::new(Term::app("h", vec![Term::app("s", vec![x.clone()])]), Term::app("h", vec![x]));
        assert!(!check_signed_usable(&[RewriteRule::new(term.clone(), term)], &[rule],
            &BTreeMap::from([("call".into(), vec![0, -1, 1]), ("h".into(), vec![0, 1]), ("s".into(), vec![1, 1])])));
    }

    #[test]
    fn independent_constructor_range_induction_rejects_a_positive_range_mutation() {
        let unary = |s: &str, t| Term::app(s, vec![t]);
        let binary = |s: &str, a, b| Term::app(s, vec![a, b]);
        let zero = Term::app("zero", vec![]);
        let x = Term::var("x");
        let y = Term::var("y");
        for positive_range in [false, true] {
            let recursive = binary("flatten", x.clone(), y.clone());
            let rules = vec![
                RewriteRule::new(binary("flatten", zero.clone(), y.clone()), zero.clone()),
                RewriteRule::new(binary("flatten", unary("succ", x.clone()), zero.clone()), zero.clone()),
                RewriteRule::new(binary("flatten", unary("succ", x.clone()), unary("succ", y.clone())),
                    if positive_range { unary("succ", recursive) } else { recursive }),
            ];
            let premises = vec![
                Constraint::Rewrite(unary("auxiliary", Term::var("a")), unary("succ", Term::var("b"))),
                Constraint::Rewrite(binary("flatten", x.clone(), y.clone()), unary("succ", Term::var("k"))),
            ];
            let conclusion = Constraint::Order(true,
                unary("rank", Term::var("a")), unary("rank", Term::var("b")));
            let mut calculus = Calculus {
                rules: &rules, defined: BTreeSet::from(["flatten".into(), "auxiliary".into()]),
                reserved: premises.iter().flat_map(Constraint::variables).chain(conclusion.variables()).collect(),
                fresh: 0, nodes: 0, reinduct: 0, independent_induction: true, dataflow_induction: false, deadline: None,
            };
            let (proof, leaves) = calculus.prove(premises, conclusion, 0).unwrap();
            assert!(proof.contains("<induction>"));
            let model = BTreeMap::from([("rank".to_owned(), vec![0, 0])]);
            assert_eq!(leaves.iter().all(|leaf| check_leaf(leaf, &model)), !positive_range);
        }
    }

    #[test]
    fn induction_premises_match_modulo_local_binders_without_capture() {
        let quantified = |binder: &str, free: Term| Constraint::All(
            vec![Variable::new(binder)], Box::new(Constraint::Implication(
                vec![Constraint::Rewrite(
                    Term::app("predicate", vec![Term::var(binder), free.clone()]),
                    Term::app("true", vec![]),
                )],
                Box::new(Constraint::Order(false, free, Term::var(binder))),
            )),
        );
        let pattern = quantified("bound_left", Term::var("outer"));
        let live = quantified("bound_right", Term::var("actual"));
        let mut subst = BTreeMap::new();
        assert!(match_constraint(&pattern, &live, &[Variable::new("outer")], &mut subst));
        assert_eq!(subst.get(&Variable::new("outer")), Some(&Term::var("actual")));
        let escaping = quantified("bound_right", Term::var("bound_right"));
        let mut subst = BTreeMap::new();
        assert!(!match_constraint(&pattern, &escaping, &[Variable::new("outer")], &mut subst));
        assert!(subst.is_empty());
        assert!(!match_constraint(
            &Constraint::Order(false, Term::var("x"), Term::var("y")),
            &Constraint::Order(true, Term::var("x"), Term::var("y")), &[], &mut subst,
        ));
    }

    #[test]
    fn implication_matching_ignores_premise_order_but_preserves_shared_variables() {
        let premise = |name: &str, arg: &str| Constraint::Rewrite(
            Term::app(name, vec![Term::var(arg)]), Term::app("truth", vec![]));
        let conclusion = || Box::new(Constraint::Order(false, Term::var("x"), Term::var("x")));
        let source = Constraint::Implication(vec![premise("p", "x"), premise("q", "x")], conclusion());
        let reversed = Constraint::Implication(vec![premise("q", "x"), premise("p", "x")], conclusion());
        assert!(match_constraint(&source, &reversed, &[], &mut Subst::new()));
        let changed = Constraint::Implication(vec![premise("q", "y"), premise("p", "x")], conclusion());
        assert!(!match_constraint(&source, &changed, &[Variable::new("x")], &mut Subst::new()));
    }

    #[test]
    fn irrelevant_fresh_rewrite_output_is_deleted_before_induction() {
        let conclusion = Constraint::Order(false, Term::var("x"), Term::var("y"));
        let premise = Constraint::Rewrite(
            Term::app("auxiliary", vec![Term::var("y")]), Term::var("unused"),
        );
        let mut calculus = Calculus {
            rules: &[], defined: BTreeSet::from(["auxiliary".to_owned()]),
            reserved: premise.variables().union(&conclusion.variables()).cloned().collect(),
            fresh: 0, nodes: 0, reinduct: 0, independent_induction: false, dataflow_induction: false, deadline: None,
        };
        let (proof, leaves) = calculus.prove(vec![premise], conclusion.clone(), 0).unwrap();
        assert!(proof.contains("<deleteCondition>"));
        assert!(!proof.contains("<induction>"));
        assert_eq!(leaves, vec![(None, false, Term::var("x"), Term::var("y"))]);
        // Deleting an irrelevant premise must not make an invalid arithmetic
        // conclusion true: the independent leaf check still rejects x >= y.
        assert!(!check_leaf(&leaves[0], &BTreeMap::new()));
    }

    #[test]
    fn open_arithmetic_branch_preserves_surrounding_induction() {
        let x = Term::var("x");
        let xs = Term::var("xs");
        let nil = Term::app("empty", vec![]);
        let zero = Term::app("zero", vec![]);
        let rules = vec![
            RewriteRule::new(Term::app("measure", vec![nil]), zero),
            RewriteRule::new(
                Term::app("measure", vec![Term::app("cell", vec![x, xs.clone()])]),
                Term::app("next", vec![Term::app("measure", vec![xs])]),
            ),
        ];
        let list = Term::var("list");
        let n = Term::var("n");
        let premise = Constraint::Rewrite(
            Term::app("measure", vec![list.clone()]),
            Term::app("next", vec![n]),
        );
        let conclusion = Constraint::Order(
            false,
            Term::app("rank", vec![list]),
            Term::app("bound", vec![]),
        );
        let mut calculus = Calculus {
            rules: &rules,
            defined: BTreeSet::from(["measure".to_owned()]),
            reserved: premise.variables().union(&conclusion.variables()).cloned().collect(),
            fresh: 0, nodes: 0, reinduct: 0, independent_induction: false, dataflow_induction: false, deadline: None,
        };
        let (proof, leaves) = calculus.prove(vec![premise], conclusion, 0).unwrap();
        assert!(proof.contains("<induction>"));
        assert!(proof.contains("<differentConstructor>"));
        assert!(proof.contains("<deleteCondition>"));
        assert_eq!(leaves.len(), 1);
        assert!(leaves[0].0.is_none());
        let Term::App { args, .. } = &leaves[0].2 else { panic!("expected rank") };
        assert_eq!(args[0].root_symbol().unwrap().as_str(), "cell");
        let model = BTreeMap::from([
            ("rank".to_owned(), vec![0, 1]),
            ("cell".to_owned(), vec![1, 0, 1]),
            ("bound".to_owned(), vec![1]),
        ]);
        assert!(check_leaf(&leaves[0], &model));
        let invalid = BTreeMap::from([
            ("rank".to_owned(), vec![0, 0]),
            ("cell".to_owned(), vec![1, 0, 1]),
            ("bound".to_owned(), vec![1]),
        ]);
        assert!(!check_leaf(&leaves[0], &invalid));
    }

    #[test]
    fn conditional_synthesis_uses_active_rules_without_changing_q() {
        use crate::core::{Trs, RewriteStrategy};
        use crate::proving::dependency_pairs::{DependencyPair, DpOptions};
        let x = Term::var("x");
        let active = RewriteRule::new(Term::app("helper", vec![x.clone()]), x.clone());
        let inactive = RewriteRule::new(Term::app("parent_only", vec![x.clone()]), x.clone());
        let trs = Trs::new_with_strategy(None, x.variables(),
            vec![active.clone(), inactive], RewriteStrategy::Innermost);
        let pairs = vec![DependencyPair::new(
            Term::app("call#", vec![Term::app("succ", vec![x.clone()])]),
            Term::app("call#", vec![x]), 0)];
        let mut state = DpProblemState::ordinary(trs, pairs, DpOptions::default());
        state.innermost_lhss = Some(vec![active.lhs().clone()]);
        let deadline = || Some(Instant::now() + std::time::Duration::from_secs(10));
        // Parent-only rules are not Q-reducible, so using the parent R fails.
        assert!(synthesize(&state, 1, deadline()).is_none());
        state.stats.active_rules = Some(vec![active]);
        let original_q = state.innermost_lhss.clone();
        assert!(synthesize(&state, 1, deadline()).is_some());
        assert_eq!(state.innermost_lhss, original_q);
        state.stats.active_rules = Some(vec![]);
        assert!(synthesize(&state, 1, deadline()).is_some());
    }

    #[test]
    fn conditional_synthesis_rejects_a_real_cycle_and_missing_q() {
        use crate::core::{Trs, RewriteStrategy};
        use crate::proving::dependency_pairs::{dependency_pairs, DpOptions};
        let f = Term::app("looping", vec![Term::var("x")]);
        let trs = Trs::new_with_strategy(None, f.variables(),
            vec![RewriteRule::new(f.clone(), f)], RewriteStrategy::Innermost);
        let mut state = DpProblemState::ordinary(trs.clone(), dependency_pairs(&trs), DpOptions::default());
        let processor = ConditionalPolynomialProcessor {
            max_coefficient: 2, degree: 1, before: 1, after: 0, squares: false, reinduct: 0, induction: 0, deadline: Some(Instant::now()+std::time::Duration::from_secs(5)),
        };
        assert!(matches!(processor.apply(&ProblemState::DependencyPairs(state.clone())), ProcessorResult::Inapplicable));
        state.innermost_lhss = Some(vec![]);
        assert!(matches!(processor.apply(&ProblemState::DependencyPairs(state)), ProcessorResult::Inapplicable));
    }

    #[test]
    fn signed_usable_rules_require_reverse_orientation() {
        let x = Term::var("x");
        let f = Term::app("worker", vec![x.clone()]);
        let r = RewriteRule::new(f.clone(), Term::app("next", vec![x.clone()]));
        let p = RewriteRule::new(Term::app("call", vec![x]), Term::app("call", vec![f]));
        let model = BTreeMap::from([
            ("call".to_owned(), vec![0, -1]),
            ("worker".to_owned(), vec![2, 1]),
            ("next".to_owned(), vec![1, 1]),
        ]);
        assert!(!check_signed_usable(&[p.clone()], &[r.clone()], &model));
        let mut model = model;
        model.insert("call".to_owned(), vec![0, 1]);
        assert!(check_signed_usable(&[p], &[r], &model));
    }

    #[test]
    fn conditional_leaf_rechecks_arithmetic_and_strictness() {
        let x = Term::var("x");
        let zero = Term::app("zero", vec![]);
        let model = BTreeMap::from([("zero".to_owned(), vec![0]), ("s".to_owned(), vec![1, 1])]);
        assert!(!check_leaf(&(None, true, x.clone(), x.clone()), &model));
        let premise = Some((x.clone(), zero.clone()));
        assert!(check_leaf(
            &(
                premise.clone(),
                false,
                Term::app("s", vec![x.clone()]),
                zero.clone()
            ),
            &model
        ));
        assert!(!check_leaf(&(premise, true, zero, x), &model));
    }

    #[test]
    fn conditional_strategy_roundtrip_and_bounds() {
        use crate::proving::DpStrategy;
        let p = DpStrategy::parse("conditional-poly(max-coefficient=2)").unwrap();
        assert_eq!(p, DpStrategy::parse("conditional-poly").unwrap());
        assert!(DpStrategy::parse("conditional-poly(max-coefficient=0)").is_err());
        assert!(DpStrategy::parse("conditional-poly(max-coefficient=99)").is_err());
        let quadratic = DpStrategy::parse("conditional-poly(max-coefficient=2,degree=2)").unwrap();
        assert_eq!(quadratic, DpStrategy::parse(&quadratic.to_strategy_atom()).unwrap());
        for induction in 0..=7 {
            let strategy = DpStrategy::parse(&format!("conditional-poly(max-coefficient=2,induction={induction})")).unwrap();
            assert_eq!(strategy, DpStrategy::parse(&strategy.to_strategy_atom()).unwrap());
        }
        assert!(DpStrategy::parse("conditional-poly(max-coefficient=2,induction=8)").is_err());
        let square = DpStrategy::parse("conditional-poly(max-coefficient=2,degree=2,before=2,squares=1)").unwrap();
        assert_eq!(square, DpStrategy::parse(&square.to_strategy_atom()).unwrap());
        let forward = DpStrategy::parse("conditional-poly(max-coefficient=2,before=0,after=1,reinduct=1)").unwrap();
        assert_eq!(forward, DpStrategy::parse(&forward.to_strategy_atom()).unwrap());
        assert!(DpStrategy::parse("conditional-poly(max-coefficient=2,before=4)").is_err());
        assert!(DpStrategy::parse("conditional-poly(max-coefficient=2,squares=1)").is_err());
        assert!(DpStrategy::parse("conditional-poly(max-coefficient=2,degree=3)").is_err());
    }
}
