use crate::core::{RewriteRule, RewriteStrategy, Term, Trs, Variable};
use crate::proving::dependency_pairs::{DependencyPair, DpProofTree};

use super::super::{
    ProblemCertificate, ProblemState, ProcessorApplication, ProcessorResult, WorklistProcessor,
};

/// The certified two-stack QDP-to-SRS transformation used by Zantema's
/// examples.  It is deliberately a state transformer: the generated SRS is
/// an ordinary worklist child and can therefore receive independent oracle
/// guidance and any existing SRS processor.
pub struct QdpToSrsProcessor;

impl WorklistProcessor for QdpToSrsProcessor {
    fn name(&self) -> &'static str {
        "qdp-to-srs"
    }

    fn apply(&self, state: &ProblemState) -> ProcessorResult {
        let ProblemState::DependencyPairs(problem) = state else {
            return ProcessorResult::Inapplicable;
        };
        let q_is_empty = problem.innermost_lhss.as_ref().is_none_or(Vec::is_empty);
        let active_rules = problem
            .stats
            .active_rules
            .as_deref()
            .unwrap_or(problem.trs.rules());
        if !q_is_empty
            || !active_rules.is_empty()
            || !problem.stats.weak_pairs.is_empty()
            || !problem.stats.strict_rules.is_empty()
            || problem.pairs.is_empty()
        {
            return ProcessorResult::Inapplicable;
        }

        let Some(rules) = transform_pairs(&problem.pairs) else {
            return ProcessorResult::Inapplicable;
        };
        let mut variables = problem.trs.variables().clone();
        for rule in &rules {
            variables.extend(rule.lhs().variables());
            variables.extend(rule.rhs().variables());
        }
        let generated = Trs::new_with_strategy(
            problem.trs.name().map(|name| format!("{name}#qdp-to-srs")),
            variables,
            rules,
            RewriteStrategy::Full,
        );
        let removed_count = problem.pairs.len();
        let child = ProblemState::from_trs(generated.clone());

        ProcessorResult::Applied(ProcessorApplication::new(vec![child], move |children| {
            let [ProblemCertificate::Trs(proof)] =
                <[ProblemCertificate; 1]>::try_from(children).ok()?
            else {
                return None;
            };
            Some(ProblemCertificate::DependencyPairTree(
                DpProofTree::QdpToSrs {
                    generated: generated.clone(),
                    removed_count,
                    proof: Box::new(proof),
                },
            ))
        }))
    }
}

fn unary_var(term: &Term) -> Option<(Vec<crate::core::Symbol>, Variable)> {
    match term {
        Term::Var(variable) => Some((Vec::new(), variable.clone())),
        Term::App { symbol, args } if args.len() == 1 => {
            let (mut prefix, variable) = unary_var(&args[0])?;
            prefix.insert(0, symbol.clone());
            Some((prefix, variable))
        }
        _ => None,
    }
}

fn unary_term(prefix: &[crate::core::Symbol], tail: Term) -> Term {
    prefix.iter().rev().fold(tail, |term, symbol| Term::App {
        symbol: symbol.clone(),
        args: vec![term],
    })
}

fn transform_pair(pair: &DependencyPair) -> Option<Option<RewriteRule>> {
    let (
        Term::App {
            symbol: lhs_root,
            args: lhs_args,
        },
        Term::App {
            symbol: rhs_root,
            args: rhs_args,
        },
    ) = (pair.lhs(), pair.rhs())
    else {
        return None;
    };
    if lhs_root != rhs_root || lhs_args.len() != 2 || rhs_args.len() != 2 {
        return None;
    }

    if let (Term::Var(x), Term::Var(y)) = (&lhs_args[0], &rhs_args[1]) {
        let (left, left_tail) = unary_var(&lhs_args[1])?;
        let (right, right_tail) = unary_var(&rhs_args[0])?;
        if x == y || &left_tail != y || &right_tail != x || left.is_empty() || right.is_empty() {
            return None;
        }
        let tail = Term::Var(x.clone());
        let lhs = unary_term(&left, tail.clone());
        let reversed = right.iter().rev().cloned().collect::<Vec<_>>();
        return Some(Some(RewriteRule::new(lhs, unary_term(&reversed, tail))));
    }

    let (
        Term::App {
            symbol: left_symbol,
            args: left_unary,
        },
        Term::Var(y),
        Term::Var(x2),
        Term::App {
            symbol: right_symbol,
            args: right_unary,
        },
    ) = (&lhs_args[0], &lhs_args[1], &rhs_args[0], &rhs_args[1])
    else {
        return None;
    };
    let ([Term::Var(x)], [Term::Var(y2)]) = (left_unary.as_slice(), right_unary.as_slice()) else {
        return None;
    };
    (left_symbol == right_symbol && x == x2 && y == y2 && x != y).then_some(None)
}

fn transform_pairs(pairs: &[DependencyPair]) -> Option<Vec<RewriteRule>> {
    let mut rules = Vec::new();
    for pair in pairs {
        if let Some(rule) = transform_pair(pair)? {
            rules.push(rule);
        }
    }
    Some(rules)
}

#[cfg(test)]
mod tests {
    use super::*;

    fn pair(lhs: Term, rhs: Term) -> DependencyPair {
        DependencyPair::new(lhs, rhs, 0)
    }

    #[test]
    fn zantema_shape_generates_aabb_to_bbbaaa() {
        let x = Term::var("x");
        let y = Term::var("y");
        let lhs_tail = Term::app(
            "a",
            vec![Term::app(
                "a",
                vec![Term::app("b", vec![Term::app("b", vec![y.clone()])])],
            )],
        );
        let rhs_stack = Term::app(
            "a",
            vec![Term::app(
                "a",
                vec![Term::app(
                    "a",
                    vec![Term::app(
                        "b",
                        vec![Term::app("b", vec![Term::app("b", vec![x.clone()])])],
                    )],
                )],
            )],
        );
        let productive = pair(
            Term::app("f#", vec![x.clone(), lhs_tail]),
            Term::app("f#", vec![rhs_stack, y.clone()]),
        );
        let transfer_a = pair(
            Term::app("f#", vec![Term::app("a", vec![x.clone()]), y.clone()]),
            Term::app("f#", vec![x.clone(), Term::app("a", vec![y.clone()])]),
        );
        let transfer_b = pair(
            Term::app("f#", vec![Term::app("b", vec![x.clone()]), y.clone()]),
            Term::app("f#", vec![x, Term::app("b", vec![y])]),
        );
        let rules = transform_pairs(&[productive, transfer_a, transfer_b]).unwrap();
        assert_eq!(rules.len(), 1);
        assert_eq!(rules[0].to_string(), "a(a(b(b(x)))) -> b(b(b(a(a(a(x))))))");
    }

    #[test]
    fn rejects_a_transfer_pair_with_different_stack_symbols() {
        let x = Term::var("x");
        let y = Term::var("y");
        let malformed = pair(
            Term::app("f#", vec![Term::app("a", vec![x.clone()]), y.clone()]),
            Term::app("f#", vec![x, Term::app("b", vec![y])]),
        );
        assert!(transform_pairs(&[malformed]).is_none());
    }

    #[test]
    fn rejects_a_productive_pair_with_a_non_unary_stack() {
        let x = Term::var("x");
        let y = Term::var("y");
        let malformed = pair(
            Term::app(
                "f#",
                vec![x.clone(), Term::app("c", vec![y.clone(), y.clone()])],
            ),
            Term::app("f#", vec![Term::app("a", vec![x]), y]),
        );
        assert!(transform_pairs(&[malformed]).is_none());
    }
}
