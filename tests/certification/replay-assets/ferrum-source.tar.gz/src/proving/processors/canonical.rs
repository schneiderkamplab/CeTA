use std::collections::BTreeSet;

use crate::cert::{write_csr_input_cpf4, write_relative_trs_input_cpf3, write_trs_input_cpf3};
use crate::core::{CsrTrs, RelativeTrs, ReplacementMap, Trs};
use crate::standardize::{standardize_trs, standardize_trs_with_bijection};

pub(crate) fn standardized_trs_input_cpf3(trs: &Trs) -> (String, Option<String>) {
    match standardize_trs(trs) {
        Ok(standardized) => (write_trs_input_cpf3(&standardized), None),
        Err(error) => (write_trs_input_cpf3(trs), Some(error.to_string())),
    }
}

pub(crate) fn standardized_relative_trs_input_cpf3(
    relative: &RelativeTrs,
) -> (String, Option<String>) {
    let raw = || write_relative_trs_input_cpf3(relative);
    let strict_count = relative.strict().rules().len();
    let standardized = match standardize_trs_with_bijection(&relative.union()) {
        Ok(standardized) => standardized,
        Err(error) => return (raw(), Some(error.to_string())),
    };
    let strict_indices = standardized
        .rule_metadata
        .iter()
        .filter(|metadata| metadata.original_pair_index < strict_count)
        .map(|metadata| metadata.canonical_pair_index)
        .collect::<BTreeSet<_>>();
    let weak_indices = standardized
        .rule_metadata
        .iter()
        .filter(|metadata| metadata.original_pair_index >= strict_count)
        .map(|metadata| metadata.canonical_pair_index)
        .collect::<BTreeSet<_>>();
    let rules = standardized.trs.rules();
    let strict_rules = rules
        .iter()
        .enumerate()
        .filter(|(index, _)| strict_indices.contains(index))
        .map(|(_, rule)| rule.clone())
        .collect();
    let weak_rules = rules
        .iter()
        .enumerate()
        .filter(|(index, _)| weak_indices.contains(index))
        .map(|(_, rule)| rule.clone())
        .collect();
    let strict = Trs::new_with_strategy(
        standardized.trs.name().map(str::to_string),
        standardized.trs.variables().clone(),
        strict_rules,
        standardized.trs.strategy(),
    );
    (
        write_relative_trs_input_cpf3(&RelativeTrs::new(strict, weak_rules)),
        None,
    )
}

pub(crate) fn standardized_csr_input_cpf4(csr: &CsrTrs) -> (String, Option<String>) {
    let raw = || write_csr_input_cpf4(csr);
    let standardized = match standardize_trs_with_bijection(csr.trs()) {
        Ok(standardized) => standardized,
        Err(error) => return (raw(), Some(error.to_string())),
    };
    let replacement_map = ReplacementMap::new(
        csr.replacement_map()
            .entries()
            .iter()
            .filter_map(|(symbol, positions)| {
                standardized
                    .function_bijection
                    .get(symbol)
                    .cloned()
                    .map(|canonical| (canonical, positions.clone()))
            })
            .collect(),
    );
    match CsrTrs::new(standardized.trs, replacement_map) {
        Ok(standardized_csr) => (write_csr_input_cpf4(&standardized_csr), None),
        Err(issues) => (
            raw(),
            Some(
                issues
                    .into_iter()
                    .map(|issue| issue.to_string())
                    .collect::<Vec<_>>()
                    .join("; "),
            ),
        ),
    }
}
