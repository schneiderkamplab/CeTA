use std::collections::{BTreeMap, BTreeSet};

use serde::{Deserialize, Serialize};

use super::dependency_pairs::{
    DependencyPair, DependencyPairProof, DpArgumentFilter, DpPathOrderKind, SemanticLabelingModel,
};
use super::processors::relative_adp::RelativeAdpProof;
use crate::core::{CsrTrs, ReplacementMap, RewriteRule, Symbol, Term, Variable};

#[derive(Clone, Debug, Deserialize, Eq, PartialEq, Serialize)]
pub enum BoundsType {
    Match,
    Roof,
}

#[derive(Clone, Debug, Deserialize, Eq, PartialEq, Serialize)]
pub enum TreeAutomatonTransitionLhs {
    State(String),
    Symbol {
        symbol: String,
        height: Option<usize>,
        args: Vec<String>,
    },
}

#[derive(Clone, Debug, Deserialize, Eq, PartialEq, Serialize)]
pub struct TreeAutomatonTransition {
    pub lhs: TreeAutomatonTransitionLhs,
    pub rhs: String,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct FlatContext {
    pub symbol: Symbol,
    pub before: Vec<Term>,
    pub after: Vec<Term>,
}

#[derive(Clone, Debug, Deserialize, Eq, PartialEq, Serialize)]
pub struct TreeAutomaton {
    pub final_states: Vec<String>,
    pub transitions: Vec<TreeAutomatonTransition>,
}

#[derive(Clone, Debug, Deserialize, Eq, PartialEq, Serialize)]
pub struct BoundsProof {
    pub bounds_type: BoundsType,
    pub bound: usize,
    pub final_states: Vec<String>,
    pub automaton: TreeAutomaton,
    pub state_compatibility: Vec<(String, String)>,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub enum Status {
    Terminating,
    Nonterminating,
    Unknown,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct LoopRewriteStep {
    pub position: Vec<usize>,
    pub rule: RewriteRule,
    pub result: Term,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct LoopProof {
    pub start: Term,
    pub steps: Vec<LoopRewriteStep>,
    pub substitution: BTreeMap<Variable, Term>,
    pub context_position: Vec<usize>,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub enum NonterminationProof {
    ExactXml(String),
    RuleRemoval {
        removed_rules: Vec<RewriteRule>,
        proof: Box<Proof>,
    },
    VariableConditionViolated,
    Loop(LoopProof),
    NotWnTreeAutomaton {
        automaton: TreeAutomaton,
        state_compatibility: Vec<(String, String)>,
    },
    SrsDerivationPatterns(SrsDerivationPatternProof),
    SwitchFullStrategy {
        wcr_depth: usize,
        proof: Box<NonterminationProof>,
    },
    DependencyPairs {
        pairs: Vec<DependencyPair>,
        proof: Box<DpNonterminationProof>,
    },
    /// CPF's Q-increase followed by the complete DP transformation.  Keeping
    /// the boundary explicit lets the universal worklist guide the resulting
    /// DP state independently instead of retaining an opaque whole proof.
    InnermostLhssDependencyPairs {
        innermost_lhss: Vec<Term>,
        pairs: Vec<DependencyPair>,
        proof: Box<DpNonterminationProof>,
    },
}

#[derive(Clone, Debug, Eq, Ord, PartialEq, PartialOrd)]
pub struct SrsWordPattern {
    pub prefix: Vec<Symbol>,
    pub repeated: Vec<Symbol>,
    pub factor: usize,
    pub constant: usize,
    pub suffix: Vec<Symbol>,
}

#[derive(Clone, Debug, Eq, Ord, PartialEq, PartialOrd)]
pub struct SrsDerivationPattern {
    pub lhs: SrsWordPattern,
    pub rhs: SrsWordPattern,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct SrsOverlapClosure {
    pub lhs: Vec<Symbol>,
    pub rhs: Vec<Symbol>,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub enum SrsDerivationPatternStep {
    ComposeClosures {
        result: SrsOverlapClosure,
        first: SrsOverlapClosure,
        second: SrsOverlapClosure,
        left: Vec<Symbol>,
        right: Vec<Symbol>,
        /// None means an internal rewrite (OC3); Some means OC2.
        overlap: Option<Vec<Symbol>>,
    },
    Lift {
        result: SrsDerivationPattern,
        premise: SrsDerivationPattern,
    },
    Rewrite {
        result: SrsDerivationPattern,
        premise: SrsDerivationPattern,
        closure: SrsOverlapClosure,
        /// 0 = finite prefix, 1 = repeated word, 2 = finite suffix.
        region: u8,
        left: Vec<Symbol>,
        right: Vec<Symbol>,
    },
    Compose {
        result: SrsDerivationPattern,
        first: SrsDerivationPattern,
        second: SrsDerivationPattern,
        /// Prefix/suffix containment case, as in CeTA DP_DP_i_j.
        kind: (u8, u8),
        left: Vec<Symbol>,
        right: Vec<Symbol>,
    },
    Original {
        closure: SrsOverlapClosure,
        is_pair: bool,
    },
    OverlapIntoPatternLeft {
        pattern: SrsDerivationPattern,
        closure: SrsOverlapClosure,
    },
    OverlapIntoPatternRight {
        pattern: SrsDerivationPattern,
        closure: SrsOverlapClosure,
    },
    PatternOverlapSuffix {
        result: SrsDerivationPattern,
        pattern: SrsDerivationPattern,
        closure: SrsOverlapClosure,
        left: Vec<Symbol>,
        right: Vec<Symbol>,
        overlap: Vec<Symbol>,
    },
    PatternCompositionPrefix {
        result: SrsDerivationPattern,
        first: SrsDerivationPattern,
        second: SrsDerivationPattern,
        left: Vec<Symbol>,
        right: Vec<Symbol>,
    },
    Equivalent {
        result: SrsDerivationPattern,
        premise: SrsDerivationPattern,
    },
    OverlapPatternPrefix {
        result: SrsDerivationPattern,
        pattern: SrsDerivationPattern,
        closure: SrsOverlapClosure,
        left: Vec<Symbol>,
        right: Vec<Symbol>,
        overlap: Vec<Symbol>,
    },
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct SrsDerivationPatternProof {
    pub steps: Vec<SrsDerivationPatternStep>,
    pub self_embedding: SrsDerivationPattern,
    pub left_context: Vec<Symbol>,
    pub right_context: Vec<Symbol>,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct DpRewriteProof {
    pub original_pair: DependencyPair,
    pub rewrite_step: LoopRewriteStep,
    pub rewritten_pair: DependencyPair,
    pub usable_rules: Vec<RewriteRule>,
    pub proof: Box<DpNonterminationProof>,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct PatternRule {
    pub lhs: Term,
    pub rhs: Term,
    pub pumping_substitution: BTreeMap<Variable, Term>,
    pub closing_substitution: BTreeMap<Variable, Term>,
    pub rhs_pumping_substitution: Option<BTreeMap<Variable, Term>>,
    pub rhs_closing_substitution: Option<BTreeMap<Variable, Term>>,
    pub proof: PatternRuleProof,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub enum PatternRuleProof {
    OriginalRule {
        rule: RewriteRule,
        is_pair: bool,
    },
    InitialPumping {
        pattern_rule: Box<PatternRule>,
        pumping_substitution: BTreeMap<Variable, Term>,
        closing_substitution: BTreeMap<Variable, Term>,
    },
    InitialPumpingContext {
        pattern_rule: Box<PatternRule>,
        pumping_substitution: BTreeMap<Variable, Term>,
        position: Vec<usize>,
        variable: Variable,
    },
    Instantiation {
        pattern_rule: Box<PatternRule>,
        substitution: BTreeMap<Variable, Term>,
        target: PatternInstantiationTarget,
    },
    InstantiationPumping {
        pattern_rule: Box<PatternRule>,
        power: usize,
    },
    Narrowing {
        pattern_rule: Box<PatternRule>,
        narrowing_rule: Box<PatternRule>,
        position: Vec<usize>,
    },
    Rewriting {
        pattern_rule: Box<PatternRule>,
        start: Term,
        steps: Vec<LoopRewriteStep>,
        target: PatternInstantiationTarget,
        variable: Option<Variable>,
    },
    Equivalence {
        pattern_rule: Box<PatternRule>,
        side: PatternEquivalenceSide,
        equivalence: PatternEquivalence,
    },
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub enum PatternInstantiationTarget {
    Base,
    Pumping,
    Closing,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub enum PatternEquivalenceSide {
    Left,
    Right,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub enum PatternEquivalence {
    DomainRenaming {
        substitution: BTreeMap<Variable, Term>,
    },
    Irrelevant {
        base_substitution: BTreeMap<Variable, Term>,
        pumping_substitution: BTreeMap<Variable, Term>,
    },
    Simplification {
        first_substitution: BTreeMap<Variable, Term>,
        second_substitution: BTreeMap<Variable, Term>,
    },
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct NonLoopProof {
    pub pattern_rule: PatternRule,
    pub pumping_substitution: BTreeMap<Variable, Term>,
    pub closing_substitution: BTreeMap<Variable, Term>,
    pub pumping_decomposition: usize,
    pub subterm_index: usize,
    pub position: Vec<usize>,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub enum DpNonterminationProof {
    Loop(LoopProof),
    InnermostLhssRemoval {
        remaining_lhss: Vec<Term>,
        proof: Box<DpNonterminationProof>,
    },
    InnermostLhssIncrease {
        added_lhss: Vec<Term>,
        child_pairs: Vec<DependencyPair>,
        proof: Box<DpNonterminationProof>,
    },
    Narrowing {
        step: crate::proving::DpNarrowingStep,
        proof: Box<DpNonterminationProof>,
    },
    SwitchFullStrategy {
        wcr_depth: usize,
        proof: Box<DpNonterminationProof>,
    },
    DpRuleRemoval {
        removed_pairs: Vec<DependencyPair>,
        removed_rules: Vec<RewriteRule>,
        proof: Box<DpNonterminationProof>,
    },
    Rewriting {
        step: Box<DpRewriteProof>,
    },
    /// Complete replacement pair set P', not additions to the parent P.
    /// Every pair in P' must be a simultaneous instance of a parent pair.
    Instantiation {
        instantiated_pairs: Vec<DependencyPair>,
        proof: Box<DpNonterminationProof>,
    },
    NonLoop(NonLoopProof),
    /// A complete CPF loop fragment retained from a checker-certified proof.
    /// The exact processor binds it to the matching live DP input before it
    /// can be emitted; CeTA independently validates the loop itself.
    ExactLoopXml(String),
    ExactNonLoopXml(String),
    /// A complete checker-certified DP nontermination proof fragment bound
    /// by its processor to one independently keyed live DP obligation.
    ExactProofXml(String),
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct UncurriedSymbolEntry {
    pub original: Symbol,
    pub arity: usize,
    pub symbols: Vec<Symbol>,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct UncurryProof {
    pub app_symbol: Symbol,
    pub symbols: Vec<UncurriedSymbolEntry>,
    pub uncurry_rules: Vec<RewriteRule>,
    pub eta_rules: Vec<RewriteRule>,
    pub transformed_rules: Vec<RewriteRule>,
    pub proof: Box<Proof>,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub enum ProofStep {
    EmptySystem,
    ExactTerminationXml(String),
    LlmLinearPolynomial {
        interpretations: Vec<(String, i64, Vec<i64>)>,
    },
    SynthesizedLinearPolynomial {
        interpretations: Vec<(String, i64, Vec<i64>)>,
    },
    PolynomialRuleRemoval {
        interpretations: Vec<(String, i64, Vec<i64>)>,
        removed: Vec<RewriteRule>,
        proof: Box<Proof>,
    },
    MatrixRuleRemoval {
        interpretations: Vec<(String, super::MatrixInterpretation)>,
        dimension: usize,
        strict_dimension: usize,
        domain: super::MatrixDomain,
        removed: Vec<RewriteRule>,
        proof: Box<Proof>,
    },
    SynthesizedKbo {
        precedence: Vec<String>,
        precedence_ranks: BTreeMap<String, usize>,
        weights: Vec<(String, i64)>,
    },
    KboRuleRemoval {
        precedence: Vec<String>,
        precedence_ranks: BTreeMap<String, usize>,
        weights: Vec<(String, i64)>,
        removed: Vec<RewriteRule>,
        proof: Box<Proof>,
    },
    PathOrderRuleRemoval {
        statuses: BTreeMap<String, DpPathOrderKind>,
        precedence: Vec<String>,
        precedence_ranks: BTreeMap<String, usize>,
        argument_filter: DpArgumentFilter,
        removed: Vec<RewriteRule>,
        proof: Box<Proof>,
    },
    SemanticLabeling {
        root_labeling: bool,
        model: SemanticLabelingModel,
        labeled_rules: Vec<RewriteRule>,
        proof: Box<Proof>,
    },
    FlatContextClosure {
        contexts: Vec<FlatContext>,
        transformed_rules: Vec<RewriteRule>,
        proof: Box<Proof>,
    },
    DependencyPairs {
        count: usize,
    },
    DependencyPairProof {
        proof: Box<DependencyPairProof>,
    },
    ContextSensitiveDependencyPairProof {
        construction: ContextSensitiveDependencyPairConstruction,
        auxiliary_rules: Vec<RewriteRule>,
        proof: Box<DependencyPairProof>,
    },
    RelativeAnnotatedDependencyPairProof {
        proof: Box<RelativeAdpProof>,
    },
    ContextSensitiveInnermostDependencyPairProof {
        auxiliary_rules: Vec<RewriteRule>,
        proof: Box<DependencyPairProof>,
    },
    RemoveNonApplicableRules {
        removed: Vec<RewriteRule>,
        proof: Box<Proof>,
    },
    SwitchInnermost {
        wcr_depth: usize,
        proof: Box<Proof>,
    },
    AaeccInnermost {
        r1: Vec<RewriteRule>,
        r2: Vec<RewriteRule>,
        sigma: BTreeSet<Symbol>,
        wcr_depth: usize,
        proof: Box<Proof>,
    },
    SwitchContextSensitive {
        replacement_map: ReplacementMap,
        csr_rules: Vec<RewriteRule>,
        proof: Box<Proof>,
    },
    Gm04InverseContextSensitive {
        source_csr: CsrTrs,
        source_signature: BTreeMap<Symbol, usize>,
        source_replacement_map: ReplacementMap,
        active_symbol: Symbol,
        mark_symbol: Symbol,
        proper_symbol: Symbol,
        ok_symbol: Symbol,
        top_symbol: Symbol,
        top_sharp_symbol: Symbol,
        transformed_proof: Box<Proof>,
        source_proof: Box<Proof>,
    },
    Gm04InverseContextSensitiveFull {
        source_csr: CsrTrs,
        source_signature: BTreeMap<Symbol, usize>,
        source_replacement_map: ReplacementMap,
        active_symbol: Symbol,
        mark_symbol: Symbol,
        proper_symbol: Symbol,
        ok_symbol: Symbol,
        top_symbol: Symbol,
        top_sharp_symbol: Symbol,
        administrative_rules: Vec<RewriteRule>,
        wcr_depth: usize,
        administrative_proof: Box<Proof>,
        source_proof: Box<Proof>,
    },
    Gm04InverseContextSensitiveNontermination {
        source_csr: CsrTrs,
        source_signature: BTreeMap<Symbol, usize>,
        source_replacement_map: ReplacementMap,
        active_symbol: Symbol,
        mark_symbol: Symbol,
        proper_symbol: Symbol,
        ok_symbol: Symbol,
        top_symbol: Symbol,
        source_proof: Box<Proof>,
    },
    ContextSensitivePolynomialRuleRemoval {
        interpretations: Vec<(String, i64, Vec<i64>)>,
        removed: Vec<RewriteRule>,
        proof: Box<Proof>,
    },
    ContextSensitiveMatrixRuleRemoval {
        interpretations: Vec<(String, super::MatrixInterpretation)>,
        dimension: usize,
        strict_dimension: usize,
        removed: Vec<RewriteRule>,
        proof: Box<Proof>,
    },
    ContextSensitiveInnermostEquivalence {
        proof: Box<Proof>,
    },
    ContextSensitiveGmTransformation {
        mark_symbol: Symbol,
        active_symbols: BTreeMap<Symbol, Symbol>,
        transformed_rules: Vec<RewriteRule>,
        proof: Box<Proof>,
    },
    OutermostRaffelsieperZantemaTransformation {
        top_symbol: Symbol,
        up_symbol: Symbol,
        down_symbol: Symbol,
        block_symbol: Symbol,
        ground_constant: Symbol,
        flat_symbols: BTreeMap<Symbol, Symbol>,
        non_redex_patterns: Vec<Term>,
        transformed_rules: Vec<RewriteRule>,
        proof: Box<Proof>,
    },
    RuleStrengthening {
        strengthened_rules: Vec<RewriteRule>,
        proof: Box<Proof>,
    },
    StringReversal {
        reversed_rules: Vec<RewriteRule>,
        reversed_weak_rules: Vec<RewriteRule>,
        proof: Box<Proof>,
    },
    ConstantToUnary {
        variable: Variable,
        renaming: BTreeMap<Symbol, Symbol>,
        transformed_rules: Vec<RewriteRule>,
        proof: Box<Proof>,
    },
    Uncurry {
        proof: UncurryProof,
    },
    Bounds {
        proof: BoundsProof,
    },
    RelativeBounds {
        proof: BoundsProof,
        removed: Vec<RewriteRule>,
        proof_after_removal: Box<Proof>,
    },
    RfcBounds {
        proof: BoundsProof,
        initial_words: Vec<Vec<Symbol>>,
    },
    RfcAutomatonClosedBounds {
        proof: BoundsProof,
        initial_words: Vec<Vec<Symbol>>,
    },
    RfcRelativeBounds {
        proof: BoundsProof,
        initial_words: Vec<Vec<Symbol>>,
        removed: Vec<RewriteRule>,
        proof_after_removal: Box<Proof>,
    },
    RfcAutomatonClosedRelativeBounds {
        proof: BoundsProof,
        initial_words: Vec<Vec<Symbol>>,
        removed: Vec<RewriteRule>,
        proof_after_removal: Box<Proof>,
    },
    RfcMatchboxRelativeBounds {
        absolute_residual: bool,
        proof: BoundsProof,
        initial_words: Vec<Vec<Symbol>>,
        removed: Vec<RewriteRule>,
        proof_after_removal: Box<Proof>,
    },
    RfcNativeMatchboxRelativeBounds {
        proof: BoundsProof,
        initial_words: Vec<Vec<Symbol>>,
        removed: Vec<RewriteRule>,
        proof_after_removal: Box<Proof>,
    },
    Nontermination {
        proof: NonterminationProof,
    },
    Unsupported {
        reason: String,
    },
}

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub enum ContextSensitiveDependencyPairConstruction {
    Native,
    Safe,
    Improved,
    MutermUnhiding,
    MutermExpandedInnermost,
    Rta08,
    Conservative,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct Proof {
    status: Status,
    steps: Vec<ProofStep>,
}

impl Proof {
    pub fn with_status(status: Status, steps: Vec<ProofStep>) -> Self {
        Self { status, steps }
    }

    pub fn terminating(steps: Vec<ProofStep>) -> Self {
        Self {
            status: Status::Terminating,
            steps,
        }
    }

    pub fn nonterminating(proof: NonterminationProof) -> Self {
        Self {
            status: Status::Nonterminating,
            steps: vec![ProofStep::Nontermination { proof }],
        }
    }

    pub fn unknown(reason: impl Into<String>, mut steps: Vec<ProofStep>) -> Self {
        steps.push(ProofStep::Unsupported {
            reason: reason.into(),
        });
        Self {
            status: Status::Unknown,
            steps,
        }
    }

    pub fn status(&self) -> &Status {
        &self.status
    }

    pub fn steps(&self) -> &[ProofStep] {
        &self.steps
    }

    pub fn has_checkable_steps(&self) -> bool {
        self.steps
            .iter()
            .any(|step| !matches!(step, ProofStep::Unsupported { .. }))
    }

    pub fn into_steps(self) -> Vec<ProofStep> {
        self.steps
    }
}
