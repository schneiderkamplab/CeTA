use std::collections::{BTreeMap, BTreeSet};

use crate::core::{RewriteRule, RewriteStrategy, Symbol, Term, Trs, Variable};

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct RaffelsieperZantemaTransformation {
    pub top_symbol: Symbol,
    pub up_symbol: Symbol,
    pub down_symbol: Symbol,
    pub block_symbol: Symbol,
    pub ground_constant: Symbol,
    pub flat_symbols: BTreeMap<Symbol, Symbol>,
    pub non_redex_patterns: Vec<Term>,
    pub transformed: Trs,
}

/// The sound Raffelsieper-Zantema transformation from outermost rewriting to
/// full rewriting. It is finite for quasi-left-linear systems.
pub fn raffelsieper_zantema_transformation(trs: &Trs) -> Option<RaffelsieperZantemaTransformation> {
    if trs.strategy() != RewriteStrategy::Outermost {
        return None;
    }

    let arities = trs.arities();
    let occupied = arities.keys().cloned().collect::<BTreeSet<_>>();
    let linear_lhss = quasi_left_linear_basis(trs)?;
    let mut fresh = FreshNames::new(&occupied);
    let top_symbol = fresh.symbol("top");
    let up_symbol = fresh.symbol("up");
    let down_symbol = fresh.symbol("down");
    let block_symbol = fresh.symbol("block");
    let ground_constant = fresh.symbol("fresh_constant");

    let mut extended_arities = arities.clone();
    extended_arities.insert(ground_constant.clone(), 0);
    let mut flat_symbols = BTreeMap::new();
    for (symbol, arity) in &arities {
        if *arity > 0 {
            flat_symbols.insert(
                symbol.clone(),
                fresh.symbol(&format!("{}_flat", symbol.as_str())),
            );
        }
    }

    let mut complement = vec![Term::var("__rz_complement")];
    for lhs in &linear_lhss {
        let mut next = Vec::new();
        for pattern in &complement {
            next.extend(pattern_difference(pattern, lhs, &extended_arities));
        }
        complement = minimize_patterns(next);
    }
    let non_redex_patterns = complement
        .into_iter()
        .map(|term| rename_variables(&term, "__rz_s"))
        .collect::<Vec<_>>();

    let mut rules = trs
        .rules()
        .iter()
        .map(|rule| {
            RewriteRule::new(
                unary(&down_symbol, rule.lhs().clone()),
                unary(&up_symbol, rule.rhs().clone()),
            )
        })
        .collect::<Vec<_>>();
    // These variable names are part of the native CeTA reconstruction of the
    // transformed TRS. Keep them aligned with rz_generated_rules.
    let x = Term::var("__rz_reset");
    rules.push(RewriteRule::new(
        unary(&top_symbol, unary(&up_symbol, x.clone())),
        unary(&top_symbol, unary(&down_symbol, x)),
    ));

    for pattern in &non_redex_patterns {
        let Term::App { symbol, args } = pattern else {
            continue;
        };
        if args.is_empty() {
            continue;
        }
        let flat = flat_symbols.get(symbol)?;
        for active in 0..args.len() {
            let target_args = args
                .iter()
                .enumerate()
                .map(|(index, argument)| {
                    if index == active {
                        unary(&down_symbol, argument.clone())
                    } else {
                        unary(&block_symbol, argument.clone())
                    }
                })
                .collect();
            rules.push(RewriteRule::new(
                unary(&down_symbol, pattern.clone()),
                Term::App {
                    symbol: flat.clone(),
                    args: target_args,
                },
            ));
        }
    }

    for (symbol, arity) in &arities {
        if *arity == 0 {
            continue;
        }
        let flat = flat_symbols.get(symbol)?;
        let variables = (0..*arity)
            .map(|index| Term::var(format!("x{}", index + 1)))
            .collect::<Vec<_>>();
        for active in 0..*arity {
            let lhs_args = variables
                .iter()
                .enumerate()
                .map(|(index, argument)| {
                    if index == active {
                        unary(&up_symbol, argument.clone())
                    } else {
                        unary(&block_symbol, argument.clone())
                    }
                })
                .collect();
            rules.push(RewriteRule::new(
                Term::App {
                    symbol: flat.clone(),
                    args: lhs_args,
                },
                unary(
                    &up_symbol,
                    Term::App {
                        symbol: symbol.clone(),
                        args: variables.clone(),
                    },
                ),
            ));
        }
    }

    let variables = rules
        .iter()
        .flat_map(|rule| {
            rule.lhs()
                .variables()
                .into_iter()
                .chain(rule.rhs().variables())
        })
        .collect();
    let transformed = Trs::new_with_strategy(
        trs.name().map(str::to_string),
        variables,
        rules,
        RewriteStrategy::Full,
    );
    Some(RaffelsieperZantemaTransformation {
        top_symbol,
        up_symbol,
        down_symbol,
        block_symbol,
        ground_constant,
        flat_symbols,
        non_redex_patterns,
        transformed,
    })
}

fn quasi_left_linear_basis(trs: &Trs) -> Option<Vec<Term>> {
    let linear = trs
        .rules()
        .iter()
        .map(RewriteRule::lhs)
        .filter(|lhs| is_linear(lhs))
        .cloned()
        .collect::<Vec<_>>();
    if trs.rules().iter().all(|rule| {
        is_linear(rule.lhs())
            || linear
                .iter()
                .any(|basis| crate::core::match_pattern(basis, rule.lhs()).is_some())
    }) {
        Some(minimize_patterns(linear))
    } else {
        None
    }
}

fn pattern_difference(
    pattern: &Term,
    excluded: &Term,
    signature: &BTreeMap<Symbol, usize>,
) -> Vec<Term> {
    let pattern = rename_variables(pattern, "__rz_p");
    let excluded = rename_variables(excluded, "__rz_q");
    if !unifiable(&pattern, &excluded) {
        return vec![pattern];
    }
    if matches!(&excluded, Term::Var(_)) {
        return Vec::new();
    }
    if matches!(&pattern, Term::Var(_)) {
        return signature
            .iter()
            .flat_map(|(symbol, arity)| {
                let expanded = Term::App {
                    symbol: symbol.clone(),
                    args: (0..*arity)
                        .map(|index| Term::var(format!("__rz_e{index}")))
                        .collect(),
                };
                pattern_difference(&expanded, &excluded, signature)
            })
            .collect();
    }

    let (
        Term::App {
            symbol: pattern_symbol,
            args: pattern_args,
        },
        Term::App {
            symbol: excluded_symbol,
            args: excluded_args,
        },
    ) = (&pattern, &excluded)
    else {
        unreachable!()
    };
    if pattern_symbol != excluded_symbol || pattern_args.len() != excluded_args.len() {
        return vec![pattern];
    }

    let mut result = Vec::new();
    let mut prefix = Vec::new();
    for index in 0..pattern_args.len() {
        let Some(intersection) = pattern_intersection(&pattern_args[index], &excluded_args[index])
        else {
            break;
        };
        for alternative in
            pattern_difference(&pattern_args[index], &excluded_args[index], signature)
        {
            let mut args = prefix
                .iter()
                .enumerate()
                .map(|(position, argument)| {
                    rename_variables(argument, &format!("__rz_pre{position}_"))
                })
                .collect::<Vec<_>>();
            args.push(rename_variables(&alternative, "__rz_alt_"));
            args.extend(pattern_args[index + 1..].iter().enumerate().map(
                |(position, argument)| rename_variables(argument, &format!("__rz_suf{position}_")),
            ));
            result.push(rename_variables(
                &Term::App {
                    symbol: pattern_symbol.clone(),
                    args,
                },
                "__rz_d",
            ));
        }
        prefix.push(intersection);
    }
    result
}

fn pattern_intersection(lhs: &Term, rhs: &Term) -> Option<Term> {
    match (lhs, rhs) {
        (Term::Var(_), term) | (term, Term::Var(_)) => Some(term.clone()),
        (
            Term::App {
                symbol: lhs_symbol,
                args: lhs_args,
            },
            Term::App {
                symbol: rhs_symbol,
                args: rhs_args,
            },
        ) if lhs_symbol == rhs_symbol && lhs_args.len() == rhs_args.len() => Some(Term::App {
            symbol: lhs_symbol.clone(),
            args: lhs_args
                .iter()
                .zip(rhs_args)
                .map(|(left, right)| pattern_intersection(left, right))
                .collect::<Option<Vec<_>>>()?,
        }),
        _ => None,
    }
}

fn minimize_patterns(patterns: Vec<Term>) -> Vec<Term> {
    let mut unique = patterns
        .into_iter()
        .map(|term| rename_variables(&term, "__rz_m"))
        .collect::<BTreeSet<_>>()
        .into_iter()
        .collect::<Vec<_>>();
    unique.sort();
    let snapshot = unique.clone();
    unique.retain(|candidate| {
        !snapshot.iter().any(|other| {
            other != candidate && crate::core::match_pattern(other, candidate).is_some()
        })
    });
    unique
}

fn is_linear(term: &Term) -> bool {
    fn collect(term: &Term, seen: &mut BTreeSet<Variable>) -> bool {
        match term {
            Term::Var(variable) => seen.insert(variable.clone()),
            Term::App { args, .. } => args.iter().all(|arg| collect(arg, seen)),
        }
    }
    collect(term, &mut BTreeSet::new())
}

fn unifiable(lhs: &Term, rhs: &Term) -> bool {
    pattern_intersection(
        &rename_variables(lhs, "__rz_u_l"),
        &rename_variables(rhs, "__rz_u_r"),
    )
    .is_some()
}

fn rename_variables(term: &Term, prefix: &str) -> Term {
    fn rename(term: &Term, prefix: &str, names: &mut BTreeMap<Variable, Variable>) -> Term {
        match term {
            Term::Var(variable) => {
                let next = names.len();
                Term::Var(
                    names
                        .entry(variable.clone())
                        .or_insert_with(|| Variable::new(format!("{prefix}{next}")))
                        .clone(),
                )
            }
            Term::App { symbol, args } => Term::App {
                symbol: symbol.clone(),
                args: args.iter().map(|arg| rename(arg, prefix, names)).collect(),
            },
        }
    }
    rename(term, prefix, &mut BTreeMap::new())
}

fn unary(symbol: &Symbol, argument: Term) -> Term {
    Term::App {
        symbol: symbol.clone(),
        args: vec![argument],
    }
}

struct FreshNames {
    occupied: BTreeSet<Symbol>,
}

impl FreshNames {
    fn new(occupied: &BTreeSet<Symbol>) -> Self {
        Self {
            occupied: occupied.clone(),
        }
    }

    fn symbol(&mut self, preferred: &str) -> Symbol {
        let preferred_symbol = Symbol::new(preferred);
        if self.occupied.insert(preferred_symbol.clone()) {
            return preferred_symbol;
        }
        for index in 0usize.. {
            let candidate = Symbol::new(format!("__RZ_{index}_{preferred}"));
            if self.occupied.insert(candidate.clone()) {
                return candidate;
            }
        }
        unreachable!()
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    fn outermost(rules: Vec<RewriteRule>) -> Trs {
        Trs::new_with_strategy(None, BTreeSet::new(), rules, RewriteStrategy::Outermost)
    }

    #[test]
    fn rejects_non_quasi_left_linear_systems() {
        let trs = outermost(vec![RewriteRule::new(
            Term::app("f", vec![Term::var("x"), Term::var("x")]),
            Term::app("a", Vec::new()),
        )]);
        assert!(raffelsieper_zantema_transformation(&trs).is_none());
    }

    #[test]
    fn accepts_non_linear_instance_of_linear_lhs() {
        let trs = outermost(vec![
            RewriteRule::new(
                Term::app("f", vec![Term::var("x"), Term::var("y")]),
                Term::app("a", Vec::new()),
            ),
            RewriteRule::new(
                Term::app("f", vec![Term::var("x"), Term::var("x")]),
                Term::app("b", Vec::new()),
            ),
        ]);
        assert!(raffelsieper_zantema_transformation(&trs).is_some());
    }

    #[test]
    fn computes_exact_unary_non_redex_cover() {
        let f5 = (0..5).fold(Term::var("x"), |term, _| Term::app("f", vec![term]));
        let trs = outermost(vec![
            RewriteRule::new(
                Term::app("a", Vec::new()),
                Term::app("f", vec![Term::app("a", Vec::new())]),
            ),
            RewriteRule::new(f5, Term::app("b", Vec::new())),
        ]);
        let result = raffelsieper_zantema_transformation(&trs).unwrap();
        let patterns = result
            .non_redex_patterns
            .iter()
            .map(ToString::to_string)
            .collect::<BTreeSet<_>>();
        assert!(patterns.contains("b"));
        assert!(patterns.contains("fresh_constant"));
        assert!(patterns.contains("f(a)"));
        assert!(patterns.contains("f(f(f(f(b))))"));
        assert!(!patterns.iter().any(|pattern| pattern == "a"));
        assert!(
            !patterns
                .iter()
                .any(|pattern| pattern.starts_with("f(f(f(f(f("))
        );
    }

    #[test]
    fn uses_fresh_control_symbols() {
        let trs = outermost(vec![RewriteRule::new(
            Term::app("down", vec![Term::var("x")]),
            Term::app("top", vec![Term::var("x")]),
        )]);
        let result = raffelsieper_zantema_transformation(&trs).unwrap();
        assert_ne!(result.down_symbol, Symbol::new("down"));
        assert_ne!(result.top_symbol, Symbol::new("top"));
    }

    #[test]
    fn uses_native_checker_variables_for_generated_rules() {
        let trs = outermost(vec![RewriteRule::new(
            Term::app("f", vec![Term::var("source")]),
            Term::app("a", Vec::new()),
        )]);
        let result = raffelsieper_zantema_transformation(&trs).unwrap();

        assert!(result.transformed.rules().iter().any(|rule| {
            rule.lhs()
                == &unary(
                    &result.top_symbol,
                    unary(&result.up_symbol, Term::var("__rz_reset")),
                )
                && rule.rhs()
                    == &unary(
                        &result.top_symbol,
                        unary(&result.down_symbol, Term::var("__rz_reset")),
                    )
        }));

        let flat = result.flat_symbols.get(&Symbol::new("f")).unwrap();
        assert!(result.transformed.rules().iter().any(|rule| {
            rule.lhs() == &unary(flat, unary(&result.up_symbol, Term::var("x1")))
                && rule.rhs() == &unary(&result.up_symbol, Term::app("f", vec![Term::var("x1")]))
        }));
    }

    #[test]
    fn non_redex_cover_is_exact_on_small_ground_terms() {
        let trs = outermost(vec![
            RewriteRule::new(
                Term::app("f", vec![Term::app("a", Vec::new()), Term::var("x")]),
                Term::app("b", Vec::new()),
            ),
            RewriteRule::new(
                Term::app("g", vec![Term::app("b", Vec::new())]),
                Term::app("a", Vec::new()),
            ),
        ]);
        let result = raffelsieper_zantema_transformation(&trs).unwrap();
        let signature = BTreeMap::from([
            (Symbol::new("a"), 0),
            (Symbol::new("b"), 0),
            (Symbol::new("f"), 2),
            (Symbol::new("g"), 1),
            (result.ground_constant.clone(), 0),
        ]);
        for term in ground_terms(&signature, 2) {
            let is_redex = trs
                .rules()
                .iter()
                .any(|rule| crate::core::match_pattern(rule.lhs(), &term).is_some());
            let covered = result
                .non_redex_patterns
                .iter()
                .any(|pattern| crate::core::match_pattern(pattern, &term).is_some());
            assert_eq!(
                covered, !is_redex,
                "incorrect cover for {term}: {:?}",
                result.non_redex_patterns
            );
        }
    }

    fn ground_terms(signature: &BTreeMap<Symbol, usize>, depth: usize) -> Vec<Term> {
        let mut terms = signature
            .iter()
            .filter(|(_, arity)| **arity == 0)
            .map(|(symbol, _)| Term::App {
                symbol: symbol.clone(),
                args: Vec::new(),
            })
            .collect::<Vec<_>>();
        if depth == 0 {
            return terms;
        }
        let smaller = ground_terms(signature, depth - 1);
        for (symbol, arity) in signature {
            if *arity == 0 {
                continue;
            }
            let mut tuples = vec![Vec::new()];
            for _ in 0..*arity {
                tuples = tuples
                    .into_iter()
                    .flat_map(|prefix| {
                        smaller.iter().cloned().map(move |argument| {
                            let mut tuple = prefix.clone();
                            tuple.push(argument);
                            tuple
                        })
                    })
                    .collect();
            }
            terms.extend(tuples.into_iter().map(|args| Term::App {
                symbol: symbol.clone(),
                args,
            }));
        }
        terms.sort();
        terms.dedup();
        terms
    }
}
