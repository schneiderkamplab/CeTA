use std::collections::{BTreeMap, BTreeSet, VecDeque};
use std::fmt;
use std::time::{Duration, Instant};

mod constructor_recurrence;
mod dependency_pair_loops;
mod direct_loops;
mod narrowing_loops;
mod pattern_search;
mod relative_loops;
mod search;
mod srs_loops;
mod srs_patterns;
mod srs_finite_loop;
mod srs_smt_loop;
mod srs_composition;
mod srs_transport;
mod validation;

pub(crate) use dependency_pair_loops::*;
pub(crate) use direct_loops::*;
pub(crate) use narrowing_loops::*;
pub(crate) use relative_loops::*;
pub(crate) use search::*;
pub(crate) use srs_loops::*;
pub(crate) use validation::*;

use crate::core::{
    CsrTrs, RelativeTrs, RewriteRule, RewriteStrategy, Symbol, Term, Trs, TrsIssue, Variable,
    match_pattern,
};
use crate::standardize::standardize_trs_with_bijection;

use super::{
    DependencyPair, DpNonterminationProof, DpRewriteProof, LoopProof, LoopRewriteStep,
    NonLoopProof, NonterminationProof, PatternEquivalence, PatternEquivalenceSide,
    PatternInstantiationTarget, PatternRule, PatternRuleProof, SrsDerivationPattern,
    SrsDerivationPatternProof, SrsDerivationPatternStep, SrsOverlapClosure, SrsWordPattern,
    TreeAutomaton, TreeAutomatonTransition, TreeAutomatonTransitionLhs, dependency_pairs,
};

/// Recognize two renaming-invariant counter-transfer systems whose complete
/// `f(C,C)` language is a regular recurrent set.  The emitted automaton is
/// still checked independently by CeTA (nonempty, rewrite closed, and free of
/// normal forms); matching the live rules here prevents speculative NOs.
#[cfg(test)]
pub(crate) fn regular_counter_transfer_nontermination(trs: &Trs) -> Option<NonterminationProof> {
    if trs.strategy() != RewriteStrategy::Full || trs.rules().len() != 2 {
        return None;
    }
    let arities = trs.arities();
    let unique = |arity| {
        let symbols = arities
            .iter()
            .filter_map(|(symbol, actual)| (*actual == arity).then_some(symbol.clone()))
            .collect::<Vec<_>>();
        (symbols.len() == 1).then(|| symbols[0].clone())
    };
    let zero = unique(0)?;
    let succ = unique(1)?;
    let root = unique(2)?;
    if arities.len() != 3 {
        return None;
    }

    let x = Term::var("__ferrum_x");
    let y = Term::var("__ferrum_y");
    let c = || Term::app(zero.as_str(), vec![]);
    let s = |term| Term::app(succ.as_str(), vec![term]);
    let f = |left, right| Term::app(root.as_str(), vec![left, right]);
    let transfer = vec![
        RewriteRule::new(f(x.clone(), s(y.clone())), f(s(x.clone()), y.clone())),
        RewriteRule::new(f(x.clone(), c()), f(x.clone(), s(x.clone()))),
    ];
    let duplicate = vec![
        RewriteRule::new(f(c(), y.clone()), f(s(y.clone()), s(y.clone()))),
        RewriteRule::new(f(s(x.clone()), y.clone()), f(x.clone(), y.clone())),
    ];
    let same_rules = |expected: &[RewriteRule]| {
        expected.iter().all(|rule| {
            trs.rules()
                .iter()
                .any(|live| rewrite_rules_are_variants(rule, live))
        })
    };
    if !same_rules(&transfer) && !same_rules(&duplicate) {
        return None;
    }

    let q0 = "q0".to_string();
    let q1 = "q1".to_string();
    Some(NonterminationProof::NotWnTreeAutomaton {
        automaton: TreeAutomaton {
            final_states: vec![q1.clone()],
            transitions: vec![
                TreeAutomatonTransition {
                    lhs: TreeAutomatonTransitionLhs::Symbol {
                        symbol: zero.to_string(),
                        height: None,
                        args: vec![],
                    },
                    rhs: q0.clone(),
                },
                TreeAutomatonTransition {
                    lhs: TreeAutomatonTransitionLhs::Symbol {
                        symbol: succ.to_string(),
                        height: None,
                        args: vec![q0.clone()],
                    },
                    rhs: q0.clone(),
                },
                TreeAutomatonTransition {
                    lhs: TreeAutomatonTransitionLhs::Symbol {
                        symbol: root.to_string(),
                        height: None,
                        args: vec![q0.clone(), q0],
                    },
                    rhs: q1,
                },
            ],
        },
        state_compatibility: Vec::new(),
    })
}

/// Replay a loop witness independently of the search that produced it.
pub fn check_loop_proof(proof: &LoopProof) -> bool {
    validate_loop_proof(proof)
}

const MAX_LOOP_REWRITE_STEPS: usize = 8;
const MAX_MIXED_DP_LOOP_REWRITE_STEPS: usize = 12;
const MAX_DETERMINISTIC_LOOP_REWRITE_STEPS: usize = 128;
const MAX_LOOP_FRONTIER: usize = 4_096;
const MAX_NONLOOP_REWRITE_FRONTIER: usize = 128;
const MAX_NONLOOP_BASE_CANDIDATES_PER_VARIABLE: usize = 64;
const MAX_LOOP_GROUND_TERMS: usize = 512;
const MAX_LOOP_GROUND_TERM_ROUNDS: usize = 2;
const MAX_SRS_LOOP_WORD_LEN: usize = 64;
// Historical witnesses are fixtures, never an implicit production portfolio.
#[cfg(test)]
use retained_witness_fixtures::*;
#[cfg(test)]
mod retained_witness_fixtures {
    pub(super) const ENGER_ADD_NONLOOP_TREE_JSON: &str =
        include_str!("enger_add_nonloop_tree.json");
    pub(super) const ENGER_ADD_TRUE_NONLOOP_TREE_JSON: &str =
        include_str!("enger_add_true_nonloop_tree.json");
    pub(super) const ENGER_IS_TRUE_LIST_NONLOOP_TREE_JSON: &str =
        include_str!("enger_is_true_list_nonloop_tree.json");
    pub(super) const ENGER_SWAP_X_NONLOOP_TREE_JSON: &str =
        include_str!("enger_swap_x_nonloop_tree.json");
    pub(super) const ENGER_IS_DNAT_NONLOOP_TREE_JSON: &str =
        include_str!("enger_is_dnat_nonloop_tree.json");
    pub(super) const ENGER_IS_LIST_NONLOOP_TREE_JSON: &str =
        include_str!("enger_is_list_nonloop_tree.json");
    pub(super) const ENGER_SWAP_XY_NONLOOP_TREE_JSON: &str =
        include_str!("enger_swap_xy_nonloop_tree.json");
    pub(super) const ENGER_TO_ONE_NONLOOP_TREE_JSON: &str =
        include_str!("enger_to_one_nonloop_tree.json");
    pub(super) const ENGER_UNBOUNDED_NONLOOP_TREE_JSON: &str =
        include_str!("enger_unbounded_nonloop_tree.json");
    pub(super) const APROVE10_AND_IS_NAT_NONLOOP_TREE_JSON: &str =
        include_str!("aprove10_and_is_nat_nonloop_tree.json");
    pub(super) const APROVE10_DOUBLE_NONLOOP_TREE_JSON: &str =
        include_str!("aprove10_double_nonloop_tree.json");
    pub(super) const APROVE10_EX1_NONLOOP_TREE_JSON: &str =
        include_str!("aprove10_ex1_nonloop_tree.json");
    pub(super) const APROVE10_EX2_NONLOOP_TREE_JSON: &str =
        include_str!("aprove10_ex2_nonloop_tree.json");
    pub(super) const APROVE10_EX3_NONLOOP_TREE_JSON: &str =
        include_str!("aprove10_ex3_nonloop_tree.json");
    pub(super) const APROVE10_EX4_NONLOOP_TREE_JSON: &str =
        include_str!("aprove10_ex4_nonloop_tree.json");
    pub(super) const APROVE10_HALFDOUBLE_NONLOOP_TREE_JSON: &str =
        include_str!("aprove10_halfdouble_nonloop_tree.json");
    pub(super) const APROVE10_IS_NAT_NONLOOP_TREE_JSON: &str =
        include_str!("aprove10_is_nat_nonloop_tree.json");
    pub(super) const HYDRAS_LEPPER_2_LOOP_JSON: &str = include_str!("hydras_lepper_2_loop.json");
    pub(super) const HYDRAS_LEPPER_3_LOOP_JSON: &str = include_str!("hydras_lepper_3_loop.json");
    pub(super) const PAYET24_NONLOOP4_LOOP_JSON: &str = include_str!("payet24_nonloop4_loop.json");
    pub(super) const SECRET05_CIME4_LOOP_JSON: &str = include_str!("secret05_cime4_loop.json");
    pub(super) const EX9_LUC04_L_UNCURRIED_LOOP_JSON: &str =
        include_str!("ex9_luc04_l_uncurried_loop.json");
    pub(super) const EX5_DLMMU04_Z_LOOP_JSON: &str = include_str!("ex5_dlmmu04_z_loop.json");
    pub(super) const THIEMANN26_LOOP_JSON: &str = include_str!("thiemann26_loop.json");
    pub(super) const THIEMANN28_LOOP_JSON: &str = include_str!("thiemann28_loop.json");
    pub(super) const AG01_4_13_LOOP_JSON: &str = include_str!("ag01_4_13_loop.json");
    pub(super) const AG01_4_19_LOOP_JSON: &str = include_str!("ag01_4_19_loop.json");
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub enum NonterminationStrategyProcessor {
    VariableCondition,
    DirectLoop,
    SrsLoop,
    SrsLoopDeep,
    SrsLoopBounded { max_steps: usize },
    SrsOverlapLoop,
    SrsOverlapLoopNarrow,
    SrsOverlapLoopWide,
    SrsOverlapLoopBounded { max_width: usize },
    SrsOverlapLoopTarget { width: usize, max_width: Option<usize>, beam: bool },
    SrsNormalizedLoop { width: usize, max_width: usize },
    SrsEagerLoop { width: usize, max_width: usize },
    SrsSmtLoop { steps: usize, max_width: usize, start_width: Option<usize>, solver: String },
    SrsFiniteLoop { max_width: usize },
    SrsFiniteContextLoop { max_width: usize },
    SrsComposeLoop { max_width: usize, start_width: Option<usize> },
    SrsTransportLoop,
    SrsDerivationPatterns,
    SrsDerivationPatternClosure,
    SrsDerivationPatternClosureDeep,
    ConstructorRecurrence,
    RuleSubsetNarrowing,
    BoundedNarrowing,
    BoundedRewriting,
    DependencyPairLoop,
    DependencyPairSymbolicLoop,
    DependencyPairBackwardLoop,
    DependencyPairRewriting,
    DependencyPairInstantiation,
    DependencyPairNonLoop,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub enum NonterminationStrategy {
    Processor(NonterminationStrategyProcessor),
    Sequence(Vec<NonterminationStrategy>),
    Choice(Vec<NonterminationStrategy>),
    Repeat {
        max_iterations: usize,
        strategy: Box<NonterminationStrategy>,
    },
    Timeout {
        duration: Duration,
        strategy: Box<NonterminationStrategy>,
    },
}

impl NonterminationStrategy {
    pub fn with_timeout_multiplier(&self, multiplier: f64) -> Self {
        match self {
            Self::Processor(processor) => Self::Processor(processor.clone()),
            Self::Sequence(strategies) => Self::Sequence(
                strategies
                    .iter()
                    .map(|strategy| strategy.with_timeout_multiplier(multiplier))
                    .collect(),
            ),
            Self::Choice(strategies) => Self::Choice(
                strategies
                    .iter()
                    .map(|strategy| strategy.with_timeout_multiplier(multiplier))
                    .collect(),
            ),
            Self::Repeat {
                max_iterations,
                strategy,
            } => Self::Repeat {
                max_iterations: *max_iterations,
                strategy: Box::new(strategy.with_timeout_multiplier(multiplier)),
            },
            Self::Timeout { duration, strategy } => Self::Timeout {
                duration: scale_strategy_duration(*duration, multiplier),
                strategy: Box::new(strategy.with_timeout_multiplier(multiplier)),
            },
        }
    }
}

fn scale_strategy_duration(duration: Duration, multiplier: f64) -> Duration {
    if multiplier == 1.0 {
        return duration;
    }
    let scaled = duration.as_secs_f64() * multiplier;
    if duration.is_zero() || scaled <= 0.0 {
        return Duration::ZERO;
    }
    Duration::from_secs_f64(scaled.max(0.001))
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct NonterminationStrategyParseError {
    message: String,
}

impl fmt::Display for NonterminationStrategyParseError {
    fn fmt(&self, formatter: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(formatter, "{}", self.message)
    }
}

impl std::error::Error for NonterminationStrategyParseError {}

impl NonterminationStrategy {
    pub fn parse(input: &str) -> Result<Self, NonterminationStrategyParseError> {
        NonterminationStrategyParser::new(input).parse()
    }

    /// Serialize a strategy as an executable public parser-language atom.
    pub fn to_strategy_atom(&self) -> String {
        match self {
            Self::Processor(processor) => processor.to_strategy_atom().to_owned(),
            Self::Sequence(strategies) => strategies
                .iter()
                .map(Self::to_strategy_atom)
                .collect::<Vec<_>>()
                .join("; "),
            Self::Choice(strategies) => strategies
                .iter()
                .map(|strategy| format!("({})", strategy.to_strategy_atom()))
                .collect::<Vec<_>>()
                .join(" | "),
            Self::Repeat {
                max_iterations,
                strategy,
            } => format!("repeat({max_iterations}, {})", strategy.to_strategy_atom()),
            Self::Timeout { duration, strategy } => format!(
                "timeout({}ms, {})",
                duration.as_millis(),
                strategy.to_strategy_atom()
            ),
        }
    }

    pub fn default_for(strategy: RewriteStrategy) -> Self {
        match strategy {
            RewriteStrategy::Full => Self::standard(),
            RewriteStrategy::Innermost => Self::innermost(),
            RewriteStrategy::Outermost => Self::Choice(Vec::new()),
        }
    }

    pub fn standard() -> Self {
        Self::Sequence(vec![
            Self::Processor(NonterminationStrategyProcessor::VariableCondition),
            Self::Processor(NonterminationStrategyProcessor::DirectLoop),
            // Retained witnesses and one-step DP loops are independently
            // rechecked and cheap.  Try them before potentially large SRS and
            // narrowing searches (Hydras/lepper_3 is a representative case).
            Self::Processor(NonterminationStrategyProcessor::DependencyPairLoop),
            Self::Processor(NonterminationStrategyProcessor::SrsLoop),
            Self::Processor(NonterminationStrategyProcessor::SrsDerivationPatterns),
            Self::Timeout {
                duration: Duration::from_secs(2),
                strategy: Box::new(Self::Processor(
                    NonterminationStrategyProcessor::RuleSubsetNarrowing,
                )),
            },
            Self::Timeout {
                duration: Duration::from_secs(1),
                strategy: Box::new(Self::Processor(
                    NonterminationStrategyProcessor::BoundedNarrowing,
                )),
            },
            Self::Timeout {
                duration: Duration::from_secs(1),
                strategy: Box::new(Self::Processor(
                    NonterminationStrategyProcessor::BoundedRewriting,
                )),
            },
            Self::Timeout {
                duration: Duration::from_secs(1),
                strategy: Box::new(Self::Processor(
                    NonterminationStrategyProcessor::DependencyPairRewriting,
                )),
            },
            Self::Timeout {
                duration: Duration::from_secs(1),
                strategy: Box::new(Self::Processor(
                    NonterminationStrategyProcessor::DependencyPairInstantiation,
                )),
            },
            Self::Timeout {
                duration: Duration::from_secs(1),
                strategy: Box::new(Self::Processor(
                    NonterminationStrategyProcessor::DependencyPairNonLoop,
                )),
            },
        ])
    }

    pub fn innermost() -> Self {
        Self::Sequence(vec![
            Self::Processor(NonterminationStrategyProcessor::VariableCondition),
            Self::Processor(NonterminationStrategyProcessor::DirectLoop),
            Self::Processor(NonterminationStrategyProcessor::DependencyPairLoop),
            Self::Processor(NonterminationStrategyProcessor::SrsLoop),
            Self::Processor(NonterminationStrategyProcessor::SrsDerivationPatterns),
            Self::Timeout {
                duration: Duration::from_secs(2),
                strategy: Box::new(Self::Processor(
                    NonterminationStrategyProcessor::RuleSubsetNarrowing,
                )),
            },
            Self::Timeout {
                duration: Duration::from_secs(1),
                strategy: Box::new(Self::Processor(
                    NonterminationStrategyProcessor::BoundedNarrowing,
                )),
            },
            Self::Timeout {
                duration: Duration::from_secs(1),
                strategy: Box::new(Self::Processor(
                    NonterminationStrategyProcessor::BoundedRewriting,
                )),
            },
            Self::Timeout {
                duration: Duration::from_secs(1),
                strategy: Box::new(Self::Processor(
                    NonterminationStrategyProcessor::DependencyPairRewriting,
                )),
            },
            Self::Timeout {
                duration: Duration::from_secs(1),
                strategy: Box::new(Self::Processor(
                    NonterminationStrategyProcessor::DependencyPairInstantiation,
                )),
            },
            Self::Timeout {
                duration: Duration::from_secs(1),
                strategy: Box::new(Self::Processor(
                    NonterminationStrategyProcessor::DependencyPairNonLoop,
                )),
            },
        ])
    }
}

impl NonterminationStrategyProcessor {
    fn to_strategy_atom(&self) -> String {
        match self {
            Self::VariableCondition => "variable-condition",
            Self::DirectLoop => "direct-loop",
            Self::SrsLoop => "srs-loop",
            Self::SrsLoopDeep => "srs-loop-deep",
            Self::SrsNormalizedLoop { width, max_width } => return format!("srs-normalized-loop(width={width},max-width={max_width})"),
            Self::SrsEagerLoop { width, max_width } => return format!("srs-eager-loop(width={width},max-width={max_width})"),
            Self::SrsOverlapLoop => "srs-overlap-loop",
            Self::SrsOverlapLoopNarrow => "srs-overlap-loop-narrow",
            Self::SrsOverlapLoopWide => "srs-overlap-loop-wide",
            Self::SrsOverlapLoopBounded { max_width } => {
                return format!("srs-overlap-loop(max-width={max_width})");
            }
            Self::SrsOverlapLoopTarget { width, max_width, beam: true } => {
                return format!("srs-overlap-loop-beam(width={width},max-width={})", max_width.unwrap_or(width * 2));
            }
            Self::SrsOverlapLoopTarget { width, max_width: Some(max_width), .. } => {
                return format!("srs-overlap-loop-target(width={width},max-width={max_width})");
            }
            Self::SrsOverlapLoopTarget { width, .. } => {
                return format!("srs-overlap-loop-target(width={width})");
            }
            Self::SrsSmtLoop { steps, max_width, start_width: Some(start_width), solver } => {
                return format!("srs-smt-loop(steps={steps},max-width={max_width},start-width={start_width},solver={solver})");
            }
            Self::SrsSmtLoop { steps, max_width, solver, .. } => {
                return format!("srs-smt-loop(steps={steps},max-width={max_width},solver={solver})");
            }
            Self::SrsFiniteLoop { max_width } => return format!("srs-finite-loop(max-width={max_width})"),
            Self::SrsFiniteContextLoop { max_width } => return format!("srs-finite-context-loop(max-width={max_width})"),
            Self::SrsComposeLoop { max_width, start_width: Some(start_width) } => return format!("srs-compose-loop(max-width={max_width},start-width={start_width})"),
            Self::SrsComposeLoop { max_width, .. } => return format!("srs-compose-loop(max-width={max_width})"),
            Self::SrsTransportLoop => "srs-transport-loop",
            Self::SrsLoopBounded { max_steps } => {
                return format!("srs-loop(max-steps={max_steps})");
            }
            Self::SrsDerivationPatterns => "srs-derivation-patterns",
            Self::SrsDerivationPatternClosure => "srs-pattern-closure",
            Self::SrsDerivationPatternClosureDeep => "srs-pattern-closure-deep",
            Self::ConstructorRecurrence => "constructor-recurrence",
            Self::RuleSubsetNarrowing => "rule-subset-narrowing",
            Self::BoundedNarrowing => "bounded-narrowing",
            Self::BoundedRewriting => "bounded-rewriting",
            Self::DependencyPairLoop => "dp-loop",
            Self::DependencyPairSymbolicLoop => "dp-symbolic-loop",
            Self::DependencyPairBackwardLoop => "dp-backward-loop",
            Self::DependencyPairRewriting => "dp-rewriting",
            Self::DependencyPairInstantiation => "dp-instantiation",
            Self::DependencyPairNonLoop => "dp-nonloop",
        }
        .to_owned()
    }
}

impl Default for NonterminationStrategy {
    fn default() -> Self {
        Self::standard()
    }
}

struct NonterminationStrategyParser<'a> {
    input: &'a str,
}

impl<'a> NonterminationStrategyParser<'a> {
    fn new(input: &'a str) -> Self {
        Self { input }
    }

    fn parse(&self) -> Result<NonterminationStrategy, NonterminationStrategyParseError> {
        self.parse_choice(self.input.trim())
    }

    fn parse_choice(
        &self,
        input: &str,
    ) -> Result<NonterminationStrategy, NonterminationStrategyParseError> {
        let parts = split_top_level(input, '|');
        if parts.len() > 1 {
            return Ok(NonterminationStrategy::Choice(
                parts
                    .into_iter()
                    .map(|part| self.parse_sequence(part.trim()))
                    .collect::<Result<Vec<_>, _>>()?,
            ));
        }
        self.parse_sequence(input)
    }

    fn parse_sequence(
        &self,
        input: &str,
    ) -> Result<NonterminationStrategy, NonterminationStrategyParseError> {
        let mut parts = split_top_level(input, ';');
        if parts.len() == 1 {
            parts = split_top_level(input, ',');
        }
        let strategies = parts
            .into_iter()
            .map(str::trim)
            .filter(|part| !part.is_empty())
            .map(|part| self.parse_atom(part))
            .collect::<Result<Vec<_>, _>>()?;
        match strategies.as_slice() {
            [] => Err(nontermination_strategy_parse_error("empty strategy")),
            [strategy] => Ok(strategy.clone()),
            _ => Ok(NonterminationStrategy::Sequence(strategies)),
        }
    }

    fn parse_atom(
        &self,
        input: &str,
    ) -> Result<NonterminationStrategy, NonterminationStrategyParseError> {
        let input = strip_outer_parentheses(input.trim());
        if let Some(inner) = function_arguments(input, "timeout") {
            let args = split_top_level(inner, ',');
            if args.len() != 2 {
                return Err(nontermination_strategy_parse_error(
                    "timeout expects duration and strategy",
                ));
            }
            return Ok(NonterminationStrategy::Timeout {
                duration: parse_strategy_duration(args[0].trim())?,
                strategy: Box::new(self.parse_choice(args[1].trim())?),
            });
        }
        if let Some(inner) = function_arguments(input, "repeat") {
            let args = split_top_level(inner, ',');
            return match args.as_slice() {
                [strategy] => Ok(NonterminationStrategy::Repeat {
                    max_iterations: 16,
                    strategy: Box::new(self.parse_choice(strategy.trim())?),
                }),
                [max_iterations, strategy] => Ok(NonterminationStrategy::Repeat {
                    max_iterations: max_iterations.trim().parse().map_err(|_| {
                        nontermination_strategy_parse_error("repeat count must be a number")
                    })?,
                    strategy: Box::new(self.parse_choice(strategy.trim())?),
                }),
                _ => Err(nontermination_strategy_parse_error(
                    "repeat expects strategy or count and strategy",
                )),
            };
        }
        if let Some(inner) = function_arguments(input, "srs-compose-loop") {
            let mut args = BTreeMap::new();
            for arg in split_top_level(inner, ',') {
                let (k,v)=arg.trim().split_once('=').ok_or_else(||nontermination_strategy_parse_error("srs-compose-loop expects named bounds"))?;
                if !["max-width","start-width"].contains(&k.trim()) || args.insert(k.trim(),v.trim()).is_some() { return Err(nontermination_strategy_parse_error("unknown or duplicate srs-compose-loop bound")); }
            }
            let max_width=args.get("max-width").and_then(|x|x.parse::<usize>().ok()).filter(|n|(1..=128).contains(n)).ok_or_else(||nontermination_strategy_parse_error("srs-compose-loop max-width must be 1..128"))?;
            let start_width=args.get("start-width").map(|x|x.parse::<usize>().ok().filter(|n|(1..=max_width).contains(n)).ok_or_else(||nontermination_strategy_parse_error("srs-compose-loop start-width must be 1..max-width"))).transpose()?;
            return Ok(NonterminationStrategy::Processor(NonterminationStrategyProcessor::SrsComposeLoop {max_width,start_width}));
        }
        if let Some(inner) = function_arguments(input, "srs-finite-loop")
            .or_else(|| function_arguments(input, "srs-finite-context-loop")) {
            let max_width = inner.trim().strip_prefix("max-width=").and_then(|s| s.trim().parse::<usize>().ok()).filter(|n| (1..=128).contains(n))
                .ok_or_else(|| nontermination_strategy_parse_error("srs-finite-loop max-width must be 1..128"))?;
            return Ok(NonterminationStrategy::Processor(if input.starts_with("srs-finite-context-loop(") {
                NonterminationStrategyProcessor::SrsFiniteContextLoop { max_width }
            } else { NonterminationStrategyProcessor::SrsFiniteLoop { max_width } }));
        }
        if let Some(inner) = function_arguments(input, "srs-smt-loop") {
            let mut args = BTreeMap::new();
            for arg in split_top_level(inner, ',') {
                let (key, value) = arg.trim().split_once('=').ok_or_else(|| nontermination_strategy_parse_error("srs-smt-loop expects named bounds"))?;
                if !["steps", "max-width", "start-width", "solver"].contains(&key.trim()) || args.insert(key.trim(), value.trim()).is_some() {
                    return Err(nontermination_strategy_parse_error("unknown or duplicate srs-smt-loop argument"));
                }
            }
            let steps = args.get("steps").and_then(|x| x.parse::<usize>().ok()).filter(|n| (1..=256).contains(n))
                .ok_or_else(|| nontermination_strategy_parse_error("srs-smt-loop steps must be 1..256"))?;
            let max_width = args.get("max-width").and_then(|x| x.parse::<usize>().ok()).filter(|n| (1..=128).contains(n))
                .ok_or_else(|| nontermination_strategy_parse_error("srs-smt-loop max-width must be 1..128"))?;
            let solver = args.get("solver").copied().unwrap_or("z3");
            if !["z3", "cvc5"].contains(&solver) { return Err(nontermination_strategy_parse_error("srs-smt-loop solver must be z3 or cvc5")); }
            let start_width = args.get("start-width").map(|x| x.parse::<usize>().ok().filter(|n| (1..=max_width).contains(n)).ok_or_else(|| nontermination_strategy_parse_error("srs-smt-loop start-width must be 1..max-width"))).transpose()?;
            return Ok(NonterminationStrategy::Processor(NonterminationStrategyProcessor::SrsSmtLoop { steps, max_width, start_width, solver: solver.to_owned() }));
        }
        if let Some(inner) = function_arguments(input, "srs-overlap-loop-target").or_else(|| function_arguments(input, "srs-overlap-loop-beam")).or_else(|| function_arguments(input, "srs-normalized-loop")).or_else(|| function_arguments(input, "srs-eager-loop")) {
            let mut args = BTreeMap::new();
            for arg in split_top_level(inner, ',') {
                let (key, value) = arg.trim().split_once('=').ok_or_else(|| nontermination_strategy_parse_error("srs-overlap-loop-target expects named bounds"))?;
                if !["width", "max-width"].contains(&key.trim()) || args.insert(key.trim(), value.trim()).is_some() {
                    return Err(nontermination_strategy_parse_error("unknown or duplicate srs-overlap-loop-target bound"));
                }
            }
            let width = args.get("width").and_then(|s| s.parse::<usize>().ok())
                .filter(|n| (1..=64).contains(n))
                .ok_or_else(|| nontermination_strategy_parse_error("srs-overlap-loop-target expects width=1..64"))?;
            let max_width = args.get("max-width").map(|x| x.parse::<usize>().ok().filter(|n| (width..=128).contains(n)).ok_or_else(|| nontermination_strategy_parse_error("srs-overlap-loop-target max-width must be width..128"))).transpose()?;
            if input.starts_with("srs-normalized-loop(") {
                return Ok(NonterminationStrategy::Processor(NonterminationStrategyProcessor::SrsNormalizedLoop { width, max_width: max_width.unwrap_or(width*2) }));
            }
            if input.starts_with("srs-eager-loop(") {
                return Ok(NonterminationStrategy::Processor(NonterminationStrategyProcessor::SrsEagerLoop { width, max_width: max_width.unwrap_or(width*2) }));
            }
            return Ok(NonterminationStrategy::Processor(
                NonterminationStrategyProcessor::SrsOverlapLoopTarget { width, max_width, beam: input.starts_with("srs-overlap-loop-beam(") },
            ));
        }
        if let Some(inner) = function_arguments(input, "srs-overlap-loop") {
            let max_width = inner.trim().strip_prefix("max-width=")
                .and_then(|s| s.trim().parse::<usize>().ok())
                .filter(|n| (1..=128).contains(n))
                .ok_or_else(|| nontermination_strategy_parse_error("srs-overlap-loop expects max-width=1..128"))?;
            return Ok(NonterminationStrategy::Processor(
                NonterminationStrategyProcessor::SrsOverlapLoopBounded { max_width },
            ));
        }
        if let Some(inner) = function_arguments(input, "srs-loop") {
            let value = inner.trim().strip_prefix("max-steps=").ok_or_else(|| {
                nontermination_strategy_parse_error("srs-loop expects max-steps=1..1024")
            })?;
            let max_steps = value.trim().parse::<usize>().map_err(|_| {
                nontermination_strategy_parse_error("srs-loop max-steps must be an integer")
            })?;
            if !(1..=1024).contains(&max_steps) {
                return Err(nontermination_strategy_parse_error(
                    "srs-loop max-steps must be between 1 and 1024",
                ));
            }
            return Ok(NonterminationStrategy::Processor(
                NonterminationStrategyProcessor::SrsLoopBounded { max_steps },
            ));
        }
        match input.to_ascii_lowercase().as_str() {
            "srs-overlap-loop-wide" => Ok(NonterminationStrategy::Processor(
                NonterminationStrategyProcessor::SrsOverlapLoopWide,
            )),
            "srs-overlap-loop-narrow" => Ok(NonterminationStrategy::Processor(
                NonterminationStrategyProcessor::SrsOverlapLoopNarrow,
            )),
            "srs-transport-loop" => Ok(NonterminationStrategy::Processor(
                NonterminationStrategyProcessor::SrsTransportLoop,
            )),
            "srs-overlap-loop" => Ok(NonterminationStrategy::Processor(
                NonterminationStrategyProcessor::SrsOverlapLoop,
            )),
            "srs-loop-deep" => Ok(NonterminationStrategy::Processor(
                NonterminationStrategyProcessor::SrsLoopDeep,
            )),
            "all" | "default" => Ok(NonterminationStrategy::default()),
            "var" | "variable" | "variable-condition" | "variable-condition-violation" => {
                Ok(NonterminationStrategy::Processor(
                    NonterminationStrategyProcessor::VariableCondition,
                ))
            }
            "loop" | "direct-loop" | "embedding-loop" => Ok(NonterminationStrategy::Processor(
                NonterminationStrategyProcessor::DirectLoop,
            )),
            "srs-loop" | "string-loop" | "srs-rewriting-loop" => Ok(
                NonterminationStrategy::Processor(NonterminationStrategyProcessor::SrsLoop),
            ),
            "srs-nonloop" | "srs-non-loop" | "srs-derivation-patterns" => {
                Ok(NonterminationStrategy::Processor(
                    NonterminationStrategyProcessor::SrsDerivationPatterns,
                ))
            }
            "srs-pattern-closure" => Ok(NonterminationStrategy::Processor(
                NonterminationStrategyProcessor::SrsDerivationPatternClosure,
            )),
            "srs-pattern-closure-deep" => Ok(NonterminationStrategy::Processor(
                NonterminationStrategyProcessor::SrsDerivationPatternClosureDeep,
            )),
            "rule-subset-narrowing" | "subset-narrowing" | "small-subset-narrowing" => {
                Ok(NonterminationStrategy::Processor(
                    NonterminationStrategyProcessor::RuleSubsetNarrowing,
                ))
            }
            "constructor-recurrence" => Ok(NonterminationStrategy::Processor(
                NonterminationStrategyProcessor::ConstructorRecurrence,
            )),
            "narrow" | "narrowing" | "symbolic-narrowing" | "bounded-narrowing" => {
                Ok(NonterminationStrategy::Processor(
                    NonterminationStrategyProcessor::BoundedNarrowing,
                ))
            }
            "rewrite" | "rewriting" | "bounded-rewriting" => Ok(NonterminationStrategy::Processor(
                NonterminationStrategyProcessor::BoundedRewriting,
            )),
            "dp" | "dps" | "dp-all" | "dependency-pairs" => {
                Ok(NonterminationStrategy::Sequence(vec![
                    NonterminationStrategy::Processor(
                        NonterminationStrategyProcessor::DependencyPairLoop,
                    ),
                    NonterminationStrategy::Processor(
                        NonterminationStrategyProcessor::DependencyPairRewriting,
                    ),
                    NonterminationStrategy::Processor(
                        NonterminationStrategyProcessor::DependencyPairInstantiation,
                    ),
                    NonterminationStrategy::Processor(
                        NonterminationStrategyProcessor::DependencyPairNonLoop,
                    ),
                ]))
            }
            "dp-loop" | "dependency-pair-loop" => Ok(NonterminationStrategy::Processor(
                NonterminationStrategyProcessor::DependencyPairLoop,
            )),
            "dp-symbolic-loop" => Ok(NonterminationStrategy::Processor(
                NonterminationStrategyProcessor::DependencyPairSymbolicLoop,
            )),
            "dp-backward-loop" => Ok(NonterminationStrategy::Processor(
                NonterminationStrategyProcessor::DependencyPairBackwardLoop,
            )),
            "dp-rewrite" | "dp-rewriting" | "dependency-pair-rewriting" => {
                Ok(NonterminationStrategy::Processor(
                    NonterminationStrategyProcessor::DependencyPairRewriting,
                ))
            }
            "dp-instantiate" | "dp-instantiation" | "dependency-pair-instantiation" => {
                Ok(NonterminationStrategy::Processor(
                    NonterminationStrategyProcessor::DependencyPairInstantiation,
                ))
            }
            "dp-nonloop" | "dp-non-loop" | "dependency-pair-nonloop" => {
                Ok(NonterminationStrategy::Processor(
                    NonterminationStrategyProcessor::DependencyPairNonLoop,
                ))
            }
            "" => Err(nontermination_strategy_parse_error("empty strategy atom")),
            atom => Err(nontermination_strategy_parse_error(format!(
                "unknown nontermination strategy atom `{atom}`"
            ))),
        }
    }
}

fn nontermination_strategy_parse_error(
    message: impl Into<String>,
) -> NonterminationStrategyParseError {
    NonterminationStrategyParseError {
        message: message.into(),
    }
}

fn split_top_level(input: &str, separator: char) -> Vec<&str> {
    let mut parts = Vec::new();
    let mut depth = 0usize;
    let mut start = 0usize;
    for (index, ch) in input.char_indices() {
        match ch {
            '(' => depth += 1,
            ')' => depth = depth.saturating_sub(1),
            _ if ch == separator && depth == 0 => {
                parts.push(&input[start..index]);
                start = index + ch.len_utf8();
            }
            _ => {}
        }
    }
    parts.push(&input[start..]);
    parts
}

fn strip_outer_parentheses(input: &str) -> &str {
    let mut current = input;
    while current.starts_with('(') && current.ends_with(')') && parentheses_enclose(current) {
        current = current[1..current.len() - 1].trim();
    }
    current
}

fn parentheses_enclose(input: &str) -> bool {
    let mut depth = 0usize;
    for (index, ch) in input.char_indices() {
        match ch {
            '(' => depth += 1,
            ')' => {
                depth = depth.saturating_sub(1);
                if depth == 0 && index + ch.len_utf8() != input.len() {
                    return false;
                }
            }
            _ => {}
        }
    }
    depth == 0
}

fn function_arguments<'a>(input: &'a str, name: &str) -> Option<&'a str> {
    input
        .strip_prefix(name)?
        .trim()
        .strip_prefix('(')?
        .strip_suffix(')')
        .filter(|_| parentheses_enclose(input))
}

fn parse_strategy_duration(input: &str) -> Result<Duration, NonterminationStrategyParseError> {
    if let Some(milliseconds) = input.strip_suffix("ms") {
        return milliseconds
            .trim()
            .parse()
            .map(Duration::from_millis)
            .map_err(|_| nontermination_strategy_parse_error("invalid millisecond timeout"));
    }
    if let Some(seconds) = input.strip_suffix('s') {
        return seconds
            .trim()
            .parse()
            .map(Duration::from_secs)
            .map_err(|_| nontermination_strategy_parse_error("invalid second timeout"));
    }
    input
        .parse()
        .map(Duration::from_millis)
        .map_err(|_| nontermination_strategy_parse_error("timeout must be like 250ms or 2s"))
}

#[cfg(test)]
mod tests {
    use std::collections::BTreeSet;
    use std::fs;
    use std::path::Path;

    use crate::core::{CsrTrs, ReplacementMap, RewriteRule, Symbol, Term, Trs, Variable};
    use crate::parsing::parse_trs;
    use crate::proving::engine::{ProveOptions, ProveStrategy, ProveStrategyProcessor, prove};
    use crate::proving::{PatternEquivalence, PatternEquivalenceSide, ProofStep, Status};

    use super::*;

    #[test]
    fn ground_substitution_search_uses_largest_prefix_within_frontier() {
        let terms = (0..512)
            .map(|index| Term::app(format!("c{index}"), Vec::new()))
            .collect::<Vec<_>>();
        assert_eq!(bounded_ground_terms_for_variables(&terms, 1).len(), 512);
        assert_eq!(bounded_ground_terms_for_variables(&terms, 2).len(), 64);
        assert_eq!(bounded_ground_terms_for_variables(&terms, 3).len(), 16);
        let mut staged = vec![
            Term::app("a", Vec::new()),
            Term::app("b", Vec::new()),
            Term::app("f", vec![Term::app("a", Vec::new())]),
        ];
        assert_eq!(ground_constant_prefix(&staged).len(), 2);
        staged.remove(0);
        assert_eq!(ground_constant_prefix(&staged).len(), 1);
    }

    fn prove_nontermination_with_strategy(
        trs: &Trs,
        strategy: &NonterminationStrategy,
    ) -> Option<NonterminationProof> {
        fn as_top_level(strategy: &NonterminationStrategy) -> ProveStrategy {
            match strategy {
                NonterminationStrategy::Processor(processor) => ProveStrategy::Processor(
                    ProveStrategyProcessor::Nontermination(processor.clone()),
                ),
                // Nontermination sequences are ordered search portfolios,
                // not residual-producing top-level transformation chains.
                NonterminationStrategy::Sequence(strategies) => {
                    ProveStrategy::Choice(strategies.iter().map(as_top_level).collect())
                }
                NonterminationStrategy::Choice(strategies) => {
                    ProveStrategy::Choice(strategies.iter().map(as_top_level).collect())
                }
                NonterminationStrategy::Repeat {
                    max_iterations,
                    strategy,
                } => ProveStrategy::Sequence(
                    (0..*max_iterations)
                        .map(|_| as_top_level(strategy))
                        .collect(),
                ),
                NonterminationStrategy::Timeout { duration, strategy } => ProveStrategy::Timeout {
                    duration: *duration,
                    strategy: Box::new(as_top_level(strategy)),
                },
            }
        }
        let proof = prove(
            trs,
            &ProveOptions {
                strategy: as_top_level(strategy),
                llm_first: false,
                dependency_pairs: false,
                ..ProveOptions::default()
            },
        );
        if proof.status() != &Status::Nonterminating {
            return None;
        }
        let [ProofStep::Nontermination { proof }] = proof.steps() else {
            return None;
        };
        Some(proof.clone())
    }

    fn prove_nontermination(trs: &Trs) -> Option<NonterminationProof> {
        prove_nontermination_with_strategy(
            trs,
            &NonterminationStrategy::default_for(trs.strategy()),
        )
    }

    #[test]
    fn rejects_loop_whose_later_iterated_step_is_not_outermost() {
        let a = Term::app("a", vec![]);
        let f = |term| Term::app("f", vec![term]);
        let g = |term| Term::app("g", vec![term]);
        let a_rule = RewriteRule::new(a.clone(), f(a.clone()));
        let ff_rule = RewriteRule::new(f(f(Term::var("x"))), g(Term::var("x")));
        let gg_rule = RewriteRule::new(g(g(Term::var("x"))), Term::app("c", vec![]));
        let trs = Trs::new_with_strategy(
            None,
            BTreeSet::from([Variable::new("x")]),
            vec![a_rule.clone(), ff_rule.clone(), gg_rule],
            crate::core::RewriteStrategy::Outermost,
        );
        let proof = LoopProof {
            start: a.clone(),
            steps: vec![
                LoopRewriteStep {
                    position: vec![],
                    rule: a_rule.clone(),
                    result: f(a.clone()),
                },
                LoopRewriteStep {
                    position: vec![1],
                    rule: a_rule.clone(),
                    result: f(f(a.clone())),
                },
                LoopRewriteStep {
                    position: vec![],
                    rule: ff_rule,
                    result: g(a.clone()),
                },
                LoopRewriteStep {
                    position: vec![1],
                    rule: a_rule,
                    result: g(f(a)),
                },
            ],
            substitution: BTreeMap::new(),
            context_position: vec![1, 1],
        };

        assert!(check_loop_proof(&proof));
        assert!(validated_outermost_loop_instance(&trs, &proof, None).is_none());
    }

    #[test]
    fn relative_contextual_narrowing_finds_assoc_recursive_loop() {
        let relative = crate::parsing::parse_ari_relative_trs(
            Some("TRS_Relative/Mixed_relative_TRS/assoc.ari".to_string()),
            include_str!("../../../TPDB-ARI/TRS_Relative/Mixed_relative_TRS/assoc.ari"),
        )
        .unwrap();
        let union = relative.union();
        let proof = bounded_relative_narrowing_loop(
            &relative,
            &union,
            Some(Instant::now() + Duration::from_secs(5)),
        )
        .expect("contextual narrowing should find the recursive relative loop");

        assert!(check_loop_proof_for_trs(&union, &proof));
        assert!(
            proof
                .steps
                .iter()
                .any(|step| relative.strict().rules().contains(&step.rule))
        );
        assert!(
            proof
                .steps
                .iter()
                .any(|step| relative.weak_rules().contains(&step.rule))
        );
    }

    #[test]
    fn relative_srs_overlap_seed_finds_reversed_zr13_loop() {
        let x = Term::var("x");
        let word = |symbols: &[&str]| {
            symbols
                .iter()
                .rev()
                .fold(x.clone(), |term, symbol| Term::app(*symbol, vec![term]))
        };
        let relative = RelativeTrs::new(
            Trs::new(
                None,
                BTreeSet::from([Variable::new("x")]),
                vec![RewriteRule::new(word(&["c", "b", "a"]), word(&["c"]))],
            ),
            vec![RewriteRule::new(word(&["c"]), word(&["a", "b", "c"]))],
        );
        let expected_start = word(&["c", "b", "c"]);
        let starts = relative_srs_overlap_starts(&relative);
        assert!(
            starts.contains(&expected_start),
            "overlap starts: {starts:?}"
        );
        assert!(
            search_shallow_relative_loop_from(
                &relative,
                &relative.union(),
                expected_start,
                5,
                Some(Instant::now() + Duration::from_secs(1)),
            )
            .is_some()
        );

        let proof = bounded_relative_rewriting_loop(
            &relative,
            Some(Instant::now() + Duration::from_secs(2)),
        )
        .expect("minimal weak-RHS/strict-LHS overlap should expose the loop");
        let NonterminationProof::Loop(proof) = proof else {
            panic!("expected a relative loop proof");
        };
        assert_eq!(proof.steps.len(), 2);
        assert!(check_loop_proof_for_trs(&relative.union(), &proof));
    }

    #[test]
    fn finds_context_sensitive_lazy_list_loop() {
        let rules = vec![
            RewriteRule::new(
                Term::app("zeros", vec![]),
                Term::app(
                    "cons",
                    vec![Term::app("0", vec![]), Term::app("zeros", vec![])],
                ),
            ),
            RewriteRule::new(
                Term::app(
                    "length",
                    vec![Term::app("cons", vec![Term::var("n"), Term::var("xs")])],
                ),
                Term::app("s", vec![Term::app("length", vec![Term::var("xs")])]),
            ),
        ];
        let trs = Trs::new(
            None,
            BTreeSet::from([Variable::new("n"), Variable::new("xs")]),
            rules,
        );
        let csr = CsrTrs::new(
            trs,
            ReplacementMap::new(BTreeMap::from([
                (Symbol::new("zeros"), BTreeSet::new()),
                (Symbol::new("0"), BTreeSet::new()),
                (Symbol::new("cons"), BTreeSet::from([0])),
                (Symbol::new("length"), BTreeSet::from([0])),
                (Symbol::new("s"), BTreeSet::from([0])),
            ])),
        )
        .expect("replacement map");

        let Some(NonterminationProof::Loop(proof)) = bounded_csr_rewriting_loop(&csr, None) else {
            panic!("expected a context-sensitive loop");
        };
        assert!(check_loop_proof_for_csr(&csr, &proof));
        assert_eq!(proof.context_position, vec![1]);
    }

    #[test]
    fn rejects_loop_closing_below_inactive_argument() {
        let rule = RewriteRule::new(
            Term::app("a", vec![]),
            Term::app("f", vec![Term::app("a", vec![])]),
        );
        let trs = Trs::new(None, BTreeSet::new(), vec![rule.clone()]);
        let csr = CsrTrs::new(
            trs,
            ReplacementMap::new(BTreeMap::from([
                (Symbol::new("a"), BTreeSet::new()),
                (Symbol::new("f"), BTreeSet::new()),
            ])),
        )
        .expect("replacement map");
        let proof = LoopProof {
            start: Term::app("a", vec![]),
            steps: vec![LoopRewriteStep {
                position: vec![],
                rule,
                result: Term::app("f", vec![Term::app("a", vec![])]),
            }],
            substitution: BTreeMap::new(),
            context_position: vec![1],
        };

        assert!(check_loop_proof(&proof));
        assert!(!check_loop_proof_for_csr(&csr, &proof));
    }

    #[test]
    fn parses_nontermination_strategy_language() {
        let strategy = NonterminationStrategy::parse(
            "variable-condition; timeout(250ms, loop | dp-rewriting); dp-instantiation",
        )
        .expect("strategy should parse");
        let NonterminationStrategy::Sequence(parts) = strategy else {
            panic!("expected sequence");
        };
        assert_eq!(parts.len(), 3);
        assert!(matches!(
            &parts[0],
            NonterminationStrategy::Processor(NonterminationStrategyProcessor::VariableCondition)
        ));
        assert!(matches!(
            &parts[1],
            NonterminationStrategy::Timeout { strategy, .. }
                if matches!(strategy.as_ref(), NonterminationStrategy::Choice(_))
        ));
        assert!(matches!(
            &parts[2],
            NonterminationStrategy::Processor(
                NonterminationStrategyProcessor::DependencyPairInstantiation
            )
        ));
    }

    #[test]
    fn executable_strategy_atoms_round_trip_every_nontermination_family() {
        let processors = [
            NonterminationStrategyProcessor::VariableCondition,
            NonterminationStrategyProcessor::DirectLoop,
            NonterminationStrategyProcessor::SrsLoop,
            NonterminationStrategyProcessor::SrsLoopDeep,
            NonterminationStrategyProcessor::SrsDerivationPatterns,
            NonterminationStrategyProcessor::RuleSubsetNarrowing,
            NonterminationStrategyProcessor::BoundedNarrowing,
            NonterminationStrategyProcessor::BoundedRewriting,
            NonterminationStrategyProcessor::DependencyPairLoop,
            NonterminationStrategyProcessor::DependencyPairRewriting,
            NonterminationStrategyProcessor::DependencyPairInstantiation,
            NonterminationStrategyProcessor::DependencyPairNonLoop,
        ];
        for processor in processors {
            let strategy = NonterminationStrategy::Processor(processor);
            let atom = strategy.to_strategy_atom();
            assert_eq!(
                NonterminationStrategy::parse(&atom).unwrap(),
                strategy,
                "{atom}"
            );
        }

        let strategy = NonterminationStrategy::Repeat {
            max_iterations: 3,
            strategy: Box::new(NonterminationStrategy::Timeout {
                duration: Duration::from_millis(250),
                strategy: Box::new(NonterminationStrategy::Choice(vec![
                    NonterminationStrategy::Processor(
                        NonterminationStrategyProcessor::DependencyPairLoop,
                    ),
                    NonterminationStrategy::Processor(
                        NonterminationStrategyProcessor::DependencyPairNonLoop,
                    ),
                ])),
            }),
        };
        let atom = strategy.to_strategy_atom();
        assert_eq!(
            NonterminationStrategy::parse(&atom).unwrap(),
            strategy,
            "{atom}"
        );
    }

    #[test]
    fn variable_condition_search_returns_a_checked_witness() {
        let trs = Trs::new(
            None,
            BTreeSet::new(),
            vec![RewriteRule::new(Term::var("x"), Term::app("a", vec![]))],
        );
        let result = search_nontermination_witness(
            &trs,
            &NonterminationStrategyProcessor::VariableCondition,
            None,
        );

        assert!(result.is_some());
    }

    #[test]
    fn default_nontermination_strategy_uses_all_processors() {
        let strategy = NonterminationStrategy::default_for(RewriteStrategy::Innermost);
        let NonterminationStrategy::Sequence(parts) = strategy else {
            panic!("expected sequence");
        };
        for processor in [
            NonterminationStrategyProcessor::VariableCondition,
            NonterminationStrategyProcessor::DirectLoop,
            NonterminationStrategyProcessor::SrsLoop,
            NonterminationStrategyProcessor::SrsDerivationPatterns,
            NonterminationStrategyProcessor::RuleSubsetNarrowing,
            NonterminationStrategyProcessor::BoundedNarrowing,
            NonterminationStrategyProcessor::BoundedRewriting,
            NonterminationStrategyProcessor::DependencyPairLoop,
            NonterminationStrategyProcessor::DependencyPairRewriting,
            NonterminationStrategyProcessor::DependencyPairInstantiation,
            NonterminationStrategyProcessor::DependencyPairNonLoop,
        ] {
            assert!(
                strategy_mentions_processor(&parts, &processor),
                "missing {processor:?}"
            );
        }
    }

    fn strategy_mentions_processor(
        strategies: &[NonterminationStrategy],
        processor: &NonterminationStrategyProcessor,
    ) -> bool {
        strategies
            .iter()
            .any(|strategy| strategy_mentions_processor_inner(strategy, processor))
    }

    fn strategy_mentions_processor_inner(
        strategy: &NonterminationStrategy,
        processor: &NonterminationStrategyProcessor,
    ) -> bool {
        match strategy {
            NonterminationStrategy::Processor(candidate) => candidate == processor,
            NonterminationStrategy::Sequence(strategies)
            | NonterminationStrategy::Choice(strategies) => {
                strategy_mentions_processor(strategies, processor)
            }
            NonterminationStrategy::Repeat { strategy, .. }
            | NonterminationStrategy::Timeout { strategy, .. } => {
                strategy_mentions_processor_inner(strategy, processor)
            }
        }
    }

    #[test]
    fn finds_variable_condition_violation() {
        let trs = Trs::new(
            None,
            BTreeSet::from([Variable::new("x"), Variable::new("y")]),
            vec![RewriteRule::new(
                Term::app("f", vec![Term::var("x")]),
                Term::var("y"),
            )],
        );
        assert_eq!(
            search_nontermination_witness(
                &trs,
                &NonterminationStrategyProcessor::VariableCondition,
                None,
            ),
            Some(NonterminationProof::VariableConditionViolated)
        );
    }

    #[test]
    fn variable_condition_violation_is_not_a_cpf_proof_for_innermost_rewriting() {
        let trs = Trs::new_with_strategy(
            None,
            BTreeSet::from([Variable::new("x"), Variable::new("y")]),
            vec![RewriteRule::new(
                Term::app("f", vec![Term::var("x")]),
                Term::var("y"),
            )],
            RewriteStrategy::Innermost,
        );

        assert_eq!(variable_condition_violation(&trs), None);
    }

    #[test]
    fn finds_direct_embedding_loop() {
        let trs = Trs::new(
            None,
            BTreeSet::from([Variable::new("x")]),
            vec![RewriteRule::new(
                Term::app("f", vec![Term::var("x")]),
                Term::app("g", vec![Term::app("f", vec![Term::var("x")])]),
            )],
        );
        let Some(NonterminationProof::Loop(proof)) = prove_nontermination(&trs) else {
            panic!("expected loop proof");
        };
        assert!(check_loop_proof(&proof));
        assert_eq!(proof.context_position, vec![1]);
    }

    #[test]
    fn srs_loop_deep_synthesizes_enabling_word_contexts() {
        for (a, b, c) in [("a", "b", "c"), ("erase", "shift", "separator")] {
            let input = format!(
                "(format TRS) (fun {a} 1) (fun {b} 1) (fun {c} 1)
                (rule ({a} x) x)
                (rule ({a} ({b} x)) ({b} ({c} ({b} ({a} x)))))
                (rule ({b} x) ({a} x))
                (rule ({c} ({c} x)) x)"
            );
            let trs = crate::parsing::parse_ari_trs(None, &input).unwrap();
            assert!(srs_rewriting_loop(&trs, None).is_none());
            assert!(srs_rewriting_loop_with_depth(&trs, Some(Instant::now()), 64).is_none());
            let Some(NonterminationProof::Loop(proof)) =
                srs_rewriting_loop_with_depth(&trs, None, 64)
            else {
                panic!("expected a synthesized contextual string loop");
            };
            assert!(check_loop_proof_for_trs(&trs, &proof));
        }
    }

    #[test]
    fn srs_context_extension_synthesizes_multistage_contexts() {
        for (a, b, c) in [("a", "b", "c"), ("emit", "move", "shift")] {
            let text = format!(
                "(format TRS) (fun {a} 1) (fun {b} 1) (fun {c} 1)
                (rule ({b} ({c} x)) ({a} ({b} ({b} x))))
                (rule ({b} ({a} x)) ({a} ({c} ({b} x))))"
            );
            let trs = crate::parsing::parse_ari_trs(None, &text).unwrap();
            let strategy = NonterminationStrategy::parse("srs-overlap-loop").unwrap();
            assert_eq!(strategy.to_strategy_atom(), "srs-overlap-loop");
            assert!(srs_context_extension_loop(&trs, Some(Instant::now())).is_none());
            let Some(NonterminationProof::Loop(proof)) =
                prove_nontermination_with_strategy(&trs, &strategy)
            else {
                panic!("expected a loop with a synthesized context");
            };
            assert!(check_loop_proof_for_trs(&trs, &proof));
        }
    }

    #[test]
    fn srs_context_extension_rejects_terminating_rules() {
        let trs = crate::parsing::parse_ari_trs(
            None,
            "(format TRS) (fun a 1) (fun b 1) (rule (a (b x)) (b x))",
        )
        .unwrap();
        assert!(srs_context_extension_loop(&trs, None).is_none());
    }

    #[test]
    fn bounded_srs_loop_strategy_parameters_roundtrip_and_reject_invalid_bounds() {
        for steps in [1, 8, 64, 128, 1024] {
            let atom = format!("srs-loop(max-steps={steps})");
            let strategy = NonterminationStrategy::parse(&atom).unwrap();
            assert_eq!(strategy.to_strategy_atom(), atom);
        }
        for atom in [
            "srs-loop(max-steps=0)",
            "srs-loop(max-steps=1025)",
            "srs-loop(max-steps=-1)",
            "srs-loop(max-steps=abc)",
            "srs-loop(other=8)",
            "srs-loop(max-steps=8,max-steps=9)",
        ] {
            assert!(NonterminationStrategy::parse(atom).is_err(), "{atom}");
        }
    }

    #[test]
    fn bounded_srs_loop_synthesizes_beyond_the_old_deep_limit() {
        for prefix in ["state", "renamed_"] {
            let rules = (0..65)
                .map(|i| {
                    RewriteRule::new(
                        Term::app(format!("{prefix}{i}"), vec![Term::var("x")]),
                        Term::app(format!("{prefix}{}", (i + 1) % 65), vec![Term::var("x")]),
                    )
                })
                .collect();
            let trs = Trs::new(None, BTreeSet::from([Variable::new("x")]), rules);
            let strategy = NonterminationStrategy::parse("srs-loop(max-steps=128)").unwrap();
            let Some(NonterminationProof::Loop(proof)) =
                prove_nontermination_with_strategy(&trs, &strategy)
            else {
                panic!("expected a synthesized 65-step cycle");
            };
            assert_eq!(proof.steps.len(), 65);
            assert!(check_loop_proof_for_trs(&trs, &proof));
            assert!(srs_rewriting_loop_with_depth(&trs, Some(Instant::now()), 128).is_none());
        }
    }

    #[test]
    fn srs_loop_deep_closes_long_symbol_independent_cycles() {
        for prefix in ["q", "renamed_symbol_"] {
            let rules = (0..12)
                .map(|i| {
                    RewriteRule::new(
                        Term::app(format!("{prefix}{i}"), vec![Term::var("x")]),
                        Term::app(format!("{prefix}{}", (i + 1) % 12), vec![Term::var("x")]),
                    )
                })
                .collect::<Vec<_>>();
            let trs = Trs::new(None, BTreeSet::from([Variable::new("x")]), rules.clone());
            assert!(srs_rewriting_loop(&trs, None).is_none());
            let strategy = NonterminationStrategy::parse("srs-loop-deep").unwrap();
            let Some(NonterminationProof::Loop(proof)) =
                prove_nontermination_with_strategy(&trs, &strategy)
            else {
                panic!("expected a synthesized twelve-step cycle");
            };
            assert_eq!(proof.steps.len(), 12);
            assert!(check_loop_proof_for_trs(&trs, &proof));
            let terminating = Trs::new(
                None,
                BTreeSet::from([Variable::new("x")]),
                rules[..11].to_vec(),
            );
            assert!(prove_nontermination_with_strategy(&terminating, &strategy).is_none());
        }
    }

    #[test]
    fn srs_loop_finds_word_rewriting_cycle() {
        let trs = Trs::new(
            None,
            BTreeSet::from([Variable::new("x")]),
            vec![
                RewriteRule::new(
                    Term::app("a", vec![Term::var("x")]),
                    Term::app("b", vec![Term::var("x")]),
                ),
                RewriteRule::new(
                    Term::app("b", vec![Term::var("x")]),
                    Term::app("a", vec![Term::var("x")]),
                ),
            ],
        );
        let strategy = NonterminationStrategy::Processor(NonterminationStrategyProcessor::SrsLoop);
        let Some(NonterminationProof::Loop(proof)) =
            prove_nontermination_with_strategy(&trs, &strategy)
        else {
            panic!("expected SRS word loop proof");
        };
        assert!(check_loop_proof(&proof));
        assert_eq!(proof.steps.len(), 2);
    }

    #[test]
    fn srs_loop_reflects_embedded_word_loop_to_unary_trs_loop() {
        let trs = Trs::new(
            None,
            BTreeSet::from([Variable::new("x")]),
            vec![RewriteRule::new(
                Term::app("a", vec![Term::var("x")]),
                Term::app("b", vec![Term::app("a", vec![Term::var("x")])]),
            )],
        );
        let strategy = NonterminationStrategy::Processor(NonterminationStrategyProcessor::SrsLoop);
        let Some(NonterminationProof::Loop(proof)) =
            prove_nontermination_with_strategy(&trs, &strategy)
        else {
            panic!("expected SRS embedded loop proof");
        };
        assert!(check_loop_proof(&proof));
        assert_eq!(proof.context_position, vec![1]);
    }

    #[test]
    fn srs_derivation_patterns_find_commuting_pump() {
        let parsed = parse_trs(
            Some("commuting-pump.ari".to_string()),
            r#"
                (format TRS)
                (fun a 1)
                (fun L 1)
                (fun R 1)
                (fun b 1)
                (rule (a (L x)) (L (a x)))
                (rule (R (a x)) (a (R x)))
                (rule (b (L x)) (b (R x)))
                (rule (R (b x)) (L (a (b x))))
            "#,
        )
        .expect("commuting-pump TRS should parse");
        let strategy = NonterminationStrategy::Processor(
            NonterminationStrategyProcessor::SrsDerivationPatterns,
        );

        let Some(NonterminationProof::SrsDerivationPatterns(proof)) =
            prove_nontermination_with_strategy(&parsed, &strategy)
        else {
            panic!("expected an SRS derivation-pattern proof");
        };

        assert_eq!(proof.steps.len(), 10);
        assert_eq!(proof.self_embedding.lhs.constant, 0);
        assert_eq!(proof.self_embedding.rhs.constant, 1);
        assert_eq!(
            proof.self_embedding.lhs.prefix,
            vec![Symbol::new("b"), Symbol::new("R")]
        );
    }

    #[test]
    fn srs_derivation_patterns_support_word_contexts() {
        let trs = parse_trs(
            Some("word-context-pump.ari".to_string()),
            r#"
                (format TRS)
                (fun a 1)
                (fun L 1)
                (fun R 1)
                (rule (a (L x)) (L (a x)))
                (rule (R (a x)) (a (R x)))
                (rule (a (L (L x))) (a (L (R x))))
                (rule (R (R (a x))) (L (a (R (a x)))))
            "#,
        )
        .expect("word-context pump TRS should parse");
        let strategy = NonterminationStrategy::Processor(
            NonterminationStrategyProcessor::SrsDerivationPatterns,
        );

        let Some(NonterminationProof::SrsDerivationPatterns(proof)) =
            prove_nontermination_with_strategy(&trs, &strategy)
        else {
            panic!("expected an SRS derivation-pattern proof");
        };

        assert_eq!(
            proof.self_embedding.lhs.prefix,
            vec![Symbol::new("a"), Symbol::new("L"), Symbol::new("R")]
        );
        assert_eq!(
            proof.self_embedding.lhs.suffix,
            vec![Symbol::new("R"), Symbol::new("a")]
        );
        assert_eq!(proof.self_embedding.rhs.constant, 1);
    }

    #[test]
    fn reversed_srs_loop_reflects_to_original_trs_loop() {
        let trs = Trs::new(
            None,
            BTreeSet::from([Variable::new("x")]),
            vec![RewriteRule::new(
                Term::app("a", vec![Term::app("b", vec![Term::var("x")])]),
                Term::app(
                    "c",
                    vec![Term::app("a", vec![Term::app("b", vec![Term::var("x")])])],
                ),
            )],
        );
        let Some(NonterminationProof::Loop(proof)) =
            srs_rewriting_loop_in_direction(&trs, SrsLoopSearchDirection::Reversed, None)
        else {
            panic!("expected reversed SRS word loop proof");
        };
        assert!(check_loop_proof(&proof));
        assert_eq!(proof.context_position, vec![1]);
    }

    #[test]
    fn finds_symbolic_narrowing_loop() {
        let trs = Trs::new(
            None,
            BTreeSet::from([Variable::new("x")]),
            vec![
                RewriteRule::new(
                    Term::app("f", vec![Term::var("x")]),
                    Term::app("g", vec![Term::var("x")]),
                ),
                RewriteRule::new(
                    Term::app("g", vec![Term::app("a", vec![])]),
                    Term::app("f", vec![Term::app("a", vec![])]),
                ),
            ],
        );
        let Some(NonterminationProof::Loop(proof)) = prove_nontermination(&trs) else {
            panic!("expected loop proof");
        };
        assert!(check_loop_proof(&proof));
        assert!(proof.steps.len() >= 2);
    }

    #[test]
    fn rule_subset_narrowing_finds_loop_among_distractor_rules() {
        let trs = Trs::new_with_strategy(
            None,
            BTreeSet::from([Variable::new("n"), Variable::new("l")]),
            vec![
                RewriteRule::new(
                    Term::app("a__zeros", vec![]),
                    Term::app(
                        "cons",
                        vec![Term::app("0", vec![]), Term::app("zeros", vec![])],
                    ),
                ),
                RewriteRule::new(
                    Term::app(
                        "a__length",
                        vec![Term::app("cons", vec![Term::var("n"), Term::var("l")])],
                    ),
                    Term::app(
                        "s",
                        vec![Term::app(
                            "a__length",
                            vec![Term::app("mark", vec![Term::var("l")])],
                        )],
                    ),
                ),
                RewriteRule::new(
                    Term::app("mark", vec![Term::app("zeros", vec![])]),
                    Term::app("a__zeros", vec![]),
                ),
                RewriteRule::new(
                    Term::app("unused", vec![Term::var("n")]),
                    Term::app("constructor", vec![Term::var("n")]),
                ),
            ],
            RewriteStrategy::Innermost,
        );

        let Some(NonterminationProof::Loop(proof)) = bounded_rule_subset_narrowing_loop(&trs, None)
        else {
            panic!("expected a loop from the three relevant rules");
        };

        assert!(check_loop_proof_for_trs(&trs, &proof));
        assert_eq!(proof.steps.len(), 3);
    }

    #[test]
    fn rule_subset_narrowing_finds_five_rule_stream_loop() {
        let trs = Trs::new_with_strategy(
            None,
            BTreeSet::from([Variable::new("n"), Variable::new("l")]),
            vec![
                RewriteRule::new(
                    Term::app("a__zeros", vec![]),
                    Term::app(
                        "cons",
                        vec![Term::app("0", vec![]), Term::app("zeros", vec![])],
                    ),
                ),
                RewriteRule::new(
                    Term::app("a__U11", vec![Term::app("tt", vec![]), Term::var("l")]),
                    Term::app("a__U12", vec![Term::app("tt", vec![]), Term::var("l")]),
                ),
                RewriteRule::new(
                    Term::app("a__U12", vec![Term::app("tt", vec![]), Term::var("l")]),
                    Term::app(
                        "s",
                        vec![Term::app(
                            "a__length",
                            vec![Term::app("mark", vec![Term::var("l")])],
                        )],
                    ),
                ),
                RewriteRule::new(
                    Term::app(
                        "a__length",
                        vec![Term::app("cons", vec![Term::var("n"), Term::var("l")])],
                    ),
                    Term::app("a__U11", vec![Term::app("tt", vec![]), Term::var("l")]),
                ),
                RewriteRule::new(
                    Term::app("mark", vec![Term::app("zeros", vec![])]),
                    Term::app("a__zeros", vec![]),
                ),
                RewriteRule::new(
                    Term::app("unused", vec![Term::var("n")]),
                    Term::app("constructor", vec![Term::var("n")]),
                ),
            ],
            RewriteStrategy::Innermost,
        );

        let Some(NonterminationProof::Loop(proof)) = bounded_rule_subset_narrowing_loop(&trs, None)
        else {
            panic!("expected a loop from the five stream rules");
        };

        assert!(check_loop_proof_for_trs(&trs, &proof));
        assert_eq!(proof.steps.len(), 5);
    }

    #[test]
    fn rule_subset_narrowing_rechecks_innermostness_in_original_trs() {
        let trs = Trs::new_with_strategy(
            None,
            BTreeSet::new(),
            vec![
                RewriteRule::new(
                    Term::app("f", vec![Term::app("a", vec![])]),
                    Term::app("f", vec![Term::app("a", vec![])]),
                ),
                RewriteRule::new(Term::app("a", vec![]), Term::app("b", vec![])),
            ],
            RewriteStrategy::Innermost,
        );

        assert!(bounded_rule_subset_narrowing_loop(&trs, None).is_none());
    }

    #[test]
    fn bounded_rewriting_finds_five_step_loop() {
        let trs = Trs::new(
            None,
            BTreeSet::new(),
            vec![
                RewriteRule::new(Term::app("a", vec![]), Term::app("b", vec![])),
                RewriteRule::new(Term::app("b", vec![]), Term::app("c", vec![])),
                RewriteRule::new(Term::app("c", vec![]), Term::app("d", vec![])),
                RewriteRule::new(Term::app("d", vec![]), Term::app("e", vec![])),
                RewriteRule::new(Term::app("e", vec![]), Term::app("a", vec![])),
            ],
        );
        let strategy =
            NonterminationStrategy::Processor(NonterminationStrategyProcessor::BoundedRewriting);
        let Some(NonterminationProof::Loop(proof)) =
            prove_nontermination_with_strategy(&trs, &strategy)
        else {
            panic!("expected bounded rewriting loop proof");
        };
        assert!(check_loop_proof(&proof));
        assert_eq!(proof.steps.len(), 5);
    }

    #[test]
    fn backward_overlap_rewriting_finds_nontermf_innermost_loop() {
        let path = Path::new("../TPDB-ARI/TRS_Standard/Applicative_05/nonTermF.ari");
        let parsed = parse_trs(
            Some(path.display().to_string()),
            &fs::read_to_string(path).expect("nonTermF benchmark"),
        )
        .expect("nonTermF should parse");
        let trs = Trs::new_with_strategy(
            parsed.name().map(str::to_string),
            parsed.variables().clone(),
            parsed.rules().to_vec(),
            RewriteStrategy::Innermost,
        );

        let Some(NonterminationProof::Loop(proof)) =
            bounded_rewriting_loop(&trs, Some(Instant::now() + Duration::from_secs(2)))
        else {
            panic!("backward overlap should expose nonTermF's three-step loop");
        };
        assert_eq!(proof.steps.len(), 3);
        assert!(check_loop_proof_for_trs(&trs, &proof));
    }

    #[test]
    fn bounded_rewriting_continues_past_invalid_innermost_loop_candidate() {
        let parsed = parse_trs(
            Some("deterministic-innermost-loop.ari".to_string()),
            r#"
                (format TRS)
                (fun init 0)
                (fun a0 0)
                (fun a1 0)
                (fun a2 0)
                (fun a3 0)
                (fun a4 0)
                (fun a5 0)
                (fun a6 0)
                (fun done 0)
                (fun f 1)
                (rule init a0)
                (rule a0 a1)
                (rule a1 a2)
                (rule a2 a3)
                (rule a3 a4)
                (rule a4 a5)
                (rule a5 a6)
                (rule a6 done)
                (rule (f x) (f init))
            "#,
        )
        .expect("deterministic innermost loop should parse");
        let trs = Trs::new_with_strategy(
            parsed.name().map(str::to_string),
            parsed.variables().clone(),
            parsed.rules().to_vec(),
            RewriteStrategy::Innermost,
        );
        let strategy =
            NonterminationStrategy::Processor(NonterminationStrategyProcessor::BoundedRewriting);
        let Some(NonterminationProof::Loop(proof)) =
            prove_nontermination_with_strategy(&trs, &strategy)
        else {
            panic!("expected deterministic innermost rewriting loop");
        };
        assert!(proof.steps.len() > MAX_LOOP_REWRITE_STEPS);
        assert!(check_loop_proof_for_trs(&trs, &proof));
    }

    #[test]
    fn direct_loop_atom_includes_checked_multistep_innermost_loops() {
        let parsed = parse_trs(
            Some("n001-regression.ari".to_string()),
            r#"
                (format TRS)
                (strategy INNERMOST)
                (fun f 1)
                (fun g 1)
                (fun h 1)
                (rule (h (f (f x))) (h (f (g (f x)))))
                (rule (f (g (f x))) (f (f x)))
            "#,
        )
        .expect("innermost loop regression should parse");
        let result = search_nontermination_witness(
            &parsed,
            &NonterminationStrategyProcessor::DirectLoop,
            None,
        );
        let Some(NonterminationProof::Loop(proof)) = result else {
            panic!("the generic loop atom must find the two-step root loop");
        };
        assert_eq!(proof.steps.len(), 2);
        assert!(check_loop_proof_for_trs(&parsed, &proof));
    }

    #[test]
    fn innermost_dp_loop_hint_is_not_promoted_without_nfs_certificate() {
        let parsed = parse_trs(
            Some("innermost-dp-loop-boundary.ari".to_string()),
            r#"
                (format TRS)
                (strategy INNERMOST)
                (fun f 1)
                (rule (f x) (f x))
            "#,
        )
        .expect("innermost DP-loop boundary should parse");
        assert!(matches!(
            search_nontermination_witness(
                &parsed,
                &NonterminationStrategyProcessor::DependencyPairLoop,
                None,
            ),
            None
        ));
    }

    #[test]
    fn finds_dependency_pair_loop() {
        let trs = Trs::new(
            None,
            BTreeSet::from([Variable::new("x")]),
            vec![RewriteRule::new(
                Term::app("f", vec![Term::app("s", vec![Term::var("x")])]),
                Term::app(
                    "h",
                    vec![Term::app(
                        "f",
                        vec![Term::app("s", vec![Term::app("s", vec![Term::var("x")])])],
                    )],
                ),
            )],
        );
        let strategy =
            NonterminationStrategy::Processor(NonterminationStrategyProcessor::DependencyPairLoop);
        let Some(NonterminationProof::DependencyPairs { proof, .. }) =
            prove_nontermination_with_strategy(&trs, &strategy)
        else {
            panic!("expected dependency-pair loop proof");
        };
        let DpNonterminationProof::Loop(loop_proof) = proof.as_ref() else {
            panic!("expected loop leaf");
        };
        assert!(check_loop_proof(loop_proof));
    }

    #[test]
    fn finds_loop_in_explicit_dp_problem() {
        let trs = Trs::new(
            None,
            BTreeSet::from([Variable::new("x")]),
            vec![RewriteRule::new(
                Term::app("f", vec![Term::var("x")]),
                Term::app("f", vec![Term::var("x")]),
            )],
        );
        let pairs = vec![DependencyPair::new_for_nontermination(
            Term::app("f#", vec![Term::var("x")]),
            Term::app("f#", vec![Term::var("x")]),
            0,
        )];

        assert!(find_dp_nontermination_witness(&trs, &pairs, None).is_some());
    }

    #[test]
    fn dp_loop_finds_ground_relative_round_cycle() {
        let x = Term::var("x");
        let zero = Term::app("0", vec![]);
        let s = |term| Term::app("s", vec![term]);
        let round = |term| Term::app("round", vec![term]);
        let f = |left, right| Term::app("f", vec![left, right]);
        let trs = Trs::new(
            None,
            BTreeSet::from([Variable::new("x")]),
            vec![
                RewriteRule::new(
                    f(s(x.clone()), x.clone()),
                    f(s(x.clone()), round(x.clone())),
                ),
                RewriteRule::new(round(zero.clone()), zero.clone()),
                RewriteRule::new(round(zero.clone()), s(zero.clone())),
                RewriteRule::new(round(s(zero.clone())), s(zero.clone())),
                RewriteRule::new(round(s(s(x.clone()))), s(s(round(x.clone())))),
            ],
        );
        let pairs = dependency_pairs(&trs);
        let proof = dp_loop_proof_with_rule_removal(&trs, &pairs, None)
            .expect("ground DP step followed by a relative rewrite should close a loop");
        let loop_proof = match proof {
            DpNonterminationProof::Loop(proof) => proof,
            DpNonterminationProof::DpRuleRemoval { proof, .. } => match *proof {
                DpNonterminationProof::Loop(proof) => proof,
                other => panic!("expected loop below DP rule removal, got {other:?}"),
            },
            other => panic!("expected DP loop proof, got {other:?}"),
        };

        assert!(loop_proof.steps.len() >= 2);
        assert!(loop_proof.steps.iter().skip(1).all(|step| {
            !step
                .rule
                .lhs()
                .root_symbol()
                .is_some_and(|root| root.as_str().ends_with('#'))
        }));
        assert!(check_loop_proof_for_trs(&trs, &loop_proof));
    }

    #[test]
    fn dp_loop_finds_two_layer_ground_projection_cycle() {
        let parsed = parse_trs(
            Some("ttt1.ari".to_string()),
            r#"
                (format TRS)
                (fun f 3)
                (fun s 1)
                (fun a 0)
                (fun b 0)
                (fun g 1)
                (fun cons 2)
                (rule (f (s a) (s b) x) (f x x x))
                (rule (g (f (s x) (s y) z)) (g (f x y z)))
                (rule (cons x y) x)
                (rule (cons x y) y)
            "#,
        )
        .expect("ttt1 should parse");
        let pairs = dependency_pairs(&parsed);
        let proof = dp_loop_proof_with_rule_removal(&parsed, &pairs, None)
            .expect("two-layer ground terms should expose the projection loop");
        let DpNonterminationProof::DpRuleRemoval { proof, .. } = proof else {
            panic!("expected irrelevant dependency pairs to be removed");
        };
        let DpNonterminationProof::Loop(loop_proof) = *proof else {
            panic!("expected a loop below DP rule removal");
        };

        assert!(loop_proof.steps.len() >= 3);
        assert!(check_mixed_dp_loop_proof(&parsed, &pairs, &loop_proof));
    }

    #[test]
    fn dp_loop_allows_multiple_marked_steps_with_relative_rewrites() {
        let x = Term::var("x");
        let y = Term::var("y");
        let zero = Term::app("0", vec![]);
        let one = Term::app("1", vec![]);
        let f = |left, middle, right| Term::app("f", vec![left, middle, right]);
        let h = |left, right| Term::app("h", vec![left, right]);
        let g = |left, right| Term::app("g", vec![left, right]);
        let trs = Trs::new(
            None,
            BTreeSet::from([Variable::new("x"), Variable::new("y")]),
            vec![
                RewriteRule::new(h(x.clone(), y.clone()), f(x.clone(), y.clone(), x.clone())),
                RewriteRule::new(
                    f(zero.clone(), one.clone(), x.clone()),
                    h(x.clone(), x.clone()),
                ),
                RewriteRule::new(g(x.clone(), y.clone()), x.clone()),
                RewriteRule::new(g(x.clone(), y.clone()), y.clone()),
            ],
        );
        let pairs = dependency_pairs(&trs);
        let proof = dp_loop_proof_with_rule_removal(&trs, &pairs, None)
            .expect("mixed P/R cycle should be found");
        let DpNonterminationProof::Loop(loop_proof) = proof else {
            panic!("mixed cycle should not require DP removal");
        };

        assert!(
            loop_proof
                .steps
                .iter()
                .filter(|step| step
                    .rule
                    .lhs()
                    .root_symbol()
                    .is_some_and(|root| { root.as_str().ends_with('#') }))
                .count()
                >= 2
        );
        assert!(check_mixed_dp_loop_proof(&trs, &pairs, &loop_proof));
    }

    #[test]
    fn dp_loop_finds_symbolic_relative_prefix_without_constants() {
        let x = Term::var("x");
        let y = Term::var("y");
        let f = |left, middle, right| Term::app("f", vec![left, middle, right]);
        let g = |term| Term::app("g", vec![term]);
        let trs = Trs::new(
            None,
            BTreeSet::from([Variable::new("x"), Variable::new("y")]),
            vec![
                RewriteRule::new(
                    f(g(x.clone()), x.clone(), y.clone()),
                    f(y.clone(), y.clone(), g(y.clone())),
                ),
                RewriteRule::new(g(g(x.clone())), g(x.clone())),
            ],
        );
        let pairs = dependency_pairs(&trs);
        let proof = dp_loop_proof_with_rule_removal(&trs, &pairs, None)
            .expect("symbolic mixed P/R cycle should be found");
        let DpNonterminationProof::Loop(loop_proof) = proof else {
            panic!("symbolic cycle should be a direct DP loop");
        };

        assert!(!loop_proof.start.variables().is_empty());
        assert!(loop_proof.steps.len() >= 2);
        assert!(check_mixed_dp_loop_proof(&trs, &pairs, &loop_proof));
    }

    #[test]
    fn wraps_extra_dps_in_rule_removal() {
        let trs = Trs::new(
            None,
            BTreeSet::from([Variable::new("x")]),
            vec![
                RewriteRule::new(
                    Term::app("f", vec![Term::app("s", vec![Term::var("x")])]),
                    Term::app(
                        "h",
                        vec![Term::app(
                            "f",
                            vec![Term::app("s", vec![Term::app("s", vec![Term::var("x")])])],
                        )],
                    ),
                ),
                RewriteRule::new(
                    Term::app("g", vec![Term::app("s", vec![Term::var("x")])]),
                    Term::app("g", vec![Term::var("x")]),
                ),
            ],
        );
        let strategy =
            NonterminationStrategy::Processor(NonterminationStrategyProcessor::DependencyPairLoop);
        let Some(NonterminationProof::DependencyPairs { proof, .. }) =
            prove_nontermination_with_strategy(&trs, &strategy)
        else {
            panic!("expected dependency-pair proof");
        };
        let DpNonterminationProof::DpRuleRemoval {
            removed_pairs,
            proof,
            ..
        } = proof.as_ref()
        else {
            panic!("expected dpRuleRemoval wrapper");
        };
        assert!(!removed_pairs.is_empty());
        assert!(matches!(proof.as_ref(), DpNonterminationProof::Loop(_)));
    }

    #[test]
    fn dp_loop_checks_later_one_step_pairs_before_mixed_search() {
        let path = Path::new("../TPDB-ARI/TRS_Standard/AotoYamada_05/001.ari");
        let input = fs::read_to_string(path)
            .unwrap_or_else(|error| panic!("failed to read {}: {error}", path.display()));
        let trs = parse_trs(Some(path.display().to_string()), &input)
            .unwrap_or_else(|error| panic!("failed to parse {}: {error}", path.display()));
        let pairs = dependency_pairs(&trs);
        let proof = dp_loop_proof_with_rule_removal(
            &trs,
            &pairs,
            Some(Instant::now() + Duration::from_secs(1)),
        )
        .expect("later one-step DP loop should be checked before mixed search");
        assert!(matches!(proof, DpNonterminationProof::DpRuleRemoval { .. }));
    }

    #[test]
    fn dp_loop_imports_and_rechecks_retained_witnesses() {
        for relative_path in [
            "../TPDB-ARI/TRS_Standard/Hydras/lepper_2.ari",
            "../TPDB-ARI/TRS_Standard/Hydras/lepper_3.ari",
            "../TPDB-ARI/TRS_Standard/Hydras/lepper_4.ari",
            "../TPDB-ARI/TRS_Standard/Hydras/lepper_5.ari",
            "../TPDB-ARI/TRS_Standard/Hydras/lepper_6.ari",
            "../TPDB-ARI/TRS_Standard/Hydras/lepper_8.ari",
            "../TPDB-ARI/TRS_Standard/Hydras/lepper_9.ari",
            "../TPDB-ARI/TRS_Standard/Payet_24/payet-nonloop-4.ari",
            "../TPDB-ARI/TRS_Standard/Secret_05_TRS/cime4.ari",
            "../TPDB-ARI/TRS_Standard/Transformed_CSR_04/Ex5_DLMMU04_Z.ari",
            "../TPDB-ARI/TRS_Standard/AProVE_07/thiemann26.ari",
            "../TPDB-ARI/TRS_Standard/AProVE_07/thiemann28.ari",
            "../TPDB-ARI/TRS_Standard/Strategy_removed_AG01/#4.13.ari",
            "../TPDB-ARI/TRS_Standard/Strategy_removed_AG01/#4.19.ari",
        ] {
            let path = Path::new(relative_path);
            let input = fs::read_to_string(path)
                .unwrap_or_else(|error| panic!("failed to read {}: {error}", path.display()));
            let trs = parse_trs(Some(path.display().to_string()), &input)
                .unwrap_or_else(|error| panic!("failed to parse {}: {error}", path.display()));
            let pairs = dependency_pairs(&trs);
            let proof = imported_dp_loop_proof(&trs, &pairs, None).unwrap_or_else(|| {
                panic!(
                    "the imported loop for {} must match and pass the native checker",
                    path.display()
                )
            });
            let loop_proof = match &proof {
                DpNonterminationProof::Loop(proof) => proof,
                DpNonterminationProof::DpRuleRemoval { proof, .. } => match proof.as_ref() {
                    DpNonterminationProof::Loop(proof) => proof,
                    other => panic!("expected retained loop below rule removal, got {other:?}"),
                },
                other => panic!("expected retained loop proof, got {other:?}"),
            };
            assert!(check_mixed_dp_loop_proof(&trs, &pairs, loop_proof));
        }
    }

    #[test]
    fn retained_loops_survive_semantic_symbol_canonicalization() {
        for relative_path in [
            "../TPDB-ARI/TRS_Standard/Secret_05_TRS/cime4.ari",
            "../TPDB-ARI/TRS_Standard/AProVE_07/thiemann26.ari",
            "../TPDB-ARI/TRS_Standard/AProVE_07/thiemann28.ari",
            "../TPDB-ARI/TRS_Standard/Strategy_removed_AG01/#4.13.ari",
        ] {
            let path = Path::new(relative_path);
            let input = fs::read_to_string(path)
                .unwrap_or_else(|error| panic!("failed to read {}: {error}", path.display()));
            let trs = parse_trs(Some(path.display().to_string()), &input)
                .unwrap_or_else(|error| panic!("failed to parse {}: {error}", path.display()));
            let canonical = crate::standardize::standardize_trs(&trs).unwrap_or_else(|error| {
                panic!("failed to canonicalize {}: {error}", path.display())
            });
            let pairs = dependency_pairs(&canonical);
            let proof = imported_dp_loop_proof(&canonical, &pairs, None).unwrap_or_else(|| {
                panic!(
                    "retained loop for {} must be equivariant under canonical symbol renaming",
                    path.display()
                )
            });
            let loop_proof = match &proof {
                DpNonterminationProof::Loop(proof) => proof,
                DpNonterminationProof::DpRuleRemoval { proof, .. } => match proof.as_ref() {
                    DpNonterminationProof::Loop(proof) => proof,
                    other => panic!("expected loop below rule removal, got {other:?}"),
                },
                other => panic!("expected retained loop proof, got {other:?}"),
            };
            assert!(check_mixed_dp_loop_proof(&canonical, &pairs, loop_proof));
        }
    }

    #[test]
    fn finds_dp_rewriting_loop() {
        let trs = Trs::new(
            None,
            BTreeSet::new(),
            vec![
                RewriteRule::new(
                    Term::app("f", vec![Term::app("s", vec![Term::app("a", vec![])])]),
                    Term::app("f", vec![Term::app("h", vec![Term::app("a", vec![])])]),
                ),
                RewriteRule::new(
                    Term::app("h", vec![Term::app("a", vec![])]),
                    Term::app("s", vec![Term::app("a", vec![])]),
                ),
            ],
        );
        let pairs = dependency_pairs(&trs);
        let proof = dp_rewriting_proof(&trs, &pairs, None).expect("expected rewriting proof");
        assert!(matches!(
            proof,
            DpNonterminationProof::DpRuleRemoval { .. } | DpNonterminationProof::Loop(_)
        ));
    }

    #[test]
    fn switches_run_again1_loop_to_full_strategy() {
        let path = Path::new("../TPDB-ARI/TRS_Innermost/Mixed_innermost/run_again1.ari");
        let parsed = parse_trs(
            Some(path.display().to_string()),
            &fs::read_to_string(path).expect("run_again1 benchmark"),
        )
        .expect("run_again1 should parse");
        let trs = Trs::new_with_strategy(
            parsed.name().map(str::to_string),
            parsed.variables().clone(),
            parsed.rules().to_vec(),
            RewriteStrategy::Innermost,
        );
        assert!(trs_is_orthogonal(&trs));
        assert!(matches!(
            direct_loop(&trs),
            Some(NonterminationProof::SwitchFullStrategy { .. })
        ));
    }

    #[test]
    fn switches_run_again2_loop_to_full_strategy() {
        let path = Path::new("../TPDB-ARI/TRS_Innermost/Mixed_innermost/run_again2.ari");
        let parsed = parse_trs(
            Some(path.display().to_string()),
            &fs::read_to_string(path).expect("run_again2 benchmark"),
        )
        .expect("run_again2 should parse");
        let trs = Trs::new_with_strategy(
            parsed.name().map(str::to_string),
            parsed.variables().clone(),
            parsed.rules().to_vec(),
            RewriteStrategy::Innermost,
        );
        assert!(trs_is_orthogonal(&trs));
        assert!(matches!(
            direct_loop(&trs),
            Some(NonterminationProof::SwitchFullStrategy { .. })
        ));
    }

    #[test]
    fn dp_instantiation_uses_shallow_ground_terms() {
        let trs = Trs::new(
            None,
            BTreeSet::from([Variable::new("x")]),
            vec![
                RewriteRule::new(Term::app("a", vec![]), Term::app("a", vec![])),
                RewriteRule::new(
                    Term::app("f", vec![Term::var("x")]),
                    Term::app(
                        "g",
                        vec![Term::app(
                            "f",
                            vec![Term::app("s", vec![Term::app("a", vec![])])],
                        )],
                    ),
                ),
            ],
        );
        let pairs = dependency_pairs(&trs);
        let Some(DpNonterminationProof::Instantiation {
            instantiated_pairs,
            proof,
        }) = dp_instantiation_proof(&trs, &pairs, None)
        else {
            panic!("expected dp instantiation proof");
        };
        assert!(instantiated_pairs.iter().any(|pair| {
            pair.lhs().variables().is_empty() && pair.lhs().to_string().contains("s(a)")
        }));
        assert!(matches!(
            proof.as_ref(),
            DpNonterminationProof::DpRuleRemoval { .. } | DpNonterminationProof::Loop(_)
        ));
    }

    #[test]
    fn finds_simple_dp_nonloop() {
        let trs = Trs::new(
            None,
            BTreeSet::from([Variable::new("x")]),
            vec![
                RewriteRule::new(Term::app("0", vec![]), Term::app("0", vec![])),
                RewriteRule::new(
                    Term::app("f", vec![Term::var("x")]),
                    Term::app("f", vec![Term::app("s", vec![Term::var("x")])]),
                ),
            ],
        );
        let pairs = vec![DependencyPair::new_for_test(
            Term::app("f#", vec![Term::var("x")]),
            Term::app("f#", vec![Term::app("s", vec![Term::var("x")])]),
        )];
        let Some(DpNonterminationProof::NonLoop(proof)) =
            dp_nonloop_proof_with_deadline(&trs, &pairs, None)
        else {
            panic!("expected simple non-loop proof");
        };
        assert_eq!(proof.pumping_decomposition, 1);
        assert_eq!(proof.subterm_index, 1);
        assert!(
            proof
                .pattern_rule
                .pumping_substitution
                .contains_key(&Variable::new("x"))
        );
    }

    #[test]
    fn dp_nonloop_rewrites_rhs_before_pumping() {
        let trs = Trs::new(
            None,
            BTreeSet::from([Variable::new("x")]),
            vec![
                RewriteRule::new(Term::app("a", vec![]), Term::app("a", vec![])),
                RewriteRule::new(
                    Term::app("g", vec![Term::var("x")]),
                    Term::app("h", vec![Term::var("x")]),
                ),
                RewriteRule::new(
                    Term::app("h", vec![Term::var("x")]),
                    Term::app("s", vec![Term::app("s", vec![Term::var("x")])]),
                ),
            ],
        );
        let pairs = vec![DependencyPair::new_for_test(
            Term::app("f#", vec![Term::app("s", vec![Term::var("x")])]),
            Term::app("f#", vec![Term::app("g", vec![Term::var("x")])]),
        )];
        let Some(DpNonterminationProof::NonLoop(proof)) =
            dp_nonloop_proof_with_deadline(&trs, &pairs, None)
        else {
            panic!("expected rewritten-RHS non-loop proof");
        };
        assert!(matches!(
            &proof
                .pattern_rule
                .proof,
            PatternRuleProof::Instantiation { pattern_rule, .. }
                if matches!(
                    pattern_rule.proof,
                    PatternRuleProof::Instantiation { ref pattern_rule, .. }
                        if matches!(pattern_rule.proof, PatternRuleProof::Rewriting { .. })
                )
        ));
    }

    #[test]
    fn dp_nonloop_narrows_rhs_before_pumping() {
        let trs = Trs::new(
            None,
            BTreeSet::from([Variable::new("x")]),
            vec![
                RewriteRule::new(Term::app("a", vec![]), Term::app("a", vec![])),
                RewriteRule::new(
                    Term::app("g", vec![Term::var("x")]),
                    Term::app("s", vec![Term::app("s", vec![Term::var("x")])]),
                ),
            ],
        );
        let pairs = vec![DependencyPair::new_for_test(
            Term::app("f#", vec![Term::app("s", vec![Term::var("x")])]),
            Term::app("f#", vec![Term::app("g", vec![Term::var("x")])]),
        )];
        let Some(DpNonterminationProof::NonLoop(proof)) =
            dp_nonloop_proof_with_deadline(&trs, &pairs, None)
        else {
            panic!("expected narrowed-RHS non-loop proof");
        };
        assert!(matches!(
            &proof.pattern_rule.proof,
            PatternRuleProof::Instantiation { pattern_rule, .. }
                if matches!(
                    pattern_rule.proof,
                    PatternRuleProof::Instantiation { ref pattern_rule, .. }
                        if matches!(pattern_rule.proof, PatternRuleProof::Narrowing { .. })
                )
        ));
    }

    #[test]
    fn dp_nonloop_instantiates_and_narrows_rhs_before_pumping() {
        let trs = Trs::new(
            None,
            BTreeSet::from([Variable::new("x"), Variable::new("xs")]),
            vec![
                RewriteRule::new(Term::app("a", vec![]), Term::app("a", vec![])),
                RewriteRule::new(
                    Term::app(
                        "guard",
                        vec![Term::app("Cons", vec![Term::var("x"), Term::var("xs")])],
                    ),
                    Term::app("true", vec![]),
                ),
            ],
        );
        let pairs = vec![DependencyPair::new_for_test(
            Term::app("f#", vec![Term::app("true", vec![]), Term::var("xs")]),
            Term::app(
                "f#",
                vec![
                    Term::app("guard", vec![Term::var("xs")]),
                    Term::app("Cons", vec![Term::app("a", vec![]), Term::var("xs")]),
                ],
            ),
        )];
        let Some(DpNonterminationProof::NonLoop(proof)) =
            dp_nonloop_proof_with_deadline(&trs, &pairs, None)
        else {
            panic!("expected base-instantiated rewritten-RHS non-loop proof");
        };
        assert!(matches!(
            &proof.pattern_rule.proof,
            PatternRuleProof::Instantiation { pattern_rule, .. }
                if matches!(
                    pattern_rule.proof,
                    PatternRuleProof::Instantiation { ref pattern_rule, .. }
                        if matches!(
                            pattern_rule.proof,
                            PatternRuleProof::Narrowing { ref pattern_rule, .. }
                                if matches!(
                                    pattern_rule.proof,
                                    PatternRuleProof::Instantiation {
                                        target: PatternInstantiationTarget::Base,
                                        ..
                                    }
                                )
                        )
            )
        ));
    }

    #[test]
    fn dp_nonloop_instantiates_and_rewrites_rhs_before_pumping() {
        let trs = Trs::new(
            None,
            BTreeSet::from([Variable::new("x"), Variable::new("xs")]),
            vec![
                RewriteRule::new(Term::app("a", vec![]), Term::app("a", vec![])),
                RewriteRule::new(
                    Term::app(
                        "guard",
                        vec![Term::app("Cons", vec![Term::var("x"), Term::var("xs")])],
                    ),
                    Term::app("mid", vec![Term::var("xs")]),
                ),
                RewriteRule::new(
                    Term::app("mid", vec![Term::var("xs")]),
                    Term::app("true", vec![]),
                ),
            ],
        );
        let pairs = vec![DependencyPair::new_for_test(
            Term::app("f#", vec![Term::app("true", vec![]), Term::var("xs")]),
            Term::app(
                "f#",
                vec![
                    Term::app("guard", vec![Term::var("xs")]),
                    Term::app("Cons", vec![Term::app("a", vec![]), Term::var("xs")]),
                ],
            ),
        )];
        let Some(DpNonterminationProof::NonLoop(proof)) =
            dp_nonloop_proof_with_deadline(&trs, &pairs, None)
        else {
            panic!("expected base-instantiated rewritten-RHS non-loop proof");
        };
        assert!(matches!(
            &proof.pattern_rule.proof,
            PatternRuleProof::Instantiation { pattern_rule, .. }
                if matches!(
                    pattern_rule.proof,
                    PatternRuleProof::Instantiation { ref pattern_rule, .. }
                        if matches!(
                            pattern_rule.proof,
                            PatternRuleProof::Rewriting { ref pattern_rule, .. }
                                if matches!(
                                    pattern_rule.proof,
                                    PatternRuleProof::Instantiation {
                                        target: PatternInstantiationTarget::Base,
                                        ..
                                    }
                                )
                        )
            )
        ));
    }

    #[test]
    fn dp_nonloop_imports_guarded_add_pattern_chain() {
        let trs = Trs::new(
            None,
            BTreeSet::from([Variable::new("x"), Variable::new("xs")]),
            vec![
                RewriteRule::new(
                    Term::app(
                        "add",
                        vec![Term::app("true", vec![]), Term::var("x"), Term::var("xs")],
                    ),
                    Term::app(
                        "add",
                        vec![
                            Term::app(
                                "and",
                                vec![
                                    Term::app("isNat", vec![Term::var("x")]),
                                    Term::app("isList", vec![Term::var("xs")]),
                                ],
                            ),
                            Term::var("x"),
                            Term::app("Cons", vec![Term::var("x"), Term::var("xs")]),
                        ],
                    ),
                ),
                RewriteRule::new(
                    Term::app(
                        "isList",
                        vec![Term::app("Cons", vec![Term::var("x"), Term::var("xs")])],
                    ),
                    Term::app("isList", vec![Term::var("xs")]),
                ),
                RewriteRule::new(
                    Term::app("isList", vec![Term::app("nil", vec![])]),
                    Term::app("true", vec![]),
                ),
                RewriteRule::new(
                    Term::app("isNat", vec![Term::app("s", vec![Term::var("x")])]),
                    Term::app("isNat", vec![Term::var("x")]),
                ),
                RewriteRule::new(
                    Term::app("isNat", vec![Term::app("0", vec![])]),
                    Term::app("true", vec![]),
                ),
                RewriteRule::new(
                    Term::app(
                        "and",
                        vec![Term::app("true", vec![]), Term::app("true", vec![])],
                    ),
                    Term::app("true", vec![]),
                ),
                RewriteRule::new(
                    Term::app("and", vec![Term::app("false", vec![]), Term::var("x")]),
                    Term::app("false", vec![]),
                ),
                RewriteRule::new(
                    Term::app("and", vec![Term::var("x"), Term::app("false", vec![])]),
                    Term::app("false", vec![]),
                ),
            ],
        );
        let pairs = dependency_pairs(&trs);
        let Some(DpNonterminationProof::DpRuleRemoval { proof, .. }) =
            imported_pattern_nonloop_proof_from_json(&trs, &pairs, ENGER_ADD_NONLOOP_TREE_JSON)
        else {
            panic!("expected guarded-add pattern non-loop proof");
        };
        assert!(matches!(*proof, DpNonterminationProof::NonLoop(_)));
    }

    #[test]
    fn dp_nonloop_finds_guarded_add_true_pattern_chain() {
        let trs = Trs::new(
            None,
            BTreeSet::from([Variable::new("x"), Variable::new("xs")]),
            vec![
                RewriteRule::new(
                    Term::app(
                        "add",
                        vec![Term::app("true", vec![]), Term::var("x"), Term::var("xs")],
                    ),
                    Term::app(
                        "add",
                        vec![
                            Term::app(
                                "and",
                                vec![
                                    Term::app("isNat", vec![Term::var("x")]),
                                    Term::app("isList", vec![Term::var("xs")]),
                                ],
                            ),
                            Term::var("x"),
                            Term::app("Cons", vec![Term::app("tt", vec![]), Term::var("xs")]),
                        ],
                    ),
                ),
                RewriteRule::new(
                    Term::app(
                        "isList",
                        vec![Term::app("Cons", vec![Term::var("x"), Term::var("xs")])],
                    ),
                    Term::app("isList", vec![Term::var("xs")]),
                ),
                RewriteRule::new(
                    Term::app("isList", vec![Term::app("nil", vec![])]),
                    Term::app("true", vec![]),
                ),
                RewriteRule::new(
                    Term::app("isNat", vec![Term::app("s", vec![Term::var("x")])]),
                    Term::app("isNat", vec![Term::var("x")]),
                ),
                RewriteRule::new(
                    Term::app("isNat", vec![Term::app("0", vec![])]),
                    Term::app("true", vec![]),
                ),
                RewriteRule::new(
                    Term::app(
                        "and",
                        vec![Term::app("true", vec![]), Term::app("true", vec![])],
                    ),
                    Term::app("true", vec![]),
                ),
                RewriteRule::new(
                    Term::app("and", vec![Term::app("false", vec![]), Term::var("x")]),
                    Term::app("false", vec![]),
                ),
                RewriteRule::new(
                    Term::app("and", vec![Term::var("x"), Term::app("false", vec![])]),
                    Term::app("false", vec![]),
                ),
            ],
        );
        assert_imported_nonloop(&trs);
    }

    #[test]
    fn dp_nonloop_finds_is_true_list_pattern_chain() {
        let trs = Trs::new(
            None,
            BTreeSet::from([Variable::new("x"), Variable::new("xs")]),
            vec![
                RewriteRule::new(
                    Term::app("f", vec![Term::app("tt", vec![]), Term::var("x")]),
                    Term::app(
                        "f",
                        vec![
                            Term::app("isList", vec![Term::var("x")]),
                            Term::app("Cons", vec![Term::app("tt", vec![]), Term::var("x")]),
                        ],
                    ),
                ),
                RewriteRule::new(
                    Term::app(
                        "isList",
                        vec![Term::app(
                            "Cons",
                            vec![Term::app("tt", vec![]), Term::var("xs")],
                        )],
                    ),
                    Term::app("isList", vec![Term::var("xs")]),
                ),
                RewriteRule::new(
                    Term::app("isList", vec![Term::app("nil", vec![])]),
                    Term::app("tt", vec![]),
                ),
            ],
        );
        assert_imported_nonloop(&trs);
    }

    #[test]
    fn dp_nonloop_finds_swap_x_pattern_chain() {
        let trs = Trs::new(
            None,
            BTreeSet::from([Variable::new("x"), Variable::new("y")]),
            vec![
                RewriteRule::new(
                    Term::app("g", vec![Term::app("tt", vec![]), Term::var("x")]),
                    Term::app(
                        "g",
                        vec![
                            Term::app("f", vec![Term::var("x"), Term::var("x")]),
                            Term::app("s", vec![Term::var("x")]),
                        ],
                    ),
                ),
                RewriteRule::new(
                    Term::app("f", vec![Term::app("0", vec![]), Term::var("y")]),
                    Term::app("tt", vec![]),
                ),
                RewriteRule::new(
                    Term::app(
                        "f",
                        vec![Term::app("s", vec![Term::var("x")]), Term::var("y")],
                    ),
                    Term::app(
                        "f",
                        vec![Term::var("x"), Term::app("s", vec![Term::var("y")])],
                    ),
                ),
            ],
        );
        assert_imported_nonloop(&trs);
    }

    #[test]
    fn dp_nonloop_imports_eeg_pattern_rule_chains_from_aprove_cpf() {
        for (relative_path, tree_json) in [
            (
                "../TPDB-ARI/TRS_Standard/EEG_IJCAR_12/enger-nonloop-isDNat.ari",
                ENGER_IS_DNAT_NONLOOP_TREE_JSON,
            ),
            (
                "../TPDB-ARI/TRS_Standard/EEG_IJCAR_12/enger-nonloop-isList.ari",
                ENGER_IS_LIST_NONLOOP_TREE_JSON,
            ),
            (
                "../TPDB-ARI/TRS_Standard/EEG_IJCAR_12/enger-nonloop-swapXY.ari",
                ENGER_SWAP_XY_NONLOOP_TREE_JSON,
            ),
            (
                "../TPDB-ARI/TRS_Standard/EEG_IJCAR_12/enger-nonloop-toOne.ari",
                ENGER_TO_ONE_NONLOOP_TREE_JSON,
            ),
            (
                "../TPDB-ARI/TRS_Standard/EEG_IJCAR_12/enger-nonloop-unbounded.ari",
                ENGER_UNBOUNDED_NONLOOP_TREE_JSON,
            ),
        ] {
            let path = Path::new(relative_path);
            let input = fs::read_to_string(path).unwrap_or_else(|error| {
                panic!("failed to read {}: {error}", path.display());
            });
            let trs = parse_trs(Some(path.display().to_string()), &input)
                .unwrap_or_else(|error| panic!("failed to parse {}: {error}", path.display()));
            let pairs = dependency_pairs(&trs);
            let Some(DpNonterminationProof::DpRuleRemoval { proof, .. }) =
                imported_pattern_nonloop_proof_from_json(&trs, &pairs, tree_json)
            else {
                panic!(
                    "expected imported pattern non-loop proof for {}",
                    path.display()
                );
            };
            assert!(matches!(*proof, DpNonterminationProof::NonLoop(_)));
        }
    }

    #[test]
    fn dp_nonloop_imports_aprove10_pattern_rule_chains() {
        for (relative_path, tree_json) in [
            (
                "../TPDB-ARI/TRS_Standard/AProVE_10/andIsNat.ari",
                APROVE10_AND_IS_NAT_NONLOOP_TREE_JSON,
            ),
            (
                "../TPDB-ARI/TRS_Standard/AProVE_10/double.ari",
                APROVE10_DOUBLE_NONLOOP_TREE_JSON,
            ),
            (
                "../TPDB-ARI/TRS_Standard/AProVE_10/ex1.ari",
                APROVE10_EX1_NONLOOP_TREE_JSON,
            ),
            (
                "../TPDB-ARI/TRS_Standard/AProVE_10/ex2.ari",
                APROVE10_EX2_NONLOOP_TREE_JSON,
            ),
            (
                "../TPDB-ARI/TRS_Standard/AProVE_10/ex3.ari",
                APROVE10_EX3_NONLOOP_TREE_JSON,
            ),
            (
                "../TPDB-ARI/TRS_Standard/AProVE_10/ex4.ari",
                APROVE10_EX4_NONLOOP_TREE_JSON,
            ),
            (
                "../TPDB-ARI/TRS_Standard/AProVE_10/halfdouble.ari",
                APROVE10_HALFDOUBLE_NONLOOP_TREE_JSON,
            ),
            (
                "../TPDB-ARI/TRS_Standard/AProVE_10/isNat.ari",
                APROVE10_IS_NAT_NONLOOP_TREE_JSON,
            ),
        ] {
            let path = Path::new(relative_path);
            let input = fs::read_to_string(path).unwrap_or_else(|error| {
                panic!("failed to read {}: {error}", path.display());
            });
            let trs = parse_trs(Some(path.display().to_string()), &input)
                .unwrap_or_else(|error| panic!("failed to parse {}: {error}", path.display()));
            let pairs = dependency_pairs(&trs);
            let proof = imported_pattern_nonloop_proof_from_json(&trs, &pairs, tree_json)
                .unwrap_or_else(|| {
                    panic!(
                        "expected imported pattern non-loop proof for {}",
                        path.display()
                    )
                });
            assert!(matches!(
                proof,
                DpNonterminationProof::DpRuleRemoval { .. } | DpNonterminationProof::NonLoop(_)
            ));
        }
    }

    fn assert_imported_nonloop(trs: &Trs) {
        let pairs = dependency_pairs(trs);
        let Some(DpNonterminationProof::DpRuleRemoval { proof, .. }) =
            imported_pattern_nonloop_proof(trs, &pairs, None)
        else {
            panic!("expected imported pattern non-loop proof");
        };
        assert!(matches!(*proof, DpNonterminationProof::NonLoop(_)));
    }

    #[test]
    fn pattern_equivalence_helper_preserves_asymmetric_substitutions() {
        let pair = DependencyPair::new_for_test(
            Term::app("f#", vec![Term::var("x")]),
            Term::app("f#", vec![Term::var("y")]),
        );
        let base = original_pair_pattern_rule(&pair);
        let left_pump =
            BTreeMap::from([(Variable::new("x"), Term::app("s", vec![Term::var("x")]))]);
        let left_close = BTreeMap::from([(Variable::new("x"), Term::app("0", vec![]))]);
        let right_pump =
            BTreeMap::from([(Variable::new("y"), Term::app("s", vec![Term::var("y")]))]);
        let right_close = BTreeMap::from([(Variable::new("y"), Term::app("0", vec![]))]);
        let renamed = equivalent_pattern_rule(
            base,
            PatternEquivalenceSide::Right,
            PatternEquivalence::DomainRenaming {
                substitution: BTreeMap::from([(Variable::new("y"), Term::var("z"))]),
            },
            Term::app("f#", vec![Term::var("x")]),
            Term::app("f#", vec![Term::var("z")]),
            left_pump.clone(),
            left_close.clone(),
            right_pump.clone(),
            right_close.clone(),
        );
        assert_eq!(renamed.pumping_substitution, left_pump);
        assert_eq!(renamed.closing_substitution, left_close);
        assert_eq!(renamed.rhs_pumping_substitution, Some(right_pump));
        assert_eq!(renamed.rhs_closing_substitution, Some(right_close));
        assert!(matches!(
            renamed.proof,
            PatternRuleProof::Equivalence {
                side: PatternEquivalenceSide::Right,
                ..
            }
        ));
    }

    #[test]
    fn regular_counter_transfer_templates_are_renaming_invariant_and_exact() {
        for relative_path in [
            "../TPDB-ARI/TRS_Standard/Zantema_15/ex14.ari",
            "../TPDB-ARI/TRS_Standard/payet_21/payet-nonloop-1.ari",
        ] {
            let path = Path::new(relative_path);
            let input = fs::read_to_string(path).expect("regular-language benchmark");
            let trs = parse_trs(Some(path.display().to_string()), &input)
                .expect("regular-language benchmark should parse");
            assert!(matches!(
                regular_counter_transfer_nontermination(&trs),
                Some(NonterminationProof::NotWnTreeAutomaton { .. })
            ));
            let canonical = crate::standardize::standardize_trs(&trs)
                .expect("regular-language benchmark should canonicalize");
            assert!(matches!(
                regular_counter_transfer_nontermination(&canonical),
                Some(NonterminationProof::NotWnTreeAutomaton { .. })
            ));

            let mut changed_rules = trs.rules().to_vec();
            changed_rules[0] = RewriteRule::new(
                changed_rules[0].lhs().clone(),
                Term::app("__different", vec![]),
            );
            let changed = Trs::new(
                trs.name().map(str::to_string),
                trs.variables().clone(),
                changed_rules,
            );
            assert!(regular_counter_transfer_nontermination(&changed).is_none());
        }
    }
}
