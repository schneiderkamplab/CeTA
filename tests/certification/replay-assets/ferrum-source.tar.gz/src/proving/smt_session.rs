use std::collections::HashMap;
use std::io::{self, BufRead, BufReader, Write};
use std::process::{Child, ChildStdin, Command, Stdio};
use std::sync::atomic::{AtomicU64, Ordering};
use std::sync::mpsc::{self, Receiver, RecvTimeoutError, TryRecvError};
use std::sync::{Mutex, OnceLock};
use std::thread;
use std::time::{Duration, Instant};

use super::runtime::{
    configure_managed_child, current_thread_cancelled, terminate_child_process_group,
};

const MAX_IDLE_SESSIONS_PER_SOLVER: usize = 4;
const RESPONSE_POLL_INTERVAL: Duration = Duration::from_millis(10);

static SESSION_POOL: OnceLock<Mutex<HashMap<SessionKey, Vec<PersistentSmtSession>>>> =
    OnceLock::new();
static QUERY_ID: AtomicU64 = AtomicU64::new(1);

#[derive(Clone, Debug, Eq, Hash, PartialEq)]
struct SessionKey {
    command: String,
    args: Vec<String>,
}

#[derive(Debug)]
pub(crate) struct PersistentSmtOutput {
    pub(crate) stdout: String,
    pub(crate) reused_session: bool,
}

struct PersistentSmtSession {
    child: Child,
    stdin: ChildStdin,
    stdout_lines: Receiver<io::Result<String>>,
}

impl PersistentSmtSession {
    fn spawn(key: &SessionKey) -> io::Result<Self> {
        let mut command = Command::new(&key.command);
        command.args(&key.args);
        command
            .stdin(Stdio::piped())
            .stdout(Stdio::piped())
            .stderr(Stdio::piped());
        configure_managed_child(&mut command);
        let mut child = command.spawn()?;
        let stdin = child
            .stdin
            .take()
            .ok_or_else(|| io::Error::other("persistent SMT solver has no stdin"))?;
        let stdout = child
            .stdout
            .take()
            .ok_or_else(|| io::Error::other("persistent SMT solver has no stdout"))?;
        let stderr = child
            .stderr
            .take()
            .ok_or_else(|| io::Error::other("persistent SMT solver has no stderr"))?;

        let (line_sender, stdout_lines) = mpsc::channel();
        thread::spawn(move || {
            for line in BufReader::new(stdout).lines() {
                let disconnected = line_sender.send(line).is_err();
                if disconnected {
                    break;
                }
            }
        });
        thread::spawn(move || {
            let _ = io::copy(&mut BufReader::new(stderr), &mut io::sink());
        });

        Ok(Self {
            child,
            stdin,
            stdout_lines,
        })
    }

    fn is_alive(&mut self) -> io::Result<bool> {
        Ok(self.child.try_wait()?.is_none())
    }

    fn is_reusable(&mut self) -> io::Result<bool> {
        if !self.is_alive()? {
            return Ok(false);
        }
        match self.stdout_lines.try_recv() {
            Err(TryRecvError::Empty) => Ok(true),
            Ok(_) | Err(TryRecvError::Disconnected) => Ok(false),
        }
    }

    fn query(
        &mut self,
        script: &str,
        deadline: Option<Instant>,
        reset: bool,
    ) -> io::Result<Option<String>> {
        if script.contains("(exit)") {
            return Err(io::Error::new(
                io::ErrorKind::InvalidInput,
                "persistent SMT query must not contain (exit)",
            ));
        }
        let query_id = QUERY_ID.fetch_add(1, Ordering::Relaxed);
        let marker = format!("ferrum_smt_response_{}_{}", std::process::id(), query_id);

        if reset {
            self.stdin.write_all(b"(reset)\n")?;
        }
        self.stdin.write_all(script.as_bytes())?;
        if !script.ends_with('\n') {
            self.stdin.write_all(b"\n")?;
        }
        writeln!(self.stdin, "(echo \"{marker}\")")?;
        self.stdin.flush()?;

        let mut stdout = String::new();
        loop {
            if deadline.is_some_and(|deadline| Instant::now() >= deadline)
                || current_thread_cancelled()
            {
                return Ok(None);
            }
            let wait = deadline
                .map(|deadline| deadline.saturating_duration_since(Instant::now()))
                .map(|remaining| remaining.min(RESPONSE_POLL_INTERVAL))
                .unwrap_or(RESPONSE_POLL_INTERVAL);
            match self.stdout_lines.recv_timeout(wait) {
                Ok(Ok(line)) => {
                    let trimmed = line.trim();
                    if trimmed == marker || trimmed == format!("(echo \"{marker}\")") {
                        return Ok(Some(stdout));
                    }
                    stdout.push_str(&line);
                    stdout.push('\n');
                }
                Ok(Err(error)) => return Err(error),
                Err(RecvTimeoutError::Timeout) => {}
                Err(RecvTimeoutError::Disconnected) => {
                    return Err(io::Error::new(
                        io::ErrorKind::BrokenPipe,
                        "persistent SMT solver closed stdout",
                    ));
                }
            }
        }
    }

    fn terminate(&mut self) {
        terminate_child_process_group(&mut self.child);
        let _ = self.child.wait();
    }
}

pub(crate) struct PersistentSmtLease {
    key: SessionKey,
    session: Option<PersistentSmtSession>,
    reused_session: bool,
    healthy: bool,
}

impl PersistentSmtLease {
    pub(crate) fn reused_session(&self) -> bool {
        self.reused_session
    }

    pub(crate) fn reset_and_query(
        &mut self,
        script: &str,
        deadline: Option<Instant>,
    ) -> io::Result<Option<String>> {
        self.query(script, deadline, true)
    }

    pub(crate) fn query_incremental(
        &mut self,
        script: &str,
        deadline: Option<Instant>,
    ) -> io::Result<Option<String>> {
        self.query(script, deadline, false)
    }

    fn query(
        &mut self,
        script: &str,
        deadline: Option<Instant>,
        reset: bool,
    ) -> io::Result<Option<String>> {
        if !self.healthy {
            return Err(io::Error::new(
                io::ErrorKind::BrokenPipe,
                "persistent SMT lease is no longer usable",
            ));
        }
        let result = self
            .session
            .as_mut()
            .ok_or_else(|| io::Error::other("persistent SMT lease has no solver"))?
            .query(script, deadline, reset);
        if !matches!(result, Ok(Some(_))) {
            self.healthy = false;
            if let Some(mut session) = self.session.take() {
                session.terminate();
            }
        }
        result
    }
}

impl Drop for PersistentSmtLease {
    fn drop(&mut self) {
        let Some(mut session) = self.session.take() else {
            return;
        };
        if !self.healthy || !session.is_reusable().unwrap_or(false) {
            session.terminate();
            return;
        }
        let Ok(mut pool) = SESSION_POOL
            .get_or_init(|| Mutex::new(HashMap::new()))
            .lock()
        else {
            session.terminate();
            return;
        };
        let idle = pool.entry(self.key.clone()).or_default();
        if idle.len() < MAX_IDLE_SESSIONS_PER_SOLVER {
            idle.push(session);
        }
    }
}

pub(crate) fn acquire_persistent_smt_session(
    command: &str,
    args: &[&str],
) -> io::Result<PersistentSmtLease> {
    acquire_persistent_smt_session_with_reuse(command, args, true)
}

fn acquire_persistent_smt_session_with_reuse(
    command: &str,
    args: &[&str],
    allow_reuse: bool,
) -> io::Result<PersistentSmtLease> {
    let key = SessionKey {
        command: command.to_string(),
        args: args.iter().map(|arg| (*arg).to_string()).collect(),
    };
    let mut reused_session = false;
    let session = loop {
        if !allow_reuse {
            break PersistentSmtSession::spawn(&key)?;
        }
        let candidate = SESSION_POOL
            .get_or_init(|| Mutex::new(HashMap::new()))
            .lock()
            .map_err(|_| io::Error::other("persistent SMT session pool is poisoned"))?
            .get_mut(&key)
            .and_then(Vec::pop);
        let Some(mut candidate) = candidate else {
            break PersistentSmtSession::spawn(&key)?;
        };
        if candidate.is_reusable()? {
            reused_session = true;
            break candidate;
        }
    };
    Ok(PersistentSmtLease {
        key,
        session: Some(session),
        reused_session,
        healthy: true,
    })
}

impl Drop for PersistentSmtSession {
    fn drop(&mut self) {
        self.terminate();
    }
}

pub(crate) fn run_persistent_smt_script(
    command: &str,
    args: &[&str],
    script: &str,
    deadline: Option<Instant>,
) -> io::Result<Option<PersistentSmtOutput>> {
    let mut last_error = None;
    for attempt in 0..2 {
        // A reset query can safely be replayed, but retrying a different
        // pooled process can encounter another stale session. The recovery
        // attempt must start a fresh solver. Incremental queries are never
        // replayed because their preceding assertion context would be lost.
        let mut lease = acquire_persistent_smt_session_with_reuse(command, args, attempt == 0)?;
        let reused_session = lease.reused_session();
        match lease.reset_and_query(script, deadline) {
            Ok(output) => {
                return Ok(output.map(|stdout| PersistentSmtOutput {
                    stdout,
                    reused_session,
                }));
            }
            Err(error) if attempt == 0 => last_error = Some(error),
            Err(error) => return Err(error),
        }
    }
    Err(last_error.unwrap_or_else(|| io::Error::other("persistent SMT query failed")))
}

#[cfg(test)]
mod tests {
    use super::*;

    const FAKE_SOLVER: &str = r#"
while IFS= read -r line; do
  case "$line" in
    "(check-sat)") printf 'sat\n' ;;
    "(get-model)") printf '(model (define-fun process_id () Int %s))\n' "$$" ;;
    "(echo "*) printf '%s\n' "$line" ;;
  esac
done
"#;

    #[test]
    fn reset_query_recovery_bypasses_other_stale_pooled_sessions() {
        let solver = format!("resets=0\n{}", FAKE_SOLVER.replace(
            "case \"$line\" in",
            "case \"$line\" in\n    \"(reset)\") resets=$((resets + 1)); if [ \"$resets\" -gt 1 ]; then exit 0; fi ;;",
        ));
        let deadline = || Some(Instant::now() + Duration::from_secs(5));
        let mut first = acquire_persistent_smt_session("sh", &["-c", &solver]).unwrap();
        let mut second = acquire_persistent_smt_session("sh", &["-c", &solver]).unwrap();
        for lease in [&mut first, &mut second] {
            assert_eq!(lease.reset_and_query("(check-sat)\n", deadline()).unwrap().unwrap().trim(), "sat");
        }
        drop(first);
        drop(second);
        let result = run_persistent_smt_script("sh", &["-c", &solver], "(check-sat)\n", deadline())
            .unwrap().unwrap();
        assert_eq!(result.stdout.trim(), "sat");
        assert!(!result.reused_session);
    }

    #[test]
    fn persistent_session_reuses_the_same_solver_process() {
        let deadline = || Some(Instant::now() + Duration::from_secs(2));
        let first = run_persistent_smt_script(
            "sh",
            &["-c", FAKE_SOLVER],
            "(check-sat)\n(get-model)\n",
            deadline(),
        )
        .expect("fake solver should start")
        .expect("fake solver should answer");
        let second = run_persistent_smt_script(
            "sh",
            &["-c", FAKE_SOLVER],
            "(check-sat)\n(get-model)\n",
            deadline(),
        )
        .expect("fake solver should remain usable")
        .expect("fake solver should answer again");

        assert!(!first.reused_session);
        assert!(second.reused_session);
        assert_eq!(first.stdout, second.stdout);
        assert!(first.stdout.starts_with("sat\n(model"));
    }

    #[test]
    fn persistent_session_rejects_exit_commands() {
        let result = run_persistent_smt_script(
            "sh",
            &["-c", FAKE_SOLVER],
            "(exit)\n",
            Some(Instant::now() + Duration::from_secs(2)),
        );

        assert!(result.is_err());
    }

    #[test]
    fn timed_out_lease_is_poisoned_and_cannot_be_reused() {
        const SLOW_SOLVER: &str = r#"
while IFS= read -r line; do
  case "$line" in
    "(check-sat)") sleep 1; printf 'sat\n' ;;
    "(echo "*) printf '%s\n' "$line" ;;
  esac
done
"#;
        let mut lease = acquire_persistent_smt_session("sh", &["-c", SLOW_SOLVER])
            .expect("slow fake solver should start");
        let timed_out = lease
            .reset_and_query(
                "(check-sat)\n",
                Some(Instant::now() + Duration::from_millis(30)),
            )
            .expect("timeout is a normal empty result");
        assert!(timed_out.is_none());
        assert!(
            lease
                .reset_and_query(
                    "(check-sat)\n",
                    Some(Instant::now() + Duration::from_secs(1)),
                )
                .is_err(),
            "a timed-out solver must never return to the pool"
        );
    }

    #[test]
    fn persistent_z3_session_handles_reset_and_model_queries() {
        if Command::new("z3").arg("--version").output().is_err() {
            return;
        }
        let query = "(set-logic QF_BV)\n\
            (declare-fun x () (_ BitVec 2))\n\
            (assert (= x #b10))\n\
            (check-sat)\n\
            (get-model)\n";
        let deadline = || Some(Instant::now() + Duration::from_secs(5));
        let first = run_persistent_smt_script("z3", &["-in"], query, deadline())
            .expect("z3 should start")
            .expect("z3 should answer");
        let second = run_persistent_smt_script("z3", &["-in"], query, deadline())
            .expect("z3 should remain usable after reset")
            .expect("z3 should answer again");

        assert!(first.stdout.starts_with("sat\n"));
        assert!(first.stdout.contains("define-fun x"));
        assert!(second.stdout.starts_with("sat\n"));
        // A concurrent query may legitimately lease the first idle Z3 process.
        // Reuse itself is asserted with the uniquely keyed fake solver above.
    }

    #[test]
    fn persistent_z3_lease_preserves_assertions_until_reset() {
        if Command::new("z3").arg("--version").output().is_err() {
            return;
        }
        let deadline = || Some(Instant::now() + Duration::from_secs(5));
        let mut lease = acquire_persistent_smt_session("z3", &["-in"])
            .expect("z3 persistent lease should start");
        let first = lease
            .reset_and_query(
                "(set-logic QF_LIA)\n(declare-fun x () Int)\n(assert (= x 1))\n(check-sat)\n",
                deadline(),
            )
            .expect("initial query should succeed")
            .expect("initial query should answer");
        let incremental = lease
            .query_incremental("(assert (= x 2))\n(check-sat)\n", deadline())
            .expect("incremental query should succeed")
            .expect("incremental query should answer");
        let reset = lease
            .reset_and_query(
                "(set-logic QF_LIA)\n(declare-fun x () Int)\n(assert (= x 2))\n(check-sat)\n",
                deadline(),
            )
            .expect("reset query should succeed")
            .expect("reset query should answer");

        assert_eq!(first.trim(), "sat");
        assert_eq!(incremental.trim(), "unsat");
        assert_eq!(reset.trim(), "sat");
    }

    #[test]
    fn persistent_z3_pool_survives_concurrent_reset_queries() {
        if Command::new("z3").arg("--version").output().is_err() {
            return;
        }
        let workers = (0..16)
            .map(|index| {
                thread::spawn(move || {
                    let query = format!(
                        "(set-logic QF_LIA)\n(declare-fun x () Int)\n(assert (= x {index}))\n(check-sat)\n(get-model)\n"
                    );
                    run_persistent_smt_script(
                        "z3",
                        &["-in"],
                        &query,
                        // Test reset isolation under concurrency, not process
                        // startup throughput on a loaded shared machine.
                        Some(Instant::now() + Duration::from_secs(30)),
                    )
                    .expect("concurrent persistent query should not break the pool")
                    .expect("concurrent persistent query should answer")
                    .stdout
                })
            })
            .collect::<Vec<_>>();
        for worker in workers {
            assert!(
                worker
                    .join()
                    .expect("SMT worker should not panic")
                    .starts_with("sat\n")
            );
        }
    }
}
