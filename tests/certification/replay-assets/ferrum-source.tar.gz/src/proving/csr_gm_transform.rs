use std::collections::{BTreeMap, BTreeSet};

use crate::core::{CsrTrs, RewriteRule, Symbol, Term, Trs};

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct CsrGmTransformation {
    pub mark_symbol: Symbol,
    pub active_symbols: BTreeMap<Symbol, Symbol>,
    pub transformed: Trs,
}

/// The termination-sound, incomplete CSR-to-TRS transformation of
/// Giesl and Middeldorp. Replacing positions are traversed; frozen arguments
/// remain ordinary terms.
pub fn csr_gm_transformation(csr: &CsrTrs) -> CsrGmTransformation {
    let arities = csr.trs().arities();
    let occupied = arities.keys().cloned().collect::<BTreeSet<_>>();
    let mark_symbol = fresh_symbol("mark", &occupied);
    let defined = csr.trs().defined_symbols();
    let mut used = occupied.clone();
    used.insert(mark_symbol.clone());
    let mut active_symbols = BTreeMap::new();
    for symbol in &defined {
        let candidate = format!("{}Active", symbol.as_str());
        let active = fresh_symbol(&candidate, &used);
        used.insert(active.clone());
        active_symbols.insert(symbol.clone(), active);
    }

    let mut rules = Vec::new();
    for rule in csr.rules() {
        rules.push(RewriteRule::new(
            activate_lhs_root(rule.lhs(), &active_symbols),
            activate_term(csr, rule.rhs(), &active_symbols, &mark_symbol, true),
        ));
    }

    for (symbol, arity) in &arities {
        let variables = (0..*arity)
            .map(|index| Term::var(format!("__csr_gm_x{}", index + 1)))
            .collect::<Vec<_>>();
        let marked_arguments = variables
            .iter()
            .enumerate()
            .map(|(index, argument)| {
                if csr.replacement_map().is_allowed(symbol, index) {
                    Term::app(mark_symbol.as_str(), vec![argument.clone()])
                } else {
                    argument.clone()
                }
            })
            .collect::<Vec<_>>();
        let marked_root = active_symbols.get(symbol).unwrap_or(symbol);
        rules.push(RewriteRule::new(
            Term::app(
                mark_symbol.as_str(),
                vec![Term::app(symbol.as_str(), variables.clone())],
            ),
            Term::app(marked_root.as_str(), marked_arguments),
        ));
        if let Some(active) = active_symbols.get(symbol) {
            rules.push(RewriteRule::new(
                Term::app(active.as_str(), variables.clone()),
                Term::app(symbol.as_str(), variables),
            ));
        }
    }

    CsrGmTransformation {
        mark_symbol,
        active_symbols,
        transformed: Trs::new(
            csr.trs().name().map(str::to_string),
            csr.trs().variables().clone(),
            rules,
        ),
    }
}

fn activate_lhs_root(term: &Term, active_symbols: &BTreeMap<Symbol, Symbol>) -> Term {
    match term {
        Term::Var(variable) => Term::Var(variable.clone()),
        Term::App { symbol, args } => Term::app(
            active_symbols.get(symbol).unwrap_or(symbol).as_str(),
            args.clone(),
        ),
    }
}

fn activate_term(
    csr: &CsrTrs,
    term: &Term,
    active_symbols: &BTreeMap<Symbol, Symbol>,
    mark_symbol: &Symbol,
    active: bool,
) -> Term {
    match term {
        Term::Var(variable) if active => {
            Term::app(mark_symbol.as_str(), vec![Term::Var(variable.clone())])
        }
        Term::Var(variable) => Term::Var(variable.clone()),
        Term::App { symbol, args } => {
            let root = if active {
                active_symbols.get(symbol).unwrap_or(symbol)
            } else {
                symbol
            };
            Term::app(
                root.as_str(),
                args.iter()
                    .enumerate()
                    .map(|(index, argument)| {
                        activate_term(
                            csr,
                            argument,
                            active_symbols,
                            mark_symbol,
                            active && csr.replacement_map().is_allowed(symbol, index),
                        )
                    })
                    .collect(),
            )
        }
    }
}

fn fresh_symbol(preferred: &str, occupied: &BTreeSet<Symbol>) -> Symbol {
    let preferred = Symbol::new(preferred);
    if !occupied.contains(&preferred) {
        return preferred;
    }
    for index in 0usize.. {
        let candidate = Symbol::new(format!("__CSR_GM_{index}_{}", preferred.as_str()));
        if !occupied.contains(&candidate) {
            return candidate;
        }
    }
    unreachable!()
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::core::{ReplacementMap, Variable};

    fn small_csr() -> CsrTrs {
        let trs = Trs::new(
            None,
            BTreeSet::from([Variable::new("x"), Variable::new("y")]),
            vec![RewriteRule::new(
                Term::app("f", vec![Term::var("x"), Term::var("y")]),
                Term::app(
                    "c",
                    vec![Term::app("f", vec![Term::var("x"), Term::var("y")])],
                ),
            )],
        );
        CsrTrs::new(
            trs,
            ReplacementMap::new(BTreeMap::from([
                (Symbol::new("f"), BTreeSet::from([0])),
                (Symbol::new("c"), BTreeSet::from([0])),
            ])),
        )
        .unwrap()
    }

    #[test]
    fn gm_transform_only_activates_replacing_positions() {
        let result = csr_gm_transformation(&small_csr());
        let rules = result
            .transformed
            .rules()
            .iter()
            .map(ToString::to_string)
            .collect::<BTreeSet<_>>();
        assert!(rules.contains("fActive(x, y) -> c(fActive(mark(x), y))"));
        assert!(rules.contains(
            "mark(f(__csr_gm_x1, __csr_gm_x2)) -> fActive(mark(__csr_gm_x1), __csr_gm_x2)"
        ));
        assert!(rules.contains("fActive(__csr_gm_x1, __csr_gm_x2) -> f(__csr_gm_x1, __csr_gm_x2)"));
    }

    #[test]
    fn gm_transform_uses_fresh_auxiliary_symbols() {
        let mut csr = small_csr();
        let mut rules = csr.rules().to_vec();
        rules.push(RewriteRule::new(
            Term::app("mark", vec![Term::var("x")]),
            Term::app("fActive", vec![Term::var("x"), Term::var("x")]),
        ));
        let trs = Trs::new(None, csr.trs().variables().clone(), rules);
        let arities = trs.arities();
        let map = ReplacementMap::new(
            arities
                .into_iter()
                .map(|(symbol, arity)| (symbol, (0..arity).collect()))
                .collect(),
        );
        csr = CsrTrs::new(trs, map).unwrap();
        let result = csr_gm_transformation(&csr);
        assert_ne!(result.mark_symbol, Symbol::new("mark"));
        assert_ne!(
            result.active_symbols[&Symbol::new("f")],
            Symbol::new("fActive")
        );
    }
}
