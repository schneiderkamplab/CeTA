mod csr_gm_transform;
mod dependency_pairs;
pub(crate) use dependency_pairs::DpProblemContext;
mod engine;
mod interpretation;
mod nontermination;
mod outermost_transform;
pub(crate) use nontermination::rewrite_rules_are_variants;
mod processors;
pub(crate) use processors::csr::recognition::Gm04InverseCsr;
pub(crate) use processors::dp::{alpha_equivalent_rules, rebind_standalone_rule_variables};
mod proof;
mod runtime;
mod smt_session;

pub(crate) use csr_gm_transform::csr_gm_transformation;
pub(crate) use dependency_pairs::muterm_innermost_unhiding_rules;
pub use dependency_pairs::{
    ArcticMatrixDomain, DependencyPair, DependencyPairProof, DpArgumentFilter,
    DpArgumentFilterEntry, DpComponentProof, DpForwardInstantiationStep, DpNarrowingStep,
    DpOptions, DpPathOrderKind, DpProofTree, DpReductionPairProof, DpRemovalProof, DpRewritingStep,
    DpSearchBackend, DpSemanticLabelingStep, DpSizeChangeEdge, DpSizeChangeGraph, DpStrategy,
    DpStrategyParseError, DpStrategyProcessor, DpSubtermProjectionEntry, DpUncurryingStep,
    DpWpoMaxWitness, DpWpoStatus, MatrixDomain, MatrixInterpretation, MaxPolynomialAlternative,
    MaxPolynomialSummary, NaturalPolynomial, NaturalPolynomialSummary, SemanticLabelingModel,
    SlArithmeticFunction, csr_dependency_pairs, dependency_pairs, qcs_usable_rules,
    safe_csr_dependency_pairs,
};
pub(crate) use dependency_pairs::{
    certificate_improved_csr_dependency_pairs, complete_dependency_pair_probe,
    conservative_csr_dependency_problem, csr_dp_flattened_size_change_graphs,
    csr_dp_proof_requires_minimality, dp_state_input_cpf, fresh_unhiding_symbol,
    improved_csr_dependency_pairs, is_rta_marking_obligation, muterm_expanded_dependency_pairs,
    qcs_certificate_usable_rules, rta_csr_dependency_pairs,
    semantic_label_unmarked_companion,
    standardized_dp_problem_state_input_cpf, standardized_relative_dp_state_input_cpf3,
};
pub use engine::{
    ProveOptions, ProveStrategy, ProveStrategyParseError, ProveStrategyProcessor, prove,
    prove_context_sensitive, prove_relative,
};
pub use interpretation::{
    linear_polynomial_is_monotone_for_trs, linear_polynomial_prove_termination,
    linear_polynomial_strictly_orients_rule, linear_polynomial_weakly_orients_rule,
    synthesize_linear_polynomial, synthesize_linear_polynomial_reduction_pair,
};
pub use nontermination::{
    NonterminationStrategy, NonterminationStrategyParseError, NonterminationStrategyProcessor,
    check_loop_proof,
};
pub(crate) use outermost_transform::raffelsieper_zantema_transformation;
#[cfg(test)]
pub(crate) use processors::csr::CsrDependencyPairKind;
pub(crate) use processors::dp::DpNonterminationProcessor;
pub use processors::dp::DpProblemState;
pub(crate) use processors::dp::{next_scheduled_result, next_scheduled_result_with_strategy};
#[cfg(test)]
pub(crate) use processors::relative_adp::{
    AnnotatedDependencyPair, RelativeAdpGraphChild, RelativeAdpOrigin, RelativeAdpPolynomialStep,
};
pub(crate) use processors::relative_adp::{
    RelativeAdpProblem, RelativeAdpProof, RelativeAdpProofTree, serialize_relative_adp_state,
};
#[cfg(test)]
pub(crate) use processors::test_support::{
    probe_csr_dp_atom, probe_dp_atom, probe_dp_atom_state,
    solve_csr_dependency_pairs_with_kind_and_atomic_policy,
    solve_csr_dependency_pairs_with_kind_and_strategy, solve_dependency_pairs,
    solve_dependency_pairs_with_strategy, solve_dp_state_with_strategy,
    solve_improved_csr_dependency_pairs_with_strategy,
};
pub(crate) use processors::top_level::{
    ConfiguredTopLevelProcessor, EmptySystemProcessor, solve_top_level_worklist,
};
pub use processors::{
    CsrProblemState, CsrProofBoundary, ProblemCertificate, ProblemState, ProcessorApplication,
    ProcessorResult, WorklistFailure, WorklistFailureKind, WorklistProcessor, solve_worklist_lazy,
    solve_worklist_lazy_until,
};
pub(crate) use processors::{
    standardized_csr_input_cpf4, standardized_relative_trs_input_cpf3, standardized_trs_input_cpf3,
};
pub use proof::{
    BoundsProof, BoundsType, ContextSensitiveDependencyPairConstruction, DpNonterminationProof,
    DpRewriteProof, FlatContext, LoopProof, LoopRewriteStep, NonLoopProof, NonterminationProof,
    PatternEquivalence, PatternEquivalenceSide, PatternInstantiationTarget, PatternRule,
    PatternRuleProof, Proof, ProofStep, SrsDerivationPattern, SrsDerivationPatternProof,
    SrsDerivationPatternStep, SrsOverlapClosure, SrsWordPattern, Status, TreeAutomaton,
    TreeAutomatonTransition, TreeAutomatonTransitionLhs, UncurriedSymbolEntry, UncurryProof,
};
pub use runtime::{
    ProcessorEventContext, set_processor_event_log_path, with_processor_event_context,
};
pub(crate) use runtime::{configure_managed_child, terminate_child_process_group};
