use std::collections::{BTreeMap, BTreeSet, HashMap, HashSet, VecDeque};
use std::hash::Hash;
use std::process::{Command, Stdio};
use std::sync::atomic::{AtomicU64, Ordering};
use std::sync::mpsc::{self, TryRecvError};
use std::sync::{Arc, Mutex};
use std::thread;
use std::time::{Duration, Instant};

use serde_json::json;
use sha2::{Digest, Sha256};

use crate::cert::{write_csr_dp_state_input_cpf4, write_relative_dp_state_input_cpf3};
use crate::core::{
    CsrTrs, RelativeTrs, ReplacementMap, RewriteRule, RewriteStrategy, Symbol, Term, Trs, Variable,
};
use crate::llm::PathOrderKind;
use crate::llm::{
    LinearPolynomial, LinearPolynomialInterpretations, LlmProposal, StatusMapPrediction,
    SymbolWeights, dp_component_prompt,
};
use crate::standardize::{
    StandardizationGroup, StandardizationProblem, TermPair, standardize_problem,
    standardize_problem_with_bijection, standardize_trs_with_bijection,
};

use super::processors::dp::{DpProblemState, initial_innermost_lhss};
#[cfg(test)]
use super::processors::dp::{refined_innermost_lhss_for_pairs, remaining_innermost_lhss};
use super::runtime::{
    CancellationScope, cancel, cooperative_parallel_wait_tick, current_thread_cancelled,
    processor_event_context_or_problem_name, processor_event_log_enabled,
    processor_event_raw_input, run_command_with_input_deadline, with_cancellation_flags,
    write_processor_event, write_progress_event,
};
use super::smt_session::{acquire_persistent_smt_session, run_persistent_smt_script};

mod cap;
mod construction;
mod direct_sat_poly;
mod direct_sat_semantic_labeling;
mod graph;
mod proof;
mod reduction_pair;
mod semantic_labeling;
mod size_change;
mod strategy;
mod transformations;
mod usable_rules;

pub(crate) use cap::term_is_q_normal;
pub(crate) use cap::*;
pub use construction::{
    DependencyPair, certificate_improved_csr_dependency_pairs, csr_dependency_pairs,
    dependency_pairs, improved_csr_dependency_pairs, safe_csr_dependency_pairs,
};
#[cfg(test)]
use construction::{
    certifiable_csr_dependency_pairs, complete_dependency_pairs,
    dependency_pairs_with_subterm_omission, mark_root,
};
pub(crate) use construction::{
    trimmed_dependency_pairs,
    conservative_csr_dependency_problem, csr_rhs_active_variables_are_active_in_lhs,
    fresh_unhiding_symbol, innermost_csr_dependency_problem, muterm_expand_dependency_pairs,
    muterm_expanded_dependency_pairs, muterm_innermost_unhiding_rules, muterm_unhiding_is_safe,
    rta_csr_dependency_pairs,
};
use graph::*;
pub(crate) use graph::{
    cached_ceta_q_dependency_pair_graph_with_rules_deadline,
    cached_dp_problem_dependency_graph_with_context_deadline, ceta_tcap_dependency_edge_for_rules,
    dp_graph_details, exact_graph_extra_pairs_are_acyclic, refine_ceta_q_dependency_graph,
    refine_ceta_q_iedg_with_pair_local_rules,
};
pub use proof::{
    ArcticMatrixDomain, DependencyPairProof, DpArgumentFilter, DpArgumentFilterEntry,
    DpComponentProof, DpForwardInstantiationStep, DpInstantiationStep, DpNarrowingStep,
    DpPathOrderKind, DpProofTree, DpReductionPairProof, DpRemovalProof, DpRewritingStep,
    DpSearchBackend, DpSemanticLabelingStep, DpSizeChangeEdge, DpSizeChangeGraph,
    DpSubtermProjectionEntry, DpUncurryingStep, DpWpoMaxWitness, DpWpoStatus, MatrixDomain,
    MatrixInterpretation, MaxPolynomialAlternative, MaxPolynomialSummary, NaturalPolynomial,
    NaturalPolynomialSummary, SemanticLabelingModel, SlArithmeticFunction,
};
pub(crate) use proof::{CsrMatrixRuleRemoval, RelativeMatrixRuleRemoval, RelativeSemanticLabeling};
use proof::{MaxPolynomialInterpretations, PolynomialSummary};
pub(crate) use reduction_pair::*;
pub(crate) use semantic_labeling::*;
pub(crate) use size_change::*;
pub(crate) use strategy::Gm04ResidualContext;
pub use strategy::{
    DpOptions, DpParallelCancel, DpStrategy, DpStrategyParseError, DpStrategyProcessor,
};
pub(crate) use transformations::*;
pub use usable_rules::qcs_usable_rules;
use usable_rules::*;
pub(crate) use usable_rules::{
    csr_u3_usable_rules, improved_qcs_certificate_usable_rules, innermost_csr_usable_rules,
    innermost_reduction_pair_usable_rules, is_rta_marking_obligation,
    muterm_extended_basic_usable_rules, qcs_certificate_usable_rules,
    rta_context_sensitive_usable_rules, rta_reduction_pair_weak_rules, usable_rules,
    usable_rules_in_innermost_context,
};

const EXPENSIVE_SIZE_CHANGE_BUDGET: Duration = Duration::from_secs(5);
const REDUCTION_PAIR_SMT_SYMBOL_LIMIT: usize = usize::MAX;
const KBO_SMT_SYMBOL_LIMIT: usize = usize::MAX;
static MATRIX_SAT_SEED: AtomicU64 = AtomicU64::new(1);

type DpStrategyCancellation = CancellationScope;

pub(crate) fn csr_rta08_proof_has_component_first_reduction_pairs(
    csr: &CsrTrs,
    proof: &DependencyPairProof,
) -> bool {
    same_dependency_pair_rules_local(&proof.pairs, &rta_csr_dependency_pairs(csr))
        && proof.component_proofs.iter().all(|component| {
            component.proved
                && (component.proof_tree.is_none()
                    || component
                        .pairs
                        .iter()
                        .all(|pair| matches!(pair.rhs(), Term::App { .. }))
                    || matches!(
                        component.proof_tree.as_deref(),
                        Some(DpProofTree::RedPair { .. })
                    ))
        })
}

fn csr_rta08_tree_is_certifiable(tree: &DpProofTree, pairs: &[DependencyPair]) -> bool {
    match tree {
        DpProofTree::Empty => pairs.is_empty(),
        DpProofTree::RedPair { reduction, proof } => {
            if !reduction.uses_usable_rules
                || !same_dependency_pair_rules_local(&reduction.pairs, pairs)
            {
                return false;
            }
            let strict = reduction
                .strict_pair_indices
                .iter()
                .copied()
                .collect::<BTreeSet<_>>();
            if strict.len() != reduction.strict_pair_indices.len()
                || strict.iter().any(|index| *index >= pairs.len())
            {
                return false;
            }
            let residual = pairs
                .iter()
                .cloned()
                .enumerate()
                .filter_map(|(index, pair)| (!strict.contains(&index)).then_some(pair))
                .collect::<Vec<_>>();
            // The legacy one-shot theorem closes a residual consisting only
            // of collapsing RTA'08 pairs by its certified marking descent.
            // Otherwise the new recursive checker validates the retained
            // child proof against exactly the undeleted pairs.
            (residual
                .iter()
                .all(|pair| matches!(pair.rhs(), Term::Var(_)))
                && matches!(proof.as_ref(), DpProofTree::Empty))
                || csr_rta08_tree_is_certifiable(proof, &residual)
        }
        DpProofTree::DepGraph { components } => {
            let child_pairs = components
                .iter()
                .flat_map(|child| child.pairs.iter().cloned())
                .collect::<Vec<_>>();
            same_dependency_pair_rules_local(&child_pairs, pairs)
                && components.iter().all(csr_rta08_component_is_certifiable)
        }
        _ => false,
    }
}

fn csr_rta08_component_is_certifiable(component: &DpComponentProof) -> bool {
    let Some(tree) = component.proof_tree.as_deref() else {
        // A missing component proof is the CPF dependency-graph convention
        // for an acyclic component.  The checker independently validates
        // that claim against its graph approximation.
        return !component.proved;
    };
    if !component.proved {
        return false;
    }
    csr_rta08_tree_is_certifiable(tree, &component.pairs)
}

pub(crate) fn csr_rta08_proof_is_certifiable(csr: &CsrTrs, proof: &DependencyPairProof) -> bool {
    if !same_dependency_pair_rules_local(&proof.pairs, &rta_csr_dependency_pairs(csr)) {
        return false;
    }
    let component_pairs = proof
        .component_proofs
        .iter()
        .flat_map(|component| component.pairs.iter().cloned())
        .collect::<Vec<_>>();
    same_dependency_pair_rules_local(&component_pairs, &proof.pairs)
        && proof
            .component_proofs
            .iter()
            .all(csr_rta08_component_is_certifiable)
}

pub(crate) fn csr_dp_proof_is_conservatively_certifiable(proof: &DependencyPairProof) -> bool {
    proof.component_proofs.len() == 1
        && proof.component_proofs[0].pairs.len() == proof.pairs.len()
        && proof.component_proofs[0]
            .proof_tree
            .as_deref()
            .is_some_and(|tree| !csr_dp_tree_requires_minimality(tree))
}

pub(crate) fn safe_csr_dependency_pair_proof_closes_all_cyclic_components(
    csr: &CsrTrs,
    proof: &DependencyPairProof,
) -> bool {
    // Validate against the same replacement-map-aware estimate used to
    // construct a safe-CS-DP proof.  Recomputing an ordinary DP graph here
    // invents frozen-argument edges and rejects an otherwise complete proof
    // after every cyclic component has been closed.
    let graph = csr_dependency_pair_graph_with_context_deadline(
        csr,
        &proof.pairs,
        None,
        None,
        &DpStrategyCancellation::default(),
    )
    .expect("uncapped dependency-graph construction should not time out");
    let components = strongly_connected_components(&graph);
    components.iter().all(|component| {
        if !component_is_cyclic(component, &graph) {
            return true;
        }
        let pairs = component
            .iter()
            .map(|index| proof.pairs[*index].clone())
            .collect::<Vec<_>>();
        proof.component_proofs.iter().any(|component_proof| {
            component_proof.proved
                && same_dependency_pair_rules_local(&component_proof.pairs, &pairs)
        })
    })
}

pub(crate) fn csr_dp_proof_requires_minimality(proof: &DependencyPairProof) -> bool {
    proof.component_proofs.iter().any(|component| {
        // A component-level usable-rule processor is itself a minimal-chain
        // processor even when every nested reduction pair is recorded as a
        // full-rule exact witness.  Omitting this field selects the weaker
        // innermost/general CSR serializer and loses the certified local R
        // boundary on output.
        component.usable_rules_processor.is_some()
            || component
                .proof_tree
                .as_deref()
                .is_some_and(csr_dp_tree_requires_minimality)
    })
}

fn csr_dp_tree_requires_minimality(tree: &DpProofTree) -> bool {
    match tree {
        DpProofTree::Empty
        | DpProofTree::ExactXml(_)
        | DpProofTree::QdpToSrs { .. }
        | DpProofTree::SwitchToTrs { .. } => false,
        DpProofTree::DepGraph { components } => components.iter().any(|component| {
            component
                .proof_tree
                .as_deref()
                .is_some_and(csr_dp_tree_requires_minimality)
        }),
        DpProofTree::GeneralRedPairExact { proofs, .. } => proofs
            .iter()
            .any(|proof| csr_dp_tree_requires_minimality(proof)),
        DpProofTree::ReductionPairExact { proof, .. }
        | DpProofTree::TransformationExact { proof, .. } => csr_dp_tree_requires_minimality(proof),
        DpProofTree::Split {
            selected_proof,
            residual_proof,
            ..
        } => {
            csr_dp_tree_requires_minimality(selected_proof)
                || csr_dp_tree_requires_minimality(residual_proof)
        }
        DpProofTree::Subterm { .. } => true,
        DpProofTree::SwitchInnermost { .. } => true,
        DpProofTree::SizeChange { .. } | DpProofTree::SizeChangeRedPair { .. } => true,
        DpProofTree::RedPair { reduction, proof } => {
            reduction.uses_usable_rules || csr_dp_tree_requires_minimality(proof)
        }
        DpProofTree::ForwardInstantiation { step, proof } => {
            step.uses_usable_rules || csr_dp_tree_requires_minimality(proof)
        }
        DpProofTree::Narrowing { proof, .. }
        | DpProofTree::Instantiation { proof, .. }
        | DpProofTree::Rewriting { proof, .. }
        | DpProofTree::SemanticLabeling { proof, .. }
        | DpProofTree::Uncurry { proof, .. }
        | DpProofTree::ComponentContext { proof, .. } => csr_dp_tree_requires_minimality(proof),
    }
}

pub(crate) fn csr_dp_minimal_processors_are_mu_valid(
    csr: &CsrTrs,
    proof: &DependencyPairProof,
    allow_improved_unhiding: bool,
) -> bool {
    proof.component_proofs.iter().all(|component| {
        component
            .proof_tree
            .as_deref()
            .is_none_or(|tree| csr_dp_tree_is_mu_valid(csr, tree, allow_improved_unhiding))
    })
}

#[cfg(test)]
fn csr_dp_minimal_processors_are_natively_certifiable(
    csr: &CsrTrs,
    proof: &DependencyPairProof,
    use_qcs_usable_rules: bool,
) -> bool {
    csr_dp_native_certification_issues(csr, proof, use_qcs_usable_rules).is_empty()
}

pub(crate) fn csr_dp_native_certification_issues(
    csr: &CsrTrs,
    proof: &DependencyPairProof,
    use_qcs_usable_rules: bool,
) -> Vec<String> {
    csr_dp_certification_issues(csr, proof, use_qcs_usable_rules, false, true, false)
}

pub(crate) fn csr_innermost_dp_certification_issues(
    csr: &CsrTrs,
    proof: &DependencyPairProof,
) -> Vec<String> {
    csr_dp_certification_issues(csr, proof, false, false, true, true)
}

fn csr_dp_certification_issues(
    csr: &CsrTrs,
    proof: &DependencyPairProof,
    use_qcs_usable_rules: bool,
    construction_is_minimal: bool,
    enforce_native_u3: bool,
    allow_innermost_active_sct: bool,
) -> Vec<String> {
    let safe_construction =
        same_dependency_pair_rules_local(&proof.pairs, &safe_csr_dependency_pairs(csr));
    let improved_construction = same_dependency_pair_rules_local(
        &proof.pairs,
        &certificate_improved_csr_dependency_pairs(csr),
    );
    let minimal = construction_is_minimal || safe_construction || improved_construction;
    let subterm_as_csr_sct = csr_dp_flattened_size_change_graphs(proof).is_some();
    let qcs_rules = use_qcs_usable_rules.then(|| qcs_certificate_usable_rules(csr, &proof.pairs));
    let active_rules = qcs_rules.as_deref().unwrap_or_else(|| csr.rules());
    proof
        .component_proofs
        .iter()
        .enumerate()
        .filter_map(|(index, component)| {
            let component_rules = component
                .usable_rules_processor
                .as_deref()
                .unwrap_or(active_rules);
            component.proof_tree.as_deref().and_then(|tree| {
                csr_dp_tree_native_certification_issue(
                    tree,
                    csr,
                    component_rules,
                    minimal || subterm_as_csr_sct,
                    safe_construction,
                    enforce_native_u3,
                    allow_innermost_active_sct,
                )
                .map(|issue| format!("component {index}: {issue}"))
            })
        })
        .collect()
}

pub(crate) fn csr_dp_flattened_size_change_graphs(
    proof: &DependencyPairProof,
) -> Option<Vec<DpSizeChangeGraph>> {
    let structurally_flattenable =
        proof
            .component_proofs
            .iter()
            .all(|component| match component.proof_tree.as_deref() {
                Some(DpProofTree::Subterm {
                    strict_pairs,
                    proof,
                    ..
                }) => {
                    matches!(proof.as_ref(), DpProofTree::Empty)
                        && strict_pairs.len() == component.pairs.len()
                }
                Some(DpProofTree::SizeChange { .. }) => true,
                Some(DpProofTree::Empty) => component.pairs.is_empty(),
                None => !component.proved,
                _ => false,
            });
    if !structurally_flattenable {
        return None;
    }
    let mut graphs = Vec::new();
    for pair in &proof.pairs {
        let graph = proof
            .component_proofs
            .iter()
            .filter_map(|component| component.proof_tree.as_deref())
            .find_map(|tree| match tree {
                DpProofTree::Subterm {
                    graphs: component_graphs,
                    ..
                }
                | DpProofTree::SizeChange {
                    graphs: component_graphs,
                } => component_graphs
                    .iter()
                    .find(|graph| graph.pair.lhs() == pair.lhs() && graph.pair.rhs() == pair.rhs()),
                _ => None,
            })
            .cloned()
            .unwrap_or_else(|| DpSizeChangeGraph {
                pair: pair.clone(),
                edges: Vec::new(),
            });
        graphs.push(graph);
    }
    // CPF's size-change processor checks every composable graph sequence.
    // A dependency-graph estimate may be used to split the problem first, but
    // it must not silently remove compositions from a flattened SCT proof.
    size_change_graphs_are_terminating(&graphs)?;
    Some(graphs)
}

fn csr_dp_tree_native_certification_issue(
    tree: &DpProofTree,
    csr: &CsrTrs,
    active_rules: &[RewriteRule],
    minimal: bool,
    safe_construction: bool,
    enforce_native_u3: bool,
    allow_innermost_active_sct: bool,
) -> Option<String> {
    match tree {
        DpProofTree::Empty => None,
        DpProofTree::ExactXml(_) => Some("exact ordinary DP proof".to_string()),
        DpProofTree::GeneralRedPairExact { .. } => {
            Some("general conditional reduction pair is ordinary-DP only".to_string())
        }
        DpProofTree::ReductionPairExact { proof, .. } => {
            // This node is emitted as an `ordinaryDpProof`, which proves the
            // stronger unrestricted DP obligation and is therefore a sound
            // continuation of a CSR-DP component.  Its exact processor has
            // already checked that the retained CPF `dps` witness is the
            // multiset of live pairs it deletes.
            csr_dp_tree_native_certification_issue(
                proof,
                csr,
                active_rules,
                minimal,
                safe_construction,
                enforce_native_u3,
                allow_innermost_active_sct,
            )
        }
        DpProofTree::TransformationExact {
            processor_tag,
            proof,
            ..
        } if processor_tag == "csrGuardedListTerminal"
            || processor_tag == "csrGuardedOvConsTerminal" =>
        {
            if matches!(proof.as_ref(), DpProofTree::Empty) {
                None
            } else {
                Some("guarded-list terminal has a nonempty continuation".to_string())
            }
        }
        DpProofTree::TransformationExact {
            processor_tag,
            proof,
            ..
        } if matches!(
            processor_tag.as_str(),
            "rewritingProc" | "narrowingProc" | "instantiationProc" | "forwardInstantiationProc"
        ) =>
        {
            csr_dp_tree_native_certification_issue(
                proof,
                csr,
                active_rules,
                minimal,
                safe_construction,
                enforce_native_u3,
                allow_innermost_active_sct,
            )
        }
        DpProofTree::TransformationExact { processor_tag, .. } => Some(format!(
            "retained transformation {processor_tag} has no native CSR proof boundary"
        )),
        DpProofTree::DepGraph { components } => {
            components
                .iter()
                .enumerate()
                .find_map(|(index, component)| {
                    let component_rules = component
                        .usable_rules_processor
                        .as_deref()
                        .unwrap_or(active_rules);
                    component.proof_tree.as_deref().and_then(|tree| {
                        csr_dp_tree_native_certification_issue(
                            tree,
                            csr,
                            component_rules,
                            minimal,
                            safe_construction,
                            enforce_native_u3,
                            allow_innermost_active_sct,
                        )
                        .map(|issue| format!("dep-graph component {index}: {issue}"))
                    })
                })
        }
        DpProofTree::ComponentContext {
            usable_rules_processor,
            proof,
            ..
        } => {
            let below_usable_rules = usable_rules_processor.is_some();
            csr_dp_tree_native_certification_issue(
                proof,
                csr,
                usable_rules_processor.as_deref().unwrap_or(active_rules),
                minimal && !below_usable_rules,
                safe_construction,
                enforce_native_u3,
                allow_innermost_active_sct,
            )
        }
        DpProofTree::Split {
            selected_proof,
            residual_proof,
            ..
        } => csr_dp_tree_native_certification_issue(
            selected_proof,
            csr,
            active_rules,
            minimal,
            safe_construction,
            enforce_native_u3,
            allow_innermost_active_sct,
        )
        .or_else(|| {
            csr_dp_tree_native_certification_issue(
                residual_proof,
                csr,
                active_rules,
                minimal,
                safe_construction,
                enforce_native_u3,
                allow_innermost_active_sct,
            )
        }),
        DpProofTree::Subterm { proof, .. } => {
            if !minimal {
                Some("subterm processor requires minimality".to_string())
            } else {
                csr_dp_tree_native_certification_issue(
                    proof,
                    csr,
                    active_rules,
                    minimal,
                    safe_construction,
                    enforce_native_u3,
                    allow_innermost_active_sct,
                )
            }
        }
        DpProofTree::SwitchInnermost { .. } => Some("innermost switch".to_string()),
        DpProofTree::SizeChange { graphs } => {
            if minimal
                || (allow_innermost_active_sct
                    && !graphs.is_empty()
                    && csr_innermost_sct_targets_are_source_covered(
                        csr,
                        &graphs
                            .iter()
                            .map(|graph| graph.pair.clone())
                            .collect::<Vec<_>>(),
                    ))
            {
                None
            } else {
                Some("size-change processor requires minimality".to_string())
            }
        }
        DpProofTree::SizeChangeRedPair { .. } => Some("size-change reduction pair".to_string()),
        DpProofTree::RedPair { reduction, proof } => {
            if reduction.uses_usable_rules && !minimal {
                return Some(format!(
                    "U3 reduction pair requires minimality (pairs={:?}, force_non_mono={}, order={:?})",
                    reduction.pairs,
                    reduction.force_non_mono_usable_rules,
                    reduction.reduction_pair
                ));
            }
            if enforce_native_u3
                && reduction.uses_usable_rules
                && !csr_pairs_have_marked_or_fresh_unhiding_roots(csr, &reduction.pairs)
            {
                return Some(format!(
                    "U3 reduction pair has a pair root outside the marked/fresh-unhiding signature (rules={}, order={:?})",
                    reduction.usable_rules.len(),
                    reduction.reduction_pair
                ));
            }
            // Exact U3 closure is the native minimal full-CSR-DP criterion.
            // Safe CS-DPs have their own usable-rule processor and checker
            // obligation; applying native U3 here rejects safe proofs that
            // CeTA validates (for example MYNAT_complete).
            if enforce_native_u3 && reduction.uses_usable_rules && !safe_construction {
                let required = csr_u3_usable_rules(csr, active_rules, &reduction.pairs);
                let missing = required
                    .iter()
                    .filter(|rule| !reduction.usable_rules.contains(rule))
                    .count();
                let outside = reduction
                    .usable_rules
                    .iter()
                    .filter(|rule| !active_rules.contains(rule))
                    .count();
                if missing != 0 || outside != 0 {
                    return Some(format!(
                        "U3 usable-rule set is not closed (required={}, supplied={}, missing={}, outside={}, active={}, csr_rules={}, unhiding={})",
                        required.len(),
                        reduction.usable_rules.len(),
                        missing,
                        outside,
                        active_rules.len(),
                        csr.rules().len(),
                        fresh_unhiding_symbol(csr.trs())
                    ));
                }
            }
            // Every reduction-pair processor here transforms a minimal DP
            // problem into a residual minimal DP problem.  In particular,
            // redPairUrProc uses U only for its orientation obligation; it
            // retains the parent R component and does not turn a minimal
            // chain problem into an arbitrary one.  Monotonicity determines
            // whether R is changed, not whether minimality survives.
            let changes_rules = reduction_pair_is_mono_for_residual(&reduction.reduction_pair)
                && !reduction.force_non_mono_usable_rules;
            let residual_rules = changes_rules.then(|| {
                reduction
                    .usable_rules
                    .iter()
                    .filter(|rule| !reduction.strict_rules.contains(rule))
                    .cloned()
                    .collect::<Vec<_>>()
            });
            csr_dp_tree_native_certification_issue(
                proof,
                csr,
                residual_rules.as_deref().unwrap_or(active_rules),
                minimal,
                safe_construction,
                enforce_native_u3,
                allow_innermost_active_sct,
            )
        }
        DpProofTree::Instantiation { proof, .. }
        | DpProofTree::ForwardInstantiation { proof, .. } => {
            csr_dp_tree_native_certification_issue(
                proof,
                csr,
                active_rules,
                minimal,
                safe_construction,
                enforce_native_u3,
                allow_innermost_active_sct,
            )
        }
        DpProofTree::Narrowing { .. } => Some("narrowing".to_string()),
        DpProofTree::Rewriting { .. } => Some("rewriting".to_string()),
        DpProofTree::SemanticLabeling { .. } => Some("semantic labeling".to_string()),
        DpProofTree::Uncurry { .. } => Some("uncurrying".to_string()),
        DpProofTree::QdpToSrs { .. } => Some("QDP-to-SRS".to_string()),
        DpProofTree::SwitchToTrs { .. } => Some("switch-to-TRS".to_string()),
    }
}

fn same_dependency_pair_rules_local(left: &[DependencyPair], right: &[DependencyPair]) -> bool {
    left.len() == right.len()
        && left
            .iter()
            .all(|pair| right.iter().any(|other| pair.as_rule() == other.as_rule()))
}

fn csr_dp_tree_is_mu_valid(
    csr: &CsrTrs,
    tree: &DpProofTree,
    allow_improved_unhiding: bool,
) -> bool {
    match tree {
        DpProofTree::Empty => true,
        DpProofTree::ExactXml(_) => false,
        DpProofTree::GeneralRedPairExact { .. } => false,
        DpProofTree::ReductionPairExact { .. } => false,
        DpProofTree::TransformationExact { .. } => false,
        DpProofTree::DepGraph { components } => components.iter().all(|component| {
            component
                .proof_tree
                .as_deref()
                .is_none_or(|tree| csr_dp_tree_is_mu_valid(csr, tree, allow_improved_unhiding))
        }),
        DpProofTree::Split {
            selected_proof,
            residual_proof,
            ..
        } => {
            csr_dp_tree_is_mu_valid(csr, selected_proof, allow_improved_unhiding)
                && csr_dp_tree_is_mu_valid(csr, residual_proof, allow_improved_unhiding)
        }
        DpProofTree::Subterm { proof, .. } => {
            csr_dp_tree_is_mu_valid(csr, proof, allow_improved_unhiding)
        }
        DpProofTree::SwitchInnermost { .. } => false,
        DpProofTree::SizeChange { graphs } | DpProofTree::SizeChangeRedPair { graphs, .. } => {
            graphs.iter().all(|graph| {
                csr_size_change_graph_is_mu_valid(csr, graph)
                    || (allow_improved_unhiding
                        && csr_size_change_graph_is_improved_unhiding(csr, graph))
            })
        }
        DpProofTree::RedPair { proof, .. }
        | DpProofTree::Narrowing { proof, .. }
        | DpProofTree::Instantiation { proof, .. }
        | DpProofTree::ForwardInstantiation { proof, .. }
        | DpProofTree::Rewriting { proof, .. }
        | DpProofTree::SemanticLabeling { proof, .. } => {
            csr_dp_tree_is_mu_valid(csr, proof, allow_improved_unhiding)
        }
        DpProofTree::ComponentContext { proof, .. } => {
            csr_dp_tree_is_mu_valid(csr, proof, allow_improved_unhiding)
        }
        DpProofTree::Uncurry { .. } => false,
        DpProofTree::QdpToSrs { .. } => false,
        DpProofTree::SwitchToTrs { .. } => false,
    }
}

pub(crate) fn csr_size_change_graph_is_mu_valid(csr: &CsrTrs, graph: &DpSizeChangeGraph) -> bool {
    graph.edges.iter().all(|edge| {
        (!edge.strict && size_change_edge_is_equality(graph, edge))
            || (csr_size_change_position_is_active(csr, graph.pair.lhs(), edge.left_position)
                && csr_size_change_edge_is_mu_valid(csr, graph, edge))
    })
}

pub(crate) fn csr_innermost_sct_targets_are_source_covered(
    csr: &CsrTrs,
    pairs: &[DependencyPair],
) -> bool {
    pairs.iter().all(|pair| {
        let (Some((lhs_root, _)), Some((rhs_root, rhs_args))) =
            (term_app_parts(pair.lhs()), term_app_parts(pair.rhs()))
        else {
            return false;
        };
        lhs_root.as_str().ends_with('#')
            && rhs_root.as_str().ends_with('#')
            && rhs_args.iter().enumerate().all(|(index, rhs_arg)| {
                !csr_symbol_allows_argument(csr, rhs_root, index)
                    || csr_term_has_active_proper_subterm(csr, pair.lhs(), rhs_arg)
            })
    })
}

fn csr_term_has_active_proper_subterm(csr: &CsrTrs, term: &Term, target: &Term) -> bool {
    let Some((symbol, args)) = term_app_parts(term) else {
        return false;
    };
    args.iter().enumerate().any(|(index, argument)| {
        csr_symbol_allows_argument(csr, symbol, index)
            && (argument == target || csr_term_has_active_proper_subterm(csr, argument, target))
    })
}

fn size_change_edge_is_equality(graph: &DpSizeChangeGraph, edge: &DpSizeChangeEdge) -> bool {
    let (Some((_, lhs_args)), Some((_, rhs_args))) = (
        term_app_parts(graph.pair.lhs()),
        term_app_parts(graph.pair.rhs()),
    ) else {
        return false;
    };
    let (Some(lhs_arg), Some(rhs_arg)) = (
        edge.left_position
            .checked_sub(1)
            .and_then(|index| lhs_args.get(index)),
        edge.right_position
            .checked_sub(1)
            .and_then(|index| rhs_args.get(index)),
    ) else {
        return false;
    };
    lhs_arg == rhs_arg
}

pub(crate) fn csr_size_change_graph_is_improved_unhiding(
    csr: &CsrTrs,
    graph: &DpSizeChangeGraph,
) -> bool {
    let unhiding = fresh_unhiding_symbol(csr.trs());
    let (Some((lhs_root, lhs_args)), Some((rhs_root, rhs_args))) = (
        term_app_parts(graph.pair.lhs()),
        term_app_parts(graph.pair.rhs()),
    ) else {
        return false;
    };
    lhs_root == &unhiding
        && rhs_root == &unhiding
        && lhs_args.len() == 1
        && rhs_args.len() == 1
        && !graph.edges.is_empty()
        && graph.edges.iter().all(|edge| {
            edge.strict
                && edge.left_position == 1
                && edge.right_position == 1
                && rhs_args[0].is_proper_subterm_of(&lhs_args[0])
        })
}

fn csr_size_change_position_is_active(csr: &CsrTrs, term: &Term, position: usize) -> bool {
    if position == 0 {
        return false;
    }
    term.root_symbol()
        .is_some_and(|symbol| csr_symbol_allows_argument(csr, symbol, position - 1))
}

fn csr_size_change_edge_is_mu_valid(
    csr: &CsrTrs,
    graph: &DpSizeChangeGraph,
    edge: &DpSizeChangeEdge,
) -> bool {
    let (Some((_, lhs_args)), Some((_, rhs_args))) = (
        term_app_parts(graph.pair.lhs()),
        term_app_parts(graph.pair.rhs()),
    ) else {
        return false;
    };
    let (Some(lhs_arg), Some(rhs_arg)) = (
        edge.left_position
            .checked_sub(1)
            .and_then(|index| lhs_args.get(index)),
        edge.right_position
            .checked_sub(1)
            .and_then(|index| rhs_args.get(index)),
    ) else {
        return false;
    };
    if edge.strict {
        csr_is_mu_proper_subterm(csr, lhs_arg, rhs_arg)
    } else {
        lhs_arg == rhs_arg || csr_is_mu_proper_subterm(csr, lhs_arg, rhs_arg)
    }
}

fn csr_is_mu_proper_subterm(csr: &CsrTrs, outer: &Term, inner: &Term) -> bool {
    let Term::App { symbol, args } = outer else {
        return false;
    };
    args.iter().enumerate().any(|(index, arg)| {
        csr_symbol_allows_argument(csr, symbol, index)
            && (arg == inner || csr_is_mu_proper_subterm(csr, arg, inner))
    })
}

/// Construct the exact executable QCS-DP residual handed to the universal
/// worklist. No dependency-pair processor is invoked here.
pub(crate) fn csr_dp_problem_state(
    csr: &CsrTrs,
    pairs: Vec<DependencyPair>,
    problem: CsrDpProblemContext,
    options: DpOptions,
    initial_active_rules: Option<Vec<RewriteRule>>,
    initial_weak_pairs: Vec<DependencyPair>,
) -> Option<DpProblemState> {
    let trs = csr.trs();
    // Materializing a DP problem must not execute a processor.  In
    // particular, `use_qcs_usable_rules` records which usable-rule theorem is
    // available; it does not mean that the theorem has already been applied.
    // The explicit `usable-rules` worklist processor is solely responsible
    // for replacing R and returning that residual state.
    let runtime_active_rules = initial_active_rules;
    // The legacy direct innermost-CSR/unhiding theorem constructs
    // `finite_dpp (False, False, P, {}, {}, {}, S)`: its chains are not
    // minimal ordinary DP chains.  In particular, graph decomposition must
    // not upgrade such a residual and enable minimal-only usable-rule or
    // reduction-pair processors.  MU-TERM's four-component construction is
    // different: it explicitly retains minimality while keeping unhiding
    // rules in their own component.
    let minimal = matches!(
        problem.construction,
        CsrDpConstruction::Native
            | CsrDpConstruction::MutermUnhiding
            | CsrDpConstruction::MutermExpanded
            | CsrDpConstruction::Rta08
            | CsrDpConstruction::Safe
            | CsrDpConstruction::Improved
    );
    let mut stats = DpProofStats {
        minimal,
        weak_pairs: initial_weak_pairs,
        problem: DpProblemContext::ContextSensitive(problem),
        normal_form_substitutions: trs.strategy() == RewriteStrategy::Innermost,
        ..DpProofStats::default()
    };
    stats.active_rules = runtime_active_rules.clone();
    stats.graph_rules = runtime_active_rules;
    let innermost_lhss = if minimal {
        match &stats.problem {
            DpProblemContext::ContextSensitive(problem) => problem
                .innermost_q_lhss
                .clone()
                .or_else(|| initial_innermost_lhss(trs)),
            DpProblemContext::Ordinary => initial_innermost_lhss(trs),
        }
    } else {
        None
    };
    Some(DpProblemState {
        trs: trs.clone(),
        pairs,
        options,
        stats,
        innermost_lhss,
        subtree_deadline: None,
    })
}
#[derive(Clone, Copy, Debug, Eq, Hash, PartialEq)]
pub(crate) enum CsrDpConstruction {
    Native,
    Innermost,
    InnermostRta08,
    MutermUnhiding,
    MutermExpanded,
    Rta08,
    Safe,
    Improved,
    Conservative,
}

impl CsrDpConstruction {
    pub(crate) fn as_str(self) -> &'static str {
        match self {
            Self::Native => "native",
            Self::Innermost => "innermost",
            Self::InnermostRta08 => "innermost-rta08",
            Self::MutermUnhiding => "muterm-unhiding",
            Self::MutermExpanded => "muterm-expanded",
            Self::Rta08 => "rta08",
            Self::Safe => "safe",
            Self::Improved => "improved",
            Self::Conservative => "conservative",
        }
    }
}

#[derive(Clone, Copy, Debug, Eq, Hash, PartialEq)]
pub(crate) enum CsrGraphEstimator {
    Ordinary,
    ContextSensitive,
}

impl CsrGraphEstimator {
    pub(crate) fn as_str(self) -> &'static str {
        match self {
            Self::Ordinary => "ordinary",
            Self::ContextSensitive => "context-sensitive",
        }
    }
}

#[derive(Clone, Debug, Eq, Hash, PartialEq)]
pub(crate) struct CsrDpProblemContext {
    pub(crate) csr: CsrTrs,
    pub(crate) construction: CsrDpConstruction,
    pub(crate) graph_estimator: CsrGraphEstimator,
    pub(crate) use_qcs_usable_rules: bool,
    pub(crate) innermost_q_lhss: Option<Vec<Term>>,
}

impl CsrDpProblemContext {
    pub(crate) fn native(
        csr: &CsrTrs,
        graph_estimator: CsrGraphEstimator,
        use_qcs_usable_rules: bool,
    ) -> Self {
        Self {
            csr: csr.clone(),
            construction: CsrDpConstruction::Native,
            graph_estimator,
            use_qcs_usable_rules,
            innermost_q_lhss: None,
        }
    }

    pub(crate) fn safe(csr: &CsrTrs) -> Self {
        Self {
            csr: csr.clone(),
            construction: CsrDpConstruction::Safe,
            // Safe CS-DPs still describe chains of the original
            // context-sensitive relation.  Keeping the ordinary estimator
            // here invents cycles through frozen arguments (MYNAT is a
            // representative case) and loses the graph decomposition that
            // CeTA accepts for <csrSafeDependencyPairs>.  Use the
            // replacement-map-aware estimator; it is an edge-removal
            // refinement only, and the emitted graph remains checked by
            // CeTA-CSR.
            graph_estimator: CsrGraphEstimator::ContextSensitive,
            use_qcs_usable_rules: false,
            innermost_q_lhss: None,
        }
    }

    pub(crate) fn rta08(csr: &CsrTrs) -> Self {
        Self {
            csr: csr.clone(),
            construction: CsrDpConstruction::Rta08,
            graph_estimator: CsrGraphEstimator::ContextSensitive,
            use_qcs_usable_rules: false,
            innermost_q_lhss: None,
        }
    }

    pub(crate) fn innermost_rta08(csr: &CsrTrs) -> Self {
        Self {
            csr: csr.clone(),
            construction: CsrDpConstruction::InnermostRta08,
            graph_estimator: CsrGraphEstimator::ContextSensitive,
            use_qcs_usable_rules: false,
            innermost_q_lhss: None,
        }
    }

    pub(crate) fn muterm_unhiding(csr: &CsrTrs) -> Self {
        Self {
            csr: csr.clone(),
            construction: CsrDpConstruction::MutermUnhiding,
            graph_estimator: CsrGraphEstimator::Ordinary,
            use_qcs_usable_rules: false,
            // The expanded MU-TERM boundary is initially a full DP problem.
            // Its Q-normality obligation is introduced only by the explicit
            // `switchInnermostProc`; pre-populating it here both hid that
            // proof step and made the switch processor inapplicable.
            innermost_q_lhss: None,
        }
    }

    pub(crate) fn muterm_expanded(csr: &CsrTrs) -> Self {
        Self {
            csr: csr.clone(),
            construction: CsrDpConstruction::MutermExpanded,
            graph_estimator: CsrGraphEstimator::Ordinary,
            use_qcs_usable_rules: false,
            innermost_q_lhss: None,
        }
    }

    pub(crate) fn innermost(csr: &CsrTrs, original_csr: &CsrTrs) -> Self {
        Self {
            csr: csr.clone(),
            construction: CsrDpConstruction::Innermost,
            // CeTA reconstructs an ordinary innermost DP obligation over the
            // original rules plus the exact unhiding rules.  Its dependency
            // graph therefore is not the replacement-map graph of the source
            // CSR.  Using that smaller graph can discard real self-edges and
            // emit an invalid decomposition (Ex15_Luc06 is the minimal
            // regression).  Estimate the same executable problem CeTA checks.
            graph_estimator: CsrGraphEstimator::Ordinary,
            use_qcs_usable_rules: false,
            innermost_q_lhss: Some(
                original_csr
                    .rules()
                    .iter()
                    .map(|rule| rule.lhs().clone())
                    .collect(),
            ),
        }
    }

    pub(crate) fn improved(csr: &CsrTrs) -> Self {
        Self {
            csr: csr.clone(),
            construction: CsrDpConstruction::Improved,
            graph_estimator: CsrGraphEstimator::ContextSensitive,
            use_qcs_usable_rules: true,
            innermost_q_lhss: None,
        }
    }

    pub(crate) fn conservative(csr: &CsrTrs) -> Self {
        Self {
            csr: csr.clone(),
            construction: CsrDpConstruction::Conservative,
            graph_estimator: CsrGraphEstimator::Ordinary,
            use_qcs_usable_rules: false,
            innermost_q_lhss: None,
        }
    }
}

#[derive(Clone, Debug, Default, Eq, Hash, PartialEq)]
pub(crate) enum DpProblemContext {
    #[default]
    Ordinary,
    ContextSensitive(CsrDpProblemContext),
}

impl DpProcessorOptionCacheKey {
    fn from_options(options: &DpOptions) -> Self {
        Self {
            llm_iterations: options.llm_iterations,
            max_symbol_weight: options.max_symbol_weight,
            max_symbols: options.max_symbols,
            max_polynomial_constant: options.max_polynomial_constant,
            max_polynomial_coefficient: options.max_polynomial_coefficient,
            max_polynomial_symbols: options.max_polynomial_symbols,
            max_polynomial_arity: options.max_polynomial_arity,
            max_component_pairs: options.max_component_pairs,
            max_search_space: options.max_search_space,
            max_narrowing_steps: options.max_narrowing_steps,
            max_narrowing_transforms: options.max_narrowing_transforms,
            max_forward_instantiation_transforms: options.max_forward_instantiation_transforms,
            max_narrowings_per_pair: options.max_narrowings_per_pair,
            max_rewritings_per_pair: options.max_rewritings_per_pair,
            max_instantiations_per_pair: options.max_instantiations_per_pair,
            max_forward_instantiations_per_pair: options.max_forward_instantiations_per_pair,
            max_narrowings_per_step: options.max_narrowings_per_step,
            smt_fallback: options.smt_fallback,
            smt_solver: options.smt_solver.clone(),
        }
    }
}

#[derive(Clone, Default)]
pub(crate) struct DpProofStats {
    pub(crate) problem: DpProblemContext,
    /// CSR semantics retained across a CPF ordinary-language transformation
    /// such as finite semantic labeling. Ordinary processors must not infer
    /// CSR obligations from this field; certified CSR residual processors
    /// consume it explicitly.
    pub(crate) semantic_csr_context: Option<CsrDpProblemContext>,
    pub(crate) active_rules: Option<Vec<RewriteRule>>,
    /// `active_rules` is the certified residual R of an explicit usable-rules
    /// processor, rather than a search-local usable-rule hint.  The original
    /// TRS is retained separately because it still defines the innermost Q
    /// context.
    pub(crate) active_rules_are_residual: bool,
    pub(crate) weak_pairs: Vec<DependencyPair>,
    /// Strict ordinary rules of a generalized DP problem.  Ordinary DP
    /// problems start with no strict rules; `splitProc` can move a selected
    /// rule into this component while making all dependency pairs weak.
    pub(crate) strict_rules: Vec<RewriteRule>,
    pub(crate) graph_rules: Option<Vec<RewriteRule>>,
    pub(crate) transformation_rules: Option<Vec<RewriteRule>>,
    pub(crate) minimal: bool,
    /// The source DP framework is minimal, but a surrounding CPF
    /// `<ordinaryDpProof>` no longer makes that fact available to ordinary
    /// SCT/subterm processors. Keep this separate from `minimal`: the latter
    /// is part of the established state/oracle identity, while this bit
    /// records the narrower checker boundary crossed by an exact ordinary
    /// reduction-pair fragment.
    pub(crate) ordinary_bridge_loses_minimality: bool,
    pub(crate) ordinary_reduction_started: bool,
    pub(crate) normal_form_substitutions: bool,
    /// Search-local depth of witness-free narrowing.  This is deliberately
    /// not part of the serialized DP obligation: exact retained narrowing
    /// atoms remain independently replayable, while one fallback worklist
    /// must not keep specializing the same recursive call forever.
    pub(crate) generic_narrowing_transforms: usize,
    /// Search-local depth of witness-free forward instantiation.  Exact
    /// selected witnesses bypass this counter for independent replay.
    pub(crate) generic_forward_instantiation_transforms: usize,
    /// Search-local depth of witness-free backward instantiation. Exact
    /// selected witnesses bypass this counter for independent oracle replay.
    pub(crate) generic_instantiation_transforms: usize,
    graph_cache: Arc<Mutex<HashMap<DpGraphCacheContext, Vec<DpGraphCacheEntry>>>>,
    graph_edge_cache: Arc<Mutex<HashMap<DpGraphEdgeCacheKey, bool>>>,
    size_change_closure_cache: Arc<Mutex<HashMap<DpSizeChangeClosureCacheKey, bool>>>,
    size_change_attempt_cache: Arc<Mutex<HashSet<DpSizeChangeAttemptCacheKey>>>,
}

pub(crate) fn reconstruct_dependency_pair_proof(
    state: &DpProblemState,
    tree: DpProofTree,
) -> DependencyPairProof {
    let initial_pairs = state.pairs.len();
    let component_proofs = match tree {
        DpProofTree::DepGraph { components } => components,
        tree => vec![component_proof_from_tree(state.pairs.clone(), tree)],
    };
    let removed_pairs = component_proofs
        .iter()
        .map(removed_pairs_in_component_proof)
        .sum();
    let usable_rules = component_proofs
        .iter()
        .flat_map(|component| component.reductions.iter())
        .map(|reduction| reduction.usable_rules.len())
        .sum();
    let smt_solved = component_proofs
        .iter()
        .flat_map(|component| component.reductions.iter())
        .any(|reduction| reduction_pair_backend(&reduction.reduction_pair) == DpSearchBackend::Smt);
    DependencyPairProof {
        initial_pairs,
        components: component_proofs.len(),
        removed_pairs,
        usable_rules,
        smt_attempted: smt_solved,
        smt_solved,
        strategy: state.trs.strategy(),
        pairs: state.pairs.clone(),
        component_proofs,
    }
}

/// Complete a one-processor probe without interpreting a root graph step as
/// the ambient decomposition of a complete proof.  Probe certificates must
/// describe the exact atom selected for the supplied state; their children
/// remain assumptions and are returned separately to the worklist caller.
pub(crate) fn complete_dependency_pair_probe(
    state: &DpProblemState,
    tree: DpProofTree,
) -> DependencyPairProof {
    let component_proofs = vec![component_proof_from_tree(state.pairs.clone(), tree)];
    let removed_pairs = component_proofs
        .iter()
        .map(removed_pairs_in_component_proof)
        .sum();
    let usable_rules = component_proofs
        .iter()
        .flat_map(|component| component.reductions.iter())
        .map(|reduction| reduction.usable_rules.len())
        .sum();
    let smt_solved = component_proofs
        .iter()
        .flat_map(|component| component.reductions.iter())
        .any(|reduction| reduction_pair_backend(&reduction.reduction_pair) == DpSearchBackend::Smt);
    DependencyPairProof {
        initial_pairs: state.pairs.len(),
        components: 1,
        removed_pairs,
        usable_rules,
        smt_attempted: smt_solved,
        smt_solved,
        strategy: state.trs.strategy(),
        pairs: state.pairs.clone(),
        component_proofs,
    }
}

fn reduction_pair_backend(reduction_pair: &DpReductionPairProof) -> DpSearchBackend {
    match reduction_pair {
        DpReductionPairProof::Polynomial { backend, .. }
        | DpReductionPairProof::NaturalPolynomial { backend, .. }
        | DpReductionPairProof::MaxPolynomial { backend, .. }
        | DpReductionPairProof::WeightedPathOrderMax { backend, .. }
        | DpReductionPairProof::RationalPolynomial { backend, .. }
        | DpReductionPairProof::RationalNaturalPolynomial { backend, .. }
        | DpReductionPairProof::Matrix { backend, .. }
        | DpReductionPairProof::IntegerMatrix { backend, .. }
        | DpReductionPairProof::ArcticMatrix { backend, .. }
        | DpReductionPairProof::PathOrder { backend, .. }
        | DpReductionPairProof::Kbo { backend, .. } => backend.clone(),
    }
}

fn removed_pairs_in_component_proof(component: &DpComponentProof) -> usize {
    component
        .proof_tree
        .as_deref()
        .map_or(0, removed_pairs_in_tree)
}

fn removed_pairs_in_tree(tree: &DpProofTree) -> usize {
    match tree {
        DpProofTree::Empty | DpProofTree::ExactXml(_) => 0,
        DpProofTree::QdpToSrs { removed_count, .. } => *removed_count,
        DpProofTree::SwitchToTrs { removed_count, .. } => *removed_count,
        DpProofTree::DepGraph { components } => components
            .iter()
            .map(removed_pairs_in_component_proof)
            .sum(),
        DpProofTree::GeneralRedPairExact { proofs, .. } => proofs
            .iter()
            .map(|proof| removed_pairs_in_tree(proof))
            .sum(),
        DpProofTree::ReductionPairExact {
            removed_count,
            proof,
            ..
        } => removed_count + removed_pairs_in_tree(proof),
        DpProofTree::Split {
            selected_proof,
            residual_proof,
            ..
        } => removed_pairs_in_tree(selected_proof) + removed_pairs_in_tree(residual_proof),
        DpProofTree::SwitchInnermost { proof, .. }
        | DpProofTree::TransformationExact { proof, .. }
        | DpProofTree::Narrowing { proof, .. }
        | DpProofTree::Instantiation { proof, .. }
        | DpProofTree::ForwardInstantiation { proof, .. }
        | DpProofTree::Rewriting { proof, .. }
        | DpProofTree::SemanticLabeling { proof, .. }
        | DpProofTree::Uncurry { proof, .. }
        | DpProofTree::ComponentContext { proof, .. } => removed_pairs_in_tree(proof),
        DpProofTree::Subterm {
            strict_pairs,
            proof,
            ..
        } => strict_pairs.len() + removed_pairs_in_tree(proof),
        DpProofTree::SizeChange { graphs } | DpProofTree::SizeChangeRedPair { graphs, .. } => {
            graphs.len()
        }
        DpProofTree::RedPair { reduction, proof } => {
            reduction.strict_pair_indices.len() + removed_pairs_in_tree(proof)
        }
    }
}

pub(crate) fn component_proof_from_tree(
    pairs: Vec<DependencyPair>,
    tree: DpProofTree,
) -> DpComponentProof {
    let (usable_rules_processor, innermost_lhss_processor, tree) = match tree {
        DpProofTree::ComponentContext {
            usable_rules_processor,
            innermost_lhss_processor,
            proof,
        } => (usable_rules_processor, innermost_lhss_processor, *proof),
        tree => (None, None, tree),
    };
    let reductions = reductions_in_tree(&tree);
    let final_acyclic_components = final_acyclic_components_in_tree(&tree);
    let (interpretation, backend) = first_polynomial_reduction_summary(&reductions);
    DpComponentProof {
        pairs,
        usable_rules: reductions
            .last()
            .map(|reduction| reduction.usable_rules.clone())
            .unwrap_or_default(),
        interpretation,
        backend,
        usable_rules_processor,
        innermost_lhss_processor,
        reductions,
        final_acyclic_components,
        proof_tree: Some(Box::new(tree)),
        proved: true,
    }
}

impl DpProofStats {
    pub(crate) fn detach_graph_caches(&mut self) {
        self.graph_cache = Default::default();
        self.graph_edge_cache = Default::default();
    }

    pub(crate) fn initial_ordinary(trs: &Trs) -> Self {
        Self {
            minimal: true,
            normal_form_substitutions: trs.strategy() == RewriteStrategy::Innermost,
            ..Self::default()
        }
    }

    pub(crate) fn pair_is_weak(&self, pair: &DependencyPair) -> bool {
        self.weak_pairs.iter().any(|weak| weak == pair)
    }
}

#[derive(Clone, Debug, Eq, Hash, PartialEq)]
struct DpGraphCacheContext {
    problem: DpProblemContext,
    trs: Trs,
    active_rules: Vec<RewriteRule>,
    innermost_lhss: Option<Vec<Term>>,
}

#[derive(Clone, Debug)]
struct DpGraphCacheEntry {
    pairs: Vec<DependencyPair>,
    graph: Vec<Vec<usize>>,
}

#[derive(Clone, Debug, Eq, Hash, PartialEq)]
enum DpGraphEdgeCacheKey {
    Dependency {
        strategy: RewriteStrategy,
        base_rules: Vec<RewriteRule>,
        active_rules: Vec<RewriteRule>,
        innermost_lhss: Option<Vec<Term>>,
        source_lhs: Option<Term>,
        pair: DependencyPair,
        target: DependencyPair,
    },
    Csr {
        csr: CsrTrs,
        innermost_lhss: Option<Vec<Term>>,
        pair: DependencyPair,
        target: DependencyPair,
    },
    CetaQ {
        active_rules: Vec<RewriteRule>,
        q_lhss: Vec<Term>,
        pair: DependencyPair,
        target: DependencyPair,
    },
}

#[derive(Clone, Debug, Eq, Hash, PartialEq)]
struct DpSizeChangeClosureCacheKey {
    graphs: Vec<DpSizeChangeGraph>,
    dependency_graph: Option<Vec<Vec<usize>>>,
}

#[derive(Clone, Debug, Eq, Hash, PartialEq)]
pub(crate) struct DpSizeChangeAttemptCacheKey {
    attempt: &'static str,
    option_key: DpProcessorOptionCacheKey,
    pairs: Vec<DependencyPair>,
    usable: Vec<RewriteRule>,
    innermost_lhss: Option<Vec<Term>>,
    dependency_graph: Option<Vec<Vec<usize>>>,
}

#[derive(Clone, Debug, Eq, Hash, PartialEq)]
struct DpProcessorOptionCacheKey {
    llm_iterations: usize,
    max_symbol_weight: i64,
    max_symbols: usize,
    max_polynomial_constant: i64,
    max_polynomial_coefficient: i64,
    max_polynomial_symbols: usize,
    max_polynomial_arity: usize,
    max_component_pairs: usize,
    max_search_space: usize,
    max_narrowing_steps: usize,
    max_narrowing_transforms: usize,
    max_forward_instantiation_transforms: usize,
    max_narrowings_per_pair: usize,
    max_rewritings_per_pair: usize,
    max_instantiations_per_pair: usize,
    max_forward_instantiations_per_pair: usize,
    max_narrowings_per_step: usize,
    smt_fallback: bool,
    smt_solver: Option<String>,
}

#[derive(Clone, Debug)]
struct DpModelGuidance {
    strategy: DpStrategy,
}

fn dp_strategy_from_model_prediction(state: &DpProblemState) -> Option<DpModelGuidance> {
    let timing_started = std::time::Instant::now();
    let timing_trace = std::env::var_os("FERRUM_TIMING_TRACE").is_some();
    let trs = &state.trs;
    let pairs = &state.pairs;
    let problem = &state.stats.problem;
    let options = &state.options;
    let raw_input_cpf = dp_state_input_cpf(state);
    if timing_trace {
        eprintln!(
            "dp guidance raw-input elapsed_ms={} bytes={}",
            timing_started.elapsed().as_millis(),
            raw_input_cpf.len()
        );
    }
    let problem_kind = match problem {
        DpProblemContext::Ordinary => "qdp",
        DpProblemContext::ContextSensitive(_) => "qcs-dp",
    };
    // These are standalone source-bound transformations, not complete-proof
    // shortcuts. Their native applicability checks preserve/validate Q, R
    // and the child boundary. Full-context canonical lookup must expose them
    // for ordinary innermost DP states too; otherwise variable freshening
    // alone makes a retained local continuation invisible. CSR lookup keeps
    // its existing, separate relocation policy.
    let allow_complete_transformation_relocation = matches!(problem, DpProblemContext::Ordinary);
    // A byte-exact certified action is already the most specific oracle hit.
    // Canonicalizing a large residual before honoring it is redundant and,
    // for graph decompositions with hundreds of independently guided SCCs,
    // used to consume the entire replay deadline.
    let raw_strong_exact_prediction = options
        .utility_guidance
        .as_ref()
        .filter(|_| matches!(problem, DpProblemContext::Ordinary))
        // Small residual chains normally need canonical alternatives too.
        // Explicit state-local replay order also enables the raw shortcut:
        // canonicalization of a small but highly symmetric signature can
        // otherwise dominate the deadline despite known native guidance.
        .filter(|lookup| pairs.len() >= 128 || raw_input_cpf.len() >= 64 * 1024
            || lookup.has_replay_order(&raw_input_cpf))
        .and_then(|lookup| lookup.predict(&raw_input_cpf))
        .filter(|prediction| {
            prediction
                .solved
                .iter()
                .chain(&prediction.transformed_strong)
                .any(|candidate| candidate.starts_with("exact-"))
                || (options.utility_guidance.as_ref().is_some_and(|lookup|
                    lookup.has_replay_order(&raw_input_cpf)) && !prediction.ordered_positive.is_empty())
        });
    if timing_trace {
        eprintln!(
            "dp guidance raw-lookup elapsed_ms={} hit={}",
            timing_started.elapsed().as_millis(),
            raw_strong_exact_prediction.is_some()
        );
    }
    let (canonical_input_cpf, canonical_error) = if raw_strong_exact_prediction.is_some() {
        (
            String::new(),
            Some("skipped after exact raw oracle hit".to_owned()),
        )
    } else {
        standardized_dp_problem_state_input_cpf(state)
    };
    let (prediction, source) = if let Some(lookup) = options.utility_guidance.as_ref() {
        if matches!(problem, DpProblemContext::ContextSensitive(_)) {
            // Canonicalize the complete QCS-DP state, including the
            // replacement map. Never merge with an ordinary-DP serialization,
            // which would silently strengthen the rewrite relation.
            // Older certified improved-CS-DP states omitted the fresh,
            // deterministically frozen U symbol from the serialized
            // replacement map.  The proof serializer now declares it
            // explicitly, as CPF requires, but that representational repair
            // must not orphan the already certified oracle state.  Query the
            // old byte representation as a compatibility alias; it denotes
            // exactly the same rewrite relation because this helper accepts
            // only a frozen fresh-U entry.
            let legacy_raw_input = legacy_frozen_unhiding_oracle_input(&raw_input_cpf);
            let legacy_canonical_input = legacy_frozen_unhiding_oracle_input(&canonical_input_cpf);
            let legacy_raw_active = without_active_rules_residual_marker(&raw_input_cpf);
            let legacy_canonical_active =
                without_active_rules_residual_marker(&canonical_input_cpf);
            let mut exact_inputs = vec![raw_input_cpf.as_str()];
            for legacy in [
                legacy_raw_input.as_deref(),
                legacy_canonical_input.as_deref(),
                legacy_raw_active.as_deref(),
                legacy_canonical_active.as_deref(),
            ]
            .into_iter()
            .flatten()
            {
                if !exact_inputs.contains(&legacy) {
                    exact_inputs.push(legacy);
                }
            }
            let raw_prediction = lookup.predict_prefer_exact_aliases(
                &exact_inputs,
                &raw_input_cpf,
                allow_complete_transformation_relocation,
            );
            let prediction = if canonical_error.is_some() {
                raw_prediction
            } else {
                lookup.predict_prefer_exact_aliases(
                    &exact_inputs,
                    &canonical_input_cpf,
                    allow_complete_transformation_relocation,
                )
            };
            let Some(prediction) = prediction else {
                write_dp_llm_guidance_query_event(
                    trs,
                    pairs,
                    "failed",
                    "none",
                    None,
                    Some(
                        "utility lookup miss for raw and canonical context-sensitive DP state"
                            .to_string(),
                    ),
                    0,
                    0,
                    "utility-lookup-canonical+raw",
                    &raw_input_cpf,
                    problem_kind,
                );
                return None;
            };
            (prediction, "utility-lookup-canonical+raw")
        } else {
            let raw_prediction =
                raw_strong_exact_prediction.or_else(|| lookup.predict(&raw_input_cpf));
            if let Some(error) = canonical_error.clone() {
                if let Some(prediction) = raw_prediction {
                    (prediction, "utility-lookup-raw")
                } else {
                    write_dp_llm_guidance_query_event(
                        trs,
                        pairs,
                        "failed",
                        "none",
                        None,
                        Some(error),
                        0,
                        0,
                        "utility-lookup-canonical",
                        &canonical_input_cpf,
                        problem_kind,
                    );
                    return None;
                }
            } else {
                // The bridge-soundness marker was added after the retained
                // oracle states were frozen.  It restricts which processors
                // may close the state, but does not change P, R, Q, or any
                // graph/order witness.  Query the pre-marker spelling as a
                // compatibility alias and let every selected processor check
                // the live state (in particular SCT/subterm still reject the
                // marked boundary).  Keeping the marker in the primary key
                // and worklist key prevents the two obligations from being
                // conflated during search.
                let legacy_raw_bridge = without_ordinary_bridge_minimality_marker(&raw_input_cpf);
                let legacy_canonical_bridge =
                    without_ordinary_bridge_minimality_marker(&canonical_input_cpf);
                let legacy_raw_active = without_active_rules_residual_marker(&raw_input_cpf);
                let legacy_canonical_active =
                    without_active_rules_residual_marker(&canonical_input_cpf);
                let mut exact_inputs = vec![raw_input_cpf.as_str()];
                for legacy in [
                    legacy_raw_bridge.as_deref(),
                    legacy_canonical_bridge.as_deref(),
                    legacy_raw_active.as_deref(),
                    legacy_canonical_active.as_deref(),
                ]
                .into_iter()
                .flatten()
                {
                    if !exact_inputs.contains(&legacy) {
                        exact_inputs.push(legacy);
                    }
                }
                let prediction = lookup.predict_prefer_exact_aliases(
                    &exact_inputs,
                    &canonical_input_cpf,
                    allow_complete_transformation_relocation,
                );
                // The marked/base relationship became part of ordinary-DP
                // canonicalization after the existing certified union was
                // frozen.  Preserve that union as a lookup-only compatibility
                // alias while all newly exported states use the safer key.
                // Selected exact processors still validate and relocate their
                // complete witness against the live state.
                let prediction = prediction.or_else(|| {
                    let (legacy_unpinned, legacy_error) =
                        standardized_dp_problem_state_input_cpf_with_marked_base(state, false);
                    if legacy_error.is_some() || legacy_unpinned == canonical_input_cpf {
                        return None;
                    }
                    let legacy_bridge = without_ordinary_bridge_minimality_marker(&legacy_unpinned);
                    let legacy_active = without_active_rules_residual_marker(&legacy_unpinned);
                    let mut legacy_exact_inputs = exact_inputs.clone();
                    for legacy in [legacy_bridge.as_deref(), legacy_active.as_deref()]
                        .into_iter()
                        .flatten()
                    {
                        if !legacy_exact_inputs.contains(&legacy) {
                            legacy_exact_inputs.push(legacy);
                        }
                    }
                    let prediction = lookup.predict_prefer_exact_aliases(
                        &legacy_exact_inputs,
                        &legacy_unpinned,
                        allow_complete_transformation_relocation,
                    );
                    if dp_llm_debug() {
                        let contextless = without_ferrum_dp_state_context(&legacy_unpinned);
                        eprintln!(
                            "portable exact unpinned lookup hit={} unpinned_key={:x} contextless_key={}",
                            prediction.is_some(),
                            Sha256::digest(legacy_unpinned.trim().as_bytes()),
                            contextless
                                .as_deref()
                                .map(|cpf| format!("{:x}", Sha256::digest(cpf.trim().as_bytes())))
                                .unwrap_or_default(),
                        );
                    }
                    prediction.or_else(|| {
                        without_ferrum_dp_state_context(&legacy_unpinned).and_then(|legacy| {
                            lookup.predict_portable_exact(
                                &legacy,
                                allow_complete_transformation_relocation,
                            )
                        })
                    })
                });
                let prediction = prediction.or_else(|| {
                    let semantic_core = if trs.strategy() == crate::core::RewriteStrategy::Full
                        && state.innermost_lhss.is_none()
                    {
                        let mut core_state = state.clone();
                        core_state.stats.active_rules = None;
                        core_state.stats.graph_rules = None;
                        core_state.stats.transformation_rules = None;
                        core_state.stats.active_rules_are_residual = false;
                        core_state.stats.ordinary_reduction_started = false;
                        core_state.stats.ordinary_bridge_loses_minimality = false;
                        let (with_context, error) =
                            standardized_dp_problem_state_input_cpf(&core_state);
                        error
                            .is_none()
                            .then(|| without_ferrum_dp_state_context(&with_context))
                            .flatten()
                    } else {
                        None
                    };
                    semantic_core.as_deref().and_then(|cpf| {
                        lookup.predict_semantic_canonical(
                            cpf,
                            allow_complete_transformation_relocation,
                        )
                    })
                });
                let prediction = prediction.or_else(|| {
                    let raw_legacy = without_ferrum_dp_state_context(&raw_input_cpf)?;
                    let canonical_legacy = without_ferrum_dp_state_context(&canonical_input_cpf);
                    let (proof_canonical, proof_canonical_error) =
                        standardized_dp_input_cpf3(trs, pairs);
                    let (proof_state_core, proof_state_core_error) =
                        standardized_dp_state_input_cpf3(
                            trs,
                            pairs,
                            None,
                            state.stats.minimal,
                            state.stats.normal_form_substitutions,
                        );
                    // A usable-rule reduction keeps the mathematical CPF
                    // successor (P, R) but Ferrum executes later processors
                    // over the smaller active rule set U(P, R).  The live
                    // state consequently serializes U in <trs> and retains R
                    // in transformationRules, whereas an extracted CPF proof
                    // node serializes R directly in <trs>.  Query that proof
                    // projection as a compatibility alias.  Only portable
                    // exact candidates may cross this boundary, and each of
                    // them independently validates its complete source
                    // obligation against the live state before it can make
                    // progress.
                    let proof_projection_results = state
                        .stats
                        .transformation_rules
                        .as_deref()
                        .filter(|rules| *rules != trs.rules())
                        .map(|rules| {
                            let variables = rules
                                .iter()
                                .flat_map(|rule| {
                                    rule.lhs()
                                        .variables()
                                        .into_iter()
                                        .chain(rule.rhs().variables())
                                })
                                .collect();
                            let proof_trs = Trs::new_with_strategy(
                                None,
                                variables,
                                rules.to_vec(),
                                trs.strategy(),
                            );
                            [
                                standardized_dp_state_input_cpf3(
                                    &proof_trs,
                                    pairs,
                                    Some(trs.rules()),
                                    state.stats.minimal,
                                    state.stats.normal_form_substitutions,
                                ),
                                standardized_dp_state_input_cpf3(
                                    &proof_trs,
                                    pairs,
                                    None,
                                    state.stats.minimal,
                                    state.stats.normal_form_substitutions,
                                ),
                            ]
                        })
                        .into_iter()
                        .flatten()
                        .collect::<Vec<_>>();
                    let proof_projections = proof_projection_results
                        .iter()
                        .filter_map(|(cpf, error)| error.is_none().then_some(cpf.clone()))
                        .collect::<Vec<_>>();
                    let canonical_sources = (0..pairs.len()).collect::<Vec<_>>();
                    let proof_canonical_with_context =
                        crate::cert::append_ferrum_dp_state_context(
                            proof_canonical.clone(),
                            &canonical_sources,
                            &[],
                            &[],
                            None,
                            false,
                            None,
                            None,
                            false,
                            false,
                            false,
                            trs.strategy() == crate::core::RewriteStrategy::Innermost,
                            false,
                        );
                    let raw_hit = lookup.predict_portable_exact(
                        &raw_legacy,
                        allow_complete_transformation_relocation,
                    );
                    let canonical_context_hit = proof_canonical_error
                        .is_none()
                        .then(|| {
                            lookup.predict_portable_exact(
                                &proof_canonical_with_context,
                                allow_complete_transformation_relocation,
                            )
                        })
                        .flatten();
                    let canonical_hit = lookup.predict_portable_exact(
                        &proof_canonical,
                        allow_complete_transformation_relocation,
                    );
                    let proof_state_core_hit = proof_state_core_error.is_none().then(|| {
                        lookup.predict_portable_exact(
                            &proof_state_core,
                            allow_complete_transformation_relocation,
                        )
                    }).flatten();
                    let proof_projection_hit = proof_projections.iter().find_map(|cpf| {
                        lookup.predict_portable_exact(cpf, allow_complete_transformation_relocation)
                    });
                if dp_llm_debug() {
                    let proof_projection_keys = proof_projections
                        .iter()
                        .map(|cpf| format!("{:x}", Sha256::digest(cpf.trim().as_bytes())))
                        .collect::<Vec<_>>();
                    let proof_projection_errors = proof_projection_results
                        .iter()
                        .filter_map(|(_, error)| error.as_deref())
                        .collect::<Vec<_>>();
                    eprintln!(
                        "portable exact legacy lookup pairs={} raw={} canonical_context={} canonical={} proof_projection={} projection_keys={:?} projection_errors={:?} raw_len={} raw_key={:x} canonical_context_len={} live_canonical_len={}",
                        pairs.len(),
                        raw_hit.is_some(),
                        canonical_context_hit.is_some(),
                        canonical_hit.is_some(),
                        proof_state_core_hit.is_some() || proof_projection_hit.is_some(),
                        proof_projection_keys,
                        proof_projection_errors,
                        raw_legacy.len(),
                        Sha256::digest(raw_input_cpf.trim().as_bytes()),
                        proof_canonical_with_context.len(),
                        canonical_input_cpf.len(),
                    );
                    }
                    raw_hit
                        .or(canonical_context_hit)
                        .or(canonical_hit)
                        .or(proof_state_core_hit)
                        .or(proof_projection_hit)
                        .or_else(|| {
                            canonical_legacy.as_deref().and_then(|cpf| {
                                lookup.predict_semantic_canonical(
                                    cpf,
                                    allow_complete_transformation_relocation,
                                )
                            })
                        })
                        .or_else(|| {
                            canonical_legacy
                                .as_deref()
                                .and_then(|cpf| {
                                    lookup.predict_portable_exact(
                                        cpf,
                                        allow_complete_transformation_relocation,
                                    )
                                })
                        })
                });
                let Some(prediction) = prediction else {
                    write_dp_llm_guidance_query_event(
                        trs,
                        pairs,
                        "failed",
                        "none",
                        None,
                        Some("utility lookup miss after canonical merge".to_string()),
                        0,
                        0,
                        "utility-lookup-canonical+raw",
                        &canonical_input_cpf,
                        problem_kind,
                    );
                    return None;
                };
                (prediction, "utility-lookup-canonical+raw")
            }
        }
    } else {
        let client = options.llm_client.as_ref()?;
        let (canonical_input_cpf, error) = standardized_dp_input_cpf3(trs, pairs);
        if let Some(error) = error {
            write_dp_llm_guidance_query_event(
                trs,
                pairs,
                "failed",
                "none",
                None,
                Some(error),
                0,
                0,
                "llm",
                &canonical_input_cpf,
                problem_kind,
            );
            return None;
        }
        match client.request_status_map(&canonical_input_cpf) {
            Ok(prediction) => (prediction, "llm"),
            Err(error) => {
                write_dp_llm_guidance_query_event(
                    trs,
                    pairs,
                    "failed",
                    "none",
                    None,
                    Some(error.to_string()),
                    0,
                    0,
                    "llm",
                    &canonical_input_cpf,
                    problem_kind,
                );
                return None;
            }
        }
    };
    if dp_llm_debug() {
        eprintln!(
            "Ferrum DP LLM prediction for {} pairs: solved={:?}; transformed_strong={:?}; transformed_weak={:?}; failed={:?}; timeout={:?}",
            pairs.len(),
            prediction.solved,
            prediction.transformed_strong,
            prediction.transformed_weak,
            prediction.failed,
            prediction.timeout
        );
    }
    let mut strategies = Vec::new();
    let positive_atoms = if prediction.ordered_positive.is_empty() {
        prediction.solved.len()
            + prediction.transformed_strong.len()
            + prediction.transformed_weak.len()
    } else {
        prediction.ordered_positive.len()
    };
    let ordered_evidence = !prediction.ordered_positive.is_empty();
    let mut atoms = Vec::new();
    if !ordered_evidence {
        atoms.extend(prediction.solved.iter().map(|atom| (0u8, atom)));
        atoms.extend(prediction.transformed_strong.iter().map(|atom| (1u8, atom)));
        atoms.extend(prediction.transformed_weak.iter().map(|atom| (2u8, atom)));
    } else {
        atoms.extend(prediction.ordered_positive.iter().map(|atom| {
            let rank = if prediction.solved.contains(atom) {
                0
            } else if prediction.transformed_strong.contains(atom) {
                1
            } else {
                2
            };
            (rank, atom)
        }));
    }
    if dp_llm_try_timeout_candidates() {
        atoms.extend(prediction.timeout.iter().map(|atom| (3u8, atom)));
    }
    if dp_llm_try_failed_candidates() {
        atoms.extend(prediction.failed.iter().map(|atom| (4u8, atom)));
    }
    if !ordered_evidence {
        // An exported ordered-positive sequence records the causal order of a
        // certified replay and is authoritative.  In particular, do not move
        // an exact reduction-pair transformation ahead of an earlier closing
        // atom: although its witness is valid for the live P/R state, its
        // residual may belong to a different, uncovered proof chain.  Legacy
        // unordered manifests still use the generic cost ordering below.
        atoms.sort_by_key(|(evidence_rank, atom)| {
            (
                { if *atom == "size-change" { 0 } else { 1 } },
                *evidence_rank,
                {
                    if atom.starts_with("exact-") {
                        0
                    } else if matches!(atom.as_str(), "graph" | "usable-rules" | "subterm") {
                        1
                    } else if atom.starts_with("rat-poly(") || atom.starts_with("rational-poly(") {
                        3
                    } else {
                        2
                    }
                },
            )
        });
    }
    for (evidence_rank, atom) in atoms.into_iter() {
        // Complete-GM04 graph components all use the paper's fixed
        // administrative RPO.  Extracted CPF evidence used to serialize that
        // same order together with the entire 666-rule transformed state for
        // every tiny SCC.  Recognize a certified RPO red-pair atom and rebuild
        // the equivalent role-based witness directly from the live GM04
        // context.  The ExactPathOrder processor still checks every live weak
        // rule and strict pair and emits the ordinary CPF order proof; this
        // only avoids decoding megabytes of duplicate source XML per SCC.
        let gm04_rpo = (options.gm04_residual.is_some()
            && atom.starts_with("exact-red-pair(hex=")
            && atom.contains("3c726563757273697665506174684f726465723e"))
        .then(|| {
            crate::proving::processors::dp::gm04_administrative_rpo(state)
                .map(DpStrategy::Processor)
        })
        .flatten();
        let parsed = gm04_rpo.map_or_else(|| DpStrategy::parse(atom), Ok);
        match parsed {
            Ok(mut strategy) if matches!(strategy, DpStrategy::Processor(_)) => {
                if let DpStrategy::Processor(DpStrategyProcessor::ExactDependencyGraph {
                    source_dp_input_xml: Some(source),
                    source_is_live,
                    ..
                }) = &mut strategy
                {
                    let source = source.trim();
                    // Only byte/content-address identity with the complete live
                    // state may bypass source validation.  A canonical CPF is
                    // intentionally coarser (and historically omitted pieces
                    // of GM04/CSR residual context), so treating equality with
                    // it as state identity can transport a graph containing
                    // rules from another transformed system.  Portable exact
                    // witnesses still replay after renaming, but must pass the
                    // full TRS/pair/context isomorphism below.
                    *source_is_live = source == raw_input_cpf.trim();
                }
                strategies.push(DpStrategy::Timeout {
                    duration: dp_llm_measured_atom_timeout(atom, evidence_rank,
                        prediction.measured_elapsed_ms.get(atom.as_str()).copied()),
                    strategy: Box::new(strategy),
                });
            }
            Ok(_) => {
                if dp_llm_debug() {
                    eprintln!("Ferrum DP LLM ignored composed oracle advice {atom:?}");
                }
            }
            Err(error) => {
                if dp_llm_debug() {
                    eprintln!("Ferrum DP LLM ignored unparsable atom {atom:?}: {error:#}");
                }
            }
        }
        // Root-local certified atom pools intentionally contain alternative
        // processors for state-drifted residuals.  Keep the bound finite, but
        // do not truncate a typical certified proof's atom vocabulary before
        // the applicable exact model is reached.
        if strategies.len() >= 128 {
            break;
        }
    }
    if timing_trace {
        eprintln!(
            "dp guidance parsed elapsed_ms={} strategies={}",
            timing_started.elapsed().as_millis(),
            strategies.len()
        );
    }
    // Canonical residuals can legitimately aggregate several isomorphic,
    // source-checked reduction-pair witnesses.  Their historical utility
    // order is not a proof-chain order: trying a one-pair deletion before an
    // available two-pair deletion creates many avoidable intermediate
    // residuals and exponential backtracking across graph components.  When
    // this state offers only exact reduction pairs, prefer the strongest
    // certified deletion.  Choice still retains every smaller deletion as a
    // sound fallback if the maximal child lacks a continuation.
    let exact_removed_count = |strategy: &DpStrategy| match strategy {
        DpStrategy::Timeout { strategy, .. } => match strategy.as_ref() {
            DpStrategy::Processor(DpStrategyProcessor::ExactReductionPair {
                removed_indices,
                ..
            }) => Some(removed_indices.len()),
            _ => None,
        },
        _ => None,
    };
    if !strategies.is_empty()
        && strategies
            .iter()
            .all(|strategy| exact_removed_count(strategy).is_some())
    {
        strategies.sort_by_key(|strategy| {
            std::cmp::Reverse(exact_removed_count(strategy).unwrap_or_default())
        });
    }
    dedup_dp_strategies(&mut strategies);
    if timing_trace {
        eprintln!(
            "dp guidance deduped elapsed_ms={} strategies={}",
            timing_started.elapsed().as_millis(),
            strategies.len()
        );
    }
    if dp_llm_debug() {
        eprintln!("Ferrum DP LLM guided strategy: {strategies:?}");
    }
    if strategies.is_empty() {
        write_dp_llm_guidance_query_event(
            trs,
            pairs,
            "failed",
            "none",
            Some(&prediction),
            None,
            positive_atoms,
            0,
            source,
            &raw_input_cpf,
            problem_kind,
        );
        return None;
    }
    Some(DpModelGuidance {
        // Oracle alternatives are ranked, independently executable atoms.
        // A transformation is only progress, not a proof: racing with
        // cancel-on-progress can kill the exact branch and then discover that
        // the winning child has no continuation.  Choice preserves the
        // ranking and backtracks whenever a transformed residual cannot be
        // closed, which is the required worklist/oracle contract.
        strategy: DpStrategy::Choice(strategies),
    })
}

/// Recover the pre-`ferrumDpStateContext` serialization used by archived CPF
/// proof nodes.  The caller exposes only self-validating portable exact
/// processors from this alias; native graph/order advice still requires the
/// complete live context.
pub(crate) fn without_ferrum_dp_state_context(cpf: &str) -> Option<String> {
    let start = cpf.find("<ferrumDpStateContext>")?;
    let relative_end = cpf[start..].find("</ferrumDpStateContext>")?;
    let end = start + relative_end + "</ferrumDpStateContext>".len();
    let line_start = cpf[..start].rfind('\n').map_or(start, |index| index + 1);
    let line_end = if cpf.as_bytes().get(end) == Some(&b'\n') {
        end + 1
    } else {
        end
    };
    let mut legacy = String::with_capacity(cpf.len() - (line_end - line_start));
    legacy.push_str(&cpf[..line_start]);
    legacy.push_str(&cpf[line_end..]);
    Some(legacy)
}

/// Recover the immediately preceding serialization of an ordinary DP state
/// crossing a CSR proof bridge.  This is an oracle lookup alias only: the
/// executable state retains the marker, hashes it in the worklist key, and
/// processors validate against that live state before producing a proof.
fn without_ordinary_bridge_minimality_marker(cpf: &str) -> Option<String> {
    const TAG: &str = "<ordinaryBridgeLosesMinimality>true</ordinaryBridgeLosesMinimality>";
    let tag_start = cpf.find(TAG)?;
    let tag_end = tag_start + TAG.len();
    let line_start = cpf[..tag_start]
        .rfind('\n')
        .map_or(tag_start, |index| index + 1);
    let line_end = if cpf.as_bytes().get(tag_end) == Some(&b'\n') {
        tag_end + 1
    } else {
        tag_end
    };
    let mut legacy = String::with_capacity(cpf.len() - (line_end - line_start));
    legacy.push_str(&cpf[..line_start]);
    legacy.push_str(&cpf[line_end..]);
    Some(legacy)
}

/// Compatibility alias for certified oracle states frozen before the
/// residual-rule progress marker was serialized.  The marker remains on the
/// executable state and in its worklist key; removing it is lookup-only.
fn without_active_rules_residual_marker(cpf: &str) -> Option<String> {
    const TAG: &str = "<activeRulesAreResidual>true</activeRulesAreResidual>";
    let tag_start = cpf.find(TAG)?;
    let tag_end = tag_start + TAG.len();
    let line_start = cpf[..tag_start]
        .rfind('\n')
        .map_or(tag_start, |index| index + 1);
    let line_end = if cpf.as_bytes().get(tag_end) == Some(&b'\n') {
        tag_end + 1
    } else {
        tag_end
    };
    let mut legacy = String::with_capacity(cpf.len() - (line_end - line_start));
    legacy.push_str(&cpf[..line_start]);
    legacy.push_str(&cpf[line_end..]);
    Some(legacy)
}

pub(crate) fn worklist_guidance_strategy(state: &DpProblemState) -> Option<DpStrategy> {
    dp_strategy_from_model_prediction(state).map(|guidance| guidance.strategy)
}

pub(crate) fn dp_state_input_cpf(state: &DpProblemState) -> String {
    let trs = &state.trs;
    let pairs = &state.pairs;
    let stats = &state.stats;
    let csr_context = match &stats.problem {
        DpProblemContext::ContextSensitive(context) => Some(context),
        DpProblemContext::Ordinary => stats.semantic_csr_context.as_ref(),
    };
    let xml = match csr_context {
        None => {
            // `None` and an explicit copy of the complete TRS denote the
            // same active-rule obligation.  Materialization already folds
            // the latter into `None`; serialize live states identically so
            // their oracle identity survives a CPF round trip.
            let active_rules = stats
                .active_rules
                .as_deref()
                .filter(|rules| *rules != trs.rules());
            write_relative_dp_state_input_cpf3(
                trs,
                pairs,
                &stats.weak_pairs,
                active_rules,
                stats.minimal,
                stats.normal_form_substitutions,
            )
        }
        Some(context) => {
            let active_rules = stats
                .active_rules
                .as_deref()
                .or_else(|| (trs.rules() != context.csr.trs().rules()).then_some(trs.rules()));
            write_csr_dp_state_input_cpf4(
                &context.csr,
                pairs,
                &stats.weak_pairs,
                active_rules,
                stats.minimal,
                context.construction.as_str(),
                context.graph_estimator.as_str(),
                context.use_qcs_usable_rules,
            )
        }
    };
    let default_lhss = initial_innermost_lhss(trs);
    let context_lhss = match (state.innermost_lhss.as_deref(), default_lhss.as_deref()) {
        (Some(current), Some(default)) if current != default => Some(current),
        (Some(current), None) => Some(current),
        _ => None,
    };
    let clear_innermost_lhss = state.innermost_lhss.is_none() && default_lhss.is_some();
    let graph_rules = stats
        .graph_rules
        .as_deref()
        .filter(|rules| *rules != trs.rules());
    crate::cert::append_ferrum_dp_state_context(
        xml,
        &state
            .pairs
            .iter()
            .map(DependencyPair::source_rule)
            .collect::<Vec<_>>(),
        &stats
            .weak_pairs
            .iter()
            .map(DependencyPair::source_rule)
            .collect::<Vec<_>>(),
        &stats.strict_rules,
        context_lhss,
        clear_innermost_lhss,
        graph_rules,
        stats.transformation_rules.as_deref(),
        stats.active_rules_are_residual,
        stats.ordinary_reduction_started,
        stats.ordinary_bridge_loses_minimality,
        trs.strategy() == crate::core::RewriteStrategy::Innermost,
        stats.semantic_csr_context.is_some(),
    )
}

/// Reconstruct the pre-fix oracle representation of an improved CS-DP state.
///
/// This is deliberately narrower than general XML canonicalization: only a
/// fresh `__CSR_U*` replacement-map entry with arity one and no active
/// position is removable.  Such an entry explicitly records a frozen symbol,
/// so omitting it changes representation but not the processor obligation.
fn legacy_frozen_unhiding_oracle_input(cpf: &str) -> Option<String> {
    let strategy_start = cpf.find("<strategy>")?;
    let mut cursor = strategy_start;
    while let Some(relative_start) = cpf[cursor..].find("<replacementMapEntry>") {
        let tag_start = cursor + relative_start;
        let line_start = cpf[..tag_start].rfind('\n').map_or(0, |index| index + 1);
        let relative_end = cpf[tag_start..].find("</replacementMapEntry>")?;
        let tag_end = tag_start + relative_end + "</replacementMapEntry>".len();
        let block = &cpf[tag_start..tag_end];
        let is_frozen_fresh_unhiding = block.contains("<name>__CSR_U")
            && block.contains("<arity>1</arity>")
            && !block.contains("<position>");
        if is_frozen_fresh_unhiding {
            let line_end = if cpf.as_bytes().get(tag_end) == Some(&b'\n') {
                tag_end + 1
            } else {
                tag_end
            };
            let mut legacy = String::with_capacity(cpf.len() - (line_end - line_start));
            legacy.push_str(&cpf[..line_start]);
            legacy.push_str(&cpf[line_end..]);
            return Some(legacy);
        }
        cursor = tag_end;
    }
    None
}

fn dedup_dp_strategies(strategies: &mut Vec<DpStrategy>) {
    let mut seen = BTreeSet::new();
    strategies.retain(|strategy| seen.insert(format!("{strategy:?}")));
}

fn write_dp_llm_guidance_query_event(
    trs: &Trs,
    pairs: &[DependencyPair],
    outcome: &str,
    progress: &str,
    prediction: Option<&StatusMapPrediction>,
    error: Option<String>,
    positive_atoms: usize,
    parsed_candidates: usize,
    source: &'static str,
    input_cpf: &str,
    problem_kind: &'static str,
) {
    write_dp_llm_guidance_event(
        trs,
        pairs,
        outcome,
        progress,
        Duration::ZERO,
        prediction,
        error,
        positive_atoms,
        parsed_candidates,
        source,
        input_cpf,
        problem_kind,
    );
}

fn write_dp_llm_guidance_event(
    trs: &Trs,
    pairs: &[DependencyPair],
    outcome: &str,
    progress: &str,
    elapsed: Duration,
    prediction: Option<&StatusMapPrediction>,
    error: Option<String>,
    positive_atoms: usize,
    parsed_candidates: usize,
    guidance_source: &str,
    input_cpf: &str,
    problem_kind: &str,
) {
    if !processor_event_log_enabled() {
        return;
    }
    // Utility-oracle events are replay inputs, including successful
    // intermediate states.  The event runtime retains the first occurrence
    // of every content-addressed CPF inline; subsequent occurrences can refer
    // to that key.  Forcing every repeated query inline made a single GM04
    // replay write hundreds of megabytes of duplicate state XML.
    let mut input = processor_event_raw_input(input_cpf.to_string(), "cpf3", false);
    if let Some(input) = input.as_object_mut() {
        input.insert(
            "dependency_pairs".to_string(),
            json!(
                pairs
                    .iter()
                    .map(|pair| format!("{} -> {}", pair.lhs(), pair.rhs()))
                    .collect::<Vec<_>>()
            ),
        );
    }
    let context = processor_event_context_or_problem_name(trs.name());
    let witness = prediction.map(|prediction| {
        if guidance_source.starts_with("utility-lookup") {
            let refs = |candidates: &[String]| {
                candidates
                    .iter()
                    .map(|candidate| {
                        json!({
                            "sha256": format!("{:x}", Sha256::digest(candidate.as_bytes())),
                            "bytes": candidate.len(),
                        })
                    })
                    .collect::<Vec<_>>()
            };
            json!({
                "kind": "status_map_refs",
                "solved": refs(&prediction.solved),
                "transformed_strong": refs(&prediction.transformed_strong),
                "transformed_weak": refs(&prediction.transformed_weak),
                "failed": refs(&prediction.failed),
                "timeout": refs(&prediction.timeout),
            })
        } else {
            json!({
                "kind": "status_map",
                "solved": prediction.solved,
                "transformed_strong": prediction.transformed_strong,
                "transformed_weak": prediction.transformed_weak,
                "failed": prediction.failed,
                "timeout": prediction.timeout,
            })
        }
    });
    write_processor_event(&json!({
        "schema": "ferrum.processor-event.v1",
        "run_id": context.as_ref().map(|context| context.run_id.as_str()),
        "problem_id": context.as_ref().map(|context| context.problem_id.as_str()),
        "category": context.as_ref().and_then(|context| context.category.as_deref()),
        "level": "dependency-pair",
        "problem_kind": problem_kind,
        "processor": if guidance_source.starts_with("utility-lookup") {
            "UtilityGuidance"
        } else {
            "LlmGuidance"
        },
        "strategy_atom": if guidance_source.starts_with("utility-lookup") {
            "utility-guidance"
        } else {
            "llm-guidance"
        },
        "outcome": outcome,
        "progress": progress,
        "elapsed_ms": elapsed.as_millis(),
        "input": input,
        "metrics": {
            "rules": trs.rules().len(),
            "pairs": pairs.len(),
            "strategy": format!("{:?}", trs.strategy()),
            "positive_atoms": positive_atoms,
            "parsed_candidates": parsed_candidates,
            "guidance_source": guidance_source,
            "solved_atoms": prediction.map_or(0, |prediction| prediction.solved.len()),
            "transformed_strong_atoms": prediction.map_or(0, |prediction| prediction.transformed_strong.len()),
            "transformed_weak_atoms": prediction.map_or(0, |prediction| prediction.transformed_weak.len()),
            "failed_atoms": prediction.map_or(0, |prediction| prediction.failed.len()),
            "timeout_atoms": prediction.map_or(0, |prediction| prediction.timeout.len()),
        },
        "witness": witness,
        "error": error,
        "credit": {
            "status": "pending"
        }
    }));
}

fn dp_llm_debug() -> bool {
    std::env::var_os("FERRUM_DP_LLM_DEBUG").is_some()
}

fn dp_llm_try_timeout_candidates() -> bool {
    std::env::var_os("FERRUM_DP_LLM_TRY_TIMEOUT").is_some()
}

fn dp_llm_try_failed_candidates() -> bool {
    std::env::var_os("FERRUM_DP_LLM_TRY_FAILED").is_some()
}

fn dp_llm_measured_atom_timeout(atom: &str, evidence_rank: u8, measured_ms: Option<u64>) -> Duration {
    let base = dp_llm_atom_timeout(atom, evidence_rank);
    crate::proving::runtime::measured_oracle_atom_timeout(base, measured_ms)
}

fn dp_llm_atom_timeout(atom: &str, evidence_rank: u8) -> Duration {
    // A certified oracle entry identifies a processor that is known to be
    // useful for this exact state.  The replay caller's deadline is the
    // authoritative ceiling; short portfolio-oriented atom limits used to
    // turn independently replayable mono-polynomial and instantiation states
    // into false oracle misses under a 60-second strict replay.
    if evidence_rank < 2 {
        return Duration::from_secs(60);
    }
    // Exact atoms are self-contained, independently rechecked witnesses.  A
    // root-local pool only weakens their ranking; it does not make validating
    // the witness cheaper.  In particular, usable-rule closure and matrix
    // validation on large transformed states can take substantially longer
    // than two seconds before exposing the independently guided child.  The
    // replay caller's deadline remains the hard ceiling, so retain the user's
    // full 60-second allowance at every exact CPF/runtime boundary.
    if atom.starts_with("exact-") {
        return Duration::from_secs(60);
    }
    // Root-local atom pools are deliberately weak: they recover a processor
    // family from a complete certified proof but do not claim it is the right
    // next action for this drifted residual.  Giving every such alternative
    // the full root budget lets one wrong synthesizer starve all later atoms.
    // Open searches receive bounded but useful local allowances and retain
    // the worklist fallback branch.
    let family = atom.split_once('(').map_or(atom, |(family, _)| family);
    match family {
        // Graph recomputation is a deterministic state analysis, not model
        // enumeration. Restarting the same large graph after a two-second
        // cutoff can consume the entire root budget without ever producing
        // its decomposition. Let it finish under the normal replay ceiling.
        "graph" => Duration::from_secs(60),
        "usable-rules" | "subterm" | "size-change" | "innermost-lhss"
        | "switch-innermost" | "switch-full" => Duration::from_secs(2),
        "narrow" | "rewrite" | "instantiate" | "forward-instantiate" => Duration::from_secs(10),
        "rat-poly" | "rational-poly" | "quadratic-poly" => Duration::from_secs(20),
        // These explicitly bounded syntheses jointly choose several order
        // components. The old generic eight-second allowance cuts off known
        // native 10–32 second searches even on the exact guided state.
        "wpo-max" | "rat-quadratic-poly" => Duration::from_secs(60),
        _ => Duration::from_secs(8),
    }
}

pub(crate) fn dp_pairs_overlap_rules(pairs: &[DependencyPair], rules: &[RewriteRule]) -> bool {
    pairs.iter().any(|pair| {
        positions_with_subterms(pair.lhs())
            .into_iter()
            .filter(|(_, subterm)| !matches!(subterm, Term::Var(_)))
            .any(|(_, subterm)| {
                rules
                    .iter()
                    .any(|rule| unifies_with_rule_lhs(subterm, rule.lhs()))
            })
    })
}

pub(crate) fn dp_rhs_roots_are_constructors(
    pairs: &[DependencyPair],
    rules: &[RewriteRule],
) -> bool {
    !pairs.iter().any(|pair| {
        pair.rhs().root_symbol().is_some_and(|root| {
            rules.iter().any(|rule| {
                rule.lhs()
                    .root_symbol()
                    .is_some_and(|defined| defined.as_str() == root.as_str())
            })
        })
    })
}

pub(crate) fn standardized_dp_input_cpf3(
    trs: &Trs,
    pairs: &[DependencyPair],
) -> (String, Option<String>) {
    standardized_dp_state_input_cpf3(trs, pairs, None, true, true)
}

/// Canonicalize the complete executable DP state used as an oracle key.
///
/// Unlike the CPF mathematical core, a live residual also contains Q,
/// graph/transformation rules, and pair-to-source provenance.  Canonicalizing
/// those collections together prevents order drift from orphaning guidance
/// while retaining every distinction that can change processor applicability.
pub(crate) fn standardized_dp_problem_state_input_cpf(
    state: &DpProblemState,
) -> (String, Option<String>) {
    standardized_dp_problem_state_input_cpf_with_marked_base(state, true)
}

fn standardized_dp_problem_state_input_cpf_with_marked_base(
    state: &DpProblemState,
    pin_ordinary_marked_base: bool,
) -> (String, Option<String>) {
    let csr_context = match &state.stats.problem {
        DpProblemContext::ContextSensitive(context) => Some(context),
        DpProblemContext::Ordinary => state.stats.semantic_csr_context.as_ref(),
    };
    let (base_rules, replacement_map) = match csr_context {
        None => (state.trs.rules(), None),
        Some(context) => (context.csr.rules(), Some(context.csr.replacement_map())),
    };
    let active_rules = match csr_context {
        None => state.stats.active_rules.as_deref().filter(|rules| {
            // An explicitly residual rule set is also a progress marker.  A
            // usable-rules step may compute a rule multiset alpha-equivalent
            // to R; dropping it would canonicalize the successor back to its
            // parent and replay the same transformation indefinitely.
            state.stats.active_rules_are_residual
                || !crate::proving::processors::dp::same_rule_multiset(rules, state.trs.rules())
        }),
        Some(context) => state.stats.active_rules.as_deref().or_else(|| {
            (state.trs.rules() != context.csr.trs().rules()).then_some(state.trs.rules())
        }),
    };
    let default_lhss = initial_innermost_lhss(&state.trs);
    let context_lhss = match (state.innermost_lhss.as_deref(), default_lhss.as_deref()) {
        (Some(current), Some(default)) if !same_alpha_term_multiset(current, default) => {
            Some(current)
        }
        (Some(current), None) => Some(current),
        _ => None,
    };
    let clear_innermost_lhss = state.innermost_lhss.is_none() && default_lhss.is_some();
    let graph_rules = state
        .stats
        .graph_rules
        .as_deref()
        .filter(|rules| *rules != state.trs.rules());
    let transformation_rules = state.stats.transformation_rules.as_deref();

    let mut groups = vec![
        StandardizationGroup::new(
            "rules",
            base_rules.iter().map(TermPair::from_rule).collect(),
        ),
        StandardizationGroup::new(
            "dps",
            state
                .pairs
                .iter()
                .map(|pair| TermPair::new(pair.lhs().clone(), pair.rhs().clone()))
                .collect(),
        ),
        StandardizationGroup::new(
            "weak-dps",
            state
                .stats
                .weak_pairs
                .iter()
                .map(|pair| TermPair::new(pair.lhs().clone(), pair.rhs().clone()))
                .collect(),
        ),
    ];
    let mut push_rules = |label: &str, rules: Option<&[RewriteRule]>| {
        if let Some(rules) = rules {
            groups.push(StandardizationGroup::new(
                label,
                rules.iter().map(TermPair::from_rule).collect(),
            ));
        }
    };
    push_rules("active-rules", active_rules);
    push_rules("graph-rules", graph_rules);
    push_rules("transformation-rules", transformation_rules);
    if let Some(lhss) = context_lhss {
        groups.push(StandardizationGroup::new(
            "innermost-lhss",
            lhss.iter()
                .map(|lhs| TermPair::new(lhs.clone(), lhs.clone()))
                .collect(),
        ));
    }
    let standardized =
        match standardize_problem_with_bijection(&StandardizationProblem::new(groups)) {
            Ok(standardized) => standardized,
            Err(error) => return (dp_state_input_cpf(state), Some(error.to_string())),
        };
    let source_rule_map = standardized
        .pair_metadata
        .iter()
        .filter(|metadata| metadata.group_label == "rules")
        .map(|metadata| (metadata.original_pair_index, metadata.canonical_pair_index))
        .collect::<BTreeMap<_, _>>();
    let pair_source_map = standardized
        .pair_metadata
        .iter()
        .filter(|metadata| metadata.group_label == "dps")
        .map(|metadata| (metadata.canonical_pair_index, metadata.original_pair_index))
        .collect::<BTreeMap<_, _>>();
    let weak_pair_source_map = standardized
        .pair_metadata
        .iter()
        .filter(|metadata| metadata.group_label == "weak-dps")
        .map(|metadata| (metadata.canonical_pair_index, metadata.original_pair_index))
        .collect::<BTreeMap<_, _>>();
    let mut canonical_groups = standardized
        .problem
        .groups
        .into_iter()
        .map(|group| (group.label, group.pairs))
        .collect::<BTreeMap<_, _>>();
    // A marked dependency-pair symbol is not an independent signature symbol:
    // its identity is tied to the corresponding unmarked TRS symbol.  Pin that
    // relationship after structural standardization for ordinary as well as
    // context-sensitive DP states.  Otherwise an automorphism of the TRS can
    // rename the marked SCC independently, collapsing distinct live residuals
    // onto one oracle key and pooling mutually inapplicable exact witnesses.
    let mut pinned_bijection = BTreeMap::new();
    if pin_ordinary_marked_base || csr_context.is_some() {
        for pair in state.pairs.iter().chain(&state.stats.weak_pairs) {
            for root in [pair.lhs().root_symbol(), pair.rhs().root_symbol()]
                .into_iter()
                .flatten()
            {
                let Some(base) = (if csr_context.is_some() {
                    semantic_label_unmarked_companion(root)
                } else {
                    root.as_str().strip_suffix('#').map(Symbol::new)
                }) else {
                    continue;
                };
                let Some(canonical_marked) = standardized.function_bijection.get(root) else {
                    continue;
                };
                let canonical_base = match standardized.function_bijection.get(&base) {
                    Some(base) => base,
                    // Rule deletion may remove the unmarked companion from
                    // the entire residual signature. Preserve the sharp role
                    // nonetheless: otherwise CSR import mistakes this symbol
                    // for a legacy alias and consults obsolete rule indices.
                    // Canonical symbol identities are injective, so this fresh
                    // sharp name cannot collide with another pinned companion.
                    None if csr_context.is_some() => canonical_marked,
                    None => continue,
                };
                pinned_bijection.insert(
                    canonical_marked.clone(),
                    Symbol::new(format!("{canonical_base}#")),
                );
            }
        }
    }
    if let Some(context) = csr_context {
        let unhiding = fresh_unhiding_symbol(context.csr.trs());
        let has_improved_unhiding = context.construction == CsrDpConstruction::Improved
            && state
                .pairs
                .iter()
                .chain(&state.stats.weak_pairs)
                .any(|pair| {
                    pair.lhs().root_symbol() == Some(&unhiding)
                        || pair.rhs().root_symbol() == Some(&unhiding)
                });
        if has_improved_unhiding {
            if let Some(canonical_unhiding) = standardized.function_bijection.get(&unhiding) {
                // The fresh improved-CS-DP wrapper is part of the processor
                // context, not an interchangeable source-signature symbol.
                // Pin it after structural standardization so a CPF round trip
                // can still recognize the exact improved processor state.
                let pinned = Symbol::new("__CSR_U0");
                if canonical_unhiding != &pinned {
                    pinned_bijection.insert(canonical_unhiding.clone(), pinned);
                }
            }
        }
    }
    if !pinned_bijection.is_empty() {
        for pairs in canonical_groups.values_mut() {
            *pairs = pairs
                .iter()
                .map(|pair| crate::standardize::translate_pair_symbols(pair, &pinned_bijection))
                .collect();
        }
    }
    let take_rules = |groups: &mut BTreeMap<String, Vec<TermPair>>, label: &str| {
        groups
            .remove(label)
            .unwrap_or_default()
            .into_iter()
            .map(TermPair::into_rule)
            .collect::<Vec<_>>()
    };
    let rules = take_rules(&mut canonical_groups, "rules");
    let canonical_pair_rules = take_rules(&mut canonical_groups, "dps");
    let canonical_weak_pair_rules = take_rules(&mut canonical_groups, "weak-dps");
    let mut canonical_pair_entries = canonical_pair_rules
        .into_iter()
        .enumerate()
        .map(|(canonical_index, rule)| {
            let original_index = pair_source_map[&canonical_index];
            let source = state.pairs[original_index].source_rule();
            (
                rule,
                source_rule_map.get(&source).copied().unwrap_or(source),
            )
        })
        .collect::<Vec<_>>();
    canonical_pair_entries.sort_by(|(left, left_source), (right, right_source)| {
        left.lhs()
            .cmp(right.lhs())
            .then_with(|| left.rhs().cmp(right.rhs()))
            .then_with(|| left_source.cmp(right_source))
    });
    let canonical_pairs = canonical_pair_entries
        .into_iter()
        .map(|(rule, source)| DependencyPair::from_rule(rule, source))
        .collect::<Vec<_>>();
    let mut canonical_weak_pair_entries = canonical_weak_pair_rules
        .into_iter()
        .enumerate()
        .map(|(canonical_index, rule)| {
            let original_index = weak_pair_source_map[&canonical_index];
            let source = state.stats.weak_pairs[original_index].source_rule();
            (
                rule,
                source_rule_map.get(&source).copied().unwrap_or(source),
            )
        })
        .collect::<Vec<_>>();
    canonical_weak_pair_entries.sort_by(|(left, left_source), (right, right_source)| {
        left.lhs()
            .cmp(right.lhs())
            .then_with(|| left.rhs().cmp(right.rhs()))
            .then_with(|| left_source.cmp(right_source))
    });
    let canonical_weak_pairs = canonical_weak_pair_entries
        .into_iter()
        .map(|(rule, source)| DependencyPair::from_rule(rule, source))
        .collect::<Vec<_>>();
    let canonical_active_rules =
        active_rules.map(|_| take_rules(&mut canonical_groups, "active-rules"));
    let canonical_graph_rules =
        graph_rules.map(|_| take_rules(&mut canonical_groups, "graph-rules"));
    let canonical_transformation_rules =
        transformation_rules.map(|_| take_rules(&mut canonical_groups, "transformation-rules"));
    let canonical_lhss = context_lhss.map(|_| {
        canonical_groups
            .remove("innermost-lhss")
            .unwrap_or_default()
            .into_iter()
            .map(|pair| pair.lhs)
            .collect::<Vec<_>>()
    });
    let variables = rules
        .iter()
        .flat_map(|rule| {
            rule.lhs()
                .variables()
                .into_iter()
                .chain(rule.rhs().variables())
        })
        .collect();
    let canonical_trs = Trs::new_with_strategy(None, variables, rules, state.trs.strategy());
    let mut xml = match csr_context {
        None => write_relative_dp_state_input_cpf3(
            &canonical_trs,
            &canonical_pairs,
            &canonical_weak_pairs,
            canonical_active_rules
                .as_deref()
                .filter(|rules| *rules != canonical_trs.rules()),
            state.stats.minimal,
            state.stats.normal_form_substitutions,
        ),
        Some(context) => {
            let source_unhiding = fresh_unhiding_symbol(context.csr.trs());
            let frozen_auxiliary = context.csr.replacement_map()
                .allowed_positions(&source_unhiding).is_some_and(BTreeSet::is_empty);
            let replacement_map = ReplacementMap::new(
                replacement_map
                    .expect("CSR state has a replacement map")
                    .entries()
                    .iter()
                    .filter_map(|(symbol, positions)| {
                        if frozen_auxiliary && symbol == &source_unhiding {
                            return None;
                        }
                        standardized
                            .function_bijection
                            .get(symbol)
                            .cloned()
                            .map(|canonical| (canonical, positions.clone()))
                    })
                    .collect(),
            );
            let canonical_csr = match CsrTrs::new(canonical_trs.clone(), replacement_map) {
                Ok(csr) => csr,
                Err(issues) => {
                    return (
                        dp_state_input_cpf(state),
                        Some(
                            issues
                                .into_iter()
                                .map(|issue| issue.to_string())
                                .collect::<Vec<_>>()
                                .join("; "),
                        ),
                    );
                }
            };
            write_csr_dp_state_input_cpf4(
                &canonical_csr,
                &canonical_pairs,
                &canonical_weak_pairs,
                canonical_active_rules
                    .as_deref()
                    .filter(|rules| *rules != canonical_trs.rules()),
                state.stats.minimal,
                context.construction.as_str(),
                context.graph_estimator.as_str(),
                context.use_qcs_usable_rules,
            )
        }
    };
    xml = crate::cert::append_ferrum_dp_state_context(
        xml,
        &canonical_pairs
            .iter()
            .map(DependencyPair::source_rule)
            .collect::<Vec<_>>(),
        &canonical_weak_pairs
            .iter()
            .map(DependencyPair::source_rule)
            .collect::<Vec<_>>(),
        &state
            .stats
            .strict_rules
            .iter()
            .map(|rule| {
                crate::standardize::translate_rule_symbols(rule, &standardized.function_bijection)
            })
            .collect::<Vec<_>>(),
        canonical_lhss.as_deref(),
        clear_innermost_lhss,
        canonical_graph_rules.as_deref(),
        canonical_transformation_rules.as_deref(),
        state.stats.active_rules_are_residual,
        state.stats.ordinary_reduction_started,
        state.stats.ordinary_bridge_loses_minimality,
        canonical_trs.strategy() == crate::core::RewriteStrategy::Innermost,
        state.stats.semantic_csr_context.is_some(),
    );
    (xml, None)
}

/// Compare Q/LHS collections modulo the bound-variable spelling of each
/// pattern.  Variables in distinct innermost-LHS patterns are independent;
/// CPF parsing may therefore rename them without changing Q.  This is used
/// only to recognize the implicit default Q during canonical serialization,
/// so it cannot merge two different executable Q obligations.
fn same_alpha_term_multiset(left: &[Term], right: &[Term]) -> bool {
    if left.len() != right.len() {
        return false;
    }
    let mut used = vec![false; right.len()];
    left.iter().all(|left| {
        right.iter().enumerate().any(|(index, right)| {
            if used[index] {
                return false;
            }
            let left_rule = RewriteRule::new(left.clone(), left.clone());
            let right_rule = RewriteRule::new(right.clone(), right.clone());
            if crate::proving::processors::dp::alpha_equivalent_rules(&left_rule, &right_rule) {
                used[index] = true;
                true
            } else {
                false
            }
        })
    })
}

pub(crate) fn standardized_dp_state_input_cpf3(
    trs: &Trs,
    pairs: &[DependencyPair],
    active_rules: Option<&[RewriteRule]>,
    minimal: bool,
    normal_form_substitutions: bool,
) -> (String, Option<String>) {
    standardized_relative_dp_state_input_cpf3(
        trs,
        pairs,
        &[],
        active_rules,
        minimal,
        normal_form_substitutions,
    )
}

pub(crate) fn standardized_relative_dp_state_input_cpf3(
    trs: &Trs,
    pairs: &[DependencyPair],
    weak_pairs: &[DependencyPair],
    active_rules: Option<&[RewriteRule]>,
    minimal: bool,
    normal_form_substitutions: bool,
) -> (String, Option<String>) {
    // CPF rule variables are local to each rule.  A producer may therefore
    // repeat R as `<usableRules>` with fresh variable spellings without
    // changing the DP problem.  Keeping that redundant copy in the
    // canonical key orphaned recursive oracle guidance after Ferrum restored
    // the literal live spellings for certificate reconstruction.
    let active_rules = active_rules
        .filter(|rules| !crate::proving::processors::dp::same_rule_multiset(rules, trs.rules()));
    let raw_input = || {
        write_relative_dp_state_input_cpf3(
            trs,
            pairs,
            weak_pairs,
            active_rules,
            minimal,
            normal_form_substitutions,
        )
    };
    let mut groups = vec![StandardizationGroup::new(
        "rules",
        trs.rules().iter().map(TermPair::from_rule).collect(),
    )];
    if let Some(active_rules) = active_rules {
        groups.push(StandardizationGroup::new(
            "active-rules",
            active_rules.iter().map(TermPair::from_rule).collect(),
        ));
    }
    groups.push(StandardizationGroup::new(
        "dps",
        pairs
            .iter()
            .map(|pair| TermPair::new(pair.lhs().clone(), pair.rhs().clone()))
            .collect(),
    ));
    groups.push(StandardizationGroup::new(
        "weak-dps",
        weak_pairs
            .iter()
            .map(|pair| TermPair::new(pair.lhs().clone(), pair.rhs().clone()))
            .collect(),
    ));
    let problem = StandardizationProblem::new(groups);
    let standardized = match standardize_problem(&problem) {
        Ok(problem) => problem,
        Err(error) => return (raw_input(), Some(error.to_string())),
    };
    let mut rules = Vec::new();
    let mut standardized_active_rules = active_rules.map(|_| Vec::new());
    let mut standardized_pairs = Vec::new();
    let mut standardized_weak_pairs = Vec::new();
    for group in standardized.groups {
        match group.label.as_str() {
            "rules" => {
                rules = group.pairs.into_iter().map(TermPair::into_rule).collect();
            }
            "active-rules" => {
                standardized_active_rules =
                    Some(group.pairs.into_iter().map(TermPair::into_rule).collect());
            }
            "dps" => {
                standardized_pairs = group
                    .pairs
                    .into_iter()
                    .enumerate()
                    .map(|(index, pair)| DependencyPair::from_rule(pair.into_rule(), index))
                    .collect();
            }
            "weak-dps" => {
                standardized_weak_pairs = group
                    .pairs
                    .into_iter()
                    .enumerate()
                    .map(|(index, pair)| DependencyPair::from_rule(pair.into_rule(), index))
                    .collect();
            }
            _ => {}
        }
    }
    let variables = rules
        .iter()
        .flat_map(|rule| {
            rule.lhs()
                .variables()
                .into_iter()
                .chain(rule.rhs().variables())
        })
        .chain(standardized_pairs.iter().flat_map(|pair| {
            pair.lhs()
                .variables()
                .into_iter()
                .chain(pair.rhs().variables())
        }))
        .chain(standardized_weak_pairs.iter().flat_map(|pair| {
            pair.lhs()
                .variables()
                .into_iter()
                .chain(pair.rhs().variables())
        }))
        .collect();
    // Omitting <usableRules> means that the complete TRS is active.  Keep
    // that semantic default canonical: otherwise the same DP obligation gets
    // two oracle keys depending only on whether a producer serialized the
    // default explicitly.
    if standardized_active_rules.as_deref() == Some(rules.as_slice()) {
        standardized_active_rules = None;
    }
    let standardized_trs = Trs::new_with_strategy(None, variables, rules, trs.strategy());
    (
        write_relative_dp_state_input_cpf3(
            &standardized_trs,
            &standardized_pairs,
            &standardized_weak_pairs,
            standardized_active_rules.as_deref(),
            minimal,
            normal_form_substitutions,
        ),
        None,
    )
}

#[cfg(test)]
pub(crate) fn standardized_csr_dp_state_input_cpf4(
    csr: &CsrTrs,
    pairs: &[DependencyPair],
    active_rules: Option<&[RewriteRule]>,
    minimal: bool,
    construction: &str,
    graph_estimator: &str,
    use_qcs_usable_rules: bool,
) -> (String, Option<String>) {
    standardized_relative_csr_dp_state_input_cpf4(
        csr,
        pairs,
        &[],
        active_rules,
        minimal,
        construction,
        graph_estimator,
        use_qcs_usable_rules,
    )
}

#[cfg(test)]
pub(crate) fn standardized_relative_csr_dp_state_input_cpf4(
    csr: &CsrTrs,
    pairs: &[DependencyPair],
    weak_pairs: &[DependencyPair],
    active_rules: Option<&[RewriteRule]>,
    minimal: bool,
    construction: &str,
    graph_estimator: &str,
    use_qcs_usable_rules: bool,
) -> (String, Option<String>) {
    let active_rules = active_rules.filter(|rules| *rules != csr.rules());
    let raw_input = || {
        write_csr_dp_state_input_cpf4(
            csr,
            pairs,
            weak_pairs,
            active_rules,
            minimal,
            construction,
            graph_estimator,
            use_qcs_usable_rules,
        )
    };
    let mut groups = vec![StandardizationGroup::new(
        "rules",
        csr.rules().iter().map(TermPair::from_rule).collect(),
    )];
    if let Some(active_rules) = active_rules {
        groups.push(StandardizationGroup::new(
            "active-rules",
            active_rules.iter().map(TermPair::from_rule).collect(),
        ));
    }
    groups.push(StandardizationGroup::new(
        "dps",
        pairs
            .iter()
            .map(|pair| TermPair::new(pair.lhs().clone(), pair.rhs().clone()))
            .collect(),
    ));
    groups.push(StandardizationGroup::new(
        "weak-dps",
        weak_pairs
            .iter()
            .map(|pair| TermPair::new(pair.lhs().clone(), pair.rhs().clone()))
            .collect(),
    ));
    let standardized =
        match standardize_problem_with_bijection(&StandardizationProblem::new(groups)) {
            Ok(standardized) => standardized,
            Err(error) => return (raw_input(), Some(error.to_string())),
        };
    let mut rules = Vec::new();
    let mut standardized_active_rules = active_rules.map(|_| Vec::new());
    let mut standardized_pairs = Vec::new();
    let mut standardized_weak_pairs = Vec::new();
    for group in standardized.problem.groups {
        match group.label.as_str() {
            "rules" => {
                rules = group.pairs.into_iter().map(TermPair::into_rule).collect();
            }
            "active-rules" => {
                standardized_active_rules =
                    Some(group.pairs.into_iter().map(TermPair::into_rule).collect());
            }
            "dps" => {
                standardized_pairs = group
                    .pairs
                    .into_iter()
                    .enumerate()
                    .map(|(index, pair)| DependencyPair::from_rule(pair.into_rule(), index))
                    .collect();
            }
            "weak-dps" => {
                standardized_weak_pairs = group
                    .pairs
                    .into_iter()
                    .enumerate()
                    .map(|(index, pair)| DependencyPair::from_rule(pair.into_rule(), index))
                    .collect();
            }
            _ => {}
        }
    }
    let variables = rules
        .iter()
        .flat_map(|rule| {
            rule.lhs()
                .variables()
                .into_iter()
                .chain(rule.rhs().variables())
        })
        .chain(standardized_pairs.iter().flat_map(|pair| {
            pair.lhs()
                .variables()
                .into_iter()
                .chain(pair.rhs().variables())
        }))
        .chain(standardized_weak_pairs.iter().flat_map(|pair| {
            pair.lhs()
                .variables()
                .into_iter()
                .chain(pair.rhs().variables())
        }))
        .collect();
    if standardized_active_rules.as_deref() == Some(rules.as_slice()) {
        standardized_active_rules = None;
    }
    let standardized_trs = Trs::new_with_strategy(None, variables, rules, csr.trs().strategy());
    let replacement_map = ReplacementMap::new(
        csr.replacement_map()
            .entries()
            .iter()
            .filter_map(|(symbol, positions)| {
                standardized
                    .function_bijection
                    .get(symbol)
                    .cloned()
                    .map(|canonical| (canonical, positions.clone()))
            })
            .collect(),
    );
    let standardized_csr = match CsrTrs::new(standardized_trs, replacement_map) {
        Ok(csr) => csr,
        Err(issues) => {
            return (
                raw_input(),
                Some(
                    issues
                        .into_iter()
                        .map(|issue| issue.to_string())
                        .collect::<Vec<_>>()
                        .join("; "),
                ),
            );
        }
    };
    (
        write_csr_dp_state_input_cpf4(
            &standardized_csr,
            &standardized_pairs,
            &standardized_weak_pairs,
            standardized_active_rules.as_deref(),
            minimal,
            construction,
            graph_estimator,
            use_qcs_usable_rules,
        ),
        None,
    )
}

pub(crate) fn reduction_pair_residual_base_rules(
    parent_rules: &[RewriteRule],
    active_rules: &[RewriteRule],
    deletes_rules_from_base: bool,
) -> Vec<RewriteRule> {
    if deletes_rules_from_base {
        active_rules.to_vec()
    } else {
        parent_rules.to_vec()
    }
}

#[cfg(test)]
fn csr_pairs_have_marked_roots(pairs: &[DependencyPair]) -> bool {
    pairs.iter().all(|pair| {
        pair.lhs()
            .root_symbol()
            .is_some_and(|symbol| symbol.as_str().ends_with('#'))
            && pair
                .rhs()
                .root_symbol()
                .is_some_and(|symbol| symbol.as_str().ends_with('#'))
    })
}

pub(crate) fn csr_construction_uses_u3(construction: CsrDpConstruction) -> bool {
    matches!(
        construction,
        CsrDpConstruction::Native | CsrDpConstruction::Improved
    )
}

pub(crate) fn csr_pairs_have_marked_or_fresh_unhiding_roots(
    csr: &CsrTrs,
    pairs: &[DependencyPair],
) -> bool {
    let unhiding = fresh_unhiding_symbol(csr.trs());
    pairs.iter().all(|pair| {
        [pair.lhs(), pair.rhs()].into_iter().all(|term| {
            term.root_symbol()
                .is_some_and(|symbol| symbol.as_str().ends_with('#') || symbol == &unhiding)
        })
    })
}

#[cfg(test)]
pub(crate) fn csr_pairs_have_mixed_marked_fresh_unhiding_roots(
    csr: &CsrTrs,
    pairs: &[DependencyPair],
) -> bool {
    let unhiding = fresh_unhiding_symbol(csr.trs());
    csr_pairs_have_marked_or_fresh_unhiding_roots(csr, pairs)
        && pairs.iter().any(|pair| {
            pair.lhs().root_symbol() == Some(&unhiding)
                || pair.rhs().root_symbol() == Some(&unhiding)
        })
}

pub(crate) fn usable_rule_reduction_pair_is_certifiable(
    minimal: bool,
    uses_usable_rules: bool,
) -> bool {
    minimal || !uses_usable_rules
}

pub(crate) fn same_rule_set(left: &[RewriteRule], right: &[RewriteRule]) -> bool {
    left.len() == right.len() && left.iter().all(|rule| right.contains(rule))
}

pub(crate) fn reduction_pair_is_mono_for_residual(reduction_pair: &DpReductionPairProof) -> bool {
    match reduction_pair {
        DpReductionPairProof::Polynomial { interpretation, .. } => {
            interpretation.iter().all(|(_, constant, coefficients)| {
                *constant >= 0 && coefficients.iter().all(|coefficient| *coefficient >= 1)
            })
        }
        DpReductionPairProof::NaturalPolynomial { interpretation, .. } => {
            interpretation.iter().all(|(_, polynomial)| {
                polynomial.constant >= 0
                    && polynomial
                        .linear
                        .iter()
                        .all(|coefficient| *coefficient >= 1)
                    && polynomial
                        .quadratic
                        .iter()
                        .enumerate()
                        .all(|(row, coefficients)| {
                            coefficients
                                .iter()
                                .enumerate()
                                .all(|(column, coefficient)| column < row || *coefficient >= 0)
                        })
            })
        }
        DpReductionPairProof::MaxPolynomial { .. }
        | DpReductionPairProof::WeightedPathOrderMax { .. }
        | DpReductionPairProof::Matrix { .. }
        | DpReductionPairProof::IntegerMatrix { .. }
        | DpReductionPairProof::ArcticMatrix { .. }
        | DpReductionPairProof::RationalPolynomial { .. }
        | DpReductionPairProof::RationalNaturalPolynomial { .. }
        | DpReductionPairProof::PathOrder { .. }
        | DpReductionPairProof::Kbo { .. } => false,
    }
}

pub(crate) struct ReductionPairContext<'a> {
    pub(crate) pairs: &'a [DependencyPair],
    pub(crate) strict_pairs: Option<&'a [DependencyPair]>,
    pub(crate) input_rules: Vec<RewriteRule>,
    pub(crate) usable_rules: Vec<RewriteRule>,
    pub(crate) fixed_usable_rules: bool,
    pub(crate) required_strict_rule_indices: Vec<usize>,
    pub(crate) required_strict_pair_index: Option<usize>,
    pub(crate) q_monotonic_rule_index: Option<usize>,
    pub(crate) options: &'a DpOptions,
    pub(crate) innermost_lhss: Option<&'a [Term]>,
    pub(crate) deadline: Option<Instant>,
    pub(crate) cancellation: &'a DpStrategyCancellation,
}

impl<'a> ReductionPairContext<'a> {
    pub(crate) fn new(
        trs: &'a Trs,
        pairs: &'a [DependencyPair],
        active_rules: Option<&[RewriteRule]>,
        active_rules_are_residual: bool,
        minimal: bool,
        options: &'a DpOptions,
        innermost_lhss: Option<&'a [Term]>,
        deadline: Option<Instant>,
        cancellation: &'a DpStrategyCancellation,
    ) -> Self {
        // For ordinary minimal innermost DP problems `active_rules` is a
        // search hint recording the last computed usable-rule set.  It is
        // not the residual TRS: monotonic processors materialize a genuine
        // rule deletion in `trs` itself.  Treating that hint as the complete
        // rule universe is unsound once a later argument filter exposes a
        // different defined symbol (Ex14_Luc06_iGM).  CeTA recomputes usable
        // rules from the DP problem's R, so mirror that boundary here.
        let input_rules = if active_rules_are_residual {
            active_rules.unwrap_or(trs.rules()).to_vec()
        } else if minimal && trs.strategy() == RewriteStrategy::Innermost {
            trs.rules().to_vec()
        } else {
            active_rules.unwrap_or(trs.rules()).to_vec()
        };
        let active_trs = Trs::new_with_strategy(
            trs.name().map(str::to_string),
            trs.variables().clone(),
            input_rules.clone(),
            trs.strategy(),
        );
        Self {
            pairs,
            strict_pairs: None,
            usable_rules: if minimal && active_trs.strategy() == RewriteStrategy::Innermost {
                // The usable-rule obligation of an innermost reduction pair
                // depends on the interpretation-induced argument filter.
                // A filter can expose a root that the unfiltered Q-local
                // approximation omitted (Ex14_Luc06 reaches b below the kept
                // argument of f).  Keep the complete active R as the search
                // universe; every AF-aware processor computes and validates
                // its exact closure from this set before emitting redPairUr.
                // Using the smaller pre-filter approximation here let an
                // empty U pass internally although CeTA required b/f rules.
                input_rules.clone()
            } else if minimal {
                reduction_pair_context_rules(&active_trs, pairs, innermost_lhss)
            } else {
                input_rules.clone()
            },
            fixed_usable_rules: false,
            required_strict_rule_indices: Vec::new(),
            required_strict_pair_index: None,
            q_monotonic_rule_index: None,
            input_rules,
            options,
            innermost_lhss,
            deadline,
            cancellation,
        }
    }

    pub(crate) fn is_cancelled_or_timed_out(&self) -> bool {
        strategy_timed_out(self.deadline) || self.cancellation.is_cancelled()
    }

    pub(crate) fn scoped_options(&self) -> DpOptions {
        let mut options = self.options.clone();
        options.max_symbols = options.max_symbols.max(REDUCTION_PAIR_SMT_SYMBOL_LIMIT);
        options.max_polynomial_symbols = options
            .max_polynomial_symbols
            .max(REDUCTION_PAIR_SMT_SYMBOL_LIMIT);
        options
    }
}

fn reduction_pair_context_rules(
    trs: &Trs,
    pairs: &[DependencyPair],
    innermost_lhss: Option<&[Term]>,
) -> Vec<RewriteRule> {
    if trs.strategy() == RewriteStrategy::Innermost {
        usable_rules_in_innermost_context(trs, pairs, innermost_lhss)
    } else {
        usable_rules(trs, pairs)
    }
}

/// Recognize the common guarded-tail DP kernel
///
///   U(c, L)        -> F(W(L))
///   F(C(N, L))     -> U(g, L)
///
/// and try the structural measure in which `W` is transparent and `C`
/// contributes one above its tail.  This is only candidate construction; the
/// ordinary usable-rule reduction-pair checker below validates every rule and
/// pair before the witness can enter a proof.
fn guarded_tail_polynomial_removal(context: &ReductionPairContext<'_>) -> Option<ComponentRemoval> {
    if context.fixed_usable_rules || context.pairs.len() != 2 {
        return None;
    }
    for (first, second) in [(0usize, 1usize), (1, 0)] {
        let (
            Term::App {
                symbol: u,
                args: u_lhs,
            },
            Term::App {
                symbol: f,
                args: f_rhs,
            },
        ) = (context.pairs[first].lhs(), context.pairs[first].rhs())
        else {
            continue;
        };
        if u_lhs.len() != 2 || f_rhs.len() != 1 {
            continue;
        }
        let Term::Var(tail) = &u_lhs[1] else {
            continue;
        };
        let Term::App {
            symbol: wrapper,
            args: wrapped,
        } = &f_rhs[0]
        else {
            continue;
        };
        if wrapped.as_slice() != [Term::Var(tail.clone())] {
            continue;
        }
        let (
            Term::App {
                symbol: f2,
                args: f_lhs,
            },
            Term::App {
                symbol: u2,
                args: u_rhs,
            },
        ) = (context.pairs[second].lhs(), context.pairs[second].rhs())
        else {
            continue;
        };
        if f2 != f || u2 != u || f_lhs.len() != 1 || u_rhs.len() != 2 {
            continue;
        }
        let Term::App {
            symbol: constructor,
            args: constructor_args,
        } = &f_lhs[0]
        else {
            continue;
        };
        if constructor_args.len() != 2
            || constructor_args[1] != Term::Var(tail.clone())
            || u_rhs[1] != Term::Var(tail.clone())
        {
            continue;
        }

        let mut interpretations = arities_for_constraints(context.pairs, &context.usable_rules)
            .into_iter()
            .map(|(symbol, arity)| {
                (
                    symbol,
                    LinearPolynomial {
                        constant: 0,
                        coefficients: vec![0; arity],
                    },
                )
            })
            .collect::<LinearPolynomialInterpretations>();
        interpretations.get_mut(u.as_str())?.coefficients[1] = 1;
        interpretations.get_mut(f.as_str())?.coefficients[0] = 1;
        interpretations.get_mut(wrapper.as_str())?.coefficients[0] = 1;
        let constructor_interpretation = interpretations.get_mut(constructor.as_str())?;
        constructor_interpretation.constant = 1;
        constructor_interpretation.coefficients[1] = 1;

        for rule in &context.usable_rules {
            let (
                Term::App {
                    symbol: lhs_symbol,
                    args: lhs_args,
                },
                Term::App {
                    symbol: rhs_symbol,
                    args: rhs_args,
                },
            ) = (rule.lhs(), rule.rhs())
            else {
                continue;
            };
            if rhs_args.len() != 1 {
                continue;
            }
            let Term::Var(variable) = &rhs_args[0] else {
                continue;
            };
            let Some(position) = lhs_args
                .iter()
                .position(|argument| argument == &Term::Var(variable.clone()))
            else {
                continue;
            };
            if let Some(lhs_interpretation) = interpretations.get_mut(lhs_symbol.as_str()) {
                lhs_interpretation.coefficients[position] = 1;
            }
            if let Some(rhs_interpretation) = interpretations.get_mut(rhs_symbol.as_str())
                && !rhs_interpretation.coefficients.is_empty()
            {
                rhs_interpretation.coefficients[0] = 1;
            }
            if let Some(base) = lhs_symbol.as_str().strip_suffix("Active")
                && let Some(base_interpretation) = interpretations.get_mut(base)
                && position < base_interpretation.coefficients.len()
            {
                base_interpretation.coefficients[position] = 1;
            }
        }

        // Generator and dispatcher rules can often be made weak by raising
        // only their defined root constant; their unmarked roots are
        // independent of the marked DP roots carrying the tail descent.
        for _ in 0..16 {
            let roots = context
                .usable_rules
                .iter()
                .filter(|rule| {
                    !weakly_decreases_by_polynomial(rule.lhs(), rule.rhs(), &interpretations)
                })
                .filter_map(|rule| rule.lhs().root_symbol().cloned())
                .filter(|root| root != u && root != f && root != wrapper && root != constructor)
                .collect::<BTreeSet<_>>();
            if roots.is_empty() {
                break;
            }
            for root in roots {
                if let Some(root_interpretation) = interpretations.get_mut(root.as_str()) {
                    root_interpretation.constant += 1;
                }
            }
        }
        let active_interpretations = interpretations
            .iter()
            .filter_map(|(symbol, interpretation)| {
                symbol
                    .strip_suffix("Active")
                    .map(|base| (base.to_string(), interpretation.clone()))
            })
            .collect::<Vec<_>>();
        for (base, active_interpretation) in active_interpretations {
            if let Some(base_interpretation) = interpretations.get_mut(&base) {
                *base_interpretation = active_interpretation;
            }
        }
        let activation_equalities = context
            .usable_rules
            .iter()
            .filter_map(|rule| {
                let (
                    Term::App {
                        symbol: lhs_wrapper,
                        args: lhs_wrapper_args,
                    },
                    Term::App {
                        symbol: active,
                        args: active_args,
                    },
                ) = (rule.lhs(), rule.rhs())
                else {
                    return None;
                };
                if lhs_wrapper_args.len() != 1 {
                    return None;
                }
                let Term::App {
                    symbol: base,
                    args: base_args,
                } = &lhs_wrapper_args[0]
                else {
                    return None;
                };
                if base_args.len() != active_args.len() || base_args.is_empty() {
                    return None;
                }
                let Term::App {
                    symbol: rhs_wrapper,
                    args: rhs_wrapper_args,
                } = &active_args[0]
                else {
                    return None;
                };
                if rhs_wrapper_args.len() != 1
                    || rhs_wrapper_args[0] != base_args[0]
                    || active_args[1..] != base_args[1..]
                {
                    return None;
                }
                Some((
                    base.as_str().to_string(),
                    active.as_str().to_string(),
                    lhs_wrapper.as_str().to_string(),
                    rhs_wrapper.as_str().to_string(),
                ))
            })
            .collect::<Vec<_>>();
        for (base, active, lhs_wrapper, rhs_wrapper) in activation_equalities {
            if let Some(active_interpretation) = interpretations.get(&active).cloned()
                && let Some(base_interpretation) = interpretations.get_mut(&base)
            {
                *base_interpretation = active_interpretation;
            }
            for wrapper in [lhs_wrapper, rhs_wrapper] {
                if let Some(wrapper_interpretation) = interpretations.get_mut(&wrapper)
                    && !wrapper_interpretation.coefficients.is_empty()
                {
                    wrapper_interpretation.coefficients[0] = 1;
                }
            }
        }

        if let Some(removal) = checked_component_removal_by_polynomial_with_usable_rules(
            context.pairs,
            &context.usable_rules,
            &interpretations,
            DpSearchBackend::Sat,
            context.innermost_lhss,
        ) {
            return Some(removal);
        }
    }
    None
}

pub(crate) fn synthesize_component_removal_by_processor(
    processor: &DpStrategyProcessor,
    context: &ReductionPairContext<'_>,
) -> Option<ComponentRemoval> {
    match processor {
        DpStrategyProcessor::Llm => orient_component_with_llm(
            context.pairs,
            &context.usable_rules,
            context.options,
            true,
            context.innermost_lhss,
        ),
        DpStrategyProcessor::SymbolWeights { max_weight } => {
            let mut scoped_options = context.scoped_options();
            scoped_options.max_symbol_weight = *max_weight;
            synthesize_symbol_weights_for_component(
                context.pairs,
                &context.usable_rules,
                &scoped_options,
                context.deadline,
            )
            .and_then(|weights| {
                checked_component_removal_by_weights(
                    context.pairs,
                    &context.usable_rules,
                    &weights,
                    DpSearchBackend::Sat,
                    context.innermost_lhss,
                )
            })
        }
        DpStrategyProcessor::LinearPolynomial {
            max_constant,
            max_coefficient,
            max_symbols,
            max_arity,
        } => {
            let mut scoped_options = context.scoped_options();
            scoped_options.max_polynomial_constant = *max_constant;
            scoped_options.max_polynomial_coefficient = *max_coefficient;
            if let Some(max_symbols) = max_symbols {
                scoped_options.max_polynomial_symbols = *max_symbols;
            }
            if let Some(max_arity) = max_arity {
                scoped_options.max_polynomial_arity = *max_arity;
            }
            if !context.fixed_usable_rules
                && *max_constant >= 1
                && *max_coefficient >= 1
                && let Some(removal) = guarded_tail_polynomial_removal(context)
            {
                Some(removal)
            } else if context.fixed_usable_rules {
                synthesize_linear_polynomial_with_sat_requiring_strict_rules(
                    context.pairs,
                    &context.usable_rules,
                    &context.required_strict_rule_indices,
                    &scoped_options,
                    context.deadline,
                )
                .and_then(|interpretations| {
                    checked_component_removal_by_polynomial_with_required_strict_rules(
                        context.pairs,
                        &context.usable_rules,
                        &interpretations,
                        DpSearchBackend::Sat,
                        false,
                        context.innermost_lhss,
                        &context.required_strict_rule_indices,
                    )
                })
            } else {
                synthesize_polynomial_with_usable_rules_requiring_strict(
                    context.pairs,
                    context.strict_pairs.unwrap_or(context.pairs),
                    None,
                    &context.usable_rules,
                    &scoped_options,
                    context.deadline,
                )
                .and_then(|interpretations| {
                    checked_component_removal_by_polynomial_with_usable_rules(
                        context.pairs,
                        &context.usable_rules,
                        &interpretations,
                        DpSearchBackend::Sat,
                        context.innermost_lhss,
                    )
                })
            }
        }
        DpStrategyProcessor::SelectedLinearPolynomial {
            max_constant,
            max_coefficient,
            max_symbols,
            max_arity,
            candidate_index,
        } => {
            let mut scoped_options = context.scoped_options();
            scoped_options.max_polynomial_constant = *max_constant;
            scoped_options.max_polynomial_coefficient = *max_coefficient;
            if let Some(max_symbols) = max_symbols {
                scoped_options.max_polynomial_symbols = *max_symbols;
            }
            if let Some(max_arity) = max_arity {
                scoped_options.max_polynomial_arity = *max_arity;
            }
            if context.fixed_usable_rules {
                // Candidate zero denotes the unselected base search. Its
                // event atom must retain the same fixed-rule obligations
                // as the successful native processor (not ordinary U(R)).
                if *candidate_index == 0 {
                    synthesize_component_removal_by_processor(
                        &DpStrategyProcessor::LinearPolynomial {
                            max_constant: *max_constant,
                            max_coefficient: *max_coefficient,
                            max_symbols: *max_symbols,
                            max_arity: *max_arity,
                        }, context)
                } else {
                    None
                }
            } else {
                synthesize_polynomial_with_usable_rules_requiring_strict(
                    context.pairs,
                    context.strict_pairs.unwrap_or(context.pairs),
                    None,
                    &context.usable_rules,
                    &scoped_options,
                    context.deadline,
                )
                .and_then(|interpretations| {
                    checked_component_removal_by_polynomial_with_usable_rules(
                        context.pairs,
                        &context.usable_rules,
                        &interpretations,
                        DpSearchBackend::Sat,
                        context.innermost_lhss,
                    )
                })
            }
        }
        DpStrategyProcessor::TargetLinearPolynomial {
            max_constant,
            max_coefficient,
            max_symbols,
            max_arity,
            strict_pair_indices,
        } => {
            let mut scoped_options = context.scoped_options();
            scoped_options.max_polynomial_constant = *max_constant;
            scoped_options.max_polynomial_coefficient = *max_coefficient;
            if let Some(max_symbols) = max_symbols {
                scoped_options.max_polynomial_symbols = *max_symbols;
            }
            if let Some(max_arity) = max_arity {
                scoped_options.max_polynomial_arity = *max_arity;
            }
            let interpretations = if context.fixed_usable_rules {
                synthesize_linear_polynomial_for_target_residual(
                    context.pairs,
                    &context.usable_rules,
                    &context.required_strict_rule_indices,
                    strict_pair_indices,
                    &scoped_options,
                    context.deadline,
                )
            } else {
                synthesize_polynomial_with_usable_rules_requiring_strict(
                    context.pairs,
                    context.pairs,
                    Some(strict_pair_indices),
                    &context.usable_rules,
                    &scoped_options,
                    context.deadline,
                )
            }?;
            if context.fixed_usable_rules {
                checked_component_removal_by_polynomial_with_required_strict_rules(
                    context.pairs,
                    &context.usable_rules,
                    &interpretations,
                    DpSearchBackend::Sat,
                    false,
                    context.innermost_lhss,
                    &context.required_strict_rule_indices,
                )
            } else {
                checked_component_removal_by_polynomial_with_usable_rules(
                    context.pairs,
                    &context.usable_rules,
                    &interpretations,
                    DpSearchBackend::Sat,
                    context.innermost_lhss,
                )
            }
        }
        DpStrategyProcessor::ExactLinearPolynomial { interpretation }
        | DpStrategyProcessor::ExactMonotonicPolynomial { interpretation } => {
            let exact_started = Instant::now();
            if std::env::var_os("FERRUM_TIMING_TRACE").is_some() {
                eprintln!(
                    "exact polynomial validation start pairs={} rules={} symbols={}",
                    context.pairs.len(),
                    context.usable_rules.len(),
                    interpretation.len(),
                );
                if context.pairs.len() <= 4 {
                    for pair in context.pairs {
                        eprintln!(
                            "exact polynomial residual pair: {} -> {}",
                            pair.lhs(),
                            pair.rhs(),
                        );
                    }
                }
            }
            let delete_strict_rules = matches!(
                processor,
                DpStrategyProcessor::ExactMonotonicPolynomial { .. }
            );
            let interpretations = interpretation
                .iter()
                .map(|(name, constant, coefficients)| {
                    (
                        name.clone(),
                        LinearPolynomial {
                            constant: *constant,
                            coefficients: coefficients.clone(),
                        },
                    )
                })
                .collect::<LinearPolynomialInterpretations>();
            if interpretations.len() != interpretation.len() {
                return None;
            }
            let usable_strict_rule_removal = (!context.fixed_usable_rules
                && delete_strict_rules
                && !context.required_strict_rule_indices.is_empty())
            .then(|| {
                let argument_filter = polynomial_argument_filter(
                    context.pairs,
                    &context.input_rules,
                    &interpretations,
                );
                let seed_usable = argument_filtered_usable_rules(
                    &context.input_rules,
                    context.pairs,
                    &argument_filter,
                );
                let filtered_usable = complete_argument_filtered_usable_rules(
                    &context.input_rules,
                    context.pairs,
                    &seed_usable,
                    Some(&argument_filter),
                );
                let required_strict_rules = context
                    .required_strict_rule_indices
                    .iter()
                    .filter_map(|index| context.usable_rules.get(*index))
                    .collect::<Vec<_>>();
                // This is CeTA's `us` set in `mono_ur_redpair_proc`:
                // function/arity symbols occurring in the right-hand
                // sides of P and the certified usable-rule set.  A
                // selected rule whose left-hand side mentions a symbol
                // outside this set may be put into Rremove after only a
                // weak orientation check (`urnwf` in the checker).
                let usable_rhs_symbols = context
                    .pairs
                    .iter()
                    .flat_map(|pair| term_funas(pair.rhs()))
                    .chain(
                        filtered_usable
                            .iter()
                            .flat_map(|rule| term_funas(rule.rhs())),
                    )
                    .collect::<BTreeSet<_>>();
                let strict_rule_indices = filtered_usable
                    .iter()
                    .enumerate()
                    .filter_map(|(index, rule)| {
                        required_strict_rules
                            .iter()
                            .any(|required| {
                                crate::proving::processors::dp::alpha_equivalent_rules(
                                    required, rule,
                                )
                            })
                            .then(|| {
                                (strictly_decreases_by_polynomial(
                                    rule.lhs(),
                                    rule.rhs(),
                                    &interpretations,
                                ) || !term_funas(rule.lhs()).is_subset(&usable_rhs_symbols))
                                .then_some(index)
                            })
                            .flatten()
                    })
                    .collect::<Vec<_>>();
                (polynomial_q_minimality_holds(context.innermost_lhss)
                    && polynomial_coefficients_are_weakly_monotone(
                        context.pairs,
                        &filtered_usable,
                        &interpretations,
                    )
                    && interpretations
                        .values()
                        .all(|interpretation| interpretation.constant >= 0)
                    && context.pairs.iter().all(|pair| {
                        weakly_decreases_by_polynomial(pair.lhs(), pair.rhs(), &interpretations)
                    })
                    && filtered_usable.iter().all(|rule| {
                        weakly_decreases_by_polynomial(rule.lhs(), rule.rhs(), &interpretations)
                    })
                    && (!same_rule_set(&filtered_usable, &context.input_rules)
                        || !strict_rule_indices.is_empty()))
                .then_some(ComponentRemoval {
                    strict_pair_indices: Vec::new(),
                    strict_rule_indices,
                    reduction_pair: DpReductionPairProof::Polynomial {
                        interpretation: interpretation.clone(),
                        backend: DpSearchBackend::Sat,
                    },
                    smt_attempted: false,
                    usable_rules: Some(filtered_usable),
                })
            })
            .flatten();
            let mut removal = usable_strict_rule_removal.or_else(|| {
                if context.fixed_usable_rules {
                    checked_component_removal_by_polynomial_with_required_strict_rules(
                        context.pairs,
                        &context.usable_rules,
                        &interpretations,
                        DpSearchBackend::Sat,
                        false,
                        context.innermost_lhss,
                        &context.required_strict_rule_indices,
                    )
                } else {
                    checked_component_removal_by_polynomial_with_usable_rules(
                        context.pairs,
                        &context.usable_rules,
                        &interpretations,
                        DpSearchBackend::Sat,
                        context.innermost_lhss,
                    )
                }
            });
            if removal.is_none() && delete_strict_rules && context.innermost_lhss.is_some() {
                removal = checked_q_monotonic_polynomial_rule_removal(
                    context.pairs,
                    &context.usable_rules,
                    &interpretations,
                );
            }
            if removal.is_none()
                && delete_strict_rules
                && !same_rule_set(&context.usable_rules, &context.input_rules)
                && polynomial_q_minimality_holds(context.innermost_lhss)
                && polynomial_coefficients_are_weakly_monotone(
                    context.pairs,
                    &context.usable_rules,
                    &interpretations,
                )
                && interpretations
                    .values()
                    .all(|interpretation| interpretation.constant >= 0)
                && context.pairs.iter().all(|pair| {
                    weakly_decreases_by_polynomial(pair.lhs(), pair.rhs(), &interpretations)
                })
                && context.usable_rules.iter().all(|rule| {
                    weakly_decreases_by_polynomial(rule.lhs(), rule.rhs(), &interpretations)
                })
            {
                // Exact oracle replay must be able to reconstruct the same
                // pure usable-rule restriction as the live mono-poly search.
                // At this point ReductionPairContext has already computed
                // the strict usable subset, so no strict DP is required.
                removal = Some(ComponentRemoval {
                    strict_pair_indices: Vec::new(),
                    strict_rule_indices: Vec::new(),
                    reduction_pair: DpReductionPairProof::Polynomial {
                        interpretation: interpretation.clone(),
                        backend: DpSearchBackend::Sat,
                    },
                    smt_attempted: false,
                    usable_rules: Some(context.usable_rules.clone()),
                });
            }
            if removal.is_none()
                && delete_strict_rules
                && polynomial_q_minimality_holds(context.innermost_lhss)
                && polynomial_coefficients_are_weakly_monotone(
                    context.pairs,
                    &context.input_rules,
                    &interpretations,
                )
                && interpretations
                    .values()
                    .all(|interpretation| interpretation.constant >= 0)
                && context.pairs.iter().all(|pair| {
                    weakly_decreases_by_polynomial(pair.lhs(), pair.rhs(), &interpretations)
                })
                && context.input_rules.iter().all(|rule| {
                    weakly_decreases_by_polynomial(rule.lhs(), rule.rhs(), &interpretations)
                })
                && context.input_rules.iter().any(|rule| {
                    strictly_decreases_by_polynomial(rule.lhs(), rule.rhs(), &interpretations)
                })
            {
                // `monoRedPairProc` is recursive in both components: it may
                // leave every dependency pair weak while deleting strictly
                // oriented ordinary rules.  Requiring strict DP progress
                // here made a sound nested rule-removal step impossible on
                // full-rewriting residuals such as Secret_07_TRS/4.
                removal = Some(ComponentRemoval {
                    strict_pair_indices: Vec::new(),
                    strict_rule_indices: Vec::new(),
                    reduction_pair: DpReductionPairProof::Polynomial {
                        interpretation: interpretation.clone(),
                        backend: DpSearchBackend::Sat,
                    },
                    smt_attempted: false,
                    usable_rules: None,
                });
            }
            if delete_strict_rules {
                let removal = removal.as_mut()?;
                if !polynomial_coefficients_are_weakly_monotone(
                    context.pairs,
                    &context.usable_rules,
                    &interpretations,
                ) || interpretations
                    .values()
                    .any(|interpretation| interpretation.constant < 0)
                {
                    return None;
                }
                if context.required_strict_rule_indices.is_empty() {
                    let oriented_rules = removal
                        .usable_rules
                        .as_deref()
                        .unwrap_or(&context.usable_rules);
                    removal.strict_rule_indices = oriented_rules
                        .iter()
                        .enumerate()
                        .filter_map(|(index, rule)| {
                            strictly_decreases_by_polynomial(
                                rule.lhs(),
                                rule.rhs(),
                                &interpretations,
                            )
                            .then_some(index)
                        })
                        .collect();
                }
            }
            if removal.is_none() {
                let argument_filter = polynomial_argument_filter(
                    context.pairs,
                    &context.usable_rules,
                    &interpretations,
                );
                let checked_rules = if context.fixed_usable_rules {
                    context.usable_rules.clone()
                } else {
                    let seed_usable = argument_filtered_usable_rules(
                        &context.usable_rules,
                        context.pairs,
                        &argument_filter,
                    );
                    complete_argument_filtered_usable_rules(
                        &context.usable_rules,
                        context.pairs,
                        &seed_usable,
                        Some(&argument_filter),
                    )
                };
                let weak_pairs = context
                    .pairs
                    .iter()
                    .map(|pair| {
                        weakly_decreases_by_polynomial(pair.lhs(), pair.rhs(), &interpretations)
                    })
                    .collect::<Vec<_>>();
                let strict_pairs = context
                    .pairs
                    .iter()
                    .map(|pair| {
                        strictly_decreases_by_polynomial(pair.lhs(), pair.rhs(), &interpretations)
                    })
                    .collect::<Vec<_>>();
                let weak_rules = checked_rules
                    .iter()
                    .map(|rule| {
                        weakly_decreases_by_polynomial(rule.lhs(), rule.rhs(), &interpretations)
                    })
                    .collect::<Vec<_>>();
                write_progress_event(
                    "dp-exact-witness",
                    "rejected",
                    "exact-poly",
                    0,
                    &format!(
                        "q_minimal={} monotone={} weak_pairs={weak_pairs:?} strict_pairs={strict_pairs:?} checked_rules={} weak_rules={weak_rules:?} rules={:?}",
                        polynomial_q_minimality_holds(context.innermost_lhss),
                        polynomial_coefficients_are_weakly_monotone(
                            context.pairs,
                            &checked_rules,
                            &interpretations,
                        ),
                        checked_rules.len(),
                        checked_rules
                            .iter()
                            .map(ToString::to_string)
                            .collect::<Vec<_>>(),
                    ),
                );
            }
            if std::env::var_os("FERRUM_TIMING_TRACE").is_some() {
                eprintln!(
                    "exact polynomial validation finish elapsed_ms={} applicable={}",
                    exact_started.elapsed().as_millis(),
                    removal.is_some(),
                );
            }
            removal
        }
        DpStrategyProcessor::ExactWeakPolynomial { interpretation } => {
            let interpretations = interpretation
                .iter()
                .map(|(name, constant, coefficients)| {
                    (
                        name.clone(),
                        LinearPolynomial {
                            constant: *constant,
                            coefficients: coefficients.clone(),
                        },
                    )
                })
                .collect::<LinearPolynomialInterpretations>();
            if interpretations.len() != interpretation.len() {
                return None;
            }
            checked_component_removal_by_weak_polynomial(
                context.pairs,
                &context.usable_rules,
                &interpretations,
                DpSearchBackend::Smt,
                context.innermost_lhss,
                context.fixed_usable_rules,
                &context.scoped_options(),
                context.deadline,
            )
        }
        DpStrategyProcessor::ExactMaxPolynomial { interpretation } => {
            let interpretations = interpretation
                .iter()
                .map(|(name, alternatives)| {
                    (
                        name.clone(),
                        alternatives
                            .iter()
                            .map(|(constant, coefficients)| LinearPolynomial {
                                constant: *constant,
                                coefficients: coefficients.clone(),
                            })
                            .collect::<Vec<_>>(),
                    )
                })
                .collect::<MaxPolynomialInterpretations>();
            let required_arities = arities_for_constraints(context.pairs, &context.usable_rules);
            let incomplete = required_arities
                .iter()
                .filter_map(|(symbol, arity)| {
                    interpretations
                        .get(symbol)
                        .filter(|alternatives| {
                            !alternatives.is_empty()
                                && alternatives
                                    .iter()
                                    .all(|alternative| alternative.coefficients.len() == *arity)
                        })
                        .is_none()
                        .then(|| format!("{symbol}/{arity}"))
                })
                .collect::<Vec<_>>();
            if interpretations.len() != interpretation.len() || !incomplete.is_empty() {
                write_progress_event(
                    "dp-exact-witness",
                    "rejected",
                    "exact-max-poly",
                    0,
                    &format!("missing_or_wrong_arity={}", incomplete.join(",")),
                );
                return None;
            }
            let removal = checked_component_removal_by_max_polynomial_with_required_strict_rules(
                context.pairs,
                &context.usable_rules,
                &interpretations,
                DpSearchBackend::Smt,
                context.innermost_lhss,
                &context.required_strict_rule_indices,
            );
            if removal.is_none() {
                let weak_pairs = context
                    .pairs
                    .iter()
                    .map(|pair| {
                        weakly_decreases_by_max_polynomial(pair.lhs(), pair.rhs(), &interpretations)
                    })
                    .collect::<Vec<_>>();
                let strict_pairs = context
                    .pairs
                    .iter()
                    .map(|pair| {
                        strictly_decreases_by_max_polynomial(
                            pair.lhs(),
                            pair.rhs(),
                            &interpretations,
                        )
                    })
                    .collect::<Vec<_>>();
                let weak_rules = context
                    .usable_rules
                    .iter()
                    .map(|rule| {
                        weakly_decreases_by_max_polynomial(rule.lhs(), rule.rhs(), &interpretations)
                    })
                    .collect::<Vec<_>>();
                write_progress_event(
                    "dp-exact-witness",
                    "rejected",
                    "exact-max-poly",
                    0,
                    &format!(
                        "weak_pairs={weak_pairs:?} strict_pairs={strict_pairs:?} weak_rules={weak_rules:?} required_strict_rules={:?}",
                        context.required_strict_rule_indices,
                    ),
                );
            }
            removal
        }
        DpStrategyProcessor::ExactWeightedPathOrderMax { witness } => {
            checked_component_removal_by_wpo_max(
                context.pairs,
                &context.usable_rules,
                witness,
                context.innermost_lhss,
            )
        }
        DpStrategyProcessor::ExactRationalPolynomial {
            denominator,
            interpretation,
        } => {
            let interpretations = interpretation
                .iter()
                .map(|(name, constant, coefficients)| {
                    (
                        name.clone(),
                        LinearPolynomial {
                            constant: *constant,
                            coefficients: coefficients.clone(),
                        },
                    )
                })
                .collect::<LinearPolynomialInterpretations>();
            let required_arities = arities_for_constraints(context.pairs, &context.usable_rules);
            let incomplete = required_arities
                .iter()
                .filter_map(|(symbol, arity)| {
                    interpretations
                        .get(symbol)
                        .filter(|candidate| candidate.coefficients.len() == *arity)
                        .is_none()
                        .then(|| format!("{symbol}/{arity}"))
                })
                .collect::<Vec<_>>();
            if interpretations.len() != interpretation.len() || !incomplete.is_empty() {
                write_progress_event(
                    "dp-exact-witness",
                    "rejected",
                    "exact-rat-poly",
                    0,
                    &format!("missing_or_wrong_arity={}", incomplete.join(",")),
                );
                return None;
            }
            if !context.required_strict_rule_indices.is_empty() {
                write_progress_event(
                    "dp-exact-witness",
                    "checking",
                    "exact-rat-poly",
                    0,
                    &format!(
                        "required_strict_rules={:?}",
                        context
                            .required_strict_rule_indices
                            .iter()
                            .filter_map(|index| context.usable_rules.get(*index))
                            .map(ToString::to_string)
                            .collect::<Vec<_>>()
                    ),
                );
            }
            // CPF's rational natural-polynomial processor carries an explicit
            // positive delta.  Retained AProVE witnesses such as csrdiv use a
            // 1/denominator gap; treating them as a rational-linear
            // processor silently imposed a gap of one and lost valid strict
            // pairs.  A zero-quadratic degree-2 polynomial is the exact same
            // affine interpretation while preserving that CPF boundary.
            let natural = interpretations
                .iter()
                .map(|(symbol, candidate)| {
                    let arity = candidate.coefficients.len();
                    (
                        symbol.clone(),
                        NaturalPolynomial {
                            constant: candidate.constant,
                            linear: candidate.coefficients.clone(),
                            quadratic: vec![vec![0; arity]; arity],
                        },
                    )
                })
                .collect::<BTreeMap<_, _>>();
            // Retained exact witnesses must recover the same
            // interpretation-induced usable-rule obligation as synthesized
            // witnesses.  Checking an exact polynomial against the whole R
            // component is strictly stronger and used to reject valid
            // external witnesses (Ex1_GM03 is the small representative: the
            // zero coefficients of `if` exclude its rules, while `leq` and
            // `p` remain usable).  The closure below is CeTA's AF-aware
            // matchCapRMBelow closure and is independently checked by the
            // emitted redPairUrProc.
            let filtered_usable =
                if context.fixed_usable_rules || !context.required_strict_rule_indices.is_empty() {
                    None
                } else {
                    let argument_filter = polynomial_argument_filter(
                        context.pairs,
                        &context.usable_rules,
                        &interpretations,
                    );
                    let seed_usable = argument_filtered_usable_rules(
                        &context.usable_rules,
                        context.pairs,
                        &argument_filter,
                    );
                    Some(complete_argument_filtered_usable_rules(
                        &context.usable_rules,
                        context.pairs,
                        &seed_usable,
                        Some(&argument_filter),
                    ))
                };
            let checked_usable = filtered_usable.as_deref().unwrap_or(&context.usable_rules);
            // The coefficient denominator and the well-founded delta are
            // independent in CPF.  Preserve the exact rational values while
            // refining their common representation until a positive strict
            // gap is represented.  This is deterministic and every selected
            // scale is rechecked below before proof construction.
            [1_i64, 2, 4, 8, 16, 32, 64].into_iter().find_map(|scale| {
                let scaled_denominator = denominator.checked_mul(scale)?;
                let scaled = natural
                    .iter()
                    .map(|(symbol, polynomial)| {
                        Some((
                            symbol.clone(),
                            NaturalPolynomial {
                                constant: polynomial.constant.checked_mul(scale)?,
                                linear: polynomial
                                    .linear
                                    .iter()
                                    .map(|coefficient| coefficient.checked_mul(scale))
                                    .collect::<Option<Vec<_>>>()?,
                                quadratic: polynomial
                                    .quadratic
                                    .iter()
                                    .map(|row| {
                                        row.iter()
                                            .map(|coefficient| coefficient.checked_mul(scale))
                                            .collect::<Option<Vec<_>>>()
                                    })
                                    .collect::<Option<Vec<_>>>()?,
                            },
                        ))
                    })
                    .collect::<Option<BTreeMap<_, _>>>()?;
                let mut removal = checked_component_removal_by_rational_natural_polynomial_with_required_strict_rules(
                    context.pairs,
                    checked_usable,
                    &scaled,
                    scaled_denominator,
                    1,
                    DpSearchBackend::Smt,
                    &context.required_strict_rule_indices,
                )?;
                if let Some(filtered_usable) = &filtered_usable {
                    removal.usable_rules = Some(filtered_usable.clone());
                }
                Some(removal)
            })
        }
        DpStrategyProcessor::MinimumDeletionLinearPolynomial {
            max_constant,
            max_coefficient,
            max_symbols,
            max_arity,
            min_delete,
            residual_budget,
        } => {
            debug_assert_eq!(*residual_budget, 1);
            let mut scoped_options = context.scoped_options();
            scoped_options.max_polynomial_constant = *max_constant;
            scoped_options.max_polynomial_coefficient = *max_coefficient;
            if let Some(max_symbols) = max_symbols {
                scoped_options.max_polynomial_symbols = *max_symbols;
            }
            if let Some(max_arity) = max_arity {
                scoped_options.max_polynomial_arity = *max_arity;
            }
            synthesize_linear_polynomial_for_minimum_deletion(
                context.pairs,
                &context.usable_rules,
                &context.required_strict_rule_indices,
                *min_delete,
                &scoped_options,
                context.deadline,
            )
            .and_then(|interpretations| {
                checked_component_removal_by_polynomial_with_required_strict_rules(
                    context.pairs,
                    &context.usable_rules,
                    &interpretations,
                    DpSearchBackend::Sat,
                    false,
                    context.innermost_lhss,
                    &context.required_strict_rule_indices,
                )
            })
        }
        DpStrategyProcessor::ExactRationalNaturalPolynomial {
            denominator,
            delta,
            interpretation,
        } => {
            let interpretations = interpretation
                .iter()
                .map(|(name, constant, linear, quadratic)| {
                    (
                        name.clone(),
                        NaturalPolynomial {
                            constant: *constant,
                            linear: linear.clone(),
                            quadratic: quadratic.clone(),
                        },
                    )
                })
                .collect::<BTreeMap<_, _>>();
            if interpretations.len() != interpretation.len() {
                return None;
            }
            let filtered_usable =
                if context.fixed_usable_rules || !context.required_strict_rule_indices.is_empty() {
                    None
                } else {
                    let filter_interpretations = interpretations
                        .iter()
                        .map(|(symbol, polynomial)| {
                            let arity = polynomial.linear.len();
                            let coefficients = (0..arity)
                                .map(|index| {
                                    let linear = polynomial.linear.get(index).copied().unwrap_or(0);
                                    let quadratic = polynomial.quadratic.iter().enumerate().any(
                                        |(row, coefficients)| {
                                            (row == index
                                                && coefficients.iter().any(|value| *value > 0))
                                                || coefficients
                                                    .get(index)
                                                    .is_some_and(|value| *value > 0)
                                        },
                                    );
                                    i64::from(linear > 0 || quadratic)
                                })
                                .collect();
                            (
                                symbol.clone(),
                                LinearPolynomial {
                                    constant: polynomial.constant,
                                    coefficients,
                                },
                            )
                        })
                        .collect::<LinearPolynomialInterpretations>();
                    let argument_filter = polynomial_argument_filter(
                        context.pairs,
                        &context.usable_rules,
                        &filter_interpretations,
                    );
                    let seed_usable = argument_filtered_usable_rules(
                        &context.usable_rules,
                        context.pairs,
                        &argument_filter,
                    );
                    Some(complete_argument_filtered_usable_rules(
                        &context.usable_rules,
                        context.pairs,
                        &seed_usable,
                        Some(&argument_filter),
                    ))
                };
            let checked_usable = filtered_usable.as_deref().unwrap_or(&context.usable_rules);
            let Some(mut removal) =
                checked_component_removal_by_rational_natural_polynomial_with_required_strict_rules(
                    context.pairs,
                    checked_usable,
                    &interpretations,
                    *denominator,
                    *delta,
                    DpSearchBackend::Smt,
                    &context.required_strict_rule_indices,
                )
            else {
                let weak_pairs = context
                    .pairs
                    .iter()
                    .map(|pair| {
                        rational_natural_polynomial_relation(
                            pair.lhs(),
                            pair.rhs(),
                            &interpretations,
                            *denominator,
                            *delta,
                            false,
                        )
                    })
                    .collect::<Vec<_>>();
                let strict_pairs = context
                    .pairs
                    .iter()
                    .map(|pair| {
                        rational_natural_polynomial_relation(
                            pair.lhs(),
                            pair.rhs(),
                            &interpretations,
                            *denominator,
                            *delta,
                            true,
                        )
                    })
                    .collect::<Vec<_>>();
                let weak_rules = checked_usable
                    .iter()
                    .map(|rule| {
                        rational_natural_polynomial_relation(
                            rule.lhs(),
                            rule.rhs(),
                            &interpretations,
                            *denominator,
                            *delta,
                            false,
                        )
                    })
                    .collect::<Vec<_>>();
                write_progress_event(
                    "dp-exact-witness",
                    "rejected",
                    "exact-rat-natural-poly",
                    0,
                    &format!(
                        "weak_pairs={weak_pairs:?} strict_pairs={strict_pairs:?} checked_rules={} weak_rules={weak_rules:?} rules={:?}",
                        checked_usable.len(),
                        checked_usable
                            .iter()
                            .map(ToString::to_string)
                            .collect::<Vec<_>>(),
                    ),
                );
                return None;
            };
            if let Some(filtered_usable) = filtered_usable {
                removal.usable_rules = Some(filtered_usable);
            }
            Some(removal)
        }
        DpStrategyProcessor::ExactMatrixInterpretation { interpretation } => {
            let interpretations = interpretation
                .iter()
                .map(|(name, constant, coefficients)| {
                    (
                        name.clone(),
                        MatrixInterpretation {
                            constant: constant.clone(),
                            coefficients: coefficients.clone(),
                        },
                    )
                })
                .collect::<BTreeMap<_, _>>();
            if interpretations.len() != interpretation.len() {
                return None;
            }
            let ordinary = checked_component_removal_by_matrix_with_required_strict_rules(
                context.pairs,
                &context.usable_rules,
                &interpretations,
                DpSearchBackend::Sat,
                context.innermost_lhss,
                &context.required_strict_rule_indices,
            );
            let q_monotonic = ordinary
                .is_none()
                .then(|| {
                    context.innermost_lhss.and_then(|_| {
                        checked_q_monotonic_matrix_rule_removal(
                            context.pairs,
                            &context.usable_rules,
                            &interpretations,
                            DpSearchBackend::Sat,
                        )
                    })
                })
                .flatten();
            if std::env::var_os("FERRUM_TIMING_TRACE").is_some() {
                eprintln!(
                    "exact matrix validation pairs={} rules={} q={} ordinary={} q_monotonic={}",
                    context.pairs.len(),
                    context.usable_rules.len(),
                    context.innermost_lhss.is_some(),
                    ordinary.is_some(),
                    q_monotonic.is_some(),
                );
            }
            ordinary.or(q_monotonic)
        }
        DpStrategyProcessor::ExactArcticMatrixInterpretation {
            integer_domain,
            interpretation,
        } => {
            let interpretations = interpretation
                .iter()
                .map(|(name, constant, coefficients)| {
                    (
                        name.clone(),
                        MatrixInterpretation {
                            constant: constant.clone(),
                            coefficients: coefficients.clone(),
                        },
                    )
                })
                .collect::<BTreeMap<_, _>>();
            if interpretations.len() != interpretation.len() {
                return None;
            }
            checked_component_removal_by_arctic_matrix_with_usable_rules(
                context.pairs,
                if context.fixed_usable_rules {
                    &context.usable_rules
                } else {
                    &context.input_rules
                },
                &interpretations,
                if *integer_domain {
                    ArcticMatrixDomain::Integers
                } else {
                    ArcticMatrixDomain::Naturals
                },
                DpSearchBackend::Sat,
                context.innermost_lhss,
                context.fixed_usable_rules,
            )
        }
        DpStrategyProcessor::MonotonicPolynomial {
            max_constant,
            max_coefficient,
            max_symbols,
            max_arity,
        } => {
            let mut scoped_options = context.scoped_options();
            scoped_options.max_polynomial_constant = *max_constant;
            scoped_options.max_polynomial_coefficient = *max_coefficient;
            if let Some(max_symbols) = max_symbols {
                scoped_options.max_polynomial_symbols = *max_symbols;
            }
            if let Some(max_arity) = max_arity {
                scoped_options.max_polynomial_arity = *max_arity;
            }
            synthesize_monotonic_usable_polynomial(
                context.pairs,
                &context.usable_rules,
                &scoped_options,
                !same_rule_set(&context.usable_rules, &context.input_rules),
                context.deadline,
            )
        }
        DpStrategyProcessor::SmtPolynomial {
            max_constant,
            max_coefficient,
            max_symbols,
            max_arity,
        } => {
            let mut scoped_options = context.scoped_options();
            scoped_options.smt_fallback = true;
            scoped_options.max_polynomial_constant = *max_constant;
            scoped_options.max_polynomial_coefficient = *max_coefficient;
            if let Some(max_symbols) = max_symbols {
                scoped_options.max_polynomial_symbols = *max_symbols;
            }
            if let Some(max_arity) = max_arity {
                scoped_options.max_polynomial_arity = *max_arity;
            }
            synthesize_linear_polynomial_with_smt(
                context.pairs,
                &context.usable_rules,
                &scoped_options,
                context.deadline,
            )
            .and_then(|(interpretations, attempted)| {
                checked_component_removal_by_polynomial(
                    context.pairs,
                    &context.usable_rules,
                    &interpretations,
                    DpSearchBackend::Smt,
                    attempted,
                    context.innermost_lhss,
                )
            })
        }
        DpStrategyProcessor::QuadraticPolynomial {
            max_constant,
            max_coefficient,
            max_symbols,
            max_arity,
        } => {
            let mut scoped_options = context.scoped_options();
            scoped_options.max_polynomial_constant = *max_constant;
            scoped_options.max_polynomial_coefficient = *max_coefficient;
            if let Some(max_symbols) = max_symbols {
                scoped_options.max_polynomial_symbols = *max_symbols;
            }
            if let Some(max_arity) = max_arity {
                scoped_options.max_polynomial_arity = *max_arity;
            }
            synthesize_quadratic_polynomial_with_smt(
                context.pairs,
                &context.usable_rules,
                &scoped_options,
                context.deadline,
            )
            .and_then(|interpretations| {
                checked_component_removal_by_natural_polynomial(
                    context.pairs,
                    &context.usable_rules,
                    &interpretations,
                    DpSearchBackend::Smt,
                    context.innermost_lhss,
                )
            })
        }
        DpStrategyProcessor::SatPolynomial {
            max_constant,
            max_coefficient,
            max_symbols,
            max_arity,
        } => {
            let mut scoped_options = context.scoped_options();
            scoped_options.max_polynomial_constant = *max_constant;
            scoped_options.max_polynomial_coefficient = *max_coefficient;
            if let Some(max_symbols) = max_symbols {
                scoped_options.max_polynomial_symbols = *max_symbols;
            }
            if let Some(max_arity) = max_arity {
                scoped_options.max_polynomial_arity = *max_arity;
            }
            synthesize_linear_polynomial_with_sat_requiring_strict_rules(
                context.pairs,
                &context.usable_rules,
                &context.required_strict_rule_indices,
                &scoped_options,
                context.deadline,
            )
            .and_then(|interpretations| {
                checked_component_removal_by_polynomial_with_required_strict_rules(
                    context.pairs,
                    &context.usable_rules,
                    &interpretations,
                    DpSearchBackend::Sat,
                    false,
                    context.innermost_lhss,
                    &context.required_strict_rule_indices,
                )
            })
        }
        DpStrategyProcessor::WeakPolynomial {
            min_constant,
            max_constant,
            max_coefficient,
            max_symbols,
            max_arity,
        } => {
            let mut scoped_options = context.scoped_options();
            scoped_options.max_polynomial_constant = *max_constant;
            scoped_options.max_polynomial_coefficient = *max_coefficient;
            if let Some(max_symbols) = max_symbols {
                scoped_options.max_polynomial_symbols = *max_symbols;
            }
            if let Some(max_arity) = max_arity {
                scoped_options.max_polynomial_arity = *max_arity;
            }
            synthesize_weak_polynomial(
                context.pairs,
                &context.usable_rules,
                &scoped_options,
                *min_constant,
                context.fixed_usable_rules,
                context.deadline,
            )
            .and_then(|(interpretations, backend)| {
                checked_component_removal_by_weak_polynomial(
                    context.pairs,
                    &context.usable_rules,
                    &interpretations,
                    backend,
                    context.innermost_lhss,
                    context.fixed_usable_rules,
                    &scoped_options,
                    context.deadline,
                )
            })
        }
        DpStrategyProcessor::TargetWeakPolynomial {
            min_constant,
            max_constant,
            max_coefficient,
            max_symbols,
            max_arity,
            strict_pair_indices,
        } => {
            let mut scoped_options = context.scoped_options();
            scoped_options.max_polynomial_constant = *max_constant;
            scoped_options.max_polynomial_coefficient = *max_coefficient;
            if let Some(max_symbols) = max_symbols {
                scoped_options.max_polynomial_symbols = *max_symbols;
            }
            if let Some(max_arity) = max_arity {
                scoped_options.max_polynomial_arity = *max_arity;
            }
            synthesize_weak_polynomial_with_smt_only(
                context.pairs,
                &context.usable_rules,
                &scoped_options,
                *min_constant,
                context.fixed_usable_rules,
                Some(strict_pair_indices),
                context.deadline,
            )
            .and_then(|interpretations| {
                checked_component_removal_by_weak_polynomial(
                    context.pairs,
                    &context.usable_rules,
                    &interpretations,
                    DpSearchBackend::Smt,
                    context.innermost_lhss,
                    context.fixed_usable_rules,
                    &scoped_options,
                    context.deadline,
                )
            })
        }
        DpStrategyProcessor::MaxPolynomial {
            max_constant,
            max_coefficient,
            alternatives,
            max_symbols,
            max_arity,
        } => {
            let mut scoped_options = context.scoped_options();
            scoped_options.max_polynomial_constant = *max_constant;
            scoped_options.max_polynomial_coefficient = *max_coefficient;
            if let Some(max_symbols) = max_symbols {
                scoped_options.max_polynomial_symbols = *max_symbols;
            }
            if let Some(max_arity) = max_arity {
                scoped_options.max_polynomial_arity = *max_arity;
            }
            synthesize_max_polynomial_requiring_strict_rules(
                context.pairs,
                &context.usable_rules,
                &context.required_strict_rule_indices,
                &scoped_options,
                *alternatives,
                context.deadline,
            )
            .and_then(|(interpretations, backend)| {
                checked_component_removal_by_max_polynomial_with_required_strict_rules(
                    context.pairs,
                    &context.usable_rules,
                    &interpretations,
                    backend,
                    context.innermost_lhss,
                    &context.required_strict_rule_indices,
                )
            })
        }
        DpStrategyProcessor::WeightedPathOrderMax {
            max_constant, max_coefficient, alternatives, max_symbols, max_arity, all_strict, permutations, compact_ground, ordered_alternatives,
        } => {
            // The initial native WPO route preserves Q and declines contexts
            // requiring strict R deletion; it must not silently weaken either.
            if !context.required_strict_rule_indices.is_empty()
                || context.innermost_lhss.is_some_and(|q| !q.is_empty()) {
                return None;
            }
            let mut options = context.scoped_options();
            options.max_polynomial_constant = *max_constant;
            options.max_polynomial_coefficient = *max_coefficient;
            if let Some(n) = max_symbols { options.max_polynomial_symbols = *n; }
            if let Some(n) = max_arity { options.max_polynomial_arity = *n; }
            synthesize_wpo_max_permuting(context.pairs, &context.usable_rules,
                &options, *alternatives, *all_strict, *permutations, *compact_ground, *ordered_alternatives, context.deadline)
        }
        DpStrategyProcessor::RationalQuadraticPolynomial {
            max_constant, max_coefficient, max_symbols, max_arity,
            denominator, delta_denominator, solver, coefficient_values, max_quadratic_terms, quadratic_shape,
        } => {
            let mut options = context.scoped_options();
            if let Some(solver) = solver { options.smt_solver = Some(solver.clone()); }
            options.max_polynomial_constant = *max_constant;
            options.max_polynomial_coefficient = *max_coefficient;
            if let Some(bound) = max_symbols { options.max_polynomial_symbols = *bound; }
            if let Some(bound) = max_arity { options.max_polynomial_arity = *bound; }
            // The checker represents the strict gap as delta / denominator.
            // Round up to a representable gap, never weaken the requested gap.
            if *denominator <= 0 || *delta_denominator <= 0 { return None; }
            let delta = denominator / delta_denominator
                + i64::from(denominator % delta_denominator != 0);
            synthesize_rational_quadratic_polynomial_with_integer_smt(
                context.pairs, &context.usable_rules,
                &context.required_strict_rule_indices, &options,
                *denominator, delta, context.deadline,
                coefficient_values, *max_quadratic_terms, quadratic_shape,
            ).and_then(|interpretations| {
                checked_component_removal_by_rational_natural_polynomial_with_required_strict_rules(
                    context.pairs, &context.usable_rules, &interpretations,
                    *denominator, delta, DpSearchBackend::Smt,
                    &context.required_strict_rule_indices,
                )
            })
        }
        DpStrategyProcessor::RationalPolynomial {
            max_constant,
            max_coefficient,
            max_symbols,
            max_arity,
            denominator,
            delta_denominator,
        } => {
            let mut scoped_options = context.scoped_options();
            scoped_options.max_polynomial_constant = *max_constant;
            scoped_options.max_polynomial_coefficient = *max_coefficient;
            if let Some(max_symbols) = max_symbols {
                scoped_options.max_polynomial_symbols = *max_symbols;
            }
            if let Some(max_arity) = max_arity {
                scoped_options.max_polynomial_arity = *max_arity;
            }
            synthesize_rational_linear_with_usable_rules_requiring_strict_rules(
                context.pairs,
                &context.usable_rules,
                &context.required_strict_rule_indices,
                &scoped_options,
                *denominator,
                *delta_denominator,
                context.deadline,
                context.fixed_usable_rules,
                None,
            )
                .or_else(|| {
                    // Any positive rational gap yields a well-founded strict part.
                    // Use the smallest gap representable by this denominator.
                    let delta = 1;
                    synthesize_rational_quadratic_polynomial_with_smt(
                        context.pairs,
                        &context.usable_rules,
                        &context.required_strict_rule_indices,
                        &scoped_options,
                        *denominator,
                        delta,
                        context.deadline,
                    )
                    .and_then(|interpretations| {
                        checked_component_removal_by_rational_natural_polynomial_with_required_strict_rules(
                            context.pairs,
                            &context.usable_rules,
                            &interpretations,
                            *denominator,
                            delta,
                            DpSearchBackend::Smt,
                            &context.required_strict_rule_indices,
                        )
                    })
                })
        }
        DpStrategyProcessor::TargetRationalPolynomial {
            max_constant,
            max_coefficient,
            max_symbols,
            max_arity,
            denominator,
            delta_denominator,
            min_delete,
            residual_budget,
        } => {
            debug_assert_eq!(*residual_budget, 1);
            let mut scoped_options = context.scoped_options();
            scoped_options.max_polynomial_constant = *max_constant;
            scoped_options.max_polynomial_coefficient = *max_coefficient;
            if let Some(max_symbols) = max_symbols {
                scoped_options.max_polynomial_symbols = *max_symbols;
            }
            if let Some(max_arity) = max_arity {
                scoped_options.max_polynomial_arity = *max_arity;
            }
            synthesize_rational_linear_with_usable_rules_requiring_strict_rules(
                context.pairs,
                &context.usable_rules,
                &context.required_strict_rule_indices,
                &scoped_options,
                *denominator,
                *delta_denominator,
                context.deadline,
                context.fixed_usable_rules,
                Some(*min_delete),
            )
        }
        DpStrategyProcessor::MatrixInterpretation {
            dimension,
            max_constant,
            max_coefficient,
            min_nonzero,
            max_nonzero,
            max_nonzero_constants,
            max_nonzero_per_row,
            max_symbols,
            max_arity,
        } => {
            let mut scoped_options = context.scoped_options();
            scoped_options.max_polynomial_constant = *max_constant;
            scoped_options.max_polynomial_coefficient = *max_coefficient;
            if let Some(max_symbols) = max_symbols {
                scoped_options.max_polynomial_symbols = *max_symbols;
            }
            if let Some(max_arity) = max_arity {
                scoped_options.max_polynomial_arity = *max_arity;
            }
            let ordinary = synthesize_matrix_interpretation_for_component_requiring_strict_rules(
                context.pairs,
                &context.usable_rules,
                &context.required_strict_rule_indices,
                context.required_strict_pair_index,
                &scoped_options,
                *dimension,
                *min_nonzero,
                *max_nonzero,
                *max_nonzero_constants,
                *max_nonzero_per_row,
                context.deadline,
            )
            .and_then(|(interpretations, backend)| {
                checked_component_removal_by_matrix_with_required_strict_rules(
                    context.pairs,
                    &context.usable_rules,
                    &interpretations,
                    backend,
                    context.innermost_lhss,
                    &context.required_strict_rule_indices,
                )
            });
            if ordinary.is_some() || context.innermost_lhss.is_none() {
                return ordinary;
            }

            // A Q-monotonic rule-removal step need not delete a DP. Ask for
            // one strict rule at a time, then independently validate the
            // entire live P/R orientation. The CPF checker performs the final
            // exact usable-replacement-map monotonicity check.
            for strict_rule_index in 0..context.usable_rules.len() {
                if strategy_timed_out(context.deadline) {
                    return None;
                }
                let Some((interpretations, backend)) = synthesize_q_monotonic_matrix_rule_removal(
                    context.pairs,
                    &context.usable_rules,
                    context.innermost_lhss.expect("Q-monotonic branch requires Q"),
                    strict_rule_index,
                    &scoped_options,
                    *dimension,
                    *min_nonzero,
                    *max_nonzero,
                    *max_nonzero_constants,
                    *max_nonzero_per_row,
                    context.deadline,
                ) else {
                    continue;
                };
                if let Some(mut removal) = checked_q_monotonic_matrix_rule_removal(
                    context.pairs,
                    &context.usable_rules,
                    &interpretations,
                    backend,
                ) {
                    // Monotonicity was synthesized for this singleton S.
                    // Other strict rules need their own usable-map check.
                    if !removal.strict_rule_indices.contains(&strict_rule_index) {
                        continue;
                    }
                    removal.strict_rule_indices = vec![strict_rule_index];
                    return Some(removal);
                }
            }
            None
        }
        DpStrategyProcessor::SelectedMatrixInterpretation {
            dimension,
            max_constant,
            max_coefficient,
            min_nonzero,
            max_nonzero,
            max_nonzero_constants,
            max_nonzero_per_row,
            max_symbols,
            max_arity,
            candidate_index,
        } => {
            if *candidate_index == 0 {
                // The retained base-search atom must also retain the
                // Q-monotonic rule-removal continuation of native matrix.
                return synthesize_component_removal_by_processor(
                    &DpStrategyProcessor::MatrixInterpretation {
                        dimension: *dimension, max_constant: *max_constant,
                        max_coefficient: *max_coefficient, min_nonzero: *min_nonzero,
                        max_nonzero: *max_nonzero, max_nonzero_constants: *max_nonzero_constants,
                        max_nonzero_per_row: *max_nonzero_per_row,
                        max_symbols: *max_symbols, max_arity: *max_arity,
                    }, context);
            }
            let mut scoped_options = context.scoped_options();
            scoped_options.max_polynomial_constant = *max_constant;
            scoped_options.max_polynomial_coefficient = *max_coefficient;
            if let Some(max_symbols) = max_symbols {
                scoped_options.max_polynomial_symbols = *max_symbols;
            }
            if let Some(max_arity) = max_arity {
                scoped_options.max_polynomial_arity = *max_arity;
            }
            if let Some(index) = context.q_monotonic_rule_index {
                let (interpretations, backend) = synthesize_q_monotonic_matrix_rule_removal(
                    context.pairs, &context.usable_rules, context.innermost_lhss?, index,
                    &scoped_options, *dimension, *min_nonzero, *max_nonzero,
                    *max_nonzero_constants, *max_nonzero_per_row, context.deadline)?;
                let mut removal = checked_q_monotonic_matrix_rule_removal(
                    context.pairs, &context.usable_rules, &interpretations, backend)?;
                if !removal.strict_rule_indices.contains(&index) { return None; }
                removal.strict_rule_indices = vec![index];
                return Some(removal);
            }
            synthesize_matrix_interpretation_for_component_requiring_strict_rules(
                context.pairs,
                &context.usable_rules,
                &context.required_strict_rule_indices,
                context.required_strict_pair_index,
                &scoped_options,
                *dimension,
                *min_nonzero,
                *max_nonzero,
                *max_nonzero_constants,
                *max_nonzero_per_row,
                context.deadline,
            )
            .and_then(|(interpretations, backend)| {
                checked_component_removal_by_matrix_with_required_strict_rules(
                    context.pairs,
                    &context.usable_rules,
                    &interpretations,
                    backend,
                    context.innermost_lhss,
                    &context.required_strict_rule_indices,
                )
            })
        }
        DpStrategyProcessor::IntegerMatrixInterpretation {
            dimension,
            min_value,
            max_value,
            max_symbols,
            max_arity,
        } => synthesize_integer_matrix_interpretation_for_component(
            context.pairs,
            &context.usable_rules,
            *dimension,
            *min_value,
            *max_value,
            max_symbols.unwrap_or(context.options.max_polynomial_symbols),
            max_arity.unwrap_or(context.options.max_polynomial_arity),
            context.options,
            context.deadline,
        )
        .and_then(|interpretations| {
            checked_component_removal_by_integer_matrix(
                context.pairs,
                &context.usable_rules,
                &interpretations,
                DpSearchBackend::Sat,
                context.innermost_lhss,
            )
        }),
        DpStrategyProcessor::ArcticMatrixInterpretation {
            threshold,
            shared,
            dimension,
            max_constant,
            max_coefficient,
            max_nonzero,
            max_symbols,
            max_arity,
        } => {
            let mut scoped_options = context.scoped_options();
            scoped_options.arctic_threshold_encoding = *threshold;
            scoped_options.max_polynomial_constant = *max_constant;
            scoped_options.max_polynomial_coefficient = *max_coefficient;
            if let Some(max_symbols) = max_symbols {
                scoped_options.max_polynomial_symbols = *max_symbols;
            }
            if let Some(max_arity) = max_arity {
                scoped_options.max_polynomial_arity = *max_arity;
            }
            synthesize_arctic_matrix_interpretation_for_component(
                context.pairs,
                &context.usable_rules,
                &scoped_options,
                *dimension,
                *max_nonzero,
                context.required_strict_pair_index,
                None,
                context.deadline,
                *shared,
            )
            .and_then(|interpretations| {
                checked_component_removal_by_arctic_matrix(
                    context.pairs,
                    &context.usable_rules,
                    &interpretations,
                    ArcticMatrixDomain::Naturals,
                    DpSearchBackend::Smt,
                    context.innermost_lhss,
                )
            })
        }
        DpStrategyProcessor::SelectedArcticMatrixInterpretation {
            threshold,
            shared,
            dimension,
            max_constant,
            max_coefficient,
            max_nonzero,
            max_symbols,
            max_arity,
            ..
        } => {
            let mut scoped_options = context.scoped_options();
            scoped_options.arctic_threshold_encoding = *threshold;
            scoped_options.max_polynomial_constant = *max_constant;
            scoped_options.max_polynomial_coefficient = *max_coefficient;
            if let Some(max_symbols) = max_symbols {
                scoped_options.max_polynomial_symbols = *max_symbols;
            }
            if let Some(max_arity) = max_arity {
                scoped_options.max_polynomial_arity = *max_arity;
            }
            synthesize_arctic_matrix_interpretation_for_component(
                context.pairs,
                &context.usable_rules,
                &scoped_options,
                *dimension,
                *max_nonzero,
                context.required_strict_pair_index,
                None,
                context.deadline,
                *shared,
            )
            .and_then(|interpretations| {
                checked_component_removal_by_arctic_matrix(
                    context.pairs,
                    &context.usable_rules,
                    &interpretations,
                    ArcticMatrixDomain::Naturals,
                    DpSearchBackend::Smt,
                    context.innermost_lhss,
                )
            })
        }
        DpStrategyProcessor::TargetArcticMatrixInterpretation {
            threshold,
            shared,
            symmetry,
            solver,
            dimension,
            max_constant,
            max_coefficient,
            max_nonzero,
            max_symbols,
            max_arity,
            strict_pair_indices,
        } => {
            // Resolve "all" on the live state, not on historical pair positions.
            let all_indices;
            let strict_pair_indices = match strict_pair_indices {
                Some(indices) => indices.as_slice(),
                None => {
                    all_indices = (0..context.pairs.len()).collect::<Vec<_>>();
                    all_indices.as_slice()
                }
            };
            let mut scoped_options = context.scoped_options();
            scoped_options.arctic_threshold_encoding = *threshold;
            if solver.is_some() { scoped_options.smt_solver = solver.clone(); }
            scoped_options.max_polynomial_constant = *max_constant;
            scoped_options.max_polynomial_coefficient = *max_coefficient;
            if let Some(max_symbols) = max_symbols {
                scoped_options.max_polynomial_symbols = *max_symbols;
            }
            if let Some(max_arity) = max_arity {
                scoped_options.max_polynomial_arity = *max_arity;
            }
            synthesize_arctic_matrix_interpretation_with_symmetry(
                context.pairs,
                &context.usable_rules,
                &scoped_options,
                *dimension,
                *max_nonzero,
                None,
                Some(strict_pair_indices),
                context.deadline,
                *shared,
                *symmetry,
            )
            .and_then(|interpretations| {
                checked_component_removal_by_arctic_matrix(
                    context.pairs,
                    &context.usable_rules,
                    &interpretations,
                    ArcticMatrixDomain::Naturals,
                    DpSearchBackend::Smt,
                    context.innermost_lhss,
                )
            })
        }
        DpStrategyProcessor::QuasiPeriodic { period, max_weight } =>
            synthesize_quasi_periodic(context.pairs, &context.usable_rules,
                *period, *max_weight, context.options, context.required_strict_pair_index,
                context.deadline).and_then(|model| {
                checked_component_removal_by_arctic_matrix(context.pairs, &context.usable_rules,
                    &model, ArcticMatrixDomain::Integers, DpSearchBackend::Smt, context.innermost_lhss)
            }),
        DpStrategyProcessor::QuasiPeriodicBv { period, max_weight } =>
            synthesize_quasi_periodic_bv(context.pairs, &context.usable_rules,
                *period, *max_weight, context.options, context.required_strict_pair_index,
                context.deadline).and_then(|model| {
                checked_component_removal_by_arctic_matrix(context.pairs, &context.usable_rules,
                    &model, ArcticMatrixDomain::Integers, DpSearchBackend::Smt, context.innermost_lhss)
            }),
        DpStrategyProcessor::IntegerArcticMatrixInterpretation {
            threshold,
            all_strict,
            max_finite_per_row,
            bitvectors,
            root_projection,
            optimize,
            symmetry,
            solver,
            dimension,
            min_value,
            max_value,
            max_symbols,
            max_arity,
        }
        | DpStrategyProcessor::SelectedIntegerArcticMatrixInterpretation {
            threshold,
            all_strict,
            max_finite_per_row,
            bitvectors,
            root_projection,
            optimize,
            symmetry,
            solver,
            dimension,
            min_value,
            max_value,
            max_symbols,
            max_arity,
            ..
        } => {
            let mut options = context.options.clone();
            options.arctic_threshold_encoding = *threshold;
            if let Some(solver) = solver {
                options.smt_solver = Some(solver.clone());
            }
            synthesize_integer_arctic_matrix_interpretation_with_search_constraints(
                context.pairs,
                &context.usable_rules,
                *dimension,
                *min_value,
                *max_value,
                max_symbols.unwrap_or(context.options.max_polynomial_symbols),
                max_arity.unwrap_or(context.options.max_polynomial_arity),
                &options,
                context.required_strict_pair_index,
                context.deadline,
                *symmetry,
                *bitvectors,
                *optimize,
                *root_projection,
                *all_strict,
                *max_finite_per_row,
            )
            .and_then(|interpretations| {
                checked_component_removal_by_arctic_matrix(
                    context.pairs,
                    &context.usable_rules,
                    &interpretations,
                    ArcticMatrixDomain::Integers,
                    DpSearchBackend::Smt,
                    context.innermost_lhss,
                )
            })
        },
        // Preserve the public atom, but synthesize a general checked order:
        // no signature-specific filters or fixed matrix witnesses.
        DpStrategyProcessor::ApplicativeReductionPair => {
            synthesize_kbo_for_component_requiring_strict_rules(
                context.pairs,
                &context.usable_rules,
                &context.required_strict_rule_indices,
                &context.scoped_options(),
                context.innermost_lhss,
                context.deadline,
                context.fixed_usable_rules,
            )
        }
        DpStrategyProcessor::PathOrder | DpStrategyProcessor::SelectedPathOrder { .. } => {
            synthesize_path_order_for_component_requiring_strict_rules(
                context.pairs,
                &context.usable_rules,
                &context.required_strict_rule_indices,
                &context.scoped_options(),
                context.innermost_lhss,
                context.required_strict_pair_index,
                None,
                context.deadline,
                context.fixed_usable_rules,
            )
        }
        DpStrategyProcessor::ConfiguredPathOrder { order, optimize } => {
            let mut options = context.scoped_options();
            options.path_order_status = Some(*order);
            options.path_order_optimize = *optimize;
            synthesize_path_order_for_component_requiring_strict_rules(
                context.pairs, &context.usable_rules, &context.required_strict_rule_indices,
                &options, context.innermost_lhss, context.required_strict_pair_index,
                None, context.deadline, context.fixed_usable_rules,
            )
        }
        DpStrategyProcessor::TargetPathOrder {
            strict_pair_indices,
        } => synthesize_path_order_for_component_requiring_strict_rules(
            context.pairs,
            &context.usable_rules,
            &context.required_strict_rule_indices,
            &context.scoped_options(),
            context.innermost_lhss,
            None,
            Some(strict_pair_indices),
            context.deadline,
            context.fixed_usable_rules,
        ),
        DpStrategyProcessor::ExactPathOrder {
            default_order,
            statuses,
            precedence,
            precedence_ranks,
            argument_filter,
        } => {
            let removal = checked_component_removal_by_mixed_path_order_with_usable_rules(
                context.pairs,
                &context.usable_rules,
                *default_order,
                statuses,
                precedence,
                precedence_ranks,
                argument_filter,
                DpSearchBackend::PathOrder,
                context.innermost_lhss,
                &context.required_strict_rule_indices,
                context.fixed_usable_rules,
            );
            if removal.is_none() {
                let complete_filter =
                    complete_argument_filter(context.pairs, &context.usable_rules, argument_filter);
                let ranks = precedence_rank_refs(precedence_ranks);
                let rejected_rules = context
                    .usable_rules
                    .iter()
                    .enumerate()
                    .filter_map(|(index, rule)| {
                        (!weakly_decreases_by_mixed_path_order(
                            rule.lhs(),
                            rule.rhs(),
                            *default_order,
                            statuses,
                            &ranks,
                            &complete_filter,
                        ))
                        .then(|| format!("{index}:{rule}"))
                    })
                    .collect::<Vec<_>>();
                let rejected_pairs = context
                    .pairs
                    .iter()
                    .enumerate()
                    .filter_map(|(index, pair)| {
                        (!weakly_decreases_by_mixed_path_order(
                            pair.lhs(),
                            pair.rhs(),
                            *default_order,
                            statuses,
                            &ranks,
                            &complete_filter,
                        ) || !strictly_decreases_by_mixed_path_order(
                            pair.lhs(),
                            pair.rhs(),
                            *default_order,
                            statuses,
                            &ranks,
                            &complete_filter,
                        ))
                        .then(|| format!("{index}:{} -> {}", pair.lhs(), pair.rhs()))
                    })
                    .collect::<Vec<_>>();
                if std::env::var_os("FERRUM_WORKLIST_TRACE").is_some() {
                    eprintln!(
                        "exact path order rejected: nonweak_rules={rejected_rules:?} nonstrict_pairs={rejected_pairs:?}"
                    );
                }
                write_progress_event(
                    "dp-exact-witness",
                    "rejected",
                    "exact-path-order",
                    0,
                    &format!("nonweak_rules={rejected_rules:?} nonstrict_pairs={rejected_pairs:?}"),
                );
            }
            removal
        }
        DpStrategyProcessor::Kbo {
            max_weight,
            max_symbols,
        } => {
            let mut scoped_options = context.scoped_options();
            scoped_options.max_symbol_weight = *max_weight;
            scoped_options.max_symbols = *max_symbols;
            synthesize_kbo_for_component_requiring_strict_rules(
                context.pairs,
                &context.usable_rules,
                &context.required_strict_rule_indices,
                &scoped_options,
                context.innermost_lhss,
                context.deadline,
                context.fixed_usable_rules,
            )
        }
        DpStrategyProcessor::DependencyGraph
        | DpStrategyProcessor::RefinedDependencyGraph
        | DpStrategyProcessor::ExactDependencyGraph { .. }
        | DpStrategyProcessor::ExactGeneralRedPair { .. }
        | DpStrategyProcessor::ExactReductionPair { .. }
        | DpStrategyProcessor::ExactUsableRules { .. }
        | DpStrategyProcessor::ExactInnermostLhss { .. }
        | DpStrategyProcessor::ExactDpTransformation { .. }
        | DpStrategyProcessor::ExactNonterminationRuleRemoval { .. }
        | DpStrategyProcessor::SwitchFullNontermination
        | DpStrategyProcessor::NonterminationLoop
        | DpStrategyProcessor::NonterminationNonLoop
        | DpStrategyProcessor::NonterminationSymbolicLoop
        | DpStrategyProcessor::NonterminationBackwardLoop
        | DpStrategyProcessor::NonterminationForkLoop
        | DpStrategyProcessor::NonterminationFairLoop
        | DpStrategyProcessor::NonterminationInstance { .. }
        | DpStrategyProcessor::NonterminationRuleFilter { .. }
        | DpStrategyProcessor::ExactNonterminationLoop { .. }
        | DpStrategyProcessor::ExactNonterminationProof { .. }
        | DpStrategyProcessor::ExactNonterminationNonLoop { .. }
        | DpStrategyProcessor::ExactSplit { .. }
        | DpStrategyProcessor::UsableRules
        | DpStrategyProcessor::MutermExpand
        | DpStrategyProcessor::Gm04SourceCsr
        | DpStrategyProcessor::Gm04AdministrativeRpo
        | DpStrategyProcessor::InnermostLhss
        | DpStrategyProcessor::SwitchInnermost
        | DpStrategyProcessor::QdpToSrs
        | DpStrategyProcessor::SwitchToTrs
        | DpStrategyProcessor::Subterm
        | DpStrategyProcessor::SizeChange
        | DpStrategyProcessor::ExactSizeChange { .. }
        | DpStrategyProcessor::Rewriting { .. }
        | DpStrategyProcessor::SelectedRewriting { .. }
        | DpStrategyProcessor::Narrowing { .. }
        | DpStrategyProcessor::SelectedNarrowing { .. }
        | DpStrategyProcessor::AlphaMerge
        | DpStrategyProcessor::Instantiation { .. }
        | DpStrategyProcessor::SelectedInstantiation { .. }
        | DpStrategyProcessor::ForwardInstantiation { .. }
        | DpStrategyProcessor::SelectedForwardInstantiation { .. }
        | DpStrategyProcessor::SemanticLabeling
        | DpStrategyProcessor::RootLabeling
        | DpStrategyProcessor::ExactSemanticLabeling { .. }
        | DpStrategyProcessor::UncurryBelow
        | DpStrategyProcessor::Uncurry
        | DpStrategyProcessor::Split
        | DpStrategyProcessor::SelectedSplit { .. }
        | DpStrategyProcessor::ExactSubterm { .. } => None,
        DpStrategyProcessor::ExactTerminationProof { .. }
        | DpStrategyProcessor::NonterminationUsableRules
        | DpStrategyProcessor::NonterminationCycle { .. }
        | DpStrategyProcessor::NonterminationNarrowing { .. }
        | DpStrategyProcessor::NonterminationInnermostLhss
        | DpStrategyProcessor::ConditionalPolynomial { .. }
        | DpStrategyProcessor::ComplexConstantRemoval
        | DpStrategyProcessor::LargestComplexConstantRemoval => None,
    }
}

pub(crate) fn narrowing_processor_side_conditions_hold(
    trs: &Trs,
    pairs: &[DependencyPair],
) -> bool {
    match trs.strategy() {
        RewriteStrategy::Innermost => !pairs.is_empty(),
        RewriteStrategy::Full => pairs
            .iter()
            .any(|pair| narrowing_pair_side_conditions_hold(trs, pair)),
        RewriteStrategy::Outermost => false,
    }
}

fn narrowing_pair_side_conditions_hold(trs: &Trs, pair: &DependencyPair) -> bool {
    match trs.strategy() {
        RewriteStrategy::Innermost => true,
        RewriteStrategy::Full => term_is_linear(pair.rhs()),
        RewriteStrategy::Outermost => false,
    }
}

pub(crate) fn strategy_timed_out(deadline: Option<Instant>) -> bool {
    deadline.is_some_and(|deadline| Instant::now() >= deadline)
}

#[cfg(test)]
fn is_cyclic_dp_problem(
    trs: &Trs,
    pairs: &[DependencyPair],
    innermost_lhss: Option<&[Term]>,
) -> bool {
    let graph = dependency_pair_graph_with_context(trs, pairs, innermost_lhss);
    strongly_connected_components(&graph)
        .iter()
        .any(|component| component_is_cyclic(component, &graph))
}

pub(crate) fn component_is_cyclic(component: &[usize], graph: &[Vec<usize>]) -> bool {
    component.len() > 1
        || component
            .first()
            .is_some_and(|index| graph[*index].contains(index))
}

fn reductions_in_tree(tree: &DpProofTree) -> Vec<DpRemovalProof> {
    let mut reductions = Vec::new();
    collect_reductions_in_tree(tree, &mut reductions);
    reductions
}

fn collect_reductions_in_tree(tree: &DpProofTree, reductions: &mut Vec<DpRemovalProof>) {
    match tree {
        DpProofTree::ExactXml(_)
        | DpProofTree::QdpToSrs { .. }
        | DpProofTree::SwitchToTrs { .. }
        | DpProofTree::Empty
        | DpProofTree::SizeChange { .. }
        | DpProofTree::SizeChangeRedPair { .. } => {}
        DpProofTree::Subterm { proof, .. } => collect_reductions_in_tree(proof, reductions),
        DpProofTree::SwitchInnermost { proof, .. } => collect_reductions_in_tree(proof, reductions),
        DpProofTree::DepGraph { components } => {
            for component in components {
                reductions.extend(component.reductions.clone());
            }
        }
        DpProofTree::GeneralRedPairExact { proofs, .. } => {
            for proof in proofs {
                collect_reductions_in_tree(proof, reductions);
            }
        }
        DpProofTree::ReductionPairExact { proof, .. }
        | DpProofTree::TransformationExact { proof, .. } => {
            collect_reductions_in_tree(proof, reductions);
        }
        DpProofTree::Split {
            selected_proof,
            residual_proof,
            ..
        } => {
            collect_reductions_in_tree(selected_proof, reductions);
            collect_reductions_in_tree(residual_proof, reductions);
        }
        DpProofTree::Narrowing { proof, .. } => collect_reductions_in_tree(proof, reductions),
        DpProofTree::Instantiation { proof, .. } => collect_reductions_in_tree(proof, reductions),
        DpProofTree::ForwardInstantiation { proof, .. } => {
            collect_reductions_in_tree(proof, reductions);
        }
        DpProofTree::Rewriting { proof, .. } => collect_reductions_in_tree(proof, reductions),
        DpProofTree::RedPair { reduction, proof } => {
            reductions.push(reduction.clone());
            collect_reductions_in_tree(proof, reductions);
        }
        DpProofTree::SemanticLabeling { proof, .. } | DpProofTree::Uncurry { proof, .. } => {
            collect_reductions_in_tree(proof, reductions);
        }
        DpProofTree::ComponentContext { proof, .. } => {
            collect_reductions_in_tree(proof, reductions);
        }
    }
}

#[cfg(test)]
fn dp_proof_tree_contains_uncurry(tree: &DpProofTree) -> bool {
    match tree {
        DpProofTree::Uncurry { .. } => true,
        DpProofTree::DepGraph { components } => components.iter().any(|component| {
            component
                .proof_tree
                .as_deref()
                .is_some_and(dp_proof_tree_contains_uncurry)
        }),
        DpProofTree::GeneralRedPairExact { proofs, .. } => proofs
            .iter()
            .any(|proof| dp_proof_tree_contains_uncurry(proof)),
        DpProofTree::Split {
            selected_proof,
            residual_proof,
            ..
        } => {
            dp_proof_tree_contains_uncurry(selected_proof)
                || dp_proof_tree_contains_uncurry(residual_proof)
        }
        DpProofTree::Subterm { proof, .. }
        | DpProofTree::SwitchInnermost { proof, .. }
        | DpProofTree::Narrowing { proof, .. }
        | DpProofTree::Instantiation { proof, .. }
        | DpProofTree::ForwardInstantiation { proof, .. }
        | DpProofTree::Rewriting { proof, .. }
        | DpProofTree::RedPair { proof, .. }
        | DpProofTree::ReductionPairExact { proof, .. }
        | DpProofTree::TransformationExact { proof, .. }
        | DpProofTree::SemanticLabeling { proof, .. }
        | DpProofTree::ComponentContext { proof, .. } => dp_proof_tree_contains_uncurry(proof),
        DpProofTree::ExactXml(_)
        | DpProofTree::QdpToSrs { .. }
        | DpProofTree::SwitchToTrs { .. }
        | DpProofTree::Empty
        | DpProofTree::SizeChange { .. }
        | DpProofTree::SizeChangeRedPair { .. } => false,
    }
}

#[cfg(test)]
fn dp_proof_tree_contains_dependency_graph(tree: &DpProofTree) -> bool {
    match tree {
        DpProofTree::DepGraph { .. } => true,
        DpProofTree::GeneralRedPairExact { proofs, .. } => proofs
            .iter()
            .any(|proof| dp_proof_tree_contains_dependency_graph(proof)),
        DpProofTree::Split {
            selected_proof,
            residual_proof,
            ..
        } => {
            dp_proof_tree_contains_dependency_graph(selected_proof)
                || dp_proof_tree_contains_dependency_graph(residual_proof)
        }
        DpProofTree::Subterm { proof, .. }
        | DpProofTree::SwitchInnermost { proof, .. }
        | DpProofTree::Narrowing { proof, .. }
        | DpProofTree::Instantiation { proof, .. }
        | DpProofTree::ForwardInstantiation { proof, .. }
        | DpProofTree::Rewriting { proof, .. }
        | DpProofTree::RedPair { proof, .. }
        | DpProofTree::ReductionPairExact { proof, .. }
        | DpProofTree::TransformationExact { proof, .. }
        | DpProofTree::SemanticLabeling { proof, .. }
        | DpProofTree::Uncurry { proof, .. }
        | DpProofTree::ComponentContext { proof, .. } => {
            dp_proof_tree_contains_dependency_graph(proof)
        }
        DpProofTree::ExactXml(_)
        | DpProofTree::QdpToSrs { .. }
        | DpProofTree::SwitchToTrs { .. }
        | DpProofTree::Empty
        | DpProofTree::SizeChange { .. }
        | DpProofTree::SizeChangeRedPair { .. } => false,
    }
}

fn final_acyclic_components_in_tree(tree: &DpProofTree) -> Vec<Vec<DependencyPair>> {
    match tree {
        DpProofTree::ExactXml(_) => Vec::new(),
        DpProofTree::QdpToSrs { .. } => Vec::new(),
        DpProofTree::SwitchToTrs { .. } => Vec::new(),
        DpProofTree::DepGraph { components }
            if components.iter().all(|component| !component.proved) =>
        {
            components
                .iter()
                .map(|component| component.pairs.clone())
                .collect()
        }
        DpProofTree::RedPair { proof, .. } => final_acyclic_components_in_tree(proof),
        DpProofTree::GeneralRedPairExact { proofs, .. } => proofs
            .iter()
            .flat_map(|proof| final_acyclic_components_in_tree(proof))
            .collect(),
        DpProofTree::ReductionPairExact { proof, .. }
        | DpProofTree::TransformationExact { proof, .. } => final_acyclic_components_in_tree(proof),
        DpProofTree::SwitchInnermost { proof, .. } => final_acyclic_components_in_tree(proof),
        DpProofTree::Subterm { proof, .. } => final_acyclic_components_in_tree(proof),
        DpProofTree::Narrowing { proof, .. } => final_acyclic_components_in_tree(proof),
        DpProofTree::Instantiation { proof, .. } => final_acyclic_components_in_tree(proof),
        DpProofTree::ForwardInstantiation { proof, .. } => final_acyclic_components_in_tree(proof),
        DpProofTree::Rewriting { proof, .. } => final_acyclic_components_in_tree(proof),
        DpProofTree::SemanticLabeling { proof, .. } => final_acyclic_components_in_tree(proof),
        DpProofTree::Uncurry { proof, .. } => final_acyclic_components_in_tree(proof),
        DpProofTree::ComponentContext { proof, .. } => final_acyclic_components_in_tree(proof),
        DpProofTree::Split {
            selected_proof,
            residual_proof,
            ..
        } => {
            let mut components = final_acyclic_components_in_tree(selected_proof);
            components.extend(final_acyclic_components_in_tree(residual_proof));
            components
        }
        DpProofTree::Empty
        | DpProofTree::SizeChange { .. }
        | DpProofTree::SizeChangeRedPair { .. }
        | DpProofTree::DepGraph { .. } => Vec::new(),
    }
}

pub(crate) fn alpha_unique_rules_with_deadline(
    rules: Vec<RewriteRule>,
    deadline: Option<Instant>,
    cancellation: &DpStrategyCancellation,
) -> Option<Vec<RewriteRule>> {
    let mut seen = BTreeSet::new();
    let mut unique = Vec::new();
    for rule in rules {
        if semlab_timed_out_or_cancelled(deadline, cancellation) {
            return None;
        }
        let key = format!("{} -> {}", rule.lhs(), rule.rhs());
        if seen.insert(key) {
            unique.push(rule);
        }
    }
    Some(unique)
}

fn alpha_unique_terms_with_deadline(
    terms: Vec<Term>,
    deadline: Option<Instant>,
    cancellation: &DpStrategyCancellation,
) -> Option<Vec<Term>> {
    let mut seen = BTreeSet::new();
    let mut unique = Vec::new();
    for term in terms {
        if semlab_timed_out_or_cancelled(deadline, cancellation) {
            return None;
        }
        let key = format!("{term}");
        if seen.insert(key) {
            unique.push(term);
        }
    }
    Some(unique)
}

#[cfg(test)]
mod tests {
    use std::collections::{BTreeMap, BTreeSet};
    use std::fs;
    use std::os::unix::fs::PermissionsExt;
    use std::time::{Duration, Instant};

    use crate::core::{ReplacementMap, RewriteRule, RewriteStrategy, Symbol, Term, Trs, Variable};
    use crate::parsing::{CpfInputProblem, parse_cpf_input};
    use crate::proving::ProblemState;
    use crate::proving::processors::WorklistProcessor;
    use crate::proving::processors::dp::synthesize_applicative_top_uncurrying;
    use crate::proving::processors::test_support::{
        solve_csr_root, solve_csr_root_with_strategy, solve_dependency_pairs,
        solve_dependency_pairs_with_strategy, solve_dp_state_with_strategy,
        solve_improved_csr_dependency_pairs, solve_improved_csr_dependency_pairs_with_strategy,
    };
    use crate::proving::runtime::{cancel, new_cancellation_flag, with_cancellation_flags};

    use super::construction::{
        conservative_csr_dependency_pairs, csr_rhs_active_variables_are_active_in_lhs,
    };
    use super::*;

    #[test]
    fn legacy_oracle_alias_removes_only_frozen_fresh_unhiding_entry() {
        let current = "<dpInput>\n  <strategy>\n    <contextSensitive>\n      <replacementMapEntry>\n        <name>f</name>\n        <arity>1</arity>\n        <position>1</position>\n      </replacementMapEntry>\n      <replacementMapEntry>\n        <name>__CSR_U0</name>\n        <arity>1</arity>\n      </replacementMapEntry>\n    </contextSensitive>\n  </strategy>\n</dpInput>\n";
        let legacy = legacy_frozen_unhiding_oracle_input(current).expect("frozen U alias");
        assert!(!legacy.contains("__CSR_U0"));
        assert!(legacy.contains("<name>f</name>"));

        let active = current.replace(
            "        <arity>1</arity>\n      </replacementMapEntry>\n    </contextSensitive>",
            "        <arity>1</arity>\n        <position>1</position>\n      </replacementMapEntry>\n    </contextSensitive>",
        );
        assert!(legacy_frozen_unhiding_oracle_input(&active).is_none());
    }

    #[test]
    fn legacy_oracle_alias_removes_only_ordinary_bridge_marker() {
        let current = "<dpInput>\n  <minimal>false</minimal>\n  <ferrumDpStateContext>\n    <ordinaryReductionStarted>false</ordinaryReductionStarted>\n    <ordinaryBridgeLosesMinimality>true</ordinaryBridgeLosesMinimality>\n  </ferrumDpStateContext>\n</dpInput>\n";
        let legacy = without_ordinary_bridge_minimality_marker(current)
            .expect("ordinary bridge compatibility alias");
        assert!(!legacy.contains("ordinaryBridgeLosesMinimality"));
        assert!(legacy.contains("<ordinaryReductionStarted>false"));
        assert!(legacy.contains("<minimal>false</minimal>"));
        assert!(without_ordinary_bridge_minimality_marker(&legacy).is_none());
    }

    #[test]
    fn legacy_oracle_alias_removes_only_active_rules_residual_marker() {
        let current = "<dpInput>\n  <ferrumDpStateContext>\n    <graphRules><rules/></graphRules>\n    <activeRulesAreResidual>true</activeRulesAreResidual>\n    <ordinaryReductionStarted>false</ordinaryReductionStarted>\n  </ferrumDpStateContext>\n</dpInput>\n";
        let legacy = without_active_rules_residual_marker(current)
            .expect("active-rules compatibility alias");
        assert!(!legacy.contains("activeRulesAreResidual"));
        assert!(legacy.contains("<graphRules><rules/></graphRules>"));
        assert!(legacy.contains("<ordinaryReductionStarted>false"));
        assert!(without_active_rules_residual_marker(&legacy).is_none());
    }

    #[test]
    fn canonical_improved_csr_dp_input_pins_fresh_unhiding_and_is_idempotent() {
        let legacy = r#"<dpInput>
  <trs><rules><rule><funapp><name>f</name><var>x</var></funapp><var>x</var></rule></rules></trs>
  <dps><rules><rule><funapp><name>u</name><funapp><name>f</name><var>x</var></funapp></funapp><funapp><name>u</name><var>x</var></funapp></rule></rules></dps>
  <strategy><contextSensitive>
    <replacementMapEntry><name>f</name><arity>1</arity><position>1</position></replacementMapEntry>
    <replacementMapEntry><name>u</name><arity>1</arity></replacementMapEntry>
  </contextSensitive></strategy>
  <minimal>true</minimal>
  <ferrumCsrDpContext><construction>improved</construction><graphEstimator>context-sensitive</graphEstimator><qcsUsableRules>true</qcsUsableRules></ferrumCsrDpContext>
</dpInput>"#;
        let materialize = |input: &str| {
            let CpfInputProblem::CsrDp {
                csr,
                pairs,
                pair_source_rules,
                weak_pairs,
                weak_pair_source_rules,
                active_rules,
                minimal,
                construction,
                graph_estimator,
                use_qcs_usable_rules,
                ..
            } = parse_cpf_input(None, input).expect("parse improved CSR-DP state")
            else {
                panic!("expected improved CSR-DP state");
            };
            let with_sources = |rules: Vec<RewriteRule>, sources: Option<Vec<usize>>| {
                rules
                    .into_iter()
                    .enumerate()
                    .map(|(index, rule)| {
                        DependencyPair::from_rule(
                            rule,
                            sources
                                .as_ref()
                                .and_then(|sources| sources.get(index))
                                .copied()
                                .unwrap_or(index),
                        )
                    })
                    .collect()
            };
            DpProblemState::csr_materialized_from_parts(
                &csr,
                with_sources(pairs, pair_source_rules),
                with_sources(weak_pairs, weak_pair_source_rules),
                active_rules,
                minimal,
                &construction,
                &graph_estimator,
                use_qcs_usable_rules,
                DpOptions::default(),
            )
            .expect("materialize improved CSR-DP state")
        };
        let first = standardized_dp_problem_state_input_cpf(&materialize(legacy));
        assert!(first.1.is_none(), "{:?}", first.1);
        assert!(first.0.contains("<name>__CSR_U0</name>"));
        assert!(!first.0.contains("<name>u</name>"));
        let second = standardized_dp_problem_state_input_cpf(&materialize(&first.0));
        assert!(second.1.is_none(), "{:?}", second.1);
        assert_eq!(first.0, second.0);
    }

    #[test]
    fn canonical_csr_dp_input_pins_marked_companions_and_is_idempotent() {
        let trs = Trs::new(
            None,
            BTreeSet::from([Variable::new("x")]),
            vec![
                RewriteRule::new(
                    Term::app("f", vec![Term::var("x")]),
                    Term::app("g", vec![Term::var("x")]),
                ),
                RewriteRule::new(
                    Term::app("g", vec![Term::var("x")]),
                    Term::app("f", vec![Term::var("x")]),
                ),
            ],
        );
        let csr = CsrTrs::new(
            trs,
            ReplacementMap::new(BTreeMap::from([
                (Symbol::new("f"), BTreeSet::from([0])),
                (Symbol::new("g"), BTreeSet::from([0])),
            ])),
        )
        .unwrap();
        let state = DpProblemState::csr_materialized_from_parts(
            &csr,
            vec![
                DependencyPair::from_rule(
                    RewriteRule::new(
                        Term::app("f#", vec![Term::var("x")]),
                        Term::app("g#", vec![Term::var("x")]),
                    ),
                    0,
                ),
                DependencyPair::from_rule(
                    RewriteRule::new(
                        Term::app("g#", vec![Term::var("x")]),
                        Term::app("f#", vec![Term::var("x")]),
                    ),
                    1,
                ),
            ],
            Vec::new(),
            None,
            true,
            "safe",
            "context-sensitive",
            false,
            DpOptions::default(),
        )
        .unwrap();
        let first = standardized_dp_problem_state_input_cpf(&state);
        assert!(first.1.is_none(), "{:?}", first.1);
        assert_eq!(first.0.matches("<sharp>").count(), 4);
        let CpfInputProblem::CsrDp {
            csr,
            pairs,
            pair_source_rules,
            minimal,
            construction,
            graph_estimator,
            use_qcs_usable_rules,
            ..
        } = parse_cpf_input(None, &first.0).unwrap()
        else {
            panic!("expected canonical CSR-DP state");
        };
        let pairs = pairs
            .into_iter()
            .enumerate()
            .map(|(index, rule)| {
                DependencyPair::from_rule(rule, pair_source_rules.as_ref().unwrap()[index])
            })
            .collect();
        let reparsed = DpProblemState::csr_materialized_from_parts(
            &csr,
            pairs,
            Vec::new(),
            None,
            minimal,
            &construction,
            &graph_estimator,
            use_qcs_usable_rules,
            DpOptions::default(),
        )
        .unwrap();
        assert_eq!(
            first.0,
            standardized_dp_problem_state_input_cpf(&reparsed).0
        );
    }

    fn parsed_dp_probe_residual(
        residual: &ProblemState,
    ) -> (Trs, Vec<RewriteRule>, Vec<RewriteRule>, bool) {
        let ProblemState::DependencyPairs(residual) = residual else {
            panic!("expected dependency-pair residual state");
        };
        let cpf = dp_state_input_cpf(residual);
        let CpfInputProblem::Dp {
            trs,
            pairs,
            weak_pairs,
            normal_form_substitutions,
            ..
        } = parse_cpf_input(None, &cpf).expect("parse probe residual")
        else {
            panic!("expected ordinary DP residual");
        };
        (trs, pairs, weak_pairs, normal_form_substitutions)
    }

    #[test]
    fn executable_dp_state_round_trip_preserves_all_runtime_context() {
        let x = Variable::new("x");
        let rule = RewriteRule::new(
            Term::app("f", vec![Term::var("x")]),
            Term::app("g", vec![Term::var("x")]),
        );
        let graph_rule = RewriteRule::new(Term::app("g", vec![Term::var("x")]), Term::var("x"));
        let transformation_rule = RewriteRule::new(
            Term::app("h", vec![Term::var("x")]),
            Term::app("g", vec![Term::var("x")]),
        );
        let trs = Trs::new_with_strategy(
            None,
            BTreeSet::from([x]),
            vec![rule],
            RewriteStrategy::Innermost,
        );
        let pair = DependencyPair::from_rule(
            RewriteRule::new(
                Term::app("f#", vec![Term::var("x")]),
                Term::app("g#", vec![Term::var("x")]),
            ),
            7,
        );
        let mut state = DpProblemState::ordinary(trs, vec![pair], DpOptions::default());
        state.innermost_lhss = Some(vec![Term::app("q", vec![Term::var("x")])]);
        state.stats.graph_rules = Some(vec![graph_rule]);
        state.stats.transformation_rules = Some(vec![transformation_rule]);
        state.stats.active_rules = Some(state.trs.rules().to_vec());
        state.stats.active_rules_are_residual = true;
        state.stats.ordinary_reduction_started = true;
        state.stats.ordinary_bridge_loses_minimality = true;
        let serialized = dp_state_input_cpf(&state);
        assert!(!serialized.contains("<usableRules>"));

        let CpfInputProblem::Dp {
            trs,
            pairs,
            pair_source_rules,
            weak_pairs,
            weak_pair_source_rules,
            strict_rules: _,
            active_rules,
            minimal,
            normal_form_substitutions,
            innermost_lhss,
            clear_innermost_lhss,
            graph_rules,
            transformation_rules,
            active_rules_are_residual,
            ordinary_reduction_started,
            ordinary_bridge_loses_minimality,
        } = parse_cpf_input(None, &serialized).expect("parse executable DP state")
        else {
            panic!("expected DP state");
        };
        assert_eq!(pair_source_rules.as_deref(), Some(&[7][..]));
        let pair_source_rules = pair_source_rules.unwrap_or_else(|| (0..pairs.len()).collect());
        let weak_pair_source_rules =
            weak_pair_source_rules.unwrap_or_else(|| (0..weak_pairs.len()).collect());
        let rebuilt = DpProblemState::materialized_from_parts(
            trs,
            pairs
                .into_iter()
                .zip(pair_source_rules)
                .map(|(rule, source_rule)| DependencyPair::from_rule(rule, source_rule))
                .collect(),
            weak_pairs
                .into_iter()
                .zip(weak_pair_source_rules)
                .map(|(rule, source_rule)| DependencyPair::from_rule(rule, source_rule))
                .collect(),
            active_rules,
            minimal,
            DpOptions::default(),
        )
        .restore_runtime_context(
            innermost_lhss,
            clear_innermost_lhss,
            graph_rules,
            transformation_rules,
            ordinary_reduction_started,
            ordinary_bridge_loses_minimality,
        )
        .with_active_rules_are_residual(active_rules_are_residual)
        .with_normal_form_substitutions(normal_form_substitutions);
        assert_eq!(dp_state_input_cpf(&rebuilt), serialized);
    }

    #[test]
    fn executable_dp_state_distinguishes_removed_q_from_default_q() {
        let rule = RewriteRule::new(
            Term::app("f", vec![Term::var("x")]),
            Term::app("f", vec![Term::var("x")]),
        );
        let trs = Trs::new_with_strategy(
            None,
            BTreeSet::from([Variable::new("x")]),
            vec![rule],
            RewriteStrategy::Innermost,
        );
        let pair = DependencyPair::new_for_test(
            Term::app("f#", vec![Term::var("x")]),
            Term::app("f#", vec![Term::var("x")]),
        );
        let root = DpProblemState::ordinary(trs, vec![pair], DpOptions::default());
        let mut without_q = root.clone();
        without_q.innermost_lhss = None;
        let root_cpf = dp_state_input_cpf(&root);
        let without_q_cpf = dp_state_input_cpf(&without_q);
        assert_ne!(root_cpf, without_q_cpf);
        assert!(root_cpf.contains("ferrumDpStateContext"));
        assert!(without_q_cpf.contains("<noInnermostLhss/>"));
        let CpfInputProblem::Dp {
            clear_innermost_lhss,
            ..
        } = parse_cpf_input(None, &without_q_cpf).expect("parse Q-free state")
        else {
            panic!("expected DP state");
        };
        assert!(clear_innermost_lhss);
    }

    #[test]
    fn executable_csr_dp_state_does_not_recreate_absent_q() {
        let rule = RewriteRule::new(
            Term::app("f", vec![Term::var("x")]),
            Term::app("f", vec![Term::var("x")]),
        );
        let trs = Trs::new(
            None,
            BTreeSet::from([Variable::new("x")]),
            vec![rule.clone()],
        );
        let csr = crate::core::CsrTrs::new(
            trs,
            ReplacementMap::new(BTreeMap::from([(Symbol::new("f"), BTreeSet::new())])),
        )
        .expect("valid replacement map");
        let pair = DependencyPair::new_for_test(
            Term::app("f#", vec![Term::var("x")]),
            Term::app("f#", vec![Term::var("x")]),
        );
        let mut state = csr_dp_problem_state(
            &csr,
            vec![pair],
            CsrDpProblemContext::improved(&csr),
            DpOptions::default(),
            None,
            Vec::new(),
        )
        .expect("CSR-DP state");
        state.stats.active_rules_are_residual = true;
        assert!(state.innermost_lhss.is_none());
        let serialized = dp_state_input_cpf(&state);
        let CpfInputProblem::CsrDp {
            csr,
            pairs,
            pair_source_rules,
            weak_pairs,
            weak_pair_source_rules,
            strict_rules: _,
            active_rules,
            minimal,
            construction,
            graph_estimator,
            use_qcs_usable_rules,
            innermost_lhss,
            clear_innermost_lhss,
            graph_rules,
            transformation_rules,
            active_rules_are_residual,
            ordinary_reduction_started,
            ordinary_bridge_loses_minimality,
            semantic_csr_continuation: _,
        } = parse_cpf_input(None, &serialized).expect("parse executable CSR-DP state")
        else {
            panic!("expected CSR-DP state");
        };
        let pair_source_rules = pair_source_rules.unwrap_or_else(|| (0..pairs.len()).collect());
        let weak_pair_source_rules =
            weak_pair_source_rules.unwrap_or_else(|| (0..weak_pairs.len()).collect());
        let rebuilt = DpProblemState::csr_materialized_from_parts(
            &csr,
            pairs
                .into_iter()
                .zip(pair_source_rules)
                .map(|(rule, source_rule)| DependencyPair::from_rule(rule, source_rule))
                .collect(),
            weak_pairs
                .into_iter()
                .zip(weak_pair_source_rules)
                .map(|(rule, source_rule)| DependencyPair::from_rule(rule, source_rule))
                .collect(),
            active_rules,
            minimal,
            &construction,
            &graph_estimator,
            use_qcs_usable_rules,
            DpOptions::default(),
        )
        .expect("rebuild CSR-DP state")
        .restore_runtime_context(
            innermost_lhss,
            clear_innermost_lhss,
            graph_rules,
            transformation_rules,
            ordinary_reduction_started,
            ordinary_bridge_loses_minimality,
        )
        .with_active_rules_are_residual(active_rules_are_residual)
        .with_normal_form_substitutions(false);
        assert!(rebuilt.innermost_lhss.is_none());
        assert_eq!(dp_state_input_cpf(&rebuilt), serialized);
    }

    #[test]
    fn executable_semantic_csr_residual_preserves_reconstruction_metadata() {
        let rule = RewriteRule::new(
            Term::app("f_0", vec![Term::var("x")]),
            Term::app("g_0", vec![Term::var("x")]),
        );
        let trs = Trs::new(None, BTreeSet::from([Variable::new("x")]), vec![rule]);
        let csr = crate::core::CsrTrs::new(
            trs.clone(),
            ReplacementMap::new(BTreeMap::from([
                (Symbol::new("f_0"), BTreeSet::from([0])),
                (Symbol::new("g_0"), BTreeSet::new()),
            ])),
        )
        .expect("valid labeled replacement map");
        let mut state = DpProblemState::ordinary(
            trs,
            vec![DependencyPair::new_for_test(
                Term::app("f_0#", vec![Term::var("x")]),
                Term::app("g_0#", vec![Term::var("x")]),
            )],
            DpOptions::default(),
        );
        state.stats.semantic_csr_context = Some(CsrDpProblemContext {
            csr: csr.clone(),
            construction: CsrDpConstruction::Improved,
            graph_estimator: CsrGraphEstimator::ContextSensitive,
            use_qcs_usable_rules: true,
            innermost_q_lhss: None,
        });
        state.stats.minimal = false;

        let serialized = dp_state_input_cpf(&state);
        assert!(serialized.contains("<ferrumCsrDpContext>"));
        let CpfInputProblem::CsrDp {
            csr: parsed,
            construction,
            graph_estimator,
            use_qcs_usable_rules,
            semantic_csr_continuation,
            minimal,
            ..
        } = parse_cpf_input(None, &serialized).expect("parse semantic CSR residual")
        else {
            panic!("semantic CSR residual was serialized as an ordinary DP problem");
        };
        assert_eq!(parsed.replacement_map(), csr.replacement_map());
        assert_eq!(construction, "improved");
        assert_eq!(graph_estimator, "context-sensitive");
        assert!(use_qcs_usable_rules);
        assert!(semantic_csr_continuation);
        assert!(!minimal);

        let canonical = standardized_dp_problem_state_input_cpf(&state);
        assert!(canonical.1.is_none(), "{:?}", canonical.1);
        assert!(matches!(
            parse_cpf_input(None, &canonical.0),
            Ok(CpfInputProblem::CsrDp { .. })
        ));
    }

    #[test]
    fn canonical_semantic_csr_empty_rules_preserves_orphan_marked_root() {
      for depth in 0..4 {
        let mut marked = Symbol::new("F#");
        let mut unmarked = Symbol::new("F");
        for _ in 0..depth {
            marked = Symbol::new(semantic_label_symbol(&marked, &[1]));
            unmarked = Symbol::new(semantic_label_symbol(&unmarked, &[1]));
        }
        assert_eq!(semantic_label_unmarked_companion(&marked), Some(unmarked));
        let trs = Trs::new(None, BTreeSet::from([Variable::new("x")]), vec![]);
        let csr = crate::core::CsrTrs::new(trs.clone(), ReplacementMap::new(BTreeMap::new()))
            .expect("empty CSR");
        let pair = RewriteRule::new(
            Term::app(marked.as_str(), vec![Term::app("s", vec![Term::var("x")])]),
            Term::app(marked.as_str(), vec![Term::var("x")]),
        );
        let mut state = DpProblemState::ordinary(
            trs, vec![DependencyPair::from_rule(pair, 4)], DpOptions::default());
        state.stats.semantic_csr_context = Some(CsrDpProblemContext {
            csr, construction: CsrDpConstruction::Improved,
            graph_estimator: CsrGraphEstimator::ContextSensitive,
            use_qcs_usable_rules: true, innermost_q_lhss: None,
        });
        state.stats.minimal = false;
        parse_cpf_input(None, &dp_state_input_cpf(&state)).expect("raw labeled sharp role survives");
        let (canonical, error) = standardized_dp_problem_state_input_cpf(&state);
        assert!(error.is_none());
        let CpfInputProblem::CsrDp { pairs, pair_source_rules, semantic_csr_continuation, .. } =
            parse_cpf_input(None, &canonical).expect("orphan marked root survives canonical import")
        else { panic!("lost CSR context") };
        assert!(pairs[0].lhs().root_symbol().unwrap().as_str().ends_with('#'));
        assert_eq!(pair_source_rules, Some(vec![4]));
        assert!(semantic_csr_continuation);
      }
    }

    #[test]
    fn executable_csr_dp_state_preserves_innermost_rewrite_strategy() {
        let rule = RewriteRule::new(
            Term::app("f", vec![Term::var("x")]),
            Term::app("f", vec![Term::var("x")]),
        );
        let trs = Trs::new_with_strategy(
            None,
            BTreeSet::from([Variable::new("x")]),
            vec![rule],
            RewriteStrategy::Innermost,
        );
        let csr = crate::core::CsrTrs::new(
            trs,
            ReplacementMap::new(BTreeMap::from([(Symbol::new("f"), BTreeSet::from([0]))])),
        )
        .expect("valid replacement map");
        let state = csr_dp_problem_state(
            &csr,
            vec![DependencyPair::new_for_test(
                Term::app("f#", vec![Term::var("x")]),
                Term::app("f#", vec![Term::var("x")]),
            )],
            CsrDpProblemContext::muterm_unhiding(&csr),
            DpOptions::default(),
            None,
            Vec::new(),
        )
        .expect("CSR-DP state");
        let serialized = dp_state_input_cpf(&state);
        assert!(serialized.contains("<rewriteStrategy>innermost</rewriteStrategy>"));
        let CpfInputProblem::CsrDp { csr: parsed, .. } =
            parse_cpf_input(None, &serialized).expect("parse executable CSR-DP state")
        else {
            panic!("expected CSR-DP state");
        };
        assert_eq!(parsed.trs().strategy(), RewriteStrategy::Innermost);
    }

    #[test]
    fn nonminimal_innermost_csr_dp_round_trip_preserves_construction() {
        let trs = Trs::new(
            None,
            BTreeSet::from([Variable::new("x")]),
            vec![RewriteRule::new(
                Term::app("f", vec![Term::var("x")]),
                Term::var("x"),
            )],
        );
        let csr = crate::core::CsrTrs::new(
            trs,
            ReplacementMap::new(BTreeMap::from([(Symbol::new("f"), BTreeSet::new())])),
        )
        .expect("valid replacement map");
        let state = DpProblemState::csr_materialized_from_parts(
            &csr,
            vec![DependencyPair::new_for_test(
                Term::app("f#", vec![Term::var("x")]),
                Term::var("x"),
            )],
            Vec::new(),
            None,
            false,
            "innermost",
            "ordinary",
            false,
            DpOptions::default(),
        )
        .expect("materialize nonminimal innermost CSR-DP state");

        assert!(matches!(
            state.stats.problem,
            DpProblemContext::ContextSensitive(CsrDpProblemContext {
                construction: CsrDpConstruction::Innermost,
                graph_estimator: CsrGraphEstimator::Ordinary,
                ..
            })
        ));
        assert!(!state.stats.minimal);
    }

    #[test]
    fn certified_oracle_dp_atoms_keep_the_full_replay_allowance() {
        for atom in [
            "mono-poly(max-constant=2,max-coefficient=2)",
            "forward-instantiate(max-per-pair=2)",
            "matrix(dim=4,max-constant=2,max-coefficient=2)",
        ] {
            assert_eq!(dp_llm_atom_timeout(atom, 0), Duration::from_secs(60));
        }
    }

    #[test]
    fn native_graph_guidance_gets_a_complete_analysis_budget() {
        for rank in 0..=4 {
            assert_eq!(dp_llm_atom_timeout("graph", rank), Duration::from_secs(60));
        }
        assert_eq!(dp_llm_atom_timeout("subterm", 2), Duration::from_secs(2));
    }

    #[test]
    fn native_guidance_measured_budget_has_headroom_without_promoting_evidence() {
        assert_eq!(dp_llm_measured_atom_timeout("poly", 2, Some(13_777)), Duration::from_millis(16_533));
        assert_eq!(dp_llm_measured_atom_timeout("poly", 2, Some(1)), Duration::from_secs(8));
        assert_eq!(dp_llm_measured_atom_timeout("poly", 2, None), Duration::from_secs(8));
        assert_eq!(dp_llm_measured_atom_timeout("poly", 2, Some(u64::MAX)), Duration::from_secs(300));
    }

    #[test]
    fn weak_root_local_exact_atoms_keep_the_full_replay_allowance() {
        for atom in ["wpo-max(max-constant=4,max-coefficient=1,alternatives=2)",
            "rat-quadratic-poly(max-constant=4,max-coefficient=4,denominator=2,delta-denominator=2)"] {
            assert_eq!(dp_llm_atom_timeout(atom, 2), Duration::from_secs(60));
        }
        assert_eq!(
            dp_llm_atom_timeout("exact-matrix(hex=5b5d)", 2),
            Duration::from_secs(60)
        );
        assert_eq!(
            dp_llm_atom_timeout("poly(max-constant=2,max-coefficient=2)", 2),
            Duration::from_secs(8)
        );
        assert_eq!(
            dp_llm_atom_timeout("exact-usable-rules(hex=5b5d)", 2),
            Duration::from_secs(60)
        );
    }

    fn mixed7_uncurried_innermost_trs() -> Trs {
        let rules = vec![
            RewriteRule::new(
                Term::app(
                    "j4",
                    vec![
                        Term::var("a"),
                        Term::var("b"),
                        Term::var("c"),
                        Term::var("d"),
                    ],
                ),
                Term::app(
                    "f",
                    vec![
                        Term::app("f", vec![Term::var("a"), Term::var("b")]),
                        Term::app(
                            "f",
                            vec![
                                Term::app("f", vec![Term::var("a"), Term::var("d")]),
                                Term::var("c"),
                            ],
                        ),
                    ],
                ),
            ),
            RewriteRule::new(
                Term::app("f", vec![Term::app("j", vec![]), Term::var("y")]),
                Term::app("j1", vec![Term::var("y")]),
            ),
            RewriteRule::new(
                Term::app(
                    "f",
                    vec![Term::app("j1", vec![Term::var("x0")]), Term::var("y")],
                ),
                Term::app("j2", vec![Term::var("x0"), Term::var("y")]),
            ),
            RewriteRule::new(
                Term::app(
                    "f",
                    vec![
                        Term::app("j2", vec![Term::var("x0"), Term::var("x1")]),
                        Term::var("y"),
                    ],
                ),
                Term::app("j3", vec![Term::var("x0"), Term::var("x1"), Term::var("y")]),
            ),
            RewriteRule::new(
                Term::app(
                    "f",
                    vec![
                        Term::app(
                            "j3",
                            vec![Term::var("x0"), Term::var("x1"), Term::var("x2")],
                        ),
                        Term::var("y"),
                    ],
                ),
                Term::app(
                    "j4",
                    vec![
                        Term::var("x0"),
                        Term::var("x1"),
                        Term::var("x2"),
                        Term::var("y"),
                    ],
                ),
            ),
        ];
        let variables = rules
            .iter()
            .flat_map(|rule| {
                rule.lhs()
                    .variables()
                    .into_iter()
                    .chain(rule.rhs().variables())
            })
            .collect();
        Trs::new_with_strategy(None, variables, rules, RewriteStrategy::Innermost)
    }

    #[test]
    fn narrowing_candidates_include_mixed7_outer_application_step() {
        let trs = mixed7_uncurried_innermost_trs();
        let pairs = dependency_pairs(&trs);
        let q_lhss = trs
            .rules()
            .iter()
            .map(|rule| rule.lhs().clone())
            .collect::<Vec<_>>();
        let candidates = synthesize_narrowing_steps_filtered(
            None,
            &trs,
            &pairs,
            &DpOptions::default(),
            Some(&q_lhss),
            None,
            &DpStrategyCancellation::default(),
            |_| true,
        )
        .expect("narrowing search");
        let selected = pairs
            .iter()
            .find(|pair| {
                pair.rhs()
                    == &Term::app(
                        "f#",
                        vec![
                            Term::app("f", vec![Term::var("a"), Term::var("b")]),
                            Term::app(
                                "f",
                                vec![
                                    Term::app("f", vec![Term::var("a"), Term::var("d")]),
                                    Term::var("c"),
                                ],
                            ),
                        ],
                    )
            })
            .expect("outer application pair");
        assert!(narrowing_position_is_admissible(
            &trs,
            selected,
            &[1],
            &pairs,
            &q_lhss
        ));
        assert!(narrowing_position_is_ceta_q_admissible(
            &trs,
            selected,
            &[1],
            &q_lhss
        ));
        let desired = candidates.iter().position(|(_, step, _)| {
            step.pair.rhs()
                == &Term::app(
                    "f#",
                    vec![
                        Term::app("f", vec![Term::var("a"), Term::var("b")]),
                        Term::app(
                            "f",
                            vec![
                                Term::app("f", vec![Term::var("a"), Term::var("d")]),
                                Term::var("c"),
                            ],
                        ),
                    ],
                )
                && step.position == vec![1]
                && step.narrowings.len() == 4
        });
        assert!(
            desired.is_some(),
            "the CeTA-certified AProVE narrowing must be generated; positions: {:?}",
            candidates
                .iter()
                .map(|(_, step, _)| (step.pair.rhs().clone(), step.position.clone()))
                .collect::<Vec<_>>()
        );
        let desired = desired.unwrap();
        assert_eq!(desired, 0, "productive narrowing should rank first");
        let residual = &candidates[desired].2;
        let graph = dependency_pair_graph_with_context(&trs, residual, Some(&q_lhss));
        let components = strongly_connected_components(&graph);
        let mut component_sizes = components.iter().map(Vec::len).collect::<Vec<_>>();
        component_sizes.sort_unstable();
        assert_eq!(
            component_sizes,
            vec![1, 1, 6],
            "CeTA-style IEDG should isolate the two acyclic narrowed pairs"
        );
        let cyclic = components
            .iter()
            .find(|component| component.len() == 6)
            .expect("six-pair cyclic component")
            .iter()
            .map(|index| residual[*index].clone())
            .collect::<Vec<_>>();
        let (rewrite, _) =
            synthesize_innermost_rewriting_step_filtered(&trs, &cyclic, Some(&q_lhss), |_| true)
                .expect("AProVE-style rewrite after narrowing");
        assert!(
            candidates[desired]
                .1
                .narrowings
                .contains(&rewrite.original_pair)
        );
        assert!(
            rewrite.rewrite_step.position == vec![1] || rewrite.rewrite_step.position == vec![2, 1]
        );
    }

    #[test]
    fn arctic_well_formedness_accepts_positive_argument_coefficient() {
        let positive_coefficient = MatrixInterpretation {
            constant: vec![i64::MIN, i64::MIN],
            coefficients: vec![vec![vec![0, i64::MIN], vec![i64::MIN, i64::MIN]]],
        };
        assert!(arctic_matrix_interpretations_are_well_formed(
            &BTreeMap::from([("f#".to_string(), positive_coefficient.clone())]),
            2,
            ArcticMatrixDomain::Naturals,
        ));

        let mut non_positive = positive_coefficient;
        non_positive.coefficients[0][0][0] = i64::MIN;
        assert!(!arctic_matrix_interpretations_are_well_formed(
            &BTreeMap::from([("f#".to_string(), non_positive)]),
            2,
            ArcticMatrixDomain::Naturals,
        ));
    }

    #[test]
    fn arctic_evaluation_width_covers_deep_and_large_weight_terms() {
        let mut term = Term::var("x");
        assert_eq!(arctic_evaluation_width(std::iter::once(&term), 1, 1), Some(6));
        for _ in 0..100 { term = Term::app("f", vec![term]); }
        let width = arctic_evaluation_width(std::iter::once(&term), 64, 64).unwrap();
        assert!(width >= 13);
        assert!((1u128 << width) > 100 * 64 + 64 + 1);
        assert_eq!(arctic_evaluation_width(std::iter::once(&term), -1, 1), None);
    }

    #[test]
    fn all_strict_arctic_actions_roundtrip_without_pair_positions() {
        for name in ["arctic-target", "arctic-target-cached"] {
            for strict in ["all", "0+2"] {
                for solver in ["", ",solver=z3", ",solver=cvc5"] {
                let parsed = DpStrategy::parse(&format!("{name}(dimension=2,max-constant=1,max-coefficient=1,strict={strict}{solver})")).unwrap();
                let DpStrategy::Processor(processor) = &parsed else { panic!() };
                assert_eq!(DpStrategy::parse(&processor.to_strategy_atom()).unwrap(), parsed);
                }
            }
        }
        assert!(DpStrategy::parse("arctic-target(strict=all,solver=unknown)").is_err());
    }

    #[test]
    fn all_strict_arctic_synthesis_checks_every_pair() {
        let x = Term::var("x");
        let pairs = vec![
            DependencyPair::new_for_test(Term::app("f#", vec![Term::app("s", vec![x.clone()])]), Term::app("f#", vec![x.clone()])),
            DependencyPair::new_for_test(Term::app("g#", vec![Term::app("s", vec![x.clone()])]), Term::app("g#", vec![x.clone()])),
        ];
        let options = DpOptions { max_polynomial_constant: 1, max_polynomial_coefficient: 1, ..DpOptions::default() };
        for reversed in [false, true] {
            let mut pairs = pairs.clone();
            if reversed { pairs.reverse(); }
            let model = synthesize_arctic_matrix_interpretation_for_component(&pairs, &[], &options, 1, None, None, Some(&[0, 1]), Some(Instant::now() + Duration::from_secs(10)), true).unwrap();
            let removal = checked_component_removal_by_arctic_matrix(&pairs, &[], &model, ArcticMatrixDomain::Naturals, DpSearchBackend::Smt, None).unwrap();
            assert_eq!(removal.strict_pair_indices.len(), 2);
        }
        let mut bad = pairs;
        bad[1] = DependencyPair::new_for_test(Term::app("g#", vec![x.clone()]), Term::app("g#", vec![x]));
        assert!(synthesize_arctic_matrix_interpretation_for_component(&bad, &[], &options, 1, None, None, Some(&[0, 1]), Some(Instant::now() + Duration::from_secs(10)), true).is_none());
    }

    #[test]
    fn cached_arctic_action_is_distinct_from_legacy_guidance() {
        for candidate in ["", ",candidate=1"] {
            let legacy = DpStrategy::parse(&format!("arctic-matrix(dimension=4,max-constant=1,max-coefficient=1{candidate})")).unwrap();
            let cached = DpStrategy::parse(&format!("arctic-matrix-cached(dimension=4,max-constant=1,max-coefficient=1{candidate})")).unwrap();
            assert_ne!(legacy, cached);
            let DpStrategy::Processor(processor) = cached else { panic!() };
            let atom = processor.to_strategy_atom();
            assert!(atom.starts_with("arctic-matrix-cached("));
            assert_eq!(DpStrategy::parse(&atom).unwrap(), DpStrategy::Processor(processor));
        }
    }

    #[test]
    fn arctic_coordinate_symmetry_is_opt_in_and_exact_checked() {
        let atom = "arctic-target-cached(dimension=3,max-constant=1,max-coefficient=1,strict=all,symmetry=true)";
        let DpStrategy::Processor(processor) = DpStrategy::parse(atom).unwrap() else {panic!()};
        assert_eq!(DpStrategy::parse(&processor.to_strategy_atom()).unwrap(), DpStrategy::Processor(processor));
        assert!(DpStrategy::parse("arctic-target(strict=all,symmetry=maybe)").is_err());
        let x = Term::var("x");
        let pairs = vec![DependencyPair::new_for_test(
            Term::app("f#",vec![Term::app("a",vec![x.clone()])]), Term::app("f#",vec![x]))];
        let mut options = DpOptions::default();
        options.max_polynomial_constant = 1;
        options.max_polynomial_coefficient = 1;
        let model = synthesize_arctic_matrix_interpretation_with_symmetry(
            &pairs,&[],&options,3,None,None,Some(&[0]),
            Some(Instant::now()+Duration::from_secs(15)),true,true).expect("symmetric Arctic synthesis");
        let proof = checked_component_removal_by_arctic_matrix(&pairs,&[],&model,
            ArcticMatrixDomain::Naturals,DpSearchBackend::Smt,None).unwrap();
        assert_eq!(proof.strict_pair_indices,vec![0]);
        let atom = "integer-arctic-matrix(dimension=3,min-value=-1,max-value=1,symmetry=true,solver=z3,candidate=0,encoding=bv,root-projection=true)";
        let DpStrategy::Processor(processor) = DpStrategy::parse(atom).unwrap() else {panic!()};
        assert_eq!(DpStrategy::parse(&processor.to_strategy_atom()).unwrap(),DpStrategy::Processor(processor));
        let model = synthesize_integer_arctic_matrix_interpretation_with_symmetry(
            &pairs,&[],3,-1,1,8,1,&options,None,
            Some(Instant::now()+Duration::from_secs(15)),true,true,false,true).expect("integer symmetric synthesis");
        let proof = checked_component_removal_by_arctic_matrix(&pairs,&[],&model,
            ArcticMatrixDomain::Integers,DpSearchBackend::Smt,None).unwrap();
        assert_eq!(proof.strict_pair_indices,vec![0]);
    }

    #[test]
    fn integer_arctic_all_strict_synthesis_is_checked_and_roundtrips() {
        let atom="integer-arctic-matrix(dimension=2,min-value=0,max-value=1,encoding=bv,strict=all,max-finite-per-row=1)";
        let DpStrategy::Processor(p)=DpStrategy::parse(atom).unwrap() else {panic!()};
        assert_eq!(DpStrategy::parse(&p.to_strategy_atom()).unwrap(),DpStrategy::Processor(p));
        assert!(DpStrategy::parse("integer-arctic-matrix(min-value=0,max-value=1,strict=invalid)").is_err());
        if !command_exists("z3") {return;}
        let x=Term::var("x");
        let pairs=vec![DependencyPair::new_for_test(Term::app("f#",vec![Term::app("a",vec![x.clone()])]),Term::app("f#",vec![x.clone()]))];
        let options=DpOptions::default();
        let model=synthesize_integer_arctic_matrix_interpretation_with_search_constraints(&pairs,&[],2,0,1,8,1,&options,None,Some(Instant::now()+Duration::from_secs(10)),false,true,false,true,true,Some(1)).expect("all-strict model");
        let proof=checked_component_removal_by_arctic_matrix(&pairs,&[],&model,ArcticMatrixDomain::Integers,DpSearchBackend::Smt,None).unwrap();
        assert_eq!(proof.strict_pair_indices,vec![0]);
        let impossible=vec![DependencyPair::new_for_test(Term::app("f#",vec![x.clone()]),Term::app("f#",vec![x]))];
        assert!(synthesize_integer_arctic_matrix_interpretation_with_search_constraints(&impossible,&[],2,0,1,8,1,&options,None,Some(Instant::now()+Duration::from_secs(10)),false,true,false,true,true,Some(1)).is_none());
    }

    #[test]
    fn unary_dimension3_arctic_seed_closes_ag01_431_states() {
        let x = Term::var("x");
        let app = |name: &str, argument: Term| Term::app(name, vec![argument]);
        let rules = vec![
            RewriteRule::new(
                app("d", app("a", x.clone())),
                app("a", app("b", app("c", app("d", x.clone())))),
            ),
            RewriteRule::new(
                app("c", app("b", x.clone())),
                app("b", app("a", app("d", app("c", x.clone())))),
            ),
            RewriteRule::new(app("c", app("a", x.clone())), x.clone()),
            RewriteRule::new(app("d", app("b", x.clone())), x.clone()),
        ];
        let pairs = vec![
            DependencyPair::new_for_test(
                app("d#", app("a", x.clone())),
                app("c#", app("d", x.clone())),
            ),
            DependencyPair::new_for_test(app("d#", app("a", x.clone())), app("d#", x.clone())),
            DependencyPair::new_for_test(
                app("c#", app("b", x.clone())),
                app("d#", app("c", x.clone())),
            ),
            DependencyPair::new_for_test(app("c#", app("b", x.clone())), app("c#", x.clone())),
        ];
        let arities = arities_for_constraints(&pairs, &rules);
        let first = unary_arctic_dimension3_candidate(&arities, 0).expect("six-symbol seed");
        let q_lhss = rules
            .iter()
            .map(|rule| rule.lhs().clone())
            .collect::<Vec<_>>();
        let removal = checked_component_removal_by_arctic_matrix(
            &pairs,
            &rules,
            &first,
            ArcticMatrixDomain::Naturals,
            DpSearchBackend::Smt,
            Some(&q_lhss),
        )
        .expect("the independently checked seed must remove a pair");
        assert!(!removal.strict_pair_indices.is_empty());

        let residual_pair =
            DependencyPair::new_for_test(app("d#", app("a", x.clone())), app("d#", x));
        let residual_arities = arities_for_constraints(std::slice::from_ref(&residual_pair), &[]);
        let second =
            unary_arctic_dimension3_candidate(&residual_arities, 0).expect("two-symbol seed");
        assert!(
            checked_component_removal_by_arctic_matrix(
                &[residual_pair],
                &[],
                &second,
                ArcticMatrixDomain::Naturals,
                DpSearchBackend::Smt,
                None,
            )
            .is_some()
        );

        let normalized_rules = vec![
            RewriteRule::new(
                app("f", app("e", Term::var("x"))),
                app("e", app("b", app("d", app("f", Term::var("x"))))),
            ),
            RewriteRule::new(
                app("d", app("b", Term::var("x"))),
                app("b", app("e", app("f", app("d", Term::var("x"))))),
            ),
            RewriteRule::new(app("d", app("e", Term::var("x"))), Term::var("x")),
            RewriteRule::new(app("f", app("b", Term::var("x"))), Term::var("x")),
        ];
        let normalized_pairs = vec![
            DependencyPair::new_for_test(
                app("c", app("e", Term::var("x"))),
                app("a", app("f", Term::var("x"))),
            ),
            DependencyPair::new_for_test(
                app("c", app("e", Term::var("x"))),
                app("c", Term::var("x")),
            ),
            DependencyPair::new_for_test(
                app("a", app("b", Term::var("x"))),
                app("c", app("d", Term::var("x"))),
            ),
            DependencyPair::new_for_test(
                app("a", app("b", Term::var("x"))),
                app("a", Term::var("x")),
            ),
        ];
        let normalized_arities = arities_for_constraints(&normalized_pairs, &normalized_rules);
        let normalized = unary_arctic_dimension3_candidate(&normalized_arities, 0)
            .expect("canonicalized six-symbol seed");
        assert!(
            checked_component_removal_by_arctic_matrix(
                &normalized_pairs,
                &normalized_rules,
                &normalized,
                ArcticMatrixDomain::Naturals,
                DpSearchBackend::Smt,
                None,
            )
            .is_some()
        );
    }

    #[test]
    fn cyclic_unary_arctic_seed_closes_zantema_z05_narrowed_residual() {
        let x = Term::var("x");
        let app = |name: &str, argument: Term| Term::app(name, vec![argument]);
        let pairs = vec![
            DependencyPair::new_for_test(
                app("a1#", app("a1", app("b1", x.clone()))),
                app("c1#", app("a1", app("c1", x.clone()))),
            ),
            DependencyPair::new_for_test(
                app("b1#", app("b1", app("c1", x.clone()))),
                app("a1#", app("b1", app("a1", x.clone()))),
            ),
            DependencyPair::new_for_test(
                app("c1#", app("c1", app("a1", x.clone()))),
                app("b1#", app("c1", app("b1", x))),
            ),
        ];
        let arities = arities_for_constraints(&pairs, &[]);
        let candidate = cyclic_unary_arctic_dimension3_candidate(&pairs, &arities)
            .expect("the cyclic unary signature should produce a candidate");
        let removal = checked_component_removal_by_arctic_matrix(
            &pairs,
            &[],
            &candidate,
            ArcticMatrixDomain::Naturals,
            DpSearchBackend::Smt,
            None,
        )
        .expect("the independently checked candidate must remove a pair");
        assert_eq!(removal.strict_pair_indices, vec![0]);
    }

    #[test]
    fn mixed7_aprove_arctic_witness_orients_ferrum_residual() {
        let trs = mixed7_uncurried_innermost_trs();
        let q_lhss = trs
            .rules()
            .iter()
            .map(|rule| rule.lhs().clone())
            .collect::<Vec<_>>();
        let cancellation = DpStrategyCancellation::default();
        let mut pairs = dependency_pairs(&trs);
        let narrow = |pairs: &[DependencyPair]| {
            synthesize_narrowing_steps_filtered(
                None,
                &trs,
                pairs,
                &DpOptions::default(),
                Some(&q_lhss),
                None,
                &cancellation,
                |_| true,
            )
            .expect("narrowing candidates")[0]
                .2
                .clone()
        };
        let cyclic = |pairs: Vec<DependencyPair>| {
            let graph = dependency_pair_graph_with_context(&trs, &pairs, Some(&q_lhss));
            strongly_connected_components(&graph)
                .into_iter()
                .max_by_key(Vec::len)
                .expect("cyclic component")
                .into_iter()
                .map(|index| pairs[index].clone())
                .collect::<Vec<_>>()
        };

        pairs = cyclic(narrow(&pairs));
        while let Some((_, residual)) =
            synthesize_innermost_rewriting_step_filtered(&trs, &pairs, Some(&q_lhss), |_| true)
        {
            pairs = residual;
        }
        pairs = cyclic(narrow(&pairs));
        let (_, residual) =
            synthesize_innermost_rewriting_step_filtered(&trs, &pairs, Some(&q_lhss), |_| true)
                .expect("post-narrowing rewrite");
        pairs = residual;
        for _ in 0..4 {
            pairs = synthesize_forward_instantiation_candidates_filtered(
                None,
                &trs,
                &pairs,
                trs.rules(),
                false,
                Some(&q_lhss),
                true,
                None,
                &cancellation,
                |_| true,
            )
            .expect("forward-instantiation candidates")[0]
                .2
                .clone();
        }
        assert_eq!(pairs.len(), 9);

        const N: i64 = i64::MIN;
        let matrix = |constant: [i64; 3], coefficients: Vec<[[i64; 3]; 3]>| MatrixInterpretation {
            constant: constant.to_vec(),
            coefficients: coefficients
                .into_iter()
                .map(|rows| rows.into_iter().map(|row| row.to_vec()).collect())
                .collect(),
        };
        let z = [[N, N, N], [N, N, N], [N, N, N]];
        let interpretation = BTreeMap::from([
            (
                "j4#".to_string(),
                matrix([0, N, N], vec![[[N, N, 0], [N, N, N], [N, N, N]], z, z, z]),
            ),
            (
                "j2".to_string(),
                matrix(
                    [0, N, N],
                    vec![
                        [[N, N, N], [0, 0, 0], [0, 0, 0]],
                        [[N, N, N], [N, N, N], [0, 0, 0]],
                    ],
                ),
            ),
            (
                "f#".to_string(),
                matrix([N, N, N], vec![[[0, N, N], [N, N, N], [N, N, N]], z]),
            ),
            (
                "j3".to_string(),
                matrix(
                    [N, 0, N],
                    vec![
                        [[0, 0, 0], [0, 0, 0], [1, 1, 1]],
                        [[N, N, N], [N, 0, 0], [0, 0, 0]],
                        [[N, N, N], [N, N, N], [0, 0, 0]],
                    ],
                ),
            ),
            (
                "f".to_string(),
                matrix(
                    [0, 0, N],
                    vec![
                        [[N, 0, N], [0, N, 0], [0, 1, 0]],
                        [[N, N, N], [N, N, N], [0, 0, 0]],
                    ],
                ),
            ),
            ("j".to_string(), matrix([0, N, N], vec![])),
            (
                "j1".to_string(),
                matrix([0, N, 0], vec![[[N, N, N], [N, N, N], [0, 0, 0]]]),
            ),
            (
                "j4".to_string(),
                matrix(
                    [0, 0, 1],
                    vec![
                        [[0, N, 0], [0, 1, 0], [1, 1, 1]],
                        [[N, N, N], [0, 0, 0], [0, 0, 0]],
                        [[N, N, N], [0, 0, 0], [0, 0, 0]],
                        [[N, N, N], [N, N, N], [0, 0, 0]],
                    ],
                ),
            ),
        ]);
        let removal = checked_component_removal_by_arctic_matrix(
            &pairs,
            trs.rules(),
            &interpretation,
            ArcticMatrixDomain::Naturals,
            DpSearchBackend::Smt,
            Some(&q_lhss),
        )
        .expect("AProVE's CeTA-certified Arctic witness must orient Ferrum's residual");
        assert!(removal.strict_pair_indices.len() >= 2);

        let first_strict = removal
            .strict_pair_indices
            .into_iter()
            .collect::<BTreeSet<_>>();
        pairs = pairs
            .into_iter()
            .enumerate()
            .filter_map(|(index, pair)| (!first_strict.contains(&index)).then_some(pair))
            .collect();
        let second = degree4_uncurrying_arctic_candidate(
            &arities_for_constraints(&pairs, trs.rules()),
            3,
            1,
            1,
            1,
        )
        .and_then(|interpretation| {
            checked_component_removal_by_arctic_matrix(
                &pairs,
                trs.rules(),
                &interpretation,
                ArcticMatrixDomain::Naturals,
                DpSearchBackend::Smt,
                Some(&q_lhss),
            )
        })
        .expect("AProVE's second Arctic witness");
        let second_strict = second
            .strict_pair_indices
            .into_iter()
            .collect::<BTreeSet<_>>();
        pairs = pairs
            .into_iter()
            .enumerate()
            .filter_map(|(index, pair)| (!second_strict.contains(&index)).then_some(pair))
            .collect();
        pairs = cyclic(pairs);
        assert_eq!(pairs.len(), 3);

        let kbo = degree4_uncurrying_kbo_candidate(&pairs, trs.rules(), Some(&[]))
            .expect("AProVE's filtered KBO witness");
        assert_eq!(kbo.usable_rules, Some(Vec::new()));
        assert_eq!(kbo.strict_pair_indices.len(), 2);
    }

    #[test]
    fn wiehe07_aprove_first_times_arctic_witness_orients_exact_scc() {
        let trs = crate::parsing::parse_ari_trs(
            None,
            include_str!("../../../TPDB-ARI/TRS_Standard/AProVE_07/wiehe07.ari"),
        )
        .expect("wiehe07 fixture");
        let pairs = dependency_pairs(&trs);
        let graph = dependency_pair_graph(&trs, &pairs);
        let components = strongly_connected_components(&graph);
        let times = components
            .iter()
            .map(|component| {
                component
                    .iter()
                    .map(|index| pairs[*index].clone())
                    .collect::<Vec<_>>()
            })
            .find(|component| {
                component.len() == 3
                    && component.iter().all(|pair| {
                        pair.lhs()
                            .root_symbol()
                            .is_some_and(|symbol| symbol.as_str() == "times#")
                    })
            })
            .expect("three-pair TIMES component");
        let neg_inf = i64::MIN;
        let scalar = |constant, coefficients: Vec<i64>| MatrixInterpretation {
            constant: vec![constant],
            coefficients: coefficients
                .into_iter()
                .map(|coefficient| vec![vec![coefficient]])
                .collect(),
        };
        let interpretation = BTreeMap::from([
            ("times#".to_string(), scalar(0, vec![neg_inf, 0])),
            ("plus".to_string(), scalar(1, vec![1, 1])),
            ("s".to_string(), scalar(neg_inf, vec![0])),
            ("times".to_string(), scalar(0, vec![neg_inf, 0])),
            ("|0|".to_string(), scalar(0, vec![])),
            ("if".to_string(), scalar(neg_inf, vec![neg_inf, 0, 0])),
            ("gt".to_string(), scalar(0, vec![neg_inf, neg_inf])),
            ("not".to_string(), scalar(3, vec![4])),
            ("id".to_string(), scalar(neg_inf, vec![0])),
            ("zero".to_string(), scalar(0, vec![])),
            ("true".to_string(), scalar(0, vec![])),
            ("false".to_string(), scalar(0, vec![])),
        ]);
        let usable = usable_rules(&trs, &times);
        let removal = checked_component_removal_by_arctic_matrix_with_usable_rules(
            &times,
            &usable,
            &interpretation,
            ArcticMatrixDomain::Naturals,
            DpSearchBackend::Smt,
            None,
            false,
        )
        .expect("AProVE's first TIMES witness must validate exactly");
        assert_eq!(removal.strict_pair_indices.len(), 1);
        let strict = &times[removal.strict_pair_indices[0]];
        assert_eq!(
            strict.rhs(),
            &Term::app(
                "times#",
                vec![Term::var("x"), Term::app("s", vec![Term::var("z")])]
            )
        );
    }

    #[test]
    fn rewriting_freshens_rule_variables_before_matching() {
        let rule = RewriteRule::new(
            Term::app(
                "j4",
                vec![
                    Term::var("a"),
                    Term::var("b"),
                    Term::var("c"),
                    Term::var("d"),
                ],
            ),
            Term::app(
                "f",
                vec![
                    Term::app("f", vec![Term::var("a"), Term::var("b")]),
                    Term::app(
                        "f",
                        vec![
                            Term::app("f", vec![Term::var("a"), Term::var("d")]),
                            Term::var("c"),
                        ],
                    ),
                ],
            ),
        );
        let trs = Trs::new_with_strategy(
            None,
            BTreeSet::from([
                Variable::new("a"),
                Variable::new("b"),
                Variable::new("c"),
                Variable::new("d"),
            ]),
            vec![rule],
            RewriteStrategy::Innermost,
        );
        let pair = DependencyPair::new_for_test(
            Term::app("p#", vec![Term::var("x")]),
            Term::app(
                "f#",
                vec![
                    Term::app(
                        "j4",
                        vec![
                            Term::var("x0"),
                            Term::var("x1"),
                            Term::var("d"),
                            Term::var("c"),
                        ],
                    ),
                    Term::var("z"),
                ],
            ),
        );

        let (step, _) =
            synthesize_innermost_rewriting_step_filtered(&trs, &[pair], Some(&[]), |_| true)
                .expect("rewriting step");
        assert_eq!(
            step.rewritten_pair.rhs(),
            &Term::app(
                "f#",
                vec![
                    Term::app(
                        "f",
                        vec![
                            Term::app("f", vec![Term::var("x0"), Term::var("x1")]),
                            Term::app(
                                "f",
                                vec![
                                    Term::app("f", vec![Term::var("x0"), Term::var("c")]),
                                    Term::var("d"),
                                ],
                            ),
                        ],
                    ),
                    Term::var("z"),
                ],
            )
        );
    }

    #[test]
    fn parses_dp_uncurrying_processor() {
        assert_eq!(
            DpStrategy::parse("uncurry").unwrap(),
            DpStrategy::Processor(DpStrategyProcessor::Uncurry)
        );
        assert_eq!(
            DpStrategy::parse("uncurrying").unwrap(),
            DpStrategy::Processor(DpStrategyProcessor::Uncurry)
        );
        assert_eq!(
            DpStrategy::parse("uncurry-below").unwrap(),
            DpStrategy::Processor(DpStrategyProcessor::UncurryBelow)
        );
    }

    #[test]
    fn applicative_top_uncurrying_exposes_the_nested_head_arguments() {
        let x = Term::var("x");
        let y = Term::var("y");
        let sx = Term::app("s", vec![x.clone()]);
        let lhs = Term::app(
            "app#",
            vec![
                Term::app("app", vec![Term::app("f", Vec::new()), sx.clone()]),
                y.clone(),
            ],
        );
        let rhs = Term::app(
            "app#",
            vec![
                Term::app("app", vec![Term::app("f", Vec::new()), x.clone()]),
                y.clone(),
            ],
        );
        let pair = DependencyPair::new_for_test(lhs, rhs);
        let trs = Trs::new_with_strategy(
            None,
            BTreeSet::from([Variable::new("x"), Variable::new("y")]),
            Vec::new(),
            RewriteStrategy::Innermost,
        );

        let step =
            synthesize_applicative_top_uncurrying(&trs, &[pair], &[]).expect("applicative DP");
        assert_eq!(step.app_symbol, Symbol::new("app#"));
        assert_eq!(step.applicative_top, Some(2));
        assert!(step.uncurry_rules.is_empty());
        assert_eq!(step.transformed_pairs.len(), 1);
        let expanded = &step
            .symbols
            .iter()
            .find(|entry| entry.original == Symbol::new("app") && entry.arity == 2)
            .expect("application signature entry")
            .symbols[1];
        assert_eq!(
            step.transformed_pairs[0].lhs(),
            &Term::App {
                symbol: expanded.clone(),
                args: vec![Term::app("f", Vec::new()), sx, y.clone()],
            }
        );
        assert_eq!(
            step.transformed_pairs[0].rhs(),
            &Term::App {
                symbol: expanded.clone(),
                args: vec![Term::app("f", Vec::new()), x, y],
            }
        );
    }

    #[test]
    fn applicative_top_uncurrying_materializes_required_eta_pairs() {
        let x = Term::var("x");
        let y = Term::var("y");
        let pair = DependencyPair::new_for_test(
            Term::app(
                "app#",
                vec![
                    Term::app("app", vec![Term::app("rec", Vec::new()), x.clone()]),
                    Term::app("s", vec![y.clone()]),
                ],
            ),
            Term::app(
                "app#",
                vec![
                    Term::app("app", vec![Term::app("rec", Vec::new()), x]),
                    y.clone(),
                ],
            ),
        );
        let collapsing = RewriteRule::new(
            Term::app(
                "app",
                vec![
                    Term::app(
                        "app",
                        vec![Term::app("add", Vec::new()), Term::app("0", Vec::new())],
                    ),
                    y.clone(),
                ],
            ),
            y,
        );
        let trs = Trs::new(
            None,
            BTreeSet::from([Variable::new("x"), Variable::new("y")]),
            vec![collapsing.clone()],
        );

        let step =
            synthesize_applicative_top_uncurrying(&trs, &[pair], std::slice::from_ref(&collapsing))
                .expect("applicative DP with eta closure");
        assert_eq!(step.eta_rules.len(), 1);
        assert_eq!(
            step.eta_rules[0].lhs().root_symbol(),
            Some(&Symbol::new("app#"))
        );
        assert_eq!(
            step.eta_rules[0].rhs().root_symbol(),
            Some(&Symbol::new("app#"))
        );
        // Source pair, strict eta pair, and weak uncurrying pair.
        assert_eq!(step.transformed_pairs.len(), 3);
    }

    #[test]
    fn applicative_top_uncurrying_rejects_unary_transformed_csr_wrapper() {
        let x = Term::var("x");
        let pair = DependencyPair::new_for_test(
            Term::app("top#", vec![Term::app("ok", vec![x.clone()])]),
            Term::app("top#", vec![Term::app("active", vec![x])]),
        );
        let rule = RewriteRule::new(
            Term::app("active", vec![Term::app("f", vec![Term::var("y")])]),
            Term::app("mark", vec![Term::var("y")]),
        );
        let trs = Trs::new_with_strategy(
            None,
            BTreeSet::from([Variable::new("x"), Variable::new("y")]),
            vec![rule.clone()],
            RewriteStrategy::Full,
        );
        assert!(synthesize_applicative_top_uncurrying(&trs, &[pair], &[rule]).is_none());
    }

    #[test]
    fn applicative_top_uncurrying_rejects_ordinary_marked_function_roots() {
        let x = Term::var("x");
        let y = Term::var("y");
        let pair = DependencyPair::new_for_test(
            Term::app("log#", vec![Term::app("s", vec![x.clone()]), y.clone()]),
            Term::app(
                "log#",
                vec![Term::app("div", vec![x.clone(), y.clone()]), y],
            ),
        );
        let rules = vec![RewriteRule::new(
            Term::app("log", vec![Term::app("s", vec![x.clone()]), x.clone()]),
            Term::app("log", vec![x.clone(), x]),
        )];
        let trs = Trs::new(
            None,
            BTreeSet::from([Variable::new("x"), Variable::new("y")]),
            rules.clone(),
        );
        assert!(synthesize_applicative_top_uncurrying(&trs, &[pair], &rules).is_none());
    }

    #[test]
    fn applicative_top_uncurrying_rejects_variable_headed_pairs() {
        let pair = DependencyPair::new_for_test(
            Term::app("app#", vec![Term::var("x"), Term::app("a", Vec::new())]),
            Term::app(
                "app#",
                vec![
                    Term::app("app", vec![Term::app("f", Vec::new()), Term::var("x")]),
                    Term::app("a", Vec::new()),
                ],
            ),
        );
        let trs = Trs::new(None, BTreeSet::from([Variable::new("x")]), Vec::new());
        assert!(synthesize_applicative_top_uncurrying(&trs, &[pair], &[]).is_none());
    }

    #[test]
    fn ordinary_dp_uncurrying_below_is_ceta_certified() {
        let x = Term::var("x");
        let pair = DependencyPair::new_for_test(
            Term::app(
                "f#",
                vec![Term::app(
                    "g",
                    vec![Term::app("c", Vec::new()), Term::app("s", vec![x.clone()])],
                )],
            ),
            Term::app("f#", vec![x.clone()]),
        );
        let trs = Trs::new(
            None,
            BTreeSet::from([Variable::new("x")]),
            vec![RewriteRule::new(
                Term::app("g", vec![Term::app("c", Vec::new()), x.clone()]),
                x,
            )],
        );
        let pairs = vec![pair];
        let proof = solve_dp_state_with_strategy(
            &trs,
            pairs.clone(),
            &DpOptions::default(),
            &DpStrategy::parse("pipeline(uncurry-below; size-change)").unwrap(),
            None,
        )
        .expect("ordinary uncurrying below should expose the strict argument descent");
        let cpf = crate::cert::write_cpf3_dp_problem(&trs, &pairs, &proof);
        assert!(cpf.contains("<uncurryProc>"));
        assert!(!cpf.contains("<applicativeTop>"));
        let ceta = std::path::Path::new("../CeTA-CSR/ceta");
        if ceta.exists() {
            let path = std::env::temp_dir().join("ferrum-dp-uncurry-below.cpf3.xml");
            fs::write(&path, cpf).unwrap();
            let output = Command::new(ceta).arg(path).output().unwrap();
            assert!(
                output.status.success(),
                "CeTA rejected ordinary DP uncurrying CPF:\nstdout:\n{}\nstderr:\n{}",
                String::from_utf8_lossy(&output.stdout),
                String::from_utf8_lossy(&output.stderr)
            );
        }
    }

    #[test]
    fn full_dp_problem_uses_applicative_top_uncurrying_before_size_change() {
        let x = Term::var("x");
        let y = Term::var("y");
        let pair = DependencyPair::new_for_test(
            Term::app(
                "app#",
                vec![
                    Term::app(
                        "app",
                        vec![Term::app("f", Vec::new()), Term::app("s", vec![x.clone()])],
                    ),
                    y.clone(),
                ],
            ),
            Term::app(
                "app#",
                vec![Term::app("app", vec![Term::app("f", Vec::new()), x]), y],
            ),
        );
        let trs = Trs::new(
            None,
            BTreeSet::from([Variable::new("x"), Variable::new("y")]),
            Vec::new(),
        );
        let options = DpOptions::default();
        let strategy = DpStrategy::parse("graph; uncurry; graph; size-change").unwrap();

        let pairs = vec![pair];
        let proof = solve_dp_state_with_strategy(&trs, pairs.clone(), &options, &strategy, None)
            .expect("uncurrying and size change should close the full DP problem");
        assert!(proof.component_proofs.iter().any(|component| {
            component
                .proof_tree
                .as_deref()
                .is_some_and(dp_proof_tree_contains_uncurry)
        }));

        let cpf = crate::cert::write_cpf3_dp_problem(&trs, &pairs, &proof);
        assert!(cpf.contains("<uncurryProc>"));
        assert!(cpf.contains("<applicativeTop>2</applicativeTop>"));
        let ceta = std::path::Path::new("../CeTA-CSR/ceta");
        if ceta.exists() {
            let path = std::env::temp_dir().join("ferrum-dp-applicative-top.cpf3.xml");
            fs::write(&path, cpf).unwrap();
            let output = Command::new(ceta).arg(path).output().unwrap();
            assert!(
                output.status.success(),
                "CeTA rejected DP uncurrying CPF:\nstdout:\n{}\nstderr:\n{}",
                String::from_utf8_lossy(&output.stdout),
                String::from_utf8_lossy(&output.stderr)
            );
        }
    }

    #[test]
    fn synthesizes_csr_matrix_rule_removal_with_inactive_argument() {
        let trs = Trs::new(
            None,
            BTreeSet::from([Variable::new("x")]),
            vec![RewriteRule::new(
                Term::app("f", vec![Term::var("x")]),
                Term::var("x"),
            )],
        );
        let csr = CsrTrs::new(
            trs,
            ReplacementMap::new(BTreeMap::from([(Symbol::new("f"), BTreeSet::new())])),
        )
        .unwrap();
        let options = DpOptions {
            max_polynomial_constant: 1,
            max_polynomial_coefficient: 1,
            ..DpOptions::default()
        };
        let removal =
            synthesize_csr_matrix_rule_removal(&csr, &options, 2, None).expect("matrix removal");

        assert_eq!(removal.removed, csr.rules());
        assert!(removal.remaining.rules().is_empty());
    }

    #[test]
    fn synthesizes_aprove_csr_matrix_rule_removal_example() {
        let csr = crate::parsing::parse_ari_cstrs(
            None,
            include_str!("../../tests/fixtures/csr_matrix_aprove_ex55.ari"),
        )
        .unwrap();
        let options = DpOptions {
            max_polynomial_constant: 1,
            max_polynomial_coefficient: 1,
            ..DpOptions::default()
        };
        let removal =
            synthesize_csr_matrix_rule_removal(&csr, &options, 2, None).expect("matrix removal");

        assert!(!removal.removed.is_empty());
        assert!(removal.remaining.rules().len() < csr.rules().len());
    }

    #[test]
    fn csr_matrix_rule_removal_is_invariant_under_renaming_and_rule_order() {
        let original = crate::parsing::parse_ari_cstrs(
            None,
            include_str!("../../tests/fixtures/csr_matrix_aprove_ex55.ari"),
        )
        .unwrap();
        let bijection = original
            .trs()
            .arities()
            .keys()
            .enumerate()
            .map(|(index, symbol)| {
                (
                    symbol.clone(),
                    Symbol::new(format!("renamed_symbol_{index}")),
                )
            })
            .collect::<BTreeMap<_, _>>();
        let mut renamed_rules = original
            .rules()
            .iter()
            .map(|rule| crate::standardize::translate_rule_symbols(rule, &bijection))
            .collect::<Vec<_>>();
        renamed_rules.reverse();
        let renamed_trs = Trs::new_with_strategy(
            None,
            original.trs().variables().clone(),
            renamed_rules,
            original.trs().strategy(),
        );
        let renamed_map = ReplacementMap::new(
            original
                .replacement_map()
                .entries()
                .iter()
                .map(|(symbol, positions)| {
                    (bijection.get(symbol).unwrap().clone(), positions.clone())
                })
                .collect(),
        );
        let renamed = CsrTrs::new(renamed_trs, renamed_map).unwrap();
        let options = DpOptions {
            max_polynomial_constant: 1,
            max_polynomial_coefficient: 1,
            ..DpOptions::default()
        };

        let original_removal =
            synthesize_csr_matrix_rule_removal(&original, &options, 2, None).unwrap();
        let renamed_removal =
            synthesize_csr_matrix_rule_removal(&renamed, &options, 2, None).unwrap();
        let (original_remaining, original_error) =
            super::super::engine::standardized_csr_input_cpf4(&original_removal.remaining);
        let (renamed_remaining, renamed_error) =
            super::super::engine::standardized_csr_input_cpf4(&renamed_removal.remaining);

        assert!(original_error.is_none(), "{original_error:?}");
        assert!(renamed_error.is_none(), "{renamed_error:?}");
        assert_eq!(
            original_removal.removed.len(),
            renamed_removal.removed.len()
        );
        assert_eq!(original_remaining, renamed_remaining);
    }

    #[test]
    fn extracts_dependency_pairs() {
        let variables = BTreeSet::from([Variable::new("x")]);
        let trs = Trs::new(
            None,
            variables,
            vec![RewriteRule::new(
                Term::app("f", vec![Term::var("x")]),
                Term::app("f", vec![Term::app("g", vec![Term::var("x")])]),
            )],
        );
        assert_eq!(dependency_pairs(&trs).len(), 1);
    }

    #[test]
    fn dependency_pair_construction_removes_duplicate_rhs_calls() {
        let variables = BTreeSet::from([Variable::new("x")]);
        let recursive_call = Term::app("f", vec![Term::var("x")]);
        let trs = Trs::new(
            None,
            variables,
            vec![RewriteRule::new(
                Term::app("f", vec![Term::var("x")]),
                Term::app("g", vec![recursive_call.clone(), recursive_call]),
            )],
        );

        assert_eq!(dependency_pairs(&trs).len(), 1);
    }

    #[test]
    fn canonical_dp_input_is_invariant_under_symbol_and_variable_renaming() {
        let left_trs = Trs::new(
            None,
            BTreeSet::from([Variable::new("x")]),
            vec![RewriteRule::new(
                Term::app("f", vec![Term::var("x")]),
                Term::app("g", vec![Term::var("x")]),
            )],
        );
        let right_trs = Trs::new(
            None,
            BTreeSet::from([Variable::new("z")]),
            vec![RewriteRule::new(
                Term::app("alpha", vec![Term::var("z")]),
                Term::app("beta", vec![Term::var("z")]),
            )],
        );
        let left_pairs = vec![DependencyPair::new_for_test(
            Term::app("f#", vec![Term::var("y")]),
            Term::app("g#", vec![Term::var("y")]),
        )];
        let right_pairs = vec![DependencyPair::new_for_test(
            Term::app("alpha#", vec![Term::var("w")]),
            Term::app("beta#", vec![Term::var("w")]),
        )];

        assert_eq!(
            standardized_dp_input_cpf3(&left_trs, &left_pairs).0,
            standardized_dp_input_cpf3(&right_trs, &right_pairs).0,
        );
    }

    #[test]
    fn canonical_complete_dp_state_is_invariant_under_set_order_and_remaps_sources() {
        let first = RewriteRule::new(
            Term::app("f", vec![Term::var("x")]),
            Term::app("g", vec![Term::var("x")]),
        );
        let second = RewriteRule::new(
            Term::app("g", vec![Term::var("x")]),
            Term::app("h", vec![Term::var("x")]),
        );
        let left_trs = Trs::new(
            None,
            BTreeSet::from([Variable::new("x")]),
            vec![first.clone(), second.clone()],
        );
        let right_trs = Trs::new(
            None,
            BTreeSet::from([Variable::new("x")]),
            vec![second.clone(), first.clone()],
        );
        let f_pair = RewriteRule::new(
            Term::app("f#", vec![Term::var("x")]),
            Term::app("g#", vec![Term::var("x")]),
        );
        let g_pair = RewriteRule::new(
            Term::app("g#", vec![Term::var("x")]),
            Term::app("h#", vec![Term::var("x")]),
        );
        let mut left = DpProblemState::materialized_from_parts(
            left_trs,
            vec![
                DependencyPair::from_rule(f_pair.clone(), 0),
                DependencyPair::from_rule(g_pair.clone(), 1),
            ],
            Vec::new(),
            None,
            true,
            DpOptions::default(),
        );
        left.stats.graph_rules = Some(vec![first.clone()]);
        let mut right = DpProblemState::materialized_from_parts(
            right_trs,
            vec![
                DependencyPair::from_rule(g_pair, 0),
                DependencyPair::from_rule(f_pair, 1),
            ],
            Vec::new(),
            None,
            true,
            DpOptions::default(),
        );
        right.stats.graph_rules = Some(vec![first]);

        let left = standardized_dp_problem_state_input_cpf(&left);
        let right = standardized_dp_problem_state_input_cpf(&right);
        assert!(left.1.is_none(), "{:?}", left.1);
        assert!(right.1.is_none(), "{:?}", right.1);
        assert_eq!(left.0, right.0);
    }

    #[test]
    fn canonical_complete_dp_state_recognizes_alpha_renamed_default_q() {
        let trs = Trs::new_with_strategy(
            None,
            BTreeSet::from([Variable::new("x")]),
            vec![RewriteRule::new(
                Term::app("f", vec![Term::var("x")]),
                Term::app("g", vec![Term::var("x")]),
            )],
            RewriteStrategy::Innermost,
        );
        let pair = DependencyPair::new_for_test(
            Term::app("f#", vec![Term::var("x")]),
            Term::app("g#", vec![Term::var("x")]),
        );
        let default_q = DpProblemState::materialized_from_parts(
            trs.clone(),
            vec![pair.clone()],
            Vec::new(),
            Some(Vec::new()),
            true,
            DpOptions::default(),
        );
        let mut parsed_spelling = DpProblemState::materialized_from_parts(
            trs,
            vec![pair],
            Vec::new(),
            Some(Vec::new()),
            true,
            DpOptions::default(),
        );
        parsed_spelling.innermost_lhss = Some(vec![Term::app("f", vec![Term::var("x0")])]);

        assert_eq!(
            standardized_dp_problem_state_input_cpf(&default_q).0,
            standardized_dp_problem_state_input_cpf(&parsed_spelling).0,
        );
    }

    #[test]
    fn canonical_complete_dp_state_orders_alpha_duplicates_by_source() {
        let trs = Trs::new(
            None,
            BTreeSet::from([Variable::new("x")]),
            vec![
                RewriteRule::new(
                    Term::app("a", vec![Term::var("x")]),
                    Term::app("b", vec![Term::var("x")]),
                ),
                RewriteRule::new(
                    Term::app("c", vec![Term::var("x")]),
                    Term::app("d", vec![Term::var("x")]),
                ),
            ],
        );
        let pair_x = DependencyPair::from_rule(
            RewriteRule::new(
                Term::app("u#", vec![Term::var("x")]),
                Term::app("v#", vec![Term::var("x")]),
            ),
            0,
        );
        let pair_y = DependencyPair::from_rule(
            RewriteRule::new(
                Term::app("u#", vec![Term::var("y")]),
                Term::app("v#", vec![Term::var("y")]),
            ),
            1,
        );
        let left = DpProblemState::materialized_from_parts(
            trs.clone(),
            vec![pair_x.clone(), pair_y.clone()],
            Vec::new(),
            None,
            true,
            DpOptions::default(),
        );
        let right = DpProblemState::materialized_from_parts(
            trs,
            vec![pair_y, pair_x],
            Vec::new(),
            None,
            true,
            DpOptions::default(),
        );

        assert_eq!(
            standardized_dp_problem_state_input_cpf(&left).0,
            standardized_dp_problem_state_input_cpf(&right).0,
        );
    }

    #[test]
    fn canonical_complete_dp_state_keeps_processor_relevant_context_distinct() {
        let trs = Trs::new(
            None,
            BTreeSet::from([Variable::new("x")]),
            vec![
                RewriteRule::new(
                    Term::app("f", vec![Term::var("x")]),
                    Term::app("g", vec![Term::var("x")]),
                ),
                RewriteRule::new(Term::app("g", vec![Term::var("x")]), Term::var("x")),
            ],
        );
        let pairs = dependency_pairs(&trs);
        let plain = DpProblemState::materialized_from_parts(
            trs.clone(),
            pairs.clone(),
            Vec::new(),
            None,
            true,
            DpOptions::default(),
        );
        let mut restricted_graph = DpProblemState::materialized_from_parts(
            trs.clone(),
            pairs,
            Vec::new(),
            None,
            true,
            DpOptions::default(),
        );
        restricted_graph.stats.graph_rules = Some(vec![trs.rules()[0].clone()]);

        assert_ne!(
            standardized_dp_problem_state_input_cpf(&plain).0,
            standardized_dp_problem_state_input_cpf(&restricted_graph).0,
        );
    }

    #[test]
    fn canonical_dp_input_identifies_explicit_full_usable_rules_with_default() {
        let trs = Trs::new(
            None,
            BTreeSet::from([Variable::new("x")]),
            vec![RewriteRule::new(
                Term::app("f", vec![Term::var("x")]),
                Term::app("f", vec![Term::app("s", vec![Term::var("x")])]),
            )],
        );
        let pairs = dependency_pairs(&trs);
        let implicit =
            standardized_relative_dp_state_input_cpf3(&trs, &pairs, &[], None, true, false);
        let explicit = standardized_relative_dp_state_input_cpf3(
            &trs,
            &pairs,
            &[],
            Some(trs.rules()),
            true,
            false,
        );
        let alpha_renamed_rules = vec![RewriteRule::new(
            Term::app("f", vec![Term::var("fresh")]),
            Term::app("f", vec![Term::app("s", vec![Term::var("fresh")])]),
        )];
        let alpha_explicit = standardized_relative_dp_state_input_cpf3(
            &trs,
            &pairs,
            &[],
            Some(&alpha_renamed_rules),
            true,
            false,
        );

        assert!(implicit.1.is_none(), "{:?}", implicit.1);
        assert!(explicit.1.is_none(), "{:?}", explicit.1);
        assert!(alpha_explicit.1.is_none(), "{:?}", alpha_explicit.1);
        assert_eq!(implicit.0, explicit.0);
        assert_eq!(implicit.0, alpha_explicit.0);
        assert!(!implicit.0.contains("<usableRules>"));
    }

    #[test]
    fn canonical_dp_input_retains_full_rules_when_they_mark_a_residual() {
        let trs = Trs::new(
            None,
            BTreeSet::from([Variable::new("x")]),
            vec![RewriteRule::new(
                Term::app("f", vec![Term::var("x")]),
                Term::app("f", vec![Term::app("s", vec![Term::var("x")])]),
            )],
        );
        let pairs = dependency_pairs(&trs);
        let plain = DpProblemState::materialized_from_parts(
            trs.clone(),
            pairs.clone(),
            Vec::new(),
            None,
            true,
            DpOptions::default(),
        );
        let residual = DpProblemState::materialized_from_parts(
            trs.clone(),
            pairs,
            Vec::new(),
            Some(trs.rules().to_vec()),
            true,
            DpOptions::default(),
        )
        .with_active_rules_are_residual(true);

        let plain = standardized_dp_problem_state_input_cpf(&plain).0;
        let residual = standardized_dp_problem_state_input_cpf(&residual).0;
        assert_ne!(plain, residual);
        assert!(residual.contains("<activeRulesAreResidual>true</activeRulesAreResidual>"));
    }

    #[test]
    fn canonical_csr_dp_input_preserves_replacement_map_under_renaming() {
        fn problem(f: &str, g: &str, variable: &str) -> (CsrTrs, Vec<DependencyPair>) {
            let trs = Trs::new(
                None,
                BTreeSet::from([Variable::new(variable)]),
                vec![RewriteRule::new(
                    Term::app(f, vec![Term::var(variable)]),
                    Term::app(g, vec![Term::var(variable)]),
                )],
            );
            let csr = CsrTrs::new(
                trs,
                ReplacementMap::new(BTreeMap::from([
                    (Symbol::new(f), BTreeSet::from([0])),
                    (Symbol::new(g), BTreeSet::new()),
                ])),
            )
            .unwrap();
            let pairs = vec![DependencyPair::new_for_test(
                Term::app(format!("{f}#"), vec![Term::var(variable)]),
                Term::app(format!("{g}#"), vec![Term::var(variable)]),
            )];
            (csr, pairs)
        }
        let (left_csr, left_pairs) = problem("f", "g", "x");
        let (right_csr, right_pairs) = problem("alpha", "beta", "z");

        let left = standardized_csr_dp_state_input_cpf4(
            &left_csr,
            &left_pairs,
            None,
            true,
            "improved",
            "context-sensitive",
            true,
        );
        let right = standardized_csr_dp_state_input_cpf4(
            &right_csr,
            &right_pairs,
            None,
            true,
            "improved",
            "context-sensitive",
            true,
        );

        assert!(left.1.is_none(), "{:?}", left.1);
        assert!(right.1.is_none(), "{:?}", right.1);
        assert_eq!(left.0, right.0);
        assert!(left.0.contains("<position>1</position>"));
    }

    #[test]
    fn canonical_csr_dp_input_identifies_explicit_full_usable_rules_with_default() {
        let trs = Trs::new(
            None,
            BTreeSet::from([Variable::new("x")]),
            vec![RewriteRule::new(
                Term::app("f", vec![Term::var("x")]),
                Term::app("f", vec![Term::app("s", vec![Term::var("x")])]),
            )],
        );
        let csr = CsrTrs::new(
            trs,
            ReplacementMap::new(BTreeMap::from([
                (Symbol::new("f"), BTreeSet::from([0])),
                (Symbol::new("s"), BTreeSet::new()),
            ])),
        )
        .unwrap();
        let pairs = csr_dependency_pairs(&csr);
        let implicit = standardized_relative_csr_dp_state_input_cpf4(
            &csr,
            &pairs,
            &[],
            None,
            true,
            "improved",
            "context-sensitive",
            true,
        );
        let explicit = standardized_relative_csr_dp_state_input_cpf4(
            &csr,
            &pairs,
            &[],
            Some(csr.rules()),
            true,
            "improved",
            "context-sensitive",
            true,
        );

        assert!(implicit.1.is_none(), "{:?}", implicit.1);
        assert!(explicit.1.is_none(), "{:?}", explicit.1);
        assert_eq!(implicit.0, explicit.0);
        assert!(!implicit.0.contains("<usableRules>"));
    }

    #[test]
    fn canonical_csr_dp_input_with_restricted_rules_is_parseable_and_idempotent() {
        let (csr, pairs) = {
            let trs = Trs::new(
                None,
                BTreeSet::from([Variable::new("x")]),
                vec![
                    RewriteRule::new(
                        Term::app("f", vec![Term::var("x")]),
                        Term::app("g", vec![Term::var("x")]),
                    ),
                    RewriteRule::new(
                        Term::app("g", vec![Term::var("x")]),
                        Term::app("h", vec![Term::var("x")]),
                    ),
                ],
            );
            let csr = CsrTrs::new(
                trs,
                ReplacementMap::new(BTreeMap::from([
                    (Symbol::new("f"), BTreeSet::from([0])),
                    (Symbol::new("g"), BTreeSet::from([0])),
                    (Symbol::new("h"), BTreeSet::new()),
                ])),
            )
            .unwrap();
            let pairs = csr_dependency_pairs(&csr);
            (csr, pairs)
        };
        let (first, error) = standardized_csr_dp_state_input_cpf4(
            &csr,
            &pairs,
            Some(&[]),
            true,
            "safe",
            "context-sensitive",
            false,
        );
        assert!(error.is_none(), "{error:?}");
        let crate::parsing::CpfInputProblem::CsrDp {
            csr: parsed,
            pairs: parsed_pairs,
            active_rules,
            minimal,
            construction,
            graph_estimator,
            use_qcs_usable_rules,
            ..
        } = crate::parsing::parse_cpf_input(None, &first).unwrap()
        else {
            panic!("expected a QCS-DP state");
        };
        assert_eq!(active_rules, Some(Vec::new()));
        let parsed_pairs = parsed_pairs
            .into_iter()
            .enumerate()
            .map(|(index, rule)| DependencyPair::from_rule(rule, index))
            .collect::<Vec<_>>();
        let (second, second_error) = standardized_csr_dp_state_input_cpf4(
            &parsed,
            &parsed_pairs,
            active_rules.as_deref(),
            minimal,
            &construction,
            &graph_estimator,
            use_qcs_usable_rules,
        );
        assert!(second_error.is_none(), "{second_error:?}");
        assert_eq!(first, second);
    }

    #[test]
    fn csr_dependency_pairs_ignore_inactive_rhs_calls() {
        let variables = BTreeSet::from([Variable::new("x")]);
        let trs = Trs::new(
            None,
            variables,
            vec![
                RewriteRule::new(
                    Term::app("f", vec![Term::var("x")]),
                    Term::app("g", vec![Term::app("f", vec![Term::var("x")])]),
                ),
                RewriteRule::new(Term::app("g", vec![Term::var("x")]), Term::var("x")),
            ],
        );
        let replacement_map = crate::core::ReplacementMap::new(BTreeMap::from([
            (Symbol::new("f"), BTreeSet::from([0])),
            (Symbol::new("g"), BTreeSet::new()),
        ]));
        let csr = CsrTrs::new(trs, replacement_map).unwrap();

        let pairs = csr_dependency_pairs(&csr);

        assert_eq!(pairs.len(), 1);
        assert_eq!(pairs[0].lhs(), &Term::app("f#", vec![Term::var("x")]));
        assert_eq!(
            pairs[0].rhs(),
            &Term::app("g#", vec![Term::app("f", vec![Term::var("x")])])
        );
    }

    #[test]
    fn ex1_gm03_innermost_csr_problem_covers_hidden_calls_and_active_contexts() {
        let csr = crate::parsing::parse_ari_cstrs(
            None,
            r#"
                (format CSTRS)
                (fun p 1 :replacement-map (1))
                (fun |0| 0 :replacement-map ())
                (fun s 1 :replacement-map (1))
                (fun leq 2 :replacement-map (1 2))
                (fun true 0 :replacement-map ())
                (fun false 0 :replacement-map ())
                (fun if 3 :replacement-map (1))
                (fun diff 2 :replacement-map (1 2))
                (rule (p |0|) |0|)
                (rule (p (s X)) X)
                (rule (leq |0| Y) true)
                (rule (leq (s X) |0|) false)
                (rule (leq (s X) (s Y)) (leq X Y))
                (rule (if true X Y) X)
                (rule (if false X Y) Y)
                (rule (diff X Y) (if (leq X Y) |0| (s (diff (p X) Y))))
            "#,
        )
        .unwrap();

        let (problem, pairs) = innermost_csr_dependency_problem(&csr);
        let auxiliary = &problem.rules()[csr.rules().len()..];
        let auxiliary_rules = auxiliary
            .iter()
            .map(ToString::to_string)
            .collect::<BTreeSet<_>>();
        let pair_rules = pairs
            .iter()
            .map(|pair| pair.as_rule().to_string())
            .collect::<BTreeSet<_>>();

        assert_eq!(auxiliary.len(), 7);
        assert!(auxiliary_rules.contains("diff(x1, x2) -> x1"));
        assert!(auxiliary_rules.contains("diff(x1, x2) -> x2"));
        assert!(auxiliary_rules.contains("if(x1, x2, x3) -> x1"));
        assert!(!auxiliary_rules.contains("if(x1, x2, x3) -> x2"));
        assert!(!auxiliary_rules.contains("if(x1, x2, x3) -> x3"));

        assert_eq!(pairs.len(), 7);
        assert!(pair_rules.contains("diff(p(X), Y) -> diff#(p(X), Y)"));
        assert!(pair_rules.contains("p(X) -> p#(X)"));
        assert!(pair_rules.contains("diff#(X, Y) -> leq#(X, Y)"));
        assert!(pair_rules.contains("diff#(X, Y) -> if#(leq(X, Y), |0|, s(diff(p(X), Y)))"));

        let context = CsrDpProblemContext::innermost(&problem, &csr);
        let state = csr_dp_problem_state(
            &problem,
            pairs,
            context,
            DpOptions::default(),
            None,
            Vec::new(),
        )
        .expect("materialize direct innermost-CSR dependency pairs");
        assert!(
            !state.stats.minimal,
            "the verified direct-unhiding theorem produces a nonminimal DPP"
        );
    }

    #[test]
    fn ex1_gm03_muterm_problem_has_exact_specialized_unhiding_component() {
        let csr = crate::parsing::parse_ari_cstrs(
            Some("CSR_04/Ex1_GM03.ari".to_string()),
            include_str!("../../tests/fixtures/csr_ex1_gm03.ari"),
        )
        .expect("parse Ex1_GM03 fixture");

        let pairs = rta_csr_dependency_pairs(&csr);
        let unhiding = muterm_innermost_unhiding_rules(&csr);
        let pair_rules = pairs
            .iter()
            .map(|pair| format!("{} -> {}", pair.lhs(), pair.rhs()))
            .collect::<BTreeSet<_>>();
        let unhiding_rules = unhiding
            .iter()
            .map(ToString::to_string)
            .collect::<BTreeSet<_>>();

        assert_eq!(pairs.len(), 5);
        assert_eq!(
            unhiding.len(),
            2,
            "unexpected unhiding rules: {unhiding_rules:?}"
        );
        assert!(pair_rules.contains("diff#(X, Y) -> if#(leq(X, Y), |0|, s(diff(p(X), Y)))"));
        assert!(pair_rules.contains("if#(false, X, Y) -> Y"));
        assert!(pair_rules.contains("if#(true, X, Y) -> X"));
        assert_eq!(
            unhiding_rules,
            BTreeSet::from([
                "s(diff(p(X), Y)) -> diff#(p(X), Y)".to_string(),
                "s(diff(p(X), Y)) -> p#(X)".to_string(),
            ])
        );
    }

    #[test]
    fn ex1_gm03_improved_pairs_diagnostic() {
        let csr = crate::parsing::parse_ari_cstrs(
            Some("CSR_04/Ex1_GM03.ari".to_string()),
            include_str!("../../tests/fixtures/csr_ex1_gm03.ari"),
        )
        .expect("parse Ex1_GM03 fixture");
        let pairs = certificate_improved_csr_dependency_pairs(&csr);
        for pair in &pairs {
            eprintln!("{} -> {}", pair.lhs(), pair.rhs());
        }
        eprintln!("pairs={}", pairs.len());
    }

    #[test]
    fn ex1_gm03_muterm_reduction_triples_are_exactly_recheckable() {
        let csr = crate::parsing::parse_ari_cstrs(
            Some("CSR_04/Ex1_GM03.ari".to_string()),
            include_str!("../../tests/fixtures/csr_ex1_gm03.ari"),
        )
        .expect("parse Ex1_GM03 fixture");
        let pairs = rta_csr_dependency_pairs(&csr)
            .into_iter()
            .filter(|pair| {
                matches!(
                    pair.lhs().root_symbol().map(Symbol::as_str),
                    Some("diff#" | "if#")
                ) && pair
                    .rhs()
                    .root_symbol()
                    .is_none_or(|s| s.as_str() != "leq#")
            })
            .collect::<Vec<_>>();
        assert_eq!(pairs.len(), 3);

        let wanted = [
            "leq(|0|, Y) -> true",
            "leq(s(X), |0|) -> false",
            "leq(s(X), s(Y)) -> leq(X, Y)",
            "p(|0|) -> |0|",
            "p(s(X)) -> X",
        ];
        let weak = csr
            .rules()
            .iter()
            .filter(|rule| wanted.contains(&rule.to_string().as_str()))
            .cloned()
            .collect::<Vec<_>>();
        let retained = muterm_ex1_gm03_rational_candidate(&pairs, &weak, &[])
            .expect("the retained Ex1 model must be selected and exactly rechecked");
        assert_eq!(retained.strict_pair_indices.len(), 1);
        let mut weak = weak;
        weak.extend(muterm_innermost_unhiding_rules(&csr));
        assert_eq!(weak.len(), 7, "unexpected weak component: {weak:?}");

        let linear = |constant, coefficients: &[i64]| NaturalPolynomial {
            constant,
            linear: coefficients.to_vec(),
            quadratic: vec![vec![0; coefficients.len()]; coefficients.len()],
        };
        let interpretation = BTreeMap::from([
            ("diff".into(), linear(1, &[2, 2])),
            ("if".into(), linear(0, &[0, 0, 0])),
            ("leq".into(), linear(0, &[1, 0])),
            ("p".into(), linear(0, &[1])),
            ("|0|".into(), linear(0, &[])),
            ("false".into(), linear(1, &[])),
            ("s".into(), linear(2, &[4])),
            ("true".into(), linear(0, &[])),
            ("diff#".into(), linear(4, &[4, 4])),
            ("if#".into(), linear(0, &[2, 2, 2])),
            ("leq#".into(), linear(0, &[0, 0])),
            ("p#".into(), linear(0, &[0])),
        ]);
        let removal =
            checked_component_removal_by_rational_natural_polynomial_with_required_strict_rules(
                &pairs,
                &weak,
                &interpretation,
                2,
                1,
                DpSearchBackend::Smt,
                &[],
            )
            .expect("MU-TERM's first reduction triple must recheck exactly");
        assert_eq!(removal.strict_pair_indices.len(), 1);
        assert_eq!(
            pairs[removal.strict_pair_indices[0]].lhs().to_string(),
            "if#(false, X, Y)"
        );

        let residual = pairs
            .iter()
            .enumerate()
            .filter(|(index, _)| !removal.strict_pair_indices.contains(index))
            .map(|(_, pair)| pair.clone())
            .collect::<Vec<_>>();
        let second = BTreeMap::from([
            ("diff".into(), linear(1, &[2, 2])),
            ("if".into(), linear(0, &[0, 0, 0])),
            ("leq".into(), linear(0, &[0, 2])),
            ("p".into(), linear(2, &[2])),
            ("|0|".into(), linear(0, &[])),
            ("false".into(), linear(0, &[])),
            ("s".into(), linear(1, &[2])),
            ("true".into(), linear(0, &[])),
            ("diff#".into(), linear(2, &[0, 2])),
            ("if#".into(), linear(2, &[1, 2, 0])),
            ("leq#".into(), linear(0, &[0, 0])),
            ("p#".into(), linear(0, &[0])),
        ]);
        let second_removal =
            checked_component_removal_by_rational_natural_polynomial_with_required_strict_rules(
                &residual,
                &weak,
                &second,
                1,
                1,
                DpSearchBackend::Smt,
                &[],
            )
            .expect("MU-TERM's second reduction triple must recheck exactly");
        assert_eq!(second_removal.strict_pair_indices.len(), 1);
        assert_eq!(
            residual[second_removal.strict_pair_indices[0]]
                .lhs()
                .to_string(),
            "if#(true, X, Y)"
        );

        let exact = |denominator: i64, interpretation: &BTreeMap<String, NaturalPolynomial>| {
            DpStrategy::Processor(DpStrategyProcessor::ExactRationalNaturalPolynomial {
                denominator,
                delta: 1,
                interpretation: interpretation
                    .iter()
                    .map(|(symbol, polynomial)| {
                        (
                            symbol.clone(),
                            polynomial.constant,
                            polynomial.linear.clone(),
                            polynomial.quadratic.clone(),
                        )
                    })
                    .collect(),
            })
        };
        let strategy = DpStrategy::Sequence(vec![
            DpStrategy::Processor(DpStrategyProcessor::DependencyGraph),
            DpStrategy::Choice(vec![
                DpStrategy::Processor(DpStrategyProcessor::Subterm),
                DpStrategy::Sequence(vec![
                    exact(2, &interpretation),
                    DpStrategy::Processor(DpStrategyProcessor::DependencyGraph),
                    exact(1, &second),
                    DpStrategy::Processor(DpStrategyProcessor::DependencyGraph),
                ]),
            ]),
        ]);
        let serialized = strategy.to_strategy_atom();
        assert_eq!(
            DpStrategy::parse(&serialized).expect("round-trip MU strategy"),
            strategy
        );
        let proof = crate::proving::solve_csr_dependency_pairs_with_kind_and_atomic_policy(
            &csr,
            crate::proving::CsrDependencyPairKind::MutermUnhiding,
            &DpOptions::default(),
            &strategy,
            None,
        )
        .expect("the complete retained MU-TERM/RTA08 pipeline must reconstruct");
        assert_eq!(
            proof.initial_pairs, 5,
            "the executable state must retain the native typed pairs"
        );
        assert!(proof.smt_solved);
        assert!(
            proof
                .component_proofs
                .iter()
                .all(|component| { component.proof_tree.is_none() || component.proved })
        );
        let root_proof = crate::proving::Proof::terminating(vec![
            crate::proving::ProofStep::ContextSensitiveDependencyPairProof {
                construction:
                    crate::proving::ContextSensitiveDependencyPairConstruction::MutermUnhiding,
                auxiliary_rules: muterm_innermost_unhiding_rules(&csr),
                proof: Box::new(proof),
            },
        ]);
        let cpf = crate::cert::write_cpf_csr(&csr, &root_proof, crate::cert::CpfMode::Cpf40)
            .expect("serialize the self-contained expanded CSR continuation");
        assert!(cpf.contains("<csrMutermTypedDependencyPairs>"));
        assert!(
            cpf.contains("<generalUsableRulesProc>") || cpf.contains("<localUsableRulesProc>"),
            "each retained reduction triple must carry a checked usable-rule boundary"
        );
        assert!(!cpf.contains("<expandedCsrProof>"));
    }

    #[test]
    fn improved_csr_pairs_include_hidden_terms_without_collapsing_pairs() {
        let rules = vec![
            RewriteRule::new(
                Term::app(
                    "f",
                    vec![Term::app("a", vec![]), Term::var("x"), Term::var("x")],
                ),
                Term::app(
                    "f",
                    vec![
                        Term::var("x"),
                        Term::app("b", vec![]),
                        Term::app("b", vec![]),
                    ],
                ),
            ),
            RewriteRule::new(Term::app("b", vec![]), Term::app("a", vec![])),
        ];
        let trs = Trs::new(None, BTreeSet::from([Variable::new("x")]), rules);
        let csr = CsrTrs::new(
            trs,
            ReplacementMap::new(BTreeMap::from([
                (Symbol::new("a"), BTreeSet::new()),
                (Symbol::new("b"), BTreeSet::new()),
                (Symbol::new("f"), BTreeSet::from([1])),
            ])),
        )
        .unwrap();
        let pairs = improved_csr_dependency_pairs(&csr);
        let unhiding_symbol = fresh_unhiding_symbol(csr.trs());

        assert!(!pairs.iter().any(|pair| {
            pair.lhs().root_symbol() != Some(&unhiding_symbol)
                && pair.rhs().root_symbol() == Some(&unhiding_symbol)
        }));
        assert!(pairs.iter().any(|pair| {
            pair.lhs().root_symbol() == Some(&unhiding_symbol)
                && pair.rhs().root_symbol() == Some(&Symbol::new("b#"))
        }));
    }

    #[test]
    fn refined_hiding_positions_exclude_active_rule_variables() {
        let csr = crate::parsing::parse_ari_cstrs(
            None,
            r#"
                (format CSTRS)
                (fun fact 1 :replacement-map (1))
                (fun if 3 :replacement-map (1))
                (fun zero 1 :replacement-map (1))
                (fun s 1 :replacement-map (1))
                (fun |0| 0 :replacement-map ())
                (fun prod 2 :replacement-map (1 2))
                (fun p 1 :replacement-map (1))
                (fun true 0 :replacement-map ())
                (fun false 0 :replacement-map ())
                (rule (fact X)
                    (if (zero X) (s |0|) (prod X (fact (p X)))))
                (rule (zero |0|) true)
                (rule (zero (s X)) false)
                (rule (p (s X)) X)
            "#,
        )
        .unwrap();
        let pairs = improved_csr_dependency_pairs(&csr);
        let projection_pairs = pairs
            .iter()
            .filter(|pair| {
                pair.lhs().root_symbol() == Some(&Symbol::new("__CSR_U0"))
                    && pair.rhs().root_symbol() == Some(&Symbol::new("__CSR_U0"))
            })
            .map(|pair| pair.as_rule().to_string())
            .collect::<BTreeSet<_>>();

        assert_eq!(
            projection_pairs,
            BTreeSet::from([
                "__CSR_U0(fact(x1)) -> __CSR_U0(x1)".to_string(),
                "__CSR_U0(prod(x1, x2)) -> __CSR_U0(x2)".to_string(),
            ])
        );

        let certificate_projection_pairs = certificate_improved_csr_dependency_pairs(&csr)
            .iter()
            .filter(|pair| {
                pair.lhs().root_symbol() == Some(&Symbol::new("__CSR_U0"))
                    && pair.rhs().root_symbol() == Some(&Symbol::new("__CSR_U0"))
            })
            .map(|pair| pair.as_rule().to_string())
            .collect::<BTreeSet<_>>();
        assert!(certificate_projection_pairs.contains("__CSR_U0(p(x1)) -> __CSR_U0(x1)"));
        assert!(certificate_projection_pairs.contains("__CSR_U0(prod(x1, x2)) -> __CSR_U0(x1)"));
    }

    #[test]
    fn verified_hiding_positions_allow_rhs_active_variables_frozen_in_the_lhs() {
        let rules = vec![RewriteRule::new(
            Term::app("f", vec![Term::var("x")]),
            Term::app(
                "pair",
                vec![
                    Term::app("box", vec![Term::app("h", vec![Term::var("x")])]),
                    Term::var("x"),
                ],
            ),
        )];
        let trs = Trs::new(None, BTreeSet::from([Variable::new("x")]), rules);
        let csr = CsrTrs::new(
            trs,
            ReplacementMap::new(BTreeMap::from([
                (Symbol::new("box"), BTreeSet::new()),
                (Symbol::new("f"), BTreeSet::new()),
                (Symbol::new("h"), BTreeSet::from([0])),
                (Symbol::new("pair"), BTreeSet::from([1])),
            ])),
        )
        .unwrap();

        let projection_pairs = improved_csr_dependency_pairs(&csr)
            .into_iter()
            .filter(|pair| {
                pair.lhs().root_symbol() == Some(&Symbol::new("__CSR_U0"))
                    && pair.rhs().root_symbol() == Some(&Symbol::new("__CSR_U0"))
            })
            .map(|pair| pair.as_rule().to_string())
            .collect::<BTreeSet<_>>();

        assert!(projection_pairs.contains("__CSR_U0(h(x1)) -> __CSR_U0(x1)"));
    }

    #[test]
    fn conservative_csr_dependency_pairs_unhide_inactive_calls() {
        let rules = vec![
            RewriteRule::new(
                Term::app("from", vec![Term::var("x")]),
                Term::app(
                    "cons",
                    vec![
                        Term::var("x"),
                        Term::app("from", vec![Term::app("s", vec![Term::var("x")])]),
                    ],
                ),
            ),
            RewriteRule::new(
                Term::app(
                    "take",
                    vec![
                        Term::var("n"),
                        Term::app("cons", vec![Term::var("x"), Term::var("xs")]),
                    ],
                ),
                Term::var("xs"),
            ),
        ];
        let csr = qcs_test_csr(
            rules,
            &[
                ("from", &[0]),
                ("cons", &[0]),
                ("s", &[0]),
                ("take", &[0, 1]),
            ],
        );

        let (conservative_csr, pairs) = conservative_csr_dependency_problem(&csr);

        assert!(pairs.iter().any(|pair| {
            pair.lhs().root_symbol() == Some(&Symbol::new("take#"))
                && pair.rhs().root_symbol() == Some(&Symbol::new("__CSR_U0"))
        }));
        assert!(pairs.iter().any(|pair| {
            pair.lhs().root_symbol() == Some(&Symbol::new("__CSR_U0"))
                && pair.rhs().root_symbol() == Some(&Symbol::new("from#"))
        }));
        assert!(conservative_csr.rules().iter().any(|rule| {
            rule.lhs().root_symbol() == Some(&Symbol::new("__CSR_U0"))
                && rule.rhs().root_symbol() == Some(&Symbol::new("from#"))
        }));
        assert!(conservative_csr.rules().iter().any(|rule| {
            rule.lhs().root_symbol() == Some(&Symbol::new("__CSR_U0"))
                && rule.rhs().root_symbol() == Some(&Symbol::new("__CSR_U0"))
                && rule.lhs().to_string().contains("cons")
        }));
    }

    #[test]
    fn conservative_csr_pairs_cover_active_calls_already_in_the_lhs() {
        let rules = vec![
            RewriteRule::new(
                Term::app("f", vec![Term::app("g", vec![Term::var("x")])]),
                Term::app("g", vec![Term::var("x")]),
            ),
            RewriteRule::new(
                Term::app("g", vec![Term::var("x")]),
                Term::app("f", vec![Term::var("x")]),
            ),
        ];
        let csr = qcs_test_csr(rules, &[("f", &[0]), ("g", &[0])]);

        assert!(!csr_dependency_pairs(&csr).iter().any(|pair| {
            pair.lhs().root_symbol() == Some(&Symbol::new("f#"))
                && pair.rhs().root_symbol() == Some(&Symbol::new("g#"))
        }));
        assert!(conservative_csr_dependency_pairs(&csr).iter().any(|pair| {
            pair.lhs().root_symbol() == Some(&Symbol::new("f#"))
                && pair.rhs().root_symbol() == Some(&Symbol::new("g#"))
        }));
    }

    #[test]
    fn conservative_csr_rejects_reduction_pairs_with_any_usable_rules() {
        let pair = DependencyPair::new_for_test(
            Term::app("f#", vec![Term::var("x")]),
            Term::app("f#", vec![Term::var("x")]),
        );
        let rule = RewriteRule::new(Term::app("f", vec![Term::var("x")]), Term::var("x"));
        let reduction = DpRemovalProof {
            pairs: vec![pair.clone()],
            usable_rules: vec![rule],
            uses_usable_rules: true,
            force_non_mono_usable_rules: false,
            strict_pair_indices: vec![0],
            strict_rules: Vec::new(),
            reduction_pair: DpReductionPairProof::Polynomial {
                interpretation: vec![("f#".to_string(), 0, vec![1])],
                backend: DpSearchBackend::Smt,
            },
        };
        let proof = DependencyPairProof {
            initial_pairs: 1,
            components: 1,
            removed_pairs: 1,
            usable_rules: 1,
            smt_attempted: true,
            smt_solved: true,
            strategy: RewriteStrategy::Full,
            pairs: vec![pair.clone()],
            component_proofs: vec![DpComponentProof {
                pairs: vec![pair],
                usable_rules: reduction.usable_rules.clone(),
                interpretation: None,
                backend: None,
                usable_rules_processor: None,
                innermost_lhss_processor: None,
                reductions: vec![reduction.clone()],
                final_acyclic_components: Vec::new(),
                proof_tree: Some(Box::new(DpProofTree::RedPair {
                    reduction,
                    proof: Box::new(DpProofTree::Empty),
                })),
                proved: true,
            }],
        };

        assert!(csr_dp_proof_requires_minimality(&proof));
    }

    #[test]
    fn csr_certification_preserves_minimality_across_nonmonotone_red_pair() {
        let pair = DependencyPair::new_for_test(
            Term::app("f#", vec![Term::var("x")]),
            Term::app("f#", vec![Term::var("x")]),
        );
        let rule = RewriteRule::new(Term::app("f", vec![Term::var("x")]), Term::var("x"));
        let csr = qcs_test_csr(vec![rule.clone()], &[("f", &[0])]);
        let nonmonotone = DpRemovalProof {
            pairs: vec![pair.clone()],
            usable_rules: vec![rule.clone()],
            uses_usable_rules: false,
            force_non_mono_usable_rules: false,
            strict_pair_indices: Vec::new(),
            strict_rules: Vec::new(),
            reduction_pair: DpReductionPairProof::Polynomial {
                interpretation: vec![("f#".to_string(), 0, vec![0])],
                backend: DpSearchBackend::Smt,
            },
        };
        let usable = DpRemovalProof {
            pairs: vec![pair],
            usable_rules: vec![rule.clone()],
            uses_usable_rules: true,
            force_non_mono_usable_rules: false,
            strict_pair_indices: vec![0],
            strict_rules: Vec::new(),
            reduction_pair: DpReductionPairProof::Polynomial {
                interpretation: vec![("f#".to_string(), 0, vec![1])],
                backend: DpSearchBackend::Smt,
            },
        };
        let tree = DpProofTree::RedPair {
            reduction: nonmonotone,
            proof: Box::new(DpProofTree::RedPair {
                reduction: usable,
                proof: Box::new(DpProofTree::Empty),
            }),
        };

        assert_eq!(
            csr_dp_tree_native_certification_issue(&tree, &csr, &[rule], true, false, true, false,),
            None
        );
    }

    fn qcs_test_csr(rules: Vec<RewriteRule>, map: &[(&str, &[usize])]) -> CsrTrs {
        let variables = rules
            .iter()
            .flat_map(|rule| rule.lhs().variables().into_iter())
            .collect();
        let trs = Trs::new(None, variables, rules);
        let replacement_map = ReplacementMap::new(
            map.iter()
                .map(|(symbol, positions)| {
                    (
                        Symbol::new(*symbol),
                        positions.iter().copied().collect::<BTreeSet<_>>(),
                    )
                })
                .collect(),
        );
        CsrTrs::new(trs, replacement_map).unwrap()
    }

    #[test]
    fn innermost_csr_sct_accepts_active_source_covered_targets() {
        let rule = RewriteRule::new(
            Term::app("f", vec![Term::app("s", vec![Term::var("x")])]),
            Term::app("f", vec![Term::var("x")]),
        );
        let csr = qcs_test_csr(vec![rule], &[("f", &[0]), ("s", &[0])]);
        let pair = DependencyPair::new_for_test(
            Term::app("f#", vec![Term::app("s", vec![Term::var("x")])]),
            Term::app("f#", vec![Term::var("x")]),
        );

        assert!(csr_innermost_sct_targets_are_source_covered(&csr, &[pair]));
    }

    #[test]
    fn innermost_csr_sct_rejects_targets_below_frozen_source_arguments() {
        let rule = RewriteRule::new(
            Term::app(
                "sel",
                vec![
                    Term::app("s", vec![Term::var("x")]),
                    Term::app("cons", vec![Term::var("y"), Term::var("z")]),
                ],
            ),
            Term::app("sel", vec![Term::var("x"), Term::var("z")]),
        );
        let csr = qcs_test_csr(vec![rule], &[("sel", &[0, 1]), ("s", &[]), ("cons", &[])]);
        let pair = DependencyPair::new_for_test(
            Term::app(
                "sel#",
                vec![
                    Term::app("s", vec![Term::var("x")]),
                    Term::app("cons", vec![Term::var("y"), Term::var("z")]),
                ],
            ),
            Term::app("sel#", vec![Term::var("x"), Term::var("z")]),
        );

        assert!(!csr_innermost_sct_targets_are_source_covered(&csr, &[pair]));
    }

    #[test]
    fn improved_csr_dp_accepts_mixed_size_change() {
        let csr = crate::parsing::parse_ari_cstrs(
            None,
            include_str!("../../tests/fixtures/csr_mixed_frozen_projection.ari"),
        )
        .unwrap();
        let options = DpOptions::default();
        let strategy = DpStrategy::parse("graph; subterm; size-change").unwrap();
        let proof = solve_improved_csr_dependency_pairs_with_strategy(
            &csr,
            &options,
            &strategy,
            Some(Instant::now() + Duration::from_secs(5)),
        )
        .unwrap();
        assert!(csr_dp_minimal_processors_are_mu_valid(&csr, &proof, true));
        assert!(csr_dp_minimal_processors_are_natively_certifiable(
            &csr, &proof, true
        ));
    }

    #[test]
    fn improved_csr_dp_accepts_all_marked_projection_subterm() {
        let rule = RewriteRule::new(
            Term::app("quote", vec![Term::app("s", vec![Term::var("x")])]),
            Term::app("quote", vec![Term::var("x")]),
        );
        let csr = qcs_test_csr(vec![rule], &[("quote", &[0]), ("s", &[0])]);
        let options = DpOptions::default();
        let strategy = DpStrategy::parse("graph; subterm").unwrap();

        let proof = solve_improved_csr_dependency_pairs_with_strategy(
            &csr,
            &options,
            &strategy,
            Some(Instant::now() + Duration::from_secs(5)),
        );

        // The proved mixed marked/unhiding projection theorem also covers an
        // all-marked SCC.  Fresh U roots are supported, not required.
        assert!(proof.is_some());
    }

    #[test]
    fn csr_size_change_requires_active_projection_and_nested_mu_subterm() {
        let rule = RewriteRule::new(
            Term::app("f", vec![Term::app("s", vec![Term::var("x")])]),
            Term::app("f", vec![Term::var("x")]),
        );
        let pair = DependencyPair::new_for_test(
            Term::app("f#", vec![Term::app("s", vec![Term::var("x")])]),
            Term::app("f#", vec![Term::var("x")]),
        );
        let graph = DpSizeChangeGraph {
            pair,
            edges: vec![DpSizeChangeEdge {
                left_position: 1,
                strict: true,
                right_position: 1,
            }],
        };

        let active = qcs_test_csr(vec![rule.clone()], &[("f", &[0]), ("s", &[0])]);
        assert!(csr_size_change_graph_is_mu_valid(&active, &graph));

        let nested_frozen = qcs_test_csr(vec![rule.clone()], &[("f", &[0]), ("s", &[])]);
        assert!(!csr_size_change_graph_is_mu_valid(&nested_frozen, &graph));

        let projection_frozen = qcs_test_csr(vec![rule], &[("f", &[]), ("s", &[0])]);
        assert!(!csr_size_change_graph_is_mu_valid(
            &projection_frozen,
            &graph
        ));
    }

    #[test]
    fn csr_subterm_projection_is_deferred_to_the_ceta_processor() {
        let rule = RewriteRule::new(
            Term::app(
                "length",
                vec![Term::app("cons", vec![Term::var("n"), Term::var("l")])],
            ),
            Term::app("U11", vec![Term::var("n"), Term::var("l")]),
        );
        let csr = qcs_test_csr(
            vec![rule],
            &[("length", &[0]), ("cons", &[0]), ("U11", &[0])],
        );
        let pair = DependencyPair::new_for_test(
            Term::app(
                "length#",
                vec![Term::app("cons", vec![Term::var("n"), Term::var("l")])],
            ),
            Term::app("U11#", vec![Term::var("n"), Term::var("l")]),
        );
        let graph = DpSizeChangeGraph {
            pair: pair.clone(),
            edges: vec![DpSizeChangeEdge {
                left_position: 1,
                strict: true,
                right_position: 2,
            }],
        };
        assert!(!csr_size_change_graph_is_mu_valid(&csr, &graph));

        let tree = DpProofTree::Subterm {
            projection: vec![
                DpSubtermProjectionEntry {
                    symbol: Symbol::new("length#"),
                    arity: 1,
                    position: 1,
                },
                DpSubtermProjectionEntry {
                    symbol: Symbol::new("U11#"),
                    arity: 2,
                    position: 2,
                },
            ],
            strict_pairs: vec![pair],
            graphs: vec![graph],
            proof: Box::new(DpProofTree::Empty),
        };
        // Ferrum cannot decide this from the original replacement map alone:
        // improved CS-DPs may contain a fresh unhiding symbol whose selected
        // argument is handled by the dedicated CeTA processor.  Keep the
        // structural traversal permissive and let certificate checking decide
        // whether the concrete projection satisfies that processor.
        assert!(csr_dp_tree_is_mu_valid(&csr, &tree, true));
    }

    #[test]
    fn improved_csr_subterm_rejects_ex6_frozen_cons_projection() {
        let csr = qcs_test_csr(
            vec![
                RewriteRule::new(
                    Term::app(
                        "sel",
                        vec![
                            Term::app("s", vec![Term::var("x")]),
                            Term::app("cons", vec![Term::var("y"), Term::var("z")]),
                        ],
                    ),
                    Term::app("sel", vec![Term::var("x"), Term::var("z")]),
                ),
                RewriteRule::new(
                    Term::app(
                        "sel1",
                        vec![
                            Term::app("|0|", vec![]),
                            Term::app("cons", vec![Term::var("x"), Term::var("z")]),
                        ],
                    ),
                    Term::app("quote", vec![Term::var("x")]),
                ),
            ],
            &[
                ("sel", &[0, 1]),
                ("s", &[0]),
                ("cons", &[0]),
                ("sel1", &[0, 1]),
                ("quote", &[]),
            ],
        );
        let pairs = vec![
            DependencyPair::new_for_test(
                Term::app(
                    "quote#",
                    vec![Term::app("sel", vec![Term::var("x"), Term::var("z")])],
                ),
                Term::app("sel1#", vec![Term::var("x"), Term::var("z")]),
            ),
            DependencyPair::new_for_test(
                Term::app("quote#", vec![Term::app("s", vec![Term::var("x")])]),
                Term::app("quote#", vec![Term::var("x")]),
            ),
            DependencyPair::new_for_test(
                Term::app(
                    "sel1#",
                    vec![
                        Term::app("|0|", vec![]),
                        Term::app("cons", vec![Term::var("x"), Term::var("z")]),
                    ],
                ),
                Term::app("quote#", vec![Term::var("x")]),
            ),
            DependencyPair::new_for_test(
                Term::app(
                    "sel1#",
                    vec![
                        Term::app("s", vec![Term::var("x")]),
                        Term::app("cons", vec![Term::var("y"), Term::var("z")]),
                    ],
                ),
                Term::app("sel1#", vec![Term::var("x"), Term::var("z")]),
            ),
        ];
        let frozen_second = BTreeMap::from([(Symbol::new("quote#"), 0), (Symbol::new("sel1#"), 1)]);
        let incompatible_first =
            BTreeMap::from([(Symbol::new("quote#"), 0), (Symbol::new("sel1#"), 0)]);

        assert!(
            subterm_strict_pairs_for_projection_with_csr(&pairs, &frozen_second, Some(&csr))
                .is_none()
        );
        assert!(
            subterm_strict_pairs_for_projection_with_csr(&pairs, &incompatible_first, Some(&csr))
                .is_none()
        );
    }

    #[test]
    fn qcs_usable_rules_ignore_inactive_arguments() {
        let g_rule = RewriteRule::new(
            Term::app("g", vec![Term::var("x")]),
            Term::app("box", vec![Term::app("g", vec![Term::var("x")])]),
        );
        let csr = qcs_test_csr(vec![g_rule], &[("box", &[]), ("g", &[0])]);
        let pair = DependencyPair::new_for_test(
            Term::app("f#", vec![Term::var("x")]),
            Term::app("box", vec![Term::app("g", vec![Term::var("x")])]),
        );

        assert!(qcs_usable_rules(&csr, &[pair]).is_empty());
    }

    #[test]
    fn csr_subterm_rejects_descent_through_a_frozen_constructor_argument() {
        let csr = qcs_test_csr(
            vec![
                RewriteRule::new(
                    Term::app("zeros", vec![]),
                    Term::app(
                        "cons",
                        vec![Term::app("|0|", vec![]), Term::app("zeros", vec![])],
                    ),
                ),
                RewriteRule::new(
                    Term::app("length", vec![Term::app("nil", vec![])]),
                    Term::app("|0|", vec![]),
                ),
                RewriteRule::new(
                    Term::app("u", vec![Term::app("tt", vec![]), Term::var("l")]),
                    Term::var("l"),
                ),
            ],
            &[("cons", &[0]), ("length", &[0]), ("u", &[0])],
        );
        let pairs = vec![
            DependencyPair::new_for_test(
                Term::app("u#", vec![Term::app("tt", vec![]), Term::var("l")]),
                Term::app("length#", vec![Term::var("l")]),
            ),
            DependencyPair::new_for_test(
                Term::app(
                    "length#",
                    vec![Term::app("cons", vec![Term::var("n"), Term::var("l")])],
                ),
                Term::app("u#", vec![Term::app("guard", vec![]), Term::var("l")]),
            ),
        ];

        assert!(
            synthesize_projection_subterm_criterion(
                &pairs,
                &DpOptions::default(),
                None,
                Some(&csr),
            )
            .is_none(),
            "zeros -> cons(0,zeros) can undo this apparent tail descent"
        );
    }

    #[test]
    fn qcs_usable_rules_are_an_explicit_residual_processor() {
        let trs = Trs::new(
            None,
            BTreeSet::from([Variable::new("x")]),
            vec![RewriteRule::new(
                Term::app("g", vec![Term::var("x")]),
                Term::app("h", vec![Term::app("s", vec![Term::var("x")])]),
            )],
        );
        let csr = CsrTrs::new(
            trs,
            ReplacementMap::new(BTreeMap::from([
                (Symbol::new("g"), BTreeSet::from([0])),
                (Symbol::new("h"), BTreeSet::new()),
                (Symbol::new("s"), BTreeSet::from([0])),
            ])),
        )
        .unwrap();
        let pairs = vec![DependencyPair::new_for_test(
            Term::app("h#", vec![Term::app("s", vec![Term::var("x")])]),
            Term::app("h#", vec![Term::var("x")]),
        )];
        let options = DpOptions::default();
        let strategy = DpStrategy::parse("usable-rules").unwrap();
        let expected_usable = qcs_certificate_usable_rules(&csr, &pairs);
        assert_ne!(expected_usable.as_slice(), csr.rules());

        let (proof, residuals) = crate::proving::probe_csr_dp_atom(
            &csr,
            pairs,
            Some(csr.rules().to_vec()),
            true,
            "improved",
            "context-sensitive",
            true,
            &options,
            &strategy,
            None,
        )
        .expect("the explicit usable-rule processor should return its residual");

        assert!(proof.is_none());
        assert_eq!(residuals.len(), 1);
        let ProblemState::DependencyPairs(residual) = &residuals[0] else {
            panic!("expected CSR-DP residual state");
        };
        let CpfInputProblem::CsrDp {
            active_rules,
            graph_rules,
            ..
        } = parse_cpf_input(None, &dp_state_input_cpf(residual))
            .expect("parse QCS usable-rule residual")
        else {
            panic!("expected CSR-DP residual");
        };
        assert_eq!(active_rules, Some(expected_usable.clone()));
        assert_eq!(
            graph_rules,
            Some(expected_usable),
            "usable-rule residuals must preserve the same reduced graph context"
        );
    }

    #[test]
    fn csr_u3_dispatch_accepts_marked_or_single_fresh_unhiding_roots() {
        let csr = qcs_test_csr(Vec::new(), &[]);
        let marked = DependencyPair::new_for_test(
            Term::app("f#", vec![Term::var("x")]),
            Term::app("g#", vec![Term::var("x")]),
        );
        let unhiding = DependencyPair::new_for_test(
            Term::app("__CSR_U0", vec![Term::app("f", vec![Term::var("x")])]),
            Term::app("__CSR_U0", vec![Term::var("x")]),
        );

        assert!(csr_pairs_have_marked_roots(std::slice::from_ref(&marked)));
        assert!(!csr_pairs_have_marked_roots(&[
            marked.clone(),
            unhiding.clone()
        ]));
        assert!(csr_pairs_have_marked_or_fresh_unhiding_roots(
            &csr,
            &[marked.clone(), unhiding.clone()]
        ));
        assert!(!csr_pairs_have_mixed_marked_fresh_unhiding_roots(
            &csr,
            std::slice::from_ref(&marked)
        ));
        assert!(csr_pairs_have_mixed_marked_fresh_unhiding_roots(
            &csr,
            &[marked.clone(), unhiding]
        ));

        let unrelated_unmarked = DependencyPair::new_for_test(
            Term::app("other", vec![Term::var("x")]),
            Term::app("g#", vec![Term::var("x")]),
        );
        assert!(!csr_pairs_have_marked_or_fresh_unhiding_roots(
            &csr,
            &[marked, unrelated_unmarked]
        ));
    }

    #[test]
    fn improved_csr_dps_use_the_verified_u3_extension() {
        assert!(csr_construction_uses_u3(CsrDpConstruction::Native));
        assert!(csr_construction_uses_u3(CsrDpConstruction::Improved));
        assert!(!csr_construction_uses_u3(CsrDpConstruction::Safe));
        assert!(!csr_construction_uses_u3(CsrDpConstruction::Rta08));
    }

    #[test]
    fn innermost_label_does_not_weaken_csr_u3_validation() {
        let g_rule = RewriteRule::new(
            Term::app("g", vec![Term::var("x")]),
            Term::app("a", Vec::new()),
        );
        let box_rule = RewriteRule::new(
            Term::app("box", vec![Term::var("x")]),
            Term::app("box", vec![Term::var("x")]),
        );
        let full_csr = qcs_test_csr(
            vec![g_rule, box_rule],
            &[("box", &[]), ("g", &[0]), ("a", &[])],
        );
        let innermost_trs = Trs::new_with_strategy(
            None,
            full_csr.trs().variables().clone(),
            full_csr.rules().to_vec(),
            RewriteStrategy::Innermost,
        );
        let csr = CsrTrs::new(innermost_trs, full_csr.replacement_map().clone()).unwrap();
        let unhiding = fresh_unhiding_symbol(csr.trs());
        let pair = DependencyPair::new_for_test(
            Term::app(
                "f#",
                vec![Term::app("box", vec![Term::app("g", vec![Term::var("x")])])],
            ),
            Term::app(unhiding.as_str(), vec![Term::var("x")]),
        );
        let reduction = DpRemovalProof {
            pairs: vec![pair],
            usable_rules: Vec::new(),
            uses_usable_rules: true,
            force_non_mono_usable_rules: false,
            strict_pair_indices: vec![0],
            strict_rules: Vec::new(),
            reduction_pair: DpReductionPairProof::Polynomial {
                interpretation: Vec::new(),
                backend: DpSearchBackend::Smt,
            },
        };
        let tree = DpProofTree::RedPair {
            reduction,
            proof: Box::new(DpProofTree::Empty),
        };

        let issue = csr_dp_tree_native_certification_issue(
            &tree,
            &csr,
            csr.rules(),
            true,
            false,
            true,
            false,
        )
        .expect("empty usable rules must not pass the full-CSR U3 obligation");
        assert!(
            issue.contains("U3 usable-rule set is not closed"),
            "{issue}"
        );
    }

    #[test]
    fn qcs_usable_rules_follow_active_calls_and_rule_closure() {
        let g_rule = RewriteRule::new(
            Term::app("g", vec![Term::app("a", vec![])]),
            Term::app("h", vec![Term::app("a", vec![])]),
        );
        let h_rule = RewriteRule::new(Term::app("h", vec![Term::var("x")]), Term::app("a", vec![]));
        let csr = qcs_test_csr(
            vec![g_rule.clone(), h_rule.clone()],
            &[("g", &[0]), ("h", &[0]), ("a", &[])],
        );
        let pair = DependencyPair::new_for_test(
            Term::app("g#", vec![Term::var("x")]),
            Term::app("g#", vec![Term::app("g", vec![Term::app("a", vec![])])]),
        );

        assert_eq!(qcs_usable_rules(&csr, &[pair]), vec![g_rule, h_rule]);
    }

    #[test]
    fn csr_u3_usable_rules_seed_pair_rhs_and_inactive_pair_lhs() {
        let g_rule = RewriteRule::new(
            Term::app("g", vec![Term::var("x")]),
            Term::app("h", vec![Term::var("x")]),
        );
        let h_rule = RewriteRule::new(Term::app("h", vec![Term::var("x")]), Term::app("a", vec![]));
        let k_rule = RewriteRule::new(Term::app("k", vec![Term::var("x")]), Term::app("a", vec![]));
        let z_rule = RewriteRule::new(Term::app("z", vec![Term::var("x")]), Term::app("a", vec![]));
        let csr = qcs_test_csr(
            vec![g_rule.clone(), h_rule.clone(), k_rule.clone(), z_rule],
            &[
                ("g", &[0]),
                ("h", &[0]),
                ("k", &[0]),
                ("z", &[0]),
                ("a", &[]),
            ],
        );
        let pair = DependencyPair::new_for_test(
            Term::app(
                "f#",
                vec![Term::app("box", vec![Term::app("k", vec![Term::var("x")])])],
            ),
            Term::app("f#", vec![Term::app("g", vec![Term::var("x")])]),
        );

        assert_eq!(
            csr_u3_usable_rules(&csr, csr.rules(), &[pair]),
            vec![g_rule, h_rule, k_rule]
        );
    }

    #[test]
    fn csr_u3_usable_rules_seed_inactive_subterms_of_every_rule_rhs() {
        let z_rule = RewriteRule::new(Term::app("z", vec![Term::var("x")]), Term::app("a", vec![]));
        let dormant_rule = RewriteRule::new(
            Term::app("d", vec![Term::var("x")]),
            Term::app("box", vec![Term::app("z", vec![Term::var("x")])]),
        );
        let csr = qcs_test_csr(
            vec![z_rule.clone(), dormant_rule.clone()],
            &[("d", &[0]), ("z", &[0]), ("a", &[])],
        );
        let pair = DependencyPair::new_for_test(
            Term::app("f#", vec![Term::var("x")]),
            Term::app("f#", vec![Term::var("x")]),
        );

        assert_eq!(
            csr_u3_usable_rules(&csr, csr.rules(), std::slice::from_ref(&pair)),
            vec![z_rule]
        );
        assert!(csr_u3_usable_rules(&csr, &[dormant_rule], std::slice::from_ref(&pair)).is_empty());
    }

    #[test]
    fn rta_csr_usable_rules_exclude_inactive_pair_rhs_calls() {
        let q_rule = RewriteRule::new(
            Term::app(
                "q",
                vec![Term::app("box", vec![Term::app("f", vec![Term::var("x")])])],
            ),
            Term::app("a", vec![]),
        );
        let csr = qcs_test_csr(
            vec![q_rule.clone()],
            &[("f", &[0]), ("box", &[]), ("q", &[0]), ("a", &[])],
        );
        let pair = DependencyPair::new_for_test(
            Term::app("f#", vec![Term::var("x")]),
            Term::app(
                "f#",
                vec![Term::app("box", vec![Term::app("q", vec![Term::var("x")])])],
            ),
        );

        assert!(
            rta_context_sensitive_usable_rules(&csr, csr.rules(), std::slice::from_ref(&pair))
                .is_empty()
        );
        assert_eq!(
            csr_u3_usable_rules(&csr, csr.rules(), std::slice::from_ref(&pair)),
            vec![q_rule]
        );
    }

    #[test]
    fn rta_csr_usable_rules_include_hidden_and_inactive_lhs_dependencies() {
        let h_rule = RewriteRule::new(
            Term::app(
                "h",
                vec![Term::app(
                    "box",
                    vec![Term::app("k", vec![Term::app("f", vec![Term::var("x")])])],
                )],
            ),
            Term::app("a", vec![]),
        );
        let k_rule = RewriteRule::new(Term::app("k", vec![Term::var("x")]), Term::app("a", vec![]));
        let hidden_rule = RewriteRule::new(
            Term::app("d", vec![Term::var("x")]),
            Term::app("box", vec![Term::app("z", vec![Term::var("x")])]),
        );
        let z_rule = RewriteRule::new(Term::app("z", vec![Term::var("x")]), Term::app("a", vec![]));
        let csr = qcs_test_csr(
            vec![h_rule.clone(), k_rule.clone(), hidden_rule, z_rule.clone()],
            &[
                ("f", &[0]),
                ("h", &[0]),
                ("box", &[]),
                ("k", &[0]),
                ("d", &[0]),
                ("z", &[0]),
                ("a", &[]),
            ],
        );
        let pair = DependencyPair::new_for_test(
            Term::app("f#", vec![Term::var("x")]),
            Term::app("f#", vec![Term::app("h", vec![Term::var("x")])]),
        );

        assert_eq!(
            rta_context_sensitive_usable_rules(&csr, csr.rules(), &[pair]),
            vec![h_rule, k_rule, z_rule]
        );
    }

    #[test]
    fn rta_csr_ex3_uses_collapsing_pairs_and_general_usable_rules() {
        let csr = crate::parsing::parse_ari_cstrs(
            None,
            include_str!("../../tests/fixtures/csr_ex3_2_luc97.ari"),
        )
        .unwrap();
        let pairs = rta_csr_dependency_pairs(&csr);
        let usable = rta_context_sensitive_usable_rules(&csr, csr.rules(), &pairs);

        assert!(pairs.iter().any(|pair| matches!(pair.rhs(), Term::Var(_))));
        assert!(usable.iter().all(|rule| csr.rules().contains(rule)));
        assert_eq!(pairs.len(), 4);
        assert_eq!(usable.len(), 9);
    }

    #[test]
    fn rta_csr_collapsing_case_adds_theorem_one_weak_obligations() {
        let rule = RewriteRule::new(
            Term::app("f", vec![Term::app("box", vec![Term::var("x")])]),
            Term::var("x"),
        );
        let g_rule = RewriteRule::new(Term::app("g", vec![Term::var("x")]), Term::app("a", vec![]));
        let csr = qcs_test_csr(
            vec![rule, g_rule],
            &[("f", &[0]), ("g", &[0]), ("box", &[]), ("a", &[])],
        );
        let mut pairs = rta_csr_dependency_pairs(&csr);
        pairs.push(DependencyPair::new_for_test(
            Term::app("f#", vec![Term::var("x")]),
            Term::app("g#", vec![Term::var("x")]),
        ));
        let noncollapsing_component = pairs
            .iter()
            .filter(|pair| matches!(pair.rhs(), Term::App { .. }))
            .cloned()
            .collect::<Vec<_>>();
        let weak = rta_reduction_pair_weak_rules(&csr, &[], &noncollapsing_component);

        assert!(pairs.iter().any(|pair| matches!(pair.rhs(), Term::Var(_))));
        assert!(weak.iter().any(|obligation| {
            obligation.lhs().root_symbol() == Some(&Symbol::new("f"))
                && obligation.rhs() == &Term::var("csr_arg_0")
        }));
        assert!(weak.iter().any(|obligation| {
            obligation.lhs().root_symbol() == Some(&Symbol::new("f"))
                && obligation.rhs().root_symbol() == Some(&Symbol::new("f#"))
        }));
        assert!(weak.iter().any(|obligation| {
            obligation.lhs().root_symbol() == Some(&Symbol::new("f#"))
                && obligation.rhs() == &Term::var("csr_arg_0")
        }));
        assert!(
            weak.iter().any(|obligation| {
                obligation.lhs().root_symbol() == Some(&Symbol::new("g#"))
                    && obligation.rhs() == &Term::var("csr_arg_0")
            }),
            "SCC-local processing must retain sibling marked projections"
        );
        assert!(weak.iter().any(|obligation| {
            obligation.lhs().root_symbol() == Some(&Symbol::new("g"))
                && obligation.rhs().root_symbol() == Some(&Symbol::new("g#"))
        }));
        assert_eq!(
            weak.iter()
                .filter(|obligation| {
                    obligation
                        .lhs()
                        .root_symbol()
                        .is_some_and(|symbol| symbol.as_str().starts_with("__CSR_PI"))
                })
                .count(),
            2
        );
    }

    #[test]
    fn rta_csr_collapsing_case_is_solved_by_one_constrained_sat_query() {
        let csr = crate::parsing::parse_ari_cstrs(
            None,
            "(format CSTRS)\n\
             (fun f 1 :replacement-map (1))\n\
             (fun box 1 :replacement-map ())\n\
             (rule (f (box X)) X)\n",
        )
        .unwrap();
        let options = DpOptions::default();
        let strategy = DpStrategy::Processor(DpStrategyProcessor::SatPolynomial {
            max_constant: 2,
            max_coefficient: 2,
            max_symbols: None,
            max_arity: None,
        });

        let proof = crate::proving::solve_csr_dependency_pairs_with_kind_and_atomic_policy(
            &csr,
            crate::proving::CsrDependencyPairKind::Rta08,
            &options,
            &strategy,
            None,
        )
        .unwrap();

        assert!(
            csr_rta08_proof_has_component_first_reduction_pairs(&csr, &proof),
            "unexpected proof: {proof:?}"
        );
        assert!(csr_rta08_proof_is_certifiable(&csr, &proof));
        let mut recursively_decomposed = proof.clone();
        let terminal = recursively_decomposed.component_proofs[0].clone();
        recursively_decomposed.component_proofs = vec![component_proof_from_tree(
            recursively_decomposed.pairs.clone(),
            DpProofTree::DepGraph {
                components: vec![terminal],
            },
        )];
        assert!(csr_rta08_proof_is_certifiable(
            &csr,
            &recursively_decomposed
        ));
        let mut incomplete = proof.clone();
        let Some(DpProofTree::RedPair { reduction, .. }) =
            incomplete.component_proofs[0].proof_tree.as_deref_mut()
        else {
            panic!("expected one RTA08 reduction-pair processor");
        };
        reduction.strict_pair_indices.pop();
        assert!(
            csr_rta08_proof_is_certifiable(&csr, &incomplete),
            "a weak collapsing RTA08 pair is closed by the certified marking descent"
        );
        let Some(DpProofTree::RedPair { reduction, proof }) =
            proof.component_proofs[0].proof_tree.as_deref()
        else {
            panic!("expected one RTA08 reduction-pair processor");
        };
        assert!(matches!(proof.as_ref(), DpProofTree::Empty));
        assert!(reduction.strict_rules.iter().any(is_rta_marking_obligation));
        assert!(
            reduction
                .pairs
                .iter()
                .all(|pair| matches!(pair.rhs(), Term::Var(_)))
        );
    }

    #[test]
    fn rta_csr_marking_obligations_are_encoded_by_rational_matrix_path_order_and_kbo() {
        let csr = crate::parsing::parse_ari_cstrs(
            None,
            include_str!("../../tests/fixtures/csr_rta08_collapsing.ari"),
        )
        .unwrap();
        let max_options = DpOptions::default();
        let max_strategy = DpStrategy::Processor(DpStrategyProcessor::MaxPolynomial {
            max_constant: 2,
            max_coefficient: 2,
            alternatives: 1,
            max_symbols: None,
            max_arity: None,
        });
        let max_proof = solve_csr_root_with_strategy(&csr, &max_options, &max_strategy, None)
            .expect("failed max-polynomial attempt remains inspectable");
        assert!(
            !csr_rta08_proof_has_component_first_reduction_pairs(&csr, &max_proof),
            "max-polynomial RTA08 positives require an exact extra-obligation validator"
        );

        let processors = [
            DpStrategyProcessor::RationalPolynomial {
                max_constant: 2,
                max_coefficient: 2,
                max_symbols: None,
                max_arity: None,
                denominator: 2,
                delta_denominator: 2,
            },
            DpStrategyProcessor::MatrixInterpretation {
                dimension: 1,
                max_constant: 2,
                max_coefficient: 1,
                min_nonzero: None,
                max_nonzero: None,
                max_nonzero_constants: None,
                max_nonzero_per_row: None,
                max_symbols: None,
                max_arity: None,
            },
            DpStrategyProcessor::PathOrder,
            DpStrategyProcessor::Kbo {
                max_weight: 2,
                max_symbols: KBO_SMT_SYMBOL_LIMIT,
            },
        ];

        for processor in processors {
            let options = DpOptions::default();
            let strategy = DpStrategy::Processor(processor.clone());
            let proof = crate::proving::solve_csr_dependency_pairs_with_kind_and_atomic_policy(
                &csr,
                crate::proving::CsrDependencyPairKind::Rta08,
                &options,
                &strategy,
                None,
            )
            .unwrap_or_else(|| panic!("RTA08 processor failed: {processor:?}"));
            assert!(
                csr_rta08_proof_has_component_first_reduction_pairs(&csr, &proof),
                "unexpected {processor:?} proof: {proof:?}"
            );
            let Some(DpProofTree::RedPair { reduction, proof }) =
                proof.component_proofs[0].proof_tree.as_deref()
            else {
                panic!("expected one RTA08 reduction-pair processor: {processor:?}");
            };
            assert!(matches!(proof.as_ref(), DpProofTree::Empty));
            assert!(
                reduction.strict_rules.iter().any(is_rta_marking_obligation),
                "missing strict marking rule for {processor:?}: {reduction:?}"
            );
        }
    }

    #[test]
    fn exintrod_rta08_external_quadratic_witness_needs_certified_usable_rules() {
        let csr = crate::parsing::parse_ari_cstrs(
            None,
            include_str!("../../tests/fixtures/csr_exintrod_zan97.ari"),
        )
        .unwrap();
        let zero = |arity| vec![vec![0; arity]; arity];
        let interpretation = vec![
            ("add".into(), 0, vec![0, 0], zero(2)),
            ("fact".into(), 0, vec![1], zero(1)),
            ("if".into(), 0, vec![0, 0, 0], zero(3)),
            ("p".into(), 0, vec![1], zero(1)),
            ("prod".into(), 4, vec![2, 0], vec![vec![0, 4], vec![0, 0]]),
            ("zero".into(), 0, vec![0], vec![vec![1]]),
            ("|0|".into(), 4, vec![], vec![]),
            ("false".into(), 1, vec![], vec![]),
            ("s".into(), 2, vec![4], zero(1)),
            ("true".into(), 4, vec![], vec![]),
            ("add#".into(), 0, vec![0, 0], zero(2)),
            ("fact#".into(), 4, vec![4], vec![vec![4]]),
            (
                "if#".into(),
                0,
                vec![1, 0, 2],
                vec![vec![0, 1, 0], vec![0, 0, 0], vec![0, 0, 0]],
            ),
            ("p#".into(), 0, vec![0], zero(1)),
            ("prod#".into(), 0, vec![0, 0], zero(2)),
            ("zero#".into(), 0, vec![0], zero(1)),
            ("__CSR_PI0".into(), 0, vec![2, 2], zero(2)),
        ];
        let interpretations = interpretation
            .into_iter()
            .map(|(name, constant, linear, quadratic)| {
                (
                    name,
                    NaturalPolynomial {
                        constant,
                        linear,
                        quadratic,
                    },
                )
            })
            .collect::<BTreeMap<_, _>>();
        let pairs = rta_csr_dependency_pairs(&csr);
        let hard = pairs
            .iter()
            .filter(|pair| {
                matches!(
                    pair.lhs().root_symbol().map(Symbol::as_str),
                    Some("fact#" | "if#")
                )
            })
            .cloned()
            .collect::<Vec<_>>();
        let usable = rta_context_sensitive_usable_rules(&csr, csr.rules(), &hard);
        let weak = rta_reduction_pair_weak_rules(&csr, &usable, &hard);
        assert!(
            checked_component_removal_by_rational_natural_polynomial_with_required_strict_rules(
                &hard,
                &weak,
                &interpretations,
                2,
                1,
                DpSearchBackend::Smt,
                &weak
                    .iter()
                    .enumerate()
                    .filter_map(|(index, rule)| is_rta_marking_obligation(rule).then_some(index))
                    .collect::<Vec<_>>(),
            )
            .is_none(),
            "the external usable-rule witness must not be applied to the stronger full-RTA08 obligation"
        );

        let expanded =
            muterm_expand_dependency_pairs(&hard, &muterm_innermost_unhiding_rules(&csr));
        let external_usable = csr
            .rules()
            .iter()
            .filter(|rule| {
                matches!(
                    rule.lhs().root_symbol().map(Symbol::as_str),
                    Some("p" | "zero")
                )
            })
            .cloned()
            .collect::<Vec<_>>();
        let mut typed_weak = external_usable.clone();
        typed_weak.extend(muterm_innermost_unhiding_rules(&csr));
        let typed_component = hard
            .iter()
            .filter(|pair| {
                pair.rhs()
                    .root_symbol()
                    .is_none_or(|symbol| symbol.as_str() != "zero#")
            })
            .cloned()
            .collect::<Vec<_>>();
        let typed = muterm_exintrod_zan97_rational_candidate(&typed_component, &typed_weak, &[])
            .expect("the retained ExIntrod model must orient the typed MU-TERM component");
        assert!(!typed.strict_pair_indices.is_empty());
        assert!(
            checked_component_removal_by_rational_natural_polynomial_with_required_strict_rules(
                &expanded,
                &external_usable,
                &interpretations,
                2,
                1,
                DpSearchBackend::Smt,
                &[],
            )
            .is_some(),
            "the same witness should apply after the collapsing component is explicitly expanded"
        );
    }

    #[test]
    fn native_rational_quadratic_preserves_fixed_rules_and_roundtrips() {
        let strategy = DpStrategy::parse("rat-quadratic-poly(max-constant=2,max-coefficient=2,max-symbols=8,max-arity=2,denominator=2,delta-denominator=2,solver=z3)").unwrap();
        let DpStrategy::Processor(processor) = strategy else { panic!("expected processor"); };
        assert!(matches!(processor, DpStrategyProcessor::RationalQuadraticPolynomial { .. }));
        let atom = DpStrategy::Processor(processor.clone()).to_strategy_atom();
        assert_eq!(DpStrategy::parse(&atom).unwrap().to_strategy_atom(), atom);
        let pairs = vec![DependencyPair::new_for_test(
            Term::app("f#", vec![Term::app("s", vec![Term::var("x")])]),
            Term::app("f#", vec![Term::var("x")]))];
        let options = DpOptions::default();
        let cancellation = DpStrategyCancellation::default();
        let trs = Trs::new(None, Default::default(), vec![]);
        let mut context = ReductionPairContext::new(&trs, &pairs, None, false,
            true, &options, None, Some(Instant::now() + Duration::from_secs(10)), &cancellation);
        context.fixed_usable_rules = true;
        let removal = synthesize_component_removal_by_processor(&processor, &context)
            .expect("direct native synthesis should find descent");
        assert_eq!(removal.strict_pair_indices, vec![0]);
        context.usable_rules.push(RewriteRule::new(
            Term::app("s", vec![Term::var("x")]),
            Term::app("s", vec![Term::app("s", vec![Term::var("x")])])));
        assert!(synthesize_component_removal_by_processor(&processor, &context).is_none());
    }

    #[test]
    fn native_wpo_and_sparse_quadratic_parameters_roundtrip() {
        for atom in [
            "wpo-max(max-constant=4,max-coefficient=1,max-symbols=32,max-arity=3,alternatives=2)",
            "rat-quadratic-poly(max-constant=4,max-coefficient=4,denominator=2,delta-denominator=2,solver=z3,coefficients=0+1+2+4,quadratic-terms=1)",
        ] {
            let strategy = DpStrategy::parse(atom).unwrap();
            let canonical = strategy.to_strategy_atom();
            assert_eq!(DpStrategy::parse(&canonical).unwrap().to_strategy_atom(), canonical);
        }
        for domain in ["1+2", "0+-1", "0+foo"] {
            assert!(DpStrategy::parse(&format!("rat-quadratic-poly(max-constant=4,max-coefficient=4,denominator=2,delta-denominator=2,coefficients={domain})")).is_err());
        }
    }

    #[test]
    fn exact_rational_natural_polynomial_rechecks_quadratic_witness() {
        let pairs = vec![DependencyPair::new_for_test(
            Term::app("f#", vec![Term::app("s", vec![Term::var("x")])]),
            Term::app("f#", vec![Term::var("x")]),
        )];
        let interpretation = vec![
            ("f#".into(), 0, vec![2], vec![vec![1]]),
            ("s".into(), 2, vec![2], vec![vec![0]]),
        ];
        let cancellation = DpStrategyCancellation::default();
        let options = DpOptions::default();
        let trs = Trs::new(None, Default::default(), Vec::new());
        let context = ReductionPairContext::new(
            &trs,
            &pairs,
            None,
            false,
            true,
            &options,
            None,
            None,
            &cancellation,
        );
        let removal = synthesize_component_removal_by_processor(
            &DpStrategyProcessor::ExactRationalNaturalPolynomial {
                denominator: 2,
                delta: 1,
                interpretation,
            },
            &context,
        )
        .expect("the exact quadratic witness should be independently accepted");
        assert_eq!(removal.strict_pair_indices, vec![0]);
    }

    #[test]
    fn exact_rational_validation_does_not_overflow_i64_denominators() {
        let half = Rational::new(1, 2);
        let mut value = Rational::one();
        for _ in 0..80 {
            value = value.mul(half);
        }
        assert!(value.ge(Rational::zero()));
        assert!(value.add(value).ge(value));
    }

    #[test]
    fn smt_integer_model_parser_skips_expression_valued_auxiliaries() {
        let values = parse_smt_values(
            "sat\n(model\n\
             (define-fun aux () Int (+ w_f 1))\n\
             (define-fun r_f () Int 2)\n\
             (define-fun w_f () Int 1)\n\
             (define-fun af_f () Int 0))\n",
        )
        .unwrap();

        assert_eq!(values.get("r_f"), Some(&2));
        assert_eq!(values.get("w_f"), Some(&1));
        assert_eq!(values.get("af_f"), Some(&0));
        assert!(!values.contains_key("aux"));
    }

    #[test]
    fn qcs_usable_rules_use_ecap_mu_when_matching_rule_roots() {
        let g_rule = RewriteRule::new(Term::app("g", vec![Term::var("x")]), Term::app("a", vec![]));
        let f_rule = RewriteRule::new(
            Term::app("f", vec![Term::app("g", vec![Term::var("x")])]),
            Term::app("a", vec![]),
        );
        let csr = qcs_test_csr(
            vec![g_rule.clone(), f_rule.clone()],
            &[("f", &[0]), ("g", &[0]), ("a", &[])],
        );
        let pair = DependencyPair::new_for_test(
            Term::app("g#", vec![Term::var("x")]),
            Term::app(
                "g#",
                vec![Term::app(
                    "f",
                    vec![Term::app("g", vec![Term::app("a", vec![])])],
                )],
            ),
        );

        assert_eq!(qcs_usable_rules(&csr, &[pair]), vec![g_rule, f_rule]);
    }

    #[test]
    fn qcs_usable_rules_active_variable_forces_all_rules() {
        let rules = vec![
            RewriteRule::new(Term::app("g", vec![Term::var("x")]), Term::app("a", vec![])),
            RewriteRule::new(Term::app("h", vec![Term::var("x")]), Term::app("b", vec![])),
        ];
        let csr = qcs_test_csr(
            rules.clone(),
            &[("g", &[0]), ("h", &[0]), ("a", &[]), ("b", &[])],
        );
        let pair = DependencyPair::new_for_test(
            Term::app("g#", vec![Term::var("x")]),
            Term::app("g#", vec![Term::var("x")]),
        );

        assert_eq!(qcs_usable_rules(&csr, &[pair]), rules);
    }

    #[test]
    fn qcs_usable_rules_ex2_sqr_pair_is_not_empty() {
        let rules = vec![
            RewriteRule::new(
                Term::app("sqr", vec![Term::app("0", vec![])]),
                Term::app("0", vec![]),
            ),
            RewriteRule::new(
                Term::app("sqr", vec![Term::app("s", vec![Term::var("x")])]),
                Term::app("sqr", vec![Term::var("x")]),
            ),
            RewriteRule::new(Term::app("dbl", vec![Term::var("x")]), Term::var("x")),
        ];
        let csr = qcs_test_csr(
            rules.clone(),
            &[("sqr", &[0]), ("s", &[0]), ("dbl", &[0]), ("0", &[])],
        );
        let pair = DependencyPair::new_for_test(
            Term::app("sqr#", vec![Term::app("s", vec![Term::var("x")])]),
            Term::app("sqr#", vec![Term::var("x")]),
        );

        assert_eq!(qcs_usable_rules(&csr, &[pair]), rules);
    }

    #[test]
    fn csr_dependency_graph_preserves_inactive_marked_arguments() {
        let variables = BTreeSet::from([Variable::new("X"), Variable::new("Y")]);
        let trs = Trs::new(
            None,
            variables,
            vec![
                RewriteRule::new(
                    Term::app(
                        "f",
                        vec![
                            Term::var("X"),
                            Term::app("g", vec![Term::var("X")]),
                            Term::var("Y"),
                        ],
                    ),
                    Term::app("f", vec![Term::var("Y"), Term::var("Y"), Term::var("Y")]),
                ),
                RewriteRule::new(
                    Term::app("g", vec![Term::app("b", vec![])]),
                    Term::app("c", vec![]),
                ),
                RewriteRule::new(Term::app("b", vec![]), Term::app("c", vec![])),
            ],
        );
        let csr = CsrTrs::new(
            trs,
            ReplacementMap::new(BTreeMap::from([
                (Symbol::new("f"), BTreeSet::new()),
                (Symbol::new("g"), BTreeSet::from([0])),
                (Symbol::new("b"), BTreeSet::new()),
                (Symbol::new("c"), BTreeSet::new()),
            ])),
        )
        .unwrap();
        let pairs = csr_dependency_pairs(&csr);
        assert_eq!(pairs.len(), 1);
        assert!(csr_rhs_active_variables_are_active_in_lhs(&csr));
        assert_eq!(certifiable_csr_dependency_pairs(&csr), pairs);

        let graph = csr_dependency_pair_graph_with_context(&csr, &pairs, None);

        assert_eq!(graph, vec![Vec::<usize>::new()]);
        let root_proof = solve_csr_root(
            &csr,
            &DpOptions::default(),
            Some(Instant::now() + Duration::from_millis(100)),
        );
        assert!(
            root_proof.is_none(),
            "an acyclic graph with an unclosed CSR proof boundary must not return a partial proof: {root_proof:#?}"
        );
    }

    #[test]
    fn csr_dependency_graph_does_not_apply_ordinary_innermost_normality() {
        let rules = vec![
            RewriteRule::new(
                Term::app("f", vec![Term::var("x")]),
                Term::app("f", vec![Term::app("g", vec![Term::var("x")])]),
            ),
            RewriteRule::new(Term::app("g", vec![Term::var("x")]), Term::app("a", vec![])),
        ];
        let csr = qcs_test_csr(rules.clone(), &[("f", &[]), ("g", &[0]), ("a", &[])]);
        let pair = DependencyPair::new_for_test(
            Term::app("f#", vec![Term::var("x")]),
            Term::app("f#", vec![Term::app("g", vec![Term::var("x")])]),
        );
        let q_lhss = rules
            .iter()
            .map(RewriteRule::lhs)
            .cloned()
            .collect::<Vec<_>>();

        let full_graph =
            csr_dependency_pair_graph_with_context(&csr, std::slice::from_ref(&pair), None);
        let innermost_graph = csr_dependency_pair_graph_with_context(
            &csr,
            std::slice::from_ref(&pair),
            Some(&q_lhss),
        );

        assert_eq!(full_graph, vec![vec![0]]);
        assert_eq!(innermost_graph, full_graph);
    }

    #[test]
    fn csr_problem_context_keeps_the_csr_estimator_for_residual_graphs() {
        let variables = BTreeSet::from([Variable::new("x")]);
        let trs = Trs::new(
            None,
            variables,
            vec![
                RewriteRule::new(
                    Term::app("f", vec![Term::var("x")]),
                    Term::app("f", vec![Term::app("a", vec![])]),
                ),
                RewriteRule::new(Term::app("a", vec![]), Term::app("c", vec![])),
                RewriteRule::new(Term::app("b", vec![]), Term::app("c", vec![])),
            ],
        );
        let csr = CsrTrs::new(
            trs.clone(),
            ReplacementMap::new(BTreeMap::from([
                (Symbol::new("f"), BTreeSet::new()),
                (Symbol::new("a"), BTreeSet::new()),
                (Symbol::new("b"), BTreeSet::new()),
                (Symbol::new("c"), BTreeSet::new()),
            ])),
        )
        .unwrap();
        let source = DependencyPair::new_for_test(
            Term::app("f#", vec![Term::var("x")]),
            Term::app("f#", vec![Term::app("a", vec![])]),
        );
        let target = DependencyPair::new_for_test(
            Term::app("f#", vec![Term::app("b", vec![])]),
            Term::app("f#", vec![Term::app("b", vec![])]),
        );
        let pairs = vec![source, target];
        let cancellation = DpStrategyCancellation::default();
        let problem = DpProblemContext::ContextSensitive(CsrDpProblemContext::native(
            &csr,
            CsrGraphEstimator::ContextSensitive,
            true,
        ));
        let context_sensitive = dp_problem_dependency_graph_with_context_deadline(
            &problem,
            &trs,
            &pairs,
            None,
            None,
            None,
            &cancellation,
        )
        .unwrap();
        let direct = csr_dependency_pair_graph_with_context(&csr, &pairs, None);

        assert!(matches!(
            problem,
            DpProblemContext::ContextSensitive(CsrDpProblemContext {
                graph_estimator: CsrGraphEstimator::ContextSensitive,
                ..
            })
        ));
        assert_eq!(context_sensitive, direct);
        assert!(!context_sensitive[0].contains(&1));
    }

    #[test]
    fn csr_dependency_graph_renames_active_variable_occurrences() {
        let variables = BTreeSet::from([Variable::new("x")]);
        let trs = Trs::new(
            None,
            variables,
            vec![
                RewriteRule::new(
                    Term::app(
                        "f",
                        vec![Term::app("s", vec![Term::var("x")]), Term::var("x")],
                    ),
                    Term::app("f", vec![Term::var("x"), Term::var("x")]),
                ),
                RewriteRule::new(
                    Term::app("a", vec![]),
                    Term::app("s", vec![Term::app("a", vec![])]),
                ),
            ],
        );
        let csr = CsrTrs::new(
            trs,
            ReplacementMap::new(BTreeMap::from([
                (Symbol::new("f"), BTreeSet::from([0])),
                (Symbol::new("s"), BTreeSet::new()),
                (Symbol::new("a"), BTreeSet::new()),
            ])),
        )
        .unwrap();
        let pair = DependencyPair::new_for_test(
            Term::app(
                "f#",
                vec![Term::app("s", vec![Term::var("x")]), Term::var("x")],
            ),
            Term::app("f#", vec![Term::var("x"), Term::var("x")]),
        );

        let graph = csr_dependency_pair_graph_with_context(&csr, &[pair], None);

        assert_eq!(graph, vec![vec![0]]);
    }

    #[test]
    fn csr_dependency_graph_combines_active_cap_with_inactive_arguments() {
        let variables = BTreeSet::from([Variable::new("x")]);
        let trs = Trs::new(
            None,
            variables,
            vec![
                RewriteRule::new(
                    Term::app("f", vec![Term::var("x"), Term::var("x")]),
                    Term::app("f", vec![Term::app("a", vec![]), Term::app("b", vec![])]),
                ),
                RewriteRule::new(Term::app("b", vec![]), Term::app("a", vec![])),
            ],
        );
        let csr = CsrTrs::new(
            trs,
            ReplacementMap::new(BTreeMap::from([
                (Symbol::new("f"), BTreeSet::from([0])),
                (Symbol::new("a"), BTreeSet::new()),
                (Symbol::new("b"), BTreeSet::new()),
            ])),
        )
        .unwrap();
        let pairs = csr_dependency_pairs(&csr);

        let graph = csr_dependency_pair_graph_with_context(&csr, &pairs, None);

        assert_eq!(graph, vec![Vec::<usize>::new()]);
    }

    #[test]
    fn csr_dependency_graph_uses_ceta_default_active_map_for_fresh_unhiding() {
        let rules = vec![
            RewriteRule::new(
                Term::app("minus", vec![Term::var("x"), Term::var("y")]),
                Term::app(
                    "if",
                    vec![
                        Term::app("gt", vec![Term::var("y"), Term::app("0", vec![])]),
                        Term::app(
                            "minus",
                            vec![
                                Term::app("p", vec![Term::var("x")]),
                                Term::app("p", vec![Term::var("y")]),
                            ],
                        ),
                        Term::var("x"),
                    ],
                ),
            ),
            RewriteRule::new(
                Term::app(
                    "if",
                    vec![Term::app("false", vec![]), Term::var("x"), Term::var("y")],
                ),
                Term::var("y"),
            ),
        ];
        let csr = qcs_test_csr(
            rules,
            &[
                ("minus", &[0, 1]),
                ("if", &[0]),
                ("gt", &[0, 1]),
                ("p", &[0]),
            ],
        );
        let source = DependencyPair::new_for_test(
            Term::app("f#", vec![Term::var("x"), Term::var("y")]),
            Term::app(
                "__CSR_U0",
                vec![Term::app(
                    "minus",
                    vec![
                        Term::app("p", vec![Term::var("y")]),
                        Term::app("p", vec![Term::var("x")]),
                    ],
                )],
            ),
        );
        let target = DependencyPair::new_for_test(
            Term::app("__CSR_U0", vec![Term::app("p", vec![Term::var("z")])]),
            Term::app("__CSR_U0", vec![Term::var("z")]),
        );

        let graph = csr_dependency_pair_graph_with_context(&csr, &[source.clone(), target.clone()], None);
        assert!(graph[0].contains(&1),
            "CeTA's graph checker gives the fresh symbol its default active map");
        let fresh = fresh_unhiding_symbol(csr.trs());
        let frozen = csr.with_frozen_auxiliary_symbol(fresh);
        let frozen_graph = csr_dependency_pair_graph_with_context(&frozen, &[source, target], None);
        assert!(!frozen_graph[0].contains(&1),
            "an explicit frozen U map forbids rewriting minus(...) into p(...)");
    }

    #[test]
    fn csr_dependency_graph_keeps_listutilities_unhiding_edge() {
        let rules = vec![
            RewriteRule::new(
                Term::app("isLNat", vec![Term::var("x")]),
                Term::app(
                    "and",
                    vec![
                        Term::app("isNatural", vec![Term::var("x")]),
                        Term::app("isLNat", vec![Term::var("xs")]),
                    ],
                ),
            ),
            RewriteRule::new(
                Term::app("and", vec![Term::app("tt", vec![]), Term::var("x")]),
                Term::var("x"),
            ),
        ];
        let csr = qcs_test_csr(
            rules,
            &[
                ("isLNat", &[]),
                ("isNatural", &[]),
                ("and", &[0]),
                ("tt", &[]),
            ],
        );
        let source = DependencyPair::new_for_test(
            Term::app("and#", vec![Term::app("tt", vec![]), Term::var("x")]),
            Term::app("__CSR_U0", vec![Term::app("isLNat", vec![Term::var("x")])]),
        );
        let target = DependencyPair::new_for_test(
            Term::app(
                "__CSR_U0",
                vec![Term::app(
                    "and",
                    vec![
                        Term::app("isNatural", vec![Term::var("y")]),
                        Term::app("isLNat", vec![Term::var("ys")]),
                    ],
                )],
            ),
            Term::app("and#", vec![Term::var("y"), Term::var("ys")]),
        );

        let graph = csr_dependency_pair_graph_with_context(&csr, &[source, target], None);

        assert!(graph[0].contains(&1));
    }

    #[test]
    fn csr_dependency_graph_preserves_sharing_between_inactive_arguments() {
        let variables = BTreeSet::from([Variable::new("x")]);
        let trs = Trs::new(
            None,
            variables,
            vec![RewriteRule::new(
                Term::app(
                    "f",
                    vec![
                        Term::app("a", vec![]),
                        Term::app("b", vec![]),
                        Term::var("x"),
                    ],
                ),
                Term::app("f", vec![Term::var("x"), Term::var("x"), Term::var("x")]),
            )],
        );
        let csr = CsrTrs::new(
            trs,
            ReplacementMap::new(BTreeMap::from([
                (Symbol::new("f"), BTreeSet::from([2])),
                (Symbol::new("a"), BTreeSet::new()),
                (Symbol::new("b"), BTreeSet::new()),
            ])),
        )
        .unwrap();
        let pairs = csr_dependency_pairs(&csr);

        let graph = csr_dependency_pair_graph_with_context(&csr, &pairs, None);

        assert_eq!(graph, vec![Vec::<usize>::new()]);
    }

    #[test]
    fn csr_dependency_graph_propagates_frozen_value_to_shared_active_argument() {
        let variables = BTreeSet::from([Variable::new("x")]);
        let trs = Trs::new(
            None,
            variables,
            vec![
                RewriteRule::new(
                    Term::app(
                        "f",
                        vec![
                            Term::app("a", vec![]),
                            Term::app("b", vec![]),
                            Term::var("x"),
                        ],
                    ),
                    Term::app("f", vec![Term::var("x"), Term::var("x"), Term::var("x")]),
                ),
                RewriteRule::new(Term::app("c", vec![]), Term::app("a", vec![])),
                RewriteRule::new(Term::app("c", vec![]), Term::app("b", vec![])),
            ],
        );
        let csr = CsrTrs::new(
            trs,
            ReplacementMap::new(BTreeMap::from([
                (Symbol::new("f"), BTreeSet::from([0, 2])),
                (Symbol::new("a"), BTreeSet::new()),
                (Symbol::new("b"), BTreeSet::new()),
                (Symbol::new("c"), BTreeSet::new()),
            ])),
        )
        .unwrap();
        let pairs = csr_dependency_pairs(&csr);

        let graph = csr_dependency_pair_graph_with_context(&csr, &pairs, None);

        assert_eq!(pairs.len(), 1);
        assert_eq!(graph, vec![Vec::<usize>::new()]);
    }

    #[test]
    fn csr_dependency_graph_keeps_active_call_reduction_into_marked_target() {
        let variables = BTreeSet::from([Variable::new("x"), Variable::new("y")]);
        let trs = Trs::new(
            None,
            variables,
            vec![
                RewriteRule::new(
                    Term::app("isNatural", vec![Term::app("zero", vec![])]),
                    Term::app("tt", vec![]),
                ),
                RewriteRule::new(
                    Term::app("and", vec![Term::app("tt", vec![]), Term::var("x")]),
                    Term::var("x"),
                ),
                RewriteRule::new(
                    Term::app(
                        "isLNat",
                        vec![Term::app("afterNth", vec![Term::var("x"), Term::var("y")])],
                    ),
                    Term::app(
                        "and",
                        vec![
                            Term::app("isNatural", vec![Term::var("x")]),
                            Term::app("isLNat", vec![Term::var("y")]),
                        ],
                    ),
                ),
            ],
        );
        let csr = CsrTrs::new(
            trs,
            ReplacementMap::new(BTreeMap::from([
                (Symbol::new("and"), BTreeSet::from([0])),
                (Symbol::new("isNatural"), BTreeSet::new()),
                (Symbol::new("isLNat"), BTreeSet::new()),
                (Symbol::new("afterNth"), BTreeSet::from([0, 1])),
                (Symbol::new("tt"), BTreeSet::new()),
                (Symbol::new("zero"), BTreeSet::new()),
            ])),
        )
        .unwrap();
        let source = DependencyPair::new_for_test(
            Term::app(
                "isLNat#",
                vec![Term::app("afterNth", vec![Term::var("x"), Term::var("y")])],
            ),
            Term::app(
                "and#",
                vec![
                    Term::app("isNatural", vec![Term::var("x")]),
                    Term::app("isLNat", vec![Term::var("y")]),
                ],
            ),
        );
        let target = DependencyPair::new_for_test(
            Term::app("and#", vec![Term::app("tt", vec![]), Term::var("x")]),
            Term::app("__CSR_U0", vec![Term::var("x")]),
        );

        let graph = csr_dependency_pair_graph_with_context(&csr, &[source, target], None);

        assert!(
            graph[0].contains(&1),
            "the active isNatural call can reduce to tt before the marked and call"
        );
    }

    #[test]
    fn csr_certifiable_pairs_use_reduced_set_when_rhs_active_variables_are_safe() {
        let variables = BTreeSet::from([Variable::new("x")]);
        let trs = Trs::new(
            None,
            variables,
            vec![
                RewriteRule::new(
                    Term::app("f", vec![Term::var("x")]),
                    Term::app("g", vec![Term::app("f", vec![Term::var("x")])]),
                ),
                RewriteRule::new(Term::app("g", vec![Term::var("x")]), Term::app("a", vec![])),
            ],
        );
        let csr = CsrTrs::new(
            trs,
            ReplacementMap::new(BTreeMap::from([
                (Symbol::new("f"), BTreeSet::from([0])),
                (Symbol::new("g"), BTreeSet::new()),
                (Symbol::new("a"), BTreeSet::new()),
            ])),
        )
        .unwrap();

        assert!(csr_rhs_active_variables_are_active_in_lhs(&csr));
        assert_eq!(
            certifiable_csr_dependency_pairs(&csr),
            csr_dependency_pairs(&csr)
        );
        assert_ne!(
            certifiable_csr_dependency_pairs(&csr),
            dependency_pairs(csr.trs())
        );
    }

    #[test]
    fn csr_certifiable_pairs_fall_back_to_safe_set_for_rhs_active_variables() {
        let variables = BTreeSet::from([Variable::new("x")]);
        let trs = Trs::new(
            None,
            variables,
            vec![
                RewriteRule::new(
                    Term::app("f", vec![Term::var("x")]),
                    Term::app("g", vec![Term::app("f", vec![Term::var("x")])]),
                ),
                RewriteRule::new(Term::app("g", vec![Term::var("x")]), Term::var("x")),
            ],
        );
        let csr = CsrTrs::new(
            trs,
            ReplacementMap::new(BTreeMap::from([
                (Symbol::new("f"), BTreeSet::from([0])),
                (Symbol::new("g"), BTreeSet::new()),
            ])),
        )
        .unwrap();

        assert!(!csr_rhs_active_variables_are_active_in_lhs(&csr));
        assert_eq!(
            certifiable_csr_dependency_pairs(&csr),
            dependency_pairs(csr.trs())
        );
        assert_ne!(
            certifiable_csr_dependency_pairs(&csr),
            csr_dependency_pairs(&csr)
        );
    }

    #[test]
    fn improved_csr_dp_branch_keeps_exact_unhiding_pair_set() {
        let variables = BTreeSet::from([Variable::new("x")]);
        let trs = Trs::new(
            None,
            variables,
            vec![
                RewriteRule::new(
                    Term::app("f", vec![Term::app("s", vec![Term::var("x")])]),
                    Term::app("f", vec![Term::var("x")]),
                ),
                RewriteRule::new(Term::app("g", vec![Term::var("x")]), Term::var("x")),
            ],
        );
        let csr = CsrTrs::new(
            trs,
            ReplacementMap::new(BTreeMap::from([
                (Symbol::new("f"), BTreeSet::from([0])),
                (Symbol::new("g"), BTreeSet::new()),
                (Symbol::new("s"), BTreeSet::from([0])),
            ])),
        )
        .unwrap();

        assert!(!csr_rhs_active_variables_are_active_in_lhs(&csr));
        let proof = solve_improved_csr_dependency_pairs(&csr, &DpOptions::default(), None).unwrap();

        assert_eq!(proof.pairs, certificate_improved_csr_dependency_pairs(&csr));
        assert_eq!(proof.component_proofs.len(), 2);
        assert!(proof.component_proofs[0].usable_rules_processor.is_none());
        assert!(proof.component_proofs[0].proved);
    }

    #[test]
    fn parses_dp_strategy_language() {
        let strategy =
            DpStrategy::parse("graph; subterm; orders | timeout(250ms, narrow)").unwrap();
        assert_eq!(
            strategy,
            DpStrategy::Choice(vec![
                DpStrategy::Sequence(vec![
                    DpStrategy::Processor(DpStrategyProcessor::DependencyGraph),
                    DpStrategy::Processor(DpStrategyProcessor::Subterm),
                    DpStrategy::standard_orders(),
                ]),
                DpStrategy::Timeout {
                    duration: Duration::from_millis(250),
                    strategy: Box::new(DpStrategy::Processor(DpStrategyProcessor::Narrowing {
                        max_per_pair: None
                    })),
                },
            ])
        );

        let repeated = DpStrategy::parse("repeat(3, graph; orders)").unwrap();
        assert!(matches!(
            repeated,
            DpStrategy::Repeat {
                max_iterations: 3,
                ..
            }
        ));

        let delayed = DpStrategy::parse("delay(500ms, kbo)").unwrap();
        assert!(matches!(
            delayed,
            DpStrategy::Delay {
                duration,
                strategy
            } if duration == Duration::from_millis(500)
                && matches!(
                    strategy.as_ref(),
                    DpStrategy::Processor(DpStrategyProcessor::Kbo {
                        max_weight: 2,
                        max_symbols: KBO_SMT_SYMBOL_LIMIT,
                    })
                )
        ));

        assert_eq!(
            DpStrategy::parse("switch-innermost").unwrap(),
            DpStrategy::Processor(DpStrategyProcessor::SwitchInnermost)
        );
        assert_eq!(
            DpStrategy::parse("split").unwrap(),
            DpStrategy::Processor(DpStrategyProcessor::Split)
        );
        let source = "<dpInput><trs><rules/></trs><dps><rules/></dps></dpInput>";
        let proof = "<loop/>";
        let encoded = serde_json::to_vec(&(source, proof))
            .unwrap()
            .into_iter()
            .map(|byte| format!("{byte:02x}"))
            .collect::<String>();
        assert_eq!(
            DpStrategy::parse(&format!("exact-dp-loop(hex={encoded})")).unwrap(),
            DpStrategy::Processor(DpStrategyProcessor::ExactNonterminationLoop {
                source_dp_input_xml: source.to_owned(),
                loop_xml: proof.to_owned(),
            })
        );
        let selected_split_processor = DpStrategyProcessor::SelectedSplit { candidate_index: 2 };
        let selected_split = DpStrategy::Processor(selected_split_processor.clone());
        assert_eq!(
            DpStrategy::parse("split(candidate=2)").unwrap(),
            selected_split
        );
        assert_eq!(
            selected_split_processor.to_strategy_atom(),
            "split(candidate=2)"
        );

        assert_eq!(
            DpStrategy::parse("poly(2,1,6,3)").unwrap(),
            DpStrategy::Processor(DpStrategyProcessor::LinearPolynomial {
                max_constant: 2,
                max_coefficient: 1,
                max_symbols: Some(6),
                max_arity: Some(3),
            })
        );
        let parallel = DpStrategy::parse("parallel(rpo | kbo | sat-poly)").unwrap();
        assert!(matches!(
            parallel,
            DpStrategy::Parallel {
                cancel_on: DpParallelCancel::Proof,
                strategies: ref branches
            }
                if branches.len() == 3
                    && branches.iter().any(|branch| matches!(
                        branch,
                        DpStrategy::Processor(DpStrategyProcessor::Kbo {
                            max_weight: 2,
                            max_symbols: KBO_SMT_SYMBOL_LIMIT,
                        })
                    ))
        ));
        assert!(matches!(
            DpStrategy::parse("parallel(cancel=progress, rpo | kbo)").unwrap(),
            DpStrategy::Parallel {
                cancel_on: DpParallelCancel::Progress,
                strategies: ref branches
            } if branches.len() == 2
        ));
        let pipeline = DpStrategy::parse(
            "pipeline(graph; narrow(per-pair=1); graph; semantic-labeling; graph; size-change)",
        )
        .unwrap();
        assert!(matches!(
            pipeline,
            DpStrategy::Pipeline(ref stages) if stages.len() == 6
        ));
        assert_eq!(
            DpStrategy::parse(&pipeline.to_strategy_atom()).unwrap(),
            pipeline
        );
        assert_eq!(
            DpStrategy::parse("kbo(3)").unwrap(),
            DpStrategy::Processor(DpStrategyProcessor::Kbo {
                max_weight: 3,
                max_symbols: KBO_SMT_SYMBOL_LIMIT,
            })
        );
        assert_eq!(
            DpStrategy::parse("kbo(3,5)").unwrap(),
            DpStrategy::Processor(DpStrategyProcessor::Kbo {
                max_weight: 3,
                max_symbols: 5,
            })
        );
        assert_eq!(
            DpStrategy::parse("sat-poly(2,2,5,3)").unwrap(),
            DpStrategy::Processor(DpStrategyProcessor::SatPolynomial {
                max_constant: 2,
                max_coefficient: 2,
                max_symbols: Some(5),
                max_arity: Some(3),
            })
        );
        assert_eq!(
            DpStrategy::parse("mono-poly(const=2, coeff=2, symbols=5, arity=3)").unwrap(),
            DpStrategy::Processor(DpStrategyProcessor::MonotonicPolynomial {
                max_constant: 2,
                max_coefficient: 2,
                max_symbols: Some(5),
                max_arity: Some(3),
            })
        );
        assert_eq!(
            DpStrategy::parse("max-polo(2,1,3,5,2)").unwrap(),
            DpStrategy::Processor(DpStrategyProcessor::MaxPolynomial {
                max_constant: 2,
                max_coefficient: 1,
                alternatives: 3,
                max_symbols: Some(5),
                max_arity: Some(2),
            })
        );
        assert_eq!(
            DpStrategy::parse("rat-poly(16,16,12,3,4)").unwrap(),
            DpStrategy::Processor(DpStrategyProcessor::RationalPolynomial {
                max_constant: 16,
                max_coefficient: 16,
                max_symbols: Some(12),
                max_arity: Some(3),
                denominator: 4,
                delta_denominator: 4,
            })
        );
        assert_eq!(
            DpStrategy::parse("smt-poly(2,2,5,3)").unwrap(),
            DpStrategy::Processor(DpStrategyProcessor::SmtPolynomial {
                max_constant: 2,
                max_coefficient: 2,
                max_symbols: Some(5),
                max_arity: Some(3),
            })
        );
        assert_eq!(
            DpStrategy::parse("quadratic-poly(2,1,5,3)").unwrap(),
            DpStrategy::Processor(DpStrategyProcessor::QuadraticPolynomial {
                max_constant: 2,
                max_coefficient: 1,
                max_symbols: Some(5),
                max_arity: Some(3),
            })
        );
        assert_eq!(
            DpStrategy::parse("matrix(2,2,5,3)").unwrap(),
            DpStrategy::Processor(DpStrategyProcessor::MatrixInterpretation {
                dimension: 2,
                max_constant: 2,
                max_coefficient: 2,
                min_nonzero: None,
                max_nonzero: None,
                max_nonzero_constants: None,
                max_nonzero_per_row: None,
                max_symbols: Some(5),
                max_arity: Some(3),
            })
        );
        assert_eq!(
            DpStrategy::parse("matrix(dim=1, const=2, coeff=1, symbols=5, arity=3)").unwrap(),
            DpStrategy::Processor(DpStrategyProcessor::MatrixInterpretation {
                dimension: 1,
                max_constant: 2,
                max_coefficient: 1,
                min_nonzero: None,
                max_nonzero: None,
                max_nonzero_constants: None,
                max_nonzero_per_row: None,
                max_symbols: Some(5),
                max_arity: Some(3),
            })
        );
        assert_eq!(
            DpStrategy::parse(
                "integer-matrix(dimension=2,min-value=-2,max-value=3,max-symbols=20,max-arity=3)"
            )
            .unwrap(),
            DpStrategy::Processor(DpStrategyProcessor::IntegerMatrixInterpretation {
                dimension: 2,
                min_value: -2,
                max_value: 3,
                max_symbols: Some(20),
                max_arity: Some(3),
            })
        );
        assert_eq!(
            DpStrategy::parse("arctic-matrix(dim=3, const=1, coeff=1, symbols=6, arity=1)")
                .unwrap(),
            DpStrategy::Processor(DpStrategyProcessor::ArcticMatrixInterpretation {
                threshold: false,
                shared: false,
                dimension: 3,
                max_constant: 1,
                max_coefficient: 1,
                max_nonzero: None,
                max_symbols: Some(6),
                max_arity: Some(1),
            })
        );
        assert_eq!(
            DpStrategy::parse("forward-instantiation").unwrap(),
            DpStrategy::Processor(DpStrategyProcessor::ForwardInstantiation { max_per_pair: None })
        );
        assert_eq!(
            DpStrategy::parse("narrow(max-per-pair=1)").unwrap(),
            DpStrategy::Processor(DpStrategyProcessor::Narrowing {
                max_per_pair: Some(1),
            })
        );
        assert_eq!(
            DpStrategy::parse("rewrite(3)").unwrap(),
            DpStrategy::Processor(DpStrategyProcessor::Rewriting {
                max_per_pair: Some(3),
            })
        );
        assert_eq!(
            DpStrategy::parse("instantiate(per_pair=2)").unwrap(),
            DpStrategy::Processor(DpStrategyProcessor::Instantiation {
                max_per_pair: Some(2),
            })
        );
        let selected_transform = DpStrategy::parse("instantiate(candidate=2,per-pair=1)").unwrap();
        assert_eq!(
            selected_transform,
            DpStrategy::Processor(DpStrategyProcessor::SelectedInstantiation {
                max_per_pair: Some(1),
                candidate_index: 2,
            })
        );
        assert_eq!(
            DpStrategy::parse(&selected_transform.to_strategy_atom()).unwrap(),
            selected_transform
        );
        assert_eq!(
            DpStrategy::parse("forward-instantiation(max_per_pair=4)").unwrap(),
            DpStrategy::Processor(DpStrategyProcessor::ForwardInstantiation {
                max_per_pair: Some(4),
            })
        );
        assert_eq!(
            DpStrategy::parse("poly(const=2, coeff=1, symbols=6, arity=3)").unwrap(),
            DpStrategy::Processor(DpStrategyProcessor::LinearPolynomial {
                max_constant: 2,
                max_coefficient: 1,
                max_symbols: Some(6),
                max_arity: Some(3),
            })
        );
        assert_eq!(
            DpStrategy::parse(
                "weak-poly(min=-2, max-constant=3, max-coefficient=2, max-symbols=7, max-arity=2)"
            )
            .unwrap(),
            DpStrategy::Processor(DpStrategyProcessor::WeakPolynomial {
                min_constant: -2,
                max_constant: 3,
                max_coefficient: 2,
                max_symbols: Some(7),
                max_arity: Some(2),
            })
        );
        assert_eq!(
            DpStrategy::parse(
                "max-poly(max-constant=2, max-coefficient=1, alternatives=3, symbols=5, arity=2)"
            )
            .unwrap(),
            DpStrategy::Processor(DpStrategyProcessor::MaxPolynomial {
                max_constant: 2,
                max_coefficient: 1,
                alternatives: 3,
                max_symbols: Some(5),
                max_arity: Some(2),
            })
        );
        assert_eq!(
            DpStrategy::parse("rat-poly(const=16, coeff=8, symbols=12, arity=3, denom=4)").unwrap(),
            DpStrategy::Processor(DpStrategyProcessor::RationalPolynomial {
                max_constant: 16,
                max_coefficient: 8,
                max_symbols: Some(12),
                max_arity: Some(3),
                denominator: 4,
                delta_denominator: 4,
            })
        );
        assert_eq!(
            DpStrategy::parse("rat-poly(const=16, coeff=16, denom=4, delta-denom=16)").unwrap(),
            DpStrategy::Processor(DpStrategyProcessor::RationalPolynomial {
                max_constant: 16,
                max_coefficient: 16,
                max_symbols: None,
                max_arity: None,
                denominator: 4,
                delta_denominator: 16,
            })
        );
        assert_eq!(
            DpStrategy::parse("kbo(weight=3, symbols=7)").unwrap(),
            DpStrategy::Processor(DpStrategyProcessor::Kbo {
                max_weight: 3,
                max_symbols: 7,
            })
        );
        assert_eq!(
            DpStrategy::parse("symbol-weights(max-weight=1)").unwrap(),
            DpStrategy::Processor(DpStrategyProcessor::SymbolWeights { max_weight: 1 })
        );
        let named = DpStrategy::parse(
            "let orders = parallel(rpo | kbo | sat-poly); graph; orders; timeout(2s, narrow)",
        )
        .unwrap();
        assert!(matches!(
            named,
            DpStrategy::Sequence(ref stages)
                if stages.iter().any(strategy_contains_parallel)
                    && stages.iter().any(|stage| {
                        strategy_contains_processor(stage, &DpStrategyProcessor::Narrowing { max_per_pair: None })
                    })
        ));
        let shadowed_builtin = DpStrategy::parse("orders := kbo; orders").unwrap();
        assert_eq!(
            shadowed_builtin,
            DpStrategy::Processor(DpStrategyProcessor::Kbo {
                max_weight: 2,
                max_symbols: KBO_SMT_SYMBOL_LIMIT,
            })
        );
        let named_sequence = DpStrategy::parse("let cheap = (graph; subterm); cheap").unwrap();
        assert!(matches!(
            named_sequence,
            DpStrategy::Sequence(ref stages)
                if stages.len() == 2
                    && matches!(
                        stages[0],
                        DpStrategy::Processor(DpStrategyProcessor::DependencyGraph)
                    )
        ));
        assert!(matches!(
            DpStrategy::default_for(RewriteStrategy::Full),
            DpStrategy::Sequence(ref stages)
                if stages.iter().any(strategy_contains_parallel)
                    && stages.iter().any(|stage| {
                        strategy_contains_processor(
                            stage,
                            &DpStrategyProcessor::Kbo {
                                max_weight: 2,
                                max_symbols: KBO_SMT_SYMBOL_LIMIT,
                            }
                        )
                    })
                    && stages.iter().any(|stage| {
                        strategy_contains_processor(
                            stage,
                            &DpStrategyProcessor::WeakPolynomial {
                                min_constant: -2,
                                max_constant: 2,
                                max_coefficient: 2,
                                max_symbols: None,
                                max_arity: None,
                            }
                        )
                    })
        ));
        assert!(strategy_contains_processor(
            &DpStrategy::default_for(RewriteStrategy::Full),
            &DpStrategyProcessor::Narrowing { max_per_pair: None }
        ));
        assert!(strategy_contains_processor(
            &DpStrategy::default_for(RewriteStrategy::Innermost),
            &DpStrategyProcessor::Narrowing { max_per_pair: None }
        ));
    }

    #[test]
    fn executable_strategy_atom_round_trips_complete_dp_continuations() {
        let strategy = DpStrategy::parse(
            "graph; subterm; timeout(2s, size-change); timeout(4s, parallel(\
             matrix(dimension=1,max-constant=2,max-coefficient=1) | \
             matrix(dimension=2,max-constant=1,max-coefficient=1) | path-order | \
             kbo(weight=2) | poly(max-constant=2,max-coefficient=2))); \
             timeout(4s, parallel(rewrite(per-pair=2) | instantiate(per-pair=2) | \
             forward-instantiate(per-pair=2))); timeout(2s, size-change); graph; subterm",
        )
        .unwrap();

        let atom = strategy.to_strategy_atom();
        assert_eq!(DpStrategy::parse(&atom).unwrap(), strategy, "{atom}");
    }

    #[test]
    fn executable_strategy_atoms_round_trip_every_dp_processor_family() {
        let processors = vec![
            DpStrategyProcessor::DependencyGraph,
            DpStrategyProcessor::SwitchInnermost,
            DpStrategyProcessor::Subterm,
            DpStrategyProcessor::SizeChange,
            DpStrategyProcessor::Llm,
            DpStrategyProcessor::SymbolWeights { max_weight: 3 },
            DpStrategyProcessor::LinearPolynomial {
                max_constant: 3,
                max_coefficient: 2,
                max_symbols: Some(9),
                max_arity: Some(4),
            },
            DpStrategyProcessor::ExactLinearPolynomial {
                interpretation: vec![
                    ("f".to_string(), 1, vec![2, 0]),
                    ("g#".to_string(), 0, vec![1]),
                ],
            },
            DpStrategyProcessor::ExactMonotonicPolynomial {
                interpretation: vec![
                    ("f".to_string(), 1, vec![2, 1]),
                    ("g#".to_string(), 0, vec![1]),
                ],
            },
            DpStrategyProcessor::ExactWeakPolynomial {
                interpretation: vec![
                    ("f".to_string(), -1, vec![2, 0]),
                    ("g#".to_string(), 0, vec![1]),
                ],
            },
            DpStrategyProcessor::ExactMaxPolynomial {
                interpretation: vec![("f#".to_string(), vec![(0, vec![1, 0]), (1, vec![0, 1])])],
            },
            DpStrategyProcessor::ExactRationalPolynomial {
                denominator: 4,
                interpretation: vec![("f#".to_string(), 1, vec![2, 4])],
            },
            DpStrategyProcessor::ExactRationalNaturalPolynomial {
                denominator: 4,
                delta: 1,
                interpretation: vec![(
                    "f#".to_string(),
                    1,
                    vec![2, 4],
                    vec![vec![1, 0], vec![0, 2]],
                )],
            },
            DpStrategyProcessor::ExactMatrixInterpretation {
                interpretation: vec![(
                    "f#".to_string(),
                    vec![1, 0],
                    vec![vec![vec![1, 0], vec![0, 1]]],
                )],
            },
            DpStrategyProcessor::ExactArcticMatrixInterpretation {
                integer_domain: false,
                interpretation: vec![("f#".to_string(), vec![1], vec![vec![vec![i64::MIN]]])],
            },
            DpStrategyProcessor::MonotonicPolynomial {
                max_constant: 3,
                max_coefficient: 2,
                max_symbols: Some(9),
                max_arity: Some(4),
            },
            DpStrategyProcessor::SatPolynomial {
                max_constant: 3,
                max_coefficient: 2,
                max_symbols: Some(9),
                max_arity: Some(4),
            },
            DpStrategyProcessor::WeakPolynomial {
                min_constant: -3,
                max_constant: 3,
                max_coefficient: 2,
                max_symbols: Some(9),
                max_arity: Some(4),
            },
            DpStrategyProcessor::MaxPolynomial {
                max_constant: 3,
                max_coefficient: 2,
                alternatives: 4,
                max_symbols: Some(9),
                max_arity: Some(4),
            },
            DpStrategyProcessor::RationalPolynomial {
                max_constant: 16,
                max_coefficient: 8,
                max_symbols: Some(9),
                max_arity: Some(4),
                denominator: 4,
                delta_denominator: 16,
            },
            DpStrategyProcessor::SmtPolynomial {
                max_constant: 3,
                max_coefficient: 2,
                max_symbols: Some(9),
                max_arity: Some(4),
            },
            DpStrategyProcessor::QuadraticPolynomial {
                max_constant: 3,
                max_coefficient: 2,
                max_symbols: Some(9),
                max_arity: Some(4),
            },
            DpStrategyProcessor::MatrixInterpretation {
                dimension: 3,
                max_constant: 2,
                max_coefficient: 1,
                min_nonzero: Some(3),
                max_nonzero: Some(12),
                max_nonzero_constants: Some(2),
                max_nonzero_per_row: Some(3),
                max_symbols: Some(9),
                max_arity: Some(4),
            },
            DpStrategyProcessor::ArcticMatrixInterpretation {
                threshold: false,
                shared: false,
                dimension: 3,
                max_constant: 2,
                max_coefficient: 1,
                max_nonzero: Some(12),
                max_symbols: Some(9),
                max_arity: Some(4),
            },
            DpStrategyProcessor::IntegerArcticMatrixInterpretation {
                threshold: false,
                all_strict: false,
                max_finite_per_row: None,
                bitvectors: false,
                root_projection: false,
                optimize: true,
                symmetry: false,
                solver: None,
                dimension: 2,
                min_value: -3,
                max_value: 4,
                max_symbols: Some(9),
                max_arity: Some(4),
            },
            DpStrategyProcessor::ApplicativeReductionPair,
            DpStrategyProcessor::PathOrder,
            DpStrategyProcessor::ExactPathOrder {
                default_order: DpPathOrderKind::Rpo,
                statuses: BTreeMap::from([
                    ("a".to_string(), DpPathOrderKind::Lpo),
                    ("f#".to_string(), DpPathOrderKind::Rpo),
                ]),
                precedence: vec!["a".to_string(), "f#".to_string()],
                precedence_ranks: BTreeMap::from([("a".to_string(), 0), ("f#".to_string(), 1)]),
                argument_filter: BTreeMap::from([(
                    "f#".to_string(),
                    DpArgumentFilterEntry::NonCollapsing(vec![0]),
                )]),
            },
            DpStrategyProcessor::Kbo {
                max_weight: 3,
                max_symbols: 9,
            },
            DpStrategyProcessor::Rewriting {
                max_per_pair: Some(3),
            },
            DpStrategyProcessor::Narrowing {
                max_per_pair: Some(3),
            },
            DpStrategyProcessor::Instantiation {
                max_per_pair: Some(3),
            },
            DpStrategyProcessor::ForwardInstantiation {
                max_per_pair: Some(3),
            },
            DpStrategyProcessor::NonterminationLoop,
            DpStrategyProcessor::SemanticLabeling,
            DpStrategyProcessor::ExactSemanticLabeling {
                model: SemanticLabelingModel {
                    carrier_size: 2,
                    arities: BTreeMap::from([(Symbol::new("a"), 0), (Symbol::new("f#"), 1)]),
                    interpretations: BTreeMap::from([
                        (Symbol::new("a"), SlArithmeticFunction::Constant(1)),
                        (Symbol::new("f#"), SlArithmeticFunction::Argument(0)),
                    ]),
                },
                source_dp_input_xml: None,
                expected_child_dp_input_xml: None,
            },
            DpStrategyProcessor::Uncurry,
        ];

        for processor in processors {
            let strategy = DpStrategy::Processor(processor);
            let atom = strategy.to_strategy_atom();
            assert_eq!(DpStrategy::parse(&atom).unwrap(), strategy, "{atom}");
        }

        let wrappers = DpStrategy::Repeat {
            max_iterations: 3,
            strategy: Box::new(DpStrategy::Delay {
                duration: Duration::from_millis(125),
                strategy: Box::new(DpStrategy::Choice(vec![
                    DpStrategy::Processor(DpStrategyProcessor::Subterm),
                    DpStrategy::Processor(DpStrategyProcessor::SizeChange),
                ])),
            }),
        };
        let atom = wrappers.to_strategy_atom();
        assert_eq!(DpStrategy::parse(&atom).unwrap(), wrappers, "{atom}");
    }

    #[test]
    fn exact_polynomial_strategy_rejects_malformed_witnesses() {
        assert!(DpStrategy::parse("exact-poly(hex=0)").is_err());
        assert!(DpStrategy::parse("exact-poly(hex=zz)").is_err());
        assert!(DpStrategy::parse("exact-poly(hex=5b5d)").is_err());
        assert!(DpStrategy::parse("exact-weak-poly(hex=0)").is_err());
        assert!(DpStrategy::parse("exact-weak-poly(hex=zz)").is_err());
        assert!(DpStrategy::parse("exact-weak-poly(hex=5b5d)").is_err());
        assert!(DpStrategy::parse("exact-max-poly(hex=0)").is_err());
        assert!(DpStrategy::parse("exact-max-poly(hex=zz)").is_err());
        assert!(DpStrategy::parse("exact-max-poly(hex=5b5d)").is_err());
        assert!(DpStrategy::parse("exact-rat-poly(hex=0)").is_err());
        assert!(DpStrategy::parse("exact-rat-poly(hex=zz)").is_err());
        assert!(DpStrategy::parse("exact-rat-poly(hex=5b5d)").is_err());
        assert!(DpStrategy::parse("exact-matrix(hex=0)").is_err());
        assert!(DpStrategy::parse("exact-matrix(hex=zz)").is_err());
        assert!(DpStrategy::parse("exact-matrix(hex=5b5d)").is_err());
        assert!(DpStrategy::parse("exact-arctic(hex=0)").is_err());
        assert!(DpStrategy::parse("exact-arctic(hex=zz)").is_err());
        assert!(DpStrategy::parse("exact-arctic(hex=5b5d)").is_err());
    }

    #[test]
    fn nonmonotone_reduction_retains_parent_trs_with_empty_active_rules() {
        let parent = vec![RewriteRule::new(
            Term::app("f", vec![Term::var("x")]),
            Term::var("x"),
        )];

        assert_eq!(
            reduction_pair_residual_base_rules(&parent, &[], false),
            parent
        );
        assert!(reduction_pair_residual_base_rules(&parent, &[], true).is_empty());
    }

    #[test]
    fn dp_switch_overlap_checks_rule_redexes_inside_pair_lhss() {
        let pair = DependencyPair::new_for_test(
            Term::app("f#", vec![Term::app("g", vec![Term::var("x")])]),
            Term::app("f#", vec![Term::var("x")]),
        );
        let overlapping = RewriteRule::new(Term::app("g", vec![Term::var("y")]), Term::var("y"));
        let disjoint = RewriteRule::new(Term::app("h", vec![Term::var("y")]), Term::var("y"));

        assert!(dp_pairs_overlap_rules(
            std::slice::from_ref(&pair),
            &[overlapping]
        ));
        assert!(!dp_pairs_overlap_rules(&[pair], &[disjoint]));
    }

    #[test]
    fn semantic_labeling_expands_variable_rule_over_carrier_assignments() {
        let x = Variable::new("x");
        let rule = RewriteRule::new(
            Term::app("f", vec![Term::Var(x.clone())]),
            Term::app("g", vec![Term::Var(x)]),
        );
        let model = SemanticLabelingModel {
            carrier_size: 2,
            arities: BTreeMap::from([(Symbol::new("f"), 1), (Symbol::new("g"), 1)]),
            interpretations: BTreeMap::from([
                (Symbol::new("f"), SlArithmeticFunction::Argument(0)),
                (Symbol::new("g"), SlArithmeticFunction::Constant(0)),
            ]),
        };

        let labeled =
            semantic_label_rule_instances(&model, &rule, None, &DpStrategyCancellation::default())
                .unwrap();
        let rendered = labeled
            .iter()
            .map(|rule| format!("{} -> {}", rule.lhs(), rule.rhs()))
            .collect::<BTreeSet<_>>();

        assert_eq!(labeled.len(), 2);
        assert!(rendered.iter().any(|rule| rule.contains("__66__0")));
        assert!(rendered.iter().any(|rule| rule.contains("__66__1")));
    }

    #[test]
    fn unary_semantic_labeling_candidates_include_affine_offset_model() {
        let arities = BTreeMap::from([
            (Symbol::new("f1"), 1),
            (Symbol::new("f1#"), 1),
            (Symbol::new("g1"), 1),
        ]);
        let base_model = SemanticLabelingModel {
            carrier_size: 2,
            arities: arities.clone(),
            interpretations: BTreeMap::new(),
        };
        let symbols = arities.into_iter().collect::<Vec<_>>();
        let candidate = unary_affine_semantic_labeling_candidate(&base_model, &symbols)
            .expect("unary affine candidate");
        let affine = SlArithmeticFunction::Sum(vec![
            SlArithmeticFunction::Constant(1),
            SlArithmeticFunction::Argument(0),
        ]);

        assert_eq!(
            candidate.interpretations.get(&Symbol::new("f1")),
            Some(&affine)
        );
        assert_eq!(
            candidate.interpretations.get(&Symbol::new("f1#")),
            Some(&SlArithmeticFunction::Constant(0))
        );
        assert_eq!(
            candidate.interpretations.get(&Symbol::new("g1")),
            Some(&SlArithmeticFunction::Constant(0))
        );
        assert!(semantic_labeling_function_candidates(1, 2, false).contains(&affine));
    }

    #[test]
    fn distinguished_constant_semantic_labeling_candidates_cover_tower_model() {
        let symbols = vec![
            (Symbol::new("a"), 0),
            (Symbol::new("b"), 0),
            (Symbol::new("f#"), 3),
            (Symbol::new("s"), 1),
        ];
        let base_model = SemanticLabelingModel {
            carrier_size: 2,
            arities: symbols.iter().cloned().collect(),
            interpretations: BTreeMap::new(),
        };
        let candidates = distinguished_constant_semantic_labeling_candidates(&base_model, &symbols);
        let tower = candidates
            .iter()
            .find(|candidate| {
                candidate.interpretations.get(&Symbol::new("a"))
                    == Some(&SlArithmeticFunction::Constant(1))
            })
            .expect("the nullary constructor a should be distinguished");

        assert_eq!(
            tower.interpretations.get(&Symbol::new("b")),
            Some(&SlArithmeticFunction::Constant(0))
        );
        assert_eq!(
            tower.interpretations.get(&Symbol::new("f#")),
            Some(&SlArithmeticFunction::Constant(0))
        );
        assert_eq!(
            tower.interpretations.get(&Symbol::new("s")),
            Some(&SlArithmeticFunction::Constant(0))
        );
    }

    #[test]
    fn constructor_projection_affine_candidates_cover_marking_model() {
        let symbols = vec![
            (Symbol::new("a"), 0),
            (Symbol::new("active"), 1),
            (Symbol::new("b"), 0),
            (Symbol::new("f"), 2),
            (Symbol::new("mark"), 1),
            (Symbol::new("ok"), 1),
            (Symbol::new("proper"), 1),
            (Symbol::new("top"), 1),
            (Symbol::new("top#"), 1),
        ];
        let base_model = SemanticLabelingModel {
            carrier_size: 2,
            arities: symbols.iter().cloned().collect(),
            interpretations: BTreeMap::new(),
        };
        let trs = Trs::new_with_strategy(
            None,
            BTreeSet::new(),
            vec![
                RewriteRule::new(
                    Term::app("proper", vec![Term::app("a", vec![])]),
                    Term::app("ok", vec![Term::app("a", vec![])]),
                ),
                RewriteRule::new(
                    Term::app("proper", vec![Term::app("b", vec![])]),
                    Term::app("ok", vec![Term::app("b", vec![])]),
                ),
            ],
            RewriteStrategy::Full,
        );
        let affine = SlArithmeticFunction::Sum(vec![
            SlArithmeticFunction::Constant(1),
            SlArithmeticFunction::Argument(0),
        ]);
        let candidate =
            constructor_projection_affine_semantic_labeling_candidates(&trs, &base_model, &symbols)
                .into_iter()
                .find(|candidate| {
                    candidate.interpretations.get(&Symbol::new("a"))
                        == Some(&SlArithmeticFunction::Constant(1))
                        && candidate.interpretations.get(&Symbol::new("f"))
                            == Some(&SlArithmeticFunction::Argument(0))
                        && candidate.interpretations.get(&Symbol::new("mark")) == Some(&affine)
                })
                .expect("projection/affine marking model");

        for symbol in ["ok", "proper"] {
            assert_eq!(
                candidate.interpretations.get(&Symbol::new(symbol)),
                Some(&SlArithmeticFunction::Argument(0))
            );
        }
        for symbol in ["active", "top", "top#"] {
            assert_eq!(
                candidate.interpretations.get(&Symbol::new(symbol)),
                Some(&SlArithmeticFunction::Constant(0))
            );
        }
    }

    #[test]
    fn binary_two_constant_semantic_labeling_candidate_uses_lhs_roles() {
        let symbols = vec![
            (Symbol::new("a"), 0),
            (Symbol::new("b"), 0),
            (Symbol::new("f"), 2),
            (Symbol::new("f#"), 2),
        ];
        let base_model = SemanticLabelingModel {
            carrier_size: 2,
            arities: symbols.iter().cloned().collect(),
            interpretations: BTreeMap::new(),
        };
        let lhs_symbols = BTreeSet::from([Symbol::new("a"), Symbol::new("f"), Symbol::new("f#")]);
        let candidate =
            binary_two_constant_semantic_labeling_candidate(&base_model, &symbols, &lhs_symbols)
                .expect("binary two-constant semantic-labeling candidate");

        assert_eq!(
            candidate.interpretations.get(&Symbol::new("a")),
            Some(&SlArithmeticFunction::Constant(1))
        );
        for symbol in ["b", "f", "f#"] {
            assert_eq!(
                candidate.interpretations.get(&Symbol::new(symbol)),
                Some(&SlArithmeticFunction::Constant(0))
            );
        }
    }

    #[test]
    fn binary_marked_semantic_labeling_candidates_cover_z21_projection_model() {
        let symbols = vec![
            (Symbol::new("a"), 0),
            (Symbol::new("b"), 0),
            (Symbol::new("f"), 2),
            (Symbol::new("f#"), 2),
        ];
        let base_model = SemanticLabelingModel {
            carrier_size: 2,
            arities: symbols.iter().cloned().collect(),
            interpretations: BTreeMap::new(),
        };
        let pair_symbols = BTreeSet::from([Symbol::new("a"), Symbol::new("f"), Symbol::new("f#")]);
        let candidates =
            binary_marked_semantic_labeling_candidates(&base_model, &symbols, &pair_symbols);

        assert!(candidates.iter().any(|candidate| {
            candidate.interpretations.get(&Symbol::new("a"))
                == Some(&SlArithmeticFunction::Constant(0))
                && candidate.interpretations.get(&Symbol::new("b"))
                    == Some(&SlArithmeticFunction::Constant(1))
                && candidate.interpretations.get(&Symbol::new("f"))
                    == Some(&SlArithmeticFunction::Argument(0))
                && candidate.interpretations.get(&Symbol::new("f#"))
                    == Some(&SlArithmeticFunction::Constant(0))
        }));
        assert_eq!(
            candidates[0].interpretations.get(&Symbol::new("b")),
            Some(&SlArithmeticFunction::Constant(1))
        );
        assert_eq!(
            candidates[0].interpretations.get(&Symbol::new("f")),
            Some(&SlArithmeticFunction::Argument(0))
        );
    }

    #[test]
    fn binary_marked_semantic_labeling_candidates_cover_z22_constant_model() {
        let symbols = vec![
            (Symbol::new("a"), 0),
            (Symbol::new("b"), 0),
            (Symbol::new("c"), 0),
            (Symbol::new("f"), 2),
            (Symbol::new("f#"), 2),
        ];
        let base_model = SemanticLabelingModel {
            carrier_size: 2,
            arities: symbols.iter().cloned().collect(),
            interpretations: BTreeMap::new(),
        };
        let candidates =
            binary_marked_semantic_labeling_candidates(&base_model, &symbols, &BTreeSet::new());

        assert!(candidates.iter().any(|candidate| {
            candidate.interpretations.get(&Symbol::new("a"))
                == Some(&SlArithmeticFunction::Constant(1))
                && candidate.interpretations.get(&Symbol::new("b"))
                    == Some(&SlArithmeticFunction::Constant(0))
                && candidate.interpretations.get(&Symbol::new("c"))
                    == Some(&SlArithmeticFunction::Constant(0))
                && candidate.interpretations.get(&Symbol::new("f"))
                    == Some(&SlArithmeticFunction::Constant(0))
                && candidate.interpretations.get(&Symbol::new("f#"))
                    == Some(&SlArithmeticFunction::Constant(0))
        }));
    }

    #[test]
    fn marked_unary_identity_candidates_cover_z27_model() {
        let symbols = vec![
            (Symbol::new("0"), 0),
            (Symbol::new("1"), 0),
            (Symbol::new("f"), 3),
            (Symbol::new("f#"), 3),
            (Symbol::new("g"), 1),
        ];
        let base_model = SemanticLabelingModel {
            carrier_size: 2,
            arities: symbols.iter().cloned().collect(),
            interpretations: BTreeMap::new(),
        };

        let candidates =
            marked_with_unary_identity_semantic_labeling_candidates(&base_model, &symbols);

        assert_eq!(candidates.len(), 2);
        let candidate = &candidates[0];
        assert_eq!(
            candidate.interpretations.get(&Symbol::new("0")),
            Some(&SlArithmeticFunction::Constant(0))
        );
        assert_eq!(
            candidate.interpretations.get(&Symbol::new("1")),
            Some(&SlArithmeticFunction::Constant(1))
        );
        assert_eq!(
            candidate.interpretations.get(&Symbol::new("g")),
            Some(&SlArithmeticFunction::Argument(0))
        );
        for symbol in ["f", "f#"] {
            assert_eq!(
                candidate.interpretations.get(&Symbol::new(symbol)),
                Some(&SlArithmeticFunction::Constant(0))
            );
        }
    }

    #[test]
    fn unary_dimension4_arctic_templates_are_well_formed() {
        let arities = BTreeMap::from([
            ("f1".to_string(), 1),
            ("f1#".to_string(), 1),
            ("g1".to_string(), 1),
        ]);

        for variant in 0..2 {
            let candidate = unary_arctic_dimension4_candidate(&arities, variant)
                .expect("dimension-four unary Arctic candidate");
            assert!(arctic_matrix_interpretations_are_well_formed(
                &candidate,
                4,
                ArcticMatrixDomain::Naturals,
            ));
        }
    }

    #[test]
    fn integer_arctic_solver_parameter_roundtrips_and_rejects_unknown_backends() {
        for suffix in ["", ",candidate=1"] {
            for solver in ["z3", "cvc5"] {
                let atom = format!("integer-arctic-matrix(dimension=2,min-value=-2,max-value=3,solver={solver}{suffix})");
                let parsed = DpStrategy::parse(&atom).unwrap();
                let DpStrategy::Processor(processor) = &parsed else { panic!("atomic strategy") };
                let emitted = processor.to_strategy_atom();
                assert!(emitted.contains(&format!("solver={solver}")));
                assert_eq!(DpStrategy::parse(&emitted).unwrap(), parsed);
            }
        }
        assert!(DpStrategy::parse("integer-arctic-matrix(min=-1,max=1,solver=unknown)").is_err());
    }

    #[test]
    fn integer_arctic_synthesis_uses_negative_coefficients() {
        let x = Term::var("x");
        let successor = Term::app("step", vec![x.clone()]);
        let predecessor = Term::app("pred", vec![successor.clone()]);
        let pairs = [DependencyPair::new_for_test(
            Term::app("top", vec![successor]),
            Term::app("top", vec![predecessor.clone()]),
        )];
        // The rule forces pred's coefficient to be finite; strict deletion
        // forces it below zero. A natural-Arctic search cannot satisfy both.
        let rules = [RewriteRule::new(predecessor, x)];
        for (solver, bitvectors) in [(None,false),(Some("cvc5"),false),(None,true),(Some("cvc5"),true)] {
            let options = DpOptions {
                smt_solver: solver.map(str::to_owned),
                ..DpOptions::default()
            };
            let model = synthesize_integer_arctic_matrix_interpretation_with_symmetry(
                &pairs, &rules, 1, -1, 1, 3, 1, &options, None,
                Some(Instant::now() + Duration::from_secs(15)),
                false, bitvectors, !bitvectors, false,
            ).expect("signed coefficient search");
            assert!(model.values().flat_map(|m| &m.coefficients)
                .flatten().flatten().any(|v| *v < 0 && *v != i64::MIN));
            assert!(checked_component_removal_by_arctic_matrix(
                &pairs, &rules, &model, ArcticMatrixDomain::Integers,
                DpSearchBackend::Smt, None,
            ).is_some());
        }
    }

    #[test]
    fn integer_arctic_well_formedness_allows_negative_finite_entries() {
        let interpretation = MatrixInterpretation {
            constant: vec![-1],
            coefficients: vec![vec![vec![0]]],
        };
        assert!(arctic_matrix_interpretations_are_well_formed(
            &BTreeMap::from([("f#".to_string(), interpretation.clone())]),
            1,
            ArcticMatrixDomain::Integers,
        ));
        assert!(!arctic_matrix_interpretations_are_well_formed(
            &BTreeMap::from([("f#".to_string(), interpretation)]),
            1,
            ArcticMatrixDomain::Naturals,
        ));
    }

    #[test]
    fn integer_arctic_well_formedness_rejects_all_negative_distinguished_entries() {
        let interpretation = MatrixInterpretation {
            constant: vec![-1],
            coefficients: vec![vec![vec![-1]]],
        };
        assert!(!arctic_matrix_interpretations_are_well_formed(
            &BTreeMap::from([("f#".to_string(), interpretation)]),
            1,
            ArcticMatrixDomain::Integers,
        ));
    }

    #[test]
    fn semantic_labeling_keeps_distinct_argument_labels_with_equal_interpretation() {
        let x = Variable::new("x");
        let rule = RewriteRule::new(
            Term::app("f", vec![Term::Var(x.clone())]),
            Term::app("g", vec![Term::Var(x.clone())]),
        );
        let model = SemanticLabelingModel {
            carrier_size: 2,
            arities: BTreeMap::from([(Symbol::new("f"), 1), (Symbol::new("g"), 1)]),
            interpretations: BTreeMap::from([
                (Symbol::new("f"), SlArithmeticFunction::Constant(0)),
                (Symbol::new("g"), SlArithmeticFunction::Constant(0)),
            ]),
        };

        let labeled =
            semantic_label_rule_instances(&model, &rule, None, &DpStrategyCancellation::default())
                .unwrap();
        let labeled_lhss = semantic_label_terms(
            &model,
            &[rule.lhs().clone()],
            None,
            &DpStrategyCancellation::default(),
        )
        .unwrap();

        assert_eq!(labeled.len(), 2);
        assert_eq!(labeled_lhss.len(), 2);
    }

    #[test]
    fn semantic_labeling_does_not_promote_q_lhss_to_rules() {
        let x = Variable::new("x");
        let keep = RewriteRule::new(
            Term::app("g", vec![Term::Var(x.clone())]),
            Term::app("a", vec![]),
        );
        let irrelevant = RewriteRule::new(
            Term::app("h", vec![Term::Var(x.clone())]),
            Term::app("h", vec![Term::Var(x.clone())]),
        );
        let trs = Trs::new_with_strategy(
            None,
            BTreeSet::from([x.clone()]),
            vec![keep.clone(), irrelevant.clone()],
            RewriteStrategy::Innermost,
        );
        let pair = DependencyPair::new_for_test(
            Term::app("F#", vec![Term::Var(x.clone())]),
            Term::app("G#", vec![Term::Var(x)]),
        );
        let q_lhss = vec![keep.lhs().clone()];

        let rules = semantic_labeling_context_rules(&trs, &[pair], Some(&q_lhss));

        assert_eq!(rules, vec![keep, irrelevant]);
    }

    #[test]
    fn semantic_labeling_covers_symbols_that_occur_only_in_q() {
        let x = Variable::new("x");
        let trs = Trs::new_with_strategy(
            None,
            BTreeSet::from([x.clone()]),
            vec![RewriteRule::new(
                Term::app("f", vec![Term::Var(x.clone())]),
                Term::app("f", vec![Term::Var(x.clone())]),
            )],
            RewriteStrategy::Innermost,
        );
        let pair = DependencyPair::new_for_test(
            Term::app("F#", vec![Term::Var(x.clone())]),
            Term::app("F#", vec![Term::Var(x.clone())]),
        );
        let q_lhss = vec![Term::app("q", vec![Term::app("g", vec![Term::Var(x)])])];
        let constrained = semantic_labeling_arities(&trs, &[pair.clone()], None);
        let arities = semantic_labeling_arities(&trs, &[pair], Some(&q_lhss));
        let mut interpretations = arities
            .keys()
            .cloned()
            .map(|symbol| (symbol, SlArithmeticFunction::Constant(0)))
            .collect::<BTreeMap<_, _>>();
        interpretations.insert(Symbol::new("f"), SlArithmeticFunction::Argument(0));
        interpretations.insert(Symbol::new("F#"), SlArithmeticFunction::Argument(0));
        let model = SemanticLabelingModel {
            carrier_size: 2,
            arities,
            interpretations,
        };

        assert!(!constrained.contains_key(&Symbol::new("q")));
        assert!(!constrained.contains_key(&Symbol::new("g")));
        let labeled =
            semantic_label_terms(&model, &q_lhss, None, &DpStrategyCancellation::default())
                .unwrap();
        assert_eq!(labeled.len(), 2);
    }

    #[test]
    fn semantic_labeling_expansion_obeys_expired_deadline() {
        let variables = (0..8)
            .map(|index| Variable::new(&format!("x{index}")))
            .collect::<Vec<_>>();
        let rule = RewriteRule::new(
            Term::app(
                "f",
                variables.iter().cloned().map(Term::Var).collect::<Vec<_>>(),
            ),
            Term::app(
                "g",
                variables.iter().cloned().map(Term::Var).collect::<Vec<_>>(),
            ),
        );
        let model = SemanticLabelingModel {
            carrier_size: 2,
            arities: BTreeMap::from([(Symbol::new("f"), 8), (Symbol::new("g"), 8)]),
            interpretations: BTreeMap::from([
                (Symbol::new("f"), SlArithmeticFunction::Argument(0)),
                (Symbol::new("g"), SlArithmeticFunction::Argument(0)),
            ]),
        };
        let deadline = Instant::now()
            .checked_sub(Duration::from_millis(1))
            .expect("instant subtraction within supported range");

        assert!(
            semantic_label_rule_instances(
                &model,
                &rule,
                Some(deadline),
                &DpStrategyCancellation::default(),
            )
            .is_none()
        );
    }

    #[test]
    fn dp_parallel_returns_without_waiting_for_cancelled_smt_branch() {
        let fake_solver = fake_sleeping_solver("dp-parallel");
        let variables = BTreeSet::from([Variable::new("x")]);
        let trs = Trs::new(
            None,
            variables,
            vec![RewriteRule::new(
                Term::app("f", vec![Term::app("s", vec![Term::var("x")])]),
                Term::app("f", vec![Term::var("x")]),
            )],
        );

        let started = Instant::now();
        let options = DpOptions {
            smt_solver: Some(fake_solver.to_string_lossy().into_owned()),
            ..DpOptions::default()
        };
        let strategy = DpStrategy::parse("parallel(sat-poly(1,1,4,1) | size-change)").unwrap();
        let proof = solve_dependency_pairs_with_strategy(&trs, &options, &strategy, None)
            .expect("size-change branch should prove the component");

        assert_eq!(proof.removed_pairs, 1);
        assert!(started.elapsed() < Duration::from_secs(2));
    }

    #[test]
    fn size_change_closure_observes_thread_cancellation() {
        let flag = new_cancellation_flag();
        cancel(&flag);
        let graph = SizeChangeClosureGraph {
            source: Symbol::new("F"),
            target: Symbol::new("F"),
            source_arity: 2,
            target_arity: 2,
            edges: BTreeMap::from([((1, 2), false), ((2, 1), false)]),
        };

        let started = Instant::now();
        let terminating = with_cancellation_flags(vec![flag], || {
            size_change_closure_is_terminating(vec![graph])
        });

        assert!(!terminating);
        assert!(started.elapsed() < Duration::from_millis(100));
    }

    #[test]
    fn size_change_closure_uses_dependency_edges_between_pairs() {
        let weak = SizeChangeClosureGraph {
            source: Symbol::new("app#"),
            target: Symbol::new("app#"),
            source_arity: 2,
            target_arity: 2,
            edges: BTreeMap::from([((2, 2), false)]),
        };
        let strict = SizeChangeClosureGraph {
            edges: BTreeMap::from([((2, 2), true)]),
            ..weak.clone()
        };

        assert!(!size_change_closure_is_terminating(vec![
            weak.clone(),
            strict.clone(),
        ]));
        assert!(size_change_indexed_closure_is_terminating(
            vec![(0, 0, weak), (1, 1, strict)],
            &[vec![1], vec![0]],
        ));
    }

    #[test]
    fn residual_dp_graph_score_observes_expired_deadline() {
        let variables = BTreeSet::from([Variable::new("x")]);
        let trs = Trs::new(
            None,
            variables,
            vec![RewriteRule::new(
                Term::app("f", vec![Term::var("x")]),
                Term::app("f", vec![Term::var("x")]),
            )],
        );
        let pairs = vec![DependencyPair::new_for_test(
            Term::app("F#", vec![Term::var("x")]),
            Term::app("F#", vec![Term::var("x")]),
        )];
        let deadline = Instant::now()
            .checked_sub(Duration::from_millis(1))
            .expect("instant subtraction within supported range");
        let started = Instant::now();

        let score = residual_dp_graph_score(
            &trs,
            &pairs,
            trs.rules(),
            &[],
            Some(deadline),
            &DpStrategyCancellation::default(),
        );

        assert!(score.is_none());
        assert!(started.elapsed() < Duration::from_millis(100));
    }

    #[test]
    fn residual_dp_graph_score_prefers_smaller_cyclic_components() {
        let one_large_cycle = vec![vec![1], vec![2], vec![3], vec![0]];
        let two_small_cycles = vec![vec![1], vec![0], vec![3], vec![2]];
        let cycle_and_acyclic_pair = vec![vec![1], vec![0], vec![3], vec![]];

        assert!(
            residual_dp_graph_score_from_graph(&two_small_cycles)
                < residual_dp_graph_score_from_graph(&one_large_cycle)
        );
        assert!(
            residual_dp_graph_score_from_graph(&cycle_and_acyclic_pair)
                < residual_dp_graph_score_from_graph(&two_small_cycles)
        );
    }

    fn fake_sleeping_solver(name: &str) -> std::path::PathBuf {
        let path = std::env::temp_dir().join(format!(
            "ferrum-{name}-fake-solver-{}.sh",
            std::process::id()
        ));
        fs::write(&path, "#!/bin/sh\nsleep 5\necho unknown\n").unwrap();
        let mut permissions = fs::metadata(&path).unwrap().permissions();
        permissions.set_mode(0o755);
        fs::set_permissions(&path, permissions).unwrap();
        path
    }

    #[test]
    fn unification_rejects_transitive_cycles() {
        let mut substitution = BTreeMap::new();
        assert!(unify_terms(
            &Term::var("x"),
            &Term::app("f", vec![Term::var("y")]),
            &mut substitution
        ));
        assert!(!unify_terms(
            &Term::var("y"),
            &Term::app("g", vec![Term::var("x")]),
            &mut substitution
        ));
    }

    fn strategy_contains_parallel(strategy: &DpStrategy) -> bool {
        match strategy {
            DpStrategy::Parallel { .. } => true,
            DpStrategy::Sequence(strategies)
            | DpStrategy::Pipeline(strategies)
            | DpStrategy::Choice(strategies) => strategies.iter().any(strategy_contains_parallel),
            DpStrategy::Repeat { strategy, .. }
            | DpStrategy::Timeout { strategy, .. }
            | DpStrategy::Delay { strategy, .. } => strategy_contains_parallel(strategy),
            DpStrategy::Processor(_) => false,
        }
    }

    fn strategy_contains_processor(strategy: &DpStrategy, processor: &DpStrategyProcessor) -> bool {
        match strategy {
            DpStrategy::Processor(candidate) => candidate == processor,
            DpStrategy::Sequence(strategies)
            | DpStrategy::Pipeline(strategies)
            | DpStrategy::Choice(strategies)
            | DpStrategy::Parallel { strategies, .. } => strategies
                .iter()
                .any(|strategy| strategy_contains_processor(strategy, processor)),
            DpStrategy::Repeat { strategy, .. }
            | DpStrategy::Timeout { strategy, .. }
            | DpStrategy::Delay { strategy, .. } => {
                strategy_contains_processor(strategy, processor)
            }
        }
    }

    #[test]
    fn default_ladder_places_graph_and_component_work_before_semantic_labeling() {
        let DpStrategy::Sequence(stages) =
            DpStrategy::default_refinement_ladder(RewriteStrategy::Innermost)
        else {
            panic!("default refinement ladder should be a sequence");
        };
        let semlab_index = stages
            .iter()
            .position(|stage| {
                strategy_contains_processor(stage, &DpStrategyProcessor::SemanticLabeling)
            })
            .expect("semantic labeling stage should be present");

        assert!(
            stages[..semlab_index]
                .iter()
                .any(|stage| strategy_contains_processor(
                    stage,
                    &DpStrategyProcessor::DependencyGraph
                ))
        );
        assert!(
            stages[..semlab_index]
                .iter()
                .any(|stage| strategy_contains_processor(stage, &DpStrategyProcessor::Subterm))
        );
        assert!(
            stages[..semlab_index]
                .iter()
                .any(|stage| strategy_contains_processor(stage, &DpStrategyProcessor::SizeChange))
        );
    }

    #[test]
    fn proves_decreasing_recursive_dp_component() {
        let variables = BTreeSet::from([Variable::new("x")]);
        let trs = Trs::new(
            None,
            variables,
            vec![RewriteRule::new(
                Term::app("f", vec![Term::app("s", vec![Term::var("x")])]),
                Term::app("f", vec![Term::var("x")]),
            )],
        );
        let proof = solve_dependency_pairs(&trs, &DpOptions::default()).unwrap();
        assert_eq!(proof.initial_pairs, 1);
        assert_eq!(proof.removed_pairs, 1);
    }

    #[test]
    fn computes_usable_rules_from_pair_rhs() {
        let variables = BTreeSet::from([Variable::new("x")]);
        let trs = Trs::new_with_strategy(
            None,
            variables,
            vec![
                RewriteRule::new(
                    Term::app("f", vec![Term::var("x")]),
                    Term::app(
                        "f",
                        vec![Term::app("g", vec![Term::app("s", vec![Term::var("x")])])],
                    ),
                ),
                RewriteRule::new(
                    Term::app("g", vec![Term::app("s", vec![Term::var("x")])]),
                    Term::app("g", vec![Term::var("x")]),
                ),
            ],
            RewriteStrategy::Innermost,
        );
        let pairs = dependency_pairs(&trs);
        let usable = usable_rules(&trs, &pairs);
        assert_eq!(usable.len(), 1);
    }

    #[test]
    fn ag01_3_22_uses_ceta_match_cap_usable_rule_closure() {
        let trs =
            crate::parsing::parse_ari_trs(None, include_str!("../../tests/fixtures/ag01_3_22.ari"))
                .unwrap();
        let pairs = dependency_pairs(&trs);
        let graph = dependency_pair_graph(&trs, &pairs);
        let component = strongly_connected_components(&graph)
            .into_iter()
            .find(|component| component.len() == 3)
            .expect("AProVE's three-pair times component");
        let component_pairs = component
            .iter()
            .map(|index| pairs[*index].clone())
            .collect::<Vec<_>>();

        let usable = usable_rules(&trs, &component_pairs);
        let usable_indices = trs
            .rules()
            .iter()
            .enumerate()
            .filter_map(|(index, rule)| usable.contains(rule).then_some(index))
            .collect::<Vec<_>>();

        assert_eq!(usable_indices, vec![1, 3, 4]);
    }

    #[test]
    fn gen9_standard_matrix_component_uses_only_usable_rules() {
        let trs = Trs::new(
            None,
            BTreeSet::from([Variable::new("x"), Variable::new("y"), Variable::new("z")]),
            vec![
                RewriteRule::new(
                    Term::app(
                        "c",
                        vec![
                            Term::app(
                                "c",
                                vec![Term::var("z"), Term::var("y"), Term::app("a", vec![])],
                            ),
                            Term::app("a", vec![]),
                            Term::app("a", vec![]),
                        ],
                    ),
                    Term::app("b", vec![Term::var("z"), Term::var("y")]),
                ),
                RewriteRule::new(
                    Term::app(
                        "f",
                        vec![Term::app(
                            "c",
                            vec![Term::var("x"), Term::var("y"), Term::var("z")],
                        )],
                    ),
                    Term::app(
                        "c",
                        vec![
                            Term::var("z"),
                            Term::app(
                                "f",
                                vec![Term::app("b", vec![Term::var("y"), Term::var("z")])],
                            ),
                            Term::app("a", vec![]),
                        ],
                    ),
                ),
                RewriteRule::new(
                    Term::app(
                        "b",
                        vec![
                            Term::var("z"),
                            Term::app(
                                "b",
                                vec![
                                    Term::app(
                                        "c",
                                        vec![
                                            Term::app("a", vec![]),
                                            Term::var("y"),
                                            Term::app("a", vec![]),
                                        ],
                                    ),
                                    Term::app("f", vec![Term::app("f", vec![Term::var("x")])]),
                                ],
                            ),
                        ],
                    ),
                    Term::app(
                        "c",
                        vec![
                            Term::app(
                                "c",
                                vec![Term::var("y"), Term::app("a", vec![]), Term::var("z")],
                            ),
                            Term::var("z"),
                            Term::var("x"),
                        ],
                    ),
                ),
            ],
        );
        let pair = dependency_pairs(&trs)
            .into_iter()
            .find(|pair| {
                pair.lhs()
                    .root_symbol()
                    .is_some_and(|symbol| symbol.as_str() == "f#")
                    && pair
                        .rhs()
                        .root_symbol()
                        .is_some_and(|symbol| symbol.as_str() == "f#")
            })
            .expect("recursive f# pair");
        let pairs = vec![pair];
        let usable = reduction_pair_context_rules(&trs, &pairs, None);

        assert_eq!(usable.len(), 2);
        assert!(usable.iter().all(|rule| {
            rule.lhs()
                .root_symbol()
                .is_some_and(|symbol| matches!(symbol.as_str(), "b" | "c"))
        }));
        assert!(
            synthesize_matrix_interpretation_for_component(
                &pairs,
                &usable,
                &DpOptions {
                    max_polynomial_constant: 2,
                    max_polynomial_coefficient: 1,
                    ..DpOptions::default()
                },
                2,
                None,
                None,
                None,
                None,
                None,
            )
            .is_some()
        );
    }

    #[test]
    fn usable_rules_include_defined_marked_rhs_root_in_residual_problem() {
        let variables = BTreeSet::from([Variable::new("x")]);
        let trs = Trs::new(
            None,
            variables,
            vec![
                RewriteRule::new(
                    Term::app("o#", vec![Term::app("a", Vec::new())]),
                    Term::app("a#", Vec::new()),
                ),
                RewriteRule::new(Term::app("a#", Vec::new()), Term::app("done", Vec::new())),
            ],
        );
        let pairs = vec![DependencyPair::new_for_test(
            Term::app("p#", vec![Term::var("x")]),
            Term::app("o#", vec![Term::var("x")]),
        )];

        let usable = reduction_pair_context_rules(&trs, &pairs, None);
        assert_eq!(usable, trs.rules());
    }

    #[test]
    fn subterm_processors_reject_rhs_root_defined_by_active_marked_rule() {
        let pairs = vec![DependencyPair::new_for_test(
            Term::app("j#", vec![Term::var("x")]),
            Term::app("g#", vec![Term::var("x")]),
        )];
        let marked_rules = vec![RewriteRule::new(
            Term::app("g#", vec![Term::app("a", vec![Term::var("x")])]),
            Term::app("g#", vec![Term::var("x")]),
        )];

        assert!(!dp_rhs_roots_are_constructors(&pairs, &marked_rules));
        assert!(dp_rhs_roots_are_constructors(&pairs, &[]));
    }

    #[test]
    fn innermost_usable_rules_keep_closure_rules_from_q_component() {
        let variables = BTreeSet::from([Variable::new("x"), Variable::new("y")]);
        let trs = Trs::new_with_strategy(
            None,
            variables,
            vec![
                RewriteRule::new(
                    Term::app("pred", vec![Term::app("s", vec![Term::var("x")])]),
                    Term::var("x"),
                ),
                RewriteRule::new(
                    Term::app("minus", vec![Term::var("x"), Term::app("|0|", Vec::new())]),
                    Term::var("x"),
                ),
                RewriteRule::new(
                    Term::app(
                        "minus",
                        vec![Term::var("x"), Term::app("s", vec![Term::var("y")])],
                    ),
                    Term::app(
                        "pred",
                        vec![Term::app("minus", vec![Term::var("x"), Term::var("y")])],
                    ),
                ),
                RewriteRule::new(
                    Term::app(
                        "quot",
                        vec![
                            Term::app("s", vec![Term::var("x")]),
                            Term::app("s", vec![Term::var("y")]),
                        ],
                    ),
                    Term::app(
                        "quot",
                        vec![
                            Term::app("minus", vec![Term::var("x"), Term::var("y")]),
                            Term::app("s", vec![Term::var("y")]),
                        ],
                    ),
                ),
            ],
            RewriteStrategy::Innermost,
        );
        let pairs = dependency_pairs(&trs);
        let component = vec![
            pairs
                .iter()
                .find(|pair| {
                    pair.lhs()
                        .root_symbol()
                        .is_some_and(|symbol| symbol.as_str() == "quot#")
                })
                .cloned()
                .expect("quot# pair"),
        ];
        let initial_lhss = trs
            .rules()
            .iter()
            .map(|rule| rule.lhs().clone())
            .collect::<Vec<_>>();
        let active_rules = usable_rules(&trs, &component);
        let lhss = remaining_innermost_lhss(&initial_lhss, &active_rules, &component);
        let usable = usable_rules_in_innermost_context(&trs, &component, Some(&lhss));

        assert!(usable.iter().any(|rule| {
            rule.lhs()
                .root_symbol()
                .is_some_and(|symbol| symbol.as_str() == "pred")
        }));
        assert_eq!(usable.len(), 3);
    }

    #[test]
    fn innermost_usable_rules_are_complete_for_each_reachable_root() {
        let variables = BTreeSet::from([Variable::new("x"), Variable::new("y")]);
        let rules = vec![
            RewriteRule::new(
                Term::app("le", vec![Term::app("|0|", Vec::new()), Term::var("y")]),
                Term::app("true", Vec::new()),
            ),
            RewriteRule::new(
                Term::app(
                    "le",
                    vec![
                        Term::app("s", vec![Term::var("x")]),
                        Term::app("|0|", Vec::new()),
                    ],
                ),
                Term::app("false", Vec::new()),
            ),
            RewriteRule::new(
                Term::app(
                    "le",
                    vec![
                        Term::app("s", vec![Term::var("x")]),
                        Term::app("s", vec![Term::var("y")]),
                    ],
                ),
                Term::app("le", vec![Term::var("x"), Term::var("y")]),
            ),
        ];
        let trs =
            Trs::new_with_strategy(None, variables, rules.clone(), RewriteStrategy::Innermost);
        let pairs = vec![DependencyPair::new_for_test(
            Term::app("quot#", vec![Term::var("x"), Term::var("y")]),
            Term::app(
                "if_quot#",
                vec![
                    Term::app("le", vec![Term::var("x"), Term::var("y")]),
                    Term::var("x"),
                    Term::var("y"),
                ],
            ),
        )];
        let q_lhss = rules
            .iter()
            .map(|rule| rule.lhs().clone())
            .collect::<Vec<_>>();

        assert_eq!(
            usable_rules_in_innermost_context(&trs, &pairs, Some(&q_lhss)),
            rules
        );
    }

    #[test]
    fn innermost_usable_rules_do_not_revive_q_blocked_root_siblings() {
        let rules = vec![
            RewriteRule::new(
                Term::app("mark", vec![Term::app("b", Vec::new())]),
                Term::app("done", Vec::new()),
            ),
            RewriteRule::new(
                Term::app("mark", vec![Term::app("f", vec![Term::var("x")])]),
                Term::app("active", vec![Term::app("f", vec![Term::var("x")])]),
            ),
            RewriteRule::new(
                Term::app("active", vec![Term::app("f", vec![Term::var("x")])]),
                Term::app("mark", vec![Term::var("x")]),
            ),
        ];
        let trs = Trs::new_with_strategy(
            None,
            BTreeSet::from([Variable::new("x")]),
            rules.clone(),
            RewriteStrategy::Innermost,
        );
        let pairs = vec![DependencyPair::new_for_test(
            Term::app("start#", vec![Term::var("x")]),
            Term::app(
                "mark#",
                vec![Term::app("mark", vec![Term::app("b", Vec::new())])],
            ),
        )];
        let q_lhss = rules
            .iter()
            .map(|rule| rule.lhs().clone())
            .collect::<Vec<_>>();

        let usable = usable_rules_in_innermost_context(&trs, &pairs, Some(&q_lhss));

        assert_eq!(usable, vec![rules[0].clone()]);
    }

    #[test]
    fn innermost_reduction_pair_rules_close_rhs_of_root_completed_siblings() {
        let rules = vec![
            RewriteRule::new(
                Term::app("mark", vec![Term::app("b", Vec::new())]),
                Term::app("done", Vec::new()),
            ),
            RewriteRule::new(
                Term::app("mark", vec![Term::app("f", vec![Term::var("x")])]),
                Term::app("active", vec![Term::app("f", vec![Term::var("x")])]),
            ),
            RewriteRule::new(
                Term::app("active", vec![Term::app("f", vec![Term::var("x")])]),
                Term::app("mark", vec![Term::var("x")]),
            ),
        ];
        let trs = Trs::new_with_strategy(
            None,
            BTreeSet::from([Variable::new("x")]),
            rules.clone(),
            RewriteStrategy::Innermost,
        );
        let pairs = vec![DependencyPair::new_for_test(
            Term::app("start#", vec![Term::var("x")]),
            Term::app(
                "mark#",
                vec![Term::app("mark", vec![Term::app("b", Vec::new())])],
            ),
        )];
        let q_lhss = rules
            .iter()
            .map(|rule| rule.lhs().clone())
            .collect::<Vec<_>>();

        let usable = innermost_reduction_pair_usable_rules(&trs, &pairs, &q_lhss);

        assert!(usable.iter().any(|rule| {
            rule.lhs()
                .root_symbol()
                .is_some_and(|symbol| symbol.as_str() == "active")
        }));
    }

    #[test]
    fn various_04_11_q_reduction_exposes_narrowing_rewriting_pipeline() {
        let trs = Trs::new_with_strategy(
            None,
            BTreeSet::from([Variable::new("x"), Variable::new("y")]),
            vec![
                RewriteRule::new(
                    Term::app(
                        "f",
                        vec![
                            Term::app("|0|", vec![]),
                            Term::app("|1|", vec![]),
                            Term::var("x"),
                        ],
                    ),
                    Term::app(
                        "f",
                        vec![
                            Term::app("h", vec![Term::var("x")]),
                            Term::app("h", vec![Term::var("x")]),
                            Term::var("x"),
                        ],
                    ),
                ),
                RewriteRule::new(
                    Term::app("h", vec![Term::app("|0|", vec![])]),
                    Term::app("|0|", vec![]),
                ),
                RewriteRule::new(
                    Term::app(
                        "h",
                        vec![Term::app("g", vec![Term::var("x"), Term::var("y")])],
                    ),
                    Term::var("y"),
                ),
            ],
            RewriteStrategy::Innermost,
        );
        let component = vec![
            dependency_pairs(&trs)
                .into_iter()
                .find(|pair| {
                    pair.rhs()
                        .root_symbol()
                        .is_some_and(|symbol| symbol.as_str() == "f#")
                })
                .expect("recursive f# pair"),
        ];
        let initial_lhss = trs
            .rules()
            .iter()
            .map(|rule| rule.lhs().clone())
            .collect::<Vec<_>>();
        let usable = usable_rules_in_innermost_context(&trs, &component, Some(&initial_lhss));
        let reduced_lhss = remaining_innermost_lhss(&initial_lhss, &usable, &component);

        assert_eq!(usable.len(), 2);
        assert_eq!(reduced_lhss.len(), 2);
        assert!(reduced_lhss.iter().all(|lhs| {
            lhs.root_symbol()
                .is_some_and(|symbol| symbol.as_str() == "h")
        }));

        let (_, narrowed) = synthesize_narrowing_step_filtered(
            &trs,
            &component,
            &DpOptions::default(),
            Some(&reduced_lhss),
            None,
            &DpStrategyCancellation::default(),
            |_| true,
        )
        .expect("narrowing at the first h(x)");
        let narrowed_graph = dependency_pair_graph_with_rules_deadline(
            &trs,
            &usable,
            &narrowed,
            Some(&reduced_lhss),
            None,
            &DpStrategyCancellation::default(),
        )
        .expect("narrowed graph");

        assert_eq!(narrowed.len(), 2);
        assert_eq!(narrowed_graph, vec![vec![], vec![1]]);

        let cyclic_pair = vec![narrowed[1].clone()];
        let rewrite_usable =
            usable_rules_in_innermost_context(&trs, &cyclic_pair, Some(&reduced_lhss));
        let (_, rewritten) =
            synthesize_rewriting_step(&cyclic_pair, &rewrite_usable).expect("h(g(x,y)) rewrite");
        let final_lhss = remaining_innermost_lhss(&reduced_lhss, &[], &rewritten);
        let final_graph = dependency_pair_graph_with_rules_deadline(
            &trs,
            &[],
            &rewritten,
            Some(&final_lhss),
            None,
            &DpStrategyCancellation::default(),
        )
        .expect("final graph");

        assert!(final_lhss.is_empty());
        assert_eq!(final_graph, vec![Vec::<usize>::new()]);
    }

    #[test]
    fn innermost_reduction_pairs_do_not_conflate_q_with_usable_rules() {
        let q_rule = RewriteRule::new(
            Term::app("a", vec![Term::var("x")]),
            Term::app("b", vec![Term::var("x")]),
        );
        let trs = Trs::new_with_strategy(
            None,
            BTreeSet::from([Variable::new("x")]),
            vec![q_rule.clone()],
            RewriteStrategy::Innermost,
        );
        let pairs = vec![DependencyPair::new_for_test(
            Term::app("j#", vec![Term::app("c", vec![])]),
            Term::app("i#", vec![Term::app("d", vec![])]),
        )];
        let q_lhss = vec![q_rule.lhs().clone()];

        assert!(usable_rules_in_innermost_context(&trs, &pairs, Some(&q_lhss)).is_empty());
        assert!(reduction_pair_context_rules(&trs, &pairs, Some(&q_lhss)).is_empty());
    }

    #[test]
    fn sat_polynomial_synthesizes_component_interpretation() {
        let variables = BTreeSet::from([Variable::new("x")]);
        let trs = Trs::new(
            None,
            variables,
            vec![RewriteRule::new(
                Term::app("f", vec![Term::app("s", vec![Term::var("x")])]),
                Term::app("f", vec![Term::var("x")]),
            )],
        );
        let pairs = dependency_pairs(&trs);
        let usable = usable_rules(&trs, &pairs);
        let options = DpOptions {
            max_polynomial_constant: 1,
            max_polynomial_coefficient: 1,
            ..DpOptions::default()
        };
        let interpretations =
            synthesize_linear_polynomial_with_sat(&pairs, &usable, &options, None).unwrap();
        assert!(
            checked_component_removal_by_polynomial(
                &pairs,
                &usable,
                &interpretations,
                DpSearchBackend::Sat,
                false,
                None,
            )
            .is_some()
        );
    }

    #[test]
    fn sat_polynomial_synthesizes_interpretation_dependent_usable_rules() {
        let local_boolector = ".tools/boolector-src/build/bin/boolector";
        if !command_exists(local_boolector)
            && !command_exists("boolector")
            && !command_exists("z3")
            && !command_exists("cvc5")
        {
            return;
        }
        let pairs = vec![DependencyPair::new_for_test(
            Term::app("f#", vec![Term::app("s", vec![Term::var("x")])]),
            Term::app("f#", vec![Term::var("x")]),
        )];
        let usable = vec![RewriteRule::new(
            Term::app("h", vec![Term::var("x")]),
            Term::app("s", vec![Term::app("h", vec![Term::var("x")])]),
        )];
        let options = DpOptions {
            max_polynomial_constant: 1,
            max_polynomial_coefficient: 1,
            max_polynomial_symbols: 3,
            max_polynomial_arity: 1,
            ..DpOptions::default()
        };

        let interpretations = synthesize_polynomial_with_usable_rules_requiring_strict(
            &pairs, &pairs, None, &usable, &options, None,
        )
        .expect("the unreachable h rule must not constrain the reduction pair");
        let removal = checked_component_removal_by_polynomial_with_usable_rules(
            &pairs,
            &usable,
            &interpretations,
            DpSearchBackend::Sat,
            None,
        )
        .expect("decoded model must pass exact validation");

        assert_eq!(removal.strict_pair_indices, vec![0]);
        assert_eq!(removal.usable_rules, Some(Vec::new()));
    }

    #[test]
    fn rational_polynomial_distinguishes_usable_rules_with_the_same_root() {
        let trs = crate::parsing::parse_ari_trs(None, r#"
            (format TRS) (fun branch 2) (fun stop 0) (fun grow 0) (fun tick 1)
            (rule (branch stop x) x)
            (rule (branch grow x) (tick (branch grow x)))
        "#).unwrap();
        let pairs = vec![DependencyPair::new_for_test(
            Term::app("run#", vec![Term::app("tick", vec![Term::var("x")])]),
            Term::app("run#", vec![Term::app("branch", vec![Term::app("stop", vec![]), Term::var("x")])]),
        )];
        let options = DpOptions {
            max_polynomial_constant: 1,
            max_polynomial_coefficient: 1,
            max_polynomial_symbols: 8,
            max_polynomial_arity: 2,
            ..DpOptions::default()
        };
        let removal = synthesize_rational_linear_with_usable_rules(
            &pairs, trs.rules(), &options, 1, 1,
            Some(Instant::now() + Duration::from_secs(10)), false,
        ).expect("unreachable constructor branch must not constrain the model");
        assert_eq!(removal.strict_pair_indices, vec![0]);
        assert_eq!(removal.usable_rules, Some(vec![trs.rules()[0].clone()]));
    }

    #[test]
    fn bv_model_parser_does_not_cross_boolean_define_fun_boundaries() {
        let output = "sat\n(model\n\
            (define-fun usable_h () Bool false)\n\
            (define-fun c_f () (_ BitVec 2) #b01)\n\
            (define-fun a_f_0 () (_ BitVec 2) #b10))\n";
        let values = parse_bv_values(output).expect("mixed optimized model must parse");

        assert!(!values.contains_key("usable_h"));
        assert_eq!(values.get("c_f"), Some(&1));
        assert_eq!(values.get("a_f_0"), Some(&2));
    }

    #[test]
    fn sat_polynomial_usable_rule_encoding_declines_empty_components() {
        let options = DpOptions::default();
        let arities = BTreeMap::from([("f#".to_string(), 1)]);

        assert!(
            polynomial_usable_rules_bv_script(&[], &[], None, &[], &options, &arities, 1, 2, None,)
                .is_none()
        );
    }

    #[test]
    fn sat_polynomial_usable_rule_encoding_uses_lexicographic_objectives() {
        let pairs = vec![
            DependencyPair::new_for_test(
                Term::app("f#", vec![Term::app("s", vec![Term::var("x")])]),
                Term::app("f#", vec![Term::var("x")]),
            ),
            DependencyPair::new_for_test(
                Term::app("f#", vec![Term::app("s", vec![Term::var("x")])]),
                Term::app("g#", vec![Term::var("x")]),
            ),
        ];
        let usable = vec![RewriteRule::new(
            Term::app("g", vec![Term::var("x")]),
            Term::app("s", vec![Term::var("x")]),
        )];
        let options = DpOptions {
            max_polynomial_constant: 2,
            max_polynomial_coefficient: 2,
            ..DpOptions::default()
        };
        let arities = arities_for_constraints(&pairs, &usable);

        let script = polynomial_usable_rules_bv_script(
            &pairs, &pairs, None, &usable, &options, &arities, 2, 4, None,
        )
        .expect("nonempty component must be encoded");

        assert!(script.contains("(set-option :opt.priority lex)"));
        assert_eq!(script.matches("(maximize ").count(), 1);
        assert_eq!(script.matches("(minimize ").count(), 2);
        assert!(script.contains("(define-fun p_e_"), "usable-rule terms must share a DAG");
    }

    #[test]
    fn sat_polynomial_usable_rules_restore_long_symbol_models_without_collisions() {
        if !command_exists("z3") { return; }
        let long = "label".repeat(10_000);
        let pair = |name: &str| DependencyPair::new_for_test(
            Term::app(name, vec![Term::app("s", vec![Term::var("x")])]),
            Term::app(name, vec![Term::var("x")]));
        // q0 deliberately overlaps the short-name vocabulary, but all symbols
        // are mapped by one bijection, so no original symbol is overwritten.
        let pairs = vec![pair(&long), pair("q0")];
        let options = DpOptions {
            max_polynomial_constant: 1, max_polynomial_coefficient: 1,
            ..DpOptions::default()
        };
        let model = synthesize_polynomial_with_usable_rules_requiring_strict(
            &pairs, &pairs, Some(&[0, 1]), &[], &options, None).expect("compact joint query");
        assert_eq!(model.len(), 3);
        assert!(model.contains_key(&long) && model.contains_key("q0") && model.contains_key("s"));
        let removal = checked_component_removal_by_polynomial_with_usable_rules(
            &pairs, &[], &model, DpSearchBackend::Sat, None).expect("exact original-state check");
        assert_eq!(removal.strict_pair_indices, vec![0, 1]);
        let cyclic = vec![DependencyPair::new_for_test(pairs[0].rhs().clone(), pairs[0].rhs().clone())];
        assert!(synthesize_polynomial_with_usable_rules_requiring_strict(
            &cyclic, &cyclic, None, &[], &options, None).is_none());
    }

    #[test]
    fn bv_polynomial_model_block_mentions_all_active_parameters() {
        let arities = BTreeMap::from([("f".to_string(), 2), ("g".to_string(), 0)]);
        let interpretations = BTreeMap::from([
            (
                "f".to_string(),
                LinearPolynomial {
                    constant: 1,
                    coefficients: vec![2, 3],
                },
            ),
            (
                "g".to_string(),
                LinearPolynomial {
                    constant: 0,
                    coefficients: Vec::new(),
                },
            ),
        ]);
        let mut script = String::new();

        push_bv_polynomial_model_block(&mut script, &interpretations, &arities, 4).unwrap();

        assert!(script.starts_with("(assert (not (and "));
        assert!(script.contains(&format!("(= {} (_ bv1 4))", smt_c("f"))));
        assert!(script.contains(&format!("(= {} (_ bv2 4))", smt_a("f", 0))));
        assert!(script.contains(&format!("(= {} (_ bv3 4))", smt_a("f", 1))));
        assert!(script.contains(&format!("(= {} (_ bv0 4))", smt_c("g"))));
        assert!(script.ends_with(")))\n"));
    }

    #[test]
    fn polynomial_size_change_graph_pattern_cut_blocks_exact_edge_pattern() {
        let x = Term::var("x");
        let y = Term::var("y");
        let u = Term::var("u");
        let v = Term::var("v");
        let pair = DependencyPair::new_for_test(
            Term::app("f#", vec![x.clone(), y.clone()]),
            Term::app("f#", vec![u.clone(), v.clone()]),
        );
        let graph = DpSizeChangeGraph {
            pair: pair.clone(),
            edges: vec![
                DpSizeChangeEdge {
                    left_position: 1,
                    strict: true,
                    right_position: 1,
                },
                DpSizeChangeEdge {
                    left_position: 2,
                    strict: false,
                    right_position: 2,
                },
            ],
        };

        let cut = polynomial_size_change_graph_pattern_cut(&[pair], &[graph], 4).unwrap();

        assert!(cut.starts_with("(assert (or "));
        assert!(cut.contains(&format!("(not {})", polynomial_bv_strict(&x, &u, 4))));
        assert!(cut.contains(&format!(
            "(or (not {}) {})",
            polynomial_bv_weak_edge(&y, &v, 4),
            polynomial_bv_strict(&y, &v, 4)
        )));
        assert!(cut.contains(&polynomial_bv_weak_edge(&x, &v, 4)));
    }

    #[test]
    fn symbolic_size_change_closure_script_declares_finite_closure_graphs() {
        let pairs = vec![DependencyPair::new_for_test(
            Term::app("f#", vec![Term::app("s", vec![Term::var("x")])]),
            Term::app("f#", vec![Term::var("x")]),
        )];
        let usable = Vec::new();
        let options = DpOptions {
            max_polynomial_constant: 1,
            max_polynomial_coefficient: 1,
            ..DpOptions::default()
        };
        let arities = arities_for_constraints(&pairs, &usable);

        let encoding = symbolic_polynomial_size_change_closure_script(
            &pairs, &usable, &options, &arities, 3, None,
        )
        .unwrap();

        assert_eq!(
            encoding
                .script
                .matches("(declare-fun sct_closure_g_")
                .count(),
            3
        );
        assert!(encoding.script.contains("(assert (not sct_closure_g_0))"));
        assert!(encoding.script.contains("(assert (=> "));
        assert!(encoding.script.ends_with("(check-sat)\n(get-model)\n"));
    }

    #[test]
    fn symbolic_size_change_graph_enumeration_counts_all_edge_statuses() {
        let pairs = vec![DependencyPair::new_for_test(
            Term::app("f#", vec![Term::var("x"), Term::var("y")]),
            Term::app("g#", vec![Term::var("x")]),
        )];

        let graphs = enumerate_symbolic_size_change_graphs(&pairs, None).unwrap();

        assert_eq!(graphs.len(), 102);
    }

    #[test]
    fn max_polynomial_synthesizes_component_interpretation() {
        if !command_exists("z3") && !command_exists("cvc5") {
            return;
        }
        let pairs = vec![DependencyPair::new_for_test(
            Term::app("f#", vec![Term::app("s", vec![Term::var("x")])]),
            Term::app("f#", vec![Term::var("x")]),
        )];
        let usable = Vec::new();
        let options = DpOptions {
            max_polynomial_constant: 1,
            max_polynomial_coefficient: 1,
            max_polynomial_symbols: 2,
            max_polynomial_arity: 1,
            ..DpOptions::default()
        };
        let (interpretations, backend) =
            synthesize_max_polynomial(&pairs, &usable, &options, 2, None).unwrap();
        assert_eq!(backend, DpSearchBackend::Smt);
        let removal = checked_component_removal_by_max_polynomial(
            &pairs,
            &usable,
            &interpretations,
            backend,
            None,
        )
        .unwrap();
        assert_eq!(removal.strict_pair_indices, vec![0]);
    }

    #[test]
    fn max_polynomial_encoding_observes_expired_deadline() {
        let mut nested = Term::var("x");
        for _ in 0..24 {
            nested = Term::app("s", vec![nested]);
        }
        let pairs = vec![DependencyPair::new_for_test(
            Term::app("f#", vec![nested]),
            Term::app("f#", vec![Term::var("x")]),
        )];
        let options = DpOptions {
            max_polynomial_constant: 1,
            max_polynomial_coefficient: 1,
            max_polynomial_symbols: 3,
            max_polynomial_arity: 1,
            ..DpOptions::default()
        };

        assert!(
            max_polynomial_smt_script_requiring_strict_rules(
                &pairs,
                &[],
                &[],
                &options,
                2,
                Some(Instant::now()),
            )
            .is_none()
        );
        assert!(
            max_polynomial_smt_script_requiring_strict_rules(
                &pairs,
                &[],
                &[],
                &options,
                2,
                Some(Instant::now() + Duration::from_secs(1)),
            )
            .is_none(),
            "exponential max-polynomial encodings must be rejected before allocation"
        );
        let arities = arities_for_constraints(&pairs, &[]);
        assert!(
            quadratic_polynomial_smt_script(
                &pairs,
                &[],
                &options,
                &arities,
                Some(Instant::now() + Duration::from_secs(1)),
            )
            .is_none(),
            "exponential quadratic encodings must be rejected before allocation"
        );
        assert!(
            synthesize_rational_quadratic_polynomial_with_smt(
                &pairs,
                &[],
                &[],
                &options,
                4,
                1,
                Some(Instant::now() + Duration::from_secs(1)),
            )
            .is_none(),
            "exponential rational-quadratic encodings must be rejected before allocation"
        );
    }

    #[test]
    fn sat_polynomial_strategy_proves_decreasing_component() {
        let trs = Trs::new(
            None,
            BTreeSet::from([Variable::new("x")]),
            vec![RewriteRule::new(
                Term::app("f", vec![Term::app("s", vec![Term::var("x")])]),
                Term::app("f", vec![Term::var("x")]),
            )],
        );
        let pairs = dependency_pairs(&trs);
        let usable = reduction_pair_context_rules(&trs, &pairs, None);
        let scoped_options = DpOptions {
            max_polynomial_constant: 1,
            max_polynomial_coefficient: 1,
            max_polynomial_symbols: 4,
            max_polynomial_arity: 1,
            ..DpOptions::default()
        };
        assert!(
            synthesize_linear_polynomial_with_sat(&pairs, &usable, &scoped_options, None).is_some()
        );
        let processor = DpStrategyProcessor::SatPolynomial {
            max_constant: 1,
            max_coefficient: 1,
            max_symbols: Some(4),
            max_arity: Some(1),
        };
        let cancellation = DpStrategyCancellation::current(None);
        let context = ReductionPairContext::new(
            &trs,
            &pairs,
            None,
            false,
            true,
            &scoped_options,
            None,
            None,
            &cancellation,
        );
        assert!(synthesize_component_removal_by_processor(&processor, &context).is_some());
        let options = DpOptions::default();
        let strategy = DpStrategy::parse("sat-poly(1,1,4,1)").unwrap();
        let proof = solve_dependency_pairs_with_strategy(&trs, &options, &strategy, None).unwrap();
        assert_eq!(proof.removed_pairs, 1);
    }

    #[test]
    fn reduction_pair_context_does_not_treat_usable_hint_as_empty_rule_universe() {
        let trs = Trs::new_with_strategy(
            None,
            BTreeSet::from([Variable::new("x")]),
            vec![RewriteRule::new(
                Term::app("f", vec![Term::var("x")]),
                Term::app("f", vec![Term::var("x")]),
            )],
            RewriteStrategy::Innermost,
        );
        let pairs = dependency_pairs(&trs);
        let cancellation = DpStrategyCancellation::current(None);
        let options = DpOptions::default();
        let context = ReductionPairContext::new(
            &trs,
            &pairs,
            Some(&[]),
            false,
            true,
            &options,
            Some(&[]),
            None,
            &cancellation,
        );

        assert_eq!(context.input_rules, trs.rules());
        assert_eq!(context.usable_rules, trs.rules());
    }

    #[test]
    fn reduction_pair_context_preserves_certified_empty_rule_residual() {
        let trs = Trs::new_with_strategy(
            None,
            BTreeSet::from([Variable::new("x")]),
            vec![RewriteRule::new(
                Term::app("f", vec![Term::var("x")]),
                Term::app("f", vec![Term::var("x")]),
            )],
            RewriteStrategy::Innermost,
        );
        let pairs = dependency_pairs(&trs);
        let cancellation = DpStrategyCancellation::current(None);
        let options = DpOptions::default();
        let context = ReductionPairContext::new(
            &trs,
            &pairs,
            Some(&[]),
            true,
            true,
            &options,
            Some(&[]),
            None,
            &cancellation,
        );

        assert!(context.input_rules.is_empty());
        assert!(context.usable_rules.is_empty());
    }

    #[test]
    fn reduction_pair_context_recomputes_usable_rules_inside_active_rules() {
        let trs = Trs::new(
            None,
            BTreeSet::from([Variable::new("x")]),
            vec![
                RewriteRule::new(
                    Term::app("f", vec![Term::var("x")]),
                    Term::app("f", vec![Term::var("x")]),
                ),
                RewriteRule::new(
                    Term::app("g", vec![Term::var("x")]),
                    Term::app("g", vec![Term::var("x")]),
                ),
            ],
        );
        let pair = DependencyPair::new_for_test(
            Term::app("h#", vec![Term::var("x")]),
            Term::app("h#", vec![Term::app("f", vec![Term::var("x")])]),
        );
        let cancellation = DpStrategyCancellation::current(None);
        let options = DpOptions::default();
        let pairs = [pair];
        let context = ReductionPairContext::new(
            &trs,
            &pairs,
            Some(trs.rules()),
            false,
            true,
            &options,
            None,
            None,
            &cancellation,
        );

        assert_eq!(context.input_rules, trs.rules());
        assert_eq!(context.usable_rules, trs.rules()[..1]);
    }

    #[test]
    fn proves_component_pairs_that_need_reduction_pairs() {
        let variables = BTreeSet::from([Variable::new("x"), Variable::new("y")]);
        let trs = Trs::new_with_strategy(
            None,
            variables,
            vec![
                RewriteRule::new(
                    Term::app(
                        "f",
                        vec![Term::app("s", vec![Term::var("x")]), Term::var("y")],
                    ),
                    Term::app("f", vec![Term::var("x"), Term::var("y")]),
                ),
                RewriteRule::new(
                    Term::app(
                        "f",
                        vec![Term::var("x"), Term::app("g", vec![Term::var("y")])],
                    ),
                    Term::app("f", vec![Term::var("x"), Term::var("y")]),
                ),
            ],
            RewriteStrategy::Innermost,
        );
        let proof = solve_dependency_pairs(&trs, &DpOptions::default()).unwrap();
        let proved_component = proof
            .component_proofs
            .iter()
            .find(|component| component.proved)
            .expect("cyclic component should be proved");
        assert!(proof.removed_pairs > 0);
        assert!(proved_component.proof_tree.is_some());
    }

    #[test]
    fn subterm_criterion_runs_before_path_order_when_polynomials_are_disabled() {
        let variables = BTreeSet::from([Variable::new("x")]);
        let trs = Trs::new(
            None,
            variables,
            vec![RewriteRule::new(
                Term::app("f", vec![Term::app("g", vec![Term::var("x")])]),
                Term::app("f", vec![Term::var("x")]),
            )],
        );
        let proof = solve_dependency_pairs(
            &trs,
            &DpOptions {
                max_symbol_weight: 0,
                max_polynomial_constant: 0,
                max_polynomial_coefficient: 0,
                ..DpOptions::default()
            },
        )
        .unwrap();
        let proved_component = proof
            .component_proofs
            .iter()
            .find(|component| component.proved)
            .expect("cyclic component should be proved");
        assert!(matches!(
            proved_component.proof_tree.as_deref(),
            Some(DpProofTree::SizeChange { .. })
        ));
    }

    #[test]
    fn generalized_size_change_proves_sum_decreasing_component() {
        let pairs = vec![
            DependencyPair::new_for_test(
                Term::app(
                    "f#",
                    vec![Term::app("s", vec![Term::var("x")]), Term::var("y")],
                ),
                Term::app("f#", vec![Term::var("x"), Term::var("y")]),
            ),
            DependencyPair::new_for_test(
                Term::app(
                    "f#",
                    vec![Term::var("x"), Term::app("s", vec![Term::var("y")])],
                ),
                Term::app("f#", vec![Term::var("x"), Term::var("y")]),
            ),
        ];

        let graphs = synthesize_subterm_criterion(&pairs).unwrap();
        assert_eq!(graphs.len(), 2);
        assert!(
            graphs
                .iter()
                .all(|graph| graph.edges.iter().any(|edge| edge.strict))
        );
    }

    #[test]
    fn generalized_size_change_allows_non_idempotent_cycle_without_self_descent() {
        let pairs = vec![DependencyPair::new_for_test(
            Term::app(
                "f#",
                vec![
                    Term::app("s", vec![Term::var("x")]),
                    Term::app("s", vec![Term::var("y")]),
                ],
            ),
            Term::app("f#", vec![Term::var("y"), Term::var("x")]),
        )];

        assert!(
            synthesize_projection_subterm_criterion(&pairs, &DpOptions::default(), None, None)
                .is_none()
        );
        let graphs = synthesize_subterm_criterion(&pairs).unwrap();
        assert_eq!(
            graphs[0].edges,
            vec![
                DpSizeChangeEdge {
                    left_position: 1,
                    strict: true,
                    right_position: 2,
                },
                DpSizeChangeEdge {
                    left_position: 2,
                    strict: true,
                    right_position: 1,
                },
            ]
        );
    }

    #[test]
    fn projection_subterm_smt_has_no_symbol_cap() {
        let pairs = (0..9)
            .map(|index| {
                DependencyPair::new_for_test(
                    Term::app(
                        format!("f{index}#"),
                        vec![Term::app("s", vec![Term::var("x")])],
                    ),
                    Term::app(format!("f{}#", (index + 1) % 9), vec![Term::var("x")]),
                )
            })
            .collect::<Vec<_>>();

        let (projection, strict) =
            synthesize_projection_subterm_criterion(&pairs, &DpOptions::default(), None, None)
                .expect("one-shot SMT projection");
        assert_eq!(projection.len(), 9);
        assert_eq!(strict.len(), 9);
    }

    #[test]
    fn generalized_size_change_rejects_alternating_descent_without_global_progress() {
        let pairs = vec![
            DependencyPair::new_for_test(
                Term::app(
                    "f#",
                    vec![Term::app("s", vec![Term::var("x")]), Term::var("y")],
                ),
                Term::app(
                    "f#",
                    vec![Term::var("x"), Term::app("s", vec![Term::var("y")])],
                ),
            ),
            DependencyPair::new_for_test(
                Term::app(
                    "f#",
                    vec![Term::var("x"), Term::app("s", vec![Term::var("y")])],
                ),
                Term::app(
                    "f#",
                    vec![Term::app("s", vec![Term::var("x")]), Term::var("y")],
                ),
            ),
        ];

        assert!(synthesize_subterm_criterion(&pairs).is_none());
    }

    #[test]
    fn generalized_size_change_does_not_trust_missing_estimated_edges() {
        let pairs = vec![DependencyPair::new_for_test(
            Term::app("f#", vec![Term::var("x")]),
            Term::app("f#", vec![Term::var("x")]),
        )];

        // Even if an estimator omits the self edge, the emitted CPF SCT
        // processor must consider the composable f# -> f# graph.
        assert!(
            synthesize_general_size_change_criterion(
                &DpProofStats::default(),
                &pairs,
                &[Vec::new()],
            )
            .is_none()
        );
    }

    #[test]
    fn narrows_dependency_pair_rhs_below_root() {
        let pair = DependencyPair::new_for_test(
            Term::app("f#", vec![Term::var("x")]),
            Term::app("f#", vec![Term::app("g", vec![Term::var("x")])]),
        );
        let rules = vec![RewriteRule::new(
            Term::app("g", vec![Term::app("s", vec![Term::var("y")])]),
            Term::var("y"),
        )];
        let narrowings = narrow_pair_at_position(&pair, &[1], &rules, &[], 4).unwrap();

        assert_eq!(
            narrowings,
            vec![DependencyPair::new_for_test(
                Term::app("f#", vec![Term::app("s", vec![Term::var("y__n0")])]),
                Term::app("f#", vec![Term::var("y__n0")]),
            )]
        );
    }

    #[test]
    fn narrowing_prioritizes_nondeterministic_defined_calls() {
        let pair = DependencyPair::new_for_test(
            Term::app("f#", vec![Term::var("x")]),
            Term::app("f#", vec![Term::app("choose", vec![Term::var("x")])]),
        );
        let rules = vec![
            RewriteRule::new(Term::app("choose", vec![Term::var("x")]), Term::var("x")),
            RewriteRule::new(
                Term::app("choose", vec![Term::var("x")]),
                Term::app("s", vec![Term::var("x")]),
            ),
        ];
        let trs = Trs::new(None, [Variable::new("x")].into_iter().collect(), rules);
        let step = DpNarrowingStep {
            pair,
            position: vec![1],
            narrowings: Vec::new(),
        };

        assert!(narrowing_step_specializes_nondeterministic_call(
            &trs, &step
        ));
    }

    #[test]
    fn narrowing_candidate_order_is_independent_of_parent_pair_order() {
        let rules = vec![RewriteRule::new(
            Term::app("g", vec![Term::app("s", vec![Term::var("y")])]),
            Term::var("y"),
        )];
        let trs = Trs::new(
            None,
            [Variable::new("x"), Variable::new("y")]
                .into_iter()
                .collect(),
            rules,
        );
        let f_pair = DependencyPair::new_for_test(
            Term::app("f#", vec![Term::var("x")]),
            Term::app("f#", vec![Term::app("g", vec![Term::var("x")])]),
        );
        let h_pair = DependencyPair::new_for_test(
            Term::app("h#", vec![Term::var("x")]),
            Term::app("h#", vec![Term::app("g", vec![Term::var("x")])]),
        );
        let options = DpOptions::default();
        let cancellation = DpStrategyCancellation::default();
        let candidate_keys = |pairs: &[DependencyPair]| {
            synthesize_narrowing_steps_filtered(
                None,
                &trs,
                pairs,
                &options,
                None,
                None,
                &cancellation,
                |_| true,
            )
            .unwrap()
            .into_iter()
            .map(|(_, step, _)| {
                (
                    canonical_dependency_pair_key(&step.pair),
                    step.position,
                    step.narrowings
                        .iter()
                        .map(canonical_dependency_pair_key)
                        .collect::<Vec<_>>(),
                )
            })
            .collect::<Vec<_>>()
        };

        assert_eq!(
            candidate_keys(&[f_pair.clone(), h_pair.clone()]),
            candidate_keys(&[h_pair, f_pair])
        );
    }

    #[test]
    fn narrowing_candidate_ordinals_survive_symbol_canonicalization() {
        let make = |defined: &str, constructor: &str, left: &str, right: &str| {
            let trs = Trs::new(
                None,
                [Variable::new("x"), Variable::new("y")]
                    .into_iter()
                    .collect(),
                vec![RewriteRule::new(
                    Term::app(defined, vec![Term::app(constructor, vec![Term::var("y")])]),
                    Term::var("y"),
                )],
            );
            let pairs = vec![
                DependencyPair::new_for_test(
                    Term::app(left, vec![Term::var("x")]),
                    Term::app(left, vec![Term::app(defined, vec![Term::var("x")])]),
                ),
                DependencyPair::new_for_test(
                    Term::app(right, vec![Term::var("x")]),
                    Term::app(right, vec![Term::app(defined, vec![Term::var("x")])]),
                ),
            ];
            let cancellation = DpStrategyCancellation::default();
            synthesize_narrowing_steps_filtered(
                None,
                &trs,
                &pairs,
                &DpOptions::default(),
                None,
                None,
                &cancellation,
                |_| true,
            )
            .unwrap()
            .into_iter()
            .map(|(_, _, residual)| {
                standardized_dp_state_input_cpf3(&trs, &residual, None, true, false).0
            })
            .collect::<Vec<_>>()
        };

        assert_eq!(make("g", "s", "f#", "h#"), make("q", "t", "a#", "b#"));
    }

    #[test]
    fn narrowing_position_covers_the_complete_descendant_region() {
        let pair = DependencyPair::new_for_test(
            Term::app("h#", vec![Term::var("x")]),
            Term::app(
                "f#",
                vec![Term::app("g", vec![Term::app("g", vec![Term::var("x")])])],
            ),
        );
        let rules = vec![RewriteRule::new(
            Term::app("g", vec![Term::var("y")]),
            Term::app("a", Vec::new()),
        )];

        let narrowings = narrow_pair_at_position(&pair, &[1], &rules, &[], 4).unwrap();

        assert_eq!(narrowings.len(), 2);
        assert!(
            narrowings
                .iter()
                .any(|pair| { pair.rhs() == &Term::app("f#", vec![Term::app("a", Vec::new())]) })
        );
        assert!(narrowings.iter().any(|pair| {
            pair.rhs() == &Term::app("f#", vec![Term::app("g", vec![Term::app("a", Vec::new())])])
        }));
    }

    #[test]
    fn narrowing_freshens_rules_away_from_existing_pair_variables() {
        let pair = DependencyPair::new_for_test(
            Term::app(
                "bits#",
                vec![Term::app(
                    "s",
                    vec![Term::app("s", vec![Term::var("x__n2")])],
                )],
            ),
            Term::app(
                "bits#",
                vec![Term::app(
                    "s",
                    vec![Term::app("half", vec![Term::var("x__n2")])],
                )],
            ),
        );
        let rules = vec![
            RewriteRule::new(
                Term::app("half", vec![Term::app("|0|", Vec::new())]),
                Term::app("|0|", Vec::new()),
            ),
            RewriteRule::new(
                Term::app(
                    "half",
                    vec![Term::app("s", vec![Term::app("|0|", Vec::new())])],
                ),
                Term::app("|0|", Vec::new()),
            ),
            RewriteRule::new(
                Term::app(
                    "half",
                    vec![Term::app("s", vec![Term::app("s", vec![Term::var("x")])])],
                ),
                Term::app("s", vec![Term::app("half", vec![Term::var("x")])]),
            ),
        ];

        let narrowings = narrow_pair_at_position(&pair, &[1, 1], &rules, &[], 8).unwrap();

        assert_eq!(narrowings.len(), 3);
        assert!(narrowings.iter().any(|narrowed| {
            narrowed.lhs()
                == &Term::app(
                    "bits#",
                    vec![Term::app(
                        "s",
                        vec![Term::app(
                            "s",
                            vec![Term::app(
                                "s",
                                vec![Term::app("s", vec![Term::var("x__n2_1")])],
                            )],
                        )],
                    )],
                )
        }));
    }

    #[test]
    fn full_narrowing_rejects_positions_with_dp_successor_overlap() {
        let narrowed = DependencyPair::new_for_test(
            Term::app(
                "if#",
                vec![
                    Term::app("false", Vec::new()),
                    Term::var("x"),
                    Term::var("y"),
                ],
            ),
            Term::app(
                "minus#",
                vec![Term::app("p", vec![Term::var("x")]), Term::var("y")],
            ),
        );
        let other = DependencyPair::new_for_test(
            Term::app("minus#", vec![Term::var("x"), Term::var("y")]),
            Term::app(
                "if#",
                vec![
                    Term::app("le", vec![Term::var("x"), Term::var("y")]),
                    Term::var("x"),
                    Term::var("y"),
                ],
            ),
        );
        let pairs = vec![narrowed.clone(), other];
        let trs = Trs::new(
            None,
            BTreeSet::from([Variable::new("x"), Variable::new("y")]),
            vec![RewriteRule::new(
                Term::app("le", vec![Term::var("x"), Term::var("y")]),
                Term::app("false", Vec::new()),
            )],
        );

        assert!(!narrowing_position_is_admissible(
            &trs,
            &narrowed,
            &[1],
            &pairs,
            &[]
        ));
    }

    #[test]
    fn standard_narrowing_side_conditions_accept_linear_nonoverlapping_fragment() {
        let trs = Trs::new(
            None,
            BTreeSet::from([Variable::new("x"), Variable::new("y")]),
            vec![RewriteRule::new(
                Term::app("g", vec![Term::app("s", vec![Term::var("y")])]),
                Term::var("y"),
            )],
        );
        let pairs = vec![DependencyPair::new_for_test(
            Term::app("f#", vec![Term::app("h", vec![Term::var("x")])]),
            Term::app("f#", vec![Term::app("g", vec![Term::var("x")])]),
        )];

        assert!(narrowing_processor_side_conditions_hold(&trs, &pairs));
        let (step, residual) = synthesize_narrowing_step(&trs, &pairs, &DpOptions::default())
            .expect("standard narrowing step");
        assert_eq!(step.position, vec![1]);
        assert_eq!(step.narrowings, residual);
    }

    #[test]
    fn standard_narrowing_side_conditions_reject_non_linear_pairs() {
        let trs = Trs::new(
            None,
            BTreeSet::from([Variable::new("x")]),
            vec![RewriteRule::new(
                Term::app("g", vec![Term::var("x")]),
                Term::var("x"),
            )],
        );
        let pairs = vec![DependencyPair::new_for_test(
            Term::app("f#", vec![Term::var("x")]),
            Term::app("f#", vec![Term::var("x"), Term::var("x")]),
        )];

        assert!(!narrowing_processor_side_conditions_hold(&trs, &pairs));
    }

    #[test]
    fn standard_narrowing_side_conditions_allow_overlapping_rules() {
        let trs = Trs::new(
            None,
            BTreeSet::from([Variable::new("x")]),
            vec![
                RewriteRule::new(
                    Term::app("g", vec![Term::app("h", vec![Term::var("x")])]),
                    Term::var("x"),
                ),
                RewriteRule::new(Term::app("h", vec![Term::var("x")]), Term::var("x")),
            ],
        );
        let pairs = vec![DependencyPair::new_for_test(
            Term::app("f#", vec![Term::var("x")]),
            Term::app("f#", vec![Term::app("g", vec![Term::var("x")])]),
        )];

        assert!(narrowing_processor_side_conditions_hold(&trs, &pairs));
    }

    #[test]
    fn dependency_pairs_retain_rhs_calls_that_are_lhs_proper_subterms() {
        let variables = BTreeSet::from([Variable::new("x")]);
        let trs = Trs::new_with_strategy(
            None,
            variables,
            vec![RewriteRule::new(
                Term::app(
                    "a",
                    vec![Term::app(
                        "b",
                        vec![Term::app("a", vec![Term::app("b", vec![Term::var("x")])])],
                    )],
                ),
                Term::app(
                    "b",
                    vec![Term::app(
                        "a",
                        vec![Term::app(
                            "b",
                            vec![Term::app(
                                "a",
                                vec![Term::app("a", vec![Term::app("b", vec![Term::var("x")])])],
                            )],
                        )],
                    )],
                ),
            )],
            RewriteStrategy::Innermost,
        );
        let pairs = dependency_pairs(&trs);

        assert_eq!(pairs.len(), 3);
        assert!(pairs.contains(&DependencyPair::new_for_test(
            Term::app(
                "a#",
                vec![Term::app(
                    "b",
                    vec![Term::app("a", vec![Term::app("b", vec![Term::var("x")])])],
                )],
            ),
            Term::app(
                "a#",
                vec![Term::app(
                    "b",
                    vec![Term::app(
                        "a",
                        vec![Term::app("a", vec![Term::app("b", vec![Term::var("x")])])],
                    )],
                )],
            ),
        )));
        assert!(pairs.contains(&DependencyPair::new_for_test(
            Term::app(
                "a#",
                vec![Term::app(
                    "b",
                    vec![Term::app("a", vec![Term::app("b", vec![Term::var("x")])])],
                )],
            ),
            Term::app("a#", vec![Term::app("b", vec![Term::var("x")])]),
        )));
    }

    #[test]
    fn full_strategy_rejects_narrowing_with_non_linear_target() {
        let variables = BTreeSet::from([Variable::new("x")]);
        let trs = Trs::new(
            None,
            variables,
            vec![
                RewriteRule::new(
                    Term::app("f", vec![Term::var("x"), Term::var("x")]),
                    Term::app(
                        "f",
                        vec![Term::app("g", vec![Term::var("x")]), Term::var("x")],
                    ),
                ),
                RewriteRule::new(
                    Term::app("g", vec![Term::var("x")]),
                    Term::app("s", vec![Term::var("x")]),
                ),
            ],
        );
        let pairs = vec![DependencyPair::new_for_test(
            Term::app("f#", vec![Term::var("x"), Term::var("x")]),
            Term::app(
                "f#",
                vec![Term::app("g", vec![Term::var("x")]), Term::var("x")],
            ),
        )];

        assert!(!narrowing_processor_side_conditions_hold(&trs, &pairs));
        assert!(synthesize_narrowing_step(&trs, &pairs, &DpOptions::default()).is_none());
    }

    #[test]
    fn tries_reduction_pairs_before_narrowing() {
        let variables = BTreeSet::from([Variable::new("x"), Variable::new("y")]);
        let trs = Trs::new(
            None,
            variables,
            vec![
                RewriteRule::new(
                    Term::app("f", vec![Term::app("s", vec![Term::var("x")])]),
                    Term::app("f", vec![Term::app("h", vec![Term::var("x")])]),
                ),
                RewriteRule::new(Term::app("h", vec![Term::var("y")]), Term::var("y")),
            ],
        );
        let proof = solve_dependency_pairs(&trs, &DpOptions::default()).unwrap();
        assert!(proof.component_proofs.iter().any(|component| {
            component.proof_tree.as_deref().is_some_and(|tree| {
                matches!(
                    tree,
                    DpProofTree::RedPair { .. } | DpProofTree::SizeChangeRedPair { .. }
                )
            })
        }));
        assert!(!proof.component_proofs.iter().any(|component| {
            component
                .proof_tree
                .as_deref()
                .is_some_and(|tree| matches!(tree, DpProofTree::Narrowing { .. }))
        }));
    }

    #[test]
    fn innermost_components_record_usable_rules_processor() {
        let variables = BTreeSet::from([Variable::new("x")]);
        let trs = Trs::new_with_strategy(
            None,
            variables,
            vec![RewriteRule::new(
                Term::app("f", vec![Term::app("s", vec![Term::var("x")])]),
                Term::app("f", vec![Term::var("x")]),
            )],
            RewriteStrategy::Innermost,
        );
        // Exercise the processor explicitly.  The default worklist is free
        // to close this still-minimal innermost problem directly with SCT.
        let strategy = DpStrategy::Pipeline(vec![
            DpStrategy::Processor(DpStrategyProcessor::UsableRules),
            DpStrategy::Processor(DpStrategyProcessor::SizeChange),
        ]);
        let proof =
            solve_dependency_pairs_with_strategy(&trs, &DpOptions::default(), &strategy, None)
                .unwrap();
        let proved_component = proof
            .component_proofs
            .iter()
            .find(|component| component.proved)
            .expect("cyclic component should be proved");
        assert_eq!(proof.strategy, RewriteStrategy::Innermost);
        assert!(proved_component.usable_rules_processor.is_some());
    }

    #[test]
    fn rpo_multiset_does_not_accept_bad_greedy_matching() {
        let lhs = Term::app(
            "f",
            vec![
                Term::app("g", vec![Term::var("x")]),
                Term::app("s", vec![Term::app("|0|", vec![])]),
            ],
        );
        let rhs = Term::app(
            "f",
            vec![
                Term::app("g", vec![Term::var("x")]),
                Term::app("g", vec![Term::var("x")]),
            ],
        );
        let precedence = ["g", "f", "s", "|0|"]
            .into_iter()
            .enumerate()
            .map(|(rank, symbol)| (symbol, rank))
            .collect::<BTreeMap<_, _>>();
        let argument_filter = BTreeMap::from([
            (
                "f".to_string(),
                DpArgumentFilterEntry::NonCollapsing(vec![0, 1]),
            ),
            (
                "g".to_string(),
                DpArgumentFilterEntry::NonCollapsing(vec![0]),
            ),
            (
                "s".to_string(),
                DpArgumentFilterEntry::NonCollapsing(vec![0]),
            ),
            (
                "|0|".to_string(),
                DpArgumentFilterEntry::NonCollapsing(vec![]),
            ),
        ]);
        assert!(!weakly_decreases_by_path_order(
            &lhs,
            &rhs,
            DpPathOrderKind::Rpo,
            &precedence,
            &argument_filter,
        ));
    }

    #[test]
    fn lpo_lex_status_accepts_same_root_lexicographic_decrease() {
        let lhs = Term::app(
            "f",
            vec![Term::app("s", vec![Term::var("x")]), Term::var("y")],
        );
        let rhs = Term::app(
            "f",
            vec![Term::var("x"), Term::app("s", vec![Term::var("y")])],
        );
        let precedence = ["f", "s"]
            .into_iter()
            .enumerate()
            .map(|(rank, symbol)| (symbol, rank))
            .collect::<BTreeMap<_, _>>();
        let argument_filter = BTreeMap::from([
            (
                "f".to_string(),
                DpArgumentFilterEntry::NonCollapsing(vec![0, 1]),
            ),
            (
                "s".to_string(),
                DpArgumentFilterEntry::NonCollapsing(vec![0]),
            ),
        ]);

        assert!(strictly_decreases_by_path_order(
            &lhs,
            &rhs,
            DpPathOrderKind::Lpo,
            &precedence,
            &argument_filter,
        ));
        assert!(!strictly_decreases_by_path_order(
            &lhs,
            &rhs,
            DpPathOrderKind::Rpo,
            &precedence,
            &argument_filter,
        ));
    }

    #[test]
    fn mixed_path_order_checker_preserves_per_symbol_statuses() {
        let pairs = vec![
            DependencyPair::new_for_test(
                Term::app(
                    "f#",
                    vec![Term::app("s", vec![Term::var("x")]), Term::var("y")],
                ),
                Term::app(
                    "f#",
                    vec![Term::var("x"), Term::app("s", vec![Term::var("y")])],
                ),
            ),
            DependencyPair::new_for_test(
                Term::app(
                    "g#",
                    vec![
                        Term::app("s", vec![Term::var("x")]),
                        Term::app("s", vec![Term::var("y")]),
                    ],
                ),
                Term::app("g#", vec![Term::var("y"), Term::var("x")]),
            ),
        ];
        let usable = Vec::new();
        let precedence = vec!["f#".to_string(), "g#".to_string(), "s".to_string()];
        let statuses = BTreeMap::from([
            ("f#".to_string(), DpPathOrderKind::Lpo),
            ("g#".to_string(), DpPathOrderKind::Rpo),
            ("s".to_string(), DpPathOrderKind::Rpo),
        ]);
        let argument_filter = BTreeMap::from([
            (
                "f#".to_string(),
                DpArgumentFilterEntry::NonCollapsing(vec![0, 1]),
            ),
            (
                "g#".to_string(),
                DpArgumentFilterEntry::NonCollapsing(vec![0, 1]),
            ),
            (
                "s".to_string(),
                DpArgumentFilterEntry::NonCollapsing(vec![0]),
            ),
        ]);

        let removal = checked_component_removal_by_mixed_path_order(
            &pairs,
            &usable,
            DpPathOrderKind::Rpo,
            &statuses,
            &precedence,
            &argument_filter,
            DpSearchBackend::PathOrder,
            None,
        )
        .expect("mixed path order should remove both pairs");

        assert_eq!(removal.strict_pair_indices, vec![0, 1]);
        let DpReductionPairProof::PathOrder { statuses, .. } = removal.reduction_pair else {
            panic!("expected path-order removal");
        };
        assert_eq!(statuses.get("f#"), Some(&DpPathOrderKind::Lpo));
        assert_eq!(statuses.get("g#"), Some(&DpPathOrderKind::Rpo));
    }

    #[test]
    fn mixed_path_order_checker_accepts_quasi_precedence_equal_roots() {
        let pairs = vec![DependencyPair::new_for_test(
            Term::app("f#", vec![Term::app("s", vec![Term::var("x")])]),
            Term::app("g#", vec![Term::var("x")]),
        )];
        let usable = Vec::new();
        let precedence = vec!["f#".to_string(), "g#".to_string(), "s".to_string()];
        let precedence_ranks = BTreeMap::from([
            ("f#".to_string(), 0),
            ("g#".to_string(), 0),
            ("s".to_string(), 1),
        ]);
        let statuses = BTreeMap::from([
            ("f#".to_string(), DpPathOrderKind::Lpo),
            ("g#".to_string(), DpPathOrderKind::Lpo),
            ("s".to_string(), DpPathOrderKind::Lpo),
        ]);
        let argument_filter = BTreeMap::from([
            (
                "f#".to_string(),
                DpArgumentFilterEntry::NonCollapsing(vec![0]),
            ),
            (
                "g#".to_string(),
                DpArgumentFilterEntry::NonCollapsing(vec![0]),
            ),
            (
                "s".to_string(),
                DpArgumentFilterEntry::NonCollapsing(vec![0]),
            ),
        ]);
        let removal = checked_component_removal_by_mixed_path_order_with_ranks(
            &pairs,
            &usable,
            DpPathOrderKind::Lpo,
            &statuses,
            &precedence,
            &precedence_ranks,
            &argument_filter,
            DpSearchBackend::PathOrder,
            None,
        )
        .expect("equal-rank path-order roots should compare by lex status");

        assert_eq!(removal.strict_pair_indices, vec![0]);
        let DpReductionPairProof::PathOrder {
            precedence_ranks: stored_ranks,
            ..
        } = removal.reduction_pair
        else {
            panic!("expected path-order removal");
        };
        assert_eq!(stored_ranks.get("f#"), stored_ranks.get("g#"));
    }

    #[test]
    fn mixed_path_order_checker_rejects_mixed_statuses_in_quasi_class() {
        let pairs = vec![DependencyPair::new_for_test(
            Term::app("f#", vec![Term::app("s", vec![Term::var("x")])]),
            Term::app("g#", vec![Term::var("x")]),
        )];
        let precedence = vec!["f#".to_string(), "g#".to_string(), "s".to_string()];
        let precedence_ranks = BTreeMap::from([
            ("f#".to_string(), 0),
            ("g#".to_string(), 0),
            ("s".to_string(), 1),
        ]);
        let statuses = BTreeMap::from([
            ("f#".to_string(), DpPathOrderKind::Lpo),
            ("g#".to_string(), DpPathOrderKind::Rpo),
            ("s".to_string(), DpPathOrderKind::Lpo),
        ]);
        let argument_filter = BTreeMap::from([
            (
                "f#".to_string(),
                DpArgumentFilterEntry::NonCollapsing(vec![0]),
            ),
            (
                "g#".to_string(),
                DpArgumentFilterEntry::NonCollapsing(vec![0]),
            ),
            (
                "s".to_string(),
                DpArgumentFilterEntry::NonCollapsing(vec![0]),
            ),
        ]);

        assert!(
            checked_component_removal_by_mixed_path_order_with_ranks(
                &pairs,
                &[],
                DpPathOrderKind::Lpo,
                &statuses,
                &precedence,
                &precedence_ranks,
                &argument_filter,
                DpSearchBackend::PathOrder,
                None,
            )
            .is_none(),
            "symbols equivalent in a quasi-precedence must have the same status"
        );
    }

    #[test]
    fn pair2simple2_residual_accepts_aprove_lex_rpo_witness() {
        let rule = RewriteRule::new(
            Term::app(
                "p",
                vec![
                    Term::app("a", vec![Term::var("x0")]),
                    Term::app(
                        "p",
                        vec![
                            Term::app(
                                "a",
                                vec![Term::app("a", vec![Term::app("a", vec![Term::var("x1")])])],
                            ),
                            Term::var("x2"),
                        ],
                    ),
                ],
            ),
            Term::app(
                "p",
                vec![
                    Term::app("a", vec![Term::var("x2")]),
                    Term::app(
                        "p",
                        vec![
                            Term::app(
                                "a",
                                vec![Term::app("a", vec![Term::app("b", vec![Term::var("x0")])])],
                            ),
                            Term::var("x2"),
                        ],
                    ),
                ],
            ),
        );
        let trs = Trs::new(
            None,
            BTreeSet::from([
                Variable::new("x0"),
                Variable::new("x1"),
                Variable::new("x2"),
            ]),
            vec![rule.clone()],
        );
        let pairs = dependency_pairs(&trs);
        assert_eq!(pairs.len(), 2);
        let residual = vec![pairs[0].clone()];
        // Ferrum stores greatest symbols at the smallest rank; CPF writes the
        // equivalent opposite numeric convention used by AProVE's witness.
        let precedence = vec!["p".to_string(), "a".to_string(), "b".to_string()];
        let precedence_ranks = BTreeMap::from([
            ("p".to_string(), 0),
            ("a".to_string(), 1),
            ("b".to_string(), 2),
        ]);
        let statuses = BTreeMap::from([
            ("a".to_string(), DpPathOrderKind::Lpo),
            ("b".to_string(), DpPathOrderKind::Lpo),
            ("p".to_string(), DpPathOrderKind::Lpo),
            ("p#".to_string(), DpPathOrderKind::Lpo),
        ]);
        let argument_filter = BTreeMap::from([
            ("p#".to_string(), DpArgumentFilterEntry::Collapsing(1)),
            (
                "a".to_string(),
                DpArgumentFilterEntry::NonCollapsing(vec![0]),
            ),
            (
                "p".to_string(),
                DpArgumentFilterEntry::NonCollapsing(vec![1, 0]),
            ),
            (
                "b".to_string(),
                DpArgumentFilterEntry::NonCollapsing(Vec::new()),
            ),
        ]);
        let complete_filter =
            complete_argument_filter(&residual, std::slice::from_ref(&rule), &argument_filter);
        let rank_refs = precedence_rank_refs(&precedence_ranks);
        assert!(
            term_size(&filter_term(rule.rhs(), &complete_filter))
                <= term_size(&filter_term(rule.lhs(), &complete_filter)),
            "the filtered-size precheck should accept AProVE's rule"
        );
        assert!(
            weakly_decreases_by_mixed_path_order(
                rule.lhs(),
                rule.rhs(),
                DpPathOrderKind::Lpo,
                &statuses,
                &rank_refs,
                &complete_filter,
            ),
            "AProVE's filtered rule should be weakly RPO-oriented"
        );
        assert!(
            weakly_decreases_by_mixed_path_order(
                residual[0].lhs(),
                residual[0].rhs(),
                DpPathOrderKind::Lpo,
                &statuses,
                &rank_refs,
                &complete_filter,
            ),
            "AProVE's residual pair should be weakly RPO-oriented"
        );
        assert!(
            strictly_decreases_by_mixed_path_order(
                residual[0].lhs(),
                residual[0].rhs(),
                DpPathOrderKind::Lpo,
                &statuses,
                &rank_refs,
                &complete_filter,
            ),
            "AProVE's residual pair should be strictly RPO-oriented"
        );

        let removal = checked_component_removal_by_mixed_path_order_with_ranks(
            &residual,
            std::slice::from_ref(&rule),
            DpPathOrderKind::Lpo,
            &statuses,
            &precedence,
            &precedence_ranks,
            &argument_filter,
            DpSearchBackend::PathOrder,
            None,
        )
        .expect("Ferrum should validate AProVE's residual lex-RPO witness");

        assert_eq!(removal.strict_pair_indices, vec![0]);
    }

    #[test]
    fn ag01_3_19_component_accepts_aprove_lex_rpo_witness() {
        let trs =
            crate::parsing::parse_ari_trs(None, include_str!("../../tests/fixtures/ag01_3_19.ari"))
                .unwrap();
        // Validate the exact four-pair AProVE witness independently of the
        // additional proper-subterm calls now retained by Ferrum's complete
        // production dpTrans boundary.
        let pairs = dependency_pairs_with_subterm_omission(&trs, true);
        let graph = dependency_pair_graph(&trs, &pairs);
        let component = strongly_connected_components(&graph)
            .into_iter()
            .find(|component| component.len() == 4)
            .expect("AProVE's four-pair plus component");
        let component_pairs = component
            .iter()
            .map(|index| pairs[*index].clone())
            .collect::<Vec<_>>();
        let precedence = vec![
            "plus".to_string(),
            "double".to_string(),
            "|0|".to_string(),
            "plus#".to_string(),
            "s".to_string(),
            "minus".to_string(),
        ];
        let precedence_ranks = BTreeMap::from([
            ("plus".to_string(), 0),
            ("double".to_string(), 1),
            ("|0|".to_string(), 1),
            ("plus#".to_string(), 2),
            ("s".to_string(), 2),
            ("minus".to_string(), 3),
        ]);
        let statuses = precedence
            .iter()
            .map(|symbol| (symbol.clone(), DpPathOrderKind::Lpo))
            .collect::<BTreeMap<_, _>>();
        let argument_filter = BTreeMap::from([
            (
                "plus#".to_string(),
                DpArgumentFilterEntry::NonCollapsing(vec![0]),
            ),
            (
                "s".to_string(),
                DpArgumentFilterEntry::NonCollapsing(vec![0]),
            ),
            ("minus".to_string(), DpArgumentFilterEntry::Collapsing(0)),
            (
                "double".to_string(),
                DpArgumentFilterEntry::NonCollapsing(vec![0]),
            ),
            (
                "plus".to_string(),
                DpArgumentFilterEntry::NonCollapsing(vec![0, 1]),
            ),
            (
                "|0|".to_string(),
                DpArgumentFilterEntry::NonCollapsing(Vec::new()),
            ),
        ]);
        let complete_filter =
            complete_argument_filter(&component_pairs, trs.rules(), &argument_filter);
        let rank_refs = precedence_rank_refs(&precedence_ranks);
        for (index, rule) in trs.rules().iter().enumerate() {
            assert!(
                weakly_decreases_by_mixed_path_order(
                    rule.lhs(),
                    rule.rhs(),
                    DpPathOrderKind::Lpo,
                    &statuses,
                    &rank_refs,
                    &complete_filter,
                ),
                "AProVE's RPO should weakly orient rule {index}: {rule:?}"
            );
        }
        for (index, pair) in component_pairs.iter().enumerate() {
            assert!(
                strictly_decreases_by_mixed_path_order(
                    pair.lhs(),
                    pair.rhs(),
                    DpPathOrderKind::Lpo,
                    &statuses,
                    &rank_refs,
                    &complete_filter,
                ),
                "AProVE's RPO should strictly orient pair {index}: {pair:?}"
            );
        }

        let removal = checked_component_removal_by_mixed_path_order_with_ranks(
            &component_pairs,
            trs.rules(),
            DpPathOrderKind::Lpo,
            &statuses,
            &precedence,
            &precedence_ranks,
            &argument_filter,
            DpSearchBackend::PathOrder,
            None,
        )
        .expect("Ferrum should accept AProVE's certified RPO witness");

        assert_eq!(removal.strict_pair_indices.len(), component_pairs.len());
    }

    #[test]
    fn lpo_accepts_aprove_ex1_gm99_component_shape() {
        let pairs = vec![
            DependencyPair::new_for_test(
                Term::app(
                    "a__f#",
                    vec![
                        Term::app("a", vec![]),
                        Term::app("b", vec![]),
                        Term::var("X"),
                    ],
                ),
                Term::app("mark#", vec![Term::var("X")]),
            ),
            DependencyPair::new_for_test(
                Term::app(
                    "mark#",
                    vec![Term::app(
                        "f",
                        vec![Term::var("X1"), Term::var("X2"), Term::var("X3")],
                    )],
                ),
                Term::app(
                    "a__f#",
                    vec![
                        Term::var("X1"),
                        Term::var("X2"),
                        Term::app("mark", vec![Term::var("X3")]),
                    ],
                ),
            ),
        ];
        let usable = Vec::new();
        let argument_filter = BTreeMap::from([
            (
                "a__f#".to_string(),
                DpArgumentFilterEntry::NonCollapsing(vec![2]),
            ),
            (
                "mark#".to_string(),
                DpArgumentFilterEntry::NonCollapsing(vec![0]),
            ),
            (
                "f".to_string(),
                DpArgumentFilterEntry::NonCollapsing(vec![2]),
            ),
            (
                "a__f".to_string(),
                DpArgumentFilterEntry::NonCollapsing(vec![2]),
            ),
            ("mark".to_string(), DpArgumentFilterEntry::Collapsing(0)),
        ]);
        let symbols = vec![
            "a".to_string(),
            "b".to_string(),
            "a__f#".to_string(),
            "mark#".to_string(),
            "f".to_string(),
            "mark".to_string(),
        ];

        assert!(
            permutations_of_positions(&(0..symbols.len()).collect::<Vec<_>>())
                .into_iter()
                .map(|permutation| {
                    permutation
                        .into_iter()
                        .map(|index| symbols[index].clone())
                        .collect::<Vec<_>>()
                })
                .any(|precedence| checked_component_removal_by_path_order(
                    &pairs,
                    &usable,
                    DpPathOrderKind::Lpo,
                    &precedence,
                    &argument_filter,
                    DpSearchBackend::PathOrder,
                    None,
                )
                .is_some())
        );
    }

    #[test]
    fn kbo_admissibility_allows_only_unary_zero_weight_maximal_symbols() {
        let pairs = vec![DependencyPair::new_for_test(
            Term::app("f#", vec![Term::app("s", vec![Term::var("x")])]),
            Term::app("f#", vec![Term::var("x")]),
        )];
        let usable = Vec::new();
        let weights = BTreeMap::from([("f#".to_string(), 1), ("s".to_string(), 0)]);
        let admissible_precedence = vec!["s".to_string(), "f#".to_string()];
        let admissible_precedence_ranks =
            BTreeMap::from([("s".to_string(), 0), ("f#".to_string(), 1)]);
        let inadmissible_precedence_ranks =
            BTreeMap::from([("f#".to_string(), 0), ("s".to_string(), 1)]);
        let argument_filter = BTreeMap::from([
            (
                "f#".to_string(),
                DpArgumentFilterEntry::NonCollapsing(vec![0]),
            ),
            (
                "s".to_string(),
                DpArgumentFilterEntry::NonCollapsing(vec![0]),
            ),
        ]);

        assert!(kbo_weights_are_admissible(
            &pairs,
            &usable,
            &weights,
            &admissible_precedence_ranks,
            &argument_filter
        ));
        assert!(!kbo_weights_are_admissible(
            &pairs,
            &usable,
            &weights,
            &inadmissible_precedence_ranks,
            &argument_filter
        ));
        assert!(
            checked_component_removal_by_kbo(
                &pairs,
                &usable,
                &admissible_precedence,
                &weights,
                &argument_filter,
                DpSearchBackend::Kbo,
                None,
            )
            .is_some()
        );
    }

    #[test]
    fn kbo_admissibility_rejects_zero_weight_binary_symbols() {
        let pairs = vec![DependencyPair::new_for_test(
            Term::app(
                "f#",
                vec![Term::app("h", vec![Term::var("x"), Term::var("y")])],
            ),
            Term::app("f#", vec![Term::var("x")]),
        )];
        let weights = BTreeMap::from([("f#".to_string(), 1), ("h".to_string(), 0)]);
        let precedence_ranks = BTreeMap::from([("h".to_string(), 0), ("f#".to_string(), 1)]);
        let argument_filter = BTreeMap::from([
            (
                "f#".to_string(),
                DpArgumentFilterEntry::NonCollapsing(vec![0]),
            ),
            (
                "h".to_string(),
                DpArgumentFilterEntry::NonCollapsing(vec![0, 1]),
            ),
        ]);

        assert!(!kbo_weights_are_admissible(
            &pairs,
            &[],
            &weights,
            &precedence_ranks,
            &argument_filter
        ));
    }

    #[test]
    fn kbo_admissibility_allows_zero_weight_collapsed_binary_symbols() {
        let pairs = vec![DependencyPair::new_for_test(
            Term::app(
                "f#",
                vec![Term::app(
                    "h",
                    vec![Term::app("s", vec![Term::var("x")]), Term::var("y")],
                )],
            ),
            Term::app("f#", vec![Term::var("x")]),
        )];
        let usable = Vec::new();
        let weights = BTreeMap::from([
            ("f#".to_string(), 1),
            ("h".to_string(), 0),
            ("s".to_string(), 1),
        ]);
        let precedence = vec!["h".to_string(), "s".to_string(), "f#".to_string()];
        let precedence_ranks = BTreeMap::from([
            ("h".to_string(), 0),
            ("s".to_string(), 1),
            ("f#".to_string(), 2),
        ]);
        let argument_filter = BTreeMap::from([
            (
                "f#".to_string(),
                DpArgumentFilterEntry::NonCollapsing(vec![0]),
            ),
            ("h".to_string(), DpArgumentFilterEntry::Collapsing(0)),
            (
                "s".to_string(),
                DpArgumentFilterEntry::NonCollapsing(vec![0]),
            ),
        ]);

        assert!(kbo_weights_are_admissible(
            &pairs,
            &usable,
            &weights,
            &precedence_ranks,
            &argument_filter
        ));
        assert!(
            checked_component_removal_by_kbo(
                &pairs,
                &usable,
                &precedence,
                &weights,
                &argument_filter,
                DpSearchBackend::Kbo,
                None,
            )
            .is_some()
        );
    }

    #[test]
    fn pair3hard_aprove_kbo_argument_filter_orients_ferrum_residual() {
        let variables = ["x0", "x1", "x2", "x3"]
            .into_iter()
            .map(Variable::new)
            .collect();
        let rule = RewriteRule::new(
            Term::app(
                "p",
                vec![
                    Term::app("a", vec![Term::var("x0")]),
                    Term::app(
                        "p",
                        vec![
                            Term::var("x1"),
                            Term::app("p", vec![Term::var("x2"), Term::var("x3")]),
                        ],
                    ),
                ],
            ),
            Term::app(
                "p",
                vec![
                    Term::var("x1"),
                    Term::app(
                        "p",
                        vec![
                            Term::var("x0"),
                            Term::app(
                                "p",
                                vec![Term::app("a", vec![Term::var("x3")]), Term::var("x3")],
                            ),
                        ],
                    ),
                ],
            ),
        );
        let trs = Trs::new(None, variables, vec![rule]);
        let pairs = dependency_pairs(&trs);
        assert_eq!(pairs.len(), 3);

        let argument_filter = BTreeMap::from([
            ("p#".to_string(), DpArgumentFilterEntry::Collapsing(1)),
            (
                "p".to_string(),
                DpArgumentFilterEntry::NonCollapsing(vec![1]),
            ),
        ]);
        let weights = BTreeMap::from([("p".to_string(), 1)]);
        let precedence = vec!["p".to_string()];
        let removal = checked_component_removal_by_kbo(
            &pairs,
            trs.rules(),
            &precedence,
            &weights,
            &argument_filter,
            DpSearchBackend::Kbo,
            None,
        )
        .expect("AProVE's certified KBO+AF witness must orient pair3hard");
        assert_eq!(removal.strict_pair_indices, vec![1, 2]);

        let singleton = vec![pairs[0].clone()];
        let cancellation = DpStrategyCancellation::default();
        let candidates = synthesize_forward_instantiation_candidates_filtered(
            None,
            &trs,
            &singleton,
            trs.rules(),
            false,
            None,
            false,
            None,
            &cancellation,
            |_| true,
        )
        .expect("pair3hard forward-instantiation candidates");
        let residual = &candidates
            .first()
            .expect("AProVE's forward instantiation")
            .2;
        assert_eq!(residual.len(), 1);

        let model = SemanticLabelingModel {
            carrier_size: 2,
            arities: BTreeMap::from([
                (Symbol::new("a"), 1),
                (Symbol::new("p"), 2),
                (Symbol::new("p#"), 2),
            ]),
            interpretations: BTreeMap::from([
                (Symbol::new("a"), SlArithmeticFunction::Constant(1)),
                (Symbol::new("p"), SlArithmeticFunction::Constant(0)),
                (Symbol::new("p#"), SlArithmeticFunction::Constant(0)),
            ]),
        };
        assert!(semantic_labeling_model_condition_holds(
            &model,
            trs.rules(),
            None,
            &cancellation,
        ));
        let labeled_pairs =
            semantic_label_pair_instances(&model, &residual[0], None, &cancellation)
                .expect("labeled pairs");
        let labeled_rules =
            semantic_label_rule_instances(&model, &trs.rules()[0], None, &cancellation)
                .expect("labeled rules");
        assert_eq!(labeled_pairs.len(), 16);
        assert_eq!(labeled_rules.len(), 16);
        let labeled_trs = Trs::new(None, trs.variables().clone(), labeled_rules);
        let graph = dependency_pair_graph(&labeled_trs, &labeled_pairs);
        let cyclic_components = strongly_connected_components(&graph)
            .into_iter()
            .filter(|component| component_is_cyclic(component, &graph))
            .map(|component| {
                component
                    .into_iter()
                    .map(|index| labeled_pairs[index].clone())
                    .collect::<Vec<_>>()
            })
            .collect::<Vec<_>>();
        assert_eq!(
            cyclic_components.iter().map(Vec::len).collect::<Vec<_>>(),
            vec![2, 1]
        );
        let two_pair_component = cyclic_components
            .iter()
            .find(|component| component.len() == 2)
            .expect("AProVE's two-pair labeled SCC");
        let polynomial = synthesize_linear_polynomial_with_sat(
            two_pair_component,
            labeled_trs.rules(),
            &DpOptions {
                max_polynomial_constant: 1,
                max_polynomial_coefficient: 1,
                ..DpOptions::default()
            },
            None,
        );
        assert!(
            polynomial.is_some(),
            "one-shot 0/1 polynomial search must find AProVE's certified interpretation"
        );
    }

    #[test]
    fn kbo_checker_accepts_quasi_precedence_equal_roots() {
        let pairs = vec![DependencyPair::new_for_test(
            Term::app("f#", vec![Term::app("s", vec![Term::var("x")])]),
            Term::app("g#", vec![Term::var("x")]),
        )];
        let usable = Vec::new();
        let precedence = vec!["s".to_string(), "f#".to_string(), "g#".to_string()];
        let precedence_ranks = BTreeMap::from([
            ("s".to_string(), 0),
            ("f#".to_string(), 1),
            ("g#".to_string(), 1),
        ]);
        let weights = BTreeMap::from([
            ("s".to_string(), 0),
            ("f#".to_string(), 1),
            ("g#".to_string(), 1),
        ]);
        let argument_filter = BTreeMap::from([
            (
                "f#".to_string(),
                DpArgumentFilterEntry::NonCollapsing(vec![0]),
            ),
            (
                "g#".to_string(),
                DpArgumentFilterEntry::NonCollapsing(vec![0]),
            ),
            (
                "s".to_string(),
                DpArgumentFilterEntry::NonCollapsing(vec![0]),
            ),
        ]);

        let removal = checked_component_removal_by_kbo_with_ranks(
            &pairs,
            &usable,
            &precedence,
            &precedence_ranks,
            &weights,
            &argument_filter,
            DpSearchBackend::Kbo,
            None,
        )
        .expect("equal-rank KBO roots should compare by lex arguments");

        assert_eq!(removal.strict_pair_indices, vec![0]);
        let DpReductionPairProof::Kbo {
            precedence_ranks: stored_ranks,
            ..
        } = removal.reduction_pair
        else {
            panic!("expected KBO removal");
        };
        assert_eq!(stored_ranks.get("f#"), stored_ranks.get("g#"));
    }

    #[test]
    fn one_blast_kbo_synthesizes_simple_component() {
        if !command_exists("z3") && !command_exists("cvc5") {
            return;
        }
        let pairs = vec![DependencyPair::new_for_test(
            Term::app("f#", vec![Term::app("s", vec![Term::var("x")])]),
            Term::app("f#", vec![Term::var("x")]),
        )];
        let usable = Vec::new();
        let options = DpOptions {
            max_symbol_weight: 1,
            ..DpOptions::default()
        };
        let removal = synthesize_kbo_for_component(&pairs, &usable, &options, None, None, false)
            .expect("one-blast KBO should synthesize a removable component");

        assert_eq!(removal.strict_pair_indices, vec![0]);
        assert!(matches!(
            removal.reduction_pair,
            DpReductionPairProof::Kbo { .. }
        ));
    }

    #[test]
    fn monotonic_polynomial_search_removes_strict_residual_rules() {
        if !command_exists("z3") && !command_exists("cvc5") {
            return;
        }
        let pairs = vec![DependencyPair::new_for_test(
            Term::app("f#", vec![Term::var("x")]),
            Term::app("f#", vec![Term::var("x")]),
        )];
        let rules = vec![RewriteRule::new(
            Term::app("g", vec![Term::app("s", vec![Term::var("x")])]),
            Term::app("g", vec![Term::var("x")]),
        )];
        let removal = synthesize_monotonic_usable_polynomial(
            &pairs,
            &rules,
            &DpOptions::default(),
            false,
            None,
        )
        .expect("one-shot monotonic search should remove the strict residual rule");

        assert!(removal.strict_pair_indices.is_empty());
        assert_eq!(removal.strict_rule_indices, vec![0]);
    }

    #[test]
    fn kbo_uses_the_argument_filtered_usable_rule_closure() {
        let pairs = vec![DependencyPair::new_for_test(
            Term::app("f#", vec![Term::app("s", vec![Term::var("x")])]),
            Term::app("f#", vec![Term::var("x")]),
        )];
        let usable_rule = RewriteRule::new(
            Term::app("g", vec![Term::app("s", vec![Term::var("x")])]),
            Term::app("g", vec![Term::var("x")]),
        );
        let rules = vec![usable_rule];
        let options = DpOptions {
            max_symbol_weight: 2,
            ..DpOptions::default()
        };
        let removal = synthesize_kbo_for_component(&pairs, &rules, &options, None, None, false)
            .expect("KBO should orient the component");
        assert_eq!(removal.usable_rules, Some(Vec::new()));
    }

    #[test]
    fn fixed_kbo_preserves_the_supplied_usable_rules() {
        if !command_exists("z3") && !command_exists("cvc5") {
            return;
        }
        let pairs = vec![DependencyPair::new_for_test(
            Term::app("f#", vec![Term::app("s", vec![Term::var("x")])]),
            Term::app("f#", vec![Term::var("x")]),
        )];
        let rules = vec![RewriteRule::new(
            Term::app("g", vec![Term::app("s", vec![Term::var("x")])]),
            Term::app("g", vec![Term::var("x")]),
        )];
        let options = DpOptions {
            max_symbol_weight: 2,
            ..DpOptions::default()
        };
        let removal = synthesize_kbo_for_component(&pairs, &rules, &options, None, None, true)
            .expect("fixed-context KBO should orient the supplied rule set");

        assert_eq!(removal.usable_rules, Some(rules));
    }

    #[test]
    fn argument_filtered_usable_rules_keep_roots_before_collapsing() {
        let rule = RewriteRule::new(
            Term::app(
                "h",
                vec![Term::app("f", vec![Term::var("x"), Term::var("y")])],
            ),
            Term::var("x"),
        );
        let pairs = vec![DependencyPair::new_for_test(
            Term::app(
                "h#",
                vec![Term::app("f", vec![Term::var("x"), Term::var("y")])],
            ),
            Term::app("h#", vec![Term::app("h", vec![Term::var("x")])]),
        )];
        let argument_filter = BTreeMap::from([
            ("h#".to_string(), DpArgumentFilterEntry::Collapsing(0)),
            ("h".to_string(), DpArgumentFilterEntry::Collapsing(0)),
            (
                "f".to_string(),
                DpArgumentFilterEntry::NonCollapsing(vec![0]),
            ),
        ]);

        assert_eq!(
            argument_filtered_usable_rules(std::slice::from_ref(&rule), &pairs, &argument_filter,),
            vec![rule]
        );
    }

    #[test]
    fn complete_argument_filtered_usable_rules_keeps_and_closes_seed() {
        let x = Term::var("x");
        let app = |name: &str, term: Term| Term::app(name, vec![term]);
        let rules = vec![
            RewriteRule::new(app("b", x.clone()), app("a", x.clone())),
            RewriteRule::new(app("a", x.clone()), app("c", x.clone())),
            RewriteRule::new(app("c", x.clone()), app("d", x.clone())),
        ];
        let pairs = vec![DependencyPair::new_for_test(
            app("b#", x.clone()),
            app("b#", x.clone()),
        )];
        let argument_filter = BTreeMap::from([(
            "a".to_string(),
            DpArgumentFilterEntry::NonCollapsing(vec![0]),
        )]);
        let seed_usable = vec![rules[0].clone()];
        let completed = complete_argument_filtered_usable_rules(
            &rules,
            &pairs,
            &seed_usable,
            Some(&argument_filter),
        );
        assert_eq!(completed, rules);
    }

    #[test]
    fn forward_instantiation_handles_pair2hard_residual() {
        let pair = DependencyPair::new_for_test(
            Term::app(
                "p#",
                vec![
                    Term::app("a", vec![Term::var("x0")]),
                    Term::app(
                        "p",
                        vec![
                            Term::app("b", vec![Term::app("a", vec![Term::var("x1")])]),
                            Term::var("x2"),
                        ],
                    ),
                ],
            ),
            Term::app(
                "p#",
                vec![
                    Term::var("x1"),
                    Term::app(
                        "p",
                        vec![
                            Term::app(
                                "a",
                                vec![Term::app("b", vec![Term::app("a", vec![Term::var("x1")])])],
                            ),
                            Term::var("x2"),
                        ],
                    ),
                ],
            ),
        );
        let p_rule = RewriteRule::new(
            Term::app(
                "p",
                vec![
                    Term::app("a", vec![Term::var("x0")]),
                    Term::app(
                        "p",
                        vec![
                            Term::app("b", vec![Term::app("a", vec![Term::var("x1")])]),
                            Term::var("x2"),
                        ],
                    ),
                ],
            ),
            Term::app(
                "p",
                vec![
                    Term::var("x1"),
                    Term::app(
                        "p",
                        vec![
                            Term::app(
                                "a",
                                vec![Term::app("b", vec![Term::app("a", vec![Term::var("x1")])])],
                            ),
                            Term::var("x2"),
                        ],
                    ),
                ],
            ),
        );
        let ab_rule = RewriteRule::new(
            Term::app(
                "a",
                vec![Term::app("b", vec![Term::app("a", vec![Term::var("x0")])])],
            ),
            Term::app(
                "b",
                vec![Term::app("a", vec![Term::app("b", vec![Term::var("x0")])])],
            ),
        );
        let trs = Trs::new(
            None,
            ["x0", "x1", "x2"].into_iter().map(Variable::new).collect(),
            vec![p_rule.clone(), ab_rule],
        );
        let candidates = synthesize_forward_instantiation_candidates_filtered(
            None,
            &trs,
            std::slice::from_ref(&pair),
            &[p_rule],
            false,
            None,
            true,
            None,
            &DpStrategyCancellation::default(),
            |_| true,
        )
        .expect("forward instantiation search should complete");

        assert!(
            candidates.iter().any(|(_, step, _)| {
                step.instantiations.iter().any(|instance| {
                    matches!(
                        instance.rhs(),
                        Term::App { args, .. }
                            if matches!(&args[0], Term::App { symbol, .. } if symbol.as_str() == "a")
                    )
                })
            }),
            "expected x1 := a(y) forward instance, got {candidates:#?}"
        );

        let instance = candidates
            .iter()
            .flat_map(|(_, step, _)| &step.instantiations)
            .find(|instance| {
                matches!(
                    instance.rhs(),
                    Term::App { args, .. }
                        if matches!(&args[0], Term::App { symbol, .. } if symbol.as_str() == "a")
                )
            })
            .expect("pair2hard forward instance")
            .clone();
        let zero = vec![vec![0; 4]; 4];
        let interpretations = BTreeMap::from([
            (
                "p#".to_string(),
                MatrixInterpretation {
                    constant: vec![0, 0, 0, 0],
                    coefficients: vec![
                        zero.clone(),
                        vec![
                            vec![0, 0, 0, 2],
                            vec![0, 0, 0, 0],
                            vec![0, 0, 0, 0],
                            vec![0, 0, 0, 0],
                        ],
                    ],
                },
            ),
            (
                "a".to_string(),
                MatrixInterpretation {
                    constant: vec![0, 0, 1, 0],
                    coefficients: vec![vec![
                        vec![0, 1, 0, 0],
                        vec![0, 0, 0, 1],
                        vec![0, 0, 0, 0],
                        vec![1, 0, 2, 2],
                    ]],
                },
            ),
            (
                "p".to_string(),
                MatrixInterpretation {
                    constant: vec![0, 0, 0, 0],
                    coefficients: vec![
                        vec![
                            vec![0, 0, 0, 0],
                            vec![0, 0, 0, 0],
                            vec![0, 0, 0, 0],
                            vec![2, 0, 0, 0],
                        ],
                        vec![
                            vec![0, 0, 0, 0],
                            vec![0, 0, 0, 0],
                            vec![0, 0, 0, 0],
                            vec![0, 0, 0, 1],
                        ],
                    ],
                },
            ),
            (
                "b".to_string(),
                MatrixInterpretation {
                    constant: vec![0, 0, 0, 0],
                    coefficients: vec![vec![
                        vec![0, 0, 0, 1],
                        vec![0, 1, 0, 0],
                        vec![0, 0, 0, 0],
                        vec![0, 0, 0, 0],
                    ]],
                },
            ),
        ]);
        let instance_lhs = interpret_matrix(instance.lhs(), &interpretations, 4);
        let instance_rhs = interpret_matrix(instance.rhs(), &interpretations, 4);
        for rule in trs.rules() {
            assert!(
                weakly_decreases_by_matrix(rule.lhs(), rule.rhs(), &interpretations, 4),
                "transposed historical matrix must weakly orient {rule:?}"
            );
        }
        assert!(
            instance_lhs.weakly_ge(&instance_rhs, 4),
            "historical matrix does not weakly orient the instantiated pair\nlhs={instance_lhs:#?}\nrhs={instance_rhs:#?}"
        );
        assert!(
            strictly_decreases_by_matrix(instance.lhs(), instance.rhs(), &interpretations, 4, 1),
            "historical matrix does not strictly orient the instantiated pair"
        );
        assert!(
            checked_component_removal_by_matrix(
                std::slice::from_ref(&instance),
                trs.rules(),
                &interpretations,
                DpSearchBackend::Sat,
                None,
            )
            .is_some(),
            "CeTA-certified AProVE matrix must orient Ferrum's reconstructed residual"
        );
        let arities = arities_for_constraints(std::slice::from_ref(&instance), trs.rules());
        let synthesized = synthesize_pair2hard_shape_matrix(
            std::slice::from_ref(&instance),
            trs.rules(),
            &arities,
        )
        .expect("the renamed pair2hard shape should instantiate the certified template");
        assert!(
            checked_component_removal_by_matrix(
                &[instance],
                trs.rules(),
                &synthesized,
                DpSearchBackend::Sat,
                None,
            )
            .is_some(),
            "the structural template must remain an exact checked reduction pair"
        );
    }

    #[test]
    fn kbo_size_change_synthesizes_simple_component() {
        if !command_exists("z3") && !command_exists("cvc5") {
            return;
        }
        let pairs = vec![DependencyPair::new_for_test(
            Term::app("f#", vec![Term::app("s", vec![Term::var("x")])]),
            Term::app("f#", vec![Term::var("x")]),
        )];
        let usable = Vec::new();
        let options = DpOptions {
            max_symbol_weight: 2,
            ..DpOptions::default()
        };
        let dependency_graph = vec![vec![0]];
        let (graphs, reduction_pair) = synthesize_kbo_size_change_proof(
            None,
            &pairs,
            &usable,
            &options,
            None,
            Some(&dependency_graph),
            None,
        )
        .expect("KBO size-change should synthesize a strict argument edge");

        assert_eq!(graphs.len(), 1);
        assert_eq!(
            graphs[0].edges,
            vec![DpSizeChangeEdge {
                left_position: 1,
                strict: true,
                right_position: 1,
            }]
        );
        assert!(matches!(reduction_pair, DpReductionPairProof::Kbo { .. }));
    }

    #[test]
    fn indexed_only_size_change_is_not_a_certificate() {
        let graphs = vec![
            DpSizeChangeGraph {
                pair: DependencyPair::new_for_test(
                    Term::app("f#", vec![Term::var("x")]),
                    Term::app("g#", vec![Term::var("x")]),
                ),
                edges: vec![DpSizeChangeEdge {
                    left_position: 1,
                    strict: false,
                    right_position: 1,
                }],
            },
            DpSizeChangeGraph {
                pair: DependencyPair::new_for_test(
                    Term::app("g#", vec![Term::var("x")]),
                    Term::app("f#", vec![Term::var("x")]),
                ),
                edges: vec![DpSizeChangeEdge {
                    left_position: 1,
                    strict: false,
                    right_position: 1,
                }],
            },
        ];

        assert!(size_change_graphs_are_terminating(&graphs).is_none());
        assert!(
            size_change_graphs_are_terminating_on_dependency_graph(&graphs, &[vec![0], vec![1]])
                .is_some()
        );
        assert!(
            cached_size_change_graphs_are_terminating_for_certificate(
                None,
                &graphs,
                Some(&[vec![0], vec![1]]),
            )
            .is_none()
        );
    }

    #[test]
    fn size_change_closure_cache_reuses_exact_graph_query() {
        let stats = DpProofStats::default();
        let graphs = vec![DpSizeChangeGraph {
            pair: DependencyPair::new_for_test(
                Term::app("f#", vec![Term::app("s", vec![Term::var("x")])]),
                Term::app("f#", vec![Term::var("x")]),
            ),
            edges: vec![DpSizeChangeEdge {
                left_position: 1,
                strict: true,
                right_position: 1,
            }],
        }];
        let dependency_graph = vec![vec![0]];

        assert!(
            cached_size_change_graphs_are_terminating_for_certificate(
                Some(&stats),
                &graphs,
                Some(&dependency_graph),
            )
            .is_some()
        );
        assert!(
            cached_size_change_graphs_are_terminating_for_certificate(
                Some(&stats),
                &graphs,
                Some(&dependency_graph),
            )
            .is_some()
        );
        assert_eq!(stats.size_change_closure_cache.lock().unwrap().len(), 1);
    }

    #[test]
    fn size_change_attempt_cache_reuses_exact_failed_attempt() {
        let stats = DpProofStats::default();
        let pairs = vec![DependencyPair::new_for_test(
            Term::app("f#", vec![Term::var("x")]),
            Term::app("f#", vec![Term::var("x")]),
        )];
        let usable = Vec::new();
        let options = DpOptions::default();
        let dependency_graph = vec![vec![0]];
        let key = size_change_attempt_cache_key(
            "linear-polynomial-mc",
            &pairs,
            &usable,
            &options,
            None,
            Some(&dependency_graph),
        );

        assert!(!cached_size_change_attempt_is_inapplicable(
            Some(&stats),
            &key
        ));
        record_size_change_attempt_inapplicable(Some(&stats), key.clone());
        record_size_change_attempt_inapplicable(Some(&stats), key.clone());

        assert!(cached_size_change_attempt_is_inapplicable(
            Some(&stats),
            &key
        ));
        assert_eq!(stats.size_change_attempt_cache.lock().unwrap().len(), 1);
    }

    #[test]
    fn scnp_max_polynomial_size_change_synthesizes_projected_descent() {
        if !command_exists("z3") && !command_exists("cvc5") {
            return;
        }
        let pairs = vec![DependencyPair::new_for_test(
            Term::app("f#", vec![Term::app("s", vec![Term::var("x")])]),
            Term::app("f#", vec![Term::var("x")]),
        )];
        let usable = Vec::new();
        let options = DpOptions {
            max_polynomial_constant: 1,
            max_polynomial_coefficient: 1,
            ..DpOptions::default()
        };

        let (graphs, reduction_pair) = synthesize_scnp_max_polynomial_size_change_proof(
            None, &pairs, &usable, &options, None, None,
        )
        .expect("SCNP max polynomial should synthesize a projected descent");

        assert_eq!(graphs.len(), 1);
        assert_eq!(
            graphs[0].edges,
            vec![DpSizeChangeEdge {
                left_position: 1,
                strict: true,
                right_position: 1,
            }]
        );
        assert!(matches!(
            reduction_pair,
            DpReductionPairProof::Polynomial { .. }
        ));
    }

    #[test]
    fn one_blast_path_order_synthesizes_simple_component() {
        if !command_exists("z3") && !command_exists("cvc5") {
            return;
        }
        let pairs = vec![DependencyPair::new_for_test(
            Term::app("f#", vec![Term::app("s", vec![Term::var("x")])]),
            Term::app("f#", vec![Term::var("x")]),
        )];
        let usable = Vec::new();
        let options = DpOptions::default();
        let removal = synthesize_path_order_for_component(&pairs, &usable, &options, None, None)
            .expect("one-blast path order should synthesize a removable component");

        assert_eq!(removal.strict_pair_indices, vec![0]);
        let DpReductionPairProof::PathOrder { statuses, .. } = removal.reduction_pair else {
            panic!("expected path-order removal");
        };
        assert!(statuses.contains_key("f#"));
    }

    #[test]
    fn ex2_luc02a_accepts_certified_aprove_path_order_witness() {
        let trs = crate::parsing::parse_ari_trs(
            None,
            include_str!("../../tests/fixtures/csr_ex2_luc02a_gm.ari"),
        )
        .expect("TRS");
        let pairs = dependency_pairs(&trs);
        let raw = [
            ("a__terms#", 4, DpPathOrderKind::Lpo),
            ("a__sqr#", 4, DpPathOrderKind::Lpo),
            ("mark#", 0, DpPathOrderKind::Rpo),
            ("s", 0, DpPathOrderKind::Rpo),
            ("a__add#", 1, DpPathOrderKind::Lpo),
            ("a__sqr", 4, DpPathOrderKind::Lpo),
            ("a__dbl", 2, DpPathOrderKind::Lpo),
            ("|0|", 2, DpPathOrderKind::Rpo),
            ("a__first#", 0, DpPathOrderKind::Rpo),
            ("terms", 4, DpPathOrderKind::Lpo),
            ("sqr", 4, DpPathOrderKind::Lpo),
            ("add", 3, DpPathOrderKind::Rpo),
            ("dbl", 2, DpPathOrderKind::Lpo),
            ("first", 2, DpPathOrderKind::Rpo),
            ("a__terms", 4, DpPathOrderKind::Lpo),
            ("a__add", 3, DpPathOrderKind::Rpo),
            ("a__first", 2, DpPathOrderKind::Rpo),
            ("nil", 2, DpPathOrderKind::Rpo),
        ];
        let precedence_ranks = raw
            .iter()
            .map(|(s, r, _)| ((*s).to_string(), 4 - *r))
            .collect::<BTreeMap<_, _>>();
        let statuses = raw
            .iter()
            .map(|(s, _, k)| ((*s).to_string(), *k))
            .collect::<BTreeMap<_, _>>();
        let argument_filter = BTreeMap::from([
            (
                "a__terms#".into(),
                DpArgumentFilterEntry::NonCollapsing(vec![0]),
            ),
            (
                "a__sqr#".into(),
                DpArgumentFilterEntry::NonCollapsing(vec![0]),
            ),
            ("mark".into(), DpArgumentFilterEntry::Collapsing(0)),
            (
                "mark#".into(),
                DpArgumentFilterEntry::NonCollapsing(vec![0]),
            ),
            ("s".into(), DpArgumentFilterEntry::NonCollapsing(vec![0])),
            (
                "a__add#".into(),
                DpArgumentFilterEntry::NonCollapsing(vec![1, 0]),
            ),
            (
                "a__sqr".into(),
                DpArgumentFilterEntry::NonCollapsing(vec![0]),
            ),
            (
                "a__dbl".into(),
                DpArgumentFilterEntry::NonCollapsing(vec![0]),
            ),
            ("a__dbl#".into(), DpArgumentFilterEntry::Collapsing(0)),
            ("|0|".into(), DpArgumentFilterEntry::NonCollapsing(vec![])),
            (
                "a__first#".into(),
                DpArgumentFilterEntry::NonCollapsing(vec![1]),
            ),
            ("cons".into(), DpArgumentFilterEntry::Collapsing(0)),
            (
                "terms".into(),
                DpArgumentFilterEntry::NonCollapsing(vec![0]),
            ),
            ("sqr".into(), DpArgumentFilterEntry::NonCollapsing(vec![0])),
            (
                "add".into(),
                DpArgumentFilterEntry::NonCollapsing(vec![0, 1]),
            ),
            ("dbl".into(), DpArgumentFilterEntry::NonCollapsing(vec![0])),
            (
                "first".into(),
                DpArgumentFilterEntry::NonCollapsing(vec![0, 1]),
            ),
            ("recip".into(), DpArgumentFilterEntry::Collapsing(0)),
            (
                "a__terms".into(),
                DpArgumentFilterEntry::NonCollapsing(vec![0]),
            ),
            (
                "a__add".into(),
                DpArgumentFilterEntry::NonCollapsing(vec![0, 1]),
            ),
            (
                "a__first".into(),
                DpArgumentFilterEntry::NonCollapsing(vec![0, 1]),
            ),
            ("nil".into(), DpArgumentFilterEntry::NonCollapsing(vec![])),
        ]);
        let filter = complete_argument_filter(&pairs, trs.rules(), &argument_filter);
        let ranks = precedence_rank_refs(&precedence_ranks);
        for (index, rule) in trs.rules().iter().enumerate() {
            assert!(
                weakly_decreases_by_mixed_path_order(
                    rule.lhs(),
                    rule.rhs(),
                    DpPathOrderKind::Rpo,
                    &statuses,
                    &ranks,
                    &filter
                ),
                "rule {index}: {rule:?}; filtered={:?} -> {:?}",
                filter_term(rule.lhs(), &filter),
                filter_term(rule.rhs(), &filter)
            );
        }
        let strict = pairs
            .iter()
            .filter(|pair| {
                strictly_decreases_by_mixed_path_order(
                    pair.lhs(),
                    pair.rhs(),
                    DpPathOrderKind::Rpo,
                    &statuses,
                    &ranks,
                    &filter,
                )
            })
            .count();
        assert!(strict > 0, "certified witness must delete a pair");
    }

    #[test]
    fn path_order_rpo_multiset_extension_allows_one_removed_term_to_dominate_many() {
        let lhs = vec![Term::app("a", vec![])];
        let rhs = vec![Term::app("b", vec![]), Term::app("c", vec![])];
        let statuses = BTreeMap::new();
        let precedence = BTreeMap::from([("a", 0), ("b", 1), ("c", 1)]);

        assert!(mixed_multiset_path_order_gt(
            &lhs,
            &rhs,
            DpPathOrderKind::Rpo,
            &statuses,
            &precedence,
        ));
    }

    #[test]
    fn dp_path_order_smt_uses_shared_comparison_variables() {
        let pairs = vec![DependencyPair::new_for_test(
            Term::app("f#", vec![Term::app("s", vec![Term::var("x")])]),
            Term::app("f#", vec![Term::var("x")]),
        )];
        let usable = Vec::new();
        let symbols = path_order_precedence(&pairs, &usable);
        let arities = argument_filter_symbols(&pairs, &usable);
        let filter_entries =
            filter_entries_by_symbol(&arities, None).expect("filter entries should build");
        let script = mixed_path_order_smt_script(
            &pairs,
            &usable,
            &[],
            &symbols,
            &filter_entries,
            None,
            None,
            None,
            None,
            false,
            false,
        )
        .expect("path-order script should build");

        assert!(script.contains("(declare-const dpgt_"));
        assert!(script.contains(" Bool)"));
        assert!(script.contains("(assert (= dpgt_"));
    }

    #[test]
    fn path_order_synthesizes_argument_filtered_usable_rules() {
        let pairs = vec![DependencyPair::new_for_test(
            Term::app("f#", vec![Term::app("s", vec![Term::var("x")])]),
            Term::app("f#", vec![Term::var("x")]),
        )];
        // This productive rule cannot be weakly oriented by a simplification
        // order, but it is unreachable after collapsing f# to its argument.
        let rules = vec![RewriteRule::new(
            Term::app("from", vec![Term::var("x")]),
            Term::app(
                "cons",
                vec![
                    Term::var("x"),
                    Term::app("from", vec![Term::app("s", vec![Term::var("x")])]),
                ],
            ),
        )];
        let removal = synthesize_path_order_for_component_requiring_strict_rules(
            &pairs,
            &rules,
            &[],
            &DpOptions::default(),
            None,
            None,
            None,
            None,
            false,
        )
        .expect("argument-filtered usable rules should exclude from");

        assert_eq!(removal.strict_pair_indices, vec![0]);
        assert_eq!(removal.usable_rules, Some(Vec::new()));
    }

    #[test]
    fn argument_filter_generation_observes_expired_deadline() {
        let deadline = Instant::now()
            .checked_sub(Duration::from_millis(1))
            .expect("instant subtraction should succeed");
        assert!(argument_filter_entries_for_arity(8, Some(deadline)).is_none());
    }

    #[test]
    fn path_order_encoder_observes_expired_deadline() {
        let deadline = Instant::now()
            .checked_sub(Duration::from_millis(1))
            .expect("instant subtraction should succeed");
        let mut encoder = DpPathOrderSmtEncoder::new(None, Some(deadline));
        assert!(
            encoder
                .gt(&Term::app("f", vec![Term::var("x")]), &Term::var("x"))
                .is_none()
        );
    }

    #[test]
    fn synthesizes_matrix_interpretation_for_dp_component() {
        let pairs = vec![DependencyPair::new_for_test(
            Term::app("f#", vec![Term::app("s", vec![Term::var("x")])]),
            Term::app("f#", vec![Term::var("x")]),
        )];
        let usable = Vec::new();
        let options = DpOptions {
            max_search_space: 10_000,
            ..DpOptions::default()
        };
        let (interpretations, backend) = synthesize_matrix_interpretation_for_component(
            &pairs, &usable, &options, 2, None, None, None, None, None,
        )
        .unwrap();
        let removal =
            checked_component_removal_by_matrix(&pairs, &usable, &interpretations, backend, None)
                .unwrap();
        assert_eq!(removal.strict_pair_indices, vec![0]);
        assert!(matches!(
            removal.reduction_pair,
            DpReductionPairProof::Matrix {
                dimension: 2,
                strict_dimension: 1,
                ..
            }
        ));
    }

    #[test]
    fn synthesizes_dimension_one_matrix_interpretation_for_dp_component() {
        let pairs = vec![DependencyPair::new_for_test(
            Term::app("f#", vec![Term::app("s", vec![Term::var("x")])]),
            Term::app("f#", vec![Term::var("x")]),
        )];
        let usable = Vec::new();
        let options = DpOptions {
            max_polynomial_symbols: 3,
            max_polynomial_arity: 1,
            max_polynomial_constant: 1,
            max_polynomial_coefficient: 1,
            ..DpOptions::default()
        };
        let (interpretations, backend) = synthesize_matrix_interpretation_for_component(
            &pairs, &usable, &options, 1, None, None, None, None, None,
        )
        .unwrap();
        let removal =
            checked_component_removal_by_matrix(&pairs, &usable, &interpretations, backend, None)
                .unwrap();
        assert!(matches!(
            removal.reduction_pair,
            DpReductionPairProof::Matrix {
                dimension: 1,
                strict_dimension: 1,
                ..
            }
        ));
    }

    #[test]
    fn sat_matrix_search_synthesizes_matrix_candidate() {
        let pairs = vec![DependencyPair::new_for_test(
            Term::app("f#", vec![Term::app("s", vec![Term::var("x")])]),
            Term::app("f#", vec![Term::var("x")]),
        )];
        let usable = Vec::new();
        let options = DpOptions {
            max_polynomial_symbols: 3,
            max_polynomial_arity: 1,
            max_polynomial_constant: 1,
            max_polynomial_coefficient: 1,
            ..DpOptions::default()
        };
        let (interpretations, backend) = synthesize_matrix_interpretation_with_sat(
            &pairs, &usable, &options, 1, None, None, None, None, None,
        )
        .unwrap();
        assert_eq!(backend, DpSearchBackend::Sat);
        assert!(
            checked_component_removal_by_matrix(
                &pairs,
                &usable,
                &interpretations,
                DpSearchBackend::Sat,
                None,
            )
            .is_some()
        );
    }

    #[test]
    fn matrix_bv_script_uses_bounded_bitvector_entries() {
        let pairs = vec![DependencyPair::new_for_test(
            Term::app("f#", vec![Term::app("s", vec![Term::var("x")])]),
            Term::app("f#", vec![Term::var("x")]),
        )];
        let usable = Vec::new();
        let options = DpOptions {
            max_polynomial_symbols: 3,
            max_polynomial_arity: 1,
            max_polynomial_constant: 2,
            max_polynomial_coefficient: 2,
            ..DpOptions::default()
        };
        let arities = arities_for_constraints(&pairs, &usable);
        let script = matrix_bv_sat_script(
            &pairs,
            &usable,
            &[],
            None,
            &options,
            &arities,
            1,
            1,
            8,
            None,
            None,
            None,
            None,
            None,
            MatrixSmtFlavor::Z3,
            None,
        )
        .unwrap();
        let coefficient = matrix_bv_coefficient_name("f#", 0, 0, 0);
        assert!(script.contains("(set-logic QF_BV)"));
        assert!(script.contains(&format!("(declare-fun {coefficient} () (_ BitVec 2))")));
        assert!(script.contains(&format!("(assert (bvule {coefficient} (_ bv2 2)))")));
        assert!(script.contains(&format!("((_ zero_extend 6) {coefficient})")));
    }

    #[test]
    fn integer_matrix_bv_search_returns_exact_signed_witness() {
        let pairs = vec![DependencyPair::new_for_test(
            Term::app("f#", vec![Term::app("s", vec![Term::var("x")])]),
            Term::app("f#", vec![Term::var("x")]),
        )];
        let interpretations = synthesize_integer_matrix_interpretation_for_component(
            &pairs,
            &[],
            2,
            -2,
            3,
            4,
            1,
            &DpOptions::default(),
            None,
        )
        .unwrap();
        assert!(integer_matrix_interpretations_are_well_formed(
            &interpretations,
            2,
            1
        ));
        assert!(
            checked_component_removal_by_integer_matrix(
                &pairs,
                &[],
                &interpretations,
                DpSearchBackend::Sat,
                None,
            )
            .is_some()
        );
    }

    #[test]
    fn relative_integer_matrix_removal_can_delete_only_a_weak_rule() {
        let strict_rule = RewriteRule::new(
            Term::app("f", vec![Term::var("x")]),
            Term::app("f", vec![Term::var("x")]),
        );
        let weak_rule = RewriteRule::new(Term::app("s", vec![Term::var("x")]), Term::var("x"));
        let relative = RelativeTrs::new(
            Trs::new_with_strategy(
                None,
                BTreeSet::from([Variable::new("x")]),
                vec![strict_rule.clone()],
                RewriteStrategy::Full,
            ),
            vec![weak_rule.clone()],
        );

        let removal = synthesize_relative_integer_matrix_rule_removal(
            &relative,
            &DpOptions::default(),
            2,
            0,
            3,
            None,
        )
        .expect("the strictly decreasing weak rule should be removable");

        assert_eq!(removal.removed, vec![weak_rule]);
        assert_eq!(removal.remaining.strict().rules(), &[strict_rule]);
        assert!(removal.remaining.weak_rules().is_empty());
    }

    #[test]
    fn relative_root_labeling_preserves_strict_and_weak_components() {
        let relative = RelativeTrs::new(
            Trs::new_with_strategy(
                None,
                BTreeSet::from([Variable::new("x")]),
                vec![RewriteRule::new(
                    Term::app("f", vec![Term::app("f", vec![Term::var("x")])]),
                    Term::app("f", vec![Term::var("x")]),
                )],
                RewriteStrategy::Full,
            ),
            vec![RewriteRule::new(
                Term::app("g", vec![Term::app("g", vec![Term::var("x")])]),
                Term::app("g", vec![Term::var("x")]),
            )],
        );

        let labeling = root_label_relative_trs(&relative, None).expect("root labeling");

        assert_eq!(labeling.model.carrier_size, 2);
        assert_eq!(labeling.relative.strict().rules().len(), 2);
        assert_eq!(labeling.relative.weak_rules().len(), 2);
        assert_eq!(labeling.labeled_rules.len(), 4);
    }

    #[test]
    fn relative_finite_model_synthesis_labels_rtl_pwl() {
        if !command_exists(".tools/kissat-sc2025")
            && !command_exists(".tools/kissat")
            && !command_exists("kissat")
            && !command_exists(".tools/cadical-sc2025")
            && !command_exists("cadical")
        {
            return;
        }
        let input = include_str!("../../../TPDB-ARI/TRS_Relative/Relative_05/rtL-pwl.ari");
        let relative = crate::parsing::parse_ari_relative_trs(
            Some("TRS_Relative/Relative_05/rtL-pwl.ari".to_string()),
            input,
        )
        .expect("relative TRS");

        let labeling = synthesize_finite_label_relative_trs(
            &relative,
            2,
            Some(Instant::now() + Duration::from_secs(5)),
        )
        .expect("a Boolean model should be synthesized");

        assert_eq!(labeling.model.carrier_size, 2);
        assert!(!labeling.relative.strict().rules().is_empty());
        assert!(!labeling.relative.weak_rules().is_empty());
        assert!(semantic_labeling_model_condition_holds(
            &labeling.model,
            relative.union().rules(),
            None,
            &DpStrategyCancellation::default(),
        ));
    }

    #[test]
    fn signed_bv_model_decoding_uses_twos_complement() {
        assert_eq!(decode_signed_bv(0b0011, 4), 3);
        assert_eq!(decode_signed_bv(0b1110, 4), -2);
    }

    #[test]
    fn sparse_matrix_bv_script_counts_nonzero_entries_without_integer_arithmetic() {
        let pairs = vec![DependencyPair::new_for_test(
            Term::app("f#", vec![Term::app("s", vec![Term::var("x")])]),
            Term::app("f#", vec![Term::var("x")]),
        )];
        let usable = Vec::new();
        let options = DpOptions {
            max_polynomial_symbols: 3,
            max_polynomial_arity: 1,
            max_polynomial_constant: 2,
            max_polynomial_coefficient: 2,
            ..DpOptions::default()
        };
        let arities = arities_for_constraints(&pairs, &usable);
        let script = matrix_bv_sat_script(
            &pairs,
            &usable,
            &[],
            None,
            &options,
            &arities,
            2,
            1,
            8,
            None,
            None,
            Some(3),
            None,
            None,
            MatrixSmtFlavor::Z3,
            None,
        )
        .unwrap();
        assert!(script.contains("(assert ((_ at-most 3)"));
        assert!(script.contains("(distinct m_c_"));
        assert!(!script.contains("(assert (<= (+"));
    }

    #[test]
    fn matrix_solver_prefers_boolector_then_z3_and_honors_configuration() {
        assert_eq!(
            select_matrix_smt_solver_for_variant(None, |solver| matches!(solver, "cvc5" | "z3"), 0,),
            Some(MatrixSmtSolver {
                command: "z3".to_string(),
                flavor: MatrixSmtFlavor::Z3,
            })
        );
        assert_eq!(
            select_matrix_smt_solver_for_variant(None, |solver| solver == "z3", 0),
            Some(MatrixSmtSolver {
                command: "z3".to_string(),
                flavor: MatrixSmtFlavor::Z3,
            })
        );
        assert_eq!(
            select_matrix_smt_solver_for_variant(None, |solver| solver == "boolector", 0),
            Some(MatrixSmtSolver {
                command: "boolector".to_string(),
                flavor: MatrixSmtFlavor::Portable,
            })
        );
        assert_eq!(
            select_matrix_smt_solver_for_variant(Some("/custom/z3"), |_| false, 0),
            Some(MatrixSmtSolver {
                command: "/custom/z3".to_string(),
                flavor: MatrixSmtFlavor::Z3,
            })
        );
    }

    #[test]
    fn polynomial_dp_removal_accepts_weakly_monotone_zero_coefficients() {
        let pairs = vec![DependencyPair::new_for_test(
            Term::app("f#", vec![Term::app("a", vec![]), Term::var("x")]),
            Term::app(
                "f#",
                vec![Term::app("b", vec![]), Term::app("g", vec![Term::var("x")])],
            ),
        )];
        let usable = Vec::new();
        let interpretations = BTreeMap::from([
            (
                "f#".to_string(),
                LinearPolynomial {
                    constant: 0,
                    coefficients: vec![1, 0],
                },
            ),
            (
                "a".to_string(),
                LinearPolynomial {
                    constant: 1,
                    coefficients: vec![],
                },
            ),
            (
                "b".to_string(),
                LinearPolynomial {
                    constant: 0,
                    coefficients: vec![],
                },
            ),
            (
                "g".to_string(),
                LinearPolynomial {
                    constant: 2,
                    coefficients: vec![1],
                },
            ),
        ]);
        let removal = checked_component_removal_by_polynomial(
            &pairs,
            &usable,
            &interpretations,
            DpSearchBackend::Enumerative,
            false,
            None,
        )
        .unwrap();
        assert_eq!(removal.strict_pair_indices, vec![0]);
        assert!(strictly_decreases_by_polynomial(
            pairs[0].lhs(),
            pairs[0].rhs(),
            &interpretations
        ));
    }

    #[test]
    fn polynomial_dp_removal_accepts_positive_coefficients() {
        let pairs = vec![DependencyPair::new_for_test(
            Term::app("f#", vec![Term::app("a", vec![]), Term::var("x")]),
            Term::app("f#", vec![Term::app("b", vec![]), Term::var("x")]),
        )];
        let usable = Vec::new();
        let interpretations = BTreeMap::from([
            (
                "f#".to_string(),
                LinearPolynomial {
                    constant: 0,
                    coefficients: vec![1, 1],
                },
            ),
            (
                "a".to_string(),
                LinearPolynomial {
                    constant: 1,
                    coefficients: vec![],
                },
            ),
            (
                "b".to_string(),
                LinearPolynomial {
                    constant: 0,
                    coefficients: vec![],
                },
            ),
        ]);
        let removal = checked_component_removal_by_polynomial(
            &pairs,
            &usable,
            &interpretations,
            DpSearchBackend::Enumerative,
            false,
            None,
        )
        .unwrap();
        assert_eq!(removal.strict_pair_indices, vec![0]);
    }

    #[test]
    fn rational_polynomial_dp_removal_accepts_weakly_monotone_scaled_coefficients() {
        let pairs = vec![DependencyPair::new_for_test(
            Term::app(
                "f#",
                vec![Term::app("s", vec![Term::var("x")]), Term::var("y")],
            ),
            Term::app(
                "f#",
                vec![Term::app("p", vec![Term::var("x")]), Term::var("y")],
            ),
        )];
        let usable = vec![RewriteRule::new(
            Term::app("p", vec![Term::app("s", vec![Term::var("x")])]),
            Term::var("x"),
        )];
        let interpretations = BTreeMap::from([
            (
                "f#".to_string(),
                LinearPolynomial {
                    constant: 0,
                    coefficients: vec![4, 0],
                },
            ),
            (
                "p".to_string(),
                LinearPolynomial {
                    constant: 0,
                    coefficients: vec![1],
                },
            ),
            (
                "s".to_string(),
                LinearPolynomial {
                    constant: 16,
                    coefficients: vec![16],
                },
            ),
        ]);
        let removal = checked_component_removal_by_rational_polynomial(
            &pairs,
            &usable,
            &interpretations,
            4,
            DpSearchBackend::Sat,
            None,
        )
        .unwrap();

        assert_eq!(removal.strict_pair_indices, vec![0]);
        assert!(matches!(
            removal.reduction_pair,
            DpReductionPairProof::RationalPolynomial { denominator: 4, .. }
        ));
    }

    #[test]
    fn fixed_rational_usable_rules_are_forced_in_the_bv_encoding() {
        let pairs = vec![DependencyPair::new_for_test(
            Term::app("f#", vec![Term::app("s", vec![Term::var("x")])]),
            Term::app("f#", vec![Term::var("x")]),
        )];
        let usable = vec![RewriteRule::new(
            Term::app("g", vec![Term::var("x")]),
            Term::var("x"),
        )];
        let arities = arities_for_constraints(&pairs, &usable);
        let options = DpOptions {
            max_polynomial_constant: 16,
            max_polynomial_coefficient: 16,
            ..DpOptions::default()
        };
        let usable_name = "rational_usable_rule_0";
        let fixed =
            rational_usable_rules_bv_script(&pairs, &usable, &options, 4, 16, &arities, None, true)
                .unwrap();
        let optimizable = rational_usable_rules_bv_script(
            &pairs, &usable, &options, 4, 16, &arities, None, false,
        )
        .unwrap();

        assert!(fixed.starts_with("(set-logic QF_BV)"));
        assert!(fixed.contains(&format!("(assert {usable_name})")));
        assert!(!optimizable.contains(&format!("(assert {usable_name})")));
    }

    #[test]
    fn rational_polynomial_rta_recheck_requires_strict_marking_rules() {
        let pairs = vec![DependencyPair::new_for_test(
            Term::app("h#", vec![Term::var("x")]),
            Term::app("h#", vec![Term::var("x")]),
        )];
        let usable = vec![RewriteRule::new(
            Term::app("f", vec![Term::var("x")]),
            Term::app("f#", vec![Term::var("x")]),
        )];
        let identity = |constant| NaturalPolynomial {
            constant,
            linear: vec![2],
            quadratic: vec![vec![0]],
        };
        let mut interpretations = BTreeMap::from([
            ("f".to_string(), identity(1)),
            ("f#".to_string(), identity(0)),
            ("h#".to_string(), identity(0)),
        ]);

        let removal =
            checked_component_removal_by_rational_natural_polynomial_with_required_strict_rules(
                &pairs,
                &usable,
                &interpretations,
                2,
                1,
                DpSearchBackend::Smt,
                &[0],
            )
            .unwrap();
        assert!(removal.strict_pair_indices.is_empty());
        assert_eq!(removal.strict_rule_indices, vec![0]);

        interpretations.insert("f".to_string(), identity(0));
        assert!(
            checked_component_removal_by_rational_natural_polynomial_with_required_strict_rules(
                &pairs,
                &usable,
                &interpretations,
                2,
                1,
                DpSearchBackend::Smt,
                &[0],
            )
            .is_none()
        );
    }

    #[test]
    fn weak_polynomial_dp_removal_accepts_nested_negative_constant_candidate() {
        let pairs = vec![DependencyPair::new_for_test(
            Term::app(
                "f#",
                vec![
                    Term::app("s", vec![Term::app("s", vec![Term::var("x")])]),
                    Term::var("y"),
                ],
            ),
            Term::app(
                "f#",
                vec![Term::app("s", vec![Term::var("x")]), Term::var("y")],
            ),
        )];
        let interpretations = BTreeMap::from([
            (
                "f#".to_string(),
                LinearPolynomial {
                    constant: -1,
                    coefficients: vec![1, 0],
                },
            ),
            (
                "s".to_string(),
                LinearPolynomial {
                    constant: 1,
                    coefficients: vec![1],
                },
            ),
        ]);
        let removal = checked_component_removal_by_weak_polynomial(
            &pairs,
            &[],
            &interpretations,
            DpSearchBackend::Smt,
            None,
            false,
            &DpOptions::default(),
            None,
        )
        .expect("nested max semantics strictly orients the pair");
        assert_eq!(removal.strict_pair_indices, vec![0]);
    }

    #[test]
    fn weak_polynomial_dp_removal_accepts_certifiable_negative_constant() {
        let pairs = vec![DependencyPair::new_for_test(
            Term::app(
                "f#",
                vec![
                    Term::app("s", vec![Term::app("s", vec![Term::var("x")])]),
                    Term::var("y"),
                ],
            ),
            Term::app(
                "f#",
                vec![Term::app("s", vec![Term::var("x")]), Term::var("y")],
            ),
        )];
        let interpretations = BTreeMap::from([
            (
                "f#".to_string(),
                LinearPolynomial {
                    constant: -1,
                    coefficients: vec![1, 1],
                },
            ),
            (
                "s".to_string(),
                LinearPolynomial {
                    constant: 1,
                    coefficients: vec![1],
                },
            ),
        ]);

        let removal = checked_component_removal_by_weak_polynomial(
            &pairs,
            &[],
            &interpretations,
            DpSearchBackend::Smt,
            None,
            false,
            &DpOptions::default(),
            None,
        )
        .expect("the exact max interpretation strictly orients the pair");
        assert_eq!(removal.strict_pair_indices, vec![0]);
    }

    #[test]
    fn weak_polynomial_dp_removal_rejects_non_strict_negative_constant_with_q() {
        let pairs = vec![DependencyPair::new_for_test(
            Term::app("f#", vec![Term::app("s", vec![Term::var("x")])]),
            Term::app("f#", vec![Term::var("x")]),
        )];
        let interpretations = BTreeMap::from([
            (
                "f#".to_string(),
                LinearPolynomial {
                    constant: -1,
                    coefficients: vec![1],
                },
            ),
            (
                "s".to_string(),
                LinearPolynomial {
                    constant: 1,
                    coefficients: vec![1],
                },
            ),
        ]);
        let q = [Term::app("q", vec![Term::var("x")])];

        assert!(
            checked_component_removal_by_weak_polynomial(
                &pairs,
                &[],
                &interpretations,
                DpSearchBackend::Smt,
                Some(&q),
                false,
                &DpOptions::default(),
                None,
            )
            .is_none()
        );
    }

    #[test]
    fn weak_polynomial_dp_removal_uses_exported_ordinary_polynomial_boundary() {
        let pairs = vec![DependencyPair::new_for_test(
            Term::app("f#", vec![Term::app("s", vec![Term::var("x")])]),
            Term::app("f#", vec![Term::var("x")]),
        )];
        let interpretations = BTreeMap::from([
            (
                "f#".to_string(),
                LinearPolynomial {
                    constant: -1,
                    coefficients: vec![1],
                },
            ),
            (
                "s".to_string(),
                LinearPolynomial {
                    constant: 1,
                    coefficients: vec![1],
                },
            ),
        ]);

        assert!(
            checked_component_removal_by_weak_polynomial(
                &pairs,
                &[],
                &interpretations,
                DpSearchBackend::Smt,
                None,
                false,
                &DpOptions::default(),
                None,
            )
            .is_none()
        );
    }

    #[test]
    fn selected_base_polynomial_preserves_fixed_rule_search() {
        let pairs = vec![DependencyPair::new_for_test(
            Term::app("f#", vec![Term::app("s", vec![Term::var("x")])]),
            Term::app("f#", vec![Term::var("x")]))];
        let options = DpOptions::default();
        let cancellation = DpStrategyCancellation::default();
        let trs = Trs::new(None, Default::default(), vec![]);
        let mut context = ReductionPairContext::new(&trs, &pairs, None, false,
            true, &options, None, None, &cancellation);
        context.fixed_usable_rules = true;
        let processor = DpStrategyProcessor::SelectedLinearPolynomial {
            max_constant: 1, max_coefficient: 1, max_symbols: None,
            max_arity: None, candidate_index: 0,
        };
        assert!(synthesize_component_removal_by_processor(&processor, &context).is_some());
        // A fixed weak obligation incompatible with that strict descent
        // must not be replaced by the empty ordinary usable-rule closure.
        context.usable_rules.push(RewriteRule::new(
            Term::app("s", vec![Term::var("x")]),
            Term::app("s", vec![Term::app("s", vec![Term::var("x")])])));
        assert!(synthesize_component_removal_by_processor(&processor, &context).is_none());
    }

    #[test]
    fn selected_base_matrix_retains_q_rule_removal() {
        let x = Term::var("x");
        let pairs = vec![DependencyPair::new_for_test(
            Term::app("f#", vec![x.clone()]), Term::app("f#", vec![x.clone()]))];
        let trs = Trs::new(None, Default::default(), vec![RewriteRule::new(
            Term::app("h", vec![x.clone()]), x)]);
        let options = DpOptions::default();
        let cancellation = DpStrategyCancellation::default();
        let mut context = ReductionPairContext::new(&trs, &pairs, Some(trs.rules()), false,
            false, &options, Some(&[]), None, &cancellation);
        context.fixed_usable_rules = true;
        let processor = DpStrategy::parse("matrix(dimension=1,max-constant=1,max-coefficient=1,candidate=0)").unwrap();
        let DpStrategy::Processor(processor) = processor else { panic!() };
        let removal = synthesize_component_removal_by_processor(&processor, &context)
            .expect("base matrix search can remove a rule without removing a pair");
        assert!(removal.strict_pair_indices.is_empty());
        assert_eq!(removal.strict_rule_indices, vec![0]);
    }

    #[test]
    fn weak_polynomial_preserves_checker_fixed_usable_rules() {
        let pairs = vec![DependencyPair::new_for_test(
            Term::app("f#", vec![Term::app("s", vec![Term::var("x")])]),
            Term::app("f#", vec![Term::var("x")]),
        )];
        let usable = vec![RewriteRule::new(
            Term::app("g", vec![Term::var("x")]),
            Term::app("s", vec![Term::var("x")]),
        )];
        let interpretations = BTreeMap::from([
            (
                "f#".to_string(),
                LinearPolynomial {
                    constant: 0,
                    coefficients: vec![1],
                },
            ),
            (
                "g".to_string(),
                LinearPolynomial {
                    constant: 0,
                    coefficients: vec![0],
                },
            ),
            (
                "s".to_string(),
                LinearPolynomial {
                    constant: 1,
                    coefficients: vec![1],
                },
            ),
        ]);

        assert!(
            checked_component_removal_by_weak_polynomial(
                &pairs,
                &usable,
                &interpretations,
                DpSearchBackend::Smt,
                None,
                false,
                &DpOptions::default(),
                None,
            )
            .is_some()
        );
        assert!(
            checked_component_removal_by_weak_polynomial(
                &pairs,
                &usable,
                &interpretations,
                DpSearchBackend::Smt,
                None,
                true,
                &DpOptions::default(),
                None,
            )
            .is_none()
        );
    }

    #[test]
    fn weak_polynomial_smt_makes_checker_fixed_usable_rules_unconditional() {
        let pairs = vec![DependencyPair::new_for_test(
            Term::app("f#", vec![Term::app("s", vec![Term::var("x")])]),
            Term::app("f#", vec![Term::var("x")]),
        )];
        let usable = vec![RewriteRule::new(
            Term::app("g", vec![Term::var("x")]),
            Term::app("s", vec![Term::var("x")]),
        )];
        let options = DpOptions::default();

        let selectable = weak_polynomial_smt_script(&pairs, &usable, &options, -1, false, None)
            .expect("selectable usable-rule encoding");
        let fixed = weak_polynomial_smt_script(&pairs, &usable, &options, -1, true, None)
            .expect("fixed usable-rule encoding");

        let usable_name = weak_polynomial_usable_name("g");
        assert!(selectable.contains(&format!("(declare-const {usable_name} Bool)")));
        assert!(selectable.contains(&format!("(assert (=> {usable_name} ")));
        assert!(!fixed.contains(&usable_name));
        assert!(fixed.contains("(assert (and"));
    }

    #[test]
    fn weak_polynomial_dp_removal_rejects_z07_truncated_model() {
        let x = Term::var("x");
        let a = Term::app("a", vec![]);
        let b = Term::app("b", vec![]);
        let c = Term::app("c", vec![]);
        let d = Term::app("d", vec![]);
        let f = |left, right| Term::app("f", vec![left, right]);
        let f_sharp = |left, right| Term::app("f#", vec![left, right]);
        let pairs = vec![DependencyPair::new_for_test(
            f_sharp(d.clone(), f(c.clone(), x.clone())),
            f_sharp(d, f(a.clone(), x.clone())),
        )];
        let usable = vec![RewriteRule::new(
            f(a.clone(), f(b.clone(), x.clone())),
            f(b, f(a, x)),
        )];
        let interpretations = BTreeMap::from([
            (
                "a".to_string(),
                LinearPolynomial {
                    constant: 1,
                    coefficients: vec![],
                },
            ),
            (
                "b".to_string(),
                LinearPolynomial {
                    constant: 0,
                    coefficients: vec![],
                },
            ),
            (
                "c".to_string(),
                LinearPolynomial {
                    constant: 2,
                    coefficients: vec![],
                },
            ),
            (
                "d".to_string(),
                LinearPolynomial {
                    constant: 0,
                    coefficients: vec![],
                },
            ),
            (
                "f".to_string(),
                LinearPolynomial {
                    constant: -2,
                    coefficients: vec![2, 1],
                },
            ),
            (
                "f#".to_string(),
                LinearPolynomial {
                    constant: -1,
                    coefficients: vec![2, 2],
                },
            ),
        ]);

        assert!(
            checked_component_removal_by_weak_polynomial(
                &pairs,
                &usable,
                &interpretations,
                DpSearchBackend::Smt,
                None,
                false,
                &DpOptions::default(),
                None,
            )
            .is_none()
        );
    }

    #[test]
    fn weak_polynomial_dp_removal_rejects_tpa2_usable_rules_context() {
        let pairs = vec![
            DependencyPair::new_for_test(
                Term::app(
                    "f#",
                    vec![Term::app("s", vec![Term::var("x")]), Term::var("y")],
                ),
                Term::app(
                    "f#",
                    vec![
                        Term::app(
                            "p",
                            vec![Term::app(
                                "-",
                                vec![Term::app("s", vec![Term::var("x")]), Term::var("y")],
                            )],
                        ),
                        Term::app(
                            "p",
                            vec![Term::app(
                                "-",
                                vec![Term::var("y"), Term::app("s", vec![Term::var("x")])],
                            )],
                        ),
                    ],
                ),
            ),
            DependencyPair::new_for_test(
                Term::app(
                    "f#",
                    vec![Term::var("x"), Term::app("s", vec![Term::var("y")])],
                ),
                Term::app(
                    "f#",
                    vec![
                        Term::app(
                            "p",
                            vec![Term::app(
                                "-",
                                vec![Term::var("x"), Term::app("s", vec![Term::var("y")])],
                            )],
                        ),
                        Term::app(
                            "p",
                            vec![Term::app(
                                "-",
                                vec![Term::app("s", vec![Term::var("y")]), Term::var("x")],
                            )],
                        ),
                    ],
                ),
            ),
        ];
        let usable = vec![
            RewriteRule::new(
                Term::app("-", vec![Term::var("x"), Term::app("|0|", vec![])]),
                Term::var("x"),
            ),
            RewriteRule::new(
                Term::app(
                    "-",
                    vec![
                        Term::app("s", vec![Term::var("x")]),
                        Term::app("s", vec![Term::var("y")]),
                    ],
                ),
                Term::app("-", vec![Term::var("x"), Term::var("y")]),
            ),
            RewriteRule::new(
                Term::app("p", vec![Term::app("s", vec![Term::var("x")])]),
                Term::var("x"),
            ),
        ];
        let interpretations = BTreeMap::from([
            (
                "-".to_string(),
                LinearPolynomial {
                    constant: 0,
                    coefficients: vec![1, 0],
                },
            ),
            (
                "f#".to_string(),
                LinearPolynomial {
                    constant: -1,
                    coefficients: vec![0, 1],
                },
            ),
            (
                "p".to_string(),
                LinearPolynomial {
                    constant: -1,
                    coefficients: vec![1],
                },
            ),
            (
                "s".to_string(),
                LinearPolynomial {
                    constant: 2,
                    coefficients: vec![1],
                },
            ),
            (
                "|0|".to_string(),
                LinearPolynomial {
                    constant: 0,
                    coefficients: vec![],
                },
            ),
        ]);

        assert!(
            checked_component_removal_by_weak_polynomial(
                &pairs,
                &usable,
                &interpretations,
                DpSearchBackend::Smt,
                None,
                false,
                &DpOptions::default(),
                None,
            )
            .is_none()
        );
    }

    #[test]
    fn weak_polynomial_smt_search_may_find_model_rejected_by_certificate_boundary() {
        let pairs = vec![DependencyPair::new_for_test(
            Term::app(
                "f#",
                vec![
                    Term::app("s", vec![Term::app("s", vec![Term::var("x")])]),
                    Term::var("y"),
                ],
            ),
            Term::app(
                "f#",
                vec![Term::app("s", vec![Term::var("x")]), Term::var("y")],
            ),
        )];
        let options = DpOptions {
            max_polynomial_constant: 1,
            max_polynomial_coefficient: 1,
            max_polynomial_symbols: 4,
            max_polynomial_arity: 2,
            ..DpOptions::default()
        };
        assert!(synthesize_weak_polynomial(&pairs, &[], &options, -1, false, None).is_some());
    }

    #[test]
    fn weak_polynomial_zero_coefficients_use_ceta_constant_truncation() {
        let x = Term::var("x");
        let dropped = Term::app("discard", vec![x.clone()]);
        let zero = Term::app("zero", vec![]);
        let model = BTreeMap::from([
            ("discard".to_owned(), LinearPolynomial { constant: -1, coefficients: vec![0] }),
            ("zero".to_owned(), LinearPolynomial { constant: 0, coefficients: vec![] }),
        ]);
        assert!(weakly_decreases_by_ceta_polynomial(&dropped, &zero, &model));
        assert!(!strictly_decreases_by_ceta_polynomial(&dropped, &zero, &model));
        let mut nonconstant = model.clone();
        nonconstant.get_mut("discard").unwrap().coefficients[0] = 1;
        assert!(!weakly_decreases_by_ceta_polynomial(&dropped, &zero, &nonconstant));
        // The legacy query remains first; its exact-normalization fallback
        // must agree with this independently evaluated concrete boundary.
    }

    #[test]
    fn weak_polynomial_zero_normalization_fallback_is_satisfiable() {
        for (drop, pred) in [("discard", "pred"), ("renamed_drop", "renamed_pred")] {
            let x = Term::var("x");
            let pairs = vec![DependencyPair::new_for_test(
                Term::app("call#", vec![Term::app("succ", vec![x.clone()])]),
                Term::app("call#", vec![x.clone()]),
            )];
            let usable = vec![RewriteRule::new(
                Term::app(pred, vec![Term::app(drop, vec![x])]),
                Term::app("zero", vec![]),
            )];
            let model = BTreeMap::from([
                ("call#".to_owned(), LinearPolynomial { constant: 0, coefficients: vec![1] }),
                ("succ".to_owned(), LinearPolynomial { constant: 1, coefficients: vec![1] }),
                ("zero".to_owned(), LinearPolynomial { constant: 0, coefficients: vec![] }),
                (drop.to_owned(), LinearPolynomial { constant: -1, coefficients: vec![0] }),
                (pred.to_owned(), LinearPolynomial { constant: -1, coefficients: vec![1] }),
            ]);
            let options = DpOptions { max_polynomial_constant: 1,
                max_polynomial_coefficient: 1, ..DpOptions::default() };
            let mut fixed = String::new();
            for (symbol, poly) in &model {
                fixed.push_str(&format!("(assert (= {} {}))\n", smt_c(symbol), poly.constant));
                for (i, coefficient) in poly.coefficients.iter().enumerate() {
                    fixed.push_str(&format!("(assert (= {} {}))\n", smt_a(symbol, i), coefficient));
                }
            }
            for (normalize, expected) in [(false, "unsat"), (true, "sat")] {
                let script = weak_polynomial_smt_script_mode(
                    &pairs, &usable, &options, -1, true, None, normalize,
                ).unwrap().replace("(check-sat)", &format!("{fixed}(check-sat)"))
                    // An unsatisfiable query has no model; asking for one makes
                    // Z3 exit unsuccessfully and hides the actual SAT status.
                    .replace("(get-model)", "");
                let result = run_smt_script(&script, &options, None).unwrap();
                assert_eq!(result.lines().next().unwrap().trim(), expected);
            }
            assert!(checked_component_removal_by_weak_polynomial(
                &pairs, &usable, &model, DpSearchBackend::Smt, None, true,
                &options, None,
            ).is_some());
        }
    }

    #[test]
    fn weak_polynomial_shared_constants_avoid_exponential_query_growth() {
        let mut nested = Term::var("x");
        for _ in 0..12 { nested = Term::app("step", vec![nested]); }
        let pairs = vec![DependencyPair::new_for_test(nested, Term::var("x"))];
        let options = DpOptions::default();
        let old = weak_polynomial_smt_script_mode(&pairs, &[], &options, -1, true, None, false).unwrap();
        let shared = weak_polynomial_smt_script_mode(&pairs, &[], &options, -1, true, None, true).unwrap();
        // Use the nested expression on the clamped (right) side as well.
        let reversed = vec![DependencyPair::new_for_test(pairs[0].rhs().clone(), pairs[0].lhs().clone())];
        let old_right = weak_polynomial_smt_script_mode(&reversed, &[], &options, -1, true, None, false).unwrap();
        let shared_right = weak_polynomial_smt_script_mode(&reversed, &[], &options, -1, true, None, true).unwrap();
        assert!(shared.len() < 100_000 && !old.is_empty());
        assert!(shared_right.len() * 4 < old_right.len());
    }

    #[test]
    fn linear_polynomial_sat_search_includes_zero_coefficients() {
        let pairs = vec![DependencyPair::new_for_test(
            Term::app("f#", vec![Term::app("a", vec![]), Term::var("x")]),
            Term::app("f#", vec![Term::app("b", vec![]), Term::var("x")]),
        )];
        let options = DpOptions {
            max_polynomial_constant: 1,
            max_polynomial_coefficient: 1,
            max_polynomial_symbols: 4,
            max_polynomial_arity: 2,
            ..DpOptions::default()
        };
        let arities = arities_for_constraints(&pairs, &[]);
        let width = polynomial_bv_width(&pairs, &[], &options).unwrap();
        let script = polynomial_bv_sat_script(
            &pairs,
            &[],
            &options,
            &arities,
            width,
            width,
            &[],
            &[],
            None,
            None,
            true,
            false,
            true,
            true,
            true,
            None,
        )
        .unwrap();

        assert!(script.contains(&format!(
            "(bvuge {} {})",
            smt_a("f#", 1),
            bv_literal(0, width)
        )));
    }

    #[test]
    fn linear_polynomial_sat_search_maximizes_strict_pairs_in_one_query() {
        let pair = DependencyPair::new_for_test(
            Term::app("f#", vec![Term::app("s", vec![Term::var("x")])]),
            Term::app("f#", vec![Term::var("x")]),
        );
        let pairs = vec![pair.clone(), pair];
        let options = DpOptions::default();
        let arities = arities_for_constraints(&pairs, &[]);
        let width = polynomial_bv_width(&pairs, &[], &options).unwrap();
        let script = polynomial_bv_sat_script(
            &pairs,
            &[],
            &options,
            &arities,
            width,
            width,
            &[],
            &[],
            None,
            None,
            true,
            false,
            true,
            true,
            true,
            None,
        )
        .unwrap();

        assert!(script.contains("(set-option :opt.priority lex)"));
        assert!(script.contains("(maximize "));
        assert_eq!(script.matches("(check-sat)").count(), 1);
    }

    #[test]
    fn linear_polynomial_sat_search_uses_narrow_parameters_with_wide_values() {
        let pairs = vec![DependencyPair::new_for_test(
            Term::app("f#", vec![Term::app("s", vec![Term::var("x")])]),
            Term::app("f#", vec![Term::var("x")]),
        )];
        let options = DpOptions {
            max_polynomial_constant: 2,
            max_polynomial_coefficient: 2,
            ..DpOptions::default()
        };
        let arities = arities_for_constraints(&pairs, &[]);
        let width = polynomial_bv_width(&pairs, &[], &options).unwrap();
        let parameter_width = unsigned_bit_width(2);
        let script = polynomial_bv_sat_script(
            &pairs,
            &[],
            &options,
            &arities,
            parameter_width,
            width,
            &[],
            &[],
            None,
            None,
            true,
            false,
            true,
            true,
            true,
            None,
        )
        .unwrap();

        assert!(parameter_width < width);
        assert!(script.contains(&format!(
            "(declare-fun {} () (_ BitVec {parameter_width}))",
            smt_a("f#", 0)
        )));
        assert!(script.contains(&format!(
            "((_ zero_extend {}) {})",
            width - parameter_width,
            smt_c("f#")
        )));
        assert!(script.contains(&format!(
            "(ite (= {} {})",
            smt_a("f#", 0),
            bv_literal(2, parameter_width)
        )));
    }

    #[test]
    fn polynomial_bv_encoder_hash_conses_terms_and_commutative_expressions() {
        let width = 6;
        let mut encoder = PolynomialBvEncoder::new(String::new(), width, 2, 2, true, true);
        let repeated = Term::app(
            "f",
            vec![
                Term::app("g", vec![Term::var("x")]),
                Term::app("g", vec![Term::var("x")]),
            ],
        );

        let first = encoder.interpret(&repeated);
        let bindings_after_first = encoder.script().matches("(define-fun p_e_").count();
        let second = encoder.interpret(&repeated);
        assert_eq!(first, second);
        assert_eq!(
            encoder.script().matches("(define-fun p_e_").count(),
            bindings_after_first
        );

        let sum = encoder.add("left", "right");
        assert_eq!(encoder.add("right", "left"), sum);
        let product = encoder.mul("left", "right");
        assert_eq!(encoder.mul("right", "left"), product);
        assert_eq!(encoder.add(&bv_literal(0, width), "left"), "left");
        assert_eq!(encoder.mul(&bv_literal(1, width), "left"), "left");
        assert_eq!(
            encoder.mul(&bv_literal(0, width), "left"),
            bv_literal(0, width)
        );
        let scaled = encoder.scale("coefficient", "value");
        assert!(encoder.script().contains(
            "(ite (= coefficient (_ bv2 2)) (bvshl value (_ bv1 6)) \
             (ite (= coefficient (_ bv1 2)) value (_ bv0 6)))"
        ));
        assert_eq!(encoder.scale("coefficient", "value"), scaled);
    }

    #[test]
    fn polynomial_strict_objective_uses_balanced_unsigned_sum() {
        let width = unsigned_bit_width(5);
        let sum = balanced_bv_sum(
            ["a", "b", "c", "d", "e"]
                .into_iter()
                .map(str::to_string)
                .collect(),
            width,
        );

        assert_eq!(width, 3);
        assert_eq!(sum, "(bvadd (bvadd (bvadd a b) (bvadd c d)) e)");
    }

    #[test]
    fn weak_polynomial_synthesis_uses_one_shot_ceta_affine_constraints() {
        let pairs = vec![DependencyPair::new_for_test(
            Term::app("h#", vec![Term::app("s", vec![Term::var("x")])]),
            Term::app("h#", vec![Term::var("x")]),
        )];
        let usable = Vec::new();
        let options = DpOptions {
            max_polynomial_constant: 1,
            max_polynomial_coefficient: 1,
            max_polynomial_symbols: 4,
            max_polynomial_arity: 1,
            ..DpOptions::default()
        };
        let script = weak_polynomial_smt_script(&pairs, &usable, &options, 0, false, None).unwrap();
        assert!(script.contains("(set-logic ALL)"));
        assert!(!script.contains("(forall"));
        assert!(script.contains("(ite (>= "));

        assert!(
            synthesize_weak_polynomial_with_smt_only(
                &pairs, &usable, &options, 0, false, None, None,
            )
            .is_some()
        );
        assert!(synthesize_weak_polynomial(&pairs, &usable, &options, 0, false, None).is_some());
    }

    #[test]
    fn rational_polynomial_accepts_aprove_ag01_4_26_component() {
        let (pairs, usable) = ag01_4_26_aprove_component();
        let interpretations = ag01_4_26_aprove_rational_interpretation();
        let removal = checked_component_removal_by_rational_polynomial(
            &pairs,
            &usable,
            &interpretations,
            4,
            DpSearchBackend::Sat,
            None,
        )
        .unwrap();

        assert!(removal.strict_pair_indices.contains(&1));
    }

    #[test]
    fn rational_structural_candidate_finds_aprove_ag01_4_26_component() {
        let (pairs, usable) = ag01_4_26_aprove_component();
        let options = DpOptions {
            max_polynomial_constant: 16,
            max_polynomial_coefficient: 16,
            ..DpOptions::default()
        };
        let removal =
            predecessor_comparison_rational_candidate(&pairs, &usable, &options, 4).unwrap();

        assert_eq!(removal.strict_pair_indices, vec![1]);
        assert!(matches!(
            removal.reduction_pair,
            DpReductionPairProof::RationalPolynomial { denominator: 4, .. }
        ));
    }

    #[test]
    fn halving_rational_candidate_uses_match_cap_rule_precision() {
        let trs = crate::parsing::parse_ari_trs(
            None,
            r#"
                (format TRS)
                (fun g 2) (fun |0| 0) (fun d 0) (fun s 1) (fun h 0)
                (fun double 1) (fun half 1) (fun f 2)
                (rule (g x |0|) |0|)
                (rule (g d (s x)) (s (s (g d x))))
                (rule (g h (s |0|)) |0|)
                (rule (g h (s (s x))) (s (g h x)))
                (rule (double x) (g d x))
                (rule (half x) (g h x))
                (rule (f (s x) y) (f (half (s x)) (double y)))
            "#,
        )
        .unwrap();
        let pair = dependency_pairs(&trs)
            .into_iter()
            .find(|pair| {
                pair.lhs()
                    .root_symbol()
                    .is_some_and(|root| root.as_str() == "f#")
            })
            .unwrap();
        let options = DpOptions {
            max_polynomial_constant: 16,
            max_polynomial_coefficient: 16,
            ..DpOptions::default()
        };
        let synthesized = synthesize_rational_linear_with_usable_rules(
            &[pair.clone()], trs.rules(), &options, 4, 2,
            Some(Instant::now() + Duration::from_secs(30)), false,
        ).expect("native synthesis must distinguish rules sharing a defined symbol");
        assert!(!synthesized.strict_pair_indices.is_empty());
        let synthesized_usable = synthesized.usable_rules.unwrap();
        assert!(!synthesized_usable.contains(&trs.rules()[1]));
        assert!(!synthesized_usable.contains(&trs.rules()[4]));
        let removal = halving_rational_candidate(&[pair], trs.rules(), &options, 4)
            .expect("the exact checked halving witness should orient the recursive pair");
        let usable = removal.usable_rules.unwrap();

        assert_eq!(usable.len(), 4);
        assert!(!usable.contains(&trs.rules()[1]));
        assert!(!usable.contains(&trs.rules()[4]));
    }

    #[test]
    fn rational_polynomial_bv_finds_ag01_4_26_component() {
        let (pairs, usable) = ag01_4_26_aprove_component();
        let options = DpOptions {
            max_polynomial_constant: 16,
            max_polynomial_coefficient: 16,
            max_polynomial_symbols: 12,
            max_polynomial_arity: 3,
            ..DpOptions::default()
        };
        let removal = synthesize_rational_linear_with_usable_rules(
            &pairs, &usable, &options, 4, 4, None, true,
        )
        .expect("bit-vector search should find a rational weakly monotone interpretation");

        assert!(removal.strict_pair_indices.contains(&1));
    }

    fn ag01_4_26_aprove_component() -> (Vec<DependencyPair>, Vec<RewriteRule>) {
        (
            vec![
                DependencyPair::new_for_test(
                    Term::app("minus#", vec![Term::var("x"), Term::var("y")]),
                    Term::app(
                        "if#",
                        vec![
                            Term::app("le", vec![Term::var("x"), Term::var("y")]),
                            Term::var("x"),
                            Term::var("y"),
                        ],
                    ),
                ),
                DependencyPair::new_for_test(
                    Term::app(
                        "if#",
                        vec![Term::app("false", vec![]), Term::var("x"), Term::var("y")],
                    ),
                    Term::app(
                        "minus#",
                        vec![Term::app("p", vec![Term::var("x")]), Term::var("y")],
                    ),
                ),
            ],
            vec![
                RewriteRule::new(
                    Term::app("p", vec![Term::app("|0|", vec![])]),
                    Term::app("|0|", vec![]),
                ),
                RewriteRule::new(
                    Term::app("p", vec![Term::app("s", vec![Term::var("x")])]),
                    Term::var("x"),
                ),
                RewriteRule::new(
                    Term::app("le", vec![Term::app("|0|", vec![]), Term::var("y")]),
                    Term::app("true", vec![]),
                ),
                RewriteRule::new(
                    Term::app(
                        "le",
                        vec![
                            Term::app("s", vec![Term::var("x")]),
                            Term::app("|0|", vec![]),
                        ],
                    ),
                    Term::app("false", vec![]),
                ),
                RewriteRule::new(
                    Term::app(
                        "le",
                        vec![
                            Term::app("s", vec![Term::var("x")]),
                            Term::app("s", vec![Term::var("y")]),
                        ],
                    ),
                    Term::app("le", vec![Term::var("x"), Term::var("y")]),
                ),
            ],
        )
    }

    fn ag01_4_26_aprove_rational_interpretation() -> LinearPolynomialInterpretations {
        BTreeMap::from([
            (
                "minus#".to_string(),
                LinearPolynomial {
                    constant: 0,
                    coefficients: vec![8, 0],
                },
            ),
            (
                "if#".to_string(),
                LinearPolynomial {
                    constant: 0,
                    coefficients: vec![16, 2, 0],
                },
            ),
            (
                "le".to_string(),
                LinearPolynomial {
                    constant: 0,
                    coefficients: vec![1, 0],
                },
            ),
            (
                "false".to_string(),
                LinearPolynomial {
                    constant: 1,
                    coefficients: vec![],
                },
            ),
            (
                "p".to_string(),
                LinearPolynomial {
                    constant: 0,
                    coefficients: vec![1],
                },
            ),
            (
                "|0|".to_string(),
                LinearPolynomial {
                    constant: 0,
                    coefficients: vec![],
                },
            ),
            (
                "true".to_string(),
                LinearPolynomial {
                    constant: 0,
                    coefficients: vec![],
                },
            ),
            (
                "s".to_string(),
                LinearPolynomial {
                    constant: 16,
                    coefficients: vec![16],
                },
            ),
        ])
    }

    #[test]
    fn rewriting_then_subterm_proves_component() {
        let trs = Trs::new_with_strategy(
            None,
            BTreeSet::new(),
            vec![
                RewriteRule::new(
                    Term::app("h", vec![Term::app("a", vec![])]),
                    Term::app("a", vec![]),
                ),
                RewriteRule::new(
                    Term::app("f", vec![Term::app("s", vec![Term::app("a", vec![])])]),
                    Term::app("f", vec![Term::app("h", vec![Term::app("a", vec![])])]),
                ),
            ],
            RewriteStrategy::Innermost,
        );
        let pair = DependencyPair::new_for_test(
            Term::app("f#", vec![Term::app("s", vec![Term::app("a", vec![])])]),
            Term::app("f#", vec![Term::app("h", vec![Term::app("a", vec![])])]),
        );
        let (step, residual) = synthesize_rewriting_step(&[pair.clone()], trs.rules()).unwrap();

        assert_eq!(step.original_pair, pair);
        assert_eq!(
            residual,
            vec![DependencyPair::new_for_test(
                Term::app("f#", vec![Term::app("s", vec![Term::app("a", vec![])])]),
                Term::app("f#", vec![Term::app("a", vec![])]),
            )]
        );
        assert!(synthesize_subterm_criterion(&residual).is_some());
    }

    #[test]
    fn processor_probe_returns_rewriting_residual_without_replaying_root() {
        let trs = Trs::new_with_strategy(
            None,
            BTreeSet::new(),
            vec![RewriteRule::new(
                Term::app("h", vec![Term::app("a", vec![])]),
                Term::app("s", vec![Term::app("a", vec![])]),
            )],
            RewriteStrategy::Innermost,
        );
        let pair = DependencyPair::new_for_test(
            Term::app("f#", vec![Term::app("s", vec![Term::app("a", vec![])])]),
            Term::app("f#", vec![Term::app("h", vec![Term::app("a", vec![])])]),
        );
        let options = DpOptions::default();
        let strategy = DpStrategy::Processor(DpStrategyProcessor::Rewriting {
            max_per_pair: Some(1),
        });
        let (_fragment, residuals) =
            crate::proving::probe_dp_atom(&trs, vec![pair], &options, &strategy, None).unwrap();
        assert_eq!(residuals.len(), 1);
        let (_, residual_pairs, _, _) = parsed_dp_probe_residual(&residuals[0]);
        assert_eq!(
            residual_pairs[0].rhs(),
            &Term::app("f#", vec![Term::app("s", vec![Term::app("a", vec![])])],)
        );
    }

    #[test]
    fn rewriting_match_treats_identity_variable_binding_as_noop() {
        let pair = DependencyPair::new_for_test(
            Term::app("f#", vec![Term::var("x"), Term::var("x")]),
            Term::app(
                "f#",
                vec![Term::app("g", vec![Term::var("x")]), Term::var("x")],
            ),
        );
        let rules = vec![RewriteRule::new(
            Term::app("g", vec![Term::var("x")]),
            Term::app("s", vec![Term::var("x")]),
        )];
        let (_step, residual) = synthesize_rewriting_step(&[pair], &rules).unwrap();

        assert_eq!(
            residual[0].rhs(),
            &Term::app(
                "f#",
                vec![Term::app("s", vec![Term::var("x")]), Term::var("x")]
            )
        );
    }

    #[test]
    fn forward_instantiation_prefers_call_family_boundaries_to_projection_chains() {
        let boundary = DpForwardInstantiationStep {
            pair: DependencyPair::new_for_test(
                Term::app("if#", vec![Term::var("x")]),
                Term::app("__CSR_U0", vec![Term::var("x")]),
            ),
            instantiations: Vec::new(),
            usable_rules: Vec::new(),
            uses_usable_rules: true,
        };
        let projection = DpForwardInstantiationStep {
            pair: DependencyPair::new_for_test(
                Term::app("__CSR_U0", vec![Term::app("s", vec![Term::var("x")])]),
                Term::app("__CSR_U0", vec![Term::var("x")]),
            ),
            instantiations: Vec::new(),
            usable_rules: Vec::new(),
            uses_usable_rules: true,
        };
        let score = (1, 1, 1, 1);

        assert!(
            forward_instantiation_candidate_priority(true, score, &boundary)
                < forward_instantiation_candidate_priority(true, score, &projection)
        );
    }

    #[test]
    fn forward_instantiation_uses_successor_lhs_skeletons() {
        let trs = Trs::new_with_strategy(
            None,
            BTreeSet::from([Variable::new("x")]),
            vec![RewriteRule::new(
                Term::app("f", vec![Term::var("x")]),
                Term::app("g", vec![Term::var("x"), Term::var("x")]),
            )],
            RewriteStrategy::Innermost,
        );
        let selected = DependencyPair::new_for_test(
            Term::app("f#", vec![Term::var("x")]),
            Term::app("g#", vec![Term::var("x"), Term::var("x")]),
        );
        let successor = DependencyPair::new_for_test(
            Term::app(
                "g#",
                vec![Term::app("0", Vec::new()), Term::app("0", Vec::new())],
            ),
            Term::app("f#", vec![Term::app("s", vec![Term::app("0", Vec::new())])]),
        );

        let (step, residual) =
            synthesize_forward_instantiation_step(&trs, &[selected, successor.clone()], &[])
                .expect("forward instantiation step");

        assert_eq!(
            step.instantiations,
            vec![DependencyPair::new_for_test(
                Term::app("f#", vec![Term::app("0", Vec::new())]),
                Term::app(
                    "g#",
                    vec![Term::app("0", Vec::new()), Term::app("0", Vec::new())],
                ),
            )]
        );
        assert_eq!(residual, vec![step.instantiations[0].clone(), successor]);
    }

    #[test]
    fn forward_instantiation_does_not_emit_usable_rules_for_empty_q_and_nonempty_r() {
        let trs = Trs::new_with_strategy(
            None,
            BTreeSet::from([Variable::new("x")]),
            vec![RewriteRule::new(
                Term::app("f", vec![Term::var("x")]),
                Term::app("g", vec![Term::var("x"), Term::var("x")]),
            )],
            RewriteStrategy::Innermost,
        );
        let selected = DependencyPair::new_for_test(
            Term::app("f#", vec![Term::var("x")]),
            Term::app("g#", vec![Term::var("x"), Term::var("x")]),
        );
        let successor = DependencyPair::new_for_test(
            Term::app(
                "g#",
                vec![Term::app("0", Vec::new()), Term::app("0", Vec::new())],
            ),
            Term::app("f#", vec![Term::app("s", vec![Term::app("0", Vec::new())])]),
        );

        let candidates = synthesize_forward_instantiation_candidates_filtered(
            None,
            &trs,
            &[selected, successor],
            &[],
            false,
            Some(&[]),
            true,
            None,
            &DpStrategyCancellation::default(),
            |_| true,
        )
        .expect("forward instantiation search should complete");

        assert!(!candidates.is_empty());
        assert!(candidates.iter().all(|(_, step, _)| {
            !step.uses_usable_rules && same_rule_set(&step.usable_rules, trs.rules())
        }));
    }

    #[test]
    fn jwmatchb1_prefers_exact_two_pair_forward_instantiation() {
        let f = |left, right| Term::app("f", vec![left, right]);
        let h = |argument| Term::app("h", vec![argument]);
        let sharp = |argument| Term::app("h#", vec![argument]);
        let a = || Term::app("a", Vec::new());
        let rule_lhs = h(f(Term::var("x"), Term::var("y")));
        let trs = Trs::new_with_strategy(
            None,
            ["x", "y", "x0", "x1", "y1"]
                .into_iter()
                .map(Variable::new)
                .collect(),
            vec![RewriteRule::new(
                rule_lhs.clone(),
                f(Term::var("y"), f(h(h(Term::var("x"))), a())),
            )],
            RewriteStrategy::Innermost,
        );
        let narrowed = DependencyPair::new_for_test(
            sharp(f(f(Term::var("x0"), Term::var("x1")), Term::var("y1"))),
            sharp(f(Term::var("x1"), f(h(h(Term::var("x0"))), a()))),
        );
        let selected = DependencyPair::new_for_test(
            sharp(f(Term::var("x"), Term::var("y"))),
            sharp(Term::var("x")),
        );
        let pairs = vec![narrowed, selected.clone()];
        let expected = vec![
            DependencyPair::new_for_test(
                sharp(f(f(Term::var("y_0"), Term::var("y_1")), Term::var("x1"))),
                sharp(f(Term::var("y_0"), Term::var("y_1"))),
            ),
            DependencyPair::new_for_test(
                sharp(f(
                    f(f(Term::var("y_0"), Term::var("y_1")), Term::var("y_2")),
                    Term::var("x1"),
                )),
                sharp(f(f(Term::var("y_0"), Term::var("y_1")), Term::var("y_2"))),
            ),
        ];

        let candidates = synthesize_forward_instantiation_candidates_filtered(
            None,
            &trs,
            &pairs,
            trs.rules(),
            false,
            Some(std::slice::from_ref(&rule_lhs)),
            true,
            None,
            &DpStrategyCancellation::default(),
            |_| true,
        )
        .expect("forward-instantiation candidates");
        let (_, step, residual) = candidates.first().expect("exact candidate");

        assert!(dependency_pairs_alpha_equivalent(&step.pair, &selected));
        assert_eq!(step.instantiations.len(), 2);
        assert!(expected.iter().all(|expected_pair| {
            step.instantiations
                .iter()
                .any(|actual| dependency_pairs_alpha_equivalent(actual, expected_pair))
        }));
        assert_eq!(residual.len(), 3);
        assert!(step.uses_usable_rules);
        assert!(step.usable_rules.is_empty());

        let matrix = BTreeMap::from([
            (
                "h#".to_string(),
                MatrixInterpretation {
                    constant: vec![0, 0],
                    coefficients: vec![vec![vec![2, 0], vec![0, 0]]],
                },
            ),
            (
                "f".to_string(),
                MatrixInterpretation {
                    constant: vec![1, 1],
                    coefficients: vec![vec![vec![1, 1], vec![0, 0]], vec![vec![0, 0], vec![1, 1]]],
                },
            ),
            (
                "h".to_string(),
                MatrixInterpretation {
                    constant: vec![0, 0],
                    coefficients: vec![vec![vec![0, 1], vec![3, 0]]],
                },
            ),
            (
                "a".to_string(),
                MatrixInterpretation {
                    constant: vec![0, 0],
                    coefficients: Vec::new(),
                },
            ),
        ]);
        let removal = checked_component_removal_by_matrix(
            &residual,
            &[],
            &matrix,
            DpSearchBackend::Sat,
            Some(std::slice::from_ref(&rule_lhs)),
        )
        .expect("AProVE's certified 2D matrix witness should remove the residual");
        assert_eq!(removal.strict_pair_indices.len(), residual.len());
        assert!(
            trs.rules().iter().all(|rule| weakly_decreases_by_matrix(
                rule.lhs(),
                rule.rhs(),
                &matrix,
                2
            )),
            "AProVE's matrix witness should weakly orient the child DP rules"
        );

        let options = DpOptions {
            max_polynomial_constant: 1,
            max_polynomial_coefficient: 3,
            ..DpOptions::default()
        };
        synthesize_matrix_interpretation_for_component(
            &residual,
            trs.rules(),
            &options,
            2,
            None,
            Some(12),
            None,
            None,
            Some(Instant::now() + Duration::from_secs(20)),
        )
        .expect("one-shot matrix search should find a checked witness for the residual");
    }

    #[test]
    fn labeling_aprove_forward_instantiation_witness_has_ceta_coverage() {
        let f = |args| Term::app("f", args);
        let sharp = |args| Term::app("f#", args);
        let a = || Term::app("a", Vec::new());
        let variables = ["x", "y", "z", "w"]
            .into_iter()
            .map(Variable::new)
            .collect();
        let trs = Trs::new(
            None,
            variables,
            vec![RewriteRule::new(
                f(vec![
                    f(vec![Term::var("x"), Term::var("y"), a()]),
                    Term::var("z"),
                    Term::var("w"),
                ]),
                f(vec![
                    Term::var("z"),
                    Term::var("w"),
                    f(vec![Term::var("y"), Term::var("x"), Term::var("z")]),
                ]),
            )],
        );
        let pairs = dependency_pairs(&trs);
        let selected = pairs
            .iter()
            .find(|pair| {
                pair.rhs()
                    == &sharp(vec![
                        Term::var("z"),
                        Term::var("w"),
                        f(vec![Term::var("y"), Term::var("x"), Term::var("z")]),
                    ])
            })
            .expect("root-call dependency pair");
        let witness = DependencyPair::new_for_test(
            sharp(vec![
                f(vec![Term::var("x0"), Term::var("x1"), a()]),
                f(vec![Term::var("y0"), Term::var("y1"), a()]),
                Term::var("x3"),
            ]),
            sharp(vec![
                f(vec![Term::var("y0"), Term::var("y1"), a()]),
                Term::var("x3"),
                f(vec![
                    Term::var("x1"),
                    Term::var("x0"),
                    f(vec![Term::var("y0"), Term::var("y1"), a()]),
                ]),
            ]),
        );

        assert!(
            forward_instantiation_ceta_coverage_holds(
                &trs,
                &pairs,
                selected,
                std::slice::from_ref(&witness),
                &[],
                trs.rules(),
                trs.rules(),
            ),
            "the first forward-instantiation step in AProVE's CeTA-certified labeling proof"
        );
        let candidates = synthesize_forward_instantiation_candidates_filtered(
            None,
            &trs,
            &pairs,
            trs.rules(),
            false,
            None,
            true,
            None,
            &DpStrategyCancellation::default(),
            |_| true,
        )
        .expect("candidate synthesis should complete");
        assert_eq!(
            candidates.first().map(|(_, step, _)| &step.pair),
            Some(selected),
            "equal graph scores should prioritize the structurally larger root call"
        );
        assert!(candidates.iter().any(|(_, step, residual)| {
            step.pair == *selected
                && step.instantiations.len() == 1
                && dependency_pairs_alpha_equivalent(&step.instantiations[0], &witness)
                && residual.len() == pairs.len()
        }));
    }

    #[test]
    fn forward_instantiation_rejects_empty_rules_without_exact_ceta_coverage() {
        let trs = Trs::new_with_strategy(
            None,
            BTreeSet::from([Variable::new("x")]),
            vec![
                RewriteRule::new(
                    Term::app("a", vec![Term::app("c", vec![Term::var("x")])]),
                    Term::var("x"),
                ),
                RewriteRule::new(
                    Term::app("b", vec![Term::app("d", vec![Term::var("x")])]),
                    Term::var("x"),
                ),
            ],
            RewriteStrategy::Innermost,
        );
        let selected = DependencyPair::new_for_test(
            Term::app("b#", vec![Term::app("c", vec![Term::var("x")])]),
            Term::app("b#", vec![Term::var("x")]),
        );
        let successor_one = DependencyPair::new_for_test(
            Term::app("b#", vec![Term::app("c", vec![Term::var("y")])]),
            Term::app("b#", vec![Term::var("y")]),
        );
        let successor_two = DependencyPair::new_for_test(
            Term::app("b#", vec![Term::app("c", vec![Term::var("z")])]),
            Term::app("a#", vec![Term::var("z")]),
        );

        let pairs = vec![selected, successor_one, successor_two];
        assert!(
            synthesize_forward_instantiation_step(&trs, &pairs, &[]).is_none(),
            "an empty active rule set must not bypass CeTA's root-complete coverage"
        );
    }

    #[test]
    fn forward_instantiation_then_graph_decomposition_proves_component() {
        let trs = Trs::new_with_strategy(
            None,
            BTreeSet::from([Variable::new("x")]),
            vec![
                RewriteRule::new(
                    Term::app("f", vec![Term::var("x")]),
                    Term::app("g", vec![Term::var("x"), Term::var("x")]),
                ),
                RewriteRule::new(
                    Term::app(
                        "g",
                        vec![Term::app("0", Vec::new()), Term::app("0", Vec::new())],
                    ),
                    Term::app("f", vec![Term::app("s", vec![Term::app("0", Vec::new())])]),
                ),
            ],
            RewriteStrategy::Innermost,
        );
        let options = DpOptions {
            max_narrowing_steps: 1,
            ..DpOptions::default()
        };
        let strategy = DpStrategy::Sequence(vec![
            DpStrategy::Processor(DpStrategyProcessor::DependencyGraph),
            DpStrategy::Processor(DpStrategyProcessor::ForwardInstantiation { max_per_pair: None }),
        ]);
        let proof = solve_dependency_pairs_with_strategy(&trs, &options, &strategy, None)
            .expect("forward instantiation should prove the DP problem");

        assert!(proof.component_proofs.iter().any(|component| {
            component
                .proof_tree
                .as_deref()
                .is_some_and(|tree| matches!(tree, DpProofTree::ForwardInstantiation { .. }))
        }));
    }

    #[test]
    fn standard_forward_instantiation_handles_aprove_forward_instantiation2_shape() {
        let trs = Trs::new(
            None,
            BTreeSet::from([Variable::new("x"), Variable::new("y"), Variable::new("z")]),
            vec![
                RewriteRule::new(
                    Term::app("f", vec![Term::var("x"), Term::var("y"), Term::var("z")]),
                    Term::app("g", vec![Term::var("x"), Term::var("y"), Term::var("z")]),
                ),
                RewriteRule::new(
                    Term::app(
                        "g",
                        vec![
                            Term::app("0", Vec::new()),
                            Term::app("1", Vec::new()),
                            Term::var("x"),
                        ],
                    ),
                    Term::app("f", vec![Term::var("x"), Term::var("x"), Term::var("x")]),
                ),
                RewriteRule::new(Term::app("a", Vec::new()), Term::app("b", Vec::new())),
                RewriteRule::new(Term::app("a", Vec::new()), Term::app("c", Vec::new())),
            ],
        );
        let options = DpOptions {
            max_narrowing_steps: 1,
            ..DpOptions::default()
        };
        let strategy = DpStrategy::Sequence(vec![
            DpStrategy::Processor(DpStrategyProcessor::DependencyGraph),
            DpStrategy::Processor(DpStrategyProcessor::ForwardInstantiation { max_per_pair: None }),
            DpStrategy::Processor(DpStrategyProcessor::DependencyGraph),
        ]);
        let proof = solve_dependency_pairs_with_strategy(&trs, &options, &strategy, None)
            .expect("standard forward instantiation should split the DP graph");

        let step = proof.component_proofs.iter().find_map(|component| {
            let Some(DpProofTree::ForwardInstantiation { step, .. }) =
                component.proof_tree.as_deref()
            else {
                return None;
            };
            Some(step)
        });
        let step = step.expect("expected forward instantiation proof step");
        assert_eq!(step.instantiations.len(), 1);
        let Some((symbol, args)) = term_app_parts(step.instantiations[0].lhs()) else {
            panic!("expected instantiated pair lhs to be an application");
        };
        assert_eq!(symbol.as_str(), "f#");
        assert_eq!(args[0], Term::app("0", Vec::new()));
        assert_eq!(args[1], Term::app("1", Vec::new()));
        assert!(matches!(args[2], Term::Var(_)));
    }

    #[test]
    fn standard_forward_instantiation_coverage_rejects_uncovered_outgoing_edge() {
        let trs = Trs::new(
            None,
            BTreeSet::from([Variable::new("x")]),
            vec![
                RewriteRule::new(
                    Term::app("f", vec![Term::var("x")]),
                    Term::app("g", vec![Term::var("x")]),
                ),
                RewriteRule::new(
                    Term::app("g", vec![Term::app("a", Vec::new())]),
                    Term::app("h", Vec::new()),
                ),
            ],
        );
        let selected = DependencyPair::new_for_test(
            Term::app("f#", vec![Term::var("x")]),
            Term::app("g#", vec![Term::var("x")]),
        );
        let successor = DependencyPair::new_for_test(
            Term::app("g#", vec![Term::app("a", Vec::new())]),
            Term::app("h#", Vec::new()),
        );
        let bad_instantiation = DependencyPair::new_for_test(
            Term::app("f#", vec![Term::app("b", Vec::new())]),
            Term::app("g#", vec![Term::app("b", Vec::new())]),
        );

        let required =
            standard_forward_instantiation_required_pair(&trs, &selected, &successor).unwrap();
        assert_eq!(
            required,
            DependencyPair::new_for_test(
                Term::app("f#", vec![Term::app("a", Vec::new())]),
                Term::app("g#", vec![Term::app("a", Vec::new())]),
            )
        );
        assert!(dependency_pair_is_instance_of(
            &bad_instantiation,
            &selected
        ));
        assert!(!dependency_pair_is_instance_of(
            &required,
            &bad_instantiation
        ));
        assert!(!standard_forward_instantiation_ceta_coverage_holds(
            &trs,
            &[selected.clone(), successor],
            &selected,
            &[bad_instantiation],
        ));
    }

    #[test]
    fn standard_forward_instantiation_coverage_matches_ceta_self_edge() {
        let trs = Trs::new(
            None,
            BTreeSet::from([Variable::new("x"), Variable::new("y")]),
            vec![
                RewriteRule::new(
                    Term::app(
                        "f",
                        vec![
                            Term::app("g", vec![Term::var("x")]),
                            Term::app("s", vec![Term::app("0", Vec::new())]),
                            Term::var("y"),
                        ],
                    ),
                    Term::app(
                        "f",
                        vec![
                            Term::var("y"),
                            Term::var("y"),
                            Term::app("g", vec![Term::var("x")]),
                        ],
                    ),
                ),
                RewriteRule::new(
                    Term::app("g", vec![Term::app("s", vec![Term::var("x")])]),
                    Term::app("s", vec![Term::app("g", vec![Term::var("x")])]),
                ),
                RewriteRule::new(
                    Term::app("g", vec![Term::app("0", Vec::new())]),
                    Term::app("0", Vec::new()),
                ),
            ],
        );
        let selected = DependencyPair::new_for_test(
            Term::app(
                "f#",
                vec![
                    Term::app("g", vec![Term::var("x")]),
                    Term::app("s", vec![Term::app("0", Vec::new())]),
                    Term::var("y"),
                ],
            ),
            Term::app(
                "f#",
                vec![
                    Term::var("y"),
                    Term::var("y"),
                    Term::app("g", vec![Term::var("x")]),
                ],
            ),
        );
        let singleton_instantiation = DependencyPair::new_for_test(
            Term::app(
                "f#",
                vec![
                    Term::app("g", vec![Term::var("x")]),
                    Term::app("s", vec![Term::app("0", Vec::new())]),
                    Term::app("s", vec![Term::app("0", Vec::new())]),
                ],
            ),
            Term::app(
                "f#",
                vec![
                    Term::app("s", vec![Term::app("0", Vec::new())]),
                    Term::app("s", vec![Term::app("0", Vec::new())]),
                    Term::app("g", vec![Term::var("x")]),
                ],
            ),
        );

        let required =
            standard_forward_instantiation_required_pair(&trs, &selected, &selected).unwrap();
        assert_eq!(
            required,
            DependencyPair::new_for_test(
                Term::app(
                    "f#",
                    vec![
                        Term::app("g", vec![Term::var("yx")]),
                        Term::app("s", vec![Term::app("0", Vec::new())]),
                        Term::app("g", vec![Term::var("z0")]),
                    ],
                ),
                Term::app(
                    "f#",
                    vec![
                        Term::app("g", vec![Term::var("z0")]),
                        Term::app("g", vec![Term::var("z0")]),
                        Term::app("g", vec![Term::var("yx")]),
                    ],
                ),
            )
        );
        assert!(!standard_forward_instantiation_ceta_coverage_holds(
            &trs,
            &[selected.clone()],
            &selected,
            &[singleton_instantiation],
        ));
    }

    #[test]
    fn q_graph_excludes_impossible_edge_before_rewriting_timeout() {
        let trs = Trs::new_with_strategy(
            None,
            BTreeSet::new(),
            vec![
                RewriteRule::new(
                    Term::app("h", vec![Term::app("a", vec![])]),
                    Term::app("a", vec![]),
                ),
                RewriteRule::new(
                    Term::app("f", vec![Term::app("s", vec![Term::app("a", vec![])])]),
                    Term::app("f", vec![Term::app("h", vec![Term::app("a", vec![])])]),
                ),
            ],
            RewriteStrategy::Innermost,
        );
        let timed_out = DpOptions::default();
        let timed_out_rewriting = DpStrategy::Timeout {
            duration: Duration::from_millis(0),
            strategy: Box::new(DpStrategy::Processor(DpStrategyProcessor::Rewriting {
                max_per_pair: None,
            })),
        };
        let timed_out_strategy = DpStrategy::Sequence(vec![
            timed_out_rewriting,
            DpStrategy::Processor(DpStrategyProcessor::DependencyGraph),
        ]);

        let pairs = dependency_pairs(&trs);
        let pair = pairs
            .iter()
            .find(|pair| {
                pair.lhs().root_symbol() == Some(&Symbol::new("f#"))
                    && pair.rhs().root_symbol() == Some(&Symbol::new("f#"))
            })
            .expect("recursive f dependency pair");
        let q_lhss = initial_innermost_lhss(&trs).expect("innermost Q");
        let graph = dependency_pair_graph_with_context(&trs, &pairs, Some(&q_lhss));
        let pair_index = pairs
            .iter()
            .position(|candidate| candidate == pair)
            .expect("pair index");
        assert!(!graph[pair_index].contains(&pair_index));
        assert!(
            solve_dependency_pairs_with_strategy(&trs, &timed_out, &timed_out_strategy, None,)
                .is_some()
        );

        let exhausted_budget = DpOptions {
            max_narrowing_steps: 0,
            ..DpOptions::default()
        };
        let exhausted_strategy = DpStrategy::Sequence(vec![
            DpStrategy::Processor(DpStrategyProcessor::Rewriting { max_per_pair: None }),
            DpStrategy::Processor(DpStrategyProcessor::DependencyGraph),
        ]);
        assert!(
            solve_dependency_pairs_with_strategy(
                &trs,
                &exhausted_budget,
                &exhausted_strategy,
                None,
            )
            .is_some()
        );
    }

    #[test]
    fn innermost_rewriting_handles_ag01_4_17_component() {
        let trs = Trs::new_with_strategy(
            None,
            BTreeSet::from([Variable::new("x"), Variable::new("y")]),
            vec![
                RewriteRule::new(
                    Term::app(
                        "f",
                        vec![
                            Term::app("g", vec![Term::var("x")]),
                            Term::app("s", vec![Term::app("|0|", vec![])]),
                            Term::var("y"),
                        ],
                    ),
                    Term::app(
                        "f",
                        vec![
                            Term::app("g", vec![Term::app("s", vec![Term::app("|0|", vec![])])]),
                            Term::var("y"),
                            Term::app("g", vec![Term::var("x")]),
                        ],
                    ),
                ),
                RewriteRule::new(
                    Term::app("g", vec![Term::app("s", vec![Term::var("x")])]),
                    Term::app("s", vec![Term::app("g", vec![Term::var("x")])]),
                ),
                RewriteRule::new(
                    Term::app("g", vec![Term::app("|0|", vec![])]),
                    Term::app("|0|", vec![]),
                ),
            ],
            RewriteStrategy::Innermost,
        );
        let pairs = dependency_pairs(&trs);
        let component = vec![
            pairs
                .iter()
                .find(|pair| {
                    pair.lhs()
                        .root_symbol()
                        .is_some_and(|symbol| symbol.as_str() == "f#")
                })
                .cloned()
                .expect("f# pair"),
        ];
        let usable_without_q = usable_rules(&trs, &component);
        let initial_lhss = trs
            .rules()
            .iter()
            .map(|rule| rule.lhs().clone())
            .collect::<Vec<_>>();
        let lhss = remaining_innermost_lhss(&initial_lhss, &usable_without_q, &component);
        let usable = usable_rules_in_innermost_context(&trs, &component, Some(&lhss));

        let (first_step, first_residual) =
            synthesize_rewriting_step(&component, &usable).expect("first rewrite");
        assert_eq!(first_step.rewrite_step.position, vec![1]);
        let first_usable = usable_rules_in_innermost_context(&trs, &first_residual, Some(&lhss));
        let (second_step, second_residual) =
            synthesize_rewriting_step(&first_residual, &first_usable).expect("second rewrite");
        assert_eq!(second_step.rewrite_step.position, vec![1, 1]);
        assert!(!is_cyclic_dp_problem(&trs, &second_residual, Some(&lhss)));
    }

    #[test]
    fn innermost_rewriting_respects_empty_active_rules() {
        let trs = Trs::new_with_strategy(
            None,
            BTreeSet::new(),
            vec![RewriteRule::new(
                Term::app("a", vec![Term::app("b", vec![])]),
                Term::app("c", vec![]),
            )],
            RewriteStrategy::Innermost,
        );
        let pair = DependencyPair::new_for_test(
            Term::app(
                "h#",
                vec![
                    Term::app("b", vec![]),
                    Term::app("a", vec![Term::app("b", vec![])]),
                ],
            ),
            Term::app(
                "f#",
                vec![
                    Term::app("a", vec![Term::app("b", vec![])]),
                    Term::app("a", vec![Term::app("b", vec![])]),
                ],
            ),
        );
        let stats = DpProofStats {
            active_rules: Some(Vec::new()),
            ..DpProofStats::default()
        };
        let state = DpProblemState {
            trs,
            pairs: vec![pair],
            options: DpOptions::default(),
            stats,
            innermost_lhss: None,
            subtree_deadline: None,
        };
        let outcome = crate::proving::processors::dp::RewritingProcessor {
            max_per_pair: None,
            candidate_index: 0,
            deadline: None,
        }
        .apply(&crate::proving::processors::ProblemState::DependencyPairs(
            state,
        ));

        assert!(matches!(
            outcome,
            crate::proving::processors::ProcessorResult::Inapplicable
        ));
    }

    #[test]
    fn instantiation_uses_predecessor_cap_skeleton() {
        let trs = Trs::new(
            None,
            BTreeSet::from([Variable::new("x")]),
            vec![RewriteRule::new(
                Term::app("f", vec![Term::var("x")]),
                Term::app("g", vec![Term::var("x")]),
            )],
        );
        let selected = DependencyPair::new_for_test(
            Term::app("f#", vec![Term::var("x")]),
            Term::app("g#", vec![Term::var("x")]),
        );
        let predecessor = DependencyPair::new_for_test(
            Term::app("g#", vec![Term::app("a", vec![])]),
            Term::app("f#", vec![Term::app("a", vec![])]),
        );
        let (step, residual) =
            synthesize_instantiation_step(&trs, &[selected.clone(), predecessor.clone()]).unwrap();

        assert_eq!(step.pair, selected);
        assert_eq!(
            step.instantiations,
            vec![DependencyPair::new_for_test(
                Term::app("f#", vec![Term::app("a", vec![])]),
                Term::app("g#", vec![Term::app("a", vec![])]),
            )]
        );
        assert_eq!(residual, vec![step.instantiations[0].clone(), predecessor]);
    }

    #[test]
    fn instantiation_residual_preserves_alpha_equivalent_source_spellings() {
        let selected = DependencyPair::new_for_test(
            Term::app("and#", vec![Term::app("tt", vec![]), Term::var("x")]),
            Term::app("__CSR_U0", vec![Term::var("x")]),
        );
        let spelled_x = DependencyPair::new_for_test(
            Term::app(
                "__CSR_U0",
                vec![Term::app("isLNatKind", vec![Term::var("x")])],
            ),
            Term::app("isLNatKind#", vec![Term::var("x")]),
        );
        let spelled_xs = DependencyPair::new_for_test(
            Term::app(
                "__CSR_U0",
                vec![Term::app("isLNatKind", vec![Term::var("xs")])],
            ),
            Term::app("isLNatKind#", vec![Term::var("xs")]),
        );
        assert!(dependency_pairs_alpha_equivalent(&spelled_x, &spelled_xs));
        assert_ne!(spelled_x, spelled_xs);

        let instance = DependencyPair::new_for_test(
            Term::app(
                "and#",
                vec![
                    Term::app("tt", vec![]),
                    Term::app("isLNatKind", vec![Term::var("n")]),
                ],
            ),
            Term::app(
                "__CSR_U0",
                vec![Term::app("isLNatKind", vec![Term::var("n")])],
            ),
        );
        let residual = exact_instantiation_residual(
            &[selected, spelled_x.clone(), spelled_xs.clone()],
            0,
            std::slice::from_ref(&instance),
        );

        assert_eq!(residual, vec![instance, spelled_x, spelled_xs]);
    }

    #[test]
    fn instantiation_removes_pair_without_predecessor_obligations() {
        let trs = Trs::new_with_strategy(
            None,
            BTreeSet::from([Variable::new("x")]),
            vec![
                RewriteRule::new(
                    Term::app("f", vec![Term::var("x"), Term::var("x")]),
                    Term::app(
                        "f",
                        vec![Term::app("g", vec![Term::var("x")]), Term::var("x")],
                    ),
                ),
                RewriteRule::new(
                    Term::app("g", vec![Term::var("x")]),
                    Term::app("s", vec![Term::var("x")]),
                ),
            ],
            RewriteStrategy::Innermost,
        );
        let rewritten = DependencyPair::new_for_test(
            Term::app("f#", vec![Term::var("x"), Term::var("x")]),
            Term::app(
                "f#",
                vec![Term::app("s", vec![Term::var("x")]), Term::var("x")],
            ),
        );

        let (step, residual) = synthesize_instantiation_step_filtered(
            None,
            &trs,
            std::slice::from_ref(&rewritten),
            &[],
            &[],
            None,
            None,
            &DpStrategyCancellation::default(),
            |_| true,
        )
        .expect("covered empty instantiation");

        assert_eq!(step.pair, rewritten);
        assert!(step.instantiations.is_empty());
        assert!(residual.is_empty());
    }

    #[test]
    fn innermost_forward_instantiation_uses_restricted_rules_and_preserves_q() {
        let variables = BTreeSet::from([Variable::new("x"), Variable::new("y")]);
        let trs = Trs::new_with_strategy(
            None,
            variables,
            vec![
                RewriteRule::new(
                    Term::app(
                        "f",
                        vec![Term::app("a", vec![Term::var("x")]), Term::var("y")],
                    ),
                    Term::app("g", vec![Term::var("x"), Term::var("y")]),
                ),
                RewriteRule::new(
                    Term::app("g", vec![Term::var("x"), Term::var("y")]),
                    Term::app("h", vec![Term::var("x"), Term::var("y")]),
                ),
                RewriteRule::new(
                    Term::app("h", vec![Term::app("b", vec![]), Term::var("y")]),
                    Term::app("f", vec![Term::var("y"), Term::var("y")]),
                ),
                RewriteRule::new(
                    Term::app("a", vec![Term::app("b", vec![])]),
                    Term::app("c", vec![]),
                ),
            ],
            RewriteStrategy::Innermost,
        );
        let proof = solve_dependency_pairs(&trs, &DpOptions::default())
            .expect("the default strategy should make the graph acyclic by Q-aware instantiation");

        let component = &proof.component_proofs[0];
        assert_eq!(component.usable_rules_processor, Some(Vec::new()));
        assert_eq!(component.innermost_lhss_processor, None);
        let Some(DpProofTree::ComponentContext {
            innermost_lhss_processor,
            proof,
            ..
        }) = component.proof_tree.as_deref()
        else {
            panic!(
                "expected explicit Q-context residual: {:?}",
                component.proof_tree
            );
        };
        assert_eq!(
            innermost_lhss_processor.as_deref(),
            Some(std::slice::from_ref(trs.rules()[3].lhs()))
        );
        let DpProofTree::ForwardInstantiation { step, proof } = proof.as_ref() else {
            panic!("expected forward instantiation below the Q context: {proof:?}");
        };
        assert!(step.usable_rules.is_empty());
        assert!(step.uses_usable_rules);
        assert!(dp_proof_tree_contains_dependency_graph(proof));
    }

    #[test]
    fn csr_lpar08_instantiation_preserves_frozen_arguments() {
        let trs = Trs::new(
            None,
            BTreeSet::from([Variable::new("X")]),
            vec![
                RewriteRule::new(
                    Term::app(
                        "f",
                        vec![Term::app("a", vec![]), Term::var("X"), Term::var("X")],
                    ),
                    Term::app(
                        "f",
                        vec![
                            Term::var("X"),
                            Term::app("b", vec![]),
                            Term::app("b", vec![]),
                        ],
                    ),
                ),
                RewriteRule::new(Term::app("b", vec![]), Term::app("a", vec![])),
            ],
        );
        let csr = CsrTrs::new(
            trs,
            ReplacementMap::new(BTreeMap::from([
                (Symbol::new("f"), BTreeSet::from([1])),
                (Symbol::new("a"), BTreeSet::new()),
                (Symbol::new("b"), BTreeSet::new()),
            ])),
        )
        .unwrap();
        let pairs = improved_csr_dependency_pairs(&csr);
        let recursive = pairs
            .iter()
            .find(|pair| pair.lhs().root_symbol() == Some(&Symbol::new("f#")))
            .expect("recursive improved CS-DP");
        let required =
            csr_instantiation_required_pair(&csr, &csr.trs().rules()[1..], recursive, recursive)
                .expect("LPAR'08 cap must unify");
        assert_eq!(
            required.lhs(),
            &Term::app(
                "f#",
                vec![
                    Term::app("a", vec![]),
                    Term::app("b", vec![]),
                    Term::app("b", vec![]),
                ],
            )
        );
        assert_eq!(
            required.rhs(),
            &Term::app(
                "f#",
                vec![
                    Term::app("b", vec![]),
                    Term::app("b", vec![]),
                    Term::app("b", vec![]),
                ],
            )
        );
    }

    #[test]
    fn ex1_gm03_lpar08_instantiation_preserves_hidden_diff_call() {
        let csr = crate::parsing::parse_ari_cstrs(
            Some("CSR_04/Ex1_GM03.ari".to_string()),
            include_str!("../../tests/fixtures/csr_ex1_gm03.ari"),
        )
        .expect("parse Ex1_GM03 fixture");
        let pairs = certificate_improved_csr_dependency_pairs(&csr);
        let predecessor = pairs
            .iter()
            .find(|pair| {
                pair.lhs().root_symbol() == Some(&Symbol::new("diff#"))
                    && pair.rhs().root_symbol() == Some(&Symbol::new("if#"))
            })
            .expect("diff-to-if predecessor");
        let selected = pairs
            .iter()
            .find(|pair| {
                pair.lhs().to_string().starts_with("if#(false")
                    && pair.rhs().root_symbol() == Some(&fresh_unhiding_symbol(csr.trs()))
            })
            .expect("collapsing-if replacement pair");
        let required = csr_instantiation_required_pair(&csr, csr.rules(), predecessor, selected)
            .expect("LPAR'08 predecessor must instantiate the frozen branch");

        assert!(
            required.lhs().to_string().contains("s(diff(p("),
            "frozen hidden call was over-capped: {required:?}"
        );
        assert!(
            !required.lhs().to_string().contains("__cap"),
            "frozen hidden call was over-capped: {required:?}"
        );
    }

    #[test]
    fn default_innermost4_remains_provable_after_valid_rewriting_step() {
        let trs = Trs::new_with_strategy(
            None,
            BTreeSet::from([
                Variable::new("x"),
                Variable::new("y"),
                Variable::new("z"),
                Variable::new("u"),
            ]),
            vec![
                RewriteRule::new(
                    Term::app(
                        "f",
                        vec![
                            Term::app("a", vec![Term::var("x")]),
                            Term::var("y"),
                            Term::app("s", vec![Term::var("z")]),
                            Term::var("u"),
                        ],
                    ),
                    Term::app(
                        "f",
                        vec![
                            Term::app("a", vec![Term::app("b", vec![])]),
                            Term::var("y"),
                            Term::var("z"),
                            Term::app(
                                "g",
                                vec![
                                    Term::var("x"),
                                    Term::var("y"),
                                    Term::app("s", vec![Term::var("z")]),
                                    Term::var("u"),
                                ],
                            ),
                        ],
                    ),
                ),
                RewriteRule::new(
                    Term::app(
                        "g",
                        vec![
                            Term::var("x"),
                            Term::var("y"),
                            Term::var("z"),
                            Term::var("u"),
                        ],
                    ),
                    Term::app(
                        "h",
                        vec![
                            Term::var("x"),
                            Term::var("y"),
                            Term::var("z"),
                            Term::var("u"),
                        ],
                    ),
                ),
                RewriteRule::new(
                    Term::app(
                        "h",
                        vec![
                            Term::app("b", vec![]),
                            Term::var("y"),
                            Term::var("z"),
                            Term::var("u"),
                        ],
                    ),
                    Term::app(
                        "f",
                        vec![
                            Term::var("y"),
                            Term::var("y"),
                            Term::var("z"),
                            Term::var("u"),
                        ],
                    ),
                ),
                RewriteRule::new(
                    Term::app("a", vec![Term::app("b", vec![])]),
                    Term::app("c", vec![]),
                ),
            ],
            RewriteStrategy::Innermost,
        );

        let pairs = dependency_pairs(&trs);
        let q_lhss = trs
            .rules()
            .iter()
            .map(|rule| rule.lhs().clone())
            .collect::<Vec<_>>();
        let (rewriting, residual) =
            synthesize_innermost_rewriting_step_filtered(&trs, &pairs, Some(&q_lhss), |_| true)
                .expect("redex-level rewriting step");
        assert_eq!(rewriting.usable_rules.len(), 1);
        assert_eq!(rewriting.rewrite_step.position, vec![1]);
        let graph = dependency_pair_graph_with_context(&trs, &residual, Some(&q_lhss));
        assert!(
            strongly_connected_components(&graph)
                .iter()
                .any(|component| component.len() == 3),
            "graph decomposition must expose the cyclic three-pair residual"
        );

        solve_dependency_pairs(&trs, &DpOptions::default())
            .expect("the default strategy should still prove innermost4");
    }

    #[test]
    fn transformed_probe_residual_preserves_ceta_nfs_context() {
        let trs = Trs::new(
            None,
            BTreeSet::from([Variable::new("x")]),
            vec![RewriteRule::new(
                Term::app("f", vec![Term::var("x")]),
                Term::app("g", vec![Term::var("x")]),
            )],
        );
        let selected = DependencyPair::new_for_test(
            Term::app("f#", vec![Term::var("x")]),
            Term::app("g#", vec![Term::var("x")]),
        );
        let predecessor = DependencyPair::new_for_test(
            Term::app("g#", vec![Term::app("a", vec![])]),
            Term::app("f#", vec![Term::app("a", vec![])]),
        );
        assert!(
            synthesize_instantiation_step(&trs, &[selected.clone(), predecessor.clone()]).is_some()
        );
        let strategy = DpStrategy::Processor(DpStrategyProcessor::Instantiation {
            max_per_pair: Some(1),
        });
        let options = DpOptions {
            max_narrowing_steps: 1,
            ..DpOptions::default()
        };

        let (proof, residuals) = crate::proving::probe_dp_atom(
            &trs,
            vec![selected, predecessor],
            &options,
            &strategy,
            None,
        )
        .expect("instantiation probe");

        assert_eq!(residuals.len(), 1);
        assert!(parsed_dp_probe_residual(&residuals[0]).3);
        assert!(proof.is_none());
    }

    #[test]
    fn switch_innermost_probe_residual_preserves_strategy_context() {
        let trs = Trs::new(
            None,
            BTreeSet::from([Variable::new("x"), Variable::new("y")]),
            vec![RewriteRule::new(
                Term::app("p", vec![Term::app("s", vec![Term::var("x")])]),
                Term::var("x"),
            )],
        );
        let pairs = vec![DependencyPair::new_for_test(
            Term::app(
                "plus#",
                vec![Term::var("x"), Term::app("s", vec![Term::var("y")])],
            ),
            Term::app(
                "plus#",
                vec![
                    Term::var("x"),
                    Term::app("p", vec![Term::app("s", vec![Term::var("y")])]),
                ],
            ),
        )];
        let options = DpOptions::default();
        let strategy = DpStrategy::Processor(DpStrategyProcessor::SwitchInnermost);

        let (_, residuals) = crate::proving::probe_dp_atom(&trs, pairs, &options, &strategy, None)
            .expect("switch probe");

        assert_eq!(residuals.len(), 1);
        let (residual_trs, _, _, normal_form_substitutions) =
            parsed_dp_probe_residual(&residuals[0]);
        assert_eq!(residual_trs.strategy(), RewriteStrategy::Innermost);
        assert!(normal_form_substitutions);
    }

    #[test]
    fn graph_probe_applies_to_exact_input_before_component_decomposition() {
        let trs = Trs::new(
            None,
            BTreeSet::from([Variable::new("x")]),
            vec![
                RewriteRule::new(
                    Term::app("f", vec![Term::var("x")]),
                    Term::app("g", vec![Term::var("x")]),
                ),
                RewriteRule::new(
                    Term::app("g", vec![Term::var("x")]),
                    Term::app("g", vec![Term::var("x")]),
                ),
            ],
        );
        let pairs = vec![
            DependencyPair::new_for_test(
                Term::app("f#", vec![Term::var("x")]),
                Term::app("g#", vec![Term::var("x")]),
            ),
            DependencyPair::new_for_test(
                Term::app("g#", vec![Term::var("x")]),
                Term::app("g#", vec![Term::var("x")]),
            ),
        ];
        let options = DpOptions::default();
        let strategy = DpStrategy::Processor(DpStrategyProcessor::DependencyGraph);

        let (proof, residuals) =
            crate::proving::probe_dp_atom(&trs, pairs, &options, &strategy, None)
                .expect("graph probe");

        assert_eq!(residuals.len(), 1);
        assert_eq!(parsed_dp_probe_residual(&residuals[0]).1.len(), 1);
        assert!(proof.is_none());
    }

    #[test]
    fn csr_graph_probe_applies_to_exact_input_before_component_decomposition() {
        let trs = Trs::new(
            None,
            BTreeSet::from([Variable::new("x")]),
            vec![
                RewriteRule::new(
                    Term::app("f", vec![Term::var("x")]),
                    Term::app("g", vec![Term::var("x")]),
                ),
                RewriteRule::new(
                    Term::app("g", vec![Term::var("x")]),
                    Term::app("g", vec![Term::var("x")]),
                ),
            ],
        );
        let csr = CsrTrs::new(
            trs,
            ReplacementMap::new(BTreeMap::from([
                (Symbol::new("f"), BTreeSet::from([0])),
                (Symbol::new("g"), BTreeSet::from([0])),
            ])),
        )
        .unwrap();
        let pairs = vec![
            DependencyPair::new_for_test(
                Term::app("f#", vec![Term::var("x")]),
                Term::app("g#", vec![Term::var("x")]),
            ),
            DependencyPair::new_for_test(
                Term::app("g#", vec![Term::var("x")]),
                Term::app("g#", vec![Term::var("x")]),
            ),
        ];
        let options = DpOptions::default();
        let strategy = DpStrategy::Processor(DpStrategyProcessor::DependencyGraph);

        let (proof, residuals) = crate::proving::probe_csr_dp_atom(
            &csr,
            pairs,
            None,
            true,
            "improved",
            "context-sensitive",
            false,
            &options,
            &strategy,
            None,
        )
        .expect("CSR graph probe");

        assert_eq!(residuals.len(), 1);
        let ProblemState::DependencyPairs(residual) = &residuals[0] else {
            panic!("expected CSR-DP residual state");
        };
        let CpfInputProblem::CsrDp { pairs, .. } =
            parse_cpf_input(None, &dp_state_input_cpf(residual))
                .expect("parse CSR-DP probe residual")
        else {
            panic!("expected CSR-DP residual");
        };
        assert_eq!(pairs.len(), 1);
        assert!(proof.is_none());
    }

    #[test]
    fn csr_lpar08_cap_ren_preserves_frozen_variable_sharing() {
        let x = Term::var("x");
        let trs = Trs::new(
            None,
            BTreeSet::from([Variable::new("x")]),
            vec![RewriteRule::new(
                Term::app("f", vec![x.clone()]),
                Term::app(
                    "c",
                    vec![Term::app("a", Vec::new()), Term::app("b", Vec::new())],
                ),
            )],
        );
        let source = Term::app("c", vec![x.clone(), x]);
        let target = Term::app(
            "c",
            vec![Term::app("a", Vec::new()), Term::app("b", Vec::new())],
        );

        let frozen = CsrTrs::new(
            trs.clone(),
            ReplacementMap::new(BTreeMap::from([(Symbol::new("c"), BTreeSet::new())])),
        )
        .unwrap();
        assert!(csr_lpar08_cap_ren_no_edge(&frozen, &source, &target));

        let active = CsrTrs::new(
            trs,
            ReplacementMap::new(BTreeMap::from([(Symbol::new("c"), BTreeSet::from([0, 1]))])),
        )
        .unwrap();
        assert!(!csr_lpar08_cap_ren_no_edge(&active, &source, &target));
    }

    #[test]
    fn csr_graph_preserves_undefined_marked_and_unhiding_roots() {
        let trs = Trs::new(
            None,
            BTreeSet::from([Variable::new("x")]),
            vec![RewriteRule::new(
                Term::app("f", vec![Term::var("x")]),
                Term::app("g", vec![Term::var("x")]),
            )],
        );
        let csr = CsrTrs::new(
            trs,
            ReplacementMap::new(BTreeMap::from([
                (Symbol::new("f"), BTreeSet::from([0])),
                (Symbol::new("g"), BTreeSet::from([0])),
            ])),
        )
        .unwrap();
        let marked = Term::app("f#", vec![Term::var("x")]);
        let unhiding = Term::app("__CSR_U0", vec![Term::var("x")]);

        assert!(csr_undefined_root_mismatch_no_edge(
            &csr, &unhiding, &marked
        ));
        assert!(!csr_undefined_root_mismatch_no_edge(
            &csr, &unhiding, &unhiding
        ));
        assert!(!csr_undefined_root_mismatch_no_edge(
            &csr,
            &Term::app("f", vec![Term::var("x")]),
            &Term::app("g", vec![Term::var("x")]),
        ));
    }

    #[test]
    fn nonminimal_dp_state_rejects_usable_rule_reduction_pairs() {
        assert!(!usable_rule_reduction_pair_is_certifiable(false, true));
        assert!(usable_rule_reduction_pair_is_certifiable(false, false));
        assert!(usable_rule_reduction_pair_is_certifiable(true, true));
    }

    #[test]
    fn empty_usable_rule_reduction_pair_still_requires_minimality() {
        let tree = DpProofTree::RedPair {
            reduction: DpRemovalProof {
                pairs: Vec::new(),
                usable_rules: Vec::new(),
                uses_usable_rules: true,
                force_non_mono_usable_rules: false,
                strict_pair_indices: Vec::new(),
                strict_rules: Vec::new(),
                reduction_pair: DpReductionPairProof::Polynomial {
                    interpretation: Vec::new(),
                    backend: DpSearchBackend::Sat,
                },
            },
            proof: Box::new(DpProofTree::Empty),
        };

        assert!(csr_dp_tree_requires_minimality(&tree));
    }

    #[test]
    fn innermost_narrowing_rejects_positions_outside_ceta_icap_when_q_normal() {
        let trs = Trs::new_with_strategy(
            None,
            BTreeSet::from([Variable::new("x")]),
            vec![RewriteRule::new(
                Term::app("g", vec![Term::var("x")]),
                Term::var("x"),
            )],
            RewriteStrategy::Innermost,
        );
        let pair = DependencyPair::new_for_test(
            Term::app("f#", vec![Term::var("x")]),
            Term::app("f#", vec![Term::app("g", vec![Term::app("a", Vec::new())])]),
        );
        let q_lhss = vec![Term::app("h", vec![Term::var("x")])];

        assert!(!narrowing_position_is_ceta_q_admissible(
            &trs,
            &pair,
            &[1, 1],
            &q_lhss,
        ));
        assert!(narrowing_position_is_ceta_q_admissible(
            &trs,
            &pair,
            &[1],
            &q_lhss,
        ));
    }

    #[test]
    fn innermost_narrowing_rejects_root_overlap_with_reducible_rule_argument() {
        let zero = Term::app("0", Vec::new());
        let h_zero = Term::app("h", vec![zero.clone()]);
        let pair = DependencyPair::new_for_test(
            Term::app("f#", vec![Term::app("s", vec![h_zero.clone()])]),
            Term::app("f#", vec![Term::app("g", vec![h_zero])]),
        );
        let rules = vec![
            RewriteRule::new(
                Term::app("g", vec![Term::app("h", vec![Term::var("x")])]),
                Term::app("g", vec![Term::var("x")]),
            ),
            RewriteRule::new(Term::app("h", vec![zero]), Term::app("a", Vec::new())),
        ];
        let q_lhss = rules
            .iter()
            .map(|rule| rule.lhs().clone())
            .collect::<Vec<_>>();

        assert!(
            narrow_pair_at_exact_position(&pair, &[1], &rules, &q_lhss)
                .expect("narrowing set")
                .is_empty()
        );
        assert_eq!(
            narrow_pair_at_exact_position(&pair, &[1], &rules, &[])
                .expect("ordinary narrowing set")
                .len(),
            1
        );
    }

    #[test]
    fn full_narrowing_rejects_positions_erased_by_empty_q_icap() {
        let x = Term::var("x");
        let trs = Trs::new_with_strategy(
            None,
            BTreeSet::from([Variable::new("x")]),
            vec![
                RewriteRule::new(
                    Term::app("mark", vec![Term::app("s", vec![x.clone()])]),
                    Term::app("active", vec![Term::app("s", vec![x.clone()])]),
                ),
                RewriteRule::new(
                    Term::app("f", vec![Term::app("mark", vec![x.clone()])]),
                    Term::app("f", vec![x.clone()]),
                ),
            ],
            RewriteStrategy::Full,
        );
        let pair = DependencyPair::new_for_test(
            Term::app("mark#", vec![Term::app("f", vec![x.clone()])]),
            Term::app(
                "active#",
                vec![Term::app("f", vec![Term::app("mark", vec![x])])],
            ),
        );

        assert!(!narrowing_position_is_ceta_q_admissible(
            &trs,
            &pair,
            &[1, 1],
            &[],
        ));
        assert!(narrowing_position_is_ceta_q_admissible(
            &trs,
            &pair,
            &[1],
            &[],
        ));
    }

    #[test]
    fn jwteparla1_innermost_narrowing_matches_ceta_side_conditions() {
        let x = Term::var("x");
        let a = Term::app("a", Vec::new());
        let fixed = Term::app(
            "f",
            vec![
                a.clone(),
                Term::app(
                    "f",
                    vec![Term::app("f", vec![a.clone(), a.clone()]), a.clone()],
                ),
            ],
        );
        let lhs = Term::app("f", vec![x.clone(), fixed.clone()]);
        let rhs = Term::app("f", vec![Term::app("f", vec![a.clone(), x.clone()]), x]);
        let trs = Trs::new_with_strategy(
            None,
            BTreeSet::from([Variable::new("x")]),
            vec![RewriteRule::new(lhs.clone(), rhs.clone())],
            RewriteStrategy::Innermost,
        );
        let marked_lhs = mark_root(&lhs, &Symbol::new("f"));
        let pair =
            DependencyPair::new_for_test(marked_lhs.clone(), mark_root(&rhs, &Symbol::new("f")));
        let inner_pair = DependencyPair::new_for_test(
            marked_lhs,
            Term::app("f#", vec![a.clone(), Term::var("x")]),
        );
        let pairs = vec![pair.clone(), inner_pair.clone()];
        let q_lhss = vec![lhs];
        assert!(ceta_q_iedg_edge(
            &trs,
            &pair,
            &inner_pair,
            &q_lhss,
            trs.rules()
        ));
        let graph = dependency_pair_graph_with_context(&trs, &pairs, Some(&q_lhss));
        let outer_index = pairs
            .iter()
            .position(|candidate| candidate == &pair)
            .unwrap();
        let inner_index = pairs
            .iter()
            .position(|candidate| candidate == &inner_pair)
            .unwrap();
        assert!(graph[outer_index].contains(&inner_index));
        assert!(ceta_q_iedg_edge(&trs, &pair, &pair, &q_lhss, trs.rules()));
        assert!(narrowing_position_is_admissible(
            &trs,
            &pair,
            &[],
            std::slice::from_ref(&pair),
            &q_lhss
        ));
        assert!(!narrowing_position_is_admissible(
            &trs,
            &pair,
            &[1],
            std::slice::from_ref(&pair),
            &q_lhss
        ));

        let candidates = synthesize_narrowing_steps_filtered(
            None,
            &trs,
            std::slice::from_ref(&pair),
            &DpOptions::default(),
            Some(&q_lhss),
            None,
            &DpStrategyCancellation::default(),
            |_| true,
        )
        .expect("CeTA-compatible narrowing candidate");
        assert!(candidates.iter().any(|(_, step, _)| {
            step.position.is_empty()
                && step.narrowings.iter().any(|narrowed| {
                    narrowed.lhs() == &Term::app("f#", vec![fixed.clone(), fixed.clone()])
                })
        }));
    }

    #[test]
    fn standard_instantiation_coverage_rejects_uncovered_incoming_edge() {
        let trs = Trs::new(
            None,
            BTreeSet::from([Variable::new("x"), Variable::new("y")]),
            vec![
                RewriteRule::new(
                    Term::app(
                        "f",
                        vec![
                            Term::app("|0|", Vec::new()),
                            Term::app("|1|", Vec::new()),
                            Term::var("x"),
                        ],
                    ),
                    Term::app("h", vec![Term::var("x"), Term::var("x")]),
                ),
                RewriteRule::new(
                    Term::app("h", vec![Term::var("x"), Term::var("y")]),
                    Term::app("f", vec![Term::var("x"), Term::var("y"), Term::var("x")]),
                ),
            ],
        );
        let selected = DependencyPair::new_for_test(
            Term::app(
                "f#",
                vec![
                    Term::app("|0|", Vec::new()),
                    Term::app("|1|", Vec::new()),
                    Term::var("x"),
                ],
            ),
            Term::app("h#", vec![Term::var("x"), Term::var("x")]),
        );
        let predecessor = DependencyPair::new_for_test(
            Term::app("h#", vec![Term::var("x"), Term::var("y")]),
            Term::app("f#", vec![Term::var("x"), Term::var("y"), Term::var("x")]),
        );
        let bad_instantiation = DependencyPair::new_for_test(
            Term::app(
                "f#",
                vec![
                    Term::app("|0|", Vec::new()),
                    Term::app("|1|", Vec::new()),
                    Term::app("|0|", Vec::new()),
                ],
            ),
            Term::app(
                "h#",
                vec![Term::app("|0|", Vec::new()), Term::app("|0|", Vec::new())],
            ),
        );

        let required = standard_instantiation_required_pair(&trs, &predecessor, &selected).unwrap();
        assert!(dependency_pair_is_instance_of(&required, &selected));
        assert!(!dependency_pair_is_instance_of(
            &required,
            &bad_instantiation
        ));
        assert!(!standard_instantiation_ceta_coverage_holds(
            &trs,
            &[predecessor, selected.clone()],
            &selected,
            &[bad_instantiation],
        ));
    }

    #[test]
    fn innermost_instantiation_keeps_repeated_predecessor_variables() {
        let trs = Trs::new_with_strategy(
            None,
            BTreeSet::from([Variable::new("x"), Variable::new("y"), Variable::new("z")]),
            vec![
                RewriteRule::new(
                    Term::app("f", vec![Term::var("x"), Term::var("y"), Term::var("z")]),
                    Term::app("g", vec![Term::var("x"), Term::var("y"), Term::var("z")]),
                ),
                RewriteRule::new(
                    Term::app(
                        "g",
                        vec![
                            Term::app("|0|", Vec::new()),
                            Term::app("|1|", Vec::new()),
                            Term::var("x"),
                        ],
                    ),
                    Term::app("f", vec![Term::var("x"), Term::var("x"), Term::var("x")]),
                ),
            ],
            RewriteStrategy::Innermost,
        );
        let pairs = dependency_pairs(&trs);
        let (step, residual) = synthesize_instantiation_step(&trs, &pairs)
            .expect("AProVE-style repeated-variable instantiation");

        assert_eq!(step.instantiations.len(), 1);
        assert_eq!(
            step.instantiations[0],
            DependencyPair {
                lhs: Term::app("f#", vec![Term::var("z"), Term::var("z"), Term::var("z")]),
                rhs: Term::app("g#", vec![Term::var("z"), Term::var("z"), Term::var("z")]),
                source_rule: 0,
            }
        );
        assert_eq!(residual.len(), pairs.len());
    }

    #[test]
    fn polynomial_size_change_handles_non_subterm_decrease() {
        let trs = Trs::new_with_strategy(
            None,
            BTreeSet::from([Variable::new("x")]),
            vec![
                RewriteRule::new(Term::app("g", vec![Term::var("x")]), Term::var("x")),
                RewriteRule::new(
                    Term::app("f", vec![Term::app("s", vec![Term::var("x")])]),
                    Term::app("f", vec![Term::app("g", vec![Term::var("x")])]),
                ),
            ],
            RewriteStrategy::Innermost,
        );
        let pairs = vec![DependencyPair::new_for_test(
            Term::app("f#", vec![Term::app("s", vec![Term::var("x")])]),
            Term::app("f#", vec![Term::app("g", vec![Term::var("x")])]),
        )];
        assert!(synthesize_subterm_criterion(&pairs).is_none());
        let (graphs, reduction_pair, usable_rules) = synthesize_polynomial_size_change(
            None,
            &pairs,
            &trs,
            &DpOptions::default(),
            None,
            None,
            None,
        )
        .unwrap();
        assert_eq!(graphs.len(), 1);
        assert!(graphs[0].edges.iter().any(|edge| edge.strict));
        assert!(matches!(
            reduction_pair,
            DpReductionPairProof::Polynomial { .. }
        ));
        assert!(usable_rules.iter().any(|rule| {
            rule.lhs()
                .root_symbol()
                .is_some_and(|symbol| symbol.as_str() == "g")
        }));
    }

    #[test]
    fn polynomial_sct_retries_models_after_symbol_renaming() {
        if !command_exists("z3") { return; }
        for (binary, unary) in [("-", "neg"), ("audit_symbol_0", "audit_symbol_1")] {
            let x = Term::var("x");
            let y = Term::var("y");
            let duplicate = |term: Term| Term::app(binary, vec![term.clone(), term]);
            let nx = Term::app(unary, vec![x.clone()]);
            let ny = Term::app(unary, vec![y.clone()]);
            let lhs_args = vec![duplicate(nx), duplicate(ny)];
            let xy = Term::app(binary, vec![x.clone(), y.clone()]);
            let rhs_args = vec![xy.clone(), xy];
            let marked = format!("{binary}#");
            let pairs = vec![
                DependencyPair::new_for_test(Term::app(&marked, lhs_args.clone()), Term::app(&marked, rhs_args.clone())),
                DependencyPair::new_for_test(Term::app(&marked, lhs_args.clone()), Term::app(&marked, vec![x, y])),
            ];
            let rules = vec![RewriteRule::new(Term::app(binary, lhs_args), Term::app(binary, rhs_args))];
            assert!(synthesize_pair_oriented_polynomial_size_change_proof(
                None, &pairs, &rules, &DpOptions::default(), None,
                Some(Instant::now() + Duration::from_secs(10)),
            ).is_some(), "SCT model search failed for {binary}/{unary}");
        }
    }

    #[test]
    fn incremental_polynomial_size_change_matches_rebuilding_solver() {
        if !command_exists("z3") {
            return;
        }
        let pairs = vec![DependencyPair::new_for_test(
            Term::app("f#", vec![Term::app("s", vec![Term::var("x")])]),
            Term::app("f#", vec![Term::var("x")]),
        )];
        let options = DpOptions {
            max_polynomial_constant: 1,
            max_polynomial_coefficient: 1,
            max_search_space: 8,
            smt_solver: Some("z3".to_string()),
            ..DpOptions::default()
        };

        let rebuilding =
            synthesize_linear_polynomial_for_size_change_rebuilding(&pairs, &[], &options, None)
                .expect("rebuilding solver should find a checked interpretation");
        let incremental =
            synthesize_linear_polynomial_for_size_change_incrementally(&pairs, &[], &options, None)
                .expect("incremental solver protocol should succeed")
                .expect("incremental solver should find a checked interpretation");

        assert!(polynomial_coefficients_are_strictly_monotone(
            &pairs,
            &[],
            &rebuilding,
        ));
        assert!(polynomial_coefficients_are_strictly_monotone(
            &pairs,
            &[],
            &incremental,
        ));
        for interpretations in [&rebuilding, &incremental] {
            let graphs = polynomial_size_change_graphs(&pairs, interpretations)
                .expect("checked interpretations must induce size-change graphs");
            assert!(size_change_graphs_are_terminating(&graphs).is_some());
        }
    }

    #[test]
    fn standard_polynomial_size_change_uses_certified_usable_rule_context() {
        let trs = Trs::new(
            None,
            BTreeSet::from([Variable::new("x")]),
            vec![
                RewriteRule::new(Term::app("g", vec![Term::var("x")]), Term::var("x")),
                RewriteRule::new(
                    Term::app("f", vec![Term::app("s", vec![Term::var("x")])]),
                    Term::app("f", vec![Term::app("g", vec![Term::var("x")])]),
                ),
            ],
        );
        let pairs = vec![DependencyPair::new_for_test(
            Term::app("f#", vec![Term::app("s", vec![Term::var("x")])]),
            Term::app("f#", vec![Term::app("g", vec![Term::var("x")])]),
        )];
        assert!(synthesize_subterm_criterion(&pairs).is_none());
        let (graphs, reduction_pair, usable_rules) = synthesize_polynomial_size_change(
            None,
            &pairs,
            &trs,
            &DpOptions::default(),
            None,
            None,
            None,
        )
        .unwrap();
        assert_eq!(graphs.len(), 1);
        assert!(graphs[0].edges.iter().any(|edge| edge.strict));
        assert!(matches!(
            reduction_pair,
            DpReductionPairProof::Polynomial { .. }
        ));
        assert!(usable_rules.iter().any(|rule| {
            rule.lhs()
                .root_symbol()
                .is_some_and(|symbol| symbol.as_str() == "g")
        }));
        assert_eq!(usable_rules, vec![trs.rules()[0].clone()]);
    }

    #[test]
    fn polynomial_size_change_obeys_q_minimality_guard() {
        let trs = Trs::new(
            None,
            BTreeSet::from([Variable::new("x")]),
            vec![
                RewriteRule::new(Term::app("g", vec![Term::var("x")]), Term::var("x")),
                RewriteRule::new(
                    Term::app("f", vec![Term::app("s", vec![Term::var("x")])]),
                    Term::app("f", vec![Term::app("g", vec![Term::var("x")])]),
                ),
            ],
        );
        let pairs = vec![DependencyPair::new_for_test(
            Term::app("f#", vec![Term::app("s", vec![Term::var("x")])]),
            Term::app("f#", vec![Term::app("g", vec![Term::var("x")])]),
        )];
        let q_minimal = vec![Term::app("a", vec![])];
        assert!(
            synthesize_polynomial_size_change(
                None,
                &pairs,
                &trs,
                &DpOptions::default(),
                Some(&q_minimal),
                None,
                None,
            )
            .is_some()
        );

        let q_minimal_with_compound_lhs = vec![Term::app("g", vec![Term::var("x")])];
        assert!(
            synthesize_polynomial_size_change(
                None,
                &pairs,
                &trs,
                &DpOptions::default(),
                Some(&q_minimal_with_compound_lhs),
                None,
                None,
            )
            .is_some()
        );

        let q_non_minimal = vec![
            Term::app("f", vec![Term::app("g", vec![Term::var("x")])]),
            Term::app("g", vec![Term::var("x")]),
        ];
        assert!(
            synthesize_polynomial_size_change(
                None,
                &pairs,
                &trs,
                &DpOptions::default(),
                Some(&q_non_minimal),
                None,
                None,
            )
            .is_none()
        );
    }

    #[test]
    fn estimated_dependency_graph_ren_separates_variable_occurrences() {
        let trs = Trs::new(
            None,
            BTreeSet::from([Variable::new("x")]),
            vec![RewriteRule::new(
                Term::app("f", vec![Term::var("x")]),
                Term::app("a", vec![]),
            )],
        );
        let rhs = Term::app("F#", vec![Term::var("y"), Term::var("y")]);
        let target_lhs = Term::app("F#", vec![Term::app("a", vec![]), Term::app("b", vec![])]);
        assert!(estimated_dependency_edge(&trs, &rhs, &target_lhs));
    }

    #[test]
    fn standard_dependency_graph_uses_estimated_edges() {
        let trs = Trs::new(
            None,
            BTreeSet::from([Variable::new("x")]),
            vec![RewriteRule::new(
                Term::app("f", vec![Term::var("x")]),
                Term::app("f", vec![Term::var("x")]),
            )],
        );
        let pairs = vec![
            DependencyPair::new_for_test(
                Term::app("F#", vec![Term::app("a", vec![])]),
                Term::app("F#", vec![Term::app("a", vec![])]),
            ),
            DependencyPair::new_for_test(
                Term::app("F#", vec![Term::app("b", vec![])]),
                Term::app("F#", vec![Term::app("b", vec![])]),
            ),
        ];
        let graph = dependency_pair_graph(&trs, &pairs);
        assert_eq!(graph, vec![vec![0], vec![1]]);
    }

    #[test]
    fn standard_dependency_graph_keeps_mark_mediated_self_edge_for_ceta() {
        let trs = crate::parsing::parse_trs(
            None,
            r#"
(format TRS)
(fun a__zeros 0) (fun cons 2) (fun |0| 0) (fun zeros 0)
(fun a__and 2) (fun tt 0) (fun mark 1) (fun a__length 1)
(fun nil 0) (fun s 1) (fun and 2) (fun length 1)
(rule a__zeros (cons |0| zeros))
(rule (a__and tt X) (mark X))
(rule (a__length nil) |0|)
(rule (a__length (cons N L)) (s (a__length (mark L))))
(rule (mark zeros) a__zeros)
(rule (mark (and X1 X2)) (a__and (mark X1) X2))
(rule (mark (length X)) (a__length (mark X)))
(rule (mark (cons X1 X2)) (cons (mark X1) X2))
(rule (mark |0|) |0|)
(rule (mark tt) tt)
(rule (mark nil) nil)
(rule (mark (s X)) (s (mark X)))
(rule a__zeros zeros)
(rule (a__and X1 X2) (and X1 X2))
(rule (a__length X) (length X))
"#,
        )
        .unwrap();
        let pairs = dependency_pairs(&trs)
            .into_iter()
            .filter(|pair| pair.source_rule() == 3 && term_root_name(pair.rhs()) == "a__length#")
            .collect::<Vec<_>>();
        assert_eq!(pairs.len(), 1);

        let edge_context = DpGraphEdgeContext::new(&trs);
        assert!(
            ceta_tcap_match_cached(&trs, &edge_context, pairs[0].rhs(), pairs[0].lhs()),
            "forward tcap must retain the self-edge"
        );
        assert!(
            ceta_reverse_tcap_match_cached(&trs, &edge_context, pairs[0].lhs(), pairs[0].rhs()),
            "reverse tcap must retain the self-edge"
        );
        assert!(
            !ceta_nonreachable_gtcap_cached(&trs, &edge_context, pairs[0].rhs(), pairs[0].lhs(),),
            "gtcap must not reject the checker-required self-edge"
        );
        assert_eq!(dependency_pair_graph(&trs, &pairs), vec![vec![0]]);
    }

    #[test]
    fn semantic_labeling_graph_uses_label_changing_active_rules() {
        let variables = BTreeSet::from([Variable::new("x"), Variable::new("y")]);
        let original_trs = Trs::new(
            None,
            variables.clone(),
            vec![RewriteRule::new(
                Term::app("a", vec![Term::var("x")]),
                Term::app("a", vec![Term::var("x")]),
            )],
        );
        let labeled_rules = vec![RewriteRule::new(
            Term::app("__ferrum_sl__61__0", vec![Term::var("x")]),
            Term::app("__ferrum_sl__61__1", vec![Term::var("x")]),
        )];
        let pairs = vec![
            DependencyPair::new_for_test(
                Term::app(
                    "__ferrum_sl__7023__0",
                    vec![Term::app("__ferrum_sl__61__0", vec![Term::var("x")])],
                ),
                Term::app(
                    "__ferrum_sl__7023__0",
                    vec![Term::app("__ferrum_sl__61__0", vec![Term::var("x")])],
                ),
            ),
            DependencyPair::new_for_test(
                Term::app(
                    "__ferrum_sl__7023__0",
                    vec![Term::app("__ferrum_sl__61__1", vec![Term::var("y")])],
                ),
                Term::app(
                    "__ferrum_sl__7023__0",
                    vec![Term::app("__ferrum_sl__61__1", vec![Term::var("y")])],
                ),
            ),
        ];

        let graph = dependency_pair_graph_with_rules_deadline(
            &original_trs,
            &labeled_rules,
            &pairs,
            None,
            None,
            &DpStrategyCancellation::default(),
        )
        .unwrap();

        assert!(graph[0].contains(&1));
    }

    #[test]
    fn innermost_iedg_uses_pair_local_usable_rules_for_reverse_cap() {
        let rule = RewriteRule::new(
            Term::app(
                "app",
                vec![
                    Term::app("h", vec![]),
                    Term::app(
                        "app",
                        vec![
                            Term::app("app", vec![Term::app("g", vec![]), Term::var("x")]),
                            Term::var("y"),
                        ],
                    ),
                ],
            ),
            Term::app("app", vec![Term::app("h", vec![]), Term::var("x")]),
        );
        let trs = Trs::new_with_strategy(
            None,
            BTreeSet::from([Variable::new("x"), Variable::new("y")]),
            vec![rule.clone()],
            RewriteStrategy::Innermost,
        );
        let pair = DependencyPair::new_for_test(
            mark_root(rule.lhs(), &Symbol::new("app")),
            mark_root(rule.rhs(), &Symbol::new("app")),
        );
        let q_lhss = vec![rule.lhs().clone()];

        assert!(ceta_innermost_usable_rules_for_pair(trs.rules(), &q_lhss, &pair).is_empty());
        assert_eq!(
            dependency_pair_graph_with_context(&trs, &[pair], Some(&q_lhss)),
            vec![vec![0]]
        );
    }

    #[test]
    fn applicative_innermost_usable_rules_drop_q_blocked_f_component() {
        let lhs = Term::app(
            "app",
            vec![
                Term::app(
                    "app",
                    vec![
                        Term::app(
                            "app",
                            vec![Term::app("f", vec![]), Term::app("s", vec![Term::var("x")])],
                        ),
                        Term::var("y"),
                    ],
                ),
                Term::var("z"),
            ],
        );
        let rhs = Term::app(
            "app",
            vec![
                Term::app(
                    "app",
                    vec![
                        Term::app("app", vec![Term::app("f", vec![]), Term::var("x")]),
                        Term::app(
                            "s",
                            vec![Term::app(
                                "app",
                                vec![Term::app("c", vec![]), Term::var("y")],
                            )],
                        ),
                    ],
                ),
                Term::app("app", vec![Term::app("c", vec![]), Term::var("z")]),
            ],
        );
        let rule = RewriteRule::new(lhs.clone(), rhs.clone());
        let trs = Trs::new_with_strategy(
            None,
            BTreeSet::from([Variable::new("x"), Variable::new("y"), Variable::new("z")]),
            vec![rule],
            RewriteStrategy::Innermost,
        );
        let pair = DependencyPair::new_for_test(
            mark_root(&lhs, &Symbol::new("app")),
            mark_root(&rhs, &Symbol::new("app")),
        );

        assert!(
            usable_rules_in_innermost_context(&trs, &[pair], Some(&[lhs])).is_empty(),
            "the source's Q-normality excludes the only applicative redex"
        );
    }

    #[test]
    fn applicative_innermost_usable_rules_keep_variable_head_application_rule() {
        let rule = RewriteRule::new(
            Term::app("app", vec![Term::var("function"), Term::var("argument")]),
            Term::var("argument"),
        );
        let trs = Trs::new_with_strategy(
            None,
            BTreeSet::from([Variable::new("function"), Variable::new("argument")]),
            vec![rule.clone()],
            RewriteStrategy::Innermost,
        );
        let pair = DependencyPair::new_for_test(
            Term::app("p#", vec![Term::var("argument")]),
            Term::app(
                "p#",
                vec![Term::app(
                    "app",
                    vec![Term::var("function"), Term::var("argument")],
                )],
            ),
        );

        assert_eq!(
            usable_rules_in_innermost_context(
                &trs,
                &[pair],
                Some(std::slice::from_ref(rule.lhs())),
            ),
            vec![rule]
        );
    }

    #[test]
    fn innermost_usable_rules_close_root_completed_rule_right_hand_sides() {
        let active = RewriteRule::new(
            Term::app(
                "active",
                vec![Term::app("f", vec![Term::var("x"), Term::var("x")])],
            ),
            Term::app(
                "mark",
                vec![Term::app(
                    "f",
                    vec![Term::app("a", vec![]), Term::app("b", vec![])],
                )],
            ),
        );
        let mark = RewriteRule::new(
            Term::app(
                "mark",
                vec![Term::app("f", vec![Term::var("x"), Term::var("y")])],
            ),
            Term::app(
                "active",
                vec![Term::app(
                    "f",
                    vec![Term::app("mark", vec![Term::var("x")]), Term::var("y")],
                )],
            ),
        );
        let expose_mark = RewriteRule::new(
            Term::app("seed", vec![Term::var("x")]),
            Term::app(
                "mark",
                vec![Term::app("f", vec![Term::var("x"), Term::app("b", vec![])])],
            ),
        );
        let trs = Trs::new_with_strategy(
            None,
            BTreeSet::from([Variable::new("x"), Variable::new("y")]),
            vec![active.clone(), mark.clone(), expose_mark.clone()],
            RewriteStrategy::Innermost,
        );
        let pair = DependencyPair::new_for_test(
            Term::app("p#", vec![Term::var("x")]),
            Term::app("seed", vec![Term::var("x")]),
        );
        let q_lhss = trs
            .rules()
            .iter()
            .map(|rule| rule.lhs().clone())
            .collect::<Vec<_>>();

        let usable = usable_rules_in_innermost_context(&trs, &[pair], Some(&q_lhss));
        assert!(usable.contains(&expose_mark));
        assert!(usable.contains(&mark));
        assert!(
            usable.contains(&active),
            "the rhs of the root-completed mark rule exposes active(f(mark(x),y))"
        );
    }

    #[test]
    fn innermost_q_graph_retains_cap_edge_through_defined_condition() {
        let rules = vec![
            RewriteRule::new(
                Term::app(
                    "lt",
                    vec![
                        Term::app("|0|", vec![]),
                        Term::app("s", vec![Term::var("x")]),
                    ],
                ),
                Term::app("true", vec![]),
            ),
            RewriteRule::new(
                Term::app("lt", vec![Term::var("x"), Term::app("|0|", vec![])]),
                Term::app("false", vec![]),
            ),
            RewriteRule::new(
                Term::app(
                    "lt",
                    vec![
                        Term::app("s", vec![Term::var("x")]),
                        Term::app("s", vec![Term::var("y")]),
                    ],
                ),
                Term::app("lt", vec![Term::var("x"), Term::var("y")]),
            ),
        ];
        let trs = Trs::new_with_strategy(
            None,
            BTreeSet::from([Variable::new("x"), Variable::new("y"), Variable::new("c")]),
            rules.clone(),
            RewriteStrategy::Innermost,
        );
        let pairs = vec![
            DependencyPair::new_for_test(
                Term::app("help#", vec![Term::var("x"), Term::var("c")]),
                Term::app(
                    "if#",
                    vec![
                        Term::app("lt", vec![Term::var("c"), Term::var("x")]),
                        Term::var("x"),
                        Term::var("c"),
                    ],
                ),
            ),
            DependencyPair::new_for_test(
                Term::app(
                    "if#",
                    vec![Term::app("true", vec![]), Term::var("x"), Term::var("c")],
                ),
                Term::app(
                    "help#",
                    vec![Term::var("x"), Term::app("s", vec![Term::var("c")])],
                ),
            ),
        ];
        let q_lhss = rules
            .iter()
            .map(|rule| rule.lhs().clone())
            .collect::<Vec<_>>();
        let usable = ceta_innermost_usable_rules_for_pair(trs.rules(), &q_lhss, &pairs[0]);

        assert!(
            usable
                .iter()
                .any(|rule| rule.rhs() == &Term::app("true", vec![]))
        );
        assert!(ceta_q_iedg_edge_with_usable_rules(
            &pairs[0],
            &pairs[1],
            &q_lhss,
            trs.rules(),
            Some(&usable),
        ));
        assert!(dependency_pair_graph_with_context(&trs, &pairs, Some(&q_lhss))[0].contains(&1));
    }

    #[test]
    fn innermost_dependency_graph_uses_rhs_lhs_unification_without_cap() {
        let trs = Trs::new_with_strategy(
            None,
            BTreeSet::from([Variable::new("x")]),
            vec![RewriteRule::new(
                Term::app(
                    "a",
                    vec![Term::app(
                        "b",
                        vec![Term::app("a", vec![Term::app("b", vec![Term::var("x")])])],
                    )],
                ),
                Term::app(
                    "b",
                    vec![Term::app(
                        "a",
                        vec![Term::app(
                            "b",
                            vec![Term::app(
                                "a",
                                vec![Term::app("a", vec![Term::app("b", vec![Term::var("x")])])],
                            )],
                        )],
                    )],
                ),
            )],
            RewriteStrategy::Innermost,
        );
        let pairs = complete_dependency_pairs(&trs);
        let graph = dependency_pair_graph(&trs, &pairs);

        assert_eq!(pairs.len(), 3);
        assert_eq!(graph, vec![vec![0, 1, 2], vec![0, 1, 2], vec![0, 1, 2]]);
    }

    #[test]
    fn innermost_dependency_graph_uses_ground_normal_rhs_calls_without_cap() {
        let trs = Trs::new_with_strategy(
            None,
            BTreeSet::from([Variable::new("x")]),
            vec![
                RewriteRule::new(
                    Term::app("f", vec![Term::app("|1|", vec![])]),
                    Term::app("f", vec![Term::app("g", vec![Term::app("|1|", vec![])])]),
                ),
                RewriteRule::new(
                    Term::app("f", vec![Term::app("f", vec![Term::var("x")])]),
                    Term::app("f", vec![Term::var("x")]),
                ),
                RewriteRule::new(
                    Term::app("g", vec![Term::app("|0|", vec![])]),
                    Term::app("g", vec![Term::app("f", vec![Term::app("|0|", vec![])])]),
                ),
                RewriteRule::new(
                    Term::app("g", vec![Term::app("g", vec![Term::var("x")])]),
                    Term::app("g", vec![Term::var("x")]),
                ),
            ],
            RewriteStrategy::Innermost,
        );
        let pairs = complete_dependency_pairs(&trs);
        let graph = dependency_pair_graph(&trs, &pairs);

        assert_eq!(pairs.len(), 6);
        assert_eq!(
            graph,
            vec![
                vec![0, 1, 2],
                Vec::new(),
                vec![0, 1, 2],
                vec![3, 4, 5],
                Vec::new(),
                vec![3, 4, 5],
            ]
        );
    }

    #[test]
    fn innermost_dependency_graph_keeps_source_normality_edges_for_ceta() {
        let trs = Trs::new_with_strategy(
            None,
            BTreeSet::from([Variable::new("x")]),
            vec![
                RewriteRule::new(
                    Term::app(
                        "f",
                        vec![Term::var("x"), Term::app("g", vec![Term::var("x")])],
                    ),
                    Term::app(
                        "f",
                        vec![
                            Term::app("|1|", vec![]),
                            Term::app("g", vec![Term::var("x")]),
                        ],
                    ),
                ),
                RewriteRule::new(
                    Term::app("g", vec![Term::app("|1|", vec![])]),
                    Term::app("g", vec![Term::app("|0|", vec![])]),
                ),
            ],
            RewriteStrategy::Innermost,
        );
        let pairs = complete_dependency_pairs(&trs);
        let graph = dependency_pair_graph(&trs, &pairs);

        assert_eq!(pairs.len(), 3);
        assert_eq!(graph, vec![vec![0, 1], vec![2], Vec::new()]);
    }

    #[test]
    fn innermost_dependency_graph_uses_target_normality_edges_for_ceta() {
        let trs = Trs::new_with_strategy(
            None,
            BTreeSet::from([Variable::new("x"), Variable::new("y")]),
            vec![
                RewriteRule::new(
                    Term::app(
                        "f",
                        vec![Term::app("a", vec![Term::var("x")]), Term::var("y")],
                    ),
                    Term::app("g", vec![Term::var("x"), Term::var("y")]),
                ),
                RewriteRule::new(
                    Term::app("g", vec![Term::app("b", vec![]), Term::var("y")]),
                    Term::app("f", vec![Term::var("y"), Term::var("y")]),
                ),
                RewriteRule::new(
                    Term::app("a", vec![Term::app("b", vec![])]),
                    Term::app("c", vec![]),
                ),
            ],
            RewriteStrategy::Innermost,
        );
        let pairs = dependency_pairs(&trs);
        let graph = dependency_pair_graph(&trs, &pairs);

        assert_eq!(pairs.len(), 2);
        assert_eq!(graph, vec![vec![1], vec![0]]);
    }

    #[test]
    fn innermost_dependency_graph_keeps_edges_with_variable_redex_uncertainty() {
        let trs = Trs::new_with_strategy(
            None,
            BTreeSet::from([Variable::new("x"), Variable::new("y")]),
            vec![
                RewriteRule::new(
                    Term::app(
                        "f",
                        vec![Term::app("a", vec![Term::var("x")]), Term::var("y")],
                    ),
                    Term::app("g", vec![Term::var("x"), Term::var("y")]),
                ),
                RewriteRule::new(
                    Term::app("g", vec![Term::var("x"), Term::var("y")]),
                    Term::app("f", vec![Term::var("y"), Term::var("y")]),
                ),
                RewriteRule::new(
                    Term::app("a", vec![Term::app("b", vec![])]),
                    Term::app("c", vec![]),
                ),
            ],
            RewriteStrategy::Innermost,
        );
        let pairs = dependency_pairs(&trs);
        let graph = dependency_pair_graph(&trs, &pairs);

        assert_eq!(pairs.len(), 2);
        assert_eq!(graph, vec![vec![1], vec![0]]);
    }

    #[test]
    fn innermost_dependency_graph_keeps_nested_condition_rewrite_edge() {
        let variables = BTreeSet::from([
            Variable::new("n"),
            Variable::new("m"),
            Variable::new("k"),
            Variable::new("x"),
        ]);
        let trs = Trs::new_with_strategy(
            None,
            variables,
            vec![
                RewriteRule::new(
                    Term::app("eq", vec![Term::var("n"), Term::var("k")]),
                    Term::app("false", vec![]),
                ),
                RewriteRule::new(
                    Term::app(
                        "replace",
                        vec![
                            Term::var("n"),
                            Term::var("m"),
                            Term::app("cons", vec![Term::var("k"), Term::var("x")]),
                        ],
                    ),
                    Term::app(
                        "if_replace",
                        vec![
                            Term::app("eq", vec![Term::var("n"), Term::var("k")]),
                            Term::var("n"),
                            Term::var("m"),
                            Term::app("cons", vec![Term::var("k"), Term::var("x")]),
                        ],
                    ),
                ),
                RewriteRule::new(
                    Term::app(
                        "if_replace",
                        vec![
                            Term::app("false", vec![]),
                            Term::var("n"),
                            Term::var("m"),
                            Term::app("cons", vec![Term::var("k"), Term::var("x")]),
                        ],
                    ),
                    Term::app(
                        "replace",
                        vec![Term::var("n"), Term::var("m"), Term::var("x")],
                    ),
                ),
            ],
            RewriteStrategy::Innermost,
        );
        let pairs = dependency_pairs(&trs);
        let q_lhss = initial_innermost_lhss(&trs).expect("innermost left-hand sides");
        let graph = dependency_pair_graph_with_context(&trs, &pairs, Some(&q_lhss));
        assert_eq!(pairs.len(), 3);
        let replace_to_if = pairs
            .iter()
            .position(|pair| {
                term_root_name(pair.lhs()) == "replace#"
                    && term_root_name(pair.rhs()) == "if_replace#"
            })
            .expect("replace# to if_replace# pair");
        let if_to_replace = pairs
            .iter()
            .position(|pair| {
                term_root_name(pair.lhs()) == "if_replace#"
                    && term_root_name(pair.rhs()) == "replace#"
            })
            .expect("if_replace# to replace# pair");

        assert!(ceta_estimated_dependency_edge(
            &trs,
            pairs[replace_to_if].rhs(),
            pairs[if_to_replace].lhs(),
        ));
        assert!(graph[replace_to_if].contains(&if_to_replace));
    }

    #[test]
    fn innermost_dependency_graph_separates_mixed_innermost2_calls() {
        let variables = BTreeSet::from([Variable::new("x"), Variable::new("y")]);
        let trs = Trs::new_with_strategy(
            None,
            variables,
            vec![
                RewriteRule::new(
                    Term::app(
                        "g",
                        vec![
                            Term::app("c", vec![]),
                            Term::app(
                                "g",
                                vec![Term::app("a", vec![Term::var("x")]), Term::var("y")],
                            ),
                        ],
                    ),
                    Term::app(
                        "g",
                        vec![
                            Term::app("f", vec![Term::app("a", vec![Term::app("b", vec![])])]),
                            Term::app(
                                "g",
                                vec![Term::app("a", vec![Term::var("y")]), Term::var("x")],
                            ),
                        ],
                    ),
                ),
                RewriteRule::new(
                    Term::app("f", vec![Term::app("a", vec![Term::var("x")])]),
                    Term::app("c", vec![]),
                ),
                RewriteRule::new(
                    Term::app("a", vec![Term::app("b", vec![])]),
                    Term::app("d", vec![]),
                ),
            ],
            RewriteStrategy::Innermost,
        );
        let pairs = dependency_pairs(&trs);
        let q_lhss = initial_innermost_lhss(&trs).expect("innermost left-hand sides");
        let graph = dependency_pair_graph_with_context(&trs, &pairs, Some(&q_lhss));
        assert_eq!(pairs.len(), 5);
        let outer_g = pairs
            .iter()
            .position(|pair| {
                pair.lhs()
                    == &Term::app(
                        "g#",
                        vec![
                            Term::app("c", vec![]),
                            Term::app(
                                "g",
                                vec![
                                    Term::app("a", vec![Term::var("x")]),
                                    Term::var("y"),
                                ],
                            ),
                        ],
                    )
                    && term_root_name(pair.rhs()) == "g#"
                    && matches!(
                        pair.rhs(),
                        Term::App { args, .. }
                            if matches!(args.first(), Some(Term::App { symbol, .. }) if symbol.as_str() == "f")
                    )
            })
            .expect("outer g dependency pair");
        let cyclic = vec![pairs[outer_g].clone()];
        let refined_lhss = refined_innermost_lhss_for_pairs(&trs, &cyclic, Some(&q_lhss))
            .expect("refined innermost left-hand sides");
        let (rewrite, residual) = synthesize_innermost_rewriting_step_filtered(
            &trs,
            &cyclic,
            Some(&refined_lhss),
            |_| true,
        )
        .unwrap_or_else(|| {
            panic!("the cyclic pair should expose an innermost rewrite; refined Q={refined_lhss:?}")
        });
        let residual_graph =
            dependency_pair_graph_with_context(&trs, &residual, Some(&refined_lhss));
        assert!(
            residual_graph[0].is_empty(),
            "the rewrite should remove the self edge: step={rewrite:?}, graph={residual_graph:?}"
        );
        assert!(
            graph[outer_g].contains(&outer_g),
            "the complete five-pair problem must retain the cyclic outer g edge: {:?}",
            graph[outer_g],
        );
        // The local regression is the Q-preserving rewrite and the absence of
        // the formerly spurious residual self-edge.  The now-complete initial
        // DP problem also contains proper-subterm calls and therefore needs
        // the broader default continuation; it is intentionally not asserted
        // to close under only `rewriting; graph` here.
    }

    #[test]
    fn innermost_dependency_graph_separates_applicative_ag01_4_19_calls() {
        let variables = BTreeSet::from([Variable::new("x"), Variable::new("y")]);
        let trs = Trs::new_with_strategy(
            None,
            variables,
            vec![RewriteRule::new(
                Term::app(
                    "app",
                    vec![
                        Term::app(
                            "app",
                            vec![
                                Term::app("app", vec![Term::app("f", vec![]), Term::var("x")]),
                                Term::app("app", vec![Term::app("c", vec![]), Term::var("x")]),
                            ],
                        ),
                        Term::app("app", vec![Term::app("c", vec![]), Term::var("y")]),
                    ],
                ),
                Term::app(
                    "app",
                    vec![
                        Term::app(
                            "app",
                            vec![
                                Term::app("app", vec![Term::app("f", vec![]), Term::var("y")]),
                                Term::var("y"),
                            ],
                        ),
                        Term::app(
                            "app",
                            vec![
                                Term::app(
                                    "app",
                                    vec![
                                        Term::app(
                                            "app",
                                            vec![Term::app("f", vec![]), Term::var("y")],
                                        ),
                                        Term::var("x"),
                                    ],
                                ),
                                Term::var("y"),
                            ],
                        ),
                    ],
                ),
            )],
            RewriteStrategy::Innermost,
        );
        let lhs = Term::app(
            "app#",
            vec![
                Term::app(
                    "app",
                    vec![
                        Term::app("app", vec![Term::app("f", vec![]), Term::var("x")]),
                        Term::app("app", vec![Term::app("c", vec![]), Term::var("x")]),
                    ],
                ),
                Term::app("app", vec![Term::app("c", vec![]), Term::var("y")]),
            ],
        );
        let small = DependencyPair::new_for_test(
            lhs.clone(),
            Term::app(
                "app#",
                vec![
                    Term::app(
                        "app",
                        vec![
                            Term::app("app", vec![Term::app("f", vec![]), Term::var("y")]),
                            Term::var("x"),
                        ],
                    ),
                    Term::var("y"),
                ],
            ),
        );
        let large = DependencyPair::new_for_test(
            lhs,
            Term::app(
                "app#",
                vec![
                    Term::app(
                        "app",
                        vec![
                            Term::app("app", vec![Term::app("f", vec![]), Term::var("y")]),
                            Term::var("y"),
                        ],
                    ),
                    small.rhs().clone(),
                ],
            ),
        );
        let q_lhss = vec![trs.rules()[0].lhs().clone()];
        let graph = dependency_pair_graph_with_context(&trs, &[small, large], Some(&q_lhss));

        assert!(!graph[1].contains(&0));
    }

    #[test]
    fn innermost_dependency_graph_uses_source_lhs_ground_redex_filter() {
        let trs = Trs::new_with_strategy(
            None,
            BTreeSet::from([Variable::new("x"), Variable::new("y")]),
            vec![
                RewriteRule::new(
                    Term::app(
                        "f",
                        vec![Term::app("a", vec![Term::var("x")]), Term::var("y")],
                    ),
                    Term::app("g", vec![Term::var("x"), Term::var("y")]),
                ),
                RewriteRule::new(
                    Term::app("g", vec![Term::app("b", vec![]), Term::var("y")]),
                    Term::app("f", vec![Term::var("y"), Term::var("y")]),
                ),
                RewriteRule::new(
                    Term::app("a", vec![Term::app("b", vec![])]),
                    Term::app("c", vec![]),
                ),
            ],
            RewriteStrategy::Innermost,
        );
        let pairs = dependency_pairs(&trs);
        let graph = dependency_pair_graph(&trs, &pairs);

        assert_eq!(pairs.len(), 2);
        assert_eq!(graph, vec![vec![1], vec![0]]);
    }

    #[test]
    fn q_aware_innermost_dependency_graph_prunes_q_redex_source_instances() {
        let trs = Trs::new_with_strategy(
            None,
            BTreeSet::from([Variable::new("x"), Variable::new("y")]),
            vec![
                RewriteRule::new(
                    Term::app("f", vec![Term::var("x")]),
                    Term::app("h", vec![Term::var("x")]),
                ),
                RewriteRule::new(Term::app("g", vec![Term::var("y")]), Term::app("a", vec![])),
            ],
            RewriteStrategy::Innermost,
        );
        let pairs = vec![
            DependencyPair::new_for_test(
                Term::app("F#", vec![Term::var("x")]),
                Term::app("H#", vec![Term::var("x")]),
            ),
            DependencyPair::new_for_test(
                Term::app("H#", vec![Term::app("g", vec![Term::var("y")])]),
                Term::app("H#", vec![Term::var("y")]),
            ),
        ];
        let q_lhss = vec![Term::app("g", vec![Term::var("z")])];

        assert_eq!(dependency_pair_graph(&trs, &pairs)[0], vec![1]);
        assert_eq!(
            dependency_pair_graph_with_context(&trs, &pairs, Some(&q_lhss))[0],
            Vec::<usize>::new()
        );
    }

    #[test]
    fn q_aware_innermost_dependency_graph_keeps_variable_redex_uncertainty() {
        let trs = Trs::new_with_strategy(
            None,
            BTreeSet::from([Variable::new("x"), Variable::new("y")]),
            vec![
                RewriteRule::new(
                    Term::app("f", vec![Term::var("x")]),
                    Term::app("h", vec![Term::var("x")]),
                ),
                RewriteRule::new(Term::app("g", vec![Term::var("y")]), Term::app("a", vec![])),
            ],
            RewriteStrategy::Innermost,
        );
        let pairs = vec![
            DependencyPair::new_for_test(
                Term::app("F#", vec![Term::var("x")]),
                Term::app("H#", vec![Term::var("x")]),
            ),
            DependencyPair::new_for_test(
                Term::app("H#", vec![Term::var("y")]),
                Term::app("H#", vec![Term::var("y")]),
            ),
        ];
        let q_lhss = vec![Term::app("g", vec![Term::var("z")])];

        assert_eq!(
            dependency_pair_graph_with_context(&trs, &pairs, Some(&q_lhss))[0],
            vec![1]
        );
    }

    #[test]
    fn q_aware_innermost_dependency_graph_caps_defined_rhs_subterms() {
        let trs = Trs::new_with_strategy(
            None,
            BTreeSet::from([Variable::new("x"), Variable::new("y")]),
            vec![
                RewriteRule::new(
                    Term::app("f", vec![Term::var("x")]),
                    Term::app("h", vec![Term::app("g", vec![Term::var("x")])]),
                ),
                RewriteRule::new(Term::app("g", vec![Term::var("y")]), Term::app("a", vec![])),
                RewriteRule::new(
                    Term::app("h", vec![Term::app("a", vec![])]),
                    Term::app("b", vec![]),
                ),
            ],
            RewriteStrategy::Innermost,
        );
        let pairs = vec![
            DependencyPair::new_for_test(
                Term::app("F#", vec![Term::var("x")]),
                Term::app("H#", vec![Term::app("g", vec![Term::var("x")])]),
            ),
            DependencyPair::new_for_test(
                Term::app("H#", vec![Term::app("a", vec![])]),
                Term::app("H#", vec![Term::app("a", vec![])]),
            ),
        ];
        let q_lhss = vec![Term::app("g", vec![Term::var("z")])];

        assert_eq!(
            dependency_pair_graph_with_context(&trs, &pairs, Some(&q_lhss))[0],
            vec![1]
        );
    }

    #[test]
    fn innermost_q_graph_keeps_zerolist_transformed_ceta_edge() {
        let rules = vec![
            RewriteRule::new(
                Term::app(
                    "sub",
                    vec![Term::app("|0|", vec![]), Term::app("|0|", vec![])],
                ),
                Term::app("|0|", vec![]),
            ),
            RewriteRule::new(
                Term::app(
                    "sub",
                    vec![
                        Term::app("s", vec![Term::var("x")]),
                        Term::app("|0|", vec![]),
                    ],
                ),
                Term::app("s", vec![Term::var("x")]),
            ),
            RewriteRule::new(
                Term::app(
                    "sub",
                    vec![
                        Term::app("|0|", vec![]),
                        Term::app("s", vec![Term::var("x")]),
                    ],
                ),
                Term::app("|0|", vec![]),
            ),
            RewriteRule::new(
                Term::app(
                    "sub",
                    vec![
                        Term::app("s", vec![Term::var("x")]),
                        Term::app("s", vec![Term::var("y")]),
                    ],
                ),
                Term::app("sub", vec![Term::var("x"), Term::var("y")]),
            ),
        ];
        let trs = Trs::new_with_strategy(
            None,
            BTreeSet::from([
                Variable::new("x"),
                Variable::new("xs"),
                Variable::new("y"),
                Variable::new("y__n3"),
                Variable::new("y__n3__dp3"),
            ]),
            rules.clone(),
            RewriteStrategy::Innermost,
        );
        let instantiated_zero2 = DependencyPair::new_for_test(
            Term::app(
                "zero2#",
                vec![
                    Term::app("s", vec![Term::var("y")]),
                    Term::app(
                        "cons",
                        vec![
                            Term::app("s", vec![Term::var("y__n3__dp3")]),
                            Term::var("xs"),
                        ],
                    ),
                ],
            ),
            Term::app(
                "zero#",
                vec![Term::app(
                    "cons",
                    vec![
                        Term::app("s", vec![Term::var("y__n3__dp3")]),
                        Term::var("xs"),
                    ],
                )],
            ),
        );
        let narrowed_zero = DependencyPair::new_for_test(
            Term::app(
                "zero#",
                vec![Term::app(
                    "cons",
                    vec![Term::app("s", vec![Term::var("y__n3")]), Term::var("xs")],
                )],
            ),
            Term::app(
                "zero2#",
                vec![
                    Term::app("sub", vec![Term::var("y__n3"), Term::var("y__n3")]),
                    Term::app(
                        "cons",
                        vec![Term::app("s", vec![Term::var("y__n3")]), Term::var("xs")],
                    ),
                ],
            ),
        );
        let q_lhss = rules
            .iter()
            .map(|rule| rule.lhs().clone())
            .collect::<Vec<_>>();
        let pairs = vec![instantiated_zero2, narrowed_zero];
        let graph = dependency_pair_graph_with_context(&trs, &pairs, Some(&q_lhss));

        assert!(
            graph[1].contains(&0),
            "Ferrum must retain the CeTA EDG***+IEDG*** edge after transformed Q decomposition"
        );
    }

    #[test]
    fn labeled_jwteparla2_q_graph_keeps_ceta_iedg_edge() {
        let a = || Term::app("__ferrum_sl__61__", vec![]);
        let a1 =
            |label: usize, arg: Term| Term::app(format!("__ferrum_sl__6131__{label}"), vec![arg]);
        let a2 = |left: usize, right: usize, x: Term, y: Term| {
            Term::app(format!("__ferrum_sl__6132__{left}_{right}"), vec![x, y])
        };
        let a3 = |left: usize, middle: usize, right: usize, x: Term, y: Term, z: Term| {
            Term::app(
                format!("__ferrum_sl__6133__{left}_{middle}_{right}"),
                vec![x, y, z],
            )
        };
        let f = |left: usize, right: usize, x: Term, y: Term| {
            Term::app(format!("__ferrum_sl__66__{left}_{right}"), vec![x, y])
        };
        let rules = vec![
            RewriteRule::new(
                a3(1, 1, 1, a1(1, a()), a(), Term::var("x")),
                f(1, 1, Term::var("x"), f(1, 1, Term::var("x"), a())),
            ),
            RewriteRule::new(f(1, 1, a(), Term::var("y")), a1(1, Term::var("y"))),
            RewriteRule::new(
                f(1, 1, a1(0, Term::var("x0")), Term::var("y")),
                a2(0, 1, Term::var("x0"), Term::var("y")),
            ),
            RewriteRule::new(
                f(1, 1, a1(1, Term::var("x0")), Term::var("y")),
                a2(1, 1, Term::var("x0"), Term::var("y")),
            ),
            RewriteRule::new(
                f(
                    1,
                    1,
                    a2(0, 0, Term::var("x0"), Term::var("x1")),
                    Term::var("y"),
                ),
                a3(0, 0, 1, Term::var("x0"), Term::var("x1"), Term::var("y")),
            ),
            RewriteRule::new(
                f(
                    1,
                    1,
                    a2(0, 1, Term::var("x0"), Term::var("x1")),
                    Term::var("y"),
                ),
                a3(0, 1, 1, Term::var("x0"), Term::var("x1"), Term::var("y")),
            ),
            RewriteRule::new(
                f(
                    1,
                    1,
                    a2(1, 0, Term::var("x0"), Term::var("x1")),
                    Term::var("y"),
                ),
                a3(1, 0, 1, Term::var("x0"), Term::var("x1"), Term::var("y")),
            ),
            RewriteRule::new(
                f(
                    1,
                    1,
                    a2(1, 1, Term::var("x0"), Term::var("x1")),
                    Term::var("y"),
                ),
                a3(1, 1, 1, Term::var("x0"), Term::var("x1"), Term::var("y")),
            ),
        ];
        let marked_a3 = |args: Vec<Term>| Term::app("__ferrum_sl__613323__1_1_1", args);
        let marked_f = |args: Vec<Term>| Term::app("__ferrum_sl__6623__1_1", args);
        let first = DependencyPair::new_for_test(
            marked_a3(vec![
                a1(1, a()),
                a(),
                a2(1, 1, Term::var("x0"), Term::var("x1")),
            ]),
            marked_f(vec![
                a2(1, 1, Term::var("x0"), Term::var("x1")),
                a3(1, 1, 1, Term::var("x0"), Term::var("x1"), a()),
            ]),
        );
        let second = DependencyPair::new_for_test(
            marked_f(vec![
                a2(1, 1, a1(1, a()), a()),
                a2(1, 1, Term::var("z0"), Term::var("z1")),
            ]),
            marked_a3(vec![
                a1(1, a()),
                a(),
                a2(1, 1, Term::var("z0"), Term::var("z1")),
            ]),
        );
        let trs = Trs::new_with_strategy(
            None,
            BTreeSet::from([
                Variable::new("x"),
                Variable::new("x0"),
                Variable::new("x1"),
                Variable::new("y"),
            ]),
            rules,
            RewriteStrategy::Innermost,
        );
        let pairs = [first, second];

        assert!(ceta_q_iedg_edge_with_usable_rules(
            &pairs[0],
            &pairs[1],
            &[],
            trs.rules(),
            Some(trs.rules()),
        ));
        assert!(
            dependency_pair_graph_with_context(&trs, &pairs, Some(&[]))[0].contains(&1),
            "Ferrum must retain every CeTA IEDG edge after Q/LHS reduction"
        );
    }

    #[test]
    fn dependency_graph_components_tie_break_by_original_pair_order() {
        let components = vec![vec![0], vec![2], vec![1]];
        let graph = vec![
            Vec::<usize>::new(),
            Vec::<usize>::new(),
            Vec::<usize>::new(),
        ];

        assert_eq!(
            topologically_order_components(components, &graph),
            vec![vec![0], vec![1], vec![2]]
        );
    }

    #[test]
    fn dependency_graph_cache_extracts_reordered_induced_subgraph() {
        let pair = |name: &str| {
            DependencyPair::new_for_test(
                Term::app(format!("{name}#"), vec![Term::var("x")]),
                Term::app(format!("{name}#"), vec![Term::var("x")]),
            )
        };
        let first = pair("f");
        let second = pair("g");
        let third = pair("h");
        let cached_pairs = vec![first.clone(), second, third.clone()];
        let cached_graph = vec![vec![0, 1], vec![2], vec![1]];

        assert_eq!(
            induced_dependency_graph(&cached_pairs, &cached_graph, &[third, first]),
            Some(vec![vec![], vec![1]])
        );
    }

    #[test]
    fn dependency_graph_edge_cache_reuses_edges_for_expanded_pair_sets() {
        let trs = Trs::new(
            None,
            BTreeSet::from([Variable::new("x")]),
            vec![RewriteRule::new(
                Term::app("f", vec![Term::var("x")]),
                Term::app("f", vec![Term::var("x")]),
            )],
        );
        let pair = |name: &str| {
            DependencyPair::new_for_test(
                Term::app(format!("{name}#"), vec![Term::var("x")]),
                Term::app(format!("{name}#"), vec![Term::var("x")]),
            )
        };
        let first = pair("f");
        let second = pair("g");
        let third = pair("h");
        let stats = DpProofStats::default();

        let initial = cached_dependency_pair_graph_with_rules_deadline(
            &stats,
            &trs,
            trs.rules(),
            &[first.clone(), second.clone()],
            None,
            None,
            &DpStrategyCancellation::default(),
        )
        .expect("uncapped graph construction should not time out");
        assert_eq!(initial.len(), 2);
        assert_eq!(stats.graph_edge_cache.lock().unwrap().len(), 4);

        let expanded = cached_dependency_pair_graph_with_rules_deadline(
            &stats,
            &trs,
            trs.rules(),
            &[first, second, third],
            None,
            None,
            &DpStrategyCancellation::default(),
        )
        .expect("uncapped graph construction should not time out");
        assert_eq!(expanded.len(), 3);
        assert_eq!(
            stats.graph_edge_cache.lock().unwrap().len(),
            9,
            "the four existing edge decisions should be reused and only the five new edges added"
        );
    }

    #[test]
    fn ceta_q_dependency_graph_reuses_cached_edge_decisions() {
        let rule = RewriteRule::new(
            Term::app("f", vec![Term::var("x")]),
            Term::app("f", vec![Term::var("x")]),
        );
        let pair = DependencyPair::new_for_test(
            Term::app("F#", vec![Term::var("x")]),
            Term::app("F#", vec![Term::var("x")]),
        );
        let stats = DpProofStats::default();

        cached_ceta_q_dependency_pair_graph_with_rules_deadline(
            &stats,
            &[rule.clone()],
            std::slice::from_ref(&pair),
            &[rule.lhs().clone()],
            None,
            &DpStrategyCancellation::default(),
        )
        .expect("uncapped Q graph construction should not time out");
        assert_eq!(stats.graph_edge_cache.lock().unwrap().len(), 1);

        cached_ceta_q_dependency_pair_graph_with_rules_deadline(
            &stats,
            &[rule.clone()],
            &[pair],
            &[rule.lhs().clone()],
            None,
            &DpStrategyCancellation::default(),
        )
        .expect("uncapped Q graph construction should not time out");
        assert_eq!(
            stats.graph_edge_cache.lock().unwrap().len(),
            1,
            "repeating the SCT Q graph should reuse the cached Q edge"
        );
    }

    #[test]
    fn q_graph_intersects_iedg_with_active_rule_nonreachability() {
        let zero = || Term::app("zero", vec![]);
        let yes = || Term::app("yes", vec![]);
        let no = || Term::app("no", vec![]);
        let succ = |t| Term::app("succ", vec![t]);
        let ge = |a, b| Term::app("compare", vec![a, b]);
        let marked = |t| Term::app("call#", vec![t]);
        let x = Term::var("x");
        let rules = vec![
            RewriteRule::new(ge(zero(), zero()), yes()),
            RewriteRule::new(ge(zero(), succ(zero())), no()),
            RewriteRule::new(ge(zero(), succ(succ(x.clone()))), ge(zero(), succ(x.clone()))),
        ];
        let source = DependencyPair::new_for_test(marked(x.clone()), marked(ge(zero(), succ(x.clone()))));
        let target = DependencyPair::new_for_test(marked(yes()), marked(yes()));
        let mut graph = cached_ceta_q_dependency_pair_graph_with_rules_deadline(
            &DpProofStats::default(), &rules, &[source.clone(), target.clone()],
            &rules.iter().map(|r| r.lhs().clone()).collect::<Vec<_>>(), None,
            &DpStrategyCancellation::default(),
        ).unwrap();
        assert!(graph[0].contains(&1), "the established graph policy remains unchanged");
        let mut sct_graph = graph.clone();
        refine_ceta_q_iedg_with_pair_local_rules(&rules, &[source.clone(), target.clone()],
            &rules.iter().map(|r| r.lhs().clone()).collect::<Vec<_>>(), &mut sct_graph, None,
            &DpStrategyCancellation::default()).unwrap();
        assert!(!sct_graph[0].contains(&1), "pair-local IEDG refinement is available to SCT without TCAP intersection");
        refine_ceta_q_dependency_graph(&rules, &[source.clone(), target.clone()],
            &rules.iter().map(|r| r.lhs().clone()).collect::<Vec<_>>(), &mut graph, None,
            &DpStrategyCancellation::default()).unwrap();
        assert!(!graph[0].contains(&1), "a positive successor cannot reach the zero branch");
        let mut no_q = cached_ceta_q_dependency_pair_graph_with_rules_deadline(
            &DpProofStats::default(), &rules, &[source.clone(), target.clone()], &[], None,
            &DpStrategyCancellation::default(),
        ).unwrap();
        let before = no_q.clone();
        refine_ceta_q_iedg_with_pair_local_rules(&rules, &[source.clone(), target.clone()], &[], &mut no_q,
            None, &DpStrategyCancellation::default()).unwrap();
        assert_eq!(no_q, before, "SCT must retain all edges when Q coverage is absent");
        refine_ceta_q_dependency_graph(&rules, &[source.clone(), target.clone()], &[], &mut no_q,
            None, &DpStrategyCancellation::default()).unwrap();
        assert!(no_q[0].contains(&1), "pair-local usable rules require the Q coverage guard");
        // The decision must use R: adding a genuinely applicable rule makes
        // the edge realizable even though the original rules are unchanged.
        let mut extended = rules;
        extended.push(RewriteRule::new(ge(zero(), succ(x)), yes()));
        let mut graph = cached_ceta_q_dependency_pair_graph_with_rules_deadline(
            &DpProofStats::default(), &extended, &[source.clone(), target.clone()],
            &extended.iter().map(|r| r.lhs().clone()).collect::<Vec<_>>(), None,
            &DpStrategyCancellation::default(),
        ).unwrap();
        refine_ceta_q_dependency_graph(&extended, &[source, target],
            &extended.iter().map(|r| r.lhs().clone()).collect::<Vec<_>>(), &mut graph,
            None, &DpStrategyCancellation::default()).unwrap();
        assert!(graph[0].contains(&1));
        assert_eq!(DpStrategy::parse("graph-refined").unwrap(),
            DpStrategy::Processor(DpStrategyProcessor::RefinedDependencyGraph));
    }

    #[test]
    fn innermost_dependency_graph_keeps_single_pair_self_edges_for_ceta() {
        let trs = Trs::new_with_strategy(
            None,
            BTreeSet::from([Variable::new("x"), Variable::new("y")]),
            vec![
                RewriteRule::new(
                    Term::app(
                        "f",
                        vec![
                            Term::app("g", vec![Term::var("x")]),
                            Term::app("s", vec![Term::app("|0|", vec![])]),
                            Term::var("y"),
                        ],
                    ),
                    Term::app(
                        "f",
                        vec![
                            Term::app("g", vec![Term::app("s", vec![Term::app("|0|", vec![])])]),
                            Term::var("y"),
                            Term::app("g", vec![Term::var("x")]),
                        ],
                    ),
                ),
                RewriteRule::new(
                    Term::app("g", vec![Term::app("s", vec![Term::var("x")])]),
                    Term::app("s", vec![Term::app("g", vec![Term::var("x")])]),
                ),
                RewriteRule::new(
                    Term::app("g", vec![Term::app("|0|", vec![])]),
                    Term::app("|0|", vec![]),
                ),
            ],
            RewriteStrategy::Innermost,
        );
        let pairs = complete_dependency_pairs(&trs);
        let graph = dependency_pair_graph(&trs, &pairs);

        assert_eq!(pairs.len(), 4);
        assert!(graph[0].contains(&0));
    }

    #[test]
    fn innermost_dependency_graph_separates_ag01_4_14_components() {
        let trs = Trs::new_with_strategy(
            None,
            BTreeSet::from([Variable::new("x")]),
            vec![
                RewriteRule::new(
                    Term::app(
                        "f",
                        vec![
                            Term::app("g", vec![Term::var("x")]),
                            Term::app("s", vec![Term::app("|0|", vec![])]),
                        ],
                    ),
                    Term::app(
                        "f",
                        vec![
                            Term::app("g", vec![Term::var("x")]),
                            Term::app("g", vec![Term::var("x")]),
                        ],
                    ),
                ),
                RewriteRule::new(
                    Term::app("g", vec![Term::app("s", vec![Term::var("x")])]),
                    Term::app("s", vec![Term::app("g", vec![Term::var("x")])]),
                ),
                RewriteRule::new(
                    Term::app("g", vec![Term::app("|0|", vec![])]),
                    Term::app("|0|", vec![]),
                ),
            ],
            RewriteStrategy::Innermost,
        );
        let pairs = complete_dependency_pairs(&trs);
        let graph = dependency_pair_graph(&trs, &pairs);

        assert_eq!(pairs.len(), 3);
        assert_eq!(graph, vec![vec![0, 1], vec![2], vec![2]]);
    }

    #[test]
    fn innermost_dependency_graph_separates_ag01_4_16_components() {
        let trs = Trs::new_with_strategy(
            None,
            BTreeSet::from([Variable::new("x")]),
            vec![
                RewriteRule::new(
                    Term::app(
                        "f",
                        vec![
                            Term::app("s", vec![Term::app("|0|", vec![])]),
                            Term::app("g", vec![Term::var("x")]),
                        ],
                    ),
                    Term::app(
                        "f",
                        vec![Term::var("x"), Term::app("g", vec![Term::var("x")])],
                    ),
                ),
                RewriteRule::new(
                    Term::app("g", vec![Term::app("s", vec![Term::var("x")])]),
                    Term::app("g", vec![Term::var("x")]),
                ),
            ],
            RewriteStrategy::Innermost,
        );
        let pairs = complete_dependency_pairs(&trs);
        let graph = dependency_pair_graph(&trs, &pairs);

        assert_eq!(pairs.len(), 3);
        assert_eq!(graph, vec![vec![0, 1], vec![2], vec![2]]);
    }

    #[test]
    fn initial_innermost_q_graph_separates_beerendonk_cond_components() {
        let trs = Trs::new_with_strategy(
            None,
            BTreeSet::from([Variable::new("x")]),
            vec![
                RewriteRule::new(
                    Term::app("cond", vec![Term::app("true", vec![]), Term::var("x")]),
                    Term::app(
                        "cond",
                        vec![
                            Term::app("odd", vec![Term::var("x")]),
                            Term::app("p", vec![Term::var("x")]),
                        ],
                    ),
                ),
                RewriteRule::new(
                    Term::app("odd", vec![Term::app("|0|", vec![])]),
                    Term::app("false", vec![]),
                ),
                RewriteRule::new(
                    Term::app("odd", vec![Term::app("s", vec![Term::app("|0|", vec![])])]),
                    Term::app("true", vec![]),
                ),
                RewriteRule::new(
                    Term::app(
                        "odd",
                        vec![Term::app("s", vec![Term::app("s", vec![Term::var("x")])])],
                    ),
                    Term::app("odd", vec![Term::var("x")]),
                ),
                RewriteRule::new(
                    Term::app("p", vec![Term::app("|0|", vec![])]),
                    Term::app("|0|", vec![]),
                ),
                RewriteRule::new(
                    Term::app("p", vec![Term::app("s", vec![Term::var("x")])]),
                    Term::var("x"),
                ),
            ],
            RewriteStrategy::Innermost,
        );

        let proof = solve_dependency_pairs(&trs, &DpOptions::default())
            .expect("initial Q-aware graph should expose provable components");

        assert_eq!(proof.initial_pairs, 4);
        assert_eq!(proof.component_proofs.len(), 4);
        assert_eq!(
            proof
                .component_proofs
                .iter()
                .filter(|component| component.proved)
                .count(),
            2
        );
    }

    #[test]
    fn innermost_dependency_graph_separates_ag01_4_15_components() {
        let trs = Trs::new_with_strategy(
            None,
            BTreeSet::from([Variable::new("x"), Variable::new("y"), Variable::new("z")]),
            vec![
                RewriteRule::new(
                    Term::app(
                        "f",
                        vec![
                            Term::app("|0|", vec![]),
                            Term::app("|1|", vec![]),
                            Term::app("g", vec![Term::var("x"), Term::var("y")]),
                            Term::var("z"),
                        ],
                    ),
                    Term::app(
                        "f",
                        vec![
                            Term::app("g", vec![Term::var("x"), Term::var("y")]),
                            Term::app("g", vec![Term::var("x"), Term::var("y")]),
                            Term::app("g", vec![Term::var("x"), Term::var("y")]),
                            Term::app("h", vec![Term::var("x")]),
                        ],
                    ),
                ),
                RewriteRule::new(
                    Term::app(
                        "g",
                        vec![Term::app("|0|", vec![]), Term::app("|1|", vec![])],
                    ),
                    Term::app("|0|", vec![]),
                ),
                RewriteRule::new(
                    Term::app(
                        "g",
                        vec![Term::app("|0|", vec![]), Term::app("|1|", vec![])],
                    ),
                    Term::app("|1|", vec![]),
                ),
                RewriteRule::new(
                    Term::app(
                        "h",
                        vec![Term::app("g", vec![Term::var("x"), Term::var("y")])],
                    ),
                    Term::app("h", vec![Term::var("x")]),
                ),
            ],
            RewriteStrategy::Innermost,
        );
        let pairs = complete_dependency_pairs(&trs);
        let graph = dependency_pair_graph(&trs, &pairs);

        assert_eq!(pairs.len(), 4);
        assert_eq!(graph, vec![vec![0, 1, 2], Vec::new(), vec![3], vec![3]]);
    }

    #[test]
    fn innermost_dependency_graph_separates_ag01_4_26_minus_if_component() {
        let trs = Trs::new_with_strategy(
            None,
            BTreeSet::from([Variable::new("x"), Variable::new("y")]),
            vec![
                RewriteRule::new(
                    Term::app("p", vec![Term::app("|0|", vec![])]),
                    Term::app("|0|", vec![]),
                ),
                RewriteRule::new(
                    Term::app("p", vec![Term::app("s", vec![Term::var("x")])]),
                    Term::var("x"),
                ),
                RewriteRule::new(
                    Term::app("le", vec![Term::app("|0|", vec![]), Term::var("y")]),
                    Term::app("true", vec![]),
                ),
                RewriteRule::new(
                    Term::app(
                        "le",
                        vec![
                            Term::app("s", vec![Term::var("x")]),
                            Term::app("|0|", vec![]),
                        ],
                    ),
                    Term::app("false", vec![]),
                ),
                RewriteRule::new(
                    Term::app(
                        "le",
                        vec![
                            Term::app("s", vec![Term::var("x")]),
                            Term::app("s", vec![Term::var("y")]),
                        ],
                    ),
                    Term::app("le", vec![Term::var("x"), Term::var("y")]),
                ),
                RewriteRule::new(
                    Term::app("minus", vec![Term::var("x"), Term::var("y")]),
                    Term::app(
                        "if",
                        vec![
                            Term::app("le", vec![Term::var("x"), Term::var("y")]),
                            Term::var("x"),
                            Term::var("y"),
                        ],
                    ),
                ),
                RewriteRule::new(
                    Term::app(
                        "if",
                        vec![Term::app("true", vec![]), Term::var("x"), Term::var("y")],
                    ),
                    Term::app("|0|", vec![]),
                ),
                RewriteRule::new(
                    Term::app(
                        "if",
                        vec![Term::app("false", vec![]), Term::var("x"), Term::var("y")],
                    ),
                    Term::app(
                        "s",
                        vec![Term::app(
                            "minus",
                            vec![Term::app("p", vec![Term::var("x")]), Term::var("y")],
                        )],
                    ),
                ),
            ],
            RewriteStrategy::Innermost,
        );
        let pairs = dependency_pairs(&trs);
        let graph = dependency_pair_graph(&trs, &pairs);
        let minus_to_if = pairs
            .iter()
            .position(|pair| {
                pair.lhs()
                    .root_symbol()
                    .is_some_and(|symbol| symbol.as_str() == "minus#")
                    && pair
                        .rhs()
                        .root_symbol()
                        .is_some_and(|symbol| symbol.as_str() == "if#")
            })
            .expect("minus# to if# DP");
        let if_to_minus = pairs
            .iter()
            .position(|pair| {
                pair.lhs()
                    .root_symbol()
                    .is_some_and(|symbol| symbol.as_str() == "if#")
                    && pair
                        .rhs()
                        .root_symbol()
                        .is_some_and(|symbol| symbol.as_str() == "minus#")
            })
            .expect("if# to minus# DP");
        let if_to_p = pairs
            .iter()
            .position(|pair| {
                pair.lhs()
                    .root_symbol()
                    .is_some_and(|symbol| symbol.as_str() == "if#")
                    && pair
                        .rhs()
                        .root_symbol()
                        .is_some_and(|symbol| symbol.as_str() == "p#")
            })
            .expect("if# to p# DP");

        assert_eq!(pairs.len(), 5);
        assert!(graph[minus_to_if].contains(&if_to_minus));
        assert!(graph[if_to_minus].contains(&minus_to_if));
        assert!(graph[if_to_p].is_empty());
    }

    #[test]
    fn innermost_dependency_graph_keeps_ag01_4_25_repeated_variable_self_edge_for_ceta() {
        let trs = Trs::new_with_strategy(
            None,
            BTreeSet::from([Variable::new("x")]),
            vec![
                RewriteRule::new(
                    Term::app("f", vec![Term::var("x"), Term::var("x")]),
                    Term::app(
                        "f",
                        vec![Term::app("g", vec![Term::var("x")]), Term::var("x")],
                    ),
                ),
                RewriteRule::new(
                    Term::app("g", vec![Term::var("x")]),
                    Term::app("s", vec![Term::var("x")]),
                ),
            ],
            RewriteStrategy::Innermost,
        );
        let pairs = dependency_pairs(&trs);
        let graph = dependency_pair_graph(&trs, &pairs);
        let recursive = pairs
            .iter()
            .position(|pair| {
                pair.lhs()
                    .root_symbol()
                    .is_some_and(|symbol| symbol.as_str() == "f#")
                    && pair
                        .rhs()
                        .root_symbol()
                        .is_some_and(|symbol| symbol.as_str() == "f#")
            })
            .expect("recursive f# pair");

        assert!(graph[recursive].contains(&recursive));
    }

    #[test]
    fn innermost_dependency_graph_keeps_ag01_4_29_half_times_edge_for_ceta() {
        let trs = Trs::new_with_strategy(
            None,
            BTreeSet::from([Variable::new("x"), Variable::new("y")]),
            vec![
                RewriteRule::new(
                    Term::app("even", vec![Term::app("|0|", vec![])]),
                    Term::app("true", vec![]),
                ),
                RewriteRule::new(
                    Term::app("even", vec![Term::app("s", vec![Term::app("|0|", vec![])])]),
                    Term::app("false", vec![]),
                ),
                RewriteRule::new(
                    Term::app(
                        "even",
                        vec![Term::app("s", vec![Term::app("s", vec![Term::var("x")])])],
                    ),
                    Term::app("even", vec![Term::var("x")]),
                ),
                RewriteRule::new(
                    Term::app("half", vec![Term::app("|0|", vec![])]),
                    Term::app("|0|", vec![]),
                ),
                RewriteRule::new(
                    Term::app(
                        "half",
                        vec![Term::app("s", vec![Term::app("s", vec![Term::var("x")])])],
                    ),
                    Term::app("s", vec![Term::app("half", vec![Term::var("x")])]),
                ),
                RewriteRule::new(
                    Term::app("plus", vec![Term::app("|0|", vec![]), Term::var("y")]),
                    Term::var("y"),
                ),
                RewriteRule::new(
                    Term::app(
                        "plus",
                        vec![Term::app("s", vec![Term::var("x")]), Term::var("y")],
                    ),
                    Term::app(
                        "s",
                        vec![Term::app("plus", vec![Term::var("x"), Term::var("y")])],
                    ),
                ),
                RewriteRule::new(
                    Term::app("times", vec![Term::app("|0|", vec![]), Term::var("y")]),
                    Term::app("|0|", vec![]),
                ),
                RewriteRule::new(
                    Term::app(
                        "times",
                        vec![Term::app("s", vec![Term::var("x")]), Term::var("y")],
                    ),
                    Term::app(
                        "if_times",
                        vec![
                            Term::app("even", vec![Term::app("s", vec![Term::var("x")])]),
                            Term::app("s", vec![Term::var("x")]),
                            Term::var("y"),
                        ],
                    ),
                ),
                RewriteRule::new(
                    Term::app(
                        "if_times",
                        vec![
                            Term::app("true", vec![]),
                            Term::app("s", vec![Term::var("x")]),
                            Term::var("y"),
                        ],
                    ),
                    Term::app(
                        "plus",
                        vec![
                            Term::app(
                                "times",
                                vec![
                                    Term::app("half", vec![Term::app("s", vec![Term::var("x")])]),
                                    Term::var("y"),
                                ],
                            ),
                            Term::app(
                                "times",
                                vec![
                                    Term::app("half", vec![Term::app("s", vec![Term::var("x")])]),
                                    Term::var("y"),
                                ],
                            ),
                        ],
                    ),
                ),
                RewriteRule::new(
                    Term::app(
                        "if_times",
                        vec![
                            Term::app("false", vec![]),
                            Term::app("s", vec![Term::var("x")]),
                            Term::var("y"),
                        ],
                    ),
                    Term::app(
                        "plus",
                        vec![
                            Term::var("y"),
                            Term::app("times", vec![Term::var("x"), Term::var("y")]),
                        ],
                    ),
                ),
            ],
            RewriteStrategy::Innermost,
        );
        let pairs = dependency_pairs(&trs);
        let graph = dependency_pair_graph(&trs, &pairs);
        let from = pairs
            .iter()
            .position(|pair| {
                pair.lhs()
                    == &Term::app(
                        "if_times#",
                        vec![
                            Term::app("true", vec![]),
                            Term::app("s", vec![Term::var("x")]),
                            Term::var("y"),
                        ],
                    )
                    && pair.rhs()
                        == &Term::app(
                            "times#",
                            vec![
                                Term::app("half", vec![Term::app("s", vec![Term::var("x")])]),
                                Term::var("y"),
                            ],
                        )
            })
            .expect("source DP");
        let to = pairs
            .iter()
            .position(|pair| {
                pair.lhs()
                    == &Term::app(
                        "times#",
                        vec![Term::app("s", vec![Term::var("x")]), Term::var("y")],
                    )
            })
            .expect("target DP");

        assert!(graph[from].contains(&to));
    }

    #[test]
    fn smt_symbol_names_are_injective_for_operator_symbols() {
        assert_ne!(sanitize_smt_name("*"), sanitize_smt_name("+"));
        assert_ne!(sanitize_smt_name("*"), sanitize_smt_name("*#"));
        assert_ne!(smt_c("*"), smt_c("+"));
        assert_ne!(smt_a("*", 0), smt_a("+", 0));
    }

    #[test]
    fn quadratic_polynomial_removes_der95_13_distributivity_pairs() {
        if !command_exists("z3") && !command_exists("cvc5") {
            return;
        }
        let variables =
            BTreeSet::from([Variable::new("x"), Variable::new("y"), Variable::new("z")]);
        let multiply = |left, right| Term::app("*", vec![left, right]);
        let plus = |left, right| Term::app("+", vec![left, right]);
        let x = || Term::var("x");
        let y = || Term::var("y");
        let z = || Term::var("z");
        let trs = Trs::new(
            None,
            variables,
            vec![
                RewriteRule::new(
                    multiply(x(), plus(y(), z())),
                    plus(multiply(x(), y()), multiply(x(), z())),
                ),
                RewriteRule::new(
                    multiply(plus(y(), z()), x()),
                    plus(multiply(x(), y()), multiply(x(), z())),
                ),
                RewriteRule::new(
                    multiply(multiply(x(), y()), z()),
                    multiply(x(), multiply(y(), z())),
                ),
                RewriteRule::new(plus(plus(x(), y()), z()), plus(x(), plus(y(), z()))),
            ],
        );
        let pairs = dependency_pairs(&trs);
        let graph = dependency_pair_graph(&trs, &pairs);
        let component = strongly_connected_components(&graph)
            .into_iter()
            .find(|component| component.len() == 6)
            .expect("six-pair multiplication SCC");
        let component_pairs = component
            .into_iter()
            .map(|index| pairs[index].clone())
            .collect::<Vec<_>>();
        let usable = usable_rules(&trs, &component_pairs);
        let options = DpOptions {
            max_polynomial_constant: 2,
            max_polynomial_coefficient: 1,
            ..DpOptions::default()
        };

        let interpretation =
            synthesize_quadratic_polynomial_with_smt(&component_pairs, &usable, &options, None)
                .expect("quadratic interpretation");
        let removal = checked_component_removal_by_natural_polynomial(
            &component_pairs,
            &usable,
            &interpretation,
            DpSearchBackend::Smt,
            None,
        )
        .expect("validated quadratic reduction pair");

        assert_eq!(removal.strict_pair_indices.len(), 4);
        assert_eq!(interpretation["*"].quadratic[0][1], 1);
        assert_eq!(interpretation["*#"].quadratic[0][1], 1);
        assert_eq!(interpretation["+"].constant, 1);
    }

    #[test]
    fn arctic_matrix_strictness_covers_every_row_like_ceta() {
        let x = Term::var("x");
        let fx = Term::app("f", vec![x.clone()]);
        let mut interpretations = BTreeMap::from([(
            "f".to_string(),
            MatrixInterpretation {
                constant: vec![0, i64::MIN],
                coefficients: vec![vec![vec![0, i64::MIN], vec![i64::MIN, 0]]],
            },
        )]);

        assert!(weakly_decreases_by_arctic_matrix(
            &fx,
            &x,
            &interpretations,
            2
        ));
        assert!(!strictly_decreases_by_arctic_matrix(
            &fx,
            &x,
            &interpretations,
            2
        ));

        interpretations.get_mut("f").unwrap().coefficients[0][0][0] = 1;
        assert!(!strictly_decreases_by_arctic_matrix(
            &fx,
            &x,
            &interpretations,
            2
        ));

        interpretations.get_mut("f").unwrap().coefficients[0][1][1] = 1;
        assert!(strictly_decreases_by_arctic_matrix(
            &fx,
            &x,
            &interpretations,
            2
        ));
    }

    #[test]
    fn split_probe_exposes_both_children_with_exact_weak_pair_context() {
        let trs = Trs::new(None, BTreeSet::new(), Vec::new());
        let pairs = vec![
            DependencyPair::new_for_test(Term::app("f#", Vec::new()), Term::app("f#", Vec::new())),
            DependencyPair::new_for_test(Term::app("g#", Vec::new()), Term::app("g#", Vec::new())),
        ];
        let options = DpOptions::default();
        let strategy = DpStrategy::Processor(DpStrategyProcessor::Split);

        let (_, residuals) =
            crate::proving::probe_dp_atom_state(&trs, pairs, None, true, &options, &strategy, None)
                .expect("split probe should expose two residual obligations");

        assert_eq!(residuals.len(), 2);
        let (_, first_pairs, first_weak_pairs, _) = parsed_dp_probe_residual(&residuals[0]);
        let (_, second_pairs, second_weak_pairs, _) = parsed_dp_probe_residual(&residuals[1]);
        assert_eq!(first_pairs.len(), 2);
        assert_eq!(first_weak_pairs.len(), 1);
        assert_eq!(second_pairs.len(), 1);
        assert!(second_weak_pairs.is_empty());
    }

    #[test]
    fn q_monotonic_matrix_can_delete_innermost_rule_without_deleting_pair() {
        let zero = || Term::app("|0|", Vec::new());
        let unary = |symbol: &str, argument| Term::app(symbol, vec![argument]);
        let pair = DependencyPair::new_for_test(
            Term::app(
                "f#",
                vec![
                    unary("s", Term::var("x")),
                    Term::var("y"),
                    Term::app("b", Vec::new()),
                ],
            ),
            Term::app(
                "f#",
                vec![
                    unary("g", unary("h", Term::var("x"))),
                    Term::var("y"),
                    unary("i", Term::var("y")),
                ],
            ),
        );
        let rules = vec![
            RewriteRule::new(
                unary("g", unary("h", Term::var("x"))),
                unary("g", Term::var("x")),
            ),
            RewriteRule::new(
                unary("g", unary("s", Term::var("x"))),
                unary("s", Term::var("x")),
            ),
            RewriteRule::new(unary("g", zero()), unary("s", zero())),
            RewriteRule::new(unary("h", zero()), Term::app("a", Vec::new())),
            RewriteRule::new(unary("i", zero()), Term::app("b", Vec::new())),
            RewriteRule::new(
                unary("i", unary("s", Term::var("y"))),
                unary("i", Term::var("y")),
            ),
        ];
        let scalar = |constant, coefficients: Vec<i64>| MatrixInterpretation {
            constant: vec![constant],
            coefficients: coefficients
                .into_iter()
                .map(|coefficient| vec![vec![coefficient]])
                .collect(),
        };
        let interpretations = BTreeMap::from([
            ("|0|".to_string(), scalar(2, vec![])),
            ("f#".to_string(), scalar(0, vec![2, 0, 0])),
            ("a".to_string(), scalar(1, vec![])),
            ("b".to_string(), scalar(0, vec![])),
            ("g".to_string(), scalar(0, vec![2])),
            ("h".to_string(), scalar(0, vec![1])),
            ("i".to_string(), scalar(0, vec![0])),
            ("s".to_string(), scalar(0, vec![2])),
        ]);

        let removal = checked_q_monotonic_matrix_rule_removal(
            &[pair.clone()],
            &rules,
            &interpretations,
            DpSearchBackend::Sat,
        )
        .expect("validated Q-monotonic matrix removal");
        assert!(removal.strict_pair_indices.is_empty());
        assert_eq!(removal.strict_rule_indices, vec![3]);
        use crate::proving::processors::{ProblemState, ProcessorResult, WorklistProcessor};
        use crate::proving::processors::dp::{DpProblemState, ReductionPairProcessor};
        let trs = Trs::new_with_strategy(None, Default::default(), rules.clone(), RewriteStrategy::Innermost);
        let state = ProblemState::DependencyPairs(DpProblemState::ordinary(trs, vec![pair], DpOptions::default()));
        // Zero is the broad search; 1 addresses the sole DP; 2..7 address R.
        let DpStrategy::Processor(atom) = DpStrategy::parse("matrix(dimension=1,max-constant=2,max-coefficient=2,max-symbols=16,max-arity=4,candidate=5)").unwrap() else { panic!("atomic strategy"); };
        let ProcessorResult::Applied(application) = (ReductionPairProcessor { processor: atom, deadline: Some(Instant::now()+Duration::from_secs(10)) }).apply(&state) else { panic!("selected Q-rule search should apply"); };
        let [ProblemState::DependencyPairs(child)] = application.residuals.as_slice() else { panic!("one residual expected"); };
        assert_eq!(child.pairs.len(), 1);
        assert!(!child.trs.rules().contains(&rules[3]));
        let DpStrategy::Processor(atom) = DpStrategy::parse("matrix(dimension=1,max-constant=2,max-coefficient=2,candidate=100)").unwrap() else { panic!("atomic strategy"); };
        assert!(matches!((ReductionPairProcessor { processor: atom, deadline: None }).apply(&state), ProcessorResult::Inapplicable));
    }
}
