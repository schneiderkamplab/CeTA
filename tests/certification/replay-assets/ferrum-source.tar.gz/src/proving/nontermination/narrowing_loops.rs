//! Bounded narrowing and mixed rewrite/narrow loop search.

use super::*;

#[cfg(test)]
mod scheduling_tests {
    use super::*;

    #[test]
    fn separable_argument_loops_reconstruct_actual_marked_steps() {
        for [p, c, d, s] in [["p#", "c", "d", "s"], ["again#", "ready", "work", "grow"]] {
            let x = Term::var("x");
            let y = Term::var("y");
            let app = |name: &str, t| Term::app(name, vec![t]);
            let trs = Trs::new(
                None,
                BTreeSet::from([Variable::new("x"), Variable::new("y")]),
                vec![RewriteRule::new(
                    app(d, x.clone()),
                    app(c, app(s, x.clone())),
                )],
            );
            let pairs = vec![DependencyPair::new_for_test(
                Term::app(p, vec![app(c, x.clone()), app(c, y.clone())]),
                Term::app(p, vec![app(d, x), app(d, y)]),
            )];
            let proof = separable_dp_loop_proof(
                &trs,
                &pairs,
                Some(Instant::now() + Duration::from_secs(2)),
            )
            .unwrap();
            let state = crate::proving::processors::dp::DpProblemState::ordinary(
                trs,
                pairs,
                crate::proving::dependency_pairs::DpOptions::default(),
            );
            let xml = crate::cert::write_cpf3_dp_nontermination_state(&state, &proof).unwrap();
            let path = std::env::temp_dir()
                .join(format!("ferrum-separable-loop-{}.xml", std::process::id()));
            std::fs::write(&path, xml).unwrap();
            let checker =
                std::env::var("CETA_CSR_BIN").unwrap_or_else(|_| "../CeTA-CSR/ceta".into());
            let output = std::process::Command::new(checker)
                .arg(&path)
                .output()
                .unwrap();
            let _ = std::fs::remove_file(path);
            assert!(
                output.status.success()
                    && String::from_utf8_lossy(&output.stdout).trim() == "CERTIFIED",
                "{}{}",
                String::from_utf8_lossy(&output.stdout),
                String::from_utf8_lossy(&output.stderr)
            );
            assert!(
                separable_dp_loop_proof(&state.trs, &state.pairs, Some(Instant::now())).is_none()
            );
        }
    }

    #[test]
    fn fair_loop_lane_rechecks_its_witness_and_respects_deadlines() {
        let x = Term::var("x");
        let trs = Trs::new(
            None,
            BTreeSet::from([Variable::new("x")]),
            vec![
                RewriteRule::new(
                    Term::app("f", vec![x.clone()]),
                    Term::app("g", vec![x.clone()]),
                ),
                RewriteRule::new(Term::app("g", vec![x.clone()]), Term::app("f", vec![x])),
            ],
        );
        let pairs = dependency_pairs(&trs);
        assert!(fair_dp_loop_proof(&trs, &pairs, Some(Instant::now())).is_none());
        let mut proof =
            fair_dp_loop_proof(&trs, &pairs, Some(Instant::now() + Duration::from_secs(2)))
                .unwrap();
        while let DpNonterminationProof::DpRuleRemoval { proof: nested, .. } = proof {
            proof = *nested;
        }
        let DpNonterminationProof::Loop(proof) = proof else {
            panic!()
        };
        assert!(check_mixed_dp_loop_proof(&trs, &pairs, &proof));
        assert!(
            crate::proving::dependency_pairs::DpStrategy::parse("nontermination(dp-fair-loop)")
                .is_ok()
        );
    }

    #[test]
    fn fork_seed_search_uses_live_rules_under_renaming() {
        for [p, q, fork, seed, a, b] in [
            ["p", "q", "fork", "seed", "a", "b"],
            ["again", "join", "choose", "zero", "left", "right"],
        ] {
            let c = |name| Term::app(name, vec![]);
            let x = Term::var("x");
            let source = Term::app(fork, vec![c(seed)]);
            let rules = vec![
                RewriteRule::new(source.clone(), c(a)),
                RewriteRule::new(source.clone(), c(b)),
                RewriteRule::new(
                    Term::app(p, vec![x.clone()]),
                    Term::app(q, vec![x.clone(), x]),
                ),
                RewriteRule::new(Term::app(q, vec![c(a), c(b)]), Term::app(p, vec![source])),
            ];
            let trs = Trs::new(None, BTreeSet::from([Variable::new("x")]), rules);
            let pairs = dependency_pairs(&trs);
            let proof =
                fork_dp_loop_proof(&trs, &pairs, Some(Instant::now() + Duration::from_secs(2)))
                    .expect("duplicated argument chooses two different live reducts");
            let state = crate::proving::processors::dp::DpProblemState::ordinary(
                trs,
                pairs,
                crate::proving::dependency_pairs::DpOptions::default(),
            );
            let xml = crate::cert::write_cpf3_dp_nontermination_state(&state, &proof).unwrap();
            let path =
                std::env::temp_dir().join(format!("ferrum-fork-loop-{}.xml", std::process::id()));
            std::fs::write(&path, xml).unwrap();
            let checker =
                std::env::var("CETA_CSR_BIN").unwrap_or_else(|_| "../CeTA-CSR/ceta".into());
            let output = std::process::Command::new(checker)
                .arg(&path)
                .output()
                .unwrap();
            let _ = std::fs::remove_file(path);
            assert!(
                output.status.success()
                    && String::from_utf8_lossy(&output.stdout).trim() == "CERTIFIED",
                "{}{}",
                String::from_utf8_lossy(&output.stdout),
                String::from_utf8_lossy(&output.stderr)
            );
            let mut mutant = state.trs.rules().to_vec();
            mutant.remove(1);
            let mutant = Trs::new(None, state.trs.variables().clone(), mutant);
            assert!(
                fork_dp_loop_proof(
                    &mutant,
                    &dependency_pairs(&mutant),
                    Some(Instant::now() + Duration::from_secs(1))
                )
                .is_none()
            );
        }
    }

    #[test]
    fn symbolic_loop_combines_shared_argument_refinement_with_growth() {
        let x = Term::var("x");
        let z = Term::var("z");
        let w = Term::var("w");
        let rule = RewriteRule::new(
            Term::app("p", vec![x.clone(), x, z.clone(), w.clone()]),
            Term::app(
                "p",
                vec![
                    w.clone(),
                    Term::app("a", vec![]),
                    Term::app("grow", vec![z]),
                    w,
                ],
            ),
        );
        let trs = Trs::new(None, rule.lhs().variables(), vec![rule]);
        let pairs = dependency_pairs(&trs);
        let DpNonterminationProof::Loop(proof) = dp_symbolic_loop_proof(&trs, &pairs, None)
            .expect("shared constraints plus a growing argument")
        else {
            panic!()
        };
        assert!(check_mixed_dp_loop_proof(&trs, &pairs, &proof));
        assert!(!proof.substitution.is_empty());
    }

    #[test]
    fn symbolic_deep_pass_narrows_variables_exposed_by_marked_steps() {
        let c = |name| Term::app(name, vec![]);
        let x = Term::var("x");
        let trs = Trs::new(
            None,
            BTreeSet::from([Variable::new("x")]),
            vec![
                RewriteRule::new(c("seed"), c("left")),
                RewriteRule::new(c("seed"), c("right")),
                RewriteRule::new(
                    Term::app("f", vec![x.clone()]),
                    Term::app("g", vec![x.clone(), x]),
                ),
                RewriteRule::new(
                    Term::app("g", vec![c("left"), c("right")]),
                    Term::app("f", vec![c("seed")]),
                ),
            ],
        );
        dp_symbolic_loop_proof(&trs, &dependency_pairs(&trs), None)
            .expect("narrow a duplicated variable to the common predecessor");
    }

    #[test]
    fn backward_endpoint_key_preserves_cross_endpoint_sharing() {
        let app = |a, b| Term::app("f", vec![Term::var(a), Term::var(b)]);
        assert_eq!(
            backward_endpoint_key(&app("x", "y"), &app("y", "x")),
            backward_endpoint_key(&app("fresh1", "fresh2"), &app("fresh2", "fresh1")),
        );
        assert_ne!(
            backward_endpoint_key(&app("x", "y"), &app("y", "x")),
            backward_endpoint_key(&app("x", "y"), &app("z", "x")),
        );
    }

    #[test]
    fn backward_loop_can_cross_more_than_eight_rewrite_steps() {
        let constant = |s: String| Term::app(s, vec![]);
        let mut rules = Vec::new();
        for side in ["left", "right"] {
            rules.push(RewriteRule::new(
                constant("seed".into()),
                constant(format!("{side}4")),
            ));
            for index in (1..=4).rev() {
                rules.push(RewriteRule::new(
                    constant(format!("{side}{index}")),
                    constant(format!("{side}{}", index - 1)),
                ));
            }
        }
        let x = Term::var("x");
        rules.push(RewriteRule::new(
            Term::app(
                "repeat",
                vec![
                    constant("left0".into()),
                    constant("right0".into()),
                    x.clone(),
                ],
            ),
            Term::app("repeat", vec![x.clone(), x.clone(), x]),
        ));
        let trs = Trs::new(None, BTreeSet::from([Variable::new("x")]), rules);
        let pairs = dependency_pairs(&trs)
            .into_iter()
            .filter(|pair| pair.source_rule() == trs.rules().len() - 1)
            .collect::<Vec<_>>();
        let DpNonterminationProof::Loop(proof) =
            backward_dp_loop_proof(&trs, &pairs, None).expect("long common-ancestor cycle")
        else {
            panic!("one pair")
        };
        assert!(proof.steps.len() > 8);
        assert!(check_mixed_dp_loop_proof(&trs, &pairs, &proof));
    }

    #[test]
    fn backward_loop_handles_collapsing_selectors_and_shared_variables() {
        let x = Term::var("x");
        let y = Term::var("y");
        let constant = |s| Term::app(s, vec![]);
        let choose = |a, b, c| Term::app("choose", vec![a, b, c]);
        let repeat = |a, b, c| Term::app("repeat", vec![a, b, c]);
        let trs = Trs::new(
            None,
            BTreeSet::from([Variable::new("x"), Variable::new("y")]),
            vec![
                RewriteRule::new(constant("left"), constant("common")),
                RewriteRule::new(constant("right"), constant("common")),
                RewriteRule::new(choose(x.clone(), x.clone(), y.clone()), y.clone()),
                RewriteRule::new(choose(x.clone(), y.clone(), y.clone()), x.clone()),
                RewriteRule::new(
                    repeat(constant("left"), constant("right"), x.clone()),
                    repeat(x.clone(), x.clone(), x),
                ),
            ],
        );
        let pairs = dependency_pairs(&trs);
        // This checks bounded-search completeness, not wall-clock scheduling.
        // The depth/frontier caps still bound the search under a loaded suite.
        let proof = backward_dp_loop_proof(&trs, &pairs, None)
            .expect("infer a shared selector ancestor without a supplied term");
        let DpNonterminationProof::Loop(proof) = proof else {
            panic!("one pair")
        };
        assert!(check_mixed_dp_loop_proof(&trs, &pairs, &proof));
    }

    #[test]
    fn backward_loop_infers_a_common_predecessor_for_duplicated_arguments() {
        for names in [
            ["f", "h", "a", "b", "c"],
            ["join", "fork", "seed", "left", "right"],
        ] {
            let [f, h, a, b, c] = names;
            let constant = |name| Term::app(name, vec![]);
            let x = Term::var("x");
            let ancestor = Term::app(h, vec![constant(a)]);
            let rules = vec![
                RewriteRule::new(ancestor.clone(), constant(b)),
                RewriteRule::new(ancestor, constant(c)),
                RewriteRule::new(
                    Term::app(f, vec![constant(b), constant(c), x.clone()]),
                    Term::app(f, vec![x.clone(), x.clone(), x]),
                ),
            ];
            let trs = Trs::new(None, BTreeSet::from([Variable::new("x")]), rules.clone());
            let pairs = dependency_pairs(&trs);
            let proof =
                backward_dp_loop_proof(&trs, &pairs, Some(Instant::now() + Duration::from_secs(2)))
                    .expect("common predecessor loop");
            let DpNonterminationProof::Loop(proof) = proof else {
                panic!("single pair needs no removal")
            };
            assert_eq!(proof.steps.len(), 3);
            assert!(check_mixed_dp_loop_proof(&trs, &pairs, &proof));
            let mutant = Trs::new(
                None,
                trs.variables().clone(),
                vec![rules[0].clone(), rules[2].clone()],
            );
            assert!(!check_mixed_dp_loop_proof(&mutant, &pairs, &proof));
            assert!(
                backward_dp_loop_proof(
                    &mutant,
                    &pairs,
                    Some(Instant::now() + Duration::from_secs(1))
                )
                .is_none()
            );
        }
    }

    #[test]
    fn symbolic_loop_atom_is_available_at_root_and_dp_states() {
        assert!(super::super::NonterminationStrategy::parse("dp-symbolic-loop").is_ok());
        assert!(super::super::NonterminationStrategy::parse("dp-backward-loop").is_ok());
        assert!(
            crate::proving::dependency_pairs::DpStrategy::parse("nontermination(dp-symbolic-loop)")
                .is_ok()
        );
    }

    #[test]
    fn chained_unification_is_idempotent_and_checks_indirect_occurs() {
        let x = Term::var("x");
        let y = Term::var("y");
        let z = Term::var("z");
        let mut substitution = BTreeMap::new();
        assert!(unify_terms(&x, &y, &mut substitution));
        assert!(unify_terms(
            &y,
            &Term::app("f", vec![z.clone()]),
            &mut substitution
        ));
        assert_eq!(
            apply_substitution(&x, &substitution),
            Term::app("f", vec![z.clone()])
        );
        for image in substitution.values() {
            assert_eq!(apply_substitution(image, &substitution), *image);
        }
        assert!(!unify_terms(
            &z,
            &Term::app("g", vec![x]),
            &mut substitution
        ));
    }

    #[test]
    fn mixed_symbolic_cycle_refines_shared_arguments_without_ground_enumeration() {
        for names in [
            ["F", "G", "project", "s", "l"],
            ["alpha", "beta", "pick", "up", "wrap"],
        ] {
            let [f, g, project, s, l] = names;
            let x = Term::var("x");
            let y = Term::var("y");
            let z = Term::var("z");
            let app = |name, args| Term::app(name, args);
            let lhs = app(f, vec![x.clone(), app(l, vec![y.clone()]), z.clone()]);
            let rhs = app(
                g,
                vec![
                    x.clone(),
                    app(project, vec![x.clone(), y.clone(), z.clone()]),
                    app("zero", vec![]),
                ],
            );
            let pairs = vec![
                DependencyPair::new_for_nontermination(lhs.clone(), rhs.clone(), 0),
                DependencyPair::new_for_nontermination(
                    app(g, vec![x.clone(), app(s, vec![y.clone()]), z.clone()]),
                    app(f, vec![x.clone(), y.clone(), z.clone()]),
                    1,
                ),
            ];
            let trs = Trs::new(
                None,
                BTreeSet::from([Variable::new("x"), Variable::new("y"), Variable::new("z")]),
                vec![RewriteRule::new(app(project, vec![x.clone(), y, z]), x)],
            );
            let proof = search_mixed_dp_narrowing_loop_with_limit(
                &trs,
                &pairs,
                lhs,
                rhs.clone(),
                vec![LoopRewriteStep {
                    position: vec![],
                    rule: pairs[0].as_rule(),
                    result: rhs,
                }],
                1,
                3,
                Some(Instant::now() + Duration::from_secs(2)),
            )
            .expect("projection and a second marked step close a symbolic cycle");
            assert!(check_mixed_dp_loop_proof(&trs, &pairs, &proof));
            assert!(!proof.start.variables().is_empty());
            assert_eq!(proof.steps.len(), 3);
            assert!(!check_mixed_dp_loop_proof(
                &Trs::new(None, trs.variables().clone(), vec![]),
                &pairs,
                &proof
            ));
        }
    }

    #[test]
    fn iterative_deepening_finds_later_cycle_under_symbol_and_rule_permutation() {
        for (f, g, reverse) in [("f", "g", false), ("renamed", "other", true)] {
            let x = Term::var("v");
            let mut rules = vec![
                RewriteRule::new(Term::app("erase", vec![x.clone()]), x.clone()),
                RewriteRule::new(Term::app(f, vec![x.clone()]), Term::app(g, vec![x.clone()])),
                RewriteRule::new(Term::app(g, vec![x.clone()]), Term::app(f, vec![x.clone()])),
            ];
            if reverse {
                rules.reverse();
            }
            let trs = Trs::new(None, BTreeSet::from([Variable::new("v")]), rules);
            let Some(NonterminationProof::Loop(proof)) =
                bounded_narrowing_loop(&trs, Some(Instant::now() + Duration::from_secs(2)))
            else {
                panic!("a two-step symbolic loop must not be starved")
            };
            assert!(check_loop_proof_for_trs(&trs, &proof));
            assert_eq!(proof.steps.len(), 2);
            let first = proof.steps[0].clone();
            assert!(
                search_narrowing_loop_from_with_limit(
                    &trs,
                    proof.start.clone(),
                    first.result.clone(),
                    vec![first],
                    1,
                    1,
                    None,
                )
                .is_none()
            );
        }
    }

    #[test]
    fn iterative_deepening_respects_deadline_and_rejects_decreasing_rules() {
        let x = Term::var("x");
        let trs = Trs::new(
            None,
            BTreeSet::from([Variable::new("x")]),
            vec![RewriteRule::new(Term::app("erase", vec![x.clone()]), x)],
        );
        assert!(bounded_narrowing_loop(&trs, Some(Instant::now())).is_none());
        assert!(
            bounded_narrowing_loop(&trs, Some(Instant::now() + Duration::from_secs(1))).is_none()
        );
    }
}

pub(crate) fn bounded_narrowing_loop(
    trs: &Trs,
    deadline: Option<Instant>,
) -> Option<NonterminationProof> {
    // Iterative deepening across *all* initial rules prevents a deep branch
    // of the first rule from starving a short cycle of a later rule.  This
    // changes candidate scheduling only: every returned loop is replayed.
    // Restricted strategies retain their tuned deep-first subset search.
    let first_limit = if trs.strategy() == RewriteStrategy::Full {
        1
    } else {
        MAX_LOOP_REWRITE_STEPS
    };
    for limit in first_limit..=MAX_LOOP_REWRITE_STEPS {
        for rule in trs.rules() {
            if strategy_timed_out(deadline) {
                return None;
            }
            let start = rule.lhs().clone();
            let first = LoopRewriteStep {
                position: Vec::new(),
                rule: rule.clone(),
                result: rule.rhs().clone(),
            };
            if let Some(proof) = search_narrowing_loop_from_with_limit(
                trs,
                start.clone(),
                rule.rhs().clone(),
                vec![first],
                1,
                limit,
                deadline,
            ) {
                return Some(NonterminationProof::Loop(proof));
            }
        }
    }
    None
}

pub(crate) fn bounded_rule_subset_narrowing_loop(
    trs: &Trs,
    deadline: Option<Instant>,
) -> Option<NonterminationProof> {
    const MAX_RULES: usize = 32;
    const MAX_SUBSET_SIZE: usize = 5;
    const MAX_OUTERMOST_SUBSETS: usize = 8_192;

    if trs.rules().len() > MAX_RULES {
        return None;
    }
    let mut candidates = Vec::new();
    let outermost = trs.strategy() == RewriteStrategy::Outermost;
    let max_candidates = outermost
        .then_some(MAX_OUTERMOST_SUBSETS)
        .unwrap_or(usize::MAX);
    let subset_sizes = if outermost {
        (1..=MAX_SUBSET_SIZE.min(trs.rules().len())).collect::<Vec<_>>()
    } else {
        (1..=MAX_SUBSET_SIZE.min(trs.rules().len())).rev().collect()
    };
    for subset_size in subset_sizes {
        let mut indices = Vec::with_capacity(subset_size);
        if !collect_rule_subsets(
            trs.rules().len(),
            subset_size,
            0,
            &mut indices,
            &mut candidates,
            outermost.then_some(deadline).flatten(),
            max_candidates,
        ) {
            break;
        }
    }
    candidates.retain(|indices| {
        let rules = indices
            .iter()
            .map(|index| trs.rules()[*index].clone())
            .collect::<Vec<_>>();
        rule_subset_may_recur(&rules)
    });
    if outermost {
        candidates.sort_by(|left, right| {
            left.len().cmp(&right.len()).then_with(|| {
                rule_subset_dependency_score(trs, right)
                    .cmp(&rule_subset_dependency_score(trs, left))
            })
        });
    } else {
        candidates.sort_by(|left, right| {
            rule_subset_dependency_score(trs, right)
                .cmp(&rule_subset_dependency_score(trs, left))
                .then_with(|| right.len().cmp(&left.len()))
        });
    }

    let candidate_count = candidates.len();
    for (candidate_index, indices) in candidates.into_iter().enumerate() {
        if strategy_timed_out(deadline) {
            return None;
        }
        let rules = indices
            .iter()
            .map(|index| trs.rules()[*index].clone())
            .collect::<Vec<_>>();
        let subset = Trs::new_with_strategy(
            trs.name().map(str::to_string),
            trs.variables().clone(),
            rules,
            trs.strategy(),
        );
        let now = Instant::now();
        let attempt_deadline = now
            + rule_subset_attempt_budget(
                deadline.map(|end| end.saturating_duration_since(now)),
                candidate_count - candidate_index,
            );
        let attempt_deadline = Some(
            deadline
                .map(|global_deadline| global_deadline.min(attempt_deadline))
                .unwrap_or(attempt_deadline),
        );
        let Some(NonterminationProof::Loop(proof)) =
            bounded_narrowing_loop(&subset, attempt_deadline)
        else {
            continue;
        };
        if trs.strategy() == RewriteStrategy::Outermost {
            if let Some(proof) = validated_outermost_loop_instance(trs, &proof, deadline) {
                return Some(NonterminationProof::Loop(proof));
            }
        } else if check_loop_proof_for_trs(trs, &proof) {
            return Some(NonterminationProof::Loop(proof));
        }
    }
    None
}

fn rule_subset_attempt_budget(remaining: Option<Duration>, candidates_left: usize) -> Duration {
    let base = Duration::from_millis(100);
    remaining.map_or(base, |remaining| {
        (remaining / candidates_left.max(1).min(u32::MAX as usize) as u32)
            .max(base)
            .min(Duration::from_secs(1))
            .min(remaining)
    })
}

#[cfg(test)]
mod rule_subset_budget_tests {
    use super::*;

    #[test]
    fn subset_attempts_share_the_parent_budget_without_exceeding_it() {
        assert_eq!(
            rule_subset_attempt_budget(None, 4),
            Duration::from_millis(100)
        );
        assert_eq!(
            rule_subset_attempt_budget(Some(Duration::from_secs(2)), 4),
            Duration::from_millis(500)
        );
        assert_eq!(
            rule_subset_attempt_budget(Some(Duration::from_secs(20)), 2),
            Duration::from_secs(1)
        );
        assert_eq!(
            rule_subset_attempt_budget(Some(Duration::from_millis(10)), 4),
            Duration::from_millis(10)
        );
        assert_eq!(
            rule_subset_attempt_budget(Some(Duration::ZERO), 0),
            Duration::ZERO
        );
    }
}

pub(crate) fn collect_rule_subsets(
    rule_count: usize,
    subset_size: usize,
    next_index: usize,
    indices: &mut Vec<usize>,
    subsets: &mut Vec<Vec<usize>>,
    deadline: Option<Instant>,
    max_subsets: usize,
) -> bool {
    if strategy_timed_out(deadline) || subsets.len() >= max_subsets {
        return false;
    }
    if indices.len() == subset_size {
        subsets.push(indices.clone());
        return subsets.len() < max_subsets;
    }
    let remaining = subset_size - indices.len();
    let Some(last_start) = rule_count.checked_sub(remaining) else {
        return true;
    };
    for index in next_index..=last_start {
        indices.push(index);
        let complete = collect_rule_subsets(
            rule_count,
            subset_size,
            index + 1,
            indices,
            subsets,
            deadline,
            max_subsets,
        );
        indices.pop();
        if !complete {
            return false;
        }
    }
    true
}

pub(crate) fn rule_subset_dependency_score(trs: &Trs, indices: &[usize]) -> (usize, usize) {
    let roots = indices
        .iter()
        .filter_map(|index| trs.rules()[*index].lhs().root_symbol().cloned())
        .collect::<BTreeSet<_>>();
    let mut cross_dependencies = 0usize;
    let mut dependencies = 0usize;
    for index in indices {
        let rule = &trs.rules()[*index];
        let lhs_root = rule.lhs().root_symbol();
        for root in &roots {
            if term_contains_symbol(rule.rhs(), root) {
                dependencies += 1;
                if lhs_root != Some(root) {
                    cross_dependencies += 1;
                }
            }
        }
    }
    (cross_dependencies, dependencies)
}

pub(crate) fn rule_subset_may_recur(rules: &[RewriteRule]) -> bool {
    let roots = rules
        .iter()
        .filter_map(|rule| rule.lhs().root_symbol().cloned())
        .collect::<BTreeSet<_>>();
    rules
        .iter()
        .any(|rule| term_contains_any_symbol(rule.rhs(), &roots))
}

pub(crate) fn term_contains_symbol(term: &Term, needle: &Symbol) -> bool {
    match term {
        Term::Var(_) => false,
        Term::App { symbol, args } => {
            symbol == needle
                || args
                    .iter()
                    .any(|argument| term_contains_symbol(argument, needle))
        }
    }
}

pub(crate) fn term_contains_any_symbol(term: &Term, symbols: &BTreeSet<Symbol>) -> bool {
    match term {
        Term::Var(_) => false,
        Term::App { symbol, args } => {
            symbols.contains(symbol)
                || args
                    .iter()
                    .any(|argument| term_contains_any_symbol(argument, symbols))
        }
    }
}

pub(crate) fn search_narrowing_loop_from(
    trs: &Trs,
    start: Term,
    current: Term,
    steps: Vec<LoopRewriteStep>,
    depth: usize,
    deadline: Option<Instant>,
) -> Option<LoopProof> {
    search_narrowing_loop_from_with_limit(
        trs,
        start,
        current,
        steps,
        depth,
        MAX_LOOP_REWRITE_STEPS,
        deadline,
    )
}

fn search_narrowing_loop_from_with_limit(
    trs: &Trs,
    start: Term,
    current: Term,
    steps: Vec<LoopRewriteStep>,
    depth: usize,
    limit: usize,
    deadline: Option<Instant>,
) -> Option<LoopProof> {
    if strategy_timed_out(deadline) {
        return None;
    }
    if !steps.is_empty()
        && let Some((context_position, substitution, instantiation)) =
            closes_loop_with_subject_refinement(&start, &current)
    {
        let proof = LoopProof {
            start: apply_substitution(&start, &instantiation),
            steps: steps
                .iter()
                .map(|step| LoopRewriteStep {
                    position: step.position.clone(),
                    rule: step.rule.clone(),
                    result: apply_substitution(&step.result, &instantiation),
                })
                .collect(),
            substitution,
            context_position,
        };
        let valid = if trs.strategy() == RewriteStrategy::Outermost {
            validated_outermost_loop_instance(trs, &proof, deadline).is_some()
        } else {
            check_loop_proof_for_trs(trs, &proof)
        };
        if valid {
            return Some(proof);
        }
    }
    if depth >= limit {
        return None;
    }
    let mut tried = 0usize;
    let mut narrowing_positions = positions_with_subterms(&current);
    narrowing_positions.sort_by_key(|(_, subterm)| usize::from(matches!(subterm, Term::Var(_))));
    for (position, subterm) in narrowing_positions {
        for (rule_index, rule) in trs.rules().iter().enumerate() {
            if strategy_timed_out(deadline) {
                return None;
            }
            let fresh_rule = freshen_rule(rule, rule_index, depth);
            let mut unifier = BTreeMap::new();
            if !unify_terms(subterm, fresh_rule.lhs(), &mut unifier) {
                continue;
            }
            let narrowed_start = apply_substitution(&start, &unifier);
            let narrowed_current = apply_substitution(&current, &unifier);
            let narrowed_steps = steps
                .iter()
                .map(|step| LoopRewriteStep {
                    position: step.position.clone(),
                    rule: step.rule.clone(),
                    result: apply_substitution(&step.result, &unifier),
                })
                .collect::<Vec<_>>();
            let rhs = apply_substitution(fresh_rule.rhs(), &unifier);
            let Some(next) = replace_subterm_at_position(&narrowed_current, &position, &rhs) else {
                continue;
            };
            tried += 1;
            if tried > MAX_LOOP_FRONTIER {
                return None;
            }
            let mut next_steps = narrowed_steps;
            next_steps.push(LoopRewriteStep {
                position: position.clone(),
                rule: fresh_rule,
                result: next.clone(),
            });
            if let Some(proof) = search_narrowing_loop_from_with_limit(
                trs,
                narrowed_start,
                next,
                next_steps,
                depth + 1,
                limit,
                deadline,
            ) {
                return Some(proof);
            }
        }
    }
    None
}

pub(crate) fn closes_loop_with_subject_refinement(
    start: &Term,
    current: &Term,
) -> Option<(
    Vec<usize>,
    BTreeMap<Variable, Term>,
    BTreeMap<Variable, Term>,
)> {
    const MAX_REFINEMENTS: usize = 4;

    for (position, subterm) in positions_with_subterms(current) {
        let mut instantiation = BTreeMap::new();
        for refinement_index in 0..=MAX_REFINEMENTS {
            let pattern = apply_substitution(start, &instantiation);
            let subject = apply_substitution(subterm, &instantiation);
            if let Some(substitution) = match_pattern(&pattern, &subject) {
                return Some((position, substitution, instantiation));
            }
            if let Some(refinements) = repeated_subject_constraints(&pattern, &subject) {
                for term in instantiation.values_mut() {
                    *term = apply_substitution(term, &refinements);
                }
                instantiation.extend(refinements);
                continue;
            }
            let mut occupied = start.variables();
            occupied.extend(current.variables());
            occupied.extend(
                instantiation
                    .values()
                    .flat_map(Term::variables)
                    .collect::<BTreeSet<_>>(),
            );
            let Some((variable, replacement)) =
                subject_refinement(&pattern, &subject, refinement_index, &occupied)
            else {
                break;
            };
            if replacement.variables().contains(&variable) {
                break;
            }
            for term in instantiation.values_mut() {
                *term = apply_substitution(
                    term,
                    &BTreeMap::from([(variable.clone(), replacement.clone())]),
                );
            }
            instantiation.insert(variable, replacement);
        }
    }
    None
}

/// Repeated pattern variables constrain their subject images to be equal.
/// Solve those equalities without unifying the entire start/end terms: a
/// singly occurring variable may legitimately grow in the loop substitution.
fn repeated_subject_constraints(
    pattern: &Term,
    subject: &Term,
) -> Option<BTreeMap<Variable, Term>> {
    fn walk(
        pattern: &Term,
        subject: &Term,
        images: &mut BTreeMap<Variable, Term>,
        refinement: &mut BTreeMap<Variable, Term>,
    ) -> bool {
        match (pattern, subject) {
            (Term::Var(variable), _) => match images.get(variable) {
                Some(previous) => unify_terms(previous, subject, refinement),
                None => {
                    images.insert(variable.clone(), subject.clone());
                    true
                }
            },
            (
                Term::App {
                    symbol: a,
                    args: xs,
                },
                Term::App {
                    symbol: b,
                    args: ys,
                },
            ) if a == b && xs.len() == ys.len() => xs
                .iter()
                .zip(ys)
                .all(|(x, y)| walk(x, y, images, refinement)),
            // Structural mismatches are handled by the existing subject
            // refinement stage; do not invent any interpretation here.
            _ => true,
        }
    }
    let mut refinement = BTreeMap::new();
    (walk(pattern, subject, &mut BTreeMap::new(), &mut refinement) && !refinement.is_empty())
        .then_some(refinement)
}

pub(crate) fn subject_refinement(
    pattern: &Term,
    subject: &Term,
    refinement_index: usize,
    occupied: &BTreeSet<Variable>,
) -> Option<(Variable, Term)> {
    match (pattern, subject) {
        (Term::Var(_), _) => None,
        (Term::App { .. }, Term::Var(variable)) => Some((
            variable.clone(),
            rename_variables_away_from(pattern, occupied, refinement_index),
        )),
        (
            Term::App {
                symbol: pattern_symbol,
                args: pattern_args,
            },
            Term::App {
                symbol: subject_symbol,
                args: subject_args,
            },
        ) if pattern_symbol == subject_symbol && pattern_args.len() == subject_args.len() => {
            pattern_args
                .iter()
                .zip(subject_args)
                .find_map(|(pattern, subject)| {
                    subject_refinement(pattern, subject, refinement_index, occupied)
                })
        }
        _ => None,
    }
}

pub(crate) fn search_loop_from(
    trs: &Trs,
    start: Term,
    current: Term,
    steps: Vec<LoopRewriteStep>,
    depth: usize,
    deadline: Option<Instant>,
) -> Option<LoopProof> {
    let mut queue = VecDeque::from([(current.clone(), steps, depth)]);
    let mut seen = BTreeSet::from([current]);
    let mut explored = 0usize;
    while let Some((current, steps, depth)) = queue.pop_front() {
        if strategy_timed_out(deadline) {
            return None;
        }
        if let Some((context_position, substitution)) = closes_loop(&start, &current) {
            let proof = LoopProof {
                start: start.clone(),
                steps: steps.clone(),
                substitution,
                context_position,
            };
            if check_loop_proof_for_trs(trs, &proof) {
                return Some(proof);
            }
        }
        if depth >= MAX_DETERMINISTIC_LOOP_REWRITE_STEPS {
            continue;
        }
        let mut successors = Vec::new();
        for (position, subterm) in positions_with_subterms(&current) {
            if trs.strategy() == RewriteStrategy::Innermost
                && !proper_subterms_are_normal(subterm, trs.rules())
            {
                continue;
            }
            for rule in trs.rules() {
                if strategy_timed_out(deadline) {
                    return None;
                }
                let Some(substitution) = match_pattern(rule.lhs(), subterm) else {
                    continue;
                };
                let rhs = apply_substitution(rule.rhs(), &substitution);
                let Some(next) = replace_subterm_at_position(&current, &position, &rhs) else {
                    continue;
                };
                successors.push((position.clone(), rule.clone(), next));
            }
        }
        if depth >= MAX_LOOP_REWRITE_STEPS && successors.len() != 1 {
            continue;
        }
        for (position, rule, next) in successors {
            let mut next_steps = steps.clone();
            next_steps.push(LoopRewriteStep {
                position: position.clone(),
                rule: rule.clone(),
                result: next.clone(),
            });
            // Detect a closing edge before duplicate-state suppression.  An
            // exact cycle necessarily returns to an already seen state, so
            // checking only dequeued states made every concrete cycle of
            // length greater than one invisible to this search.
            if let Some((context_position, substitution)) = closes_loop(&start, &next) {
                let proof = LoopProof {
                    start: start.clone(),
                    steps: next_steps.clone(),
                    substitution,
                    context_position,
                };
                if check_loop_proof_for_trs(trs, &proof) {
                    return Some(proof);
                }
            }
            if !seen.insert(next.clone()) {
                continue;
            }
            explored += 1;
            if explored > MAX_LOOP_FRONTIER {
                return None;
            }
            queue.push_back((next, next_steps, depth + 1));
        }
    }
    None
}

pub(crate) fn search_mixed_dp_rewriting_loop_from(
    trs: &Trs,
    pairs: &[DependencyPair],
    start: Term,
    current: Term,
    steps: Vec<LoopRewriteStep>,
    depth: usize,
    deadline: Option<Instant>,
) -> Option<LoopProof> {
    let mut queue = VecDeque::from([(current.clone(), steps, depth)]);
    let mut seen = BTreeSet::from([current]);
    let mut explored = 0usize;
    while let Some((current, steps, depth)) = queue.pop_front() {
        if strategy_timed_out(deadline) {
            return None;
        }
        if let Some((context_position, substitution)) = closes_loop(&start, &current) {
            let proof = LoopProof {
                start: start.clone(),
                steps: steps.clone(),
                substitution,
                context_position,
            };
            if check_mixed_dp_loop_proof(trs, pairs, &proof) {
                return Some(proof);
            }
        }
        if depth >= MAX_MIXED_DP_LOOP_REWRITE_STEPS {
            continue;
        }

        let mut successors = Vec::new();
        for pair in pairs {
            let rule = pair.as_rule();
            if let Some(substitution) = match_pattern(rule.lhs(), &current) {
                successors.push((
                    Vec::new(),
                    rule,
                    apply_substitution(pair.rhs(), &substitution),
                ));
            }
        }
        for (position, subterm) in positions_with_subterms(&current) {
            for rule in trs.rules() {
                let Some(substitution) = match_pattern(rule.lhs(), subterm) else {
                    continue;
                };
                let rhs = apply_substitution(rule.rhs(), &substitution);
                let Some(next) = replace_subterm_at_position(&current, &position, &rhs) else {
                    continue;
                };
                successors.push((position.clone(), rule.clone(), next));
            }
        }
        for (position, rule, next) in successors {
            if !seen.insert(next.clone()) {
                continue;
            }
            explored += 1;
            if explored > MAX_LOOP_FRONTIER {
                return None;
            }
            let mut next_steps = steps.clone();
            next_steps.push(LoopRewriteStep {
                position,
                rule,
                result: next.clone(),
            });
            queue.push_back((next, next_steps, depth + 1));
        }
    }
    None
}

pub(crate) fn search_mixed_dp_narrowing_loop_from(
    trs: &Trs,
    pairs: &[DependencyPair],
    start: Term,
    current: Term,
    steps: Vec<LoopRewriteStep>,
    depth: usize,
    deadline: Option<Instant>,
) -> Option<LoopProof> {
    search_mixed_dp_narrowing_loop_inner(
        trs,
        pairs,
        start,
        current,
        steps,
        depth,
        MAX_LOOP_REWRITE_STEPS,
        deadline,
        true,
        false,
        true,
        &mut BTreeMap::new(),
    )
}

pub(crate) fn search_mixed_dp_narrowing_loop_with_limit(
    trs: &Trs,
    pairs: &[DependencyPair],
    start: Term,
    current: Term,
    steps: Vec<LoopRewriteStep>,
    depth: usize,
    limit: usize,
    deadline: Option<Instant>,
) -> Option<LoopProof> {
    search_mixed_dp_narrowing_loop_inner(
        trs,
        pairs,
        start,
        current,
        steps,
        depth,
        limit,
        deadline,
        false,
        false,
        true,
        &mut BTreeMap::new(),
    )
}

pub(crate) fn search_structured_dp_narrowing_loop_with_limit(
    trs: &Trs,
    pairs: &[DependencyPair],
    start: Term,
    current: Term,
    steps: Vec<LoopRewriteStep>,
    depth: usize,
    limit: usize,
    deadline: Option<Instant>,
) -> Option<LoopProof> {
    search_mixed_dp_narrowing_loop_inner(
        trs,
        pairs,
        start,
        current,
        steps,
        depth,
        limit,
        deadline,
        false,
        true,
        true,
        &mut BTreeMap::new(),
    )
}

pub(crate) fn search_structured_relative_loop_with_limit(
    trs: &Trs,
    pairs: &[DependencyPair],
    start: Term,
    current: Term,
    steps: Vec<LoopRewriteStep>,
    depth: usize,
    limit: usize,
    deadline: Option<Instant>,
) -> Option<LoopProof> {
    search_mixed_dp_narrowing_loop_inner(
        trs,
        pairs,
        start,
        current,
        steps,
        depth,
        limit,
        deadline,
        false,
        true,
        false,
        &mut BTreeMap::new(),
    )
}

fn search_mixed_dp_narrowing_loop_inner(
    trs: &Trs,
    pairs: &[DependencyPair],
    start: Term,
    current: Term,
    steps: Vec<LoopRewriteStep>,
    depth: usize,
    limit: usize,
    deadline: Option<Instant>,
    allow_variable_positions: bool,
    structured_only: bool,
    allow_marked_steps: bool,
    visited: &mut BTreeMap<(Term, Term), usize>,
) -> Option<LoopProof> {
    if strategy_timed_out(deadline) {
        return None;
    }
    if let Some(proof) = checked_mixed_narrowing_closure(trs, pairs, &start, &current, &steps) {
        return Some(proof);
    }
    if depth >= limit {
        return None;
    }
    // Interleavings of independent rewrites often reach the same symbolic
    // endpoints. A previously explored representative with at least as much
    // remaining depth subsumes this continuation. Joint alpha normalization
    // preserves all cross-endpoint variable constraints.
    // On short traces, copying and alpha-normalizing large endpoints costs
    // more than the handful of repeated continuations it can eliminate.
    if limit > 4 {
        let key = backward_endpoint_key(&start, &current);
        let remaining = limit - depth;
        if visited.get(&key).is_some_and(|old| *old >= remaining) {
            return None;
        }
        if visited.len() < 65_536 {
            visited.insert(key, remaining);
        }
    }

    let mut candidates = Vec::new();
    if limit <= 3 && !short_marked_root_can_return(trs, pairs, &start, &current, limit - depth) {
        return None;
    }
    for (pair_index, pair) in pairs.iter().enumerate() {
        if !allow_marked_steps || current.root_symbol() != pair.lhs().root_symbol() {
            continue;
        }
        candidates.push((
            Vec::new(),
            current.clone(),
            freshen_rule(&pair.as_rule(), pair_index, depth + 30_000),
        ));
    }
    for (position, subterm) in positions_with_subterms(&current) {
        // The initial shallow pass avoids guessing unconstrained instances.
        // The deeper pass must include variable positions even near the
        // start: their narrowing can expose a short closing cycle.
        if (structured_only || (!allow_variable_positions && limit <= 3))
            && matches!(subterm, Term::Var(_))
        {
            continue;
        }
        for (rule_index, rule) in trs.rules().iter().enumerate() {
            if !matches!(subterm, Term::Var(_))
                && !matches!(rule.lhs(), Term::Var(_))
                && subterm.root_symbol() != rule.lhs().root_symbol()
            {
                continue;
            }
            candidates.push((
                position.clone(),
                subterm.clone(),
                freshen_rule(rule, rule_index, depth + 40_000),
            ));
        }
    }
    candidates.sort_by_key(|(_, subterm, rule)| match_pattern(rule.lhs(), subterm).is_none());

    let mut successors = Vec::new();
    for (position, subterm, rule) in candidates {
        if strategy_timed_out(deadline) {
            return None;
        }
        let mut unifier = BTreeMap::new();
        if !unify_terms(&subterm, rule.lhs(), &mut unifier) {
            continue;
        }
        let narrowed_start = apply_substitution(&start, &unifier);
        let narrowed_current = apply_substitution(&current, &unifier);
        let narrowed_steps = steps
            .iter()
            .map(|step| LoopRewriteStep {
                position: step.position.clone(),
                rule: step.rule.clone(),
                result: apply_substitution(&step.result, &unifier),
            })
            .collect::<Vec<_>>();
        let rhs = apply_substitution(rule.rhs(), &unifier);
        let Some(next) = replace_subterm_at_position(&narrowed_current, &position, &rhs) else {
            continue;
        };
        let mut next_steps = narrowed_steps;
        next_steps.push(LoopRewriteStep {
            position: position.clone(),
            rule,
            result: next.clone(),
        });
        successors.push((narrowed_start, next, next_steps));
    }

    for (narrowed_start, next, next_steps) in &successors {
        if let Some(proof) =
            checked_mixed_narrowing_closure(trs, pairs, narrowed_start, next, next_steps)
        {
            return Some(proof);
        }
    }
    if structured_only || !allow_marked_steps {
        // Search ranking only: favour closing the fixed constructor skeleton
        // before expanding unconstrained subterms. This is useful when several
        // independent arguments must return to their respective patterns.
        fn distance(pattern: &Term, subject: &Term) -> usize {
            match (pattern, subject) {
                (Term::Var(_), _) => 0,
                (
                    Term::App {
                        symbol: p,
                        args: ps,
                    },
                    Term::App {
                        symbol: s,
                        args: ss,
                    },
                ) if p == s && ps.len() == ss.len() => {
                    ps.iter().zip(ss).map(|(p, s)| distance(p, s)).sum()
                }
                _ => positions_with_subterms(pattern)
                    .iter()
                    .filter(|(_, t)| !matches!(t, Term::Var(_)))
                    .count(),
            }
        }
        successors.sort_by_key(|(start, next, _)| distance(start, next));
    }
    for (narrowed_start, next, next_steps) in successors {
        if let Some(proof) = search_mixed_dp_narrowing_loop_inner(
            trs,
            pairs,
            narrowed_start,
            next,
            next_steps,
            depth + 1,
            limit,
            deadline,
            allow_variable_positions,
            structured_only,
            allow_marked_steps,
            visited,
        ) {
            return Some(proof);
        }
    }
    None
}

/// Cheap overapproximation for the short marked-cycle search. Ordinary
/// rewrites below a marked root cannot change it; every root change must
/// therefore use a dependency pair. If the root is not known to be protected
/// from ordinary rewriting, decline this pruning entirely.
fn short_marked_root_can_return(
    trs: &Trs,
    pairs: &[DependencyPair],
    start: &Term,
    current: &Term,
    remaining: usize,
) -> bool {
    let (Some(goal), Some(root)) = (start.root_symbol(), current.root_symbol()) else {
        return true;
    };
    let mut reachable = BTreeSet::from([root.clone()]);
    for _ in 0..=remaining {
        if reachable.contains(goal) {
            return true;
        }
        if trs.rules().iter().any(|rule| {
            rule.lhs()
                .root_symbol()
                .is_none_or(|symbol| reachable.contains(symbol))
        }) {
            return true;
        }
        let mut next = BTreeSet::new();
        for pair in pairs {
            if pair
                .lhs()
                .root_symbol()
                .is_some_and(|symbol| reachable.contains(symbol))
            {
                let Some(symbol) = pair.rhs().root_symbol() else {
                    return true;
                };
                next.insert(symbol.clone());
            }
        }
        if next.is_empty() {
            return false;
        }
        reachable = next;
    }
    false
}

pub(crate) fn checked_mixed_narrowing_closure(
    trs: &Trs,
    pairs: &[DependencyPair],
    start: &Term,
    current: &Term,
    steps: &[LoopRewriteStep],
) -> Option<LoopProof> {
    // A cycle may require identifying variables shared between arguments.
    // Matching alone cannot express that refinement. Unify an exact cycle
    // first, then independently replay every instantiated P/R step.
    for (position, subterm) in positions_with_subterms(current) {
        let mut instantiation = BTreeMap::new();
        if !unify_terms(start, subterm, &mut instantiation) {
            continue;
        }
        let proof = LoopProof {
            start: apply_substitution(start, &instantiation),
            steps: steps
                .iter()
                .map(|step| LoopRewriteStep {
                    position: step.position.clone(),
                    rule: step.rule.clone(),
                    result: apply_substitution(&step.result, &instantiation),
                })
                .collect(),
            substitution: BTreeMap::new(),
            context_position: position,
        };
        if check_mixed_dp_loop_proof(trs, pairs, &proof) {
            return Some(proof);
        }
    }
    let (context_position, substitution, instantiation) =
        closes_loop_with_subject_refinement(start, current)?;
    let proof = LoopProof {
        start: apply_substitution(start, &instantiation),
        steps: steps
            .iter()
            .map(|step| LoopRewriteStep {
                position: step.position.clone(),
                rule: step.rule.clone(),
                result: apply_substitution(&step.result, &instantiation),
            })
            .collect(),
        substitution,
        context_position,
    };
    check_mixed_dp_loop_proof(trs, pairs, &proof).then_some(proof)
}

/// Discover overlapping-rule fork seeds for copied arguments, then check a
/// bounded mixed rewrite trace. No supplied substitution or loop is used.
pub(crate) fn fork_dp_loop_proof(
    trs: &Trs,
    pairs: &[DependencyPair],
    deadline: Option<Instant>,
) -> Option<DpNonterminationProof> {
    if trs.strategy() != RewriteStrategy::Full {
        return None;
    }
    // A duplicated argument can take incompatible reducts after copying.
    // Propose small common predecessors from actual overlapping root rules,
    // not from a Cartesian enumeration of arbitrary ground substitutions.
    let constants = trs
        .arities()
        .into_iter()
        .filter_map(|(symbol, arity)| (arity == 0).then(|| Term::app(symbol.as_str(), vec![])))
        .collect::<Vec<_>>();
    let mut forks = BTreeSet::new();
    'overlaps: for (i, left) in trs.rules().iter().enumerate() {
        for (j, right) in trs.rules().iter().enumerate().skip(i + 1) {
            if strategy_timed_out(deadline) {
                return None;
            }
            let right = freshen_rule(right, j, 90_000);
            let mut overlap = BTreeMap::new();
            if !unify_terms(left.lhs(), right.lhs(), &mut overlap) {
                continue;
            }
            let common = apply_substitution(left.lhs(), &overlap);
            for constant in &constants {
                let ground = common
                    .variables()
                    .into_iter()
                    .map(|v| (v, constant.clone()))
                    .collect();
                let seed = apply_substitution(&common, &ground);
                let Some(a) = match_pattern(left.lhs(), &seed) else {
                    continue;
                };
                let Some(b) = match_pattern(right.lhs(), &seed) else {
                    continue;
                };
                if apply_substitution(left.rhs(), &a) != apply_substitution(right.rhs(), &b) {
                    forks.insert(seed);
                }
                if forks.len() >= 128 {
                    break 'overlaps;
                }
            }
        }
    }
    for pair in pairs {
        let variables = pair.lhs().variables();
        for variable in &variables {
            let occurrences = positions_with_subterms(pair.rhs())
                .into_iter()
                .filter(|(_, t)| matches!(t, Term::Var(v) if v == variable))
                .count();
            if occurrences < 2 {
                continue;
            }
            for seed in &forks {
                for constant in &constants {
                    if strategy_timed_out(deadline) {
                        return None;
                    }
                    let mut assignment: BTreeMap<_, _> = variables
                        .iter()
                        .cloned()
                        .map(|v| (v, constant.clone()))
                        .collect();
                    assignment.insert(variable.clone(), seed.clone());
                    let start = apply_substitution(pair.lhs(), &assignment);
                    let current = apply_substitution(pair.rhs(), &assignment);
                    let local = Instant::now() + Duration::from_millis(100);
                    let local = Some(deadline.map_or(local, |outer| outer.min(local)));
                    if let Some(proof) = search_mixed_dp_rewriting_loop_from(
                        trs,
                        pairs,
                        start,
                        current.clone(),
                        vec![LoopRewriteStep {
                            position: vec![],
                            rule: pair.as_rule(),
                            result: current,
                        }],
                        1,
                        local,
                    ) {
                        return Some(dp_loop_with_used_pair_rule_removal(pairs, proof));
                    }
                }
            }
        }
    }
    None
}

/// Solve independent argument cycles separately, then reconstruct and check
/// one actual marked step followed by ordinary rewrites. The synthetic unary
/// pairs are search devices only and never occur in the returned certificate.
pub(crate) fn separable_dp_loop_proof(
    trs: &Trs,
    pairs: &[DependencyPair],
    deadline: Option<Instant>,
) -> Option<DpNonterminationProof> {
    let trace = std::env::var_os("FERRUM_LOOP_TRACE").is_some();
    for pair in pairs {
        if strategy_timed_out(deadline) {
            return None;
        }
        let (
            Term::App {
                symbol: left,
                args: ls,
            },
            Term::App {
                symbol: right,
                args: rs,
            },
        ) = (pair.lhs(), pair.rhs())
        else {
            continue;
        };
        if left != right || ls.len() < 2 || ls.len() > 8 || ls.len() != rs.len() {
            continue;
        }
        let mut used = BTreeSet::new();
        if ls.iter().zip(rs).any(|(l, r)| {
            let variables = l
                .variables()
                .union(&r.variables())
                .cloned()
                .collect::<BTreeSet<_>>();
            let overlaps = !used.is_disjoint(&variables);
            used.extend(variables);
            overlaps
        }) {
            continue;
        }
        let mut local_proofs = Vec::new();
        for (i, (l, r)) in ls.iter().zip(rs).enumerate() {
            let local_pair = DependencyPair::new(
                Term::App {
                    symbol: left.clone(),
                    args: vec![l.clone()],
                },
                Term::App {
                    symbol: left.clone(),
                    args: vec![r.clone()],
                },
                pair.source_rule(),
            );
            let mut found = None;
            for limit in 1..=16 {
                let local = Instant::now() + Duration::from_millis(50);
                let local = Some(deadline.map_or(local, |d| d.min(local)));
                let first = LoopRewriteStep {
                    position: vec![],
                    rule: local_pair.as_rule(),
                    result: local_pair.rhs().clone(),
                };
                if let Some(proof) = search_mixed_dp_narrowing_loop_inner(
                    trs,
                    std::slice::from_ref(&local_pair),
                    local_pair.lhs().clone(),
                    local_pair.rhs().clone(),
                    vec![first],
                    1,
                    limit,
                    local,
                    true,
                    false,
                    false,
                    &mut BTreeMap::new(),
                ) {
                    if proof.context_position.is_empty()
                        && proof.steps.iter().skip(1).all(|s| {
                            !s.position.is_empty()
                                && trs
                                    .rules()
                                    .iter()
                                    .any(|r| rewrite_rules_are_variants(r, &s.rule))
                        })
                    {
                        found = Some(proof);
                        if trace {
                            eprintln!("separable-loop argument={i} depth={limit} closed");
                        }
                        break;
                    }
                }
            }
            if found.is_none() && !strategy_timed_out(deadline) {
                let local = Instant::now() + Duration::from_secs(1);
                let mut backward = backward_dp_loop_proof(
                    trs,
                    std::slice::from_ref(&local_pair),
                    Some(deadline.map_or(local, |d| d.min(local))),
                );
                while let Some(DpNonterminationProof::DpRuleRemoval { proof, .. }) = backward {
                    backward = Some(*proof);
                }
                if let Some(DpNonterminationProof::Loop(proof)) = backward {
                    if proof.context_position.is_empty()
                        && proof.steps.iter().filter(|s| s.position.is_empty()).count() == 1
                        && proof.steps.iter().all(|s| {
                            if s.position.is_empty() {
                                rewrite_rules_are_variants(&s.rule, &local_pair.as_rule())
                            } else {
                                trs.rules()
                                    .iter()
                                    .any(|r| rewrite_rules_are_variants(r, &s.rule))
                            }
                        })
                    {
                        found = Some(proof);
                    }
                }
            }
            let Some(mut proof) = found else {
                if trace {
                    eprintln!("separable-loop argument={i} no local closure");
                }
                break;
            };
            let mut variables = proof.start.variables();
            for step in &proof.steps {
                variables.extend(step.result.variables());
            }
            let renaming = variables
                .into_iter()
                .enumerate()
                .map(|(n, v)| (v, Term::var(format!("component_{i}_{n}"))))
                .collect::<BTreeMap<_, _>>();
            proof.start = apply_substitution(&proof.start, &renaming);
            for step in &mut proof.steps {
                step.result = apply_substitution(&step.result, &renaming);
            }
            local_proofs.push(proof);
        }
        if local_proofs.len() != ls.len() {
            continue;
        }
        let argument = |t: &Term| match t {
            Term::App { args, .. } if args.len() == 1 => Some(args[0].clone()),
            _ => None,
        };
        let Some(start_args) = local_proofs
            .iter()
            .map(|p| argument(&p.start))
            .collect::<Option<Vec<_>>>()
        else {
            continue;
        };
        let mut args = start_args.clone();
        let start = Term::App {
            symbol: left.clone(),
            args: start_args,
        };
        let mut current = Term::App {
            symbol: left.clone(),
            args: args.clone(),
        };
        let mut steps = Vec::new();
        for before in [true, false] {
            if !before {
                for (i, proof) in local_proofs.iter().enumerate() {
                    args[i] =
                        argument(&proof.steps.iter().find(|s| s.position.is_empty())?.result)?;
                }
                current = Term::App {
                    symbol: left.clone(),
                    args: args.clone(),
                };
                steps.push(LoopRewriteStep {
                    position: vec![],
                    rule: pair.as_rule(),
                    result: current.clone(),
                });
            }
            for (i, proof) in local_proofs.iter().enumerate() {
                let marked = proof.steps.iter().position(|s| s.position.is_empty())?;
                let relative = if before {
                    &proof.steps[..marked]
                } else {
                    &proof.steps[marked + 1..]
                };
                for step in relative {
                    args[i] = argument(&step.result)?;
                    current = Term::App {
                        symbol: left.clone(),
                        args: args.clone(),
                    };
                    let mut position = step.position.clone();
                    position[0] = i + 1;
                    steps.push(LoopRewriteStep {
                        position,
                        rule: step.rule.clone(),
                        result: current.clone(),
                    });
                }
            }
        }
        if let Some(proof) = checked_mixed_narrowing_closure(trs, pairs, &start, &current, &steps) {
            return Some(dp_loop_with_used_pair_rule_removal(pairs, proof));
        }
        if trace {
            eprintln!("separable-loop joint reconstruction rejected");
        }
    }
    None
}

/// Search predecessors of a marked step. Backwards rewriting can infer a
/// common ancestor for duplicated arguments that have distinct reducts.
pub(crate) fn backward_dp_loop_proof(
    trs: &Trs,
    pairs: &[DependencyPair],
    deadline: Option<Instant>,
) -> Option<DpNonterminationProof> {
    // Finish both cheap modes before enlarging either frontier; otherwise
    // the first mode can starve a short inverse-collapsing proof.
    for frontier_limit in [MAX_LOOP_FRONTIER, 65_536] {
        for allow_collapsing in [false, true] {
            if let Some(proof) =
                backward_dp_loop_search(trs, pairs, deadline, allow_collapsing, frontier_limit)
            {
                return Some(proof);
            }
        }
    }
    None
}

/// Quotient only variable names, jointly across the two endpoints. Sharing
/// between the endpoints is part of the search state and must be retained.
fn backward_endpoint_key(start: &Term, end: &Term) -> (Term, Term) {
    fn rename(term: &Term, names: &mut BTreeMap<Variable, Variable>) -> Term {
        match term {
            Term::Var(variable) => {
                let next = Variable::new(format!("v{}", names.len()));
                Term::Var(names.entry(variable.clone()).or_insert(next).clone())
            }
            Term::App { symbol, args } => Term::App {
                symbol: symbol.clone(),
                args: args.iter().map(|arg| rename(arg, names)).collect(),
            },
        }
    }
    let mut names = BTreeMap::new();
    (rename(start, &mut names), rename(end, &mut names))
}

fn backward_dp_loop_search(
    trs: &Trs,
    pairs: &[DependencyPair],
    deadline: Option<Instant>,
    allow_collapsing: bool,
    frontier_limit: usize,
) -> Option<DpNonterminationProof> {
    // Dedicated search, separate from the cheap default mixed-loop lane.
    const MAX_BACKWARD_STEPS: usize = 16;
    // This explicitly selected symbolic lane must not inherit the tiny
    // frontier used by cheap default ground-loop probes. The caller deadline
    // still bounds each search, including separable-argument subsearches.
    if trs.strategy() != RewriteStrategy::Full {
        return None;
    }
    let marked_rules = pairs
        .iter()
        .map(DependencyPair::as_rule)
        .collect::<Vec<_>>();
    for pair in pairs {
        if !short_marked_root_can_return(trs, pairs, pair.lhs(), pair.rhs(), MAX_BACKWARD_STEPS - 1)
        {
            continue;
        }
        let first = LoopRewriteStep {
            position: vec![],
            rule: pair.as_rule(),
            result: pair.rhs().clone(),
        };
        let mut queue = VecDeque::from([(pair.lhs().clone(), pair.rhs().clone(), vec![first])]);
        let mut seen = BTreeSet::new();
        while let Some((start, end, steps)) = queue.pop_front() {
            if strategy_timed_out(deadline) {
                return None;
            }
            if let Some(proof) = checked_mixed_narrowing_closure(trs, pairs, &start, &end, &steps) {
                return Some(dp_loop_with_used_pair_rule_removal(pairs, proof));
            }
            if steps.len() >= MAX_BACKWARD_STEPS || seen.len() >= frontier_limit {
                continue;
            }
            for (position, subterm) in positions_with_subterms(&start) {
                if !allow_collapsing && matches!(subterm, Term::Var(_)) {
                    continue;
                }
                for (index, rule) in trs
                    .rules()
                    .iter()
                    .chain(marked_rules.iter().filter(|_| position.is_empty()))
                    .enumerate()
                {
                    if strategy_timed_out(deadline) {
                        return None;
                    }
                    // Inverse collapsing rules otherwise invent arbitrarily
                    // nested contexts even at unconstrained variables. Use
                    // structured targets and at most one occurrence of the new
                    // root along the ancestor path in this bounded lane.
                    if rule.rhs().root_symbol().is_none()
                        && (matches!(subterm, Term::Var(_))
                            || (0..position.len()).any(|length| {
                                subterm_at_position(&start, &position[..length])
                                    .and_then(Term::root_symbol)
                                    == rule.lhs().root_symbol()
                            }))
                    {
                        continue;
                    }
                    if (rule.rhs().root_symbol().is_none()
                        && (!allow_collapsing || position.is_empty()))
                        || (rule.rhs().root_symbol().is_some()
                            && subterm.root_symbol().is_some()
                            && rule.rhs().root_symbol() != subterm.root_symbol())
                    {
                        continue;
                    }
                    let fresh = freshen_rule(rule, index, steps.len() + 70_000);
                    let mut substitution = BTreeMap::new();
                    if !unify_terms(fresh.rhs(), subterm, &mut substitution) {
                        continue;
                    }
                    let instantiated_start = apply_substitution(&start, &substitution);
                    let lhs = apply_substitution(fresh.lhs(), &substitution);
                    let Some(predecessor) =
                        replace_subterm_at_position(&instantiated_start, &position, &lhs)
                    else {
                        continue;
                    };
                    let end = apply_substitution(&end, &substitution);
                    if !seen.insert(backward_endpoint_key(&predecessor, &end)) {
                        continue;
                    }
                    let mut path = vec![LoopRewriteStep {
                        position: position.clone(),
                        rule: fresh,
                        result: instantiated_start,
                    }];
                    path.extend(steps.iter().map(|step| LoopRewriteStep {
                        position: step.position.clone(),
                        rule: step.rule.clone(),
                        result: apply_substitution(&step.result, &substitution),
                    }));
                    queue.push_back((predecessor, end, path));
                }
            }
        }
    }
    None
}
