//! Bounded, one-shot symbolic string-loop search. No seed word or rewrite
//! sequence is supplied. Solver output is only a proposal: the ordinary loop
//! checker reconstructs and checks every original-rule step independently.
use super::*;
use crate::proving::dependency_pairs::{bv_literal, parse_bv_values, run_matrix_smt_script};

#[cfg(test)]
fn search(
    trs: &Trs,
    deadline: Option<Instant>,
    steps: usize,
    width: usize,
    solver: &str,
) -> Option<NonterminationProof> {
    search_with_start_width(trs, deadline, steps, width, width, solver)
}

pub(super) fn search_with_start_width(
    trs: &Trs,
    deadline: Option<Instant>,
    steps: usize,
    width: usize,
    start_width: usize,
    solver: &str,
) -> Option<NonterminationProof> {
    if trs.strategy() != RewriteStrategy::Full
        || !(1..=256).contains(&steps)
        || !(1..=128).contains(&width)
        || !(1..=width).contains(&start_width)
    {
        return None;
    }
    let rules = trs.srs_rules()?;
    if rules.is_empty() {
        return None;
    }
    let alphabet = rules
        .iter()
        .flat_map(|r| r.lhs().iter().chain(r.rhs()))
        .cloned()
        .collect::<BTreeSet<_>>()
        .into_iter()
        .collect::<Vec<_>>();
    if alphabet.is_empty() || alphabet.len() > 256 {
        return None;
    }
    let chars = alphabet
        .iter()
        .enumerate()
        .map(|(i, s)| (s.clone(), i))
        .collect::<BTreeMap<_, _>>();
    let bits = |n: usize| (usize::BITS - n.max(1).leading_zeros()) as usize;
    // Twice the maximum width covers all position/length additions without
    // modular overflow. Rule and step selectors use the same safe index sort.
    let iw = bits((2 * width + 1).max(steps + 1).max(rules.len() + 1));
    let cw = bits(alphabet.len());
    let bv = |n: usize| bv_literal(n as u128, iw);
    let ch = |n: usize| bv_literal(n as u128, cw);
    let mut script = String::from("(set-logic QF_ABV)\n");
    script += &format!(
        "(declare-const count (_ BitVec {iw}))\n(assert (and (bvugt count {}) (bvule count {})))\n",
        bv(0),
        bv(steps)
    );
    for t in 0..=steps {
        script += &format!(
            "(declare-const w{t} (Array (_ BitVec {iw}) (_ BitVec {cw})))\n(declare-const n{t} (_ BitVec {iw}))\n(assert (bvule n{t} {}))\n",
            bv(width)
        );
    }
    script += &format!("(assert (bvugt n0 {}))\n", bv(0));
    script += &format!("(assert (bvule n0 {}))\n", bv(start_width));
    for j in 0..width {
        script += &format!(
            "(declare-const c{j} (_ BitVec {cw}))\n(assert (= c{j} (select w0 {})))\n(assert (bvult c{j} {}))\n",
            bv(j),
            ch(alphabet.len())
        );
    }
    for t in 0..steps {
        if strategy_timed_out(deadline) {
            return None;
        }
        let next = t + 1;
        let active = format!("(bvult {} count)", bv(t));
        script += &format!(
            "(declare-const r{t} (_ BitVec {iw}))\n(declare-const p{t} (_ BitVec {iw}))\n(declare-const lhslen{t} (_ BitVec {iw}))\n(declare-const rhslen{t} (_ BitVec {iw}))\n(declare-const rhs{t} (Array (_ BitVec {iw}) (_ BitVec {cw})))\n"
        );
        let mut alternatives = Vec::new();
        for (ri, rule) in rules.iter().enumerate() {
            if rule.lhs().len() > width || rule.rhs().len() > width {
                continue;
            }
            let l = rule.lhs().len();
            let r = rule.rhs().len();
            let mut conditions = vec![
                format!("(= r{t} {})", bv(ri)),
                format!("(= lhslen{t} {})", bv(l)),
                format!("(= rhslen{t} {})", bv(r)),
            ];
            for (j, symbol) in rule.lhs().iter().enumerate() {
                conditions.push(format!(
                    "(= (select w{t} (bvadd p{t} {})) {})",
                    bv(j),
                    ch(chars[symbol])
                ));
            }
            for (j, symbol) in rule.rhs().iter().enumerate() {
                conditions.push(format!(
                    "(= (select rhs{t} {}) {})",
                    bv(j),
                    ch(chars[symbol])
                ));
            }
            alternatives.push(format!("(and {})", conditions.join(" ")));
        }
        if alternatives.is_empty() {
            return None;
        }
        script += &format!(
            "(assert (=> {active} (or {})))\n(assert (=> (not {active}) (and (= n{next} n{t}) (= w{next} w{t}))))\n",
            alternatives.join(" ")
        );
        // Share the shift/copy circuit across all rule alternatives. Previously
        // every rule duplicated this width-sized circuit (and a nested RHS
        // selector), even though only the selected lengths and symbols differ.
        script += &format!(
            "(assert (=> {active} (and (bvule p{t} n{t}) (bvule (bvadd p{t} lhslen{t}) n{t}) (= n{next} (bvadd (bvsub n{t} lhslen{t}) rhslen{t})))))\n"
        );
        for j in 0..width {
            script += &format!(
                "(assert (=> (and {active} (bvult {} n{next})) (= (select w{next} {}) (ite (bvult {} p{t}) (select w{t} {}) (ite (bvult {} (bvadd p{t} rhslen{t})) (select rhs{t} (bvsub {} p{t})) (select w{t} (bvsub (bvadd {} lhslen{t}) rhslen{t})))))))\n",
                bv(j),
                bv(j),
                bv(j),
                bv(j),
                bv(j),
                bv(j),
                bv(j)
            );
        }
    }
    script += &format!(
        "(declare-const offset (_ BitVec {iw}))\n(assert (and (bvule offset n{steps}) (bvule (bvadd offset n0) n{steps})))\n"
    );
    for j in 0..width {
        script += &format!(
            "(assert (=> (bvult {} n0) (= (select w0 {}) (select w{steps} (bvadd offset {})))))\n",
            bv(j),
            bv(j),
            bv(j)
        );
    }
    script += "(check-sat)\n(get-model)\n";
    crate::proving::runtime::write_progress_event(
        "srs-smt-loop",
        "encoded",
        "bounded-loop",
        0,
        &format!(
            "steps={steps} width={width} rules={} alphabet={} bytes={}",
            rules.len(),
            alphabet.len(),
            script.len()
        ),
    );
    let output = run_matrix_smt_script(&script, solver, deadline)?;
    if !output.starts_with("sat") {
        return None;
    }
    let values = parse_bv_values(&output)?;
    let value = |key: &str| usize::try_from(*values.get(key)?).ok();
    let n = value("n0")?;
    let count = value("count")?;
    if n == 0 || n > start_width || count == 0 || count > steps {
        return None;
    }
    let word = (0..n)
        .map(|j| alphabet.get(value(&format!("c{j}"))?).cloned())
        .collect::<Option<Vec<_>>>()?;
    let start = word_to_term_with_tail(&word, Term::var("_srs_smt_tail"));
    let mut current = word.clone();
    let mut term = start.clone();
    let mut trace = Vec::new();
    for t in 0..count {
        let ri = value(&format!("r{t}"))?;
        let pos = value(&format!("p{t}"))?;
        let rule = rules.get(ri)?;
        if pos.checked_add(rule.lhs().len())? > current.len()
            || current[pos..pos + rule.lhs().len()] != *rule.lhs()
        {
            return None;
        }
        current = replace_word_at(&current, pos, rule.lhs().len(), rule.rhs());
        if current.len() > width {
            return None;
        }
        let original = trs.rules().get(ri)?;
        let position = vec![1; pos];
        let subst = match_pattern(original.lhs(), subterm_at_position(&term, &position)?)?;
        term = replace_subterm_at_position(
            &term,
            &position,
            &apply_substitution(original.rhs(), &subst),
        )?;
        trace.push(LoopRewriteStep {
            position,
            rule: original.clone(),
            result: term.clone(),
        });
    }
    let (context_position, substitution) = closes_srs_loop(&word, &current, &start)?;
    let proof = LoopProof {
        start,
        steps: trace,
        context_position,
        substitution,
    };
    check_loop_proof_for_trs(trs, &proof).then_some(NonterminationProof::Loop(proof))
}

#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn bounded_smt_loop_search_checks_rules_and_rejects_decrease() {
        for (a, b) in [("a", "b"), ("renamed", "other")] {
            let trs = crate::parsing::parse_ari_trs(None, &format!("(format TRS) (fun {a} 1) (fun {b} 1) (rule ({a} x) ({b} ({a} x))) (rule ({b} ({a} x)) ({a} ({a} x)))")).unwrap();
            let Some(NonterminationProof::Loop(proof)) = search(
                &trs,
                Some(Instant::now() + Duration::from_secs(10)),
                3,
                4,
                "z3",
            ) else {
                panic!("loop expected")
            };
            assert!(check_loop_proof_for_trs(&trs, &proof));
        }
        let trs =
            crate::parsing::parse_ari_trs(None, "(format TRS) (fun a 1) (rule (a (a x)) (a x))")
                .unwrap();
        assert!(
            search(
                &trs,
                Some(Instant::now() + Duration::from_secs(10)),
                3,
                4,
                "z3"
            )
            .is_none()
        );
    }
    #[test]
    fn bounded_smt_loop_strategy_roundtrip() {
        let atom = "srs-smt-loop(steps=49,max-width=42,start-width=9,solver=z3)";
        assert_eq!(
            NonterminationStrategy::parse(atom)
                .unwrap()
                .to_strategy_atom(),
            atom
        );
        for atom in [
            "srs-smt-loop(steps=3,max-width=4,start-width=0)",
            "srs-smt-loop(steps=3,max-width=4,start-width=5)",
        ] {
            assert!(NonterminationStrategy::parse(atom).is_err());
        }
        let parsed =
            NonterminationStrategy::parse("srs-smt-loop(steps=24,max-width=12,solver=cvc5)")
                .unwrap();
        assert_eq!(
            NonterminationStrategy::parse(&parsed.to_strategy_atom()).unwrap(),
            parsed
        );
        assert!(NonterminationStrategy::parse("srs-smt-loop(steps=0,max-width=12)").is_err());
        assert!(
            NonterminationStrategy::parse("srs-smt-loop(steps=2,max-width=12,steps=3)").is_err()
        );
    }
    #[test]
    fn bounded_smt_loop_requires_real_multistep_cycle() {
        let trs = crate::parsing::parse_ari_trs(
            None,
            "(format TRS) (fun a 1) (fun b 1) (rule (a x) (b x)) (rule (b (b x)) (a (a x)))",
        )
        .unwrap();
        for solver in ["z3", "cvc5"] {
            assert!(
                search_with_start_width(
                    &trs,
                    Some(Instant::now() + Duration::from_secs(10)),
                    3,
                    2,
                    1,
                    solver
                )
                .is_none()
            );
            assert!(
                search_with_start_width(
                    &trs,
                    Some(Instant::now() + Duration::from_secs(10)),
                    3,
                    2,
                    2,
                    solver
                )
                .is_some()
            );
            assert!(
                search(
                    &trs,
                    Some(Instant::now() + Duration::from_secs(10)),
                    2,
                    2,
                    solver
                )
                .is_none()
            );
            let Some(NonterminationProof::Loop(proof)) = search(
                &trs,
                Some(Instant::now() + Duration::from_secs(10)),
                3,
                2,
                solver,
            ) else {
                panic!("three-step cycle expected")
            };
            assert_eq!(proof.steps.len(), 3);
            assert!(check_loop_proof_for_trs(&trs, &proof));
        }
    }
}
