use std::time::Instant;

use crate::core::{RewriteStrategy, Trs};
use crate::proving::NonterminationProof;
use crate::proving::runtime::current_thread_cancelled;

use super::{
    NonterminationStrategyProcessor, bounded_narrowing_loop, bounded_outermost_context_loop,
    bounded_outermost_rewriting_cycle, bounded_outermost_symbolic_cycle, bounded_rewriting_loop,
    bounded_rule_subset_narrowing_loop, dependency_pair_loop_hint_with,
    dependency_pair_nonloop_hint_with, direct_loop, dp_instantiation_proof,
    dp_loop_proof_with_rule_removal, dp_rewriting_proof, dp_symbolic_loop_proof,
    srs_derivation_pattern_nontermination, srs_rewriting_loop, variable_condition_violation,
};

/// Search for one independently checked terminal witness.
///
/// This is an algorithm shared by the ordinary and relative worklist
/// processors, not a second processor interface: scheduling, failure
/// classification, and proof reconstruction remain in `WorklistProcessor`.
pub(crate) fn search_nontermination_witness(
    trs: &Trs,
    processor: &NonterminationStrategyProcessor,
    deadline: Option<Instant>,
) -> Option<NonterminationProof> {
    if strategy_timed_out(deadline) {
        return None;
    }
    match processor {
        NonterminationStrategyProcessor::VariableCondition => variable_condition_violation(trs),
        NonterminationStrategyProcessor::ConstructorRecurrence => {
            super::constructor_recurrence::search(trs)
        }
        NonterminationStrategyProcessor::DirectLoop => {
            // This is the complete direct checked loop family for the active
            // rewrite strategy.  The outermost searches used to run as an
            // implicit top-level fallback after this atom failed, which made
            // strict oracle replay dishonest.  They now belong to this one
            // atomic processor and share its deadline.
            direct_loop(trs)
                .or_else(|| {
                    (trs.strategy() == RewriteStrategy::Outermost).then(|| {
                        bounded_outermost_symbolic_cycle(
                            trs,
                            local_deadline(deadline, std::time::Duration::from_millis(100)),
                        )
                    })?
                })
                .or_else(|| {
                    (trs.strategy() == RewriteStrategy::Outermost).then(|| {
                        bounded_outermost_context_loop(
                            trs,
                            local_deadline(deadline, std::time::Duration::from_millis(500)),
                        )
                    })?
                })
                .or_else(|| {
                    (trs.strategy() == RewriteStrategy::Outermost).then(|| {
                        bounded_outermost_rewriting_cycle(
                            trs,
                            local_deadline(deadline, std::time::Duration::from_millis(250)),
                        )
                    })?
                })
                .or_else(|| bounded_rewriting_loop(trs, deadline))
        }
        NonterminationStrategyProcessor::SrsLoop => srs_rewriting_loop(trs, deadline),
        NonterminationStrategyProcessor::SrsLoopDeep => {
            super::srs_rewriting_loop_with_depth(trs, deadline, 64)
        }
        NonterminationStrategyProcessor::SrsLoopBounded { max_steps } => {
            super::srs_rewriting_loop_with_depth(trs, deadline, *max_steps)
        }
        NonterminationStrategyProcessor::SrsOverlapLoop => {
            super::srs_context_extension_loop(trs, deadline)
        }
        NonterminationStrategyProcessor::SrsOverlapLoopNarrow => {
            super::srs_context_extension_loop_narrow(trs, deadline)
        }
        NonterminationStrategyProcessor::SrsOverlapLoopWide => {
            super::srs_context_extension_loop_wide(trs, deadline)
        }
        NonterminationStrategyProcessor::SrsOverlapLoopBounded { max_width } => {
            super::srs_context_extension_loop_bounded(trs, deadline, *max_width)
        }
        NonterminationStrategyProcessor::SrsOverlapLoopTarget { width, max_width, beam } => {
            super::srs_context_extension_loop_target(trs, deadline, *width, *max_width, *beam)
        }
        NonterminationStrategyProcessor::SrsNormalizedLoop { width, max_width } => {
            super::srs_normalized_loop(trs, deadline, *width, *max_width)
        }
        NonterminationStrategyProcessor::SrsEagerLoop { width, max_width } => {
            super::srs_eager_loop(trs, deadline, *width, *max_width)
        }
        NonterminationStrategyProcessor::SrsSmtLoop { steps, max_width, start_width, solver } => {
            super::srs_smt_loop::search_with_start_width(trs, deadline, *steps, *max_width, start_width.unwrap_or(*max_width), solver)
        }
        NonterminationStrategyProcessor::SrsFiniteLoop { max_width } => {
            super::srs_finite_loop::search(trs, deadline, *max_width, false)
        }
        NonterminationStrategyProcessor::SrsFiniteContextLoop { max_width } => {
            super::srs_finite_loop::search(trs, deadline, *max_width, true)
        }
        NonterminationStrategyProcessor::SrsComposeLoop { max_width, start_width } => {
            super::srs_composition::search(trs, deadline, *max_width, *start_width)
        }
        NonterminationStrategyProcessor::SrsTransportLoop => {
            super::srs_transport::search(trs, deadline)
        }
        NonterminationStrategyProcessor::SrsDerivationPatterns => {
            srs_derivation_pattern_nontermination(trs)
        }
        NonterminationStrategyProcessor::SrsDerivationPatternClosure => {
            srs_derivation_pattern_nontermination(trs)
                .or_else(|| super::srs_patterns::search(trs, deadline))
        }
        NonterminationStrategyProcessor::SrsDerivationPatternClosureDeep => {
            super::srs_patterns::search_with_closures(trs, deadline, 2)
        }
        NonterminationStrategyProcessor::RuleSubsetNarrowing => {
            bounded_rule_subset_narrowing_loop(trs, deadline)
        }
        NonterminationStrategyProcessor::BoundedNarrowing => bounded_narrowing_loop(trs, deadline),
        NonterminationStrategyProcessor::BoundedRewriting => bounded_rewriting_loop(trs, deadline),
        // CeTA's innermost DP nontermination format additionally requires a
        // certified normal-form-substitution obligation. Concrete innermost
        // rewrite-position checks alone do not establish that obligation.
        NonterminationStrategyProcessor::DependencyPairLoop
        | NonterminationStrategyProcessor::DependencyPairSymbolicLoop
        | NonterminationStrategyProcessor::DependencyPairBackwardLoop
        | NonterminationStrategyProcessor::DependencyPairRewriting
        | NonterminationStrategyProcessor::DependencyPairInstantiation
        | NonterminationStrategyProcessor::DependencyPairNonLoop
            if trs.strategy() == RewriteStrategy::Innermost =>
        {
            None
        }
        NonterminationStrategyProcessor::DependencyPairLoop => {
            dependency_pair_loop_hint_with(trs, deadline, dp_loop_proof_with_rule_removal)
        }
        NonterminationStrategyProcessor::DependencyPairSymbolicLoop => {
            dependency_pair_loop_hint_with(trs, deadline, dp_symbolic_loop_proof)
        }
        NonterminationStrategyProcessor::DependencyPairBackwardLoop => {
            dependency_pair_loop_hint_with(trs, deadline, super::backward_dp_loop_proof)
        }
        NonterminationStrategyProcessor::DependencyPairRewriting => {
            dependency_pair_loop_hint_with(trs, deadline, dp_rewriting_proof)
        }
        NonterminationStrategyProcessor::DependencyPairInstantiation => {
            dependency_pair_loop_hint_with(trs, deadline, dp_instantiation_proof)
        }
        NonterminationStrategyProcessor::DependencyPairNonLoop => {
            dependency_pair_nonloop_hint_with(trs, deadline)
        }
    }
}

fn local_deadline(deadline: Option<Instant>, allowance: std::time::Duration) -> Option<Instant> {
    let local = Instant::now() + allowance;
    Some(deadline.map_or(local, |outer| outer.min(local)))
}

pub(crate) fn strategy_timed_out(deadline: Option<Instant>) -> bool {
    current_thread_cancelled() || deadline.is_some_and(|deadline| Instant::now() >= deadline)
}
