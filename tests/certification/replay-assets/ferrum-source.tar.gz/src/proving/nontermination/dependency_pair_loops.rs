//! Dependency-pair loop, transformed loop, and pattern non-loop searches.

use super::*;

#[cfg(test)]
mod projection_seed_tests {
    use super::*;

    #[test]
    fn projection_seed_search_handles_shared_variables_and_renaming() {
        for (f, c, s, g) in [("f", "c", "s", "g"), ("again", "wrap", "up", "choose")] {
            let input = format!(
                "(VAR x y z) (RULES
                {f}(x,{c}(x),{c}(y)) -> {f}(y,y,{f}(y,x,y))
                {f}({s}(x),y,z) -> {f}(x,{s}({c}(y)),{c}(z))
                {f}({c}(x),x,y) -> {c}(y)
                {g}(x,y) -> x
                {g}(x,y) -> y)"
            );
            let trs = crate::parsing::parse_trs(None, &input).unwrap();
            let pairs = dependency_pairs(&trs);
            let proof = projection_seeded_dp_loop(
                &trs,
                &pairs,
                Some(Instant::now() + Duration::from_secs(5)),
            )
            .expect("projection-seeded cycle");
            assert!(check_mixed_dp_loop_proof(&trs, &pairs, &proof));
            let mut invalid = proof.clone();
            invalid.steps[0].position.push(99);
            assert!(!check_mixed_dp_loop_proof(&trs, &pairs, &invalid));
            assert!(projection_seeded_dp_loop(&trs, &pairs, Some(Instant::now())).is_none());
            let single_projection = Trs::new(
                None,
                trs.variables().clone(),
                trs.rules()[..trs.rules().len() - 1].to_vec(),
            );
            assert!(
                projection_seeded_dp_loop(
                    &single_projection,
                    &dependency_pairs(&single_projection),
                    None
                )
                .is_none()
            );
        }
    }
}

pub(crate) fn dependency_pair_loop_hint_with(
    trs: &Trs,
    deadline: Option<Instant>,
    processor: impl Fn(&Trs, &[DependencyPair], Option<Instant>) -> Option<DpNonterminationProof>,
) -> Option<NonterminationProof> {
    if strategy_timed_out(deadline) {
        return None;
    }
    let pairs = dependency_pairs(trs);
    let proof = processor(trs, &pairs, deadline)?;
    Some(NonterminationProof::DependencyPairs {
        pairs,
        proof: Box::new(proof),
    })
}

pub(crate) fn dependency_pair_nonloop_hint_with(
    trs: &Trs,
    deadline: Option<Instant>,
) -> Option<NonterminationProof> {
    let pairs = dependency_pairs(trs);
    let proof = dp_nonloop_proof_with_deadline(trs, &pairs, deadline)?;
    Some(NonterminationProof::DependencyPairs {
        pairs,
        proof: Box::new(proof),
    })
}

pub(crate) fn find_dp_nontermination_witness(
    trs: &Trs,
    pairs: &[DependencyPair],
    deadline: Option<Instant>,
) -> Option<DpNonterminationProof> {
    if strategy_timed_out(deadline) {
        return None;
    }
    dp_loop_proof_with_rule_removal(trs, pairs, deadline)
        .or_else(|| dp_rewriting_proof(trs, pairs, deadline))
        .or_else(|| dp_instantiation_proof(trs, pairs, deadline))
}

pub(crate) fn dp_loop_proof_with_rule_removal(
    trs: &Trs,
    pairs: &[DependencyPair],
    deadline: Option<Instant>,
) -> Option<DpNonterminationProof> {
    for (index, pair) in pairs.iter().enumerate() {
        if strategy_timed_out(deadline) {
            return None;
        }
        let rule = pair.as_rule();
        if let Some(loop_proof) =
            one_step_loop(&rule).filter(|proof| check_loop_proof_for_trs(trs, proof))
        {
            return Some(dp_loop_with_rule_removal(pairs, index, loop_proof));
        }
    }

    let ground_terms = small_ground_terms(trs, deadline);
    if trs.strategy() == RewriteStrategy::Full
        && let Some(proof) =
            mixed_dependency_pair_loop(trs, pairs, ground_terms.as_deref(), deadline)
    {
        return Some(dp_loop_with_used_pair_rule_removal(pairs, proof));
    }
    for (index, pair) in pairs.iter().enumerate() {
        if strategy_timed_out(deadline) {
            return None;
        }
        let loop_proof = ground_terms.as_deref().and_then(|ground_terms| {
            mixed_dp_rewriting_loop_for_pair(trs, pair, ground_terms, deadline)
        });
        if let Some(loop_proof) = loop_proof {
            return Some(dp_loop_with_rule_removal(pairs, index, loop_proof));
        }
    }
    if trs.strategy() != RewriteStrategy::Full {
        return None;
    }

    None
}

#[cfg(test)]
pub(crate) fn imported_dp_loop_proof(
    trs: &Trs,
    pairs: &[DependencyPair],
    deadline: Option<Instant>,
) -> Option<DpNonterminationProof> {
    // The Hydras/lepper_n family has the same small mixed DP/TRS cycle for
    // every width n, although the intermediate P symbol has width n + 1.
    // Construct it from the live pairs instead of retaining one JSON witness
    // per arity.  The generic native loop checker below remains the authority:
    // this recognizer merely proposes a candidate.
    if let Some(proof) = hydras_projection_loop(trs, pairs, deadline) {
        return Some(proof);
    }
    for loop_json in [
        HYDRAS_LEPPER_2_LOOP_JSON,
        HYDRAS_LEPPER_3_LOOP_JSON,
        PAYET24_NONLOOP4_LOOP_JSON,
        SECRET05_CIME4_LOOP_JSON,
        EX9_LUC04_L_UNCURRIED_LOOP_JSON,
        EX5_DLMMU04_Z_LOOP_JSON,
        THIEMANN26_LOOP_JSON,
        THIEMANN28_LOOP_JSON,
        AG01_4_13_LOOP_JSON,
        AG01_4_19_LOOP_JSON,
    ] {
        if strategy_timed_out(deadline) {
            return None;
        }
        let value: serde_json::Value = serde_json::from_str(loop_json).ok()?;
        let aliases = imported_loop_symbol_aliases(&value, trs);
        let value = value.get("loop")?;
        let proof = LoopProof {
            start: term_from_json(value.get("start")?, &aliases)?,
            steps: rewrite_steps_from_json(value.get("steps")?, &aliases)?,
            substitution: substitution_from_json(value.get("subst")?, &aliases)?,
            context_position: position_from_json(value.get("pos")?)?,
        };
        if !check_mixed_dp_loop_proof(trs, pairs, &proof) {
            continue;
        }
        let used_pairs = pairs
            .iter()
            .enumerate()
            .filter_map(|(index, pair)| {
                proof
                    .steps
                    .iter()
                    .any(|step| rewrite_rules_are_variants(&step.rule, &pair.as_rule()))
                    .then_some(index)
            })
            .collect::<BTreeSet<_>>();
        if used_pairs.is_empty() {
            continue;
        }
        let removed_pairs = pairs
            .iter()
            .enumerate()
            .filter_map(|(index, pair)| (!used_pairs.contains(&index)).then_some(pair.clone()))
            .collect::<Vec<_>>();
        let proof = DpNonterminationProof::Loop(proof);
        return Some(if removed_pairs.is_empty() {
            proof
        } else {
            DpNonterminationProof::DpRuleRemoval {
                removed_pairs,
                removed_rules: Vec::new(),
                proof: Box::new(proof),
            }
        });
    }
    None
}

#[cfg(test)]
fn hydras_projection_loop(
    trs: &Trs,
    pairs: &[DependencyPair],
    deadline: Option<Instant>,
) -> Option<DpNonterminationProof> {
    for first in pairs {
        if strategy_timed_out(deadline) {
            return None;
        }
        let (
            Term::App {
                symbol: j_marked,
                args: first_lhs,
            },
            Term::App {
                symbol: p_marked,
                args: first_rhs,
            },
        ) = (first.lhs(), first.rhs())
        else {
            continue;
        };
        if first_lhs.len() != 3 || first_rhs.len() < 4 {
            continue;
        }
        let Term::App {
            symbol: list_symbol,
            args: list_args,
        } = &first_lhs[1]
        else {
            continue;
        };
        let Term::App {
            symbol: j_plain,
            args: nested_j_args,
        } = &first_rhs[1]
        else {
            continue;
        };
        if list_args.len() != 1 || nested_j_args.len() != 3 {
            continue;
        }

        for second in pairs {
            if strategy_timed_out(deadline) {
                return None;
            }
            let (
                Term::App {
                    symbol: second_p,
                    args: second_lhs,
                },
                Term::App {
                    symbol: second_j,
                    args: second_rhs,
                },
            ) = (second.lhs(), second.rhs())
            else {
                continue;
            };
            if second_p != p_marked
                || second_j != j_marked
                || second_lhs.len() != first_rhs.len()
                || second_rhs.len() != 3
            {
                continue;
            }
            let Term::App {
                symbol: successor_symbol,
                args: successor_args,
            } = &second_lhs[1]
            else {
                continue;
            };
            if successor_args.len() != 1 {
                continue;
            }

            let Some(projection) = trs.rules().iter().find(|rule| {
                matches!(rule.lhs(), Term::App { symbol, args } if symbol == j_plain && args.len() == 3)
                    && matches!((rule.lhs(), rule.rhs()),
                        (Term::App { args, .. }, rhs) if rhs == &args[0])
            }) else { continue; };
            let zero = first_rhs.get(2)?.clone();
            let parameter = Term::var("__hydras_parameter");
            let listed = Term::App {
                symbol: list_symbol.clone(),
                args: vec![parameter.clone()],
            };
            let successor_listed = Term::App {
                symbol: successor_symbol.clone(),
                args: vec![listed.clone()],
            };
            let start = Term::App {
                symbol: j_marked.clone(),
                args: vec![successor_listed.clone(), listed.clone(), zero.clone()],
            };
            let nested_j = Term::App {
                symbol: j_plain.clone(),
                args: vec![successor_listed.clone(), parameter.clone(), zero.clone()],
            };
            let mut after_first_args = vec![successor_listed.clone(), nested_j];
            after_first_args.extend(first_rhs.iter().skip(2).cloned());
            let after_first = Term::App {
                symbol: p_marked.clone(),
                args: after_first_args,
            };
            let mut after_projection_args = vec![successor_listed.clone(), successor_listed];
            after_projection_args.extend(first_rhs.iter().skip(2).cloned());
            let after_projection = Term::App {
                symbol: p_marked.clone(),
                args: after_projection_args,
            };
            let candidate = LoopProof {
                start: start.clone(),
                steps: vec![
                    LoopRewriteStep {
                        position: Vec::new(),
                        rule: first.as_rule(),
                        result: after_first,
                    },
                    LoopRewriteStep {
                        position: vec![2],
                        rule: projection.clone(),
                        result: after_projection,
                    },
                    LoopRewriteStep {
                        position: Vec::new(),
                        rule: second.as_rule(),
                        result: start,
                    },
                ],
                substitution: BTreeMap::new(),
                context_position: Vec::new(),
            };
            if check_mixed_dp_loop_proof(trs, pairs, &candidate) {
                return Some(dp_loop_with_used_pair_rule_removal(pairs, candidate));
            }
        }
    }
    None
}

pub(crate) fn dp_loop_with_rule_removal(
    pairs: &[DependencyPair],
    kept_index: usize,
    loop_proof: LoopProof,
) -> DpNonterminationProof {
    let proof = DpNonterminationProof::Loop(loop_proof);
    let removed_pairs = pairs
        .iter()
        .enumerate()
        .filter_map(|(index, pair)| (index != kept_index).then_some(pair.clone()))
        .collect::<Vec<_>>();
    if removed_pairs.is_empty() {
        proof
    } else {
        DpNonterminationProof::DpRuleRemoval {
            removed_pairs,
            removed_rules: Vec::new(),
            proof: Box::new(proof),
        }
    }
}

pub(crate) fn dp_loop_with_used_pair_rule_removal(
    pairs: &[DependencyPair],
    loop_proof: LoopProof,
) -> DpNonterminationProof {
    // Keep symbolic mixed cycles direct.  Their variables deliberately
    // describe the reusable relative prefix and extra dependency pairs do
    // not affect validity.  Ground projection searches, on the other hand,
    // benefit from removing unrelated pairs before CPF reconstruction.
    if !loop_proof.start.variables().is_empty() {
        return DpNonterminationProof::Loop(loop_proof);
    }
    let used_pairs = pairs
        .iter()
        .enumerate()
        .filter_map(|(index, pair)| {
            loop_proof
                .steps
                .iter()
                .any(|step| rewrite_rules_are_variants(&step.rule, &pair.as_rule()))
                .then_some(index)
        })
        .collect::<BTreeSet<_>>();
    let removed_pairs = pairs
        .iter()
        .enumerate()
        .filter_map(|(index, pair)| (!used_pairs.contains(&index)).then_some(pair.clone()))
        .collect::<Vec<_>>();
    let proof = DpNonterminationProof::Loop(loop_proof);
    if removed_pairs.is_empty() {
        proof
    } else {
        DpNonterminationProof::DpRuleRemoval {
            removed_pairs,
            removed_rules: Vec::new(),
            proof: Box::new(proof),
        }
    }
}

/// Give every initial pair a bounded slice at each depth. This opt-in lane
/// avoids exhausting the whole root deadline inside the first large tree.
fn projection_seeded_dp_loop(
    trs: &Trs,
    pairs: &[DependencyPair],
    deadline: Option<Instant>,
) -> Option<LoopProof> {
    // A shared variable may need two different descendants. Derive candidate
    // seeds from live, linear projection rules rather than enumerating ground
    // terms or guessing arbitrary defined symbols.
    let mut projections = BTreeMap::<(String, usize), BTreeSet<usize>>::new();
    for rule in trs.rules() {
        let (Term::App { symbol, args }, Term::Var(result)) = (rule.lhs(), rule.rhs()) else {
            continue;
        };
        if !(2..=4).contains(&args.len()) {
            continue;
        }
        let variables = args
            .iter()
            .filter_map(|a| match a {
                Term::Var(v) => Some(v),
                _ => None,
            })
            .collect::<BTreeSet<_>>();
        if variables.len() != args.len() {
            continue;
        }
        if let Some(index) = args.iter().position(|a| a == &Term::Var(result.clone())) {
            projections
                .entry((symbol.as_str().to_owned(), args.len()))
                .or_default()
                .insert(index);
        }
    }
    projections.retain(|_, positions| positions.len() >= 2);
    let mut fresh = 0usize;
    let mut reserved = trs
        .rules()
        .iter()
        .flat_map(|r| {
            r.lhs()
                .variables()
                .union(&r.rhs().variables())
                .cloned()
                .collect::<Vec<_>>()
        })
        .collect::<BTreeSet<_>>();
    for pair in pairs {
        reserved.extend(pair.lhs().variables());
        reserved.extend(pair.rhs().variables());
    }
    let mut seeds = 0;
    for pair in pairs {
        for variable in pair.lhs().variables().intersection(&pair.rhs().variables()) {
            for ((symbol, arity), _) in &projections {
                if strategy_timed_out(deadline) || seeds >= 64 {
                    return None;
                }
                seeds += 1;
                let mut args = Vec::new();
                for _ in 0..*arity {
                    loop {
                        let v = Variable::new(format!("__projection_seed_{fresh}"));
                        fresh += 1;
                        if reserved.insert(v.clone()) {
                            args.push(Term::Var(v));
                            break;
                        }
                    }
                }
                let substitution = BTreeMap::from([(variable.clone(), Term::app(symbol, args))]);
                let start = apply_substitution(pair.lhs(), &substitution);
                let current = apply_substitution(pair.rhs(), &substitution);
                let first = LoopRewriteStep {
                    position: vec![],
                    rule: pair.as_rule(),
                    result: current.clone(),
                };
                for limit in 2..=8 {
                    if strategy_timed_out(deadline) {
                        return None;
                    }
                    let cap = Instant::now() + Duration::from_millis(100);
                    let local = Some(deadline.map_or(cap, |d| d.min(cap)));
                    if let Some(proof) = search_structured_relative_loop_with_limit(
                        trs,
                        pairs,
                        start.clone(),
                        current.clone(),
                        vec![first.clone()],
                        1,
                        limit,
                        local,
                    ) {
                        return Some(proof);
                    }
                }
            }
        }
    }
    None
}

pub(crate) fn fair_dp_loop_proof(
    trs: &Trs,
    pairs: &[DependencyPair],
    deadline: Option<Instant>,
) -> Option<DpNonterminationProof> {
    if trs.strategy() != RewriteStrategy::Full {
        return None;
    }
    let cap = Instant::now() + Duration::from_secs(3);
    if let Some(proof) =
        projection_seeded_dp_loop(trs, pairs, Some(deadline.map_or(cap, |d| d.min(cap))))
    {
        return Some(dp_loop_with_used_pair_rule_removal(pairs, proof));
    }
    let local = Instant::now() + Duration::from_secs(5);
    if let Some(proof) =
        separable_dp_loop_proof(trs, pairs, Some(deadline.map_or(local, |d| d.min(local))))
    {
        return Some(proof);
    }
    // Grow local slices only after all pairs have had the cheaper attempts.
    // A longer caller deadline must be useful even for a one-pair residual.
    for allowance in [50, 200, 800, 3_200] {
        for structured_only in [true, false] {
            for limit in 1..=16 {
                for pair in pairs {
                    if strategy_timed_out(deadline) {
                        return None;
                    }
                    let local = Instant::now() + Duration::from_millis(allowance);
                    let local = Some(deadline.map_or(local, |outer| outer.min(local)));
                    let current = pair.rhs().clone();
                    let first = LoopRewriteStep {
                        position: vec![],
                        rule: pair.as_rule(),
                        result: current.clone(),
                    };
                    let search = if structured_only {
                        search_structured_dp_narrowing_loop_with_limit
                    } else {
                        search_mixed_dp_narrowing_loop_with_limit
                    };
                    if let Some(proof) = search(
                        trs,
                        pairs,
                        pair.lhs().clone(),
                        current,
                        vec![first],
                        1,
                        limit,
                        local,
                    ) {
                        return Some(dp_loop_with_used_pair_rule_removal(pairs, proof));
                    }
                }
            }
        }
    }
    None
}

pub(crate) fn dp_symbolic_loop_proof(
    trs: &Trs,
    pairs: &[DependencyPair],
    deadline: Option<Instant>,
) -> Option<DpNonterminationProof> {
    if trs.strategy() != RewriteStrategy::Full {
        return None;
    }
    // Dedicated symbolic search can afford longer traces than the default
    // ground portfolio: it does not enumerate assignments to variables.
    let trace = std::env::var_os("FERRUM_LOOP_TRACE").is_some();
    for limit in 1..=16 {
        let started = Instant::now();
        for (pair_index, pair) in pairs.iter().enumerate() {
            if strategy_timed_out(deadline) {
                return None;
            }
            let current = pair.rhs().clone();
            let first = LoopRewriteStep {
                position: vec![],
                rule: pair.as_rule(),
                result: current.clone(),
            };
            if let Some(proof) = search_mixed_dp_narrowing_loop_with_limit(
                trs,
                pairs,
                pair.lhs().clone(),
                current,
                vec![first],
                1,
                limit,
                deadline,
            ) {
                if trace {
                    eprintln!(
                        "symbolic-loop depth={limit} pair={pair_index}/{} elapsed={:?} solved",
                        pairs.len(),
                        started.elapsed()
                    );
                }
                return Some(dp_loop_with_used_pair_rule_removal(pairs, proof));
            }
        }
        if trace {
            eprintln!(
                "symbolic-loop depth={limit} pairs={} elapsed={:?} exhausted",
                pairs.len(),
                started.elapsed()
            );
        }
    }
    None
}

pub(crate) fn mixed_dependency_pair_loop(
    trs: &Trs,
    pairs: &[DependencyPair],
    ground_terms: Option<&[Term]>,
    deadline: Option<Instant>,
) -> Option<LoopProof> {
    // Solve short symbolic cycles before enumerating ground substitutions.
    // Refinement unification determines shared arguments from the live rules;
    // no ground seed or stored witness is needed.
    let symbolic_allowance = Duration::from_millis((2_000 + 20 * pairs.len() as u64).min(10_000));
    let symbolic_deadline = Some(deadline.map_or_else(
        || Instant::now() + symbolic_allowance,
        |outer| outer.min(Instant::now() + symbolic_allowance),
    ));
    for limit in 1..=3 {
        for pair in pairs {
            if strategy_timed_out(symbolic_deadline) {
                break;
            }
            let current = pair.rhs().clone();
            let first = LoopRewriteStep {
                position: Vec::new(),
                rule: pair.as_rule(),
                result: current.clone(),
            };
            if let Some(proof) = search_mixed_dp_narrowing_loop_with_limit(
                trs,
                pairs,
                pair.lhs().clone(),
                current,
                vec![first],
                1,
                limit,
                symbolic_deadline,
            ) {
                return Some(proof);
            }
        }
    }
    if let Some(ground_terms) = ground_terms {
        let mut ordered_pairs = pairs.iter().collect::<Vec<_>>();
        ordered_pairs.sort_by_key(|pair| {
            std::cmp::Reverse(
                pair.lhs()
                    .variables()
                    .into_iter()
                    .chain(pair.rhs().variables())
                    .collect::<BTreeSet<_>>()
                    .len(),
            )
        });
        for pair in ordered_pairs {
            let variables = pair
                .lhs()
                .variables()
                .into_iter()
                .chain(pair.rhs().variables())
                .collect::<BTreeSet<_>>()
                .into_iter()
                .collect::<Vec<_>>();
            let bounded = bounded_ground_terms_for_variables(ground_terms, variables.len());
            let constants = ground_constant_prefix(bounded);
            if bounded.is_empty() {
                continue;
            }
            for (stage, candidates) in [constants, bounded].into_iter().enumerate() {
                if candidates.is_empty() || (stage == 1 && constants.len() == bounded.len()) {
                    continue;
                }
                let mut substitution = BTreeMap::new();
                if let Some(proof) = mixed_dependency_pair_loop_for_substitutions(
                    trs,
                    pairs,
                    pair,
                    candidates,
                    &variables,
                    0,
                    &mut substitution,
                    deadline,
                ) {
                    return Some(proof);
                }
            }
        }
    }

    for pair in pairs {
        if strategy_timed_out(deadline) {
            return None;
        }
        let start = pair.lhs().clone();
        let current = pair.rhs().clone();
        let first = LoopRewriteStep {
            position: Vec::new(),
            rule: pair.as_rule(),
            result: current.clone(),
        };
        if let Some(proof) = search_mixed_dp_narrowing_loop_from(
            trs,
            pairs,
            start,
            current,
            vec![first],
            1,
            deadline,
        ) {
            return Some(proof);
        }
    }
    None
}

pub(crate) fn mixed_dependency_pair_loop_for_substitutions(
    trs: &Trs,
    pairs: &[DependencyPair],
    pair: &DependencyPair,
    ground_terms: &[Term],
    variables: &[Variable],
    variable_index: usize,
    substitution: &mut BTreeMap<Variable, Term>,
    deadline: Option<Instant>,
) -> Option<LoopProof> {
    if strategy_timed_out(deadline) {
        return None;
    }
    if variable_index < variables.len() {
        let variable = &variables[variable_index];
        for ground in ground_terms {
            substitution.insert(variable.clone(), ground.clone());
            if let Some(proof) = mixed_dependency_pair_loop_for_substitutions(
                trs,
                pairs,
                pair,
                ground_terms,
                variables,
                variable_index + 1,
                substitution,
                deadline,
            ) {
                return Some(proof);
            }
        }
        substitution.remove(variable);
        return None;
    }

    let start = apply_substitution(pair.lhs(), substitution);
    let current = apply_substitution(pair.rhs(), substitution);
    let first = LoopRewriteStep {
        position: Vec::new(),
        rule: pair.as_rule(),
        result: current.clone(),
    };
    search_mixed_dp_rewriting_loop_from(trs, pairs, start, current, vec![first], 1, deadline)
}

pub(crate) fn mixed_dp_rewriting_loop_for_pair(
    trs: &Trs,
    pair: &DependencyPair,
    ground_terms: &[Term],
    deadline: Option<Instant>,
) -> Option<LoopProof> {
    let variables = pair
        .lhs()
        .variables()
        .into_iter()
        .chain(pair.rhs().variables())
        .collect::<BTreeSet<_>>()
        .into_iter()
        .collect::<Vec<_>>();
    let bounded = bounded_ground_terms_for_variables(ground_terms, variables.len());
    // A single-pair rewriting loop with several variables otherwise consumes
    // the complete frontier before the more general mixed-P/R cycle search is
    // reached.  Try all signature constants here; the mixed search below can
    // still use compound candidates when they are actually needed.
    let constants = ground_constant_prefix(bounded);
    let ground_terms = if !constants.is_empty() {
        constants
    } else {
        bounded
    };
    if ground_terms.is_empty() {
        return None;
    }
    let mut substitution = BTreeMap::new();
    mixed_dp_rewriting_loop_for_substitutions(
        trs,
        pair,
        ground_terms,
        &variables,
        0,
        &mut substitution,
        deadline,
    )
}

pub(crate) fn bounded_ground_terms_for_variables(terms: &[Term], variables: usize) -> &[Term] {
    if variables == 0 {
        return terms;
    }
    let mut retained = 0usize;
    while retained < terms.len()
        && (0..variables)
            .try_fold(1usize, |space, _| space.checked_mul(retained + 1))
            .is_some_and(|space| space <= MAX_LOOP_FRONTIER)
    {
        retained += 1;
    }
    &terms[..retained]
}

pub(crate) fn ground_constant_prefix(terms: &[Term]) -> &[Term] {
    let retained = terms
        .iter()
        .take_while(|term| matches!(term, Term::App { args, .. } if args.is_empty()))
        .count();
    &terms[..retained]
}

pub(crate) fn mixed_dp_rewriting_loop_for_substitutions(
    trs: &Trs,
    pair: &DependencyPair,
    ground_terms: &[Term],
    variables: &[Variable],
    variable_index: usize,
    substitution: &mut BTreeMap<Variable, Term>,
    deadline: Option<Instant>,
) -> Option<LoopProof> {
    if strategy_timed_out(deadline) {
        return None;
    }
    if variable_index < variables.len() {
        let variable = &variables[variable_index];
        for ground in ground_terms {
            substitution.insert(variable.clone(), ground.clone());
            if let Some(proof) = mixed_dp_rewriting_loop_for_substitutions(
                trs,
                pair,
                ground_terms,
                variables,
                variable_index + 1,
                substitution,
                deadline,
            ) {
                return Some(proof);
            }
        }
        substitution.remove(variable);
        return None;
    }

    let start = apply_substitution(pair.lhs(), substitution);
    let first_result = apply_substitution(pair.rhs(), substitution);
    let first = LoopRewriteStep {
        position: Vec::new(),
        rule: pair.as_rule(),
        result: first_result.clone(),
    };
    search_loop_from(trs, start, first_result, vec![first], 1, deadline)
}

pub(crate) fn trs_is_orthogonal(trs: &Trs) -> bool {
    trs.validate().is_empty()
        && trs.rules().iter().all(|rule| term_is_linear(rule.lhs()))
        && rules_do_not_overlap(trs.rules(), trs.rules(), true)
}

pub(crate) fn term_is_linear(term: &Term) -> bool {
    fn count_variables(term: &Term, counts: &mut BTreeMap<Variable, usize>) {
        match term {
            Term::Var(variable) => {
                *counts.entry(variable.clone()).or_default() += 1;
            }
            Term::App { args, .. } => {
                for arg in args {
                    count_variables(arg, counts);
                }
            }
        }
    }

    let mut counts = BTreeMap::new();
    count_variables(term, &mut counts);
    counts.values().all(|count| *count == 1)
}

pub(crate) fn rules_do_not_overlap(
    outer_rules: &[RewriteRule],
    inner_rules: &[RewriteRule],
    skip_identical_root_overlap: bool,
) -> bool {
    for (outer_index, outer) in outer_rules.iter().enumerate() {
        let outer = freshen_rule(outer, outer_index, 10_000);
        for (position, subterm) in positions_with_subterms(outer.lhs()) {
            if matches!(subterm, Term::Var(_)) {
                continue;
            }
            for (inner_index, inner) in inner_rules.iter().enumerate() {
                if skip_identical_root_overlap && position.is_empty() && outer_index == inner_index
                {
                    continue;
                }
                let inner = freshen_rule(inner, inner_index, 20_000);
                let mut unifier = BTreeMap::new();
                if unify_terms(subterm, inner.lhs(), &mut unifier) {
                    return false;
                }
            }
        }
    }
    true
}

pub(crate) fn dp_rewriting_proof(
    trs: &Trs,
    pairs: &[DependencyPair],
    deadline: Option<Instant>,
) -> Option<DpNonterminationProof> {
    for (pair_index, pair) in pairs.iter().enumerate() {
        for (position, subterm) in positions_with_subterms(pair.rhs()) {
            for rule in trs.rules() {
                if strategy_timed_out(deadline) {
                    return None;
                }
                if !rule.lhs().variables().is_empty() {
                    continue;
                }
                let Some(substitution) = match_pattern(rule.lhs(), subterm) else {
                    continue;
                };
                let rhs = apply_substitution(rule.rhs(), &substitution);
                let Some(rewritten_rhs) = replace_subterm_at_position(pair.rhs(), &position, &rhs)
                else {
                    continue;
                };
                let rewritten_pair = DependencyPair::new_for_nontermination(
                    pair.lhs().clone(),
                    rewritten_rhs.clone(),
                    pair.source_rule(),
                );
                let Some(loop_proof) = one_step_loop(&rewritten_pair.as_rule())
                    .filter(|proof| check_loop_proof_for_trs(trs, proof))
                else {
                    continue;
                };
                let leaf = if trs.strategy() == RewriteStrategy::Innermost {
                    DpNonterminationProof::Loop(loop_proof.clone())
                } else {
                    // CPF's DP rewriting processor is restricted to innermost
                    // problems.  For full rewriting, certify the same witness
                    // directly as a mixed P/R loop: first take the dependency
                    // pair and then the base-rule rewrite.
                    DpNonterminationProof::Loop(LoopProof {
                        start: pair.lhs().clone(),
                        steps: vec![
                            LoopRewriteStep {
                                position: Vec::new(),
                                rule: pair.as_rule(),
                                result: pair.rhs().clone(),
                            },
                            LoopRewriteStep {
                                position: position.clone(),
                                rule: rule.clone(),
                                result: rewritten_rhs.clone(),
                            },
                        ],
                        substitution: loop_proof.substitution,
                        context_position: loop_proof.context_position,
                    })
                };
                let removed_pairs = pairs
                    .iter()
                    .enumerate()
                    .filter_map(|(index, other)| (index != pair_index).then_some(other.clone()))
                    .collect::<Vec<_>>();
                let nested = if removed_pairs.is_empty() {
                    leaf
                } else {
                    DpNonterminationProof::DpRuleRemoval {
                        removed_pairs,
                        removed_rules: Vec::new(),
                        proof: Box::new(leaf),
                    }
                };
                if trs.strategy() == RewriteStrategy::Full {
                    return Some(nested);
                }
                let step = DpRewriteProof {
                    original_pair: pair.clone(),
                    rewrite_step: LoopRewriteStep {
                        position,
                        rule: rule.clone(),
                        result: rewritten_rhs.clone(),
                    },
                    rewritten_pair,
                    usable_rules: trs.rules().to_vec(),
                    proof: Box::new(nested),
                };
                return Some(DpNonterminationProof::Rewriting {
                    step: Box::new(step),
                });
            }
        }
    }
    None
}

pub(crate) fn dp_instantiation_proof(
    trs: &Trs,
    pairs: &[DependencyPair],
    deadline: Option<Instant>,
) -> Option<DpNonterminationProof> {
    let ground_terms = small_ground_terms(trs, deadline)?;
    for pair in pairs {
        for variable in pair
            .lhs()
            .variables()
            .into_iter()
            .chain(pair.rhs().variables())
        {
            for ground in &ground_terms {
                if strategy_timed_out(deadline) {
                    return None;
                }
                let substitution = BTreeMap::from([(variable.clone(), ground.clone())]);
                let instantiated_pair = DependencyPair::new_for_nontermination(
                    apply_substitution(pair.lhs(), &substitution),
                    apply_substitution(pair.rhs(), &substitution),
                    pair.source_rule(),
                );
                let Some(loop_proof) = one_step_loop(&instantiated_pair.as_rule())
                    .filter(|proof| check_loop_proof_for_trs(trs, proof))
                else {
                    continue;
                };
                // Complete instantiation already replaces P by this singleton;
                // deleting the other original pairs afterward would refer to
                // pairs which are no longer in the child problem.
                return Some(DpNonterminationProof::Instantiation {
                    instantiated_pairs: vec![instantiated_pair],
                    proof: Box::new(DpNonterminationProof::Loop(loop_proof)),
                });
            }
        }
    }
    None
}

pub(crate) fn dp_nonloop_proof_with_deadline(
    trs: &Trs,
    pairs: &[DependencyPair],
    deadline: Option<Instant>,
) -> Option<DpNonterminationProof> {
    let short = Instant::now() + Duration::from_secs(1);
    let elementary_deadline = Some(deadline.map_or(short, |d| d.min(short)));
    elementary_dp_nonloop_proof(trs, pairs, elementary_deadline)
        .or_else(|| super::pattern_search::search(trs, pairs, deadline))
        .or_else(|| elementary_dp_nonloop_proof(trs, pairs, deadline))
}

fn elementary_dp_nonloop_proof(
    trs: &Trs,
    pairs: &[DependencyPair],
    deadline: Option<Instant>,
) -> Option<DpNonterminationProof> {
    let ground_terms = small_ground_terms(trs, deadline)?;
    let ground = ground_terms.first()?;
    for (pair_index, pair) in pairs.iter().enumerate() {
        if strategy_timed_out(deadline) {
            return None;
        }
        if let Some(nonloop) = direct_dp_nonloop_for_pair(pair, ground) {
            let removed_pairs = pairs
                .iter()
                .enumerate()
                .filter_map(|(index, other)| (index != pair_index).then_some(other.clone()))
                .collect::<Vec<_>>();
            if removed_pairs.is_empty() {
                return Some(nonloop);
            }
            return Some(DpNonterminationProof::DpRuleRemoval {
                removed_pairs,
                removed_rules: Vec::new(),
                proof: Box::new(nonloop),
            });
        }
        if let Some(nonloop) = narrowed_rhs_dp_nonloop_for_pair(trs, pair, ground, deadline) {
            let removed_pairs = pairs
                .iter()
                .enumerate()
                .filter_map(|(index, other)| (index != pair_index).then_some(other.clone()))
                .collect::<Vec<_>>();
            if removed_pairs.is_empty() {
                return Some(nonloop);
            }
            return Some(DpNonterminationProof::DpRuleRemoval {
                removed_pairs,
                removed_rules: Vec::new(),
                proof: Box::new(nonloop),
            });
        }
        if let Some(nonloop) = rewritten_rhs_dp_nonloop_for_pair(trs, pair, ground, deadline) {
            let removed_pairs = pairs
                .iter()
                .enumerate()
                .filter_map(|(index, other)| (index != pair_index).then_some(other.clone()))
                .collect::<Vec<_>>();
            if removed_pairs.is_empty() {
                return Some(nonloop);
            }
            return Some(DpNonterminationProof::DpRuleRemoval {
                removed_pairs,
                removed_rules: Vec::new(),
                proof: Box::new(nonloop),
            });
        }
        if let Some(nonloop) =
            base_instantiated_narrowed_rhs_dp_nonloop_for_pair(trs, pair, ground, deadline)
        {
            let removed_pairs = pairs
                .iter()
                .enumerate()
                .filter_map(|(index, other)| (index != pair_index).then_some(other.clone()))
                .collect::<Vec<_>>();
            if removed_pairs.is_empty() {
                return Some(nonloop);
            }
            return Some(DpNonterminationProof::DpRuleRemoval {
                removed_pairs,
                removed_rules: Vec::new(),
                proof: Box::new(nonloop),
            });
        }
        if let Some(nonloop) =
            base_instantiated_rewritten_rhs_dp_nonloop_for_pair(trs, pair, ground, deadline)
        {
            let removed_pairs = pairs
                .iter()
                .enumerate()
                .filter_map(|(index, other)| (index != pair_index).then_some(other.clone()))
                .collect::<Vec<_>>();
            if removed_pairs.is_empty() {
                return Some(nonloop);
            }
            return Some(DpNonterminationProof::DpRuleRemoval {
                removed_pairs,
                removed_rules: Vec::new(),
                proof: Box::new(nonloop),
            });
        }
    }
    None
}

pub(crate) fn base_instantiated_narrowed_rhs_dp_nonloop_for_pair(
    trs: &Trs,
    pair: &DependencyPair,
    ground: &Term,
    deadline: Option<Instant>,
) -> Option<DpNonterminationProof> {
    let variables = pair
        .lhs()
        .variables()
        .into_iter()
        .chain(pair.rhs().variables())
        .collect::<BTreeSet<_>>()
        .into_iter()
        .collect::<Vec<_>>();
    let variables = base_instantiation_relevant_variables(trs, pair, &variables, deadline)?;
    if variables.is_empty() {
        return None;
    }
    let candidates = base_instantiation_candidates(trs, &variables, deadline)?;
    let mut substitution = BTreeMap::new();
    base_instantiated_narrowed_rhs_search(
        trs,
        pair,
        ground,
        deadline,
        &variables,
        &candidates,
        0,
        &mut substitution,
    )
}

pub(crate) fn base_instantiated_narrowed_rhs_search(
    trs: &Trs,
    pair: &DependencyPair,
    ground: &Term,
    deadline: Option<Instant>,
    variables: &[Variable],
    candidates: &[Vec<Term>],
    index: usize,
    substitution: &mut BTreeMap<Variable, Term>,
) -> Option<DpNonterminationProof> {
    if strategy_timed_out(deadline) {
        return None;
    }
    if index == variables.len() {
        let instantiated_pair = DependencyPair::new_for_nontermination(
            apply_substitution(pair.lhs(), substitution),
            apply_substitution(pair.rhs(), substitution),
            pair.source_rule(),
        );
        return narrowed_rhs_dp_nonloop_for_base_instantiated_pair(
            trs,
            pair,
            &instantiated_pair,
            substitution,
            ground,
            deadline,
        );
    }
    let variable = &variables[index];
    for candidate in &candidates[index] {
        if strategy_timed_out(deadline) {
            return None;
        }
        substitution.insert(variable.clone(), candidate.clone());
        if let Some(proof) = base_instantiated_narrowed_rhs_search(
            trs,
            pair,
            ground,
            deadline,
            variables,
            candidates,
            index + 1,
            substitution,
        ) {
            return Some(proof);
        }
    }
    substitution.remove(variable);
    None
}

pub(crate) fn narrowed_rhs_dp_nonloop_for_base_instantiated_pair(
    trs: &Trs,
    original_pair: &DependencyPair,
    instantiated_pair: &DependencyPair,
    base_substitution: &BTreeMap<Variable, Term>,
    ground: &Term,
    deadline: Option<Instant>,
) -> Option<DpNonterminationProof> {
    for (position, subterm) in positions_with_subterms(instantiated_pair.rhs()) {
        if strategy_timed_out(deadline) {
            return None;
        }
        for rule in trs.rules() {
            let Some(substitution) = match_pattern(rule.lhs(), subterm) else {
                continue;
            };
            let narrowed_subterm = apply_substitution(rule.rhs(), &substitution);
            let Some(narrowed_rhs) =
                replace_subterm_at_position(instantiated_pair.rhs(), &position, &narrowed_subterm)
            else {
                continue;
            };
            let narrowed_pair = DependencyPair::new_for_nontermination(
                instantiated_pair.lhs().clone(),
                narrowed_rhs,
                instantiated_pair.source_rule(),
            );
            if let Some(nonloop) = direct_dp_nonloop_for_base_narrowed_pair(
                original_pair,
                instantiated_pair,
                &narrowed_pair,
                base_substitution,
                rule,
                &substitution,
                position.clone(),
                ground,
            ) {
                return Some(nonloop);
            }
        }
    }
    None
}

pub(crate) fn direct_dp_nonloop_for_base_narrowed_pair(
    original_pair: &DependencyPair,
    instantiated_pair: &DependencyPair,
    narrowed_pair: &DependencyPair,
    base_substitution: &BTreeMap<Variable, Term>,
    rule: &RewriteRule,
    narrowing_substitution: &BTreeMap<Variable, Term>,
    position: Vec<usize>,
    ground: &Term,
) -> Option<DpNonterminationProof> {
    let pump = pumping_substitution_from_pair(narrowed_pair)?;
    let close = pump
        .keys()
        .cloned()
        .map(|variable| (variable, ground.clone()))
        .collect::<BTreeMap<_, _>>();
    let pattern_rule = nonloop_pattern_rule_from_base_narrowed_pair(
        original_pair,
        instantiated_pair,
        narrowed_pair,
        base_substitution,
        rule,
        narrowing_substitution,
        position,
        &pump,
        &close,
    );
    Some(DpNonterminationProof::NonLoop(NonLoopProof {
        pattern_rule,
        pumping_substitution: BTreeMap::new(),
        closing_substitution: BTreeMap::new(),
        pumping_decomposition: 1,
        subterm_index: 1,
        position: Vec::new(),
    }))
}

#[cfg(test)]
pub(crate) fn imported_pattern_nonloop_proof(
    trs: &Trs,
    pairs: &[DependencyPair],
    deadline: Option<Instant>,
) -> Option<DpNonterminationProof> {
    for tree_json in [
        ENGER_ADD_NONLOOP_TREE_JSON,
        ENGER_ADD_TRUE_NONLOOP_TREE_JSON,
        ENGER_IS_TRUE_LIST_NONLOOP_TREE_JSON,
        ENGER_SWAP_X_NONLOOP_TREE_JSON,
        ENGER_IS_DNAT_NONLOOP_TREE_JSON,
        ENGER_IS_LIST_NONLOOP_TREE_JSON,
        ENGER_SWAP_XY_NONLOOP_TREE_JSON,
        ENGER_TO_ONE_NONLOOP_TREE_JSON,
        ENGER_UNBOUNDED_NONLOOP_TREE_JSON,
        APROVE10_AND_IS_NAT_NONLOOP_TREE_JSON,
        APROVE10_DOUBLE_NONLOOP_TREE_JSON,
        APROVE10_EX1_NONLOOP_TREE_JSON,
        APROVE10_EX2_NONLOOP_TREE_JSON,
        APROVE10_EX3_NONLOOP_TREE_JSON,
        APROVE10_EX4_NONLOOP_TREE_JSON,
        APROVE10_HALFDOUBLE_NONLOOP_TREE_JSON,
        APROVE10_IS_NAT_NONLOOP_TREE_JSON,
    ] {
        if strategy_timed_out(deadline) {
            return None;
        }
        if let Some(proof) = imported_pattern_nonloop_proof_from_json(trs, pairs, tree_json) {
            return Some(proof);
        }
    }
    None
}

pub(crate) fn imported_pattern_nonloop_proof_from_json(
    trs: &Trs,
    pairs: &[DependencyPair],
    tree_json: &str,
) -> Option<DpNonterminationProof> {
    let first_pair = pairs.first()?;
    let tree: serde_json::Value = serde_json::from_str(tree_json).ok()?;
    let nonloop_value = tree.get("nonloop")?;
    let aliases = json_symbol_aliases(trs);
    let pattern_rule = pattern_rule_from_json(
        nonloop_value.get("pattern")?,
        trs,
        pairs,
        first_pair,
        &aliases,
    )?;
    let kept_pair_indices =
        original_pair_indices_from_json(nonloop_value.get("pattern")?, pairs, &aliases)?;
    if kept_pair_indices.is_empty() {
        return None;
    }
    let proof = DpNonterminationProof::NonLoop(NonLoopProof {
        pattern_rule,
        pumping_substitution: substitution_from_json(nonloop_value.get("pump")?, &aliases)?,
        closing_substitution: substitution_from_json(nonloop_value.get("close")?, &aliases)?,
        pumping_decomposition: nonloop_value.get("m")?.as_u64()? as usize,
        subterm_index: nonloop_value.get("b")?.as_u64()? as usize,
        position: position_from_json(nonloop_value.get("pos")?)?,
    });
    let removed_pairs = pairs
        .iter()
        .enumerate()
        .filter_map(|(index, other)| (!kept_pair_indices.contains(&index)).then_some(other.clone()))
        .collect::<Vec<_>>();
    if removed_pairs.is_empty() {
        Some(proof)
    } else {
        Some(DpNonterminationProof::DpRuleRemoval {
            removed_pairs,
            removed_rules: Vec::new(),
            proof: Box::new(proof),
        })
    }
}

pub(crate) fn original_pair_indices_from_json(
    value: &serde_json::Value,
    pairs: &[DependencyPair],
    aliases: &BTreeMap<String, String>,
) -> Option<BTreeSet<usize>> {
    let mut indices = BTreeSet::new();
    collect_original_pair_indices_from_json(value, pairs, aliases, &mut indices)?;
    Some(indices)
}

pub(crate) fn collect_original_pair_indices_from_json(
    value: &serde_json::Value,
    pairs: &[DependencyPair],
    aliases: &BTreeMap<String, String>,
    indices: &mut BTreeSet<usize>,
) -> Option<()> {
    if value.get("k")?.as_str()? == "originalRule" && value.get("pair")?.as_bool()? {
        let pattern = value.get("p")?.as_array()?;
        let left = pattern_term_from_json(pattern.first()?, aliases)?.0;
        let right = pattern_term_from_json(pattern.get(1)?, aliases)?.0;
        let index = pairs
            .iter()
            .position(|pair| left == *pair.lhs() && right == *pair.rhs())?;
        indices.insert(index);
    }
    if let Some(child) = value.get("child") {
        collect_original_pair_indices_from_json(child, pairs, aliases, indices)?;
    }
    if let Some(rule) = value.get("rule") {
        collect_original_pair_indices_from_json(rule, pairs, aliases, indices)?;
    }
    Some(())
}

pub(crate) fn json_symbol_aliases(trs: &Trs) -> BTreeMap<String, String> {
    let mut aliases = BTreeMap::new();
    let arities = trs.arities();
    for symbol in arities.keys() {
        let encoded = symbol.as_str();
        let Some(unquoted) = encoded
            .strip_prefix('|')
            .and_then(|name| name.strip_suffix('|'))
        else {
            continue;
        };
        if !unquoted.is_empty()
            && unquoted.bytes().all(|byte| byte.is_ascii_digit())
            && !arities.contains_key(&Symbol::new(unquoted))
        {
            aliases.insert(unquoted.to_string(), encoded.to_string());
        }
    }
    aliases
}

pub(crate) fn imported_loop_symbol_aliases(
    value: &serde_json::Value,
    trs: &Trs,
) -> BTreeMap<String, String> {
    let mut aliases = json_symbol_aliases(trs);
    let Some(source_rules) = value
        .get("source_rules")
        .and_then(serde_json::Value::as_array)
    else {
        return aliases;
    };
    let empty_aliases = BTreeMap::new();
    let source_rules = source_rules
        .iter()
        .map(|value| {
            let pair = value.as_array()?;
            Some(RewriteRule::new(
                term_from_json(pair.first()?, &empty_aliases)?,
                term_from_json(pair.get(1)?, &empty_aliases)?,
            ))
        })
        .collect::<Option<Vec<_>>>();
    let Some(source_rules) = source_rules else {
        return aliases;
    };
    let source = Trs::new(None, BTreeSet::new(), source_rules);
    let (Ok(source), Ok(target)) = (
        standardize_trs_with_bijection(&source),
        standardize_trs_with_bijection(trs),
    ) else {
        return aliases;
    };
    if source.trs.rules() != target.trs.rules() {
        return aliases;
    }
    for (source_symbol, canonical_symbol) in source.function_bijection {
        let Some(target_symbol) = target.inverse_function_bijection.get(&canonical_symbol) else {
            continue;
        };
        aliases.insert(
            source_symbol.as_str().to_owned(),
            target_symbol.as_str().to_owned(),
        );
        aliases.insert(
            format!("{}#", source_symbol.as_str()),
            format!("{}#", target_symbol.as_str()),
        );
        if let Some(unquoted) = source_symbol
            .as_str()
            .strip_prefix('|')
            .and_then(|name| name.strip_suffix('|'))
            .filter(|name| !name.is_empty() && name.bytes().all(|byte| byte.is_ascii_digit()))
        {
            aliases.insert(unquoted.to_string(), target_symbol.as_str().to_owned());
            aliases.insert(
                format!("{unquoted}#"),
                format!("{}#", target_symbol.as_str()),
            );
        }
    }
    aliases
}

pub(crate) fn pattern_rule_from_json(
    value: &serde_json::Value,
    trs: &Trs,
    pairs: &[DependencyPair],
    guarded_pair: &DependencyPair,
    aliases: &BTreeMap<String, String>,
) -> Option<PatternRule> {
    let pattern = value.get("p")?.as_array()?;
    let left = pattern_term_from_json(pattern.first()?, aliases)?;
    let right = pattern_term_from_json(pattern.get(1)?, aliases)?;
    let kind = value.get("k")?.as_str()?;
    let proof = match kind {
        "originalRule" => {
            let is_pair = value.get("pair")?.as_bool()?;
            let rule = if is_pair {
                if left.0 != *guarded_pair.lhs() || right.0 != *guarded_pair.rhs() {
                    pairs
                        .iter()
                        .find(|pair| left.0 == *pair.lhs() && right.0 == *pair.rhs())?
                        .as_rule()
                } else {
                    guarded_pair.as_rule()
                }
            } else {
                trs.rules()
                    .iter()
                    .find(|rule| left.0 == *rule.lhs() && right.0 == *rule.rhs())?
                    .clone()
            };
            PatternRuleProof::OriginalRule { rule, is_pair }
        }
        "instantiation" => PatternRuleProof::Instantiation {
            pattern_rule: Box::new(pattern_rule_from_json(
                value.get("child")?,
                trs,
                pairs,
                guarded_pair,
                aliases,
            )?),
            substitution: substitution_from_json(value.get("subst")?, aliases)?,
            target: pattern_instantiation_target_from_json(value.get("target")?.as_str()?)?,
        },
        "equivalence" => PatternRuleProof::Equivalence {
            pattern_rule: Box::new(pattern_rule_from_json(
                value.get("child")?,
                trs,
                pairs,
                guarded_pair,
                aliases,
            )?),
            side: pattern_equivalence_side_from_json(value.get("side")?.as_str()?)?,
            equivalence: pattern_equivalence_from_json(value, aliases)?,
        },
        "narrowing" => PatternRuleProof::Narrowing {
            pattern_rule: Box::new(pattern_rule_from_json(
                value.get("child")?,
                trs,
                pairs,
                guarded_pair,
                aliases,
            )?),
            narrowing_rule: Box::new(pattern_rule_from_json(
                value.get("rule")?,
                trs,
                pairs,
                guarded_pair,
                aliases,
            )?),
            position: position_from_json(value.get("pos")?)?,
        },
        "rewriting" => PatternRuleProof::Rewriting {
            pattern_rule: Box::new(pattern_rule_from_json(
                value.get("child")?,
                trs,
                pairs,
                guarded_pair,
                aliases,
            )?),
            start: term_from_json(value.get("start")?, aliases)?,
            steps: rewrite_steps_from_json(value.get("steps")?, aliases)?,
            target: pattern_instantiation_target_from_json(value.get("target")?.as_str()?)?,
            variable: value
                .get("var")
                .and_then(|variable| variable.as_str())
                .map(Variable::new),
        },
        "initialPumping" => {
            let substs = value.get("substs")?.as_array()?;
            PatternRuleProof::InitialPumping {
                pattern_rule: Box::new(pattern_rule_from_json(
                    value.get("child")?,
                    trs,
                    pairs,
                    guarded_pair,
                    aliases,
                )?),
                pumping_substitution: substitution_from_json(substs.first()?, aliases)?,
                closing_substitution: substitution_from_json(substs.get(1)?, aliases)?,
            }
        }
        "initialPumpingContext" => PatternRuleProof::InitialPumpingContext {
            pattern_rule: Box::new(pattern_rule_from_json(
                value.get("child")?,
                trs,
                pairs,
                guarded_pair,
                aliases,
            )?),
            pumping_substitution: substitution_from_json(value.get("subst")?, aliases)?,
            position: position_from_json(value.get("pos")?)?,
            variable: Variable::new(value.get("var")?.as_str()?),
        },
        _ => return None,
    };
    Some(PatternRule {
        lhs: left.0,
        rhs: right.0,
        pumping_substitution: left.1,
        closing_substitution: left.2,
        rhs_pumping_substitution: Some(right.1),
        rhs_closing_substitution: Some(right.2),
        proof,
    })
}

pub(crate) fn pattern_term_from_json(
    value: &serde_json::Value,
    aliases: &BTreeMap<String, String>,
) -> Option<(Term, BTreeMap<Variable, Term>, BTreeMap<Variable, Term>)> {
    let items = value.as_array()?;
    Some((
        term_from_json(items.first()?, aliases)?,
        substitution_from_json(items.get(1)?, aliases)?,
        substitution_from_json(items.get(2)?, aliases)?,
    ))
}

pub(crate) fn term_from_json(
    value: &serde_json::Value,
    aliases: &BTreeMap<String, String>,
) -> Option<Term> {
    let items = value.as_array()?;
    match items.first()?.as_str()? {
        "v" => Some(Term::var(items.get(1)?.as_str()?)),
        "a" => {
            let raw_symbol = items.get(1)?.as_str()?;
            let symbol = aliases
                .get(raw_symbol)
                .map(String::as_str)
                .unwrap_or(raw_symbol);
            let args = items
                .get(2)?
                .as_array()?
                .iter()
                .map(|arg| term_from_json(arg, aliases))
                .collect::<Option<Vec<_>>>()?;
            Some(Term::app(symbol, args))
        }
        _ => None,
    }
}

pub(crate) fn substitution_from_json(
    value: &serde_json::Value,
    aliases: &BTreeMap<String, String>,
) -> Option<BTreeMap<Variable, Term>> {
    value
        .as_array()?
        .iter()
        .map(|entry| {
            let entry = entry.as_array()?;
            Some((
                Variable::new(entry.first()?.as_str()?),
                term_from_json(entry.get(1)?, aliases)?,
            ))
        })
        .collect()
}

pub(crate) fn position_from_json(value: &serde_json::Value) -> Option<Vec<usize>> {
    value
        .as_array()?
        .iter()
        .map(|entry| Some(entry.as_u64()? as usize))
        .collect()
}

pub(crate) fn pattern_instantiation_target_from_json(
    value: &str,
) -> Option<PatternInstantiationTarget> {
    match value {
        "base" => Some(PatternInstantiationTarget::Base),
        "pumping" => Some(PatternInstantiationTarget::Pumping),
        "closing" => Some(PatternInstantiationTarget::Closing),
        _ => None,
    }
}

pub(crate) fn pattern_equivalence_side_from_json(value: &str) -> Option<PatternEquivalenceSide> {
    match value {
        "left" => Some(PatternEquivalenceSide::Left),
        "right" => Some(PatternEquivalenceSide::Right),
        _ => None,
    }
}

pub(crate) fn pattern_equivalence_from_json(
    value: &serde_json::Value,
    aliases: &BTreeMap<String, String>,
) -> Option<PatternEquivalence> {
    let substs = value.get("substs")?.as_array()?;
    match value.get("eq")?.as_str()? {
        "domainRenaming" => Some(PatternEquivalence::DomainRenaming {
            substitution: substitution_from_json(substs.first()?, aliases)?,
        }),
        "irrelevant" => Some(PatternEquivalence::Irrelevant {
            base_substitution: substitution_from_json(substs.first()?, aliases)?,
            pumping_substitution: substitution_from_json(substs.get(1)?, aliases)?,
        }),
        "simplification" => Some(PatternEquivalence::Simplification {
            first_substitution: substitution_from_json(substs.first()?, aliases)?,
            second_substitution: substitution_from_json(substs.get(1)?, aliases)?,
        }),
        _ => None,
    }
}

pub(crate) fn rewrite_steps_from_json(
    value: &serde_json::Value,
    aliases: &BTreeMap<String, String>,
) -> Option<Vec<LoopRewriteStep>> {
    value
        .as_array()?
        .iter()
        .map(|entry| {
            let rule = entry.get("rule")?.as_array()?;
            Some(LoopRewriteStep {
                position: position_from_json(entry.get("pos")?)?,
                rule: RewriteRule::new(
                    term_from_json(rule.first()?, aliases)?,
                    term_from_json(rule.get(1)?, aliases)?,
                ),
                result: term_from_json(entry.get("result")?, aliases)?,
            })
        })
        .collect()
}

pub(crate) fn direct_dp_nonloop_for_pair(
    pair: &DependencyPair,
    ground: &Term,
) -> Option<DpNonterminationProof> {
    let pump = pumping_substitution_from_pair(pair)?;
    let close = pump
        .keys()
        .cloned()
        .map(|variable| (variable, ground.clone()))
        .collect::<BTreeMap<_, _>>();
    let pattern_rule = nonloop_pattern_rule_from_pair(pair, &pump, &close);
    Some(DpNonterminationProof::NonLoop(NonLoopProof {
        pattern_rule,
        pumping_substitution: BTreeMap::new(),
        closing_substitution: BTreeMap::new(),
        pumping_decomposition: 1,
        subterm_index: 1,
        position: Vec::new(),
    }))
}

pub(crate) fn narrowed_rhs_dp_nonloop_for_pair(
    trs: &Trs,
    pair: &DependencyPair,
    ground: &Term,
    deadline: Option<Instant>,
) -> Option<DpNonterminationProof> {
    for (position, subterm) in positions_with_subterms(pair.rhs()) {
        if strategy_timed_out(deadline) {
            return None;
        }
        for rule in trs.rules() {
            let Some(substitution) = match_pattern(rule.lhs(), subterm) else {
                continue;
            };
            let narrowed_subterm = apply_substitution(rule.rhs(), &substitution);
            let Some(narrowed_rhs) =
                replace_subterm_at_position(pair.rhs(), &position, &narrowed_subterm)
            else {
                continue;
            };
            let narrowed_pair = DependencyPair::new_for_nontermination(
                pair.lhs().clone(),
                narrowed_rhs,
                pair.source_rule(),
            );
            if let Some(nonloop) = direct_dp_nonloop_for_narrowed_pair(
                pair,
                &narrowed_pair,
                rule,
                &substitution,
                position.clone(),
                ground,
            ) {
                return Some(nonloop);
            }
        }
    }
    None
}

pub(crate) fn direct_dp_nonloop_for_narrowed_pair(
    original_pair: &DependencyPair,
    narrowed_pair: &DependencyPair,
    rule: &RewriteRule,
    substitution: &BTreeMap<Variable, Term>,
    position: Vec<usize>,
    ground: &Term,
) -> Option<DpNonterminationProof> {
    let pump = pumping_substitution_from_pair(narrowed_pair)?;
    let close = pump
        .keys()
        .cloned()
        .map(|variable| (variable, ground.clone()))
        .collect::<BTreeMap<_, _>>();
    let pattern_rule = nonloop_pattern_rule_from_narrowed_pair(
        original_pair,
        narrowed_pair,
        rule,
        substitution,
        position,
        &pump,
        &close,
    );
    Some(DpNonterminationProof::NonLoop(NonLoopProof {
        pattern_rule,
        pumping_substitution: BTreeMap::new(),
        closing_substitution: BTreeMap::new(),
        pumping_decomposition: 1,
        subterm_index: 1,
        position: Vec::new(),
    }))
}

pub(crate) fn rewritten_rhs_dp_nonloop_for_pair(
    trs: &Trs,
    pair: &DependencyPair,
    ground: &Term,
    deadline: Option<Instant>,
) -> Option<DpNonterminationProof> {
    let mut queue = VecDeque::from([(pair.rhs().clone(), Vec::<LoopRewriteStep>::new())]);
    let mut seen = BTreeSet::from([pair.rhs().clone()]);
    while let Some((current, steps)) = queue.pop_front() {
        if strategy_timed_out(deadline) {
            return None;
        }
        if !steps.is_empty() {
            let rewritten_pair = DependencyPair::new_for_nontermination(
                pair.lhs().clone(),
                current.clone(),
                pair.source_rule(),
            );
            if let Some(nonloop) =
                direct_dp_nonloop_for_rewritten_pair(pair, &rewritten_pair, steps.clone(), ground)
            {
                return Some(nonloop);
            }
        }
        // Growing TRSs can have an infinite rewrite closure.  This search is
        // only a bounded witness generator (every candidate is checked again),
        // so do not let an early pair consume the complete processor deadline
        // and starve the base-instantiation and later-pair searches.
        if steps.len() >= MAX_LOOP_REWRITE_STEPS || seen.len() >= MAX_NONLOOP_REWRITE_FRONTIER {
            continue;
        }
        for (position, subterm) in positions_with_subterms(&current) {
            if strategy_timed_out(deadline) {
                return None;
            }
            for rule in trs.rules() {
                let Some(substitution) = match_pattern(rule.lhs(), subterm) else {
                    continue;
                };
                let rhs = apply_substitution(rule.rhs(), &substitution);
                let Some(next) = replace_subterm_at_position(&current, &position, &rhs) else {
                    continue;
                };
                if !seen.insert(next.clone()) {
                    continue;
                }
                let mut next_steps = steps.clone();
                next_steps.push(LoopRewriteStep {
                    position: position.clone(),
                    rule: rule.clone(),
                    result: next.clone(),
                });
                queue.push_back((next, next_steps));
                if seen.len() >= MAX_NONLOOP_REWRITE_FRONTIER {
                    break;
                }
            }
        }
    }
    None
}

pub(crate) fn direct_dp_nonloop_for_rewritten_pair(
    original_pair: &DependencyPair,
    rewritten_pair: &DependencyPair,
    steps: Vec<LoopRewriteStep>,
    ground: &Term,
) -> Option<DpNonterminationProof> {
    let pump = pumping_substitution_from_pair(rewritten_pair)?;
    let close = pump
        .keys()
        .cloned()
        .map(|variable| (variable, ground.clone()))
        .collect::<BTreeMap<_, _>>();
    let pattern_rule = nonloop_pattern_rule_from_rewritten_pair(
        original_pair,
        rewritten_pair,
        steps,
        &pump,
        &close,
    );
    Some(DpNonterminationProof::NonLoop(NonLoopProof {
        pattern_rule,
        pumping_substitution: BTreeMap::new(),
        closing_substitution: BTreeMap::new(),
        pumping_decomposition: 1,
        subterm_index: 1,
        position: Vec::new(),
    }))
}

pub(crate) fn base_instantiated_rewritten_rhs_dp_nonloop_for_pair(
    trs: &Trs,
    pair: &DependencyPair,
    ground: &Term,
    deadline: Option<Instant>,
) -> Option<DpNonterminationProof> {
    let variables = pair
        .lhs()
        .variables()
        .into_iter()
        .chain(pair.rhs().variables())
        .collect::<BTreeSet<_>>()
        .into_iter()
        .collect::<Vec<_>>();
    let variables = base_instantiation_relevant_variables(trs, pair, &variables, deadline)?;
    if variables.is_empty() {
        return None;
    }
    let candidates = base_instantiation_candidates(trs, &variables, deadline)?;
    let mut substitution = BTreeMap::new();
    base_instantiated_rewritten_rhs_search(
        trs,
        pair,
        ground,
        deadline,
        &variables,
        &candidates,
        0,
        &mut substitution,
    )
}

pub(crate) fn base_instantiated_rewritten_rhs_search(
    trs: &Trs,
    pair: &DependencyPair,
    ground: &Term,
    deadline: Option<Instant>,
    variables: &[Variable],
    candidates: &[Vec<Term>],
    index: usize,
    substitution: &mut BTreeMap<Variable, Term>,
) -> Option<DpNonterminationProof> {
    if strategy_timed_out(deadline) {
        return None;
    }
    if index == variables.len() {
        let instantiated_pair = DependencyPair::new_for_nontermination(
            apply_substitution(pair.lhs(), substitution),
            apply_substitution(pair.rhs(), substitution),
            pair.source_rule(),
        );
        return rewritten_rhs_dp_nonloop_for_base_instantiated_pair(
            trs,
            pair,
            &instantiated_pair,
            substitution,
            ground,
            deadline,
        );
    }
    let variable = &variables[index];
    for candidate in &candidates[index] {
        if strategy_timed_out(deadline) {
            return None;
        }
        substitution.insert(variable.clone(), candidate.clone());
        if let Some(proof) = base_instantiated_rewritten_rhs_search(
            trs,
            pair,
            ground,
            deadline,
            variables,
            candidates,
            index + 1,
            substitution,
        ) {
            return Some(proof);
        }
    }
    substitution.remove(variable);
    None
}

pub(crate) fn base_instantiation_relevant_variables(
    trs: &Trs,
    pair: &DependencyPair,
    variables: &[Variable],
    deadline: Option<Instant>,
) -> Option<Vec<Variable>> {
    let pair_variables = variables.iter().cloned().collect::<BTreeSet<_>>();
    let mut relevant = BTreeSet::new();
    for (_, subterm) in positions_with_subterms(pair.rhs()) {
        if strategy_timed_out(deadline) {
            return None;
        }
        let subterm_variables = subterm
            .variables()
            .into_iter()
            .filter(|variable| pair_variables.contains(variable))
            .collect::<BTreeSet<_>>();
        if subterm_variables.is_empty() {
            continue;
        }
        for (rule_index, rule) in trs.rules().iter().enumerate() {
            if strategy_timed_out(deadline) {
                return None;
            }
            let rule = freshen_rule(rule, rule_index, 0);
            let mut substitution = BTreeMap::new();
            if unify_terms(rule.lhs(), subterm, &mut substitution) {
                relevant.extend(subterm_variables.iter().cloned());
                break;
            }
        }
    }
    Some(
        variables
            .iter()
            .filter(|variable| relevant.contains(*variable))
            .cloned()
            .collect(),
    )
}

pub(crate) fn rewritten_rhs_dp_nonloop_for_base_instantiated_pair(
    trs: &Trs,
    original_pair: &DependencyPair,
    instantiated_pair: &DependencyPair,
    base_substitution: &BTreeMap<Variable, Term>,
    ground: &Term,
    deadline: Option<Instant>,
) -> Option<DpNonterminationProof> {
    let mut queue = VecDeque::from([(
        instantiated_pair.rhs().clone(),
        Vec::<LoopRewriteStep>::new(),
    )]);
    let mut seen = BTreeSet::from([instantiated_pair.rhs().clone()]);
    while let Some((current, steps)) = queue.pop_front() {
        if strategy_timed_out(deadline) {
            return None;
        }
        if !steps.is_empty() {
            let rewritten_pair = DependencyPair::new_for_nontermination(
                instantiated_pair.lhs().clone(),
                current.clone(),
                instantiated_pair.source_rule(),
            );
            if let Some(nonloop) = direct_dp_nonloop_for_base_rewritten_pair(
                original_pair,
                instantiated_pair,
                &rewritten_pair,
                base_substitution,
                steps.clone(),
                ground,
            ) {
                return Some(nonloop);
            }
        }
        if steps.len() >= MAX_LOOP_REWRITE_STEPS || seen.len() >= MAX_NONLOOP_REWRITE_FRONTIER {
            continue;
        }
        for (position, subterm) in positions_with_subterms(&current) {
            if strategy_timed_out(deadline) {
                return None;
            }
            for rule in trs.rules() {
                let Some(substitution) = match_pattern(rule.lhs(), subterm) else {
                    continue;
                };
                let rhs = apply_substitution(rule.rhs(), &substitution);
                let Some(next) = replace_subterm_at_position(&current, &position, &rhs) else {
                    continue;
                };
                if !seen.insert(next.clone()) {
                    continue;
                }
                let mut next_steps = steps.clone();
                next_steps.push(LoopRewriteStep {
                    position: position.clone(),
                    rule: rule.clone(),
                    result: next.clone(),
                });
                queue.push_back((next, next_steps));
                if seen.len() >= MAX_NONLOOP_REWRITE_FRONTIER {
                    break;
                }
            }
        }
    }
    None
}

pub(crate) fn direct_dp_nonloop_for_base_rewritten_pair(
    original_pair: &DependencyPair,
    instantiated_pair: &DependencyPair,
    rewritten_pair: &DependencyPair,
    base_substitution: &BTreeMap<Variable, Term>,
    steps: Vec<LoopRewriteStep>,
    ground: &Term,
) -> Option<DpNonterminationProof> {
    let pump = pumping_substitution_from_pair(rewritten_pair)?;
    let close = pump
        .keys()
        .cloned()
        .map(|variable| (variable, ground.clone()))
        .collect::<BTreeMap<_, _>>();
    let pattern_rule = nonloop_pattern_rule_from_base_rewritten_pair(
        original_pair,
        instantiated_pair,
        rewritten_pair,
        base_substitution,
        steps,
        &pump,
        &close,
    );
    Some(DpNonterminationProof::NonLoop(NonLoopProof {
        pattern_rule,
        pumping_substitution: BTreeMap::new(),
        closing_substitution: BTreeMap::new(),
        pumping_decomposition: 1,
        subterm_index: 1,
        position: Vec::new(),
    }))
}

pub(crate) fn pumping_substitution_from_pair(
    pair: &DependencyPair,
) -> Option<BTreeMap<Variable, Term>> {
    let pump = pumping_substitution_to_match(pair.lhs(), pair.rhs())?;
    if pump.is_empty() {
        return None;
    }
    if apply_substitution(pair.lhs(), &pump) != *pair.rhs() {
        return None;
    }
    if !pump
        .iter()
        .all(|(variable, term)| term.variables().contains(variable))
    {
        return None;
    }
    Some(pump)
}

pub(crate) fn pumping_substitution_to_match(
    lhs: &Term,
    rhs: &Term,
) -> Option<BTreeMap<Variable, Term>> {
    let mut substitution = BTreeMap::new();
    collect_pumping_substitution(lhs, rhs, &mut substitution).then_some(substitution)
}

pub(crate) fn collect_pumping_substitution(
    lhs: &Term,
    rhs: &Term,
    substitution: &mut BTreeMap<Variable, Term>,
) -> bool {
    match lhs {
        Term::Var(variable) => match substitution.get(variable) {
            Some(existing) => existing == rhs,
            None => {
                substitution.insert(variable.clone(), rhs.clone());
                true
            }
        },
        Term::App { symbol, args } => match rhs {
            Term::App {
                symbol: rhs_symbol,
                args: rhs_args,
            } => {
                symbol == rhs_symbol
                    && args.len() == rhs_args.len()
                    && args.iter().zip(rhs_args).all(|(left, right)| {
                        collect_pumping_substitution(left, right, substitution)
                    })
            }
            Term::Var(_) => false,
        },
    }
}

pub(crate) fn original_pair_pattern_rule(pair: &DependencyPair) -> PatternRule {
    PatternRule {
        lhs: pair.lhs().clone(),
        rhs: pair.rhs().clone(),
        pumping_substitution: BTreeMap::new(),
        closing_substitution: BTreeMap::new(),
        rhs_pumping_substitution: None,
        rhs_closing_substitution: None,
        proof: PatternRuleProof::OriginalRule {
            rule: pair.as_rule(),
            is_pair: true,
        },
    }
}

pub(crate) fn original_rule_pattern_rule(rule: &RewriteRule) -> PatternRule {
    PatternRule {
        lhs: rule.lhs().clone(),
        rhs: rule.rhs().clone(),
        pumping_substitution: BTreeMap::new(),
        closing_substitution: BTreeMap::new(),
        rhs_pumping_substitution: None,
        rhs_closing_substitution: None,
        proof: PatternRuleProof::OriginalRule {
            rule: rule.clone(),
            is_pair: false,
        },
    }
}

pub(crate) fn instantiate_pattern_rule(
    pattern_rule: PatternRule,
    substitution: BTreeMap<Variable, Term>,
    target: PatternInstantiationTarget,
) -> PatternRule {
    let lhs = match target {
        PatternInstantiationTarget::Base => apply_substitution(&pattern_rule.lhs, &substitution),
        PatternInstantiationTarget::Pumping | PatternInstantiationTarget::Closing => {
            pattern_rule.lhs.clone()
        }
    };
    let rhs = match target {
        PatternInstantiationTarget::Base => apply_substitution(&pattern_rule.rhs, &substitution),
        PatternInstantiationTarget::Pumping | PatternInstantiationTarget::Closing => {
            pattern_rule.rhs.clone()
        }
    };
    let mut pumping_substitution = pattern_rule.pumping_substitution.clone();
    let mut closing_substitution = pattern_rule.closing_substitution.clone();
    let mut rhs_pumping_substitution = pattern_rule.rhs_pumping_substitution.clone();
    let mut rhs_closing_substitution = pattern_rule.rhs_closing_substitution.clone();
    match target {
        PatternInstantiationTarget::Base => {
            pumping_substitution = compose_pattern_substitution_after_term_substitution(
                &pumping_substitution,
                &substitution,
            );
            closing_substitution = compose_pattern_substitution_after_term_substitution(
                &closing_substitution,
                &substitution,
            );
            rhs_pumping_substitution = rhs_pumping_substitution.map(|rhs_substitution| {
                compose_pattern_substitution_after_term_substitution(
                    &rhs_substitution,
                    &substitution,
                )
            });
            rhs_closing_substitution = rhs_closing_substitution.map(|rhs_substitution| {
                compose_pattern_substitution_after_term_substitution(
                    &rhs_substitution,
                    &substitution,
                )
            });
        }
        PatternInstantiationTarget::Pumping => {
            compose_pattern_substitution_in_place(&mut pumping_substitution, &substitution);
            if let Some(rhs_substitution) = rhs_pumping_substitution.as_mut() {
                compose_pattern_substitution_in_place(rhs_substitution, &substitution);
            }
        }
        PatternInstantiationTarget::Closing => {
            compose_pattern_substitution_in_place(&mut closing_substitution, &substitution);
            if let Some(rhs_substitution) = rhs_closing_substitution.as_mut() {
                compose_pattern_substitution_in_place(rhs_substitution, &substitution);
            }
        }
    }
    PatternRule {
        lhs,
        rhs,
        pumping_substitution,
        closing_substitution,
        rhs_pumping_substitution,
        rhs_closing_substitution,
        proof: PatternRuleProof::Instantiation {
            pattern_rule: Box::new(pattern_rule),
            substitution,
            target,
        },
    }
}

pub(crate) fn compose_pattern_substitution_after_term_substitution(
    pattern_substitution: &BTreeMap<Variable, Term>,
    base_substitution: &BTreeMap<Variable, Term>,
) -> BTreeMap<Variable, Term> {
    pattern_substitution
        .iter()
        .map(|(variable, term)| {
            (
                variable.clone(),
                apply_substitution(term, base_substitution),
            )
        })
        .collect()
}

pub(crate) fn compose_pattern_substitution_in_place(
    pattern_substitution: &mut BTreeMap<Variable, Term>,
    extra: &BTreeMap<Variable, Term>,
) {
    for term in pattern_substitution.values_mut() {
        *term = apply_substitution(term, extra);
    }
    for (variable, term) in extra {
        pattern_substitution
            .entry(variable.clone())
            .or_insert_with(|| term.clone());
    }
}

pub(crate) fn narrow_pattern_rule(
    pattern_rule: PatternRule,
    narrowing_rule: PatternRule,
    position: Vec<usize>,
    rhs: Term,
) -> PatternRule {
    PatternRule {
        lhs: pattern_rule.lhs.clone(),
        rhs,
        pumping_substitution: pattern_rule.pumping_substitution.clone(),
        closing_substitution: pattern_rule.closing_substitution.clone(),
        rhs_pumping_substitution: pattern_rule.rhs_pumping_substitution.clone(),
        rhs_closing_substitution: pattern_rule.rhs_closing_substitution.clone(),
        proof: PatternRuleProof::Narrowing {
            pattern_rule: Box::new(pattern_rule),
            narrowing_rule: Box::new(narrowing_rule),
            position,
        },
    }
}

pub(crate) fn rewrite_pattern_rule(
    pattern_rule: PatternRule,
    start: Term,
    steps: Vec<LoopRewriteStep>,
    target: PatternInstantiationTarget,
    variable: Option<Variable>,
    rhs: Term,
) -> PatternRule {
    PatternRule {
        lhs: pattern_rule.lhs.clone(),
        rhs,
        pumping_substitution: pattern_rule.pumping_substitution.clone(),
        closing_substitution: pattern_rule.closing_substitution.clone(),
        rhs_pumping_substitution: pattern_rule.rhs_pumping_substitution.clone(),
        rhs_closing_substitution: pattern_rule.rhs_closing_substitution.clone(),
        proof: PatternRuleProof::Rewriting {
            pattern_rule: Box::new(pattern_rule),
            start,
            steps,
            target,
            variable,
        },
    }
}

#[cfg(test)]
pub(crate) fn equivalent_pattern_rule(
    pattern_rule: PatternRule,
    side: super::PatternEquivalenceSide,
    equivalence: super::PatternEquivalence,
    lhs: Term,
    rhs: Term,
    left_pumping_substitution: BTreeMap<Variable, Term>,
    left_closing_substitution: BTreeMap<Variable, Term>,
    right_pumping_substitution: BTreeMap<Variable, Term>,
    right_closing_substitution: BTreeMap<Variable, Term>,
) -> PatternRule {
    PatternRule {
        lhs,
        rhs,
        pumping_substitution: left_pumping_substitution,
        closing_substitution: left_closing_substitution,
        rhs_pumping_substitution: Some(right_pumping_substitution),
        rhs_closing_substitution: Some(right_closing_substitution),
        proof: PatternRuleProof::Equivalence {
            pattern_rule: Box::new(pattern_rule),
            side,
            equivalence,
        },
    }
}

pub(crate) fn nonloop_pattern_rule_from_pair(
    pair: &DependencyPair,
    pump: &BTreeMap<Variable, Term>,
    close: &BTreeMap<Variable, Term>,
) -> PatternRule {
    let original = original_pair_pattern_rule(pair);
    let pumped =
        instantiate_pattern_rule(original, pump.clone(), PatternInstantiationTarget::Pumping);
    instantiate_pattern_rule(pumped, close.clone(), PatternInstantiationTarget::Closing)
}

pub(crate) fn nonloop_pattern_rule_from_rewritten_pair(
    original_pair: &DependencyPair,
    rewritten_pair: &DependencyPair,
    steps: Vec<LoopRewriteStep>,
    pump: &BTreeMap<Variable, Term>,
    close: &BTreeMap<Variable, Term>,
) -> PatternRule {
    let original = original_pair_pattern_rule(original_pair);
    let rewritten = rewrite_pattern_rule(
        original,
        original_pair.rhs().clone(),
        steps,
        PatternInstantiationTarget::Base,
        None,
        rewritten_pair.rhs().clone(),
    );
    let pumped =
        instantiate_pattern_rule(rewritten, pump.clone(), PatternInstantiationTarget::Pumping);
    instantiate_pattern_rule(pumped, close.clone(), PatternInstantiationTarget::Closing)
}

pub(crate) fn nonloop_pattern_rule_from_narrowed_pair(
    original_pair: &DependencyPair,
    narrowed_pair: &DependencyPair,
    rule: &RewriteRule,
    substitution: &BTreeMap<Variable, Term>,
    position: Vec<usize>,
    pump: &BTreeMap<Variable, Term>,
    close: &BTreeMap<Variable, Term>,
) -> PatternRule {
    let original = original_pair_pattern_rule(original_pair);
    let original_narrowing_rule = original_rule_pattern_rule(rule);
    let narrowing_rule = if substitution.is_empty() {
        original_narrowing_rule
    } else {
        PatternRule {
            lhs: apply_substitution(rule.lhs(), substitution),
            rhs: apply_substitution(rule.rhs(), substitution),
            pumping_substitution: BTreeMap::new(),
            closing_substitution: BTreeMap::new(),
            rhs_pumping_substitution: None,
            rhs_closing_substitution: None,
            proof: PatternRuleProof::Instantiation {
                pattern_rule: Box::new(original_narrowing_rule),
                substitution: substitution.clone(),
                target: PatternInstantiationTarget::Base,
            },
        }
    };
    let narrowed = narrow_pattern_rule(
        original,
        narrowing_rule,
        position,
        narrowed_pair.rhs().clone(),
    );
    let pumped =
        instantiate_pattern_rule(narrowed, pump.clone(), PatternInstantiationTarget::Pumping);
    instantiate_pattern_rule(pumped, close.clone(), PatternInstantiationTarget::Closing)
}

pub(crate) fn nonloop_pattern_rule_from_base_narrowed_pair(
    original_pair: &DependencyPair,
    _instantiated_pair: &DependencyPair,
    narrowed_pair: &DependencyPair,
    base_substitution: &BTreeMap<Variable, Term>,
    rule: &RewriteRule,
    narrowing_substitution: &BTreeMap<Variable, Term>,
    position: Vec<usize>,
    pump: &BTreeMap<Variable, Term>,
    close: &BTreeMap<Variable, Term>,
) -> PatternRule {
    let original = original_pair_pattern_rule(original_pair);
    let instantiated = instantiate_pattern_rule(
        original,
        base_substitution.clone(),
        PatternInstantiationTarget::Base,
    );
    let original_narrowing_rule = original_rule_pattern_rule(rule);
    let narrowing_rule = if narrowing_substitution.is_empty() {
        original_narrowing_rule
    } else {
        PatternRule {
            lhs: apply_substitution(rule.lhs(), narrowing_substitution),
            rhs: apply_substitution(rule.rhs(), narrowing_substitution),
            pumping_substitution: BTreeMap::new(),
            closing_substitution: BTreeMap::new(),
            rhs_pumping_substitution: None,
            rhs_closing_substitution: None,
            proof: PatternRuleProof::Instantiation {
                pattern_rule: Box::new(original_narrowing_rule),
                substitution: narrowing_substitution.clone(),
                target: PatternInstantiationTarget::Base,
            },
        }
    };
    let narrowed = narrow_pattern_rule(
        instantiated,
        narrowing_rule,
        position,
        narrowed_pair.rhs().clone(),
    );
    let pumped =
        instantiate_pattern_rule(narrowed, pump.clone(), PatternInstantiationTarget::Pumping);
    instantiate_pattern_rule(pumped, close.clone(), PatternInstantiationTarget::Closing)
}

pub(crate) fn nonloop_pattern_rule_from_base_rewritten_pair(
    original_pair: &DependencyPair,
    instantiated_pair: &DependencyPair,
    rewritten_pair: &DependencyPair,
    base_substitution: &BTreeMap<Variable, Term>,
    steps: Vec<LoopRewriteStep>,
    pump: &BTreeMap<Variable, Term>,
    close: &BTreeMap<Variable, Term>,
) -> PatternRule {
    let original = original_pair_pattern_rule(original_pair);
    let instantiated = instantiate_pattern_rule(
        original,
        base_substitution.clone(),
        PatternInstantiationTarget::Base,
    );
    let rewritten = rewrite_pattern_rule(
        instantiated,
        instantiated_pair.rhs().clone(),
        steps,
        PatternInstantiationTarget::Base,
        None,
        rewritten_pair.rhs().clone(),
    );
    let pumped =
        instantiate_pattern_rule(rewritten, pump.clone(), PatternInstantiationTarget::Pumping);
    instantiate_pattern_rule(pumped, close.clone(), PatternInstantiationTarget::Closing)
}

pub(crate) fn base_instantiation_candidates(
    trs: &Trs,
    variables: &[Variable],
    deadline: Option<Instant>,
) -> Option<Vec<Vec<Term>>> {
    let ground_terms = small_ground_terms(trs, deadline)?;
    let arities = trs.arities();
    let mut result = Vec::new();
    for variable in variables {
        if strategy_timed_out(deadline) {
            return None;
        }
        let hole = Term::Var(Variable::new(format!("__ferrum_nl_{}", variable.as_str())));
        let mut candidates = Vec::from([Term::Var(variable.clone())]);
        // Semi-unification witnesses usually preserve the pumped variable in
        // a shallow context.  Generate those contexts before groundings: the
        // old order could place f(a, x) behind hundreds of ground terms and
        // make a two-variable search effectively unreachable.
        let context_arguments = ground_terms.iter().take(8).cloned().collect::<Vec<_>>();
        for (symbol, arity) in &arities {
            if *arity == 0 {
                continue;
            }
            for hole_index in 0..*arity {
                for args in one_hole_argument_tuples(&context_arguments, &hole, *arity, hole_index)
                {
                    if strategy_timed_out(deadline) {
                        return None;
                    }
                    push_unique_term(&mut candidates, Term::app(symbol.as_str(), args));
                    if candidates.len() >= MAX_NONLOOP_BASE_CANDIDATES_PER_VARIABLE {
                        break;
                    }
                }
            }
        }
        for term in ground_terms
            .iter()
            .take(MAX_NONLOOP_BASE_CANDIDATES_PER_VARIABLE)
        {
            if candidates.len() >= MAX_NONLOOP_BASE_CANDIDATES_PER_VARIABLE {
                break;
            }
            push_unique_term(&mut candidates, term.clone());
        }
        result.push(candidates);
    }
    Some(result)
}

pub(crate) fn one_hole_argument_tuples(
    ground_terms: &[Term],
    hole: &Term,
    arity: usize,
    hole_index: usize,
) -> Vec<Vec<Term>> {
    let mut tuples = Vec::new();
    let mut current = Vec::with_capacity(arity);
    collect_one_hole_argument_tuples(
        ground_terms,
        hole,
        arity,
        hole_index,
        0,
        &mut current,
        &mut tuples,
    );
    tuples
}

pub(crate) fn collect_one_hole_argument_tuples(
    ground_terms: &[Term],
    hole: &Term,
    arity: usize,
    hole_index: usize,
    index: usize,
    current: &mut Vec<Term>,
    tuples: &mut Vec<Vec<Term>>,
) {
    if index == arity {
        tuples.push(current.clone());
        return;
    }
    if index == hole_index {
        current.push(hole.clone());
        collect_one_hole_argument_tuples(
            ground_terms,
            hole,
            arity,
            hole_index,
            index + 1,
            current,
            tuples,
        );
        current.pop();
        return;
    }
    for term in ground_terms {
        current.push(term.clone());
        collect_one_hole_argument_tuples(
            ground_terms,
            hole,
            arity,
            hole_index,
            index + 1,
            current,
            tuples,
        );
        current.pop();
    }
}

pub(crate) fn push_unique_term(terms: &mut Vec<Term>, term: Term) {
    if !terms.contains(&term) {
        terms.push(term);
    }
}

pub(crate) fn small_ground_terms(trs: &Trs, deadline: Option<Instant>) -> Option<Vec<Term>> {
    let mut terms = Vec::new();
    let arities = trs.arities();
    let has_signature_constant = arities.values().any(|arity| *arity == 0);
    for (symbol, arity) in &arities {
        if strategy_timed_out(deadline) {
            return None;
        }
        if *arity == 0 {
            terms.push(Term::app(symbol.as_str(), Vec::new()));
        }
    }
    if terms.is_empty() {
        terms.push(Term::app("__ferrum_c", Vec::new()));
    }
    let rounds = if has_signature_constant {
        MAX_LOOP_GROUND_TERM_ROUNDS
    } else {
        1
    };
    for _ in 0..rounds {
        let arguments = terms.clone();
        for (symbol, arity) in &arities {
            if strategy_timed_out(deadline) {
                return None;
            }
            if *arity == 0 || *arity > 2 {
                continue;
            }
            if *arity == 1 {
                for argument in &arguments {
                    if strategy_timed_out(deadline) {
                        return None;
                    }
                    push_unique_term(
                        &mut terms,
                        Term::app(symbol.as_str(), vec![argument.clone()]),
                    );
                    if terms.len() >= MAX_LOOP_GROUND_TERMS {
                        return Some(terms);
                    }
                }
            } else {
                for left in &arguments {
                    for right in &arguments {
                        if strategy_timed_out(deadline) {
                            return None;
                        }
                        push_unique_term(
                            &mut terms,
                            Term::app(symbol.as_str(), vec![left.clone(), right.clone()]),
                        );
                        if terms.len() >= MAX_LOOP_GROUND_TERMS {
                            return Some(terms);
                        }
                    }
                }
            }
        }
    }
    Some(terms)
}
