//! Bounded transport-system discovery, expanded to checked ordinary loops.
//!
//! For blocks x and a pivot p, synthesize x p ->* p phi(x). Thus
//! w p^k ->* p^k phi^k(w). We only accept when the expanded derivation is
//! nonempty and its target contains its source. No morphism is trusted.
//! Reference: Waldmann, AJRW 2007, "Non-Termination", Lindenmayer loops.

use super::*;

type Word = Vec<Symbol>;
type Trace = Vec<(usize, usize)>;
type LocalDerivations = Vec<(Word, Trace)>;
const MAX_WORD: usize = 4096;
const MAX_STEPS: usize = 4096;

#[derive(Clone)]
struct Move {
    image: Vec<usize>,
    trace: Trace,
}

pub(super) fn search(trs: &Trs, deadline: Option<Instant>) -> Option<NonterminationProof> {
    if trs.strategy() != RewriteStrategy::Full || strategy_timed_out(deadline) {
        return None;
    }
    let rules = trs.srs_rules()?;
    let forward = rules
        .iter()
        .map(|r| (r.lhs().to_vec(), r.rhs().to_vec()))
        .collect::<Vec<_>>();
    let half =
        deadline.map(|end| Instant::now() + end.saturating_duration_since(Instant::now()) / 2);
    search_direction(trs, &forward, false, half).or_else(|| {
        let reversed = forward
            .iter()
            .map(|(l, r)| {
                (
                    l.iter().cloned().rev().collect(),
                    r.iter().cloned().rev().collect(),
                )
            })
            .collect::<Vec<_>>();
        search_direction(trs, &reversed, true, deadline)
    })
}

fn search_direction(
    trs: &Trs,
    rules: &[(Word, Word)],
    reversed: bool,
    deadline: Option<Instant>,
) -> Option<NonterminationProof> {
    // Every seed and extension is computed from the live rules, not names or
    // external loop terms. A seed only proposes a pivot; local moves are found
    // afresh and the final trace is independently validated.
    let mut candidates = Vec::new();
    let mut seen = BTreeSet::new();
    for (l, r) in rules {
        for n in 1..=l.len().min(r.len()) {
            if l[l.len() - n..] != r[..n] {
                continue;
            }
            let a = &l[..l.len() - n];
            let p = &r[..n];
            let c = &r[n..];
            if a.is_empty() || c.is_empty() {
                continue;
            }
            for k in 0..=c.len().min(8) {
                let candidate = (
                    a.to_vec(),
                    [p, &c[..k]].concat(),
                    [&c[k..], &c[..k]].concat(),
                );
                if seen.insert(candidate.clone()) {
                    candidates.push(candidate);
                }
            }
            for k in 1..a.len() {
                let candidate = (
                    [&a[k..], &a[..k]].concat(),
                    [&a[k..], p].concat(),
                    c.to_vec(),
                );
                if seen.insert(candidate.clone()) {
                    candidates.push(candidate);
                }
            }
        }
    }
    // Short moving blocks and images tend to admit small decompositions. Sort
    // only on lengths, retaining construction order for equal-size candidates.
    candidates.sort_by_key(|(a, p, c)| (a.len() + c.len(), p.len()));
    for (a, p, c) in candidates {
        if strategy_timed_out(deadline) {
            return None;
        }
        if c.len() > 24 || p.len() > 32 {
            continue;
        }
        let mut alphabets = Vec::new();
        let mut seen_alphabets = BTreeSet::new();
        partitions(
            &c,
            &mut vec![a],
            &mut alphabets,
            &mut seen_alphabets,
            deadline,
        );
        let mut cache = BTreeMap::<Word, LocalDerivations>::new();
        for blocks in alphabets {
            if strategy_timed_out(deadline) {
                return None;
            }
            let Some(pivot_blocks) = segment(&p, &blocks) else {
                continue;
            };
            let mut moves = Vec::new();
            for x in &blocks {
                let derivations = cache
                    .entry(x.clone())
                    .or_insert_with(|| local_moves(x, &p, rules, deadline));
                let found = derivations.iter().find_map(|(end, trace)| {
                    Some(Move {
                        image: segment(end, &blocks)?,
                        trace: trace.clone(),
                    })
                });
                let Some(found) = found else {
                    break;
                };
                moves.push(found);
            }
            if moves.len() != blocks.len() || moves.iter().all(|m| m.trace.is_empty()) {
                continue;
            }
            for start in 0..blocks.len() {
                if let Some(proof) = expand(
                    trs,
                    rules,
                    reversed,
                    &blocks,
                    &pivot_blocks,
                    &moves,
                    start,
                    deadline,
                ) {
                    return Some(proof);
                }
            }
        }
    }
    None
}

// Enumerate distinct small block alphabets induced by factorizations, not
// arbitrary words over the signature. Deadlines and output caps bound search.
fn partitions(
    rest: &[Symbol],
    blocks: &mut Vec<Word>,
    out: &mut Vec<Vec<Word>>,
    seen: &mut BTreeSet<Vec<Word>>,
    deadline: Option<Instant>,
) {
    if out.len() >= 2048 || strategy_timed_out(deadline) {
        return;
    }
    if rest.is_empty() {
        let mut key = blocks.clone();
        key.sort();
        if seen.insert(key) {
            out.push(blocks.clone());
        }
        return;
    }
    for n in 1..=rest.len().min(16) {
        let w = rest[..n].to_vec();
        let fresh = !blocks.contains(&w);
        if fresh && blocks.len() >= 4 {
            continue;
        }
        if fresh {
            blocks.push(w);
        }
        partitions(&rest[n..], blocks, out, seen, deadline);
        if fresh {
            blocks.pop();
        }
        if out.len() >= 2048 || strategy_timed_out(deadline) {
            break;
        }
    }
}

fn segment(word: &[Symbol], blocks: &[Word]) -> Option<Vec<usize>> {
    let mut paths: Vec<Option<Vec<usize>>> = vec![None; word.len() + 1];
    paths[word.len()] = Some(Vec::new());
    for i in (0..word.len()).rev() {
        for (j, b) in blocks.iter().enumerate() {
            if word_has_at(word, b, i) {
                if let Some(tail) = &paths[i + b.len()] {
                    let mut path = vec![j];
                    path.extend_from_slice(tail);
                    paths[i] = Some(path);
                    break;
                }
            }
        }
    }
    paths[0].take()
}

fn local_moves(
    x: &[Symbol],
    p: &[Symbol],
    rules: &[(Word, Word)],
    deadline: Option<Instant>,
) -> LocalDerivations {
    let source = [x, p].concat();
    let mut queue = VecDeque::from([(source.clone(), Trace::new())]);
    let mut seen = BTreeSet::from([source]);
    let mut result = Vec::new();
    while let Some((word, trace)) = queue.pop_front() {
        if strategy_timed_out(deadline) {
            break;
        }
        if word.starts_with(p) {
            result.push((word[p.len()..].to_vec(), trace.clone()));
            if result.len() >= 16 {
                break;
            }
        }
        if trace.len() >= 3 || seen.len() >= 512 {
            continue;
        }
        for (i, (l, r)) in rules.iter().enumerate() {
            for at in 0..=word.len().saturating_sub(l.len()) {
                if !word_has_at(&word, l, at) {
                    continue;
                }
                let next = replace_word_at(&word, at, l.len(), r);
                if next.len() > 128 || !seen.insert(next.clone()) {
                    continue;
                }
                let mut steps = trace.clone();
                steps.push((i, at));
                queue.push_back((next, steps));
            }
        }
    }
    result
}

#[allow(clippy::too_many_arguments)]
fn expand(
    trs: &Trs,
    rules: &[(Word, Word)],
    reversed: bool,
    blocks: &[Word],
    pivot: &[usize],
    moves: &[Move],
    start_block: usize,
    deadline: Option<Instant>,
) -> Option<NonterminationProof> {
    let flatten = |xs: &[usize]| {
        xs.iter()
            .flat_map(|&i| blocks[i].iter().cloned())
            .collect::<Word>()
    };
    let p = flatten(pivot);
    let mut source = blocks[start_block].clone();
    let mut image = vec![start_block];
    let mut trace = Trace::new();
    let mut extensions = 0usize;
    // Obtain S p^e ->* A S B, then freeze A S while transporting the suffix.
    for _ in 0..4096 {
        if strategy_timed_out(deadline) || trace.len() > MAX_STEPS {
            return None;
        }
        let word = flatten(&image);
        if word.len() > MAX_WORD || source.len() > MAX_WORD {
            return None;
        }
        if !trace.is_empty() && contains_word(&word, &source) {
            return checked_trace(trs, rules, reversed, source, trace, deadline);
        }
        if !trace.is_empty() {
            if let Some(i) = (0..image.len()).find(|&i| {
                image[i] == start_block
                    && image[i + 1..].iter().any(|&j| !moves[j].trace.is_empty())
            }) {
                let offset = image[..=i].iter().map(|&j| blocks[j].len()).sum::<usize>();
                let mut suffix = image[i + 1..].to_vec();
                // B p^f ->* p^(e+f) C closes S p^(e+f) ->+ A S p^(e+f) C.
                for _ in 0..4096 {
                    if strategy_timed_out(deadline) || trace.len() > MAX_STEPS {
                        return None;
                    }
                    let tail = flatten(&suffix);
                    if offset + tail.len() > MAX_WORD || source.len() > MAX_WORD {
                        return None;
                    }
                    let power = (0..extensions)
                        .flat_map(|_| p.iter().cloned())
                        .collect::<Word>();
                    if tail.starts_with(&power) {
                        return checked_trace(trs, rules, reversed, source, trace, deadline);
                    }
                    if transport_step(&mut suffix, pivot, blocks, moves, &mut trace, offset) {
                        extensions += 1;
                        source.extend_from_slice(&p);
                    }
                }
                return None;
            }
        }
        if transport_step(&mut image, pivot, blocks, moves, &mut trace, 0) {
            extensions += 1;
            source.extend_from_slice(&p);
        }
    }
    None
}

// True exactly when a new trailing pivot was required. Schedule productive
// moves only; identity commutations are represented by the block alphabet.
fn transport_step(
    image: &mut Vec<usize>,
    pivot: &[usize],
    blocks: &[Word],
    moves: &[Move],
    trace: &mut Trace,
    base: usize,
) -> bool {
    let Some(i) = (0..image.len())
        .find(|&i| !moves[image[i]].trace.is_empty() && image[i + 1..].starts_with(pivot))
    else {
        image.extend_from_slice(pivot);
        return true;
    };
    let offset = base + image[..i].iter().map(|&j| blocks[j].len()).sum::<usize>();
    let m = &moves[image[i]];
    trace.extend(m.trace.iter().map(|&(rule, pos)| (rule, offset + pos)));
    image.splice(
        i..i + 1 + pivot.len(),
        pivot.iter().chain(m.image.iter()).copied(),
    );
    false
}

fn checked_trace(
    trs: &Trs,
    rules: &[(Word, Word)],
    reversed: bool,
    source: Word,
    trace: Trace,
    deadline: Option<Instant>,
) -> Option<NonterminationProof> {
    if trace.is_empty() {
        return None;
    }
    let mut word = source.clone();
    let mut original_trace = Trace::new();
    for (i, at) in trace {
        if strategy_timed_out(deadline) {
            return None;
        }
        let (l, r) = &rules[i];
        if !word_has_at(&word, l, at) {
            return None;
        }
        original_trace.push((
            i,
            if reversed {
                word.len() - at - l.len()
            } else {
                at
            },
        ));
        word = replace_word_at(&word, at, l.len(), r);
        if word.len() > MAX_WORD {
            return None;
        }
    }
    let original = |w: Word| {
        if reversed {
            w.into_iter().rev().collect::<Word>()
        } else {
            w
        }
    };
    let source = original(source);
    let target = original(word);
    let start = word_to_term_with_tail(&source, Term::var("_transport_tail"));
    let (context_position, substitution) = closes_srs_loop(&source, &target, &start)?;
    let mut term = start.clone();
    let mut steps = Vec::new();
    for (i, at) in original_trace {
        if strategy_timed_out(deadline) {
            return None;
        }
        let rule = &trs.rules()[i];
        let position = vec![1; at];
        let subst = match_pattern(rule.lhs(), subterm_at_position(&term, &position)?)?;
        term =
            replace_subterm_at_position(&term, &position, &apply_substitution(rule.rhs(), &subst))?;
        steps.push(LoopRewriteStep {
            position,
            rule: rule.clone(),
            result: term.clone(),
        });
    }
    let proof = LoopProof {
        start,
        steps,
        substitution,
        context_position,
    };
    check_loop_proof_for_trs(trs, &proof).then_some(NonterminationProof::Loop(proof))
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn transport_freezes_prefix_to_close_a_long_one_rule_loop() {
        for (a, b, c) in [("a", "b", "c"), ("advance", "carry", "emit")] {
            let word = |s: &str| {
                word_to_term_with_tail(
                    &s.chars()
                        .map(|x| {
                            Symbol::new(match x {
                                'a' => a,
                                'b' => b,
                                _ => c,
                            })
                        })
                        .collect::<Word>(),
                    Term::var("x"),
                )
            };
            let trs = Trs::new(
                None,
                BTreeSet::from([Variable::new("x")]),
                vec![RewriteRule::new(word("bacaaaaaa"), word("aaaaaaabacbac"))],
            );
            let Some(NonterminationProof::Loop(proof)) =
                search(&trs, Some(Instant::now() + Duration::from_secs(30)))
            else {
                panic!("expected synthesized long transport loop");
            };
            assert!(proof.steps.len() >= 32);
            assert!(check_loop_proof_for_trs(&trs, &proof));
        }
    }

    #[test]
    fn transport_rejects_terminating_and_expired_search() {
        let trs = crate::parsing::parse_ari_trs(
            None,
            "(format TRS) (fun a 1) (fun b 1) (rule (a (b x)) (b x))",
        )
        .unwrap();
        assert!(search(&trs, None).is_none());
        assert!(search(&trs, Some(Instant::now())).is_none());
        let atom = "srs-transport-loop";
        assert_eq!(
            NonterminationStrategy::parse(atom)
                .unwrap()
                .to_strategy_atom(),
            atom
        );
    }

    #[test]
    fn transport_synthesizes_and_checks_a_morphism_loop_under_renaming() {
        for (a, b) in [("a", "b"), ("run", "move")] {
            let trs = crate::parsing::parse_ari_trs(
                None,
                &format!(
                    "(format TRS) (fun {a} 1) (fun {b} 1) (rule ({a} ({b} x)) ({b} ({a} ({b} x))))"
                ),
            )
            .unwrap();
            let Some(NonterminationProof::Loop(proof)) = search(&trs, None) else {
                panic!("missing transport loop");
            };
            assert!(check_loop_proof_for_trs(&trs, &proof));
            let mut invalid = proof.clone();
            invalid.steps.clear();
            assert!(!check_loop_proof_for_trs(&trs, &invalid));
            for strategy in [RewriteStrategy::Innermost, RewriteStrategy::Outermost] {
                let restricted = Trs::new_with_strategy(
                    None,
                    trs.variables().clone(),
                    trs.rules().to_vec(),
                    strategy,
                );
                assert!(search(&restricted, None).is_none());
            }
        }
    }

    #[test]
    fn transport_reversed_search_reconstructs_original_rules() {
        let trs = crate::parsing::parse_ari_trs(
            None,
            "(format TRS) (fun a 1) (fun b 1) (rule (b (a x)) (b (a (b x))))",
        )
        .unwrap();
        let rules = trs
            .srs_rules()
            .unwrap()
            .iter()
            .map(|r| {
                (
                    r.lhs().iter().cloned().rev().collect(),
                    r.rhs().iter().cloned().rev().collect(),
                )
            })
            .collect::<Vec<_>>();
        let Some(NonterminationProof::Loop(proof)) = search_direction(&trs, &rules, true, None)
        else {
            panic!("expected reversed transport proof");
        };
        assert!(check_loop_proof_for_trs(&trs, &proof));
    }
}
