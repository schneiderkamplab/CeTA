//! Exact cycle detection in the finite graph of words up to a given length.
//! Each word is visited once, rather than repeatedly enumerating derivations.
//! A 512-million-vertex ceiling bounds the packed color table to 128 MB. This is an
//! optional search route, never an argument that absence of a cycle proves SN.
use super::*;

/// Two bits suffice for unseen, active and completed vertices. Packing them
/// permits a wider search with the same table budget; no graph state is merged.
struct Colors(Vec<u64>);
impl Colors {
    fn new(vertices: usize) -> Self {
        Self(vec![0; vertices.div_ceil(32)])
    }
    fn get(&self, vertex: usize) -> u64 {
        (self.0[vertex / 32] >> (2 * (vertex % 32))) & 3
    }
    fn set(&mut self, vertex: usize, value: u64) {
        let shift = 2 * (vertex % 32);
        let cell = &mut self.0[vertex / 32];
        *cell = (*cell & !(3 << shift)) | (value << shift);
    }
}

#[derive(Clone, Copy)]
enum Edge {
    Rewrite {
        rule: usize,
        pos: usize,
        trim_left: usize,
        trim_right: usize,
    },
    TrimLeft,
    TrimRight,
}

struct Frame {
    word: usize,
    len: usize,
    rule: usize,
    pos: usize,
    window: usize,
    incoming: Option<Edge>,
}

pub(super) fn search(
    trs: &Trs,
    deadline: Option<Instant>,
    width: usize,
    contexts: bool,
) -> Option<NonterminationProof> {
    if trs.strategy() != RewriteStrategy::Full || !(1..=128).contains(&width) {
        return None;
    }
    let rules = trs.srs_rules()?;
    // With no length-increasing rule, a loop cannot contain a length-decrease
    // (including a virtual context trim). Different word lengths are then
    // independent graphs, so reuse the color table rather than storing their
    // disjoint union. This is only a loop-search reduction, not an SN claim.
    let fixed_length = rules.iter().all(|r| r.rhs().len() <= r.lhs().len());
    let contexts = contexts && !fixed_length;
    let alphabet = rules
        .iter()
        .flat_map(|r| r.lhs().iter().chain(r.rhs()))
        .cloned()
        .collect::<BTreeSet<_>>()
        .into_iter()
        .collect::<Vec<_>>();
    let base = alphabet.len();
    if base == 0 {
        return None;
    }
    let indices = alphabet
        .iter()
        .enumerate()
        .map(|(i, s)| (s.clone(), i))
        .collect::<BTreeMap<_, _>>();
    let encode = |word: &[Symbol]| {
        word.iter()
            .try_fold(0usize, |n, s| n.checked_mul(base)?.checked_add(indices[s]))
    };
    let mut powers = vec![1usize];
    let mut offsets = vec![0usize];
    let mut total = 1usize;
    for _ in 0..width {
        let power = powers.last()?.checked_mul(base)?;
        powers.push(power);
        offsets.push(if fixed_length { 0 } else { total });
        total = if fixed_length {
            power
        } else {
            total.checked_add(power)?
        };
        if total > 512_000_000 {
            return None;
        }
    }
    let encoded = rules
        .iter()
        .enumerate()
        .filter(|(_, r)| {
            r.lhs().len() <= width
                && (contexts || r.rhs().len() <= width)
                && (!fixed_length || r.lhs().len() == r.rhs().len())
        })
        .map(|(i, r)| {
            Some((
                i,
                r.lhs().len(),
                encode(r.lhs())?,
                r.rhs().len(),
                if r.rhs().len() <= width {
                    encode(r.rhs())?
                } else {
                    0
                },
            ))
        })
        .collect::<Option<Vec<_>>>()?;
    if encoded.is_empty() {
        return None;
    }
    let decode = |mut word: usize, len: usize| {
        let mut result = vec![alphabet[0].clone(); len];
        for j in (0..len).rev() {
            result[j] = alphabet[word % base].clone();
            word /= base;
        }
        result
    };
    let mut colors = Colors::new(if fixed_length { 1 } else { total });
    let mut visited = 0usize;
    // Any shorter fixed-length cycle embeds in a width-sized context. Search
    // that single graph directly; smaller lengths need not be re-enumerated.
    for len in if fixed_length { width } else { 0 }..=width {
        if fixed_length {
            colors = Colors::new(powers[len]);
        }
        for word in 0..powers[len] {
            if strategy_timed_out(deadline) {
                return None;
            }
            if colors.get(offsets[len] + word) != 0 {
                continue;
            }
            let mut stack = vec![Frame {
                word,
                len,
                rule: 0,
                pos: 0,
                window: 0,
                incoming: None,
            }];
            colors.set(offsets[len] + word, 1);
            while let Some(frame) = stack.last_mut() {
                if strategy_timed_out(deadline) {
                    return None;
                }
                if frame.rule == encoded.len() + if contexts { 2 } else { 0 } {
                    colors.set(offsets[frame.len] + frame.word, 2);
                    stack.pop();
                    continue;
                }
                // Trimming is a search abstraction only. During reconstruction
                // the removed letters remain as contexts surrounding all later
                // genuine rewrites. They are never emitted as rewrite steps.
                let (next_word, next_len, edge) = if frame.rule >= encoded.len() {
                    let left = frame.rule == encoded.len();
                    frame.rule += 1;
                    if frame.len == 0 {
                        continue;
                    }
                    (
                        if left {
                            frame.word % powers[frame.len - 1]
                        } else {
                            frame.word / base
                        },
                        frame.len - 1,
                        if left {
                            Edge::TrimLeft
                        } else {
                            Edge::TrimRight
                        },
                    )
                } else {
                    let (ri, l, lhs, r, rhs) = encoded[frame.rule];
                    if l > frame.len
                        || (!contexts && frame.len - l + r > width)
                        || frame.pos > frame.len - l
                    {
                        frame.rule += 1;
                        frame.pos = 0;
                        frame.window = 0;
                        continue;
                    }
                    let pos = frame.pos;
                    let suffix_len = frame.len - pos - l;
                    if (frame.word / powers[suffix_len]) % powers[l] != lhs {
                        frame.pos += 1;
                        frame.window = 0;
                        continue;
                    }
                    let new_len = frame.len - l + r;
                    let window = frame.window;
                    frame.window += 1;
                    if frame.window == new_len.saturating_sub(width) + 1 {
                        frame.pos += 1;
                        frame.window = 0;
                    }
                    if new_len > width {
                        // Represent rewrite followed by context trimming as one
                        // search edge. Every shorter subword lies in a window
                        // of this width; normal trim edges handle the remainder.
                        let expanded = replace_word_at(
                            &decode(frame.word, frame.len),
                            pos,
                            l,
                            rules[ri].rhs(),
                        );
                        (
                            encode(&expanded[window..window + width])?,
                            width,
                            Edge::Rewrite {
                                rule: ri,
                                pos,
                                trim_left: window,
                                trim_right: new_len - width - window,
                            },
                        )
                    } else {
                        let prefix = frame.word / powers[frame.len - pos];
                        let suffix = frame.word % powers[suffix_len];
                        let next_word = (prefix * powers[r] + rhs) * powers[suffix_len] + suffix;
                        let next_len = frame.len - l + r;
                        (
                            next_word,
                            next_len,
                            Edge::Rewrite {
                                rule: ri,
                                pos,
                                trim_left: 0,
                                trim_right: 0,
                            },
                        )
                    }
                };
                let id = offsets[next_len] + next_word;
                if colors.get(id) == 1 {
                    let begin = stack
                        .iter()
                        .position(|f| f.len == next_len && f.word == next_word)?;
                    let source_word = decode(next_word, next_len);
                    let start = word_to_term_with_tail(&source_word, Term::var("_srs_finite_tail"));
                    let edges = stack[begin + 1..]
                        .iter()
                        .map(|f| f.incoming)
                        .chain(std::iter::once(Some(edge)))
                        .collect::<Option<Vec<_>>>()?;
                    let mut term = start.clone();
                    let mut steps = Vec::new();
                    let mut current_word = source_word.clone();
                    let mut prefix = 0usize;
                    let mut active_len = source_word.len();
                    for edge in edges {
                        let (rule_index, offset, trim_left, trim_right) = match edge {
                            Edge::TrimLeft => {
                                active_len = active_len.checked_sub(1)?;
                                prefix += 1;
                                continue;
                            }
                            Edge::TrimRight => {
                                active_len = active_len.checked_sub(1)?;
                                continue;
                            }
                            Edge::Rewrite {
                                rule,
                                pos,
                                trim_left,
                                trim_right,
                            } => (rule, pos, trim_left, trim_right),
                        };
                        let srs_rule = rules.get(rule_index)?;
                        if offset.checked_add(srs_rule.lhs().len())? > active_len {
                            return None;
                        }
                        active_len = active_len - srs_rule.lhs().len() + srs_rule.rhs().len();
                        let offset = prefix.checked_add(offset)?;
                        current_word = replace_word_at(
                            &current_word,
                            offset,
                            srs_rule.lhs().len(),
                            srs_rule.rhs(),
                        );
                        let rule = trs.rules().get(rule_index)?;
                        let position = vec![1; offset];
                        let subst =
                            match_pattern(rule.lhs(), subterm_at_position(&term, &position)?)?;
                        term = replace_subterm_at_position(
                            &term,
                            &position,
                            &apply_substitution(rule.rhs(), &subst),
                        )?;
                        steps.push(LoopRewriteStep {
                            position,
                            rule: rule.clone(),
                            result: term.clone(),
                        });
                        active_len = active_len.checked_sub(trim_left.checked_add(trim_right)?)?;
                        prefix = prefix.checked_add(trim_left)?;
                    }
                    if steps.is_empty() {
                        return None;
                    }
                    let (context_position, substitution) =
                        closes_srs_loop(&source_word, &current_word, &start)?;
                    let proof = LoopProof {
                        start,
                        steps,
                        context_position,
                        substitution,
                    };
                    return check_loop_proof_for_trs(trs, &proof)
                        .then_some(NonterminationProof::Loop(proof));
                }
                if colors.get(id) == 2 {
                    continue;
                }
                colors.set(id, 1);
                visited += 1;
                if visited % 100_000 == 0 {
                    crate::proving::runtime::write_progress_event(
                        "srs-finite-loop",
                        "visited",
                        "bounded-graph",
                        0,
                        &format!(
                            "visited={visited} vertices={total} stack={} width={width}",
                            stack.len()
                        ),
                    );
                }
                stack.push(Frame {
                    word: next_word,
                    len: next_len,
                    rule: 0,
                    pos: 0,
                    window: 0,
                    incoming: Some(edge),
                });
            }
        }
    }
    None
}

#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn packed_colors_preserve_neighbors_and_word_boundaries() {
        let mut colors = Colors::new(97);
        for i in 0..97 {
            assert_eq!(colors.get(i), 0);
        }
        for i in 0..97 {
            colors.set(i, (i % 3) as u64);
        }
        for i in 0..97 {
            assert_eq!(colors.get(i), (i % 3) as u64);
        }
        for i in (0..97).step_by(2) {
            colors.set(i, 2);
        }
        for i in 0..97 {
            assert_eq!(colors.get(i), if i % 2 == 0 { 2 } else { (i % 3) as u64 });
        }
        assert_eq!(Colors::new(128_000_000).0.len() * 8, 32_000_000);
    }
    #[test]
    fn finite_word_graph_finds_multistep_cycle_and_checks_renaming() {
        for (a, b) in [("a", "b"), ("other", "renamed")] {
            let trs = crate::parsing::parse_ari_trs(None,&format!("(format TRS) (fun {a} 1) (fun {b} 1) (rule ({a} x) ({b} x)) (rule ({b} ({b} x)) ({a} ({a} x)))")).unwrap();
            assert!(search(&trs, None, 1, false).is_none());
            let Some(NonterminationProof::Loop(proof)) = search(&trs, None, 2, false) else {
                panic!("cycle")
            };
            assert_eq!(proof.steps.len(), 3);
            assert!(check_loop_proof_for_trs(&trs, &proof));
            assert!(search(&trs, Some(Instant::now()), 2, false).is_none());
        }
        let trs =
            crate::parsing::parse_ari_trs(None, "(format TRS) (fun a 1) (rule (a (a x)) (a x))")
                .unwrap();
        assert!(search(&trs, None, 8, false).is_none());
        assert!(search(&trs, None, 8, true).is_none());
        let mixed = crate::parsing::parse_ari_trs(None,"(format TRS) (fun a 1) (fun b 1) (rule (a x) (b x)) (rule (b x) (a x)) (rule (a (a x)) (a x))").unwrap();
        let Some(NonterminationProof::Loop(proof)) = search(&mixed, None, 3, true) else {
            panic!("length-preserving cycle")
        };
        assert_eq!(proof.steps.len(), 2);
        assert!(check_loop_proof_for_trs(&mixed, &proof));
    }
    #[test]
    fn finite_context_graph_checks_embedding_and_suffix_substitution() {
        for rhs in ["(a (b x))", "(b (a x))"] {
            let trs = crate::parsing::parse_ari_trs(
                None,
                &format!("(format TRS) (fun a 1) (fun b 1) (rule (a x) {rhs})"),
            )
            .unwrap();
            assert!(search(&trs, None, 2, false).is_none());
            let Some(NonterminationProof::Loop(proof)) = search(&trs, None, 2, true) else {
                panic!("context loop")
            };
            assert!(check_loop_proof_for_trs(&trs, &proof));
        }
        let atom = "srs-finite-context-loop(max-width=13)";
        assert_eq!(
            NonterminationStrategy::parse(atom)
                .unwrap()
                .to_strategy_atom(),
            atom
        );
    }

    #[test]
    fn finite_context_graph_lifts_rewrites_through_nested_trimmed_contexts() {
        for rhs in ["(b (c (d x)))", "(d (c (b x)))"] {
            let trs = crate::parsing::parse_ari_trs(None,&format!("(format TRS) (fun a 1) (fun b 1) (fun c 1) (fun d 1) (rule (a x) {rhs}) (rule (c x) (a x))")).unwrap();
            assert!(search(&trs, None, 1, false).is_none());
            let Some(NonterminationProof::Loop(proof)) = search(&trs, None, 1, true) else {
                panic!("trimmed two-step loop")
            };
            assert_eq!(proof.steps.len(), 2);
            assert!(check_loop_proof_for_trs(&trs, &proof));
            assert!(proof.steps.iter().any(|s| !s.position.is_empty()));
        }
        let decreasing = crate::parsing::parse_ari_trs(
            None,
            "(format TRS) (fun a 1) (fun b 1) (rule (a (b x)) (b x)) (rule (b (a x)) (a x))",
        )
        .unwrap();
        assert!(search(&decreasing, None, 6, true).is_none());
    }
}
