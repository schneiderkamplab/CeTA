//! Compose discovered finite derivations, not only single original rules.
//! Every synthesized shortcut carries its expanded original-rule trace. No
//! shortcut is trusted by certification or by the independent loop validator.
use super::*;

#[derive(Clone, Eq, PartialEq, Ord, PartialOrd)]
struct Derivation {
    lhs: Vec<Symbol>,
    rhs: Vec<Symbol>,
    trace: Vec<(usize, usize)>,
}

fn checked_loop(trs: &Trs, d: &Derivation) -> Option<NonterminationProof> {
    let start = word_to_term_with_tail(&d.lhs, Term::var("_srs_compose_tail"));
    let (context_position, substitution) = closes_srs_loop(&d.lhs, &d.rhs, &start)?;
    let mut term = start.clone();
    let mut steps = Vec::new();
    for &(index, offset) in &d.trace {
        let rule = trs.rules().get(index)?;
        let position = vec![1; offset];
        let subst = match_pattern(rule.lhs(), subterm_at_position(&term, &position)?)?;
        term =
            replace_subterm_at_position(&term, &position, &apply_substitution(rule.rhs(), &subst))?;
        steps.push(LoopRewriteStep {
            position,
            rule: rule.clone(),
            result: term.clone(),
        });
    }
    // Reject any faulty shortcut composition even before checking the loop.
    if term != word_to_term_with_tail(&d.rhs, Term::var("_srs_compose_tail")) {
        return None;
    }
    let proof = LoopProof {
        start,
        steps,
        context_position,
        substitution,
    };
    check_loop_proof_for_trs(trs, &proof).then_some(NonterminationProof::Loop(proof))
}

fn compose(a: &Derivation, b: &Derivation, offset: isize, width: usize) -> Option<Derivation> {
    let left = offset.max(0) as usize;
    let right = (offset + b.lhs.len() as isize).min(a.rhs.len() as isize) as usize;
    if left >= right
        || a.rhs[left..right]
            != b.lhs[(left as isize - offset) as usize..(right as isize - offset) as usize]
    {
        return None;
    }
    let prefix = (-offset).max(0) as usize;
    let suffix = (a.rhs.len() as isize - offset).min(b.lhs.len() as isize) as usize;
    let lhs = [&b.lhs[..prefix], a.lhs.as_slice(), &b.lhs[suffix..]].concat();
    let extended = [&b.lhs[..prefix], a.rhs.as_slice(), &b.lhs[suffix..]].concat();
    let position = (offset + prefix as isize) as usize;
    let rhs = replace_word_at(&extended, position, b.lhs.len(), &b.rhs);
    if lhs.len() > width || rhs.len() > width || a.trace.len() + b.trace.len() > 1024 {
        return None;
    }
    let trace = a
        .trace
        .iter()
        .map(|&(r, p)| (r, p + prefix))
        .chain(b.trace.iter().map(|&(r, p)| (r, p + position)))
        .collect();
    Some(Derivation { lhs, rhs, trace })
}

pub(super) fn search(
    trs: &Trs,
    deadline: Option<Instant>,
    width: usize,
    start_width: Option<usize>,
) -> Option<NonterminationProof> {
    if trs.strategy() != RewriteStrategy::Full || !(1..=128).contains(&width) {
        return None;
    }
    let rules = trs.srs_rules()?;
    let originals = rules
        .iter()
        .enumerate()
        .map(|(i, r)| Derivation {
            lhs: r.lhs().to_vec(),
            rhs: r.rhs().to_vec(),
            trace: vec![(i, 0)],
        })
        .collect::<Vec<_>>();
    let priority = |d: &Derivation| {
        7 * (d.trace.len() + 1).ilog2() as i64
            - 7 * start_width.map_or(d.lhs.len(), |n| d.lhs.len().abs_diff(n)) as i64
            - d.rhs.len() as i64
    };
    let mut queue = std::collections::BinaryHeap::new();
    let mut seen = BTreeSet::new();
    let mut serial = 0usize;
    for d in &originals {
        if seen.insert((d.lhs.clone(), d.rhs.clone())) {
            queue.push((priority(d), std::cmp::Reverse(serial), d.clone()));
            serial += 1;
        }
    }
    let mut recent = VecDeque::new();
    while let Some((_, _, a)) = queue.pop() {
        if strategy_timed_out(deadline) {
            return None;
        }
        if let Some(proof) = checked_loop(trs, &a) {
            return Some(proof);
        }
        if seen.len() >= 200_000 {
            // A full *search* table is not an exhausted closure. Keep the best
            // pending derivations and continue extending them, instead of
            // draining the queue without expanding a single remaining node.
            // Eviction may repeat search but cannot create a proof: each
            // proposed loop still needs its complete original-rule trace.
            let mut pending = queue.into_sorted_vec();
            pending.reverse();
            pending.truncate(10_000);
            seen.clear();
            seen.extend(
                pending
                    .iter()
                    .map(|(_, _, d)| (d.lhs.clone(), d.rhs.clone())),
            );
            seen.insert((a.lhs.clone(), a.rhs.clone()));
            queue = std::collections::BinaryHeap::from(pending);
            crate::proving::runtime::write_progress_event(
                "srs-compose-loop",
                "compact",
                "bounded-frontier",
                0,
                &format!(
                    "retained={} steps={} source={} target={}",
                    queue.len(),
                    a.trace.len(),
                    a.lhs.len(),
                    a.rhs.len()
                ),
            );
        }
        for b in originals
            .iter()
            .chain(recent.iter())
            .chain(std::iter::once(&a))
        {
            for (first, second) in [(&a, b), (b, &a)] {
                if second.lhs.is_empty() {
                    continue;
                }
                let mut candidates = Vec::new();
                for offset in -(second.lhs.len() as isize - 1)..first.rhs.len() as isize {
                    if strategy_timed_out(deadline) {
                        return None;
                    }
                    if let Some(d) = compose(first, second, offset, width) {
                        if !seen.contains(&(d.lhs.clone(), d.rhs.clone())) {
                            candidates.push(d);
                        }
                    }
                }
                candidates.sort_by_key(|d| std::cmp::Reverse(priority(d)));
                for d in candidates.into_iter().take(8) {
                    if seen.len() >= 200_000 {
                        break;
                    }
                    if seen.insert((d.lhs.clone(), d.rhs.clone())) {
                        if let Some(proof) = checked_loop(trs, &d) {
                            return Some(proof);
                        }
                        queue.push((priority(&d), std::cmp::Reverse(serial), d));
                        serial += 1;
                    }
                }
            }
        }
        if a.trace.len() > 1 {
            recent.push_back(a);
            if recent.len() > 32 {
                recent.pop_front();
            }
        }
    }
    None
}

#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn composed_loops_reconstruct_original_steps_and_renaming() {
        for (a, b) in [("a", "b"), ("renamed", "other")] {
            let trs=crate::parsing::parse_ari_trs(None,&format!("(format TRS) (fun {a} 1) (fun {b} 1) (rule ({a} x) ({b} x)) (rule ({b} ({b} x)) ({a} ({a} x)))")).unwrap();
            let Some(NonterminationProof::Loop(p)) =
                search(&trs, Some(Instant::now() + Duration::from_secs(5)), 4, None)
            else {
                panic!("composed loop")
            };
            assert!(p.steps.len() >= 3);
            assert!(check_loop_proof_for_trs(&trs, &p));
            assert!(search(&trs, Some(Instant::now()), 4, None).is_none());
            assert!(
                search(
                    &trs,
                    Some(Instant::now() + Duration::from_secs(5)),
                    4,
                    Some(2)
                )
                .is_some()
            );
        }
        let trs =
            crate::parsing::parse_ari_trs(None, "(format TRS) (fun a 1) (rule (a (a x)) (a x))")
                .unwrap();
        assert!(search(&trs, Some(Instant::now() + Duration::from_secs(2)), 6, None).is_none());
        let atom = "srs-compose-loop(max-width=42)";
        assert_eq!(
            NonterminationStrategy::parse(atom)
                .unwrap()
                .to_strategy_atom(),
            atom
        );
    }
}
