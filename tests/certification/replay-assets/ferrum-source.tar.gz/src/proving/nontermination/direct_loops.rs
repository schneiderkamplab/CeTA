//! Direct, CSR, and outermost loop searches.

use super::*;

pub(crate) fn variable_condition_violation(trs: &Trs) -> Option<NonterminationProof> {
    if trs.strategy() != RewriteStrategy::Full {
        return None;
    }
    trs.validate()
        .iter()
        .any(|issue| {
            matches!(
                issue,
                TrsIssue::ExtraVariablesOnRhs { .. } | TrsIssue::LhsIsVariable { .. }
            )
        })
        .then_some(NonterminationProof::VariableConditionViolated)
}

pub(crate) fn direct_loop(trs: &Trs) -> Option<NonterminationProof> {
    for rule in trs.rules() {
        if let Some(proof) =
            extra_variable_loop(rule).filter(|proof| check_loop_proof_for_trs(trs, proof))
        {
            return Some(NonterminationProof::Loop(proof));
        }
        if let Some(proof) =
            one_step_loop(rule).filter(|proof| check_loop_proof_for_trs(trs, proof))
        {
            return Some(NonterminationProof::Loop(proof));
        }
    }
    if trs.strategy() == RewriteStrategy::Innermost && trs_is_orthogonal(trs) {
        let full_trs = Trs::new(
            trs.name().map(str::to_string),
            trs.variables().clone(),
            trs.rules().to_vec(),
        );
        for rule in trs.rules() {
            if let Some(proof) =
                one_step_loop(rule).filter(|proof| check_loop_proof_for_trs(&full_trs, proof))
            {
                return Some(NonterminationProof::SwitchFullStrategy {
                    wcr_depth: 1,
                    proof: Box::new(NonterminationProof::Loop(proof)),
                });
            }
        }
    }
    None
}

pub(crate) fn extra_variable_loop(rule: &RewriteRule) -> Option<LoopProof> {
    let lhs_variables = rule.lhs().variables();
    for (context_position, subterm) in positions_with_subterms(rule.rhs()) {
        let Term::Var(variable) = subterm else {
            continue;
        };
        if lhs_variables.contains(variable) {
            continue;
        }
        let result = apply_substitution(
            rule.rhs(),
            &BTreeMap::from([(variable.clone(), rule.lhs().clone())]),
        );
        let proof = LoopProof {
            start: rule.lhs().clone(),
            steps: vec![LoopRewriteStep {
                position: Vec::new(),
                rule: rule.clone(),
                result,
            }],
            substitution: BTreeMap::new(),
            context_position,
        };
        if check_loop_proof(&proof) {
            return Some(proof);
        }
    }
    None
}

pub(crate) fn bounded_csr_rewriting_loop(
    csr: &CsrTrs,
    deadline: Option<Instant>,
) -> Option<NonterminationProof> {
    let starts = small_ground_terms(csr.trs(), deadline)?;
    for start in starts {
        if strategy_timed_out(deadline) {
            return None;
        }
        if let Some(proof) = search_csr_loop_from(csr, &start, deadline) {
            return Some(NonterminationProof::Loop(proof));
        }
    }
    None
}

pub(crate) fn bounded_outermost_symbolic_cycle(
    trs: &Trs,
    deadline: Option<Instant>,
) -> Option<NonterminationProof> {
    if trs.strategy() != RewriteStrategy::Outermost {
        return None;
    }
    for rule in trs.rules() {
        let start = rule.lhs().clone();
        let mut queue = VecDeque::from([(start.clone(), Vec::<LoopRewriteStep>::new())]);
        let mut seen = BTreeSet::from([start.clone()]);
        let mut explored = 0usize;
        while let Some((current, steps)) = queue.pop_front() {
            if strategy_timed_out(deadline) {
                return None;
            }
            if steps.len() >= MAX_LOOP_REWRITE_STEPS {
                continue;
            }
            for step in outermost_rewrite_successors(trs, &current) {
                let next = step.result.clone();
                let mut next_steps = steps.clone();
                next_steps.push(step);
                if next == start {
                    let proof = LoopProof {
                        start: start.clone(),
                        steps: next_steps.clone(),
                        substitution: BTreeMap::new(),
                        context_position: Vec::new(),
                    };
                    if check_loop_proof_for_trs(trs, &proof) {
                        return Some(NonterminationProof::Loop(proof));
                    }
                }
                if seen.insert(next.clone()) {
                    explored += 1;
                    if explored >= MAX_LOOP_FRONTIER {
                        break;
                    }
                    queue.push_back((next, next_steps));
                }
            }
        }
    }
    None
}

pub(crate) fn bounded_outermost_rewriting_cycle(
    trs: &Trs,
    deadline: Option<Instant>,
) -> Option<NonterminationProof> {
    if trs.strategy() != RewriteStrategy::Outermost {
        return None;
    }
    let ground_terms = small_ground_terms(trs, deadline)?;
    let mut starts = ground_rule_side_instances(trs, &ground_terms, deadline);
    starts.extend(ground_terms);
    let mut unique_starts = BTreeSet::new();
    starts.retain(|term| unique_starts.insert(term.clone()));
    let mut explored = 0usize;
    for start in starts {
        if strategy_timed_out(deadline) {
            return None;
        }
        let mut queue = VecDeque::from([(start.clone(), Vec::<LoopRewriteStep>::new())]);
        let mut seen = BTreeSet::from([start.clone()]);
        while let Some((current, steps)) = queue.pop_front() {
            if strategy_timed_out(deadline) {
                return None;
            }
            if steps.len() >= MAX_LOOP_REWRITE_STEPS {
                continue;
            }
            for step in outermost_rewrite_successors(trs, &current) {
                let next = step.result.clone();
                let mut next_steps = steps.clone();
                next_steps.push(step);
                if next == start {
                    let proof = LoopProof {
                        start: start.clone(),
                        steps: next_steps.clone(),
                        substitution: BTreeMap::new(),
                        context_position: Vec::new(),
                    };
                    if check_loop_proof_for_trs(trs, &proof) {
                        return Some(NonterminationProof::Loop(proof));
                    }
                }
                if seen.insert(next.clone()) {
                    explored += 1;
                    if explored > MAX_LOOP_FRONTIER {
                        return None;
                    }
                    queue.push_back((next, next_steps));
                }
            }
        }
    }
    None
}

pub(crate) fn bounded_outermost_context_loop(
    trs: &Trs,
    deadline: Option<Instant>,
) -> Option<NonterminationProof> {
    if trs.strategy() != RewriteStrategy::Outermost {
        return None;
    }
    let NonterminationProof::Loop(proof) = bounded_rule_subset_narrowing_loop(trs, deadline)?
    else {
        return None;
    };
    let proof = validated_outermost_loop_instance(trs, &proof, deadline)?;
    Some(NonterminationProof::Loop(proof))
}

pub(crate) fn ground_rule_side_instances(
    trs: &Trs,
    ground_terms: &[Term],
    deadline: Option<Instant>,
) -> Vec<Term> {
    const MAX_GROUND_CHOICES: usize = 16;
    const MAX_RULE_INSTANCES: usize = 2_048;

    fn instantiate(
        side: &Term,
        variables: &[Variable],
        choices: &[Term],
        index: usize,
        substitution: &mut BTreeMap<Variable, Term>,
        instances: &mut Vec<Term>,
        deadline: Option<Instant>,
    ) {
        if instances.len() >= MAX_RULE_INSTANCES || strategy_timed_out(deadline) {
            return;
        }
        if index == variables.len() {
            instances.push(apply_substitution(side, substitution));
            return;
        }
        let variable = variables[index].clone();
        for choice in choices {
            substitution.insert(variable.clone(), choice.clone());
            instantiate(
                side,
                variables,
                choices,
                index + 1,
                substitution,
                instances,
                deadline,
            );
            if instances.len() >= MAX_RULE_INSTANCES || strategy_timed_out(deadline) {
                break;
            }
        }
        substitution.remove(&variable);
    }

    let choices = &ground_terms[..ground_terms.len().min(MAX_GROUND_CHOICES)];
    let mut instances = Vec::new();
    for rule in trs.rules() {
        for side in [rule.lhs(), rule.rhs()] {
            let variables = side.variables().into_iter().collect::<Vec<_>>();
            instantiate(
                side,
                &variables,
                choices,
                0,
                &mut BTreeMap::new(),
                &mut instances,
                deadline,
            );
            if instances.len() >= MAX_RULE_INSTANCES || strategy_timed_out(deadline) {
                return instances;
            }
        }
    }
    instances
}

pub(crate) fn outermost_rewrite_successors(trs: &Trs, term: &Term) -> Vec<LoopRewriteStep> {
    let mut successors = Vec::new();
    for (position, subterm) in positions_with_subterms(term) {
        if !is_outermost_rewrite_position(term, &position, trs.rules()) {
            continue;
        }
        for rule in trs.rules() {
            let Some(substitution) = match_pattern(rule.lhs(), subterm) else {
                continue;
            };
            let replacement = apply_substitution(rule.rhs(), &substitution);
            if let Some(result) = replace_subterm_at_position(term, &position, &replacement) {
                successors.push(LoopRewriteStep {
                    position: position.clone(),
                    rule: rule.clone(),
                    result,
                });
            }
        }
    }
    successors
}

pub(crate) fn is_outermost_rewrite_position(
    term: &Term,
    position: &[usize],
    rules: &[RewriteRule],
) -> bool {
    (0..position.len()).all(|prefix_len| {
        subterm_at_position(term, &position[..prefix_len]).is_some_and(|prefix| {
            rules
                .iter()
                .all(|rule| match_pattern(rule.lhs(), prefix).is_none())
        })
    })
}

pub(crate) fn search_csr_loop_from(
    csr: &CsrTrs,
    start: &Term,
    deadline: Option<Instant>,
) -> Option<LoopProof> {
    let mut queue = VecDeque::from([(start.clone(), Vec::<LoopRewriteStep>::new())]);
    let mut seen = BTreeSet::from([start.clone()]);
    let mut explored = 0usize;
    while let Some((current, steps)) = queue.pop_front() {
        if strategy_timed_out(deadline) {
            return None;
        }
        if !steps.is_empty()
            && let Some((context_position, substitution)) = closes_csr_loop(csr, start, &current)
        {
            let proof = LoopProof {
                start: start.clone(),
                steps: steps.clone(),
                substitution,
                context_position,
            };
            if check_loop_proof_for_csr(csr, &proof) {
                return Some(proof);
            }
        }
        if steps.len() >= MAX_LOOP_REWRITE_STEPS {
            continue;
        }
        for (zero_based_position, subterm) in csr.replacing_subterms(&current) {
            for rule in csr.rules() {
                if strategy_timed_out(deadline) {
                    return None;
                }
                let Some(substitution) = match_pattern(rule.lhs(), subterm) else {
                    continue;
                };
                let rhs = apply_substitution(rule.rhs(), &substitution);
                let position = zero_based_position
                    .iter()
                    .map(|index| index + 1)
                    .collect::<Vec<_>>();
                let Some(next) = replace_subterm_at_position(&current, &position, &rhs) else {
                    continue;
                };
                if !seen.insert(next.clone()) {
                    continue;
                }
                explored += 1;
                if explored > MAX_LOOP_FRONTIER {
                    return None;
                }
                let mut next_steps = steps.clone();
                next_steps.push(LoopRewriteStep {
                    position,
                    rule: rule.clone(),
                    result: next.clone(),
                });
                queue.push_back((next, next_steps));
            }
        }
    }
    None
}

pub(crate) fn closes_csr_loop(
    csr: &CsrTrs,
    start: &Term,
    current: &Term,
) -> Option<(Vec<usize>, BTreeMap<Variable, Term>)> {
    for (zero_based_position, subterm) in csr.replacing_subterms(current) {
        let Some(substitution) = match_pattern(start, subterm) else {
            continue;
        };
        return Some((
            zero_based_position.iter().map(|index| index + 1).collect(),
            substitution,
        ));
    }
    None
}

pub(crate) fn check_loop_proof_for_csr(csr: &CsrTrs, proof: &LoopProof) -> bool {
    if !check_loop_proof(proof) {
        return false;
    }
    let mut current = proof.start.clone();
    for step in &proof.steps {
        if !csr.rules().contains(&step.rule) {
            return false;
        }
        let Some(zero_based_position) = step
            .position
            .iter()
            .map(|index| index.checked_sub(1))
            .collect::<Option<Vec<_>>>()
        else {
            return false;
        };
        if !csr.rewrite_step_allowed(&current, &zero_based_position) {
            return false;
        }
        current = step.result.clone();
    }
    let Some(zero_based_context) = proof
        .context_position
        .iter()
        .map(|index| index.checked_sub(1))
        .collect::<Option<Vec<_>>>()
    else {
        return false;
    };
    csr.is_replacing_position(&zero_based_context, &current)
}
