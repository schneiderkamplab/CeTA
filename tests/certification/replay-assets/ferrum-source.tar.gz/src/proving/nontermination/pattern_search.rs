//! Native pattern-rule synthesis (Emmes/Enger/Giesl, IJCAR 2012).
//!
//! Every constructor checks the corresponding Nonloop_Impl side conditions.
//! Seeds come exclusively from live rules and pairs, never retained proofs.
use super::*;

type Subst = BTreeMap<Variable, Term>;

fn image(s: &Subst, x: &Variable) -> Term {
    s.get(x).cloned().unwrap_or_else(|| Term::Var(x.clone()))
}

fn clean(mut s: Subst) -> Subst {
    s.retain(|x, t| *t != Term::Var(x.clone()));
    s
}

fn compose(a: &Subst, b: &Subst) -> Subst {
    clean(
        a.keys()
            .chain(b.keys())
            .map(|x| (x.clone(), apply_substitution(&image(a, x), b)))
            .collect(),
    )
}

fn commutes(a: &Subst, b: &Subst) -> bool {
    compose(a, b) == compose(b, a)
}

// Solve a ; rho = b by first-order matching, then validate the complete
// substitution equation (including variables outside the initial domains).
fn right_factor(a: &Subst, b: &Subst) -> Option<Subst> {
    let vars: BTreeSet<_> = a
        .keys()
        .chain(b.keys())
        .cloned()
        .chain(a.values().chain(b.values()).flat_map(Term::variables))
        .collect();
    let mut rho = Subst::new();
    for v in vars {
        let candidate = match_pattern(&image(a, &v), &image(b, &v))?;
        rho = union(&rho, &candidate)?;
    }
    let rho = clean(rho);
    (compose(a, &rho) == *b).then_some(rho)
}

fn factor_on(a: &Subst, b: &Subst, vars: &BTreeSet<Variable>) -> Option<Subst> {
    let mut rho = Subst::new();
    for v in vars {
        rho = union(&rho, &match_pattern(&image(a, v), &image(b, v))?)?;
    }
    let rho = clean(rho);
    vars.iter()
        .all(|v| apply_substitution(&image(a, v), &rho) == image(b, v))
        .then_some(rho)
}

fn abstract_term(term: &Term, needle: &Term, variable: &Variable) -> Term {
    if term == needle {
        return Term::Var(variable.clone());
    }
    match term {
        Term::Var(_) => term.clone(),
        Term::App { symbol, args } => Term::App {
            symbol: symbol.clone(),
            args: args
                .iter()
                .map(|t| abstract_term(t, needle, variable))
                .collect(),
        },
    }
}

// Propagate a proposed pumping action through closing aliases. For example,
// mu(z)=y and rho(y)=s(y) force rho(z)=s(z). Every inferred image is checked
// against its equation, and the final substitutions must commute globally.
fn commuting_extension(mut extra: Subst, contexts: &[&Subst]) -> Option<Subst> {
    let fixed: BTreeSet<_> = extra.keys().cloned().collect();
    for _ in 0..16 {
        if contexts.iter().all(|s| commutes(&extra, s)) {
            return Some(extra);
        }
        let old = extra.clone();
        for context in contexts {
            let vars: BTreeSet<_> = context.keys().chain(extra.keys()).cloned().collect();
            for v in vars {
                let rhs = apply_substitution(&image(context, &v), &extra);
                let lhs = apply_substitution(&image(&extra, &v), context);
                if lhs == rhs {
                    continue;
                }
                if let Some(required) = match_pattern(&image(context, &v), &lhs) {
                    if let Some(extended) = union(&extra, &required) {
                        if extended != extra {
                            extra = extended;
                            continue;
                        }
                    }
                }
                if fixed.contains(&v) {
                    return None;
                }
                let candidate = abstract_term(&rhs, &image(context, &v), &v);
                if apply_substitution(&candidate, context) != rhs {
                    return None;
                }
                extra.insert(v, candidate);
                extra = clean(extra);
            }
        }
        if extra == old {
            return None;
        }
    }
    None
}

// Restrict a free parameter to a pattern over existing iteration variables.
// Pumping/closing instantiation followed by a checked simplification supplies
// the proof; substituting a bound variable directly would be invalid.
fn bind_free_pattern(p: PatternRule, v: &Variable, term: &Term) -> Option<PatternRule> {
    let (rs, rm) = right(&p);
    if domains(&p).contains(v)
        || term.variables().contains(v)
        || rs != &p.pumping_substitution
        || rm != &p.closing_substitution
    {
        return None;
    }
    let sigma = p.pumping_substitution.clone();
    let mu = p.closing_substitution.clone();
    let pumped = apply_substitution(term, &sigma);
    let lifted = abstract_term(&pumped, term, v);
    let binding = Subst::from([(v.clone(), term.clone())]);
    if apply_substitution(&lifted, &binding) != pumped {
        return None;
    }
    let extra = commuting_extension(clean(Subst::from([(v.clone(), lifted)])), &[&sigma, &mu])?;
    let mut p = instantiate_pattern_rule(p, extra, PatternInstantiationTarget::Pumping);
    let close = clean(Subst::from([(v.clone(), apply_substitution(term, &mu))]));
    p = instantiate_pattern_rule(p, close, PatternInstantiationTarget::Closing);
    if !commutes(&binding, &p.pumping_substitution) {
        return None;
    }
    let mut second = p.closing_substitution.clone();
    second.remove(v);
    if compose(&binding, &second) != p.closing_substitution {
        return None;
    }
    for left in [true, false] {
        let t = apply_substitution(if left { &p.lhs } else { &p.rhs }, &binding);
        let sigma = p.pumping_substitution.clone();
        p = equivalent(
            p,
            left,
            t,
            sigma,
            second.clone(),
            PatternEquivalence::Simplification {
                first_substitution: binding.clone(),
                second_substitution: second.clone(),
            },
        );
    }
    Some(p)
}

fn identify_domains(p: PatternRule, v: &Variable, w: &Variable) -> Option<PatternRule> {
    if v == w || !domains(&p).contains(v) || !domains(&p).contains(w) {
        return None;
    }
    let (rs, rm) = right(&p);
    if rs != &p.pumping_substitution || rm != &p.closing_substitution {
        return None;
    }
    let mut mgu = Subst::new();
    if !unify_terms(
        &image(&p.closing_substitution, v),
        &image(&p.closing_substitution, w),
        &mut mgu,
    ) {
        return None;
    }
    let mut p = base(p, &mgu)?;
    let first = Subst::from([(v.clone(), Term::Var(w.clone()))]);
    if !commutes(&first, &p.pumping_substitution) {
        return None;
    }
    let mut second = p.closing_substitution.clone();
    second.remove(v);
    if compose(&first, &second) != p.closing_substitution {
        return None;
    }
    for left in [true, false] {
        let t = apply_substitution(if left { &p.lhs } else { &p.rhs }, &first);
        let sigma = p.pumping_substitution.clone();
        p = equivalent(
            p,
            left,
            t,
            sigma,
            second.clone(),
            PatternEquivalence::Simplification {
                first_substitution: first.clone(),
                second_substitution: second.clone(),
            },
        );
    }
    Some(p)
}

fn right(p: &PatternRule) -> (&Subst, &Subst) {
    (
        p.rhs_pumping_substitution
            .as_ref()
            .unwrap_or(&p.pumping_substitution),
        p.rhs_closing_substitution
            .as_ref()
            .unwrap_or(&p.closing_substitution),
    )
}

fn variables(p: &PatternRule) -> BTreeSet<Variable> {
    let (s, m) = right(p);
    let mut vars = p
        .lhs
        .variables()
        .into_iter()
        .chain(p.rhs.variables())
        .collect::<BTreeSet<_>>();
    for sub in [&p.pumping_substitution, &p.closing_substitution, s, m] {
        vars.extend(sub.keys().cloned());
        for t in sub.values() {
            vars.extend(t.variables());
        }
    }
    vars
}

fn domains(p: &PatternRule) -> BTreeSet<Variable> {
    let (s, m) = right(p);
    [&p.pumping_substitution, &p.closing_substitution, s, m]
        .into_iter()
        .flat_map(|s| s.keys().cloned())
        .collect()
}

#[derive(Default)]
struct Fresh {
    used: BTreeSet<Variable>,
    next: usize,
}
impl Fresh {
    fn variable(&mut self) -> Variable {
        loop {
            let v = Variable::new(format!("__pattern{}", self.next));
            self.next += 1;
            if self.used.insert(v.clone()) {
                return v;
            }
        }
    }
}

fn base(p: PatternRule, substitution: &Subst) -> Option<PatternRule> {
    let vars = variables(&p);
    let substitution = clean(
        substitution
            .iter()
            .filter(|(v, _)| vars.contains(*v))
            .map(|(v, t)| (v.clone(), t.clone()))
            .collect(),
    );
    if substitution.is_empty() {
        return Some(p);
    }
    let forbidden = domains(&p);
    if substitution
        .iter()
        .any(|(v, t)| forbidden.contains(v) || !t.variables().is_disjoint(&forbidden))
    {
        return None;
    }
    Some(instantiate_pattern_rule(
        p,
        substitution,
        PatternInstantiationTarget::Base,
    ))
}

fn equivalent(
    p: PatternRule,
    left: bool,
    t: Term,
    sigma: Subst,
    mu: Subst,
    equivalence: PatternEquivalence,
) -> PatternRule {
    let (rs, rm) = right(&p);
    let mut result = PatternRule {
        lhs: p.lhs.clone(),
        rhs: p.rhs.clone(),
        pumping_substitution: p.pumping_substitution.clone(),
        closing_substitution: p.closing_substitution.clone(),
        rhs_pumping_substitution: Some(rs.clone()),
        rhs_closing_substitution: Some(rm.clone()),
        proof: PatternRuleProof::Equivalence {
            pattern_rule: Box::new(p),
            side: if left {
                PatternEquivalenceSide::Left
            } else {
                PatternEquivalenceSide::Right
            },
            equivalence,
        },
    };
    if left {
        result.lhs = t;
        result.pumping_substitution = sigma;
        result.closing_substitution = mu;
    } else {
        result.rhs = t;
        result.rhs_pumping_substitution = Some(sigma);
        result.rhs_closing_substitution = Some(mu);
    }
    result
}

fn rename_domain(p: PatternRule, left: bool, fresh: &mut Fresh) -> PatternRule {
    let (s, m) = if left {
        (&p.pumping_substitution, &p.closing_substitution)
    } else {
        right(&p)
    };
    let dom = s.keys().chain(m.keys()).cloned().collect::<BTreeSet<_>>();
    fresh.used.extend(variables(&p));
    let rename = dom
        .into_iter()
        .map(|v| (v, Term::Var(fresh.variable())))
        .collect();
    rename_with(p, left, &rename).expect("fresh domain renaming")
}

fn rename_with(p: PatternRule, left: bool, rename: &Subst) -> Option<PatternRule> {
    let rename = clean(rename.clone());
    if rename.is_empty() {
        return Some(p);
    }
    let (t, s, m) = if left {
        (&p.lhs, &p.pumping_substitution, &p.closing_substitution)
    } else {
        let (s, m) = right(&p);
        (&p.rhs, s, m)
    };
    let dom = s.keys().chain(m.keys()).cloned().collect::<BTreeSet<_>>();
    let mut vars = t.variables();
    vars.extend(dom.iter().cloned());
    for term in s.values().chain(m.values()) {
        vars.extend(term.variables());
    }
    let mut targets = BTreeSet::new();
    for (v, term) in &rename {
        let Term::Var(w) = term else {
            return None;
        };
        if !dom.contains(v) || vars.contains(w) || !targets.insert(w.clone()) {
            return None;
        }
    }
    let renamed = |v: &Variable| match rename.get(v) {
        Some(Term::Var(w)) => w.clone(),
        _ => v.clone(),
    };
    let sigma = s
        .iter()
        .map(|(v, t)| (renamed(v), apply_substitution(t, &rename)))
        .collect();
    // The closing substitution restores the original (free) variables, not
    // the renamed domain variables. This distinction is essential.
    let mut mu: Subst = m.iter().map(|(v, t)| (renamed(v), t.clone())).collect();
    for v in rename.keys() {
        mu.entry(renamed(v)).or_insert_with(|| Term::Var(v.clone()));
    }
    let t = apply_substitution(t, &rename);
    Some(equivalent(
        p,
        left,
        t,
        sigma,
        mu,
        PatternEquivalence::DomainRenaming {
            substitution: rename,
        },
    ))
}

fn relevant(t: &Term, s: &Subst) -> BTreeSet<Variable> {
    let mut vars = t.variables();
    loop {
        let old = vars.len();
        for v in vars.clone() {
            vars.extend(image(s, &v).variables());
        }
        if vars.len() == old {
            return vars;
        }
    }
}

fn irrelevant(p: PatternRule, left: bool, sigma: &Subst, mu: &Subst) -> Option<PatternRule> {
    let (t, s, m) = if left {
        (&p.lhs, &p.pumping_substitution, &p.closing_substitution)
    } else {
        let (s, m) = right(&p);
        (&p.rhs, s, m)
    };
    if relevant(t, s)
        .iter()
        .any(|v| image(s, v) != image(sigma, v) || image(m, v) != image(mu, v))
    {
        return None;
    }
    if s == sigma && m == mu {
        return Some(p);
    }
    let t = t.clone();
    Some(equivalent(
        p,
        left,
        t,
        sigma.clone(),
        mu.clone(),
        PatternEquivalence::Irrelevant {
            base_substitution: sigma.clone(),
            pumping_substitution: mu.clone(),
        },
    ))
}

fn union(a: &Subst, b: &Subst) -> Option<Subst> {
    let mut out = a.clone();
    for (v, t) in b {
        if out.get(v).is_some_and(|old| old != t) {
            return None;
        }
        out.insert(v.clone(), t.clone());
    }
    Some(clean(out))
}

fn normalize(p: PatternRule, fresh: &mut Fresh) -> Option<PatternRule> {
    let p = rename_domain(p, true, fresh);
    let p = rename_domain(p, false, fresh);
    let (rs, rm) = right(&p);
    let sigma = union(&p.pumping_substitution, rs)?;
    let mu = union(&p.closing_substitution, rm)?;
    let p = irrelevant(p, true, &sigma, &mu)?;
    irrelevant(p, false, &sigma, &mu)
}

fn initial(p: PatternRule, fresh: &mut Fresh) -> Option<PatternRule> {
    let (rs, rm) = right(&p);
    if !p.pumping_substitution.is_empty()
        || !p.closing_substitution.is_empty()
        || !rs.is_empty()
        || !rm.is_empty()
    {
        return None;
    }
    let rename = p
        .lhs
        .variables()
        .iter()
        .map(|v| (v.clone(), Term::Var(fresh.variable())))
        .collect::<Subst>();
    let inverse = rename
        .iter()
        .map(|(v, t)| match t {
            Term::Var(w) => (w.clone(), Term::Var(v.clone())),
            _ => unreachable!(),
        })
        .collect::<Subst>();
    let mut mgu = Subst::new();
    if !unify_terms(&apply_substitution(&p.lhs, &rename), &p.rhs, &mut mgu) {
        return None;
    }
    let theta = clean(
        p.lhs
            .variables()
            .iter()
            .map(|v| {
                (
                    v.clone(),
                    apply_substitution(&apply_substitution(&image(&rename, v), &mgu), &inverse),
                )
            })
            .collect(),
    );
    let sigma = clean(
        p.rhs
            .variables()
            .iter()
            .map(|v| (v.clone(), apply_substitution(&image(&mgu, v), &inverse)))
            .collect(),
    );
    if sigma.is_empty() && theta.is_empty() {
        return None;
    }
    if apply_substitution(&p.lhs, &theta) != apply_substitution(&p.rhs, &sigma)
        || !commutes(&sigma, &theta)
    {
        return None;
    }
    let out = PatternRule {
        lhs: p.lhs.clone(),
        rhs: p.rhs.clone(),
        pumping_substitution: sigma.clone(),
        closing_substitution: Subst::new(),
        rhs_pumping_substitution: Some(theta.clone()),
        rhs_closing_substitution: Some(Subst::new()),
        proof: PatternRuleProof::InitialPumping {
            pattern_rule: Box::new(p),
            pumping_substitution: sigma,
            closing_substitution: theta,
        },
    };
    normalize(out, fresh)
}

fn initial_context(p: &PatternRule, fresh: &mut Fresh) -> Vec<PatternRule> {
    fn contains_pair(p: &PatternRule) -> bool {
        match &p.proof {
            PatternRuleProof::OriginalRule { is_pair, .. } => *is_pair,
            PatternRuleProof::Narrowing {
                pattern_rule,
                narrowing_rule,
                ..
            } => contains_pair(pattern_rule) || contains_pair(narrowing_rule),
            PatternRuleProof::InitialPumping { pattern_rule, .. }
            | PatternRuleProof::InitialPumpingContext { pattern_rule, .. }
            | PatternRuleProof::Instantiation { pattern_rule, .. }
            | PatternRuleProof::InstantiationPumping { pattern_rule, .. }
            | PatternRuleProof::Rewriting { pattern_rule, .. }
            | PatternRuleProof::Equivalence { pattern_rule, .. } => contains_pair(pattern_rule),
        }
    }
    let mut result = Vec::new();
    // Context pumping cannot repeat marked steps below the root.
    let (rs, rm) = right(p);
    if contains_pair(p)
        || !p.pumping_substitution.is_empty()
        || !p.closing_substitution.is_empty()
        || !rs.is_empty()
        || !rm.is_empty()
    {
        return result;
    }
    for (position, subterm) in positions_with_subterms(&p.rhs) {
        if position.is_empty() || matches!(subterm, Term::Var(_)) {
            continue;
        }
        let Some(sigma) = match_pattern(subterm, &p.lhs).map(clean) else {
            continue;
        };
        if apply_substitution(subterm, &sigma) != p.lhs {
            continue;
        }
        fresh.used.extend(variables(p));
        let z = fresh.variable();
        let Some(context) = replace_subterm_at_position(&p.rhs, &position, &Term::Var(z.clone()))
        else {
            continue;
        };
        let mut theta = sigma.clone();
        theta.insert(z.clone(), context.clone());
        let out = PatternRule {
            lhs: p.lhs.clone(),
            rhs: context,
            pumping_substitution: sigma.clone(),
            closing_substitution: Subst::new(),
            rhs_pumping_substitution: Some(theta),
            rhs_closing_substitution: Some(Subst::from([(z.clone(), subterm.clone())])),
            proof: PatternRuleProof::InitialPumpingContext {
                pattern_rule: Box::new(p.clone()),
                pumping_substitution: sigma,
                position,
                variable: z,
            },
        };
        if let Some(out) = normalize(out, fresh) {
            result.push(out);
        }
    }
    result
}

fn extend(mut p: PatternRule, sigma: &Subst, mu: &Subst) -> Option<PatternRule> {
    if let Some(out) =
        irrelevant(p.clone(), true, sigma, mu).and_then(|p| irrelevant(p, false, sigma, mu))
    {
        return Some(out);
    }
    let (rs, rm) = right(&p);
    if rs != &p.pumping_substitution || rm != &p.closing_substitution {
        return None;
    }
    let extra = clean(
        sigma
            .iter()
            .filter(|(v, _)| !p.pumping_substitution.contains_key(*v))
            .map(|(v, t)| (v.clone(), t.clone()))
            .collect(),
    );
    if !commutes(&extra, &p.pumping_substitution)
        || !commutes(&extra, &p.closing_substitution)
        || compose(&p.pumping_substitution, &extra) != *sigma
    {
        return None;
    }
    if !extra.is_empty() {
        p = instantiate_pattern_rule(p, extra, PatternInstantiationTarget::Pumping);
    }
    let extra = clean(
        mu.iter()
            .filter(|(v, _)| !p.closing_substitution.contains_key(*v))
            .map(|(v, t)| (v.clone(), t.clone()))
            .collect(),
    );
    if compose(&p.closing_substitution, &extra) != *mu {
        return None;
    }
    if !extra.is_empty() {
        p = instantiate_pattern_rule(p, extra, PatternInstantiationTarget::Closing);
    }
    Some(p)
}

fn narrow(
    a: &PatternRule,
    b: &PatternRule,
    position: &[usize],
    fresh: &mut Fresh,
) -> Option<PatternRule> {
    if let (Term::App { symbol: f, args: a }, Term::App { symbol: g, args: b }) =
        (subterm_at_position(&a.rhs, position)?, &b.lhs)
    {
        if f != g || a.len() != b.len() {
            return None;
        }
    }
    narrow_unshifted(a, b, position, fresh).or_else(|| {
        if domains(a).is_empty() {
            return None;
        }
        let (rs, _) = right(a);
        let mut lhs = a.lhs.clone();
        let mut rhs = a.rhs.clone();
        for power in 1..=2 {
            lhs = apply_substitution(&lhs, &a.pumping_substitution);
            rhs = apply_substitution(&rhs, rs);
            if lhs == a.lhs && rhs == a.rhs {
                return None;
            }
            let mut shifted = a.clone();
            shifted.lhs = lhs.clone();
            shifted.rhs = rhs.clone();
            shifted.proof = PatternRuleProof::InstantiationPumping {
                pattern_rule: Box::new(a.clone()),
                power,
            };
            if let Some(out) = narrow_unshifted(&shifted, b, position, fresh) {
                return Some(out);
            }
        }
        None
    })
}

fn narrow_unshifted(
    a: &PatternRule,
    b: &PatternRule,
    position: &[usize],
    fresh: &mut Fresh,
) -> Option<PatternRule> {
    narrow_basic(a, b, position, fresh).or_else(|| {
        let mut a = normalize(trimmed(a.clone())?, fresh)?;
        let mut b = normalize(trimmed(b.clone())?, fresh)?;
        for _ in 0..4 {
            let subterm = subterm_at_position(&a.rhs, position)?;
            let mut mgu = Subst::new();
            if !unify_terms(subterm, &b.lhs, &mut mgu) {
                return None;
            }
            let mut changed = false;
            for (v, t) in &mgu {
                for p in [&mut a, &mut b] {
                    let dom = domains(p);
                    if let Term::Var(w) = t {
                        if let Some(next) = identify_domains(p.clone(), v, w) {
                            *p = next;
                            changed = true;
                            continue;
                        }
                    }
                    if variables(p).contains(v)
                        && !dom.contains(v)
                        && !t.variables().is_disjoint(&dom)
                    {
                        if let Some(next) = bind_free_pattern(p.clone(), v, t) {
                            *p = next;
                            changed = true;
                        }
                    }
                }
            }
            if let Some(result) = narrow_basic(&a, &b, position, fresh) {
                return Some(result);
            }
            if !changed {
                return None;
            }
        }
        None
    })
}

fn narrow_basic(
    a: &PatternRule,
    b: &PatternRule,
    position: &[usize],
    fresh: &mut Fresh,
) -> Option<PatternRule> {
    // Reusing an accelerated helper must not identify its iteration variable
    // with an earlier occurrence. Domain renaming is an equivalence, whereas
    // ordinary base instantiation is forbidden on those variables.
    let renamed;
    let b = if !domains(a).is_disjoint(&domains(b)) {
        renamed = normalize(b.clone(), fresh)?;
        &renamed
    } else {
        b
    };
    let subterm = subterm_at_position(&a.rhs, position)?;
    if matches!(subterm, Term::Var(_)) {
        return None;
    }
    let mut mgu = Subst::new();
    if !unify_terms(subterm, &b.lhs, &mut mgu) {
        return None;
    }
    let adom = domains(a);
    let bdom = domains(b);
    let mut align = Subst::new();
    for (v, term) in &mgu {
        let Term::Var(w) = term else {
            continue;
        };
        if adom.contains(v) && bdom.contains(w) {
            align.insert(w.clone(), Term::Var(v.clone()));
        }
        if bdom.contains(v) && adom.contains(w) {
            align.insert(v.clone(), Term::Var(w.clone()));
        }
    }
    let b = if align.is_empty() {
        b.clone()
    } else {
        let b = rename_with(b.clone(), true, &align)?;
        rename_with(b, false, &align)?
    };
    mgu.clear();
    if !unify_terms(subterm, &b.lhs, &mut mgu) {
        return None;
    }
    let a = base(a.clone(), &mgu)?;
    let b = base(b, &mgu)?;
    // Base matching alone cannot see free parameters inside closing images.
    // Unify those shared context equations too, but apply the solution only
    // through the existing bound-domain-safe base instantiation constructor.
    let mut context_mgu = Subst::new();
    for (sa, sb) in [
        (&a.pumping_substitution, &b.pumping_substitution),
        (&a.closing_substitution, &b.closing_substitution),
    ] {
        for (v, t) in sa {
            if let Some(u) = sb.get(v) {
                if !unify_terms(t, u, &mut context_mgu) {
                    return None;
                }
            }
        }
    }
    let a = base(a, &context_mgu)?;
    let b = base(b, &context_mgu)?;
    let sigma = union(&a.pumping_substitution, &b.pumping_substitution)?;
    let mu = union(&a.closing_substitution, &b.closing_substitution)?;
    let a = extend(a, &sigma, &mu)?;
    let b = extend(b, &sigma, &mu)?;
    if subterm_at_position(&a.rhs, position)? != &b.lhs {
        return None;
    }
    let rhs = replace_subterm_at_position(&a.rhs, position, &b.rhs)?;
    Some(narrow_pattern_rule(a, b, position.to_vec(), rhs))
}

fn closed_basic(p: &PatternRule) -> Option<DpNonterminationProof> {
    let (rs, rm) = right(p);
    if rs != &p.pumping_substitution || rm != &p.closing_substitution {
        return None;
    }
    let mut lhs = p.lhs.clone();
    for shift in 0..=4 {
        let mut mgu = Subst::new();
        let candidate = if unify_terms(&lhs, &p.rhs, &mut mgu) {
            base(p.clone(), &mgu)
        } else {
            None
        };
        if let Some(candidate) = candidate.filter(|q| {
            let mut term = q.lhs.clone();
            for _ in 0..shift {
                term = apply_substitution(&term, &q.pumping_substitution);
            }
            term == q.rhs
        }) {
            return Some(DpNonterminationProof::NonLoop(NonLoopProof {
                pattern_rule: candidate,
                pumping_substitution: Subst::new(),
                closing_substitution: Subst::new(),
                pumping_decomposition: 1,
                subterm_index: shift,
                position: vec![],
            }));
        }
        lhs = apply_substitution(&lhs, &p.pumping_substitution);
    }
    None
}

fn trimmed(mut p: PatternRule) -> Option<PatternRule> {
    for left in [true, false] {
        let (t, s, m) = if left {
            (&p.lhs, &p.pumping_substitution, &p.closing_substitution)
        } else {
            let (s, m) = right(&p);
            (&p.rhs, s, m)
        };
        let vars = relevant(t, s);
        let sigma = s
            .iter()
            .filter(|(v, _)| vars.contains(*v))
            .map(|(v, t)| (v.clone(), t.clone()))
            .collect();
        let mu = m
            .iter()
            .filter(|(v, _)| vars.contains(*v))
            .map(|(v, t)| (v.clone(), t.clone()))
            .collect();
        p = irrelevant(p, left, &sigma, &mu)?;
    }
    Some(p)
}

fn closed(p: &PatternRule) -> Option<DpNonterminationProof> {
    if let (Term::App { symbol: f, .. }, Term::App { symbol: g, .. }) = (&p.lhs, &p.rhs) {
        if f != g {
            return None;
        }
    }
    closed_inner(p)
        .or_else(|| {
            let mut fresh = Fresh::default();
            fresh.used.extend(variables(p));
            closed_inner(&rename_domain(p.clone(), true, &mut fresh))
        })
        .or_else(|| {
            let p = trimmed(p.clone())?;
            let desired = match_pattern(&p.lhs, &p.rhs)?;
            let mut target = p.pumping_substitution.clone();
            target.extend(desired);
            let extra = right_factor(&p.pumping_substitution, &clean(target))?;
            if extra.is_empty() {
                return None;
            }
            let (rs, rm) = right(&p);
            let extra = commuting_extension(
                extra,
                &[&p.pumping_substitution, &p.closing_substitution, rs, rm],
            )?;
            let p = instantiate_pattern_rule(p, extra, PatternInstantiationTarget::Pumping);
            closed_inner(&p)
        })
        .or_else(|| {
            let (rs, _) = right(p);
            let mut lhs = p.lhs.clone();
            let mut rhs = p.rhs.clone();
            for power in 1..=4 {
                lhs = apply_substitution(&lhs, &p.pumping_substitution);
                rhs = apply_substitution(&rhs, rs);
                if lhs == p.lhs && rhs == p.rhs {
                    return None;
                }
                let mut q = p.clone();
                q.lhs = lhs.clone();
                q.rhs = rhs.clone();
                q.proof = PatternRuleProof::InstantiationPumping {
                    pattern_rule: Box::new(p.clone()),
                    power,
                };
                if let Some(proof) = closed_inner(&q) {
                    return Some(proof);
                }
            }
            None
        })
}

fn closed_inner(p: &PatternRule) -> Option<DpNonterminationProof> {
    if let Some(proof) = closed_basic(p) {
        return Some(proof);
    }
    let p = trimmed(p.clone())?;
    let mut lhs = p.lhs.clone();
    for shift in 0..=4 {
        // Align only bound iteration variables, using an actual equivalence
        // proof. Free-variable instantiation cannot substitute for this step.
        if let Some(rename) = pumping_substitution_to_match(&lhs, &p.rhs) {
            if let Some(mut q) = rename_with(p.clone(), true, &rename) {
                // Closing parameters are free, unlike iteration variables.
                // Solve their compatibility equations by unification, then
                // use the ordinary checked base-instantiation constructor.
                // This discovers exit instances without enumerating terms.
                let (rs, rm) = right(&q);
                let active = relevant(&q.rhs, rs);
                if factor_on(&q.closing_substitution, rm, &active).is_none() {
                    let mut substitution = Subst::new();
                    let compatible = active.iter().all(|v| {
                        unify_terms(
                            &image(&q.closing_substitution, v),
                            &image(rm, v),
                            &mut substitution,
                        )
                    });
                    if compatible {
                        if let Some(instance) = base(q.clone(), &substitution) {
                            q = instance;
                        }
                    }
                }
                let (rs, rm) = right(&q);
                let mut shifted = q.lhs.clone();
                for _ in 0..shift {
                    shifted = apply_substitution(&shifted, &q.pumping_substitution);
                }
                if shifted == q.rhs {
                    let active = relevant(&q.rhs, rs);
                    let Some(extra_close) = factor_on(&q.closing_substitution, rm, &active) else {
                        continue;
                    };
                    let target_close = compose(&q.closing_substitution, &extra_close);
                    let mut power = Subst::new();
                    for exponent in 0..=4 {
                        if let Some(extra_pump) = factor_on(&power, rs, &active).and_then(|extra| {
                            commuting_extension(
                                extra,
                                &[&q.pumping_substitution, &q.closing_substitution],
                            )
                        }) {
                            let target_pump = compose(&power, &extra_pump);
                            if let Some(final_rule) =
                                irrelevant(q.clone(), false, &target_pump, &target_close)
                            {
                                return Some(DpNonterminationProof::NonLoop(NonLoopProof {
                                    pattern_rule: final_rule,
                                    pumping_substitution: extra_pump,
                                    closing_substitution: extra_close.clone(),
                                    pumping_decomposition: exponent,
                                    subterm_index: shift,
                                    position: vec![],
                                }));
                            }
                        }
                        power = compose(&power, &q.pumping_substitution);
                    }
                }
            }
        }
        lhs = apply_substitution(&lhs, &p.pumping_substitution);
    }
    None
}

fn key(p: &PatternRule) -> String {
    fn term(t: &Term, ids: &mut BTreeMap<Variable, usize>) -> String {
        match t {
            Term::Var(v) => {
                let next = ids.len();
                format!("v{}", ids.entry(v.clone()).or_insert(next))
            }
            Term::App { symbol, args } => format!(
                "({symbol:?}:{})",
                args.iter()
                    .map(|t| term(t, ids))
                    .collect::<Vec<_>>()
                    .join(",")
            ),
        }
    }
    let mut ids = BTreeMap::new();
    let mut out = format!("{}|{}", term(&p.lhs, &mut ids), term(&p.rhs, &mut ids));
    let (rs, rm) = right(p);
    for (t, s, m) in [
        (&p.lhs, &p.pumping_substitution, &p.closing_substitution),
        (&p.rhs, rs, rm),
    ] {
        let vars = relevant(t, s);
        let mut done = BTreeSet::new();
        let mut sigma = Vec::new();
        while done.len() < vars.len() {
            let mut ready: Vec<_> = vars
                .iter()
                .filter(|v| !done.contains(*v))
                .filter_map(|v| ids.get(v).map(|id| (*id, v.clone())))
                .collect();
            ready.sort();
            assert!(
                !ready.is_empty(),
                "pumping reachability starts at base variables"
            );
            for (id, v) in ready {
                sigma.push((id, term(&image(s, &v), &mut ids)));
                done.insert(v);
            }
        }
        sigma.sort();
        let mut ordered: Vec<_> = vars.iter().map(|v| (ids[v], v)).collect();
        ordered.sort();
        let mu: Vec<_> = ordered
            .into_iter()
            .map(|(id, v)| (id, term(&image(m, v), &mut ids)))
            .collect();
        out.push_str(&format!("|{sigma:?}|{mu:?}"));
    }
    out
}

fn pattern_cost(p: &PatternRule, defined: &BTreeSet<Symbol>) -> usize {
    fn cost(t: &Term, defined: &BTreeSet<Symbol>) -> usize {
        match t {
            Term::Var(_) => 0,
            Term::App { symbol, args } => {
                usize::from(defined.contains(symbol))
                    + args.iter().map(|t| cost(t, defined)).sum::<usize>()
            }
        }
    }
    let (s, m) = right(p);
    cost(&p.rhs, defined)
        + relevant(&p.rhs, s)
            .iter()
            .map(|v| cost(&image(m, v), defined))
            .sum::<usize>()
}

// Cache each immutable state's priority at insertion. Recomputing substitution
// closures for every queued state on every pop made the old queue quadratic.
// Front/back tickets preserve the old stable tie-breaking exactly.
struct PatternQueue<'a> {
    entries: BTreeMap<(usize, usize, i64), PatternRule>,
    defined: &'a BTreeSet<Symbol>,
    front: i64,
    back: i64,
}

impl<'a> PatternQueue<'a> {
    fn new(defined: &'a BTreeSet<Symbol>) -> Self {
        Self {
            entries: BTreeMap::new(),
            defined,
            front: 0,
            back: 0,
        }
    }
    fn len(&self) -> usize {
        self.entries.len()
    }
    fn push_back(&mut self, (p, depth): (PatternRule, usize)) {
        self.back += 1;
        self.entries
            .insert((pattern_cost(&p, self.defined), depth, self.back), p);
    }
    fn push_front(&mut self, (p, depth): (PatternRule, usize)) {
        self.front -= 1;
        self.entries
            .insert((pattern_cost(&p, self.defined), depth, self.front), p);
    }
    fn pop(&mut self) -> Option<(PatternRule, usize)> {
        self.entries
            .pop_first()
            .map(|((_, depth, _), p)| (p, depth))
    }
}

// Constructor clashes cannot be repaired by R rewriting. Defined calls and
// variables remain wildcards: this is only a conservative search filter.
fn may_enable_marked(t: &Term, lhs: &Term, defined: &BTreeSet<Symbol>) -> bool {
    match (t, lhs) {
        (Term::Var(_), _) | (_, Term::Var(_)) => true,
        (
            Term::App { symbol, args },
            Term::App {
                symbol: other,
                args: rhs,
            },
        ) => {
            defined.contains(symbol)
                || (symbol == other
                    && args.len() == rhs.len()
                    && args
                        .iter()
                        .zip(rhs)
                        .all(|(a, b)| may_enable_marked(a, b, defined)))
        }
    }
}

// Move a commuting part of the closing substitution into the base. Avoid
// enumerating subsets: prune conflicting entries to a fixed point, then check
// both equations required by CeTA's Pat_Simplify independently.
fn simplify(mut p: PatternRule) -> PatternRule {
    for left in [true, false] {
        // Factor a commuting context out of a closing image. E.g. closing
        // x -> s(s(0)) may become base-context s(s(x)), closing x -> 0.
        // Candidates are live subterms, not an enumeration of substitutions.
        loop {
            let (t, sigma, mu) = if left {
                (&p.lhs, &p.pumping_substitution, &p.closing_substitution)
            } else {
                let (s, m) = right(&p);
                (&p.rhs, s, m)
            };
            let mut candidate = None;
            'images: for (v, image) in mu {
                let mut positions = positions_with_subterms(image);
                positions.sort_by_key(|(pos, _)| std::cmp::Reverse(pos.len()));
                for (pos, subterm) in positions {
                    if pos.is_empty() {
                        continue;
                    }
                    let Some(context) =
                        replace_subterm_at_position(image, &pos, &Term::Var(v.clone()))
                    else {
                        continue;
                    };
                    let first = clean(Subst::from([(v.clone(), context)]));
                    if first.is_empty() || !commutes(&first, sigma) {
                        continue;
                    }
                    let mut second = mu.clone();
                    second.insert(v.clone(), subterm.clone());
                    second = clean(second);
                    if compose(&first, &second) != *mu {
                        continue;
                    }
                    candidate = Some((apply_substitution(t, &first), sigma.clone(), first, second));
                    break 'images;
                }
            }
            let Some((t, sigma, first, second)) = candidate else {
                break;
            };
            p = equivalent(
                p,
                left,
                t,
                sigma,
                second.clone(),
                PatternEquivalence::Simplification {
                    first_substitution: first,
                    second_substitution: second,
                },
            );
        }
        // Equal closing images can identify independently introduced iteration
        // variables, but only when the identification commutes with pumping.
        // This factors mu rather than merely selecting a subset of its entries.
        loop {
            let (t, sigma, mu) = if left {
                (&p.lhs, &p.pumping_substitution, &p.closing_substitution)
            } else {
                let (s, m) = right(&p);
                (&p.rhs, s, m)
            };
            let mut candidate = None;
            for (v, image_v) in mu {
                for (w, image_w) in mu.range(..v.clone()) {
                    if image_v != image_w {
                        continue;
                    }
                    let first = Subst::from([(v.clone(), Term::Var(w.clone()))]);
                    let mut second = mu.clone();
                    second.remove(v);
                    if commutes(&first, sigma) && compose(&first, &second) == *mu {
                        candidate =
                            Some((apply_substitution(t, &first), sigma.clone(), first, second));
                        break;
                    }
                }
                if candidate.is_some() {
                    break;
                }
            }
            let Some((term, sigma, first, second)) = candidate else {
                break;
            };
            p = equivalent(
                p,
                left,
                term,
                sigma,
                second.clone(),
                PatternEquivalence::Simplification {
                    first_substitution: first,
                    second_substitution: second,
                },
            );
        }
        let (t, sigma, mu) = if left {
            (&p.lhs, &p.pumping_substitution, &p.closing_substitution)
        } else {
            let (s, m) = right(&p);
            (&p.rhs, s, m)
        };
        let mut first = mu.clone();
        loop {
            let ab = compose(&first, sigma);
            let ba = compose(sigma, &first);
            if ab == ba {
                break;
            }
            let bad: BTreeSet<_> = ab
                .keys()
                .chain(ba.keys())
                .filter(|v| image(&ab, v) != image(&ba, v))
                .cloned()
                .collect();
            let old = first.len();
            first.retain(|v, _| {
                !bad.contains(v) && !bad.iter().any(|w| image(sigma, w).variables().contains(v))
            });
            if first.len() == old {
                first.clear();
                break;
            }
        }
        if first.is_empty() {
            continue;
        }
        let second = mu
            .iter()
            .filter(|(v, _)| !first.contains_key(*v))
            .map(|(v, t)| (v.clone(), t.clone()))
            .collect();
        if !commutes(&first, sigma) || compose(&first, &second) != *mu {
            continue;
        }
        let term = apply_substitution(t, &first);
        let sigma = sigma.clone();
        p = equivalent(
            p,
            left,
            term,
            sigma,
            second.clone(),
            PatternEquivalence::Simplification {
                first_substitution: first,
                second_substitution: second,
            },
        );
    }
    p
}

fn rewrites(p: &PatternRule, trs: &Trs, deadline: Option<Instant>) -> Vec<PatternRule> {
    let (rs, rm) = right(p);
    let mut targets = vec![(PatternInstantiationTarget::Base, None, p.rhs.clone())];
    for (target, sub) in [
        (PatternInstantiationTarget::Pumping, rs),
        (PatternInstantiationTarget::Closing, rm),
    ] {
        for (v, t) in sub {
            targets.push((target.clone(), Some(v.clone()), t.clone()));
        }
    }
    let mut out = Vec::new();
    for (target, variable, start) in targets {
        for (position, term) in positions_with_subterms(&start) {
            for rule in trs.rules() {
                if strategy_timed_out(deadline) || out.len() >= 32 {
                    return out;
                }
                let Some(substitution) = match_pattern(rule.lhs(), term) else {
                    continue;
                };
                // A rewriting step is matching, never narrowing or grounding.
                if !rule.rhs().variables().is_subset(&rule.lhs().variables()) {
                    continue;
                }
                let replacement = apply_substitution(rule.rhs(), &substitution);
                let Some(result) = replace_subterm_at_position(&start, &position, &replacement)
                else {
                    continue;
                };
                if result == start {
                    continue;
                }
                let mut steps = vec![LoopRewriteStep {
                    position: position.clone(),
                    rule: rule.clone(),
                    result: result.clone(),
                }];
                steps.extend(rewrite_term_chain(&result, trs, deadline));
                let result = steps.last().unwrap().result.clone();
                let mut q = p.clone();
                q.rhs_pumping_substitution = Some(rs.clone());
                q.rhs_closing_substitution = Some(rm.clone());
                match target {
                    PatternInstantiationTarget::Base => q.rhs = result.clone(),
                    PatternInstantiationTarget::Pumping => {
                        q.rhs_pumping_substitution
                            .as_mut()
                            .unwrap()
                            .insert(variable.clone().unwrap(), result.clone());
                    }
                    PatternInstantiationTarget::Closing => {
                        q.rhs_closing_substitution
                            .as_mut()
                            .unwrap()
                            .insert(variable.clone().unwrap(), result.clone());
                    }
                }
                q.proof = PatternRuleProof::Rewriting {
                    pattern_rule: Box::new(p.clone()),
                    start: start.clone(),
                    steps,
                    target: target.clone(),
                    variable: variable.clone(),
                };
                q.rhs_pumping_substitution = q.rhs_pumping_substitution.map(clean);
                q.rhs_closing_substitution = q.rhs_closing_substitution.map(clean);
                out.push(q);
            }
        }
    }
    out
}

// Guess closing instances by unifying live redexes, never by enumerating
// ground terms. The base constructor rejects any change to bound variables.
fn closing_instances(
    p: &PatternRule,
    trs: &Trs,
    fresh: &mut Fresh,
    deadline: Option<Instant>,
) -> Vec<PatternRule> {
    let (_, mu) = right(p);
    let mut out = Vec::new();
    for term in mu.values() {
        for (_, subterm) in positions_with_subterms(term) {
            if matches!(subterm, Term::Var(_)) {
                continue;
            }
            for rule in trs.rules() {
                if strategy_timed_out(deadline) || out.len() >= 16 {
                    return out;
                }
                fresh.used.extend(variables(p));
                let rename: Subst = rule
                    .lhs()
                    .variables()
                    .into_iter()
                    .map(|v| (v, Term::Var(fresh.variable())))
                    .collect();
                let lhs = apply_substitution(rule.lhs(), &rename);
                let mut mgu = Subst::new();
                if !unify_terms(subterm, &lhs, &mut mgu) {
                    continue;
                }
                let Some(q) = base(p.clone(), &mgu) else {
                    continue;
                };
                for next in rewrites(&q, trs, deadline) {
                    if matches!(
                        next.proof,
                        PatternRuleProof::Rewriting {
                            target: PatternInstantiationTarget::Closing,
                            ..
                        }
                    ) {
                        out.push(next);
                    }
                    if out.len() >= 16 {
                        return out;
                    }
                }
            }
        }
    }
    out
}

fn rewrite_base_chain(
    p: &PatternRule,
    trs: &Trs,
    deadline: Option<Instant>,
) -> Option<PatternRule> {
    let steps = rewrite_term_chain(&p.rhs, trs, deadline);
    let current = steps.last()?.result.clone();
    Some(rewrite_pattern_rule(
        p.clone(),
        p.rhs.clone(),
        steps,
        PatternInstantiationTarget::Base,
        None,
        current,
    ))
}

fn rewrite_term_chain(start: &Term, trs: &Trs, deadline: Option<Instant>) -> Vec<LoopRewriteStep> {
    let mut current = start.clone();
    let mut steps = Vec::new();
    let mut seen = BTreeSet::new();
    for _ in 0..12 {
        if strategy_timed_out(deadline) || !seen.insert(current.clone()) {
            break;
        }
        let mut next = None;
        'positions: for (position, term) in positions_with_subterms(&current) {
            for rule in trs.rules() {
                let Some(sub) = match_pattern(rule.lhs(), term) else {
                    continue;
                };
                if !rule.rhs().variables().is_subset(&rule.lhs().variables()) {
                    continue;
                }
                let replacement = apply_substitution(rule.rhs(), &sub);
                let Some(result) = replace_subterm_at_position(&current, &position, &replacement)
                else {
                    continue;
                };
                if result == current || positions_with_subterms(&result).len() > 512 {
                    continue;
                }
                next = Some(LoopRewriteStep {
                    position,
                    rule: rule.clone(),
                    result,
                });
                break 'positions;
            }
        }
        let Some(step) = next else {
            break;
        };
        current = step.result.clone();
        steps.push(step);
    }
    steps
}

pub(super) fn search(
    trs: &Trs,
    pairs: &[DependencyPair],
    deadline: Option<Instant>,
) -> Option<DpNonterminationProof> {
    search_with_budget(trs, pairs, deadline, Duration::from_secs(60))
}

fn search_with_budget(
    trs: &Trs,
    pairs: &[DependencyPair],
    deadline: Option<Instant>,
    budget: Duration,
) -> Option<DpNonterminationProof> {
    let trace = std::env::var_os("FERRUM_TRACE_PATTERN_SEARCH").is_some();
    let started = Instant::now();
    let deadline =
        Some(deadline.map_or(Instant::now() + budget, |d| d.min(Instant::now() + budget)));
    let mut fresh = Fresh::default();
    for rule in trs
        .rules()
        .iter()
        .cloned()
        .chain(pairs.iter().map(DependencyPair::as_rule))
    {
        fresh.used.extend(rule.lhs().variables());
        fresh.used.extend(rule.rhs().variables());
    }
    let mut originals = Vec::new();
    for rule in trs.rules() {
        let p = original_rule_pattern_rule(rule);
        let renaming = variables(&p)
            .into_iter()
            .map(|v| (v, Term::Var(fresh.variable())))
            .collect();
        originals.push(base(p, &renaming)?);
    }
    let mut marked = Vec::new();
    for pair in pairs {
        let p = original_pair_pattern_rule(pair);
        let renaming = variables(&p)
            .into_iter()
            .map(|v| (v, Term::Var(fresh.variable())))
            .collect();
        marked.push(base(p, &renaming)?);
    }
    let mut helpers = originals.clone();
    let mut queue = VecDeque::new();
    let mut seen = BTreeSet::new();
    for p in &originals {
        if let Some(p) = initial(p.clone(), &mut fresh) {
            queue.push_back((p, 0));
        }
        for p in initial_context(p, &mut fresh) {
            queue.push_back((p, 0));
        }
    }
    // Build accelerated auxiliary relations and their bounded exit chains.
    while let Some((p, depth)) = queue.pop_front() {
        if strategy_timed_out(deadline) {
            if trace {
                eprintln!(
                    "pattern-search helper timeout: elapsed={:?} helpers={} seen={} queued={}",
                    started.elapsed(),
                    helpers.len(),
                    seen.len(),
                    queue.len()
                );
            }
            return None;
        }
        if !seen.insert(key(&p)) {
            continue;
        }
        helpers.push(p.clone());
        let simplified = simplify(p.clone());
        if key(&simplified) != key(&p) {
            if let Some(simplified) = trimmed(simplified).and_then(|p| normalize(p, &mut fresh)) {
                helpers.push(simplified);
            }
        }
        if depth >= 3 || helpers.len() >= 256 {
            continue;
        }
        for next in closing_instances(&p, trs, &mut fresh, deadline) {
            if queue.len() < 256 {
                queue.push_back((next, depth + 1));
            }
        }
        for (pos, _) in positions_with_subterms(&p.rhs) {
            for rule in &originals {
                if strategy_timed_out(deadline) {
                    return None;
                }
                if queue.len() >= 256 {
                    break;
                }
                if let Some(next) = narrow(&p, rule, &pos, &mut fresh) {
                    queue.push_back((next, depth + 1));
                }
            }
        }
    }
    // Each starting rule contains a marked step. Auxiliary rules never do.
    let defined: BTreeSet<_> = trs
        .rules()
        .iter()
        .filter_map(|r| match r.lhs() {
            Term::App { symbol, .. } => Some(symbol.clone()),
            _ => None,
        })
        .collect();
    // Propagate ground arguments already present in live calls into free
    // helper parameters. This is partial evaluation, not ground-term
    // enumeration: each instance is justified by native base instantiation.
    let mut specialized = Vec::new();
    let mut instance_keys = BTreeSet::new();
    for helper in &helpers {
        let Term::App { symbol, args } = &helper.lhs else {
            continue;
        };
        for rule in trs.rules() {
            for (_, call) in positions_with_subterms(rule.rhs()) {
                let Term::App {
                    symbol: callee,
                    args: actual,
                } = call
                else {
                    continue;
                };
                if callee != symbol || actual.len() != args.len() {
                    continue;
                }
                let mut sub = Subst::new();
                for (formal, actual) in args.iter().zip(actual) {
                    if let Term::Var(v) = formal {
                        if actual.variables().is_empty() {
                            sub.insert(v.clone(), actual.clone());
                        }
                    }
                }
                if sub.is_empty() {
                    continue;
                }
                let Some(mut q) = base(helper.clone(), &sub) else {
                    continue;
                };
                for _ in 0..4 {
                    let Some(next) = rewrites(&q, trs, deadline).into_iter().next() else {
                        break;
                    };
                    q = next;
                }
                if instance_keys.insert(key(&q)) {
                    specialized.push(q);
                }
                if strategy_timed_out(deadline) {
                    return None;
                }
            }
        }
    }
    specialized.extend(helpers);
    let helpers = specialized;
    if trace {
        eprintln!(
            "pattern-search helpers ready: elapsed={:?} helpers={}",
            started.elapsed(),
            helpers.len()
        );
    }
    let mut starts: Vec<_> = pairs.iter().collect();
    // Try recursive calls with unresolved auxiliary computation first. Pure
    // arithmetic helper pairs otherwise consume the shared search budget.
    starts.sort_by_key(|pair| {
        std::cmp::Reverse(
            positions_with_subterms(pair.rhs())
                .iter()
                .filter(|(_, t)| matches!(t, Term::App { symbol, .. } if defined.contains(symbol)))
                .count(),
        )
    });
    for pair in starts {
        if trace {
            eprintln!(
                "pattern-search starting pair: elapsed={:?} lhs={:?}",
                started.elapsed(),
                pair.lhs()
            );
        }
        // A marked root can change only through another marked step. Prune
        // paths that cannot return to this starting root, rather than spending
        // the bounded search on terminating auxiliary components.
        let head = |t: &Term| match t {
            Term::App { symbol, .. } => Some(symbol.clone()),
            _ => None,
        };
        let mut returning = BTreeSet::new();
        if let Some(symbol) = head(pair.lhs()) {
            returning.insert(symbol);
            loop {
                let old = returning.len();
                for edge in pairs {
                    if head(edge.rhs()).is_some_and(|s| returning.contains(&s)) {
                        if let Some(s) = head(edge.lhs()) {
                            returning.insert(s);
                        }
                    }
                }
                if returning.len() == old {
                    break;
                }
            }
        }
        let mut queue = PatternQueue::new(&defined);
        queue.push_back((original_pair_pattern_rule(pair), 0));
        let mut seen = BTreeSet::new();
        while let Some((p, depth)) = queue.pop() {
            if strategy_timed_out(deadline) {
                if trace {
                    eprintln!(
                        "pattern-search main timeout: elapsed={:?} seen={} queued={}",
                        started.elapsed(),
                        seen.len(),
                        queue.len()
                    );
                }
                return None;
            }
            if head(&p.rhs).is_some_and(|s| !returning.contains(&s)) {
                continue;
            }
            if !pairs
                .iter()
                .any(|pair| may_enable_marked(&p.rhs, pair.lhs(), &defined))
            {
                continue;
            }
            if !seen.insert(key(&p)) {
                continue;
            }
            if trace && seen.len() % 64 == 0 {
                eprintln!(
                    "pattern-search progress: elapsed={:?} seen={} queued={} depth={depth}",
                    started.elapsed(),
                    seen.len(),
                    queue.len()
                );
            }
            if let Some(proof) = closed(&p) {
                return Some(proof);
            }
            let simplified = simplify(p.clone());
            if key(&simplified) != key(&p) && queue.len() < 2048 {
                queue.push_front((simplified, depth));
            }
            if depth >= 10 || seen.len() >= 2048 {
                continue;
            }
            for next in closing_instances(&p, trs, &mut fresh, deadline) {
                if queue.len() < 2048 {
                    queue.push_back((next, depth + 1));
                }
            }
            if let Some(next) = rewrite_base_chain(&p, trs, deadline) {
                if queue.len() < 2048 {
                    queue.push_front((next, depth + 1));
                }
            }
            for next in rewrites(&p, trs, deadline) {
                if queue.len() < 2048 {
                    queue.push_back((next, depth + 1));
                }
            }
            for (pos, _) in positions_with_subterms(&p.rhs) {
                for rule in &helpers {
                    if strategy_timed_out(deadline) {
                        return None;
                    }
                    if queue.len() >= 2048 {
                        break;
                    }
                    if let Some(next) = narrow(&p, rule, &pos, &mut fresh) {
                        queue.push_back((next, depth + 1));
                    }
                }
            }
            // A second marked step is legal only at the root. Its proof
            // remains a native pattern narrowing step over the live P set.
            for rule in &marked {
                if strategy_timed_out(deadline) {
                    return None;
                }
                if queue.len() >= 2048 {
                    break;
                }
                if let Some(next) = narrow(&p, rule, &[], &mut fresh) {
                    queue.push_back((next, depth + 1));
                }
            }
        }
    }
    None
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn cached_pattern_queue_preserves_priority_and_front_back_ties() {
        let trs = crate::parsing::parse_ari_trs(
            None,
            "(format TRS) (fun f 1) (fun g 1) (fun s 1)
             (rule (f x) (g x)) (rule (g x) (s x))",
        )
        .unwrap();
        let defined = BTreeSet::from([Symbol::new("f"), Symbol::new("g")]);
        let mut queue = PatternQueue::new(&defined);
        let mut reference = VecDeque::new();
        for i in 0..24 {
            let p = original_rule_pattern_rule(&trs.rules()[i % 2]);
            let item = (p, i % 3);
            if i % 5 == 0 {
                queue.push_front(item.clone());
                reference.push_front(item);
            } else {
                queue.push_back(item.clone());
                reference.push_back(item);
            }
        }
        while !reference.is_empty() {
            let index = reference
                .iter()
                .enumerate()
                .min_by_key(|(_, (p, depth))| (pattern_cost(p, &defined), *depth))
                .unwrap()
                .0;
            let expected = reference.remove(index).unwrap();
            let actual = queue.pop().unwrap();
            assert_eq!((key(&actual.0), actual.1), (key(&expected.0), expected.1));
            assert_eq!(queue.len(), reference.len());
        }
        assert!(queue.pop().is_none());
    }

    #[test]
    fn pattern_context_pumping_rejects_marked_seeds() {
        let trs = crate::parsing::parse_ari_trs(
            None,
            "(format TRS) (fun f 1) (fun s 1) (rule (f (s x)) (s (f x)))",
        )
        .unwrap();
        let p = original_rule_pattern_rule(&trs.rules()[0]);
        assert!(!initial_context(&p, &mut Fresh::default()).is_empty());
        let mut invalid = p;
        if let PatternRuleProof::OriginalRule { is_pair, .. } = &mut invalid.proof {
            *is_pair = true;
        }
        assert!(initial_context(&invalid, &mut Fresh::default()).is_empty());
    }

    #[test]
    fn pattern_commuting_extension_checks_aliases_and_conflicts() {
        let x = Variable::new("x");
        let y = Variable::new("y");
        let close = Subst::from([(x.clone(), Term::Var(y.clone()))]);
        let extra = Subst::from([(y.clone(), Term::app("s", vec![Term::Var(y.clone())]))]);
        let extended = commuting_extension(extra, &[&close]).unwrap();
        assert!(commutes(&extended, &close));
        assert_eq!(
            image(&extended, &x),
            Term::app("s", vec![Term::Var(x.clone())])
        );
        let conflict = Subst::from([
            (x.clone(), Term::app("t", vec![Term::Var(x)])),
            (y.clone(), Term::app("s", vec![Term::Var(y)])),
        ]);
        assert!(commuting_extension(conflict, &[&close]).is_none());
    }

    #[test]
    fn pattern_signed_subtraction_guard_certifies() {
        let input = "(format TRS) (fun nz 1) (fun pos 1) (fun s 1) (fun yes 0)
          (fun neg 1) (fun zero 0) (fun no 0) (fun positive 1) (fun both 2)
          (fun diff 2) (fun add 2) (fun flip 1) (fun sub 2) (fun run 3)
          (rule (nz (pos (s x))) yes) (rule (nz (neg (s x))) yes)
          (rule (nz (neg zero)) no) (rule (nz (pos zero)) no)
          (rule (positive (pos (s x))) yes) (rule (positive (pos zero)) no)
          (rule (positive (neg x)) no)
          (rule (both no no) no) (rule (both no yes) no)
          (rule (both yes no) no) (rule (both yes yes) yes)
          (rule (diff zero y) (neg y)) (rule (diff x zero) (pos x))
          (rule (diff (s x) (s y)) (diff x y))
          (rule (add zero y) y) (rule (add (s x) y) (add x (s y)))
          (rule (flip (pos x)) (neg x)) (rule (flip (neg x)) (pos x))
          (rule (sub (pos x) (pos y)) (diff x y))
          (rule (sub (neg x) (neg y)) (flip (diff x y)))
          (rule (sub (pos x) (neg y)) (pos (add x y)))
          (rule (sub (neg x) (pos y)) (neg (add x y)))
          (rule (run yes i y) (run (both (nz y) (positive i)) (sub i y) y))";
        let trs = crate::parsing::parse_ari_trs(None, input).unwrap();
        let pairs = dependency_pairs(&trs);
        let proof =
            search(&trs, &pairs, None).expect("signed subtraction with guarded positive growth");
        let proof = crate::proving::Proof::nonterminating(NonterminationProof::DependencyPairs {
            pairs,
            proof: Box::new(proof),
        });
        certify(&trs, &proof, "signed-subtraction", true);
    }

    #[test]
    fn pattern_multiplication_guard_certifies() {
        let input = "(format TRS) (fun run 3) (fun yes 0) (fun no 0)
          (fun greater 2) (fun twice 1) (fun mul 2) (fun add 2) (fun succ 1) (fun zero 0)
          (rule (run yes x y) (run (greater x y) (twice x) (succ y)))
          (rule (greater (succ x) zero) yes) (rule (greater zero y) no)
          (rule (greater (succ x) (succ y)) (greater x y))
          (rule (twice x) (mul x (succ (succ zero))))
          (rule (mul zero y) zero) (rule (mul (succ x) y) (add y (mul x y)))
          (rule (add zero y) y) (rule (add (succ x) y) (add x (succ y)))";
        let trs = crate::parsing::parse_ari_trs(None, input).unwrap();
        let pairs = dependency_pairs(&trs);
        // This is a proof-construction/certification test, not a runtime
        // benchmark. Production retains its 60-second ceiling; allow this
        // larger fixture headroom on shared campaign machines.
        let proof = search_with_budget(&trs, &pairs, None, Duration::from_secs(180))
            .expect("multiplication helper composition");
        let proof = crate::proving::Proof::nonterminating(NonterminationProof::DependencyPairs {
            pairs,
            proof: Box::new(proof),
        });
        certify(&trs, &proof, "multiplication-guard", true);
    }

    #[test]
    fn pattern_shared_accumulator_doubling_certifies() {
        let input = "(format TRS) (fun run 2) (fun yes 0) (fun positive 1)
          (fun twice 1) (fun add 2) (fun succ 1) (fun zero 0)
          (rule (run yes x) (run (positive x) (twice x)))
          (rule (positive (succ x)) yes) (rule (twice x) (add x x))
          (rule (add zero y) y) (rule (add (succ x) y) (add x (succ y)))";
        let trs = crate::parsing::parse_ari_trs(None, input).unwrap();
        let pairs = dependency_pairs(&trs);
        let proof = search(&trs, &pairs, None).expect("doubling with a shared accumulator input");
        let proof = crate::proving::Proof::nonterminating(NonterminationProof::DependencyPairs {
            pairs,
            proof: Box::new(proof),
        });
        certify(&trs, &proof, "shared-doubling", true);
    }

    #[test]
    fn pattern_keys_ignore_renaming_but_preserve_contexts() {
        let trs = guarded("", true);
        let p = original_rule_pattern_rule(&trs.rules()[0]);
        let q = base(
            p.clone(),
            &Subst::from([(Variable::new("counter"), Term::var("fresh"))]),
        )
        .unwrap();
        assert_eq!(key(&p), key(&q));
        let q = instantiate_pattern_rule(
            q,
            Subst::from([(Variable::new("fresh"), Term::app("zero", vec![]))]),
            PatternInstantiationTarget::Closing,
        );
        assert_ne!(key(&p), key(&q));
    }

    #[test]
    fn pattern_substitution_factors_check_all_variables() {
        let x = Variable::new("x");
        let y = Variable::new("y");
        let a = Subst::from([(x.clone(), Term::app("f", vec![Term::Var(y.clone())]))]);
        let rho = Subst::from([(y.clone(), Term::app("g", vec![Term::Var(y.clone())]))]);
        let b = compose(&a, &rho);
        assert_eq!(right_factor(&a, &b), Some(rho));
        let mut invalid = b;
        invalid.remove(&y);
        assert!(right_factor(&a, &invalid).is_none());
    }

    #[test]
    fn pattern_context_double_half_chain_certifies() {
        let input = "(format TRS) (fun run 2) (fun yes 0) (fun same 2)
          (fun halve 1) (fun twice 1) (fun succ 1) (fun zero 0)
          (rule (run yes x) (run (same x (halve (twice x))) (succ x)))
          (rule (same (succ x) (succ y)) (same x y)) (rule (same zero zero) yes)
          (rule (twice (succ x)) (succ (succ (twice x)))) (rule (twice zero) zero)
          (rule (halve (succ (succ x))) (succ (halve x))) (rule (halve zero) zero)";
        let trs = crate::parsing::parse_ari_trs(None, input).unwrap();
        let pairs = dependency_pairs(&trs);
        let proof = search(&trs, &pairs, None).expect("composed context-pumping helpers");
        let proof = crate::proving::Proof::nonterminating(NonterminationProof::DependencyPairs {
            pairs,
            proof: Box::new(proof),
        });
        certify(&trs, &proof, "double-half", true);
    }

    #[test]
    fn pattern_nested_guard_accumulator_certifies() {
        let input = "(format TRS) (fun run 2) (fun yes 0) (fun guard 1)
          (fun acc 2) (fun succ 1) (fun zero 0)
          (rule (run yes x) (run (guard (acc x x)) (succ x)))
          (rule (guard (acc zero y)) yes)
          (rule (acc (succ x) y) (acc x (succ y)))";
        let trs = crate::parsing::parse_ari_trs(None, input).unwrap();
        let pairs = dependency_pairs(&trs);
        let proof =
            search(&trs, &pairs, None).expect("nested guard over an accelerated accumulator");
        let proof = crate::proving::Proof::nonterminating(NonterminationProof::DependencyPairs {
            pairs,
            proof: Box::new(proof),
        });
        certify(&trs, &proof, "nested-guard", true);
    }

    fn certify(trs: &Trs, proof: &crate::proving::Proof, label: &str, expected: bool) {
        let xml = crate::cert::write_cpf(trs, proof, crate::cert::CpfMode::Cpf30).unwrap();
        let path =
            std::env::temp_dir().join(format!("ferrum-pattern-{}-{label}.xml", std::process::id()));
        std::fs::write(&path, xml).unwrap();
        let checker = std::env::var("CETA_CSR_BIN").unwrap_or_else(|_| "../CeTA-CSR/ceta".into());
        let output = std::process::Command::new(checker)
            .arg(&path)
            .output()
            .unwrap();
        let accepted = output.status.success()
            && String::from_utf8_lossy(&output.stdout).trim() == "CERTIFIED";
        assert_eq!(
            accepted,
            expected,
            "{}: {} {}",
            path.display(),
            String::from_utf8_lossy(&output.stdout),
            String::from_utf8_lossy(&output.stderr)
        );
    }

    fn guarded(prefix: &str, exit: bool) -> Trs {
        let app = |name: &str, args| Term::app(format!("{prefix}{name}"), args);
        let x = Term::var("counter");
        let mut rules = vec![
            RewriteRule::new(
                app("run", vec![app("yes", vec![]), x.clone()]),
                app(
                    "run",
                    vec![app("test", vec![x.clone()]), app("cons", vec![x.clone()])],
                ),
            ),
            RewriteRule::new(
                app("test", vec![app("cons", vec![x.clone()])]),
                app("test", vec![x]),
            ),
        ];
        if exit {
            rules.push(RewriteRule::new(
                app("test", vec![app("zero", vec![])]),
                app("yes", vec![]),
            ));
        }
        Trs::new(None, BTreeSet::from([Variable::new("counter")]), rules)
    }

    #[test]
    fn pattern_substitution_rewriting_certifies_and_checks_live_rules() {
        let trs = crate::parsing::parse_ari_trs(
            None,
            "(format TRS)
            (fun loop 1) (fun erase 1)
            (rule (loop x) (loop x)) (rule (erase x) x)",
        )
        .unwrap();
        let pairs = dependency_pairs(&trs);
        for target in [
            PatternInstantiationTarget::Pumping,
            PatternInstantiationTarget::Closing,
        ] {
            let name = if target == PatternInstantiationTarget::Closing {
                "auxiliary"
            } else {
                "x"
            };
            let p = instantiate_pattern_rule(
                original_pair_pattern_rule(&pairs[0]),
                Subst::from([(
                    Variable::new(name),
                    Term::app("erase", vec![Term::var(name)]),
                )]),
                target.clone(),
            );
            let q = rewrites(&p, &trs, None)
                .into_iter()
                .find(
                    |q| matches!(&q.proof,PatternRuleProof::Rewriting {target:t,..} if *t==target),
                )
                .expect("rewrite substitution image");
            // The original DP is a self-loop, but the submitted derivation
            // must still validate every claimed auxiliary rewrite.
            let q = if target == PatternInstantiationTarget::Closing {
                // Simplifying both sides exposes the finite closing rewrite.
                simplify(q)
            } else {
                q
            };
            let proof = closed(&q).expect("self-loop after checked substitution rewrite");
            let proof =
                crate::proving::Proof::nonterminating(NonterminationProof::DependencyPairs {
                    pairs: pairs.clone(),
                    proof: Box::new(proof),
                });
            certify(&trs, &proof, &format!("substitution-{target:?}"), true);
            let mutated = Trs::new(None, trs.variables().clone(), vec![trs.rules()[0].clone()]);
            certify(
                &mutated,
                &proof,
                &format!("missing-rewrite-{target:?}"),
                false,
            );
        }
    }

    #[test]
    fn pattern_base_rewrite_chain_certifies_list_growth() {
        let input = "(format TRS)
            (fun run 2) (fun yes 0) (fun valid 1) (fun append 2)
            (fun cons 2) (fun item 0) (fun nil 0) (fun acc 2) (fun reverse 1)
            (rule (run yes xs) (run (valid xs) (append (cons item nil) xs)))
            (rule (valid nil) yes)
            (rule (valid (cons x xs)) (valid xs))
            (rule (append xs ys) (acc (reverse xs) ys))
            (rule (acc nil ys) ys)
            (rule (acc (cons x xs) ys) (acc xs (cons x ys)))
            (rule (reverse nil) nil)
            (rule (reverse (cons x xs)) (append (reverse xs) (cons x nil)))";
        let trs = crate::parsing::parse_ari_trs(None, input).unwrap();
        let pairs = dependency_pairs(&trs);
        let proof =
            search(&trs, &pairs, None).expect("ordinary rewrite chain followed by pumped guard");
        let proof = crate::proving::Proof::nonterminating(NonterminationProof::DependencyPairs {
            pairs,
            proof: Box::new(proof),
        });
        certify(&trs, &proof, "rewrite-list", true);
    }

    #[test]
    fn pattern_simplification_preserves_all_sampled_instances() {
        let trs = guarded("", true);
        let mut p = original_rule_pattern_rule(&trs.rules()[0]);
        let x = Variable::new("counter");
        let y = Variable::new("free");
        p.pumping_substitution =
            Subst::from([(x.clone(), Term::app("cons", vec![Term::Var(x.clone())]))]);
        p.closing_substitution = Subst::from([
            (x, Term::app("zero", vec![])),
            (y, Term::app("yes", vec![])),
        ]);
        let q = simplify(p.clone());
        for left in [true, false] {
            let instance = |r: &PatternRule, n| {
                let (t, s, m) = if left {
                    (&r.lhs, &r.pumping_substitution, &r.closing_substitution)
                } else {
                    let (s, m) = right(r);
                    (&r.rhs, s, m)
                };
                let mut t = t.clone();
                for _ in 0..n {
                    t = apply_substitution(&t, s);
                }
                apply_substitution(&t, m)
            };
            for n in 0..8 {
                assert_eq!(instance(&p, n), instance(&q, n));
            }
        }
        // The noncommuting zero substitution must not move into the base.
        assert_eq!(q.lhs, p.lhs);
        assert!(
            q.closing_substitution
                .contains_key(&Variable::new("counter"))
        );
    }

    #[test]
    fn pattern_simplification_factors_equal_iteration_domains() {
        let x = Variable::new("left");
        let y = Variable::new("right");
        let t = Term::app("pair", vec![Term::Var(x.clone()), Term::Var(y.clone())]);
        let mut p = original_rule_pattern_rule(&RewriteRule::new(t.clone(), t));
        p.pumping_substitution = [x.clone(), y.clone()]
            .into_iter()
            .map(|v| (v.clone(), Term::app("grow", vec![Term::Var(v)])))
            .collect();
        p.closing_substitution = [x, y].into_iter().map(|v| (v, Term::var("free"))).collect();
        let q = simplify(p.clone());
        assert_eq!(q.lhs.variables().len(), 1);
        assert_eq!(q.closing_substitution.len(), 1);
        for n in 0..8 {
            let instantiate = |p: &PatternRule| {
                let mut t = p.lhs.clone();
                for _ in 0..n {
                    t = apply_substitution(&t, &p.pumping_substitution);
                }
                apply_substitution(&t, &p.closing_substitution)
            };
            assert_eq!(instantiate(&p), instantiate(&q));
        }
    }

    #[test]
    fn pattern_rewriting_does_not_narrow_variable_redexes() {
        let trs = guarded("", true);
        let p = original_rule_pattern_rule(&RewriteRule::new(Term::var("x"), Term::var("x")));
        assert!(rewrites(&p, &trs, None).is_empty());
        assert!(
            rewrites(
                &original_rule_pattern_rule(&trs.rules()[0]),
                &trs,
                Some(Instant::now())
            )
            .is_empty()
        );
    }

    #[test]
    fn native_pattern_search_derives_and_certifies_guarded_growth() {
        for prefix in ["", "renamed_"] {
            let trs = guarded(prefix, true);
            let pairs = dependency_pairs(&trs);
            let proof =
                search(&trs, &pairs, None).expect("accelerated test plus exit closes growing run");
            let proof =
                crate::proving::Proof::nonterminating(NonterminationProof::DependencyPairs {
                    pairs,
                    proof: Box::new(proof),
                });
            let xml = crate::cert::write_cpf(&trs, &proof, crate::cert::CpfMode::Cpf30).unwrap();
            assert!(xml.contains("<initialPumping>"));
            let path = std::env::temp_dir().join(format!(
                "ferrum-native-pattern-{}-{prefix}.xml",
                std::process::id()
            ));
            std::fs::write(&path, xml).unwrap();
            let checker =
                std::env::var("CETA_CSR_BIN").unwrap_or_else(|_| "../CeTA-CSR/ceta".into());
            if std::path::Path::new(&checker).exists() {
                let out = std::process::Command::new(checker)
                    .arg(&path)
                    .output()
                    .unwrap();
                assert!(
                    out.status.success()
                        && String::from_utf8_lossy(&out.stdout).trim() == "CERTIFIED",
                    "{}\n{}\n{}",
                    path.display(),
                    String::from_utf8_lossy(&out.stdout),
                    String::from_utf8_lossy(&out.stderr)
                );
            }
        }
    }

    #[test]
    fn native_pattern_search_rejects_missing_exit_and_expired_deadline() {
        let trs = guarded("", false);
        assert!(search(&trs, &dependency_pairs(&trs), None).is_none());
        let trs = guarded("", true);
        assert!(search(&trs, &dependency_pairs(&trs), Some(Instant::now())).is_none());
    }

    #[test]
    fn native_pattern_independent_helper_instances_certify_and_missing_rule_rejects() {
        let mut trs = guarded("", true);
        let app = |s, args| Term::app(s, args);
        let x = Term::var("counter");
        let y = Term::var("other");
        let ready = app("yes", vec![]);
        let mut rules = trs.rules().to_vec();
        rules[0] = RewriteRule::new(
            app("run", vec![ready.clone(), x.clone(), y.clone()]),
            app(
                "run",
                vec![
                    app(
                        "both",
                        vec![app("test", vec![x.clone()]), app("test", vec![y.clone()])],
                    ),
                    app("cons", vec![x]),
                    app("cons", vec![y]),
                ],
            ),
        );
        rules.push(RewriteRule::new(
            app("both", vec![ready.clone(), ready.clone()]),
            ready,
        ));
        trs = Trs::new(
            None,
            BTreeSet::from([Variable::new("counter"), Variable::new("other")]),
            rules.clone(),
        );
        let pairs = dependency_pairs(&trs);
        let proof = search(&trs, &pairs, None).expect("two independent pumped guards");
        let proof = crate::proving::Proof::nonterminating(NonterminationProof::DependencyPairs {
            pairs,
            proof: Box::new(proof),
        });
        certify(&trs, &proof, "independent", true);
        rules.remove(2);
        let mutated = Trs::new(None, trs.variables().clone(), rules);
        certify(&mutated, &proof, "missing-exit", false);
    }

    #[test]
    fn native_pattern_initial_pumping_rejects_noncommuting_substitutions() {
        let rule = RewriteRule::new(
            Term::app("f", vec![Term::var("x"), Term::app("a", vec![])]),
            Term::app("f", vec![Term::app("b", vec![]), Term::var("x")]),
        );
        let mut fresh = Fresh::default();
        fresh.used.insert(Variable::new("x"));
        assert!(initial(original_rule_pattern_rule(&rule), &mut fresh).is_none());
    }

    #[test]
    fn native_pattern_base_cannot_instantiate_domain_variables() {
        let trs = guarded("", true);
        let mut fresh = Fresh::default();
        fresh.used.insert(Variable::new("counter"));
        let p = initial(original_rule_pattern_rule(&trs.rules()[1]), &mut fresh).unwrap();
        let v = domains(&p).into_iter().next().unwrap();
        assert!(base(p, &Subst::from([(v, Term::app("zero", vec![]))])).is_none());
    }

    #[test]
    fn native_pattern_accumulator_growth_uses_checked_pumping_power() {
        let input = "(format TRS)
            (fun run 2) (fun yes 0) (fun positive 1) (fun scale 1)
            (fun acc 2) (fun zero 0) (fun succ 1)
            (rule (run yes x) (run (positive x) (scale x)))
            (rule (positive (succ x)) yes)
            (rule (scale x) (acc x zero))
            (rule (acc zero y) y)
            (rule (acc (succ x) y) (acc x (succ (succ y))))";
        let trs = crate::parsing::parse_ari_trs(None, input).unwrap();
        let pairs = dependency_pairs(&trs);
        let proof = search(&trs, &pairs, None).expect("accelerated accumulator and positive guard");
        let DpNonterminationProof::NonLoop(ref pattern) = proof else {
            panic!("native pattern terminal")
        };
        assert_eq!(pattern.pumping_decomposition, 2);
        let proof = crate::proving::Proof::nonterminating(NonterminationProof::DependencyPairs {
            pairs,
            proof: Box::new(proof),
        });
        certify(&trs, &proof, "accumulator", true);
    }
}
