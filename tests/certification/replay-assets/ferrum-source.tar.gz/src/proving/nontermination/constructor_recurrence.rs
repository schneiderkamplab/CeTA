//! Synthesize a recurrent language f(C,...,C) from live constructor rules.
//! C contains all ground constructor terms. It is nonempty when a constructor
//! constant exists. Constructors have no rewrite rules. Every root rewrite
//! must preserve this language, and a complete shallow pattern partition must
//! cover it. Consequently no accepted term has a normal form. The emitted
//! regular-language certificate is independently checked by CeTA.
use std::collections::BTreeSet;

use crate::core::{RewriteStrategy, Term, Trs};
use crate::proving::{
    NonterminationProof, TreeAutomaton, TreeAutomatonTransition, TreeAutomatonTransitionLhs,
};

pub(super) fn search(trs: &Trs) -> Option<NonterminationProof> {
    if trs.strategy() != RewriteStrategy::Full
        || !trs.validate().is_empty()
        || trs.rules().iter().any(|r| r.lhs().root_symbol().is_none())
    {
        return None;
    }
    let defined: BTreeSet<_> = trs
        .rules()
        .iter()
        .filter_map(|r| r.lhs().root_symbol().cloned())
        .collect();
    let arities = trs.arities();
    let constructors: BTreeSet<_> = arities
        .keys()
        .filter(|s| !defined.contains(*s))
        .cloned()
        .collect();
    if !constructors.iter().any(|s| arities[s] == 0) {
        return None;
    }
    fn constructor_term(t: &Term, cs: &BTreeSet<crate::core::Symbol>) -> bool {
        match t {
            Term::Var(_) => true,
            Term::App { symbol, args } => {
                cs.contains(symbol) && args.iter().all(|a| constructor_term(a, cs))
            }
        }
    }
    for root in &defined {
        let rules: Vec<_> = trs
            .rules()
            .iter()
            .filter(|r| r.lhs().root_symbol() == Some(root))
            .collect();
        let arity = arities[root];
        // Check every possible root rule, not merely the covering subset.
        if !rules.iter().all(|r| match r.rhs() {
            Term::App { symbol, args } => {
                symbol == root
                    && args.iter().all(|a| constructor_term(a, &constructors))
                    && r.rhs().variables().is_subset(&r.lhs().variables())
            }
            _ => false,
        }) {
            continue;
        }
        let mut covered = false;
        for position in 0..arity {
            let mut cases = BTreeSet::new();
            for rule in &rules {
                let Term::App { args, .. } = rule.lhs() else {
                    continue;
                };
                let mut variables = BTreeSet::new();
                let mut branch = None;
                let shallow_linear = args.iter().enumerate().all(|(i, t)| match t {
                    Term::Var(v) => variables.insert(v.clone()),
                    Term::App { symbol, args }
                        if i == position && constructors.contains(symbol) =>
                    {
                        branch = Some(symbol.clone());
                        args.iter().all(|a| match a {
                            Term::Var(v) => variables.insert(v.clone()),
                            _ => false,
                        })
                    }
                    _ => false,
                });
                if shallow_linear {
                    if let Some(symbol) = branch {
                        cases.insert(symbol);
                    } else {
                        covered = true;
                    }
                }
            }
            covered |= cases == constructors;
        }
        // Nullary defined roots are covered by any ground rule for that root.
        covered |= arity == 0 && !rules.is_empty();
        if !covered {
            continue;
        }
        let mut transitions: Vec<_> = constructors
            .iter()
            .map(|symbol| TreeAutomatonTransition {
                lhs: TreeAutomatonTransitionLhs::Symbol {
                    symbol: symbol.to_string(),
                    height: None,
                    args: vec!["constructor".into(); arities[symbol]],
                },
                rhs: "constructor".into(),
            })
            .collect();
        transitions.push(TreeAutomatonTransition {
            lhs: TreeAutomatonTransitionLhs::Symbol {
                symbol: root.to_string(),
                height: None,
                args: vec!["constructor".into(); arity],
            },
            rhs: "recurrent".into(),
        });
        return Some(NonterminationProof::NotWnTreeAutomaton {
            automaton: TreeAutomaton {
                final_states: vec!["recurrent".into()],
                transitions,
            },
            state_compatibility: Vec::new(),
        });
    }
    None
}

#[cfg(test)]
mod tests {
    use super::*;

    fn recognizes(rules: &str) -> bool {
        let input = format!("(format TRS) (fun run 2) (fun nil 0) (fun fork 2) {rules}");
        search(&crate::parsing::parse_ari_trs(None, &input).unwrap()).is_some()
    }

    #[test]
    fn constructor_recurrence_covers_arbitrary_constructor_arities() {
        assert!(recognizes(
            "(rule (run nil y) (run (fork y y) y))
            (rule (run (fork x z) y) (run x (fork z y)))"
        ));
    }

    #[test]
    fn constructor_recurrence_rejects_missing_case_and_exits() {
        assert!(!recognizes("(rule (run (fork x z) y) (run x y))"));
        assert!(!recognizes(
            "(rule (run nil y) (run (fork y y) y))
            (rule (run (fork x z) y) y)"
        ));
    }

    #[test]
    fn constructor_recurrence_rejects_nonlinear_coverage() {
        assert!(!recognizes(
            "(rule (run nil y) (run (fork y y) y))
            (rule (run (fork x x) y) (run x y))"
        ));
    }

    #[test]
    fn constructor_recurrence_strategy_roundtrip() {
        let atom = "constructor-recurrence";
        let parsed = crate::proving::nontermination::NonterminationStrategy::parse(atom).unwrap();
        assert_eq!(parsed.to_strategy_atom(), atom);
    }
}
