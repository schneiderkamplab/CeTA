//! Bounded rewriting and relative mixed strict/weak loop search.

use super::*;

pub(crate) fn bounded_rewriting_loop(
    trs: &Trs,
    deadline: Option<Instant>,
) -> Option<NonterminationProof> {
    // A short loop is often hidden behind a backwards overlap: one rule is
    // first used below the root, and its result enables a second rule at the
    // root.  Starting only from rule left-hand sides misses exactly these
    // contextual loops (and leaves the much broader narrowing search to find
    // them).  Materialize the finite set of RHS/LHS overlaps first, then run
    // the ordinary independently checked rewrite search from each seed.
    for (start, position, rule) in backward_overlap_loop_seeds(trs, deadline) {
        if strategy_timed_out(deadline) {
            return None;
        }
        if trs.strategy() == RewriteStrategy::Innermost {
            let Some(redex) = subterm_at_position(&start, &position) else {
                continue;
            };
            if !proper_subterms_are_normal(redex, trs.rules()) {
                continue;
            }
        }
        let Some(redex) = subterm_at_position(&start, &position) else {
            continue;
        };
        let Some(matcher) = match_pattern(rule.lhs(), redex) else {
            continue;
        };
        let rhs = apply_substitution(rule.rhs(), &matcher);
        let Some(next) = replace_subterm_at_position(&start, &position, &rhs) else {
            continue;
        };
        let first = LoopRewriteStep {
            position,
            rule,
            result: next.clone(),
        };
        if let Some(proof) = search_loop_from(trs, start.clone(), next, vec![first], 1, deadline) {
            return Some(NonterminationProof::Loop(proof));
        }
    }
    for rule in trs.rules() {
        if strategy_timed_out(deadline) {
            return None;
        }
        let start = rule.lhs().clone();
        let first = LoopRewriteStep {
            position: Vec::new(),
            rule: rule.clone(),
            result: rule.rhs().clone(),
        };
        if let Some(proof) = search_loop_from(
            trs,
            start.clone(),
            rule.rhs().clone(),
            vec![first],
            1,
            deadline,
        ) {
            return Some(NonterminationProof::Loop(proof));
        }
    }
    None
}

/// Construct contextual predecessors of rule left-hand sides by unifying a
/// producer RHS with a non-variable subterm of a consumer LHS.  Every seed is
/// merely a search hint: the returned rewrite sequence is still replayed by
/// `check_loop_proof_for_trs`, including the active rewrite strategy.
pub(crate) fn backward_overlap_loop_seeds(
    trs: &Trs,
    deadline: Option<Instant>,
) -> Vec<(Term, Vec<usize>, RewriteRule)> {
    const MAX_SEEDS: usize = 512;

    let mut seeds = Vec::new();
    let mut seen = BTreeSet::new();
    for (producer_index, producer) in trs.rules().iter().enumerate() {
        let fresh_producer = freshen_rule(producer, producer_index, 0);
        for (consumer_index, consumer) in trs.rules().iter().enumerate() {
            if strategy_timed_out(deadline) || seeds.len() >= MAX_SEEDS {
                return seeds;
            }
            let fresh_consumer = freshen_rule(consumer, consumer_index, 1);
            for (position, subterm) in positions_with_subterms(fresh_consumer.lhs()) {
                if matches!(subterm, Term::Var(_)) {
                    continue;
                }
                let mut unifier = BTreeMap::new();
                if !unify_terms(fresh_producer.rhs(), subterm, &mut unifier) {
                    continue;
                }
                let consumer_lhs = apply_substitution(fresh_consumer.lhs(), &unifier);
                let predecessor = apply_substitution(fresh_producer.lhs(), &unifier);
                let Some(start) =
                    replace_subterm_at_position(&consumer_lhs, &position, &predecessor)
                else {
                    continue;
                };
                if seen.insert((start.clone(), position.clone(), producer_index)) {
                    seeds.push((start, position.clone(), producer.clone()));
                    if seeds.len() >= MAX_SEEDS {
                        return seeds;
                    }
                }
            }
        }
    }
    // One later rewrite may require a constructor case that is still a
    // variable in the binary overlap.  Add the bounded one-variable/nullary
    // refinements needed to expose such cases without launching general
    // narrowing or a Cartesian ground-instantiation search.
    let mut constants = Vec::new();
    for rule in trs.rules() {
        for side in [rule.lhs(), rule.rhs()] {
            for (_, subterm) in positions_with_subterms(side) {
                if matches!(subterm, Term::App { args, .. } if args.is_empty()) {
                    push_unique_term(&mut constants, subterm.clone());
                }
            }
        }
    }
    let base_seeds = seeds.clone();
    for (start, position, rule) in base_seeds {
        let variables = start.variables().into_iter().collect::<Vec<_>>();
        for variable in &variables {
            for constant in &constants {
                if seeds.len() >= MAX_SEEDS {
                    return seeds;
                }
                let refined = apply_substitution(
                    &start,
                    &BTreeMap::from([(variable.clone(), constant.clone())]),
                );
                if seen.insert((refined.clone(), position.clone(), usize::MAX)) {
                    seeds.push((refined, position.clone(), rule.clone()));
                }
            }
        }
        for left in 0..variables.len() {
            for right in left + 1..variables.len() {
                for left_constant in &constants {
                    for right_constant in &constants {
                        if seeds.len() >= MAX_SEEDS {
                            return seeds;
                        }
                        let refined = apply_substitution(
                            &start,
                            &BTreeMap::from([
                                (variables[left].clone(), left_constant.clone()),
                                (variables[right].clone(), right_constant.clone()),
                            ]),
                        );
                        if seen.insert((refined.clone(), position.clone(), usize::MAX)) {
                            seeds.push((refined, position.clone(), rule.clone()));
                        }
                    }
                }
            }
        }
    }
    seeds
}

pub(crate) fn bounded_relative_rewriting_loop(
    relative: &RelativeTrs,
    deadline: Option<Instant>,
) -> Option<NonterminationProof> {
    let union = relative.union();
    let overlap_starts = relative_srs_overlap_starts(relative);
    for start in overlap_starts {
        if strategy_timed_out(deadline) {
            return None;
        }
        let seed_deadline = deadline
            .map(|end| end.min(Instant::now() + Duration::from_millis(200)))
            .or_else(|| Some(Instant::now() + Duration::from_millis(200)));
        if let Some(proof) =
            search_shallow_relative_loop_from(relative, &union, start, 5, seed_deadline)
        {
            return Some(NonterminationProof::Loop(proof));
        }
    }
    let ground_terms = small_ground_terms(&union, deadline)?;
    let choices = &ground_terms[..ground_terms.len().min(16)];
    let mut starts = Vec::new();
    for rule in relative.strict().rules() {
        for side in [rule.lhs(), rule.rhs()] {
            for (_, subterm) in positions_with_subterms(side) {
                if matches!(subterm, Term::Var(_)) {
                    continue;
                }
                push_unique_term(&mut starts, subterm.clone());
                let variables = subterm.variables();
                for choice in choices {
                    let substitution = variables
                        .iter()
                        .cloned()
                        .map(|variable| (variable, choice.clone()))
                        .collect();
                    push_unique_term(&mut starts, apply_substitution(subterm, &substitution));
                }
            }
        }
    }
    for start in ground_rule_side_instances(&union, &ground_terms, deadline) {
        push_unique_term(&mut starts, start);
    }
    for rule in union.rules() {
        push_unique_term(&mut starts, rule.lhs().clone());
        push_unique_term(&mut starts, rule.rhs().clone());
    }

    let shallow_deadline = deadline
        .map(|end| end.min(Instant::now() + Duration::from_secs(20)))
        .or_else(|| Some(Instant::now() + Duration::from_secs(20)));
    for start in &starts {
        if strategy_timed_out(deadline) {
            return None;
        }
        if strategy_timed_out(shallow_deadline) {
            break;
        }
        if let Some(proof) =
            search_shallow_relative_loop_from(relative, &union, start.clone(), 5, shallow_deadline)
        {
            return Some(NonterminationProof::Loop(proof));
        }
    }

    if let Some(proof) = bounded_relative_narrowing_loop(relative, &union, deadline) {
        return Some(NonterminationProof::Loop(proof));
    }

    for start in starts {
        if strategy_timed_out(deadline) {
            return None;
        }
        for (position, subterm) in positions_with_subterms(&start) {
            for rule in union.rules() {
                let Some(substitution) = match_pattern(rule.lhs(), subterm) else {
                    continue;
                };
                let rhs = apply_substitution(rule.rhs(), &substitution);
                let Some(next) = replace_subterm_at_position(&start, &position, &rhs) else {
                    continue;
                };
                let first = LoopRewriteStep {
                    position: position.clone(),
                    rule: rule.clone(),
                    result: next.clone(),
                };
                let Some(proof) =
                    search_loop_from(&union, start.clone(), next, vec![first], 1, deadline)
                else {
                    continue;
                };
                if proof
                    .steps
                    .iter()
                    .any(|step| relative.strict().rules().contains(&step.rule))
                {
                    return Some(NonterminationProof::Loop(proof));
                }
            }
        }
    }
    None
}

pub(crate) fn relative_srs_overlap_starts(relative: &RelativeTrs) -> Vec<Term> {
    let Some(strict_rules) = relative.strict().srs_rules() else {
        return Vec::new();
    };
    let weak = Trs::new_with_strategy(
        relative.strict().name().map(str::to_string),
        relative.strict().variables().clone(),
        relative.weak_rules().to_vec(),
        relative.strict().strategy(),
    );
    let Some(weak_rules) = weak.srs_rules() else {
        return Vec::new();
    };
    let tail = relative
        .strict()
        .variables()
        .iter()
        .next()
        .cloned()
        .unwrap_or_else(|| Variable::new("x"));
    let mut starts = Vec::new();

    for strict in &strict_rules {
        let strict_lhs = strict.lhs();
        for weak in &weak_rules {
            let weak_rhs = weak.rhs();
            if strict_lhs.is_empty() || weak_rhs.is_empty() {
                continue;
            }
            let first_offset = 1 - weak_rhs.len() as isize;
            let last_offset = strict_lhs.len() as isize - 1;
            for offset in first_offset..=last_offset {
                let left = 0.min(offset);
                let right = (strict_lhs.len() as isize).max(offset + weak_rhs.len() as isize);
                let mut merged = vec![None; (right - left) as usize];
                let strict_start = (-left) as usize;
                for (index, symbol) in strict_lhs.iter().enumerate() {
                    merged[strict_start + index] = Some(symbol.clone());
                }
                let weak_start = (offset - left) as usize;
                let mut compatible = true;
                for (index, symbol) in weak_rhs.iter().enumerate() {
                    let slot = &mut merged[weak_start + index];
                    if slot.as_ref().is_some_and(|existing| existing != symbol) {
                        compatible = false;
                        break;
                    }
                    *slot = Some(symbol.clone());
                }
                if !compatible {
                    continue;
                }
                let Some(merged) = merged.into_iter().collect::<Option<Vec<_>>>() else {
                    continue;
                };
                let mut predecessor = merged[..weak_start].to_vec();
                predecessor.extend_from_slice(weak.lhs());
                predecessor.extend_from_slice(&merged[weak_start + weak_rhs.len()..]);
                let term = predecessor
                    .iter()
                    .rev()
                    .fold(Term::Var(tail.clone()), |term, symbol| {
                        Term::app(symbol.as_str(), vec![term])
                    });
                push_unique_term(&mut starts, term);
            }
        }
    }
    starts
}

pub(crate) fn bounded_relative_narrowing_loop(
    relative: &RelativeTrs,
    union: &Trs,
    deadline: Option<Instant>,
) -> Option<LoopProof> {
    for strict_rule in relative.strict().rules() {
        for seed in [strict_rule.lhs(), strict_rule.rhs()] {
            for (position, subterm) in positions_with_subterms(seed) {
                if !matches!(subterm, Term::Var(_)) {
                    continue;
                }
                for (weak_index, weak_rule) in relative.weak_rules().iter().enumerate() {
                    if strategy_timed_out(deadline) {
                        return None;
                    }
                    let fresh_rule = freshen_rule(weak_rule, weak_index, 0);
                    let mut unifier = BTreeMap::new();
                    if !unify_terms(subterm, fresh_rule.lhs(), &mut unifier) {
                        continue;
                    }
                    let narrowed_start = apply_substitution(seed, &unifier);
                    let narrowed_current = narrowed_start.clone();
                    let rhs = apply_substitution(fresh_rule.rhs(), &unifier);
                    let Some(next) =
                        replace_subterm_at_position(&narrowed_current, &position, &rhs)
                    else {
                        continue;
                    };
                    let first = LoopRewriteStep {
                        position: position.clone(),
                        rule: weak_rule.clone(),
                        result: next.clone(),
                    };
                    let branch_deadline = deadline
                        .map(|end| end.min(Instant::now() + Duration::from_secs(2)))
                        .or_else(|| Some(Instant::now() + Duration::from_secs(2)));
                    let mut explored = 0usize;
                    let Some(proof) = search_contextual_relative_loop_path(
                        relative,
                        union,
                        &narrowed_start,
                        next,
                        vec![first],
                        false,
                        5,
                        &mut explored,
                        branch_deadline,
                    ) else {
                        continue;
                    };
                    if proof
                        .steps
                        .iter()
                        .any(|step| relative.strict().rules().contains(&step.rule))
                    {
                        return Some(proof);
                    }
                }
            }
        }
    }

    let mut narrowing_rules = relative.weak_rules().to_vec();
    narrowing_rules.extend(relative.strict().rules().iter().cloned());
    let narrowing_trs = Trs::new_with_strategy(
        union.name().map(str::to_string),
        union.variables().clone(),
        narrowing_rules,
        union.strategy(),
    );
    for rule in relative.strict().rules() {
        for seed in [rule.lhs(), rule.rhs()] {
            if strategy_timed_out(deadline) {
                return None;
            }
            let branch_deadline = deadline
                .map(|end| end.min(Instant::now() + Duration::from_secs(2)))
                .or_else(|| Some(Instant::now() + Duration::from_secs(2)));
            let Some(proof) = search_narrowing_loop_from(
                &narrowing_trs,
                seed.clone(),
                seed.clone(),
                Vec::new(),
                0,
                branch_deadline,
            ) else {
                continue;
            };
            if proof
                .steps
                .iter()
                .any(|step| relative.strict().rules().contains(&step.rule))
            {
                return Some(proof);
            }
        }
    }
    let rules = relative
        .weak_rules()
        .iter()
        .chain(relative.strict().rules())
        .collect::<Vec<_>>();
    for rule in rules {
        if strategy_timed_out(deadline) {
            return None;
        }
        let branch_deadline = deadline
            .map(|end| end.min(Instant::now() + Duration::from_secs(2)))
            .or_else(|| Some(Instant::now() + Duration::from_secs(2)));
        let first = LoopRewriteStep {
            position: Vec::new(),
            rule: rule.clone(),
            result: rule.rhs().clone(),
        };
        let Some(proof) = search_narrowing_loop_from(
            &narrowing_trs,
            rule.lhs().clone(),
            rule.rhs().clone(),
            vec![first],
            1,
            branch_deadline,
        ) else {
            continue;
        };
        if proof
            .steps
            .iter()
            .any(|step| relative.strict().rules().contains(&step.rule))
        {
            return Some(proof);
        }
    }
    None
}

#[allow(clippy::too_many_arguments)]
pub(crate) fn search_contextual_relative_loop_path(
    relative: &RelativeTrs,
    union: &Trs,
    start: &Term,
    current: Term,
    steps: Vec<LoopRewriteStep>,
    used_strict: bool,
    max_depth: usize,
    explored: &mut usize,
    deadline: Option<Instant>,
) -> Option<LoopProof> {
    if strategy_timed_out(deadline) || *explored >= MAX_LOOP_FRONTIER {
        return None;
    }
    if used_strict
        && let Some((context_position, substitution, instantiation)) =
            closes_loop_with_subject_refinement(start, &current)
    {
        let proof = LoopProof {
            start: apply_substitution(start, &instantiation),
            steps: steps
                .iter()
                .map(|step| LoopRewriteStep {
                    position: step.position.clone(),
                    rule: step.rule.clone(),
                    result: apply_substitution(&step.result, &instantiation),
                })
                .collect(),
            substitution,
            context_position,
        };
        if check_loop_proof_for_trs(union, &proof) {
            return Some(proof);
        }
    }
    if steps.len() >= max_depth {
        return None;
    }
    for (position, subterm) in positions_with_subterms(&current) {
        for rule in union.rules() {
            let Some(substitution) = match_pattern(rule.lhs(), subterm) else {
                continue;
            };
            let rhs = apply_substitution(rule.rhs(), &substitution);
            let Some(next) = replace_subterm_at_position(&current, &position, &rhs) else {
                continue;
            };
            *explored += 1;
            let mut next_steps = steps.clone();
            next_steps.push(LoopRewriteStep {
                position: position.clone(),
                rule: rule.clone(),
                result: next.clone(),
            });
            if let Some(proof) = search_contextual_relative_loop_path(
                relative,
                union,
                start,
                next,
                next_steps,
                used_strict || relative.strict().rules().contains(rule),
                max_depth,
                explored,
                deadline,
            ) {
                return Some(proof);
            }
        }
    }
    None
}

pub(crate) fn search_shallow_relative_loop_from(
    relative: &RelativeTrs,
    union: &Trs,
    start: Term,
    max_depth: usize,
    deadline: Option<Instant>,
) -> Option<LoopProof> {
    search_shallow_relative_loop_state(
        relative,
        union,
        start.clone(),
        start,
        Vec::new(),
        false,
        max_depth,
        deadline,
    )
}

pub(crate) fn search_shallow_relative_loop_state(
    relative: &RelativeTrs,
    union: &Trs,
    start: Term,
    current: Term,
    steps: Vec<LoopRewriteStep>,
    used_strict: bool,
    max_depth: usize,
    deadline: Option<Instant>,
) -> Option<LoopProof> {
    let mut queue = VecDeque::from([(current.clone(), steps, used_strict)]);
    let mut seen = BTreeSet::from([(current, used_strict)]);
    let mut explored = 0usize;
    while let Some((current, steps, used_strict)) = queue.pop_front() {
        if strategy_timed_out(deadline) {
            return None;
        }
        if used_strict
            && !steps.is_empty()
            && let Some((context_position, substitution)) = closes_loop(&start, &current)
        {
            let proof = LoopProof {
                start: start.clone(),
                steps: steps.clone(),
                substitution,
                context_position,
            };
            if check_loop_proof_for_trs(union, &proof) {
                return Some(proof);
            }
        }
        if steps.len() >= max_depth {
            continue;
        }
        for (position, subterm) in positions_with_subterms(&current) {
            for (rule_index, rule) in union.rules().iter().enumerate() {
                let fresh_rule = freshen_rule(rule, rule_index, steps.len() + explored);
                let Some(substitution) = match_pattern(fresh_rule.lhs(), subterm) else {
                    continue;
                };
                let rhs = apply_substitution(fresh_rule.rhs(), &substitution);
                let Some(next) = replace_subterm_at_position(&current, &position, &rhs) else {
                    continue;
                };
                let next_used_strict = used_strict || relative.strict().rules().contains(rule);
                if !seen.insert((next.clone(), next_used_strict)) {
                    continue;
                }
                explored += 1;
                if explored > MAX_LOOP_FRONTIER {
                    break;
                }
                let mut next_steps = steps.clone();
                next_steps.push(LoopRewriteStep {
                    position: position.clone(),
                    rule: rule.clone(),
                    result: next.clone(),
                });
                queue.push_back((next, next_steps, next_used_strict));
            }
        }
    }
    None
}
