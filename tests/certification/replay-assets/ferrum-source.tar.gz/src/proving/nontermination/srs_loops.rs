//! String-rewriting loop and derivation-pattern searches.

use super::*;

// Prefer long derivations with small source contexts. Breadth-first traversal
// exhausts the bounded frontier on shallow, widening closures. Integer log
// scores depend only on sizes, never on the spelling of the alphabet.
fn closure_priority(lhs: usize, rhs: usize, steps: usize) -> i64 {
    1024 * (steps + 1).ilog2() as i64
        - 4096 * (lhs + 1).ilog2() as i64
        - 512 * (rhs + 1).ilog2() as i64
}

/// A separate bounded-width portfolio, leaving recorded legacy searches
/// unchanged. Both directions receive time even when the first frontier grows
/// indefinitely. Every closure still denotes original forward rewrite steps.
pub(crate) fn srs_context_extension_loop_narrow(
    trs: &Trs,
    deadline: Option<Instant>,
) -> Option<NonterminationProof> {
    let now = Instant::now();
    let first_deadline = deadline.map(|end| now + end.saturating_duration_since(now) / 2);
    srs_context_extension_loop_ordered(trs, first_deadline, 3)
        .or_else(|| srs_context_extension_loop_ordered(trs, deadline, 4))
}

pub(crate) fn srs_context_extension_loop_wide(
    trs: &Trs,
    deadline: Option<Instant>,
) -> Option<NonterminationProof> {
    let now = Instant::now();
    let first_deadline = deadline.map(|end| now + end.saturating_duration_since(now) / 2);
    srs_context_extension_loop_ordered(trs, first_deadline, 5)
        .or_else(|| srs_context_extension_loop_ordered(trs, deadline, 6))
}

/// Grow a concrete derivation's context only when it enables a new boundary
/// redex. Unlike a fixed seed list, this can discover arbitrarily shaped
/// starting words within the explicit word, depth, and frontier bounds.
/// Every accepted candidate is reconstructed and independently rule-checked.
pub(crate) fn srs_context_extension_loop(
    trs: &Trs,
    deadline: Option<Instant>,
) -> Option<NonterminationProof> {
    // Preserve the inexpensive breadth-first lane: a depth-biased search can
    // spend its whole bounded frontier on an unhelpful infinite branch.
    srs_context_extension_loop_ordered(trs, deadline, 0)
        .or_else(|| srs_context_extension_loop_ordered(trs, deadline, 1))
        .or_else(|| srs_context_extension_loop_ordered(trs, deadline, 2))
}

fn srs_context_extension_loop_ordered(
    trs: &Trs,
    deadline: Option<Instant>,
    lane: u8,
) -> Option<NonterminationProof> {
    srs_context_extension_loop_with_width(trs, deadline, lane, if lane >= 5 { 25 } else { 15 }, None)
}

pub(crate) fn srs_context_extension_loop_bounded(
    trs: &Trs, deadline: Option<Instant>, max_width: usize,
) -> Option<NonterminationProof> {
    if !(1..=128).contains(&max_width) { return None; }
    let now = Instant::now();
    let first_deadline = deadline.map(|end| now + end.saturating_duration_since(now) / 2);
    srs_context_extension_loop_with_width(trs, first_deadline, 3, max_width, None)
        .or_else(|| srs_context_extension_loop_with_width(trs, deadline, 4, max_width, None))
}

/// Prefer closures near a requested source width rather than indefinitely
/// exploring shorter contexts. This changes only search order; reconstructed
/// forward traces still pass the same independent checker.
pub(crate) fn srs_context_extension_loop_target(
    trs: &Trs, deadline: Option<Instant>, width: usize, max_width: Option<usize>, beam: bool,
) -> Option<NonterminationProof> {
    if !(1..=64).contains(&width) { return None; }
    let now = Instant::now();
    let first = deadline.map(|end| now + end.saturating_duration_since(now) / 2);
    let max_width = max_width.unwrap_or(width * 2);
    if !(width..=128).contains(&max_width) { return None; }
    srs_context_extension_loop_with_width(trs, first, if beam {9} else {7}, max_width, Some(width))
        .or_else(|| srs_context_extension_loop_with_width(trs, deadline, if beam {10} else {8}, max_width, Some(width)))
}

/// Prioritize finite non-growing reductions between overlap extensions. This
/// is only a search heuristic: all shortcut steps are retained and expanded
/// into the ordinary independently checked loop certificate.
pub(crate) fn srs_normalized_loop(trs: &Trs, deadline: Option<Instant>, width: usize, max_width: usize) -> Option<NonterminationProof> {
    if !(1..=64).contains(&width) || !(width..=128).contains(&max_width) { return None; }
    let now=Instant::now();
    let half=deadline.map(|end|now+end.saturating_duration_since(now)/2);
    srs_context_extension_loop_with_width(trs,half,11,max_width,Some(width))
        .or_else(||srs_context_extension_loop_with_width(trs,deadline,12,max_width,Some(width)))
}

/// A bounded alternative to normalization: also follow growing reductions.
/// Every shortcut is expanded into genuine rule steps and independently
/// checked; growth and trace bounds affect search completeness only.
pub(crate) fn srs_eager_loop(trs: &Trs, deadline: Option<Instant>, width: usize, max_width: usize) -> Option<NonterminationProof> {
    if !(1..=64).contains(&width) || !(width..=128).contains(&max_width) { return None; }
    let now=Instant::now();
    let half=deadline.map(|end|now+end.saturating_duration_since(now)/2);
    srs_context_extension_loop_with_width(trs,half,13,max_width,Some(width))
        .or_else(||srs_context_extension_loop_with_width(trs,deadline,14,max_width,Some(width)))
}

fn reduce_loop_endpoint(rules: &[crate::core::SrsRule], lhs: &[Symbol], rhs: &mut Vec<Symbol>, trace: &mut Vec<(usize,usize)>, rightmost: bool, growth_bound: Option<usize>, deadline: Option<Instant>) {
    let mut seen=BTreeSet::new();
    for _ in 0..256 {
        if trace.len()>=1024 || strategy_timed_out(deadline) || contains_word(rhs,lhs) || !seen.insert(rhs.clone()) { break; }
        let positions:Box<dyn Iterator<Item=usize>>=if rightmost {Box::new((0..=rhs.len()).rev())} else {Box::new(0..=rhs.len())};
        let next=positions.flat_map(|p|rules.iter().enumerate().map(move |(i,r)|(p,i,r)))
            .find(|(p,_,r)|!r.lhs().is_empty() && r.lhs()!=r.rhs() && rhs[*p..].starts_with(r.lhs())
                && (r.rhs().len()<=r.lhs().len() || growth_bound.is_some_and(|bound|
                    rhs.len()-r.lhs().len()+r.rhs().len()<=bound)));
        let Some((p,i,r))=next else {break};
        *rhs=replace_word_at(rhs,p,r.lhs().len(),r.rhs());
        trace.push((i,p));
    }
}

fn srs_context_extension_loop_with_width(
    trs: &Trs, deadline: Option<Instant>, lane: u8, max_width: usize, target_width: Option<usize>,
) -> Option<NonterminationProof> {
    if trs.strategy() != RewriteStrategy::Full {
        return None;
    }
    let prioritized = lane != 0;
    let backward = lane == 2 || lane == 4 || lane == 6 || lane == 8 || lane == 10;
    let beam = lane >= 9;
    let narrow = lane >= 3;
    let frontier_limit = if narrow {
        1_000_000
    } else if prioritized {
        131072
    } else {
        16384
    };
    let depth_limit = if prioritized { 1024 } else { 64 };
    let priority = |lhs: usize, rhs: usize, steps: usize| {
        if lane >= 11 {
            7 * (steps + 1).ilog2() as i64
                - 7 * lhs.abs_diff(target_width.unwrap_or(max_width / 2)) as i64
                - rhs as i64
        } else if beam {
            7 * (steps + 1).ilog2() as i64 - 7 * lhs as i64 - rhs as i64
        } else if lane >= 7 {
            7 * (steps + 1).ilog2() as i64 - 7 * lhs.abs_diff(target_width.unwrap_or(max_width / 2)) as i64 - rhs as i64
        } else if narrow {
            7 * (steps + 1).ilog2() as i64 - 7 * lhs as i64 - rhs as i64
        } else if prioritized {
            closure_priority(lhs, rhs, steps)
        } else {
            0
        }
    };
    let rules = trs.srs_rules()?;
    let mut queue = std::collections::BinaryHeap::new();
    let mut serial = 0usize;
    let mut seen = BTreeSet::new();
    for (i, rule) in rules.iter().enumerate() {
        let lhs = rule.lhs().to_vec();
        let rhs = rule.rhs().to_vec();
        if seen.insert((lhs.clone(), rhs.clone())) {
            queue.push((
                priority(lhs.len(), rhs.len(), 1),
                std::cmp::Reverse(serial),
                lhs,
                rhs,
                vec![(i, 0usize)],
            ));
            serial += 1;
        }
    }
    while let Some((_, _, lhs, rhs, trace)) = queue.pop() {
        if strategy_timed_out(deadline) {
            return None;
        }
        let start = word_to_term_with_tail(&lhs, Term::var("_srs_context_tail"));
        if let Some((context_position, substitution)) = closes_srs_loop(&lhs, &rhs, &start) {
            let mut term = start.clone();
            let mut steps = Vec::new();
            let mut valid = true;
            for &(index, offset) in &trace {
                let rule = &trs.rules()[index];
                let position = vec![1; offset];
                let next = subterm_at_position(&term, &position)
                    .and_then(|redex| match_pattern(rule.lhs(), redex))
                    .and_then(|subst| {
                        replace_subterm_at_position(
                            &term,
                            &position,
                            &apply_substitution(rule.rhs(), &subst),
                        )
                    });
                let Some(result) = next else {
                    valid = false;
                    break;
                };
                steps.push(LoopRewriteStep {
                    position,
                    rule: rule.clone(),
                    result: result.clone(),
                });
                term = result;
            }
            let proof = LoopProof {
                start,
                steps,
                substitution,
                context_position,
            };
            if valid && check_loop_proof_for_trs(trs, &proof) {
                return Some(NonterminationProof::Loop(proof));
            }
        }
        if trace.len() >= depth_limit || seen.len() >= frontier_limit {
            continue;
        }
        let mut children = Vec::new();
        for (index, rule) in rules.iter().enumerate() {
            // Backward closures prepend a genuine forward step; they are not
            // loops of the inverse system. The final proof is always checked
            // against the original rules in their original direction.
            let (pattern, replacement, endpoint) = if backward {
                (rule.rhs(), rule.lhs(), &lhs)
            } else {
                (rule.lhs(), rule.rhs(), &rhs)
            };
            if pattern.is_empty() {
                continue;
            }
            // Include internal rewrites and both nonempty boundary overlaps.
            for offset in -(pattern.len() as isize - 1)..endpoint.len() as isize {
                if strategy_timed_out(deadline) {
                    return None;
                }
                let left = offset.max(0) as usize;
                let right = (offset + pattern.len() as isize).min(endpoint.len() as isize) as usize;
                if left >= right
                    || endpoint[left..right]
                        != pattern
                            [(left as isize - offset) as usize..(right as isize - offset) as usize]
                {
                    continue;
                }
                let prefix_len = (-offset).max(0) as usize;
                let prefix = &pattern[..prefix_len];
                let suffix_start =
                    (endpoint.len() as isize - offset).min(pattern.len() as isize) as usize;
                let suffix = &pattern[suffix_start..];
                let extended_lhs = [prefix, lhs.as_slice(), suffix].concat();
                let extended_rhs = [prefix, rhs.as_slice(), suffix].concat();
                let position = (offset + prefix_len as isize) as usize;
                let (new_lhs, mut new_rhs) = if backward {
                    (
                        replace_word_at(&extended_lhs, position, pattern.len(), replacement),
                        extended_rhs,
                    )
                } else {
                    (
                        extended_lhs,
                        replace_word_at(&extended_rhs, position, pattern.len(), replacement),
                    )
                };
                let mut next_trace = trace
                    .iter()
                    .map(|&(i, p)| (i, p + prefix_len))
                    .collect::<Vec<_>>();
                if backward {
                    next_trace.insert(0, (index, position));
                } else {
                    next_trace.push((index, position));
                }
                if lane>=11 {
                    reduce_loop_endpoint(&rules,&new_lhs,&mut new_rhs,&mut next_trace,lane%2==0,
                        (lane>=13).then_some(max_width),deadline);
                }
                let word_limit = if narrow { max_width } else { MAX_SRS_LOOP_WORD_LEN };
                if new_lhs.len() > word_limit || new_rhs.len() > word_limit
                    || (beam && new_lhs.len() > target_width.unwrap_or(word_limit)) {
                    continue;
                }
                if if beam { seen.contains(&(new_lhs.clone(), new_rhs.clone())) } else { !seen.insert((new_lhs.clone(), new_rhs.clone())) } {
                    continue;
                }
                let child = (
                    priority(new_lhs.len(), new_rhs.len(), next_trace.len()),
                    std::cmp::Reverse(serial),
                    new_lhs,
                    new_rhs,
                    next_trace,
                );
                if beam {
                    children.push((prefix_len != 0 || !suffix.is_empty(), child));
                } else {
                    queue.push(child);
                }
                serial += 1;
                if seen.len() >= frontier_limit {
                    break;
                }
            }
            if seen.len() >= frontier_limit {
                break;
            }
        }
        // Keep independent budgets for internal and boundary extensions.
        // This bounds redundant local branching without supplying any rule
        // choices. Rejected search branches never justify a positive result.
        if beam {
            children.sort_by(|a, b| b.1.cmp(&a.1));
            let mut counts = [0usize; 2];
            for (outer, child) in children {
                let class = usize::from(outer);
                let limit = if lane >= 11 { if outer {32} else {64} }
                    else if outer {2} else {8};
                if counts[class] >= limit { continue; }
                if seen.len() >= frontier_limit { break; }
                if seen.insert((child.2.clone(), child.3.clone())) {
                    counts[class] += 1;
                    queue.push(child);
                }
            }
        }
    }
    None
}

#[cfg(test)]
mod priority_tests {
    use super::*;

    #[test]
    fn eager_overlap_search_retains_growing_steps_and_respects_bounds() {
        for (a,b,c,d) in [("a","b","c","d"),("start","expand","tail","return")] {
            let input=format!("(format TRS) (fun {a} 1) (fun {b} 1) (fun {c} 1) (fun {d} 1) (rule ({a} x) ({b} ({c} x))) (rule ({b} ({c} x)) ({d} x)) (rule ({d} x) ({a} x))");
            let trs=crate::parsing::parse_ari_trs(None,&input).unwrap();
            let Some(NonterminationProof::Loop(proof))=srs_eager_loop(&trs,Some(Instant::now()+Duration::from_secs(5)),1,8) else {panic!("eager loop")};
            assert!(check_loop_proof_for_trs(&trs,&proof));
            assert!(proof.steps.len()>=3);
            assert!(srs_eager_loop(&trs,Some(Instant::now()),1,8).is_none());
            assert!(srs_eager_loop(&trs,None,0,8).is_none());
        }
        let terminating=crate::parsing::parse_ari_trs(None,"(format TRS) (fun a 1) (fun b 1) (rule (a (a x)) (b x))").unwrap();
        assert!(srs_eager_loop(&terminating,Some(Instant::now()+Duration::from_secs(1)),2,8).is_none());
        let atom="srs-eager-loop(width=7,max-width=64)";
        let NonterminationStrategy::Processor(processor)=NonterminationStrategy::parse(atom).unwrap() else {panic!("processor")};
        assert_eq!(processor.to_strategy_atom(),atom);
        assert!(NonterminationStrategy::parse("srs-eager-loop(width=7,max-width=6)").is_err());
    }

    #[test]
    fn normalized_overlap_loops_preserve_steps_and_renaming() {
        for (a,b,c,d) in [("a","b","c","d"),("split","left","right","join")] {
            let input=format!("(format TRS) (fun {a} 1) (fun {b} 1) (fun {c} 1) (fun {d} 1) (rule ({a} x) ({b} ({c} x))) (rule ({b} ({c} x)) ({d} x)) (rule ({d} x) ({a} x))");
            let trs=crate::parsing::parse_ari_trs(None,&input).unwrap();
            let Some(NonterminationProof::Loop(p))=srs_normalized_loop(&trs,Some(Instant::now()+Duration::from_secs(5)),1,8) else {panic!("normalized loop")};
            assert!(check_loop_proof_for_trs(&trs,&p));
            assert!(p.steps.len()>=3);
            assert!(srs_normalized_loop(&trs,Some(Instant::now()),1,8).is_none());
        }
        let trs=crate::parsing::parse_ari_trs(None,"(format TRS) (fun a 1) (fun b 1) (rule (a (a x)) (b x))").unwrap();
        assert!(srs_normalized_loop(&trs,Some(Instant::now()+Duration::from_secs(1)),2,8).is_none());
        let atom="srs-normalized-loop(width=6,max-width=48)";
        let NonterminationStrategy::Processor(p)=NonterminationStrategy::parse(atom).unwrap() else {panic!("processor")};
        assert_eq!(p.to_strategy_atom(),atom);
        assert!(NonterminationStrategy::parse("srs-normalized-loop(width=0,max-width=48)").is_err());
    }

    #[test]
    fn backward_closure_reconstructs_original_rule_direction() {
        for (a, b, c) in [("a", "b", "c"), ("erase", "move", "grow")] {
            let input = format!(
                "(format TRS) (fun {a} 1) (fun {b} 1) (fun {c} 1)
                (rule ({a} x) x) (rule ({a} x) ({b} x))
                (rule ({b} ({b} ({c} x))) ({a} ({c} ({c} ({c} ({a} ({a} x)))))))"
            );
            let trs = crate::parsing::parse_ari_trs(None, &input).unwrap();
            let Some(NonterminationProof::Loop(proof)) =
                srs_context_extension_loop_ordered(&trs, None, 2)
            else {
                panic!("backward loop");
            };
            assert!(check_loop_proof_for_trs(&trs, &proof));
            assert!(!proof.steps.is_empty());
            assert!(srs_context_extension_loop_ordered(&trs, Some(Instant::now()), 2).is_none());
        }
        let trs =
            crate::parsing::parse_ari_trs(None, "(format TRS) (fun a 1) (rule (a (a x)) (a x))")
                .unwrap();
        assert!(srs_context_extension_loop_ordered(&trs, None, 2).is_none());
    }

    #[test]
    fn narrow_closure_checks_forward_rules_and_deadlines() {
        for (a, b) in [("a", "b"), ("second", "first")] {
            let input = format!(
                "(format TRS) (fun {a} 1) (fun {b} 1)
                (rule ({a} ({b} x)) ({b} ({a} x)))
                (rule ({b} ({a} x)) ({a} ({b} ({b} x))))"
            );
            let trs = crate::parsing::parse_ari_trs(None, &input).unwrap();
            for lane in [3, 4, 5, 6] {
                let Some(NonterminationProof::Loop(proof)) =
                    srs_context_extension_loop_ordered(&trs, None, lane)
                else {
                    panic!("loop");
                };
                assert!(check_loop_proof_for_trs(&trs, &proof));
            }
            assert!(srs_context_extension_loop_narrow(&trs, Some(Instant::now())).is_none());
            let Some(NonterminationProof::Loop(proof)) = srs_context_extension_loop_target(
                &trs, Some(Instant::now() + Duration::from_secs(5)), 3, None, false,
            ) else { panic!("target-width loop"); };
            assert!(check_loop_proof_for_trs(&trs, &proof));
            let Some(NonterminationProof::Loop(proof)) = srs_context_extension_loop_target(
                &trs, Some(Instant::now() + Duration::from_secs(5)), 3, Some(12), true,
            ) else { panic!("beam loop"); };
            assert!(check_loop_proof_for_trs(&trs, &proof));
        }
        let trs =
            crate::parsing::parse_ari_trs(None, "(format TRS) (fun a 1) (rule (a (a x)) (a x))")
                .unwrap();
        assert!(srs_context_extension_loop_narrow(&trs, None).is_none());
        let strategy = NonterminationStrategy::parse("srs-overlap-loop-narrow").unwrap();
        assert_eq!(strategy.to_strategy_atom(), "srs-overlap-loop-narrow");
        for width in [1, 15, 25, 40, 64, 128] {
            let atom = format!("srs-overlap-loop(max-width={width})");
            assert_eq!(NonterminationStrategy::parse(&atom).unwrap().to_strategy_atom(), atom);
        }
        assert!(NonterminationStrategy::parse("srs-overlap-loop(max-width=129)").is_err());
        assert!(srs_context_extension_loop_bounded(&trs, None, 0).is_none());
        assert!(srs_context_extension_loop_target(&trs, None, 0, None, false).is_none());
        assert!(srs_context_extension_loop_target(&trs, Some(Instant::now()), 3, None, false).is_none());
        assert!(srs_context_extension_loop_target(&trs, Some(Instant::now() + Duration::from_secs(1)), 3, None, false).is_none());
        assert!(srs_context_extension_loop_target(&trs, Some(Instant::now() + Duration::from_secs(1)), 3, None, true).is_none());
        let atom = "srs-overlap-loop-beam(width=9,max-width=42)";
        assert_eq!(NonterminationStrategy::parse(atom).unwrap().to_strategy_atom(), atom);
        let atom = "srs-overlap-loop-target(width=9,max-width=42)";
        assert_eq!(NonterminationStrategy::parse(atom).unwrap().to_strategy_atom(), atom);
        for atom in ["srs-overlap-loop-target(width=9,max-width=8)", "srs-overlap-loop-target(width=9,max-width=129)"] {
            assert!(NonterminationStrategy::parse(atom).is_err());
        }
        for width in [1, 9, 21, 64] {
            let atom = format!("srs-overlap-loop-target(width={width})");
            assert_eq!(NonterminationStrategy::parse(&atom).unwrap().to_strategy_atom(), atom);
        }
        assert!(NonterminationStrategy::parse("srs-overlap-loop-target(width=65)").is_err());
    }

    #[test]
    fn parameterized_closure_can_cross_the_legacy_word_limit() {
        let word = |symbol: &str| format!("{}x{}", format!("({symbol} ").repeat(70), ")".repeat(70));
        let a = word("a");
        let b = word("b");
        let trs = crate::parsing::parse_ari_trs(None, &format!(
            "(format TRS) (fun a 1) (fun b 1) (rule {a} {b}) (rule {b} {a})"
        )).unwrap();
        let Some(NonterminationProof::Loop(proof)) = srs_context_extension_loop_bounded(
            &trs, Some(Instant::now() + Duration::from_secs(5)), 96,
        ) else { panic!("wide two-step loop"); };
        assert!(check_loop_proof_for_trs(&trs, &proof));
        assert!(srs_context_extension_loop_bounded(&trs, None, 40).is_none());
    }

    #[test]
    fn closure_priority_prefers_deeper_narrow_derivations() {
        assert!(closure_priority(2, 3, 32) > closure_priority(2, 3, 2));
        assert!(closure_priority(2, 3, 8) > closure_priority(12, 3, 8));
        assert!(closure_priority(2, 3, 8) > closure_priority(2, 16, 8));
        let _ = closure_priority(0, 0, 1);
    }
}

#[derive(Clone)]
pub(crate) struct StrictSrsRule<'a> {
    rule: &'a RewriteRule,
    lhs: Vec<Symbol>,
    search_lhs: Vec<Symbol>,
    search_rhs: Vec<Symbol>,
}

#[derive(Clone, Copy)]
pub(crate) enum SrsLoopSearchDirection {
    Forward,
    Reversed,
}

pub(crate) fn srs_rewriting_loop(
    trs: &Trs,
    deadline: Option<Instant>,
) -> Option<NonterminationProof> {
    srs_rewriting_loop_with_depth(trs, deadline, MAX_LOOP_REWRITE_STEPS)
}

pub(crate) fn srs_rewriting_loop_with_depth(
    trs: &Trs,
    deadline: Option<Instant>,
    max_steps: usize,
) -> Option<NonterminationProof> {
    srs_rewriting_loop_bounded(trs, SrsLoopSearchDirection::Forward, deadline, max_steps).or_else(
        || {
            if strategy_timed_out(deadline) {
                None
            } else {
                srs_rewriting_loop_bounded(
                    trs,
                    SrsLoopSearchDirection::Reversed,
                    deadline,
                    max_steps,
                )
            }
        },
    )
}

#[cfg(test)]
pub(crate) fn srs_rewriting_loop_in_direction(
    trs: &Trs,
    direction: SrsLoopSearchDirection,
    deadline: Option<Instant>,
) -> Option<NonterminationProof> {
    srs_rewriting_loop_bounded(trs, direction, deadline, MAX_LOOP_REWRITE_STEPS)
}

fn srs_rewriting_loop_bounded(
    trs: &Trs,
    direction: SrsLoopSearchDirection,
    deadline: Option<Instant>,
    max_steps: usize,
) -> Option<NonterminationProof> {
    let srs_rules = trs.srs_rules()?;
    let rules = trs
        .rules()
        .iter()
        .zip(srs_rules)
        .map(|(rule, srs_rule)| {
            let lhs = srs_rule.lhs().to_vec();
            let rhs = srs_rule.rhs().to_vec();
            let search_lhs = srs_loop_search_word(&lhs, direction);
            let search_rhs = srs_loop_search_word(&rhs, direction);
            StrictSrsRule {
                rule,
                lhs,
                search_lhs,
                search_rhs,
            }
        })
        .collect::<Vec<_>>();
    if rules.is_empty() {
        return None;
    }
    let mut starts = rules
        .iter()
        .map(|r| (r.lhs.clone(), r.rule.lhs().clone()))
        .collect::<Vec<_>>();
    if max_steps > MAX_LOOP_REWRITE_STEPS {
        // A loop need not start at an isolated lhs: neighboring redexes may
        // enable one another. Build bounded overlap/concatenation contexts
        // from the live rules, not from retained witness terms.
        let words = trs
            .srs_rules()?
            .into_iter()
            .flat_map(|r| [r.lhs().to_vec(), r.rhs().to_vec()])
            .collect::<Vec<_>>();
        let mut seen = starts
            .iter()
            .map(|(w, _)| w.clone())
            .collect::<BTreeSet<_>>();
        'contexts: for left in &words {
            for right in &words {
                if strategy_timed_out(deadline) {
                    return None;
                }
                for overlap in (0..left.len().min(right.len())).rev() {
                    if left[left.len() - overlap..] != right[..overlap] {
                        continue;
                    }
                    let mut word = left.clone();
                    word.extend_from_slice(&right[overlap..]);
                    if word.is_empty()
                        || word.len() > MAX_SRS_LOOP_WORD_LEN
                        || !seen.insert(word.clone())
                    {
                        continue;
                    }
                    let term = word_to_term_with_tail(&word, Term::var("_srs_loop_tail"));
                    starts.push((word, term));
                    if starts.len() >= 256 {
                        break 'contexts;
                    }
                }
            }
        }
    }
    'starts: for (start_original_word, start) in starts {
        if strategy_timed_out(deadline) {
            return None;
        }
        let start_search_word = srs_loop_search_word(&start_original_word, direction);
        if start_search_word.is_empty() {
            continue;
        }
        let mut queue = VecDeque::from([(start_search_word.clone(), start.clone(), Vec::new())]);
        let mut seen = BTreeSet::from([start_search_word.clone()]);
        let mut explored = 0usize;
        while let Some((search_word, term, steps)) = queue.pop_front() {
            if strategy_timed_out(deadline) {
                return None;
            }
            let original_word = srs_loop_original_word(&search_word, direction);
            if !steps.is_empty()
                && let Some((context_position, substitution)) =
                    closes_srs_loop(&start_original_word, &original_word, &start)
            {
                let proof = LoopProof {
                    start: start.clone(),
                    steps: steps.clone(),
                    substitution,
                    context_position,
                };
                if check_loop_proof_for_trs(trs, &proof) {
                    return Some(NonterminationProof::Loop(proof));
                }
            }
            if steps.len() >= max_steps {
                continue;
            }
            for search_offset in 0..=search_word.len() {
                for rule in &rules {
                    if strategy_timed_out(deadline) {
                        return None;
                    }
                    if !word_has_at(&search_word, &rule.search_lhs, search_offset) {
                        continue;
                    }
                    let next_search_word = replace_word_at(
                        &search_word,
                        search_offset,
                        rule.search_lhs.len(),
                        &rule.search_rhs,
                    );
                    if next_search_word.len() > MAX_SRS_LOOP_WORD_LEN {
                        continue;
                    }
                    let closes_candidate = contains_word(&next_search_word, &start_search_word);
                    if !closes_candidate && !seen.insert(next_search_word.clone()) {
                        continue;
                    }
                    let Some(original_offset) = srs_loop_original_offset(
                        search_word.len(),
                        search_offset,
                        rule.search_lhs.len(),
                        direction,
                    ) else {
                        continue;
                    };
                    let position = vec![1; original_offset];
                    let Some(redex) = subterm_at_position(&term, &position) else {
                        continue;
                    };
                    let Some(substitution) = match_pattern(rule.rule.lhs(), redex) else {
                        continue;
                    };
                    let rhs = apply_substitution(rule.rule.rhs(), &substitution);
                    let Some(next_term) = replace_subterm_at_position(&term, &position, &rhs)
                    else {
                        continue;
                    };
                    explored += 1;
                    if explored > MAX_LOOP_FRONTIER {
                        if max_steps > MAX_LOOP_REWRITE_STEPS {
                            continue 'starts;
                        }
                        return None;
                    }
                    let mut next_steps = steps.clone();
                    next_steps.push(LoopRewriteStep {
                        position,
                        rule: rule.rule.clone(),
                        result: next_term.clone(),
                    });
                    queue.push_back((next_search_word, next_term, next_steps));
                }
            }
        }
    }
    None
}

pub(crate) fn srs_derivation_pattern_nontermination(trs: &Trs) -> Option<NonterminationProof> {
    if trs.strategy() != RewriteStrategy::Full {
        return None;
    }
    let rules = trs
        .srs_rules()?
        .into_iter()
        .map(|rule| SrsOverlapClosure {
            lhs: rule.lhs().to_vec(),
            rhs: rule.rhs().to_vec(),
        })
        .collect::<Vec<_>>();

    for commute_left in &rules {
        let [a, left] = commute_left.lhs.as_slice() else {
            continue;
        };
        if commute_left.rhs != [left.clone(), a.clone()] {
            continue;
        }
        for commute_right in &rules {
            let [right, commute_symbol] = commute_right.lhs.as_slice() else {
                continue;
            };
            if commute_symbol != a || commute_right.rhs != [a.clone(), right.clone()] {
                continue;
            }
            for switch in &rules {
                let Some(switch_left) = switch.lhs.last() else {
                    continue;
                };
                if switch_left != left
                    || switch.rhs.last() != Some(right)
                    || switch.lhs[..switch.lhs.len() - 1] != switch.rhs[..switch.rhs.len() - 1]
                {
                    continue;
                }
                let pump_prefix = &switch.lhs[..switch.lhs.len() - 1];
                let Some(expand) = rules.iter().find(|rule| {
                    rule.lhs.first() == Some(right)
                        && rule.rhs.starts_with(&[left.clone(), a.clone()])
                        && rule.lhs[1..] == rule.rhs[2..]
                }) else {
                    continue;
                };
                let pump_suffix = &expand.lhs[1..];
                return Some(NonterminationProof::SrsDerivationPatterns(
                    commuting_pump_derivation_pattern_proof(
                        a,
                        left,
                        right,
                        pump_prefix,
                        pump_suffix,
                        commute_left,
                        commute_right,
                        switch,
                        expand,
                    ),
                ));
            }
        }
    }
    None
}

pub(crate) fn srs_word_pattern(
    prefix: Vec<Symbol>,
    repeated: &Symbol,
    constant: usize,
    suffix: Vec<Symbol>,
) -> SrsWordPattern {
    SrsWordPattern {
        prefix,
        repeated: vec![repeated.clone()],
        factor: 1,
        constant,
        suffix,
    }
}

pub(crate) fn commuting_pump_derivation_pattern_proof(
    a: &Symbol,
    left: &Symbol,
    right: &Symbol,
    pump_prefix: &[Symbol],
    pump_suffix: &[Symbol],
    commute_left: &SrsOverlapClosure,
    commute_right: &SrsOverlapClosure,
    switch: &SrsOverlapClosure,
    expand: &SrsOverlapClosure,
) -> SrsDerivationPatternProof {
    let commute_right_pattern = SrsDerivationPattern {
        lhs: srs_word_pattern(vec![right.clone()], a, 0, vec![]),
        rhs: srs_word_pattern(vec![], a, 0, vec![right.clone()]),
    };
    let expanded_pattern = SrsDerivationPattern {
        lhs: srs_word_pattern(vec![right.clone()], a, 0, pump_suffix.to_vec()),
        rhs: srs_word_pattern(
            vec![],
            a,
            0,
            [vec![left.clone(), a.clone()], pump_suffix.to_vec()].concat(),
        ),
    };
    let commute_left_pattern = SrsDerivationPattern {
        lhs: srs_word_pattern(vec![], a, 0, vec![left.clone()]),
        rhs: srs_word_pattern(vec![left.clone()], a, 0, vec![]),
    };
    let composed_pattern = SrsDerivationPattern {
        lhs: expanded_pattern.lhs.clone(),
        rhs: srs_word_pattern(
            vec![left.clone()],
            a,
            0,
            [vec![a.clone()], pump_suffix.to_vec()].concat(),
        ),
    };
    let normalized_pattern = SrsDerivationPattern {
        lhs: composed_pattern.lhs.clone(),
        rhs: srs_word_pattern(vec![left.clone()], a, 1, pump_suffix.to_vec()),
    };
    let mut self_prefix = pump_prefix.to_vec();
    self_prefix.push(right.clone());
    let self_embedding = SrsDerivationPattern {
        lhs: srs_word_pattern(self_prefix.clone(), a, 0, pump_suffix.to_vec()),
        rhs: srs_word_pattern(self_prefix, a, 1, pump_suffix.to_vec()),
    };

    SrsDerivationPatternProof {
        steps: vec![
            SrsDerivationPatternStep::Original {
                closure: commute_right.clone(),
                is_pair: false,
            },
            SrsDerivationPatternStep::OverlapIntoPatternRight {
                pattern: commute_right_pattern.clone(),
                closure: commute_right.clone(),
            },
            SrsDerivationPatternStep::Original {
                closure: expand.clone(),
                is_pair: false,
            },
            SrsDerivationPatternStep::PatternOverlapSuffix {
                result: expanded_pattern.clone(),
                pattern: commute_right_pattern,
                closure: expand.clone(),
                left: vec![],
                right: pump_suffix.to_vec(),
                overlap: vec![right.clone()],
            },
            SrsDerivationPatternStep::Original {
                closure: commute_left.clone(),
                is_pair: false,
            },
            SrsDerivationPatternStep::OverlapIntoPatternLeft {
                pattern: commute_left_pattern.clone(),
                closure: commute_left.clone(),
            },
            SrsDerivationPatternStep::PatternCompositionPrefix {
                result: composed_pattern.clone(),
                first: expanded_pattern,
                second: commute_left_pattern,
                left: vec![],
                right: [vec![a.clone()], pump_suffix.to_vec()].concat(),
            },
            SrsDerivationPatternStep::Equivalent {
                result: normalized_pattern.clone(),
                premise: composed_pattern,
            },
            SrsDerivationPatternStep::Original {
                closure: switch.clone(),
                is_pair: false,
            },
            SrsDerivationPatternStep::OverlapPatternPrefix {
                result: self_embedding.clone(),
                pattern: normalized_pattern,
                closure: switch.clone(),
                left: pump_prefix.to_vec(),
                right: vec![],
                overlap: vec![left.clone()],
            },
        ],
        self_embedding,
        left_context: vec![],
        right_context: vec![],
    }
}

pub(crate) fn srs_loop_search_word(
    word: &[Symbol],
    direction: SrsLoopSearchDirection,
) -> Vec<Symbol> {
    match direction {
        SrsLoopSearchDirection::Forward => word.to_vec(),
        SrsLoopSearchDirection::Reversed => word.iter().cloned().rev().collect(),
    }
}

pub(crate) fn srs_loop_original_word(
    word: &[Symbol],
    direction: SrsLoopSearchDirection,
) -> Vec<Symbol> {
    srs_loop_search_word(word, direction)
}

pub(crate) fn srs_loop_original_offset(
    search_word_len: usize,
    search_offset: usize,
    search_lhs_len: usize,
    direction: SrsLoopSearchDirection,
) -> Option<usize> {
    match direction {
        SrsLoopSearchDirection::Forward => Some(search_offset),
        SrsLoopSearchDirection::Reversed => {
            search_word_len.checked_sub(search_offset + search_lhs_len)
        }
    }
}

pub(crate) fn contains_word(word: &[Symbol], needle: &[Symbol]) -> bool {
    (0..=word.len().saturating_sub(needle.len())).any(|offset| word_has_at(word, needle, offset))
}

pub(crate) fn word_has_at(word: &[Symbol], needle: &[Symbol], offset: usize) -> bool {
    !needle.is_empty()
        && offset + needle.len() <= word.len()
        && word[offset..offset + needle.len()] == *needle
}

pub(crate) fn replace_word_at(
    word: &[Symbol],
    offset: usize,
    matched_len: usize,
    replacement: &[Symbol],
) -> Vec<Symbol> {
    let mut next = Vec::with_capacity(word.len() + replacement.len().saturating_sub(matched_len));
    next.extend_from_slice(&word[..offset]);
    next.extend_from_slice(replacement);
    next.extend_from_slice(&word[offset + matched_len..]);
    next
}

pub(crate) fn closes_srs_loop(
    start_word: &[Symbol],
    current_word: &[Symbol],
    start_term: &Term,
) -> Option<(Vec<usize>, BTreeMap<Variable, Term>)> {
    for offset in 0..=current_word.len().saturating_sub(start_word.len()) {
        if !word_has_at(current_word, start_word, offset) {
            continue;
        }
        if start_term.variables().len() != 1 {
            continue;
        }
        let variable = start_term.variables().into_iter().next()?;
        let suffix = word_to_term_with_tail(
            &current_word[offset + start_word.len()..],
            Term::Var(variable.clone()),
        );
        let mut substitution = BTreeMap::new();
        substitution.insert(variable, suffix);
        return Some((vec![1; offset], substitution));
    }
    None
}

pub(crate) fn word_to_term_with_tail(word: &[Symbol], tail: Term) -> Term {
    word.iter()
        .rev()
        .fold(tail, |term, symbol| Term::app(symbol.as_str(), vec![term]))
}

pub(crate) fn one_step_loop(rule: &RewriteRule) -> Option<LoopProof> {
    for (position, subterm) in positions_with_subterms(rule.rhs()) {
        if let Some(substitution) = match_pattern(rule.lhs(), subterm) {
            let step = LoopRewriteStep {
                position: Vec::new(),
                rule: rule.clone(),
                result: rule.rhs().clone(),
            };
            let proof = LoopProof {
                start: rule.lhs().clone(),
                steps: vec![step],
                substitution,
                context_position: position,
            };
            if check_loop_proof(&proof) {
                return Some(proof);
            }
        }
    }
    None
}
