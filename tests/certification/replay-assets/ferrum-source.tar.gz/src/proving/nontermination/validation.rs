//! Independent loop replay, strategy validation, and term operations.

use super::*;

pub(crate) fn validate_loop_proof(proof: &LoopProof) -> bool {
    if proof.steps.is_empty() {
        return false;
    }
    let mut current = proof.start.clone();
    for (step_index, step) in proof.steps.iter().enumerate() {
        let Some(redex) = subterm_at_position(&current, &step.position) else {
            return false;
        };
        let rule = freshen_rule(&step.rule, step_index, proof.steps.len());
        let Some(mut substitution) = match_pattern(rule.lhs(), redex) else {
            return false;
        };
        let Some(expected_replacement) = subterm_at_position(&step.result, &step.position) else {
            return false;
        };
        let partially_instantiated_rhs = apply_substitution(rule.rhs(), &substitution);
        let Some(rhs_substitution) =
            match_pattern(&partially_instantiated_rhs, expected_replacement)
        else {
            return false;
        };
        for (variable, term) in rhs_substitution {
            if substitution
                .get(&variable)
                .is_some_and(|existing| existing != &term)
            {
                return false;
            }
            substitution.insert(variable, term);
        }
        let rhs = apply_substitution(rule.rhs(), &substitution);
        let Some(next) = replace_subterm_at_position(&current, &step.position, &rhs) else {
            return false;
        };
        if next != step.result {
            return false;
        }
        current = next;
    }
    let closed = apply_substitution(&proof.start, &proof.substitution);
    subterm_at_position(&current, &proof.context_position) == Some(&closed)
}

pub(crate) fn ground_outermost_loop_instance(
    trs: &Trs,
    proof: &LoopProof,
    deadline: Option<Instant>,
) -> Option<LoopProof> {
    const MAX_GROUND_ASSIGNMENTS: usize = 4096;

    let variables = proof
        .start
        .variables()
        .into_iter()
        .chain(proof.steps.iter().flat_map(|step| step.result.variables()))
        .chain(proof.substitution.values().flat_map(Term::variables))
        .collect::<BTreeSet<_>>()
        .into_iter()
        .collect::<Vec<_>>();
    let ground_terms = small_ground_terms(trs, deadline)?;
    let mut assignment = BTreeMap::new();
    let mut tried = 0usize;
    find_ground_outermost_loop_instance(
        trs,
        proof,
        &variables,
        &ground_terms,
        0,
        &mut assignment,
        &mut tried,
        MAX_GROUND_ASSIGNMENTS,
        deadline,
    )
}

pub(crate) fn validated_outermost_loop_instance(
    trs: &Trs,
    proof: &LoopProof,
    deadline: Option<Instant>,
) -> Option<LoopProof> {
    let validated = if check_symbolic_outermost_loop_by_nonunifiability(trs, proof) {
        proof.clone()
    } else {
        ground_outermost_loop_instance(trs, proof, deadline)?
    };
    canonicalize_loop_rules_for_cpf(trs, &validated)
}

/// CPF's loop checker requires every displayed rewrite rule to be a literal
/// member of the input TRS. Search deliberately freshens rule variables to
/// avoid capture, so retain the searched terms/substitutions but serialize the
/// corresponding input-rule representative. Alpha-renaming does not change
/// the rewrite step, and the final replay below checks that fact explicitly.
pub(crate) fn canonicalize_loop_rules_for_cpf(trs: &Trs, proof: &LoopProof) -> Option<LoopProof> {
    let mut canonical = proof.clone();
    for step in &mut canonical.steps {
        step.rule = trs
            .rules()
            .iter()
            .find(|rule| rewrite_rules_are_variants(rule, &step.rule))?
            .clone();
    }
    check_loop_proof(&canonical).then_some(canonical)
}

/// Sufficient outermost-loop criterion closed under arbitrary substitutions.
/// If no rule left-hand side unifies with any proper ancestor of a loop step,
/// applying the loop substitution cannot introduce a redex above that step.
pub(crate) fn check_symbolic_outermost_loop_by_nonunifiability(
    trs: &Trs,
    proof: &LoopProof,
) -> bool {
    if !check_loop_proof(proof) {
        return false;
    }

    let rigid_subject_variables = proof
        .substitution
        .iter()
        .all(|(variable, term)| term == &Term::Var(variable.clone()));
    let mut current = proof.start.clone();
    for step in &proof.steps {
        for prefix_len in 0..step.position.len() {
            let Some(ancestor) = subterm_at_position(&current, &step.position[..prefix_len]) else {
                return false;
            };
            if term_may_become_redex(ancestor, trs.rules(), rigid_subject_variables) {
                return false;
            }
        }
        current = step.result.clone();
    }

    repeated_context_ancestors_cannot_be_redex(trs, proof, &current, rigid_subject_variables)
}

pub(crate) fn repeated_context_ancestors_cannot_be_redex(
    trs: &Trs,
    proof: &LoopProof,
    loop_result: &Term,
    rigid_subject_variables: bool,
) -> bool {
    if proof.context_position.is_empty() {
        return true;
    }
    let hole = fresh_outermost_hole_variable(loop_result, trs.rules());
    let Some(context) = replace_subterm_at_position(
        loop_result,
        &proof.context_position,
        &Term::Var(hole.clone()),
    ) else {
        return false;
    };
    let max_lhs_depth = trs
        .rules()
        .iter()
        .map(|rule| term_depth(rule.lhs()))
        .max()
        .unwrap_or(0);
    let mut plugged = proof.start.clone();
    for iteration in 0..=max_lhs_depth {
        let context = freshen_context_variables(&context, &hole, iteration, &plugged.variables());
        let next = apply_substitution(&context, &BTreeMap::from([(hole.clone(), plugged.clone())]));
        for prefix_len in 0..proof.context_position.len() {
            let Some(ancestor) = subterm_at_position(&next, &proof.context_position[..prefix_len])
            else {
                return false;
            };
            if term_may_become_redex(ancestor, trs.rules(), rigid_subject_variables) {
                return false;
            }
        }
        plugged = next;
    }

    // Checking only the ancestors of the context hole is insufficient.  A
    // later step of the repeated rewrite sequence can create a redex between
    // the hole and that step.  For example, in C = g(f(box)), the sequence
    // a -> f(a) -> f(f(a)) is outermost once, but its second step below C is
    // blocked by the newly created f(f(a)) redex.  CPF/CeTA checks the
    // iterated sequence, so mirror that obligation for identity-substitution
    // symbolic loops before emitting a certificate.
    if rigid_subject_variables {
        for copies in 1..=max_lhs_depth.saturating_add(1) {
            let mut current = proof.start.clone();
            for step in &proof.steps {
                let mut embedded = current.clone();
                for iteration in 0..copies {
                    let fresh_context = freshen_context_variables(
                        &context,
                        &hole,
                        iteration,
                        &embedded.variables(),
                    );
                    embedded = apply_substitution(
                        &fresh_context,
                        &BTreeMap::from([(hole.clone(), embedded)]),
                    );
                }
                let mut embedded_position = Vec::new();
                for _ in 0..copies {
                    embedded_position.extend_from_slice(&proof.context_position);
                }
                embedded_position.extend_from_slice(&step.position);
                for prefix_len in 0..embedded_position.len() {
                    let Some(ancestor) =
                        subterm_at_position(&embedded, &embedded_position[..prefix_len])
                    else {
                        return false;
                    };
                    if term_may_become_redex(ancestor, trs.rules(), true) {
                        return false;
                    }
                }
                current = step.result.clone();
            }
        }
    }
    true
}

pub(crate) fn freshen_context_variables(
    term: &Term,
    hole: &Variable,
    iteration: usize,
    occupied: &BTreeSet<Variable>,
) -> Term {
    fn freshen(
        term: &Term,
        hole: &Variable,
        iteration: usize,
        occupied: &BTreeSet<Variable>,
        renaming: &mut BTreeMap<Variable, Term>,
    ) -> Term {
        match term {
            Term::Var(variable) if variable == hole => term.clone(),
            Term::Var(variable) => {
                if let Some(term) = renaming.get(variable) {
                    return term.clone();
                }
                let mut candidate = Variable::new(format!(
                    "__outermost_context_{iteration}_{}",
                    variable.as_str()
                ));
                while occupied.contains(&candidate)
                    || renaming
                        .values()
                        .any(|value| value == &Term::Var(candidate.clone()))
                {
                    candidate = Variable::new(format!("_{}", candidate.as_str()));
                }
                let term = Term::Var(candidate);
                renaming.insert(variable.clone(), term.clone());
                term
            }
            Term::App { symbol, args } => Term::app(
                symbol.as_str(),
                args.iter()
                    .map(|argument| freshen(argument, hole, iteration, occupied, renaming))
                    .collect(),
            ),
        }
    }

    freshen(term, hole, iteration, occupied, &mut BTreeMap::new())
}

pub(crate) fn term_depth(term: &Term) -> usize {
    match term {
        Term::Var(_) => 0,
        Term::App { args, .. } => 1 + args.iter().map(term_depth).max().unwrap_or(0),
    }
}

pub(crate) fn term_may_become_redex(
    term: &Term,
    rules: &[RewriteRule],
    rigid_subject_variables: bool,
) -> bool {
    if rigid_subject_variables {
        return rules
            .iter()
            .any(|rule| match_pattern(rule.lhs(), term).is_some());
    }
    let occupied = term.variables();
    rules.iter().enumerate().any(|(index, rule)| {
        let lhs = rename_variables_away_from(rule.lhs(), &occupied, index);
        unify_terms(term, &lhs, &mut BTreeMap::new())
    })
}

pub(crate) fn rename_variables_away_from(
    term: &Term,
    occupied: &BTreeSet<Variable>,
    index: usize,
) -> Term {
    let mut renaming = BTreeMap::new();
    for variable in term.variables() {
        let mut candidate =
            Variable::new(format!("__outermost_rule_{index}_{}", variable.as_str()));
        while occupied.contains(&candidate)
            || renaming
                .values()
                .any(|value| value == &Term::Var(candidate.clone()))
        {
            candidate = Variable::new(format!("_{}", candidate.as_str()));
        }
        renaming.insert(variable, Term::Var(candidate));
    }
    apply_substitution(term, &renaming)
}

pub(crate) fn fresh_outermost_hole_variable(term: &Term, rules: &[RewriteRule]) -> Variable {
    let mut occupied = term.variables();
    occupied.extend(
        rules
            .iter()
            .flat_map(|rule| rule.lhs().variables().into_iter()),
    );
    let mut variable = Variable::new("__outermost_context_hole");
    while occupied.contains(&variable) {
        variable = Variable::new(format!("_{}", variable.as_str()));
    }
    variable
}

#[allow(clippy::too_many_arguments)]
pub(crate) fn find_ground_outermost_loop_instance(
    trs: &Trs,
    proof: &LoopProof,
    variables: &[Variable],
    ground_terms: &[Term],
    index: usize,
    assignment: &mut BTreeMap<Variable, Term>,
    tried: &mut usize,
    max_assignments: usize,
    deadline: Option<Instant>,
) -> Option<LoopProof> {
    if strategy_timed_out(deadline) || *tried >= max_assignments {
        return None;
    }
    if index < variables.len() {
        let variable = variables[index].clone();
        for term in ground_terms {
            assignment.insert(variable.clone(), term.clone());
            if let Some(proof) = find_ground_outermost_loop_instance(
                trs,
                proof,
                variables,
                ground_terms,
                index + 1,
                assignment,
                tried,
                max_assignments,
                deadline,
            ) {
                return Some(proof);
            }
        }
        assignment.remove(&variable);
        return None;
    }

    *tried += 1;
    let candidate = LoopProof {
        start: apply_substitution(&proof.start, assignment),
        steps: proof
            .steps
            .iter()
            .map(|step| LoopRewriteStep {
                position: step.position.clone(),
                rule: step.rule.clone(),
                result: apply_substitution(&step.result, assignment),
            })
            .collect(),
        substitution: BTreeMap::new(),
        context_position: proof.context_position.clone(),
    };
    check_ground_outermost_context_loop(trs, &candidate).then_some(candidate)
}

pub(crate) fn check_ground_outermost_context_loop(trs: &Trs, proof: &LoopProof) -> bool {
    if !proof.start.variables().is_empty()
        || !proof.substitution.is_empty()
        || proof
            .steps
            .iter()
            .any(|step| !step.result.variables().is_empty())
        || !check_loop_proof(proof)
    {
        return false;
    }
    let mut current = proof.start.clone();
    for step in &proof.steps {
        if !is_outermost_rewrite_position(&current, &step.position, trs.rules()) {
            return false;
        }
        current = step.result.clone();
    }
    if !is_outermost_rewrite_position(&current, &proof.context_position, trs.rules()) {
        return false;
    }
    (0..proof.context_position.len()).all(|prefix_len| {
        let Some(symbol) = subterm_at_position(&current, &proof.context_position[..prefix_len])
            .and_then(Term::root_symbol)
        else {
            return false;
        };
        trs.rules()
            .iter()
            .all(|rule| rule.lhs().root_symbol() != Some(symbol))
    })
}

pub(crate) fn check_loop_proof_for_trs(trs: &Trs, proof: &LoopProof) -> bool {
    if !check_loop_proof(proof) {
        return false;
    }
    match trs.strategy() {
        RewriteStrategy::Full => return true,
        RewriteStrategy::Outermost => {
            if proof.context_position.is_empty()
                && proof.steps.iter().all(|step| step.position.is_empty())
            {
                return true;
            }
            return check_symbolic_outermost_loop_by_nonunifiability(trs, proof)
                || check_ground_outermost_context_loop(trs, proof);
        }
        RewriteStrategy::Innermost => {}
    }
    let mut current = proof.start.clone();
    for step in &proof.steps {
        let instantiated_current = apply_substitution(&current, &proof.substitution);
        let Some(redex) = subterm_at_position(&instantiated_current, &step.position) else {
            return false;
        };
        if !proper_subterms_are_normal(redex, trs.rules()) {
            return false;
        }
        current = step.result.clone();
    }
    true
}

pub(crate) fn check_mixed_dp_loop_proof(
    trs: &Trs,
    pairs: &[DependencyPair],
    proof: &LoopProof,
) -> bool {
    if !check_loop_proof_for_trs(trs, proof) {
        return false;
    }
    proof.steps.iter().all(|step| {
        let is_dependency_pair = pairs
            .iter()
            .any(|pair| rewrite_rules_are_variants(&step.rule, &pair.as_rule()));
        if is_dependency_pair {
            step.position.is_empty()
        } else {
            trs.rules()
                .iter()
                .any(|rule| rewrite_rules_are_variants(&step.rule, rule))
        }
    })
}

pub(crate) fn rewrite_rules_are_variants(left: &RewriteRule, right: &RewriteRule) -> bool {
    fn terms_are_variants(
        left: &Term,
        right: &Term,
        forward: &mut BTreeMap<Variable, Variable>,
        backward: &mut BTreeMap<Variable, Variable>,
    ) -> bool {
        match (left, right) {
            (Term::Var(left), Term::Var(right)) => {
                if forward.get(left).is_some_and(|mapped| mapped != right)
                    || backward.get(right).is_some_and(|mapped| mapped != left)
                {
                    return false;
                }
                forward.insert(left.clone(), right.clone());
                backward.insert(right.clone(), left.clone());
                true
            }
            (
                Term::App {
                    symbol: left_symbol,
                    args: left_args,
                },
                Term::App {
                    symbol: right_symbol,
                    args: right_args,
                },
            ) => {
                left_symbol == right_symbol
                    && left_args.len() == right_args.len()
                    && left_args
                        .iter()
                        .zip(right_args)
                        .all(|(left, right)| terms_are_variants(left, right, forward, backward))
            }
            _ => false,
        }
    }

    let mut forward = BTreeMap::new();
    let mut backward = BTreeMap::new();
    terms_are_variants(left.lhs(), right.lhs(), &mut forward, &mut backward)
        && terms_are_variants(left.rhs(), right.rhs(), &mut forward, &mut backward)
}

pub(crate) fn proper_subterms_are_normal(term: &Term, rules: &[RewriteRule]) -> bool {
    let Term::App { args, .. } = term else {
        return true;
    };
    args.iter()
        .all(|arg| is_normal_form(arg, rules) && proper_subterms_are_normal(arg, rules))
}

pub(crate) fn is_normal_form(term: &Term, rules: &[RewriteRule]) -> bool {
    positions_with_subterms(term)
        .into_iter()
        .all(|(_, subterm)| {
            rules
                .iter()
                .all(|rule| match_pattern(rule.lhs(), subterm).is_none())
        })
}

pub(crate) fn closes_loop(
    start: &Term,
    current: &Term,
) -> Option<(Vec<usize>, BTreeMap<Variable, Term>)> {
    for (position, subterm) in positions_with_subterms(current) {
        if let Some(substitution) = match_pattern(start, subterm) {
            return Some((position, substitution));
        }
    }
    None
}

pub(crate) fn freshen_rule(rule: &RewriteRule, rule_index: usize, depth: usize) -> RewriteRule {
    RewriteRule::new(
        freshen_term(rule.lhs(), rule_index, depth),
        freshen_term(rule.rhs(), rule_index, depth),
    )
}

pub(crate) fn freshen_term(term: &Term, rule_index: usize, depth: usize) -> Term {
    match term {
        Term::Var(variable) => Term::var(format!("{}_n{depth}_{rule_index}", variable.as_str())),
        Term::App { symbol, args } => Term::app(
            symbol.as_str(),
            args.iter()
                .map(|arg| freshen_term(arg, rule_index, depth))
                .collect(),
        ),
    }
}

pub(crate) fn unify_terms(
    lhs: &Term,
    rhs: &Term,
    substitution: &mut BTreeMap<Variable, Term>,
) -> bool {
    let lhs = apply_substitution(lhs, substitution);
    let rhs = apply_substitution(rhs, substitution);
    match (&lhs, &rhs) {
        (Term::Var(variable), term) => bind_unification_variable(variable, term, substitution),
        (term, Term::Var(variable)) => bind_unification_variable(variable, term, substitution),
        (
            Term::App {
                symbol: lhs_symbol,
                args: lhs_args,
            },
            Term::App {
                symbol: rhs_symbol,
                args: rhs_args,
            },
        ) => {
            lhs_symbol == rhs_symbol
                && lhs_args.len() == rhs_args.len()
                && lhs_args
                    .iter()
                    .zip(rhs_args)
                    .all(|(left, right)| unify_terms(left, right, substitution))
        }
    }
}

pub(crate) fn bind_unification_variable(
    variable: &Variable,
    term: &Term,
    substitution: &mut BTreeMap<Variable, Term>,
) -> bool {
    if matches!(term, Term::Var(other) if other == variable) {
        return true;
    }
    if term.variables().contains(variable) {
        return false;
    }
    // Keep the unifier idempotent. apply_substitution is intentionally a
    // simultaneous substitution, not recursive dereferencing; leaving x -> y
    // behind after binding y -> f(z) loses constraints when replaying a path.
    let binding = BTreeMap::from([(variable.clone(), term.clone())]);
    for image in substitution.values_mut() {
        *image = apply_substitution(image, &binding);
    }
    substitution.insert(variable.clone(), term.clone());
    true
}

pub(crate) fn apply_substitution(term: &Term, substitution: &BTreeMap<Variable, Term>) -> Term {
    match term {
        Term::Var(variable) => substitution
            .get(variable)
            .cloned()
            .unwrap_or_else(|| term.clone()),
        Term::App { symbol, args } => Term::app(
            symbol.as_str(),
            args.iter()
                .map(|arg| apply_substitution(arg, substitution))
                .collect(),
        ),
    }
}

pub(crate) fn positions_with_subterms(term: &Term) -> Vec<(Vec<usize>, &Term)> {
    let mut positions = Vec::new();
    collect_positions(term, &mut Vec::new(), &mut positions);
    positions
}

pub(crate) fn collect_positions<'a>(
    term: &'a Term,
    current: &mut Vec<usize>,
    positions: &mut Vec<(Vec<usize>, &'a Term)>,
) {
    positions.push((current.clone(), term));
    let Term::App { args, .. } = term else {
        return;
    };
    for (index, arg) in args.iter().enumerate() {
        current.push(index + 1);
        collect_positions(arg, current, positions);
        current.pop();
    }
}

pub(crate) fn subterm_at_position<'a>(term: &'a Term, position: &[usize]) -> Option<&'a Term> {
    let mut current = term;
    for index in position {
        let Term::App { args, .. } = current else {
            return None;
        };
        current = args.get(index.checked_sub(1)?)?;
    }
    Some(current)
}

pub(crate) fn replace_subterm_at_position(
    term: &Term,
    position: &[usize],
    replacement: &Term,
) -> Option<Term> {
    // Save the path, then rebuild it once. Cloning all arguments before
    // descending also clones the soon-to-be-replaced subtree at every depth,
    // making deep unary loop replay quadratic in the context length.
    let mut frames = Vec::with_capacity(position.len());
    let mut current = term;
    for &one_based in position {
        let Term::App { symbol, args } = current else {
            return None;
        };
        let index = one_based.checked_sub(1)?;
        current = args.get(index)?;
        frames.push((symbol, args, index));
    }
    let mut rebuilt = replacement.clone();
    for (symbol, args, index) in frames.into_iter().rev() {
        let mut children = Vec::with_capacity(args.len());
        children.extend_from_slice(&args[..index]);
        children.push(rebuilt);
        children.extend_from_slice(&args[index + 1..]);
        rebuilt = Term::app(symbol.as_str(), children);
    }
    Some(rebuilt)
}

#[cfg(test)]
mod replacement_tests {
    use super::*;

    #[test]
    fn zipper_replacement_preserves_siblings_and_rejects_bad_positions() {
        let a = Term::var("a");
        let b = Term::var("b");
        let c = Term::var("c");
        let replacement = Term::app("new", vec![c.clone()]);
        let tree = Term::app(
            "root",
            vec![
                a.clone(),
                Term::app("branch", vec![b.clone(), c.clone()]),
                a.clone(),
            ],
        );
        assert_eq!(
            replace_subterm_at_position(&tree, &[2, 1], &replacement),
            Some(Term::app(
                "root",
                vec![
                    a.clone(),
                    Term::app("branch", vec![replacement.clone(), c]),
                    a
                ]
            ))
        );
        assert_eq!(
            replace_subterm_at_position(&tree, &[], &replacement),
            Some(replacement.clone())
        );
        for path in [vec![0], vec![4], vec![2, 3], vec![1, 1]] {
            assert!(replace_subterm_at_position(&tree, &path, &replacement).is_none());
        }
        assert_eq!(subterm_at_position(&tree, &[2, 1]), Some(&b));
    }
}
