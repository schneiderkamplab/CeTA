//! Bounded symbolic derivation-pattern closure using CeTA's Nonloop_SRS rules.
//! No alphabet names, supplied derivations, or benchmark dispatch are used.
use super::*;
use std::collections::{BTreeMap, BTreeSet, VecDeque};
use std::sync::Arc;

type Pattern = SrsDerivationPattern;
type Step = SrsDerivationPatternStep;

fn word(prefix: Vec<Symbol>, repeated: Vec<Symbol>, suffix: Vec<Symbol>) -> SrsWordPattern {
    SrsWordPattern {
        prefix,
        repeated,
        factor: 1,
        constant: 0,
        suffix,
    }
}

// This is the executable normal form from Nonloop_SRS_Impl.normalize_wp.
fn normalize(w: &SrsWordPattern) -> SrsWordPattern {
    let mut p = w.clone();
    for _ in 0..p.constant {
        p.prefix.extend(w.repeated.clone());
    }
    p.constant = 0;
    p.repeated = (0..p.factor)
        .flat_map(|_| w.repeated.iter().cloned())
        .collect();
    p.factor = 1;
    if p.repeated.is_empty() {
        p.suffix = [p.prefix, p.suffix].concat();
        p.prefix = vec![];
        return p;
    }
    while p.suffix.first() == p.repeated.first() {
        let s = p.suffix.remove(0);
        p.prefix.push(s);
        p.repeated.rotate_left(1);
    }
    p
}

fn key(p: &Pattern) -> Pattern {
    Pattern {
        lhs: normalize(&p.lhs),
        rhs: normalize(&p.rhs),
    }
}

/// All boundary rotations and collection of explicit periods of a word.
/// Each returned representation has exactly the same function of n, not just
/// the same sampled words. The normal-form equality is checked independently.
fn variants(w: &SrsWordPattern) -> Vec<SrsWordPattern> {
    let normal = normalize(w);
    let mut p = normal.clone();
    let mut out = BTreeSet::new();
    loop {
        let mut q = p.clone();
        out.insert(q.clone());
        while !q.repeated.is_empty() && q.prefix.ends_with(&q.repeated) {
            q.prefix.truncate(q.prefix.len() - q.repeated.len());
            q.constant += 1;
            out.insert(q.clone());
        }
        if p.repeated.is_empty() || p.prefix.last() != p.repeated.last() {
            break;
        }
        let s = p.prefix.pop().unwrap();
        p.suffix.insert(0, s);
        p.repeated.rotate_right(1);
    }
    let mut expanded = out.clone();
    for q in out {
        for len in 1..q.repeated.len() {
            if q.repeated.len() % len != 0
                || !q
                    .repeated
                    .iter()
                    .enumerate()
                    .all(|(i, s)| *s == q.repeated[i % len])
            {
                continue;
            }
            let mut r = q.clone();
            let power = r.repeated.len() / len;
            r.repeated.truncate(len);
            r.factor *= power;
            r.constant *= power;
            expanded.insert(r.clone());
            while r.prefix.ends_with(&r.repeated) {
                r.prefix.truncate(r.prefix.len() - len);
                r.constant += 1;
                expanded.insert(r.clone());
            }
        }
    }
    expanded
        .into_iter()
        .filter(|p| normalize(p) == normal)
        .collect()
}

#[derive(Clone)]
struct Node {
    pattern: Pattern,
    steps: Arc<Trace>,
    depth: usize,
}

enum Trace {
    Leaf(Vec<Step>),
    Append(Arc<Trace>, Step),
    Join(Arc<Trace>, Arc<Trace>),
}

impl Node {
    fn push(&mut self, step: Step) {
        self.steps = Arc::new(Trace::Append(self.steps.clone(), step));
    }
}

fn flatten(trace: &Arc<Trace>) -> Vec<Step> {
    fn visit(t: &Arc<Trace>, seen: &mut BTreeSet<usize>, out: &mut Vec<Step>) {
        if !seen.insert(Arc::as_ptr(t) as usize) {
            return;
        }
        match t.as_ref() {
            Trace::Leaf(steps) => out.extend(steps.iter().cloned()),
            Trace::Append(parent, step) => {
                visit(parent, seen, out);
                out.push(step.clone());
            }
            Trace::Join(a, b) => {
                visit(a, seen, out);
                visit(b, seen, out);
            }
        }
    }
    let mut steps = Vec::new();
    visit(trace, &mut BTreeSet::new(), &mut steps);
    steps
}

fn equivalent(n: &Node, p: Pattern) -> Node {
    let mut n = n.clone();
    if n.pattern != p {
        assert_eq!(key(&n.pattern), key(&p));
        n.push(Step::Equivalent {
            result: p.clone(),
            premise: n.pattern.clone(),
        });
        n.pattern = p;
    }
    n
}

fn terminal(n: &Node) -> Option<SrsDerivationPatternProof> {
    for l in variants(&n.pattern.lhs) {
        for r in variants(&n.pattern.rhs) {
            if l.repeated.is_empty()
                || l.repeated != r.repeated
                || l.factor == 0
                || l.factor > r.factor
                || r.factor % l.factor != 0
                || l.constant.abs_diff(r.constant) % l.factor != 0
                || (l.factor == r.factor && l.constant > r.constant)
                || !r.prefix.ends_with(&l.prefix)
                || !r.suffix.starts_with(&l.suffix)
            {
                continue;
            }
            let p = Pattern {
                lhs: l.clone(),
                rhs: r.clone(),
            };
            let e = equivalent(n, p.clone());
            return Some(SrsDerivationPatternProof {
                steps: flatten(&e.steps),
                self_embedding: p,
                left_context: r.prefix[..r.prefix.len() - l.prefix.len()].to_vec(),
                right_context: r.suffix[l.suffix.len()..].to_vec(),
            });
        }
    }
    None
}

fn add(mut n: Node, step: Step, p: Pattern, out: &mut Vec<Node>) {
    n.push(step);
    n.pattern = p;
    n.depth += 1;
    out.push(n);
}

fn successors(n: &Node, rules: &[SrsOverlapClosure], seeds: &[Node]) -> Vec<Node> {
    let mut out = vec![];
    for rhs in variants(&n.pattern.rhs) {
        let p = Pattern {
            lhs: n.pattern.lhs.clone(),
            rhs,
        };
        let base = equivalent(n, p.clone());
        for rule in rules {
            if rule.lhs.is_empty() {
                continue;
            }
            for region in 0..3 {
                let part = match region {
                    0 => &p.rhs.prefix,
                    1 => &p.rhs.repeated,
                    _ => &p.rhs.suffix,
                };
                for pos in 0..=part.len().saturating_sub(rule.lhs.len()) {
                    if !part[pos..].starts_with(&rule.lhs) {
                        continue;
                    }
                    let left = part[..pos].to_vec();
                    let right = part[pos + rule.lhs.len()..].to_vec();
                    let mut q = p.clone();
                    let replacement = [left.clone(), rule.rhs.clone(), right.clone()].concat();
                    match region {
                        0 => q.rhs.prefix = replacement,
                        1 => q.rhs.repeated = replacement,
                        _ => q.rhs.suffix = replacement,
                    }
                    add(
                        base.clone(),
                        Step::Rewrite {
                            result: q.clone(),
                            premise: p.clone(),
                            closure: rule.clone(),
                            region,
                            left,
                            right,
                        },
                        q,
                        &mut out,
                    );
                }
            }
            // Boundary overlaps extend the SOURCE as well as the target.
            for k in 1..=rule.lhs.len().min(p.rhs.prefix.len()) {
                if rule.lhs[rule.lhs.len() - k..] != p.rhs.prefix[..k] {
                    continue;
                }
                let left = rule.lhs[..rule.lhs.len() - k].to_vec();
                let right = p.rhs.prefix[k..].to_vec();
                let mut q = p.clone();
                q.lhs.prefix = [left.clone(), q.lhs.prefix].concat();
                q.rhs.prefix = [rule.rhs.clone(), right.clone()].concat();
                add(
                    base.clone(),
                    Step::OverlapPatternPrefix {
                        result: q.clone(),
                        pattern: p.clone(),
                        closure: rule.clone(),
                        left,
                        right,
                        overlap: p.rhs.prefix[..k].to_vec(),
                    },
                    q,
                    &mut out,
                );
            }
            for k in 1..=rule.lhs.len().min(p.rhs.suffix.len()) {
                if p.rhs.suffix[p.rhs.suffix.len() - k..] != rule.lhs[..k] {
                    continue;
                }
                let left = p.rhs.suffix[..p.rhs.suffix.len() - k].to_vec();
                let right = rule.lhs[k..].to_vec();
                let mut q = p.clone();
                q.lhs.suffix.extend(right.clone());
                q.rhs.suffix = [left.clone(), rule.rhs.clone()].concat();
                add(
                    base.clone(),
                    Step::PatternOverlapSuffix {
                        result: q.clone(),
                        pattern: p.clone(),
                        closure: rule.clone(),
                        left,
                        right,
                        overlap: rule.lhs[..k].to_vec(),
                    },
                    q,
                    &mut out,
                );
            }
        }
        for seed in seeds {
            let s = &seed.pattern;
            if p.rhs.repeated != s.lhs.repeated
                || p.rhs.constant != s.lhs.constant
                || p.rhs.factor != s.lhs.factor
            {
                continue;
            }
            let (i, left) = if p.rhs.prefix.ends_with(&s.lhs.prefix) {
                (
                    1,
                    p.rhs.prefix[..p.rhs.prefix.len() - s.lhs.prefix.len()].to_vec(),
                )
            } else if s.lhs.prefix.ends_with(&p.rhs.prefix) {
                (
                    2,
                    s.lhs.prefix[..s.lhs.prefix.len() - p.rhs.prefix.len()].to_vec(),
                )
            } else {
                continue;
            };
            let (j, right) = if p.rhs.suffix.starts_with(&s.lhs.suffix) {
                (1, p.rhs.suffix[s.lhs.suffix.len()..].to_vec())
            } else if s.lhs.suffix.starts_with(&p.rhs.suffix) {
                (2, s.lhs.suffix[p.rhs.suffix.len()..].to_vec())
            } else {
                continue;
            };
            let mut q = Pattern {
                lhs: p.lhs.clone(),
                rhs: s.rhs.clone(),
            };
            if i == 1 {
                q.rhs.prefix = [left.clone(), q.rhs.prefix].concat();
            } else {
                q.lhs.prefix = [left.clone(), q.lhs.prefix].concat();
            }
            if j == 1 {
                q.rhs.suffix.extend(right.clone());
            } else {
                q.lhs.suffix.extend(right.clone());
            }
            let mut combined = base.clone();
            combined.steps = Arc::new(Trace::Join(combined.steps, seed.steps.clone()));
            add(
                combined,
                Step::Compose {
                    result: q.clone(),
                    first: p.clone(),
                    second: s.clone(),
                    kind: (i, j),
                    left,
                    right,
                },
                q,
                &mut out,
            );
        }
    }
    out
}

pub(super) fn search(trs: &Trs, deadline: Option<Instant>) -> Option<NonterminationProof> {
    search_with_closures(trs, deadline, 0)
}

pub(super) fn search_with_closures(
    trs: &Trs,
    deadline: Option<Instant>,
    rounds: usize,
) -> Option<NonterminationProof> {
    if trs.strategy() != RewriteStrategy::Full {
        return None;
    }
    let mut rules: Vec<_> = trs
        .srs_rules()?
        .into_iter()
        .map(|r| SrsOverlapClosure {
            lhs: r.lhs().to_vec(),
            rhs: r.rhs().to_vec(),
        })
        .collect();
    let mut original_steps: Vec<_> = rules
        .iter()
        .map(|r| Step::Original {
            closure: r.clone(),
            is_pair: false,
        })
        .collect();
    let mut closures = BTreeSet::new();
    for r in &rules {
        closures.insert((r.lhs.clone(), r.rhs.clone()));
    }
    let originals = rules.clone();
    let mut frontier = rules.clone();
    for _ in 0..rounds {
        let mut next = vec![];
        for a in &frontier {
            for b in &originals {
                if b.lhs.is_empty() {
                    continue;
                }
                let mut candidates = vec![];
                for k in 1..=a.rhs.len().min(b.lhs.len()) {
                    if a.rhs[a.rhs.len() - k..] != b.lhs[..k] {
                        continue;
                    }
                    let left = a.rhs[..a.rhs.len() - k].to_vec();
                    let right = b.lhs[k..].to_vec();
                    let result = SrsOverlapClosure {
                        lhs: [a.lhs.clone(), right.clone()].concat(),
                        rhs: [left.clone(), b.rhs.clone()].concat(),
                    };
                    candidates.push((result, left, right, Some(b.lhs[..k].to_vec())));
                }
                for pos in 0..=a.rhs.len().saturating_sub(b.lhs.len()) {
                    if !a.rhs[pos..].starts_with(&b.lhs) {
                        continue;
                    }
                    let left = a.rhs[..pos].to_vec();
                    let right = a.rhs[pos + b.lhs.len()..].to_vec();
                    let result = SrsOverlapClosure {
                        lhs: a.lhs.clone(),
                        rhs: [left.clone(), b.rhs.clone(), right.clone()].concat(),
                    };
                    candidates.push((result, left, right, None));
                }
                for (result, left, right, overlap) in candidates {
                    if result.lhs.len().max(result.rhs.len()) > 16
                        || closures.len() >= 64
                        || !closures.insert((result.lhs.clone(), result.rhs.clone()))
                    {
                        continue;
                    }
                    original_steps.push(Step::ComposeClosures {
                        result: result.clone(),
                        first: a.clone(),
                        second: b.clone(),
                        left,
                        right,
                        overlap,
                    });
                    next.push(result);
                }
            }
        }
        rules.extend(next.clone());
        frontier = next;
    }
    let original_steps = Arc::new(Trace::Leaf(original_steps));
    let mut seeds = vec![];
    for r in &rules {
        for k in 1..=r.lhs.len().min(r.rhs.len()) {
            for direction in 0..2 {
                let p = if direction == 0 && r.lhs[r.lhs.len() - k..] == r.rhs[..k] {
                    Pattern {
                        lhs: word(
                            vec![],
                            r.lhs[..r.lhs.len() - k].to_vec(),
                            r.rhs[..k].to_vec(),
                        ),
                        rhs: word(r.rhs[..k].to_vec(), r.rhs[k..].to_vec(), vec![]),
                    }
                } else if direction == 1 && r.lhs[..k] == r.rhs[r.rhs.len() - k..] {
                    Pattern {
                        lhs: word(r.lhs[..k].to_vec(), r.lhs[k..].to_vec(), vec![]),
                        rhs: word(
                            vec![],
                            r.rhs[..r.rhs.len() - k].to_vec(),
                            r.lhs[..k].to_vec(),
                        ),
                    }
                } else {
                    continue;
                };
                if p.lhs.repeated.is_empty() || p.rhs.repeated.is_empty() {
                    continue;
                }
                let step = if direction == 0 {
                    Step::OverlapIntoPatternLeft {
                        pattern: p.clone(),
                        closure: r.clone(),
                    }
                } else {
                    Step::OverlapIntoPatternRight {
                        pattern: p.clone(),
                        closure: r.clone(),
                    }
                };
                let mut n = Node {
                    pattern: p,
                    steps: Arc::new(Trace::Append(original_steps.clone(), step)),
                    depth: 0,
                };
                for _ in 0..3 {
                    for lhs in variants(&n.pattern.lhs) {
                        seeds.push(equivalent(
                            &n,
                            Pattern {
                                lhs,
                                rhs: n.pattern.rhs.clone(),
                            },
                        ));
                    }
                    let mut lifted = n.pattern.clone();
                    lifted.lhs.constant += lifted.lhs.factor;
                    lifted.rhs.constant += lifted.rhs.factor;
                    n.push(Step::Lift {
                        result: lifted.clone(),
                        premise: n.pattern.clone(),
                    });
                    n.pattern = lifted;
                }
            }
        }
    }
    let mut pending = BTreeSet::new();
    let mut queue: VecDeque<_> = seeds
        .iter()
        .filter(|n| pending.insert(key(&n.pattern)))
        .cloned()
        .collect();
    let mut seen = BTreeMap::new();
    while let Some(n) = queue.pop_front() {
        if deadline.is_some_and(|d| Instant::now() >= d) || seen.len() >= 30000 {
            break;
        }
        let k = key(&n.pattern);
        pending.remove(&k);
        if seen.contains_key(&k) {
            continue;
        }
        seen.insert(k, ());
        if let Some(proof) = terminal(&n) {
            return Some(NonterminationProof::SrsDerivationPatterns(proof));
        }
        if n.depth >= 10 {
            continue;
        }
        let mut next = successors(&n, &rules, &seeds);
        next.retain(|n| {
            let p = &n.pattern;
            [&p.lhs, &p.rhs].iter().all(|w| {
                w.prefix.len() + w.suffix.len() + w.repeated.len() * w.constant <= 20
                    && w.repeated.len() <= 8
            }) && !seen.contains_key(&key(p))
        });
        next.sort_by_key(|n| {
            n.pattern.lhs.prefix.len()
                + n.pattern.lhs.suffix.len()
                + n.pattern.rhs.prefix.len()
                + n.pattern.rhs.suffix.len()
        });
        queue.extend(next.into_iter().filter(|n| pending.insert(key(&n.pattern))));
        if queue.len() > 100000 {
            queue.truncate(100000);
            pending = queue.iter().map(|n| key(&n.pattern)).collect();
        }
    }
    None
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::cert::{CpfMode, write_cpf};
    use crate::proving::Proof;

    fn symbols(s: &str) -> Vec<Symbol> {
        s.chars().map(|c| Symbol::new(c.to_string())).collect()
    }
    fn term(s: &str) -> Term {
        s.chars()
            .rev()
            .fold(Term::var("x"), |t, c| Term::app(c.to_string(), vec![t]))
    }
    fn system(rules: &[(&str, &str)]) -> Trs {
        Trs::new(
            None,
            Default::default(),
            rules
                .iter()
                .map(|(l, r)| RewriteRule::new(term(l), term(r)))
                .collect(),
        )
    }

    #[test]
    fn rotations_and_power_collection_preserve_word_functions() {
        let p = SrsWordPattern {
            prefix: symbols("aa"),
            repeated: symbols("ba"),
            factor: 2,
            constant: 1,
            suffix: symbols("babz"),
        };
        let eval = |w: &SrsWordPattern, n| {
            [
                w.prefix.clone(),
                (0..w.factor * n + w.constant)
                    .flat_map(|_| w.repeated.clone())
                    .collect(),
                w.suffix.clone(),
            ]
            .concat()
        };
        for v in variants(&p) {
            for n in 0..8 {
                assert_eq!(eval(&p, n), eval(&v, n));
            }
        }
        let p = word(symbols("c"), symbols("aa"), symbols("a"));
        assert!(
            variants(&p)
                .iter()
                .any(|v| v.repeated == symbols("a") && v.factor == 2)
        );
    }

    #[test]
    fn symbolic_closure_is_renaming_independent_and_checks_with_ceta() {
        let original = [
            ("abc", "cba"),
            ("ac", "aada"),
            ("dab", "bad"),
            ("dac", "bcc"),
        ];
        for alphabet in ["abcd", "zyxw"] {
            let rename = |s: &str| {
                s.bytes()
                    .map(|b| alphabet.as_bytes()[(b - b'a') as usize] as char)
                    .collect::<String>()
            };
            let renamed: Vec<_> = original
                .iter()
                .map(|(l, r)| (rename(l), rename(r)))
                .collect();
            let trs = system(
                &renamed
                    .iter()
                    .map(|(l, r)| (l.as_str(), r.as_str()))
                    .collect::<Vec<_>>(),
            );
            let proof = search(&trs, Some(Instant::now() + Duration::from_secs(10)))
                .expect("symbolic pump");
            let xml =
                write_cpf(&trs, &Proof::nonterminating(proof.clone()), CpfMode::Cpf30).unwrap();
            let Some(ceta) = std::env::var_os("CETA_CSR_BIN") else {
                continue;
            };
            let path = std::env::temp_dir().join(format!(
                "ferrum-pattern-{alphabet}-{}.xml",
                std::process::id()
            ));
            std::fs::write(&path, &xml).unwrap();
            let output = std::process::Command::new(&ceta)
                .arg(&path)
                .output()
                .unwrap();
            assert!(
                output.status.success(),
                "{}",
                String::from_utf8_lossy(&output.stdout)
            );
            let NonterminationProof::SrsDerivationPatterns(mut bad) = proof else {
                unreachable!()
            };
            bad.self_embedding.rhs.prefix.push(Symbol::new("absent"));
            let xml = write_cpf(
                &trs,
                &Proof::nonterminating(NonterminationProof::SrsDerivationPatterns(bad)),
                CpfMode::Cpf30,
            )
            .unwrap();
            std::fs::write(&path, xml).unwrap();
            let output = std::process::Command::new(&ceta)
                .arg(&path)
                .output()
                .unwrap();
            assert!(!output.status.success(), "mutated pattern must not certify");
            std::fs::remove_file(path).unwrap();
        }
    }

    #[test]
    fn symbolic_closure_respects_deadline_and_rejects_decreasing_systems() {
        let trs = system(&[("aa", "a"), ("ab", "b")]);
        assert!(search(&trs, Some(Instant::now() + Duration::from_secs(2))).is_none());
        let trs = system(&[
            ("abc", "cba"),
            ("ac", "aada"),
            ("dab", "bad"),
            ("dac", "bcc"),
        ]);
        assert!(search(&trs, Some(Instant::now())).is_none());
    }
}
