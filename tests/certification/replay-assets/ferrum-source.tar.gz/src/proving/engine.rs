use std::collections::{BTreeMap, BTreeSet};
use std::fmt;
use std::time::{Duration, Instant};

#[cfg(test)]
use crate::cert::write_csr_input_cpf4;
use crate::cert::{write_relative_trs_input_cpf3, write_trs_input_cpf3};
use crate::core::{CsrTrs, RelativeTrs, RewriteStrategy, Trs};
use crate::llm::{LlmClient, LlmProposal, UtilityGuidanceLookup};

use super::dependency_pairs::{
    DpArgumentFilter, DpPathOrderKind, DpStrategy, SlArithmeticFunction,
};
#[cfg(test)]
use super::processors::csr::polynomial::{
    csr_linear_polynomial_is_mu_monotone, synthesize_csr_linear_polynomial_removal,
};
use super::processors::csr::recognition::looks_like_standard_transformed_csr;
#[cfg(test)]
use super::processors::relative::{
    close_relative as flat_context_close_relative, find_relative_loop as prove_relative_loop,
};
#[cfg(test)]
use super::processors::rewrite_analysis::{
    critical_pairs, is_overlay_trs, switch_innermost_wcr_depth, weakly_confluent_by_join_bfs,
};
#[cfg(test)]
use super::processors::top_level::kbo::{
    synthesize_top_level_kbo, top_level_kbo_gt, top_precedence_rank_refs,
};
#[cfg(test)]
use super::processors::top_level::path_order::{
    checked_top_level_path_order_removal_with_ranks,
    synthesize_top_level_path_order_removal_with_deadline,
    top_level_path_order_permutation_filter_entries_by_symbol, top_level_path_order_smt_script,
};
#[cfg(test)]
use super::processors::top_level::polynomial::synthesize_top_level_polynomial_removal_with_smt;
use super::processors::top_level::srs::{
    SrsMatchAtBound, SrsRfcBarrenClosure, cons_encoded_srs_rules,
};
#[cfg(test)]
use super::processors::top_level::srs::{
    SrsMatchAutomatonBuilder, SrsMatchPath, SrsMatchWordIndex, SrsRfcBarrenBuilder,
    complete_srs_match_bounds_automaton_for_initial_words, complete_srs_match_bounds_completion,
    complete_srs_rfc_match_bounds_completion_for_initial_words, match_bounds_weak_rhs_height,
    prove_srs_by_match_bounds_completion, prove_srs_by_reversal_match_bounds_completion,
    prove_srs_by_rfc_match_bounds_with_limits, srs_relative_match_bounds_candidate_batches,
    srs_rfc_initial_words,
};
pub(crate) use super::processors::top_level::uncurrying::infer_uncurrying_application_symbol;
use super::processors::{CsrProblemState, CsrProofBoundary, ProblemCertificate, ProblemState};
pub(crate) use super::processors::{
    standardized_csr_input_cpf4, standardized_relative_trs_input_cpf3, standardized_trs_input_cpf3,
};
use super::{
    BoundsProof, DpOptions, NonterminationStrategy, NonterminationStrategyProcessor, Proof,
    ProofStep,
};

const DEFAULT_PROVE_STRATEGY_SOURCE: &str = include_str!("../../strategies/default.fs");
const DEFAULT_SRS_WEIGHT_MAX: i64 = 64;
const DEFAULT_SRS_MATCH_BOUND_MAX: usize = usize::MAX;
const DEFAULT_SRS_MATCH_BOUNDS_MAX_STATES: usize = usize::MAX;
const DEFAULT_SRS_MATCH_BOUNDS_MAX_TRANSITIONS: usize = usize::MAX;
const DEFAULT_SRS_RFC_MAX_WORDS: usize = usize::MAX;
const DEFAULT_SRS_RFC_MAX_WORD_LEN: usize = usize::MAX;

#[derive(Clone, Debug)]
pub struct ProveOptions {
    pub strategy: ProveStrategy,
    pub llm_first: bool,
    pub llm_proposals: Vec<LlmProposal>,
    pub llm_client: Option<LlmClient>,
    pub utility_guidance: Option<UtilityGuidanceLookup>,
    pub llm_iterations: usize,
    pub synthesize_kbo: bool,
    pub max_symbol_weight: i64,
    pub max_synthesis_symbols: usize,
    pub synthesize_smt_polynomial: bool,
    pub synthesize_path_order: bool,
    pub max_polynomial_constant: i64,
    pub max_polynomial_coefficient: i64,
    pub max_polynomial_symbols: usize,
    pub max_polynomial_arity: usize,
    pub dependency_pairs: bool,
    pub dp_options: DpOptions,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub enum ProveStrategy {
    Processor(ProveStrategyProcessor),
    Sequence(Vec<ProveStrategy>),
    Choice(Vec<ProveStrategy>),
    Parallel(Vec<ProveStrategy>),
    Conditional {
        condition: ProveStrategyCondition,
        then_strategy: Box<ProveStrategy>,
        else_strategy: Box<ProveStrategy>,
    },
    Timeout {
        duration: Duration,
        strategy: Box<ProveStrategy>,
    },
    Delay {
        duration: Duration,
        strategy: Box<ProveStrategy>,
    },
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub enum ProveStrategyCondition {
    Csr,
    Relative,
    TransformedCsr,
    Standard,
    Innermost,
    Outermost,
    Applicative,
    StrictSrs,
    UnarySrs,
    Srs,
    RulesAtLeast(usize),
    RulesAtMost(usize),
    Not(Box<ProveStrategyCondition>),
    All(Vec<ProveStrategyCondition>),
    Any(Vec<ProveStrategyCondition>),
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub enum ProveStrategyProcessor {
    Fail,
    ExactTerminationProof {
        source_trs_input_xml: String,
        termination_proof_xml: String,
    },
    ExactNonterminationProof {
        source_trs_input_xml: String,
        nontermination_proof_xml: String,
    },
    ExactNonterminationTerminal {
        source_trs_input_xml: String,
        terminal_xml: String,
    },
    ExactNonterminationRuleRemoval {
        source_trs_input_xml: String,
        residual_trs_input_xml: String,
    },
    /// A complete, certified linear chain of exact top-level rule-removal
    /// witnesses.  This is reconstructed from a CPF only when the proof has
    /// no branching or intervening transformation.
    CertifiedLinearSequence(Vec<ProveStrategyProcessor>),
    NonterminationSearch,
    Nontermination(NonterminationStrategyProcessor),
    RemoveNonApplicableRules,
    StringReversal,
    SrsStripContexts {
        max_prefix: Option<usize>,
        max_suffix: Option<usize>,
    },
    NativeConstantToUnary,
    ConstantToUnary {
        variable: String,
        renaming: BTreeMap<String, String>,
    },
    SrsLength,
    SrsWeightedLength {
        max_weight: i64,
    },
    SrsWeightedRuleRemoval {
        max_weight: i64,
    },
    SrsCanonicalWeightRemoval { max_weight: i64 },
    SrsCompactWeightRemoval { max_weight: i64 },
    SrsCanonicalCompactWeightRemoval { max_weight: i64 },
    SrsSummedWeightRemoval { max_weight: i64 },
    SrsLinearWeightRemoval { max_weight: i64 },
    SrsLpWeightRemoval { max_weight: i64, all_strict: bool, maximal: bool },
    SrsMatchBounds {
        max_bound: usize,
        max_states: usize,
        max_transitions: usize,
    },
    /// A retained match-bounds automaton replayed exactly and checked against
    /// the live SRS before proof construction.
    ExactSrsMatchBounds {
        proof: BoundsProof,
    },
    /// A retained relative match-bounds automaton and the strict rules it
    /// deletes, replayed exactly against the live SRS.
    ExactSrsRelativeMatchBounds {
        proof: BoundsProof,
        removed_indices: Vec<usize>,
    },
    SrsRelativeMatchBounds {
        max_bound: usize,
        max_states: usize,
        max_transitions: usize,
    },
    SrsRelativeMatchBoundsRemoval {
        max_bound: usize,
        max_states: usize,
        max_transitions: usize,
    },
    SrsRfcMatchBounds {
        max_bound: usize,
        max_words: usize,
        max_word_len: usize,
        max_states: usize,
        max_transitions: usize,
        at_bound: SrsMatchAtBound,
        closure: SrsRfcBarrenClosure,
    },
    SrsRfcRelativeMatchBounds {
        allow_partial: bool,
        absolute_residual: bool,
        layered_seconds: u64,
        fresh_seconds: u64,
        min_bound: usize,
        max_bound: usize,
        max_words: usize,
        max_word_len: usize,
        max_states: usize,
        max_transitions: usize,
        at_bound: SrsMatchAtBound,
        closure: SrsRfcBarrenClosure,
    },
    LinearPolynomial {
        max_constant: i64,
        max_coefficient: i64,
        max_symbols: Option<usize>,
        max_arity: Option<usize>,
    },
    SelectedLinearPolynomial {
        max_constant: i64,
        max_coefficient: i64,
        max_symbols: Option<usize>,
        max_arity: Option<usize>,
        candidate_index: usize,
    },
    TargetLinearPolynomial {
        max_constant: i64,
        max_coefficient: i64,
        max_symbols: Option<usize>,
        max_arity: Option<usize>,
        strict_rule_indices: Vec<usize>,
    },
    MinimumDeletionLinearPolynomial {
        max_constant: i64,
        max_coefficient: i64,
        max_symbols: Option<usize>,
        max_arity: Option<usize>,
        min_delete: usize,
        residual_budget: usize,
    },
    /// A certified linear polynomial model replayed exactly and revalidated
    /// against the live rules before any proof node is constructed.
    ExactLinearPolynomial {
        interpretation: Vec<(String, i64, Vec<i64>)>,
    },
    ExactLinearPolynomialRemoval {
        interpretation: Vec<(String, i64, Vec<i64>)>,
        removed_rule_indices: Vec<usize>,
    },
    /// One source-bound polynomial/KBO action, never a strategy or proof chain.
    ExactSourceBoundOrder {
        source_trs_input_xml: String,
        order_atom: String,
    },
    SmtLinearPolynomial {
        max_constant: i64,
        max_coefficient: i64,
        max_symbols: Option<usize>,
        max_arity: Option<usize>,
    },
    MatrixInterpretation {
        dimension: usize,
        max_constant: i64,
        max_coefficient: i64,
        max_symbols: Option<usize>,
        max_arity: Option<usize>,
    },
    IntegerMatrixInterpretation {
        dimension: usize,
        min_value: i64,
        max_value: i64,
        max_symbols: Option<usize>,
        max_arity: Option<usize>,
    },
    /// A certified natural matrix model replayed exactly and revalidated
    /// against the live CSR rules and replacement map.
    ExactMatrixInterpretation {
        interpretation: Vec<(String, Vec<i64>, Vec<Vec<Vec<i64>>>)>,
    },
    /// A certified ordinary integer-matrix model replayed exactly on a
    /// relative TRS and revalidated before proof construction.
    ExactIntegerMatrixInterpretation {
        interpretation: Vec<(String, Vec<i64>, Vec<Vec<Vec<i64>>>)>,
    },
    Kbo {
        max_weight: i64,
        max_symbols: usize,
    },
    /// A synthesized KBO witness replayed and checked exactly on the live
    /// rules before exposing the residual system.
    ExactKbo {
        precedence: Vec<String>,
        precedence_ranks: BTreeMap<String, usize>,
        weights: BTreeMap<String, i64>,
    },
    PathOrder {
        max_symbols: usize,
    },
    SharedPathOrder { max_symbols: usize },
    /// A synthesized path-order witness replayed and checked exactly on the
    /// live rules before exposing the residual system.
    ExactPathOrder {
        statuses: BTreeMap<String, DpPathOrderKind>,
        precedence: Vec<String>,
        precedence_ranks: BTreeMap<String, usize>,
        argument_filter: DpArgumentFilter,
    },
    /// Replay a certified path-order witness while deleting exactly the
    /// selected live rules.
    ExactPathOrderRemoval {
        source_trs_input_xml: Option<String>,
        statuses: BTreeMap<String, DpPathOrderKind>,
        precedence: Vec<String>,
        precedence_ranks: BTreeMap<String, usize>,
        argument_filter: DpArgumentFilter,
        removed_rule_indices: Vec<usize>,
    },
    /// Close a relative TRS under all flat one-hole contexts and prove the
    /// resulting ordinary union TRS.  This is a first-class atom so certified
    /// relative proofs can replay the transformation without entering the
    /// broad fallback portfolio.
    RelativeFlatContextClosure,
    SrsContextClosure { depth: usize },
    SrsShiftLabeling { memory: usize },
    SrsWeightedLabeling { carrier_size: usize, max_weight: usize, strict_percent: usize },
    TrsRootLabeling,
    /// The IJCAR 2024 annotated dependency-pair framework for full relative
    /// termination.  Kept as a first-class atom so it can be timed and
    /// benchmarked independently of the surrounding relative portfolio.
    RelativeAnnotatedDependencyPairs,
    /// Synthesize one finite relative semantic-labeling model and expose the
    /// labeled relative TRS as a worklist residual.
    RelativeSemanticLabeling {
        carrier_size: usize,
    },
    /// Replay the certified finite model selected by a relative semantic-
    /// labeling proof.  The model is checked against the live relative TRS
    /// before the labeled ordinary child is handed back to oracle guidance.
    ExactRelativeSemanticLabeling {
        carrier_size: usize,
        interpretations: Vec<(String, usize, SlArithmeticFunction)>,
    },
    OutermostRaffelsieperZantema,
    SwitchContextSensitive,
    Gm04InverseContextSensitive,
    Gm04InverseContextSensitiveFull,
    CsrLoop,
    CsrInnermostEquivalence,
    CsrInnermostEquivalenceWithStrategy(DpStrategy),
    CsrInnermostRta08Equivalence,
    /// Orthogonal CSR-to-innermost-RTA08 transformation with an explicit
    /// state-local DP continuation.
    CsrInnermostRta08EquivalenceWithStrategy(DpStrategy),
    SwitchInnermost,
    AaeccInnermost,
    Uncurry,
    UncurryRole { role: usize },
    SafeCsrDependencyPairs,
    ImprovedCsrDependencyPairs,
    MutermUnhidingCsrDependencyPairs,
    MutermExpandedCsrDependencyPairs,
    InnermostCsrDependencyPairs,
    Rta08CsrDependencyPairs,
    NativeContextSensitiveCsrDependencyPairs,
    NativeOrdinaryCsrDependencyPairs,
    ConservativeCsrDependencyPairs,
    CsrGmTransformation,
    DependencyPairs,
    /// Native Q = lhs(R) initialization for nontermination, preserving NFS.
    InnermostLhssDependencyPairs,
    /// Replay the exact dependency-pair set from a certified CPF dpTrans.
    /// The child remains an ordinary independently guided DP state.
    ExactDependencyPairs {
        dp_input_xml: String,
    },
    /// Certified Q-increase plus DP transformation for nontermination.  The
    /// resulting DP problem is still a first-class worklist residual.
    ExactInnermostLhssDependencyPairs {
        dp_input_xml: String,
    },
    /// Ordinary dependency-pair transformation with a state-local recursive
    /// continuation.  This restores executable `dp(...)` recipes without
    /// hiding any residual state from the universal worklist.
    DependencyPairsWithStrategy(DpStrategy),
    /// CeTA DP_list root construction, omitting LHS proper-subterm calls.
    TrimmedDependencyPairs,
    TrimmedDependencyPairsWithStrategy(DpStrategy),
    /// GM CSR transformation followed by an explicit recursive DP recipe.
    CsrGmTransformationWithStrategy(DpStrategy),
    SafeCsrDependencyPairsWithStrategy(DpStrategy),
    ImprovedCsrDependencyPairsWithStrategy(DpStrategy),
    MutermUnhidingCsrDependencyPairsWithStrategy(DpStrategy),
    MutermExpandedCsrDependencyPairsWithStrategy(DpStrategy),
    InnermostCsrDependencyPairsWithStrategy(DpStrategy),
    Rta08CsrDependencyPairsWithStrategy(DpStrategy),
    NativeContextSensitiveCsrDependencyPairsWithStrategy(DpStrategy),
    NativeOrdinaryCsrDependencyPairsWithStrategy(DpStrategy),
    ConservativeCsrDependencyPairsWithStrategy(DpStrategy),
}

impl ProveStrategy {
    pub fn with_timeout_multiplier(&self, multiplier: f64) -> Self {
        match self {
            Self::Processor(processor) => {
                Self::Processor(processor.with_timeout_multiplier(multiplier))
            }
            Self::Sequence(strategies) => Self::Sequence(
                strategies
                    .iter()
                    .map(|strategy| strategy.with_timeout_multiplier(multiplier))
                    .collect(),
            ),
            Self::Choice(strategies) => Self::Choice(
                strategies
                    .iter()
                    .map(|strategy| strategy.with_timeout_multiplier(multiplier))
                    .collect(),
            ),
            Self::Parallel(strategies) => Self::Parallel(
                strategies
                    .iter()
                    .map(|strategy| strategy.with_timeout_multiplier(multiplier))
                    .collect(),
            ),
            Self::Conditional {
                condition,
                then_strategy,
                else_strategy,
            } => Self::Conditional {
                condition: condition.clone(),
                then_strategy: Box::new(then_strategy.with_timeout_multiplier(multiplier)),
                else_strategy: Box::new(else_strategy.with_timeout_multiplier(multiplier)),
            },
            Self::Timeout { duration, strategy } => Self::Timeout {
                duration: scale_strategy_duration(*duration, multiplier),
                strategy: Box::new(strategy.with_timeout_multiplier(multiplier)),
            },
            Self::Delay { duration, strategy } => Self::Delay {
                duration: *duration,
                strategy: Box::new(strategy.with_timeout_multiplier(multiplier)),
            },
        }
    }
}

impl ProveStrategyProcessor {
    fn with_timeout_multiplier(&self, _multiplier: f64) -> Self {
        match self {
            _ => self.clone(),
        }
    }
}

fn scale_strategy_duration(duration: Duration, multiplier: f64) -> Duration {
    if multiplier == 1.0 {
        return duration;
    }
    let scaled = duration.as_secs_f64() * multiplier;
    if duration.is_zero() || scaled <= 0.0 {
        return Duration::ZERO;
    }
    Duration::from_secs_f64(scaled.max(0.001))
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct ProveStrategyParseError {
    message: String,
}

impl fmt::Display for ProveStrategyParseError {
    fn fmt(&self, formatter: &mut fmt::Formatter<'_>) -> fmt::Result {
        formatter.write_str(&self.message)
    }
}

impl std::error::Error for ProveStrategyParseError {}

impl ProveStrategy {
    pub fn parse(input: &str) -> Result<Self, ProveStrategyParseError> {
        ProveStrategyParser::new(input).parse()
    }

    pub fn default_from_file() -> Self {
        Self::parse(DEFAULT_PROVE_STRATEGY_SOURCE)
            .expect("checked-in default Ferrum strategy must parse")
    }
}

struct ProveStrategyParser<'a> {
    input: &'a str,
    definitions: BTreeMap<String, ProveStrategy>,
}

impl<'a> ProveStrategyParser<'a> {
    fn new(input: &'a str) -> Self {
        Self {
            input,
            definitions: BTreeMap::new(),
        }
    }

    fn parse(mut self) -> Result<ProveStrategy, ProveStrategyParseError> {
        let statements = split_top_level(self.input.trim(), ';');
        let mut body_start = 0usize;
        for (index, statement) in statements.iter().enumerate() {
            let statement = statement.trim();
            if statement.is_empty() {
                body_start = index + 1;
                continue;
            }
            let Some((name, value)) = parse_strategy_definition(statement)? else {
                break;
            };
            let strategy = self.parse_choice(value.trim())?;
            self.definitions.insert(name, strategy);
            body_start = index + 1;
        }
        let body = statements[body_start..]
            .iter()
            .map(|statement| statement.trim())
            .filter(|statement| !statement.is_empty())
            .collect::<Vec<_>>()
            .join("; ");
        if body.is_empty() {
            return Err(prove_strategy_parse_error("strategy body is empty"));
        }
        self.parse_choice(&body)
    }

    fn parse_choice(&self, input: &str) -> Result<ProveStrategy, ProveStrategyParseError> {
        let parts = split_top_level(input, '|');
        if parts.len() > 1 {
            return Ok(ProveStrategy::Choice(
                parts
                    .into_iter()
                    .map(|part| self.parse_sequence(part.trim()))
                    .collect::<Result<Vec<_>, _>>()?,
            ));
        }
        self.parse_sequence(input)
    }

    fn parse_sequence(&self, input: &str) -> Result<ProveStrategy, ProveStrategyParseError> {
        let mut parts = split_top_level(input, ';');
        if parts.len() == 1 {
            parts = split_top_level(input, ',');
        }
        let strategies = parts
            .into_iter()
            .map(str::trim)
            .filter(|part| !part.is_empty())
            .map(|part| self.parse_atom(part))
            .collect::<Result<Vec<_>, _>>()?;
        match strategies.as_slice() {
            [] => Err(prove_strategy_parse_error("empty strategy")),
            [strategy] => Ok(strategy.clone()),
            _ => Ok(ProveStrategy::Sequence(strategies)),
        }
    }

    fn parse_atom(&self, input: &str) -> Result<ProveStrategy, ProveStrategyParseError> {
        let raw_input = input.trim();
        let input = strip_outer_parentheses(raw_input);
        if input != raw_input
            && (split_top_level(input, '|').len() > 1
                || split_top_level(input, ';').len() > 1
                || split_top_level(input, ',').len() > 1)
        {
            return self.parse_choice(input);
        }
        if let Some(strategy) = self.definitions.get(&input.to_ascii_lowercase()) {
            return Ok(strategy.clone());
        }
        if let Some(inner) = function_arguments(input, "timeout") {
            let args = split_top_level(inner, ',');
            if args.len() != 2 {
                return Err(prove_strategy_parse_error(
                    "timeout expects duration and strategy",
                ));
            }
            return Ok(ProveStrategy::Timeout {
                duration: parse_strategy_duration(args[0].trim())?,
                strategy: Box::new(self.parse_choice(args[1].trim())?),
            });
        }
        if let Some(inner) = function_arguments(input, "delay") {
            let args = split_top_level(inner, ',');
            if args.len() != 2 {
                return Err(prove_strategy_parse_error(
                    "delay expects duration and strategy",
                ));
            }
            return Ok(ProveStrategy::Delay {
                duration: parse_strategy_duration(args[0].trim())?,
                strategy: Box::new(self.parse_choice(args[1].trim())?),
            });
        }
        if let Some(inner) = function_arguments(input, "parallel") {
            return Ok(ProveStrategy::Parallel(parse_parallel_arguments(
                self, inner,
            )?));
        }
        if let Some(inner) = function_arguments(input, "if") {
            let args = split_top_level(inner, ',');
            if args.len() != 3 {
                return Err(prove_strategy_parse_error(
                    "if expects condition, then strategy, and else strategy",
                ));
            }
            return Ok(ProveStrategy::Conditional {
                condition: parse_prove_strategy_condition(args[0].trim())?,
                then_strategy: Box::new(self.parse_choice(args[1].trim())?),
                else_strategy: Box::new(self.parse_choice(args[2].trim())?),
            });
        }
        if let Some(inner) = function_arguments(input, "nontermination") {
            let parsed = NonterminationStrategy::parse(inner)
                .map_err(|error| prove_strategy_parse_error(error.to_string()))?;
            let NonterminationStrategy::Processor(processor) = parsed else {
                return Err(prove_strategy_parse_error(
                    "nontermination(...) accepts exactly one processor; compose top-level atoms instead",
                ));
            };
            return Ok(ProveStrategy::Processor(
                ProveStrategyProcessor::Nontermination(processor),
            ));
        }
        if let Some(inner) = function_arguments(input, "dp-trimmed") {
            let strategy = DpStrategy::parse(inner)
                .map_err(|error| prove_strategy_parse_error(error.to_string()))?;
            return Ok(ProveStrategy::Processor(
                ProveStrategyProcessor::TrimmedDependencyPairsWithStrategy(strategy),
            ));
        }
        if let Some(inner) = function_arguments(input, "dp")
            .or_else(|| function_arguments(input, "dependency-pairs"))
        {
            let strategy = DpStrategy::parse(inner)
                .map_err(|error| prove_strategy_parse_error(error.to_string()))?;
            return Ok(ProveStrategy::Processor(
                ProveStrategyProcessor::DependencyPairsWithStrategy(strategy),
            ));
        }
        if let Some(inner) = function_arguments(input, "csr-innermost-rta08")
            .or_else(|| function_arguments(input, "csr-innermost-rta08-equivalence"))
        {
            let strategy = DpStrategy::parse(inner)
                .map_err(|error| prove_strategy_parse_error(error.to_string()))?;
            return Ok(ProveStrategy::Processor(
                ProveStrategyProcessor::CsrInnermostRta08EquivalenceWithStrategy(strategy),
            ));
        }
        if let Some(inner) = function_arguments(input, "csr-innermost")
            .or_else(|| function_arguments(input, "csr-innermost-equivalence"))
        {
            let strategy = DpStrategy::parse(inner)
                .map_err(|error| prove_strategy_parse_error(error.to_string()))?;
            return Ok(ProveStrategy::Processor(
                ProveStrategyProcessor::CsrInnermostEquivalenceWithStrategy(strategy),
            ));
        }
        if let Some(inner) = function_arguments(input, "csr-gm-transform")
            .or_else(|| function_arguments(input, "gm-csr-transform"))
        {
            let strategy = DpStrategy::parse(inner)
                .map_err(|error| prove_strategy_parse_error(error.to_string()))?;
            return Ok(ProveStrategy::Processor(
                ProveStrategyProcessor::CsrGmTransformationWithStrategy(strategy),
            ));
        }
        for (names, make) in [
            (
                &["csr-safe-dp", "safe-csr-dp"][..],
                ProveStrategyProcessor::SafeCsrDependencyPairsWithStrategy
                    as fn(DpStrategy) -> ProveStrategyProcessor,
            ),
            (
                &["csr-improved-dp", "improved-csr-dp"][..],
                ProveStrategyProcessor::ImprovedCsrDependencyPairsWithStrategy,
            ),
            (
                &["csr-muterm-unhiding", "muterm-unhiding-csr-dp"][..],
                ProveStrategyProcessor::MutermUnhidingCsrDependencyPairsWithStrategy,
            ),
            (
                &["csr-muterm-expanded", "muterm-expanded-csr-dp"][..],
                ProveStrategyProcessor::MutermExpandedCsrDependencyPairsWithStrategy,
            ),
            (
                &["csr-innermost-dp", "innermost-csr-dp"][..],
                ProveStrategyProcessor::InnermostCsrDependencyPairsWithStrategy,
            ),
            (
                &["csr-rta08-dp", "rta08-csr-dp"][..],
                ProveStrategyProcessor::Rta08CsrDependencyPairsWithStrategy,
            ),
            (
                &["csr-native-dp", "native-csr-dp"][..],
                ProveStrategyProcessor::NativeContextSensitiveCsrDependencyPairsWithStrategy,
            ),
            (
                &["csr-native-ordinary-dp", "native-ordinary-csr-dp"][..],
                ProveStrategyProcessor::NativeOrdinaryCsrDependencyPairsWithStrategy,
            ),
            (
                &["csr-conservative-dp", "conservative-csr-dp"][..],
                ProveStrategyProcessor::ConservativeCsrDependencyPairsWithStrategy,
            ),
        ] {
            if let Some(inner) = names
                .iter()
                .find_map(|name| function_arguments(input, name))
            {
                let strategy = DpStrategy::parse(inner)
                    .map_err(|error| prove_strategy_parse_error(error.to_string()))?;
                return Ok(ProveStrategy::Processor(make(strategy)));
            }
        }
        if let Some(inner) =
            function_arguments(input, "poly").or_else(|| function_arguments(input, "polynomial"))
        {
            let (max_constant, max_coefficient, max_symbols, max_arity) =
                parse_top_level_polynomial_bounds(inner, "poly")?;
            let candidate_index = if inner.contains('=') {
                NamedProveStrategyArgs::parse(&split_top_level(inner, ','), "poly")?
                    .optional_usize(
                        &["candidate", "candidate-index", "candidate_index"],
                        "candidate index",
                    )?
            } else {
                None
            };
            return Ok(ProveStrategy::Processor(match candidate_index {
                Some(candidate_index) => ProveStrategyProcessor::SelectedLinearPolynomial {
                    max_constant,
                    max_coefficient,
                    max_symbols,
                    max_arity,
                    candidate_index,
                },
                None => ProveStrategyProcessor::LinearPolynomial {
                    max_constant,
                    max_coefficient,
                    max_symbols,
                    max_arity,
                },
            }));
        }
        if let Some(inner) = function_arguments(input, "poly-target") {
            let (max_constant, max_coefficient, max_symbols, max_arity) =
                parse_top_level_polynomial_bounds(inner, "poly-target")?;
            let args = split_top_level(inner, ',');
            let named = NamedProveStrategyArgs::parse(&args, "poly-target")?;
            let strict_rule_indices = named
                .value(
                    &["strict", "strict-rules", "strict_rules"],
                    "strict rule indices",
                )?
                .split('+')
                .map(|index| {
                    index
                        .parse::<usize>()
                        .map_err(|_| prove_strategy_parse_error("invalid strict rule index"))
                })
                .collect::<Result<Vec<_>, _>>()?;
            if strict_rule_indices.is_empty() {
                return Err(prove_strategy_parse_error(
                    "polynomial target must delete at least one rule",
                ));
            }
            return Ok(ProveStrategy::Processor(
                ProveStrategyProcessor::TargetLinearPolynomial {
                    max_constant,
                    max_coefficient,
                    max_symbols,
                    max_arity,
                    strict_rule_indices,
                },
            ));
        }
        if let Some(inner) = function_arguments(input, "poly-min-delete") {
            let (max_constant, max_coefficient, max_symbols, max_arity) =
                parse_top_level_polynomial_bounds(inner, "poly-min-delete")?;
            let args = split_top_level(inner, ',');
            let named = NamedProveStrategyArgs::parse(&args, "poly-min-delete")?;
            let min_delete = named
                .value(&["min-delete", "min_delete"], "minimum deletion count")?
                .parse::<usize>()
                .map_err(|_| prove_strategy_parse_error("invalid minimum deletion count"))?;
            let residual_budget = named
                .value(&["residual-budget", "residual_budget"], "residual budget")?
                .parse::<usize>()
                .map_err(|_| prove_strategy_parse_error("invalid residual budget"))?;
            if min_delete == 0 || residual_budget != 1 {
                return Err(prove_strategy_parse_error(
                    "poly-min-delete requires min-delete > 0 and residual-budget=1",
                ));
            }
            return Ok(ProveStrategy::Processor(
                ProveStrategyProcessor::MinimumDeletionLinearPolynomial {
                    max_constant,
                    max_coefficient,
                    max_symbols,
                    max_arity,
                    min_delete,
                    residual_budget,
                },
            ));
        }
        if let Some(inner) = function_arguments(input, "exact-poly") {
            let args = split_top_level(inner, ',');
            let named = NamedProveStrategyArgs::parse(&args, "exact-poly")?;
            let encoded = named.value(&["hex"], "hex-encoded polynomial witness")?;
            if encoded.len() % 2 != 0 || !encoded.bytes().all(|byte| byte.is_ascii_hexdigit()) {
                return Err(prove_strategy_parse_error(
                    "exact-poly hex witness must contain an even number of hexadecimal digits",
                ));
            }
            let bytes = encoded
                .as_bytes()
                .chunks_exact(2)
                .map(|digits| {
                    let text = std::str::from_utf8(digits).map_err(|_| {
                        prove_strategy_parse_error("invalid exact-poly hex witness")
                    })?;
                    u8::from_str_radix(text, 16)
                        .map_err(|_| prove_strategy_parse_error("invalid exact-poly hex witness"))
                })
                .collect::<Result<Vec<_>, _>>()?;
            let interpretation: Vec<(String, i64, Vec<i64>)> = serde_json::from_slice(&bytes)
                .map_err(|_| prove_strategy_parse_error("invalid exact-poly polynomial witness"))?;
            if interpretation.is_empty() {
                return Err(prove_strategy_parse_error(
                    "exact-poly polynomial witness must not be empty",
                ));
            }
            return Ok(ProveStrategy::Processor(
                ProveStrategyProcessor::ExactLinearPolynomial { interpretation },
            ));
        }
        if let Some(inner) = function_arguments(input, "exact-trs-proof") {
            crate::proving::processors::reject_retired_complete_termination_proof();
            let args = split_top_level(inner, ',');
            let named = NamedProveStrategyArgs::parse(&args, "exact-trs-proof")?;
            let encoded = named.value(&["hex"], "hex-encoded TRS proof witness")?;
            let bytes = decode_hex_strategy_witness(encoded, "exact-trs-proof")?;
            let (source_trs_input_xml, termination_proof_xml) =
                serde_json::from_slice::<(String, String)>(&bytes)
                    .map_err(|_| prove_strategy_parse_error("invalid exact TRS proof witness"))?;
            return Ok(ProveStrategy::Processor(
                ProveStrategyProcessor::ExactTerminationProof {
                    source_trs_input_xml,
                    termination_proof_xml,
                },
            ));
        }
        if let Some(inner) = function_arguments(input, "exact-trs-nontermination-terminal") {
            let args = split_top_level(inner, ',');
            let named = NamedProveStrategyArgs::parse(&args, "exact-trs-nontermination-terminal")?;
            let encoded = named.value(&["hex"], "hex-encoded terminal witness")?;
            let bytes = decode_hex_strategy_witness(encoded, "exact-trs-nontermination-terminal")?;
            let (source_trs_input_xml, terminal_xml) = serde_json::from_slice::<(String, String)>(&bytes)
                .map_err(|_| prove_strategy_parse_error("invalid nontermination terminal witness"))?;
            return Ok(ProveStrategy::Processor(ProveStrategyProcessor::ExactNonterminationTerminal {
                source_trs_input_xml, terminal_xml,
            }));
        }
        if let Some(inner) = function_arguments(input, "exact-trs-no-rule-removal") {
            let args = split_top_level(inner, ',');
            let named = NamedProveStrategyArgs::parse(&args, "exact-trs-no-rule-removal")?;
            let bytes = decode_hex_strategy_witness(named.value(&["hex"], "source and residual")?, "exact-trs-no-rule-removal")?;
            let (source_trs_input_xml, residual_trs_input_xml) = serde_json::from_slice::<(String, String)>(&bytes)
                .map_err(|_| prove_strategy_parse_error("invalid nontermination rule-removal boundary"))?;
            return Ok(ProveStrategy::Processor(ProveStrategyProcessor::ExactNonterminationRuleRemoval {
                source_trs_input_xml, residual_trs_input_xml,
            }));
        }
        if let Some(inner) = function_arguments(input, "exact-trs-nontermination-proof") {
            crate::proving::processors::reject_retired_complete_nontermination_proof();
            let args = split_top_level(inner, ',');
            let named = NamedProveStrategyArgs::parse(&args, "exact-trs-nontermination-proof")?;
            let encoded = named.value(&["hex"], "hex-encoded TRS nontermination proof witness")?;
            let bytes = decode_hex_strategy_witness(encoded, "exact-trs-nontermination-proof")?;
            let (source_trs_input_xml, nontermination_proof_xml) =
                serde_json::from_slice::<(String, String)>(&bytes).map_err(|_| {
                    prove_strategy_parse_error("invalid exact TRS nontermination proof witness")
                })?;
            return Ok(ProveStrategy::Processor(
                ProveStrategyProcessor::ExactNonterminationProof {
                    source_trs_input_xml,
                    nontermination_proof_xml,
                },
            ));
        }
        if let Some(inner) = function_arguments(input, "exact-poly-removal") {
            let args = split_top_level(inner, ',');
            let named = NamedProveStrategyArgs::parse(&args, "exact-poly-removal")?;
            let encoded = named.value(&["hex"], "hex-encoded polynomial removal witness")?;
            let bytes = decode_hex_strategy_witness(encoded, "exact-poly-removal")?;
            let (interpretation, removed_rule_indices) = serde_json::from_slice(&bytes)
                .map_err(|_| prove_strategy_parse_error("invalid exact-poly-removal witness"))?;
            return Ok(ProveStrategy::Processor(
                ProveStrategyProcessor::ExactLinearPolynomialRemoval {
                    interpretation,
                    removed_rule_indices,
                },
            ));
        }
        if let Some(inner) = function_arguments(input, "exact-trs-order") {
            let args = split_top_level(inner, ',');
            let named = NamedProveStrategyArgs::parse(&args, "exact-trs-order")?;
            let bytes = decode_hex_strategy_witness(named.value(&["hex"], "source-bound order")?, "exact-trs-order")?;
            let (source_trs_input_xml, order_atom): (String, String) = serde_json::from_slice(&bytes)
                .map_err(|_| prove_strategy_parse_error("invalid source-bound order"))?;
            if !["exact-poly-removal(", "exact-kbo(", "exact-poly(", "exact-matrix("].iter()
                .any(|prefix| order_atom.starts_with(prefix)) {
                return Err(prove_strategy_parse_error("source-bound order requires one polynomial, matrix or KBO atom"));
            }
            if !matches!(ProveStrategy::parse(&order_atom)?, ProveStrategy::Processor(
                ProveStrategyProcessor::ExactLinearPolynomialRemoval { .. } | ProveStrategyProcessor::ExactKbo { .. }
                | ProveStrategyProcessor::ExactLinearPolynomial { .. } | ProveStrategyProcessor::ExactMatrixInterpretation { .. })) {
                return Err(prove_strategy_parse_error("source-bound order cannot contain a strategy"));
            }
            return Ok(ProveStrategy::Processor(ProveStrategyProcessor::ExactSourceBoundOrder { source_trs_input_xml, order_atom }));
        }
        if let Some(inner) = function_arguments(input, "exact-constant-to-unary") {
            let args = split_top_level(inner, ',');
            let named = NamedProveStrategyArgs::parse(&args, "exact-constant-to-unary")?;
            let encoded = named.value(&["hex"], "hex-encoded constant-to-unary witness")?;
            let bytes = decode_hex_strategy_witness(encoded, "exact-constant-to-unary")?;
            let (variable, renaming) = serde_json::from_slice(&bytes).map_err(|_| {
                prove_strategy_parse_error("invalid exact-constant-to-unary witness")
            })?;
            return Ok(ProveStrategy::Processor(
                ProveStrategyProcessor::ConstantToUnary { variable, renaming },
            ));
        }
        if let Some(inner) = function_arguments(input, "exact-relative-semantic-labeling") {
            let args = split_top_level(inner, ',');
            let named = NamedProveStrategyArgs::parse(&args, "exact-relative-semantic-labeling")?;
            let carrier_size = named
                .value(&["carrier-size", "carrier_size", "carrier"], "carrier size")?
                .parse::<usize>()
                .map_err(|_| {
                    prove_strategy_parse_error("semantic-labeling carrier size must be numeric")
                })?;
            if carrier_size == 0 {
                return Err(prove_strategy_parse_error(
                    "semantic-labeling carrier size must be positive",
                ));
            }
            let encoded = named.value(&["hex"], "hex-encoded semantic-labeling model")?;
            if encoded.len() % 2 != 0 || !encoded.bytes().all(|byte| byte.is_ascii_hexdigit()) {
                return Err(prove_strategy_parse_error(
                    "semantic-labeling hex model must contain an even number of hexadecimal digits",
                ));
            }
            let bytes = encoded
                .as_bytes()
                .chunks_exact(2)
                .map(|digits| {
                    let text = std::str::from_utf8(digits).map_err(|_| {
                        prove_strategy_parse_error("invalid semantic-labeling model")
                    })?;
                    u8::from_str_radix(text, 16)
                        .map_err(|_| prove_strategy_parse_error("invalid semantic-labeling model"))
                })
                .collect::<Result<Vec<_>, _>>()?;
            let interpretations: Vec<(String, usize, SlArithmeticFunction)> =
                serde_json::from_slice(&bytes)
                    .map_err(|_| prove_strategy_parse_error("invalid semantic-labeling model"))?;
            if interpretations.is_empty() {
                return Err(prove_strategy_parse_error(
                    "semantic-labeling model must not be empty",
                ));
            }
            return Ok(ProveStrategy::Processor(
                ProveStrategyProcessor::ExactRelativeSemanticLabeling {
                    carrier_size,
                    interpretations,
                },
            ));
        }
        for (name, key) in [("srs-context-closure", "depth"), ("srs-shift-labeling", "memory")] {
            if let Some(inner) = function_arguments(input, name) {
                let args = split_top_level(inner, ',');
                let named = NamedProveStrategyArgs::parse(&args, name)?;
                let value = named.value(&[key], key)?.parse::<usize>()
                    .map_err(|_| prove_strategy_parse_error("SRS context size must be numeric"))?;
                if !(1..=8).contains(&value) {
                    return Err(prove_strategy_parse_error("SRS context size must be between 1 and 8"));
                }
                return Ok(ProveStrategy::Processor(if name == "srs-context-closure" {
                    ProveStrategyProcessor::SrsContextClosure { depth: value }
                } else {
                    ProveStrategyProcessor::SrsShiftLabeling { memory: value }
                }));
            }
        }
        if let Some(inner) = function_arguments(input, "srs-weighted-labeling") {
            let args = split_top_level(inner, ',');
            let named = NamedProveStrategyArgs::parse(&args, "srs-weighted-labeling")?;
            let carrier_size = named.optional_usize(&["carrier-size"], "carrier size")?.unwrap_or(3);
            let max_weight = named.optional_usize(&["max-weight"], "weight bound")?.unwrap_or(4);
            let strict_percent = named.optional_usize(&["strict-percent"], "minimum strict percentage")?.unwrap_or(0);
            if !(2..=8).contains(&carrier_size) || !(1..=128).contains(&max_weight) || strict_percent > 100 {
                return Err(prove_strategy_parse_error("srs-weighted-labeling requires carrier-size 2..8, max-weight 1..128, strict-percent 0..100"));
            }
            return Ok(ProveStrategy::Processor(ProveStrategyProcessor::SrsWeightedLabeling { carrier_size, max_weight, strict_percent }));
        }
        if let Some(inner) = function_arguments(input, "relative-semantic-labeling") {
            let args = split_top_level(inner, ',');
            let named = NamedProveStrategyArgs::parse(&args, "relative-semantic-labeling")?;
            let carrier_size = named
                .optional_usize(&["carrier-size", "carrier_size", "carrier"], "carrier size")?
                .unwrap_or(2);
            if carrier_size == 0 {
                return Err(prove_strategy_parse_error(
                    "semantic-labeling carrier size must be positive",
                ));
            }
            return Ok(ProveStrategy::Processor(
                ProveStrategyProcessor::RelativeSemanticLabeling { carrier_size },
            ));
        }
        if let Some(inner) = function_arguments(input, "matrix")
            .or_else(|| function_arguments(input, "matrix-interpretation"))
        {
            let args = split_top_level(inner, ',');
            let named = NamedProveStrategyArgs::parse(&args, "matrix")?;
            return Ok(ProveStrategy::Processor(
                ProveStrategyProcessor::MatrixInterpretation {
                    dimension: named
                        .optional_usize(&["dimension", "dim"], "dimension")?
                        .unwrap_or(2),
                    max_constant: named
                        .required_i64(&["max-constant", "max_constant"], "max constant")?,
                    max_coefficient: named
                        .required_i64(&["max-coefficient", "max_coefficient"], "max coefficient")?,
                    max_symbols: named
                        .optional_usize(&["symbols", "max-symbols", "max_symbols"], "symbol cap")?,
                    max_arity: named
                        .optional_usize(&["arity", "max-arity", "max_arity"], "arity cap")?,
                },
            ));
        }
        if let Some(inner) = function_arguments(input, "integer-matrix") {
            let args = split_top_level(inner, ',');
            let named = NamedProveStrategyArgs::parse(&args, "integer-matrix")?;
            let min_value =
                named.required_i64(&["min", "min-value", "min_value"], "minimum value")?;
            let max_value =
                named.required_i64(&["max", "max-value", "max_value"], "maximum value")?;
            if min_value > max_value {
                return Err(prove_strategy_parse_error(
                    "integer-matrix minimum exceeds maximum",
                ));
            }
            return Ok(ProveStrategy::Processor(
                ProveStrategyProcessor::IntegerMatrixInterpretation {
                    dimension: named
                        .optional_usize(&["dimension", "dim"], "dimension")?
                        .unwrap_or(2),
                    min_value,
                    max_value,
                    max_symbols: named
                        .optional_usize(&["symbols", "max-symbols", "max_symbols"], "symbol cap")?,
                    max_arity: named
                        .optional_usize(&["arity", "max-arity", "max_arity"], "arity cap")?,
                },
            ));
        }
        if let Some(inner) = function_arguments(input, "exact-matrix") {
            let args = split_top_level(inner, ',');
            let named = NamedProveStrategyArgs::parse(&args, "exact-matrix")?;
            let encoded = named.value(&["hex"], "hex-encoded matrix witness")?;
            if encoded.len() % 2 != 0 || !encoded.bytes().all(|byte| byte.is_ascii_hexdigit()) {
                return Err(prove_strategy_parse_error(
                    "exact-matrix hex witness must contain an even number of hexadecimal digits",
                ));
            }
            let bytes = encoded
                .as_bytes()
                .chunks_exact(2)
                .map(|digits| {
                    let text = std::str::from_utf8(digits)
                        .map_err(|_| prove_strategy_parse_error("invalid exact-matrix witness"))?;
                    u8::from_str_radix(text, 16)
                        .map_err(|_| prove_strategy_parse_error("invalid exact-matrix witness"))
                })
                .collect::<Result<Vec<_>, _>>()?;
            let interpretation: Vec<(String, Vec<i64>, Vec<Vec<Vec<i64>>>)> =
                serde_json::from_slice(&bytes)
                    .map_err(|_| prove_strategy_parse_error("invalid exact-matrix witness"))?;
            if interpretation.is_empty() {
                return Err(prove_strategy_parse_error(
                    "exact-matrix witness must not be empty",
                ));
            }
            return Ok(ProveStrategy::Processor(
                ProveStrategyProcessor::ExactMatrixInterpretation { interpretation },
            ));
        }
        if let Some(inner) = function_arguments(input, "srs-strip-contexts") {
            let args = split_top_level(inner, ',');
            let named = NamedProveStrategyArgs::parse(&args, "srs-strip-contexts")?;
            if named.values.keys().any(|key| !matches!(key.as_str(), "max-prefix" | "max-suffix")) {
                return Err(prove_strategy_parse_error("unknown srs-strip-contexts argument"));
            }
            return Ok(ProveStrategy::Processor(ProveStrategyProcessor::SrsStripContexts {
                max_prefix: named.optional_usize(&["max-prefix"], "maximum prefix length")?,
                max_suffix: named.optional_usize(&["max-suffix"], "maximum suffix length")?,
            }));
        }
        if let Some(inner) = function_arguments(input, "uncurry") {
            let args = split_top_level(inner, ',');
            let named = NamedProveStrategyArgs::parse(&args, "uncurry")?;
            let role = named.optional_usize(&["role"], "application role")?
                .ok_or_else(|| prove_strategy_parse_error("uncurry requires role=N"))?;
            return Ok(ProveStrategy::Processor(ProveStrategyProcessor::UncurryRole { role }));
        }
        if let Some(inner) = function_arguments(input, "exact-integer-matrix") {
            let args = split_top_level(inner, ',');
            let named = NamedProveStrategyArgs::parse(&args, "exact-integer-matrix")?;
            let encoded = named.value(&["hex"], "hex-encoded integer matrix witness")?;
            if encoded.len() % 2 != 0 || !encoded.bytes().all(|byte| byte.is_ascii_hexdigit()) {
                return Err(prove_strategy_parse_error(
                    "exact-integer-matrix hex witness must contain an even number of hexadecimal digits",
                ));
            }
            let bytes = encoded
                .as_bytes()
                .chunks_exact(2)
                .map(|digits| {
                    let text = std::str::from_utf8(digits).map_err(|_| {
                        prove_strategy_parse_error("invalid exact-integer-matrix witness")
                    })?;
                    u8::from_str_radix(text, 16).map_err(|_| {
                        prove_strategy_parse_error("invalid exact-integer-matrix witness")
                    })
                })
                .collect::<Result<Vec<_>, _>>()?;
            let interpretation: Vec<(String, Vec<i64>, Vec<Vec<Vec<i64>>>)> =
                serde_json::from_slice(&bytes).map_err(|_| {
                    prove_strategy_parse_error("invalid exact-integer-matrix witness")
                })?;
            if interpretation.is_empty() {
                return Err(prove_strategy_parse_error(
                    "exact-integer-matrix witness must not be empty",
                ));
            }
            return Ok(ProveStrategy::Processor(
                ProveStrategyProcessor::ExactIntegerMatrixInterpretation { interpretation },
            ));
        }
        if let Some(inner) = function_arguments(input, "exact-kbo") {
            let args = split_top_level(inner, ',');
            let named = NamedProveStrategyArgs::parse(&args, "exact-kbo")?;
            let encoded = named.value(&["hex"], "hex-encoded KBO witness")?;
            let bytes = decode_hex_strategy_witness(encoded, "exact-kbo")?;
            let (precedence, precedence_ranks, weights) = serde_json::from_slice(&bytes)
                .map_err(|_| prove_strategy_parse_error("invalid exact-kbo witness"))?;
            return Ok(ProveStrategy::Processor(ProveStrategyProcessor::ExactKbo {
                precedence,
                precedence_ranks,
                weights,
            }));
        }
        if let Some(inner) = function_arguments(input, "exact-path-order") {
            let args = split_top_level(inner, ',');
            let named = NamedProveStrategyArgs::parse(&args, "exact-path-order")?;
            let encoded = named.value(&["hex"], "hex-encoded path-order witness")?;
            let bytes = decode_hex_strategy_witness(encoded, "exact-path-order")?;
            let decoded = serde_json::from_slice::<(
                BTreeMap<String, DpPathOrderKind>,
                Vec<String>,
                BTreeMap<String, usize>,
                DpArgumentFilter,
            )>(&bytes)
            .or_else(|_| {
                // Older certified-oracle extraction used the DP path-order
                // encoding at the top-level boundary.  Its leading default
                // order is redundant here because these retained witnesses
                // explicitly record the status of every live symbol.
                serde_json::from_slice::<(
                    DpPathOrderKind,
                    BTreeMap<String, DpPathOrderKind>,
                    Vec<String>,
                    BTreeMap<String, usize>,
                    DpArgumentFilter,
                )>(&bytes)
                .map(
                    |(_, statuses, precedence, precedence_ranks, argument_filter)| {
                        (statuses, precedence, precedence_ranks, argument_filter)
                    },
                )
            })
            .map_err(|_| prove_strategy_parse_error("invalid exact-path-order witness"))?;
            let (statuses, precedence, precedence_ranks, argument_filter) = decoded;
            return Ok(ProveStrategy::Processor(
                ProveStrategyProcessor::ExactPathOrder {
                    statuses,
                    precedence,
                    precedence_ranks,
                    argument_filter,
                },
            ));
        }
        if let Some(inner) = function_arguments(input, "exact-path-order-removal") {
            let args = split_top_level(inner, ',');
            let named = NamedProveStrategyArgs::parse(&args, "exact-path-order-removal")?;
            let encoded = named.value(&["hex"], "hex-encoded path-order removal witness")?;
            let bytes = decode_hex_strategy_witness(encoded, "exact-path-order-removal")?;
            let source_trs_input_xml = named.optional_value(&["source-hex"])
                .map(|value| {
                    let bytes = decode_hex_strategy_witness(value, "exact-path-order-removal")?;
                    String::from_utf8(bytes).map_err(|_| prove_strategy_parse_error("invalid path-order source UTF-8"))
                }).transpose()?;
            let (statuses, precedence, precedence_ranks, argument_filter, removed_rule_indices) =
                serde_json::from_slice(&bytes).map_err(|_| {
                    prove_strategy_parse_error("invalid exact-path-order-removal witness")
                })?;
            return Ok(ProveStrategy::Processor(
                ProveStrategyProcessor::ExactPathOrderRemoval {
                    source_trs_input_xml,
                    statuses,
                    precedence,
                    precedence_ranks,
                    argument_filter,
                    removed_rule_indices,
                },
            ));
        }
        if let Some(inner) = function_arguments(input, "exact-dp") {
            let args = split_top_level(inner, ',');
            let named = NamedProveStrategyArgs::parse(&args, "exact-dp")?;
            let encoded = named.value(&["hex"], "hex-encoded DP input")?;
            let bytes = decode_hex_strategy_witness(encoded, "exact-dp")?;
            let dp_input_xml = serde_json::from_slice(&bytes)
                .map_err(|_| prove_strategy_parse_error("invalid exact-dp witness"))?;
            return Ok(ProveStrategy::Processor(
                ProveStrategyProcessor::ExactDependencyPairs { dp_input_xml },
            ));
        }
        if let Some(inner) = function_arguments(input, "exact-innermost-lhss-dp") {
            let args = split_top_level(inner, ',');
            let named = NamedProveStrategyArgs::parse(&args, "exact-innermost-lhss-dp")?;
            let encoded = named.value(&["hex"], "hex-encoded Q-increase DP input")?;
            let bytes = decode_hex_strategy_witness(encoded, "exact-innermost-lhss-dp")?;
            let dp_input_xml = serde_json::from_slice(&bytes).map_err(|_| {
                prove_strategy_parse_error("invalid exact-innermost-lhss-dp witness")
            })?;
            return Ok(ProveStrategy::Processor(
                ProveStrategyProcessor::ExactInnermostLhssDependencyPairs { dp_input_xml },
            ));
        }
        if let Some(inner) = function_arguments(input, "srs-weighted-length")
            .or_else(|| function_arguments(input, "weighted-length"))
            .or_else(|| function_arguments(input, "srs-weight"))
        {
            let max_weight = parse_optional_i64_strategy_argument(
                inner,
                "srs-weighted-length",
                DEFAULT_SRS_WEIGHT_MAX,
            )?;
            return Ok(ProveStrategy::Processor(
                ProveStrategyProcessor::SrsWeightedLength { max_weight },
            ));
        }
        if let Some(inner) = function_arguments(input, "srs-canonical-weight-removal") {
            let max_weight = parse_optional_i64_strategy_argument(inner,
                "srs-canonical-weight-removal", DEFAULT_SRS_WEIGHT_MAX)?;
            return Ok(ProveStrategy::Processor(ProveStrategyProcessor::SrsCanonicalWeightRemoval { max_weight }));
        }
        if let Some(inner) = function_arguments(input, "srs-compact-weight-removal") {
            let max_weight = parse_optional_i64_strategy_argument(inner,
                "srs-compact-weight-removal", DEFAULT_SRS_WEIGHT_MAX)?;
            return Ok(ProveStrategy::Processor(ProveStrategyProcessor::SrsCompactWeightRemoval { max_weight }));
        }
        if let Some(inner) = function_arguments(input, "srs-canonical-compact-weight-removal") {
            let max_weight = parse_optional_i64_strategy_argument(inner,
                "srs-canonical-compact-weight-removal", DEFAULT_SRS_WEIGHT_MAX)?;
            return Ok(ProveStrategy::Processor(ProveStrategyProcessor::SrsCanonicalCompactWeightRemoval { max_weight }));
        }
        if let Some(inner) = function_arguments(input, "srs-summed-weight-removal") {
            let max_weight = parse_optional_i64_strategy_argument(inner,
                "srs-summed-weight-removal", DEFAULT_SRS_WEIGHT_MAX)?;
            return Ok(ProveStrategy::Processor(ProveStrategyProcessor::SrsSummedWeightRemoval { max_weight }));
        }
        if let Some(inner) = function_arguments(input, "srs-linear-weight-removal") {
            let max_weight = parse_optional_i64_strategy_argument(inner,
                "srs-linear-weight-removal", DEFAULT_SRS_WEIGHT_MAX)?;
            return Ok(ProveStrategy::Processor(ProveStrategyProcessor::SrsLinearWeightRemoval { max_weight }));
        }
        if let Some(inner) = function_arguments(input, "srs-lp-weight-removal") {
            let args = split_top_level(inner, ',');
            let (max_weight, all_strict, maximal) = if args.iter().any(|arg| arg.contains('=')) {
                let named = NamedProveStrategyArgs::parse(&args, "srs-lp-weight-removal")?;
                let weight = named.optional_value(&["max-weight", "max_weight", "weight"])
                    .map(|value| value.parse::<i64>().map_err(|_| prove_strategy_parse_error("max-weight must be numeric")))
                    .transpose()?.unwrap_or(DEFAULT_SRS_WEIGHT_MAX);
                let strict = named
                    .optional_value(&["all-strict"]).map(|value| value.parse::<bool>()
                        .map_err(|_| prove_strategy_parse_error("all-strict expects true or false"))).transpose()?.unwrap_or(false);
                let maximal = named.optional_value(&["maximal"]).map(|value| value.parse::<bool>()
                    .map_err(|_| prove_strategy_parse_error("maximal expects true or false"))).transpose()?.unwrap_or(false);
                if strict && maximal { return Err(prove_strategy_parse_error("all-strict and maximal are separate LP objectives")); }
                (weight, strict, maximal)
            } else { (parse_optional_i64_strategy_argument(inner,
                "srs-lp-weight-removal", DEFAULT_SRS_WEIGHT_MAX)?, false, false) };
            return Ok(ProveStrategy::Processor(ProveStrategyProcessor::SrsLpWeightRemoval { max_weight, all_strict, maximal }));
        }
        if let Some(inner) = function_arguments(input, "srs-weighted-rule-removal")
            .or_else(|| function_arguments(input, "srs-weight-rule-removal"))
            .or_else(|| function_arguments(input, "srs-weighted-removal"))
        {
            let max_weight = parse_optional_i64_strategy_argument(
                inner,
                "srs-weighted-rule-removal",
                DEFAULT_SRS_WEIGHT_MAX,
            )?;
            return Ok(ProveStrategy::Processor(
                ProveStrategyProcessor::SrsWeightedRuleRemoval { max_weight },
            ));
        }
        if let Some(inner) = function_arguments(input, "exact-match-bounds") {
            let args = split_top_level(inner, ',');
            let named = NamedProveStrategyArgs::parse(&args, "exact-match-bounds")?;
            let encoded = named.value(&["hex"], "hex-encoded match-bounds witness")?;
            if encoded.len() % 2 != 0 || !encoded.bytes().all(|byte| byte.is_ascii_hexdigit()) {
                return Err(prove_strategy_parse_error(
                    "exact-match-bounds witness must contain an even number of hexadecimal digits",
                ));
            }
            let bytes = encoded
                .as_bytes()
                .chunks_exact(2)
                .map(|digits| {
                    let text = std::str::from_utf8(digits).map_err(|_| {
                        prove_strategy_parse_error("invalid exact-match-bounds witness")
                    })?;
                    u8::from_str_radix(text, 16).map_err(|_| {
                        prove_strategy_parse_error("invalid exact-match-bounds witness")
                    })
                })
                .collect::<Result<Vec<_>, _>>()?;
            let proof = serde_json::from_slice(&bytes)
                .map_err(|_| prove_strategy_parse_error("invalid exact-match-bounds witness"))?;
            return Ok(ProveStrategy::Processor(
                ProveStrategyProcessor::ExactSrsMatchBounds { proof },
            ));
        }
        if let Some(inner) = function_arguments(input, "exact-relative-match-bounds") {
            let args = split_top_level(inner, ',');
            let named = NamedProveStrategyArgs::parse(&args, "exact-relative-match-bounds")?;
            let encoded = named.value(&["hex"], "hex-encoded relative match-bounds witness")?;
            if encoded.len() % 2 != 0 || !encoded.bytes().all(|byte| byte.is_ascii_hexdigit()) {
                return Err(prove_strategy_parse_error(
                    "exact-relative-match-bounds witness must contain an even number of hexadecimal digits",
                ));
            }
            let bytes = encoded
                .as_bytes()
                .chunks_exact(2)
                .map(|digits| {
                    let text = std::str::from_utf8(digits).map_err(|_| {
                        prove_strategy_parse_error("invalid exact-relative-match-bounds witness")
                    })?;
                    u8::from_str_radix(text, 16).map_err(|_| {
                        prove_strategy_parse_error("invalid exact-relative-match-bounds witness")
                    })
                })
                .collect::<Result<Vec<_>, _>>()?;
            let (proof, removed_indices) = serde_json::from_slice(&bytes).map_err(|_| {
                prove_strategy_parse_error("invalid exact-relative-match-bounds witness")
            })?;
            return Ok(ProveStrategy::Processor(
                ProveStrategyProcessor::ExactSrsRelativeMatchBounds {
                    proof,
                    removed_indices,
                },
            ));
        }
        if let Some(inner) = function_arguments(input, "match-bounds")
            .or_else(|| function_arguments(input, "matchbounds"))
            .or_else(|| function_arguments(input, "srs-match-bounds"))
        {
            let (max_bound, max_states, max_transitions) = parse_match_bounds_arguments(inner)?;
            return Ok(ProveStrategy::Processor(
                ProveStrategyProcessor::SrsMatchBounds {
                    max_bound,
                    max_states,
                    max_transitions,
                },
            ));
        }
        if let Some(inner) = function_arguments(input, "relative-match-bounds")
            .or_else(|| function_arguments(input, "relative-matchbounds"))
            .or_else(|| function_arguments(input, "srs-relative-match-bounds"))
        {
            let (max_bound, max_states, max_transitions) = parse_match_bounds_arguments(inner)?;
            return Ok(ProveStrategy::Processor(
                ProveStrategyProcessor::SrsRelativeMatchBounds {
                    max_bound,
                    max_states,
                    max_transitions,
                },
            ));
        }
        if let Some(inner) = function_arguments(input, "relative-match-bounds-removal")
            .or_else(|| function_arguments(input, "relative-matchbounds-removal"))
            .or_else(|| function_arguments(input, "srs-relative-match-bounds-removal"))
        {
            let (max_bound, max_states, max_transitions) = parse_match_bounds_arguments(inner)?;
            return Ok(ProveStrategy::Processor(
                ProveStrategyProcessor::SrsRelativeMatchBoundsRemoval {
                    max_bound,
                    max_states,
                    max_transitions,
                },
            ));
        }
        if let Some(inner) = function_arguments(input, "rfc-match-bounds")
            .or_else(|| function_arguments(input, "rfc-matchbounds"))
            .or_else(|| function_arguments(input, "srs-rfc-match-bounds"))
        {
            let (
                max_bound,
                max_words,
                max_word_len,
                max_states,
                max_transitions,
                at_bound,
                closure,
            ) = parse_rfc_match_bounds_arguments(inner)?;
            return Ok(ProveStrategy::Processor(
                ProveStrategyProcessor::SrsRfcMatchBounds {
                    max_bound,
                    max_words,
                    max_word_len,
                    max_states,
                    max_transitions,
                    at_bound,
                    closure,
                },
            ));
        }
        if let Some(inner) = function_arguments(input, "rfc-relative-match-bounds")
            .or_else(|| function_arguments(input, "rfc-relative-matchbounds"))
            .or_else(|| function_arguments(input, "srs-rfc-relative-match-bounds"))
        {
            let args = split_top_level(inner, ',');
            let named = args.iter().any(|arg| arg.contains('=')).then(||
                NamedProveStrategyArgs::parse(&args, "rfc-relative-match-bounds")).transpose()?;
            let flag = |name: &str| -> Result<bool, ProveStrategyParseError> {
                match named.as_ref().and_then(|n| n.optional_value(&[name])) {
                    None | Some("false") | Some("0") => Ok(false),
                    Some("true") | Some("1") => Ok(true),
                    _ => Err(prove_strategy_parse_error(format!("{name} must be true or false"))),
                }
            };
            let absolute_residual = flag("absolute-residual")?;
            let allow_partial = flag("allow-partial")? || absolute_residual;
            let layered_seconds = named.as_ref().map(|n|
                n.optional_usize(&["layered-seconds"], "layered completion seconds")
            ).transpose()?.flatten().unwrap_or(2) as u64;
            if layered_seconds == 0 || layered_seconds > 300 {
                return Err(prove_strategy_parse_error("layered-seconds must be in 1..=300"));
            }
            let fresh_seconds = named.as_ref().map(|n|
                n.optional_usize(&["fresh-seconds"], "fresh-path completion seconds")
            ).transpose()?.flatten().map(|v| v as u64).unwrap_or(layered_seconds.min(3));
            if fresh_seconds > 300 {
                return Err(prove_strategy_parse_error("fresh-seconds must be in 0..=300"));
            }
            let min_bound = if args.iter().any(|arg| arg.contains('=')) {
                NamedProveStrategyArgs::parse(&args, "rfc-relative-match-bounds")?
                    .optional_usize(&["min-bound", "min_bound"], "minimum bound")?.unwrap_or(0)
            } else { 0 };
            let (
                max_bound,
                max_words,
                max_word_len,
                max_states,
                max_transitions,
                at_bound,
                closure,
            ) = parse_rfc_match_bounds_arguments(inner)?;
            if min_bound > max_bound {
                return Err(prove_strategy_parse_error("minimum RFC bound exceeds maximum bound"));
            }
            return Ok(ProveStrategy::Processor(
                ProveStrategyProcessor::SrsRfcRelativeMatchBounds {
                    allow_partial,
                    absolute_residual,
                    layered_seconds,
                    fresh_seconds,
                    min_bound,
                    max_bound,
                    max_words,
                    max_word_len,
                    max_states,
                    max_transitions,
                    at_bound,
                    closure,
                },
            ));
        }
        if let Some(inner) = function_arguments(input, "smt-poly")
            .or_else(|| function_arguments(input, "smt-polynomial"))
            .or_else(|| function_arguments(input, "smt"))
        {
            let (max_constant, max_coefficient, max_symbols, max_arity) =
                parse_top_level_polynomial_bounds(inner, "smt-poly")?;
            return Ok(ProveStrategy::Processor(
                ProveStrategyProcessor::SmtLinearPolynomial {
                    max_constant,
                    max_coefficient,
                    max_symbols,
                    max_arity,
                },
            ));
        }
        if let Some(inner) = function_arguments(input, "path-order")
            .or_else(|| function_arguments(input, "rpo"))
            .or_else(|| function_arguments(input, "lpo"))
        {
            let args = split_top_level(inner, ',');
            let named = NamedProveStrategyArgs::parse(&args, "path-order")?;
            let max_symbols = named
                .optional_usize(&["symbols", "max-symbols", "max_symbols"], "symbol cap")?
                .unwrap_or(usize::MAX);
            let shared = named.optional_usize(&["shared"], "shared encoding")?.unwrap_or(0);
            if shared > 1 { return Err(prove_strategy_parse_error("shared must be 0 or 1")); }
            if shared == 1 {
                return Ok(ProveStrategy::Processor(ProveStrategyProcessor::SharedPathOrder { max_symbols }));
            }
            return Ok(ProveStrategy::Processor(ProveStrategyProcessor::PathOrder { max_symbols }));
        }
        if let Some(inner) = function_arguments(input, "kbo") {
            let args = split_top_level(inner, ',');
            if args.iter().any(|arg| arg.contains('=')) {
                let named = NamedProveStrategyArgs::parse(&args, "kbo")?;
                return Ok(ProveStrategy::Processor(ProveStrategyProcessor::Kbo {
                    max_weight: named
                        .required_i64(&["weight", "max-weight", "max_weight"], "weight")?,
                    max_symbols: named
                        .optional_usize(&["symbols", "max-symbols", "max_symbols"], "symbol cap")?
                        .unwrap_or(usize::MAX),
                }));
            }
            return match args.as_slice() {
                [max_weight] => Ok(ProveStrategy::Processor(ProveStrategyProcessor::Kbo {
                    max_weight: max_weight
                        .trim()
                        .parse()
                        .map_err(|_| prove_strategy_parse_error("kbo weight must be numeric"))?,
                    max_symbols: usize::MAX,
                })),
                [max_weight, max_symbols] => {
                    Ok(ProveStrategy::Processor(ProveStrategyProcessor::Kbo {
                        max_weight: max_weight.trim().parse().map_err(|_| {
                            prove_strategy_parse_error("kbo weight must be numeric")
                        })?,
                        max_symbols: max_symbols.trim().parse().map_err(|_| {
                            prove_strategy_parse_error("kbo symbol cap must be numeric")
                        })?,
                    }))
                }
                _ => Err(prove_strategy_parse_error(
                    "kbo expects max weight and optional max symbols",
                )),
            };
        }
        match input.to_ascii_lowercase().as_str() {
            "constant-to-unary" => Ok(ProveStrategy::Processor(
                ProveStrategyProcessor::NativeConstantToUnary,
            )),
            "nontermination" => Ok(ProveStrategy::Processor(
                ProveStrategyProcessor::NonterminationSearch,
            )),
            "remove-non-applicable-rules" => Ok(ProveStrategy::Processor(
                ProveStrategyProcessor::RemoveNonApplicableRules,
            )),
            "srs-length" | "strict-length" | "length" => {
                Ok(ProveStrategy::Processor(ProveStrategyProcessor::SrsLength))
            }
            "srs-weighted-length" | "weighted-length" | "srs-weight" => Ok(
                ProveStrategy::Processor(ProveStrategyProcessor::SrsWeightedLength {
                    max_weight: DEFAULT_SRS_WEIGHT_MAX,
                }),
            ),
            "srs-weighted-rule-removal" | "srs-weight-rule-removal" | "srs-weighted-removal" => Ok(
                ProveStrategy::Processor(ProveStrategyProcessor::SrsWeightedRuleRemoval {
                    max_weight: DEFAULT_SRS_WEIGHT_MAX,
                }),
            ),
            "match-bounds" | "matchbounds" | "srs-match-bounds" => Ok(ProveStrategy::Processor(
                ProveStrategyProcessor::SrsMatchBounds {
                    max_bound: DEFAULT_SRS_MATCH_BOUND_MAX,
                    max_states: DEFAULT_SRS_MATCH_BOUNDS_MAX_STATES,
                    max_transitions: DEFAULT_SRS_MATCH_BOUNDS_MAX_TRANSITIONS,
                },
            )),
            "poly01" => Ok(ProveStrategy::Processor(
                ProveStrategyProcessor::LinearPolynomial {
                    max_constant: 0,
                    max_coefficient: 1,
                    max_symbols: None,
                    max_arity: None,
                },
            )),
            "poly11" | "linear-poly" | "linear-polynomial" => Ok(ProveStrategy::Processor(
                ProveStrategyProcessor::LinearPolynomial {
                    max_constant: 1,
                    max_coefficient: 1,
                    max_symbols: None,
                    max_arity: None,
                },
            )),
            "poly21" => Ok(ProveStrategy::Processor(
                ProveStrategyProcessor::LinearPolynomial {
                    max_constant: 2,
                    max_coefficient: 1,
                    max_symbols: None,
                    max_arity: None,
                },
            )),
            "poly22" => Ok(ProveStrategy::Processor(
                ProveStrategyProcessor::LinearPolynomial {
                    max_constant: 2,
                    max_coefficient: 2,
                    max_symbols: None,
                    max_arity: None,
                },
            )),
            "smt" | "smt-poly" | "smt-polynomial" => Ok(ProveStrategy::Processor(
                ProveStrategyProcessor::SmtLinearPolynomial {
                    max_constant: 2,
                    max_coefficient: 1,
                    max_symbols: None,
                    max_arity: None,
                },
            )),
            "matrix" | "matrix-interpretation" => Ok(ProveStrategy::Processor(
                ProveStrategyProcessor::MatrixInterpretation {
                    dimension: 2,
                    max_constant: 1,
                    max_coefficient: 1,
                    max_symbols: None,
                    max_arity: None,
                },
            )),
            "kbo" => Ok(ProveStrategy::Processor(ProveStrategyProcessor::Kbo {
                max_weight: 2,
                max_symbols: usize::MAX,
            })),
            "path-order" | "rpo" | "lpo" => Ok(ProveStrategy::Processor(
                ProveStrategyProcessor::PathOrder {
                    max_symbols: usize::MAX,
                },
            )),
            "relative-flat-context-closure" | "flat-context-closure" => Ok(
                ProveStrategy::Processor(ProveStrategyProcessor::RelativeFlatContextClosure),
            ),
            "relative-adp" | "relative-annotated-dependency-pairs" => Ok(ProveStrategy::Processor(
                ProveStrategyProcessor::RelativeAnnotatedDependencyPairs,
            )),
            "trs-root-labeling" => Ok(ProveStrategy::Processor(ProveStrategyProcessor::TrsRootLabeling)),
            "relative-semantic-labeling" | "relative-semlab" => Ok(ProveStrategy::Processor(
                ProveStrategyProcessor::RelativeSemanticLabeling { carrier_size: 2 },
            )),
            "outermost-rz" | "raffelsieper-zantema" | "outermost-raffelsieper-zantema" => Ok(
                ProveStrategy::Processor(ProveStrategyProcessor::OutermostRaffelsieperZantema),
            ),
            "switch-csr" | "switch-context-sensitive" => Ok(ProveStrategy::Processor(
                ProveStrategyProcessor::SwitchContextSensitive,
            )),
            "gm04-inverse-csr" => Ok(ProveStrategy::Processor(
                ProveStrategyProcessor::Gm04InverseContextSensitive,
            )),
            "gm04-inverse-csr-full" | "qtrs-to-csr" | "qtrs-to-csr-full" => Ok(
                ProveStrategy::Processor(ProveStrategyProcessor::Gm04InverseContextSensitiveFull),
            ),
            "csr-loop" | "context-sensitive-loop" => {
                Ok(ProveStrategy::Processor(ProveStrategyProcessor::CsrLoop))
            }
            "switch-innermost" => Ok(ProveStrategy::Processor(
                ProveStrategyProcessor::SwitchInnermost,
            )),
            "aaecc-innermost" | "aaecc" => Ok(ProveStrategy::Processor(
                ProveStrategyProcessor::AaeccInnermost,
            )),
            "srs-strip-contexts" => Ok(ProveStrategy::Processor(
                ProveStrategyProcessor::SrsStripContexts { max_prefix: None, max_suffix: None },
            )),
            "string-reversal" | "stringreversal" | "reverse-srs" | "reverse" => Ok(
                ProveStrategy::Processor(ProveStrategyProcessor::StringReversal),
            ),
            "csr-innermost" | "csr-innermost-equivalence" | "innermost-equivalent" => Ok(
                ProveStrategy::Processor(ProveStrategyProcessor::CsrInnermostEquivalence),
            ),
            "csr-innermost-rta08" | "csr-innermost-rta08-equivalence" => Ok(
                ProveStrategy::Processor(ProveStrategyProcessor::CsrInnermostRta08Equivalence),
            ),
            "uncurry" | "uncurrying" => {
                Ok(ProveStrategy::Processor(ProveStrategyProcessor::Uncurry))
            }
            "csr-safe-dp" | "safe-csr-dp" => Ok(ProveStrategy::Processor(
                ProveStrategyProcessor::SafeCsrDependencyPairs,
            )),
            "csr-improved-dp" | "improved-csr-dp" => Ok(ProveStrategy::Processor(
                ProveStrategyProcessor::ImprovedCsrDependencyPairs,
            )),
            "csr-muterm-unhiding" | "muterm-unhiding-csr-dp" => Ok(ProveStrategy::Processor(
                ProveStrategyProcessor::MutermUnhidingCsrDependencyPairs,
            )),
            "csr-muterm-expanded" | "muterm-expanded-csr-dp" => Ok(ProveStrategy::Processor(
                ProveStrategyProcessor::MutermExpandedCsrDependencyPairs,
            )),
            "csr-innermost-dp" | "innermost-csr-dp" => Ok(ProveStrategy::Processor(
                ProveStrategyProcessor::InnermostCsrDependencyPairs,
            )),
            "csr-rta08-dp" | "rta08-csr-dp" => Ok(ProveStrategy::Processor(
                ProveStrategyProcessor::Rta08CsrDependencyPairs,
            )),
            "csr-native-dp" | "native-csr-dp" => Ok(ProveStrategy::Processor(
                ProveStrategyProcessor::NativeContextSensitiveCsrDependencyPairs,
            )),
            "csr-native-ordinary-dp" | "native-ordinary-csr-dp" => Ok(ProveStrategy::Processor(
                ProveStrategyProcessor::NativeOrdinaryCsrDependencyPairs,
            )),
            "csr-conservative-dp" | "conservative-csr-dp" => Ok(ProveStrategy::Processor(
                ProveStrategyProcessor::ConservativeCsrDependencyPairs,
            )),
            "csr-gm-transform" | "gm-csr-transform" => Ok(ProveStrategy::Processor(
                ProveStrategyProcessor::CsrGmTransformation,
            )),
            "default" => Ok(ProveStrategy::default_from_file()),
            "fail" | "inapplicable" => Ok(ProveStrategy::Processor(ProveStrategyProcessor::Fail)),
            "innermost-lhss-dp" => Ok(ProveStrategy::Processor(
                ProveStrategyProcessor::InnermostLhssDependencyPairs,
            )),
            "dp-trimmed" => Ok(ProveStrategy::Processor(
                ProveStrategyProcessor::TrimmedDependencyPairs,
            )),
            "dp" | "dependency-pairs" => Ok(ProveStrategy::Processor(
                ProveStrategyProcessor::DependencyPairs,
            )),
            "" => Err(prove_strategy_parse_error("empty strategy atom")),
            atom => Err(prove_strategy_parse_error(format!(
                "unknown top-level strategy atom `{atom}`"
            ))),
        }
    }
}

fn prove_strategy_parse_error(message: impl Into<String>) -> ProveStrategyParseError {
    ProveStrategyParseError {
        message: message.into(),
    }
}

fn decode_hex_strategy_witness(
    encoded: &str,
    atom: &str,
) -> Result<Vec<u8>, ProveStrategyParseError> {
    if encoded.len() % 2 != 0 || !encoded.bytes().all(|byte| byte.is_ascii_hexdigit()) {
        return Err(prove_strategy_parse_error(format!(
            "{atom} hex witness must contain an even number of hexadecimal digits"
        )));
    }
    encoded
        .as_bytes()
        .chunks_exact(2)
        .map(|digits| {
            let text = std::str::from_utf8(digits)
                .map_err(|_| prove_strategy_parse_error(format!("invalid {atom} witness")))?;
            u8::from_str_radix(text, 16)
                .map_err(|_| prove_strategy_parse_error(format!("invalid {atom} witness")))
        })
        .collect()
}

fn parse_top_level_polynomial_bounds(
    input: &str,
    atom: &str,
) -> Result<(i64, i64, Option<usize>, Option<usize>), ProveStrategyParseError> {
    let args = split_top_level(input, ',');
    if args.iter().any(|arg| arg.contains('=')) {
        let named = NamedProveStrategyArgs::parse(&args, atom)?;
        let max_constant = named.required_i64(
            &["const", "constant", "max-constant", "max_constant"],
            "constant",
        )?;
        let max_coefficient = named.required_i64(
            &[
                "coeff",
                "coefficient",
                "max-coeff",
                "max-coefficient",
                "max_coefficient",
            ],
            "coefficient",
        )?;
        return Ok((
            max_constant,
            max_coefficient,
            named.optional_usize(&["symbols", "max-symbols", "max_symbols"], "symbol cap")?,
            named.optional_usize(&["arity", "max-arity", "max_arity"], "arity cap")?,
        ));
    }
    if args.len() != 2 && args.len() != 4 {
        return Err(prove_strategy_parse_error(format!(
            "{atom} expects max constant and max coefficient, optionally max symbols and max arity"
        )));
    }
    let max_constant = args[0]
        .trim()
        .parse()
        .map_err(|_| prove_strategy_parse_error(format!("{atom} constant must be numeric")))?;
    let max_coefficient = args[1]
        .trim()
        .parse()
        .map_err(|_| prove_strategy_parse_error(format!("{atom} coefficient must be numeric")))?;
    let max_symbols = if let Some(value) = args.get(2) {
        Some(value.trim().parse().map_err(|_| {
            prove_strategy_parse_error(format!("{atom} symbol cap must be numeric"))
        })?)
    } else {
        None
    };
    let max_arity =
        if let Some(value) = args.get(3) {
            Some(value.trim().parse().map_err(|_| {
                prove_strategy_parse_error(format!("{atom} arity cap must be numeric"))
            })?)
        } else {
            None
        };
    Ok((max_constant, max_coefficient, max_symbols, max_arity))
}

fn parse_optional_i64_strategy_argument(
    input: &str,
    atom: &str,
    default: i64,
) -> Result<i64, ProveStrategyParseError> {
    let input = input.trim();
    if input.is_empty() {
        return Ok(default);
    }
    let args = split_top_level(input, ',');
    if args.len() != 1 {
        return Err(prove_strategy_parse_error(format!(
            "{atom} expects at most one numeric argument"
        )));
    }
    if args[0].contains('=') {
        let named = NamedProveStrategyArgs::parse(&args, atom)?;
        if let Some(value) = named.optional_value(&["max-weight", "max_weight", "weight"]) {
            return value.parse().map_err(|_| {
                prove_strategy_parse_error(format!("{atom} max weight must be numeric"))
            });
        }
        return Err(prove_strategy_parse_error(format!(
            "{atom} missing max-weight argument"
        )));
    }
    args[0]
        .trim()
        .parse()
        .map_err(|_| prove_strategy_parse_error(format!("{atom} argument must be numeric")))
}

fn parse_match_bounds_arguments(
    input: &str,
) -> Result<(usize, usize, usize), ProveStrategyParseError> {
    let input = input.trim();
    if input.is_empty() {
        return Ok((
            DEFAULT_SRS_MATCH_BOUND_MAX,
            DEFAULT_SRS_MATCH_BOUNDS_MAX_STATES,
            DEFAULT_SRS_MATCH_BOUNDS_MAX_TRANSITIONS,
        ));
    }
    let args = split_top_level(input, ',');
    if args.iter().any(|arg| arg.contains('=')) {
        let named = NamedProveStrategyArgs::parse(&args, "match-bounds")?;
        return Ok((
            named
                .optional_usize(&["max-bound", "max_bound", "bound"], "max bound")?
                .unwrap_or(DEFAULT_SRS_MATCH_BOUND_MAX),
            named
                .optional_usize(&["max-states", "max_states", "states"], "state cap")?
                .unwrap_or(DEFAULT_SRS_MATCH_BOUNDS_MAX_STATES),
            named
                .optional_usize(
                    &["max-transitions", "max_transitions", "transitions"],
                    "transition cap",
                )?
                .unwrap_or(DEFAULT_SRS_MATCH_BOUNDS_MAX_TRANSITIONS),
        ));
    }
    if args.len() != 1 {
        return Err(prove_strategy_parse_error(
            "match-bounds expects max bound or named arguments",
        ));
    }
    let max_bound = args[0]
        .trim()
        .parse()
        .map_err(|_| prove_strategy_parse_error("match-bounds max bound must be numeric"))?;
    Ok((
        max_bound,
        DEFAULT_SRS_MATCH_BOUNDS_MAX_STATES,
        DEFAULT_SRS_MATCH_BOUNDS_MAX_TRANSITIONS,
    ))
}

fn parse_rfc_match_bounds_arguments(
    input: &str,
) -> Result<
    (
        usize,
        usize,
        usize,
        usize,
        usize,
        SrsMatchAtBound,
        SrsRfcBarrenClosure,
    ),
    ProveStrategyParseError,
> {
    let input = input.trim();
    if input.is_empty() {
        return Ok((
            DEFAULT_SRS_MATCH_BOUND_MAX,
            DEFAULT_SRS_RFC_MAX_WORDS,
            DEFAULT_SRS_RFC_MAX_WORD_LEN,
            DEFAULT_SRS_MATCH_BOUNDS_MAX_STATES,
            DEFAULT_SRS_MATCH_BOUNDS_MAX_TRANSITIONS,
            SrsMatchAtBound::Exact,
            SrsRfcBarrenClosure::Right,
        ));
    }
    let args = split_top_level(input, ',');
    if args.iter().any(|arg| arg.contains('=')) {
        let named = NamedProveStrategyArgs::parse(&args, "rfc-match-bounds")?;
        return Ok((
            named
                .optional_usize(&["max-bound", "max_bound", "bound"], "max bound")?
                .unwrap_or(DEFAULT_SRS_MATCH_BOUND_MAX),
            named
                .optional_usize(&["max-words", "max_words", "words"], "word cap")?
                .unwrap_or(DEFAULT_SRS_RFC_MAX_WORDS),
            named
                .optional_usize(
                    &["max-word-len", "max_word_len", "word-len", "word_len"],
                    "word length cap",
                )?
                .unwrap_or(DEFAULT_SRS_RFC_MAX_WORD_LEN),
            named
                .optional_usize(&["max-states", "max_states", "states"], "state cap")?
                .unwrap_or(DEFAULT_SRS_MATCH_BOUNDS_MAX_STATES),
            named
                .optional_usize(
                    &["max-transitions", "max_transitions", "transitions"],
                    "transition cap",
                )?
                .unwrap_or(DEFAULT_SRS_MATCH_BOUNDS_MAX_TRANSITIONS),
            named
                .optional_value(&["at-bound", "at_bound"])
                .map(parse_srs_match_at_bound)
                .transpose()?
                .unwrap_or(SrsMatchAtBound::Exact),
            named
                .optional_value(&["closure", "closures", "barren-closure", "barren_closure"])
                .map(parse_srs_rfc_barren_closure)
                .transpose()?
                .unwrap_or(SrsRfcBarrenClosure::Right),
        ));
    }
    if args.len() != 1 {
        return Err(prove_strategy_parse_error(
            "rfc-match-bounds expects max bound or named arguments",
        ));
    }
    let max_bound = args[0]
        .trim()
        .parse()
        .map_err(|_| prove_strategy_parse_error("rfc-match-bounds max bound must be numeric"))?;
    Ok((
        max_bound,
        DEFAULT_SRS_RFC_MAX_WORDS,
        DEFAULT_SRS_RFC_MAX_WORD_LEN,
        DEFAULT_SRS_MATCH_BOUNDS_MAX_STATES,
        DEFAULT_SRS_MATCH_BOUNDS_MAX_TRANSITIONS,
        SrsMatchAtBound::Exact,
        SrsRfcBarrenClosure::Right,
    ))
}

fn parse_srs_match_at_bound(input: &str) -> Result<SrsMatchAtBound, ProveStrategyParseError> {
    match normalize_prove_strategy_argument_name(input).as_str() {
        "exact" => Ok(SrsMatchAtBound::Exact),
        "merge" => Ok(SrsMatchAtBound::Merge),
        _ => Err(prove_strategy_parse_error(
            "rfc-match-bounds at-bound must be exact or merge",
        )),
    }
}

fn parse_srs_rfc_barren_closure(
    input: &str,
) -> Result<SrsRfcBarrenClosure, ProveStrategyParseError> {
    match normalize_prove_strategy_argument_name(input).as_str() {
        "right" | "right-extension" | "right-extension-only" => Ok(SrsRfcBarrenClosure::Right),
        "full" | "matchbox" => Ok(SrsRfcBarrenClosure::Full),
        _ => Err(prove_strategy_parse_error(
            "rfc-match-bounds closure must be right or full",
        )),
    }
}

fn parse_prove_strategy_condition(
    input: &str,
) -> Result<ProveStrategyCondition, ProveStrategyParseError> {
    let input = strip_outer_parentheses(input.trim());
    if let Some(inner) = function_arguments(input, "rules-at-least") {
        let minimum = inner.trim().parse::<usize>().map_err(|_| {
            prove_strategy_parse_error("rules-at-least expects one nonnegative integer")
        })?;
        return Ok(ProveStrategyCondition::RulesAtLeast(minimum));
    }
    if let Some(inner) = function_arguments(input, "rules-at-most") {
        let maximum = inner.trim().parse::<usize>().map_err(|_| {
            prove_strategy_parse_error("rules-at-most expects one nonnegative integer")
        })?;
        return Ok(ProveStrategyCondition::RulesAtMost(maximum));
    }
    if let Some(inner) = function_arguments(input, "not") {
        return Ok(ProveStrategyCondition::Not(Box::new(
            parse_prove_strategy_condition(inner.trim())?,
        )));
    }
    if let Some(inner) = function_arguments(input, "all") {
        let conditions = split_top_level(inner, ',')
            .into_iter()
            .map(str::trim)
            .filter(|condition| !condition.is_empty())
            .map(parse_prove_strategy_condition)
            .collect::<Result<Vec<_>, _>>()?;
        if conditions.is_empty() {
            return Err(prove_strategy_parse_error(
                "all condition expects at least one argument",
            ));
        }
        return Ok(ProveStrategyCondition::All(conditions));
    }
    if let Some(inner) = function_arguments(input, "any") {
        let conditions = split_top_level(inner, ',')
            .into_iter()
            .map(str::trim)
            .filter(|condition| !condition.is_empty())
            .map(parse_prove_strategy_condition)
            .collect::<Result<Vec<_>, _>>()?;
        if conditions.is_empty() {
            return Err(prove_strategy_parse_error(
                "any condition expects at least one argument",
            ));
        }
        return Ok(ProveStrategyCondition::Any(conditions));
    }
    match normalize_prove_strategy_argument_name(input).as_str() {
        "csr" | "context-sensitive" | "trs-context-sensitive" | "cstrs" => {
            Ok(ProveStrategyCondition::Csr)
        }
        "transformed-csr" | "transformed-context-sensitive" | "trs-transformed-csr" => {
            Ok(ProveStrategyCondition::TransformedCsr)
        }
        "relative" | "relative-trs" | "relative-srs" => Ok(ProveStrategyCondition::Relative),
        "standard" | "full" | "trs-standard" => Ok(ProveStrategyCondition::Standard),
        "innermost" | "trs-innermost" => Ok(ProveStrategyCondition::Innermost),
        "outermost" | "trs-outermost" => Ok(ProveStrategyCondition::Outermost),
        "applicative" | "atrs" | "applicative-trs" => Ok(ProveStrategyCondition::Applicative),
        "strict-srs" | "encoded-srs" | "tpdb-srs" => Ok(ProveStrategyCondition::StrictSrs),
        "unary-srs" | "unary-trs" | "effective-srs" => Ok(ProveStrategyCondition::UnarySrs),
        "srs" | "string-rewriting" => Ok(ProveStrategyCondition::Srs),
        "" => Err(prove_strategy_parse_error("empty strategy condition")),
        condition => Err(prove_strategy_parse_error(format!(
            "unknown strategy condition `{condition}`"
        ))),
    }
}

struct NamedProveStrategyArgs {
    values: BTreeMap<String, String>,
    atom: String,
}

impl NamedProveStrategyArgs {
    fn parse(args: &[&str], atom: &str) -> Result<Self, ProveStrategyParseError> {
        let mut values = BTreeMap::new();
        for arg in args {
            let Some((name, value)) = arg.split_once('=') else {
                return Err(prove_strategy_parse_error(format!(
                    "{atom} cannot mix positional and named arguments"
                )));
            };
            let name = normalize_prove_strategy_argument_name(name);
            let value = value.trim();
            if name.is_empty() || value.is_empty() {
                return Err(prove_strategy_parse_error(format!(
                    "{atom} named arguments must be like name=value"
                )));
            }
            if values.insert(name.clone(), value.to_string()).is_some() {
                return Err(prove_strategy_parse_error(format!(
                    "{atom} argument `{name}` is repeated"
                )));
            }
        }
        Ok(Self {
            values,
            atom: atom.to_string(),
        })
    }

    fn required_i64(&self, names: &[&str], label: &str) -> Result<i64, ProveStrategyParseError> {
        self.value(names, label)?.parse().map_err(|_| {
            prove_strategy_parse_error(format!("{} {label} must be numeric", self.atom))
        })
    }

    fn optional_usize(
        &self,
        names: &[&str],
        label: &str,
    ) -> Result<Option<usize>, ProveStrategyParseError> {
        self.optional_value(names)
            .map(|value| {
                value.parse().map_err(|_| {
                    prove_strategy_parse_error(format!("{} {label} must be numeric", self.atom))
                })
            })
            .transpose()
    }

    fn value(&self, names: &[&str], label: &str) -> Result<&str, ProveStrategyParseError> {
        self.optional_value(names).ok_or_else(|| {
            prove_strategy_parse_error(format!("{} missing required {label}", self.atom))
        })
    }

    fn optional_value(&self, names: &[&str]) -> Option<&str> {
        names
            .iter()
            .map(|name| normalize_prove_strategy_argument_name(name))
            .find_map(|name| self.values.get(&name).map(String::as_str))
    }
}

fn normalize_prove_strategy_argument_name(name: &str) -> String {
    name.trim().to_ascii_lowercase().replace('_', "-")
}

fn parse_strategy_definition(
    input: &str,
) -> Result<Option<(String, &str)>, ProveStrategyParseError> {
    if let Some(definition) = input.strip_prefix("let ") {
        return parse_named_strategy_definition(definition, '=').map(Some);
    }
    if let Some(definition) = input.strip_prefix("def ") {
        return parse_named_strategy_definition(definition, '=').map(Some);
    }
    if let Some((name, value)) = input.split_once(":=") {
        let name = normalize_strategy_name(name.trim())?;
        if value.trim().is_empty() {
            return Err(prove_strategy_parse_error(
                "strategy definition body is empty",
            ));
        }
        return Ok(Some((name, value)));
    }
    Ok(None)
}

fn parse_named_strategy_definition(
    input: &str,
    separator: char,
) -> Result<(String, &str), ProveStrategyParseError> {
    let Some((name, value)) = input.split_once(separator) else {
        return Err(prove_strategy_parse_error(
            "strategy definition must be like `let name = strategy`",
        ));
    };
    let name = normalize_strategy_name(name.trim())?;
    if value.trim().is_empty() {
        return Err(prove_strategy_parse_error(
            "strategy definition body is empty",
        ));
    }
    Ok((name, value))
}

fn normalize_strategy_name(name: &str) -> Result<String, ProveStrategyParseError> {
    let name = name.trim();
    if name.is_empty() {
        return Err(prove_strategy_parse_error(
            "strategy definition name is empty",
        ));
    }
    let mut chars = name.chars();
    let Some(first) = chars.next() else {
        return Err(prove_strategy_parse_error(
            "strategy definition name is empty",
        ));
    };
    if !(first.is_ascii_alphabetic() || first == '_') {
        return Err(prove_strategy_parse_error(
            "strategy definition name must start with a letter or underscore",
        ));
    }
    if !chars.all(|ch| ch.is_ascii_alphanumeric() || ch == '_' || ch == '-') {
        return Err(prove_strategy_parse_error(
            "strategy definition name may only contain letters, numbers, underscores, or hyphens",
        ));
    }
    Ok(name.to_ascii_lowercase())
}

fn parse_parallel_arguments(
    parser: &ProveStrategyParser<'_>,
    input: &str,
) -> Result<Vec<ProveStrategy>, ProveStrategyParseError> {
    for separator in ['|', ';', ','] {
        let parts = split_top_level(input, separator);
        if parts.len() > 1 {
            let strategies = parts
                .into_iter()
                .map(str::trim)
                .filter(|part| !part.is_empty())
                .map(|part| parser.parse_choice(part))
                .collect::<Result<Vec<_>, _>>()?;
            if strategies.is_empty() {
                return Err(prove_strategy_parse_error(
                    "parallel expects at least one strategy",
                ));
            }
            return Ok(strategies);
        }
    }
    Ok(vec![parser.parse_choice(input.trim())?])
}

fn split_top_level(input: &str, separator: char) -> Vec<&str> {
    let mut parts = Vec::new();
    let mut depth = 0usize;
    let mut start = 0usize;
    for (index, ch) in input.char_indices() {
        match ch {
            '(' => depth += 1,
            ')' => depth = depth.saturating_sub(1),
            _ if ch == separator && depth == 0 => {
                parts.push(&input[start..index]);
                start = index + ch.len_utf8();
            }
            _ => {}
        }
    }
    parts.push(&input[start..]);
    parts
}

fn strip_outer_parentheses(input: &str) -> &str {
    let mut current = input;
    while current.starts_with('(') && current.ends_with(')') && parentheses_enclose(current) {
        current = current[1..current.len() - 1].trim();
    }
    current
}

fn parentheses_enclose(input: &str) -> bool {
    let mut depth = 0usize;
    for (index, ch) in input.char_indices() {
        match ch {
            '(' => depth += 1,
            ')' => {
                depth = depth.saturating_sub(1);
                if depth == 0 && index + ch.len_utf8() != input.len() {
                    return false;
                }
            }
            _ => {}
        }
    }
    depth == 0
}

fn function_arguments<'a>(input: &'a str, name: &str) -> Option<&'a str> {
    input
        .strip_prefix(name)?
        .trim()
        .strip_prefix('(')?
        .strip_suffix(')')
        .filter(|_| parentheses_enclose(input))
}

fn parse_strategy_duration(input: &str) -> Result<Duration, ProveStrategyParseError> {
    if let Some(milliseconds) = input.strip_suffix("ms") {
        return milliseconds
            .trim()
            .parse()
            .map(Duration::from_millis)
            .map_err(|_| prove_strategy_parse_error("invalid millisecond timeout"));
    }
    if let Some(seconds) = input.strip_suffix('s') {
        return seconds
            .trim()
            .parse()
            .map(Duration::from_secs)
            .map_err(|_| prove_strategy_parse_error("invalid second timeout"));
    }
    input
        .parse()
        .map(Duration::from_millis)
        .map_err(|_| prove_strategy_parse_error("timeout must be like 250ms or 2s"))
}

impl Default for ProveOptions {
    fn default() -> Self {
        Self {
            strategy: ProveStrategy::default_from_file(),
            llm_first: true,
            llm_proposals: Vec::new(),
            llm_client: None,
            utility_guidance: None,
            llm_iterations: 2,
            synthesize_kbo: true,
            max_symbol_weight: 2,
            max_synthesis_symbols: usize::MAX,
            synthesize_smt_polynomial: true,
            synthesize_path_order: true,
            max_polynomial_constant: 2,
            max_polynomial_coefficient: 1,
            max_polynomial_symbols: usize::MAX,
            max_polynomial_arity: usize::MAX,
            dependency_pairs: true,
            dp_options: DpOptions::default(),
        }
    }
}

pub fn prove(trs: &Trs, options: &ProveOptions) -> Proof {
    let deadline = prove_strategy_wall_clock_deadline(&options.strategy, trs);
    // A unary encoding is an SRS state only under full rewriting.  Innermost
    // and outermost unary TRSs have different semantics and must retain their
    // strategy so DP/Q and strategy-specific processors remain applicable.
    let state = if trs.strategy() == RewriteStrategy::Full && trs.srs_rules().is_some() {
        ProblemState::Srs(trs.clone())
    } else {
        ProblemState::Trs(trs.clone())
    };
    let proof =
        match super::processors::top_level::solve_top_level_worklist(state, options, deadline) {
            Ok(ProblemCertificate::Trs(proof)) => proof,
            Ok(_) => Proof::unknown(
                "top-level worklist returned a certificate of the wrong problem kind",
                Vec::new(),
            ),
            Err(failure) => Proof::unknown(failure.to_string(), Vec::new()),
        };
    proof
}

pub fn prove_context_sensitive(csr: &CsrTrs, options: &ProveOptions) -> Proof {
    let deadline = prove_strategy_wall_clock_deadline(&options.strategy, csr.trs());
    match super::processors::top_level::solve_top_level_worklist(
        ProblemState::Csr(CsrProblemState::root(csr.clone())),
        options,
        deadline,
    ) {
        Ok(ProblemCertificate::Trs(proof)) => proof,
        Ok(_) => Proof::unknown(
            "context-sensitive worklist returned a certificate of the wrong problem kind",
            Vec::new(),
        ),
        Err(failure) => Proof::unknown(failure.to_string(), Vec::new()),
    }
}

pub fn prove_relative(relative: &RelativeTrs, options: &ProveOptions) -> Proof {
    let strict = relative.strict();
    if strict.is_empty() {
        return Proof::terminating(vec![ProofStep::EmptySystem]);
    }

    let deadline = prove_strategy_wall_clock_deadline(&options.strategy, strict)
        .or_else(|| Some(Instant::now() + Duration::from_secs(30)));

    let state = if relative.strict().srs_rules().is_some() {
        ProblemState::RelativeSrs(relative.clone())
    } else {
        ProblemState::RelativeTrs(relative.clone())
    };
    match super::processors::top_level::solve_top_level_worklist(state, options, deadline) {
        Ok(ProblemCertificate::Trs(proof)) => proof,
        Ok(_) => Proof::unknown(
            "relative worklist returned a certificate of the wrong problem kind",
            Vec::new(),
        ),
        Err(failure) => Proof::unknown(failure.to_string(), Vec::new()),
    }
}
fn prove_strategy_wall_clock_deadline(strategy: &ProveStrategy, trs: &Trs) -> Option<Instant> {
    prove_strategy_wall_clock_budget(strategy, trs).map(|duration| Instant::now() + duration)
}

fn prove_strategy_wall_clock_budget(strategy: &ProveStrategy, trs: &Trs) -> Option<Duration> {
    match strategy {
        ProveStrategy::Timeout { duration, .. } => Some(*duration),
        ProveStrategy::Conditional {
            condition,
            then_strategy,
            else_strategy,
        } => {
            if evaluate_prove_strategy_condition(condition, trs) {
                prove_strategy_wall_clock_budget(then_strategy, trs)
            } else {
                prove_strategy_wall_clock_budget(else_strategy, trs)
            }
        }
        ProveStrategy::Delay { strategy, .. } => prove_strategy_wall_clock_budget(strategy, trs),
        ProveStrategy::Sequence(strategies)
        | ProveStrategy::Choice(strategies)
        | ProveStrategy::Parallel(strategies) => strategies
            .iter()
            .filter_map(|strategy| prove_strategy_wall_clock_budget(strategy, trs))
            .max(),
        ProveStrategy::Processor(_) => None,
    }
}

fn top_level_strategy_from_status_prediction(
    prediction: &crate::llm::StatusMapPrediction,
) -> Option<ProveStrategy> {
    let mut strategies = Vec::new();
    let ordered_evidence = !prediction.ordered_positive.is_empty();
    let mut atoms = if !ordered_evidence {
        prediction
            .solved
            .iter()
            .map(|atom| (0u8, atom))
            .chain(prediction.transformed_strong.iter().map(|atom| (1u8, atom)))
            .chain(prediction.transformed_weak.iter().map(|atom| (2u8, atom)))
            .collect::<Vec<_>>()
    } else {
        prediction
            .ordered_positive
            .iter()
            .map(|atom| (0u8, atom))
            .collect::<Vec<_>>()
    };
    // State-first v2 exports already carry the authoritative evidence order.
    // Keep it intact; status-based resorting can displace the exact
    // transformation whose residual continuation is recorded. Legacy maps
    // without `ordered_positive` retain the exact-witness tie-breaker.
    if !ordered_evidence {
        atoms.sort_by_key(|(rank, atom)| (*rank, !atom.starts_with("exact-")));
    }
    for (_, atom) in atoms {
        match ProveStrategy::parse(atom) {
            Ok(strategy) if certified_linear_oracle_processor(&strategy).is_some() => {
                strategies.push(ProveStrategy::Timeout {
                    duration: crate::proving::runtime::measured_oracle_atom_timeout(
                        guided_top_level_atom_timeout(atom),
                        prediction.measured_elapsed_ms.get(atom.as_str()).copied(),
                    ),
                    strategy: Box::new(ProveStrategy::Processor(
                        certified_linear_oracle_processor(&strategy)
                            .expect("guard established a certified linear sequence"),
                    )),
                });
            }
            Ok(strategy) if is_atomic_oracle_strategy(&strategy) => {
                strategies.push(ProveStrategy::Timeout {
                    duration: crate::proving::runtime::measured_oracle_atom_timeout(
                        guided_top_level_atom_timeout(atom),
                        prediction.measured_elapsed_ms.get(atom.as_str()).copied(),
                    ),
                    strategy: Box::new(strategy),
                });
            }
            Ok(_) if std::env::var_os("FERRUM_WORKLIST_TRACE").is_some() => {
                let prefix = atom.chars().take(80).collect::<String>();
                eprintln!(
                    "worklist ignored composed oracle advice prefix={prefix:?} bytes={}",
                    atom.len()
                );
            }
            Ok(_) => {}
            Err(error) if std::env::var_os("FERRUM_WORKLIST_TRACE").is_some() => {
                let prefix = atom.chars().take(80).collect::<String>();
                eprintln!(
                    "worklist ignored oracle atom prefix={prefix:?} bytes={}: {error}",
                    atom.len()
                );
            }
            Err(_) => {}
        }
    }
    dedup_top_level_strategies(&mut strategies);
    // Oracle entries are ordered evidence, not a portfolio suggestion.  A
    // parallel race can let a fast transformation beat a slightly slower
    // certified closing action; the resulting child may have a different
    // serialization and no local guidance yet.  Try the retained actions in
    // order instead.  This is deterministic, still backtracks when an old
    // atom no longer applies, and only accepts a transformation after all
    // higher-ranked closing candidates have been tried.
    (!strategies.is_empty()).then_some(ProveStrategy::Choice(strategies))
}

fn certified_linear_oracle_processor(strategy: &ProveStrategy) -> Option<ProveStrategyProcessor> {
    let ProveStrategy::Sequence(steps) = strategy else {
        return None;
    };
    if steps.len() < 2 {
        return None;
    }
    let processors = steps
        .iter()
        .map(|step| match step {
            ProveStrategy::Processor(
                processor @ (ProveStrategyProcessor::ExactLinearPolynomial { .. }
                | ProveStrategyProcessor::ExactMatrixInterpretation { .. }),
            ) => Some(processor.clone()),
            _ => None,
        })
        .collect::<Option<Vec<_>>>()?;
    Some(ProveStrategyProcessor::CertifiedLinearSequence(processors))
}

/// Oracle guidance selects exactly one processor for the current state.
///
/// Strategy files may still use sequencing, choice, races, and timeouts to
/// define an unguided portfolio.  Persisted oracle records may not: every
/// transformation must expose its residuals to the worklist so the next
/// processor is selected from the child state's own key.  In particular,
/// `dp(graph;...)` and the older transformation-with-continuation spellings
/// are archived evidence, not executable guidance.
fn is_atomic_oracle_strategy(strategy: &ProveStrategy) -> bool {
    let ProveStrategy::Processor(processor) = strategy else {
        return false;
    };
    match processor {
        ProveStrategyProcessor::NonterminationSearch
        | ProveStrategyProcessor::Fail
        // Although this is represented by one top-level enum variant, the
        // enclosed DP strategy is a complete continuation.  Accepting it as
        // an oracle atom hides every DP residual from state-local lookup and
        // lets an old portfolio outrank the independently replayable `dp`
        // transformation.  In particular, a stale narrowing choice in the
        // archived fact-hard recipe could never be repaired by newly learned
        // child-state evidence.
        | ProveStrategyProcessor::DependencyPairsWithStrategy(_)
        | ProveStrategyProcessor::TrimmedDependencyPairsWithStrategy(_) => false,
        _ => true,
    }
}

#[cfg(test)]
mod trimmed_oracle_tests {
    use super::*;

    #[test]
    fn trimmed_dp_oracle_accepts_only_the_state_local_transformation() {
        assert!(is_atomic_oracle_strategy(&ProveStrategy::parse("dp-trimmed").unwrap()));
        assert!(!is_atomic_oracle_strategy(
            &ProveStrategy::parse("dp-trimmed(graph; size-change)").unwrap(),
        ));
    }
}

pub(crate) fn worklist_guidance_strategy_for_trs(
    trs: &Trs,
    options: &ProveOptions,
) -> Option<ProveStrategy> {
    let lookup = options.utility_guidance.as_ref()?;
    let raw = write_trs_input_cpf3(trs);
    let raw_prediction = lookup.predict(&raw);
    // Exact runtime-state aliases are stronger than canonical guidance and
    // already preserve the complete serialized obligation.  Do not perform
    // potentially expensive symbol canonicalization after such a hit.  This
    // is especially important for large, highly symmetric transformed-CSR
    // TRSs, where canonicalization can dominate an otherwise millisecond
    // exact-witness replay.
    let prediction = if raw_prediction.as_ref().is_some_and(|prediction| {
        !prediction.solved.is_empty() || !prediction.transformed_strong.is_empty()
            || (lookup.has_replay_order(&raw) && !prediction.ordered_positive.is_empty())
    }) {
        raw_prediction
    } else {
        let (canonical, error) = standardized_trs_input_cpf3(trs);
        if error.is_some() {
            raw_prediction
        } else {
            if std::env::var_os("FERRUM_WORKLIST_TRACE").is_some() {
                eprintln!(
                    "worklist trs canonical key={:x}",
                    <sha2::Sha256 as sha2::Digest>::digest(canonical.trim().as_bytes())
                );
            }
            lookup.predict_prefer_canonical(
                &raw,
                &canonical,
                trs.strategy() == crate::core::RewriteStrategy::Full,
            )
        }
    }?;
    top_level_strategy_from_status_prediction(&prediction)
}

/// Deferred canonical alternatives, considered only after the exact schedule
/// has failed. This preserves the cheap exact-hit path without making stale
/// exact evidence permanently hide independently checked portable actions.
pub(crate) fn worklist_canonical_guidance_for_trs(trs: &Trs, options: &ProveOptions) -> Option<ProveStrategy> {
    let lookup = options.utility_guidance.as_ref()?;
    let raw = write_trs_input_cpf3(trs);
    let (canonical, error) = standardized_trs_input_cpf3(trs);
    if error.is_some() { return None; }
    let prediction = lookup.predict_prefer_canonical(&raw, &canonical,
        trs.strategy() == crate::core::RewriteStrategy::Full)?;
    top_level_strategy_from_status_prediction(&prediction)
}

pub(crate) fn worklist_guidance_strategy_for_csr(
    state: &CsrProblemState,
    options: &ProveOptions,
) -> Option<ProveStrategy> {
    let lookup = options.utility_guidance.as_ref()?;
    let nested = state.boundary != CsrProofBoundary::Root;
    let raw = crate::cert::write_csr_state_input_cpf4(&state.csr, state.boundary);
    let raw_prediction = lookup.predict(&raw);
    let boundaryless = crate::cert::write_csr_state_input_cpf4(&state.csr, CsrProofBoundary::Root);
    let boundary_prediction = if nested {
        lookup.predict_prefer_canonical(&raw, &boundaryless, false)
    } else {
        raw_prediction.clone()
    };
    let prediction = if boundary_prediction.as_ref().is_some_and(|prediction| {
        !prediction.solved.is_empty() || !prediction.transformed_strong.is_empty()
    }) {
        boundary_prediction
    } else {
        let (canonical, error) = standardized_csr_input_cpf4(&state.csr);
        if error.is_some() {
            boundary_prediction
        } else {
            // The proof boundary controls how a solved child is reconstructed
            // into its parent certificate; it does not change the CSR
            // reduction relation or processor applicability.  Keep the marker
            // in the exact runtime state above, but omit it from the canonical
            // semantic lookup so root and nested occurrences of the same CSR
            // share guidance.
            lookup.predict_prefer_canonical(&boundaryless, &canonical, false)
                .filter(|p| !p.solved.is_empty() || !p.transformed_strong.is_empty()
                    || !p.transformed_weak.is_empty())
                .or(boundary_prediction)
        }
    }?;
    top_level_strategy_from_status_prediction(&prediction)
}

pub(crate) fn worklist_guidance_strategy_for_relative(
    relative: &RelativeTrs,
    options: &ProveOptions,
) -> Option<ProveStrategy> {
    let lookup = options.utility_guidance.as_ref()?;
    let raw = write_relative_trs_input_cpf3(relative);
    let raw_prediction = lookup.predict(&raw);
    let prediction = if raw_prediction.as_ref().is_some_and(|prediction| {
        !prediction.solved.is_empty() || !prediction.transformed_strong.is_empty()
    }) {
        raw_prediction
    } else {
        let (canonical, error) = standardized_relative_trs_input_cpf3(relative);
        if error.is_some() {
            raw_prediction
        } else {
            lookup.predict_prefer_canonical(&raw, &canonical, false)
        }
    }?;
    top_level_strategy_from_status_prediction(&prediction)
}

fn guided_top_level_atom_timeout(atom: &str) -> Duration {
    // A certified composition may contain a cheap parent transformation and
    // a substantially more expensive closing child.  Classifying it only by
    // the first family (for example `matrix; csr-safe-dp`) reinstates the
    // matrix family's eight-second cap and truncates the retained proof.
    if split_top_level(atom, ';').len() > 1 {
        return Duration::from_secs(60);
    }
    let family = atom.split_once('(').map_or(atom, |(family, _)| family);
    match family.to_ascii_lowercase().as_str() {
        // The caller's strategy deadline is the campaign/replay ceiling.  Do
        // not impose a second hidden 60-second boundary on a certified DP
        // recipe: strict campaigns still pass a 60-second outer deadline,
        // while deliberately lenient replay can diagnose slower-but-findable
        // guidance without changing the atom or its CPF shape.
        "dp" | "dependency-pairs" => Duration::from_secs(300),
        // These are dependency-pair searches too.  Treating unparameterized
        // aliases as generic processors gave them the two-second default and
        // made retained, CeTA-certified CSR recipes unreachable during a
        // 60-second oracle-only replay.
        "fast-dp"
        | "dp-fast"
        | "dependency-pairs-fast"
        | "csr-safe-dp"
        | "safe-csr-dp"
        | "csr-improved-dp"
        | "improved-csr-dp"
        | "csr-conservative-dp"
        | "conservative-csr-dp"
        | "csr-gm-transform"
        | "gm-csr-transform" => Duration::from_secs(60),
        "switch-innermost" => Duration::from_secs(60),
        "nontermination" => Duration::from_secs(60),
        "uncurry" | "uncurrying" | "string-reversal" | "stringreversal" | "reverse-srs"
        | "reverse" => Duration::from_secs(55),
        "exact-match-bounds" | "exact-relative-match-bounds" => Duration::from_secs(60),
        "poly" | "smt-poly" | "smt-polynomial" => Duration::from_secs(8),
        "exact-poly" => Duration::from_secs(60),
        "kbo" | "path-order" | "rpo" | "lpo" => Duration::from_secs(60),
        _ => Duration::from_secs(2),
    }
}

fn dedup_top_level_strategies(strategies: &mut Vec<ProveStrategy>) {
    let mut seen = BTreeSet::new();
    strategies.retain(|strategy| seen.insert(format!("{strategy:?}")));
}

pub(crate) fn evaluate_prove_strategy_condition(
    condition: &ProveStrategyCondition,
    trs: &Trs,
) -> bool {
    match condition {
        ProveStrategyCondition::Csr => false,
        ProveStrategyCondition::Relative => false,
        ProveStrategyCondition::TransformedCsr => looks_like_standard_transformed_csr(trs),
        ProveStrategyCondition::Standard => trs.strategy() == RewriteStrategy::Full,
        ProveStrategyCondition::Innermost => trs.strategy() == RewriteStrategy::Innermost,
        ProveStrategyCondition::Outermost => trs.strategy() == RewriteStrategy::Outermost,
        ProveStrategyCondition::Applicative => infer_uncurrying_application_symbol(trs).is_some(),
        ProveStrategyCondition::StrictSrs => trs.is_srs_encoded(),
        ProveStrategyCondition::UnarySrs => trs.unary_srs_rules().is_some(),
        ProveStrategyCondition::Srs => {
            trs.is_srs_encoded()
                || trs.unary_srs_rules().is_some()
                || cons_encoded_srs_rules(trs).is_some()
        }
        ProveStrategyCondition::RulesAtLeast(minimum) => trs.rules().len() >= *minimum,
        ProveStrategyCondition::RulesAtMost(maximum) => trs.rules().len() <= *maximum,
        ProveStrategyCondition::Not(condition) => {
            !evaluate_prove_strategy_condition(condition, trs)
        }
        ProveStrategyCondition::All(conditions) => conditions
            .iter()
            .all(|condition| evaluate_prove_strategy_condition(condition, trs)),
        ProveStrategyCondition::Any(conditions) => conditions
            .iter()
            .any(|condition| evaluate_prove_strategy_condition(condition, trs)),
    }
}

pub(crate) fn evaluate_csr_prove_strategy_condition(
    condition: &ProveStrategyCondition,
    csr: &CsrTrs,
) -> bool {
    match condition {
        ProveStrategyCondition::Csr => true,
        ProveStrategyCondition::Relative => false,
        ProveStrategyCondition::TransformedCsr => true,
        ProveStrategyCondition::Standard => csr.trs().strategy() == RewriteStrategy::Full,
        ProveStrategyCondition::Innermost => csr.trs().strategy() == RewriteStrategy::Innermost,
        ProveStrategyCondition::Outermost => csr.trs().strategy() == RewriteStrategy::Outermost,
        ProveStrategyCondition::Applicative => {
            infer_uncurrying_application_symbol(csr.trs()).is_some()
        }
        ProveStrategyCondition::StrictSrs => csr.trs().is_srs_encoded(),
        ProveStrategyCondition::UnarySrs => csr.trs().unary_srs_rules().is_some(),
        ProveStrategyCondition::Srs => {
            csr.trs().is_srs_encoded() || csr.trs().unary_srs_rules().is_some()
        }
        ProveStrategyCondition::RulesAtLeast(minimum) => csr.rules().len() >= *minimum,
        ProveStrategyCondition::RulesAtMost(maximum) => csr.rules().len() <= *maximum,
        ProveStrategyCondition::Not(condition) => {
            !evaluate_csr_prove_strategy_condition(condition, csr)
        }
        ProveStrategyCondition::All(conditions) => conditions
            .iter()
            .all(|condition| evaluate_csr_prove_strategy_condition(condition, csr)),
        ProveStrategyCondition::Any(conditions) => conditions
            .iter()
            .any(|condition| evaluate_csr_prove_strategy_condition(condition, csr)),
    }
}

#[cfg(test)]
mod tests {
    use std::collections::{BTreeMap, BTreeSet};
    use std::fs;
    use std::path::Path;
    use std::process::Command;

    use crate::cert::write_cpf_csr;
    use crate::core::{
        RelativeTrs, ReplacementMap, RewriteRule, RewriteStrategy, Symbol, Term, Trs, Variable,
    };
    use crate::llm::LinearPolynomial;
    use crate::parsing::parse_trs;
    use crate::proving::TreeAutomatonTransitionLhs;
    use crate::proving::dependency_pairs::DpArgumentFilterEntry;
    use crate::proving::processors::top_level::remove_non_applicable_rules;
    use crate::proving::processors::top_level::smt::command_exists as top_smt_command_exists;
    use crate::proving::processors::top_level::srs::{
        reverse_srs_rules, srs_word_to_term, strict_srs_word_with_tail,
    };
    use crate::proving::processors::top_level::uncurrying::synthesize_uncurrying_transform;
    use crate::proving::processors::top_level::{
        EmptySystemProcessor, ExactSrsMatchBoundsProcessor, SrsLengthProcessor,
        SrsRelativeMatchBoundsProcessor, SrsRfcRelativeMatchBoundsProcessor,
        SrsWeightedLengthProcessor, SrsWeightedRuleRemovalProcessor, UncurryProcessor,
    };
    use crate::proving::processors::{
        LazyProcessorAttempt, ProblemCertificate, ProblemState, ProcessorResult, WorklistProcessor,
        solve_worklist_lazy,
    };
    use crate::proving::runtime::CancellationScope;
    use sha2::{Digest, Sha256};

    use super::*;

    fn solved_trs_proof(result: ProcessorResult) -> Option<Proof> {
        let ProcessorResult::Applied(application) = result else {
            return None;
        };
        if !application.residuals.is_empty() {
            return None;
        }
        let ProblemCertificate::Trs(proof) = application.reconstruct(Vec::new())? else {
            return None;
        };
        Some(proof)
    }

    fn atomic_rfc_relative_match_bounds_proof(
        trs: &Trs,
        max_bound: usize,
        max_words: usize,
        max_word_len: usize,
        max_states: usize,
        max_transitions: usize,
        at_bound: SrsMatchAtBound,
        closure: SrsRfcBarrenClosure,
        deadline: Option<Instant>,
    ) -> Option<Proof> {
        let ProcessorResult::Applied(application) = (SrsRfcRelativeMatchBoundsProcessor {
            allow_partial: false,
            absolute_residual: false,
            layered_seconds: 2,
            fresh_seconds: 2,
            min_bound: 0,
            max_bound,
            max_words,
            max_word_len,
            max_states,
            max_transitions,
            at_bound,
            closure,
            deadline,
        })
        .apply(&ProblemState::Srs(trs.clone())) else {
            return None;
        };
        let [ProblemState::RelativeSrs(residual)] = application.residuals.as_slice() else {
            return None;
        };
        if !residual.strict().is_empty() {
            return None;
        }
        let empty = ProblemCertificate::Trs(Proof::terminating(vec![ProofStep::EmptySystem]));
        let ProblemCertificate::Trs(proof) = application.reconstruct(vec![empty])? else {
            return None;
        };
        Some(proof)
    }

    fn atomic_relative_match_bounds_proof(
        trs: &Trs,
        max_bound: usize,
        max_states: usize,
        max_transitions: usize,
        deadline: Option<Instant>,
    ) -> Option<Proof> {
        let [ProblemCertificate::Trs(proof)] = <[ProblemCertificate; 1]>::try_from(
            solve_worklist_lazy(
                vec![ProblemState::Srs(trs.clone())],
                |state, cursor, _is_root| {
                    let result = match cursor {
                        0 => EmptySystemProcessor.apply(state),
                        1 => SrsRelativeMatchBoundsProcessor {
                            max_bound,
                            max_states,
                            max_transitions,
                            deadline,
                        }
                        .apply(state),
                        _ => return None,
                    };
                    Some(LazyProcessorAttempt::alternative(result, cursor + 1))
                },
            )
            .ok()?,
        )
        .ok()?
        else {
            return None;
        };
        Some(proof)
    }

    #[test]
    fn relative_flat_context_closure_is_complete_and_preserves_components() {
        let strict_rule = RewriteRule::new(
            Term::app("f", vec![Term::var("x")]),
            Term::app("g", vec![Term::var("x")]),
        );
        let weak_rule = RewriteRule::new(
            Term::app("f", vec![Term::app("f", vec![Term::var("x")])]),
            Term::app("f", vec![Term::var("x")]),
        );
        let relative = RelativeTrs::new(
            Trs::new_with_strategy(
                None,
                BTreeSet::from([Variable::new("x")]),
                vec![strict_rule],
                RewriteStrategy::Full,
            ),
            vec![weak_rule.clone()],
        );

        let (contexts, transformed_rules, transformed) =
            flat_context_close_relative(&relative).expect("flat contexts");

        assert_eq!(contexts.len(), 2);
        assert_eq!(transformed.strict().rules().len(), 2);
        assert_eq!(transformed.weak_rules(), &[weak_rule]);
        assert_eq!(transformed_rules.len(), 3);
    }

    #[test]
    fn relative_loop_uses_weak_steps_but_requires_a_strict_step() {
        let relative = RelativeTrs::new(
            Trs::new_with_strategy(
                None,
                BTreeSet::from([Variable::new("x")]),
                vec![RewriteRule::new(
                    Term::app("a", vec![Term::var("x")]),
                    Term::app("b", vec![Term::var("x")]),
                )],
                RewriteStrategy::Full,
            ),
            vec![RewriteRule::new(
                Term::app("b", vec![Term::var("x")]),
                Term::app("a", vec![Term::var("x")]),
            )],
        );

        let loop_proof =
            prove_relative_loop(&relative, Some(Instant::now() + Duration::from_secs(2)))
                .expect("mixed strict/weak loop");
        let proof = Proof::nonterminating(loop_proof);
        let cpf = crate::cert::write_cpf_relative(&relative, &proof, crate::cert::CpfMode::Cpf30)
            .expect("relative CPF");
        assert!(cpf.contains("<relative/>"));

        let path = std::env::temp_dir().join(format!(
            "ferrum-relative-mixed-loop-{}.cpf3.xml",
            std::process::id()
        ));
        fs::write(&path, cpf).unwrap();
        let output = Command::new("../CeTA-CSR/ceta")
            .arg(&path)
            .output()
            .unwrap();
        let _ = fs::remove_file(path);
        assert!(
            output.status.success(),
            "{}{}",
            String::from_utf8_lossy(&output.stdout),
            String::from_utf8_lossy(&output.stderr)
        );

        let weak_only = RelativeTrs::new(
            Trs::new_with_strategy(
                None,
                BTreeSet::from([Variable::new("x")]),
                vec![RewriteRule::new(
                    Term::app("c", vec![Term::var("x")]),
                    Term::app("d", vec![Term::var("x")]),
                )],
                RewriteStrategy::Full,
            ),
            vec![
                RewriteRule::new(
                    Term::app("a", vec![Term::var("x")]),
                    Term::app("b", vec![Term::var("x")]),
                ),
                RewriteRule::new(
                    Term::app("b", vec![Term::var("x")]),
                    Term::app("a", vec![Term::var("x")]),
                ),
            ],
        );
        assert!(
            prove_relative_loop(
                &weak_only,
                Some(Instant::now() + Duration::from_millis(200))
            )
            .is_none()
        );
    }

    #[test]
    fn relative_narrowing_closes_loop_through_weak_context_step() {
        let relative = RelativeTrs::new(
            Trs::new_with_strategy(
                None,
                BTreeSet::from([Variable::new("x")]),
                vec![RewriteRule::new(
                    Term::app("f", vec![Term::app("s", vec![Term::var("x")])]),
                    Term::app("f", vec![Term::var("x")]),
                )],
                RewriteStrategy::Full,
            ),
            vec![RewriteRule::new(
                Term::app("inf", vec![]),
                Term::app("s", vec![Term::app("inf", vec![])]),
            )],
        );

        assert!(matches!(
            prove_relative_loop(&relative, Some(Instant::now() + Duration::from_secs(5))),
            Some(NonterminationProof::Loop(_))
        ));
    }

    #[test]
    fn outermost_termination_uses_a_full_termination_obligation() {
        let trs = crate::parsing::parse_ari_trs(
            Some("TRS_Outermost/outermost_simple.ari".to_string()),
            include_str!("../../tests/fixtures/outermost_simple.ari"),
        )
        .unwrap();
        let options = ProveOptions {
            strategy: ProveStrategy::parse("poly(max-constant=2,max-coefficient=2)").unwrap(),
            llm_first: false,
            ..ProveOptions::default()
        };
        assert_eq!(prove(&trs, &options).status(), &Status::Terminating);
    }

    #[test]
    fn full_nontermination_is_not_lifted_to_outermost_nontermination() {
        let trs = Trs::new_with_strategy(
            None,
            BTreeSet::from([Variable::new("x")]),
            vec![
                RewriteRule::new(
                    Term::app("a", vec![]),
                    Term::app("f", vec![Term::app("a", vec![])]),
                ),
                RewriteRule::new(Term::app("f", vec![Term::var("x")]), Term::app("b", vec![])),
            ],
            RewriteStrategy::Outermost,
        );
        let options = ProveOptions {
            strategy: ProveStrategy::parse("nontermination(loop)").unwrap(),
            llm_first: false,
            ..ProveOptions::default()
        };
        assert_eq!(prove(&trs, &options).status(), &Status::Unknown);
    }

    #[test]
    fn root_loop_proves_outermost_nontermination() {
        let trs = Trs::new_with_strategy(
            None,
            BTreeSet::from([Variable::new("x")]),
            vec![RewriteRule::new(
                Term::app("f", vec![Term::var("x")]),
                Term::app("f", vec![Term::var("x")]),
            )],
            RewriteStrategy::Outermost,
        );
        let options = ProveOptions {
            strategy: ProveStrategy::parse("nontermination(loop)").unwrap(),
            llm_first: false,
            ..ProveOptions::default()
        };
        assert_eq!(prove(&trs, &options).status(), &Status::Nonterminating);
    }

    #[test]
    fn concrete_nonroot_cycle_proves_outermost_nontermination() {
        let a = Term::app("a", vec![]);
        let b = Term::app("b", vec![]);
        let trs = Trs::new_with_strategy(
            None,
            BTreeSet::new(),
            vec![
                RewriteRule::new(
                    Term::app("f", vec![a.clone()]),
                    Term::app("f", vec![b.clone()]),
                ),
                RewriteRule::new(b, a),
            ],
            RewriteStrategy::Outermost,
        );
        let options = ProveOptions {
            strategy: ProveStrategy::parse("nontermination(loop)").unwrap(),
            llm_first: false,
            ..ProveOptions::default()
        };
        assert_eq!(prove(&trs, &options).status(), &Status::Nonterminating);
    }

    #[test]
    fn contextual_loop_proves_outermost_nontermination() {
        let a = Term::app("a", vec![]);
        let b = Term::app("b", vec![]);
        let trs = Trs::new_with_strategy(
            None,
            BTreeSet::new(),
            vec![
                RewriteRule::new(a.clone(), Term::app("f", vec![b.clone()])),
                RewriteRule::new(b, a),
            ],
            RewriteStrategy::Outermost,
        );
        let options = ProveOptions {
            strategy: ProveStrategy::parse("nontermination(loop)").unwrap(),
            llm_first: false,
            ..ProveOptions::default()
        };
        assert_eq!(prove(&trs, &options).status(), &Status::Nonterminating);
    }

    #[test]
    fn symbolic_context_loop_allows_defined_but_nonunifiable_context_root() {
        let trs = Trs::new_with_strategy(
            None,
            BTreeSet::from([Variable::new("x")]),
            vec![
                RewriteRule::new(
                    Term::app("a", vec![Term::var("x")]),
                    Term::app(
                        "f",
                        vec![Term::app("a", vec![Term::app("g", vec![Term::var("x")])])],
                    ),
                ),
                RewriteRule::new(
                    Term::app("f", vec![Term::app("b", vec![])]),
                    Term::app("c", vec![]),
                ),
            ],
            RewriteStrategy::Outermost,
        );
        let options = ProveOptions {
            strategy: ProveStrategy::parse("nontermination(loop)").unwrap(),
            llm_first: false,
            ..ProveOptions::default()
        };
        assert_eq!(prove(&trs, &options).status(), &Status::Nonterminating);
    }

    #[test]
    fn symbolic_nonroot_cycle_proves_outermost_nontermination() {
        let trs = Trs::new_with_strategy(
            None,
            BTreeSet::from([Variable::new("x"), Variable::new("y"), Variable::new("z")]),
            vec![
                RewriteRule::new(
                    Term::app("f", vec![Term::var("x"), Term::app("a", vec![])]),
                    Term::app("f", vec![Term::var("x"), Term::app("b", vec![])]),
                ),
                RewriteRule::new(Term::app("b", vec![]), Term::app("a", vec![])),
                RewriteRule::new(
                    Term::app("f", vec![Term::app("a", vec![]), Term::var("x")]),
                    Term::app("a", vec![]),
                ),
                RewriteRule::new(
                    Term::app("f", vec![Term::app("b", vec![]), Term::var("x")]),
                    Term::app("a", vec![]),
                ),
                RewriteRule::new(
                    Term::app(
                        "f",
                        vec![
                            Term::app("f", vec![Term::var("x"), Term::var("y")]),
                            Term::var("z"),
                        ],
                    ),
                    Term::app("a", vec![]),
                ),
            ],
            RewriteStrategy::Outermost,
        );
        assert!(
            super::super::nontermination::bounded_outermost_symbolic_cycle(&trs, None).is_some()
        );
    }

    #[test]
    fn extra_variable_rule_proves_outermost_nontermination() {
        let trs = Trs::new_with_strategy(
            None,
            BTreeSet::from([Variable::new("x")]),
            vec![RewriteRule::new(
                Term::app("and", vec![Term::app("true", vec![])]),
                Term::var("x"),
            )],
            RewriteStrategy::Outermost,
        );
        let options = ProveOptions {
            strategy: ProveStrategy::parse("nontermination(loop)").unwrap(),
            llm_first: false,
            ..ProveOptions::default()
        };
        assert_eq!(prove(&trs, &options).status(), &Status::Nonterminating);
    }

    #[test]
    fn guided_nontermination_processors_receive_the_campaign_ceiling() {
        assert_eq!(
            guided_top_level_atom_timeout("nontermination(rule-subset-narrowing)"),
            Duration::from_secs(60)
        );
        assert_eq!(
            guided_top_level_atom_timeout("nontermination(srs-derivation-patterns)"),
            Duration::from_secs(60)
        );
        assert_eq!(
            guided_top_level_atom_timeout("Uncurry"),
            Duration::from_secs(55),
            "CPF-extracted processor names must receive the same allowance as strategy aliases"
        );
    }

    #[test]
    fn guided_dp_atom_does_not_shorten_the_outer_replay_deadline() {
        assert_eq!(
            guided_top_level_atom_timeout("dp(graph;poly(max-constant=2,max-coefficient=2))"),
            Duration::from_secs(300)
        );
        for atom in ["fast-dp", "csr-safe-dp", "safe-csr-dp"] {
            assert_eq!(
                guided_top_level_atom_timeout(atom),
                Duration::from_secs(60),
                "{atom} must retain the CSR replay ceiling"
            );
        }
        assert_eq!(
            guided_top_level_atom_timeout(
                "matrix(dimension=2,max-constant=1,max-coefficient=1);csr-safe-dp"
            ),
            Duration::from_secs(60)
        );
    }

    #[test]
    fn canonical_csr_input_preserves_map_and_ignores_symbol_names() {
        fn example(f: &str, g: &str, variable: &str) -> CsrTrs {
            let trs = Trs::new(
                None,
                BTreeSet::from([Variable::new(variable)]),
                vec![RewriteRule::new(
                    Term::app(f, vec![Term::var(variable)]),
                    Term::app(g, vec![Term::var(variable)]),
                )],
            );
            CsrTrs::new(
                trs,
                ReplacementMap::new(BTreeMap::from([
                    (Symbol::new(f), BTreeSet::from([0])),
                    (Symbol::new(g), BTreeSet::new()),
                ])),
            )
            .unwrap()
        }
        let left = example("f", "g", "x");
        let right = example("alpha", "beta", "z");

        let (left_canonical, left_error) = standardized_csr_input_cpf4(&left);
        let (right_canonical, right_error) = standardized_csr_input_cpf4(&right);

        assert!(left_error.is_none(), "{left_error:?}");
        assert!(right_error.is_none(), "{right_error:?}");
        assert_eq!(left_canonical, right_canonical);
        assert!(left_canonical.contains("<position>1</position>"));
    }

    #[test]
    fn canonical_relative_input_preserves_the_strict_weak_boundary() {
        let strict = RewriteRule::new(Term::app("f", vec![]), Term::app("a", vec![]));
        let weak = RewriteRule::new(Term::app("g", vec![]), Term::app("b", vec![]));
        let relative = RelativeTrs::new(Trs::new(None, BTreeSet::new(), vec![strict]), vec![weak]);
        let ordinary = relative.union();
        let (relative_canonical, relative_error) = standardized_relative_trs_input_cpf3(&relative);
        let (ordinary_canonical, ordinary_error) = standardized_trs_input_cpf3(&ordinary);
        assert!(relative_error.is_none(), "{relative_error:?}");
        assert!(ordinary_error.is_none(), "{ordinary_error:?}");
        assert!(relative_canonical.contains("<relativeRules>"));
        assert_ne!(relative_canonical, ordinary_canonical);
    }

    use crate::cert::{CpfMode, write_cpf};
    use crate::proving::{NonterminationProof, Status};

    #[test]
    fn rfc_epsilon_batch_matches_incremental_transitive_closure() {
        let mut batched = SrsMatchAutomatonBuilder::empty(32, 128);
        batched
            .states
            .extend(["q1", "q2", "q3", "q4"].into_iter().map(str::to_string));
        let mut incremental = batched.clone();
        let required = BTreeSet::from([
            ("q0".to_string(), "q1".to_string()),
            ("q1".to_string(), "q2".to_string()),
            ("q2".to_string(), "q0".to_string()),
            ("q3".to_string(), "q2".to_string()),
            ("q2".to_string(), "q4".to_string()),
        ]);

        assert_eq!(batched.insert_epsilon_batch(&required), Some(true));
        for (source, target) in &required {
            incremental.insert_epsilon(source, target).unwrap();
        }

        assert_eq!(batched.epsilon_forward, incremental.epsilon_forward);
        assert_eq!(batched.epsilon_backward, incremental.epsilon_backward);
        assert_eq!(batched.state_transitions, incremental.state_transitions);
    }

    #[test]
    fn rfc_word_bitset_index_matches_reference_reachability() {
        let mut automaton = SrsMatchAutomatonBuilder::empty(32, 128);
        automaton.insert_transition("a", 0, "q2", "q1");
        automaton.insert_transition("b", 0, "q1", "q0");
        automaton.insert_transition("a", 0, "q3", "q2");
        automaton.insert_epsilon("q4", "q2").unwrap();
        automaton.insert_epsilon("q0", "q5").unwrap();
        let index = SrsMatchWordIndex::new(&automaton);
        let words = [
            vec![Symbol::new("a")],
            vec![Symbol::new("b"), Symbol::new("a")],
            vec![Symbol::new("a"), Symbol::new("a")],
        ];

        for (state_id, state) in index.states.iter().enumerate() {
            for word in &words {
                assert_eq!(
                    index.exact_heads(word, 0, state),
                    automaton.exact_heads_for_word(word, 0, state)
                );
                let indexed = index.exact_head_bits(word, 0, state_id);
                let mut indexed_names = Vec::new();
                SrsMatchWordIndex::for_each_bit(&indexed, |head| {
                    indexed_names.push(index.state(head).to_string())
                });
                assert_eq!(
                    indexed_names,
                    automaton.exact_heads_for_word(word, 0, state)
                );
            }
        }
    }

    #[test]
    fn srs_length_processor_handles_unary_trs_constants() {
        let trs = Trs::new(
            None,
            BTreeSet::new(),
            vec![RewriteRule::new(
                Term::app("a", vec![Term::app("b", vec![Term::app("c", Vec::new())])]),
                Term::app("d", Vec::new()),
            )],
        );
        let proof = solved_trs_proof(SrsLengthProcessor.apply(&ProblemState::Srs(trs))).unwrap();
        assert_eq!(proof.status(), &Status::Terminating);
        assert!(matches!(
            proof.steps(),
            [ProofStep::SynthesizedLinearPolynomial { .. }]
        ));
    }

    #[test]
    fn srs_length_processor_rejects_non_decreasing_unary_trs() {
        let trs = Trs::new(
            None,
            BTreeSet::from([Variable::new("x")]),
            vec![RewriteRule::new(
                Term::app("a", vec![Term::var("x")]),
                Term::app("b", vec![Term::app("c", vec![Term::var("x")])]),
            )],
        );
        assert!(matches!(
            SrsLengthProcessor.apply(&ProblemState::Srs(trs.clone())),
            ProcessorResult::Inapplicable
        ));
    }

    #[test]
    fn srs_match_bounds_zero_handles_deleting_rules() {
        let trs = Trs::new(
            None,
            BTreeSet::from([Variable::new("x")]),
            vec![RewriteRule::new(
                Term::app("a", vec![Term::var("x")]),
                Term::var("x"),
            )],
        );
        let proof = prove_srs_by_match_bounds_completion(&trs, 0).unwrap();
        assert_eq!(proof.status(), &Status::Terminating);
        assert!(matches!(proof.steps(), [ProofStep::Bounds { .. }]));
    }

    #[test]
    fn exact_srs_match_bounds_rechecks_the_live_automaton() {
        let trs = Trs::new(
            None,
            BTreeSet::from([Variable::new("x")]),
            vec![RewriteRule::new(
                Term::app("a", vec![Term::var("x")]),
                Term::var("x"),
            )],
        );
        let synthesized = prove_srs_by_match_bounds_completion(&trs, 0).unwrap();
        let [ProofStep::Bounds { proof }] = synthesized.steps() else {
            panic!("expected a bounds proof");
        };
        assert!(
            solved_trs_proof(
                ExactSrsMatchBoundsProcessor {
                    proof: proof.clone(),
                    deadline: None,
                }
                .apply(&ProblemState::Srs(trs.clone()))
            )
            .is_some()
        );

        let mut incomplete = proof.clone();
        incomplete.automaton.transitions.clear();
        assert!(matches!(
            ExactSrsMatchBoundsProcessor {
                proof: incomplete,
                deadline: None,
            }
            .apply(&ProblemState::Srs(trs)),
            ProcessorResult::Inapplicable
        ));
    }

    fn cons_word(symbols: &[&str], tail: Term) -> Term {
        symbols.iter().rev().fold(tail, |tail, symbol| {
            Term::app("cons", vec![Term::app(*symbol, Vec::new()), tail])
        })
    }

    #[test]
    fn match_bounds_lifts_cons_encoded_string_systems() {
        let trs = Trs::new(
            None,
            BTreeSet::from([Variable::new("x")]),
            vec![RewriteRule::new(
                cons_word(&["a", "b"], Term::var("x")),
                cons_word(&["a"], Term::var("x")),
            )],
        );

        let native = crate::proving::processors::top_level::SrsMatchBoundsProcessor {
            max_bound: 1,
            max_states: 1000,
            max_transitions: 10000,
            deadline: None,
        };
        assert!(matches!(
            crate::proving::WorklistProcessor::apply(&native, &crate::proving::ProblemState::Trs(trs.clone())),
            crate::proving::ProcessorResult::Applied(_)
        ));
        let proof = prove_srs_by_match_bounds_completion(&trs, 1)
            .expect("cons-encoded deleting string rule must have match bound one");
        let [ProofStep::Bounds { proof }] = proof.steps() else {
            panic!("expected an ordinary bounds proof");
        };

        assert!(proof.automaton.transitions.iter().any(|transition| {
            matches!(
                &transition.lhs,
                TreeAutomatonTransitionLhs::Symbol { symbol, args, .. }
                    if symbol == "cons" && args.len() == 2
            )
        }));
        assert!(proof.automaton.transitions.iter().any(|transition| {
            matches!(
                &transition.lhs,
                TreeAutomatonTransitionLhs::Symbol { symbol, args, .. }
                    if symbol == "a" && args.is_empty()
            )
        }));
    }

    #[test]
    fn ceta_certifies_cons_encoded_match_bounds_when_available() {
        let checker = Path::new(".tools/ceta-relative-bounds");
        if !checker.exists() {
            return;
        }
        let trs = Trs::new(
            None,
            BTreeSet::from([Variable::new("x")]),
            vec![RewriteRule::new(
                cons_word(&["a", "b"], Term::var("x")),
                cons_word(&["a"], Term::var("x")),
            )],
        );
        let proof = prove_srs_by_match_bounds_completion(&trs, 1).unwrap();
        let cpf = write_cpf(&trs, &proof, CpfMode::Cpf30).unwrap();
        let path = std::env::temp_dir().join(format!(
            "ferrum-cons-match-bounds-{}.cpf3.xml",
            std::process::id()
        ));
        fs::write(&path, cpf).unwrap();
        let output = Command::new(checker).arg(&path).output().unwrap();
        let _ = fs::remove_file(path);

        assert!(
            output.status.success(),
            "{}{}",
            String::from_utf8_lossy(&output.stdout),
            String::from_utf8_lossy(&output.stderr)
        );
    }

    #[test]
    fn relative_srs_match_bounds_removes_all_rules_with_empty_residual() {
        let trs = Trs::new(
            None,
            BTreeSet::from([Variable::new("x")]),
            vec![RewriteRule::new(
                Term::app("a", vec![Term::var("x")]),
                Term::var("x"),
            )],
        );
        let proof = atomic_relative_match_bounds_proof(
            &trs,
            0,
            DEFAULT_SRS_MATCH_BOUNDS_MAX_STATES,
            DEFAULT_SRS_MATCH_BOUNDS_MAX_TRANSITIONS,
            None,
        )
        .unwrap();
        let [
            ProofStep::RelativeBounds {
                removed,
                proof_after_removal,
                ..
            },
        ] = proof.steps()
        else {
            panic!("expected relative match-bounds proof");
        };
        assert_eq!(removed, trs.rules());
        assert!(matches!(
            proof_after_removal.steps(),
            [ProofStep::EmptySystem]
        ));
    }

    #[test]
    fn relative_match_bounds_certifies_mixed_srs_3_after_all_path_completion() {
        let trs = parse_trs(
            Some("Mixed_SRS/3".to_string()),
            r#"
                (format TRS)
                (fun a 1)
                (fun b 1)
                (fun c 1)
                (rule (a (a x1)) (a (b (a x1))))
                (rule (b (a (b x1))) (a (c (a x1))))
            "#,
        )
        .unwrap();

        let proof = atomic_relative_match_bounds_proof(
            &trs,
            5,
            DEFAULT_SRS_MATCH_BOUNDS_MAX_STATES,
            DEFAULT_SRS_MATCH_BOUNDS_MAX_TRANSITIONS,
            None,
        )
        .expect("all-path completion should construct the certified witness");
        let cpf = write_cpf(&trs, &proof, CpfMode::Cpf30).unwrap();
        let path = std::env::temp_dir().join(format!(
            "ferrum-mixed-srs-3-relative-{}.cpf3.xml",
            std::process::id()
        ));
        fs::write(&path, cpf).unwrap();
        let output = Command::new("../CeTA-CSR/ceta")
            .arg(&path)
            .output()
            .unwrap();
        let _ = fs::remove_file(path);
        assert!(
            output.status.success(),
            "{}{}",
            String::from_utf8_lossy(&output.stdout),
            String::from_utf8_lossy(&output.stderr)
        );
    }

    #[test]
    fn match_bounds_is_an_atomic_worklist_processor() {
        let trs = Trs::new(
            None,
            BTreeSet::from([Variable::new("x")]),
            vec![RewriteRule::new(
                Term::app("a", vec![Term::var("x")]),
                Term::var("x"),
            )],
        );
        let options = ProveOptions {
            strategy: ProveStrategy::parse("match-bounds(max-bound=0)").unwrap(),
            ..ProveOptions::default()
        };
        let proof = prove(&trs, &options);
        assert!(matches!(proof.steps(), [ProofStep::Bounds { .. }]));
    }

    #[test]
    fn rfc_match_bounds_uses_automaton_closed_witness_when_finite_closure_is_not_enumerable() {
        let rule = crate::core::SrsRule::new_for_test(
            vec!["b", "c", "b", "c", "a", "a"],
            vec!["a", "a", "a", "b", "c", "b", "c", "b", "c"],
        );
        let completion = complete_srs_rfc_match_bounds_completion_for_initial_words(
            &[rule],
            &[vec![
                Symbol::new("a"),
                Symbol::new("a"),
                Symbol::new("a"),
                Symbol::new("b"),
                Symbol::new("c"),
                Symbol::new("b"),
                Symbol::new("c"),
                Symbol::new("b"),
                Symbol::new("c"),
            ]],
            0,
            2_000,
            50_000,
            SrsMatchAtBound::Merge,
            None,
        )
        .expect("automaton-closed RFC should complete the z031-style system");
        assert_eq!(completion.automaton.final_states, vec!["q0".to_string()]);
        assert!(!completion.automaton.transitions.is_empty());
    }

    #[test]
    fn rfc_no_top_redex_validator_detects_bound_height_lhs_path() {
        let rule = crate::core::SrsRule::new_for_test(vec!["a"], vec!["b"]);
        let mut builder = SrsMatchAutomatonBuilder::empty(DEFAULT_SRS_MATCH_BOUNDS_MAX_STATES, 16);
        builder.insert_transition("a", 2, "q0", "q0");
        assert!(!builder.has_no_rfc_top_redex_at_bound(std::slice::from_ref(&rule), 2));
        assert!(builder.has_no_rfc_top_redex_at_bound(&[rule], 1));
    }

    #[test]
    fn rfc_native_word_evaluation_closes_epsilon_only_between_letters() {
        let mut builder = SrsMatchAutomatonBuilder::empty(16, 16);
        builder.insert_transition("a", 0, "q0", "q1");
        builder.insert_epsilon("q1", "q2").unwrap();
        builder.insert_transition("b", 0, "q2", "q3");
        builder.insert_epsilon("q3", "q4").unwrap();
        let word = vec![Symbol::new("b"), Symbol::new("a")];

        assert_eq!(
            builder.native_heads_for_word(&word, 0, "q0"),
            BTreeSet::from(["q3".to_string()])
        );
        assert_eq!(
            builder.exact_heads_for_word(&word, 0, "q0"),
            vec!["q3".to_string(), "q4".to_string()]
        );
    }

    #[test]
    fn rfc_native_relational_closure_uses_state_compatibility() {
        let rule = crate::core::SrsRule::new_for_test(vec!["a"], vec!["b"]);
        let mut builder = SrsMatchAutomatonBuilder::empty(16, 16);
        builder.insert_transition("a", 0, "q0", "q1");
        builder.insert_transition("b", 0, "q0", "q2");
        builder
            .state_compatibility
            .insert(("q1".to_string(), "q2".to_string()));

        assert!(!builder.is_rfc_native_matchbox_closed(std::slice::from_ref(&rule)));
        assert!(builder.is_rfc_native_matchbox_closed_with_relation(&[rule]));

        assert!(builder.are_rfc_tail_states_epsilon_closed(&["q0".to_string()]));
        builder.insert_epsilon("q0", "q3").unwrap();
        assert!(!builder.are_rfc_tail_states_epsilon_closed(&["q0".to_string()]));
        assert!(builder.are_rfc_tail_states_epsilon_closed(&["q0".to_string(), "q3".to_string()]));
    }

    #[test]
    fn rfc_barren_builder_recognizes_z033_at_bound_zero() {
        let input = fs::read_to_string("../TPDB-ARI/SRS_Standard/Zantema_04/z033.ari").unwrap();
        let trs = parse_trs(Some("z033".to_string()), &input).unwrap();
        let rules = trs.srs_rules().unwrap();
        let barren = SrsRfcBarrenBuilder::new(&rules, 0)
            .complete_all_rule_removal(SrsRfcBarrenClosure::Right, None)
            .expect("right-barren completion should terminate");
        assert_eq!(barren.top, vec![None]);
        assert_eq!(barren.epsilons.len(), 2);
        assert_eq!(barren.removed_rule_indices(), vec![0]);
        assert!(barren.kept_rule_indices().is_empty());
    }

    #[test]
    fn rfc_partial_deletion_preserves_reverse_relative_residual() {
        let trs = parse_trs(None, "(VAR x) (RULES a(x) -> b(x) b(x) -> b(x))").unwrap();
        let ProcessorResult::Applied(application) = (SrsRfcRelativeMatchBoundsProcessor {
            allow_partial: true,
            absolute_residual: false,
            layered_seconds: 2,
            fresh_seconds: 2,
            min_bound: 0, max_bound: 0, max_words: 100, max_word_len: 16,
            max_states: 128, max_transitions: 2048,
            at_bound: SrsMatchAtBound::Merge, closure: SrsRfcBarrenClosure::Right,
            deadline: Some(Instant::now() + Duration::from_secs(5)),
        }).apply(&ProblemState::Srs(trs.clone())) else {
            panic!("expected a partial RFC deletion");
        };
        let [ProblemState::RelativeSrs(residual)] = application.residuals.as_slice() else {
            panic!("RFC must retain removed rules as the weak component");
        };
        assert_eq!(residual.strict().rules(), &trs.rules()[1..]);
        assert_eq!(residual.weak_rules(), &trs.rules()[..1]);
    }

    #[test]
    fn rfc_barren_completion_supports_erasing_rules() {
        let trs = parse_trs(None, "(VAR x) (RULES a(x) -> x)").unwrap();
        let proof = atomic_rfc_relative_match_bounds_proof(
            &trs, 2, 100, 16, 128, 2048, SrsMatchAtBound::Merge,
            SrsRfcBarrenClosure::Right, Some(Instant::now() + Duration::from_secs(5)),
        ).expect("erasing right-linear RFC proof");
        assert_eq!(proof.status(), &Status::Terminating);
    }

    #[test]
    fn rfc_match_bounds_emits_exact_right_barren_z033_witness() {
        let input = fs::read_to_string("../TPDB-ARI/SRS_Standard/Zantema_04/z033.ari").unwrap();
        let trs = parse_trs(Some("z033".to_string()), &input).unwrap();
        let proof = atomic_rfc_relative_match_bounds_proof(
            &trs,
            0,
            1,
            128,
            2_000,
            50_000,
            SrsMatchAtBound::Merge,
            SrsRfcBarrenClosure::Right,
            None,
        )
        .expect("z033 should have an exact right-barren proof");
        let [
            ProofStep::RfcMatchboxRelativeBounds {
                proof: bounds,
                removed,
                ..
            },
        ] = proof.steps()
        else {
            panic!("expected an RFC Matchbox relative-bounds proof");
        };
        assert_eq!(bounds.bound, 0);
        assert_eq!(bounds.final_states.len(), 1);
        assert_eq!(removed, trs.rules());
        assert!(bounds.automaton.final_states.len() >= 2);
        let tail = &bounds.final_states[0];
        let result_states = bounds
            .automaton
            .transitions
            .iter()
            .filter_map(|transition| {
                matches!(transition.lhs, TreeAutomatonTransitionLhs::Symbol { .. })
                    .then_some(&transition.rhs)
            })
            .collect::<BTreeSet<_>>();
        assert!(bounds.automaton.transitions.iter().any(|transition| {
            matches!(
                &transition.lhs,
                TreeAutomatonTransitionLhs::State(source)
                    if result_states.contains(source) && &transition.rhs == tail
            )
        }));
        let cpf = write_cpf(&trs, &proof, CpfMode::Cpf40).unwrap();
        assert!(cpf.contains("<rfcMatchboxRelativeBounds>"));
        assert!(cpf.contains("<bound>0</bound>"));
    }

    #[test]
    fn rfc_match_bounds_emits_paired_tail_witness_for_64160() {
        let input = fs::read_to_string("../TPDB-ARI/SRS_Standard/ICFP_2010/64160.ari").unwrap();
        let trs = parse_trs(Some("64160".to_string()), &input).unwrap();
        let proof = atomic_rfc_relative_match_bounds_proof(
            &trs,
            0,
            10_000,
            128,
            2_000,
            50_000,
            SrsMatchAtBound::Merge,
            SrsRfcBarrenClosure::Right,
            None,
        )
        .expect("64160 should have a paired-tail right-barren proof");
        let [
            ProofStep::RfcMatchboxRelativeBounds {
                proof: bounds,
                initial_words,
                removed,
                ..
            },
        ] = proof.steps()
        else {
            panic!("expected an RFC Matchbox relative-bounds proof");
        };
        assert_eq!(bounds.bound, 0);
        assert_eq!(bounds.final_states.len(), trs.rules().len());
        assert_eq!(initial_words.len(), trs.rules().len());
        assert_eq!(removed, trs.rules());
        assert!(
            bounds
                .state_compatibility
                .iter()
                .all(|(source, target)| source == target)
        );
        let cpf = write_cpf(&trs, &proof, CpfMode::Cpf40).unwrap();
        assert!(cpf.contains("<rfcMatchboxRelativeBounds>"));
    }

    #[test]
    fn rfc_match_bounds_emits_canonical_witness_for_z061() {
        let input = fs::read_to_string("../TPDB-ARI/SRS_Standard/Zantema_04/z061.ari").unwrap();
        let trs = parse_trs(Some("z061".to_string()), &input).unwrap();
        let proof = atomic_rfc_relative_match_bounds_proof(
            &trs,
            0,
            10_000,
            128,
            10_000,
            250_000,
            SrsMatchAtBound::Merge,
            SrsRfcBarrenClosure::Right,
            None,
        )
        .expect("z061 should have a canonical Matchbox-relative witness");
        assert!(matches!(
            proof.steps(),
            [ProofStep::RfcMatchboxRelativeBounds { .. }]
        ));
        let cpf = write_cpf(&trs, &proof, CpfMode::Cpf40).unwrap();
        assert!(cpf.contains("<rfcMatchboxRelativeBounds>"));
        assert!(!cpf.contains("<rfcNativeMatchboxRelativeBounds>"));
    }

    #[test]
    fn rfc_match_bounds_completes_strict_below_top_witness_for_140639() {
        let input = fs::read_to_string("../TPDB-ARI/SRS_Standard/ICFP_2010/140639.ari").unwrap();
        let trs = parse_trs(Some("140639".to_string()), &input).unwrap();
        let proof = atomic_rfc_relative_match_bounds_proof(
            &trs,
            1,
            10_000,
            128,
            10_000,
            250_000,
            SrsMatchAtBound::Merge,
            SrsRfcBarrenClosure::Right,
            None,
        )
        .expect("140639 should have a strict-compatible bound-one RFC witness");
        let [
            ProofStep::RfcMatchboxRelativeBounds {
                proof: bounds,
                removed,
                proof_after_removal,
                ..
            },
        ] = proof.steps()
        else {
            panic!("expected an RFC Matchbox relative-bounds proof");
        };
        assert_eq!(bounds.bound, 1);
        assert_eq!(removed, trs.rules());
        assert!(matches!(
            proof_after_removal.steps(),
            [ProofStep::EmptySystem]
        ));
        let cpf = write_cpf(&trs, &proof, CpfMode::Cpf40).unwrap();
        assert!(cpf.contains("<rfcMatchboxRelativeBounds>"));
    }

    #[test]
    fn rfc_match_bounds_production_does_not_export_merge_automaton_closed_witnesses() {
        let trs = strict_srs_trs_for_test(&[(
            vec!["b", "c", "b", "c", "a", "a"],
            vec!["a", "a", "a", "b", "c", "b", "c", "b", "c"],
        )]);
        let witness = prove_srs_by_rfc_match_bounds_with_limits(
            &trs,
            3,
            1,
            128,
            2_000,
            50_000,
            SrsMatchAtBound::Merge,
            SrsRfcBarrenClosure::Right,
            Some(Instant::now() + Duration::from_secs(1)),
        );
        assert!(witness.is_none());
    }

    #[test]
    fn relative_srs_match_bounds_removal_prefers_certified_rule_batches() {
        let rules = vec![
            crate::core::SrsRule::new_for_test(vec!["a", "b"], vec!["b"]),
            crate::core::SrsRule::new_for_test(vec!["c"], vec!["d", "d"]),
            crate::core::SrsRule::new_for_test(vec!["e", "f", "g"], vec!["e"]),
        ];
        let batches = srs_relative_match_bounds_candidate_batches(&rules);
        assert_eq!(batches.first(), Some(&vec![0, 1, 2]));
        assert!(batches.iter().any(|batch| batch == &vec![0, 2]));
        assert_eq!(
            batches
                .iter()
                .filter(|batch| batch.len() == 1)
                .collect::<Vec<_>>()
                .len(),
            3
        );
    }

    #[test]
    fn srs_match_bounds_completion_handles_growing_then_deleting_rules() {
        let trs = Trs::new(
            None,
            BTreeSet::from([Variable::new("x")]),
            vec![RewriteRule::new(
                Term::app("a", vec![Term::var("x")]),
                Term::app("b", vec![Term::var("x")]),
            )],
        );
        assert!(matches!(
            SrsLengthProcessor.apply(&ProblemState::Srs(trs.clone())),
            ProcessorResult::Inapplicable
        ));
        let proof = prove_srs_by_match_bounds_completion(&trs, 2).unwrap();
        assert_eq!(proof.status(), &Status::Terminating);
        assert!(matches!(proof.steps(), [ProofStep::Bounds { .. }]));
    }

    #[test]
    fn decomp_match_bounds_does_not_export_an_incompatible_aoto_automaton() {
        let rules = vec![
            crate::core::SrsRule::new_for_test(vec!["f", "f"], vec!["f", "g", "f", "g", "f"]),
            crate::core::SrsRule::new_for_test(vec!["f", "g", "f"], vec!["g", "f"]),
        ];
        let symbols = BTreeMap::from([("f".to_string(), 1), ("g".to_string(), 1)]);
        if let Some(completion) =
            complete_srs_match_bounds_completion(&rules, &symbols, 3, 2_000, 50_000, None)
        {
            let validator =
                SrsMatchAutomatonBuilder::from_completion_for_validation(completion, 2_000, 50_000)
                    .unwrap();
            assert_eq!(
                validator.is_rfc_matchbox_below_top_strict_compatible(&rules, 3, None),
                Some(true)
            );
        }
    }

    #[test]
    fn srs_rfc_initial_words_decline_alpha_only_bounded_rhs_descendants_for_ceta() {
        let trs = strict_srs_trs_for_test(&[
            (vec!["a"], vec!["b", "b"]),
            (vec!["b"], Vec::<&str>::new()),
        ]);
        let rules = trs.srs_rules().unwrap();
        let (_, tail) = strict_srs_word_with_tail(trs.rules()[0].lhs()).unwrap();
        assert!(srs_rfc_initial_words(trs.rules(), &tail, &rules, 16, 4).is_none());
    }

    #[test]
    fn srs_rfc_initial_words_decline_alpha_only_prefix_overlap_narrowings_for_ceta() {
        let trs = strict_srs_trs_for_test(&[
            (vec!["a", "b", "c"], vec!["d"]),
            (vec!["e"], vec!["a", "b"]),
        ]);
        let rules = trs.srs_rules().unwrap();
        let (_, tail) = strict_srs_word_with_tail(trs.rules()[0].lhs()).unwrap();
        assert!(srs_rfc_initial_words(trs.rules(), &tail, &rules, 512, 8).is_none());
    }

    #[test]
    fn srs_rfc_initial_words_decline_rule_side_tail_variables_for_ceta() {
        let trs = strict_srs_trs_for_test(&[(vec!["a"], vec!["f"]), (vec!["f", "f"], vec!["g"])]);
        let rules = trs.srs_rules().unwrap();
        let (_, tail) = strict_srs_word_with_tail(trs.rules()[0].lhs()).unwrap();
        assert!(srs_rfc_initial_words(trs.rules(), &tail, &rules, 16, 8).is_none());
    }

    #[test]
    fn srs_rfc_initial_words_fail_when_closure_exceeds_word_cap() {
        let trs = strict_srs_trs_for_test(&[(vec!["a", "b", "a"], vec!["b", "a", "b"])]);
        let rules = trs.srs_rules().unwrap();
        let (_, tail) = strict_srs_word_with_tail(trs.rules()[0].lhs()).unwrap();
        assert!(srs_rfc_initial_words(trs.rules(), &tail, &rules, 1024, 8).is_none());
    }

    #[test]
    fn finite_initial_match_bounds_completion_builds_rfc_candidate_automaton() {
        let trs = strict_srs_trs_for_test(&[(vec!["a"], vec!["b", "b"]), (vec!["b"], vec!["c"])]);
        let rules = trs.srs_rules().unwrap();
        let initial = vec![
            vec![crate::core::Symbol::new("b"), crate::core::Symbol::new("b")],
            vec![crate::core::Symbol::new("c")],
        ];
        let automaton = complete_srs_match_bounds_automaton_for_initial_words(
            &rules,
            &initial,
            2,
            DEFAULT_SRS_MATCH_BOUNDS_MAX_STATES,
            DEFAULT_SRS_MATCH_BOUNDS_MAX_TRANSITIONS,
            None,
        )
        .unwrap();
        assert!(automaton.transitions.iter().any(|transition| matches!(
            &transition.lhs,
            TreeAutomatonTransitionLhs::Symbol {
                height: Some(height),
                ..
            } if *height > 0
        )));
    }

    fn strict_srs_trs_for_test(rules: &[(Vec<&str>, Vec<&str>)]) -> Trs {
        Trs::new(
            None,
            BTreeSet::from([Variable::new("x")]),
            rules
                .iter()
                .map(|(lhs, rhs)| {
                    RewriteRule::new(
                        srs_word_to_term(
                            &lhs.iter()
                                .map(|symbol| crate::core::Symbol::new(*symbol))
                                .collect::<Vec<_>>(),
                            Term::var("x"),
                        ),
                        srs_word_to_term(
                            &rhs.iter()
                                .map(|symbol| crate::core::Symbol::new(*symbol))
                                .collect::<Vec<_>>(),
                            Term::var("x"),
                        ),
                    )
                })
                .collect(),
        )
    }

    #[test]
    fn rfc_match_bounds_emits_cpf4_rfc_bounds_certificate_object() {
        let trs = Trs::new(
            None,
            BTreeSet::from([Variable::new("x")]),
            vec![RewriteRule::new(
                Term::app("a", vec![Term::var("x")]),
                Term::app("b", vec![Term::var("x")]),
            )],
        );
        let witness = prove_srs_by_rfc_match_bounds_with_limits(
            &trs,
            1,
            16,
            4,
            DEFAULT_SRS_MATCH_BOUNDS_MAX_STATES,
            DEFAULT_SRS_MATCH_BOUNDS_MAX_TRANSITIONS,
            SrsMatchAtBound::Exact,
            SrsRfcBarrenClosure::Right,
            None,
        )
        .unwrap();
        let proof = Proof::terminating(vec![ProofStep::RfcBounds {
            proof: witness.proof,
            initial_words: witness.initial_words,
        }]);
        assert_eq!(proof.status(), &Status::Terminating);
        let [ProofStep::RfcBounds { initial_words, .. }] = proof.steps() else {
            panic!("expected RFC match-bounds proof");
        };
        let rendered = initial_words
            .iter()
            .map(|word| {
                word.iter()
                    .map(|symbol| symbol.as_str())
                    .collect::<Vec<_>>()
                    .join("")
            })
            .collect::<BTreeSet<_>>();
        assert!(rendered.contains("b"));
        let cpf = write_cpf(&trs, &proof, CpfMode::Cpf40).unwrap();
        assert!(cpf.contains("<rfcBounds>"));
        assert!(cpf.contains("<initialTerms>"));
        assert!(cpf.contains("<bounds>"));
    }

    #[test]
    fn ceta_certifies_cpf4_rfc_match_bounds_when_available() {
        let checker = Path::new("../CeTA-CSR/ceta");
        if !checker.is_file() {
            return;
        }
        let trs = Trs::new(
            None,
            BTreeSet::from([Variable::new("x")]),
            vec![RewriteRule::new(
                Term::app("a", vec![Term::var("x")]),
                Term::app("b", vec![Term::var("x")]),
            )],
        );
        let witness = prove_srs_by_rfc_match_bounds_with_limits(
            &trs,
            1,
            16,
            4,
            DEFAULT_SRS_MATCH_BOUNDS_MAX_STATES,
            DEFAULT_SRS_MATCH_BOUNDS_MAX_TRANSITIONS,
            SrsMatchAtBound::Exact,
            SrsRfcBarrenClosure::Right,
            None,
        )
        .unwrap();
        let step = if witness.automaton_closed {
            ProofStep::RfcAutomatonClosedBounds {
                proof: witness.proof,
                initial_words: witness.initial_words,
            }
        } else {
            ProofStep::RfcBounds {
                proof: witness.proof,
                initial_words: witness.initial_words,
            }
        };
        let proof = Proof::terminating(vec![step]);
        let cpf = write_cpf(&trs, &proof, CpfMode::Cpf40).unwrap();
        let path = std::env::temp_dir().join(format!(
            "ferrum-rfc-match-bounds-{}.cpf4.xml",
            std::process::id()
        ));
        fs::write(&path, cpf).unwrap();
        let output = Command::new(checker).arg(&path).output().unwrap();
        let _ = fs::remove_file(path);
        assert!(
            output.status.success(),
            "{}{}",
            String::from_utf8_lossy(&output.stdout),
            String::from_utf8_lossy(&output.stderr)
        );
    }

    #[test]
    fn srs_match_bounds_reuses_existing_rhs_path_prefixes() {
        let mut builder = SrsMatchAutomatonBuilder::empty(
            DEFAULT_SRS_MATCH_BOUNDS_MAX_STATES,
            DEFAULT_SRS_MATCH_BOUNDS_MAX_TRANSITIONS,
        );
        assert!(
            builder
                .add_rhs_path(
                    &[
                        crate::core::Symbol::new("a"),
                        crate::core::Symbol::new("b"),
                        crate::core::Symbol::new("c"),
                    ],
                    1,
                    "",
                    "q0",
                )
                .unwrap()
        );
        let states_after_first = builder.states.len();
        assert!(
            builder
                .add_rhs_path(
                    &[
                        crate::core::Symbol::new("d"),
                        crate::core::Symbol::new("b"),
                        crate::core::Symbol::new("c"),
                    ],
                    1,
                    "",
                    "q0",
                )
                .unwrap()
        );
        assert_eq!(builder.states.len(), states_after_first);
    }

    #[test]
    fn reversed_srs_match_bounds_uses_string_reversal_processor() {
        let trs = Trs::new(
            None,
            BTreeSet::from([Variable::new("x")]),
            vec![
                RewriteRule::new(
                    Term::app("a", vec![Term::var("x")]),
                    Term::app("b", vec![Term::app("b", vec![Term::var("x")])]),
                ),
                RewriteRule::new(Term::app("b", vec![Term::var("x")]), Term::var("x")),
            ],
        );
        let proof = prove_srs_by_reversal_match_bounds_completion(&trs, 2).unwrap();
        assert_eq!(proof.status(), &Status::Terminating);
        assert!(
            matches!(proof.steps(), [ProofStep::StringReversal { proof, .. }]
                if matches!(proof.steps(), [ProofStep::Bounds { .. }]))
        );
    }

    #[test]
    fn string_reversal_residual_is_closed_by_the_common_worklist() {
        let trs = Trs::new(
            None,
            BTreeSet::from([Variable::new("x")]),
            vec![
                RewriteRule::new(
                    Term::app("a", vec![Term::var("x")]),
                    Term::app("b", vec![Term::app("b", vec![Term::var("x")])]),
                ),
                RewriteRule::new(Term::app("b", vec![Term::var("x")]), Term::var("x")),
            ],
        );
        let options = ProveOptions {
            strategy: ProveStrategy::parse("string-reversal").unwrap(),
            ..ProveOptions::default()
        };
        let proof = prove(&trs, &options);
        assert_eq!(proof.status(), &Status::Terminating);
        assert!(matches!(
            proof.steps(),
            [ProofStep::StringReversal { proof, .. }]
                if proof.status() == &Status::Terminating
        ));
    }

    #[test]
    fn innermost_string_reversal_uses_a_full_rewriting_child() {
        let trs = Trs::new_with_strategy(
            None,
            BTreeSet::from([Variable::new("x")]),
            vec![RewriteRule::new(
                Term::app("a", vec![Term::var("x")]),
                Term::var("x"),
            )],
            RewriteStrategy::Innermost,
        );
        let options = ProveOptions {
            strategy: ProveStrategy::parse("string-reversal").unwrap(),
            ..ProveOptions::default()
        };
        let proof = prove(&trs, &options);
        assert_eq!(proof.status(), &Status::Terminating);
        assert!(matches!(
            proof.steps(),
            [ProofStep::StringReversal { proof, .. }] if proof.status() == &Status::Terminating
        ));
    }

    #[test]
    fn string_reversal_nontermination_is_reconstructed_from_an_atomic_child() {
        let trs = Trs::new(
            None,
            BTreeSet::from([Variable::new("x")]),
            vec![
                RewriteRule::new(
                    Term::app("a", vec![Term::var("x")]),
                    Term::app("b", vec![Term::var("x")]),
                ),
                RewriteRule::new(
                    Term::app("b", vec![Term::var("x")]),
                    Term::app("a", vec![Term::var("x")]),
                ),
            ],
        );
        let options = ProveOptions {
            strategy: ProveStrategy::parse("string-reversal").unwrap(),
            ..ProveOptions::default()
        };
        let proof = prove(&trs, &options);
        assert_eq!(proof.status(), &Status::Nonterminating);
        assert!(
            matches!(proof.steps(), [ProofStep::StringReversal { proof, .. }]
                if matches!(proof.steps(), [ProofStep::Nontermination { .. }]))
        );
    }

    #[test]
    fn ceta_certifies_cpf3_reversal_srs_loop_when_available() {
        if !Path::new("../CeTA-CSR/ceta").exists() {
            return;
        }
        let trs = Trs::new(
            None,
            BTreeSet::from([Variable::new("x")]),
            vec![
                RewriteRule::new(
                    Term::app("a", vec![Term::var("x")]),
                    Term::app("b", vec![Term::var("x")]),
                ),
                RewriteRule::new(
                    Term::app("b", vec![Term::var("x")]),
                    Term::app("a", vec![Term::var("x")]),
                ),
            ],
        );
        let options = ProveOptions {
            strategy: ProveStrategy::parse("string-reversal").unwrap(),
            ..ProveOptions::default()
        };
        let proof = prove(&trs, &options);
        let cpf = write_cpf(&trs, &proof, CpfMode::Cpf30).unwrap();
        assert!(cpf.contains("<stringReversal>"));
        assert!(cpf.contains("<trsNonterminationProof>"));
        let path = std::env::temp_dir().join(format!(
            "ferrum-reversal-srs-loop-{}.cpf3.xml",
            std::process::id()
        ));
        fs::write(&path, cpf).unwrap();
        let output = Command::new("../CeTA-CSR/ceta")
            .arg(&path)
            .output()
            .unwrap();
        let _ = fs::remove_file(path);
        assert!(
            output.status.success(),
            "{}{}",
            String::from_utf8_lossy(&output.stdout),
            String::from_utf8_lossy(&output.stderr)
        );
    }

    #[test]
    fn ceta_certifies_cpf3_reversal_match_bounds_when_available() {
        if !Path::new("../CeTA-CSR/ceta").exists() {
            return;
        }
        let trs = Trs::new(
            None,
            BTreeSet::from([Variable::new("x")]),
            vec![
                RewriteRule::new(
                    Term::app("a", vec![Term::var("x")]),
                    Term::app("b", vec![Term::app("b", vec![Term::var("x")])]),
                ),
                RewriteRule::new(Term::app("b", vec![Term::var("x")]), Term::var("x")),
            ],
        );
        let proof = prove_srs_by_reversal_match_bounds_completion(&trs, 2).unwrap();
        let cpf = write_cpf(&trs, &proof, CpfMode::Cpf30).unwrap();
        assert!(cpf.contains("<stringReversal>"));
        let path = std::env::temp_dir().join(format!(
            "ferrum-reversal-match-bounds-{}.cpf3.xml",
            std::process::id()
        ));
        fs::write(&path, cpf).unwrap();
        let output = Command::new("../CeTA-CSR/ceta")
            .arg(&path)
            .output()
            .unwrap();
        let _ = fs::remove_file(path);
        assert!(
            output.status.success(),
            "{}{}",
            String::from_utf8_lossy(&output.stdout),
            String::from_utf8_lossy(&output.stderr)
        );
    }

    #[test]
    fn ceta_certifies_cpf3_partial_relative_match_bounds_when_available() {
        if !Path::new("../CeTA-CSR/ceta").exists() {
            return;
        }
        let trs = Trs::new(
            None,
            BTreeSet::from([Variable::new("x")]),
            vec![
                RewriteRule::new(
                    Term::app("a", vec![Term::var("x")]),
                    Term::app("b", vec![Term::var("x")]),
                ),
                RewriteRule::new(
                    Term::app("b", vec![Term::var("x")]),
                    Term::app("c", vec![Term::var("x")]),
                ),
            ],
        );
        let proof = prove(
            &trs,
            &ProveOptions {
                strategy: ProveStrategy::parse("relative-match-bounds-removal(max-bound=1)")
                    .unwrap(),
                ..ProveOptions::default()
            },
        );
        assert_eq!(proof.status(), &Status::Terminating);
        let cpf = write_cpf(&trs, &proof, CpfMode::Cpf30).unwrap();
        assert!(cpf.contains("<relativeBounds>"));
        let path = std::env::temp_dir().join(format!(
            "ferrum-partial-relative-match-bounds-{}.cpf3.xml",
            std::process::id()
        ));
        fs::write(&path, cpf).unwrap();
        let output = Command::new("../CeTA-CSR/ceta")
            .arg(&path)
            .output()
            .unwrap();
        let _ = fs::remove_file(path);
        assert!(
            output.status.success(),
            "{}{}",
            String::from_utf8_lossy(&output.stdout),
            String::from_utf8_lossy(&output.stderr)
        );
    }

    #[test]
    fn srs_weighted_length_handles_nonuniform_symbol_weights() {
        let trs = Trs::new(
            None,
            BTreeSet::from([Variable::new("x")]),
            vec![
                RewriteRule::new(
                    Term::app("a", vec![Term::var("x")]),
                    Term::app("b", vec![Term::app("b", vec![Term::var("x")])]),
                ),
                RewriteRule::new(Term::app("b", vec![Term::var("x")]), Term::var("x")),
            ],
        );
        assert!(matches!(
            SrsLengthProcessor.apply(&ProblemState::Srs(trs.clone())),
            ProcessorResult::Inapplicable
        ));
        let proof = solved_trs_proof(
            SrsWeightedLengthProcessor {
                max_weight: 8,
                deadline: None,
            }
            .apply(&ProblemState::Srs(trs)),
        )
        .unwrap();
        assert_eq!(proof.status(), &Status::Terminating);
    }

    #[test]
    fn srs_weighted_rule_removal_removes_strict_subset() {
        let trs = Trs::new(
            None,
            BTreeSet::from([Variable::new("x")]),
            vec![
                RewriteRule::new(
                    Term::app("a", vec![Term::var("x")]),
                    Term::app("b", vec![Term::var("x")]),
                ),
                RewriteRule::new(
                    Term::app("c", vec![Term::var("x")]),
                    Term::app("c", vec![Term::var("x")]),
                ),
            ],
        );
        let ProcessorResult::Applied(application) = (SrsWeightedRuleRemovalProcessor {
            max_weight: 4,
            deadline: None,
        })
        .apply(&ProblemState::Srs(trs)) else {
            panic!("weighted removal should apply")
        };
        assert_eq!(application.residuals.len(), 1);
        let ProblemState::Srs(remaining) = &application.residuals[0] else {
            panic!("expected an SRS residual")
        };
        assert_eq!(remaining.rules().len(), 1);
    }

    #[test]
    fn srs_weighted_rule_removal_can_be_cpf_certified() {
        if !Path::new("../CeTA-CSR/ceta").exists() {
            return;
        }
        let trs = Trs::new(
            None,
            BTreeSet::from([Variable::new("x")]),
            vec![
                RewriteRule::new(
                    Term::app("a", vec![Term::var("x")]),
                    Term::app("b", vec![Term::var("x")]),
                ),
                RewriteRule::new(Term::app("b", vec![Term::var("x")]), Term::var("x")),
            ],
        );
        let options = ProveOptions {
            strategy: ProveStrategy::parse("srs-weighted-rule-removal(max-weight=4)").unwrap(),
            ..ProveOptions::default()
        };
        let proof = prove(&trs, &options);
        assert_eq!(proof.status(), &Status::Terminating);
        assert!(matches!(
            proof.steps(),
            [ProofStep::PolynomialRuleRemoval { .. }]
        ));
        let cpf = write_cpf(&trs, &proof, CpfMode::Cpf30).unwrap();
        let path = std::env::temp_dir().join(format!(
            "ferrum-srs-weighted-removal-{}.cpf3.xml",
            std::process::id()
        ));
        fs::write(&path, cpf).unwrap();
        let output = Command::new("../CeTA-CSR/ceta")
            .arg(&path)
            .output()
            .unwrap();
        let _ = fs::remove_file(path);
        assert!(
            output.status.success(),
            "{}{}",
            String::from_utf8_lossy(&output.stdout),
            String::from_utf8_lossy(&output.stderr)
        );
    }

    #[test]
    fn rfc_fresh_budget_preserves_legacy_defaults_and_roundtrips() {
        for (args, expected) in [
            ("", 2), ("layered-seconds=60", 3),
            ("layered-seconds=60,fresh-seconds=60", 60),
            ("fresh-seconds=0", 0), ("fresh-seconds=300", 300),
        ] {
            let strategy = ProveStrategy::parse(&format!(
                "rfc-relative-match-bounds({args})"
            )).unwrap();
            let ProveStrategy::Processor(p) = strategy else { panic!("processor"); };
            assert!(matches!(&p, ProveStrategyProcessor::SrsRfcRelativeMatchBounds {
                fresh_seconds, ..
            } if *fresh_seconds == expected));
            assert_eq!(ProveStrategy::parse(&p.to_strategy_atom()).unwrap(), ProveStrategy::Processor(p));
        }
        assert!(ProveStrategy::parse("rfc-relative-match-bounds(fresh-seconds=301)").is_err());
        assert!(ProveStrategy::parse("rfc-relative-match-bounds(fresh-seconds=-1)").is_err());
    }

    #[test]
    fn parses_top_level_strategy_language() {
        let strategy = ProveStrategy::parse(
            "let no = nontermination; let yes = path-order; let p = parallel(no | yes); timeout(2s, p)",
        )
        .unwrap();
        assert!(matches!(
            strategy,
            ProveStrategy::Timeout { strategy, .. }
                if matches!(strategy.as_ref(), ProveStrategy::Parallel(branches) if branches.len() == 2)
        ));

        let default_timeout = ProveStrategy::parse("timeout(1s, default)").unwrap();
        assert!(matches!(default_timeout, ProveStrategy::Timeout { .. }));

        let delayed = ProveStrategy::parse("delay(500ms, path-order)").unwrap();
        assert!(matches!(
            delayed,
            ProveStrategy::Delay {
                duration,
                strategy
            } if duration == Duration::from_millis(500)
                && matches!(strategy.as_ref(), ProveStrategy::Processor(ProveStrategyProcessor::PathOrder { .. }))
        ));

        assert!(ProveStrategy::parse("exhaust(path-order)").is_err());

        assert!(matches!(
            ProveStrategy::parse("dp(graph; subterm)").unwrap(),
            ProveStrategy::Processor(ProveStrategyProcessor::DependencyPairsWithStrategy(
                DpStrategy::Sequence(processors)
            )) if processors.len() == 2
        ));
        assert!(matches!(
            ProveStrategy::parse("csr-gm-transform(graph; poly(2,2))").unwrap(),
            ProveStrategy::Processor(
                ProveStrategyProcessor::CsrGmTransformationWithStrategy(
                    DpStrategy::Sequence(processors)
                )
            ) if processors.len() == 2
        ));

        for restored in [
            "csr-safe-dp(graph; size-change)",
            "csr-improved-dp(graph; size-change)",
            "csr-conservative-dp(graph; size-change)",
        ] {
            assert!(
                ProveStrategy::parse(restored).is_ok(),
                "state-local CSR-DP recipe rejected: {restored}"
            );
        }
        assert!(ProveStrategy::parse("switch-innermost(graph; size-change)").is_err());

        assert!(ProveStrategy::parse("nontermination(loop; dp-loop)").is_err());
        assert!(matches!(
            ProveStrategy::parse("nontermination(loop)").unwrap(),
            ProveStrategy::Processor(ProveStrategyProcessor::Nontermination(_))
        ));

        assert!(ProveStrategy::parse("string-reversal(path-order)").is_err());
        let guided_reversal = ProveStrategy::parse("string-reversal").unwrap();
        assert!(matches!(
            guided_reversal,
            ProveStrategy::Processor(ProveStrategyProcessor::StringReversal)
        ));

        assert!(ProveStrategy::parse("normalize-bounds(match-bounds)").is_err());

        assert!(ProveStrategy::parse("csr(switch-csr)").is_err());
        assert!(matches!(
            ProveStrategy::parse("switch-csr").unwrap(),
            ProveStrategy::Processor(ProveStrategyProcessor::SwitchContextSensitive)
        ));

        let switch_csr = ProveStrategy::parse("switch-context-sensitive").unwrap();
        assert!(matches!(
            switch_csr,
            ProveStrategy::Processor(ProveStrategyProcessor::SwitchContextSensitive)
        ));

        let csr_innermost = ProveStrategy::parse("csr-innermost").unwrap();
        assert!(matches!(
            csr_innermost,
            ProveStrategy::Processor(ProveStrategyProcessor::CsrInnermostEquivalence)
        ));
        assert!(matches!(
            ProveStrategy::parse("csr-innermost(graph; size-change)").unwrap(),
            ProveStrategy::Processor(ProveStrategyProcessor::CsrInnermostEquivalenceWithStrategy(
                _
            ))
        ));

        let csr_innermost_rta08 = ProveStrategy::parse("csr-innermost-rta08").unwrap();
        assert!(matches!(
            csr_innermost_rta08,
            ProveStrategy::Processor(ProveStrategyProcessor::CsrInnermostRta08Equivalence)
        ));
        let csr_innermost_rta08_with_strategy = ProveStrategy::parse(
            "csr-innermost-rta08(graph; poly(max-constant=2,max-coefficient=1))",
        )
        .unwrap();
        assert!(matches!(
            csr_innermost_rta08_with_strategy,
            ProveStrategy::Processor(
                ProveStrategyProcessor::CsrInnermostRta08EquivalenceWithStrategy(_)
            )
        ));

        let uncurry = ProveStrategy::parse("uncurry").unwrap();
        assert!(matches!(
            uncurry,
            ProveStrategy::Processor(ProveStrategyProcessor::Uncurry)
        ));

        let poly = ProveStrategy::parse("poly(2,1,17,3)").unwrap();
        assert!(matches!(
            poly,
            ProveStrategy::Processor(ProveStrategyProcessor::LinearPolynomial {
                max_constant: 2,
                max_coefficient: 1,
                max_symbols: Some(17),
                max_arity: Some(3)
            })
        ));

        let kbo = ProveStrategy::parse("kbo(1,7)").unwrap();
        assert!(matches!(
            kbo,
            ProveStrategy::Processor(ProveStrategyProcessor::Kbo {
                max_weight: 1,
                max_symbols: 7
            })
        ));

        let path_order = ProveStrategy::parse("path-order").unwrap();
        assert!(matches!(
            path_order,
            ProveStrategy::Processor(ProveStrategyProcessor::PathOrder {
                max_symbols: usize::MAX
            })
        ));

        for atom in ["path-order(max-symbols=17)", "rpo(symbols=17)", "lpo(max_symbols=17)"] {
            assert!(matches!(ProveStrategy::parse(atom).unwrap(),
                ProveStrategy::Processor(ProveStrategyProcessor::PathOrder { max_symbols: 17 })));
            assert_eq!(guided_top_level_atom_timeout(atom), Duration::from_secs(60));
        }
        assert!(ProveStrategy::parse("path-order(max-symbols=bad)").is_err());
        let shared = ProveStrategyProcessor::SharedPathOrder { max_symbols: 17 };
        assert_eq!(ProveStrategy::parse(&shared.to_strategy_atom()).unwrap(),
                   ProveStrategy::Processor(shared));
        assert!(ProveStrategy::parse("path-order(shared=2)").is_err());

        let named_poly =
            ProveStrategy::parse("poly(const=2, coeff=1, symbols=17, arity=3)").unwrap();
        assert!(matches!(
            named_poly,
            ProveStrategy::Processor(ProveStrategyProcessor::LinearPolynomial {
                max_constant: 2,
                max_coefficient: 1,
                max_symbols: Some(17),
                max_arity: Some(3)
            })
        ));

        let named_kbo = ProveStrategy::parse("kbo(weight=1, symbols=7)").unwrap();
        assert!(matches!(
            named_kbo,
            ProveStrategy::Processor(ProveStrategyProcessor::Kbo {
                max_weight: 1,
                max_symbols: 7
            })
        ));

        let match_bounds = ProveStrategy::parse("match-bounds(max-bound=3)").unwrap();
        assert!(matches!(
            match_bounds,
            ProveStrategy::Processor(ProveStrategyProcessor::SrsMatchBounds {
                max_bound: 3,
                max_states: DEFAULT_SRS_MATCH_BOUNDS_MAX_STATES,
                max_transitions: DEFAULT_SRS_MATCH_BOUNDS_MAX_TRANSITIONS,
            })
        ));

        let relative_match_bounds =
            ProveStrategy::parse("relative-match-bounds(max-bound=3)").unwrap();
        assert!(matches!(
            relative_match_bounds,
            ProveStrategy::Processor(ProveStrategyProcessor::SrsRelativeMatchBounds {
                max_bound: 3,
                max_states: DEFAULT_SRS_MATCH_BOUNDS_MAX_STATES,
                max_transitions: DEFAULT_SRS_MATCH_BOUNDS_MAX_TRANSITIONS,
            })
        ));

        let relative_match_bounds_removal =
            ProveStrategy::parse("relative-match-bounds-removal(max-bound=3)").unwrap();
        assert!(matches!(
            relative_match_bounds_removal,
            ProveStrategy::Processor(ProveStrategyProcessor::SrsRelativeMatchBoundsRemoval {
                max_bound: 3,
                max_states: DEFAULT_SRS_MATCH_BOUNDS_MAX_STATES,
                max_transitions: DEFAULT_SRS_MATCH_BOUNDS_MAX_TRANSITIONS,
            })
        ));

        let rfc_match_bounds = ProveStrategy::parse(
            "rfc-match-bounds(max-bound=4, max-words=123, max-word-len=17, max-states=9000, max-transitions=120000)",
        )
        .unwrap();
        assert!(matches!(
            rfc_match_bounds,
            ProveStrategy::Processor(ProveStrategyProcessor::SrsRfcMatchBounds {
                max_bound: 4,
                max_words: 123,
                max_word_len: 17,
                max_states: 9000,
                max_transitions: 120000,
                at_bound: SrsMatchAtBound::Exact,
                closure: SrsRfcBarrenClosure::Right,
            })
        ));

        let rfc_relative_match_bounds = ProveStrategy::parse(
            "rfc-relative-match-bounds(max-bound=4, max-words=123, max-word-len=17, max-states=9000, max-transitions=120000, at-bound=merge, closure=full)",
        )
        .unwrap();
        assert!(matches!(
            rfc_relative_match_bounds,
            ProveStrategy::Processor(ProveStrategyProcessor::SrsRfcRelativeMatchBounds {
                allow_partial: false,
                absolute_residual: false,
                layered_seconds: 2,
                fresh_seconds: 2,
                min_bound: 0,
                max_bound: 4,
                max_words: 123,
                max_word_len: 17,
                max_states: 9000,
                max_transitions: 120000,
                at_bound: SrsMatchAtBound::Merge,
                closure: SrsRfcBarrenClosure::Full,
            })
        ));

        let large_match_bounds = ProveStrategy::parse(
            "match-bounds(max-bound=7, max-states=9000, max-transitions=120000)",
        )
        .unwrap();
        assert!(matches!(
            large_match_bounds,
            ProveStrategy::Processor(ProveStrategyProcessor::SrsMatchBounds {
                max_bound: 7,
                max_states: 9000,
                max_transitions: 120000,
            })
        ));

        let weighted_length = ProveStrategy::parse("srs-weighted-length(max-weight=9)").unwrap();
        assert!(matches!(
            weighted_length,
            ProveStrategy::Processor(ProveStrategyProcessor::SrsWeightedLength { max_weight: 9 })
        ));

        let weighted_removal =
            ProveStrategy::parse("srs-weighted-rule-removal(max-weight=9)").unwrap();
        assert!(matches!(
            weighted_removal,
            ProveStrategy::Processor(ProveStrategyProcessor::SrsWeightedRuleRemoval {
                max_weight: 9
            })
        ));

        let strict_length = ProveStrategy::parse("srs-length").unwrap();
        assert!(matches!(
            strict_length,
            ProveStrategy::Processor(ProveStrategyProcessor::SrsLength)
        ));
    }

    #[test]
    fn wall_clock_budget_follows_selected_top_level_branch() {
        let full = Trs::new(None, BTreeSet::new(), Vec::new());
        let innermost = Trs::new_with_strategy(
            None,
            BTreeSet::new(),
            Vec::new(),
            RewriteStrategy::Innermost,
        );
        let strategy = ProveStrategy::parse(
            "if(innermost, timeout(1s, dp), timeout(300s, parallel(dp | timeout(2s, path-order))))",
        )
        .unwrap();

        assert_eq!(
            prove_strategy_wall_clock_budget(&strategy, &full),
            Some(Duration::from_secs(300))
        );
        assert_eq!(
            prove_strategy_wall_clock_budget(&strategy, &innermost),
            Some(Duration::from_secs(1))
        );
    }

    #[test]
    fn string_reversal_rejects_unary_srs_with_constants_for_ceta() {
        let trs = Trs::new(
            None,
            BTreeSet::from([Variable::new("x")]),
            vec![
                RewriteRule::new(
                    Term::app("f", vec![Term::app("s", vec![Term::var("x")])]),
                    Term::app(
                        "s",
                        vec![Term::app(
                            "f",
                            vec![Term::app(
                                "f",
                                vec![Term::app("p", vec![Term::app("s", vec![Term::var("x")])])],
                            )],
                        )],
                    ),
                ),
                RewriteRule::new(
                    Term::app("f", vec![Term::app("0", Vec::new())]),
                    Term::app("0", Vec::new()),
                ),
                RewriteRule::new(
                    Term::app("p", vec![Term::app("s", vec![Term::var("x")])]),
                    Term::var("x"),
                ),
            ],
        );

        assert!(reverse_srs_rules(trs.rules()).is_none());
    }

    #[test]
    fn top_level_path_order_smt_uses_shared_comparison_variables() {
        let trs = Trs::new(
            None,
            BTreeSet::from([Variable::new("x")]),
            vec![RewriteRule::new(
                Term::app("f", vec![Term::app("s", vec![Term::var("x")])]),
                Term::app("f", vec![Term::var("x")]),
            )],
        );
        let arities = trs
            .arities()
            .into_iter()
            .map(|(symbol, arity)| (symbol.as_str().to_string(), arity))
            .collect::<BTreeMap<_, _>>();
        let symbols = arities.keys().cloned().collect::<Vec<_>>();
        let filter_entries = top_level_path_order_permutation_filter_entries_by_symbol(&arities);
        let script = top_level_path_order_smt_script(&trs, &symbols, &filter_entries, None)
            .expect("path-order script should build");

        assert!(script.contains("(declare-const pogt_"));
        assert!(script.contains(" Bool)"));
        assert!(script.contains("(assert (= pogt_"));
    }

    #[test]
    fn top_level_path_order_synthesizes_simple_rule_removal() {
        if !top_smt_command_exists("z3") && !top_smt_command_exists("cvc5") {
            return;
        }
        let rule = RewriteRule::new(
            Term::app("f", vec![Term::app("s", vec![Term::var("x")])]),
            Term::app("f", vec![Term::var("x")]),
        );
        let trs = Trs::new(
            None,
            BTreeSet::from([Variable::new("x")]),
            vec![rule.clone()],
        );
        let removal = synthesize_top_level_path_order_removal_with_deadline(&trs, usize::MAX, None)
            .expect("path-order should remove the simple rule");

        assert_eq!(removal.removed, vec![rule]);
        assert!(removal.remaining.rules().is_empty());
    }

    #[test]
    fn top_level_path_order_checker_accepts_sk90_4_02_qrpo_witness() {
        let x = Term::var("x");
        let y = Term::var("y");
        let z = Term::var("z");
        let one = Term::app("|1|", Vec::new());
        let mul = |a: Term, b: Term| Term::app("*", vec![a, b]);
        let inv = |a: Term| Term::app("i", vec![a]);
        let k = |a: Term, b: Term| Term::app("k", vec![a, b]);
        let rules = vec![
            RewriteRule::new(mul(x.clone(), one.clone()), x.clone()),
            RewriteRule::new(mul(one.clone(), y.clone()), y.clone()),
            RewriteRule::new(mul(inv(x.clone()), x.clone()), one.clone()),
            RewriteRule::new(mul(x.clone(), inv(x.clone())), one.clone()),
            RewriteRule::new(
                mul(x.clone(), mul(y.clone(), z.clone())),
                mul(mul(x.clone(), y.clone()), z.clone()),
            ),
            RewriteRule::new(inv(one.clone()), one.clone()),
            RewriteRule::new(mul(mul(x.clone(), y.clone()), inv(y.clone())), x.clone()),
            RewriteRule::new(mul(mul(x.clone(), inv(y.clone())), y.clone()), x.clone()),
            RewriteRule::new(inv(inv(x.clone())), x.clone()),
            RewriteRule::new(
                inv(mul(x.clone(), y.clone())),
                mul(inv(y.clone()), inv(x.clone())),
            ),
            RewriteRule::new(k(x.clone(), one.clone()), one.clone()),
            RewriteRule::new(k(x.clone(), x.clone()), one.clone()),
            RewriteRule::new(
                mul(k(x.clone(), y.clone()), k(y.clone(), x.clone())),
                one.clone(),
            ),
            RewriteRule::new(
                mul(mul(inv(x.clone()), k(y.clone(), z.clone())), x.clone()),
                k(
                    mul(mul(inv(x.clone()), y.clone()), x.clone()),
                    mul(mul(inv(x.clone()), z.clone()), x.clone()),
                ),
            ),
            RewriteRule::new(
                k(
                    mul(x.clone(), inv(y.clone())),
                    mul(y.clone(), inv(x.clone())),
                ),
                one.clone(),
            ),
        ];
        let trs = Trs::new(
            None,
            BTreeSet::from([Variable::new("x"), Variable::new("y"), Variable::new("z")]),
            rules.clone(),
        );
        let statuses = BTreeMap::from([
            ("*".to_string(), DpPathOrderKind::Lpo),
            ("|1|".to_string(), DpPathOrderKind::Rpo),
            ("i".to_string(), DpPathOrderKind::Lpo),
            ("k".to_string(), DpPathOrderKind::Lpo),
        ]);
        let precedence = vec![
            "i".to_string(),
            "*".to_string(),
            "|1|".to_string(),
            "k".to_string(),
        ];
        let precedence_ranks = BTreeMap::from([
            ("i".to_string(), 0),
            ("*".to_string(), 1),
            ("|1|".to_string(), 2),
            ("k".to_string(), 2),
        ]);
        let argument_filter = BTreeMap::from([
            (
                "*".to_string(),
                DpArgumentFilterEntry::NonCollapsing(vec![1, 0]),
            ),
            (
                "|1|".to_string(),
                DpArgumentFilterEntry::NonCollapsing(vec![]),
            ),
            (
                "i".to_string(),
                DpArgumentFilterEntry::NonCollapsing(vec![0]),
            ),
            (
                "k".to_string(),
                DpArgumentFilterEntry::NonCollapsing(vec![0, 1]),
            ),
        ]);

        let removal = checked_top_level_path_order_removal_with_ranks(
            &trs,
            &statuses,
            &precedence,
            &precedence_ranks,
            &argument_filter,
        )
        .expect("AProVE QRPO witness should remove all rules");

        assert_eq!(removal.removed, rules);
        assert!(removal.remaining.rules().is_empty());
    }

    #[test]
    fn uncurrying_transform_flattens_applicative_chains() {
        let trs = Trs::new(
            None,
            BTreeSet::new(),
            vec![RewriteRule::new(
                Term::app(
                    "app",
                    vec![
                        Term::app("app", vec![Term::app("f", vec![]), Term::app("a", vec![])]),
                        Term::app("b", vec![]),
                    ],
                ),
                Term::app("c", vec![]),
            )],
        );

        let transform = synthesize_uncurrying_transform(&trs).unwrap();
        assert_eq!(transform.uncurry_rules.len(), 2);
        assert!(transform.symbols.iter().any(|entry| {
            entry.original.as_str() == "f"
                && entry.symbols.iter().map(Symbol::as_str).collect::<Vec<_>>()
                    == vec!["f", "f1", "f2"]
        }));
        assert!(matches!(
            transform.transformed.rules()[0].lhs(),
            Term::App { symbol, args } if symbol.as_str() == "f2" && args.len() == 2
        ));
        assert_eq!(transform.transformed.strategy(), RewriteStrategy::Full);
    }

    #[test]
    fn uncurrying_infers_unique_binary_application_symbol_for_atrs() {
        let x = Term::var("x");
        let app = |left, right| Term::app("f", vec![left, right]);
        let a = || Term::app("a", vec![]);
        let b = || Term::app("b", vec![]);
        let trs = Trs::new(
            None,
            BTreeSet::from([Variable::new("x")]),
            vec![
                RewriteRule::new(
                    app(a(), app(b(), x.clone())),
                    app(a(), app(a(), app(a(), x.clone()))),
                ),
                RewriteRule::new(
                    app(b(), app(a(), x.clone())),
                    app(b(), app(b(), app(b(), x))),
                ),
            ],
        );

        let transform = synthesize_uncurrying_transform(&trs).unwrap();
        assert_eq!(transform.app_symbol.as_str(), "f");
        assert_eq!(transform.uncurry_rules.len(), 2);
        assert!(transform.symbols.iter().any(|entry| {
            entry.original.as_str() == "a"
                && entry.symbols.iter().map(Symbol::as_str).collect::<Vec<_>>() == vec!["a", "a1"]
        }));
        assert!(transform.symbols.iter().any(|entry| {
            entry.original.as_str() == "b"
                && entry.symbols.iter().map(Symbol::as_str).collect::<Vec<_>>() == vec!["b", "b1"]
        }));
        assert!(matches!(
            transform.transformed.rules()[0].lhs(),
            Term::App { symbol, args } if symbol.as_str() == "a1" && args.len() == 1
        ));
    }

    #[test]
    fn uncurrying_role_parameter_parses_without_a_symbol_witness() {
        assert!(matches!(ProveStrategy::parse("uncurry(role=2)").unwrap(),
            ProveStrategy::Processor(ProveStrategyProcessor::UncurryRole { role: 2 })));
        assert!(ProveStrategy::parse("uncurry(role=invalid)").is_err());
    }

    #[test]
    fn inferred_uncurrying_rejects_non_applicative_mixed_signature() {
        let trs = Trs::new(
            None,
            BTreeSet::from([Variable::new("x")]),
            vec![RewriteRule::new(
                Term::app(
                    "f",
                    vec![Term::app("g", vec![Term::var("x")]), Term::var("x")],
                ),
                Term::var("x"),
            )],
        );

        assert!(infer_uncurrying_application_symbol(&trs).is_none());
    }

    #[test]
    fn uncurrying_turns_innermost_input_into_full_residual_problem() {
        let trs = Trs::new_with_strategy(
            None,
            BTreeSet::from([Variable::new("x")]),
            vec![RewriteRule::new(
                Term::app("app", vec![Term::app("f", vec![]), Term::var("x")]),
                Term::app("a", vec![]),
            )],
            RewriteStrategy::Innermost,
        );

        let transform = synthesize_uncurrying_transform(&trs).unwrap();
        assert_eq!(transform.transformed.strategy(), RewriteStrategy::Full);

        let proof = prove(
            &trs,
            &ProveOptions {
                strategy: ProveStrategy::parse("uncurry").unwrap(),
                ..ProveOptions::default()
            },
        );
        assert_eq!(proof.status(), &Status::Terminating);
        assert!(matches!(proof.steps(), [ProofStep::Uncurry { .. }]));
        let cpf = write_cpf(&trs, &proof, CpfMode::Cpf30).unwrap();
        assert!(cpf.contains("<innermost><nfs>true</nfs></innermost>"));
        assert!(cpf.contains("<uncurry>"));
        assert!(!cpf.contains("<switchInnermost>"));
    }

    #[test]
    fn uncurrying_strategy_can_prove_small_applicative_trs() {
        let trs = Trs::new(
            None,
            BTreeSet::from([Variable::new("x")]),
            vec![RewriteRule::new(
                Term::app("app", vec![Term::app("f", vec![]), Term::var("x")]),
                Term::app("a", vec![]),
            )],
        );
        let options = ProveOptions {
            strategy: ProveStrategy::parse("uncurry").unwrap(),
            ..ProveOptions::default()
        };
        let proof = prove(&trs, &options);
        assert_eq!(proof.status(), &Status::Terminating);
        assert!(matches!(proof.steps(), [ProofStep::Uncurry { .. }]));
        let cpf = write_cpf(&trs, &proof, CpfMode::Cpf30).unwrap();
        assert!(cpf.contains("<uncurry>"));
        assert!(cpf.contains("<uncurryRules>"));
        assert!(!cpf.contains("<switchInnermost>"));
    }

    #[test]
    fn uncurrying_can_preserve_a_nontermination_proof() {
        for relative_path in [
            "../TPDB-ARI/TRS_Standard/AotoYamada_05/001.ari",
            "../TPDB-ARI/TRS_Standard/Transformed_CSR_04/Ex9_Luc04_L.ari",
        ] {
            let path = Path::new(relative_path);
            let input = fs::read_to_string(path)
                .unwrap_or_else(|error| panic!("failed to read {}: {error}", path.display()));
            let trs = parse_trs(Some(path.display().to_string()), &input)
                .unwrap_or_else(|error| panic!("failed to parse {}: {error}", path.display()));
            let proof = prove(
                &trs,
                &ProveOptions {
                    strategy: ProveStrategy::parse("uncurry").unwrap(),
                    ..ProveOptions::default()
                },
            );

            assert_eq!(proof.status(), &Status::Nonterminating);
            assert!(matches!(proof.steps(), [ProofStep::Uncurry { .. }]));
            let cpf = write_cpf(&trs, &proof, CpfMode::Cpf30).unwrap();
            assert!(cpf.contains("<uncurry>"));
            assert!(cpf.contains("<trsNonterminationProof>"));
            assert!(cpf.contains("<loop>"));
        }
    }

    #[test]
    fn uncurrying_strategy_proves_inferred_application_symbol_example() {
        let x = Term::var("x");
        let app = |left, right| Term::app("f", vec![left, right]);
        let a = || Term::app("a", vec![]);
        let b = || Term::app("b", vec![]);
        let trs = Trs::new(
            None,
            BTreeSet::from([Variable::new("x")]),
            vec![
                RewriteRule::new(
                    app(a(), app(b(), x.clone())),
                    app(a(), app(a(), app(a(), x.clone()))),
                ),
                RewriteRule::new(
                    app(b(), app(a(), x.clone())),
                    app(b(), app(b(), app(b(), x))),
                ),
            ],
        );
        let options = ProveOptions {
            strategy: ProveStrategy::parse("uncurry").unwrap(),
            ..ProveOptions::default()
        };

        let proof = prove(&trs, &options);

        assert_eq!(proof.status(), &Status::Terminating);
        assert!(matches!(
            proof.steps(),
            [ProofStep::Uncurry { proof }] if proof.app_symbol.as_str() == "f"
        ));
        let cpf = write_cpf(&trs, &proof, CpfMode::Cpf30).unwrap();
        assert!(cpf.contains("<uncurry>"));
        assert!(cpf.contains("<name>f</name>"));
    }

    #[test]
    fn uncurrying_materializes_the_zantema05_z05_residual() {
        let trs = parse_trs(None, include_str!("../../tests/fixtures/zantema05_z05.ari"))
            .expect("z05 fixture");
        let ProcessorResult::Applied(application) =
            UncurryProcessor.apply(&ProblemState::Trs(trs.clone()))
        else {
            panic!("z05 should be uncurrying-applicable")
        };
        let (residuals, _) = application.into_parts();
        let [ProblemState::Trs(residual)] = residuals.as_slice() else {
            panic!("uncurrying should expose one ordinary TRS residual")
        };
        assert_ne!(residual.rules(), trs.rules());
        assert!(residual.rules().iter().any(|rule| {
            rule.lhs()
                .root_symbol()
                .is_some_and(|symbol| symbol.as_str().ends_with('1'))
        }));
    }

    #[test]
    fn uncurrying_rejects_lhs_variable_head_applications() {
        let trs = Trs::new(
            None,
            BTreeSet::from([Variable::new("l"), Variable::new("k")]),
            vec![RewriteRule::new(
                Term::app("app", vec![Term::var("l"), Term::app("nil", vec![])]),
                Term::var("l"),
            )],
        );
        assert!(synthesize_uncurrying_transform(&trs).is_none());
    }

    #[test]
    fn uncurrying_generates_eta_expansion_rules() {
        let trs = Trs::new(
            None,
            BTreeSet::from([Variable::new("x")]),
            vec![
                RewriteRule::new(
                    Term::app("app", vec![Term::app("id", vec![]), Term::var("x")]),
                    Term::var("x"),
                ),
                RewriteRule::new(
                    Term::app(
                        "app",
                        vec![Term::app("add", vec![]), Term::app("zero", vec![])],
                    ),
                    Term::app("id", vec![]),
                ),
                RewriteRule::new(
                    Term::app(
                        "app",
                        vec![
                            Term::app(
                                "app",
                                vec![
                                    Term::app("add", vec![]),
                                    Term::app("s", vec![Term::var("x")]),
                                ],
                            ),
                            Term::var("y"),
                        ],
                    ),
                    Term::app(
                        "s",
                        vec![Term::app(
                            "app",
                            vec![
                                Term::app("app", vec![Term::app("add", vec![]), Term::var("x")]),
                                Term::var("y"),
                            ],
                        )],
                    ),
                ),
            ],
        );
        let transform = synthesize_uncurrying_transform(&trs).unwrap();
        assert_eq!(transform.eta_rules.len(), 1);
        assert!(matches!(
            transform.eta_rules[0].lhs(),
            Term::App { symbol, args }
                if symbol.as_str() == "app"
                    && args.len() == 2
                    && matches!(&args[0], Term::App { symbol, .. } if symbol.as_str() == "app")
        ));
    }

    #[test]
    fn uncurrying_eta_saturates_collapsing_rhs_rules() {
        let trs = Trs::new(
            None,
            BTreeSet::from([Variable::new("x")]),
            vec![
                RewriteRule::new(
                    Term::app("+", vec![Term::app("one", Vec::new()), Term::var("x")]),
                    Term::app(
                        "+",
                        vec![
                            Term::app(
                                "+",
                                vec![Term::app("zero", Vec::new()), Term::app("one", Vec::new())],
                            ),
                            Term::var("x"),
                        ],
                    ),
                ),
                RewriteRule::new(
                    Term::app("+", vec![Term::app("zero", Vec::new()), Term::var("x")]),
                    Term::var("x"),
                ),
            ],
        );

        let transform = synthesize_uncurrying_transform(&trs).unwrap();
        assert_eq!(transform.eta_rules.len(), 1);
        assert!(matches!(
            transform.eta_rules[0].rhs(),
            Term::App { symbol, args }
                if symbol.as_str() == "+"
                    && matches!(&args[0], Term::Var(variable) if variable.as_str() == "x")
        ));
    }

    #[test]
    fn default_strategy_is_loaded_from_checked_in_file() {
        let parsed = ProveStrategy::parse(DEFAULT_PROVE_STRATEGY_SOURCE).unwrap();
        assert_eq!(ProveStrategy::default_from_file(), parsed);
        assert_eq!(ProveOptions::default().strategy, parsed);
    }

    #[test]
    fn exact_root_proof_atoms_round_trip() {
        let processors = [
            ProveStrategyProcessor::ExactNonterminationTerminal {
                source_trs_input_xml: "<trsInput><trs><rules/></trs></trsInput>".into(),
                terminal_xml: "<variableConditionViolated/>"
                    .into(),
            },
        ];
        for processor in processors {
            let atom = processor.to_strategy_atom();
            let parsed = ProveStrategy::parse(&atom).unwrap();
            assert_eq!(parsed, ProveStrategy::Processor(processor));
        }
    }

    #[test]
    fn qtrs_to_csr_selects_the_full_termination_transformation() {
        assert_eq!(
            ProveStrategy::parse("qtrs-to-csr").unwrap(),
            ProveStrategy::Processor(ProveStrategyProcessor::Gm04InverseContextSensitiveFull)
        );
        assert_eq!(
            ProveStrategy::parse("gm04-inverse-csr").unwrap(),
            ProveStrategy::Processor(ProveStrategyProcessor::Gm04InverseContextSensitive)
        );
    }

    #[test]
    fn certified_linear_oracle_recipe_accepts_only_exact_rule_removals() {
        let exact = ProveStrategy::parse(
            "exact-poly(hex=5b5b2266222c302c5b315d5d5d);\
             exact-matrix(hex=5b5b2266222c5b305d2c5b5b5b315d5d5d5d5d)",
        )
        .unwrap();
        assert!(matches!(
            certified_linear_oracle_processor(&exact),
            Some(ProveStrategyProcessor::CertifiedLinearSequence(processors))
                if processors.len() == 2
        ));

        let branching = ProveStrategy::parse(
            "parallel(exact-poly(hex=5b5b2266222c302c5b315d5d5d),\
             exact-matrix(hex=5b5b2266222c5b305d2c5b5b5b315d5d5d5d5d))",
        )
        .unwrap();
        let mixed = ProveStrategy::parse("exact-poly(hex=5b5b2266222c302c5b315d5d5d);dp").unwrap();
        assert!(certified_linear_oracle_processor(&branching).is_none());
        assert!(certified_linear_oracle_processor(&mixed).is_none());
    }

    #[test]
    fn scoped_outermost_rz_uses_full_trs_continuation() {
        let trs = Trs::new_with_strategy(
            None,
            BTreeSet::from([Variable::new("x")]),
            vec![RewriteRule::new(
                Term::app("f", vec![Term::var("x")]),
                Term::var("x"),
            )],
            RewriteStrategy::Outermost,
        );
        let mut options = ProveOptions::default();
        options.strategy = ProveStrategy::parse("timeout(5s, outermost-rz)").unwrap();

        let proof = prove(&trs, &options);

        assert_eq!(proof.status(), &Status::Terminating);
        assert!(matches!(
            proof.steps().first(),
            Some(ProofStep::OutermostRaffelsieperZantemaTransformation { .. })
        ));
    }

    #[test]
    fn default_srs_strategy_uses_explicit_srs_portfolio() {
        let parsed = ProveStrategy::parse(DEFAULT_PROVE_STRATEGY_SOURCE).unwrap();
        fn collect_srs_branches<'a>(
            strategy: &'a ProveStrategy,
            branches: &mut Vec<&'a ProveStrategy>,
        ) {
            match strategy {
                ProveStrategy::Conditional {
                    condition: ProveStrategyCondition::Srs,
                    then_strategy,
                    ..
                } => branches.push(then_strategy.as_ref()),
                ProveStrategy::Conditional {
                    then_strategy,
                    else_strategy,
                    ..
                } => {
                    collect_srs_branches(then_strategy, branches);
                    collect_srs_branches(else_strategy, branches);
                }
                ProveStrategy::Sequence(strategies)
                | ProveStrategy::Choice(strategies)
                | ProveStrategy::Parallel(strategies) => {
                    for strategy in strategies {
                        collect_srs_branches(strategy, branches);
                    }
                }
                ProveStrategy::Timeout { strategy, .. } | ProveStrategy::Delay { strategy, .. } => {
                    collect_srs_branches(strategy, branches)
                }
                ProveStrategy::Processor(_) => {}
            }
        }
        let mut srs_branches = Vec::new();
        collect_srs_branches(&parsed, &mut srs_branches);
        assert!(
            !srs_branches.is_empty(),
            "default strategy must dispatch on SRS"
        );
        assert!(srs_branches.iter().any(|srs_strategy| {
            let ProveStrategy::Timeout { strategy, .. } = srs_strategy else {
                return false;
            };
            let ProveStrategy::Parallel(branches) = strategy.as_ref() else {
                return false;
            };
            let debug = format!("{branches:?}");
            branches.len() == 2
                && debug.contains("SrsRelativeMatchBounds")
                && debug.contains("SrsWeightedLength")
                && debug.contains("SrsWeightedRuleRemoval")
                && debug.contains("StringReversal")
        }));
    }

    #[test]
    fn default_strategy_routes_transformed_csr_before_srs() {
        let parsed = ProveStrategy::parse(DEFAULT_PROVE_STRATEGY_SOURCE).unwrap();
        fn transformed_csr_precedes_srs(strategy: &ProveStrategy) -> bool {
            match strategy {
                ProveStrategy::Conditional {
                    condition: ProveStrategyCondition::TransformedCsr,
                    else_strategy,
                    ..
                } => contains_condition(else_strategy, &ProveStrategyCondition::Srs),
                ProveStrategy::Conditional {
                    then_strategy,
                    else_strategy,
                    ..
                } => {
                    transformed_csr_precedes_srs(then_strategy)
                        || transformed_csr_precedes_srs(else_strategy)
                }
                ProveStrategy::Sequence(strategies)
                | ProveStrategy::Choice(strategies)
                | ProveStrategy::Parallel(strategies) => {
                    strategies.iter().any(transformed_csr_precedes_srs)
                }
                ProveStrategy::Timeout { strategy, .. } | ProveStrategy::Delay { strategy, .. } => {
                    transformed_csr_precedes_srs(strategy)
                }
                ProveStrategy::Processor(_) => false,
            }
        }
        fn contains_condition(strategy: &ProveStrategy, needle: &ProveStrategyCondition) -> bool {
            match strategy {
                ProveStrategy::Conditional {
                    condition,
                    then_strategy,
                    else_strategy,
                } => {
                    condition == needle
                        || contains_condition(then_strategy, needle)
                        || contains_condition(else_strategy, needle)
                }
                ProveStrategy::Sequence(strategies)
                | ProveStrategy::Choice(strategies)
                | ProveStrategy::Parallel(strategies) => strategies
                    .iter()
                    .any(|strategy| contains_condition(strategy, needle)),
                ProveStrategy::Timeout { strategy, .. } | ProveStrategy::Delay { strategy, .. } => {
                    contains_condition(strategy, needle)
                }
                ProveStrategy::Processor(_) => false,
            }
        }

        assert!(transformed_csr_precedes_srs(&parsed));
    }

    #[test]
    fn default_transformed_csr_route_excludes_uncertified_switch_csr() {
        fn switch_csr_timeouts(strategy: &ProveStrategy, outer: Option<Duration>) -> Vec<Duration> {
            match strategy {
                ProveStrategy::Processor(ProveStrategyProcessor::SwitchContextSensitive) => {
                    outer.into_iter().collect()
                }
                ProveStrategy::Conditional {
                    then_strategy,
                    else_strategy,
                    ..
                } => [then_strategy, else_strategy]
                    .into_iter()
                    .flat_map(|strategy| switch_csr_timeouts(strategy, outer))
                    .collect(),
                ProveStrategy::Sequence(strategies)
                | ProveStrategy::Choice(strategies)
                | ProveStrategy::Parallel(strategies) => strategies
                    .iter()
                    .flat_map(|strategy| switch_csr_timeouts(strategy, outer))
                    .collect(),
                ProveStrategy::Timeout { duration, strategy } => {
                    let timeout = outer.map_or(*duration, |outer| outer.min(*duration));
                    switch_csr_timeouts(strategy, Some(timeout))
                }
                ProveStrategy::Delay { strategy, .. } => switch_csr_timeouts(strategy, outer),
                ProveStrategy::Processor(_) => Vec::new(),
            }
        }

        let parsed = ProveStrategy::parse(DEFAULT_PROVE_STRATEGY_SOURCE).unwrap();
        let timeouts = switch_csr_timeouts(&parsed, None);
        assert!(timeouts.is_empty());
    }

    #[test]
    fn default_strategy_routes_innermost_before_srs() {
        let parsed = ProveStrategy::parse(DEFAULT_PROVE_STRATEGY_SOURCE).unwrap();
        let ProveStrategy::Conditional {
            condition: ProveStrategyCondition::Relative,
            else_strategy,
            ..
        } = parsed
        else {
            panic!("default strategy must dispatch on relative problems first");
        };
        let ProveStrategy::Conditional {
            condition: ProveStrategyCondition::Csr,
            else_strategy,
            ..
        } = *else_strategy
        else {
            panic!("default strategy must dispatch on CSR first");
        };
        let ProveStrategy::Conditional {
            condition: ProveStrategyCondition::TransformedCsr,
            else_strategy,
            ..
        } = *else_strategy
        else {
            panic!("default strategy must dispatch on transformed CSR second");
        };
        let ProveStrategy::Conditional {
            condition: ProveStrategyCondition::Innermost,
            else_strategy,
            ..
        } = *else_strategy
        else {
            panic!("default strategy must dispatch on innermost before SRS");
        };

        assert!(matches!(
            *else_strategy,
            ProveStrategy::Conditional {
                condition: ProveStrategyCondition::Srs,
                ..
            }
        ));
    }

    #[test]
    fn default_relative_strategy_uses_annotated_dependency_pairs() {
        let parsed = ProveStrategy::parse(DEFAULT_PROVE_STRATEGY_SOURCE).unwrap();
        let ProveStrategy::Conditional {
            condition: ProveStrategyCondition::Relative,
            then_strategy,
            ..
        } = parsed
        else {
            panic!("default strategy must dispatch on relative problems first");
        };
        assert!(format!("{then_strategy:?}").contains("RelativeAnnotatedDependencyPairs"));
    }

    #[test]
    fn top_level_strategy_conditions_parse() {
        let strategy = ProveStrategy::parse(
            "if(srs, match-bounds, if(innermost, dp, nontermination(variable-condition)))",
        )
        .unwrap();
        assert!(matches!(
            strategy,
            ProveStrategy::Conditional {
                condition: ProveStrategyCondition::Srs,
                ..
            }
        ));

        let strategy = ProveStrategy::parse("if(csr, csr-improved-dp, path-order)").unwrap();
        assert!(matches!(
            strategy,
            ProveStrategy::Conditional {
                condition: ProveStrategyCondition::Csr,
                ..
            }
        ));

        let strategy = ProveStrategy::parse("if(relative, relative-adp, path-order)").unwrap();
        assert!(matches!(
            strategy,
            ProveStrategy::Conditional {
                condition: ProveStrategyCondition::Relative,
                ..
            }
        ));

        let strategy =
            ProveStrategy::parse("if(all(unary-srs, not(strict-srs)), match-bounds, dp)").unwrap();
        assert!(matches!(
            strategy,
            ProveStrategy::Conditional {
                condition: ProveStrategyCondition::All(_),
                ..
            }
        ));

        let strategy = ProveStrategy::parse("if(transformed-csr, dp, srs-length)").unwrap();
        assert!(matches!(
            strategy,
            ProveStrategy::Conditional {
                condition: ProveStrategyCondition::TransformedCsr,
                ..
            }
        ));

        let strategy = ProveStrategy::parse("if(applicative, uncurry, dp)").unwrap();
        assert!(matches!(
            strategy,
            ProveStrategy::Conditional {
                condition: ProveStrategyCondition::Applicative,
                ..
            }
        ));

        let strategy = ProveStrategy::parse("if(outermost, outermost-rz, fail)").unwrap();
        assert!(matches!(
            strategy,
            ProveStrategy::Conditional {
                condition: ProveStrategyCondition::Outermost,
                ..
            }
        ));

        let strategy = ProveStrategy::parse("if(rules-at-least(30), dp, fail)").unwrap();
        assert!(matches!(
            strategy,
            ProveStrategy::Conditional {
                condition: ProveStrategyCondition::RulesAtLeast(30),
                ..
            }
        ));

        let strategy = ProveStrategy::parse("if(rules-at-most(15), dp, fail)").unwrap();
        assert!(matches!(
            strategy,
            ProveStrategy::Conditional {
                condition: ProveStrategyCondition::RulesAtMost(15),
                ..
            }
        ));
    }

    #[test]
    fn top_level_strategy_conditions_evaluate_problem_shape() {
        let variables = BTreeSet::from([Variable::new("x")]);
        let srs = Trs::new(
            None,
            variables.clone(),
            vec![RewriteRule::new(
                Term::app("a", vec![Term::var("x")]),
                Term::app("b", vec![Term::var("x")]),
            )],
        );
        assert!(evaluate_prove_strategy_condition(
            &ProveStrategyCondition::Srs,
            &srs
        ));
        assert!(evaluate_prove_strategy_condition(
            &ProveStrategyCondition::StrictSrs,
            &srs
        ));
        assert!(evaluate_prove_strategy_condition(
            &ProveStrategyCondition::Standard,
            &srs
        ));

        let innermost = Trs::new_with_strategy(
            None,
            variables,
            vec![RewriteRule::new(
                Term::app("f", vec![Term::var("x")]),
                Term::var("x"),
            )],
            RewriteStrategy::Innermost,
        );
        assert!(evaluate_prove_strategy_condition(
            &ProveStrategyCondition::Innermost,
            &innermost
        ));
        assert!(!evaluate_prove_strategy_condition(
            &ProveStrategyCondition::Standard,
            &innermost
        ));

        let outermost = Trs::new_with_strategy(
            None,
            BTreeSet::new(),
            vec![RewriteRule::new(
                Term::app("a", vec![]),
                Term::app("b", vec![]),
            )],
            RewriteStrategy::Outermost,
        );
        assert!(evaluate_prove_strategy_condition(
            &ProveStrategyCondition::Outermost,
            &outermost
        ));
        assert!(!evaluate_prove_strategy_condition(
            &ProveStrategyCondition::Standard,
            &outermost
        ));

        let applicative = Trs::new_with_strategy(
            None,
            BTreeSet::from([Variable::new("x")]),
            vec![RewriteRule::new(
                Term::app("app", vec![Term::app("f", vec![]), Term::var("x")]),
                Term::var("x"),
            )],
            RewriteStrategy::Innermost,
        );
        assert!(evaluate_prove_strategy_condition(
            &ProveStrategyCondition::Applicative,
            &applicative
        ));
        assert!(!evaluate_prove_strategy_condition(
            &ProveStrategyCondition::Applicative,
            &innermost
        ));
        assert!(evaluate_prove_strategy_condition(
            &ProveStrategyCondition::RulesAtLeast(1),
            &innermost
        ));
        assert!(!evaluate_prove_strategy_condition(
            &ProveStrategyCondition::RulesAtLeast(2),
            &innermost
        ));
        assert!(evaluate_prove_strategy_condition(
            &ProveStrategyCondition::RulesAtMost(1),
            &innermost
        ));
        assert!(!evaluate_prove_strategy_condition(
            &ProveStrategyCondition::RulesAtMost(0),
            &innermost
        ));

        let transformed_csr = Trs::new(
            None,
            BTreeSet::from([Variable::new("X")]),
            vec![
                RewriteRule::new(
                    Term::app("mark", vec![Term::app("f", vec![Term::var("X")])]),
                    Term::app("a__f", vec![Term::app("mark", vec![Term::var("X")])]),
                ),
                RewriteRule::new(
                    Term::app("a__f", vec![Term::var("X")]),
                    Term::app("f", vec![Term::var("X")]),
                ),
            ],
        );
        assert!(evaluate_prove_strategy_condition(
            &ProveStrategyCondition::TransformedCsr,
            &transformed_csr
        ));

        let direct_active_mark = Trs::new(
            None,
            BTreeSet::from([Variable::new("x")]),
            vec![
                RewriteRule::new(
                    Term::app("active", vec![Term::app("f", vec![Term::var("x")])]),
                    Term::app("mark", vec![Term::app("f", vec![Term::var("x")])]),
                ),
                RewriteRule::new(
                    Term::app("mark", vec![Term::app("f", vec![Term::var("x")])]),
                    Term::app("active", vec![Term::app("f", vec![Term::var("x")])]),
                ),
            ],
        );
        assert!(evaluate_prove_strategy_condition(
            &ProveStrategyCondition::TransformedCsr,
            &direct_active_mark
        ));

        let ordinary_active = Trs::new(
            None,
            BTreeSet::from([Variable::new("x")]),
            vec![RewriteRule::new(
                Term::app("active", vec![Term::var("x")]),
                Term::var("x"),
            )],
        );
        assert!(!evaluate_prove_strategy_condition(
            &ProveStrategyCondition::TransformedCsr,
            &ordinary_active
        ));
    }

    #[test]
    fn top_level_parallel_returns_without_waiting_for_cancelled_branch() {
        let variables = BTreeSet::from([Variable::new("x")]);
        let trs = Trs::new(
            None,
            variables,
            vec![RewriteRule::new(
                Term::app("f", vec![Term::app("s", vec![Term::var("x")])]),
                Term::app("f", vec![Term::var("x")]),
            )],
        );
        let started = Instant::now();
        let proof = prove(
            &trs,
            &ProveOptions {
                strategy: ProveStrategy::parse("parallel(delay(30s, path-order) | dp)").unwrap(),
                ..ProveOptions::default()
            },
        );

        assert_eq!(proof.status(), &Status::Terminating);
        let elapsed = started.elapsed();
        assert!(
            elapsed < Duration::from_secs(4),
            "cancelled top-level branch returned after {elapsed:?}"
        );
    }

    #[test]
    fn nested_parallel_resolves_inner_and_outer_siblings() {
        let variables = BTreeSet::from([Variable::new("x")]);
        let trs = Trs::new(
            None,
            variables,
            vec![RewriteRule::new(
                Term::app("f", vec![Term::app("s", vec![Term::var("x")])]),
                Term::app("f", vec![Term::var("x")]),
            )],
        );

        let proof = prove(
            &trs,
            &ProveOptions {
                strategy: ProveStrategy::parse(
                    "parallel(parallel(delay(30s, path-order) | dp) | delay(30s, path-order))",
                )
                .unwrap(),
                ..ProveOptions::default()
            },
        );

        assert_eq!(proof.status(), &Status::Terminating);
    }

    #[test]
    fn top_level_strategy_can_run_dp_directly() {
        let variables = BTreeSet::from([Variable::new("x")]);
        let trs = Trs::new(
            None,
            variables,
            vec![RewriteRule::new(
                Term::app("f", vec![Term::app("s", vec![Term::var("x")])]),
                Term::app("f", vec![Term::var("x")]),
            )],
        );
        let proof = prove(
            &trs,
            &ProveOptions {
                strategy: ProveStrategy::parse("dp").unwrap(),
                llm_first: false,
                ..ProveOptions::default()
            },
        );
        assert_eq!(proof.status(), &Status::Terminating);
        assert!(matches!(
            proof.steps()[0],
            ProofStep::DependencyPairProof { .. }
        ));
    }

    #[test]
    fn switch_csr_is_not_scheduled_without_a_transformation_certificate() {
        let variables = BTreeSet::from([Variable::new("x"), Variable::new("xs")]);
        let trs = Trs::new(
            None,
            variables,
            vec![
                RewriteRule::new(
                    Term::app(
                        "mark",
                        vec![Term::app("cons", vec![Term::var("x"), Term::var("xs")])],
                    ),
                    Term::app(
                        "cons",
                        vec![Term::app("mark", vec![Term::var("x")]), Term::var("xs")],
                    ),
                ),
                RewriteRule::new(
                    Term::app("mark", vec![Term::app("nil", vec![])]),
                    Term::app("nil", vec![]),
                ),
            ],
        );
        let proof = prove(
            &trs,
            &ProveOptions {
                strategy: ProveStrategy::parse("switch-csr").unwrap(),
                ..ProveOptions::default()
            },
        );
        assert_eq!(proof.status(), &Status::Unknown);
    }

    #[test]
    fn switch_csr_cannot_claim_a_small_full_trs() {
        let trs = Trs::new(
            None,
            BTreeSet::new(),
            vec![RewriteRule::new(
                Term::app("mark", vec![Term::app("a", vec![])]),
                Term::app("b", vec![]),
            )],
        );
        let proof = prove(
            &trs,
            &ProveOptions {
                strategy: ProveStrategy::parse("switch-csr").unwrap(),
                ..ProveOptions::default()
            },
        );
        assert_eq!(proof.status(), &Status::Unknown);
    }

    #[test]
    fn csr_loop_strategy_returns_a_checked_nontermination_witness() {
        let rules = vec![
            RewriteRule::new(
                Term::app("zeros", vec![]),
                Term::app(
                    "cons",
                    vec![Term::app("0", vec![]), Term::app("zeros", vec![])],
                ),
            ),
            RewriteRule::new(
                Term::app(
                    "length",
                    vec![Term::app("cons", vec![Term::var("n"), Term::var("xs")])],
                ),
                Term::app("s", vec![Term::app("length", vec![Term::var("xs")])]),
            ),
        ];
        let trs = Trs::new(
            None,
            BTreeSet::from([Variable::new("n"), Variable::new("xs")]),
            rules,
        );
        let csr = CsrTrs::new(
            trs,
            ReplacementMap::new(BTreeMap::from([
                (Symbol::new("zeros"), BTreeSet::new()),
                (Symbol::new("0"), BTreeSet::new()),
                (Symbol::new("cons"), BTreeSet::from([0])),
                (Symbol::new("length"), BTreeSet::from([0])),
                (Symbol::new("s"), BTreeSet::from([0])),
            ])),
        )
        .unwrap();

        let proof = prove_context_sensitive(
            &csr,
            &ProveOptions {
                strategy: ProveStrategy::parse("csr-loop").unwrap(),
                llm_first: false,
                ..ProveOptions::default()
            },
        );

        assert_eq!(proof.status(), &Status::Nonterminating);
        assert!(matches!(
            proof.steps(),
            [ProofStep::Nontermination {
                proof: crate::proving::NonterminationProof::Loop(_),
            }]
        ));
    }

    #[test]
    fn csr_polynomial_residual_returns_to_the_common_worklist() {
        let trs = Trs::new(
            None,
            BTreeSet::new(),
            vec![
                RewriteRule::new(Term::app("f", vec![]), Term::app("g", vec![])),
                RewriteRule::new(Term::app("g", vec![]), Term::app("h", vec![])),
            ],
        );
        let csr = CsrTrs::new(
            trs,
            ReplacementMap::new(BTreeMap::from([
                (Symbol::new("f"), BTreeSet::new()),
                (Symbol::new("g"), BTreeSet::new()),
                (Symbol::new("h"), BTreeSet::new()),
            ])),
        )
        .unwrap();
        let proof = prove_context_sensitive(
            &csr,
            &ProveOptions {
                strategy: ProveStrategy::parse("(poly(1,1); poly(1,1))").unwrap(),
                llm_first: false,
                ..ProveOptions::default()
            },
        );
        assert_eq!(proof.status(), &Status::Terminating, "{proof:#?}");
        assert!(matches!(
            proof.steps(),
            [ProofStep::ContextSensitivePolynomialRuleRemoval { proof, .. }]
                if proof.status() == &Status::Terminating
        ));
    }

    #[test]
    fn csr_polynomial_atom_returns_each_residual_to_the_worklist() {
        let trs = Trs::new(
            None,
            BTreeSet::new(),
            vec![
                RewriteRule::new(Term::app("f", vec![]), Term::app("g", vec![])),
                RewriteRule::new(Term::app("g", vec![]), Term::app("h", vec![])),
            ],
        );
        let csr = CsrTrs::new(
            trs,
            ReplacementMap::new(BTreeMap::from([
                (Symbol::new("f"), BTreeSet::new()),
                (Symbol::new("g"), BTreeSet::new()),
                (Symbol::new("h"), BTreeSet::new()),
            ])),
        )
        .unwrap();
        let proof = prove_context_sensitive(
            &csr,
            &ProveOptions {
                strategy: ProveStrategy::parse("poly(1,1)").unwrap(),
                llm_first: false,
                ..ProveOptions::default()
            },
        );
        assert_eq!(proof.status(), &Status::Terminating, "{proof:#?}");
        assert!(matches!(
            proof.steps(),
            [ProofStep::ContextSensitivePolynomialRuleRemoval { proof, .. }]
                if proof.status() == &Status::Terminating
        ));
    }

    #[test]
    fn csr_guidance_chains_strong_transformations_without_fallback() {
        let rules = vec![
            RewriteRule::new(Term::app("f", vec![]), Term::app("g", vec![])),
            RewriteRule::new(Term::app("g", vec![]), Term::app("h", vec![])),
        ];
        let make_csr = |rules| {
            let trs = Trs::new(None, BTreeSet::new(), rules);
            let replacement_map = ReplacementMap::new(
                trs.arities()
                    .into_keys()
                    .map(|symbol| (symbol, BTreeSet::new()))
                    .collect(),
            );
            CsrTrs::new(trs, replacement_map).unwrap()
        };
        let csr = make_csr(rules.clone());
        let residuals = [
            make_csr(vec![rules[0].clone()]),
            make_csr(vec![rules[1].clone()]),
        ];
        let mut states = vec![write_csr_input_cpf4(&csr)];
        states.extend(residuals.iter().map(write_csr_input_cpf4));
        let manifest_path = std::env::temp_dir().join(format!(
            "ferrum-csr-guided-chain-{}.jsonl",
            std::process::id()
        ));
        let mut manifest = String::new();
        for (index, state) in states.iter().enumerate() {
            let key = format!("{:x}", Sha256::digest(state.trim().as_bytes()));
            let status = if index == 0 {
                "transformed_strong"
            } else {
                "solved"
            };
            manifest.push_str(&format!(
                "{{\"schema\":\"ferrum.utility-guidance.v2\",\"problem_key\":\"{key}\",\
                 \"prefer\":[{{\"candidate\":\"poly(max-constant=1,max-coefficient=1)\",\
                 \"status\":\"{status}\",\"utility_score\":100.0,\"best_elapsed_ms\":1,\
                 \"attempts\":1,\"solved_count\":1,\"transformed_count\":1,\
                 \"failed_count\":0,\"timeout_count\":0,\"certified_count\":1}}]}}\n"
            ));
        }
        fs::write(&manifest_path, manifest).unwrap();
        let lookup = UtilityGuidanceLookup::from_path(&manifest_path).unwrap();
        let proof = prove_context_sensitive(
            &csr,
            &ProveOptions {
                strategy: ProveStrategy::Processor(ProveStrategyProcessor::SwitchContextSensitive),
                // Local oracle lookup remains enabled when model calls are
                // explicitly disabled (`--no-top-level-llm`).
                llm_first: false,
                utility_guidance: Some(lookup),
                ..ProveOptions::default()
            },
        );
        let _ = fs::remove_file(manifest_path);
        assert_eq!(proof.status(), &Status::Terminating, "{proof:#?}");
        let cpf = write_cpf_csr(&csr, &proof, CpfMode::Cpf40).unwrap();
        assert_eq!(cpf.matches("<csrRuleRemoval>").count(), 2);
    }

    #[test]
    fn nested_csr_retains_raw_weak_guidance_on_canonical_miss() {
        let trs = Trs::new(None, BTreeSet::new(), vec![RewriteRule::new(
            Term::app("f", vec![]), Term::app("g", vec![]))]);
        let csr = CsrTrs::new(trs, ReplacementMap::new(BTreeMap::from([
            (Symbol::new("f"), BTreeSet::new()), (Symbol::new("g"), BTreeSet::new())
        ]))).unwrap();
        let state = CsrProblemState::nested(csr);
        let raw = crate::cert::write_csr_state_input_cpf4(&state.csr, state.boundary);
        let key = format!("{:x}", Sha256::digest(raw.trim().as_bytes()));
        let path = std::env::temp_dir().join(format!("ferrum-csr-weak-{}.jsonl", std::process::id()));
        fs::write(&path, format!(r#"{{"schema":"ferrum.utility-guidance.v2","problem_key":"{key}","possible":[{{"candidate":"poly(1,1)","status":"transformed_weak","utility_score":1,"best_elapsed_ms":0,"attempts":1,"solved_count":0,"transformed_count":1,"failed_count":0,"timeout_count":0,"certified_count":0}}]}}"#)).unwrap();
        // A canonical row with no positive evidence must not mask this
        // exact nested state's weak, independently applicable advice.
        let (canonical, error) = standardized_csr_input_cpf4(&state.csr);
        assert!(error.is_none());
        let canonical_key = format!("{:x}", Sha256::digest(canonical.trim().as_bytes()));
        let manifest = fs::read_to_string(&path).unwrap();
        fs::write(&path, format!("{manifest}\n{{\"schema\":\"ferrum.utility-guidance.v2\",\"problem_key\":\"{canonical_key}\",\"prefer\":[]}}\n")).unwrap();
        let options = ProveOptions { utility_guidance: Some(UtilityGuidanceLookup::from_path(&path).unwrap()), ..ProveOptions::default() };
        let guided = worklist_guidance_strategy_for_csr(&state, &options);
        fs::remove_file(path).unwrap();
        assert!(guided.is_some());
    }

    #[test]
    fn exact_raw_trs_guidance_precedes_canonical_fallback() {
        let x = Term::var("x");
        let trs = Trs::new(
            None,
            BTreeSet::from([Variable::new("x")]),
            vec![RewriteRule::new(
                Term::app("user_z", vec![x.clone()]),
                Term::app("user_a", vec![x]),
            )],
        );
        let raw = write_trs_input_cpf3(&trs);
        let (canonical, error) = standardized_trs_input_cpf3(&trs);
        assert!(error.is_none());
        let raw_key = format!("{:x}", Sha256::digest(raw.trim().as_bytes()));
        let canonical_key = format!("{:x}", Sha256::digest(canonical.trim().as_bytes()));
        assert_ne!(raw_key, canonical_key);
        let manifest_path = std::env::temp_dir().join(format!(
            "ferrum-raw-guidance-first-{}.jsonl",
            std::process::id()
        ));
        let row = |key: &str, candidate: &str| {
            format!(
                "{{\"schema\":\"ferrum.utility-guidance.v2\",\"problem_key\":\"{key}\",\
                 \"prefer\":[{{\"candidate\":\"{candidate}\",\"status\":\"transformed_strong\",\
                 \"utility_score\":100.0,\"best_elapsed_ms\":1,\"attempts\":1,\
                 \"solved_count\":0,\"transformed_count\":1,\"failed_count\":0,\
                 \"timeout_count\":0,\"certified_count\":1}}]}}\n"
            )
        };
        fs::write(
            &manifest_path,
            row(&raw_key, "dp") + &row(&canonical_key, "uncurry"),
        )
        .unwrap();
        let lookup = UtilityGuidanceLookup::from_path(&manifest_path).unwrap();
        let options = ProveOptions {
            utility_guidance: Some(lookup),
            ..ProveOptions::default()
        };

        let strategy = worklist_guidance_strategy_for_trs(&trs, &options).unwrap();

        let _ = fs::remove_file(manifest_path);
        let ProveStrategy::Choice(choices) = strategy else {
            panic!("expected raw-guided choice");
        };
        let [ProveStrategy::Timeout { strategy, .. }] = choices.as_slice() else {
            panic!("expected one bounded raw-guided processor");
        };
        let ProveStrategy::Processor(processor) = strategy.as_ref() else {
            panic!("expected atomic raw-guided processor");
        };
        assert_eq!(processor.to_strategy_atom(), "dp");
    }

    #[test]
    fn top_level_oracle_honors_observed_native_search_time() {
        let prediction = crate::llm::StatusMapPrediction {
            ordered_positive: vec!["poly(1,1)".into()],
            measured_elapsed_ms: std::collections::BTreeMap::from([("poly(1,1)".into(), 20_000)]),
            ..Default::default()
        };
        let Some(ProveStrategy::Choice(choices)) = top_level_strategy_from_status_prediction(&prediction)
            else { panic!("expected guidance"); };
        let ProveStrategy::Timeout { duration, .. } = &choices[0] else { panic!("expected timeout"); };
        assert_eq!(*duration, Duration::from_secs(24));
    }

    #[test]
    fn oracle_rejects_dp_processors_with_embedded_continuations() {
        let prediction = crate::llm::StatusMapPrediction {
            solved: vec!["dp(graph;size-change)".to_string()],
            transformed_strong: vec!["dp".to_string()],
            ordered_positive: vec!["dp(graph;size-change)".to_string(), "dp".to_string()],
            ..crate::llm::StatusMapPrediction::default()
        };

        let strategy = top_level_strategy_from_status_prediction(&prediction)
            .expect("the independently guided DP transformation remains");
        let ProveStrategy::Choice(choices) = strategy else {
            panic!("expected a state-local oracle choice");
        };
        let [ProveStrategy::Timeout { strategy, .. }] = choices.as_slice() else {
            panic!("the composed DP continuation must be filtered");
        };
        assert_eq!(
            strategy.as_ref(),
            &ProveStrategy::Processor(ProveStrategyProcessor::DependencyPairs)
        );
    }

    #[test]
    fn csr_inapplicable_fallback_strategy_is_not_an_unsupported_processor_error() {
        let trs = Trs::new(
            None,
            BTreeSet::new(),
            vec![RewriteRule::new(
                Term::app("f", vec![]),
                Term::app("g", vec![]),
            )],
        );
        let csr = CsrTrs::new(
            trs,
            ReplacementMap::new(BTreeMap::from([
                (Symbol::new("f"), BTreeSet::new()),
                (Symbol::new("g"), BTreeSet::new()),
            ])),
        )
        .unwrap();
        let proof = prove_context_sensitive(
            &csr,
            &ProveOptions {
                strategy: ProveStrategy::parse("fail").unwrap(),
                llm_first: false,
                ..ProveOptions::default()
            },
        );

        assert_eq!(proof.status(), &Status::Unknown, "{proof:#?}");
        let reason = match proof.steps().last() {
            Some(ProofStep::Unsupported { reason }) => reason.as_str(),
            _ => panic!("expected unsupported reason in fallback inapplicable proof: {proof:#?}"),
        };
        assert!(reason.contains("Inapplicable"), "{reason}");
        assert!(!reason.contains("unsupported processor"), "{reason}");
    }

    #[test]
    fn csr_parallel_cancels_a_running_sibling_after_a_closed_proof() {
        let trs = Trs::new(
            None,
            BTreeSet::new(),
            vec![RewriteRule::new(
                Term::app("f", vec![]),
                Term::app("g", vec![]),
            )],
        );
        let csr = CsrTrs::new(
            trs,
            ReplacementMap::new(BTreeMap::from([
                (Symbol::new("f"), BTreeSet::new()),
                (Symbol::new("g"), BTreeSet::new()),
            ])),
        )
        .unwrap();
        let polynomial = ProveStrategy::parse("poly(1,1)").unwrap();
        let strategy = ProveStrategy::Parallel(vec![
            ProveStrategy::Delay {
                duration: Duration::from_secs(30),
                strategy: Box::new(polynomial.clone()),
            },
            polynomial,
        ]);
        let started = Instant::now();
        let proof = prove_context_sensitive(
            &csr,
            &ProveOptions {
                strategy,
                llm_first: false,
                ..ProveOptions::default()
            },
        );
        assert_eq!(proof.status(), &Status::Terminating, "{proof:#?}");
        let elapsed = started.elapsed();
        assert!(
            elapsed < Duration::from_secs(20),
            "the closed sibling did not cancel the 30-second delay promptly: {elapsed:?}"
        );
    }

    #[test]
    fn csr_innermost_equivalence_materializes_a_solved_orthogonal_child() {
        let trs = Trs::new(
            None,
            BTreeSet::from([Variable::new("X")]),
            vec![RewriteRule::new(
                Term::app("f", vec![Term::app("s", vec![Term::var("X")])]),
                Term::app("f", vec![Term::var("X")]),
            )],
        );
        let csr = CsrTrs::new(
            trs,
            ReplacementMap::new(BTreeMap::from([
                (crate::core::Symbol::new("f"), BTreeSet::from([0])),
                (crate::core::Symbol::new("s"), BTreeSet::from([0])),
            ])),
        )
        .unwrap();
        let proof = prove_context_sensitive(
            &csr,
            &ProveOptions {
                strategy: ProveStrategy::parse("csr-innermost").unwrap(),
                llm_first: false,
                ..ProveOptions::default()
            },
        );
        assert_eq!(proof.status(), &Status::Terminating, "{proof:#?}");
        assert!(matches!(
            proof.steps(),
            [ProofStep::ContextSensitiveInnermostEquivalence { proof }]
                if proof.status() == &Status::Terminating
        ));
    }

    #[test]
    fn csr_polynomial_monotonicity_requires_positive_coefficients_only_for_mu_positions() {
        let variables = BTreeSet::from([Variable::new("x"), Variable::new("y")]);
        let trs = Trs::new(
            None,
            variables,
            vec![RewriteRule::new(
                Term::app("f", vec![Term::var("x"), Term::var("y")]),
                Term::var("x"),
            )],
        );
        let csr = CsrTrs::new(
            trs,
            ReplacementMap::new(BTreeMap::from([(
                crate::core::Symbol::new("f"),
                BTreeSet::from([0]),
            )])),
        )
        .unwrap();
        let interpretations = BTreeMap::from([(
            "f".to_string(),
            LinearPolynomial {
                constant: 0,
                coefficients: vec![1, 0],
            },
        )]);
        assert!(csr_linear_polynomial_is_mu_monotone(&csr, &interpretations));

        let bad = BTreeMap::from([(
            "f".to_string(),
            LinearPolynomial {
                constant: 0,
                coefficients: vec![0, 1],
            },
        )]);
        assert!(!csr_linear_polynomial_is_mu_monotone(&csr, &bad));
    }

    #[test]
    fn csr_polynomial_rule_removal_is_invariant_under_renaming_and_rule_order() {
        let original = CsrTrs::new(
            Trs::new(
                None,
                BTreeSet::from([Variable::new("x"), Variable::new("y")]),
                vec![
                    RewriteRule::new(
                        Term::app("f", vec![Term::var("x"), Term::var("y")]),
                        Term::var("x"),
                    ),
                    RewriteRule::new(
                        Term::app("g", vec![Term::var("x")]),
                        Term::app("g", vec![Term::var("x")]),
                    ),
                ],
            ),
            ReplacementMap::new(BTreeMap::from([
                (Symbol::new("f"), BTreeSet::from([0])),
                (Symbol::new("g"), BTreeSet::from([0])),
            ])),
        )
        .unwrap();
        let bijection = original
            .trs()
            .arities()
            .keys()
            .enumerate()
            .map(|(index, symbol)| {
                (
                    symbol.clone(),
                    Symbol::new(format!("renamed_symbol_{index}")),
                )
            })
            .collect::<BTreeMap<_, _>>();
        let mut renamed_rules = original
            .rules()
            .iter()
            .map(|rule| crate::standardize::translate_rule_symbols(rule, &bijection))
            .collect::<Vec<_>>();
        renamed_rules.reverse();
        let renamed_trs = Trs::new_with_strategy(
            None,
            original.trs().variables().clone(),
            renamed_rules,
            original.trs().strategy(),
        );
        let renamed_map = ReplacementMap::new(
            original
                .replacement_map()
                .entries()
                .iter()
                .map(|(symbol, positions)| {
                    (bijection.get(symbol).unwrap().clone(), positions.clone())
                })
                .collect(),
        );
        let renamed = CsrTrs::new(renamed_trs, renamed_map).unwrap();
        let cancellation = CancellationScope::current(None);

        let original_removal = synthesize_csr_linear_polynomial_removal(
            &original,
            1,
            1,
            usize::MAX,
            usize::MAX,
            0,
            None,
            &cancellation,
        )
        .unwrap();
        let renamed_removal = synthesize_csr_linear_polynomial_removal(
            &renamed,
            1,
            1,
            usize::MAX,
            usize::MAX,
            0,
            None,
            &cancellation,
        )
        .unwrap();
        let (original_remaining, original_error) =
            standardized_csr_input_cpf4(&original_removal.remaining);
        let (renamed_remaining, renamed_error) =
            standardized_csr_input_cpf4(&renamed_removal.remaining);

        assert!(original_error.is_none(), "{original_error:?}");
        assert!(renamed_error.is_none(), "{renamed_error:?}");
        assert_eq!(
            original_removal.removed.len(),
            renamed_removal.removed.len()
        );
        assert_eq!(original_remaining, renamed_remaining);
    }

    #[test]
    fn top_level_strategy_polynomial_atom_uses_parameter_bounds() {
        let trs = Trs::new(
            None,
            BTreeSet::new(),
            vec![RewriteRule::new(
                Term::app("a", vec![]),
                Term::app("b", vec![]),
            )],
        );
        let too_small = prove(
            &trs,
            &ProveOptions {
                strategy: ProveStrategy::parse("poly(0,1)").unwrap(),
                llm_first: false,
                ..ProveOptions::default()
            },
        );
        assert_eq!(too_small.status(), &Status::Unknown);
        let proof = prove(
            &trs,
            &ProveOptions {
                strategy: ProveStrategy::parse("poly(1,1)").unwrap(),
                llm_first: false,
                ..ProveOptions::default()
            },
        );
        assert_eq!(proof.status(), &Status::Terminating);
        assert!(matches!(
            proof.steps()[0],
            ProofStep::PolynomialRuleRemoval { .. }
        ));
    }

    #[test]
    fn top_level_strategy_smt_polynomial_atom_uses_parameter_bounds() {
        let trs = Trs::new(
            None,
            BTreeSet::new(),
            vec![RewriteRule::new(
                Term::app("a", vec![]),
                Term::app("b", vec![]),
            )],
        );
        let proof = prove(
            &trs,
            &ProveOptions {
                strategy: ProveStrategy::parse("smt-poly(1,1,2,0)").unwrap(),
                llm_first: false,
                ..ProveOptions::default()
            },
        );
        assert_eq!(proof.status(), &Status::Terminating);
        assert!(matches!(
            proof.steps()[0],
            ProofStep::PolynomialRuleRemoval { .. }
        ));
    }

    #[test]
    fn proves_simple_subterm_system() {
        let variables = BTreeSet::from([Variable::new("x")]);
        let trs = Trs::new(
            None,
            variables,
            vec![RewriteRule::new(
                Term::app("f", vec![Term::var("x")]),
                Term::var("x"),
            )],
        );
        let proof = prove(&trs, &ProveOptions::default());
        assert_eq!(proof.status(), &Status::Terminating);
    }

    #[test]
    fn accepts_llm_linear_polynomial_proposals() {
        let variables = BTreeSet::from([Variable::new("x"), Variable::new("y")]);
        let trs = Trs::new(
            None,
            variables,
            vec![RewriteRule::new(
                Term::app("f", vec![Term::var("x"), Term::var("y")]),
                Term::app("g", vec![Term::var("x"), Term::var("y")]),
            )],
        );
        let proof = prove(
            &trs,
            &ProveOptions {
                strategy: ProveStrategy::Processor(ProveStrategyProcessor::Fail),
                llm_first: true,
                llm_proposals: vec![crate::llm::LlmProposal::LinearPolynomial {
                    interpretations: std::collections::BTreeMap::from([
                        (
                            "f".to_string(),
                            crate::llm::LinearPolynomial {
                                constant: 1,
                                coefficients: vec![1, 1],
                            },
                        ),
                        (
                            "g".to_string(),
                            crate::llm::LinearPolynomial {
                                constant: 0,
                                coefficients: vec![1, 1],
                            },
                        ),
                    ]),
                }],
                ..ProveOptions::default()
            },
        );
        assert!(matches!(
            proof.steps()[0],
            ProofStep::PolynomialRuleRemoval { .. }
        ));
    }

    #[test]
    fn accepts_llm_linear_polynomial_rule_removal_proposals() {
        let variables = BTreeSet::from([Variable::new("x"), Variable::new("y")]);
        let trs = Trs::new(
            None,
            variables,
            vec![
                RewriteRule::new(Term::app("a", vec![]), Term::app("b", vec![])),
                RewriteRule::new(
                    Term::app(
                        "f",
                        vec![Term::app("s", vec![Term::var("x")]), Term::var("y")],
                    ),
                    Term::app(
                        "f",
                        vec![Term::var("x"), Term::app("s", vec![Term::var("y")])],
                    ),
                ),
            ],
        );
        let proof = prove(
            &trs,
            &ProveOptions {
                strategy: ProveStrategy::Processor(ProveStrategyProcessor::Fail),
                llm_first: true,
                llm_proposals: vec![crate::llm::LlmProposal::LinearPolynomial {
                    interpretations: std::collections::BTreeMap::from([
                        (
                            "a".to_string(),
                            crate::llm::LinearPolynomial {
                                constant: 1,
                                coefficients: vec![],
                            },
                        ),
                        (
                            "b".to_string(),
                            crate::llm::LinearPolynomial {
                                constant: 0,
                                coefficients: vec![],
                            },
                        ),
                        (
                            "f".to_string(),
                            crate::llm::LinearPolynomial {
                                constant: 0,
                                coefficients: vec![1, 1],
                            },
                        ),
                        (
                            "s".to_string(),
                            crate::llm::LinearPolynomial {
                                constant: 0,
                                coefficients: vec![1],
                            },
                        ),
                    ]),
                }],
                ..ProveOptions::default()
            },
        );
        assert_eq!(proof.status(), &Status::Terminating);
        assert!(matches!(
            proof.steps()[0],
            ProofStep::PolynomialRuleRemoval { .. }
        ));
    }

    #[test]
    fn ignores_top_level_path_order_proposals() {
        let variables = BTreeSet::from([Variable::new("x")]);
        let trs = Trs::new(
            None,
            variables,
            vec![RewriteRule::new(
                Term::app(
                    "f",
                    vec![Term::app("g", vec![Term::var("x")]), Term::var("x")],
                ),
                Term::app("f", vec![Term::var("x"), Term::var("x")]),
            )],
        );
        let proof = prove(
            &trs,
            &ProveOptions {
                llm_first: true,
                llm_proposals: vec![crate::llm::LlmProposal::PathOrder {
                    order: crate::llm::PathOrderKind::Rpo,
                    precedence: vec!["f".to_string(), "g".to_string()],
                    argument_filter: std::collections::BTreeMap::from([("f".to_string(), vec![0])]),
                }],
                synthesize_kbo: false,
                synthesize_smt_polynomial: false,
                synthesize_path_order: false,
                dependency_pairs: false,
                strategy: ProveStrategy::Processor(ProveStrategyProcessor::Fail),
                ..ProveOptions::default()
            },
        );
        assert_eq!(proof.status(), &Status::Unknown);
    }

    #[test]
    fn explicit_polynomial_atom_removes_rules() {
        let variables = BTreeSet::from([Variable::new("x"), Variable::new("y")]);
        let trs = Trs::new(
            None,
            variables,
            vec![RewriteRule::new(
                Term::app("f", vec![Term::var("x"), Term::var("y")]),
                Term::app("g", vec![Term::var("x"), Term::var("y")]),
            )],
        );
        let proof = prove(
            &trs,
            &ProveOptions {
                strategy: ProveStrategy::Processor(ProveStrategyProcessor::LinearPolynomial {
                    max_constant: 2,
                    max_coefficient: 1,
                    max_symbols: None,
                    max_arity: None,
                }),
                llm_first: false,
                synthesize_kbo: false,
                dependency_pairs: false,
                ..ProveOptions::default()
            },
        );
        assert_eq!(proof.status(), &Status::Terminating);
        assert!(matches!(
            proof.steps()[0],
            ProofStep::PolynomialRuleRemoval { .. }
        ));
    }

    #[test]
    fn synthesizes_top_level_kbo_for_precedence_system() {
        let variables = BTreeSet::from([Variable::new("x")]);
        let trs = Trs::new(
            None,
            variables,
            vec![RewriteRule::new(
                Term::app("f", vec![Term::var("x")]),
                Term::app("g", vec![Term::var("x")]),
            )],
        );
        let (_precedence, precedence_ranks, weights) =
            synthesize_top_level_kbo(&trs, 1, 8, None).unwrap();
        let ranks = top_precedence_rank_refs(&precedence_ranks);
        assert!(top_level_kbo_gt(
            trs.rules()[0].lhs(),
            trs.rules()[0].rhs(),
            &weights,
            &ranks
        ));
    }

    #[test]
    fn atomic_top_level_kbo_returns_a_certified_residual() {
        let variables = BTreeSet::from([Variable::new("x"), Variable::new("y")]);
        let trs = Trs::new(
            None,
            variables,
            vec![RewriteRule::new(
                Term::app(
                    "f",
                    vec![Term::app("s", vec![Term::var("x")]), Term::var("y")],
                ),
                Term::app(
                    "f",
                    vec![Term::var("x"), Term::app("s", vec![Term::var("y")])],
                ),
            )],
        );
        let proof = prove(
            &trs,
            &ProveOptions {
                strategy: ProveStrategy::Processor(ProveStrategyProcessor::Kbo {
                    max_weight: 2,
                    max_symbols: 8,
                }),
                dependency_pairs: false,
                ..ProveOptions::default()
            },
        );
        assert_eq!(proof.status(), &Status::Terminating);
        assert!(matches!(proof.steps()[0], ProofStep::KboRuleRemoval { .. }));
    }

    #[test]
    fn top_level_kbo_allows_zero_weight_for_maximal_unary_symbol() {
        let variables = BTreeSet::from([Variable::new("x")]);
        let trs = Trs::new(
            None,
            variables,
            vec![RewriteRule::new(
                Term::app("mark", vec![Term::var("x")]),
                Term::var("x"),
            )],
        );
        let (_precedence, _precedence_ranks, weights) =
            synthesize_top_level_kbo(&trs, 1, 8, None).unwrap();
        assert_eq!(weights.get("mark").copied(), Some(0));
    }

    #[test]
    fn top_level_kbo_allows_nonnegative_weight_for_binary_symbols() {
        let variables = BTreeSet::from([Variable::new("x"), Variable::new("y")]);
        let trs = Trs::new(
            None,
            variables,
            vec![RewriteRule::new(
                Term::app("f", vec![Term::var("x"), Term::var("y")]),
                Term::app("g", vec![Term::var("x"), Term::var("y")]),
            )],
        );
        let (_precedence, _precedence_ranks, weights) =
            synthesize_top_level_kbo(&trs, 1, 8, None).unwrap();
        assert!(weights.get("f").copied().is_some_and(|weight| weight >= 0));
        assert!(weights.get("g").copied().is_some_and(|weight| weight >= 0));
    }

    #[test]
    fn synthesizes_partial_top_level_polynomial_rule_removal() {
        let variables = BTreeSet::from([Variable::new("x")]);
        let removed = RewriteRule::new(
            Term::app("f", vec![Term::var("x")]),
            Term::app("g", vec![Term::var("x")]),
        );
        let weak = RewriteRule::new(
            Term::app("h", vec![Term::var("x")]),
            Term::app("h", vec![Term::var("x")]),
        );
        let trs = Trs::new(None, variables, vec![removed.clone(), weak.clone()]);
        let removal = synthesize_top_level_polynomial_removal_with_smt(
            &trs,
            &ProveOptions {
                max_polynomial_constant: 1,
                max_polynomial_coefficient: 1,
                max_polynomial_symbols: 8,
                max_polynomial_arity: 2,
                ..ProveOptions::default()
            },
            None,
        )
        .unwrap();
        assert_eq!(removal.removed, vec![removed]);
        assert_eq!(removal.remaining.rules(), &[weak]);
    }

    #[test]
    fn transformed_csr_mark_example_does_not_use_uncertified_csr_switch() {
        let variables =
            BTreeSet::from([Variable::new("X"), Variable::new("X1"), Variable::new("X2")]);
        let trs = Trs::new_with_strategy(
            None,
            variables,
            vec![
                RewriteRule::new(
                    Term::app("a__f", vec![Term::app("|0|", Vec::new())]),
                    Term::app(
                        "cons",
                        vec![
                            Term::app("|0|", Vec::new()),
                            Term::app(
                                "f",
                                vec![Term::app("s", vec![Term::app("|0|", Vec::new())])],
                            ),
                        ],
                    ),
                ),
                RewriteRule::new(
                    Term::app(
                        "a__f",
                        vec![Term::app("s", vec![Term::app("|0|", Vec::new())])],
                    ),
                    Term::app(
                        "a__f",
                        vec![Term::app(
                            "a__p",
                            vec![Term::app("s", vec![Term::app("|0|", Vec::new())])],
                        )],
                    ),
                ),
                RewriteRule::new(
                    Term::app(
                        "a__p",
                        vec![Term::app("s", vec![Term::app("|0|", Vec::new())])],
                    ),
                    Term::app("|0|", Vec::new()),
                ),
                RewriteRule::new(
                    Term::app("mark", vec![Term::app("f", vec![Term::var("X")])]),
                    Term::app("a__f", vec![Term::app("mark", vec![Term::var("X")])]),
                ),
                RewriteRule::new(
                    Term::app("mark", vec![Term::app("p", vec![Term::var("X")])]),
                    Term::app("a__p", vec![Term::app("mark", vec![Term::var("X")])]),
                ),
                RewriteRule::new(
                    Term::app("mark", vec![Term::app("|0|", Vec::new())]),
                    Term::app("|0|", Vec::new()),
                ),
                RewriteRule::new(
                    Term::app(
                        "mark",
                        vec![Term::app("cons", vec![Term::var("X1"), Term::var("X2")])],
                    ),
                    Term::app(
                        "cons",
                        vec![Term::app("mark", vec![Term::var("X1")]), Term::var("X2")],
                    ),
                ),
                RewriteRule::new(
                    Term::app("mark", vec![Term::app("s", vec![Term::var("X")])]),
                    Term::app("s", vec![Term::app("mark", vec![Term::var("X")])]),
                ),
                RewriteRule::new(
                    Term::app("a__f", vec![Term::var("X")]),
                    Term::app("f", vec![Term::var("X")]),
                ),
                RewriteRule::new(
                    Term::app("a__p", vec![Term::var("X")]),
                    Term::app("p", vec![Term::var("X")]),
                ),
            ],
            RewriteStrategy::Innermost,
        );

        let proof = prove(
            &trs,
            &ProveOptions {
                strategy: ProveStrategy::parse("switch-csr").unwrap(),
                ..ProveOptions::default()
            },
        );

        assert_eq!(proof.status(), &Status::Unknown);
    }

    #[test]
    fn removes_non_applicable_innermost_rules() {
        let variables = BTreeSet::from([Variable::new("x")]);
        let trs = Trs::new_with_strategy(
            None,
            variables,
            vec![
                RewriteRule::new(
                    Term::app("f", vec![Term::app("g", vec![Term::var("x")])]),
                    Term::app("f", vec![Term::var("x")]),
                ),
                RewriteRule::new(
                    Term::app("g", vec![Term::var("x")]),
                    Term::app("h", vec![Term::var("x")]),
                ),
            ],
            RewriteStrategy::Innermost,
        );
        let (removed, remaining) = remove_non_applicable_rules(&trs).unwrap();
        assert_eq!(removed, vec![trs.rules()[0].clone()]);
        assert_eq!(remaining.rules(), &trs.rules()[1..]);
    }

    #[test]
    fn removes_rules_with_nested_non_applicable_innermost_subterms() {
        let blocked = RewriteRule::new(
            Term::app(
                "f",
                vec![Term::app("h", vec![Term::app("g", vec![Term::var("x")])])],
            ),
            Term::var("x"),
        );
        let reducer =
            RewriteRule::new(Term::app("g", vec![Term::var("x")]), Term::app("a", vec![]));
        let trs = Trs::new_with_strategy(
            None,
            BTreeSet::from([Variable::new("x")]),
            vec![blocked.clone(), reducer],
            RewriteStrategy::Innermost,
        );
        let (removed, remaining) = remove_non_applicable_rules(&trs).unwrap();
        assert_eq!(removed, vec![blocked]);
        assert_eq!(remaining.rules(), &trs.rules()[1..]);
    }

    #[test]
    fn switch_innermost_accepts_overlay_system_without_critical_pairs() {
        let variables = BTreeSet::from([Variable::new("x")]);
        let trs = Trs::new(
            None,
            variables,
            vec![RewriteRule::new(
                Term::app("f", vec![Term::var("x")]),
                Term::var("x"),
            )],
        );
        assert_eq!(switch_innermost_wcr_depth(&trs), Some(1));
    }

    #[test]
    fn identity_switch_innermost_overlay_diagnostic() {
        let input = r#"
            (format TRS)
            (fun g 2) (fun |0| 0) (fun d 0) (fun s 1) (fun h 0)
            (fun double 1) (fun half 1) (fun f 2) (fun id 1)
            (rule (g x |0|) |0|)
            (rule (g d (s x)) (s (s (g d x))))
            (rule (g h (s |0|)) |0|)
            (rule (g h (s (s x))) (s (g h x)))
            (rule (double x) (g d x))
            (rule (half x) (g h x))
            (rule (f (s x) y) (f (half (s x)) (double y)))
            (rule (f (s |0|) y) y)
            (rule (id x) (f x (s |0|)))
        "#;
        let trs = parse_trs(Some("identity".to_string()), input).unwrap();
        assert!(is_overlay_trs(&trs));
        let pairs = critical_pairs(&trs);
        assert!(!weakly_confluent_by_join_bfs(
            &pairs,
            trs.rules(),
            10,
            Instant::now() + Duration::from_secs(10),
        ));

        let residual = Trs::new_with_strategy(
            Some("identity residual".to_string()),
            trs.variables().clone(),
            trs.rules()[..7].to_vec(),
            RewriteStrategy::Full,
        );
        let residual_pairs = critical_pairs(&residual);
        assert!(weakly_confluent_by_join_bfs(
            &residual_pairs,
            residual.rules(),
            10,
            Instant::now() + Duration::from_secs(10),
        ));
    }

    #[test]
    fn switch_innermost_allows_dp_instantiation_pipeline() {
        let trs = Trs::new(
            None,
            BTreeSet::from([Variable::new("x"), Variable::new("y"), Variable::new("z")]),
            vec![
                RewriteRule::new(
                    Term::app("f", vec![Term::var("x"), Term::var("y"), Term::var("z")]),
                    Term::app("g", vec![Term::var("x"), Term::var("y"), Term::var("z")]),
                ),
                RewriteRule::new(
                    Term::app(
                        "g",
                        vec![
                            Term::app("|0|", Vec::new()),
                            Term::app("|1|", Vec::new()),
                            Term::var("x"),
                        ],
                    ),
                    Term::app("f", vec![Term::var("x"), Term::var("x"), Term::var("x")]),
                ),
            ],
        );

        let proof = prove(&trs, &ProveOptions::default());

        assert_eq!(proof.status(), &Status::Terminating);
        assert!(proof.steps().iter().any(|step| matches!(
            step,
            ProofStep::SwitchInnermost { .. } | ProofStep::DependencyPairProof { .. }
        )));
    }

    #[test]
    fn relative_match_bounds_weak_height_matches_ceta_cases() {
        let decreasing = crate::core::SrsRule::new_for_test(vec!["a", "b"], vec!["a"]);
        let growing = crate::core::SrsRule::new_for_test(vec!["a"], vec!["a", "b"]);
        let uniform = SrsMatchPath {
            tail: "q0".to_string(),
            head: "q0".to_string(),
            heights: vec![2, 2],
        };
        let mixed = SrsMatchPath {
            tail: "q0".to_string(),
            head: "q0".to_string(),
            heights: vec![2, 3],
        };

        assert_eq!(
            match_bounds_weak_rhs_height(&decreasing, &uniform, 5, false),
            Some(2)
        );
        assert_eq!(
            match_bounds_weak_rhs_height(&decreasing, &mixed, 5, false),
            Some(3)
        );
        assert_eq!(
            match_bounds_weak_rhs_height(&growing, &uniform, 5, false),
            Some(3)
        );
        assert_eq!(
            match_bounds_weak_rhs_height(&growing, &uniform, 2, true),
            Some(2)
        );
    }
}
