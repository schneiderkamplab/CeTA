use std::collections::BTreeMap;

use crate::core::{Term, Trs, Variable};
use crate::llm::{LinearPolynomial, LinearPolynomialInterpretations};

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct LinearForm {
    constant: i64,
    coefficients: BTreeMap<Variable, i64>,
}

struct LinearPolynomialSynthesis<'a> {
    trs: &'a Trs,
    symbols: Vec<(String, usize)>,
    choices: Vec<Vec<LinearPolynomial>>,
    max_constant: i64,
    max_coefficient: i64,
    require_all_strict: bool,
}

impl LinearForm {
    fn variable(variable: Variable) -> Self {
        Self {
            constant: 0,
            coefficients: BTreeMap::from([(variable, 1)]),
        }
    }

    fn constant(value: i64) -> Self {
        Self {
            constant: value,
            coefficients: BTreeMap::new(),
        }
    }

    fn add(&mut self, other: LinearForm) {
        self.constant += other.constant;
        for (variable, coefficient) in other.coefficients {
            *self.coefficients.entry(variable).or_default() += coefficient;
        }
    }

    fn scale(&mut self, coefficient: i64) {
        self.constant *= coefficient;
        for value in self.coefficients.values_mut() {
            *value *= coefficient;
        }
    }

    fn weakly_ge(&self, other: &LinearForm) -> bool {
        self.constant >= other.constant
            && other
                .coefficients
                .iter()
                .all(|(variable, coefficient)| self.coefficient(variable) >= *coefficient)
    }

    fn strictly_gt_with_weak_coefficients(&self, other: &LinearForm) -> bool {
        self.constant > other.constant
            && other
                .coefficients
                .iter()
                .all(|(variable, coefficient)| self.coefficient(variable) >= *coefficient)
            && self
                .coefficients
                .iter()
                .all(|(variable, coefficient)| *coefficient >= other.coefficient(variable))
    }

    fn coefficient(&self, variable: &Variable) -> i64 {
        self.coefficients.get(variable).copied().unwrap_or(0)
    }
}

pub fn linear_polynomial_prove_termination(
    trs: &Trs,
    interpretations: &LinearPolynomialInterpretations,
) -> bool {
    linear_polynomial_is_monotone_for_trs(trs, interpretations)
        && !trs.rules().is_empty()
        && trs
            .rules()
            .iter()
            .all(|rule| linear_polynomial_strictly_orients_rule(rule, interpretations))
}

pub fn linear_polynomial_is_monotone_for_trs(
    trs: &Trs,
    interpretations: &LinearPolynomialInterpretations,
) -> bool {
    interpretations.values().all(|interpretation| {
        interpretation.constant >= 0 && interpretation.coefficients.iter().all(|value| *value >= 0)
    }) && coefficients_are_strictly_monotone(trs, interpretations)
}

pub fn linear_polynomial_weakly_orients_rule(
    rule: &crate::core::RewriteRule,
    interpretations: &LinearPolynomialInterpretations,
) -> bool {
    let lhs = interpret_polynomial(rule.lhs(), interpretations);
    let rhs = interpret_polynomial(rule.rhs(), interpretations);
    lhs.weakly_ge(&rhs)
}

pub fn linear_polynomial_strictly_orients_rule(
    rule: &crate::core::RewriteRule,
    interpretations: &LinearPolynomialInterpretations,
) -> bool {
    let lhs = interpret_polynomial(rule.lhs(), interpretations);
    let rhs = interpret_polynomial(rule.rhs(), interpretations);
    lhs.weakly_ge(&rhs) && lhs.strictly_gt_with_weak_coefficients(&rhs)
}

fn coefficients_are_strictly_monotone(
    trs: &Trs,
    interpretations: &LinearPolynomialInterpretations,
) -> bool {
    trs.arities().into_iter().all(|(symbol, arity)| {
        let Some(interpretation) = interpretations.get(symbol.as_str()) else {
            return true;
        };
        (0..arity).all(|index| interpretation.coefficients.get(index).copied().unwrap_or(1) >= 1)
    })
}

pub fn synthesize_linear_polynomial(
    trs: &Trs,
    max_constant: i64,
    max_coefficient: i64,
    max_symbols: usize,
    max_arity: usize,
) -> Option<LinearPolynomialInterpretations> {
    synthesize_linear_polynomial_reduction_pair(
        trs,
        max_constant,
        max_coefficient,
        max_symbols,
        max_arity,
        true,
    )
}

pub fn synthesize_linear_polynomial_reduction_pair(
    trs: &Trs,
    max_constant: i64,
    max_coefficient: i64,
    max_symbols: usize,
    max_arity: usize,
    require_all_strict: bool,
) -> Option<LinearPolynomialInterpretations> {
    if max_constant < 0 || max_coefficient < 0 {
        return None;
    }
    let symbols = trs
        .arities()
        .into_iter()
        .map(|(symbol, arity)| (symbol.as_str().to_string(), arity))
        .collect::<Vec<_>>();
    if symbols.is_empty()
        || symbols.len() > max_symbols
        || symbols.iter().any(|(_, arity)| *arity > max_arity)
    {
        return None;
    }
    let choices = symbols
        .iter()
        .map(|(_, arity)| polynomial_choices(*arity, max_constant, max_coefficient))
        .collect::<Vec<_>>();
    let mut interpretations = BTreeMap::new();
    let context = LinearPolynomialSynthesis {
        trs,
        symbols,
        choices,
        max_constant,
        max_coefficient,
        require_all_strict,
    };
    synthesize_linear_polynomial_from(&context, 0, &mut interpretations)
}

fn synthesize_linear_polynomial_from(
    context: &LinearPolynomialSynthesis<'_>,
    index: usize,
    interpretations: &mut LinearPolynomialInterpretations,
) -> Option<LinearPolynomialInterpretations> {
    if index == context.symbols.len() {
        if !linear_polynomial_is_monotone_for_trs(context.trs, interpretations) {
            return None;
        }
        let all_weak = context
            .trs
            .rules()
            .iter()
            .all(|rule| linear_polynomial_weakly_orients_rule(rule, interpretations));
        let all_strict = all_weak
            && context
                .trs
                .rules()
                .iter()
                .all(|rule| linear_polynomial_strictly_orients_rule(rule, interpretations));
        let has_strict = context
            .trs
            .rules()
            .iter()
            .any(|rule| linear_polynomial_strictly_orients_rule(rule, interpretations));
        return (all_weak && has_strict && (!context.require_all_strict || all_strict))
            .then(|| interpretations.clone());
    }
    let symbol = context.symbols[index].0.clone();
    for interpretation in &context.choices[index] {
        interpretations.insert(symbol.clone(), interpretation.clone());
        if partial_polynomial_constraints_possible(
            context.trs,
            interpretations,
            context.max_constant,
            context.max_coefficient,
            context.require_all_strict,
        ) && let Some(solution) =
            synthesize_linear_polynomial_from(context, index + 1, interpretations)
        {
            return Some(solution);
        }
    }
    interpretations.remove(&symbol);
    None
}

fn partial_polynomial_constraints_possible(
    trs: &Trs,
    interpretations: &LinearPolynomialInterpretations,
    max_constant: i64,
    max_coefficient: i64,
    require_all_strict: bool,
) -> bool {
    trs.rules().iter().all(|rule| {
        let lhs = interval_interpret_polynomial(
            rule.lhs(),
            interpretations,
            max_constant,
            max_coefficient,
        );
        let rhs = interval_interpret_polynomial(
            rule.rhs(),
            interpretations,
            max_constant,
            max_coefficient,
        );
        lhs.can_weakly_ge(&rhs)
            && (!require_all_strict || lhs.can_strictly_gt_with_weak_coefficients(&rhs))
    })
}

fn polynomial_choices(
    arity: usize,
    max_constant: i64,
    max_coefficient: i64,
) -> Vec<LinearPolynomial> {
    let mut choices = Vec::new();
    let mut coefficients = vec![0; arity];
    polynomial_coefficient_choices(
        arity,
        max_coefficient,
        0,
        &mut coefficients,
        &mut choices,
        max_constant,
    );
    choices
}

fn polynomial_coefficient_choices(
    arity: usize,
    max_coefficient: i64,
    index: usize,
    coefficients: &mut [i64],
    choices: &mut Vec<LinearPolynomial>,
    max_constant: i64,
) {
    if index == arity {
        for constant in 0..=max_constant {
            choices.push(LinearPolynomial {
                constant,
                coefficients: coefficients.to_vec(),
            });
        }
        return;
    }
    let first_coefficient = if max_coefficient == 0 { 0 } else { 1 };
    for coefficient in first_coefficient..=max_coefficient {
        coefficients[index] = coefficient;
        polynomial_coefficient_choices(
            arity,
            max_coefficient,
            index + 1,
            coefficients,
            choices,
            max_constant,
        );
    }
}

fn interpret_polynomial(
    term: &Term,
    interpretations: &LinearPolynomialInterpretations,
) -> LinearForm {
    match term {
        Term::Var(variable) => LinearForm::variable(variable.clone()),
        Term::App { symbol, args } => {
            let interpretation = interpretations
                .get(symbol.as_str())
                .cloned()
                .unwrap_or_else(|| default_interpretation(args.len()));
            let mut form = LinearForm::constant(interpretation.constant);
            for (index, arg) in args.iter().enumerate() {
                let coefficient = interpretation.coefficients.get(index).copied().unwrap_or(1);
                let mut arg_form = interpret_polynomial(arg, interpretations);
                arg_form.scale(coefficient);
                form.add(arg_form);
            }
            form
        }
    }
}

fn default_interpretation(arity: usize) -> LinearPolynomial {
    LinearPolynomial {
        constant: 0,
        coefficients: vec![1; arity],
    }
}

#[derive(Clone, Debug, Eq, PartialEq)]
struct Interval {
    min: i64,
    max: i64,
}

impl Interval {
    fn exact(value: i64) -> Self {
        Self {
            min: value,
            max: value,
        }
    }

    fn add(&self, other: &Self) -> Self {
        Self {
            min: self.min + other.min,
            max: self.max + other.max,
        }
    }

    fn scale(&self, coefficient: &Self) -> Self {
        Self {
            min: self.min * coefficient.min,
            max: self.max * coefficient.max,
        }
    }
}

#[derive(Clone, Debug, Eq, PartialEq)]
struct IntervalForm {
    constant: Interval,
    coefficients: BTreeMap<Variable, Interval>,
}

impl IntervalForm {
    fn variable(variable: Variable) -> Self {
        Self {
            constant: Interval::exact(0),
            coefficients: BTreeMap::from([(variable, Interval::exact(1))]),
        }
    }

    fn constant(value: Interval) -> Self {
        Self {
            constant: value,
            coefficients: BTreeMap::new(),
        }
    }

    fn add(&mut self, other: Self) {
        self.constant = self.constant.add(&other.constant);
        for (variable, coefficient) in other.coefficients {
            self.coefficients
                .entry(variable)
                .and_modify(|old| *old = old.add(&coefficient))
                .or_insert(coefficient);
        }
    }

    fn scale(&mut self, coefficient: &Interval) {
        self.constant = self.constant.scale(coefficient);
        for value in self.coefficients.values_mut() {
            *value = value.scale(coefficient);
        }
    }

    fn coefficient(&self, variable: &Variable) -> Interval {
        self.coefficients
            .get(variable)
            .cloned()
            .unwrap_or_else(|| Interval::exact(0))
    }

    fn can_weakly_ge(&self, other: &Self) -> bool {
        self.constant.max >= other.constant.min
            && self
                .coefficients
                .keys()
                .chain(other.coefficients.keys())
                .all(|variable| self.coefficient(variable).max >= other.coefficient(variable).min)
    }

    fn can_strictly_gt_with_weak_coefficients(&self, other: &Self) -> bool {
        self.constant.max > other.constant.min
            && self
                .coefficients
                .keys()
                .chain(other.coefficients.keys())
                .all(|variable| self.coefficient(variable).max >= other.coefficient(variable).min)
    }
}

fn interval_interpret_polynomial(
    term: &Term,
    interpretations: &LinearPolynomialInterpretations,
    max_constant: i64,
    max_coefficient: i64,
) -> IntervalForm {
    match term {
        Term::Var(variable) => IntervalForm::variable(variable.clone()),
        Term::App { symbol, args } => {
            let maybe_interpretation = interpretations.get(symbol.as_str());
            let constant = maybe_interpretation.map_or(
                Interval {
                    min: 0,
                    max: max_constant,
                },
                |interpretation| Interval::exact(interpretation.constant),
            );
            let mut form = IntervalForm::constant(constant);
            for (index, arg) in args.iter().enumerate() {
                let coefficient = maybe_interpretation.map_or(
                    Interval {
                        min: 1,
                        max: max_coefficient,
                    },
                    |interpretation| {
                        Interval::exact(
                            interpretation.coefficients.get(index).copied().unwrap_or(1),
                        )
                    },
                );
                let mut arg_form = interval_interpret_polynomial(
                    arg,
                    interpretations,
                    max_constant,
                    max_coefficient,
                );
                arg_form.scale(&coefficient);
                form.add(arg_form);
            }
            form
        }
    }
}

#[cfg(test)]
mod tests {
    use std::collections::{BTreeMap, BTreeSet};

    use crate::core::{RewriteRule, Term, Trs, Variable};

    use super::*;

    #[test]
    fn checks_linear_polynomial_interpretation() {
        let trs = Trs::new(
            None,
            BTreeSet::from([Variable::new("x")]),
            vec![RewriteRule::new(
                Term::app("f", vec![Term::var("x")]),
                Term::app("g", vec![Term::var("x")]),
            )],
        );
        assert!(linear_polynomial_prove_termination(
            &trs,
            &BTreeMap::from([
                (
                    "f".to_string(),
                    LinearPolynomial {
                        constant: 1,
                        coefficients: vec![1],
                    },
                ),
                (
                    "g".to_string(),
                    LinearPolynomial {
                        constant: 0,
                        coefficients: vec![1],
                    },
                ),
            ])
        ));
    }

    #[test]
    fn rejects_non_monotone_zero_coefficients() {
        let trs = Trs::new(
            None,
            BTreeSet::from([Variable::new("x")]),
            vec![RewriteRule::new(
                Term::app("f", vec![Term::var("x")]),
                Term::var("x"),
            )],
        );
        assert!(!linear_polynomial_prove_termination(
            &trs,
            &BTreeMap::from([(
                "f".to_string(),
                LinearPolynomial {
                    constant: 1,
                    coefficients: vec![0],
                },
            )])
        ));
    }

    #[test]
    fn synthesizes_small_linear_polynomial() {
        let trs = Trs::new(
            None,
            BTreeSet::from([Variable::new("x")]),
            vec![RewriteRule::new(
                Term::app("f", vec![Term::var("x")]),
                Term::app("g", vec![Term::app("h", vec![Term::var("x")])]),
            )],
        );
        let interpretations = synthesize_linear_polynomial(&trs, 1, 1, 4, 1).unwrap();
        assert!(linear_polynomial_prove_termination(&trs, &interpretations));
    }
}
