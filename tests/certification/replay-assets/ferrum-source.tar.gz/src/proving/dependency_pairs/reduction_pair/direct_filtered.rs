//! RPO comparisons over original subterms with symbolic root filters.
//!
//! This implements the root cases of RPO modulo filtering (Codish et al.,
//! JAR 2012, Definition 16). Filter selectors, precedence, usable-rule
//! conditions and exact model validation are unchanged. Only the comparison
//! encoding differs: never materialize the Cartesian product of filtered
//! descendants. Each original subterm pair has one shared Boolean node.

use super::*;

enum RootView {
    Variable,
    Collapse(Term),
    Keep(String, Vec<Term>),
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn direct_filtered_lpo_matches_concrete_filters_and_ranks() {
        if !command_exists("z3") {
            return;
        }
        let filters = BTreeMap::from([
            (
                "f".into(),
                vec![
                    DpArgumentFilterEntry::NonCollapsing(vec![0, 1]),
                    DpArgumentFilterEntry::NonCollapsing(vec![1, 0]),
                    DpArgumentFilterEntry::NonCollapsing(vec![]),
                    DpArgumentFilterEntry::Collapsing(0),
                    DpArgumentFilterEntry::Collapsing(1),
                ],
            ),
            (
                "g".into(),
                vec![
                    DpArgumentFilterEntry::NonCollapsing(vec![0]),
                    DpArgumentFilterEntry::NonCollapsing(vec![]),
                    DpArgumentFilterEntry::Collapsing(0),
                ],
            ),
        ]);
        let terms = vec![
            Term::var("x"),
            Term::var("y"),
            Term::app("f", vec![Term::var("x"), Term::var("y")]),
            Term::app("g", vec![Term::var("x")]),
            Term::app(
                "f",
                vec![Term::app("g", vec![Term::var("y")]), Term::var("x")],
            ),
            Term::app(
                "g",
                vec![Term::app("f", vec![Term::var("x"), Term::var("y")])],
            ),
        ];
        let mut encoder = DpPathOrderSmtEncoder::new(Some(DpPathOrderKind::Lpo), None);
        encoder.share_multiset_comparisons = true;
        encoder.direct_filters = Some(filters.clone());
        let mut comparisons = Vec::new();
        for a in &terms {
            for b in &terms {
                comparisons.push((
                    a,
                    b,
                    encoder.gt(a, b).unwrap(),
                    encoder.equivalent(a, b).unwrap(),
                ));
            }
        }
        let mut script = order_smt_prelude(&["f".into(), "g".into()], &filters, None).unwrap();
        script.push_str(&encoder.definitions);
        let mut checks = 0;
        for f in 0..filters["f"].len() {
            for g in 0..filters["g"].len() {
                let filter = BTreeMap::from([
                    ("f".into(), filters["f"][f].clone()),
                    ("g".into(), filters["g"][g].clone()),
                ]);
                for (fr, gr) in [(0, 1), (1, 0), (0, 0)] {
                    let ranks = BTreeMap::from([("f", fr), ("g", gr)]);
                    script.push_str(&format!("(push 1)\n(assert (= {} {f}))\n(assert (= {} {g}))\n(assert (= {} {fr}))\n(assert (= {} {gr}))\n",
                    filter_name("f"), filter_name("g"), order_rank_name("f"), order_rank_name("g")));
                    let mut differences = Vec::new();
                    for (a, b, gt, eq) in &comparisons {
                        let left = filter_term(a, &filter);
                        let right = filter_term(b, &filter);
                        // The exact native comparator is independent of SMT encoding.
                        let expected_gt = strictly_decreases_by_mixed_path_order(
                            a,
                            b,
                            DpPathOrderKind::Lpo,
                            &BTreeMap::new(),
                            &ranks,
                            &filter,
                        );
                        let expected_eq = mixed_path_order_equivalent(
                            &left,
                            &right,
                            DpPathOrderKind::Lpo,
                            &BTreeMap::new(),
                            &ranks,
                        );
                        differences.push(format!("(not (= {gt} {}))", smt_bool(expected_gt)));
                        differences.push(format!("(not (= {eq} {}))", smt_bool(expected_eq)));
                    }
                    script.push_str(&format!(
                        "(assert {})\n(check-sat)\n(pop 1)\n",
                        smt_or(differences)
                    ));
                    checks += 1;
                }
            }
        }
        let output = run_smt_script_with_solver(
            &script,
            "z3",
            Some(Instant::now() + Duration::from_secs(30)),
        )
        .expect("Z3 result");
        let results: Vec<_> = output.lines().filter(|s| !s.trim().is_empty()).collect();
        assert_eq!(results.len(), checks, "{output}");
        assert!(results.iter().all(|s| *s == "unsat"), "{output}");
    }

    #[test]
    fn direct_filtered_multiset_matches_exact_comparator() {
        if !command_exists("z3") {
            return;
        }
        let filters = BTreeMap::from([
            (
                "f".into(),
                vec![
                    DpArgumentFilterEntry::NonCollapsing(vec![0, 1]),
                    DpArgumentFilterEntry::NonCollapsing(vec![1, 0]),
                    DpArgumentFilterEntry::NonCollapsing(vec![]),
                    DpArgumentFilterEntry::Collapsing(1),
                ],
            ),
            (
                "g".into(),
                vec![
                    DpArgumentFilterEntry::NonCollapsing(vec![0]),
                    DpArgumentFilterEntry::NonCollapsing(vec![]),
                    DpArgumentFilterEntry::Collapsing(0),
                ],
            ),
        ]);
        let terms = vec![
            Term::var("x"),
            Term::var("y"),
            Term::app("f", vec![Term::var("x"), Term::var("y")]),
            Term::app("f", vec![Term::var("y"), Term::var("x")]),
            Term::app("g", vec![Term::var("x")]),
            Term::app(
                "f",
                vec![Term::app("g", vec![Term::var("x")]), Term::var("y")],
            ),
        ];
        let mut encoder = DpPathOrderSmtEncoder::new(Some(DpPathOrderKind::Rpo), None);
        encoder.share_multiset_comparisons = true;
        encoder.direct_filters = Some(filters.clone());
        let mut comparisons = Vec::new();
        for a in &terms {
            for b in &terms {
                comparisons.push((
                    a,
                    b,
                    encoder.gt(a, b).unwrap(),
                    encoder.equivalent(a, b).unwrap(),
                ));
            }
        }
        let mut script = order_smt_prelude(&["f".into(), "g".into()], &filters, None).unwrap();
        script.push_str(&encoder.definitions);
        let mut expected = Vec::new();
        for f in 0..filters["f"].len() {
            for g in 0..filters["g"].len() {
                let filter = BTreeMap::from([
                    ("f".into(), filters["f"][f].clone()),
                    ("g".into(), filters["g"][g].clone()),
                ]);
                for (fr, gr) in [(0, 1), (1, 0), (0, 0)] {
                    let ranks = BTreeMap::from([("f", fr), ("g", gr)]);
                    script.push_str(&format!("(push 1)\n(assert (= {} {f}))\n(assert (= {} {g}))\n(assert (= {} {fr}))\n(assert (= {} {gr}))\n",
                    filter_name("f"), filter_name("g"), order_rank_name("f"), order_rank_name("g")));
                    for (a, b, gt, eq) in &comparisons {
                        let exact_gt = strictly_decreases_by_mixed_path_order(
                            a,
                            b,
                            DpPathOrderKind::Rpo,
                            &BTreeMap::new(),
                            &ranks,
                            &filter,
                        );
                        let exact_eq = mixed_path_order_equivalent(
                            &filter_term(a, &filter),
                            &filter_term(b, &filter),
                            DpPathOrderKind::Rpo,
                            &BTreeMap::new(),
                            &ranks,
                        );
                        // Matching auxiliaries are existential witnesses. Test
                        // satisfiability of positive claims, not arbitrary false
                        // assignments to those auxiliaries.
                        for (formula, holds) in [(gt, exact_gt), (eq, exact_eq)] {
                            script.push_str(&format!(
                                "(push 1)\n(assert {formula})\n(check-sat)\n(pop 1)\n"
                            ));
                            expected.push(if holds { "sat" } else { "unsat" });
                        }
                    }
                    script.push_str("(pop 1)\n");
                }
            }
        }
        let output = run_smt_script_with_solver(
            &script,
            "z3",
            Some(Instant::now() + Duration::from_secs(30)),
        )
        .expect("Z3 result");
        assert_eq!(
            output
                .lines()
                .filter(|s| !s.trim().is_empty())
                .collect::<Vec<_>>(),
            expected
        );
    }

    #[test]
    fn direct_filtered_comparisons_are_shared_and_cancellable() {
        let mut encoder = DpPathOrderSmtEncoder::new(Some(DpPathOrderKind::Lpo), None);
        encoder.share_multiset_comparisons = true;
        encoder.direct_filters = Some(BTreeMap::new());
        let a = Term::app("f", vec![Term::var("x")]);
        let b = Term::var("x");
        let first = encoder.gt(&a, &b).unwrap();
        let bytes = encoder.definitions.len();
        assert_eq!(encoder.gt(&a, &b).unwrap(), first);
        assert_eq!(encoder.definitions.len(), bytes);
        let first_multiset = encoder.multiset_gt(&[a.clone()], &[b.clone()]).unwrap();
        let bytes = encoder.definitions.len();
        assert_eq!(encoder.multiset_gt(&[a.clone()], &[b.clone()]).unwrap(), first_multiset);
        assert_eq!(encoder.definitions.len(), bytes);
        encoder.deadline = Some(Instant::now() - Duration::from_secs(1));
        assert!(encoder.gt(&a, &b).is_none());
        assert!(encoder.equivalent(&a, &b).is_none());
    }
}

impl DpPathOrderSmtEncoder {
    fn root_views(&self, term: &Term) -> Option<Vec<(String, RootView)>> {
        match term {
            Term::Var(_) => Some(vec![("true".into(), RootView::Variable)]),
            Term::App { symbol, args } => {
                let entries = self.direct_filters.as_ref()?.get(symbol.as_str());
                let Some(entries) = entries else {
                    return Some(vec![(
                        "true".into(),
                        RootView::Keep(symbol.as_str().into(), args.clone()),
                    )]);
                };
                entries
                    .iter()
                    .enumerate()
                    .map(|(index, entry)| {
                        let view = match entry {
                            DpArgumentFilterEntry::Collapsing(position) => {
                                RootView::Collapse(args.get(*position)?.clone())
                            }
                            DpArgumentFilterEntry::NonCollapsing(positions) => RootView::Keep(
                                symbol.as_str().into(),
                                positions
                                    .iter()
                                    .map(|position| args.get(*position).cloned())
                                    .collect::<Option<Vec<_>>>()?,
                            ),
                        };
                        Some((
                            format!("(= {} {index})", filter_name(symbol.as_str())),
                            view,
                        ))
                    })
                    .collect()
            }
        }
    }

    fn filtered_compare(&mut self, lhs: &Term, rhs: &Term, strict: bool) -> Option<String> {
        if strict {
            self.gt(lhs, rhs)
        } else {
            self.equivalent(lhs, rhs)
        }
    }

    pub(super) fn direct_filtered_equivalent(&mut self, lhs: &Term, rhs: &Term) -> Option<String> {
        let key = path_order_equivalence_key(lhs, rhs);
        if let Some(variable) = self.equivalence_variables.get(&key) {
            return Some(variable.clone());
        }
        let variable = format!("dpeq_{}", self.next_equivalence_variable);
        self.next_equivalence_variable += 1;
        self.equivalence_variables.insert(key, variable.clone());
        self.definitions
            .push_str(&format!("(declare-const {variable} Bool)\n"));
        let formula = self.direct_filtered_relation(lhs, rhs, false)?;
        self.definitions
            .push_str(&format!("(assert (= {variable} {formula}))\n"));
        Some(variable)
    }

    fn filtered_argument_comparison(
        &mut self,
        symbol: &str,
        lhs: &[Term],
        rhs: &[Term],
        strict: bool,
    ) -> Option<String> {
        if !strict && lhs.len() != rhs.len() {
            return Some("false".into());
        }
        if !strict && self.positional_equivalence {
            return Some(smt_and(lhs.iter().zip(rhs)
                .map(|(a, b)| self.equivalent(a, b)).collect::<Option<Vec<_>>>()?));
        }
        let lex = if self.fixed_order != Some(DpPathOrderKind::Rpo) {
            Some(if strict {
                self.lex_gt(lhs, rhs)?
            } else {
                smt_and(
                    lhs.iter()
                        .zip(rhs)
                        .map(|(a, b)| self.equivalent(a, b))
                        .collect::<Option<Vec<_>>>()?,
                )
            })
        } else {
            None
        };
        let multiset = if self.fixed_order != Some(DpPathOrderKind::Lpo) {
            Some(if strict {
                self.multiset_gt(lhs, rhs)?
            } else {
                self.multiset_equivalent(lhs, rhs)?
            })
        } else {
            None
        };
        match self.fixed_order {
            Some(DpPathOrderKind::Lpo) => lex,
            Some(DpPathOrderKind::Rpo) => multiset,
            None => Some(smt_or(vec![
                smt_and(vec![
                    format!("(= {} 1)", path_order_status_name(symbol)),
                    lex?,
                ]),
                smt_and(vec![
                    format!("(= {} 0)", path_order_status_name(symbol)),
                    multiset?,
                ]),
            ])),
        }
    }

    pub(super) fn direct_filtered_relation(
        &mut self,
        lhs: &Term,
        rhs: &Term,
        strict: bool,
    ) -> Option<String> {
        if self.is_cancelled() {
            return None;
        }
        let left_views = self.root_views(lhs)?;
        let right_views = self.root_views(rhs)?;
        let mut alternatives = Vec::new();
        for (left_condition, left) in &left_views {
            if self.is_cancelled() {
                return None;
            }
            if let RootView::Collapse(child) = left {
                alternatives.push(smt_and(vec![
                    left_condition.clone(),
                    self.filtered_compare(child, rhs, strict)?,
                ]));
                continue;
            }
            for (right_condition, right) in &right_views {
                if self.is_cancelled() {
                    return None;
                }
                // One symbol has one global filter selector. Different root
                // choices for equal symbols cannot both hold; do not build
                // comparisons or matching auxiliaries for those branches.
                if self.share_multiset_comparisons && lhs.root_symbol().is_some()
                    && lhs.root_symbol() == rhs.root_symbol()
                    && left_condition != right_condition
                {
                    continue;
                }
                let relation = match (left, right) {
                    (_, RootView::Collapse(child)) => self.filtered_compare(lhs, child, strict)?,
                    (RootView::Variable, RootView::Variable) => smt_bool(!strict && lhs == rhs),
                    (RootView::Variable, RootView::Keep(..)) => "false".into(),
                    (RootView::Keep(_, args), RootView::Variable) => {
                        if strict {
                            smt_or(
                                args.iter()
                                    .map(|arg| {
                                        Some(smt_or(vec![
                                            self.equivalent(arg, rhs)?,
                                            self.gt(arg, rhs)?,
                                        ]))
                                    })
                                    .collect::<Option<Vec<_>>>()?,
                            )
                        } else {
                            "false".into()
                        }
                    }
                    (RootView::Keep(f, xs), RootView::Keep(g, ys)) => {
                        let rank_equal =
                            format!("(= {} {})", order_rank_name(f), order_rank_name(g));
                        let arguments = self.filtered_argument_comparison(f, xs, ys, strict)?;
                        if strict {
                            let subterm = smt_or(
                                xs.iter()
                                    .map(|x| {
                                        Some(smt_or(vec![
                                            self.equivalent(x, rhs)?,
                                            self.gt(x, rhs)?,
                                        ]))
                                    })
                                    .collect::<Option<Vec<_>>>()?,
                            );
                            let dominates = smt_and(
                                ys.iter()
                                    .map(|y| self.gt(lhs, y))
                                    .collect::<Option<Vec<_>>>()?,
                            );
                            smt_or(vec![
                                subterm,
                                smt_and(vec![
                                    dominates,
                                    smt_or(vec![
                                        format!(
                                            "(< {} {})",
                                            order_rank_name(f),
                                            order_rank_name(g)
                                        ),
                                        smt_and(vec![rank_equal, arguments]),
                                    ]),
                                ]),
                            ])
                        } else {
                            smt_and(vec![rank_equal, arguments])
                        }
                    }
                    (RootView::Collapse(_), _) => unreachable!("handled before right root cases"),
                };
                alternatives.push(smt_and(vec![
                    left_condition.clone(),
                    right_condition.clone(),
                    relation,
                ]));
            }
        }
        Some(smt_or(alternatives))
    }
}
