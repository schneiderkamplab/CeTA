//! Bounded native WPO(max) synthesis. No interpretation, filter or precedence
//! is supplied by the caller. The default search uses partial left-to-right
//! lexicographic statuses and identity/collapsing filters. Optional joint
//! position synthesis covers arbitrary partial lexicographic permutations;
//! multiset statuses remain outside this search class.
//!
//! Boolean comparison DAGs mirror `WpoMaxOrder`; the returned model is also
//! checked independently by that evaluator before constructing a proof.
use super::*;

fn af(s: &str) -> String {
    format!("waf_{}", sanitize_smt_name(s))
}
fn rank(s: &str) -> String {
    format!("wpr_{}", sanitize_smt_name(s))
}
fn selected(s: &str, i: usize) -> String {
    format!("wst_{}_{}", sanitize_smt_name(s), i)
}
fn position(s: &str, i: usize) -> String {
    format!("wpos_{}_{}", sanitize_smt_name(s), i)
}
fn keep(t: &Term) -> String {
    match t {
        Term::Var(_) => "true".into(),
        Term::App { symbol, .. } => format!("(= {} 0)", af(symbol.as_str())),
    }
}

struct Encoding {
    script: String,
    fresh: usize,
    alternatives: usize,
    binary: bool,
    permutations: bool,
    compact_ground: bool,
    deadline: Option<Instant>,
    forms: HashMap<Term, Vec<SmtForm>>,
    comparisons: HashMap<(Term, Term), (String, String)>,
}

impl Encoding {
    fn bind(&mut self, ty: &str, value: String) -> String {
        let name = format!("wdag_{}", self.fresh);
        self.fresh += 1;
        self.script.push_str(&format!(
            "(declare-const {name} {ty})\n(assert (= {name} {value}))\n"
        ));
        name
    }

    // A collapsing filter is exactly a projection algebra. Use conditional
    // coefficients rather than enumerating exponentially many filtered terms.
    fn interpret(&mut self, term: &Term) -> Option<Vec<SmtForm>> {
        if let Some(forms) = self.forms.get(term) {
            return Some(forms.clone());
        }
        check_smt_build(&self.script, self.deadline)?;
        let result = match term {
            Term::Var(v) => vec![SmtForm {
                constant: "0".into(),
                coefficients: BTreeMap::from([(v.as_str().to_owned(), "1".into())]),
            }],
            Term::App { symbol, args } => {
                let arg_forms = args
                    .iter()
                    .map(|arg| self.interpret(arg))
                    .collect::<Option<Vec<_>>>()?;
                let combinations = max_smt_arg_combinations_until(&arg_forms, self.deadline)?;
                if combinations.len().checked_mul(self.alternatives)? > MAX_MAX_POLYNOMIAL_FORMS {
                    return None;
                }
                let mut forms = Vec::new();
                let f = af(symbol.as_str());
                for alt in 0..self.alternatives {
                    for combination in &combinations {
                        check_smt_build(&self.script, self.deadline)?;
                        let mut form = SmtForm {
                            constant: format!(
                                "(ite (= {f} 0) {} 0)",
                                max_smt_c(symbol.as_str(), alt)
                            ),
                            coefficients: BTreeMap::new(),
                        };
                        for (i, arg) in combination.iter().enumerate() {
                            let a = max_smt_a(symbol.as_str(), alt, i);
                            let scale = |value: &str| {
                                let ordinary = if self.binary {
                                    format!("(ite (= {a} 0) 0 {value})")
                                } else {
                                    smt_mul(&a, value)
                                };
                                format!(
                                    "(ite (= {f} 0) {ordinary} (ite (= {f} {}) {value} 0))",
                                    i + 1
                                )
                            };
                            form.constant = smt_add(&form.constant, &scale(&arg.constant));
                            for (v, c) in &arg.coefficients {
                                let scaled = scale(c);
                                form.coefficients
                                    .entry(v.clone())
                                    .and_modify(|old| *old = smt_add(old, &scaled))
                                    .or_insert(scaled);
                            }
                        }
                        form.constant = self.bind("Int", form.constant);
                        for c in form.coefficients.values_mut() {
                            *c = self.bind("Int", c.clone());
                        }
                        forms.push(form);
                    }
                }
                forms
            }
        };
        // Ground subterms denote one scalar, even when their algebra has
        // several max alternatives. Keep that scalar as a shared SMT DAG
        // node instead of multiplying identical variable-free branches into
        // every enclosing argument combination. This is exact, not a bound
        // or a restriction on the synthesized interpretation.
        let result = if self.compact_ground && result.len() > 1 && result.iter().all(|f| f.coefficients.is_empty()) {
            let mut maximum = result[0].constant.clone();
            for form in &result[1..] {
                maximum = self.bind("Int", format!(
                    "(ite (>= {maximum} {}) {maximum} {})", form.constant, form.constant
                ));
            }
            vec![SmtForm { constant: maximum, coefficients: BTreeMap::new() }]
        } else {
            result
        };
        self.forms.insert(term.clone(), result.clone());
        Some(result)
    }

    fn lex(
        &mut self,
        f: &str,
        ss: &[Term],
        g: &str,
        ts: &[Term],
        i: usize,
        j: usize,
    ) -> Option<(String, String)> {
        if self.permutations {
            return self.permuted_lex(f, ss, g, ts);
        }
        check_smt_build(&self.script, self.deadline)?;
        if i == ss.len() {
            return Some((
                "false".into(),
                smt_and(
                    (j..ts.len())
                        .map(|k| format!("(= {} 0)", selected(g, k)))
                        .collect(),
                ),
            ));
        }
        if j == ts.len() {
            return Some((
                smt_or(
                    (i..ss.len())
                        .map(|k| format!("(= {} 1)", selected(f, k)))
                        .collect(),
                ),
                "true".into(),
            ));
        }
        let skip_left = self.lex(f, ss, g, ts, i + 1, j)?;
        let skip_right = self.lex(f, ss, g, ts, i, j + 1)?;
        let rest = self.lex(f, ss, g, ts, i + 1, j + 1)?;
        let cmp = self.compare(&ss[i], &ts[j])?;
        let l = selected(f, i);
        let r = selected(g, j);
        let combine = |a: &str, b: &str, c: &str| {
            format!("(ite (= {l} 0) {a} (ite (= {r} 0) {b} (or {} (and {} {c}))))", cmp.0, cmp.1)
        };
        Some((
            self.bind(
                "Bool",
                combine(&skip_left.0, &skip_right.0, &rest.0),
            ),
            self.bind(
                "Bool",
                combine(&skip_left.1, &skip_right.1, &rest.1),
            ),
        ))
    }

    fn permuted_lex(&mut self, f: &str, ss: &[Term], g: &str, ts: &[Term]) -> Option<(String, String)> {
        // One rank per selected argument, not one case per permutation.
        // Pair comparisons are shared across every position in the status.
        let mut comparisons = Vec::new();
        for (i, s) in ss.iter().enumerate() {
            for (j, t) in ts.iter().enumerate() {
                comparisons.push((i, j, self.compare(s, t)?));
            }
        }
        let mut rest = ("false".to_owned(), "true".to_owned());
        for slot in (1..=ss.len().max(ts.len())).rev() {
            check_smt_build(&self.script, self.deadline)?;
            let left = smt_or((0..ss.len()).map(|i| format!("(= {} {slot})", position(f, i))).collect());
            let right = smt_or((0..ts.len()).map(|j| format!("(= {} {slot})", position(g, j))).collect());
            let mut strict = Vec::new();
            let mut weak = Vec::new();
            for (i, j, cmp) in &comparisons {
                let guard = format!("(and (= {} {slot}) (= {} {slot}))", position(f, *i), position(g, *j));
                strict.push(smt_and(vec![guard.clone(), cmp.0.clone()]));
                weak.push(smt_and(vec![guard, cmp.1.clone()]));
            }
            let strict = self.bind("Bool", smt_or(strict));
            let weak = self.bind("Bool", smt_or(weak));
            rest = (
                self.bind("Bool", format!("(ite {left} (ite {right} (or {strict} (and {weak} {})) true) false)", rest.0)),
                self.bind("Bool", format!("(ite {left} (ite {right} (or {strict} (and {weak} {})) true) (not {right}))", rest.1)),
            );
        }
        Some(rest)
    }

    fn compare(&mut self, lhs: &Term, rhs: &Term) -> Option<(String, String)> {
        // Reflexivity is independent of the synthesized interpretation,
        // filter and status. Avoid encoding an entire recursive comparison
        // DAG merely to rediscover that a shared subterm equals itself.
        if lhs == rhs {
            return Some(("false".into(), "true".into()));
        }
        let key = (lhs.clone(), rhs.clone());
        if let Some(value) = self.comparisons.get(&key) {
            return Some(value.clone());
        }
        check_smt_build(&self.script, self.deadline)?;
        let mut strict_cases = Vec::new();
        let mut weak_cases = Vec::new();
        if let Term::App { symbol, args } = lhs {
            for (i, arg) in args.iter().enumerate() {
                let cmp = self.compare(arg, rhs)?;
                let guard = format!("(= {} {})", af(symbol.as_str()), i + 1);
                strict_cases.push(smt_and(vec![guard.clone(), cmp.0]));
                weak_cases.push(smt_and(vec![guard, cmp.1]));
            }
        }
        if let Term::App { symbol, args } = rhs {
            for (i, arg) in args.iter().enumerate() {
                let cmp = self.compare(lhs, arg)?;
                let guard = smt_and(vec![
                    keep(lhs),
                    format!("(= {} {})", af(symbol.as_str()), i + 1),
                ]);
                strict_cases.push(smt_and(vec![guard.clone(), cmp.0]));
                weak_cases.push(smt_and(vec![guard, cmp.1]));
            }
        }
        let left = self.interpret(lhs)?;
        let right = self.interpret(rhs)?;
        let algebra_strict = self.bind(
            "Bool",
            max_smt_strict_formula_until(&left, &right, self.deadline)?,
        );
        let algebra_weak = self.bind(
            "Bool",
            max_smt_weak_formula_until(&left, &right, self.deadline)?,
        );
        let mut path_strict = Vec::new();
        let mut path_weak = Vec::new();
        match (lhs, rhs) {
            (Term::Var(x), Term::Var(y)) => {
                if x == y {
                    path_weak.push("true".into());
                }
            }
            (Term::Var(_), Term::App { symbol, args }) => {
                let mut clauses = vec![format!("(= {} 0)", rank(symbol.as_str()))];
                clauses.extend(
                    (0..args.len()).map(|i| format!("(= {} 0)", selected(symbol.as_str(), i))),
                );
                path_weak.push(smt_and(clauses));
            }
            (
                Term::App {
                    symbol: f,
                    args: ss,
                },
                _,
            ) => {
                for (i, arg) in ss.iter().enumerate() {
                    let case = smt_and(vec![
                        format!("(= {} 1)", selected(f.as_str(), i)),
                        self.compare(arg, rhs)?.1,
                    ]);
                    path_strict.push(case.clone());
                    path_weak.push(case);
                }
                if let Term::App {
                    symbol: g,
                    args: ts,
                } = rhs
                {
                    let mut domination = Vec::new();
                    for (j, arg) in ts.iter().enumerate() {
                        domination.push(format!(
                            "(=> (= {} 1) {})",
                            selected(g.as_str(), j),
                            self.compare(lhs, arg)?.0
                        ));
                    }
                    let lex = self.lex(f.as_str(), ss, g.as_str(), ts, 0, 0)?;
                    let greater = format!("(> {} {})", rank(f.as_str()), rank(g.as_str()));
                    let equal = format!("(= {} {})", rank(f.as_str()), rank(g.as_str()));
                    let dom = smt_and(domination);
                    path_strict.push(smt_and(vec![
                        dom.clone(),
                        smt_or(vec![greater.clone(), smt_and(vec![equal.clone(), lex.0])]),
                    ]));
                    path_weak.push(smt_and(vec![
                        dom,
                        smt_or(vec![greater, smt_and(vec![equal, lex.1])]),
                    ]));
                }
            }
        }
        let guard = smt_and(vec![keep(lhs), keep(rhs)]);
        strict_cases.push(smt_and(vec![
            guard.clone(),
            smt_or(vec![
                algebra_strict.clone(),
                smt_and(vec![algebra_weak.clone(), smt_or(path_strict)]),
            ]),
        ]));
        weak_cases.push(smt_and(vec![
            guard,
            smt_or(vec![
                algebra_strict,
                smt_and(vec![algebra_weak, smt_or(path_weak)]),
            ]),
        ]));
        let result = (
            self.bind("Bool", smt_or(strict_cases)),
            self.bind("Bool", smt_or(weak_cases)),
        );
        self.comparisons.insert(key, result.clone());
        Some(result)
    }
}

#[cfg(test)]
pub(crate) fn synthesize_wpo_max(
    pairs: &[DependencyPair],
    rules: &[RewriteRule],
    options: &DpOptions,
    alternatives: usize,
    all_strict: bool,
    deadline: Option<Instant>,
) -> Option<ComponentRemoval> {
    synthesize_wpo_max_permuting(pairs, rules, options, alternatives, all_strict, false, false, false, deadline)
}

pub(crate) fn synthesize_wpo_max_permuting(
    pairs: &[DependencyPair], rules: &[RewriteRule], options: &DpOptions,
    alternatives: usize, all_strict: bool, permutations: bool, compact_ground: bool, ordered_alternatives: bool, deadline: Option<Instant>,
) -> Option<ComponentRemoval> {
    let started = Instant::now();
    let arities = arities_for_constraints(pairs, rules);
    if pairs.is_empty()
        || alternatives == 0
        || alternatives > 8
        || arities.len() > options.max_polynomial_symbols
        || arities
            .values()
            .any(|a| *a > options.max_polynomial_arity || *a > 4)
        || options.max_polynomial_constant < 0
        || options.max_polynomial_coefficient < 0
    {
        return None;
    }
    let mut e = Encoding {
        script: String::from(if options.max_polynomial_coefficient <= 1 {
            "(set-logic QF_LIA)\n"
        } else {
            "(set-logic QF_NIA)\n"
        }),
        fresh: 0,
        alternatives,
        binary: options.max_polynomial_coefficient <= 1,
        permutations,
        compact_ground,
        deadline,
        forms: HashMap::new(),
        comparisons: HashMap::new(),
    };
    for (s, arity) in &arities {
        for (name, bound) in [(af(s), *arity as i64), (rank(s), arities.len() as i64)] {
            e.script.push_str(&format!(
                "(declare-const {name} Int)\n(assert (and (<= 0 {name}) (<= {name} {bound})))\n"
            ));
        }
        for alt in 0..alternatives {
            for (name, bound) in
                std::iter::once((max_smt_c(s, alt), options.max_polynomial_constant)).chain(
                    (0..*arity).map(|i| (max_smt_a(s, alt, i), options.max_polynomial_coefficient)),
                )
            {
                e.script.push_str(&format!(
                    "(declare-const {name} Int)\n(assert (and (<= 0 {name}) (<= {name} {bound})))\n"
                ));
            }
        }
        if ordered_alternatives {
            // Max is invariant under permutation of its alternatives. A
            // lexicographic ordering of coefficient tuples removes only
            // redundant representations, not possible interpretations.
            for alt in 1..alternatives {
                let tuple = |a| std::iter::once(max_smt_c(s, a))
                    .chain((0..*arity).map(|i| max_smt_a(s, a, i))).collect::<Vec<_>>();
                let left = tuple(alt - 1);
                let right = tuple(alt);
                let mut le = "true".to_owned();
                for (a, b) in left.iter().zip(&right).rev() {
                    le = format!("(or (< {a} {b}) (and (= {a} {b}) {le}))");
                }
                e.script.push_str(&format!("(assert {le})\n"));
            }
        }
        for i in 0..*arity {
            let st = selected(s, i);
            e.script.push_str(&format!(
                "(declare-const {st} Int)\n(assert (and (<= 0 {st}) (<= {st} 1)))\n"
            ));
            // Weak simplicity on selected status positions is necessary for WPO.
            let simple = smt_or(
                (0..alternatives)
                    .map(|alt| format!("(>= {} 1)", max_smt_a(s, alt, i)))
                    .collect(),
            );
            e.script
                .push_str(&format!("(assert (=> (= {st} 1) {simple}))\n"));
        }
        if permutations {
            let count = (0..*arity).fold("0".to_owned(), |sum, i| smt_add(&sum, &selected(s, i)));
            for i in 0..*arity {
                let pos = position(s, i);
                e.script.push_str(&format!(
                    "(declare-const {pos} Int)\n(assert (and (<= 0 {pos}) (<= {pos} {count})))\n(assert (= (= {pos} 0) (= {} 0)))\n", selected(s, i)
                ));
                for j in 0..i {
                    e.script.push_str(&format!("(assert (=> (and (> {pos} 0) (> {} 0)) (distinct {pos} {})))\n", position(s, j), position(s, j)));
                }
            }
        }
    }
    for rule in rules {
        let weak = e.compare(rule.lhs(), rule.rhs())?.1;
        e.script.push_str(&format!("(assert {weak})\n"));
    }
    let mut strict = Vec::new();
    for pair in pairs {
        let cmp = e.compare(pair.lhs(), pair.rhs())?;
        e.script.push_str(&format!("(assert {})\n", cmp.1));
        strict.push(cmp.0);
    }
    e.script.push_str(&format!(
        "(assert {})\n(check-sat)\n(get-model)\n",
        if all_strict { smt_and(strict) } else { smt_or(strict) }
    ));
    write_smt_encoding_event(
        "wpo-max",
        started,
        &e.script,
        pairs,
        rules,
        format!("alternatives={alternatives} all_strict={all_strict} dag_nodes={}", e.fresh),
    );
    let output = run_smt_script(&e.script, options, deadline)?;
    let base = parse_max_polynomial_model(&output, &arities, alternatives)?;
    let values = parse_smt_values(&output)?;
    let mut witness = DpWpoMaxWitness {
        precedence_ranks: BTreeMap::new(),
        statuses: BTreeMap::new(),
        argument_filter: BTreeMap::new(),
        interpretation: base
            .into_iter()
            .map(|(s, ps)| {
                (
                    s,
                    ps.into_iter()
                        .map(|p| (p.constant, p.coefficients))
                        .collect(),
                )
            })
            .collect(),
    };
    for (s, arity) in arities {
        let filter = usize::try_from(*values.get(&af(&s))?).ok()?;
        if filter > arity {
            return None;
        }
        if filter > 0 {
            witness
                .argument_filter
                .insert(s.clone(), DpArgumentFilterEntry::Collapsing(filter - 1));
        }
        witness
            .precedence_ranks
            .insert(s.clone(), usize::try_from(*values.get(&rank(&s))?).ok()?);
        let mut positions = (0..arity)
            .filter(|i| values.get(&selected(&s, *i)) == Some(&1)).collect::<Vec<_>>();
        if permutations {
            positions.sort_by_key(|i| values.get(&position(&s, *i)).copied().unwrap_or(0));
        }
        witness.statuses.insert(
            s.clone(),
            DpWpoStatus {
                positions,
                multiset: false,
            },
        );
    }
    let mut removal = checked_component_removal_by_wpo_max(pairs, rules, &witness, None)?;
    removal.smt_attempted = true;
    Some(removal)
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn symbolic_weak_lex_prefix_checks_the_tail() {
        for permutations in [false, true] {
            let mut e = Encoding {
                script: String::from("(set-logic QF_LIA)\n"), fresh: 0,
                alternatives: 1, binary: true, permutations, compact_ground: false, deadline: None,
                forms: HashMap::new(), comparisons: HashMap::new(),
            };
            for symbol in ["left", "right"] {
                for i in 0..2 {
                    e.script.push_str(&format!("(define-fun {} () Int {})\n", position(symbol, i), i+1));
                    e.script.push_str(&format!("(define-fun {} () Int 1)\n", selected(symbol, i)));
                }
            }
            for symbol in ["a", "b"] {
                for name in [af(symbol), rank(symbol), max_smt_c(symbol, 0)] {
                    e.script.push_str(&format!("(define-fun {name} () Int 0)\n"));
                }
            }
            let cmp = e.lex("left", &[Term::app("a", vec![]), Term::var("x")],
                "right", &[Term::app("b", vec![]), Term::var("y")], 0, 0).unwrap();
            e.script.push_str(&format!("(assert {})\n(check-sat)\n", cmp.1));
            let output = run_smt_script(&e.script, &DpOptions::default(),
                Some(Instant::now()+std::time::Duration::from_secs(5))).unwrap();
            assert!(output.lines().any(|line| line.trim() == "unsat"), "{output}");
        }
    }

    #[test]
    fn symbolic_status_positions_compare_reverse_lex_without_enumeration() {
        for reverse in [false, true] {
            let mut e = Encoding {
                script: String::from("(set-logic QF_LIA)\n"), fresh: 0,
                alternatives: 1, binary: true, permutations: true, compact_ground: false, deadline: None,
                forms: HashMap::new(), comparisons: HashMap::new(),
            };
            for symbol in ["left", "right"] {
                for i in 0..2 {
                    let value = if reverse { 2-i } else { i+1 };
                    e.script.push_str(&format!("(define-fun {} () Int {value})\n", position(symbol, i)));
                }
            }
            for (name, value) in [(af("succ"), 0), (rank("succ"), 1),
                (selected("succ", 0), 1), (position("succ", 0), 1),
                (max_smt_c("succ", 0), 0), (max_smt_a("succ", 0, 0), 1)] {
                e.script.push_str(&format!("(define-fun {name} () Int {value})\n"));
            }
            let x = Term::var("x");
            let y = Term::var("y");
            let cmp = e.lex("left", &[x.clone(), Term::app("succ", vec![y.clone()])],
                "right", &[Term::app("succ", vec![x]), y], 0, 0).unwrap();
            e.script.push_str(&format!("(assert (not (= {} {})))\n(check-sat)\n", cmp.0, reverse));
            let output = run_smt_script(&e.script, &DpOptions::default(),
                Some(Instant::now()+std::time::Duration::from_secs(5))).unwrap();
            assert!(output.lines().any(|line| line.trim() == "unsat"), "{output}");
        }
    }

    #[test]
    fn ground_max_subterms_share_one_exact_scalar() {
        let mut encoding = Encoding {
            script: String::from("(set-logic QF_LIA)\n"), fresh: 0,
            alternatives: 3, binary: true, permutations: false, compact_ground: true, deadline: None,
            forms: HashMap::new(), comparisons: HashMap::new(),
        };
        for symbol in ["atom", "wrap"] {
            encoding.script.push_str(&format!("(define-fun {} () Int 0)\n", af(symbol)));
            for alt in 0..3 {
                encoding.script.push_str(&format!("(define-fun {} () Int {})\n",
                    max_smt_c(symbol, alt), alt + usize::from(symbol == "atom")));
                if symbol == "wrap" {
                    encoding.script.push_str(&format!("(define-fun {} () Int 1)\n",
                        max_smt_a(symbol, alt, 0)));
                }
            }
        }
        let mut term = Term::app("atom", vec![]);
        for _ in 0..20 { term = Term::app("wrap", vec![term]); }
        let forms = encoding.interpret(&term).unwrap();
        assert_eq!(forms.len(), 1);
        assert!(forms[0].coefficients.is_empty());
        let nodes = encoding.fresh;
        assert_eq!(encoding.interpret(&term).unwrap().len(), 1);
        assert_eq!(encoding.fresh, nodes);
        assert!(nodes < 150);
        encoding.script.push_str(&format!("(assert (not (= {} 43)))\n(check-sat)\n", forms[0].constant));
        let output = run_smt_script(&encoding.script, &DpOptions::default(),
            Some(Instant::now() + std::time::Duration::from_secs(5))).unwrap();
        assert!(output.lines().any(|line| line.trim() == "unsat"), "{output}");
    }

    #[test]
    fn native_wpo_synthesizes_without_supplied_filter_or_model() {
        for suffix in ["", "_renamed"] {
            let unary = |s: &str, t: Term| Term::app(format!("{s}{suffix}"), vec![t]);
            let x = Term::var("x");
            let pairs = [DependencyPair::new_for_test(
                unary("top", unary("s", x.clone())),
                unary("top", unary("mark", x.clone())),
            )];
            let rules = [RewriteRule::new(
                unary("mark", unary("dbl", x.clone())),
                unary("active", unary("mark", x)),
            )];
            let mut options = DpOptions::default();
            options.max_polynomial_coefficient = 1;
            options.max_polynomial_constant = 1;
            let removal = synthesize_wpo_max(
                &pairs,
                &rules,
                &options,
                1,
                false,
                Some(Instant::now() + Duration::from_secs(15)),
            )
            .expect("native WPO search");
            assert_eq!(removal.strict_pair_indices, vec![0]);
        }
    }

    #[test]
    fn native_wpo_all_strict_strategy_round_trips() {
        let atom = "wpo-max(max-constant=127,max-coefficient=1,alternatives=3,all-strict=1,permutations=1)";
        let parsed = DpStrategy::parse(atom).expect("all-strict is a native search bound");
        let serialized = parsed.to_strategy_atom();
        assert!(serialized.contains("all-strict=1"));
        assert!(serialized.contains("permutations=1"));
        assert_eq!(DpStrategy::parse(&serialized).unwrap().to_strategy_atom(), serialized);
        assert!(DpStrategy::parse(&atom.replace("all-strict=1", "all-strict=2")).is_err());
        assert!(DpStrategy::parse(&atom.replace("permutations=1", "permutations=2")).is_err());
        for flag in ["compact-ground=0", "compact-ground=1", "ordered-alternatives=0", "ordered-alternatives=1"] {
            let atom = atom.replace("permutations=1", flag);
            let parsed = DpStrategy::parse(&atom).unwrap().to_strategy_atom();
            assert_eq!(DpStrategy::parse(&parsed).unwrap().to_strategy_atom(), parsed);
        }
        assert!(DpStrategy::parse(&atom.replace("permutations=1", "compact-ground=2")).is_err());
        assert!(DpStrategy::parse(&atom.replace("permutations=1", "ordered-alternatives=2")).is_err());
        assert!(!DpStrategy::parse("wpo-max(1,1,1)").unwrap()
            .to_strategy_atom().contains("all-strict"));
    }

    #[test]
    fn native_wpo_all_strict_does_not_accept_partial_deletion() {
        let x = Term::var("x");
        let decreasing = DependencyPair::new_for_test(
            Term::app("top", vec![Term::app("s", vec![x.clone()])]),
            Term::app("top", vec![x.clone()]),
        );
        let stationary = Term::app("other", vec![x]);
        let pairs = [decreasing, DependencyPair::new_for_test(stationary.clone(), stationary)];
        let mut options = DpOptions::default();
        options.max_polynomial_coefficient = 1;
        options.max_polynomial_constant = 1;
        let partial = synthesize_wpo_max(
            &pairs, &[], &options, 1, false,
            Some(Instant::now() + Duration::from_secs(15)),
        ).expect("one pair can be deleted");
        assert_eq!(partial.strict_pair_indices, vec![0]);
        assert!(synthesize_wpo_max(
            &pairs, &[], &options, 1, true,
            Some(Instant::now() + Duration::from_secs(15)),
        ).is_none());
        let total = synthesize_wpo_max(
            &pairs[..1], &[], &options, 1, true,
            Some(Instant::now() + Duration::from_secs(15)),
        ).expect("all decreasing pairs can be deleted");
        assert_eq!(total.strict_pair_indices, vec![0]);
    }

    #[test]
    fn ordered_max_alternatives_still_synthesize_a_native_order() {
        let x = Term::var("x");
        let pairs = [DependencyPair::new_for_test(
            Term::app("top", vec![Term::app("s", vec![x.clone()])]),
            Term::app("top", vec![x]),
        )];
        let mut options = DpOptions::default();
        options.max_polynomial_constant = 2;
        options.max_polynomial_coefficient = 1;
        let removal = synthesize_wpo_max_permuting(&pairs, &[], &options,
            3, true, true, true, true,
            Some(Instant::now() + Duration::from_secs(15))).unwrap();
        assert_eq!(removal.strict_pair_indices, vec![0]);
    }

    #[test]
    fn native_wpo_rejects_self_loop() {
        let t = Term::app("f", vec![Term::var("x")]);
        let pair = DependencyPair::new_for_test(t.clone(), t);
        assert!(
            synthesize_wpo_max(
                &[pair],
                &[],
                &DpOptions::default(),
                1,
                false,
                Some(Instant::now() + Duration::from_secs(10))
            )
            .is_none()
        );
    }
}
