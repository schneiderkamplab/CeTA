//! Slope-one quasi-periodic synthesis on unary signatures.
//!
//! Search f(d*q+r) = d*q + v_f[r], with monotonicity across a whole period.
//! Convert to integer-Arctic matrices (Koprowski/Waldmann, Acta Cybernetica
//! 19(2), 2009, section 9) and independently check the matrices. This module
//! is candidate discovery only: no new trusted certificate rule is introduced.
use super::*;

pub(crate) fn synthesize_quasi_periodic(
    pairs: &[DependencyPair],
    rules: &[RewriteRule],
    period: usize,
    max_weight: i64,
    options: &DpOptions,
    required: Option<usize>,
    deadline: Option<Instant>,
) -> Option<BTreeMap<String, MatrixInterpretation>> {
    synthesize(
        pairs, rules, period, max_weight, options, required, deadline, false,
    )
}

pub(crate) fn synthesize_quasi_periodic_bv(
    pairs: &[DependencyPair],
    rules: &[RewriteRule],
    period: usize,
    max_weight: i64,
    options: &DpOptions,
    required: Option<usize>,
    deadline: Option<Instant>,
) -> Option<BTreeMap<String, MatrixInterpretation>> {
    synthesize(
        pairs, rules, period, max_weight, options, required, deadline, true,
    )
}

fn synthesize(
    pairs: &[DependencyPair],
    rules: &[RewriteRule],
    period: usize,
    max_weight: i64,
    options: &DpOptions,
    required: Option<usize>,
    deadline: Option<Instant>,
    bitvectors: bool,
) -> Option<BTreeMap<String, MatrixInterpretation>> {
    if !(1..=16).contains(&period)
        || !(0..=64).contains(&max_weight)
        || strategy_timed_out(deadline)
        || pairs.is_empty()
    {
        return None;
    }
    let arities = arities_for_constraints(pairs, rules);
    if arities.is_empty() || arities.len() > 128 || arities.values().any(|n| *n != 1) {
        return None;
    }
    let symbols = arities
        .keys()
        .enumerate()
        .map(|(i, s)| (s.clone(), i))
        .collect::<BTreeMap<_, _>>();
    let tops = pairs
        .iter()
        .flat_map(|p| [p.lhs().root_symbol(), p.rhs().root_symbol()])
        .flatten()
        .map(|s| s.as_str().to_owned())
        .collect::<BTreeSet<_>>();
    let d = period as i64;
    // For depth h, evaluation is at most d-1+h*max(v). Reserve also
    // max(v)+d for the monotonicity constraint. Thus no BV addition or
    // multiplication can wrap: this is the same finite search as QF_LIA.
    fn unary_depth(term: &Term) -> Option<u64> {
        match term {
            Term::Var(_) => Some(0),
            Term::App { args, .. } if args.len() == 1 => unary_depth(&args[0])?.checked_add(1),
            _ => None,
        }
    }
    let depth = rules
        .iter()
        .flat_map(|r| [r.lhs(), r.rhs()])
        .chain(pairs.iter().flat_map(|p| [p.lhs(), p.rhs()]))
        .map(unary_depth)
        .collect::<Option<Vec<_>>>()?
        .into_iter()
        .max()?;
    let bound = (d as u64)
        .checked_mul(max_weight as u64 + 1)?
        .checked_sub(1)?;
    let maximum = depth.max(1).checked_mul(bound)?.checked_add(d as u64)?;
    let bits = (64 - maximum.leading_zeros()).max(1);
    if bits > 62 {
        return None;
    }
    let sort = if bitvectors {
        format!("(_ BitVec {bits})")
    } else {
        "Int".into()
    };
    let lit = |n: i64| {
        if bitvectors {
            format!("(_ bv{n} {bits})")
        } else {
            n.to_string()
        }
    };
    let ge = if bitvectors { "bvuge" } else { ">=" };
    let le = if bitvectors { "bvule" } else { "<=" };
    let gt = if bitvectors { "bvugt" } else { ">" };
    let add = if bitvectors { "bvadd" } else { "+" };
    let mul = if bitvectors { "bvmul" } else { "*" };
    let div = if bitvectors { "bvudiv" } else { "div" };
    let rem = if bitvectors { "bvurem" } else { "mod" };
    let mut script = format!(
        "(set-logic {})\n",
        if bitvectors { "QF_BV" } else { "QF_LIA" }
    );
    for i in symbols.values() {
        for r in 0..period {
            script.push_str(&format!("(declare-const qp_v_{i}_{r} {sort})\n(assert (and ({ge} qp_v_{i}_{r} {}) ({le} qp_v_{i}_{r} {})))\n", lit(0), lit(bound as i64)));
            if r > 0 {
                script.push_str(&format!(
                    "(assert ({le} qp_v_{i}_{} qp_v_{i}_{r}))\n",
                    r - 1
                ));
            }
        }
        script.push_str(&format!(
            "(assert ({le} qp_v_{i}_{} ({add} qp_v_{i}_0 {})))\n",
            period - 1,
            lit(d)
        ));
        let mut lookup = format!("qp_v_{i}_{}", period - 1);
        for r in (0..period - 1).rev() {
            lookup = format!(
                "(ite (= ({rem} x {}) {}) qp_v_{i}_{r} {lookup})",
                lit(d),
                lit(r as i64)
            );
        }
        script.push_str(&format!(
            "(define-fun qp_f_{i} ((x {sort})) {sort} ({add} ({mul} {} ({div} x {})) {lookup}))\n",
            lit(d),
            lit(d)
        ));
    }
    // Each distinct subterm/residue is encoded once. Long shared word suffixes
    // are named DAG nodes, not repeatedly inlined arithmetic expressions.
    let mut cache = std::collections::HashMap::new();
    let mut strict = Vec::new();
    for (lhs, rhs, is_pair) in rules
        .iter()
        .map(|r| (r.lhs(), r.rhs(), false))
        .chain(pairs.iter().map(|p| (p.lhs(), p.rhs(), true)))
    {
        let vars = lhs.variables();
        if vars.len() != 1 || vars != rhs.variables() {
            return None;
        }
        let mut comparisons = Vec::new();
        for residue in 0..period {
            let l = encode(lhs, residue, &symbols, &mut script, &mut cache, &sort, &lit)?;
            let r = encode(rhs, residue, &symbols, &mut script, &mut cache, &sort, &lit)?;
            script.push_str(&format!("(assert ({ge} {l} {r}))\n"));
            comparisons.push(format!("({gt} {l} {r})"));
        }
        if is_pair {
            strict.push(smt_and(comparisons));
        }
    }
    if let Some(i) = required {
        script.push_str(&format!("(assert {})\n", strict.get(i)?));
    } else {
        script.push_str(&format!("(assert {})\n", smt_or(strict.clone())));
    }
    if options
        .smt_solver
        .as_deref()
        .unwrap_or("z3")
        .rsplit('/')
        .next()
        == Some("z3")
    {
        for relation in strict {
            script.push_str(&format!("(maximize (ite {relation} 1 0))\n"));
        }
    }
    script.push_str("(check-sat)\n(get-model)\n");
    write_progress_event(
        "dp-qpi",
        "encoded",
        "quasi-periodic",
        0,
        &format!(
            "period={period} symbols={} nodes={} bytes={}",
            symbols.len(),
            cache.len(),
            script.len()
        ),
    );
    let output = run_smt_script(&script, options, deadline)?;
    if output.lines().map(str::trim).find(|s| !s.is_empty())? != "sat" {
        return None;
    }
    let values = if bitvectors {
        parse_bv_values(&output)?
    } else {
        parse_smt_values(&output)?
    };
    let mut model = BTreeMap::new();
    for (symbol, i) in symbols {
        let v = (0..period)
            .map(|r| values.get(&format!("qp_v_{i}_{r}")).copied())
            .collect::<Option<Vec<_>>>()?;
        if v.iter().any(|n| *n < 0 || *n > d * (max_weight + 1) - 1)
            || v.windows(2).any(|w| w[0] > w[1])
            || v[period - 1] > v[0] + d
        {
            return None;
        }
        let matrix = (0..period)
            .map(|row| {
                v.iter()
                    .map(|n| {
                        if tops.contains(&symbol) {
                            *n
                        } else {
                            d * (n / d - i64::from(row as i64 > n % d))
                        }
                    })
                    .collect()
            })
            .collect();
        model.insert(
            symbol,
            MatrixInterpretation {
                constant: vec![i64::MIN; period],
                coefficients: vec![matrix],
            },
        );
    }
    checked_component_removal_by_arctic_matrix(
        pairs,
        rules,
        &model,
        ArcticMatrixDomain::Integers,
        DpSearchBackend::Smt,
        None,
    )
    .map(|_| model)
}

fn encode(
    term: &Term,
    residue: usize,
    symbols: &BTreeMap<String, usize>,
    script: &mut String,
    cache: &mut std::collections::HashMap<(Term, usize), String>,
    sort: &str,
    lit: &impl Fn(i64) -> String,
) -> Option<String> {
    let key = (term.clone(), residue);
    if let Some(v) = cache.get(&key) {
        return Some(v.clone());
    }
    let value = match term {
        Term::Var(_) => lit(residue as i64),
        Term::App { symbol, args } if args.len() == 1 => {
            let child = encode(&args[0], residue, symbols, script, cache, sort, lit)?;
            let index = symbols.get(symbol.as_str())?;
            let name = format!("qp_t_{}", cache.len());
            script.push_str(&format!(
                "(define-fun {name} () {sort} (qp_f_{index} {child}))\n"
            ));
            name
        }
        _ => return None,
    };
    cache.insert(key, value.clone());
    Some(value)
}

#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn arctic_validation_collapses_equivalent_paths_exactly() {
        let model = BTreeMap::from([(
            "f".into(),
            MatrixInterpretation {
                constant: vec![i64::MIN; 3],
                coefficients: vec![vec![vec![1; 3]; 3]],
            },
        )]);
        let mut term = Term::var("x");
        for depth in 1..=100 {
            term = Term::app("f", vec![term]);
            let rows = arctic_interpret(&term, &model, 3).unwrap();
            for row in rows {
                assert_eq!(row.len(), 3);
                assert!(row.iter().all(|a| a.value == depth));
                assert_eq!(
                    row.iter()
                        .map(|a| a.source.clone())
                        .collect::<BTreeSet<_>>()
                        .len(),
                    3
                );
            }
        }
    }
    #[test]
    fn bitvector_qpi_matches_integer_checks_without_wraparound() {
        for period in [1, 2, 3, 4, 5, 8, 9, 12, 16] {
            // Keep the original long-word overflow regression; larger-period
            // acceptance uses the narrow bounds intended for the new search.
            let max_weight = if period <= 8 { 7 } else { 1 };
            let x = Term::var("x");
            let mut long = x.clone();
            for _ in 0..if period <= 8 { 40 } else { 4 } {
                long = Term::app("f", vec![long]);
            }
            let pairs = [DependencyPair::new_for_test(
                Term::app("top", vec![long]),
                Term::app("top", vec![x]),
            )];
            assert!(
                synthesize_quasi_periodic_bv(
                    &pairs,
                    &[],
                    period,
                    max_weight,
                    &DpOptions::default(),
                    None,
                    Some(Instant::now() + Duration::from_secs(10))
                )
                .is_some(), "positive period={period}"
            );
            let cycle = [DependencyPair::new_for_test(
                pairs[0].lhs().clone(),
                pairs[0].lhs().clone(),
            )];
            assert!(
                synthesize_quasi_periodic_bv(
                    &cycle,
                    &[],
                    period,
                    max_weight,
                    &DpOptions::default(),
                    None,
                    Some(Instant::now() + Duration::from_secs(10))
                )
                .is_none(), "cycle period={period}"
            );
        }
        let atom = "qpi-bv(period=4,max-weight=7)";
        assert_eq!(DpStrategy::parse(atom).unwrap().to_strategy_atom(), atom);
        let extended = "qpi-bv(period=16,max-weight=1)";
        assert_eq!(DpStrategy::parse(extended).unwrap().to_strategy_atom(), extended);
        assert!(DpStrategy::parse("qpi-bv(period=17,max-weight=1)").is_err());
    }
    #[test]
    fn qpi_synthesis_is_checked_as_an_arctic_order() {
        for f in ["f", "renamed"] {
            let x = Term::var("x");
            let pairs = [DependencyPair::new_for_test(
                Term::app("top", vec![Term::app(f, vec![x.clone()])]),
                Term::app("top", vec![x]),
            )];
            let model = synthesize_quasi_periodic(
                &pairs,
                &[],
                3,
                3,
                &DpOptions::default(),
                None,
                Some(Instant::now() + Duration::from_secs(10)),
            )
            .expect("periodic order");
            assert!(
                checked_component_removal_by_arctic_matrix(
                    &pairs,
                    &[],
                    &model,
                    ArcticMatrixDomain::Integers,
                    DpSearchBackend::Smt,
                    None
                )
                .is_some()
            );
            assert!(
                synthesize_quasi_periodic(
                    &pairs,
                    &[],
                    3,
                    3,
                    &DpOptions::default(),
                    None,
                    Some(Instant::now())
                )
                .is_none()
            );
        }
        let atom = "qpi(period=3,max-weight=7)";
        assert_eq!(DpStrategy::parse(atom).unwrap().to_strategy_atom(), atom);
        assert!(DpStrategy::parse("qpi(period=0,max-weight=7)").is_err());
        let t = Term::app("same", vec![Term::var("x")]);
        let cycle = [DependencyPair::new_for_test(t.clone(), t)];
        assert!(
            synthesize_quasi_periodic(
                &cycle,
                &[],
                3,
                3,
                &DpOptions::default(),
                None,
                Some(Instant::now() + Duration::from_secs(10)),
            )
            .is_none()
        );
        let binary = [DependencyPair::new_for_test(
            Term::app("f", vec![Term::var("x"), Term::var("x")]),
            Term::var("x"),
        )];
        assert!(
            synthesize_quasi_periodic(&binary, &[], 3, 3, &DpOptions::default(), None, None,)
                .is_none()
        );
    }
}
