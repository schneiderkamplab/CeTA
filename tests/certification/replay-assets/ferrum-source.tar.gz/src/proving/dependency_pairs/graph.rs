use super::variable_occurrences;
use super::*;
use rayon::prelude::*;

#[cfg(test)]
pub(super) fn dependency_pair_graph(trs: &Trs, pairs: &[DependencyPair]) -> Vec<Vec<usize>> {
    dependency_pair_graph_with_context(trs, pairs, None)
}

#[cfg(test)]
pub(super) fn dependency_pair_graph_with_context(
    trs: &Trs,
    pairs: &[DependencyPair],
    innermost_lhss: Option<&[Term]>,
) -> Vec<Vec<usize>> {
    dependency_pair_graph_with_context_deadline(
        trs,
        pairs,
        innermost_lhss,
        None,
        &DpStrategyCancellation::default(),
    )
    .expect("uncapped dependency-graph construction should not time out")
}

#[cfg(test)]
pub(super) fn dependency_pair_graph_with_context_deadline(
    trs: &Trs,
    pairs: &[DependencyPair],
    innermost_lhss: Option<&[Term]>,
    deadline: Option<Instant>,
    cancellation: &DpStrategyCancellation,
) -> Option<Vec<Vec<usize>>> {
    dependency_pair_graph_with_rules_deadline(
        trs,
        trs.rules(),
        pairs,
        innermost_lhss,
        deadline,
        cancellation,
    )
}

pub(super) fn dependency_pair_graph_with_rules_deadline(
    trs: &Trs,
    active_rules: &[RewriteRule],
    pairs: &[DependencyPair],
    innermost_lhss: Option<&[Term]>,
    deadline: Option<Instant>,
    cancellation: &DpStrategyCancellation,
) -> Option<Vec<Vec<usize>>> {
    let mut graph = vec![Vec::<usize>::new(); pairs.len()];
    let active_trs = Trs::new_with_strategy(
        trs.name().map(str::to_owned),
        trs.variables().clone(),
        active_rules.to_vec(),
        trs.strategy(),
    );
    let edge_context = DpGraphEdgeContext::new(&active_trs);
    let q_context_started = Instant::now();
    let q_source_contexts = innermost_lhss.map(|q_lhss| {
        pairs
            .par_iter()
            .map(|pair| ceta_q_iedg_source_context(pair, q_lhss, active_trs.rules()))
            .collect::<Vec<_>>()
    });
    if q_source_contexts.is_some() && std::env::var_os("FERRUM_WORKLIST_TRACE").is_some() {
        eprintln!(
            "dp graph Q source contexts pairs={} elapsed_ms={}",
            pairs.len(),
            q_context_started.elapsed().as_millis()
        );
    }
    if strategy_timed_out(deadline) || cancellation.is_cancelled() {
        return None;
    }
    let q_target_started = Instant::now();
    let q_target_contexts = innermost_lhss.map(|q_lhss| {
        pairs
            .par_iter()
            .map(|pair| ceta_q_iedg_target_context(pair, q_lhss, &edge_context.q_reversed_rules))
            .collect::<Vec<_>>()
    });
    if q_target_contexts.is_some() && std::env::var_os("FERRUM_WORKLIST_TRACE").is_some() {
        eprintln!(
            "dp graph Q target contexts pairs={} elapsed_ms={}",
            pairs.len(),
            q_target_started.elapsed().as_millis()
        );
    }
    if strategy_timed_out(deadline) || cancellation.is_cancelled() {
        return None;
    }
    for (from, pair) in pairs.iter().enumerate() {
        if strategy_timed_out(deadline) || cancellation.is_cancelled() {
            return None;
        }
        for (to, target) in pairs.iter().enumerate() {
            if strategy_timed_out(deadline) || cancellation.is_cancelled() {
                write_progress_event(
                    "dp-graph",
                    "timeout",
                    "dependency-graph",
                    0,
                    &format!(
                        "pairs={} checked_from={} checked_to={}",
                        pairs.len(),
                        from,
                        to
                    ),
                );
                return None;
            }
            if estimated_dependency_edge_for_pair(
                trs,
                &active_trs,
                &edge_context,
                pair,
                target,
                innermost_lhss,
                innermost_lhss.map(|_| active_trs.rules()),
                q_source_contexts
                    .as_ref()
                    .zip(q_target_contexts.as_ref())
                    .map(|(sources, targets)| (&sources[from], &targets[to])),
            ) {
                log_dp_graph_edge(trs, pairs, from, to, innermost_lhss);
                graph[from].push(to);
            }
        }
    }
    Some(graph)
}

pub(super) fn cached_dependency_pair_graph_with_rules_deadline(
    stats: &DpProofStats,
    trs: &Trs,
    active_rules: &[RewriteRule],
    pairs: &[DependencyPair],
    innermost_lhss: Option<&[Term]>,
    deadline: Option<Instant>,
    cancellation: &DpStrategyCancellation,
) -> Option<Vec<Vec<usize>>> {
    // The edge-cache key contains the complete base and active rule context.
    // Materializing that key for every one of n^2 candidate edges is more
    // expensive than recomputing the edges once on large DP problems (and can
    // transiently clone gigabytes of terms).  The enclosing problem-level
    // graph cache still retains the completed graph, so bypass only the
    // per-edge cache once the repeated rule-context work becomes substantial.
    const MAX_EDGE_CACHE_CONTEXT_COPIES: usize = 16_384;
    if pairs
        .len()
        .saturating_mul(pairs.len())
        .saturating_mul(active_rules.len().max(1))
        > MAX_EDGE_CACHE_CONTEXT_COPIES
    {
        write_progress_event(
            "dp-graph",
            "edge-cache-bypass",
            "dependency-graph",
            0,
            &format!(
                "pairs={} active_rules={} context_copies={}",
                pairs.len(),
                active_rules.len(),
                pairs
                    .len()
                    .saturating_mul(pairs.len())
                    .saturating_mul(active_rules.len().max(1))
            ),
        );
        return dependency_pair_graph_with_rules_deadline(
            trs,
            active_rules,
            pairs,
            innermost_lhss,
            deadline,
            cancellation,
        );
    }
    let mut graph = vec![Vec::<usize>::new(); pairs.len()];
    let active_trs = Trs::new_with_strategy(
        trs.name().map(str::to_owned),
        trs.variables().clone(),
        active_rules.to_vec(),
        trs.strategy(),
    );
    let edge_context = DpGraphEdgeContext::new(&active_trs);
    let q_context_started = Instant::now();
    let q_source_contexts = innermost_lhss.map(|q_lhss| {
        pairs
            .par_iter()
            .map(|pair| ceta_q_iedg_source_context(pair, q_lhss, active_trs.rules()))
            .collect::<Vec<_>>()
    });
    if q_source_contexts.is_some() && std::env::var_os("FERRUM_WORKLIST_TRACE").is_some() {
        eprintln!(
            "cached dp graph Q source contexts pairs={} elapsed_ms={}",
            pairs.len(),
            q_context_started.elapsed().as_millis()
        );
    }
    if strategy_timed_out(deadline) || cancellation.is_cancelled() {
        return None;
    }
    let q_target_started = Instant::now();
    let q_target_contexts = innermost_lhss.map(|q_lhss| {
        pairs
            .par_iter()
            .map(|pair| ceta_q_iedg_target_context(pair, q_lhss, &edge_context.q_reversed_rules))
            .collect::<Vec<_>>()
    });
    if q_target_contexts.is_some() && std::env::var_os("FERRUM_WORKLIST_TRACE").is_some() {
        eprintln!(
            "cached dp graph Q target contexts pairs={} elapsed_ms={}",
            pairs.len(),
            q_target_started.elapsed().as_millis()
        );
    }
    if strategy_timed_out(deadline) || cancellation.is_cancelled() {
        return None;
    }
    let mut edge_cache_hits = 0usize;
    let mut edge_cache_misses = 0usize;
    for (from, pair) in pairs.iter().enumerate() {
        let source_lhs = trs.rules().get(pair.source_rule()).map(RewriteRule::lhs);
        if strategy_timed_out(deadline) || cancellation.is_cancelled() {
            return None;
        }
        for (to, target) in pairs.iter().enumerate() {
            if strategy_timed_out(deadline) || cancellation.is_cancelled() {
                write_progress_event(
                    "dp-graph",
                    "timeout",
                    "dependency-graph",
                    0,
                    &format!(
                        "pairs={} checked_from={} checked_to={}",
                        pairs.len(),
                        from,
                        to
                    ),
                );
                return None;
            }
            let key = DpGraphEdgeCacheKey::Dependency {
                strategy: trs.strategy(),
                base_rules: trs.rules().to_vec(),
                active_rules: active_rules.to_vec(),
                innermost_lhss: innermost_lhss.map(<[Term]>::to_vec),
                source_lhs: source_lhs.cloned(),
                pair: pair.clone(),
                target: target.clone(),
            };
            let (edge, cache_hit) = cached_dp_graph_edge(stats, key, || {
                estimated_dependency_edge_for_pair(
                    trs,
                    &active_trs,
                    &edge_context,
                    pair,
                    target,
                    innermost_lhss,
                    innermost_lhss.map(|_| active_trs.rules()),
                    q_source_contexts
                        .as_ref()
                        .zip(q_target_contexts.as_ref())
                        .map(|(sources, targets)| (&sources[from], &targets[to])),
                )
            });
            if cache_hit {
                edge_cache_hits += 1;
            } else {
                edge_cache_misses += 1;
            }
            if edge {
                log_dp_graph_edge(trs, pairs, from, to, innermost_lhss);
                graph[from].push(to);
            }
        }
    }
    log_dp_graph_edge_cache_event(
        "dependency-graph",
        pairs.len(),
        &graph,
        edge_cache_hits,
        edge_cache_misses,
    );
    Some(graph)
}

#[cfg(test)]
#[allow(dead_code)]
pub(super) fn ceta_q_dependency_pair_graph_with_rules_deadline(
    active_rules: &[RewriteRule],
    pairs: &[DependencyPair],
    q_lhss: &[Term],
    deadline: Option<Instant>,
    cancellation: &DpStrategyCancellation,
) -> Option<Vec<Vec<usize>>> {
    let mut graph = vec![Vec::new(); pairs.len()];
    for (from, pair) in pairs.iter().enumerate() {
        for (to, target) in pairs.iter().enumerate() {
            if strategy_timed_out(deadline) || cancellation.is_cancelled() {
                return None;
            }
            if ceta_q_iedg_edge_with_usable_rules(
                pair,
                target,
                q_lhss,
                active_rules,
                Some(active_rules),
            ) {
                graph[from].push(to);
            }
        }
    }
    Some(graph)
}

pub(crate) fn cached_ceta_q_dependency_pair_graph_with_rules_deadline(
    stats: &DpProofStats,
    active_rules: &[RewriteRule],
    pairs: &[DependencyPair],
    q_lhss: &[Term],
    deadline: Option<Instant>,
    cancellation: &DpStrategyCancellation,
) -> Option<Vec<Vec<usize>>> {
    let mut graph = vec![Vec::new(); pairs.len()];
    let context_copies = pairs
        .len()
        .saturating_mul(pairs.len())
        .saturating_mul(active_rules.len().saturating_add(q_lhss.len()).max(1));
    let use_edge_cache = context_copies <= 16_384;
    let reversed_rules = reverse_rules(active_rules);
    let source_contexts = pairs
        .par_iter()
        .map(|pair| ceta_q_iedg_source_context(pair, q_lhss, active_rules))
        .collect::<Vec<_>>();
    if strategy_timed_out(deadline) || cancellation.is_cancelled() {
        return None;
    }
    let target_contexts = pairs
        .par_iter()
        .map(|pair| ceta_q_iedg_target_context(pair, q_lhss, &reversed_rules))
        .collect::<Vec<_>>();
    if strategy_timed_out(deadline) || cancellation.is_cancelled() {
        return None;
    }
    let defined_symbols = active_rules
        .iter()
        .filter_map(|rule| rule.lhs().root_symbol().cloned())
        .collect::<BTreeSet<_>>();
    if !use_edge_cache {
        // Large Q-aware graphs already bypass the per-edge cache because its
        // cloned rule context would dominate memory.  Their edge obligations
        // are independent, so evaluate complete source rows in parallel
        // instead of leaving the O(|P|^2) phase serial after parallel context
        // construction.  Row order and target order remain deterministic.
        let rows = pairs
            .par_iter()
            .enumerate()
            .map(|(from, pair)| {
                let mut row = Vec::new();
                for (to, target) in pairs.iter().enumerate() {
                    if strategy_timed_out(deadline) || cancellation.is_cancelled() {
                        return None;
                    }
                    let root_mismatch = matches!(
                        (pair.rhs().root_symbol(), target.lhs().root_symbol()),
                        (Some(source_root), Some(target_root))
                            if source_root != target_root
                                && !defined_symbols.contains(source_root)
                    );
                    if !root_mismatch
                        && ceta_q_iedg_edge_from_contexts(
                            &source_contexts[from],
                            &target_contexts[to],
                            q_lhss,
                        )
                    {
                        row.push(to);
                    }
                }
                Some(row)
            })
            .collect::<Vec<Option<Vec<usize>>>>();
        let graph = rows.into_iter().collect::<Option<Vec<_>>>()?;
        log_dp_graph_edge_cache_event("q-dependency-graph", pairs.len(), &graph, 0, 0);
        return Some(graph);
    }
    let mut edge_cache_hits = 0usize;
    let mut edge_cache_misses = 0usize;
    for (from, pair) in pairs.iter().enumerate() {
        for (to, target) in pairs.iter().enumerate() {
            if strategy_timed_out(deadline) || cancellation.is_cancelled() {
                return None;
            }
            let root_mismatch = matches!(
                (pair.rhs().root_symbol(), target.lhs().root_symbol()),
                (Some(source_root), Some(target_root))
                    if source_root != target_root && !defined_symbols.contains(source_root)
            );
            let (edge, cache_hit) = if root_mismatch {
                (false, false)
            } else if use_edge_cache {
                let key = DpGraphEdgeCacheKey::CetaQ {
                    active_rules: active_rules.to_vec(),
                    q_lhss: q_lhss.to_vec(),
                    pair: pair.clone(),
                    target: target.clone(),
                };
                cached_dp_graph_edge(stats, key, || {
                    ceta_q_iedg_edge_from_contexts(
                        &source_contexts[from],
                        &target_contexts[to],
                        q_lhss,
                    )
                })
            } else {
                (
                    ceta_q_iedg_edge_from_contexts(
                        &source_contexts[from],
                        &target_contexts[to],
                        q_lhss,
                    ),
                    false,
                )
            };
            if cache_hit {
                edge_cache_hits += 1;
            } else {
                edge_cache_misses += 1;
            }
            if edge {
                graph[from].push(to);
            }
        }
    }
    log_dp_graph_edge_cache_event(
        "q-dependency-graph",
        pairs.len(),
        &graph,
        edge_cache_hits,
        edge_cache_misses,
    );
    Some(graph)
}

/// CeTA's `check_dep_graph_proc` intersects IEDG with
/// forward/reverse TCAP matching and `not (nonreachable_gtcapRM ... t u)`.
/// These independent reachability
/// filter uses the active R, not the original input TRS or the Q patterns.
/// Keep the cached IEDG decisions separate from this additional filter.
pub(crate) fn refine_ceta_q_dependency_graph(
    active_rules: &[RewriteRule],
    pairs: &[DependencyPair],
    q_lhss: &[Term],
    graph: &mut [Vec<usize>],
    deadline: Option<Instant>,
    cancellation: &DpStrategyCancellation,
) -> Option<()> {
    refine_ceta_q_iedg_with_pair_local_rules(active_rules, pairs, q_lhss, graph, deadline, cancellation)?;
    let active_trs = Trs::new_with_strategy(
        None, Default::default(), active_rules.to_vec(), RewriteStrategy::Full,
    );
    let context = DpGraphEdgeContext::new(&active_trs);
    for (from, successors) in graph.iter_mut().enumerate() {
        if strategy_timed_out(deadline) || cancellation.is_cancelled() { return None; }
        successors.retain(|&to| ceta_estimated_dependency_edge_cached(
            &active_trs, &context, pairs[from].rhs(), pairs[to].lhs()));
    }
    Some(())
}

/// SCT uses IEDG alone, unlike graph decomposition's TCAP intersection.
/// Keep this refinement separate so SCT never relies on edges that only
/// the stronger decomposition checker can remove.
pub(crate) fn refine_ceta_q_iedg_with_pair_local_rules(
    active_rules: &[RewriteRule],
    pairs: &[DependencyPair],
    q_lhss: &[Term],
    graph: &mut [Vec<usize>],
    deadline: Option<Instant>,
    cancellation: &DpStrategyCancellation,
) -> Option<()> {
    // Conservative sufficient conditions for CeTA's inn_usable_rules_pair:
    // NF(Q) subset NF(R), variable preservation of the pair, and weak
    // well-formedness of R. No assumption about hidden minimality or normal
    // substitutions is needed under this branch of its executable guard.
    let pair_local = active_rules.iter().all(|rule|
        !term_is_q_normal(rule.lhs(), q_lhss)
        && rule.rhs().variables().is_subset(&rule.lhs().variables()));
    for (from, successors) in graph.iter_mut().enumerate() {
        if strategy_timed_out(deadline) || cancellation.is_cancelled() { return None; }
        let usable = (pair_local && pairs[from].rhs().variables().is_subset(&pairs[from].lhs().variables()))
            .then(|| ceta_innermost_usable_rules_for_pair(active_rules, q_lhss, &pairs[from]));
        let mut retained = Vec::with_capacity(successors.len());
        for &to in successors.iter() {
            if strategy_timed_out(deadline) || cancellation.is_cancelled() { return None; }
            if usable.as_ref().is_none_or(|rules| rules.len() == active_rules.len()
                    || ceta_q_iedg_edge_with_usable_rules(&pairs[from], &pairs[to], q_lhss, active_rules, Some(rules)))
            { retained.push(to); }
        }
        *successors = retained;
    }
    Some(())
}

#[cfg(test)]
pub(super) fn dp_problem_dependency_graph_with_context_deadline(
    problem: &DpProblemContext,
    trs: &Trs,
    pairs: &[DependencyPair],
    innermost_lhss: Option<&[Term]>,
    active_rules: Option<&[RewriteRule]>,
    deadline: Option<Instant>,
    cancellation: &DpStrategyCancellation,
) -> Option<Vec<Vec<usize>>> {
    match problem {
        DpProblemContext::ContextSensitive(CsrDpProblemContext {
            csr,
            graph_estimator: CsrGraphEstimator::ContextSensitive,
            ..
        }) => csr_dependency_pair_graph_with_context_deadline(
            csr,
            pairs,
            innermost_lhss,
            deadline,
            cancellation,
        ),
        DpProblemContext::Ordinary
        | DpProblemContext::ContextSensitive(CsrDpProblemContext {
            graph_estimator: CsrGraphEstimator::Ordinary,
            ..
        }) => dependency_pair_graph_with_rules_deadline(
            trs,
            active_rules.unwrap_or(trs.rules()),
            pairs,
            innermost_lhss,
            deadline,
            cancellation,
        ),
    }
}

pub(super) fn cached_dp_problem_dependency_graph_edges_with_context_deadline(
    stats: &DpProofStats,
    trs: &Trs,
    pairs: &[DependencyPair],
    innermost_lhss: Option<&[Term]>,
    active_rules: Option<&[RewriteRule]>,
    deadline: Option<Instant>,
    cancellation: &DpStrategyCancellation,
) -> Option<Vec<Vec<usize>>> {
    match &stats.problem {
        DpProblemContext::ContextSensitive(CsrDpProblemContext {
            csr,
            construction: CsrDpConstruction::MutermUnhiding,
            ..
        }) => Some(muterm_typed_dependency_pair_graph(csr, pairs)),
        DpProblemContext::ContextSensitive(CsrDpProblemContext {
            csr,
            graph_estimator: CsrGraphEstimator::ContextSensitive,
            ..
        }) => cached_csr_dependency_pair_graph_with_context_deadline(
            stats,
            csr,
            pairs,
            innermost_lhss,
            deadline,
            cancellation,
        ),
        DpProblemContext::Ordinary
        | DpProblemContext::ContextSensitive(CsrDpProblemContext {
            graph_estimator: CsrGraphEstimator::Ordinary,
            ..
        }) => cached_dependency_pair_graph_with_rules_deadline(
            stats,
            trs,
            active_rules.unwrap_or(trs.rules()),
            pairs,
            innermost_lhss,
            deadline,
            cancellation,
        ),
    }
}

fn muterm_typed_dependency_pair_graph(csr: &CsrTrs, pairs: &[DependencyPair]) -> Vec<Vec<usize>> {
    let native = rta_csr_dependency_pairs(csr);
    let expanded = muterm_expanded_dependency_pairs(csr);
    let mut bridge_rules = csr.rules().to_vec();
    bridge_rules.extend(muterm_innermost_unhiding_rules(csr));
    let bridge_trs = Trs::new_with_strategy(
        csr.trs().name().map(str::to_owned),
        csr.trs().variables().clone(),
        bridge_rules,
        RewriteStrategy::Full,
    );
    let edge_context = DpGraphEdgeContext::new(&bridge_trs);

    let represents = |expanded_pair: &DependencyPair, pair: &DependencyPair| {
        // Instantiation augments a collapsing typed pair with non-variable
        // instances.  Those instances retain the source pair's typed
        // collapsing semantics: selecting an expanded representative solely
        // from the instance's new RHS root can therefore erase checker edges.
        // Classify by the native source pair and preserve all of its expanded
        // representatives throughout the recursive proof.
        let originally_collapsing = native.iter().any(|native_pair| {
            native_pair.source_rule() == pair.source_rule()
                && native_pair.lhs().root_symbol() == pair.lhs().root_symbol()
                && matches!(native_pair.rhs(), Term::Var(_))
        });
        if !originally_collapsing && !matches!(pair.rhs(), Term::Var(_)) {
            return expanded_pair.source_rule() == pair.source_rule()
                && expanded_pair.lhs().root_symbol() == pair.lhs().root_symbol()
                && expanded_pair.rhs().root_symbol() == pair.rhs().root_symbol();
        }
        expanded_pair.source_rule() == pair.source_rule()
            && expanded_pair.lhs().root_symbol() == pair.lhs().root_symbol()
    };

    // CeTA checks the typed pairs themselves in addition to their expanded
    // representatives. In particular, a collapsing RHS variable can reach
    // every compatible marked target. Preserve those direct typed edges;
    // expansion is an additional precision source, never a reason to erase
    // an edge required by the checker.
    let typed_graph = csr_dependency_pair_graph_with_context_deadline(
        csr,
        pairs,
        None,
        None,
        &DpStrategyCancellation::default(),
    )
    .unwrap_or_else(|| vec![(0..pairs.len()).collect(); pairs.len()]);

    pairs
        .iter()
        .enumerate()
        .map(|(source_index, pair)| {
            pairs
                .iter()
                .enumerate()
                .filter_map(|(target_index, target)| {
                    (typed_graph[source_index].contains(&target_index)
                        || expanded
                            .iter()
                            .filter(|expanded_pair| represents(expanded_pair, pair))
                            .any(|expanded_pair| {
                                ceta_estimated_dependency_edge_cached(
                                    &bridge_trs,
                                    &edge_context,
                                    expanded_pair.rhs(),
                                    target.lhs(),
                                )
                            }))
                    .then_some(target_index)
                })
                .collect()
        })
        .collect()
}

#[allow(clippy::too_many_arguments)]
pub(crate) fn cached_dp_problem_dependency_graph_with_context_deadline(
    stats: &DpProofStats,
    trs: &Trs,
    pairs: &[DependencyPair],
    innermost_lhss: Option<&[Term]>,
    active_rules: Option<&[RewriteRule]>,
    deadline: Option<Instant>,
    cancellation: &DpStrategyCancellation,
) -> Option<Vec<Vec<usize>>> {
    let context = DpGraphCacheContext {
        problem: stats.problem.clone(),
        trs: trs.clone(),
        active_rules: active_rules.unwrap_or(trs.rules()).to_vec(),
        innermost_lhss: innermost_lhss.map(<[Term]>::to_vec),
    };
    if let Ok(cache) = stats.graph_cache.lock() {
        if let Some(entries) = cache.get(&context) {
            for entry in entries.iter().rev() {
                if let Some(graph) = induced_dependency_graph(&entry.pairs, &entry.graph, pairs) {
                    write_progress_event(
                        "dp-graph",
                        "cache-hit",
                        "dependency-graph",
                        0,
                        &format!(
                            "cached_pairs={} pairs={} cached_edges={} edges={}",
                            entry.pairs.len(),
                            pairs.len(),
                            graph_edge_count(&entry.graph),
                            graph_edge_count(&graph)
                        ),
                    );
                    return Some(graph);
                }
            }
        }
    }
    let graph = cached_dp_problem_dependency_graph_edges_with_context_deadline(
        stats,
        trs,
        pairs,
        innermost_lhss,
        active_rules,
        deadline,
        cancellation,
    )?;
    if let Ok(mut cache) = stats.graph_cache.lock() {
        let entries = cache.entry(context.clone()).or_default();
        if !entries.iter().any(|entry| entry.pairs == pairs) {
            entries.push(DpGraphCacheEntry {
                pairs: pairs.to_vec(),
                graph: graph.clone(),
            });
        }
    }
    Some(graph)
}

pub(super) fn cached_dp_graph_edge(
    stats: &DpProofStats,
    key: DpGraphEdgeCacheKey,
    compute: impl FnOnce() -> bool,
) -> (bool, bool) {
    if let Ok(cache) = stats.graph_edge_cache.lock()
        && let Some(&edge) = cache.get(&key)
    {
        return (edge, true);
    }

    let edge = compute();
    if let Ok(mut cache) = stats.graph_edge_cache.lock() {
        cache.entry(key).or_insert(edge);
    }
    (edge, false)
}

pub(super) fn log_dp_graph_edge_cache_event(
    processor: &str,
    pairs: usize,
    graph: &[Vec<usize>],
    hits: usize,
    misses: usize,
) {
    if hits == 0 {
        return;
    }
    write_progress_event(
        "dp-graph",
        "edge-cache",
        processor,
        0,
        &format!(
            "pairs={} edges={} hits={} misses={}",
            pairs,
            graph_edge_count(graph),
            hits,
            misses
        ),
    );
}

pub(super) fn induced_dependency_graph(
    cached_pairs: &[DependencyPair],
    cached_graph: &[Vec<usize>],
    pairs: &[DependencyPair],
) -> Option<Vec<Vec<usize>>> {
    if cached_graph.len() != cached_pairs.len() {
        return None;
    }
    let mut used = vec![false; cached_pairs.len()];
    let mut cached_indices = Vec::with_capacity(pairs.len());
    for pair in pairs {
        let index = cached_pairs
            .iter()
            .enumerate()
            .position(|(index, candidate)| !used[index] && candidate == pair)?;
        used[index] = true;
        cached_indices.push(index);
    }
    let reverse = cached_indices
        .iter()
        .enumerate()
        .map(|(index, cached)| (*cached, index))
        .collect::<BTreeMap<_, _>>();
    Some(
        cached_indices
            .iter()
            .map(|cached| {
                cached_graph[*cached]
                    .iter()
                    .filter_map(|target| reverse.get(target).copied())
                    .collect()
            })
            .collect(),
    )
}

#[cfg(test)]
pub(super) fn csr_dependency_pair_graph_with_context(
    csr: &CsrTrs,
    pairs: &[DependencyPair],
    innermost_lhss: Option<&[Term]>,
) -> Vec<Vec<usize>> {
    csr_dependency_pair_graph_with_context_deadline(
        csr,
        pairs,
        innermost_lhss,
        None,
        &DpStrategyCancellation::default(),
    )
    .expect("uncapped CSR dependency-graph construction should not time out")
}

pub(super) fn csr_dependency_pair_graph_with_context_deadline(
    csr: &CsrTrs,
    pairs: &[DependencyPair],
    innermost_lhss: Option<&[Term]>,
    deadline: Option<Instant>,
    cancellation: &DpStrategyCancellation,
) -> Option<Vec<Vec<usize>>> {
    let mut graph = vec![Vec::<usize>::new(); pairs.len()];
    let edge_context = DpGraphEdgeContext::new(csr.trs());
    let forward_tcaps = csr_graph_forward_tcaps(csr.trs(), &edge_context, pairs);
    let reverse_tcaps = csr_graph_reverse_tcaps(csr.trs(), &edge_context, pairs);
    let root_tcaps = csr_graph_root_tcaps(csr, pairs);
    let target_arg_tcap_matches =
        csr_graph_target_arg_tcap_matches(csr.trs(), &edge_context, pairs);
    for (from, pair) in pairs.iter().enumerate() {
        for (to, target) in pairs.iter().enumerate() {
            if strategy_timed_out(deadline) || cancellation.is_cancelled() {
                write_progress_event(
                    "dp-graph",
                    "timeout",
                    "csr-dependency-graph",
                    0,
                    &format!(
                        "pairs={} checked_from={} checked_to={}",
                        pairs.len(),
                        from,
                        to
                    ),
                );
                return None;
            }
            if estimated_csr_dependency_edge_for_pair_with_tcaps(
                csr,
                pair,
                target,
                innermost_lhss,
                &forward_tcaps[from],
                reverse_tcaps[to].as_ref(),
                root_tcaps[from].as_ref(),
                &target_arg_tcap_matches[to],
            ) {
                log_dp_graph_edge(csr.trs(), pairs, from, to, innermost_lhss);
                graph[from].push(to);
            }
        }
    }
    Some(graph)
}

pub(super) fn cached_csr_dependency_pair_graph_with_context_deadline(
    stats: &DpProofStats,
    csr: &CsrTrs,
    pairs: &[DependencyPair],
    innermost_lhss: Option<&[Term]>,
    deadline: Option<Instant>,
    cancellation: &DpStrategyCancellation,
) -> Option<Vec<Vec<usize>>> {
    let mut graph = vec![Vec::<usize>::new(); pairs.len()];
    let edge_context = DpGraphEdgeContext::new(csr.trs());
    let forward_tcaps = csr_graph_forward_tcaps(csr.trs(), &edge_context, pairs);
    let reverse_tcaps = csr_graph_reverse_tcaps(csr.trs(), &edge_context, pairs);
    let root_tcaps = csr_graph_root_tcaps(csr, pairs);
    let target_arg_tcap_matches =
        csr_graph_target_arg_tcap_matches(csr.trs(), &edge_context, pairs);
    let edge_cache_snapshot = stats
        .graph_edge_cache
        .lock()
        .map(|cache| cache.clone())
        .unwrap_or_default();
    let mut pending_edge_cache_entries = Vec::new();
    let mut edge_cache_hits = 0usize;
    let mut edge_cache_misses = 0usize;
    for (from, pair) in pairs.iter().enumerate() {
        for (to, target) in pairs.iter().enumerate() {
            if strategy_timed_out(deadline) || cancellation.is_cancelled() {
                merge_dp_graph_edge_cache_entries(stats, &mut pending_edge_cache_entries);
                write_progress_event(
                    "dp-graph",
                    "timeout",
                    "csr-dependency-graph",
                    0,
                    &format!(
                        "pairs={} checked_from={} checked_to={}",
                        pairs.len(),
                        from,
                        to
                    ),
                );
                return None;
            }
            let key = DpGraphEdgeCacheKey::Csr {
                csr: csr.clone(),
                innermost_lhss: innermost_lhss.map(<[Term]>::to_vec),
                pair: pair.clone(),
                target: target.clone(),
            };
            let cached = edge_cache_snapshot.get(&key).copied();
            let (edge, cache_hit) = if let Some(edge) = cached {
                (edge, true)
            } else {
                let edge = estimated_csr_dependency_edge_for_pair_with_tcaps(
                    csr,
                    pair,
                    target,
                    innermost_lhss,
                    &forward_tcaps[from],
                    reverse_tcaps[to].as_ref(),
                    root_tcaps[from].as_ref(),
                    &target_arg_tcap_matches[to],
                );
                pending_edge_cache_entries.push((key, edge));
                (edge, false)
            };
            if cache_hit {
                edge_cache_hits += 1;
            } else {
                edge_cache_misses += 1;
            }
            if edge {
                log_dp_graph_edge(csr.trs(), pairs, from, to, innermost_lhss);
                graph[from].push(to);
            }
        }
    }
    merge_dp_graph_edge_cache_entries(stats, &mut pending_edge_cache_entries);
    log_dp_graph_edge_cache_event(
        "csr-dependency-graph",
        pairs.len(),
        &graph,
        edge_cache_hits,
        edge_cache_misses,
    );
    Some(graph)
}

pub(super) fn merge_dp_graph_edge_cache_entries(
    stats: &DpProofStats,
    pending: &mut Vec<(DpGraphEdgeCacheKey, bool)>,
) {
    if pending.is_empty() {
        return;
    }
    if let Ok(mut cache) = stats.graph_edge_cache.lock() {
        for (key, edge) in pending.drain(..) {
            cache.entry(key).or_insert(edge);
        }
    }
}

pub(super) fn log_dp_graph_edge(
    trs: &Trs,
    pairs: &[DependencyPair],
    from: usize,
    to: usize,
    innermost_lhss: Option<&[Term]>,
) {
    if std::env::var_os("FERRUM_PROGRESS_LOG_DP_EDGES").is_none() {
        return;
    }
    let pair = &pairs[from];
    let target = &pairs[to];
    write_progress_event(
        "dp-graph",
        "edge",
        "dependency-graph",
        0,
        &format!(
            "from={} to={} source_rule={} target_rule={} from_lhs={:?} from_rhs={:?} target_lhs={:?} from_rhs_root={} target_lhs_root={} strategy={:?} q_lhss={}",
            from,
            to,
            pair.source_rule(),
            target.source_rule(),
            pair.lhs(),
            pair.rhs(),
            target.lhs(),
            term_root_name(pair.rhs()),
            term_root_name(target.lhs()),
            trs.strategy(),
            innermost_lhss.map_or(0, <[Term]>::len)
        ),
    );
}

pub(super) fn term_root_name(term: &Term) -> String {
    term.root_symbol()
        .map(|symbol| symbol.as_str().to_string())
        .unwrap_or_else(|| "<var>".to_string())
}

pub(super) fn term_arguments(term: &Term) -> &[Term] {
    match term {
        Term::Var(_) => &[],
        Term::App { args, .. } => args,
    }
}

pub(crate) fn dp_graph_details(
    trs: &Trs,
    pairs: &[DependencyPair],
    innermost_lhss: Option<&[Term]>,
    graph: &[Vec<usize>],
) -> String {
    let components = strongly_connected_components(graph);
    let cyclic = components
        .iter()
        .filter(|component| component_is_cyclic(component, graph))
        .count();
    format!(
        "pairs={} edges={} components={} cyclic_components={} component_sizes={} strategy={:?} q_lhss={}",
        pairs.len(),
        graph_edge_count(graph),
        components.len(),
        cyclic,
        component_sizes(&components),
        trs.strategy(),
        innermost_lhss.map_or(0, <[Term]>::len)
    )
}

pub(super) fn graph_edge_count(graph: &[Vec<usize>]) -> usize {
    graph.iter().map(Vec::len).sum()
}

pub(super) fn component_sizes(components: &[Vec<usize>]) -> String {
    components
        .iter()
        .map(Vec::len)
        .map(|size| size.to_string())
        .collect::<Vec<_>>()
        .join(",")
}

pub(super) struct DpGraphEdgeContext {
    rules_non_empty: bool,
    rules_no_left_var: bool,
    rules_non_collapsing: bool,
    defined_symbols: BTreeSet<Symbol>,
    funas: BTreeSet<(Symbol, usize)>,
    reversed_rules: Vec<RewriteRule>,
    q_reversed_rules: Vec<RewriteRule>,
    root_gt: BTreeSet<(Option<(Symbol, usize)>, Option<(Symbol, usize)>)>,
}

impl DpGraphEdgeContext {
    pub(super) fn new(trs: &Trs) -> Self {
        let rules_non_empty = !trs.rules().is_empty();
        let rules_no_left_var = trs
            .rules()
            .iter()
            .all(|rule| !matches!(rule.lhs(), Term::Var(_)));
        let rules_non_collapsing = trs
            .rules()
            .iter()
            .all(|rule| !matches!(rule.rhs(), Term::Var(_)));
        let defined_symbols = trs.defined_symbols();
        let funas = trs
            .rules()
            .iter()
            .flat_map(|rule| {
                let mut symbols = term_funas(rule.lhs());
                symbols.extend(term_funas(rule.rhs()));
                symbols
            })
            .collect();
        let q_reversed_rules = reverse_rules(trs.rules());
        let reversed_rules = if rules_non_collapsing {
            q_reversed_rules.clone()
        } else {
            Vec::new()
        };
        let root_gt = ceta_root_gt_closure(trs.rules());
        Self {
            rules_non_empty,
            rules_no_left_var,
            rules_non_collapsing,
            defined_symbols,
            funas,
            reversed_rules,
            q_reversed_rules,
            root_gt,
        }
    }
}

pub(super) fn estimated_dependency_edge_for_pair(
    trs: &Trs,
    active_trs: &Trs,
    edge_context: &DpGraphEdgeContext,
    pair: &DependencyPair,
    target: &DependencyPair,
    innermost_lhss: Option<&[Term]>,
    pair_usable_rules: Option<&[RewriteRule]>,
    precomputed_q_context: Option<(&CetaQIEDGSourceContext, &CetaQIEDGTargetContext)>,
) -> bool {
    // Rewriting between dependency-pair steps happens strictly below the
    // marked root.  Hence a marked (or otherwise R-undefined) RHS root cannot
    // turn into a different target root.  Test this before the substantially
    // more expensive innermost CAP/Q estimators; large generated systems may
    // contain hundreds of pairs spread across many marked call families.
    if let (Some(source_root), Some(target_root)) =
        (pair.rhs().root_symbol(), target.lhs().root_symbol())
        && source_root != target_root
        && !edge_context.defined_symbols.contains(source_root)
    {
        return false;
    }
    if trs.strategy() == RewriteStrategy::Innermost
        && let Some(q_lhss) = innermost_lhss
    {
        let source_lhs = trs.rules().get(pair.source_rule()).map(RewriteRule::lhs);
        let ceta_edge = if let Some((source, target)) = precomputed_q_context {
            ceta_q_iedg_edge_from_contexts(source, target, q_lhss)
        } else if pair_usable_rules.is_some() {
            ceta_q_iedg_edge_with_precomputed_reversed_usable_rules(
                pair,
                target,
                q_lhss,
                active_trs.rules(),
                &edge_context.q_reversed_rules,
            )
        } else {
            ceta_q_iedg_edge_with_usable_rules(pair, target, q_lhss, active_trs.rules(), None)
        };
        if ceta_edge {
            return true;
        }
        if innermost_dependency_edge(pair.rhs(), target.lhs(), source_lhs, q_lhss) {
            return true;
        }
        // IEDG alone over-approximates the innermost dependency graph
        // (Dependency_Graph.IEDG). CeTA intersects it with additional CAP and
        // nonreachability estimates for precision, but disagreement with our
        // reimplementation of those optional filters must never erase an
        // IEDG edge accepted by the checker.
        return one_step_innermost_dependency_edge(
            active_trs.rules(),
            pair.rhs(),
            target.lhs(),
            source_lhs,
            q_lhss,
        );
    }
    if trs.strategy() == RewriteStrategy::Innermost {
        if old_cap_estimated_dependency_edge(active_trs, pair.rhs(), target.lhs())
            || ceta_estimated_dependency_edge_cached(
                active_trs,
                edge_context,
                pair.rhs(),
                target.lhs(),
            )
        {
            return true;
        }
        let source_lhs = trs.rules().get(pair.source_rule()).map(RewriteRule::lhs);
        let direct_graph_safe = source_lhs.is_some_and(|lhs| {
            proper_defined_rhs_subterms_are_safe_for_target(
                pair.rhs(),
                target.lhs(),
                lhs,
                &edge_context.defined_symbols,
                trs.rules(),
            )
        });
        if direct_graph_safe {
            let q_lhss = trs
                .rules()
                .iter()
                .map(RewriteRule::lhs)
                .cloned()
                .collect::<Vec<_>>();
            return innermost_dependency_edge(pair.rhs(), target.lhs(), source_lhs, &q_lhss);
        }
        return false;
    }
    ceta_estimated_dependency_edge_cached(active_trs, edge_context, pair.rhs(), target.lhs())
}

/// Check whether dependency pairs absent from a retained exact graph can be
/// added as acyclic singleton components without changing any retained cyclic
/// component.
///
/// The retained graph tells us nothing about edges between its old SCCs.  We
/// therefore use a deliberately sufficient (rather than necessary) test: the
/// new-pair subgraph must be acyclic, and new pairs may have edges on at most
/// one side of the old graph.  Consequently no path through a new pair can
/// close a cycle containing an old pair.  The resulting complete graph proof
/// is still checked independently by CeTA before it can be promoted.
pub(crate) fn exact_graph_extra_pairs_are_acyclic(
    trs: &Trs,
    active_rules: &[RewriteRule],
    pairs: &[DependencyPair],
    old_pair: &[bool],
    innermost_lhss: Option<&[Term]>,
) -> bool {
    if pairs.len() != old_pair.len() {
        return false;
    }
    let extras = old_pair
        .iter()
        .enumerate()
        .filter_map(|(index, old)| (!old).then_some(index))
        .collect::<Vec<_>>();
    if extras.is_empty() {
        return true;
    }
    let active_trs = Trs::new_with_strategy(
        trs.name().map(str::to_owned),
        trs.variables().clone(),
        active_rules.to_vec(),
        trs.strategy(),
    );
    let edge_context = DpGraphEdgeContext::new(&active_trs);
    let edge = |from: usize, to: usize| {
        estimated_dependency_edge_for_pair(
            trs,
            &active_trs,
            &edge_context,
            &pairs[from],
            &pairs[to],
            innermost_lhss,
            innermost_lhss.map(|_| active_trs.rules()),
            None,
        )
    };

    let mut has_old_to_extra = false;
    let mut has_extra_to_old = false;
    let mut extra_graph = vec![Vec::new(); extras.len()];
    for (extra_position, &extra) in extras.iter().enumerate() {
        for (other_position, &other) in extras.iter().enumerate() {
            if edge(extra, other) {
                extra_graph[extra_position].push(other_position);
            }
        }
        for (index, old) in old_pair.iter().copied().enumerate() {
            if !old {
                continue;
            }
            has_old_to_extra |= edge(index, extra);
            has_extra_to_old |= edge(extra, index);
        }
    }
    if has_old_to_extra && has_extra_to_old {
        return false;
    }
    strongly_connected_components(&extra_graph)
        .iter()
        .all(|component| !component_is_cyclic(component, &extra_graph))
}

pub(super) fn estimated_csr_dependency_edge_for_pair_with_tcaps(
    csr: &CsrTrs,
    pair: &DependencyPair,
    target: &DependencyPair,
    _innermost_lhss: Option<&[Term]>,
    forward_tcap: &GroundContext,
    reverse_tcap: Option<&GroundContext>,
    root_tcap: Option<&GroundContext>,
    target_arg_tcap_matches: &[Vec<bool>],
) -> bool {
    let source = pair.rhs();
    let target_lhs = target.lhs();
    // The replacement map in the original CPF problem does not mention the
    // fresh improved-CS-DP unhiding symbol.  CeTA's `mu_of` therefore gives
    // that symbol the default, fully active replacement map when checking a
    // dependency graph.  The materialized Ferrum DP state deliberately pins
    // the same symbol to a frozen argument for the transformation processors,
    // so using that internal map here can incorrectly delete required U
    // edges.  For a U-rooted source, retain the map-independent CAP filters
    // and conservatively skip our replacement-map refinements.  The final
    // decomposition is still checked independently by CeTA.
    let fresh_unhiding_source = source.root_symbol() == Some(&fresh_unhiding_symbol(csr.trs()))
        && csr.replacement_map().allowed_positions(&fresh_unhiding_symbol(csr.trs())).is_none();
    if csr_undefined_root_mismatch_no_edge(csr, source, target_lhs)
        || (!fresh_unhiding_source
            && (csr_inactive_arg_no_edge(csr, source, target_lhs)
                || csr_frozen_root_no_edge(csr, source, target_lhs)))
        || csr_lpar08_cap_ren_no_edge(csr, source, target_lhs)
        || !ground_context_matches(forward_tcap, target_lhs)
        || reverse_tcap.is_some_and(|context| !ground_context_matches(context, source))
        || root_tcap.is_some_and(|context| !ground_context_matches(context, target_lhs))
        || csr_shared_inactive_arg_no_edge(csr, source, target_lhs)
        || csr_shared_source_inactive_arg_no_edge_with_matches(
            csr,
            source,
            target_lhs,
            target_arg_tcap_matches,
        )
    {
        return false;
    }
    true
}

/// Rewriting below a constructor-like DP root cannot change that root.
///
/// Marked symbols and the fresh improved-CS-DP unhiding symbol are not
/// defined by the original CSR.  If such a right-hand-side root differs from
/// the next pair's left-hand-side root, no intervening context-sensitive
/// rewrite sequence can create an edge.  Keeping this elementary filter
/// explicit avoids losing the fact when a later CAP approximation replaces
/// active arguments by variables.
pub(super) fn csr_undefined_root_mismatch_no_edge(
    csr: &CsrTrs,
    source: &Term,
    target: &Term,
) -> bool {
    let (Some(source_root), Some(target_root)) = (source.root_symbol(), target.root_symbol())
    else {
        return false;
    };
    source_root != target_root && !csr.trs().defined_symbols().contains(source_root)
}

/// The graph approximation from Alarcón et al. (LPAR'08, Sect. 4.1).
///
/// `Cap_mu` replaces active defined calls, while `Ren_mu` gives every active
/// variable occurrence a fresh name.  Crucially, variables below frozen
/// positions retain their sharing.  The older ground-context CAP above loses
/// that information and therefore merges several independent SCCs in the
/// LISTUTILITIES family.
pub(super) fn csr_lpar08_cap_ren_no_edge(csr: &CsrTrs, source: &Term, target: &Term) -> bool {
    fn cap_ren(
        csr: &CsrTrs,
        defined: &BTreeSet<Symbol>,
        term: &Term,
        active: bool,
        next_fresh: &mut usize,
    ) -> Term {
        if active {
            if let Term::App { symbol, .. } = term {
                // Marked DP symbols are constructors of the DP problem; CAP
                // only replaces roots defined by the original rule system.
                if defined.contains(symbol) {
                    let fresh = Term::var(format!("__csr_lpar_cap_{}", *next_fresh));
                    *next_fresh += 1;
                    return fresh;
                }
            }
        }
        match term {
            Term::Var(_variable) if active => {
                let fresh = Term::var(format!("__csr_lpar_ren_{}", *next_fresh));
                *next_fresh += 1;
                fresh
            }
            Term::Var(variable) => Term::var(format!("__csr_lpar_keep_{}", variable.as_str())),
            Term::App { symbol, args } => Term::app(
                symbol.as_str(),
                args.iter()
                    .enumerate()
                    .map(|(index, arg)| {
                        let fresh_unhiding = symbol == &fresh_unhiding_symbol(csr.trs())
                            && csr.replacement_map().allowed_positions(symbol).is_none();
                        cap_ren(
                            csr,
                            defined,
                            arg,
                            active
                                && (fresh_unhiding
                                    || csr_symbol_allows_argument(csr, symbol, index)),
                            next_fresh,
                        )
                    })
                    .collect(),
            ),
        }
    }

    let mut next_fresh = 0;
    let left = cap_ren(
        csr,
        &csr.trs().defined_symbols(),
        source,
        true,
        &mut next_fresh,
    );
    let right = standardize_variables_apart(target, "__csr_lpar_target");
    !unifies(&left, &right)
}

pub(super) fn csr_graph_forward_tcaps(
    trs: &Trs,
    edge_context: &DpGraphEdgeContext,
    pairs: &[DependencyPair],
) -> Vec<GroundContext> {
    pairs
        .iter()
        .map(|pair| {
            ceta_tcap_with_left_var_status(
                trs,
                trs.rules(),
                edge_context.rules_no_left_var,
                false,
                pair.rhs(),
            )
        })
        .collect()
}

pub(super) fn csr_graph_reverse_tcaps(
    trs: &Trs,
    edge_context: &DpGraphEdgeContext,
    pairs: &[DependencyPair],
) -> Vec<Option<GroundContext>> {
    pairs
        .iter()
        .map(|pair| {
            edge_context.rules_non_collapsing.then(|| {
                ceta_tcap_with_left_var_status(
                    trs,
                    &edge_context.reversed_rules,
                    true,
                    false,
                    pair.lhs(),
                )
            })
        })
        .collect()
}

pub(super) fn csr_graph_root_tcaps(
    csr: &CsrTrs,
    pairs: &[DependencyPair],
) -> Vec<Option<GroundContext>> {
    pairs
        .iter()
        .map(|pair| csr_root_tcap_context(csr, pair.rhs()))
        .collect()
}

pub(super) fn csr_graph_target_arg_tcap_matches(
    trs: &Trs,
    edge_context: &DpGraphEdgeContext,
    pairs: &[DependencyPair],
) -> Vec<Vec<Vec<bool>>> {
    pairs
        .iter()
        .map(|pair| csr_target_arg_tcap_matches(trs, edge_context, pair.lhs()))
        .collect()
}

pub(super) fn csr_target_arg_tcap_matches(
    trs: &Trs,
    edge_context: &DpGraphEdgeContext,
    target: &Term,
) -> Vec<Vec<bool>> {
    let Term::App { args, .. } = target else {
        return Vec::new();
    };
    args.iter()
        .map(|left| {
            args.iter()
                .map(|right| ceta_tcap_match_cached(trs, edge_context, left, right))
                .collect()
        })
        .collect()
}

pub(super) fn csr_inactive_arg_no_edge(csr: &CsrTrs, source: &Term, target: &Term) -> bool {
    let (
        Term::App {
            symbol: source_symbol,
            args: source_args,
        },
        Term::App {
            symbol: target_symbol,
            args: target_args,
        },
    ) = (source, target)
    else {
        return false;
    };
    if csr.trs().defined_symbols().contains(source_symbol) {
        return false;
    }
    if source_symbol != target_symbol || source_args.len() != target_args.len() {
        return true;
    }
    source_args
        .iter()
        .zip(target_args)
        .enumerate()
        .any(|(index, (source_arg, target_arg))| {
            !csr_symbol_allows_argument(csr, source_symbol, index)
                && !ground_context_matches(&term_ground_context(source_arg), target_arg)
        })
}

pub(super) fn csr_frozen_root_no_edge(csr: &CsrTrs, source: &Term, target: &Term) -> bool {
    let Term::App { symbol, args } = source else {
        return false;
    };
    if csr.trs().defined_symbols().contains(symbol)
        || args
            .iter()
            .enumerate()
            .any(|(index, _)| csr_symbol_allows_argument(csr, symbol, index))
    {
        return false;
    }
    let source = standardize_variables_apart(source, "csr_frozen_from");
    let target = standardize_variables_apart(target, "csr_frozen_to");
    !unifies(&source, &target)
}

pub(super) fn csr_root_tcap_context(csr: &CsrTrs, source: &Term) -> Option<GroundContext> {
    let Term::App { symbol, args } = source else {
        return None;
    };
    if csr.trs().defined_symbols().contains(symbol) {
        return None;
    }
    let fresh_unhiding = symbol == &fresh_unhiding_symbol(csr.trs())
        && csr.replacement_map().allowed_positions(symbol).is_none();
    Some(GroundContext::Fun(
        symbol.clone(),
        args.iter()
            .enumerate()
            .map(|(index, arg)| {
                if fresh_unhiding || csr_symbol_allows_argument(csr, symbol, index) {
                    ceta_tcap(csr.trs(), csr.trs().rules(), false, arg)
                } else {
                    term_ground_context(arg)
                }
            })
            .collect(),
    ))
}

pub(super) fn csr_shared_inactive_arg_no_edge(csr: &CsrTrs, source: &Term, target: &Term) -> bool {
    let (
        Term::App {
            symbol: source_symbol,
            args: source_args,
        },
        Term::App {
            symbol: target_symbol,
            args: target_args,
        },
    ) = (source, target)
    else {
        return false;
    };
    if csr.trs().defined_symbols().contains(source_symbol)
        || source_symbol != target_symbol
        || source_args.len() != target_args.len()
    {
        return false;
    }
    for left_index in 0..source_args.len() {
        if csr_symbol_allows_argument(csr, source_symbol, left_index) {
            continue;
        }
        for right_index in 0..source_args.len() {
            if left_index == right_index
                || csr_symbol_allows_argument(csr, source_symbol, right_index)
                || source_args[left_index] != source_args[right_index]
            {
                continue;
            }
            let left = standardize_variables_apart(&target_args[left_index], "csr_shared_left");
            let right = standardize_variables_apart(&target_args[right_index], "csr_shared_right");
            if !unifies(&left, &right) {
                return true;
            }
        }
    }
    false
}

pub(super) fn csr_shared_source_inactive_arg_no_edge_with_matches(
    csr: &CsrTrs,
    source: &Term,
    target: &Term,
    target_arg_tcap_matches: &[Vec<bool>],
) -> bool {
    let (
        Term::App {
            symbol: source_symbol,
            args: source_args,
        },
        Term::App {
            symbol: target_symbol,
            args: target_args,
        },
    ) = (source, target)
    else {
        return false;
    };
    if csr.trs().defined_symbols().contains(source_symbol)
        || source_symbol != target_symbol
        || source_args.len() != target_args.len()
    {
        return false;
    }
    for frozen_index in 0..source_args.len() {
        if csr_symbol_allows_argument(csr, source_symbol, frozen_index) {
            continue;
        }
        for other_index in 0..source_args.len() {
            if frozen_index == other_index || source_args[frozen_index] != source_args[other_index]
            {
                continue;
            }
            if !target_arg_tcap_matches[frozen_index][other_index] {
                return true;
            }
        }
    }
    false
}

pub(super) fn term_ground_context(term: &Term) -> GroundContext {
    match term {
        Term::Var(_) => GroundContext::Hole,
        Term::App { symbol, args } => GroundContext::Fun(
            symbol.clone(),
            args.iter().map(term_ground_context).collect(),
        ),
    }
}

pub(super) fn csr_symbol_allows_argument(csr: &CsrTrs, symbol: &Symbol, index: usize) -> bool {
    csr.replacement_map().is_allowed(symbol, index)
        || symbol.as_str().strip_suffix('#').is_some_and(|unmarked| {
            csr.replacement_map()
                .is_allowed(&Symbol::new(unmarked), index)
        })
}

pub(super) fn old_cap_estimated_dependency_edge(trs: &Trs, rhs: &Term, target_lhs: &Term) -> bool {
    let mut cap_index = 0usize;
    let capped_rhs = cap_defined_subterms(rhs, &trs.defined_symbols(), true, &mut cap_index);
    let mut ren_index = 0usize;
    let left = rename_variable_occurrences(&capped_rhs, "from", &mut ren_index);
    let right = standardize_variables_apart(target_lhs, "to");
    unifies(&left, &right)
}

pub(super) fn one_step_innermost_dependency_edge(
    rules: &[RewriteRule],
    rhs: &Term,
    target_lhs: &Term,
    source_lhs: Option<&Term>,
    q_lhss: &[Term],
) -> bool {
    for (position, redex) in positions_with_subterms(rhs) {
        if position.is_empty()
            || !term_arguments(redex)
                .iter()
                .all(|argument| term_is_q_normal(argument, q_lhss))
        {
            continue;
        }
        for rule in rules {
            let rule_lhs = prefix_term_variables(rule.lhs(), "__edge_rule_");
            let rule_rhs = prefix_term_variables(rule.rhs(), "__edge_rule_");
            let mut substitution = BTreeMap::new();
            if !unify_terms(&rule_lhs, redex, &mut substitution) {
                continue;
            }
            let result = apply_substitution(&rule_rhs, &substitution);
            let instantiated_rhs = apply_substitution(rhs, &substitution);
            let one_based_position = position.iter().map(|index| index + 1).collect::<Vec<_>>();
            let Some(rewritten) =
                replace_subterm_at_position(&instantiated_rhs, &one_based_position, &result)
            else {
                continue;
            };
            let instantiated_source_lhs =
                source_lhs.map(|lhs| apply_substitution(lhs, &substitution));
            if innermost_dependency_edge(
                &rewritten,
                target_lhs,
                instantiated_source_lhs.as_ref(),
                q_lhss,
            ) {
                return true;
            }
        }
    }
    false
}

#[cfg(test)]
pub(super) fn ceta_estimated_dependency_edge(trs: &Trs, rhs: &Term, target_lhs: &Term) -> bool {
    let edge_context = DpGraphEdgeContext::new(trs);
    ceta_estimated_dependency_edge_cached(trs, &edge_context, rhs, target_lhs)
}

pub(super) fn ceta_estimated_dependency_edge_cached(
    trs: &Trs,
    edge_context: &DpGraphEdgeContext,
    rhs: &Term,
    target_lhs: &Term,
) -> bool {
    if !ceta_tcap_match_cached(trs, edge_context, rhs, target_lhs) {
        return false;
    }
    if !ceta_reverse_tcap_match_cached(trs, edge_context, target_lhs, rhs) {
        return false;
    }
    !ceta_nonreachable_gtcap_cached(trs, edge_context, rhs, target_lhs)
}

pub(crate) fn ceta_tcap_dependency_edge_for_rules(
    trs: &Trs,
    rhs: &Term,
    target_lhs: &Term,
) -> bool {
    let edge_context = DpGraphEdgeContext::new(trs);
    ceta_tcap_match_cached(trs, &edge_context, rhs, target_lhs)
}

#[cfg(test)]
pub(super) fn estimated_dependency_edge(trs: &Trs, rhs: &Term, target_lhs: &Term) -> bool {
    ceta_estimated_dependency_edge(trs, rhs, target_lhs)
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub(super) enum GroundContext {
    Hole,
    Fun(Symbol, Vec<GroundContext>),
}

pub(super) fn ceta_tcap_match_cached(
    trs: &Trs,
    edge_context: &DpGraphEdgeContext,
    from: &Term,
    to: &Term,
) -> bool {
    ground_context_matches(
        &ceta_tcap_with_left_var_status(
            trs,
            trs.rules(),
            edge_context.rules_no_left_var,
            false,
            from,
        ),
        to,
    )
}

pub(super) fn ceta_reverse_tcap_match_cached(
    trs: &Trs,
    edge_context: &DpGraphEdgeContext,
    from: &Term,
    to: &Term,
) -> bool {
    if !edge_context.rules_non_collapsing {
        return true;
    }
    ground_context_matches(
        &ceta_tcap_with_left_var_status(trs, &edge_context.reversed_rules, true, false, from),
        to,
    )
}

pub(super) fn ceta_tcap(
    trs: &Trs,
    rules: &[RewriteRule],
    force_hole: bool,
    term: &Term,
) -> GroundContext {
    let rules_no_left_var = rules.iter().all(|rule| !matches!(rule.lhs(), Term::Var(_)));
    ceta_tcap_with_left_var_status(trs, rules, rules_no_left_var, force_hole, term)
}

pub(super) fn ceta_tcap_with_left_var_status(
    trs: &Trs,
    rules: &[RewriteRule],
    rules_no_left_var: bool,
    force_hole: bool,
    term: &Term,
) -> GroundContext {
    if force_hole || !rules_no_left_var {
        return GroundContext::Hole;
    }
    ceta_tcap_rm2(trs, rules, term)
}

pub(super) fn ceta_tcap_rm2(trs: &Trs, rules: &[RewriteRule], term: &Term) -> GroundContext {
    match term {
        Term::Var(_) => GroundContext::Hole,
        Term::App { symbol, args } => {
            let context = GroundContext::Fun(
                symbol.clone(),
                args.iter()
                    .map(|arg| ceta_tcap_rm2(trs, rules, arg))
                    .collect(),
            );
            if rules
                .iter()
                .filter(|rule| term_has_same_root_arity(term, rule.lhs()))
                .any(|rule| ground_context_matches(&context, rule.lhs()))
            {
                GroundContext::Hole
            } else {
                context
            }
        }
    }
}

pub(super) fn term_has_same_root_arity(left: &Term, right: &Term) -> bool {
    match (left, right) {
        (
            Term::App {
                symbol: left_symbol,
                args: left_args,
            },
            Term::App {
                symbol: right_symbol,
                args: right_args,
            },
        ) => left_symbol == right_symbol && left_args.len() == right_args.len(),
        _ => false,
    }
}

pub(super) fn ground_context_matches(context: &GroundContext, term: &Term) -> bool {
    let mut variable_contexts = BTreeMap::new();
    ground_context_matches_with_bindings(context, term, &mut variable_contexts)
}

pub(super) fn ground_context_matches_with_bindings(
    context: &GroundContext,
    term: &Term,
    variable_contexts: &mut BTreeMap<Variable, GroundContext>,
) -> bool {
    match (context, term) {
        (GroundContext::Hole, _) => true,
        (GroundContext::Fun(context_symbol, context_args), Term::App { symbol, args }) => {
            context_symbol == symbol
                && context_args.len() == args.len()
                && context_args.iter().zip(args).all(|(context_arg, arg)| {
                    ground_context_matches_with_bindings(context_arg, arg, variable_contexts)
                })
        }
        (GroundContext::Fun(_, _), Term::Var(variable)) => {
            if let Some(previous) = variable_contexts.get(variable) {
                ground_contexts_unifiable(previous, context)
            } else {
                variable_contexts.insert(variable.clone(), context.clone());
                true
            }
        }
    }
}

pub(super) fn ground_contexts_unifiable(left: &GroundContext, right: &GroundContext) -> bool {
    match (left, right) {
        (GroundContext::Hole, _) | (_, GroundContext::Hole) => true,
        (
            GroundContext::Fun(left_symbol, left_args),
            GroundContext::Fun(right_symbol, right_args),
        ) => {
            left_symbol == right_symbol
                && left_args.len() == right_args.len()
                && left_args
                    .iter()
                    .zip(right_args)
                    .all(|(left_arg, right_arg)| ground_contexts_unifiable(left_arg, right_arg))
        }
    }
}

pub(super) fn ceta_nonreachable_gtcap_cached(
    trs: &Trs,
    edge_context: &DpGraphEdgeContext,
    source_rhs: &Term,
    target_lhs: &Term,
) -> bool {
    let relevant_pairs = ceta_rd_impl(
        trs,
        &edge_context.root_gt,
        edge_context.rules_non_empty,
        edge_context.rules_no_left_var,
        source_rhs,
        target_lhs,
    );
    relevant_pairs.iter().any(|(left, right)| {
        ceta_nonreach(
            trs,
            &edge_context.root_gt,
            edge_context.rules_non_empty,
            edge_context.rules_no_left_var,
            left,
            right,
        )
    }) || edge_context.rules_no_left_var
        && edge_context.rules_non_empty
        && ceta_nonlinear_var_nonreach(&edge_context.root_gt, &edge_context.funas, &relevant_pairs)
}

pub(super) fn ceta_root_gt_closure(
    rules: &[RewriteRule],
) -> BTreeSet<(Option<(Symbol, usize)>, Option<(Symbol, usize)>)> {
    type Root = Option<(Symbol, usize)>;
    let mut adjacency = BTreeMap::<Root, BTreeSet<Root>>::new();
    let mut sources = BTreeSet::new();
    for rule in rules {
        let source = term_root_arity(rule.lhs());
        let target = term_root_arity(rule.rhs());
        sources.insert(source.clone());
        adjacency.entry(source).or_default().insert(target);
    }

    let mut closure = BTreeSet::new();
    for source in sources {
        let mut pending = adjacency
            .get(&source)
            .into_iter()
            .flat_map(|targets| targets.iter().cloned())
            .collect::<Vec<_>>();
        let mut reachable = BTreeSet::new();
        while let Some(target) = pending.pop() {
            if !reachable.insert(target.clone()) {
                continue;
            }
            if let Some(next) = adjacency.get(&target) {
                pending.extend(next.iter().cloned());
            }
        }
        closure.extend(reachable.into_iter().map(|target| (source.clone(), target)));
    }
    closure
}

pub(super) fn term_root_arity(term: &Term) -> Option<(Symbol, usize)> {
    match term {
        Term::Var(_) => None,
        Term::App { symbol, args } => Some((symbol.clone(), args.len())),
    }
}

pub(super) fn ceta_gt_fun(
    root_gt: &BTreeSet<(Option<(Symbol, usize)>, Option<(Symbol, usize)>)>,
    left: Option<(Symbol, usize)>,
    right: Option<(Symbol, usize)>,
) -> bool {
    root_gt.contains(&(left, right))
}

pub(super) fn ceta_gt_term(
    trs: &Trs,
    root_gt: &BTreeSet<(Option<(Symbol, usize)>, Option<(Symbol, usize)>)>,
    rules_non_empty: bool,
    rules_no_left_var: bool,
    source: &Term,
    target: &Term,
) -> bool {
    if !rules_non_empty {
        return false;
    }
    let root1 = term_root_arity(source);
    let root2 = term_root_arity(target);
    let may_reach_by_root = matches!(source, Term::Var(_))
        || matches!(target, Term::Var(_))
        || ceta_gt_fun(root_gt, None, None)
        || ceta_gt_fun(root_gt, root1.clone(), root2.clone())
        || ceta_gt_fun(root_gt, root1.clone(), None)
        || ceta_gt_fun(root_gt, None, root2);
    if !may_reach_by_root {
        return false;
    }
    if !rules_no_left_var {
        return true;
    }
    let Some(root) = root1 else {
        return true;
    };
    let cap = ceta_tcap(trs, trs.rules(), false, source);
    trs.rules()
        .iter()
        .filter(|rule| term_root_arity(rule.lhs()).as_ref() == Some(&root))
        .any(|rule| ground_context_matches(&cap, rule.lhs()))
}

pub(super) fn ceta_rd_impl(
    trs: &Trs,
    root_gt: &BTreeSet<(Option<(Symbol, usize)>, Option<(Symbol, usize)>)>,
    rules_non_empty: bool,
    rules_no_left_var: bool,
    source: &Term,
    target: &Term,
) -> Vec<(Term, Term)> {
    match (source, target) {
        (
            Term::App {
                symbol: source_symbol,
                args: source_args,
            },
            Term::App {
                symbol: target_symbol,
                args: target_args,
            },
        ) if source_symbol == target_symbol
            && source_args.len() == target_args.len()
            && !ceta_gt_term(
                trs,
                root_gt,
                rules_non_empty,
                rules_no_left_var,
                source,
                target,
            ) =>
        {
            source_args
                .iter()
                .zip(target_args)
                .flat_map(|(source_arg, target_arg)| {
                    ceta_rd_impl(
                        trs,
                        root_gt,
                        rules_non_empty,
                        rules_no_left_var,
                        source_arg,
                        target_arg,
                    )
                })
                .collect()
        }
        _ => vec![(source.clone(), target.clone())],
    }
}

pub(super) fn ceta_nonreach(
    trs: &Trs,
    root_gt: &BTreeSet<(Option<(Symbol, usize)>, Option<(Symbol, usize)>)>,
    rules_non_empty: bool,
    rules_no_left_var: bool,
    source: &Term,
    target: &Term,
) -> bool {
    match (source, target) {
        (Term::Var(_), _) | (Term::App { .. }, Term::Var(_)) => false,
        (
            Term::App {
                symbol: source_symbol,
                args: source_args,
            },
            Term::App {
                symbol: target_symbol,
                args: target_args,
            },
        ) => {
            (source_symbol != target_symbol || source_args.len() != target_args.len())
                && !ceta_gt_term(
                    trs,
                    root_gt,
                    rules_non_empty,
                    rules_no_left_var,
                    source,
                    target,
                )
        }
    }
}

pub(super) fn ceta_nonlinear_var_nonreach(
    root_gt: &BTreeSet<(Option<(Symbol, usize)>, Option<(Symbol, usize)>)>,
    funas: &BTreeSet<(Symbol, usize)>,
    pairs: &[(Term, Term)],
) -> bool {
    let mut targets_by_variable: BTreeMap<Variable, Vec<&Term>> = BTreeMap::new();
    for (source, target) in pairs {
        if let Term::Var(variable) = source {
            targets_by_variable
                .entry(variable.clone())
                .or_default()
                .push(target);
        }
    }
    targets_by_variable.values().any(|targets| {
        targets.len() > 1
            && funas.iter().all(|root| {
                !ceta_gt_fun(root_gt, Some(root.clone()), None)
                    && targets.iter().any(|target| {
                        !matches!(target, Term::Var(_))
                            && term_funas(target).is_subset(&funas)
                            && term_root_arity(target).as_ref() != Some(root)
                            && !ceta_gt_fun(root_gt, Some(root.clone()), term_root_arity(target))
                    })
            })
    })
}

pub(super) fn term_funas(term: &Term) -> BTreeSet<(Symbol, usize)> {
    let mut funas = BTreeSet::new();
    collect_term_funas(term, &mut funas);
    funas
}

pub(super) fn collect_term_funas(term: &Term, funas: &mut BTreeSet<(Symbol, usize)>) {
    match term {
        Term::Var(_) => {}
        Term::App { symbol, args } => {
            funas.insert((symbol.clone(), args.len()));
            for arg in args {
                collect_term_funas(arg, funas);
            }
        }
    }
}

pub(super) fn innermost_dependency_edge(
    rhs: &Term,
    target_lhs: &Term,
    source_lhs: Option<&Term>,
    q_lhss: &[Term],
) -> bool {
    let left = standardize_variables_apart(rhs, "from");
    let right = standardize_variables_apart(target_lhs, "to");
    let mut substitution = BTreeMap::new();
    if !unify_terms(&left, &right, &mut substitution) {
        return false;
    }
    if let Some(source_lhs) = source_lhs {
        let source_lhs = standardize_variables_apart(source_lhs, "from");
        if !proper_subterms_are_not_guaranteed_q_redexes(&source_lhs, &substitution, q_lhss) {
            return false;
        }
    }
    proper_subterms_are_not_guaranteed_q_redexes(&right, &substitution, q_lhss)
}

pub(super) fn proper_subterms_are_not_guaranteed_q_redexes(
    term: &Term,
    substitution: &BTreeMap<Variable, Term>,
    q_lhss: &[Term],
) -> bool {
    positions_with_subterms(term)
        .into_iter()
        .filter(|(position, _)| !position.is_empty())
        .all(|(_, subterm)| {
            let instantiated = apply_substitution(subterm, substitution);
            !term_is_guaranteed_q_redex(&instantiated, q_lhss)
        })
}

pub(super) fn term_is_guaranteed_q_redex(term: &Term, q_lhss: &[Term]) -> bool {
    q_lhss
        .iter()
        .any(|lhs| pattern_matches_with_fresh_variables(lhs, term))
}

pub(super) fn pattern_matches_with_fresh_variables(pattern: &Term, term: &Term) -> bool {
    let pattern = standardize_variables_apart(pattern, "q");
    let mut substitution = BTreeMap::new();
    match_term(&pattern, term, &mut substitution)
}

pub(super) fn proper_defined_rhs_subterms_are_safe_for_target(
    term: &Term,
    target_lhs: &Term,
    source_lhs: &Term,
    defined_symbols: &BTreeSet<Symbol>,
    rules: &[RewriteRule],
) -> bool {
    positions_with_subterms(term)
        .into_iter()
        .filter(|(position, _)| !position.is_empty())
        .filter(|(_, subterm)| term_root_is_defined(subterm, defined_symbols))
        .all(|(position, subterm)| {
            target_position_is_under_linear_variable(target_lhs, &position)
                || defined_rhs_subterms_are_innermost_normal(
                    subterm,
                    source_lhs,
                    defined_symbols,
                    rules,
                )
                || defined_rhs_subterms_are_ground_normal(subterm, defined_symbols, rules)
        })
}

pub(super) fn target_position_is_under_linear_variable(term: &Term, position: &[usize]) -> bool {
    target_variable_at_position(term, position)
        .is_some_and(|variable| variable_occurrences(term, variable) == 1)
}

pub(super) fn target_variable_at_position<'a>(
    term: &'a Term,
    position: &[usize],
) -> Option<&'a Variable> {
    if position.is_empty() {
        return match term {
            Term::Var(variable) => Some(variable),
            Term::App { .. } => None,
        };
    }
    match term {
        Term::Var(variable) => Some(variable),
        Term::App { args, .. } => position
            .first()
            .and_then(|index| args.get(*index))
            .and_then(|arg| target_variable_at_position(arg, &position[1..])),
    }
}
