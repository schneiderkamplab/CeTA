//! Shared semantic-labeling model construction and materialization.
//!
//! Processor scheduling lives in `processors`; this module only computes and
//! validates one semantic-labeling transition.

use super::*;

#[cfg(test)]
mod conditional_model_tests {
    use super::*;

    #[test]
    fn finite_model_if_equal_uses_carrier_values_and_selected_branch() {
        use SlArithmeticFunction::{Argument, Constant, IfEqual, Sum};
        let function = IfEqual(Box::new([
            Sum(vec![Argument(0), Constant(2)]),
            Constant(1),
            Constant(3),
            Constant(0),
        ]));
        assert_eq!(function.eval(&[1], 2), Some(1));
        assert_eq!(function.eval(&[0], 2), Some(0));
        assert_eq!(function.eval(&[], 2), None);
        assert_eq!(function.eval(&[1], 0), None);
        let encoded = serde_json::to_string(&function).unwrap();
        assert_eq!(serde_json::from_str::<SlArithmeticFunction>(&encoded).unwrap(), function);
    }
}

impl SlArithmeticFunction {
    pub(crate) fn eval(&self, args: &[usize], carrier_size: usize) -> Option<usize> {
        if carrier_size == 0 {
            return None;
        }
        match self {
            SlArithmeticFunction::IfEqual(parts) => {
                let equal = parts[0].eval(args, carrier_size)? == parts[1].eval(args, carrier_size)?;
                parts[if equal { 2 } else { 3 }].eval(args, carrier_size)
            }
            SlArithmeticFunction::Constant(value) => Some(value % carrier_size),
            SlArithmeticFunction::Argument(index) => {
                args.get(*index).map(|value| value % carrier_size)
            }
            SlArithmeticFunction::Sum(items) => {
                let mut value = 0usize;
                for item in items {
                    value = (value + item.eval(args, carrier_size)?) % carrier_size;
                }
                Some(value)
            }
            SlArithmeticFunction::Product(items) => {
                let mut value = 1usize;
                for item in items {
                    value = (value * item.eval(args, carrier_size)?) % carrier_size;
                }
                Some(value)
            }
        }
    }
}

pub(crate) fn distinguished_constant_semantic_labeling_candidates(
    base_model: &SemanticLabelingModel,
    symbols: &[(Symbol, usize)],
) -> Vec<SemanticLabelingModel> {
    let constants = symbols
        .iter()
        .filter_map(|(symbol, arity)| (*arity == 0).then_some(symbol))
        .collect::<Vec<_>>();
    constants
        .into_iter()
        .map(|distinguished| {
            let mut model = base_model.clone();
            model
                .interpretations
                .extend(symbols.iter().map(|(symbol, _)| {
                    (
                        symbol.clone(),
                        SlArithmeticFunction::Constant(usize::from(symbol == distinguished)),
                    )
                }));
            model
        })
        .collect()
}

pub(crate) fn constructor_projection_affine_semantic_labeling_candidates(
    trs: &Trs,
    base_model: &SemanticLabelingModel,
    symbols: &[(Symbol, usize)],
) -> Vec<SemanticLabelingModel> {
    let constants = symbols
        .iter()
        .filter_map(|(symbol, arity)| (*arity == 0).then_some(symbol.clone()))
        .collect::<Vec<_>>();
    let projections = symbols
        .iter()
        .filter(|(symbol, arity)| *arity >= 2 && !symbol.as_str().ends_with('#'))
        .flat_map(|(symbol, arity)| (0..*arity).map(move |argument| (symbol.clone(), argument)))
        .collect::<Vec<_>>();
    if constants.len() < 2 || projections.is_empty() {
        return Vec::new();
    }

    let mut identity_symbols = BTreeSet::new();
    for rule in trs.rules() {
        let (
            Term::App {
                symbol: lhs_symbol,
                args: lhs_args,
            },
            Term::App {
                symbol: rhs_symbol,
                args: rhs_args,
            },
        ) = (rule.lhs(), rule.rhs())
        else {
            continue;
        };
        if lhs_symbol != rhs_symbol
            && lhs_args.len() == 1
            && rhs_args.len() == 1
            && lhs_args[0] == rhs_args[0]
        {
            identity_symbols.insert(lhs_symbol.clone());
            identity_symbols.insert(rhs_symbol.clone());
        }
    }
    if identity_symbols.len() < 2 {
        return Vec::new();
    }
    let affine_symbols = symbols
        .iter()
        .filter_map(|(symbol, arity)| {
            (*arity == 1 && !identity_symbols.contains(symbol) && !symbol.as_str().ends_with('#'))
                .then_some(symbol.clone())
        })
        .collect::<Vec<_>>();

    let mut candidates = Vec::new();
    for distinguished in &constants {
        for (projected, argument) in &projections {
            for affine in &affine_symbols {
                let mut model = base_model.clone();
                model
                    .interpretations
                    .extend(symbols.iter().map(|(symbol, arity)| {
                        let function = if symbol == projected {
                            SlArithmeticFunction::Argument(*argument)
                        } else if symbol == affine {
                            SlArithmeticFunction::Sum(vec![
                                SlArithmeticFunction::Constant(1),
                                SlArithmeticFunction::Argument(0),
                            ])
                        } else if *arity == 1 && identity_symbols.contains(symbol) {
                            SlArithmeticFunction::Argument(0)
                        } else {
                            SlArithmeticFunction::Constant(usize::from(
                                *arity == 0 && symbol == distinguished,
                            ))
                        };
                        (symbol.clone(), function)
                    }));
                candidates.push(model);
            }
        }
    }
    candidates
}

pub(crate) fn constructor_normalization_semantic_labeling_candidate(
    trs: &Trs,
    base_model: &SemanticLabelingModel,
    symbols: &[(Symbol, usize)],
) -> Option<SemanticLabelingModel> {
    let mut identity_symbols = BTreeSet::new();
    let mut distinguished_constants = BTreeSet::new();
    for rule in trs.rules() {
        let (
            Term::App {
                symbol: lhs_symbol,
                args: lhs_args,
            },
            Term::App {
                symbol: rhs_symbol,
                args: rhs_args,
            },
        ) = (rule.lhs(), rule.rhs())
        else {
            continue;
        };
        if lhs_symbol == rhs_symbol
            || lhs_args.len() != 1
            || rhs_args.len() != 1
            || lhs_args[0] != rhs_args[0]
        {
            continue;
        }
        identity_symbols.insert(lhs_symbol.clone());
        identity_symbols.insert(rhs_symbol.clone());
        if let Term::App {
            symbol: constant,
            args,
        } = &lhs_args[0]
            && args.is_empty()
        {
            distinguished_constants.insert(constant.clone());
        }
    }
    let distinguished = distinguished_constants.into_iter().next()?;
    if identity_symbols.len() < 2 {
        return None;
    }
    let mut model = base_model.clone();
    model
        .interpretations
        .extend(symbols.iter().map(|(symbol, arity)| {
            let function = if *arity == 1 && identity_symbols.contains(symbol) {
                SlArithmeticFunction::Argument(0)
            } else {
                SlArithmeticFunction::Constant(usize::from(*arity == 0 && *symbol == distinguished))
            };
            (symbol.clone(), function)
        }));
    Some(model)
}

#[cfg(test)]
pub(crate) fn binary_two_constant_semantic_labeling_candidate(
    base_model: &SemanticLabelingModel,
    symbols: &[(Symbol, usize)],
    lhs_symbols: &BTreeSet<Symbol>,
) -> Option<SemanticLabelingModel> {
    if symbols.len() != 4
        || symbols.iter().filter(|(_, arity)| *arity == 0).count() != 2
        || symbols.iter().filter(|(_, arity)| *arity == 2).count() != 2
    {
        return None;
    }
    let marked = symbols.iter().find_map(|(symbol, arity)| {
        (*arity == 2 && symbol.as_str().ends_with('#')).then_some(symbol)
    })?;
    let base_name = marked.as_str().strip_suffix('#')?;
    if !symbols
        .iter()
        .any(|(symbol, arity)| *arity == 2 && symbol.as_str() == base_name)
    {
        return None;
    }
    let mut model = base_model.clone();
    model
        .interpretations
        .extend(symbols.iter().map(|(symbol, arity)| {
            let value = usize::from(*arity == 0 && lhs_symbols.contains(symbol));
            (symbol.clone(), SlArithmeticFunction::Constant(value))
        }));
    Some(model)
}

#[cfg(test)]
pub(crate) fn binary_marked_semantic_labeling_candidates(
    base_model: &SemanticLabelingModel,
    symbols: &[(Symbol, usize)],
    pair_symbols: &BTreeSet<Symbol>,
) -> Vec<SemanticLabelingModel> {
    let constants = symbols
        .iter()
        .filter_map(|(symbol, arity)| (*arity == 0).then_some(symbol.clone()))
        .collect::<Vec<_>>();
    if constants.len() < 2
        || symbols.len() != constants.len() + 2
        || symbols.iter().filter(|(_, arity)| *arity == 2).count() != 2
    {
        return Vec::new();
    }
    let Some(marked) = symbols.iter().find_map(|(symbol, arity)| {
        (*arity == 2 && symbol.as_str().ends_with('#')).then_some(symbol.clone())
    }) else {
        return Vec::new();
    };
    let Some(base_name) = marked.as_str().strip_suffix('#') else {
        return Vec::new();
    };
    let Some(base) = symbols.iter().find_map(|(symbol, arity)| {
        (*arity == 2 && symbol.as_str() == base_name).then_some(symbol.clone())
    }) else {
        return Vec::new();
    };

    let binary_functions = if constants.len() == 2 {
        [
            SlArithmeticFunction::Argument(0),
            SlArithmeticFunction::Constant(0),
            SlArithmeticFunction::Argument(1),
        ]
    } else {
        [
            SlArithmeticFunction::Constant(0),
            SlArithmeticFunction::Argument(0),
            SlArithmeticFunction::Argument(1),
        ]
    };
    let mut distinguished_constants = constants.clone();
    distinguished_constants.sort_by_key(|constant| pair_symbols.contains(constant));
    let mut candidates = Vec::new();
    for distinguished in &distinguished_constants {
        for function in &binary_functions {
            let mut model = base_model.clone();
            for constant in &constants {
                model.interpretations.insert(
                    constant.clone(),
                    SlArithmeticFunction::Constant(usize::from(constant == distinguished)),
                );
            }
            model.interpretations.insert(base.clone(), function.clone());
            model
                .interpretations
                .insert(marked.clone(), SlArithmeticFunction::Constant(0));
            candidates.push(model);
        }
    }
    candidates
}

#[cfg(test)]
pub(crate) fn marked_with_unary_identity_semantic_labeling_candidates(
    base_model: &SemanticLabelingModel,
    symbols: &[(Symbol, usize)],
) -> Vec<SemanticLabelingModel> {
    let constants = symbols
        .iter()
        .filter_map(|(symbol, arity)| (*arity == 0).then_some(symbol.clone()))
        .collect::<Vec<_>>();
    if constants.len() != 2 || symbols.len() != 5 {
        return Vec::new();
    }
    let Some((marked, marked_arity)) = symbols.iter().find_map(|(symbol, arity)| {
        (*arity >= 2 && symbol.as_str().ends_with('#')).then_some((symbol.clone(), *arity))
    }) else {
        return Vec::new();
    };
    let Some(base_name) = marked.as_str().strip_suffix('#') else {
        return Vec::new();
    };
    let Some(base) = symbols.iter().find_map(|(symbol, arity)| {
        (*arity == marked_arity && symbol.as_str() == base_name).then_some(symbol.clone())
    }) else {
        return Vec::new();
    };
    let Some(unary) = symbols.iter().find_map(|(symbol, arity)| {
        (*arity == 1 && symbol != &marked && symbol != &base).then_some(symbol.clone())
    }) else {
        return Vec::new();
    };

    let mut distinguished_constants = constants.clone();
    distinguished_constants.reverse();
    distinguished_constants
        .into_iter()
        .map(|distinguished| {
            let mut model = base_model.clone();
            for constant in &constants {
                model.interpretations.insert(
                    constant.clone(),
                    SlArithmeticFunction::Constant(usize::from(*constant == distinguished)),
                );
            }
            model
                .interpretations
                .insert(unary.clone(), SlArithmeticFunction::Argument(0));
            model
                .interpretations
                .insert(base.clone(), SlArithmeticFunction::Constant(0));
            model
                .interpretations
                .insert(marked.clone(), SlArithmeticFunction::Constant(0));
            model
        })
        .collect()
}

#[cfg(test)]
pub(crate) fn unary_affine_semantic_labeling_candidate(
    base_model: &SemanticLabelingModel,
    symbols: &[(Symbol, usize)],
) -> Option<SemanticLabelingModel> {
    if symbols.len() != 3 || symbols.iter().any(|(_, arity)| *arity != 1) {
        return None;
    }
    let marked = symbols
        .iter()
        .find_map(|(symbol, _)| symbol.as_str().ends_with('#').then_some(symbol))?;
    let base_name = marked.as_str().strip_suffix('#')?;
    let base = symbols
        .iter()
        .find_map(|(symbol, _)| (symbol.as_str() == base_name).then_some(symbol))?;
    let other = symbols
        .iter()
        .find_map(|(symbol, _)| (symbol != marked && symbol != base).then_some(symbol))?;
    let mut model = base_model.clone();
    model
        .interpretations
        .insert(marked.clone(), SlArithmeticFunction::Constant(0));
    model.interpretations.insert(
        base.clone(),
        SlArithmeticFunction::Sum(vec![
            SlArithmeticFunction::Constant(1),
            SlArithmeticFunction::Argument(0),
        ]),
    );
    model
        .interpretations
        .insert(other.clone(), SlArithmeticFunction::Constant(0));
    Some(model)
}

/// Bounded low-support affine models over any signature. One symbol projects
/// any argument with a carrier offset; optionally one constant is nonzero.
/// These are search proposals, subject to the ordinary complete model check.
pub(crate) fn sparse_affine_semantic_labeling_candidates(
    base: &SemanticLabelingModel,
    symbols: &[(Symbol, usize)],
    limit: usize,
) -> Vec<SemanticLabelingModel> {
    let mut result = Vec::new();
    if limit == 0 || base.carrier_size == 0 {
        return result;
    }
    let constants = std::iter::once(None)
        .chain(
            symbols
                .iter()
                .filter_map(|(symbol, arity)| (*arity == 0).then_some(Some(symbol))),
        )
        .collect::<Vec<_>>();
    for distinguished in constants {
        for (symbol, arity) in symbols {
            for argument in 0..*arity {
                for offset in 0..base.carrier_size {
                    let mut model = base.clone();
                    model
                        .interpretations
                        .extend(symbols.iter().map(|(name, _)| {
                            (
                                name.clone(),
                                SlArithmeticFunction::Constant(usize::from(
                                    distinguished == Some(name),
                                )),
                            )
                        }));
                    let projection = SlArithmeticFunction::Argument(argument);
                    model.interpretations.insert(
                        symbol.clone(),
                        if offset == 0 {
                            projection
                        } else {
                            SlArithmeticFunction::Sum(vec![
                                SlArithmeticFunction::Constant(offset),
                                projection,
                            ])
                        },
                    );
                    result.push(model);
                    if result.len() == limit {
                        return result;
                    }
                }
            }
        }
    }
    result
}

#[cfg(test)]
mod sparse_model_tests {
    use super::*;

    #[test]
    fn sparse_affine_models_cover_extra_symbols_and_arbitrary_arguments() {
        for names in [["root", "constant", "extra"], ["renamed", "nil", "aux"]] {
            let symbols = vec![
                (Symbol::new(names[0]), 4),
                (Symbol::new(names[1]), 0),
                (Symbol::new(names[2]), 2),
            ];
            let base = SemanticLabelingModel {
                carrier_size: 3,
                arities: symbols.iter().cloned().collect(),
                interpretations: BTreeMap::new(),
            };
            let models = sparse_affine_semantic_labeling_candidates(&base, &symbols, 100);
            assert_eq!(models.len(), 36);
            assert!(
                models
                    .iter()
                    .any(
                        |m| m.interpretations[&symbols[0].0].eval(&[0, 0, 0, 1], 3) == Some(0)
                            && m.interpretations[&symbols[0].0].eval(&[0, 0, 0, 0], 3) == Some(2)
                            && m.interpretations[&symbols[1].0].eval(&[], 3) == Some(1)
                    )
            );
            assert!(models.iter().all(|m| m.interpretations.len() == 3));
            assert_eq!(
                sparse_affine_semantic_labeling_candidates(&base, &symbols, 2).len(),
                2
            );
            assert!(sparse_affine_semantic_labeling_candidates(&base, &symbols, 0).is_empty());
        }
    }
}

pub(crate) fn semantic_labeling_context_rules(
    trs: &Trs,
    _pairs: &[DependencyPair],
    _innermost_lhss: Option<&[Term]>,
) -> Vec<RewriteRule> {
    // Q (represented by ``innermost_lhss``) constrains normal-form
    // substitutions; it is not part of R.  Adding rules recovered from Q here
    // produces a semantic-labeling certificate over a larger TRS than the
    // current DP problem.  CeTA correctly rejects that certificate because
    // those labeled rules are not allowed.
    trs.rules().to_vec()
}

pub(crate) fn semlab_timed_out_or_cancelled(
    deadline: Option<Instant>,
    cancellation: &DpStrategyCancellation,
) -> bool {
    strategy_timed_out(deadline) || cancellation.is_cancelled() || current_thread_cancelled()
}

pub(crate) fn semantic_labeling_model_condition_holds(
    model: &SemanticLabelingModel,
    rules: &[RewriteRule],
    deadline: Option<Instant>,
    cancellation: &DpStrategyCancellation,
) -> bool {
    rules.iter().all(|rule| {
        if semlab_timed_out_or_cancelled(deadline, cancellation) {
            return false;
        }
        let mut variables = rule.lhs().variables();
        variables.extend(rule.rhs().variables());
        let variables = variables.into_iter().collect::<Vec<_>>();
        semantic_labeling_rule_model_condition_holds(
            model,
            rule,
            &variables,
            0,
            &mut BTreeMap::new(),
            deadline,
            cancellation,
        )
    })
}

fn semantic_labeling_rule_model_condition_holds(
    model: &SemanticLabelingModel,
    rule: &RewriteRule,
    variables: &[Variable],
    index: usize,
    env: &mut BTreeMap<Variable, usize>,
    deadline: Option<Instant>,
    cancellation: &DpStrategyCancellation,
) -> bool {
    if semlab_timed_out_or_cancelled(deadline, cancellation) || model.carrier_size == 0 {
        return false;
    }
    if index == variables.len() {
        let Some((_, lhs_value)) = semantic_label_term(model, rule.lhs(), env) else {
            return false;
        };
        let Some((_, rhs_value)) = semantic_label_term(model, rule.rhs(), env) else {
            return false;
        };
        return lhs_value == rhs_value;
    }
    let variable = variables[index].clone();
    for value in 0..model.carrier_size {
        if semlab_timed_out_or_cancelled(deadline, cancellation) {
            env.remove(&variable);
            return false;
        }
        env.insert(variable.clone(), value);
        if !semantic_labeling_rule_model_condition_holds(
            model,
            rule,
            variables,
            index + 1,
            env,
            deadline,
            cancellation,
        ) {
            env.remove(&variable);
            return false;
        }
    }
    env.remove(&variable);
    true
}

pub(crate) fn semantic_labeling_arities(
    trs: &Trs,
    pairs: &[DependencyPair],
    extra_terms: Option<&[Term]>,
) -> BTreeMap<Symbol, usize> {
    let mut arities = BTreeMap::new();
    for rule in trs.rules() {
        collect_symbol_arities(rule.lhs(), &mut arities);
        collect_symbol_arities(rule.rhs(), &mut arities);
    }
    for pair in pairs {
        collect_symbol_arities(pair.lhs(), &mut arities);
        collect_symbol_arities(pair.rhs(), &mut arities);
    }
    for term in extra_terms.into_iter().flatten() {
        collect_symbol_arities(term, &mut arities);
    }
    arities
}

pub(crate) fn collect_symbol_arities(term: &Term, arities: &mut BTreeMap<Symbol, usize>) {
    if let Term::App { symbol, args } = term {
        arities.insert(symbol.clone(), args.len());
        for arg in args {
            collect_symbol_arities(arg, arities);
        }
    }
}

pub(crate) fn semantic_labeling_function_candidates(
    arity: usize,
    carrier_size: usize,
    prefer_nonzero_constant: bool,
) -> Vec<SlArithmeticFunction> {
    let mut constant_values = (0..carrier_size).collect::<Vec<_>>();
    if arity == 0 || prefer_nonzero_constant {
        constant_values.reverse();
    }
    let mut candidates = constant_values
        .into_iter()
        .map(SlArithmeticFunction::Constant)
        .collect::<Vec<_>>();
    for index in 0..arity {
        candidates.push(SlArithmeticFunction::Argument(index));
    }
    if arity > 0 {
        let args = (0..arity)
            .map(SlArithmeticFunction::Argument)
            .collect::<Vec<_>>();
        for index in 0..arity {
            candidates.push(SlArithmeticFunction::Sum(vec![
                SlArithmeticFunction::Constant(1),
                SlArithmeticFunction::Argument(index),
            ]));
        }
        candidates.push(SlArithmeticFunction::Sum(args.clone()));
        candidates.push(SlArithmeticFunction::Sum(
            std::iter::once(SlArithmeticFunction::Constant(1))
                .chain(args.iter().cloned())
                .collect(),
        ));
        candidates.push(SlArithmeticFunction::Product(args));
    }
    candidates
}

/// Synthesize one carrier-two quasi-model with the direct SAT backend.
///
/// DP semantic labeling historically tried a fixed set of structural models
/// followed by lexicographic enumeration.  That misses small, genuinely
/// semantic invariants (for example, the finite-list guard in the Maude
/// encodings) until very late or altogether.  Keep materialization and exact
/// validation unchanged, but expose the same checked SAT synthesis already
/// used by relative semantic labeling to the DP worklist.
pub(crate) fn direct_sat_semantic_labeling_candidate(
    trs: &Trs,
    symbols: &[(Symbol, usize)],
    defined_symbols: &BTreeSet<Symbol>,
    lhs_symbols: &BTreeSet<Symbol>,
    base_model: &SemanticLabelingModel,
    deadline: Option<Instant>,
    cancellation: &DpStrategyCancellation,
) -> Option<SemanticLabelingModel> {
    direct_sat_semantic_labeling::synthesize(
        trs,
        symbols,
        defined_symbols,
        lhs_symbols,
        base_model,
        deadline,
        cancellation,
    )
}

pub(crate) fn conjunctive_sat_semantic_labeling_candidate(
    trs: &Trs,
    symbols: &[(Symbol, usize)],
    base_model: &SemanticLabelingModel,
    deadline: Option<Instant>,
    cancellation: &DpStrategyCancellation,
) -> Option<SemanticLabelingModel> {
    direct_sat_semantic_labeling::synthesize_conjunctive(trs, symbols, base_model, deadline, cancellation)
}

/// Jointly choose a carrier-two labeling and label-dependent linear order
/// that makes progress on the current dependency pairs.  The TRS rules remain
/// quasi-model equalities; only the pair copies are used as strict goals.
pub(crate) fn goal_directed_sat_semantic_labeling_candidate(
    trs: &Trs,
    pairs: &[DependencyPair],
    symbols: &[(Symbol, usize)],
    base_model: &SemanticLabelingModel,
    deadline: Option<Instant>,
    cancellation: &DpStrategyCancellation,
) -> Option<(SemanticLabelingModel, Vec<(String, i64, Vec<i64>)>)> {
    let strict_rules = pairs
        .iter()
        .map(|pair| RewriteRule::new(pair.lhs().clone(), pair.rhs().clone()))
        .collect();
    let strict = Trs::new_with_strategy(
        trs.name().map(str::to_string),
        trs.variables().clone(),
        strict_rules,
        trs.strategy(),
    );
    let relative = RelativeTrs::new(strict, trs.rules().to_vec());
    direct_sat_semantic_labeling::synthesize_goal_directed_relative(
        &relative,
        symbols,
        base_model,
        deadline,
        cancellation,
    )
}

pub(crate) fn semantic_label_rule_instances(
    model: &SemanticLabelingModel,
    rule: &RewriteRule,
    deadline: Option<Instant>,
    cancellation: &DpStrategyCancellation,
) -> Option<Vec<RewriteRule>> {
    let mut variables = rule.lhs().variables();
    variables.extend(rule.rhs().variables());
    semantic_label_rule_instances_for_variables(
        model,
        rule,
        variables.into_iter().collect(),
        deadline,
        cancellation,
    )
}

#[cfg(test)]
pub(crate) fn root_label_relative_trs(
    relative: &RelativeTrs,
    deadline: Option<Instant>,
) -> Option<RelativeSemanticLabeling> {
    let union = relative.union();
    let arities = union.arities();
    if arities.is_empty() || arities.keys().any(is_semantic_label_symbol) {
        return None;
    }
    let interpretations = arities
        .keys()
        .enumerate()
        .map(|(index, symbol)| (symbol.clone(), SlArithmeticFunction::Constant(index)))
        .collect();
    let model = SemanticLabelingModel {
        carrier_size: arities.len(),
        arities,
        interpretations,
    };
    label_relative_trs_with_model(relative, model, deadline)
}

pub(crate) fn synthesize_finite_label_relative_trs(
    relative: &RelativeTrs,
    carrier_size: usize,
    deadline: Option<Instant>,
) -> Option<RelativeSemanticLabeling> {
    let union = relative.union();
    let arities = union.arities();
    if arities.is_empty() || arities.keys().any(is_semantic_label_symbol) {
        return None;
    }
    let symbols = arities
        .iter()
        .map(|(f, a)| (f.clone(), *a))
        .collect::<Vec<_>>();
    let mut lhs_arities = BTreeMap::new();
    for rule in union.rules() {
        collect_symbol_arities(rule.lhs(), &mut lhs_arities);
    }
    if carrier_size == 0 {
        return None;
    }
    let model = SemanticLabelingModel {
        carrier_size,
        arities,
        interpretations: BTreeMap::new(),
    };
    let cancellation = DpStrategyCancellation::current(deadline);
    let model = if carrier_size == 2 {
        direct_sat_semantic_labeling::synthesize_goal_directed_relative(
            relative,
            &symbols,
            &model,
            deadline,
            &cancellation,
        )
        .map(|(model, _)| model)
        .or_else(|| {
            direct_sat_semantic_labeling::synthesize(
                &union,
                &symbols,
                &union.defined_symbols(),
                &lhs_arities.into_keys().collect(),
                &model,
                deadline,
                &cancellation,
            )
        })?
    } else {
        SemanticLabelingModel {
            carrier_size,
            arities: model.arities,
            interpretations: symbols
                .iter()
                .enumerate()
                .map(|(index, (symbol, _))| {
                    (
                        symbol.clone(),
                        SlArithmeticFunction::Constant(index % carrier_size),
                    )
                })
                .collect(),
        }
    };
    label_relative_trs_with_model(relative, model, deadline)
}

pub(crate) fn label_relative_trs_with_model(
    relative: &RelativeTrs,
    model: SemanticLabelingModel,
    deadline: Option<Instant>,
) -> Option<RelativeSemanticLabeling> {
    let union = relative.union();
    let cancellation = DpStrategyCancellation::current(deadline);
    if !semantic_labeling_model_condition_holds(&model, union.rules(), deadline, &cancellation) {
        return None;
    }
    let label_rules = |rules: &[RewriteRule]| -> Option<Vec<RewriteRule>> {
        let mut labeled = Vec::new();
        for rule in rules {
            labeled.extend(semantic_label_rule_instances(
                &model,
                rule,
                deadline,
                &cancellation,
            )?);
        }
        alpha_unique_rules_with_deadline(labeled, deadline, &cancellation)
    };
    let strict_rules = label_rules(relative.strict().rules())?;
    let weak_rules = label_rules(relative.weak_rules())?;
    let mut labeled_rules = strict_rules.clone();
    labeled_rules.extend(weak_rules.iter().cloned());
    labeled_rules = alpha_unique_rules_with_deadline(labeled_rules, deadline, &cancellation)?;
    let relative = RelativeTrs::new(
        Trs::new_with_strategy(
            relative.strict().name().map(str::to_string),
            relative.strict().variables().clone(),
            strict_rules,
            relative.strict().strategy(),
        ),
        weak_rules,
    );
    Some(RelativeSemanticLabeling {
        model,
        labeled_rules,
        relative,
    })
}

fn semantic_label_rule_instances_for_variables(
    model: &SemanticLabelingModel,
    rule: &RewriteRule,
    variables: Vec<Variable>,
    deadline: Option<Instant>,
    cancellation: &DpStrategyCancellation,
) -> Option<Vec<RewriteRule>> {
    if model.carrier_size == 0 || semlab_timed_out_or_cancelled(deadline, cancellation) {
        return None;
    }
    let mut instances = Vec::new();
    let mut env = BTreeMap::new();
    semantic_label_rule_instances_rec(
        model,
        rule,
        &variables,
        0,
        &mut env,
        &mut instances,
        deadline,
        cancellation,
    )?;
    alpha_unique_rules_with_deadline(instances, deadline, cancellation)
}

fn semantic_label_rule_instances_rec(
    model: &SemanticLabelingModel,
    rule: &RewriteRule,
    variables: &[Variable],
    index: usize,
    env: &mut BTreeMap<Variable, usize>,
    instances: &mut Vec<RewriteRule>,
    deadline: Option<Instant>,
    cancellation: &DpStrategyCancellation,
) -> Option<()> {
    if semlab_timed_out_or_cancelled(deadline, cancellation) {
        return None;
    }
    if index == variables.len() {
        let (lhs, _) = semantic_label_term(model, rule.lhs(), env)?;
        let (rhs, _) = semantic_label_term(model, rule.rhs(), env)?;
        instances.push(RewriteRule::new(lhs, rhs));
        return Some(());
    }
    let variable = variables[index].clone();
    for value in 0..model.carrier_size {
        if semlab_timed_out_or_cancelled(deadline, cancellation) {
            env.remove(&variable);
            return None;
        }
        env.insert(variable.clone(), value);
        semantic_label_rule_instances_rec(
            model,
            rule,
            variables,
            index + 1,
            env,
            instances,
            deadline,
            cancellation,
        )?;
    }
    env.remove(&variable);
    Some(())
}

pub(crate) fn semantic_label_pair_instances(
    model: &SemanticLabelingModel,
    pair: &DependencyPair,
    deadline: Option<Instant>,
    cancellation: &DpStrategyCancellation,
) -> Option<Vec<DependencyPair>> {
    semantic_label_rule_instances(model, &pair.as_rule(), deadline, cancellation).map(|rules| {
        rules
            .into_iter()
            .map(|rule| DependencyPair {
                lhs: rule.lhs().clone(),
                rhs: rule.rhs().clone(),
                source_rule: pair.source_rule,
            })
            .collect()
    })
}

pub(crate) fn semantic_label_terms(
    model: &SemanticLabelingModel,
    terms: &[Term],
    deadline: Option<Instant>,
    cancellation: &DpStrategyCancellation,
) -> Option<Vec<Term>> {
    let mut labeled = Vec::new();
    for term in terms {
        if semlab_timed_out_or_cancelled(deadline, cancellation) {
            return None;
        }
        let variables = term.variables().into_iter().collect::<Vec<_>>();
        let rule = RewriteRule::new(term.clone(), term.clone());
        for instance in semantic_label_rule_instances_for_variables(
            model,
            &rule,
            variables,
            deadline,
            cancellation,
        )? {
            labeled.push(instance.lhs().clone());
        }
    }
    alpha_unique_terms_with_deadline(labeled, deadline, cancellation)
}

fn semantic_label_term(
    model: &SemanticLabelingModel,
    term: &Term,
    env: &BTreeMap<Variable, usize>,
) -> Option<(Term, usize)> {
    match term {
        Term::Var(variable) => Some((Term::Var(variable.clone()), *env.get(variable)?)),
        Term::App { symbol, args } => {
            let mut labeled_args = Vec::with_capacity(args.len());
            let mut arg_values = Vec::with_capacity(args.len());
            for arg in args {
                let (labeled, value) = semantic_label_term(model, arg, env)?;
                labeled_args.push(labeled);
                arg_values.push(value);
            }
            let interpretation = model.interpretations.get(symbol)?;
            let value = interpretation.eval(&arg_values, model.carrier_size)?;
            Some((
                Term::app(semantic_label_symbol(symbol, &arg_values), labeled_args),
                value,
            ))
        }
    }
}

pub(crate) fn semantic_label_symbol(symbol: &Symbol, labels: &[usize]) -> String {
    format!(
        "__ferrum_sl__{}__{}",
        hex_encode(symbol.as_str()),
        labels
            .iter()
            .map(usize::to_string)
            .collect::<Vec<_>>()
            .join("_")
    )
}

pub(crate) fn semantic_label_base_symbol(symbol: &Symbol) -> Option<Symbol> {
    let encoded = symbol.as_str().strip_prefix("__ferrum_sl__")?;
    let (hex, _) = encoded.split_once("__")?;
    if hex.len() % 2 != 0 {
        return None;
    }
    let bytes = (0..hex.len())
        .step_by(2)
        .map(|index| u8::from_str_radix(&hex[index..index + 2], 16).ok())
        .collect::<Option<Vec<_>>>()?;
    String::from_utf8(bytes).ok().map(Symbol::new)
}

/// The unmarked companion of a sharp symbol, preserving every semantic-label
/// layer. Iterative decoding is bounded by the strictly decreasing name length.
pub(crate) fn semantic_label_unmarked_companion(symbol: &Symbol) -> Option<Symbol> {
    let mut current = symbol.clone();
    let mut layers = Vec::new();
    loop {
        if let Some(base) = current.as_str().strip_suffix('#') {
            let mut result = base.to_owned();
            for labels in layers.into_iter().rev() {
                result = format!("__ferrum_sl__{}__{}", hex_encode(&result), labels);
            }
            return Some(Symbol::new(result));
        }
        let encoded = current.as_str().strip_prefix("__ferrum_sl__")?;
        let (_, labels) = encoded.split_once("__")?;
        if !labels.is_empty() && labels.split('_').any(|label| label.parse::<usize>().is_err()) {
            return None;
        }
        layers.push(labels.to_owned());
        current = semantic_label_base_symbol(&current)?;
    }
}

fn is_semantic_label_symbol(symbol: &Symbol) -> bool {
    symbol.as_str().starts_with("__ferrum_sl__")
}

fn hex_encode(input: &str) -> String {
    const HEX: &[u8; 16] = b"0123456789abcdef";
    let mut output = String::with_capacity(input.len() * 2);
    for byte in input.as_bytes() {
        output.push(HEX[(byte >> 4) as usize] as char);
        output.push(HEX[(byte & 0x0f) as usize] as char);
    }
    output
}
